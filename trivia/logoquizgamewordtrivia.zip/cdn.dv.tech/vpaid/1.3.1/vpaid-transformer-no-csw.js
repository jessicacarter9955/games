/*!
 * v1.3.1 (c) 2026
 *
 * Includes:
 * - https://www.npmjs.com/package/bowser
 * - https://www.npmjs.com/package/delay
 * - https://www.npmjs.com/package/es6-error
 * - https://www.npmjs.com/package/es6-symbol
 * - https://www.npmjs.com/package/eventemitter3
 * - https://www.npmjs.com/package/json-stringify-safe
 * - https://www.npmjs.com/package/p-defer
 * - https://www.npmjs.com/package/promise-queue
 * - https://www.npmjs.com/package/protochain
 * - https://www.npmjs.com/package/unfetch
 * - https://www.npmjs.com/package/upper-case-first
 */
!(function () {
  Function.prototype.$asyncbind = function e(t, n) {
    "use strict";
    function r() {
      return i.apply(t, arguments);
    }
    Function.prototype.$asyncbind ||
      Object.defineProperty(Function.prototype, "$asyncbind", {
        value: e,
        enumerable: !1,
        configurable: !0,
        writable: !0,
      }),
      e.trampoline ||
        (e.trampoline = function (e, t, n, r, i) {
          return function s(o) {
            for (; o; ) {
              if (o.then) return (o = o.then(s, r)), i ? void 0 : o;
              try {
                if (o.pop) {
                  if (o.length) return o.pop() ? t.call(e) : o;
                  o = n;
                } else o = o.call(e);
              } catch (e) {
                return r(e);
              }
            }
          };
        }),
      e.LazyThenable ||
        ((e.LazyThenable = (function () {
          function e(e) {
            return e && e instanceof Object && "function" == typeof e.then;
          }
          function t(n, r, i) {
            try {
              var s = i ? i(r) : r;
              if (n === s)
                return n.reject(new TypeError("Promise resolution loop"));
              e(s)
                ? s.then(
                    function (e) {
                      t(n, e);
                    },
                    function (e) {
                      n.reject(e);
                    }
                  )
                : n.resolve(s);
            } catch (e) {
              n.reject(e);
            }
          }
          function n(e) {}
          function r() {}
          function i(n, i) {
            var s = new r();
            try {
              this._resolver(
                function (r) {
                  return e(r) ? r.then(n, i) : t(s, r, n);
                },
                function (e) {
                  t(s, e, i);
                }
              );
            } catch (e) {
              t(s, e, i);
            }
            return s;
          }
          function s(e) {
            (this._resolver = e), (this.then = i);
          }
          return (
            (r.prototype = {
              resolve: n,
              reject: n,
              then: function (e, t) {
                (this.resolve = e), (this.reject = t);
              },
            }),
            (s.resolve = function (e) {
              return s.isThenable(e)
                ? e
                : {
                    then: function (t) {
                      return t(e);
                    },
                  };
            }),
            (s.isThenable = e),
            s
          );
        })()),
        (e.EagerThenable = e.Thenable =
          (e.EagerThenableFactory = function (e) {
            e =
              e ||
              ("object" == typeof process && process.nextTick) ||
              ("function" == typeof setImmediate && setImmediate) ||
              function (e) {
                setTimeout(e, 0);
              };
            var t = (function () {
              var t = [],
                n = 0;
              function r() {
                for (; t.length - n; ) {
                  try {
                    t[n]();
                  } catch (e) {}
                  (t[n++] = void 0), 1024 === n && (t.splice(0, 1024), (n = 0));
                }
              }
              return function (i) {
                t.push(i), t.length - n === 1 && e(r);
              };
            })();
            function n(e) {
              if (e) {
                var t = this;
                e(
                  function (e) {
                    t.resolve(e);
                  },
                  function (e) {
                    t.reject(e);
                  }
                );
              }
            }
            function r(e, t) {
              if ("function" == typeof e.y)
                try {
                  var n = e.y.call(void 0, t);
                  e.p.resolve(n);
                } catch (t) {
                  e.p.reject(t);
                }
              else e.p.resolve(t);
            }
            function i(e, t) {
              if ("function" == typeof e.n)
                try {
                  var n = e.n.call(void 0, t);
                  e.p.resolve(n);
                } catch (t) {
                  e.p.reject(t);
                }
              else e.p.reject(t);
            }
            return (
              (n.prototype = {
                resolve: function (e) {
                  if (void 0 === this.state) {
                    if (e === this)
                      return this.reject(
                        new TypeError("Attempt to resolve promise with self")
                      );
                    var n = this;
                    if (e && ("function" == typeof e || "object" == typeof e))
                      try {
                        var i = 0,
                          s = e.then;
                        if ("function" == typeof s)
                          return void s.call(
                            e,
                            function (e) {
                              i++ || n.resolve(e);
                            },
                            function (e) {
                              i++ || n.reject(e);
                            }
                          );
                      } catch (e) {
                        return void (i || this.reject(e));
                      }
                    (this.state = r),
                      (this.v = e),
                      n.c &&
                        t(function () {
                          for (var t = 0, i = n.c.length; t < i; t++)
                            r(n.c[t], e);
                        });
                  }
                },
                reject: function (e) {
                  if (void 0 === this.state) {
                    (this.state = i), (this.v = e);
                    var n = this.c;
                    n &&
                      t(function () {
                        for (var t = 0, r = n.length; t < r; t++) i(n[t], e);
                      });
                  }
                },
                then: function (e, r) {
                  var i = new n(),
                    s = { y: e, n: r, p: i };
                  if (void 0 === this.state)
                    this.c ? this.c.push(s) : (this.c = [s]);
                  else {
                    var o = this.state,
                      a = this.v;
                    t(function () {
                      o(s, a);
                    });
                  }
                  return i;
                },
              }),
              (n.resolve = function (e) {
                if (e && e instanceof n) return e;
                var t = new n();
                return t.resolve(e), t;
              }),
              (n.reject = function (e) {
                if (e && e instanceof n) return e;
                var t = new n();
                return t.reject(e), t;
              }),
              (n.version = "2.3.3-nodent"),
              n
            );
          })()));
    var i = this;
    switch (n) {
      case !0:
        return new e.Thenable(r);
      case 0:
        return new e.LazyThenable(r);
      case void 0:
        return (r.then = r), r;
      default:
        return function () {
          try {
            return i.apply(t, arguments);
          } catch (e) {
            return n(e);
          }
        };
    }
  };
  var e,
    t,
    n,
    r,
    i,
    s,
    o,
    a,
    l = !1,
    u = "1.3.1";
  function c(e) {
    return e &&
      e.__esModule &&
      Object.prototype.hasOwnProperty.call(e, "default")
      ? e.default
      : e;
  }
  function d() {
    return s
      ? i
      : ((s = 1),
        (i = (t
          ? e
          : ((t = 1),
            (e = function () {
              return (
                "object" == typeof globalThis &&
                !!globalThis &&
                globalThis.Array === Array
              );
            })))()
          ? globalThis
          : (function () {
              if (r) return n;
              r = 1;
              var e = function () {
                if ("object" == typeof self && self) return self;
                if ("object" == typeof window && window) return window;
                throw new Error("Unable to resolve global `this`");
              };
              return (n = (function () {
                if (this) return this;
                try {
                  Object.defineProperty(Object.prototype, "__global__", {
                    get: function () {
                      return this;
                    },
                    configurable: !0,
                  });
                } catch (t) {
                  return e();
                }
                try {
                  return __global__ || e();
                } finally {
                  delete Object.prototype.__global__;
                }
              })());
            })()));
  }
  var h,
    p,
    f,
    m,
    g,
    v,
    y,
    b,
    _,
    w,
    A,
    k,
    S,
    P,
    E,
    C,
    x,
    T,
    O,
    I,
    M,
    V,
    j,
    F,
    L,
    R,
    D,
    $,
    N,
    U,
    B,
    z,
    W,
    q,
    H,
    G,
    Q,
    Y,
    X,
    K,
    Z,
    J,
    ee,
    te,
    ne,
    re,
    ie,
    se,
    oe,
    ae,
    le = { exports: {} };
  function ue() {
    return p
      ? h
      : ((p = 1),
        (h = function (e) {
          return null != e;
        }));
  }
  function ce() {
    if (T) return x;
    T = 1;
    var e = (C ? E : ((C = 1), (E = function () {})))();
    return (x = function (t) {
      return t !== e && null !== t;
    });
  }
  function de() {
    return (
      V ||
        ((V = 1),
        (M = (P
          ? S
          : ((P = 1),
            (S = function () {
              try {
                return Object.keys("primitive"), !0;
              } catch (e) {
                return !1;
              }
            })))()
          ? Object.keys
          : (function () {
              if (I) return O;
              I = 1;
              var e = ce(),
                t = Object.keys;
              return (O = function (n) {
                return t(e(n) ? Object(n) : n);
              });
            })())),
      M
    );
  }
  function he() {
    return $
      ? D
      : (($ = 1),
        (D = (k ||
          ((k = 1),
          (A = function () {
            var e,
              t = Object.assign;
            return (
              "function" == typeof t &&
              (t((e = { foo: "raz" }), { bar: "dwa" }, { trzy: "trzy" }),
              e.foo + e.bar + e.trzy === "razdwatrzy")
            );
          })),
        A)()
          ? Object.assign
          : (function () {
              if (R) return L;
              R = 1;
              var e = de(),
                t = (function () {
                  if (F) return j;
                  F = 1;
                  var e = ce();
                  return (j = function (t) {
                    if (!e(t))
                      throw new TypeError("Cannot use null or undefined");
                    return t;
                  });
                })(),
                n = Math.max;
              return (
                (L = function (r, i) {
                  var s,
                    o,
                    a,
                    l = n(arguments.length, 2);
                  for (
                    r = Object(t(r)),
                      a = function (e) {
                        try {
                          r[e] = i[e];
                        } catch (e) {
                          s || (s = e);
                        }
                      },
                      o = 1;
                    o < l;
                    ++o
                  )
                    e((i = arguments[o])).forEach(a);
                  if (void 0 !== s) throw s;
                  return r;
                }),
                L
              );
            })()));
  }
  function pe() {
    return (
      G ||
        ((G = 1),
        (H = (function () {
          if (z) return B;
          z = 1;
          var e = "razdwatrzy";
          return (B = function () {
            return (
              "function" == typeof e.contains &&
              !0 === e.contains("dwa") &&
              !1 === e.contains("foo")
            );
          });
        })()()
          ? String.prototype.contains
          : (function () {
              if (q) return W;
              q = 1;
              var e = String.prototype.indexOf;
              return (
                (W = function (t) {
                  return e.call(this, t, arguments[1]) > -1;
                }),
                W
              );
            })())),
      H
    );
  }
  function fe() {
    if (Q) return le.exports;
    Q = 1;
    var e = ue(),
      t = (function () {
        if (w) return _;
        w = 1;
        var e = (function () {
            if (b) return y;
            b = 1;
            var e = (function () {
              if (v) return g;
              v = 1;
              var e = (function () {
                if (m) return f;
                m = 1;
                var e = ue(),
                  t = { object: !0, function: !0, undefined: !0 };
                return (f = function (n) {
                  return !!e(n) && hasOwnProperty.call(t, typeof n);
                });
              })();
              return (g = function (t) {
                if (!e(t)) return !1;
                try {
                  return !!t.constructor && t.constructor.prototype === t;
                } catch (e) {
                  return !1;
                }
              });
            })();
            return (y = function (t) {
              if ("function" != typeof t) return !1;
              if (!hasOwnProperty.call(t, "length")) return !1;
              try {
                if ("number" != typeof t.length) return !1;
                if ("function" != typeof t.call) return !1;
                if ("function" != typeof t.apply) return !1;
              } catch (e) {
                return !1;
              }
              return !e(t);
            });
          })(),
          t = /^\s*class[\s{/}]/,
          n = Function.prototype.toString;
        return (_ = function (r) {
          return !!e(r) && !t.test(n.call(r));
        });
      })(),
      n = he(),
      r = (function () {
        if (U) return N;
        U = 1;
        var e = ce(),
          t = Array.prototype.forEach,
          n = Object.create;
        return (
          (N = function (r) {
            var i = n(null);
            return (
              t.call(arguments, function (t) {
                e(t) &&
                  (function (e, t) {
                    var n;
                    for (n in e) t[n] = e[n];
                  })(Object(t), i);
              }),
              i
            );
          }),
          N
        );
      })(),
      i = pe(),
      s = (le.exports = function (t, s) {
        var o, a, l, u, c;
        return (
          arguments.length < 2 || "string" != typeof t
            ? ((u = s), (s = t), (t = null))
            : (u = arguments[2]),
          e(t)
            ? ((o = i.call(t, "c")), (a = i.call(t, "e")), (l = i.call(t, "w")))
            : ((o = l = !0), (a = !1)),
          (c = { value: s, configurable: o, enumerable: a, writable: l }),
          u ? n(r(u), c) : c
        );
      });
    return (
      (s.gs = function (s, o, a) {
        var l, u, c, d;
        return (
          "string" != typeof s
            ? ((c = a), (a = o), (o = s), (s = null))
            : (c = arguments[3]),
          e(o)
            ? t(o)
              ? e(a)
                ? t(a) || ((c = a), (a = void 0))
                : (a = void 0)
              : ((c = o), (o = a = void 0))
            : (o = void 0),
          e(s)
            ? ((l = i.call(s, "c")), (u = i.call(s, "e")))
            : ((l = !0), (u = !1)),
          (d = { get: o, set: a, configurable: l, enumerable: u }),
          c ? n(r(c), d) : d
        );
      }),
      le.exports
    );
  }
  function me() {
    return X
      ? Y
      : ((X = 1),
        (Y = function (e) {
          return (
            !!e &&
            ("symbol" == typeof e ||
              (!!e.constructor &&
                "Symbol" === e.constructor.name &&
                "Symbol" === e[e.constructor.toStringTag]))
          );
        }));
  }
  function ge() {
    if (Z) return K;
    Z = 1;
    var e = me();
    return (K = function (t) {
      if (!e(t)) throw new TypeError(t + " is not a symbol");
      return t;
    });
  }
  function ve() {
    if (ee) return J;
    ee = 1;
    var e = fe(),
      t = Object.create,
      n = Object.defineProperty,
      r = Object.prototype,
      i = t(null);
    return (J = function (t) {
      for (var s, o, a = 0; i[t + (a || "")]; ) ++a;
      return (
        (i[(t += a || "")] = !0),
        n(
          r,
          (s = "@@" + t),
          e.gs(null, function (t) {
            o || ((o = !0), n(this, s, e(t)), (o = !1));
          })
        ),
        s
      );
    });
  }
  ae ||
    ((ae = 1),
    (function () {
      if (a) return o;
      a = 1;
      var e = d(),
        t = { object: !0, symbol: !0 };
      return (o = function () {
        var n,
          r = e.Symbol;
        if ("function" != typeof r) return !1;
        n = r("test symbol");
        try {
          String(n);
        } catch (e) {
          return !1;
        }
        return (
          !!t[typeof r.iterator] &&
          !!t[typeof r.toPrimitive] &&
          !!t[typeof r.toStringTag]
        );
      });
    })()() ||
      Object.defineProperty(d(), "Symbol", {
        value: (function () {
          if (oe) return se;
          oe = 1;
          var e,
            t,
            n,
            r = fe(),
            i = ge(),
            s = d().Symbol,
            o = ve(),
            a = (function () {
              if (ne) return te;
              ne = 1;
              var e = fe(),
                t = d().Symbol;
              return (te = function (n) {
                return Object.defineProperties(n, {
                  hasInstance: e("", (t && t.hasInstance) || n("hasInstance")),
                  isConcatSpreadable: e(
                    "",
                    (t && t.isConcatSpreadable) || n("isConcatSpreadable")
                  ),
                  iterator: e("", (t && t.iterator) || n("iterator")),
                  match: e("", (t && t.match) || n("match")),
                  replace: e("", (t && t.replace) || n("replace")),
                  search: e("", (t && t.search) || n("search")),
                  species: e("", (t && t.species) || n("species")),
                  split: e("", (t && t.split) || n("split")),
                  toPrimitive: e("", (t && t.toPrimitive) || n("toPrimitive")),
                  toStringTag: e("", (t && t.toStringTag) || n("toStringTag")),
                  unscopables: e("", (t && t.unscopables) || n("unscopables")),
                });
              });
            })(),
            l = (function () {
              if (ie) return re;
              ie = 1;
              var e = fe(),
                t = ge(),
                n = Object.create(null);
              return (
                (re = function (r) {
                  return Object.defineProperties(r, {
                    for: e(function (e) {
                      return n[e] ? n[e] : (n[e] = r(String(e)));
                    }),
                    keyFor: e(function (e) {
                      var r;
                      for (r in (t(e), n)) if (n[r] === e) return r;
                    }),
                  });
                }),
                re
              );
            })(),
            u = Object.create,
            c = Object.defineProperties,
            h = Object.defineProperty;
          if ("function" == typeof s)
            try {
              String(s()), (n = !0);
            } catch (e) {}
          else s = null;
          return (
            (t = function (n) {
              if (this instanceof t)
                throw new TypeError("Symbol is not a constructor");
              return e(n);
            }),
            (se = e =
              function e(i) {
                var a;
                if (this instanceof e)
                  throw new TypeError("Symbol is not a constructor");
                return n
                  ? s(i)
                  : ((a = u(t.prototype)),
                    (i = void 0 === i ? "" : String(i)),
                    c(a, { __description__: r("", i), __name__: r("", o(i)) }));
              }),
            a(e),
            l(e),
            c(t.prototype, {
              constructor: r(e),
              toString: r("", function () {
                return this.__name__;
              }),
            }),
            c(e.prototype, {
              toString: r(function () {
                return "Symbol (" + i(this).__description__ + ")";
              }),
              valueOf: r(function () {
                return i(this);
              }),
            }),
            h(
              e.prototype,
              e.toPrimitive,
              r("", function () {
                var e = i(this);
                return "symbol" == typeof e ? e : e.toString();
              })
            ),
            h(e.prototype, e.toStringTag, r("c", "Symbol")),
            h(t.prototype, e.toStringTag, r("c", e.prototype[e.toStringTag])),
            h(t.prototype, e.toPrimitive, r("c", e.prototype[e.toPrimitive])),
            se
          );
        })(),
        configurable: !0,
        enumerable: !1,
        writable: !0,
      }));
  const ye = -2;
  var be = {
      AdLoaded: "AdLoaded",
      AdStarted: "AdStarted",
      AdStopped: "AdStopped",
      AdSkipped: "AdSkipped",
      AdSkippableStateChange: "AdSkippableStateChange",
      AdSizeChange: "AdSizeChange",
      AdLinearChange: "AdLinearChange",
      AdDurationChange: "AdDurationChange",
      AdExpandedChange: "AdExpandedChange",
      AdRemainingTimeChange: "AdRemainingTimeChange",
      AdVolumeChange: "AdVolumeChange",
      AdImpression: "AdImpression",
      AdVideoStart: "AdVideoStart",
      AdVideoFirstQuartile: "AdVideoFirstQuartile",
      AdVideoMidpoint: "AdVideoMidpoint",
      AdVideoThirdQuartile: "AdVideoThirdQuartile",
      AdVideoComplete: "AdVideoComplete",
      AdClickThru: "AdClickThru",
      AdInteraction: "AdInteraction",
      AdUserAcceptInvitation: "AdUserAcceptInvitation",
      AdUserMinimize: "AdUserMinimize",
      AdUserClose: "AdUserClose",
      AdPaused: "AdPaused",
      AdPlaying: "AdPlaying",
      AdLog: "AdLog",
      AdError: "AdError",
      AdMutedUnmutedPlayback: "AdMutedUnmutedPlayback",
    },
    _e = [
      be.AdLoaded,
      be.AdStarted,
      be.AdStopped,
      be.AdSkipped,
      be.AdImpression,
      be.AdVideoStart,
      be.AdVideoFirstQuartile,
      be.AdVideoMidpoint,
      be.AdVideoThirdQuartile,
      be.AdVideoComplete,
      be.AdError,
    ],
    we = {
      initAd: "initAd",
      resizeAd: "resizeAd",
      startAd: "startAd",
      stopAd: "stopAd",
      pauseAd: "pauseAd",
      resumeAd: "resumeAd",
      expandAd: "expandAd",
      collapseAd: "collapseAd",
      skipAd: "skipAd",
    },
    Ae = [we.initAd, we.startAd, we.stopAd, we.skipAd],
    ke = {
      adLinear: { defaultValue: !0 },
      adWidth: { defaultValue: ye },
      adHeight: { defaultValue: ye },
      adExpanded: { defaultValue: !1 },
      adSkippableState: { defaultValue: !1 },
      adRemainingTime: { defaultValue: ye },
      adDuration: { defaultValue: ye },
      adVolume: { writable: !0, defaultValue: ye },
      adCompanions: { defaultValue: "" },
      adIcons: { defaultValue: !1 },
    },
    Se = [
      be.AdVideoStart,
      be.AdVideoFirstQuartile,
      be.AdVideoMidpoint,
      be.AdVideoThirdQuartile,
      be.AdVideoComplete,
    ],
    Pe = [be.AdStopped, be.AdError],
    Ee = (e) => null != e && "function" == typeof e.then;
  Object.keys(be).map((e) => be[e]);
  var Ce,
    xe,
    Te,
    Oe,
    Ie = { exports: {} },
    Me =
      (Ce ||
        ((Ce = 1),
        (Te = Ie.exports),
        (Oe = function () {
          var e = !0;
          function t(t) {
            function n(e) {
              var n = t.match(e);
              return (n && n.length > 1 && n[1]) || "";
            }
            function r(e) {
              var n = t.match(e);
              return (n && n.length > 1 && n[2]) || "";
            }
            var i,
              o = n(/(ipod|iphone|ipad)/i).toLowerCase(),
              a = !/like android/i.test(t) && /android/i.test(t),
              l = /nexus\s*[0-6]\s*/i.test(t),
              u = !l && /nexus\s*[0-9]+/i.test(t),
              c = /CrOS/.test(t),
              d = /silk/i.test(t),
              h = /sailfish/i.test(t),
              p = /tizen/i.test(t),
              f = /(web|hpw)(o|0)s/i.test(t),
              m = /windows phone/i.test(t),
              g = !m && /windows/i.test(t),
              v = !o && !d && /macintosh/i.test(t),
              y = !a && !h && !p && !f && /linux/i.test(t),
              b = r(/edg([ea]|ios)\/(\d+(\.\d+)?)/i),
              _ = n(/version\/(\d+(\.\d+)?)/i),
              w = /tablet/i.test(t) && !/tablet pc/i.test(t),
              A = !w && /[^-]mobi/i.test(t),
              k = /xbox/i.test(t);
            /opera/i.test(t)
              ? (i = {
                  name: "Opera",
                  opera: e,
                  version: _ || n(/(?:opera|opr|opios)[\s\/](\d+(\.\d+)?)/i),
                })
              : /opr\/|opios/i.test(t)
              ? (i = {
                  name: "Opera",
                  opera: e,
                  version: n(/(?:opr|opios)[\s\/](\d+(\.\d+)?)/i) || _,
                })
              : /SamsungBrowser/i.test(t)
              ? (i = {
                  name: "Samsung Internet for Android",
                  samsungBrowser: e,
                  version: _ || n(/(?:SamsungBrowser)[\s\/](\d+(\.\d+)?)/i),
                })
              : /Whale/i.test(t)
              ? (i = {
                  name: "NAVER Whale browser",
                  whale: e,
                  version: n(/(?:whale)[\s\/](\d+(?:\.\d+)+)/i),
                })
              : /MZBrowser/i.test(t)
              ? (i = {
                  name: "MZ Browser",
                  mzbrowser: e,
                  version: n(/(?:MZBrowser)[\s\/](\d+(?:\.\d+)+)/i),
                })
              : /coast/i.test(t)
              ? (i = {
                  name: "Opera Coast",
                  coast: e,
                  version: _ || n(/(?:coast)[\s\/](\d+(\.\d+)?)/i),
                })
              : /focus/i.test(t)
              ? (i = {
                  name: "Focus",
                  focus: e,
                  version: n(/(?:focus)[\s\/](\d+(?:\.\d+)+)/i),
                })
              : /yabrowser/i.test(t)
              ? (i = {
                  name: "Yandex Browser",
                  yandexbrowser: e,
                  version: _ || n(/(?:yabrowser)[\s\/](\d+(\.\d+)?)/i),
                })
              : /ucbrowser/i.test(t)
              ? (i = {
                  name: "UC Browser",
                  ucbrowser: e,
                  version: n(/(?:ucbrowser)[\s\/](\d+(?:\.\d+)+)/i),
                })
              : /mxios/i.test(t)
              ? (i = {
                  name: "Maxthon",
                  maxthon: e,
                  version: n(/(?:mxios)[\s\/](\d+(?:\.\d+)+)/i),
                })
              : /epiphany/i.test(t)
              ? (i = {
                  name: "Epiphany",
                  epiphany: e,
                  version: n(/(?:epiphany)[\s\/](\d+(?:\.\d+)+)/i),
                })
              : /puffin/i.test(t)
              ? (i = {
                  name: "Puffin",
                  puffin: e,
                  version: n(/(?:puffin)[\s\/](\d+(?:\.\d+)?)/i),
                })
              : /sleipnir/i.test(t)
              ? (i = {
                  name: "Sleipnir",
                  sleipnir: e,
                  version: n(/(?:sleipnir)[\s\/](\d+(?:\.\d+)+)/i),
                })
              : /k-meleon/i.test(t)
              ? (i = {
                  name: "K-Meleon",
                  kMeleon: e,
                  version: n(/(?:k-meleon)[\s\/](\d+(?:\.\d+)+)/i),
                })
              : m
              ? ((i = {
                  name: "Windows Phone",
                  osname: "Windows Phone",
                  windowsphone: e,
                }),
                b
                  ? ((i.msedge = e), (i.version = b))
                  : ((i.msie = e), (i.version = n(/iemobile\/(\d+(\.\d+)?)/i))))
              : /msie|trident/i.test(t)
              ? (i = {
                  name: "Internet Explorer",
                  msie: e,
                  version: n(/(?:msie |rv:)(\d+(\.\d+)?)/i),
                })
              : c
              ? (i = {
                  name: "Chrome",
                  osname: "Chrome OS",
                  chromeos: e,
                  chromeBook: e,
                  chrome: e,
                  version: n(/(?:chrome|crios|crmo)\/(\d+(\.\d+)?)/i),
                })
              : /edg([ea]|ios)/i.test(t)
              ? (i = { name: "Microsoft Edge", msedge: e, version: b })
              : /vivaldi/i.test(t)
              ? (i = {
                  name: "Vivaldi",
                  vivaldi: e,
                  version: n(/vivaldi\/(\d+(\.\d+)?)/i) || _,
                })
              : h
              ? (i = {
                  name: "Sailfish",
                  osname: "Sailfish OS",
                  sailfish: e,
                  version: n(/sailfish\s?browser\/(\d+(\.\d+)?)/i),
                })
              : /seamonkey\//i.test(t)
              ? (i = {
                  name: "SeaMonkey",
                  seamonkey: e,
                  version: n(/seamonkey\/(\d+(\.\d+)?)/i),
                })
              : /firefox|iceweasel|fxios/i.test(t)
              ? ((i = {
                  name: "Firefox",
                  firefox: e,
                  version: n(/(?:firefox|iceweasel|fxios)[ \/](\d+(\.\d+)?)/i),
                }),
                /\((mobile|tablet);[^\)]*rv:[\d\.]+\)/i.test(t) &&
                  ((i.firefoxos = e), (i.osname = "Firefox OS")))
              : d
              ? (i = {
                  name: "Amazon Silk",
                  silk: e,
                  version: n(/silk\/(\d+(\.\d+)?)/i),
                })
              : /phantom/i.test(t)
              ? (i = {
                  name: "PhantomJS",
                  phantom: e,
                  version: n(/phantomjs\/(\d+(\.\d+)?)/i),
                })
              : /slimerjs/i.test(t)
              ? (i = {
                  name: "SlimerJS",
                  slimer: e,
                  version: n(/slimerjs\/(\d+(\.\d+)?)/i),
                })
              : /blackberry|\bbb\d+/i.test(t) || /rim\stablet/i.test(t)
              ? (i = {
                  name: "BlackBerry",
                  osname: "BlackBerry OS",
                  blackberry: e,
                  version: _ || n(/blackberry[\d]+\/(\d+(\.\d+)?)/i),
                })
              : f
              ? ((i = {
                  name: "WebOS",
                  osname: "WebOS",
                  webos: e,
                  version: _ || n(/w(?:eb)?osbrowser\/(\d+(\.\d+)?)/i),
                }),
                /touchpad\//i.test(t) && (i.touchpad = e))
              : /bada/i.test(t)
              ? (i = {
                  name: "Bada",
                  osname: "Bada",
                  bada: e,
                  version: n(/dolfin\/(\d+(\.\d+)?)/i),
                })
              : p
              ? (i = {
                  name: "Tizen",
                  osname: "Tizen",
                  tizen: e,
                  version: n(/(?:tizen\s?)?browser\/(\d+(\.\d+)?)/i) || _,
                })
              : /qupzilla/i.test(t)
              ? (i = {
                  name: "QupZilla",
                  qupzilla: e,
                  version: n(/(?:qupzilla)[\s\/](\d+(?:\.\d+)+)/i) || _,
                })
              : /chromium/i.test(t)
              ? (i = {
                  name: "Chromium",
                  chromium: e,
                  version: n(/(?:chromium)[\s\/](\d+(?:\.\d+)?)/i) || _,
                })
              : /chrome|crios|crmo/i.test(t)
              ? (i = {
                  name: "Chrome",
                  chrome: e,
                  version: n(/(?:chrome|crios|crmo)\/(\d+(\.\d+)?)/i),
                })
              : a
              ? (i = { name: "Android", version: _ })
              : /safari|applewebkit/i.test(t)
              ? ((i = { name: "Safari", safari: e }), _ && (i.version = _))
              : o
              ? ((i = {
                  name:
                    "iphone" == o ? "iPhone" : "ipad" == o ? "iPad" : "iPod",
                }),
                _ && (i.version = _))
              : (i = /googlebot/i.test(t)
                  ? {
                      name: "Googlebot",
                      googlebot: e,
                      version: n(/googlebot\/(\d+(\.\d+))/i) || _,
                    }
                  : { name: n(/^(.*)\/(.*) /), version: r(/^(.*)\/(.*) /) }),
              !i.msedge && /(apple)?webkit/i.test(t)
                ? (/(apple)?webkit\/537\.36/i.test(t)
                    ? ((i.name = i.name || "Blink"), (i.blink = e))
                    : ((i.name = i.name || "Webkit"), (i.webkit = e)),
                  !i.version && _ && (i.version = _))
                : !i.opera &&
                  /gecko\//i.test(t) &&
                  ((i.name = i.name || "Gecko"),
                  (i.gecko = e),
                  (i.version = i.version || n(/gecko\/(\d+(\.\d+)?)/i))),
              i.windowsphone || (!a && !i.silk)
                ? !i.windowsphone && o
                  ? ((i[o] = e), (i.ios = e), (i.osname = "iOS"))
                  : v
                  ? ((i.mac = e), (i.osname = "macOS"))
                  : k
                  ? ((i.xbox = e), (i.osname = "Xbox"))
                  : g
                  ? ((i.windows = e), (i.osname = "Windows"))
                  : y && ((i.linux = e), (i.osname = "Linux"))
                : ((i.android = e), (i.osname = "Android"));
            var S = "";
            i.windows
              ? (S = (function (e) {
                  switch (e) {
                    case "NT":
                      return "NT";
                    case "XP":
                    case "NT 5.1":
                      return "XP";
                    case "NT 5.0":
                      return "2000";
                    case "NT 5.2":
                      return "2003";
                    case "NT 6.0":
                      return "Vista";
                    case "NT 6.1":
                      return "7";
                    case "NT 6.2":
                      return "8";
                    case "NT 6.3":
                      return "8.1";
                    case "NT 10.0":
                      return "10";
                    default:
                      return;
                  }
                })(n(/Windows ((NT|XP)( \d\d?.\d)?)/i)))
              : i.windowsphone
              ? (S = n(/windows phone (?:os)?\s?(\d+(\.\d+)*)/i))
              : i.mac
              ? (S = (S = n(/Mac OS X (\d+([_\.\s]\d+)*)/i)).replace(
                  /[_\s]/g,
                  "."
                ))
              : o
              ? (S = (S = n(/os (\d+([_\s]\d+)*) like mac os x/i)).replace(
                  /[_\s]/g,
                  "."
                ))
              : a
              ? (S = n(/android[ \/-](\d+(\.\d+)*)/i))
              : i.webos
              ? (S = n(/(?:web|hpw)os\/(\d+(\.\d+)*)/i))
              : i.blackberry
              ? (S = n(/rim\stablet\sos\s(\d+(\.\d+)*)/i))
              : i.bada
              ? (S = n(/bada\/(\d+(\.\d+)*)/i))
              : i.tizen && (S = n(/tizen[\/\s](\d+(\.\d+)*)/i)),
              S && (i.osversion = S);
            var P = !i.windows && S.split(".")[0];
            return (
              w ||
              u ||
              "ipad" == o ||
              (a && (3 == P || (P >= 4 && !A))) ||
              i.silk
                ? (i.tablet = e)
                : (A ||
                    "iphone" == o ||
                    "ipod" == o ||
                    a ||
                    l ||
                    i.blackberry ||
                    i.webos ||
                    i.bada) &&
                  (i.mobile = e),
              i.msedge ||
              (i.msie && i.version >= 10) ||
              (i.yandexbrowser && i.version >= 15) ||
              (i.vivaldi && i.version >= 1) ||
              (i.chrome && i.version >= 20) ||
              (i.samsungBrowser && i.version >= 4) ||
              (i.whale && 1 === s([i.version, "1.0"])) ||
              (i.mzbrowser && 1 === s([i.version, "6.0"])) ||
              (i.focus && 1 === s([i.version, "1.0"])) ||
              (i.firefox && i.version >= 20) ||
              (i.safari && i.version >= 6) ||
              (i.opera && i.version >= 10) ||
              (i.ios && i.osversion && i.osversion.split(".")[0] >= 6) ||
              (i.blackberry && i.version >= 10.1) ||
              (i.chromium && i.version >= 20)
                ? (i.a = e)
                : (i.msie && i.version < 10) ||
                  (i.chrome && i.version < 20) ||
                  (i.firefox && i.version < 20) ||
                  (i.safari && i.version < 6) ||
                  (i.opera && i.version < 10) ||
                  (i.ios && i.osversion && i.osversion.split(".")[0] < 6) ||
                  (i.chromium && i.version < 20)
                ? (i.c = e)
                : (i.x = e),
              i
            );
          }
          var n = t(
            ("undefined" != typeof navigator && navigator.userAgent) || ""
          );
          function r(e) {
            return e.split(".").length;
          }
          function i(e, t) {
            var n,
              r = [];
            if (Array.prototype.map) return Array.prototype.map.call(e, t);
            for (n = 0; n < e.length; n++) r.push(t(e[n]));
            return r;
          }
          function s(e) {
            for (
              var t = Math.max(r(e[0]), r(e[1])),
                n = i(e, function (e) {
                  var n = t - r(e);
                  return i(
                    (e += new Array(n + 1).join(".0")).split("."),
                    function (e) {
                      return new Array(20 - e.length).join("0") + e;
                    }
                  ).reverse();
                });
              --t >= 0;

            ) {
              if (n[0][t] > n[1][t]) return 1;
              if (n[0][t] !== n[1][t]) return -1;
              if (0 === t) return 0;
            }
          }
          function o(e, r, i) {
            var o = n;
            "string" == typeof r && ((i = r), (r = void 0)),
              void 0 === r && (r = !1),
              i && (o = t(i));
            var a = "" + o.version;
            for (var l in e)
              if (e.hasOwnProperty(l) && o[l]) {
                if ("string" != typeof e[l])
                  throw new Error(
                    "Browser version in the minVersion map should be a string: " +
                      l +
                      ": " +
                      String(e)
                  );
                return s([a, e[l]]) < 0;
              }
            return r;
          }
          return (
            (n.test = function (e) {
              for (var t = 0; t < e.length; ++t) {
                var r = e[t];
                if ("string" == typeof r && r in n) return !0;
              }
              return !1;
            }),
            (n.isUnsupportedBrowser = o),
            (n.compareVersions = s),
            (n.check = function (e, t, n) {
              return !o(e, t, n);
            }),
            (n._detect = t),
            (n.detect = t),
            n
          );
        }),
        (xe = Ie).exports ? (xe.exports = Oe()) : (Te.bowser = Oe())),
      Ie.exports),
    Ve = c(Me);
  const je = ["dns-prefetch", "preconnect", "prefetch", "preload"],
    Fe = {},
    Le = je.reverse();
  "undefined" != typeof document &&
    (() => {
      const e = document.createElement("link");
      e.relList && e.relList.supports
        ? je.forEach((t) => {
            Fe[t] = e.relList.supports(t);
          })
        : Object.assign(Fe, {
            "dns-prefetch": Ve.check({ msie: "10", msedge: "12" }, !0),
            prefetch: Ve.check({ msie: "11", msedge: "12" }, !0),
            preload: Ve.check({ msedge: "17" }, !0),
          });
    })();
  const Re = (e) => !!Fe[e];
  var De = function (e, t, n) {
      if (
        (void 0 === t && (t = document),
        void 0 === n && (n = null),
        null == e || null == e.href || null == e.rel)
      )
        return;
      if (
        ((e.rel = (function (e, t) {
          if ((void 0 === t && (t = null), null == t)) {
            const n = Le.indexOf(e);
            n >= 0 && (t = Le.slice(n + 1));
          }
          if (null != t) {
            let n = 0;
            for (; n < t.length && !Re(e); ) e = t[n++];
          }
          return Re(e) ? e : null;
        })(e.rel, n)),
        null == e.rel)
      )
        return;
      "dns-prefetch" === e.rel || "preconnect" === e.rel
        ? ((e.href = ((e) => {
            const t = e.indexOf("//");
            if (t < 0) return null;
            const n = e.indexOf("/", t + 2);
            return n < 0 ? e : e.substr(0, n);
          })(e.href)),
          delete e.as,
          delete e.type)
        : ("prefetch" !== e.rel && "preload" !== e.rel) ||
          (e.href = ((e) => {
            const t = e.indexOf("#");
            return t < 0 ? e : e.substr(0, t);
          })(e.href));
      const r = t.createElement("link");
      Object.assign(r, e), t.head.appendChild(r);
    },
    $e = () => "" + (1e9 + Math.floor(9e9 * Math.random()));
  const Ne = Symbol("name"),
    Ue = Symbol("view");
  class Be {
    constructor(e, t) {
      let n, r;
      switch ((void 0 === t && (t = null), typeof e)) {
        case "object":
          (n = e.name), (r = e.callback);
          break;
        case "string":
          n = e;
          break;
        case "function":
          r = e;
      }
      null == n &&
        (n = `cb_${new Date().getTime().toString(36)}${parseInt($e())
          .toString(16)
          .substring(1)}`),
        (this[Ne] = n),
        null != t && null != t.defaultView && (t = t.defaultView),
        (this[Ue] = null != t ? t : window),
        null != r && (this.callback = r);
    }
    get name() {
      return this[Ne];
    }
    get exists() {
      return null != this.callback;
    }
    get callback() {
      return null != this[Ue] && "function" == typeof this[Ue][this.name]
        ? this[Ue][this.name]
        : null;
    }
    set callback(e) {
      null != this[Ue] && (this[Ue][this.name] = e);
    }
    remove() {
      this.exists && delete this[Ue][this.name];
    }
    invoke() {
      this.exists && this.callback(...arguments);
    }
  }
  const ze = (e) =>
      null == e ||
      "" === ("" + e).trim() ||
      (Array.isArray(e) && null == e.length),
    We = { vast: "vast", video: "video", vpaid: "vpaid", unknown: null },
    qe = /^(?:application|text)\/xml\+vast$/i,
    He = /^(?:application|text)\/(?:x-)?javascript$/i,
    Ge = /^video\//i,
    Qe = (e) => {
      let { type: t, apiFramework: n } = e;
      return ze(n) && qe.test(t);
    },
    Ye = (e) => {
      let { type: t, apiFramework: n } = e;
      return "VPAID" === n && He.test(t);
    },
    Xe = [
      { eval: Qe, result: We.vast },
      { eval: Ye, result: We.vpaid },
      {
        eval: (e) => {
          let { type: t, apiFramework: n } = e;
          return ze(n) && Ge.test(t);
        },
        result: We.video,
      },
    ],
    Ke = (e) => Xe.reduce((t, n) => (n.eval(e) ? n.result : t), We.unknown);
  var Ze,
    Je = {},
    et = { exports: {} },
    tt = { exports: {} },
    nt = { exports: {} };
  function rt() {
    if (Ze) return nt.exports;
    Ze = 1;
    var e = (nt.exports = { version: "2.6.12" });
    return "number" == typeof __e && (__e = e), nt.exports;
  }
  var it,
    st,
    ot,
    at,
    lt,
    ut,
    ct,
    dt = { exports: {} };
  function ht() {
    if (it) return dt.exports;
    it = 1;
    var e = (dt.exports =
      "undefined" != typeof window && window.Math == Math
        ? window
        : "undefined" != typeof self && self.Math == Math
        ? self
        : Function("return this")());
    return "number" == typeof __g && (__g = e), dt.exports;
  }
  function pt() {
    return ot ? st : ((ot = 1), (st = !1));
  }
  function ft() {
    if (at) return tt.exports;
    at = 1;
    var e = rt(),
      t = ht(),
      n = "__core-js_shared__",
      r = t[n] || (t[n] = {});
    return (
      (tt.exports = function (e, t) {
        return r[e] || (r[e] = void 0 !== t ? t : {});
      })("versions", []).push({
        version: e.version,
        mode: pt() ? "pure" : "global",
        copyright: "© 2020 Denis Pushkarev (zloirock.ru)",
      }),
      tt.exports
    );
  }
  function mt() {
    if (ut) return lt;
    ut = 1;
    var e = 0,
      t = Math.random();
    return (
      (lt = function (n) {
        return "Symbol(".concat(
          void 0 === n ? "" : n,
          ")_",
          (++e + t).toString(36)
        );
      }),
      lt
    );
  }
  function gt() {
    if (ct) return et.exports;
    ct = 1;
    var e = ft()("wks"),
      t = mt(),
      n = ht().Symbol,
      r = "function" == typeof n;
    return (
      ((et.exports = function (i) {
        return e[i] || (e[i] = (r && n[i]) || (r ? n : t)("Symbol." + i));
      }).store = e),
      et.exports
    );
  }
  var vt,
    yt,
    bt,
    _t,
    wt,
    At,
    kt,
    St,
    Pt,
    Et,
    Ct,
    xt,
    Tt,
    Ot,
    It,
    Mt,
    Vt,
    jt,
    Ft,
    Lt,
    Rt,
    Dt,
    $t,
    Nt,
    Ut,
    Bt,
    zt,
    Wt,
    qt,
    Ht,
    Gt,
    Qt,
    Yt,
    Xt = {};
  function Kt() {
    return yt
      ? vt
      : ((yt = 1),
        (vt = function (e) {
          return "object" == typeof e ? null !== e : "function" == typeof e;
        }));
  }
  function Zt() {
    if (_t) return bt;
    _t = 1;
    var e = Kt();
    return (bt = function (t) {
      if (!e(t)) throw TypeError(t + " is not an object!");
      return t;
    });
  }
  function Jt() {
    return At
      ? wt
      : ((At = 1),
        (wt = function (e) {
          try {
            return !!e();
          } catch (e) {
            return !0;
          }
        }));
  }
  function en() {
    return St
      ? kt
      : ((St = 1),
        (kt = !Jt()(function () {
          return (
            7 !=
            Object.defineProperty({}, "a", {
              get: function () {
                return 7;
              },
            }).a
          );
        })));
  }
  function tn() {
    if (Et) return Pt;
    Et = 1;
    var e = Kt(),
      t = ht().document,
      n = e(t) && e(t.createElement);
    return (Pt = function (e) {
      return n ? t.createElement(e) : {};
    });
  }
  function nn() {
    if (It) return Xt;
    It = 1;
    var e = Zt(),
      t = xt
        ? Ct
        : ((xt = 1),
          (Ct =
            !en() &&
            !Jt()(function () {
              return (
                7 !=
                Object.defineProperty(tn()("div"), "a", {
                  get: function () {
                    return 7;
                  },
                }).a
              );
            }))),
      n = (function () {
        if (Ot) return Tt;
        Ot = 1;
        var e = Kt();
        return (Tt = function (t, n) {
          if (!e(t)) return t;
          var r, i;
          if (n && "function" == typeof (r = t.toString) && !e((i = r.call(t))))
            return i;
          if ("function" == typeof (r = t.valueOf) && !e((i = r.call(t))))
            return i;
          if (
            !n &&
            "function" == typeof (r = t.toString) &&
            !e((i = r.call(t)))
          )
            return i;
          throw TypeError("Can't convert object to primitive value");
        });
      })(),
      r = Object.defineProperty;
    return (
      (Xt.f = en()
        ? Object.defineProperty
        : function (i, s, o) {
            if ((e(i), (s = n(s, !0)), e(o), t))
              try {
                return r(i, s, o);
              } catch (e) {}
            if ("get" in o || "set" in o)
              throw TypeError("Accessors not supported!");
            return "value" in o && (i[s] = o.value), i;
          }),
      Xt
    );
  }
  function rn() {
    return Vt
      ? Mt
      : ((Vt = 1),
        (Mt = function (e, t) {
          return {
            enumerable: !(1 & e),
            configurable: !(2 & e),
            writable: !(4 & e),
            value: t,
          };
        }));
  }
  function sn() {
    if (Ft) return jt;
    Ft = 1;
    var e = nn(),
      t = rn();
    return (
      (jt = en()
        ? function (n, r, i) {
            return e.f(n, r, t(1, i));
          }
        : function (e, t, n) {
            return (e[t] = n), e;
          }),
      jt
    );
  }
  function on() {
    return Ut ? Nt : ((Ut = 1), (Nt = {}));
  }
  function an() {
    return Gt
      ? Ht
      : ((Gt = 1),
        (Ht = function (e) {
          if (null == e) throw TypeError("Can't call method on  " + e);
          return e;
        }));
  }
  function ln() {
    if (Yt) return Qt;
    Yt = 1;
    var e = (function () {
        if (qt) return Wt;
        qt = 1;
        var e = (function () {
          if (zt) return Bt;
          zt = 1;
          var e = {}.toString;
          return (Bt = function (t) {
            return e.call(t).slice(8, -1);
          });
        })();
        return (Wt = Object("z").propertyIsEnumerable(0)
          ? Object
          : function (t) {
              return "String" == e(t) ? t.split("") : Object(t);
            });
      })(),
      t = an();
    return (Qt = function (n) {
      return e(t(n));
    });
  }
  var un,
    cn,
    dn,
    hn,
    pn,
    fn,
    mn,
    gn,
    vn,
    yn,
    bn,
    _n,
    wn,
    An,
    kn,
    Sn,
    Pn,
    En,
    Cn,
    xn,
    Tn,
    On,
    In,
    Mn,
    Vn,
    jn,
    Fn,
    Ln,
    Rn,
    Dn,
    $n,
    Nn,
    Un,
    Bn,
    zn,
    Wn,
    qn,
    Hn,
    Gn,
    Qn,
    Yn,
    Xn,
    Kn,
    Zn,
    Jn,
    er,
    tr = { exports: {} };
  function nr() {
    if (cn) return un;
    cn = 1;
    var e = {}.hasOwnProperty;
    return (
      (un = function (t, n) {
        return e.call(t, n);
      }),
      un
    );
  }
  function rr() {
    if (pn) return tr.exports;
    pn = 1;
    var e = ht(),
      t = sn(),
      n = nr(),
      r = mt()("src"),
      i = hn
        ? dn
        : ((hn = 1),
          (dn = ft()("native-function-to-string", Function.toString))),
      s = "toString",
      o = ("" + i).split(s);
    return (
      (rt().inspectSource = function (e) {
        return i.call(e);
      }),
      (tr.exports = function (i, s, a, l) {
        var u = "function" == typeof a;
        u && (n(a, "name") || t(a, "name", s)),
          i[s] !== a &&
            (u && (n(a, r) || t(a, r, i[s] ? "" + i[s] : o.join(String(s)))),
            i === e
              ? (i[s] = a)
              : l
              ? i[s]
                ? (i[s] = a)
                : t(i, s, a)
              : (delete i[s], t(i, s, a)));
      })(Function.prototype, s, function () {
        return ("function" == typeof this && this[r]) || i.call(this);
      }),
      tr.exports
    );
  }
  function ir() {
    if (wn) return _n;
    wn = 1;
    var e = Math.ceil,
      t = Math.floor;
    return (_n = function (n) {
      return isNaN((n = +n)) ? 0 : (n > 0 ? t : e)(n);
    });
  }
  function sr() {
    if (Tn) return xn;
    Tn = 1;
    var e = ft()("keys"),
      t = mt();
    return (
      (xn = function (n) {
        return e[n] || (e[n] = t(n));
      }),
      xn
    );
  }
  function or() {
    return Vn
      ? Mn
      : ((Vn = 1),
        (Mn =
          "constructor,hasOwnProperty,isPrototypeOf,propertyIsEnumerable,toLocaleString,toString,valueOf".split(
            ","
          )));
  }
  function ar() {
    if (Fn) return jn;
    Fn = 1;
    var e = (function () {
        if (In) return On;
        In = 1;
        var e = nr(),
          t = ln(),
          n = (function () {
            if (Cn) return En;
            Cn = 1;
            var e = ln(),
              t = (function () {
                if (kn) return An;
                kn = 1;
                var e = ir(),
                  t = Math.min;
                return (An = function (n) {
                  return n > 0 ? t(e(n), 9007199254740991) : 0;
                });
              })(),
              n = (function () {
                if (Pn) return Sn;
                Pn = 1;
                var e = ir(),
                  t = Math.max,
                  n = Math.min;
                return (Sn = function (r, i) {
                  return (r = e(r)) < 0 ? t(r + i, 0) : n(r, i);
                });
              })();
            return (En = function (r) {
              return function (i, s, o) {
                var a,
                  l = e(i),
                  u = t(l.length),
                  c = n(o, u);
                if (r && s != s) {
                  for (; u > c; ) if ((a = l[c++]) != a) return !0;
                } else
                  for (; u > c; c++)
                    if ((r || c in l) && l[c] === s) return r || c || 0;
                return !r && -1;
              };
            });
          })()(!1),
          r = sr()("IE_PROTO");
        return (
          (On = function (i, s) {
            var o,
              a = t(i),
              l = 0,
              u = [];
            for (o in a) o != r && e(a, o) && u.push(o);
            for (; s.length > l; )
              e(a, (o = s[l++])) && (~n(u, o) || u.push(o));
            return u;
          }),
          On
        );
      })(),
      t = or();
    return (jn =
      Object.keys ||
      function (n) {
        return e(n, t);
      });
  }
  function lr() {
    if (zn) return Bn;
    zn = 1;
    var e = nn().f,
      t = nr(),
      n = gt()("toStringTag");
    return (Bn = function (r, i, s) {
      r &&
        !t((r = s ? r : r.prototype), n) &&
        e(r, n, { configurable: !0, value: i });
    });
  }
  !(function () {
    if (er) return Je;
    er = 1;
    for (
      var e = (function () {
          if (Jn) return Zn;
          Jn = 1;
          var e = (function () {
              if (Rt) return Lt;
              Rt = 1;
              var e = gt()("unscopables"),
                t = Array.prototype;
              return (
                null == t[e] && sn()(t, e, {}),
                (Lt = function (n) {
                  t[e][n] = !0;
                }),
                Lt
              );
            })(),
            t = $t
              ? Dt
              : (($t = 1),
                (Dt = function (e, t) {
                  return { value: t, done: !!e };
                })),
            n = on(),
            r = ln();
          return (
            (Zn = (function () {
              if (Kn) return Xn;
              Kn = 1;
              var e = pt(),
                t = (function () {
                  if (bn) return yn;
                  bn = 1;
                  var e = ht(),
                    t = rt(),
                    n = sn(),
                    r = rr(),
                    i = (function () {
                      if (vn) return gn;
                      vn = 1;
                      var e = mn
                        ? fn
                        : ((mn = 1),
                          (fn = function (e) {
                            if ("function" != typeof e)
                              throw TypeError(e + " is not a function!");
                            return e;
                          }));
                      return (
                        (gn = function (t, n, r) {
                          if ((e(t), void 0 === n)) return t;
                          switch (r) {
                            case 1:
                              return function (e) {
                                return t.call(n, e);
                              };
                            case 2:
                              return function (e, r) {
                                return t.call(n, e, r);
                              };
                            case 3:
                              return function (e, r, i) {
                                return t.call(n, e, r, i);
                              };
                          }
                          return function () {
                            return t.apply(n, arguments);
                          };
                        }),
                        gn
                      );
                    })(),
                    s = "prototype",
                    o = function (a, l, u) {
                      var c,
                        d,
                        h,
                        p,
                        f = a & o.F,
                        m = a & o.G,
                        g = a & o.S,
                        v = a & o.P,
                        y = a & o.B,
                        b = m ? e : g ? e[l] || (e[l] = {}) : (e[l] || {})[s],
                        _ = m ? t : t[l] || (t[l] = {}),
                        w = _[s] || (_[s] = {});
                      for (c in (m && (u = l), u))
                        (h = ((d = !f && b && void 0 !== b[c]) ? b : u)[c]),
                          (p =
                            y && d
                              ? i(h, e)
                              : v && "function" == typeof h
                              ? i(Function.call, h)
                              : h),
                          b && r(b, c, h, a & o.U),
                          _[c] != h && n(_, c, p),
                          v && w[c] != h && (w[c] = h);
                    };
                  return (
                    (e.core = t),
                    (o.F = 1),
                    (o.G = 2),
                    (o.S = 4),
                    (o.P = 8),
                    (o.B = 16),
                    (o.W = 32),
                    (o.U = 64),
                    (o.R = 128),
                    (yn = o)
                  );
                })(),
                n = rr(),
                r = sn(),
                i = on(),
                s = (function () {
                  if (qn) return Wn;
                  qn = 1;
                  var e = (function () {
                      if (Un) return Nn;
                      Un = 1;
                      var e = Zt(),
                        t = (function () {
                          if (Rn) return Ln;
                          Rn = 1;
                          var e = nn(),
                            t = Zt(),
                            n = ar();
                          return (
                            (Ln = en()
                              ? Object.defineProperties
                              : function (r, i) {
                                  t(r);
                                  for (
                                    var s, o = n(i), a = o.length, l = 0;
                                    a > l;

                                  )
                                    e.f(r, (s = o[l++]), i[s]);
                                  return r;
                                }),
                            Ln
                          );
                        })(),
                        n = or(),
                        r = sr()("IE_PROTO"),
                        i = function () {},
                        s = "prototype",
                        o = function () {
                          var e,
                            t = tn()("iframe"),
                            r = n.length;
                          for (
                            t.style.display = "none",
                              (function () {
                                if ($n) return Dn;
                                $n = 1;
                                var e = ht().document;
                                return (Dn = e && e.documentElement);
                              })().appendChild(t),
                              t.src = "javascript:",
                              (e = t.contentWindow.document).open(),
                              e.write("<script>document.F=Object</script>"),
                              e.close(),
                              o = e.F;
                            r--;

                          )
                            delete o[s][n[r]];
                          return o();
                        };
                      return (Nn =
                        Object.create ||
                        function (n, a) {
                          var l;
                          return (
                            null !== n
                              ? ((i[s] = e(n)),
                                (l = new i()),
                                (i[s] = null),
                                (l[r] = n))
                              : (l = o()),
                            void 0 === a ? l : t(l, a)
                          );
                        });
                    })(),
                    t = rn(),
                    n = lr(),
                    r = {};
                  return (
                    sn()(r, gt()("iterator"), function () {
                      return this;
                    }),
                    (Wn = function (i, s, o) {
                      (i.prototype = e(r, { next: t(1, o) })),
                        n(i, s + " Iterator");
                    })
                  );
                })(),
                o = lr(),
                a = (function () {
                  if (Yn) return Qn;
                  Yn = 1;
                  var e = nr(),
                    t = (function () {
                      if (Gn) return Hn;
                      Gn = 1;
                      var e = an();
                      return (Hn = function (t) {
                        return Object(e(t));
                      });
                    })(),
                    n = sr()("IE_PROTO"),
                    r = Object.prototype;
                  return (Qn =
                    Object.getPrototypeOf ||
                    function (i) {
                      return (
                        (i = t(i)),
                        e(i, n)
                          ? i[n]
                          : "function" == typeof i.constructor &&
                            i instanceof i.constructor
                          ? i.constructor.prototype
                          : i instanceof Object
                          ? r
                          : null
                      );
                    });
                })(),
                l = gt()("iterator"),
                u = !([].keys && ("next" in [].keys())),
                c = "keys",
                d = "values",
                h = function () {
                  return this;
                };
              return (
                (Xn = function (p, f, m, g, v, y, b) {
                  s(m, f, g);
                  var _,
                    w,
                    A,
                    k = function (e) {
                      if (!u && (e in C)) return C[e];
                      switch (e) {
                        case c:
                        case d:
                          return function () {
                            return new m(this, e);
                          };
                      }
                      return function () {
                        return new m(this, e);
                      };
                    },
                    S = f + " Iterator",
                    P = v == d,
                    E = !1,
                    C = p.prototype,
                    x = C[l] || C["@@iterator"] || (v && C[v]),
                    T = x || k(v),
                    O = v ? (P ? k("entries") : T) : void 0,
                    I = ("Array" == f && C.entries) || x;
                  if (
                    (I &&
                      (A = a(I.call(new p()))) !== Object.prototype &&
                      A.next &&
                      (o(A, S, !0),
                      e || "function" == typeof A[l] || r(A, l, h)),
                    P &&
                      x &&
                      x.name !== d &&
                      ((E = !0),
                      (T = function () {
                        return x.call(this);
                      })),
                    (e && !b) || (!u && !E && C[l]) || r(C, l, T),
                    (i[f] = T),
                    (i[S] = h),
                    v)
                  )
                    if (
                      ((_ = {
                        values: P ? T : k(d),
                        keys: y ? T : k(c),
                        entries: O,
                      }),
                      b)
                    )
                      for (w in _) (w in C) || n(C, w, _[w]);
                    else t(t.P + t.F * (u || E), f, _);
                  return _;
                }),
                Xn
              );
            })()(
              Array,
              "Array",
              function (e, t) {
                (this._t = r(e)), (this._i = 0), (this._k = t);
              },
              function () {
                var e = this._t,
                  n = this._k,
                  r = this._i++;
                return !e || r >= e.length
                  ? ((this._t = void 0), t(1))
                  : t(0, "keys" == n ? r : "values" == n ? e[r] : [r, e[r]]);
              },
              "values"
            )),
            (n.Arguments = n.Array),
            e("keys"),
            e("values"),
            e("entries"),
            Zn
          );
        })(),
        t = ar(),
        n = rr(),
        r = ht(),
        i = sn(),
        s = on(),
        o = gt(),
        a = o("iterator"),
        l = o("toStringTag"),
        u = s.Array,
        c = {
          CSSRuleList: !0,
          CSSStyleDeclaration: !1,
          CSSValueList: !1,
          ClientRectList: !1,
          DOMRectList: !1,
          DOMStringList: !1,
          DOMTokenList: !0,
          DataTransferItemList: !1,
          FileList: !1,
          HTMLAllCollection: !1,
          HTMLCollection: !1,
          HTMLFormElement: !1,
          HTMLSelectElement: !1,
          MediaList: !0,
          MimeTypeArray: !1,
          NamedNodeMap: !1,
          NodeList: !0,
          PaintRequestList: !1,
          Plugin: !1,
          PluginArray: !1,
          SVGLengthList: !1,
          SVGNumberList: !1,
          SVGPathSegList: !1,
          SVGPointList: !1,
          SVGStringList: !1,
          SVGTransformList: !1,
          SourceBufferList: !1,
          StyleSheetList: !0,
          TextTrackCueList: !1,
          TextTrackList: !1,
          TouchList: !1,
        },
        d = t(c),
        h = 0;
      h < d.length;
      h++
    ) {
      var p,
        f = d[h],
        m = c[f],
        g = r[f],
        v = g && g.prototype;
      if (v && (v[a] || i(v, a, u), v[l] || i(v, l, f), (s[f] = u), m))
        for (p in e) v[p] || n(v, p, e[p], !0);
    }
  })();
  const ur = (e, t, n) => {
      e.setAttribute(t, n);
    },
    cr = (e, t, n) => {
      var r;
      e[t] =
        0 === (r = (r = n).trim()).length
          ? r
          : 1 === r.length
          ? r.toLowerCase()
          : r
              .replace(/(^[-_.]+)|([-_.]+$)/g, "")
              .replace(/[-_.\s]+(\w)/g, (e, t) => t.toUpperCase())
              .replace(/(\d+)(\w)/g, (e, t, n) => t + n.toUpperCase());
    },
    dr = function (e, t, n) {
      if ((void 0 === n && (n = !1), null == e || null == e.style)) return;
      const r = "function" == typeof e.style.setProperty,
        i = n ? "important" : "";
      Object.keys(t).forEach((n) => {
        const s = t[n];
        r ? e.style.setProperty(n, s, i) : (e.style[n] = s);
      });
    },
    hr = function (e, t, n, r, i) {
      return (
        void 0 === i && (i = !1),
        (function (e, t, n, r, i, s) {
          void 0 === s && (s = !1);
          const o = e.createElementNS("http://www.w3.org/2000/svg", n);
          return (
            null != r &&
              ((e, t) => {
                const n = "function" == typeof e.setAttribute ? ur : cr;
                Object.keys(t).forEach((r) => {
                  n(e, r, t[r]);
                });
              })(o, r),
            null != i && dr(o, i, s),
            o
          );
        })(e, 0, t, n, r, i)
      );
    };
  var pr,
    fr = { exports: {} },
    mr = (function () {
      if (pr) return fr.exports;
      pr = 1;
      const e = () => {
          const e = new Error("Delay aborted");
          return (e.name = "AbortError"), e;
        },
        t = (t) => {
          let { clearTimeout: n, setTimeout: r, willResolve: i } = t;
          return function (t, s) {
            let o,
              a,
              l,
              { value: u, signal: c } = void 0 === s ? {} : s;
            if (c && c.aborted) return Promise.reject(e());
            const d = n || clearTimeout,
              h = () => {
                d(o), l(e());
              },
              p = new Promise((e, n) => {
                (a = () => {
                  c && c.removeEventListener("abort", h), i ? e(u) : n(u);
                }),
                  (l = n),
                  (o = (r || setTimeout)(a, t));
              });
            return (
              c && c.addEventListener("abort", h, { once: !0 }),
              (p.clear = () => {
                d(o), (o = null), a();
              }),
              p
            );
          };
        },
        n = (e) => {
          const n = t({ ...e, willResolve: !0 });
          return (
            (n.reject = t({ ...e, willResolve: !1 })),
            (n.range = (e, t, r) =>
              n(
                ((e, t) => Math.floor(Math.random() * (t - e + 1) + e))(e, t),
                r
              )),
            n
          );
        },
        r = n();
      return (
        (r.createWithTimers = n),
        (fr.exports = r),
        (fr.exports.default = r),
        fr.exports
      );
    })(),
    gr = c(mr);
  const vr = () => {};
  function yr() {
    const e = {};
    return (
      (e.promise = new Promise((t, n) => {
        (e.resolve = t), (e.reject = n);
      })),
      e
    );
  }
  var br = (e, t) => {
    const n = yr(),
      r = () => {
        e.removeEventListener(t, r), n.resolve();
      };
    return (
      e.addEventListener(t, r),
      (n.promise.cancel = () => {
        e.removeEventListener(t, r), n.reject(new Error("Canceled"));
      }),
      n.promise
    );
  };
  var _r = function (e) {
    return new Promise(function (t, n) {
      var r = function (e) {
        return function (t) {
          try {
            return i.cancel(), s.cancel(), e && e.call(this, t);
          } catch (e) {
            return n(e);
          }
        }.bind(this);
      }.bind(this);
      let i, s;
      if ((void 0 === e && (e = document), null != e.body)) return t();
      var o, a;
      (o = e),
        (a = "body"),
        (i = (() => {
          const e = yr(),
            t = setInterval(() => {
              null != o[a] && e.resolve();
            }, 20);
          return (
            (e.promise.cancel = () => {
              clearInterval(t), e.reject(new Error("Canceled"));
            }),
            e.promise
          );
        })()),
        (s = br(e, "DOMContentLoaded")),
        i.catch(vr),
        s.catch(vr);
      var l = function () {
          try {
            return t();
          } catch (e) {
            return n(e);
          }
        },
        u = function (e) {
          try {
            throw e;
          } catch (e) {
            return r(n)(e);
          }
        };
      try {
        return Promise.resolve(Promise.race([i, s])).then(function (e) {
          try {
            return r(l)();
          } catch (e) {
            return u(e);
          }
        }, u);
      } catch (e) {
        u(e);
      }
    });
  };
  const wr = (e) =>
      new Promise(function (t, n) {
        var r;
        function i() {
          return null == e.contentWindow || null == e.contentWindow.document
            ? Promise.resolve(gr(100)).then(function (e) {
                try {
                  return i;
                } catch (e) {
                  return n(e);
                }
              }, n)
            : [1];
        }
        return (r = function (e) {
          for (; e; ) {
            if (e.then) return void e.then(r, n);
            try {
              if (e.pop) {
                if (e.length) return e.pop() ? s.call(this) : e;
                e = i;
              } else e = e.call(this);
            } catch (e) {
              return n(e);
            }
          }
        }.bind(this))(i);
        function s() {
          return t();
        }
      }),
    Ar = Symbol("data");
  class kr {
    constructor() {
      this[Ar] = Object.create(null);
    }
    _get(e) {
      return this[Ar][e];
    }
    _put(e, t) {
      this[Ar][e] = t;
    }
    _putAll(e) {
      const t = Object.keys(e);
      for (let n = 0; n < t.length; ++n) {
        const r = t[n],
          i = e[r];
        this._put(r, i);
      }
    }
  }
  const Sr = Symbol("listeners");
  class Pr {
    constructor() {
      this[Sr] = [];
    }
    get count() {
      return this[Sr].length;
    }
    add(e, t, n, r) {
      return (
        void 0 === r && (r = null),
        ((e) => null != e && "function" == typeof e.addEventListener)(e)
          ? (null != r && (n = n.bind(r)),
            e.addEventListener(t, n),
            this[Sr].push({ target: e, type: t, listener: n }),
            this)
          : this
      );
    }
    addMany(e, t, n) {
      return (
        void 0 === n && (n = null),
        Object.keys(t).forEach((r) => this.add(e, r, t[r], n)),
        this
      );
    }
    removeAll() {
      return (
        this[Sr].splice(0).forEach((e) => {
          let { target: t, type: n, listener: r } = e;
          t.removeEventListener(n, r);
        }),
        this
      );
    }
  }
  function Er(e, t) {
    if (!e)
      throw new ReferenceError(
        "this hasn't been initialised - super() hasn't been called"
      );
    return !t || ("object" != typeof t && "function" != typeof t) ? e : t;
  }
  var Cr = (function (e) {
    function t() {
      var e =
        arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "";
      !(function (e, t) {
        if (!(e instanceof t))
          throw new TypeError("Cannot call a class as a function");
      })(this, t);
      var n = Er(this, (t.__proto__ || Object.getPrototypeOf(t)).call(this, e));
      return (
        Object.defineProperty(n, "message", {
          configurable: !0,
          enumerable: !1,
          value: e,
          writable: !0,
        }),
        Object.defineProperty(n, "name", {
          configurable: !0,
          enumerable: !1,
          value: n.constructor.name,
          writable: !0,
        }),
        Error.hasOwnProperty("captureStackTrace")
          ? (Error.captureStackTrace(n, n.constructor), Er(n))
          : (Object.defineProperty(n, "stack", {
              configurable: !0,
              enumerable: !1,
              value: new Error(e).stack,
              writable: !0,
            }),
            n)
      );
    }
    return (
      (function (e, t) {
        if ("function" != typeof t && null !== t)
          throw new TypeError(
            "Super expression must either be null or a function, not " +
              typeof t
          );
        (e.prototype = Object.create(t.prototype, {
          constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0,
          },
        })),
          Object.setPrototypeOf
            ? Object.setPrototypeOf(e, t)
            : (e.__proto__ = t);
      })(t, e),
      t
    );
  })(
    (function (e) {
      function t() {
        e.apply(this, arguments);
      }
      return (
        (t.prototype = Object.create(e.prototype, {
          constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0,
          },
        })),
        Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : (t.__proto__ = e),
        t
      );
    })(Error)
  );
  class xr extends Cr {
    constructor(e) {
      super(e), (this.name = "CancelError");
    }
  }
  class Tr extends Cr {
    constructor() {
      super("Guest VPAID not available"),
        (this.name = "GuestNotAvailableError");
    }
  }
  let Or = class extends Cr {
    constructor(e, t, n, r) {
      void 0 === e && (e = null),
        void 0 === t && (t = null),
        void 0 === n && (n = null),
        void 0 === r && (r = null),
        super(e),
        (this.message = e),
        (this.code = t),
        (this.subject = r),
        (this.cause = n);
    }
    toString() {
      return (
        "VAST error" +
        (null == this.code ? "" : ` ${this.code}`) +
        (null == this.message || 0 === this.message.length
          ? " (no error message)"
          : `: ${this.message}`)
      );
    }
  };
  class Ir extends Or {
    constructor(e) {
      super(`Method "${e}" not available`, 405),
        (this.name = "MethodNotAvailableError");
    }
  }
  const Mr = /\/js\/vpaid-transformer\/[^/]+\/[a-z0-9-]+\.js#/;
  let Vr = null;
  const jr = () => (
      null == Vr &&
        (Vr =
          document.currentScript ||
          (() => {
            const e = document.querySelectorAll("script");
            let t = null,
              n = e.length - 1;
            for (; n >= 0 && null == t; ) {
              const r = e[n],
                { src: i } = r;
              null != i && Mr.test(i) && (t = r), --n;
            }
            return t;
          })()),
      Vr
    ),
    Fr = ["caller", "callee", "arguments"],
    Lr = (e, t) => {
      const n = { enumerable: !1, writable: !1, value: e[t] };
      Object.defineProperty(e, t, n);
    },
    Rr = (e) => {
      if (null == e || "" === e) return null;
      if ("undefined" != typeof URL && URL instanceof Function)
        return new URL(e).hostname;
      {
        const t = document.createElement("a");
        return (t.href = e), t.hostname;
      }
    },
    Dr = (e) => (t) => {
      for (t = "" + t; t.length < e; ) t = "0" + t;
      return t;
    },
    $r = Dr(2),
    Nr = Dr(3),
    Ur = (e) => {
      const {
          domainLookupStart: t,
          domainLookupEnd: n,
          connectStart: r,
          connectEnd: i,
          secureConnectionStart: s,
          requestStart: o,
          responseStart: a,
          responseEnd: l,
        } = e,
        u = {
          dns: Math.round(n - t),
          tcpHandshake: Math.round(i - r),
          response: Math.round(l - a),
          requestStartUntilResponseEnd: Math.round(l - o),
        };
      return s > 0 && (u.secureConnection = Math.round(i - s)), u;
    },
    Br = (e) => {
      const t = ((e) => {
        let t = null;
        try {
          t = performance.getEntriesByType("resource").find((t) => {
            let { name: n } = t;
            return n === e;
          });
        } catch (e) {}
        return t;
      })(e);
      return null == t ? null : Ur(t);
    },
    zr = /^[^:]+:\/\/tpc\.googlesyndication\.com\/pagead\/js\/loader/,
    Wr =
      /^[^:]+:\/\/imasdk\.googleapis\.com\/js\/sdkloader\/vpaid_adapter\.js\b/,
    qr = (e) => Wr.test(e);
  var Hr = function (e, t, n) {
      return (
        void 0 === t && (t = null),
        void 0 === n && (n = document),
        new Promise((r, i) => {
          const s = n.createElement("script");
          s.addEventListener("load", () => r(s)),
            s.addEventListener("error", () =>
              i(new Or(`Failed to insert "${e}"`, 405))
            ),
            (s.src = e),
            (s.crossOrigin = t),
            n.getElementsByTagName("head")[0].appendChild(s);
        })
      );
    },
    Gr = (e) => {
      let t = 0,
        n = null;
      return function () {
        if (0 === t)
          try {
            for (var r = arguments.length, i = new Array(r), s = 0; s < r; s++)
              i[s] = arguments[s];
            (n = e.apply(this, i)), (t = 1);
          } catch (e) {
            (n = e), (t = 2);
          }
        if (2 === t) throw n;
        return n;
      };
    };
  const Qr = {
      HH_MM_SS: {
        regex: /^\s*(\d+):(\d+):(\d+(?:\.\d+)?)\s*$/,
        parse: (e) =>
          60 * (60 * parseInt(e[1], 10) + parseInt(e[2], 10)) +
          parseFloat(e[3]),
      },
      MILLISECONDS: {
        regex: /^\s*(\d+(?:\.\d+)?)\s*ms\s*$/i,
        parse: (e) => parseFloat(e[1]) / 1e3,
      },
      SECONDS: { regex: /^\s*(\d+(?:\.\d+)?)\s*s\s*$/i },
      BARE_NUMBER: { regex: /^\s*(\d+(?:\.\d+)?)\s*$/ },
      PERCENT: { regex: /^\s*(\d+(?:\.\d+)?)\s*%\s*$/ },
    },
    Yr = (e) => {
      if ("number" == typeof e) return !Number.isFinite(e) || e < 0 ? null : e;
      if ("string" != typeof e || 0 === e.length) return null;
      for (const t of Object.values(Qr)) {
        const n = t.regex.exec(e);
        if (null != n) return null != t.parse ? t.parse(n) : parseFloat(n[1]);
      }
      return null;
    },
    Xr = (e) => null != e && "object" == typeof e && Number.isFinite(e.percent),
    Kr = (e) =>
      !Number.isFinite(e) || e < 0 || e > 100 ? null : { percent: e },
    Zr = (e, t) =>
      Xr(e)
        ? "number" != typeof t || !Number.isFinite(t) || t <= 0
          ? null
          : (e.percent / 100) * t
        : null;
  var Jr,
    ei = () => new Date().getTime(),
    ti = { exports: {} },
    ni = ti.exports,
    ri =
      (Jr ||
        ((Jr = 1),
        (function (e) {
          !(function (t, n) {
            e.exports ? (e.exports = n()) : (t.Queue = n());
          })(ni, function () {
            var e =
                "undefined" != typeof Promise
                  ? Promise
                  : function () {
                      return {
                        then: function () {
                          throw new Error("Queue.configure() before use Queue");
                        },
                      };
                    },
              t = function () {};
            function n(e, t, n) {
              (this.options = n = n || {}),
                (this.pendingPromises = 0),
                (this.maxPendingPromises = void 0 !== e ? e : 1 / 0),
                (this.maxQueuedPromises = void 0 !== t ? t : 1 / 0),
                (this.queue = []);
            }
            return (
              (n.configure = function (t) {
                e = t;
              }),
              (n.prototype.add = function (n) {
                var r = this;
                return new e(function (e, i, s) {
                  r.queue.length >= r.maxQueuedPromises
                    ? i(new Error("Queue limit reached"))
                    : (r.queue.push({
                        promiseGenerator: n,
                        resolve: e,
                        reject: i,
                        notify: s || t,
                      }),
                      r._dequeue());
                });
              }),
              (n.prototype.getPendingLength = function () {
                return this.pendingPromises;
              }),
              (n.prototype.getQueueLength = function () {
                return this.queue.length;
              }),
              (n.prototype._dequeue = function () {
                var t = this;
                if (this.pendingPromises >= this.maxPendingPromises) return !1;
                var n,
                  r = this.queue.shift();
                if (!r)
                  return this.options.onEmpty && this.options.onEmpty(), !1;
                try {
                  this.pendingPromises++,
                    ((n = r.promiseGenerator()),
                    n && "function" == typeof n.then
                      ? n
                      : new e(function (e) {
                          e(n);
                        })).then(
                      function (e) {
                        t.pendingPromises--, r.resolve(e), t._dequeue();
                      },
                      function (e) {
                        t.pendingPromises--, r.reject(e), t._dequeue();
                      },
                      function (e) {
                        r.notify(e);
                      }
                    );
                } catch (e) {
                  t.pendingPromises--, r.reject(e), t._dequeue();
                }
                return !0;
              }),
              n
            );
          });
        })(ti)),
      ti.exports),
    ii = c(ri);
  function si(e) {
    return e.charAt(0).toUpperCase() + e.substr(1);
  }
  const oi = Symbol("plugins"),
    ai = Symbol("queue"),
    li = Symbol("logger");
  class ui {
    constructor() {
      (this[oi] = []),
        (this[ai] = new ii(1)),
        (this.dispose = Gr(this.dispose));
    }
    get plugins() {
      return this[oi].slice();
    }
    addPlugin(e) {
      this[oi].push(e);
    }
    dispose() {
      return Promise.all(this._runStageHooks("dispose", [])).then(() =>
        this[li].info("Plugin disposal finished")
      );
    }
    runPhase(e, t, n, r) {
      return new Promise(
        function (i, s) {
          return (
            void 0 === r && (r = null),
            i(
              this[ai].add(
                () =>
                  new Promise(
                    function (i, s) {
                      return i(this._runPhase0(e, t, n, r));
                    }.bind(this)
                  )
              )
            )
          );
        }.bind(this)
      );
    }
    runPhaseSync(e, t, n, r) {
      const i = si(e);
      this._runStageHooks(`before${i}Sync`, t);
      const s = n(...t);
      return this._runStage(`after${i}`, [...t, s]).catch(r), s;
    }
    _runPhase0(e, t, n, r) {
      return new Promise(
        function (i, s) {
          let o, a, l;
          if (null != r && r()) return s(new Error(`Phase ${e} canceled`));
          o = si(e);
          var u = function () {
              try {
                return (
                  (a = n(...t)),
                  Promise.resolve(
                    new Promise(function (e, t) {
                      return Ee(a) ? Promise.resolve(a).then(e, t) : e(a);
                    })
                  ).then(
                    function (e) {
                      try {
                        return (
                          (l = e),
                          Promise.resolve(
                            this._runStage(`after${o}`, [...t, a])
                          ).then(function (e) {
                            try {
                              return i(l);
                            } catch (e) {
                              return s(e);
                            }
                          }, s)
                        );
                      } catch (e) {
                        return s(e);
                      }
                    }.bind(this),
                    s
                  )
                );
              } catch (e) {
                return s(e);
              }
            }.bind(this),
            c = function (e) {
              try {
                if (e instanceof xr) return i(null);
                throw e;
              } catch (e) {
                return s(e);
              }
            };
          try {
            return Promise.resolve(this._runStage(`before${o}`, t)).then(
              function (e) {
                try {
                  return u();
                } catch (e) {
                  return c(e);
                }
              },
              c
            );
          } catch (e) {
            c(e);
          }
        }.bind(this)
      );
    }
    _runStage(e, t) {
      return new Promise(
        function (n, r) {
          return n(Promise.all(this._runStageHooks(e, t)));
        }.bind(this)
      );
    }
    _runStageHooks(e, t) {
      return this[oi]
        .filter((t) => null != t[e])
        .map((n) => n[e](...t))
        .filter(Ee);
    }
  }
  const ci = function (e, t, n) {
    void 0 === n && (n = "Timed out");
    const r = gr.reject(t, { value: new Error(n) });
    return (
      r.catch(vr),
      Promise.race([e, r]).finally(() => {
        r.clear();
      })
    );
  };
  var di = (e) => {
    const t = {};
    return (
      Object.keys(e)
        .filter((t) => null != e[t])
        .forEach((n) => {
          t[n] = e[n];
        }),
      t
    );
  };
  const hi = {
      timestamp: () =>
        encodeURIComponent(
          ((e) => {
            const t = e.getTimezoneOffset(),
              n = Math.floor(t / 60),
              r = (n < 0 ? "+" + $r(-n) : "-" + $r(n)) + ":" + $r(t % 60);
            return (
              e.getFullYear() +
              "-" +
              $r(e.getMonth() + 1) +
              "-" +
              $r(e.getDate()) +
              "T" +
              $r(e.getHours()) +
              ":" +
              $r(e.getMinutes()) +
              ":" +
              $r(e.getSeconds()) +
              "." +
              Nr(e.getMilliseconds()) +
              r
            );
          })(new Date())
        ),
      cachebusting: () => ("" + $e()).substring(0, 8),
      errorcode: (e) => {
        let {
          macros: { errorcode: t },
        } = e;
        return null != t ? t : 900;
      },
      serverside: () => "0",
      apiframeworks: () => "2",
      vastversions: () => "2,3,5,6,7,8,11,12,13,14",
      verificationvendors: () => "",
      extensions: () => "",
      gdpr: (e) => {
        let {
          config: { gdpr: t = "" },
        } = e;
        return encodeURIComponent(t);
      },
      gdprconsent: (e) => {
        let {
          config: { gdpr_consent: t = "" },
        } = e;
        return encodeURIComponent(t);
      },
    },
    pi = /\[([A-Z_]+)]/g,
    fi = {
      GDPR: {
        regexp: /\$\{GDPR\}/g,
        value: (e) => {
          let { gdpr: t = "" } = e;
          return encodeURIComponent(t);
        },
      },
      GDPR_CONSENT: {
        regexp: /\$\{GDPR_CONSENT_\d+\}/g,
        value: (e) => {
          let { gdpr_consent: t = "" } = e;
          return encodeURIComponent(t);
        },
      },
    },
    mi = 91,
    gi = 92,
    vi = 94,
    yi = 95,
    bi = (e) => {
      const t = {
        [mi]: e.dns,
        [gi]: e.tcpHandshake,
        [vi]: e.response,
        [yi]: e.requestStartUntilResponseEnd,
      };
      return (
        e.secureConnectionStart > 0 && (t[93] = e.secureConnectionStart), t
      );
    },
    _i = Math.sqrt(2),
    wi = ["video/3gpp"],
    Ai = { [We.vpaid]: 1, [We.video]: 2, [We.vast]: 3 },
    ki = (e) => {
      let { width: t, height: n } = e;
      return t * n;
    },
    Si = (e) => e.reduce((e, t) => (ki(t) < ki(e) ? t : e)),
    Pi = (e) => e.reduce((e, t) => (ki(t) > ki(e) ? t : e)),
    Ei = (e, t) => {
      let { selector: n, filter: r } = t,
        i = null,
        s = 0;
      for (; s < e.length && null == i; ) {
        const t = e[s].filter(r);
        t.length > 0 && (i = n(t)), ++s;
      }
      return i;
    },
    Ci = (e) => (e > 0 ? e : 1 / 0),
    xi = (e, t, n, r) => {
      const { probably: i = [], maybe: s = [] } = ((e, t, n) => {
        const r = {};
        for (let n = 0; n < e.length; ++n) {
          const { type: i } = e[n];
          Object.prototype.hasOwnProperty.call(r, i) ||
            (r[i] = t.canPlayType(i));
        }
        const i = {};
        for (let e = 0; e < n.length; ++e) i[n[e]] = [];
        for (let t = 0; t < e.length; ++t) {
          const n = e[t],
            s = r[n.type];
          null != i[s] && i[s].push(n);
        }
        return i;
      })(e, n, ["probably", ...(r ? ["maybe"] : [])]);
      if (i.length + s.length === 0) return null;
      let o = null,
        a = 0;
      for (; a < t.length && null == o; ) (o = Ei([i, s], t[a])), ++a;
      return o;
    },
    Ti = {
      [We.vast]: (e) => e[0],
      [We.vpaid]: (e) =>
        ((e) => {
          const t = e.filter(Ye);
          return t.length > 0 ? Pi(t) : null;
        })(e),
      [We.video]: (e, t, n) => {
        const r = e.filter((e) => {
            let { type: t } = e;
            return wi.indexOf(t) < 0;
          }),
          i = r.length > 0 ? r : e;
        let s;
        return (
          null != n &&
            "function" == typeof n.canPlayType &&
            (s = xi(i, t, n, !1)),
          null == s && (s = xi(i, t, document.createElement("video"), !0)),
          s
        );
      },
    },
    Oi = (e, t) => Ai[e] - Ai[t];
  var Ii,
    Mi,
    Vi,
    ji = { exports: {} },
    Fi =
      (Ii ||
        ((Ii = 1),
        (function (e) {
          function t(e, t) {
            var n = [],
              r = [];
            return (
              null == t &&
                (t = function (e, t) {
                  return n[0] === t
                    ? "[Circular ~]"
                    : "[Circular ~." + r.slice(0, n.indexOf(t)).join(".") + "]";
                }),
              function (i, s) {
                if (n.length > 0) {
                  var o = n.indexOf(this);
                  ~o ? n.splice(o + 1) : n.push(this),
                    ~o ? r.splice(o, 1 / 0, i) : r.push(i),
                    ~n.indexOf(s) && (s = t.call(this, i, s));
                } else n.push(s);
                return null == e ? s : e.call(this, i, s);
              }
            );
          }
          (e.exports = function (e, n, r, i) {
            return JSON.stringify(e, t(n, i), r);
          }).getSerialize = t;
        })(ji)),
      ji.exports),
    Li = c(Fi),
    Ri = c(
      (function () {
        if (Vi) return Mi;
        function e(e) {
          return null == e ? null : Object.getPrototypeOf(Object(e));
        }
        return (
          (Vi = 1),
          (Mi = function (t) {
            for (var n = [], r = e(t); r; ) n.push(r), (r = e(r));
            return n;
          })
        );
      })()
    );
  const Di = (e) => {
      if (null == e) return e;
      const t = Object.keys(e);
      if (1 !== t.length || "message" !== t[0]) return e;
      let n = e.message;
      return Array.isArray(n) && 1 === n.length && (n = n[0]), Di(n);
    },
    $i = (e, t) => {
      let n, r;
      switch (typeof e) {
        case "object":
          return null == e
            ? e
            : null != e.nodeType
            ? `[DOM ${((e) => {
                if (null == e) return "null";
                if (1 !== e.nodeType) return "node";
                try {
                  let t = (e.nodeName || "unknown").toLowerCase();
                  return (
                    null != e.id && (t += `#${e.id}`),
                    e.classList &&
                      e.classList.length > 0 &&
                      (t += "." + Array.from(e.classList).join(".")),
                    t
                  );
                } catch (e) {
                  return "err";
                }
              })(e)}]`
            : t.indexOf(e) >= 0
            ? "[Circular]"
            : (t.push(e),
              (n = Array.isArray(e) ? [] : {}),
              (r = Ri(e).filter((e) => e !== Object.prototype)),
              Di(
                [e]
                  .concat(r)
                  .map((e) => Object.getOwnPropertyNames(e))
                  .reduce(
                    (n, r) => (
                      r.forEach((r) => {
                        try {
                          (e instanceof Error && "stack" === r) ||
                            (n[r] = $i(e[r], t));
                        } catch (e) {
                          n[r] = `[Error: ${e.message || e}]`;
                        }
                      }),
                      n
                    ),
                    n
                  )
              ));
        case "function":
          if (t.length > 0) return;
          return `[Function ${e.name || "anonymous"}]`;
        default:
          return e;
      }
    },
    Ni = (e) => {
      try {
        const t = $i(e, []) || e;
        switch (typeof t) {
          case "string":
            return t;
          case "number":
            return "" + t;
          default:
            return Li(t);
        }
      } catch (e) {
        return "[Error]";
      }
    },
    Ui = ei(),
    Bi = () => ei() - Ui,
    [zi, Wi] =
      "undefined" != typeof process
        ? [process.env.LOG_LEVEL, process.env.NODE_ENV]
        : [];
  class qi {
    constructor(e, t) {
      (this._scope = e), (this.level = t), this._init();
    }
    get scope() {
      return this._scope;
    }
    get level() {
      return this._level;
    }
    set level(e) {
      (this._level = e), (this._levelIndex = qi.LEVELS.indexOf(this._level));
    }
    isAllowed(e) {
      return qi.LEVELS.indexOf(e) >= this._levelIndex;
    }
    formatArgs(e) {
      const t = Date.now(),
        n = t - this._startTime,
        r = t - this._prevTime;
      return (
        (this._prevTime = t),
        (e = e.slice()).unshift(`(${n}, +${r})`),
        null != this._scope && e.unshift(this._scope + ":"),
        e.join(" ")
      );
    }
    _init() {
      var e = this;
      (this._startTime =
        "undefined" != typeof window &&
        null != window.performance &&
        null != window.performance.timing
          ? window.performance.timing.navigationStart
          : Date.now()),
        (this._prevTime = this._startTime);
      for (let t = 0; t < qi.LEVELS.length; ++t) {
        const n = qi.LEVELS[t],
          r = function () {
            if (t >= e._levelIndex) {
              for (
                var r = arguments.length, i = new Array(r), s = 0;
                s < r;
                s++
              )
                i[s] = arguments[s];
              console[n](e.formatArgs(i));
            }
          };
        Object.defineProperty(this, n, { value: r });
      }
    }
  }
  Object.defineProperty(qi, "LEVELS", {
    value: ["debug", "log", "info", "warn", "error"],
  });
  const Hi = new WeakMap();
  let Gi = 0;
  const Qi = (e) => "string" != typeof e || 0 === e.length,
    Yi = Symbol("runtime"),
    Xi = Symbol("init"),
    Ki = Symbol("setGuest"),
    Zi = Symbol("ensureContainer"),
    Ji = Symbol("slot"),
    es = Symbol("videoSlot"),
    ts = Symbol("phaser"),
    ns = Symbol("pubSub"),
    rs = Symbol("clickThroughUrl"),
    is = Symbol("adCompanions"),
    ss = Symbol("options"),
    os = Symbol("internal"),
    as = Symbol("adParameters");
  var ls = Object.freeze({
    __proto__: null,
    adCompanions: is,
    adParameters: as,
    clickThroughUrl: rs,
    ensureContainer: Zi,
    init: Xi,
    internal: os,
    options: ss,
    phaser: ts,
    pubSub: ns,
    runtime: Yi,
    setGuest: Ki,
    slot: Ji,
    videoSlot: es,
  });
  const us = Symbol("config"),
    cs = Symbol("logger");
  class ds {
    static get id() {
      throw new Error("Method is abstract");
    }
    static get defaultConfig() {
      return null;
    }
    constructor() {
      (this[cs] = (function (e, t) {
        void 0 === t && (t = {});
        const n = ((e) => (
            null != e && "string" != typeof e
              ? (Hi.has(e) || Hi.set(e, Gi++),
                (e =
                  ("function" == typeof e ? e.name : e.constructor.name) +
                  "@" +
                  Hi.get(e)))
              : "string" == typeof e && (e = "" + e),
            e
          ))(e),
          r = "test" === Wi ? "error" : "log",
          i = [t.level, zi, r].reduce((e, t) => (Qi(e) && !Qi(t) ? t : e));
        return new qi(n, i);
      })(this)),
        (this[us] = null),
        (this[Yi] = null),
        (this.dispose = Gr(this.dispose));
    }
    get runtime() {
      return this[Yi];
    }
    get config() {
      return this[us];
    }
    get host() {
      return this[Yi].host;
    }
    get hostInfo() {
      return this[Yi].hostInfo;
    }
    get guest() {
      return this[Yi].guest;
    }
    get logger() {
      return this[cs];
    }
    init() {}
    dispose() {}
    publish(e, t) {
      return (
        void 0 === t && (t = []),
        this[Yi].publish(e, t, `plugin-${this.constructor.id}`)
      );
    }
    track() {
      this[Yi].track(...arguments);
    }
    trackPixel(e, t) {
      this[Yi].trackPixel(e, t);
    }
    trackError() {
      this[Yi].trackError(...arguments);
    }
    setConfig(e) {
      this[us] = Object.assign({}, this.constructor.defaultConfig, this[us], e);
    }
    [Xi](e, t) {
      if (null != this[us]) throw new Error("Already configured");
      (this[Yi] = e), this.setConfig(t), this.init();
    }
  }
  const { init: hs } = ls;
  class ps extends ds {}
  const fs = Object.create(null);
  var ms = new (class {
    constructor() {
      this._contents = Object.create(null);
    }
    register(e) {
      const t = e.id;
      if (null != this._contents[t] && this._contents[t] !== e)
        throw new Error(`Plugin "${t}" already registered`);
      this._provisionParent(t), (this._contents[t] = e);
    }
    create(e, t, n) {
      if (null == this._contents[e])
        throw new Error(`Plugin "${e}" not registered`);
      const r = new (0, this._contents[e])();
      return r[hs](n, t), r;
    }
    _provisionParent(e) {
      const t = e.indexOf(".");
      if (t < 0) return;
      const n = e.substr(0, t);
      null == this._contents[n] &&
        (this._contents[n] = ((e) => (
          null == fs[e] &&
            (fs[e] = class extends ps {
              static get id() {
                return e;
              }
            }),
          fs[e]
        ))(n));
    }
  })();
  const gs = Symbol("subscribers"),
    vs = Symbol("published"),
    ys = Symbol("options");
  class bs {
    constructor(e) {
      void 0 === e && (e = {}),
        (this[gs] = {}),
        (this[vs] = []),
        (this[ys] = e);
    }
    get published() {
      return this[vs];
    }
    get options() {
      return this[ys];
    }
    subscribe(e, t, n) {
      void 0 === n && (n = null),
        null == this[gs][t] && (this[gs][t] = []),
        this[gs][t].push({ fn: e, ctx: n });
    }
    unsubscribe(e, t) {
      const n = this[gs][t];
      if (null != n)
        for (let t = n.length - 1; t >= 0; --t) n[t].fn === e && n.splice(t, 1);
    }
    publish(e, t) {
      if ((void 0 === t && (t = []), _e.indexOf(e) >= 0 && this.didPublish(e)))
        return;
      const n = this._normalizeEventArgs(e, t);
      if ((this[vs].push({ name: e, args: t }), null == this[gs][e])) return;
      const r = this[gs][e].slice();
      for (let e = 0; e < r.length; ++e) {
        const { fn: i, ctx: s } = r[e],
          o = null != s && !0 === s[os];
        i.apply(s, o ? t : n);
      }
    }
    didPublish(e) {
      return this[vs].some((t) => {
        let { name: n } = t;
        return e === n;
      });
    }
    _normalizeEventArgs(e, t) {
      if (e === be.AdClickThru) {
        const [e, n, r] = t;
        return [
          "string" == typeof e ? e : void 0,
          null != n ? n : "",
          null == r || !!r,
        ];
      }
      if (e === be.AdError) {
        const [e, n] = t;
        return !0 === this[ys].sendErrorInfo ? [e, di(n)] : [e];
      }
      return t;
    }
  }
  const _s = 10,
    ws = 110,
    As =
      "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAAAAAA6fptVAAAAAXNCSVQI5gpbmQAAAApJREFUCB1jYAAAAAIAAc/INeUAAAAASUVORK5CYII=",
    ks = "cdn.doubleverify.com",
    Ss = "rtb0.doubleverify.com",
    Ps = "https://c.amazon-adsystem.com/vfw/dv",
    Es = "advm.js",
    Cs = `https://${ks}/dvtp_src.js`,
    xs = `https://${ks}/dvbs_src.js`,
    Ts = `https://${ks}/dvbm.js`,
    Os = `${Ps}/advbm.js`,
    Is = [
      { id: "boot", pattern: `${xs}?` },
      { id: "src", pattern: `//${ks}/dvbs_src_internal` },
      { id: "verify", pattern: `//${Ss}/verify.js?` },
    ],
    Ms = {
      tagtype: "video",
      dvtagver: "6.1.src",
      tagformat: "2",
      msrapi: "jsVpaid",
      zjsver: u,
      omid: "0",
    },
    Vs = [
      "ctx",
      "cmp",
      "sid",
      "plc",
      "advid",
      "crt",
      "dup",
      "adsrv",
      "tagtype",
      "omid",
    ],
    js = Symbol("name"),
    Fs = Symbol("states"),
    Ls = Symbol("infos"),
    Rs = Symbol("state"),
    Ds = Symbol("initialState"),
    $s = Symbol("timings");
  class Ns {
    constructor(e, t, n) {
      void 0 === t && (t = 0),
        void 0 === n && (n = void 0),
        (this[js] = e),
        (this[Fs] = []),
        (this[Ls] = []),
        (this[$s] = []),
        (this[Ds] = t),
        this.set(t, n);
    }
    get name() {
      return this[js];
    }
    get state() {
      return this[Rs];
    }
    getInfo(e) {
      if (e <= this.state) return this[Ls][e];
    }
    set(e, t) {
      void 0 === t && (t = void 0);
      const n = this[Rs];
      if (e < n)
        throw new Error(`Invalid ${this[js]} state change: ${n} → ${e}`);
      if (e !== n) {
        this._ensureStates(e);
        for (let t = n + 1; t < e; ++t) this[Fs][t].resolve();
        this[Fs][e].resolve(t),
          (this[Ls][e] = t),
          (this[$s][e] = ei()),
          (this[Rs] = e),
          this[Ds];
      }
    }
    maybeSet(e, t) {
      return (
        void 0 === t && (t = void 0), !this.reached(e) && (this.set(e, t), !0)
      );
    }
    reach(e) {
      return new Promise(
        function (t, n) {
          return this._ensureStates(e), t(this[Fs][e].promise);
        }.bind(this)
      );
    }
    reached(e) {
      return e <= this.state;
    }
    time(e) {
      return this[$s][e];
    }
    timeBetween(e, t) {
      if (e > t)
        throw new Error(
          `toState (${t}) must be greater than or equal to fromState (${e})`
        );
      return this.time(t) - this.time(e);
    }
    _ensureStates(e) {
      for (let t = this[Fs].length; t <= e; ++t)
        this[Fs].push(yr()), this[Ls].push(void 0), this[$s].push(void 0);
    }
  }
  const Us = Symbol("facade"),
    Bs = Symbol("proxyCb");
  class zs {
    constructor(e) {
      (this[Us] = e), De({ href: `//${ks}`, rel: "preconnect", pr: "1.0" });
    }
    get facade() {
      return this[Us];
    }
    get logger() {
      return this.facade.logger;
    }
    start() {
      return new Promise(
        function (e, t) {
          return (
            (this[Bs] = new Be(() => this.facade.proxy)),
            (this.facade.config.adid = this[Bs].name),
            e()
          );
        }.bind(this)
      );
    }
    decide() {
      return new Promise(function (e, t) {
        return e(3);
      });
    }
    enableDecisionTimeout() {
      return new Promise(function (e, t) {
        return e();
      });
    }
    onStartCreativeLoad() {}
    dispose() {
      return new Promise(
        function (e, t) {
          return (
            null != this[Bs] && (this[Bs].remove(), (this[Bs] = null)), e()
          );
        }.bind(this)
      );
    }
    _getFalconUri(e) {
      return "amazon" === e.proxy
        ? Os
        : "1" === e.falcondvtechcdn
        ? "https://cdn.dv.tech/dvbm.js"
        : Ts;
    }
    _insertScript(e) {
      return new Promise(
        function (t, n) {
          let r, i, s, o;
          return (
            void 0 === e && (e = Hr),
            (r = this._getConfig(Vs)),
            (i = this._getScriptUri(r)),
            (s = this._getDelimiter(r)),
            (o = `${i}${s}${((e) => {
              const t = Object.keys(e);
              if (0 === t.length) return "";
              let n =
                encodeURIComponent(t[0]) + "=" + encodeURIComponent(e[t[0]]);
              for (let r = 1; r < t.length; ++r)
                n +=
                  "&" +
                  encodeURIComponent(t[r]) +
                  "=" +
                  encodeURIComponent(e[t[r]]);
              return n;
            })(r)}`),
            Promise.resolve(e(o, void 0, void 0)).then(function (e) {
              try {
                return t();
              } catch (e) {
                return n(e);
              }
            }, n)
          );
        }.bind(this)
      );
    }
    _getScriptUri(e) {
      throw new Error("Not implemented");
    }
    _getDelimiter(e) {
      throw new Error("Not implemented");
    }
    _getConfig(e) {
      let t;
      if (null != e) {
        (t = {}),
          e.forEach((e) => {
            null != this.facade.config[e] && (t[e] = this.facade.config[e]);
          });
        for (const n in this.facade.config)
          Object.prototype.hasOwnProperty.call(this.facade.config, n) &&
            !e.includes(n) &&
            (t[n] = this.facade.config[n]);
      } else t = this.facade.config;
      return t;
    }
  }
  const Ws = Symbol("state"),
    qs = Symbol("recommendationFromDvCb"),
    Hs = Symbol("ackConfirmationFromDvCb"),
    Gs = Symbol("timedOut"),
    Qs = Symbol("shouldAcknowledge"),
    Ys = Symbol("timingMonitorInterval"),
    Xs = Symbol("timingMonitorSeen"),
    Ks = (e, t) =>
      e.startsWith("//")
        ? t.startsWith(`https:${e}`) || t.startsWith(`http:${e}`)
        : t.startsWith(e);
  class Zs extends zs {
    constructor(e) {
      super(e),
        (this[Ws] = new Ns("blocking-state")),
        (this[qs] = null),
        (this[Hs] = null),
        (this[Gs] = !1),
        (this[Qs] = !1),
        (this._scheduleAndProcessRecommendationTimeout = Gr(
          this._scheduleAndProcessRecommendationTimeout
        )),
        De({ href: `//${Ss}`, rel: "preconnect", pr: "1.0" }),
        De({ href: "//tps.doubleverify.com", rel: "preconnect", pr: "1.0" });
    }
    start(e) {
      return new Promise(
        function (t, n) {
          return (
            void 0 === e && (e = Hr),
            Promise.resolve(this.$super$1("start").call(this)).then(
              function (r) {
                try {
                  return (
                    (this[qs] = new Be(
                      this._processRecommendationFromDv.bind(this)
                    )),
                    (this.facade.config.DVP_DCB = this[qs].name),
                    this[Ws].set(1),
                    this._startTimingMonitor(),
                    Promise.resolve(this._insertScript(e)).then(
                      function (e) {
                        try {
                          return this._processTimings(), t();
                        } catch (e) {
                          return n(e);
                        }
                      }.bind(this),
                      n
                    )
                  );
                } catch (e) {
                  return n(e);
                }
              }.bind(this),
              n
            )
          );
        }.bind(this)
      );
    }
    _getDelimiter(e) {
      return "1" === e.falcon ? "#" : "?";
    }
    _getScriptUri(e) {
      return "1" === e.falcon || null != e.proxy ? super._getFalconUri(e) : xs;
    }
    onStartCreativeLoad(e) {
      null == e || (null != e.poster && "" !== e.poster) || (e.poster = As);
    }
    decide() {
      return new Promise(
        function (e, t) {
          return e(this[Ws].reach(2));
        }.bind(this)
      );
    }
    enableDecisionTimeout() {
      return new Promise(
        function (e, t) {
          return this._scheduleAndProcessRecommendationTimeout(), e();
        }.bind(this)
      );
    }
    dispose() {
      return new Promise(
        function (e, t) {
          if (this[Ws].reached(1))
            return Promise.resolve(this.enableDecisionTimeout()).then(
              function (e) {
                try {
                  if (this[Qs] && !this[Ws].reached(3))
                    return Promise.resolve(this[Ws].reach(3)).then(
                      function (e) {
                        try {
                          return r.call(this);
                        } catch (e) {
                          return t(e);
                        }
                      }.bind(this),
                      t
                    );
                  function r() {
                    return n.call(this);
                  }
                  return r.call(this);
                } catch (i) {
                  return t(i);
                }
              }.bind(this),
              t
            );
          function n() {
            return (
              null != this[qs] && (this[qs].remove(), (this[qs] = null)),
              null != this[Hs] && (this[Hs].remove(), (this[Hs] = null)),
              this._processTimings(),
              this._disposeTimingMonitor(),
              Promise.resolve(this.$super$1("dispose").call(this)).then(
                function (n) {
                  try {
                    return e();
                  } catch (e) {
                    return t(e);
                  }
                },
                t
              )
            );
          }
          return n.call(this);
        }.bind(this)
      );
    }
    _getBlockingTimeout() {
      const { blkto: e } = this.facade.config,
        t = null != e ? parseInt(e, 10) : 900;
      return isNaN(t) ? 900 : Math.min(Math.max(t, 100), 3e3);
    }
    _scheduleAndProcessRecommendationTimeout() {
      return new Promise(
        function (e, t) {
          let n, r, i;
          return Promise.resolve(this[Ws].reach(1)).then(
            function (s) {
              try {
                if (
                  ((n = this[Ws].time(1)),
                  (r = this._getBlockingTimeout()),
                  (i = n + r - ei()),
                  i > 0)
                )
                  return Promise.resolve(gr(i)).then(
                    function (e) {
                      try {
                        return o.call(this);
                      } catch (e) {
                        return t(e);
                      }
                    }.bind(this),
                    t
                  );
                function o() {
                  return (
                    (this[Gs] = this[Ws].maybeSet(
                      2,
                      "block" === this.facade.config.blktoa ? 1 : 2
                    )),
                    this[Gs] && (this.facade.timedOut = this[Gs]),
                    e()
                  );
                }
                return o.call(this);
              } catch (a) {
                return t(a);
              }
            }.bind(this),
            t
          );
        }.bind(this)
      );
    }
    _processRecommendationFromDv(e, t) {
      (this[Qs] = !0),
        this[Ws].maybeSet(2, e),
        this._sendRecommendationAckToDv(t, ei());
    }
    _sendRecommendationAckToDv(e, t) {
      return new Promise(
        function (n, r) {
          let i, s, o, a, l, u;
          return Promise.resolve(
            new Promise(
              function (e, t) {
                return this.facade.creative.reached(3)
                  ? e([!1, !1])
                  : Promise.resolve(
                      Promise.race([
                        this.facade
                          .decide()
                          .then(
                            (e) =>
                              !!e &&
                              this.facade.creative.reach(1).then(() => !0)
                          ),
                        this.facade.creative.reach(3).then(() => !1),
                      ])
                    ).then(
                      function (n) {
                        try {
                          return e([n, !this[Gs]]);
                        } catch (e) {
                          return t(e);
                        }
                      }.bind(this),
                      t
                    );
              }.bind(this)
            )
          ).then(
            function (c) {
              try {
                ([i, s] = c),
                  (o = this.facade.creative.time(1) || -1),
                  (a = this.facade.creative.time(2) || -1),
                  (l = yr()),
                  (this[Hs] = new Be(() => {
                    l.resolve();
                  })),
                  (u = [i, s, o, a, t, this[Hs].name]);
                var d = function () {
                    try {
                      return this[Ws].set(3), n();
                    } catch (e) {
                      return r(e);
                    }
                  }.bind(this),
                  h = function (e) {
                    try {
                      return d();
                    } catch (e) {
                      return r(e);
                    }
                  };
                try {
                  return (
                    new Be(e).invoke(...u),
                    Promise.resolve(Promise.race([l.promise, gr(500)])).then(
                      function (e) {
                        try {
                          return d();
                        } catch (e) {
                          return h();
                        }
                      },
                      h
                    )
                  );
                } catch (e) {
                  h();
                }
              } catch (e) {
                return r(e);
              }
            }.bind(this),
            r
          );
        }.bind(this)
      );
    }
    _startTimingMonitor() {
      (this[Xs] = Is.map(() => !1)),
        (this[Ys] = setInterval(this._processTimings.bind(this), 250));
    }
    _disposeTimingMonitor() {
      null != this[Ys] &&
        (clearInterval(this[Ys]), (this[Ys] = null), (this[Xs] = null));
    }
    _processTimings() {
      let e;
      try {
        e = performance.getEntriesByType("resource");
      } catch (e) {
        return void this._disposeTimingMonitor();
      }
      for (let t = 0; t < e.length; ++t) {
        const n = e[t];
        for (let e = 0; e < Is.length; ++e) {
          const { id: t, pattern: r } = Is[e];
          null != this[Xs] &&
            !this[Xs][e] &&
            Ks(r, n.name) &&
            ((this[Xs][e] = !0),
            this.facade.onScriptResourceTiming(`dvbs-${t}`, n));
        }
      }
      null != this[Xs] &&
        this[Xs].every(Boolean) &&
        this._disposeTimingMonitor();
    }
    $super$1(e) {
      return super[e];
    }
  }
  class Js extends zs {
    start(e) {
      return new Promise(
        function (t, n) {
          return (
            void 0 === e && (e = Hr),
            Promise.resolve(this.$super$1("start").call(this)).then(
              function (r) {
                try {
                  return Promise.resolve(this.facade.creative.reach(1)).then(
                    function (r) {
                      try {
                        return Promise.resolve(this._insertScript(e)).then(
                          function (e) {
                            try {
                              return t();
                            } catch (e) {
                              return n(e);
                            }
                          },
                          n
                        );
                      } catch (e) {
                        return n(e);
                      }
                    }.bind(this),
                    n
                  );
                } catch (e) {
                  return n(e);
                }
              }.bind(this),
              n
            )
          );
        }.bind(this)
      );
    }
    _getDelimiter(e) {
      return "#";
    }
    _getScriptUri(e) {
      if ("1" === e.falcon) return super._getFalconUri(e);
      if (null == e.proxy) return Cs;
      if (null != e.static) return `${e.static}/${Es}`;
      const t = e.dvmver;
      return null != t ? `${Ps}/advm/${t}/${Es}` : `${Ps}/${Es}`;
    }
    $super$1(e) {
      return super[e];
    }
  }
  var eo = (e) => new (e.blockingEnabled ? Zs : Js)(e);
  const to = Symbol("logger"),
    no = Symbol("config"),
    ro = Symbol("proxy"),
    io = Symbol("mode"),
    so = Symbol("decision"),
    oo = Symbol("createMode"),
    ao = Symbol("timedOut"),
    lo = Symbol("creativeState");
  class uo {
    constructor(e) {
      void 0 === e && (e = eo),
        (this[lo] = new Ns("dvf-creative")),
        (this[so] = yr()),
        (this[oo] = e),
        (this[io] = null),
        (this[ao] = !1),
        (this.start = Gr(this.start)),
        (this._determineDecision = Gr(this._determineDecision)),
        (this.dispose = Gr(this.dispose));
    }
    get logger() {
      return this[to];
    }
    get blockingEnabled() {
      return "1" === this[no].blk;
    }
    get dryRun() {
      return "1" === this[no].dry;
    }
    get timedOut() {
      return this[ao];
    }
    set timedOut(e) {
      this[ao] = e;
    }
    get creative() {
      return this[lo];
    }
    get config() {
      return this[no];
    }
    get proxy() {
      return this[ro];
    }
    start(e, t) {
      return new Promise(
        function (n, r) {
          (this[ro] = t), (this[no] = this._createMeasurementModeConfig(e));
          var i = function () {
              try {
                return n();
              } catch (e) {
                return r(e);
              }
            },
            s = function (e) {
              try {
                return (
                  this[so].reject(e), this[so].promise.catch(() => {}), i()
                );
              } catch (e) {
                return r(e);
              }
            }.bind(this);
          try {
            return (
              (this[io] = this[oo](this)),
              Promise.resolve(this[io].start()).then(function (e) {
                try {
                  return i();
                } catch (e) {
                  return s(e);
                }
              }, s)
            );
          } catch (e) {
            s(e);
          }
        }.bind(this)
      );
    }
    decide() {
      return new Promise(
        function (e, t) {
          return null == this[io]
            ? t(new Error("Not started yet"))
            : (this._awaitAndResolveDecision(), e(this[so].promise));
        }.bind(this)
      );
    }
    decideWithTimeout() {
      return new Promise(
        function (e, t) {
          return null == this[io]
            ? t(new Error("Not started yet"))
            : (this[io].enableDecisionTimeout(), e(this.decide()));
        }.bind(this)
      );
    }
    onStartCreativeLoad(e) {
      null != this[io] && this[io].onStartCreativeLoad(e),
        this.creative.maybeSet(1);
    }
    onEndCreativeLoad() {
      this.creative.maybeSet(2);
    }
    onScriptResourceTiming(e, t) {
      const n = { 91: e },
        r = Ur(t),
        i = bi(r);
      this.track("timing", n, i);
    }
    dispose() {
      return new Promise(
        function (e, t) {
          if ((this.creative.maybeSet(3), null != this[io]))
            return Promise.resolve(this[io].dispose()).then(
              function (e) {
                try {
                  return (this[io] = null), n.call(this);
                } catch (e) {
                  return t(e);
                }
              }.bind(this),
              t
            );
          function n() {
            return e();
          }
          return n.call(this);
        }.bind(this)
      );
    }
    _awaitAndResolveDecision() {
      return new Promise(
        function (e, t) {
          let n;
          return Promise.resolve(this[io].decide()).then(
            function (r) {
              try {
                return (n = 1 !== r || this.dryRun), this[so].resolve(n), e();
              } catch (e) {
                return t(e);
              }
            }.bind(this),
            t
          );
        }.bind(this)
      );
    }
    _createMeasurementModeConfig(e) {
      const t = Object.assign({}, e, Ms);
      return null != e.dvtagver && (t.dvtagver = e.dvtagver), t;
    }
    track() {}
  }
  const co = Symbol("plugin"),
    ho = Symbol("disposed"),
    { slot: po, videoSlot: fo } = ls;
  class mo {
    constructor(e) {
      if (null == e) throw new Error("Must specify the plugin");
      (this[co] = e), (this[ho] = !1);
    }
    dispose() {
      this[ho] = !0;
    }
    getAdVolume() {
      return this._genericCall(
        "getAdVolume",
        () => this[co].host.getAdVolume(),
        -1
      );
    }
    getAdDuration() {
      return this._genericCall(
        "getAdDuration",
        () => this[co].host.getAdDuration(),
        -1
      );
    }
    subscribe() {
      for (var e = arguments.length, t = new Array(e), n = 0; n < e; n++)
        t[n] = arguments[n];
      return this._genericCall("subscribe", () =>
        this[co].host.subscribe(...t)
      );
    }
    unsubscribe() {
      for (var e = arguments.length, t = new Array(e), n = 0; n < e; n++)
        t[n] = arguments[n];
      return this._genericCall("unsubscribe", () =>
        this[co].host.unsubscribe(...t)
      );
    }
    getPlayer() {
      return this._genericCall("getPlayer", () => this[co][fo]);
    }
    getSlot() {
      return this._genericCall("getSlot", () => this[co][po]);
    }
    getPreviousEvents() {
      return this._genericCall(
        "getPreviousEvents",
        () =>
          this[co].runtime.hostInfo.publishedEvents.map((e) => {
            let { name: t } = e;
            return t;
          }),
        []
      );
    }
    _genericCall(e, t, n) {
      if ((void 0 === n && (n = void 0), this[ho]));
      else
        try {
          return t();
        } catch (e) {}
      return n;
    }
  }
  const go = Symbol("dvFacade"),
    vo = Symbol("videoSlotOriginalPoster"),
    { slot: yo, videoSlot: bo } = ls,
    _o = Symbol("domEventTracker"),
    wo = Symbol("initialVideoSource"),
    Ao = (e) => ("currentSrc" in e ? e.currentSrc : e.src),
    ko = [
      "dns",
      "tcpHandshake",
      "secureConnection",
      "response",
      "requestStartUntilResponseEnd",
    ],
    So = (e) =>
      null != e
        ? ko
            .map((t) => {
              return "number" == typeof (n = e[t]) ? n : "";
              var n;
            })
            .join(":")
        : "",
    Po = (e) =>
      e
        .map((e) => e.timings)
        .map(So)
        .join(","),
    Eo = (e) =>
      new Promise((t, n) => {
        const r = new XMLHttpRequest();
        (r.onload = () => {
          if (r.status < 200 || r.status >= 300)
            n(new Error(`HTTP ${r.status}`));
          else {
            const e = r.status,
              n = ((e) => {
                const t = {};
                let n = null;
                try {
                  n = e.getResponseHeader("content-type");
                } catch (e) {}
                return null != n && (t["content-type"] = n), t;
              })(r),
              i = ((e) => ({ text: e.responseText, xml: e.responseXML }))(r);
            t({ statusCode: e, headers: n, body: i });
          }
        }),
          (r.onerror = () => {
            n(new Error("Unknown error"));
          }),
          r.open("GET", e),
          r.send();
      });
  class Co extends Cr {
    constructor(e, t, n) {
      super(e), (this.vastUrl = t), (this.wrapperCount = n);
    }
  }
  const xo = (e, t) =>
      Array.prototype.find.call(e.childNodes, (e) => e.localName === t),
    To = (e, t) =>
      new Promise(function (n, r) {
        let i;
        var s;
        function o() {
          if (!(null != e && i++ < 5)) return [1];
          {
            let s, a;
            (s = { url: e }), t.push(s), (s.startTime = ei());
            var n = function (t) {
              try {
                throw new Co(t.message, e, i);
              } catch (e) {
                return r(e);
              }
            };
            try {
              return Promise.resolve(
                ((e) =>
                  new Promise(function (t, n) {
                    let r, i;
                    return Promise.resolve(Eo(e)).then(function (e) {
                      try {
                        if (
                          (({
                            headers: r,
                            body: { xml: i },
                          } = e),
                          null == i ||
                            null == i.documentElement ||
                            "VAST" !== i.documentElement.localName)
                        ) {
                          let e;
                          return (
                            (e = r["content-type"] || "unknown"),
                            n(new Error(`Invalid response: ${e}`))
                          );
                        }
                        return t(i);
                      } catch (e) {
                        return n(e);
                      }
                    }, n);
                  }))(e)
              ).then(function (t) {
                try {
                  return (
                    (a = t),
                    (function () {
                      try {
                        (s.endTime = ei()), (s.timings = Br(e));
                        try {
                          e = ((e) => {
                            const t = xo(e.documentElement, "Ad");
                            if (null == t) throw new Error("No ads");
                            if (null != xo(t, "InLine")) return null;
                            const n = xo(t, "Wrapper");
                            if (null == n)
                              throw new Error("No InLine or Wrapper");
                            const r = xo(n, "VASTAdTagURI");
                            if (null == r) throw new Error("No VASTAdTagURI");
                            return r.textContent.trim();
                          })(a);
                        } catch (t) {
                          throw new Co(t.message, e, i);
                        }
                        return o;
                      } catch (e) {
                        return r(e);
                      }
                    })()
                  );
                } catch (e) {
                  return n(e);
                }
              }, n);
            } catch (e) {
              n(e);
            }
          }
        }
        return (
          (i = 0),
          (s = function (e) {
            for (; e; ) {
              if (e.then) return void e.then(s, r);
              try {
                if (e.pop) {
                  if (e.length) return e.pop() ? a.call(this) : e;
                  e = o;
                } else e = e.call(this);
              } catch (e) {
                return r(e);
              }
            }
          }.bind(this))(o)
        );
        function a() {
          return null != e ? r(new Co("Wrapper limit exceeded", e, i)) : n();
        }
      }),
    Oo = 9,
    Io = 102,
    Mo = 9;
  ms.register(
    class extends ds {
      static get id() {
        return "dv";
      }
      static get defaultConfig() {
        return { falcon: "0", mon: "1", blk: "0" };
      }
      constructor() {
        super(),
          (this[go] = new uo()),
          (this[go].track = this.track.bind(this));
      }
      init() {
        this[go].start(this.config, new mo(this));
      }
      dispose() {
        return this[go].dispose();
      }
      beforeInitAd(e, t, n, r, i, s) {
        return new Promise(
          function (e, t) {
            const { slot: n, videoSlot: r } = s;
            return (
              (this[yo] = n),
              (this[bo] = r),
              (this[vo] = null != r ? r.poster : null),
              this[go].onStartCreativeLoad(this[bo]),
              this._awaitAndHandleBlockDecision(),
              e()
            );
          }.bind(this)
        );
      }
      beforeAdLoaded() {
        return new Promise(
          function (e, t) {
            let n;
            return (
              this[go].onEndCreativeLoad(),
              Promise.resolve(this[go].decideWithTimeout()).then(function (r) {
                try {
                  return (n = r), n ? e() : t(new Error("Ad blocked"));
                } catch (e) {
                  return t(e);
                }
              }, t)
            );
          }.bind(this)
        );
      }
      _awaitAndHandleBlockDecision() {
        return new Promise(
          function (e, t) {
            let n, r, i, s;
            return (
              this.runtime.tracking.addMetric(118, () => this[go].config.blkto),
              (n = Bi()),
              this.runtime.tracking.addMetric(119, () => n),
              Promise.resolve(this[go].decide()).then(
                function (n) {
                  try {
                    if (
                      ((r = n),
                      (i = Bi()),
                      this.runtime.tracking.addMetric(120, () => i),
                      (s = this[go].timedOut ? "timeout" : "decision"),
                      this.track(
                        r ? "dv-res-allow" : "dv-res-block",
                        { 197: s },
                        null
                      ),
                      r)
                    )
                      null != this[bo] &&
                        this[bo].poster === As &&
                        (this[bo].poster = this[vo]);
                    else {
                      let e, t;
                      (e = "Ad blocked"),
                        (t = { message: e }),
                        this.publish(be.AdError, [e, t]);
                    }
                    return e();
                  } catch (e) {
                    return t(e);
                  }
                }.bind(this),
                t
              )
            );
          }.bind(this)
        );
      }
    }
  ),
    ms.register(
      class extends ds {
        constructor() {
          super(), (this[_o] = new Pr()), (this[wo] = null);
        }
        static get id() {
          return "quirk.early-start";
        }
        beforeInitAd(e, t, n, r, i, s) {
          return new Promise(
            function (e, t) {
              if (null == s) return e();
              const { videoSlot: n } = s;
              if (null == n) return e();
              this[wo] = Ao(n);
              const r = this._preventEarlyPlayback.bind(this);
              return (
                this[_o].addMany(n, {
                  loadedmetadata: r,
                  loadeddata: r,
                  canplay: r,
                  canplaythrough: r,
                  playing: r,
                }),
                e()
              );
            }.bind(this)
          );
        }
        beforeStartAd() {
          this[_o].removeAll();
        }
        dispose() {
          super.dispose(), this[_o].removeAll();
        }
        _preventEarlyPlayback() {
          const { videoSlot: e } = this.runtime.hostInfo;
          !e.paused && this._hasVideoSourceChanged() && e.pause();
        }
        _hasVideoSourceChanged() {
          const { videoSlot: e } = this.runtime.hostInfo;
          return Ao(e) !== this[wo];
        }
      }
    ),
    ms.register(
      class extends ds {
        static get id() {
          return "unwrapper-benchmark";
        }
        init() {
          return new Promise(
            function (e, t) {
              return (
                (this._vastUrl = this.config.vastUrl),
                (this._strategies = this.config.strategies),
                (this._dimensions = { [Oo]: "warmup", [Io]: this._vastUrl }),
                (this._metrics = { [Mo]: this.config.originChainLength }),
                this._runStrategies(),
                e()
              );
            }.bind(this)
          );
        }
        _runStrategies() {
          return new Promise(
            function (e, t) {
              let n;
              (n = this._strategies.slice()),
                ((e) => {
                  for (let t = e.length - 1; t > 0; --t) {
                    const n = Math.floor(Math.random() * t),
                      r = e[t];
                    (e[t] = e[n]), (e[n] = r);
                  }
                })(n);
              var r = function () {
                  try {
                    return this._trackBenchmarkSuccess(), e();
                  } catch (e) {
                    return t(e);
                  }
                }.bind(this),
                i = function (n) {
                  try {
                    return e();
                  } catch (e) {
                    return t(e);
                  }
                };
              try {
                return Promise.resolve(
                  Promise.all(n.map(this._runStrategy.bind(this)))
                ).then(function (e) {
                  try {
                    return r();
                  } catch (e) {
                    return i();
                  }
                }, i);
              } catch (e) {
                i();
              }
            }.bind(this)
          );
        }
        _runStrategy(e) {
          return new Promise(
            function (t, n) {
              let r;
              (r = this._buildVastUrl(e)), (e.chain = []);
              var i = function () {
                  try {
                    var i = function (t) {
                      try {
                        throw (this._trackBenchmarkError(e.name, t), t);
                      } catch (e) {
                        return n(e);
                      }
                    }.bind(this);
                    try {
                      let s;
                      return (
                        (s = ei()),
                        Promise.resolve(To(r, e.chain)).then(function (r) {
                          try {
                            return (
                              (e.totalTime = ei() - s),
                              (function () {
                                try {
                                  return t();
                                } catch (e) {
                                  return n(e);
                                }
                              })()
                            );
                          } catch (e) {
                            return i(e);
                          }
                        }, i)
                      );
                    } catch (e) {
                      i(e);
                    }
                  } catch (e) {
                    return n(e);
                  }
                }.bind(this),
                s = function (e) {
                  try {
                    return i();
                  } catch (e) {
                    return n(e);
                  }
                };
              try {
                return Promise.resolve(this._warmUp(r)).then(function (e) {
                  try {
                    return i();
                  } catch (e) {
                    return s();
                  }
                }, s);
              } catch (e) {
                s();
              }
            }.bind(this)
          );
        }
        _buildVastUrl(e) {
          if (null == e.endpoint) return this._vastUrl;
          const t = encodeURIComponent(this._vastUrl);
          return `https://${e.endpoint}/1?t=vast&src=${t}`;
        }
        _warmUp(e) {
          return new Promise(function (t, n) {
            let r;
            return (
              (r = ((e) => {
                const t = e.indexOf("//");
                if (t < 0) return null;
                const n = e.indexOf("/", t + 2);
                return n < 0 ? e : e.substr(0, n);
              })(e)),
              Promise.resolve(Eo(r)).then(function (e) {
                try {
                  return t();
                } catch (e) {
                  return n(e);
                }
              }, n)
            );
          });
        }
        _trackBenchmarkSuccess() {
          for (let e = 0; e < this._strategies.length; ++e) {
            const t = 10 * (e + 1),
              n = this._strategies[e];
            this._addSuccessDimensions(t, n), this._addSuccessMetrics(t, n);
          }
          this.track("benchmark-end", this._dimensions, this._metrics, !0);
        }
        _trackBenchmarkError(e, t) {
          (this._dimensions[10] = e),
            (this._dimensions[110] = Ni(t)),
            null != t.vastUrl &&
              ((this._dimensions[102] = Rr(t.vastUrl)),
              (this._metrics[8] = t.wrapperCount)),
            this.track("benchmark-error", this._dimensions, this._metrics, !0);
        }
        _addSuccessDimensions(e, t) {
          let { name: n, chain: r } = t;
          Object.assign(this._dimensions, {
            [e]: n,
            [e + 1]: r.map((e) => e.endTime - e.startTime).join(","),
            [e + 2]: r.map((e) => Rr(e.url)).join(","),
            [e + 3]: Po(r),
          });
        }
        _addSuccessMetrics(e, t) {
          let { chain: n, totalTime: r } = t;
          Object.assign(this._metrics, { [e]: r, [e + 1]: n.length });
          const i = n[0].timings;
          if (null != i)
            for (let t = 0; t < ko.length; ++t) {
              const n = i[ko[t]];
              "number" == typeof n && (this._metrics[e + 2 + t] = n);
            }
        }
      }
    );
  const Vo = "[debug] ",
    jo = Object.keys(ke);
  class Fo extends ds {
    static get id() {
      return "debug";
    }
  }
  const Lo = (e) => {
      const t = si(e),
        n = `before${t}`,
        r = `after${t}`;
      Object.assign(Fo.prototype, {
        [n]: function () {
          var e = arguments;
          return new Promise(function (t, r) {
            for (var i = e.length, s = new Array(i), o = 0; o < i; o++)
              s[o] = e[o];
            return console.log(`${Vo}${n}`, ...s), t();
          });
        },
        [r]: function () {
          var e = arguments;
          return new Promise(function (t, n) {
            for (var i = e.length, s = new Array(i), o = 0; o < i; o++)
              s[o] = e[o];
            return s.pop(), console.log(`${Vo}${r}`, ...s), t();
          });
        },
      });
    },
    Ro = (e) => {
      for (let t = 0; t < e.length; ++t) Lo(e[t]);
    };
  Ro(Object.keys(we).map((e) => we[e])),
    Ro(Object.keys(be).map((e) => be[e])),
    Ro(jo.map((e) => "set" + si(e)));
  for (let e = 0; e < jo.length; ++e) {
    const t = jo[e],
      n = "afterGet" + si(t);
    let r;
    Fo.prototype[n] = function () {
      var e;
      const n =
        (e = arguments.length - 1) < 0 || arguments.length <= e
          ? void 0
          : arguments[e];
      r !== n && (console.log(`${Vo}${t}:`, r, "→", n), (r = n));
    };
  }
  ms.register(Fo);
  const Do = Symbol("play"),
    $o = Symbol("skip"),
    No = Symbol("interval"),
    Uo = {
      position: "absolute",
      bottom: "10%",
      right: "0px",
      padding: "12px",
      "z-index": "10000001",
      "background-color": "rgba(0, 0, 0, 0.7)",
      color: "white",
      "font-size": "12px",
      "font-weight": "200",
      "font-family": "Arial, Helvetica, sans-serif",
      "border-color": "rgba(255, 255, 255, 0.5)",
      "border-width": "0px",
      "border-style": "solid",
      cursor: "default",
      "user-select": "none",
    },
    Bo = Object.assign({}, Uo, {
      "font-size": "18px",
      "border-width": "1px 0px 1px 1px",
      cursor: "pointer",
    });
  ms.register(
    class extends ds {
      constructor() {
        super(), (this[Do] = null);
      }
      static get id() {
        return "play";
      }
      _createPlay(e) {
        const t = e.ownerDocument || document,
          n = hr(
            t,
            "svg",
            { width: "100%", height: "100%", viewBox: "0 0 100 100" },
            {
              display: "none",
              position: "absolute",
              "z-index": "10000001",
              "background-color": "rgba(0, 0, 0, 0.3)",
              cursor: "pointer",
            },
            !0
          ),
          r = hr(
            t,
            "circle",
            {
              cx: "50%",
              cy: "50%",
              r: "25%",
              fill: "none",
              stroke: "white",
              "stroke-width": "2px",
            },
            !0
          );
        n.appendChild(r);
        const i = hr(
          t,
          "polygon",
          { points: "45,40,45,60,60,50", fill: "white" },
          !0
        );
        n.appendChild(i),
          (this[Do] = n),
          e.appendChild(n),
          n.addEventListener("click", () => {
            this.host.resumeAd();
          });
      }
      _isEnabled() {
        const { acceptMedia: e } = this.config,
          { type: t } = this.runtime.guestInfo.mediaFile;
        let n = !0;
        if ("string" == typeof e && "string" == typeof t)
          try {
            n = new RegExp(e).test(t);
          } catch (e) {}
        return n;
      }
      beforeInitAd(e, t, n, r, i, s) {
        return new Promise(
          function (e, t) {
            return this._isEnabled() && this._createPlay(s.slot), e();
          }.bind(this)
        );
      }
      afterAdPaused() {
        return new Promise(
          function (e, t) {
            return (
              null !== this[Do] && dr(this[Do], { display: "block" }, !0), e()
            );
          }.bind(this)
        );
      }
      beforeAdPlaying() {
        return new Promise(
          function (e, t) {
            return (
              null !== this[Do] && dr(this[Do], { display: "none" }, !0), e()
            );
          }.bind(this)
        );
      }
    }
  ),
    ms.register(
      class extends ds {
        constructor() {
          super(), (this[$o] = null), (this[No] = null);
        }
        static get id() {
          return "skip";
        }
        _createSkip(e) {
          const t = (e.ownerDocument || document).createElement("div");
          t.addEventListener("click", () => this._maybeSkip()),
            (this[$o] = t),
            this._updateSkip(),
            e.appendChild(t);
        }
        _updateSkip() {
          const e = this._getSkipTimeRemaining(),
            t = !isNaN(e) || this.host.getAdSkippableState();
          dr(this[$o], { display: t ? "block" : "none" }, !0);
          const n = e > 0;
          let r = "Skip ad";
          n &&
            (r = "You can skip to video in [T]".replace(
              "[T]",
              "" + Math.round(e)
            )),
            this[$o].innerHTML !== r && (this[$o].innerHTML = r),
            dr(this[$o], n ? Uo : Bo, !0);
        }
        _resolveSkipOffset() {
          const { skipOffset: e } = this.runtime.config;
          if (null == e) return NaN;
          const t = "number" == typeof e ? e : Zr(e, this.host.getAdDuration());
          return "number" != typeof t ? NaN : t;
        }
        _getSkipTimeRemaining() {
          const e = this.host.getAdDuration(),
            t = this.host.getAdRemainingTime();
          return e < 0 || t < 0
            ? NaN
            : this._resolveSkipOffset() - Math.max(e - t, 0);
        }
        _maybeSkip() {
          return new Promise(
            function (e, t) {
              return this._getSkipTimeRemaining() > 0
                ? e()
                : !0 === this.guest.getAdSkippableState()
                ? (this.host.skipAd(), n.call(this))
                : Promise.resolve(this.publish("AdSkipped")).then(
                    function (e) {
                      try {
                        return this.host.stopAd(), n.call(this);
                      } catch (e) {
                        return t(e);
                      }
                    }.bind(this),
                    t
                  );
              function n() {
                return e();
              }
            }.bind(this)
          );
        }
        _isEnabled() {
          const { acceptMedia: e } = this.config;
          return (
            null == e ||
            ("string" == typeof e &&
              null !=
                this.runtime.guestInfo.mediaFile.type.match(new RegExp(e)))
          );
        }
        beforeInitAd(e, t, n, r, i, s) {
          return new Promise(
            function (e, t) {
              return (
                this._isEnabled() &&
                  (this._createSkip(s.slot),
                  (this[No] = setInterval(() => this._updateSkip(), 250))),
                e()
              );
            }.bind(this)
          );
        }
        afterAdSkippableStateChange() {
          return new Promise(
            function (e, t) {
              return this._isEnabled() && this._updateSkip(), e();
            }.bind(this)
          );
        }
        beforeAdStopped() {
          return new Promise(
            function (e, t) {
              return (
                null !== this[No] &&
                  (clearInterval(this[No]), (this[No] = null)),
                e()
              );
            }.bind(this)
          );
        }
      }
    ),
    ms.register(
      class extends ds {
        static get id() {
          return "vast-chain-tracking";
        }
        constructor() {
          super(), (this._fetchStartTime = 0);
        }
        setConfig(e) {
          super.setConfig(e);
          const { vastChainInfo: t } = e;
          null != t && this.hostInfo.addAdParamsVastChainInfo(t);
        }
        beforeLoadVast() {
          this._fetchStartTime = ei();
        }
        afterLoadVast(e) {
          let { uri: t } = e;
          const n = ei() - this._fetchStartTime;
          this.hostInfo.addVastChainInfo("vast", t, n, !1);
        }
        afterLoadVpaid(e) {
          let { uri: t, time: n } = e;
          this.hostInfo.addVastChainInfo("vpaid", t, n, !1);
        }
      }
    );
  class zo extends Cr {
    constructor(e, t) {
      super(`HTTP ${e}` + (null != t && "" !== t ? `: ${t}` : "")),
        (this.status = e),
        (this.statusText = t),
        (this.$type = "HTTPError");
    }
  }
  class Wo {
    _contents = [];
    get length() {
      return this._contents.length;
    }
    add(e) {
      this._contents.push(e),
        this._contents.sort((e, t) => (e.sequence || 0) - (t.sequence || 0));
    }
    remove(e) {
      let t = this._contents.indexOf(e);
      for (; t >= 0; )
        this._contents.splice(t, 1), (t = this._contents.indexOf(e, t));
    }
    get(e) {
      return this._contents[e];
    }
    clear() {
      this._contents.length = 0;
    }
    [Symbol.iterator]() {
      const e = this;
      let t = 0;
      return {
        next: () =>
          t < e.length
            ? { value: e.get(t++), done: !1 }
            : { value: void 0, done: !0 },
      };
    }
    toArray() {
      return this._contents.slice();
    }
    get $type() {
      return "SortedList";
    }
  }
  class qo {
    sequence = null;
  }
  class Ho extends qo {
    _impressions = [];
    _errors = [];
    _verifications = [];
    _extensions = [];
    _creatives = (() => new Wo())();
    id = null;
    conditionalAd = !1;
    adSystem = null;
    pricing = null;
    viewableImpression = null;
    get impressions() {
      return this._impressions;
    }
    get errors() {
      return this._errors;
    }
    get verifications() {
      return this._verifications;
    }
    get extensions() {
      return this._extensions;
    }
    get creatives() {
      return this._creatives;
    }
  }
  class Go extends Ho {
    _categories = [];
    _surveys = [];
    adTitle = null;
    description = null;
    advertiser = null;
    get categories() {
      return this._categories;
    }
    get surveys() {
      return this._surveys;
    }
    get $type() {
      return "InLine";
    }
  }
  class Qo extends Ho {
    followAdditionalWrappers = !0;
    allowMultipleAds = !1;
    fallbackOnNoAd = !1;
    vastAdTagURI = null;
    get $type() {
      return "Wrapper";
    }
  }
  class Yo {
    _clickTrackings = [];
    clickThrough = null;
    get clickTrackings() {
      return this._clickTrackings;
    }
  }
  class Xo extends Yo {
    get $type() {
      return "IconClicks";
    }
  }
  class Ko extends Yo {
    _customClicks = [];
    get customClicks() {
      return this._customClicks;
    }
    get $type() {
      return "VideoClicks";
    }
  }
  class Zo {
    version = null;
    name = null;
    get $type() {
      return "AdSystem";
    }
  }
  class Jo {
    authority = null;
    code = null;
    get $type() {
      return "Category";
    }
  }
  class ea {
    id = null;
    uri = null;
    get $type() {
      return "Click";
    }
  }
  class ta extends qo {
    _extensions = [];
    id = null;
    adID = null;
    apiFramework = null;
    universalAdId = null;
    linear = null;
    companionAds = null;
    nonLinearAds = null;
    get extensions() {
      return this._extensions;
    }
    get $type() {
      return "Creative";
    }
  }
  class na {
    _viewTrackings = [];
    program = null;
    width = null;
    height = null;
    xPosition = null;
    yPosition = null;
    duration = null;
    offset = null;
    apiFramework = null;
    pxratio = null;
    resource = null;
    resources = null;
    clicks = null;
    get viewTrackings() {
      return this._viewTrackings;
    }
    get $type() {
      return "Icon";
    }
  }
  class ra {
    id = null;
    uri = null;
    get $type() {
      return "Impression";
    }
  }
  class ia {
    type = null;
    apiFramework = null;
    uri = null;
    get $type() {
      return "InteractiveCreativeFile";
    }
  }
  class sa {
    delivery = null;
    type = null;
    width = null;
    height = null;
    codec = null;
    id = null;
    bitrate = null;
    minBitrate = null;
    maxBitrate = null;
    scalable = !1;
    maintainAspectRatio = !1;
    apiFramework = null;
    uri = null;
    get $type() {
      return "MediaFile";
    }
  }
  class oa {
    model = null;
    currency = null;
    value = null;
    get $type() {
      return "Pricing";
    }
  }
  class aa {
    type = null;
    uri = null;
    get $type() {
      return "Survey";
    }
  }
  class la {
    uri = null;
    offset = null;
    get $type() {
      return "TrackingEvent";
    }
  }
  class ua {
    _map = (() => Object.create(null))();
    get types() {
      return Object.keys(this._map);
    }
    get(e) {
      return this._map[e] || [];
    }
    add(e, t) {
      (this._map[e] = this._map[e] || []), this._map[e].push(t);
    }
    get $type() {
      return "TrackingEvents";
    }
  }
  class ca {
    idRegistry = "unknown";
    idValue = "unknown";
    creativeIdentifier = null;
    get $type() {
      return "UniversalAdId";
    }
  }
  class da {
    _ads = (() => new Wo())();
    adPod = null;
    get ads() {
      return this._ads;
    }
    get $type() {
      return "AdBuffet";
    }
  }
  class ha extends da {
    _errors = [];
    uri = null;
    version = null;
    get errors() {
      return this._errors;
    }
    get $type() {
      return "VAST";
    }
  }
  class pa {
    _javaScriptResources = [];
    _flashResources = [];
    vendor = null;
    viewableImpression = null;
    parameters = null;
    get javaScriptResources() {
      return this._javaScriptResources;
    }
    get flashResources() {
      return this._flashResources;
    }
    get $type() {
      return "Verification";
    }
  }
  class fa {
    _viewables = [];
    _notViewables = [];
    _viewUndetermineds = [];
    id = null;
    get viewables() {
      return this._viewables;
    }
    get notViewables() {
      return this._notViewables;
    }
    get viewUndetermineds() {
      return this._viewUndetermineds;
    }
    get $type() {
      return "ViewableImpression";
    }
  }
  class ma {
    _clickTrackings = [];
    id = null;
    width = null;
    height = null;
    assetWidth = null;
    assetHeight = null;
    expandedWidth = null;
    expandedHeight = null;
    apiFramework = null;
    adSlotID = null;
    pxratio = null;
    resource = null;
    adParameters = null;
    altText = null;
    clickThrough = null;
    trackingEvents = null;
    get clickTrackings() {
      return this._clickTrackings;
    }
    get $type() {
      return "Companion";
    }
  }
  class ga {
    _companions = [];
    required = null;
    xmlElement = null;
    get companions() {
      return this._companions;
    }
    get $type() {
      return "CompanionAds";
    }
  }
  class va {
    _mediaFiles = [];
    _interactiveCreativeFiles = [];
    _icons = [];
    skipoffset = null;
    duration = null;
    mezzanine = null;
    adParameters = null;
    videoClicks = null;
    trackingEvents = null;
    get mediaFiles() {
      return this._mediaFiles;
    }
    get interactiveCreativeFiles() {
      return this._interactiveCreativeFiles;
    }
    get icons() {
      return this._icons;
    }
    get $type() {
      return "Linear";
    }
  }
  class ya {
    _clickTrackings = [];
    id = null;
    width = null;
    height = null;
    expandedWidth = null;
    expandedHeight = null;
    scalable = !1;
    maintainAspectRatio = !1;
    minSuggestedDuration = null;
    apiFramework = null;
    resource = null;
    adParameters = null;
    clickThrough = null;
    get clickTrackings() {
      return this._clickTrackings;
    }
    get $type() {
      return "NonLinear";
    }
  }
  class ba {
    _nonLinears = [];
    trackingEvents = null;
    get nonLinears() {
      return this._nonLinears;
    }
    get $type() {
      return "NonLinearAds";
    }
  }
  class _a {
    type = null;
    xmlElement = null;
  }
  class wa extends _a {
    get $type() {
      return "CreativeExtension";
    }
  }
  class Aa extends _a {
    get $type() {
      return "Extension";
    }
  }
  class ka {
    uri = null;
  }
  class Sa extends ka {
    get $type() {
      return "HTMLResource";
    }
  }
  class Pa extends ka {
    get $type() {
      return "IFrameResource";
    }
  }
  class Ea extends ka {
    creativeType = null;
    get $type() {
      return "StaticResource";
    }
  }
  class Ca extends ka {
    apiFramework = null;
  }
  class xa extends Ca {
    get $type() {
      return "FlashResource";
    }
  }
  class Ta extends Ca {
    get $type() {
      return "JavaScriptResource";
    }
  }
  class Oa {
    value = null;
  }
  class Ia extends Oa {
    get $type() {
      return "AbsoluteTimeOffset";
    }
  }
  class Ma extends Oa {
    get $type() {
      return "RelativeTimeOffset";
    }
  }
  class Va {
    _ads = (() => new Wo())();
    get ads() {
      return this._ads;
    }
    get $type() {
      return "AdPod";
    }
  }
  class ja extends Cr {
    constructor(e, t) {
      super(e), (this.code = t), (this.name = "VASTParserError");
    }
  }
  class Fa {
    constructor(e) {
      this._strictMode = e;
    }
    failWithErrorCode(e, t) {
      if (e instanceof ja) throw e;
      throw new ja(e instanceof Error ? e.message : e, t);
    }
    fail(e) {
      this.failWithErrorCode(e, 101);
    }
    tryRecover(e) {
      this._strictMode && this.fail(e);
    }
  }
  var La = (e) => "string" == typeof e && e.length > 0,
    Ra = (e) => null != e && La(e._value),
    Da = (e) => Array.isArray(e) && e.length > 0;
  const $a = /^\s*(\d+):(\d+):(\d+(?:\.\d+)?)\s*$/;
  var Na = (e) => {
      if ("string" != typeof e) return null;
      const t = $a.exec(e);
      return null == t
        ? null
        : 60 * (60 * parseInt(t[1], 10) + parseInt(t[2], 10)) +
            parseFloat(t[3]);
    },
    Ua = (e, t) => {
      if ("%" === e.charAt(e.length - 1)) {
        const t = new Ma();
        return (t.value = parseFloat(e.substr(0, e.length - 1))), t;
      }
      {
        const n = new Ia();
        try {
          n.value = Na(e);
        } catch (e) {
          t.errorHandler.tryRecover(e);
        }
        return n;
      }
    },
    Ba = (e, t, n) => {
      if (null != e && Array.isArray(e.tracking))
        for (const r of e.tracking) {
          if (!La(r._value)) continue;
          const e = new la();
          if (((e.uri = r._value), La(r.offset)))
            try {
              e.offset = Ua(r.offset);
            } catch (e) {
              n.errorHandler.tryRecover(e);
            }
          t.add(r.event, e);
        }
    },
    za = (e) => {
      const t = new ea();
      return (t.id = e.id), (t.uri = e._value), t;
    },
    Wa = (e) =>
      null != e.staticResource
        ? ((e) => {
            const t = new Ea();
            return (t.creativeType = e.creativeType), (t.uri = e._value), t;
          })(e.staticResource)
        : null != e.iFrameResource
        ? ((e) => {
            const t = new Pa();
            return (t.uri = e._value), t;
          })(e.iFrameResource)
        : null != e.htmlResource
        ? ((e) => {
            const t = new Sa();
            return (t.uri = e._value), t;
          })(e.htmlResource)
        : null,
    qa = (e) => {
      const t = new ma();
      return (
        (t.id = e.id),
        (t.width = e.width),
        (t.height = e.height),
        (t.assetWidth = e.assetWidth),
        (t.assetHeight = e.assetHeight),
        (t.expandedWidth = e.expandedWidth),
        (t.expandedHeight = e.expandedHeight),
        (t.apiFramework = e.apiFramework),
        (t.adSlotID = e.adSlotID),
        (t.pxratio = e.pxratio),
        (t.resource = Wa(e)),
        null != e.adParameters &&
          Ra(e.adParameters) &&
          (t.adParameters = e.adParameters._value),
        null != e.altText &&
          Ra(e.altText._value) &&
          (t.altText = e.altText._value),
        null != e.companionClickThrough &&
          Ra(e.companionClickThrough) &&
          (t.clickThrough = za(e.companionClickThrough)),
        null != e.companionClickTracking &&
          t.clickTrackings.push(...e.companionClickTracking.filter(Ra).map(za)),
        null != e.trackingEvents &&
          Da(e.trackingEvents.tracking) &&
          ((t.trackingEvents = new ua()),
          Ba(e.trackingEvents, t.trackingEvents)),
        t
      );
    },
    Ha = (e) => {
      const t = new wa();
      return (t.type = e.type), (t.xmlElement = e._value), t;
    };
  const Ga = (e, t) => (null == e ? e : t.indexOf(e) < 0 ? parseInt(e, 0) : e);
  var Qa = (e) => {
      const t = new na();
      return (
        (t.program = e.program),
        (t.width = e.width),
        (t.height = e.height),
        (t.xPosition = Ga(e.xPosition, ["left", "right"])),
        (t.yPosition = Ga(e.yPosition, ["top", "bottom"])),
        (t.duration = e.duration),
        (t.offset = e.offset),
        (t.apiFramework = e.apiFramework),
        (t.pxratio = e.pxratio),
        (t.resources = Wa(e)),
        null != e.iconClicks &&
          (Ra(e.iconClicks.iconClickThrough) ||
            Da(e.iconClicks.iconClickTracking)) &&
          (t.clicks = ((e) => {
            const t = new Xo();
            return (
              null != e.iconClickThrough &&
                Ra(e.iconClickThrough) &&
                (t.clickThrough = za(e.iconClickThrough)),
              null != e.iconClickTracking &&
                t.clickTrackings.push(
                  ...e.iconClickTracking.filter(Ra).map(za)
                ),
              t
            );
          })(e.iconClicks)),
        null != e.iconViewTracking &&
          t.viewTrackings.push(...e.iconViewTracking.filter(Ra).map(za)),
        t
      );
    },
    Ya = (e) => {
      const t = new ia();
      return (
        (t.type = e.type),
        (t.apiFramework = e.apiFramework),
        (t.uri = e._value),
        t
      );
    },
    Xa = (e) => {
      const t = new sa();
      return (
        (t.id = e.id),
        (t.delivery = e.delivery),
        (t.type = e.type),
        (t.bitrate = e.bitrate),
        (t.minBitrate = e.minBitrate),
        (t.maxBitrate = e.maxBitrate),
        (t.width = e.width),
        (t.height = e.height),
        (t.scalable = e.scalable),
        (t.maintainAspectRatio = e.maintainAspectRatio),
        (t.codec = e.codec),
        (t.apiFramework = e.apiFramework),
        (t.uri = e._value),
        t
      );
    },
    Ka = (e) => {
      const t = new ya();
      return (
        (t.id = e.id),
        (t.width = e.width),
        (t.height = e.height),
        (t.expandedWidth = e.expandedWidth),
        (t.expandedHeight = e.expandedHeight),
        (t.scalable = e.scalable),
        (t.maintainAspectRatio = e.maintainAspectRatio),
        (t.minSuggestedDuration = e.minSuggestedDuration),
        (t.apiFramework = e.apiFramework),
        (t.resource = Wa(e)),
        null != e.adParameters && (t.adParameters = e.adParameters._value),
        null != e.nonLinearClickThrough &&
          Ra(e.nonLinearClickThrough) &&
          (t.clickThrough = za(e.nonLinearClickThrough)),
        null != e.nonLinearClickTracking &&
          t.clickTrackings.push(...e.nonLinearClickTracking.filter(Ra).map(za)),
        t
      );
    },
    Za = (e) => {
      const t = new Aa();
      return (t.type = e.type), (t.xmlElement = e._value), t;
    },
    Ja = (e) => {
      const t = new ra();
      return (t.id = e.id), (t.uri = e._value), t;
    },
    el = (e) => {
      const t = new xa();
      return (t.apiFramework = e.apiFramework), (t.uri = e._value), t;
    },
    tl = (e) => {
      const t = new Ta();
      return (t.apiFramework = e.apiFramework), (t.uri = e._value), t;
    };
  const nl = (e) => null != e && La(e._value);
  var rl = (e, t, n, r) => (
      (n.id = e.id),
      (n.conditionalAd = e.conditionalAd),
      (n.sequence = e.sequence),
      null != t.adSystem &&
        (n.adSystem = ((e) => {
          const t = new Zo();
          return (t.version = e.version), (t.name = e._value), t;
        })(t.adSystem)),
      null != t.impression &&
        n.impressions.push(...t.impression.filter(nl).map(Ja)),
      null != t.pricing &&
        (n.pricing = ((e) => {
          const t = new oa();
          return (
            (t.model = e.model),
            (t.currency = e.currency),
            (t.value = e._value),
            t
          );
        })(t.pricing)),
      null != t.error &&
        n.errors.push(...t.error.filter(nl).map((e) => e._value)),
      null != t.viewableImpression &&
        (n.viewableImpression = ((e) => {
          const t = new fa();
          return (
            (t.id = e.id),
            null != e.viewable &&
              t.viewables.push(...e.viewable.map((e) => e._value)),
            null != e.notViewable &&
              t.notViewables.push(...e.notViewable.map((e) => e._value)),
            null != e.viewUndetermined &&
              t.viewUndetermineds.push(
                ...e.viewUndetermined.map((e) => e._value)
              ),
            t
          );
        })(t.viewableImpression)),
      null != t.adVerifications &&
        t.adVerifications.verification.forEach((e) => {
          try {
            const t = ((e) => {
              const t = new pa();
              return (
                (t.vendor = e.vendor),
                null != e.javaScriptResource &&
                  t.javaScriptResources.push(...e.javaScriptResource.map(tl)),
                null != e.flashResource &&
                  t.flashResources.push(...e.flashResource.map(el)),
                null != e.viewableImpression &&
                  (t.viewableImpression = e.viewableImpression._value),
                null != e.verificationParameters &&
                  (t.parameters = e.verificationParameters._value),
                t
              );
            })(e);
            n.verifications.push(t);
          } catch (e) {
            r.errorHandler.tryRecover(e);
          }
        }),
      null != t.extensions &&
        n.extensions.push(...t.extensions.extension.map(Za)),
      null != t.creatives &&
        t.creatives.creative.forEach((e) => {
          try {
            const t = ((e, t) => {
              const n = new ta();
              return (
                (n.id = e.id),
                (n.sequence = e.sequence),
                (n.adID = e.AdID || e.adID || e.adId),
                (n.apiFramework = e.apiFramework),
                null != e.universalAdId &&
                  (n.universalAdId = ((e) => {
                    const t = new ca();
                    return (
                      null != e.idRegistry && (t.idRegistry = e.idRegistry),
                      null != e.idValue && (t.idValue = e.idValue),
                      (t.creativeIdentifier = e._value),
                      t
                    );
                  })(e.universalAdId)),
                null != e.creativeExtensions &&
                  e.creativeExtensions.creativeExtension &&
                  n.extensions.push(
                    ...e.creativeExtensions.creativeExtension.map(Ha)
                  ),
                null != e.linear
                  ? (n.linear = ((e, t) => {
                      const n = e.linear,
                        r = new va();
                      var i, s;
                      return (
                        La(n.skipoffset) &&
                          (r.skipoffset = Ua(n.skipoffset, t)),
                        null != n.duration && (r.duration = n.duration._value),
                        null != n.mediaFiles &&
                          (null != n.mediaFiles.mezzanine &&
                            (r.mezzanine = n.mediaFiles.mezzanine._value),
                          null != n.mediaFiles.mediaFile &&
                            r.mediaFiles.push(
                              ...n.mediaFiles.mediaFile.map(Xa)
                            ),
                          null != n.mediaFiles.interactiveCreativeFile &&
                            r.interactiveCreativeFiles.push(
                              ...n.mediaFiles.interactiveCreativeFile.map(Ya)
                            )),
                        null != n.adParameters &&
                          (r.adParameters = n.adParameters._value),
                        null != n.videoClicks &&
                          ((r.videoClicks = new Ko()),
                          (i = n.videoClicks),
                          (s = r.videoClicks),
                          null != i.clickThrough &&
                            Ra(i.clickThrough) &&
                            (s.clickThrough = za(i.clickThrough)),
                          null != i.clickTracking &&
                            s.clickTrackings.push(
                              ...i.clickTracking.filter(Ra).map(za)
                            ),
                          null != i.customClick &&
                            s.customClicks.push(
                              ...i.customClick.filter(Ra).map(za)
                            )),
                        null != n.trackingEvents &&
                          Da(n.trackingEvents.tracking) &&
                          ((r.trackingEvents = new ua()),
                          Ba(n.trackingEvents, r.trackingEvents, t)),
                        null != n.icons &&
                          n.icons.icon &&
                          r.icons.push(...n.icons.icon.map(Qa)),
                        r
                      );
                    })(e, t))
                  : null != e.nonLinearAds &&
                    (n.nonLinearAds = ((e) => {
                      const t = e.nonLinearAds,
                        n = new ba();
                      return (
                        null != t.nonLinear &&
                          n.nonLinears.push(...t.nonLinear.map(Ka)),
                        null != t.trackingEvents &&
                          Da(t.trackingEvents.tracking) &&
                          ((n.trackingEvents = new ua()),
                          Ba(t.trackingEvents, n.trackingEvents)),
                        n
                      );
                    })(e)),
                null != e.companionAds &&
                  (n.companionAds = ((e) => {
                    const t = e.companionAds,
                      n = new ga();
                    return (
                      (n.required = t.required),
                      null != t.companion &&
                        n.companions.push(...t.companion.map(qa)),
                      (n.xmlElement = t._value),
                      n
                    );
                  })(e)),
                null == n.linear &&
                  null == n.nonLinearAds &&
                  null == n.companionAds &&
                  t.errorHandler.tryRecover("Creative has no ads"),
                n
              );
            })(e, r);
            n.creatives.add(t);
          } catch (e) {
            r.errorHandler.tryRecover(e);
          }
        }),
      n
    ),
    il = (e) => {
      const t = new Jo();
      return (t.authority = e.authority), (t.code = e._value), t;
    },
    sl = (e) => {
      const t = new aa();
      return (t.type = e.type), (t.uri = e._value), t;
    },
    ol = (e, t) => {
      if (null != e.inLine)
        return ((e, t) => {
          const n = new Go(),
            r = e.inLine;
          return (
            rl(e, r, n, t),
            (n.adTitle = null != r.adTitle ? r.adTitle._value : null),
            null != r.category &&
              n.categories.push(
                ...r.category.filter((e) => null != e.authority).map(il)
              ),
            (n.description =
              null != r.description ? r.description._value : null),
            (n.advertiser = null != r.advertiser ? r.advertiser._value : null),
            null != r.survey &&
              n.surveys.push(
                ...r.survey.filter((e) => e._value.length > 0).map(sl)
              ),
            n
          );
        })(e, t);
      if (null != e.wrapper)
        return ((e, t) => {
          const n = new Qo(),
            r = e.wrapper;
          return (
            rl(e, r, n, t),
            null != r.followAdditionalWrappers &&
              (n.followAdditionalWrappers = r.followAdditionalWrappers),
            null != r.allowMultipleAds &&
              (n.allowMultipleAds = r.allowMultipleAds),
            (n.fallbackOnNoAd = r.fallbackOnNoAd),
            (n.vastAdTagURI =
              null != r.vastAdTagURI ? r.vastAdTagURI._value : null),
            n
          );
        })(e, t);
      throw new Error("Unrecognized ad type");
    },
    al = "b",
    ll = "i",
    ul = "f",
    cl = "t",
    dl = {
      collections: {
        AdVerifications: ["Verification"],
        Companion: ["CompanionClickTracking"],
        CompanionAds: ["Companion"],
        CreativeExtensions: ["CreativeExtension"],
        Creatives: ["Creative"],
        Extensions: ["Extension"],
        Icon: ["IconViewTracking"],
        IconClicks: ["IconClickTracking"],
        Icons: ["Icon"],
        InLine: ["Category", "Error", "Impression", "Survey"],
        MediaFiles: ["MediaFile", "InteractiveCreativeFile"],
        NonLinear: ["NonLinearClickTracking"],
        NonLinearAds: ["NonLinear"],
        TrackingEvents: ["Tracking"],
        VAST: ["Error", "Ad"],
        Verification: ["JavaScriptResource", "FlashResource"],
        ViewableImpression: ["Viewable", "NotViewable", "ViewUndetermined"],
        VideoClicks: ["ClickTracking", "CustomClick"],
        Wrapper: ["Impression", "Error"],
      },
      freeforms: {
        CreativeExtensions: ["CreativeExtension"],
        Extensions: ["Extension"],
      },
      hybrids: ["CompanionAds"],
      types: {
        Ad: { sequence: ll },
        AdParameters: { xmlEncoded: al },
        Companion: {
          width: ll,
          height: ll,
          expandedWidth: ll,
          expandedHeight: ll,
        },
        Creative: { sequence: ll },
        Duration: { _value: cl },
        Icon: { width: ll, height: ll, offset: cl, duration: cl },
        MediaFile: {
          bitrate: ll,
          minBitrate: ll,
          maxBitrate: ll,
          width: ll,
          height: ll,
          scalable: al,
          maintainAspectRatio: al,
        },
        NonLinear: {
          width: ll,
          height: ll,
          assetWidth: ll,
          assetHeight: ll,
          expandedWidth: ll,
          expandedHeight: ll,
          scalable: al,
          maintainAspectRatio: al,
          minSuggestedDuration: cl,
        },
        Pricing: { _value: "f" },
        Wrapper: {
          followAdditionalWrappers: al,
          allowMultipleAds: al,
          fallbackOnNoAd: al,
        },
      },
    },
    hl = {
      [al]: (e) => "true" === e || "1" === e,
      [ll]: (e) => parseInt(e, 10),
      [ul]: parseFloat,
      [cl]: Na,
    };
  const pl = (e) => (t) => t.nodeType === e,
    fl = pl(1),
    ml = pl(3),
    gl = pl(4),
    vl = (e, t) => Array.prototype.filter.call(e.childNodes, t),
    yl = (e) => ml(e) || gl(e),
    bl = (() => {
      const e = /^[A-Z]+/,
        t = (e) =>
          1 === e.length
            ? e.toLowerCase()
            : e.substr(0, e.length - 1).toLowerCase() + e.charAt(e.length - 1);
      return (n) => n.replace(e, t);
    })(),
    _l = (e, t, n) => null != e[t] && ~e[t].indexOf(n);
  class wl {
    constructor(e) {
      let { collections: t, freeforms: n, hybrids: r, types: i } = e;
      (this._collections = t),
        (this._freeforms = n),
        (this._hybrids = r),
        (this._types = i);
    }
    unmarshal(e) {
      return this._createNode(e);
    }
    _createNode(e) {
      const t = Object.create(null);
      return (
        (t._value = this._isHybrid(e.nodeName)
          ? e
          : this._convertPropertyValue(
              ((e) =>
                vl(e, yl)
                  .map((e) => e.nodeValue)
                  .join("")
                  .trim())(e),
              e.nodeName,
              "_value"
            )),
        this._copyAttributes(t, e),
        this._createCollections(t, e),
        this._createChildren(t, e),
        t
      );
    }
    _createFreeformNode(e) {
      const t = Object.create(null);
      return this._copyAttributes(t, e), (t._value = e), t;
    }
    _copyAttributes(e, t) {
      const n = t.nodeName;
      for (let r = 0; r < t.attributes.length; ++r) {
        const i = t.attributes[r],
          s = i.nodeName,
          o = i.nodeValue;
        e[s] = this._convertPropertyValue(o, n, s);
      }
    }
    _createCollections(e, t) {
      null != this._collections[t.nodeName] &&
        this._collections[t.nodeName].forEach((t) => {
          e[bl(t)] = [];
        });
    }
    _createChildren(e, t) {
      const n = t.nodeName;
      vl(t, fl).forEach((t) => {
        const r = t.nodeName,
          i = bl(r);
        this._isFreeformParent(n)
          ? this._isFreeformChild(n, r) && this._addFreeformChild(t, i, e)
          : this._addNodeChild(t, i, e, n, r);
      });
    }
    _addNodeChild(e, t, n, r, i) {
      const s = this._createNode(e);
      if (null == n[t]) n[t] = s;
      else {
        if (!this._isCollection(r, i))
          throw new Error(`Multiple values for ${r}.${i}`);
        n[t].push(s);
      }
    }
    _addFreeformChild(e, t, n) {
      (n[t] = n[t] || []), n[t].push(this._createFreeformNode(e));
    }
    _convertPropertyValue(e, t, n) {
      const r = null != this._types[t] ? this._types[t][n] : null;
      return null != r ? hl[r](e) : e;
    }
    _isCollection(e, t) {
      return _l(this._collections, e, t);
    }
    _isFreeformParent(e) {
      return null != this._freeforms[e];
    }
    _isFreeformChild(e, t) {
      return _l(this._freeforms, e, t);
    }
    _isHybrid(e) {
      return this._hybrids.indexOf(e) >= 0;
    }
  }
  const Al = { strict: !1, noSingleAdPods: !1 };
  var kl,
    Sl = { exports: {} },
    Pl =
      (kl ||
        ((kl = 1),
        (function (e) {
          var t = Object.prototype.hasOwnProperty,
            n = "~";
          function r() {}
          function i(e, t, n) {
            (this.fn = e), (this.context = t), (this.once = n || !1);
          }
          function s(e, t, r, s, o) {
            if ("function" != typeof r)
              throw new TypeError("The listener must be a function");
            var a = new i(r, s || e, o),
              l = n ? n + t : t;
            return (
              e._events[l]
                ? e._events[l].fn
                  ? (e._events[l] = [e._events[l], a])
                  : e._events[l].push(a)
                : ((e._events[l] = a), e._eventsCount++),
              e
            );
          }
          function o(e, t) {
            0 === --e._eventsCount
              ? (e._events = new r())
              : delete e._events[t];
          }
          function a() {
            (this._events = new r()), (this._eventsCount = 0);
          }
          Object.create &&
            ((r.prototype = Object.create(null)),
            new r().__proto__ || (n = !1)),
            (a.prototype.eventNames = function () {
              var e,
                r,
                i = [];
              if (0 === this._eventsCount) return i;
              for (r in (e = this._events))
                t.call(e, r) && i.push(n ? r.slice(1) : r);
              return Object.getOwnPropertySymbols
                ? i.concat(Object.getOwnPropertySymbols(e))
                : i;
            }),
            (a.prototype.listeners = function (e) {
              var t = n ? n + e : e,
                r = this._events[t];
              if (!r) return [];
              if (r.fn) return [r.fn];
              for (var i = 0, s = r.length, o = new Array(s); i < s; i++)
                o[i] = r[i].fn;
              return o;
            }),
            (a.prototype.listenerCount = function (e) {
              var t = n ? n + e : e,
                r = this._events[t];
              return r ? (r.fn ? 1 : r.length) : 0;
            }),
            (a.prototype.emit = function (e, t, r, i, s, o) {
              var a = n ? n + e : e;
              if (!this._events[a]) return !1;
              var l,
                u,
                c = this._events[a],
                d = arguments.length;
              if (c.fn) {
                switch (
                  (c.once && this.removeListener(e, c.fn, void 0, !0), d)
                ) {
                  case 1:
                    return c.fn.call(c.context), !0;
                  case 2:
                    return c.fn.call(c.context, t), !0;
                  case 3:
                    return c.fn.call(c.context, t, r), !0;
                  case 4:
                    return c.fn.call(c.context, t, r, i), !0;
                  case 5:
                    return c.fn.call(c.context, t, r, i, s), !0;
                  case 6:
                    return c.fn.call(c.context, t, r, i, s, o), !0;
                }
                for (u = 1, l = new Array(d - 1); u < d; u++)
                  l[u - 1] = arguments[u];
                c.fn.apply(c.context, l);
              } else {
                var h,
                  p = c.length;
                for (u = 0; u < p; u++)
                  switch (
                    (c[u].once && this.removeListener(e, c[u].fn, void 0, !0),
                    d)
                  ) {
                    case 1:
                      c[u].fn.call(c[u].context);
                      break;
                    case 2:
                      c[u].fn.call(c[u].context, t);
                      break;
                    case 3:
                      c[u].fn.call(c[u].context, t, r);
                      break;
                    case 4:
                      c[u].fn.call(c[u].context, t, r, i);
                      break;
                    default:
                      if (!l)
                        for (h = 1, l = new Array(d - 1); h < d; h++)
                          l[h - 1] = arguments[h];
                      c[u].fn.apply(c[u].context, l);
                  }
              }
              return !0;
            }),
            (a.prototype.on = function (e, t, n) {
              return s(this, e, t, n, !1);
            }),
            (a.prototype.once = function (e, t, n) {
              return s(this, e, t, n, !0);
            }),
            (a.prototype.removeListener = function (e, t, r, i) {
              var s = n ? n + e : e;
              if (!this._events[s]) return this;
              if (!t) return o(this, s), this;
              var a = this._events[s];
              if (a.fn)
                a.fn !== t ||
                  (i && !a.once) ||
                  (r && a.context !== r) ||
                  o(this, s);
              else {
                for (var l = 0, u = [], c = a.length; l < c; l++)
                  (a[l].fn !== t ||
                    (i && !a[l].once) ||
                    (r && a[l].context !== r)) &&
                    u.push(a[l]);
                u.length
                  ? (this._events[s] = 1 === u.length ? u[0] : u)
                  : o(this, s);
              }
              return this;
            }),
            (a.prototype.removeAllListeners = function (e) {
              var t;
              return (
                e
                  ? ((t = n ? n + e : e), this._events[t] && o(this, t))
                  : ((this._events = new r()), (this._eventsCount = 0)),
                this
              );
            }),
            (a.prototype.off = a.prototype.removeListener),
            (a.prototype.addListener = a.prototype.on),
            (a.prefixed = n),
            (a.EventEmitter = a),
            (e.exports = a);
        })(Sl)),
      Sl.exports),
    El = c(Pl);
  function Cl(e, t) {
    return (
      (t = t || {}),
      new Promise(function (n, r) {
        var i = new XMLHttpRequest(),
          s = [],
          o = [],
          a = {},
          l = function () {
            return {
              ok: 2 == ((i.status / 100) | 0),
              statusText: i.statusText,
              status: i.status,
              url: i.responseURL,
              text: function () {
                return Promise.resolve(i.responseText);
              },
              json: function () {
                return Promise.resolve(i.responseText).then(JSON.parse);
              },
              blob: function () {
                return Promise.resolve(new Blob([i.response]));
              },
              clone: l,
              headers: {
                keys: function () {
                  return s;
                },
                entries: function () {
                  return o;
                },
                get: function (e) {
                  return a[e.toLowerCase()];
                },
                has: function (e) {
                  return e.toLowerCase() in a;
                },
              },
            };
          };
        for (var u in (i.open(t.method || "get", e, !0),
        (i.onload = function () {
          i
            .getAllResponseHeaders()
            .replace(/^(.*?):[^\S\n]*([\s\S]*?)$/gm, function (e, t, n) {
              s.push((t = t.toLowerCase())),
                o.push([t, n]),
                (a[t] = a[t] ? a[t] + "," + n : n);
            }),
            n(l());
        }),
        (i.onerror = r),
        (i.withCredentials = "include" == t.credentials),
        t.headers))
          i.setRequestHeader(u, t.headers[u]);
        i.send(t.body || null);
      })
    );
  }
  const xl =
      "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",
    Tl = (e) => {
      let t = "",
        n = 0;
      do {
        const r = xl.indexOf(e.charAt(n++)),
          i = xl.indexOf(e.charAt(n++)),
          s = xl.indexOf(e.charAt(n++)),
          o = ((63 & r) << 2) | ((i >> 4) & 3),
          a = ((15 & i) << 4) | ((s >> 2) & 15),
          l = ((3 & s) << 6) | (63 & xl.indexOf(e.charAt(n++)));
        t +=
          String.fromCharCode(o) +
          (a ? String.fromCharCode(a) : "") +
          (l ? String.fromCharCode(l) : "");
      } while (n < e.length);
      return t;
    };
  var Ol = {
    100: "XML parsing error.",
    101: "VAST schema validation error.",
    102: "VAST version of response not supported.",
    200: "Trafficking error. Video player received an ad type that it was not expecting and/or cannot display.",
    201: "Video player expecting different linearity.",
    202: "Video player expecting different duration.",
    203: "Video player expecting different size.",
    300: "General Wrapper error.",
    301: "Timeout of VAST URI provided in Wrapper element, or of VAST URI provided in a subsequent Wrapper element.",
    302: "Wrapper limit reached, as defined by the video player. Too many Wrapper responses have been received with no InLine response.",
    303: "No ads VAST response after one or more Wrappers. Also includes number of empty VAST responses from fallback.",
    400: "General linear error. Video player is unable to display the linear ad.",
    401: "File not found. Unable to find Linear/MediaFile from URI.",
    402: "Timeout of MediaFile URI.",
    403: "Could not find MediaFile that is supported by this video player, based on the attributes of the MediaFile element.",
    405: "Problem displaying MediaFile.",
    406: "Mezzanine was required but not provided. Ad not served.",
    407: "Mezzanine is in the process of being downloaded for the first time. Download may take several hours. Ad will not be served until mezzanine is downloaded and transcoded.",
    408: "Conditional ad rejected.",
    409: "Interactive unit in the InteractiveCreativeFile node was not executed",
    410: "Verification unit in the Verification node was not executed.",
    411: "Mezzanine was provided as required, but file did not meet required specification. Ad not served.",
    500: "General NonLinearAds error.",
    501: "Unable to display NonLinear Ad because creative dimensions do not align with creative display area.",
    502: "Unable to fetch NonLinearAds/NonLinear resource.",
    503: "Could not find NonLinearresource with supported type.",
    600: "General CompanionAds error.",
    601: "Unable to display companion because creative dimensions do not fit within Companion display area.",
    602: "Unable to display Required Companion.",
    603: "Unable to fetch CompanionAds/Companion resource.",
    604: "Could not find Companion resource with supported type.",
    900: "Undefined error.",
    901: "General VPAID error.",
  };
  class Il extends Cr {
    constructor(e) {
      void 0 === e && (e = 900),
        super(`VAST error ${e}` + (e in Ol ? ": " + Ol[e] : "")),
        (this.code = e),
        (this.$type = "VASTError");
    }
  }
  class Ml extends Il {
    constructor(e, t, n) {
      void 0 === t && (t = null),
        void 0 === n && (n = null),
        super(e),
        (this.cause = t),
        (this.uri = n),
        (this.$type = "VASTLoaderError");
    }
  }
  const Vl = /^data:(.*?)(;\s*base64)?,(.*)/,
    jl = {
      maxDepth: 10,
      credentials: "omit",
      timeout: 1e4,
      noSingleAdPods: !1,
      prepareUri: (e) => e,
    };
  class Fl extends El {
    constructor(e, t, n) {
      super(),
        (this._uri = e),
        null != n
          ? ((this._root = n._root),
            (this._options = this._root._options),
            (this._depth = n._depth + 1))
          : ((this._root = this),
            (this._options = Object.assign({}, jl, t)),
            (this._depth = 1),
            (this._fetch = this._options.fetch || Fl.fetch || Cl));
    }
    load() {
      return this._load(this._uri).catch((e) => {
        throw (this._emit("error", { error: e }), e);
      });
    }
    _load(e) {
      return Promise.resolve()
        .then(() => {
          this._emit("willFetch", { uri: e });
          const t = Vl.exec(e);
          return null == t
            ? this._fetchUri(e)
            : this._parseDataUri(t[3], t[1], null != t[2]);
        })
        .then((t) => {
          let { headers: n, body: r } = t;
          this._emit("didFetch", { uri: e, headers: n, body: r }),
            this._emit("willParse", { uri: e, headers: n, body: r });
          const i = (function (e, t) {
            void 0 === t && (t = {}),
              ((t = Object.assign({}, Al, t)).errorHandler = new Fa(t.strict));
            const n = ((e, t) => (
                "string" == typeof e &&
                  (e = (t.domParser || new DOMParser()).parseFromString(
                    e,
                    "text/xml"
                  )),
                null != e.documentElement && (e = e.documentElement),
                e.getElementsByTagName("parsererror").length > 0 &&
                  t.errorHandler.failWithErrorCode("XML parsing error", 100),
                e
              ))(e, t),
              r = new wl(dl);
            try {
              return ((e, t) => {
                const n = new ha();
                (n.version = e.version),
                  n.errors.push(
                    ...e.error.map((e) => e._value).filter((e) => "" !== e)
                  );
                const [r, i] = ((e) => {
                  const t = [],
                    n = [];
                  for (let r = 0; r < e.length; ++r) {
                    const i = e[r];
                    void 0 !== i.sequence ? t.push(i) : n.push(i);
                  }
                  return [t, n];
                })(e.ad);
                if (r.length > 0)
                  if (t.noSingleAdPods && 1 === e.ad.length && 1 === r.length)
                    i.push(r[0]);
                  else {
                    n.adPod = new Va();
                    for (let e = 0; e < r.length; e++)
                      n.adPod.ads.add(ol(r[e], t));
                  }
                for (let e = 0; e < i.length; e++) n.ads.add(ol(i[e], t));
                return n;
              })(r.unmarshal(n), t);
            } catch (e) {
              t.errorHandler.fail(e);
            }
          })(r, { noSingleAdPods: this._options.noSingleAdPods });
          if (
            ((i.uri = e),
            this._emit("didParse", { uri: e, headers: n, body: r, vast: i }),
            0 === i.ads.length)
          )
            throw new Ml(303, null, e);
          const s = i.ads.get(0);
          return s instanceof Qo || "Wrapper" === s.$type
            ? this._loadWrapped(s.vastAdTagURI, i)
            : [i];
        });
    }
    _parseDataUri(e, t, n) {
      return { body: n ? Tl(e) : decodeURIComponent(e) };
    }
    _loadWrapped(e, t) {
      return Promise.resolve()
        .then(() => {
          const { maxDepth: t } = this._options;
          if (t > 0 && this._depth + 1 >= t) throw new Ml(302, null, e);
          return new Fl(e, null, this).load();
        })
        .then((e) => [t, ...e]);
    }
    _fetchUri(e) {
      const t = this._options.prepareUri(e),
        n = this._fetchWithCredentials(t),
        r = this._createTimeouter(n, t);
      return Promise.race([n, r])
        .then((e) => (r.cancel(), e))
        .catch((e) => {
          if ((r.cancel(), this._depth > 1)) throw new Ml(301, null, t);
          throw e;
        });
    }
    _fetchWithCredentials(e) {
      let { credentials: t } = this._options;
      return (
        "function" == typeof t && (t = t(e)),
        Array.isArray(t) || (t = [t]),
        t.reduce(
          (t, n) => t.catch(() => this._tryFetch(e, n)),
          Promise.reject(new Error())
        )
      );
    }
    _tryFetch(e, t) {
      return this._root
        ._fetch(e, { credentials: t })
        .then((t) => {
          if (!t.ok) {
            const n = new zo(t.status, t.statusText);
            throw new Ml(301, n, e);
          }
          return t.text().then((e) => ({ headers: t.headers, body: e }));
        })
        .catch((n) => {
          throw (
            (this._emit("fetchError", { uri: e, credentials: t, error: n }), n)
          );
        });
    }
    _createTimeouter(e, t) {
      const n = this._options.timeout;
      let r = null;
      const i = new Promise((e, i) => {
        r = setTimeout(() => {
          i(new Ml(301, null, t));
        }, n);
      });
      return (
        (i.cancel = () => {
          null != r && (clearTimeout(r), (r = null));
        }),
        i
      );
    }
    _emit() {
      this._root.emit(...arguments);
    }
  }
  Fl.fetch = void 0;
  const Ll = {
      visibility: "hidden",
      position: "absolute",
      left: 0,
      top: 0,
      width: 0,
      height: 0,
      margin: 0,
      padding: 0,
      border: 0,
    },
    Rl = /^https?:\/\//,
    Dl = (e) => {
      let t = null;
      try {
        t = e.document.baseURI;
      } catch (e) {}
      return null != t && Rl.test(t) ? t : null;
    },
    $l = (e, t, n) =>
      new Promise(function (r, i) {
        let s, o;
        return (
          (s = ei()),
          Promise.resolve(Hr(e, t, n)).then(function (e) {
            try {
              return (o = ei() - s), r(o);
            } catch (e) {
              return i(e);
            }
          }, i)
        );
      }),
    Nl = (e, t) =>
      new Promise(function (n, r) {
        let i, s, o, a, l;
        return (
          (i = t.ownerDocument),
          (s = i.defaultView),
          (o = s.getVPAIDAd),
          delete s.getVPAIDAd,
          Promise.resolve($l(e, null, i)).then(function (e) {
            try {
              a = e;
              try {
                l = s.getVPAIDAd();
              } finally {
                s.getVPAIDAd = o;
              }
              return n({ vpaid: l, time: a });
            } catch (e) {
              return r(e);
            }
          }, r)
        );
      }),
    Ul = (e, t) =>
      new Promise(function (n, r) {
        let i, s, o, a, l, u;
        return Promise.resolve(
          ((e, t) =>
            new Promise(function (n, r) {
              return Promise.resolve(_r(e.ownerDocument)).then(function (i) {
                try {
                  return n(
                    ((e, t) =>
                      new Promise(function (n, r) {
                        let i, s;
                        return (
                          (i = e.ownerDocument.createElement("iframe")),
                          (s = br(i, "load")),
                          (i.loading = "eager"),
                          (i.frameBorder = "0"),
                          (i.scrolling = "no"),
                          dr(i, t, !0),
                          (i.srcdoc =
                            '<div style="display:none !important; width: 0 !important; height: 0 !important;"></div>'),
                          e.appendChild(i),
                          Promise.resolve(Promise.race([s, wr(i)])).then(
                            function (e) {
                              try {
                                return n(i);
                              } catch (e) {
                                return r(e);
                              }
                            },
                            r
                          )
                        );
                      }))(e, t)
                  );
                } catch (e) {
                  return r(e);
                }
              }, r);
            }))(t, Ll)
        ).then(function (t) {
          try {
            return (
              (i = t),
              (s = i.contentWindow),
              (o = s.document),
              (a = ((e) =>
                ((e, t) => {
                  let n = 0,
                    r = t(e);
                  for (; null == r && e !== e.parent && n < 10; )
                    (r = t((e = e.parent))), ++n;
                  return r;
                })(e, Dl))(s)),
              o.write(
                "<html><head>" +
                  (null != a
                    ? `<base href="${((e) => {
                        const t = document.createElement("span");
                        return (t.textContent = e), t.innerHTML;
                      })(a)}">`
                    : "") +
                  "</head><body></body></html>"
              ),
              o.close(),
              Promise.resolve($l(e, null, o)).then(function (e) {
                try {
                  return (
                    (l = e),
                    (u = s.getVPAIDAd()),
                    n({ iframe: i, vpaid: u, time: l })
                  );
                } catch (e) {
                  return r(e);
                }
              }, r)
            );
          } catch (e) {
            return r(e);
          }
        }, r);
      }),
    Bl = {
      fullscreenEnabled: 0,
      fullscreenElement: 1,
      requestFullscreen: 2,
      exitFullscreen: 3,
      fullscreenchange: 4,
      fullscreenerror: 5,
    },
    zl = [
      "webkitFullscreenEnabled",
      "webkitFullscreenElement",
      "webkitRequestFullscreen",
      "webkitExitFullscreen",
      "webkitfullscreenchange",
      "webkitfullscreenerror",
    ],
    Wl = [
      "mozFullScreenEnabled",
      "mozFullScreenElement",
      "mozRequestFullScreen",
      "mozCancelFullScreen",
      "mozfullscreenchange",
      "mozfullscreenerror",
    ],
    ql = [
      "msFullscreenEnabled",
      "msFullscreenElement",
      "msRequestFullscreen",
      "msExitFullscreen",
      "MSFullscreenChange",
      "MSFullscreenError",
    ],
    Hl =
      "undefined" != typeof window && void 0 !== window.document
        ? window.document
        : {},
    Gl =
      ("fullscreenEnabled" in Hl && Object.keys(Bl)) ||
      (zl[0] in Hl && zl) ||
      (Wl[0] in Hl && Wl) ||
      (ql[0] in Hl && ql) ||
      [],
    Ql = {
      get changeEventType() {
        return Gl[Bl.fullscreenchange];
      },
      isActive(e) {
        const { ownerDocument: t } = e,
          n = Gl[Bl.fullscreenElement];
        return null != t && t[n] === e;
      },
      request(e) {
        if (Ql.isActive(e)) return Promise.resolve();
        const t = Gl[Bl.requestFullscreen];
        return "function" != typeof e[t]
          ? Promise.reject(new Error("Not supported"))
          : ci(e[t](), 3e3);
      },
      exit(e) {
        const t = Gl[Bl.exitFullscreen];
        return "function" != typeof e[t]
          ? Promise.reject(new Error("Not supported"))
          : ci(e[t](), 1e3);
      },
    },
    Yl = Symbol("url"),
    Xl = Symbol("options"),
    Kl = Symbol("pubSub"),
    Zl = Symbol("skippable"),
    Jl = Symbol("slot"),
    eu = Symbol("videoSlot"),
    tu = Symbol("clickSlot"),
    nu = Symbol("width"),
    ru = Symbol("height"),
    iu = Symbol("viewMode"),
    su = Symbol("volumeImpaired"),
    ou = Symbol("volume"),
    au = Symbol("paused"),
    lu = Symbol("stopped"),
    uu = Symbol("loaded"),
    cu = Symbol("clicked"),
    du = Symbol("requested"),
    hu = Symbol("domEventTracker"),
    pu = Symbol("tickInterval"),
    fu = Symbol("quartile"),
    mu = Symbol("monitors"),
    gu = Symbol("lastTimeChangeTimestamp"),
    { internal: vu } = ls,
    yu = {
      noMutedAutoplayFallback: !1,
      noPauseOnClickThrough: !1,
      skipOffset: null,
    },
    bu = {
      1: "MEDIA_ERR_ABORTED",
      2: "MEDIA_ERR_NETWORK",
      3: "MEDIA_ERR_DECODE",
      4: "MEDIA_ERR_SRC_NOT_SUPPORTED",
    },
    _u = {
      position: "absolute",
      left: "0",
      top: "0",
      border: "0",
      margin: "0",
      padding: "0",
    },
    wu = Object.assign({}, _u, { cursor: "pointer" }),
    Au = "duration",
    ku = "remainingTime",
    Su = "volume",
    Pu = "skippableState",
    Eu = "size",
    Cu = {
      [Au]: [["getAdDuration"], "AdDurationChange"],
      [ku]: [["getAdRemainingTime"], "AdRemainingTimeChange"],
      [Su]: [["getAdVolume"], "AdVolumeChange"],
      [Pu]: [["getAdSkippableState"], "AdSkippableStateChange"],
      [Eu]: [["getAdWidth", "getAdHeight"], "AdSizeChange"],
    };
  class xu {
    constructor(e, t) {
      (this[Yl] = e),
        (this[Xl] = Object.assign({}, yu, t)),
        (this[Kl] = new bs()),
        (this[Zl] = null == this[Xl].skipOffset),
        (this[nu] = ye),
        (this[ru] = ye),
        (this[iu] = null),
        (this[su] = !1),
        (this[ou] = ye),
        (this[Jl] = null),
        (this[eu] = null),
        (this[au] = !0),
        (this[lu] = !1),
        (this[uu] = !1),
        (this[cu] = !1),
        (this[vu] = !0),
        (this[hu] = new Pr()),
        (this[du] = {}),
        (this[pu] = null),
        (this[fu] = -1),
        (this[mu] = this._buildMonitors()),
        (this[gu] = ei()),
        (this._handleTimeChange = this._handleTimeChange.bind(this)),
        (this._onTick = this._onTick.bind(this));
      for (let e = 0; e < Ae.length; ++e) {
        const t = Ae[e];
        this[t] = Gr(this[t]).bind(this);
      }
      De({ rel: "preconnect", href: e, pr: "1.0" });
    }
    _getSlot() {
      return this[Jl];
    }
    getAdLinear() {
      return !0;
    }
    getAdWidth() {
      return this._isFullscreen() ? screen.width : this[nu];
    }
    getAdHeight() {
      return this._isFullscreen() ? screen.height : this[ru];
    }
    getAdExpanded() {
      return !1;
    }
    getAdSkippableState() {
      return this[Zl];
    }
    getAdRemainingTime() {
      if (this[uu] && null != this[eu]) {
        const { currentTime: e, duration: t } = this[eu];
        if (isFinite(e) && isFinite(t) && t > 0 && e >= 0) return t - e;
      }
      return ye;
    }
    getAdDuration() {
      if (this[uu] && null != this[eu]) {
        const { duration: e } = this[eu];
        if (isFinite(e) && e > 0) return e;
      }
      return ye;
    }
    getAdVolume() {
      if (this[uu] && null != this[eu]) {
        const { volume: e, muted: t } = this[eu];
        if ("boolean" == typeof t && t) return 0;
        if (isFinite(e)) return e;
      }
      return this[ou];
    }
    setAdVolume(e) {
      (this[ou] = e),
        null != this[eu] &&
          (this._setVolume(e), this[su] && this._notifyMonitor(Su));
    }
    getAdCompanions() {
      return "";
    }
    getAdIcons() {
      return !1;
    }
    handshakeVersion() {
      return "2.0";
    }
    initAd(e, t, n, r, i, s) {
      let { videoSlot: o, slot: a, sendErrorInfo: l } = s || {};
      const u = null == a || null == a.ownerDocument;
      (this[Kl].options.sendErrorInfo = !0 === l),
        u && ((a = document.createElement("div")), dr(a, _u)),
        null == o &&
          ((o = a.ownerDocument.createElement("video")),
          dr(o, _u),
          a.appendChild(o)),
        (this[Jl] = a),
        (this[eu] = o),
        (this[tu] = a.ownerDocument.createElement("div")),
        dr(this[tu], wu, !0),
        a.appendChild(this[tu]),
        (this[su] = !("volume" in o && "muted" in o)),
        this._setDimensions(e, t, n, !1),
        this._preloadSrc(this[Yl]);
      const c = () => {
        this._publish(be.AdLoaded);
      };
      u
        ? _r(document).then(() => {
            document.body.appendChild(a), c();
          })
        : c();
    }
    resizeAd(e, t, n) {
      this._setDimensions(e, t, n, !0);
    }
    startAd() {
      this._request(be.AdImpression),
        this._addDomListeners(),
        this[eu].pause(),
        this[ou] >= 0 && (this._setVolume(this[ou]), this._notifyMonitor(Su)),
        this._initVideoSlot(this[Yl]),
        (this[uu] = !0),
        this._publish(be.AdStarted),
        (this[au] = !1),
        this._play();
    }
    stopAd() {
      this._stop();
    }
    skipAd() {
      this._request(be.AdSkipped), this._stop();
    }
    pauseAd() {
      this._pause();
    }
    resumeAd() {
      this._resume();
    }
    expandAd() {}
    collapseAd() {}
    subscribe(e, t, n) {
      void 0 === n && (n = null), this[Kl].subscribe(e, t, n);
    }
    unsubscribe(e, t) {
      this[Kl].unsubscribe(e, t);
    }
    _publish(e, t) {
      void 0 === t && (t = []), this[Kl].publish(e, t);
    }
    _addDomListeners() {
      var e, t;
      this[hu].removeAll(),
        this[hu]
          .add(this[tu], "click", this._onClickSlotClick, this)
          .add(
            ((e = this[eu].ownerDocument),
            null != (t = e) && "function" == typeof t.addEventListener
              ? e
              : document),
            Ql.changeEventType,
            this._onFullscreenchange,
            this
          )
          .addMany(
            this[eu],
            {
              durationchange: this._onVideoDurationchange,
              volumechange: this._onVideoVolumechange,
              playing: this._onVideoPlaying,
              play: this._onVideoPlay,
              pause: this._onVideoPause,
              seeked: this._onVideoSeeked,
              ended: this._onVideoEnded,
              error: this._onVideoError,
              timeupdate: this._onVideoTimeupdate,
            },
            this
          );
    }
    _onClickSlotClick() {
      if (this[lu]) this._publish(be.AdClickThru, [null, null, !0]);
      else if (this[cu] && this[au])
        this[au] && ((this[cu] = !1), this._resume());
      else {
        const { noPauseOnClickThrough: e } = this[Xl];
        e || this[au] || this._pause(),
          (this[cu] = !0),
          this._publish(be.AdClickThru, [null, null, !0]);
      }
    }
    _onTick() {
      ei() - this[gu] >= 245 && this._handleTimeChange();
    }
    _onVideoDurationchange() {
      this._notifyMonitor(Au), this._notifyMonitor(ku);
    }
    _onVideoVolumechange() {
      this._notifyMonitor(Su);
    }
    _onVideoPlaying() {
      this._satisfy(be.AdImpression),
        this._satisfy(be.AdPlaying),
        this._startTicking();
    }
    _onVideoPlay() {}
    _onVideoPause() {
      this._stopTicking(),
        this._satisfy(be.AdPaused),
        this._satisfyStopRequest();
    }
    _onVideoSeeked() {
      this._notifyMonitor(ku);
    }
    _onVideoEnded() {
      this._handleTimeChange(), this._stop();
    }
    _onVideoError() {
      const { error: e } = this[eu],
        t =
          "Video Playback Error" +
          ((e) => {
            if (null == e || (null == e.code && ze(e.message)))
              return " (no error code, no error message)";
            const { code: t, message: n } = e;
            if (null == t) return `: ${n} (no error code)`;
            const r = bu[t];
            return null == r
              ? ze(n)
                ? ` (unknown error code ${t}, no error message)`
                : `: ${n} (unknown error code ${t})`
              : `: ${r} ${ze(n) ? "(no error message)" : `- ${n}`}`;
          })(e),
        n = new Or(t, 405, null, this[Yl]),
        r = { message: n.toString(), code: n.code, subject: n.subject };
      this._publish(be.AdError, [r.message, r]), this._stop();
    }
    _onVideoTimeupdate() {
      this._onTick();
    }
    _preloadSrc(e) {
      const { src: t, currentSrc: n } = this[eu];
      (null != t && "" !== t) ||
        (null != n && "" !== n) ||
        (this[hu].add(this[eu], "error", this._onVideoError, this),
        this._initVideoSlot(e));
    }
    _initVideoSlot(e) {
      "function" == typeof this[eu].setAttribute
        ? (this[eu].setAttribute("playsinline", "true"),
          this[eu].setAttribute("webkit-playsinline", "true"))
        : (this[eu].playsInline = !0),
        (this[eu].autoplay = !1),
        (this[eu].controls = !1),
        (this[eu].loop = !1),
        (this[eu].src = e);
    }
    _setDimensions(e, t, n, r) {
      "fullscreen" === n
        ? this._requestFullscreen().catch((e) => {
            this._publishAdLog(`Fullscreen mode failed: ${e}`);
          })
        : this._exitFullscreen()
            .catch(vr)
            .then(() => {
              this._setDimensionsNormal(e, t), r && this._notifyMonitor(Eu);
            });
    }
    _setDimensionsNormal(e, t) {
      (this[nu] = e), (this[ru] = t), (this[iu] = "normal");
      const n = { width: e + "px", height: t + "px" };
      dr(this[eu], n), dr(this[Jl], n), dr(this[tu], n, !0);
    }
    _requestFullscreen() {
      return this._isFullscreen()
        ? Promise.resolve()
        : Ql.request(this[eu]).then(
            () => {},
            (e) => {
              throw e;
            }
          );
    }
    _exitFullscreen() {
      return this._isFullscreen()
        ? Ql.exit(this[eu].ownerDocument).catch((e) => {
            throw e;
          })
        : Promise.resolve();
    }
    _onFullscreenchange() {
      const e = this._isFullscreen() ? "fullscreen" : "normal";
      e !== this[iu] && ((this[iu] = e), this._notifyMonitor(Eu));
    }
    _isFullscreen() {
      return null != this[eu] && Ql.isActive(this[eu]);
    }
    _setVolume(e) {
      this[eu].volume !== e && (this[eu].volume = e);
      const t = 0 === e;
      this[eu].muted !== t && (this[eu].muted = t);
    }
    _play() {
      const { noMutedAutoplayFallback: e } = this[Xl],
        t = this[eu].muted,
        n = this[eu].play();
      null != n && "function" == typeof n.catch
        ? (this._publish(
            be.AdMutedUnmutedPlayback,
            t
              ? [{ mutedPlaybackAttempted: !0 }]
              : [{ unmutedPlaybackAttempted: !0 }]
          ),
          n
            .then(() => {
              this._publish(be.AdMutedUnmutedPlayback, [
                { playbackSuccessful: !0 },
              ]);
            })
            .catch((n) => {
              if (t) throw n;
              if (
                (this._publishAdLog(`Unmuted playback failed: ${n}`), this[au])
              )
                this._publishAdLog(
                  "Unmuted playback failed and ad is paused, not falling back to muted playback"
                ),
                  this._publish(be.AdMutedUnmutedPlayback, [
                    { playbackSuccessful: !1, adPaused: !0 },
                  ]);
              else {
                if (!e)
                  return (
                    this._publishAdLog(
                      "Unmuted playback failed, attempting fallback to muted playback"
                    ),
                    (this[eu].muted = !0),
                    this._publish(be.AdMutedUnmutedPlayback, [
                      { mutedPlaybackAttempted: !0 },
                    ]),
                    this[eu].play()
                  );
                this._publishAdLog(
                  "Unmuted playback failed and fallback to muted playback disabled, giving up"
                ),
                  this._publish(be.AdMutedUnmutedPlayback, [
                    { playbackSuccessful: !1, mutedPlaybackDisabled: !0 },
                  ]);
              }
            })
            .catch((e) => {
              this._publish(be.AdMutedUnmutedPlayback, [
                { playbackSuccessful: !1 },
              ]),
                this._publishAdLog(`Muted playback failed: ${e}`);
            }))
        : this._publishAdLog(
            "Video slot does not report disallowed play attempts"
          );
    }
    _pause() {
      (this[au] = !0),
        null == this[eu] || this[eu].paused
          ? this._publish(be.AdPaused)
          : (this._request(be.AdPaused), this[eu].pause());
    }
    _resume() {
      (this[au] = !1),
        null != this[eu] && this[eu].paused
          ? (this._request(be.AdPlaying), this._play())
          : this._publish(be.AdPlaying);
    }
    _stop() {
      this._stopTicking(),
        (this[au] = !0),
        (this[lu] = !0),
        this._request(be.AdStopped),
        null == this[eu] || this[eu].paused || this[eu].ended
          ? this._satisfyStopRequest()
          : this[eu].pause();
    }
    _satisfyStopRequest() {
      this._requested(be.AdStopped) &&
        (this[Xl].autoDisposeDisabled || this[hu].removeAll(),
        null != this[eu] && this._resetMediaSrc(),
        this._satisfy(be.AdSkipped),
        this._satisfy(be.AdStopped));
    }
    _resetMediaSrc() {
      const e = this[eu];
      "function" == typeof e.removeAttribute
        ? (e.removeAttribute("src"), e.load())
        : (e.src = ""),
        (this[uu] = !1);
    }
    _startTicking() {
      null == this[pu] &&
        ((this[pu] = setInterval(this._onTick, 250)), this._handleTimeChange());
    }
    _stopTicking() {
      null != this[pu] &&
        (this._handleTimeChange(), clearInterval(this[pu]), (this[pu] = null));
    }
    _handleTimeChange() {
      if (((this[gu] = ei()), !this[uu])) return;
      const e = this[eu];
      null == e ||
        e.readyState < 1 ||
        null != e.error ||
        (this._notifyMonitor(Au),
        this._notifyMonitor(ku),
        this._handleSkippableState(),
        this._handleQuartiles());
    }
    _handleSkippableState() {
      if (this[Zl]) return;
      const { skipOffset: e } = this[Xl],
        { currentTime: t, duration: n } = this[eu],
        r = Xr(e) ? Zr(e, n) : e;
      "number" == typeof r &&
        t >= r &&
        ((this[Zl] = !0), this._notifyMonitor(Pu));
    }
    _handleQuartiles() {
      const { currentTime: e, duration: t, ended: n, played: r } = this[eu],
        i =
          null != r && r.length > 0
            ? ((s = r),
              Array.apply(null, s).reduce(
                (e, t, n) => e + s.end(n) - s.start(n),
                0
              ))
            : e;
      var s;
      if (!isFinite(i) || i < 0 || !isFinite(t) || t <= 0) return;
      const o = this[fu],
        a = n ? 0.25 : 0;
      this[fu] = Math.min(Math.max(o, Math.floor(((i + a) / t) * 4)), 4);
      for (let e = o + 1; e <= this[fu]; ++e) this._publish(Se[e]);
    }
    _request(e) {
      this[du][e] = !0;
    }
    _requested(e) {
      return !!this[du][e];
    }
    _satisfy(e) {
      this._requested(e) && ((this[du][e] = !1), this._publish(e));
    }
    _buildMonitors() {
      const e = {},
        t = Object.keys(Cu);
      for (let n = 0; n < t.length; ++n) {
        const r = t[n],
          [i, s] = Cu[r];
        e[r] = this._buildMonitor(i, s);
      }
      return e;
    }
    _buildMonitor(e, t) {
      const n = () => e.map((e) => this[e]()).join("\0");
      let r = n();
      return () => {
        const e = n();
        e !== r && ((r = e), this._publish(t));
      };
    }
    _notifyMonitor(e) {
      this[mu][e]();
    }
    _publishAdLog(e) {
      this._publish(be.AdLog, [e]);
    }
  }
  const { runtime: Tu, clickThroughUrl: Ou, options: Iu } = ls,
    Mu = [
      /\/adbridge-vpaid\.min\.js(?:\?|#|$)/,
      /\/\/(?:www\.)?wootag\.com\/player\/(?:ad\/)?v3\/bundle\.js(?:\?|#|$)/,
      /\/\/(?:www\.)?viewbix\.com\/plugins\/vpaid\.bundle\.js(?:\?|#|$)/,
      /\/\/(?:[^/]+\.)?(?:ssl-images|media)-amazon\.com\//,
    ],
    { phaser: Vu, runtime: ju } = ls,
    Fu = ["GuestNotAvailableError", "MethodNotAvailableError"],
    Lu = ["initAd", "startAd", "stopAd", "skipAd"],
    { runtime: Ru } = ls,
    Du = (e, t, n) => {
      null == e[t] &&
        (e[t] = function () {
          let e = null;
          try {
            for (var r = arguments.length, i = new Array(r), s = 0; s < r; s++)
              i[s] = arguments[s];
            e = this._phasedGuestCallSync(t, i);
          } catch (t) {
            if (!(null != t && Fu.indexOf(t.name) >= 0)) throw t;
            e = n;
          }
          return e;
        });
    },
    $u = (e, t) => {
      null == e[t] &&
        (e[t] = function () {
          Lu.indexOf(t) >= 0 && this[Ru].track(t);
          for (var e = arguments.length, n = new Array(e), r = 0; r < e; r++)
            n[r] = arguments[r];
          this._phasedGuestCall(t, n).catch((e) => {
            this._onError(e, t);
          });
        });
    },
    Nu = "https",
    Uu = "";
  class Bu {
    config;
    constructor(e) {
      this.config = {
        urlComponents: e,
        queryParams: new Map(),
        delimiter: "?",
      };
    }
    build() {
      return `${this.baseUrl}${this.buildQueryString()}`;
    }
    addQueryParameter(e) {
      return (
        this.isValidParameter(e) && this.config.queryParams.set(e.key, e), this
      );
    }
    addQueryParameters(e) {
      for (const t of e) this.addQueryParameter(t);
      return this;
    }
    addRawQueryParameters(e, t) {
      for (const [n, r] of Object.entries(e))
        this.addQueryParameter({ key: n, value: r, ...t });
      return this;
    }
    setQueryParameters(e) {
      return (
        (this.config.queryParams = this.generateQueryParametersMapFromList(
          e ?? []
        )),
        this
      );
    }
    setDelimiter(e) {
      return (this.config.delimiter = e), this;
    }
    get baseUrl() {
      return ((e) => {
        let { protocol: t = Nu, hostname: n, path: r = Uu } = e;
        return `${((e) => e.trim().replace(/:?\/*$/, ""))(t)}://${((e) =>
          e.trim().replace(/^\/+/, "").replace(/\/+$/, ""))(n)}${((e) => {
          const t = e.trim();
          return "" === t ? "" : `/${t.replace(/^\/+/, "")}`;
        })(r)}`;
      })(this.config.urlComponents);
    }
    get queryParametersString() {
      return this.buildQueryParams(this.getQueryParameterList());
    }
    get parameters() {
      const e = {};
      for (const [t, n] of this.config.queryParams.entries()) e[t] = n.value;
      return e;
    }
    getQueryParameterList() {
      return Array.from(this.config.queryParams.values());
    }
    mapQueryParameter(e) {
      return e;
    }
    buildQueryString() {
      return "" === this.queryParametersString
        ? ""
        : `${this.config.delimiter}${this.queryParametersString}`;
    }
    buildQueryParams(e) {
      return null == e || 0 === e.length
        ? ""
        : e
            .map(
              ((t = this.mapQueryParameter.bind(this)),
              (n = this.buildParameter.bind(this)),
              (e) => n(t(e)))
            )
            .join("&");
      var t, n;
    }
    buildParameter(e) {
      const t = e.value?.toString() ?? "";
      return `${encodeURIComponent(e.key)}=${
        e.encode ?? 1 ? encodeURIComponent(t) : t
      }`;
    }
    isValidParameter(e) {
      let { value: t } = e;
      return null != t && "" !== t;
    }
    generateQueryParametersMapFromList(e) {
      return new Map(
        ((e, t, n) => {
          const r = [];
          for (const i of e) t(i) && r.push(n(i));
          return r;
        })(e, this.isValidParameter.bind(this), (e) => [e.key, e])
      );
    }
  }
  class zu extends Bu {
    priorityMapping = {};
    defaultPriority = 0;
    setPriorityMapping(e) {
      return (this.priorityMapping = Object.assign({}, e)), this;
    }
    extendPriorityMapping(e) {
      return Object.assign(this.priorityMapping, e), this;
    }
    setPriorityMappingSequence(e, t) {
      return (
        (this.priorityMapping = {}), this.extendPriorityMappingSequence(e, t)
      );
    }
    extendPriorityMappingSequence(e, t) {
      return (
        void 0 === t && (t = this.defaultPriority),
        e.forEach((e, n) => {
          this.priorityMapping[e] = n + t;
        }),
        this
      );
    }
    setDefaultPriority(e) {
      return (this.defaultPriority = e), this;
    }
    getQueryParameterList() {
      return super
        .getQueryParameterList()
        .sort(this.compareQueryParameters.bind(this));
    }
    compareQueryParameters(e, t) {
      return this.processQueryPriority(e) - this.processQueryPriority(t);
    }
    processQueryPriority(e) {
      return this.priorityMapping[e.key] ?? e.priority ?? this.defaultPriority;
    }
  }
  var Wu, qu, Hu, Gu;
  !(function (e) {
    (e.SKYFAKE = "skyfake"),
      (e.AMAZON = "amazon"),
      (e.TWITCH = "twitch"),
      (e.CUSTOM = "custom");
  })(Wu || (Wu = {})),
    new Set([Wu.AMAZON, Wu.TWITCH]),
    new Set([Wu.CUSTOM, Wu.SKYFAKE, Wu.AMAZON, Wu.TWITCH]),
    Wu.SKYFAKE,
    Wu.AMAZON,
    Wu.TWITCH,
    (function (e) {
      (e.DV = "DV"), (e.DV_TECH = "DV_TECH");
    })(qu || (qu = {})),
    qu.DV,
    qu.DV_TECH,
    (function (e) {
      (e.PROTOCOL_VERSION = "v"),
        (e.HIT_TYPE = "t"),
        (e.TRACKING_ID = "tid"),
        (e.CTX = "ctx"),
        (e.CMP = "cmp"),
        (e.CACHE_BUSTER = "z"),
        (e.EVENT_ACTION = "ea"),
        (e.EVENT_LABEL = "el"),
        (e.EVENT_CATEGORY = "ec"),
        (e.EVENT_VALUE = "ev"),
        (e.REDIRECT_URL = "redir"),
        (e.CLIENT_ID = "cid"),
        (e.DOCUMENT_REFERRER = "dr"),
        (e.GDPR_APPLIES = "gdpr"),
        (e.GDPR_CONSENT = "gdpr_consent");
    })(Hu || (Hu = {})),
    (function (e) {
      (e.CUSTOM_DIMENSION_PREFIX = "cd"), (e.CUSTOM_METRIC_PREFIX = "cm");
    })(Gu || (Gu = {}));
  const Qu = { redir: 1 / 0 },
    Yu = {
      protocol: "https",
      hostname: "vfw.amazon-adsystem.com",
      path: "/dv/vtrk.doubleverify.com",
    },
    Xu = {
      [Wu.SKYFAKE]: {
        protocol: "https",
        hostname: "video-qa.doubleverify.com",
        path: "/skyfake/pxsrv",
      },
      [Wu.AMAZON]: Yu,
      [Wu.TWITCH]: Yu,
    },
    Ku = { protocol: "https", hostname: "vtrk.dv.tech" },
    Zu = new Set(Object.values(Hu)),
    Ju = new RegExp(
      `^(?:${Gu.CUSTOM_DIMENSION_PREFIX}|${Gu.CUSTOM_METRIC_PREFIX})(?:[1-9]\\d?|1\\d{2}|200)$`
    ),
    ec = [Hu.EVENT_ACTION, Hu.EVENT_CATEGORY];
  var tc, nc, rc, ic, sc;
  !(function (e) {
    (e.DISABLED = "DISABLED"),
      (e.DATE = "DATE"),
      (e.MACRO = "MACRO"),
      (e.CUSTOM = "CUSTOM");
  })(tc || (tc = {}));
  class oc extends zu {
    constructor(e) {
      const t = oc.generateURIBase(e ?? {});
      var n;
      (t.path = "/" === (n = t.path ?? "").slice(-1) ? n : `${n}/`),
        super(t),
        this.setPriorityMapping(Qu);
    }
    setCustomDimension(e, t) {
      return this.addQueryParameter({
        key: `${Gu.CUSTOM_DIMENSION_PREFIX}${e}`,
        ...t,
      });
    }
    setCustomMetric(e, t) {
      return this.addQueryParameter({
        key: `${Gu.CUSTOM_METRIC_PREFIX}${e}`,
        ...t,
      });
    }
    build() {
      return (
        (function (e) {
          const t = [];
          for (const n of ec) e.has(n) || t.push(`"${n}" is required`);
          for (const { key: n } of e.values())
            Zu.has(n) ||
              Ju.test(n) ||
              t.push(`"${n}" is not a valid Pxsrv field`);
          if (t.length > 0)
            throw new Error(`Validation failed: ${t.join("; ")}`);
        })(this.config.queryParams),
        super.build()
      );
    }
    setCacheBusterMode(e, t) {
      const n = (function (e, t) {
        switch (e) {
          case tc.DISABLED:
            return null;
          case tc.CUSTOM:
            return { value: (t ?? "").toString(), encode: !0 };
          case tc.MACRO:
            return { value: "[CACHEBUSTING]", encode: !1 };
          case tc.DATE: {
            const e = 1e6 + Math.floor(9e6 * Math.random());
            return { value: `${new Date().getTime()}${e}`, encode: !1 };
          }
        }
      })(e, t);
      return (
        null != n &&
          this.addQueryParameter({
            key: Hu.CACHE_BUSTER,
            value: n.value,
            encode: n.encode,
          }),
        this
      );
    }
    static generateURIBase(e) {
      let { hostname: t, proxy: n } = e;
      if (null != n && null != Xu[n.value]) return Xu[n.value];
      const r = Object.assign({}, Ku);
      return null != t && "" !== t && (r.hostname = t), r;
    }
  }
  !(function (e) {
    (e.DISPLAY = "display"), (e.VIDEO = "video");
  })(nc || (nc = {})),
    Object.values(nc),
    (function (e) {
      (e.UE = "ue"), (e.UW = "uw"), (e.EU = "eu"), (e.AS = "as");
    })(rc || (rc = {})),
    Object.values(rc),
    (function (e) {
      (e.EVENT = "EVENT"), (e.VISIT = "VISIT");
    })(ic || (ic = {})),
    Object.values(ic),
    (function (e) {
      (e.DVP_PREFIX = "dvp_"), (e.DVPF_PREFIX = "dvpf_");
    })(sc || (sc = {})),
    ic.EVENT,
    ic.VISIT,
    ic.EVENT,
    ic.VISIT,
    Wu.SKYFAKE,
    Wu.AMAZON,
    Wu.TWITCH,
    ic.EVENT,
    ic.VISIT,
    Wu.SKYFAKE,
    Wu.AMAZON,
    Wu.TWITCH,
    Wu.SKYFAKE,
    Wu.AMAZON;
  const ac = (e) =>
      ((e) => "string" == typeof e && e.startsWith("data:"))(e) ? "data:" : e,
    lc = {
      timeout: 2e3,
      postAllowed: !1,
      styles: {
        position: "absolute",
        top: 0,
        left: 0,
        width: 0,
        height: 0,
        border: 0,
        pointerEvents: "none",
        visibility: "hidden",
      },
    },
    uc = () => {};
  class cc {
    _url;
    _options;
    _window;
    _deferred = null;
    _image = null;
    constructor(e, t) {
      void 0 === t && (t = {}),
        (this._url = e),
        (this._options = Object.assign({}, lc, t));
      let n = window,
        r = 0;
      try {
        for (
          ;
          r < 10 &&
          n.parent !== n &&
          null != n.parent.document.createElement("img");

        )
          (n = n.parent), ++r;
      } catch (e) {}
      this._window = n;
    }
    get promise() {
      return null != this._deferred ? this._deferred.promise : null;
    }
    load() {
      return null != this._deferred
        ? Promise.reject(new Error("Already loading"))
        : ((this._deferred = yr()),
          this._deferred.promise.catch(uc),
          (this._options.postAllowed &&
          "function" == typeof navigator.sendBeacon
            ? this._sendBeacon
            : this._loadPixel
          ).call(this),
          this._deferred.promise);
    }
    dispose() {
      this._rejectWith("Disposed");
    }
    _sendBeacon() {
      const e = navigator.sendBeacon(this._url, "");
      null != this._deferred &&
        (e
          ? this._deferred.resolve()
          : this._deferred.reject(new Error("Failed")));
    }
    _loadPixel() {
      (this._image = this._window.document.createElement("img")),
        (this._image.src = this._url),
        Object.assign(this._image.style, this._options.styles),
        (this._image.onload = this._onImageLoad.bind(this)),
        (this._image.onerror = this._onImageError.bind(this)),
        this._window.document.body.appendChild(this._image),
        setTimeout(this._onImageTimeout.bind(this), this._options.timeout);
    }
    _onImageLoad() {
      null != this._deferred && this._deferred.resolve(), this._remove();
    }
    _onImageError() {
      this._rejectWith("Unknown error");
    }
    _onImageTimeout() {
      this._rejectWith("Timed out");
    }
    _rejectWith(e) {
      null != this._deferred && this._deferred.reject(new Error(e)),
        this._remove();
    }
    _remove() {
      null != this._image &&
        (null != this._image.parentNode &&
          this._image.parentNode.removeChild(this._image),
        (this._image = null));
    }
  }
  function dc() {
    if ("object" == typeof crypto && "function" == typeof crypto.randomUUID)
      return crypto.randomUUID();
    let e = new Date().getTime(),
      t =
        "undefined" != typeof performance &&
        "function" == typeof performance.now
          ? 1e3 * performance.now()
          : 0;
    return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(
      /[xy]/g,
      function (n) {
        let r = 16 * Math.random();
        return (
          e > 0
            ? ((r = (e + r) % 16 | 0), (e = Math.floor(e / 16)))
            : ((r = (t + r) % 16 | 0), (t = Math.floor(t / 16))),
          ("x" === n ? r : (3 & r) | 8).toString(16)
        );
      }
    );
  }
  const hc = Symbol("timings"),
    pc = Symbol("eventCount"),
    fc = Symbol("lastEventTime"),
    mc = Symbol("handlers"),
    gc = Symbol("configured"),
    vc = Symbol("configuring"),
    yc = Symbol("gpdrApplies"),
    bc = Symbol("gdprConsent"),
    _c = Symbol("doNotSampleAdLoadedEvents"),
    wc = Symbol("currentTimestampInCacheBuster"),
    Ac = Symbol("config"),
    { runtime: kc, internal: Sc } = ls,
    Pc = ei(),
    Ec = ["start", "load", "initAd", "AdLoaded", "startAd", "AdStarted"],
    Cc = Math.random() < 0.1,
    xc = document,
    Tc = (() => {
      let e = window,
        t = 0;
      try {
        for (
          ;
          t < 10 &&
          e.parent !== e &&
          null != e.parent.location &&
          null != e.parent.location.hostname;

        )
          (e = e.parent), ++t;
      } catch (e) {}
      return e;
    })().location.hostname,
    Oc = [];
  class Ic {
    constructor(e) {
      (this[Sc] = !0),
        (this[hc] = { start: Pc }),
        (this[pc] = 0),
        (this[fc] = Pc),
        (this[mc] = []),
        (this[gc] = !1),
        (this[vc] = yr()),
        (this[yc] = null),
        (this[bc] = null),
        (this[_c] = !1),
        (this[Ac] = {});
      const t = `vpaid-transformer@${u}+js`,
        n = (t) => {
          const { mediaFile: n } = e[kc].guestInfo;
          return null == n || Qe(n) ? void 0 : n[t];
        };
      this.addEventLabel(() => ac(e[kc].hostInfo.originVastUrl)),
        this.addDimension(136, () => {
          const { uriBlacklistedForFriendlyIframe: t } = e[kc].contextInfo;
          return null == t ? null : (t << 1) | e[kc].isFlagEnabled(4);
        }),
        this.addDimension(137, () => {
          const {
            imaSdkPresent: t,
            hasImaVpaidMediaFiles: n,
            hasNonImaVpaidMediaFiles: r,
          } = e[kc].contextInfo;
          return null == t || null == n || null == r
            ? null
            : (t ? "Y" : "N") +
                (n ? "Y" : "N") +
                (e[kc].isFlagEnabled(2) ? "Y" : "N") +
                (r ? "Y" : "N");
        }),
        this.addDimension(140, () => e[kc].videoPlaybackContext.toString()),
        this.addDimension(138, () => {
          const { slotProvidedOnInitAd: t } = e[kc].contextInfo;
          return null == t ? null : t ? "1" : "0";
        }),
        this.addDimension(139, () => {
          const { videoSlotProvidedOnInitAd: t } = e[kc].contextInfo;
          return null == t ? null : t ? "1" : "0";
        }),
        this.addDimension(100, () => e[kc].hostInfo.viewMode),
        this.addDimension(104, () => n("type")),
        this.addDimension(103, () => ac(n("uri"))),
        this.addDimension(105, () => t),
        this.addDimension(107, () => xc.readyState),
        this.addDimension(171, () => Tc),
        this.addDimension(109, () => ac(e[kc].hostInfo.innermostVastUrl)),
        this.addDimension(116, () =>
          0 === e[kc].hostInfo.vastChainInfo.length
            ? null
            : e[kc].hostInfo.vastChainInfo.map((e) => e.join(":")).join(",")
        ),
        this.addMetric(100, () => e.getAdWidth()),
        this.addMetric(101, () => e.getAdHeight()),
        this.addMetric(104, () => e.getAdVolume()),
        this.addMetric(105, () => n("width")),
        this.addMetric(106, () => n("height")),
        this.addMetric(107, () => n("bitrate")),
        this.addMetric(108, () => e[kc].hostInfo.desiredBitrate),
        this.addMetric(109, () => {
          const e = (() => {
            const e =
              window.navigator &&
              window.navigator.connection &&
              window.navigator.connection.downlink;
            return null != e ? 1024 * e : 1 / 0;
          })();
          return isFinite(e) ? e : -1;
        }),
        this.addMetric(110, () => ei() - Pc),
        this.addMetric(111, () => {
          const e = ei(),
            t = e - this[fc];
          return (this[fc] = e), t;
        }),
        this.addMetric(112, () => e[kc].hostInfo.width),
        this.addMetric(113, () => e[kc].hostInfo.height),
        this.addMetric(167, () => e.getAdDuration());
      for (let e = 0; e < Ec.length - 1; e++) {
        const t = 180 + e,
          n = Ec[e],
          r = Ec[e + 1];
        this.addMetric(t, () => this._getTimingInfo(n, r));
      }
      window.addEventListener("unload", () => this.track("global-unload")),
        window.addEventListener("error", (e) =>
          this.trackError(
            "global-error",
            ((e) => {
              if (null != e) {
                const { error: t } = e;
                if (null != t) return t;
                {
                  const { message: t, filename: n, lineno: r, colno: i } = e;
                  return { message: t, filename: n, lineno: r, colno: i };
                }
              }
              return "[Unknown error]";
            })(e)
          )
        );
      const r = (t) => e.subscribe(() => this.track(t), t);
      r(be.AdStarted),
        r(be.AdImpression),
        r(be.AdStopped),
        e.subscribe(this._handleAdLoadedEvent, be.AdLoaded, this),
        e.subscribe(this._handleAdErrorEvent, be.AdError, this);
      let i = null;
      try {
        const { src: e } = jr(),
          t = Br(e);
        i = bi(t);
      } catch (e) {}
      this.track("load", null, i);
    }
    _handleAdErrorEvent(e, t) {
      const n = null == t ? null : t.code,
        r = null == n ? null : { [_s]: n };
      this.trackError(be.AdError, e, r, null, !0);
    }
    _handleAdLoadedEvent() {
      this.track(be.AdLoaded, null, null, this[_c] || l);
    }
    get configured() {
      return this[gc];
    }
    get gdprApplies() {
      return this[yc];
    }
    get gdprConsent() {
      return this[bc];
    }
    set gdprApplies(e) {
      this[yc] = e;
    }
    set gdprConsent(e) {
      this[bc] = e;
    }
    configure(e) {
      let {
        wrapperId: t,
        customDimensions: n,
        customMetrics: r,
        trackingUri: i,
        trackingHost: s,
        adServingId: o,
        dvConsolidationId: a,
        ctx: l,
        cmp: u,
        gdpr: c,
        gdpr_consent: d,
        alwaysTrackVastChains: h = !1,
        currentTimestampInCacheBuster: p = !1,
      } = e;
      this[gc] ||
        (null == t && null == l) ||
        ((this[Ac] = {
          ctx: l,
          cmp: u,
          wrapperId: t,
          baseUrl: i ?? "https://vtrk.dv.tech",
          clientId: a ?? o ?? dc(),
          trackingId: null == l ? `ZW-${t}` : void 0,
        }),
        this._logIds(this[Ac]),
        null != n &&
          Object.keys(n).forEach((e) => {
            e !== (116).toString() && this.addDimension(e, () => n[e]);
          }),
        null != r &&
          Object.keys(r).forEach((e) => {
            this.addMetric(e, () => r[e]);
          }),
        null != c && (this.gdprApplies = c),
        null != d && (this.gdprConsent = d),
        (this[_c] = h),
        (this[wc] = p),
        (this[gc] = !0),
        this[vc].resolve());
    }
    _logIds(e) {
      null != e.cmp && e.cmp, e.ctx;
    }
    track(e, t, n, r) {
      void 0 === t && (t = null),
        void 0 === n && (n = null),
        void 0 === r && (r = l);
      try {
        if ((this._addTiming(e), !r && (!Cc || this[pc] >= 100))) return;
        this[pc]++;
        const i = e + (r ? "" : "/10"),
          s = this._getPixelInfo(t, n);
        this._pxsrvTrack("vpaid", i, s);
      } catch (e) {}
    }
    trackError(e, t, n, r, i) {
      void 0 === n && (n = null),
        void 0 === r && (r = null),
        void 0 === i && (i = !1);
      const s = Ni((t = t || "[Unknown error]")),
        o = Object.assign({}, n, { [ws]: s.substring(0, 1e3) });
      this.track(e, o, r, i);
    }
    addEventLabel(e) {
      this[mc].push((t) => {
        t.label = e();
      });
    }
    addDimension(e, t) {
      this._addField("customDimensions", e, t);
    }
    addMetric(e, t) {
      this._addField("customMetrics", e, t);
    }
    _addField(e, t, n) {
      this[mc].push((r) => {
        r[e][`${t}`] = n();
      });
    }
    _addTiming(e) {
      null == this[hc][e] && (this[hc][e] = ei());
    }
    _pxsrvTrack(e, t, n) {
      this[gc]
        ? this._trackEvent(e, t, n)
        : this[vc].promise.then(() => {
            (n = this._mergeOptions(this._getPixelInfo(null, null), n)),
              this._trackEvent(e, t, n);
          });
    }
    _trackEvent(e, t, n) {
      const r = this._buildPxsrvUrl(e, t, n),
        i = new cc(r, { postAllowed: !0 }),
        s = i.load().catch(() => {});
      return Oc.push(s), i;
    }
    _buildPxsrvUrl(e, t, n) {
      const r = new URL(this[Ac].baseUrl),
        i = r.host + r.pathname,
        s =
          null != this[Ac].ctx
            ? { key: Hu.CTX, value: this[Ac].ctx }
            : { key: Hu.TRACKING_ID, value: this[Ac].trackingId },
        o = new oc({ hostname: i });
      o.addQueryParameters([
        { key: Hu.PROTOCOL_VERSION, value: 1 },
        { key: Hu.HIT_TYPE, value: "event" },
        s,
        { key: Hu.CMP, value: this[Ac].cmp },
        { key: Hu.CLIENT_ID, value: this[Ac].clientId },
        { key: Hu.EVENT_CATEGORY, value: e },
        { key: Hu.EVENT_ACTION, value: t },
        { key: Hu.EVENT_LABEL, value: n.label },
        { key: Hu.EVENT_VALUE, value: n.value },
        { key: Hu.GDPR_APPLIES, value: n.gdpr },
        { key: Hu.GDPR_CONSENT, value: n.gdpr_consent },
      ]);
      for (const [e, t] of Object.entries(n.customDimensions ?? {}))
        o.setCustomDimension(e, { value: t });
      for (const [e, t] of Object.entries(n.customMetrics ?? {}))
        o.setCustomMetric(e, { value: t });
      null != n.redirectUrl &&
        o.addQueryParameter({ key: Hu.REDIRECT_URL, value: n.redirectUrl });
      const a = n.cacheBusterMode ?? tc.DATE;
      return o.setCacheBusterMode(a, n.customCacheBusterValue), o.build();
    }
    _mergeOptions() {
      for (var e = arguments.length, t = new Array(e), n = 0; n < e; n++)
        t[n] = arguments[n];
      return {
        customDimensions: Object.assign(
          {},
          ...t.map((e) => e.customDimensions)
        ),
        customMetrics: Object.assign({}, ...t.map((e) => e.customMetrics)),
        gdpr: this._findOption("gdpr", t),
        gdpr_consent: this._findOption("gdpr_consent", t),
        label: this._findOption("label", t),
        cacheBusterMode: this._findOption("cacheBusterMode", t),
        customCacheBusterValue: this._findOption("customCacheBusterValue", t),
      };
    }
    _findOption(e, t) {
      const n = t.find((t) => null != t[e]);
      return null != n ? n[e] : null;
    }
    _getPixelInfo(e, t) {
      const n = {
        customDimensions: {},
        customMetrics: {},
        gdpr: this.gdprApplies,
        gdpr_consent: this.gdprConsent,
        label: null,
        cacheBusterMode: this[wc] ? tc.CUSTOM : null,
        customCacheBusterValue: this[wc] ? ei() : null,
      };
      return (
        this[mc].forEach((e) => {
          try {
            e(n);
          } catch (e) {}
        }),
        Object.assign(n.customDimensions, e),
        Object.assign(n.customMetrics, t),
        n
      );
    }
    _getTimingInfo(e, t) {
      const n = this[hc][e],
        r = this[hc][t];
      return null != n && n > 0 && null != r && r > 0 ? r - n : void 0;
    }
  }
  const Mc = {
      width: "100%",
      height: "100%",
      pointerEvents: "auto",
      position: "absolute",
      top: 0,
      left: 0,
    },
    Vc = Symbol("host"),
    jc = Symbol("guest"),
    Fc = Symbol("config"),
    Lc = Symbol("tracking"),
    Rc = Symbol("hostInfo"),
    Dc = Symbol("guestInfo"),
    $c = Symbol("contextInfo"),
    Nc = Symbol("container"),
    Uc = Symbol("topContainer"),
    Bc = Symbol("containerSelector"),
    zc = Symbol("videoPlaybackContext"),
    Wc = Symbol("vastChainInfo"),
    {
      pubSub: qc,
      phaser: Hc,
      init: Gc,
      setGuest: Qc,
      ensureContainer: Yc,
      adParameters: Xc,
    } = ls,
    Kc = {
      wrapperId: null,
      duration: null,
      skipOffset: null,
      mediaFiles: [],
      adParameters: null,
      plugins: [],
      flags: 0,
    },
    Zc = (e, t) => {
      const n = (e.ownerDocument || document).createElement("div");
      return (n.id = t), Object.assign(n.style, Mc), e.appendChild(n), n;
    };
  class Jc extends kr {
    constructor(e) {
      super(), (this[Vc] = e), (this[Wc] = []);
    }
    get publishedEvents() {
      return this[Vc][qc].published;
    }
    get width() {
      return this._get("width");
    }
    get height() {
      return this._get("height");
    }
    get viewMode() {
      return this._get("viewMode");
    }
    get desiredBitrate() {
      return this._get("desiredBitrate");
    }
    get environmentVariables() {
      return this._get("environmentVariables");
    }
    get slot() {
      return this._get("slot");
    }
    get videoSlot() {
      return this._get("videoSlot");
    }
    get vastChain() {
      return this._get("vastChain");
    }
    get originVastUrl() {
      return this._get("originVastUrl");
    }
    get innermostVastUrl() {
      return this._get("innermostVastUrl");
    }
    get vastChainInfo() {
      return this[Wc];
    }
    addAdParamsVastChainInfo(e) {
      e.split(",").forEach((e) => {
        const t = e.split(":");
        4 === t.length && t.push("0"), this[Wc].push(t);
      });
    }
    addVastChainInfo(e, t, n, r) {
      let i;
      try {
        i = Rr(t);
      } catch (e) {
        i = "";
      }
      this[Wc].push([e, i, n, r ? "1" : "0", "1"]);
    }
  }
  class ed extends kr {
    get mediaFile() {
      return this._get("mediaFile");
    }
  }
  class td {
    constructor() {
      (this.uriBlacklistedForFriendlyIframe = null),
        (this.imaSdkPresent = null),
        (this.hasImaVpaidMediaFiles = null),
        (this.hasNonImaVpaidMediaFiles = null),
        (this.slotProvidedOnInitAd = null),
        (this.videoSlotProvidedOnInitAd = null);
    }
  }
  class nd {
    constructor() {
      (this.unmutedPlaybackAttempted = !1),
        (this.mutedPlaybackAttempted = !1),
        (this.playbackSuccessful = !1),
        (this.mutedPlaybackDisabled = !1),
        (this.adPaused = !1);
    }
    toString() {
      return (
        (this.unmutedPlaybackAttempted ? "Y" : "N") +
        (this.mutedPlaybackAttempted ? "Y" : "N") +
        (this.playbackSuccessful ? "Y" : "N") +
        (this.mutedPlaybackDisabled ? "Y" : "N") +
        (this.adPaused ? "Y" : "N")
      );
    }
  }
  class rd {
    constructor(e) {
      (this[Vc] = e),
        (this[jc] = null),
        (this[Rc] = new Jc(e)),
        (this[Dc] = new ed()),
        (this[$c] = new td()),
        (this[Fc] = Object.assign({}, Kc)),
        (this[Lc] = new Ic(e)),
        (this[Nc] = null),
        (this[Bc] = null),
        (this[Yc] = Gr(this[Yc])),
        (this[Xc] = null),
        (this[zc] = new nd());
    }
    get host() {
      return this[Vc];
    }
    get guest() {
      return this[jc];
    }
    get hostInfo() {
      return this[Rc];
    }
    get guestInfo() {
      return this[Dc];
    }
    get contextInfo() {
      return this[$c];
    }
    get videoPlaybackContext() {
      return this[zc];
    }
    get config() {
      return this[Fc];
    }
    get plugins() {
      return this[Vc][Hc].plugins;
    }
    get tracking() {
      return this[Lc];
    }
    get container() {
      return this[Nc];
    }
    get topContainer() {
      return this[Uc];
    }
    get containerSelector() {
      return this[Bc];
    }
    get adParameters() {
      return this[Xc];
    }
    publish(e, t, n) {
      return (
        void 0 === t && (t = []),
        void 0 === n && (n = null),
        this[Vc]._publish(e, t, n)
      );
    }
    track() {
      this[Lc].track(...arguments);
    }
    trackPixel(e, t) {
      return (
        (e = (function (e, t) {
          let { macros: n = {}, config: r = {} } = void 0 === t ? {} : t,
            i = e.replace(pi, (e, t) => {
              const i = t.toLowerCase();
              return null != hi[i]
                ? hi[i]({ macros: n, config: r })
                : null != n[i]
                ? encodeURIComponent("" + n[i])
                : "";
            });
          for (const e of Object.values(fi))
            i = i.replace(e.regexp, () => e.value(r));
          return i;
        })(e, { macros: t, config: this.config })),
        new cc(e).load()
      );
    }
    trackError() {
      this[Lc].trackError(...arguments);
    }
    isFlagEnabled(e) {
      return 0 !== (this[Fc].flags & e);
    }
    _normalizeConfig(e) {
      var t;
      return (
        (e.duration = ((t = e.duration), Yr(t))),
        (e.skipOffset = ((e) => {
          if (Xr(e)) return Kr(e.percent);
          if ("string" == typeof e) {
            const t = Qr.PERCENT.regex.exec(e);
            if (null != t) return Kr(parseFloat(t[1]));
          }
          return Yr(e);
        })(e.skipOffset)),
        e
      );
    }
    [Gc](e) {
      (this[Fc] = this._normalizeConfig(Object.assign({}, Kc, this[Fc], e))),
        this[Lc].configure(this[Fc]);
    }
    [Qc](e) {
      this[jc] = e;
    }
    [Yc]() {
      const { slot: e } = this[Rc],
        t = e.ownerDocument || document,
        n = "vpaid-container-" + $e(),
        r = `${n}-0`,
        i = t.createElement("style");
      (i.textContent = `#${r}, #${r} :not(html) { \n  margin: 0;\n  padding: 0;\n  border: 0;\n  font-size: 100%;\n  font: inherit;\n  vertical-align: baseline;\n  background: none;\n  opacity: 1;\n  border: none;\n  outline: none;\n  top: auto;\n  bottom: auto;\n  left: auto;\n  right: auto;\n }`),
        e.appendChild(i);
      const s = Zc(e, r);
      this[Uc] = s;
      let o = s,
        a = "#" + s.id;
      for (let e = 1; e < 5; ++e) (o = Zc(o, `${n}-${e}`)), (a += " #" + o.id);
      (this[Nc] = o), (this[Bc] = a);
    }
  }
  const id = Symbol("guest"),
    sd = Symbol("guestVpaidVersion"),
    od = Symbol("guestIframe"),
    ad = Symbol("guestSubscriptions"),
    ld = Symbol("managingSlotSize"),
    ud = Symbol("hadError"),
    cd = Symbol("isLoaded"),
    {
      phaser: dd,
      pubSub: hd,
      runtime: pd,
      clickThroughUrl: fd,
      options: md,
      internal: gd,
    } = ls;
  class vd {
    constructor(e) {
      void 0 === e && (e = {}),
        (this[dd] = new ui()),
        (this[hd] = new bs()),
        (this[id] = null),
        (this[od] = null),
        (this[ad] = []),
        (this[ld] = !1),
        (this[ud] = !1),
        (this[cd] = !1),
        (this[pd] = new rd(this)),
        (this[md] = e);
    }
    subscribe(e, t, n) {
      void 0 === n && (n = null),
        this[dd].runPhaseSync(
          "subscribe",
          [e, t, n],
          () => {
            this[hd].subscribe(e, t, n);
          },
          (e) => this._onError(e, "subscribe")
        );
    }
    unsubscribe(e, t) {
      this[dd].runPhaseSync(
        "unsubscribe",
        [e, t],
        () => {
          this[hd].unsubscribe(e, t);
        },
        (e) => this._onError(e, "unsubscribe")
      );
    }
    handshakeVersion(e) {
      return (this[sd] = e), "2.0";
    }
    initAd(e, t, n, r, i, s) {
      this[pd].track("initAd"), this._initAdAsync(e, t, n, r, i, s);
    }
    resizeAd(e, t, n) {
      const { hostInfo: r } = this[pd];
      try {
        r._putAll({ width: e, height: t, viewMode: n }),
          this._phasedGuestCall("resizeAd", [e, t, n]).catch((e) => {
            this._onError(e, "resizeAd");
          });
      } catch (e) {
        this._onError(e, "resizeAd");
      }
    }
    _createGuest(e) {
      return new Promise(function (e, t) {
        return t(new Error("Method is abstract"));
      });
    }
    _initAdAsync(e, t, n, r, i, s) {
      return new Promise(
        function (o, a) {
          let l, u;
          (l = this[pd]), ({ hostInfo: u } = l);
          var c = function () {
              try {
                return o();
              } catch (e) {
                return a(e);
              }
            },
            d = function (e) {
              try {
                return this._onError(e, "initAd"), c();
              } catch (e) {
                return a(e);
              }
            }.bind(this);
          try {
            let o, a, h, p;
            if (
              (u._putAll({
                width: e,
                height: t,
                viewMode: n,
                desiredBitrate: r,
                environmentVariables: s,
              }),
              null == s)
            )
              l.track("no-envvars");
            else {
              let n, r, i;
              ({ slot: n, videoSlot: r, sendErrorInfo: i } = s),
                u._putAll({ slot: n, videoSlot: r }),
                (this[hd].options.sendErrorInfo = !0 === i),
                null == n
                  ? (l.contextInfo.slotProvidedOnInitAd = !1)
                  : ((l.contextInfo.slotProvidedOnInitAd = !0),
                    (this[ld] =
                      null != n.style &&
                      (0 === n.clientWidth || 0 === n.clientHeight)),
                    this._maybeResizeSlot(e, t)),
                (l.contextInfo.videoSlotProvidedOnInitAd = null != r);
            }
            return Promise.resolve(
              this._createGuest({
                width: e,
                height: t,
                viewMode: n,
                desiredBitrate: r,
                creativeData: i,
                envVars: s,
              })
            ).then(
              function (i) {
                try {
                  return (
                    ({ iframe: o, vpaid: a, adParameters: h } = i),
                    (this[id] = a),
                    (this[od] = o),
                    this._guestSubscribeAll(),
                    Promise.resolve(
                      this._phasedGuestCall("handshakeVersion", [this[sd]], !0)
                    ).then(
                      function (i) {
                        try {
                          return (
                            (p = { AdParameters: h }),
                            Promise.resolve(
                              this._phasedGuestCall("initAd", [
                                e,
                                t,
                                n,
                                r,
                                p,
                                Object.assign({}, s, { sendErrorInfo: !0 }),
                              ])
                            ).then(function (e) {
                              try {
                                return c();
                              } catch (e) {
                                return d(e);
                              }
                            }, d)
                          );
                        } catch (e) {
                          return d(e);
                        }
                      }.bind(this),
                      d
                    )
                  );
                } catch (e) {
                  return d(e);
                }
              }.bind(this),
              d
            );
          } catch (e) {
            d(e);
          }
        }.bind(this)
      );
    }
    _maybeResizeSlot(e, t) {
      if (this[ld]) {
        const {
          hostInfo: { slot: n },
        } = this[pd];
        Object.assign(n.style, { width: `${e}px`, height: `${t}px` });
      }
    }
    _publish(e, t, n) {
      switch ((void 0 === t && (t = []), void 0 === n && (n = null), e)) {
        case be.AdError: {
          const [r] = t;
          if (!this._processErrorAndDecideOnPublish({ error: r, method: n }))
            return Promise.resolve();
          if ("guest" !== n) return this._phasedGuestEvent(e, [Ni(r)]);
          break;
        }
        case be.AdClickThru: {
          const [n] = t;
          if ("string" != typeof n)
            return this._phasedGuestEvent(e, [this[fd]]);
          break;
        }
      }
      return this._phasedGuestEvent(e, t);
    }
    _guestSubscribeAll() {
      var e = this;
      const t = Object.keys(be).map((e) => be[e]);
      for (let n = 0; n < t.length; ++n) {
        const r = t[n],
          i = function () {
            for (var t = arguments.length, n = new Array(t), i = 0; i < t; i++)
              n[i] = arguments[i];
            e._onGuestEvent(r, n);
          },
          s = [i, r];
        this._guestCall("subscribe", s), this[ad].push(s);
      }
    }
    _guestUnsubscribeAll() {
      if (null == this[id]) return;
      const e = this[ad].splice(0);
      for (let t = 0; t < e.length; ++t)
        try {
          this._guestCall("unsubscribe", e[t]);
        } catch (e) {}
    }
    _onGuestEvent(e, t) {
      switch (e) {
        case be.AdLoaded:
          this._handleAdLoadedGuestEvent(t);
          break;
        case be.AdError:
          this._handleAdErrorGuestEvent(t);
          break;
        case be.AdMutedUnmutedPlayback:
          this._handleAdMutedUnmutedPlayback(t);
          break;
        default:
          this._publish(e, t, "guest");
      }
    }
    _handleAdMutedUnmutedPlayback(e) {
      Object.assign(this[pd].videoPlaybackContext, e[0]);
    }
    _handleAdLoadedGuestEvent(e) {
      (this[cd] = !0), this._publish(be.AdLoaded, e, "guest");
    }
    _handleAdErrorGuestEvent(e) {
      const [t, n] = e;
      let r;
      (r = this._guestIsInternalVpaid()
        ? n
        : {
            message:
              "VAST error 901 due to AdError event" +
              (ze(t) ? " (no AdError message)" : `: ${t}`),
            code: 901,
            cause: null == n ? null : n,
          }),
        this._publish(be.AdError, [r.message, r], "guest");
    }
    _guestIsInternalVpaid() {
      return null != this[id] && !0 === this[id][gd];
    }
    _guestCall(e, t) {
      if (null == this[id]) throw new Tr();
      if (
        !1 === this[cd] &&
        "initAd" !== e &&
        "subscribe" !== e &&
        "unsubscribe" !== e &&
        "handshakeVersion" !== e
      )
        throw new Tr();
      "resizeAd" === e && this._maybeResizeSlot(...t);
      const n = this[id][e];
      if ("function" != typeof n) throw new Ir(e);
      return n.apply(this[id], t);
    }
    _phasedGuestCallSync(e, t) {
      var n = this;
      return this[dd].runPhaseSync(
        e,
        t,
        function () {
          for (var t = arguments.length, r = new Array(t), i = 0; i < t; i++)
            r[i] = arguments[i];
          return n._guestCall(e, r);
        },
        (t) => this._onError(t, e, !0)
      );
    }
    _phasedGuestCall(e, t, n) {
      return new Promise(
        function (r, i) {
          var s;
          (s = this), void 0 === n && (n = !1);
          var o = function () {
              try {
                return r();
              } catch (e) {
                return i(e);
              }
            },
            a = function (t) {
              try {
                return this._onError(t, e, !0), o();
              } catch (e) {
                return i(e);
              }
            }.bind(this);
          try {
            return Promise.resolve(
              this[dd].runPhase(
                e,
                t,
                function () {
                  for (
                    var t = arguments.length, r = new Array(t), i = 0;
                    i < t;
                    i++
                  )
                    r[i] = arguments[i];
                  const o = s._guestCall(e, r);
                  return n ? o : null;
                },
                () => this[ud]
              )
            ).then(function (e) {
              try {
                return o();
              } catch (e) {
                return a(e);
              }
            }, a);
          } catch (e) {
            a(e);
          }
        }.bind(this)
      );
    }
    _phasedGuestEvent(e, t) {
      return new Promise(
        function (n, r) {
          var i;
          i = this;
          var s = function () {
              try {
                return (
                  e === be.AdStopped && this._removeGuestIframe(),
                  e === be.AdError &&
                    this[md].destroyAdOnAdError &&
                    (this._unloadVideoSlot(),
                    this._removeGuestIframe(),
                    this._removeAdContainers()),
                  n()
                );
              } catch (e) {
                return r(e);
              }
            }.bind(this),
            o = function (t) {
              try {
                return this._onError(t, e), s();
              } catch (e) {
                return r(e);
              }
            }.bind(this);
          try {
            return Promise.resolve(
              this[dd].runPhase(
                e,
                t,
                function () {
                  var t = arguments;
                  return new Promise(function (n, r) {
                    var s, o, a;
                    if (Pe.indexOf(e) >= 0)
                      return Promise.resolve(i._dispose()).then(
                        function (e) {
                          try {
                            return l.call(this);
                          } catch (e) {
                            return r(e);
                          }
                        }.bind(this),
                        r
                      );
                    function l() {
                      for (s = t.length, o = new Array(s), a = 0; a < s; a++)
                        o[a] = t[a];
                      return i[hd].publish(e, o), n();
                    }
                    return l.call(this);
                  });
                },
                () => this[ud] && Pe.indexOf(e) < 0
              )
            ).then(function (e) {
              try {
                return s();
              } catch (e) {
                return o(e);
              }
            }, o);
          } catch (e) {
            o(e);
          }
        }.bind(this)
      );
    }
    _removeGuestIframe() {
      try {
        this[od].parentNode.removeChild(this[od]);
      } catch (e) {}
      this[od] = null;
    }
    _removeAdContainers() {
      try {
        this[pd].topContainer.parentNode.removeChild(this[pd].topContainer);
      } catch (e) {}
    }
    _unloadVideoSlot() {
      try {
        const e = this[pd].hostInfo.videoSlot;
        e.pause(), e.removeAttribute("src"), e.load();
      } catch (e) {}
    }
    _addPlugin(e) {
      this[dd].addPlugin(e);
    }
    _processErrorAndDecideOnPublish(e, t) {
      if (null != e && "GuestNotAvailableError" === e.name) return !1;
      const n = !this[ud];
      return n && ((this[ud] = !0), this._guestUnsubscribeAll()), n;
    }
    _createErrorMessage(e, t, n) {
      return (
        void 0 === n && (n = !1),
        e instanceof Or
          ? e.toString()
          : n
          ? `VAST error 901 due to error on ${t}${
              null == e || ze(e.message)
                ? " (no error message)"
                : `: ${e.message}`
            }`
          : null == e.message
          ? "Unknown internal error"
          : Ni(e.message).substring(0, 1e3)
      );
    }
    _onError(e, t, n) {
      if (
        (void 0 === n && (n = !1), this._processErrorAndDecideOnPublish(e, t))
      ) {
        const r = this._createErrorMessage(e, t, n);
        this._phasedGuestEvent(be.AdError, [
          r,
          { message: r, code: null != e.code ? e.code : "901" },
        ]);
      }
    }
    _dispose() {
      return new Promise(
        function (e, t) {
          if (this[md].autoDisposeDisabled) return e();
          var n = function () {
              try {
                var n = function () {
                    try {
                      return e();
                    } catch (e) {
                      return t(e);
                    }
                  },
                  r = function (e) {
                    try {
                      return n();
                    } catch (e) {
                      return t(e);
                    }
                  };
                try {
                  return Promise.resolve(
                    new Promise(function (e, t) {
                      var n;
                      function r() {
                        if (Oc.length > 0) {
                          let e;
                          return (
                            (e = Oc.splice(0)),
                            Promise.resolve(Promise.all(e)).then(function (e) {
                              try {
                                return r;
                              } catch (e) {
                                return t(e);
                              }
                            }, t)
                          );
                        }
                        return [1];
                      }
                      return (n = function (e) {
                        for (; e; ) {
                          if (e.then) return void e.then(n, t);
                          try {
                            if (e.pop) {
                              if (e.length) return e.pop() ? i.call(this) : e;
                              e = r;
                            } else e = e.call(this);
                          } catch (e) {
                            return t(e);
                          }
                        }
                      }.bind(this))(r);
                      function i() {
                        return e();
                      }
                    })
                  ).then(function (e) {
                    try {
                      return n();
                    } catch (e) {
                      return r();
                    }
                  }, r);
                } catch (e) {
                  r();
                }
              } catch (e) {
                return t(e);
              }
            },
            r = function (e) {
              try {
                return n();
              } catch (e) {
                return t(e);
              }
            };
          try {
            return Promise.resolve(this[dd].dispose()).then(function (e) {
              try {
                return n();
              } catch (e) {
                return r();
              }
            }, r);
          } catch (e) {
            r();
          }
        }.bind(this)
      );
    }
  }
  var yd;
  ((e) => {
    const t = Object.keys(ke);
    for (let n = 0; n < t.length; n++) {
      const r = t[n],
        { defaultValue: i, writable: s } = ke[r],
        o = si(r);
      Du(e, `get${o}`, i), s && $u(e, `set${o}`);
    }
  })((yd = vd.prototype)),
    ((e) => {
      const t = Object.keys(we).map((e) => we[e]);
      for (let n = 0; n < t.length; ++n) {
        const r = t[n];
        $u(e, r);
      }
    })(yd);
  const { runtime: bd, init: _d, setGuest: wd, adCompanions: Ad } = ls,
    kd = Symbol("loaders");
  class Sd extends vd {
    constructor(e, t) {
      void 0 === t && (t = {}),
        super(t),
        (this[kd] = e),
        this._preprocessHashConfig();
    }
    getAdDuration() {
      return this._getPropertyValueWithConfigFallback(
        "adDuration",
        this[bd].config.duration
      );
    }
    getAdWidth() {
      return this._getPropertyValueWithConfigFallback(
        "adWidth",
        this[bd].hostInfo.width
      );
    }
    getAdHeight() {
      return this._getPropertyValueWithConfigFallback(
        "adHeight",
        this[bd].hostInfo.height
      );
    }
    getAdCompanions() {
      return null != this[Ad] ? this[Ad] : super.getAdCompanions();
    }
    _getPropertyValueWithConfigFallback(e, t) {
      const n = super[`get${si(e)}`]();
      return n === ke[e].defaultValue && null != t ? t : n;
    }
    _createGuest(e) {
      return new Promise(
        function (t, n) {
          let r, i, s, o;
          return (
            (r = ((e) => {
              const t = ((e) =>
                null == e || "string" == typeof e ? e : e.AdParameters)(e);
              try {
                return JSON.parse(t);
              } catch (e) {
                throw new Error(`Failed to parse AdParameters "${t}"`);
              }
            })(e.creativeData)),
            this._loadConfig(r),
            this[bd].tracking.configured
              ? Promise.resolve(
                  this._loadMediaFile(r.mediaFiles, r.adParameters, e)
                ).then(
                  function (e) {
                    try {
                      return (
                        ({ iframe: i, vpaid: s, adParameters: o } = e),
                        this[bd][wd](s),
                        t({ iframe: i, vpaid: s, adParameters: o })
                      );
                    } catch (e) {
                      return n(e);
                    }
                  }.bind(this),
                  n
                )
              : n(new Error("Invalid configuration"))
          );
        }.bind(this)
      );
    }
    _loadMediaFile(e, t, n) {
      return new Promise(
        function (r, i) {
          let s, o, a, l, u, c, d, h, p, f, m, g, v, y;
          return (
            ({
              width: s,
              height: o,
              desiredBitrate: a,
              envVars: { videoSlot: l },
            } = n),
            (u = this[bd].contextInfo),
            (c = Object.keys(this[kd])),
            (d = (function (e, t) {
              return (
                void 0 === t && (t = [We.vast, We.vpaid, We.video]),
                e.reduce((e, n) => {
                  const r = Ke(n);
                  return (
                    t.indexOf(r) >= 0 &&
                      (null == e[r] && (e[r] = []), e[r].push(n)),
                    e
                  );
                }, {})
              );
            })(e, c)),
            (h = ((e) => {
              let { [We.vpaid]: t } = e;
              return null == t
                ? 0
                : t.filter((e) => {
                    let { uri: t } = e;
                    return qr(t);
                  }).length;
            })(d)),
            (u.hasImaVpaidMediaFiles = h > 0),
            (u.hasNonImaVpaidMediaFiles = ((e, t) => {
              const n = e[We.vpaid];
              return null == n
                ? Object.keys(e).length > 0
                : n.length > t || Object.keys(e).length > 1;
            })(d, h)),
            (u.imaSdkPresent =
              (() => {
                let e = null;
                try {
                  e = window.parent.google.ima.VERSION;
                } catch (e) {}
                return "string" == typeof e;
              })() || zr.test(window.location.href)),
            this[bd].isFlagEnabled(2) &&
              ((e) => {
                let {
                  imaSdkPresent: t,
                  hasImaVpaidMediaFiles: n,
                  hasNonImaVpaidMediaFiles: r,
                } = e;
                return t && n && r;
              })(u) &&
              ((e) => {
                const t = e[We.vpaid].filter((e) => {
                  let { uri: t } = e;
                  return !qr(t);
                });
                t.length > 0 ? (e[We.vpaid] = t) : delete e[We.vpaid];
              })(d),
            (p = ((e, t, n, r, i) => {
              const s = ((e, t, n) => {
                const r = Ci(e * _i),
                  i = Ci(t * _i),
                  s = Ci(e),
                  o = Ci(t),
                  a = Ci(n);
                return [
                  {
                    filter: (e) => {
                      let { width: t, height: n, bitrate: l } = e;
                      return t >= s && t <= r && n >= o && n <= i && l <= a;
                    },
                    selector: Si,
                  },
                  {
                    filter: (e) => {
                      let { width: t, height: n, bitrate: r } = e;
                      return t <= s && n <= o && r <= a;
                    },
                    selector: Pi,
                  },
                  {
                    filter: (e) => {
                      let { bitrate: t } = e;
                      return isFinite(a) && t <= a;
                    },
                    selector: Pi,
                  },
                  { filter: () => !0, selector: Si },
                ];
              })(t, n, r);
              return ((e, t, n) => {
                const r = Object.keys(e).sort(Oi);
                let i = null,
                  s = 0;
                for (; null == i && s < r.length; ) {
                  const o = r[s],
                    a = e[o];
                  (i = (0, Ti[o])(a, t, n)), ++s;
                }
                return i;
              })(e, s, i);
            })(d, s, o, a, l)),
            null == p
              ? i(new Or("No valid media files found", 403))
              : (this[bd].guestInfo._put("mediaFile", p),
                (f = Ke(p)),
                (m = this[kd][f]),
                null == m
                  ? i(new Or(`Unsupported media file of type ${f}`, 403))
                  : ((g = Bi()),
                    this[bd].tracking.addMetric(116, () => g),
                    Promise.resolve(m(this, p, t, n)).then(
                      function (e) {
                        try {
                          return (
                            (v = e),
                            (y = Bi()),
                            this[bd].tracking.addMetric(117, () => y),
                            r(v)
                          );
                        } catch (e) {
                          return i(e);
                        }
                      }.bind(this),
                      i
                    )))
          );
        }.bind(this)
      );
    }
    _preprocessHashConfig() {
      const e = jr();
      if (null == e) return;
      const t = ((e) => {
        const t = e.indexOf("#");
        return t >= 0 ? e.substr(t + 1) : null;
      })(e.src);
      null != t && "" !== t && this._loadConfig(decodeURIComponent(t), !0);
    }
    _loadConfig(e, t) {
      if ((void 0 === t && (t = !1), null != e)) {
        if (
          (((e, t) => {
            t ||
              (null == e.ctx &&
                null == e.wrapperId &&
                (e.wrapperId = "12000000"));
          })(e, t),
          this[bd][_d](e),
          Array.isArray(e.plugins))
        ) {
          const t = {
            id: "vast-chain-tracking",
            config: {
              vastChainInfo:
                null != e.customDimensions ? e.customDimensions[116] : null,
            },
          };
          e.plugins.push(t);
        }
        this._addPlugins(e.plugins);
      }
    }
    _addPlugins(e) {
      if (null == e || this[bd].plugins.length > 0) return;
      if (0 === e.length) return;
      const t = {};
      for (let n = 0; n < e.length; ++n) {
        const { id: r, config: i } = e[n];
        let s;
        const o = r.indexOf(".");
        if (o < 0) s = t[r] = i || {};
        else {
          const e = r.substr(0, o);
          s = Object.assign({}, t[e], i);
        }
        try {
          this._createAndAddPlugin(r, s);
        } catch (e) {
          console.warn(`Error creating plugin "${r}": ${e}`);
        }
      }
    }
    _createAndAddPlugin(e, t) {
      const n = ms.create(e, t, this[bd]);
      return this._addPlugin(n), n;
    }
  }
  const Pd = {
    [We.vpaid]: (e, t, n, r) =>
      new Promise(function (i, s) {
        let o, a, l, u, c, d, h;
        return (
          ({ contextInfo: o } = e[ju]),
          ({ uri: a } = t),
          (l = o.uriBlacklistedForFriendlyIframe =
            ((e) => Mu.some((t) => t.test(e)))(a)),
          (u = e[ju].isFlagEnabled(4) || l ? "inline" : null),
          Promise.resolve(
            (function (e, t, n) {
              return new Promise(function (r, i) {
                return (
                  void 0 === n && (n = {}),
                  r(("inline" === n.mode ? Nl : Ul)(e, t))
                );
              });
            })(a, r.envVars.slot, { mode: u })
          ).then(function (t) {
            try {
              return (
                ({ iframe: c, vpaid: d, time: h } = t),
                Promise.resolve(
                  e[Vu]._runStage("afterLoadVpaid", [{ uri: a, time: h }])
                ).then(function (e) {
                  try {
                    return i({ iframe: c, vpaid: d, adParameters: n });
                  } catch (e) {
                    return s(e);
                  }
                }, s)
              );
            } catch (e) {
              return s(e);
            }
          }, s)
        );
      }),
    [We.video]: (e, t, n) =>
      new Promise(function (r, i) {
        const { clickThroughUrl: s, skipOffset: o } = e[Tu].config;
        null == e[Ou] && (e[Ou] = s);
        const a = e[Tu].isFlagEnabled(1),
          l = e[Tu].isFlagEnabled(8);
        return r({
          vpaid: new xu(
            t.uri,
            Object.assign({}, e[Iu], {
              skipOffset: o,
              noMutedAutoplayFallback: a,
              noPauseOnClickThrough: l,
            })
          ),
          adParameters: n,
        });
      }),
  };
  (() => {
    const e =
      (((e) => {
        const t = ((e) => {
          const t = [];
          let n = e,
            r = 0;
          for (; r++ < 10 && null != n && n !== Object.prototype; ) {
            const e = Object.getOwnPropertyDescriptors(n);
            t.push(...Object.keys(e).filter((e) => t.indexOf(e) < 0)),
              (n = Object.getPrototypeOf(n));
          }
          return t.filter(
            (t) => Fr.indexOf(t) < 0 && "function" == typeof e[t]
          );
        })(e);
        for (let n = 0; n < t.length; ++n) {
          const r = t[n];
          Lr(e, r);
        }
      })(Sd),
      new Sd(Pd, {}));
    window.getVPAIDAd = () => e;
  })();
})();
//# sourceMappingURL=https://ene-debug-scripts.doubleverify.io/vpaid/1.3.1/vpaid-transformer-no-csw.js.map
