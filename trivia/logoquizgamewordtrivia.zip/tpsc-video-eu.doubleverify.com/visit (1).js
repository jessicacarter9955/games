try {
  var dv_win = window._dv_win || window.parent._dv_win;
  dv_win["dvCallback_1795522849884791"](
    $dv,
    window,
    "31dabb2e65094cfc8a2d3056811d410e",
    "maestro-ew1.tps.dv.tech",
    { ce: { ddt: 1, dt: 1 } }
  );
} catch (e) {
  try {
    var image = window.document.createElement("img");
    image.src =
      ("https://tpsc-video-eu.doubleverify.com/visit.jpg" ||
        window.location.protocol + "//tps30.doubleverify.com/visit.jpg") +
      "?ctx=818052&cmp=1619415&dvtagver=6.1.src&dvp_cbError=" +
      encodeURIComponent(e.message);
  } catch (e) {}
}
try {
  $dv.pubSub.publish("ImpressionServed", $uid);
  $dv.pubSub.publish("ImpressionServed", $frmId);
} catch (e) {}
