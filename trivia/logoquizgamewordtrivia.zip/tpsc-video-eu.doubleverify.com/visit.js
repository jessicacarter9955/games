try {
  var dv_win = window._dv_win || window.parent._dv_win;
  dv_win["dvCallback_1795522849376961"](
    $dv,
    window,
    "4b4d5c4e87a04527b7f296e5c73f4b29",
    "maestro-ew1.tps.dv.tech",
    { ce: { ddt: 1, dt: 1 } }
  );
} catch (e) {
  try {
    var image = window.document.createElement("img");
    image.src =
      ("https://tpsc-video-eu.doubleverify.com/visit.jpg" ||
        window.location.protocol + "//tps30.doubleverify.com/visit.jpg") +
      "?ctx=818052&cmp=1619415&dvtagver=6.1.src&dvp_cbError=" +
      encodeURIComponent(e.message);
  } catch (e) {}
}
try {
  $dv.pubSub.publish("ImpressionServed", $uid);
  $dv.pubSub.publish("ImpressionServed", $frmId);
} catch (e) {}
