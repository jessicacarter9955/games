!(function () {
  try {
    var e =
        "undefined" != typeof window
          ? window
          : "undefined" != typeof global
          ? global
          : "undefined" != typeof globalThis
          ? globalThis
          : "undefined" != typeof self
          ? self
          : {},
      n = new e.Error().stack;
    n &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[n] = "c34b4be6-d867-57c2-8276-7ba2af9999bd"));
  } catch (e) {}
})();
(function () {
  try {
    var e =
      typeof window < `u`
        ? window
        : typeof global < `u`
        ? global
        : typeof globalThis < `u`
        ? globalThis
        : typeof self < `u`
        ? self
        : {};
    (e._sentryModuleMetadata = e._sentryModuleMetadata || {}),
      (e._sentryModuleMetadata[new e.Error().stack] = (function (e) {
        for (var t = 1; t < arguments.length; t++) {
          var n = arguments[t];
          if (n != null) for (var r in n) n.hasOwnProperty(r) && (e[r] = n[r]);
        }
        return e;
      })({}, e._sentryModuleMetadata[new e.Error().stack], {
        "_sentryBundlerPluginAppKey:crazygames-gameframe": !0,
      }));
    var t = new e.Error().stack;
    t &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[t] = `f68a09d0-600f-4553-9cb0-36d408cf2cf9`),
      (e._sentryDebugIdIdentifier = `sentry-dbid-f68a09d0-600f-4553-9cb0-36d408cf2cf9`));
  } catch {}
})();
import {
  D as e,
  E as t,
  Ft as n,
  H as r,
  Ht as i,
  Lt as a,
  Mt as o,
  Xt as s,
  an as ee,
  bn as c,
  c as l,
  gn as u,
  jt as d,
  ln as f,
  nn as te,
  rn as p,
  s as m,
  tn as h,
  un as g,
  wn as _,
  xn as v,
  yn as y,
} from "../../bundle.js";
import { t as b } from "./kpsB5uDx.js";
import { i as x, n as S, r as C, t as w } from "./DCXju1XY.js";
import { n as T, t as ne } from "./C-s8CM732.js";
var E = _(y()),
  D = g(),
  O = `WebGL 1.0`,
  k = `WebGL 2.0`,
  A = class {
    constructor(e) {
      v(this, `missingRequirements`, void 0),
        v(this, `graphicsAPI`, void 0),
        (this.graphicsAPI = e.graphicsAPI || []),
        (this.missingRequirements = !e.graphicsAPI);
    }
    canUseWebGL1() {
      return this.graphicsAPI.indexOf(O) >= 0;
    }
    canUseWebGL2() {
      return this.graphicsAPI.indexOf(k) >= 0;
    }
  },
  j = u(),
  M = new l(`unity56ready`),
  N = () => {
    let r = (0, D.c)(25),
      { onLoadFinished: l } = (0, E.useContext)(o),
      { isFullscreen: u } = (0, E.useContext)(t),
      { isGameDisabled: g } = (0, E.useContext)(d),
      [_, v] = (0, E.useState)(0),
      [y, O] = (0, E.useState)(`loading`),
      [k, N] = (0, E.useState)(null),
      L = E.useRef(null),
      R = E.useRef(null),
      z;
    r[0] === Symbol.for(`react.memo_cache_sentinel`)
      ? ((z = p()), (r[0] = z))
      : (z = r[0]);
    let B = z;
    if (R.current === null) {
      let e;
      r[1] === Symbol.for(`react.memo_cache_sentinel`)
        ? ((e = new ne()), (r[1] = e))
        : (e = r[1]),
        (R.current = e);
    }
    let V, H;
    r[2] === g
      ? ((V = r[3]), (H = r[4]))
      : ((V = () => {
          if (g) {
            L.current &&= (L.current.remove(), null);
            return;
          }
          let e = w(m(`unity56`));
          (L.current = e), n(P), te().appendChild(e);
        }),
        (H = [g]),
        (r[2] = g),
        (r[3] = V),
        (r[4] = H)),
      (0, E.useEffect)(V, H);
    let U, W;
    r[5] !== u || r[6] !== y
      ? ((U = () => {
          y === `loaded` &&
            (u
              ? M.sendMessage({ type: `unity56RequestFullScreen` })
              : M.sendMessage({ type: `unity56DisableFullScreen` }));
        }),
        (W = [u, y]),
        (r[5] = u),
        (r[6] = y),
        (r[7] = U),
        (r[8] = W))
      : ((U = r[7]), (W = r[8])),
      (0, E.useEffect)(U, W);
    let G, K;
    r[9] !== u || r[10] !== l
      ? ((G = () => {
          let e = function (e) {
            bb19: switch (e.data.type) {
              case `loadProgress`:
                v(R.current.trackProgress(e.data.progress));
                break bb19;
              case `loadFinished`:
                R.current.trackLoadFinished(),
                  B.fullscreen === `REQUIRED` && !f() && !u
                    ? O(`fullscreen`)
                    : (O(`loaded`), l());
                break bb19;
              case `syncUnityData`:
                a.Instance.autoSyncUnityData();
                break bb19;
              case `unityMemoryUsage`:
                s.getInstance().sendEvent(e.data.usageData);
                break bb19;
              case `unityError`:
                N(e.data), O(`error`), x(`unity-game-load-failed`, e.data);
            }
          };
          return (
            window.addEventListener(`message`, e),
            () => {
              window.removeEventListener(`message`, e);
            }
          );
        }),
        (K = [B, l, u]),
        (r[9] = u),
        (r[10] = l),
        (r[11] = G),
        (r[12] = K))
      : ((G = r[11]), (K = r[12])),
      (0, E.useEffect)(G, K);
    let q, J;
    r[13] === Symbol.for(`react.memo_cache_sentinel`)
      ? ((q = () => {
          let e = p().loaderOptions,
            t = {
              loaderOptions: e,
              companyName: `CrazyGames`,
              productName: h(),
            },
            n = { gameLink: p().gameLink, userInfo: ee() };
          M.sendMessage({
            type: `unity56config`,
            config: t,
            oldSdkInitObject: n,
          });
          let r = async () => {
              let e = await o();
              return e.missingRequirements || e.canUseWebGL1()
                ? C()
                  ? null
                  : `unity-unavailable`
                : e.canUseWebGL2()
                ? S()
                  ? null
                  : `unity-unavailable`
                : C()
                ? null
                : `unity-unavailable`;
            },
            o = async () => {
              try {
                return new A(await (await fetch(e.moduleJsonUrl)).json());
              } catch {
                return new A({});
              }
            },
            s = F,
            l = async () => {
              if (await r()) {
                c.error(`Unity WebGL is not available on this browser`),
                  O(`error`),
                  x(`unity-unavailable`);
                return;
              }
              R.current.trackLoadStarted(), await a.Instance.waitForAPS(), s();
            },
            u = I;
          return (
            l(),
            i().addAdFinishedListener(u),
            () => {
              i().removeAdFinishedListener(u);
            }
          );
        }),
        (J = []),
        (r[13] = q),
        (r[14] = J))
      : ((q = r[13]), (J = r[14])),
      (0, E.useEffect)(q, J);
    let Y;
    r[15] === l
      ? (Y = r[16])
      : ((Y = async () => {
          O(`loaded`), l();
        }),
        (r[15] = l),
        (r[16] = Y));
    let X = Y,
      Z;
    r[17] !== k || r[18] !== X || r[19] !== _ || r[20] !== y
      ? ((Z = (() => {
          switch (y) {
            case `loading`:
              return (0, j.jsx)(j.Fragment, {
                children: (0, j.jsx)(e, { progress: _, showProgress: !0 }),
              });
            case `error`:
              return (0, j.jsx)(b, {
                warning: k ? `unity-load-failed` : `unity-unavailable`,
              });
            case `fullscreen`:
              return (0, j.jsx)(b, { warning: `force-fullscreen`, close: X });
            default:
              return null;
          }
        })()),
        (r[17] = k),
        (r[18] = X),
        (r[19] = _),
        (r[20] = y),
        (r[21] = Z))
      : (Z = r[21]);
    let Q;
    r[22] === Symbol.for(`react.memo_cache_sentinel`)
      ? ((Q = (0, j.jsx)(T, {})), (r[22] = Q))
      : (Q = r[22]);
    let $;
    return (
      r[23] === Z
        ? ($ = r[24])
        : (($ = (0, j.jsxs)(j.Fragment, { children: [Z, Q] })),
          (r[23] = Z),
          (r[24] = $)),
      $
    );
  };
function P() {
  M.sendMessage({ type: `focusGame` });
}
function F() {
  let e = !1,
    t =
      new URLSearchParams(window.location.search).get(`enableUnityCache`) ===
      `true`;
  r() && !t && (e = !0);
  let n = e ? {} : { default: `immutable` };
  M.sendMessage({ type: `loadGame`, cacheControl: n });
}
function I() {
  M.sendMessage({ type: `focusGame` });
}
export { N as default };
//# debugId=c34b4be6-d867-57c2-8276-7ba2af9999bd
