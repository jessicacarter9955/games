if (
  ((window.ftUtils = window.ftUtils || {}),
  (window.ftUtils.common = {
    $: function (e) {
      var t = this,
        i = e;
      return (
        "string" == typeof (e = e || t.markup.div.id) &&
          (i = t.w.document.getElementById(e)),
        new t.$Base({ o: t, y: i })
      );
    },
    $Base: function (t) {
      var i = this;
      (i.$ = !0),
        (i.o = t.o),
        (t.y = t.y || {}),
        (i.target = t.y.$ ? t.y.target : t.y),
        (i.style = t.y.style || {}),
        (i.parent = function () {
          return i.target.parentNode && i.target.parentNode !== t.o.w.document
            ? t.o.$(i.target.parentNode)
            : i;
        }),
        (i.hash = function () {
          return 1;
        }),
        (i.alignTo = function (e) {
          return (
            e.$ && e.target && (e = e.target),
            (t.y.style.left = t.o.$(e).x() + "px"),
            (t.y.style.top = t.o.$(e).y() + "px"),
            i
          );
        }),
        (i.x = function () {
          return t.o.getAbsLeft(i.target);
        }),
        (i.y = function () {
          return t.o.getAbsTop(i.target);
        }),
        (i.getStyle = function (e) {
          var t = window.getComputedStyle(i.target, "");
          if (null == t) return t;
          try {
            return t[e];
          } catch (e) {
            return "auto";
          }
        });
    },
    addEventListener: function (e, t) {
      var i = this;
      void 0 === i.eventListeners[e] && (i.eventListeners[e] = []),
        "function" == typeof t && i.eventListeners[e].unshift(t),
        (("adonpage" === e && i.adDisplayed) ||
          ("adready" === e && i.adReady)) &&
          t.call(i);
    },
    addExtraValuesToParams: function () {
      function e(e, t) {
        var i = {};
        n.params.split("&").forEach(function (e) {
          e = e.split("=");
          i[e[0]] = e[1];
        }),
          t &&
            !1 === i.hasOwnProperty(e) &&
            ((t = ~t.indexOf("&") ? encodeURIComponent(t) : t),
            (n.params += "&" + e + "=" + t));
      }
      var n = this,
        a = JSON.parse("[]");
      e(
        "ftExpTrack",
        ((e) => {
          var t = window[e + "_" + n.placement.id],
            i = a.length;
          if (!t)
            for (t = ""; i--; )
              if (window[e + "_" + a[i]]) {
                t = window[e + "_" + a[i]];
                break;
              }
          return t;
        })("ftExpTrack")
      ),
        e("click", n.click);
    },
    addFrequencySignalling: function () {
      var i = this;
      if (
        !i.campaign.hasOwnProperty("frequencySignal") ||
        !i.campaign.frequencySignal
      )
        return !1;
      i.impressions = (i.impressions || []).map(function (e) {
        return i.convertUrlProtocol(e);
      });
      var e = [],
        t = i.decode("%5C"),
        n = function (e) {
          var t = 1e3 * m;
          return new Date(Math.floor((1e3 * e) / t) * t + 1e3 * a);
        },
        a = function () {
          var e = parseInt(window["ftTimeZone_" + i.placement.id] || 0, 10),
            t = Math.floor(e / 100);
          return 3600 * t + 60 * Math.floor(e - 100 * t);
        },
        r = (i.campaign.frequencySignal.impressionType || "" || "").replace(
          RegExp("[^" + t + "w]"),
          ""
        ),
        o = parseInt(i.campaign.frequencySignal.impressionThreshold || "", 10),
        s = Number(i.campaign.frequencySignal.periodUnits || ""),
        c = 0,
        d = window["ftSegmentList_" + i.placement.id] || {},
        p = parseInt(window["ftTimestamp_" + i.placement.id], 10),
        l = p,
        m = "2" == i.campaign.frequencySignal.period ? 3600 : 86400,
        u = n(p);
      if (!isNaN(o) && !isNaN(s) && r) {
        for (var f = r, h = f + "vp", g = d.length; g--; )
          if (d[g].m == h) {
            var v = d[g].s.match(
                RegExp("^" + f + "(" + t + "d+)_(" + t + "d+)")
              ) || ["", "", ""],
              w = parseInt(v[1], 10),
              v = parseInt(v[2], 10);
            isNaN(w) && (c = w), isNaN(v) && (l = v);
            break;
          }
        if (
          (((e, t, i) => ((e = n(e)).setSeconds(e.getSeconds() + t * i), e))(
            l,
            s,
            m
          ) <= u && ((l = p), (c = 0)),
          o <= (c += 1))
        )
          for (g = i.campaign.frequencySignal.frequencyPixels.length; g--; )
            e.push(i.campaign.frequencySignal.frequencyPixels[g].url);
        e.push(
          i.campaign.servedByDomain +
            "/segment/modify/" +
            f +
            c +
            "_" +
            l +
            ";;pixel/?name=impCount&valuePairs=" +
            h +
            "&cb=[RANDOM]"
        ),
          e.forEach(function (e) {
            new Image().src = i.replaceMacros(e);
          });
      }
    },
    addFtrack: function () {
      var E = this,
        e =
          (E.campaign.advertiser && E.campaign.advertiser.attributionTrigger) ||
          "";
      if (
        !!window.document.querySelector(
          'script[data-d9-placement-id="' + E.placement.id + '"]'
        ) ||
        !E.campaign.shouldFtrackRun ||
        ![1, 2].includes(e) ||
        (2 === e && !E.is("mobile"))
      )
        return !1;
      function t() {
        var t = {
          D9v: { TAG: "1", CampID: "3175", CCampID: E.campaign.id },
          D9r: { DeviceID: !0, SingleDeviceID: !0 },
        };
        E.ftId && (t.D9v.EnvID = encodeURIComponent(E.ftId)),
          E.ftImpId &&
            ((t.D9v.ImpID = E.ftImpId),
            (window.ft_d9LinkID && !1 !== window.ft_d9LinkID) ||
              (window.ft_d9LinkID = E.ftImpId)),
          window.ft_d9LinkID && (t.D9v.LinkID = window.ft_d9LinkID),
          E.privacyParams.forEach(function (e) {
            E[e] &&
              void 0 !== E[e] &&
              "string" == typeof E[e] &&
              "" !== E[e] &&
              (t.D9v[e] = E[e]);
          }),
          i(
            t,
            function (e, t) {
              var i = E.campaign.servedByDomain,
                n = [],
                a = "",
                r = "";
              (t = t || {}).d9ID && n.push("d9:" + t.d9ID),
                t.d9sID && n.push("d9s:" + t.d9sID),
                0 < n.length && (a = "ft_data=" + n.join(";") + "&"),
                E.ftImpId &&
                  a &&
                  ((r =
                    i +
                    "/state/" +
                    E.placement.id +
                    ";" +
                    E.creative.id +
                    ";" +
                    E.confID +
                    ";401;" +
                    E.ftImpId +
                    "/?" +
                    a +
                    "cachebuster=[RANDOM]"),
                  (r = E.secure ? r.replace(/^http:/, "https:") : r),
                  (new Image().src = E.replaceMacros(r)));
            },
            window["ftImp" + E.placement.id] &&
              window["ftImp" + E.placement.id].privacy,
            E.GUID || E.guid || ""
          ),
          (E.shiftFtrackIconAttempts = 0),
          (E.shiftFtrackIcon = function (e, t) {
            var i = this,
              n = i.w.document.querySelector("#ftAdMarker_" + i.placement.id);
            n
              ? ("expand" === e &&
                  (t.fullscreen
                    ? (n.style.position = "fixed")
                    : ((n.style.left = -t.indentAcross + "px"),
                      (n.style.top = -t.indentDown + "px"))),
                "contract" === e &&
                  ((n.style.position = "absolute"),
                  (n.style.left = "0px"),
                  (n.style.top = "0px")))
              : i.shiftFtrackIconAttempts < 5 &&
                (i.shiftFtrackIconAttempts++,
                window.setTimeout(function () {
                  i.shiftFtrackIcon(e, t);
                }, 1e3));
          });
      }
      var i = function (r, i, e, t, n, a) {
        var o = window,
          s = "ftD9ResponseRegister",
          c = s + "3",
          d = "d9.flashtalking.com",
          p = "tag.device9.com",
          l = "https",
          m = "99999999999999",
          u = parseInt(n, 10) || 0,
          f = {},
          h = function () {
            return o.ft_d9ID || "";
          },
          g = function (t) {
            function e(e) {
              "function" == typeof e.d9Response && e.d9Response(t);
            }
            var i = [];
            w();
            for (var n = 0, a = o[c].length; n < a; n++)
              !o[c][n].forceF || o[c][n].forceFDeploy
                ? e(o[c][n])
                : i.push(o[c][n]);
            (o[c] = []),
              (o.d9Fire = !1),
              0 < i.length &&
                ((o[c] = i), (o[c][0].forceFDeploy = !0), I(o[c][0]));
          },
          v = function (e) {
            e.D9Settings.D9v ||
              e.D9Settings.D9r ||
              (e.D9Settings = { D9v: e.D9Settings }),
              void 0 === e.D9Settings.D9v.UserID &&
                (e.D9Settings.D9v.UserID = e.guid || m),
              (o.D9v = {}),
              (o.D9r = {
                DeviceID: !0,
                SingleDeviceID: !0,
                callback: function (e) {
                  g(e);
                },
              });
            var t,
              i,
              n = r.D9r,
              a = r.D9v;
            for (t in a) o.D9v[t] = a[t];
            for (i in n) o.D9r[i] = n[i];
            return e;
          },
          w = function () {
            var t = !1,
              e = 0 === o[c].length;
            return (
              [s, s + "2"].forEach(function (e) {
                void 0 !== o[e] &&
                  o[e].constructor == Array &&
                  0 < o[e].length &&
                  ((o[c] = o[c].concat(o[e])), (o[e] = []), (t = !0));
              }),
              e && 0 < o[c].length && (o[c][0].forceFDeploy = !0),
              t
            );
          },
          y = function (e) {
            var t = {};
            "timeout" == b.status && (y = function () {}),
              e
                ? (t = e)
                : ((t.guid = b.guid),
                  (t.d9ID = h()),
                  (t.d9sID = o.ft_d9sID || ""),
                  (t.lgcResponse = f),
                  (t.v = b.v)),
              i(null, t);
          },
          I = function (e) {
            var t, i;
            o.d9Fire ||
              ((o.d9Fire = !0),
              "x" === (e = v(e)).privacy
                ? ("undefined" !== o.d9PendingXDR && (o.d9PendingXDR = void 0),
                  (o.D9scr = document.createElement("script")),
                  (o.D9scr.type = "text/javascript"),
                  (o.D9scr.async = !0),
                  (o.D9scr.src =
                    l + "://" + (e.D9Settings.d9Dom || d) + "/d9core"),
                  o.D9scr.addEventListener("error", () => {
                    E.fireImpression({ code: E.impressionTypes.d9coreBlocked });
                  }),
                  (o.D9 = document.getElementsByTagName("script")[0]),
                  o.D9.parentNode.insertBefore(o.D9scr, o.D9))
                : "y" === e.privacy &&
                  ((t = new XMLHttpRequest()),
                  (i = {
                    c2s: !0,
                    tagData: { D9v: e.D9Settings.D9v, D9r: e.D9Settings.D9r },
                  }),
                  t.addEventListener("load", function (e) {
                    200 === this.status
                      ? o.D9r.callback(JSON.parse(this.responseText))
                      : (console.warn("D9 did not load:", this.status),
                        E.fireImpression({
                          code: E.impressionTypes.d9coreBlocked,
                        }));
                  }),
                  t.addEventListener("error", () => {
                    E.fireImpression({ code: E.impressionTypes.d9coreBlocked });
                  }),
                  t.addEventListener("abort", () => {
                    E.fireImpression({ code: E.impressionTypes.d9coreBlocked });
                  }),
                  t.open(
                    "POST",
                    l + "://" + (e.D9Settings.d9PDom || p) + "/api"
                  ),
                  t.send(JSON.stringify(i))),
              0 < u &&
                (e.d9Timeout = setTimeout(function () {
                  e.d9Response({ DeviceID: ["timeout"] });
                }, u)));
          },
          b = {
            v: "6",
            D9Settings: r || {},
            privacy: e,
            guid: "",
            d9Timeout: 0,
            forceF: a || !1,
            forceFDeploy: !1,
            status: "",
            d9Response: function (e) {
              var t, i;
              (i = t = ""),
                (f = "object" == typeof (e = e) ? e : {}),
                o.clearTimeout(b.d9Timeout),
                Object.prototype.hasOwnProperty.call(f, "DeviceID") &&
                  0 < f.DeviceID.length &&
                  (t = String(f.DeviceID[0])),
                Object.prototype.hasOwnProperty.call(f, "SingleDeviceID") &&
                  0 < f.SingleDeviceID.length &&
                  (i = String(f.SingleDeviceID[0])),
                "timeout" != t && t
                  ? h() ||
                    ((o.ft_d9ID = t || ""),
                    (o.ft_d9sID = i || ""),
                    h() && ((b.d9Response = function () {}), (b.status = "ok")))
                  : (b.status = "timeout"),
                y();
            },
          };
        b.privacy && "x" !== b.privacy && "y" !== b.privacy
          ? y({ privacy: b.privacy })
          : ((n = ""),
            (e = decodeURIComponent("%24")),
            Object.prototype.hasOwnProperty.call(o, "ft_GUID")
              ? (n = o.ft_GUID)
              : "string" == typeof t &&
                RegExp("^(?!9{13})[0-9]{4}[0-9A-F]{10}" + e).test(t) &&
                (n = t),
            (e = n),
            void 0 === o[c] && (o[c] = []),
            0 === o[c].length && (b.forceFDeploy = !0),
            o[c].push(b),
            e && ((o.ft_GUID = e), (b.guid = e)),
            h() && !b.forceF ? g() : I(b));
      };
      !0 === E.mayExpand || window.getVPAIDAd
        ? E.addEventListener("end", t)
        : t();
    },
    addOBA: function () {
      var n,
        a,
        i,
        e,
        r = this,
        o =
          ((r.campaign.obaData = r.campaign.obaData || {}),
          (r.campaign.obaData.notification =
            r.campaign.obaData.notification || "No Notification"),
          (() => {
            var t,
              e = r.divholder || r.markup.div.id;
            try {
              t = r.w.document.getElementById(e);
            } catch (e) {
              t = null;
            }
            return t;
          })()),
        s = "https://cdn.flashtalking.com/oba/icon/",
        c = s + "iconc.png?EDAA_icon=y",
        d = "en",
        p = 72,
        l = "";
      o &&
        "Ad Choices" === r.campaign.obaData.notification &&
        "1" === r.qs("ftOBA", 0) &&
        ((n = function () {
          for (
            var e = (navigator.language || navigator.userLanguage)
                .toLowerCase()
                .substr(0, 2),
              t = [
                { c: "bg", w: 89 },
                { c: "cs", w: 84 },
                { c: "da", w: 81 },
                { c: "de", w: 93 },
                { c: "el", w: 105 },
                { c: "en", w: 72 },
                { c: "es", w: 99 },
                { c: "fi", w: 73 },
                { c: "fr", w: 86 },
                { c: "it", w: 62 },
                { c: "nl", w: 102 },
                { c: "pl", w: 69 },
                { c: "ro", w: 53 },
                { c: "sk", w: 72 },
                { c: "sv", w: 72 },
              ],
              i = t.length;
            i--;

          )
            if (e == t[i].c) {
              (d = t[i].c), (p = t[i].w);
              break;
            }
          l = s + "icone_" + d + ".png?EDAA_icon=y";
        }),
        (a = function () {
          function e(e) {
            return (e = (e = r.secure
              ? e.replace(
                  /\bhttp:\/\/(cdn(?=\.flash)|video(?=\.flash)|stat(?=\.flash)|a(?=\.flash))/,
                  "https://secure"
                )
              : e).replace(/http:/g, "https:"));
          }
          (c = e(c)), (l = e(l));
        }),
        (i = function () {
          n(), a();
          var e,
            t = r.w.document.createElement("div"),
            i = r.w.document.createElement("style");
          (t.id = "ftAdChoices_" + r.placement.id),
            (t.innerHTML = [
              `<a href='${r.campaign.obaData.adChoices.url}' title='Click here to learn more about AdChoices'>`,
              `<img id='button' src='${c}' alt='AdChoices arrow' />`,
              `<img id='expButton' src='${l}' alt='AdChoices logo' />`,
              "</a>",
            ].join("")),
            (e = t.querySelector("a")),
            r.campaign.obaData.adChoices.clickTrackingUrl
              ? e.addEventListener("click", (e) => {
                  e.preventDefault(),
                    (new Image().src =
                      r.campaign.obaData.adChoices.clickTrackingUrl),
                    window.open(r.campaign.obaData.adChoices.url, "_blank");
                })
              : (e.target = "_blank"),
            (i.textContent = [
              "[id^=ftAdChoices_] {",
              "position: absolute;",
              "top: 1px;",
              "right: 2px;",
              `z-index: ${o.style.zIndex || "999999"};`,
              "img {",
              "border: 0;",
              "height: 15px;",
              "}",
              "#button {",
              "width: 19px;",
              "}",
              "#expButton {",
              "display: none;",
              `width: ${p}px;`,
              "}",
              "&[data-show='hover'] {",
              "#button {",
              "display: none;",
              "}",
              "#expButton {",
              "display: inline;",
              "}",
              "}",
              "}",
            ].join("")),
            o.appendChild(i),
            o.appendChild(t),
            r.campaign.obaData.adChoices.viewTrackingUrl &&
              (new Image().src = r.campaign.obaData.adChoices.viewTrackingUrl),
            o.style.position || (o.style.position = "relative"),
            o.style.width || (o.style.width = r.creative.width + "px"),
            o.style.height || (o.style.height = r.creative.height + "px"),
            t.addEventListener("mouseover", (e) => {
              e.currentTarget.dataset.show = "hover";
            }),
            t.addEventListener("mouseout", (e) => {
              e.currentTarget.dataset.show = "default";
            }),
            (r.shiftObaIcon = function (e, t) {
              var i = this.w.document.querySelector(
                "#ftAdChoices_" + this.placement.id
              );
              "expand" === e &&
                (t.fullscreen
                  ? (i.style.position = "fixed")
                  : ((i.style.right =
                      this.creative.width -
                      t.width +
                      t.indentAcross +
                      2 +
                      "px"),
                    (i.style.top = -t.indentDown + "px"))),
                "contract" === e &&
                  ((i.style.position = "absolute"),
                  (i.style.right = "2px"),
                  (i.style.top = "1px"));
            }),
            r.dispatchEvent("obaEnd");
        }),
        null != o
          ? i()
          : ((e = r.swf || r.markup.iframe.src ? "adonpage" : "backup"),
            r.addEventListener(e, function () {
              function t() {
                var e;
                (e = r.divholder || r.markup.div.id),
                  null != (o = r.w.document.getElementById(e))
                    ? i()
                    : setTimeout(t, 200);
              }
              t();
            })));
    },
    addVClick: function (e) {
      var t = this,
        i = t.decode(t.qs("click", "")),
        n = t.encodeClickCount,
        a = t.hasOwnProperty("setCreativeProperty");
      if (n && i)
        for (a && t.setCreativeProperty("ftEscapeMod", "" + n); n--; )
          e = encodeURIComponent(e);
      else
        i &&
          t.inApp &&
          (/^mopubnativebrowser:\/\//.test(i)
            ? ((e = encodeURIComponent(encodeURIComponent(e))),
              a && t.setCreativeProperty("ftEscapeMod", 2))
            : ((e = encodeURIComponent(e)),
              a && t.setCreativeProperty("ftEscapeMod", 1)));
      return i + e;
    },
    api: {
      _BRIDGE: null,
      _STATE: "loading",
      _LISTENERQUEUE: [],
      _EVENTS: {},
      _call: function (e) {
        return this._BRIDGE[e] || this.fallbackAPI[e] || function () {};
      },
      addEventListener: function (t, e) {
        var i = this;
        null === i._BRIDGE || ("loading" === i.getState() && "ready" !== t)
          ? i._LISTENERQUEUE.push([t, e])
          : (void 0 === i._EVENTS[t] &&
              ((i._EVENTS[t] = []),
              i._call("addEventListener").call(i._BRIDGE, t, function () {
                var e = [t].concat([].slice.call(arguments, 0));
                i.dispatchEvent.apply(i, e);
              })),
            "function" == typeof e && i._EVENTS[t].push(e));
      },
      close: function () {
        this._call("close").apply(this._BRIDGE, arguments);
      },
      dispatchEvent: function () {
        var e = arguments[0],
          t = [].slice.call(arguments, 1);
        if (void 0 !== this._EVENTS[e])
          for (var i = 0; i < this._EVENTS[e].length; i++)
            this._EVENTS[e][i].apply(this, t);
      },
      expand: function (e, t) {
        var i,
          n,
          a = this,
          r = /^1/.test(a.getVersion());
        if (a._BRIDGE === window.mraid)
          if (e.fullscreen || r)
            r &&
              e.fullscreen &&
              ((e.width = a.getExpandProperties().width),
              (e.height = a.getExpandProperties().height),
              a.ajs.is("Android")) &&
              e.width > screen.width / window.devicePixelRatio &&
              ((e.width /= window.devicePixelRatio),
              (e.height /= window.devicePixelRatio)),
              (n = void 0 === e.useCustomClose || e.useCustomClose),
              (i = {
                width: Math.floor(e.width),
                height: Math.floor(e.height),
                useCustomClose: n,
              }),
              r ||
                ((i.allowOrientationChange =
                  void 0 === e.allowOrientationChange ||
                  e.allowOrientationChange),
                (i.forceOrientation =
                  void 0 !== e.forceOrientation ? e.forceOrientation : "none")),
              a._call("setExpandProperties").call(a._BRIDGE, i),
              a._call("useCustomClose").call(a._BRIDGE, n),
              a._call("expand").call(a._BRIDGE, t);
          else {
            for (var o in ((r = a.getMaxSize()),
            (e.indentAcross =
              e.width < r.width ? (r.width - e.width) / 2 : e.indentAcross),
            (e.allowOffscreen =
              void 0 !== e.allowOffscreen && e.allowOffscreen),
            e))
              "number" == typeof e[o] && (e[o] = Math.floor(e[o]));
            a
              ._call("setResizeProperties")
              .call(a._BRIDGE, {
                width: e.width,
                height: e.height,
                offsetX: e.indentAcross,
                offsetY: e.indentDown,
                customClosePosition: e.customClosePosition || "top-right",
                allowOffscreen: e.allowOffscreen,
              }),
              a._call("resize").call(a._BRIDGE);
          }
        else
          a._BRIDGE === window.ormma
            ? (a
                ._call("setExpandProperties")
                .call(a._BRIDGE, {
                  width: e.width,
                  height: e.height,
                  useCustomClose:
                    void 0 === e.useCustomClose || e.useCustomClose,
                }),
              e.fullscreen
                ? a._call("expand").call(a._BRIDGE)
                : a._call("resize").call(a._BRIDGE, e.width, e.height))
            : a._call("expand").call(a._BRIDGE, e, t);
      },
      fallbackAPI: {
        _FT: null,
        _STATE: "loading",
        _EVENTS: {},
        _TARGET: "_blank",
        addEventListener: function (e, t) {
          void 0 === this._EVENTS[e] && (this._EVENTS[e] = []),
            "function" == typeof t && this._EVENTS[e].push(t);
        },
        close: function () {
          "default" !== this._STATE && "default" === this.ft.api._STATE
            ? (this._STATE = this.ft.api._STATE = "default")
            : (this._STATE = this.ft.api._STATE = "hidden"),
            this._FT && this._FT.safeFrame && this._FT.safeFrame.collapse(),
            this.dispatchEvent("stateChange", this._STATE);
        },
        dispatchEvent: function () {
          var e = arguments[0],
            t = [].slice.call(arguments, 1);
          if (void 0 !== this._EVENTS[e])
            for (var i = 0; i < this._EVENTS[e].length; i++)
              this._EVENTS[e][i].apply(this, t);
        },
        expand: function (e) {
          var t,
            i,
            n,
            a,
            r = this.ajs;
          r.safeFrame &&
            ((a = e.fullscreen
              ? ((t = (a = r.safeFrame.geom()).exp.l),
                (i = a.exp.r),
                (n = a.exp.t),
                a.exp.b)
              : ((t = Math.abs(e.indentAcross)),
                (n = Math.abs(e.indentDown)),
                (i = e.width - r.creative.width - t),
                e.height - r.creative.height - n)),
            r.safeFrame.expand({
              t: n,
              l: t,
              r: i,
              b: a,
              push: !!r.pushdown && r.safeFrame.supports().exp_push,
            })),
            (this._STATE = r.api._STATE =
              e.fullscreen ? "expanded" : "resized"),
            this.dispatchEvent("stateChange", this._STATE);
        },
        getExpandProperties: function () {
          return this._EXPANDPROPERTIES;
        },
        getMaxSize: function () {
          var e = this.ajs,
            t = {};
          return (
            e.safeFrame
              ? ((t.width = e.safeFrame.geom().win.w),
                (t.height = e.safeFrame.geom().win.h))
              : ((t.width = e.w.innerWidth),
                (t.height = e.w.innerHeight),
                (t.scale =
                  e.w.innerWidth / e.w.document.documentElement.clientWidth)),
            t
          );
        },
        getOrientation: function () {
          var e = this.ajs,
            t = 0,
            i = null;
          return (
            (i =
              e.hasOwnProperty("w") && e.w.hasOwnProperty("screen")
                ? e.w.screen
                : i) &&
              e.w === window.top &&
              ((t =
                (i.orientation && i.orientation.type) ||
                i.mozOrientation ||
                i.msOrientation ||
                e.w.orientation),
              (t = isNaN(t)
                ? /portrait/.test(t) ||
                  (!/landscape/.test(t) &&
                    window.innerHeight > window.innerWidth)
                  ? 0
                  : 90
                : t)),
            t
          );
        },
        getState: function () {
          return this._STATE;
        },
        isViewable: function () {
          return !0;
        },
        open: function (e) {
          window.open(e, "_blank");
        },
        request: function (e) {
          new Image().src = e;
        },
        setExpandProperties: function (e) {
          this._EXPANDPROPERTIES = e;
        },
      },
      getExpandProperties: function () {
        return this._call("getExpandProperties").call(this._BRIDGE);
      },
      getMaxSize: function () {
        var e,
          t = this,
          i = t.ajs;
        return (
          /^2/.test(t.getVersion()) || !i.inApp
            ? (((e = t.fallbackAPI.getMaxSize()).width &&
                void 0 === window.MMJS) ||
                (e = t._call("getMaxSize").apply(t._BRIDGE, arguments)).width ||
                (e = i.api.fallbackAPI.getMaxSize()),
              i.is("android") &&
                /mydas\.mobi/.test(location.href) &&
                ((e.width = e.width *= 2 * window.devicePixelRatio),
                (e.height = e.height *= 2 * window.devicePixelRatio)))
            : ((e = t.getExpandProperties()).width ||
                (e = i.api.fallbackAPI.getMaxSize()),
              i.is("mobile") &&
                ((i.api.getOrientation() % 180 != 0 &&
                  -1 !== i.api.getOrientation() &&
                  e.width < e.height) ||
                  (i.api.getOrientation() % 180 == 0 && e.width > e.height)) &&
                ((t = e.width), (e.width = e.height), (e.height = t))),
          e
        );
      },
      getOrientation: function (e, t) {
        var i,
          n = this;
        if (n._BRIDGE.hasOwnProperty("getOrientation"))
          try {
            i = n._call("getOrientation").call(n._BRIDGE);
          } catch (e) {}
        else
          try {
            i = n.fallbackAPI.getOrientation.call(n._BRIDGE);
          } catch (e) {}
        return (i =
          n.fallbackAPI &&
          n.fallbackAPI._FT &&
          n.fallbackAPI._FT.goneFullscreen &&
          e
            ? i % 180 == 0
              ? t < e
                ? 90
                : i
              : e < t
              ? 0
              : i
            : i);
      },
      getState: function () {
        return this._call("getState").call(this._BRIDGE);
      },
      getVersion: function () {
        return this._BRIDGE.getVersion
          ? this._call("getVersion").apply(this._BRIDGE, arguments)
          : 2;
      },
      isViewable: function () {
        return this._call("isViewable").apply(this._BRIDGE, arguments);
      },
      open: function (e) {
        window.ftClickYOC
          ? this._call("open").call(
              this._BRIDGE,
              encodeURIComponent(window.ftClickYOC),
              !0,
              encodeURIComponent(e)
            )
          : this._call("open").call(this._BRIDGE, e);
      },
      processQueuedListeners: function () {
        var t = this;
        t._LISTENERQUEUE.forEach(function (e) {
          t.addEventListener(e[0], e[1]);
        });
      },
      removeEventListener: function (i, n) {
        var a = this;
        a._EVENTS.hasOwnProperty(i) &&
          0 < a._EVENTS[i].length &&
          a._EVENTS[i].forEach(function (e, t) {
            e === n && a._EVENTS[i].splice(t, 1);
          });
      },
      request: function (e, t) {
        this.fallbackAPI.request(e, t);
      },
      useCustomClose: function () {
        return this._call("useCustomClose").apply(this._BRIDGE, arguments);
      },
    },
    appendLandingPageSuffix: function (e) {
      var t,
        i,
        n,
        a,
        r,
        o,
        s,
        c =
          this.campaign.landingPageSuffix &&
          this.campaign.landingPageSuffix.content,
        d =
          (c &&
            0 < c.length &&
            (this.creativePropertiesList.ftClickSuf = this.replaceMacros(
              c,
              !0
            )),
          e.split(/(\?|&)url=/gi)),
        p = d[d.length - 1],
        l = "" + p;
      return (d.length && d.length < 2) || !c
        ? e
        : ((s = -1 < (d = l.indexOf("#"))),
          (i = -1 < (t = l.indexOf("%23"))),
          (n = -1 < (r = l.indexOf("?"))),
          (a = -1 < l.indexOf("&")),
          n &&
            "?http" === l.substring(r, r + 5) &&
            ((n = -1 < (r = (o = l.substring(r + 1)).indexOf("?"))),
            (a = -1 < o.indexOf("&"))),
          s || i
            ? ((r = l.substring(0, d)),
              (o = l.substring(d)),
              i && ((r = l.substring(0, t)), (o = l.substring(t))),
              -1 < r.indexOf((s = "?")) && (s = "&"),
              (l = r + s + c + o))
            : (l += n || a ? "&" + c : "?" + c),
          e.replace(p, l));
    },
    appendScriptToHead: function (e) {
      var t = this.$().target,
        i = document.createElement("script");
      (t && "[object Object]" !== Object.getPrototypeOf(t).toString()) ||
        (t = document.head),
        (i.type = "text/javascript"),
        (i.src = e),
        t.appendChild(i);
    },
    bver: function (e, t) {
      return t
        ? 0 <=
            (this.w.navigator[t] || "").toLowerCase().indexOf(e.toLowerCase())
        : this.is(e);
    },
    compareVersions: function (e, t) {
      if (!this.adReady) return 1;
      (e = e.split(".")), (t = t.split("."));
      for (var i = 0; i < 3; i++) {
        if ((+e[i] || 0) > (+t[i] || 0)) return 1;
        if ((+e[i] || 0) < (+t[i] || 0)) return -1;
      }
      return 0;
    },
    getParamsAsMap(e) {
      return (e || "").split("&").reduce((e, t) => {
        var [t, i] = t.split("=");
        return t && (e[t] = i || ""), e;
      }, {});
    },
    configMerge: function (e) {
      var t,
        i = this;
      for (t in ((i.v = "1.15.1"),
      (i.markup = {
        div: { id: "", style: {} },
        anchor: {
          href: "",
          title: "Click to learn more",
          id: "",
          target: "_blank",
          style: {},
        },
        image: { src: "", id: "", alt: "Click Here", style: { border: 0 } },
        iframe: {
          src: "",
          id: "",
          name: "",
          width: "",
          height: "",
          frameBorder: 0,
          margin: 0,
          allowTransparency: "true",
          webkitallowfullscreen: "",
          mozallowfullscreen: "",
          allowfullscreen: "",
          style: {},
        },
      }),
      i.isWhat(),
      (i.adDisplayed = !1),
      (i.cachedEvents = i.cachedEvents || []),
      (i.customPos = !1),
      (i.customPosFunc = function () {}),
      (i.eventListeners = {}),
      (i.lockableOrientation = !(
        !window.screen ||
        !(
          screen.mozLockOrientation ||
          screen.msLockOrientation ||
          screen.lockOrientation ||
          (screen.orientation && screen.orientation.lock)
        )
      )),
      (i.pageVisible = "maybe"),
      (i.w = window),
      e))
        i[t] = e[t];
      switch (
        ((i.placement = i.placement || {}),
        (i.partnerTagEncoded = i.partnerTagEncoded || null),
        (i.partnerTag = i.partnerTag || { markup: null, macros: [] }),
        "" === i.partnerTag.markup &&
          (i.partnerTag = { markup: null, macros: [] }),
        (i.creative = i.creative || { creativeLibrary: {} }),
        (i.campaignSite = i.campaignSite || { site: {} }),
        (i.campaign = i.campaign || {}),
        (i.placement.id = "" + i.placement.id),
        (i.creative.blockBrowsers = i.creative.blockBrowsers || []),
        Array.isArray(i.creative.blockBrowsers) ||
          (i.creative.blockBrowsers = i.creative.blockBrowsers.split(",")),
        (i.creative.creativeLibrary.id =
          "" + (i.creative.creativeLibrary.id || "")),
        (i.campaign.id = "" + (i.campaign.id || "")),
        (i.creative.id = "" + (i.creative.id || "")),
        (i.ftCdnUrl = i.campaign.cdnDomain || "https://cdn.flashtalking.com"),
        (i.creative.baseAssetUrl = i.creative.baseAssetUrl || "" + i.ftCdnUrl),
        (i.markup.div.id = i.divID || i.markup.div.id),
        (i.markup.anchor.href = i.convertUrlProtocol(
          i.altImageUrl || i.altImgHref || i.markup.anchor.href
        )),
        (i.markup.anchor.id = i.altImgID || i.markup.anchor.id),
        (i.markup.anchor.target = i.altImgTarget || i.markup.anchor.target),
        (i.markup.image.src = i.convertUrlProtocol(
          i.altimg || i.markup.image.src
        )),
        (i.markup.image.id = i.altImgID || i.markup.image.id),
        (i.markup.image.alt = i.alttext || i.markup.image.alt),
        (i.markup.iframe.src = i.convertUrlProtocol(
          i.creative.baseAsset.host +
            i.creative.baseAsset.path +
            i.creative.baseAsset.file
        )),
        (i.markup.iframe.id = i.frameID || "ftframe" + i.placement.id),
        (i.gdpr =
          (window["ftImp" + i.placement.id] &&
            window["ftImp" + i.placement.id].gdpr) ||
          ""),
        (i.gdpr_consent =
          (window["ftImp" + i.placement.id] &&
            window["ftImp" + i.placement.id].gdpr_consent) ||
          ""),
        (i.gdpr_pd =
          (window["ftImp" + i.placement.id] &&
            window["ftImp" + i.placement.id].gdpr_pd) ||
          ""),
        (i.us_privacy =
          (window["ftImp" + i.placement.id] &&
            window["ftImp" + i.placement.id].us_privacy) ||
          ""),
        (i.api = i.api || {}),
        (i.api.fallbackAPI = i.api.fallbackAPI || {}),
        (i.api.ajs = i.api.fallbackAPI.ajs = this),
        (i.creative.adType = (i.creative.adType || "").toLowerCase()),
        (i.markup.anchor.id = "ftalt" + i.placement.id),
        (i.confID = window["ftConfID_" + i.placement.id] || "0"),
        (i.campaign.shouldFtrackRun = !(
          !i.campaign || !i.campaign.isMobileEnhanced
        )),
        (i.campaign.isMobileEnhanced =
          i.is.mobile && i.campaign.isMobileEnhanced),
        (i.markup.div.id = "ftdiv" + i.placement.id),
        (i.encodeClickCount = parseInt(i.encodeClickCount, 10) || 0),
        (i.ftId = window["ftId_" + i.placement.id] || ""),
        (i.ftImpId =
          (window["ftImp" + i.placement.id] &&
            window["ftImp" + i.placement.id].impID) ||
          ""),
        (i.ftReturn = window["ftKeyword_" + i.placement.id] || ""),
        (i.keyword = window["ftKeyword_" + i.placement.id] || ""),
        (i.params = window["ftParams_" + i.placement.id] || ""),
        (i.click = i.getClickString()),
        i.addExtraValuesToParams(),
        (i.paramsMap = i.getParamsAsMap(this.params)),
        (i.gpp = i.paramsMap.gpp || ""),
        (i.gpp_sid = i.paramsMap.gpp_sid || ""),
        (i.scriptLocation = document.getElementById(
          "ftscript_m" + i.placement.id
        )),
        "head" === i.scriptLocation.parentNode.tagName.toLowerCase() &&
          document.body.appendChild(i.scriptLocation),
        (i.secure = !!(
          "https:" === location.protocol ||
          (document.getElementById("ftscript_m" + i.placement.id) &&
            /^https:/.test(
              document.getElementById("ftscript_m" + i.placement.id).src
            )) ||
          (window.qs &&
            "function" == typeof qs.get &&
            /^https:/.test(qs.get("ifsrc", "")))
        )),
        (i.mii = function () {
          return 99999 < parseInt(i.placement.id)
            ? "xre/" + parseInt(i.placement.id / 1e4)
            : "agsv3";
        }),
        (i.pathstump = "327"),
        (i.placement.name = (i.placement.name || "").replace(
          / |_|\-|\(|\)|\//g,
          ""
        )),
        (i.campaignSite.site.name = (i.campaignSite.site.name || "").replace(
          / |_|\-|\(|\)/g,
          ""
        )),
        (i.stump = i.campaign.servedByDomain + "/" || ""),
        (i.statBaseUrl =
          i.statBaseUrl ||
          "https://ad-events.flashtalking.com/reportV3/ft.stat?0-" +
            i.placement.id +
            ";" +
            i.creative.id +
            ";"),
        (i.clickTags = i.landingPageRedirects || []),
        (i.landingPageEventRedirects = i.landingPageEventRedirects || []),
        (i.mutations = i.mutations || []),
        (i.surveys = i.surveys || []),
        (i.impressions = (i.impressions || []).map(function (e) {
          return i.convertUrlProtocol(e);
        })),
        (i.pID = i.placement.id),
        (i.placementDescription =
          i.placement.description || i.placement.name || ""),
        (i.cID = i.creative.creativeLibrary.id),
        (i.campaignID = i.campaign.id),
        (i.creativeID = i.creative.id),
        (i.width = i.creative.width || ""),
        (i.height = i.creative.height || ""),
        (i.exttrack = i.impressions),
        (i.extscript = i.surveys),
        (i.adType = i.creative.adType),
        (i.siteName = i.campaignSite.site.name),
        (i.altimghref = i.markup.anchor.href || ""),
        (i.countOnDownload = i.campaign.isMobileEnhanced),
        (i.centreAd = i.isCenterAd),
        (i.blockBrowsers = i.creative.blockBrowsers),
        (i.divID = i.markup.div.id),
        (i.frameID = i.markup.iframe.id),
        (i.file = i.markup.iframe.src),
        (i.protocolSwitch = function () {}),
        (i.setupFlashVars = function () {}),
        i.creative.adType)
      ) {
        case "altimage":
        case "html_standard":
          i = Object.assign(i, window.ftUtils.altimg);
          break;
        case "html":
        case "html_onpage":
        case "custom_rule":
        case "display_html_tag":
        case "html_expand":
        case "jsvpaid":
        case "vpaid":
        case "native_image":
          i = Object.assign(i, window.ftUtils.html);
          break;
        default:
          i = Object.assign(i, {
            init: function () {
              console.warn(
                "Ad type of '" + i.creative.adType + "' is not supported"
              );
            },
          });
      }
      window.o = i;
      var n = window.setInterval(function () {
        window.document &&
          window.document.body &&
          (window.clearInterval(n),
          i.setupImpressionMonitor(i),
          i.init(),
          i.addOBA(),
          i.setUpOmidMonitor());
      }, 20);
    },
    convertUrlProtocol: function (e) {
      return (
        "string" != typeof e && (e = String(e)),
        this.secure && /^http:\/\//.test(e)
          ? e.replace("http://", "https://")
          : e
      );
    },
    createStateUrl: function (e) {
      let t = this,
        i;
      return (i = e
        ? "https://ad-events.flashtalking.com/ft.stat?" +
          ((t.campaign.advertiser && t.campaign.advertiser.id) || "") +
          ";" +
          t.campaign.id +
          ";" +
          t.placement.id +
          ";" +
          t.creative.id +
          ";" +
          (t.creative.version || 0) +
          ";<STATE_CODE>;" +
          t.ftImpId +
          ";" +
          (t.GUID || t.guid || "") +
          ";" +
          t.random()
        : (t.campaign.servedByDomain || "https://ad-events.flashtalking.com") +
          "/state/" +
          t.placement.id +
          ";" +
          t.creative.id +
          ";" +
          (t.confID || "") +
          ";<STATE_CODE>;[%IMPRESSIONID%]/?cachebuster=[RANDOM]");
    },
    creativePropertiesList: {},
    cssPrefix: ((e) => {
      var e = Object.keys(e)
          .filter(function (e) {
            return !/[0-9]+/.test(e);
          })
          .map(function (e) {
            var t = "";
            return (t =
              null !== e.match(/^-?(moz|webkit|ms)-?/i)
                ? e.match(/^-?(moz|webkit|ms)-?/i)[1]
                : t);
          })
          .filter(function (e) {
            return "" !== e;
          }),
        t = "";
      return (
        e.includes("ms")
          ? (t = "-ms-")
          : e.includes("moz")
          ? (t = "-moz-")
          : e.includes("webkit") && (t = "-webkit-"),
        t
      );
    })(window.getComputedStyle(document.documentElement, "")),
    decode: function (t) {
      var i = t;
      try {
        i = decodeURIComponent(t);
      } catch (e) {
        i = unescape(t);
      }
      return i;
    },
    dispatchEvent: function (e, t) {
      var i = this;
      if (
        ("html_standard" === i.creative.adType &&
          "backup" === e &&
          (e = "adonpage"),
        i.eventListeners.hasOwnProperty(e))
      )
        for (var n = i.eventListeners[e].length; n--; )
          i.eventListeners[e][n].call(i, t);
      ("adonpage" !== e && "backup" !== e) || (i.adDisplayed = !0);
    },
    getAbsLeft: function (e) {
      return (
        e.getBoundingClientRect().left +
        (null != window.scrollX
          ? window.scrollX
          : null != window.pageXOffset
          ? window.pageXOffset
          : document.documentElement.scrollLeft)
      );
    },
    getAbsTop: function (e) {
      return (
        e.getBoundingClientRect().top +
        (null != window.scrollY
          ? window.scrollY
          : null != window.pageYOffset
          ? window.pageYOffset
          : document.documentElement.scrollTop)
      );
    },
    getBackup: function (e, t) {
      var i,
        n = this;
      return (
        n.supportedBrowser() && "html_standard" === n.creative.adType
          ? ((n.markup.iframe.scrolling = "no"), (i = n.makeElement("iframe")))
          : ("basic" === e
              ? ((n.backupShown = !0),
                (n.fullClick = "" + n.markup.anchor.href),
                n.api.bridge !== n.api.fallbackAPI &&
                  ((n.markup.anchor.target = "_self"),
                  (n.markup.anchor.href = "javascript:void(0);")))
              : ((n.backupDisplayed = !0),
                (n.markup.image.src = n.insertParam(n.markup.image.src, {
                  param: "ft_creative",
                  value: n.creative.id,
                })),
                (n.markup.image.src = n.insertParam(n.markup.image.src, {
                  param: "ft_configuration",
                  value: window["ftConfID_" + n.placement.id],
                })),
                (n.markup.image.src += "?" + n.random()),
                (n.markup.image.style.border = "0px")),
            (n.markup.anchor.id = n.markup.anchor.id || n.imgID),
            (n.markup.anchor.style.display = "inline-block"),
            (n.markup.image.id = "" + n.markup.anchor.id),
            (n.markup.image.style.width = n.creative.width + "px"),
            (n.markup.image.style.height = n.creative.height + "px"),
            n.makeElement("anchor"),
            n.makeElement("image"),
            (i = n.makeElement("anchor")).appendChild(n.makeElement("image"))),
        t ? (t.appendChild(i), t) : i
      );
    },
    getBannerConfig: function (t, e) {
      e = e || window["ftCreativeId_" + t];
      var i = new XMLHttpRequest(),
        e = "https://agen-assets.ftstatic.com/display/" + t + "/" + e + ".json",
        n = this;
      (i.responseType = "json"),
        i.open("GET", e),
        i.send(),
        (i.onreadystatechange = function () {
          if (4 === i.readyState)
            switch (i.status) {
              case 200:
                n.configMerge(i.response);
                break;
              case 404:
                n.getBannerConfigFail("file not found", t, "file not found");
                break;
              default:
                n.getBannerConfigFail(
                  "ARMADA ERROR",
                  t,
                  "Something went wrong, Armada GEN returned a status of " +
                    i.status
                );
            }
        }),
        i.addEventListener("error", function (e) {
          n.getBannerConfigFail("error", t, e);
        }),
        i.addEventListener("abort", function (e) {
          n.getBannerConfigFail("abort", t, e);
        }),
        i.addEventListener("timeout", function (e) {
          n.getBannerConfigFail("timeout", t, e);
        });
    },
    getBannerConfigFail: function (e, t, i) {
      console.log("FAILED TO LOAD PLACEMENT INFORMATION");
    },
    getClickString: function () {
      var e = "";
      return (
        window["ftClick_" + this.placement.id] &&
          (e = window["ftClick_" + this.placement.id]),
        (e =
          -1 < this.params.indexOf("ftclick")
            ? this.params
                .split("&")
                .filter(function (e) {
                  return -1 < e.indexOf("ftclick");
                })
                .map(function (e) {
                  return decodeURIComponent(e.split("=")[1]);
                })
                .join("")
            : e)
      );
    },
    getFrame: function (e) {
      var t, i;
      if (e)
        return (
          (i = function () {
            t.adFrame.setAttribute("src", t.adFrame.getAttribute("data-src"));
          }),
          ((t = this).markup.iframe.scrolling = "no"),
          (t.creativePropertiesList.name = t.markup.iframe.id),
          (t.markup.iframe.name = JSON.stringify(t.creativePropertiesList)),
          "quickload" !== t.loadMethod &&
            ((t.markup.iframe["data-src"] = "" + t.markup.iframe.src),
            (t.markup.iframe.src = "about:blank"),
            "DOMLoaded" === t.loadMethod
              ? "loading" === document.readyState
                ? t.listen(document, "DOMContentLoaded", i)
                : setTimeout(i, 0)
              : "complete" !== document.readyState
              ? t.listen(window, "load", i)
              : setTimeout(i, 0)),
          (t.markup.iframe.style.visibility = "hidden"),
          (t.adFrame = t.makeElement("iframe")),
          e.appendChild(t.adFrame),
          e
        );
    },
    visibility: { VISIBLE: 2, PARTIAL: 1, HIDDEN: 0 },
    isImpressionMonitorSetup: !1,
    isPlacementVisible: !1,
    isPlacementXdom: !1,
    impressionViewableThreshold: 0.5,
    impressionTimeOfLastCheck: new Date().getTime(),
    backgroundTimeSinceLastCheck: 0,
    timeSentToBackground: 0,
    firedImpressions: { 201: !0 },
    isWindowActive: !0,
    viewableImpressionTime: 0,
    impressionTypes: {
      viewable: "202",
      undetectable: "270",
      rendered: "271",
      invalid: "272",
      nonRenderingDevice: "273",
      omidOnePixelViewable: "405",
      omidNotAvailable: "406",
      d9coreBlocked: "407",
    },
    hasImpressionMonitorSetupRun: !1,
    previousVisibility: 0,
    privacyParams: [
      "gdpr",
      "gdpr_consent",
      "gdpr_pd",
      "us_privacy",
      "gpp",
      "gpp_sid",
    ],
    addImpressionMonitorListeners: function () {
      var t = this;
      (t.timeSentToBackground = t.getNow()),
        t.isPageVisible(t.pageVisible) &&
          ((t.timeSentToBackground = 0), t.impressionWatcher()),
        t.addEventListener("visibilitychange", function (e) {
          (t.isWindowActive = t.isPageVisible(e)),
            t.isWindowActive
              ? (t.backgroundTimeSinceLastCheck += t.timeSentToBackground
                  ? Math.max(0, t.getNow() - t.timeSentToBackground)
                  : 0)
              : (t.timeSentToBackground = t.getNow()),
            t.validateRenderFor("rendered"),
            t.impressionWatcher();
        });
    },
    checkNonRenderingDevice: function () {
      var t = this;
      try {
        var e = new window.Image();
        e.setAttribute("test_image", !0), (e.src = "data:,");
        window.setTimeout(function () {
          (void 0 !== e.complete && e.complete) ||
            t.fireImpression({
              code: t.impressionTypes.nonRenderingDevice,
              asImage: !1,
            });
        }, 100);
      } catch (e) {
        console.warn("Is Image supported?\n", e),
          t.fireImpression({
            code: t.impressionTypes.nonRenderingDevice,
            asImage: !1,
          });
      }
    },
    getPercentOfPlacementVisible: function () {
      return this.getAdVisiblePercentage(
        this.getPlacementPosition(this.placementWrapper),
        this.getWindowDetails()
      );
    },
    fireImpression: function (e) {
      this.hasImpressionMonitorStartRun || this.startImpressionMonitor();
      var t,
        i = this || e.ajs,
        n = e.isOmid
          ? ((i.omidStateUrl = i.omidStateUrl || i.createStateUrl(!0)),
            i.omidStateUrl.replace("<STATE_CODE>", e.code))
          : ((i.stateUrl = i.stateUrl || i.createStateUrl()),
            i.replaceMacros(i.stateUrl.replace("<STATE_CODE>", e.code)));
      i.firedImpressions.hasOwnProperty(e.code) ||
        "prerender" === document.visibilityState ||
        (!1 === e.asImage
          ? ((t = document.createElement("script")).setAttribute("src", n),
            window.document.body.appendChild(t))
          : (new Image().src = n),
        (i.firedImpressions[e.code] = i.placement.id));
    },
    getAdVisiblePercentage: function (e, t) {
      var i,
        n,
        a,
        r,
        o,
        t = {
          left: t.scrollLeft,
          right: t.scrollLeft + t.width,
          top: t.scrollTop,
          bottom: t.scrollTop + t.height,
        },
        e = {
          left: e.x,
          right: e.x + e.width,
          top: e.y,
          bottom: e.y + e.height,
        };
      return (
        (t = t),
        (r = ((e = e).right - e.left) * (e.bottom - e.top)),
        (o = 0),
        (a = e),
        (n = t).top > a.bottom ||
          n.left > a.right ||
          n.right < a.left ||
          n.bottom < a.top ||
          ((n = t),
          (a = e),
          (t = Math.max(n.left, a.left)),
          (e = Math.min(n.right, a.right)),
          (i = Math.max(n.top, a.top)),
          (o = (e - t) * (Math.min(n.bottom, a.bottom) - i))),
        Math.floor((o / r) * 100) / 100
      );
    },
    getInnerDimensions: function (e) {
      var t,
        i,
        n = { height: null, width: null };
      return (
        e &&
          ((t = getComputedStyle(e)),
          (i = e.getBoundingClientRect()),
          "inline" === t.display
            ? ((n.height = i.height), (n.width = i.width))
            : ((n.height =
                e.clientHeight -
                (parseFloat(t.paddingTop) + parseFloat(t.paddingBottom))),
              (n.width =
                e.clientWidth -
                (parseFloat(t.paddingLeft) + parseFloat(t.paddingRight))))),
        n
      );
    },
    getNow: function () {
      return new Date().getTime();
    },
    getPixelModifiers: function (e) {
      var t = Math.sqrt(e),
        t = [0, 1 - t, 1 - e, 0.5, e, t, 1].sort();
      return 0.5 === e ? [0, 0.2, 0.4, 0.5, 0.6, 0.8, 1] : t;
    },
    getPlacementsParentDetails: function () {
      var e = this,
        t =
          e.placementWrapper &&
          e.placementWrapper.parentNode &&
          e.placementWrapper.parentNode.tagName.toLowerCase(),
        i = null,
        n = null;
      try {
        n = window.top && window.top.document;
      } catch (e) {
        n = !1;
      }
      "body" === t
        ? (i = document.body)
        : n && n.querySelector('[name="ftscript_m' + e.placement.id + '"]')
        ? (i = n.querySelector(
            '[name="ftscript_m' + e.placement.id + '"]'
          ).parentNode)
        : e.placementWrapper &&
          e.placementWrapper.parentNode &&
          (i = e.placementWrapper.parentNode);
      (t = i ? e.getInnerDimensions(i) : null),
        (n = i ? window.getComputedStyle(i) : null),
        (e = t ? t.width : null);
      return {
        height: t ? t.height : null,
        width: e,
        display: n ? n.display : null,
        visibility: n ? n.visibility : null,
      };
    },
    getPlacementPosition: function (e, t) {
      t = t || this.w || this.window || window;
      var e = e.getBoundingClientRect(),
        t = (
          this.isPlacementXdom ? t : t.parent
        ).document.documentElement.getBoundingClientRect(),
        i = this.getWindowDetails(),
        n = (i.scrollLeft && t.left) || 0,
        i = (i.scrollTop && t.top) || 0;
      return {
        x: Math.round(e.left) - n,
        y: Math.round(e.top) - i,
        width: e.right - e.left,
        height: e.bottom - e.top,
      };
    },
    getPointCheckArray: function (e) {
      var t = this.placementWrapper.getBoundingClientRect(),
        i = (this.currentWidth = t.right - t.left - 1),
        n = (this.currentHeight = t.bottom - t.top - 1),
        a = this.pixelModifiers.map(function (e) {
          return i * e;
        }),
        r = this.pixelModifiers.map(function (e) {
          return n * e;
        });
      return [
        { id: "0", left: a[0], top: r[1] },
        { id: "1", left: a[0], top: r[5] },
        { id: "2", left: a[1], top: r[0] },
        { id: "3", left: a[1], top: r[6] },
        { id: "4", left: a[2], top: r[2] },
        { id: "5", left: a[2], top: r[4] },
        { id: "6", left: a[3], top: r[3] },
        { id: "7", left: a[4], top: r[2] },
        { id: "8", left: a[4], top: r[4] },
        { id: "9", left: a[5], top: r[0] },
        { id: "10", left: a[5], top: r[6] },
        { id: "11", left: a[6], top: r[1] },
        { id: "12", left: a[6], top: r[5] },
      ].map(function (e) {
        return (e.left += t.left), (e.top += t.top), e;
      });
    },
    getReadableVisibility: function (e) {
      var t = this,
        i = t.visibility.HIDDEN;
      return (
        t.impressionViewableThreshold <= e || 1 === e
          ? (i = t.visibility.VISIBLE)
          : 0 < e && (i = t.visibility.PARTIAL),
        i
      );
    },
    getPlacementWrapper: function () {
      var e = this;
      return (
        e.isPlacementXdom
          ? (e.placementWrapper = window.document.getElementById(e.adId))
          : e.frameless
          ? (e.placementWrapper =
              window.document.querySelector("innovid-creative"))
          : (e.placementWrapper =
              window.parent.document.getElementById(e.adId) ||
              window.frameElement),
        (e.placementWrapper &&
          /^ft||innovid/.test(e.placementWrapper.getAttribute("id"))) ||
          (e.placementWrapper = e.$().target),
        e.placementWrapper
      );
    },
    getWindowDetails: function (e) {
      e = e || this.w || this.window || window;
      var t = { scrollLeft: 0, scrollTop: 0, height: 0, width: 0 },
        e = this.isPlacementXdom ? e : e.parent;
      return (
        e.innerWidth
          ? ((t.width = e.innerWidth),
            (t.height = e.innerHeight),
            (t.scrollLeft = e.pageXOffset),
            (t.scrollTop = e.pageYOffset))
          : e.document.documentElement &&
            e.document.documentElement.clientHeight
          ? ((t.width = e.document.documentElement.clientWidth),
            (t.height = e.document.documentElement.clientHeight),
            (t.scrollLeft = e.document.documentElement.scrollLeft),
            (t.scrollTop = e.document.documentElement.scrollTop))
          : e.document.body &&
            ((t.width = e.document.body.clientWidth),
            (t.height = e.document.body.clientHeight),
            (t.scrollLeft = e.document.body.scrollLeft),
            (t.scrollTop = e.document.body.scrollTop)),
        t
      );
    },
    startImpressionMonitor: function (t) {
      if (
        (this.hasImpressionMonitorSetupRun || this.setupImpressionMonitor(t),
        !this.hasImpressionMonitorStartRun)
      ) {
        (this.hasImpressionMonitorStartRun = !0), (t = this || t);
        window.navigator.userAgent, window.navigator.platform;
        if (
          ((t.firedImpressions = { 201: t.placement.id }),
          t.paramsMap &&
            "0" === t.paramsMap.cas &&
            t.fireImpression({ code: t.impressionTypes.d9coreBlocked }),
          (t.iframe = window !== window.top),
          t.iframe)
        )
          try {
            window.top.document.getElementsByTagName("head");
          } catch (e) {
            t.isPlacementXdom = !0;
          }
        if (
          (t.is.mobile
            ? (t.impressionViewableThreshold = 0.5)
            : 242500 < t.width * t.height &&
              (t.impressionViewableThreshold =
                0.6 * t.impressionViewableThreshold),
          (t.pixelModifiers = t.getPixelModifiers(
            t.impressionViewableThreshold
          )),
          (t.placementWrapper = t.getPlacementWrapper()),
          (t.initialVisibility = t.visibility.HIDDEN),
          (t.lastVisibility = t.initialVisibility),
          t.validateRenderFor("rendered"),
          t.isPlacementXdom)
        ) {
          if (void 0 === window.IntersectionObserver)
            return (
              t.fireImpression({ code: t.impressionTypes.undetectable }),
              void t.dispatchEvent("advisibility", !1)
            );
          t.setupIntersectionObserver(),
            (t.getPercentOfPlacementVisible = t.getIoIntersectionRatio),
            delete t.getPlacementPosition,
            delete t.getWindowDetails,
            delete t.getAdVisiblePercentage;
        }
        t.validateRenderFor("invalid"),
          t.checkNonRenderingDevice(),
          t.addEventListener("adonpage", t.initAdVisibilityCheck),
          t.addEventListener("backup", t.initAdVisibilityCheck);
      }
    },
    setupImpressionMonitor: function (e) {
      (e = this || e).campaign.servedByDomain;
      (e.hasImpressionMonitorSetupRun = !0),
        (e.width = e.currentWidth = parseInt(e.creative.width, 10)),
        (e.height = e.currentHeight = parseInt(e.creative.height, 10)),
        (e.hasApi =
          e.hasOwnProperty("api") &&
          !(
            e.api.bridge === e.api.fallbackAPI ||
            e.api._BRIDGE === e.api.fallbackAPI
          )),
        (e.stateUrl = e.stateUrl || e.createStateUrl()),
        e.addEventListener("adready", function () {
          e.addEventListener("advisibility", e.onAdVisibility);
        });
    },
    setUpOmidMonitor: function () {
      let a = this,
        e = document.createElement("script"),
        t = document.createElement("script"),
        r = (e) => {
          console.warn(
            "[ftUtils] omid tracking not available: " + JSON.stringify(e)
          ),
            a.fireImpression({
              code: a.impressionTypes.omidNotAvailable,
              isOmid: !0,
              asImage: !1,
            });
        };
      a.paramsMap.omid &&
        ((e.src = "omweb-v1.js"),
        e.addEventListener("error", r),
        e.addEventListener("load", () => {
          document.body.appendChild(t);
        }),
        (t.src = "omid-session-client-v2.js"),
        t.addEventListener("error", r),
        t.addEventListener("load", function () {
          var e = JSON.stringify({
              impression: (a.omidStateUrl =
                a.omidStateUrl || a.createStateUrl(!0)).replace(
                "<STATE_CODE>",
                "[%EVENT_ID%]"
              ),
            }),
            t = window.location.href,
            i = window.top,
            n = new Partner("Innovid", "0.0.1"),
            e = new VerificationScriptResource(
              "https://ajs-assets.ftstatic.com/innovid-omid-validation-verification.js",
              "innovid.com",
              e,
              "full"
            ),
            n = new Context(n, [e], t),
            e = (n.setServiceWindow(i), new AdSession(n));
          if (
            (e.setCreativeType("htmlDisplay"),
            e.setImpressionType("onePixel"),
            e.isSupported())
          ) {
            let t = new AdEvents(e);
            e.registerSessionObserver((e) => {
              "sessionStart" === e.type && t.impressionOccurred();
            }),
              e.start();
          } else r({ message: "AdSession is not supported" });
        }),
        document.body.appendChild(e));
    },
    initAdVisibility: function () {
      var e = this,
        t =
          ((e.placementWrapper = e.placementWrapper || e.getPlacementWrapper()),
          e.getPercentOfPlacementVisible());
      (e.lastVisibility = e.initialVisibility = e.getReadableVisibility(t)),
        e.hasApi && "loading" === e.api.getState()
          ? e.api.addEventListener("ready", function () {
              e.addImpressionMonitorListeners(e);
            })
          : e.addImpressionMonitorListeners(e);
    },
    initAdVisibilityCheck: function () {
      this.isImpressionMonitorSetup ||
        ((this.isImpressionMonitorSetup = !0), this.initAdVisibility());
    },
    getIoIntersectionRatio: function () {
      return this.ioIntersectionRatio;
    },
    setupIntersectionObserver: function () {
      var i = this,
        e = new window.IntersectionObserver(
          function (e, t) {
            i.ioIntersectionRatio = e[0].intersectionRatio;
          },
          {
            root: null,
            rootMargin: "0px",
            threshold: [
              0.05, 0.1, 0.15, 0.2, 0.25, 0.3, 0.35, 0.4, 0.45, 0.5, 0.55, 0.6,
              0.65, 0.7, 0.75, 0.8, 0.85, 0.9, 0.95, 1, 0,
            ],
          }
        );
      (i.ioIntersectionRatio = 0), e.observe(i.placementWrapper);
    },
    onAdVisibility: function (e) {
      var t = this;
      t.isPlacementVisible ||
        (e >= t.impressionViewableThreshold
          ? ((t.isPlacementVisible = !0), t.dispatchEvent("visibleAd", !0))
          : !1 === e && t.dispatchEvent("visibleAd", !1));
    },
    isPageVisible: function (e) {
      return (
        "yes" === e ||
        this.waitingForInvalidToTurnValid ||
        ("no" !== e && (!0 === this.isPlacementXdom || !0 === this.ios))
      );
    },
    impressionWatcher: function () {
      var e = this,
        t = e.getNow(),
        i = t - e.impressionTimeOfLastCheck - e.backgroundTimeSinceLastCheck,
        n = e.getPercentOfPlacementVisible(),
        a = e.getReadableVisibility(n);
      250 < i &&
        (t - e.lastScroll < i
          ? e.ios && (n = Math.min(e.previousVisibility, n))
          : ((e.viewableImpressionTime = 0),
            (e.backgroundTimeSinceLastStep += Math.max(
              0,
              t - e.impressionTimeOfLastCheck
            )),
            (e.backgroundTimeSinceLastCheck += Math.max(
              0,
              t - e.impressionTimeOfLastCheck
            )),
            (i =
              t -
              e.impressionTimeOfLastCheck -
              e.backgroundTimeSinceLastCheck))),
        e.isWindowActive &&
          e.placementWrapper.parentNode &&
          (e.dispatchEvent("advisibility", 100 * n),
          a > e.lastVisibility && (e.lastVisibility = a),
          n >= e.impressionViewableThreshold
            ? (e.viewableImpressionTime += i)
            : (e.viewableImpressionTime = 0),
          1e3 <= e.viewableImpressionTime &&
            (((e.window || window).viewableImpFired = !0),
            e.validateRenderFor("viewable")),
          e.validateRenderFor("rendered"),
          (e.impressionTimeOfLastCheck = t),
          (e.backgroundTimeSinceLastCheck = 0),
          (e.previousVisibility = n)),
        !e.placementWrapper.parentNode ||
          (e.hasApi && (e.hasApi, e.viewableImpression)) ||
          !e.isWindowActive ||
          setTimeout(function () {
            e.impressionWatcher();
          }, e.pollingCycle);
    },
    validateRenderFor: function (e) {
      var t = this,
        i = t.getPlacementsParentDetails();
      switch (e) {
        case "rendered":
          1 < i.height &&
            1 < i.width &&
            "none" !== i.display &&
            "hidden" !== i.visibility &&
            (delete t.waitingForInvalidToTurnValid,
            t.fireImpression({ code: t.impressionTypes.rendered }));
          break;
        case "invalid":
          ((i.height < 2 && i.width < 2) ||
            "none" === i.display ||
            "hidden" === i.visibility) &&
            ((t.waitingForInvalidToTurnValid = !0),
            t.fireImpression({ code: t.impressionTypes.invalid }));
          break;
        case "viewable":
          1 < i.height &&
            1 < i.width &&
            (delete t.waitingForInvalidToTurnValid,
            t.fireImpression({ code: t.impressionTypes.viewable }));
      }
    },
    insertParam: function (e, t) {
      return (e =
        "string" == typeof e && "" !== t.value
          ? e.replace("/?", "/?" + t.param + "=" + t.value + "&")
          : e);
    },
    is: function (e, t) {
      if (!t || !this.is[e]) return !!this.is[e];
      for (
        var i,
          n = (/^\D+/.exec(t) || [""]).pop(),
          a = new Function("a", "b", "return a" + (n || "==") + "b"),
          r = "string" == typeof this.is[e] ? this.is[e].split(".") : [],
          o = String(t).slice(String(t).search(/\d/)).split("."),
          s = 0,
          c = o.length;
        s < c;
        s++
      )
        if (((i = r[s] === o[s]), a(+r[s], +o[s]))) {
          if (!o[s + 1] || "=" !== n.charAt(1) || !i) return !0;
        } else if (!o[s + 1] || (">" !== n && "<" !== n && !i)) return !1;
    },
    isWhat: function () {
      function e(e) {
        return (
          (RegExp(e + "[/ ](\\d+(?:[\\._]\\d+)*)").exec(n) || [""])
            .pop()
            .replace(/_/g, ".") || !1
        );
      }
      var t,
        i = (() => {
          var e,
            t = "",
            i = window.getComputedStyle(document.documentElement, "");
          for (e in i) t += e + i[e];
          var n = (t.match(/-(moz|webkit|ms)-/) ||
            ("" === i.OLink && ["", "o"]))[1];
          return "WebKit|Moz|MS|O".match(new RegExp("(" + n + ")", "i"))[1];
        })(),
        n = navigator.userAgent,
        a = navigator.platform,
        r = (window.matchMedia || window.msMatchMedia)(
          "(pointer:coarse)"
        ).matches,
        o = "iP" === a.slice(0, 2) && e("OS"),
        s = ~n.search(/ Edge?\//i) && e("Edge?"),
        c = !!window.StyleMedia,
        d = /Android/i.test(a) && r && /WebKit/i.test(i),
        p = !(!~n.indexOf("; U;") && !~n.indexOf("Verson")) && d,
        l = 0 !== (!p && s),
        m = (e("ChriOS"), !!window.chrome && /WebKit/i.test(i)),
        u = ("opera" in window || "opr" in window) && /WebKit/i.test(i),
        f = {
          mobile: r,
          android: d,
          ios: o,
          windows: e("Windows(?: NT| Phone(?: OS)?)?"),
          mac: !/like Mac OS/.test(n) && e("Mac OS X"),
          linux: "Linux" === a.slice(0, 5) && !d,
          chromeOS: e("CrOS \\w+"),
          aosp: p,
          chrome: !p && !s && m && e("Chrome"),
          edge: (l || c) && s,
          firefox:
            ("sidebar" in window ||
              "MozAppearance" in document.documentElement.style ||
              /Moz/i.test(i)) &&
            e("Firefox"),
          safari:
            ((o && "boolean" == typeof window.navigator.standalone) ||
              /constructor/i.test(window.HTMLElement) ||
              "[object SafariRemoteNotification]" ===
                (
                  !window.safari ||
                  ("undefined" != typeof safari && safari.pushNotification)
                ).toString()) &&
            e("Version"),
          webkit: /WebKit/i.test(i),
          blink: (m || u) && "CSS" in window,
          kindleFire: e("Silk"),
          opera: u,
          operaMini:
            window.operamini &&
            "[object OperaMini]" ===
              Object.prototype.toString.call(window.operamini),
        };
      for (t in ((f[navigator.platform.toLowerCase()] = !0), f))
        this.is[t] = f[t];
    },
    listen: function (e, t, i) {
      return (
        (this.cachedEvents = this.cachedEvents || []),
        this.cachedEvents.push([e, t, i]),
        e.addEventListener(t, i, !1),
        function (e, t, i) {
          e.addEventListener(t, i, !1);
        }
      );
    },
    macSaf: function () {
      return this.is.mac && this.is.safari && !this.is.chrome;
    },
    makeElement: function (e) {
      var t,
        i,
        n = this;
      switch (e) {
        case "anchor":
          t = document.createElement("a");
          break;
        case "image":
          t = document.createElement("img");
          break;
        case "iframe":
          (n.markup.iframe.width = n.creative.width),
            (n.markup.iframe.height = n.creative.height),
            (t = document.createElement("iframe"));
          break;
        default:
          (t = document.createElement(e)), (n.markup[e] = n.markup[e] || {});
      }
      for (i in n.markup[e])
        if ("style" === i)
          for (var a in n.markup[e].style) t.style[a] = n.markup[e].style[a];
        else t.setAttribute(i, n.markup[e][i]);
      return t;
    },
    applySearchParameterMapToString: function (t) {
      var i = this,
        e = [
          {
            param: "ft_custom",
            value: window["ftCustom_" + i.placement.id] || "",
          },
          {
            param: "ft_section",
            value: window["ftSection_" + i.placement.id] || "",
          },
          { param: "ft_id", value: i.ftId || "" },
          { param: "ft_impID", value: i.ftImpId || "" },
          {
            param: "ft_agentEnv",
            value:
              i.qs("ft_agentEnv") && "0" !== i.qs("ft_agentEnv")
                ? i.qs("ft_agentEnv")
                : "",
          },
          {
            param: "ft_partnerid",
            value:
              i.qs("ft_partnerid") && "0" !== i.qs("ft_partnerid").length
                ? i.qs("ft_partnerid")
                : "",
          },
          {
            param: "ft_partnerimpid",
            value:
              i.qs("ft_partnerimpid") && "0" !== i.qs("ft_partnerimpid").length
                ? i.qs("ft_partnerimpid")
                : "",
          },
          { param: "gdpr", value: i.gdpr },
          { param: "gdpr_consent", value: i.gdpr_consent },
          { param: "gdpr_pd", value: i.gdpr_pd },
          { param: "us_privacy", value: i.us_privacy },
          { param: "gpp", value: i.gpp },
          { param: "gpp_sid", value: i.gpp_sid },
          {
            param: "ft_c1",
            value:
              i.qs("ft_c1") && "0" !== i.qs("ft_c1").length
                ? i.qs("ft_c1")
                : "",
          },
          {
            param: "ft_c2",
            value:
              i.qs("ft_c2") && "0" !== i.qs("ft_c2").length
                ? i.qs("ft_c2")
                : "",
          },
          {
            param: "ft_c3",
            value:
              i.qs("ft_c3") && "0" !== i.qs("ft_c3").length
                ? i.qs("ft_c3")
                : "",
          },
          {
            param: "plid",
            value:
              i.qs("plid") && "0" !== i.qs("plid").length ? i.qs("plid") : "",
          },
          {
            param: "plid2",
            value:
              i.qs("plid2") && "0" !== i.qs("plid2").length
                ? i.qs("plid2")
                : "",
          },
          {
            param: "plid3",
            value:
              i.qs("plid3") && "0" !== i.qs("plid3").length
                ? i.qs("plid3")
                : "",
          },
          {
            param: "plid4",
            value:
              i.qs("plid4") && "0" !== i.qs("plid4").length
                ? i.qs("plid4")
                : "",
          },
          {
            param: "fts",
            value: i.qs("fts") && "0" !== i.qs("fts").length ? i.qs("fts") : "",
          },
          {
            param: "fl",
            value: i.qs("fl") && "0" !== i.qs("fl").length ? i.qs("fl") : "",
          },
          {
            param: "oob",
            value: i.qs("oob") && "0" !== i.qs("oob").length ? i.qs("oob") : "",
          },
          {
            param: "ft_mcid",
            value:
              i.qs("ft_mcid") && "0" !== i.qs("ft_mcid").length
                ? i.qs("ft_mcid")
                : "",
          },
          {
            param: "rc",
            value: i.qs("rc") && "0" !== i.qs("rc").length ? i.qs("rc") : "",
          },
          {
            param: "ft_pid",
            value:
              i.qs("ft_pid") && 0 < i.qs("ft_pid").length ? i.qs("ft_pid") : "",
          },
          {
            param: "ft_mliid",
            value:
              i.qs("ft_mliid") && "0" !== i.qs("ft_mliid").length
                ? i.qs("ft_mliid")
                : "",
          },
        ];
      return (
        (t = t || ""),
        e.forEach(function (e) {
          t = i.insertParam(t, e);
        }),
        t
      );
    },
    modifyClicks: function () {
      var i = this,
        n = i.clickTags.filter(function (e) {
          return !!e && 0 < e.length;
        });
      return (
        n.forEach(function (e, t) {
          e &&
            (n[t] = i.addVClick(
              i.replaceMacros(
                i.appendLandingPageSuffix(i.applySearchParameterMapToString(e)),
                !0
              )
            ));
        }),
        (i.markup.anchor.href = i.addVClick(
          i.replaceMacros(
            i.appendLandingPageSuffix(
              i.applySearchParameterMapToString(i.markup.anchor.href)
            ),
            !0
          )
        )),
        n
      );
    },
    once: function (i, n) {
      function a(e) {
        var t = r.eventListeners[i].length;
        for (n.call(r, e); t--; )
          r.eventListeners[i][t] === a && r.eventListeners[i].splice(t, 1);
      }
      var r = this;
      r.addEventListener(i, a);
    },
    osmatch: function (e) {
      e = e.slice(e.indexOf("-") + 1);
      return this.is(e);
    },
    outputDiv: async function (e, t) {
      var s = this;
      if ("basic" === e)
        (s.markup.div.style.position = "relative"),
          (s.markup.div.style.width = s.creative.width + "px"),
          (s.markup.div.style.height = s.creative.height + "px"),
          (s.qs("ftx", "") || s.qs("fty", "")) &&
            ((s.markup.div.style.left = s.qs("ftx", "") + "px"),
            (s.markup.div.style.top = s.qs("fty", "") + "px"),
            (s.markup.div.style.position = "absolute")),
          "" !== s.qs("ftadz", "") &&
            (s.markup.div.style["z-index"] = s.qs("ftadz")),
          s.isCenterAd && (s.markup.div.style.margin = "0 auto"),
          (e = s.makeElement("div")).appendChild(s.getBackup("basic")),
          s.scriptLocation.insertAdjacentHTML("afterEnd", e.outerHTML),
          (s.$().target.children[0].onclick = function (e) {
            (e = e || window.event).preventDefault && e.preventDefault(),
              (e.returnValue = !1),
              s.requestAllLandingPageEventRedirects(s),
              window.open(s.fullClick || s.markup.anchor.href, "_blank");
          }),
          s.campaign.isMobileEnhanced &&
            s.fireImpression({ code: 271, ajs: s }),
          s.dispatchEvent("backup"),
          s.dispatchEvent("adready"),
          (s.adDisplayed = !0);
      else {
        e = (s.markup.iframe.src || "")
          .split("/")
          .map((e, t, i) => (t + 1 < i.length ? e : ""))
          .join("/");
        if (
          (s.setCreativeProperty("creativeAssetPath", e),
          null !== s.partnerTag.markup || null !== s.partnerTagEncoded)
        ) {
          var c,
            e = document.querySelector("#ftscript_m" + s.placement.id),
            i = document.createElement("div"),
            n = (s.click || "") + s.modifyClicks()[0];
          i.setAttribute("id", "ftdiv" + s.placement.id),
            (i.style.position = "relative"),
            (i.style.height = s.creative.height + "px"),
            (i.style.width = s.creative.width + "px"),
            null !== s.partnerTag.markup
              ? ((c = s.partnerTag.markup.trim()),
                (s.click = s.click || ""),
                s.partnerTag.macros.forEach(function (e) {
                  var t, i;
                  ("fullTracker" !== e.name && "clickTracker" !== e.name) ||
                    ((t = (i = e.value.split(/\/?[&|?]url=/))[0]),
                    (i = i[1] || ""),
                    t.indexOf("/?") < 0 && (t += "/?"),
                    (e.value =
                      s.click +
                      s.applySearchParameterMapToString(t) +
                      "url=" +
                      i));
                }),
                s.partnerTag.macros.forEach(function (e) {
                  "fullTrackerEncoded" === e.name &&
                    ((e.name = "fullTracker_enc"),
                    (e.value = encodeURIComponent(
                      s.partnerTag.macros.filter(
                        (e) => "fullTracker" === e.name
                      )[0].value
                    )));
                }),
                s.partnerTag.macros.forEach(function (e) {
                  for (
                    var t,
                      i,
                      n = "[%" + e.name + "%]",
                      a = c.split(n).length - 1,
                      r = (c.indexOf(n), ""),
                      o = 0;
                    o < a;
                    o++
                  )
                    (i = (t = c.indexOf(n)) + n.length),
                      (r = c.substring(0, t)),
                      (r = (r += e.value) + c.substring(i)),
                      (c = s.replaceMacros(r, !0));
                }))
              : (c = s.replaceMacros(s.partnerTagEncoded, !0));
          "iframe" ==
          (0 === c.toLowerCase().indexOf("<iframe") ? "iframe" : "html")
            ? ((i.innerHTML = c),
              e.parentNode.append(i),
              i
                .querySelector("iframe")
                .setAttribute("id", "ftframe" + s.placement.id))
            : ((o = document.createElement("iframe")).setAttribute(
                "id",
                "ftframe" + s.placement.id
              ),
              o.setAttribute("allowtransparency", !0),
              o.setAttribute("marginheight", "0"),
              o.setAttribute("marginwidth", "0"),
              o.setAttribute("scrolling", "no"),
              o.setAttribute("frameborder", "no"),
              (o.style.borderWidth = 0),
              c.indexOf("</body"),
              (a = c.substring(0, c)),
              (r = c.substring(c)),
              (o.height = s.creative.height),
              (o.width = s.creative.width),
              i.appendChild(o),
              e.parentNode.appendChild(i),
              (c = [
                a,
                [
                  "<script>",
                  "var ftUtil = {",
                  "init: function init(){",
                  "this.cacheOpen();",
                  "this.redefineOpen();",
                  "},",
                  "cacheOpen: function cacheOpen(){",
                  "this.classicWindowOpen = window.open;",
                  "},",
                  "redefineOpen: function redefineOpen(){",
                  "window.open = function(){",
                  "ftUtil.classicWindowOpen.apply(window, [('" +
                    n +
                    '\' || arguments[0]), (arguments[1] || "_blank")]);',
                  "}",
                  "}",
                  "};",
                  "ftUtil.init();",
                  "</script>",
                ].join(""),
                r,
              ].join("")),
              o.contentWindow.document.open(),
              o.contentWindow.document.write(c),
              o.contentWindow.document.close()),
            1 <
              e.parentNode.querySelectorAll("#" + s.markup.iframe.id).length &&
              (i.style.transform = "translateY(-100%)");
        } else if (s.frameless) {
          let i = window.document.createElement("innovid-creative");
          (i.styles = {
            width: s.creative.width + "px",
            height: s.creative.height + "px",
            display: "block",
            position: "relative",
            overflow: "hidden",
          }),
            s
              .pubPos()
              .split(";")
              .forEach((e, t) => {
                0 === t
                  ? (i.styles.position = e)
                  : 2 === (t = e.split(":")).length && (i.styles[t[0]] = t[1]);
              }),
            s.setCreativeProperty("frameless", 1),
            (i.creativeProperties = s.creativePropertiesList),
            i.setAttribute("id", "innovid_creative_" + s.placement.id),
            (s.customCreative = i),
            (s.adId = "innovid_creative_" + s.placement.id),
            (s.adFrame = i),
            (s.divID = "innovid_creative_" + s.placement.id),
            (((s.adWindow = window).frameElement = i).source =
              s.markup.iframe.src),
            s.scriptLocation.parentNode.appendChild(i);
        } else {
          var a = null,
            n = s.safeFrame
              ? "width:100%;height:100%;position:absolute;"
              : "width:" +
                s.creative.width +
                "px; height:" +
                s.creative.height +
                "px; position:" +
                s.pubPos(),
            r = s.w.document.createElement("div"),
            o = !(
              document.write instanceof Function &&
              ~document.write.toString().indexOf("[native code]")
            );
          (r.style.cssText = n),
            ((r = t ? s.getFrame(r) : s.getBackup("complex", r)).id =
              s.markup.div.id),
            "html_onpage" == s.creative.adType || (!s.iframe && !s.attachtobody)
              ? o || s.append
                ? ((s.mayExpand && "html_expand" === s.creative.adType) ||
                    ((r.style.overflow = "hidden"),
                    (s.markup.anchor.id = s.markup.iframe.id)),
                  s.scriptLocation.parentNode.insertBefore(
                    r,
                    s.scriptLocation.parentNode.lastChild.nextSibling
                  ))
                : s.scriptLocation.parentNode.append(r)
              : s.attachtobody
              ? (((a = document.createElement("div")).id = s.phID),
                (a.style.cssText = n),
                s.iframe
                  ? (frameElement.parentNode.insertBefore(
                      a,
                      frameElement.nextSibling
                    ),
                    (frameElement.style.display = "none"))
                  : o || s.append
                  ? s.scriptLocation.parentNode.insertBefore(
                      a,
                      s.scriptLocation.nextSibling
                    )
                  : s.scriptLocation.parentNode.append(a),
                s.w.document.body.appendChild(r),
                (s.phDiv = s.$(s.phID).target),
                s.$().alignTo(s.$(s.phID).target),
                !1 === s.customPos &&
                  s.addEventListener("resize", function () {
                    s.$().alignTo(s.$(s.phID).target);
                  }))
              : (frameElement.parentNode.insertBefore(r, frameElement),
                (frameElement.style.display = "none"));
        }
        s.campaign.isMobileEnhanced && s.fireImpression({ code: 271, ajs: s }),
          s.customPos &&
            (s.customPosFunc(),
            s.addEventListener("adonpage", function () {
              s.customPosFunc(), s.addEventListener("resize", s.customPosFunc);
            })),
          s.setupResizeListener(),
          (s.adDisplayed = !0),
          (s.adDiv = s.$().target),
          s.dispatchEvent("adonpage");
      }
      s.startImpressionMonitor(s);
    },
    parseURL: function (e) {
      var t;
      return (
        e
          ? ((t = document.createElement("a")).href = e || "")
          : (t = { search: "" }),
        {
          domain: t.hostname || "",
          hash: t.hash || "",
          host: t.host || "",
          hostname: t.hostname || "",
          href: t.href || "",
          query: t.search.substring(1, t.search.length) || "",
          path: t.pathname || "",
          pathname: t.pathname || "",
          port: t.port || "",
          protocol: t.protocol || "",
          search: t.search || "",
        }
      );
    },
    processMutations: function () {
      var n = this;
      n.mutations.forEach(function (t, e) {
        var i = t || "";
        if (
          -1 <
          (i = (i = (i = (i =
            -1 <
            (i = (i = (i = (i = (i = (i = (i = i.replace(
              "var originalReplaceMacros = o.replaceMacros;",
              "o.originalReplaceMacros" + e + " = o.replaceMacros;"
            )).replace(
              "return originalReplaceMacros(str, cb);",
              "return o.originalReplaceMacros" + e + "(str, cb);"
            )).replace(
              ",\n        oldRM = o.replaceMacros;",
              ";\n        o.oldRM" + e + " = o.replaceMacros;"
            )).replace(
              "return oldRM(str, cb);",
              "return o.oldRM" + e + "(str, cb);"
            )).replace(
              "}(o));",
              "}(window.ft" + n.placement.id + "));"
            )).replace(
              "\n  o.html5sitebar = {\n",
              '\n  o.creative.adType = "html5sitebar";\n  o.html5sitebar = {\n'
            )).replace(
              "o.altimghref = o.altImgHref = o.replaceMacros(o.altimghref || o.altImgHref, true);",
              "o.altimghref = o.altImgHref = o.markup.anchor.href = o.replaceMacros(o.altimghref || o.altImgHref, true);"
            )).indexOf("setTimeout")
              ? i.replace("}, 200);", "}, 1000);")
              : i).replace(
            "d = c.document.getElementById(b.divholder ? b.divholder : b.divID),\n",
            "d = (c.document.getElementById(b.divholder ? b.divholder : b.divID)||document.getElementById(b.divholder ? b.divholder : b.divID)),\n"
          )).replace(/o\.adType/g, "o.creative.adType")).replace(
            'window.location.href.indexOf("www.flashtalking")===-1',
            'window.location.href.indexOf("tag.flashtalking")===-1'
          )).indexOf("eval")
        )
          return !1;
        try {
          new Function(i).apply(n);
        } catch (e) {
          console.log("Unsupported Mutations will not be executed"),
            console.log("mutation", t),
            console.log(e);
        }
      });
    },
    pubPos: function () {
      var e = this,
        t = e.isCenterAd ? "margin:0 auto;" : "",
        t = e.attachtobody ? "absolute;" : "relative;" + t,
        i = e.qs("ftx", ""),
        n = e.qs("fty", ""),
        e = e.qs("ftadz", "");
      return (
        ("" === i && "" === n) ||
          (t =
            (t = "absolute;") +
            (i ? "left:" + i + "px;" : "") +
            (n ? "top:" + n + "px;" : "")),
        "" !== e && (t += "z-index:" + e + ";"),
        t
      );
    },
    random: function (e) {
      return Math.floor(Math.random() * (e || 1e9));
    },
    removeMargin: function (e) {
      var t = this;
      e &&
        (document.body
          ? (document.body.style.margin = 0)
          : setTimeout(function () {
              t.removeMargin(e);
            }, 20));
    },
    replaceMacros: function (t, e) {
      function i(e, t, i) {
        return (
          "NOCACHEBUSTER" === (i = i.toUpperCase()) && (n = !0),
          "RANDOM" === i && !1 !== n
            ? ((a = !0), e)
            : c.hasOwnProperty(i)
            ? c[i]
            : e
        );
      }
      var n,
        a,
        r,
        o,
        s = this,
        c = {
          TIMESTAMP: window["ftTimestamp_" + s.placement.id],
          GUID: window["ftGUID_" + s.placement.id],
          IDFA: s.ftId,
          RANDOM: s.random(),
          CONFID: window["ftConfID_" + s.placement.id],
          NOCACHEBUSTER: "",
          IMPRESSIONID: s.ftImpId,
          IMPRESSION_ID: s.ftImpId,
          PROTOCOL: s.secure ? "https" : "http",
          GDPR: s.gdpr || "",
          GDPR_CONSENT: s.gdpr_consent || "",
          GDPR_PD: s.gdpr_pd || "",
          US_PRIVACY: s.us_privacy || "",
          GPP: s.gpp || "",
          GPP_SID: s.gpp_sid || "",
          POSTAL: window["ftPostal_" + s.placement.id] || "",
        },
        d = /(?:\[|%5B|%255B)(%|%25|%2525)?(?:FT_)?(\w+)\1(?:\]|%5D|%255D)/gi,
        p = (s.decode("%5C"), t.match(/\[ftqs:\[(\w+)\]\]/g) || []),
        l = t.match(/\[%FT_qs(\w+)%\]/gi) || [],
        m = t.match(/\[%FTE_(\w+)%\]/gi) || [],
        u = [
          "[%FT_CAMPAIGN_ID%]",
          "[%FT_SITE_ID%]",
          "[%FT_PLACEMENT_ID%]",
          "[%FT_CREATIVE_ID%]",
          "[%FT_CONFIGURATION_ID%]",
          "[%FT_WIDTH%]",
          "[%FT_HEIGHT%]",
          "[%FT_GUID%]",
          "[%FT_RANDOM%]",
          "[%FT_IMPRESSION_ID%]",
        ];
      if (s.hasOwnProperty("replaceMacrosMap"))
        try {
          c = Object.assign(c, s.replaceMacrosMap);
        } catch (e) {}
      function f(e, t) {
        var i = (e + (t ? "_encoded" : "")).toUpperCase(),
          n = h.hasOwnProperty(e),
          a = c.hasOwnProperty(i),
          n = n ? h[e] : "";
        t && (n = encodeURIComponent(n)), a || (c[i] = n);
      }
      var h = {};
      s.params.split("&").forEach(function (e) {
        e = e.split("=");
        h[e[0]] = e[1];
      }),
        h.site_cmpid && (h.site_cmpId = h.site_cmpid);
      return (
        Array.isArray(p) &&
          0 < p.length &&
          p.forEach(function (e) {
            (r = e.replace(/\[ftqs:\[/gi, "").replace("]]", "")),
              (o = new RegExp("\\[ftqs:\\[" + r + "\\]\\]", "gi")),
              f(r),
              (t = t.replace(o, "[%FT_" + r + "%]"));
          }),
        Array.isArray(l) &&
          0 < l.length &&
          l.forEach(function (e) {
            u.includes(e) ||
              ((r = e.replace(/\[%ft_/gi, "").replace("%]", "")), f(r));
          }),
        Array.isArray(m) &&
          0 < m.length &&
          m.forEach(function (e) {
            (r = e.replace(/\[%fte_/gi, "").replace("%]", "")),
              (o = new RegExp("\\[%FTE_" + r + "%\\]", "gi")),
              f(r, !0),
              (t = t.replace(o, "[%FT_" + r + "_encoded%]"));
          }),
        -1 < (t = t.replace(d, i)).indexOf("random=") && (a = !0),
        (t = !(n = !!n) && a ? t.replace(d, i) : t) +
          (n || a || e ? "" : (-1 !== t.indexOf("?") ? "&" : "?") + s.random())
      );
    },
    requestAllImpressions: function () {
      var t = this;
      t.impressions.forEach(function (e) {
        e && (new Image().src = t.replaceMacros(e));
      });
    },
    requestAllLandingPageEventRedirects: function (e) {
      e.landingPageEventRedirects &&
        0 < e.landingPageEventRedirects.length &&
        e.landingPageEventRedirects.forEach(function (e) {
          new Image().src = e;
        });
    },
    requestExpandTracking: function () {
      var e = this,
        t = e.decode(e.qs("ftExpTrack", ""));
      t &&
        !e.expandTracked &&
        ((new Image().src = e.replaceMacros(t)), (e.expandTracked = !0));
    },
    setAPI: function (e) {
      var t = this,
        i = (() => {
          if ("basic" !== e)
            return (
              ((t.api.fallbackAPI.ft = t).api._BRIDGE = t.api.bridge =
                t.api._BRIDGE ||
                window.mraid ||
                window.ormma ||
                t.api.fallbackAPI),
              t.api.getState()
            );
        })();
      if (
        ("basic" === e &&
          (t.api._BRIDGE = t.api.bridge =
            window.ormma || window.mraid || t.api.fallbackAPI),
        (t.inApp = t.api._BRIDGE !== t.api.fallbackAPI),
        t.inApp
          ? ("basic" === e ? t.removeMargin(!0) : (t.noBreakout = !0),
            t.setupViewport())
          : t.safeFrame && "complex" === e
          ? t.setSFEnvironment()
          : (t.api.fallbackAPI._STATE = "default"),
        "complex" === e)
      )
        return (
          ((t.api.fallbackAPI._FT = t).api.fallbackAPI._STATE = "default"), i
        );
    },
    setupLoadListener: function () {
      var e = this;
      e.w.addEventListener(
        e.advload ? "DOMContentLoaded" : "load",
        function () {
          e.dispatchEvent("load");
        },
        !1
      );
    },
    setupPageVisibility: function () {
      var n,
        t,
        i,
        a,
        r,
        o = this,
        s = !0,
        c = "hidden",
        d = function (e) {
          var e = (e || w.event).type,
            t = {
              focus: "yes",
              blur: "maybe",
              focusin: "yes",
              focusout: "maybe",
            },
            i = "yes";
          l[c] ? (i = "no") : t.hasOwnProperty(e) && (i = t[e]),
            o.pageVisible !== i &&
              ((o.pageVisible = i),
              o.dispatchEvent("visibilitychange", i),
              o.dispatchToCreative) &&
              o.dispatchToCreative("visibilitychange", i),
            n !== ("no" !== i) &&
              ((n = s = "no" !== i),
              o.dispatchEvent("viewableChange", n),
              o.api && o.api.dispatchEvent("viewableChange", n),
              s) &&
              (clearTimeout(a), (a = setTimeout(p, 100)));
        },
        p = function () {
          var e = {};
          s &&
            void 0 !== l.hasFocus &&
            ((i = l.hasFocus() || o.w.document.hasFocus()) !== t &&
              ((t = i), (e.type = i ? "focus" : "blur"), d(e)),
            clearTimeout(a),
            (a = setTimeout(p, 100)));
        },
        l =
          ((r = o.w),
          o.mayExpand
            ? e("top") === window.top
              ? e("top")
              : e("parent")
            : o.w !== window.top && e("top"),
          r.document);
      function e(e) {
        try {
          r = "string" == typeof o.w[e].document.body.style.cssText && o.w[e];
        } catch (e) {
          r = o.w;
        }
      }
      c in l
        ? o.listen(l, "visibilitychange", d)
        : "mozHidden" in l
        ? ((c = "mozHidden"), o.listen(l, "mozvisibilitychange", d))
        : "webkitHidden" in l &&
          ((c = "webkitHidden"), o.listen(l, "webkitvisibilitychange", d)),
        o.addEventListener("adonpage", function () {
          clearTimeout(a),
            (a = setTimeout(p, 100)),
            (o.pageVisible = "maybe"),
            l[c]
              ? (o.pageVisible = "no")
              : l.hasFocus &&
                (l.hasFocus() || o.w.document.hasFocus()) &&
                (o.pageVisible = "yes");
        }),
        (o.pageVisible = "maybe"),
        l[c]
          ? (o.pageVisible = "no")
          : l.hasFocus && l.hasFocus() && (o.pageVisible = "yes");
    },
    setupQS: function (e) {
      var t,
        i = this,
        e = e.split("&"),
        n = {};
      return (
        e.forEach(function (e) {
          ((t = e.split("="))[1] = t.slice(1).join("=")),
            (n[i.decode(t[0])] = i.decode(t[1]));
        }),
        (window.qs && window.qs.get) ||
          function (e, t) {
            return n[e] || t;
          }
      );
    },
    setupResizeListener: function () {
      var e = this;
      e.listen(e.w, "resize", function () {
        e.dispatchEvent("resize");
      });
    },
    setupViewport: function () {
      var e = this.w || window,
        t = e.document.querySelector("head");
      e.document.querySelector('meta[name="viewport"]') ||
        (t ||
          ((t = e.document.createElement("head")),
          e.document.body.parentElement.insertBefore(t, e.document.body)),
        ((e = e.document.createElement("meta")).name = "viewport"),
        (e.content =
          "width=device-width,initial-scale=1,maximum-scale=1,minimum-scale=1"),
        t.insertBefore(e, t.children[0]));
    },
    supportedBrowser: function () {
      var e,
        t,
        i,
        n = this,
        a = n.creative.blockBrowsers.length,
        r = /\D+/,
        o = /\d+/;
      if (
        void 0 === document.querySelector ||
        void 0 === window.postMessage ||
        n.isForceBackup
      )
        return !1;
      for (; a--; )
        if (
          ((e = n.creative.blockBrowsers[a].toLowerCase()),
          (t = i = t = void 0),
          (t = r.exec(e.substr(0, e.indexOf("-"))) || r.exec(e)),
          (i = o.test(e) ? parseInt(o.exec(e), 10) : Math.pow(2, 32)),
          (e = 0 < e.indexOf("-") ? e.slice(e.indexOf("-") + 1) : ""),
          (t = t && t.toString()),
          !(!n.is(t, "<=" + i) || (e && !n.is(e))))
        )
          return !1;
      return !0;
    },
  }),
  (window.ftUtils.altimg = {
    htmlStandard: function () {
      var e = this;
      e.supportedBrowser() &&
        (e.addEventListener("start", function () {
          e.adId = e.markup.iframe.id;
        }),
        e.addEventListener("adonpage", e.injectAnchor));
    },
    init: function () {
      var t = this;
      (t.markup.image.src =
        t.creative.baseAsset.host +
        t.creative.baseAsset.path +
        t.creative.baseAsset.file +
        (-1 < t.creative.baseAsset.file.indexOf("?") ? "&" : "?") +
        "cb=" +
        t.random()),
        "html_standard" === t.creative.adType &&
          ((t.markup.anchor.href = t.markup.anchor.href.replace(
            ";210;",
            ";211;"
          )),
          (t.markup.image.src = t.convertUrlProtocol(
            t.campaign.servedByDomain +
              "/imp/" +
              t.campaign.id +
              ";" +
              t.placement.id +
              ";204;gif;" +
              t.campaignSite.site.id +
              ";" +
              t.placement.id +
              "/?"
          )),
          t.htmlStandard()),
        (t.append = !(
          !window["ftImp" + t.placement.id] ||
          1 !== parseInt(window["ftImp" + t.placement.id].jsAppend, 10)
        )),
        (t.cdn = /(cdn|secure)\.flashtalking/.test(location.host)),
        (t.cdnSrc =
          "https://cdn.flashtalking.com/frameworks/js/frame/index.html?g="),
        (t.guid = window["ftConfID_" + t.placement.id] || ""),
        (t.servedby = /servedby\.flashtalking/.test(location.host)),
        (t.qs = t.setupQS(t.params)),
        t.addFrequencySignalling(),
        t.addFtrack(),
        t.processMutations(),
        (t.landingPageEventRedirects = (t.landingPageEventRedirects || []).map(
          function (e) {
            return t.replaceMacros(t.appendLandingPageSuffix(e));
          }
        )),
        t.setAPI("basic"),
        t.setupPageVisibility(),
        (t.adId = t.markup.anchor.id),
        t.setup(t.placement.id, "basic"),
        t.requestAllImpressions(),
        t.dispatchEvent("start"),
        t.outputDiv("basic"),
        t.dispatchEvent("end"),
        t.surveys.forEach(function (e) {
          t.appendScriptToHead(t.replaceMacros(e));
        });
    },
    injectAnchor: function () {
      var e,
        t,
        i,
        n = this;
      n.storeGUID ||
        ((e = n.$().target),
        (t = n.api.bridge !== n.api.fallbackAPI),
        (i = document.createElement("a")),
        (n.fullClick = n.markup.anchor.href),
        i.setAttribute(
          "href",
          t ? "javascript:void(0);" : n.markup.anchor.href
        ),
        i.setAttribute("target", t ? "_self" : "_blank"),
        (i.style.cssText = [
          "cursor: pointer;",
          "position: absolute;",
          "width:" + n.creative.width + "px;",
          "height:" + n.creative.height + "px;",
          "z-index: 89000;",
          'background: url("data:image/gif;base64,R0lGODlhAQABAIAAAP///wAAACH5BAEAAAAALAAAAAABAAEAAAICRAEAOw==");',
          "top: 0;",
          "left: 0;",
        ].join(" ")),
        i.addEventListener("click", function () {
          n.requestAllLandingPageEventRedirects(n);
        }),
        e.offsetParent !== e.parentElement &&
          (e.parentElement.style.position = "relative"),
        e.insertBefore(i, e.children[0] || null),
        n.api.bridge !== n.api.fallbackAPI &&
          (i.onclick = function () {
            n.api.open(n.markup.anchor.href);
          }));
    },
    setup: function () {
      var i = this;
      (i.ftId = window["ftId_" + i.placement.id] =
        window["ftId_" + i.placement.id] || i.qs("ft_id", "")),
        ("" === i.qs("ftx", "") && "" === i.qs("fty", "")) ||
          ((i.qs.ftx = i.qs("ftx", "0")), (i.qs.fty = i.qs("fty", "0"))),
        i.privacyParams.forEach(function (e) {
          var t =
            (window["ftImp" + i.placement.id]
              ? window["ftImp" + i.placement.id][e]
              : null) || i.qs(e, "");
          t &&
            ((i[e] = t),
            window["ftImp" + i.placement.id].hasOwnProperty(e) ||
              (window["ftImp" + i.placement.id][e] = t));
        }),
        i.setupLoadListener(),
        i.modifyClicks(),
        i.setupBackupImp();
    },
    setupBackupImp: function () {
      var e = this;
      (e.markup.image.src = e.insertParam(e.markup.image.src, {
        param: "ft_creative",
        value: e.creative.id,
      })),
        (e.markup.image.src = e.insertParam(e.markup.image.src, {
          param: "ft_configuration",
          value: window["ftConfID_" + this.placement.id],
        }));
    },
  }),
  (window.ftUtils.html = {
    adVisibilityListener: function () {
      var i = 0,
        n = this;
      n.addEventListener("visibleAd", function (e) {
        n.dispatchToCreative("ftAdVisible", e ? "visible" : "undetectable");
      }),
        n.addEventListener("advisibility", function (e) {
          var t = {
            aboveThreshold: !!(e && e > n.impressionViewableThreshold),
            undetectable: !1 === e,
            percentInView: !1 === e ? NaN : e,
            shouldPlay: !1 === e || e >= n.impressionViewableThreshold,
          };
          e !== i && n.dispatchToCreative("visibilityupdate", t), (i = e);
        });
    },
    addAPICreativeProperties: function (e) {
      var t = this;
      t.setCreativeProperty("state", e ? t.api.getState() : "loading"),
        t.setCreativeProperty("isViewable", !!e && t.api.isViewable()),
        t.mayExpand
          ? (t.setCreativeProperty(
              "orientation",
              (e ? t.api : t.api.fallbackAPI).getOrientation()
            ),
            t.setCreativeProperty(
              "maxWidth",
              e
                ? t.api.getMaxSize().width
                : window["ftImp" + t.placement.id] &&
                  window["ftImp" + t.placement.id].wurfl
                ? window["ftImp" + t.placement.id].wurfl.maxWidth
                : window.innerWidth
            ),
            t.setCreativeProperty(
              "maxHeight",
              e
                ? t.api.getMaxSize().height
                : window["ftImp" + t.placement.id] &&
                  window["ftImp" + t.placement.id].wurfl
                ? window["ftImp" + t.placement.id].wurfl.maxHeight
                : window.innerHeight
            ))
          : (t.setCreativeProperty("orientation", 0),
            t.setCreativeProperty("maxWidth", t.creative.width),
            t.setCreativeProperty("maxHeight", t.creative.height));
    },
    addAPIListeners: function () {
      function t() {
        i.api._ORIENTATION !== i.api.getOrientation() &&
          (i.sendOrientation(), i.is.ios) &&
          i.dispatchToCreative("maxsizechange", i.getSizeAndScale()),
          i.inApp ||
            (i.goneFullscreen && i.fullPageResize(i.getSizeAndScale()),
            i.is.ios) ||
            i.dispatchToCreative("maxsizechange", i.getSizeAndScale());
      }
      var i = this,
        e = i.w,
        n = "orientationchange",
        a = [];
      i.api.addEventListener("stateChange", function (e) {
        i.dispatchToCreative("statechange", e),
          "default" === e &&
            /(resized|expanded)/.test(i.api._STATE) &&
            (i.contract(), i.compareVersions(i.ftVersion, "2.6")) &&
            i.dispatchToCreative("contract"),
          (i.api._STATE = e);
      }),
        i.is.ios && !1 === i.inApp && window.matchMedia
          ? (window.addEventListener("pageshow", t),
            window
              .matchMedia("(orientation:portrait)")
              .addListener(function () {
                setTimeout(t);
              }))
          : (i.is.mobile || i.is.ios || i.is.android) &&
            (i.w.ScreenOrientation
              ? ((e = i.w.screen.orientation), (n = "change"))
              : i.w.screen.msOrientation
              ? ((e = i.w), (n = "orientationchange"))
              : i.w.screen.mozOrientation &&
                ((e = i.w.screen), (n = "mozorientationchange")),
            i.listen(
              e,
              n,
              function () {
                function e(e) {
                  (e && "resize" !== e.type) || t(),
                    i.w.removeEventListener("resize", i.checkOrientation, !1),
                    clearTimeout(a.shift());
                }
                i.listen(i.w, "resize", e, !0), a.push(setTimeout(e, 30));
              },
              !1
            )),
        i.listen(i.w, "resize", t, !0),
        /^2/.test(i.api.getVersion()) &&
          i.api.addEventListener("sizeChange", function (e, t) {
            e.width && ((t = e.height), (e = e.width)),
              i.dispatchToCreative("maxsizechange", i.getSizeAndScale(e, t)),
              i.sendOrientation(e, t);
          }),
        i.api.addEventListener("viewableChange", function (e) {
          i.dispatchToCreative("viewablechange", e);
        });
    },
    addListeners: function () {
      var t = this;
      t.interactionManager(),
        t.politeLoadSetup(),
        t.adVisibilityListener(),
        t.touchAbsorber(t.absorbSwipes),
        t.subloadSetup(),
        t.addEventListener("expand", function (e) {
          t.ftVersion &&
            0 <= t.compareVersions(t.ftVersion, "2.6") &&
            t.dispatchToCreative("expand", e);
        }),
        t.addEventListener("contract", function () {
          t.ftVersion &&
            0 <= t.compareVersions(t.ftVersion, "2.6") &&
            t.dispatchToCreative("contract");
        });
    },
    allowFullscreen: function (e) {
      try {
        var t = (e || window).frameElement;
        t.setAttribute("webkitallowfullscreen", ""),
          t.setAttribute("mozallowfullscreen", ""),
          t.setAttribute("allowfullscreen", "");
      } catch (e) {}
    },
    breakout: function () {
      var e = this,
        t = e.parseURL(document.referrer),
        i = t.host,
        n = "?ifsrc=";
      if (e.iframe && i !== location.host && "" !== i) {
        if (
          !(
            -1 <
            self.location.href.indexOf(e.campaignSite.site.fallbackFilePath)
          )
        )
          return (
            e.secure &&
              (e.jsurl = e.jsurl.replace(
                /\bhttp:\/\/(cdn(?=\.flash)|video(?=\.flash)|stat(?=\.flash)|a(?=\.flash))/,
                "https://cdn"
              )),
            (n += encodeURIComponent(
              e.jsurl + "&" + e.params + e.getQsVarsAsSearchParams()
            )),
            (t =
              t.protocol +
              "//" +
              i +
              "/" +
              e.campaignSite.site.fallbackFilePath +
              n),
            e.locationReplace(t),
            (e.breakingOut = !0)
          );
        e.qs = function (e, t) {
          return qs.get(e, t);
        };
      }
      return !1;
    },
    contract: function () {
      var e,
        t = this,
        i =
          (t.forcedScrollPosition !==
            (t.w.scrollY ||
              t.w.document.body.scrollTop ||
              t.w.document.documentElement.scrollTop) &&
            t.w.setTimeout(function () {
              t.w.scrollTo(0, t.forcedScrollPosition);
            }, 1),
          t.$(t.markup.iframe.id)),
        n = new Date(),
        n = t.expandCounter
          ? Math.floor((n.getTime() - t.expandCounter.getTime()) / 100)
          : 0;
      for (e in ((i.style.cssText = ""),
      10 <= n && t.fireEvent(t.event.EXPAND_TIME, n),
      t.goneFullscreen &&
        (t.setScroll(!0), (t.goneFullscreen = !1), t.touchAbsorber(!1)),
      (t.forceOrientation = "none"),
      (t.expandCounter = 0),
      /(resiz|expand)ed/.test(t.api.getState()) &&
        ((t.api._STATE = "default"), t.api.close()),
      t.cachedBodyStyles))
        (document.body.style[e] = t.cachedBodyStyles[e]),
          delete t.cachedBodyStyles[e];
      t.hasOwnProperty("shiftObaIcon") && t.shiftObaIcon("contract"),
        t.hasOwnProperty("shiftFtrackIcon") && t.shiftFtrackIcon("contract"),
        t.dispatchEvent("contract");
    },
    customPosition: function (e) {
      (this.customPos = !0), (this.customPosFunc = e);
    },
    dispatchToCreative: function (e, t) {
      function i(e, t) {
        n.send(n.adWindow, { method: "dispatch", msg: { ev: e, msg: t } });
      }
      var n = this;
      n.adReady
        ? i(e, t)
        : n.once("adready", function () {
            i(e, t);
          });
    },
    displayAd: function (e) {
      var t = this,
        i = t.surveys.length;
      for (
        t.outputDiv("complex", e),
          e &&
            ((t.adDiv =
              t.w.document.getElementById(t.markup.div.id) ||
              document.getElementById(t.markup.div.id)),
            t.frameless ||
              ((t.adFrame =
                t.w.document.getElementById(t.markup.iframe.id) ||
                document.getElementById(t.markup.iframe.id)),
              (t.adWindow = t.adFrame.contentWindow))),
          t.addListeners();
        i--;

      )
        "" !== t.surveys[i] &&
          t.appendScriptToHead(t.replaceMacros(t.surveys[i]));
      t.dispatchEvent("end");
    },
    expand: function (t) {
      var i = this,
        n =
          ((i.forcedScrollPosition =
            i.w.scrollY ||
            i.w.document.body.scrollTop ||
            i.w.document.documentElement.scrollTop),
          (t.indentAcross = t.indentAcross || 0),
          (t.indentDown = t.indentDown || 0),
          i.getSizeAndScale()),
        a = i.$(i.markup.iframe.id),
        r = {
          left:
            (i.inApp
              ? 0
              : t.fullscreen
              ? -a.x()
              : -parseInt(t.indentAcross, 10)) + "px",
          width: (t.fullscreen ? n.width : parseInt(t.width, 10)) + "px",
          top:
            (i.inApp
              ? 0
              : t.fullscreen
              ? -a.y()
              : -parseInt(t.indentDown, 10)) + "px",
          height: (t.fullscreen ? n.height : parseInt(t.height, 10)) + "px",
          position: "absolute",
          "z-index": i.zIndex,
          scale: t.fullscreen ? n.scale : 1,
        },
        o = new Date(),
        s = function (e) {
          i.api.removeEventListener("stateChange", s),
            ("expanded" !== e && "resized" !== e) ||
              ((r["transform-origin"] = "0 0"),
              (r.transform = "scale(" + ((t.fullscreen && n.scale) || 1) + ")"),
              (a.style.cssText = i.expandCss(r)),
              i.event.EXPAND &&
                (i.fireEvent(i.event.EXPAND), (i.event.EXPAND = !1)),
              i.requestExpandTracking(),
              (i.expandCounter = o),
              t.fullscreen &&
                i.getFSElement() !== i.adFrame &&
                i.fullPageResize(i.getSizeAndScale(), n),
              i.hasOwnProperty("shiftObaIcon") && i.shiftObaIcon("expand", t),
              i.hasOwnProperty("shiftFtrackIcon") &&
                i.shiftFtrackIcon("expand", t),
              i.dispatchEvent("expand", t));
        };
      t.fullscreen &&
        ((i.forceOrientation = t.forceOrientation || "none"),
        (i.forceOrientation =
          "none" !== i.forceOrientation
            ? i.forceOrientation
            : !1 === t.allowOrientationChange
            ? n.orientation % 180 == 0
              ? "portrait"
              : "landscape"
            : "none"),
        i.setScroll(),
        (t.width = parseFloat(r.width, 10)),
        (t.height = parseFloat(r.height, 10)),
        (i.cachedBodyStyles = {
          overflow: document.body.style.overflow || "",
          overflowX: document.body.style.overflowX || "",
          overflowY: document.body.style.overflowY || "",
        }),
        (document.body.style.overflow = "hidden"),
        (document.body.style.overflowX = "hidden"),
        (document.body.style.overflowY = "hidden"),
        i.touchAbsorber(!0)),
        (i.goneFullscreen = t.fullscreen),
        i.api.addEventListener("stateChange", s),
        "loading" === i.api.getState()
          ? i.api.addEventListener("ready", function () {
              i.api.expand(t);
            })
          : i.api.expand(t);
    },
    expandCss: function (e) {
      var t,
        i,
        n = "",
        a =
          "portrait" === this.forceOrientation
            ? 0 -
              ("number" == typeof this.w.orientation
                ? this.w.orientation
                : this.api.getOrientation())
            : 90;
      if (this.getFSElement() === this.adFrame) return "";
      for (i in (this.switchDimensions() &&
        ((t = e.width),
        (e.width = e.height),
        (e.height = t),
        (e.transform += "rotate(" + a + "deg)"),
        a < 0
          ? ((e["transform-origin"] =
              parseInt(e.width, 10) * (e.scale || 1) + "px 0"),
            (e.left =
              parseInt(e.left, 10) -
              parseInt(e.width, 10) * (e.scale || 1) +
              "px"))
          : (e.left =
              parseInt(e.left, 10) +
              parseInt(e.height, 10) * (e.scale || 1) +
              "px")),
      e))
        n += i + ":" + e[i] + ";";
      return n;
    },
    fireEvent: function (e, t, i) {
      var n = this.statBaseUrl,
        a = Math.floor(1e7 * Math.random());
      (n +=
        this.confID +
        "-" +
        e +
        "-" +
        (t = t || "0") +
        "-" +
        this.GUID +
        "-" +
        a +
        (i = i ? "-" + i : "")),
        this.api.request(n, "proxy");
    },
    fullPageResize: function (t, i) {
      var n,
        a = this,
        r = a.$(),
        o = a.$(a.markup.iframe.id);
      setTimeout(
        function () {
          var e =
            window.devicePixelRatio ||
            window.screen.availWidth / document.documentElement.clientWidth;
          a.inApp && i && i.height > t.height
            ? (t = i)
            : a.inApp &&
              !i &&
              ((t.width = Math.floor(t.width / e)),
              (t.height = Math.floor(t.height / e)),
              (t.scale = a.api.fallbackAPI.getMaxSize().width / t.width)),
            a.goneFullscreen &&
              (a.setScroll(),
              ((n = {
                width: t.width / t.scale + "px",
                height: t.height / t.scale + "px",
                left: -r.x() + "px",
                top: -r.y() + "px",
                position: "absolute",
                "z-index": a.zIndex,
                scale: t.scale,
                "transform-origin": "0 0",
              }).transform = "scale(" + t.scale + ")"),
              (o.style.cssText = a.expandCss(n)));
        },
        /rubicon/i.test(a.parseURL(location.host).domain) ? 350 : 25
      );
    },
    getCreativeProperties: function () {
      var e,
        t = "",
        i = "";
      for (e in this.creativePropertiesList)
        (t += i + e + "=" + encodeURIComponent(this.creativePropertiesList[e])),
          (i = "&");
      return t;
    },
    getFSElement: function () {
      return (
        document.fullscreenElement ||
        document.webkitFullscreenElement ||
        document.mozFullScreenElement ||
        document.msFullscreenElement
      );
    },
    getQsVarsAsSearchParams: function () {
      var t,
        i,
        n = "",
        a = this;
      return (
        (a.qsVars || []).forEach(function (e) {
          (t = e[0] || null),
            (i = "ajs" === e[1] ? a : window[e[1]] || null),
            e.length < 3
              ? (n += "&" + t + "=" + encodeURIComponent(i || ""))
              : i &&
                i[e[2]] &&
                (n += "&" + t + "=" + encodeURIComponent(i[e[2]]));
        }),
        n
      );
    },
    getSizeAndScale: function (e, t) {
      var i = this,
        n = i.api.getMaxSize(),
        a = i.api.getOrientation(e, t),
        r = document.documentElement.clientWidth,
        o = document.documentElement.clientHeight,
        s = i.w.screen.orientation;
      return (
        (n.width = e || n.width),
        (n.height = t || n.height),
        (n.orientation = 270 === a ? 90 : a),
        (n.scale =
          n.scale && !i.lockableOrientation && "none" !== i.forceOrientation
            ? n.scale
            : 1),
        (n.angle = s ? s.angle : a),
        (n.type = s
          ? s.type
          : (e || n.width) > (t || n.height)
          ? "landscape"
          : "portrait"),
        i.is.android &&
          n.width >=
            (a % 180 == 0
              ? Math.min(r, o === i.creative.height ? r + 1 : o)
              : Math.max(r, o)) *
              window.devicePixelRatio &&
          ((n.height /= window.devicePixelRatio),
          (n.width /= window.devicePixelRatio)),
        n
      );
    },
    html_communication: function () {
      window.ftSharedObject = window.ftSharedObject || {
        ads: {},
        add: function (e, t) {
          function i(e, t) {
            e.adReady
              ? e.send(e.adWindow, {
                  method: "communicate",
                  msg: { name: t, type: "register" },
                })
              : e.addEventListener("adready", function () {
                  i(e, t);
                });
          }
          for (var n in this.ads) i(this.ads[n], e), i(t, n);
          this.ads[e] = t;
        },
        send: function (e, t, i) {
          void 0 !== this.ads[e] &&
            (e = this.ads[e]).send(e.adWindow, {
              method: "communicate",
              msg: { msg: t, name: i, type: "talk" },
            });
        },
      };
      try {
        window.parent.ftSharedObject = window.ftSharedObject;
      } catch (e) {}
      return window.ftSharedObject;
    },
    init: function () {
      function e() {
        t.displayAd(n);
      }
      var t = this,
        i =
          (t.hasOwnProperty("campaign") &&
            t.campaign.hasOwnProperty("isAdVisibility") &&
            (t.adVis = t.adVis ? 1 : 0),
          (t.absorbSwipes = "true" === t.absorbSwipes),
          t.creative &&
            t.creative.apiVersion &&
            "string" == typeof t.creative.apiVersion &&
            (t.creative.apiVersion =
              ((i = (t.creative.apiVersion || "").split(".")),
              {
                major: parseInt(i[0], 10) || 0,
                minor: parseInt(i[1], 10) || 0,
                patch: parseInt(i[2], 10) || 0,
              })),
          (t.append = !(
            !window["ftImp" + t.placement.id] ||
            1 !== parseInt(window["ftImp" + t.placement.id].jsAppend, 10)
          )),
          (t.creative.blockBrowsers = t.creative.blockBrowsers || []),
          "string" == typeof t.creative.blockBrowsers &&
            (t.creative.blockBrowsers = t.creative.blockBrowsers.split(",")),
          (t.clicks = {}),
          (t.event = {
            INTERACTION: "18",
            INTERACTION_TIME: "19",
            EXPAND: "20",
            EXPAND_TIME: "30",
            CLICKMAP: "95",
            VIDEO: {
              init: "1",
              replay: "2",
              starts: "3",
              "25%": "4",
              "50%": "5",
              "75%": "6",
              "100%": "7",
              unmute: "38",
            },
            extra: {},
          }),
          (t.expID = "ftexpframe" + t.placement.id),
          t.hasOwnProperty("isForceBackup") &&
            (t.isForceBackup = "true" === t.isForceBackup),
          (t.ajsToCreativePropertiesList = [
            ["adVis", "adVis"],
            ["divID", "markup.div.id"],
            ["ftfuncid", "placement.id"],
            ["creativeID", "creative.id"],
            ["cID", "creative.creativeLibrary.id"],
            ["ftPlacementID", "placement.id"],
            ["aID", "aID"],
            ["pID", "placement.id"],
            ["ftSetFileSize", "setFileSize"],
            ["ftStatBaseURL", "statBaseUrl"],
            ["ftMVT", "creative.isInstantAd"],
            ["ftServeDom", "ftCdnUrl"],
            ["serveDom", "ftCdnUrl"],
            ["ftSegment", "segment"],
            ["ftSegmentList", "segmentList"],
            ["ftLinkMode", "linkMode"],
            ["ftLinkID", "linkID"],
            ["ftPL", "isPoliteLoad"],
            ["ftStreamMode", "streamMode"],
            ["ftReturn", "ftReturn"],
            ["guid", "GUID"],
            ["ftBrowserInfo", "is"],
            ["clicks", "clicks"],
            ["impressionID", "ftImpId"],
            ["ftServedStump", "stump"],
            ["siteID", "siteID"],
            ["clickEvents", "landingPageEventRedirects"],
            ["campaignName", "campaign.name"],
            ["siteName", "campaignSite.site.name"],
            ["placementName", "placement.name"],
            ["creativeName", "creative.name"],
            ["clientID", "campaign.advertiser.id"],
            ["campaignID", "campaign.id"],
            ["siteID", "campaignSite.site.id"],
          ]),
          (t.windowToCreativePropertiesList = [
            ["ftGUID", "ftGUID_"],
            ["ftConfID", "ftConfID_"],
            ["ftKeyword", "ftKeyword_"],
            ["ftSegment", "ftSegment_"],
            ["ftGeoCountry", "ftGeoC2_"],
            ["ftGeoState", "ftGeoState_"],
            ["ftGeoCity", "ftGeoCity_"],
            ["ftGeoISP", "ftISP_"],
            ["ftGeoSpeed", "ftSpeed_"],
            ["ftDMA", "ftDMA_"],
            ["ftLong", "ftLong_"],
            ["ftLat", "ftLat_"],
            ["ftPostal", "ftPostal_"],
          ]),
          (t.GUID = window["ftGUID_" + t.placement.id] || "99999999999"),
          (t.imp = window["ftImp" + t.placement.id]),
          (t.mayExpand =
            t.creative.expandedHeight > t.creative.height ||
            t.creative.expandedWidth > t.creative.width ||
            !1),
          (t.phID = "ftpos" + t.placement.id),
          (t.qsVars = [
            ["ftguid", "ftGUID_" + t.placement.id],
            ["ftcfid", "ftConfID_" + t.placement.id],
            ["fttime", "ftTimestamp_" + t.placement.id],
            ["ftsection", "ftSection_" + t.placement.id],
            ["ftcustom", "ftCustom_" + t.placement.id],
            ["ft_id", "ftId_" + t.placement.id],
            ["ftimpid", "ftImp" + t.placement.id, "impID"],
            ["gdpr", "ftImp[%pID%]", "gdpr"],
            ["gdpr_consent", "ftImp[%pID%]", "gdpr_consent"],
            ["gdpr_pd", "ftImp[%pID%]", "gdpr_pd"],
            ["us_privacy", "ftImp[%pID%]", "us_privacy"],
            ["gpp", "ajs", "gpp"],
            ["gpp_sid", "ajs", "gpp_sid"],
          ]),
          (t.safeFrame = (window.$sf && window.$sf.ext) || !1),
          (t.segment = window["ftSegment_" + t.placement.id] || ""),
          (t.attachtobody = t.attachtobody || null),
          (t.baggyFrameLimit = t.baggyFrameLimit || null),
          (t.politeLoad = t.isPoliteLoad || t.politeLoad || null),
          t.hasOwnProperty("tracking3rdParty")
            ? (t.tracking3rdParty.videoQuartiles &&
                null !== t.tracking3rdParty.videoQuartiles &&
                "object" != typeof t.tracking3rdParty.videoQuartiles &&
                (t.tracking3rdParty.videoQuartiles = JSON.parse(
                  t.tracking3rdParty.videoQuartiles.replace(
                    /^(\[%\w+%])?$/,
                    "{}"
                  )
                )),
              t.tracking3rdParty.userEngagement &&
                (t.tracking3rdParty.userEngagement =
                  t.tracking3rdParty.userEngagement.replace(/^\[%\w+%\]$/, "")))
            : (t.tracking3rdParty = { videoQuartiles: {}, userEngagement: "" }),
          (t.ext = t.ext || "gif"),
          (t.markup.image.src =
            t.campaign.servedByDomain +
            "/imp/3/" +
            t.campaign.id +
            ";" +
            t.placement.id +
            ";204;" +
            t.ext +
            ";" +
            t.campaignSite.site.id +
            ";" +
            t.placement.id +
            "/?"),
          (t.jsurl =
            "https://ajs-assets.ftstatic.com/ftUtils.js?placementId=" +
            t.placement.id +
            "&creativeId=" +
            t.creative.id),
          (t.noBreakout = t.ftifroverride || t.noBreakout || null),
          (t.segmentList = (
            window["ftSegmentList_" + t.placement.id] || []
          ).slice(0)),
          t.creative.hasOwnProperty("version") &&
            (t.creativePropertiesList.creativeVersion = t.creative.version),
          (t.forceBackup = t.isForceBackup),
          (t.fVarList = t.creativePropertiesList),
          (t.apiVersion = t.creative.apiVersion),
          (t.flashVarHolder = t.ajsToCreativePropertiesList),
          (t.gFlashVarList = t.windowToCreativePropertiesList),
          (t.flashVar = t.setCreativeProperty),
          (t.mvt = t.creative.isInstantAd),
          (t.ftlocal = t.ftlocal || "flashtalking/ftlocal.html"),
          (t.zIndex = t.zIndex || 77e3),
          (t.qs = t.setupQS(t.params)),
          void 0 !== t.paramsMap.frameless &&
            ((t.frameless = t.paramsMap.frameless), (t.markup.frameless = {})),
          (t.gpp = t.paramsMap.gpp || ""),
          (t.gpp_sid = t.paramsMap.gpp_sid || ""),
          t.addFrequencySignalling(),
          t.addFtrack(),
          t.processMutations(),
          (t.landingPageEventRedirects = (
            t.landingPageEventRedirects || []
          ).map(function (e) {
            return t.replaceMacros(t.appendLandingPageSuffix(e));
          })),
          (t.receiveMethod.placement = t.receiveMethod.placement || {}),
          (t.receiveMethod.placement.id = "" + t.placement.id),
          (window.innerWidth || document.documentElement.offsetWidth) >=
            t.creative.width + t.baggyFrameLimit &&
            (window.innerHeight || document.documentElement.offsetHeight) >=
              t.creative.height + t.baggyFrameLimit),
        n = t.supportedBrowser(),
        a = t.setAPI("complex");
      if (
        (t.setup(t.placement.id, "complex"),
        t.onAPIReady(a),
        t.addAPICreativeProperties(a),
        t.removeMargin(t.inApp || (t.w !== window.top && !i)),
        t.requestAllImpressions(),
        t.dispatchEvent("start"),
        n)
      ) {
        if (
          ((t.adId = t.markup.iframe.id),
          t.mayExpand && t.shouldBreakout && t.shouldBreakout(i))
        )
          return;
        t.messageListen();
      } else t.adId = t.markup.anchor.id;
      t.setupPageVisibility(),
        "loading" === t.api.getState() && t.append
          ? t.api.addEventListener("ready", e)
          : e();
    },
    interactionManager: function () {
      var t,
        i = this,
        n = 10,
        a = 6e3,
        r = 0,
        o = i.is.mobile,
        e = i.tracking3rdParty.userEngagement,
        s = !0;
      function c() {
        i.dispatchEvent("interaction"),
          (o &&
            i.mayExpand &&
            !/^(?:expanded|resized)$/i.test(i.api.getState())) ||
            ((r = new Date()),
            s &&
              (t = setTimeout(function () {
                i.fireEvent(i.event.INTERACTION),
                  e && i.api.request(i.replaceMacros(e)),
                  (s = !1);
              }, 1e3))),
          i.send(i.adWindow, { method: "dispatch", msg: "rollover" });
      }
      function d() {
        t && (clearTimeout(t), (t = null));
        var e = new Date(),
          e = Math.floor((e.getTime() - (r ? r.getTime() : 0)) / 100);
        n <= e &&
          0 < r &&
          ((e = Math.min(e, a)), i.fireEvent(i.event.INTERACTION_TIME, e)),
          (r = 0),
          i.send(i.adWindow, { method: "dispatch", msg: "rollout" });
      }
      !(function e() {
        (i.adDiv = i.$().target),
          i.adDiv.id
            ? ((i.adFrame = i.backupDisplayed
                ? null
                : i.$(i.markup.iframe.id).target),
              (i.adWindow = i.adFrame ? i.adFrame.contentWindow : window),
              (i.receiveMethod.interaction = function () {
                r || c();
              }),
              (i.receiveMethod.interactionComplete = function () {
                d();
              }),
              i.listen(i.adDiv, "mouseover", c),
              i.listen(i.adDiv, "mouseout", d),
              i.listen(i.w, "beforeunload", d),
              i.backupDisplayed || i.listen(i.w, "touchstart", d),
              o &&
                (i.listen(i.w, "scroll", function () {
                  !1 === /(resiz|expand)ed/.test(i.api.getState()) &&
                    ((r = 0), d());
                }),
                i.addEventListener("contract", d),
                i.addEventListener("clickthrough", d),
                i.addEventListener("viewableChange", function (e) {
                  e || d();
                })))
            : setTimeout(e, 10);
      })();
    },
    locationReplace: function (e) {
      document.location.replace(e);
    },
    messageListen: function () {
      var t = this;
      t.listen(t.w, "message", function (e) {
        t.receive(e);
      });
    },
    nuke: function () {
      var e = this,
        t = e.$();
      e.contract(),
        t.parent().target &&
          t.parent().target.removeChild &&
          t.parent().target.removeChild(t.target),
        e.api.close(),
        "default" === e.api.getState() && e.api.close(),
        e.cachedEvents
          .filter(function (e) {
            return 3 === e.length;
          })
          .forEach(function (e) {
            e[0].removeEventListener(e[1], e[2], !1);
          }),
        (e.cachedEvents = []),
        e.dispatchEvent("nuke");
    },
    nullifySwipe: function (e) {
      e.preventDefault && e.preventDefault(),
        e.stopPropagation && e.stopPropagation();
    },
    onAPIReady: function (e) {
      var t = this,
        i = t.api.fallbackAPI !== t.api._BRIDGE;
      "loading" === e
        ? t.api.addEventListener("ready", function () {
            (t.api._STATE = t.api.getState()),
              t.api.processQueuedListeners(),
              t.addAPIListeners(i);
          })
        : t.addAPIListeners(i);
    },
    politeLoadSetup: function () {
      var e = this;
      "complete" !== document.readyState && "loaded" !== document.readyState
        ? window.setTimeout(function () {
            e.politeLoadSetup();
          }, 15)
        : e.dispatchToCreative("politeload");
    },
    receive: function (e) {
      var t,
        i,
        n,
        a = !1,
        r = this,
        o = e.data;
      if ("string" == typeof e.data)
        try {
          o = JSON.parse(e.data);
        } catch (e) {}
      if ("Innovid Placement" !== o.source)
        if (
          o.msg &&
          o.msg.hasOwnProperty("placementId") &&
          o.msg.placementId !== r.placement.id
        )
          try {
            window["ft" + o.msg.placementId].receive(e);
          } catch (e) {
            console.warn(
              "The placement IDs did not match between messages and something went wrong. \nError message: ",
              e
            );
          }
        else if (
          (!r.ftCdnUrl ||
            /^https?:\/\/[a-z0-9\-\.]*flashtalking\.(com|net|dev)/i.test(
              e.origin.toString()
            ) ||
            r.adWindow === e.source) &&
          (r.creative.apiVersion &&
            0 === r.creative.apiVersion.major &&
            o.msg.version &&
            ((t = String(o.msg.version).split(".")),
            (r.creative.apiVersion = {
              major: parseInt(t[0], 10) || 0,
              minor: parseInt(t[1], 10) || 0,
              patch: parseInt(t[2], 10) || 0,
            })),
          "ready" === o.method &&
            (r.frameless || -1 < o.msg.location.indexOf(r.markup.iframe.src)) &&
            (r.adWindow = e.source),
          e.source === r.adWindow)
        ) {
          try {
            n = r.receiveMethod[o.method].call(r, o.msg, r);
          } catch (e) {
            (a = !0), (i = e.message);
          }
          r.creative.apiVersion &&
            3 <= r.creative.apiVersion.major &&
            r.send(e.source, {
              correlationId: o.messageId,
              isError: a,
              value: n,
              error: i,
            });
        }
    },
    receiveMethod: {
      ready: function (e, t) {
        if (
          ((this.readyCount = this.readyCount || 0),
          (this.parentElement = this.parentElement || null),
          !(
            0 < this.readyCount &&
            null !== this.parentElement &&
            document.querySelector("#" + t.divID).parentNode ===
              this.parentElement
          ))
        ) {
          var i = {
            confID: t.confID,
            creativeID: t.creative.id,
            cID: t.creative.creativeLibrary.id,
            serveDOM: t.ftCdnUrl,
            mvt: t.creative.isInstantAd,
            api: t.api._BRIDGE === t.api.fallbackAPI ? "ft" : "ext",
            guid: t.GUID,
          };
          if (
            ((t.adReady = !0),
            t.compareVersions("" + e.version || "0", "2.9") < 0)
          )
            for (var n in ((i.clicks = t.clicks), t.creativePropertiesList))
              i[n] = t.creativePropertiesList[n];
          document.addEventListener &&
            document.addEventListener(
              "touchstart",
              function e() {
                document.removeEventListener("touchstart", e, !0),
                  t.send(t.adWindow, { method: "dispatch", msg: "firsttouch" });
              },
              !0
            ),
            t.send(t.adWindow, { method: "init", msg: i }),
            (t.adFrame.style.visibility = ""),
            (t.ftVersion = String(e.version || "")),
            t.dispatchEvent("adready", { ad: t.adWindow }),
            !1 === t.inApp &&
              ((t.api.fallbackAPI._STATE = "default"),
              t.api.dispatchEvent("ready")),
            this.readyCount++,
            (this.parentElement = document.querySelector(
              "#" + t.divID
            ).parentNode);
        }
      },
      tracker: function (e, t) {
        t.trackerManager(e);
      },
      expand: function (e, t) {
        t.expand(e);
      },
      contract: function (e, t) {
        t.mayExpand && t.contract();
      },
      open: function (e, t) {
        t.api.open(e);
      },
      destroy: function (e, t) {
        t.nuke();
      },
      nuke: function (e, t) {
        t.nuke();
      },
      mraidcustomclose: function (e, t) {
        t.api.useCustomClose(e);
      },
      clickthrough: function (e, t) {
        t.dispatchEvent("clickthrough", e);
      },
      click: function (e, t) {
        e = e.url || t.clicks["clickTag" + (e.clickTag || "")];
        t.api.open(e);
      },
      communicate: function (e, t) {
        var i;
        try {
          i = window.parent.ftSharedObject || window.ftSharedObject;
        } catch (e) {
          i = window.ftSharedObject;
        }
        "register" === e.type
          ? ((this.name = e.name), i.add(e.name, this))
          : i.send(e.name, e.msg, this.name);
      },
      preventSwipes: function (e, t) {
        t.touchAbsorber(e);
      },
      interaction: function (e, t) {},
      interactionComplete: function (e, t) {},
    },
    requestExpandTracking: function () {
      var e = this,
        t = e.decode(e.qs("ftExpTrack", ""));
      t &&
        !e.expandTracked &&
        ((new Image().src = e.replaceMacros(t)), (e.expandTracked = !0));
    },
    send: function (e, t) {
      e &&
        e.parent &&
        ((t.placementId = this.placement.id),
        (t.creativeId = this.creative.id),
        (t.source = "Innovid Placement"),
        e.postMessage(
          this.creative.apiVersion && 3 <= this.creative.apiVersion.major
            ? t
            : JSON.stringify(t),
          "*"
        ));
    },
    sendOrientation: function (e, t) {
      var i = this,
        e = i.getSizeAndScale(e, t);
      i.goneFullscreen && i.fullPageResize(e),
        i.api._ORIENTATION !== e.orientation &&
          ((i.api._ORIENTATION = e.orientation),
          i.dispatchToCreative("orientationchange", e));
    },
    setCreativeProperty: function (e, t) {
      e && "string" == typeof e && (this.creativePropertiesList[e] = t);
    },
    setSFEnvironment: function () {
      var e = this,
        t = document.querySelector("#ftscript_m" + e.placement.id),
        i = e.makeElement("iframe"),
        n =
          "width:" +
          e.creative.width +
          "px; height:" +
          e.creative.height +
          "px; border:none;";
      (window["ftImp" + e.placement.id] =
        window["ftImp" + e.placement.id] || {}),
        (window["ftImp" + e.placement.id].jsAppend = e.append = 1),
        (i.style.cssText = n),
        t.parentNode.insertBefore(i, t),
        (e.w = i.contentWindow),
        e.w.document.open(),
        e.w.document.write(
          '<!DOCTYPE HTML><html><head></head><body style="margin:0;text-align:right;"><div id="ref"></div></body></html>'
        ),
        e.w.document.close(),
        (e.scriptLocation = e.w.document.getElementById("ref")),
        e.addEventListener("end", function () {
          (e._expand = e.expand),
            (e._contract = e.contract),
            (e.expand = function () {
              e._expand.apply(e, arguments),
                (e.adDiv.style.position = "absolute"),
                (e.adDiv.style.right = e.adDiv.style.top = 0),
                (i.style.width = e.adFrame.style.width),
                (i.style.height = e.adFrame.style.height);
            }),
            (e.contract = function () {
              e._contract.apply(e, arguments), (i.style.cssText = n);
            });
        }),
        window.DARLA && (e.secure = !0);
    },
    setScroll: function (e) {
      var t = this;
      !0 === e
        ? (t.w.scrollTo(t.scrollXVal || 0, t.scrollYVal || 0),
          (t.scrollXVal = -1),
          (t.scrollYVal = -1))
        : ((t.scrollXVal = t.scrollXVal < 0 ? t.w.pageXOffset : t.scrollXVal),
          (t.scrollYVal = t.scrollYVal < 0 ? t.w.pageYOffset : t.scrollYVal),
          !1 !== t.to00 && t.w.scrollTo(0, 0));
    },
    setup: function () {
      var i = this,
        n = this.placement.id,
        e =
          !!i.safeFrame ||
          (-1 === i.creative.adType.indexOf("expand") && !i.mayExpand);
      i.html_communication(),
        (i.confID = window["ftConfID_" + n] =
          window["ftConfID_" + n] || i.qs("ftcfid", "0")),
        (i.GUID = window["ftGUID_" + n] =
          window["ftGUID_" + n] || i.qs("ftguid", "99999999999999")),
        (i.timestamp = window["ftTimestamp_" + n] =
          window["ftTimestamp_" + n] || i.qs("fttime", "99999999999999")),
        (i.custom = window["ftCustom_" + n] =
          window["ftCustom_" + n] || i.qs("ftcustom", "")),
        (i.section = window["ftSection_" + n] =
          window["ftSection_" + n] || i.qs("ftsection", "")),
        (i.ftId = window["ftId_" + n] =
          window["ftId_" + n] || i.qs("ft_id", "")),
        (i.ftImpId =
          (window["ftImp" + n] && window["ftImp" + n].impID) ||
          i.qs("ftimpid", "")),
        i.ftImpId &&
          window["ftImp" + n] &&
          !window["ftImp" + n].impID &&
          (window["ftImp" + n].impID = i.ftImpId),
        i.privacyParams.forEach(function (e) {
          var t =
            (window["ftImp" + n] ? window["ftImp" + n][e] : null) ||
            i.qs(e, "");
          t &&
            !window["ftImp" + n].hasOwnProperty(e) &&
            (window["ftImp" + n][e] = t);
        }),
        (i.noBreakout = e || i.noBreakout),
        (i.attachtobody = !e && i.attachtobody),
        i.setupClickTags(),
        i.setupCreativeProperties(),
        i.safeFrame &&
          "function" == typeof i.safeFrame.register &&
          i.safeFrame.register(i.creative.width, i.creative.height);
    },
    setupClickTags: function () {
      var i = this;
      (i.clickTags = i.clickTags.map(function (e) {
        return i.convertUrlProtocol(e);
      })),
        (i.clicks = i.clicks || {}),
        i.modifyClicks().forEach(function (e, t) {
          i.clicks["clickTag" + (t + 1)] = e;
        }),
        (i.clicks.clickTag = "" + i.clicks.clickTag1),
        i.storeCreativeProperty("clicks", i.clicks);
    },
    setupCreativeProperties: function () {
      function i(e, t) {
        return e.split(".").reduce(function (e, t) {
          return e.hasOwnProperty(t) && e[t];
        }, n);
      }
      var n = this;
      n.ajsToCreativePropertiesList.forEach(function (e) {
        var t = -1 < e[1].indexOf(".") ? i(e[1]) : n[e[1]];
        t && n.storeCreativeProperty(e[0], t);
      }),
        n.windowToCreativePropertiesList.forEach(function (e) {
          var t =
            -1 < e[1].indexOf(".")
              ? i(e[1], window)
              : window[e[1] + n.placement.id];
          t && n.storeCreativeProperty(e[0], t);
        }),
        [
          ["ftCustom", n.replaceMacros("[ftqs:[ft_custom]]", !0)],
          ["ftSection", n.replaceMacros("[ftqs:[ft_section]]", !0)],
        ].forEach(function (e) {
          e[1] && n.storeCreativeProperty(e[0], e[1]);
        });
    },
    setupExtraQS: function () {
      var e = this,
        t = e.placement.id;
      window.hasOwnProperty("ftGeoC2_" + t) &&
        e.qsVars.push(
          ["ftgc", "ftGeoC2_" + t],
          ["ftgs", "ftGeoState_" + t],
          ["ftgs", "ftGeoState_" + t],
          ["ftgcit", "ftGeoCity_" + t],
          ["ftgi", "ftISP_" + t],
          ["ftgsp", "ftSpeed_" + t],
          ["ftdma", "ftDMA_" + t],
          ["ftlg", "ftLong_" + t],
          ["ftlt", "ftLat_" + t],
          ["ftpst", "ftPostal_" + t]
        ),
        window.hasOwnProperty("ftKeyword_" + t) &&
          e.qsVars.push(["ftkw", "ftKeyword_" + t]),
        void 0 !== window["ftClick_" + t] &&
          -1 === e.params.indexOf("click") &&
          e.qsVars.push(["click", "ftClick_" + t]);
    },
    shouldBreakout: function (e) {
      var t = this,
        i = !1,
        n = (() => {
          try {
            return !parent.document;
          } catch (e) {
            return !0;
          }
        })();
      return (
        t.w === top ||
          t.noBreakout ||
          e ||
          ((t.iframe = !0),
          (t.w = t.w.parent),
          !(i = n ? t.breakout() : i) &&
            t.addAPICreativeProperties &&
            t.addAPICreativeProperties()),
        i
      );
    },
    storeCreativeProperty: function () {
      var t,
        n = this,
        e = 0 === arguments.length,
        i = arguments[0] || null,
        a = arguments[1] || null;
      if (e) return n.getCreativeProperties();
      a
        ? (Array.isArray(i) && (i = i.toString()), n.setCreativeProperty(i, a))
        : ((t = []),
          -1 < i.indexOf("&")
            ? i.split("&").forEach(function (e) {
                t.push(e);
              })
            : t.push(i),
          t.forEach(function (e) {
            var t = e,
              i = "";
            -1 < e.indexOf("=") && ((t = (e = e.split("="))[0]), (i = e[1])),
              n.setCreativeProperty(t, i);
          }));
    },
    subloadSetup: function () {
      function e(e) {
        setTimeout(function () {
          i.dispatchToCreative("subload");
        }, e);
      }
      var t,
        i = this;
      "loading" !== document.readyState
        ? window.performance
          ? ((t = window.performance.timing.domContentLoadedEventEnd),
            (t = Date.now() - t),
            e(1e3 <= t ? 0 : 1e3 - t))
          : e(1e3)
        : i.listen(document, "DOMContentLoaded", function () {
            e(1e3);
          });
    },
    switchDimensions: function (e) {
      return (
        (e = "number" != typeof e ? this.getSizeAndScale().orientation : e),
        (((!this.inApp || !/^2/.test(this.api.getVersion())) &&
          "portrait" === this.forceOrientation &&
          e % 180 != 0) ||
          ("landscape" === this.forceOrientation && e % 180 == 0)) &&
          !this.lockableOrientation
      );
    },
    touchAbsorber: function (e) {
      var t = this;
      e && !t.touchMoveDisabled
        ? (t.listen(t.adDiv, "touchmove", t.nullifySwipe),
          (t.touchMoveDisabled = !0),
          t.addEventListener("adready", function () {
            t.send(t.adWindow, { method: "absorbSwipes", msg: !0 });
          }))
        : t.touchMoveDisabled &&
          !e &&
          (t.adDiv.removeEventListener("touchmove", t.nullifySwipe, !1),
          (t.touchMoveDisabled = !1),
          t.addEventListener("adready", function () {
            t.send(t.adWindow, { method: "absorbSwipes", msg: !1 });
          }));
    },
    trackerManager: function (e) {
      var t = this,
        i = t.tracking3rdParty.videoQuartiles[e.event];
      switch (e.type) {
        case "clickmap":
          t.fireEvent(t.event.CLICKMAP, "0", e.x + "x" + e.y);
          break;
        case "custom":
          t.fireEvent(e.num, e.value, e.string);
          break;
        case "video":
          i && t.api.request(t.replaceMacros(i), "proxy"),
            "unmute" === e.event
              ? t.unmuteDispatched ||
                ((t.unmuteDispatched = !0), t.fireEvent(t.event.VIDEO[e.event]))
              : t.event.VIDEO.hasOwnProperty(e.event) &&
                t.fireEvent(e.id + t.event.VIDEO[e.event], e.duration);
          break;
        default:
          t.event.hasOwnProperty("extra") &&
            void 0 !== t.event.extra[e.type] &&
            t.event.extra[e.type].call(t, e);
      }
    },
  }),
  (() => {
    var p,
      l,
      e,
      t,
      i,
      m =
        document.currentScript ||
        document.querySelector('script[src*="ftUtils.js"]'),
      n = {},
      a = m && null !== m.getAttribute("src") && m.src.split("?")[1];
    a &&
      (a
        .split("&")
        .map(function (e) {
          return e.split("=");
        })
        .forEach(function (e) {
          n[e[0]] = e[1];
        }),
      (t = n["creative-id"] || n.creativeId || !1),
      (i = {
        VPAID: {
          adTimer: void 0,
          adSlot: void 0,
          videoSlot: void 0,
          vidNeedsPlay: void 0,
          isInteracting: void 0,
          isPaused: void 0,
          isLinear: void 0,
          slotWidth: void 0,
          slotHeight: void 0,
          linearVids: {},
          __listeners: {},
          __properties: {
            adLinear: !1,
            adWidth: 0,
            adHeight: 0,
            adExpanded: 0,
            adSkippableState: !0,
            adRemainingTime: 0,
            adDuration: 0,
            adCurrentTime: 0,
            adVolume: 1,
            adCompanions: [],
            adIcons: !1,
            scale: 1,
            video: "",
          },
          getAdCompanions: function () {
            return this.__properties.adCompanions;
          },
          getAdVolume: function () {
            return this.__properties.adVolume;
          },
          getAdExpanded: function () {
            return this.__properties.adExpanded;
          },
          getAdLinear: function () {
            return this.__properties.adLinear;
          },
          getAdIcons: function () {
            return this.__properties.adIcons;
          },
          getAdSkippableState: function () {
            return this.__properties.adSkippableState;
          },
          getAdDuration: function () {
            return this.__properties.adDuration;
          },
          startAd: function () {
            this.myFTCall("VPAID_startAd");
          },
          pauseAd: function () {
            this.myFTCall("VPAID_pauseAd");
          },
          resumeAd: function () {
            this.myFTCall("VPAID_resumeAd");
          },
          expandAd: function () {
            this.myFTCall("VPAID_expandAd");
          },
          collapseAd: function () {
            this.myFTCall("VPAID_collapseAd");
          },
          getAdHeight: function () {
            return Math.round(
              this.__properties.adHeight * this.__properties.scale
            );
          },
          getAdWidth: function () {
            return Math.round(
              this.__properties.adWidth * this.__properties.scale
            );
          },
          getAdRemainingTime: function () {
            return null != this.adTimer || this.isPaused
              ? this.__properties.adRemainingTime
              : -2;
          },
          initAd: function (e, t, i, n, a, r) {
            var o,
              s,
              c = this,
              d = a.AdParameters || a || {};
            if (
              ("string" == typeof d && (d = JSON.parse(d)),
              (o = d.hasOwnProperty("json") && d.json))
            ) {
              for (s in ("string" == typeof o && (o = JSON.parse(o)),
              (l = o.placement.id),
              m.setAttribute("id", "ftscript_m" + l),
              m.setAttribute("name", "ftscript_m" + l),
              (o.ftifroverride = !0),
              (o.noBreakout = !0),
              (o.secure = !0),
              p.configMerge(o),
              ["jsurl", "serveDOM", "statBaseUrl"].forEach(function (e) {
                p[e] && (p[e] = p[e].replace(/\[%FT_PROTOCOL%\]/, "https"));
              }),
              !0 === o.jsVPaid.isRemoveMargin &&
                (document.body.style.margin = 0),
              (p.receiveMethod.VPAIDAction = function (e) {
                if (e.method && "function" == typeof c[e.method])
                  return c[e.method](e.payload);
                if (e.set)
                  for (var t in e.set)
                    c.__properties.hasOwnProperty(t) &&
                      (c.__properties[t] = e.set[t]);
                c.dispatchEvent(e.event, e.payload);
              }),
              p.addEventListener("expand", function (e) {
                c.__properties.adExpanded ||
                  (c.interactionStart(),
                  (c.__properties.adExpanded = 1),
                  (c.__properties.adWidth = e.width),
                  (c.__properties.adHeight = e.height),
                  c.setPosition(),
                  c.dispatchEvent("AdExpandedChange"));
              }),
              p.addEventListener("contract", function () {
                c.__properties.adExpanded &&
                  ((c.__properties.adExpanded = 0),
                  (c.__properties.adWidth = o.creative.width),
                  (c.__properties.adHeight = o.creative.height),
                  c.setPosition(),
                  c.dispatchEvent("AdExpandedChange"),
                  c.interactionEnd());
              }),
              p.addEventListener("adonpage", function () {
                c.isLinear || c.dispatchEvent("AdImpression");
              }),
              p.addEventListener("clickthrough", function (e) {
                c.dispatchEvent("AdClickThru", [e.url, void 0, !1]);
              }),
              p.addEventListener("interaction", function () {
                c.dispatchEvent("AdInteraction");
              }),
              (c.adSlot = r.slot),
              (c.slotWidth = e),
              (c.slotHeight = t),
              (c._videoSlot = c.videoSlot = r.videoSlot),
              c.setTracking(c.videoSlot),
              p.setCreativeProperty("initialVideo", o.jsVPaid.videoNumber),
              p.setCreativeProperty("isVPAID", !0),
              d.ft &&
                ((p.secure = p.secure || "https" === d.ft.protocol),
                (d.ft.segmentList = new Function(
                  "return " +
                    d.ft.segmentList.replace(/\[%FT_SEGMENTLIST%\]/, "") +
                    ";"
                )()),
                [
                  "params",
                  "GUID",
                  "confID",
                  "keyword",
                  "segment",
                  "segmentList",
                  "timestamp",
                  "GeoC2",
                  "GeoState",
                  "GeoCity",
                  "ISP",
                  "Speed",
                  "DMA",
                  "Long",
                  "Lat",
                  "Postal",
                  "MobileCarrier",
                ].forEach(function (e) {
                  var t = e[0].toUpperCase() + e.slice(1);
                  p[e] = window["ft" + t + "_" + l] = d.ft[e];
                }),
                (p.imp = p.imp = window["ftImp" + l] = d.ftImp),
                (p.paramsMap = p.getParamsAsMap(p.params)),
                (p.gpp = p.paramsMap.gpp || ""),
                (p.gpp_sid = p.paramsMap.gpp_sid || ""),
                p.imp &&
                  ((p.gdpr = p.imp.gdpr || ""),
                  (p.gdpr_consent = p.imp.gdpr_consent || ""),
                  (p.gdpr_pd = p.imp.gdpr_pd || ""),
                  (p.us_privacy = p.imp.us_privacy || "")),
                (window["ftCustom_" + l] = d.ft.custom),
                (window["ftSection_" + l] = d.ft.section),
                (window["ftRuleMatch_" + l] = d.ft.ruleMatch),
                d) &&
                d.hasOwnProperty("ft") &&
                d.ft.hasOwnProperty("custom") &&
                p.setCreativeProperty("dvMacro", d.ft.custom),
              d.VPAIDProperties))
                c.__properties[s] = d.VPAIDProperties[s];
              for (s in ((p.jsVPaid.upscale =
                "true" === p.jsVPaid.upscale ? "zoom" : p.jsVPaid.upscale),
              d.placementData))
                /^ft/.test(s) && (window[s] = d.placementData[s]);
              (c.__properties.adDuration =
                ((a = c.__properties.adDuration),
                /:/.test(a)
                  ? ((e = a.split(/[:\.]/)),
                    Date.UTC(1970, 0, 1, e[0], e[1], e[2], e[3] || 0) / 1e3)
                  : parseFloat(a))),
                (c.__properties.adRemainingTime = c.__properties.adDuration),
                (c.isLinear = c.__properties.adLinear),
                (p.scriptLocation = document.createElement("div")),
                (p.scriptLocation.style.display = "none"),
                c.adSlot.appendChild(p.scriptLocation),
                (p.w = c.adSlot.ownerDocument.defaultView),
                (document.body.style.margin = 0),
                (p.append = p.jsAppend = 1),
                p.init2(),
                c.setPosition(),
                p.adDiv.addEventListener("mouseenter", function () {
                  c.isLinear || c.stopTimer();
                }),
                p.adDiv.addEventListener("mouseleave", function () {
                  c.startTimer();
                });
            }
          },
          handshakeVersion: function (e) {
            return "2.0";
          },
          subscribe: function (e, t, i) {
            (this.__listeners[t] = this.__listeners[t] || []),
              this.__listeners[t].push({ callback: e, context: i });
          },
          unsubscribe: function (t, e) {
            this.__listeners[e] = (this.__listeners[e] || []).filter(function (
              e
            ) {
              return e !== t;
            });
          },
          dispatchEvent: function (e, i) {
            var n = this;
            "AdStarted" === e &&
              ((n.__properties.adStartedSent = !0), n.isLinear) &&
              n.dispatchEvent("AdImpression"),
              ~[
                "AdLoaded",
                "AdStarted",
                "AdStopped",
                "AdSkipped",
                "AdSizeChange",
                "AdLinearChange",
                "AdDurationChange",
                "AdExpandedChange",
                "AdPaused",
                "AdVolumeChange",
                "AdImpression",
                "AdVideoStart",
                "AdVideoFirstQuartile",
                "AdPlaying",
                "AdVideoMidpoint",
                "AdVideoThirdQuartile",
                "AdVideoComplete",
                "AdClickThru",
                "AdInteraction",
                "AdUserAcceptInvitation",
                "AdUserMinimize",
                "AdUserClose",
                "AdSkippableStateChange",
              ].indexOf(e) &&
                ("AdStarted" === e || "AdPlaying" === e
                  ? ((n.isPaused = !1), n.startTimer())
                  : "AdPaused" === e && ((n.isPaused = !0), n.stopTimer()),
                "[object Array]" !== Object.prototype.toString.call(i) &&
                  (i = [i]),
                (n.__listeners[e] || []).forEach(function (e) {
                  var t = void 0 !== e.context ? e.context : n;
                  e.callback.apply(t, i);
                }));
          },
          setAdVolume: function (e) {
            this.myFTCall("VPAID_setAdVolume", (e = e < 0 ? 0 : 1 < e ? 1 : e));
          },
          stopAd: function () {
            p.nuke(),
              this.dispatchEvent("AdStopped"),
              (p.nuke = function () {});
          },
          skipAd: function () {
            this.__properties.adSkippableState &&
              (p.nuke(), this.dispatchEvent("AdSkipped"));
          },
          interactionStart: function () {
            this.isInteracting ||
              (this.__properties.adLinear ||
                ((this.__properties.adLinear = !0),
                this.dispatchEvent("AdLinearChange")),
              this.videoSlot &&
                ((this.vidNeedsPlay = !this.videoSlot.paused),
                this.videoSlot.pause()),
              this.stopTimer(),
              (this.isInteracting = !0));
          },
          interactionEnd: function () {
            this.isInteracting &&
              ((this.isInteracting = !1),
              this.startTimer(),
              this.isLinear ||
                ((this.__properties.adLinear = !1),
                this.dispatchEvent("AdLinearChange")),
              this.vidNeedsPlay) &&
              this.videoSlot.play();
          },
          resizeAd: function (e, t, i) {
            (this.slotWidth = e),
              (this.slotHeight = t),
              p.jsVPaid.upscale &&
                (this.setPosition(), this.dispatchEvent("AdSizeChange"));
          },
          setPosition: function () {
            var e = this,
              t = p.$(),
              i = "bottom" === p.jsVPaid.verticalAlign ? "bottom" : "top",
              n = "right" === p.jsVPaid.horizontalAlign ? "right" : "left",
              a = "center" === p.jsVPaid.verticalAlign ? "50%" : 0,
              r = "center" === p.jsVPaid.horizontalAlign ? "50%" : 0,
              o =
                "zoom" === p.jsVPaid.upscale
                  ? Math.min(
                      e.slotWidth / e.__properties.adWidth,
                      e.slotHeight / e.__properties.adHeight
                    )
                  : 1,
              s =
                p.cssPrefix +
                "transform: translate(-" +
                r +
                ", -" +
                a +
                ") scale(" +
                o +
                ")",
              c =
                { left: 0, right: 100, center: 50 }[p.jsVPaid.horizontalAlign] +
                "% " +
                { top: 0, bottom: 100, center: 50 }[p.jsVPaid.verticalAlign] +
                "%",
              d = document.createElement("style");
            (d.innerHTML =
              "#" +
              p.adFrame.getAttribute("id") +
              ":-webkit-full-screen { transform: none !important }"),
              t.target.appendChild(d),
              (e.__properties.scale = o),
              (t.style.cssText =
                "position: relative; width: " +
                e.slotWidth +
                "px; height: " +
                e.slotHeight +
                "px;"),
              (p.adFrame.style.cssText =
                "position: absolute; " +
                i +
                ":" +
                a +
                ";" +
                n +
                ":" +
                r +
                ";" +
                p.cssPrefix +
                "transform-origin: " +
                c +
                ";" +
                s),
              ("responsive" !== p.jsVPaid.upscale &&
                "responsive-width" !== p.jsVPaid.upscale) ||
                (p.adFrame.style.width = e.slotWidth + "px"),
              ("responsive" !== p.jsVPaid.upscale &&
                "responsive-height" !== p.jsVPaid.upscale) ||
                (p.adFrame.style.height = e.slotHeight + "px");
          },
          startTimer: function () {
            var t,
              i = this;
            i.isPaused ||
              i.isInteracting ||
              i.adTimer ||
              ((t = Date.now()),
              (i.adTimer = setInterval(function () {
                var e = Date.now();
                (i.__properties.adRemainingTime -= (e - t) / 1e3),
                  (t = e),
                  i.getAdRemainingTime() <= 0 &&
                    (i.stopTimer(),
                    setTimeout(function () {
                      i.stopAd();
                    }, 100));
              }, 250)));
          },
          stopTimer: function () {
            clearInterval(this.adTimer), (this.adTimer = null);
          },
          myFTCall: function (e, t) {
            p.send(p.adWindow, { method: e, msg: t });
          },
          setTracking: function (t) {
            var i = this,
              n = [
                { factor: 0, event: "starts", vpaidEvent: "AdVideoStart" },
                {
                  factor: 0.25,
                  event: "25%",
                  vpaidEvent: "AdVideoFirstQuartile",
                },
                { factor: 0.5, event: "50%", vpaidEvent: "AdVideoMidpoint" },
                {
                  factor: 0.75,
                  event: "75%",
                  vpaidEvent: "AdVideoThirdQuartile",
                },
                { factor: 1, event: "100%", vpaidEvent: "AdVideoComplete" },
              ];
            t.addEventListener("timeupdate", function () {
              var e;
              t.src in i.linearVids &&
                ((e = i.linearVids[t.src]),
                i.__properties.adDuration !== t.duration &&
                  ((i.__properties.adDuration = t.duration),
                  i.dispatchEvent("AdDurationChange")),
                (i.__properties.adCurrentTime = t.currentTime),
                e < 5) &&
                t.currentTime >= t.duration * n[e].factor &&
                (p.trackerManager({
                  type: "video",
                  id: 1,
                  duration: Math.floor(t.duration),
                  event: n[e].event,
                }),
                (i.linearVids[t.src] += 1));
            });
          },
          setupVideoPlayer: function (e) {
            var t = ".",
              i = this,
              n = "";
            if (
              (-1 < e.indexOf("?cb=") &&
                ((n = "?cb=" + e.split("?cb=")[1]), (e = e.split("?cb=")[0])),
              i.videoSlot.canPlayType("video/mp4")
                ? (t += "mp4")
                : i.videoSlot.canPlayType("video/webm") && (t += "web"),
              "." === t)
            )
              throw new Error("browser does not support available video types");
            (i.videoSlot.src = e + ".mp4" + n),
              (i.linearVids[i.videoSlot.src] =
                i.linearVids[i.videoSlot.src] || 0),
              (i.__properties.adLinear = !0),
              i.dispatchEvent("AdLinearChange"),
              i.videoSlot.addEventListener("loadedmetadata", function () {
                i.stopTimer(),
                  (i.getAdRemainingTime = function () {
                    return i.videoSlot.duration - i.videoSlot.currentTime;
                  }),
                  i.__properties.adDuration != i.videoSlot.duration &&
                    ((i.__properties.adDuration = i.videoSlot.duration),
                    i.dispatchEvent("AdDurationChange"));
              }),
              i.videoSlot.play(),
              i.__properties.adExpanded && p.contract(),
              i.subscribe(function () {
                i.videoSlot.play();
              }, "AdPlaying"),
              i.subscribe(function () {
                i.videoSlot.pause();
              }, "AdPaused"),
              i.subscribe(i.stopAd, "AdVideoComplete");
          },
        },
      }),
      (e = n["placement-id"] || n.placementId || !1)) &&
      t &&
      (n["ft-local"] || n.ftlocal || n.ftLocal || !1
        ? (m.setAttribute("id", "ftscript_m" + e),
          (window["ft" + e] = Object.assign({}, window.ftUtils.common)),
          (window["ftParams_" + e] = a),
          window["ft" + e].getBannerConfig(e, t))
        : ((window.ftUtils.html.trackerManager2 =
            window.ftUtils.html.trackerManager),
          (window.ftUtils.html.trackerManager = function (e) {
            var t = this,
              i = this.tracking3rdParty.videoQuartiles[e.event],
              n = {
                starts: "AdVideoStart",
                "25%": "AdVideoFirstQuartile",
                "50%": "AdVideoMidpoint",
                "75%": "AdVideoThirdQuartile",
                "100%": "AdVideoComplete",
              }[e.event];
            if (
              ("AdVideoStart" !== n ||
                t.VPAID.__properties.adStartedSent ||
                t.VPAID.dispatchEvent("AdStarted"),
              1 == e.id &&
                n &&
                (i && t.api.request(t.replaceMacros(i), "proxy"),
                t.VPAID.dispatchEvent(n)),
              !t.VPAID.isLinear || 1 !== e.id)
            )
              return t.trackerManager2(e);
          }),
          (window.ftUtils.html.init2 = window.ftUtils.html.init),
          (window.ftUtils.html.init = function () {}),
          (window.ftUtils.html.contract2 = window.ftUtils.html.contract),
          (window.ftUtils.html.contract = function () {
            this.VPAID.__properties.adExpanded && this.contract2();
          }),
          (p = window["ft" + l] = Object.assign(i, window.ftUtils.common)),
          (window.getVPAIDAd = function () {
            return p.VPAID;
          })));
  })(),
  !window.innovidCreativeDefined)
) {
  class r8 extends HTMLElement {
    static creativeProperties;
    static creativeUrlPath;
    static creativeAssetPath;
    static styles;
    constructor() {
      super(),
        (window.__preventFTTestMode = !0),
        this.attachShadow({ mode: "open" });
    }
    connectedCallback() {}
    disconnectedCallback() {}
    adoptedCallback() {}
    attributeChangedCallback(e, t, i) {}
    updateCreativeUrls(e) {
      let t = this.creativeProperties.creativeAssetPath;
      return (
        e.querySelectorAll("[href]").forEach((e) => {
          /^https:\/\//.test(e.getAttribute("href")) ||
            (/^\.\//.test(e.getAttribute("href"))
              ? e.setAttribute(
                  "href",
                  t + e.getAttribute("href").replace("./", "")
                )
              : e.setAttribute("href", t + e.getAttribute("href")));
        }),
        e.querySelectorAll("[src]").forEach((e) => {
          "" === e.getAttribute("src") ||
            (/^\/\//.test(e.getAttribute("src")) &&
              e.setAttribute("src", "https:" + e.getAttribute("src")),
            /^https:\/\//.test(e.getAttribute("src"))) ||
            e.setAttribute("src", t + e.getAttribute("src"));
        }),
        e
      );
    }
    fetchSource() {
      let t,
        i = this,
        n = i.creativeUrlPath;
      try {
        fetch(n)
          .then((e) => {
            if (e.ok) return e.text();
            throw new Error("Response status: " + e.status);
          })
          .then((e) => {
            (t = document.createRange().createContextualFragment(e)),
              (t = i.updateCreativeUrls(t, n)),
              i.buildDom(t);
          });
      } catch (e) {
        t = e.message;
      }
    }
    buildDom(e) {
      let t = this,
        i,
        n = "",
        a,
        r = [...e.children],
        o = r.length,
        s = t.creativeProperties.creativeAssetPath,
        c = document.createElement("script");
      (c.src =
        "https://cdn.flashtalking.com/frameworks/js/api/2/10/html5API.js"),
        c.addEventListener("load", function () {
          (t.shadowRoot.innerHTML = t.shadowRoot.innerHTML + n),
            (window.myFT.w = t.shadowRoot),
            (t.shadowRoot.document = t.shadowRoot),
            (t.shadowRoot.document.createElement =
              window.document.createElement),
            window.myFT.on("instantads", () => {
              for (var e in window.myFT.instantAds)
                !/^https?:\/\//i.test(myFT.instantAds[e]) &&
                  /[a-z\/]\.(jpg|png|gif)$/i.test(myFT.instantAds[e]) &&
                  (myFT.instantAds[e] = s + myFT.instantAds[e]);
            }),
            window.setTimeout(function () {
              d(-1);
            }, 100);
        });
      for (let e = 0; e < o; e++)
        (i = r[e]),
          (a = i.tagName.toLowerCase()),
          ["script", "meta"].includes(a) || (n += i.outerHTML);
      let d = function (e) {
        e + 1 >= o ||
          ((i = r[e + 1]),
          (a = i.tagName.toLowerCase()),
          ["script"].includes(a) && !/html5API\.js/i.test(i.src)
            ? (i.addEventListener("load", function () {
                d(e + 1);
              }),
              t.shadowRoot.appendChild(i))
            : d(e + 1));
      };
      t.shadowRoot.appendChild(c);
    }
    get source() {
      return this.creativeUrlPath;
    }
    set source(e) {
      (this.creativeUrlPath = e), this.fetchSource();
    }
    get styles() {
      return this.style;
    }
    set styles(e) {
      for (var t in e) this.style[t] = e[t];
    }
  }
  window.customElements.define("innovid-creative", r8),
    (window.innovidCreativeDefined = !0);
}
"function" != typeof Object.assign &&
  Object.defineProperty(Object, "assign", {
    value: function (e, t) {
      if (null == e)
        throw new TypeError("Cannot convert undefined or null to object");
      for (var i = Object(e), n = 1; n < arguments.length; n++) {
        var a = arguments[n];
        if (null != a)
          for (var r in a)
            Object.prototype.hasOwnProperty.call(a, r) && (i[r] = a[r]);
      }
      return i;
    },
    writable: !0,
    configurable: !0,
  });
