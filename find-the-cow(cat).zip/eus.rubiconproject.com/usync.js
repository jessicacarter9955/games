var comments = "User-Sync: generated: 2026-11-20 22:34:47 PST";
var rtb_sync = {
  consent_rate: 0,
  reset_rate: 0,
  ttl: 14,
  sample: 100,
  max_pixels: 16,
  pixel_sets: {
    rtb: {
      sample: 100,
      pixels: {
        1185: {
          ttl: 7,
          img: "https://ad.turn.com/r/cs?pid=6",
          secure: { img: "https://ad.turn.com/r/cs?pid=6" },
          priority: 7,
          partner: "amobee",
        },
        1902: {
          priority: 17,
          ttl: 2,
          img: "https://cms.quantserve.com/pixel/p-e4m3Yko6bFYVc.gif?idmatch=0",
          secure: {
            img: "https://cms.quantserve.com/pixel/p-e4m3Yko6bFYVc.gif?idmatch=0",
          },
          partner: "quantcast",
        },
        1986: {
          priority: 7,
          ttl: 1,
          img: "https://ib.adnxs.com/getuidnb?http%3A%2F%2Fpixel.rubiconproject.com%2Ftap.php%3Fv%3D4894%26nid%3D1986%26put%3D$UID%26expires%3D30",
          secure: {
            img: "https://secure.adnxs.com/getuidnb?https%3A%2F%2Fpixel.rubiconproject.com%2Ftap.php%3Fv%3D4894%26nid%3D1986%26put%3D$UID%26expires%3D30",
          },
          partner: "xandr",
        },
        2046: {
          priority: 13,
          ttl: 7,
          img: "https://token.rubiconproject.com/token?pid=2046&pt=n&a=1",
          secure: {
            img: "https://token.rubiconproject.com/token?pid=2046&pt=n&a=1",
          },
          partner: "conversant",
        },
        2082: {
          priority: 16,
          img: "https://ums.acuityplatform.com/tum?umid=2",
          secure: { img: "https://ums.acuityplatform.com/tum?umid=2" },
          partner: "acuity",
        },
        2132: {
          priority: 12,
          img: "https://um.simpli.fi/rb_match",
          secure: { img: "https://um.simpli.fi/rb_match" },
          partner: "simpli.fi",
        },
        2135: {
          img: "https://d5p.de17a.com/cookies/rubicon",
          secure: { img: "https://d5p.de17a.com/cookies/rubicon" },
          partner: "delta-rtb",
          country: ["se", "dk", "nl", "de", "fi", "no"],
        },
        2149: {
          priority: 6,
          img: "https://dis.criteo.com/dis/usersync.aspx?r=6&p=70&cp=Rubicon&cu=1&url=https%3A%2F%2Fpixel.rubiconproject.com%2Ftap.php%3Fv%3D6434%26nid%3D2149%26put%3D%40%40CRITEO_USERID%40%40",
          secure: {
            img: "https://dis.criteo.com/dis/usersync.aspx?r=6&p=70&cp=Rubicon&cu=1&url=https%3A%2F%2Fpixel.rubiconproject.com%2Ftap.php%3Fv%3D6434%26nid%3D2149%26put%3D%40%40CRITEO_USERID%40%40",
          },
          partner: "criteo",
        },
        2238: {
          priority: 10,
          img: "https://pixel-sync.sitescout.com/dmp/pixelSync?nid=1",
          secure: {
            img: "https://pixel-sync.sitescout.com/dmp/pixelSync?nid=1",
          },
          partner: "basis",
        },
        2249: {
          ttl: 1,
          img: "https://cm.g.doubleclick.net/pixel?google_nid=rubicon&google_cm&google_sc&process_consent=T",
          priority: 1,
          secure: {
            img: "https://cm.g.doubleclick.net/pixel?google_nid=rubicon&google_cm&google_sc&process_consent=T",
          },
          partner: "dv360",
        },
        2307: {
          img: "https://match.adsrvr.org/track/cmf/rubicon",
          priority: 1,
          secure: { img: "https://match.adsrvr.org/track/cmf/rubicon" },
          partner: "thetradedesk",
        },
        2313: {
          img: "https://rbp.mxptint.net/sn.ashx",
          priority: 17,
          secure: { img: "https://rbp.mxptint.net/sn.ashx" },
          partner: "valassis",
          country: ["us", "ca"],
        },
        2494: {
          img: "https://um4.eqads.com/um/rc",
          region: ["na"],
          secure: { img: "https://um4.eqads.com:443/um/rc" },
          partner: "eq-ads",
        },
        2528: {
          img: "https://sync.intentiq.com/profiles_engine/ProfilesEngineServlet?at=20&mi=10&dpi=54",
          secure: {
            img: "https://sync.intentiq.com/profiles_engine/ProfilesEngineServlet?at=20&mi=10&dpi=54",
          },
          partner: "intent-iq",
        },
        2540: {
          priority: 13,
          img: "https://tr.blismedia.com/v1/api/sync/rubicon",
          secure: { img: "https://tr.blismedia.com/v1/api/sync/rubicon" },
          partner: "blis",
        },
        2596: {
          ttl: 7,
          priority: 20,
          img: "https://p.rfihub.com/cm?in=1&pub=64",
          secure: { img: "https://p.rfihub.com/cm?in=1&pub=64" },
          partner: "zeta",
        },
        2650: {
          priority: 18,
          img: "https://match.adsby.bidtheatre.com/rubiconmatch",
          secure: { img: "https://match.adsby.bidtheatre.com/rubiconmatch" },
          partner: "bid-theatre",
        },
        2676: {
          img: "https://c1.adform.net/serving/cookie/match?party=1164",
          secure: {
            img: "https://c1.adform.net/serving/cookie/match?party=1164",
          },
          priority: 6,
          partner: "adform",
        },
        2760: {
          img: "https://x.bidswitch.net/sync?ssp=rubicon",
          secure: { img: "https://x.bidswitch.net/sync?ssp=rubicon" },
          partner: "bidswitch",
        },
        2861: {
          priority: 5,
          img: "https://sync.ipredictive.com/d/sync/cookie/generic?https://pixel.rubiconproject.com/tap.php?v=17149&nid=2861&put=${ADELPHIC_CUID}&expires=30",
          secure: {
            img: "https://sync.ipredictive.com/d/sync/cookie/generic?https://pixel.rubiconproject.com/tap.php?v=17149&nid=2861&put=${ADELPHIC_CUID}&expires=30",
          },
          partner: "adelphic",
        },
        2915: {
          img: "https://sync.smartadserver.com/getuid?gdpr=0&url=https%3A%2F%2Fpixel.rubiconproject.com%2Ftap.php%3Fv%3D32128%26nid%3D2915%26put%3D[sas_uid]",
          secure: {
            img: "https://sync.smartadserver.com/getuid?gdpr=0&url=https%3A%2F%2Fpixel.rubiconproject.com%2Ftap.php%3Fv%3D32128%26nid%3D2915%26put%3D[sas_uid]",
          },
          partner: "liquidm",
        },
        2966: {
          img: "https://rtb.adentifi.com/CookieSyncRubicon",
          secure: { img: "https://rtb.adentifi.com/CookieSyncRubicon" },
          partner: "adheorent",
        },
        2974: {
          ttl: 7,
          img: "https://token.rubiconproject.com/token?pid=2974&pt=n&a=1",
          priority: 1,
          secure: {
            img: "https://token.rubiconproject.com/token?pid=2974&pt=n&a=1",
          },
          partner: "yahoo-openrtb",
        },
        3470: {
          priority: 7,
          img: "https://creativecdn.com/cm-notify?pi=rp",
          secure: { img: "https://creativecdn.com/cm-notify?pi=rp" },
          partner: "rtbhouse",
        },
        3632: {
          img: "https://rcp.c.appier.net/rbcm",
          secure: { img: "https://rcp.c.appier.net/rbcm" },
          partner: "appier",
        },
        3636: {
          img: "https://cm.smadex.com/sync?sm_p=rbc&sm_r=rbc",
          secure: { img: "https://cm.smadex.com/sync?sm_p=rbc&sm_r=rbc" },
          partner: "smadex",
        },
        3664: {
          priority: 6,
          img: "https://bttrack.com/pixel/cookiesync?source=c91bfcce-bb43-46f7-b14e-567c0a4332b3",
          secure: {
            img: "https://bttrack.com/pixel/cookiesync?source=c91bfcce-bb43-46f7-b14e-567c0a4332b3",
          },
          partner: "bidtellect",
        },
        3668: {
          img: "https://tg.socdm.com/rtb/sync?proto=rubicon",
          secure: { img: "https://tg.socdm.com/rtb/sync?proto=rubicon" },
          partner: "supership",
        },
        3778: {
          img: "https://sync-tm.everesttech.net/upi/pid/btu4jd3a?redir=https%3A%2F%2Fpixel.rubiconproject.com%2Ftap.php%3Fv%3D191940%26nid%3D3778%26put%3D%24%7BUSER_ID%7D",
          secure: {
            img: "https://sync-tm.everesttech.net/upi/pid/btu4jd3a?redir=https%3A%2F%2Fpixel.rubiconproject.com%2Ftap.php%3Fv%3D191940%26nid%3D3778%26put%3D%24%7BUSER_ID%7D",
          },
          partner: "adobe",
          priority: 11,
        },
        3822: {
          priority: 15,
          img: "https://dsp-cookie.adfarm1.adition.com/?ssp=7",
          secure: { img: "https://dsp-cookie.adfarm1.adition.com/?ssp=7" },
          partner: "active-agent",
        },
        3856: {
          priority: 15,
          img: "https://a.tribalfusion.com/i.match?p=b10&u={rubicon_user_token}&redirect=https%3A//pixel.rubiconproject.com/tap.php%3Fv%3D111756%26nid%3D3856%26put%3D%24TF_USER_ID_ENC%24%26expires%3D180",
          secure: {
            img: "https://a.tribalfusion.com/i.match?p=b10&u={rubicon_user_token}&redirect=https%3A//pixel.rubiconproject.com/tap.php%3Fv%3D111756%26nid%3D3856%26put%3D%24TF_USER_ID_ENC%24%26expires%3D180",
          },
          partner: "vdx.tv",
        },
        3858: {
          priority: 6,
          img: "https://sync.srv.stackadapt.com/sync?nid=14",
          secure: { img: "https://sync.srv.stackadapt.com/sync?nid=14" },
          partner: "stackadapt",
        },
        3956: {
          img: "https://sync.adotmob.com/cookie/rubicon?r=https%3A%2F%2Fpixel.rubiconproject.com%2Ftap.php%3Fv%3D123034%26nid%3D3956%26put%3D%7Buser_token%7D",
          secure: {
            img: "https://sync.adotmob.com/cookie/rubicon?r=https%3A%2F%2Fpixel.rubiconproject.com%2Ftap.php%3Fv%3D123034%26nid%3D3956%26put%3D%7Buser_token%7D",
          },
          partner: "AdotMob",
        },
        3992: {
          priority: 16,
          img: "https://b1sync.outbrain.com/usersync/rubicon",
          secure: { img: "https://b1sync.outbrain.com/usersync/rubicon" },
          partner: "zemanta",
        },
        4016: {
          priority: 15,
          img: "https://cr-p16.ladsp.com/cookiesender/16",
          secure: { img: "https://cr-p16.ladsp.com/cookiesender/16" },
          partner: "so-netmedia",
          country: ["jp"],
        },
        4032: {
          priority: 12,
          img: "https://cm.adgrx.com/bridge?AG_SETCOOKIE&AG_PID=rubicon",
          secure: {
            img: "https://cm.adgrx.com/bridge?AG_SETCOOKIE&AG_PID=rubicon",
          },
          partner: "samsung",
        },
        4086: {
          img: "https://dsp.360yield.com/dsp_match/275?ssp=52&r=https%3A%2F%2Fpixel.rubiconproject.com%2Ftap.php%3Fv%3D165466%26nid%3D4086%26put%3D%7BDSP_USER_ID%7D",
          secure: {
            img: "https://dsp.360yield.com/dsp_match/275?ssp=52&r=https%3A%2F%2Fpixel.rubiconproject.com%2Ftap.php%3Fv%3D165466%26nid%3D4086%26put%3D%7BDSP_USER_ID%7D",
          },
          partner: "hawk",
        },
        4114: {
          priority: 4,
          img: "https://match.prod.bidr.io/cookie-sync/rp?bee_sync_partners=rp",
          secure: {
            img: "https://match.prod.bidr.io/cookie-sync/rp?bee_sync_partners=rp",
          },
          partner: "beeswax",
        },
        4584: {
          img: "https://onetag-sys.com/match/?int_id=4",
          secure: { img: "https://onetag-sys.com/match/?int_id=4" },
          partner: "onetag",
          country: ["it", "de", "fr", "se", "at", "uk", "es", "gr", "ro", "us"],
        },
        4804: {
          priority: 18,
          img: "https://ssbsync.smartadserver.com/api/sync?callerId=87",
          secure: {
            img: "https://ssbsync.smartadserver.com/api/sync?callerId=87",
          },
          partner: "dynadmic",
        },
        4840: {
          img: "https://pixelfnt-us.dsp-api.moloco.com/v1/cm/magnitepm?bidfnt",
          secure: {
            img: "https://pixelfnt-us.dsp-api.moloco.com/v1/cm/magnitepm?bidfnt",
          },
          partner: "moloco",
        },
        4858: {
          priority: 1,
          img: "https://token.rubiconproject.com/token?pid=36584",
          secure: { img: "https://token.rubiconproject.com/token?pid=36584" },
          partner: "linkedin",
        },
        4906: {
          img: "https://sync-dsp.ad-m.asia/dsp/api/sync/send?s=rubicon",
          secure: {
            img: "https://sync-dsp.ad-m.asia/dsp/api/sync/send?s=rubicon",
          },
          partner: "craid",
          country: ["jp"],
        },
        5120: {
          priority: 15,
          img: "https://bh.contextweb.com/bh/rtset?pid=560687&ev=1&rurl=https%3A%2F%2Fpixel.rubiconproject.com%2Ftap.php%3Fv%3D390200%26nid%3D5120%26put%3D%25%25VGUID%25%25",
          secure: {
            img: "https://bh.contextweb.com/bh/rtset?pid=560687&ev=1&rurl=https%3A%2F%2Fpixel.rubiconproject.com%2Ftap.php%3Fv%3D390200%26nid%3D5120%26put%3D%25%25VGUID%25%25",
          },
          partner: "pulsepoint",
        },
        5446: {
          img: "https://dmp.brand-display.com/cm/api/rubicon",
          secure: { img: "https://dmp.brand-display.com/cm/api/rubicon" },
          partner: "knorex",
        },
        5498: {
          img: "https://services.digitaleast.mobi/cookie-sync/cookie/v1/exchange-to-de-match/rubicon.gif",
          secure: {
            img: "https://services.digitaleast.mobi/cookie-sync/cookie/v1/exchange-to-de-match/rubicon.gif",
          },
          partner: "digital-east",
        },
        5500: {
          priority: 19,
          img: "https://ds.uncn.jp/rp/0/sync",
          secure: { img: "https://ds.uncn.jp/rp/0/sync" },
          country: ["jp"],
          partner: "unicorn",
        },
        5504: {
          img: "https://pixel.rubiconproject.com/token?pid=5504&pt=n",
          secure: {
            img: "https://pixel.rubiconproject.com/token?pid=5504&pt=n",
          },
          partner: "cognitiv",
        },
        5528: {
          priority: 10,
          img: "https://match.deepintent.com/usersync/143",
          secure: { img: "https://match.deepintent.com/usersync/143" },
          partner: "deepintent",
        },
        5570: {
          img: "https://sid.storygize.net/ccm/729e4e94-63c3-438d-8ce4-184eb34e703f",
          secure: {
            img: "https://sid.storygize.net/ccm/729e4e94-63c3-438d-8ce4-184eb34e703f",
          },
          partner: "storygize",
        },
        5578: {
          img: "https://s.company-target.com/s/rp",
          secure: { img: "https://s.company-target.com/s/rp" },
          partner: "demandbase",
        },
        5610: {
          img: "https://evt.undertone.com/userPixel/syncr?partnerid=51&r=https%3A%2F%2Fpixel.rubiconproject.com%2Ftap.php%3Fv%3D1317278%26nid%3D5610%26put%3D%24UIDENC",
          secure: {
            img: "https://evt.undertone.com/userPixel/syncr?partnerid=51&r=https%3A%2F%2Fpixel.rubiconproject.com%2Ftap.php%3Fv%3D1317278%26nid%3D5610%26put%3D%24UIDENC",
          },
          partner: "undertone",
        },
        5648: {
          img: "https://t.adx.opera.com/pub/sync?pubid=pub12174542627584",
          secure: {
            img: "https://t.adx.opera.com/pub/sync?pubid=pub12174542627584",
          },
          partner: "opera",
        },
        5676: {
          img: "https://pixelfnt-us.dsp-api.moloco.com/v1/cm/magnitepm",
          secure: {
            img: "https://pixelfnt-us.dsp-api.moloco.com/v1/cm/magnitepm",
          },
          partner: "moloco-web-only",
        },
        5678: {
          img: "https://s.ad.smaato.net/c/?adExInit=mw&$GDPR_PARAMS&redir=https%3A%2F%2Fpixel.rubiconproject.com%2Ftap.php%3Fv%3D1470350%26nid%3D5678%26put%3D%24UID",
          secure: {
            img: "https://s.ad.smaato.net/c/?adExInit=mw&$GDPR_PARAMS&redir=https%3A%2F%2Fpixel.rubiconproject.com%2Ftap.php%3Fv%3D1470350%26nid%3D5678%26put%3D%24UID",
          },
          partner: "smaato",
        },
        5688: {
          priority: 10,
          img: "https://pixel.rubiconproject.com/token?pid=5688&pt=n",
          secure: {
            img: "https://pixel.rubiconproject.com/token?pid=5688&pt=n",
          },
          partner: "pinterest",
          country: ["us"],
        },
        5692: {
          img: "https://bypass.ad-stir.com/push_sync?xid=magnite",
          secure: { img: "https://bypass.ad-stir.com/push_sync?xid=magnite" },
          country: ["jp"],
          partner: "wise-ads",
        },
        idl: {
          priority: 1,
          ttl: 1,
          img: "https://id.rlcdn.com/709414.gif",
          secure: { img: "https://id.rlcdn.com/709414.gif" },
          partner: "liveramp",
        },
        "2179-na": {
          priority: 1,
          ttl: 6,
          img: "https://s.amazon-adsystem.com/dcm?pid=94c5f526-dc47-4863-976e-c5fbd9bde1f8",
          secure: {
            img: "https://s.amazon-adsystem.com/dcm?pid=94c5f526-dc47-4863-976e-c5fbd9bde1f8",
          },
          partner: "amazon-na-sync",
        },
        "2179-eu": {
          priority: 1,
          ttl: 6,
          img: "https://aax-eu.amazon-adsystem.com/s/dcm?pid=fd2c2d83-30e4-42d2-9dea-d40519bcd8e7",
          secure: {
            img: "https://aax-eu.amazon-adsystem.com/s/dcm?pid=fd2c2d83-30e4-42d2-9dea-d40519bcd8e7",
          },
          partner: "amazon-eu-sync",
        },
        "2249-DV360-Hosted": {
          priority: 1,
          ttl: 7,
          img: "https://token.rubiconproject.com/token?pid=2249&pt=n",
          secure: {
            img: "https://token.rubiconproject.com/token?pid=2249&pt=n",
          },
          partner: "DV360-Google",
        },
        w55c: {
          nid: 1523,
          priority: 20,
          ttl: 7,
          img: "https://i.w55c.net/ping_match.gif?ei=RUBICON&rurl=https%3A%2F%2Fpixel.rubiconproject.com%2Ftap.php%3Fv%3D4210%26nid%3D1523%26put%3D_wfivefivec_%26expires%3D30",
          secure: {
            img: "https://i.w55c.net/ping_match.gif?ei=RUBICON&rurl=https%3A%2F%2Fpixel.rubiconproject.com%2Ftap.php%3Fv%3D4210%26nid%3D1523%26put%3D_wfivefivec_%26expires%3D30",
          },
          partner: "roku-oneview",
        },
        "1523ext": {
          iframe: "https://cti.w55c.net/ct/cms-2c-rubicon.html",
          secure: { iframe: "https://cti.w55c.net/ct/cms-2c-rubicon.html" },
          partner: "roku-oneview",
        },
        "mediavine-seller": {
          img: "https://pixel.rubiconproject.com/exchange/sync.php?p=17404",
          priority: 10,
          secure: {
            img: "https://pixel.rubiconproject.com/exchange/sync.php?p=17404",
          },
          partner: "mediavine-seller",
        },
        "vrtcal-seller": {
          img: "https://pixel.rubiconproject.com/exchange/sync.php?p=vrtcal",
          secure: {
            img: "https://pixel.rubiconproject.com/exchange/sync.php?p=vrtcal",
          },
          partner: "vrtcal-seller",
          country: ["us"],
        },
        "undertone-seller": {
          img: "https://pixel.rubiconproject.com/exchange/sync.php?p=12776",
          priority: 15,
          secure: {
            img: "https://pixel.rubiconproject.com/exchange/sync.php?p=12776",
          },
          partner: "undertone-seller",
        },
        goog: {
          priority: 1,
          img: "https://token.rubiconproject.com/token?pid=25470",
          secure: { img: "https://token.rubiconproject.com/token?pid=25470" },
          partner: "goog",
        },
        a9eu: {
          priority: 1,
          img: "https://pixel.rubiconproject.com/exchange/sync.php?p=a9eu",
          secure: {
            img: "https://pixel.rubiconproject.com/exchange/sync.php?p=a9eu",
          },
          partner: "a9eu",
          country: [
            "ie",
            "gb",
            "uk",
            "fr",
            "de",
            "es",
            "pt",
            "it",
            "no",
            "se",
            "nl",
            "be",
            "fi",
            "ch",
          ],
        },
        a9us: {
          priority: 1,
          img: "https://pixel.rubiconproject.com/exchange/sync.php?p=a9us",
          secure: {
            img: "https://pixel.rubiconproject.com/exchange/sync.php?p=a9us",
          },
          partner: "a9us",
        },
        adsyoulike: {
          priority: 10,
          img: "https://pixel.rubiconproject.com/exchange/sync.php?p=adyoulike",
          secure: {
            img: "https://pixel.rubiconproject.com/exchange/sync.php?p=adyoulike",
          },
          partner: "adsyoulike-publisher",
        },
        pb_appneuxs: {
          priority: 5,
          img: "https://pixel.rubiconproject.com/exchange/sync.php?p=pbs-apn",
          secure: {
            img: "https://pixel.rubiconproject.com/exchange/sync.php?p=pbs-apn",
          },
          partner: "pb_appnexus-publisher",
        },
        primis: {
          priority: 5,
          img: "https://pixel.rubiconproject.com/exchange/sync.php?p=primis",
          secure: {
            img: "https://pixel.rubiconproject.com/exchange/sync.php?p=primis",
          },
          partner: "primis-publisher",
        },
        "share-through": {
          priority: 5,
          img: "https://pixel.rubiconproject.com/exchange/sync.php?p=18694",
          secure: {
            img: "https://pixel.rubiconproject.com/exchange/sync.php?p=18694",
          },
          partner: "share-through-publisher",
        },
        yieldmo: {
          priority: 15,
          img: "https://pixel.rubiconproject.com/exchange/sync.php?p=yieldmo",
          secure: {
            img: "https://pixel.rubiconproject.com/exchange/sync.php?p=yieldmo",
          },
          partner: "yieldmo-publisher",
        },
        "33across": {
          priority: 10,
          img: "https://pixel.rubiconproject.com/exchange/sync.php?p=33across",
          secure: {
            img: "https://pixel.rubiconproject.com/exchange/sync.php?p=33across",
          },
          partner: "33across-publisher",
        },
        pb_triple13: {
          priority: 10,
          img: "https://pixel.rubiconproject.com/exchange/sync.php?p=pbs-triple13",
          secure: {
            img: "https://pixel.rubiconproject.com/exchange/sync.php?p=pbs-triple13",
          },
          partner: "pb_triple13-publisher",
        },
        seedtag: {
          priority: 6,
          img: "https://pixel.rubiconproject.com/exchange/sync.php?p=seedtag",
          secure: {
            img: "https://pixel.rubiconproject.com/exchange/sync.php?p=seedtag",
          },
          partner: "seedtag-publisher",
        },
        unruly: {
          priority: 10,
          img: "https://pixel.rubiconproject.com/exchange/sync.php?p=unruly",
          secure: {
            img: "https://pixel.rubiconproject.com/exchange/sync.php?p=unruly",
          },
          partner: "unruly-publisher",
        },
        outbrain: {
          priority: 10,
          img: "https://pixel.rubiconproject.com/exchange/sync.php?p=outbrain",
          secure: {
            img: "https://pixel.rubiconproject.com/exchange/sync.php?p=outbrain",
          },
          partner: "outbrain-publisher",
        },
        pb_adaptmx: {
          priority: 5,
          img: "https://pixel.rubiconproject.com/exchange/sync.php?p=pbs-adaptmx",
          secure: {
            img: "https://pixel.rubiconproject.com/exchange/sync.php?p=pbs-adaptmx",
          },
          partner: "pb_adaptmx-publisher",
        },
        epsilon: {
          priority: 17,
          img: "https://pixel.rubiconproject.com/exchange/sync.php?p=epsilon",
          secure: {
            img: "https://pixel.rubiconproject.com/exchange/sync.php?p=epsilon",
          },
          partner: "epsilon-publisher",
        },
        loopme_global: {
          priority: 17,
          img: "https://pixel.rubiconproject.com/exchange/sync.php?p=loopme",
          secure: {
            img: "https://pixel.rubiconproject.com/exchange/sync.php?p=loopme",
          },
          partner: "loopme_global-publisher",
        },
        rise_engage: {
          priority: 10,
          img: "https://pixel.rubiconproject.com/exchange/sync.php?p=rise_engage",
          secure: {
            img: "https://pixel.rubiconproject.com/exchange/sync.php?p=rise_engage",
          },
          partner: "rise_engage-publisher",
        },
        minute_media: {
          priority: 10,
          img: "https://pixel.rubiconproject.com/exchange/sync.php?p=minute_media",
          secure: {
            img: "https://pixel.rubiconproject.com/exchange/sync.php?p=minute_media",
          },
          partner: "minute_media-publisher",
        },
        kargo: {
          priority: 15,
          img: "https://pixel.rubiconproject.com/exchange/sync.php?p=11864",
          secure: {
            img: "https://pixel.rubiconproject.com/exchange/sync.php?p=11864",
          },
          partner: "kargo-publisher",
        },
        smartadserver: {
          priority: 15,
          img: "https://pixel.rubiconproject.com/exchange/sync.php?p=smartadserver",
          secure: {
            img: "https://pixel.rubiconproject.com/exchange/sync.php?p=smartadserver",
          },
          partner: "smartadserver-publisher",
        },
        consumable_inc: {
          priority: 17,
          img: "https://pixel.rubiconproject.com/exchange/sync.php?p=24856",
          secure: {
            img: "https://pixel.rubiconproject.com/exchange/sync.php?p=24856",
          },
          partner: "consumable_inc-publisher",
        },
        spot_im: {
          priority: 15,
          img: "https://pixel.rubiconproject.com/exchange/sync.php?p=17184",
          secure: {
            img: "https://pixel.rubiconproject.com/exchange/sync.php?p=17184",
          },
          partner: "spot_im-publisher",
        },
        smaato: {
          priority: 20,
          img: "https://pixel.rubiconproject.com/exchange/sync.php?p=smaato",
          secure: {
            img: "https://pixel.rubiconproject.com/exchange/sync.php?p=smaato",
          },
          partner: "smaato-publisher",
        },
        pb_forbes: {
          priority: 15,
          img: "https://pixel.rubiconproject.com/exchange/sync.php?p=pbs-medianet",
          secure: {
            img: "https://pixel.rubiconproject.com/exchange/sync.php?p=pbs-medianet",
          },
          partner: "pb_forbes-publisher",
        },
        connatix: {
          priority: 5,
          img: "https://pixel.rubiconproject.com/exchange/sync.php?p=19564",
          secure: {
            img: "https://pixel.rubiconproject.com/exchange/sync.php?p=19564",
          },
          partner: "connatix-publisher",
        },
        "ex.co": {
          sample: 50,
          priority: 17,
          img: "https://pixel.rubiconproject.com/exchange/sync.php?p=17136_2",
          secure: {
            img: "https://pixel.rubiconproject.com/exchange/sync.php?p=17136_2",
          },
          partner: "ex.co-publisher",
        },
        sovrn: {
          priority: 5,
          img: "https://pixel.rubiconproject.com/exchange/sync.php?p=sovrn",
          secure: {
            img: "https://pixel.rubiconproject.com/exchange/sync.php?p=sovrn",
          },
          partner: "sovrn-publisher",
        },
        pb_bricks: {
          sample: 0,
          img: "https://pixel.rubiconproject.com/exchange/sync.php?p=pbs-bricks",
          secure: {
            img: "https://pixel.rubiconproject.com/exchange/sync.php?p=pbs-bricks",
          },
          partner: "pb_bricks-publisher",
        },
        smilewanted: {
          img: "https://pixel.rubiconproject.com/exchange/sync.php?p=pbs-smilewanted",
          secure: {
            img: "https://pixel.rubiconproject.com/exchange/sync.php?p=pbs-smilewanted",
          },
          partner: "smilewanted-publisher",
        },
        "pulsepoint-seller": {
          img: "https://pixel.rubiconproject.com/exchange/sync.php?p=pulsepoint",
          secure: {
            img: "https://pixel.rubiconproject.com/exchange/sync.php?p=pulsepoint",
          },
          partner: "pulsepoint-publisher",
        },
        "gumgum-seller": {
          img: "https://pixel.rubiconproject.com/exchange/sync.php?p=gumgum",
          secure: {
            img: "https://pixel.rubiconproject.com/exchange/sync.php?p=gumgum",
          },
          partner: "gumgum-publisher",
        },
        vidazoo: {
          img: "https://pixel.rubiconproject.com/exchange/sync.php?p=vidazoo",
          secure: {
            img: "https://pixel.rubiconproject.com/exchange/sync.php?p=vidazoo",
          },
          partner: "vidazoo-publisher",
        },
        "convert-media": {
          img: "https://pixel.rubiconproject.com/exchange/sync.php?p=15414",
          secure: {
            img: "https://pixel.rubiconproject.com/exchange/sync.php?p=15414",
          },
          partner: "convert-media-publisher",
        },
        onfocus: {
          img: "https://pixel.rubiconproject.com/exchange/sync.php?p=onfocus",
          secure: {
            img: "https://pixel.rubiconproject.com/exchange/sync.php?p=onfocus",
          },
          partner: "onfocus-publisher",
        },
        "pbs-ozone": {
          img: "https://pixel.rubiconproject.com/exchange/sync.php?p=pbs-ozone",
          secure: {
            img: "https://pixel.rubiconproject.com/exchange/sync.php?p=pbs-ozone",
          },
          partner: "pbs-ozone-publisher",
        },
        ogury: {
          img: "https://pixel.rubiconproject.com/exchange/sync.php?p=ogury",
          secure: {
            img: "https://pixel.rubiconproject.com/exchange/sync.php?p=ogury",
          },
          partner: "ogury-publisher",
        },
        medianet: {
          img: "https://pixel.rubiconproject.com/exchange/sync.php?p=medianet",
          secure: {
            img: "https://pixel.rubiconproject.com/exchange/sync.php?p=medianet",
          },
          partner: "medianet-publisher",
        },
        inmobi: {
          img: "https://pixel.rubiconproject.com/exchange/sync.php?p=inmobi",
          secure: {
            img: "https://pixel.rubiconproject.com/exchange/sync.php?p=inmobi",
          },
          partner: "inmobi-publisher",
        },
        "pbs-yahoo-exchange": {
          priority: 5,
          img: "https://pixel.rubiconproject.com/exchange/sync.php?p=pbs-yahoo-exchange",
          secure: {
            img: "https://pixel.rubiconproject.com/exchange/sync.php?p=pbs-yahoo-exchange",
          },
          partner: "pbs-yahoo-exchange-publisher",
        },
        "next-millennium": {
          priority: 10,
          img: "https://pixel.rubiconproject.com/exchange/sync.php?p=17888",
          secure: {
            img: "https://pixel.rubiconproject.com/exchange/sync.php?p=17888",
          },
          partner: "next-millennium-publisher",
        },
        onomagic: {
          img: "https://pixel.rubiconproject.com/exchange/sync.php?p=onomagic",
          secure: {
            img: "https://pixel.rubiconproject.com/exchange/sync.php?p=onomagic",
          },
          partner: "onomagic-publisher",
        },
        "pbs-optidigital": {
          img: "https://pixel.rubiconproject.com/exchange/sync.php?p=pbs-optidigital",
          secure: {
            img: "https://pixel.rubiconproject.com/exchange/sync.php?p=pbs-optidigital",
          },
          partner: "pbs-optidigital-publisher",
        },
        smarthub: {
          sample: 5,
          img: "https://pixel.rubiconproject.com/exchange/sync.php?p=smarthub",
          secure: {
            img: "https://pixel.rubiconproject.com/exchange/sync.php?p=smarthub",
          },
          partner: "smarthub-publisher",
        },
        onetag: {
          img: "https://pixel.rubiconproject.com/exchange/sync.php?p=onetag",
          secure: {
            img: "https://pixel.rubiconproject.com/exchange/sync.php?p=onetag",
          },
          partner: "onetag-publisher",
        },
        publicidad: {
          img: "https://pixel.rubiconproject.com/exchange/sync.php?p=publicidad",
          secure: {
            img: "https://pixel.rubiconproject.com/exchange/sync.php?p=publicidad",
          },
          partner: "publicidad-publisher",
        },
        "pbs-hashtag-labs": {
          img: "https://pixel.rubiconproject.com/exchange/sync.php?p=pbs-hashtag-labs",
          secure: {
            img: "https://pixel.rubiconproject.com/exchange/sync.php?p=pbs-hashtag-labs",
          },
          partner: "pbs-hashtag-labs-publisher",
        },
        "pbs-rich_audience": {
          img: "https://pixel.rubiconproject.com/exchange/sync.php?p=publicidad",
          secure: {
            img: "https://pixel.rubiconproject.com/exchange/sync.php?p=publicidad",
          },
          partner: "rich_audience-pub",
        },
        missena: {
          img: "https://pixel.rubiconproject.com/exchange/sync.php?p=missena",
          secure: {
            img: "https://pixel.rubiconproject.com/exchange/sync.php?p=missena",
          },
          partner: "missena-publisher",
        },
        "GetMedia-seller": {
          img: "https://pixel.rubiconproject.com/exchange/sync.php?p=getmedia",
          secure: {
            img: "https://pixel.rubiconproject.com/exchange/sync.php?p=getmedia",
          },
          partner: "GetMedia-seller",
        },
        tappcelerator: {
          img: "https://pixel.rubiconproject.com/exchange/sync.php?p=tappcelerator",
          secure: {
            img: "https://pixel.rubiconproject.com/exchange/sync.php?p=tappcelerator",
          },
          partner: "tappcel-pub",
        },
      },
    },
    rtb_ext: { sample: 100, pixels: {} },
    aud: {
      sample: 25,
      pixels: {
        liveintent: {
          priority: 1,
          img: "https://token.rubiconproject.com/token?pid=49096",
          secure: { img: "https://token.rubiconproject.com/token?pid=49096" },
          partner: "liveintent-publisher",
          country: ["us"],
        },
        aam: {
          pingdom_id: "661320",
          ttl: 14,
          img: "https://token.rubiconproject.com/token?pid=6404",
          secure: { img: "https://token.rubiconproject.com/token?pid=6404" },
          partner: "adobe",
        },
        neu: {
          pingdom_id: "1411157",
          ttl: 7,
          sample: 0,
          img: "https://adadvisor.net/adscores/g.pixel?sid=9212270498",
          secure: {
            img: "https://adadvisor.net/adscores/g.pixel?sid=9212270498",
          },
          partner: "neustar",
          country: ["us"],
        },
        "tapad-crossdevice": {
          ttl: 7,
          img: "https://token.rubiconproject.com/token?pid=37556&a=1",
          secure: {
            img: "https://token.rubiconproject.com/token?pid=37556&a=1",
          },
          sample: 100,
          priority: 5,
          partner: "tapad-crossdevice",
        },
        digitrust: {
          ttl: 14,
          img: "https://rubicon.digitru.st/digitrust-sync",
          secure: { img: "https://rubicon.digitru.st/digitrust-sync" },
          sample: 0,
          partner: "digitrust",
        },
        "ownerIQ-dmp": {
          sample: 0,
          ttl: 14,
          img: "https://px.owneriq.net/eucm/p/rc?redir=http%3A%2F%2Ftoken.rubiconproject.com%2Ftoken%3Fpid%3D3353%26puid%3D(OIQ_UUID)",
          secure: {
            img: "https://px.owneriq.net/eucm/p/rc?redir=https%3A%2F%2Ftoken.rubiconproject.com%2Ftoken%3Fpid%3D3353%26puid%3D(OIQ_UUID)",
          },
          partner: "ownerIQ-dmp",
        },
        a9s: {
          ttl: 7,
          sample: 100,
          region: ["us"],
          iframe: "https://s.amazon-adsystem.com/x/1c2fd14bf310b6aff649",
          secure: {
            iframe: "https://s.amazon-adsystem.com/x/1c2fd14bf310b6aff649",
          },
          partner: "amazon-pub-us-sync",
        },
        "a9s-eu": {
          ttl: 7,
          sample: 100,
          region: ["eu"],
          iframe: "https://aax-eu.amazon-adsystem.com/s/x/1c2fd14bf310b6aff649",
          secure: {
            iframe:
              "https://aax-eu.amazon-adsystem.com/s/x/1c2fd14bf310b6aff649",
          },
          partner: "amazon-eu-sync",
        },
        Merkle: {
          sample: 0,
          ttl: 14,
          img: "https://token.rubiconproject.com/token?pid=28752",
          secure: { img: "https://token.rubiconproject.com/token?pid=28752" },
          partner: "Merkle",
        },
        sirdata: {
          img: "https://pixel.rubiconproject.com/token?pid=34458",
          secure: { img: "https://pixel.rubiconproject.com/token?pid=34458" },
          sample: 0,
          partner: "sirdata",
        },
        sem: {
          ttl: 7,
          sample: 50,
          img: "https://token.rubiconproject.com/token?pid=10362",
          secure: { img: "https://token.rubiconproject.com/token?pid=10362" },
          partner: "semasio",
          country: [
            "us",
            "ca",
            "mx",
            "au",
            "hk",
            "in",
            "nz",
            "sg",
            "at",
            "be",
            "dk",
            "fi",
            "fr",
            "de",
            "it",
            "nl",
            "es",
            "se",
            "ch",
          ],
        },
        "spr-global": {
          ttl: 1,
          priority: 1,
          img: "https://pixel.rubiconproject.com/token?pid=52948",
          secure: { img: "https://pixel.rubiconproject.com/token?pid=52948" },
          partner: "springserve-global",
        },
        transunion: {
          img: "https://token.rubiconproject.com/token?pid=31224",
          secure: { img: "https://token.rubiconproject.com/token?pid=31224" },
          priority: 20,
          partner: "transunion",
        },
        por: {
          ttl: 7,
          img: "https://ksk.t.zucks.net/mc/cs",
          secure: { img: "https://ksk.t.zucks.net/mc/cs" },
          partner: "porto",
          country: ["jp"],
        },
        sca: {
          ttl: 7,
          img: "https://tg.socdm.com/aux/idsync?proto=magnite_ctv",
          secure: { img: "https://tg.socdm.com/aux/idsync?proto=magnite_ctv" },
          partner: "scaleout",
          country: ["jp"],
        },
        adi: {
          priority: 20,
          img: "https://hrbh3.publishers.tremorhub.com/pubsync?redir=https%3A%2F%2Fcs.adingo.jp%2Fsync%2F%3Ffrom%3Dmagnite%26id%3D%5Btvid%5D",
          secure: {
            img: "https://hrbh3.publishers.tremorhub.com/pubsync?redir=https%3A%2F%2Fcs.adingo.jp%2Fsync%2F%3Ffrom%3Dmagnite%26id%3D%5Btvid%5D",
          },
          partner: "TBS Japan",
          country: ["jp"],
        },
        sup: {
          priority: 20,
          img: "https://p57w7.publishers.tremorhub.com/pubsync?redir=https%3A%2F%2Ftg.socdm.com%2Faux%2Fidsync%3Fproto%3Dmagnite_ctv_dsp%26ssp_uid%3D%5Btvid%5D",
          secure: {
            img: "https://p57w7.publishers.tremorhub.com/pubsync?redir=https%3A%2F%2Ftg.socdm.com%2Faux%2Fidsync%3Fproto%3Dmagnite_ctv_dsp%26ssp_uid%3D%5Btvid%5D",
          },
          partner: "Supership Japan",
          country: ["jp"],
        },
        log: {
          priority: 20,
          img: "https://cr-p43.ladsp.com/cookiesender/43",
          secure: { img: "https://cr-p43.ladsp.com/cookiesender/43" },
          partner: "LogicAd DSP",
          country: ["jp"],
        },
      },
    },
    nets: { sample: 100, pixels: {} },
    pubs: { sample: 0, pixels: {} },
  },
  notify: {
    rubicon: { sample: 0, img: "https://tap.rubiconproject.com/stats/rtbsync" },
  },
  priority: 20,
  resync: 0,
  max_ie_partners: 1000,
  lastModified: "2018-05-10 09:19:59",
  dateRetrieved: "2026-11-20 22:34:47 PST",
};

function isSellerSync() {
  return !!retrieveQueryParams().p;
}
var skipBuyerSync, consentParams;
function shouldSkipBuyerSync() {
  if (!skipBuyerSync && !1 !== skipBuyerSync) {
    if (!(Math.floor(100 * Math.random()) < Number(rtb_sync.sample)))
      return log("skipping buyer sync due to sampling"), (skipBuyerSync = !0);
    if (alreadyRanOnPage())
      return log("skipping buyer sync cause already ran"), (skipBuyerSync = !0);
    skipBuyerSync = !1;
  }
  return skipBuyerSync;
}
var localStorageAccess,
  sessionStorageAccess,
  expiration_info,
  logPrefix,
  debug,
  regionCountries = {
    af: [
      "ao",
      "bi",
      "bj",
      "bf",
      "bw",
      "cf",
      "ci",
      "cm",
      "cd",
      "cg",
      "km",
      "cv",
      "dj",
      "dz",
      "eg",
      "er",
      "eh",
      "et",
      "ga",
      "gh",
      "gn",
      "gm",
      "gw",
      "gq",
      "ke",
      "lr",
      "ly",
      "ls",
      "ma",
      "mg",
      "ml",
      "mz",
      "mr",
      "mu",
      "mw",
      "yt",
      "na",
      "ne",
      "ng",
      "re",
      "rw",
      "sd",
      "sn",
      "sh",
      "sl",
      "so",
      "ss",
      "st",
      "sz",
      "sc",
      "td",
      "tg",
      "tn",
      "tz",
      "ug",
      "za",
      "zm",
      "zw",
    ],
    an: ["aq", "tf", "bv"],
    as: [
      "af",
      "ae",
      "am",
      "ap",
      "az",
      "bd",
      "bh",
      "bn",
      "bt",
      "cn",
      "hk",
      "id",
      "in",
      "io",
      "ir",
      "iq",
      "il",
      "jo",
      "jp",
      "kz",
      "kg",
      "kh",
      "kr",
      "kw",
      "la",
      "lb",
      "lk",
      "mo",
      "mv",
      "mm",
      "mn",
      "my",
      "np",
      "om",
      "pk",
      "ph",
      "kp",
      "ps",
      "qa",
      "sa",
      "sg",
      "sy",
      "th",
      "tj",
      "tm",
      "tl",
      "tw",
      "uz",
      "vn",
      "ye",
    ],
    au: [
      "as",
      "au",
      "cc",
      "ck",
      "cx",
      "fj",
      "fm",
      "gu",
      "hm",
      "ki",
      "mh",
      "mp",
      "nc",
      "nf",
      "nu",
      "nr",
      "nz",
      "pn",
      "pw",
      "pg",
      "pf",
      "sb",
      "tk",
      "to",
      "tv",
      "um",
      "vu",
      "wf",
      "ws",
    ],
    eu: [
      "ax",
      "al",
      "ad",
      "at",
      "be",
      "bg",
      "ba",
      "by",
      "ch",
      "cy",
      "cz",
      "de",
      "dk",
      "es",
      "ee",
      "eu",
      "fi",
      "fr",
      "fo",
      "uk",
      "ge",
      "gg",
      "gi",
      "gr",
      "hr",
      "hu",
      "im",
      "ie",
      "is",
      "it",
      "je",
      "li",
      "lt",
      "lu",
      "lv",
      "mc",
      "md",
      "mk",
      "mt",
      "me",
      "nl",
      "no",
      "pl",
      "pt",
      "ro",
      "ru",
      "sj",
      "sm",
      "rs",
      "sk",
      "si",
      "se",
      "tr",
      "ua",
      "va",
    ],
    na: [
      "aw",
      "ai",
      "an",
      "ag",
      "bq",
      "bs",
      "bl",
      "bz",
      "bm",
      "bb",
      "ca",
      "cr",
      "cu",
      "cw",
      "ky",
      "dm",
      "do",
      "gp",
      "gd",
      "gl",
      "gt",
      "hn",
      "ht",
      "jm",
      "kn",
      "lc",
      "mf",
      "mx",
      "ms",
      "mq",
      "ni",
      "pa",
      "pr",
      "sv",
      "pm",
      "sx",
      "tc",
      "tt",
      "us",
      "vc",
      "vg",
      "vi",
    ],
    sa: [
      "ar",
      "bo",
      "br",
      "cl",
      "co",
      "ec",
      "fk",
      "gf",
      "gy",
      "pe",
      "py",
      "gs",
      "sr",
      "uy",
      "ve",
    ],
  },
  rtb_sync = window.rtb_sync || {},
  rtb_pixel_set = ["rtb", "aud", "nets", "pubs"],
  request_country = getQueryStringParam("co") || getCountry(),
  request_region = getQueryStringParam("geo") || getRegion(request_country),
  expiration = 86400,
  cap = 1;
try {
  document.cookie, (document.noCookieAccess = !1);
} catch (e) {
  document.noCookieAccess = !0;
}
try {
  window.localStorage.getItem("any"), (localStorageAccess = !0);
} catch (e) {
  localStorageAccess = !1;
}
try {
  window.sessionStorage.getItem("any"), (sessionStorageAccess = !0);
} catch (e) {
  sessionStorageAccess = !1;
}
function getPartnerFcaps(e) {
  try {
    var t = JSON.parse(lsGet(e));
  } catch (e) {}
  return t || {};
}
function getPartnerFcap(e, t) {
  return t ? ((e[t] = e[t] || createNewFcap()), e[t]) : null;
}
function isExpired(e) {
  return !e || !e.exp || e.exp < new Date().getTime() / 1e3;
}
function isCapped(e) {
  return !!e && e.cap >= cap && !isExpired(e);
}
function createNewFcap() {
  return { cap: 0, exp: new Date().getTime() / 1e3 + expiration };
}
function incrementPartnerFcap(e) {
  e.cap++;
}
function removeExpiredPartners(e) {
  for (var t in e) e.hasOwnProperty(t) && isExpired(e[t]) && delete e[t];
}
function savePartnerFcaps(e, t) {
  if (e)
    try {
      lsSet(e, JSON.stringify(t));
    } catch (e) {}
}
function getConsentWindowFor(e) {
  for (var t = window; t !== window.top; ) {
    t = t.parent;
    try {
      if (t.frames[e]) return t;
    } catch (e) {}
  }
  return !1;
}
function oz_onPixelsLoaded(e) {
  if (e && e.pixels)
    for (var t, n = 0; n < e.pixels.length; n++)
      (t = e.pixels[n].url) &&
        0 == t.indexOf("http") &&
        (new Image().src = appendConsentQS(t));
}
function getReferrer() {
  var e,
    t = document.referrer;
  return (e = t && 0 < t.length ? escape(t) : e);
}
function setCookie(e, t, n) {
  var r,
    n = n
      ? ((r = new Date()).setTime(r.getTime() + 24 * n * 60 * 60 * 1e3),
        "; expires=" + r.toGMTString())
      : "";
  try {
    document.cookie =
      e + "=" + escape(t) + n + "; path=/; SameSite=None; Secure";
  } catch (e) {}
}
function deleteCookie(e) {
  try {
    document.cookie =
      e +
      "=; Path=/; Expires=Thu, 01 Jan 1970 00:00:01 GMT; SameSite=None; Secure";
  } catch (e) {}
}
function readCookie(e) {
  var t = e + "=",
    n = "";
  try {
    n = document.cookie.split(";");
  } catch (e) {}
  for (var r = 0; r < n.length; r++) {
    for (var o = n[r]; " " == o.charAt(0); ) o = o.substring(1, o.length);
    if (0 == o.indexOf(t)) return unescape(o.substring(t.length, o.length));
  }
  return null;
}
function trim_whitespace(e) {
  return e.replace(/^\s+|\s+$/gm, "");
}
function countCookies(e) {
  var t = "";
  try {
    t = document.cookie.split(";");
  } catch (e) {}
  for (var n = 0, r = 0; r < t.length; r++) {
    var o = trim_whitespace((o = t[r]));
    (!e || 0 == o.indexOf(e)) && n++;
  }
  return n;
}
function addScriptAsync(e, t) {
  var n = document.createElement("script");
  t && n.setAttribute("id", t),
    n.setAttribute("type", "text/javascript"),
    (e = e.replace(/\s/g, "+")),
    n.setAttribute("src", e),
    document.getElementsByTagName("head").item(0).appendChild(n);
}
function addScript(e, t) {
  document.write(
    '<script type="text/javascript" SRC="' + e + '" async></script>'
  );
}
function retrieveQueryParams() {
  for (
    var e, t = window.location.search.substring(1).split("&"), n = {}, r = 0;
    r < t.length;
    r++
  )
    (e = t[r].split("="))[0] &&
      (n[decodeURIComponent(e[0])] = decodeURIComponent(e[1] || ""));
  return n;
}
function getCountry() {
  return (navigator.language || navigator.userLanguage || "")
    .substr(-2)
    .toLowerCase();
}
function getRegion(e) {
  if (e)
    for (var t in regionCountries)
      if (
        regionCountries.hasOwnProperty(t) &&
        -1 < regionCountries[t].indexOf(e)
      )
        return t;
  return "";
}
function getAllowList(e) {
  e = e || window;
  try {
    var t,
      n = /^\/account\/\d+\.html$/,
      r = findFriendlyIframes(e.location.host, e.top, 1).filter(function (e) {
        return n.test(e.location.pathname);
      });
    if (r.length)
      return (
        log("found account iframe:", r[0]),
        (t = r[0].allowlist) && t.sync_pixels
      );
  } catch (e) {
    log("allowlist error:", e);
  }
}
function getQueryStringParam(e) {
  return !e ||
    -1 === (window.location.search || "").indexOf(e) ||
    !(e = new RegExp("[?&]" + e + "((=([^&]*))|(&|$))").exec(
      window.location.search
    )) ||
    e.length < 5
    ? null
    : decodeURIComponent(e[3] || "");
}
function loadExpiration() {
  if (localStorageAccess) t = lsGet;
  else {
    if (!sessionStorageAccess)
      return log("No storage access. Expiration not loaded"), {};
    t = ssGet;
  }
  var e = {},
    t = t("pux");
  if (t) {
    var n,
      r = t.split("&");
    for (n in r) {
      var o,
        a = r[n].split("=");
      a.length < 2 ||
        ((o = a[0]),
        0 < (a = a[1].split(",")).length && (e[o] = { created: a[0] }));
    }
  }
  return e;
}
function saveExpiration(e) {
  var t;
  if (localStorageAccess) t = lsSet;
  else {
    if (!sessionStorageAccess)
      return void log("No storage access. Expiration not saved");
    t = ssSet;
  }
  var n = "";
  for (name in e) var r = e[name], n = (n += name + "=") + r.created + "&";
  t("pux", n);
}
function is_expired(e, t) {
  return !(
    t &&
    ((e = Number(e)),
    new Date().getTime() / 36e5 -
      new Date(2010, 0, 1, 0, 0, 0, 0).getTime() / 36e5 <
      new Number(t.created) + 24 * e)
  );
}
function shouldFirePixel(e) {
  var t = expiration_info[e.nid];
  return (
    !(t && !is_expired(e.info.ttl || e.context.ttl || rtb_sync.ttl, t)) &&
    ((t =
      0 == e.info.sample
        ? e.info.sample
        : e.info.sample || e.context.sample || rtb_sync.pixel_sample || 0),
    (t = Number(t)),
    Math.floor(100 * Math.random()) < t)
  );
}
function firePixel(e) {
  var t,
    n = Math.floor(new Date().getTime() / 36e5),
    r = new Date(2010, 0, 1, 0, 0, 0, 0).getTime() / 36e5,
    o =
      ((expiration_info[e.nid] = { created: n - r }), e.info.secure || e.info);
  o &&
    ((n = getReferrer()),
    o.script &&
      ((t = o.script), "rp" == e.nid) &&
      n &&
      (t = appendQSParams(t, "rf=" + n)),
    o.img &&
      setTimeout(function () {
        new Image().src = appendConsentQS(o.img);
      }, 100),
    o.iframe &&
      document.write(
        "<iframe src='" +
          appendConsentQS(o.iframe) +
          "' width='1' height='1' frameborder='0'></iframe>"
      ),
    o.script) &&
    addScript(appendConsentQS(t));
}
function shuffle(e) {
  var t = e.length;
  if (0 == t) return !1;
  for (; --t; ) {
    var n = Math.floor(Math.random() * (t + 1)),
      r = e[t];
    (e[t] = e[n]), (e[n] = r);
  }
}
function prioritize(e) {
  e.sort(function (e, t) {
    return e.info.priority - t.info.priority;
  });
}
function firePixelsToMax(e, t) {
  for (var n = 0; n < t && n < e.length; n++) firePixel(e[n]);
}
function fireRandomPixelsByPriority(e, t) {
  e = sortPixelsByPriority(e);
  allocatePixelCalls(e, t),
    fireXRandomPixels(e.p1, e.p1Calls),
    fireXRandomPixels(e.other, e.otherCalls);
}
function sortPixelsByPriority(e) {
  var t = { p1: [], other: [] };
  return (
    e.forEach(function (e) {
      sortPixel(e, t);
    }),
    t
  );
}
function sortPixel(e, t) {
  (1 === e.info.priority ? t.p1 : t.other).push(e);
}
function allocatePixelCalls(e, t) {
  var n = localStorageAccess || sessionStorageAccess ? 4 : 2,
    r = e.p1.length,
    o = e.other.length;
  for (
    e.p1Calls = determineAllocation(r, o, n),
      e.otherCalls = determineAllocation(o, r, n);
    e.p1Calls + e.otherCalls > t && 0 < e.otherCalls;

  )
    --e.otherCalls;
  for (; e.p1Calls + e.otherCalls > t && 0 < e.p1Calls; ) --e.p1Calls;
}
function determineAllocation(e, t, n) {
  t = t < n ? n - t : 0;
  return Math.min(e, n + t);
}
function fireXRandomPixels(e, t) {
  for (var n = 0; n < t; n++) {
    var r = Math.floor(Math.random() * e.length);
    firePixel(e.splice(r, 1)[0]);
  }
}
function array_contains(t, n) {
  for (e in t) if (n == t[e]) return !0;
  return !1;
}
function detectIE() {
  var e = window.navigator.userAgent;
  return (
    0 < e.indexOf("MSIE ") ||
    0 < e.indexOf("Trident/") ||
    0 < e.indexOf("Edge/")
  );
}
function doPixels(t) {
  var e,
    n,
    r = [],
    o = [],
    a = ((expiration_info = loadExpiration()), getAllowList());
  for (n in (a && log('restricting to the following "allowlist" pixels:', a),
  rtb_pixel_set)) {
    var i = rtb_pixel_set[n],
      s = rtb_sync.pixel_sets[i];
    if (s)
      for (g in s.pixels)
        (!a || -1 < a.indexOf(g)) &&
          (((c = s.pixels[g]).priority =
            c.priority || s.priority || rtb_sync.priority),
          isPixelAllowed(
            c.sample,
            c.region,
            request_region,
            c.country,
            request_country
          )) &&
          ((c.ttl = c.ttl || s.ttl || rtb_sync.ttl),
          (r[r.length] = { pixel_set: i, nid: g, info: c, context: s }));
  }
  for (n in (t &&
    (log("filtering pixels by vendorConsentArray:", t),
    (r = r.filter((e) => t.includes(e.nid)))),
  prioritize(r),
  detectIE() &&
    ((e = rtb_sync.max_ie_partners || r.length), r.splice(e, r.length - e)),
  r))
    is_expired((l = r[n]).info.ttl, expiration_info[l.nid]) &&
      0 != l.info.sample &&
      (o[o.length] = l);
  (e = 0 == o.length), shuffle(o), prioritize(o);
  var c,
    l,
    u = o.filter(shouldFirePixel),
    p = rtb_sync.max_pixels || 1,
    g =
      (readCookie("khaos")
        ? firePixelsToMax(u, p)
        : fireRandomPixelsByPriority(o, p),
      "rubicon");
  shouldFirePixel(
    (l = { nid: g, info: (c = rtb_sync.notify[g]), context: rtb_sync })
  ) &&
    ((l.info.img += "?allfired=" + e),
    (l.info.img += "&cookies=" + countCookies()),
    (l.info.img += "&ie=" + (detectIE() ? "true" : "false")),
    firePixel(l)),
    saveExpiration(expiration_info);
}
function isPixelAllowed(e, t, n, r, o) {
  var a;
  return (
    0 != e &&
    ((e = !(!r || !o)),
    (!(a = !(!t || !n)) && !e) ||
      (a && (t == n || array_contains(t, n))) ||
      (e && (r == o || array_contains(r, o))))
  );
}
function getConsentParams(e, t, n) {
  return !1 === n
    ? t
    : ((n = t || {}),
      e &&
        "object" == typeof e &&
        (e.uspString || (n.gdpr_consent = e.tcString || e.consentData),
        void 0 !== e.gdprApplies && (n.gdpr = e.gdprApplies ? 1 : 0),
        e.uspString) &&
        (n.us_privacy = encodeURIComponent(e.uspString)),
      "string" == typeof e && (n.gdpr_consent = e),
      n);
}
function getConsentQS(t) {
  return (
    (t = t || {}),
    ["gdpr_consent", "gdpr", "us_privacy"]
      .filter(function (e) {
        return void 0 !== t[e];
      })
      .map(function (e) {
        return e + "=" + t[e];
      })
      .join("&")
  );
}
function appendQSParams(e, t) {
  return (e = t ? e && e + (e.match(/\?/) ? "&" : "?") + t : e);
}
function appendConsentQS(e) {
  return appendQSParams(e, getConsentQS(consentParams));
}
function appendQueryParams(t) {
  t = t || {};
  var n = ["endpoint", "region", "country", "p"];
  return Object.keys(t)
    .filter(function (e) {
      return -1 === n.indexOf(e) && !e.match(/^rp_/);
    })
    .map(function (e) {
      return encodeURIComponent(e) + "=" + encodeURIComponent(t[e]);
    })
    .join("&");
}
function getConsentQSParams() {
  var e,
    t = getQueryStringParam("gdpr"),
    n = getQueryStringParam("gdpr_consent"),
    r = getQueryStringParam("us_privacy");
  return (
    n && (e = { gdpr_consent: n }),
    t && ((e = e || {}).gdpr = "false" === t || "0" === t ? 0 : 1),
    r && ((e = e || {}).us_privacy = r),
    e
  );
}
function getConsent(r) {
  var e, t, n, o, a, i, s, c, l, u, p;
  function g(t, e, n) {
    0 !== o.length &&
      o.includes(t) &&
      ((o = o.filter(function (e) {
        return e !== t;
      })),
      (consentParams = getConsentParams(n, consentParams, e)),
      0 !== o.length || a || ((a = !0), r()));
  }
  ((consentParams = getConsentQSParams()) && void 0 !== consentParams.gdpr) ||
    (t = (e = getConsentWindowFor("__tcfapiLocator"))
      ? null
      : getConsentWindowFor("__cmpLocator")),
    (consentParams && consentParams.us_privacy) ||
      (n = getConsentWindowFor("__uspapiLocator")),
    e || t || n
      ? ((a = !(o = [])),
        (i = "us-" + Math.random()),
        (s = "us-" + Math.random()),
        (c = "us-" + Math.random()),
        e
          ? (o.push("tcf"),
            e.postMessage(
              {
                __tcfapiCall: {
                  callId: c,
                  command: "addEventListener",
                  version: 2,
                },
              },
              "*"
            ))
          : t &&
            (o.push("cmp"),
            t.postMessage(
              {
                __cmpCall: {
                  callId: i,
                  command: "getConsentData",
                  parameter: null,
                },
              },
              "*"
            )),
        n &&
          (o.push("usp"),
          n.postMessage(
            { __uspapiCall: { callId: s, command: "getUSPData", version: 1 } },
            "*"
          )),
        window.addEventListener("message", function (e) {
          try {
            var t, n, r, o;
            e &&
              e.data &&
              ((n = (t =
                "string" == typeof e.data ? JSON.parse(e.data) : e.data)
                .__cmpReturn),
              (r = t.__uspapiReturn),
              (o = t.__tcfapiReturn) &&
              o.callId === c &&
              o.returnValue &&
              ("tcloaded" === o.returnValue.eventStatus ||
                "useractioncomplete" === o.returnValue.eventStatus)
                ? (clearTimeout(u), g("tcf", o.success, o.returnValue))
                : n &&
                  n.callId === i &&
                  (clearTimeout(p), g("cmp", n.success, n.returnValue)),
              r) &&
              r.callId === s &&
              (clearTimeout(l), g("usp", r.success, r.returnValue));
          } catch (e) {}
        }),
        n &&
          (l = setTimeout(function () {
            g("usp", !1);
          }, 100)),
        e
          ? (u = setTimeout(function () {
              g("tcf", !1);
            }, 500))
          : t &&
            (p = setTimeout(function () {
              g("cmp", !1);
            }, 500)))
      : r();
}
function checkConsent() {
  if ("true" === readCookie("trp_optout"))
    return log("trp_optout == true, not running syncs"), !1;
  document.noCookieAccess &&
    log("no access to document.cookie, running syncs anyway"),
    log("making request for consent");
  var t,
    e = getConsentQS(consentParams),
    n = lsGet("khaos"),
    n = n ? (e.length ? "&" : "") + "khaos=" + n : "",
    r = !1,
    o = new XMLHttpRequest();
  (o.withCredentials = !0),
    ["error", "abort"].forEach(function (e) {
      o.addEventListener(e, function () {
        log("request failed, not running syncs:", e);
      });
    }),
    o.addEventListener("load", function () {
      try {
        var e = JSON.parse(o.responseText);
        (r = 1 === Number(e.c)),
          checkSampling(
            "filter syncs by vendor consent",
            rtb_sync.consent_rate,
            "VC",
            lsGet,
            lsSet,
            lsRemove
          ) &&
            (t = e.sa) &&
            log("vendorConsentArray:", t);
      } catch (e) {
        log("failed to parse consent response", o.responseText);
      }
      r
        ? (log("have consent"), runSyncs(t))
        : log("no consent, not running syncs");
    }),
    o.open("GET", "https://token.rubiconproject.com/khaos.json?" + e + n),
    o.send();
}
function alreadyRanOnPage(e) {
  if (!navigator.cookieEnabled)
    return log("The browser does not support cookies"), !1;
  e = e || window;
  try {
    return findFriendlyIframes(e.location.host, e.top, 5).find(function (e) {
      return e.emilyRan && /^\/usync\.html$/.test(e.location.pathname);
    })
      ? !0
      : ((e.emilyRan = !0),
        setTimeout(function () {
          e.emilyRan = !1;
        }, 3e5),
        !1);
  } catch (e) {
    return log("failed checking if already ran:", e), !1;
  }
}
function sellerSync(e, t, n, r) {
  var o = "",
    o = appendQSParams(
      (o = [
        "https://pixel",
        (o =
          (e = e || {}).endpoint in
          { "us-west": "", "us-east": "", eu: "", apac: "" }
            ? "-" + e.endpoint
            : o),
        ".rubiconproject.com/exchange/sync.php?p=",
        t,
      ].join("")),
      appendQueryParams(e)
    );
  (o = appendQSParams(o, appendQueryParams(n))),
    r && (o = appendQSParams(o, "khaos=" + r)),
    (new Image().src = o);
}
function initiateSellerSync(e) {
  var t, n;
  return (
    !!e &&
    (removeExpiredPartners((t = getPartnerFcaps("fcap"))),
    (n = !1),
    isCapped((e = getPartnerFcap(t, e))) || ((n = !0), incrementPartnerFcap(e)),
    savePartnerFcaps("fcap", t),
    n)
  );
}
function runSyncs(e) {
  var t,
    n,
    r,
    o,
    a = readCookie("khaos");
  a || document.noCookieAccess
    ? (checkKhaosMatchesPrevious(a),
      (n = (t = retrieveQueryParams()).p) &&
        (log("doing seller sync"),
        (r = lsGet("khaos")),
        (o = ssGet("khaos")),
        n
          .split(",")
          .filter(function (e) {
            return initiateSellerSync(e);
          })
          .forEach(function (e) {
            return sellerSync(t, e, consentParams, a || r || o);
          })),
      shouldSkipBuyerSync() || (log("doing buyer sync"), doPixels(e)))
    : log("skipping syncs cause no khaos");
}
function findFriendlyIframes(e, t, n, r) {
  r = r || 0;
  var o = [];
  try {
    e == t.location.host && (o.push(t), log("found friendly iframe:", t));
  } catch (e) {}
  if (r < n)
    try {
      for (var a = 0; a < t.frames.length; a++)
        o = o.concat(findFriendlyIframes(e, t.frames[a], n, r + 1));
    } catch (e) {
      log("error looping iframes:", e);
    }
  return o;
}
function checkKhaosMatchesPrevious(e) {
  var t;
  e &&
    e !== (t = lsGet("khaos")) &&
    (log("khaos (" + e + ") does not match previous khaos (" + t + ")"),
    resetSyncTracking(),
    lsSet("khaos", e));
}
function resetSyncTracking() {
  log("resetting sync tracking"), lsRemove("pux"), lsRemove("fcap");
}
function checkSampling(e, t, n, r, o, a) {
  n = getSampleNumber((t = Number(t) || 0), n, r, o, a);
  return (
    log("checkSampling: sampleNumber:", n, "sampleRate:", t),
    n < t
      ? (log(e, ": Yes, sampled in"), !0)
      : (log(e, ": No, sampled out"), !1)
  );
}
function getSampleNumber(e, t, n, r, o) {
  var a = "SMPL-";
  if (0 === e || 100 === e) {
    if (t && o)
      try {
        o(a + t);
      } catch (e) {}
    return 50;
  }
  if (e && t && n && r) {
    try {
      var i = JSON.parse(n(a + t));
      if (i.rate === e && Number.isInteger(i.rn))
        return log("found existing sampleNumber:", i.rn, "for key:", t), i.rn;
    } catch (e) {}
    try {
      var s = { rate: e, rn: Math.floor(100 * Math.random()) };
      return r(a + t, JSON.stringify(s)), s.rn;
    } catch (e) {
      log("failed to store sampleNumber for key:", t);
    }
  }
  return Math.floor(100 * Math.random());
}
function startSync() {
  return (
    log("starting"),
    !(
      (shouldSkipBuyerSync() && !isSellerSync()) ||
      (getConsent(checkConsent), 0)
    )
  );
}
function lsGet(t) {
  try {
    return window.localStorage.getItem(t);
  } catch (e) {
    return t !== debug_param && log("LS: failed to get:", t), null;
  }
}
function lsSet(t, n) {
  try {
    window.localStorage.setItem(t, n);
  } catch (e) {
    log("LS: failed to set:", t, n);
  }
}
function lsRemove(t) {
  try {
    window.localStorage.removeItem(t);
  } catch (e) {
    log("LS: failed to remove:", t);
  }
}
function ssGet(t) {
  try {
    return window.sessionStorage.getItem(t);
  } catch (e) {
    return t !== debug_param && log("SS: failed to get:", t), null;
  }
}
function ssSet(t, n) {
  try {
    window.sessionStorage.setItem(t, n);
  } catch (e) {
    log("SS: failed to set:", t, n);
  }
}
function ssRemove(t) {
  try {
    window.sessionStorage.removeItem(t);
  } catch (e) {
    log("SS: failed to remove:", t);
  }
}
function getLogPrefix() {
  var e;
  return (
    logPrefix ||
      ((e = "" + Math.random()),
      (logPrefix = "Emily (" + e.substring(e.length - 3) + "):")),
    logPrefix
  );
}
var debug_param = "emily_debug";
function log() {
  try {
    !1 !== debug &&
      (!0 === debug ||
      "true" === readCookie(debug_param) ||
      "true" === lsGet(debug_param) ||
      "true" === ssGet(debug_param)
        ? ((debug = !0),
          console.log.apply(
            console,
            [getLogPrefix()].concat(Array.prototype.slice.call(arguments))
          ))
        : (debug = !1));
  } catch (e) {}
}
startSync();
