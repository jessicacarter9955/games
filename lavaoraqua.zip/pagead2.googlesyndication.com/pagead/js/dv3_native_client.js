(function () {
  var aa =
      typeof Object.create == "function"
        ? Object.create
        : function (a) {
            function b() {}
            b.prototype = a;
            return new b();
          },
    ba =
      typeof Object.defineProperties == "function"
        ? Object.defineProperty
        : function (a, b, c) {
            if (a == Array.prototype || a == Object.prototype) return a;
            a[b] = c.value;
            return a;
          };
  function ca(a) {
    a = [
      "object" == typeof globalThis && globalThis,
      a,
      "object" == typeof window && window,
      "object" == typeof self && self,
      "object" == typeof global && global,
    ];
    for (var b = 0; b < a.length; ++b) {
      var c = a[b];
      if (c && c.Math == Math) return c;
    }
    throw Error("Cannot find global object");
  }
  var p = ca(this),
    da = typeof Symbol === "function" && typeof Symbol("x") === "symbol",
    r = {},
    ea = {};
  function u(a, b, c) {
    if (!c || a != null) {
      c = ea[b];
      if (c == null) return a[b];
      c = a[c];
      return c !== void 0 ? c : a[b];
    }
  }
  function w(a, b, c) {
    if (b)
      a: {
        var d = a.split(".");
        a = d.length === 1;
        var e = d[0],
          g;
        !a && e in r ? (g = r) : (g = p);
        for (e = 0; e < d.length - 1; e++) {
          var f = d[e];
          if (!(f in g)) break a;
          g = g[f];
        }
        d = d[d.length - 1];
        c = da && c === "es6" ? g[d] : null;
        b = b(c);
        b != null &&
          (a
            ? ba(r, d, { configurable: !0, writable: !0, value: b })
            : b !== c &&
              (ea[d] === void 0 &&
                ((a = (Math.random() * 1e9) >>> 0),
                (ea[d] = da ? p.Symbol(d) : "$jscp$" + a + "$" + d)),
              ba(g, ea[d], { configurable: !0, writable: !0, value: b })));
      }
  }
  var fa;
  if (da && typeof u(Object, "setPrototypeOf") == "function")
    fa = u(Object, "setPrototypeOf");
  else {
    var ha;
    a: {
      var ia = { a: !0 },
        ja = {};
      try {
        ja.__proto__ = ia;
        ha = ja.a;
        break a;
      } catch (a) {}
      ha = !1;
    }
    fa = ha
      ? function (a, b) {
          a.__proto__ = b;
          if (a.__proto__ !== b) throw new TypeError(a + " is not extensible");
          return a;
        }
      : null;
  }
  var z = fa;
  function A(a, b) {
    a.prototype = aa(b.prototype);
    a.prototype.constructor = a;
    if (z) z(a, b);
    else
      for (var c in b)
        if (c != "prototype")
          if (Object.defineProperties) {
            var d = Object.getOwnPropertyDescriptor(b, c);
            d && Object.defineProperty(a, c, d);
          } else a[c] = b[c];
    a.ya = b.prototype;
  }
  function ka(a) {
    var b = 0;
    return function () {
      return b < a.length ? { done: !1, value: a[b++] } : { done: !0 };
    };
  }
  function C(a) {
    var b =
      typeof r.Symbol != "undefined" &&
      u(r.Symbol, "iterator") &&
      a[u(r.Symbol, "iterator")];
    if (b) return b.call(a);
    if (typeof a.length == "number") return { next: ka(a) };
    throw Error(String(a) + " is not an iterable or ArrayLike");
  }
  function la(a) {
    if (!(a instanceof Array)) {
      a = C(a);
      for (var b, c = []; !(b = a.next()).done; ) c.push(b.value);
      a = c;
    }
    return a;
  }
  function ma(a) {
    return na(a, a);
  }
  function na(a, b) {
    a.raw = b;
    Object.freeze && (Object.freeze(a), Object.freeze(b));
    return a;
  }
  var oa =
    da && typeof u(Object, "assign") == "function"
      ? u(Object, "assign")
      : function (a, b) {
          if (a == null) throw new TypeError("No nullish arg");
          a = Object(a);
          for (var c = 1; c < arguments.length; c++) {
            var d = arguments[c];
            if (d)
              for (var e in d)
                Object.prototype.hasOwnProperty.call(d, e) && (a[e] = d[e]);
          }
          return a;
        };
  w(
    "Object.assign",
    function (a) {
      return a || oa;
    },
    "es6"
  );
  function pa(a) {
    if (!(a instanceof Object))
      throw new TypeError("Iterator result " + a + " is not an object");
  }
  function D() {
    this.A = !1;
    this.l = null;
    this.o = void 0;
    this.h = 1;
    this.m = this.v = 0;
    this.M = this.i = null;
  }
  function qa(a) {
    if (a.A) throw new TypeError("Generator is already running");
    a.A = !0;
  }
  D.prototype.H = function (a) {
    this.o = a;
  };
  function E(a, b) {
    a.i = { da: b, fa: !0 };
    a.h = a.v || a.m;
  }
  D.prototype.getNextAddressJsc = function () {
    return this.h;
  };
  D.prototype.getYieldResultJsc = function () {
    return this.o;
  };
  D.prototype.return = function (a) {
    this.i = { return: a };
    this.h = this.m;
  };
  D.prototype["return"] = D.prototype.return;
  D.prototype.ka = function (a) {
    this.i = { I: a };
    this.m < a ? ((this.h = a), (this.i = null)) : (this.h = this.m);
  };
  D.prototype.jumpThroughFinallyBlocks = D.prototype.ka;
  D.prototype.j = function (a, b) {
    this.h = b;
    return { value: a };
  };
  D.prototype.yield = D.prototype.j;
  D.prototype.na = function (a, b) {
    a = C(a);
    var c = a.next();
    pa(c);
    if (c.done) (this.o = c.value), (this.h = b);
    else return (this.l = a), this.j(c.value, b);
  };
  D.prototype.yieldAll = D.prototype.na;
  D.prototype.I = function (a) {
    this.h = a;
  };
  D.prototype.jumpTo = D.prototype.I;
  D.prototype.N = function () {
    this.h = 0;
  };
  D.prototype.jumpToEnd = D.prototype.N;
  D.prototype.F = function (a, b) {
    this.v = a;
    b != void 0 && (this.m = b);
  };
  D.prototype.setCatchFinallyBlocks = D.prototype.F;
  D.prototype.ma = function (a) {
    this.v = 0;
    this.m = a || 0;
  };
  D.prototype.setFinallyBlock = D.prototype.ma;
  D.prototype.D = function (a, b) {
    this.h = a;
    this.v = b || 0;
  };
  D.prototype.leaveTryBlock = D.prototype.D;
  D.prototype.C = function (a) {
    this.v = a || 0;
    a = this.i.da;
    this.i = null;
    return a;
  };
  D.prototype.enterCatchBlock = D.prototype.C;
  D.prototype.V = function (a, b, c) {
    c ? (this.M[c] = this.i) : (this.M = [this.i]);
    this.v = a || 0;
    this.m = b || 0;
    this.i = null;
  };
  D.prototype.enterFinallyBlock = D.prototype.V;
  D.prototype.la = function (a, b) {
    b = this.M.splice(b || 0)[0];
    (b = this.i = this.i || b)
      ? b.fa
        ? (this.h = this.v || this.m)
        : b.I != void 0 && this.m < b.I
        ? ((this.h = b.I), (this.i = null))
        : (this.h = this.m)
      : (this.h = a);
  };
  D.prototype.leaveFinallyBlock = D.prototype.la;
  D.prototype.ja = function (a) {
    return new ra(a);
  };
  D.prototype.forIn = D.prototype.ja;
  function ra(a) {
    this.j = a;
    this.h = [];
    for (var b in a) this.h.push(b);
    this.h.reverse();
  }
  ra.prototype.i = function () {
    for (; this.h.length > 0; ) {
      var a = this.h.pop();
      if (a in this.j) return a;
    }
    return null;
  };
  ra.prototype.getNext = ra.prototype.i;
  function sa(a) {
    this.h = new D();
    this.i = a;
  }
  function ta(a, b) {
    qa(a.h);
    var c = a.h.l;
    if (c)
      return ua(
        a,
        "return" in c
          ? c["return"]
          : function (d) {
              return { value: d, done: !0 };
            },
        b,
        a.h.return
      );
    a.h.return(b);
    return F(a);
  }
  function ua(a, b, c, d) {
    try {
      var e = b.call(a.h.l, c);
      pa(e);
      if (!e.done) return (a.h.A = !1), e;
      var g = e.value;
    } catch (f) {
      return (a.h.l = null), E(a.h, f), F(a);
    }
    a.h.l = null;
    d.call(a.h, g);
    return F(a);
  }
  function F(a) {
    for (; a.h.h; )
      try {
        var b = a.i(a.h);
        if (b) return (a.h.A = !1), { value: b.value, done: !1 };
      } catch (c) {
        (a.h.o = void 0), E(a.h, c);
      }
    a.h.A = !1;
    if (a.h.i) {
      b = a.h.i;
      a.h.i = null;
      if (b.fa) throw b.da;
      return { value: b.return, done: !0 };
    }
    return { value: void 0, done: !0 };
  }
  function va(a) {
    this.next = function (b) {
      qa(a.h);
      a.h.l ? (b = ua(a, a.h.l.next, b, a.h.H)) : (a.h.H(b), (b = F(a)));
      return b;
    };
    this.throw = function (b) {
      qa(a.h);
      if (a.h.l) {
        var c = a.h.l["throw"];
        if (c) var d = ua(a, c, b, a.h.H);
        else {
          b = a.h.l;
          a.h.l = null;
          try {
            b["return"] && ((d = b["return"]()), pa(d)),
              E(
                a.h,
                new TypeError("The iterator does not provide a 'throw' method.")
              );
          } catch (e) {
            E(a.h, e);
          }
          d = F(a);
        }
      } else E(a.h, b), (d = F(a));
      return d;
    };
    this.return = function (b) {
      return ta(a, b);
    };
    this[u(r.Symbol, "iterator")] = function () {
      return this;
    };
  }
  function wa(a) {
    function b(d) {
      return a.next(d);
    }
    function c(d) {
      return a.throw(d);
    }
    return new r.Promise(function (d, e) {
      function g(f) {
        f.done ? d(f.value) : r.Promise.resolve(f.value).then(b, c).then(g, e);
      }
      g(a.next());
    });
  }
  function H(a) {
    return wa(new va(new sa(a)));
  }
  function xa() {
    for (var a = Number(this), b = [], c = a; c < arguments.length; c++)
      b[c - a] = arguments[c];
    return b;
  }
  w(
    "globalThis",
    function (a) {
      return a || p;
    },
    "es_2020"
  );
  w(
    "Reflect.setPrototypeOf",
    function (a) {
      return a
        ? a
        : z
        ? function (b, c) {
            try {
              return z(b, c), !0;
            } catch (d) {
              return !1;
            }
          }
        : null;
    },
    "es6"
  );
  w(
    "Symbol",
    function (a) {
      function b(g) {
        if (this instanceof b)
          throw new TypeError("Symbol is not a constructor");
        return new c(d + (g || "") + "_" + e++, g);
      }
      function c(g, f) {
        this.h = g;
        ba(this, "description", { configurable: !0, writable: !0, value: f });
      }
      if (a) return a;
      c.prototype.toString = function () {
        return this.h;
      };
      var d = "jscomp_symbol_" + ((Math.random() * 1e9) >>> 0) + "_",
        e = 0;
      return b;
    },
    "es6"
  );
  w(
    "Symbol.iterator",
    function (a) {
      if (a) return a;
      a = (0, r.Symbol)("Symbol.iterator");
      ba(Array.prototype, a, {
        configurable: !0,
        writable: !0,
        value: function () {
          return ya(ka(this));
        },
      });
      return a;
    },
    "es6"
  );
  function ya(a) {
    a = { next: a };
    a[u(r.Symbol, "iterator")] = function () {
      return this;
    };
    return a;
  }
  w(
    "Promise",
    function (a) {
      function b(f) {
        this.i = 0;
        this.j = void 0;
        this.h = [];
        this.v = !1;
        var h = this.l();
        try {
          f(h.resolve, h.reject);
        } catch (k) {
          h.reject(k);
        }
      }
      function c() {
        this.h = null;
      }
      function d(f) {
        return f instanceof b
          ? f
          : new b(function (h) {
              h(f);
            });
      }
      if (a) return a;
      c.prototype.i = function (f) {
        if (this.h == null) {
          this.h = [];
          var h = this;
          this.j(function () {
            h.m();
          });
        }
        this.h.push(f);
      };
      var e = p.setTimeout;
      c.prototype.j = function (f) {
        e(f, 0);
      };
      c.prototype.m = function () {
        for (; this.h && this.h.length; ) {
          var f = this.h;
          this.h = [];
          for (var h = 0; h < f.length; ++h) {
            var k = f[h];
            f[h] = null;
            try {
              k();
            } catch (l) {
              this.l(l);
            }
          }
        }
        this.h = null;
      };
      c.prototype.l = function (f) {
        this.j(function () {
          throw f;
        });
      };
      b.prototype.l = function () {
        function f(l) {
          return function (m) {
            k || ((k = !0), l.call(h, m));
          };
        }
        var h = this,
          k = !1;
        return { resolve: f(this.H), reject: f(this.m) };
      };
      b.prototype.H = function (f) {
        if (f === this)
          this.m(new TypeError("A Promise cannot resolve to itself"));
        else if (f instanceof b) this.N(f);
        else {
          a: switch (typeof f) {
            case "object":
              var h = f != null;
              break a;
            case "function":
              h = !0;
              break a;
            default:
              h = !1;
          }
          h ? this.F(f) : this.o(f);
        }
      };
      b.prototype.F = function (f) {
        var h = void 0;
        try {
          h = f.then;
        } catch (k) {
          this.m(k);
          return;
        }
        typeof h == "function" ? this.V(h, f) : this.o(f);
      };
      b.prototype.m = function (f) {
        this.A(2, f);
      };
      b.prototype.o = function (f) {
        this.A(1, f);
      };
      b.prototype.A = function (f, h) {
        if (this.i != 0)
          throw Error(
            "Cannot settle(" +
              f +
              ", " +
              h +
              "): Promise already settled in state" +
              this.i
          );
        this.i = f;
        this.j = h;
        this.i === 2 && this.M();
        this.C();
      };
      b.prototype.M = function () {
        var f = this;
        e(function () {
          if (f.D()) {
            var h = p.console;
            typeof h !== "undefined" && h.error(f.j);
          }
        }, 1);
      };
      b.prototype.D = function () {
        if (this.v) return !1;
        var f = p.CustomEvent,
          h = p.Event,
          k = p.dispatchEvent;
        if (typeof k === "undefined") return !0;
        typeof f === "function"
          ? (f = new f("unhandledrejection", { cancelable: !0 }))
          : typeof h === "function"
          ? (f = new h("unhandledrejection", { cancelable: !0 }))
          : ((f = p.document.createEvent("CustomEvent")),
            f.initCustomEvent("unhandledrejection", !1, !0, f));
        f.promise = this;
        f.reason = this.j;
        return k(f);
      };
      b.prototype.C = function () {
        if (this.h != null) {
          for (var f = 0; f < this.h.length; ++f) g.i(this.h[f]);
          this.h = null;
        }
      };
      var g = new c();
      b.prototype.N = function (f) {
        var h = this.l();
        f.R(h.resolve, h.reject);
      };
      b.prototype.V = function (f, h) {
        var k = this.l();
        try {
          f.call(h, k.resolve, k.reject);
        } catch (l) {
          k.reject(l);
        }
      };
      b.prototype.then = function (f, h) {
        function k(n, t) {
          return typeof n == "function"
            ? function (x) {
                try {
                  l(n(x));
                } catch (v) {
                  m(v);
                }
              }
            : t;
        }
        var l,
          m,
          q = new b(function (n, t) {
            l = n;
            m = t;
          });
        this.R(k(f, l), k(h, m));
        return q;
      };
      b.prototype.catch = function (f) {
        return this.then(void 0, f);
      };
      b.prototype.R = function (f, h) {
        function k() {
          switch (l.i) {
            case 1:
              f(l.j);
              break;
            case 2:
              h(l.j);
              break;
            default:
              throw Error("Unexpected state: " + l.i);
          }
        }
        var l = this;
        this.h == null ? g.i(k) : this.h.push(k);
        this.v = !0;
      };
      b.resolve = d;
      b.reject = function (f) {
        return new b(function (h, k) {
          k(f);
        });
      };
      b.race = function (f) {
        return new b(function (h, k) {
          for (var l = C(f), m = l.next(); !m.done; m = l.next())
            d(m.value).R(h, k);
        });
      };
      b.all = function (f) {
        var h = C(f),
          k = h.next();
        return k.done
          ? d([])
          : new b(function (l, m) {
              function q(x) {
                return function (v) {
                  n[x] = v;
                  t--;
                  t == 0 && l(n);
                };
              }
              var n = [],
                t = 0;
              do
                n.push(void 0),
                  t++,
                  d(k.value).R(q(n.length - 1), m),
                  (k = h.next());
              while (!k.done);
            });
      };
      return b;
    },
    "es6"
  );
  w(
    "Object.setPrototypeOf",
    function (a) {
      return a || z;
    },
    "es6"
  );
  w(
    "Symbol.dispose",
    function (a) {
      return a ? a : (0, r.Symbol)("Symbol.dispose");
    },
    "es_next"
  );
  function za(a, b) {
    a instanceof String && (a += "");
    var c = 0,
      d = !1,
      e = {
        next: function () {
          if (!d && c < a.length) {
            var g = c++;
            return { value: b(g, a[g]), done: !1 };
          }
          d = !0;
          return { done: !0, value: void 0 };
        },
      };
    e[u(r.Symbol, "iterator")] = function () {
      return e;
    };
    return e;
  }
  w(
    "Array.prototype.keys",
    function (a) {
      return a
        ? a
        : function () {
            return za(this, function (b) {
              return b;
            });
          };
    },
    "es6"
  );
  w(
    "Array.prototype.entries",
    function (a) {
      return a
        ? a
        : function () {
            return za(this, function (b, c) {
              return [b, c];
            });
          };
    },
    "es6"
  );
  w(
    "Object.entries",
    function (a) {
      return a
        ? a
        : function (b) {
            var c = [],
              d;
            for (d in b)
              Object.prototype.hasOwnProperty.call(b, d) && c.push([d, b[d]]);
            return c;
          };
    },
    "es8"
  );
  w(
    "Number.isFinite",
    function (a) {
      return a
        ? a
        : function (b) {
            return typeof b !== "number"
              ? !1
              : !isNaN(b) && b !== Infinity && b !== -Infinity;
          };
    },
    "es6"
  );
  w(
    "Number.MAX_SAFE_INTEGER",
    function () {
      return 9007199254740991;
    },
    "es6"
  );
  w(
    "Number.MIN_SAFE_INTEGER",
    function () {
      return -9007199254740991;
    },
    "es6"
  );
  w(
    "Object.is",
    function (a) {
      return a
        ? a
        : function (b, c) {
            return b === c ? b !== 0 || 1 / b === 1 / c : b !== b && c !== c;
          };
    },
    "es6"
  );
  w(
    "Array.prototype.find",
    function (a) {
      return a
        ? a
        : function (b, c) {
            a: {
              var d = this;
              d instanceof String && (d = String(d));
              for (var e = d.length, g = 0; g < e; g++) {
                var f = d[g];
                if (b.call(c, f, g, d)) {
                  b = f;
                  break a;
                }
              }
              b = void 0;
            }
            return b;
          };
    },
    "es6"
  );
  w(
    "Object.values",
    function (a) {
      return a
        ? a
        : function (b) {
            var c = [],
              d;
            for (d in b)
              Object.prototype.hasOwnProperty.call(b, d) && c.push(b[d]);
            return c;
          };
    },
    "es8"
  );
  w(
    "Number.isNaN",
    function (a) {
      return a
        ? a
        : function (b) {
            return typeof b === "number" && isNaN(b);
          };
    },
    "es6"
  );
  w(
    "Array.prototype.values",
    function (a) {
      return a
        ? a
        : function () {
            return za(this, function (b, c) {
              return c;
            });
          };
    },
    "es8"
  ); /* 
 
 Copyright The Closure Library Authors. 
 SPDX-License-Identifier: Apache-2.0 
*/
  var I = this || self;
  function Aa(a, b) {
    a: {
      var c = ["CLOSURE_FLAGS"];
      for (var d = I, e = 0; e < c.length; e++)
        if (((d = d[c[e]]), d == null)) {
          c = null;
          break a;
        }
      c = d;
    }
    a = c && c[a];
    return a != null ? a : b;
  }
  function Ba(a, b) {
    var c = Array.prototype.slice.call(arguments, 1);
    return function () {
      var d = c.slice();
      d.push.apply(d, arguments);
      return a.apply(this, d);
    };
  }
  function Ca(a) {
    return a;
  } /* 
 
 Copyright Google LLC 
 SPDX-License-Identifier: Apache-2.0 
*/
  var Da = r.globalThis.trustedTypes,
    Ea;
  function Fa() {
    var a = null;
    if (!Da) return a;
    try {
      var b = function (c) {
        return c;
      };
      a = Da.createPolicy("goog#html", {
        createHTML: b,
        createScript: b,
        createScriptURL: b,
      });
    } catch (c) {}
    return a;
  }
  function Ga(a) {
    this.h = a;
  }
  Ga.prototype.toString = function () {
    return this.h + "";
  };
  function Ha(a) {
    var b;
    Ea === void 0 && (Ea = Fa());
    a = (b = Ea) ? b.createScriptURL(a) : a;
    return new Ga(a);
  }
  function Ia(a) {
    var b = xa.apply(1, arguments);
    if (b.length === 0) return Ha(a[0]);
    for (var c = a[0], d = 0; d < b.length; d++)
      c += encodeURIComponent(b[d]) + a[d + 1];
    return Ha(c);
  }
  var Ja = ma(["https://tpc.googlesyndication.com/sodar/", ".js"]),
    Ka = ma(["https://ep2.adtrafficquality.google/sodar/", ".js"]),
    La = ma(["https://www.google.com/recaptcha/api2/aframe"]);
  Ia(La);
  var Ma = Aa(610401301, !1),
    Na = Aa(748402147, !0);
  function Oa() {
    var a = I.navigator;
    return a && (a = a.userAgent) ? a : "";
  }
  var Pa,
    Qa = I.navigator;
  Pa = Qa ? Qa.userAgentData || null : null;
  var Ra =
    Ma && Pa && Pa.brands.length > 0
      ? !1
      : Oa().indexOf("Trident") != -1 || Oa().indexOf("MSIE") != -1;
  function Sa(a, b) {
    if (b instanceof Ga) b = b.h;
    else throw Error("");
    a.src = b;
    var c;
    b = a.ownerDocument;
    b = b === void 0 ? document : b;
    var d;
    b =
      (d = (c = b).querySelector) == null ? void 0 : d.call(c, "script[nonce]");
    (c = b == null ? "" : b.nonce || b.getAttribute("nonce") || "") &&
      a.setAttribute("nonce", c);
  }
  function Ta(a, b) {
    a.__closure__error__context__984382 ||
      (a.__closure__error__context__984382 = {});
    a.__closure__error__context__984382.severity = b;
  }
  function Ua(a, b) {
    typeof a.addEventListener === "function" &&
      a.addEventListener.call(a, "load", b, !1);
  }
  function Va(a) {
    var b = window,
      c = !0;
    c = c === void 0 ? !1 : c;
    new r.Promise(function (d, e) {
      function g() {
        f.onload = null;
        f.onerror = null;
        var h;
        (h = f.parentElement) == null || h.removeChild(f);
      }
      var f = b.document.createElement("script");
      f.onload = function () {
        g();
        d();
      };
      f.onerror = function () {
        g();
        e(void 0);
      };
      f.type = "text/javascript";
      Sa(f, a);
      c && b.document.readyState !== "complete"
        ? Ua(b, function () {
            b.document.body.appendChild(f);
          })
        : b.document.body.appendChild(f);
    });
  }
  var J = {},
    Wa =
      ((J["internal-error"] = -1),
      (J["non-recoverable-error"] = -2),
      (J["api-disabled-by-application"] = -3),
      (J["invalid-argument"] = -4),
      (J["token-provider-invalid"] = -5),
      J);
  function Xa() {
    this.G = !1;
  }
  var Ya;
  function Za() {
    Ya || (Ya = new Xa());
    return Ya;
  }
  function $a(a) {
    var b;
    H(function (c) {
      if (c.h == 1)
        return (
          c.F(2),
          c.j(
            window.android.webview.getExperimentalMediaIntegrityTokenProvider({
              cloudProjectNumber: 187810013193,
            }),
            4
          )
        );
      if (c.h != 2) return (a.i = c.o), (a.h = void 0), c.D(0);
      b = c.C();
      a.h = ab(b);
      c.N();
    });
  }
  function ab(a) {
    if (!a || typeof a !== "object") return -100;
    var b = a.mediaIntegrityErrorName;
    if (typeof b === "string") {
      var c;
      return (c = Wa[b]) != null ? c : -100;
    }
    a = a.code;
    if (typeof a === "function")
      try {
        return a();
      } catch (d) {}
    return -100;
  }
  function bb(a) {
    var b, c, d, e, g, f, h, k, l, m, q;
    return H(function (n) {
      switch (n.h) {
        case 1:
          return (
            (b = a.K
              ? "https://ep1.adtrafficquality.google/getconfig/sodar"
              : "https://pagead2.googlesyndication.com/getconfig/sodar"),
            (c = a.l ? "&sde=1" : ""),
            (d = a.L ? "&sjk=" + a.L : ""),
            (e = a.h === "cr" && a.J === "env" ? a.h + "_" + a.J : a.J),
            (g =
              b + "?sv=200&tid=" + a.i + ("&tv=" + a.j + "&st=") + e + d + c),
            (f = void 0),
            n.F(2),
            n.j(cb(g), 4)
          );
        case 4:
          f = n.o;
          n.D(3);
          break;
        case 2:
          n.C();
        case 3:
          if (!f || a.o) return n.return(void 0);
          h = a.L || f.sodar_query_id;
          k = f.rc_enable !== void 0 && a.m ? f.rc_enable : "n";
          l = f.bg_snapshot_delay_ms === void 0 ? "0" : f.bg_snapshot_delay_ms;
          m = f.is_gen_204 === void 0 ? "1" : f.is_gen_204;
          return h && f.bg_hash_basename && f.bg_binary
            ? ((q = {
                context: a.h,
                qa: f.bg_hash_basename,
                pa: f.bg_binary,
                ta: a.i + "_" + a.j,
                L: h,
                J: a.J,
                T: k,
                U: l,
                S: m,
                K: a.K,
                O: a.O,
              }),
              a.G
                ? n.return(u(Object, "assign").call(Object, {}, q, { G: !0 }))
                : n.return(q))
            : n.return(void 0);
      }
    });
  }
  function cb(a) {
    return new r.Promise(function (b, c) {
      var d = new XMLHttpRequest();
      d.onreadystatechange = function () {
        d.readyState === d.DONE &&
          (d.status >= 200 && d.status < 300
            ? b(
                u(Object, "assign").call(
                  Object,
                  Object.create(null),
                  JSON.parse(d.responseText)
                )
              )
            : c());
      };
      d.open("GET", a, !0);
      d.send();
    });
  }
  function db(a) {
    var b;
    return H(function (c) {
      if (c.h == 1) {
        if (a.G) {
          Za().G = !0;
          var d = Za();
          window.android &&
            window.android.webview &&
            window.android.webview.getExperimentalMediaIntegrityTokenProvider &&
            d.G &&
            $a(d);
        }
        return c.j(bb(a), 2);
      }
      if ((b = c.o)) {
        d = b;
        var e = "sodar2";
        e = e === void 0 ? "sodar2" : e;
        var g = window,
          f = g.GoogleGcLKhOms;
        (f && typeof f.push === "function") || (f = g.GoogleGcLKhOms = []);
        var h = {};
        h =
          ((h._ctx_ = d.context),
          (h._bgv_ = d.qa),
          (h._bgp_ = d.pa),
          (h._li_ = d.ta),
          (h._jk_ = d.L),
          (h._st_ = d.J),
          (h._rc_ = d.T),
          (h._dl_ = d.U),
          (h._g2_ = d.S),
          (h._atqg_ = d.K ? "1" : "0"),
          (h._sic_ = d.O ? "1" : "0"),
          h);
        d.G && (h._wvp_ = "1");
        f.push(h);
        if ((f = g.GoogleDX5YKUSkRag)) {
          if (f.length > 0 && (g = f.shift()))
            try {
              g();
            } catch (k) {}
        } else if ((f = g.GoogleDX5YKUSk)) (g.GoogleDX5YKUSk = void 0), f[1]();
        d = d.K ? Ia(Ka, e) : Ia(Ja, e);
        Va(d);
      }
      return c.return(b);
    });
  }
  function K() {
    throw Error("Invalid UTF8");
  }
  function eb(a, b) {
    b = String.fromCharCode.apply(null, b);
    return a == null ? b : a + b;
  }
  var fb = void 0,
    gb,
    hb = typeof TextDecoder !== "undefined";
  function ib(a) {
    I.setTimeout(function () {
      throw a;
    }, 0);
  }
  var jb = {},
    kb = null;
  function lb(a) {
    var b = a.length,
      c = (b * 3) / 4;
    c % 3
      ? (c = Math.floor(c))
      : "=.".indexOf(a[b - 1]) != -1 &&
        (c = "=.".indexOf(a[b - 2]) != -1 ? c - 2 : c - 1);
    var d = new Uint8Array(c),
      e = 0;
    mb(a, function (g) {
      d[e++] = g;
    });
    return e !== c ? d.subarray(0, e) : d;
  }
  function mb(a, b) {
    function c(k) {
      for (; d < a.length; ) {
        var l = a.charAt(d++),
          m = kb[l];
        if (m != null) return m;
        if (!/^[\s\xa0]*$/.test(l))
          throw Error("Unknown base64 encoding at char: " + l);
      }
      return k;
    }
    nb();
    for (var d = 0; ; ) {
      var e = c(-1),
        g = c(0),
        f = c(64),
        h = c(64);
      if (h === 64 && e === -1) break;
      b((e << 2) | (g >> 4));
      f != 64 &&
        (b(((g << 4) & 240) | (f >> 2)), h != 64 && b(((f << 6) & 192) | h));
    }
  }
  function nb() {
    if (!kb) {
      kb = {};
      for (
        var a =
            "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(
              ""
            ),
          b = ["+/=", "+/", "-_=", "-_.", "-_"],
          c = 0;
        c < 5;
        c++
      ) {
        var d = a.concat(b[c].split(""));
        jb[c] = d;
        for (var e = 0; e < d.length; e++) {
          var g = d[e];
          kb[g] === void 0 && (kb[g] = e);
        }
      }
    }
  }
  var ob = typeof Uint8Array !== "undefined",
    pb = !Ra && typeof btoa === "function",
    qb = /[-_.]/g,
    rb = { "-": "+", _: "/", ".": "=" };
  function sb(a) {
    return rb[a] || "";
  }
  function tb(a) {
    if (!pb) return lb(a);
    a = qb.test(a) ? a.replace(qb, sb) : a;
    a = atob(a);
    for (var b = new Uint8Array(a.length), c = 0; c < a.length; c++)
      b[c] = a.charCodeAt(c);
    return b;
  }
  var ub = {};
  function L(a, b) {
    vb(b);
    this.h = a;
    if (a != null && a.length === 0)
      throw Error("ByteString should be constructed with non-empty values");
  }
  var wb;
  function vb(a) {
    if (a !== ub) throw Error("illegal external caller");
  }
  var xb = void 0;
  function yb(a, b) {
    if (a != null) {
      var c;
      var d = (c = xb) != null ? c : (xb = {});
      c = d[a] || 0;
      c >= b || ((d[a] = c + 1), (a = Error()), Ta(a, "incident"), ib(a));
    }
  }
  var zb =
    typeof r.Symbol === "function" && typeof (0, r.Symbol)() === "symbol";
  function Ab(a, b, c) {
    return typeof r.Symbol === "function" && typeof (0, r.Symbol)() === "symbol"
      ? (c === void 0 ? 0 : c) && r.Symbol.for && a
        ? r.Symbol.for(a)
        : a != null
        ? (0, r.Symbol)(a)
        : (0, r.Symbol)()
      : b;
  }
  var Bb = Ab("jas", void 0, !0),
    M = Ab(void 0, (0, r.Symbol)()),
    Cb = Ab(void 0, "0ubs"),
    Db = Ab(void 0, "0actk"),
    Eb = Ab("m_m", "va", !0);
  var Fb = { ra: { value: 0, configurable: !0, writable: !0, enumerable: !1 } },
    Gb = Object.defineProperties,
    N = zb ? Bb : "ra";
  function Hb(a, b) {
    zb || N in a || Gb(a, Fb);
    a[N] |= b;
  }
  function O(a, b) {
    zb || N in a || Gb(a, Fb);
    a[N] = b;
  }
  var Ib = {};
  function P(a, b) {
    return b === void 0
      ? a.h !== Q && !!(2 & (a.u[N] | 0))
      : !!(2 & b) && a.h !== Q;
  }
  var Q = {};
  function Jb(a, b, c) {
    var d = b & 128 ? 0 : -1,
      e = a.length,
      g;
    if ((g = !!e))
      (g = a[e - 1]),
        (g = g != null && typeof g === "object" && g.constructor === Object);
    var f = e + (g ? -1 : 0);
    for (b = b & 128 ? 1 : 0; b < f; b++) c(b - d, a[b]);
    if (g) {
      a = a[e - 1];
      for (var h in a)
        Object.prototype.hasOwnProperty.call(a, h) && !isNaN(h) && c(+h, a[h]);
    }
  }
  var Kb = {};
  var Lb = typeof I.BigInt === "function" && typeof I.BigInt(0) === "bigint";
  var Mb = u(Number, "MIN_SAFE_INTEGER").toString(),
    Nb = Lb ? BigInt(u(Number, "MIN_SAFE_INTEGER")) : void 0,
    Ob = u(Number, "MAX_SAFE_INTEGER").toString(),
    Pb = Lb ? BigInt(u(Number, "MAX_SAFE_INTEGER")) : void 0;
  function Qb(a, b) {
    if (a.length > b.length) return !1;
    if (a.length < b.length || a === b) return !0;
    for (var c = 0; c < a.length; c++) {
      var d = a[c],
        e = b[c];
      if (d > e) return !1;
      if (d < e) return !0;
    }
  }
  var Rb = typeof Uint8Array.prototype.slice === "function";
  var Sb = u(Number, "isFinite");
  function Tb(a) {
    if (!Sb(a)) throw ((a = Error("enum")), Ta(a, "warning"), a);
    return a | 0;
  }
  function Ub(a) {
    return a;
  }
  function Vb(a) {
    var b = Ca(M);
    return b ? a[b] : void 0;
  }
  function Wb() {}
  function Xb(a, b) {
    for (var c in a)
      Object.prototype.hasOwnProperty.call(a, c) && !isNaN(c) && b(a, +c, a[c]);
  }
  function Yb(a) {
    var b = new Wb();
    Xb(a, function (c, d, e) {
      b[d] = Array.prototype.slice.call(e);
    });
    b.h = a.h;
    return b;
  }
  function Zb(a, b) {
    b < 100 || yb(Cb, 1);
  }
  function $b(a, b, c, d) {
    var e = d !== void 0;
    d = !!d;
    var g = Ca(M),
      f;
    !e && zb && g && (f = a[g]) && Xb(f, Zb);
    g = [];
    var h = a.length;
    f = 4294967295;
    var k = !1,
      l = !!(b & 64),
      m = l ? (b & 128 ? 0 : -1) : void 0;
    if (!(b & 1)) {
      var q = h && a[h - 1];
      q != null && typeof q === "object" && q.constructor === Object
        ? (h--, (f = h))
        : (q = void 0);
      if (l && !(b & 128) && !e) {
        k = !0;
        var n;
        f = ((n = ac) != null ? n : Ub)(f - m, m, a, q, void 0) + m;
      }
    }
    b = void 0;
    for (n = 0; n < h; n++) {
      var t = a[n];
      if (t != null && (t = c(t, d)) != null)
        if (l && n >= f) {
          var x = n - m,
            v = void 0;
          ((v = b) != null ? v : (b = {}))[x] = t;
        } else g[n] = t;
    }
    if (q)
      for (var B in q)
        Object.prototype.hasOwnProperty.call(q, B) &&
          ((h = q[B]),
          h != null &&
            (h = c(h, d)) != null &&
            ((n = +B),
            (t = void 0),
            l && !u(Number, "isNaN").call(Number, n) && (t = n + m) < f
              ? (g[t] = h)
              : ((n = void 0), (((n = b) != null ? n : (b = {}))[B] = h))));
    b && (k ? g.push(b) : (g[f] = b));
    e && Ca(M) && (a = Vb(a)) && a instanceof Wb && (g[M] = Yb(a));
    return g;
  }
  function bc(a) {
    switch (typeof a) {
      case "number":
        return u(Number, "isFinite").call(Number, a) ? a : "" + a;
      case "bigint":
        return (Lb ? a >= Nb && a <= Pb : a[0] === "-" ? Qb(a, Mb) : Qb(a, Ob))
          ? Number(a)
          : "" + a;
      case "boolean":
        return a ? 1 : 0;
      case "object":
        if (Array.isArray(a)) {
          var b = a[N] | 0;
          return a.length === 0 && b & 1 ? void 0 : $b(a, b, bc);
        }
        if (a != null && a[Eb] === Ib) return cc(a);
        if (a instanceof L) {
          b = a.h;
          if (b == null) a = "";
          else if (typeof b === "string") a = b;
          else {
            if (pb) {
              for (var c = "", d = 0, e = b.length - 10240; d < e; )
                c += String.fromCharCode.apply(
                  null,
                  b.subarray(d, (d += 10240))
                );
              c += String.fromCharCode.apply(null, d ? b.subarray(d) : b);
              b = btoa(c);
            } else {
              c === void 0 && (c = 0);
              nb();
              c = jb[c];
              d = Array(Math.floor(b.length / 3));
              e = c[64] || "";
              for (var g = 0, f = 0; g < b.length - 2; g += 3) {
                var h = b[g],
                  k = b[g + 1],
                  l = b[g + 2],
                  m = c[h >> 2];
                h = c[((h & 3) << 4) | (k >> 4)];
                k = c[((k & 15) << 2) | (l >> 6)];
                l = c[l & 63];
                d[f++] = m + h + k + l;
              }
              m = 0;
              l = e;
              switch (b.length - g) {
                case 2:
                  (m = b[g + 1]), (l = c[(m & 15) << 2] || e);
                case 1:
                  (b = b[g]),
                    (d[f] = c[b >> 2] + c[((b & 3) << 4) | (m >> 4)] + l + e);
              }
              b = d.join("");
            }
            a = a.h = b;
          }
          return a;
        }
        return;
    }
    return a;
  }
  var ac;
  function cc(a) {
    a = a.u;
    return $b(a, a[N] | 0, bc);
  }
  var dc, ec;
  function fc(a) {
    switch (typeof a) {
      case "boolean":
        return dc || (dc = [0, void 0, !0]);
      case "number":
        return a > 0
          ? void 0
          : a === 0
          ? ec || (ec = [0, void 0])
          : [-a, void 0];
      case "string":
        return [0, a];
      case "object":
        return a;
    }
  }
  function hc(a, b) {
    return ic(a, b[0], b[1]);
  }
  function ic(a, b, c, d) {
    d = d === void 0 ? 0 : d;
    if (a == null) {
      var e = 32;
      c ? ((a = [c]), (e |= 128)) : (a = []);
      b && (e = (e & -16760833) | ((b & 1023) << 14));
    } else {
      if (!Array.isArray(a)) throw Error("narr");
      e = a[N] | 0;
      if (Na && 1 & e) throw Error("rfarr");
      2048 & e && !(2 & e) && jc();
      if (e & 256) throw Error("farr");
      if (e & 64) return (e | d) !== e && O(a, e | d), a;
      if (c && ((e |= 128), c !== a[0])) throw Error("mid");
      a: {
        c = a;
        e |= 64;
        var g = c.length;
        if (g) {
          var f = g - 1,
            h = c[f];
          if (h != null && typeof h === "object" && h.constructor === Object) {
            b = e & 128 ? 0 : -1;
            f -= b;
            if (f >= 1024) throw Error("pvtlmt");
            for (var k in h)
              Object.prototype.hasOwnProperty.call(h, k) &&
                ((g = +k), g < f && ((c[g + b] = h[k]), delete h[k]));
            e = (e & -16760833) | ((f & 1023) << 14);
            break a;
          }
        }
        if (b) {
          k = Math.max(b, g - (e & 128 ? 0 : -1));
          if (k > 1024) throw Error("spvt");
          e = (e & -16760833) | ((k & 1023) << 14);
        }
      }
    }
    O(a, e | 64 | d);
    return a;
  }
  function jc() {
    if (Na) throw Error("carr");
    yb(Db, 5);
  }
  function kc(a, b) {
    if (typeof a !== "object") return a;
    if (Array.isArray(a)) {
      var c = a[N] | 0;
      a.length === 0 && c & 1
        ? (a = void 0)
        : c & 2 ||
          (!b || 4096 & c || 16 & c
            ? (a = lc(a, c, !1, b && !(c & 16)))
            : (Hb(a, 34), c & 4 && Object.freeze(a)));
      return a;
    }
    if (a != null && a[Eb] === Ib)
      return (
        (b = a.u),
        (c = b[N] | 0),
        P(a, c) ? a : mc(a, b, c) ? nc(a, b) : lc(b, c)
      );
    if (a instanceof L) return a;
  }
  function nc(a, b, c) {
    a = new a.constructor(b);
    c && (a.h = Q);
    a.i = Q;
    return a;
  }
  function lc(a, b, c, d) {
    d != null || (d = !!(34 & b));
    a = $b(a, b, kc, d);
    d = 32;
    c && (d |= 2);
    b = (b & 16769217) | d;
    O(a, b);
    return a;
  }
  function oc(a) {
    if (a.h !== Q) return !1;
    var b = a.u;
    b = lc(b, b[N] | 0);
    Hb(b, 2048);
    a.u = b;
    a.h = void 0;
    a.i = void 0;
    return !0;
  }
  function pc(a) {
    if (!oc(a) && P(a, a.u[N] | 0)) throw Error();
  }
  function wc(a, b) {
    b === void 0 && (b = a[N] | 0);
    b & 32 && !(b & 4096) && O(a, b | 4096);
  }
  function mc(a, b, c) {
    return c & 2
      ? !0
      : c & 32 && !(c & 4096)
      ? (O(b, c | 2), (a.h = Q), !0)
      : !1;
  }
  function xc(a, b) {
    a = yc(a.u, b);
    if (a !== null) return a;
  }
  function yc(a, b, c, d) {
    if (b === -1) return null;
    var e = b + (c ? 0 : -1),
      g = a.length - 1;
    if (!(g < 1 + (c ? 0 : -1))) {
      if (e >= g) {
        var f = a[g];
        if (f != null && typeof f === "object" && f.constructor === Object) {
          c = f[b];
          var h = !0;
        } else if (e === g) c = f;
        else return;
      } else c = a[e];
      if (d && c != null) {
        d = d(c);
        if (d == null) return d;
        if (!u(Object, "is").call(Object, d, c))
          return h ? (f[b] = d) : (a[e] = d), d;
      }
      return c;
    }
  }
  function R(a, b, c, d, e) {
    var g = c + (e ? 0 : -1),
      f = a.length - 1;
    if (f >= 1 + (e ? 0 : -1) && g >= f) {
      var h = a[f];
      if (h != null && typeof h === "object" && h.constructor === Object)
        return (h[c] = d), b;
    }
    if (g <= f) return (a[g] = d), b;
    if (d !== void 0) {
      var k;
      f = (((k = b) != null ? k : (b = a[N] | 0)) >> 14) & 1023 || 536870912;
      c >= f
        ? d != null && ((g = {}), (a[f + (e ? 0 : -1)] = ((g[c] = d), g)))
        : (a[g] = d);
    }
    return b;
  }
  function zc(a, b, c, d) {
    pc(a);
    var e = a.u;
    R(e, e[N] | 0, b, (d === "0" ? Number(c) === 0 : c === d) ? void 0 : c);
    return a;
  }
  function Ac(a, b, c) {
    var d = a[N] | 0,
      e = d & 128 ? Kb : void 0,
      g = yc(a, c, e);
    if (g != null && g[Eb] === Ib) {
      if (!P(g)) return oc(g), g.u;
      var f = g.u;
    } else Array.isArray(g) && (f = g);
    if (f) {
      var h = f[N] | 0;
      h & 2 && (f = lc(f, h));
    }
    f = hc(f, b);
    f !== g && R(a, d, c, f, e);
    return f;
  }
  function Bc(a, b, c) {
    var d = Cc,
      e = !1;
    c = yc(a, c, void 0, function (g) {
      if (g != null && g[Eb] === Ib) var f = g;
      else if (Array.isArray(g)) {
        f = g[N] | 0;
        var h = f | (b & 32);
        h |= b & 2;
        h !== f && O(g, h);
        f = new d(g);
      } else f = void 0;
      e = f !== g && f != null;
      return f;
    });
    if (c != null) return e && !P(c) && wc(a, b), c;
  }
  function Dc(a, b) {
    var c = a.u,
      d = c[N] | 0,
      e = Bc(c, d, b);
    if (e == null) return e;
    d = c[N] | 0;
    if (!P(a, d)) {
      var g = e;
      var f = g.u,
        h = f[N] | 0;
      g = P(g, h)
        ? mc(g, f, h)
          ? nc(g, f, !0)
          : new g.constructor(lc(f, h, !1))
        : g;
      g !== e &&
        (oc(a) && ((c = a.u), (d = c[N] | 0)),
        (e = g),
        (d = R(c, d, b, e)),
        wc(c, d));
    }
    return e;
  }
  function S(a, b) {
    var c = c === void 0 ? !1 : c;
    a = xc(a, b);
    a =
      a == null || typeof a === "boolean"
        ? a
        : typeof a === "number"
        ? !!a
        : void 0;
    return a != null ? a : c;
  }
  function Ec(a, b) {
    var c = c === void 0 ? "" : c;
    a = xc(a, b);
    a = a == null || typeof a === "string" ? a : void 0;
    return a != null ? a : c;
  }
  function Fc(a, b) {
    var c = c === void 0 ? 0 : c;
    a = xc(a, b);
    a = a == null ? a : Sb(a) ? a | 0 : void 0;
    return a != null ? a : c;
  }
  function T(a, b, c) {
    this.buffer = a;
    if (c && !b) throw Error();
    this.h = b;
  }
  function Gc(a, b) {
    if (typeof a === "string") return new T(tb(a), b);
    if (Array.isArray(a)) return new T(new Uint8Array(a), b);
    if (a.constructor === Uint8Array) return new T(a, !1);
    if (a.constructor === ArrayBuffer)
      return (a = new Uint8Array(a)), new T(a, !1);
    if (a.constructor === L)
      return (
        vb(ub),
        (b = a.h),
        (b =
          b == null || (ob && b != null && b instanceof Uint8Array)
            ? b
            : typeof b === "string"
            ? tb(b)
            : null),
        (b = (b == null ? b : (a.h = b)) || new Uint8Array(0)),
        new T(b, !0, a)
      );
    if (a instanceof Uint8Array)
      return (
        (a =
          a.constructor === Uint8Array
            ? a
            : new Uint8Array(a.buffer, a.byteOffset, a.byteLength)),
        new T(a, !1)
      );
    throw Error();
  }
  function Hc(a, b, c, d) {
    this.i = null;
    this.m = !1;
    this.h = this.j = this.l = 0;
    this.init(a, b, c, d);
  }
  Hc.prototype.init = function (a, b, c, d) {
    var e = d === void 0 ? {} : d;
    d = e.W;
    e = e.aa;
    e = e === void 0 ? !1 : e;
    this.W = d === void 0 ? !1 : d;
    this.aa = e;
    a &&
      ((a = Gc(a, this.aa)),
      (this.i = a.buffer),
      (this.m = a.h),
      (this.l = b || 0),
      (this.j = c !== void 0 ? this.l + c : this.i.length),
      (this.h = this.l));
  };
  Hc.prototype.clear = function () {
    this.i = null;
    this.m = !1;
    this.h = this.j = this.l = 0;
    this.W = !1;
  };
  function Ic(a, b) {
    a.h = b;
    if (b > a.j) throw Error();
  }
  function Jc(a) {
    var b = a.i,
      c = a.h,
      d = b[c++],
      e = d & 127;
    if (
      d & 128 &&
      ((d = b[c++]),
      (e |= (d & 127) << 7),
      d & 128 &&
        ((d = b[c++]),
        (e |= (d & 127) << 14),
        d & 128 &&
          ((d = b[c++]),
          (e |= (d & 127) << 21),
          d & 128 &&
            ((d = b[c++]),
            (e |= d << 28),
            d & 128 &&
              b[c++] & 128 &&
              b[c++] & 128 &&
              b[c++] & 128 &&
              b[c++] & 128 &&
              b[c++] & 128))))
    )
      throw Error();
    Ic(a, c);
    return e;
  }
  function Kc(a, b) {
    if (b < 0) throw Error();
    var c = a.h;
    b = c + b;
    if (b > a.j) throw Error();
    a.h = b;
    return c;
  }
  var Lc = [];
  var U = 0;
  function Mc(a, b, c, d) {
    if (Lc.length) {
      var e = Lc.pop();
      e.init(a, b, c, d);
      a = e;
    } else a = new Hc(a, b, c, d);
    this.h = a;
    this.l = this.h.h;
    this.i = this.j = -1;
    Nc(this, d);
  }
  function Nc(a, b) {
    b = (b === void 0 ? {} : b).ca;
    a.ca = b === void 0 ? !1 : b;
  }
  function Oc(a, b, c, d) {
    if (Pc.length) {
      var e = Pc.pop();
      Nc(e, d);
      e.h.init(a, b, c, d);
      return e;
    }
    return new Mc(a, b, c, d);
  }
  function Qc(a) {
    a.h.clear();
    a.j = -1;
    a.i = -1;
    Pc.length < 100 && Pc.push(a);
  }
  function Rc(a) {
    var b = a.h;
    if (b.h == b.j) return !1;
    a.l = a.h.h;
    var c = Jc(a.h) >>> 0;
    b = c >>> 3;
    c &= 7;
    if (!(c >= 0 && c <= 5)) throw Error();
    if (b < 1) throw Error();
    a.j = b;
    a.i = c;
    return !0;
  }
  function Sc() {
    if (U >= 100) throw new SyntaxError();
    U++;
  }
  function Tc(a) {
    try {
      switch (a.i) {
        case 0:
          if (a.i != 0) Tc(a);
          else
            a: {
              var b = a.h,
                c = b.h;
              a = c + 10;
              for (var d = b.i; c < a; )
                if ((d[c++] & 128) === 0) {
                  Ic(b, c);
                  break a;
                }
              throw Error();
            }
          break;
        case 1:
          var e = a.h;
          Ic(e, e.h + 8);
          break;
        case 2:
          if (a.i != 2) Tc(a);
          else {
            var g = Jc(a.h) >>> 0,
              f = a.h;
            Ic(f, f.h + g);
          }
          break;
        case 5:
          var h = a.h;
          Ic(h, h.h + 4);
          break;
        case 3:
          Sc();
          var k = a.j;
          try {
            do {
              if (!Rc(a)) throw Error();
              if (a.i == 4) {
                if (a.j != k) throw Error();
                break;
              }
              Tc(a);
            } while (1);
          } catch (l) {
            if (l instanceof RangeError) throw new SyntaxError();
            throw l;
          } finally {
            U > 0 && U--;
          }
          break;
        default:
          throw Error();
      }
    } catch (l) {
      if (l instanceof RangeError) throw new SyntaxError();
      throw l;
    }
  }
  function Uc(a, b, c) {
    var d = a.h.j,
      e = Jc(a.h) >>> 0;
    e = a.h.h + e;
    var g = e - d;
    g <= 0 && ((a.h.j = e), c(b, a, void 0, void 0, void 0), (g = e - a.h.h));
    if (g) throw Error();
    a.h.h = e;
    a.h.j = d;
  }
  var Pc = [];
  function Vc() {
    function a() {
      throw Error();
    }
    u(Object, "setPrototypeOf").call(Object, a, a.prototype);
    return a;
  }
  var Wc = Vc(),
    Xc = Vc();
  function Yc(a, b, c) {
    this.u = ic(a, b, c, 2048);
  }
  Yc.prototype.toJSON = function () {
    var a = cc(this);
    return a;
  };
  Yc.prototype[Eb] = Ib;
  function Zc(a, b) {
    this.h = a;
    a = Ca(Wc);
    this.i = (!!a && b === a) || !1;
  }
  function $c(a) {
    var b = b === void 0 ? Wc : b;
    return new Zc(a, b);
  }
  var ad = $c(function (a, b, c, d, e) {
      if (a.i !== 2) return !1;
      Uc(a, Ac(b, d, c), e);
      return !0;
    }),
    bd = $c(function (a, b, c, d, e) {
      if (a.i !== 2) return !1;
      Uc(a, Ac(b, d, c), e);
      return !0;
    }),
    cd = (0, r.Symbol)(),
    dd = (0, r.Symbol)(),
    ed = (0, r.Symbol)(),
    fd,
    gd;
  function hd(a) {
    var b = id,
      c = jd,
      d = a[cd];
    if (d) return d;
    d = {};
    d.oa = a;
    d.Y = fc(a[0]);
    var e = a[1],
      g = 1;
    e &&
      e.constructor === Object &&
      ((d.ea = e),
      (e = a[++g]),
      typeof e === "function" &&
        ((d.sa = !0),
        fd != null || (fd = e),
        gd != null || (gd = a[g + 1]),
        (e = a[(g += 2)])));
    for (
      var f = {};
      e && Array.isArray(e) && e.length && typeof e[0] === "number" && e[0] > 0;

    ) {
      for (var h = 0; h < e.length; h++) f[e[h]] = e;
      e = a[++g];
    }
    for (h = 1; e !== void 0; ) {
      typeof e === "number" && ((h += e), (e = a[++g]));
      var k = void 0;
      if (e instanceof Zc) var l = e;
      else (l = ad), g--;
      e = void 0;
      if ((e = l) == null ? 0 : e.i) {
        e = a[++g];
        k = a;
        var m = g;
        typeof e === "function" && ((e = e()), (k[m] = e));
        k = e;
      }
      e = a[++g];
      m = h + 1;
      typeof e === "number" && e < 0 && ((m -= e), (e = a[++g]));
      for (; h < m; h++) {
        var q = f[h];
        k ? c(d, h, l, k, q) : b(d, h, l, q);
      }
    }
    return (a[cd] = d);
  }
  function id(a, b, c, d) {
    var e = c.h;
    a[b] = d
      ? function (g, f, h) {
          return e(g, f, h, d);
        }
      : e;
  }
  function jd(a, b, c, d, e) {
    var g = c.h,
      f,
      h;
    a[b] = function (k, l, m) {
      return g(k, l, m, h || (h = hd(d).Y), f || (f = kd(d)), e);
    };
  }
  function kd(a) {
    var b = a[dd];
    if (b != null) return b;
    var c = hd(a);
    b = c.sa
      ? function (d, e) {
          return fd(d, e, c);
        }
      : function (d, e) {
          a: {
            Sc();
            try {
              for (; Rc(e) && e.i != 4; ) {
                var g = e.j,
                  f = c[g];
                if (f == null) {
                  var h = c.ea;
                  if (h) {
                    var k = h[g];
                    if (k) {
                      var l = ld(k);
                      l != null && (f = c[g] = l);
                    }
                  }
                }
                if (f == null || !f(e, d, g)) {
                  var m = e,
                    q = m.l;
                  Tc(m);
                  var n = void 0,
                    t = void 0;
                  if (m.ca) var x = void 0;
                  else {
                    var v = m.h.h - q;
                    m.h.h = q;
                    var B = m.h;
                    if (v == 0) t = wb || (wb = new L(null, ub));
                    else {
                      var y = Kc(B, v);
                      if (B.W && B.m) n = B.i.subarray(y, y + v);
                      else {
                        var G = B.i;
                        m = y + v;
                        n =
                          y === m
                            ? new Uint8Array(0)
                            : Rb
                            ? G.slice(y, m)
                            : new Uint8Array(G.subarray(y, m));
                      }
                      t =
                        n.length == 0
                          ? wb || (wb = new L(null, ub))
                          : new L(n, ub);
                    }
                    x = t;
                  }
                  m = n = t = void 0;
                  var qc = d,
                    rc = g,
                    sc = x;
                  sc &&
                    ((t = (n = (m = qc[M]) != null ? m : (qc[M] = new Wb()))[
                      rc
                    ]) != null
                      ? t
                      : (n[rc] = [])
                    ).push(sc);
                }
              }
              var tc = Vb(d);
              tc && (tc.h = c.oa[ed]);
              var uc = !0;
              break a;
            } catch (vc) {
              if (vc instanceof RangeError) throw new SyntaxError();
              throw vc;
            } finally {
              U > 0 && U--;
            }
            uc = void 0;
          }
          return uc;
        };
    a[dd] = b;
    a[ed] = md.bind(a);
    return b;
  }
  function md(a, b, c, d) {
    var e = this[cd],
      g = this[dd],
      f = hc(void 0, e.Y),
      h = Vb(a);
    if (h) {
      var k = !1,
        l = e.ea;
      if (l) {
        e = function (x, v, B) {
          if (B.length !== 0)
            if (l[v]) {
              x = C(B);
              v = x.next();
              var y;
              try {
                for (; !v.done; v = x.next()) {
                  var G = Oc(v.value);
                  try {
                    (k = !0), g(f, G);
                  } finally {
                    Qc(G);
                  }
                }
              } finally {
                v && !v.done && (y = x.return) && y.call(x);
              }
            } else d == null || d(a, v, B);
        };
        if (b == null) Xb(h, e);
        else if (h != null) {
          var m = h[b];
          m && e(h, b, m);
        }
        if (k) {
          var q = a[N] | 0;
          if (q & 2 && q & 2048 && (c == null || !c.xa)) throw Error();
          var n = q & 128 ? Kb : void 0,
            t = function (x, v) {
              if (yc(a, x, n) != null)
                switch (c == null ? void 0 : c.wa) {
                  case 1:
                    return;
                  default:
                    throw Error();
                }
              v != null && (q = R(a, q, x, v, n));
              delete h[x];
            };
          b == null
            ? Jb(f, f[N] | 0, function (x, v) {
                t(x, v);
              })
            : t(b, yc(f, b, n));
        }
      }
    }
  }
  function ld(a) {
    a = Array.isArray(a) ? (a[0] instanceof Zc ? a : [bd, a]) : [a, void 0];
    var b = a[0].h;
    if ((a = a[1])) {
      var c = kd(a),
        d = hd(a).Y;
      return function (e, g, f) {
        return b(e, g, f, d, c);
      };
    }
    return b;
  }
  var nd;
  nd = new Zc(function (a, b, c) {
    if (a.i !== 2) return !1;
    var d,
      e = Jc(a.h) >>> 0;
    a = a.h;
    var g = Kc(a, e);
    a = a.i;
    if (hb) {
      var f = a;
      (d = gb) || (d = gb = new TextDecoder("utf-8", { fatal: !0 }));
      e = g + e;
      f = g === 0 && e === f.length ? f : f.subarray(g, e);
      try {
        var h = d.decode(f);
      } catch (q) {
        if (fb === void 0) {
          try {
            d.decode(new Uint8Array([128]));
          } catch (n) {}
          try {
            d.decode(new Uint8Array([97])), (fb = !0);
          } catch (n) {
            fb = !1;
          }
        }
        !fb && (gb = void 0);
        throw q;
      }
    } else {
      h = g;
      e = h + e;
      g = [];
      for (var k = null, l, m; h < e; )
        (l = a[h++]),
          l < 128
            ? g.push(l)
            : l < 224
            ? h >= e
              ? K()
              : ((m = a[h++]),
                l < 194 || (m & 192) !== 128
                  ? (h--, K())
                  : g.push(((l & 31) << 6) | (m & 63)))
            : l < 240
            ? h >= e - 1
              ? K()
              : ((m = a[h++]),
                (m & 192) !== 128 ||
                (l === 224 && m < 160) ||
                (l === 237 && m >= 160) ||
                ((d = a[h++]) & 192) !== 128
                  ? (h--, K())
                  : g.push(((l & 15) << 12) | ((m & 63) << 6) | (d & 63)))
            : l <= 244
            ? h >= e - 2
              ? K()
              : ((m = a[h++]),
                (m & 192) !== 128 ||
                ((l << 28) + (m - 144)) >> 30 !== 0 ||
                ((d = a[h++]) & 192) !== 128 ||
                ((f = a[h++]) & 192) !== 128
                  ? (h--, K())
                  : ((l =
                      ((l & 7) << 18) |
                      ((m & 63) << 12) |
                      ((d & 63) << 6) |
                      (f & 63)),
                    (l -= 65536),
                    g.push(((l >> 10) & 1023) + 55296, (l & 1023) + 56320)))
            : K(),
          g.length >= 8192 && ((k = eb(k, g)), (g.length = 0));
      h = eb(k, g);
    }
    d = h;
    R(b, b[N] | 0, c, d === "" ? void 0 : d, (b[N] | 0) & 128 ? Kb : void 0);
    return !0;
  }, Xc);
  function Cc(a) {
    this.u = ic(a, void 0, void 0, 2048);
  }
  A(Cc, Yc);
  var od = [0, nd];
  function pd(a) {
    this.u = ic(a, void 0, void 0, 2048);
  }
  A(pd, Yc);
  function qd(a) {
    switch (a) {
      case 1:
        return "gda";
      case 2:
        return "gpt";
      case 3:
        return "ima";
      case 4:
        return "pal";
      case 5:
        return "xfad";
      case 6:
        return "dv3n";
      case 7:
        return "spa";
      case 8:
        return "afs";
      case 9:
        return "oos";
      default:
        return "unk";
    }
  }
  function rd(a) {
    this.i = a.l;
    this.j = a.m;
    this.h = a.o;
    this.L = a.L;
    this.J = a.J;
    this.T = a.T;
    this.U = a.U;
    this.S = a.S;
    this.m = a.i;
    this.K = a.K;
    this.G = a.G;
    this.l = a.h;
    this.O = a.O;
    this.o = a.j;
  }
  function sd(a, b, c) {
    this.l = a;
    this.m = b;
    this.o = c;
    this.v = window;
    this.J = "env";
    this.T = "n";
    this.U = "0";
    this.S = "1";
    this.i = !0;
    this.j = this.O = this.h = this.G = this.K = !1;
  }
  function td() {
    var a = this;
    this.promise = new r.Promise(function (b, c) {
      a.resolve = b;
      a.reject = c;
    });
  }
  function V(a) {
    a = Error.call(this, a);
    this.message = a.message;
    "stack" in a && (this.stack = a.stack);
    u(Object, "setPrototypeOf").call(Object, this, V.prototype);
    this.name = "InputError";
  }
  A(V, Error);
  function ud() {
    this.h = !1;
  }
  function W() {
    ud.apply(this, arguments);
    this.i = new td();
  }
  A(W, ud);
  function vd(a, b) {
    a.h || ((a.h = !0), (a.l = b), a.i.resolve(b));
  }
  p.Object.defineProperties(W.prototype, {
    promise: {
      configurable: !0,
      enumerable: !0,
      get: function () {
        return this.i.promise;
      },
    },
    ha: {
      configurable: !0,
      enumerable: !0,
      get: function () {
        return this.h;
      },
    },
    error: {
      configurable: !0,
      enumerable: !0,
      get: function () {
        return this.j;
      },
    },
  });
  function wd() {
    W.apply(this, arguments);
  }
  A(wd, W);
  function xd(a, b, c) {
    a.h || ((a.h = !0), (a.l = null), (a.j = b), c && c(a.j), a.i.reject(b));
  }
  function yd(a) {
    this.h = !1;
    this.i = a;
  }
  A(yd, ud);
  p.Object.defineProperties(yd.prototype, {
    error: {
      configurable: !0,
      enumerable: !0,
      get: function () {
        return this.i.j;
      },
    },
  });
  yd.prototype.ha = function () {
    return this.i.h;
  };
  function zd(a) {
    yd.call(this, a);
    this.i = a;
  }
  A(zd, yd);
  p.Object.defineProperties(zd.prototype, {
    value: {
      configurable: !0,
      enumerable: !0,
      get: function () {
        var a;
        return (a = this.i.l) != null ? a : null;
      },
    },
  });
  function Ad() {
    W.apply(this, arguments);
  }
  A(Ad, W);
  Ad.prototype.notify = function () {
    vd(this, null);
  };
  function Bd(a) {
    a && typeof a.dispose == "function" && a.dispose();
  }
  function X() {
    this.h = this.h;
    this.j = this.j;
  }
  X.prototype.h = !1;
  X.prototype.dispose = function () {
    this.h || ((this.h = !0), this.m());
  };
  X.prototype[u(r.Symbol, "dispose")] = function () {
    this.dispose();
  };
  function Cd(a, b) {
    a.h ? b() : (a.j || (a.j = []), a.j.push(b));
  }
  X.prototype.m = function () {
    if (this.j) for (; this.j.length; ) this.j.shift()();
  };
  function Dd() {
    X.apply(this, arguments);
    this.l = [];
    this.i = [];
    this.o = [];
  }
  A(Dd, X);
  Dd.prototype.P = function (a) {
    var b = u(this.i, "find").call(this.i, function (c) {
      return c.X === a;
    });
    b && (b.P = !0);
  };
  Dd.prototype.m = function () {
    this.l.length = 0;
    this.o.length = 0;
    this.i.length = 0;
    X.prototype.m.call(this);
  };
  function Ed(a, b) {
    var c, d;
    return H(function (e) {
      if (e.h == 1)
        return (
          (c = b
            ? a.filter(function (g) {
                return !g.P;
              })
            : a),
          e.j(
            r.Promise.all(
              c.map(function (g) {
                return g.X.promise;
              })
            ),
            2
          )
        );
      if (a.length === c.length) return e.return();
      d = a.filter(function (g) {
        return g.P;
      });
      return e.j(
        r.Promise.race([
          r.Promise.all(
            d.map(function (g) {
              return g.X.promise;
            })
          ),
          new r.Promise(function (g) {
            return void setTimeout(g, b);
          }),
        ]),
        0
      );
    });
  }
  function Y(a, b, c) {
    X.call(this);
    this.id = a;
    this.v = b;
    this.F = c;
    this.C = !1;
    this.i = new Dd();
    Cd(this, Ba(Bd, this.i));
  }
  A(Y, X);
  Y.prototype.start = function () {
    var a = this,
      b,
      c;
    return H(function (d) {
      if (d.h == 1) {
        if (a.C) return d.return();
        a.C = !0;
        d.F(2);
        return d.j(Ed(a.i.i, (b = a.H) != null ? b : a.F), 4);
      }
      if (d.h != 2) {
        if (!a.h) {
          var e = 0,
            g = C(a.i.o),
            f = g.next(),
            h;
          try {
            for (; !f.done; f = g.next()) {
              if (f.value.i.l == null)
                throw Error("missing input: " + a.id + "/" + e);
              ++e;
            }
          } finally {
            f && !f.done && (h = g.return) && h.call(g);
          }
          e = a.f;
          g = e.apply;
          f = {};
          h = C(u(Object, "entries").call(Object, a.inputs));
          var k = h.next(),
            l;
          try {
            for (; !k.done; k = h.next()) {
              var m = C(k.value),
                q = m.next().value,
                n = m.next().value;
              f[q] = n.value;
            }
          } finally {
            k && !k.done && (l = h.return) && l.call(h);
          }
          l = g.call(e, a, [f].concat(la(a.D)));
          a.o(l);
        }
        return d.D(0);
      }
      c = d.C();
      if (a.h) return d.return();
      c instanceof V
        ? a.A(c)
        : c instanceof Error && (a.v.ga({ methodName: a.id, ba: c }), a.l(c));
      d.N();
    });
  };
  function Fd(a, b) {
    b = b === void 0 ? new wd() : b;
    a.i.l.push(b);
    return b;
  }
  Y.prototype.A = function () {};
  Y.prototype.l = function (a) {
    if (this.i.l.length) {
      var b = new V(a.message),
        c = C(this.i.l),
        d = c.next(),
        e;
      try {
        for (; !d.done; d = c.next()) {
          var g = d.value;
          if (!g.ha) {
            var f = g,
              h = b;
            f.h = !0;
            f.j = h;
            f.i.reject(h);
          }
        }
      } finally {
        d && !d.done && (e = c.return) && e.call(c);
      }
    }
    if (!(a instanceof V)) {
      var k;
      (k = console) == null || k.error(a);
    }
  };
  function Z(a, b, c, d, e) {
    Y.call(this, a, c);
    this.f = b;
    this.D = e;
    a = {};
    d = C(u(Object, "entries").call(Object, d));
    b = d.next();
    var g;
    try {
      for (; !b.done; b = d.next()) {
        var f = C(b.value),
          h = f.next().value,
          k = f.next().value;
        k && (this.i.i.push({ P: !1, X: k }), (a[h] = new zd(k)));
      }
    } finally {
      b && !b.done && (g = d.return) && g.call(d);
    }
    this.inputs = a;
  }
  A(Z, Y);
  Z.prototype.A = function (a) {
    this.l(a);
  };
  function Gd(a, b, c, d, e, g) {
    Z.call(this, a, b, c, d, g);
    this.B = e;
    this.output = Fd(this, new wd());
    this.complete = new Ad();
  }
  A(Gd, Z);
  Gd.prototype.o = function (a) {
    var b = this;
    a.then(
      function (c) {
        vd(b.output, c);
        b.complete.notify();
      },
      function (c) {
        b.B
          ? vd(b.output, b.B(c))
          : xd(b.output, new V("output error: " + c.message), function () {
              b.v.ga({ methodName: b.id, ba: c });
            });
        b.complete.notify();
      }
    );
  };
  Gd.prototype.l = function (a) {
    this.B
      ? (vd(this.output, this.B(a)), this.complete.notify())
      : Z.prototype.l.call(this, a);
  };
  function Hd(a, b, c) {
    return new Gd(a.id, a, b, c, a.B, xa.apply(3, arguments));
  }
  function Id(a, b) {
    return H(function (c) {
      var d = c.return,
        e = window;
      var g = new pd();
      g = zc(g, 4, Tb(1), 0);
      g = zc(g, 2, Tb(6), 0);
      if (b != null && typeof b !== "string") throw Error();
      g = zc(g, 3, b, "");
      var f = a.ua;
      f == null && (f = void 0);
      var h = f;
      pc(g);
      var k = g.u;
      R(k, k[N] | 0, 5, h);
      f && !P(f) && wc(g.u);
      g = zc(g, 6, !0, !1);
      h = S(g, 6) === void 0 ? !0 : S(g, 6);
      var l, m;
      f = qd(Fc(g, 2));
      k = Ec(g, 3);
      a: switch (Fc(g, 4)) {
        case 1:
          var q = "pt";
          break a;
        case 2:
          q = "cr";
          break a;
        default:
          q = "";
      }
      f = new sd(f, k, q);
      k = (m = (l = Dc(g, 5)) == null ? void 0 : Ec(l, 1)) != null ? m : "";
      f.L = k;
      f.i = h;
      l = !!S(g, 7);
      f.K = l;
      l = !!S(g, 8);
      f.G = l;
      l = !!S(g, 9);
      f.h = l;
      l = !!S(g, 10);
      f.j = l;
      f.v = e;
      return d.call(c, db(new rd(f)));
    });
  }
  var Jd = { id: 900 };
  Id.id = Jd.id;
  Id.B = Jd.B;
  function Kd(a) {
    this.u = ic(a, void 0, void 0, 2048);
  }
  A(Kd, Yc);
  var Ld = (function (a, b) {
    return function (c, d) {
      a: {
        var e = { aa: !0 };
        d && u(Object, "assign").call(Object, e, d);
        c = Oc(c, void 0, void 0, e);
        try {
          var g = new a(),
            f = g.u;
          kd(b)(f, c);
          var h = g;
          break a;
        } catch (k) {
          if (k instanceof RangeError) throw new SyntaxError();
          throw k;
        } finally {
          Qc(c);
        }
        h = void 0;
      }
      return h;
    };
  })(Kd, [0, od]);
  function Md(a, b, c, d, e, g, f) {
    Z.call(this, a, b, c, d, f);
    this.B = g;
    this.finished = new Ad();
    a = u(Object, "keys").call(Object, e);
    a = C(a);
    b = a.next();
    var h;
    try {
      for (; !b.done; b = a.next()) this[b.value] = Fd(this);
    } finally {
      b && !b.done && (h = a.return) && h.call(a);
    }
  }
  A(Md, Z);
  Md.prototype.o = function (a) {
    a = C(u(Object, "entries").call(Object, a));
    var b = a.next(),
      c;
    try {
      for (; !b.done; b = a.next()) {
        var d = C(b.value),
          e = d.next().value,
          g = d.next().value,
          f = e,
          h = g;
        h instanceof Error && xd(this[f], h);
        vd(this[f], h);
      }
    } finally {
      b && !b.done && (c = a.return) && c.call(a);
    }
    this.finished.notify();
  };
  Md.prototype.l = function (a) {
    this.B ? this.o(this.B(a)) : Z.prototype.l.call(this, a);
  };
  function Nd(a, b, c) {
    return new Md(a.id, a, b, c, a.Z, a.B, xa.apply(3, arguments));
  }
  function Od(a, b) {
    a = b.indexOf("#");
    b = Ld(a === -1 ? "" : b.substring(a + 1));
    b = Dc(b, 1);
    return { ia: b != null ? b : null };
  }
  var Pd = { id: 899, Z: { ia: void 0 } };
  Od.id = Pd.id;
  Od.Z = Pd.Z;
  Od.B = Pd.B;
  function Qd(a, b) {
    var c = c === void 0 ? {} : c;
    this.error = a;
    this.meta = c;
    this.context = b.context;
    this.msg = b.message || "";
    this.id = b.id || "jserror";
  }
  var Rd = ma(["https://pagead2.googlesyndication.com/pagead/js/err_rep.js"]);
  function Sd() {
    var a = a === void 0 ? "jserror" : a;
    var b = b === void 0 ? 0.01 : b;
    var c = c === void 0 ? Ia(Rd) : c;
    this.h = a;
    this.i = b;
    this.j = c;
  }
  function Td(a, b, c, d, e) {
    d = d === void 0 ? a.i : d;
    e = e === void 0 ? a.h : e;
    if (Math.random() > d) return !1;
    (c.error && c.meta && c.id) || (c = new Qd(c, { context: b, id: e }));
    I.google_js_errors = I.google_js_errors || [];
    I.google_js_errors.push(c);
    I.error_rep_loaded ||
      ((c = b = I.document),
      (c = c === void 0 ? document : c),
      (c = c.createElement("script")),
      Sa(c, a.j),
      (a = b.getElementsByTagName("script")[0]) &&
        a.parentNode &&
        a.parentNode.insertBefore(c, a),
      (I.error_rep_loaded = !0));
    return !1;
  }
  function Ud(a) {
    X.call(this);
    this.C = a;
    this.A = [];
    this.D = [];
    this.v = {};
    this.l = [];
    this.i = new td();
    this.o = {};
  }
  A(Ud, X);
  function Vd(a, b) {
    Cd(a, Ba(Bd, b));
    a.A.push(b);
    return b;
  }
  Ud.prototype.H = function (a, b) {
    return Vd(
      this,
      Nd.apply(null, [a, this.C, b].concat(la(xa.apply(2, arguments))))
    );
  };
  Ud.prototype.F = function (a, b) {
    Vd(this, Hd.apply(null, [a, this.C, b].concat(la(xa.apply(2, arguments)))));
  };
  function Wd(a) {
    var b, c, d, e, g, f, h, k, l, m, q, n, t, x, v, B;
    H(function (y) {
      switch (y.h) {
        case 1:
          if (!a.l.length) {
            y.I(2);
            break;
          }
          return y.j(
            r.Promise.all(
              a.l.map(function (G) {
                return G.i.promise;
              })
            ),
            2
          );
        case 2:
          return y.j(Xd(), 4);
        case 4:
          b = y.o;
          if (!b) return a.i.resolve(a.v), y.return(a.i.promise);
          c = C(a.A);
          d = c.next();
          try {
            for (; !d.done; d = c.next()) (g = d.value), g.start();
          } finally {
            d && !d.done && (e = c.return) && e.call(c);
          }
          f = C(a.D);
          h = f.next();
          try {
            for (; !h.done; h = f.next()) (l = h.value), Wd(l);
          } finally {
            h && !h.done && (k = f.return) && k.call(f);
          }
          if (!a.o) {
            y.I(5);
            break;
          }
          m = u(Object, "keys").call(Object, a.o);
          if (!m.length) {
            y.I(5);
            break;
          }
          return y.j(
            r.Promise.all(
              u(Object, "values")
                .call(Object, a.o)
                .map(function (G) {
                  return G.promise;
                })
            ),
            7
          );
        case 7:
          q = y.o;
          n = 0;
          t = C(m);
          x = t.next();
          try {
            for (; !x.done; x = t.next()) (B = x.value), (a.v[B] = q[n++]);
          } finally {
            x && !x.done && (v = t.return) && v.call(t);
          }
        case 5:
          return a.i.resolve(a.v), y.return(a.i.promise);
      }
    });
  }
  function Xd() {
    return H(function (a) {
      return a.return(!0);
    });
  }
  Ud.prototype.m = function () {
    X.prototype.m.call(this);
    this.A.length = 0;
    this.D.length = 0;
    this.l.length = 0;
  };
  var Yd = function () {
      var a,
        b,
        c =
          (b = (a = document.currentScript) == null ? void 0 : a.src) != null
            ? b
            : "";
      if (c) {
        var d = new Sd();
        a = new Ud({
          ga: function (e) {
            var g = e.ba;
            g = g instanceof Error ? g : Error(String(g));
            var f;
            Td(d, (f = e.methodName) != null ? f : 0, g);
            var h, k;
            (h = window.console) == null ||
              (k = h.error) == null ||
              k.call(h, g);
          },
        });
        c = a.H(Od, {}, c).ia;
        a.F(Id, { ua: c }, "m202609280201");
        Wd(a);
      }
    },
    Zd = new Sd();
  try {
    Yd();
  } catch (a) {
    if (!Td(Zd, 897, a, Zd.i, Zd.h)) throw a;
  }
}.call(this));
