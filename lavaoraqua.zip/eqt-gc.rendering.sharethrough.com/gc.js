(function () {
  "use strict";
  var $n = document.createElement("style");
  ($n.textContent = `@charset "UTF-8";@import"https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap";@import"https://fonts.googleapis.com/css2?family=Inter:wght@100..900&family=Roboto:wght@300;500;700&display=swap";._green-pmp-icon_gf0hn_1{height:13px;width:13px}._green-pmp-container_gf0hn_5{cursor:pointer;padding-right:1px}._opt-out-icon_by4l6_1,._opt-out-icon-equativ_by4l6_1{height:13px;width:13px;background-size:13px 13px;background-repeat:no-repeat;margin:1px 2px 1px 4px}._opt-out-icon-equativ_by4l6_1{margin:0}._opt-out-container_by4l6_11{cursor:pointer;background-color:#ffffffb3;display:flex;flex-direction:row-reverse;height:fit-content}._opt-out-container_by4l6_11:hover ._opt-out-label_by4l6_18{display:block}._opt-out-label_by4l6_18{margin-left:9px;font-size:11px;font-family:arial;font-weight:regular;line-height:14px;display:none}.str-buttons-container{position:absolute;z-index:7;display:flex;right:0;top:0}.str-buttons-container.bottom{bottom:0;top:unset}.str-amazon-advertiser-container{width:100%}.str-amazon-advertiser-container.str-advertiser-container{position:absolute;inset:auto auto 3px 1em;justify-content:flex-start}@container amazon-native-container (max-aspect-ratio: 4){.str-amazon-advertiser-container.str-advertiser-container{left:auto;right:1em;justify-content:flex-end}}@container amazon-native-container (max-aspect-ratio: 1.5){.str-amazon-advertiser-container.str-advertiser-container{right:auto;justify-content:center}}@container amazon-native-container (max-width: 320px) and (max-height: 50px){.str-amazon-advertiser-container.str-advertiser-container{position:absolute;display:none}}.str-amazon-advertiser-container.str-advertiser-container .str-amazon-advertiser{flex:0;text-wrap:nowrap}.str-amazon-advertiser-container.str-advertiser-pull-right{right:0;left:auto}@container amazon-native-container (max-aspect-ratio: 1.5){.str-amazon-body{margin-bottom:clamp(4px,1cqw + 1cqh,8px)}}@font-face{font-family:Amazon Ember;src:url(https://m.media-amazon.com/images/G/01/AUIClients/AmazonUIFont-amazonember_rg-cc7ebaa05a2cd3b02c0929ac0475a44ab30b7efa._V2_.woff2) format("woff2"),url(https://m.media-amazon.com/images/G/01/AUIClients/AmazonUIFont-amazonember_rg-8a9db402d8966ae93717c348b9ab0bd08703a7a7._V2_.woff) format("woff")}@font-face{font-family:Amazon Ember;font-style:italic;src:url(https://m.media-amazon.com/images/G/01/AUIClients/AmazonUIFont-amazonember_rgit-9cc1bb64eb270135f1adf3a4881c2ee5e7c37be5._V2_.woff2) format("woff2"),url(https://m.media-amazon.com/images/G/01/AUIClients/AmazonUIFont-amazonember_rgit-a4dc98d644ff2aedd41da3da462f09ffce86eafb._V2_.woff) format("woff")}@font-face{font-family:Amazon Ember;font-weight:700;src:url(https://m.media-amazon.com/images/G/01/AUIClients/AmazonUIFont-amazonember_bd-46b91bda68161c14e554a779643ef4957431987b._V2_.woff2) format("woff2"),url(https://m.media-amazon.com/images/G/01/AUIClients/AmazonUIFont-amazonember_bd-b605252f87b8b3df5ae206596dac0938fc5888bc._V2_.woff) format("woff")}@font-face{font-family:Amazon Ember;font-style:italic;font-weight:700;src:url(https://m.media-amazon.com/images/G/01/AUIClients/AmazonUIFont-amazonember_bdit-80ff7aba37dd1ff5a6b90233a19e3a780a96dc2f._V2_.woff2) format("woff2"),url(https://m.media-amazon.com/images/G/01/AUIClients/AmazonUIFont-amazonember_bdit-57598ce426a612be5a1d15eee08252668fca5e7a._V2_.woff) format("woff")}.str-amazon-native-container{height:100%;width:100%;container-type:size;container-name:amazon-native-container}.str-amazon-native-container .str-amazon-native{display:flex;align-items:center;font-family:Amazon Ember,arial,sans-serif;color:#0f1111;height:100%;width:100%;box-sizing:border-box;cursor:pointer;padding:clamp(4px,1.5cqw + 1.5cqh,10px);font-size:clamp(12px,1cqw + 4cqh,16px);gap:min(4px,clamp(4px,1cqw + 1cqh,8px))}@container amazon-native-container (max-aspect-ratio: 3.5){.str-amazon-native-container .str-amazon-native{gap:clamp(4px,1cqw + 1cqh,8px)}}@container amazon-native-container (max-aspect-ratio: 1.5){.str-amazon-native-container .str-amazon-native{flex-direction:column;font-size:clamp(12px,3.5cqw + 1.5cqh,16px)}}.str-amazon-native-container .str-amazon-native .str-amazon-body{flex:3;display:flex;flex-direction:column;gap:min(4px,clamp(4px,1cqw + 1cqh,8px))}@container amazon-native-container (max-aspect-ratio: 3.5){.str-amazon-native-container .str-amazon-native .str-amazon-body{gap:clamp(4px,1cqw + 1cqh,8px)}}@container amazon-native-container (max-width: 320px) and (max-height: 100px){.str-amazon-native-container .str-amazon-native .str-amazon-body{gap:2px}}.str-amazon-native-container .str-amazon-native .str-amazon-body .str-amazon-product-image,.str-amazon-native-container .str-amazon-native .str-amazon-body .str-amazon-brand-logo,.str-amazon-native-container .str-amazon-native .str-amazon-body .str-amazon-title,.str-amazon-native-container .str-amazon-native .str-amazon-body .str-amazon-rating{flex:0}.str-amazon-native-container .str-amazon-native .str-amazon-body .str-amazon-price-cta{width:100%;display:flex;gap:min(4px,clamp(4px,1cqw + 1cqh,8px));flex-direction:row;align-items:center;justify-content:flex-start}@container amazon-native-container (max-aspect-ratio: 3.5){.str-amazon-native-container .str-amazon-native .str-amazon-body .str-amazon-price-cta{gap:clamp(4px,1cqw + 1cqh,8px);flex-direction:column;align-items:flex-start}}@container amazon-native-container (max-aspect-ratio: 1.5){.str-amazon-native-container .str-amazon-native .str-amazon-body .str-amazon-price-cta{flex-direction:row;align-items:center}}@container amazon-native-container (max-aspect-ratio: .8){.str-amazon-native-container .str-amazon-native .str-amazon-body .str-amazon-price-cta{flex-direction:column;justify-content:space-between}}@container amazon-native-container (max-aspect-ratio: 3.5){.str-amazon-native-container .str-amazon-native .str-amazon-body{align-items:flex-start;justify-content:center;height:100%}}@container amazon-native-container (max-aspect-ratio: 1.5){.str-amazon-native-container .str-amazon-native .str-amazon-body{flex:0 1 content;align-items:flex-start;justify-content:flex-end}}@container amazon-native-container (max-aspect-ratio: .8){.str-amazon-native-container .str-amazon-native .str-amazon-body{align-items:center}}@container amazon-native-container (max-width: 320px) and (max-height: 100px){.str-amazon-native-container .str-amazon-native .str-amazon-body{align-items:flex-end}}.str-amazon-badge{display:flex;flex-wrap:wrap;row-gap:4px;column-gap:6px;align-items:center}.str-amazon-badge-label{display:inline-block;min-width:fit-content;line-height:12px;border-radius:2px;padding:4px 6px;font-weight:400}.str-amazon-badge-label-text,.str-amazon-badge-messaging-text{font-size:12px!important;line-height:16px!important}@container amazon-native-container (max-width: 320px) and (max-height: 100px){.str-amazon-badge{display:none}}@container amazon-native-container (min-width: 728px) and (max-height: 90px){.str-amazon-badge{display:none}}@container amazon-native-container (max-width: 200px){.str-amazon-badge{display:none}}.str-amazon-prime-logo{flex:1;min-width:50px;max-width:3.5em;min-height:1em;width:auto;margin-left:.5em;background-size:contain;background-repeat:no-repeat;background-position:center}@container amazon-native-container (max-aspect-ratio: .375){.str-amazon-prime-logo{margin-left:0;margin-right:0;margin-top:.5em}}.str-amazon-coupon-container{display:flex;flex-direction:row;flex-wrap:wrap;width:100%}.str-amazon-coupon-container .str-amazon-coupon{color:#c45500;text-align:start;font-size:1.35em}@container amazon-native-container (max-aspect-ratio: .8){.str-amazon-coupon-container{justify-content:center}.str-amazon-coupon-container .str-amazon-coupon{text-align:center}}.str-amazon-native.str-amazon-native-coupon .str-amazon-body .str-amazon-description.str-amazon-description-multiline{-webkit-line-clamp:6}@container amazon-native-container (max-width: 320px) and (max-height: 50px){.str-amazon-native.str-amazon-native-coupon .str-amazon-body .str-amazon-description.str-amazon-description-multiline{-webkit-line-clamp:1}}.str-amazon-cta{font-family:Amazon Ember,arial,sans-serif;width:fit-content;inset:0;cursor:pointer;display:flex;justify-content:center;align-items:center;text-decoration:none;color:#0f1111;box-sizing:border-box;box-shadow:#d5d9d980 0 2px 5px;border-radius:20px;min-height:31px;padding:1px 16px;gap:10px;border:1px solid;margin-left:auto}@container amazon-native-container (max-aspect-ratio: 4){.str-amazon-cta{margin-left:0}}@container amazon-native-container (max-aspect-ratio: 1.5){.str-amazon-cta{margin-left:auto}}@container amazon-native-container (max-aspect-ratio: .8){.str-amazon-cta{margin-left:0}}.str-amazon-cta.str-amazon-cta-shop-now{background:#ffa41c;border-color:#ff8f00}.str-amazon-cta.str-amazon-cta-add-to-cart{background:#ffd814;border-color:#fcd200}.str-amazon-cta div{cursor:pointer;white-space:nowrap;font-weight:400;font-style:normal;color:#0f1111;text-align:center;font-family:Amazon Ember;font-size:13px}.str-amazon-native:hover .str-amazon-cta-shop-now{background:#fa8900;border-color:#f78307}.str-amazon-native:hover .str-amazon-cta-add-to-cart{background:#f7ca00;border-color:#f2c200}@container amazon-native-container (max-width: 320px) and (max-height: 100px){.str-amazon-cta{display:none}}@container amazon-native-container (max-width: 160px) and (min-height: 600px){.str-amazon-cta{width:100%;max-width:150px}}.str-amazon-description{display:-webkit-box;-webkit-box-orient:vertical;word-break:break-word;overflow:hidden;text-align:start;font-size:1em;line-height:1.3em;-webkit-line-clamp:1}.str-amazon-description.str-amazon-description-multiline{-webkit-line-clamp:1}@container amazon-native-container (max-aspect-ratio: 4){.str-amazon-description.str-amazon-description-multiline{-webkit-line-clamp:3}}@container amazon-native-container (max-aspect-ratio: 1.5){.str-amazon-description{-webkit-line-clamp:2}.str-amazon-description.str-amazon-description-multiline{-webkit-line-clamp:3}}@container amazon-native-container (max-aspect-ratio: .8){.str-amazon-description{text-align:center;-webkit-line-clamp:3}.str-amazon-description.str-amazon-description-multiline{-webkit-line-clamp:4}}@container amazon-native-container (max-height: 250px) and (max-width: 300px){.str-amazon-description{-webkit-line-clamp:1}}@container amazon-native-container (max-width: 320px) and (max-height: 100px){.str-amazon-description{-webkit-line-clamp:2}.str-amazon-description.str-amazon-description-multiline{-webkit-line-clamp:1}}@container amazon-native-container (max-width: 320px) and (max-height: 50px){.str-amazon-description,.str-amazon-description.str-amazon-description-multiline{-webkit-line-clamp:1}}.str-amazon-price-container{flex:0 0 content;display:flex;flex-wrap:wrap;column-gap:min(4px,clamp(4px,1cqw + 1cqh,8px))}.str-amazon-price-container .str-amazon-price{display:flex;flex-direction:row;color:#0f1111;font-size:2em}.str-amazon-price-container .str-amazon-price span{flex:1}.str-amazon-price-container .str-amazon-price .str-amazon-price-currency{font-size:13px;line-height:16px;margin-top:.25em}.str-amazon-price-container .str-amazon-price .str-amazon-price-whole{line-height:1em}.str-amazon-price-container .str-amazon-price .str-amazon-price-fraction{font-size:13px;line-height:16px;margin-top:.25em}.str-amazon-price-container .str-amazon-price-sale{text-decoration:line-through;color:#565959;align-self:center;text-align:start;font-size:14px;line-height:20px}@container amazon-native-container (max-width: 250px) and (max-height: 250px){.str-amazon-price-container .str-amazon-price-sale{position:absolute;display:none}}@container amazon-native-container (max-aspect-ratio: 4){.str-amazon-price-container{column-gap:clamp(4px,1cqw + 1cqh,8px)}}@container amazon-native-container (max-aspect-ratio: .375){.str-amazon-price-container{justify-content:center}}@container amazon-native-container (max-width: 320px) and (max-height: 100px){.str-amazon-price-container{width:100%}.str-amazon-price-container .str-amazon-prime-logo{margin-right:.5em}}.str-amazon-rating-container{overflow:hidden;display:flex;flex-direction:row;flex:0 0 auto;width:100%}@container amazon-native-container (max-aspect-ratio: .8){.str-amazon-rating-container{justify-content:center;flex-wrap:wrap}}.str-amazon-rating-container .str-amazon-rating{flex:1;display:flex}@container amazon-native-container (max-aspect-ratio: 4){.str-amazon-rating-container .str-amazon-rating{display:flex;position:relative;align-items:center;justify-content:center;flex-direction:row}}.str-amazon-rating-container .str-amazon-rating .str-amazon-rating-stars{display:flex;flex-wrap:nowrap}.str-amazon-rating-container .str-amazon-rating .str-amazon-rating-stars svg{height:clamp(14px,1.5em,20px);width:clamp(14px,1.5em,20px)}.str-amazon-rating-container .str-amazon-rating .str-amazon-rating-count{flex:0 0 auto;font-family:Amazon Ember,arial,sans-serif;color:#565959;overflow:hidden;padding-left:4px;text-align:start;font-size:1em;line-height:1.5em;margin:auto 0}@container amazon-native-container (max-width: 320px) and (max-height: 50px){.str-amazon-rating-container{position:absolute;display:none}}@container amazon-native-container (max-width: 320px) and (max-height: 100px){.str-amazon-rating-container .str-amazon-rating{display:flex;position:relative}}.str-amazon-review{display:-webkit-box;-webkit-box-orient:vertical;-webkit-line-clamp:2;overflow:hidden;margin:0 auto;padding:.25em 0;border-top:1px solid rgb(221,221,221);quotes:"“" "”";font-size:1em;text-align:left;text-decoration:none;color:inherit;width:100%}@container amazon-native-container (max-aspect-ratio: 1.5){.str-amazon-review{text-align:center}}.str-amazon-review:before{content:open-quote}.str-amazon-review:after{content:close-quote}@container amazon-native-container (max-height: 50px){.str-amazon-review{display:none}}.str-amazon-available-logo{display:non;flex:1;background-size:contain;background-position:center;background-repeat:no-repeat;max-height:75%;max-width:75%;width:100%;height:100%;align-self:center}.str-amazon-brand-logo{flex:1;background-size:contain;background-position:center;background-repeat:no-repeat;max-height:75%;max-width:75%;width:100%;height:100%;align-self:center}.str-amazon-headline{display:flex;justify-content:center;align-items:center;overflow:hidden;text-align:center;font-style:italic;margin:auto;font-size:1.05em;flex:1}@container amazon-native-contaner (max-aspect-ratio: 1.5){.str-amazon-headline{flex:2}}@container amazon-native-container (max-width: 320px) and (max-height: 100px){.str-amazon-headline{position:absolute;display:none}}.str-amazon-thumbnail .str-amazon-product-image{flex:1;background-size:contain;background-position:center;background-repeat:no-repeat;height:100%;width:auto}@container amazon-native-container (max-aspect-ratio: 1.5){.str-amazon-thumbnail .str-amazon-product-image{width:100%;height:auto}}.str-amazon-thumbnail{flex:2;display:flex;justify-content:center;flex-direction:row;gap:clamp(4px,1cqw + 1cqh,8px);height:100%;width:auto;min-width:35%}@container amazon-native-container (max-width: 320px) and (max-height: 50px){.str-amazon-thumbnail{min-width:20%}}.str-amazon-thumbnail .str-amazon-thumbnail-brand{flex:2;display:flex;flex-direction:row;justify-content:center;gap:clamp(4px,1cqw + 1cqh,8px)}.str-amazon-thumbnail .str-amazon-thumbnail-brand .str-amazon-thumbnail-logo{flex:1;display:flex;justify-content:center;align-items:center}@container amazon-native-container (max-aspect-ratio: .8){.str-amazon-thumbnail .str-amazon-thumbnail-brand .str-amazon-thumbnail-logo{display:flex;position:relative}}.str-amazon-thumbnail .str-amazon-product-image{flex:1}@container amazon-native-container (max-aspect-ratio: 4){.str-amazon-thumbnail .str-amazon-product-image{flex:2}.str-amazon-thumbnail .str-amazon-thumbnail-brand{flex:1;flex-direction:column}}@container amazon-native-container (max-aspect-ratio: 1.5){.str-amazon-thumbnail{width:100%;height:auto}.str-amazon-thumbnail .str-amazon-product-image{flex:1}.str-amazon-thumbnail .str-amazon-thumbnail-brand{flex:1;flex-direction:column}}@container amazon-native-container (max-aspect-ratio: .8){.str-amazon-thumbnail{flex-direction:column}.str-amazon-thumbnail .str-amazon-thumbnail-brand{flex:1;flex-direction:column}.str-amazon-thumbnail .str-amazon-product-image{flex:2}.str-amazon-thumbnail .str-amazon-headline{display:block}}@container amazon-native-container (max-width: 320px) and (max-height: 100px){.str-amazon-thumbnail-brand{display:none!important}.str-amazon-thumbnail{flex:1}}.gc-price{display:inline-flex;align-items:flex-start;justify-content:center;gap:2px}.gc-price .gc-price-currency{font-size:1.25em;margin:auto 0;font-weight:400}.gc-price .gc-price-amount{font-size:1.5em;font-weight:600;letter-spacing:-1.5px}.gc-price .gc-price-decimal{font-size:.75em;font-weight:400}.gc-price .gc-price-currency,.gc-price .gc-price-amount,.gc-price .gc-price-decimal{overflow:unset}.gc-rating-stars{display:flex;gap:4px;font-size:1em}.gc-rating-stars .gc-star{position:relative;color:#d1d5db;text-shadow:0 1px 2px rgba(0,0,0,.08)}.gc-rating-stars .gc-star-full{background:linear-gradient(135deg,#fff9d6,#ffe27a 18%,#f6c344 35%,#ffd86b,#e0a215 65%,#b57400 85%,#7a4a00);-webkit-background-clip:text;-webkit-text-fill-color:transparent}.gc-rating-stars .gc-star-half:before{content:"★";position:absolute;left:0;top:0;width:50%;overflow:hidden;background:linear-gradient(135deg,#fff9d6,#ffe27a 18%,#f6c344 35%,#ffd86b,#e0a215 65%,#b57400 85%,#7a4a00);-webkit-background-clip:text;-webkit-text-fill-color:transparent}.gc-default-assets{display:flex;flex-direction:column;align-items:center;gap:.5em}.str-enhanced-description{font-size:.8em}.str-enhanced-description:hover{color:var(--hover-color)}.gc-description{font-weight:400;font-size:clamp(12px,4cqw + 2cqh,16px)}.advertiser-container{display:flex;justify-content:center;gap:3px;font-weight:300;font-size:9px;line-height:11px;text-align:center;flex-wrap:wrap;align-items:baseline}.advertiser{font-weight:600;flex-grow:1}.brand-logo{width:auto;max-height:25px;object-fit:contain;display:block;flex-shrink:0}.str-ad-unit:hover .gc-cta{background-color:var(--cta-background-hover-color)!important;color:var(--cta-text-hover-color)!important}.gc-cta{font:500 12px Inter,sans-serif;border-radius:24px;align-self:unset;min-width:auto;line-height:12px;background-color:#25394a;color:#fff;display:block;padding:6px 12px;--cta-text-color: #fff;--cta-background-color: #25394a;--cta-text-hover-color: #fff;--cta-background-hover-color: #4bd1a6;--cta-border-width: unset;--cta-border-color: unset;--cta-border-style: unset;--cta-border-radius: 24px;background-color:var(--cta-background-color)!important;color:var(--cta-text-color)!important;border-width:var(--cta-border-width)!important;border-color:var(--cta-border-color)!important;border-style:var(--cta-border-style)!important;border-radius:var(--cta-border-radius)!important;white-space:nowrap;text-align:center}.gc-cta span{display:inline-block;width:fit-content}.str-enhancement-footer{z-index:2}.gc-bottom{display:flex;flex:0;gap:4px;align-items:end;flex-direction:row;justify-content:space-between}@container enhanced-info (max-width: 160px) and (max-height: 600px){.gc-bottom{flex-direction:column-reverse;align-items:center}}@container enhanced-info (max-height: 40px){.gc-bottom{display:none}}.str-isi-bundle-2{display:flex;overflow:hidden;flex-direction:column;font-family:arial,sans-serif;margin-top:.5em;height:100%}.str-isi-bundle-2 .str-isi-headline{font-size:14px;font-weight:700;text-transform:uppercase;padding:0 10px}.str-isi-bundle-2 .str-isi-text{overflow-y:scroll;height:auto;font-size:10px;line-height:12px;background-color:#fff;padding:0 10px}.str-enhanced-title{font-size:1em;transition:color .2s ease-in-out}.str-enhanced-title:hover{color:var(--hover-color)}.gc-title{font-weight:600;font-size:clamp(14px,6cqw + 2cqh,20px);align-content:center}@container enhanced-info (max-height: 75px){.gc-title span{font-size:.9em}}.str-enhanced-text{font-size:clamp(12px,4cqh + 4cqw,20px)}.gc-text{flex:1;display:flex;flex-direction:column;gap:4px;align-items:center}.gc-text>div{flex:1 1 auto;display:flex}.gc-text>div span{-webkit-box-orient:vertical;-webkit-line-clamp:1;display:-webkit-box;line-clamp:1;line-height:1.2em;overflow:hidden;text-align:center}.gc-text>div.gc-title{align-items:center}@container enhanced-info (min-width: 769px) and (max-width: 1440px) and (max-height: 1024px){.gc-text .gc-title span,.gc-text .gc-description span{-webkit-line-clamp:8;line-clamp:8}@container (max-height: 450px){.gc-text .gc-title span,.gc-text .gc-description span{-webkit-line-clamp:5;line-clamp:5}}@container (max-height: 250px){.gc-text .gc-title span,.gc-text .gc-description span{-webkit-line-clamp:4;line-clamp:4}}@container (max-height: 200px){.gc-default-assets{display:none!important}.gc-text .gc-title span,.gc-text .gc-description span{-webkit-line-clamp:3;line-clamp:3}}@container (max-height: 160px){.gc-text .gc-title span,.gc-text .gc-description span{-webkit-line-clamp:2;line-clamp:2}}@container (max-height: 100px){.gc-text .gc-title span,.gc-text .gc-description span{-webkit-line-clamp:1;line-clamp:1}}@container (max-height: 80px){.gc-text .gc-title span,.gc-text .gc-description span{-webkit-line-clamp:1;line-clamp:1}.gc-text .gc-description{display:none}}}@container enhanced-info (min-width: 481px) and (max-width: 768px) and (max-height: 1024px){.gc-text .gc-title span,.gc-text .gc-description span{-webkit-line-clamp:10;line-clamp:10}@container (max-height: 450px){.gc-text .gc-title span,.gc-text .gc-description span{-webkit-line-clamp:6;line-clamp:6}}@container (max-height: 300px){.gc-text .gc-title span{-webkit-line-clamp:5;line-clamp:5}.gc-text .gc-description span{-webkit-line-clamp:4;line-clamp:4}}@container (max-height: 250px){.gc-default-assets{flex-direction:row}.gc-text .gc-title span,.gc-text .gc-description span{-webkit-line-clamp:3;line-clamp:3}}@container (max-height: 200px){.gc-default-assets{display:none!important}.gc-text .gc-title span{-webkit-line-clamp:3;line-clamp:3}.gc-text .gc-description span{-webkit-line-clamp:2;line-clamp:2}}@container (max-height: 150px){.gc-text .gc-title span,.gc-text .gc-description span{-webkit-line-clamp:2;line-clamp:2}}@container (max-height: 110px){.gc-text .gc-title span{-webkit-line-clamp:2;line-clamp:2}.gc-text .gc-description span{-webkit-line-clamp:1;line-clamp:1}}@container (max-height: 100px){.gc-text .gc-title span,.gc-text .gc-description span{-webkit-line-clamp:1;line-clamp:1}}}@container enhanced-info (min-width: 361px) and (max-width: 480px) and (max-height: 1024px){.gc-text .gc-title span,.gc-text .gc-description span{-webkit-line-clamp:8;line-clamp:8}@container enhanced-info (max-height: 600px){.gc-text .gc-title span,.gc-text .gc-description span{-webkit-line-clamp:4;line-clamp:4}}@container (max-height: 220px){.gc-default-assets{display:none!important}.gc-text .gc-title span{-webkit-line-clamp:3;line-clamp:3}.gc-text .gc-description span{-webkit-line-clamp:2;line-clamp:2}}@container (max-height: 110px){.gc-text .gc-title span,.gc-text .gc-description span{-webkit-line-clamp:2;line-clamp:2}.gc-text .gc-description{display:none}}}@container enhanced-info (min-width: 301px) and (max-width: 360px) and (max-height: 600px){.gc-text .gc-title span{-webkit-line-clamp:5;line-clamp:5}.gc-text .gc-description span{-webkit-line-clamp:4;line-clamp:4}.gc-default-assets{flex-direction:row}@container (max-height: 250px){.gc-text .gc-title span,.gc-text .gc-description span{-webkit-line-clamp:4;line-clamp:4}}@container (max-height: 220px){.gc-text .gc-title span,.gc-text .gc-description span{-webkit-line-clamp:3;line-clamp:3}}@container (max-height: 180px){.gc-text .gc-title span,.gc-text .gc-description span{-webkit-line-clamp:2;line-clamp:2}.gc-default-assets{display:none!important}}@container (max-height: 120px){.gc-text .gc-title span{-webkit-line-clamp:2;line-clamp:2}.gc-text .gc-description span{-webkit-line-clamp:1;line-clamp:1}}@container (max-height: 100px){.gc-text .gc-description{display:none}}@container (max-height: 65px){.gc-text .gc-title span,.gc-text .gc-description span{-webkit-line-clamp:1;line-clamp:1}}}@container enhanced-info (min-width: 161px) and (max-width: 300px) and (max-height: 600px){.gc-text .gc-title span,.gc-text .gc-description span{-webkit-line-clamp:6;line-clamp:6}@container (max-height: 300px){.gc-text .gc-title span,.gc-text .gc-description span{-webkit-line-clamp:5;line-clamp:5}}@container (max-height: 250px){.gc-text .gc-title span{-webkit-line-clamp:4;line-clamp:4}.gc-text .gc-description span{-webkit-line-clamp:3;line-clamp:3}}@container (max-height: 200px){.gc-default-assets{display:none!important}.gc-text .gc-title span,.gc-text .gc-description span{-webkit-line-clamp:3;line-clamp:3}}@container (max-height: 150px){.gc-text .gc-title span{-webkit-line-clamp:3;line-clamp:3}.gc-text .gc-description span{-webkit-line-clamp:2;line-clamp:2}}@container (max-height: 120px){.gc-text .gc-title span{-webkit-line-clamp:2;line-clamp:2}.gc-text .gc-description span{-webkit-line-clamp:1;line-clamp:1}}@container (max-height: 100px){.gc-text .gc-title span,.gc-text .gc-description span{-webkit-line-clamp:2;line-clamp:2}.gc-text .gc-description{display:none}.gc-default-assets{flex-direction:row}}@container (max-height: 75px){.gc-text .gc-title span,.gc-text .gc-description span{-webkit-line-clamp:1;line-clamp:1}.gc-default-assets{display:none!important}}}@container enhanced-info (min-width: 121px) and (max-width: 160px) and (max-height: 600px){.gc-text .gc-title span,.gc-text .gc-description span{-webkit-line-clamp:9;line-clamp:9}@container (max-height: 450px){.gc-text .gc-title span,.gc-text .gc-description span{-webkit-line-clamp:8;line-clamp:8}}@container (max-height: 300px){.gc-text .gc-title span,.gc-text .gc-description span{-webkit-line-clamp:6;line-clamp:6}}@container (max-height: 150px){.gc-text .gc-title span,.gc-text .gc-description span{-webkit-line-clamp:2;line-clamp:2}.gc-default-assets{display:none!important}}}@container enhanced-info (max-width: 120px) and (max-height: 600px){.gc-text .gc-title span,.gc-text .gc-description span{-webkit-line-clamp:10;line-clamp:10}@container (max-height: 360px){.gc-text .gc-title span,.gc-text .gc-description span{-webkit-line-clamp:7;line-clamp:7}}@container (max-height: 250px){.gc-text .gc-title span,.gc-text .gc-description span{-webkit-line-clamp:4;line-clamp:4}.gc-default-assets{display:none!important}}@container (max-height: 150px){.gc-text .gc-title span{-webkit-line-clamp:3;line-clamp:3}.gc-text .gc-description span{-webkit-line-clamp:2;line-clamp:2}}@container (max-height: 140px){.gc-text .gc-description{display:none}}@container (max-height: 90px){.gc-text .gc-title span,.gc-text .gc-description span{-webkit-line-clamp:1;line-clamp:1}}}@container enhanced-info (max-height: 60px){.gc-text .gc-title span,.gc-text .gc-description span{-webkit-line-clamp:1;line-clamp:1}.gc-text .gc-description{display:none}}@container enhanced-info (max-height: 50px){.gc-text span{font-size:.85em}}@container enhanced-info (max-height: 20px){.gc-text{display:none}}@property --headlinePrimaryBgColor{syntax: "<color>"; inherits: true; initial-value: #2d2d2d;}@property --headlineSecondaryBgColor{syntax: "<color>"; inherits: true; initial-value: #fff;}@property --headlineTextColor{syntax: "<color>"; inherits: true; initial-value: #eeeeee;}.gc-enhancement-main-container{container-name:enhancement-container;container-type:size;overflow:hidden;display:flex}.gc-enhancement-main-container-banner-headline,.gc-enhancement-main-container-outstream-headline,.gc-enhancement-main-container-fallback{padding:0!important}.gc-enhancement-main-container-banner-headline .gc-enhancement-container,.gc-enhancement-main-container-outstream-headline .gc-enhancement-container,.gc-enhancement-main-container-fallback .gc-enhancement-container{padding:8px}.gc-enhancement-container{flex:1;display:flex;flex-direction:column}@container enhanced-info (max-height: 75px){.gc-enhancement-main-container-banner-headline .gc-enhancement-container,.gc-enhancement-main-container-outstream-headline .gc-enhancement-container{padding:4px}}.gc-exp-headline-alt{--headlinePrimaryBgColor: #2d2d2d;--headlineSecondaryBgColor: #fff;--headlineTextColor: #eeeeee;--aurora-delay-a: 0s;--aurora-delay-b: 0s;--aurora-p1x: 30%;--aurora-p1y: 40%;--aurora-p2x: 70%;--aurora-p2y: 60%;--aurora-p3x: 50%;--aurora-p3y: 50%;--aurora-edge1: 55%;--aurora-edge2: 50%;--aurora-edge3: 50%;--aurora-blur-a: 10px;--aurora-blur-b: 12px;position:relative;background:color-mix(in srgb,var(--headlinePrimaryBgColor) 85%,#000);color:var(--headlineTextColor);transition:--headlinePrimaryBgColor .6s ease,--headlineSecondaryBgColor .6s ease,--headlineTextColor .6s ease,color .6s ease}.gc-exp-headline-alt:before{content:"";position:absolute;inset:-25%;background:radial-gradient(circle at var(--aurora-p1x) var(--aurora-p1y),var(--headlinePrimaryBgColor) 0%,transparent var(--aurora-edge1)),radial-gradient(circle at var(--aurora-p2x) var(--aurora-p2y),color-mix(in srgb,var(--headlinePrimaryBgColor) 60%,var(--headlineSecondaryBgColor)) 0%,transparent var(--aurora-edge2));opacity:.9;animation:headline-aurora-a 18s cubic-bezier(.45,.05,.55,.95) infinite;animation-delay:var(--aurora-delay-a)}.gc-exp-headline-alt:after{content:"";position:absolute;inset:-25%;background:radial-gradient(circle at var(--aurora-p3x) var(--aurora-p3y),color-mix(in srgb,var(--headlineSecondaryBgColor) 35%,var(--headlinePrimaryBgColor)) 0%,transparent var(--aurora-edge3));opacity:.7;mix-blend-mode:screen;animation:headline-aurora-b 13s cubic-bezier(.45,.05,.55,.95) infinite;animation-delay:var(--aurora-delay-b)}@keyframes headline-aurora-a{0%{transform:translate(0) rotate(0) scale(1);filter:blur(var(--aurora-blur-a))}14%{transform:translate(22px,-14px) rotate(2deg) scale(1.06);filter:blur(calc(var(--aurora-blur-a) * 1.6))}28%{transform:translate(8px,-28px) rotate(-1.5deg) scale(.94);filter:blur(calc(var(--aurora-blur-a) * .5))}42%{transform:translate(-24px,-8px) rotate(-2.5deg) scale(1.08);filter:blur(calc(var(--aurora-blur-a) * 1.8))}57%{transform:translate(-16px,20px) rotate(1deg) scale(.93);filter:blur(calc(var(--aurora-blur-a) * .7))}71%{transform:translate(12px,26px) rotate(2.2deg) scale(1.04);filter:blur(calc(var(--aurora-blur-a) * 1.4))}85%{transform:translate(26px,6px) rotate(-1deg) scale(.96);filter:blur(calc(var(--aurora-blur-a) * .6))}to{transform:translate(0) rotate(0) scale(1);filter:blur(var(--aurora-blur-a))}}@keyframes headline-aurora-b{0%{transform:translate(0) scale(1) rotate(0);filter:blur(var(--aurora-blur-b))}12%{transform:translate(-18px,16px) scale(1.08) rotate(-1.5deg);filter:blur(calc(var(--aurora-blur-b) * .5))}25%{transform:translate(-28px,-6px) scale(.92) rotate(1deg);filter:blur(calc(var(--aurora-blur-b) * 1.7))}37%{transform:translate(-8px,-24px) scale(1.06) rotate(2.2deg);filter:blur(calc(var(--aurora-blur-b) * .6))}50%{transform:translate(20px,-18px) scale(.9) rotate(-.8deg);filter:blur(calc(var(--aurora-blur-b) * 1.5))}62%{transform:translate(28px,8px) scale(1.1) rotate(-2deg);filter:blur(calc(var(--aurora-blur-b) * .4))}75%{transform:translate(12px,24px) scale(.94) rotate(1.5deg);filter:blur(calc(var(--aurora-blur-b) * 1.8))}87%{transform:translate(-10px,14px) scale(1.03) rotate(-.5deg);filter:blur(calc(var(--aurora-blur-b) * .7))}to{transform:translate(0) scale(1) rotate(0);filter:blur(var(--aurora-blur-b))}}.gc-exp-headline-alt>.gc-enhancement-container{position:relative}.str-weather-container{container-type:size;container-name:weather-container;align-items:center;background-color:#eee;background-size:cover;background-position:center;background-repeat:no-repeat;border-radius:4px;display:flex;flex-direction:column;flex:1;font-weight:600;gap:.5em;justify-content:center;padding:10px;min-height:0}.str-weather-container .str-city{align-items:center;font-size:1em;display:flex;flex-direction:row}.str-weather-container .str-city .str-map-marker{width:1em;height:1em}.str-weather-container .str-forecast-icon{display:flex;align-items:center;gap:.75em}.str-weather-container .str-forecast{font-weight:600;font-size:.7em}.str-weather-container .str-forecast.str-forecast-condensed{text-align:left;flex-direction:column;font-size:1em;line-height:1.2em;display:none}.str-weather-container .str-forecast span{text-transform:capitalize;font-weight:400}.str-weather-container .str-forecast span.str-forecast-weekday{font-weight:600}.str-weather-container .str-information-container{display:flex;align-items:center;width:100%;justify-content:space-around}.str-weather-container .str-information-container .str-temperature{font-size:2.25em}.str-weather-container .str-information-container .str-information{font-size:1.5em}.str-weather-container .str-information-container .str-weather-icon{display:flex;height:2.25em;width:2.25em;align-items:center}.str-weather-container .str-information-container .str-temperature-variation{font-size:.7em;font-weight:500;gap:.4em;display:flex;flex-direction:column;justify-content:space-between}.str-weather-container .str-information-container .str-temperature-variation .str-temperature-high,.str-weather-container .str-information-container .str-temperature-variation .str-temperature-low{display:flex;align-items:center;gap:.4em}.str-weather-container .str-information-container .str-temperature-variation .str-temperature-high>span.icon,.str-weather-container .str-information-container .str-temperature-variation .str-temperature-low>span.icon{display:block;width:0;height:0;border-left:5px solid transparent;border-right:5px solid transparent;margin-right:5px}.str-weather-container .str-information-container .str-temperature-variation .str-temperature-high>span.icon.icon-up,.str-weather-container .str-information-container .str-temperature-variation .str-temperature-low>span.icon.icon-up{border-bottom:8px solid #fff}.str-weather-container .str-information-container .str-temperature-variation .str-temperature-high>span.icon.icon-down,.str-weather-container .str-information-container .str-temperature-variation .str-temperature-low>span.icon.icon-down{border-top:8px solid #fff}.str-weather-container .loading{background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEgAAABICAYAAABV7bNHAAADWklEQVR4Ae2cYW7aMBSAX0r4z26Q3oD+RAgYN1hPsPQELSegPcHgBKMn2G7ACEL8DDdobjAk+AeBvVc5U8aAOLGTONX7pCiRUWTnw1ix3zMWGMJ8Pn88Ho/PeLm2LGvS6XRewAAsMIDlcunsdru3eFkYhp/6/f4aSuYGDGC/3zunZbZtN8EAjBBkMiwoARaUAAtKgAUlwIISSCXI9/0GHVBRsrRfWhC96W42mzc8fnue9w0qBrb5O7VdtP9J9j4pQdPptIHTgBFeRvafqEKoCKKtbqxoSM8kc6/KGORWQdIZOYT0z0xKEM2JsAe9nvnIaEkX5AA+y1h2nifdg3q9npuXJJyLrfD0t8FYTyDKMnNFzis+i94xKCIvSfRt4uz9Di9/0nE4HO5VZvIJclxIQabljtlsNsE1m69nPpp0u90HKBGdcojM60EmStIth1BaMDNJUh5yCOUVxUuSsKyPy6a/oADwJfYzipielqvKIZTnYpcGbiwrdUqiQw6hbU0ae9IIe80jXWPjVti4OygQrN/H+puifi1ytENdnQ4oibLrZxiGYRiGYRgm4n0uRrGi7XabKt3Etu2g1WoFUAFUns/CuctQZHalJajVavftdltp7ThvRHKWDykiGTEGNyjHhWw4uLD+DIaDcijImXXpZXijcPOHBzvPmgRlSpakmzH6IB0+KQscBl4ojAQZwPWl8fsgjWFYBwclJ83NFLcyIclSBgozp815rNLzMQzDMAzDMMwHh8K+nud9gZLII/SsLdOe8nNECsoPSiSAgkExPtVPh87EUi2CTpOXKMuiyCQC6rUoJj4Z1ZZ9qyzoUmZXkeAXcm7WrUWSkqBraW9FZZcRVFdeKcqZE6jyyglUIY+cyUyCTJQToVtSakF5yVksFs0wDId42ajX6w8qISWdklIJyksOLYni2jG9GjiiiDLvb1WWPHVJkh6kxR4x97Rcx89KrBc7saKG6r55XdsmpPeL4em/CIax2aSCa5Ly2C/2T3c3XU7EFUlSSO8Xg1j8rCpyIoSkMV1TPA9PA+37xXBgG9EfjtBRJTkRtEeM2o7Bzlt6Ftn7bEhB1QNpWdrP++YTYEEJsKAEWFACLCgBFpSAKf9htjpTFoABGCFIvJ8MKBMs9qYbgAH8AQXRNaAq3gBaAAAAAElFTkSuQmCC);background-size:cover;background-position:center;background-repeat:no-repeat;width:2em;height:2em;animation:beat .5s infinite alternate}.str-weather-container-clear{background-image:url(https://cdn.rendering.sharethrough.com/weather-icons/clear.jpg)}.str-weather-container-rain,.str-weather-container-drizzle{background-image:url(https://cdn.rendering.sharethrough.com/weather-icons/rain.jpg)}.str-weather-container-clouds{background-image:url(https://cdn.rendering.sharethrough.com/weather-icons/clouds.jpg)}.str-weather-container-snow{background-image:url(https://cdn.rendering.sharethrough.com/weather-icons/snow.jpg)}.str-weather-container-thunderstorm{background-image:url(https://cdn.rendering.sharethrough.com/weather-icons/thunderstorm.jpg)}@container weather-container (max-width: 180px){.str-weather-container .str-information-container .str-forecast-icon .str-weather-icon{display:none!important}}@container weather-container (max-height: 50px){.str-weather-container .str-information-container .str-forecast.str-forecast-condensed .str-forecast-city{display:none}}@container weather-container (max-height: 150px){.str-weather-container .str-city,.str-weather-container .str-forecast:not(.str-forecast-condensed),.str-weather-container .str-temperature span{display:none}.str-weather-container .str-forecast.str-forecast-condensed{display:block}.str-weather-container .str-forecast.str-forecast-condensed .str-forecast-city{display:none}.str-weather-container .str-information-container{font-size:.75em;gap:.5em}.str-weather-container .str-information-container .str-forecast-icon{flex:1}.str-weather-container-main .str-forecast.str-forecast-condensed .str-forecast-city{display:block}}@container weather-information (max-height: 80px){.str-weather-container{display:none}.str-weather-container:nth-child(-n+1){display:flex}}@container weather-information (min-height:80px) and (max-height: 120px){.str-weather-container{display:none}.str-weather-container:nth-child(-n+2){display:flex}}@container weather-information (min-height:120px) and (max-height: 160px){.str-weather-container{display:none}.str-weather-container:nth-child(-n+3){display:flex}}@container weather-information (min-height:160px) and (max-height: 200px){.str-weather-container{display:none}.str-weather-container:nth-child(-n+4){display:flex}}@keyframes beat{to{opacity:.5}}.str-responsive-placement-widest.str-responsive-creative-wide .str-enhanced-info.weather .str-weather,.str-responsive-placement-widest.str-responsive-creative-square .str-enhanced-info.weather .str-weather,.str-responsive-placement-widest.str-responsive-creative-tall .str-enhanced-info.weather .str-weather,.str-responsive-placement-widest.str-responsive-creative-tallest .str-enhanced-info.weather .str-weather{flex-direction:row}.str-responsive-placement-widest.str-responsive-creative-wide .str-enhanced-info.weather .str-weather .str-weather-information,.str-responsive-placement-widest.str-responsive-creative-square .str-enhanced-info.weather .str-weather .str-weather-information,.str-responsive-placement-widest.str-responsive-creative-tall .str-enhanced-info.weather .str-weather .str-weather-information,.str-responsive-placement-widest.str-responsive-creative-tallest .str-enhanced-info.weather .str-weather .str-weather-information{flex:1}.str-enhanced-info.weather{container-type:size;container-name:weather;font-size:clamp(14px,28cqh,20px);display:flex;color:#fff!important;font-family:Roboto,sans-serif!important;min-height:0}.str-enhanced-info.weather .str-weather{display:flex;gap:8px;flex-direction:column;flex:1;min-height:0}.str-enhanced-info.weather .str-weather .str-weather-main{display:flex;flex:1;min-height:0}.str-enhanced-info.weather .str-weather .str-weather-information{container-type:size;container-name:weather-information;gap:8px;display:flex;flex-direction:column;flex:.5;min-height:0}@container weather (max-height: 80px){.str-weather .str-weather-information{display:none!important}}@container enhanced-info (max-height: 40px){.str-react-template .str-adunit .str-enhanced-info-wrapper .str-enhanced-info{padding:4px}}.str-countdown-container{font-family:Roboto,sans-serif;display:flex;flex-direction:column;justify-content:center;align-items:center;overflow:hidden;flex:1;z-index:2;font-size:clamp(12px,2cqw + 2cqh,16px)}@container enhanced-info (min-height: 100px){.str-countdown-container .str-countdown-content{flex-direction:column}}@container enhanced-info (aspect-ratio > 1){.str-countdown-container{font-size:clamp(12px,1cqw + 6cqh,16px)}}@container enhanced-info (aspect-ratio < 1){.str-countdown-container{font-size:clamp(12px,6cqw + 1cqh,16px)}}.str-countdown-container .str-countdown-content{font-size:1em;display:flex;width:100%;height:100%;row-gap:clamp(.5em,3.5cqw + 3.5cqh,2em);column-gap:1.25em;flex-wrap:wrap;justify-content:center;align-items:center}@container ad-unit (max-width: 320px) and (max-height: 250px){.str-countdown-container .str-countdown-content{flex-wrap:nowrap}}.str-countdown-container .str-countdown-content .str-countdown-cta{font-size:1.2em;flex:0 0 content}@container ad-unit (max-width: 320px) and (max-height: 250px){.str-countdown-container .str-countdown-content .str-countdown-cta{font-size:1.05em;flex:0 1 content;white-space:initial;min-width:0}}.str-countdown-container .str-countdown-content.nowrap{flex-wrap:nowrap}.str-countdown-container .str-countdown-time{flex:0 0 content;display:grid;grid-template-columns:1fr auto 1fr auto 1fr auto 1fr}.str-countdown-container .str-countdown-time div{text-align:center;display:flex;flex-direction:column}.str-countdown-container .str-countdown-time div label{text-transform:uppercase;font-size:.8em}@container enhanced-info (max-height: 40px){.str-countdown-container .str-countdown-time div label{display:none}}.str-countdown-container .str-countdown-time div span{font-size:1.8em;align-self:center}.str-countdown-wrapper~.str-title,.str-countdown-wrapper~.str-description,.str-countdown-wrapper~.str-text,.str-countdown-wrapper~.str-buttons.str-buttons-container{position:absolute;bottom:2px;right:2px;display:none!important}@container ad-unit (max-width: 320px) and (max-height: 250px){.str-countdown-container~.gc-bottom{display:none!important}}.str-enhanced-captions{position:relative}.str-enhanced-captions .str-captions-background{position:absolute;display:flex;overflow:hidden;justify-content:center;align-items:center;height:100%;width:100%;left:0;top:0;background-color:#fff}.str-enhanced-captions .str-captions-background .str-caption-canvas{filter:blur(12px);position:absolute}.str-enhanced-captions .str-caption-container{height:unset;width:unset}.str-enhanced-captions .str-captions{position:absolute;align-items:center}.str-enhanced-captions span[data-shadow]{display:flex;text-align:center;text-shadow:0px 0px 4px rgba(0,0,0,.7);filter:drop-shadow(0px 0px 4px #000)}.str-enhanced-captions span[data-shadow]:after{content:attr(data-shadow);position:absolute;color:#fff}.str-enhanced-captions.str-solid-background span[data-shadow]{text-shadow:none;filter:none;color:#000}.str-enhanced-captions.str-solid-background span[data-shadow]:after{color:#000}.str-enhanced-captions .str-bottom-captions{z-index:1}.str-caption-container{height:100%;width:100%;flex-direction:column;position:absolute;display:flex;justify-content:center;font-size:clamp(12px,4cqw + 4cqh,18px)}.str-caption-container.str-prev-caption{animation:subtitle-fade-out .25s ease-out;opacity:0}.str-caption-container.str-current-caption{animation:subtitle-fade-in .6s ease-out;opacity:1}@keyframes subtitle-fade-in{0%{opacity:0}to{opacity:1}}@keyframes subtitle-fade-out{0%{opacity:1}to{opacity:0}}.str-adunit-overlay .str-enhanced-info-wrapper{bottom:0;position:absolute;left:0;width:100%;height:50%;z-index:6;transform:translate(-100%);transition:transform .5s ease-in-out}.str-adunit-overlay .str-enhanced-info-wrapper.is-open{transform:translate(0)}.str-responsive-placement-widest.str-responsive-creative-widest .str-adunit-overlay .str-enhanced-info-wrapper{left:auto;right:0;width:30%;height:100%;transform:translate(100%);transition:transform .5s ease-in-out}.str-responsive-placement-widest.str-responsive-creative-widest .str-adunit-overlay .str-enhanced-info-wrapper.is-open{transform:translate(0)}._str-banner-clickblocker_1414n_1{position:absolute;z-index:6;width:100%;height:100%}._str-banner-clickblocker-thumbnail_1414n_7{position:absolute;z-index:6}.str-adunit-banner-only{width:100%!important;height:auto;background-color:#fff;margin:auto}.str-adunit-banner-only .str-thumbnail,.str-adunit-banner-only .thumbnail-wrapper{background-color:#ebf0f0;overflow:hidden}.str-ad-type-banner .str-compiled-template-unenhanced{justify-content:center;align-items:center}._thumbnail-wrapper_6fmrl_1{flex:0 1 auto;align-self:flex-start;height:100%;width:auto;margin:auto 0}._thumbnail-wrapper_6fmrl_1 ._thumbnail_6fmrl_1{max-width:none;max-height:100%}@container ad-unit (max-aspect-ratio: 1.5){._thumbnail-wrapper_6fmrl_1{height:auto;width:auto;margin:0 auto}._thumbnail-wrapper_6fmrl_1 ._thumbnail_6fmrl_1{max-width:100cqw;max-height:50cqh}}@container ad-unit (max-aspect-ratio: .8){._thumbnail-wrapper_6fmrl_1{height:auto;width:100%;margin:0 auto}._thumbnail-wrapper_6fmrl_1 ._thumbnail_6fmrl_1{max-width:100%;max-height:none}}._thumbnail_6fmrl_1{width:auto;height:auto;object-fit:contain}.str-react-template .str-clickout.str-adunit{display:flex;gap:5px;height:100%;width:100%;flex-direction:row}@container ad-unit (max-aspect-ratio: 1.5){.str-react-template .str-clickout.str-adunit{flex-direction:column}}.str-retail-advertiser{flex:0 0 auto;display:flex;align-items:center;gap:4px;font:400 12px/160% Inter,sans-serif;color:#1b1b1b}.str-retail-advertiser .str-retail-promoted-by{white-space:nowrap}.str-retail-advertiser .str-retail-advertiser-name{font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.str-retail-brand-logo{flex:0 0 auto;display:flex;align-items:center}.str-retail-brand-logo .str-retail-brand-logo-img{width:var(--logo-size);height:var(--logo-size);object-fit:contain}.str-retail-cta{flex:0 0 auto;display:inline-flex;align-items:center;justify-content:center;width:var(--cta-width);height:var(--cta-height);font:500 12px/160% Inter,sans-serif;color:var(--cta-text-color, #fff);background-color:var(--cta-background-color, #2e2e2e);border:none;border-radius:4px;cursor:pointer;white-space:nowrap}.str-retail-cta:hover{color:var(--cta-text-hover-color, var(--cta-text-color, #fff));background-color:var(--cta-background-hover-color, #333)}.str-retail-description{flex:0 1 auto;font:400 12px/120% Inter,sans-serif;color:#000}.str-retail-price{flex:0 0 auto;display:flex;align-items:baseline;justify-content:center;gap:12px;font-family:Inter,sans-serif;margin-bottom:8px}.str-retail-price .str-retail-price-symbol{font-size:.645em;vertical-align:top;line-height:1}.str-retail-price .str-retail-current-price{font:500 14px/100% Inter,sans-serif;color:#000}.str-retail-price .str-retail-sale-price{color:#ad1414}.str-retail-price .str-retail-original-price{font:500 12px/100% Inter,sans-serif;color:#000;text-decoration:line-through}.str-retail-thumbnail{display:flex;align-items:center;justify-content:center;min-height:0}.str-retail-thumbnail .str-retail-thumbnail-img{width:var(--thumbnail-size);height:var(--thumbnail-size);object-fit:contain;border:1px solid #efefef;border-radius:2px}.str-retail-title{flex:0 0 auto;font:700 12px/120% Inter,sans-serif;color:#000;overflow:hidden;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;text-overflow:ellipsis}.str-retail-shoppable-single-product-container{height:100%;width:100%;container-type:size;container-name:retail-shoppable-single-product}.str-retail-shoppable-single-product-container .str-retail-shoppable-single-product{display:flex;flex-direction:column;align-items:center;font-family:Inter,sans-serif;color:#1a1a1a;box-sizing:border-box;height:100%;width:100%;cursor:pointer;padding:clamp(12px,1.5cqw + 1.5cqh,16px);gap:clamp(8px,1cqw + 1cqh,14px);overflow:hidden;--cta-width: 268px;--cta-height: 34px;--thumbnail-size: 106px;--logo-size: 32px}.str-retail-shoppable-single-product-container .str-retail-shoppable-single-product .str-retail-shoppable-single-product-body{flex:0 1 auto;display:flex;flex-direction:column;width:100%;min-height:0;text-align:center}.str-retail-shoppable-single-product-container .str-retail-shoppable-single-product .str-retail-footer{display:contents}.str-retail-shoppable-single-product-container .str-retail-shoppable-single-product .str-retail-brand-logo{order:-1}.str-retail-shoppable-single-product-container .str-retail-shoppable-single-product .str-retail-cta{order:1}.str-retail-shoppable-single-product-container .str-retail-shoppable-single-product .str-retail-advertiser{order:2}@container retail-shoppable-single-product (max-aspect-ratio: .8){.str-retail-shoppable-single-product-container .str-retail-shoppable-single-product .str-retail-title{-webkit-line-clamp:unset;display:block}}@container retail-shoppable-single-product (max-aspect-ratio: .2857142857){.str-retail-shoppable-single-product-container .str-retail-shoppable-single-product .str-retail-title{overflow:hidden;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical}}@container retail-shoppable-single-product (max-aspect-ratio: .8) and (min-width: 280px){.str-retail-shoppable-single-product-container .str-retail-shoppable-single-product .str-retail-title{font:700 14px/120% Inter,sans-serif}}@container retail-shoppable-single-product (min-aspect-ratio: .8){.str-retail-shoppable-single-product-container .str-retail-shoppable-single-product .str-retail-title{text-align:left}}@container retail-shoppable-single-product (min-aspect-ratio: 1.5){.str-retail-shoppable-single-product-container .str-retail-shoppable-single-product .str-retail-title{font:700 14px/120% Inter,sans-serif}}@container retail-shoppable-single-product (min-aspect-ratio: 3.5){.str-retail-shoppable-single-product-container .str-retail-shoppable-single-product .str-retail-title{font:700 12px/120% Inter,sans-serif}}@container retail-shoppable-single-product (min-aspect-ratio: 3.5) and (min-width: 800px){.str-retail-shoppable-single-product-container .str-retail-shoppable-single-product .str-retail-title{font:700 14px/120% Inter,sans-serif}}@container retail-shoppable-single-product (max-aspect-ratio: .8) and (min-width: 280px){.str-retail-shoppable-single-product-container .str-retail-shoppable-single-product .str-retail-description{font:400 14px/120% Inter,sans-serif}}@container retail-shoppable-single-product (min-aspect-ratio: .8){.str-retail-shoppable-single-product-container .str-retail-shoppable-single-product .str-retail-description{text-align:left}}@container retail-shoppable-single-product (min-aspect-ratio: 1.5){.str-retail-shoppable-single-product-container .str-retail-shoppable-single-product .str-retail-description{font:400 14px/120% Inter,sans-serif}}@container retail-shoppable-single-product (min-aspect-ratio: 3.5){.str-retail-shoppable-single-product-container .str-retail-shoppable-single-product .str-retail-description{font:400 12px/120% Inter,sans-serif;overflow:hidden;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;text-overflow:ellipsis;text-align:left}}@container retail-shoppable-single-product (min-aspect-ratio: 3.5) and (min-width: 800px){.str-retail-shoppable-single-product-container .str-retail-shoppable-single-product .str-retail-description{font:400 14px/120% Inter,sans-serif;-webkit-line-clamp:unset;display:block}}@container retail-shoppable-single-product (min-aspect-ratio: .8){.str-retail-shoppable-single-product-container .str-retail-shoppable-single-product .str-retail-price{justify-content:flex-start}}@container retail-shoppable-single-product (max-aspect-ratio: .8) and (min-width: 280px){.str-retail-shoppable-single-product-container .str-retail-shoppable-single-product .str-retail-current-price{font:500 22px/100% Inter,sans-serif}}@container retail-shoppable-single-product (min-aspect-ratio: .8){.str-retail-shoppable-single-product-container .str-retail-shoppable-single-product .str-retail-current-price{font:500 16px/100% Inter,sans-serif}}@container retail-shoppable-single-product (min-aspect-ratio: 3.5){.str-retail-shoppable-single-product-container .str-retail-shoppable-single-product .str-retail-current-price{font:500 14px/100% Inter,sans-serif}}@container retail-shoppable-single-product (min-aspect-ratio: 3.5) and (min-width: 800px){.str-retail-shoppable-single-product-container .str-retail-shoppable-single-product .str-retail-current-price{font:500 22px/100% Inter,sans-serif}}@container retail-shoppable-single-product (max-aspect-ratio: .8) and (min-width: 280px){.str-retail-shoppable-single-product-container .str-retail-shoppable-single-product .str-retail-original-price{font:500 18px/100% Inter,sans-serif}}@container retail-shoppable-single-product (min-aspect-ratio: .8){.str-retail-shoppable-single-product-container .str-retail-shoppable-single-product .str-retail-original-price{font:500 13px/100% Inter,sans-serif}}@container retail-shoppable-single-product (min-aspect-ratio: 3.5){.str-retail-shoppable-single-product-container .str-retail-shoppable-single-product .str-retail-original-price{font:500 12px/100% Inter,sans-serif}}@container retail-shoppable-single-product (min-aspect-ratio: 3.5) and (min-width: 800px){.str-retail-shoppable-single-product-container .str-retail-shoppable-single-product .str-retail-original-price{font:500 18px/100% Inter,sans-serif}}@container retail-shoppable-single-product (max-aspect-ratio: .8) and (min-width: 280px){.str-retail-shoppable-single-product-container .str-retail-shoppable-single-product .str-retail-cta{font:500 14px/160% Inter,sans-serif}}@container retail-shoppable-single-product (min-aspect-ratio: 1.5){.str-retail-shoppable-single-product-container .str-retail-shoppable-single-product .str-retail-cta{font:500 14px/160% Inter,sans-serif}}@container retail-shoppable-single-product (min-aspect-ratio: 3.5){.str-retail-shoppable-single-product-container .str-retail-shoppable-single-product .str-retail-cta{font:500 12px/160% Inter,sans-serif}}@container retail-shoppable-single-product (min-aspect-ratio: 3.5) and (min-width: 800px){.str-retail-shoppable-single-product-container .str-retail-shoppable-single-product .str-retail-cta{font:500 14px/160% Inter,sans-serif}}@container retail-shoppable-single-product (min-aspect-ratio: .8){.str-retail-shoppable-single-product-container .str-retail-shoppable-single-product .str-retail-advertiser{font:400 8px/160% Inter,sans-serif}}@container retail-shoppable-single-product (min-aspect-ratio: 1.5){.str-retail-shoppable-single-product-container .str-retail-shoppable-single-product .str-retail-advertiser{font:400 12px/160% Inter,sans-serif}}@container retail-shoppable-single-product (min-aspect-ratio: 3.5) and (min-width: 800px){.str-retail-shoppable-single-product-container .str-retail-shoppable-single-product .str-retail-advertiser{font:400 12px/160% Inter,sans-serif}}@container retail-shoppable-single-product (max-aspect-ratio: .8){.str-retail-shoppable-single-product-container .str-retail-shoppable-single-product .str-retail-thumbnail{flex:0 1 auto}}@container retail-shoppable-single-product (min-aspect-ratio: 1.5){.str-retail-shoppable-single-product-container .str-retail-shoppable-single-product .str-retail-thumbnail{flex:0 0 40%;height:100%}}@container retail-shoppable-single-product (min-aspect-ratio: 3.5){.str-retail-shoppable-single-product-container .str-retail-shoppable-single-product .str-retail-thumbnail{flex:0 0 auto}}@container retail-shoppable-single-product (max-aspect-ratio: .8){.str-retail-shoppable-single-product-container .str-retail-shoppable-single-product{--thumbnail-size: 268px;--logo-size: 60px}.str-retail-shoppable-single-product-container .str-retail-shoppable-single-product .str-retail-cta{margin-top:auto}}@container retail-shoppable-single-product (max-aspect-ratio: .2857142857){.str-retail-shoppable-single-product-container .str-retail-shoppable-single-product{--cta-width: 107px;--cta-height: 32px;--thumbnail-size: 104px;--logo-size: 30px}.str-retail-shoppable-single-product-container .str-retail-shoppable-single-product .str-retail-advertiser{display:none}.str-retail-shoppable-single-product-container .str-retail-shoppable-single-product .str-retail-cta{margin-top:auto}}@container retail-shoppable-single-product (max-aspect-ratio: .8) and (min-aspect-ratio: .2857142857){.str-retail-shoppable-single-product-container .str-retail-shoppable-single-product .str-retail-description{overflow:hidden;display:-webkit-box;-webkit-line-clamp:5;-webkit-box-orient:vertical}}@container retail-shoppable-single-product (max-aspect-ratio: .8) and (min-width: 320px){.str-retail-shoppable-single-product-container .str-retail-shoppable-single-product{--cta-width: 304px;--cta-height: 34px;--thumbnail-size: 140px}.str-retail-shoppable-single-product-container .str-retail-shoppable-single-product .str-retail-description{-webkit-line-clamp:7}}@container retail-shoppable-single-product (min-aspect-ratio: .8){.str-retail-shoppable-single-product-container .str-retail-shoppable-single-product{--cta-width: 107px;--cta-height: 32px;flex-direction:row;flex-wrap:wrap;align-items:flex-start;align-content:space-between}.str-retail-shoppable-single-product-container .str-retail-shoppable-single-product .str-retail-thumbnail{flex:0 0 40%;order:1}.str-retail-shoppable-single-product-container .str-retail-shoppable-single-product .str-retail-shoppable-single-product-body{flex:1 1 50%;order:2}.str-retail-shoppable-single-product-container .str-retail-shoppable-single-product .str-retail-footer{display:flex;order:3;flex:1 1 100%;align-items:center;gap:clamp(4px,1cqw + 1cqh,8px)}.str-retail-shoppable-single-product-container .str-retail-shoppable-single-product .str-retail-footer .str-retail-advertiser{order:-1}.str-retail-shoppable-single-product-container .str-retail-shoppable-single-product .str-retail-footer .str-retail-brand-logo{order:0;margin-left:auto}.str-retail-shoppable-single-product-container .str-retail-shoppable-single-product .str-retail-footer .str-retail-cta{order:1}}@container retail-shoppable-single-product (min-aspect-ratio: 1.5){.str-retail-shoppable-single-product-container .str-retail-shoppable-single-product{--cta-width: 128px;--cta-height: 34px;--thumbnail-size: 200px;--logo-size: 32px;flex-direction:row;flex-wrap:wrap;align-items:center;align-content:space-between}.str-retail-shoppable-single-product-container .str-retail-shoppable-single-product .str-retail-thumbnail{flex:0 0 45%;height:auto;order:1}.str-retail-shoppable-single-product-container .str-retail-shoppable-single-product .str-retail-shoppable-single-product-body{flex:1 1 0;order:2;justify-content:center}.str-retail-shoppable-single-product-container .str-retail-shoppable-single-product .str-retail-footer{display:flex;order:3;flex:1 1 100%;align-items:center;gap:clamp(4px,1cqw + 1cqh,8px)}.str-retail-shoppable-single-product-container .str-retail-shoppable-single-product .str-retail-footer .str-retail-advertiser{order:-1}.str-retail-shoppable-single-product-container .str-retail-shoppable-single-product .str-retail-footer .str-retail-brand-logo{order:0;margin-left:auto}.str-retail-shoppable-single-product-container .str-retail-shoppable-single-product .str-retail-footer .str-retail-cta{order:1}}@container retail-shoppable-single-product (min-aspect-ratio: 3.5){.str-retail-shoppable-single-product-container .str-retail-shoppable-single-product{--cta-width: 107px;--cta-height: 32px;--thumbnail-size: 78px;--logo-size: 30px;flex-direction:row;flex-wrap:nowrap;align-items:center}.str-retail-shoppable-single-product-container .str-retail-shoppable-single-product .str-retail-thumbnail{flex:0 0 auto;height:80%;order:1}.str-retail-shoppable-single-product-container .str-retail-shoppable-single-product .str-retail-shoppable-single-product-body{flex:1 1 0;order:2;flex-direction:column;align-items:flex-start;justify-content:center;text-align:left}.str-retail-shoppable-single-product-container .str-retail-shoppable-single-product .str-retail-footer{display:contents}.str-retail-shoppable-single-product-container .str-retail-shoppable-single-product .str-retail-footer .str-retail-brand-logo{order:0;margin-left:0;flex:0 0 auto}.str-retail-shoppable-single-product-container .str-retail-shoppable-single-product .str-retail-footer .str-retail-cta{order:3;flex:0 0 auto}.str-retail-shoppable-single-product-container .str-retail-shoppable-single-product .str-retail-footer .str-retail-advertiser{display:none}}@container retail-shoppable-single-product (min-aspect-ratio: 3.5) and (min-width: 800px){.str-retail-shoppable-single-product-container .str-retail-shoppable-single-product{--cta-width: 276px;--cta-height: 34px;--thumbnail-size: 218px;--logo-size: 100px;flex-direction:row;flex-wrap:nowrap;align-items:stretch}.str-retail-shoppable-single-product-container .str-retail-shoppable-single-product .str-retail-thumbnail{flex:0 0 auto;align-self:center;height:80%}.str-retail-shoppable-single-product-container .str-retail-shoppable-single-product .str-retail-shoppable-single-product-body{flex:1 1 0;flex-direction:column;align-items:flex-start;justify-content:center;text-align:left}.str-retail-shoppable-single-product-container .str-retail-shoppable-single-product .str-retail-footer{display:flex;flex:0 0 auto;flex-direction:column;align-items:center;justify-content:center;gap:clamp(4px,1cqw + 1cqh,8px);max-width:var(--cta-width)}.str-retail-shoppable-single-product-container .str-retail-shoppable-single-product .str-retail-footer .str-retail-brand-logo{order:0;margin-left:0;margin-bottom:auto}.str-retail-shoppable-single-product-container .str-retail-shoppable-single-product .str-retail-footer .str-retail-advertiser{order:0;display:flex}.str-retail-shoppable-single-product-container .str-retail-shoppable-single-product .str-retail-footer .str-retail-cta{order:0}}.str-retail-carousel{display:flex;flex-direction:column;align-items:center;gap:8px;width:100%;min-height:0;flex:0 1 auto;overflow:hidden}.str-retail-carousel-track{display:flex;align-items:center;justify-content:center;width:100%;flex:0 1 auto;min-height:0;position:relative;overflow:hidden}.str-retail-carousel-slide{display:flex;align-items:center;justify-content:center;flex:0 0 auto;transition:transform .3s ease,opacity .3s ease}.str-retail-carousel-slide.active{position:relative;z-index:2;transform:scale(1);opacity:1;flex:0 0 auto;max-height:100%;border-radius:4px;overflow:hidden;filter:drop-shadow(0 3px 7px rgba(0,0,0,.15))}.str-retail-carousel-slide.prev,.str-retail-carousel-slide.next{position:relative;z-index:1;transform:scale(.85);opacity:.6;flex:0 0 25%;max-height:80%;overflow:hidden;border-radius:4px}.str-retail-carousel-img{width:100%;height:100%;display:block}.str-retail-carousel-dots{display:flex;gap:6px;justify-content:center;align-items:center;flex:0 0 auto}.str-retail-carousel-dot{width:7px;height:7px;border-radius:50%;border:none;background:#00000040;padding:0;cursor:pointer;transition:background .2s ease}.str-retail-carousel-dot.active{background:#000}.str-retail-shoppable-single-product-carousel-container{height:100%;width:100%;container-type:size;container-name:retail-shoppable-single-product-carousel}.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel{display:flex;flex-direction:column;align-items:center;font-family:Inter,sans-serif;color:#1a1a1a;box-sizing:border-box;height:100%;width:100%;cursor:pointer;padding:clamp(12px,1.5cqw + 1.5cqh,16px);gap:clamp(8px,1cqw + 1cqh,14px);overflow:hidden;--cta-width: 268px;--cta-height: 34px;--logo-size: 60px;--active-thumbnail-size: 200px;--peek-thumbnail-size: 120px}.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel .str-retail-brand-logo-img{width:var(--logo-size);height:var(--logo-size)}.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel .str-retail-carousel-slide.active{flex:0 0 auto}.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel .str-retail-carousel-slide.active .str-retail-carousel-img{width:var(--active-thumbnail-size);height:var(--active-thumbnail-size)}.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel .str-retail-carousel-slide.prev,.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel .str-retail-carousel-slide.next{flex:0 0 auto}.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel .str-retail-carousel-slide.prev .str-retail-carousel-img,.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel .str-retail-carousel-slide.next .str-retail-carousel-img{width:var(--peek-thumbnail-size);height:var(--peek-thumbnail-size)}.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel .str-retail-shoppable-single-product-carousel-body{flex:0 1 auto;display:flex;flex-direction:column;width:100%;min-height:0;text-align:center}.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel .str-retail-footer{display:contents}.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel .str-retail-brand-logo{order:-1}.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel .str-retail-cta{order:1}.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel .str-retail-advertiser{order:2}@container retail-shoppable-single-product-carousel (max-aspect-ratio: .8){.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel .str-retail-title{-webkit-line-clamp:unset;display:block}}@container retail-shoppable-single-product-carousel (max-aspect-ratio: .2857142857){.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel .str-retail-title{overflow:hidden;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical}}@container retail-shoppable-single-product-carousel (max-aspect-ratio: .8) and (min-width: 280px){.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel .str-retail-title{font:700 14px/120% Inter,sans-serif}}@container retail-shoppable-single-product-carousel (min-aspect-ratio: .8){.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel .str-retail-title{text-align:left}}@container retail-shoppable-single-product-carousel (min-aspect-ratio: 1.5){.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel .str-retail-title{font:700 14px/120% Inter,sans-serif}}@container retail-shoppable-single-product-carousel (min-aspect-ratio: 3.5){.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel .str-retail-title{font:700 12px/120% Inter,sans-serif}}@container retail-shoppable-single-product-carousel (min-aspect-ratio: 3.5) and (min-width: 800px){.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel .str-retail-title{font:700 14px/120% Inter,sans-serif}}@container retail-shoppable-single-product-carousel (max-aspect-ratio: .8) and (min-width: 280px){.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel .str-retail-description{font:400 14px/120% Inter,sans-serif}}@container retail-shoppable-single-product-carousel (min-aspect-ratio: .8){.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel .str-retail-description{text-align:left}}@container retail-shoppable-single-product-carousel (min-aspect-ratio: 1.5){.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel .str-retail-description{font:400 14px/120% Inter,sans-serif}}@container retail-shoppable-single-product-carousel (min-aspect-ratio: 3.5){.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel .str-retail-description{font:400 12px/120% Inter,sans-serif;overflow:hidden;display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;text-overflow:ellipsis;text-align:left}}@container retail-shoppable-single-product-carousel (min-aspect-ratio: 3.5) and (min-width: 800px){.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel .str-retail-description{font:400 14px/120% Inter,sans-serif;-webkit-line-clamp:unset;display:block}}@container retail-shoppable-single-product-carousel (min-aspect-ratio: .8){.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel .str-retail-price{justify-content:flex-start}}@container retail-shoppable-single-product-carousel (max-aspect-ratio: .8) and (min-width: 280px){.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel .str-retail-current-price{font:500 22px/100% Inter,sans-serif}}@container retail-shoppable-single-product-carousel (min-aspect-ratio: .8){.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel .str-retail-current-price{font:500 16px/100% Inter,sans-serif}}@container retail-shoppable-single-product-carousel (min-aspect-ratio: 3.5){.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel .str-retail-current-price{font:500 14px/100% Inter,sans-serif}}@container retail-shoppable-single-product-carousel (min-aspect-ratio: 3.5) and (min-width: 800px){.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel .str-retail-current-price{font:500 22px/100% Inter,sans-serif}}@container retail-shoppable-single-product-carousel (max-aspect-ratio: .8) and (min-width: 280px){.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel .str-retail-original-price{font:500 18px/100% Inter,sans-serif}}@container retail-shoppable-single-product-carousel (min-aspect-ratio: .8){.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel .str-retail-original-price{font:500 13px/100% Inter,sans-serif}}@container retail-shoppable-single-product-carousel (min-aspect-ratio: 3.5){.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel .str-retail-original-price{font:500 12px/100% Inter,sans-serif}}@container retail-shoppable-single-product-carousel (min-aspect-ratio: 3.5) and (min-width: 800px){.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel .str-retail-original-price{font:500 18px/100% Inter,sans-serif}}@container retail-shoppable-single-product-carousel (max-aspect-ratio: .8) and (min-width: 280px){.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel .str-retail-cta{font:500 14px/160% Inter,sans-serif}}@container retail-shoppable-single-product-carousel (min-aspect-ratio: 1.5){.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel .str-retail-cta{font:500 14px/160% Inter,sans-serif}}@container retail-shoppable-single-product-carousel (min-aspect-ratio: 3.5){.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel .str-retail-cta{font:500 12px/160% Inter,sans-serif}}@container retail-shoppable-single-product-carousel (min-aspect-ratio: 3.5) and (min-width: 800px){.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel .str-retail-cta{font:500 14px/160% Inter,sans-serif}}@container retail-shoppable-single-product-carousel (min-aspect-ratio: .8){.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel .str-retail-advertiser{font:400 8px/160% Inter,sans-serif}}@container retail-shoppable-single-product-carousel (min-aspect-ratio: 1.5){.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel .str-retail-advertiser{font:400 12px/160% Inter,sans-serif}}@container retail-shoppable-single-product-carousel (min-aspect-ratio: 3.5) and (min-width: 800px){.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel .str-retail-advertiser{font:400 12px/160% Inter,sans-serif}}@container retail-shoppable-single-product-carousel (max-aspect-ratio: .8){.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel .str-retail-carousel{flex:0 1 auto}}@container retail-shoppable-single-product-carousel (min-aspect-ratio: .8){.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel .str-retail-carousel{flex:0 0 40%;height:100%}}@container retail-shoppable-single-product-carousel (min-aspect-ratio: 3.5){.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel .str-retail-carousel{flex:0 0 auto}}@container retail-shoppable-single-product-carousel (min-aspect-ratio: .8) and (max-aspect-ratio: 1.5){.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel .str-retail-carousel-slide.prev,.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel .str-retail-carousel-slide.next{display:flex;transform:none;opacity:.5;box-shadow:none;border-radius:4px}.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel .str-retail-carousel-slide.active{box-shadow:0 2px 8px #0000001a;border-radius:8px}}@container retail-shoppable-single-product-carousel (max-aspect-ratio: .2857142857){.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel{--cta-width: 107px;--cta-height: 32px;--logo-size: 30px;--active-thumbnail-size: 84px;--peek-thumbnail-size: 40px}.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel .str-retail-advertiser{display:none}.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel .str-retail-cta{margin-top:auto}.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel .str-retail-carousel{margin-left:calc(-1*clamp(12px,1.5cqw + 1.5cqh,16px));margin-right:calc(-1*clamp(12px,1.5cqw + 1.5cqh,16px));width:calc(100% + 2*clamp(12px,1.5cqw + 1.5cqh,16px))}}@container retail-shoppable-single-product-carousel (max-aspect-ratio: .8) and (min-aspect-ratio: .2857142857){.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel .str-retail-cta{margin-top:auto}.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel .str-retail-description{overflow:hidden;display:-webkit-box;-webkit-line-clamp:6;-webkit-box-orient:vertical}}@container retail-shoppable-single-product-carousel (max-aspect-ratio: .8) and (min-width: 320px){.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel{--cta-width: 304px;--cta-height: 34px;--logo-size: 60px;--active-thumbnail-size: 140px;--peek-thumbnail-size: 90px}.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel .str-retail-description{overflow:hidden;display:-webkit-box;-webkit-line-clamp:5;-webkit-box-orient:vertical}}@container retail-shoppable-single-product-carousel (min-aspect-ratio: .8){.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel{--cta-width: 107px;--cta-height: 32px;--logo-size: 30px;--active-thumbnail-size: 84px;--peek-thumbnail-size: 40px;flex-direction:row;flex-wrap:wrap;align-items:flex-start;align-content:space-between}.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel .str-retail-carousel{flex:0 0 40%;order:1;height:auto;flex-direction:column}.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel .str-retail-shoppable-single-product-carousel-body{flex:1 1 50%;order:2;min-height:0;overflow:hidden}.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel .str-retail-footer{display:flex;order:3;flex:1 1 100%;align-items:center;gap:clamp(4px,1cqw + 1cqh,8px)}.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel .str-retail-footer .str-retail-advertiser{order:-1}.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel .str-retail-footer .str-retail-brand-logo{order:0;margin-left:auto}.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel .str-retail-footer .str-retail-cta{order:1}}@container retail-shoppable-single-product-carousel (min-aspect-ratio: 1.5){.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel{--cta-width: 128px;--cta-height: 34px;--active-thumbnail-size: 180px;--peek-thumbnail-size: 100px;flex-direction:row;flex-wrap:wrap;align-items:center;align-content:space-between}.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel .str-retail-carousel{flex:0 0 45%;order:1;height:auto;align-self:center;flex-direction:column}.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel .str-retail-carousel-slide.prev,.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel .str-retail-carousel-slide.next{display:flex;transform:none;opacity:.5;box-shadow:none;border-radius:4px}.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel .str-retail-carousel-slide.active{box-shadow:0 2px 8px #0000001a;border-radius:8px}.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel .str-retail-carousel-dots{display:flex}.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel .str-retail-shoppable-single-product-carousel-body{flex:1 1 0;order:2;justify-content:center}.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel .str-retail-footer{display:flex;order:3;flex:1 1 100%;align-items:center;gap:clamp(4px,1cqw + 1cqh,8px)}.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel .str-retail-footer .str-retail-advertiser{order:-1}.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel .str-retail-footer .str-retail-brand-logo{order:0;margin-left:auto}.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel .str-retail-footer .str-retail-cta{order:1}}@container retail-shoppable-single-product-carousel (min-aspect-ratio: 3.5){.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel{--cta-width: 107px;--cta-height: 32px;--logo-size: 30px;--active-thumbnail-size: 68px;--peek-thumbnail-size: 40px;flex-direction:row;flex-wrap:nowrap;align-items:center}.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel .str-retail-carousel{flex:0 0 auto;width:auto;height:100%;order:1;flex-direction:column}.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel .str-retail-carousel-slide.prev,.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel .str-retail-carousel-slide.next{display:flex;transform:none;opacity:.5;box-shadow:none;border-radius:4px}.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel .str-retail-carousel-slide.active{box-shadow:none;border-radius:4px}.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel .str-retail-carousel-dots{display:flex}.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel .str-retail-shoppable-single-product-carousel-body{flex:1 1 0;order:2;flex-direction:column;align-items:flex-start;justify-content:center;text-align:left}.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel .str-retail-footer{display:contents}.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel .str-retail-footer .str-retail-brand-logo{order:0;margin-left:0;flex:0 0 auto}.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel .str-retail-footer .str-retail-cta{order:3;flex:0 0 auto}.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel .str-retail-footer .str-retail-advertiser{display:none}}@container retail-shoppable-single-product-carousel (min-aspect-ratio: 3.5) and (min-width: 800px){.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel{--cta-width: 276px;--cta-height: 34px;--logo-size: 100px;--active-thumbnail-size: 200px;--peek-thumbnail-size: 120px;flex-direction:row;flex-wrap:nowrap;align-items:stretch}.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel .str-retail-carousel{flex:0 0 auto;order:1;align-self:center;height:100%;flex-direction:column}.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel .str-retail-carousel-slide.prev{display:flex;flex:0 0 var(--peek-thumbnail-size);margin-right:-100px}.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel .str-retail-carousel-slide.next{display:flex;flex:0 0 var(--peek-thumbnail-size);margin-left:-100px}.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel .str-retail-carousel-slide.active{flex:0 0 auto;box-shadow:0 2px 8px #0000001a;border-radius:8px}.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel .str-retail-carousel-dots{display:flex}.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel .str-retail-shoppable-single-product-carousel-body{flex:1 1 0;order:2;flex-direction:column;align-items:flex-start;justify-content:center;text-align:left}.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel .str-retail-footer{display:flex;order:3;flex:0 0 auto;flex-direction:column;align-items:center;justify-content:center;gap:clamp(4px,1cqw + 1cqh,8px);max-width:var(--cta-width)}.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel .str-retail-footer .str-retail-brand-logo{order:0;margin-left:0;margin-bottom:auto}.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel .str-retail-footer .str-retail-advertiser{order:0;display:flex}.str-retail-shoppable-single-product-carousel-container .str-retail-shoppable-single-product-carousel .str-retail-footer .str-retail-cta{order:0}}.str-retail-shoppable-carousel-container{height:100%;width:100%;container-type:size;container-name:retail-shoppable-carousel}.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel{display:flex;flex-direction:column;align-items:center;font-family:Inter,sans-serif;color:#1a1a1a;box-sizing:border-box;height:100%;width:100%;cursor:pointer;padding:clamp(12px,1.5cqw + 1.5cqh,16px);gap:clamp(8px,1cqw + 1cqh,14px);overflow:hidden;--cta-width: 268px;--cta-height: 34px;--logo-size: 60px;--active-product-size: 180px;--inactive-product-size: 84px}.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-brand-logo-img{width:var(--logo-size);height:var(--logo-size)}.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-shoppable-carousel-active{display:flex;align-items:center;gap:4px;flex:0 0 auto}.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-shoppable-carousel-active-img-stack{position:relative;width:var(--active-product-size);height:var(--active-product-size)}.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-shoppable-carousel-active-img{width:var(--active-product-size);height:var(--active-product-size);border-radius:4px;cursor:pointer;position:absolute;top:0;left:0;opacity:0;pointer-events:none;object-fit:contain}.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-shoppable-carousel-active-img.active{opacity:1;pointer-events:auto}.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-shoppable-carousel-arrow{display:none;align-items:center;justify-content:center;width:24px;height:24px;border-radius:50%;border:none;background:#f6f6f6;font-size:16px;line-height:1;cursor:pointer;flex-shrink:0;padding:0}.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-shoppable-carousel-arrow:hover{background:#ececec}.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-shoppable-carousel-body{flex:0 1 auto;display:flex;flex-direction:column;width:100%;min-height:0;text-align:center}.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-footer{display:contents}.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-brand-logo{order:-1}.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-cta{order:1}.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-advertiser{order:2}.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-shoppable-carousel-thumbnails{display:flex;flex-direction:row;gap:4px;flex:0 0 auto;justify-content:center}.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-shoppable-carousel-thumbnail{width:var(--inactive-product-size);height:var(--inactive-product-size);border-radius:2px;border:1px solid #efefef;object-fit:contain;cursor:pointer;transition:opacity .15s ease}.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-shoppable-carousel-thumbnail:hover{opacity:.8}.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-shoppable-carousel-thumbnail:nth-child(n+4){display:none}.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-carousel-dots{display:flex;gap:6px;justify-content:center;align-items:center;flex:0 0 auto}.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-carousel-dot{width:7px;height:7px;border-radius:50%;border:none;background:#00000040;padding:0;cursor:pointer;transition:background .2s ease}.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-carousel-dot.active{background:#000}@container retail-shoppable-carousel (max-aspect-ratio: .8){.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-title{-webkit-line-clamp:unset;display:block}}@container retail-shoppable-carousel (max-aspect-ratio: .2857142857){.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-title{overflow:hidden;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical}}@container retail-shoppable-carousel (max-aspect-ratio: .8) and (min-width: 280px){.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-title{font:700 14px/120% Inter,sans-serif}}@container retail-shoppable-carousel (min-aspect-ratio: .8){.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-title{text-align:left}}@container retail-shoppable-carousel (min-aspect-ratio: 1.5){.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-title{font:700 14px/120% Inter,sans-serif}}@container retail-shoppable-carousel (min-aspect-ratio: 3.5){.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-title{font:700 12px/120% Inter,sans-serif}}@container retail-shoppable-carousel (min-aspect-ratio: 3.5) and (min-width: 800px){.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-title{font:700 14px/120% Inter,sans-serif}}@container retail-shoppable-carousel (max-aspect-ratio: .8) and (min-width: 280px){.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-description{font:400 14px/120% Inter,sans-serif}}@container retail-shoppable-carousel (min-aspect-ratio: .8){.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-description{text-align:left;overflow:hidden;display:-webkit-box;-webkit-line-clamp:4;-webkit-box-orient:vertical}}@container retail-shoppable-carousel (min-aspect-ratio: 1.5){.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-description{font:400 14px/120% Inter,sans-serif}}@container retail-shoppable-carousel (min-aspect-ratio: 3.5){.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-description{font:400 12px/120% Inter,sans-serif;overflow:hidden;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;text-overflow:ellipsis;text-align:left}}@container retail-shoppable-carousel (min-aspect-ratio: 3.5) and (min-width: 800px){.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-description{font:400 14px/120% Inter,sans-serif;-webkit-line-clamp:3}}@container retail-shoppable-carousel (min-aspect-ratio: .8){.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-price{justify-content:flex-start}}@container retail-shoppable-carousel (max-aspect-ratio: .8) and (min-width: 280px){.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-current-price{font:500 22px/100% Inter,sans-serif}}@container retail-shoppable-carousel (min-aspect-ratio: .8){.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-current-price{font:500 16px/100% Inter,sans-serif}}@container retail-shoppable-carousel (min-aspect-ratio: 3.5){.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-current-price{font:500 14px/100% Inter,sans-serif}}@container retail-shoppable-carousel (min-aspect-ratio: 3.5) and (min-width: 800px){.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-current-price{font:500 22px/100% Inter,sans-serif}}@container retail-shoppable-carousel (max-aspect-ratio: .8) and (min-width: 280px){.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-original-price{font:500 18px/100% Inter,sans-serif}}@container retail-shoppable-carousel (min-aspect-ratio: .8){.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-original-price{font:500 13px/100% Inter,sans-serif}}@container retail-shoppable-carousel (min-aspect-ratio: 3.5){.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-original-price{font:500 12px/100% Inter,sans-serif}}@container retail-shoppable-carousel (min-aspect-ratio: 3.5) and (min-width: 800px){.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-original-price{font:500 18px/100% Inter,sans-serif}}@container retail-shoppable-carousel (max-aspect-ratio: .8) and (min-width: 280px){.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-cta{font:500 14px/160% Inter,sans-serif}}@container retail-shoppable-carousel (min-aspect-ratio: 1.5){.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-cta{font:500 14px/160% Inter,sans-serif}}@container retail-shoppable-carousel (min-aspect-ratio: 3.5){.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-cta{font:500 12px/160% Inter,sans-serif}}@container retail-shoppable-carousel (min-aspect-ratio: 3.5) and (min-width: 800px){.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-cta{font:500 14px/160% Inter,sans-serif}}@container retail-shoppable-carousel (min-aspect-ratio: .8){.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-advertiser{font:400 8px/160% Inter,sans-serif}}@container retail-shoppable-carousel (min-aspect-ratio: 1.5){.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-advertiser{font:400 12px/160% Inter,sans-serif}}@container retail-shoppable-carousel (min-aspect-ratio: 3.5) and (min-width: 800px){.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-advertiser{font:400 12px/160% Inter,sans-serif}}@container retail-shoppable-carousel (max-aspect-ratio: .2857142857){.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel{--cta-width: 107px;--cta-height: 32px;--logo-size: 30px;--active-product-size: 104px;--inactive-product-size: 70px;justify-content:space-between}.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-advertiser{display:none}.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-shoppable-carousel-thumbnails{flex-direction:column}.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-description{overflow:hidden;display:-webkit-box;-webkit-line-clamp:5;-webkit-box-orient:vertical}}@container retail-shoppable-carousel (max-aspect-ratio: .8){.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-shoppable-carousel-arrow{display:flex}}@container retail-shoppable-carousel (max-aspect-ratio: .2857142857){.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-shoppable-carousel-arrow{display:none}}@container retail-shoppable-carousel (max-aspect-ratio: .8) and (min-aspect-ratio: .2857142857){.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-description{overflow:hidden;display:-webkit-box;-webkit-line-clamp:4;-webkit-box-orient:vertical}}@container retail-shoppable-carousel (max-aspect-ratio: .8) and (min-aspect-ratio: .2857142857) and (max-width: 320px){.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel{justify-content:space-between}}@container retail-shoppable-carousel (max-aspect-ratio: .8) and (min-width: 320px){.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel{--cta-width: 304px;--cta-height: 34px;--logo-size: 60px;--active-product-size: 140px;--inactive-product-size: 96px;flex-direction:row;flex-wrap:wrap;align-content:space-between}.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-shoppable-carousel-active{display:contents}.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-brand-logo{flex:1 0 100%;order:0;justify-content:center}.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-shoppable-carousel-arrow.prev{order:1;align-self:center}.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-shoppable-carousel-active-img-stack{order:2;align-self:center}.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-shoppable-carousel-body{flex:1 1 0;min-width:0;width:auto;text-align:left;order:3;align-self:flex-start}.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-price{flex-direction:column;align-items:flex-start;gap:2px}.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-description{overflow:hidden;display:-webkit-box;-webkit-line-clamp:7;-webkit-box-orient:vertical}.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-shoppable-carousel-arrow.next{order:4;align-self:center}.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-shoppable-carousel-thumbnails{flex:1 0 100%;order:5}.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-carousel-dots{flex:1 0 100%;order:6}.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-cta{flex:1 0 100%;order:7}.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-advertiser{flex:1 0 100%;order:8;justify-content:center}}@container retail-shoppable-carousel (min-aspect-ratio: .8){.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel{--cta-width: 107px;--cta-height: 32px;--logo-size: 32px;--active-product-size: 106px;--inactive-product-size: 56px;flex-direction:row;flex-wrap:wrap;align-items:flex-start;align-content:space-between}.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-shoppable-carousel-active{flex:0 0 40%;order:1}.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-shoppable-carousel-body{flex:1 1 50%;order:2}.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-shoppable-carousel-thumbnails{flex:1 0 100%;order:3}.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-carousel-dots{flex:1 0 100%;order:4}.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-footer{display:flex;order:5;flex:1 1 100%;align-items:center;gap:clamp(4px,1cqw + 1cqh,8px)}.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-footer .str-retail-advertiser{order:-1}.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-footer .str-retail-brand-logo{order:0;margin-left:auto}.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-footer .str-retail-cta{order:1}.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-shoppable-carousel-arrow{display:none}}@container retail-shoppable-carousel (min-aspect-ratio: 1.5){.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel{--cta-width: 128px;--cta-height: 34px;--logo-size: 32px;--active-product-size: 120px;--inactive-product-size: 106px;display:grid;grid-template-columns:auto 1fr;grid-template-rows:1fr auto auto;align-content:normal;align-items:center}.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-shoppable-carousel-active{grid-column:1;grid-row:1;align-self:center}.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-shoppable-carousel-body{grid-column:2;grid-row:1;justify-content:center}.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-shoppable-carousel-thumbnails{grid-column:1/-1;grid-row:2}.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-carousel-dots{display:none}.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-footer{grid-column:1/-1;grid-row:3;display:flex;align-items:center;gap:clamp(4px,1cqw + 1cqh,8px)}.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-footer .str-retail-advertiser{order:-1}.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-footer .str-retail-brand-logo{order:0;margin-left:auto}.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-footer .str-retail-cta{order:1}.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-shoppable-carousel-arrow{display:flex}}@container retail-shoppable-carousel (min-aspect-ratio: 3.5){.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel{--cta-width: 107px;--cta-height: 32px;--logo-size: 30px;--active-product-size: 78px;--inactive-product-size: 70px;display:flex;flex-direction:row;flex-wrap:nowrap;align-items:center}.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-shoppable-carousel-active{order:1;flex:0 0 auto}.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-shoppable-carousel-body{flex:1 1 0;order:2;flex-direction:column;align-items:flex-start;justify-content:center;text-align:left}.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-shoppable-carousel-thumbnails{order:3;flex:0 0 auto}.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-carousel-dots{display:none}.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-footer{display:contents}.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-footer .str-retail-brand-logo{order:0;margin-left:0;flex:0 0 auto}.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-footer .str-retail-cta{order:4;flex:0 0 auto}.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-footer .str-retail-advertiser,.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-shoppable-carousel-arrow{display:none}}@container retail-shoppable-carousel (min-aspect-ratio: 3.5) and (min-width: 800px){.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel{--cta-width: 200px;--cta-height: 34px;--logo-size: 100px;--active-product-size: 218px;--inactive-product-size: 100px;display:grid;grid-template-columns:auto 1fr auto;grid-template-rows:1fr auto auto;align-content:normal}.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-shoppable-carousel-active{grid-column:1;grid-row:1/-1;align-self:stretch}.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-shoppable-carousel-body{grid-column:2;grid-row:1;flex-direction:column;align-items:flex-start;text-align:left}.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-shoppable-carousel-thumbnails{grid-column:2;grid-row:2;justify-content:flex-start}.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-carousel-dots{display:none}.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-shoppable-carousel-thumbnail:nth-child(4){display:block}.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-footer{grid-column:3;grid-row:1/-1;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:clamp(4px,1cqw + 1cqh,8px);max-width:var(--cta-width)}.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-footer .str-retail-brand-logo{order:0;margin-left:0;margin-bottom:auto;max-width:var(--cta-width)}.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-footer .str-retail-advertiser{order:0;display:flex}.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-footer .str-retail-cta{order:0;margin-left:0}.str-retail-shoppable-carousel-container .str-retail-shoppable-carousel .str-retail-shoppable-carousel-arrow{display:flex}}.str-icon-wrapper{aspect-ratio:1/1;background-position:center;background-repeat:no-repeat;bottom:0;height:25%;max-height:50px;min-height:26px;position:absolute;right:0;z-index:2}.str-icon-wrapper.str-icon-mute{background-image:url(https://sdk.sharethrough.com/md-icon-volume-off.svg)}.str-icon-wrapper.str-icon-sound{background-image:url(https://sdk.sharethrough.com/md-icon-volume-up.svg)}.video-replay{position:absolute;overflow:hidden;display:flex;z-index:-999;justify-content:center;width:100%;height:100%;top:0}.video-replay.show{z-index:1}.video-replay.show .video-replay-container{transition:opacity .5s ease-in-out;opacity:1}.video-replay .video-replay-container{background-color:#00000080;display:grid;grid-template-columns:auto auto;height:100%;opacity:0;position:absolute;width:100%;z-index:999999}.video-replay .video-replay-container .replay-icon,.video-replay .video-replay-container .see-more-icon{height:100%}.video-replay .video-replay-container .replay-icon .img-icon,.video-replay .video-replay-container .see-more-icon .img-icon{background-repeat:no-repeat;background-size:contain;height:100%;width:40%;margin:auto;background-position:center}.video-replay .video-replay-container .replay-video{width:100%;height:100%}.video-replay .video-replay-container .replay-icon .img-icon{background-image:url(https://sdk.sharethrough.com/replay_combined.png)}.video-replay .video-replay-container .see-more-icon .img-icon{background-image:url(https://sdk.sharethrough.com/seemore_combined.png)}.str-ad-unit{position:relative;background-color:#fff;container-name:ad-unit;container-type:size;width:100%;height:100%}.str-ad-unit.str-responsive-ad .str-react-template .str-compiled-template .str-thumbnail-wrapper img.str-thumbnail{width:100%;height:100%}.str-adunit{cursor:pointer;position:relative}.test_page_form{text-align:center}.str-ad-unit.str-responsive{display:flex}.str-ad-unit.str-responsive .str-react-template,.str-ad-unit.str-responsive .str-react-template .str-compiled-template{display:flex;flex:1}.str-ad-unit.str-responsive .str-react-template .str-compiled-template .str-adunit{flex:1;display:flex;flex-direction:row;max-width:unset;min-width:unset;max-width:100%;max-height:100%}.str-ad-unit.str-responsive .str-react-template .str-compiled-template .str-adunit .str-thumbnail-wrapper{margin:unset;height:unset;width:unset}.str-ad-unit.str-responsive .str-react-template .str-compiled-template .str-adunit .str-thumbnail-wrapper .str-thumbnail{max-width:unset;min-width:unset;max-height:unset;min-height:unset;max-width:inherit;max-height:inherit;min-width:inherit;min-height:inherit}.str-ad-unit.str-responsive .str-react-template .str-compiled-template .str-adunit .str-enhanced-info-wrapper{container-type:size;container-name:enhanced-info;flex:1 1 auto;justify-content:center;font-family:Inter,sans-serif;font-weight:500;display:flex}.str-ad-unit.str-responsive .str-react-template .str-compiled-template .str-adunit .str-enhanced-info-wrapper>div{width:auto;flex:1;height:auto;align-self:auto}.str-ad-unit.str-responsive .str-react-template .str-compiled-template .str-adunit .str-enhanced-info-wrapper .str-enhanced-info{display:flex;padding:8px;font-family:arial,sans-serif}.str-ad-unit.str-responsive .str-react-template .str-compiled-template .str-adunit .str-enhanced-info-wrapper .str-enhanced-info.hide-description .str-text .str-description,.str-ad-unit.str-responsive .str-react-template .str-compiled-template .str-adunit .str-enhanced-info-wrapper .str-enhanced-info.hide-title .str-text .str-title{display:none}@container ad-unit (max-width: 320px) and (max-height: 100px){.str-ad-unit.str-responsive .str-react-template .str-compiled-template .str-adunit .str-enhanced-info-wrapper .str-enhanced-info{padding:6px}}@container ad-unit (max-width: 320px) and (max-height: 50px){.str-ad-unit.str-responsive .str-react-template .str-compiled-template .str-adunit .str-enhanced-info-wrapper .str-enhanced-info{padding:2px}}.str-ad-unit.str-responsive .str-react-template .str-compiled-template .str-adunit .str-enhanced-info-wrapper .str-enhanced-info .str-text{flex:1;display:flex;flex-direction:column;gap:4px;text-align:center}.str-ad-unit.str-responsive .str-react-template .str-compiled-template .str-adunit .str-enhanced-info-wrapper .str-enhanced-info .str-text.str-captions{position:relative}.str-ad-unit.str-responsive .str-react-template .str-compiled-template .str-adunit .str-enhanced-info-wrapper .str-enhanced-info .str-text.str-captions>div{flex:1}.str-ad-unit.str-responsive .str-react-template .str-compiled-template .str-adunit .str-enhanced-info-wrapper .str-enhanced-info .str-text.str-captions .str-title.str-caption-container{display:flex;flex:1;justify-content:center}.str-ad-unit.str-responsive .str-react-template .str-compiled-template .str-adunit .str-enhanced-info-wrapper .str-enhanced-info .str-text .str-title{font:500 clamp(14px,6cqw + 2cqh,20px) "Inter",sans-serif;display:flex;flex:1 1 auto;font-weight:600;align-items:center;justify-content:center}@container ad-unit (max-width: 320px) and (max-height: 100px){.str-ad-unit.str-responsive .str-react-template .str-compiled-template .str-adunit .str-enhanced-info-wrapper .str-enhanced-info .str-text .str-title{display:-webkit-box;-webkit-box-orient:vertical;word-break:break-word;overflow:hidden;-webkit-line-clamp:1;line-clamp:1}}@container ad-unit (max-width: 320px) and (min-height: 51px) and (max-height: 100px){.str-ad-unit.str-responsive .str-react-template .str-compiled-template .str-adunit .str-enhanced-info-wrapper .str-enhanced-info .str-text .str-title{-webkit-line-clamp:3;line-clamp:3}}.str-ad-unit.str-responsive .str-react-template .str-compiled-template .str-adunit .str-enhanced-info-wrapper .str-enhanced-info .str-text .str-description{font:400 clamp(12px,4cqw + 2cqh,16px) "Inter",sans-serif;flex:1 1 auto;align-items:flex-start;justify-content:center;text-align:center;font-weight:400}@container ad-unit (max-width: 320px) and (max-height: 100px){.str-ad-unit.str-responsive .str-react-template .str-compiled-template .str-adunit .str-enhanced-info-wrapper .str-enhanced-info .str-text .str-description{display:none}}@container ad-unit (max-width: 320px) and (max-height: 50px){.str-ad-unit.str-responsive .str-react-template .str-compiled-template .str-adunit .str-enhanced-info-wrapper .str-enhanced-info .str-text{display:flex}.str-ad-unit.str-responsive .str-react-template .str-compiled-template .str-adunit .str-enhanced-info-wrapper{display:none}.str-ad-unit.str-responsive .str-react-template .str-compiled-template .str-adunit .str-enhanced-info-wrapper__native{display:flex}}.str-ad-unit.str-responsive .str-react-template .str-compiled-template .str-adunit .str-thumbnail-wrapper{container-name:thumbnail-wrapper;container-type:size;z-index:5;flex:3 0;width:auto;height:100%;margin:auto 0}@container ad-unit (max-aspect-ratio: 1.5){.str-ad-unit.str-responsive .str-react-template .str-compiled-template .str-adunit .str-thumbnail-wrapper{flex:2 0;width:100%;height:auto;margin:0 auto}}@container ad-unit (max-aspect-ratio: .8){.str-ad-unit.str-responsive .str-react-template .str-compiled-template .str-adunit .str-thumbnail-wrapper{flex:3 0}}.str-ad-unit.str-responsive .str-react-template .str-compiled-template .str-adunit .str-thumbnail-wrapper.str-thumbnail-wrapper-isi{flex:.5!important}.str-ad-unit.str-responsive .str-react-template .str-compiled-template .str-adunit .str-thumbnail-wrapper.str-same-size-pinned{flex:0 0 75%!important}.str-ad-unit.str-responsive .str-react-template .str-compiled-template .str-adunit .str-thumbnail-wrapper .str-thumbnail{margin:auto 0;width:100%;height:100%;position:relative}.str-ad-unit.str-responsive-placement-tallest .str-react-template .str-compiled-template .str-adunit,.str-ad-unit.str-responsive-placement-tallest .str-react-template .str-compiled-template .str-adunit .str-enhanced-info-wrapper .str-enhanced-info{flex-direction:column}.str-ad-unit.str-responsive-placement-tallest .str-react-template .str-compiled-template .str-adunit .str-enhanced-info-wrapper .str-enhanced-info .str-bottom{flex-direction:column-reverse;align-items:center}.str-ad-unit.str-responsive-placement-tallest .str-react-template .str-compiled-template .str-adunit .str-enhanced-info-wrapper .str-enhanced-info .str-text{justify-content:space-around}.str-ad-unit.str-responsive-placement-tallest .str-react-template .str-compiled-template .str-adunit .str-enhanced-info-wrapper .str-enhanced-info .str-text .str-title{line-height:1em}.str-ad-unit.str-responsive-placement-tallest.str-responsive-creative-square .str-react-template .str-compiled-template .str-adunit .str-enhanced-info-wrapper .str-enhanced-info .str-text .str-description,.str-ad-unit.str-responsive-placement-tallest.str-responsive-creative-wide .str-react-template .str-compiled-template .str-adunit .str-enhanced-info-wrapper .str-enhanced-info .str-text .str-description,.str-ad-unit.str-responsive-placement-tallest.str-responsive-creative-widest .str-react-template .str-compiled-template .str-adunit .str-enhanced-info-wrapper .str-enhanced-info .str-text .str-description{display:block}.str-ad-unit.str-responsive-placement-tall .str-react-template .str-compiled-template .str-adunit,.str-ad-unit.str-responsive-placement-tall .str-react-template .str-compiled-template .str-adunit .str-enhanced-info-wrapper .str-enhanced-info{flex-direction:column}.str-ad-unit.str-responsive-placement-tall .str-react-template .str-compiled-template .str-adunit .str-enhanced-info-wrapper .str-enhanced-info .str-bottom{align-items:end;flex-direction:row;justify-content:space-between}@container ad-unit (max-width: 160px){.str-ad-unit.str-responsive-placement-tall .str-react-template .str-compiled-template .str-adunit .str-enhanced-info-wrapper .str-enhanced-info .str-bottom{flex-direction:column-reverse;align-items:center}}.str-ad-unit.str-responsive-placement-tall .str-react-template .str-compiled-template .str-adunit .str-enhanced-info-wrapper .str-enhanced-info .str-bottom .str-cta{align-self:auto}.str-ad-unit.str-responsive-placement-tall .str-react-template .str-compiled-template .str-adunit .str-enhanced-info-wrapper .str-enhanced-info .str-text{justify-content:space-around}.str-ad-unit.str-responsive-placement-square .str-react-template .str-compiled-template .str-adunit,.str-ad-unit.str-responsive-placement-square .str-react-template .str-compiled-template .str-adunit .str-enhanced-info-wrapper .str-enhanced-info{flex-direction:column}.str-ad-unit.str-responsive-placement-square .str-react-template .str-compiled-template .str-adunit .str-enhanced-info-wrapper .str-enhanced-info .str-bottom{align-items:end;flex-direction:row;justify-content:space-between}.str-ad-unit.str-responsive-placement-square .str-react-template .str-compiled-template .str-adunit .str-enhanced-info-wrapper .str-enhanced-info .str-bottom .str-cta{align-self:auto}.str-ad-unit.str-responsive-placement-square .str-react-template .str-compiled-template .str-adunit .str-enhanced-info-wrapper .str-enhanced-info .str-text{justify-content:space-around}.str-ad-unit.str-responsive-placement-square.str-responsive-creative-tallest .str-react-template .str-compiled-template .str-adunit:not(.str-compiled-template-unenhanced),.str-ad-unit.str-responsive-placement-square.str-responsive-creative-tall .str-react-template .str-compiled-template .str-adunit:not(.str-compiled-template-unenhanced){flex-direction:row}.str-ad-unit.str-responsive-placement-square.str-responsive-creative-tallest .str-react-template .str-compiled-template .str-adunit .str-enhanced-info-wrapper .str-enhanced-info .str-bottom,.str-ad-unit.str-responsive-placement-square.str-responsive-creative-tall .str-react-template .str-compiled-template .str-adunit .str-enhanced-info-wrapper .str-enhanced-info .str-bottom{align-items:center}.str-ad-unit.str-responsive-placement-square.str-responsive-creative-tallest .str-react-template .str-compiled-template .str-adunit .str-enhanced-info-wrapper .str-enhanced-info .str-text .str-description,.str-ad-unit.str-responsive-placement-square.str-responsive-creative-tall .str-react-template .str-compiled-template .str-adunit .str-enhanced-info-wrapper .str-enhanced-info .str-text .str-description,.str-ad-unit.str-responsive-placement-square.str-responsive-creative-wide .str-react-template .str-compiled-template .str-adunit .str-enhanced-info-wrapper .str-enhanced-info .str-text .str-description{display:block}@container ad-unit (max-width: 320px) and (max-height: 250px){.str-ad-unit.str-responsive-placement-square.str-responsive-creative-wide .str-react-template .str-compiled-template .str-adunit .str-enhanced-info-wrapper .str-enhanced-info .str-text .str-description{display:none}}.str-ad-unit.str-responsive-placement-square.str-responsive-creative-widest .str-react-template .str-compiled-template .str-adunit .str-enhanced-info-wrapper .str-enhanced-info .str-text .str-description{display:block}.str-ad-unit.str-responsive-placement-wide .str-react-template .str-compiled-template .str-adunit{flex-direction:column}.str-ad-unit.str-responsive-placement-wide .str-react-template .str-compiled-template .str-adunit.str-clickout{flex-direction:row}.str-ad-unit.str-responsive-placement-wide .str-react-template .str-compiled-template .str-adunit .str-enhanced-info-wrapper .str-enhanced-info{flex-direction:column}.str-ad-unit.str-responsive-placement-wide .str-react-template .str-compiled-template .str-adunit .str-enhanced-info-wrapper .str-enhanced-info .str-bottom{align-items:end;flex-direction:row;justify-content:space-between}.str-ad-unit.str-responsive-placement-wide.str-responsive-creative-tallest .str-react-template .str-compiled-template .str-adunit:not(.str-compiled-template-unenhanced),.str-ad-unit.str-responsive-placement-wide.str-responsive-creative-tall .str-react-template .str-compiled-template .str-adunit:not(.str-compiled-template-unenhanced){flex-direction:row}.str-ad-unit.str-responsive-placement-wide.str-responsive-creative-square .str-react-template .str-compiled-template .str-adunit:not(.str-compiled-template-unenhanced){flex-direction:row}.str-ad-unit.str-responsive-placement-wide.str-responsive-creative-widest .str-react-template .str-compiled-template .str-adunit .str-enhanced-info-wrapper .str-enhanced-info .str-text .str-description{display:block}.str-ad-unit.str-responsive-placement-widest .str-react-template .str-compiled-template .str-adunit .str-enhanced-info-wrapper .str-enhanced-info{flex-direction:column}.str-ad-unit.str-responsive-placement-widest .str-react-template .str-compiled-template .str-adunit .str-enhanced-info-wrapper .str-enhanced-info .str-bottom{align-items:end;flex-direction:row;justify-content:space-between}.str-ad-unit.str-responsive-placement-widest .str-react-template .str-compiled-template .str-adunit .str-enhanced-info-wrapper .str-enhanced-info .str-text{justify-content:space-evenly;align-items:center}@container ad-unit (max-width: 320px) and (max-height: 50px){.str-ad-unit.str-responsive-placement-widest .str-react-template .str-compiled-template .str-adunit .str-enhanced-info-wrapper .str-enhanced-info .str-text .str-title{text-align:left;flex:none}}.str-ad-unit.str-responsive-placement-widest .str-react-template .str-compiled-template .str-adunit .str-enhanced-info-wrapper .str-enhanced-info .str-text .str-description{display:flex}@container ad-unit (max-width: 320px) and (max-height: 50px){.str-ad-unit.str-responsive-placement-widest .str-react-template .str-compiled-template .str-adunit .str-enhanced-info-wrapper .str-enhanced-info .str-text .str-description{display:none}}.str-ad-unit.str-responsive-placement-widest.str-responsive-creative-wide .str-react-template .str-compiled-template .str-adunit,.str-ad-unit.str-responsive-placement-widest.str-responsive-creative-widest .str-react-template .str-compiled-template .str-adunit{flex-wrap:wrap}@container ad-unit (min-width: 969px) and (min-height: 249px){.str-ad-unit.str-responsive-placement-widest.str-responsive-creative-widest .str-react-template .str-compiled-template .str-adunit:not(.str-compiled-template-unenhanced){flex-direction:column}.str-ad-unit.str-responsive-placement-widest.str-responsive-creative-widest .str-react-template .str-compiled-template .str-adunit:not(.str-compiled-template-unenhanced) .str-thumbnail-wrapper{align-self:center;width:100%}}.str-ad-unit.str-responsive-placement-widest.str-responsive-creative-square .str-react-template .str-compiled-template .str-adunit .str-enhanced-info-wrapper .str-enhanced-info .str-bottom,.str-ad-unit.str-responsive-placement-widest.str-responsive-creative-tall .str-react-template .str-compiled-template .str-adunit .str-enhanced-info-wrapper .str-enhanced-info .str-bottom,.str-ad-unit.str-responsive-placement-widest.str-responsive-creative-tallest .str-react-template .str-compiled-template .str-adunit .str-enhanced-info-wrapper .str-enhanced-info .str-bottom{align-items:end;flex-direction:row}@media screen and (max-height:150px){.str-ad-unit.str-responsive-placement-widest.str-responsive-creative-widest .str-react-template .str-compiled-template .str-adunit .str-enhanced-info-wrapper .str-enhanced-info .str-text .str-description{display:none}}.str-ad-unit.str-responsive .str-react-template .str-compiled-template .str-adunit .str-thumbnail-wrapper.str-thumbnail-wrapper-outstream{display:flex;flex:0 1 177.7777777778cqh}@container ad-unit (max-aspect-ratio: 1.5){.str-ad-unit.str-responsive .str-react-template .str-compiled-template .str-adunit .str-thumbnail-wrapper.str-thumbnail-wrapper-outstream{flex:0 1 56.25cqw}}.str-ad-unit.str-responsive .str-react-template .str-compiled-template .str-adunit .str-thumbnail-wrapper .str-thumbnail .str-video-container,.str-ad-unit.str-responsive .str-react-template .str-compiled-template .str-adunit .str-thumbnail-wrapper .str-thumbnail .video-wrapper{height:100%;width:100%}.str-ad-unit.str-responsive .str-react-template .str-compiled-template .str-adunit .str-thumbnail-wrapper .str-thumbnail .str-video-container{background-color:#000;position:relative;flex:1}.str-ad-unit.str-responsive .str-react-template .str-compiled-template .str-adunit .str-thumbnail-wrapper .str-thumbnail .str-video-container .blank-video{display:none}.str-ad-unit.str-responsive .str-react-template .str-compiled-template .str-adunit .str-thumbnail-wrapper .str-thumbnail .str-video-container .video-replay .replay-video{max-width:100%}.str-ad-unit.str-responsive .str-react-template .str-compiled-template .str-adunit .str-thumbnail-wrapper .str-thumbnail .str-video-container .video-replay .video-replay-container>div{padding-top:8px;height:calc(100% - 16px)}.str-ad-unit.str-responsive .str-react-template .str-compiled-template .str-adunit .str-thumbnail-wrapper .str-thumbnail .str-video-container .video-wrapper{display:flex;flex:1}.str-ad-unit.str-responsive .str-react-template .str-compiled-template .str-compiled-template-unenhanced .str-thumbnail-wrapper.str-thumbnail-wrapper-outstream{aspect-ratio:16/9;flex:1 1 auto}.str-ad-unit.str-responsive .str-vast-container{margin:unset}
/*$vite$:1*/`),
    document.head.appendChild($n);
  function ir(e, t) {
    let r = window.parent,
      n = 0;
    for (; r && n < t; )
      try {
        if (r[e]) return r[e];
        if (r === r.parent) break;
        (r = r.parent), n++;
      } catch {
        try {
          if (r === r.parent) break;
          (r = r.parent), n++;
        } catch {
          break;
        }
      }
  }
  function Fn(e) {
    if (!e || typeof e != "object")
      return { valid: !1, path: "", expected: "object", received: typeof e };
    const t = e;
    return typeof t.width != "number" || t.width <= 0
      ? {
          valid: !1,
          path: "width",
          expected: "positive number",
          received: typeof t.width,
        }
      : typeof t.height != "number" || t.height <= 0
      ? {
          valid: !1,
          path: "height",
          expected: "positive number",
          received: typeof t.height,
        }
      : { valid: !0 };
  }
  var ht,
    C,
    Gn,
    jn,
    Ie,
    qn,
    Wn,
    Yn,
    Xn,
    or,
    sr,
    cr,
    Kn,
    mt = {},
    ft = [],
    Qs = /acit|ex(?:s|g|n|p|$)|rph|grid|ows|mnc|ntw|ine[ch]|zoo|^ord|itera/i,
    Ye = Array.isArray;
  function ve(e, t) {
    for (var r in t) e[r] = t[r];
    return e;
  }
  function lr(e) {
    e && e.parentNode && e.parentNode.removeChild(e);
  }
  function dr(e, t, r) {
    var n,
      a,
      i,
      o = {};
    for (i in t)
      i == "key" ? (n = t[i]) : i == "ref" ? (a = t[i]) : (o[i] = t[i]);
    if (
      (arguments.length > 2 &&
        (o.children = arguments.length > 3 ? ht.call(arguments, 2) : r),
      typeof e == "function" && e.defaultProps != null)
    )
      for (i in e.defaultProps) o[i] === void 0 && (o[i] = e.defaultProps[i]);
    return gt(e, o, n, a, null);
  }
  function gt(e, t, r, n, a) {
    var i = {
      type: e,
      props: t,
      key: r,
      ref: n,
      __k: null,
      __: null,
      __b: 0,
      __e: null,
      __c: null,
      constructor: void 0,
      __v: a ?? ++Gn,
      __i: -1,
      __u: 0,
    };
    return a == null && C.vnode != null && C.vnode(i), i;
  }
  function me() {
    return { current: null };
  }
  function G(e) {
    return e.children;
  }
  function se(e, t) {
    (this.props = e), (this.context = t);
  }
  function ze(e, t) {
    if (t == null) return e.__ ? ze(e.__, e.__i + 1) : null;
    for (var r; t < e.__k.length; t++)
      if ((r = e.__k[t]) != null && r.__e != null) return r.__e;
    return typeof e.type == "function" ? ze(e) : null;
  }
  function Js(e) {
    if (e.__P && e.__d) {
      var t = e.__v,
        r = t.__e,
        n = [],
        a = [],
        i = ve({}, t);
      (i.__v = t.__v + 1),
        C.vnode && C.vnode(i),
        pr(
          e.__P,
          i,
          t,
          e.__n,
          e.__P.namespaceURI,
          32 & t.__u ? [r] : null,
          n,
          r ?? ze(t),
          !!(32 & t.__u),
          a
        ),
        (i.__v = t.__v),
        (i.__.__k[i.__i] = i),
        ra(n, i, a),
        (t.__e = t.__ = null),
        i.__e != r && Qn(i);
    }
  }
  function Qn(e) {
    if ((e = e.__) != null && e.__c != null)
      return (
        (e.__e = e.__c.base = null),
        e.__k.some(function (t) {
          if (t != null && t.__e != null) return (e.__e = e.__c.base = t.__e);
        }),
        Qn(e)
      );
  }
  function ur(e) {
    ((!e.__d && (e.__d = !0) && Ie.push(e) && !bt.__r++) ||
      qn != C.debounceRendering) &&
      ((qn = C.debounceRendering) || Wn)(bt);
  }
  function bt() {
    for (var e, t = 1; Ie.length; )
      Ie.length > t && Ie.sort(Yn), (e = Ie.shift()), (t = Ie.length), Js(e);
    bt.__r = 0;
  }
  function Jn(e, t, r, n, a, i, o, c, l, u, p) {
    var h,
      m,
      f,
      g,
      w,
      y,
      v,
      x = (n && n.__k) || ft,
      E = t.length;
    for (l = Zs(r, t, x, l, E), h = 0; h < E; h++)
      (f = r.__k[h]) != null &&
        ((m = (f.__i != -1 && x[f.__i]) || mt),
        (f.__i = h),
        (y = pr(e, f, m, a, i, o, c, l, u, p)),
        (g = f.__e),
        f.ref &&
          m.ref != f.ref &&
          (m.ref && mr(m.ref, null, f), p.push(f.ref, f.__c || g, f)),
        w == null && g != null && (w = g),
        (v = !!(4 & f.__u)) || m.__k === f.__k
          ? (l = Zn(f, l, e, v))
          : typeof f.type == "function" && y !== void 0
          ? (l = y)
          : g && (l = g.nextSibling),
        (f.__u &= -7));
    return (r.__e = w), l;
  }
  function Zs(e, t, r, n, a) {
    var i,
      o,
      c,
      l,
      u,
      p = r.length,
      h = p,
      m = 0;
    for (e.__k = new Array(a), i = 0; i < a; i++)
      (o = t[i]) != null && typeof o != "boolean" && typeof o != "function"
        ? (typeof o == "string" ||
          typeof o == "number" ||
          typeof o == "bigint" ||
          o.constructor == String
            ? (o = e.__k[i] = gt(null, o, null, null, null))
            : Ye(o)
            ? (o = e.__k[i] = gt(G, { children: o }, null, null, null))
            : o.constructor === void 0 && o.__b > 0
            ? (o = e.__k[i] =
                gt(o.type, o.props, o.key, o.ref ? o.ref : null, o.__v))
            : (e.__k[i] = o),
          (l = i + m),
          (o.__ = e),
          (o.__b = e.__b + 1),
          (c = null),
          (u = o.__i = ec(o, r, l, h)) != -1 &&
            (h--, (c = r[u]) && (c.__u |= 2)),
          c == null || c.__v == null
            ? (u == -1 && (a > p ? m-- : a < p && m++),
              typeof o.type != "function" && (o.__u |= 4))
            : u != l &&
              (u == l - 1
                ? m--
                : u == l + 1
                ? m++
                : (u > l ? m-- : m++, (o.__u |= 4))))
        : (e.__k[i] = null);
    if (h)
      for (i = 0; i < p; i++)
        (c = r[i]) != null &&
          (2 & c.__u) == 0 &&
          (c.__e == n && (n = ze(c)), aa(c, c));
    return n;
  }
  function Zn(e, t, r, n) {
    var a, i;
    if (typeof e.type == "function") {
      for (a = e.__k, i = 0; a && i < a.length; i++)
        a[i] && ((a[i].__ = e), (t = Zn(a[i], t, r, n)));
      return t;
    }
    e.__e != t &&
      (n &&
        (t && e.type && !t.parentNode && (t = ze(e)),
        r.insertBefore(e.__e, t || null)),
      (t = e.__e));
    do t = t && t.nextSibling;
    while (t != null && t.nodeType == 8);
    return t;
  }
  function vt(e, t) {
    return (
      (t = t || []),
      e == null ||
        typeof e == "boolean" ||
        (Ye(e)
          ? e.some(function (r) {
              vt(r, t);
            })
          : t.push(e)),
      t
    );
  }
  function ec(e, t, r, n) {
    var a,
      i,
      o,
      c = e.key,
      l = e.type,
      u = t[r],
      p = u != null && (2 & u.__u) == 0;
    if ((u === null && c == null) || (p && c == u.key && l == u.type)) return r;
    if (n > (p ? 1 : 0)) {
      for (a = r - 1, i = r + 1; a >= 0 || i < t.length; )
        if (
          (u = t[(o = a >= 0 ? a-- : i++)]) != null &&
          (2 & u.__u) == 0 &&
          c == u.key &&
          l == u.type
        )
          return o;
    }
    return -1;
  }
  function ea(e, t, r) {
    t[0] == "-"
      ? e.setProperty(t, r ?? "")
      : (e[t] =
          r == null ? "" : typeof r != "number" || Qs.test(t) ? r : r + "px");
  }
  function _t(e, t, r, n, a) {
    var i, o;
    e: if (t == "style")
      if (typeof r == "string") e.style.cssText = r;
      else {
        if ((typeof n == "string" && (e.style.cssText = n = ""), n))
          for (t in n) (r && t in r) || ea(e.style, t, "");
        if (r) for (t in r) (n && r[t] == n[t]) || ea(e.style, t, r[t]);
      }
    else if (t[0] == "o" && t[1] == "n")
      (i = t != (t = t.replace(Xn, "$1"))),
        (o = t.toLowerCase()),
        (t =
          o in e || t == "onFocusOut" || t == "onFocusIn"
            ? o.slice(2)
            : t.slice(2)),
        e.l || (e.l = {}),
        (e.l[t + i] = r),
        r
          ? n
            ? (r.u = n.u)
            : ((r.u = or), e.addEventListener(t, i ? cr : sr, i))
          : e.removeEventListener(t, i ? cr : sr, i);
    else {
      if (a == "http://www.w3.org/2000/svg")
        t = t.replace(/xlink(H|:h)/, "h").replace(/sName$/, "s");
      else if (
        t != "width" &&
        t != "height" &&
        t != "href" &&
        t != "list" &&
        t != "form" &&
        t != "tabIndex" &&
        t != "download" &&
        t != "rowSpan" &&
        t != "colSpan" &&
        t != "role" &&
        t != "popover" &&
        t in e
      )
        try {
          e[t] = r ?? "";
          break e;
        } catch {}
      typeof r == "function" ||
        (r == null || (r === !1 && t[4] != "-")
          ? e.removeAttribute(t)
          : e.setAttribute(t, t == "popover" && r == 1 ? "" : r));
    }
  }
  function ta(e) {
    return function (t) {
      if (this.l) {
        var r = this.l[t.type + e];
        if (t.t == null) t.t = or++;
        else if (t.t < r.u) return;
        return r(C.event ? C.event(t) : t);
      }
    };
  }
  function pr(e, t, r, n, a, i, o, c, l, u) {
    var p,
      h,
      m,
      f,
      g,
      w,
      y,
      v,
      x,
      E,
      _,
      k,
      T,
      P,
      W,
      Y = t.type;
    if (t.constructor !== void 0) return null;
    128 & r.__u && ((l = !!(32 & r.__u)), (i = [(c = t.__e = r.__e)])),
      (p = C.__b) && p(t);
    e: if (typeof Y == "function")
      try {
        if (
          ((v = t.props),
          (x = "prototype" in Y && Y.prototype.render),
          (E = (p = Y.contextType) && n[p.__c]),
          (_ = p ? (E ? E.props.value : p.__) : n),
          r.__c
            ? (y = (h = t.__c = r.__c).__ = h.__E)
            : (x
                ? (t.__c = h = new Y(v, _))
                : ((t.__c = h = new se(v, _)),
                  (h.constructor = Y),
                  (h.render = rc)),
              E && E.sub(h),
              h.state || (h.state = {}),
              (h.__n = n),
              (m = h.__d = !0),
              (h.__h = []),
              (h._sb = [])),
          x && h.__s == null && (h.__s = h.state),
          x &&
            Y.getDerivedStateFromProps != null &&
            (h.__s == h.state && (h.__s = ve({}, h.__s)),
            ve(h.__s, Y.getDerivedStateFromProps(v, h.__s))),
          (f = h.props),
          (g = h.state),
          (h.__v = t),
          m)
        )
          x &&
            Y.getDerivedStateFromProps == null &&
            h.componentWillMount != null &&
            h.componentWillMount(),
            x && h.componentDidMount != null && h.__h.push(h.componentDidMount);
        else {
          if (
            (x &&
              Y.getDerivedStateFromProps == null &&
              v !== f &&
              h.componentWillReceiveProps != null &&
              h.componentWillReceiveProps(v, _),
            t.__v == r.__v ||
              (!h.__e &&
                h.shouldComponentUpdate != null &&
                h.shouldComponentUpdate(v, h.__s, _) === !1))
          ) {
            t.__v != r.__v && ((h.props = v), (h.state = h.__s), (h.__d = !1)),
              (t.__e = r.__e),
              (t.__k = r.__k),
              t.__k.some(function (ye) {
                ye && (ye.__ = t);
              }),
              ft.push.apply(h.__h, h._sb),
              (h._sb = []),
              h.__h.length && o.push(h);
            break e;
          }
          h.componentWillUpdate != null && h.componentWillUpdate(v, h.__s, _),
            x &&
              h.componentDidUpdate != null &&
              h.__h.push(function () {
                h.componentDidUpdate(f, g, w);
              });
        }
        if (
          ((h.context = _),
          (h.props = v),
          (h.__P = e),
          (h.__e = !1),
          (k = C.__r),
          (T = 0),
          x)
        )
          (h.state = h.__s),
            (h.__d = !1),
            k && k(t),
            (p = h.render(h.props, h.state, h.context)),
            ft.push.apply(h.__h, h._sb),
            (h._sb = []);
        else
          do
            (h.__d = !1),
              k && k(t),
              (p = h.render(h.props, h.state, h.context)),
              (h.state = h.__s);
          while (h.__d && ++T < 25);
        (h.state = h.__s),
          h.getChildContext != null && (n = ve(ve({}, n), h.getChildContext())),
          x &&
            !m &&
            h.getSnapshotBeforeUpdate != null &&
            (w = h.getSnapshotBeforeUpdate(f, g)),
          (P =
            p != null && p.type === G && p.key == null
              ? na(p.props.children)
              : p),
          (c = Jn(e, Ye(P) ? P : [P], t, r, n, a, i, o, c, l, u)),
          (h.base = t.__e),
          (t.__u &= -161),
          h.__h.length && o.push(h),
          y && (h.__E = h.__ = null);
      } catch (ye) {
        if (((t.__v = null), l || i != null))
          if (ye.then) {
            for (
              t.__u |= l ? 160 : 128;
              c && c.nodeType == 8 && c.nextSibling;

            )
              c = c.nextSibling;
            (i[i.indexOf(c)] = null), (t.__e = c);
          } else {
            for (W = i.length; W--; ) lr(i[W]);
            hr(t);
          }
        else (t.__e = r.__e), (t.__k = r.__k), ye.then || hr(t);
        C.__e(ye, t, r);
      }
    else
      i == null && t.__v == r.__v
        ? ((t.__k = r.__k), (t.__e = r.__e))
        : (c = t.__e = tc(r.__e, t, r, n, a, i, o, l, u));
    return (p = C.diffed) && p(t), 128 & t.__u ? void 0 : c;
  }
  function hr(e) {
    e && (e.__c && (e.__c.__e = !0), e.__k && e.__k.some(hr));
  }
  function ra(e, t, r) {
    for (var n = 0; n < r.length; n++) mr(r[n], r[++n], r[++n]);
    C.__c && C.__c(t, e),
      e.some(function (a) {
        try {
          (e = a.__h),
            (a.__h = []),
            e.some(function (i) {
              i.call(a);
            });
        } catch (i) {
          C.__e(i, a.__v);
        }
      });
  }
  function na(e) {
    return typeof e != "object" || e == null || e.__b > 0
      ? e
      : Ye(e)
      ? e.map(na)
      : ve({}, e);
  }
  function tc(e, t, r, n, a, i, o, c, l) {
    var u,
      p,
      h,
      m,
      f,
      g,
      w,
      y = r.props || mt,
      v = t.props,
      x = t.type;
    if (
      (x == "svg"
        ? (a = "http://www.w3.org/2000/svg")
        : x == "math"
        ? (a = "http://www.w3.org/1998/Math/MathML")
        : a || (a = "http://www.w3.org/1999/xhtml"),
      i != null)
    ) {
      for (u = 0; u < i.length; u++)
        if (
          (f = i[u]) &&
          "setAttribute" in f == !!x &&
          (x ? f.localName == x : f.nodeType == 3)
        ) {
          (e = f), (i[u] = null);
          break;
        }
    }
    if (e == null) {
      if (x == null) return document.createTextNode(v);
      (e = document.createElementNS(a, x, v.is && v)),
        c && (C.__m && C.__m(t, i), (c = !1)),
        (i = null);
    }
    if (x == null) y === v || (c && e.data == v) || (e.data = v);
    else {
      if (((i = i && ht.call(e.childNodes)), !c && i != null))
        for (y = {}, u = 0; u < e.attributes.length; u++)
          y[(f = e.attributes[u]).name] = f.value;
      for (u in y)
        (f = y[u]),
          u == "dangerouslySetInnerHTML"
            ? (h = f)
            : u == "children" ||
              u in v ||
              (u == "value" && "defaultValue" in v) ||
              (u == "checked" && "defaultChecked" in v) ||
              _t(e, u, null, f, a);
      for (u in v)
        (f = v[u]),
          u == "children"
            ? (m = f)
            : u == "dangerouslySetInnerHTML"
            ? (p = f)
            : u == "value"
            ? (g = f)
            : u == "checked"
            ? (w = f)
            : (c && typeof f != "function") ||
              y[u] === f ||
              _t(e, u, f, y[u], a);
      if (p)
        c ||
          (h && (p.__html == h.__html || p.__html == e.innerHTML)) ||
          (e.innerHTML = p.__html),
          (t.__k = []);
      else if (
        (h && (e.innerHTML = ""),
        Jn(
          t.type == "template" ? e.content : e,
          Ye(m) ? m : [m],
          t,
          r,
          n,
          x == "foreignObject" ? "http://www.w3.org/1999/xhtml" : a,
          i,
          o,
          i ? i[0] : r.__k && ze(r, 0),
          c,
          l
        ),
        i != null)
      )
        for (u = i.length; u--; ) lr(i[u]);
      c ||
        ((u = "value"),
        x == "progress" && g == null
          ? e.removeAttribute("value")
          : g != null &&
            (g !== e[u] ||
              (x == "progress" && !g) ||
              (x == "option" && g != y[u])) &&
            _t(e, u, g, y[u], a),
        (u = "checked"),
        w != null && w != e[u] && _t(e, u, w, y[u], a));
    }
    return e;
  }
  function mr(e, t, r) {
    try {
      if (typeof e == "function") {
        var n = typeof e.__u == "function";
        n && e.__u(), (n && t == null) || (e.__u = e(t));
      } else e.current = t;
    } catch (a) {
      C.__e(a, r);
    }
  }
  function aa(e, t, r) {
    var n, a;
    if (
      (C.unmount && C.unmount(e),
      (n = e.ref) && ((n.current && n.current != e.__e) || mr(n, null, t)),
      (n = e.__c) != null)
    ) {
      if (n.componentWillUnmount)
        try {
          n.componentWillUnmount();
        } catch (i) {
          C.__e(i, t);
        }
      n.base = n.__P = null;
    }
    if ((n = e.__k))
      for (a = 0; a < n.length; a++)
        n[a] && aa(n[a], t, r || typeof e.type != "function");
    r || lr(e.__e), (e.__c = e.__ = e.__e = void 0);
  }
  function rc(e, t, r) {
    return this.constructor(e, r);
  }
  function nc(e, t, r) {
    var n, a, i, o;
    t == document && (t = document.documentElement),
      C.__ && C.__(e, t),
      (a = (n = !1) ? null : t.__k),
      (i = []),
      (o = []),
      pr(
        t,
        (e = t.__k = dr(G, null, [e])),
        a || mt,
        mt,
        t.namespaceURI,
        a ? null : t.firstChild ? ht.call(t.childNodes) : null,
        i,
        a ? a.__e : t.firstChild,
        n,
        o
      ),
      ra(i, e, o);
  }
  function ue(e) {
    function t(r) {
      var n, a;
      return (
        this.getChildContext ||
          ((n = new Set()),
          ((a = {})[t.__c] = this),
          (this.getChildContext = function () {
            return a;
          }),
          (this.componentWillUnmount = function () {
            n = null;
          }),
          (this.shouldComponentUpdate = function (i) {
            this.props.value != i.value &&
              n.forEach(function (o) {
                (o.__e = !0), ur(o);
              });
          }),
          (this.sub = function (i) {
            n.add(i);
            var o = i.componentWillUnmount;
            i.componentWillUnmount = function () {
              n && n.delete(i), o && o.call(i);
            };
          })),
        r.children
      );
    }
    return (
      (t.__c = "__cC" + Kn++),
      (t.__ = e),
      (t.Provider =
        t.__l =
        (t.Consumer = function (r, n) {
          return r.children(n);
        }).contextType =
          t),
      t
    );
  }
  (ht = ft.slice),
    (C = {
      __e: function (e, t, r, n) {
        for (var a, i, o; (t = t.__); )
          if ((a = t.__c) && !a.__)
            try {
              if (
                ((i = a.constructor) &&
                  i.getDerivedStateFromError != null &&
                  (a.setState(i.getDerivedStateFromError(e)), (o = a.__d)),
                a.componentDidCatch != null &&
                  (a.componentDidCatch(e, n || {}), (o = a.__d)),
                o)
              )
                return (a.__E = a);
            } catch (c) {
              e = c;
            }
        throw e;
      },
    }),
    (Gn = 0),
    (jn = function (e) {
      return e != null && e.constructor === void 0;
    }),
    (se.prototype.setState = function (e, t) {
      var r;
      (r =
        this.__s != null && this.__s != this.state
          ? this.__s
          : (this.__s = ve({}, this.state))),
        typeof e == "function" && (e = e(ve({}, r), this.props)),
        e && ve(r, e),
        e != null && this.__v && (t && this._sb.push(t), ur(this));
    }),
    (se.prototype.forceUpdate = function (e) {
      this.__v && ((this.__e = !0), e && this.__h.push(e), ur(this));
    }),
    (se.prototype.render = G),
    (Ie = []),
    (Wn =
      typeof Promise == "function"
        ? Promise.prototype.then.bind(Promise.resolve())
        : setTimeout),
    (Yn = function (e, t) {
      return e.__v.__b - t.__v.__b;
    }),
    (bt.__r = 0),
    (Xn = /(PointerCapture)$|Capture$/i),
    (or = 0),
    (sr = ta(!1)),
    (cr = ta(!0)),
    (Kn = 0);
  var ac = 0;
  function d(e, t, r, n, a, i) {
    t || (t = {});
    var o,
      c,
      l = t;
    if ("ref" in l)
      for (c in ((l = {}), t)) c == "ref" ? (o = t[c]) : (l[c] = t[c]);
    var u = {
      type: e,
      props: l,
      key: r,
      ref: o,
      __k: null,
      __: null,
      __b: 0,
      __e: null,
      __c: null,
      constructor: void 0,
      __v: --ac,
      __i: -1,
      __u: 0,
      __source: a,
      __self: i,
    };
    if (typeof e == "function" && (o = e.defaultProps))
      for (c in o) l[c] === void 0 && (l[c] = o[c]);
    return C.vnode && C.vnode(u), u;
  }
  var xe,
    L,
    fr,
    ia,
    Ue = 0,
    oa = [],
    j = C,
    sa = j.__b,
    ca = j.__r,
    la = j.diffed,
    da = j.__c,
    ua = j.unmount,
    pa = j.__;
  function Me(e, t) {
    j.__h && j.__h(L, e, Ue || t), (Ue = 0);
    var r = L.__H || (L.__H = { __: [], __h: [] });
    return e >= r.__.length && r.__.push({}), r.__[e];
  }
  function V(e) {
    return (Ue = 1), ic(fa, e);
  }
  function ic(e, t, r) {
    var n = Me(xe++, 2);
    if (
      ((n.t = e),
      !n.__c &&
        ((n.__ = [
          r ? r(t) : fa(void 0, t),
          function (c) {
            var l = n.__N ? n.__N[0] : n.__[0],
              u = n.t(l, c);
            l !== u && ((n.__N = [u, n.__[1]]), n.__c.setState({}));
          },
        ]),
        (n.__c = L),
        !L.__f))
    ) {
      var a = function (c, l, u) {
        if (!n.__c.__H) return !0;
        var p = n.__c.__H.__.filter(function (m) {
          return m.__c;
        });
        if (
          p.every(function (m) {
            return !m.__N;
          })
        )
          return !i || i.call(this, c, l, u);
        var h = n.__c.props !== c;
        return (
          p.some(function (m) {
            if (m.__N) {
              var f = m.__[0];
              (m.__ = m.__N), (m.__N = void 0), f !== m.__[0] && (h = !0);
            }
          }),
          (i && i.call(this, c, l, u)) || h
        );
      };
      L.__f = !0;
      var i = L.shouldComponentUpdate,
        o = L.componentWillUpdate;
      (L.componentWillUpdate = function (c, l, u) {
        if (this.__e) {
          var p = i;
          (i = void 0), a(c, l, u), (i = p);
        }
        o && o.call(this, c, l, u);
      }),
        (L.shouldComponentUpdate = a);
    }
    return n.__N || n.__;
  }
  function A(e, t) {
    var r = Me(xe++, 3);
    !j.__s && br(r.__H, t) && ((r.__ = e), (r.u = t), L.__H.__h.push(r));
  }
  function ha(e, t) {
    var r = Me(xe++, 4);
    !j.__s && br(r.__H, t) && ((r.__ = e), (r.u = t), L.__h.push(r));
  }
  function O(e) {
    return (
      (Ue = 5),
      ce(function () {
        return { current: e };
      }, [])
    );
  }
  function oc(e, t, r) {
    (Ue = 6),
      ha(
        function () {
          if (typeof e == "function") {
            var n = e(t());
            return function () {
              e(null), n && typeof n == "function" && n();
            };
          }
          if (e)
            return (
              (e.current = t()),
              function () {
                return (e.current = null);
              }
            );
        },
        r == null ? r : r.concat(e)
      );
  }
  function ce(e, t) {
    var r = Me(xe++, 7);
    return br(r.__H, t) && ((r.__ = e()), (r.__H = t), (r.__h = e)), r.__;
  }
  function fe(e, t) {
    return (
      (Ue = 8),
      ce(function () {
        return e;
      }, t)
    );
  }
  function ae(e) {
    var t = L.context[e.__c],
      r = Me(xe++, 9);
    return (
      (r.c = e),
      t ? (r.__ == null && ((r.__ = !0), t.sub(L)), t.props.value) : e.__
    );
  }
  function sc(e) {
    var t = Me(xe++, 10),
      r = V();
    return (
      (t.__ = e),
      L.componentDidCatch ||
        (L.componentDidCatch = function (n, a) {
          t.__ && t.__(n, a), r[1](n);
        }),
      [
        r[0],
        function () {
          r[1](void 0);
        },
      ]
    );
  }
  function cc() {
    for (var e; (e = oa.shift()); ) {
      var t = e.__H;
      if (e.__P && t)
        try {
          t.__h.some(wt), t.__h.some(gr), (t.__h = []);
        } catch (r) {
          (t.__h = []), j.__e(r, e.__v);
        }
    }
  }
  (j.__b = function (e) {
    (L = null), sa && sa(e);
  }),
    (j.__ = function (e, t) {
      e && t.__k && t.__k.__m && (e.__m = t.__k.__m), pa && pa(e, t);
    }),
    (j.__r = function (e) {
      ca && ca(e), (xe = 0);
      var t = (L = e.__c).__H;
      t &&
        (fr === L
          ? ((t.__h = []),
            (L.__h = []),
            t.__.some(function (r) {
              r.__N && (r.__ = r.__N), (r.u = r.__N = void 0);
            }))
          : (t.__h.some(wt), t.__h.some(gr), (t.__h = []), (xe = 0))),
        (fr = L);
    }),
    (j.diffed = function (e) {
      la && la(e);
      var t = e.__c;
      t &&
        t.__H &&
        (t.__H.__h.length &&
          ((oa.push(t) !== 1 && ia === j.requestAnimationFrame) ||
            ((ia = j.requestAnimationFrame) || lc)(cc)),
        t.__H.__.some(function (r) {
          r.u && (r.__H = r.u), (r.u = void 0);
        })),
        (fr = L = null);
    }),
    (j.__c = function (e, t) {
      t.some(function (r) {
        try {
          r.__h.some(wt),
            (r.__h = r.__h.filter(function (n) {
              return !n.__ || gr(n);
            }));
        } catch (n) {
          t.some(function (a) {
            a.__h && (a.__h = []);
          }),
            (t = []),
            j.__e(n, r.__v);
        }
      }),
        da && da(e, t);
    }),
    (j.unmount = function (e) {
      ua && ua(e);
      var t,
        r = e.__c;
      r &&
        r.__H &&
        (r.__H.__.some(function (n) {
          try {
            wt(n);
          } catch (a) {
            t = a;
          }
        }),
        (r.__H = void 0),
        t && j.__e(t, r.__v));
    });
  var ma = typeof requestAnimationFrame == "function";
  function lc(e) {
    var t,
      r = function () {
        clearTimeout(n), ma && cancelAnimationFrame(t), setTimeout(e);
      },
      n = setTimeout(r, 35);
    ma && (t = requestAnimationFrame(r));
  }
  function wt(e) {
    var t = L,
      r = e.__c;
    typeof r == "function" && ((e.__c = void 0), r()), (L = t);
  }
  function gr(e) {
    var t = L;
    (e.__c = e.__()), (L = t);
  }
  function br(e, t) {
    return (
      !e ||
      e.length !== t.length ||
      t.some(function (r, n) {
        return r !== e[n];
      })
    );
  }
  function fa(e, t) {
    return typeof t == "function" ? t(e) : t;
  }
  const ga = ue(null),
    dc = ({ configuration: e, children: t }) =>
      d(ga.Provider, { value: e, children: t }),
    uc = () => ae(ga);
  var F = ((e) => (
      (e[(e.ICON = 1)] = "ICON"),
      (e[(e.LOGO = 2)] = "LOGO"),
      (e[(e.MAIN = 3)] = "MAIN"),
      (e[(e.PRIME_LOGO = 512)] = "PRIME_LOGO"),
      (e[(e.AVAILABLE_ON_AMAZON = 513)] = "AVAILABLE_ON_AMAZON"),
      e
    ))(F || {}),
    I = ((e) => (
      (e[(e.SPONSORED = 1)] = "SPONSORED"),
      (e[(e.DESC = 2)] = "DESC"),
      (e[(e.RATING = 3)] = "RATING"),
      (e[(e.LIKES = 4)] = "LIKES"),
      (e[(e.DOWNLOADS = 5)] = "DOWNLOADS"),
      (e[(e.PRICE = 6)] = "PRICE"),
      (e[(e.SALEPRICE = 7)] = "SALEPRICE"),
      (e[(e.PHONE = 8)] = "PHONE"),
      (e[(e.ADDRESS = 9)] = "ADDRESS"),
      (e[(e.DESC2 = 10)] = "DESC2"),
      (e[(e.DISPLAYURL = 11)] = "DISPLAYURL"),
      (e[(e.CTATEXT = 12)] = "CTATEXT"),
      (e[(e.OPT_OUT = 501)] = "OPT_OUT"),
      (e[(e.OPT_OUT_URL = 502)] = "OPT_OUT_URL"),
      (e[(e.ISI = 503)] = "ISI"),
      (e[(e.BANNER = 504)] = "BANNER"),
      (e[(e.CALL_TO_ACTION = 505)] = "CALL_TO_ACTION"),
      (e[(e.BADGE = 507)] = "BADGE"),
      (e[(e.REVIEW = 508)] = "REVIEW"),
      (e[(e.CLIMATE_PLEDGE = 511)] = "CLIMATE_PLEDGE"),
      (e[(e.COUPON = 512)] = "COUPON"),
      (e[(e.SHOPPABLE = 520)] = "SHOPPABLE"),
      e
    ))(I || {}),
    B = ((e) => (
      (e[(e.Disabled = 0)] = "Disabled"),
      (e[(e.Default = 1)] = "Default"),
      (e[(e.OutstreamCaptions = 8)] = "OutstreamCaptions"),
      (e[(e.OutstreamCountdown = 9)] = "OutstreamCountdown"),
      (e[(e.OutstreamHeadline = 10)] = "OutstreamHeadline"),
      (e[(e.BannerCountdown = 11)] = "BannerCountdown"),
      (e[(e.BannerHeadline = 12)] = "BannerHeadline"),
      (e[(e.BannerDailyWeatherOutlook = 13)] = "BannerDailyWeatherOutlook"),
      (e[(e.BannerWeather = 14)] = "BannerWeather"),
      (e[(e.BannerSportsTicker = 15)] = "BannerSportsTicker"),
      (e[(e.OutstreamShoppable = 16)] = "OutstreamShoppable"),
      (e[(e.BannerShoppable = 17)] = "BannerShoppable"),
      (e[(e.OutstreamDailyWeatherOutlook = 18)] =
        "OutstreamDailyWeatherOutlook"),
      (e[(e.OutstreamSportsTicker = 19)] = "OutstreamSportsTicker"),
      (e[(e.OutstreamWeather = 20)] = "OutstreamWeather"),
      (e[(e.BannerShoppableOverlay = 22)] = "BannerShoppableOverlay"),
      (e[(e.BannerMedalCount = 23)] = "BannerMedalCount"),
      (e[(e.OutstreamMedalCount = 24)] = "OutstreamMedalCount"),
      (e[(e.BannerBrandedHeadline = 30)] = "BannerBrandedHeadline"),
      (e[(e.OutstreamBrandedHeadlines = 31)] = "OutstreamBrandedHeadlines"),
      (e[(e.BannerWorldTournament = 36)] = "BannerWorldTournament"),
      (e[(e.OutstreamWorldTournament = 37)] = "OutstreamWorldTournament"),
      (e[(e.BannerCustom = 39)] = "BannerCustom"),
      (e[(e.OutstreamCustom = 40)] = "OutstreamCustom"),
      (e[(e.BannerSofiaPulseSportsHeadlines = 26)] =
        "BannerSofiaPulseSportsHeadlines"),
      (e[(e.BannerSofiaPulseQuiz = 27)] = "BannerSofiaPulseQuiz"),
      (e[(e.BannerSofiaPulseBettingOdds = 28)] = "BannerSofiaPulseBettingOdds"),
      (e[(e.BannerSofiaPulseStockTicker = 29)] = "BannerSofiaPulseStockTicker"),
      e
    ))(B || {}),
    vr = ((e) => (
      (e.AMAZON = "MR2ocDuaNCWP75ZJSgTEHjdB"),
      (e.AMAZON_EQT = "437"),
      (e.AMAZON_NATIVE_B_EQT = "490"),
      (e.NEXXEN_BANNER = "9d7CMfp2nZ18hckXmDwoFxbs"),
      (e.OPENX = "6E6dnPq1ztfkuxxNupdpgjDB"),
      (e.PUBMATIC = "t2DCBn66fGJXtaXNiotHoWdn"),
      e
    ))(vr || {}),
    Ce = ((e) => (
      (e[(e.GcMeasurement = 1)] = "GcMeasurement"),
      (e[(e.Dv360ClickExtraction = 2)] = "Dv360ClickExtraction"),
      (e[(e.AppnexusClickExtraction = 3)] = "AppnexusClickExtraction"),
      (e[(e.TradeDeskClickExtraction = 4)] = "TradeDeskClickExtraction"),
      (e[(e.RubiconClickExtraction = 5)] = "RubiconClickExtraction"),
      (e[(e.DatadogErrorReporting = 6)] = "DatadogErrorReporting"),
      e
    ))(Ce || {});
  const pc = (e) => e === vr.AMAZON || e === vr.AMAZON_NATIVE_B_EQT;
  var N = ((e) => (
      (e.Banner = "banner"),
      (e.Outstream = "outstream"),
      (e.Native = "native"),
      e
    ))(N || {}),
    D = ((e) => (
      (e.GroundControlLoaded = "10032"),
      (e.TrackClick = "10008"),
      (e.Viewable = "41"),
      (e.IsEnhanced = "10033"),
      (e.VideoStart = "2"),
      (e.AudioOn = "7"),
      (e.EnhancedEngagement = "10037"),
      (e.EnhancedContent = "10038"),
      (e.ProductCard = "10034"),
      (e.ShoppableCarouselArrow = "10035"),
      (e.VideoResume = "22"),
      (e.VideoFirstQuartile = "14"),
      (e.VideoMidpoint = "15"),
      (e.VideoThirdQuartile = "16"),
      (e.VideoComplete = "17"),
      (e.VideoError = "10009"),
      (e.BannerClickable = "10039"),
      (e.MraidImpression = "10012"),
      (e.OmidImpression = "10013"),
      (e.OverlayActive = "10041"),
      (e.AmazonNativeImpression = "10043"),
      (e.friendlyIframeEnv = "10044"),
      (e.HeavyAdIntervention = "10045"),
      (e.EnhancementLoadFailure = "10046"),
      (e.DcoRequestSuccess = "10047"),
      (e.DcoRequestFailure = "10048"),
      (e.DecoEnhancementFallback = "10050"),
      (e.PublisherStylingRequested = "10052"),
      (e.PublisherStylingLoaded = "10053"),
      e
    ))(D || {});
  const _e = (e, t = e.stage) => ({
    stage: t,
    get identifiers() {
      return e.identifiers;
    },
  });
  class yt {
    constructor(t) {
      (this.adIdentifiers = {}), (this.currentStage = t);
    }
    get stage() {
      return this.currentStage;
    }
    get identifiers() {
      return this.adIdentifiers;
    }
    enter(t) {
      this.currentStage = t;
    }
    identify(t) {
      this.adIdentifiers = { ...this.adIdentifiers, ...t };
    }
    track(t = this.currentStage) {
      return _e(this, t);
    }
  }
  var re = ((e) => (
    (e.Wrapper = "wrapper"),
    (e.Load = "load"),
    (e.Placeholder = "placeholder"),
    (e.Payload = "payload"),
    (e.Assets = "assets"),
    (e.Creative = "creative"),
    (e.Enhancement = "enhancement"),
    (e.Impression = "impression"),
    (e.Viewable = "viewable"),
    (e.MeasuredImpression = "measured_impression"),
    (e.Playback = "playback"),
    (e.Interaction = "interaction"),
    e
  ))(re || {});
  function hc(e) {
    if (!e || typeof e != "object")
      return { valid: !1, path: "", expected: "object", received: typeof e };
    const t = e;
    if (!t.type || !Object.values(N).includes(t.type))
      return {
        valid: !1,
        path: "type",
        expected: Object.values(N).join(" | "),
        received: t.type,
      };
    const r = Fn(t.size);
    if (!r.valid)
      return {
        valid: !1,
        path: `size.${r.path}`,
        expected: r.expected,
        received: r.received,
      };
    const n = [
      "content",
      "language",
      "behaviors",
      "partnerId",
      "seatId",
      "creativeId",
      "trackers",
    ];
    for (const a of n)
      if (!t[a])
        return {
          valid: !1,
          path: a,
          expected: "non-empty value",
          received: "undefined or null",
        };
    return { valid: !0 };
  }
  const mc = (e) =>
      Object.values(N)
        .map((r) => r.toString())
        .includes(e),
    fc = (e) => {
      if (!e) return null;
      if (typeof e == "string")
        try {
          return JSON.parse(e);
        } catch {
          return null;
        }
      else if (typeof e == "object") return e;
      return null;
    },
    ba = (e) => {
      const { message: t } = e;
      /(script error\.|syntaxerror|unexpected token|invalid token|unterminated)/i.test(
        t
      ) &&
        window.parent.postMessage(
          { eventType: "iframeError", error: { message: t } },
          "*"
        );
    };
  var _r = ((e) => ((e.Clickout = "clickout"), (e.Video = "video"), e))(
    _r || {}
  );
  const gc = 217882,
    bc = "6d7b08a83db80dc921bcdc71b3efa9e6",
    vc = 1e-5,
    va = 1e-4,
    _c = "https://browser-intake-datadoghq.eu/api/v2/logs",
    wc = "groundcontrol",
    yc = 5,
    wr = "https://ljv37e7t7uuolmfy4tnog4w7za0auwrm.lambda-url.us-east-1.on.aws",
    _a = "https://sfar-data-production.s3.amazonaws.com/logging",
    xc = 15e3,
    Ec = "data-gc-airbrake",
    Ac = (e) => {
      const t = e.context.sourceMaps ?? {},
        r = "https://eqt-gc.rendering.sharethrough.com/gc.js";
      return (
        (e.context.sourceMaps = {
          ...t,
          [r]: `${r}.map`,
          "https://eqt-gc.rendering.sharethrough.com/airbrake.js":
            "https://eqt-gc.rendering.sharethrough.com/airbrake.js.map",
        }),
        e
      );
    },
    kc = (e) => e,
    Ic = (e) => e,
    Cc = (e) => (
      (e.context.windowError || e.context.unhandledRejection) &&
        (e.context.build = "equativ"),
      e
    ),
    Sc = () =>
      window.__gcAirbrake?.Notifier
        ? Promise.resolve(window.__gcAirbrake.Notifier)
        : new Promise((e, t) => {
            const r = document.createElement("script");
            (r.src = "https://eqt-gc.rendering.sharethrough.com/airbrake.js"),
              (r.async = !0),
              r.setAttribute(Ec, "");
            const n = window.setTimeout(() => {
                a(), t(new Error("Airbrake script load timed out"));
              }, xc),
              a = () => {
                window.clearTimeout(n),
                  r.removeEventListener("load", i),
                  r.removeEventListener("error", o);
              },
              i = () => {
                a();
                const c = window.__gcAirbrake?.Notifier;
                c
                  ? e(c)
                  : t(
                      new Error(
                        "Airbrake script loaded but window.__gcAirbrake.Notifier is missing"
                      )
                    );
              },
              o = () => {
                a(), t(new Error("Airbrake script failed to load"));
              };
            r.addEventListener("load", i), r.addEventListener("error", o);
            try {
              document.head.appendChild(r);
            } catch (c) {
              a(), t(new Error(`Airbrake script append failed: ${String(c)}`));
            }
          }),
    Tc = async () => {
      const e = await Sc(),
        t = new e({ projectId: gc, projectKey: bc, environment: "prod" });
      return (
        t.addFilter(Ac), t.addFilter(kc), t.addFilter(Ic), t.addFilter(Cc), t
      );
    },
    Oc = 50,
    Rc = () => {
      let e, t;
      const r = [];
      let n = 0;
      const a = async (o, c) => {
          if (!t) return;
          const l = n > 0 ? { ...c, droppedNotices: n } : c;
          n > 0 && (n = 0);
          try {
            await t.notify({ error: o, context: l });
          } catch (u) {
            console.error("[Airbrake] Failed to send notification:", u);
          }
        },
        i = async (o) => {
          try {
            t = await o;
          } catch (l) {
            console.error("[Airbrake] Failed to initialize client:", l),
              (e = void 0);
            const u = r.splice(0, r.length);
            (n = 0), u.forEach((p) => p.done());
            return;
          }
          const c = r.splice(0, r.length);
          for (const l of c) await a(l.error, l.context), l.done();
        };
      return {
        name: "airbrake",
        notify(o, c) {
          return t
            ? a(o, c)
            : new Promise((l) => {
                if (r.length >= Oc) {
                  const u = r.shift();
                  n++, u?.done();
                }
                r.push({ error: o, context: c, done: l }),
                  e || ((e = Tc()), i(e));
              });
        },
      };
    },
    wa = () => `${_c}?dd-api-key=pubdfa9ad039a22fe1af9e23f1deba53bb4`,
    Nc = async (e) => {
      const t = JSON.stringify({ service: wc, ddsource: "browser", ...e });
      try {
        return navigator.sendBeacon
          ? navigator.sendBeacon(wa(), t)
          : (await fetch(wa(), {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: t,
              keepalive: !0,
            }),
            !0);
      } catch (r) {
        return console.error("[Datadog] Failed to send log:", r), !1;
      }
    },
    Dc = () => ({
      name: "datadog",
      async notify(e, t) {
        await Nc({
          message: e.message,
          status: "error",
          ...t,
          error: { kind: e.name, message: e.message, stack: e.stack },
        });
      },
    });
  let ya = yc;
  const Pc = () => (ya <= 0 ? !1 : ((ya -= 1), !0));
  class yr {
    constructor(t) {
      this.state = t;
    }
    getState() {
      return this.state;
    }
    setState(t) {
      this.state = { ...this.state, ...t };
    }
  }
  const K = [];
  for (let e = 0; e < 256; ++e) K.push((e + 256).toString(16).slice(1));
  function zc(e, t = 0) {
    return (
      K[e[t + 0]] +
      K[e[t + 1]] +
      K[e[t + 2]] +
      K[e[t + 3]] +
      "-" +
      K[e[t + 4]] +
      K[e[t + 5]] +
      "-" +
      K[e[t + 6]] +
      K[e[t + 7]] +
      "-" +
      K[e[t + 8]] +
      K[e[t + 9]] +
      "-" +
      K[e[t + 10]] +
      K[e[t + 11]] +
      K[e[t + 12]] +
      K[e[t + 13]] +
      K[e[t + 14]] +
      K[e[t + 15]]
    ).toLowerCase();
  }
  let xr;
  const Uc = new Uint8Array(16);
  function Mc() {
    if (!xr) {
      if (typeof crypto > "u" || !crypto.getRandomValues)
        throw new Error(
          "crypto.getRandomValues() not supported. See https://github.com/uuidjs/uuid#getrandomvalues-not-supported"
        );
      xr = crypto.getRandomValues.bind(crypto);
    }
    return xr(Uc);
  }
  const xa = {
    randomUUID:
      typeof crypto < "u" &&
      crypto.randomUUID &&
      crypto.randomUUID.bind(crypto),
  };
  function Ea(e, t, r) {
    if (xa.randomUUID && !e) return xa.randomUUID();
    e = e || {};
    const n = e.random ?? e.rng?.() ?? Mc();
    if (n.length < 16) throw new Error("Random bytes length must be >= 16");
    return (n[6] = (n[6] & 15) | 64), (n[8] = (n[8] & 63) | 128), zc(n);
  }
  const Aa = new yr({ gcid: "" }),
    Bc = () => {
      const e = Ea();
      Aa.setState({ gcid: e });
    },
    Lc = () => Aa.getState().gcid,
    xt = new yr({}),
    Er = new yr({}),
    Vc = (e) => {
      Er.setState({ ...Er.getState(), [e.id]: e });
    },
    Ar = (e) => Er.getState()[e];
  let kr;
  const Hc = (e) => {
      xt.setState({ ...xt.getState(), [e.id]: e }), (kr = e.id);
    },
    ka = (e) => xt.getState()[e],
    $c = () => (kr === void 0 ? void 0 : xt.getState()[kr]),
    Ir = {
      RENDER_START: "groundcontrol-render-start",
      RENDER_END: "groundcontrol-render-end",
      ENHANCEMENT_RENDER_END: "groundcontrol-enhancement-render-end",
    },
    Fc = () =>
      typeof window < "u" &&
      "performance" in window &&
      "mark" in window.performance &&
      "measure" in window.performance,
    Gc = () => {
      if (!Fc())
        throw new Error("Performance API is not supported in this environment");
      return window.performance;
    },
    Cr = (e) => {
      try {
        Gc().mark(e);
      } catch {}
    },
    jc = () => {
      Cr(Ir.RENDER_START);
    },
    Sr = () => {
      Cr(Ir.RENDER_END);
    },
    qc = () => {
      Cr(Ir.ENHANCEMENT_RENDER_END);
    },
    Ia = {},
    Ca = {},
    Et = {
      setRawResponse(e) {
        const t = e.adserverRequestId;
        Ca[t] = e;
      },
      getRawResponse(e) {
        return Ca[e];
      },
      setResponse(e) {
        const t = e.adserverRequestId;
        Ia[t] = e;
      },
      getResponse(e) {
        return Ia[e];
      },
    },
    Wc = (e) => {
      const r = ((e ? ka(e) : void 0) ?? $c())?.reporting?.errorSamplingFactor;
      return typeof r == "number" && Number.isFinite(r) && r >= 0 ? r : 1;
    },
    S = 0.01,
    Yc = [
      { callerId: "143", partnerId: "43", networkId: "5026", samplingRate: S },
      { callerId: "143", partnerId: "76", networkId: "4762", samplingRate: S },
      { callerId: "143", partnerId: "76", networkId: "5026", samplingRate: S },
      { callerId: "143", samplingRate: S },
      { callerId: "5", partnerId: "22", networkId: "4111", samplingRate: S },
      { callerId: "5", partnerId: "28", networkId: "4111", samplingRate: S },
      { callerId: "5", partnerId: "67", networkId: "4111", samplingRate: S },
      { callerId: "5", partnerId: "76", networkId: "4111", samplingRate: S },
      { callerId: "5", partnerId: "420", networkId: "4111", samplingRate: S },
      { callerId: "5", samplingRate: S },
      { callerId: "43", partnerId: "419", networkId: "3554", samplingRate: S },
      { callerId: "43", partnerId: "76", networkId: "3554", samplingRate: S },
      { callerId: "43", samplingRate: S },
      { callerId: "60", partnerId: "100", networkId: "3837", samplingRate: S },
      { callerId: "60", samplingRate: S },
      { callerId: "127", partnerId: "419", networkId: "4039", samplingRate: S },
      { callerId: "127", partnerId: "404", networkId: "4039", samplingRate: S },
      { callerId: "127", partnerId: "342", networkId: "4039", samplingRate: S },
      { callerId: "127", partnerId: "415", networkId: "4039", samplingRate: S },
      { callerId: "127", samplingRate: S },
      { callerId: "63", partnerId: "67", samplingRate: S },
      { callerId: "63", partnerId: "43", samplingRate: S },
      { callerId: "63", samplingRate: S },
      { callerId: "11", partnerId: "76", networkId: "2491", samplingRate: S },
      { callerId: "11", partnerId: "80", networkId: "2491", samplingRate: S },
      { callerId: "11", partnerId: "26", networkId: "2491", samplingRate: S },
      { callerId: "11", partnerId: "410", networkId: "2491", samplingRate: S },
      { callerId: "11", samplingRate: S },
      { callerId: "169", networkId: "4932", samplingRate: S },
      { callerId: "169", samplingRate: S },
      { callerId: "121", partnerId: "59", samplingRate: S },
      { callerId: "121", partnerId: "326", samplingRate: S },
      { callerId: "121", partnerId: "40", samplingRate: S },
      { callerId: "121", partnerId: "68", samplingRate: S },
      { callerId: "121", partnerId: "76", samplingRate: S },
      { callerId: "121", partnerId: "419", samplingRate: S },
      { callerId: "121", partnerId: "100", samplingRate: S },
      { callerId: "121", samplingRate: S },
      { callerId: "32", samplingRate: S },
      { callerId: "176", samplingRate: S },
      { callerId: "7", samplingRate: S },
    ];
  function Xc(e, t) {
    const r = e.find(
      (n) =>
        (n.partnerId === void 0 || n.partnerId === t.partnerId) &&
        (n.callerId === void 0 || n.callerId === t.callerId) &&
        (n.networkId === void 0 || n.networkId === t.networkId) &&
        (n.domain === void 0 || n.domain === t.domain)
    );
    return r ? r.samplingRate : void 0;
  }
  const Tr = new Map(),
    Kc = (e) => {
      const { callerId: t, partnerId: r, networkId: n, domain: a } = e;
      return [t ?? "", r ?? "", n ?? "", a ? String(a).toLowerCase() : ""].join(
        "|"
      );
    },
    Qc = (e) => {
      const t = Kc(e);
      if (Tr.has(t)) return Tr.get(t);
      const r = Xc(Yc, e);
      return Tr.set(t, r), r;
    },
    Or = { type: "payload", getData: ka },
    Jc = async (e, t, r) => {
      try {
        return (
          navigator.sendBeacon
            ? navigator.sendBeacon(
                wr,
                JSON.stringify({ path: e, content: t, contentType: r })
              )
            : await fetch(wr, {
                method: "POST",
                body: JSON.stringify({ path: e, content: t, contentType: r }),
                keepalive: !0,
              }),
          !0
        );
      } catch (n) {
        return console.error("Failed to log content:", n), !1;
      }
    },
    Rr = Rc(),
    Zc = Dc(),
    Nr = (e) => typeof e == "object" && e !== null,
    el = (e) =>
      (Nr(e) && "scenario" in e ? e.scenario : void 0) ===
      Ce.DatadogErrorReporting,
    tl = () =>
      `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`,
    rl = async (e) => {
      const t = Or.getData(e);
      if (t)
        return await Jc(`${Or.type}/${e}`, t, "json"), `${_a}/${Or.type}/${e}`;
    },
    nl = (e, t) => {
      const { payload: r, ...n } = e;
      return {
        ...t.identifiers,
        ...n,
        ...(t.stage ? { stage: t.stage } : {}),
        version: "gc-eqt-default-0.3.521",
        build: "equativ",
        environment: "prod",
      };
    },
    Sa = (e) => {
      const t = Nr(e.payload) && "id" in e.payload ? e.payload.id : void 0;
      return e.id || (typeof t == "string" ? t : void 0);
    },
    Ta = async (e, t, r, n = 1) => {
      const a = Sa(t);
      let i;
      if (a && typeof a == "string")
        try {
          i = await rl(a);
        } catch (h) {
          console.error("[Monitoring] Failed to log raw data:", h);
        }
      const o = nl(i ? { ...t, payloadLink: i } : t, r);
      console.error({ error: e, context: o });
      const c = async (h, m) => {
        try {
          await h.notify(e, m);
        } catch (f) {
          console.error("[Monitoring] Failed to send error to provider:", f);
        }
      };
      if (!el(t.payload)) {
        await c(Rr, o);
        return;
      }
      const l = tl(),
        u = Pc() ? void 0 : "bootCap";
      if (u) {
        await c(Rr, { ...o, errorReportId: l, datadogSkipped: u });
        return;
      }
      const p = {
        ...(Nr(o.Properties) ? o.Properties : {}),
        DatadogIngestWeight: Math.round(1 / n),
      };
      await Promise.all([
        c(Rr, { ...o, errorReportId: l }),
        c(Zc, { ...o, errorReportId: l, Properties: p }),
      ]);
    },
    R = (e, t) => {
      const r =
          e instanceof Error
            ? e
            : new Error(typeof e == "string" ? e : String(e)),
        { sampling: n, scope: a, ...i } = t,
        o = Wc(Sa(t));
      if (o === 0) return Promise.resolve(null);
      const c = typeof n == "object" ? n.alreadySampledAt : void 0;
      if (c !== void 0) {
        const m = Math.min(o, 1, va / c);
        return Math.random() < m ? Ta(r, i, a, c * m) : Promise.resolve(null);
      }
      const l = typeof n == "number" ? n : void 0,
        u = Qc({ ...a.identifiers, ...i }),
        h = Math.min((l ?? u ?? vc) * o, va);
      return Math.random() < h ? Ta(r, i, a, h) : Promise.resolve(null);
    },
    Oa = ue(null),
    Dr = ({ scope: e, children: t }) =>
      d(Oa.Provider, { value: e, children: t }),
    le = () => {
      const e = ae(Oa);
      return ce(() => _e(e ?? new yt()), [e]);
    },
    Ra = new Map(),
    al = (e, t) => {
      Ra.set(e, t);
    },
    Na = (e) => _e((e ? Ra.get(e) : void 0) ?? new yt()),
    il = (e) => ({
      id: e.id,
      partnerId: e.creative.partnerId,
      networkId: e.network.networkId,
      callerId: e.network.callerId,
      creativeType: e.creative.type,
    }),
    ol = (e) => (e ? sl(e) : ""),
    sl = ({ nativeType: e, type: t }) =>
      t === N.Native && e ? e : t === N.Outstream ? "native-outstream" : t,
    At = ue(null),
    cl = ({ payload: e, children: t }) => {
      const r = { ...e, getButlerAction: () => ol(e.creative) };
      return d(At.Provider, { value: r, children: t });
    },
    Q = () => ae(At),
    kt = (e) => {
      const t = Q() ?? void 0,
        r = t?.enhancement ?? null,
        n = le();
      return sc((a) => {
        const i = { scope: n, payload: t, enhancement: r };
        e && a instanceof Error && (a.message = `${e}: ${a.message}`), R(a, i);
      });
    };
  function ll(e, t) {
    return e.reduceRight((r, [n, a]) => d(n, { ...a, children: r }), t);
  }
  class dl {
    constructor(t) {
      (this.ChildComponent = t), (this.ChildComponent = t);
    }
    render(t, r, n, a, i, o) {
      const c = r.id,
        u = ll(
          a,
          d(() => {
            const [h] = kt(`Error in AdUnitComponent with id: ${c}`);
            return h
              ? (console.log(" wrappedAdunit", h), null)
              : d(i, {
                  id: c,
                  response: t,
                  childComponent: this.ChildComponent,
                });
          }, {})
        );
      if (n.parentElement) {
        for (n.setAttribute("data-str-visited-flag", "true"); n.firstChild; )
          n.removeChild(n.firstChild);
        nc(u, n);
      } else
        R(new Error("RenderService: placeholder detached at render time"), {
          scope: o,
          function: "core/render-service:render",
          payloadId: c,
          bundleId: r.network.bundleId,
          readyState: document.readyState,
        });
    }
  }
  class ul {
    constructor(t) {
      this.EnhancementComponent = t;
    }
    getEnhancementComponent() {
      return this.EnhancementComponent;
    }
  }
  function pl(e) {
    if (!e || typeof e != "object")
      return { valid: !1, path: "", expected: "object", received: typeof e };
    const t = e;
    if (!t.networkId || typeof t.networkId != "string")
      return {
        valid: !1,
        path: "networkId",
        expected: "string",
        received: typeof t.networkId,
      };
    const r = Fn(t.size);
    return r.valid ? { valid: !0 } : { ...r, path: `size.${r.path}` };
  }
  function hl(e) {
    if (Object.prototype.hasOwnProperty.call(e, "__esModule")) return e;
    var t = e.default;
    if (typeof t == "function") {
      var r = function n() {
        return this instanceof n
          ? Reflect.construct(t, arguments, this.constructor)
          : t.apply(this, arguments);
      };
      r.prototype = t.prototype;
    } else r = {};
    return (
      Object.defineProperty(r, "__esModule", { value: !0 }),
      Object.keys(e).forEach(function (n) {
        var a = Object.getOwnPropertyDescriptor(e, n);
        Object.defineProperty(
          r,
          n,
          a.get
            ? a
            : {
                enumerable: !0,
                get: function () {
                  return e[n];
                },
              }
        );
      }),
      r
    );
  }
  var Pr = {},
    zr = function (e, t) {
      return (
        (zr =
          Object.setPrototypeOf ||
          ({ __proto__: [] } instanceof Array &&
            function (r, n) {
              r.__proto__ = n;
            }) ||
          function (r, n) {
            for (var a in n)
              Object.prototype.hasOwnProperty.call(n, a) && (r[a] = n[a]);
          }),
        zr(e, t)
      );
    };
  function Da(e, t) {
    if (typeof t != "function" && t !== null)
      throw new TypeError(
        "Class extends value " + String(t) + " is not a constructor or null"
      );
    zr(e, t);
    function r() {
      this.constructor = e;
    }
    e.prototype =
      t === null ? Object.create(t) : ((r.prototype = t.prototype), new r());
  }
  var It = function () {
    return (
      (It =
        Object.assign ||
        function (t) {
          for (var r, n = 1, a = arguments.length; n < a; n++) {
            r = arguments[n];
            for (var i in r)
              Object.prototype.hasOwnProperty.call(r, i) && (t[i] = r[i]);
          }
          return t;
        }),
      It.apply(this, arguments)
    );
  };
  function Pa(e, t) {
    var r = {};
    for (var n in e)
      Object.prototype.hasOwnProperty.call(e, n) &&
        t.indexOf(n) < 0 &&
        (r[n] = e[n]);
    if (e != null && typeof Object.getOwnPropertySymbols == "function")
      for (var a = 0, n = Object.getOwnPropertySymbols(e); a < n.length; a++)
        t.indexOf(n[a]) < 0 &&
          Object.prototype.propertyIsEnumerable.call(e, n[a]) &&
          (r[n[a]] = e[n[a]]);
    return r;
  }
  function za(e, t, r, n) {
    var a = arguments.length,
      i =
        a < 3
          ? t
          : n === null
          ? (n = Object.getOwnPropertyDescriptor(t, r))
          : n,
      o;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function")
      i = Reflect.decorate(e, t, r, n);
    else
      for (var c = e.length - 1; c >= 0; c--)
        (o = e[c]) && (i = (a < 3 ? o(i) : a > 3 ? o(t, r, i) : o(t, r)) || i);
    return a > 3 && i && Object.defineProperty(t, r, i), i;
  }
  function Ua(e, t) {
    return function (r, n) {
      t(r, n, e);
    };
  }
  function Ma(e, t, r, n, a, i) {
    function o(v) {
      if (v !== void 0 && typeof v != "function")
        throw new TypeError("Function expected");
      return v;
    }
    for (
      var c = n.kind,
        l = c === "getter" ? "get" : c === "setter" ? "set" : "value",
        u = !t && e ? (n.static ? e : e.prototype) : null,
        p = t || (u ? Object.getOwnPropertyDescriptor(u, n.name) : {}),
        h,
        m = !1,
        f = r.length - 1;
      f >= 0;
      f--
    ) {
      var g = {};
      for (var w in n) g[w] = w === "access" ? {} : n[w];
      for (var w in n.access) g.access[w] = n.access[w];
      g.addInitializer = function (v) {
        if (m)
          throw new TypeError(
            "Cannot add initializers after decoration has completed"
          );
        i.push(o(v || null));
      };
      var y = (0, r[f])(
        c === "accessor" ? { get: p.get, set: p.set } : p[l],
        g
      );
      if (c === "accessor") {
        if (y === void 0) continue;
        if (y === null || typeof y != "object")
          throw new TypeError("Object expected");
        (h = o(y.get)) && (p.get = h),
          (h = o(y.set)) && (p.set = h),
          (h = o(y.init)) && a.unshift(h);
      } else (h = o(y)) && (c === "field" ? a.unshift(h) : (p[l] = h));
    }
    u && Object.defineProperty(u, n.name, p), (m = !0);
  }
  function Ba(e, t, r) {
    for (var n = arguments.length > 2, a = 0; a < t.length; a++)
      r = n ? t[a].call(e, r) : t[a].call(e);
    return n ? r : void 0;
  }
  function La(e) {
    return typeof e == "symbol" ? e : "".concat(e);
  }
  function Va(e, t, r) {
    return (
      typeof t == "symbol" &&
        (t = t.description ? "[".concat(t.description, "]") : ""),
      Object.defineProperty(e, "name", {
        configurable: !0,
        value: r ? "".concat(r, " ", t) : t,
      })
    );
  }
  function Ha(e, t) {
    if (typeof Reflect == "object" && typeof Reflect.metadata == "function")
      return Reflect.metadata(e, t);
  }
  function $a(e, t, r, n) {
    function a(i) {
      return i instanceof r
        ? i
        : new r(function (o) {
            o(i);
          });
    }
    return new (r || (r = Promise))(function (i, o) {
      function c(p) {
        try {
          u(n.next(p));
        } catch (h) {
          o(h);
        }
      }
      function l(p) {
        try {
          u(n.throw(p));
        } catch (h) {
          o(h);
        }
      }
      function u(p) {
        p.done ? i(p.value) : a(p.value).then(c, l);
      }
      u((n = n.apply(e, t || [])).next());
    });
  }
  function Fa(e, t) {
    var r = {
        label: 0,
        sent: function () {
          if (i[0] & 1) throw i[1];
          return i[1];
        },
        trys: [],
        ops: [],
      },
      n,
      a,
      i,
      o = Object.create(
        (typeof Iterator == "function" ? Iterator : Object).prototype
      );
    return (
      (o.next = c(0)),
      (o.throw = c(1)),
      (o.return = c(2)),
      typeof Symbol == "function" &&
        (o[Symbol.iterator] = function () {
          return this;
        }),
      o
    );
    function c(u) {
      return function (p) {
        return l([u, p]);
      };
    }
    function l(u) {
      if (n) throw new TypeError("Generator is already executing.");
      for (; o && ((o = 0), u[0] && (r = 0)), r; )
        try {
          if (
            ((n = 1),
            a &&
              (i =
                u[0] & 2
                  ? a.return
                  : u[0]
                  ? a.throw || ((i = a.return) && i.call(a), 0)
                  : a.next) &&
              !(i = i.call(a, u[1])).done)
          )
            return i;
          switch (((a = 0), i && (u = [u[0] & 2, i.value]), u[0])) {
            case 0:
            case 1:
              i = u;
              break;
            case 4:
              return r.label++, { value: u[1], done: !1 };
            case 5:
              r.label++, (a = u[1]), (u = [0]);
              continue;
            case 7:
              (u = r.ops.pop()), r.trys.pop();
              continue;
            default:
              if (
                ((i = r.trys),
                !(i = i.length > 0 && i[i.length - 1]) &&
                  (u[0] === 6 || u[0] === 2))
              ) {
                r = 0;
                continue;
              }
              if (u[0] === 3 && (!i || (u[1] > i[0] && u[1] < i[3]))) {
                r.label = u[1];
                break;
              }
              if (u[0] === 6 && r.label < i[1]) {
                (r.label = i[1]), (i = u);
                break;
              }
              if (i && r.label < i[2]) {
                (r.label = i[2]), r.ops.push(u);
                break;
              }
              i[2] && r.ops.pop(), r.trys.pop();
              continue;
          }
          u = t.call(e, r);
        } catch (p) {
          (u = [6, p]), (a = 0);
        } finally {
          n = i = 0;
        }
      if (u[0] & 5) throw u[1];
      return { value: u[0] ? u[1] : void 0, done: !0 };
    }
  }
  var Ct = Object.create
    ? function (e, t, r, n) {
        n === void 0 && (n = r);
        var a = Object.getOwnPropertyDescriptor(t, r);
        (!a || ("get" in a ? !t.__esModule : a.writable || a.configurable)) &&
          (a = {
            enumerable: !0,
            get: function () {
              return t[r];
            },
          }),
          Object.defineProperty(e, n, a);
      }
    : function (e, t, r, n) {
        n === void 0 && (n = r), (e[n] = t[r]);
      };
  function Ga(e, t) {
    for (var r in e)
      r !== "default" &&
        !Object.prototype.hasOwnProperty.call(t, r) &&
        Ct(t, e, r);
  }
  function St(e) {
    var t = typeof Symbol == "function" && Symbol.iterator,
      r = t && e[t],
      n = 0;
    if (r) return r.call(e);
    if (e && typeof e.length == "number")
      return {
        next: function () {
          return (
            e && n >= e.length && (e = void 0), { value: e && e[n++], done: !e }
          );
        },
      };
    throw new TypeError(
      t ? "Object is not iterable." : "Symbol.iterator is not defined."
    );
  }
  function Ur(e, t) {
    var r = typeof Symbol == "function" && e[Symbol.iterator];
    if (!r) return e;
    var n = r.call(e),
      a,
      i = [],
      o;
    try {
      for (; (t === void 0 || t-- > 0) && !(a = n.next()).done; )
        i.push(a.value);
    } catch (c) {
      o = { error: c };
    } finally {
      try {
        a && !a.done && (r = n.return) && r.call(n);
      } finally {
        if (o) throw o.error;
      }
    }
    return i;
  }
  function ja() {
    for (var e = [], t = 0; t < arguments.length; t++)
      e = e.concat(Ur(arguments[t]));
    return e;
  }
  function qa() {
    for (var e = 0, t = 0, r = arguments.length; t < r; t++)
      e += arguments[t].length;
    for (var n = Array(e), a = 0, t = 0; t < r; t++)
      for (var i = arguments[t], o = 0, c = i.length; o < c; o++, a++)
        n[a] = i[o];
    return n;
  }
  function Wa(e, t, r) {
    if (r || arguments.length === 2)
      for (var n = 0, a = t.length, i; n < a; n++)
        (i || !(n in t)) &&
          (i || (i = Array.prototype.slice.call(t, 0, n)), (i[n] = t[n]));
    return e.concat(i || Array.prototype.slice.call(t));
  }
  function Be(e) {
    return this instanceof Be ? ((this.v = e), this) : new Be(e);
  }
  function Ya(e, t, r) {
    if (!Symbol.asyncIterator)
      throw new TypeError("Symbol.asyncIterator is not defined.");
    var n = r.apply(e, t || []),
      a,
      i = [];
    return (
      (a = Object.create(
        (typeof AsyncIterator == "function" ? AsyncIterator : Object).prototype
      )),
      c("next"),
      c("throw"),
      c("return", o),
      (a[Symbol.asyncIterator] = function () {
        return this;
      }),
      a
    );
    function o(f) {
      return function (g) {
        return Promise.resolve(g).then(f, h);
      };
    }
    function c(f, g) {
      n[f] &&
        ((a[f] = function (w) {
          return new Promise(function (y, v) {
            i.push([f, w, y, v]) > 1 || l(f, w);
          });
        }),
        g && (a[f] = g(a[f])));
    }
    function l(f, g) {
      try {
        u(n[f](g));
      } catch (w) {
        m(i[0][3], w);
      }
    }
    function u(f) {
      f.value instanceof Be
        ? Promise.resolve(f.value.v).then(p, h)
        : m(i[0][2], f);
    }
    function p(f) {
      l("next", f);
    }
    function h(f) {
      l("throw", f);
    }
    function m(f, g) {
      f(g), i.shift(), i.length && l(i[0][0], i[0][1]);
    }
  }
  function Xa(e) {
    var t, r;
    return (
      (t = {}),
      n("next"),
      n("throw", function (a) {
        throw a;
      }),
      n("return"),
      (t[Symbol.iterator] = function () {
        return this;
      }),
      t
    );
    function n(a, i) {
      t[a] = e[a]
        ? function (o) {
            return (r = !r) ? { value: Be(e[a](o)), done: !1 } : i ? i(o) : o;
          }
        : i;
    }
  }
  function Ka(e) {
    if (!Symbol.asyncIterator)
      throw new TypeError("Symbol.asyncIterator is not defined.");
    var t = e[Symbol.asyncIterator],
      r;
    return t
      ? t.call(e)
      : ((e = typeof St == "function" ? St(e) : e[Symbol.iterator]()),
        (r = {}),
        n("next"),
        n("throw"),
        n("return"),
        (r[Symbol.asyncIterator] = function () {
          return this;
        }),
        r);
    function n(i) {
      r[i] =
        e[i] &&
        function (o) {
          return new Promise(function (c, l) {
            (o = e[i](o)), a(c, l, o.done, o.value);
          });
        };
    }
    function a(i, o, c, l) {
      Promise.resolve(l).then(function (u) {
        i({ value: u, done: c });
      }, o);
    }
  }
  function Qa(e, t) {
    return (
      Object.defineProperty
        ? Object.defineProperty(e, "raw", { value: t })
        : (e.raw = t),
      e
    );
  }
  var ml = Object.create
      ? function (e, t) {
          Object.defineProperty(e, "default", { enumerable: !0, value: t });
        }
      : function (e, t) {
          e.default = t;
        },
    Mr = function (e) {
      return (
        (Mr =
          Object.getOwnPropertyNames ||
          function (t) {
            var r = [];
            for (var n in t)
              Object.prototype.hasOwnProperty.call(t, n) && (r[r.length] = n);
            return r;
          }),
        Mr(e)
      );
    };
  function Ja(e) {
    if (e && e.__esModule) return e;
    var t = {};
    if (e != null)
      for (var r = Mr(e), n = 0; n < r.length; n++)
        r[n] !== "default" && Ct(t, e, r[n]);
    return ml(t, e), t;
  }
  function Za(e) {
    return e && e.__esModule ? e : { default: e };
  }
  function ei(e, t, r, n) {
    if (r === "a" && !n)
      throw new TypeError("Private accessor was defined without a getter");
    if (typeof t == "function" ? e !== t || !n : !t.has(e))
      throw new TypeError(
        "Cannot read private member from an object whose class did not declare it"
      );
    return r === "m" ? n : r === "a" ? n.call(e) : n ? n.value : t.get(e);
  }
  function ti(e, t, r, n, a) {
    if (n === "m") throw new TypeError("Private method is not writable");
    if (n === "a" && !a)
      throw new TypeError("Private accessor was defined without a setter");
    if (typeof t == "function" ? e !== t || !a : !t.has(e))
      throw new TypeError(
        "Cannot write private member to an object whose class did not declare it"
      );
    return n === "a" ? a.call(e, r) : a ? (a.value = r) : t.set(e, r), r;
  }
  function ri(e, t) {
    if (t === null || (typeof t != "object" && typeof t != "function"))
      throw new TypeError("Cannot use 'in' operator on non-object");
    return typeof e == "function" ? t === e : e.has(t);
  }
  function ni(e, t, r) {
    if (t != null) {
      if (typeof t != "object" && typeof t != "function")
        throw new TypeError("Object expected.");
      var n, a;
      if (r) {
        if (!Symbol.asyncDispose)
          throw new TypeError("Symbol.asyncDispose is not defined.");
        n = t[Symbol.asyncDispose];
      }
      if (n === void 0) {
        if (!Symbol.dispose)
          throw new TypeError("Symbol.dispose is not defined.");
        (n = t[Symbol.dispose]), r && (a = n);
      }
      if (typeof n != "function") throw new TypeError("Object not disposable.");
      a &&
        (n = function () {
          try {
            a.call(this);
          } catch (i) {
            return Promise.reject(i);
          }
        }),
        e.stack.push({ value: t, dispose: n, async: r });
    } else r && e.stack.push({ async: !0 });
    return t;
  }
  var fl =
    typeof SuppressedError == "function"
      ? SuppressedError
      : function (e, t, r) {
          var n = new Error(r);
          return (
            (n.name = "SuppressedError"), (n.error = e), (n.suppressed = t), n
          );
        };
  function ai(e) {
    function t(i) {
      (e.error = e.hasError
        ? new fl(i, e.error, "An error was suppressed during disposal.")
        : i),
        (e.hasError = !0);
    }
    var r,
      n = 0;
    function a() {
      for (; (r = e.stack.pop()); )
        try {
          if (!r.async && n === 1)
            return (n = 0), e.stack.push(r), Promise.resolve().then(a);
          if (r.dispose) {
            var i = r.dispose.call(r.value);
            if (r.async)
              return (
                (n |= 2),
                Promise.resolve(i).then(a, function (o) {
                  return t(o), a();
                })
              );
          } else n |= 1;
        } catch (o) {
          t(o);
        }
      if (n === 1)
        return e.hasError ? Promise.reject(e.error) : Promise.resolve();
      if (e.hasError) throw e.error;
    }
    return a();
  }
  function ii(e, t) {
    return typeof e == "string" && /^\.\.?\//.test(e)
      ? e.replace(
          /\.(tsx)$|((?:\.d)?)((?:\.[^./]+?)?)\.([cm]?)ts$/i,
          function (r, n, a, i, o) {
            return n
              ? t
                ? ".jsx"
                : ".js"
              : a && (!i || !o)
              ? r
              : a + i + "." + o.toLowerCase() + "js";
          }
        )
      : e;
  }
  const oi = hl(
    Object.freeze(
      Object.defineProperty(
        {
          __proto__: null,
          __addDisposableResource: ni,
          get __assign() {
            return It;
          },
          __asyncDelegator: Xa,
          __asyncGenerator: Ya,
          __asyncValues: Ka,
          __await: Be,
          __awaiter: $a,
          __classPrivateFieldGet: ei,
          __classPrivateFieldIn: ri,
          __classPrivateFieldSet: ti,
          __createBinding: Ct,
          __decorate: za,
          __disposeResources: ai,
          __esDecorate: Ma,
          __exportStar: Ga,
          __extends: Da,
          __generator: Fa,
          __importDefault: Za,
          __importStar: Ja,
          __makeTemplateObject: Qa,
          __metadata: Ha,
          __param: Ua,
          __propKey: La,
          __read: Ur,
          __rest: Pa,
          __rewriteRelativeImportExtension: ii,
          __runInitializers: Ba,
          __setFunctionName: Va,
          __spread: ja,
          __spreadArray: Wa,
          __spreadArrays: qa,
          __values: St,
          default: {
            __extends: Da,
            __assign: It,
            __rest: Pa,
            __decorate: za,
            __param: Ua,
            __esDecorate: Ma,
            __runInitializers: Ba,
            __propKey: La,
            __setFunctionName: Va,
            __metadata: Ha,
            __awaiter: $a,
            __generator: Fa,
            __createBinding: Ct,
            __exportStar: Ga,
            __values: St,
            __read: Ur,
            __spread: ja,
            __spreadArrays: qa,
            __spreadArray: Wa,
            __await: Be,
            __asyncGenerator: Ya,
            __asyncDelegator: Xa,
            __asyncValues: Ka,
            __makeTemplateObject: Qa,
            __importStar: Ja,
            __importDefault: Za,
            __classPrivateFieldGet: ei,
            __classPrivateFieldSet: ti,
            __classPrivateFieldIn: ri,
            __addDisposableResource: ni,
            __disposeResources: ai,
            __rewriteRelativeImportExtension: ii,
          },
        },
        Symbol.toStringTag,
        { value: "Module" }
      )
    )
  );
  var pe = {},
    si;
  function ci() {
    if (si) return pe;
    (si = 1),
      Object.defineProperty(pe, "__esModule", { value: !0 }),
      (pe.SortOrder =
        pe.GCWeatherUnit =
        pe.GCEnhancementLanguage =
        pe.GCEnhancementType =
          void 0);
    var e;
    (function (a) {
      (a.BannerCountdown = "banner-countdown"),
        (a.BannerMedalCount = "banner-medal-count"),
        (a.BannerWorldTournament = "banner-world-tournament"),
        (a.BannerCustom = "banner-custom"),
        (a.OutstreamCustom = "outstream-custom"),
        (a.OutstreamCountdown = "outstream-countdown"),
        (a.BannerHeadline = "banner-headline"),
        (a.BannerBrandedHeadline = "banner-ai-branding"),
        (a.BannerSportsTicker = "banner-sports-ticker"),
        (a.BannerWeather = "banner-weather"),
        (a.BannerDailyWeatherOutlook = "banner-daily-weather-outlook"),
        (a.BannerShoppable = "banner-shoppable"),
        (a.BannerShoppableOverlay = "banner-shoppable-overlay"),
        (a.OutstreamHeadline = "outstream-headline"),
        (a.OutstreamCaptions = "outstream-captions"),
        (a.OutstreamWeather = "outstream-weather"),
        (a.OutstreamDailyWeatherOutlook = "outstream-daily-weather-outlook"),
        (a.OutstreamSportsTicker = "outstream-sports-ticker"),
        (a.OutstreamMedalCount = "outstream-medal-count"),
        (a.OutstreamWorldTournament = "outstream-world-tournament"),
        (a.OutstreamBrandedHeadline = "outstream-ai-branding"),
        (a.OutstreamShoppable = "outstream-shoppable"),
        (a.BannerSofiaPulseSportsHeadlines = "banner-sp-sports-headline"),
        (a.BannerSofiaPulseQuiz = "banner-sp-sports-quiz"),
        (a.BannerSofiaPulseBettingOdds = "banner-sp-odds-ticker"),
        (a.BannerSofiaPulseStockTicker = "banner-sp-stock-ticker");
    })(e || (pe.GCEnhancementType = e = {}));
    var t;
    (function (a) {
      (a.English = "en"),
        (a.French = "fr"),
        (a.German = "de"),
        (a.Spanish = "es"),
        (a.Italian = "it");
    })(t || (pe.GCEnhancementLanguage = t = {}));
    var r;
    (function (a) {
      (a.Metric = "metric"), (a.Imperial = "imperial");
    })(r || (pe.GCWeatherUnit = r = {}));
    var n;
    return (
      (function (a) {
        (a.Ordered = "ordered"), (a.Shuffled = "shuffled");
      })(n || (pe.SortOrder = n = {})),
      pe
    );
  }
  var Xe = {},
    li;
  function gl() {
    if (li) return Xe;
    (li = 1),
      Object.defineProperty(Xe, "__esModule", { value: !0 }),
      (Xe.getGCEnhancementType = void 0);
    const e = ci(),
      t = (r) => {
        const n = Object.values(e.GCEnhancementType).find((a) => a === r);
        if (!n) throw new Error(`Unknown enhancement type: ${r}`);
        return n;
      };
    return (Xe.getGCEnhancementType = t), Xe;
  }
  var Br = {},
    Lr = {},
    di;
  function bl() {
    return (
      di || ((di = 1), Object.defineProperty(Lr, "__esModule", { value: !0 })),
      Lr
    );
  }
  var Vr = {},
    ui;
  function vl() {
    return (
      ui || ((ui = 1), Object.defineProperty(Vr, "__esModule", { value: !0 })),
      Vr
    );
  }
  var Hr = {},
    pi;
  function _l() {
    return (
      pi || ((pi = 1), Object.defineProperty(Hr, "__esModule", { value: !0 })),
      Hr
    );
  }
  var $r = {},
    hi;
  function wl() {
    return (
      hi || ((hi = 1), Object.defineProperty($r, "__esModule", { value: !0 })),
      $r
    );
  }
  var Fr = {},
    mi;
  function yl() {
    return (
      mi || ((mi = 1), Object.defineProperty(Fr, "__esModule", { value: !0 })),
      Fr
    );
  }
  var Gr = {},
    fi;
  function xl() {
    return (
      fi || ((fi = 1), Object.defineProperty(Gr, "__esModule", { value: !0 })),
      Gr
    );
  }
  var jr = {},
    gi;
  function El() {
    return (
      gi || ((gi = 1), Object.defineProperty(jr, "__esModule", { value: !0 })),
      jr
    );
  }
  var qr = {},
    bi;
  function Al() {
    return (
      bi || ((bi = 1), Object.defineProperty(qr, "__esModule", { value: !0 })),
      qr
    );
  }
  var Wr = {},
    vi;
  function kl() {
    return (
      vi || ((vi = 1), Object.defineProperty(Wr, "__esModule", { value: !0 })),
      Wr
    );
  }
  var Yr = {},
    _i;
  function Il() {
    return (
      _i || ((_i = 1), Object.defineProperty(Yr, "__esModule", { value: !0 })),
      Yr
    );
  }
  var Xr = {},
    wi;
  function Cl() {
    return (
      wi || ((wi = 1), Object.defineProperty(Xr, "__esModule", { value: !0 })),
      Xr
    );
  }
  var Kr = {},
    yi;
  function Sl() {
    return (
      yi || ((yi = 1), Object.defineProperty(Kr, "__esModule", { value: !0 })),
      Kr
    );
  }
  var Qr = {},
    xi;
  function Tl() {
    return (
      xi || ((xi = 1), Object.defineProperty(Qr, "__esModule", { value: !0 })),
      Qr
    );
  }
  var Jr = {},
    Ei;
  function Ol() {
    return (
      Ei || ((Ei = 1), Object.defineProperty(Jr, "__esModule", { value: !0 })),
      Jr
    );
  }
  var Zr = {},
    Ai;
  function Rl() {
    return (
      Ai || ((Ai = 1), Object.defineProperty(Zr, "__esModule", { value: !0 })),
      Zr
    );
  }
  var ki;
  function Nl() {
    return (
      ki ||
        ((ki = 1),
        (function (e) {
          Object.defineProperty(e, "__esModule", { value: !0 });
          const t = oi;
          t.__exportStar(bl(), e),
            t.__exportStar(vl(), e),
            t.__exportStar(_l(), e),
            t.__exportStar(wl(), e),
            t.__exportStar(yl(), e),
            t.__exportStar(xl(), e),
            t.__exportStar(El(), e),
            t.__exportStar(Al(), e),
            t.__exportStar(kl(), e),
            t.__exportStar(Il(), e),
            t.__exportStar(Cl(), e),
            t.__exportStar(Sl(), e),
            t.__exportStar(Tl(), e),
            t.__exportStar(Ol(), e),
            t.__exportStar(Rl(), e);
        })(Br)),
      Br
    );
  }
  var Ii;
  function Dl() {
    return (
      Ii ||
        ((Ii = 1),
        (function (e) {
          Object.defineProperty(e, "__esModule", { value: !0 });
          const t = oi;
          t.__exportStar(ci(), e),
            t.__exportStar(gl(), e),
            t.__exportStar(Nl(), e);
        })(Pr)),
      Pr
    );
  }
  var b = Dl();
  function Pl(e) {
    if (!e || typeof e != "object")
      return { valid: !1, path: "", expected: "object", received: typeof e };
    const t = e;
    if (!t.id || typeof t.id != "string")
      return {
        valid: !1,
        path: "id",
        expected: "string",
        received: typeof t.id,
      };
    const r = hc(t.creative);
    if (!r.valid) return { ...r, path: `creative.${r.path}` };
    const n = pl(t.network);
    return n.valid ? { valid: !0 } : { ...n, path: `network.${n.path}` };
  }
  const zl = ["30", "vviA7jzZ", "32", "53", "106", "136"];
  function Ul(e) {
    return e ? zl.includes(e) : !1;
  }
  function Ke(e) {
    return e ? ["7", "2TwkgUpM"].includes(e) : !1;
  }
  const Ml = 0.75,
    Bl = new Set(["300x250", "300x600", "160x600"]),
    Ci = (e, t) => Bl.has(`${e}x${t}`),
    en = new Set([
      b.GCEnhancementType.BannerSofiaPulseSportsHeadlines,
      b.GCEnhancementType.BannerSofiaPulseQuiz,
      b.GCEnhancementType.BannerSofiaPulseBettingOdds,
      b.GCEnhancementType.BannerSofiaPulseStockTicker,
    ]),
    Si = (e, t) =>
      t && en.has(t) ? !0 : e ? e.toString().includes(".sofiapulse.com") : !1,
    Ll = (e, t, r, n) => (r ? !1 : !Si(t, n) && !Ke(e));
  class Vl {
    validate(t) {
      const r = Pl(t);
      return r.valid || console.error("Validation failed:", r), r.valid;
    }
    initialize(t, r) {
      const n = this.parse(t, r);
      return Vc(n), n;
    }
  }
  const Ti = (e, t) => e?.scenario != null && e.scenario === t,
    Hl = (e) =>
      e?.reporting?.countImpressionOnePixel === !0 && Ti(e, Ce.GcMeasurement);
  var $l = Symbol.for("preact-signals");
  function tn() {
    if (Le > 1) Le--;
    else {
      for (var e, t = !1; Qe !== void 0; ) {
        var r = Qe;
        for (Qe = void 0, rn++; r !== void 0; ) {
          var n = r.o;
          if (((r.o = void 0), (r.f &= -3), !(8 & r.f) && Ni(r)))
            try {
              r.c();
            } catch (a) {
              t || ((e = a), (t = !0));
            }
          r = n;
        }
      }
      if (((rn = 0), Le--, t)) throw e;
    }
  }
  var z = void 0;
  function Oi(e) {
    var t = z;
    z = void 0;
    try {
      return e();
    } finally {
      z = t;
    }
  }
  var Qe = void 0,
    Le = 0,
    rn = 0,
    Tt = 0;
  function Ri(e) {
    if (z !== void 0) {
      var t = e.n;
      if (t === void 0 || t.t !== z)
        return (
          (t = {
            i: 0,
            S: e,
            p: z.s,
            n: void 0,
            t: z,
            e: void 0,
            x: void 0,
            r: t,
          }),
          z.s !== void 0 && (z.s.n = t),
          (z.s = t),
          (e.n = t),
          32 & z.f && e.S(t),
          t
        );
      if (t.i === -1)
        return (
          (t.i = 0),
          t.n !== void 0 &&
            ((t.n.p = t.p),
            t.p !== void 0 && (t.p.n = t.n),
            (t.p = z.s),
            (t.n = void 0),
            (z.s.n = t),
            (z.s = t)),
          t
        );
    }
  }
  function X(e, t) {
    (this.v = e),
      (this.i = 0),
      (this.n = void 0),
      (this.t = void 0),
      (this.W = t?.watched),
      (this.Z = t?.unwatched),
      (this.name = t?.name);
  }
  (X.prototype.brand = $l),
    (X.prototype.h = function () {
      return !0;
    }),
    (X.prototype.S = function (e) {
      var t = this,
        r = this.t;
      r !== e &&
        e.e === void 0 &&
        ((e.x = r),
        (this.t = e),
        r !== void 0
          ? (r.e = e)
          : Oi(function () {
              var n;
              (n = t.W) == null || n.call(t);
            }));
    }),
    (X.prototype.U = function (e) {
      var t = this;
      if (this.t !== void 0) {
        var r = e.e,
          n = e.x;
        r !== void 0 && ((r.x = n), (e.e = void 0)),
          n !== void 0 && ((n.e = r), (e.x = void 0)),
          e === this.t &&
            ((this.t = n),
            n === void 0 &&
              Oi(function () {
                var a;
                (a = t.Z) == null || a.call(t);
              }));
      }
    }),
    (X.prototype.subscribe = function (e) {
      var t = this;
      return Ot(
        function () {
          var r = t.value,
            n = z;
          z = void 0;
          try {
            e(r);
          } finally {
            z = n;
          }
        },
        { name: "sub" }
      );
    }),
    (X.prototype.valueOf = function () {
      return this.value;
    }),
    (X.prototype.toString = function () {
      return this.value + "";
    }),
    (X.prototype.toJSON = function () {
      return this.value;
    }),
    (X.prototype.peek = function () {
      var e = z;
      z = void 0;
      try {
        return this.value;
      } finally {
        z = e;
      }
    }),
    Object.defineProperty(X.prototype, "value", {
      get: function () {
        var e = Ri(this);
        return e !== void 0 && (e.i = this.i), this.v;
      },
      set: function (e) {
        if (e !== this.v) {
          if (rn > 100) throw new Error("Cycle detected");
          (this.v = e), this.i++, Tt++, Le++;
          try {
            for (var t = this.t; t !== void 0; t = t.x) t.t.N();
          } finally {
            tn();
          }
        }
      },
    });
  function U(e, t) {
    return new X(e, t);
  }
  function Ni(e) {
    for (var t = e.s; t !== void 0; t = t.n)
      if (t.S.i !== t.i || !t.S.h() || t.S.i !== t.i) return !0;
    return !1;
  }
  function Di(e) {
    for (var t = e.s; t !== void 0; t = t.n) {
      var r = t.S.n;
      if (
        (r !== void 0 && (t.r = r), (t.S.n = t), (t.i = -1), t.n === void 0)
      ) {
        e.s = t;
        break;
      }
    }
  }
  function Pi(e) {
    for (var t = e.s, r = void 0; t !== void 0; ) {
      var n = t.p;
      t.i === -1
        ? (t.S.U(t), n !== void 0 && (n.n = t.n), t.n !== void 0 && (t.n.p = n))
        : (r = t),
        (t.S.n = t.r),
        t.r !== void 0 && (t.r = void 0),
        (t = n);
    }
    e.s = r;
  }
  function Se(e, t) {
    X.call(this, void 0),
      (this.x = e),
      (this.s = void 0),
      (this.g = Tt - 1),
      (this.f = 4),
      (this.W = t?.watched),
      (this.Z = t?.unwatched),
      (this.name = t?.name);
  }
  (Se.prototype = new X()),
    (Se.prototype.h = function () {
      if (((this.f &= -3), 1 & this.f)) return !1;
      if ((36 & this.f) == 32 || ((this.f &= -5), this.g === Tt)) return !0;
      if (((this.g = Tt), (this.f |= 1), this.i > 0 && !Ni(this)))
        return (this.f &= -2), !0;
      var e = z;
      try {
        Di(this), (z = this);
        var t = this.x();
        (16 & this.f || this.v !== t || this.i === 0) &&
          ((this.v = t), (this.f &= -17), this.i++);
      } catch (r) {
        (this.v = r), (this.f |= 16), this.i++;
      }
      return (z = e), Pi(this), (this.f &= -2), !0;
    }),
    (Se.prototype.S = function (e) {
      if (this.t === void 0) {
        this.f |= 36;
        for (var t = this.s; t !== void 0; t = t.n) t.S.S(t);
      }
      X.prototype.S.call(this, e);
    }),
    (Se.prototype.U = function (e) {
      if (
        this.t !== void 0 &&
        (X.prototype.U.call(this, e), this.t === void 0)
      ) {
        this.f &= -33;
        for (var t = this.s; t !== void 0; t = t.n) t.S.U(t);
      }
    }),
    (Se.prototype.N = function () {
      if (!(2 & this.f)) {
        this.f |= 6;
        for (var e = this.t; e !== void 0; e = e.x) e.t.N();
      }
    }),
    Object.defineProperty(Se.prototype, "value", {
      get: function () {
        if (1 & this.f) throw new Error("Cycle detected");
        var e = Ri(this);
        if ((this.h(), e !== void 0 && (e.i = this.i), 16 & this.f))
          throw this.v;
        return this.v;
      },
    });
  function Fl(e, t) {
    return new Se(e, t);
  }
  function zi(e) {
    var t = e.u;
    if (((e.u = void 0), typeof t == "function")) {
      Le++;
      var r = z;
      z = void 0;
      try {
        t();
      } catch (n) {
        throw ((e.f &= -2), (e.f |= 8), nn(e), n);
      } finally {
        (z = r), tn();
      }
    }
  }
  function nn(e) {
    for (var t = e.s; t !== void 0; t = t.n) t.S.U(t);
    (e.x = void 0), (e.s = void 0), zi(e);
  }
  function Gl(e) {
    if (z !== this) throw new Error("Out-of-order effect");
    Pi(this), (z = e), (this.f &= -2), 8 & this.f && nn(this), tn();
  }
  function Ve(e, t) {
    (this.x = e),
      (this.u = void 0),
      (this.s = void 0),
      (this.o = void 0),
      (this.f = 32),
      (this.name = t?.name);
  }
  (Ve.prototype.c = function () {
    var e = this.S();
    try {
      if (8 & this.f || this.x === void 0) return;
      var t = this.x();
      typeof t == "function" && (this.u = t);
    } finally {
      e();
    }
  }),
    (Ve.prototype.S = function () {
      if (1 & this.f) throw new Error("Cycle detected");
      (this.f |= 1), (this.f &= -9), zi(this), Di(this), Le++;
      var e = z;
      return (z = this), Gl.bind(this, e);
    }),
    (Ve.prototype.N = function () {
      2 & this.f || ((this.f |= 2), (this.o = Qe), (Qe = this));
    }),
    (Ve.prototype.d = function () {
      (this.f |= 8), 1 & this.f || nn(this);
    }),
    (Ve.prototype.dispose = function () {
      this.d();
    });
  function Ot(e, t) {
    var r = new Ve(e, t);
    try {
      r.c();
    } catch (a) {
      throw (r.d(), a);
    }
    var n = r.d.bind(r);
    return (n[Symbol.dispose] = n), n;
  }
  var Rt;
  function He(e, t) {
    C[e] = t.bind(null, C[e] || function () {});
  }
  function Nt(e) {
    if (Rt) {
      var t = Rt;
      (Rt = void 0), t();
    }
    Rt = e && e.S();
  }
  function Ui(e) {
    var t = this,
      r = e.data,
      n = an(r);
    n.value = r;
    var a = ce(function () {
      for (var i = t.__v; (i = i.__); )
        if (i.__c) {
          i.__c.__$f |= 4;
          break;
        }
      return (
        (t.__$u.c = function () {
          var o,
            c = t.__$u.S(),
            l = a.value;
          c(),
            jn(l) || ((o = t.base) == null ? void 0 : o.nodeType) !== 3
              ? ((t.__$f |= 1), t.setState({}))
              : (t.base.data = l);
        }),
        Fl(function () {
          var o = n.value.value;
          return o === 0 ? 0 : o === !0 ? "" : o || "";
        })
      );
    }, []);
    return a.value;
  }
  (Ui.displayName = "_st"),
    Object.defineProperties(X.prototype, {
      constructor: { configurable: !0, value: void 0 },
      type: { configurable: !0, value: Ui },
      props: {
        configurable: !0,
        get: function () {
          return { data: this };
        },
      },
      __b: { configurable: !0, value: 1 },
    }),
    He("__b", function (e, t) {
      if (typeof t.type == "string") {
        var r,
          n = t.props;
        for (var a in n)
          if (a !== "children") {
            var i = n[a];
            i instanceof X &&
              (r || (t.__np = r = {}), (r[a] = i), (n[a] = i.peek()));
          }
      }
      e(t);
    }),
    He("__r", function (e, t) {
      e(t), Nt();
      var r,
        n = t.__c;
      n &&
        ((n.__$f &= -2),
        (r = n.__$u) === void 0 &&
          (n.__$u = r =
            (function (a) {
              var i;
              return (
                Ot(function () {
                  i = this;
                }),
                (i.c = function () {
                  (n.__$f |= 1), n.setState({});
                }),
                i
              );
            })())),
        Nt(r);
    }),
    He("__e", function (e, t, r, n) {
      Nt(), e(t, r, n);
    }),
    He("diffed", function (e, t) {
      Nt();
      var r;
      if (typeof t.type == "string" && (r = t.__e)) {
        var n = t.__np,
          a = t.props;
        if (n) {
          var i = r.U;
          if (i)
            for (var o in i) {
              var c = i[o];
              c !== void 0 && !(o in n) && (c.d(), (i[o] = void 0));
            }
          else r.U = i = {};
          for (var l in n) {
            var u = i[l],
              p = n[l];
            u === void 0 ? ((u = jl(r, l, p, a)), (i[l] = u)) : u.o(p, a);
          }
        }
      }
      e(t);
    });
  function jl(e, t, r, n) {
    var a = t in e && e.ownerSVGElement === void 0,
      i = U(r);
    return {
      o: function (o, c) {
        (i.value = o), (n = c);
      },
      d: Ot(function () {
        var o = i.value.value;
        n[t] !== o &&
          ((n[t] = o),
          a ? (e[t] = o) : o ? e.setAttribute(t, o) : e.removeAttribute(t));
      }),
    };
  }
  He("unmount", function (e, t) {
    if (typeof t.type == "string") {
      var r = t.__e;
      if (r) {
        var n = r.U;
        if (n) {
          r.U = void 0;
          for (var a in n) {
            var i = n[a];
            i && i.d();
          }
        }
      }
    } else {
      var o = t.__c;
      if (o) {
        var c = o.__$u;
        c && ((o.__$u = void 0), c.d());
      }
    }
    e(t);
  }),
    He("__h", function (e, t, r, n) {
      (n < 3 || n === 9) && (t.__$f |= 2), e(t, r, n);
    }),
    (se.prototype.shouldComponentUpdate = function (e, t) {
      if (this.__R) return !0;
      var r = this.__$u,
        n = r && r.s !== void 0;
      for (var a in t) return !0;
      if (this.__f || (typeof this.u == "boolean" && this.u === !0)) {
        if (!(n || 2 & this.__$f || 4 & this.__$f) || 1 & this.__$f) return !0;
      } else if (!(n || 4 & this.__$f) || 3 & this.__$f) return !0;
      for (var i in e)
        if (i !== "__source" && e[i] !== this.props[i]) return !0;
      for (var o in this.props) if (!(o in e)) return !0;
      return !1;
    });
  function an(e) {
    return ce(function () {
      return U(e);
    }, []);
  }
  class ql {
    get metadata() {
      return this._metadata;
    }
    set metadata(t) {
      this._metadata = t;
    }
    mergeMetadata(t) {
      this.metadata = { ...this.metadata, ...t };
    }
  }
  const ne = U(null),
    Mi = ue(null),
    Wl = ({ trackerService: e, children: t, id: r }) => {
      const n = Et.getResponse(r),
        a = Ar(r);
      return (
        e.mergeMetadata({ butlerResponse: n, payload: a }),
        ne.value?.mergeMetadata({ butlerResponse: n, payload: a }),
        d(Mi.Provider, { value: e, children: t })
      );
    },
    he = () => ae(Mi),
    Bi = U(!1);
  var Je = ((e) => (
    (e.Q25 = "25"), (e.Q50 = "50"), (e.Q75 = "75"), (e.Q95 = "95"), e
  ))(Je || {});
  function Yl(e, t = {}) {
    return e
      ? Object.entries(e)
          .sort(([r], [n]) => {
            const a = t[r] || Number.MAX_SAFE_INTEGER,
              i = t[n] || Number.MAX_SAFE_INTEGER;
            return a - i;
          })
          .map(([r, n]) =>
            Array.isArray(n)
              ? n
                  .map(
                    (a) => `${encodeURIComponent(r)}=${encodeURIComponent(a)}`
                  )
                  .join("&")
              : `${encodeURIComponent(r)}=${encodeURIComponent(n)}`
          )
          .join("&")
      : "";
  }
  function Xl(e) {
    const t = location.search;
    return t.length === 0
      ? !1
      : !!t
          .slice(1)
          .split("&")
          .find((r) => r.split("=")[0] == e);
  }
  function Kl(e) {
    const t = document.createElement("script");
    Array.from(e.attributes).forEach((r) => {
      try {
        t.setAttribute(r.nodeName, r.nodeValue || "");
      } catch {}
    });
    try {
      t.appendChild(document.createTextNode(e.innerHTML));
    } catch {
      t.text = e.innerHTML;
    }
    return t;
  }
  function Ql(e) {
    Array.from(e.getElementsByTagName("script")).forEach((r) =>
      r.parentNode.replaceChild(td.copyScriptTag(r), r)
    );
  }
  function Jl() {
    let e;
    return (
      typeof Event == "function"
        ? (e = new MouseEvent("click"))
        : ((e = document.createEvent("MouseEvents")),
          e.initEvent("click", !0, !0)),
      e
    );
  }
  const Li = (e) => {
      const t = e.dataset,
        r = t.gcId,
        n = t.gcPayload,
        a = t.gcTrackerBaseUrl;
      if (!r)
        throw new Error(
          "Ground Control ID is missing in div dataset (data-gc-id)."
        );
      if (!n)
        throw new Error(
          "Ground Control payload is missing in div dataset (data-gc-payload)."
        );
      if (!a)
        throw new Error(
          "Ground Control tracker base URL is missing in div dataset (data-gc-tracker-base-url)."
        );
      return { id: r, payload: n, trackerBaseUrl: a, rootElement: e };
    },
    Zl = (e) => {
      if (!e || typeof e != "string")
        throw new Error("Input must be a non-empty string");
      try {
        return decodeURIComponent(
          atob(Vi(e))
            .split("")
            .map((t) => "%" + ("00" + t.charCodeAt(0).toString(16)).slice(-2))
            .join("")
        );
      } catch {
        return atob(Vi(e));
      }
    },
    Vi = (e) => {
      const t = (4 - (e.length % 4)) % 4;
      return (e + "=".repeat(t)).replace(/-/g, "+").replace(/_/g, "/");
    },
    ed = (e) => {
      const t = window[e];
      if (t == null)
        throw new Error(`No payload found on window object for id "${e}"`);
      return t;
    },
    Hi = (e) => {
      if (typeof e != "string")
        throw new Error(`Expected payload to be a string, got ${typeof e}`);
      try {
        return Zl(e);
      } catch {
        return e;
      }
    },
    td = { copyScriptTag: Kl },
    rd = (e, t) => {
      try {
        const r = document.querySelector(`[data-gc-id="${e}"]`);
        if (!r) return null;
        const n = Li(r);
        return Hi(n.payload);
      } catch (r) {
        return (
          R(r, {
            scope: t,
            context: "payload-reader/get-raw-payload-from-dataset",
            id: e,
          }),
          null
        );
      }
    },
    nd = (e, t) => {
      try {
        const n = rd(e, t) ?? ed(e);
        if (typeof n == "object" && n !== null) return n;
        const a = Hi(n);
        return JSON.parse(a);
      } catch (r) {
        throw new Error(
          `Failed to parse payload for id "${e}": ${
            r instanceof Error ? r.message : String(r)
          }`
        );
      }
    };
  function ad(e = window) {
    return Object.prototype.hasOwnProperty.call(e, "AMP_CONTEXT_DATA");
  }
  const J = {
    isSafeFrame: (e) => {
      try {
        return J.safeFrameWindow(e), !0;
      } catch {
        return !1;
      }
    },
    safeFrameWindow: (e) => {
      e || (e = window);
      try {
        if (e === window.top) {
          if (e.$sf && e.$sf.ext) return e;
          throw new Error("Safeframe not found");
        } else return e.$sf && e.$sf.ext ? e : J.safeFrameWindow(e.parent);
      } catch {
        throw new Error("Safeframe not found");
      }
    },
    register: (e = 0) => {
      const t = J.safeFrameWindow(),
        r = J.containerGeometry();
      if (!r) {
        e < 5 && setTimeout(() => J.register(e + 1), 200);
        return;
      }
      t.$sf.ext.register(r.w, r.h, (n, a) => null);
    },
    expandFullscreen: () => Promise.resolve(J.expand(J.expansionGeometry())),
    expand: (e) => {
      const t = J.safeFrameWindow();
      return t.$sf.ext.status() == "expanded"
        ? Promise.resolve()
        : Promise.resolve(t.$sf.ext.expand(e));
    },
    collapse: () => {
      const e = J.safeFrameWindow();
      return e.$sf.ext.status() == "collapsed"
        ? Promise.resolve()
        : (e.$sf.ext.collapse(),
          new Promise((t, r) => {
            const n = setInterval(function () {
              e.$sf.ext.status() === "collapsed" && (clearInterval(n), t());
            }, 100);
          }));
    },
    expansionGeometry: () => J.safeFrameWindow().$sf.ext.geom().exp,
    containerGeometry: () => J.safeFrameWindow().$sf.ext.geom().self,
    windowGeometry: () => J.safeFrameWindow().$sf.ext.geom().win,
  };
  var id = { clickoutDomain: "https://clickout.sharethrough.com" };
  const od = (e) => {
      window.location.assign(e);
    },
    sd = (e, t, r) =>
      !t || !r
        ? e
        : `${id.clickoutDomain}?clickout_url=${encodeURIComponent(
            e
          )}&token=${t}&nonce=${r}`,
    cd = (e = window) => e.self !== e.top,
    ld = (e = window) => e.self === e.top,
    dd = [
      "localhost:9100",
      "localhost:7824",
      "storage.googleapis.com/g-authorized-buyers-creative-previews",
      "eqt-gc.rendering.sharethrough.com",
    ],
    Ze = () => {
      const e = window?.location?.href || "";
      return (
        (window.location.ancestorOrigins
          ? [...Array.from(window.location.ancestorOrigins), e]
          : [e]
        ).some((r) => dd.some((n) => r.includes(n))) || !1
      );
    };
  function ud(e = window) {
    return ad(e) ? `amp-${$i(e)}` : $i(e);
  }
  function Dt(e = window) {
    try {
      if (Ze()) {
        const t = e;
        if (t.isFriendlyIframe && typeof t.isFriendlyIframe == "function")
          return t.isFriendlyIframe();
      }
      return e !== e.top && !!e.top?.document;
    } catch {
      return !1;
    }
  }
  function $i(e = window) {
    return J.isSafeFrame(e)
      ? "safeframe"
      : Dt(e)
      ? "friendly-iframe"
      : cd(e)
      ? "iframe"
      : ld(e)
      ? "top"
      : "unknown";
  }
  const on = U([]),
    pd = (e, t) => {
      if (t) return t;
      {
        const r = e.name.match(/type=([^&]*)/);
        return r ? r[1] : "";
      }
    },
    hd = (e, t) => {
      if (t) return "";
      const r = e.name.match(/userEvent=([^&]*)/);
      return r ? r[1] : "";
    },
    md = (e, t) => {
      if (t) return "";
      const r = e.name.match(/arid=([^&]*)/);
      return r ? r[1] : "";
    };
  function Fi(e, t) {
    const r = e.responseStart - e.requestStart,
      n = e.responseEnd - e.fetchStart,
      a = e.responseEnd - e.startTime,
      i = e.name,
      o = pd(e, t),
      c = hd(e, !!t),
      l = md(e, !!t);
    (on.value = [
      ...on.value,
      {
        arid: l,
        type: o,
        name: i,
        userEvent: c,
        requestTime: r,
        fetchTime: n,
        totalTime: a,
      },
    ]),
      window.top?.postMessage(
        { type: "performanceEntriesSignal", data: on.value },
        "*"
      );
  }
  function fd(e, t) {
    new PerformanceObserver((n) => {
      n.getEntries()
        .filter((a) => a instanceof PerformanceResourceTiming)
        .forEach((a) => {
          const i = a;
          try {
            const c = new URL(i.name).hostname;
            e.some((u) => {
              try {
                const h = new URL(u).hostname;
                return c === h;
              } catch (p) {
                return console.error("Error parsing URL:", u, p), !1;
              }
            }) && Fi(i, t);
          } catch (o) {
            console.error("Error parsing resource URL:", i.name, o);
          }
        });
    }).observe({ type: "resource", buffered: !0 });
  }
  const gd = async (e, t) => {
      const { timeout: r, ...n } = t,
        a = new Promise((o, c) =>
          setTimeout(() => c(new Error("Request timeout")), r || 2e3)
        ),
        i = fetch(e, n);
      return Promise.race([i, a]);
    },
    bd = (e) => {
      try {
        const t = new URL(e),
          r = t.hostname,
          n = t.pathname;
        return r === "b-staging.sharethrough.com"
          ? !0
          : /^ssb-[^.]+\.smartadserver\.com$/.test(r) &&
              (n === "/api/event" || n === "/api/imp");
      } catch {
        return !1;
      }
    },
    vd = (e) => {
      try {
        const t = new URL(e);
        if (t.pathname === "/api/imp") return "impression";
        const r = t.searchParams.get("actionid");
        return r ? Object.keys(D).find((a) => D[a] === r) || r : "";
      } catch {
        return "";
      }
    };
  function _d() {
    new PerformanceObserver((t) => {
      t.getEntries()
        .filter((r) => r instanceof PerformanceResourceTiming)
        .forEach((r) => {
          if (bd(r.name)) {
            const n = vd(r.name);
            n && Fi(r, n);
          }
        });
    }).observe({ type: "resource", buffered: !0 });
  }
  function wd(e) {
    if (!e.creative.trackers || e.creative.trackers.length === 0) return;
    const t = new Map();
    e.creative.trackers.forEach((r) => {
      const n = r.event,
        a = r.url;
      a && (t.has(n) || t.set(n, []), t.get(n).push(a));
    }),
      t.forEach((r, n) => {
        r.length > 0 && fd(r, `event_${n}`);
      });
  }
  const yd = ue(void 0),
    xd = {
      2: F.MAIN,
      4: I.CTATEXT,
      5: I.SPONSORED,
      6: F.ICON,
      9: I.DESC,
      10: I.RATING,
      11: I.PRICE,
      31: F.LOGO,
      403: I.RATING,
      404: I.LIKES,
      406: I.PRICE,
      407: I.SALEPRICE,
      507: I.BADGE,
      508: I.REVIEW,
      511: I.CLIMATE_PLEDGE,
      512: I.COUPON,
      513: F.AVAILABLE_ON_AMAZON,
      514: F.PRIME_LOGO,
    },
    Gi = {
      1: "title",
      2: F.ICON,
      3: F.LOGO,
      4: F.MAIN,
      5: I.SPONSORED,
      6: I.DESC,
      11: I.OPT_OUT,
      12: I.OPT_OUT_URL,
      14: I.CTATEXT,
      21: F.LOGO,
      22: F.MAIN,
      23: F.MAIN,
      31: F.LOGO,
      32: F.MAIN,
      33: F.MAIN,
      503: I.ISI,
      504: I.BANNER,
      507: I.BADGE,
      508: I.REVIEW,
      511: I.CLIMATE_PLEDGE,
      512: I.COUPON,
      513: F.AVAILABLE_ON_AMAZON,
      514: F.PRIME_LOGO,
      403: I.RATING,
      404: I.LIKES,
      406: I.PRICE,
      407: I.SALEPRICE,
    },
    Ed = (() => {
      try {
        return xd;
      } catch (e) {
        return console.error("Error getting assets mapping", e), Gi;
      }
    })(),
    ji = (e) =>
      Object.entries(Ed)
        .filter(([t, r]) => r === e)
        .map(([t]) => Number(t)),
    et = (e, t) =>
      e.img.type !== void 0 ? e.img.type === t : ji(t).includes(e.id),
    Ad = (e) => tt(e) && et(e, F.ICON),
    kd = (e) => tt(e) && et(e, F.LOGO),
    Id = (e) => tt(e) && et(e, F.MAIN),
    Cd = (e) => tt(e) && et(e, F.PRIME_LOGO),
    Sd = (e) => tt(e) && et(e, F.AVAILABLE_ON_AMAZON),
    te = (e, t) =>
      e.data.type !== void 0 ? e.data.type === t : ji(t).includes(e.id),
    Td = (e) => Z(e) && te(e, I.SPONSORED),
    Od = (e) => Z(e) && te(e, I.DESC),
    Rd = (e) => Z(e) && te(e, I.RATING),
    Nd = (e) => Z(e) && te(e, I.CTATEXT),
    Dd = (e) => Z(e) && te(e, I.LIKES),
    Pd = (e) => Z(e) && te(e, I.DOWNLOADS),
    zd = (e) => Z(e) && te(e, I.PRICE),
    Ud = (e) => Z(e) && te(e, I.SALEPRICE),
    Md = (e) => Z(e) && te(e, I.PHONE),
    Bd = (e) => Z(e) && te(e, I.ADDRESS),
    Ld = (e) => Z(e) && te(e, I.DESC2),
    Vd = (e) => Z(e) && te(e, I.DISPLAYURL),
    Hd = (e) => Z(e) && te(e, I.BADGE),
    $d = (e) => Z(e) && te(e, I.REVIEW),
    Fd = (e) => Z(e) && te(e, I.COUPON),
    Gd = (e) => Z(e) && e.data.type === I.SHOPPABLE,
    Z = (e) => typeof e == "object" && e !== null && "data" in e,
    tt = (e) => typeof e == "object" && e !== null && "img" in e,
    jd = (e) => typeof e == "object" && e !== null && "title" in e,
    qd = [
      "single_product",
      "single_product_carousel",
      "multi_product_carousel",
    ],
    Wd = (e) => typeof e == "string" && qd.includes(e),
    Yd = /^#?(?:[0-9a-fA-F]{3,4}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})$/,
    Pt = (e) => {
      if (typeof e != "string") return;
      const t = e.trim();
      if (Yd.test(t)) return t.startsWith("#") ? t : `#${t}`;
    },
    Xd = (e) => {
      if (!e || typeof e != "object") return;
      const t = {
        textColor: Pt(e.textColor),
        textHoverColor: Pt(e.textHoverColor),
        backgroundColor: Pt(e.backgroundColor),
        backgroundHoverColor: Pt(e.backgroundHoverColor),
      };
      return Object.values(t).some(Boolean) ? t : void 0;
    },
    qi = (e) => {
      const t = [...e];
      for (let r = t.length - 1; r > 0; r--) {
        const n = Math.floor(Math.random() * (r + 1));
        [t[r], t[n]] = [t[n], t[r]];
      }
      return t;
    };
  class Kd {
    constructor(t) {
      this.assets = t;
    }
    get title() {
      return this._title || (this._title = this.assets.find(jd)), this._title;
    }
    get mainImage() {
      return (
        this._mainImage || (this._mainImage = this.assets.find(Id)),
        this._mainImage
      );
    }
    get logo() {
      return this._logo || (this._logo = this.assets.find(kd)), this._logo;
    }
    get icon() {
      if (
        (this._icon || (this._icon = this.assets.find(Ad)),
        this._icon?.img.url !== this.mainImage?.img.url)
      )
        return this._icon;
    }
    get primeLogo() {
      return (
        this._primeLogo || (this._primeLogo = this.assets.find(Cd)),
        this._primeLogo
      );
    }
    get availableOnAmazon() {
      return (
        this._availableOnAmazon ||
          (this._availableOnAmazon = this.assets.find(Sd)),
        this._availableOnAmazon
      );
    }
    get sponsored() {
      return (
        this._sponsored || (this._sponsored = this.assets.find(Td)),
        this._sponsored
      );
    }
    get description() {
      return (
        this._description || (this._description = this.assets.find(Od)),
        this._description
      );
    }
    get rating() {
      return (
        this._rating || (this._rating = this.assets.find(Rd)), this._rating
      );
    }
    get likes() {
      return this._likes || (this._likes = this.assets.find(Dd)), this._likes;
    }
    get downloads() {
      return (
        this._downloads || (this._downloads = this.assets.find(Pd)),
        this._downloads
      );
    }
    get price() {
      return this._price || (this._price = this.assets.find(zd)), this._price;
    }
    get salePrice() {
      return (
        this._salePrice || (this._salePrice = this.assets.find(Ud)),
        this._salePrice
      );
    }
    get phone() {
      return this._phone || (this._phone = this.assets.find(Md)), this._phone;
    }
    get address() {
      return (
        this._address || (this._address = this.assets.find(Bd)), this._address
      );
    }
    get desc2() {
      return this._desc2 || (this._desc2 = this.assets.find(Ld)), this._desc2;
    }
    get displayUrl() {
      return (
        this._displayUrl || (this._displayUrl = this.assets.find(Vd)),
        this._displayUrl
      );
    }
    get cta() {
      return this._cta || (this._cta = this.assets.find(Nd)), this._cta;
    }
    get review() {
      return (
        this._review || (this._review = this.assets.find($d)), this._review
      );
    }
    get badge() {
      return this._badge || (this._badge = this.assets.find(Hd)), this._badge;
    }
    get coupon() {
      return (
        this._coupon || (this._coupon = this.assets.find(Fd)), this._coupon
      );
    }
    get shoppable() {
      if (this._shoppable === void 0) {
        const t = this.assets.find(Gd)?.data.ext;
        if (!t || !Wd(t.format)) this._shoppable = null;
        else {
          let r = t.products ?? [];
          t.shuffle &&
            (t.format === "multi_product_carousel"
              ? (r = qi(r))
              : t.format === "single_product_carousel" &&
                r[0]?.images &&
                (r = [{ ...r[0], images: qi(r[0].images) }, ...r.slice(1)]));
          const n =
            (typeof t.sponsoredBy == "string" && t.sponsoredBy.trim()) ||
            void 0;
          this._shoppable = {
            ...t,
            products: r,
            ctaStyle: Xd(t.ctaStyle),
            sponsoredBy: n,
          };
        }
      }
      return this._shoppable ?? void 0;
    }
  }
  const zt = U(void 0),
    Wi = (e) => {
      zt.value = new Kd(e);
    },
    Qd = 1200,
    Yi = (e) =>
      e instanceof Error
        ? e.message
        : typeof e == "string"
        ? e
        : "Unknown error";
  async function Jd(e) {
    try {
      let t;
      try {
        if (((t = await gd(e, { timeout: Qd })), !t.ok))
          throw new Error(`HTTP error! status: ${t.status}`);
      } catch (a) {
        const i = Yi(a);
        throw new Error(`DCO Request Failed : ${i}`);
      }
      const r = await t.text();
      if (r.trim().length === 0) return null;
      let n;
      try {
        n = JSON.parse(r);
      } catch {
        return null;
      }
      return Object.keys(n).length === 0 ? null : n.assets;
    } catch (t) {
      const r = Yi(t);
      throw (console.error("Failed to parse Dco assets", r), t);
    }
  }
  const H = () => {
    const e = ae(yd);
    return e || (zt.value ? zt.value : null);
  };
  var rt = ((e) => (
      (e[(e.Impression = 1)] = "Impression"),
      (e[(e.ViewableMrc50 = 2)] = "ViewableMrc50"),
      e
    ))(rt || {}),
    Xi = ((e) => ((e[(e.Img = 1)] = "Img"), (e[(e.Js = 2)] = "Js"), e))(
      Xi || {}
    );
  class Zd {
    constructor(t) {
      (this.event = t.event), (this.method = t.method), (this.url = t.url);
    }
  }
  const eu = (e) =>
    typeof e == "object" &&
    e !== null &&
    "event" in e &&
    typeof e.event == "number" &&
    Object.values(rt).includes(e.event) &&
    "method" in e &&
    typeof e.method == "number" &&
    Object.values(Xi).includes(e.method) &&
    "url" in e &&
    typeof e.url == "string" &&
    e.url !== "";
  class tu extends Array {
    constructor(t) {
      const r = Array.isArray(t) ? t : [];
      super(...r.filter((n) => eu(n)).map((n) => new Zd(n)));
    }
    insertJsTracker(t, r) {
      const n = t.filter((a) => a.method === 2).map((a) => a.url);
      for (const a of n) {
        const i = document.createElement("script");
        (i.type = "text/javascript"),
          (i.async = !0),
          (i.src = a),
          r.appendChild(i);
      }
    }
    insertImgTracker(t) {
      const r = async (a) =>
          new Promise((i, o) => {
            const c = new Image();
            (c.onload = () => {
              i();
            }),
              (c.onerror = () => {
                i();
              }),
              (c.src = a);
          }),
        n = t.filter((a) => a.method === 1).map((a) => a.url);
      for (const a of n)
        r(a).catch((i) => {
          console.error("Error loading image tracker:", i);
        });
    }
    getTrackersByType(t) {
      const r = this.filter((a) => a.event === t && a.method === 2),
        n = this.filter((a) => a.event === t && a.method === 1);
      return { jsTrackers: r, imgTrackers: n };
    }
    fireEventTrackerByType(t, r) {
      try {
        const { jsTrackers: n, imgTrackers: a } = this.getTrackersByType(t);
        this.insertJsTracker(n, r), this.insertImgTracker(a);
      } catch (n) {
        console.error("Error firing impression trackers:", n);
      }
    }
  }
  const Ki = 0.5,
    sn = new Map();
  let Ee = new Set(),
    Ae = new Set();
  class Ut {
    static startup() {
      document.addEventListener(
        "visibilitychange",
        Ut.handleVisibilityChange,
        !1
      );
    }
    static handleVisibilityChange() {
      document.hidden
        ? Ae.size === 0 &&
          ((Ae = new Set(Ee)),
          Ee.clear(),
          Ae.forEach(function (t) {
            nt.retrieve(t).comeOutOfView();
          }))
        : (Ae.forEach(function (t) {
            nt.retrieve(t).comeInView();
          }),
          (Ee = new Set(Ae)),
          Ae.clear());
    }
    static intersectionCallback(t) {
      t.forEach(function (r) {
        const n = r.target,
          a = nt.retrieve(n);
        r.isIntersecting && r.intersectionRatio >= Ki
          ? (a.comeInView(), Ee.add(n))
          : (a.comeOutOfView(), Ee.delete(n));
      });
    }
    static getVisibleAds() {
      return Ee;
    }
    static getPreviouslyVisibleAds() {
      return Ae;
    }
    static resetTrackedAds() {
      sn.clear(), Ee.clear(), Ae.clear();
    }
  }
  const ru = () => "_" + Math.random().toString(36).substr(2, 9),
    nu = (e, t) =>
      typeof IntersectionObserver > "u"
        ? new nt(e, t, null)
        : ((Qi = new IntersectionObserver(Ut.intersectionCallback, {
            root: null,
            rootMargin: "0px",
            threshold: [Ki],
          })),
          new nt(e, t, Qi));
  class nt {
    constructor(t, r, n) {
      (this.inViewTime = 1e3),
        (this.element = t),
        (this.visibleFired = !1),
        (this.arid = r),
        (this.timer = void 0);
      const { creative: a } = Ar(r);
      if ((a.type === N.Outstream && (this.inViewTime = 2e3), !t)) return;
      const i = ru();
      (t.dataset.trackingKey = i), sn.set(i, this), n?.observe(t);
    }
    static retrieve(t) {
      return sn.get(t.dataset.trackingKey);
    }
    comeInView() {
      if (!this.visibleFired) {
        const t = this;
        this.timer = window.setTimeout(() => {
          t.fireVisible();
        }, this.inViewTime);
      }
    }
    comeOutOfView() {
      window.clearTimeout(this.timer), (this.timer = void 0);
    }
    fireVisible() {
      ne.value?.trackViewableImpression(),
        ne.value?.trackOrtbEvent(rt.ViewableMrc50, this.element),
        (this.visibleFired = !0);
    }
  }
  let Qi = null;
  function au(e) {
    return e.replace(/\\(.)/g, "$1");
  }
  const at = (e) =>
      e
        .toLowerCase()
        .replace(/[^a-z0-9]/g, "-")
        .replace(/-+/g, "-")
        .replace(/^-|-$/g, ""),
    iu = (e, t, r, n) => {
      if (
        !(
          navigator.userAgent.toLowerCase().includes("firefox") ||
          !("ReportingObserver" in window)
        )
      )
        try {
          const i = (c) => {
              for (const l of c)
                l.type === "intervention" &&
                  l.body &&
                  "id" in l.body &&
                  l.body.id === "HeavyAdIntervention" &&
                  (r.trackHeavyAdIntervention(),
                  R(new Error("HeavyAdIntervention detected"), {
                    scope: n,
                    context: "helpers:heavy-ad-intervention",
                    report: l,
                    id: e ?? void 0,
                    payloadId: e,
                    placeholderAttributes: t.dataset || {},
                  }));
            },
            o = new ReportingObserver(
              (c) => {
                i(c);
              },
              { buffered: !0 }
            );
          o.observe(),
            window.addEventListener("pagehide", () => {
              const c = o.takeRecords();
              i(c), o.disconnect();
            });
        } catch {}
    },
    ou = 0.01,
    su = (e) => Math.random() < e,
    cu = () => su(ou),
    lu = (e, t, ...r) => {
      console.log(`STR:${e}`, t, ...r);
    },
    Ji = (e, ...t) => {
      lu("debug", e, ...t);
    },
    du = (e, t) => {
      const r = O(() => {});
      A(() => {
        r.current = e;
      }),
        A(() => {
          if (t === null) return;
          function n() {
            r.current && r.current();
          }
          const a = setInterval(n, t);
          return () => clearInterval(a);
        }, [t]);
    },
    uu = /(Exchange|TAGID|DSPID|CRID)\s*:\s*([^,]+?)(?=\s*,|\s*$)/g,
    pu = { Exchange: "exchange", TAGID: "tagId", DSPID: "dspId", CRID: "crid" },
    hu = (e) =>
      e.includes("Exchange:") &&
      (e.includes("TAGID:") || e.includes("DSPID:") || e.includes("CRID:")),
    Zi = (e) => {
      if (!hu(e)) return null;
      const t = {};
      for (const r of e.matchAll(uu)) {
        const [, n, a] = r,
          i = pu[n];
        i && (t[i] = a.trim());
      }
      return Object.keys(t).length > 0 ? t : null;
    },
    mu = (e) => {
      const t = e.parentNode;
      if (!t) return null;
      for (const r of Array.from(t.childNodes)) {
        if (r.nodeType !== Node.COMMENT_NODE) continue;
        const n = Zi(r.nodeValue ?? "");
        if (n) return n;
      }
      return null;
    },
    fu = (e = document.body) => {
      if (!e) return null;
      const t = document.createTreeWalker(e, NodeFilter.SHOW_COMMENT);
      for (let r = t.nextNode(); r !== null; r = t.nextNode()) {
        const n = Zi(r.nodeValue ?? "");
        if (n) return n;
      }
      return null;
    },
    gu = "[data-gc-payload]:not([data-str-visited-flag]):not(script)",
    bu = "[data-stx-response-name]:not([data-str-visited-flag])",
    vu = "script[data-gc-payload]:not([data-str-visited-flag])",
    eo = 1e-4,
    _u = () => ({
      function: "tag/index:boot",
      readyState: document.readyState,
      allDataGcPayload: document.querySelectorAll("[data-gc-payload]").length,
      visitedPayloadCount: document.querySelectorAll(
        "[data-gc-payload][data-str-visited-flag]"
      ).length,
      bodyChildrenCount: document.body?.children.length ?? -1,
      iframeCount: document.querySelectorAll("iframe").length,
      scriptCount: document.querySelectorAll("script").length,
      bodySnippet: document.body?.innerHTML?.substring(0, 500),
      documentSize: document.documentElement?.outerHTML?.length ?? 0,
      referrer: document.referrer || void 0,
      ancestorOrigins: window.location.ancestorOrigins?.length
        ? Array.from(window.location.ancestorOrigins)
        : void 0,
      isTopDocument: window.self === window.top,
      ...(fu() ?? {}),
    }),
    wu = (e) => {
      const t = e.parentNode;
      if (!t) return null;
      const r = document.createElement("div");
      for (const n of Array.from(e.attributes))
        n.name.startsWith("data-") && r.setAttribute(n.name, n.value);
      return (
        t.insertBefore(r, e), e.setAttribute("data-str-visited-flag", ""), r
      );
    },
    yu = () => Array.from(document.querySelectorAll(gu)),
    xu = () => Array.from(document.querySelectorAll(bu)),
    Eu = () =>
      Array.from(document.querySelectorAll(vu))
        .map(wu)
        .filter((e) => e !== null),
    Au = [yu, xu],
    ku = [Eu],
    Iu = () => {
      if (window.self === window.top) return;
      const e = document.documentElement?.outerHTML;
      if (!e) return;
      const r = `boot-failure/${`${Date.now()}-${Math.random()
        .toString(36)
        .slice(2, 10)}`}`;
      try {
        fetch(wr, {
          method: "POST",
          body: JSON.stringify({
            path: r,
            content: { html: e },
            contentType: "html",
          }),
        }).catch(() => {});
      } catch {}
      return `${_a}/${r}`;
    },
    Cu = async (e, t, r) => {
      r.enter(re.Placeholder), Ut.startup(), Bc();
      const n = Au.flatMap((i) => i()),
        a = n.length > 0 ? n : ku.flatMap((i) => i());
      if (a.length === 0) {
        if (Math.random() >= eo) return;
        const i = Iu();
        R(new Error("boot: no ad placeholders matched"), {
          scope: r,
          ..._u(),
          ...(i ? { bodyDumpUrl: i } : {}),
          sampling: { alreadySampledAt: eo },
        });
        return;
      }
      await Promise.all(a.map((i) => t(i, e)));
    };
  class cn extends se {
    constructor(t) {
      super(t),
        (this._payload = null),
        (this._butlerResponse = null),
        (this.lifecycleScope = Na(t.adserverRequestId));
    }
    get payload() {
      return (
        this._payload || (this._payload = Ar(this.props.adserverRequestId)),
        this._payload
      );
    }
    get butlerResponse() {
      return (
        this._butlerResponse ||
          (this._butlerResponse = Et.getResponse(this.props.adserverRequestId)),
        this._butlerResponse
      );
    }
    get creative() {
      return this.butlerResponse?.creative;
    }
    get placement() {
      return this.butlerResponse
        ? this.butlerResponse.placement
        : this.payload.network;
    }
  }
  class $e {
    constructor(t = 5, r = 300) {
      (this.batchSize = t),
        (this.processingInterval = r),
        (this._queue = []),
        (this.cache = new Set()),
        (this.queueLock = new Set()),
        (this.isProcessing = !1),
        window.addEventListener("visibilitychange", () => {
          document.hidden && this.processQueue();
        });
    }
    get queue() {
      return this._queue;
    }
    static getInstance() {
      return $e.instance || ($e.instance = new $e()), $e.instance;
    }
    isInQueue(t) {
      return this._queue.some((r) => r.cacheKey === t.cacheKey);
    }
    isAlreadyFired(t) {
      return !!(t.fireOnce && t.cacheKey && this.cache.has(t.cacheKey));
    }
    tryLock(t) {
      return t.cacheKey
        ? this.queueLock.has(t.cacheKey) || this.isAlreadyFired(t)
          ? !1
          : (this.queueLock.add(t.cacheKey), !0)
        : !0;
    }
    enqueue(t, r) {
      r?.retry && t.cacheKey && this.queueLock.delete(t.cacheKey),
        !(
          t.cacheKey &&
          t.fireOnce &&
          (!this.tryLock(t) || this.isInQueue(t))
        ) && (this._queue.push(t), this.isProcessing || this.processQueue());
    }
    async processQueue() {
      if (this._queue.length === 0) {
        this.isProcessing = !1;
        return;
      }
      this.isProcessing = !0;
      const t = this._queue.splice(0, this.batchSize);
      await Promise.all(
        t.map(async (r) => {
          try {
            const n = await r.sendBeacon();
            r.cacheKey &&
              r.fireOnce &&
              (n
                ? this.cache.add(r.cacheKey)
                : r.retries <= 0 && this.queueLock.delete(r.cacheKey));
          } catch (n) {
            console.error("[BeaconQueue] Failed to send beacon:", n),
              r.cacheKey && this.queueLock.delete(r.cacheKey);
          }
        })
      ),
        setTimeout(() => this.processQueue(), this.processingInterval);
    }
    reset() {
      (this._queue = []),
        this.cache.clear(),
        this.queueLock.clear(),
        (this.isProcessing = !1);
    }
  }
  const Su = $e.getInstance();
  class to {
    constructor() {
      (this.retries = 3), (this.fireOnce = !1);
    }
    enqueue(t) {
      Su.enqueue(this, t);
    }
    async sendBeacon() {
      try {
        return await this.fire(), this.onSuccess && this.onSuccess(), !0;
      } catch {
        return (
          this.retries--,
          this.retries > 0
            ? this.cacheKey
              ? this.enqueue({ retry: !0 })
              : this.enqueue()
            : this.onFailure && this.onFailure(),
          !1
        );
      }
    }
  }
  class ln extends Error {
    constructor(t, r) {
      super(t),
        (this.name = "BeaconError"),
        (this.details = { failureReason: t, ...r }),
        Object.setPrototypeOf(this, ln.prototype);
    }
  }
  const Tu = (e) => {
      try {
        const r = new URL(e).searchParams,
          n = {};
        return (
          r.forEach((a, i) => {
            n[i] = a;
          }),
          n
        );
      } catch (t) {
        console.log("Error converting string params to object", t);
        return;
      }
    },
    dn = async (e) => {
      if (Ze()) {
        const t = Tu(e);
        t &&
        (() => {
          for (const r in t)
            if (Object.prototype.hasOwnProperty.call(t, r)) return !0;
          return !1;
        })()
          ? Ji(`Beacon - ${Nu(t)}`, t)
          : Ji("Beacon - unknown", e);
      }
      return new Promise((t, r) => {
        const n = new Image();
        (n.onload = () => {
          t();
        }),
          (n.onerror = () => {
            t();
          }),
          (n.src = e);
      });
    },
    Ou = (e) => "type" in e && "arid" in e,
    Ru = (e) => "actionid" in e,
    Nu = (e) => (Ou(e) ? e.type : Ru(e) ? e.actionid : "unknown");
  var Du = { trackingDomain: "https://b.sharethrough.com" };
  const Pu = {
    type: 1,
    arid: 2,
    pkey: 3,
    supplyId: 4,
    ckey: 6,
    userEvent: 7,
    umtime: 8,
  };
  class zu extends to {
    constructor(t) {
      super(),
        (this.data = {
          renderEnv: ud(),
          umtime: window.Date.now().toString(),
          version: "gc-eqt-default-0.3.521",
          gcid: Lc(),
          ...t.data,
        }),
        (this.url = this.getBeaconUrl()),
        (this.onSuccess = t.onSuccess),
        (this.onFailure = t.onFailure),
        (this.fireOnce = !!t.fireOnce),
        (this.cacheKey = t.cacheKey || `${this.data.type}-${this.data.arid}`),
        this.enqueue();
    }
    getBeaconUrl() {
      const r = Ze() ? "https://b-staging.sharethrough.com" : Du.trackingDomain,
        n = "butler",
        a = Yl(this.data, Pu);
      return `${r}/${n}?${a}`;
    }
    async fire() {
      return dn(this.url).catch((t) => {
        throw (
          (t instanceof ln &&
            ((t.details.arid = this.data.arid), (t.details.url = this.url)),
          t)
        );
      });
    }
  }
  var ro = ((e) => (
      (e.adPositionChanged = "adPositionChanged"),
      (e.attentionMetrics = "attentionMetrics"),
      (e.bannerRendered = "banner.rendered"),
      (e.beaconError = "beaconError"),
      (e.bundleIdWinTest = "bundle_id_win_test"),
      (e.chromeTopics = "chromeTopics"),
      (e.completionPercent = "completionPercent"),
      (e.dcoRequest = "DCORequest"),
      (e.doubleVerifyError = "doubleVerifyError"),
      (e.doubleVerifyFallback = "doubleVerifyFallback"),
      (e.doubleVerifyRender = "doubleVerifyRender"),
      (e.doubleVerifySuccess = "doubleVerifySuccess"),
      (e.experiment = "is_experiment"),
      (e.groundControlPresent = "groundControlPresent"),
      (e.heavyAdIntervention = "heavyAdIntervention"),
      (e.imaClick = "imaClick"),
      (e.imaNoCreativeIdFound = "imaNoCreativeIdFound"),
      (e.impression = "impression"),
      (e.impressionReceived = "impressionReceived"),
      (e.isEnhanced = "isEnhanced"),
      (e.jsTrackerFailedToLoad = "jsTrackerFailedToLoad"),
      (e.nurlFail = "winNotificationFail"),
      (e.pixelVisibleInApp = "pixelVisibleInApp"),
      (e.silentAutoPlayDuration = "silentAutoPlayDuration"),
      (e.subtitlesEnabled = "subtitlesEnabled"),
      (e.userEvent = "userEvent"),
      (e.vastClickthroughFound = "vastClickthroughFound"),
      (e.vastClickthroughNotFound = "vastClickthroughNotFound"),
      (e.vastErrorCode = "vastErrorCode"),
      (e.vastVpaidEnabled = "VastVpaidEnabled"),
      (e.vastVpaidNotEnabled = "VastVpaidNotEnabled"),
      (e.videoPlay = "videoPlay"),
      (e.videoStart = "videoStart"),
      (e.videoViewDuration = "videoViewDuration"),
      (e.videoVolumeOn = "videoVolumeOn"),
      (e.viewableImpression = "visible"),
      e
    ))(ro || {}),
    it = ((e) => (
      (e.Q25 = "25"), (e.Q50 = "50"), (e.Q75 = "75"), (e.Q95 = "95"), e
    ))(it || {});
  const Uu = (e) => {
    const t = Et.getResponse(e);
    if (!t || t.creative.action !== "clickout") return null;
    let r;
    if (t.creative.isi) r = "isi";
    else if (
      t.creative.thumbnailUrl &&
      t.creative.thumbnailUrl.includes(".gif") &&
      (t.creative.thumbnailUrl.includes(
        "https://str-thumbnails-production.imgix.net/generator"
      ) ||
        t.creative.thumbnailUrl.includes(
          "https://static.sharethrough.com/generator"
        ))
    )
      r = "cinemagraph";
    else return null;
    const n = "9e1fb270-1a8d-4e63-88c1-4132a37acaa7";
    return new zu({
      data: {
        type: ro.experiment,
        arid: e,
        experiment_id: n,
        experiment_variant_id: r,
      },
    });
  };
  class M extends to {
    constructor(t) {
      super(),
        (this.url = t.url),
        (this.onSuccess = t.onSuccess),
        (this.onFailure = t.onFailure),
        (this.fireOnce = !0),
        (this.cacheKey = this.url),
        this.enqueue();
    }
    async fire() {
      return dn(this.url);
    }
  }
  class Mu extends Error {}
  class Bu {
    constructor(t = []) {
      this.rules = t;
    }
    addRule(t) {
      this.rules.push(t), this.sortRulesByPriority();
    }
    sortRulesByPriority() {
      this.rules.sort((t, r) =>
        !t.priority && !r.priority
          ? 0
          : t.priority
          ? r.priority
            ? t.priority - r.priority
            : -1
          : 1
      );
    }
    evaluate(...t) {
      try {
        for (const r of this.rules) {
          const n = r.evaluate(...t);
          if (n) return n;
        }
        return !1;
      } catch (r) {
        if (r === Mu) return !1;
        throw r;
      }
    }
  }
  const Lu = ["17CzF5ktQoN1vCLa3wP58vYU-578616010"],
    Vu = [
      {
        seatIds: ["1456", "5038", "3889"],
        sourceIds: ["5b286190338513af73f09c28"],
      },
      {
        seatIds: ["4019"],
        sourceIds: [
          "n96oYXGCuPykdLqwSM5NUEVp",
          "WSr8YpQigv2XmTC9a4wEFtGB",
          "gcTfVrFXSws6HptieUaGhjCx",
          "gfrnFTBHKayiVeRoMX4QS7cP",
          "BVbSRuzbUWjBEF6bQrmLHKkX",
          "CoMLTJeWvGbEAymUxBat9rRZ",
        ],
      },
      {
        seatIds: [
          "10046",
          "10736",
          "11082",
          "10877",
          "11029",
          "10638",
          "10369",
          "11500",
          "10865",
          "11507",
          "11506",
          "11505",
          "10793",
          "11829",
          "11830",
          "11831",
          "11832",
          "11834",
          "11835",
          "11833",
        ],
        sourceIds: ["4rQWDMHEFSdfRbtp7Kei6UsB", "eyHpF9vNhiWXJC5Zrw7nbfRE"],
      },
      {
        seatIds: ["561971"],
        sourceIds: ["790d3e0174b12a86f1cbebf4", "4EDrwPqGiHXchxbaymLBZovJ"],
      },
    ],
    un = new Bu();
  un.addRule({
    evaluate: (e) => {
      for (const { sourceIds: t, seatIds: r } of Vu)
        if (t.includes(e.partnerId) && e.seatId && r.includes(e.seatId))
          return !0;
      return !1;
    },
  }),
    un.addRule({ evaluate: (e) => !!Lu.includes(e.creativeId) });
  const Hu = (e) => un.evaluate(e),
    $u =
      "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABIAAAASCAYAAABWzo5XAAAABHNCSVQICAgIfAhkiAAAAAlwSFlzAAAK6wAACusBgosNWgAAABx0RVh0U29mdHdhcmUAQWRvYmUgRmlyZXdvcmtzIENTNXG14zYAAAF0SURBVDiNzdTPi89BHMfxx3xtDm6IksjBjxMJf8EcXKiRInugLfkHyIWlbC6bdZCjM3twmrQ50DhsKVubktpcbG1IOXNQGpdJnz770aa+B3N5z7xfr3nO7wm1VuMoo7FQxgmaGEqGkh/gCt5issa0thEodPcolLwJT3C2M8gHnGn1o3hTY1rtg/pLm8b53kwPYRkrmMfHUPKpv4JCydsx1Zq/cB2fWntLr9+9UHJYBwol38YX7Gv5tRrTHPbiFr73QAfwOZS8Gkq+AKNQ8hzuYHPHuNLi4RrTXezHi44+gV1t4Meh5EsjXOuvFz9a3BlKflRj+lpjOomlAe8IsyO8GhAPQo3pJfaEku+3/M0BLyyOkPC8JxwJJcdWv4iroeRjeD0AeYapP/eoHemOJgZMYrrGtBRKvoFzOI0ZLDbftxrTAr0L2S2h5K2YxXs8xALe4WmNaXmdf6PX32Z6AtsQcbzG9POfQR3gDHbXmC4P6v/df/Qb6tJ33hbp654AAAAASUVORK5CYII=",
    Fu = { DEAL_ID_DISABLED: ["gxSag", "NmBT2"] },
    no = {
      "green-pmp-icon": "_green-pmp-icon_gf0hn_1",
      "green-pmp-container": "_green-pmp-container_gf0hn_5",
    },
    Gu = (e) =>
      e.creative.dealId && Fu.DEAL_ID_DISABLED.includes(e.creative.dealId)
        ? null
        : d("div", {
            className: `${no["green-pmp-container"]}`,
            children: d("a", {
              href: "https://www.sharethrough.com/green-icon",
              onClick: (t) => t.stopPropagation(),
              target: "_blank",
              rel: "noopener noreferrer",
              "data-testid": "green-pmp-link",
              children: d("img", {
                src: $u,
                alt: "Green PMP Icon",
                className: `str-green-pmp-icon ${no["green-pmp-icon"]}`,
              }),
            }),
          }),
    ju = {
      AE: "ar",
      BD: "bn",
      BG: "bg",
      BR: "pt-br",
      CA: "en",
      CN: "zh-cn",
      CZ: "cs",
      DE: "de",
      EG: "ar",
      ES: "es",
      FR: "fr",
      GB: "en",
      HK: "zh-hk",
      HR: "hr",
      HU: "hu",
      ID: "id",
      IN: "hi",
      IT: "it",
      JP: "ja",
      KR: "ko",
      LK: "ta",
      MX: "es-mx",
      PH: "tl",
      PL: "pl",
      RO: "ro",
      RS: "sr",
      SA: "ar",
      SK: "sk",
      TH: "th",
      US: "en",
      VN: "vi",
    };
  function ao(e) {
    return e ? Object.values(ju).includes(e) : !1;
  }
  const qu = [
      "lespac.com",
      "rds.ca",
      "noovomoi.ca",
      "sympatico.ca",
      "noovo.ca",
      "lookdujour.ca",
      "lapresse.ca",
      "meilleurstrucs.com",
      "toutacoup.ca",
      "985fm.ca",
      "ledevoir.com",
      "francoischarron.com",
      "lechodelaval.ca",
      "lesaffaires.com",
      "journalmetro.com",
      "zone911.com",
      "journalexpress.ca",
      "neomedia.com",
      "kadogagnant.ca",
      "dessinsdrummond.com",
      "cimtchau.ca",
      "sorel-tracyexpress.ca",
      "droit-inc.com",
      "fm93.com",
      "rythmefm.com",
      "recettedemaman.com",
      "ckoi.com",
      "lanouvelle.net",
      "chamblyexpress.ca",
      "watchmojo.com",
      "radiox.com",
      "fm1047.ca",
      "inmemoriam.ca",
      "lereflet.qc.ca",
      "tvagatineau.ca",
      "journalsaint-francois.ca",
      "stockchase.com",
      "monmatane.com",
      "domainebleu.ca",
      "laction.com",
      "macotenord.com",
      "monjoliette.com",
      "journallesoir.ca",
      "cybersoleil.com",
      "lecitoyenrouynlasarre.com",
      "lecitoyenvaldoramos.com",
      "occasionenor.com",
      "montrealracing.com",
      "cime.fm",
      "wknd.fm",
      "valleedurichelieuexpress.ca",
      "lecourrierdusud.ca",
      "919sports.ca",
      "leclaireurprogres.ca",
      "lechodelarivenord.ca",
      "lerefletdulac.com",
      "mabeauce.com",
      "cjso.ca",
      "monvicto.com",
      "957kyk.com",
      "fm1069.ca",
      "fm1033.ca",
      "fm1077.ca",
      "lavantage.qc.ca",
      "quebechebdo.com",
      "secretaire-inc.com",
      "distances.plus",
      "m1029.com",
      "monthetford.com",
      "journaldelevis.com",
      "canadafrancais.com",
      "montemiscouata.com",
      "thereview.ca",
      "lhebdodustmaurice.com",
      "lhebdojournal.com",
      "journalacces.ca",
      "portail-assurance.ca",
      "lavantagegaspesien.com",
      "larevue.qc.ca",
      "monlatuque.com",
      "courrierfrontenac.qc.ca",
      "lavoixdusud.com",
      "genie-inc.com",
      "lejournaldejoliette.ca",
      "lechodelatuque.com",
      "tvaabitibi.ca",
      "lecourriersud.com",
      "planeteradio.ca",
      "lavibe.fm",
      "hebdorivenord.com",
      "lavantposte.ca",
      "beaucemedia.ca",
      "espresso-jobs.com",
      "journallenord.com",
      "monlimoilou.com",
      "courrierdeportneuf.com",
      "lechodemaskinonge.com",
      "montreal.tv",
      "lelacstjean.com",
      "thesarniajournal.ca",
      "haliburtonecho.ca",
      "guidebateau.com",
      "blvd.fm",
      "granbyexpress.com",
      "lactiondautray.com",
      "lhebdomekinacdeschenaux.ca",
      "monquartier.quebec",
      "lexpressmontcalm.com",
      "lepeuplelotbiniere.ca",
      "nouvelleshebdo.com",
      "monsaintsauveur.com",
      "wowfm.com",
      "monsaintroch.com",
      "journaldechambly.com",
      "letoiledulac.ca",
      "guidevacances.ca",
      "gaspesienouvelles.com",
      "estrieplus.com",
      "o973.ca",
      "monmontcalm.com",
      "lasentinelle.ca",
      "leprogres.net",
      "chaleursnouvelles.com",
      "capitalerock.ca",
      "vosclassees.ca",
      "o1035.ca",
      "versants.com",
      "hitcountry.com",
      "o983.ca",
      "laveniretdesrivieres.com",
      "journalleguide.com",
      "o1015.ca",
      "noovoabitibi.ca",
      "plaisir1019.com",
      "thecosmos.ca",
      "plaisir1067.com",
      "coupdoeil.info",
      "o991.ca",
      "o953.ca",
      "o971.ca",
      "plaisir1055.com",
      "creationsdici.ca",
      "nouvelleliberte.ca",
      "noovogatineau.ca",
      "pop965.ca",
      "lerichelieu.ca",
      "pmedici.ca",
      "restosdici.ca",
      "wow971.ca",
      "bouffedici.ca",
      "montreal.wknd.fm",
      "forumquad.com",
      "plaisir941.com",
      "mamanpourlavie.com",
      "reseaucontact.com",
      "jobboom.com",
      "pagesjaunes.ca",
      "meteomedia.com",
      "journaldemontreal.com",
      "tvanouvelles.ca",
      "journaldequebec.com",
      "tabloid.co",
      "tvasports.ca",
      "7jours.ca",
      "lesacdechips.com",
      "guidetoautoweb.com",
      "salutbonjour.ca",
      "recettes.qc.ca",
      "coupdeponce.com",
      "billie.ca",
      "guideautoweb.com",
      "clindoeil.ca",
      "tvhebdo.ca",
      "pesesurstart.com",
      "coupdepouce.com",
      "espaces.ca",
      "viago.ca",
      "moietcie.ca",
      "addik.tv",
      "ellecanada.com",
      "ici.radio-canada.ca",
      "ici.tou.tv",
      "artv.ca",
      "exploratv.ca",
      "ricardocuisine.com",
      "telequebec.tv",
      "ayoye.com",
      "noovo.info",
      "rcinet.ca",
      "lenecrologue.com",
      "mjardiner.com",
      "rencontresportive.com",
      "autohebdo.net",
      "illicoweb.videotron.com",
      "qub.ca",
      "zeste.ca",
      "24heures.ca",
      "videotron.com",
      "matv.ca",
      "silo57.ca",
      "tvhebdo.com",
      "ecranpartage.ca",
      "oabitibi.ca",
      "monemploi.com",
      "ressourcessante.salutbonjour.ca",
      "letoiledulac.com",
      "lereveil.com",
      "cinoche.com",
      "showbizz.net",
      "jeuxvideo.com",
      "allocine.fr",
      "enfant.com",
      "notretemps.com",
      "familiscope.fr",
      "notrefamille.com",
      "magicmaman.com",
      "marieclaire.fr",
      "cosmopolitan.fr",
      "vanityfair.fr",
      "vogue.fr",
      "gqmagazine.fr",
      "admagazine.fr",
      "voici.fr",
      "gala.fr",
      "businessinsider.fr",
      "caminteresse.fr",
      "capital.fr",
      "cesoirtv.com",
      "cuisineactuelle.fr",
      "femmeactuelle.fr",
      "geo.fr",
      "hbrfrance.fr",
      "programme-tv.net",
      "lecanalauditif.ca",
      "sorstu.ca",
      "baronmag.com",
      "atuvu.ca",
      "labibleurbaine.com",
      "nouvelobs.com",
      "courrierinternational.com",
      "telerama.fr",
      "lemonde.fr",
      "huffingtonpost.fr",
      "suttonquebec.com",
      "royallepage.ca",
      "elle.fr",
      "routard.com",
      "bpmsports.ca",
      "educatout.com",
      "ilesdelamadeleine.com",
      "ellequebec.com",
      "joseedistasio.ca",
      "kpourkatrine.com",
      "veroniquecloutier.com",
      "lebelage.ca",
      "billie.ca",
      "lesacdechips.com",
      "pesesurstart.com",
      "silo57.ca",
    ],
    io = 0.5,
    Wu = (e) =>
      Array.isArray(e)
        ? e.includes("shouldForceEnhanced")
        : e.shouldForceEnhanced,
    Yu = (e) =>
      Array.isArray(e)
        ? e.includes("shouldForceUnenhanced")
        : e.shouldForceUnenhanced;
  function Te(e, t) {
    if (!e || !t) return !1;
    const r = e.type;
    if (r !== N.Banner && r !== N.Outstream) return !1;
    if (e.behaviors) {
      if (Wu(e.behaviors)) return !0;
      if (Yu(e.behaviors)) return !1;
    }
    return t.type !== "disabled";
  }
  const Mt = {
      "opt-out-icon-equativ": "_opt-out-icon-equativ_by4l6_1",
      "opt-out-container": "_opt-out-container_by4l6_11",
      "opt-out-label": "_opt-out-label_by4l6_18",
    },
    Xu = (e, t) =>
      !e || !t.french
        ? t.default
        : qu.some((r) => e.match(r))
        ? t.french
        : t.default,
    Ku = () =>
      d("svg", {
        fill: "#888888",
        xmlns: "http://www.w3.org/2000/svg",
        width: "24",
        height: "24",
        viewBox: "0 0 24 24",
        className: `str-opt-out-icon ${Mt["opt-out-icon-equativ"]}`,
        children: [
          d("path", { fill: "none", d: "M0 0h24v24H0V0z" }),
          d("path", {
            d: "M11 7h2v2h-2zm0 4h2v6h-2zm1-9C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8z",
          }),
        ],
      }),
    Qu = (e) => {
      const t = uc();
      if (!t || e.creative.behaviors?.includes("shouldRemoveAdchoicesLogo"))
        return null;
      const r = Xu(e.network.domain, t.optOutIconConfig),
        n = Ku;
      return d("a", {
        onClick: (a) => a.stopPropagation(),
        href: r,
        target: "_blank",
        "data-testid": "opt-out-link",
        rel: "noreferrer",
        children: d("div", {
          className: `str-opt-out-container ${Mt["opt-out-container"]} ${Mt["relocate-ad-choices"]}`,
          children: [
            d(n, {}),
            d("span", {
              className: `str-opt-out-label ${Mt["opt-out-label"]}`,
              children: "AdChoices",
            }),
          ],
        }),
      });
    };
  class Ju {
    constructor() {
      this.optOutIconConfig = {
        default: "https://equativ.com/privacy-policy/",
        french: "https://equativ.com/fr/privacy-policy/",
      };
    }
  }
  function pn(e, t) {
    if (!e.creative.trackers?.length) return;
    const r = t ? "0" : "1";
    for (const n of e.creative.trackers)
      n.event === rt.Impression && (n.url = n.url.replace("{isfallback}", r));
  }
  async function Zu(e, t) {
    const { assetsurl: r } = e.creative;
    if (r && e.creative.type === N.Native)
      try {
        const n = await Jd(r);
        n
          ? (Wi(n), ne.value?.trackDcoResolutionSuccess(), pn(e, !0))
          : (ne.value?.trackDcoResolutionFailure(), pn(e, !1));
      } catch (n) {
        ne.value?.trackDcoResolutionFailure(),
          pn(e, !1),
          R(n, { scope: t, context: "eqt/dco-handler", assetsurl: r });
      }
  }
  const ep = /%24%7B[^%]*%7D/gi,
    tp = (e) => e.replaceAll(ep, (t) => decodeURIComponent(t)),
    rp = /\$\{[^}]*\}/g,
    np = (e, t) => {
      const r =
          t.network.size.width === t.creative.size.width &&
          t.network.size.height === t.creative.size.height &&
          Ci(t.network.size.width, t.network.size.height),
        n = {
          "${AD_SUPPLY_WIDTH}": String(
            t.network.size.width - t.creative.size.width || t.network.size.width
          ),
          "${AD_SUPPLY_HEIGHT}": String(
            r
              ? t.network.size.height - Math.round(t.creative.size.height * Ml)
              : t.network.size.height - t.creative.size.height ||
                  t.network.size.height
          ),
          "${AUCTION_ID}": t.id,
          "${IMP_ID}": t.id,
          "${CREATIVE_ID}": t.creative.creativeId,
          "${DEAL_ID}": t.creative.dealId ?? void 0,
          "${DOMAIN}": t.network.domain,
          "${CAMPAIGN_KEY}": t.creative.campaignId ?? void 0,
          "${ADVERTISER_KEY}":
            t.creative.advertiserId != null
              ? String(t.creative.advertiserId)
              : void 0,
        },
        a = tp(e);
      return Object.entries(n)
        .reduce((o, [c, l]) => (l != null ? o.replaceAll(c, l) : o), a)
        .replace(rp, "");
    },
    ap = (e) => {
      switch (e) {
        case B.Disabled:
          return "disabled";
        case B.Default:
          return "default";
        case B.OutstreamCaptions:
          return b.GCEnhancementType.OutstreamCaptions;
        case B.OutstreamCountdown:
          return b.GCEnhancementType.OutstreamCountdown;
        case B.OutstreamHeadline:
          return b.GCEnhancementType.OutstreamHeadline;
        case B.OutstreamDailyWeatherOutlook:
          return b.GCEnhancementType.OutstreamDailyWeatherOutlook;
        case B.OutstreamSportsTicker:
          return b.GCEnhancementType.OutstreamSportsTicker;
        case B.OutstreamWeather:
          return b.GCEnhancementType.OutstreamWeather;
        case B.BannerCountdown:
          return b.GCEnhancementType.BannerCountdown;
        case B.BannerHeadline:
          return b.GCEnhancementType.BannerHeadline;
        case B.BannerDailyWeatherOutlook:
          return b.GCEnhancementType.BannerDailyWeatherOutlook;
        case B.BannerWeather:
          return b.GCEnhancementType.BannerWeather;
        case B.BannerSportsTicker:
          return b.GCEnhancementType.BannerSportsTicker;
        case B.BannerShoppable:
          return b.GCEnhancementType.BannerShoppable;
        case B.OutstreamShoppable:
          return b.GCEnhancementType.OutstreamShoppable;
        case B.BannerMedalCount:
          return b.GCEnhancementType.BannerMedalCount;
        case B.OutstreamMedalCount:
          return b.GCEnhancementType.OutstreamMedalCount;
        case B.BannerBrandedHeadline:
          return b.GCEnhancementType.BannerBrandedHeadline;
        case B.OutstreamBrandedHeadlines:
          return b.GCEnhancementType.OutstreamBrandedHeadline;
        case B.BannerShoppableOverlay:
          return b.GCEnhancementType.BannerShoppableOverlay;
        case B.BannerWorldTournament:
          return b.GCEnhancementType.BannerWorldTournament;
        case B.OutstreamWorldTournament:
          return b.GCEnhancementType.OutstreamWorldTournament;
        case B.BannerCustom:
          return b.GCEnhancementType.BannerCustom;
        case B.OutstreamCustom:
          return b.GCEnhancementType.OutstreamCustom;
        case B.BannerSofiaPulseSportsHeadlines:
          return b.GCEnhancementType.BannerSofiaPulseSportsHeadlines;
        case B.BannerSofiaPulseQuiz:
          return b.GCEnhancementType.BannerSofiaPulseQuiz;
        case B.BannerSofiaPulseBettingOdds:
          return b.GCEnhancementType.BannerSofiaPulseBettingOdds;
        case B.BannerSofiaPulseStockTicker:
          return b.GCEnhancementType.BannerSofiaPulseStockTicker;
        default:
          return "default";
      }
    },
    ip = (e, t) => {
      const r = ap(e.enhancement.type),
        n = fc(e.enhancement.payload);
      return n
        ? en.has(r) && "templateUrl" in n
          ? {
              type: r,
              payload: { ...n, templateUrl: np(n.templateUrl, e) },
              enhancement_version_id: e.enhancement.evid,
            }
          : { type: r, payload: n, enhancement_version_id: e.enhancement.evid }
        : r !== "default" && r !== "disabled"
        ? (R("Enhancement payload mismatch", {
            scope: t,
            callerId: e.network.callerId.toString(),
            networkId: e.network.networkId.toString(),
            partnerId: e.creative.partnerId.toString(),
            enhancement: {
              type: e.enhancement.type,
              payload: e.enhancement.payload,
            },
          }),
          { type: "disabled" })
        : { type: r };
    };
  class op extends Vl {
    parse(t, r) {
      Hc(t);
      try {
        return {
          id: t.id,
          creative: this.getCreative(t),
          network: this.getNetwork(t),
          reporting: this.getReporting(t),
          enhancement: this.getEnhancement(t, r),
          scenario: t.scenario,
        };
      } catch (n) {
        const a = n instanceof Error ? n.message : String(n);
        throw new Error("Error parsing payload: " + a);
      }
    }
    getCreative(t) {
      if (!mc(t.creative.type)) throw new Error("Invalid creative type");
      if (t.creative.type === N.Native) {
        const r = JSON.parse(t.creative.content);
        if (!Array.isArray(r))
          throw new Error("Content must be an array for native creatives");
        return (
          Wi(r),
          {
            type: N.Native,
            content: r,
            language: ao(t.creative.language) ? t.creative.language : "en",
            size: t.creative.size,
            behaviors: t.creative.behaviors ?? [],
            partnerId: t.creative.partnerId.toString(),
            seatId: t.creative.seatId,
            creativeId: t.creative.creativeId,
            dealId: t.creative.dealId,
            trackers: new tu(t.creative.eventtrackers ?? []),
            link: t.creative.link ?? "",
            clicktrackers: t.creative.clicktrackers ?? void 0,
            nativeType: t.creative.nativeType ?? "clickout",
            assetsurl: t.creative.assetsurl,
          }
        );
      }
      if (Array.isArray(t.creative.content))
        throw new Error(
          "Content must be a string for banner and outstream creatives"
        );
      return {
        type: t.creative.type,
        content: t.creative.content,
        language: ao(t.creative.language) ? t.creative.language : "en",
        size: t.creative.size,
        behaviors: t.creative.behaviors ?? [],
        partnerId: t.creative.partnerId.toString(),
        seatId: t.creative.seatId,
        creativeId: t.creative.creativeId,
        dealId: t.creative.dealId,
        link: t.creative.link ?? "",
      };
    }
    getNetwork(t) {
      return {
        networkId: t.network.networkId.toString(),
        size: { width: t.network.size.width, height: t.network.size.height },
        bundleId: t.network.bundleId ?? void 0,
        domain: t.network.domain,
        callerId: t.network.callerId.toString(),
        country: t.network.country,
      };
    }
    getEnhancement(t, r) {
      return ip(t, r);
    }
    getReporting(t) {
      return {
        trackerBaseUrl: t?.reporting?.trackerBaseUrl,
        trackerImpressionUrl: t?.reporting?.trackerImpressionUrl,
        countImpressionOnePixel: t?.reporting?.countImpressionOnePixel ?? !1,
        disableClickCounting: t?.reporting?.disableClickCounting,
      };
    }
  }
  class sp extends ql {
    hasPayload(t) {
      return t?.payload !== void 0;
    }
    constructor() {
      super();
    }
    trackImpression(t, r) {
      if (!this.hasPayload(this.metadata)) return;
      const { payload: n } = this.metadata;
      try {
        if (
          (this.trackOrtbEvent(rt.Impression, t),
          this.trackVisibleImpression(t),
          n.reporting.countImpressionOnePixel ||
            !n.reporting.trackerImpressionUrl)
        )
          return;
        new M({ url: `${n.reporting.trackerImpressionUrl}` });
      } catch (a) {
        a instanceof Error &&
          R(a, {
            scope: _e(r, re.Impression),
            context: "eqt/impression-beacon-failed",
          });
      }
    }
    trackImpressionReceived() {}
    trackVisibleImpression(t) {
      if (!this.hasPayload(this.metadata)) return;
      const { payload: r } = this.metadata;
      if (r.creative.type !== N.Outstream)
        try {
          nu(t, r.id);
        } catch {}
    }
    trackClick() {
      if (
        !this.hasPayload(this.metadata) ||
        this.metadata.payload.reporting.disableClickCounting
      )
        return;
      const { payload: t } = this.metadata;
      t.creative.type !== N.Outstream &&
        new M({
          url: `${t.reporting.trackerBaseUrl}&actionid=${D.TrackClick}`,
        });
    }
    trackViewableImpression() {
      if (!this.hasPayload(this.metadata)) return;
      const { payload: t } = this.metadata;
      t.creative.type !== N.Outstream &&
        new M({ url: `${t.reporting.trackerBaseUrl}&actionid=${D.Viewable}` });
    }
    trackOrtbEvent(t, r) {
      if (!this.hasPayload(this.metadata)) return;
      const { payload: n } = this.metadata;
      n.creative.trackers && n.creative.trackers.fireEventTrackerByType(t, r);
    }
    trackVideoStart(t) {
      if (!this.hasPayload(this.metadata)) return;
      const { payload: r } = this.metadata;
      r.creative.type !== N.Outstream &&
        new M({
          url: `${r.reporting.trackerBaseUrl}&actionid=${D.VideoStart}`,
        });
    }
    trackVideoPlay() {
      if (!this.hasPayload(this.metadata)) return;
      const { payload: t } = this.metadata;
      t.creative.type !== N.Outstream &&
        new M({
          url: `${t.reporting.trackerBaseUrl}&actionid=${D.VideoResume}`,
        });
    }
    trackVideoQuartile(t) {
      if (!this.hasPayload(this.metadata)) return;
      const { payload: r } = this.metadata;
      if (r.creative.type === N.Outstream) return;
      const n = {
        [it.Q25]: D.VideoFirstQuartile,
        [it.Q50]: D.VideoMidpoint,
        [it.Q75]: D.VideoThirdQuartile,
        [it.Q95]: D.VideoComplete,
      };
      new M({ url: `${r.reporting.trackerBaseUrl}&actionid=${n[t]}` });
    }
    trackVideoViewDuration(t, r) {}
    trackVideoVolumeOn(t) {
      if (!this.hasPayload(this.metadata)) return;
      const { payload: r } = this.metadata;
      r.creative.type !== N.Outstream &&
        new M({ url: `${r.reporting.trackerBaseUrl}&actionid=${D.AudioOn}` });
    }
    trackExperiment() {}
    trackIsEnhanced(t) {
      if (!this.hasPayload(this.metadata)) return;
      const { payload: r } = this.metadata;
      if (r.creative.type === N.Native) return;
      new M({ url: `${r.reporting.trackerBaseUrl}&actionid=${D.IsEnhanced}` });
      const n = r.enhancement?.type;
      n &&
        n !== t &&
        new M({
          url: `${r.reporting.trackerBaseUrl}&actionid=${D.DecoEnhancementFallback}`,
        });
    }
    trackVpaidEnabled(t) {}
    trackClickthroughFound(t) {}
    trackImaClick() {}
    trackJsTrackerFailedToLoad(t) {}
    trackVastError(t, r) {
      if (!this.hasPayload(this.metadata)) return;
      const { payload: n } = this.metadata;
      n.creative.type !== N.Outstream &&
        new M({
          url: `${n.reporting.trackerBaseUrl}&actionid=${D.VideoError}`,
          onFailure: () => {
            R(new Error(`Failed to fire VAST error beacon: ${t}`), {
              scope: r,
            });
          },
        });
    }
    trackVideoFailedToPlay() {
      if (!this.hasPayload(this.metadata)) return;
      const { payload: t } = this.metadata;
      new M({ url: `${t.reporting.trackerBaseUrl}&actionid=${D.VideoError}` });
    }
    trackBannerRendered(t, r, n) {}
    trackDoubleVerifyError() {}
    trackDoubleVerifyRender() {}
    trackDoubleVerifySuccess() {}
    trackDoubleVerifyFallback() {}
    trackSilentAutoPlayDuration(t) {}
    trackPixelVisible() {
      if (!this.hasPayload(this.metadata)) return;
      const { payload: t } = this.metadata;
      t.reporting.countImpressionOnePixel &&
        t.creative.type === N.Outstream &&
        new M({ url: `${t.reporting.trackerImpressionUrl}` });
    }
    trackUserShare() {}
    trackAutoplayVideoEngagement(t) {}
    trackGroundControlLoaded(t) {
      t.env === "eqt" &&
        new M({ url: `${t.trackerBaseUrl}&actionid=${D.GroundControlLoaded}` });
    }
    trackAttentionMetrics(t) {}
    trackEnhancedEngagementClick() {
      if (!this.hasPayload(this.metadata)) return;
      const { payload: t } = this.metadata;
      new M({
        url: `${t.reporting.trackerBaseUrl}&actionid=${D.EnhancedEngagement}`,
      });
    }
    trackEnhancedContentClick() {
      if (!this.hasPayload(this.metadata)) return;
      const { payload: t } = this.metadata;
      new M({
        url: `${t.reporting.trackerBaseUrl}&actionid=${D.EnhancedContent}`,
      });
    }
    trackProductCardClick(t) {
      if (!this.hasPayload(this.metadata)) return;
      const { payload: r } = this.metadata,
        n = t ? `&shoppableProductId=${encodeURIComponent(t)}` : "";
      new M({
        url: `${r.reporting.trackerBaseUrl}&actionid=${D.ProductCard}${n}`,
      });
    }
    trackShoppableCarouselArrowClick() {
      if (!this.hasPayload(this.metadata)) return;
      const { payload: t } = this.metadata;
      new M({
        url: `${t.reporting.trackerBaseUrl}&actionid=${D.ShoppableCarouselArrow}`,
      });
    }
    trackOverlayActive() {
      if (!this.hasPayload(this.metadata)) return;
      const { payload: t } = this.metadata;
      new M({
        url: `${t.reporting.trackerBaseUrl}&actionid=${D.OverlayActive}`,
      });
    }
    trackHeavyAdIntervention() {
      if (!this.hasPayload(this.metadata)) return;
      const { payload: t } = this.metadata;
      new M({
        url: `${t.reporting.trackerBaseUrl}&actionid=${D.HeavyAdIntervention}`,
      });
    }
    trackBannerClickable(t, r) {
      if (!this.hasPayload(this.metadata)) return;
      const { trackerBaseUrl: n } = this.metadata.payload.reporting;
      if (n) {
        if (t && r !== void 0) {
          const a = new URLSearchParams({
            actionid: D.BannerClickable,
            extraction_success: String(t.url !== null),
            extraction_method: t.method,
            extraction_duration_ms: String(Math.round(r)),
          });
          new M({ url: `${n}&${a.toString()}` });
          return;
        }
        new M({ url: `${n}&actionid=${D.BannerClickable}` });
      }
    }
    getSasConfig() {
      if (!this.hasPayload(this.metadata)) return;
      const { payload: t } = this.metadata;
      return {
        mraidTrackingUrl: `${t.reporting.trackerBaseUrl}&actionid=${D.MraidImpression}`,
        omidTrackingUrl: `${t.reporting.trackerBaseUrl}&actionid=${D.OmidImpression}`,
        impressionTrackingUrl: t.reporting.trackerImpressionUrl ?? "",
      };
    }
    trackRemoteHealthCheckFail() {}
    trackRemoteHealthCheckOk() {}
    trackRemoteInitialized() {}
    trackEnhancementLoadFailure() {
      if (!this.hasPayload(this.metadata)) return;
      const { payload: t } = this.metadata;
      new M({
        url: `${t.reporting.trackerBaseUrl}&actionid=${D.EnhancementLoadFailure}`,
      });
    }
    trackAmazonNativeImpression() {
      if (!this.hasPayload(this.metadata)) return;
      const { payload: t } = this.metadata;
      new M({
        url: `${t.reporting.trackerBaseUrl}&actionid=${D.AmazonNativeImpression}`,
      });
    }
    trackFriendlyIframeEnv() {
      if (!this.hasPayload(this.metadata) || !cu()) return;
      const { payload: t } = this.metadata;
      new M({
        url: `${t.reporting.trackerBaseUrl}&actionid=${D.friendlyIframeEnv}`,
      });
    }
    trackDcoResolutionSuccess() {
      if (!this.hasPayload(this.metadata)) return;
      const { payload: t } = this.metadata;
      t.reporting.trackerBaseUrl &&
        new M({
          url: `${t.reporting.trackerBaseUrl}&actionid=${D.DcoRequestSuccess}`,
        });
    }
    trackDcoResolutionFailure() {
      if (!this.hasPayload(this.metadata)) return;
      const { payload: t } = this.metadata;
      t.reporting.trackerBaseUrl &&
        new M({
          url: `${t.reporting.trackerBaseUrl}&actionid=${D.DcoRequestFailure}`,
        });
    }
    trackPublisherStylingRequested() {
      if (!this.hasPayload(this.metadata)) return;
      const { payload: t } = this.metadata;
      t.reporting.trackerBaseUrl &&
        new M({
          url: `${t.reporting.trackerBaseUrl}&actionid=${D.PublisherStylingRequested}`,
        });
    }
    trackPublisherStylingLoaded() {
      if (!this.hasPayload(this.metadata)) return;
      const { payload: t } = this.metadata;
      t.reporting.trackerBaseUrl &&
        new M({
          url: `${t.reporting.trackerBaseUrl}&actionid=${D.PublisherStylingLoaded}`,
        });
    }
  }
  var oo = ((e) => ((e.GreenPMP = "green-pmp"), e))(oo || {});
  function so(e) {
    var t,
      r,
      n = "";
    if (typeof e == "string" || typeof e == "number") n += e;
    else if (typeof e == "object")
      if (Array.isArray(e)) {
        var a = e.length;
        for (t = 0; t < a; t++)
          e[t] && (r = so(e[t])) && (n && (n += " "), (n += r));
      } else for (r in e) e[r] && (n && (n += " "), (n += r));
    return n;
  }
  function $() {
    for (var e, t, r = 0, n = "", a = arguments.length; r < a; r++)
      (e = arguments[r]) && (t = so(e)) && (n && (n += " "), (n += t));
    return n;
  }
  const Bt = new X(!1),
    cp = () => {
      const e = Q();
      if (!e) return !1;
      const t = e.creative.behaviors ?? [];
      return t.includes("shouldGreenPMP") || t.includes(oo.GreenPMP);
    },
    Fe = (e) => {
      const { creative: t, network: r } = e,
        n = Hu(t) || Bt.value;
      return d("div", {
        className: $(
          "str-buttons-container",
          t.behaviors?.includes("shouldRelocateAdchoicesLogo") && "bottom"
        ),
        children: [
          cp() && d(Gu, { creative: t }),
          !n && d(Qu, { creative: t, network: r }),
        ],
      });
    },
    co = ue(null),
    ot = () => ae(co),
    st = () => {
      const e = Q();
      return e?.enhancement
        ? { enhancement: e?.enhancement }
        : { enhancement: null };
    },
    lp = () => {
      const e = ot(),
        t = H();
      if (!e || !t || !t.sponsored) return null;
      const { sponsored: r } = t,
        { promotedByText: n } = e.creative;
      return d("div", {
        className:
          "str-amazon-advertiser-container str-advertiser-container advertiser-container",
        children: [
          d("span", {
            className: "str-amazon-promoted-by str-promoted-by promoted-by",
            children: n,
          }),
          d("span", {
            className: "str-amazon-advertiser str-advertiser advertiser",
            children: r.data.value,
          }),
        ],
      });
    },
    dp = () => {
      const e = H(),
        t = le();
      if (!e) return null;
      const { badge: r } = e;
      if (!r) return null;
      const n = (() => {
        if (r)
          try {
            return JSON.parse(r.data.value);
          } catch (a) {
            a instanceof Error &&
              ((a.message = `Error parsing badge JSON: ${a.message}`),
              R(a, { scope: t, amazonBadge: r }));
          }
        return null;
      })();
      return n
        ? d(G, {
            children: [
              d("div", { className: "str-amazon-badge-flex-break" }),
              d("div", {
                className: "str-amazon-badge",
                children: [
                  d("div", {
                    className: "str-amazon-badge-label",
                    style: {
                      color: `#${n.label.color}`,
                      backgroundColor: `#${n.label.backgroundColor}`,
                    },
                    children: d("span", {
                      className: "str-amazon-badge-label-text",
                      children: n.label.text,
                    }),
                  }),
                  d("div", {
                    className: "str-amazon-badge-messaging",
                    style: {
                      color: `#${n.messaging.color}`,
                      backgroundColor: `#${n.messaging.backgroundColor}`,
                    },
                    children: d("span", {
                      className: "str-amazon-badge-messaging-text",
                      children: n.messaging.text,
                    }),
                  }),
                ],
              }),
            ],
          })
        : null;
    },
    hn = () => {
      const e = H();
      if (!e) return null;
      const { primeLogo: t } = e;
      return t
        ? d("div", {
            className: "str-amazon-prime-logo",
            "data-testid": "amazon-prime-logo",
            style: { backgroundImage: `url(${t.img.url})` },
          })
        : null;
    },
    up = () => {
      const e = O(null),
        t = H();
      if (
        (A(() => {
          if (t && t.coupon && e.current) {
            const n = e.current;
            if (n) {
              const a = n.closest(".str-amazon-native");
              a && a.classList.add("str-amazon-native-coupon");
            }
          }
        }, [t]),
        !t)
      )
        return null;
      const { coupon: r } = t;
      return r
        ? d("div", {
            className: "str-amazon-coupon-container",
            children: [
              d("div", {
                className: "str-amazon-coupon",
                ref: e,
                children: r.data.value,
              }),
              d(hn, {}),
            ],
          })
        : null;
    },
    pp = (e) => {
      switch (e) {
        case "Add to cart":
          return "str-amazon-cta-add-to-cart";
        case "Shop now":
          return "str-amazon-cta-shop-now";
        default:
          return "";
      }
    },
    lo = () => {
      const e = H();
      if (!e) return null;
      const { cta: t } = e;
      if (!t?.data || !t?.link) return null;
      const r = pp(t.data.value);
      return d("a", {
        className: $("str-amazon-cta", r),
        children: d("div", { children: t.data.value }),
      });
    },
    hp = () => {
      const e = H();
      if (!e) return null;
      const { description: t, title: r, badge: n } = e;
      return !t && !r
        ? null
        : d("div", {
            className: $(
              "str-amazon-description",
              !n && "str-amazon-description-multiline"
            ),
            children: t?.data.value || r?.title.text,
          });
    },
    mp = () => {
      const e = H();
      if (!e) return null;
      const { price: t, salePrice: r } = e;
      if (!t) return null;
      const n = t.data.value.match(/([$€£¥]?)(\d+)\.(\d+)/);
      if (!n) return null;
      const [, a, i, o] = n;
      return !a || !i || !o
        ? null
        : d("div", {
            className: "str-amazon-price-container",
            children: [
              d("div", {
                className: "str-amazon-price",
                children: [
                  d("span", {
                    className: "str-amazon-price-currency",
                    "data-testid": "amazon-currency",
                    children: a,
                  }),
                  d("span", {
                    className: "str-amazon-price-whole",
                    "data-testid": "amazon-whole",
                    children: i,
                  }),
                  d("span", {
                    className: "str-amazon-price-fraction",
                    "data-testid": "amazon-fraction",
                    children: o,
                  }),
                ],
              }),
              r &&
                d("span", {
                  className: "str-amazon-price-sale",
                  children: r.data.value,
                }),
              d(hn, {}),
            ],
          });
    };
  var ct = ((e) => (
    (e.Full = "full"), (e.Half = "half"), (e.Empty = "empty"), e
  ))(ct || {});
  const fp = ({ type: e }) =>
      Object.values(ct).includes(e)
        ? d("svg", {
            "data-testid": `star-${e}`,
            xmlns: "http://www.w3.org/2000/svg",
            version: "1.1",
            focusable: "false",
            "aria-hidden": "true",
            viewBox: "0 0 19 19",
            width: "24px",
            height: "24px",
            "shape-rendering": "geometricPrecision",
            children: [
              e === "full" &&
                d("path", {
                  d: "M9.5,1.325L12.104,6.581L17.922,7.423L13.711,11.511L14.706,17.286L9.5,14.56L4.293,17.286L5.288,11.511L1.077,7.423L6.895,6.581L9.5,1.325Z",
                  style: { fill: 'url("#_starGradient_5pm7gjqod")' },
                }),
              e === "half" &&
                d("path", {
                  d: "M9.49,1.345L9.49,14.565L4.293,17.286L5.288,11.511L1.077,7.423L6.895,6.581L9.49,1.345Z",
                  style: { fill: 'url("#_starGradient_5pm7gjqod")' },
                }),
              e === "empty" &&
                d("path", {
                  d: "M9.5,1.325L12.104,6.581L17.922,7.423L13.711,11.511L14.706,17.286L9.5,14.56L4.293,17.286L5.288,11.511L1.077,7.423L6.895,6.581L9.5,1.325Z",
                  style: { fill: "white" },
                }),
              d("path", {
                d: "M9.5,1.325L12.104,6.581L17.922,7.423L13.711,11.511L14.706,17.286L9.5,14.56L4.293,17.286L5.288,11.511L1.077,7.423L6.895,6.581L9.5,1.325Z",
                style: {
                  fill: "none",
                  stroke: "rgb(162, 106, 0)",
                  strokeWidth: 1,
                },
              }),
              d("defs", {
                children: d("linearGradient", {
                  id: "_starGradient_5pm7gjqod",
                  x1: "0",
                  y1: "0",
                  x2: "1",
                  y2: "0",
                  gradientUnits: "userSpaceOnUse",
                  gradientTransform:
                    "matrix(7.07124e-16,11.5482,-11.5482,7.07124e-16,9.4995,5.53952)",
                  children: [
                    d("stop", {
                      offset: "0",
                      style: { stopColor: "rgb(255, 206, 0)", stopOpacity: 1 },
                    }),
                    d("stop", {
                      offset: "1",
                      style: { stopColor: "rgb(255, 167, 0)", stopOpacity: 1 },
                    }),
                  ],
                }),
              }),
            ],
          })
        : null,
    gp = () => {
      const e = H();
      if (!e) return null;
      const t = e.rating;
      if (!t) return null;
      const r = parseFloat(t.data.value);
      if (isNaN(r) || r < 0) return null;
      const n = Array.from({ length: 5 }, (o, c) => {
          const l = c < Math.floor(r) ? ct.Full : c < r ? ct.Half : ct.Empty;
          return d(fp, { type: l }, c);
        }),
        { likes: a, price: i } = e;
      return d("div", {
        className: "str-amazon-rating-container",
        children: [
          d("div", {
            className: "str-amazon-rating",
            children: [
              d("div", { className: "str-amazon-rating-stars", children: n }),
              a &&
                d("div", {
                  className: "str-amazon-rating-count",
                  children: a.data.value,
                }),
            ],
          }),
          !i && d(hn, {}),
        ],
      });
    },
    bp = () => {
      const e = H();
      if (!e) return null;
      const { review: t } = e;
      return t
        ? d("a", {
            className: "str-amazon-review",
            href: t.link?.url,
            children: d("span", { children: t.data.value }),
          })
        : null;
    },
    vp = () => {
      const e = H();
      if (!e) return null;
      const { availableOnAmazon: t } = e;
      return t
        ? d("div", {
            className: "str-amazon-available-logo",
            "data-testid": "amazon-available-logo",
            style: { backgroundImage: `url(${t.img.url})` },
          })
        : null;
    },
    _p = () => {
      const e = H();
      if (!e) return null;
      const { logo: t, availableOnAmazon: r } = e;
      return !t && r
        ? d(vp, {})
        : t
        ? d("div", {
            className: "str-amazon-thumbnail-logo",
            children: d("div", {
              className: "str-amazon-brand-logo",
              "data-testid": "amazon-brand-logo",
              style: { backgroundImage: `url(${t.img.url})` },
            }),
          })
        : null;
    },
    wp = () => {
      const e = H();
      if (!e) return null;
      const { title: t, description: r } = e;
      return !t || !r
        ? null
        : d("div", {
            className: "str-amazon-headline",
            children: d("span", { children: t.title.text }),
          });
    },
    yp = () => {
      const e = H();
      if (!e) return null;
      const { mainImage: t } = e;
      return t
        ? d("div", {
            className: "str-amazon-product-image",
            "data-testid": "amazon-product-image",
            style: { backgroundImage: `url(${t.img.url})` },
          })
        : null;
    },
    xp = () => {
      const e = H();
      if (!e) return null;
      const t = e.description || e.icon;
      return d("div", {
        className: "str-amazon-thumbnail",
        children: [
          t &&
            d("div", {
              className: "str-amazon-thumbnail-brand",
              children: [d(_p, {}), d(wp, {})],
            }),
          d(yp, {}),
        ],
      });
    },
    Ep = () => {
      const e = Q(),
        t = H(),
        r = me(),
        n = he(),
        a = le();
      if (!e || !t) return null;
      const { coupon: i, price: o, salePrice: c } = t,
        l = !i && (o || c);
      return (
        A(() => {
          const p = r.current?.parentElement;
          p && (n?.trackImpression(p, a), n?.trackAmazonNativeImpression());
        }, []),
        d("div", {
          ref: r,
          className: "str-amazon-native-container",
          "data-testid": "str-amazon-native",
          onClick: (p) => {
            const { cta: h } = t,
              m = h?.link?.url ?? e.creative.link,
              f = h?.link?.clicktrackers ?? [],
              g = e.creative.clicktrackers ?? [];
            if (
              (new Set([...f, ...g]).forEach((v) => dn(v)),
              m && window.open(m, "_blank"),
              !n)
            )
              return;
            const y = p.target;
            y instanceof HTMLElement &&
              y.dataset.strThumbnail === "true" &&
              n.trackClick(y),
              r.current && n.trackClick(r.current);
          },
          children: [
            d("div", {
              className: "str-amazon-native",
              children: [
                d(xp, {}),
                d("div", {
                  className: "str-amazon-body",
                  children: [
                    d(up, {}),
                    d(hp, {}),
                    d(gp, {}),
                    d(dp, {}),
                    l
                      ? d("div", {
                          className: "str-amazon-price-cta",
                          children: [d(mp, {}), d(lo, {})],
                        })
                      : d(lo, {}),
                    d(bp, {}),
                  ],
                }),
                d(lp, {}),
              ],
            }),
            d(Fe, { creative: e.creative, network: e.network }),
          ],
        })
      );
    };
  class uo {
    constructor(t) {
      (this.color = t?.color), (this.hoverColor = t?.hoverColor);
    }
    toStyle() {
      return { backgroundColor: this.color };
    }
  }
  class po {
    constructor(t) {
      (this.family = t?.family),
        (this.color = t?.color),
        (this.size = t?.size),
        (this.weight = t?.weight),
        (this.hoverColor = t?.hoverColor),
        (this.capitalized = t?.capitalized);
    }
    toStyle() {
      return {
        fontSize: `${this.size}em`,
        fontFamily: this.family,
        color: this.color,
        textTransform: this.capitalized ? "uppercase" : void 0,
        fontWeight: this.weight,
      };
    }
  }
  class Ap {
    constructor(t) {
      const r = t?.margin ? t.margin : 0,
        n = t?.padding ? t.padding : 0;
      (this.marginTop = t?.marginTop ? t.marginTop : r),
        (this.marginBottom = t?.marginBottom ? t.marginBottom : r),
        (this.marginLeft = t?.marginLeft ? t.marginLeft : r),
        (this.marginRight = t?.marginRight ? t.marginRight : r),
        (this.paddingTop = t?.paddingTop ? t.paddingTop : n),
        (this.paddingBottom = t?.paddingBottom ? t.paddingBottom : n),
        (this.paddingLeft = t?.paddingLeft ? t.paddingLeft : n),
        (this.paddingRight = t?.paddingRight ? t.paddingRight : n);
    }
    toStyle() {
      return {
        margin: `${this.marginTop}px ${this.marginRight}px ${this.marginBottom}px ${this.marginLeft}px`,
        padding: `${this.paddingTop}px ${this.paddingRight}px ${this.paddingBottom}px ${this.paddingLeft}px`,
      };
    }
  }
  class kp extends Array {
    constructor(t) {
      super(),
        t &&
          t.length > 0 &&
          t.map((r) => {
            this.push(r);
          });
    }
  }
  class Ip {
    constructor(t) {
      (this.color = t?.color),
        (this.width = t?.width),
        (this.style = t?.style),
        (this.radius = t?.radius);
    }
    toStyle() {
      return { borderColor: this.color, borderWidth: this.width };
    }
  }
  class Lt {
    constructor(t) {
      (this.hide = t?.hide),
        (this.font = new po(t?.font)),
        (this.background = new uo(t?.background)),
        (this.border = new Ip(t?.border)),
        (this.hoverColor = t?.hoverColor);
    }
  }
  class mn {
    constructor(t) {
      (this.direction = t?.direction),
        (this.background = new uo(t?.background)),
        (this.layout = new Ap(t?.layout)),
        (this.cta = new Lt(t?.cta)),
        (this.title = new Lt(t?.title)),
        (this.description = new Lt(t?.description)),
        (this.promotedBy = new Lt(t?.promotedBy)),
        (this.fontFamily = new kp(t?.fontFamily)),
        (this.font = new po(t?.font));
    }
  }
  const Cp = new Set([
    "allrecipes",
    "americansongwriter",
    "aol",
    "biblegateway",
    "britannica",
    "buzzfeed",
    "cbssports",
    "chess",
    "cnn",
    "coolmathgames",
    "dailymotion",
    "ebay",
    "espn",
    "fantasypros",
    "forbes",
    "genius",
    "grizly",
    "huffpost",
    "loveandlemons",
    "merriam-webster",
    "mobileposse",
    "newsweek",
    "nypost",
    "nytimes",
    "on3",
    "overwolf",
    "people",
    "poki",
    "powerball",
    "quizlet",
    "recipetineats",
    "redfin",
    "sallysbakingaddiction",
    "solitaired",
    "tastesbetterfromscratch",
    "timeanddate",
    "usatoday",
    "vegoutmag",
    "weather",
    "wunderground",
    "yahoo",
  ]);
  var ho = ((e) => (
    (e.FETCH_DATA_FAILED = "FETCH_DATA_FAILED"), (e.UNDEFINED = "UNDEFINED"), e
  ))(ho || {});
  class fn extends Error {
    constructor(t, r) {
      super(r),
        (this.type = t),
        Object.setPrototypeOf(this, new.target.prototype);
    }
  }
  const Sp = (e) => {
      const t = {
          baseUrl: "https://cdn.rendering.sharethrough.com",
          bucket: "true-template-output",
        },
        { baseUrl: r, bucket: n } = t,
        a = `${r}/${n}/${e}.json`;
      return fetch(a)
        .then((i) => {
          if (i.status === 200) return i.json();
          throw i.status === 404
            ? new Error(`Publisher styles not found for ${e}`)
            : new Error(
                `Failed to fetch publisher styles: ${i.status} ${i.statusText}`
              );
        })
        .catch((i) => {
          throw (
            (console.error(`Error fetching publisher styles for ${e}:`, i), i)
          );
        });
    },
    Tp = (e) => /(?:https?:\/\/)?(?:www\.)?([^?]+)/.exec(e)?.[1] || "",
    Op = async (e) => {
      const t = await e.load();
      document.fonts.add(t);
    },
    Rp = (e) => {
      try {
        e.map(
          (r) =>
            new FontFace(r.family, `url(${r.url})`, {
              style: r.style,
              weight: r.weight,
            })
        ).forEach((r) => {
          Op(r);
        });
      } catch (t) {
        console.error("Error loading font family", t);
      }
    },
    Np = async (e, t) => {
      try {
        const n = Tp(e).split(".")[0];
        if (Cp.has(n)) {
          t("requested");
          const a = await Sp(n);
          return t("loaded"), new mn(a);
        }
        return new mn();
      } catch (r) {
        throw r instanceof fn
          ? r
          : new fn(ho.FETCH_DATA_FAILED, `Error fetching data: ${r}`);
      }
    },
    mo = ue({ styles: void 0, error: void 0 }),
    fo = ({ domain: e, children: t, onOutcome: r }) => {
      const [n, a] = V(void 0),
        [i, o] = V(void 0),
        c = O(r);
      return (
        (c.current = r),
        A(() => {
          if (!e) return;
          (async () => {
            try {
              const u = await Np(e, (p) => c.current(p));
              a(u);
            } catch (u) {
              a(new mn()), u instanceof fn && o(u);
            }
          })();
        }, [e]),
        d(mo.Provider, { value: { styles: n, error: i }, children: t })
      );
    },
    go = () => ae(mo),
    Dp = async (e) => {
      const t = await fetch(e, { method: "HEAD" });
      return t.ok && t.status !== 204;
    };
  function bo(e, t) {
    for (var r in t) e[r] = t[r];
    return e;
  }
  function vo(e, t) {
    for (var r in e) if (r !== "__source" && !(r in t)) return !0;
    for (var n in t) if (n !== "__source" && e[n] !== t[n]) return !0;
    return !1;
  }
  function _o(e, t) {
    (this.props = e), (this.context = t);
  }
  ((_o.prototype = new se()).isPureReactComponent = !0),
    (_o.prototype.shouldComponentUpdate = function (e, t) {
      return vo(this.props, e) || vo(this.state, t);
    });
  var wo = C.__b;
  C.__b = function (e) {
    e.type && e.type.__f && e.ref && ((e.props.ref = e.ref), (e.ref = null)),
      wo && wo(e);
  };
  var Pp =
    (typeof Symbol < "u" && Symbol.for && Symbol.for("react.forward_ref")) ||
    3911;
  function yo(e) {
    function t(r) {
      var n = bo({}, r);
      return delete n.ref, e(n, r.ref || null);
    }
    return (
      (t.$$typeof = Pp),
      (t.render = e),
      (t.prototype.isReactComponent = t.__f = !0),
      (t.displayName = "ForwardRef(" + (e.displayName || e.name) + ")"),
      t
    );
  }
  var zp = C.__e;
  C.__e = function (e, t, r, n) {
    if (e.then) {
      for (var a, i = t; (i = i.__); )
        if ((a = i.__c) && a.__c)
          return (
            t.__e == null && ((t.__e = r.__e), (t.__k = r.__k)), a.__c(e, t)
          );
    }
    zp(e, t, r, n);
  };
  var xo = C.unmount;
  function Eo(e, t, r) {
    return (
      e &&
        (e.__c &&
          e.__c.__H &&
          (e.__c.__H.__.forEach(function (n) {
            typeof n.__c == "function" && n.__c();
          }),
          (e.__c.__H = null)),
        (e = bo({}, e)).__c != null &&
          (e.__c.__P === r && (e.__c.__P = t),
          (e.__c.__e = !0),
          (e.__c = null)),
        (e.__k =
          e.__k &&
          e.__k.map(function (n) {
            return Eo(n, t, r);
          }))),
      e
    );
  }
  function Ao(e, t, r) {
    return (
      e &&
        r &&
        ((e.__v = null),
        (e.__k =
          e.__k &&
          e.__k.map(function (n) {
            return Ao(n, t, r);
          })),
        e.__c &&
          e.__c.__P === t &&
          (e.__e && r.appendChild(e.__e), (e.__c.__e = !0), (e.__c.__P = r))),
      e
    );
  }
  function gn() {
    (this.__u = 0), (this.o = null), (this.__b = null);
  }
  function ko(e) {
    if (!e.__) return null;
    var t = e.__.__c;
    return t && t.__a && t.__a(e);
  }
  function Vt() {
    (this.i = null), (this.l = null);
  }
  (C.unmount = function (e) {
    var t = e.__c;
    t && (t.__z = !0),
      t && t.__R && t.__R(),
      t && 32 & e.__u && (e.type = null),
      xo && xo(e);
  }),
    ((gn.prototype = new se()).__c = function (e, t) {
      var r = t.__c,
        n = this;
      n.o == null && (n.o = []), n.o.push(r);
      var a = ko(n.__v),
        i = !1,
        o = function () {
          i || n.__z || ((i = !0), (r.__R = null), a ? a(l) : l());
        };
      r.__R = o;
      var c = r.__P;
      r.__P = null;
      var l = function () {
        if (!--n.__u) {
          if (n.state.__a) {
            var u = n.state.__a;
            n.__v.__k[0] = Ao(u, u.__c.__P, u.__c.__O);
          }
          var p;
          for (n.setState({ __a: (n.__b = null) }); (p = n.o.pop()); )
            (p.__P = c), p.forceUpdate();
        }
      };
      n.__u++ || 32 & t.__u || n.setState({ __a: (n.__b = n.__v.__k[0]) }),
        e.then(o, o);
    }),
    (gn.prototype.componentWillUnmount = function () {
      this.o = [];
    }),
    (gn.prototype.render = function (e, t) {
      if (this.__b) {
        if (this.__v.__k) {
          var r = document.createElement("div"),
            n = this.__v.__k[0].__c;
          this.__v.__k[0] = Eo(this.__b, r, (n.__O = n.__P));
        }
        this.__b = null;
      }
      var a = t.__a && dr(G, null, e.fallback);
      return a && (a.__u &= -33), [dr(G, null, t.__a ? null : e.children), a];
    });
  var Io = function (e, t, r) {
    if (
      (++r[1] === r[0] && e.l.delete(t),
      e.props.revealOrder && (e.props.revealOrder[0] !== "t" || !e.l.size))
    )
      for (r = e.i; r; ) {
        for (; r.length > 3; ) r.pop()();
        if (r[1] < r[0]) break;
        e.i = r = r[2];
      }
  };
  ((Vt.prototype = new se()).__a = function (e) {
    var t = this,
      r = ko(t.__v),
      n = t.l.get(e);
    return (
      n[0]++,
      function (a) {
        var i = function () {
          t.props.revealOrder ? (n.push(a), Io(t, e, n)) : a();
        };
        r ? r(i) : i();
      }
    );
  }),
    (Vt.prototype.render = function (e) {
      (this.i = null), (this.l = new Map());
      var t = vt(e.children);
      e.revealOrder && e.revealOrder[0] === "b" && t.reverse();
      for (var r = t.length; r--; ) this.l.set(t[r], (this.i = [1, 0, this.i]));
      return e.children;
    }),
    (Vt.prototype.componentDidUpdate = Vt.prototype.componentDidMount =
      function () {
        var e = this;
        this.l.forEach(function (t, r) {
          Io(e, r, t);
        });
      });
  var Up =
      (typeof Symbol < "u" && Symbol.for && Symbol.for("react.element")) ||
      60103,
    Mp =
      /^(?:accent|alignment|arabic|baseline|cap|clip(?!PathU)|color|dominant|fill|flood|font|glyph(?!R)|horiz|image(!S)|letter|lighting|marker(?!H|W|U)|overline|paint|pointer|shape|stop|strikethrough|stroke|text(?!L)|transform|underline|unicode|units|v|vector|vert|word|writing|x(?!C))[A-Z]/,
    Bp = /^on(Ani|Tra|Tou|BeforeInp|Compo)/,
    Lp = /[A-Z0-9]/g,
    Vp = typeof document < "u",
    Hp = function (e) {
      return (
        typeof Symbol < "u" && typeof Symbol() == "symbol"
          ? /fil|che|rad/
          : /fil|che|ra/
      ).test(e);
    };
  (se.prototype.isReactComponent = {}),
    [
      "componentWillMount",
      "componentWillReceiveProps",
      "componentWillUpdate",
    ].forEach(function (e) {
      Object.defineProperty(se.prototype, e, {
        configurable: !0,
        get: function () {
          return this["UNSAFE_" + e];
        },
        set: function (t) {
          Object.defineProperty(this, e, {
            configurable: !0,
            writable: !0,
            value: t,
          });
        },
      });
    });
  var Co = C.event;
  function $p() {}
  function Fp() {
    return this.cancelBubble;
  }
  function Gp() {
    return this.defaultPrevented;
  }
  C.event = function (e) {
    return (
      Co && (e = Co(e)),
      (e.persist = $p),
      (e.isPropagationStopped = Fp),
      (e.isDefaultPrevented = Gp),
      (e.nativeEvent = e)
    );
  };
  var jp = {
      enumerable: !1,
      configurable: !0,
      get: function () {
        return this.class;
      },
    },
    So = C.vnode;
  C.vnode = function (e) {
    typeof e.type == "string" &&
      (function (t) {
        var r = t.props,
          n = t.type,
          a = {},
          i = n.indexOf("-") === -1;
        for (var o in r) {
          var c = r[o];
          if (
            !(
              (o === "value" && "defaultValue" in r && c == null) ||
              (Vp && o === "children" && n === "noscript") ||
              o === "class" ||
              o === "className"
            )
          ) {
            var l = o.toLowerCase();
            o === "defaultValue" && "value" in r && r.value == null
              ? (o = "value")
              : o === "download" && c === !0
              ? (c = "")
              : l === "translate" && c === "no"
              ? (c = !1)
              : l[0] === "o" && l[1] === "n"
              ? l === "ondoubleclick"
                ? (o = "ondblclick")
                : l !== "onchange" ||
                  (n !== "input" && n !== "textarea") ||
                  Hp(r.type)
                ? l === "onfocus"
                  ? (o = "onfocusin")
                  : l === "onblur"
                  ? (o = "onfocusout")
                  : Bp.test(o) && (o = l)
                : (l = o = "oninput")
              : i && Mp.test(o)
              ? (o = o.replace(Lp, "-$&").toLowerCase())
              : c === null && (c = void 0),
              l === "oninput" && a[(o = l)] && (o = "oninputCapture"),
              (a[o] = c);
          }
        }
        n == "select" &&
          a.multiple &&
          Array.isArray(a.value) &&
          (a.value = vt(r.children).forEach(function (u) {
            u.props.selected = a.value.indexOf(u.props.value) != -1;
          })),
          n == "select" &&
            a.defaultValue != null &&
            (a.value = vt(r.children).forEach(function (u) {
              u.props.selected = a.multiple
                ? a.defaultValue.indexOf(u.props.value) != -1
                : a.defaultValue == u.props.value;
            })),
          r.class && !r.className
            ? ((a.class = r.class), Object.defineProperty(a, "className", jp))
            : r.className && (a.class = a.className = r.className),
          (t.props = a);
      })(e),
      (e.$$typeof = Up),
      So && So(e);
  };
  var To = C.__r;
  C.__r = function (e) {
    To && To(e), e.__c;
  };
  var Oo = C.diffed;
  C.diffed = function (e) {
    Oo && Oo(e);
    var t = e.props,
      r = e.__e;
    r != null &&
      e.type === "textarea" &&
      "value" in t &&
      t.value !== r.value &&
      (r.value = t.value == null ? "" : t.value);
  };
  var s = ((e) => (
      (e.ADVERTISER = "i18n.advertiser"),
      (e.AIR_QUALITY = "i18n.air-quality"),
      (e.CTA_TEXT = "i18n.ctaText"),
      (e.DAYS = "i18n.days"),
      (e.DESCRIPTION = "i18n.description"),
      (e.FAIR = "i18n.fair"),
      (e.GOOD = "i18n.good"),
      (e.HOURS = "i18n.hours"),
      (e.HUMIDITY = "i18n.humidity"),
      (e.ISI = "i18n.isi"),
      (e.MINUTES_ABBREVIATION = "i18n.minutes-abbreviation"),
      (e.MODERATE = "i18n.moderate"),
      (e.POOR = "i18n.poor"),
      (e.PROMOTED_BY_TEXT = "i18n.promoted-by-text"),
      (e.SECONDS_ABBREVIATION = "i18n.seconds-abbreviation"),
      (e.TITLE = "i18n.title"),
      (e.UNKNOWN = "i18n.unknown"),
      (e.UV_INDEX = "i18n.uv-index"),
      (e.VERY_POOR = "i18n.very-poor"),
      (e.WIND = "i18n.wind"),
      e
    ))(s || {}),
    Ht = ((e) => (
      (e.ARABIC = "ar"),
      (e.BENGALI = "bn"),
      (e.BULGARIAN = "bg"),
      (e.CHINESE = "zh-cn"),
      (e.CHINESE_HONG_KONG = "zh-hk"),
      (e.CROATIAN = "hr"),
      (e.CZECH = "cs"),
      (e.ENGLISH = "en"),
      (e.FRENCH = "fr"),
      (e.GERMAN = "de"),
      (e.HINDI = "hi"),
      (e.HUNGARIAN = "hu"),
      (e.INDONESIAN = "id"),
      (e.ITALIAN = "it"),
      (e.JAPANESE = "ja"),
      (e.KOREAN = "ko"),
      (e.POLISH = "pl"),
      (e.PORTUGUESE_BRAZIL = "pt-br"),
      (e.ROMANIAN = "ro"),
      (e.SERBIAN = "sr"),
      (e.SLOVAK = "sk"),
      (e.SPANISH = "es"),
      (e.SPANISH_MX = "es-mx"),
      (e.TAGALOG = "tl"),
      (e.TAGALOG_EN = "tl-en"),
      (e.TAMIL = "ta"),
      (e.THAI = "th"),
      (e.VIETNAMESE = "vi"),
      e
    ))(Ht || {});
  const qp = {
      [s.ADVERTISER]: "Sponsor",
      [s.AIR_QUALITY]: "Air Quality",
      [s.CTA_TEXT]: "See More",
      [s.DAYS]: "Days",
      [s.DESCRIPTION]: "Don't miss this content from our sponsor",
      [s.FAIR]: "Fair",
      [s.GOOD]: "Good",
      [s.HOURS]: "Hours",
      [s.HUMIDITY]: "Humidity",
      [s.ISI]: "Important Safety Information",
      [s.MINUTES_ABBREVIATION]: "Min",
      [s.MODERATE]: "Moderate",
      [s.POOR]: "Poor",
      [s.PROMOTED_BY_TEXT]: "Ad by",
      [s.SECONDS_ABBREVIATION]: "Sec",
      [s.TITLE]: "Click Here for More Information",
      [s.UNKNOWN]: "Unknown",
      [s.UV_INDEX]: "UV Index",
      [s.VERY_POOR]: "Very Poor",
      [s.WIND]: "Wind",
    },
    Wp = {
      [s.ADVERTISER]: "Patrocinador",
      [s.AIR_QUALITY]: "Calidad del aire",
      [s.CTA_TEXT]: "Ver más",
      [s.DAYS]: "Dias",
      [s.DESCRIPTION]: "No te pierdas este contenido de nuestro patrocinador",
      [s.FAIR]: "Aceptable",
      [s.GOOD]: "Buena",
      [s.HOURS]: "Horas",
      [s.HUMIDITY]: "Humedad",
      [s.ISI]: "Información de seguridad importante",
      [s.MINUTES_ABBREVIATION]: "Min",
      [s.MODERATE]: "Moderada",
      [s.POOR]: "Mala",
      [s.PROMOTED_BY_TEXT]: "Anuncio por",
      [s.SECONDS_ABBREVIATION]: "Seg",
      [s.TITLE]: "Haga clic aquí para más información",
      [s.UNKNOWN]: "Desconocido",
      [s.UV_INDEX]: "Índice UV",
      [s.VERY_POOR]: "Muy mala",
      [s.WIND]: "Viento",
    },
    Yp = {
      [s.ADVERTISER]: "الراعي",
      [s.AIR_QUALITY]: "جودة الهواء",
      [s.CTA_TEXT]: "اعرف المزيد",
      [s.DAYS]: "أيام",
      [s.DESCRIPTION]: "لا تفوت هذا المحتوى من راعينا",
      [s.FAIR]: "مقبولة",
      [s.GOOD]: "جيدة",
      [s.HOURS]: "ساعات",
      [s.HUMIDITY]: "الرطوبة",
      [s.ISI]: "معلومات السلامة الهامة",
      [s.MINUTES_ABBREVIATION]: "دق",
      [s.MODERATE]: "متوسطة",
      [s.POOR]: "رديئة",
      [s.PROMOTED_BY_TEXT]: "إعلان بواسطة",
      [s.SECONDS_ABBREVIATION]: "ث",
      [s.TITLE]: "انقر هنا لمزيد من المعلومات",
      [s.UNKNOWN]: "غير معروف",
      [s.UV_INDEX]: "مؤشر الأشعة فوق البنفسجية",
      [s.VERY_POOR]: "سيئة للغاية",
      [s.WIND]: "الرياح",
    },
    Xp = {
      [s.ADVERTISER]: "Спонсор",
      [s.AIR_QUALITY]: "Качество на въздуха",
      [s.CTA_TEXT]: "Виж повече",
      [s.DAYS]: "Дни",
      [s.DESCRIPTION]: "Не пропускайте това съдържание от нашия спонсор",
      [s.FAIR]: "Задоволително",
      [s.GOOD]: "Добро",
      [s.HOURS]: "Часа",
      [s.HUMIDITY]: "Влажност",
      [s.ISI]: "Важна информация за безопасността",
      [s.MINUTES_ABBREVIATION]: "Мин",
      [s.MODERATE]: "Умерено",
      [s.POOR]: "Лошо",
      [s.PROMOTED_BY_TEXT]: "Реклама от",
      [s.SECONDS_ABBREVIATION]: "Сек",
      [s.TITLE]: "Кликнете тук за повече информация",
      [s.UNKNOWN]: "Неизвестно",
      [s.UV_INDEX]: "UV индекс",
      [s.VERY_POOR]: "Много лошо",
      [s.WIND]: "Вятър",
    },
    Kp = {
      [s.ADVERTISER]: "স্পনসর",
      [s.AIR_QUALITY]: "বায়ুর গুণমান",
      [s.CTA_TEXT]: "আরও দেখুন",
      [s.DAYS]: "দিন",
      [s.DESCRIPTION]: "আমাদের স্পনসরের এই বিষয়বস্তুটি মিস করবেন না",
      [s.FAIR]: "মোটামুটি",
      [s.GOOD]: "ভাল",
      [s.HOURS]: "ঘণ্টা",
      [s.HUMIDITY]: "আর্দ্রতা",
      [s.ISI]: "গুরুত্বপূর্ণ সুরক্ষা তথ্য",
      [s.MINUTES_ABBREVIATION]: "মিনিট",
      [s.MODERATE]: "মাঝারি",
      [s.POOR]: "খারাপ",
      [s.PROMOTED_BY_TEXT]: "প্রচারক",
      [s.SECONDS_ABBREVIATION]: "সেকেন্ড",
      [s.TITLE]: "আরও তথ্যের জন্য এখানে ক্লিক করুন",
      [s.UNKNOWN]: "অজানা",
      [s.UV_INDEX]: "ইউভি সূচক",
      [s.VERY_POOR]: "অত্যন্ত খারাপ",
      [s.WIND]: "বাতাস",
    },
    Qp = {
      [s.ADVERTISER]: "Sponzor",
      [s.AIR_QUALITY]: "Kvalita ovzduší",
      [s.CTA_TEXT]: "Zjistit více",
      [s.DAYS]: "Dny",
      [s.DESCRIPTION]: "Nezmeškejte tento obsah od našeho sponzora",
      [s.FAIR]: "Uspokojivá",
      [s.GOOD]: "Dobrá",
      [s.HOURS]: "Hodiny",
      [s.HUMIDITY]: "Vlhkost",
      [s.ISI]: "Důležité bezpečnostní informace",
      [s.MINUTES_ABBREVIATION]: "Min",
      [s.MODERATE]: "Střední",
      [s.POOR]: "Špatná",
      [s.PROMOTED_BY_TEXT]: "Reklama od",
      [s.SECONDS_ABBREVIATION]: "Sek",
      [s.TITLE]: "Klikněte zde pro více informací",
      [s.UNKNOWN]: "Neznámá",
      [s.UV_INDEX]: "UV index",
      [s.VERY_POOR]: "Velmi špatná",
      [s.WIND]: "Vítr",
    },
    Jp = {
      [s.ADVERTISER]: "Sponsor",
      [s.AIR_QUALITY]: "Luftqualität",
      [s.CTA_TEXT]: "Mehr sehen",
      [s.DAYS]: "Tages",
      [s.DESCRIPTION]: "Verpassen Sie nicht diesen Inhalt von unserem Sponsor",
      [s.FAIR]: "Zufriedenstellend",
      [s.GOOD]: "Gut",
      [s.HOURS]: "Std",
      [s.HUMIDITY]: "Luftfeuchtigkeit",
      [s.ISI]: "Wichtige Sicherheitsinformationen",
      [s.MINUTES_ABBREVIATION]: "Min",
      [s.MODERATE]: "Mäßig",
      [s.POOR]: "Schlecht",
      [s.PROMOTED_BY_TEXT]: "Anzeige von",
      [s.SECONDS_ABBREVIATION]: "Sek",
      [s.TITLE]: "Klicken Sie hier für weitere Informationen",
      [s.UNKNOWN]: "Unbekannt",
      [s.UV_INDEX]: "UV-Index",
      [s.VERY_POOR]: "Sehr schlecht",
      [s.WIND]: "Wind",
    },
    Zp = {
      [s.ADVERTISER]: "Patrocinador",
      [s.AIR_QUALITY]: "Calidad del aire",
      [s.CTA_TEXT]: "Ver más",
      [s.DAYS]: "Dias",
      [s.DESCRIPTION]: "No te pierdas este contenido de nuestro patrocinador",
      [s.FAIR]: "Aceptable",
      [s.GOOD]: "Buena",
      [s.HOURS]: "Horas",
      [s.HUMIDITY]: "Humedad",
      [s.ISI]: "Información importante de seguridad",
      [s.MINUTES_ABBREVIATION]: "Min",
      [s.MODERATE]: "Moderada",
      [s.POOR]: "Mala",
      [s.PROMOTED_BY_TEXT]: "Anuncio por",
      [s.SECONDS_ABBREVIATION]: "Seg",
      [s.TITLE]: "Haga clic aquí para más información",
      [s.UNKNOWN]: "Desconocido",
      [s.UV_INDEX]: "Índice UV",
      [s.VERY_POOR]: "Muy mala",
      [s.WIND]: "Viento",
    },
    eh = {
      [s.ADVERTISER]: "Annonceur",
      [s.AIR_QUALITY]: "Qualité de l'air",
      [s.CTA_TEXT]: "En savoir plus",
      [s.DAYS]: "Jours",
      [s.DESCRIPTION]: "Ne manquez pas ce contenu de notre annonceur",
      [s.FAIR]: "Passable",
      [s.GOOD]: "Bonne",
      [s.HOURS]: "Heures",
      [s.HUMIDITY]: "Humidité",
      [s.ISI]: "Informations de sécurité importantes",
      [s.MINUTES_ABBREVIATION]: "Min",
      [s.MODERATE]: "Modérée",
      [s.POOR]: "Mauvaise",
      [s.PROMOTED_BY_TEXT]: "Publicité par",
      [s.SECONDS_ABBREVIATION]: "Sec",
      [s.TITLE]: "Cliquez ici pour plus d'information",
      [s.UNKNOWN]: "Inconnu",
      [s.UV_INDEX]: "Indice UV",
      [s.VERY_POOR]: "Très mauvaise",
      [s.WIND]: "Vent",
    },
    th = {
      [s.ADVERTISER]: "प्रायोजक",
      [s.AIR_QUALITY]: "वायु गुणवत्ता",
      [s.CTA_TEXT]: "और देखें",
      [s.DAYS]: "दिन",
      [s.DESCRIPTION]: "हमारे प्रायोजक की इस सामग्री को न चूकें",
      [s.FAIR]: "ठीक",
      [s.GOOD]: "अच्छा",
      [s.HOURS]: "घंटे",
      [s.HUMIDITY]: "आर्द्रता",
      [s.ISI]: "महत्वपूर्ण सुरक्षा जानकारी",
      [s.MINUTES_ABBREVIATION]: "मिनट",
      [s.MODERATE]: "मध्यम",
      [s.POOR]: "खराब",
      [s.PROMOTED_BY_TEXT]: "विज्ञापन द्वारा",
      [s.SECONDS_ABBREVIATION]: "सेकंड",
      [s.TITLE]: "अधिक जानकारी के लिए यहां क्लिक करें",
      [s.UNKNOWN]: "अज्ञात",
      [s.UV_INDEX]: "यूवी सूचकांक",
      [s.VERY_POOR]: "बहुत खराब",
      [s.WIND]: "हवा",
    },
    rh = {
      [s.ADVERTISER]: "Sponzor",
      [s.AIR_QUALITY]: "Kvaliteta zraka",
      [s.CTA_TEXT]: "Pogledaj više",
      [s.DAYS]: "Dana",
      [s.DESCRIPTION]: "Ne propustite ovaj sadržaj našeg sponzora",
      [s.FAIR]: "Zadovoljavajuća",
      [s.GOOD]: "Dobra",
      [s.HOURS]: "Sati",
      [s.HUMIDITY]: "Vlažnost",
      [s.ISI]: "Važne sigurnosne informacije",
      [s.MINUTES_ABBREVIATION]: "Min",
      [s.MODERATE]: "Umjerena",
      [s.POOR]: "Loša",
      [s.PROMOTED_BY_TEXT]: "Oglas od",
      [s.SECONDS_ABBREVIATION]: "Sek",
      [s.TITLE]: "Kliknite ovdje za više informacija",
      [s.UNKNOWN]: "Nepoznato",
      [s.UV_INDEX]: "UV indeks",
      [s.VERY_POOR]: "Vrlo loša",
      [s.WIND]: "Vjetar",
    },
    nh = {
      [s.ADVERTISER]: "Szponzor",
      [s.AIR_QUALITY]: "Levegőminőség",
      [s.CTA_TEXT]: "Tovább",
      [s.DAYS]: "Nap",
      [s.DESCRIPTION]: "Ne hagyja ki ezt a tartalmat a szponzorunktól",
      [s.FAIR]: "Elfogadható",
      [s.GOOD]: "Jó",
      [s.HOURS]: "Óra",
      [s.HUMIDITY]: "Páratartalom",
      [s.ISI]: "Fontos biztonsági információk",
      [s.MINUTES_ABBREVIATION]: "Perc",
      [s.MODERATE]: "Mérsékelt",
      [s.POOR]: "Rossz",
      [s.PROMOTED_BY_TEXT]: "Hirdetés:",
      [s.SECONDS_ABBREVIATION]: "Mp",
      [s.TITLE]: "Kattintson ide további információkért",
      [s.UNKNOWN]: "Ismeretlen",
      [s.UV_INDEX]: "UV-index",
      [s.VERY_POOR]: "Nagyon rossz",
      [s.WIND]: "Szél",
    },
    ah = {
      [s.ADVERTISER]: "Sponsor",
      [s.AIR_QUALITY]: "Kualitas udara",
      [s.CTA_TEXT]: "Lihat Selengkapnya",
      [s.DAYS]: "Hari",
      [s.DESCRIPTION]: "Jangan lewatkan konten ini dari sponsor kami",
      [s.FAIR]: "Cukup",
      [s.GOOD]: "Baik",
      [s.HOURS]: "Jam",
      [s.HUMIDITY]: "Kelembaban",
      [s.ISI]: "Informasi Keselamatan Penting",
      [s.MINUTES_ABBREVIATION]: "Menit",
      [s.MODERATE]: "Sedang",
      [s.POOR]: "Buruk",
      [s.PROMOTED_BY_TEXT]: "Iklan oleh",
      [s.SECONDS_ABBREVIATION]: "Detik",
      [s.TITLE]: "Klik di sini untuk informasi lebih lanjut",
      [s.UNKNOWN]: "Tidak diketahui",
      [s.UV_INDEX]: "Indeks UV",
      [s.VERY_POOR]: "Sangat buruk",
      [s.WIND]: "Angin",
    },
    ih = {
      [s.ADVERTISER]: "Sponsor",
      [s.AIR_QUALITY]: "Qualità dell'aria",
      [s.CTA_TEXT]: "Vedi altro",
      [s.DAYS]: "Giorni",
      [s.DESCRIPTION]: "Non perdere questo contenuto del nostro sponsor",
      [s.FAIR]: "Accettabile",
      [s.GOOD]: "Buona",
      [s.HOURS]: "Ore",
      [s.HUMIDITY]: "Umidità",
      [s.ISI]: "Informazioni di sicurezza importanti",
      [s.MINUTES_ABBREVIATION]: "Min",
      [s.MODERATE]: "Moderata",
      [s.POOR]: "Scarsa",
      [s.PROMOTED_BY_TEXT]: "Annuncio per",
      [s.SECONDS_ABBREVIATION]: "Sec",
      [s.TITLE]: "Clicca qui per maggiori informazioni",
      [s.UNKNOWN]: "Sconosciuto",
      [s.UV_INDEX]: "Indice UV",
      [s.VERY_POOR]: "Molto scarsa",
      [s.WIND]: "Vento",
    },
    oh = {
      [s.ADVERTISER]: "スポンサー",
      [s.AIR_QUALITY]: "空気の質",
      [s.CTA_TEXT]: "もっと見る",
      [s.DAYS]: "日",
      [s.DESCRIPTION]: "スポンサーのコンテンツをお見逃しなく",
      [s.FAIR]: "まあまあ",
      [s.GOOD]: "良好",
      [s.HOURS]: "時間",
      [s.HUMIDITY]: "湿度",
      [s.ISI]: "重要な安全情報",
      [s.MINUTES_ABBREVIATION]: "分",
      [s.MODERATE]: "中程度",
      [s.POOR]: "悪い",
      [s.PROMOTED_BY_TEXT]: "広告：",
      [s.SECONDS_ABBREVIATION]: "秒",
      [s.TITLE]: "詳細はこちらをクリック",
      [s.UNKNOWN]: "不明",
      [s.UV_INDEX]: "UV指数",
      [s.VERY_POOR]: "非常に悪い",
      [s.WIND]: "風",
    },
    sh = {
      [s.ADVERTISER]: "스폰서",
      [s.AIR_QUALITY]: "대기 질",
      [s.CTA_TEXT]: "자세히 보기",
      [s.DAYS]: "일",
      [s.DESCRIPTION]: "스폰서의 콘텐츠를 놓치지 마세요",
      [s.FAIR]: "보통",
      [s.GOOD]: "좋음",
      [s.HOURS]: "시간",
      [s.HUMIDITY]: "습도",
      [s.ISI]: "중요한 안전 정보",
      [s.MINUTES_ABBREVIATION]: "분",
      [s.MODERATE]: "중간",
      [s.POOR]: "나쁨",
      [s.PROMOTED_BY_TEXT]: "광고:",
      [s.SECONDS_ABBREVIATION]: "초",
      [s.TITLE]: "자세한 내용을 보려면 여기를 클릭하세요",
      [s.UNKNOWN]: "알 수 없음",
      [s.UV_INDEX]: "자외선 지수",
      [s.VERY_POOR]: "매우 나쁨",
      [s.WIND]: "바람",
    },
    ch = {
      [s.ADVERTISER]: "Sponsor",
      [s.AIR_QUALITY]: "Jakość powietrza",
      [s.CTA_TEXT]: "Zobacz więcej",
      [s.DAYS]: "Dni",
      [s.DESCRIPTION]: "Nie przegap tej treści od naszego sponsora",
      [s.FAIR]: "Zadowalająca",
      [s.GOOD]: "Dobra",
      [s.HOURS]: "Godziny",
      [s.HUMIDITY]: "Wilgotność",
      [s.ISI]: "Ważne informacje dotyczące bezpieczeństwa",
      [s.MINUTES_ABBREVIATION]: "Min",
      [s.MODERATE]: "Umiarkowana",
      [s.POOR]: "Zła",
      [s.PROMOTED_BY_TEXT]: "Reklama od",
      [s.SECONDS_ABBREVIATION]: "Sek",
      [s.TITLE]: "Kliknij tutaj, aby uzyskać więcej informacji",
      [s.UNKNOWN]: "Nieznany",
      [s.UV_INDEX]: "Indeks UV",
      [s.VERY_POOR]: "Bardzo zła",
      [s.WIND]: "Wiatr",
    },
    lh = {
      [s.ADVERTISER]: "Patrocinador",
      [s.AIR_QUALITY]: "Qualidade do ar",
      [s.CTA_TEXT]: "Ver mais",
      [s.DAYS]: "Dias",
      [s.DESCRIPTION]: "Não perca este conteúdo do nosso patrocinador",
      [s.FAIR]: "Razoável",
      [s.GOOD]: "Boa",
      [s.HOURS]: "Horas",
      [s.HUMIDITY]: "Umidade",
      [s.ISI]: "Informações importantes de segurança",
      [s.MINUTES_ABBREVIATION]: "Min",
      [s.MODERATE]: "Moderada",
      [s.POOR]: "Ruim",
      [s.PROMOTED_BY_TEXT]: "Anúncio do",
      [s.SECONDS_ABBREVIATION]: "Seg",
      [s.TITLE]: "Clique aqui para obter mais informações",
      [s.UNKNOWN]: "Desconhecido",
      [s.UV_INDEX]: "Índice UV",
      [s.VERY_POOR]: "Muito ruim",
      [s.WIND]: "Vento",
    },
    dh = {
      [s.ADVERTISER]: "Sponsor",
      [s.AIR_QUALITY]: "Calitatea aerului",
      [s.CTA_TEXT]: "Află mai multe",
      [s.DAYS]: "Zile",
      [s.DESCRIPTION]: "Nu ratați acest conținut de la sponsorul nostru",
      [s.FAIR]: "Acceptabilă",
      [s.GOOD]: "Bună",
      [s.HOURS]: "Ore",
      [s.HUMIDITY]: "Umiditate",
      [s.ISI]: "Informații importante privind siguranța",
      [s.MINUTES_ABBREVIATION]: "Min",
      [s.MODERATE]: "Moderată",
      [s.POOR]: "Proastă",
      [s.PROMOTED_BY_TEXT]: "Reclamă de la",
      [s.SECONDS_ABBREVIATION]: "Sec",
      [s.TITLE]: "Faceți clic aici pentru mai multe informații",
      [s.UNKNOWN]: "Necunoscut",
      [s.UV_INDEX]: "Indice UV",
      [s.VERY_POOR]: "Foarte proastă",
      [s.WIND]: "Vânt",
    },
    uh = {
      [s.ADVERTISER]: "Sponzor",
      [s.AIR_QUALITY]: "Kvalita ovzdušia",
      [s.CTA_TEXT]: "Zobraziť viac",
      [s.DAYS]: "Dni",
      [s.DESCRIPTION]: "Nezmeškajte tento obsah od nášho sponzora",
      [s.FAIR]: "Uspokojivá",
      [s.GOOD]: "Dobrá",
      [s.HOURS]: "Hodiny",
      [s.HUMIDITY]: "Vlhkosť",
      [s.ISI]: "Dôležité bezpečnostné informácie",
      [s.MINUTES_ABBREVIATION]: "Min",
      [s.MODERATE]: "Stredná",
      [s.POOR]: "Zlá",
      [s.PROMOTED_BY_TEXT]: "Reklama od",
      [s.SECONDS_ABBREVIATION]: "Sek",
      [s.TITLE]: "Kliknite sem pre viac informácií",
      [s.UNKNOWN]: "Neznáme",
      [s.UV_INDEX]: "Index UV",
      [s.VERY_POOR]: "Veľmi zlá",
      [s.WIND]: "Vietor",
    },
    ph = {
      [s.ADVERTISER]: "Sponzor",
      [s.AIR_QUALITY]: "Kvalitet vazduha",
      [s.CTA_TEXT]: "Pogledaj više",
      [s.DAYS]: "Dana",
      [s.DESCRIPTION]: "Ne propustite ovaj sadržaj od našeg sponzora",
      [s.FAIR]: "Zadovoljavajuća",
      [s.GOOD]: "Dobra",
      [s.HOURS]: "Sati",
      [s.HUMIDITY]: "Vlažnost",
      [s.ISI]: "Važne bezbednosne informacije",
      [s.MINUTES_ABBREVIATION]: "Min",
      [s.MODERATE]: "Umerena",
      [s.POOR]: "Loša",
      [s.PROMOTED_BY_TEXT]: "Oglas od",
      [s.SECONDS_ABBREVIATION]: "Sek",
      [s.TITLE]: "Kliknite ovde za više informacija",
      [s.UNKNOWN]: "Nepoznato",
      [s.UV_INDEX]: "UV indeks",
      [s.VERY_POOR]: "Veoma loša",
      [s.WIND]: "Vetar",
    },
    hh = {
      [s.ADVERTISER]: "ஸ்பான்சர்",
      [s.AIR_QUALITY]: "காற்று தரம்",
      [s.CTA_TEXT]: "மேலும் பார்க்க",
      [s.DAYS]: "நாட்கள்",
      [s.DESCRIPTION]: "எங்கள் விளம்பரதாரரின் உள்ளடக்கத்தை தவறவிடாதீர்கள்",
      [s.FAIR]: "சராசரி",
      [s.GOOD]: "நன்று",
      [s.HOURS]: "மணி",
      [s.HUMIDITY]: "ஈரப்பதம்",
      [s.ISI]: "முக்கியமான பாதுகாப்பு தகவல்",
      [s.MINUTES_ABBREVIATION]: "நிமி",
      [s.MODERATE]: "மிதமானது",
      [s.POOR]: "மோசமானது",
      [s.PROMOTED_BY_TEXT]: "விளம்பரம்:",
      [s.SECONDS_ABBREVIATION]: "வினா",
      [s.TITLE]: "மேலும் தகவலுக்கு இங்கே கிளிக் செய்யவும்",
      [s.UNKNOWN]: "தெரியாதது",
      [s.UV_INDEX]: "யூவி குறியீடு",
      [s.VERY_POOR]: "மிக மோசமானது",
      [s.WIND]: "காற்று",
    },
    mh = {
      [s.ADVERTISER]: "ผู้สนับสนุน",
      [s.AIR_QUALITY]: "คุณภาพอากาศ",
      [s.CTA_TEXT]: "ดูเพิ่มเติม",
      [s.DAYS]: "วัน",
      [s.DESCRIPTION]: "อย่าพลาดเนื้อหานี้จากผู้สนับสนุนของเรา",
      [s.FAIR]: "พอใช้",
      [s.GOOD]: "ดี",
      [s.HOURS]: "ชั่วโมง",
      [s.HUMIDITY]: "ความชื้น",
      [s.ISI]: "ข้อมูลด้านความปลอดภัยที่สำคัญ",
      [s.MINUTES_ABBREVIATION]: "นาที",
      [s.MODERATE]: "ปานกลาง",
      [s.POOR]: "แย่",
      [s.PROMOTED_BY_TEXT]: "โฆษณาโดย",
      [s.SECONDS_ABBREVIATION]: "วินาที",
      [s.TITLE]: "คลิกที่นี่เพื่อดูข้อมูลเพิ่มเติม",
      [s.UNKNOWN]: "ไม่ทราบ",
      [s.UV_INDEX]: "ดัชนีรังสียูวี",
      [s.VERY_POOR]: "แย่มาก",
      [s.WIND]: "ลม",
    },
    fh = {
      [s.ADVERTISER]: "Tagasuporta",
      [s.AIR_QUALITY]: "Kalidad ng hangin",
      [s.CTA_TEXT]: "Tingnan pa",
      [s.DAYS]: "Araw",
      [s.DESCRIPTION]:
        "Huwag palampasin ang nilalamang ito mula sa aming sponsor",
      [s.FAIR]: "Katamtaman",
      [s.GOOD]: "Maganda",
      [s.HOURS]: "Oras",
      [s.HUMIDITY]: "Halumigmig",
      [s.ISI]: "Mahalagang Impormasyon sa Kaligtasan",
      [s.MINUTES_ABBREVIATION]: "Min",
      [s.MODERATE]: "Tama lang",
      [s.POOR]: "Masama",
      [s.PROMOTED_BY_TEXT]: "Anunsyo mula sa",
      [s.SECONDS_ABBREVIATION]: "Sec",
      [s.TITLE]: "Mag-click dito para sa karagdagang impormasyon",
      [s.UNKNOWN]: "Hindi alam",
      [s.UV_INDEX]: "UV Index",
      [s.VERY_POOR]: "Napakasama",
      [s.WIND]: "Hangin",
    },
    gh = {
      [s.ADVERTISER]: "Sponsor",
      [s.AIR_QUALITY]: "Air Quality",
      [s.CTA_TEXT]: "Tingnan pa",
      [s.DAYS]: "Araw",
      [s.DESCRIPTION]:
        "Huwag palampasin ang nilalamang ito mula sa aming sponsor",
      [s.FAIR]: "Fair",
      [s.GOOD]: "Good",
      [s.HOURS]: "Oras",
      [s.HUMIDITY]: "Humidity",
      [s.ISI]: "Important Safety Information",
      [s.MINUTES_ABBREVIATION]: "Min",
      [s.MODERATE]: "Moderate",
      [s.POOR]: "Poor",
      [s.PROMOTED_BY_TEXT]: "Ad mula sa",
      [s.SECONDS_ABBREVIATION]: "Sec",
      [s.TITLE]: "Click dito para sa karagdagang impormasyon",
      [s.UNKNOWN]: "Unknown",
      [s.UV_INDEX]: "UV Index",
      [s.VERY_POOR]: "Very Poor",
      [s.WIND]: "Wind",
    },
    bh = {
      [s.ADVERTISER]: "Nhà tài trợ",
      [s.AIR_QUALITY]: "Chất lượng không khí",
      [s.CTA_TEXT]: "Xem thêm",
      [s.DAYS]: "Ngày",
      [s.DESCRIPTION]: "Đừng bỏ lỡ nội dung này từ nhà tài trợ của chúng tôi",
      [s.FAIR]: "Tạm ổn",
      [s.GOOD]: "Tốt",
      [s.HOURS]: "Giờ",
      [s.HUMIDITY]: "Độ ẩm",
      [s.ISI]: "Thông tin an toàn quan trọng",
      [s.MINUTES_ABBREVIATION]: "Phút",
      [s.MODERATE]: "Trung bình",
      [s.POOR]: "Kém",
      [s.PROMOTED_BY_TEXT]: "Quảng cáo bởi",
      [s.SECONDS_ABBREVIATION]: "Giây",
      [s.TITLE]: "Nhấn vào đây để biết thêm thông tin",
      [s.UNKNOWN]: "Không rõ",
      [s.UV_INDEX]: "Chỉ số UV",
      [s.VERY_POOR]: "Rất kém",
      [s.WIND]: "Gió",
    },
    vh = {
      [s.ADVERTISER]: "赞助商",
      [s.AIR_QUALITY]: "空气质量",
      [s.CTA_TEXT]: "查看更多",
      [s.DAYS]: "天",
      [s.DESCRIPTION]: "不要错过我们赞助商的内容",
      [s.FAIR]: "一般",
      [s.GOOD]: "良好",
      [s.HOURS]: "小时",
      [s.HUMIDITY]: "湿度",
      [s.ISI]: "重要安全信息",
      [s.MINUTES_ABBREVIATION]: "分",
      [s.MODERATE]: "中等",
      [s.POOR]: "差",
      [s.PROMOTED_BY_TEXT]: "广告来自",
      [s.SECONDS_ABBREVIATION]: "秒",
      [s.TITLE]: "点击此处了解更多资讯",
      [s.UNKNOWN]: "未知",
      [s.UV_INDEX]: "紫外线指数",
      [s.VERY_POOR]: "很差",
      [s.WIND]: "风",
    },
    _h = {
      [s.ADVERTISER]: "贊助商",
      [s.AIR_QUALITY]: "空氣質素",
      [s.CTA_TEXT]: "查看更多",
      [s.DAYS]: "日",
      [s.DESCRIPTION]: "不要錯過我們贊助商的內容",
      [s.FAIR]: "尚可",
      [s.GOOD]: "良好",
      [s.HOURS]: "小時",
      [s.HUMIDITY]: "濕度",
      [s.ISI]: "重要安全資訊",
      [s.MINUTES_ABBREVIATION]: "分",
      [s.MODERATE]: "中等",
      [s.POOR]: "差",
      [s.PROMOTED_BY_TEXT]: "廣告由",
      [s.SECONDS_ABBREVIATION]: "秒",
      [s.TITLE]: "點擊此處了解更多資訊",
      [s.UNKNOWN]: "未知",
      [s.UV_INDEX]: "紫外線指數",
      [s.VERY_POOR]: "非常差",
      [s.WIND]: "風",
    },
    wh = {
      en: qp,
      es: Wp,
      ar: Yp,
      bg: Xp,
      bn: Kp,
      cs: Qp,
      de: Jp,
      "es-mx": Zp,
      fr: eh,
      hi: th,
      hr: rh,
      hu: nh,
      id: ah,
      it: ih,
      ja: oh,
      ko: sh,
      pl: ch,
      "pt-br": lh,
      ro: dh,
      sk: uh,
      sr: ph,
      ta: hh,
      th: mh,
      tl: fh,
      "tl-en": gh,
      vi: bh,
      "zh-cn": vh,
      "zh-hk": _h,
    },
    Ro = ue({ t: (e) => e }),
    yh = ({ language: e = Ht.ENGLISH, children: t }) => {
      const r = ce(() => {
        const n = wh[e] ?? {};
        return (a) => n[a] ?? a;
      }, [e]);
      return d(Ro.Provider, { value: { t: r }, children: t });
    },
    Oe = () => ae(Ro),
    xh = ({ price: e }) => {
      if (!e) return null;
      const t = e.data.value.match(/([$€£¥]?)(\d+)\.(\d+)/);
      if (!t) return null;
      const [, r, n, a] = t;
      return !r || !n || !a
        ? null
        : d("div", {
            className: "gc-price",
            children: [
              d("div", { className: "gc-price-currency", children: r }),
              d("div", { className: "gc-price-amount", children: n }),
              d("div", { className: "gc-price-decimal", children: a }),
            ],
          });
    };
  var $t = ((e) => (
    (e.Full = "full"), (e.Half = "half"), (e.Empty = "empty"), e
  ))($t || {});
  const Eh = ({ rating: e }) => {
      if (!e) return null;
      const t = parseFloat(e.data.value);
      if (isNaN(t) || t < 0) return null;
      const r = Array.from({ length: 5 }, (n, a) => {
        const i = a < Math.floor(t) ? $t.Full : a < t ? $t.Half : $t.Empty;
        return d("span", { class: `gc-star gc-star-${i}`, children: "★" }, a);
      });
      return d("div", { className: "gc-rating-stars", children: r });
    },
    Ah = ({ assets: e }) =>
      !e || (!e.rating && !e.price)
        ? null
        : d("div", {
            className: "gc-default-assets",
            children: [
              e.rating && d(Eh, { rating: e.rating }),
              e.price && d(xh, { price: e.price }),
            ],
          }),
    kh = (e) => {
      switch (e.type) {
        case b.GCEnhancementType.BannerCountdown:
        case b.GCEnhancementType.BannerDailyWeatherOutlook:
        case b.GCEnhancementType.BannerHeadline:
        case b.GCEnhancementType.BannerShoppable:
        case b.GCEnhancementType.BannerSportsTicker:
        case b.GCEnhancementType.BannerWeather:
        case b.GCEnhancementType.BannerShoppableOverlay:
        case b.GCEnhancementType.BannerMedalCount:
        case b.GCEnhancementType.BannerWorldTournament:
        case b.GCEnhancementType.BannerCustom:
        case b.GCEnhancementType.BannerSofiaPulseBettingOdds:
        case b.GCEnhancementType.BannerSofiaPulseQuiz:
        case b.GCEnhancementType.BannerSofiaPulseSportsHeadlines:
        case b.GCEnhancementType.BannerSofiaPulseStockTicker:
          return {
            type: b.GCEnhancementType.BannerHeadline,
            enhancement_version_id: e.enhancement_version_id,
          };
        case b.GCEnhancementType.OutstreamCaptions:
        case b.GCEnhancementType.OutstreamCountdown:
        case b.GCEnhancementType.OutstreamDailyWeatherOutlook:
        case b.GCEnhancementType.OutstreamHeadline:
        case b.GCEnhancementType.OutstreamShoppable:
        case b.GCEnhancementType.OutstreamSportsTicker:
        case b.GCEnhancementType.OutstreamWeather:
        case b.GCEnhancementType.OutstreamMedalCount:
        case b.GCEnhancementType.OutstreamBrandedHeadline:
        case b.GCEnhancementType.OutstreamWorldTournament:
        case b.GCEnhancementType.OutstreamCustom:
          return {
            type: b.GCEnhancementType.OutstreamHeadline,
            enhancement_version_id: e.enhancement_version_id,
          };
        default:
          return e;
      }
    },
    No = (e, t) => {
      ha(() => {
        const { current: r } = e;
        if (!r) return;
        const { webkitLineClamp: n, lineHeight: a } =
            window.getComputedStyle(r),
          i = parseFloat(n),
          o = parseFloat(a);
        !isNaN(i) &&
          i > 0 &&
          !isNaN(o) &&
          o > 0 &&
          (r.style.maxHeight = `${i * o}px`);
      }, [e, t]);
    },
    Ft = (e, t) => e && !!t,
    Ih = ({ text: e, publisherStyles: t }) => {
      const r = O(null);
      No(r, t);
      let n = t?.description?.font?.toStyle();
      const a = t?.description?.background?.toStyle(),
        i = t?.description?.font?.hoverColor;
      if (i) {
        const { color: o, ...c } = n || {};
        n = { ...c, "--hover-color": i };
      }
      return d("div", {
        className: $("gc-description", t && "str-enhanced-description"),
        children: d("span", {
          style: { ...n, ...a },
          title: e,
          ref: r,
          children: e,
        }),
      });
    },
    Ch = ({ advertiser: e, publisherStyles: t }) => {
      const { promotedByText: r, name: n, brandLogoUrl: a } = e,
        i = t?.promotedBy?.font?.toStyle(),
        o = t?.promotedBy?.background?.toStyle();
      return d("div", {
        className: "str-advertiser-container advertiser-container",
        style: o,
        children: d(G, {
          children: [
            d("span", {
              className: "str-promoted-by promoted-by",
              "data-shadow": r,
              style: i,
              children: r,
            }),
            d("span", {
              className: "str-advertiser advertiser",
              "data-shadow": n,
              style: i,
              children: n,
            }),
            a &&
              d("img", { alt: "Brand Logo", className: "brand-logo", src: a }),
          ],
        }),
      });
    },
    Sh = (e) =>
      !e || !("cta" in e) || typeof e.cta != "object" ? null : e.cta.text,
    Th = (e) => (e && e?.cta?.data?.value) || null,
    Oh = (e, t) => {
      if (
        typeof e == "object" &&
        "cta" in e &&
        typeof e.cta == "object" &&
        e.cta !== null
      ) {
        const r = e.cta,
          n = {
            "--cta-text-color":
              typeof r == "object" &&
              "textColor" in r &&
              typeof r.textColor == "string"
                ? r.textColor
                : void 0,
            "--cta-background-color":
              typeof r == "object" &&
              "backgroundColor" in r &&
              typeof r.backgroundColor == "string"
                ? r.backgroundColor
                : void 0,
            "--cta-text-hover-color":
              typeof r == "object" &&
              "textHoverColor" in r &&
              typeof r.textHoverColor == "string"
                ? r.textHoverColor
                : void 0,
            "--cta-background-hover-color":
              typeof r == "object" &&
              "backgroundHoverColor" in r &&
              typeof r.backgroundHoverColor == "string"
                ? r.backgroundHoverColor
                : void 0,
          };
        return Object.fromEntries(
          Object.entries(n).filter(([a, i]) => i !== void 0)
        );
      }
      if (t && t.cta) {
        const { cta: r } = t,
          n = {
            "--cta-text-color": r.font?.color,
            "--cta-background-color": r.background?.color,
            "--cta-text-hover-color": r.font?.hoverColor,
            "--cta-background-hover-color": r.background?.hoverColor,
            "--cta-border-width": r.border?.width
              ? `${r.border.width}px`
              : void 0,
            "--cta-border-color": r.border?.color,
            "--cta-border-style": r.border?.style,
            "--cta-border-radius":
              r.border?.radius !== void 0 ? `${r.border.radius}px` : void 0,
          };
        return Object.fromEntries(
          Object.entries(n).filter(([a, i]) => i !== void 0)
        );
      }
      return {};
    },
    Rh = (e, t) => {
      const [r, n] = V(!1);
      return (
        A(() => {
          if (!e.current) return;
          const a = e.current.clientWidth;
          (e.current.parentElement?.clientWidth || 0) - a < t && n(!0);
        }, [e, t]),
        r
      );
    },
    Nh = ({ ctaText: e, ctaStyle: t }) => {
      const { t: r } = Oe(),
        n = O(null),
        a = Rh(n, 10);
      return d("div", {
        children: d("div", {
          className: "gc-cta",
          style: t,
          children: d("span", { ref: n, children: a ? r(s.CTA_TEXT) : e }),
        }),
      });
    },
    Dh = (e) =>
      !e || !("title" in e) || typeof e.title != "string" ? null : e.title,
    Ph = (e) => (e && e?.title?.title.text) || null,
    zh = (e) =>
      !e || !("description" in e) || typeof e.description != "string"
        ? null
        : e.description,
    Uh = (e) => (e && e?.description?.data.value) || null,
    Mh = (e) => {
      if (!e || !("advertiser" in e) || typeof e.advertiser != "object") return;
      if (e.advertiser === null) return null;
      const {
        advertiser: { name: t, promotedByText: r, brandLogoUrl: n },
      } = e;
      return { name: t, promotedByText: r, brandLogoUrl: n };
    },
    Bh = (e) => {
      if (!e) return null;
      const t = e?.sponsored?.data.value,
        r = Lh(e);
      return { name: t || "", promotedByText: "", brandLogoUrl: r || void 0 };
    },
    Lh = (e) => {
      const t = e?.mainImage?.img.url,
        r = e?.icon?.img.url;
      return t === r || !r ? null : r;
    };
  function Vh({ assets: e, enhancement: t }) {
    const { t: r } = Oe(),
      n = Dh(t?.payload),
      a = Ph(e);
    return n || a || (!t?.payload && r(s.TITLE)) || "";
  }
  function Hh({ assets: e, enhancement: t }) {
    const { t: r } = Oe(),
      n = zh(t?.payload),
      a = Uh(e);
    return n || a || (!t?.payload && r(s.DESCRIPTION)) || "";
  }
  function $h({ assets: e, enhancement: t, publisherStyles: r }) {
    const { t: n } = Oe(),
      a = Mh(t?.payload),
      i = Bh(e),
      o =
        a == null && i == null && t?.payload
          ? null
          : {
              promotedByText:
                a?.promotedByText ||
                i?.promotedByText ||
                (!t?.payload && n(s.PROMOTED_BY_TEXT)) ||
                "",
              name:
                a?.name || i?.name || (!t?.payload && n(s.ADVERTISER)) || "",
              brandLogoUrl: a?.brandLogoUrl || i?.brandLogoUrl,
            },
      c = Sh(t?.payload),
      l = Th(e),
      u = c || l || (!t?.payload && n(s.CTA_TEXT)) || "",
      p = Oh(t?.payload, r);
    return { advertiser: o, ctaText: u, ctaStyle: p };
  }
  const bn = ({
      assets: e,
      enhancement: t,
      publisherStyles: r,
      hideAdvertiser: n,
      hideCallToAction: a,
    }) => {
      const {
          advertiser: i,
          ctaText: o,
          ctaStyle: c,
        } = $h({ assets: e, enhancement: t, publisherStyles: r }),
        l = n || !i || Ft(r?.promotedBy?.hide, !e?.sponsored?.data.value),
        u = a || !o || Ft(r?.cta?.hide, !e?.cta?.data.value);
      return d("div", {
        className: "gc-bottom str-enhancement-footer",
        children: [
          l ? d("div", {}) : d(Ch, { publisherStyles: r, advertiser: i }),
          u ? d("div", {}) : d(Nh, { ctaText: o, ctaStyle: c }),
        ],
      });
    },
    Fh = (e) => {
      A(() => {
        const t = (r) => (n) => {
          n.stopPropagation(),
            n.preventDefault(),
            window.open(r.href, "_blank");
        };
        if (e.current) {
          const r = e.current.querySelectorAll("a"),
            n = new Map();
          return (
            r.forEach((a) => {
              const i = t(a);
              a.addEventListener("click", i), n.set(a, i);
            }),
            () => {
              r.forEach((a) => {
                a.removeEventListener("click", n.get(a));
              });
            }
          );
        }
        return () => {};
      }, [e]);
    },
    Gh = (e, t, r = 150) => {
      const [n, a] = V(!1);
      return (
        du(
          () => {
            const o = e.current;
            if (o === null || !o.scrollBy) return;
            const c = o.scrollTop;
            o.scrollBy(0, 1);
            const l = o.scrollTop;
            c === l && a(!0);
          },
          !n && t ? r : null
        ),
        n
      );
    },
    jh = ({ autoscroll: e = !1, text: t, header: r, subheader: n }) => {
      const { t: a } = Oe(),
        i = O(null);
      return (
        Gh(i, e),
        Fh(i),
        d("div", {
          className: "str-isi-bundle-2",
          children: [
            d("div", {
              "data-testid": "isi-headline",
              className: "str-isi-headline",
              children: r ?? a(s.ISI),
            }),
            n && d("div", { dangerouslySetInnerHTML: { __html: n } }),
            d("div", {
              ref: i,
              dangerouslySetInnerHTML: { __html: t },
              className: "str-isi-text",
            }),
          ],
        })
      );
    },
    qh = ({ text: e, publisherStyles: t }) => {
      const r = O(null);
      No(r, t);
      const n = t?.title?.background?.toStyle();
      let a = t?.title?.font?.toStyle();
      const i = t?.title?.font?.hoverColor;
      if (i) {
        const { color: o, ...c } = a || {};
        a = { ...c, "--hover-color": i };
      }
      return d("div", {
        className: $("gc-title", t && "str-enhanced-title"),
        children: d("span", {
          title: e,
          ref: r,
          style: { ...a, ...n },
          children: e,
        }),
      });
    },
    Do = ({
      publisherStyles: e,
      assets: t,
      enhancement: r,
      isi: n,
      fallback: a,
      onLoad: i,
    }) => {
      const o = Vh({ assets: t, enhancement: r }),
        c = Hh({ assets: t, enhancement: r });
      A(() => {
        i({ enhancementType: r.type, fallback: a });
      }, []);
      const l = Ft(e?.description?.hide, !t?.description?.data.value),
        u = Ft(e?.title?.hide, !t?.title?.title.text);
      return d(G, {
        children: [
          d("div", {
            className: $("gc-text", e && "str-enhanced-text"),
            children: [
              o && !u ? d(qh, { publisherStyles: e, text: o }) : d("div", {}),
              c && !l && d(Ih, { publisherStyles: e, text: c }),
              d(Ah, { assets: t }),
            ],
          }),
          n && d(jh, { ...n }),
          d(bn, { assets: t, enhancement: r, publisherStyles: e }),
        ],
      });
    };
  var ie = ((e) => (
    (e.CLICKTHROUGH = "enhancement_click_through"),
    (e.CONTENT = "enhancement_content"),
    (e.ENGAGEMENT = "enhancement_engagement"),
    (e.SHOPPABLECAROUSEL_ARROW = "enhancement_shoppable_carousel_arrow"),
    (e.PRODUCTCARD = "enhancement_product_card"),
    e
  ))(ie || {});
  const lt = ({
    assets: e,
    children: t,
    className: r,
    enhancement: n,
    enhancementLoaded: a,
    language: i,
    onClick: o,
    onError: c,
    onLoad: l,
    publisherStyles: u,
    style: p,
  }) => {
    const h = kh(n);
    return a === void 0
      ? null
      : d(yh, {
          language: i,
          children: d("div", {
            className: $(
              r,
              "gc-enhancement-main-container",
              n.type && `gc-enhancement-main-container-${n.type}`,
              !a && "gc-enhancement-main-container-fallback"
            ),
            onClick: () => {
              o({
                enhancementType: a ? n.type : h.type,
                eventType: ie.CONTENT,
              });
            },
            style: p,
            children: d("div", {
              className: "gc-enhancement-container",
              children: a
                ? t
                : d(Do, {
                    publisherStyles: u,
                    assets: e,
                    enhancement: h,
                    fallback: !0,
                    onLoad: l,
                    onClick: o,
                    onError: c,
                  }),
            }),
          }),
        });
  };
  var q = ((e) => (
    (e.Error = "error"),
    (e.ClickThrough = "enhancementClickThrough"),
    (e.EngagementClick = "engagementClick"),
    (e.ContentClick = "contentClick"),
    (e.ProductCardClick = "productCardClick"),
    (e.ShoppableCarouselArrowClick = "shoppableCarouselArrowClick"),
    (e.HealthCheckFail = "healthCheckFail"),
    (e.HealthCheckOk = "healthCheckOk"),
    (e.Initialized = "initialized"),
    (e.EnhancementLoaded = "enhancementLoaded"),
    e
  ))(q || {});
  const we = {
    peekDistance: 56,
    peekDelay: 700,
    peekHoldTime: 550,
    retreatTime: 320,
    loopInterval: 2800,
    slideEasing: "cubic-bezier(0.25, 0.46, 0.45, 0.94)",
    retreatEasing: "cubic-bezier(0.25, 0.46, 0.45, 0.94)",
  };
  function Wh(e, t, r) {
    let n = null,
      a = null,
      i = !1;
    const o = () => {
        n != null && (clearTimeout(n), (n = null)),
          a != null && (clearTimeout(a), (a = null));
      },
      c = () => {
        i ||
          ((t.style.transition = `transform ${we.peekHoldTime}ms ${we.slideEasing}`),
          (t.style.transform = `translateX(calc(-100% + ${we.peekDistance}px))`),
          (a = window.setTimeout(l, we.peekHoldTime)));
      },
      l = () => {
        i ||
          ((t.style.transition = `transform ${we.retreatTime}ms ${we.retreatEasing}`),
          (t.style.transform = "translateX(-100%)"),
          (n = window.setTimeout(c, we.loopInterval)));
      },
      u = () => {
        (i = !0), o(), (t.style.transition = ""), (t.style.transform = ""), r();
      },
      p = () => {
        (i = !1), (n = window.setTimeout(c, we.loopInterval));
      };
    return (
      e.addEventListener("mouseenter", u),
      e.addEventListener("mouseleave", p),
      e.addEventListener("touchstart", u, { passive: !0 }),
      (n = window.setTimeout(c, we.peekDelay)),
      () => {
        o(),
          (i = !0),
          (t.style.transition = ""),
          (t.style.transform = ""),
          e.removeEventListener("mouseenter", u),
          e.removeEventListener("mouseleave", p),
          e.removeEventListener("touchstart", u);
      }
    );
  }
  const Ge = {
      chevronCount: 3,
      animDuration: 1800,
      animDelay: 180,
      travelDistance: 7,
      baseOpacities: [1, 0.65, 0.3],
    },
    Yh =
      '<svg xmlns="http://www.w3.org/2000/svg" width="12" height="18" viewBox="0 0 12 18" fill="none"><path d="M2 2l8 7-8 7" stroke="rgba(0,0,0,0.5)" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  function Xh(e, t, r) {
    const n = e.style.position;
    e.style.position = "relative";
    const a = document.createElement("div");
    (a.className = "gc-hint-chevrons"), a.setAttribute("aria-hidden", "true");
    const i = document.createElement("style");
    i.textContent = `
    .gc-hint-chevrons {
      position: absolute;
      left: 10px;
      top: 50%;
      transform: translateY(-50%);
      z-index: 7;
      pointer-events: none;
      transition: opacity 0.3s;
      display: flex;
      align-items: center;
    }
    .gc-hint-chevron {
      position: absolute;
      top: 0;
      left: 0;
      display: flex;
      align-items: center;
      animation: gc-hint-chevron-pulse ${Ge.animDuration}ms ease-in-out infinite;
    }
    @keyframes gc-hint-chevron-pulse {
      0% { opacity: 0; transform: translateX(0); }
      20% { opacity: var(--gc-hint-chevron-opacity); }
      50% { opacity: var(--gc-hint-chevron-opacity); transform: translateX(${Ge.travelDistance}px); }
      80% { opacity: 0; transform: translateX(${Ge.travelDistance}px); }
      100% { opacity: 0; transform: translateX(0); }
    }
  `;
    for (let c = 0; c < Ge.chevronCount; c++) {
      const l = document.createElement("div");
      (l.className = "gc-hint-chevron"),
        (l.innerHTML = Yh),
        l.style.setProperty(
          "--gc-hint-chevron-opacity",
          String(Ge.baseOpacities[c])
        ),
        (l.style.animationDelay = `${c * Ge.animDelay}ms`),
        (l.style.left = `${c * 10}px`),
        a.appendChild(l);
    }
    e.appendChild(i), e.appendChild(a);
    const o = () => {
      (a.style.opacity = "0"), r();
    };
    return (
      e.addEventListener("mouseenter", o),
      e.addEventListener("touchstart", o, { passive: !0 }),
      () => {
        e.removeEventListener("mouseenter", o),
          e.removeEventListener("touchstart", o),
          a.remove(),
          i.remove(),
          (e.style.position = n);
      }
    );
  }
  const de = {
      travelDistance: 200,
      cycleDuration: 3800,
      fadeInEnd: 12,
      sweepEnd: 62,
      fadeOutEnd: 78,
      trailMaxWidth: 48,
    },
    Kh =
      '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="rgba(0,0,0,0.45)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M8 14.5V8a2.5 2.5 0 0 1 5 0v5"/><path d="M13 12.5a2 2 0 0 1 4 0v1.5"/><path d="M17 13.5a2 2 0 0 1 4 0V16a8 8 0 0 1-8 8h-1a8 8 0 0 1-6.73-3.67L3.1 17.1A1.5 1.5 0 0 1 5.66 15L8 17"/><path d="M5 2l3 3M2 5l3 3" opacity="0.5"/></svg>';
  function Qh(e, t, r) {
    const n = e.style.position;
    e.style.position = "relative";
    const a = document.createElement("div");
    (a.className = "gc-hint-ghost"), a.setAttribute("aria-hidden", "true");
    const i = document.createElement("div");
    i.className = "gc-hint-ghost-trail";
    const o = document.createElement("div");
    (o.className = "gc-hint-ghost-hand"),
      (o.innerHTML = Kh),
      a.appendChild(i),
      a.appendChild(o);
    const c = document.createElement("style");
    (c.textContent = `
    .gc-hint-ghost {
      position: absolute;
      left: 0;
      top: 50%;
      transform: translateY(-50%);
      z-index: 7;
      pointer-events: none;
      transition: opacity 0.3s;
    }
    .gc-hint-ghost-hand {
      position: relative;
      animation: gc-hint-ghost-sweep ${de.cycleDuration}ms ease-in-out infinite;
    }
    .gc-hint-ghost-trail {
      position: absolute;
      top: 50%;
      left: 12px;
      height: 2px;
      background: linear-gradient(to right, transparent, rgba(0,0,0,0.2));
      transform: translateY(-50%);
      animation: gc-hint-ghost-trail ${de.cycleDuration}ms ease-in-out infinite;
    }
    @keyframes gc-hint-ghost-sweep {
      0% { transform: translateX(10px); opacity: 0; }
      ${de.fadeInEnd}% { opacity: 0.9; }
      ${de.sweepEnd}% { transform: translateX(${de.travelDistance}px); opacity: 0.9; }
      ${de.fadeOutEnd}% { transform: translateX(${de.travelDistance}px); opacity: 0; }
      100% { transform: translateX(10px); opacity: 0; }
    }
    @keyframes gc-hint-ghost-trail {
      0% { width: 0; opacity: 0; }
      ${de.fadeInEnd}% { opacity: 0.6; }
      ${de.sweepEnd}% { width: ${de.trailMaxWidth}px; opacity: 0.6; }
      ${de.fadeOutEnd}% { width: ${de.trailMaxWidth}px; opacity: 0; }
      100% { width: 0; opacity: 0; }
    }
  `),
      e.appendChild(c),
      e.appendChild(a);
    const l = () => {
      (a.style.opacity = "0"), r();
    };
    return (
      e.addEventListener("mouseenter", l),
      e.addEventListener("touchstart", l, { passive: !0 }),
      () => {
        e.removeEventListener("mouseenter", l),
          e.removeEventListener("touchstart", l),
          a.remove(),
          c.remove(),
          (e.style.position = n);
      }
    );
  }
  const Po = { B: Wh, C: Xh, D: Qh };
  function Jh(e) {
    return e in Po;
  }
  const Zh = 48,
    vn = "gc-hint-edge-peek";
  function em(e, t, r) {
    A(() => {
      const n = e.current;
      if (!n || !r || !Jh(r)) return;
      const a = n.querySelector(t);
      if (!a) return;
      const i = document.createElement("style");
      (i.textContent = `.str-adunit-overlay ${t}.${vn}:not(.is-open) { transform: translateX(calc(-100% + ${Zh}px)); }`),
        document.head.appendChild(i);
      const o = a.style.transition;
      (a.style.transition = "none"),
        a.classList.add(vn),
        a.getBoundingClientRect(),
        (a.style.transition = o);
      const c = Po[r](n, a, () => {});
      return () => {
        c(), a.classList.remove(vn), i.remove();
      };
    }, [e, t, r]);
  }
  const tm = [q.Error],
    rm = [
      q.ClickThrough,
      q.ContentClick,
      q.EngagementClick,
      q.ProductCardClick,
      q.ShoppableCarouselArrowClick,
    ],
    nm = (e) => {
      switch (e) {
        case q.EngagementClick:
          return ie.ENGAGEMENT;
        case q.ProductCardClick:
          return ie.PRODUCTCARD;
        case q.ShoppableCarouselArrowClick:
          return ie.SHOPPABLECAROUSEL_ARROW;
        case q.ClickThrough:
          return ie.CLICKTHROUGH;
        default:
          return ie.CONTENT;
      }
    };
  function am(e) {
    return (
      typeof e == "object" &&
      e !== null &&
      "eventType" in e &&
      typeof e.eventType == "string"
    );
  }
  const im = (e, t, r, n, a, i, o) => {
      const c = new URL(t.payload.templateUrl).origin;
      if (e.origin !== c) return;
      let l;
      try {
        l = typeof e.data == "string" ? JSON.parse(e.data) : e.data;
      } catch (p) {
        a({
          error: new Error(
            `Error parsing remote enhancement event data: ${
              p instanceof Error ? p.message : String(p)
            }`
          ),
          data: e.data,
        });
        return;
      }
      if (!am(l)) return;
      const { eventType: u } = l;
      if (tm.includes(u)) {
        a({
          error: new Error(`Remote enhancement error event: ${u}`),
          data: e.data,
          isPageFailure: !0,
        }),
          i(!0);
        return;
      }
      if (rm.includes(u)) {
        n({
          enhancementType: t.type,
          eventType: nm(u),
          productId: l.data?.productId,
        });
        return;
      }
      switch (u) {
        case q.Initialized:
        case q.HealthCheckOk:
          r(u);
          break;
        case q.HealthCheckFail:
          i(!0), r(u);
          break;
        case q.EnhancementLoaded:
          o?.();
          break;
      }
    },
    om = 3e3,
    sm = ({
      enhancement: e,
      onClick: t,
      onLoad: r,
      onError: n,
      language: a,
      publisherStyles: i,
      onLifecycleChange: o,
      hasPreflight: c = !1,
    }) => {
      const [l, u] = V(!1),
        [p, h] = V(!1),
        m = O(null),
        f = O(null),
        [g, w] = V(void 0),
        y = fe(() => {
          f.current !== null && (clearTimeout(f.current), (f.current = null));
        }, []),
        v = fe(() => {
          y(), w(!0);
        }, [y]),
        x = fe(() => {
          f.current !== null ||
            Ze() ||
            (f.current = setTimeout(() => {
              (f.current = null),
                w(!1),
                n({
                  error: new Error(
                    "Remote enhancement did not send enhancementLoaded message within timeout"
                  ),
                  isPageFailure: !0,
                });
            }, om));
        }, [n]),
        E = fe(
          (T) => {
            T === q.Initialized && x(), o(T);
          },
          [x, o]
        ),
        _ = fe(
          (T) => {
            im(T, e, E, t, n, u, v);
          },
          [e, E, t, n, v]
        );
      A(() => {
        if (e?.payload.templateUrl)
          return (
            window.addEventListener("message", _),
            h(!0),
            () => {
              window.removeEventListener("message", _);
            }
          );
      }, [e?.payload.templateUrl, _]);
      const k = async (T) => {
        if (c)
          try {
            if (!(await Dp(T))) {
              w(!1),
                n({
                  error: new Error(
                    `Remote enhancement preflight: enhancement not available at ${T}`
                  ),
                  isPageFailure: !0,
                });
              return;
            }
          } catch (W) {
            const Y = W instanceof Error ? W : null;
            w(!1),
              n({
                error: new Error(
                  `Preflight check failed for remote enhancement: ${T}`
                ),
                data: Y,
                isPageFailure: !0,
              });
            return;
          }
        let P;
        try {
          P = await fetch(T, { method: "GET" });
        } catch (W) {
          const Y = W instanceof Error ? W : null;
          w(!1),
            n({
              error: new Error(
                `Failed to fetch remote enhancement templateUrl: ${T}`
              ),
              data: Y,
              isPageFailure: !0,
            });
          return;
        }
        if (!P.ok) {
          w(!1),
            n({
              error: new Error(
                `Remote enhancement templateUrl returned status ${P.status}`
              ),
              isPageFailure: !0,
            });
          return;
        }
        w(!0), r({ enhancementType: e.type });
      };
      return (
        A(() => {
          if (e) {
            if (!e.payload.templateUrl) {
              w(!1),
                n({
                  error: new Error("Remote enhancement templateUrl is missing"),
                });
              return;
            }
            return (
              k(e.payload.templateUrl),
              () => {
                y();
              }
            );
          }
        }, [e, c]),
        d(lt, {
          enhancement: e,
          enhancementLoaded: g && !l,
          language: a,
          onClick: t,
          onError: n,
          onLoad: r,
          publisherStyles: i,
          children: d("iframe", {
            "data-listener": p ? "true" : "false",
            ref: m,
            src: e.payload.templateUrl,
            style: {
              borderWidth: 0,
              width: "100%",
              height: "100%",
              overflow: "hidden",
            },
            scrolling: "no",
          }),
        })
      );
    },
    cm = { 1: s.GOOD, 2: s.FAIR, 3: s.MODERATE, 4: s.POOR, 5: s.VERY_POOR },
    zo = ue(new Map()),
    lm = ({ icons: e, children: t }) =>
      d(zo.Provider, { value: e, children: t }),
    dm = () => ae(zo),
    Uo = ({ icon: e, isCondensed: t, color: r = "#ffffff" }) => {
      const a = dm().get(e);
      return a
        ? d("div", {
            className: $("str-weather-icon", t && "condensed"),
            children: d("div", {
              style: { color: r, display: "flex", flex: 1 },
              dangerouslySetInnerHTML: { __html: a },
            }),
          })
        : null;
    },
    Gt = ({ value: e, icon: t, className: r, description: n }) => {
      const a = O(null);
      return !e || !t || !r || !n
        ? d("div", {
            className: "str-weather-container",
            children: d("span", { className: "loading" }),
          })
        : d("div", {
            ref: a,
            className: `str-weather-container str-weather-container-${r}`,
            children: d("div", {
              className: "str-information-container",
              children: [
                d("div", {
                  className: "str-forecast-icon",
                  children: [
                    d(Uo, { icon: t }),
                    d("div", {
                      className: "str-forecast str-forecast-condensed",
                      children: d("span", {
                        className: "str-forecast-weekday",
                        children: n,
                      }),
                    }),
                  ],
                }),
                d("div", { className: "str-information", children: e }),
              ],
            }),
          });
    },
    um = () =>
      d("svg", {
        role: "img",
        "aria-label": "Map marker icon",
        width: "19",
        height: "19",
        viewBox: "0 0 19 19",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        className: "str-map-marker",
        children: d("path", {
          fillRule: "evenodd",
          clipRule: "evenodd",
          d: "M15.125 6.6875C15.125 3.5809 12.6066 1.0625 9.5 1.0625C6.3934 1.0625 3.875 3.5809 3.875 6.6875C3.875 9.24275 7.6805 15.65 9.03125 17.6863C9.13547 17.8434 9.31146 17.9378 9.5 17.9378C9.68854 17.9378 9.86453 17.8434 9.96875 17.6863C11.3195 15.65 15.125 9.24275 15.125 6.6875ZM12.3125 6.6875C12.3125 8.2408 11.0533 9.5 9.5 9.5C7.9467 9.5 6.6875 8.2408 6.6875 6.6875C6.6875 5.1342 7.9467 3.875 9.5 3.875C11.0533 3.875 12.3125 5.1342 12.3125 6.6875Z",
          fill: "#ffffff",
        }),
      }),
    _n = ({ city: e, forecast: t, type: r, className: n }) => {
      const a = O(null);
      if (!t || !e || !r)
        return d("div", {
          className: "str-weather-container",
          children: d("span", { className: "loading" }),
        });
      const {
        description: i,
        icon: o,
        temperature: c,
        temperatureMax: l,
        temperatureMin: u,
        dayName: p,
        main: h,
      } = t;
      return d("div", {
        ref: a,
        className: $(
          "str-weather-container",
          `str-weather-container-${at(h)}`,
          n
        ),
        children: [
          d("div", {
            className: "str-city",
            children: [d(um, {}), d("div", { children: e })],
          }),
          d("div", {
            className: "str-forecast",
            children: [
              d("span", { className: "str-forecast-weekday", children: p }),
              d("span", { children: [" ", i] }),
            ],
          }),
          d("div", {
            className: "str-information-container",
            children: [
              d("div", {
                className: "str-forecast-icon",
                children: [
                  d(Uo, { icon: o }),
                  d("div", {
                    className: "str-forecast str-forecast-condensed",
                    children: [
                      d("div", { className: "str-forecast-city", children: e }),
                      d("span", {
                        className: "str-forecast-weekday",
                        children: [p, ","],
                      }),
                      d("span", {
                        className: "str-forecast-description",
                        children: [" ", i],
                      }),
                    ],
                  }),
                ],
              }),
              d("div", {
                className: "str-temperature",
                children: [c, "°", d("span", { children: r })],
              }),
              d("div", {
                className: "str-temperature-variation",
                children: [
                  d("div", {
                    className: "str-temperature-high",
                    children: [
                      d("span", { className: "icon icon-up" }),
                      d("span", { children: [l, "°"] }),
                    ],
                  }),
                  d("div", {
                    className: "str-temperature-low",
                    children: [
                      d("span", { className: "icon icon-down" }),
                      d("span", { children: [u, "°"] }),
                    ],
                  }),
                ],
              }),
            ],
          }),
        ],
      });
    };
  var jt = ((e) => ((e.Fahrenheit = "F"), (e.Celsius = "C"), e))(jt || {});
  const pm = ({ weatherData: e }) => {
      const { t } = Oe(),
        r = e?.forecast?.[0],
        n = e?.city,
        a = e?.type;
      return d(G, {
        children: [
          d("div", {
            className: "str-weather-main",
            children: d(_n, {
              className: "str-weather-container-main",
              type: a,
              city: n,
              forecast: r,
            }),
          }),
          d("div", {
            className: "str-weather-information",
            children: [
              d(Gt, {
                description: e ? t(s.HUMIDITY) : void 0,
                value: r ? `${r.humidity}%` : void 0,
                icon: r ? "humidity" : void 0,
                className: r ? at(r.main) : void 0,
              }),
              d(Gt, {
                description: e ? t(s.AIR_QUALITY) : void 0,
                value: r ? t(cm[e.aqi] || s.UNKNOWN) : void 0,
                icon: r ? "air" : void 0,
                className: r ? at(r.main) : void 0,
              }),
              d(Gt, {
                description: e ? t(s.WIND) : void 0,
                value: r
                  ? `${r.wind}${a === jt.Celsius ? "m/s" : "mi/h"}`
                  : void 0,
                icon: r ? "wind" : void 0,
                className: r ? at(r.main) : void 0,
              }),
              d(Gt, {
                description: e ? t(s.UV_INDEX) : void 0,
                value: r ? `${r.uvIndex}` : void 0,
                icon: r ? "uv" : void 0,
                className: r ? at(r.main) : void 0,
              }),
            ],
          }),
        ],
      });
    },
    hm = 5,
    mm = ({ weatherData: e }) => {
      const t = { city: e?.city, type: e?.type },
        r = e?.forecast?.slice(0, hm) ?? [],
        [n, ...a] = r,
        i = "str-weather-container-main",
        o = "str-weather-container-information";
      return d(G, {
        children: [
          d("div", {
            className: "str-weather-main",
            children: d(_n, { className: i, ...t, forecast: n }),
          }),
          d("div", {
            className: "str-weather-information",
            children: a.map((c) =>
              d(_n, { className: o, ...t, forecast: c }, c.time)
            ),
          }),
        ],
      });
    },
    fm = "https://cdn.rendering.sharethrough.com/weather-icons",
    gm = (e) => `${fm}/${e}.svg`,
    bm = async (e, t) => {
      const r = [...new Set(e)],
        n = new Map();
      return (
        await Promise.allSettled(
          r.map(async (a) => {
            try {
              const i = await fetch(gm(a));
              if (!i.ok) {
                R(`Failed to fetch weather icon "${a}": ${i.status}`, {
                  scope: t,
                  context: "weather/fetch-icons",
                });
                return;
              }
              const o = await i.text();
              n.set(a, o);
            } catch (i) {
              R(i, { scope: t, context: "weather/fetch-icons", iconCode: a });
            }
          })
        ),
        n
      );
    };
  let vm = class {
    constructor(t, r) {
      (this.lat = t.lat),
        (this.lon = t.lon),
        (this.city = t.location.name),
        (this.type = t.units === "imperial" ? jt.Fahrenheit : jt.Celsius),
        (this.aqi = t.aqi),
        t.daily &&
          t.current &&
          ((this.forecast = t.daily.map((n) => new _m(n, r))),
          (this.forecast[0].temperature = Math.round(t.current.temp)));
    }
  };
  class _m {
    constructor(t, r) {
      const n = new Date(t.dt * 1e3);
      (this.date = n),
        (this.time = n.getTime()),
        (this.dayName = n.toLocaleDateString(r, { weekday: "long" })),
        (this.humidity = t.humidity),
        (this.description = t.weather[0].description),
        (this.icon = t.weather[0].icon),
        (this.main = t.weather[0].main),
        (this.temperatureMax = Math.round(t.temp.max)),
        (this.temperatureMin = Math.round(t.temp.min)),
        (this.temperature = Math.round(t.temp.day)),
        (this.wind = Math.round(t.wind_speed)),
        (this.uvIndex = t.uvi);
    }
  }
  const wm = ["humidity", "air", "wind", "uv"],
    ym = ["playground.rendering.sharethrough.com", "chromatic.com"],
    xm = () => {
      let e = null;
      try {
        e = window.top?.location?.origin || window.location.origin;
      } catch {}
      return e && ym.some((t) => e.includes(t))
        ? {
            url: "/assets/json/weather.json",
            method: "GET",
            headers: !1,
            body: !1,
          }
        : {
            url: "https://cdn.rendering.sharethrough.com/weather",
            method: "POST",
            headers: !0,
            body: !0,
          };
    },
    Em = (e, t, r, n) => {
      const [a, i] = V(null),
        [o, c] = V(new Map()),
        [l, u] = V(null),
        [p, h] = V(!0),
        m = ce(() => xm(), []),
        f = le();
      return (
        A(() => {
          let g = !0;
          const w = JSON.stringify({ coordinates: r, units: n, lang: e });
          return (
            (async () => {
              try {
                const v = await fetch(m.url, {
                  method: m.method,
                  ...(m.headers
                    ? { headers: { "Content-Type": "application/json" } }
                    : {}),
                  ...(m.body ? { body: w } : {}),
                });
                if (!v.ok) throw new Error(`Weather API error: ${v.status}`);
                const x = await v.json();
                if (x && g) {
                  const E = new vm(x, e);
                  i(E), u(null);
                  const _ = t
                      ? E.forecast.slice(0, 5).map((T) => T.icon)
                      : [E.forecast[0]?.icon, ...wm].filter(Boolean),
                    k = await bm(_, f);
                  g && c(k);
                } else g && u(new Error("Weather data is null"));
              } catch (v) {
                g &&
                  u(
                    v instanceof Error
                      ? v
                      : new Error("Failed to fetch weather data")
                  );
              } finally {
                g && h(!1);
              }
            })(),
            () => {
              g = !1;
            }
          );
        }, [r, n, e, t, m.url, m.method, m.headers, m.body]),
        [a, o, l, p]
      );
    },
    Am = ({
      enhancement: e,
      language: t,
      onClick: r,
      onError: n,
      onLoad: a,
      publisherStyles: i,
    }) => {
      const [o] = kt("Weather Component Error"),
        c =
          e?.type === b.GCEnhancementType.BannerWeather ||
          e?.type === b.GCEnhancementType.OutstreamWeather,
        [l, u, p, h] = Em(
          t || Ht.ENGLISH,
          c,
          e?.payload.coordinates,
          e?.payload.units
        ),
        m = !o && !p;
      return (
        A(() => {
          if (!h)
            if (o || p) {
              const f = o ?? p;
              n({
                error: new Error(f?.message ?? "Weather data is not available"),
                data: f,
              });
            } else a({ enhancementType: e.type });
        }, [l, p, h, o, n, a]),
        d(lt, {
          className: $("str-enhanced-info", m && "weather"),
          enhancement: e,
          enhancementLoaded: m,
          language: t,
          onClick: r,
          onError: n,
          onLoad: a,
          publisherStyles: i,
          children:
            !h &&
            l &&
            d(lm, {
              icons: u,
              children: d("div", {
                className: "str-weather",
                children: c
                  ? d(mm, { weatherData: l })
                  : d(pm, { weatherData: l }),
              }),
            }),
        })
      );
    };
  function Mo(e) {
    const t = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(e);
    return t
      ? { r: parseInt(t[1], 16), g: parseInt(t[2], 16), b: parseInt(t[3], 16) }
      : null;
  }
  function dt(e, t, r) {
    const n = (a) => {
      const i = Math.round(a).toString(16);
      return i.length === 1 ? "0" + i : i;
    };
    return `#${n(e)}${n(t)}${n(r)}`;
  }
  function km(e, t, r) {
    const [n, a, i] = [e / 255, t / 255, r / 255],
      [o, c, l] = [n, a, i].map((u) =>
        u <= 0.03928 ? u / 12.92 : Math.pow((u + 0.055) / 1.055, 2.4)
      );
    return 0.2126 * o + 0.7152 * c + 0.0722 * l;
  }
  function Im(e) {
    const t = Mo(e);
    return t ? (km(t.r, t.g, t.b) < 0.5 ? "#ffffff" : "#000000") : "#ffffff";
  }
  function Cm(e, t = 0.4) {
    const r = Mo(e);
    if (!r) return "#ffffff";
    const n = Math.round(r.r + (255 - r.r) * t),
      a = Math.round(r.g + (255 - r.g) * t),
      i = Math.round(r.b + (255 - r.b) * t);
    return dt(n, a, i);
  }
  const Bo = { timeout: 2e3, sampleSize: 100, minConfidence: 0.5 };
  function Lo() {
    const e = ['iframe[data-testid="adm-iframe"]', "iframe.str-thumbnail"];
    for (const t of e) {
      const r = document.querySelector(t);
      if (r && Sm(r)) return r;
    }
    return null;
  }
  function Sm(e) {
    try {
      return e.contentDocument !== null;
    } catch {
      return !1;
    }
  }
  function Tm(e, t, r) {
    const n = e / 255,
      a = t / 255,
      i = r / 255,
      o = Math.max(n, a, i),
      c = Math.min(n, a, i),
      l = (o + c) / 2;
    if (o === c) return { h: 0, s: 0, l };
    const u = o - c,
      p = l > 0.5 ? u / (2 - o - c) : u / (o + c);
    let h;
    return (
      o === n
        ? (h = ((a - i) / u + (a < i ? 6 : 0)) * 60)
        : o === a
        ? (h = ((i - n) / u + 2) * 60)
        : (h = ((n - a) / u + 4) * 60),
      { h, s: p, l }
    );
  }
  function wn(e, t) {
    try {
      const r = document.createElement("canvas"),
        n = r.getContext("2d");
      if (!n) return null;
      const a = Math.min(1, t / Math.max(e.width, e.height));
      (r.width = e.width * a),
        (r.height = e.height * a),
        n.drawImage(e, 0, 0, r.width, r.height);
      const o = n.getImageData(0, 0, r.width, r.height).data,
        c = {};
      let l = 0;
      const u = 4;
      for (let w = 0; w < o.length; w += u * 4) {
        const y = o[w],
          v = o[w + 1],
          x = o[w + 2];
        if (
          o[w + 3] < 128 ||
          (y > 240 && v > 240 && x > 240) ||
          (y < 15 && v < 15 && x < 15)
        )
          continue;
        const { h: _, s: k, l: T } = Tm(y, v, x);
        if (k < 0.15 || T < 0.08 || T > 0.92) continue;
        l++;
        const P = Math.floor(_ / 30) * 30;
        c[P] || (c[P] = { count: 0, totalR: 0, totalG: 0, totalB: 0 }),
          (c[P].count += k),
          (c[P].totalR += y * k),
          (c[P].totalG += v * k),
          (c[P].totalB += x * k);
      }
      if (l < 10) return Vo(o, u);
      let p = 0,
        h = null;
      for (const w of Object.values(c)) w.count > p && ((p = w.count), (h = w));
      if (!h || p === 0) return Vo(o, u);
      const m = Math.round(h.totalR / h.count),
        f = Math.round(h.totalG / h.count),
        g = Math.round(h.totalB / h.count);
      return dt(m, f, g);
    } catch {
      return null;
    }
  }
  function Vo(e, t) {
    const r = {};
    for (let i = 0; i < e.length; i += t * 4) {
      const o = e[i],
        c = e[i + 1],
        l = e[i + 2];
      if (
        e[i + 3] < 128 ||
        (o > 240 && c > 240 && l > 240) ||
        (o < 15 && c < 15 && l < 15)
      )
        continue;
      const p = Math.floor(o / 32) * 32,
        h = Math.floor(c / 32) * 32,
        m = Math.floor(l / 32) * 32,
        f = `${p},${h},${m}`;
      r[f] = (r[f] || 0) + 1;
    }
    let n = 0,
      a = null;
    for (const [i, o] of Object.entries(r))
      if (o > n) {
        n = o;
        const [c, l, u] = i.split(",").map(Number);
        a = dt(c, l, u);
      }
    return a;
  }
  function Ho(e) {
    const r = window
      .getComputedStyle(e)
      .backgroundColor.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*[\d.]+)?\)/);
    if (r) {
      const [, n, a, i] = r.map(Number);
      return (n > 240 && a > 240 && i > 240) || (n === 0 && a === 0 && i === 0)
        ? null
        : dt(n, a, i);
    }
    return null;
  }
  function $o(e, t) {
    const r = e.getBoundingClientRect(),
      n = t.getBoundingClientRect(),
      a = r.width / (n.width || 1),
      i = r.height / (n.height || 1);
    if (a > 0.15 || i > 0.15) return !1;
    const o = 0.2,
      c = (r.left - n.left) / (n.width || 1) < o,
      l = (n.right - r.right) / (n.width || 1) < o,
      u = (r.top - n.top) / (n.height || 1) < o,
      p = (n.bottom - r.bottom) / (n.height || 1) < o;
    return (c || l) && (u || p);
  }
  function Om(e) {
    const t = Array.from(e.querySelectorAll("path, rect, circle, polygon")),
      r = {};
    for (const a of t) {
      const i = a.getAttribute("fill") || window.getComputedStyle(a).fill;
      if (i && i !== "none" && i !== "transparent") {
        const o = i.match(/#([0-9a-f]{6})|rgba?\((\d+),\s*(\d+),\s*(\d+)/i);
        if (o) {
          let c;
          if (o[1]) c = `#${o[1]}`;
          else if (o[2]) {
            const l = parseInt(o[2]),
              u = parseInt(o[3]),
              p = parseInt(o[4]);
            if (
              (l > 240 && u > 240 && p > 240) ||
              (l === 0 && u === 0 && p === 0)
            )
              continue;
            c = dt(l, u, p);
          } else continue;
          r[c] = (r[c] || 0) + 1;
        }
      }
    }
    const n = Object.entries(r).sort((a, i) => i[1] - a[1]);
    return n.length === 0 ? null : n[0][0];
  }
  async function Rm(e = {}) {
    const t = { ...Bo, ...e };
    try {
      const r = Lo();
      if (!r) return { color: "#2d2d2d", confidence: 0, source: "fallback" };
      await Nm(r, t.timeout);
      const n = r.contentDocument;
      if (!n) return { color: "#2d2d2d", confidence: 0, source: "fallback" };
      const i = Array.from(n.querySelectorAll("img")).filter((p) => {
        if (
          p.naturalWidth <= 2 ||
          p.naturalHeight <= 2 ||
          p.width <= 2 ||
          p.height <= 2
        )
          return !1;
        const h = n.defaultView?.getComputedStyle(p);
        return !(
          h?.display === "none" ||
          h?.visibility === "hidden" ||
          $o(p, n.body)
        );
      });
      if (i.length > 0) {
        i.sort((p, h) => h.width * h.height - p.width * p.height);
        for (const p of i)
          if (p.complete && p.naturalWidth > 0) {
            const h = wn(p, t.sampleSize);
            if (h) return { color: h, confidence: 0.8, source: "banner-image" };
            const m = await Fo(p.src, t.sampleSize);
            if (m) return { color: m, confidence: 0.8, source: "banner-image" };
          }
      }
      const o = Array.from(n.querySelectorAll("svg"));
      for (const p of o) {
        if ($o(p, n.body)) continue;
        const h = Om(p);
        if (h) return { color: h, confidence: 0.75, source: "banner-element" };
      }
      const c = Ho(n.body);
      if (c) return { color: c, confidence: 0.6, source: "banner-background" };
      const l = Array.from(n.body.querySelectorAll("body > *, body > * > *")),
        u = [];
      for (const p of l) {
        const h = Ho(p);
        if (h) {
          const m = p.getBoundingClientRect();
          let f = m.width * m.height;
          if (f === 0) {
            const g = window.getComputedStyle(p),
              w = parseFloat(g.width) || 0,
              y = parseFloat(g.height) || 0;
            f = w * y;
          }
          f > 0 && u.push({ element: p, color: h, area: f });
        }
      }
      return (
        u.sort((p, h) => h.area - p.area),
        u.length > 0
          ? { color: u[0].color, confidence: 0.5, source: "banner-element" }
          : { color: "#2d2d2d", confidence: 0, source: "fallback" }
      );
    } catch {
      return { color: "#2d2d2d", confidence: 0, source: "fallback" };
    }
  }
  async function Fo(e, t) {
    return new Promise((r) => {
      const n = new Image();
      n.crossOrigin = "anonymous";
      const a = setTimeout(() => {
        r(null);
      }, 3e3);
      (n.onload = () => {
        clearTimeout(a), r(wn(n, t));
      }),
        (n.onerror = () => {
          clearTimeout(a), r(null);
        });
      const i = e.includes("?") ? "&" : "?";
      n.src = `${e}${i}__cors=1`;
    });
  }
  async function Nm(e, t) {
    const r = Date.now() + t;
    await new Promise((i, o) => {
      const c = () => {
        if (Date.now() > r) {
          i();
          return;
        }
        try {
          const l = e.contentDocument;
          if (l && l.readyState === "complete") {
            i();
            return;
          }
        } catch (l) {
          o(l);
          return;
        }
        setTimeout(c, 100);
      };
      c();
    });
    const n = e.contentDocument;
    if (!n) return;
    const a = 150;
    await new Promise((i) => {
      const o = () => {
        if (Date.now() > r) {
          i();
          return;
        }
        const l = Array.from(n.querySelectorAll("img")).filter((u) => {
          if (u.width <= 2 || u.height <= 2) return !1;
          const p = n.defaultView?.getComputedStyle(u);
          return !(p?.display === "none" || p?.visibility === "hidden");
        });
        if (l.length > 0 && l.every((u) => u.complete && u.naturalWidth > 0)) {
          i();
          return;
        }
        setTimeout(o, a);
      };
      o();
    });
  }
  function Dm(e, t = {}, r = 15e3) {
    const n = { ...Bo, ...t };
    let a = null,
      i = !1;
    const o = () => {
        (i = !0), a?.disconnect();
      },
      c = setTimeout(o, r),
      l = async (m) => {
        if (
          i ||
          m.width <= 2 ||
          m.height <= 2 ||
          m.naturalWidth <= 2 ||
          m.naturalHeight <= 2
        )
          return;
        const f = wn(m, n.sampleSize);
        if (f) {
          e({ color: f, confidence: 0.8, source: "banner-image" }),
            clearTimeout(c),
            o();
          return;
        }
        const g = await Fo(m.src, n.sampleSize);
        !i &&
          g &&
          (e({ color: g, confidence: 0.8, source: "banner-image" }),
          clearTimeout(c),
          o());
      },
      u = Lo();
    if (!u) return clearTimeout(c), o;
    const p = u.contentDocument;
    if (!p) return clearTimeout(c), o;
    (a = new MutationObserver((m) => {
      if (!i) {
        for (const f of m)
          for (const g of Array.from(f.addedNodes))
            if (
              (g instanceof HTMLImageElement &&
                (g.complete && g.naturalWidth > 0
                  ? l(g)
                  : g.addEventListener("load", () => l(g), { once: !0 })),
              g instanceof HTMLElement)
            ) {
              const w = g.querySelectorAll("img");
              for (const y of Array.from(w))
                y.complete && y.naturalWidth > 0
                  ? l(y)
                  : y.addEventListener("load", () => l(y), { once: !0 });
            }
      }
    })),
      a.observe(p.body, { childList: !0, subtree: !0 });
    const h = Array.from(p.querySelectorAll("img"));
    for (const m of h)
      m.width <= 2 ||
        m.height <= 2 ||
        m.complete ||
        m.addEventListener("load", () => l(m), { once: !0 });
    return () => {
      clearTimeout(c), o();
    };
  }
  const Pm = "gc-exp-headline-alt";
  function zm(e) {
    const [t, r] = V(null),
      n = !!e && e.includes(Pm);
    if (
      (A(() => {
        if (!n) return;
        let a = !0,
          i = null;
        return (
          (async () => {
            try {
              const c = await Rm({ timeout: 3e3, minConfidence: 0.5 });
              if (a && c.confidence >= 0.5) {
                r(c.color);
                return;
              }
            } catch {}
            a &&
              (i = Dm((c) => {
                a && c.confidence >= 0.5 && r(c.color);
              }));
          })(),
          () => {
            (a = !1), i?.();
          }
        );
      }, [n]),
      !n || !t)
    )
      return {
        textColor: void 0,
        secondaryColor: void 0,
        backgroundColor: void 0,
      };
    try {
      const a = Cm(t, 0.4);
      return { textColor: Im(t), secondaryColor: a, backgroundColor: t };
    } catch {
      return {
        textColor: void 0,
        secondaryColor: void 0,
        backgroundColor: void 0,
      };
    }
  }
  function Um(e = Math.random) {
    const t = (n, a) => `${Math.round(n + e() * (a - n))}%`,
      r = (n, a) => `${Math.round(n + e() * (a - n))}px`;
    return {
      "--aurora-delay-a": `${-(e() * 18).toFixed(1)}s`,
      "--aurora-delay-b": `${-(e() * 13).toFixed(1)}s`,
      "--aurora-p1x": t(10, 90),
      "--aurora-p1y": t(10, 90),
      "--aurora-p2x": t(10, 90),
      "--aurora-p2y": t(10, 90),
      "--aurora-p3x": t(10, 90),
      "--aurora-p3y": t(10, 90),
      "--aurora-edge1": t(40, 65),
      "--aurora-edge2": t(35, 60),
      "--aurora-edge3": t(35, 60),
      "--aurora-blur-a": r(6, 16),
      "--aurora-blur-b": r(8, 20),
    };
  }
  function Mm(e) {
    const { textColor: t, secondaryColor: r, backgroundColor: n } = zm(e),
      a = !!n;
    return ce(() => {
      if (a)
        return {
          "--headlineTextColor": t,
          "--headlineSecondaryBgColor": r,
          "--headlinePrimaryBgColor": n,
          ...Um(),
        };
    }, [a, t, r, n]);
  }
  const Bm = ({
      assets: e,
      enhancement: t,
      isi: r,
      language: n,
      onClick: a,
      onError: i,
      onLoad: o,
      publisherStyles: c,
      className: l,
    }) => {
      const u = Mm(l);
      return d(lt, {
        assets: e,
        className: $("str-enhanced-info", `str-headline-${t.type}`, l),
        enhancement: t,
        enhancementLoaded: !0,
        onClick: a,
        onError: i,
        onLoad: o,
        publisherStyles: c,
        language: n,
        style: u,
        children: d(Do, {
          publisherStyles: c,
          assets: e,
          enhancement: t,
          isi: r,
          onLoad: o,
          onClick: a,
          onError: i,
        }),
      });
    },
    Go = (e) => {
      const t = new Date(),
        r = new Date(e);
      let n = Math.floor((r.getTime() - t.getTime()) / 1e3);
      const a = Math.floor(n / (3600 * 24));
      n %= 3600 * 24;
      const i = Math.floor(n / 3600);
      n %= 3600;
      const o = Math.floor(n / 60);
      n %= 60;
      const c = n;
      return {
        days: String(a).padStart(2, "0"),
        hours: String(i).padStart(2, "0"),
        minutes: String(o).padStart(2, "0"),
        seconds: String(c).padStart(2, "0"),
      };
    },
    Lm = ({ countdown: e, timestampColor: t, autostart: r }) => {
      const { t: n } = Oe(),
        a = an(Go(e.endTime));
      A(() => {
        if (!r) return;
        const m = setInterval(() => (a.value = Go(e.endTime)), 1e3);
        return () => clearInterval(m);
      }, [e, a, a.value]);
      const { days: o, hours: c, minutes: l, seconds: u } = a.value,
        p = () =>
          d("div", {
            children: [
              d("span", { style: { color: t }, children: ":" }),
              d("label", {}),
            ],
          });
      return d("div", {
        className: "str-countdown-time",
        "data-testid": "countdown-time",
        children: [
          o &&
            d(G, {
              children: [
                d("div", {
                  "data-testid": "days",
                  children: [
                    d("span", { style: { color: t }, children: o }),
                    d("label", { children: n(s.DAYS) }),
                  ],
                }),
                d(p, {}),
              ],
            }),
          c &&
            d(G, {
              children: [
                d("div", {
                  "data-testid": "hours",
                  children: [
                    d("span", { style: { color: t }, children: c }),
                    d("label", { children: n(s.HOURS) }),
                  ],
                }),
                d(p, {}),
              ],
            }),
          d("div", {
            "data-testid": "minutes",
            children: [
              d("span", { style: { color: t }, children: l }),
              d("label", { children: n(s.MINUTES_ABBREVIATION) }),
            ],
          }),
          d(p, {}),
          d("div", {
            "data-testid": "seconds",
            children: [
              d("span", { style: { color: t }, children: u }),
              d("label", { children: n(s.SECONDS_ABBREVIATION) }),
            ],
          }),
        ],
      });
    },
    Vm = (e) => {
      for (const t of e) {
        const r = t.startTime ? new Date(Date.parse(t.startTime)) : null,
          n = new Date(Date.parse(t.endTime));
        if ($m(r) && !Hm(n)) return t;
      }
      return null;
    },
    Hm = (e) => e < new Date(),
    $m = (e) => (e ? e < new Date() : !0),
    Fm = ({
      assets: e,
      enhancement: t,
      language: r,
      layout: n = null,
      onClick: a,
      onError: i,
      onLoad: o,
      publisherStyles: c,
    }) => {
      const l = O(null),
        [u, p] = V(void 0),
        [h, m] = V(void 0);
      A(() => {
        if (!t) return;
        const E = Vm(t.payload.configs);
        p(E),
          m(!!E),
          E
            ? o({ enhancementType: t.type })
            : i({
                error: new Error("No active countdown found"),
                data: t.payload.configs,
              });
      }, [t]),
        A(() => {
          const E = l.current;
          if (!u || !E) return;
          const _ = E.closest("[data-str-arid]");
          _ &&
            _ instanceof HTMLElement &&
            (_.style.backgroundColor = u.backgroundColor || "#FFFFFF");
        }, [u]);
      const w = u?.cta,
        y = u?.textColor || "#000000",
        v = u?.timestampColor || "#000000",
        x = u?.backgroundColor || "#FFFFFF";
      return d(lt, {
        assets: e,
        className: "str-enhanced-info",
        enhancement: t,
        enhancementLoaded: h,
        language: r,
        onClick: a,
        onError: i,
        onLoad: o,
        children:
          u &&
          d(G, {
            children: [
              d("div", {
                className: "str-countdown-container",
                "data-testid": "countdown-container",
                style: { backgroundColor: x },
                ref: l,
                onClick: () =>
                  a({ enhancementType: t.type, eventType: ie.CONTENT }),
                children: d("div", {
                  className: $(
                    "str-countdown-content",
                    n === "horizontal" && "nowrap"
                  ),
                  "data-testid": "countdown-content",
                  style: { color: y },
                  children: [
                    d("div", {
                      className: "str-countdown-cta",
                      "data-testid": "countdown-cta",
                      children: d("span", { children: w }),
                    }),
                    d(Lm, {
                      autostart: t?.enhancement_version_id !== "test-evid",
                      countdown: u,
                      timestampColor: v,
                    }),
                  ],
                }),
              }),
              d(bn, { assets: e, enhancement: t, publisherStyles: c }),
            ],
          }),
      });
    },
    jo = 3,
    qt = 5,
    Gm = ({
      assets: e,
      captionInnerCreativeId: t,
      currentCaption: r,
      enhancement: n,
      innerCreativeIds: a,
      language: i,
      onClick: o,
      onError: c,
      onLoad: l,
      publisherStyles: u,
      videoElement: p,
    }) => {
      const h = n.payload?.blurredBackground ?? !1,
        m = O(null),
        [f, g] = V([""]),
        [w, y] = V(void 0),
        [v, x] = V(!1);
      return (
        A(() => {
          if (!a || !t) return;
          const E = a.includes(t);
          y(E), E && l({ enhancementType: n.type });
        }, [t, a]),
        A(() => {
          r
            ? r !== f[f.length - 1] &&
              g((E) => {
                const _ = [...E, r];
                return _.length > qt ? _.slice(-qt) : _;
              })
            : f[f.length - 1] !== "" &&
              g((E) => {
                const _ = [...E, ""];
                return _.length > qt ? _.slice(-qt) : _;
              });
        }, [r, f]),
        A(() => {
          if (!h) return;
          const { current: E } = m;
          if (!p || !E) return;
          const { clientHeight: _, clientWidth: k } = p;
          let T;
          const P = () => {
            if (p.currentTime === 0 && T && v) {
              cancelAnimationFrame(T);
              return;
            }
            p.currentTime > 0 && x(!0);
            const W = E.getContext("2d");
            if (!W || !p) return;
            if (p.parentElement?.style.display === "none") {
              cancelAnimationFrame(T);
              return;
            }
            const Y = k * jo,
              ye = _ * jo;
            (E.width = Y),
              (E.height = ye),
              W.drawImage(p, 0, 0, Y, ye),
              (T = requestAnimationFrame(P));
          };
          return (
            P(),
            () => {
              cancelAnimationFrame(T);
            }
          );
        }, [h, p]),
        d(lt, {
          assets: e,
          className: $(
            "str-enhanced-info str-enhanced-captions",
            !h && "str-solid-background"
          ),
          enhancement: n,
          enhancementLoaded: w,
          language: i,
          onClick: o,
          onError: c,
          onLoad: l,
          children: [
            d("div", {
              className: "str-captions-background",
              children:
                h && d("canvas", { className: "str-caption-canvas", ref: m }),
            }),
            d("div", {
              className: "str-text str-captions",
              children: f.map((E, _) =>
                d(
                  "div",
                  {
                    className: $(
                      "str-caption-container",
                      _ === f.length - 1
                        ? "str-current-caption"
                        : "str-prev-caption"
                    ),
                    children: d("span", { "data-shadow": E, children: E }),
                  },
                  _
                )
              ),
            }),
            d(bn, {
              assets: e,
              enhancement: n,
              publisherStyles: u,
              hideCallToAction: !0,
            }),
          ],
        })
      );
    };
  function jm(
    e,
    t,
    {
      panelSelector: r = ".str-enhanced-info-wrapper",
      openClass: n = "is-open",
      durationMs: a = 500,
      threshold: i = 0.5,
      alwaysOpen: o = !1,
    } = {}
  ) {
    const c = O(!1),
      l = O(null);
    A(() => {
      const u = e.current,
        p = u?.querySelector(r);
      if (!t || !u || !p) return;
      const h = () => {
          l.current != null && (clearTimeout(l.current), (l.current = null));
        },
        m = () => {
          c.current ||
            (Bi.value && ((c.current = !0), ne.value?.trackOverlayActive()));
        },
        f = () => {
          h();
          const v = Math.max(0, a * i);
          l.current = window.setTimeout(() => {
            m();
          }, v);
        },
        g = () => {
          p.classList.add(n), f();
        },
        w = () => {
          h(), p.classList.remove(n);
        };
      if (o)
        return (
          g(),
          () => {
            h(), p.classList.remove(n);
          }
        );
      const y = () => {
        p.classList.contains(n) ? w() : g();
      };
      return (
        u.addEventListener("mouseenter", g),
        u.addEventListener("mouseleave", w),
        u.addEventListener("touchstart", y, { passive: !0 }),
        () => {
          h(),
            u.removeEventListener("mouseenter", g),
            u.removeEventListener("mouseleave", w),
            u.removeEventListener("touchstart", y),
            p.classList.remove(n);
        }
      );
    }, [t, e, r, n, a, i, o]);
  }
  const qo = (e) => {
      if (!e) return;
      const t = e.toLowerCase();
      return Object.values(Ht).find(
        (r) => r === t || r === t.replace("_", "-")
      );
    },
    qm = (e) => {
      if (
        e &&
        "language" in e &&
        typeof e.language == "string" &&
        e.language !== ""
      )
        return qo(e.language);
    },
    Wm = (e) => {
      if (!e || !e.creative || !e.creative.language) return;
      const t = e.creative.language.toString();
      return qo(t);
    },
    Ym = (e, t) => qm(t?.payload) || Wm(e),
    ut = (e) => {
      const t = st().enhancement || void 0,
        r = go().styles || void 0,
        n = H() || void 0,
        a = Q() || void 0,
        i = he() || void 0,
        o = le(),
        c = Ym(a, t);
      return {
        assets: n,
        enhancement: t,
        language: c,
        onError: (p) => {
          R(p.error, {
            scope: o,
            context: "template/enhancement-error",
            payloadId: a?.id || "",
            enhancement: t,
            errorPayload: p.data,
          });
        },
        onLoad: (p) => {
          (Bi.value = !0),
            i?.trackIsEnhanced(p.enhancementType, "", p.fallback);
        },
        payload: a,
        publisherStyles: r,
      };
    },
    Wo = new Map();
  function pt(e, t) {
    for (const r of e) Wo.set(r, t);
  }
  function Xm(e) {
    return e === void 0 ? void 0 : Wo.get(e);
  }
  const Yo = () => {
    const e = ae(co) || void 0,
      {
        assets: t,
        enhancement: r,
        language: n,
        onError: a,
        onLoad: i,
        publisherStyles: o,
      } = ut(),
      c = r?.payload?.blurredBackground === !0,
      l = e?.creative?.isi?.text
        ? {
            text: e.creative.isi.text,
            header: e.creative.behaviors.isiHeadlineOverride,
            subheader: e.creative.behaviors.isiCustomSub,
            autoscroll: e.creative.isi.autoscroll,
          }
        : void 0;
    return r
      ? d(Bm, {
          className: $(c && "gc-exp-headline-alt"),
          assets: t,
          enhancement: r,
          isi: l,
          language: n,
          onClick: () => {},
          onError: a,
          onLoad: i,
          publisherStyles: o,
        })
      : null;
  };
  pt(
    [b.GCEnhancementType.BannerHeadline, b.GCEnhancementType.OutstreamHeadline],
    Yo
  );
  const Km = (e) => en.has(e),
    Xo = ({ onEnhancementClick: e }) => {
      const {
          assets: t,
          enhancement: r,
          language: n,
          onError: a,
          onLoad: i,
          publisherStyles: o,
        } = ut(),
        c = he(),
        l = (h) => {
          if (c)
            switch (h.eventType) {
              case ie.ENGAGEMENT:
                c.trackEnhancedEngagementClick();
                break;
              case ie.CONTENT:
                c.trackEnhancedContentClick();
                break;
              case ie.PRODUCTCARD:
                c.trackProductCardClick(h.productId);
                break;
              case ie.SHOPPABLECAROUSEL_ARROW:
                c.trackShoppableCarouselArrowClick();
                break;
              case ie.CLICKTHROUGH:
                if ((c.trackEnhancedContentClick(), e)) {
                  const m = r?.payload.redirectUrl;
                  e({ event: new MouseEvent("click"), redirectUrl: m });
                }
                break;
            }
        };
      return r
        ? d(sm, {
            assets: t,
            enhancement: r,
            language: n,
            onClick: l,
            onError: (h) => {
              h.isPageFailure || a(h), c?.trackEnhancementLoadFailure();
            },
            onLoad: i,
            onLifecycleChange: (h) => {
              if (c)
                switch (h) {
                  case q.Initialized:
                    c.trackRemoteInitialized();
                    break;
                  case q.HealthCheckOk:
                    c.trackRemoteHealthCheckOk();
                    break;
                  case q.HealthCheckFail:
                    c.trackRemoteHealthCheckFail();
                    break;
                }
            },
            publisherStyles: o,
            hasPreflight: Km(r.type),
          })
        : null;
    };
  pt(
    [
      b.GCEnhancementType.BannerSportsTicker,
      b.GCEnhancementType.OutstreamSportsTicker,
      b.GCEnhancementType.BannerBrandedHeadline,
      b.GCEnhancementType.OutstreamBrandedHeadline,
      b.GCEnhancementType.BannerShoppable,
      b.GCEnhancementType.OutstreamShoppable,
      b.GCEnhancementType.BannerShoppableOverlay,
      b.GCEnhancementType.BannerMedalCount,
      b.GCEnhancementType.OutstreamMedalCount,
      b.GCEnhancementType.BannerWorldTournament,
      b.GCEnhancementType.OutstreamWorldTournament,
      b.GCEnhancementType.BannerCustom,
      b.GCEnhancementType.OutstreamCustom,
      b.GCEnhancementType.BannerSofiaPulseSportsHeadlines,
      b.GCEnhancementType.BannerSofiaPulseQuiz,
      b.GCEnhancementType.BannerSofiaPulseBettingOdds,
      b.GCEnhancementType.BannerSofiaPulseStockTicker,
    ],
    Xo
  );
  const Qm = ({ onEnhancementClick: e }) => {
      const { enhancement: t } = st(),
        r = t?.payload;
      return r && "templateUrl" in r
        ? d(Xo, { onEnhancementClick: e })
        : d(Yo, {});
    },
    Jm = ({ isOpen: e, onEnhancementClick: t }) => {
      const r = ot(),
        n = Q(),
        { enhancement: a } = st(),
        i = O(null);
      if (!r && !n) return null;
      const o = Xm(a?.type);
      return d("div", {
        className: $("str-enhanced-info-wrapper", {
          "str-enhanced-info-wrapper__native": n?.creative.type === N.Native,
          "is-open": e,
        }),
        ref: i,
        children: o
          ? d(o, { onEnhancementClick: t })
          : d(Qm, { onEnhancementClick: t }),
      });
    },
    Zm = (e) =>
      !e || typeof e != "object"
        ? !1
        : "alwaysExpanded" in e && e.alwaysExpanded === !0,
    ef = ({
      adserverRequestId: e,
      children: t,
      className: r,
      creative: n,
      network: a,
      onEnhancementClick: i,
    }) => {
      const o = Q(),
        c = o?.enhancement || { type: "disabled" },
        l = O(null);
      A(() => {
        !o || !Te(o.creative, c) || (c.type !== "disabled" && qc());
      }, [c, o, e]);
      const u = c.type === b.GCEnhancementType.BannerShoppableOverlay,
        p = u && Zm(c.payload),
        h =
          "type" in n
            ? n.type === N.Native
              ? n.nativeType
              : n.type
            : "unknown";
      return (
        jm(l, u, { durationMs: 500, threshold: 0.5, alwaysOpen: p }),
        em(l, ".str-enhanced-info-wrapper", u && !p ? "B" : void 0),
        d("div", {
          ref: l,
          className: $("str-adunit", "str-template", `str-${h}`, r, {
            "str-adunit-overlay": u,
          }),
          children: [
            t,
            d(Jm, { isOpen: p, onEnhancementClick: i }),
            d(Fe, { creative: n, network: a }),
          ],
        })
      );
    },
    tf = ({ creative: e, network: t, children: r }) =>
      d("div", {
        class:
          "str-adunit str-adunit-banner-only str-compiled-template-unenhanced",
        "data-testid": "unenhanced-adunit",
        children: [r, d(Fe, { creative: e, network: t })],
      }),
    yn = yo((e, t) => {
      const [r] = kt(),
        n = O(null),
        { styles: a, error: i } = go(),
        o = Q(),
        c = le(),
        l = ce(() => _e(c, re.Enhancement), [c]);
      A(() => {
        if (n.current === null) return;
        const E = n.current.base;
        E && Ql(E.parentElement);
      }, [n]),
        A(() => {
          if (i) {
            R(i, { scope: c, adserverRequestId: o?.id });
            return;
          }
          !a || !a.fontFamily || Rp(a.fontFamily);
        }, [a, i]);
      const {
          adserverRequestId: u,
          creative: p,
          network: h,
          country: m,
          className: f,
          children: g,
        } = e,
        w = {
          adserverRequestId: u,
          creative: p,
          network: h,
          className: f,
          country: m,
          children: g,
        },
        y = { ...w, children: d(Dr, { scope: c, children: g }) },
        v = o?.creative.type,
        x = o && (Te(o.creative, o?.enhancement) || v === N.Native) && !r;
      return d("div", {
        "data-testid": "str-compiled-template",
        className: "str-compiled-template",
        style: { width: "100%", height: "100%" },
        ref: t,
        children: x
          ? d(G, {
              ref: n,
              children: d(Dr, {
                scope: l,
                children: d(ef, {
                  ...y,
                  onEnhancementClick: e.onEnhancementClick,
                }),
              }),
            })
          : d(tf, { ...w }),
      });
    }),
    Ko = (e) => (t) => {
      if (t === "requested") {
        e?.trackPublisherStylingRequested();
        return;
      }
      e?.trackPublisherStylingLoaded();
    },
    rf = [
      b.GCEnhancementType.BannerSportsTicker,
      b.GCEnhancementType.OutstreamSportsTicker,
      b.GCEnhancementType.BannerShoppable,
      b.GCEnhancementType.OutstreamShoppable,
    ],
    nf = (e) => (e ? rf.includes(e.type) : !1),
    af = [
      b.GCEnhancementType.BannerMedalCount,
      b.GCEnhancementType.BannerShoppable,
      b.GCEnhancementType.BannerShoppableOverlay,
      b.GCEnhancementType.BannerSportsTicker,
      b.GCEnhancementType.OutstreamMedalCount,
      b.GCEnhancementType.OutstreamShoppable,
      b.GCEnhancementType.OutstreamSportsTicker,
      b.GCEnhancementType.BannerBrandedHeadline,
      b.GCEnhancementType.OutstreamBrandedHeadline,
      b.GCEnhancementType.BannerWorldTournament,
      b.GCEnhancementType.OutstreamWorldTournament,
      b.GCEnhancementType.BannerCustom,
      b.GCEnhancementType.OutstreamCustom,
    ],
    of = (e) => af.some((t) => t === e.type),
    Qo = {
      "str-banner-clickblocker": "_str-banner-clickblocker_1414n_1",
      "str-banner-clickblocker-thumbnail":
        "_str-banner-clickblocker-thumbnail_1414n_7",
    },
    sf = (e) => {
      const [t, r] = V({
          width: "100%",
          height: "100%",
          offsetTop: "0",
          offsetLeft: "0",
        }),
        { onClick: n, showClickBlocker: a, isBannerClickable: i } = e,
        { enhancement: o } = st();
      A(() => {
        e.iframe.current && c(e.iframe.current);
      }, [e.iframe]);
      const c = (u) => {
        u.addEventListener("load", () => {
          try {
            const h = u.contentWindow?.document?.body?.children
              ?.item(0)
              ?.getBoundingClientRect();
            h &&
              r({
                width: `${h.width}px`,
                height: `${h.height}px`,
                offsetTop: `${h.top}px`,
                offsetLeft: `${h.left}px`,
              });
          } catch {}
        });
      };
      if (!i.value || !a.value || !e.enableClickExtraction || (o && of(o)))
        return null;
      const l = nf(o);
      return d(G, {
        children: [
          !l &&
            d("div", {
              "data-testid": "str-banner-clickblocker",
              onClick: n,
              className: `${Qo["str-banner-clickblocker"]}`,
            }),
          d("div", {
            "data-testid": "str-thumbnail-clickblocker",
            onClick: n,
            className: `${Qo["str-banner-clickblocker-thumbnail"]}`,
            "data-str-thumbnail": !0,
            style: {
              width: t.width,
              height: t.height,
              top: t.offsetTop,
              left: t.offsetLeft,
            },
          }),
        ],
      });
    };
  function cf({
    inViewPercentage: e,
    outOfViewPercentage: t,
    inViewCallback: r,
    outOfViewCallback: n,
  }) {
    if (typeof IntersectionObserver > "u") return null;
    const a = (i, o) => {
      const [c] = i;
      r && c.intersectionRatio >= e && r(),
        n && c.intersectionRatio <= t && n();
    };
    return new IntersectionObserver(a, { threshold: [t, e] });
  }
  function lf(e, t, r, n, a, i, o, c) {
    e.forEach((l) => {
      const { width: u, height: p } = l.boundingClientRect,
        { width: h, height: m } = l.intersectionRect,
        f = Math.min(u, h),
        g = Math.min(p, m),
        w = f * g;
      w >= n && !document.hidden
        ? (r.current =
            o &&
            window.setTimeout(() => {
              o();
            }, i))
        : r.current && (window.clearTimeout(r.current), (r.current = void 0)),
        c && w <= a && c();
    });
  }
  function df({
    element: e,
    timeoutIdRef: t,
    inViewPixels: r,
    outOfViewPixels: n,
    inViewTime: a = 1e3,
    inViewCallback: i,
    outOfViewCallback: o,
  }) {
    if (typeof IntersectionObserver > "u") return null;
    const c = (u, p) => lf(u, p, t, r, n, a, i, o);
    let l;
    return (
      e.clientHeight > 0
        ? (l = [n / e.clientHeight, r / e.clientHeight])
        : (l = [0, 1]),
      new IntersectionObserver(c, { threshold: l })
    );
  }
  function uf(e) {
    const t = cf(e);
    return t?.observe(e.element), t;
  }
  function pf(e) {
    const t = df(e);
    return t?.observe(e.element), t;
  }
  function Wt(e) {
    if ("inViewPercentage" in e || "outOfViewPercentage" in e) return uf(e);
    if ("inViewPixels" in e || "outOfViewPixels" in e) return pf(e);
    throw new Error(
      "inViewPercentage/outOfViewPercentage or inViewPixels/outOfViewPixels must be provided"
    );
  }
  var ke = ((e) => (
    (e.Standard = "standard"),
    (e.MRAID = "mraid"),
    (e.OMID = "omid"),
    (e.OnePixel = "onepx"),
    (e.IabViewable = "iabViewable"),
    (e.Embedded = "embedded"),
    e
  ))(ke || {});
  const hf = 100,
    mf = () =>
      /iPad|iPhone|iPod/.test(navigator.userAgent) ||
      (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1),
    ff = ({ iframe: e, onClick: t, focusWindow: r = window }) => {
      const n = e.ownerDocument,
        a = !mf();
      let i = e.matches(":hover"),
        o = !1,
        c,
        l;
      const u = (v) => {
          n.activeElement === e &&
            n.hasFocus() &&
            (v || !o) &&
            (i || !a ? t() : r.focus()),
            (o = n.activeElement === e);
        },
        p = () => {
          c !== void 0 && clearTimeout(c), (c = setTimeout(() => u(!0)));
        },
        h = () => {
          l ?? (l = setInterval(() => u(!1), hf));
        },
        m = () => {
          l !== void 0 && (clearInterval(l), (l = void 0));
        },
        f = () => {
          (i = !0), h();
        },
        g = () => {
          u(!1), (i = !1), m();
        },
        w = () => {
          const { activeElement: v, body: x } = r.document;
          (!v || v === x) && r.focus();
        },
        y = () => {
          n.visibilityState === "visible" && w();
        };
      return (
        w(),
        i && h(),
        e.addEventListener("mouseenter", f),
        e.addEventListener("mouseleave", g),
        r.addEventListener("blur", p),
        n.addEventListener("visibilitychange", y),
        () => {
          c !== void 0 && clearTimeout(c),
            m(),
            e.removeEventListener("mouseenter", f),
            e.removeEventListener("mouseleave", g),
            r.removeEventListener("blur", p),
            n.removeEventListener("visibilitychange", y);
        }
      );
    },
    Yt = "omid_message_guid",
    Xt = "omid_message_method",
    Kt = "omid_message_version",
    Qt = "omid_message_args";
  class Re {
    static isValidSerializedMessage(t) {
      return (
        !!t &&
        t[Yt] !== void 0 &&
        t[Xt] !== void 0 &&
        t[Kt] !== void 0 &&
        typeof t[Yt] == "string" &&
        typeof t[Xt] == "string" &&
        typeof t[Kt] == "string" &&
        (t[Qt] === void 0 || t[Qt] !== void 0)
      );
    }
    static deserialize(t) {
      return new Re(t[Yt], t[Xt], t[Kt], t[Qt]);
    }
    constructor(t, r, n, a = void 0) {
      (this.guid = t), (this.method = r), (this.version = n), (this.args = a);
    }
    serialize() {
      const t = { [Yt]: this.guid, [Xt]: this.method, [Kt]: this.version };
      return this.args !== void 0 && (t[Qt] = this.args), t;
    }
  }
  function gf(...e) {
    bf(
      () => {
        throw new Error("Could not complete the test successfully - ", ...e);
      },
      () => console.error(...e)
    );
  }
  function bf(e, t) {
    typeof jasmine < "u" && jasmine
      ? e()
      : typeof console < "u" && console && console.error && t();
  }
  const Jt = { APP: "app", WEB: "web" },
    Zt = { NONE: "NONE", DIRECT: "DIRECT", POST_MESSAGE: "POST_MESSAGE" },
    vf = "1.6.8";
  function _f(e, t) {
    if (!t) throw new Error(`Value for ${e} is undefined, null or blank.`);
    if (typeof t != "string" && !(t instanceof String))
      throw new Error(`Value for ${e} is not a string.`);
    if (t.trim() === "") throw new Error(`Value for ${e} is empty string.`);
  }
  function wf(e, t) {
    if (!t) throw new Error(`${e} must not be truthy.`);
  }
  const yf = 3;
  function Jo(e) {
    return /\d+\.\d+\.\d+(-.*)?/.test(e);
  }
  function Zo(e, t) {
    const r = e.split("-")[0].split("."),
      n = t.split("-")[0].split(".");
    for (let a = 0; a < yf; a++) {
      const i = parseInt(r[a], 10),
        o = parseInt(n[a], 10);
      if (i > o) return !0;
      if (i < o) return !1;
    }
    return !0;
  }
  const es = "1.0.3";
  function xf(e, t) {
    return Jo(e) && Zo(e, es) ? t : JSON.stringify(t);
  }
  function Ef(e, t) {
    return Jo(e) && Zo(e, es)
      ? t || []
      : t && typeof t == "string"
      ? JSON.parse(t)
      : [];
  }
  function Af() {
    return typeof crypto < "u" && typeof crypto.getRandomValues == "function";
  }
  function kf() {
    return Af() ? If() : Cf();
  }
  function If() {
    const e = new Uint8Array(16);
    crypto.getRandomValues(e),
      (e[6] = (e[6] & 15) | 64),
      (e[8] = (e[8] & 63) | 128);
    const t = Array.from(e, (r) => r.toString(16).padStart(2, "0"));
    return `${t.slice(0, 4).join("")}-${t.slice(4, 6).join("")}-${t
      .slice(6, 8)
      .join("")}-${t.slice(8, 10).join("")}-${t.slice(10).join("")}`;
  }
  function Cf() {
    const e = (t) => {
      let r = (Math.random() * 16) | 0;
      return t ? ((r & 3) | 8).toString(16) : r.toString(16);
    };
    return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (t) =>
      e(t === "y")
    );
  }
  const Sf = "omid_v1_present",
    ts = "omid_v1_present_web",
    rs = "omid_v1_present_app";
  function Tf(e) {
    return { [Jt.APP]: rs, [Jt.WEB]: ts }[e];
  }
  function ns(e, t) {
    try {
      return !!(e.frames && e.frames[t]);
    } catch {
      return !1;
    }
  }
  function Of(e) {
    return [Sf, ts, rs].some((t) => ns(e, t));
  }
  function as(e) {
    for (const t of Object.values(Jt)) if (ns(e, Tf(t))) return t;
    return null;
  }
  function Rf() {
    if (typeof omidGlobal < "u" && omidGlobal) return omidGlobal;
    if (typeof global < "u" && global) return global;
    if (typeof window < "u" && window) return window;
    if (typeof globalThis < "u" && globalThis) return globalThis;
    {
      const e = Function("return this")();
      if (e) return e;
    }
    throw new Error("Could not determine global object context.");
  }
  const Ne = Rf();
  function is(e = void 0) {
    return e != null && typeof e.top < "u" && e.top != null;
  }
  function os(e) {
    if (e === Ne) return !1;
    try {
      if (typeof e.location.hostname > "u") return !0;
      if (Nf(e)) return !1;
    } catch {
      return !0;
    }
    return !1;
  }
  function Nf(e) {
    return e.x === "" || e.x !== "";
  }
  function ss(e = void 0) {
    return (
      typeof e > "u" && typeof window < "u" && window && (e = window),
      is(e) ? e : Ne
    );
  }
  function cs(e) {
    return is(e) ? e.top : Ne;
  }
  class ls {
    constructor(t = void 0) {
      (this.to = t), this.onMessage, (this.communicationType_ = Zt.NONE);
    }
    sendMessage(t, r) {}
    handleMessage(t, r) {
      this.onMessage && this.onMessage(t, r);
    }
    serialize(t) {
      return JSON.stringify(t);
    }
    deserialize(t) {
      return JSON.parse(t);
    }
    isDirectCommunication() {
      return this.communicationType_ === Zt.DIRECT;
    }
    isCrossOrigin() {}
  }
  class xn extends ls {
    constructor(t = void 0) {
      super(t),
        (this.communicationType_ = Zt.DIRECT),
        (this.handleExportedMessage =
          xn.prototype.handleExportedMessage.bind(this));
    }
    sendMessage(t, r = this.to) {
      if (!r)
        throw new Error(
          "Message destination must be defined at construction time or when sending the message."
        );
      r.handleExportedMessage(t.serialize(), this);
    }
    handleExportedMessage(t, r) {
      Re.isValidSerializedMessage(t) &&
        this.handleMessage(Re.deserialize(t), r);
    }
    isCrossOrigin() {
      return !1;
    }
  }
  class Df extends ls {
    static isCompatibleContext(t) {
      return !!(t && t.addEventListener && t.postMessage);
    }
    constructor(t, r = Ne) {
      super(r),
        (this.communicationType_ = Zt.POST_MESSAGE),
        t.addEventListener("message", (n) => {
          if (typeof n.data != "object") return;
          const a = n.data;
          if (!Re.isValidSerializedMessage(a)) return;
          const i = Re.deserialize(a);
          n.source && this.handleMessage(i, n.source);
        });
    }
    sendMessage(t, r = this.to) {
      if (!r)
        throw new Error(
          "Message destination must be defined at construction time or when sending the message."
        );
      r.postMessage(t.serialize(), "*");
    }
    isCrossOrigin() {
      return this.to ? os(this.to) : !0;
    }
  }
  const Pf = ["omid", "v1_VerificationServiceCommunication"],
    zf = ["omidVerificationProperties", "serviceWindow"];
  function ds(e, t) {
    return t.reduce((r, n) => r && r[n], e);
  }
  function Uf(e, t, r, n) {
    if (!os(t))
      try {
        const a = ds(t, r);
        if (a) return new xn(a);
      } catch {}
    return n(t) ? new Df(e, t) : null;
  }
  function Mf(e, t, r, n) {
    for (const a of t) {
      const i = Uf(e, a, r, n);
      if (i) return i;
    }
    return null;
  }
  function Bf(e, t = Of) {
    const r = [],
      n = ds(e, zf);
    return n && r.push(n), r.push(cs(e)), Mf(e, r, Pf, t);
  }
  const En = vf;
  function Lf() {
    const e = Ne.omid3p;
    return e &&
      typeof e.registerSessionObserver == "function" &&
      typeof e.addEventListener == "function"
      ? e
      : null;
  }
  class Vf {
    constructor(t) {
      if (
        ((this.callbackMap_ = {}),
        (this.communication = t || Bf(ss())),
        this.communication)
      )
        this.communication.onMessage = this.handleMessage_.bind(this);
      else {
        const n = Lf();
        n && (this.omid3p = n);
      }
      this.callbackMap_ = {};
      const r = Ne.omidVerificationProperties;
      this.injectionId_ = r ? r.injectionId : void 0;
    }
    isSupported() {
      return this.getEnvironment() === Jt.WEB && !this.injectionId_
        ? !1
        : !!(this.communication || this.omid3p);
    }
    getEnvironment() {
      const t = ss();
      return this.injectionSource() || as(t) || as(cs(t));
    }
    injectionSource() {
      const t = Ne.omidVerificationProperties;
      return t && t.injectionSource;
    }
    addEventListener(t, r) {
      if ((_f("eventType", t), wf("functionToExecute", r), this.omid3p)) {
        this.omid3p.addEventListener(t, r, this.injectionId_);
        return;
      }
      this.sendMessage_("addEventListener", r, t, this.injectionId_);
    }
    handleMessage_(t, r) {
      const { method: n, guid: a, args: i } = t;
      if (n === "response" && this.callbackMap_[a]) {
        const o = Ef(En, i);
        this.callbackMap_[a].apply(this, o);
      }
      n === "error" && window.console && gf(i);
    }
    sendMessage_(t, r, ...n) {
      if (!this.communication) return;
      const a = kf();
      r && (this.callbackMap_[a] = r);
      const i = new Re(a, `VerificationService.${t}`, En, xf(En, n));
      this.communication.sendMessage(i);
    }
  }
  function us(e) {
    if (!window.mraid) {
      const r = e("mraid", 10);
      r && (window.mraid = r);
    }
    if (!window.mraidbridge) {
      const r = e("mraidbridge", 10);
      r && (window.mraidbridge = r);
    }
  }
  const Hf = 10;
  function $f() {
    try {
      const e = new Vf();
      return e.isSupported()
        ? {
            isSupported: () => e.isSupported(),
            addEventListener: (t, r) => e.addEventListener(t, (n) => r(n)),
          }
        : void 0;
    } catch {
      return;
    }
  }
  function Ff() {
    return (
      us(ir), { mraid: window.mraid ?? ir("mraid", Hf), omid: $f(), document }
    );
  }
  const Gf = ({ mraid: e, onViewable: t, onError: r }) => {
      let n = !1;
      const a = (l) => {
          try {
            l();
          } catch (u) {
            r(u);
          }
        },
        i = () => {
          n ||
            ((n = !0),
            e.removeEventListener("ready", c),
            e.removeEventListener("viewableChange", o),
            t());
        },
        o = (l) =>
          a(() => {
            l && i();
          }),
        c = () =>
          a(() => {
            e.removeEventListener("ready", c), e.isViewable() && i();
          });
      return {
        start: () =>
          a(() => {
            e.addEventListener("viewableChange", o),
              e.getState() === "loading" ? e.addEventListener("ready", c) : c();
          }),
        detach: () =>
          a(() => {
            e.removeEventListener("ready", c),
              e.removeEventListener("viewableChange", o);
          }),
      };
    },
    jf = ({ omid: e, onInView: t, onError: r }) => {
      let n = !1;
      const a = (o) => {
          try {
            o();
          } catch (c) {
            r(c);
          }
        },
        i = (o) =>
          a(() => {
            !n || !(o?.data?.adView?.percentageInView > 0) || ((n = !1), t());
          });
      return {
        start: () =>
          a(() => {
            (n = !0), e.addEventListener("geometryChange", i);
          }),
        detach: () => {
          n = !1;
        },
      };
    },
    qf = 5e3,
    Wf = ({ host: e, onLoaded: t, onError: r }) => {
      let n = !1,
        a;
      const i = (l) => {
          try {
            l();
          } catch (u) {
            r(u);
          }
        },
        o = () => {
          (n = !1),
            e.document?.removeEventListener?.("DOMContentLoaded", c),
            a !== void 0 && clearTimeout(a),
            (a = void 0);
        },
        c = () =>
          i(() => {
            n && (o(), t());
          });
      return {
        start: () =>
          i(() => {
            const l = e.document;
            if (l && l.readyState !== "loading") {
              t();
              return;
            }
            if (!l?.addEventListener) {
              r(
                new Error(
                  "Measurement host exposes no DOMContentLoaded event — the Counted Impression cannot fire"
                )
              );
              return;
            }
            (n = !0),
              l.addEventListener("DOMContentLoaded", c, { once: !0 }),
              (a = setTimeout(c, qf));
          }),
        detach: () => i(o),
      };
    };
  class Yf {
    constructor(t, r) {
      (this.fireUrl = t),
        (this.scope = r),
        (this.state = "idle"),
        (this.capabilities = new Set()),
        (this.firedUrls = new Set());
    }
    get currentState() {
      return this.state;
    }
    arm(t, r) {
      if (this.state !== "idle") return;
      this.state = "armed";
      const n = t.mraid,
        a = this.isOmidSupported(t) ? t.omid : void 0,
        i = n ? "mraid" : a ? "omid" : "on-load";
      n &&
        this.attach((o) =>
          Gf({
            mraid: n,
            onViewable: () =>
              o(() => {
                this.fireOnce(r.mraidTrackingUrl),
                  i === "mraid" && this.fireCountedImpression(r);
              }),
            onError: (c) => this.report(c),
          })
        ),
        a &&
          this.attach((o) =>
            jf({
              omid: a,
              onInView: () =>
                o(() => {
                  this.fireOnce(r.omidTrackingUrl),
                    i === "omid" && this.fireCountedImpression(r);
                }),
              onError: (c) => this.report(c),
            })
          ),
        i === "on-load" &&
          this.attach((o) =>
            Wf({
              host: t,
              onLoaded: () => o(() => this.fireCountedImpression(r)),
              onError: (c) => this.report(c),
            })
          ),
        this.startAll();
    }
    teardown() {
      this.state !== "torn_down" &&
        ([...this.capabilities].forEach((t) => this.release(t)),
        (this.state = "torn_down"));
    }
    attach(t) {
      const r = {},
        n = (a) => {
          a(),
            r.capability && this.release(r.capability),
            this.settleIfComplete();
        };
      (r.capability = t(n)), this.capabilities.add(r.capability);
    }
    startAll() {
      [...this.capabilities].forEach((t) => t.start()), this.settleIfComplete();
    }
    release(t) {
      t.detach(), this.capabilities.delete(t);
    }
    settleIfComplete() {
      this.state === "fired" &&
        this.capabilities.size === 0 &&
        (this.state = "torn_down");
    }
    isOmidSupported(t) {
      try {
        return t.omid?.isSupported() === !0;
      } catch (r) {
        return this.report(r), !1;
      }
    }
    fireCountedImpression(t) {
      if (this.state === "armed") {
        if (!t.impressionTrackingUrl) {
          this.report(
            new Error(
              "Measurement has no impressionTrackingUrl — the Counted Impression cannot fire"
            )
          );
          return;
        }
        this.fireOnce(t.impressionTrackingUrl), (this.state = "fired");
      }
    }
    fireOnce(t) {
      !t || this.firedUrls.has(t) || (this.firedUrls.add(t), this.fireUrl(t));
    }
    report(t) {
      R(t instanceof Error ? t : new Error(String(t)), {
        scope: this.scope,
        context: "measurement-core",
      });
    }
  }
  function ps(e, t) {
    const r = e.getSasConfig();
    if (!r) return;
    const n = Ff(),
      a = new Yf((i) => {
        new M({ url: i });
      }, t);
    return a.arm(n, r), a;
  }
  function hs(e) {
    return Hl(e)
      ? ke.Embedded
      : e?.reporting?.countImpressionOnePixel
      ? ke.OnePixel
      : ke.Standard;
  }
  function er(e) {
    if (!e) return null;
    try {
      return e.contentDocument || e.contentWindow?.document || null;
    } catch {
      return null;
    }
  }
  const ms = (e, t) => {
      const r = er(e),
        n = r?.defaultView;
      if (!r || !n) return;
      e.dataset.hasClickListener ||
        (n.addEventListener("click", (o) => {
          t(o);
        }),
        (e.dataset.hasClickListener = "true"));
      const a = [],
        i = new MutationObserver(() => {
          er(e)
            ?.querySelectorAll("iframe")
            ?.forEach((c) => {
              if (er(c)) {
                const l = ms(c, t);
                l && a.push(l);
              }
            });
        });
      return (
        i.observe(r, { childList: !0, subtree: !0 }),
        () => {
          i.disconnect(), a.forEach((o) => o());
        }
      );
    },
    Xf = (e) => {
      const t = /clickTag=(.*?)["|'|&]/i,
        r = e.match(t);
      return r ? decodeURIComponent(r[1]) : null;
    },
    Kf = (e) => {
      const t = /<!--\s*eClickURL\s+=\s+(.*?)\s*-->/,
        r = e.match(t);
      return r ? decodeURIComponent(r[1]) : null;
    },
    Qf = (e) => {
      const t = (c) =>
          new Promise((l) => {
            c.contentDocument?.readyState === "complete"
              ? l()
              : c.addEventListener("load", () => l());
          }),
        r = /ad[-_]?choices|ad[-_]?info/i,
        n = (c) => {
          try {
            const l = c.getAttribute("data-jcp-attribution-data") || "",
              u = a(l);
            return u.length ? u.some((p) => p.some((h) => r.test(h))) : !1;
          } catch (l) {
            return console.debug("Error in getDataJcpAttributionMatch:", l), !1;
          }
        },
        a = (c) => {
          if (!c) return [];
          try {
            const l = JSON.parse(c);
            if (Array.isArray(l))
              return l
                .filter((p) => Array.isArray(p))
                .map((p) => p.filter((h) => typeof h == "string"));
          } catch (l) {
            console.debug("Error parsing dataJcpAttribution:", l);
          }
          return [];
        },
        i = (c) => {
          try {
            const l = c.getAttribute("src") || "",
              u = c.getAttribute("href") || "",
              p = n(c);
            return r.test(l) || r.test(u) || p;
          } catch {
            return !1;
          }
        },
        o = async (c) => {
          try {
            if (i(c)) return c;
            const l = c.contentDocument;
            if (!l) return null;
            await t(c);
            const p = Array.from(l.getElementsByTagName("a")).find(i);
            if (p) return p;
            const m = Array.from(l.getElementsByTagName("img")).find(i);
            if (m) return m;
            const f = Array.from(l.getElementsByTagName("iframe"));
            for (const y of f) {
              const v = await o(y);
              if (v) return v;
            }
            const w = Array.from(l.getElementsByTagName("script")).find(i);
            return w || null;
          } catch (l) {
            return console.debug("Error in searchInFrame:", l), null;
          }
        };
      return o(e);
    },
    Jf = (e) => {
      if (!e) return !1;
      try {
        return (
          "studioV2" in e &&
          typeof e.studioV2 == "object" &&
          e.studioV2 !== null &&
          "api" in e.studioV2 &&
          typeof e.studioV2.api == "object" &&
          e.studioV2.api !== null &&
          "creatives" in e.studioV2.api &&
          Array.isArray(e.studioV2.api.creatives) &&
          e.studioV2.api.creatives.length >= 0
        );
      } catch {
        return !1;
      }
    },
    Zf = /data-str-render-strategy="(ps|div|iframe)"/,
    eg = (e) => Zf.exec(e)?.[1] || null;
  var De = ((e) => (
    (e.Postscribe = "postscribe"),
    (e.Iframe = "iframe"),
    (e.Div = "div"),
    (e.DcmScript = "dcm_script"),
    (e.CentroJs = "centro_js"),
    (e.Flashtalking = "flashtalking"),
    (e.Adform = "adform"),
    (e.Xandr = "xandr"),
    (e.Quantcast = "quantcast"),
    (e.Rubicon = "rubicon"),
    (e.TradeDeskBanner = "trade_desk_banner"),
    (e.Pubmatic = "pubmatic"),
    (e.Yahoo = "yahoo"),
    (e.Openx = "openx"),
    (e.Dv360 = "dv360"),
    (e.Dv360Iframe = "dv360-iframe"),
    (e.Basis = "basis"),
    (e.Other = "other"),
    e
  ))(De || {});
  const ee = {
      regex: {
        ADFORM_REGEX: /a2\.adform\.net/,
        BASIS_REGEX: /https?:\/\/clickserv\.sitescout\.com\/clk.[^']*/,
        CENTRO_JS_REGEX:
          /<a onclick\s*=\s*('|")new Image\(\)\.src\s*=\s*('|")\S+('|")\s*href=('|")https?:\/\/clickserv\.sitescout\.com\/\S*('|")/,
        DCM_SCRIPT_REGEX: /data-dcm-rendering-mode\s*=\s*('|")script('|")/,
        FLASHTALKING_REGEX: /servedby\.flashtalking\.com/,
        LINKEDIN_REGEX: /rtb-us-(east|west)\.linkedin\.com/,
        PUBMATIC_REGEX: /ads\.pubmatic\.com/,
        QUANTCAST_REGEX: /content\.quantcount\.com/,
        RUBICON_REGEX: /(rubicon_cb\s?=\s?)|(window\.rubicon_ad\s?=\s?)/,
        TTD_PLAIN_OLD_BANNER: /<a.*?href=["|'].*?["|'].*?>/,
        XANDR_REGEX: /<script src="https?:\/\/\w{4}-ib\.adnxs\.com/,
        YAHOO_SCRIPT_REGEX: /<script.*?ybp\.yahoo\.com.*?<\/script>/,
      },
      source: {
        ADOBE: "5USETMxNT2j2QSCbVgvBAbfR",
        DV360: "V5J3YnPygd61DpGaQKLXUr8H",
        OPENX: "6E6dnPq1ztfkuxxNupdpgjDB",
        TRADE_DESK: "5b286190338513af73f09c28",
      },
    },
    tg = (e, t, r) => {
      const n = eg(e);
      return n === "ps"
        ? "postscribe"
        : n === "iframe" ||
          t === ee.source.ADOBE ||
          ee.regex.LINKEDIN_REGEX.test(e)
        ? "iframe"
        : n === "div"
        ? "div"
        : ee.regex.DCM_SCRIPT_REGEX.test(e)
        ? "dcm_script"
        : t === ee.source.TRADE_DESK
        ? ee.regex.TTD_PLAIN_OLD_BANNER.test(e)
          ? "postscribe"
          : "trade_desk_banner"
        : t === ee.source.OPENX
        ? "openx"
        : ee.regex.CENTRO_JS_REGEX.test(e)
        ? "centro_js"
        : ee.regex.FLASHTALKING_REGEX.test(e)
        ? "flashtalking"
        : ee.regex.ADFORM_REGEX.test(e)
        ? "adform"
        : ee.regex.XANDR_REGEX.test(e)
        ? "xandr"
        : ee.regex.QUANTCAST_REGEX.test(e)
        ? "quantcast"
        : ee.regex.RUBICON_REGEX.test(e)
        ? "rubicon"
        : ee.regex.PUBMATIC_REGEX.test(e)
        ? "pubmatic"
        : ee.regex.BASIS_REGEX.test(e)
        ? "basis"
        : ee.regex.YAHOO_SCRIPT_REGEX.test(e)
        ? "yahoo"
        : t === ee.source.DV360
        ? [
            "c3cac6b7",
            "31c129df",
            "1341fef4",
            "30658ce4",
            "f4074b07",
            "0aeeeff7",
          ].includes(r)
          ? "dv360-iframe"
          : "dv360"
        : "other";
    },
    An = (e) => {
      const t = e && e.innerHTML.match(/href=['"](.*?)['"]/);
      return t && t[1] && t[1].indexOf("://www.tubemogul.com") === -1
        ? t[1]
        : null;
    },
    rg = "//insight.adsrvr.org/track/clk?",
    ng = "//nym1-ib.adnxs.com/click?",
    ag = /https?:\/\/clickserv\.sitescout\.com\/clk.[^"|']*/,
    fs = 50,
    ig = /ad[-_]?choices|ad[-_]?info/i;
  function og(e) {
    const t = e.querySelectorAll("a[href]");
    let r = null;
    for (let n = 0; n < t.length; n++) {
      const a = t[n],
        i = a.getAttribute("href");
      if (!i || !i.startsWith("http") || ig.test(i)) continue;
      const o = a.getBoundingClientRect(),
        l = a.querySelector("img")?.getBoundingClientRect(),
        u = l?.width || o.width,
        p = l?.height || o.height;
      if (u > fs || p > fs) {
        const h = u * p;
        (!r || h > r.area) && (r = { href: i, area: h });
      }
    }
    return r?.href || null;
  }
  function sg(e) {
    const {
      container: t,
      bannerType: r,
      element: n,
      adm: a,
      bannerIframe: i,
    } = e;
    if (!t || !t.current) return { url: null, ruleUsed: "no-container" };
    const o = er(i);
    if (o) {
      const g = og(o);
      if (g) return { url: g, ruleUsed: "anchor-tag" };
    }
    const c = t.current.querySelectorAll("iframe");
    if (c)
      for (let g = 0; g < c.length; g++) {
        const w = c[g];
        let y;
        try {
          if (
            ((y = w && JSON.parse(w.getAttribute("name") || "{}")),
            y && y.clicks && y.clicks.clickTag)
          )
            return { url: y.clicks.clickTag, ruleUsed: "iframe-json" };
        } catch (v) {
          console.error(v);
        }
      }
    const l = n?.querySelector(".dcmads");
    if (l && l.getAttribute("data-dcm-click-tracker")) {
      const g = l.getAttribute("data-dcm-click-tracker");
      if (!g?.match(rg) && !g?.match(ng))
        return { url: g, ruleUsed: "dcm-data-attr" };
    }
    if (r === De.Adform) {
      const g = document.createElement("div");
      return (
        (g.innerHTML = a),
        { url: An(g.querySelector("noscript")), ruleUsed: "adform-noscript" }
      );
    }
    if (r === De.Basis) {
      const g = a.match(ag);
      if (g) return { url: g[0], ruleUsed: "basis-beacon" };
    }
    const u = Object.keys(window).filter((g) => g.match(/^amo_/))[0];
    if (u) {
      const g = window[u];
      if (g && g.atsLoggerBasePath && g.atsParams && g.baseParams) {
        const w = Object.keys(g.atsParams).map(
            (x) => `&${x}=${encodeURIComponent(g.atsParams[x])}`
          ),
          y = Object.keys(g.baseParams).map(
            (x) => `&${x}=${encodeURIComponent(g.baseParams[x])}`
          );
        return {
          url: `${
            g.atsLoggerBasePath
          }?cmd=CLICK_THRU&ProductURL=${encodeURIComponent(
            g.ad[0].product_url
          )}${w.join("")}${y.join("")}`,
          ruleUsed: "amo-banner",
        };
      }
    }
    const p = i?.contentWindow;
    if (Jf(p))
      try {
        const g = p.studioV2.api.creatives;
        if (!g || !g.length) return { url: null, ruleUsed: "gwd-no-creatives" };
        const w =
          p.studioV2.api.creatives[0].a ?? p.studioV2.api.creatives[0].j;
        if (!w || typeof w != "object")
          return { url: null, ruleUsed: "gwd-no-creative" };
        const y = Object.values(w).find(
          (_) => _ && typeof _ == "object" && _.Exit
        )?.Exit;
        if (!y) return { url: null, ruleUsed: "gwd-no-exit" };
        const v = ["mediaClickTag", "clickTag1"],
          x = new Map(v.map((_, k) => [_, k])),
          E = Object.keys(y).sort((_, k) => {
            const T = x.get(_),
              P = x.get(k);
            return (T ?? 1 / 0) - (P ?? 1 / 0);
          });
        for (const _ of E) {
          const k = y[_];
          if (k && typeof k == "object" && k.url)
            return { url: k.url, ruleUsed: `gwd-exit-${_}` };
        }
        return { url: null, ruleUsed: "gwd-no-exit" };
      } catch {
        return { url: null, ruleUsed: "gwd-error" };
      }
    if (r === De.TradeDeskBanner) {
      const g = Xf(a);
      if (g) return { url: g, ruleUsed: "tradedesk-click-param" };
    }
    const h = Kf(a);
    if (h) return { url: h, ruleUsed: "eclick-url" };
    const m = t.current?.querySelector("iframe");
    if (m)
      return {
        url: t && An(m.contentDocument?.querySelector("noscript") || null),
        ruleUsed: "iframe-noscript",
      };
    const f = t && An(t.current?.querySelector("noscript"));
    return { url: f, ruleUsed: f ? "noscript-container" : "no-match" };
  }
  function cg(e) {
    return e.replace(
      /data-dcm-rendering-mode\s*=\s*('|")iframe('|")/,
      'data-dcm-rendering-mode="script"'
    );
  }
  const gs = (e) => {
    const t = e?.content?.toString() || "",
      r = cg(t),
      n = r.replace(/<\\\/script>/gi, "</script>");
    return { raw: r, unescaped: n };
  };
  function lg(e) {
    return {
      placementSize: {
        width: e.network.size?.width || null,
        height: e.network.size?.height || null,
      },
      creativeSize: {
        width: e.creative.size?.width || null,
        height: e.creative.size?.height || null,
      },
      placementStringSize: e.network.size
        ? `${e.network.size?.width}x${e.network.size.height}`
        : "",
      creativeStringSize: e.creative.size
        ? `${e.creative.size.width}x${e.creative.size.height}`
        : "",
    };
  }
  var je = ((e) => (
    (e.Wide = "wide"),
    (e.Widest = "widest"),
    (e.Tall = "tall"),
    (e.Tallest = "tallest"),
    (e.Square = "square"),
    e
  ))(je || {});
  const dg = (e) => {
      const t = e.creative.type;
      if (t === N.Banner || t === N.Outstream) return !0;
      if (t === N.Native) {
        const r = e.creative.nativeType;
        if (r === _r.Clickout || r === _r.Video) return !0;
      }
      return !1;
    },
    bs = (e) => {
      if (!dg(e)) return null;
      const { placementSize: t, creativeSize: r } = lg(e);
      if (t.width && t.height) {
        const n = t.width / t.height,
          a = (r.width || 16) / (r.height || 9),
          i = vs(n),
          o = vs(a);
        return `str-responsive str-responsive-placement-${i} str-responsive-creative-${o}`;
      }
      return null;
    },
    vs = (e) =>
      e <= 2 / 7
        ? je.Tallest
        : e <= 4 / 5
        ? je.Tall
        : e <= 6 / 4
        ? je.Square
        : e <= 7 / 2
        ? je.Wide
        : je.Widest,
    ug = (e, t, r) =>
      bs(e) && !Ke(e.network.callerId)
        ? mg(t, e.creative.size.width, e.creative.size.height)
        : hg(t, r),
    pg = (e, t) => {
      e &&
        (t === 1
          ? e.style.removeProperty("transform")
          : (e.style.transform = "scale(" + t + ")"));
    },
    hg = (e, t, r = "") => `
  <html>
    <head>
      <style>
        .str-thumbnail-body {
          margin: 0 auto;
          overflow: -moz-scrollbars-none;
          width: 100%;
          height: 100%;
          ${
            t === 1
              ? ""
              : `transform: scale(${t});
          transform-origin: left top;`
          }
        }
        .str-thumbnail-body::-webkit-scrollbar { width: 0 !important };
        .str-thumbnail-body::-webkit-scrollbar::-ms-overflow-style: none;
      </style>
      <script>
        var bannerIframeErrorHandler = ${ba.toString()};
        function onLoad() {
          window.removeEventListener('error', bannerIframeErrorHandler);
          window.removeEventListener('load', onLoad);
        }

        window.addEventListener('error', bannerIframeErrorHandler);
        window.addEventListener('load', onLoad);
      <\/script>
    </head>
    <body class='str-thumbnail-body'>
      ${e}
    </body>
    ${r}
  </html>`,
    mg = (e, t, r, n = "") => `
  <html>
    <head>
      <style>
        html, body {
          margin: 0;
          padding: 0;
          width: 100%;
          height: 100%;
          overflow: hidden;
        }
        .str-thumbnail-body {
          display: flex;
          align-items: center;
          justify-content: center;
          width: 100%;
          height: 100%;
        }
        .str-thumbnail-content {
          width: ${t}px;
          height: ${r}px;
          transform-origin: center;
        }
        .str-thumbnail-content-scale {
          width: 100%;
          height: 100%;
        }
      </style>
      <script>
        var bannerIframeErrorHandler = ${ba.toString()};
        function onLoad() {
          window.removeEventListener('error', bannerIframeErrorHandler);
          window.removeEventListener('load', onLoad);
        }

        window.addEventListener('error', bannerIframeErrorHandler);
        window.addEventListener('load', onLoad);
      <\/script>
      <script>
        var applyIframeContentScale = ${pg.toString()};
        function resize() {
          const thumbnailBody = document.querySelector(".str-thumbnail-body");
          const thumbnailContent = document.querySelector(".str-thumbnail-content");
          const width = ${t};
          const height = ${r};

          const containerWidth = thumbnailBody?.clientWidth;
          const containerHeight = thumbnailBody?.clientHeight;

          const heightScale = containerHeight / height;
          const widthScale = containerWidth / width;
          const scale = Math.min(heightScale, widthScale, 1);

          applyIframeContentScale(thumbnailContent, scale);
        }
        window.addEventListener("DOMContentLoaded", resize, { once: true });
        window.addEventListener("resize", resize);

        resize();
      <\/script>
      <script>
        // var is function-scoped and can be redeclared
        // handles error: 'targetOrigin' has already been declared
        var targetOrigin = '*';
        try {
          const origin = window.parent.location.origin;
          if (origin !== "null") targetOrigin = origin;
        } catch (_) {} // keep '*'

        window.addEventListener('message', (event) => {
          if (event.data?.method === 'iframeclick') return;

          window.parent.postMessage({ ...event.data, originalOrigin: event.origin }, targetOrigin);
        });
      <\/script>
    </head>
    <body class="str-thumbnail-body">
      <div class="str-thumbnail-content">
        <div class="str-thumbnail-content-scale">${e}</div>
      </div>
    </body>
    ${n}
  </html>
`,
    fg = (e, t, r, n) => Math.min(t / n, e / r, 1),
    gg = (e, t) => {
      bg(e) && t && t(new MouseEvent("thumbnailclick"));
    },
    bg = (e) => {
      let t = typeof e == "string" ? vg(e) : e;
      return (
        t.stringValue && (t = _g(t.stringValue)),
        t.method
          ? t.method === "clickthrough" || t.method === "iframeclick"
          : t.clickTag
          ? (window.open(t.clickTag, "_blank"), !0)
          : t.methodName
          ? t.methodName === "AD_CLICKED"
          : !1
      );
    },
    vg = (e) => {
      try {
        return JSON.parse(e);
      } catch {
        return kn(e);
      }
    },
    _g = (e) => {
      try {
        const t = /\"data":{(.*?)\}/,
          r = e.match(t);
        return r ? JSON.parse("{" + r[1] + "}") : kn(e);
      } catch {
        return kn(e);
      }
    },
    kn = (e) => ({ stringValue: e }),
    _s = [
      b.GCEnhancementType.BannerShoppableOverlay,
      b.GCEnhancementType.BannerBrandedHeadline,
    ],
    wg = ({
      width: e,
      height: t,
      networkWidth: r,
      networkHeight: n,
      creative: a,
      enhancement: i,
    }) =>
      e == null ||
      t == null ||
      r == null ||
      n == null ||
      e !== r ||
      t !== n ||
      !Ci(e, t) ||
      a.type !== N.Banner ||
      !Te(a, i)
        ? !1
        : !_s.includes(i.type),
    ws = (e, t) => {
      e instanceof Error &&
        R(e, {
          scope: t.scope,
          message: t.message,
          callerId: t.payload.network.callerId,
          networkId: t.payload.network.networkId,
          partnerId: t.payload.creative.partnerId,
          payload: t.payload,
          errorPayload: {
            isRestrictedIframeCaller: t.isRestrictedIframeCaller,
            ...t.extraInfo,
          },
        });
    },
    In = (e, t, r, n) => {
      try {
        e.srcdoc = t;
      } catch (a) {
        try {
          e.src = `data:text/html,${encodeURIComponent(t)}`;
        } catch (i) {
          return (
            i instanceof Error &&
              ws(i, {
                message:
                  "SetRestrictedIframeContent: Failed to set iframe content (both srcdoc and src)",
                isRestrictedIframeCaller: !0,
                payload: r,
                scope: n,
                extraInfo: {
                  initialError: a instanceof Error ? a.message : String(a),
                  fallbacksAttempted: ["srcdoc", "src"],
                },
              }),
            !1
          );
        }
      }
      return !0;
    },
    yg = (e, t, r, n) => {
      let a = null;
      try {
        a = e.contentDocument || (e.contentWindow && e.contentWindow.document);
      } catch (i) {
        if (i instanceof Error) return In(e, t, r, n);
      }
      if (!a) {
        const i = "prerendering" in document && document.prerendering === !0;
        return (
          R(
            new Error(
              "SetUnrestrictedIframeContent: contentDocument is not accessible"
            ),
            {
              scope: n,
              message:
                "SetUnrestrictedIframeContent: contentDocument is not accessible, falling back to restricted content",
              supplyId: r.network.callerId,
              payload: r,
              errorPayload: { isRestrictedIframeCaller: !1 },
              isIframeConnected: e.isConnected,
              hasContentWindow: e.contentWindow !== null,
              readyState: document.readyState,
              visibilityState: document.visibilityState,
              isPrerendering: i,
              msSinceNavigation: Math.round(performance.now()),
              isSafeFrame: J.isSafeFrame(),
              isTopDocument: window.self === window.top,
              sampling: 0.01,
            }
          ),
          In(e, t, r, n)
        );
      }
      try {
        a.open(), a.write(t), a.close();
      } catch (i) {
        let o = [];
        i instanceof Error && (o = [i.message]);
        try {
          e.srcdoc = t;
        } catch (c) {
          if (!(c instanceof Error)) return !1;
          o.push(c.message);
          try {
            e.src = `data:text/html,${encodeURIComponent(t)}`;
          } catch (l) {
            return (
              l instanceof Error &&
                ws(l, {
                  message:
                    "SetUnrestrictedIframeContent: Failed all iframe content setting attempts",
                  isRestrictedIframeCaller: !1,
                  payload: r,
                  scope: n,
                  extraInfo: {
                    previousErrors: o,
                    fallbacksAttempted: ["document.write", "srcdoc", "src"],
                  },
                }),
              !1
            );
          }
        }
      }
      return !0;
    },
    xg = "https://cdn.rendering.sharethrough.com/OnepxImpressionScript.js",
    ys = "data-onepx-impression-id",
    xs = (e, t, r = document.body) => {
      if (!e.reporting.countImpressionOnePixel) return !1;
      const n = e.reporting.trackerImpressionUrl ?? e.id;
      if (r.getAttribute(ys) === n) return !1;
      if (!ne.value)
        return (
          R(new Error("Tracker service not found"), {
            scope: t,
            context: "get-one-pixel-script/inject-dom",
          }),
          !1
        );
      let a;
      try {
        a = ne.value?.getSasConfig();
      } catch (i) {
        return (
          console.log(
            "injectOnePixelScriptIntoDOM: Error getting SAS config",
            i
          ),
          R(i, { scope: t, context: "get-one-pixel-script/inject-dom" }),
          !1
        );
      }
      if (!a)
        return (
          R(new Error("SAS config not found"), {
            scope: t,
            context: "get-one-pixel-script/inject-dom",
          }),
          !1
        );
      try {
        const i = document.createElement("script");
        (i.textContent = `
      (function () {
        var getWindowParentAttribute = ${ir.toString()};
        var copyMraidToFrame = ${us.toString()};
        copyMraidToFrame(getWindowParentAttribute);
      })();
    `),
          r.appendChild(i);
        const o = document.createElement("script");
        (o.textContent = `window.SASAdContainerTypeTrackerConfig = ${JSON.stringify(
          a
        )}`),
          r.appendChild(o);
        const c = document.createElement("script");
        return (c.src = xg), r.appendChild(c), r.setAttribute(ys, n), !0;
      } catch (i) {
        return (
          R(i, { scope: t, context: "get-one-pixel-script/inject-dom" }), !1
        );
      }
    },
    Eg = ({ iframeRef: e, onIframeClick: t, onIframeError: r }) => {
      const n = he();
      A(() => {
        const a = (i) => {
          const o = e.current;
          if (i.source === o?.contentWindow)
            switch (i.data?.eventType) {
              case "iframeError":
                r();
                break;
              case "engagementClick":
                i.data.originalOrigin === "https://c.sofiapulse.com" &&
                  n?.trackClick(o);
                break;
              default:
                gg(i.data, t);
            }
        };
        return (
          window.addEventListener("message", a),
          () => {
            window.removeEventListener("message", a);
          }
        );
      }, [e, t, n]);
    };
  class Ag {
    constructor() {
      (this.listeners = new Set()),
        (this.handleChange = () => {
          const t = !window.document.hidden;
          this.listeners.forEach((r) => r(t));
        }),
        window.document.addEventListener("visibilitychange", this.handleChange);
    }
    subscribe(t) {
      return (
        this.listeners.add(t),
        t(!document.hidden),
        () => {
          this.listeners.delete(t);
        }
      );
    }
    disconnect() {
      document.removeEventListener("visibilitychange", this.handleChange),
        this.listeners.clear();
    }
  }
  const kg = yo((e, t) => {
      const r = O(null),
        n = Q(),
        a = O(void 0),
        i = he(),
        o = le(),
        c = ce(() => _e(o, re.MeasuredImpression), [o]),
        l = O(!1),
        u = O(void 0),
        [p, h] = V(!1),
        m = an(null),
        [f, g] = V(!1);
      oc(t, () => r.current);
      const w = Si(n?.creative.content, n?.enhancement?.type);
      n && (m.value = hs(n));
      const { raw: y, unescaped: v } = gs(n?.creative),
        x = f ? y : v;
      A(() => {
        const _ = r.current;
        if (!n || !_) return;
        const T =
            n.creative.size.width === 320 &&
            n.creative.size.height === 50 &&
            n.network.size.width === 300 &&
            n.network.size.height === 50
              ? fg(_.clientWidth, _.clientHeight, e.width, e.height)
              : 1,
          P = ug(n, x, T);
        Ul(n.network.callerId)
          ? In(_, P, n, o) && h(!0)
          : yg(_, P, n, o) && h(!0);
      }, [e.width, e.height, n, r, f]),
        A(() => {
          const _ = r.current?.parentElement;
          if (
            _ &&
            n?.reporting?.countImpressionOnePixel &&
            p &&
            !(!e.width || !e.height)
          ) {
            if (m.value === ke.Embedded) {
              Sg(n, _, c);
              return;
            }
            Es(_), xs(n, c, _);
          }
        }, [n, p, e.width, e.height, m.value]),
        A(() => {
          if (!w) return;
          const _ = new Ag();
          return (
            _.subscribe((k) => {
              if (k) window.focus();
              else {
                const T = r.current;
                T && document.activeElement === T && i && i.trackClick(T);
              }
            }),
            () => {
              _.disconnect();
            }
          );
        }, []),
        A(() => {
          if (w) return;
          const _ = r.current;
          if (!_) return;
          const k = [],
            T = () => {
              l.current ||
                ((l.current = !0),
                i?.trackClick(_),
                (u.current = setTimeout(() => {
                  (l.current = !1), (u.current = void 0);
                }, Ig)));
            },
            P = ms(_, (W) => {
              Cg(W) && T();
            });
          return (
            P && k.push(P),
            k.push(ff({ iframe: _, onClick: T })),
            () => k.forEach((W) => W())
          );
        }, [e.onIframeClick, i]),
        Eg({
          iframeRef: r,
          onIframeClick: e.onIframeClick,
          onIframeError: () => {
            y !== v && g(!0);
          },
        }),
        A(() => {
          const _ = r.current;
          p &&
            _?.parentElement &&
            (m.value === ke.Standard
              ? i?.trackImpression(_.parentElement, o, "standard")
              : i?.trackVisibleImpression(_.parentElement));
        }, [p, i, m.value]),
        A(() => {
          const _ = r.current;
          !_ ||
            Bt.value ||
            Qf(_).then((k) => {
              Bt.value = !!k;
            });
        }, []),
        A(() => {
          let _ = null,
            k = !1;
          const T = () =>
              !r.current || !p || document.hidden || k
                ? null
                : Wt({
                    element: r.current,
                    timeoutIdRef: a,
                    inViewPixels: 1,
                    outOfViewPixels: 0,
                    inViewCallback: () => {
                      !document.hidden &&
                        !k &&
                        (i?.trackPixelVisible(),
                        (k = !0),
                        _?.disconnect(),
                        (_ = null));
                    },
                  }),
            P = () => {
              document.hidden
                ? (_ && (_.disconnect(), (_ = null)),
                  a.current &&
                    (window.clearTimeout(a.current), (a.current = void 0)))
                : !_ && !k && (_ = T());
            };
          return (
            (_ = T()),
            document.addEventListener("visibilitychange", P),
            () => {
              _?.disconnect(),
                document.removeEventListener("visibilitychange", P);
            }
          );
        }, [r, p, i]);
      const E = {
        id: e.id,
        "data-thumbnail-id": e.dataThumbnailId,
        className: e.className,
        scrolling: "no",
        frameBorder: "0",
        style: { width: "100%", height: "100%", top: 0, left: 0 },
        "data-testid": "adm-iframe",
        onLoad: () => Sr(),
        ref: r,
      };
      return d("iframe", { ...E });
    }),
    Ig = 300,
    Cg = (e) => e.target?.closest('a[target="_blank" i]') != null,
    Cn = "data-embedded-measurement-armed-id",
    Sn = new WeakMap();
  function Sg(e, t, r) {
    const n = e.reporting.trackerImpressionUrl ?? e.id;
    if (t.getAttribute(Cn) === n) return;
    if ((Es(t), !ne.value)) {
      R(new Error("Tracker service not found"), {
        scope: r,
        context: "arm-embedded-measurement",
      });
      return;
    }
    let a;
    try {
      a = ps(ne.value, r);
    } catch (i) {
      R(i instanceof Error ? i : new Error(String(i)), {
        scope: r,
        context: "arm-embedded-measurement",
      });
      return;
    }
    if (!a) {
      R(new Error("SAS config not found"), {
        scope: r,
        context: "arm-embedded-measurement",
      });
      return;
    }
    Sn.set(t, a), t.setAttribute(Cn, n);
  }
  function Es(e) {
    const t = Sn.get(e);
    t && (t.teardown(), Sn.delete(e), e.removeAttribute(Cn));
  }
  const As = (e) =>
    !!e &&
    e.creative.type === N.Banner &&
    !Te(e.creative, e.enhancement) &&
    Ke(e.network.callerId);
  var ge = ((e) => (
    (e.Dv360 = "dv360"),
    (e.Appnexus = "appnexus"),
    (e.TradeDesk = "tradeDesk"),
    (e.Rubicon = "rubicon"),
    e
  ))(ge || {});
  const Tg = {
      dv360: ["76", "429", "499"],
      appnexus: ["86", "447", "519", "33046", "33091"],
      tradeDesk: ["75"],
      rubicon: ["109", "376", "438", "507"],
    },
    Og = Object.values(ge),
    Rg = /clickTag=(.*?)["|'|&]/i;
  function ks(e) {
    const t = e.match(Rg);
    if (!t) return null;
    try {
      return decodeURIComponent(t[1]);
    } catch {
      return t[1];
    }
  }
  function Is(e) {
    try {
      const t = e?.contentWindow;
      if (
        t?.clickTag &&
        typeof t.clickTag == "string" &&
        t.clickTag.startsWith("http")
      )
        return t.clickTag;
    } catch {
      return null;
    }
    return null;
  }
  const Ng = (e) =>
      e
        ? "studioV2" in e &&
          typeof e.studioV2 == "object" &&
          e.studioV2 !== null &&
          "api" in e.studioV2 &&
          typeof e.studioV2.api == "object" &&
          e.studioV2.api !== null &&
          "creatives" in e.studioV2.api &&
          Array.isArray(e.studioV2.api.creatives)
        : !1,
    Cs = 50,
    Dg = /ad[-_]?choices|ad[-_]?info/i,
    Pg = /%%CLICK_URL|\$\{CLICK_URL/,
    zg = /<gwd-exit[^>]*\burl=["']([^"']+)["'][^>]*>/gi,
    Ug = /\bmetric=["']([^"']+)["']/i;
  function Mg(e) {
    const t = [];
    let r;
    for (; (r = zg.exec(e)) !== null; ) {
      const a = r[1],
        o = r[0].match(Ug)?.[1] ?? "";
      t.push({ url: a, metric: o });
    }
    if (!t.length) return null;
    const n = ["mediaClickTag", "clickTag", "clickTag1"];
    for (const a of n) {
      const i = t.find((o) => o.metric === a);
      if (i) return i.url;
    }
    return t[0].url;
  }
  function Bg(e) {
    try {
      const t = e?.contentWindow;
      if (!Ng(t)) return null;
      const r = t.studioV2.api.creatives;
      if (!r?.length) return null;
      const n = r[0].a ?? r[0].j;
      if (!n || typeof n != "object") return null;
      const a = Object.values(n).find(
        (l) => l && typeof l == "object" && l.Exit
      )?.Exit;
      if (!a) return null;
      const i = ["mediaClickTag", "clickTag1"],
        o = new Map(i.map((l, u) => [l, u])),
        c = Object.keys(a).sort((l, u) => {
          const p = o.get(l),
            h = o.get(u);
          return (p ?? 1 / 0) - (h ?? 1 / 0);
        });
      for (const l of c) {
        const u = a[l];
        if (u && typeof u == "object" && u.url) return u.url;
      }
    } catch {
      return null;
    }
    return null;
  }
  function Lg(e) {
    try {
      const t = e?.contentDocument ?? e?.contentWindow?.document;
      if (!t) return null;
      const n = t.querySelector(".dcmads")?.dataset.dcmClickTracker;
      return !n || Pg.test(n) ? null : n;
    } catch {
      return null;
    }
  }
  function Vg(e) {
    try {
      const t = e?.contentDocument ?? e?.contentWindow?.document;
      if (!t) return null;
      const r = t.querySelectorAll("a[href]");
      let n = null;
      for (let a = 0; a < r.length; a++) {
        const i = r[a],
          o = i.getAttribute("href");
        if (!o || !o.startsWith("http") || Dg.test(o)) continue;
        const c = i.getBoundingClientRect(),
          u = i.querySelector("img")?.getBoundingClientRect(),
          p = u?.width || c.width,
          h = u?.height || c.height;
        if (p > Cs || h > Cs) {
          const m = p * h;
          (!n || m > n.area) && (n = { url: o, area: m });
        }
      }
      return n?.url ?? null;
    } catch {
      return null;
    }
  }
  function Hg(e) {
    const { bannerIframe: t, creativeLink: r, adm: n } = e;
    if (r) return { url: r, method: "creative-link" };
    if (n) {
      const l = Mg(n);
      if (l) return { url: l, method: "gwd-exit-markup" };
      const u = ks(n);
      if (u) return { url: u, method: "click-tag-param" };
    }
    const a = Bg(t);
    if (a) return { url: a, method: "gwd-exit" };
    const i = Is(t);
    if (i) return { url: i, method: "window-click-tag" };
    const o = Lg(t);
    if (o) return { url: o, method: "dcm-data-attr" };
    const c = Vg(t);
    return c
      ? { url: c, method: "anchor-tag" }
      : { url: null, method: "not-found" };
  }
  const Ss = 50,
    $g = /ad[-_]?choices|ad[-_]?info/i,
    Fg = /EBG\.ads/,
    Gg = /https?:\/\/[a-z0-9-]+\.adnxs\.com\/click\?[^"'\\\s)]+/i;
  function Ts(e) {
    if (!Fg.test(e)) return null;
    const t = new RegExp(Gg).exec(e);
    return t ? t[0] : null;
  }
  function jg(e) {
    return Ts(e);
  }
  function qg(e, t) {
    try {
      const r = [];
      e.current && r.push(e.current);
      const n = t?.contentDocument ?? t?.contentWindow?.document;
      n && r.push(n);
      for (const a of r) {
        const i = a.querySelectorAll("[onclick]");
        for (let o = 0; o < i.length; o++) {
          const c = i[o].getAttribute("onclick");
          if (!c) continue;
          const l = Ts(c);
          if (l) return l;
        }
      }
    } catch {
      return null;
    }
    return null;
  }
  function Wg(e) {
    try {
      const t = e?.contentDocument ?? e?.contentWindow?.document;
      if (!t) return null;
      const r = t.querySelectorAll("a[href]");
      let n = null;
      for (let a = 0; a < r.length; a++) {
        const i = r[a],
          o = i.getAttribute("href");
        if (!o || !o.startsWith("http") || $g.test(o)) continue;
        const c = i.getBoundingClientRect(),
          u = i.querySelector("img")?.getBoundingClientRect(),
          p = u?.width || c.width,
          h = u?.height || c.height;
        if (p > Ss || h > Ss) {
          const m = p * h;
          (!n || m > n.area) && (n = { url: o, area: m });
        }
      }
      return n?.url ?? null;
    } catch {
      return null;
    }
  }
  function Yg(e) {
    const { container: t, bannerIframe: r, creativeLink: n, adm: a } = e;
    if (n) return { url: n, method: "creative-link" };
    if (a) {
      const c = jg(a);
      if (c) return { url: c, method: "ebg-onclick-markup" };
    }
    const i = qg(t, r);
    if (i) return { url: i, method: "ebg-onclick-dom" };
    const o = Wg(r);
    return o
      ? { url: o, method: "anchor-tag" }
      : { url: null, method: "not-found" };
  }
  const Os = 50,
    Xg = /ad[-_]?choices|ad[-_]?info/i,
    Kg = /https?:\/\/pixel\.mathtag\.com\/click[/?][^"'\\\s)]+/i;
  function Rs(e) {
    const t = new RegExp(Kg).exec(e);
    return t ? t[0] : null;
  }
  function Qg(e) {
    return Rs(e);
  }
  function Jg(e, t) {
    try {
      const r = [];
      e.current && r.push(e.current);
      const n = t?.contentDocument ?? t?.contentWindow?.document;
      n && r.push(n);
      for (const a of r) {
        const i = a.querySelectorAll("[onclick]");
        for (const o of Array.from(i)) {
          const c = o.getAttribute("onclick");
          if (!c) continue;
          const l = Rs(c);
          if (l) return l;
        }
      }
    } catch {
      return null;
    }
    return null;
  }
  function Zg(e) {
    try {
      const t = e?.contentDocument ?? e?.contentWindow?.document;
      if (!t) return null;
      const r = t.querySelectorAll("a[href]");
      let n = null;
      for (const a of Array.from(r)) {
        const i = a.getAttribute("href");
        if (!i || !i.startsWith("http") || Xg.test(i)) continue;
        const o = a.getBoundingClientRect(),
          l = a.querySelector("img")?.getBoundingClientRect(),
          u = l?.width || o.width,
          p = l?.height || o.height;
        if (u > Os || p > Os) {
          const h = u * p;
          (!n || h > n.area) && (n = { url: i, area: h });
        }
      }
      return n?.url ?? null;
    } catch {
      return null;
    }
  }
  function eb(e) {
    const { container: t, bannerIframe: r, creativeLink: n, adm: a } = e;
    if (n) return { url: n, method: "creative-link" };
    if (a) {
      const c = Qg(a);
      if (c) return { url: c, method: "mathtag-onclick-markup" };
    }
    const i = Jg(t, r);
    if (i) return { url: i, method: "mathtag-onclick-dom" };
    const o = Zg(r);
    return o
      ? { url: o, method: "anchor-tag" }
      : { url: null, method: "not-found" };
  }
  function tb(e) {
    const { bannerIframe: t, creativeLink: r, adm: n } = e;
    if (r) return { url: r, method: "creative-link" };
    if (n) {
      const i = ks(n);
      if (i) return { url: i, method: "click-tag-param" };
    }
    const a = Is(t);
    return a
      ? { url: a, method: "window-click-tag" }
      : { url: null, method: "not-found" };
  }
  const rb = {
      [ge.Dv360]: Hg,
      [ge.Appnexus]: Yg,
      [ge.TradeDesk]: tb,
      [ge.Rubicon]: eb,
    },
    nb = {
      [ge.Dv360]: Ce.Dv360ClickExtraction,
      [ge.Appnexus]: Ce.AppnexusClickExtraction,
      [ge.TradeDesk]: Ce.TradeDeskClickExtraction,
      [ge.Rubicon]: Ce.RubiconClickExtraction,
    };
  function ab(e) {
    if (e.creative.type !== N.Banner) return null;
    const t = Og.find((r) => Tg[r].includes(e.creative.partnerId));
    return t && Ti(e, nb[t]) ? rb[t] : null;
  }
  const ib = "//adclick.g.doubleclick.net/pcs/click?",
    ob = "//googleads.g.doubleclick.net/dbm/clk?";
  function sb(e) {
    return e === De.Basis
      ? "[onclick]"
      : 'a:not(.qc-adchoices-link):not([href*="privacy_summary.html"]):not([href*="adssettings.google.com"]):not([href*="privacy.centro.net"]):not([href="#"]):not([href*="info.yahoo.com"]):not([href*="adchoices"]):not([href*="adinfo"]):not([href*="optout"]):not([href*="privacy"])';
  }
  function cb(e) {
    return e.offsetHeight > 0 && e.offsetWidth > 0;
  }
  function lb(e) {
    return !!(e.href?.match(ib) || e.href?.match(ob));
  }
  function db(e, t) {
    if (e) {
      for (const r of Array.from(e))
        if (r.contentDocument) {
          const n = r.contentWindow?.document?.querySelector(t);
          if (n) return n;
        }
    }
    return null;
  }
  const ub = (e) => {
      const { container: t, bannerType: r } = e;
      if (!t.current) return { element: null, ruleUsed: "no-container" };
      const n = t.current.querySelector("img[onclick]"),
        a = n?.getAttribute("onclick");
      if (a) {
        if (r === De.Xandr && a.match(/EBG\.ads/))
          return { element: n, ruleUsed: "xandr-img-onclick" };
        if (
          r === De.Rubicon &&
          a.match(/window\.open\('http(s)?:\/\/pixel\.mathtag\.com\/click/)
        )
          return { element: n, ruleUsed: "rubicon-img-onclick" };
      }
      const i = sb(r);
      let o = t.current.querySelector(i);
      try {
        if (!o) {
          const c = t.current.querySelector("iframe");
          if (
            c?.contentDocument &&
            ((o = c.contentWindow?.document.querySelector(i) || null), !o)
          ) {
            const l = c.contentWindow?.document.querySelectorAll("iframe");
            o = db(l, i);
          }
        }
      } catch (c) {
        console.error("Error: ", c);
      }
      return o
        ? lb(o)
          ? { element: o, ruleUsed: "doubleclick-link" }
          : cb(o)
          ? { element: o, ruleUsed: "visible-element" }
          : { element: o, ruleUsed: "found-element" }
        : { element: null, ruleUsed: "no-match" };
    },
    Ns = (e) => {
      const t = e.enhancement.payload;
      if (!t) return null;
      const r =
        ("redirectUrl" in t ? t.redirectUrl : null) ??
        ("clickUrl" in t ? t.clickUrl : null) ??
        ("media_url" in t ? t.media_url : null);
      return r ? String(r) : null;
    },
    pb = (e, t) => {
      const r = e.redirectUrl ?? Ns(t);
      return r && window.open(r, "_blank"), !0;
    },
    Vn = class Vn extends cn {
      constructor(t) {
        super(t),
          (this.container = me()),
          (this.iframeRef = me()),
          (this.element = null),
          (this.isEnhanced = !Te(
            this.payload.creative,
            this.payload.enhancement
          )),
          (this.thumbnailId = Ea()),
          (this.showClickBlocker = U(!1)),
          (this.isBannerClickable = U(!1)),
          (this.trackerService = null),
          (this.response = void 0),
          (this._bannerType = void 0),
          (this._clickableElementBase = null),
          (this._clickableElement = null),
          (this._clickableElementRule = void 0),
          (this._clickoutUrlBase = null),
          (this._clickoutUrl = void 0),
          (this._clickoutUrlRule = void 0),
          (this.getBannerClickability = () => {
            const n = !!(
              this.response?.creative.mediaUrl ||
              this.clickableElement ||
              this.clickoutUrl ||
              this.enhancementUrl
            );
            return (this.isBannerClickable.value = n), n;
          }),
          (this.getBannerClickabilityRule = () =>
            this.response?.creative.mediaUrl
              ? "media-url"
              : this.clickableElementRule
              ? this.clickableElementRule
              : this.clickoutUrlRule || "not-found"),
          (this.handleAdClick = (n) => {
            if (
              this.payload.reporting.disableClickCounting ||
              (!this.useClickExtractionV2 && pb(n, this.payload))
            )
              return;
            if ((this.propagateClickEvent(n.event), n.redirectUrl)) {
              window.open(n.redirectUrl, "_blank");
              return;
            }
            if (this.clickableElement) {
              const i = this.clickableElement.getAttribute("onclick");
              i && this.clickableElement.setAttribute("onclick", au(i)),
                this.clickableElement.dispatchEvent(Jl());
              return;
            }
            const a = this.clickoutUrl || this.enhancementUrl;
            if (a) {
              window.open(a, "_blank");
              return;
            }
          }),
          (this.propagateClickEvent = (n) => {
            if (
              (this.trackerService?.trackUserShare(),
              this.getBannerClickability() || n.type === "thumbnailclick")
            ) {
              const a =
                n.target instanceof HTMLElement &&
                n.target.dataset.strThumbnail === "true"
                  ? n.target
                  : this.element;
              this.trackerService?.trackClick(a);
            }
          }),
          (this.updateClickable = () => {
            (this._clickableElement = null), this.getBannerClickability();
          }),
          (this.clickBlockerClick = (n) => {
            this.handleAdClick({ event: n });
          });
        const r = Et.getResponse(t.adserverRequestId);
        (this.response = r),
          (this.trackerService = t.trackerService),
          this.setupClickabilityTracking();
      }
      setupClickabilityTracking() {
        const t = Ot(() => {
          this.isBannerClickable.value &&
            (this.trackerService?.trackBannerClickable(
              this._clickExtractionResult,
              this._clickExtractionDurationMs
            ),
            t());
        });
      }
      get bannerType() {
        return (
          this._bannerType ||
            (this._bannerType = tg(
              this.context.creative.content,
              this.context.creative.partnerId,
              this.context.network.networkId || ""
            )),
          this._bannerType
        );
      }
      get clickableElementBase() {
        return (
          this._clickableElementBase ||
            (this._clickableElementBase = ub({
              bannerType: this.bannerType,
              container: this.container,
            })),
          this._clickableElementBase
        );
      }
      get clickableElement() {
        return (
          this._clickableElement ||
            (this._clickableElement =
              this.clickableElementBase?.element || null),
          this._clickableElement
        );
      }
      get clickableElementRule() {
        return (
          this._clickableElementRule ||
            (this._clickableElementRule = this.clickableElementBase?.ruleUsed),
          this._clickableElementRule
        );
      }
      get activeClickExtractor() {
        return (
          this._activeClickExtractor === void 0 &&
            (this._activeClickExtractor = ab(this.context)),
          this._activeClickExtractor
        );
      }
      get useClickExtractionV2() {
        return this.activeClickExtractor !== null;
      }
      get clickoutUrlBase() {
        if (!this._clickoutUrlBase) {
          const { unescaped: t } = gs(this.context.creative),
            r = this.activeClickExtractor;
          if (r) {
            const n = performance.now(),
              a = r({
                container: this.container,
                bannerIframe: this.iframeRef.current,
                creativeLink: this.context.creative.link || void 0,
                adm: t,
              });
            (this._clickExtractionResult = a),
              (this._clickExtractionDurationMs = performance.now() - n),
              (this._clickoutUrlBase = { url: a.url, ruleUsed: a.method });
          } else
            this._clickoutUrlBase = sg({
              container: this.container,
              bannerIframe: this.iframeRef.current,
              bannerType: this.bannerType,
              element: this.element,
              adm: t,
            });
        }
        return this._clickoutUrlBase;
      }
      get clickoutUrl() {
        return (
          this._clickoutUrl || (this._clickoutUrl = this.clickoutUrlBase.url),
          this._clickoutUrl
        );
      }
      get clickoutUrlRule() {
        return (
          this._clickoutUrlRule ||
            (this._clickoutUrlRule = this.clickoutUrlBase.ruleUsed),
          this._clickoutUrlRule
        );
      }
      get bannerMetadata() {
        return {
          bannerType: this.bannerType,
          clickable: this.getBannerClickability(),
          clickableRule: this.getBannerClickabilityRule(),
        };
      }
      get width() {
        return this.payload?.creative?.size?.width;
      }
      get height() {
        return this.payload?.creative?.size?.height;
      }
      get networkWidth() {
        return this.payload?.network?.size?.width;
      }
      get networkHeight() {
        return this.payload?.network?.size?.height;
      }
      get enhancementUrl() {
        return Ns(this.payload);
      }
      get scale() {
        return !this.width ||
          !this.height ||
          !this.networkWidth ||
          !this.networkHeight ||
          (this.width <= this.networkWidth && this.height <= this.networkHeight)
          ? 1
          : Math.min(
              this.networkWidth / this.width,
              this.networkHeight / this.height
            );
      }
      get scaleFactors() {
        const t = Te(this.context.creative, this.context.enhancement);
        if (Ke(this.context.network.callerId))
          return { maxScale: this.scale, minScale: t ? void 0 : this.scale };
        if (!t) return { maxScale: this.scale, minScale: this.scale };
        if (
          this.width === this.networkWidth &&
          this.height === this.networkHeight &&
          _s.includes(this.context.enhancement.type)
        )
          return { maxScale: this.scale, minScale: this.scale };
        const n = `${this.width}x${this.height}`,
          a = `${this.networkWidth}x${this.networkHeight}`,
          i = `${n}-${a}`,
          c = { "336x280-300x250": 0.65 }[i] ?? Math.min(0.75, this.scale);
        return { maxScale: this.scale, minScale: c };
      }
      get getCreativeDimensionsStyle() {
        if (As(this.context)) {
          const n = `min(${this.width}px, 100cqw)`,
            a = `min(${this.height}px, 100cqh)`;
          return { minWidth: n, minHeight: a, maxWidth: n, maxHeight: a };
        }
        const { maxScale: t, minScale: r } = this.scaleFactors;
        return {
          minHeight: r && this.height * r,
          minWidth: r && this.width * r,
          maxHeight: this.height * t,
          maxWidth: this.width * t,
        };
      }
      componentDidMount() {
        window.setTimeout(() => {
          this.getBannerClickability();
          const { callerId: t } = this.payload.network,
            { content: r } = this.payload.creative,
            { disableClickCounting: n } = this.payload.reporting;
          this.showClickBlocker.value = Ll(
            t,
            r,
            n,
            this.payload.enhancement.type
          );
        }, 1e3),
          this.butlerResponse?.creative.description &&
            this.element
              ?.querySelector(".str-description")
              ?.classList.add("str-enhanced"),
          setTimeout(() => {
            const t = this.bannerMetadata;
            this.trackerService?.trackBannerRendered(
              t.clickable,
              t.clickableRule,
              Bt.value
            );
          }, 1e4);
      }
      componentDidCatch(t, r) {
        console.error(t, r),
          R(t, {
            scope: this.lifecycleScope,
            errorPayload: {
              errorInfo: r,
              creative: this.context.creative,
              adserverRequestId: this.props.adserverRequestId,
              reactRefactor: !0,
            },
          });
      }
      render() {
        return d(G, {
          children: [
            d(sf, {
              onClick: this.clickBlockerClick,
              showClickBlocker: this.showClickBlocker,
              isBannerClickable: this.isBannerClickable,
              iframe: this.iframeRef,
              enableClickExtraction: this.useClickExtractionV2,
            }),
            d("div", {
              "data-testid": "str-enhanced-display",
              className: "str-react-template",
              onClick: (t) => this.handleAdClick({ event: t }),
              ref: (t) => {
                this.element = t;
              },
              children: d(yn, {
                creative: this.context.creative,
                network: this.context.network,
                country: this.context?.network.country,
                adserverRequestId: this.context?.id || "",
                onEnhancementClick: this.handleAdClick,
                children: d("div", {
                  className: $("str-thumbnail-wrapper", {
                    "str-same-size-pinned": wg({
                      width: this.width,
                      height: this.height,
                      networkWidth: this.networkWidth,
                      networkHeight: this.networkHeight,
                      creative: this.context.creative,
                      enhancement: this.context.enhancement,
                    }),
                  }),
                  style: {
                    ...this.getCreativeDimensionsStyle,
                    position: "relative",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                  },
                  ref: this.container,
                  children: d(kg, {
                    id: this.context?.id || "",
                    dataThumbnailId: this.thumbnailId,
                    className: "str-thumbnail",
                    width: this.width,
                    height: this.height,
                    onLoad: this.updateClickable,
                    onIframeClick: (t) => this.handleAdClick({ event: t }),
                    ref: this.iframeRef,
                  }),
                }),
              }),
            }),
          ],
        });
      }
    };
  Vn.contextType = At;
  let tr = Vn;
  function hb(e) {
    const t = he(),
      r = Q();
    return !(r && Te(r.creative, r.enhancement))
      ? d(tr, { ...e, trackerService: t })
      : d(fo, {
          domain: r?.network.domain || "",
          onOutcome: Ko(t),
          children: d(tr, { ...e, trackerService: t }),
        });
  }
  const Ds = {
      "thumbnail-wrapper": "_thumbnail-wrapper_6fmrl_1",
      thumbnail: "_thumbnail_6fmrl_1",
    },
    mb = ({ style: e }) => {
      const t = he(),
        r = H(),
        n = O(void 0),
        a = ot();
      if (!r || !r.mainImage?.img.url) return null;
      let i = !1;
      a && (i = !!a.creative.isi);
      const o = O(null),
        c = r.mainImage?.img.url;
      return (
        A(() => {
          let l = null;
          return (
            o.current &&
              (l = Wt({
                element: o.current,
                timeoutIdRef: n,
                inViewPixels: 1,
                outOfViewPixels: 0,
                inViewCallback: () => {
                  t?.trackPixelVisible();
                },
              })),
            () => {
              l?.disconnect();
            }
          );
        }, [o]),
        d("div", {
          ref: o,
          className: `${Ds["thumbnail-wrapper"]} ${
            i ?? "str-thumbnail-wrapper-isi"
          }`,
          children: d("img", {
            "data-testid": "main-image",
            className: `str-thumbnail ${Ds.thumbnail}`,
            src: c,
            style: { ...e },
            "data-str-thumbnail": !0,
          }),
        })
      );
    },
    Hn = class Hn extends cn {
      constructor(t) {
        super(t),
          (this.trackerService = null),
          (this.measurementCore = null),
          (this.handleAdClick = (r) => {
            if (
              r.event.target instanceof HTMLElement &&
              !this.isValidClickTarget(r.event.target)
            )
              return;
            const n =
              r.event.target instanceof HTMLElement &&
              r.event.target.dataset.strThumbnail === "true"
                ? r.event.target
                : this.element;
            if ((this.trackerService?.trackClick(n), r.redirectUrl)) {
              window.open(r.redirectUrl, "_blank");
              return;
            }
            const a = this.butlerResponse?.creative;
            let o = this.payload.creative.link;
            if (
              (a && (o = sd(a.mediaUrl, a.mediaUrlToken, a.mediaUrlNonce)),
              a?.clickoutSamePage)
            ) {
              od(o);
              return;
            }
            window.open(o, "_blank");
          }),
          (this.state = { clickEventFired: !1 }),
          (this.element = null),
          (this.trackerService = t.trackerService);
      }
      componentDidMount() {
        if (
          (this.trackerService?.trackImpression(
            this.element?.parentElement,
            this.lifecycleScope
          ),
          Uu(this.props.adserverRequestId),
          !this.context)
        )
          return;
        const t = hs(this.context),
          r = _e(this.lifecycleScope, re.MeasuredImpression);
        t === ke.Embedded
          ? (this.measurementCore = this.trackerService
              ? ps(this.trackerService, r) ?? null
              : null)
          : t === ke.OnePixel &&
            this.element &&
            xs(this.context, r, this.element);
      }
      componentWillUnmount() {
        this.measurementCore?.teardown(), (this.measurementCore = null);
      }
      isValidClickTarget(t) {
        return !(
          t.classList.contains("str-opt-out-icon") ||
          t.classList.contains("str-green-pmp-icon") ||
          t.classList.contains("str-opt-out-label") ||
          t.classList.contains("str-subheader")
        );
      }
      render() {
        return (
          Sr(),
          d(G, {
            children: d("div", {
              className: "str-react-template",
              "data-testid": "str-clickout",
              onClick: (t) => this.handleAdClick({ event: t }),
              ref: (t) => {
                this.element = t;
              },
              children: d(yn, {
                creative: this.context.creative,
                network: this.context.network,
                country: this.context?.network.country,
                adserverRequestId: this.context?.id || "",
                onEnhancementClick: this.handleAdClick,
                children: d(mb, {}),
              }),
            }),
          })
        );
      }
    };
  Hn.contextType = At;
  let Tn = Hn;
  function Ps(e) {
    const t = he(),
      r = Q();
    return d(fo, {
      domain: r?.network.domain || "",
      onOutcome: Ko(t),
      children: d(Tn, { ...e, trackerService: t }),
    });
  }
  const fb = ue(null),
    rr = () => {
      const e = ae(fb),
        t = he();
      return e ?? t;
    },
    On = () => {
      const e = ot(),
        t = H(),
        r = t?.shoppable?.sponsoredBy ?? t?.sponsored?.data.value;
      if (!r) return null;
      const n = e?.creative.promotedByText ?? "Ad by";
      return d("div", {
        className: "str-retail-advertiser",
        children: [
          d("span", { className: "str-retail-promoted-by", children: n }),
          d("span", { className: "str-retail-advertiser-name", children: r }),
        ],
      });
    },
    Rn = () => {
      const t = H()?.icon;
      return t
        ? d("div", {
            className: "str-retail-brand-logo",
            children: d("img", {
              src: t.img.url,
              alt: "logo",
              className: "str-retail-brand-logo-img",
            }),
          })
        : null;
    },
    gb = (e) => {
      if (!e) return {};
      const t = {};
      return (
        e.textColor && (t["--cta-text-color"] = e.textColor),
        e.backgroundColor && (t["--cta-background-color"] = e.backgroundColor),
        e.textHoverColor && (t["--cta-text-hover-color"] = e.textHoverColor),
        e.backgroundHoverColor &&
          (t["--cta-background-hover-color"] = e.backgroundHoverColor),
        t
      );
    },
    Nn = () => {
      const e = H(),
        t = e?.cta;
      return t?.data
        ? d("button", {
            className: "str-retail-cta",
            type: "button",
            style: gb(e?.shoppable?.ctaStyle),
            children: t.data.value,
          })
        : null;
    },
    Dn = ({ product: e }) =>
      e?.description
        ? d("div", {
            className: "str-retail-description",
            children: e.description,
          })
        : null,
    zs = (e) => {
      const t = e.match(/^([^\d]*)(.+)$/);
      if (!t) return d(G, { children: e });
      const [, r, n] = t;
      return d(G, {
        children: [
          r && d("span", { className: "str-retail-price-symbol", children: r }),
          n,
        ],
      });
    },
    Pn = ({ product: e }) => {
      const { salePrice: t, originalPrice: r } = e ?? {},
        n = t || r;
      if (!n) return null;
      const a = t && r;
      return d("div", {
        className: "str-retail-price",
        children: [
          d("span", {
            className: a
              ? "str-retail-current-price str-retail-sale-price"
              : "str-retail-current-price",
            children: zs(n),
          }),
          a &&
            d("span", {
              className: "str-retail-original-price",
              children: zs(a),
            }),
        ],
      });
    },
    bb = ({ product: e }) => {
      const t = e?.images?.[0]?.url;
      return t
        ? d("div", {
            className: "str-retail-thumbnail",
            children: d("img", {
              src: t,
              alt: "",
              className: "str-retail-thumbnail-img",
            }),
          })
        : null;
    },
    zn = ({ product: e }) =>
      e?.name
        ? d("div", { className: "str-retail-title", children: e.name })
        : null,
    vb = () => {
      const e = Q(),
        t = H(),
        r = me(),
        n = rr(),
        a = le();
      if (
        (A(() => {
          const c = r.current?.parentElement;
          c && n?.trackImpression(c, a);
        }, []),
        !e || !t)
      )
        return null;
      const i = t.shoppable?.products[0];
      return d("div", {
        ref: r,
        className: "str-retail-shoppable-single-product-container",
        onClick: (c) => {
          const l = i?.link ?? e.creative.link;
          l && window.open(l, "_blank"), n?.trackClick(c.target);
        },
        children: [
          d("div", {
            className: "str-retail-shoppable-single-product",
            children: [
              d(bb, { product: i }),
              d("div", {
                className: "str-retail-shoppable-single-product-body",
                children: [
                  d(Pn, { product: i }),
                  d(zn, { product: i }),
                  d(Dn, { product: i }),
                ],
              }),
              d("div", {
                className: "str-retail-footer",
                children: [d(Rn, {}), d(On, {}), d(Nn, {})],
              }),
            ],
          }),
          d(Fe, { creative: e.creative, network: e.network }),
        ],
      });
    },
    _b = 3e3,
    wb = 6e3,
    yb = () =>
      typeof window < "u" &&
      typeof window.matchMedia == "function" &&
      window.matchMedia("(prefers-reduced-motion: reduce)").matches,
    Us = (e, t = _b, r = wb) => {
      const [n, a] = V(0),
        [i, o] = V(!1),
        c = O();
      A(() => {
        if (e <= 1 || i || yb()) return;
        const u = setTimeout(() => {
          a((p) => (p + 1) % e);
        }, t);
        return () => clearTimeout(u);
      }, [n, e, i, t]),
        A(() => () => clearTimeout(c.current), []);
      const l = (u) => {
        o(!0),
          clearTimeout(c.current),
          (c.current = setTimeout(() => o(!1), r)),
          a(e > 0 ? ((u % e) + e) % e : 0);
      };
      return {
        activeIndex: n,
        goTo: l,
        goNext: () => l(n + 1),
        goPrev: () => l(n - 1),
      };
    },
    xb = ({ images: e = [] }) => {
      const t = rr(),
        { activeIndex: r, goTo: n, goNext: a, goPrev: i } = Us(e.length);
      if (e.length === 0) return null;
      const o = e.length,
        c = (r - 1 + o) % o,
        l = (r + 1) % o,
        u = (m, f) => {
          m.stopPropagation(), t?.trackShoppableCarouselArrowClick(), n(f);
        },
        p = (m) => {
          m.stopPropagation(), t?.trackShoppableCarouselArrowClick(), i();
        },
        h = (m) => {
          m.stopPropagation(), t?.trackShoppableCarouselArrowClick(), a();
        };
      return d("div", {
        className: "str-retail-carousel",
        children: [
          d("div", {
            className: "str-retail-carousel-track",
            children: [
              o > 1 && d(Un, { image: e[c], position: "prev", onClick: p }),
              d(Un, { image: e[r], position: "active" }),
              o > 1 && d(Un, { image: e[l], position: "next", onClick: h }),
            ],
          }),
          o > 1 &&
            d("div", {
              className: "str-retail-carousel-dots",
              children: e.map((m, f) =>
                d(
                  "button",
                  {
                    className: `str-retail-carousel-dot${
                      f === r ? " active" : ""
                    }`,
                    onClick: (g) => u(g, f),
                  },
                  f
                )
              ),
            }),
        ],
      });
    },
    Un = ({ image: e, position: t, onClick: r }) =>
      d("div", {
        className: `str-retail-carousel-slide ${t}`,
        onClick: r,
        children: d("img", {
          src: e.url,
          alt: "",
          className: "str-retail-carousel-img",
        }),
      }),
    Eb = () => {
      const e = Q(),
        t = H(),
        r = me(),
        n = rr(),
        a = le();
      if (
        (A(() => {
          const c = r.current?.parentElement;
          c && n?.trackImpression(c, a);
        }, []),
        !e || !t)
      )
        return null;
      const i = t.shoppable?.products[0];
      return d("div", {
        ref: r,
        className: "str-retail-shoppable-single-product-carousel-container",
        onClick: (c) => {
          const l = i?.link ?? e.creative.link;
          l && window.open(l, "_blank"), n?.trackClick(c.target);
        },
        children: [
          d("div", {
            className: "str-retail-shoppable-single-product-carousel",
            children: [
              d(xb, { images: i?.images }),
              d("div", {
                className: "str-retail-shoppable-single-product-carousel-body",
                children: [
                  d(Pn, { product: i }),
                  d(zn, { product: i }),
                  d(Dn, { product: i }),
                ],
              }),
              d("div", {
                className: "str-retail-footer",
                children: [d(Rn, {}), d(On, {}), d(Nn, {})],
              }),
            ],
          }),
          d(Fe, { creative: e.creative, network: e.network }),
        ],
      });
    },
    Ab = 4,
    kb = () => {
      const e = Q(),
        t = H(),
        r = me(),
        n = rr(),
        a = le(),
        i = t?.shoppable?.products ?? [],
        { activeIndex: o, goTo: c, goNext: l, goPrev: u } = Us(i.length);
      if (
        (A(() => {
          const v = r.current?.parentElement;
          v && n?.trackImpression(v, a);
        }, []),
        !e || !t || i.length === 0)
      )
        return null;
      const p = i[o],
        h = i
          .map((v, x) => ({ product: v, index: x }))
          .filter((v) => v.index !== o)
          .slice(0, Ab),
        m = (v) => {
          v.stopPropagation();
          const x = p.link ?? e.creative.link;
          x && window.open(x, "_blank"), n?.trackClick(v.target);
        },
        f = (v, x) => {
          v.stopPropagation(), n?.trackShoppableCarouselArrowClick(), c(x);
        },
        g = (v, x) => {
          v.stopPropagation(), n?.trackShoppableCarouselArrowClick(), c(x);
        },
        w = (v) => {
          v.stopPropagation(), n?.trackShoppableCarouselArrowClick(), u();
        },
        y = (v) => {
          v.stopPropagation(), n?.trackShoppableCarouselArrowClick(), l();
        };
      return d("div", {
        ref: r,
        className: "str-retail-shoppable-carousel-container",
        onClick: m,
        children: [
          d("div", {
            className: "str-retail-shoppable-carousel",
            children: [
              d("div", {
                className: "str-retail-shoppable-carousel-active",
                children: [
                  d("button", {
                    className: "str-retail-shoppable-carousel-arrow prev",
                    onClick: w,
                    children: "‹",
                  }),
                  d("div", {
                    className: "str-retail-shoppable-carousel-active-img-stack",
                    children: i.map((v, x) =>
                      d(
                        "img",
                        {
                          src: v.images?.[0]?.url,
                          alt: v.name ?? "",
                          className: `str-retail-shoppable-carousel-active-img ${
                            x === o ? "active" : ""
                          }`,
                          onClick: m,
                        },
                        x
                      )
                    ),
                  }),
                  d("button", {
                    className: "str-retail-shoppable-carousel-arrow next",
                    onClick: y,
                    children: "›",
                  }),
                ],
              }),
              d("div", {
                className: "str-retail-shoppable-carousel-body",
                children: [
                  d(Pn, { product: p }),
                  d(zn, { product: p }),
                  d(Dn, { product: p }),
                ],
              }),
              d("div", {
                className: "str-retail-shoppable-carousel-thumbnails",
                children: h.map(({ product: v, index: x }) =>
                  d(
                    "img",
                    {
                      src: v.images?.[0]?.url,
                      alt: v.name ?? "",
                      className: "str-retail-shoppable-carousel-thumbnail",
                      onClick: (E) => f(E, x),
                    },
                    x
                  )
                ),
              }),
              i.length > 1 &&
                d("div", {
                  className: "str-retail-carousel-dots",
                  children: i.map((v, x) =>
                    d(
                      "button",
                      {
                        className: `str-retail-carousel-dot${
                          x === o ? " active" : ""
                        }`,
                        onClick: (E) => g(E, x),
                      },
                      x
                    )
                  ),
                }),
              d("div", {
                className: "str-retail-footer",
                children: [d(Rn, {}), d(On, {}), d(Nn, {})],
              }),
            ],
          }),
          d(Fe, { creative: e.creative, network: e.network }),
        ],
      });
    },
    Ms = (e) => {
      (e.completed.value = !0), (e.playing.value = !1);
    },
    nr = (e, t) => {
      e.playing.value = t;
    };
  var oe = ((e) => (
    (e.P25 = "25"), (e.P50 = "50"), (e.P75 = "75"), (e.P95 = "95"), e
  ))(oe || {});
  const Bs = (e, t) => {
      const r = e.getAdData();
      if (!r) return;
      if (
        ("duration" in r &&
          typeof r.duration == "number" &&
          t.duration.value !== r.duration &&
          (t.duration.value = r.duration),
        "currentTime" in r &&
          typeof r.currentTime == "number" &&
          t.currentTime.value !== r.currentTime &&
          (t.currentTime.value = r.currentTime),
        t.adVideoSource.value === void 0)
      ) {
        const o = document.querySelector("video:not(.blank-video)[src]");
        o && o.src && (t.adVideoSource.value = o.src);
      }
      const n = t.currentTime.value,
        a = t.duration.value;
      if (n && a && n / a >= 0.95) {
        if (n > a) return;
        t.currentQuartile.value !== oe.P95 &&
          (t.currentQuartile.value = oe.P95);
      }
    },
    qe = (e, t) => {
      e.currentQuartile.value !== t && (e.currentQuartile.value = t);
    },
    Ls = (e, t, r) => {
      e.getVolume() > 0 && e.setVolume(0),
        (r.completed.value = !1),
        (r.playing.value = !0),
        (r.started.value = !0);
      const n = Cb(t);
      n && n !== r.clickThroughUrl.value && (r.clickThroughUrl.value = n);
      const a = Sb(t);
      r.vpaid.value !== a && (r.vpaid.value = a);
      const i = Ib(r.adVideoSource.value);
      i && i !== r.adVideoHtmlElement.value && (r.adVideoHtmlElement.value = i);
    },
    Ib = (e) => (e ? document.querySelector(`video[src="${e}"]`) : null),
    Cb = (e) => {
      const t = e.getAd();
      if (t && "data" in t && typeof t.data == "object") {
        const { data: r } = t;
        if (r && "clickThroughUrl" in r && typeof r.clickThroughUrl == "string")
          return r.clickThroughUrl;
      }
    },
    Sb = (e) => {
      const t = e.getAd();
      if (t && "data" in t && typeof t.data == "object") {
        const { data: r } = t;
        if (r && "vpaid" in r) return !!r.vpaid;
      }
      return !1;
    },
    Vs = (e, t) => {
      const r = e.getAd();
      if (r && "data" in r && r.data && typeof r.data == "object") {
        const { data: n } = r;
        n !== null &&
          "volume" in n &&
          typeof n.volume == "number" &&
          (t.muted.value = n.volume === 0);
      }
    },
    Hs = (e, t) => {
      const r = e.getAd();
      if (!r) return;
      const n = r.getCreativeId(),
        a = r.getMediaUrl();
      n !== t.creativeId.value && (t.creativeId.value = n),
        a && a !== t.adVideoSource.value && (t.adVideoSource.value = a);
    },
    $s = (e, t) => {
      const r = e.getError();
      !r || !t || t(r);
    },
    Fs = (e) => {
      e.rendered.value = !0;
    },
    Tb = (e, t, r, n) => {
      try {
        const a = window.google.ima.AdEvent.Type,
          i = window.google.ima.AdErrorEvent.Type;
        e.addEventListener(a.LOADED, (o) => {
          Hs(o, t);
        }),
          e.addEventListener(a.AD_PROGRESS, (o) => {
            Bs(o, t);
          }),
          e.addEventListener(a.FIRST_QUARTILE, () => qe(t, oe.P25)),
          e.addEventListener(a.MIDPOINT, () => qe(t, oe.P50)),
          e.addEventListener(a.THIRD_QUARTILE, () => qe(t, oe.P75)),
          e.addEventListener(a.COMPLETE, () => Ms(t)),
          e.addEventListener(a.PAUSED, () => nr(t, !0)),
          e.addEventListener(a.RESUMED, () => nr(t, !1)),
          e.addEventListener(a.STARTED, (o) => Ls(e, o, t)),
          e.addEventListener(a.VOLUME_CHANGED, (o) => {
            Vs(o, t);
          }),
          e.addEventListener(i.AD_ERROR, (o) => $s(o, n)),
          e.addEventListener(a.CLICK, (o) => r()),
          e.addEventListener(a.IMPRESSION, () => Fs(t));
      } catch (a) {
        if (!n) return;
        n(a instanceof Error ? a : new Error(String(a)));
      }
    },
    Ob = (e, t, r, n) => {
      try {
        const a = window.google.ima.AdEvent.Type,
          i = window.google.ima.AdErrorEvent.Type;
        e.removeEventListener(a.LOADED, (o) => {
          Hs(o, t);
        }),
          e.removeEventListener(a.AD_PROGRESS, (o) => {
            Bs(o, t);
          }),
          e.removeEventListener(a.FIRST_QUARTILE, () => qe(t, oe.P25)),
          e.removeEventListener(a.MIDPOINT, () => qe(t, oe.P50)),
          e.removeEventListener(a.THIRD_QUARTILE, () => qe(t, oe.P75)),
          e.removeEventListener(a.COMPLETE, () => Ms(t)),
          e.removeEventListener(a.PAUSED, () => nr(t, !0)),
          e.removeEventListener(a.RESUMED, () => nr(t, !1)),
          e.removeEventListener(a.STARTED, (o) => Ls(e, o, t)),
          e.removeEventListener(a.VOLUME_CHANGED, (o) => {
            Vs(o, t);
          }),
          e.removeEventListener(i.AD_ERROR, (o) => $s(o, n)),
          e.removeEventListener(a.CLICK, (o) => r),
          e.removeEventListener(a.IMPRESSION, () => Fs(t));
      } catch (a) {
        if (!n) return;
        n(a instanceof Error ? a : new Error(String(a)));
      }
    },
    Pe = "https://imasdk.googleapis.com/js/sdkloader/ima3.js",
    Mn = () => typeof window.google < "u" && typeof window.google.ima < "u",
    Rb = async () => {
      await Nb();
    },
    We = {},
    Nb = () =>
      We[Pe] != null
        ? We[Pe]
        : Mn()
        ? ((We[Pe] = Promise.resolve("")), We[Pe])
        : ((We[Pe] = new Promise((e, t) => {
            const r = document.createElement("script");
            (r.src = Pe), document.body.appendChild(r);
            const n = setInterval(() => {
              Mn() && (clearInterval(n), e(""));
            }, 100);
          })),
          We[Pe]),
    Db = /%%[A-Z_]+%%/g;
  function Pb(e) {
    return e.replace(Db, "");
  }
  class zb {
    constructor(t, r, n, a, i, o) {
      (this.browserSupportsAutoPlay = !1),
        (this._state = {
          adVideoHtmlElement: U(void 0),
          adVideoSource: U(void 0),
          clickThroughUrl: U(void 0),
          completed: U(!1),
          creativeId: U(void 0),
          currentQuartile: U(void 0),
          currentTime: U(void 0),
          duration: U(void 0),
          muted: U(!0),
          playing: U(!1),
          rendered: U(!1),
          started: U(!1),
          vpaid: U(void 0),
        }),
        (this.state = this._state),
        (this.afterAutoPlay = (c) => {
          (this.browserSupportsAutoPlay = c), this.requestAds();
        }),
        (this.adError = (c) => {
          const l = c.getError();
          this.onError &&
            this.onError(l instanceof Error ? l : new Error(String(l)));
        }),
        (this.requestAds = () => {
          try {
            this.videoElement.pause();
            const c = new window.google.ima.AdsRequest();
            this.vastUrl.match("</VAST>")
              ? (c.adsResponse = this.vastUrl)
              : (c.adTagUrl = this.vastUrl),
              (c.linearAdSlotWidth = this.dimensions.width),
              (c.linearAdSlotHeight = this.dimensions.height),
              (c.nonLinearAdSlotWidth = this.dimensions.width),
              (c.nonLinearAdSlotHeight = this.dimensions.height),
              c.setAdWillAutoPlay(this.browserSupportsAutoPlay),
              c.setAdWillPlayMuted(!0),
              this.adsLoader.requestAds(c);
          } catch (c) {
            if (!this.onError) return;
            this.onError(c instanceof Error ? c : new Error(String(c)));
          }
        }),
        (this.adsManagerLoaded = (c) => {
          try {
            const l = new window.google.ima.AdsRenderingSettings();
            if (
              ((l.uiElements = []),
              (l.enablePreloading = !0),
              (l.loadVideoTimeout = 16e3),
              (this.adsManager = c.getAdsManager(this.videoElement, l)),
              !this.adsManager)
            )
              throw new Error("AdsManager is not defined");
            this.adsManager.setVolume(0),
              Tb(this.adsManager, this._state, this.onClick, this.onError),
              this.initializeAds();
          } catch (l) {
            if (!this.onError) return;
            this.onError(l instanceof Error ? l : new Error(String(l)));
          }
        }),
        (this.assertAdsManager = () => {
          if (!this.adsManager)
            throw new Error(
              "AdsManager not initialized. Wait for ADS_MANAGER_LOADED event."
            );
          return this.adsManager;
        }),
        (this.initializeAds = () => {
          try {
            this.adDisplayContainer.initialize(),
              this.assertAdsManager().init(
                this.dimensions.width,
                this.dimensions.height,
                window.google.ima.ViewMode.NORMAL
              ),
              this.onInit();
          } catch (c) {
            if (!this.onError) return;
            this.onError(c instanceof Error ? c : new Error(String(c)));
          }
        }),
        (this.resetState = () => {
          (this._state.adVideoHtmlElement.value = void 0),
            (this._state.adVideoSource.value = void 0),
            (this._state.clickThroughUrl.value = void 0),
            (this._state.completed.value = !1),
            (this._state.vpaid.value = void 0),
            (this._state.creativeId.value = void 0),
            (this._state.currentQuartile.value = void 0),
            (this._state.currentTime.value = void 0),
            (this._state.duration.value = void 0),
            (this._state.muted.value = !0),
            (this._state.playing.value = !1),
            (this._state.started.value = !1);
        }),
        (this.video = {
          start: () => {
            try {
              this.assertAdsManager().start();
            } catch (c) {
              if (!this.onError) return;
              this.onError(c instanceof Error ? c : new Error(String(c)));
            }
          },
          resume: () => {
            try {
              this.assertAdsManager().resume();
            } catch (c) {
              if (!this.onError) return;
              this.onError(c instanceof Error ? c : new Error(String(c)));
            }
          },
          pause: () => {
            try {
              this.assertAdsManager().pause();
            } catch (c) {
              if (!this.onError) return;
              this.onError(c instanceof Error ? c : new Error(String(c)));
            }
          },
          volume: (c) => {
            try {
              this.assertAdsManager().setVolume(c);
            } catch (l) {
              if (!this.onError) return;
              this.onError(l instanceof Error ? l : new Error(String(l)));
            }
          },
          replay: () => {
            try {
              this.destroy(), this.resetState(), this.buildAdDisplayContainer();
            } catch (c) {
              if (!this.onError) return;
              this.onError(c instanceof Error ? c : new Error(String(c)));
            }
          },
        }),
        (this.destroy = () => {
          this.adsManager &&
            (Ob(this.adsManager, this._state, this.onClick, this.onError),
            this.adsManager.destroy()),
            this.adDisplayContainer?.destroy(),
            this.adsLoader?.destroy();
        }),
        (this.containerElement = r),
        (this.vastUrl = Pb(n)),
        (this.videoElement = t),
        (this.onInit = a),
        (this.onClick = i),
        (this.onError = o),
        this.initialize();
    }
    get dimensions() {
      return {
        width: this.containerElement.clientWidth,
        height: this.containerElement.clientHeight,
      };
    }
    async initialize() {
      try {
        Mn() || (await Rb()),
          window.google.ima.settings.setVpaidMode(
            window.google.ima.ImaSdkSettings.VpaidMode.ENABLED
          ),
          window.google.ima.settings.setDisableCustomPlaybackForIOS10Plus(!0),
          this.buildAdDisplayContainer();
      } catch (t) {
        if (!this.onError) return;
        this.onError(t instanceof Error ? t : new Error(String(t)));
      }
    }
    buildAdDisplayContainer() {
      try {
        (this.adDisplayContainer = new window.google.ima.AdDisplayContainer(
          this.containerElement,
          this.videoElement
        )),
          (this.adsLoader = new window.google.ima.AdsLoader(
            this.adDisplayContainer
          )),
          this.adsLoader.addEventListener(
            window.google.ima.AdsManagerLoadedEvent.Type.ADS_MANAGER_LOADED,
            this.adsManagerLoaded,
            !1
          ),
          this.adsLoader.addEventListener(
            window.google.ima.AdErrorEvent.Type.AD_ERROR,
            this.adError,
            !1
          );
        const t = this._state.muted.value;
        (this.videoElement.volume = t ? 0 : 1), (this.videoElement.muted = t);
        const r = this.videoElement.play();
        r !== void 0 &&
          r
            .then(() => this.afterAutoPlay(!0))
            .catch(() => this.afterAutoPlay(!1));
      } catch (t) {
        if (!this.onError) return;
        this.onError(t instanceof Error ? t : new Error(String(t)));
      }
    }
    get vpaid() {
      return this._state.vpaid.value;
    }
  }
  const Ub =
      "data:video/mp4;base64,AAAAGGZ0eXBpc29tAAAAAGlzb21tcDQxAAAACGZyZWUAAAAmbWRhdCELUCh9wBQ+4cAhC1AAfcAAPuHAIQtQAH3AAD7hwAAAAlNtb292AAAAbG12aGQAAAAAxzFHd8cxR3cAAV+QAAAYfQABAAABAAAAAAAAAAAAAAAAAQAAAAAAAAAAAAAAAAAAAAEAAAAAAAAAAAAAAAAAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADAAAAG2lvZHMAAAAAEA0AT////xX/DgQAAAACAAABxHRyYWsAAABcdGtoZAAAAAfHMUd3xzFHdwAAAAIAAAAAAAAYfQAAAAAAAAAAAAAAAAEAAAAAAQAAAAAAAAAAAAAAAAAAAAEAAAAAAAAAAAAAAAAAAEAAAAAAAAAAAAAAAAAAAWBtZGlhAAAAIG1kaGQAAAAAxzFHd8cxR3cAAKxEAAAL/xXHAAAAAAA0aGRscgAAAAAAAAAAc291bgAAAAAAAAAAAAAAAFNvdW5kIE1lZGlhIEhhbmRsZXIAAAABBG1pbmYAAAAQc21oZAAAAAAAAAAAAAAAJGRpbmYAAAAcZHJlZgAAAAAAAAABAAAADHVybCAAAAABAAAAyHN0YmwAAABkc3RzZAAAAAAAAAABAAAAVG1wNGEAAAAAAAAAAQAAAAAAAAAAAAIAEAAAAACsRAAAAAAAMGVzZHMAAAAAA4CAgB8AQBAEgICAFEAVAAYAAAANdQAADXUFgICAAhIQBgECAAAAGHN0dHMAAAAAAAAAAQAAAAMAAAQAAAAAHHN0c2MAAAAAAAAAAQAAAAEAAAADAAAAAQAAABRzdHN6AAAAAAAAAAoAAAADAAAAFHN0Y28AAAAAAAAAAQAAACg=",
    Gs = (e) => {
      const t = e.split(":");
      try {
        let r = t[2].split(",");
        return (
          r.length === 1 && (r = t[2].split(".")),
          parseFloat(t[0]) * 3600 +
            parseFloat(t[1]) * 60 +
            parseFloat(r[0]) +
            parseFloat(r[1]) / 1e3
        );
      } catch {
        return 0;
      }
    },
    Mb = (e, t) => {
      let r = t;
      for (; !e[r] || e[r].match(/^\s+$/); ) r++;
      return r;
    },
    Bb = (e) => {
      let t = e.length - 1;
      for (; t >= 0 && !e[t]; ) t--;
      return t;
    },
    Lb = (e = "") => {
      const t = [],
        r = e.split(/(?:\r\n|\r|\n)/gm),
        n = Bb(r) + 1;
      let a = 0,
        i,
        o;
      for (let c = 0; c < n; c++) {
        const l = { id: 0, start: 0, end: 0, text: "" };
        for (
          o = [],
            c = Mb(r, c),
            l.id = parseInt(r[c++], 10),
            i = r[c++].split(/[\t ]*-->[\t ]*/),
            l.start = Gs(i[0]),
            a = i[1].indexOf(" "),
            a !== -1 && (i[1] = i[1].substr(0, a)),
            l.end = Gs(i[1]);
          c < n && r[c] && !r[c].match(/^\s+$/);

        )
          o.push(r[c++]);
        (l.text = o
          .join("\\N")
          .replace(/\{(\\[\w]+\(?([\w\d]+,?)+\)?)+\}/gi, "")),
          (l.text = l.text.replace(/</g, "&lt;").replace(/>/g, "&gt;")),
          (l.text = l.text.replace(
            /&lt;(\/?(font|b|u|i|s))((\s+(\w|\w[\w\-]*\w)(\s*=\s*(?:".*?"|'.*?'|[^'">\s]+))?)+\s*|\s*)(\/?)&gt;/gi,
            "<$1$3$7>"
          )),
          (l.text = l.text.replace(/\\N/gi, "<br />")),
          t.push(l);
      }
      return t;
    },
    Vb = async (e, t) => {
      const r = typeof e == "string" ? e : e[t] || e.defaultSfaId;
      if (!r) throw new Error("No captions payload found");
      const n = r.indexOf("http") === 0 ? await Hb(r) : r;
      if (!n) return null;
      try {
        return Lb(n);
      } catch (a) {
        throw a instanceof Error
          ? ((a.message = `Error parsing captions: ${a.message}`), a)
          : `Error parsing captions: ${a}`;
      }
    },
    Hb = async (e) => (await fetch(e)).text(),
    Bn = ue(null),
    $b = ({ children: e }) => {
      const { enhancement: t } = st(),
        r = Q(),
        n = le(),
        a = ce(() => _e(n, re.Enhancement), [n]),
        [i, o] = V({
          currentTime: 0,
          currentSubtitle: null,
          srt: [],
          innerCreativeId: "",
          videoElement: void 0,
        });
      A(() => {
        if (
          r?.creative.type === "outstream" &&
          t?.payload?.srt &&
          i.innerCreativeId
        ) {
          const m = t?.payload.srt;
          Vb(m, i.innerCreativeId)
            .then((f) => {
              f && o((g) => ({ ...g, srt: f }));
            })
            .catch((f) => {
              R(f, { scope: a, adserverRequestId: r?.id });
            });
        }
      }, [t, t?.type, i.innerCreativeId, r]);
      const c = ce(
        () =>
          r?.creative.type !== "outstream" || !i.srt || i.srt.length === 0
            ? null
            : i.srt.find(
                (m) => i.currentTime >= m.start && i.currentTime <= m.end
              ),
        [i.currentTime, i.srt]
      );
      A(() => {
        c !== i.currentSubtitle &&
          c?.text !== i.currentSubtitle?.text &&
          o((m) => ({ ...m, currentSubtitle: c ?? null }));
      }, [c]);
      const h = {
        ...i,
        setInnerCreativeId: (m) => {
          o((f) => ({ ...f, innerCreativeId: m }));
        },
        setCurrentTime: (m) => {
          i.srt.length !== 0 && o((f) => ({ ...f, currentTime: m }));
        },
        setVideoElement: (m) => {
          o((f) => ({ ...f, videoElement: m }));
        },
      };
      return d(Bn.Provider, { value: h, children: e });
    },
    Fb = ({ muted: e, onClick: t, videoCompleted: r, videoStarted: n }) =>
      r || !n
        ? null
        : d("div", {
            className: $(
              "str-icon-wrapper",
              e ? "str-icon-mute" : "str-icon-sound"
            ),
            onClick: t,
            "data-testid": "mute-button",
          }),
    be = {
      adVideoSource: U(void 0),
      clickThroughUrl: U(void 0),
      completed: U(!1),
      currentTime: U(0),
      duration: U(0),
      muted: U(!0),
      playing: U(!1),
      started: U(!1),
      videoReplayed: U(!1),
    },
    Gb = ({ onReplay: e, videoCompleted: t, videoStarted: r, videoSrc: n }) => {
      if (!r || !n) return null;
      const a = (o) => {
          const c = o.target;
          c.currentTime = c.duration;
        },
        i = (o) => {
          o.stopPropagation(), e(o);
        };
      return d("div", {
        className: $("video-replay", t && "show"),
        "data-testid": "replay-wrapper",
        children: [
          d("video", { className: "replay-video", src: n, onLoadedData: a }),
          d("div", {
            className: "video-replay-container",
            children: [
              d("div", {
                className: "replay-icon",
                onClick: i,
                "data-testid": "replay-icon",
                children: d("div", { className: "img-icon " }),
              }),
              d("div", {
                className: "see-more-icon",
                children: d("div", { className: "img-icon" }),
              }),
            ],
          }),
        ],
      });
    },
    jb = (e, t, r, n) => {
      const a = n?.includes("shouldNotPauseOutOfView"),
        i = n?.includes("shouldPauseAtFiftyPercentOutOfView"),
        o = !a && i,
        c = n?.includes("shouldPauseAtFiftyPercentOutOfView") ? io : 0.01,
        l = n?.includes("shouldPauseAtFiftyPercentOutOfView") ? io : 0.01;
      Wt({
        element: t,
        inViewPercentage: l,
        outOfViewPercentage: c,
        inViewCallback: () => {
          r.value ? o && e.video.resume() : e.video.start();
        },
        outOfViewCallback: () => {
          o && e.video.pause();
        },
      });
    },
    ar = [3, 10, 15, 30],
    qb = (e, t, r, n, a, i, o, c) => {
      const { state: l } = e;
      let u;
      l.creativeId.subscribe((p) => {
        p && i(p);
      }),
        l.clickThroughUrl.subscribe((p) => {
          p && (t.clickThroughUrl.value = p);
        }),
        l.vpaid.subscribe((p) => {
          u = p;
        }),
        l.currentQuartile.subscribe((p) => {
          if (!p || !n || r) return;
          const m = {
            [oe.P25]: Je.Q25,
            [oe.P50]: Je.Q50,
            [oe.P75]: Je.Q75,
            [oe.P95]: Je.Q95,
          }[p];
          n.trackVideoQuartile(m);
        }),
        l.duration.subscribe((p) => {
          p && (t.duration.value = p);
        }),
        l.started.subscribe((p) => {
          p &&
            (r ||
              window.setTimeout(() => {
                n?.trackVpaidEnabled(!!u);
                const h = !!t.clickThroughUrl.value;
                n?.trackClickthroughFound(h);
              }, 400),
            (t.started.value = p));
        }),
        l.adVideoHtmlElement.subscribe((p) => {
          p && o(p);
        }),
        l.adVideoSource.subscribe((p) => {
          p && (t.adVideoSource.value = p);
        }),
        l.currentTime.subscribe((p) => {
          if (p !== void 0 && ((t.currentTime.value = p), a(p), !r)) {
            for (let h = ar.length - 1; h >= 0; h--)
              if (p >= ar[h]) {
                n?.trackSilentAutoPlayDuration(ar[h]), ar.splice(h, 1);
                break;
              }
          }
        }),
        l.muted.subscribe((p) => {
          (t.muted.value = p),
            !r &&
              !p &&
              t.currentTime.value > 0 &&
              n?.trackVideoVolumeOn(t.currentTime.value);
        }),
        l.playing.subscribe((p) => {
          (t.playing.value = p), p && !r && (n?.trackVideoPlay(), c());
        }),
        l.completed.subscribe((p) => {
          if (((t.completed.value = p), p && n && !r)) {
            const h = t.duration.value,
              m = t.currentTime.value,
              f = t.muted.value,
              g = h - m,
              w = g >= 0 ? h - g : h;
            n.trackVideoViewDuration(w, f);
          }
        }),
        l.rendered.subscribe((p) => {
          p && n && !r && n.trackVideoStart(!0);
        });
    },
    js = (e, t) => e.querySelector(t)?.textContent?.trim() || void 0,
    Wb = (e) => {
      if (!e) return;
      if (!e.includes("</VAST>")) return e;
      const t = new DOMParser().parseFromString(e, "text/xml");
      return js(t, "VASTAdTagURI") ?? js(t, "MediaFile");
    },
    Yb = (e, t, r, n) => {
      if (
        "data" in e &&
        e.data &&
        typeof e.data == "object" &&
        "errorCode" in e.data &&
        typeof e.data.errorCode == "number"
      ) {
        const { errorCode: i } = e.data;
        if ([301, 302, 303, 400, 401, 402, 403, 602, 901].includes(i)) {
          t?.trackVastError(i, r);
          return;
        }
      } else t?.trackVideoFailedToPlay();
      const a = Wb(n?.vastSource);
      R(e, {
        scope: r,
        context: "native-outstream/ima-ad-error",
        function: "@ad-rendering/ima-sdk:imaErrorHandler",
        ...(a ? { endpoint: a } : {}),
      });
    };
  class Xb extends cn {
    constructor(t) {
      super(t),
        (this.state = { replayed: !1 }),
        (this.impressionFired = !1),
        (this.imaSDK = null),
        (this.trackerService = null),
        (this.refVastVideo = me()),
        (this.refNativeOutstreamContainer = this.props.containerRef ?? me()),
        (this.refVastContainer = me()),
        (this.refThumbnailContainer = me()),
        (this.handleAdClick = (r) => {
          if (!(r.event.target instanceof HTMLElement)) return;
          const { videoReplayed: n } = be;
          if (
            (n.value || this.trackerService?.trackUserShare(), r.redirectUrl)
          ) {
            window.open(r.redirectUrl, "_blank");
            return;
          }
          if (
            !(
              r.event.target &&
              (r.event.target.tagName === "IFRAME" ||
                r.event.target.classList.contains("icon-play-button"))
            ) &&
            (this.mainContainerParent &&
              this.trackerService?.trackClick(this.mainContainerParent),
            be.clickThroughUrl.value &&
              window.open(be.clickThroughUrl.value, "_blank"),
            this.imaSDK?.vastUrl && this.imaSDK?.vastUrl.match(/<vast/i))
          ) {
            const a = this.imaSDK?.vastUrl.match(
                /<VideoClicks>.*?<\/VideoClicks>/m
              ),
              i = new DOMParser();
            a &&
              i
                .parseFromString(a[0], "text/xml")
                .firstChild?.childNodes.forEach((c) => {
                  c.textContent &&
                    c.nodeName !== "ClickThrough" &&
                    new M({ url: c.textContent });
                });
          }
        }),
        (this.trackRenderedImpression = () => {
          this.mainContainerParent &&
            this.trackerService &&
            !this.impressionFired &&
            (this.trackerService.trackImpression(
              this.mainContainerParent,
              this.lifecycleScope
            ),
            (this.impressionFired = !0));
        }),
        (this.imaClickHandler = () => {
          const { trackerService: r } = this;
          r &&
            (this.mainContainerParent && r.trackClick(this.mainContainerParent),
            r.trackImaClick(),
            this.state.replayed ||
              r.trackAutoplayVideoEngagement(be.currentTime.value));
        }),
        (this.imaLoader = async () => {
          const { current: r } = this.refVastVideo,
            { current: n } = this.refVastContainer;
          if (!r || !n) return;
          const a =
            typeof this.payload.creative.content == "string"
              ? this.payload.creative.content
              : "";
          if (a) {
            const i = _e(this.lifecycleScope, re.Playback);
            this.imaSDK = new zb(
              r,
              n,
              a,
              this.imaInitializeHandler,
              this.imaClickHandler,
              (o) => Yb(o, this.trackerService, i, { vastSource: a })
            );
          } else
            console.warn(
              "VAST content is not available for IMA SDK initialization."
            );
        }),
        (this.setCaptionContextCurrentTime = (r) => {
          this.props.captionsContext?.setCurrentTime?.(r);
        }),
        (this.setCaptionContextCreativeId = (r) => {
          this.props.captionsContext?.setInnerCreativeId?.(r);
        }),
        (this.setCaptionContextVideoElement = (r) => {
          this.props.captionsContext?.setVideoElement?.(r);
        }),
        (this.imaInitializeHandler = () => {
          const { imaSDK: r } = this;
          if (!r) {
            console.warn("IMA SDK is not initialized.");
            return;
          }
          qb(
            r,
            be,
            this.state.replayed,
            this.trackerService,
            this.setCaptionContextCurrentTime,
            this.setCaptionContextCreativeId,
            this.setCaptionContextVideoElement,
            this.trackRenderedImpression
          ),
            this.refVastContainer.current
              ? jb(
                  r,
                  this.refVastContainer.current,
                  be.started,
                  this.payload.creative.behaviors
                )
              : console.warn(
                  "VAST container reference is not available for inview video handler."
                );
        }),
        (this.handleMute = (r) => {
          r.stopPropagation(),
            this.imaSDK && this.imaSDK.video.volume(be.muted.value ? 1 : 0);
        }),
        (this.handleReplay = async (r) => {
          r.stopPropagation(),
            this.setState({ replayed: !0 }),
            (be.started.value = !1),
            this.imaSDK && this.imaSDK.video.replay();
        }),
        (this.windowFocusHandler = () => {
          const { started: r } = be;
          this.imaSDK && r.value && this.imaSDK.video.resume();
        }),
        (this.trackerService = t.trackerService);
    }
    get mainContainerParent() {
      return this.refNativeOutstreamContainer.current?.parentElement ?? null;
    }
    componentDidUpdate() {
      this.trackRenderedImpression();
    }
    componentDidMount() {
      this.imaLoader(), this.trackRenderedImpression();
      try {
        (window.top || window).addEventListener("focus", () =>
          this.windowFocusHandler()
        );
      } catch {
        window.addEventListener("focus", () => this.windowFocusHandler());
      }
    }
    componentWillUnmount() {
      this.imaSDK && this.imaSDK.destroy();
      try {
        (window.top || window).removeEventListener("focus", () =>
          this.windowFocusHandler()
        );
      } catch {
        window.removeEventListener("focus", () => this.windowFocusHandler());
      }
    }
    render() {
      Sr();
      const { completed: t, started: r, muted: n, adVideoSource: a } = be;
      return d(G, {
        children: d("div", {
          ref: this.refNativeOutstreamContainer,
          onClick: (i) => this.handleAdClick({ event: i }),
          className: "str-vast-container str-react-template",
          children: d(yn, {
            creative: this.payload.creative,
            network: this.payload.network,
            country: this.payload.network.country,
            className: $(t && "video-completed"),
            adserverRequestId: this.props.adserverRequestId,
            onEnhancementClick: this.handleAdClick,
            children: d("div", {
              className:
                "str-thumbnail-wrapper str-thumbnail-wrapper-outstream",
              style: {
                maxHeight: this.payload.network.size.height,
                maxWidth: this.payload.network.size.width,
              },
              children: d("div", {
                className: "str-thumbnail",
                ref: this.refThumbnailContainer,
                children: [
                  d(Fb, {
                    muted: n.value,
                    videoCompleted: t.value,
                    videoStarted: r.value,
                    onClick: this.handleMute,
                  }),
                  d("div", {
                    className: $("str-video-container", t && "video-completed"),
                    children: [
                      d("div", {
                        className: "video-wrapper",
                        ref: this.refVastContainer,
                      }),
                      d("video", {
                        playsInline: !0,
                        className: "blank-video",
                        ref: this.refVastVideo,
                        src: Ub,
                        preload: "metadata",
                      }),
                      d(Gb, {
                        videoSrc: a.value,
                        videoStarted: r.value,
                        videoCompleted: t.value,
                        onReplay: this.handleReplay,
                      }),
                    ],
                  }),
                ],
              }),
            }),
          }),
        }),
      });
    }
  }
  function Kb(e) {
    const t = ae(Bn),
      r = he(),
      n = Q(),
      a = O(null),
      i = O(void 0);
    return (
      A(() => {
        let o = null,
          c = !1;
        const l = () =>
            !a.current || document.hidden || c
              ? null
              : Wt({
                  element: a.current,
                  timeoutIdRef: i,
                  inViewPixels: 1,
                  outOfViewPixels: 0,
                  inViewCallback: () => {
                    !document.hidden &&
                      !c &&
                      (r?.trackPixelVisible(),
                      (c = !0),
                      o?.disconnect(),
                      (o = null));
                  },
                }),
          u = () => {
            document.hidden
              ? (o && (o.disconnect(), (o = null)),
                i.current &&
                  (window.clearTimeout(i.current), (i.current = void 0)))
              : !o && !c && (o = l());
          };
        return (
          (o = l()),
          document.addEventListener("visibilitychange", u),
          () => {
            o?.disconnect(),
              document.removeEventListener("visibilitychange", u);
          }
        );
      }, [r]),
      d(Xb, {
        ...e,
        payload: n,
        captionsContext: t,
        trackerService: r,
        containerRef: a,
      })
    );
  }
  const Qb = (e) => {
    const t = e.filter((r) => r.indexOf("cdn.doubleverify.com") >= 0);
    return t.length ? t[0] : null;
  };
  class Jb extends se {
    constructor(t) {
      super(t),
        (this.element = null),
        (this.singleClickUsed = !1),
        (this.adUnitAttrs = () => {
          const r = this.payload.network.networkId,
            n = this.payload.id;
          return {
            "data-str-native-key": r,
            "data-str-visited-flag": "true",
            "data-str-arid": n,
            "data-str-rendered": Date.now().toString(),
          };
        }),
        ne.value?.trackExperiment(),
        (this.payload = t.payload),
        (this.lifecycleScope = Na(t.payload?.id));
    }
    get creativeType() {
      return this.payload
        ? this.payload.creative.type === N.Native
          ? this.payload.creative.nativeType
          : this.payload.creative.type
        : this.props.response?.creative.action;
    }
    get behaviors() {
      return this.payload
        ? this.payload.creative.behaviors?.reduce(
            (t, r) => ((t[r] = !0), t),
            {}
          ) || {}
        : {};
    }
    get dvTracker() {
      const t = this.payload?.creative.jsTrackers;
      return t ? Qb(t) : null;
    }
    get placementSizeStyles() {
      const t = this.payload?.network?.size || { width: null, height: null };
      return { maxHeight: t.height || "auto", maxWidth: t.width || "auto" };
    }
    componentDidCatch(t) {
      R(t, {
        scope: this.lifecycleScope,
        function: "src/tag/models/ReactAdUnit:componentDidCatch",
        adserverRequestId: this.payload.id,
      });
    }
    componentDidMount() {
      Dt() && ne.value?.trackFriendlyIframeEnv(),
        J.isSafeFrame() && J.register();
    }
    getAdUnitStyles(t, r, n) {
      return {
        width: n ? void 0 : t,
        height: r,
        maxWidth: t,
        maxHeight: r,
        minWidth: n ? void 0 : t,
        minHeight: n ? void 0 : r,
      };
    }
    render() {
      const t = this.payload?.network?.size?.width || "auto",
        r = this.payload?.network?.size?.height || "auto",
        n = this.getAdUnitStyles(t, r, Ke(this.payload?.network?.callerId));
      As(this.payload) && Dt() && (n.maxHeight = "100vh");
      const a = bs(this.payload);
      return d("div", {
        className: $(
          `str-ad-unit str-ad-type-${this.payload.creative.type} str-responsive-ad`,
          a
        ),
        "data-testid": "str-react-ad-unit",
        ref: (i) => {
          this.element = i;
        },
        ...this.adUnitAttrs(),
        style: n,
        children: d($b, { children: this.experienceToRender() }),
      });
    }
  }
  const Zb = (e) => {
      if (!e.current) return null;
      const t = window.frameElement;
      if (!t) return null;
      const r = t.getBoundingClientRect(),
        n = window.top?.innerWidth ?? window.innerWidth,
        a = window.top?.innerHeight ?? window.innerHeight,
        i =
          Math.round(
            (window.top?.devicePixelRatio ?? window.devicePixelRatio) * 100
          ) / 100;
      return {
        top: r.top,
        bottom: r.bottom,
        left: r.left,
        right: r.right,
        vp_w: n,
        vp_h: a,
        zoom_ratio: i,
      };
    },
    ev = (e, t, r, n = !0) => {
      A(() => {
        if (!n) return;
        const a = e.current;
        if (a)
          return (
            a.addEventListener("mouseenter", t),
            a.addEventListener("mouseleave", r),
            () => {
              a.removeEventListener("mouseenter", t),
                a.removeEventListener("mouseleave", r);
            }
          );
      }, [e.current, t, r, n]);
    },
    tv = (e, t, r, n = !0) => {
      const a = O(null);
      A(() => {
        if (!(!n || !e.length))
          return (
            a.current && clearTimeout(a.current),
            (a.current = setTimeout(() => {
              t(e);
            }, r)),
            () => {
              a.current && clearTimeout(a.current);
            }
          );
      }, [e, r, t, n]);
    },
    rv = (e, t, r = !0) => {
      const n = O([]),
        a = O(""),
        i = fe(() => {
          r &&
            nv({
              containerRef: e,
              rawSnapshotsRef: n,
              lastSnapshotRef: a,
              maxSnapshots: t,
            });
        }, [e, n, a, t, r]);
      return (
        A(() => {
          if (!r) return;
          const o = setInterval(i, 1e3);
          return i(), () => clearInterval(o);
        }, [i, r]),
        { getRawSnapshot: () => n.current }
      );
    },
    nv = ({
      containerRef: e,
      rawSnapshotsRef: t,
      lastSnapshotRef: r,
      maxSnapshots: n,
    }) => {
      const a = Zb(e);
      if (!a) return;
      const i = JSON.stringify(a);
      if (i !== r.current) {
        (r.current = i),
          t.current &&
            t.current.length >= n &&
            (t.current = t.current.slice(-(n - 1)));
        const o = { timestamp: Date.now(), data: a };
        t.current?.push(o);
      }
    };
  function av(e, t) {
    return e.map((r) => {
      const n = Math.round(r.timestamp / 1e3) - t;
      let a = 0,
        i = 0,
        o = 0,
        c = 0,
        l = 1;
      return (
        r.data &&
          ((a = Math.round(r.data.left * 100) / 100),
          (i = Math.round(r.data.top * 100) / 100),
          (o = r.data.vp_w),
          (c = r.data.vp_h),
          (l = r.data.zoom_ratio)),
        { ts_offset: n, vp_w: o, vp_h: c, x: a, y: i, zoom_ratio: l }
      );
    });
  }
  function iv({
    trackerService: e,
    enabled: t = !0,
    timeoutDuration: r = 5e3,
    waitSeconds: n = 5,
    stepInterval: a = 1e3,
  }) {
    const i = O(null),
      o = O(Math.floor(Date.now() / 1e3)),
      c = a / 1e3,
      l = O(0),
      u = O(!1),
      p = O(null),
      h = O(0),
      m = O(0),
      f = (_) => Math.round(_ * 100) / 100,
      g = fe((_) => {
        if (u.current && p.current != null) {
          const k = (_ - p.current) / 1e3;
          (h.current += k),
            k > m.current && (m.current = k),
            (p.current = null),
            (u.current = !1);
        }
      }, []),
      w = fe(() => {
        u.current ||
          ((u.current = !0), (p.current = performance.now()), (l.current += 1));
      }, []),
      y = fe(() => {
        g(performance.now());
      }, [g]),
      x = fe(() => t && Dt(), [t])();
    ev(i, w, y, x);
    const E = rv(i, n, x);
    return (
      tv(
        E.getRawSnapshot(),
        (_) => {
          if (e?.trackAttentionMetrics) {
            g(performance.now());
            const k = av(_, o.current);
            let T = 0,
              P = 0;
            _.length > 0 &&
              _[0].data &&
              ((T = _[0].data.right - _[0].data.left),
              (P = _[0].data.bottom - _[0].data.top));
            const W = f(h.current),
              Y = f(m.current);
            e.trackAttentionMetrics({
              init_ts: o.current,
              wait: n,
              step: c,
              ad_w: T,
              ad_h: P,
              hovers: l.current,
              hover_cumulative_time: W,
              hover_consecutive_time: Y,
              data: k,
            });
          }
        },
        r,
        x
      ),
      { containerRef: i }
    );
  }
  class ov extends Jb {
    constructor() {
      super(...arguments),
        (this.experienceToRender = () => {
          const t = this.payload.id,
            r = this.payload.creative;
          try {
            const n = {
                [N.Banner]: () => d(hb, { adserverRequestId: t }),
                [N.Outstream]: () => d(Kb, { adserverRequestId: t }),
                [N.Native]: () => {
                  if (pc(r.partnerId)) return d(Ep, { adserverRequestId: t });
                  const o = zt.value?.shoppable?.format;
                  return o === "single_product"
                    ? d(vb, { adserverRequestId: t })
                    : o === "single_product_carousel"
                    ? d(Eb, { adserverRequestId: t })
                    : o === "multi_product_carousel"
                    ? d(kb, { adserverRequestId: t })
                    : d(Ps, { adserverRequestId: t });
                },
              },
              a = r.type,
              i = n[a];
            if (!i)
              throw new Error(
                `creative type ${a} does not match any known types`
              );
            return i();
          } catch (n) {
            return (
              R(n, {
                scope: this.lifecycleScope,
                context: "ad-unit/creative-render-error",
                adserverRequestId: this.payload.id,
              }),
              console.error(
                "Failed to render creative, falling back to Clickout",
                n
              ),
              d(Ps, { adserverRequestId: this.payload.id })
            );
          }
        });
    }
  }
  function sv(e) {
    const t = Q(),
      r = he(),
      [n] = kt(),
      a = le(),
      i = !0,
      { containerRef: o } = iv({ trackerService: r || void 0, enabled: i });
    if (!t || n) {
      const c = { scope: a, adserverRequestId: e.id };
      return t || R("No payload found", c), n && R(n, c), null;
    }
    return d(ov, { ...e, payload: t, containerRef: o });
  }
  const cv = (e, t, r, n, a) => {
      const i = n.renderService,
        o = [
          [dc, { configuration: n.configurationService }],
          [cl, { payload: r }],
          [Wl, { id: r.id, trackerService: n.trackerService }],
          [Dr, { scope: a }],
        ];
      i?.render(t, r, e, o, sv, a);
    },
    qs = async (e, t) => {
      const r = mu(e) ?? {},
        n = new yt(re.Placeholder),
        a =
          e.getAttribute("data-gc-id") ??
          e.getAttribute("data-stx-response-name");
      if (!a) {
        R(new Error("Missing data-gc-id or data-stx-response-name attribute"), {
          scope: n,
          context: "tag/ad:bootAd/missing response name",
          placeholderAttributes: e.dataset || "missing",
          ...r,
        });
        return;
      }
      n.identify({ id: a }), n.enter(re.Payload);
      let i = null;
      try {
        jc();
        const o = nd(a, n);
        (i = t.payloadService.initialize(o, n)),
          n.identify(il(i)),
          al(i.id, n),
          iu(a, e, t.trackerService, n.track(re.Creative)),
          t.trackerService.mergeMetadata({ payload: i }),
          Ze() && (wd(i), _d());
      } catch (o) {
        o instanceof Error &&
          R(o, {
            scope: n,
            context: "tag/ad:bootAd/fetch ad",
            id: a,
            payload: i,
            placeholderAttributes: e.dataset || "missing",
            ...r,
          });
        return;
      }
      i.creative.assetsurl && (n.enter(re.Assets), await Zu(i, n)),
        t.trackerService.trackImpressionReceived(),
        n.enter(re.Creative);
      try {
        cv(e, null, i, t, n);
      } catch (o) {
        o instanceof Error &&
          R(o, {
            scope: n,
            context: "tag/ad:bootAd/ad rendering",
            payload: i,
            ...r,
          });
      }
    };
  window.bootAd = qs;
  const lv = (e) => {
      window.STR ||
        (window.STR = {
          debug: Xl("str_debug"),
          Tag: {
            boot: () => Ws(e),
            singleAdBoot: () =>
              console.log(
                "singleAdBoot is not available in Equativ GroundControl instance"
              ),
          },
          Uid: { xandr: "", criteo: "", ttd: "" },
        });
    },
    Ln = new yt(re.Load),
    Ws = (e) => Cu(e, qs, Ln),
    Ys = async (e) => {
      lv(e);
      try {
        await Ws(e);
      } catch (t) {
        (t instanceof Error || typeof t == "string") &&
          (R(t, { scope: Ln, function: "tag/index:main" }), console.error(t));
      }
    },
    dv = (e) => {
      let t = "";
      try {
        const r = document.querySelector("[data-gc-payload]");
        r ? (t = Li(r).trackerBaseUrl) : (t = window.tracker_base_url);
      } catch {
        t = window.tracker_base_url;
      }
      e.trackerService.trackGroundControlLoaded({
        env: "eqt",
        trackerBaseUrl: t,
      }),
        (ne.value = e.trackerService);
      try {
        (
          document.attachEvent
            ? document.readyState === "complete"
            : document.readyState !== "loading"
        )
          ? Ys(e)
          : document.addEventListener("DOMContentLoaded", () => Ys(e));
      } catch (r) {
        (r instanceof Error || typeof r == "string") &&
          R(r, { scope: Ln, function: "tag/index:gc" });
      }
    },
    Xs = {
      "300x250": ["250x250", "300x250", "336x280"],
      "320x100": ["300x50", "320x50"],
      "728x90": ["120x100", "300x50", "320x100", "320x50"],
      "970x250": ["250x250", "300x250", "320x250", "336x228", "728x90"],
    },
    Ks = {
      "160x600": ["160x600", "120x600"],
      "300x250": ["300x50", "320x50"],
      "300x600": ["160x600", "300x250", "300x600"],
    },
    uv = (e, t) => {
      if (!e || !t) return null;
      const r = `${e.size.width}x${e.size.height}`,
        n = `${t.size.width}x${t.size.height}`;
      return Ks[n] && Ks[n].includes(r)
        ? "vertical"
        : Xs[n] && Xs[n].includes(r)
        ? "horizontal"
        : null;
    },
    pv = () => {
      const {
        assets: e,
        enhancement: t,
        language: r,
        onError: n,
        onLoad: a,
        payload: i,
        publisherStyles: o,
      } = ut();
      if (!t || !i) return null;
      const c = uv(i.creative, i.network);
      return d(Fm, {
        assets: e,
        enhancement: t,
        language: r,
        layout: c,
        onClick: () => {},
        onError: n,
        onLoad: a,
        publisherStyles: o,
      });
    };
  pt(
    [
      b.GCEnhancementType.BannerCountdown,
      b.GCEnhancementType.OutstreamCountdown,
    ],
    pv
  );
  const hv = () => {
    const {
      assets: e,
      enhancement: t,
      language: r,
      onError: n,
      onLoad: a,
      publisherStyles: i,
    } = ut();
    return t
      ? d(Am, {
          assets: e,
          enhancement: t,
          language: r,
          onClick: () => {},
          onError: n,
          onLoad: a,
          publisherStyles: i,
        })
      : null;
  };
  pt(
    [
      b.GCEnhancementType.BannerWeather,
      b.GCEnhancementType.BannerDailyWeatherOutlook,
      b.GCEnhancementType.OutstreamWeather,
      b.GCEnhancementType.OutstreamDailyWeatherOutlook,
    ],
    hv
  );
  const mv = () => {
    const e = ot(),
      t = ae(Bn),
      {
        assets: r,
        enhancement: n,
        language: a,
        onError: i,
        onLoad: o,
        publisherStyles: c,
      } = ut(),
      [l, u] = V();
    return (
      A(() => {
        if (!n) return;
        const p = n
          ? n.payload.srt
          : e
          ? "srt" in e.creative
            ? e.creative.srt
            : {}
          : {};
        u(Object.keys(p || {}));
      }, [n]),
      !n || !t
        ? null
        : d(Gm, {
            assets: r,
            captionInnerCreativeId: t.innerCreativeId,
            currentCaption: t.currentSubtitle ? t.currentSubtitle.text : null,
            enhancement: n,
            innerCreativeIds: l,
            language: a,
            onClick: () => {},
            onError: i,
            onLoad: o,
            publisherStyles: c,
            videoElement: t.videoElement,
          })
    );
  };
  pt([b.GCEnhancementType.OutstreamCaptions], mv),
    dv({
      payloadService: new op(),
      trackerService: new sp(),
      configurationService: new Ju(),
      renderService: new dl(void 0),
      enhancementService: new ul(void 0),
    });
})();
//# sourceMappingURL=gc.js.map
