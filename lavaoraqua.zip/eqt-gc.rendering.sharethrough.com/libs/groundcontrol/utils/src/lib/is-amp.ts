// Is this an AMP page?
// After sampling high traffic AMP page URLs using Snowflake data,
// window["AMP_CONTEXT_DATA"] appears to be a reliable signal that the page is AMP
export function isAMP(win: Window = window): boolean {
  return Object.prototype.hasOwnProperty.call(win, 'AMP_CONTEXT_DATA');
}
