import { reportError } from '@web-rendering/groundcontrol-monitoring';
import type { LifecycleScope } from '@web-rendering/groundcontrol-shared-types/lifecycle/lifecycle';

import { decodePayloadString, getCachedPayload, getGcDataset } from './groundcontrol-utils';

export const getRawPayloadFromDataset = (id: string, scope: LifecycleScope) => {
  try {
    const gcDiv = document.querySelector<HTMLElement>(`[data-gc-id="${id}"]`);
    if (!gcDiv) {
      return null;
    }
    const gcDataset = getGcDataset(gcDiv);
    return decodePayloadString(gcDataset.payload);
  } catch (e) {
    reportError(e, { scope, context: 'payload-reader/get-raw-payload-from-dataset', id });
    return null;
  }
};

export const getRawPayload = (id: string, scope: LifecycleScope) => {
  try {
    const datasetPayload = getRawPayloadFromDataset(id, scope);

    const cachedPayload = datasetPayload ?? getCachedPayload(id);

    if (typeof cachedPayload === 'object' && cachedPayload !== null) {
      return cachedPayload;
    }

    const payloadString = decodePayloadString(cachedPayload);
    return JSON.parse(payloadString);
  } catch (e) {
    throw new Error(`Failed to parse payload for id "${id}": ${e instanceof Error ? e.message : String(e)}`);
  }
};
