import { trackerService } from '@web-rendering/groundcontrol-core';
import { getPayload } from '@web-rendering/groundcontrol-store';
import { CreativeType } from '@web-rendering/groundcontrol-shared-types';
import { OrtbEventType } from '@web-rendering/groundcontrol-ortb';

const intersectionRatio = 0.5;

const allAds = new Map();
let visibleAds = new Set<HTMLElement>();
let previouslyVisibleAds = new Set<HTMLElement>();

class InViewTracker {
  static startup() {
    document.addEventListener('visibilitychange', InViewTracker.handleVisibilityChange, false);
  }

  static handleVisibilityChange() {
    if (document.hidden) {
      if (previouslyVisibleAds.size === 0) {
        previouslyVisibleAds = new Set(visibleAds);
        visibleAds.clear();
        previouslyVisibleAds.forEach(function (adBox) {
          const trackedUnit = ViewTrackedAdUnit.retrieve(adBox);
          trackedUnit.comeOutOfView();
        });
      }
    } else {
      previouslyVisibleAds.forEach(function (adBox) {
        const trackedUnit = ViewTrackedAdUnit.retrieve(adBox);
        trackedUnit.comeInView();
      });
      visibleAds = new Set(previouslyVisibleAds);
      previouslyVisibleAds.clear();
    }
  }

  static intersectionCallback(entries: IntersectionObserverEntry[]) {
    entries.forEach(function (entry) {
      const adBox = entry.target as HTMLElement;
      const trackedUnit = ViewTrackedAdUnit.retrieve(adBox);

      if (entry.isIntersecting) {
        if (entry.intersectionRatio >= intersectionRatio) {
          trackedUnit.comeInView();
          visibleAds.add(adBox);
        } else {
          trackedUnit.comeOutOfView();
          visibleAds.delete(adBox);
        }
      } else {
        trackedUnit.comeOutOfView();
        visibleAds.delete(adBox);
      }
    });
  }

  // Used in spec only
  static getVisibleAds() {
    return visibleAds;
  }

  // Used in spec only
  static getPreviouslyVisibleAds() {
    return previouslyVisibleAds;
  }

  // Used in spec only
  static resetTrackedAds() {
    allAds.clear();
    visibleAds.clear();
    previouslyVisibleAds.clear();
  }
}

const generateKey = () => {
  return '_' + Math.random().toString(36).substr(2, 9);
};

const buildViewTrackedUnit = (element: HTMLElement, arid: string): ViewTrackedAdUnit => {
  // iOS in-app WebViews rendering the creative into an about:srcdoc iframe expose no
  // IntersectionObserver; construct it only when present so view tracking degrades to a
  // no-op instead of throwing and breaking the whole render.
  if (typeof IntersectionObserver === 'undefined') {
    return new ViewTrackedAdUnit(element, arid, null);
  }

  adObserver = new IntersectionObserver(InViewTracker.intersectionCallback, {
    root: null,
    rootMargin: '0px',
    threshold: [intersectionRatio]
  });

  return new ViewTrackedAdUnit(element, arid, adObserver);
};

class ViewTrackedAdUnit {
  element: HTMLElement;
  visibleFired: boolean;
  arid: string;
  timer: number | undefined;
  inViewTime = 1000;

  constructor(element: HTMLElement, arid: string, observer: IntersectionObserver | null) {
    this.element = element;
    this.visibleFired = false;
    this.arid = arid;
    this.timer = undefined;

    const { creative } = getPayload(arid);
    if (creative.type === CreativeType.Outstream) {
      this.inViewTime = 2000;
    }

    if (!element)
      // some browsers seem to lose the reference to the element, in which case there's no point tracking visibility
      // https://www.pivotaltracker.com/story/show/175752318
      return;

    const key = generateKey();

    element.dataset['trackingKey'] = key;
    allAds.set(key, this);
    observer?.observe(element);
  }

  static retrieve(element: HTMLElement): ViewTrackedAdUnit {
    return allAds.get(element.dataset['trackingKey']);
  }

  comeInView(): void {
    if (!this.visibleFired) {
      /* eslint-disable-next-line @typescript-eslint/no-this-alias */
      const that = this;
      this.timer = window.setTimeout(() => {
        that.fireVisible();
      }, this.inViewTime);
    }
  }

  comeOutOfView(): void {
    window.clearTimeout(this.timer);
    this.timer = undefined;
  }

  fireVisible(): void {
    trackerService.value?.trackViewableImpression();
    trackerService.value?.trackOrtbEvent(OrtbEventType.ViewableMrc50, this.element);
    this.visibleFired = true;
  }
}

let adObserver: IntersectionObserver | null = null;

export { buildViewTrackedUnit, InViewTracker, ViewTrackedAdUnit };
