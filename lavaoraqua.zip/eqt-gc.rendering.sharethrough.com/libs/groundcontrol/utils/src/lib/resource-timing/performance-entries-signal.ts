import { signal } from '@preact/signals';

export type PerformanceEntry = {
  type: string;
  name: string;
  userEvent: string;
  arid: string;
  requestTime: number;
  fetchTime: number;
  totalTime: number;
};

export const performanceEntriesSignal = signal<PerformanceEntry[]>([]);
