import type { Payload } from '@web-rendering/groundcontrol-core';
import { TrackerEventActionId } from '@web-rendering/groundcontrol-shared-types/tracker/tracker-event-action-id';
import { analyzeEntry, observeThirdPartyBeaconsPerformanceEntries } from './resource-timing';

/**
 * Checks if a URL matches the Equativ first-party beacon pattern
 * Matches:
 * - https://ssb-*.smartadserver.com/api/event or https://ssb-*.smartadserver.com/api/imp
 * - b-staging.sharethrough.com
 */
const isEquativFirstPartyBeacon = (url: string): boolean => {
  try {
    const urlObj = new URL(url);
    const hostname = urlObj.hostname;
    const pathname = urlObj.pathname;

    // Match b-staging.sharethrough.com only for beacon visualizer test purposes
    // As smartadserver.com doesn't have a staging domain
    if (hostname === 'b-staging.sharethrough.com') {
      return true;
    }

    const hostnameMatches = /^ssb-[^.]+\.smartadserver\.com$/.test(hostname);
    const pathnameMatches = pathname === '/api/event' || pathname === '/api/imp';

    return hostnameMatches && pathnameMatches;
  } catch (e) {
    return false;
  }
};

/**
 * Extracts the actionid from a URL and maps it to the corresponding TrackerEventActionId enum value name
 * Returns the enum key name (e.g., 'IsEnhanced') or 'impression' for /api/imp, or empty string if not found
 */
const getActionIdFromUrl = (url: string): string => {
  try {
    const urlObj = new URL(url);

    if (urlObj.pathname === '/api/imp') {
      return 'impression';
    }

    const actionid = urlObj.searchParams.get('actionid');
    if (!actionid) {
      return '';
    }

    const actionIdKey = Object.keys(TrackerEventActionId).find(
      (key) => TrackerEventActionId[key as keyof typeof TrackerEventActionId] === actionid
    );

    return actionIdKey || actionid;
  } catch (e) {
    return '';
  }
};

/**
 * Observes first-party Equativ beacons from smartadserver.com
 * Watches for:
 * - https://ssb-*.smartadserver.com/api/event?actionid=XXX (maps actionid to TrackerEventActionId)
 * - https://ssb-*.smartadserver.com/api/imp (impression events)
 */
export function observeFirstPartyEquativTrackersPerformanceEntries() {
  const observer = new PerformanceObserver((list) => {
    list
      .getEntries()
      .filter((entry): entry is PerformanceResourceTiming => entry instanceof PerformanceResourceTiming)
      .forEach((entry) => {
        if (isEquativFirstPartyBeacon(entry.name)) {
          const eventType = getActionIdFromUrl(entry.name);
          if (eventType) {
            analyzeEntry(entry, eventType);
          }
        }
      });
  });

  observer.observe({ type: 'resource', buffered: true });
}

/**
 * Iterates over Equativ payload trackers and sets up performance observation for third-party beacons
 * Similar to iterateAndObserveThirdPartyBeaconsPerformanceEntries but for Equativ payloads
 * Monitors network requests matching payload.creative.trackers
 */
export function iterateAndObserveEquativTrackersPerformanceEntries(payload: Payload): void {
  if (!payload.creative.trackers || payload.creative.trackers.length === 0) {
    return;
  }

  const trackersByEvent: Map<number, string[]> = new Map();

  payload.creative.trackers.forEach((tracker) => {
    const eventType = tracker.event;
    const url = tracker.url;

    if (!url) return;

    if (!trackersByEvent.has(eventType)) {
      trackersByEvent.set(eventType, []);
    }
    trackersByEvent.get(eventType)!.push(url);
  });

  trackersByEvent.forEach((urls, eventType) => {
    if (urls.length > 0) {
      observeThirdPartyBeaconsPerformanceEntries(urls, `event_${eventType}`);
    }
  });
}
