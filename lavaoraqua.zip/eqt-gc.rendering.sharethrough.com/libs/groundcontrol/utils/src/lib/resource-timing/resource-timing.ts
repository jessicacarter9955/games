import type { ButlerResponse, CreativeBeacons } from '@web-rendering/groundcontrol-shared-types';
import { performanceEntriesSignal } from './performance-entries-signal';
import { isTestEnvironment } from '../environment-info';

const getPerformanceEntryType = (entry: PerformanceEntry, thirdPartyBeaconType?: string) => {
  if (thirdPartyBeaconType) {
    return thirdPartyBeaconType;
  } else {
    const match = entry.name.match(/type=([^&]*)/);
    return match ? match[1] : '';
  }
};

const getPerformanceEntryUserEvent = (entry: PerformanceEntry, isThirdPartyBeacon: boolean) => {
  if (isThirdPartyBeacon) return '';

  const match = entry.name.match(/userEvent=([^&]*)/);
  return match ? match[1] : '';
};

const getPerformanceEntryArid = (entry: PerformanceEntry, isThirdPartyBeacon: boolean) => {
  if (isThirdPartyBeacon) return '';

  const match = entry.name.match(/arid=([^&]*)/);
  return match ? match[1] : '';
};

export function analyzeEntry(entry: globalThis.PerformanceResourceTiming): void;
export function analyzeEntry(entry: globalThis.PerformanceResourceTiming, thirdPartyBeaconType: string): void;

export function analyzeEntry(entry: globalThis.PerformanceResourceTiming, thirdPartyBeaconType?: string): void {
  const requestTime = entry.responseStart - entry.requestStart;
  const fetchTime = entry.responseEnd - entry.fetchStart;
  const totalTime = entry.responseEnd - entry.startTime;
  const name = entry.name;
  const type = getPerformanceEntryType(entry, thirdPartyBeaconType);
  const userEvent = getPerformanceEntryUserEvent(entry, !!thirdPartyBeaconType);
  const arid = getPerformanceEntryArid(entry, !!thirdPartyBeaconType);

  performanceEntriesSignal.value = [
    ...performanceEntriesSignal.value,
    {
      arid,
      type,
      name,
      userEvent,
      requestTime,
      fetchTime,
      totalTime
    }
  ];

  // share data between iframe (gc) and parent browser (sandbox)
  window.top?.postMessage({ type: 'performanceEntriesSignal', data: performanceEntriesSignal.value }, '*');
}

export function observeFirstPartyBeaconsPerformanceEntries() {
  // I tried to import dev Config from the config.development.json file
  // but raise errors in many testing files: Missing semicolon
  // mock json file in tests could be a way but it is too exhaustive
  const testTrackingDomain = 'https://b-staging.sharethrough.com';
  const trackingDomain = isTestEnvironment() ? testTrackingDomain : CONFIG.trackingDomain;

  const observer = new PerformanceObserver((list) => {
    list
      .getEntries()
      .filter((entry): entry is PerformanceResourceTiming => entry instanceof PerformanceResourceTiming)
      .forEach((entry) => {
        const resourceEntry = entry;
        if (resourceEntry.name.includes(trackingDomain)) {
          analyzeEntry(resourceEntry);
        }
      });
  });

  observer.observe({ type: 'resource', buffered: true });
}

export function observeThirdPartyBeaconsPerformanceEntries(urls: string[], beaconType: string) {
  const observer = new PerformanceObserver((list) => {
    list
      .getEntries()
      .filter((entry): entry is PerformanceResourceTiming => entry instanceof PerformanceResourceTiming)
      .forEach((entry) => {
        const resourceEntry = entry;

        try {
          const resourceUrl = new URL(resourceEntry.name);
          const resourceDomain = resourceUrl.hostname;

          const matches = urls.some((url) => {
            try {
              const targetUrl = new URL(url);
              const targetDomain = targetUrl.hostname;
              const domainMatches = resourceDomain === targetDomain;
              return domainMatches;
            } catch (e) {
              console.error('Error parsing URL:', url, e);
              return false;
            }
          });

          if (matches) {
            analyzeEntry(resourceEntry, beaconType);
          }
        } catch (e) {
          console.error('Error parsing resource URL:', resourceEntry.name, e);
        }
      });
  });

  observer.observe({ type: 'resource', buffered: true });
}

export function iterateAndObserveThirdPartyBeaconsPerformanceEntries(butlerResponse: ButlerResponse) {
  (Object.keys(butlerResponse.creative.beacons) as (keyof CreativeBeacons)[]).forEach((key: keyof CreativeBeacons) => {
    const urls = butlerResponse?.creative.beacons[key];
    if (urls && urls.length > 0) {
      observeThirdPartyBeaconsPerformanceEntries(urls, key);
    }
  });
}
