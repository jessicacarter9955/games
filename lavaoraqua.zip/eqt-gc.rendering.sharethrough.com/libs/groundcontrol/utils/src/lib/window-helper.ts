export type PerformanceTimestamp = number | null;

export const redirectSamePage = (url: string) => {
  window.location.assign(url);
};

export const redirectUrl = (mediaUrl: string, token: string | undefined, nonce: string | undefined) => {
  if (!token || !nonce) {
    return mediaUrl;
  } else {
    return `${CONFIG.clickoutDomain}?clickout_url=${encodeURIComponent(mediaUrl)}&token=${token}&nonce=${nonce}`;
  }
};

export const isIframe = (win: Window = window) => win.self !== win.top;
export const isTopWindow = (win: Window = window) => win.self === win.top;
