import type { TrackerService } from '@web-rendering/groundcontrol-core';
import { reportError } from '@web-rendering/groundcontrol-monitoring';
import type { LifecycleScope } from '@web-rendering/groundcontrol-shared-types/lifecycle/lifecycle';

export const setupHeavyAdInterventionObserver = (
  id: string | null,
  placeholder: HTMLElement,
  trackerService: TrackerService<Record<string, string | object>>,
  scope: LifecycleScope
) => {
  // Check if browser is Firefox and ReportingObserver exists
  const isFirefox = navigator.userAgent.toLowerCase().includes('firefox');
  if (isFirefox || !('ReportingObserver' in window)) return;

  try {
    const sendReports = (reports: Report[]) => {
      for (const report of reports) {
        if (
          report.type === 'intervention' &&
          report.body &&
          'id' in report.body &&
          report.body.id === 'HeavyAdIntervention'
        ) {
          trackerService.trackHeavyAdIntervention();
          reportError(new Error('HeavyAdIntervention detected'), {
            scope,
            context: 'helpers:heavy-ad-intervention',
            report,
            id: id ?? undefined,
            payloadId: id,
            placeholderAttributes: placeholder.dataset || {}
          });
        }
      }
    };

    const observer = new ReportingObserver(
      (reports) => {
        sendReports(reports);
      },
      { buffered: true }
    );

    observer.observe();

    // Add pagehide event listener to capture any pending reports
    window.addEventListener('pagehide', () => {
      const reports = observer.takeRecords();
      sendReports(reports);
      observer.disconnect(); // Clean up the observer
    });
  } catch (error) {
    // Silently fail if there's any error in setting up the observer
  }
};
