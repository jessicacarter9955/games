import { LAMBDA_URL, LOG_BASE_URL, reportError } from '@web-rendering/groundcontrol-monitoring';
import type { Lifecycle } from '@web-rendering/groundcontrol-shared-types/lifecycle/lifecycle';
import { LifecycleStage } from '@web-rendering/groundcontrol-shared-types/lifecycle/lifecycle-stage';
import { setGroundControlInstanceId } from '@web-rendering/groundcontrol-store';

import { findEqtExchangeMetadataInDocument } from './extract-eqt-exchange-metadata';
import { InViewTracker } from './in-view-tracker';

const DIV_PAYLOAD_SELECTOR = '[data-gc-payload]:not([data-str-visited-flag]):not(script)';
// TODO: remove once the wrapper is updated on SSB/DE
const STX_LEGACY_SELECTOR = '[data-stx-response-name]:not([data-str-visited-flag])';
const SCRIPT_PAYLOAD_SELECTOR = 'script[data-gc-payload]:not([data-str-visited-flag])';
const BOOT_ERROR_SAMPLING_RATE = 1e-4;

type BootAd<TOptions> = (placeholder: HTMLElement, options: TOptions) => Promise<void>;
type PayloadResolver = () => HTMLElement[];

const collectFailureContext = (): Record<string, unknown> => ({
  function: 'tag/index:boot',
  readyState: document.readyState,
  allDataGcPayload: document.querySelectorAll('[data-gc-payload]').length,
  // >0 means the SSB double-boot already rendered the ad (Pattern B false positive);
  // genuine failures (e.g. IMDB) have visitedPayloadCount === 0. Tag, don't suppress.
  visitedPayloadCount: document.querySelectorAll('[data-gc-payload][data-str-visited-flag]').length,
  bodyChildrenCount: document.body?.children.length ?? -1,
  iframeCount: document.querySelectorAll('iframe').length,
  scriptCount: document.querySelectorAll('script').length,
  bodySnippet: document.body?.innerHTML?.substring(0, 500),
  documentSize: document.documentElement?.outerHTML?.length ?? 0,
  referrer: document.referrer || undefined,
  ancestorOrigins: window.location.ancestorOrigins?.length ? Array.from(window.location.ancestorOrigins) : undefined,
  isTopDocument: window.self === window.top,
  ...(findEqtExchangeMetadataInDocument() ?? {})
});

const promoteScriptToContainer = (script: HTMLScriptElement): HTMLElement | null => {
  const parent = script.parentNode;
  if (!parent) {
    return null;
  }
  const div = document.createElement('div');
  for (const attr of Array.from(script.attributes)) {
    if (attr.name.startsWith('data-')) {
      div.setAttribute(attr.name, attr.value);
    }
  }
  parent.insertBefore(div, script);
  script.setAttribute('data-str-visited-flag', '');
  return div;
};

const fromDivAttribute: PayloadResolver = () =>
  Array.from(document.querySelectorAll<HTMLElement>(DIV_PAYLOAD_SELECTOR));

const fromStxLegacyAttribute: PayloadResolver = () =>
  Array.from(document.querySelectorAll<HTMLElement>(STX_LEGACY_SELECTOR));

const fromScriptAttribute: PayloadResolver = () =>
  Array.from(document.querySelectorAll<HTMLScriptElement>(SCRIPT_PAYLOAD_SELECTOR))
    .map(promoteScriptToContainer)
    .filter((el): el is HTMLElement => el !== null);

const primaryResolvers: PayloadResolver[] = [fromDivAttribute, fromStxLegacyAttribute];
const fallbackResolvers: PayloadResolver[] = [fromScriptAttribute];

const dumpDocumentBody = (): string | undefined => {
  // PII guard: user tokens/session data live in the publisher's top document
  // (WR-1988 Pattern D), never in about:srcdoc ad iframes. Only dump iframe HTML.
  // Identity comparison is safe cross-origin; reading window.top's properties is not.
  if (window.self === window.top) {
    return undefined;
  }

  const documentHtml = document.documentElement?.outerHTML;
  if (!documentHtml) {
    return undefined;
  }

  const failureId = `${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
  const path = `boot-failure/${failureId}`;

  // sendBeacon and fetch+keepalive both enforce a ~64KB body limit; many failing documents
  // (Pattern C empty-body srcdoc) are 160KB+ and silently failed to upload. Use plain fetch
  // here — we're at boot time, the page is unlikely to unload before this completes, and we'd
  // rather have larger bodies upload successfully than survive page unload.
  try {
    void fetch(LAMBDA_URL, {
      method: 'POST',
      body: JSON.stringify({ path, content: { html: documentHtml }, contentType: 'html' })
    }).catch(() => {
      // upload failures are non-critical; the Airbrake notice still has the diagnostic context
    });
  } catch {
    // synchronous JSON.stringify failures are non-critical
  }

  return `${LOG_BASE_URL}/${path}`;
};

export const bootEquativPlaceholders = async <TOptions>(
  options: TOptions,
  bootAd: BootAd<TOptions>,
  lifecycle: Lifecycle
): Promise<void> => {
  lifecycle.enter(LifecycleStage.Placeholder);
  InViewTracker.startup();
  setGroundControlInstanceId();

  const primaryPlaceholders = primaryResolvers.flatMap((resolve) => resolve());
  const placeholders =
    primaryPlaceholders.length > 0 ? primaryPlaceholders : fallbackResolvers.flatMap((resolve) => resolve());

  if (placeholders.length === 0) {
    // One draw governs both the report and the dump, so every dump has a notice (unless the
    // Error Sampling Factor thins it later). Canary builds sample at the same rate as stable.
    if (Math.random() >= BOOT_ERROR_SAMPLING_RATE) {
      return;
    }
    const bodyDumpUrl = dumpDocumentBody();
    reportError(new Error('boot: no ad placeholders matched'), {
      scope: lifecycle,
      ...collectFailureContext(),
      ...(bodyDumpUrl ? { bodyDumpUrl } : {}),
      sampling: { alreadySampledAt: BOOT_ERROR_SAMPLING_RATE }
    });
    return;
  }

  await Promise.all(placeholders.map((placeholder) => bootAd(placeholder, options)));
};
