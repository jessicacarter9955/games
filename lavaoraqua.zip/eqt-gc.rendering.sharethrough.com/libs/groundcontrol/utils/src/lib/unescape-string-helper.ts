export function unescapeString(str: string) {
  // This will remove all single backslashes. Double backslashes are treated as escaped backslash characters,
  // so they are replaced with a single backslash.
  return str.replace(/\\(.)/g, '$1');
}
