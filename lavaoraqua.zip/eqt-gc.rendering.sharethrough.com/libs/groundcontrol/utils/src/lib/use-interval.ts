import { useEffect, useRef } from 'preact/hooks';

/* Pass delay = null to pause the interval */
export const useInterval = (callback: () => void, delay: number | null) => {
  const savedCallback = useRef<() => void>(() => undefined);

  useEffect(() => {
    savedCallback.current = callback;
  });

  useEffect(() => {
    if (delay === null) {
      return;
    }

    function tick() {
      savedCallback.current && savedCallback.current();
    }

    const id = setInterval(tick, delay);
    return () => clearInterval(id);
  }, [delay]);
};
