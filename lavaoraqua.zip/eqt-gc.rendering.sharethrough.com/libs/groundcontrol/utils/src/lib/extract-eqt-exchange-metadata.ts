export interface EqtExchangeMetadata {
  exchange?: string;
  tagId?: string;
  dspId?: string;
  crid?: string;
}

const KEY_REGEX = /(Exchange|TAGID|DSPID|CRID)\s*:\s*([^,]+?)(?=\s*,|\s*$)/g;

const KEY_TO_FIELD: Record<string, keyof EqtExchangeMetadata> = {
  Exchange: 'exchange',
  TAGID: 'tagId',
  DSPID: 'dspId',
  CRID: 'crid'
};

const isEqtExchangeComment = (text: string): boolean =>
  text.includes('Exchange:') && (text.includes('TAGID:') || text.includes('DSPID:') || text.includes('CRID:'));

const parseEqtExchangeComment = (text: string): EqtExchangeMetadata | null => {
  if (!isEqtExchangeComment(text)) return null;

  const metadata: EqtExchangeMetadata = {};
  for (const match of text.matchAll(KEY_REGEX)) {
    const [, key, rawValue] = match;
    const field = KEY_TO_FIELD[key];
    if (field) metadata[field] = rawValue.trim();
  }
  return Object.keys(metadata).length > 0 ? metadata : null;
};

export const extractEqtExchangeMetadata = (placeholder: HTMLElement): EqtExchangeMetadata | null => {
  const parent = placeholder.parentNode;
  if (!parent) return null;

  for (const node of Array.from(parent.childNodes)) {
    if (node.nodeType !== Node.COMMENT_NODE) continue;
    const metadata = parseEqtExchangeComment(node.nodeValue ?? '');
    if (metadata) return metadata;
  }

  return null;
};

// Document-wide variant for the boot-failure path: the placeholder is missing,
// but the exchange-emitted comment may still survive elsewhere in the document.
export const findEqtExchangeMetadataInDocument = (
  root: ParentNode | null = document.body
): EqtExchangeMetadata | null => {
  if (!root) return null;

  const walker = document.createTreeWalker(root, NodeFilter.SHOW_COMMENT);
  for (let node = walker.nextNode(); node !== null; node = walker.nextNode()) {
    const metadata = parseEqtExchangeComment(node.nodeValue ?? '');
    if (metadata) return metadata;
  }
  return null;
};
