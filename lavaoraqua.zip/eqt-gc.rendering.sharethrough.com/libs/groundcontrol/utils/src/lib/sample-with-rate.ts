export const FRIENDLY_IFRAME_SAMPLING_RATE = 0.01;

export const shouldSample = (samplingRate: number): boolean => {
  if (ENV === 'dev') {
    return true;
  }

  const randomValue = Math.random();
  return randomValue < samplingRate;
};

export const shouldSampleFriendlyIframe = (): boolean => {
  return shouldSample(FRIENDLY_IFRAME_SAMPLING_RATE);
};
