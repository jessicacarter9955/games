import { isAMP } from './is-amp';
import { SafeFrameHandler } from './safe-frame-handler';
import { isIframe, isTopWindow } from './window-helper';
import { isTestEnvironment } from './environment-info';
// Possible values: safeframe, amp-safeframe, friendly-iframe, iframe, top, amp-top
// win is threaded through every check below so tests can simulate a cross-origin
// window.top without mutating the real global (jsdom's window.top is not a
// configurable property). Production callers pass nothing and get the real window.
export function renderEnv(win: Window = window): string {
  return isAMP(win) ? `amp-${renderFrame(win)}` : renderFrame(win);
}

export function isFriendlyIframe(win: Window = window): boolean {
  try {
    // for e2e testing in cypress
    if (isTestEnvironment()) {
      const winWithOverride = win as Window & { isFriendlyIframe?: () => boolean };
      if (winWithOverride.isFriendlyIframe && typeof winWithOverride.isFriendlyIframe === 'function') {
        return winWithOverride.isFriendlyIframe();
      }
    }

    return win !== win.top && Boolean(win.top?.document);
  } catch {
    return false;
  }
}

export function renderFrame(win: Window = window): string {
  // Check safeframe first as it's a special case
  if (SafeFrameHandler.isSafeFrame(win)) {
    return 'safeframe';
  } else if (isFriendlyIframe(win)) {
    return 'friendly-iframe';
  } else if (isIframe(win)) {
    return 'iframe';
  } else if (isTopWindow(win)) {
    return 'top';
  } else {
    return 'unknown';
  }
}
