const TEST_ENVS_URLS = [
  'localhost:9100',
  'localhost:7824', // e2e test port
  'storage.googleapis.com/g-authorized-buyers-creative-previews',
  'eqt-gc.rendering.sharethrough.com'
];

export const isTestEnvironment = () => {
  const currentUrl = window?.location?.href || '';
  // This includes the current URL and all ancestor URLs - required since we render in iframes
  const urls = window.location.ancestorOrigins
    ? [...Array.from(window.location.ancestorOrigins), currentUrl]
    : [currentUrl];

  return (
    urls.some((url) => TEST_ENVS_URLS.some((testUrl) => url.includes(testUrl))) ||
    (typeof ENV !== 'undefined' && (ENV === 'dev' || ENV === 'test'))
  );
};
