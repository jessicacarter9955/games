const FOCUS_POLL_INTERVAL_MS = 100;

// iOS Safari may surface no mouse event on the parent for a tap inside a cross-origin iframe, so
// the mouse guard would swallow every real click there. Off until verified on a device.
const isIosDevice = (): boolean =>
  /iPad|iPhone|iPod/.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);

export interface DetectIframeClicksOptions {
  iframe: HTMLIFrameElement;
  onClick: () => void;
  /** Top accessible window: primed, listened to for blur (subframe windows never receive it), refocused after a rejected grab. */
  focusWindow?: Window;
}

/**
 * Counts a click on a creative iframe (no DOM click events across origins) as focus moving into
 * it, the legacy `Eic` heuristic, with guards so that only a real click counts:
 * - the window is primed with focus, since blur only fires on a window that held it;
 * - focus counts only while the mouse is over the iframe, so a creative calling `focus()` on
 *   itself is not a click (a tap fires mouseenter and no mouseleave, so taps pass);
 * - focus stays in the iframe after a counted click, as in `Eic`, and a later blur counts only
 *   while `document.hasFocus()` holds, so the click's own new tab or the app going to the
 *   background does not count again;
 * - `activeElement` is polled under the mouse, since Firefox never blurs the top window when
 *   focus enters a child frame and WebKit refuses `focus()` from a cross-origin subframe.
 */
export const detectIframeClicks = ({
  iframe,
  onClick,
  focusWindow = window
}: DetectIframeClicksOptions): (() => void) => {
  const ownDocument = iframe.ownerDocument;
  const isMouseGuardEnabled = !isIosDevice();

  // a re-arm with the mouse already on the iframe gets no mouseenter
  let isMouseOver = iframe.matches(':hover');
  let wasIframeActive = false;
  let checkTimeoutId: ReturnType<typeof setTimeout> | undefined;
  let pollIntervalId: ReturnType<typeof setInterval> | undefined;

  const checkIframeFocus = (isFromBlur: boolean) => {
    const isIframeFocused = ownDocument.activeElement === iframe && ownDocument.hasFocus();
    if (isIframeFocused && (isFromBlur || !wasIframeActive)) {
      if (isMouseOver || !isMouseGuardEnabled) {
        onClick();
      } else {
        focusWindow.focus();
      }
    }
    // on activeElement alone, so a grab seen while the page had no focus does not count once it regains it
    wasIframeActive = ownDocument.activeElement === iframe;
  };

  const onBlur = () => {
    if (checkTimeoutId !== undefined) clearTimeout(checkTimeoutId);
    checkTimeoutId = setTimeout(() => checkIframeFocus(true));
  };

  const startPolling = () => {
    pollIntervalId ??= setInterval(() => checkIframeFocus(false), FOCUS_POLL_INTERVAL_MS);
  };
  const stopPolling = () => {
    if (pollIntervalId === undefined) return;
    clearInterval(pollIntervalId);
    pollIntervalId = undefined;
  };

  const onMouseEnter = () => {
    isMouseOver = true;
    startPolling();
  };
  const onMouseLeave = () => {
    // a quick click-and-leave can land between two polls
    checkIframeFocus(false);
    isMouseOver = false;
    stopPolling();
  };

  const primeFocus = () => {
    const { activeElement, body } = focusWindow.document;
    if (!activeElement || activeElement === body) focusWindow.focus();
  };
  const primeFocusWhenVisible = () => {
    if (ownDocument.visibilityState === 'visible') primeFocus();
  };

  primeFocus();
  if (isMouseOver) startPolling();
  iframe.addEventListener('mouseenter', onMouseEnter);
  iframe.addEventListener('mouseleave', onMouseLeave);
  focusWindow.addEventListener('blur', onBlur);
  ownDocument.addEventListener('visibilitychange', primeFocusWhenVisible);

  return () => {
    if (checkTimeoutId !== undefined) clearTimeout(checkTimeoutId);
    stopPolling();
    iframe.removeEventListener('mouseenter', onMouseEnter);
    iframe.removeEventListener('mouseleave', onMouseLeave);
    focusWindow.removeEventListener('blur', onBlur);
    ownDocument.removeEventListener('visibilitychange', primeFocusWhenVisible);
  };
};
