import { BackgroundStyle } from './background';
import { BorderStyle } from './border';
import { FontStyle } from './font';
import type {
  IBackgroundStyleResponse,
  IBorderStyleResponse,
  IFontStyleResponse,
  ITextStyleResponse
} from './response';

export class TextStyle implements ITextStyleResponse {
  hide: boolean | undefined;
  font: IFontStyleResponse | undefined;
  background: IBackgroundStyleResponse | undefined;
  border: IBorderStyleResponse | undefined;
  hoverColor: string | undefined;

  constructor(response?: ITextStyleResponse) {
    this.hide = response?.hide;
    this.font = new FontStyle(response?.font);
    this.background = new BackgroundStyle(response?.background);
    this.border = new BorderStyle(response?.border);
    this.hoverColor = response?.hoverColor;
  }
}
