import type { CSSProperties } from 'preact/compat';
import type { IBorderStyleResponse } from './response';

export class BorderStyle implements IBorderStyleResponse {
  color: string | undefined;
  width: number | undefined;
  style: string | undefined;
  radius: number | undefined;

  constructor(response?: IBorderStyleResponse) {
    this.color = response?.color;
    this.width = response?.width;
    this.style = response?.style;
    this.radius = response?.radius;
  }

  toStyle(): CSSProperties {
    return { borderColor: this.color, borderWidth: this.width };
  }
}
