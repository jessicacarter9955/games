import { BackgroundStyle } from './background';
import { FontStyle } from './font';
import { FontFamilyStyle } from './font-family';
import { LayoutStyle } from './layout';
import type { IFontFamilyResponse, IFontStyleResponse, IPublisherStyleResponse } from './response';
import { TextStyle } from './text';

export class PublisherStyles implements IPublisherStyleResponse {
  direction: 'row' | 'column' | undefined;
  font: IFontStyleResponse | undefined;
  background: BackgroundStyle | undefined;
  layout: LayoutStyle | undefined;
  cta: TextStyle | undefined;
  title: TextStyle | undefined;
  description: TextStyle | undefined;
  promotedBy: TextStyle | undefined;
  fontFamily: IFontFamilyResponse[] | undefined;

  constructor(publisherStyleResponse?: IPublisherStyleResponse) {
    this.direction = publisherStyleResponse?.direction;
    this.background = new BackgroundStyle(publisherStyleResponse?.background);
    this.layout = new LayoutStyle(publisherStyleResponse?.layout);
    this.cta = new TextStyle(publisherStyleResponse?.cta);
    this.title = new TextStyle(publisherStyleResponse?.title);
    this.description = new TextStyle(publisherStyleResponse?.description);
    this.promotedBy = new TextStyle(publisherStyleResponse?.promotedBy);
    this.fontFamily = new FontFamilyStyle(publisherStyleResponse?.fontFamily);
    this.font = new FontStyle(publisherStyleResponse?.font);
  }
}

// Rollout is controlled by this list alone (ADR-0013). Artifacts were scraped in one batch on
// 2025-09-18, so each entry was re-checked on 2026-08-25. Absent: crazygames and crosswordclub
// (title font resolves to a browser default), plus the eight that 403.
export const ALLOWED_PUBLISHER_STYLE_DOMAINS = new Set<string>([
  'allrecipes',
  'americansongwriter',
  'aol',
  'biblegateway',
  'britannica',
  'buzzfeed',
  'cbssports',
  'chess',
  'cnn',
  'coolmathgames',
  'dailymotion',
  'ebay',
  'espn',
  'fantasypros',
  'forbes',
  'genius',
  'grizly',
  'huffpost',
  'loveandlemons',
  'merriam-webster',
  'mobileposse',
  'newsweek',
  'nypost',
  'nytimes',
  'on3',
  'overwolf',
  'people',
  'poki',
  'powerball',
  'quizlet', // asks for a face it does not ship; lands on the generic sans
  'recipetineats',
  'redfin',
  'sallysbakingaddiction',
  'solitaired',
  'tastesbetterfromscratch',
  'timeanddate', // asks for plain Arial, same as an unstyled title
  'usatoday',
  'vegoutmag',
  'weather',
  'wunderground',
  'yahoo' // no @font-face entries, so titles land on the browser's default serif
]);
