import { useContext } from 'preact/hooks';
import { PublisherStylingContext } from './publisher-styling-provider';

export const usePublisherStyling = () => {
  return useContext(PublisherStylingContext);
};
