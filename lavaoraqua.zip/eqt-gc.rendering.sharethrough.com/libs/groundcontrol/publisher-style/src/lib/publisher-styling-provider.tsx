import type { FunctionComponent } from 'preact';
import { createContext } from 'preact';
import { useEffect, useRef, useState } from 'preact/hooks';
import type { PublisherStylingOutcome } from './helper/utils';
import { loadPublisherStyles } from './helper/utils';
import { PublisherStyles } from './model/publisher-style';
import {
  type PublisherStyleError,
  PublisherStyleError as PublisherStyleErrorClass
} from './model/publisher-style-error';

export interface PublisherStylingContext {
  styles: PublisherStyles | undefined;
  error: PublisherStyleError | undefined;
}

export const PublisherStylingContext = createContext<PublisherStylingContext>({
  styles: undefined,
  error: undefined
});

interface IPublisherStylingProviderProps {
  domain: string;
  onOutcome(outcome: PublisherStylingOutcome): void;
  children: preact.ComponentChildren;
}

export const PublisherStylingProvider: FunctionComponent<IPublisherStylingProviderProps> = ({
  domain,
  children,
  onOutcome
}) => {
  const [styles, setPublisherStyles] = useState<PublisherStyles | undefined>(undefined);
  const [error, setError] = useState<PublisherStyleError | undefined>(undefined);

  // Mount sites build onOutcome inline, so it is a new function on every render. Holding it in a ref
  // keeps it out of the effect's deps: a re-render must not refetch the artifact and fire a second
  // requested/loaded pair for one impression.
  const onOutcomeRef = useRef(onOutcome);
  onOutcomeRef.current = onOutcome;

  useEffect(() => {
    if (!domain) return;

    const fetchPublisherStyles = async () => {
      try {
        const styles = await loadPublisherStyles(domain, (outcome) => onOutcomeRef.current(outcome));
        setPublisherStyles(styles);
      } catch (error) {
        setPublisherStyles(new PublisherStyles());
        if (error instanceof PublisherStyleErrorClass) setError(error);
      }
    };

    fetchPublisherStyles();
  }, [domain]);

  return <PublisherStylingContext.Provider value={{ styles, error }}>{children}</PublisherStylingContext.Provider>;
};
