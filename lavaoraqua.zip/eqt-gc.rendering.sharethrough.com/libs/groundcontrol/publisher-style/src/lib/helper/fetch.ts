import { type IPublisherStyleResponse } from '../model';

export const fetchPublisherStyles = (publisher: string): Promise<IPublisherStyleResponse> => {
  const endpoint = {
    baseUrl: 'https://cdn.rendering.sharethrough.com',
    bucket: 'true-template-output'
  };

  const { baseUrl, bucket } = endpoint;

  const url = `${baseUrl}/${bucket}/${publisher}.json`;
  return fetch(url)
    .then((response) => {
      if (response.status === 200) {
        return response.json();
      } else if (response.status === 404) {
        throw new Error(`Publisher styles not found for ${publisher}`);
      } else {
        throw new Error(`Failed to fetch publisher styles: ${response.status} ${response.statusText}`);
      }
    })
    .catch((error) => {
      console.error(`Error fetching publisher styles for ${publisher}:`, error);
      throw error;
    });
};
