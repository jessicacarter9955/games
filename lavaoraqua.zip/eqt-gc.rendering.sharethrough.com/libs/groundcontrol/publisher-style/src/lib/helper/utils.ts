import type { FontFamilyStyle } from '../model';
import {
  PublisherStyles,
  PublisherStyleError,
  PublisherStyleErrorType,
  ALLOWED_PUBLISHER_STYLE_DOMAINS
} from '../model';
import { fetchPublisherStyles } from './fetch';

/**
 * What a publisher-styling attempt reported. `requested` means the placement's publisher is on the
 * allowlist and the artifact fetch has started; `loaded` means that fetch resolved. The pair gives
 * a rate a denominator the tracker cannot rebuild on its own, since the allowlist is a client-side
 * judgement (ADR-0012).
 */
export type PublisherStylingOutcome = 'requested' | 'loaded';

export const getDomain = (domain: string): string => {
  const regex = /(?:https?:\/\/)?(?:www\.)?([^?]+)/;
  return regex.exec(domain)?.[1] || '';
};

const loadFontFace = async (fontFace: FontFace) => {
  const loadedFont = await fontFace.load();
  document.fonts.add(loadedFont);
};

export const loadFontFamily = (font: FontFamilyStyle) => {
  try {
    const fontFace = font.map((font) => {
      return new FontFace(font.family, `url(${font.url})`, {
        style: font.style,
        weight: font.weight
      });
    });
    fontFace.forEach((fontFace) => {
      loadFontFace(fontFace);
    });
  } catch (error) {
    console.error('Error loading font family', error);
  }
};

export const loadPublisherStyles = async (
  placementDomain: string,
  onOutcome: (outcome: PublisherStylingOutcome) => void
): Promise<PublisherStyles> => {
  try {
    const domain = getDomain(placementDomain);
    const publisherDomain = domain.split('.')[0]; // e.g. 'dailymail' from 'dailymail.co.uk'

    if (ALLOWED_PUBLISHER_STYLE_DOMAINS.has(publisherDomain)) {
      // Reported before the await so a fetch that never settles reads as requested-without-loaded
      // rather than vanishing from both sides of the rate (ADR-0012).
      onOutcome('requested');
      const styles = await fetchPublisherStyles(publisherDomain);
      onOutcome('loaded');
      return new PublisherStyles(styles);
    }

    return new PublisherStyles();
  } catch (e) {
    if (e instanceof PublisherStyleError) throw e;
    const error = new PublisherStyleError(PublisherStyleErrorType.FETCH_DATA_FAILED, `Error fetching data: ${e}`);

    throw error;
  }
};
