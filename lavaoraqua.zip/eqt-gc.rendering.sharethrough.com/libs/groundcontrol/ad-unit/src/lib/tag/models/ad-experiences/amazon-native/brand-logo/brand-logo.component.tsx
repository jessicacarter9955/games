import { useNativeAssets } from '@web-rendering/groundcontrol-ortb';
import type { FunctionComponent } from 'preact';
import { AmazonAvailableLogo } from '../available-logo/amazon-logo.component';
import './brand-logo.scss';

export const AmazonBrandLogo: FunctionComponent = () => {
  const assets = useNativeAssets();
  if (!assets) return null;

  const { logo, availableOnAmazon } = assets;

  if (!logo && availableOnAmazon) return <AmazonAvailableLogo />;
  if (!logo) return null;

  return (
    <div className="str-amazon-thumbnail-logo">
      <div
        className="str-amazon-brand-logo"
        data-testid="amazon-brand-logo"
        style={{ backgroundImage: `url(${logo.img.url})` }}
      ></div>
    </div>
  );
};
