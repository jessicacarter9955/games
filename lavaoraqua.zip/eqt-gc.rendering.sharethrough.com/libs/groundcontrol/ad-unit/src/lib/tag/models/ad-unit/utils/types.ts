import type { AttentionMetricsRawSnapshot } from '@web-rendering/groundcontrol-beacon';
import type { RefObject } from 'preact';

export enum SizeType {
  Wide = 'wide',
  Widest = 'widest',
  Tall = 'tall',
  Tallest = 'tallest',
  Square = 'square'
}
export interface RecordPositionParams {
  containerRef: RefObject<HTMLDivElement>;
  dataHistoryRef: RefObject<AttentionMetricsRawSnapshot[]>;
  lastSnapshotRef: RefObject<string>;
}

export type EventHandler = (event: MouseEvent | UIEvent) => void;
export type EventListenerOptions = AddEventListenerOptions | undefined;
