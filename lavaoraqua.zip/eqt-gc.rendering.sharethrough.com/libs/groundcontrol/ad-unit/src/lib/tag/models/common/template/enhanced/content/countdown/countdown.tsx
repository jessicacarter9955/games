import type { BannerCountdownPayload, OutstreamCountdownPayload } from '@sharethrough/groundcontrol-enhancement-flush';
import { GCEnhancementType } from '@sharethrough/groundcontrol-enhancement-flush';
import { CountdownEnhancement } from '@web-rendering/groundcontrol-enhancements';
import { useContent } from '../content.hook';
import { registerEnhancement } from '../registry';
import { getLayoutType } from './get-layout-type';

export const Countdown = () => {
  const { assets, enhancement, language, onError, onLoad, payload, publisherStyles } = useContent<
    BannerCountdownPayload | OutstreamCountdownPayload
  >();

  if (!enhancement || !payload) return null;

  const layout = getLayoutType(payload.creative, payload.network);

  return (
    <CountdownEnhancement
      assets={assets}
      enhancement={enhancement}
      language={language}
      layout={layout}
      onClick={() => undefined}
      onError={onError}
      onLoad={onLoad}
      publisherStyles={publisherStyles}
    />
  );
};

registerEnhancement([GCEnhancementType.BannerCountdown, GCEnhancementType.OutstreamCountdown], Countdown);
