import type { Signal } from '@preact/signals';
import { Fragment } from 'preact';
import type { RefObject } from 'preact/compat';
import { useEffect, useState } from 'preact/hooks';
import { useEnhancement } from '../../hooks';
import { isIframeBasedEnhancement } from '../utils/is-iframe-based-enhancement';
import { isRemoteEnhancement } from '../utils/is-remote-enhancement';
import styles from './banner-clickblocker.module.scss';

type Props = {
  iframe: RefObject<HTMLIFrameElement>;
  onClick: (event: MouseEvent) => void;
  showClickBlocker: Signal<boolean>;
  isBannerClickable: Signal<boolean>;
  className?: string;
  enableClickExtraction?: boolean;
};

export const BannerClickBlocker = (props: Props) => {
  const [dimensions, setDimensions] = useState({ width: '100%', height: '100%', offsetTop: '0', offsetLeft: '0' });
  const { onClick, showClickBlocker, isBannerClickable } = props;
  const { enhancement } = useEnhancement();

  useEffect(() => {
    if (props.iframe.current) {
      setLoadEventListener(props.iframe.current);
    }
  }, [props.iframe]);

  const setLoadEventListener = (iframe: HTMLIFrameElement) => {
    iframe.addEventListener('load', () => {
      try {
        const thumbnailContentEl = iframe.contentWindow?.document?.body?.children?.item(0);
        const thumbnailWrapperRect = thumbnailContentEl?.getBoundingClientRect();

        if (thumbnailWrapperRect) {
          setDimensions({
            width: `${thumbnailWrapperRect.width}px`,
            height: `${thumbnailWrapperRect.height}px`,
            offsetTop: `${thumbnailWrapperRect.top}px`,
            offsetLeft: `${thumbnailWrapperRect.left}px`
          });
        }
      } catch (error) {
        // silently fail
      }
    });
  };

  if (!isBannerClickable.value || !showClickBlocker.value) return null;

  // EQT handles click redirection natively — unless click extraction overrides it
  if (GC_INSTANCE_NAME === 'equativ' && !props.enableClickExtraction) return null;

  if (enhancement && isRemoteEnhancement(enhancement)) return null;

  const enhancementIsIframeBased = isIframeBasedEnhancement(enhancement);

  return (
    <Fragment>
      {!enhancementIsIframeBased && (
        <div
          data-testid="str-banner-clickblocker"
          onClick={onClick}
          className={`${styles['str-banner-clickblocker']}`}
        />
      )}
      <div
        data-testid="str-thumbnail-clickblocker"
        onClick={onClick}
        className={`${styles['str-banner-clickblocker-thumbnail']}`}
        data-str-thumbnail
        style={{
          width: dimensions.width,
          height: dimensions.height,
          top: dimensions.offsetTop,
          left: dimensions.offsetLeft
        }}
      />
    </Fragment>
  );
};
