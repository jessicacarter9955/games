import type { Signal } from '@preact/signals';
import { effect, signal } from '@preact/signals';
import type { AdClickEvent } from '@sharethrough/groundcontrol-types';
import type { BannerCreative as ButlerBannerCreative, ButlerResponse } from '@web-rendering/groundcontrol-shared-types';
import { isEnhanceable } from '@web-rendering/groundcontrol-butler-helpers';
import type { BannerCreative, Payload, TrackerService } from '@web-rendering/groundcontrol-core';
import {
  getShowClickBlockerValue,
  hasRichMediaInventory,
  PayloadContext,
  usePayload,
  useTrackerService
} from '@web-rendering/groundcontrol-core';
import { PublisherStylingProvider } from '@ad-rendering/publisher-style';
import { reportError } from '@web-rendering/groundcontrol-monitoring';
import { ResponseStore } from '@web-rendering/groundcontrol-store';
import { generateClickEvent, unescapeString } from '@web-rendering/groundcontrol-utils';
import clsx from 'clsx';
import type { ErrorInfo } from 'preact';
import { createRef, Fragment } from 'preact';
import { Template } from '../../../../tag/models/common/template';
import { v4 as uuidv4 } from 'uuid';
import { disableAdChoices } from '../../common/template/enhanced/drawer/drawer.component';
import { AdExperienceBase } from '../ad-experience.base';
import { reportPublisherStylingOutcome } from '../common/publisher-styling/report-publisher-styling-outcome';
import type { AdExperienceBaseProps } from '../types';
import { BannerClickBlocker } from './banner-clickblocker/banner-clickblocker.component';
import { BannerIframe } from './banner-iframe/banner-iframe.component';
import './banner.scss';
import type { BannerProps, BannerState } from './types';
import { getSafeCreativeContent, isSameSizeEnhancedPin, SAME_SIZE_PIN_EXEMPT_ENHANCEMENT_TYPES } from './utils';
import { fitsContainer } from '../../ad-unit/utils/fits-container';
import type { FindClickoutUrlResult, GetClickableElementResult } from './utils/clickability-types';
import { findClickoutUrl } from './utils/find-clickout-url';
import type { BannerType } from './utils/get-banner-type';
import { getBannerType } from './utils/get-banner-type';
import type { ClickExtractionResult } from '@sharethrough/groundcontrol-types';
import type { ClickExtractor } from '@web-rendering/click-extraction';
import { getActiveClickExtractor } from './utils/get-active-click-extractor';
import { getClickableElement } from './utils/get-clickable-element';
import { getEnhancementUrl } from './utils/get-enhancement-url';
import { handleEqtClick } from './utils/handle-eqt-click';

export class BannerBase extends AdExperienceBase<ButlerBannerCreative, BannerProps, BannerState> {
  container = createRef<HTMLDivElement>();
  iframeRef = createRef<HTMLIFrameElement>();
  element: HTMLElement | null = null;
  isEnhanced = !isEnhanceable(this.payload.creative, this.payload.enhancement);
  thumbnailId = uuidv4();
  showClickBlocker: Signal<boolean> = signal(false);
  isBannerClickable: Signal<boolean> = signal(false);
  trackerService: TrackerService<unknown> | null = null;

  static contextType = PayloadContext;
  declare readonly context: Payload & {
    creative: BannerCreative;
  };

  constructor(props: BannerProps) {
    super(props);
    const response = ResponseStore.getResponse(props.adserverRequestId);
    this.response = response;

    this.trackerService = props.trackerService;

    this.setupClickabilityTracking();
  }

  private _clickExtractionResult: ClickExtractionResult | undefined;
  private _clickExtractionDurationMs: number | undefined;

  private setupClickabilityTracking() {
    const cleanup = effect(() => {
      if (this.isBannerClickable.value) {
        this.trackerService?.trackBannerClickable(this._clickExtractionResult, this._clickExtractionDurationMs);
        cleanup(); // cleanup once we've tracked the clickable event
      }
    });
  }

  private response: ButlerResponse | undefined = undefined;

  private _bannerType: BannerType | undefined = undefined;
  get bannerType(): BannerType {
    if (!this._bannerType) {
      this._bannerType = getBannerType(
        this.context.creative.content,
        this.context.creative.partnerId,
        this.context.network.networkId || ''
      );
    }

    return this._bannerType;
  }

  private _clickableElementBase: GetClickableElementResult | null = null;
  private _clickableElement: Element | null = null;
  private _clickableElementRule: string | undefined = undefined;
  get clickableElementBase(): GetClickableElementResult | null {
    if (!this._clickableElementBase) {
      this._clickableElementBase = getClickableElement({
        bannerType: this.bannerType,
        container: this.container
      });
    }

    return this._clickableElementBase;
  }

  get clickableElement() {
    if (!this._clickableElement) {
      this._clickableElement = this.clickableElementBase?.element || null;
    }

    return this._clickableElement;
  }

  get clickableElementRule() {
    if (!this._clickableElementRule) {
      this._clickableElementRule = this.clickableElementBase?.ruleUsed;
    }

    return this._clickableElementRule;
  }

  private _activeClickExtractor: ClickExtractor | null | undefined;
  get activeClickExtractor(): ClickExtractor | null {
    if (this._activeClickExtractor === undefined) {
      this._activeClickExtractor = getActiveClickExtractor(this.context);
    }

    return this._activeClickExtractor;
  }

  get useClickExtractionV2() {
    return this.activeClickExtractor !== null;
  }

  private _clickoutUrlBase: FindClickoutUrlResult | null = null;
  private _clickoutUrl: string | undefined | null = undefined;
  private _clickoutUrlRule: string | undefined = undefined;

  get clickoutUrlBase() {
    if (!this._clickoutUrlBase) {
      const { unescaped } = getSafeCreativeContent(this.context.creative);
      const extract = this.activeClickExtractor;

      if (extract) {
        const start = performance.now();
        const result = extract({
          container: this.container,
          bannerIframe: this.iframeRef.current,
          creativeLink: this.context.creative.link || undefined,
          adm: unescaped
        });
        this._clickExtractionResult = result;
        this._clickExtractionDurationMs = performance.now() - start;
        this._clickoutUrlBase = { url: result.url, ruleUsed: result.method };
      } else {
        this._clickoutUrlBase = findClickoutUrl({
          container: this.container,
          bannerIframe: this.iframeRef.current,
          bannerType: this.bannerType,
          element: this.element,
          adm: unescaped
        });
      }
    }

    return this._clickoutUrlBase;
  }

  get clickoutUrl() {
    if (!this._clickoutUrl) {
      this._clickoutUrl = this.clickoutUrlBase.url;
    }

    return this._clickoutUrl;
  }

  get clickoutUrlRule() {
    if (!this._clickoutUrlRule) {
      this._clickoutUrlRule = this.clickoutUrlBase.ruleUsed;
    }

    return this._clickoutUrlRule;
  }

  get bannerMetadata() {
    return {
      bannerType: this.bannerType,
      clickable: this.getBannerClickability(),
      clickableRule: this.getBannerClickabilityRule()
    };
  }

  get width() {
    return this.payload?.creative?.size?.width;
  }

  get height() {
    return this.payload?.creative?.size?.height;
  }

  get networkWidth() {
    return this.payload?.network?.size?.width;
  }

  get networkHeight() {
    return this.payload?.network?.size?.height;
  }

  get enhancementUrl() {
    return getEnhancementUrl(this.payload);
  }

  getBannerClickability = (): boolean => {
    // TODO(stx-deprecation): mediaUrl / response won't be provided for banners on EQT
    const clickability = Boolean(
      this.response?.creative.mediaUrl || this.clickableElement || this.clickoutUrl || this.enhancementUrl
    );

    this.isBannerClickable.value = clickability;
    return clickability;
  };

  getBannerClickabilityRule = (): string => {
    if (this.response?.creative.mediaUrl) return 'media-url';
    if (this.clickableElementRule) return this.clickableElementRule;
    return this.clickoutUrlRule || 'not-found';
  };

  get scale() {
    if (!this.width || !this.height || !this.networkWidth || !this.networkHeight) return 1;

    if (this.width <= this.networkWidth && this.height <= this.networkHeight) return 1;

    return Math.min(this.networkWidth / this.width, this.networkHeight / this.height);
  }

  /**
   * Calculates the scale factors for the creative based on network size and enhancement settings.
   *
   * @returns {Object} Object containing maxScale and minScale
   * @property {number} maxScale - Maximum scale to fit creative within network (0-1)
   * @property {number|undefined} minScale - Minimum scale based on enhancement rules
   */
  get scaleFactors() {
    const enableEnhancement = isEnhanceable(this.context.creative, this.context.enhancement);

    // Handle rich media inventory - apply minScale for unenhanced to prevent height collapse
    if (hasRichMediaInventory(this.context.network.callerId)) {
      return { maxScale: this.scale, minScale: enableEnhancement ? undefined : this.scale };
    }

    // Calculate minimum scale based on enhancement settings
    if (!enableEnhancement) return { maxScale: this.scale, minScale: this.scale };

    // WR-2159 AC3 / CE-178209542 FR3: BannerShoppableOverlay draws its overlay on top of the
    // native-size creative instead of freeing space beside it, and BannerBrandedHeadline is
    // explicitly excluded from the same-size combinations (decided 2026-08-26) — both stay
    // native. Pinning both axes to native (1) is always safe — unlike the 0.75 pin
    // (str-same-size-pinned CSS class, see banner render()), it never shrinks an axis nothing
    // else fills.
    const isSameSize = this.width === this.networkWidth && this.height === this.networkHeight;
    if (isSameSize && SAME_SIZE_PIN_EXEMPT_ENHANCEMENT_TYPES.includes(this.context.enhancement.type)) {
      return { maxScale: this.scale, minScale: this.scale };
    }

    // Handle special cases for enhanced scaling
    const creativeStringSize = `${this.width}x${this.height}`;
    const networkStringSize = `${this.networkWidth}x${this.networkHeight}`;
    const stringSize = `${creativeStringSize}-${networkStringSize}`;

    const specialCases: Record<string, number> = {
      '336x280-300x250': 0.65
    };

    const minScale = specialCases[stringSize] ?? Math.min(0.75, this.scale);

    return { maxScale: this.scale, minScale };
  }

  /**
   * Generates CSS style object for creative dimensions with min/max constraints.
   *
   * @returns {Object} Style object with dimension constraints
   */
  get getCreativeDimensionsStyle() {
    if (fitsContainer(this.context)) {
      // definite size (no percentage chain to collapse), bounded by the ad unit's own box
      const width = `min(${this.width}px, 100cqw)`;
      const height = `min(${this.height}px, 100cqh)`;
      return { minWidth: width, minHeight: height, maxWidth: width, maxHeight: height };
    }

    const { maxScale, minScale } = this.scaleFactors;

    return {
      minHeight: minScale && this.height * minScale,
      minWidth: minScale && this.width * minScale,
      maxHeight: this.height * maxScale,
      maxWidth: this.width * maxScale
    };
  }

  componentDidMount() {
    window.setTimeout(() => {
      this.getBannerClickability();
      const { callerId } = this.payload.network;
      const { content } = this.payload.creative;
      const { disableClickCounting } = this.payload.reporting;
      this.showClickBlocker.value = getShowClickBlockerValue(
        callerId,
        content,
        disableClickCounting,
        this.payload.enhancement.type
      );
    }, 1000);

    if (this.butlerResponse?.creative.description) {
      const descriptionDiv = this.element?.querySelector('.str-description');
      descriptionDiv?.classList.add('str-enhanced');
    }

    setTimeout(() => {
      const metadata = this.bannerMetadata;
      this.trackerService?.trackBannerRendered(metadata.clickable, metadata.clickableRule, disableAdChoices.value);
    }, 10000);
  }

  handleAdClick = (clickEvent: AdClickEvent) => {
    if (this.payload.reporting.disableClickCounting) return;

    if (!this.useClickExtractionV2 && handleEqtClick(clickEvent, this.payload)) return;

    this.propagateClickEvent(clickEvent.event);

    if (clickEvent.redirectUrl) {
      window.open(clickEvent.redirectUrl, '_blank');
      return;
    }

    if (this.clickableElement) {
      const onclick = this.clickableElement.getAttribute('onclick');
      if (onclick) {
        this.clickableElement.setAttribute('onclick', unescapeString(onclick));
      }

      this.clickableElement.dispatchEvent(generateClickEvent());
      return;
    }

    const clickoutUrl = this.clickoutUrl || this.enhancementUrl;
    if (clickoutUrl) {
      window.open(clickoutUrl, '_blank');
      return;
    }
  };

  propagateClickEvent = (event: MouseEvent) => {
    this.trackerService?.trackUserShare();

    if (this.getBannerClickability() || event.type === 'thumbnailclick') {
      const target =
        event.target instanceof HTMLElement && event.target.dataset.strThumbnail === 'true'
          ? event.target
          : this.element;

      this.trackerService?.trackClick(target as HTMLElement);
    }
  };

  updateClickable = () => {
    this._clickableElement = null;
    this.getBannerClickability();
  };

  componentDidCatch(error: string | Error, errorInfo: ErrorInfo): void {
    console.error(error, errorInfo);

    reportError(error, {
      scope: this.lifecycleScope,
      errorPayload: {
        errorInfo,
        creative: this.context.creative,
        adserverRequestId: this.props.adserverRequestId,
        reactRefactor: true
      }
    });
  }

  clickBlockerClick = (event: MouseEvent) => {
    this.handleAdClick({ event });
  };

  render() {
    return (
      <Fragment>
        <BannerClickBlocker
          onClick={this.clickBlockerClick}
          showClickBlocker={this.showClickBlocker}
          isBannerClickable={this.isBannerClickable}
          iframe={this.iframeRef}
          enableClickExtraction={this.useClickExtractionV2}
        />
        <div
          data-testid="str-enhanced-display"
          className="str-react-template"
          onClick={(event) => this.handleAdClick({ event })}
          ref={(element) => {
            this.element = element;
          }}
        >
          <Template
            creative={this.context.creative}
            network={this.context.network}
            country={this.context?.network.country}
            adserverRequestId={this.context?.id || ''}
            onEnhancementClick={this.handleAdClick}
          >
            <div
              className={clsx('str-thumbnail-wrapper', {
                'str-same-size-pinned': isSameSizeEnhancedPin({
                  width: this.width,
                  height: this.height,
                  networkWidth: this.networkWidth,
                  networkHeight: this.networkHeight,
                  creative: this.context.creative,
                  enhancement: this.context.enhancement
                })
              })}
              style={{
                ...this.getCreativeDimensionsStyle,
                position: 'relative',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center'
              }}
              ref={this.container}
            >
              <BannerIframe
                id={this.context?.id || ''}
                dataThumbnailId={this.thumbnailId}
                className="str-thumbnail"
                width={this.width}
                height={this.height}
                onLoad={this.updateClickable}
                onIframeClick={(event) => this.handleAdClick({ event })}
                ref={this.iframeRef}
              />
            </div>
          </Template>
        </div>
      </Fragment>
    );
  }
}

export function Banner(props: Readonly<AdExperienceBaseProps>) {
  const trackerService = useTrackerService();
  const payload = usePayload();

  // Don't mount the provider if not enhanced: nothing would be styled, but it would still report.
  const hasStyleableTemplate = Boolean(payload && isEnhanceable(payload.creative, payload.enhancement));

  if (!hasStyleableTemplate) return <BannerBase {...props} trackerService={trackerService} />;

  return (
    <PublisherStylingProvider
      domain={payload?.network.domain || ''}
      onOutcome={reportPublisherStylingOutcome(trackerService)}
    >
      <BannerBase {...props} trackerService={trackerService} />
    </PublisherStylingProvider>
  );
}
