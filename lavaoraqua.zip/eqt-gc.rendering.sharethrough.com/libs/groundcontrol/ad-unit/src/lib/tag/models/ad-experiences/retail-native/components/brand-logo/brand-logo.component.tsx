import { useNativeAssets } from '@web-rendering/groundcontrol-ortb';
import type { FunctionComponent } from 'preact';
import './brand-logo.scss';

export const RetailNativeBrandLogo: FunctionComponent = () => {
  const assets = useNativeAssets();
  const icon = assets?.icon;
  if (!icon) return null;

  return (
    <div className="str-retail-brand-logo">
      <img src={icon.img.url} alt="logo" className="str-retail-brand-logo-img" />
    </div>
  );
};
