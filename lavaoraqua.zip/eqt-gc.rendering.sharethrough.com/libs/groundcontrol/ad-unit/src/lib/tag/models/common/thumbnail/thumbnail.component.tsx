import { useTrackerService } from '@web-rendering/groundcontrol-core';
import { useNativeAssets } from '@web-rendering/groundcontrol-ortb';
import { registerObserver } from '../../../../modules/observer';
import type { FunctionComponent } from 'preact';
import { useEffect, useRef } from 'preact/hooks';
import { useButler } from '../../ad-experiences/hooks';
import styles from './thumbnail.module.scss';
import type { ThumbnailProps } from './types';

export const Thumbnail: FunctionComponent<ThumbnailProps> = ({ style }) => {
  const trackerService = useTrackerService();
  const assets = useNativeAssets();
  const timeoutIdRef = useRef<number | undefined>(undefined);
  const response = useButler();

  if (!assets || !assets.mainImage?.img.url) return null;

  let isIsi = false;
  if (response) {
    isIsi = !!response.creative.isi;
  }

  const thumbnailRef = useRef<HTMLDivElement>(null);

  const src = assets.mainImage?.img.url;

  useEffect(() => {
    let observer: IntersectionObserver | null = null;

    if (thumbnailRef.current) {
      observer = registerObserver({
        element: thumbnailRef.current,
        timeoutIdRef,
        inViewPixels: 1,
        outOfViewPixels: 0,
        inViewCallback: () => {
          trackerService?.trackPixelVisible();
        }
      });
    }

    return () => {
      observer?.disconnect();
    };
  }, [thumbnailRef]);

  return (
    <div ref={thumbnailRef} className={`${styles['thumbnail-wrapper']} ${isIsi ?? 'str-thumbnail-wrapper-isi'}`}>
      <img
        data-testid="main-image"
        className={`str-thumbnail ${styles['thumbnail']}`}
        src={src}
        style={{ ...style }}
        data-str-thumbnail
      />
    </div>
  );
};
