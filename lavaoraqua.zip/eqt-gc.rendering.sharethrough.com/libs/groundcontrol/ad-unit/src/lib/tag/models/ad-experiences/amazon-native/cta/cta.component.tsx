import { useNativeAssets } from '@web-rendering/groundcontrol-ortb';
import type { FunctionComponent } from 'preact';
import './cta.scss';
import { clsx } from 'clsx';

const getCtaClass = (ctaValue: string) => {
  switch (ctaValue) {
    case 'Add to cart':
      return 'str-amazon-cta-add-to-cart';
    case 'Shop now':
      return 'str-amazon-cta-shop-now';
    default:
      return '';
  }
};

export const AmazonCta: FunctionComponent = () => {
  const assets = useNativeAssets();
  if (!assets) return null;

  const { cta } = assets;
  if (!cta?.data || !cta?.link) return null;

  const ctaStyle = getCtaClass(cta.data.value);

  return (
    <a className={clsx('str-amazon-cta', ctaStyle)}>
      <div>{cta.data.value}</div>
    </a>
  );
};
