import type { ShoppableCtaStyle } from '@web-rendering/groundcontrol-ortb';
import { useNativeAssets } from '@web-rendering/groundcontrol-ortb';
import type { FunctionComponent } from 'preact';
import './cta.scss';

// Map the parsed (already hex-normalized) theme onto the CSS custom properties the
// stylesheet reads. Omitted colors fall back to the defaults declared in cta.scss.
const ctaStyleToCssVars = (style: ShoppableCtaStyle | undefined): Record<string, string> => {
  if (!style) return {};

  const vars: Record<string, string> = {};
  if (style.textColor) vars['--cta-text-color'] = style.textColor;
  if (style.backgroundColor) vars['--cta-background-color'] = style.backgroundColor;
  if (style.textHoverColor) vars['--cta-text-hover-color'] = style.textHoverColor;
  if (style.backgroundHoverColor) vars['--cta-background-hover-color'] = style.backgroundHoverColor;
  return vars;
};

export const RetailNativeCta: FunctionComponent = () => {
  const assets = useNativeAssets();
  const cta = assets?.cta;
  if (!cta?.data) return null;

  return (
    <button className="str-retail-cta" type="button" style={ctaStyleToCssVars(assets?.shoppable?.ctaStyle)}>
      {cta.data.value}
    </button>
  );
};
