import type { Payload, TrackerService } from '@web-rendering/groundcontrol-core';
import type { AdExperienceBaseProps } from '../types';

export interface BannerProps extends AdExperienceBaseProps {
  trackerService: TrackerService<unknown> | null;
}

export interface BannerState {
  payload: Payload;
}

export interface GWDWindow extends Window {
  studioV2: {
    api: {
      creatives: [
        {
          [key: string]: {
            [key: string]: {
              Exit: {
                [exitKey: string]: {
                  url: string;
                };
              };
            };
          };
        }
      ];
    };
  };
}

export const isGWDWindow = (window: Window | null | undefined): window is GWDWindow => {
  if (!window) return false;

  // a sandboxed cross-origin iframe (missing allow-same-origin) throws a SecurityError
  // on any property access against its WindowProxy, including the `in` operator
  try {
    return (
      'studioV2' in window &&
      typeof window.studioV2 === 'object' &&
      window.studioV2 !== null &&
      'api' in window.studioV2 &&
      typeof window.studioV2.api === 'object' &&
      window.studioV2.api !== null &&
      'creatives' in window.studioV2.api &&
      Array.isArray(window.studioV2.api.creatives) &&
      window.studioV2.api.creatives.length >= 0
    );
  } catch {
    return false;
  }
};
