import { Signal } from '@preact/signals';
import { type Creative, type Network, usePayload } from '@web-rendering/groundcontrol-core';
import { shouldDisableAdChoices } from '../../../../../../modules/policies/disable-ad-choices';
import type { FunctionComponent } from 'preact';
import { GreenPmpIcon } from '../../../green-pmp-icon/green-pmp-icon';
import { OptOutIcon } from '../../../opt-out-icon/opt-out-icon';
import './drawer.scss';
import { Behaviors } from '@web-rendering/groundcontrol-eqt';
import { clsx } from 'clsx';

export const disableAdChoices = new Signal<boolean>(false);

interface DrawerProps {
  creative: Creative;
  network: Network;
}

// ! this is a temporary solution to show the green pmp icon
// ! should be needed until we start deprecating the butler response
const shouldShowGreenPmpIcon = () => {
  const payload = usePayload();
  if (!payload) return false;

  const behaviors = payload.creative.behaviors ?? [];

  return behaviors.includes('shouldGreenPMP') || behaviors.includes(Behaviors.GreenPMP);
};

export const Drawer: FunctionComponent<DrawerProps> = (props: DrawerProps) => {
  const { creative, network } = props;

  // The policy answers for this creative only: writing it back to the page-wide signal would strip
  // AdChoices from every ad rendered after this one on the same page
  const isAdChoicesDisabled = shouldDisableAdChoices(creative) || disableAdChoices.value;

  return (
    <div
      className={clsx('str-buttons-container', creative.behaviors?.includes('shouldRelocateAdchoicesLogo') && 'bottom')}
    >
      {shouldShowGreenPmpIcon() && <GreenPmpIcon creative={creative} />}
      {!isAdChoicesDisabled && <OptOutIcon creative={creative} network={network} />}
    </div>
  );
};
