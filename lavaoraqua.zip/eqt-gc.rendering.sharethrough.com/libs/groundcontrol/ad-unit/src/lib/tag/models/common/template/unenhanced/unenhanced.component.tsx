import type { FunctionComponent } from 'preact';
import type { TemplateProps } from '../types';
import Drawer from '../enhanced/drawer';

export const UnenhancedTemplate: FunctionComponent<TemplateProps> = ({ creative, network, children }) => {
  return (
    <div class={`str-adunit str-adunit-banner-only str-compiled-template-unenhanced`} data-testid="unenhanced-adunit">
      {children}
      {/* @ts-expect-error: stuff */}
      <Drawer creative={creative} network={network} />
    </div>
  );
};
