import type { GCEnhancementType } from '@sharethrough/groundcontrol-enhancement-flush';
import { trackerService, usePayload } from '@web-rendering/groundcontrol-core';
import type { Enhancement } from '@web-rendering/groundcontrol-shared-types';
import { ButlerContext } from '../../../modules/butler/butler-provider';
import type { RefObject } from 'preact';
import { useContext, useEffect, useState } from 'preact/hooks';

export const useButler = () => {
  return useContext(ButlerContext);
};

export const useEnhancement = <T extends Enhancement>(): {
  enhancement: T | null;
} => {
  const payload = usePayload();

  if (!payload?.enhancement) {
    return {
      enhancement: null
    };
  }

  // we could even directly return the enhancement object here instead of nesting it
  return { enhancement: payload?.enhancement as T };
};

export const useDimensions = (ref: RefObject<HTMLElement>) => {
  const butlerResponse = useButler();

  const [dimensions, setDimensions] = useState({
    creativeDimensions: { width: 0, height: 0 },
    placementDimensions: { width: 0, height: 0 },
    creativeEl: null as HTMLElement | null,
    placementEl: null as HTMLElement | null
  });

  useEffect(() => {
    if (!ref.current || (dimensions.creativeEl && dimensions.placementEl)) return;

    setDimensions((prevDimensions) => ({
      ...prevDimensions,
      creativeEl: ref.current!.closest('.str-thumbnail-wrapper') as HTMLElement,
      placementEl: ref.current!.closest('.str-adunit') as HTMLElement
    }));
  }, [ref, dimensions.creativeEl, dimensions.placementEl]);

  useEffect(() => {
    if (!butlerResponse || (!dimensions.creativeEl && !dimensions.placementEl)) return;

    const { creative, placement } = butlerResponse;

    setDimensions((prevDimensions) => ({
      ...prevDimensions,
      creativeDimensions: {
        width: creative.size.width || dimensions.creativeEl?.clientWidth || 0,
        height: creative.size.height || dimensions.creativeEl?.clientHeight || 0
      },
      placementDimensions: {
        width: placement.size.width || dimensions.placementEl?.clientWidth || 0,
        height: placement.size.height || dimensions.placementEl?.clientHeight || 0
      }
    }));
  }, [butlerResponse, dimensions.creativeEl, dimensions.placementEl]);

  return dimensions;
};

export const useTextOverflow = (spanRef: RefObject<HTMLSpanElement>, width: number) => {
  const [textOverflow, setTextOverflow] = useState(false);

  useEffect(() => {
    if (!spanRef.current) return;

    const textWidth = spanRef.current.clientWidth;
    const divWidth = spanRef.current.parentElement?.clientWidth || 0;

    if (divWidth - textWidth < width) {
      setTextOverflow(true);
    }
  }, [spanRef, width]);

  return textOverflow;
};

/**
 * A custom hook to track when an enhancement is applied.
 *
 * @param renderedEnhancementType - The type of enhancement being tracked. If undefined, no tracking occurs.
 * @param isLoaded - A boolean indicating whether the enhancement has been loaded.
 *
 * This hook depends on the `trackerService` to perform the tracking. It triggers
 * the `trackIsEnhanced` method of `trackerService` whenever the `type` is defined,
 * `isLoaded` is true, and `trackerService.value` is available.
 */
export function useTrackIsEnhanced(renderedEnhancementType: GCEnhancementType | undefined, isLoaded: boolean) {
  const payload = usePayload();
  const payloadEnhancementType = payload?.enhancement?.type;

  const fallback = payloadEnhancementType !== renderedEnhancementType;

  useEffect(() => {
    if (trackerService.value && isLoaded && renderedEnhancementType) {
      trackerService.value.trackIsEnhanced(renderedEnhancementType, '', fallback);
    }
  }, [renderedEnhancementType, isLoaded, fallback]);
}
