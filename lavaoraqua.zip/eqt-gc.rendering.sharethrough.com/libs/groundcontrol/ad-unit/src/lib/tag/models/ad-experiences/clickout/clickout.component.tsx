import type { AdClickEvent } from '@sharethrough/groundcontrol-types';
import { dispatchNagCreativeType } from '@web-rendering/groundcontrol-beacon';
import type { NativeCreative, Payload, TrackerService } from '@web-rendering/groundcontrol-core';
import { PayloadContext, usePayload, useTrackerService } from '@web-rendering/groundcontrol-core';
import { PublisherStylingProvider } from '@ad-rendering/publisher-style';
import { setRenderEnd } from '@web-rendering/groundcontrol-store';
import { redirectSamePage, redirectUrl } from '@web-rendering/groundcontrol-utils';
import { MeasurementType } from '@web-rendering/groundcontrol-measurement/lib/types';
import type { MeasurementCore } from '@web-rendering/groundcontrol-measurement/lib/measurement-core';
import { Fragment } from 'preact';
import { Template } from '../../../../tag/models/common/template';
import Thumbnail from '../../../../tag/models/common/thumbnail';
import { AdExperienceBase } from '../ad-experience.base';
import { injectOnePixelScriptIntoDOM } from '../banner/utils/get-one-pixel-script';
import { armEmbeddedMeasurement } from '../common/measurement/arm-embedded-measurement';
import { getMeasurementType } from '../common/measurement/measurement-mode';
import { reportPublisherStylingOutcome } from '../common/publisher-styling/report-publisher-styling-outcome';
import type { AdExperienceBaseProps } from '../types';
import './clickout.scss';
import type { ClickoutCreative, ClickoutProps, ClickoutState } from './types';
import { bindStage } from '@web-rendering/groundcontrol-shared-types/lifecycle/lifecycle';
import { LifecycleStage } from '@web-rendering/groundcontrol-shared-types/lifecycle/lifecycle-stage';

export class ClickoutBase extends AdExperienceBase<ClickoutCreative, ClickoutProps, ClickoutState> {
  element: HTMLElement | null;
  trackerService: TrackerService<unknown> | null = null;
  measurementCore: MeasurementCore | null = null;

  static contextType = PayloadContext;
  declare context: Payload & {
    creative: NativeCreative;
  };

  constructor(props: ClickoutProps) {
    super(props);
    this.state = {
      clickEventFired: false
    };
    this.element = null;
    this.trackerService = props.trackerService;
  }

  componentDidMount() {
    this.trackerService?.trackImpression(this.element?.parentElement as HTMLElement, this.lifecycleScope);
    dispatchNagCreativeType(this.props.adserverRequestId);

    if (!this.context) return;

    const measurementType = getMeasurementType(this.context);
    const measuredImpressionScope = bindStage(this.lifecycleScope, LifecycleStage.MeasuredImpression);
    if (measurementType === MeasurementType.Embedded) {
      // Join the host measurement session from GC's own document: fires the Counted Impression once
      // at viewable, no external script injected (WR-2043 / WR-2087).
      this.measurementCore = this.trackerService
        ? (armEmbeddedMeasurement(this.trackerService, measuredImpressionScope) ?? null)
        : null;
    } else if (measurementType === MeasurementType.OnePixel && this.element) {
      // Legacy external OnePixel/MRAID script, kept until embedded measurement is the steady state.
      injectOnePixelScriptIntoDOM(this.context, measuredImpressionScope, this.element);
    }
    // Standard: GC's own impression tracking above is the whole story; nothing embedded to arm.
  }

  componentWillUnmount() {
    this.measurementCore?.teardown();
    this.measurementCore = null;
  }

  isValidClickTarget(target: HTMLElement): boolean {
    return !(
      target.classList.contains('str-opt-out-icon') ||
      target.classList.contains('str-green-pmp-icon') ||
      target.classList.contains('str-opt-out-label') ||
      target.classList.contains('str-subheader')
    );
  }

  handleAdClick = (clickEvent: AdClickEvent) => {
    if (clickEvent.event.target instanceof HTMLElement && !this.isValidClickTarget(clickEvent.event.target)) return;

    const target =
      clickEvent.event.target instanceof HTMLElement && clickEvent.event.target.dataset.strThumbnail === 'true'
        ? clickEvent.event.target
        : this.element;

    this.trackerService?.trackClick(target as HTMLElement);

    if (clickEvent.redirectUrl) {
      window.open(clickEvent.redirectUrl, '_blank');
      return;
    }

    const butlerCreative = this.butlerResponse?.creative;
    const creative = this.payload.creative;

    let url = creative.link;

    if (butlerCreative) {
      url = redirectUrl(butlerCreative.mediaUrl, butlerCreative.mediaUrlToken, butlerCreative.mediaUrlNonce);
    }

    if (butlerCreative?.clickoutSamePage) {
      redirectSamePage(url);
      return;
    }

    window.open(url, '_blank');
  };

  render() {
    setRenderEnd();

    return (
      <Fragment>
        <div
          className="str-react-template"
          data-testid="str-clickout"
          onClick={(event) => this.handleAdClick({ event })}
          ref={(element) => {
            this.element = element;
          }}
        >
          <Template
            creative={this.context.creative}
            network={this.context.network}
            country={this.context?.network.country}
            adserverRequestId={this.context?.id || ''}
            onEnhancementClick={this.handleAdClick}
          >
            <Thumbnail />
          </Template>
        </div>
      </Fragment>
    );
  }
}

export function Clickout(props: AdExperienceBaseProps) {
  const trackerService = useTrackerService();
  const payload = usePayload();

  return (
    <PublisherStylingProvider
      domain={payload?.network.domain || ''}
      onOutcome={reportPublisherStylingOutcome(trackerService)}
    >
      <ClickoutBase {...props} trackerService={trackerService} />
    </PublisherStylingProvider>
  );
}
