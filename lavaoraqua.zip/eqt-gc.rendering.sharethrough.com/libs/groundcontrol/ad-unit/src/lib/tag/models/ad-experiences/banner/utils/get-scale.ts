export const getScale = (
  containerWidth: number,
  containerHeight: number,
  adWidth: number,
  adHeight: number
): number => {
  return Math.min(containerHeight / adHeight, containerWidth / adWidth, 1);
};
