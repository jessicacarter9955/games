import { URLBeacon } from '@web-rendering/groundcontrol-beacon';
import { discoverMeasurementHost } from '@web-rendering/groundcontrol-measurement/lib/discovery/discover-measurement-host';
import { MeasurementCore } from '@web-rendering/groundcontrol-measurement/lib/measurement-core';
import type { LifecycleScope } from '@web-rendering/groundcontrol-shared-types/lifecycle/lifecycle';

import type { TrackerService } from '@web-rendering/groundcontrol-core';

/**
 * Arms the consume-only measurement core against the host measurement session for an ad rendered in
 * GC's own document (banner/native/clickout). Joins whatever MRAID and/or OMID session the host
 * exposes, fires the per-session `10012`/`10013` and the single Counted Impression once, then tears
 * down — with no external script injected (WR-2043 / WR-2086 / WR-2087).
 *
 * Returns the armed core so the caller can `teardown()` on unmount, or `undefined` when there is no
 * SAS config to source the tracking URLs from (nothing to fire).
 */
export function armEmbeddedMeasurement(
  trackerService: TrackerService<unknown>,
  scope: LifecycleScope
): MeasurementCore | undefined {
  const urls = trackerService.getSasConfig();
  if (!urls) return undefined;

  const host = discoverMeasurementHost();

  const core = new MeasurementCore((url) => {
    new URLBeacon({ url });
  }, scope);
  core.arm(host, urls);

  return core;
}
