import { registerObserver } from '../../../../../modules/observer';
import type { ImaSDK } from '@ad-rendering/ima-sdk';
import type { Signal } from '@preact/signals';
import { OUT_OF_VIEW_PAUSE_THRESHOLD } from '@web-rendering/groundcontrol-butler-helpers';

/**
 * Handles video ad playback based on the visibility of a given HTML element using Intersection Observer logic.
 *
 * Registers an observer on the provided `htmlObservableElement` to control the playback of a video ad via the `imaSDK`.
 * The behavior is determined by the `behaviors` array, which can include:
 * - `'shouldNotPauseOutOfView'`: Prevents the video from pausing when out of view.
 * - `'shouldPauseAtFiftyPercentOutOfView'`: Pauses the video when at least 50% out of view.
 *
 * @param imaSDK - The IMA SDK instance used to control video ad playback.
 * @param htmlObservableElement - The HTML element to observe for in-view/out-of-view changes.
 * @param videoStarted - Indicates whether the video ad has already started.
 * @param behaviors - Optional array of behavior flags to modify pause/resume logic.
 */
export const inviewVideoHandler = (
  imaSDK: ImaSDK,
  htmlObservableElement: HTMLDivElement,
  videoStarted: Signal<boolean>,
  behaviors: string[] | undefined
) => {
  const shouldNotPauseOutOfView = behaviors?.includes('shouldNotPauseOutOfView');
  const shouldPauseAtFiftyPercentOutOfView = behaviors?.includes('shouldPauseAtFiftyPercentOutOfView');
  const shouldPauseOnOutView = !shouldNotPauseOutOfView && shouldPauseAtFiftyPercentOutOfView;

  const outOfViewPercentage = behaviors?.includes('shouldPauseAtFiftyPercentOutOfView')
    ? OUT_OF_VIEW_PAUSE_THRESHOLD
    : 0.01;
  const inViewPercentage = behaviors?.includes('shouldPauseAtFiftyPercentOutOfView')
    ? OUT_OF_VIEW_PAUSE_THRESHOLD
    : 0.01;

  registerObserver({
    element: htmlObservableElement,
    inViewPercentage,
    outOfViewPercentage,
    inViewCallback: () => {
      if (!videoStarted.value) {
        imaSDK.video.start();
      } else {
        if (shouldPauseOnOutView) {
          imaSDK.video.resume();
        }
      }
    },
    outOfViewCallback: () => {
      if (shouldPauseOnOutView) {
        imaSDK.video.pause();
      }
    }
  });
};
