type VisibilityListener = (visible: boolean) => void;

export class VisibilityObserver {
  private listeners: Set<VisibilityListener> = new Set();

  constructor() {
    window.document.addEventListener('visibilitychange', this.handleChange);
  }

  private handleChange = () => {
    const visible = !window.document.hidden;
    this.listeners.forEach((cb) => cb(visible));
  };

  subscribe(cb: VisibilityListener) {
    this.listeners.add(cb);
    cb(!document.hidden);
    return () => {
      this.listeners.delete(cb);
    };
  }

  disconnect() {
    document.removeEventListener('visibilitychange', this.handleChange);
    this.listeners.clear();
  }
}
