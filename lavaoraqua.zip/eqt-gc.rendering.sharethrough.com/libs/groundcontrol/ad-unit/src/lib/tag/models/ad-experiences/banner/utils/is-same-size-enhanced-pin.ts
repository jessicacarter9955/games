import { GCEnhancementType } from '@sharethrough/groundcontrol-enhancement-flush';
import { isEnhanceable } from '@web-rendering/groundcontrol-butler-helpers';
import { CreativeType } from '@web-rendering/groundcontrol-shared-types';
import { isSameSizePinAllowedCombo } from '@web-rendering/groundcontrol-core';
import type { Creative } from '@web-rendering/groundcontrol-core';
import type { Enhancement, EnhancementType } from '@web-rendering/groundcontrol-shared-types';

export interface IsSameSizeEnhancedPinParams {
  width: number | undefined;
  height: number | undefined;
  networkWidth: number | undefined;
  networkHeight: number | undefined;
  creative: Creative;
  enhancement: Enhancement;
}

// CE-178209542 FR3 / Out of scope (decided 2026-08-26): BannerBrandedHeadline is excluded from
// the same-size combinations same as BannerShoppableOverlay — both stay native-size, unpinned.
// Shared with the scaleFactors native branch in banner.component.tsx / banner-unenhanced.component.tsx
// so the two lists can't drift.
export const SAME_SIZE_PIN_EXEMPT_ENHANCEMENT_TYPES: readonly EnhancementType[] = [
  GCEnhancementType.BannerShoppableOverlay,
  GCEnhancementType.BannerBrandedHeadline
];

export const isSameSizeEnhancedPin = ({
  width,
  height,
  networkWidth,
  networkHeight,
  creative,
  enhancement
}: IsSameSizeEnhancedPinParams): boolean => {
  if (width == null || height == null || networkWidth == null || networkHeight == null) return false;
  if (width !== networkWidth || height !== networkHeight) return false;
  // FR3 (CE-178209542) allowlists exactly 3 same-size combinations; a same-size banner outside
  // that list (e.g. 320x50, 300x50) isn't part of the restored matrix rows and stays native.
  if (!isSameSizePinAllowedCombo(width, height)) return false;
  // The plan's Global Constraint scopes the same-size pin to banner creatives only. isEnhanceable
  // alone doesn't enforce that (it also returns true for Outstream), so this predicate would
  // otherwise depend on an implicit guarantee from its call sites rather than its own name/intent.
  if (creative.type !== CreativeType.Banner) return false;
  if (!isEnhanceable(creative, enhancement)) return false;

  return !SAME_SIZE_PIN_EXEMPT_ENHANCEMENT_TYPES.includes(enhancement.type);
};
