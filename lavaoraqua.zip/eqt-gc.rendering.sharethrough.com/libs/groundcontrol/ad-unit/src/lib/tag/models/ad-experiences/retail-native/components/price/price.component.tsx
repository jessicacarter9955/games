import type { ShoppableProduct } from '@web-rendering/groundcontrol-ortb';
import type { FunctionComponent } from 'preact';
import { Fragment } from 'preact';
import './price.scss';

export const formatPrice = (value: string) => {
  const match = value.match(/^([^\d]*)(.+)$/);
  if (!match) return <Fragment>{value}</Fragment>;

  const [, symbol, amount] = match;
  return (
    <Fragment>
      {symbol && <span className="str-retail-price-symbol">{symbol}</span>}
      {amount}
    </Fragment>
  );
};

export const RetailNativePrice: FunctionComponent<{ product?: ShoppableProduct }> = ({ product }) => {
  const { salePrice, originalPrice } = product ?? {};
  const currentPrice = salePrice || originalPrice;
  if (!currentPrice) return null;

  // sale styling only when there is a regular price to strike through
  const struckPrice = salePrice && originalPrice;

  return (
    <div className="str-retail-price">
      <span className={struckPrice ? 'str-retail-current-price str-retail-sale-price' : 'str-retail-current-price'}>
        {formatPrice(currentPrice)}
      </span>
      {struckPrice && <span className="str-retail-original-price">{formatPrice(struckPrice)}</span>}
    </div>
  );
};
