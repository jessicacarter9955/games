import { GCEnhancementType } from '@sharethrough/groundcontrol-enhancement-flush';
import type { Enhancement } from '@web-rendering/groundcontrol-shared-types';

const IFRAME_BASED_ENHANCEMENTS: string[] = [
  GCEnhancementType.BannerSportsTicker,
  GCEnhancementType.OutstreamSportsTicker,
  GCEnhancementType.BannerShoppable,
  GCEnhancementType.OutstreamShoppable
];

const isIframeBasedEnhancement = (enhancement: Enhancement | null) => {
  if (!enhancement) return false;

  return IFRAME_BASED_ENHANCEMENTS.includes(enhancement.type);
};

export { isIframeBasedEnhancement };
