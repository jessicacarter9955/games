// TODO: use relative import instead
import type { OutstreamCaptionsPayload } from '@sharethrough/groundcontrol-enhancement-flush';
import { GCEnhancementType } from '@sharethrough/groundcontrol-enhancement-flush';
import { CaptionsEnhancement } from '@web-rendering/groundcontrol-enhancements';
import { CaptionsContext } from '../../../../../../../modules/enhancements/captions/captions-provider';
import { type FunctionComponent } from 'preact';
import { useContext, useEffect, useState } from 'preact/hooks';
import { useButler } from '../../../../../../../tag/models/ad-experiences/hooks';
import { useContent } from '../content.hook';
import { registerEnhancement } from '../registry';

export const Captions: FunctionComponent = () => {
  const butlerResponse = useButler();
  const captions = useContext(CaptionsContext);

  const { assets, enhancement, language, onError, onLoad, publisherStyles } = useContent<OutstreamCaptionsPayload>();

  const [innerCreativeId, setInnerCreativeId] = useState<undefined | string[]>();

  useEffect(() => {
    if (!enhancement) return;

    const srt = enhancement
      ? enhancement.payload.srt
      : butlerResponse
        ? 'srt' in butlerResponse.creative
          ? butlerResponse.creative.srt
          : {}
        : {};

    setInnerCreativeId(Object.keys(srt || {}));
  }, [enhancement]);

  if (!enhancement || !captions) return null;

  return (
    <CaptionsEnhancement
      assets={assets}
      captionInnerCreativeId={captions.innerCreativeId}
      currentCaption={captions.currentSubtitle ? captions.currentSubtitle.text : null}
      enhancement={enhancement}
      innerCreativeIds={innerCreativeId}
      language={language}
      onClick={() => undefined}
      onError={onError}
      onLoad={onLoad}
      publisherStyles={publisherStyles}
      videoElement={captions.videoElement}
    />
  );
};

registerEnhancement([GCEnhancementType.OutstreamCaptions], Captions);
