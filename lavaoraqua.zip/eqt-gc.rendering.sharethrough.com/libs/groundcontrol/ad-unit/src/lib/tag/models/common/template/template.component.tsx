import { loadFontFamily, usePublisherStyling } from '@ad-rendering/publisher-style';
import { isEnhanceable } from '@web-rendering/groundcontrol-butler-helpers';
import {
  LifecycleScopeProvider,
  useErrorHandler,
  useLifecycleScope,
  usePayload
} from '@web-rendering/groundcontrol-core';
import { CreativeType } from '@web-rendering/groundcontrol-shared-types';
import { reportError } from '@web-rendering/groundcontrol-monitoring';
import { LifecycleStage } from '@web-rendering/groundcontrol-shared-types/lifecycle/lifecycle-stage';
import { recreateChildScriptTags } from '@web-rendering/groundcontrol-utils';
import { Fragment } from 'preact';
import { forwardRef } from 'preact/compat';
import { useEffect, useMemo, useRef } from 'preact/hooks';
import { EnhancedTemplate } from './enhanced/enhanced.template';
import type { TemplateProps } from './types';
import { UnenhancedTemplate } from './unenhanced/unenhanced.component';
import { bindStage } from '@web-rendering/groundcontrol-shared-types/lifecycle/lifecycle';

export const Template = forwardRef<HTMLDivElement, TemplateProps>((props: TemplateProps, ref) => {
  const [error] = useErrorHandler();
  const adWrapperRef = useRef<HTMLElement | null>(null);
  const { styles, error: publisherStyleError } = usePublisherStyling();
  const payload = usePayload();
  const scope = useLifecycleScope();
  // Everything rendered inside the enhancement reports the enhancement stage, including its error
  // boundaries and async work that fails after the impression.
  const enhancementScope = useMemo(() => bindStage(scope, LifecycleStage.Enhancement), [scope]);

  useEffect(() => {
    if (adWrapperRef.current === null) return;
    // @ts-expect-error: Property 'base' does not exist on type 'HTMLElement' (is it correct on a Fragment?)
    const baseElement = adWrapperRef.current.base;
    if (baseElement) recreateChildScriptTags(baseElement.parentElement);
  }, [adWrapperRef]);

  useEffect(() => {
    if (publisherStyleError) {
      reportError(publisherStyleError, {
        scope,
        adserverRequestId: payload?.id
      });
      return;
    }

    if (!styles || !styles.fontFamily) return;
    loadFontFamily(styles.fontFamily);
  }, [styles, publisherStyleError]);

  const { adserverRequestId, creative, network, country, className, children } = props;
  const commonProps = { adserverRequestId, creative, network, className, country, children };
  // The enhanced template renders the creative inside itself, but the creative is not part of the
  // enhancement, so it keeps the Template's own scope.
  const enhancedProps = {
    ...commonProps,
    children: <LifecycleScopeProvider scope={scope}>{children}</LifecycleScopeProvider>
  };

  const creativeType = payload?.creative.type;

  const shouldRenderEnhancedTemplate =
    payload &&
    (isEnhanceable(payload.creative, payload?.enhancement) || creativeType === CreativeType.Native) &&
    !error;

  return (
    <div
      data-testid="str-compiled-template"
      className="str-compiled-template"
      style={{ width: '100%', height: '100%' }}
      ref={ref}
    >
      {shouldRenderEnhancedTemplate ? (
        <Fragment ref={adWrapperRef}>
          <LifecycleScopeProvider scope={enhancementScope}>
            <EnhancedTemplate {...enhancedProps} onEnhancementClick={props.onEnhancementClick} />
          </LifecycleScopeProvider>
        </Fragment>
      ) : (
        <UnenhancedTemplate {...commonProps} />
      )}
    </div>
  );
});
