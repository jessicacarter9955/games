import { getIframeDocumentSafely } from './get-iframe-document-safely';

export const addIframeWindowClick = (
  iframe: HTMLIFrameElement,
  onClickEvent: (event: MouseEvent) => void
): (() => void) | undefined => {
  const contentDocument = getIframeDocumentSafely(iframe);
  const contentWindow = contentDocument?.defaultView;

  if (!contentDocument || !contentWindow) {
    return;
  }

  if (!iframe.dataset.hasClickListener) {
    contentWindow.addEventListener('click', (event) => {
      onClickEvent(event);
    });
    iframe.dataset.hasClickListener = 'true';
  }

  const nestedCleanups: (() => void)[] = [];

  const observer = new MutationObserver(() => {
    const innerIframes = getIframeDocumentSafely(iframe)?.querySelectorAll('iframe');
    innerIframes?.forEach((innerIframe: HTMLIFrameElement) => {
      if (getIframeDocumentSafely(innerIframe)) {
        const cleanup = addIframeWindowClick(innerIframe, onClickEvent);
        if (cleanup) nestedCleanups.push(cleanup);
      }
    });
  });

  observer.observe(contentDocument, { childList: true, subtree: true });

  return () => {
    observer.disconnect();
    nestedCleanups.forEach((cleanup) => cleanup());
  };
};
