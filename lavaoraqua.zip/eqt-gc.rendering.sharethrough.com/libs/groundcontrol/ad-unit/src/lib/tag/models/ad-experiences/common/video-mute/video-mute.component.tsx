import type { FunctionComponent } from 'preact';
import type { VideoMuteProps } from './type';
import './video-mute.scss';
import { clsx } from 'clsx';

export const VideoMute: FunctionComponent<VideoMuteProps> = ({ muted, onClick, videoCompleted, videoStarted }) => {
  if (videoCompleted || !videoStarted) {
    return null;
  }

  return (
    <div
      className={clsx('str-icon-wrapper', muted ? 'str-icon-mute' : 'str-icon-sound')}
      onClick={onClick}
      data-testid="mute-button"
    ></div>
  );
};
