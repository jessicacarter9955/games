import { getWindowParentAttribute, trackerService, type Payload } from '@web-rendering/groundcontrol-core';
import { reportError } from '@web-rendering/groundcontrol-monitoring';
import { copyMraidToFrame } from '@web-rendering/groundcontrol-measurement/lib/discovery/copy-mraid-to-frame';
import type { LifecycleScope } from '@web-rendering/groundcontrol-shared-types/lifecycle/lifecycle';

const ONEPX_IMPRESSION_SCRIPT_URL = 'https://cdn.rendering.sharethrough.com/OnepxImpressionScript.js';

// Marks the host element with the impression it already carries a tracker for. Base got
// one-tracker-per-ad for free: the tracker lived in the creative iframe's srcdoc and died with the
// iframe on every content set. Running it in GC's own document, the injected AdContainerTypeTracker
// outlives React re-renders/remounts and its beacons dedupe only per instance — so without this
// guard, every remount that reuses the same host appends another tracker and fires another
// impression/mraid/omid. Keying on the impression URL (unique per ad serving) lets a genuinely new
// ad re-arm while a remount of the same ad does not double-count.
const ONEPX_INJECTED_ATTR = 'data-onepx-impression-id';

/**
 * @deprecated The OnePixel / MRAID measurement no longer runs inside the creative iframe. It now
 * runs in GroundControl's own document via `injectOnePixelScriptIntoDOM` (called from
 * `BannerIframe`), so `window.mraid` / `window.mraidbridge` are reached natively instead of a copy
 * that breaks in-app. This function is unused; kept as the revert path, slated for removal once the
 * change is validated in-app.
 *
 * Gets the one-pixel impression script HTML for iframe injection.
 */
export const getOnePixelImpressionScriptHtml = (payload: Payload, scope: LifecycleScope) => {
  if (!payload.reporting.countImpressionOnePixel) return '';

  if (!trackerService.value) {
    reportError(new Error('Tracker service not found'), {
      scope,
      context: 'get-one-pixel-script/get-html'
    });
    return '';
  }

  let sasConfig: ReturnType<typeof trackerService.value.getSasConfig>;

  try {
    sasConfig = trackerService.value?.getSasConfig();
  } catch (e) {
    console.log('getOnePixelImpressionScriptHtml: Error getting SAS config', e);
    reportError(e, { scope, context: 'get-one-pixel-script/get-html' });
    return '';
  }

  if (!sasConfig) {
    reportError(new Error('SAS config not found'), {
      scope,
      context: 'get-one-pixel-script/get-html'
    });
    return '';
  }

  try {
    return `
      <script>
        // Copy MRAID and its native bridge from the parent hierarchy into this iframe. Copying
        // mraid alone leaves mraidbridge behind, so mraid calls throw "mraidbridge is not defined".
        (function () {
          var getWindowParentAttribute = ${getWindowParentAttribute.toString()};
          var copyMraidToFrame = ${copyMraidToFrame.toString()};
          copyMraidToFrame(getWindowParentAttribute);
        })();
      </script>
      <script> window.SASAdContainerTypeTrackerConfig = ${JSON.stringify(sasConfig)} </script>
      <script src="${ONEPX_IMPRESSION_SCRIPT_URL}"></script>`;
  } catch (error) {
    reportError(error, { scope, context: 'get-one-pixel-script/get-html' });
    return '';
  }
};

/**
 * Injects one-pixel impression script directly into the DOM for non-iframe ad experiences (like clickout).
 * This uses the same logic as getOnePixelImpressionScriptHtml but injects scripts as DOM elements instead of HTML string.
 */
export const injectOnePixelScriptIntoDOM = (
  payload: Payload,
  scope: LifecycleScope,
  targetElement: HTMLElement = document.body
): boolean => {
  if (!payload.reporting.countImpressionOnePixel) return false;

  // At most one tracker per ad container — see ONEPX_INJECTED_ATTR.
  const impressionId = payload.reporting.trackerImpressionUrl ?? payload.id;
  if (targetElement.getAttribute(ONEPX_INJECTED_ATTR) === impressionId) return false;

  if (!trackerService.value) {
    reportError(new Error('Tracker service not found'), {
      scope,
      context: 'get-one-pixel-script/inject-dom'
    });
    return false;
  }

  let sasConfig: ReturnType<typeof trackerService.value.getSasConfig>;

  try {
    sasConfig = trackerService.value?.getSasConfig();
  } catch (e) {
    console.log('injectOnePixelScriptIntoDOM: Error getting SAS config', e);
    reportError(e, { scope, context: 'get-one-pixel-script/inject-dom' });
    return false;
  }

  if (!sasConfig) {
    reportError(new Error('SAS config not found'), {
      scope,
      context: 'get-one-pixel-script/inject-dom'
    });
    return false;
  }

  try {
    // Create and inject MRAID script (copies mraid AND its native bridge; see copyMraidToFrame)
    const mraidScriptElement = document.createElement('script');
    mraidScriptElement.textContent = `
      (function () {
        var getWindowParentAttribute = ${getWindowParentAttribute.toString()};
        var copyMraidToFrame = ${copyMraidToFrame.toString()};
        copyMraidToFrame(getWindowParentAttribute);
      })();
    `;
    targetElement.appendChild(mraidScriptElement);

    // Create and inject SAS config script
    const sasConfigScriptElement = document.createElement('script');
    sasConfigScriptElement.textContent = `window.SASAdContainerTypeTrackerConfig = ${JSON.stringify(sasConfig)}`;
    targetElement.appendChild(sasConfigScriptElement);

    // Create and inject impression script
    const impressionScriptElement = document.createElement('script');
    impressionScriptElement.src = ONEPX_IMPRESSION_SCRIPT_URL;
    targetElement.appendChild(impressionScriptElement);

    targetElement.setAttribute(ONEPX_INJECTED_ATTR, impressionId);
    return true;
  } catch (error) {
    reportError(error, { scope, context: 'get-one-pixel-script/inject-dom' });
    return false;
  }
};
