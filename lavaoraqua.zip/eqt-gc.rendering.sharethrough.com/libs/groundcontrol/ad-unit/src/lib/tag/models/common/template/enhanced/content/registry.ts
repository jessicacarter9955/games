import type { GCEnhancementType } from '@sharethrough/groundcontrol-enhancement-flush';
import type { EnhancementType } from '@web-rendering/groundcontrol-shared-types';
import type { ComponentType } from 'preact';
import type { EnhancedComponentProps } from './type';

// Registry maps enhancement types to dispatcher subcomponents. Each subcomponent
// side-effect-registers itself on import; per-app main.ts side-effect-imports only
// the subcomponents whose enhancement types that build serves. Unimported
// subcomponents (and their SCSS) tree-shake out of the bundle.
type EnhancementDispatch = ComponentType<EnhancedComponentProps>;

// Keyed by string so callers can pass the broader EnhancementType (includes
// 'default' / 'disabled' literals); registration is constrained to GCEnhancementType.
const registry = new Map<string, EnhancementDispatch>();

export function registerEnhancement(types: readonly GCEnhancementType[], component: EnhancementDispatch): void {
  for (const type of types) {
    registry.set(type, component);
  }
}

export function lookupEnhancement(type: EnhancementType | undefined): EnhancementDispatch | undefined {
  return type === undefined ? undefined : registry.get(type);
}
