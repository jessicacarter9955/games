import type { WeatherPayload } from '@sharethrough/groundcontrol-enhancement-flush/src/lib/interface/weather-payload.interface';
import { GCEnhancementType } from '@sharethrough/groundcontrol-enhancement-flush';
import { WeatherEnhancement } from '@web-rendering/groundcontrol-enhancements';
import type { FunctionComponent } from 'preact';
import { useContent } from '../content.hook';
import { registerEnhancement } from '../registry';

export const Weather: FunctionComponent = () => {
  const { assets, enhancement, language, onError, onLoad, publisherStyles } = useContent<WeatherPayload>();

  if (!enhancement) return null;

  return (
    <WeatherEnhancement
      assets={assets}
      enhancement={enhancement}
      language={language}
      onClick={() => undefined}
      onError={onError}
      onLoad={onLoad}
      publisherStyles={publisherStyles}
    />
  );
};

registerEnhancement(
  [
    GCEnhancementType.BannerWeather,
    GCEnhancementType.BannerDailyWeatherOutlook,
    GCEnhancementType.OutstreamWeather,
    GCEnhancementType.OutstreamDailyWeatherOutlook
  ],
  Weather
);
