import { useLifecycleScope, usePayload } from '@web-rendering/groundcontrol-core';
import { useNativeAssets } from '@web-rendering/groundcontrol-ortb';
import type { FunctionComponent } from 'preact';
import { createRef } from 'preact';
import { useEffect } from 'preact/hooks';
import { Drawer } from '../../../../../tag/models/common/template/enhanced/drawer/drawer.component';

import type { AdExperienceBaseProps } from '../../types';
import { useRetailTracker } from '../hooks/use-retail-tracker';
import { RetailNativeAdvertiser } from '../components/advertiser/advertiser.component';
import { RetailNativeBrandLogo } from '../components/brand-logo/brand-logo.component';
import { RetailNativeCta } from '../components/cta/cta.component';
import { RetailNativeDescription } from '../components/description/description.component';
import { RetailNativePrice } from '../components/price/price.component';
import { RetailNativeTitle } from '../components/title/title.component';
import { useAutoCycle } from '../hooks/use-auto-cycle';
import './carousel.scss';

const MAX_INACTIVE_THUMBNAILS = 4;

export const RetailShoppableCarousel: FunctionComponent<AdExperienceBaseProps> = () => {
  const payload = usePayload();
  const assets = useNativeAssets();
  const element = createRef<HTMLDivElement>();
  const trackerService = useRetailTracker();
  const scope = useLifecycleScope();
  const products = assets?.shoppable?.products ?? [];
  const { activeIndex: activeProductIndex, goTo, goNext, goPrev } = useAutoCycle(products.length);

  useEffect(() => {
    const parentElement = element.current?.parentElement;
    if (parentElement) {
      trackerService?.trackImpression(parentElement, scope);
    }
  }, []);

  if (!payload || !assets) return null;
  if (products.length === 0) return null;

  const activeProduct = products[activeProductIndex];

  // Render only the non-active products as thumbnails so the per-size CSS cap
  // (3 thumbnails, 4 on the 970x250 ultra-wide layout) counts deterministically.
  // Products beyond the cap stay reachable through the prev/next arrows.
  const inactiveThumbnails = products
    .map((product, index) => ({ product, index }))
    .filter((entry) => entry.index !== activeProductIndex)
    .slice(0, MAX_INACTIVE_THUMBNAILS);

  const handleShopClick = (event: MouseEvent) => {
    event.stopPropagation();
    const url = activeProduct.link ?? payload.creative.link;
    if (url) window.open(url, '_blank');
    trackerService?.trackClick(event.target as HTMLElement);
  };

  const handleThumbnailClick = (event: MouseEvent, index: number) => {
    event.stopPropagation();
    trackerService?.trackShoppableCarouselArrowClick();
    goTo(index);
  };

  const handleDotClick = (event: MouseEvent, index: number) => {
    event.stopPropagation();
    trackerService?.trackShoppableCarouselArrowClick();
    goTo(index);
  };

  const handlePrev = (event: MouseEvent) => {
    event.stopPropagation();
    trackerService?.trackShoppableCarouselArrowClick();
    goPrev();
  };

  const handleNext = (event: MouseEvent) => {
    event.stopPropagation();
    trackerService?.trackShoppableCarouselArrowClick();
    goNext();
  };

  return (
    <div ref={element} className="str-retail-shoppable-carousel-container" onClick={handleShopClick}>
      <div className="str-retail-shoppable-carousel">
        <div className="str-retail-shoppable-carousel-active">
          <button className="str-retail-shoppable-carousel-arrow prev" onClick={handlePrev}>
            &#8249;
          </button>
          <div className="str-retail-shoppable-carousel-active-img-stack">
            {products.map((product, index) => (
              <img
                key={index}
                src={product.images?.[0]?.url}
                alt={product.name ?? ''}
                className={`str-retail-shoppable-carousel-active-img ${index === activeProductIndex ? 'active' : ''}`}
                onClick={handleShopClick}
              />
            ))}
          </div>
          <button className="str-retail-shoppable-carousel-arrow next" onClick={handleNext}>
            &#8250;
          </button>
        </div>

        <div className="str-retail-shoppable-carousel-body">
          <RetailNativePrice product={activeProduct} />
          <RetailNativeTitle product={activeProduct} />
          <RetailNativeDescription product={activeProduct} />
        </div>

        <div className="str-retail-shoppable-carousel-thumbnails">
          {inactiveThumbnails.map(({ product, index }) => (
            <img
              key={index}
              src={product.images?.[0]?.url}
              alt={product.name ?? ''}
              className="str-retail-shoppable-carousel-thumbnail"
              onClick={(event: MouseEvent) => handleThumbnailClick(event, index)}
            />
          ))}
        </div>

        {products.length > 1 && (
          <div className="str-retail-carousel-dots">
            {products.map((_, index) => (
              <button
                key={index}
                className={`str-retail-carousel-dot${index === activeProductIndex ? ' active' : ''}`}
                onClick={(event: MouseEvent) => handleDotClick(event, index)}
              />
            ))}
          </div>
        )}

        <div className="str-retail-footer">
          <RetailNativeBrandLogo />
          <RetailNativeAdvertiser />
          <RetailNativeCta />
        </div>
      </div>

      <Drawer creative={payload.creative} network={payload.network} />
    </div>
  );
};
