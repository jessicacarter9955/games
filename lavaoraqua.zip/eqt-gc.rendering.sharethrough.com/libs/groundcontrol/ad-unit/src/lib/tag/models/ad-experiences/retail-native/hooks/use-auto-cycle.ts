import { useEffect, useRef, useState } from 'preact/hooks';

const DEFAULT_INTERVAL_MS = 3000;
// Resume rotation only after the viewer has stopped interacting for a beat,
// so the carousel never advances out from under an active reader.
const DEFAULT_RESUME_DELAY_MS = 6000;

const prefersReducedMotion = (): boolean =>
  typeof window !== 'undefined' &&
  typeof window.matchMedia === 'function' &&
  window.matchMedia('(prefers-reduced-motion: reduce)').matches;

export interface AutoCycleControls {
  activeIndex: number;
  goTo: (index: number) => void;
  goNext: () => void;
  goPrev: () => void;
}

/**
 * Drives a carousel's active index. The index auto-advances on a timer; any
 * manual navigation (goTo/goNext/goPrev) pauses the rotation and resumes it
 * after a quiet delay. Auto-advance is intentionally side-effect free — it never
 * fires interaction beacons, which are reserved for genuine viewer actions.
 */
export const useAutoCycle = (
  count: number,
  intervalMs: number = DEFAULT_INTERVAL_MS,
  resumeDelayMs: number = DEFAULT_RESUME_DELAY_MS
): AutoCycleControls => {
  const [activeIndex, setActiveIndex] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const resumeTimer = useRef<ReturnType<typeof setTimeout>>();

  useEffect(() => {
    if (count <= 1 || isPaused || prefersReducedMotion()) return;

    const advanceTimer = setTimeout(() => {
      setActiveIndex((index) => (index + 1) % count);
    }, intervalMs);

    return () => clearTimeout(advanceTimer);
  }, [activeIndex, count, isPaused, intervalMs]);

  useEffect(() => () => clearTimeout(resumeTimer.current), []);

  const goTo = (index: number) => {
    setIsPaused(true);
    clearTimeout(resumeTimer.current);
    resumeTimer.current = setTimeout(() => setIsPaused(false), resumeDelayMs);
    setActiveIndex(count > 0 ? ((index % count) + count) % count : 0);
  };

  return {
    activeIndex,
    goTo,
    goNext: () => goTo(activeIndex + 1),
    goPrev: () => goTo(activeIndex - 1)
  };
};
