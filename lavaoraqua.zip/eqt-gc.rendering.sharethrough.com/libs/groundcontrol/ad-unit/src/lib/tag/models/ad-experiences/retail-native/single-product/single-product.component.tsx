import { useLifecycleScope, usePayload } from '@web-rendering/groundcontrol-core';
import { useNativeAssets } from '@web-rendering/groundcontrol-ortb';
import type { FunctionComponent } from 'preact';
import { createRef } from 'preact';
import { useEffect } from 'preact/hooks';
import { Drawer } from '../../../../../tag/models/common/template/enhanced/drawer/drawer.component';

import type { AdExperienceBaseProps } from '../../types';
import { useRetailTracker } from '../hooks/use-retail-tracker';
import { RetailNativeAdvertiser } from '../components/advertiser/advertiser.component';
import { RetailNativeBrandLogo } from '../components/brand-logo/brand-logo.component';
import { RetailNativeCta } from '../components/cta/cta.component';
import { RetailNativeDescription } from '../components/description/description.component';
import { RetailNativePrice } from '../components/price/price.component';
import { RetailNativeThumbnail } from '../components/thumbnail/thumbnail.component';
import { RetailNativeTitle } from '../components/title/title.component';
import './single-product.scss';

export const RetailShoppableSingleProduct: FunctionComponent<AdExperienceBaseProps> = () => {
  const payload = usePayload();
  const assets = useNativeAssets();
  const element = createRef<HTMLDivElement>();
  const trackerService = useRetailTracker();
  const scope = useLifecycleScope();

  useEffect(() => {
    const parentElement = element.current?.parentElement;
    if (parentElement) trackerService?.trackImpression(parentElement, scope);
  }, []);

  if (!payload || !assets) return null;

  const product = assets.shoppable?.products[0];

  const handleClick = (event: MouseEvent) => {
    const url = product?.link ?? payload.creative.link;
    if (url) window.open(url, '_blank');
    trackerService?.trackClick(event.target as HTMLElement);
  };

  return (
    <div ref={element} className="str-retail-shoppable-single-product-container" onClick={handleClick}>
      <div className="str-retail-shoppable-single-product">
        <RetailNativeThumbnail product={product} />
        <div className="str-retail-shoppable-single-product-body">
          <RetailNativePrice product={product} />
          <RetailNativeTitle product={product} />
          <RetailNativeDescription product={product} />
        </div>
        <div className="str-retail-footer">
          <RetailNativeBrandLogo />
          <RetailNativeAdvertiser />
          <RetailNativeCta />
        </div>
      </div>
      <Drawer creative={payload.creative} network={payload.network} />
    </div>
  );
};
