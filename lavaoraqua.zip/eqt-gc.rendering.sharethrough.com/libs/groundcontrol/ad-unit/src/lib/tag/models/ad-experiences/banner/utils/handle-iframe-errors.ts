import type { PayloadContextType } from '@web-rendering/groundcontrol-core';
import { reportError } from '@web-rendering/groundcontrol-monitoring';
import type { LifecycleScope } from '@web-rendering/groundcontrol-shared-types/lifecycle/lifecycle';

export const handleIframeError = (
  error: Error,
  context: {
    isRestrictedIframeCaller: boolean;
    payload: PayloadContextType;
    scope: LifecycleScope;
    message: string;
    extraInfo?: Record<string, unknown>;
  }
) => {
  if (error instanceof Error) {
    reportError(error, {
      scope: context.scope,
      message: context.message,
      // Kept explicit so the per-caller sampling rules match even if the scope carries no identifiers.
      callerId: context.payload.network.callerId,
      networkId: context.payload.network.networkId,
      partnerId: context.payload.creative.partnerId,
      payload: context.payload,
      errorPayload: {
        isRestrictedIframeCaller: context.isRestrictedIframeCaller,
        ...context.extraInfo
      }
    });
  }
};
