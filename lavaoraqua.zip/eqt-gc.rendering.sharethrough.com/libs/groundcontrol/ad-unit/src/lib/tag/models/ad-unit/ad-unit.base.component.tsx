import type { Behaviors, ButlerResponse } from '@web-rendering/groundcontrol-shared-types';
import type { Payload, PayloadContextType } from '@web-rendering/groundcontrol-core';
import { getAdLifecycleScope, hasRichMediaInventory, trackerService } from '@web-rendering/groundcontrol-core';
import { CreativeType } from '@web-rendering/groundcontrol-shared-types';
import { reportError } from '@web-rendering/groundcontrol-monitoring';
import { isFriendlyIframe, SafeFrameHandler } from '@web-rendering/groundcontrol-utils';
import { clsx } from 'clsx';
import { CaptionsProvider } from '../../../modules/enhancements/captions/captions-provider';
import type { JSX, RefObject } from 'preact';
import { Component } from 'preact';
import type { CSSProperties } from 'preact/compat';
import './ad-unit.scss';
import { getDoubleVerifyTracker } from './utils/double-verify-trackers';
import { fitsContainer } from './utils/fits-container';
import { responsiveTemplate } from './utils/responsive-template';
import type { LifecycleScope } from '@web-rendering/groundcontrol-shared-types/lifecycle/lifecycle';

export type ReactAdUnitBaseProps = {
  id: string;
  response: ButlerResponse | null;
  payload: PayloadContextType;
  containerRef?: RefObject<HTMLDivElement>;
};

export abstract class ReactAdUnitBase<P extends ReactAdUnitBaseProps = ReactAdUnitBaseProps> extends Component<P> {
  element: HTMLElement | null = null;
  singleClickUsed = false;
  abstract experienceToRender(): JSX.Element | null;

  payload: Payload;
  // Bound when the ad unit is created, so a later render error keeps the stage that mounted it.
  protected readonly lifecycleScope: LifecycleScope;

  constructor(props: P) {
    super(props);

    trackerService.value?.trackExperiment();

    this.payload = props.payload;
    this.lifecycleScope = getAdLifecycleScope(props.payload?.id);
  }

  // TODO: Remove once butler response is fully converted to payload
  get creativeType() {
    if (!this.payload) return this.props.response?.creative.action;
    if (this.payload.creative.type === CreativeType.Native) {
      return this.payload.creative.nativeType;
    }

    return this.payload.creative.type;
  }

  get behaviors(): Partial<Behaviors> {
    if (!this.payload) return {};

    return (
      this.payload.creative.behaviors?.reduce((acc: Record<string, boolean>, behavior: string) => {
        acc[behavior] = true;
        return acc;
      }, {}) || {}
    );
  }

  get dvTracker(): string | null {
    const jsTrackers = this.payload?.creative.jsTrackers;
    if (jsTrackers) {
      return getDoubleVerifyTracker(jsTrackers);
    }
    return null;
  }

  adUnitAttrs = () => {
    const pkey = this.payload.network.networkId;
    const arid = this.payload.id;

    return {
      'data-str-native-key': pkey,
      'data-str-visited-flag': 'true',
      'data-str-arid': arid,
      'data-str-rendered': Date.now().toString()
    };
  };

  get placementSizeStyles(): { maxHeight: number | string; maxWidth: number | string } {
    const size = this.payload?.network?.size || { width: null, height: null };

    return {
      maxHeight: size.height || 'auto',
      maxWidth: size.width || 'auto'
    };
  }

  // life cycle method to catch any errors in rendering
  /* eslint-disable-next-line @typescript-eslint/no-explicit-any */
  override componentDidCatch(error: any): void {
    reportError(error, {
      scope: this.lifecycleScope,
      function: 'src/tag/models/ReactAdUnit:componentDidCatch',
      adserverRequestId: this.payload.id
    });
  }

  override componentDidMount(): void {
    if (isFriendlyIframe()) {
      trackerService.value?.trackFriendlyIframeEnv();
    }
    if (SafeFrameHandler.isSafeFrame()) {
      SafeFrameHandler.register();
    }
  }

  private getAdUnitStyles(width: number | string, height: number | string, responsive: boolean): CSSProperties {
    return {
      width: responsive ? undefined : width,
      height,
      maxWidth: width,
      maxHeight: height,
      minWidth: responsive ? undefined : width,
      minHeight: responsive ? undefined : height
    };
  }

  render() {
    const width = this.payload?.network?.size?.width || 'auto';
    const height = this.payload?.network?.size?.height || 'auto';
    const adUnitStyle = this.getAdUnitStyles(width, height, hasRichMediaInventory(this.payload?.network?.callerId));
    if (fitsContainer(this.payload) && isFriendlyIframe()) adUnitStyle.maxHeight = '100vh';
    const responsiveClass = responsiveTemplate(this.payload);

    return (
      <div
        className={clsx(`str-ad-unit str-ad-type-${this.payload.creative.type} str-responsive-ad`, responsiveClass)}
        data-testid="str-react-ad-unit"
        ref={(element) => {
          this.element = element;
        }}
        {...this.adUnitAttrs()}
        style={adUnitStyle}
      >
        <CaptionsProvider>{this.experienceToRender()}</CaptionsProvider>
      </div>
    );
  }
}

export default ReactAdUnitBase;
