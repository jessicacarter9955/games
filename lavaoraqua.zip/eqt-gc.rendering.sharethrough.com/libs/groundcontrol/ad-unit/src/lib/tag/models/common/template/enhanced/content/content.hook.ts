import { useEnhancement } from '../../../../../../tag/models/ad-experiences/hooks';
import { usePublisherStyling } from '@ad-rendering/publisher-style';
import { enhancementLoaded, useLifecycleScope, usePayload, useTrackerService } from '@web-rendering/groundcontrol-core';
import type { Enhancement } from '@web-rendering/groundcontrol-shared-types';
import type { EnhancementErrorEvent, EnhancementLoadedEvent } from '@web-rendering/groundcontrol-enhancements';
import { reportError } from '@web-rendering/groundcontrol-monitoring';
import { useNativeAssets } from '@web-rendering/groundcontrol-ortb';
import { getContentLanguage } from './get-content-language';
import type { ContentProps } from './type';

export const useContent = <T extends Enhancement>(_props?: ContentProps<T>): ContentProps<T> => {
  const enhancement = useEnhancement<T>().enhancement || undefined;
  const publisherStyles = usePublisherStyling().styles || undefined;
  const assets = useNativeAssets() || undefined;
  const payload = usePayload() || undefined;
  const trackerService = useTrackerService() || undefined;
  const scope = useLifecycleScope();
  const language = getContentLanguage(payload, enhancement);

  const onLoad = (event: EnhancementLoadedEvent) => {
    enhancementLoaded.value = true;
    trackerService?.trackIsEnhanced(event.enhancementType, '', event.fallback);
  };

  const onError = (event: EnhancementErrorEvent) => {
    reportError(event.error, {
      scope,
      context: 'template/enhancement-error',
      payloadId: payload?.id || '',
      enhancement: enhancement,
      errorPayload: event.data
    });
  };

  return {
    assets,
    enhancement,
    language,
    onError,
    onLoad,
    payload,
    publisherStyles
  };
};
