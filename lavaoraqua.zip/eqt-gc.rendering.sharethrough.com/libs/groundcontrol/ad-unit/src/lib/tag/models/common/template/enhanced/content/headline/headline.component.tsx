import { ButlerContext } from '../../../../../../../modules/butler/butler-provider';
import type { BannerHeadlinePayload, OutstreamHeadlinePayload } from '@sharethrough/groundcontrol-enhancement-flush';
import { GCEnhancementType } from '@sharethrough/groundcontrol-enhancement-flush';
import type { IHeadlineISIProps } from '@web-rendering/groundcontrol-enhancements';
import { HeadlineEnhancement } from '@web-rendering/groundcontrol-enhancements';
import clsx from 'clsx';
import { type FunctionComponent } from 'preact';
import { useContext } from 'preact/hooks';
import { useContent } from '../content.hook';
import { registerEnhancement } from '../registry';

export const Headline: FunctionComponent = () => {
  const butlerResponse = useContext(ButlerContext) || undefined;

  const { assets, enhancement, language, onError, onLoad, publisherStyles } = useContent<
    BannerHeadlinePayload | OutstreamHeadlinePayload
  >();

  const hasBlurredBackground = enhancement?.payload?.blurredBackground === true;

  const isi: undefined | IHeadlineISIProps = butlerResponse?.creative?.isi?.text
    ? {
        text: butlerResponse.creative.isi.text,
        header: butlerResponse.creative.behaviors.isiHeadlineOverride,
        subheader: butlerResponse.creative.behaviors.isiCustomSub,
        autoscroll: butlerResponse.creative.isi.autoscroll
      }
    : undefined;

  if (!enhancement) return null;

  return (
    <HeadlineEnhancement
      className={clsx(hasBlurredBackground && 'gc-exp-headline-alt')}
      assets={assets}
      enhancement={enhancement}
      isi={isi}
      language={language}
      onClick={() => undefined}
      onError={onError}
      onLoad={onLoad}
      publisherStyles={publisherStyles}
    />
  );
};

registerEnhancement([GCEnhancementType.BannerHeadline, GCEnhancementType.OutstreamHeadline], Headline);
