import { useNativeAssets } from '@web-rendering/groundcontrol-ortb';
import type { FunctionComponent } from 'preact';
import './amazon-logo.scss';

export const AmazonAvailableLogo: FunctionComponent = () => {
  const assets = useNativeAssets();
  if (!assets) return null;

  const { availableOnAmazon } = assets;
  if (!availableOnAmazon) return null;

  return (
    <div
      className="str-amazon-available-logo"
      data-testid="amazon-available-logo"
      style={{ backgroundImage: `url(${availableOnAmazon.img.url})` }}
    ></div>
  );
};
