import { isEnhanceable } from '@web-rendering/groundcontrol-butler-helpers';
import type { Payload } from '@web-rendering/groundcontrol-core';
import { hasRichMediaInventory } from '@web-rendering/groundcontrol-core';
import { CreativeType } from '@web-rendering/groundcontrol-shared-types';

// WR-2156: rich-media callers (Seedtag) render some products into a box smaller than network.size
// and expect the creative to fill it; a unit pinned to network.size is clipped there and never viewable.
export const fitsContainer = (payload: Payload | null | undefined): boolean =>
  !!payload &&
  payload.creative.type === CreativeType.Banner &&
  !isEnhanceable(payload.creative, payload.enhancement) &&
  hasRichMediaInventory(payload.network.callerId);
