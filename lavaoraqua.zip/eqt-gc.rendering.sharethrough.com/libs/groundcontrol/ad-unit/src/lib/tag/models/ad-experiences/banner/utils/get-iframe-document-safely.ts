export function getIframeDocumentSafely(iframe: HTMLIFrameElement | null | undefined): Document | null {
  if (!iframe) return null;

  try {
    return iframe.contentDocument || iframe.contentWindow?.document || null;
  } catch {
    // Genuinely cross-origin/sandboxed iframe (e.g. a caller embeds GC's own
    // script tag without allow-same-origin, WR-1149): contentWindow.document
    // throws instead of returning null, even for an iframe GC created itself.
    return null;
  }
}
