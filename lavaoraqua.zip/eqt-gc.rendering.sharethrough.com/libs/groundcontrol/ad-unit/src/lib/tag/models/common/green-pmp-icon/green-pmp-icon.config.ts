const GreenPmpIconConfig = {
  DEAL_ID_DISABLED: ['gxSag', 'NmBT2']
};

export default GreenPmpIconConfig;
