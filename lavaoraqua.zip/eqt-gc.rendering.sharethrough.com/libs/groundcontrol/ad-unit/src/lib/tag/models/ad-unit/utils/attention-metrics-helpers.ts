import type { RefObject } from 'preact';

/**
 * Calculates the absolute position of an element within an iframe relative to the parent window
 * @param containerRef - Reference to the container HTML element
 * @returns Object with absolute positions and viewport/zoom info
 */
export const calculateAttentionMetricsData = (containerRef: RefObject<HTMLDivElement>) => {
  // Return null if container reference is not available
  if (!containerRef.current) return null;

  const iframe = window.frameElement;
  // Return null if not in an iframe
  if (!iframe) return null;

  // Get element's position relative to viewport
  const iframeRect = iframe.getBoundingClientRect();

  // Calculate viewport and zoom
  const vp_w = window.top?.innerWidth ?? window.innerWidth;
  const vp_h = window.top?.innerHeight ?? window.innerHeight;
  const zoom_ratio = Math.round((window.top?.devicePixelRatio ?? window.devicePixelRatio) * 100) / 100;

  // Calculate absolute positions
  const absolutePosition = {
    top: iframeRect.top,
    bottom: iframeRect.bottom,
    left: iframeRect.left,
    right: iframeRect.right,
    vp_w,
    vp_h,
    zoom_ratio
  };

  return absolutePosition;
};
