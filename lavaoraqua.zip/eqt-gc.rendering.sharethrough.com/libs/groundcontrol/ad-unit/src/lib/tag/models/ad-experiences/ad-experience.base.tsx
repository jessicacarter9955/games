import type { ButlerCreative, ButlerResponse } from '@web-rendering/groundcontrol-shared-types';
import type { Payload } from '@web-rendering/groundcontrol-core';
import { getPayload, ResponseStore } from '@web-rendering/groundcontrol-store';
import { Component } from 'preact';
import type { AdExperienceBaseProps } from './types';
import type { AdClickEvent } from '@sharethrough/groundcontrol-types';
import { getAdLifecycleScope } from '@web-rendering/groundcontrol-core';
import type { LifecycleScope } from '@web-rendering/groundcontrol-shared-types/lifecycle/lifecycle';

export abstract class AdExperienceBase<
  TCreative extends ButlerCreative,
  TProps extends AdExperienceBaseProps,
  TState
> extends Component<TProps, TState> {
  // Bound when the experience is created, so an error it reports later keeps the stage that mounted it.
  protected readonly lifecycleScope: LifecycleScope;

  constructor(props: TProps) {
    super(props);
    this.lifecycleScope = getAdLifecycleScope(props.adserverRequestId);
  }

  _payload: Payload | null = null;
  get payload() {
    if (!this._payload) {
      this._payload = getPayload(this.props.adserverRequestId);
    }
    return this._payload;
  }

  _butlerResponse: ButlerResponse | null = null;
  get butlerResponse(): ButlerResponse {
    if (!this._butlerResponse) {
      this._butlerResponse = ResponseStore.getResponse(this.props.adserverRequestId);
    }
    return this._butlerResponse;
  }

  get creative(): TCreative {
    return this.butlerResponse?.creative as TCreative;
  }

  get placement() {
    if (this.butlerResponse) {
      return this.butlerResponse.placement;
    }
    return this.payload.network;
  }

  abstract handleAdClick: (event: AdClickEvent) => void;
}
