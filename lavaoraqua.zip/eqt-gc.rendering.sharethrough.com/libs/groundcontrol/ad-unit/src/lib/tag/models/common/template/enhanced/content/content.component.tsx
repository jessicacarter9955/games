import { usePayload } from '@web-rendering/groundcontrol-core';
import { CreativeType } from '@web-rendering/groundcontrol-shared-types';
import clsx from 'clsx';
import type { FunctionComponent } from 'preact';
import { useRef } from 'preact/hooks';
import { useButler, useEnhancement } from '../../../../../../tag/models/ad-experiences/hooks';
import { Fallback } from './fallback/fallback.component';
import { lookupEnhancement } from './registry';
import type { EnhancedComponentProps } from './type';

// Registry-based dispatcher. Subcomponents (Headline, Captions, etc.) self-register
// via side-effect imports from their respective module files. Per-app main.ts
// side-effect-imports only the subcomponents whose enhancement types that build
// serves; unimported subcomponents tree-shake out of the bundle.
export const EnhancedTemplateContent: FunctionComponent<EnhancedComponentProps> = ({ isOpen, onEnhancementClick }) => {
  const butlerResponse = useButler();
  const payload = usePayload();
  const { enhancement } = useEnhancement();
  const containerRef = useRef<HTMLDivElement>(null);

  if (!butlerResponse && !payload) {
    return null;
  }

  const Component = lookupEnhancement(enhancement?.type);

  return (
    <div
      className={clsx('str-enhanced-info-wrapper', {
        'str-enhanced-info-wrapper__native': payload?.creative.type === CreativeType.Native,
        'is-open': isOpen
      })}
      ref={containerRef}
    >
      {Component ? (
        <Component onEnhancementClick={onEnhancementClick} />
      ) : (
        <Fallback onEnhancementClick={onEnhancementClick} />
      )}
    </div>
  );
};
