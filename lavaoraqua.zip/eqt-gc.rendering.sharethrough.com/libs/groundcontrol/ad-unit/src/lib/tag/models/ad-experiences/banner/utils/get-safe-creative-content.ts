import type { Creative } from '@web-rendering/groundcontrol-core';

// DCM has two rendering modes that it supports: `iframe` and `script`
// Rendering in script allows us to get a clickout url, and doesn't
// seem to have an effect on the ad's ability to render.
function setDcmRenderingModeToScript(adm: string) {
  return adm.replace(/data-dcm-rendering-mode\s*=\s*('|")iframe('|")/, 'data-dcm-rendering-mode="script"');
}

export const getSafeCreativeContent = (creative: Creative | undefined) => {
  const creativeContent = creative?.content?.toString() || '';
  const raw = setDcmRenderingModeToScript(creativeContent);
  const unescaped = raw.replace(/<\\\/script>/gi, '</script>');

  return {
    raw,
    unescaped
  };
};
