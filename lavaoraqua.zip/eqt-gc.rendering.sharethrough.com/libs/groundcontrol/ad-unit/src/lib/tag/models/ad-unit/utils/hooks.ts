import type {
  AttentionMetricsPayload,
  AttentionMetricsRawSnapshot,
  AttentionMetricsSnapshot
} from '@web-rendering/groundcontrol-beacon';
import { isFriendlyIframe } from '@web-rendering/groundcontrol-utils';
import type { RefObject } from 'preact';
import { useCallback, useEffect, useLayoutEffect, useRef, useState } from 'preact/hooks';
import { calculateAttentionMetricsData } from './attention-metrics-helpers';

// Separate container event management into a custom hook for hover tracking
const useContainerEvents = (
  containerRef: RefObject<HTMLDivElement>,
  onMouseEnter: () => void,
  onMouseLeave: () => void,
  enabled = true
) => {
  useEffect(() => {
    if (!enabled) return;

    const element = containerRef.current;
    if (!element) {
      return;
    }

    element.addEventListener('mouseenter', onMouseEnter);
    element.addEventListener('mouseleave', onMouseLeave);

    return () => {
      element.removeEventListener('mouseenter', onMouseEnter);
      element.removeEventListener('mouseleave', onMouseLeave);
    };
  }, [containerRef.current, onMouseEnter, onMouseLeave, enabled]);
};

export const useSendBeacon = (
  rawSnapshots: AttentionMetricsRawSnapshot[],
  handler: (rawSnapshots: AttentionMetricsRawSnapshot[]) => void,
  timeoutDuration: number,
  enabled = true
) => {
  const timeoutRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    if (!enabled || !rawSnapshots.length) return;

    // Clear any previous timeout if rawSnapshot changes
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
    }

    // Set a new timeout
    timeoutRef.current = setTimeout(() => {
      handler(rawSnapshots); // Send the beacon with the current position history
    }, timeoutDuration);

    // Cleanup on unmount or when rawSnapshot changes
    return () => {
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
      }
    };
  }, [rawSnapshots, timeoutDuration, handler, enabled]);
};

export const useMeasureAttentionMetrics = (
  containerRef: RefObject<HTMLDivElement>,
  waitSeconds: number,
  enabled = true
) => {
  const rawSnapshotsRef = useRef<AttentionMetricsRawSnapshot[]>([]);
  const lastSnapshotRef = useRef<string>('');

  const record = useCallback(() => {
    if (!enabled) return;
    recordSnapshot({ containerRef, rawSnapshotsRef, lastSnapshotRef, maxSnapshots: waitSeconds });
  }, [containerRef, rawSnapshotsRef, lastSnapshotRef, waitSeconds, enabled]);

  // Set up interval for position recording
  useEffect(() => {
    if (!enabled) return;

    const intervalId = setInterval(record, 1000);
    record(); // Initial recording
    return () => clearInterval(intervalId);
  }, [record, enabled]);

  return { getRawSnapshot: () => rawSnapshotsRef.current };
};

export const recordSnapshot = ({
  containerRef,
  rawSnapshotsRef,
  lastSnapshotRef,
  maxSnapshots
}: {
  containerRef: RefObject<HTMLDivElement>;
  rawSnapshotsRef: React.MutableRefObject<AttentionMetricsRawSnapshot[]>;
  lastSnapshotRef: React.MutableRefObject<string>;
  maxSnapshots: number;
}) => {
  // Collect all needed data from calculateAttentionMetricsData
  const position = calculateAttentionMetricsData(containerRef);
  if (!position) return;
  const positionString = JSON.stringify(position);

  if (positionString !== lastSnapshotRef.current) {
    lastSnapshotRef.current = positionString;

    // Keep max snapshots (x snapshots for x seconds window)
    if (rawSnapshotsRef.current && rawSnapshotsRef.current.length >= maxSnapshots) {
      rawSnapshotsRef.current = rawSnapshotsRef.current.slice(-(maxSnapshots - 1));
    }

    const rawSnapshot: AttentionMetricsRawSnapshot = {
      timestamp: Date.now(),
      data: position
    };

    rawSnapshotsRef.current?.push(rawSnapshot);
  }
};

export function buildAttentionMetricsData(
  rawSnapshots: AttentionMetricsRawSnapshot[],
  initTs: number
): AttentionMetricsSnapshot[] {
  return rawSnapshots.map((snapshot) => {
    const ts_offset = Math.round(snapshot.timestamp / 1000) - initTs;
    let x = 0,
      y = 0,
      vp_w = 0,
      vp_h = 0,
      zoom_ratio = 1;
    if (snapshot.data) {
      x = Math.round(snapshot.data.left * 100) / 100;
      y = Math.round(snapshot.data.top * 100) / 100;
      vp_w = snapshot.data.vp_w;
      vp_h = snapshot.data.vp_h;
      zoom_ratio = snapshot.data.zoom_ratio;
    }
    return { ts_offset, vp_w, vp_h, x, y, zoom_ratio };
  });
}

export const useFontSizeAdjustmentOnOverflow = (
  ref: RefObject<HTMLDivElement>,
  closestSelector: string,
  minSize = 14
) => {
  const UNSET_FONT_SIZE = 0;
  const FONT_SIZE_STEP = 1;

  const [clientAdjustedFontSize, setClientAdjustedFontSize] = useState<number>(UNSET_FONT_SIZE);

  useLayoutEffect(() => {
    if (!ref.current) return;

    const elementToWatch = ref.current.closest(closestSelector);
    if (!elementToWatch) return;

    const currentSize = parseFloat(window.getComputedStyle(ref.current).fontSize);
    if (elementToWatch.scrollHeight > elementToWatch.clientHeight && currentSize >= minSize) {
      const adjustedSize = Math.floor(currentSize - FONT_SIZE_STEP);
      setClientAdjustedFontSize(adjustedSize);
    }
  }, [ref, closestSelector, clientAdjustedFontSize]);

  return clientAdjustedFontSize;
};

/**
 * useAttentionMetrics
 * Encapsulates all logic for attention metrics tracking and beacon sending.
 * Returns the containerRef to be attached to the tracked element.
 *
 * @param trackerService - the tracker service (from useTrackerService)
 * @param enabled - whether to enable attention metrics tracking (optional, default: true)
 */
export function useAttentionMetrics({
  trackerService,
  enabled = true,
  timeoutDuration = 5000, // ms
  waitSeconds = 5, // seconds
  stepInterval = 1000 // ms
}: {
  trackerService?: { trackAttentionMetrics?: (payload: AttentionMetricsPayload) => void };
  enabled?: boolean;
  timeoutDuration?: number;
  waitSeconds?: number;
  stepInterval?: number;
}) {
  const containerRef = useRef<HTMLDivElement>(null);
  const initTsRef = useRef<number>(Math.floor(Date.now() / 1000)); // epoch seconds
  const stepSeconds = stepInterval / 1000;
  const hoverCountRef = useRef(0);
  const isHoveredRef = useRef(false);

  const hoverStartTsRef = useRef<number | null>(null); // ms
  const hoverCumulativeRef = useRef(0); // seconds (float)
  const hoverMaxStreakRef = useRef(0);

  const r2 = (n: number) => Math.round(n * 100) / 100;

  const closeActiveHover = useCallback((nowMs: number) => {
    if (isHoveredRef.current && hoverStartTsRef.current != null) {
      const durSec = (nowMs - hoverStartTsRef.current) / 1000;
      hoverCumulativeRef.current += durSec;
      if (durSec > hoverMaxStreakRef.current) {
        hoverMaxStreakRef.current = durSec;
      }
      hoverStartTsRef.current = null;
      isHoveredRef.current = false;
    }
  }, []);

  const handleMouseEnter = useCallback(() => {
    if (!isHoveredRef.current) {
      isHoveredRef.current = true;
      hoverStartTsRef.current = performance.now();
      hoverCountRef.current += 1;
    }
  }, []);

  const handleMouseLeave = useCallback(() => {
    closeActiveHover(performance.now());
  }, [closeActiveHover]);

  // Check if we should enable position tracking
  const shouldTrackAttentionMetrics = useCallback(() => {
    return enabled && isFriendlyIframe();
  }, [enabled]);

  const trackingEnabled = shouldTrackAttentionMetrics();

  useContainerEvents(containerRef, handleMouseEnter, handleMouseLeave, trackingEnabled);

  const attentionMetricsTracking = useMeasureAttentionMetrics(containerRef, waitSeconds, trackingEnabled);

  useSendBeacon(
    attentionMetricsTracking.getRawSnapshot(),
    (snapshot) => {
      if (trackerService?.trackAttentionMetrics) {
        // Make sure to close any in-progress hover before sending
        closeActiveHover(performance.now());

        const data = buildAttentionMetricsData(snapshot, initTsRef.current);
        // Extract ad_w and ad_h from the first data entry if available
        let ad_w = 0,
          ad_h = 0;
        if (snapshot.length > 0 && snapshot[0].data) {
          ad_w = snapshot[0].data.right - snapshot[0].data.left;
          ad_h = snapshot[0].data.bottom - snapshot[0].data.top;
        }

        // Finalized hover metrics for this beacon
        const hover_cumulative_time = r2(hoverCumulativeRef.current);
        const hover_consecutive_time = r2(hoverMaxStreakRef.current);

        trackerService.trackAttentionMetrics({
          init_ts: initTsRef.current,
          wait: waitSeconds,
          step: stepSeconds,
          ad_w,
          ad_h,
          hovers: hoverCountRef.current,
          hover_cumulative_time,
          hover_consecutive_time,
          data
        });
      }
    },
    timeoutDuration,
    trackingEnabled
  );

  return { containerRef };
}
