import { useNativeAssets } from '@web-rendering/groundcontrol-ortb';
import type { FunctionComponent } from 'preact';
import './product-image.scss';

export const AmazonProductImage: FunctionComponent = () => {
  const assets = useNativeAssets();
  if (!assets) return null;

  const { mainImage } = assets;
  if (!mainImage) return null;

  return (
    <div
      className="str-amazon-product-image"
      data-testid="amazon-product-image"
      style={{ backgroundImage: `url(${mainImage.img.url})` }}
    ></div>
  );
};
