import type { Payload } from '@web-rendering/groundcontrol-core';

export interface PayloadSizes {
  placementSize: { width: number | null; height: number | null };
  creativeSize: { width: number | null; height: number | null };
  placementStringSize: string;
  creativeStringSize: string;
}

export function getPayloadSizes(payload: Payload): PayloadSizes {
  return {
    placementSize: {
      width: payload.network.size?.width || null,
      height: payload.network.size?.height || null
    },
    creativeSize: {
      width: payload.creative.size?.width || null,
      height: payload.creative.size?.height || null
    },
    placementStringSize: payload.network.size ? `${payload.network.size?.width}x${payload.network.size.height}` : '',
    creativeStringSize: payload.creative.size ? `${payload.creative.size.width}x${payload.creative.size.height}` : ''
  };
}
