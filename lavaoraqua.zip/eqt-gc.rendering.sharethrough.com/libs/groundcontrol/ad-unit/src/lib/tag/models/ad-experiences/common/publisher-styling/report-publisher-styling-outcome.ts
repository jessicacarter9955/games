import type { TrackerService } from '@web-rendering/groundcontrol-core';
import type { PublisherStylingOutcome } from '@ad-rendering/publisher-style';

/**
 * Bridges the publisher-style lib to the tracker. The lib stays a leaf that imports nothing else in
 * GroundControl, so the mapping from outcome to beacon lives here instead.
 */
export const reportPublisherStylingOutcome =
  (trackerService: TrackerService<unknown> | null) =>
  (outcome: PublisherStylingOutcome): void => {
    if (outcome === 'requested') {
      trackerService?.trackPublisherStylingRequested();
      return;
    }

    trackerService?.trackPublisherStylingLoaded();
  };
