import type { Payload } from '@web-rendering/groundcontrol-core';
import { CreativeType } from '@web-rendering/groundcontrol-shared-types';
import { NativeType } from '@web-rendering/groundcontrol-core';
import { getPayloadSizes } from './get-payload-sizes';
import { SizeType } from './types';

const isResponsiveCreativeType = (payload: Payload): boolean => {
  const creativeType = payload.creative.type;

  if (creativeType === CreativeType.Banner) return true;
  if (creativeType === CreativeType.Outstream) return true;

  if (creativeType === CreativeType.Native) {
    const nativeType = payload.creative.nativeType;
    if (nativeType === NativeType.Clickout || nativeType === NativeType.Video) return true;
  }

  return false;
};

export const responsiveTemplate = (payload: Payload): string | null => {
  // TODO: Remove once butler response is fully converted to payload
  if (!isResponsiveCreativeType(payload)) return null;

  const { placementSize, creativeSize } = getPayloadSizes(payload);

  if (placementSize.width && placementSize.height) {
    // TODO: Add some logic to handle sizeless placements
    const placementRatio = placementSize.width / placementSize.height;
    // TODO: Refactor to set creativeSizeType to Square for native types (when creative dimensions not provided)
    const creativeRatio = (creativeSize.width || 16) / (creativeSize.height || 9);
    const placementSizeType = getSizeType(placementRatio);
    const creativeSizeType = getSizeType(creativeRatio);

    return `str-responsive str-responsive-placement-${placementSizeType} str-responsive-creative-${creativeSizeType}`;
  }

  return null;
};

export const getSizeType = (ratio: number): SizeType => {
  return ratio <= 2 / 7
    ? SizeType.Tallest
    : ratio <= 4 / 5
      ? SizeType.Tall
      : ratio <= 6 / 4
        ? SizeType.Square
        : ratio <= 7 / 2
          ? SizeType.Wide
          : SizeType.Widest;
};
