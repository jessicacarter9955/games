import type { PayloadContextType } from '@web-rendering/groundcontrol-core';
import { handleIframeError } from './handle-iframe-errors';
import type { LifecycleScope } from '@web-rendering/groundcontrol-shared-types/lifecycle/lifecycle';

export const setRestrictedIframeContent = (
  iframe: HTMLIFrameElement,
  html: string,
  payload: PayloadContextType,
  scope: LifecycleScope
): boolean => {
  try {
    iframe.srcdoc = html;
  } catch (error) {
    try {
      // Fallback to src
      iframe.src = `data:text/html,${encodeURIComponent(html)}`;
    } catch (srcError) {
      // Only report the final error with context of both failures
      if (!(srcError instanceof Error)) return false;
      handleIframeError(srcError, {
        message: 'SetRestrictedIframeContent: Failed to set iframe content (both srcdoc and src)',
        isRestrictedIframeCaller: true,
        payload,
        scope,
        extraInfo: {
          initialError: error instanceof Error ? error.message : String(error),
          fallbacksAttempted: ['srcdoc', 'src']
        }
      });
      return false;
    }
  }

  return true;
};
