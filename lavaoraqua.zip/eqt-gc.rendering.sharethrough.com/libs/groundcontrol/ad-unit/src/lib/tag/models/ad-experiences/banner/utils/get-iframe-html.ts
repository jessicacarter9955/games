import { bannerIframeErrorListener, hasRichMediaInventory, type Payload } from '@web-rendering/groundcontrol-core';
import { responsiveTemplate } from '../../../ad-unit/utils/responsive-template';

// NOTE: the OnePixel / MRAID impression script is no longer injected into this iframe. It now
// runs in GroundControl's own document (see BannerIframe → injectOnePixelScriptIntoDOM) so it can
// reach window.mraid + window.mraidbridge natively instead of a copy that breaks in-app.
export const getIframeHtml = (payload: Payload, adm: string, scale: number): string => {
  if (responsiveTemplate(payload) && !hasRichMediaInventory(payload.network.callerId)) {
    return responsiveIframe(adm, payload.creative.size.width, payload.creative.size.height);
  }
  return defaultIframeHtml(adm, scale);
};

// Extracted (rather than left inline in the resize() script string below) so it's a real,
// directly unit-testable function instead of a code fragment we can only check by string-matching.
export const applyIframeContentScale = (thumbnailContent: HTMLElement | null, scale: number): void => {
  if (!thumbnailContent) return;

  // Any non-none transform, including the identity scale(1), makes the element a containing
  // block for position: fixed/absolute descendants. Clearing it instead of leaving scale(1)
  // avoids breaking creatives that rely on fixed-position overlays or close buttons.
  if (scale === 1) {
    thumbnailContent.style.removeProperty('transform');
  } else {
    thumbnailContent.style.transform = 'scale(' + scale + ')';
  }
};

export const defaultIframeHtml = (adm: string, scale: number, scripts = ''): string => {
  // transform (even scale(1)) makes this element a containing block for fixed/absolute
  // descendants, which breaks creatives that use position: fixed for overlays or close
  // buttons. Only apply it when a real Size Multiplexing scale is in effect.
  const scaleStyle = scale === 1 ? '' : `transform: scale(${scale});\n          transform-origin: left top;`;
  return `
  <html>
    <head>
      <style>
        .str-thumbnail-body {
          margin: 0 auto;
          overflow: -moz-scrollbars-none;
          width: 100%;
          height: 100%;
          ${scaleStyle}
        }
        .str-thumbnail-body::-webkit-scrollbar { width: 0 !important };
        .str-thumbnail-body::-webkit-scrollbar::-ms-overflow-style: none;
      </style>
      <script>
        var bannerIframeErrorHandler = ${bannerIframeErrorListener.toString()};
        function onLoad() {
          window.removeEventListener('error', bannerIframeErrorHandler);
          window.removeEventListener('load', onLoad);
        }

        window.addEventListener('error', bannerIframeErrorHandler);
        window.addEventListener('load', onLoad);
      </script>
    </head>
    <body class='str-thumbnail-body'>
      ${adm}
    </body>
    ${scripts}
  </html>`;
};

export const responsiveIframe = (adm: string, width: number | null, height: number | null, scripts = ''): string => {
  return `
  <html>
    <head>
      <style>
        html, body {
          margin: 0;
          padding: 0;
          width: 100%;
          height: 100%;
          overflow: hidden;
        }
        .str-thumbnail-body {
          display: flex;
          align-items: center;
          justify-content: center;
          width: 100%;
          height: 100%;
        }
        .str-thumbnail-content {
          width: ${width}px;
          height: ${height}px;
          transform-origin: center;
        }
        .str-thumbnail-content-scale {
          width: 100%;
          height: 100%;
        }
      </style>
      <script>
        var bannerIframeErrorHandler = ${bannerIframeErrorListener.toString()};
        function onLoad() {
          window.removeEventListener('error', bannerIframeErrorHandler);
          window.removeEventListener('load', onLoad);
        }

        window.addEventListener('error', bannerIframeErrorHandler);
        window.addEventListener('load', onLoad);
      </script>
      <script>
        var applyIframeContentScale = ${applyIframeContentScale.toString()};
        function resize() {
          const thumbnailBody = document.querySelector(".str-thumbnail-body");
          const thumbnailContent = document.querySelector(".str-thumbnail-content");
          const width = ${width};
          const height = ${height};

          const containerWidth = thumbnailBody?.clientWidth;
          const containerHeight = thumbnailBody?.clientHeight;

          const heightScale = containerHeight / height;
          const widthScale = containerWidth / width;
          const scale = Math.min(heightScale, widthScale, 1);

          applyIframeContentScale(thumbnailContent, scale);
        }
        window.addEventListener("DOMContentLoaded", resize, { once: true });
        window.addEventListener("resize", resize);

        resize();
      </script>
      <script>
        // var is function-scoped and can be redeclared
        // handles error: 'targetOrigin' has already been declared
        var targetOrigin = '*';
        try {
          const origin = window.parent.location.origin;
          if (origin !== "null") targetOrigin = origin;
        } catch (_) {} // keep '*'

        window.addEventListener('message', (event) => {
          if (event.data?.method === 'iframeclick') return;

          window.parent.postMessage({ ...event.data, originalOrigin: event.origin }, targetOrigin);
        });
      </script>
    </head>
    <body class="str-thumbnail-body">
      <div class="str-thumbnail-content">
        <div class="str-thumbnail-content-scale">${adm}</div>
      </div>
    </body>
    ${scripts}
  </html>
`;
};
