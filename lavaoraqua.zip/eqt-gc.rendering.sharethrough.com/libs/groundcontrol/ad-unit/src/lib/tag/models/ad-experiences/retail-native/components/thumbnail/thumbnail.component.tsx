import type { ShoppableProduct } from '@web-rendering/groundcontrol-ortb';
import type { FunctionComponent } from 'preact';
import './thumbnail.scss';

export const RetailNativeThumbnail: FunctionComponent<{ product?: ShoppableProduct }> = ({ product }) => {
  const url = product?.images?.[0]?.url;
  if (!url) return null;

  return (
    <div className="str-retail-thumbnail">
      <img src={url} alt="" className="str-retail-thumbnail-img" />
    </div>
  );
};
