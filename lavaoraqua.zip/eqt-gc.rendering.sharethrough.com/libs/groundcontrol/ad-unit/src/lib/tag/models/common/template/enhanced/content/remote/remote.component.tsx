import { type TemplateUrlEnhancementPayload } from '@sharethrough/groundcontrol-enhancement-flush';
import { GCEnhancementType } from '@sharethrough/groundcontrol-enhancement-flush';
import { SOFIA_PULSE_ENHANCEMENT_TYPES, useTrackerService } from '@web-rendering/groundcontrol-core';
import type { EnhancementErrorEvent } from '@web-rendering/groundcontrol-enhancements';
import {
  type EnhancementClickEvent,
  EnhancementClickEventType,
  RemoteEnhancement,
  RemoteEventType
} from '@web-rendering/groundcontrol-enhancements';
import { type FunctionComponent } from 'preact';
import { useContent } from '../content.hook';
import { registerEnhancement } from '../registry';
import type { EnhancedComponentProps } from '../type';

const isSofiaPulseEnhancement = (type: string): boolean => SOFIA_PULSE_ENHANCEMENT_TYPES.has(type);

export const Remote: FunctionComponent<EnhancedComponentProps> = ({ onEnhancementClick }) => {
  const { assets, enhancement, language, onError, onLoad, publisherStyles } =
    useContent<TemplateUrlEnhancementPayload>();
  const trackerService = useTrackerService();

  const onClick = (event: EnhancementClickEvent) => {
    if (!trackerService) return;
    switch (event.eventType) {
      case EnhancementClickEventType.ENGAGEMENT:
        trackerService.trackEnhancedEngagementClick();
        break;
      case EnhancementClickEventType.CONTENT:
        trackerService.trackEnhancedContentClick();
        break;
      case EnhancementClickEventType.PRODUCTCARD:
        trackerService.trackProductCardClick(event.productId);
        break;
      case EnhancementClickEventType.SHOPPABLECAROUSEL_ARROW:
        trackerService.trackShoppableCarouselArrowClick();
        break;
      case EnhancementClickEventType.CLICKTHROUGH:
        if (GC_INSTANCE_NAME === 'equativ') {
          trackerService.trackEnhancedContentClick();
        }
        if (onEnhancementClick) {
          const redirectUrl = enhancement?.payload.redirectUrl;
          onEnhancementClick({ event: new MouseEvent('click'), redirectUrl });
        }
        break;
    }
  };

  if (!enhancement) return null;

  const handleError = (event: EnhancementErrorEvent) => {
    if (!event.isPageFailure) onError(event);

    trackerService?.trackEnhancementLoadFailure();
  };

  const onLifecycleChange = (event: RemoteEventType) => {
    if (!trackerService) return;
    switch (event) {
      case RemoteEventType.Initialized:
        trackerService.trackRemoteInitialized();
        break;
      case RemoteEventType.HealthCheckOk:
        trackerService.trackRemoteHealthCheckOk();
        break;
      case RemoteEventType.HealthCheckFail:
        trackerService.trackRemoteHealthCheckFail();
        break;
    }
  };

  return (
    <RemoteEnhancement
      assets={assets}
      enhancement={enhancement}
      language={language}
      onClick={onClick}
      onError={handleError}
      onLoad={onLoad}
      onLifecycleChange={onLifecycleChange}
      publisherStyles={publisherStyles}
      hasPreflight={isSofiaPulseEnhancement(enhancement.type)}
    />
  );
};

registerEnhancement(
  [
    GCEnhancementType.BannerSportsTicker,
    GCEnhancementType.OutstreamSportsTicker,
    GCEnhancementType.BannerBrandedHeadline,
    GCEnhancementType.OutstreamBrandedHeadline,
    GCEnhancementType.BannerShoppable,
    GCEnhancementType.OutstreamShoppable,
    GCEnhancementType.BannerShoppableOverlay,
    GCEnhancementType.BannerMedalCount,
    GCEnhancementType.OutstreamMedalCount,
    GCEnhancementType.BannerWorldTournament,
    GCEnhancementType.OutstreamWorldTournament,
    GCEnhancementType.BannerCustom,
    GCEnhancementType.OutstreamCustom,
    GCEnhancementType.BannerSofiaPulseSportsHeadlines,
    GCEnhancementType.BannerSofiaPulseQuiz,
    GCEnhancementType.BannerSofiaPulseBettingOdds,
    GCEnhancementType.BannerSofiaPulseStockTicker
  ],
  Remote
);
