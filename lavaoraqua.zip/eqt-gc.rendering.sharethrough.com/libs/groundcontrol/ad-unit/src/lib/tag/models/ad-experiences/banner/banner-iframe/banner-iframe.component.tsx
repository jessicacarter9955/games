import { registerObserver } from '../../../../../modules/observer';
import { useSignal } from '@preact/signals';
import type { Payload } from '@web-rendering/groundcontrol-core';
import {
  isRestrictedIframeCaller,
  isSofiaPulseCreative,
  trackerService as trackerServiceSignal,
  useLifecycleScope,
  usePayload,
  useTrackerService
} from '@web-rendering/groundcontrol-core';
import type { MeasurementCore } from '@web-rendering/groundcontrol-measurement/lib/measurement-core';
import { MeasurementType } from '@web-rendering/groundcontrol-measurement/lib/types';
import { reportError } from '@web-rendering/groundcontrol-monitoring';
import { LifecycleStage } from '@web-rendering/groundcontrol-shared-types/lifecycle/lifecycle-stage';
import { setRenderEnd } from '@web-rendering/groundcontrol-store';
import { detectIframeClicks } from '@web-rendering/groundcontrol-utils/detect-iframe-clicks';
import { forwardRef } from 'preact/compat';
import { useEffect, useImperativeHandle, useMemo, useRef, useState } from 'preact/hooks';
import { disableAdChoices } from '../../../common/template/enhanced/drawer/drawer.component';
import { armEmbeddedMeasurement as armEmbeddedMeasurementCore } from '../../common/measurement/arm-embedded-measurement';
import { getMeasurementType } from '../../common/measurement/measurement-mode';
import {
  addIframeWindowClick,
  findAdChoicesLink,
  getIframeHtml,
  getSafeCreativeContent,
  getScale,
  setRestrictedIframeContent,
  setUnrestrictedIframeContent
} from '../utils';
import { injectOnePixelScriptIntoDOM } from '../utils/get-one-pixel-script';
import type { BannerIframeProps } from './types';
import { useIframeMessageListener } from './use-iframe-message-listener';
import { VisibilityObserver } from './visibility';
import { bindStage } from '@web-rendering/groundcontrol-shared-types/lifecycle/lifecycle';
import type { LifecycleScope } from '@web-rendering/groundcontrol-shared-types/lifecycle/lifecycle';

export const BannerIframe = forwardRef((props: BannerIframeProps, ref) => {
  // Hooks and refs
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const payload = usePayload();
  const timeoutIdRef = useRef<number | undefined>(undefined);
  const trackerService = useTrackerService();
  const scope = useLifecycleScope();
  // OnePixel and Embedded Measurement start here and run alongside the render, so they keep the
  // measured_impression stage whatever the ad is doing when they fail.
  const measuredImpressionScope = useMemo(() => bindStage(scope, LifecycleStage.MeasuredImpression), [scope]);
  // Refs, not effect-local state: addIframeWindowClick's listener never rebinds after
  // the first effect run, but the blur listener does — closures would diverge between
  // the two after a re-run (see the click-tracking effect below).
  const isHandlingClickRef = useRef(false);
  const dedupTimeoutIdRef = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);
  const [isHtmlRender, setHtmlRender] = useState<boolean>(false);
  const activeMeasurementType = useSignal<MeasurementType | null>(null);
  const [iframeHtmlErrorState, setIframeHtmlErrorState] = useState(false);

  useImperativeHandle(ref, () => iframeRef.current);

  const isClickTrackerVisible = isSofiaPulseCreative(payload?.creative.content, payload?.enhancement?.type);

  if (payload) {
    activeMeasurementType.value = getMeasurementType(payload);
  }

  // Setup iframe content
  const { raw, unescaped } = getSafeCreativeContent(payload?.creative);
  const creativeAdm = iframeHtmlErrorState ? raw : unescaped;
  useEffect(() => {
    const iframe = iframeRef.current;
    if (!payload || !iframe) return;

    // getScale only handles the Size-Multiplexed 320x50-into-300x50 mismatch; every other
    // creative/container combination renders unscaled (see WR-2132).
    const isSizeMultiplexedPlacement =
      payload.creative.size.width === 320 &&
      payload.creative.size.height === 50 &&
      payload.network.size.width === 300 &&
      payload.network.size.height === 50;
    const scale = isSizeMultiplexedPlacement
      ? getScale(iframe.clientWidth, iframe.clientHeight, props.width, props.height)
      : 1;
    const iframeHTML = getIframeHtml(payload, creativeAdm, scale);

    isRestrictedIframeCaller(payload.network.callerId)
      ? setRestrictedIframeContent(iframe, iframeHTML, payload, scope) && setHtmlRender(true)
      : setUnrestrictedIframeContent(iframe, iframeHTML, payload, scope) && setHtmlRender(true);
  }, [props.width, props.height, payload, iframeRef, iframeHtmlErrorState]);

  // Run the OnePixel / MRAID impression script in GC's own document (the iframe's host), NOT
  // inside the creative iframe. From here window.mraid + window.mraidbridge are reachable
  // natively, so the MRAID impression fires in-app instead of throwing "mraidbridge is not
  // defined". Idempotency is keyed on the host ad container inside injectOnePixelScriptIntoDOM
  // (not a component ref), so a remount reusing the same container does not inject a second
  // tracker and double-count the impression.
  //
  // Arm the tracker only once the creative has actually rendered content (isHtmlRender) AND the
  // creative has a non-zero box. mraid.isViewable() is a placement-level signal from the native
  // SDK — it reports the ad slot, not this creative — so a blank/zero-size creative sitting in a
  // viewable slot would otherwise fire a MRAID impression the user never saw. Gating on the
  // creative's own dimensions keeps the impression tied to something actually on screen.
  //
  // When the scenario selects Embedded measurement (WR-2043), GC counts the impression itself
  // instead of delegating to the external OnePixel script — see common/measurement/arm-embedded-
  // measurement.ts for the core's own arm/teardown semantics, and armEmbeddedMeasurement below
  // (this file) for why the idempotency guard is keyed on the host container, not a component ref.
  useEffect(() => {
    const host = iframeRef.current?.parentElement;
    if (!host) return;

    if (!payload?.reporting?.countImpressionOnePixel) return;
    if (!isHtmlRender) return;
    if (!props.width || !props.height) return;

    if (activeMeasurementType.value === MeasurementType.Embedded) {
      armEmbeddedMeasurement(payload, host, measuredImpressionScope);
      return;
    }

    // Reaching here means countImpressionOnePixel is true and the mode isn't Embedded, so this is
    // necessarily OnePixel — clears a previously-armed Embedded core when this render switches
    // from Embedded to OnePixel on the same host. No-op if nothing is armed. A render that isn't
    // ready, or that has countImpressionOnePixel false (Standard — no tracking at all), is caught
    // by the guards above and skips this: if such a render is a remount reusing a host with a
    // still-armed Embedded core from a prior instance, the old core is left listening until a
    // later render in Embedded or OnePixel mode arms/tears it down.
    teardownEmbeddedMeasurement(host);

    injectOnePixelScriptIntoDOM(payload, measuredImpressionScope, host);
  }, [payload, isHtmlRender, props.width, props.height, activeMeasurementType.value]);

  useEffect(() => {
    if (!isClickTrackerVisible) return;

    const visibilityObserver = new VisibilityObserver();

    visibilityObserver.subscribe((visible) => {
      // Focus the window when it becomes visible to change the active element
      if (visible) {
        window.focus();
      } else {
        // If the iframe is the active element when the document becomes hidden, fire beacon
        const iframe = iframeRef.current;
        if (iframe && document.activeElement === iframe && trackerService) {
          trackerService.trackClick(iframe);
        }
      }
    });

    return () => {
      visibilityObserver.disconnect();
    };
  }, []);

  useEffect(() => {
    if (isClickTrackerVisible) return;

    const iframe = iframeRef.current;
    if (!iframe) return;

    const cleanups: (() => void)[] = [];

    // A double-click within CLICK_DEDUP_WINDOW_MS collapses into one beacon — no
    // actionable difference from a single click, and it avoids having to predict
    // exactly how a given browser cascades blur for a target="_blank" click.
    //
    // Deliberately not cleared/reset from this effect's cleanup: isHandlingClickRef
    // and dedupTimeoutIdRef are refs, not per-run state, so an unrelated re-render
    // between the two mechanisms observing the same click must not touch them — the
    // timer already self-clears when it actually fires, regardless of how many
    // re-runs happen while it's pending.
    const trackClickOnce = () => {
      if (isHandlingClickRef.current) return;
      isHandlingClickRef.current = true;
      trackerService?.trackClick(iframe);
      dedupTimeoutIdRef.current = setTimeout(() => {
        isHandlingClickRef.current = false;
        dedupTimeoutIdRef.current = undefined;
      }, CLICK_DEDUP_WINDOW_MS);
    };

    // Runs alongside the blur heuristic, not instead of it: blur can't see
    // target="_blank" click-throughs (focus never cascades into the iframe before
    // the new tab opens), regardless of which partner's creative triggers it.
    // Attempted unconditionally — getIframeDocumentSafely makes it safe for any
    // caller, and a caller that sandboxes GC without allow-same-origin (WR-1149)
    // simply gets no listener and relies on blur.
    const directClickCleanup = addIframeWindowClick(iframe, (event) => {
      if (isTargetBlankAnchorClick(event)) trackClickOnce();
    });
    if (directClickCleanup) cleanups.push(directClickCleanup);

    cleanups.push(detectIframeClicks({ iframe, onClick: trackClickOnce }));

    return () => cleanups.forEach((cleanup) => cleanup());
  }, [props.onIframeClick, trackerService]);

  // setup message listeners; includes listening to click messages from sofiapulse sent through postMessage API
  useIframeMessageListener({
    iframeRef,
    onIframeClick: props.onIframeClick,
    // Falling back to the raw markup only helps when unescaping actually
    // changed it. Rewriting the live iframe re-executes every creative
    // script against a fresh document while the window persists, which
    // permanently breaks viewability measurement (e.g. Google Active View)
    // bound to the discarded DOM — and cross-origin creative scripts report
    // generic "Script error." messages that trigger this path for failures
    // unrelated to escaping.
    onIframeError: () => {
      if (raw !== unescaped) setIframeHtmlErrorState(true);
    }
  });

  // Handle impression tracking
  useEffect(() => {
    const iframe = iframeRef.current;

    if (isHtmlRender && iframe?.parentElement) {
      if (activeMeasurementType.value === MeasurementType.Standard) {
        trackerService?.trackImpression(iframe.parentElement, scope, 'standard');
      } else {
        trackerService?.trackVisibleImpression(iframe.parentElement);
      }
    }
  }, [isHtmlRender, trackerService, activeMeasurementType.value]);

  // Check for AdChoices
  useEffect(() => {
    const iframe = iframeRef.current;
    if (!iframe || disableAdChoices.value) return;

    findAdChoicesLink(iframe).then((adChoicesLink) => {
      disableAdChoices.value = Boolean(adChoicesLink);
    });
  }, []);

  useEffect(() => {
    let observer: IntersectionObserver | null = null;
    let hasTracked = false; // Add flag to track if we've already fired

    const createObserver = () => {
      if (!iframeRef.current || !isHtmlRender || document.hidden || hasTracked) return null;

      return registerObserver({
        element: iframeRef.current,
        timeoutIdRef,
        inViewPixels: 1,
        outOfViewPixels: 0,
        inViewCallback: () => {
          if (!document.hidden && !hasTracked) {
            trackerService?.trackPixelVisible();
            hasTracked = true;
            // Disconnect observer since we don't need it anymore
            observer?.disconnect();
            observer = null;
          }
        }
      });
    };

    const handleVisibilityChange = () => {
      if (document.hidden) {
        if (observer) {
          observer.disconnect();
          observer = null;
        }
        // Clear any pending timeout when document becomes hidden
        if (timeoutIdRef.current) {
          window.clearTimeout(timeoutIdRef.current);
          timeoutIdRef.current = undefined;
        }
      } else if (!observer && !hasTracked) {
        // Only create new observer if we haven't tracked yet
        observer = createObserver();
      }
    };

    // Initial observer setup
    observer = createObserver();

    document.addEventListener('visibilitychange', handleVisibilityChange);

    return () => {
      observer?.disconnect();
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, [iframeRef, isHtmlRender, trackerService]);

  const iframeProps = {
    id: props.id,
    'data-thumbnail-id': props.dataThumbnailId,
    className: props.className,
    scrolling: 'no',
    frameBorder: '0',
    style: {
      width: '100%',
      height: '100%',
      top: 0,
      left: 0
    },
    'data-testid': 'adm-iframe',
    onLoad: () => setRenderEnd(),
    ref: iframeRef
  };

  return <iframe {...iframeProps} />;
});

const CLICK_DEDUP_WINDOW_MS = 300;

// The "i" flag matches target="_BLANK" too — the HTML spec treats the keyword
// as case-insensitive.
const isTargetBlankAnchorClick = (event: MouseEvent): boolean => {
  const target = event.target as Element | null;
  return target?.closest('a[target="_blank" i]') != null;
};

// Keyed on the host ad container, same idea as ONEPX_INJECTED_ATTR (get-one-pixel-script.ts) —
// a remount reusing the same host must not re-arm, because the previously-armed core's listeners
// are still live (this module doesn't tear them down on unmount, mirroring how the OnePixel
// script also outlives remounts); re-arming would attach a second listener and double-count the
// impression when it fires.
const EMBEDDED_MEASUREMENT_ARMED_ATTR = 'data-embedded-measurement-armed-id';

// Keyed on the host, not on a component instance ref — a remount, an unrelated re-render, or a
// same-instance switch to a different measurement mode all need to find (and tear down) whatever
// core is currently live for this exact DOM node, regardless of which component instance armed it.
const armedCoresByHost = new WeakMap<HTMLElement, MeasurementCore>();

/**
 * Arms the shared embedded-measurement core (common/measurement/arm-embedded-measurement.ts, built
 * for native's componentDidMount/componentWillUnmount) against `host`, idempotently. This
 * component's own effect can re-run for the same ad without unmounting — unlike native's class
 * lifecycle, which only ever arms once per mount — so this guards with a host-attribute + WeakMap
 * check: without it, every qualifying re-render would call the shared function again, attaching
 * another live listener to the same MRAID session and double-counting the impression when it fires.
 *
 * The shared function copies window.mraidbridge alongside window.mraid before reading either
 * (WR-2238), so no bridging step is needed here.
 *
 * No-ops if already armed for this exact ad (idempotent across remounts/re-renders).
 */
function armEmbeddedMeasurement(payload: Payload, host: HTMLElement, scope: LifecycleScope): void {
  const measurementId = payload.reporting.trackerImpressionUrl ?? payload.id;
  if (host.getAttribute(EMBEDDED_MEASUREMENT_ARMED_ATTR) === measurementId) return;

  teardownEmbeddedMeasurement(host);

  if (!trackerServiceSignal.value) {
    reportError(new Error('Tracker service not found'), {
      scope,
      context: 'arm-embedded-measurement'
    });
    return;
  }

  let core: MeasurementCore | undefined;
  try {
    core = armEmbeddedMeasurementCore(trackerServiceSignal.value, scope);
  } catch (error) {
    reportError(error instanceof Error ? error : new Error(String(error)), {
      scope,
      context: 'arm-embedded-measurement'
    });
    return;
  }

  if (!core) {
    reportError(new Error('SAS config not found'), {
      scope,
      context: 'arm-embedded-measurement'
    });
    return;
  }

  armedCoresByHost.set(host, core);
  host.setAttribute(EMBEDDED_MEASUREMENT_ARMED_ATTR, measurementId);
}

/** Detaches whatever core is currently armed for `host`, if any. Safe to call unconditionally. */
function teardownEmbeddedMeasurement(host: HTMLElement): void {
  const core = armedCoresByHost.get(host);
  if (!core) return;

  core.teardown();
  armedCoresByHost.delete(host);
  host.removeAttribute(EMBEDDED_MEASUREMENT_ARMED_ATTR);
}
