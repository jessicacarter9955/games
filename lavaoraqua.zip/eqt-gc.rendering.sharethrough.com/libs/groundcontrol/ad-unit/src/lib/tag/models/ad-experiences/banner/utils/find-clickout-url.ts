import type { RefObject } from 'preact';
import { isGWDWindow } from '../types';
import type { FindClickoutUrlResult } from './clickability-types';
import { extractClickTagParam } from './extract-click-tag-param';
import { extractEClickUrl } from './extract-eclick-url';
import { BannerType } from './get-banner-type';
import { getIframeDocumentSafely } from './get-iframe-document-safely';
import { getUrlFromElement } from './get-url-from-element';

const INSIGHTS_BEACON_URL = '//insight.adsrvr.org/track/clk?';
const ADNXS_BEACON_URL = '//nym1-ib.adnxs.com/click?';
const BASIS_BEACON_URL = /https?:\/\/clickserv\.sitescout\.com\/clk.[^"|']*/;
const MIN_CLICKABLE_DIMENSION = 50; // icons are typically larger than 50px
const AD_INFO_PATTERN = /ad[-_]?choices|ad[-_]?info/i;

export interface FindClickoutUrlProps {
  container: RefObject<HTMLDivElement>;
  bannerIframe: HTMLIFrameElement | null;
  bannerType: string;
  adm: string;
  element: HTMLElement | null;
}

/**
 * Finds clickout URL from anchor tags in the given document, filtering out small elements like AdChoices icons.
 * Returns the URL of the largest anchor tag (by area) that exceeds MIN_CLICKABLE_DIMENSION.
 */
function findClickoutFromAnchorTags(doc: Document): string | null {
  const anchorTags = doc.querySelectorAll('a[href]');
  let largestAnchor: { href: string; area: number } | null = null;

  for (let i = 0; i < anchorTags.length; i++) {
    const anchorTag = anchorTags[i] as HTMLAnchorElement;
    const href = anchorTag.getAttribute('href');

    if (!href || !href.startsWith('http') || AD_INFO_PATTERN.test(href)) {
      continue;
    }

    const rect = anchorTag.getBoundingClientRect();
    const img = anchorTag.querySelector('img');
    const imgRect = img?.getBoundingClientRect();

    // Use image dimensions if available, otherwise use anchor dimensions
    const width = imgRect?.width || rect.width;
    const height = imgRect?.height || rect.height;

    // Filter out small elements (AdChoices icons, tracking pixels, etc.)
    if (width > MIN_CLICKABLE_DIMENSION || height > MIN_CLICKABLE_DIMENSION) {
      const area = width * height;

      // Keep track of the largest anchor tag
      if (!largestAnchor || area > largestAnchor.area) {
        largestAnchor = { href, area };
      }
    }
  }

  return largestAnchor?.href || null;
}

export function findClickoutUrl(props: FindClickoutUrlProps): FindClickoutUrlResult {
  const { container, bannerType, element, adm, bannerIframe } = props;

  if (!container || !container.current) {
    return { url: null, ruleUsed: 'no-container' };
  }

  // Check for anchor tags in the iframe document
  const bannerIframeDocument = getIframeDocumentSafely(bannerIframe);
  if (bannerIframeDocument) {
    const anchorUrl = findClickoutFromAnchorTags(bannerIframeDocument);
    if (anchorUrl) {
      return { url: anchorUrl, ruleUsed: 'anchor-tag' };
    }
  }

  const iframes = container.current.querySelectorAll('iframe');

  if (iframes) {
    for (let i = 0; i < iframes.length; i++) {
      const iframe = iframes[i];
      let iframeData;

      // guard against non-json iframe name attributes
      try {
        iframeData = iframe && JSON.parse(iframe.getAttribute('name') || '{}');
        if (iframeData && iframeData.clicks && iframeData.clicks.clickTag) {
          return { url: iframeData.clicks.clickTag, ruleUsed: 'iframe-json' };
        }
      } catch (e) {
        console.error(e);
      }
    }
  }

  // dcm ads frequently store the click tracker in a data attr
  const dcmAd = element?.querySelector('.dcmads');
  if (dcmAd && dcmAd.getAttribute('data-dcm-click-tracker')) {
    const clickTracker = dcmAd.getAttribute('data-dcm-click-tracker');

    // only return if it's an actual redirect, not just a click tracking beacon
    if (!clickTracker?.match(INSIGHTS_BEACON_URL) && !clickTracker?.match(ADNXS_BEACON_URL)) {
      return { url: clickTracker, ruleUsed: 'dcm-data-attr' };
    }
  }

  if (bannerType === BannerType.Adform) {
    const div = document.createElement('div');
    div.innerHTML = adm;
    const url = getUrlFromElement(div.querySelector('noscript'));
    return { url, ruleUsed: 'adform-noscript' };
  }

  if (bannerType === BannerType.Basis) {
    const basisClickout = adm.match(BASIS_BEACON_URL);
    if (basisClickout) {
      return { url: basisClickout[0], ruleUsed: 'basis-beacon' };
    }
  }

  // AMO (Adobe Media Optimizer) banners
  /* eslint-disable-next-line @typescript-eslint/no-explicit-any */
  const amoKey: any = Object.keys(window).filter((key) => key.match(/^amo_/))[0];
  if (amoKey) {
    /* eslint-disable-next-line @typescript-eslint/no-explicit-any */
    const amo: any = window[amoKey];

    if (amo && amo.atsLoggerBasePath && amo.atsParams && amo.baseParams) {
      const atsParams = Object.keys(amo.atsParams).map((key) => {
        return `&${key}=${encodeURIComponent(amo.atsParams[key])}`;
      });
      const baseParams = Object.keys(amo.baseParams).map((key) => {
        return `&${key}=${encodeURIComponent(amo.baseParams[key])}`;
      });

      const url = `${amo.atsLoggerBasePath}?cmd=CLICK_THRU&ProductURL=${encodeURIComponent(
        amo.ad[0].product_url
      )}${atsParams.join('')}${baseParams.join('')}`;
      return { url, ruleUsed: 'amo-banner' };
    }
  }

  const bannerIframeWindow = bannerIframe?.contentWindow;

  // Google Web Designer banners - refacted from old gc.js implementation
  if (isGWDWindow(bannerIframeWindow)) {
    try {
      const creatives = bannerIframeWindow.studioV2.api.creatives;
      if (!creatives || !creatives.length) return { url: null, ruleUsed: 'gwd-no-creatives' };

      const creative = bannerIframeWindow.studioV2.api.creatives[0].a ?? bannerIframeWindow.studioV2.api.creatives[0].j;
      if (!creative || typeof creative !== 'object') return { url: null, ruleUsed: 'gwd-no-creative' };

      const exitObj = Object.values(creative).find((v) => v && typeof v === 'object' && v.Exit)?.Exit;
      if (!exitObj) return { url: null, ruleUsed: 'gwd-no-exit' };

      const priorityTags = ['mediaClickTag', 'clickTag1'];
      const priorityMap = new Map(priorityTags.map((tag, index) => [tag, index]));

      const tags = Object.keys(exitObj).sort((a, b) => {
        const aPriority = priorityMap.get(a);
        const bPriority = priorityMap.get(b);
        // using Infinity to ensure that tags not in the priority list are sorted last
        return (aPriority ?? Infinity) - (bPriority ?? Infinity);
      });

      for (const tagName of tags) {
        const tag = exitObj[tagName];
        if (tag && typeof tag === 'object' && tag.url) {
          return { url: tag.url, ruleUsed: `gwd-exit-${tagName}` };
        }
      }

      return { url: null, ruleUsed: 'gwd-no-exit' };
    } catch {
      return { url: null, ruleUsed: 'gwd-error' };
    }
  }

  if (bannerType === BannerType.TradeDeskBanner) {
    const ttd_url = extractClickTagParam(adm);
    if (ttd_url) {
      return { url: ttd_url, ruleUsed: 'tradedesk-click-param' };
    }
  }

  /**
   * Use eClickURL if available for clicks (#575)  Some creatives include an 'eClickURL' variable,
   * in the form of:  <!-- eClickURL = https://example.com/ad -->  This variable will be used, when available,
   * for the banner headline.
   */
  const eClickURL = extractEClickUrl(adm);
  if (eClickURL) {
    return { url: eClickURL, ruleUsed: 'eclick-url' };
  }

  const iframe = container.current?.querySelector('iframe');
  if (iframe) {
    const url = container && getUrlFromElement(iframe.contentDocument?.querySelector('noscript') || null);
    return { url, ruleUsed: 'iframe-noscript' };
  }

  const url = container && getUrlFromElement(container.current?.querySelector('noscript'));
  return { url, ruleUsed: url ? 'noscript-container' : 'no-match' };
}
