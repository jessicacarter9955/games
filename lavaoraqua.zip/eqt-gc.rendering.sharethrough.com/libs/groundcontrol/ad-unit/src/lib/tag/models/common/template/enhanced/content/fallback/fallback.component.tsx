import { useEnhancement } from '../../../../../../../tag/models/ad-experiences/hooks';
import type { FunctionComponent } from 'preact';
import { Headline } from '../headline/headline.component';
import { Remote } from '../remote/remote.component';
import type { EnhancedComponentProps } from '../type';

export const Fallback: FunctionComponent<EnhancedComponentProps> = ({ onEnhancementClick }) => {
  const { enhancement } = useEnhancement();
  const enhancementPayload = enhancement?.payload;

  if (enhancementPayload && 'templateUrl' in enhancementPayload) {
    return <Remote onEnhancementClick={onEnhancementClick} />;
  }

  return <Headline />;
};
