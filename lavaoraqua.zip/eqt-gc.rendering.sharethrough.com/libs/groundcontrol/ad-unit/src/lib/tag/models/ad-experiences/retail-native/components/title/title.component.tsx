import type { ShoppableProduct } from '@web-rendering/groundcontrol-ortb';
import type { FunctionComponent } from 'preact';
import './title.scss';

export const RetailNativeTitle: FunctionComponent<{ product?: ShoppableProduct }> = ({ product }) => {
  if (!product?.name) return null;

  return <div className="str-retail-title">{product.name}</div>;
};
