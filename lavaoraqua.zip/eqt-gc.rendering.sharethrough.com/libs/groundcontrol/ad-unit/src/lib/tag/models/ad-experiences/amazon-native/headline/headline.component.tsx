import { useNativeAssets } from '@web-rendering/groundcontrol-ortb';
import type { FunctionComponent } from 'preact';
import './headline.scss';

export const AmazonHeadline: FunctionComponent = () => {
  const assets = useNativeAssets();
  if (!assets) return null;

  const { title, description } = assets;

  // Should only render if both title and description are present
  if (!title || !description) return null;

  return (
    <div className="str-amazon-headline">
      <span>{title.title.text}</span>
    </div>
  );
};
