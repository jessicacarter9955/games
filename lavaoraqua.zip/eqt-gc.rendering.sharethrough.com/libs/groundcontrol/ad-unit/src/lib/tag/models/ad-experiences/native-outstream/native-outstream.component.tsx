import { registerObserver } from '../../../../modules/observer';
import { ImaSDK } from '@ad-rendering/ima-sdk';
import { URLBeacon } from '@web-rendering/groundcontrol-beacon';
import type { NativeOutstreamCreative } from '@web-rendering/groundcontrol-shared-types';
import type { TrackerService } from '@web-rendering/groundcontrol-core';
import { usePayload, useTrackerService } from '@web-rendering/groundcontrol-core';
import type { AdClickEvent } from '@web-rendering/groundcontrol-shared-types/events/click-handler';
import { setRenderEnd } from '@web-rendering/groundcontrol-store';
import BlankVideo from '../../../../assets/icons/blank.mp4';
import { clsx } from 'clsx';
import { CaptionsContext } from '../../../../modules/enhancements/captions/captions-provider';
import { createRef, Fragment } from 'preact';
import { useContext, useEffect, useRef } from 'preact/hooks';
import { Template } from '../../../../tag/models/common/template';
import { AdExperienceBase } from '../ad-experience.base';
import { VideoMute } from '../common';
import type { AdExperienceBaseProps } from '../types';
import { NativeOutstreamPayloadSignalState } from './models';
import { NativeOutstreamReplay } from './native-outstream-replay/native-outstream-replay.component';
import type { INativeOutstreamBase, NativeOutstreamProps } from './types';
import { inviewVideoHandler } from './utils/inview-video-handler';
import { configureState, imaErrorHandler } from './utils/utils';
import { bindStage } from '@web-rendering/groundcontrol-shared-types/lifecycle/lifecycle';
import { LifecycleStage } from '@web-rendering/groundcontrol-shared-types/lifecycle/lifecycle-stage';

export class NativeOutstreamBase
  extends AdExperienceBase<NativeOutstreamCreative, NativeOutstreamProps, object>
  implements INativeOutstreamBase
{
  state = {
    replayed: false
  };

  impressionFired = false;
  imaSDK: ImaSDK | null = null;
  trackerService: TrackerService<unknown> | null = null;

  refVastVideo = createRef<HTMLVideoElement>();
  refNativeOutstreamContainer = this.props.containerRef ?? createRef<HTMLDivElement>();
  refVastContainer = createRef<HTMLDivElement>();
  refThumbnailContainer = createRef<HTMLDivElement>();

  constructor(props: NativeOutstreamProps) {
    super(props);
    this.trackerService = props.trackerService;
  }

  handleAdClick = (clickEvent: AdClickEvent) => {
    if (!(clickEvent.event.target instanceof HTMLElement)) return;

    const { videoReplayed } = NativeOutstreamPayloadSignalState;
    if (!videoReplayed.value) this.trackerService?.trackUserShare();

    if (clickEvent.redirectUrl) {
      window.open(clickEvent.redirectUrl, '_blank');
      return;
    }

    if (clickEvent.event.target) {
      /**
       * 1. The IMA player handles firing the click beacons in a callback function.
       * The following beacons are fired: 3rd party click beacons, clickout, imaClick, and autoplayVideoEngagement.
       * See IMA click event listener: src/modules/ima.ts#L256.
       */
      const clickedOnThumbnail = clickEvent.event.target.tagName === 'IFRAME';
      if (clickedOnThumbnail) {
        return;
      }

      /**
       * 2. For click-to-play videos, no beacons are currently fired.
       */
      const clickedOnPlayButton = clickEvent.event.target.classList.contains('icon-play-button');
      if (clickedOnPlayButton) {
        return;
      }
    }

    if (this.mainContainerParent) this.trackerService?.trackClick(this.mainContainerParent);
    if (NativeOutstreamPayloadSignalState.clickThroughUrl.value) {
      window.open(NativeOutstreamPayloadSignalState.clickThroughUrl.value, '_blank');
    }

    /**
     * Fire any beacons defined in the VAST tag, except clickthrough,
     * since that is used for redirecting.
     */
    if (this.imaSDK?.vastUrl && this.imaSDK?.vastUrl.match(/<vast/i)) {
      const videoClicksMatch = this.imaSDK?.vastUrl.match(/<VideoClicks>.*?<\/VideoClicks>/m);
      const parser = new DOMParser();
      if (videoClicksMatch) {
        const xmlDoc = parser.parseFromString(videoClicksMatch[0], 'text/xml');
        xmlDoc.firstChild?.childNodes.forEach((childNode) => {
          if (childNode.textContent) {
            // Do not fire a track pixel on click through because we redirect to it bellow already.
            if (childNode.nodeName !== 'ClickThrough') {
              new URLBeacon({ url: childNode.textContent });
            }
          }
        });
      }
    }
  };

  get mainContainerParent(): HTMLElement | null {
    return this.refNativeOutstreamContainer.current?.parentElement ?? null;
  }

  trackRenderedImpression = () => {
    if (this.mainContainerParent && this.trackerService && !this.impressionFired) {
      this.trackerService.trackImpression(this.mainContainerParent, this.lifecycleScope);
      this.impressionFired = true;
    }
  };

  componentDidUpdate() {
    this.trackRenderedImpression();
  }

  componentDidMount() {
    this.imaLoader();
    this.trackRenderedImpression();
    try {
      const windowTop = window.top || window;
      windowTop.addEventListener('focus', () => this.windowFocusHandler());
    } catch (_) {
      window.addEventListener('focus', () => this.windowFocusHandler());
    }
  }

  componentWillUnmount() {
    if (this.imaSDK) this.imaSDK.destroy();
    try {
      const windowTop = window.top || window;
      windowTop.removeEventListener('focus', () => this.windowFocusHandler());
    } catch (_) {
      window.removeEventListener('focus', () => this.windowFocusHandler());
    }
  }

  imaClickHandler = () => {
    const { trackerService } = this;
    if (!trackerService) return;

    if (this.mainContainerParent) trackerService.trackClick(this.mainContainerParent);
    trackerService.trackImaClick();

    if (!this.state.replayed) {
      trackerService.trackAutoplayVideoEngagement(NativeOutstreamPayloadSignalState.currentTime.value);
    }
  };

  imaLoader = async () => {
    const { current: videoElement } = this.refVastVideo;
    const { current: vastContainer } = this.refVastContainer;
    if (!videoElement || !vastContainer) return;

    const vastContent: string = typeof this.payload.creative.content === 'string' ? this.payload.creative.content : '';

    if (vastContent) {
      // The IMA player is where playback starts, so its errors report the playback stage.
      const playbackScope = bindStage(this.lifecycleScope, LifecycleStage.Playback);
      this.imaSDK = new ImaSDK(
        videoElement,
        vastContainer,
        vastContent,
        this.imaInitializeHandler,
        this.imaClickHandler,
        (error: Error) =>
          imaErrorHandler(error, this.trackerService, playbackScope, {
            vastSource: vastContent
          })
      );
    } else {
      console.warn('VAST content is not available for IMA SDK initialization.');
    }
  };

  setCaptionContextCurrentTime = (value: number) => {
    this.props.captionsContext?.setCurrentTime?.(value);
  };

  setCaptionContextCreativeId = (value: string) => {
    this.props.captionsContext?.setInnerCreativeId?.(value);
  };

  setCaptionContextVideoElement = (value: HTMLVideoElement) => {
    this.props.captionsContext?.setVideoElement?.(value);
  };

  imaInitializeHandler = () => {
    const { imaSDK } = this;
    if (!imaSDK) {
      console.warn('IMA SDK is not initialized.');
      return;
    }

    configureState(
      imaSDK,
      NativeOutstreamPayloadSignalState,
      this.state.replayed,
      this.trackerService,
      this.setCaptionContextCurrentTime,
      this.setCaptionContextCreativeId,
      this.setCaptionContextVideoElement,
      this.trackRenderedImpression
    );

    if (this.refVastContainer.current) {
      inviewVideoHandler(
        imaSDK,
        this.refVastContainer.current,
        NativeOutstreamPayloadSignalState.started,
        this.payload.creative.behaviors
      );
    } else {
      console.warn('VAST container reference is not available for inview video handler.');
    }
  };

  handleMute = (e: MouseEvent) => {
    e.stopPropagation();
    if (this.imaSDK) this.imaSDK.video.volume(!NativeOutstreamPayloadSignalState.muted.value ? 0 : 1);
  };

  handleReplay = async (event: MouseEvent) => {
    event.stopPropagation();
    this.setState({ replayed: true });
    NativeOutstreamPayloadSignalState.started.value = false;

    if (this.imaSDK) this.imaSDK.video.replay();
  };

  windowFocusHandler = () => {
    const { started } = NativeOutstreamPayloadSignalState;
    if (this.imaSDK && started.value) this.imaSDK.video.resume();
  };

  render() {
    setRenderEnd();
    const { completed, started, muted, adVideoSource } = NativeOutstreamPayloadSignalState;
    return (
      <Fragment>
        <div
          ref={this.refNativeOutstreamContainer}
          onClick={(event) => this.handleAdClick({ event })}
          className="str-vast-container str-react-template"
        >
          <Template
            creative={this.payload.creative}
            network={this.payload.network}
            country={this.payload.network.country}
            className={clsx(completed && 'video-completed')}
            adserverRequestId={this.props.adserverRequestId}
            onEnhancementClick={this.handleAdClick}
          >
            <div
              className="str-thumbnail-wrapper str-thumbnail-wrapper-outstream"
              style={{ maxHeight: this.payload.network.size.height, maxWidth: this.payload.network.size.width }}
            >
              <div className="str-thumbnail" ref={this.refThumbnailContainer}>
                <VideoMute
                  muted={muted.value}
                  videoCompleted={completed.value}
                  videoStarted={started.value}
                  onClick={this.handleMute}
                />
                <div className={clsx('str-video-container', completed && 'video-completed')}>
                  <div className="video-wrapper" ref={this.refVastContainer}></div>
                  <video
                    playsInline
                    className="blank-video"
                    ref={this.refVastVideo}
                    src={BlankVideo}
                    preload="metadata"
                  />
                  <NativeOutstreamReplay
                    videoSrc={adVideoSource.value}
                    videoStarted={started.value}
                    videoCompleted={completed.value}
                    onReplay={this.handleReplay}
                  />
                </div>
              </div>
            </div>
          </Template>
        </div>
      </Fragment>
    );
  }
}

export function NativeOutstream(props: AdExperienceBaseProps) {
  const captionsContext = useContext(CaptionsContext);
  const trackerService = useTrackerService();
  const payload = usePayload();
  const containerRef = useRef<HTMLIFrameElement>(null);
  const timeoutIdRef = useRef<number | undefined>(undefined);

  useEffect(() => {
    let observer: IntersectionObserver | null = null;
    let hasTracked = false; // Add flag to track if we've already fired

    const createObserver = () => {
      if (!containerRef.current || document.hidden || hasTracked) return null;

      return registerObserver({
        element: containerRef.current,
        timeoutIdRef,
        inViewPixels: 1,
        outOfViewPixels: 0,
        inViewCallback: () => {
          if (!document.hidden && !hasTracked) {
            trackerService?.trackPixelVisible();
            hasTracked = true;
            observer?.disconnect();
            observer = null;
          }
        }
      });
    };

    const handleVisibilityChange = () => {
      if (document.hidden) {
        if (observer) {
          observer.disconnect();
          observer = null;
        }
        if (timeoutIdRef.current) {
          window.clearTimeout(timeoutIdRef.current);
          timeoutIdRef.current = undefined;
        }
      } else if (!observer && !hasTracked) {
        observer = createObserver();
      }
    };

    observer = createObserver();

    document.addEventListener('visibilitychange', handleVisibilityChange);

    return () => {
      observer?.disconnect();
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, [trackerService]);

  return (
    <NativeOutstreamBase
      {...props}
      payload={payload}
      captionsContext={captionsContext}
      trackerService={trackerService}
      containerRef={containerRef}
    />
  );
}
