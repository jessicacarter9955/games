import type { AdClickEvent } from '@web-rendering/groundcontrol-shared-types/events/click-handler';
import type { Payload } from '@web-rendering/groundcontrol-core';
import { getEnhancementUrl } from './get-enhancement-url';

/**
 * Handles click redirection on EQT builds. Returns true if the click
 * was handled (caller should return early), false otherwise.
 */
export const handleEqtClick = (clickEvent: AdClickEvent, payload: Payload): boolean => {
  if (GC_INSTANCE_NAME !== 'equativ') return false;

  const url = clickEvent.redirectUrl ?? getEnhancementUrl(payload);
  if (url) {
    window.open(url, '_blank');
  }

  return true;
};
