import type { ClickExtractor } from '@web-rendering/click-extraction';
import {
  CLICK_EXTRACTION_PARTNER_IDS,
  CLICK_EXTRACTION_PARTNERS,
  ClickExtractionPartner,
  extractAppnexusClickUrl,
  extractDv360ClickUrl,
  extractRubiconClickUrl,
  extractTradeDeskClickUrl
} from '@web-rendering/click-extraction';
import type { Creative, Payload } from '@web-rendering/groundcontrol-core';
import { isScenarioActive, Scenario } from '@web-rendering/groundcontrol-core';
import { CreativeType } from '@web-rendering/groundcontrol-shared-types';

// This is the one place the three per-DSP facts meet: which extractor implements it
// (click-extraction) and which scenario activates it (core). Partner ids live with the
// extractors in CLICK_EXTRACTION_PARTNER_IDS, so onboarding a partner id touches neither this
// file nor the banner components; adding a whole DSP is one line in each map below.
const CLICK_EXTRACTORS: Readonly<Record<ClickExtractionPartner, ClickExtractor>> = {
  [ClickExtractionPartner.Dv360]: extractDv360ClickUrl,
  [ClickExtractionPartner.Appnexus]: extractAppnexusClickUrl,
  [ClickExtractionPartner.TradeDesk]: extractTradeDeskClickUrl,
  [ClickExtractionPartner.Rubicon]: extractRubiconClickUrl
};

const ACTIVATION_SCENARIOS: Readonly<Record<ClickExtractionPartner, Scenario>> = {
  [ClickExtractionPartner.Dv360]: Scenario.Dv360ClickExtraction,
  [ClickExtractionPartner.Appnexus]: Scenario.AppnexusClickExtraction,
  [ClickExtractionPartner.TradeDesk]: Scenario.TradeDeskClickExtraction,
  [ClickExtractionPartner.Rubicon]: Scenario.RubiconClickExtraction
};

type ClickExtractionPayload = Pick<Payload, 'scenario'> & {
  creative: Pick<Creative, 'type' | 'partnerId'>;
};

/**
 * Resolves the click extractor for the payload's partner when Delivery Admin assigned the
 * partner's click-extraction scenario value (arm resolved server-side, forwarded verbatim as
 * `payload.scenario` — see WR-2111's value registry). Returns null on any other value,
 * including null/unrecognized, to signal the caller should fall back to the legacy
 * findClickoutUrl path.
 */
export function getActiveClickExtractor(payload: ClickExtractionPayload): ClickExtractor | null {
  if (GC_INSTANCE_NAME !== 'equativ') return null;
  if (payload.creative.type !== CreativeType.Banner) return null;

  const partner = CLICK_EXTRACTION_PARTNERS.find((candidate) =>
    CLICK_EXTRACTION_PARTNER_IDS[candidate].includes(payload.creative.partnerId)
  );
  if (!partner) return null;

  return isScenarioActive(payload, ACTIVATION_SCENARIOS[partner]) ? CLICK_EXTRACTORS[partner] : null;
}
