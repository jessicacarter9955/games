import { GCEnhancementType } from '@sharethrough/groundcontrol-enhancement-flush';
import type { Enhancement } from '@web-rendering/groundcontrol-shared-types';

const remoteEnhancements = [
  GCEnhancementType.BannerMedalCount,
  GCEnhancementType.BannerShoppable,
  GCEnhancementType.BannerShoppableOverlay,
  GCEnhancementType.BannerSportsTicker,
  GCEnhancementType.OutstreamMedalCount,
  GCEnhancementType.OutstreamShoppable,
  GCEnhancementType.OutstreamSportsTicker,
  GCEnhancementType.BannerBrandedHeadline,
  GCEnhancementType.OutstreamBrandedHeadline,
  GCEnhancementType.BannerWorldTournament,
  GCEnhancementType.OutstreamWorldTournament,
  GCEnhancementType.BannerCustom,
  GCEnhancementType.OutstreamCustom
];

export const isRemoteEnhancement = (enhancement: Enhancement) =>
  remoteEnhancements.some((type) => type === enhancement.type);
