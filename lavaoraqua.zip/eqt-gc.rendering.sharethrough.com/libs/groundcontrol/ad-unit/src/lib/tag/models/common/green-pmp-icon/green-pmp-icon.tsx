import type { Creative } from '@web-rendering/groundcontrol-core';
import PmpIcon from '../../../../assets/icons/greenpmp.png';
import GreenPmpIconConfig from './green-pmp-icon.config';
import styles from './green-pmp-icon.module.scss';

type GreenPmpIconProps = {
  creative: Creative;
};

export const GreenPmpIcon = (props: GreenPmpIconProps) => {
  if (props.creative.dealId && GreenPmpIconConfig.DEAL_ID_DISABLED.includes(props.creative.dealId)) return null;

  return (
    <div className={`${styles['green-pmp-container']}`}>
      <a
        href="https://www.sharethrough.com/green-icon"
        onClick={(e) => e.stopPropagation()}
        target="_blank"
        rel="noopener noreferrer"
        data-testid="green-pmp-link"
      >
        <img src={PmpIcon} alt="Green PMP Icon" className={`str-green-pmp-icon ${styles['green-pmp-icon']}`} />
      </a>
    </div>
  );
};
