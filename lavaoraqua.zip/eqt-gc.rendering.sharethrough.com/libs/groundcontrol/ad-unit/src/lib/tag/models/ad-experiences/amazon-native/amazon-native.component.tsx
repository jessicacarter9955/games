import { useLifecycleScope, usePayload, useTrackerService } from '@web-rendering/groundcontrol-core';
import { firePixel } from '@web-rendering/groundcontrol-beacon';
import { useNativeAssets } from '@web-rendering/groundcontrol-ortb';
import type { FunctionComponent } from 'preact';
import { createRef } from 'preact';
import { useEffect } from 'preact/hooks';
import { Drawer } from '../../../../tag/models/common/template/enhanced/drawer/drawer.component';
import type { AdExperienceBaseProps } from '../types';
import { AmazonAdvertiser } from './advertiser/advertiser.component';
import './amazon-native.scss';
import { AmazonBadge } from './badge/badge.component';
import { AmazonCoupon } from './coupon/coupon.component';
import { AmazonCta } from './cta/cta.component';
import { AmazonDescription } from './description/description.component';
import { AmazonPrice } from './price/price.component';
import { AmazonRating } from './rating/rating.component';
import { AmazonReview } from './review/review.component';
import { AmazonThumbnail } from './thumbnail/thumbnail.component';

export const AmazonNative: FunctionComponent<AdExperienceBaseProps> = () => {
  const payload = usePayload();
  const assets = useNativeAssets();
  const element = createRef<HTMLDivElement>();
  const trackerService = useTrackerService();
  const scope = useLifecycleScope();

  if (!payload || !assets) return null;

  const { coupon, price, salePrice } = assets;

  const showPriceContainer = !coupon && (price || salePrice);

  useEffect(() => {
    const parentElement = element.current?.parentElement;
    if (parentElement) {
      trackerService?.trackImpression(parentElement, scope);
      trackerService?.trackAmazonNativeImpression();
    }
  }, []);

  const handleClick = (event: MouseEvent) => {
    const { cta } = assets;
    // The bid's click trackers live on the creative; a DCO asset may carry its own on cta.link.
    // Fire both (deduped) and open the asset link when present, else the bid's top-level link.
    const destinationUrl = cta?.link?.url ?? payload.creative.link;
    const assetTrackers = cta?.link?.clicktrackers ?? [];
    const bidTrackers = payload.creative.clicktrackers ?? [];
    const uniqueClickTrackers = new Set([...assetTrackers, ...bidTrackers]);
    uniqueClickTrackers.forEach((url) => firePixel(url));
    if (destinationUrl) window.open(destinationUrl, '_blank');
    if (!trackerService) return;

    const target = event.target;
    if (target instanceof HTMLElement && target.dataset['strThumbnail'] === 'true') {
      trackerService.trackClick(target);
    }

    if (element.current) trackerService.trackClick(element.current);
  };

  return (
    <div ref={element} className="str-amazon-native-container" data-testid="str-amazon-native" onClick={handleClick}>
      <div className="str-amazon-native">
        <AmazonThumbnail />
        <div className="str-amazon-body">
          <AmazonCoupon />
          <AmazonDescription />
          <AmazonRating />
          <AmazonBadge />
          {showPriceContainer ? (
            <div className="str-amazon-price-cta">
              <AmazonPrice />
              <AmazonCta />
            </div>
          ) : (
            <AmazonCta />
          )}
          {/* {coupon && <AmazonAvailableLogo />} */}
          <AmazonReview />
        </div>
        <AmazonAdvertiser />
      </div>

      <Drawer creative={payload.creative} network={payload.network} />
    </div>
  );
};
