import { useNativeAssets } from '@web-rendering/groundcontrol-ortb';
import type { FunctionComponent } from 'preact';
import { useButler } from '../../../hooks';
import './advertiser.scss';

export const RetailNativeAdvertiser: FunctionComponent = () => {
  const butlerResponse = useButler();
  const assets = useNativeAssets();
  const advertiserName = assets?.shoppable?.sponsoredBy ?? assets?.sponsored?.data.value;
  if (!advertiserName) return null;

  const promotedByText = butlerResponse?.creative.promotedByText ?? 'Ad by';

  return (
    <div className="str-retail-advertiser">
      <span className="str-retail-promoted-by">{promotedByText}</span>
      <span className="str-retail-advertiser-name">{advertiserName}</span>
    </div>
  );
};
