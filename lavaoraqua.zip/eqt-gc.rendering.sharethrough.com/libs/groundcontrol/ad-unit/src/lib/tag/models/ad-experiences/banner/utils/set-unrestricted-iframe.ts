import type { PayloadContextType } from '@web-rendering/groundcontrol-core';
import { reportError } from '@web-rendering/groundcontrol-monitoring';
import { SafeFrameHandler } from '@web-rendering/groundcontrol-utils';
import { handleIframeError } from './handle-iframe-errors';
import { setRestrictedIframeContent } from './set-restricted-iframe';
import type { LifecycleScope } from '@web-rendering/groundcontrol-shared-types/lifecycle/lifecycle';

export const setUnrestrictedIframeContent = (
  iframe: HTMLIFrameElement,
  html: string,
  payload: PayloadContextType,
  scope: LifecycleScope
): boolean => {
  let iframedoc: Document | null = null;
  try {
    iframedoc = iframe.contentDocument || (iframe.contentWindow && iframe.contentWindow.document);
  } catch (error) {
    // If we can't access the contentDocument, try to set the restricted content
    if (error instanceof Error) return setRestrictedIframeContent(iframe, html, payload, scope);
  }

  if (!iframedoc) {
    // contentWindow is null only while the iframe has no browsing context, i.e. it is not in
    // the document when this runs. Recording connectivity, document state and timing is what
    // lets Airbrake tell a detached-subtree race from a hidden or prerendering document.
    const isPrerendering = 'prerendering' in document && document.prerendering === true;
    reportError(new Error('SetUnrestrictedIframeContent: contentDocument is not accessible'), {
      scope,
      message: 'SetUnrestrictedIframeContent: contentDocument is not accessible, falling back to restricted content',
      supplyId: payload.network.callerId,
      payload,
      errorPayload: { isRestrictedIframeCaller: false },
      isIframeConnected: iframe.isConnected,
      hasContentWindow: iframe.contentWindow !== null,
      readyState: document.readyState,
      visibilityState: document.visibilityState,
      isPrerendering,
      msSinceNavigation: Math.round(performance.now()),
      isSafeFrame: SafeFrameHandler.isSafeFrame(),
      isTopDocument: window.self === window.top,
      // The condition recurs steadily (~55k notices/day at 10%); 1% keeps the trend visible.
      sampling: 0.01
    });
    return setRestrictedIframeContent(iframe, html, payload, scope);
  }

  try {
    iframedoc.open();
    iframedoc.write(html);
    iframedoc.close();
  } catch (error) {
    // TODO: directly use setRestrictedIframeContent once we are confident about the error
    let errors: string[] = [];
    if (error instanceof Error) {
      errors = [error.message];
    }
    try {
      // First fallback to srcdoc
      iframe.srcdoc = html;
    } catch (srcdocError) {
      if (!(srcdocError instanceof Error)) return false;
      errors.push(srcdocError.message);

      try {
        // Second fallback to src
        iframe.src = `data:text/html,${encodeURIComponent(html)}`;
      } catch (srcError) {
        // Only report the final error with context of all failures
        if (!(srcError instanceof Error)) return false;
        handleIframeError(srcError, {
          message: 'SetUnrestrictedIframeContent: Failed all iframe content setting attempts',
          isRestrictedIframeCaller: false,
          payload,
          scope,
          extraInfo: {
            previousErrors: errors,
            fallbacksAttempted: ['document.write', 'srcdoc', 'src']
          }
        });
        return false;
      }
    }
  }

  return true;
};
