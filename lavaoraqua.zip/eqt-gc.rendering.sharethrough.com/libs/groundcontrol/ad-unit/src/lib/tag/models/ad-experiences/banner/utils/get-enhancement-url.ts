import type { Payload } from '@web-rendering/groundcontrol-core';

export const getEnhancementUrl = (payload: Payload): string | null => {
  const enhancementPayload = payload.enhancement.payload;
  if (!enhancementPayload) return null;

  const url =
    ('redirectUrl' in enhancementPayload ? enhancementPayload.redirectUrl : null) ??
    ('clickUrl' in enhancementPayload ? enhancementPayload.clickUrl : null) ??
    ('media_url' in enhancementPayload ? enhancementPayload.media_url : null);

  return url ? String(url) : null;
};
