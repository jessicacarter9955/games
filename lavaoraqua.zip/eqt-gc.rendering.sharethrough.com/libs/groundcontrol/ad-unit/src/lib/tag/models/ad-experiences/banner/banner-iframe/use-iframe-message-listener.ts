import { useTrackerService } from '@web-rendering/groundcontrol-core';
import type { RefObject } from 'preact';
import { useEffect } from 'preact/hooks';
import { iframeEvent } from '../utils';

export type UseIframeMessageListenerParams = {
  iframeRef: RefObject<HTMLIFrameElement>;
  onIframeClick?: (event: MouseEvent) => void;
  onIframeError: () => void;
};

export const useIframeMessageListener = ({
  iframeRef,
  onIframeClick,
  onIframeError
}: UseIframeMessageListenerParams): void => {
  const trackerService = useTrackerService();

  useEffect(() => {
    const handleMessage = (event: MessageEvent) => {
      const currentIframe = iframeRef.current;

      if (event.source === currentIframe?.contentWindow) {
        switch (event.data?.eventType) {
          case 'iframeError':
            // Handle iframe error messages if needed
            onIframeError();
            break;
          // intentionally using hardcoded strings for `engagementClick` and
          // `https://c.sofiapulse.com` for now; if additional values need to be maintained
          // in the future, we can convert these to an enum.
          case 'engagementClick':
            if (event.data.originalOrigin === 'https://c.sofiapulse.com') {
              trackerService?.trackClick(currentIframe);
            }
            break;
          default:
            iframeEvent(event.data, onIframeClick); // old handler implementation
        }
      }
    };

    window.addEventListener('message', handleMessage);

    return () => {
      window.removeEventListener('message', handleMessage);
    };
  }, [iframeRef, onIframeClick, trackerService]);
};
