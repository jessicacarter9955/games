import { createContext } from 'preact';
import { useContext } from 'preact/hooks';
import { useTrackerService } from '@web-rendering/groundcontrol-core';

import type { TrackerService } from '@web-rendering/groundcontrol-core';

export type RetailTracker = Pick<
  TrackerService<unknown>,
  'trackImpression' | 'trackClick' | 'trackShoppableCarouselArrowClick'
>;

// Lets the native bundle take the layouts' tracker calls without a TrackerService. gc.js provides none and falls back
export const RetailTrackerContext = createContext<RetailTracker | null>(null);

export const useRetailTracker = (): RetailTracker | null => {
  const retailTracker = useContext(RetailTrackerContext);
  const trackerService = useTrackerService();
  return retailTracker ?? trackerService;
};
