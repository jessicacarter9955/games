import { reportError } from '@web-rendering/groundcontrol-monitoring';
import { useNativeAssets } from '@web-rendering/groundcontrol-ortb';
import type { FunctionComponent } from 'preact';
import { Fragment } from 'preact';
import './badge.scss';
import { useLifecycleScope } from '@web-rendering/groundcontrol-core';

export const AmazonBadge: FunctionComponent = () => {
  const assets = useNativeAssets();
  const scope = useLifecycleScope();

  if (!assets) return null;

  const { badge } = assets;
  if (!badge) return null;

  const parsedBadge = (() => {
    if (badge) {
      try {
        return JSON.parse(badge.data.value);
      } catch (e) {
        if (e instanceof Error) {
          e.message = `Error parsing badge JSON: ${e.message}`;
          reportError(e, { scope, amazonBadge: badge });
        }
      }
    }

    return null;
  })();
  if (!parsedBadge) return null;

  return (
    <Fragment>
      <div className="str-amazon-badge-flex-break" />
      <div className="str-amazon-badge">
        <div
          className="str-amazon-badge-label"
          style={{ color: `#${parsedBadge.label.color}`, backgroundColor: `#${parsedBadge.label.backgroundColor}` }}
        >
          <span className="str-amazon-badge-label-text">{parsedBadge.label.text}</span>
        </div>
        <div
          className="str-amazon-badge-messaging"
          style={{
            color: `#${parsedBadge.messaging.color}`,
            backgroundColor: `#${parsedBadge.messaging.backgroundColor}`
          }}
        >
          <span className="str-amazon-badge-messaging-text">{parsedBadge.messaging.text}</span>
        </div>
      </div>
    </Fragment>
  );
};
