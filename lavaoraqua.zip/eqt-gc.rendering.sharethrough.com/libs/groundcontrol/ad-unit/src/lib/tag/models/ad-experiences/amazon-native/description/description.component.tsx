import { useNativeAssets } from '@web-rendering/groundcontrol-ortb';
import type { FunctionComponent } from 'preact';
import './description.scss';
import { clsx } from 'clsx';

export const AmazonDescription: FunctionComponent = () => {
  const assets = useNativeAssets();
  if (!assets) return null;

  const { description, title, badge } = assets;

  if (!description && !title) return null;

  return (
    <div className={clsx('str-amazon-description', !badge && 'str-amazon-description-multiline')}>
      {description?.data.value || title?.title.text}
    </div>
  );
};
