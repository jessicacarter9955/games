/* eslint-disable-next-line @typescript-eslint/no-explicit-any */
export const iframeEvent = (data: any, onClickEvent?: ((event: MouseEvent) => void) | undefined) => {
  if (isClickEvent(data) && onClickEvent) {
    onClickEvent(new MouseEvent('thumbnailclick'));
  }
};

/* eslint-disable-next-line @typescript-eslint/no-explicit-any */
export const isClickEvent = (data: any) => {
  /* eslint-disable-next-line @typescript-eslint/no-explicit-any */
  let objectData: any = typeof data === 'string' ? stringToObject(data) : data;
  if (objectData.stringValue) objectData = tryGetDataRegex(objectData.stringValue);
  if (objectData.method) {
    return objectData.method === 'clickthrough' || objectData.method === 'iframeclick';
  } else if (objectData.clickTag) {
    window.open(objectData.clickTag, '_blank');
    return true;
  } else if (objectData.methodName) {
    return objectData.methodName === 'AD_CLICKED';
  }
  return false;
};

/* eslint-disable-next-line @typescript-eslint/no-explicit-any */
export const stringToObject = (stringData: string): any => {
  try {
    return JSON.parse(stringData);
  } catch (e) {
    return defaultStringValue(stringData);
  }
};

/* eslint-disable-next-line @typescript-eslint/no-explicit-any */
export const tryGetDataRegex = (stringData: string): any => {
  try {
    /* eslint-disable-next-line no-useless-escape */
    const regex = /\"data":{(.*?)\}/;
    const match = stringData.match(regex);
    if (match) {
      const jsonObject = JSON.parse('{' + match[1] + '}');
      return jsonObject;
    }
    return defaultStringValue(stringData);
  } catch (e) {
    return defaultStringValue(stringData);
  }
};

export const defaultStringValue = (stringData: string) => {
  return { stringValue: stringData };
};
