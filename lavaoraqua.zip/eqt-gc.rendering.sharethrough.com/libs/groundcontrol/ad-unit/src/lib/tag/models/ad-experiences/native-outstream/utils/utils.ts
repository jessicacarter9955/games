import type { ImaSDK } from '@ad-rendering/ima-sdk';
import { ImaVideoPercentage } from '@ad-rendering/ima-sdk';
import type { DurationKey, TrackerService } from '@web-rendering/groundcontrol-core';
import { QuartileKey } from '@web-rendering/groundcontrol-core';
import { reportError } from '@web-rendering/groundcontrol-monitoring';
import type { INativeOutstreamPayloadSignalState } from '../type';
import type { LifecycleScope } from '@web-rendering/groundcontrol-shared-types/lifecycle/lifecycle';

const durationKeys: DurationKey[] = [3, 10, 15, 30];

export const configureState = (
  imaSDK: ImaSDK,
  signalState: INativeOutstreamPayloadSignalState,
  replayed: boolean,
  trackerService: TrackerService<unknown> | null,
  setCurrentTime: (time: number) => void,
  setInnerCreativeId: (creativeId: string) => void,
  setVideoElement: (value: HTMLVideoElement) => void,
  trackRenderedImpression: () => void
) => {
  const { state } = imaSDK;
  let isVpaidCreative: boolean | undefined = undefined;

  state.creativeId.subscribe((creativeId: string | undefined) => {
    if (creativeId) setInnerCreativeId(creativeId);
  });

  state.clickThroughUrl.subscribe((clickThroughUrl: string | undefined) => {
    if (clickThroughUrl) signalState.clickThroughUrl.value = clickThroughUrl;
  });

  state.vpaid.subscribe((value: boolean | undefined) => {
    isVpaidCreative = value;
  });

  state.currentQuartile.subscribe((videoQuartile: ImaVideoPercentage | undefined) => {
    if (!videoQuartile || !trackerService || replayed) return;
    const quartileMap: Record<ImaVideoPercentage, QuartileKey> = {
      [ImaVideoPercentage.P25]: QuartileKey.Q25,
      [ImaVideoPercentage.P50]: QuartileKey.Q50,
      [ImaVideoPercentage.P75]: QuartileKey.Q75,
      [ImaVideoPercentage.P95]: QuartileKey.Q95
    };
    const videoQuartileKey = quartileMap[videoQuartile];
    trackerService.trackVideoQuartile(videoQuartileKey);
  });

  state.duration.subscribe((videoDuration: number | undefined) => {
    if (videoDuration) signalState.duration.value = videoDuration;
  });

  state.started.subscribe((videoStarted: boolean) => {
    if (!videoStarted) return;

    if (!replayed) {
      // allow to populate clickThroughUrl
      window.setTimeout(() => {
        trackerService?.trackVpaidEnabled(Boolean(isVpaidCreative));

        const hasClickThrough = Boolean(signalState.clickThroughUrl.value);
        trackerService?.trackClickthroughFound(hasClickThrough);
      }, 400);
    }

    signalState.started.value = videoStarted;
  });

  state.adVideoHtmlElement.subscribe((videoElement: HTMLVideoElement | undefined) => {
    if (videoElement) setVideoElement(videoElement);
  });

  state.adVideoSource.subscribe((videoSource: string | undefined) => {
    if (videoSource) signalState.adVideoSource.value = videoSource;
  });

  state.currentTime.subscribe((videoCurrentTime: number | undefined) => {
    if (videoCurrentTime === undefined) return;
    signalState.currentTime.value = videoCurrentTime;

    setCurrentTime(videoCurrentTime);

    if (!replayed) {
      for (let i = durationKeys.length - 1; i >= 0; i--) {
        if (videoCurrentTime >= durationKeys[i]) {
          trackerService?.trackSilentAutoPlayDuration(durationKeys[i]);
          durationKeys.splice(i, 1);
          break;
        }
      }
    }
  });

  state.muted.subscribe((videoMuted: boolean) => {
    signalState.muted.value = videoMuted;
    if (replayed) return;
    if (!videoMuted && signalState.currentTime.value > 0) {
      trackerService?.trackVideoVolumeOn(signalState.currentTime.value);
    }
  });

  state.playing.subscribe((videoPlaying: boolean) => {
    signalState.playing.value = videoPlaying;

    if (videoPlaying && !replayed) {
      trackerService?.trackVideoPlay();
      trackRenderedImpression();
    }
  });

  state.completed.subscribe((videoCompleted: boolean) => {
    signalState.completed.value = videoCompleted;
    if (videoCompleted && trackerService && !replayed) {
      const duration = signalState.duration.value;
      const currentTime = signalState.currentTime.value;
      const muted = signalState.muted.value;
      const remainingTime = duration - currentTime;
      const actualTime = remainingTime >= 0 ? duration - remainingTime : duration;
      trackerService.trackVideoViewDuration(actualTime, muted);
    }
  });

  state.rendered.subscribe((videoRendered: boolean) => {
    //autoplay property has been removed and true is passed to trackVideoStart
    if (videoRendered && trackerService && !replayed) trackerService.trackVideoStart(true);
  });
};

// textContent unwraps CDATA; querySelector matches the exact element name, so <MediaFile> can't
// collide with its <MediaFiles> container the way a substring match would.
const extractTagUrl = (vastDoc: Document, tag: string): string | undefined =>
  vastDoc.querySelector(tag)?.textContent?.trim() || undefined;

/**
 * Resolve the external endpoint IMA was fetching when an error occurred, for error-report context.
 *
 * Mirrors ImaSDK's own adsResponse-vs-adTagUrl decision (`vastUrl.match('</VAST>')`): a closing
 * </VAST> tag means inline VAST markup, anything else is handed to IMA as an ad tag URL. For inline
 * VAST we surface the wrapper redirect target first (the usual network/redirect failure source),
 * then fall back to the media file URL.
 */
export const resolveFailingEndpoint = (vastSource?: string): string | undefined => {
  if (!vastSource) return undefined;
  if (!vastSource.includes('</VAST>')) return vastSource;
  const vastDoc = new DOMParser().parseFromString(vastSource, 'text/xml');
  return extractTagUrl(vastDoc, 'VASTAdTagURI') ?? extractTagUrl(vastDoc, 'MediaFile');
};

export const imaErrorHandler = (
  error: Error,
  trackerService: TrackerService<unknown> | null,
  scope: LifecycleScope,
  options?: { vastSource?: string }
) => {
  if (
    'data' in error &&
    error.data &&
    typeof error.data === 'object' &&
    'errorCode' in error.data &&
    typeof error.data.errorCode === 'number'
  ) {
    const { errorCode } = error.data;
    // If the error has a data property, we can assume it's an IAdError
    // and handle it accordingly.
    const ignoreImaAirbrakeErrors = [301, 302, 303, 400, 401, 402, 403, 602, 901];
    // Don't log errors caused by the creative
    if (ignoreImaAirbrakeErrors.includes(errorCode)) {
      // send beacon code after we know the error message
      trackerService?.trackVastError(errorCode, scope);
      return;
    }
  } else {
    // IMA never turned this into an AdError, so it never fired the VAST wrapper's own <Error>
    // tracker either — without this, the ad silently fails to play and nothing is ever notified.
    trackerService?.trackVideoFailedToPlay();
  }

  const endpoint = resolveFailingEndpoint(options?.vastSource);

  reportError(error, {
    scope,
    context: 'native-outstream/ima-ad-error',
    function: '@ad-rendering/ima-sdk:imaErrorHandler',
    ...(endpoint ? { endpoint } : {})
  });
};
