import type { GCEnhancementPayload } from '@sharethrough/groundcontrol-enhancement-flush';
import type { PayloadContextType } from '@web-rendering/groundcontrol-core';
import type { Enhancement } from '@web-rendering/groundcontrol-shared-types';
import { SupportedLanguage } from '@web-rendering/groundcontrol-i18n';

const getSupportedLanguage = (language?: string): SupportedLanguage | undefined => {
  if (!language) return;

  const normalizedLanguage = language.toLowerCase();
  return Object.values(SupportedLanguage).find(
    (lang) => lang === normalizedLanguage || lang === normalizedLanguage.replace('_', '-')
  );
};

const getLanguageFromEnhancement = (
  payload: GCEnhancementPayload['payload'] | undefined
): SupportedLanguage | undefined => {
  if (!payload) return;
  if (!('language' in payload)) return;
  if (typeof payload.language !== 'string') return;
  if (payload.language === '') return;

  return getSupportedLanguage(payload.language);
};

const getLanguageFromPayload = (payload: PayloadContextType | null | undefined): SupportedLanguage | undefined => {
  if (!payload || !payload.creative || !payload.creative.language) return;

  const creativeLanguage = payload.creative.language.toString();

  return getSupportedLanguage(creativeLanguage);
};

export const getContentLanguage = (
  payload: PayloadContextType | null | undefined,
  enhancement: Enhancement | null | undefined
): SupportedLanguage | undefined => {
  return getLanguageFromEnhancement(enhancement?.payload) || getLanguageFromPayload(payload);
};
