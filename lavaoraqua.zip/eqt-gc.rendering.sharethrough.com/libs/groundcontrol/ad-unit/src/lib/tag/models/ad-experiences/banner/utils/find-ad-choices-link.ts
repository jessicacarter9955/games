export const findAdChoicesLink = (iframe: HTMLIFrameElement): Promise<HTMLElement | null> => {
  const waitForIframeLoad = (frame: HTMLIFrameElement): Promise<void> => {
    return new Promise((resolve) => {
      if (frame.contentDocument?.readyState === 'complete') {
        resolve();
      } else {
        frame.addEventListener('load', () => resolve());
      }
    });
  };

  const AD_CHOICES_PATTERN = /ad[-_]?choices|ad[-_]?info/i;

  const getDataJcpAttributionMatch = (element: HTMLElement): boolean => {
    try {
      // Check if the element has data-jcp-attribution-data with adChoices
      const dataJcpAttribution = element.getAttribute('data-jcp-attribution-data') || '';
      const dataJcpAttributionArray = parseDataJcpAttribution(dataJcpAttribution);
      if (!dataJcpAttributionArray.length) return false;
      return dataJcpAttributionArray.some((arr: string[]) => arr.some((item: string) => AD_CHOICES_PATTERN.test(item)));
    } catch (e) {
      console.debug('Error in getDataJcpAttributionMatch:', e);
      return false;
    }
  };

  const parseDataJcpAttribution = (data: string): string[][] => {
    if (!data) {
      return [];
    }
    try {
      const parsedData: string[][] = JSON.parse(data);
      if (Array.isArray(parsedData)) {
        // Filter out non-array elements and non-string elements inside arrays
        const filteredData = parsedData
          .filter((arr) => Array.isArray(arr))
          .map((arr) => arr.filter((item) => typeof item === 'string'));
        return filteredData;
      }
    } catch (e) {
      console.debug('Error parsing dataJcpAttribution:', e);
    }
    return [];
  };

  const containsAdChoices = (element: HTMLElement): boolean => {
    try {
      const src = element.getAttribute('src') || '';
      const href = element.getAttribute('href') || '';
      const dataJcpAttributionMatch = getDataJcpAttributionMatch(element);

      return AD_CHOICES_PATTERN.test(src) || AD_CHOICES_PATTERN.test(href) || dataJcpAttributionMatch;
    } catch (e) {
      return false;
    }
  };

  const searchInFrame = async (frame: HTMLIFrameElement): Promise<HTMLElement | null> => {
    try {
      // First check if the frame itself has adChoices in its src
      if (containsAdChoices(frame)) {
        return frame;
      }

      // Then try to access the frame's content
      const doc = frame.contentDocument;
      if (!doc) {
        return null;
      }

      await waitForIframeLoad(frame);

      // If we get here, we can access the frame's content
      const links = Array.from(doc.getElementsByTagName('a'));
      const adChoicesLink = links.find(containsAdChoices);
      if (adChoicesLink) return adChoicesLink;

      const images = Array.from(doc.getElementsByTagName('img'));
      const adChoicesImage = images.find(containsAdChoices);
      if (adChoicesImage) return adChoicesImage;

      const nestedFrames = Array.from(doc.getElementsByTagName('iframe'));
      for (const nestedFrame of nestedFrames) {
        const result = await searchInFrame(nestedFrame as HTMLIFrameElement);
        if (result) return result;
      }

      const scripts = Array.from(doc.getElementsByTagName('script'));
      const adChoicesScript = scripts.find(containsAdChoices);
      if (adChoicesScript) return adChoicesScript;

      return null;
    } catch (error) {
      console.debug('Error in searchInFrame:', error);
      return null;
    }
  };

  return searchInFrame(iframe);
};
