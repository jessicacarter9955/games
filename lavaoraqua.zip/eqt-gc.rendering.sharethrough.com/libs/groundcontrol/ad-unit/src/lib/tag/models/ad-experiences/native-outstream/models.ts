import { signal } from '@preact/signals';
import type { INativeOutstreamPayloadSignalState } from './type';

export const NativeOutstreamPayloadSignalState: INativeOutstreamPayloadSignalState = {
  adVideoSource: signal(undefined),
  clickThroughUrl: signal(undefined),
  completed: signal(false),
  currentTime: signal(0),
  duration: signal(0),
  muted: signal(true),
  playing: signal(false),
  started: signal(false),
  videoReplayed: signal(false)
};
