import type { Payload } from '@web-rendering/groundcontrol-core';
import { shouldUseEmbeddedMeasurement } from '@web-rendering/groundcontrol-core';
import { MeasurementType } from '@web-rendering/groundcontrol-measurement/lib/types';

/**
 * Classifies how a placement is counted, shared by every ad experience (banner, native). Kept in a
 * standalone module rather than a component file so importing it does not pull an experience's whole
 * render tree into another experience's bundle (WR-2087 AC3 bundle budget).
 */
export function getMeasurementType(payload: Payload): MeasurementType {
  if (shouldUseEmbeddedMeasurement(payload)) return MeasurementType.Embedded;
  return payload?.reporting?.countImpressionOnePixel ? MeasurementType.OnePixel : MeasurementType.Standard;
}
