import type { ShoppableProduct } from '@web-rendering/groundcontrol-ortb';
import type { FunctionComponent } from 'preact';
import './description.scss';

export const RetailNativeDescription: FunctionComponent<{ product?: ShoppableProduct }> = ({ product }) => {
  if (!product?.description) return null;

  return <div className="str-retail-description">{product.description}</div>;
};
