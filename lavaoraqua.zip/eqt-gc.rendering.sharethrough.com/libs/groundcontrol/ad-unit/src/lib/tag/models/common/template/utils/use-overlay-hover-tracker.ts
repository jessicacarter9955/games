import { enhancementLoaded, trackerService } from '@web-rendering/groundcontrol-core';
import { useEffect, useRef } from 'preact/hooks';

export type OverlayTrackerService = {
  trackOverlayActive: () => void;
};

type Options = {
  panelSelector?: string; // defaults to '.str-enhanced-info-wrapper'
  openClass?: string; // defaults to 'is-open'
  durationMs?: number; // CSS transition duration; defaults 500
  threshold?: number; // 0..1; defaults 0.5
  alwaysOpen?: boolean;
};

/**
 * Hooks up hover → overlay slide-in, and fires beacon at threshold progress.
 * JS toggles a CSS class to start the animation; no transitionend observers.
 */
export function useOverlayHoverTracker(
  rootRef: preact.RefObject<HTMLElement>,
  isOverlayVariant: boolean,
  {
    panelSelector = '.str-enhanced-info-wrapper',
    openClass = 'is-open',
    durationMs = 500, // must match: transition: left 0.5s ...
    threshold = 0.5, // 50%
    alwaysOpen = false
  }: Options = {}
) {
  const firedOnceRef = useRef(false);
  const thresholdTimerRef = useRef<number | null>(null);

  useEffect(() => {
    const root = rootRef.current;
    const panel = root?.querySelector<HTMLElement>(panelSelector);

    if (!isOverlayVariant || !root || !panel) return;

    const clearThresholdTimer = () => {
      if (thresholdTimerRef.current != null) {
        clearTimeout(thresholdTimerRef.current);
        thresholdTimerRef.current = null;
      }
    };

    const sendBeacon = () => {
      if (firedOnceRef.current) return;
      if (!enhancementLoaded.value) return;
      firedOnceRef.current = true;
      trackerService.value?.trackOverlayActive();
    };

    const startThresholdTimer = () => {
      clearThresholdTimer();
      const delay = Math.max(0, durationMs * threshold);
      thresholdTimerRef.current = window.setTimeout(() => {
        sendBeacon();
      }, delay);
    };

    const open = () => {
      panel.classList.add(openClass);
      startThresholdTimer();
    };

    const close = () => {
      clearThresholdTimer();
      panel.classList.remove(openClass);
    };

    if (alwaysOpen) {
      open();
      return () => {
        clearThresholdTimer();
        panel.classList.remove(openClass);
      };
    }

    const onTap = () => {
      if (panel.classList.contains(openClass)) {
        close();
      } else {
        open();
      }
    };

    root.addEventListener('mouseenter', open);
    root.addEventListener('mouseleave', close);
    root.addEventListener('touchstart', onTap, { passive: true });

    return () => {
      clearThresholdTimer();
      root.removeEventListener('mouseenter', open);
      root.removeEventListener('mouseleave', close);
      root.removeEventListener('touchstart', onTap);
      panel.classList.remove(openClass);
    };
  }, [isOverlayVariant, rootRef, panelSelector, openClass, durationMs, threshold, alwaysOpen]);
}
