export const getUrlFromElement = (element: HTMLElement | null) => {
  const match = element && element.innerHTML.match(/href=['"](.*?)['"]/);

  if (match && match[1] && match[1].indexOf('://www.tubemogul.com') === -1) {
    return match[1];
  }

  return null;
};
