const STR_RENDER_STRATEGY = /data-str-render-strategy="(ps|div|iframe)"/;

export const getRenderStrategy = (adm: string) => {
  return STR_RENDER_STRATEGY.exec(adm)?.[1] || null;
};
