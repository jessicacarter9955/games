import { GCEnhancementType, type TemplateUrlEnhancementPayload } from '@sharethrough/groundcontrol-enhancement-flush';
import { isEnhanceable } from '@web-rendering/groundcontrol-butler-helpers';
import { usePayload } from '@web-rendering/groundcontrol-core';
import { useOverlayHintAnimation } from '@web-rendering/groundcontrol-enhancements';
import { CreativeType } from '@web-rendering/groundcontrol-shared-types';
import { setEnhancementRenderEnd } from '@web-rendering/groundcontrol-store';
import clsx from 'clsx';
import type { FunctionComponent } from 'preact';
import { useEffect, useRef } from 'preact/hooks';
import type { TemplateProps } from '../types';
import { useOverlayHoverTracker } from '../utils/use-overlay-hover-tracker';
import EnhancedTemplateContent from './content';
import Drawer from './drawer';
import './enhanced.template.scss';

const isAlwaysExpandedShoppablePayload = (
  payload: unknown
): payload is TemplateUrlEnhancementPayload['payload'] & { alwaysExpanded: true } => {
  if (!payload || typeof payload !== 'object') return false;
  return 'alwaysExpanded' in payload && payload.alwaysExpanded === true;
};

export const EnhancedTemplate: FunctionComponent<TemplateProps> = ({
  adserverRequestId,
  children,
  className,
  creative,
  network,
  onEnhancementClick
}) => {
  const payload = usePayload();
  const enhancement = payload?.enhancement || { type: 'disabled' };
  const rootRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!payload || !isEnhanceable(payload.creative, enhancement)) return;
    if (enhancement.type === 'disabled') return;
    setEnhancementRenderEnd();
  }, [enhancement, payload, adserverRequestId]);

  const isOverlayVariant = enhancement.type === GCEnhancementType.BannerShoppableOverlay;
  const isOverlayAlwaysExpanded = isOverlayVariant && isAlwaysExpandedShoppablePayload(enhancement.payload);
  const creativeAction =
    'type' in creative ? (creative.type === CreativeType.Native ? creative.nativeType : creative.type) : 'unknown';

  // 👇 Hook: drives the .is-open class and fires at 50% (250ms of 0.5s)
  useOverlayHoverTracker(rootRef, isOverlayVariant, {
    durationMs: 500,
    threshold: 0.5,
    alwaysOpen: isOverlayAlwaysExpanded
  });

  const overlayHintVariant = isOverlayVariant && !isOverlayAlwaysExpanded ? 'B' : undefined;
  useOverlayHintAnimation(rootRef, '.str-enhanced-info-wrapper', overlayHintVariant);

  return (
    <div
      ref={rootRef}
      className={clsx('str-adunit', 'str-template', `str-${creativeAction}`, className, {
        'str-adunit-overlay': isOverlayVariant
      })}
    >
      {children}
      <EnhancedTemplateContent isOpen={isOverlayAlwaysExpanded} onEnhancementClick={onEnhancementClick} />
      {/* @ts-expect-error: stuff */}
      <Drawer creative={creative} network={network} />
    </div>
  );
};
