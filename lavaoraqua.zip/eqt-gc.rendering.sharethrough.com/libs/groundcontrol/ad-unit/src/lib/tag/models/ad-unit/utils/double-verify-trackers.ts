export const getDoubleVerifyTracker = (jsTrackers: string[]): string | null => {
  const dvTrackers = jsTrackers.filter((url) => url.indexOf('cdn.doubleverify.com') >= 0);

  return dvTrackers.length ? dvTrackers[0] : null;
};
