import { FRENCH_DOMAINS } from '@web-rendering/groundcontrol-butler-helpers';
import AdChoiceIcon from '../../../../assets/icons/adchoice.png';
import styles from './opt-out-icon.module.scss';
import type { OptOutIconProps } from './types';
import { useConfiguration } from '@web-rendering/groundcontrol-core';

const getOptOutUrl = (domain: string | undefined, config: { default: string; french: string | undefined }): string => {
  if (!domain || !config.french) return config.default;

  return FRENCH_DOMAINS.some((frenchDomain) => domain.match(frenchDomain)) ? config.french : config.default;
};

const GenericIcon = () => (
  <svg
    fill="#888888"
    xmlns="http://www.w3.org/2000/svg"
    width="24"
    height="24"
    viewBox="0 0 24 24"
    className={`str-opt-out-icon ${styles['opt-out-icon-equativ']}`}
  >
    <path fill="none" d="M0 0h24v24H0V0z" />
    <path d="M11 7h2v2h-2zm0 4h2v6h-2zm1-9C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8z" />
  </svg>
);

const BrandedIcon = () => (
  <span
    className={`str-opt-out-icon ${styles['opt-out-icon']}`}
    style={{ backgroundImage: `url(${AdChoiceIcon})` }}
  ></span>
);

export const OptOutIcon = (props: OptOutIconProps) => {
  const configuration = useConfiguration();
  if (!configuration || props.creative.behaviors?.includes('shouldRemoveAdchoicesLogo')) {
    return null;
  }

  const optOutUrl = getOptOutUrl(props.network.domain, configuration.optOutIconConfig);
  const IconToRender = GC_INSTANCE_NAME === 'equativ' ? GenericIcon : BrandedIcon;

  return (
    <a
      onClick={(e) => e.stopPropagation()}
      href={optOutUrl}
      target="_blank"
      data-testid="opt-out-link"
      rel="noreferrer"
    >
      <div className={`str-opt-out-container ${styles['opt-out-container']} ${styles['relocate-ad-choices']}`}>
        <IconToRender />
        <span className={`str-opt-out-label ${styles['opt-out-label']}`}>AdChoices</span>
      </div>
    </a>
  );
};
