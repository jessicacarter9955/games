import { useRetailTracker } from '../../hooks/use-retail-tracker';
import type { ShoppableImage } from '@web-rendering/groundcontrol-ortb';
import type { FunctionComponent } from 'preact';
import { useAutoCycle } from '../../hooks/use-auto-cycle';
import './carousel.scss';

export const RetailNativeCarousel: FunctionComponent<{ images?: ShoppableImage[] }> = ({ images = [] }) => {
  const trackerService = useRetailTracker();
  const { activeIndex, goTo, goNext, goPrev } = useAutoCycle(images.length);

  if (images.length === 0) return null;

  const totalSlides = images.length;
  const prevIndex = (activeIndex - 1 + totalSlides) % totalSlides;
  const nextIndex = (activeIndex + 1) % totalSlides;

  const handleDotClick = (event: MouseEvent, index: number) => {
    event.stopPropagation();
    trackerService?.trackShoppableCarouselArrowClick();
    goTo(index);
  };

  const handlePrevClick = (event: MouseEvent) => {
    event.stopPropagation();
    trackerService?.trackShoppableCarouselArrowClick();
    goPrev();
  };

  const handleNextClick = (event: MouseEvent) => {
    event.stopPropagation();
    trackerService?.trackShoppableCarouselArrowClick();
    goNext();
  };

  return (
    <div className="str-retail-carousel">
      <div className="str-retail-carousel-track">
        {totalSlides > 1 && <CarouselSlide image={images[prevIndex]} position="prev" onClick={handlePrevClick} />}
        <CarouselSlide image={images[activeIndex]} position="active" />
        {totalSlides > 1 && <CarouselSlide image={images[nextIndex]} position="next" onClick={handleNextClick} />}
      </div>
      {totalSlides > 1 && (
        <div className="str-retail-carousel-dots">
          {images.map((_, index) => (
            <button
              key={index}
              className={`str-retail-carousel-dot${index === activeIndex ? ' active' : ''}`}
              onClick={(event: MouseEvent) => handleDotClick(event, index)}
            />
          ))}
        </div>
      )}
    </div>
  );
};

interface CarouselSlideProps {
  image: ShoppableImage;
  position: 'prev' | 'active' | 'next';
  onClick?: (event: MouseEvent) => void;
}

const CarouselSlide: FunctionComponent<CarouselSlideProps> = ({ image, position, onClick }) => (
  <div className={`str-retail-carousel-slide ${position}`} onClick={onClick}>
    <img src={image.url} alt="" className="str-retail-carousel-img" />
  </div>
);
