import { useErrorHandler, useLifecycleScope, usePayload, useTrackerService } from '@web-rendering/groundcontrol-core';
import { CreativeType, isAmazonNativePartner } from '@web-rendering/groundcontrol-shared-types';
import { reportError } from '@web-rendering/groundcontrol-monitoring';
import { nativeAssets } from '@web-rendering/groundcontrol-ortb';
import type { JSX } from 'preact';
import {
  AmazonNative,
  Banner,
  Clickout,
  RetailShoppableCarousel,
  RetailShoppableSingleProduct,
  RetailShoppableSingleProductCarousel
} from '../../tag/models/ad-experiences/ad-experience';
import { NativeOutstream } from '../../tag/models/ad-experiences/native-outstream/native-outstream.component';
import type { ReactAdUnitBaseProps } from '../../tag/models/ad-unit/ad-unit.base.component';
import ReactAdUnitBase from '../../tag/models/ad-unit/ad-unit.base.component';
import { useAttentionMetrics } from '../../tag/models/ad-unit/utils/hooks';

class ReactAdUnit extends ReactAdUnitBase {
  experienceToRender = (): JSX.Element | null => {
    const id = this.payload.id;
    const creative = this.payload.creative;

    try {
      const renderMap = {
        [CreativeType.Banner]: () => <Banner adserverRequestId={id} />,
        [CreativeType.Outstream]: () => {
          return <NativeOutstream adserverRequestId={id} />;
        },
        [CreativeType.Native]: () => {
          if (isAmazonNativePartner(creative.partnerId)) {
            return <AmazonNative adserverRequestId={id} />;
          }

          const format = nativeAssets.value?.shoppable?.format;
          if (format === 'single_product') return <RetailShoppableSingleProduct adserverRequestId={id} />;
          if (format === 'single_product_carousel')
            return <RetailShoppableSingleProductCarousel adserverRequestId={id} />;
          if (format === 'multi_product_carousel') return <RetailShoppableCarousel adserverRequestId={id} />;

          return <Clickout adserverRequestId={id} />;
        }
      };

      const creativeType = creative.type;
      const renderFn = renderMap[creativeType];

      if (!renderFn) {
        throw new Error(`creative type ${creativeType} does not match any known types`);
      }

      return renderFn();
    } catch (error) {
      reportError(error, {
        scope: this.lifecycleScope,
        context: 'ad-unit/creative-render-error',
        adserverRequestId: this.payload.id
      });

      console.error('Failed to render creative, falling back to Clickout', error);

      // Fallback to Clickout
      return <Clickout adserverRequestId={this.payload.id} />;
    }
  };
}

export default function AdUnitComponent(props: ReactAdUnitBaseProps) {
  const payloadContext = usePayload();
  const trackerService = useTrackerService();
  const [error] = useErrorHandler();
  const scope = useLifecycleScope();

  const shouldUseAttentionMetrics = true;
  const { containerRef } = useAttentionMetrics({
    trackerService: trackerService || undefined,
    enabled: shouldUseAttentionMetrics
  });

  if (!payloadContext || error) {
    const options = { scope, adserverRequestId: props.id };

    if (!payloadContext) reportError('No payload found', options);
    if (error) reportError(error, options);

    return null;
  }

  return <ReactAdUnit {...props} payload={payloadContext} containerRef={containerRef} />;
}
