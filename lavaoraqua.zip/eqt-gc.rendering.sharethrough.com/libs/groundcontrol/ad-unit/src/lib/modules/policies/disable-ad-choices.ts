import type { Creative } from '@web-rendering/groundcontrol-core';
import { RuleEngine } from '../../modules/rule-engine';
import { NO_DRAWER_BY_CREATIVE_KEY, NO_DRAWER_BY_SEAT_ID_SOURCE_ID } from './data';

const disableAdChoicesPolicy = new RuleEngine<[Creative]>();

disableAdChoicesPolicy.addRule({
  evaluate: (creative) => {
    for (const { sourceIds, seatIds } of NO_DRAWER_BY_SEAT_ID_SOURCE_ID) {
      if (sourceIds.includes(creative.partnerId) && creative.seatId && seatIds.includes(creative.seatId)) {
        return true;
      }
    }

    return false;
  }
});

disableAdChoicesPolicy.addRule({
  evaluate: (creative) => {
    if (NO_DRAWER_BY_CREATIVE_KEY.includes(creative.creativeId)) return true;
    return false;
  }
});

export const shouldDisableAdChoices = (creative: Creative) => {
  return disableAdChoicesPolicy.evaluate(creative);
};
