export default [
  {
    seatIds: ['1456', '5038', '3889'],
    sourceIds: ['5b286190338513af73f09c28']
  },
  // Yahoo
  {
    seatIds: ['4019'],
    sourceIds: [
      'n96oYXGCuPykdLqwSM5NUEVp',
      'WSr8YpQigv2XmTC9a4wEFtGB',
      'gcTfVrFXSws6HptieUaGhjCx',
      'gfrnFTBHKayiVeRoMX4QS7cP',
      'BVbSRuzbUWjBEF6bQrmLHKkX',
      'CoMLTJeWvGbEAymUxBat9rRZ'
    ]
  },
  // Deepintent
  {
    seatIds: [
      '10046',
      '10736',
      '11082',
      '10877',
      '11029',
      '10638',
      '10369',
      '11500',
      '10865',
      '11507',
      '11506',
      '11505',
      '10793',
      '11829',
      '11830',
      '11831',
      '11832',
      '11834',
      '11835',
      '11833'
    ],
    sourceIds: ['4rQWDMHEFSdfRbtp7Kei6UsB', 'eyHpF9vNhiWXJC5Zrw7nbfRE']
  },
  // Pulsepoint
  {
    seatIds: ['561971'],
    sourceIds: ['790d3e0174b12a86f1cbebf4', '4EDrwPqGiHXchxbaymLBZovJ']
  }
];
