import type { RefObject } from 'preact';

export interface CreatePercentageObserverProps {
  element: HTMLElement;
  inViewPercentage: number;
  outOfViewPercentage: number;
  inViewCallback?: () => void;
  outOfViewCallback?: () => void;
}

export function createPercentageObserver({
  inViewPercentage,
  outOfViewPercentage,
  inViewCallback,
  outOfViewCallback
}: CreatePercentageObserverProps): IntersectionObserver | null {
  // iOS in-app WebViews rendering the creative into an about:srcdoc iframe expose no
  // IntersectionObserver; skip construction so callers no-op instead of throwing and
  // breaking the whole render.
  if (typeof IntersectionObserver === 'undefined') return null;

  const observerCallback = (entries: IntersectionObserverEntry[], _observer: IntersectionObserver) => {
    const [entry] = entries;

    if (inViewCallback && entry.intersectionRatio >= inViewPercentage) {
      inViewCallback();
    }

    if (outOfViewCallback && entry.intersectionRatio <= outOfViewPercentage) {
      outOfViewCallback();
    }
  };

  return new IntersectionObserver(observerCallback, {
    threshold: [outOfViewPercentage, inViewPercentage]
  });
}

export interface CreatePixelObserverProps {
  element: HTMLElement;
  timeoutIdRef: RefObject<number | undefined>;
  inViewPixels: number;
  outOfViewPixels: number;
  inViewTime?: number;
  inViewCallback?: () => void;
  outOfViewCallback?: () => void;
}

export function pixelObserverCallback(
  entries: IntersectionObserverEntry[],
  _observer: IntersectionObserver,
  timeoutIdRef: RefObject<number | undefined>,
  inViewPixels: number,
  outOfViewPixels: number,
  inViewTime: number,
  inViewCallback?: () => void,
  outOfViewCallback?: () => void
) {
  entries.forEach((entry) => {
    const { width, height } = entry.boundingClientRect;
    const { width: intersectionWidth, height: intersectionHeight } = entry.intersectionRect;
    const visibleWidth = Math.min(width, intersectionWidth);
    const visibleHeight = Math.min(height, intersectionHeight);
    const visiblePixels = visibleWidth * visibleHeight;
    if (visiblePixels >= inViewPixels && !document.hidden) {
      timeoutIdRef.current =
        inViewCallback &&
        window.setTimeout(() => {
          inViewCallback();
        }, inViewTime);
    } else {
      if (timeoutIdRef.current) {
        window.clearTimeout(timeoutIdRef.current);
        timeoutIdRef.current = undefined;
      }
    }

    if (outOfViewCallback && visiblePixels <= outOfViewPixels) {
      outOfViewCallback();
    }
  });
}

export function createPixelObserver({
  element,
  timeoutIdRef,
  inViewPixels,
  outOfViewPixels,
  inViewTime = 1000,
  inViewCallback,
  outOfViewCallback
}: CreatePixelObserverProps): IntersectionObserver | null {
  // Same about:srcdoc-iframe environments described in createPercentageObserver.
  if (typeof IntersectionObserver === 'undefined') return null;

  const callback = (entries: IntersectionObserverEntry[], observer: IntersectionObserver) =>
    pixelObserverCallback(
      entries,
      observer,
      timeoutIdRef,
      inViewPixels,
      outOfViewPixels,
      inViewTime,
      inViewCallback,
      outOfViewCallback
    );

  let thresholdValues: number[];
  if (element.clientHeight > 0) {
    thresholdValues = [outOfViewPixels / element.clientHeight, inViewPixels / element.clientHeight];
  } else {
    thresholdValues = [0, 1];
  }

  return new IntersectionObserver(callback, {
    threshold: thresholdValues
  });
}

export function registerPercentageObserver(props: CreatePercentageObserverProps) {
  const observer = createPercentageObserver(props);
  observer?.observe(props.element);

  return observer;
}

export function registerPixelObserver(props: CreatePixelObserverProps) {
  const observer = createPixelObserver(props);
  observer?.observe(props.element);

  return observer;
}

export function registerObserver(props: CreatePercentageObserverProps | CreatePixelObserverProps) {
  if ('inViewPercentage' in props || 'outOfViewPercentage' in props)
    return registerPercentageObserver(props as CreatePercentageObserverProps);

  if ('inViewPixels' in props || 'outOfViewPixels' in props)
    return registerPixelObserver(props as CreatePixelObserverProps);

  throw new Error('inViewPercentage/outOfViewPercentage or inViewPixels/outOfViewPixels must be provided');
}
