import type { OutstreamCaptionsPayload } from '@sharethrough/groundcontrol-enhancement-flush';
import { useLifecycleScope, usePayload } from '@web-rendering/groundcontrol-core';
import { reportError } from '@web-rendering/groundcontrol-monitoring';
import { LifecycleStage } from '@web-rendering/groundcontrol-shared-types/lifecycle/lifecycle-stage';
import type { FunctionComponent } from 'preact';
import { createContext } from 'preact';
import { useEffect, useMemo, useState } from 'preact/hooks';
import { useEnhancement } from '../../../tag/models/ad-experiences/hooks';
import { loadCaptions } from './load-captions';
import type { JSONSubtitle } from './types';
import { bindStage } from '@web-rendering/groundcontrol-shared-types/lifecycle/lifecycle';

interface CaptionsProviderState {
  currentTime: number;
  currentSubtitle: JSONSubtitle | null;
  srt: JSONSubtitle[];
  innerCreativeId: string;
  videoElement?: HTMLVideoElement;
}

interface CaptionsContextProps extends CaptionsProviderState {
  setInnerCreativeId: (value: string) => void;
  setCurrentTime: (value: number) => void;
  setVideoElement?: (value: HTMLVideoElement) => void;
}

export const CaptionsContext = createContext<CaptionsContextProps | null>(null);

export const CaptionsProvider: FunctionComponent = ({ children }) => {
  const { enhancement } = useEnhancement<OutstreamCaptionsPayload>();
  const payload = usePayload();
  const scope = useLifecycleScope();
  // Captions are enhancement work, but this provider wraps the whole ad unit, outside the enhancement subtree.
  const enhancementScope = useMemo(() => bindStage(scope, LifecycleStage.Enhancement), [scope]);

  const [captionsState, setCaptionsState] = useState<CaptionsProviderState>({
    currentTime: 0,
    currentSubtitle: null,
    srt: [],
    innerCreativeId: '',
    videoElement: undefined
  });

  useEffect(() => {
    if (payload?.creative.type !== 'outstream') return;

    if (!enhancement?.payload?.srt) return;

    if (captionsState.innerCreativeId) {
      const srt = enhancement?.payload.srt;

      loadCaptions(srt, captionsState.innerCreativeId)
        .then((srt) => {
          if (!srt) return;
          setCaptionsState((prevState) => ({ ...prevState, srt }));
        })
        .catch((e) => {
          reportError(e, {
            scope: enhancementScope,
            adserverRequestId: payload?.id
          });
        });
    }
  }, [enhancement, enhancement?.type, captionsState.innerCreativeId, payload]);

  const newSubtitle = useMemo(() => {
    if (payload?.creative.type !== 'outstream') return null;

    if (!captionsState.srt) return null;
    if (captionsState.srt.length === 0) return null;

    return captionsState.srt.find((subtitle) => {
      return captionsState.currentTime >= subtitle.start && captionsState.currentTime <= subtitle.end;
    });
  }, [captionsState.currentTime, captionsState.srt]);

  useEffect(() => {
    if (newSubtitle === captionsState.currentSubtitle) return;
    if (newSubtitle?.text !== captionsState.currentSubtitle?.text) {
      setCaptionsState((prevState) => ({ ...prevState, currentSubtitle: newSubtitle ?? null }));
    }
  }, [newSubtitle]);

  const setInnerCreativeId = (value: string) => {
    setCaptionsState((prevState) => ({ ...prevState, innerCreativeId: value }));
  };

  const setCurrentTime = (value: number) => {
    // only update state if full second has passed
    if (captionsState.srt.length === 0) return;
    setCaptionsState((prevState) => ({ ...prevState, currentTime: value }));
  };

  const setVideoElement = (videoElement: HTMLVideoElement) => {
    setCaptionsState((prevState) => ({ ...prevState, videoElement }));
  };

  const contextValue = {
    ...captionsState,
    setInnerCreativeId,
    setCurrentTime,
    setVideoElement
  };

  return <CaptionsContext.Provider value={contextValue}>{children}</CaptionsContext.Provider>;
};
