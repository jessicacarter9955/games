import type { ButlerResponse } from '@web-rendering/groundcontrol-shared-types';
import type { FunctionComponent } from 'preact';
import { createContext } from 'preact';

export const ButlerContext = createContext<ButlerResponse | null>(null);

interface ButlerProviderProps {
  butlerResponse?: ButlerResponse;
}

export const ButlerProvider: FunctionComponent<ButlerProviderProps> = ({ butlerResponse, children }) => {
  return <ButlerContext.Provider value={butlerResponse ?? null}>{children}</ButlerContext.Provider>;
};
