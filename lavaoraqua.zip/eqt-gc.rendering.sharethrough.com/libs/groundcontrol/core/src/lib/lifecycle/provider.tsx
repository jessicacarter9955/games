import { bindStage, Lifecycle } from '@web-rendering/groundcontrol-shared-types/lifecycle/lifecycle';
import { createContext } from 'preact';
import { useContext, useMemo } from 'preact/hooks';
import type { AdIdentifiers, LifecycleScope } from '@web-rendering/groundcontrol-shared-types/lifecycle/lifecycle';
import type { FunctionComponent } from 'preact';
import type { Payload } from '../payload/types';

export const LifecycleScopeContext = createContext<LifecycleScope | null>(null);

export const LifecycleScopeProvider: FunctionComponent<{ scope: LifecycleScope }> = ({ scope, children }) => (
  <LifecycleScopeContext.Provider value={scope}>{children}</LifecycleScopeContext.Provider>
);

/**
 * The scope a component reports its errors in. It keeps the stage that was current when the component
 * mounted, so an error raised later (an async fetch, a re-render after the impression) is still
 * reported in the stage whose work mounted it. Outside any lifecycle the stage is unknown.
 */
export const useLifecycleScope = (): LifecycleScope => {
  const scope = useContext(LifecycleScopeContext);

  return useMemo(() => bindStage(scope ?? new Lifecycle()), [scope]);
};

// Class components can't read a second context next to PayloadContext, so they look their ad's
// lifecycle up by payload id, the same way they look up the payload itself.
const adLifecycles = new Map<string, Lifecycle>();

export const registerAdLifecycle = (id: string, lifecycle: Lifecycle): void => {
  adLifecycles.set(id, lifecycle);
};

/**
 * The class-component counterpart of useLifecycleScope: call it once when the component is created,
 * so it keeps the stage that was current then.
 */
export const getAdLifecycleScope = (id: string | undefined): LifecycleScope =>
  bindStage((id ? adLifecycles.get(id) : undefined) ?? new Lifecycle());

export const getAdIdentifiers = (payload: Payload): AdIdentifiers => ({
  id: payload.id,
  partnerId: payload.creative.partnerId,
  networkId: payload.network.networkId,
  callerId: payload.network.callerId,
  creativeType: payload.creative.type
});
