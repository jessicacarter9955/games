import type { Payload } from '../payload/types';
import { Scenario } from './types';

/**
 * Checks whether the given scenario value matches the one SSB already resolved for this
 * payload (test 281's `GroundControlBehaviour` arm, forwarded verbatim as `payload.scenario`).
 * No criteria/volume concept here — the arm is resolved server-side, not drawn client-side.
 *
 * Accepts the full `payload.scenario` type rather than just `Scenario`, because SSB can also
 * forward a string arm (a StringValue test, as in test 619) and callers must still be able to
 * compare against one.
 *
 * @see docs/contracts/scenario.md
 *
 * @example
 * ```ts
 * if (isScenarioActive(payload, Scenario.GcMeasurement)) { ... }
 * ```
 */
export const isScenarioActive = (
  payload: Pick<Payload, 'scenario'> | null | undefined,
  targetScenario: NonNullable<Payload['scenario']>
): boolean => {
  return payload?.scenario != null && payload.scenario === targetScenario;
};

/**
 * Gates WR-2043's embedded GC measurement path: in-scope placements only
 * (`countImpressionOnePixel === true`), and only for the agreed measurement scenario —
 * every other value, including null, falls through to the external OnePixel script
 * (research.md Decision 1).
 */
export const shouldUseEmbeddedMeasurement = (
  payload: Pick<Payload, 'reporting' | 'scenario'> | null | undefined
): boolean => {
  return payload?.reporting?.countImpressionOnePixel === true && isScenarioActive(payload, Scenario.GcMeasurement);
};
