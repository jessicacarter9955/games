import type { IEnhancementService } from './service.interface';
import type { OptionalEnhancementComponent } from './types';

/**
 * Enhancement Service implementation
 *
 * Follows the same pattern as RenderService where the component is injected via constructor.
 * This enables build-specific enhancement bundling by only importing the needed enhancement
 * component in each app's main.ts entry point.
 *
 * @example
 * // For a weather enhancement build
 * import { Weather } from '@web-rendering/groundcontrol-ad-unit/tag/models/common/template/enhanced/content/weather/weather.component';
 * const enhancementService = new EnhancementService(Weather);
 *
 * @example
 * // For an unenhanced build
 * const enhancementService = new EnhancementService(null);
 */
export class EnhancementService implements IEnhancementService {
  /**
   * @param EnhancementComponent - The enhancement component to render, or null for unenhanced builds
   */
  private readonly EnhancementComponent: OptionalEnhancementComponent;
  constructor(EnhancementComponent: OptionalEnhancementComponent) {
    this.EnhancementComponent = EnhancementComponent;
  }

  /**
   * Returns the enhancement component that was injected via constructor
   * @returns The enhancement component, or null if this is an unenhanced build
   */
  getEnhancementComponent(): OptionalEnhancementComponent {
    return this.EnhancementComponent;
  }
}
