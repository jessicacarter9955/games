import type { GCEnhancementPayload } from '@sharethrough/groundcontrol-enhancement-flush';
import type { CreativeType, SupportedLanguage } from '@web-rendering/groundcontrol-shared-types';
import type { OrtbEventTrackers } from '@web-rendering/groundcontrol-ortb';
import type { Size } from '../common/types';

export enum NativeType {
  Clickout = 'clickout',
  Video = 'video'
}

interface CreativeBase<T, C> {
  content: C;
  type: T;
  creativeId: string;
  dealId?: string;
  partnerId: string;
  size: Size;
  language?: SupportedLanguage;
  behaviors?: string[];
  seatId?: string;
  trackers?: OrtbEventTrackers;
  jsTrackers?: string[];
  link: string;
  clicktrackers?: string[];
  assetsurl?: string;
}

export interface BannerCreative extends CreativeBase<CreativeType.Banner, string> {}
export interface OutstreamCreative extends CreativeBase<CreativeType.Outstream, string> {}
export interface NativeCreative extends CreativeBase<CreativeType.Native, Record<string, unknown>[]> {
  nativeType: `${NativeType}`;
  trackers: OrtbEventTrackers;
}

export type Creative = BannerCreative | OutstreamCreative | NativeCreative;

export type EnhancementPayload = GCEnhancementPayload['payload'];
