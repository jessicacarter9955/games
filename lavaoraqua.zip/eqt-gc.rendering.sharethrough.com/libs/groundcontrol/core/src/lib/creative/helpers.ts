import type { GCEnhancementPayload } from '@sharethrough/groundcontrol-enhancement-flush';
import { CreativeType } from '@web-rendering/groundcontrol-shared-types';
import { isSize } from '../common/helpers';
import type { ValidationResult } from '../common/types';
import type { EnhancementPayload } from './types';

export function isCreative(value: unknown): ValidationResult {
  if (!value || typeof value !== 'object') {
    return {
      valid: false,
      path: '',
      expected: 'object',
      received: typeof value
    };
  }

  const creative = value as Record<string, unknown>;

  // Check type
  if (!creative['type'] || !Object.values(CreativeType).includes(creative['type'] as CreativeType)) {
    return {
      valid: false,
      path: 'type',
      expected: Object.values(CreativeType).join(' | '),
      received: creative['type']
    };
  }

  // Check size
  const sizeResult = isSize(creative['size']);
  if (!sizeResult.valid) {
    return {
      valid: false,
      path: `size.${sizeResult.path}`,
      expected: sizeResult.expected,
      received: sizeResult.received
    };
  }

  // Check required fields
  const requiredFields = ['content', 'language', 'behaviors', 'partnerId', 'seatId', 'creativeId', 'trackers'];

  for (const field of requiredFields) {
    if (!creative[field]) {
      return {
        valid: false,
        path: field,
        expected: 'non-empty value',
        received: 'undefined or null'
      };
    }
  }

  return { valid: true };
}

export const isValidCreativeType = (type: string): type is CreativeType => {
  const creativeTypes = Object.values(CreativeType).map((type) => type.toString());
  return creativeTypes.includes(type);
};

export const parseEnhancementPayload = (
  payload: string | GCEnhancementPayload['payload'] | undefined
): EnhancementPayload | null => {
  if (!payload) return null;

  if (typeof payload === 'string') {
    try {
      return JSON.parse(payload);
    } catch {
      return null;
    }
  } else if (typeof payload === 'object') {
    return payload;
  }

  return null;
};

export const bannerIframeErrorListener = (event: ErrorEvent) => {
  const { message } = event;
  const SCRIPT_TERMINATION_ERROR_REGEX = /(script error\.|syntaxerror|unexpected token|invalid token|unterminated)/i;
  const matchesScriptTerminationError = SCRIPT_TERMINATION_ERROR_REGEX.test(message);

  if (matchesScriptTerminationError) {
    window.parent.postMessage(
      {
        eventType: 'iframeError',
        error: { message }
      },
      '*'
    );
  }
};
