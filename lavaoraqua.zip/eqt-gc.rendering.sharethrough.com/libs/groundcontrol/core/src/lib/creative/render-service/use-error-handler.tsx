import type { MonitoringOptions } from '@web-rendering/groundcontrol-monitoring';
import { reportError } from '@web-rendering/groundcontrol-monitoring';
import { useErrorBoundary } from 'preact/hooks';
import { useLifecycleScope } from '../../lifecycle/provider';
import { usePayload } from '../../payload/provider';

export const useErrorHandler = (message?: string) => {
  const payload = usePayload() ?? undefined;
  const enhancement = payload?.enhancement ?? null;
  const scope = useLifecycleScope();

  return useErrorBoundary((error) => {
    const options: MonitoringOptions = {
      scope,
      payload,
      enhancement
    };

    if (message && error instanceof Error) {
      error.message = `${message}: ${error.message}`;
    }

    reportError(error, options);
  });
};
