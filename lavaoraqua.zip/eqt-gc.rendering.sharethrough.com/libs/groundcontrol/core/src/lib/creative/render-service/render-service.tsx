import type { ButlerResponse } from '@web-rendering/groundcontrol-shared-types';
import { reportError } from '@web-rendering/groundcontrol-monitoring';
import { render, type ComponentChildren, type JSX } from 'preact';
import type { LifecycleScope } from '@web-rendering/groundcontrol-shared-types/lifecycle/lifecycle';
import type { Payload } from '../../payload';
import type { ICreativeRenderService } from './render-service.interface';
import { useErrorHandler } from './use-error-handler';
import type { ProviderWithProps } from './types';

// Utility to compose providers dynamically
type AnyProviderWithProps = ProviderWithProps<object>;

function composeProviders<T extends AnyProviderWithProps[]>(
  providers: T,
  children: ComponentChildren
): ComponentChildren {
  return providers.reduceRight((acc, [Provider, props]) => <Provider {...(props as object)}>{acc}</Provider>, children);
}

export class RenderService implements ICreativeRenderService {
  constructor(private readonly ChildComponent: JSX.ElementType | undefined) {
    this.ChildComponent = ChildComponent;
  }

  render<T extends AnyProviderWithProps[]>(
    response: ButlerResponse,
    payload: Payload,
    placeholder: Element,
    providers: T,
    AdUnitComponent: JSX.ElementType,
    scope: LifecycleScope
  ): void {
    const id = payload.id;

    // Create a wrapper component that uses the error handler
    const ErrorBoundaryWrapper = () => {
      const [error] = useErrorHandler(`Error in AdUnitComponent with id: ${id}`);
      if (error) {
        console.log(' wrappedAdunit', error);
        return null;
      }
      return <AdUnitComponent id={id} response={response} childComponent={this.ChildComponent} />;
    };

    const component = composeProviders(providers, <ErrorBoundaryWrapper />);

    const parent = placeholder.parentElement;
    if (parent) {
      // Publishers target this container by the id/styles their tag set — render
      // inside it, never replace or mutate it.
      // Boot re-selects unflagged slots; without the flag a double boot double-renders.
      placeholder.setAttribute('data-str-visited-flag', 'true');
      // Preact won't clear the slot's fallback content itself.
      while (placeholder.firstChild) {
        placeholder.removeChild(placeholder.firstChild);
      }
      render(component, placeholder);
    } else {
      reportError(new Error('RenderService: placeholder detached at render time'), {
        scope,
        function: 'core/render-service:render',
        payloadId: id,
        bundleId: payload.network.bundleId,
        readyState: document.readyState
      });
    }
  }
}
