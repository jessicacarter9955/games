import type { FunctionComponent } from 'preact';
import { createContext } from 'preact';
import { useContext } from 'preact/hooks';
import type { ConfigurationService } from './service';

export const ConfigurationContext = createContext<ConfigurationService | null>(null);

interface ConfigurationProviderProps {
  configuration: ConfigurationService;
}

export const ConfigurationProvider: FunctionComponent<ConfigurationProviderProps> = ({ configuration, children }) => {
  return <ConfigurationContext.Provider value={configuration}>{children}</ConfigurationContext.Provider>;
};

export const useConfiguration = () => {
  return useContext(ConfigurationContext);
};
