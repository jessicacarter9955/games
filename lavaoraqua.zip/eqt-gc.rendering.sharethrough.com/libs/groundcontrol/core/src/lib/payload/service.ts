import { setPayload } from '@web-rendering/groundcontrol-store';
import { isPayload } from './helpers';
import type { LifecycleScope } from '@web-rendering/groundcontrol-shared-types/lifecycle/lifecycle';
import type { Payload } from './types';

export abstract class PayloadService {
  abstract parse(rawPayload: unknown, scope: LifecycleScope): Payload;

  validate(payload: unknown): payload is Payload {
    const result = isPayload(payload);
    if (!result.valid) {
      console.error('Validation failed:', result);
    }

    return result.valid;
  }

  initialize(rawPayload: unknown, scope: LifecycleScope) {
    const parsedPayload = this.parse(rawPayload, scope);

    setPayload(parsedPayload);

    return parsedPayload;
  }
}
