import type { FunctionComponent } from 'preact';
import { createContext } from 'preact';
import { useContext } from 'preact/hooks';
import type { Creative } from '../creative';
import { CreativeType } from '@web-rendering/groundcontrol-shared-types';
import type { Payload } from './types';

type WithGetButlerAction<T> = T & {
  getButlerAction: () => string;
};

export type PayloadContextType = WithGetButlerAction<Payload>;

export const getButlerAction = (creative: Creative) => {
  return creative ? convertCreativeTypeToAction(creative) : '';
};

const convertCreativeTypeToAction = ({ nativeType, type }: { nativeType?: string; type: CreativeType }) => {
  if (type === CreativeType.Native && nativeType) return nativeType;
  if (type === CreativeType.Outstream) return 'native-outstream';
  return type;
};

export const PayloadContext = createContext<PayloadContextType | null>(null);

export const PayloadProvider: FunctionComponent<{ payload: Payload }> = ({ payload, children }) => {
  const context = {
    ...payload,
    getButlerAction: () => getButlerAction(payload.creative)
  };

  return <PayloadContext.Provider value={context}>{children}</PayloadContext.Provider>;
};

export const usePayload = () => {
  return useContext(PayloadContext);
};
