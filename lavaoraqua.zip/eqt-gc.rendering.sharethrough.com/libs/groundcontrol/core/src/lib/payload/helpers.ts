import { GCEnhancementType } from '@sharethrough/groundcontrol-enhancement-flush';
import type { Creative } from '../creative/types';
import type { EnhancementType } from '@web-rendering/groundcontrol-shared-types';
import type { ValidationResult } from '../common/types';
import { isCreative } from '../creative/helpers';
import { isNetwork } from '../network/helpers';
import type { Payload } from './types';

export function validatePayload(payload: unknown): payload is Payload {
  const result = isPayload(payload);
  return result.valid;
}

export function isPayload(value: unknown): ValidationResult {
  if (!value || typeof value !== 'object') {
    return {
      valid: false,
      path: '',
      expected: 'object',
      received: typeof value
    };
  }

  const payload = value as Record<string, unknown>;

  // Check required fields
  if (!payload['id'] || typeof payload['id'] !== 'string') {
    return {
      valid: false,
      path: 'id',
      expected: 'string',
      received: typeof payload['id']
    };
  }

  // Validate creative
  const creativeResult = isCreative(payload['creative']);
  if (!creativeResult.valid) {
    return {
      ...creativeResult,
      path: `creative.${creativeResult.path}`
    };
  }

  // Validate network
  const networkResult = isNetwork(payload['network']);
  if (!networkResult.valid) {
    return {
      ...networkResult,
      path: `network.${networkResult.path}`
    };
  }

  return { valid: true };
}

// Known callers with restricted iframe
const RESTRICTED_IFRAME_CALLER_IDS = [
  '30', // Outbrain
  'vviA7jzZ', // Outbrain
  '32', // SmileWanted
  '53', // Limpid
  '106', // Vidazoo
  '136' // Playdigo
];

export function isRestrictedIframeCaller(callerId: string | undefined): boolean {
  if (!callerId) return false;

  return RESTRICTED_IFRAME_CALLER_IDS.includes(callerId);
}

/**
 * Check if the caller is among the list of callers that have most of their inventory responsive
 * It means that the caller is responsible for making the ad responsive
 * and we disable our responsive template
 * @param callerId
 * @returns boolean
 */
export function hasRichMediaInventory(callerId: string | undefined): boolean {
  if (!callerId) return false;

  const callerIds = ['7', '2TwkgUpM'];

  return callerIds.includes(callerId);
}

// Deliberately a single hardcoded ratio (design decision 2026-08-24, WR-2159) — no per-enhancement-type
// map, no payload field. Shared here (not in ad-unit) so eqt's macro substitution can use the exact same
// ratio without ad-unit needing to depend on eqt, or vice versa. Two other places hardcode this same
// value directly and must stay in sync if it ever changes: the CSS pin in responsive.scss
// (`flex: 0 0 75%` on .str-same-size-pinned, SCSS can't import a TS constant) and the generic
// `Math.min(0.75, this.scale)` fallback in banner.component.tsx's scaleFactors getter (the WR-2159
// same-size branch there pins to NATIVE — 1.0, this.scale — not to this ratio). eqt's
// substitute-template-macros.ts applies this ratio to height only, since every combo in
// SAME_SIZE_PIN_ALLOWED_COMBOS below happens to pin height — check that assumption too if the
// allowlist ever grows to include a row-direction combo.
export const SAME_SIZE_ENHANCED_SCALE = 0.75;

// FR3 (CE-178209542) lists exactly 3 same-size pairs among the 8 restored combinations; the other
// 5 are size-multiplexed and never reach the same-size pin. FR9 ramps eligibility one combination
// at a time over several weeks, so this allowlist is a second copy of matrix state and must be
// updated in lockstep with the ramp — it does not derive eligibility generically from "any equal
// size" the way isSameSizeEnhancedPin/substituteTemplateMacros did before this list existed.
const SAME_SIZE_PIN_ALLOWED_COMBOS: ReadonlySet<string> = new Set(['300x250', '300x600', '160x600']);

export const isSameSizePinAllowedCombo = (width: number, height: number): boolean =>
  SAME_SIZE_PIN_ALLOWED_COMBOS.has(`${width}x${height}`);

export const SOFIA_PULSE_ENHANCEMENT_TYPES: Set<string> = new Set([
  GCEnhancementType.BannerSofiaPulseSportsHeadlines,
  GCEnhancementType.BannerSofiaPulseQuiz,
  GCEnhancementType.BannerSofiaPulseBettingOdds,
  GCEnhancementType.BannerSofiaPulseStockTicker
]);

export const isSofiaPulseCreative = (
  creativeContent: Creative['content'] | undefined,
  enhancementType?: EnhancementType
): boolean => {
  if (enhancementType && SOFIA_PULSE_ENHANCEMENT_TYPES.has(enhancementType)) {
    return true;
  }
  if (!creativeContent) return false;
  return creativeContent.toString().includes('.sofiapulse.com');
};

export const getShowClickBlockerValue = (
  callerId: string | undefined,
  creativeContent: Creative['content'] | undefined,
  disableClickCounting?: boolean,
  enhancementType?: EnhancementType
) => {
  if (disableClickCounting) return false;

  return !isSofiaPulseCreative(creativeContent, enhancementType) && !hasRichMediaInventory(callerId);
};
