/* eslint-disable @typescript-eslint/no-explicit-any */
import type { ValidationResult } from './types';

// Host discovery lives in the measurement lib so the display tracker can reach it without the core
// barrel (WR-2196); re-exported so existing core callers are unchanged.
export { getWindowParentAttribute } from '@web-rendering/groundcontrol-measurement/lib/discovery/window-parent-attribute';

export function isSize(value: unknown): ValidationResult {
  if (!value || typeof value !== 'object') {
    return {
      valid: false,
      path: '',
      expected: 'object',
      received: typeof value
    };
  }

  const size = value as Record<string, unknown>;

  // Check width
  if (typeof size['width'] !== 'number' || size['width'] <= 0) {
    return {
      valid: false,
      path: 'width',
      expected: 'positive number',
      received: typeof size['width']
    };
  }

  // Check height
  if (typeof size['height'] !== 'number' || size['height'] <= 0) {
    return {
      valid: false,
      path: 'height',
      expected: 'positive number',
      received: typeof size['height']
    };
  }

  return { valid: true };
}

export function getNestedAttribute(obj: unknown, attributeName: string, maxDepth = 5) {
  function search(obj: any, depth: number): any {
    if (depth > maxDepth) return undefined;
    if (obj === null || obj === undefined) return undefined;

    try {
      // Check current level
      if (Object.prototype.hasOwnProperty.call(obj, attributeName)) {
        return obj[attributeName];
      }

      // Search nested objects
      if (typeof obj === 'object') {
        // Safely get keys - some cross-origin objects might throw here
        let keys: string[];
        try {
          keys = Object.keys(obj);
        } catch (e) {
          return undefined;
        }

        for (const key of keys) {
          try {
            const value = obj[key];
            const result: any = search(value, depth + 1);
            if (result !== undefined) {
              return result;
            }
          } catch (e) {
            // Skip properties that can't be accessed due to cross-origin restrictions
            continue;
          }
        }
      }
    } catch (e) {
      // If we hit any security/cross-origin errors, return undefined
      return undefined;
    }
    return undefined;
  }

  try {
    return search(obj, 0);
  } catch (e) {
    return undefined;
  }
}

// Safe version with default value
export function getNestedAttributeSafe(
  obj: unknown,
  attributeName: string,
  defaultValue: string | number | boolean | undefined = undefined
) {
  const result = getNestedAttribute(obj, attributeName);
  return result !== undefined ? result : defaultValue;
}
