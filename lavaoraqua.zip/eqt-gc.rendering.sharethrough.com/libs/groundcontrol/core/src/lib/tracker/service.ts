import { signal } from '@preact/signals';
import type { AttentionMetricsPayload } from '@web-rendering/groundcontrol-beacon';
import type { OrtbEventType } from '@web-rendering/groundcontrol-ortb';
import type { ValidEnhancementType } from '@web-rendering/groundcontrol-shared-types';
import type { DurationKey, QuartileKey } from './types';
import type { ClickExtractionResult } from '@sharethrough/groundcontrol-types';
import type { LifecycleScope } from '@web-rendering/groundcontrol-shared-types/lifecycle/lifecycle';

export abstract class TrackerService<T = null> {
  private _metadata: T;

  get metadata(): T {
    return this._metadata;
  }

  set metadata(metadata: T) {
    this._metadata = metadata;
  }

  mergeMetadata(newData: Partial<T>): void {
    this.metadata = {
      ...this.metadata,
      ...newData
    };
  }

  abstract trackImpression(
    placeholderEl: HTMLElement,
    scope: LifecycleScope,
    measureMode?: 'mraid' | 'omid' | 'onepx' | 'standard' | 'iabViewable'
  ): void;
  abstract trackImpressionReceived(): void;
  abstract trackVisibleImpression(placeholderEl: HTMLElement): void;
  abstract trackClick(element: HTMLElement | undefined): void;
  abstract trackViewableImpression(): void;
  abstract trackOrtbEvent(eventType: OrtbEventType, element: HTMLElement): void;
  abstract trackVideoStart(autoPlay: boolean): void; //Billable Event
  abstract trackVideoPlay(): void;
  abstract trackVideoQuartile(percentThreshold: QuartileKey): void;
  abstract trackVideoViewDuration(currentTime: number, muted: boolean): void;
  abstract trackVideoVolumeOn(currentTime: number): void;
  abstract trackExperiment(): void;
  abstract trackIsEnhanced(enhancementType?: ValidEnhancementType, innerCreativeId?: string, fallback?: boolean): void;
  abstract trackVpaidEnabled(vpaidEnabled: boolean): void;
  abstract trackClickthroughFound(found: boolean): void;
  abstract trackImaClick(): void;
  abstract trackJsTrackerFailedToLoad(sources: string): void;
  abstract trackVastError(error: number, scope: LifecycleScope): void;
  abstract trackVideoFailedToPlay(): void;
  abstract trackBannerRendered(clickable: boolean, clickableRule: string, disableAdChoices: boolean): void;
  abstract trackDoubleVerifyError(): void;
  abstract trackDoubleVerifyRender(): void;
  abstract trackDoubleVerifySuccess(): void;
  abstract trackDoubleVerifyFallback(): void;
  abstract trackSilentAutoPlayDuration(durationThreshold: DurationKey): void;
  abstract trackPixelVisible(): void;
  abstract trackUserShare(): void;
  abstract trackAutoplayVideoEngagement(currentTime: number): void;
  abstract trackGroundControlLoaded(metadata: GroundControlLoadedParams): void;
  abstract trackAttentionMetrics(payload: AttentionMetricsPayload): void;
  abstract trackEnhancedEngagementClick(): void;
  abstract trackEnhancedContentClick(): void;
  abstract trackHeavyAdIntervention(): void;
  abstract trackProductCardClick(productId?: string): void;
  abstract trackShoppableCarouselArrowClick(): void;
  abstract trackBannerClickable(extraction?: ClickExtractionResult, durationMs?: number): void;
  abstract trackRemoteHealthCheckFail(): void;
  abstract trackRemoteHealthCheckOk(): void;
  abstract trackRemoteInitialized(): void;
  abstract trackEnhancementLoadFailure(): void;
  abstract trackOverlayActive(): void;
  abstract trackFriendlyIframeEnv(): void;
  abstract getSasConfig(): SasConfig | undefined;
  abstract trackAmazonNativeImpression(): void;
  abstract trackDcoResolutionSuccess(): void;
  abstract trackDcoResolutionFailure(): void;
  abstract trackPublisherStylingRequested(): void;
  abstract trackPublisherStylingLoaded(): void;
}

export const trackerService = signal<TrackerService<Record<string, string | object>> | null>(null);

export type GroundControlLoadedParams = {
  env: 'eqt';
  trackerBaseUrl: string;
};

export type SasConfig = {
  mraidTrackingUrl: string;
  omidTrackingUrl: string;
  impressionTrackingUrl: string;
};
