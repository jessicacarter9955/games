import { signal } from '@preact/signals';

export const enhancementLoaded = signal(false);
