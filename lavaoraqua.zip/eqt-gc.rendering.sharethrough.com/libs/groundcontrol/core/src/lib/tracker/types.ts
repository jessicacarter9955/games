import type { TrackerEvent } from '@web-rendering/groundcontrol-shared-types';

export interface Tracker {
  event: `${TrackerEvent}`;
  url: string;
}

export interface Reporting {
  trackerBaseUrl: string | null;
  trackerImpressionUrl?: string | null;
  countImpressionOnePixel?: boolean | null;
  disableClickCounting?: boolean;
}

export enum QuartileKey {
  Q25 = '25',
  Q50 = '50',
  Q75 = '75',
  Q95 = '95'
}

export type DurationKey = 3 | 10 | 15 | 30;
