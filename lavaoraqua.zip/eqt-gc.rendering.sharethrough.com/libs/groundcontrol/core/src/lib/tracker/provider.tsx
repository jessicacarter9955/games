import { getPayload, ResponseStore } from '@web-rendering/groundcontrol-store';
import type { FunctionComponent } from 'preact';
import { createContext } from 'preact';
import { useContext } from 'preact/hooks';
import type { TrackerService } from './service';
import { trackerService as trackerServiceSignal } from './service';

export const TrackerServiceContext = createContext<TrackerService<unknown> | null>(null);

interface TrackerServiceProviderProps {
  id: string;
  trackerService: TrackerService<unknown>;
}

export const TrackerServiceProvider: FunctionComponent<TrackerServiceProviderProps> = ({
  trackerService,
  children,
  id
}) => {
  const butlerResponse = ResponseStore.getResponse(id);
  const payload = getPayload(id);

  trackerService.mergeMetadata({
    butlerResponse,
    payload
  });

  trackerServiceSignal.value?.mergeMetadata({
    butlerResponse,
    payload
  });

  return <TrackerServiceContext.Provider value={trackerService}>{children}</TrackerServiceContext.Provider>;
};

export const useTrackerService = () => {
  return useContext(TrackerServiceContext);
};
