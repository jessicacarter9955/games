import { isSize } from '../common/helpers';
import type { ValidationResult } from '../common/types';

export function isNetwork(value: unknown): ValidationResult {
  if (!value || typeof value !== 'object') {
    return {
      valid: false,
      path: '',
      expected: 'object',
      received: typeof value
    };
  }

  const network = value as Record<string, unknown>;

  // Check networkId
  if (!network['networkId'] || typeof network['networkId'] !== 'string') {
    return {
      valid: false,
      path: 'networkId',
      expected: 'string',
      received: typeof network['networkId']
    };
  }

  // Check size
  const sizeResult = isSize(network['size']);
  if (!sizeResult.valid) {
    return {
      ...sizeResult,
      path: `size.${sizeResult.path}`
    };
  }

  return { valid: true };
}
