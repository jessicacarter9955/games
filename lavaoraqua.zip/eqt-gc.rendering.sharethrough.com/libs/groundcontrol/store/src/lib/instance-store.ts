import { Store } from '@web-rendering/groundcontrol-store/store.class';
import { v4 } from 'uuid';

const store = new Store<{ gcid: string }>({ gcid: '' });

export const setGroundControlInstanceId = () => {
  const gcid = v4();
  store.setState({ gcid });
};

export const getGroundControlInstanceId = () => {
  return store.getState()['gcid'];
};
