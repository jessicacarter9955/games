import type { ButlerResponse, RawResponse } from '@web-rendering/groundcontrol-shared-types';

const _responses: { [arid: string]: ButlerResponse } = {};
const _rawResponses: { [arid: string]: RawResponse } = {};

export const ResponseStore = {
  setRawResponse(response: RawResponse) {
    const key = response.adserverRequestId;
    _rawResponses[key] = response;
  },

  getRawResponse(adserverRequestId: string) {
    return _rawResponses[adserverRequestId];
  },

  setResponse(response: ButlerResponse) {
    const key = response.adserverRequestId;
    _responses[key] = response;
  },

  getResponse(adserverRequestId: string) {
    return _responses[adserverRequestId];
  }
};
