import type { Payload } from '@web-rendering/groundcontrol-core';
import { Store } from './store.class';
import type { RawPayload } from '@web-rendering/groundcontrol-shared-types';

type PayloadStoreState = {
  [id: string]: Payload;
};

type RawPayloadStoreState = {
  [id: string]: RawPayload;
};

const rawStore = new Store<RawPayloadStoreState>({});

const store = new Store<PayloadStoreState>({});

export const setPayload = (payload: Payload) => {
  store.setState({
    ...store.getState(),
    [payload.id]: payload
  });
};

export const getPayload = (id: string): Payload => {
  return store.getState()[id];
};

let latestRawPayloadId: string | undefined;

export const setRawPayload = (payload: RawPayload) => {
  rawStore.setState({
    ...rawStore.getState(),
    [payload.id]: payload
  });
  latestRawPayloadId = payload.id;
};

export const getRawPayload = (id: string): RawPayload => {
  return rawStore.getState()[id];
};

export const getLatestRawPayload = (): RawPayload | undefined => {
  return latestRawPayloadId === undefined ? undefined : rawStore.getState()[latestRawPayloadId];
};
