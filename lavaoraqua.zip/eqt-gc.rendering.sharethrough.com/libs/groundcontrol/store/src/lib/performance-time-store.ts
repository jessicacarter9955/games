// Performance mark names
export const PERFORMANCE_MARKS = {
  // Fired in the rendering wrapper
  RENDERING_WRAPPER_SERVED: 'rendering-wrapper-served',

  // Fired in groundcontrol
  RENDER_START: 'groundcontrol-render-start',
  RENDER_END: 'groundcontrol-render-end',
  ENHANCEMENT_RENDER_END: 'groundcontrol-enhancement-render-end'
} as const;

// Performance measure names
export const PERFORMANCE_MEASURES = {
  BOOT_DURATION: 'boot-duration',
  RENDER_DURATION: 'render-duration',
  TOTAL_DURATION: 'total-duration'
} as const;

const isPerformanceSupported = () => {
  return (
    typeof window !== 'undefined' &&
    'performance' in window &&
    'mark' in window.performance &&
    'measure' in window.performance
  );
};

const getPerformanceContext = () => {
  if (!isPerformanceSupported()) {
    throw new Error('Performance API is not supported in this environment');
  }
  return window.performance;
};

const setMark = (markName: string) => {
  try {
    const perf = getPerformanceContext();
    perf.mark(markName);
  } catch (e) {
    // Do nothing
  }
};

const doesMarkExist = (perf: Performance, markName: string) => {
  return perf.getEntriesByName(markName, 'mark').length > 0;
};

export const setRenderStart = () => {
  setMark(PERFORMANCE_MARKS.RENDER_START);
};

export const setRenderEnd = () => {
  setMark(PERFORMANCE_MARKS.RENDER_END);
};

export const setEnhancementRenderEnd = () => {
  setMark(PERFORMANCE_MARKS.ENHANCEMENT_RENDER_END);
};

export const getBootDuration = () => {
  try {
    const perf = getPerformanceContext();

    if (!doesMarkExist(perf, PERFORMANCE_MARKS.RENDERING_WRAPPER_SERVED)) {
      throw new Error(`${PERFORMANCE_MARKS.RENDERING_WRAPPER_SERVED} mark not found`);
    }

    if (!doesMarkExist(perf, PERFORMANCE_MARKS.RENDER_START)) {
      throw new Error(`${PERFORMANCE_MARKS.RENDER_START} mark not found`);
    }

    const measure = perf.measure(
      PERFORMANCE_MEASURES.BOOT_DURATION,
      PERFORMANCE_MARKS.RENDERING_WRAPPER_SERVED,
      PERFORMANCE_MARKS.RENDER_START
    );
    return Math.round(measure.duration);
  } catch {
    return null;
  }
};

export const getRenderDuration = () => {
  try {
    const perf = getPerformanceContext();

    if (!doesMarkExist(perf, PERFORMANCE_MARKS.RENDER_START)) {
      throw new Error(`${PERFORMANCE_MARKS.RENDER_START} mark not found`);
    }

    if (!doesMarkExist(perf, PERFORMANCE_MARKS.RENDER_END)) {
      throw new Error(`${PERFORMANCE_MARKS.RENDER_END} mark not found`);
    }

    const measure = perf.measure(
      PERFORMANCE_MEASURES.RENDER_DURATION,
      PERFORMANCE_MARKS.RENDER_START,
      PERFORMANCE_MARKS.RENDER_END
    );

    return Math.round(measure.duration);
  } catch {
    return null;
  }
};

export const getEnhancementRenderDuration = () => {
  try {
    const perf = getPerformanceContext();

    if (!doesMarkExist(perf, PERFORMANCE_MARKS.RENDER_START)) {
      throw new Error(`${PERFORMANCE_MARKS.RENDER_START} mark not found`);
    }

    if (!doesMarkExist(perf, PERFORMANCE_MARKS.ENHANCEMENT_RENDER_END)) {
      throw new Error(`${PERFORMANCE_MARKS.ENHANCEMENT_RENDER_END} mark not found`);
    }

    const measure = perf.measure(
      PERFORMANCE_MEASURES.RENDER_DURATION,
      PERFORMANCE_MARKS.RENDER_START,
      PERFORMANCE_MARKS.ENHANCEMENT_RENDER_END
    );

    return Math.round(measure.duration);
  } catch {
    return null;
  }
};

export const getTotalDuration = () => {
  try {
    const perf = getPerformanceContext();

    if (!doesMarkExist(perf, PERFORMANCE_MARKS.RENDERING_WRAPPER_SERVED)) {
      throw new Error(`${PERFORMANCE_MARKS.RENDERING_WRAPPER_SERVED} mark not found`);
    }

    if (!doesMarkExist(perf, PERFORMANCE_MARKS.RENDER_END)) {
      throw new Error(`${PERFORMANCE_MARKS.RENDER_END} mark not found`);
    }

    const measure = perf.measure(
      PERFORMANCE_MEASURES.TOTAL_DURATION,
      PERFORMANCE_MARKS.RENDERING_WRAPPER_SERVED,
      PERFORMANCE_MARKS.ENHANCEMENT_RENDER_END
    );

    return Math.round(measure.duration);
  } catch {
    return null;
  }
};
