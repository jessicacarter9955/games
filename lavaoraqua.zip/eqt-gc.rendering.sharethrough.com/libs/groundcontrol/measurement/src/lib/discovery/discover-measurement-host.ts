import VerificationClient, { type VerificationEvent } from '../omid-verification-client/verification-client';
import { copyMraidToFrame } from './copy-mraid-to-frame';
import { getWindowParentAttribute } from './window-parent-attribute';

import type { Mraid, MeasurementHost, OmidClient } from '../types';

// Same parent-window search depth the legacy OnePixel script uses (see copyMraidToFrame). GC renders
// native in its own document, so mraid is usually on GC's own window; the parent walk is the
// in-app-iframe fallback.
export const MRAID_PARENT_SEARCH_DEPTH = 10;

/**
 * Joins the host's OMID measurement session when the OM SDK service is present, adapted to the slice
 * the core consumes (WR-2157). Wrapped defensively: a page with no OM service yields an unsupported
 * client (dropped), and any client-access throw is swallowed so OMID discovery can never break the
 * render or the MRAID path.
 *
 * The core reads only `event.data.adView.percentageInView` off the `geometryChange` event, which the
 * verification client already delivers inside `VerificationEvent.data`, so the adapter is a pass-through.
 */
function discoverOmid(): OmidClient | undefined {
  try {
    const client = new VerificationClient();
    if (!client.isSupported()) return undefined;

    return {
      isSupported: () => client.isSupported(),
      addEventListener: (event, handler) =>
        client.addEventListener<{ adView: { percentageInView: number } }>(
          event,
          (verificationEvent: VerificationEvent<{ adView: { percentageInView: number } }>) => handler(verificationEvent)
        )
    };
  } catch {
    return undefined;
  }
}

/**
 * Discovers the measurement sessions the host exposes to this window, as the `MeasurementHost` the core
 * consumes. Window discovery is the caller's job (the core only reads what it is given), so every
 * caller of `MeasurementCore` shares this one implementation: prefer `mraid` on this window, else walk
 * the parent hierarchy the way an in-app SDK exposes it, and join the OMID session too so `10013` fires
 * independently wherever an OM session is present.
 */
export function discoverMeasurementHost(): MeasurementHost {
  // In-app MRAID SDKs expose window.mraid whose methods call into a separate window.mraidbridge
  // native bridge (WR-2238). Copy both from the parent hierarchy before reading mraid below —
  // mraid alone leaves the bridge behind, so the first mraid call throws "mraidbridge is not
  // defined" and the MRAID impression never fires, taking the Counted Impression down with it
  // (MeasurementCore locks the impression owner onto mraid the moment mraid is present, whether
  // or not its calls actually succeed).
  copyMraidToFrame(getWindowParentAttribute);

  const mraid = window.mraid ?? (getWindowParentAttribute('mraid', MRAID_PARENT_SEARCH_DEPTH) as Mraid | undefined);

  return { mraid, omid: discoverOmid(), document };
}
