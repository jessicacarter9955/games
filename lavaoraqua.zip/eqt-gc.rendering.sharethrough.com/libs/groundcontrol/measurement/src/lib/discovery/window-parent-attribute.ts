/* eslint-disable @typescript-eslint/no-explicit-any */

/**
 * Traverse up the window parent chain to find an attribute
 * This function is designed to be stringified and injected into iframe HTML
 * This function will only run in JS script context within the iframe
 * @param attributeName - The attribute to search for (e.g., 'mraid')
 * @param maxDepth - Maximum depth to traverse
 * @returns The attribute value if found, undefined otherwise
 */
export function getWindowParentAttribute(attributeName: string, maxDepth: number): unknown {
  let currentWindow = window.parent;
  let depth = 0;

  while (currentWindow && depth < maxDepth) {
    try {
      // Try to access the attribute on this window level
      // Use truthy check to skip null, undefined, false, 0, empty strings, etc.
      if ((currentWindow as any)[attributeName]) {
        return (currentWindow as any)[attributeName];
      }

      // Check if we've reached the top window
      if (currentWindow === currentWindow.parent) {
        break;
      }

      // Move to the next parent
      currentWindow = currentWindow.parent;
      depth++;
    } catch (e) {
      // Cross-origin error - try to move to parent anyway
      try {
        if (currentWindow === currentWindow.parent) {
          break;
        }
        currentWindow = currentWindow.parent;
        depth++;
      } catch (e2) {
        // Can't access parent - stop traversal
        break;
      }
    }
  }
  return undefined;
}
