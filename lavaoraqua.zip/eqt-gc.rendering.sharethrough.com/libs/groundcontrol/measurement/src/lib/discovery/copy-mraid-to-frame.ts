/**
 * Copies the host page's MRAID object **and its native `mraidbridge`** from the parent window
 * hierarchy into the current (creative iframe) window.
 *
 * In-app MRAID SDKs expose `window.mraid` whose methods call into a separate `window.mraidbridge`
 * native bridge. Copying `mraid` alone leaves the bridge behind, so the first mraid call throws
 * `ReferenceError: mraidbridge is not defined` inside the creative iframe and the MRAID impression
 * never fires. Copying both keeps the object usable.
 *
 * This function is shipped by stringifying it (`.toString()`) and injecting the text into the
 * creative iframe, so its body MUST be lexically self-contained: no references to module-scoped
 * identifiers (they are invisible across the `.toString()` boundary and throw a ReferenceError in
 * the iframe). That is why the parent-window search depth is an inline literal rather than a
 * module constant, and why `getParentAttribute` (the parent-window walk) is passed in.
 */
export function copyMraidToFrame(getParentAttribute: (attributeName: string, maxDepth: number) => unknown): void {
  const parentSearchDepth = 10;

  if (!window.mraid) {
    const mraid = getParentAttribute('mraid', parentSearchDepth);
    if (mraid) window.mraid = mraid as Window['mraid'];
  }

  if (!window.mraidbridge) {
    const mraidbridge = getParentAttribute('mraidbridge', parentSearchDepth);
    if (mraidbridge) window.mraidbridge = mraidbridge;
  }
}
