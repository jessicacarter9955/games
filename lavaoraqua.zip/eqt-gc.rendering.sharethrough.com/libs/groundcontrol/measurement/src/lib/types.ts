export enum MeasurementType {
  Standard = 'standard',
  MRAID = 'mraid',
  OMID = 'omid',
  OnePixel = 'onepx',
  IabViewable = 'iabViewable',
  Embedded = 'embedded'
}

/** The host-injected MRAID bridge the core consumes (never creates — FR-003). */
export interface Mraid {
  getState(): 'loading' | 'default' | 'expanded' | 'resized' | 'hidden';
  isViewable(): boolean;
  addEventListener(event: 'ready' | 'viewableChange', handler: (viewable?: boolean) => void): void;
  removeEventListener(event: 'ready' | 'viewableChange', handler: (viewable?: boolean) => void): void;
}

/** An OMID `geometryChange` event, in the envelope the verification client delivers. */
export interface OmidGeometryChangeEvent {
  readonly data: { readonly adView: { readonly percentageInView: number } };
}

/**
 * The slice of the IAB OMID verification client the core consumes. GC never starts an OM
 * session — it joins one the host app's OM SDK already started, which is why the only
 * capability probe is `isSupported()` (FR-003).
 *
 * Deliberately has no `removeEventListener`: the IAB client
 * ([verification-client.js](../../../../onepx-impression/omid-verification-client/src/verification-client/verification-client.js))
 * exposes none, so the OMID path can only stop *responding* to events, not unsubscribe.
 * Supplying a real client is follow-up work; no production caller has one yet.
 */
export interface OmidClient {
  isSupported(): boolean;
  addEventListener(event: 'geometryChange', handler: (event: OmidGeometryChangeEvent) => void): void;
}

/**
 * The slice of the host's `document` the on-load fallback reads. `DOMContentLoaded` rather
 * than the window's `load`: GC's `load` transitively waits for the creative iframe it hosts,
 * which some adm templates stall indefinitely (WR-2115) — see `armOnLoad`.
 */
export interface MeasurementDocument {
  readonly readyState: DocumentReadyState;
  addEventListener?(event: 'DOMContentLoaded', handler: () => void, options?: { once?: boolean }): void;
  removeEventListener?(event: 'DOMContentLoaded', handler: () => void): void;
}

/**
 * The window-like host the core is handed. Window discovery (walking to the frame that
 * exposes `mraid`) is the caller's job, deferred with the render wiring (T009); the core
 * only reads what it is given. A real `Window` satisfies this structurally — its `document`
 * backs the on-load fallback path.
 */
export interface MeasurementHost {
  readonly mraid?: Mraid;
  readonly omid?: OmidClient;
  readonly document?: MeasurementDocument;
}

/** Fires a tracking URL. Injected so the core never reaches the network in unit tests. */
export type FireUrl = (url: string) => void;

/** The tracking URLs the measurement core fires, sourced by the caller from `getSasConfig()`. */
export interface MeasurementUrls {
  /** MraidImpression, actionid `10012`. Fired whenever a MRAID session reports viewable. */
  readonly mraidTrackingUrl: string;
  /** OmidImpression, actionid `10013`. Fired whenever an OMID session reports in-view. */
  readonly omidTrackingUrl: string;
  /** The single Counted Impression (`impressionTrackingUrl`), owned by one path (FR-002). */
  readonly impressionTrackingUrl: string;
}

/** Handle returned by an armed measurement path so the caller can detach its listeners. */
export interface MeasurementHandle {
  teardown(): void;
}

/** A wired-up measurement path the core can start and later detach. */
export interface Capability {
  /** Begin listening (or fire synchronously if the host already reports the signal). */
  start(): void;
  /** Stop responding to this path's signal. Idempotent. */
  detach(): void;
}
