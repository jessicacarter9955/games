import type { Capability, MeasurementHost } from '../types';

interface ArmOnLoadOptions {
  host: MeasurementHost;
  /** Invoked once, at begin-to-render — or immediately if the document is already parsed. */
  onLoaded(): void;
  /** Invoked for any host access that throws (routed to reportError by the core). */
  onError(error: unknown): void;
}

/**
 * Upper bound (ms) for the `DOMContentLoaded` wait, mirroring the external script's
 * `IMPRESSION_LOAD_TIMEOUT_MS`. Fire rather than risk starving the impression on a
 * pathologically delayed parse.
 */
export const IMPRESSION_LOAD_TIMEOUT_MS = 5000;

/**
 * The no-session fallback: mirrors the external OnePixel script's `trackRenderedImpression`,
 * counting at begin-to-render rather than at a visibility signal there is no session to
 * provide.
 *
 * Gated on the document being parsed (`readyState !== 'loading'`) and, when it is not yet,
 * on `DOMContentLoaded` — deliberately *not* the window's `load`. The core runs in GC's own
 * frame, whose `load` transitively waits for the creative iframe GC hosts, and adm templates
 * that front-load hidden cookie-sync iframes there can delay it indefinitely, silently
 * starving the impression (WR-2115). `DOMContentLoaded` never waits on iframes; begin-to-render
 * intent is upheld by ordering instead — the creative is attached before measurement arms.
 *
 * The script has a second, earlier no-session branch — an immediate count when `mraid.js`
 * loads but leaves `mraid` undefined. That one is unreachable here: the core never injects
 * `mraid.js` (ADR-0007), so this is the only fallback timing GC can mirror (ADR-0008).
 */
export const armOnLoad = ({ host, onLoaded, onError }: ArmOnLoadOptions): Capability => {
  let isPending = false;
  let timeout: ReturnType<typeof setTimeout> | undefined;

  const safely = (action: () => void): void => {
    try {
      action();
    } catch (error) {
      onError(error);
    }
  };

  const stopWaiting = (): void => {
    isPending = false;
    host.document?.removeEventListener?.('DOMContentLoaded', settle);
    if (timeout !== undefined) clearTimeout(timeout);
    timeout = undefined;
  };

  // Shared by the `DOMContentLoaded` listener and the timeout backstop, so whichever fires
  // first counts and the other is dropped.
  const settle = (): void =>
    safely(() => {
      if (!isPending) return;
      stopWaiting();
      onLoaded();
    });

  return {
    start: () =>
      safely(() => {
        const document = host.document;

        // 'interactive' already means parsed — the script counts there too.
        if (document && document.readyState !== 'loading') {
          onLoaded();
          return;
        }

        // No session, no parse signal: this render cannot be counted at all, which is the one
        // outcome US3 forbids silently. A real `Window` never lands here.
        if (!document?.addEventListener) {
          onError(new Error('Measurement host exposes no DOMContentLoaded event — the Counted Impression cannot fire'));
          return;
        }

        isPending = true;
        document.addEventListener('DOMContentLoaded', settle, { once: true });
        timeout = setTimeout(settle, IMPRESSION_LOAD_TIMEOUT_MS);
      }),
    detach: () => safely(stopWaiting)
  };
};
