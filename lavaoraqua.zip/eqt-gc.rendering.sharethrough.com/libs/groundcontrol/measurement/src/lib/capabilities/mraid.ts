import type { Capability, Mraid } from '../types';

interface ArmMraidOptions {
  mraid: Mraid;
  /** Invoked once, when the host first reports viewable. */
  onViewable(): void;
  /** Invoked for any host-session access that throws (routed to reportError by the core). */
  onError(error: unknown): void;
}

/**
 * The MRAID capability: mirrors the external OnePixel script's MRAID handler. Fires on the
 * first `viewableChange` viewable — or immediately when already viewable once `ready` has
 * passed. Consume-only: reads a host-injected bridge, never injects `mraid.js` (ADR-0007).
 * Every host call is guarded so a throwing SDK is reported, never propagated (AC4).
 *
 * One deliberate departure from the script: `viewableChange` is subscribed at arm, not after
 * `ready`. Some hosts never deliver `ready` to a listener added while `getState()` is still
 * 'loading', yet keep sending `viewableChange`; gated on `ready`, this path never counted
 * (WR-2313, ADR-0003).
 */
export const armMraid = ({ mraid, onViewable, onError }: ArmMraidOptions): Capability => {
  let hasFired = false;

  const safely = (action: () => void): void => {
    try {
      action();
    } catch (error) {
      onError(error);
    }
  };

  // `ready` + isViewable() and viewableChange can both report the same session; whichever lands
  // first counts.
  const fire = (): void => {
    if (hasFired) return;
    hasFired = true;
    mraid.removeEventListener('ready', onReady);
    mraid.removeEventListener('viewableChange', onViewableChange);
    onViewable();
  };

  const onViewableChange = (viewable?: boolean): void =>
    safely(() => {
      if (viewable) fire();
    });

  const onReady = (): void =>
    safely(() => {
      mraid.removeEventListener('ready', onReady);
      if (mraid.isViewable()) fire();
    });

  return {
    start: () =>
      safely(() => {
        mraid.addEventListener('viewableChange', onViewableChange);
        if (mraid.getState() === 'loading') {
          mraid.addEventListener('ready', onReady);
        } else {
          onReady();
        }
      }),
    detach: () =>
      safely(() => {
        mraid.removeEventListener('ready', onReady);
        mraid.removeEventListener('viewableChange', onViewableChange);
      })
  };
};
