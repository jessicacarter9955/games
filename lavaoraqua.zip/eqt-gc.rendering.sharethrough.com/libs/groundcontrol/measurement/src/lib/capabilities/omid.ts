import type { Capability, OmidClient, OmidGeometryChangeEvent } from '../types';

interface ArmOmidOptions {
  omid: OmidClient;
  /** Invoked once, when the OM session first reports any part of the ad in view. */
  onInView(): void;
  /** Invoked for any client access that throws (routed to reportError by the core). */
  onError(error: unknown): void;
}

/**
 * The OMID capability: mirrors the external OnePixel script's `handleGeometryChangeEvent`.
 * Fires on the first `geometryChange` whose `percentageInView` exceeds zero — one pixel, per
 * OnePixel's definition, not an MRC50 threshold. Consume-only: it joins a session the host
 * app's OM SDK already started and never creates one (FR-003).
 *
 * The IAB verification client cannot unsubscribe, so `detach` flips a flag and later events
 * are dropped instead of unregistering the handler.
 */
export const armOmid = ({ omid, onInView, onError }: ArmOmidOptions): Capability => {
  let isListening = false;

  const safely = (action: () => void): void => {
    try {
      action();
    } catch (error) {
      onError(error);
    }
  };

  const onGeometryChange = (event: OmidGeometryChangeEvent): void =>
    safely(() => {
      if (!isListening || !(event?.data?.adView?.percentageInView > 0)) return;
      isListening = false;
      onInView();
    });

  return {
    start: () =>
      safely(() => {
        isListening = true;
        omid.addEventListener('geometryChange', onGeometryChange);
      }),
    detach: () => {
      isListening = false;
    }
  };
};
