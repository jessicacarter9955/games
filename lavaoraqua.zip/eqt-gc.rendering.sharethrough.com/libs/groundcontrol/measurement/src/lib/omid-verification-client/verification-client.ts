/**
 * OMID verification-client API.
 *
 * IMPORTANT: importing or bundling this module does not register the resulting
 * script as an OMID verification resource. The host player/SDK must receive
 * the script URL as verification metadata and inject it through OM SDK (for
 * example, from VAST AdVerifications or a native VerificationScriptResource).
 *
 * OpenRTB API framework 7 only advertises OMID support/requirements; it does
 * not perform registration. Current Web services identify a legitimate
 * injected resource through `omidVerificationProperties.injectionId`.
 *
 * See ./README.md for the complete auction and runtime integration flow.
 *
 * Divergences from upstream
 * ([verification-client.js](../../../../../onepx-impression/omid-verification-client/src/verification-client/verification-client.js),
 * 1.3.15-dev). The shrink in item 6 deletes the diff that used to answer this,
 * so "we removed it" is no longer distinguishable from "upstream added it":
 *   1. isSupported() returns false on Environment.WEB without an injectionId — 1.4.8.
 *   2. getEnvironment() — 1.4.8; not in the mirror.
 *   3. injectionSource() — 1.3.17; reached only through getEnvironment().
 *   4. addEventListener passes injectionId_ to the service — 1.4.3/1.4.4.
 *   5. Version is 1.6.8 (common/version.ts); the mirror reads 1.3.15-dev.
 *   6. GC-only: the session-owning API is deleted — see
 *      docs/adr/0021-the-omid-verification-client-is-shrunk-in-place-and-gc-js-stays-one-artifact.md.
 *      GC joins a host session and never owns one (ADR-0002), so none of
 *      registerSessionObserver, attest, sendUrl, injectJavaScriptResource or the
 *      remote timers was reachable.
 * common/ is vendored and unchanged, but it is not pristine either: guid.ts
 * prefers crypto and omid-global-provider.ts falls back to Function('return this')().
 */
import InternalMessage from './common/internal-message.js';
import * as logger from './common/logger.js';
import { Environment } from './common/constants.js';
import { Version } from './common/version.js';
import { assertFunction, assertTruthyString } from './common/args-checker.js';
import { deserializeMessageArgs, serializeMessageArgs } from './common/args-serde.js';
import { generateGuid } from './common/guid.js';
import { getOmidEnvironment } from './common/detect-omid.js';
import { omidGlobal } from './common/omid-global-provider.js';
import { resolveGlobalContext, resolveTopWindowContext } from './common/window-utils.js';
import { startVerificationServiceCommunication } from './common/service-communication.js';

export interface VerificationMessage {
  guid: string;
  method: string;
  version: string;
  args: unknown[];
}

export interface VerificationClientCommunication {
  onMessage?: (message: VerificationMessage, from?: unknown) => void;
  sendMessage(message: VerificationMessage, to?: unknown): void;
}

export interface VerificationEvent<TData = Record<string, unknown>> {
  adSessionId: string;
  timestamp: number;
  type: string;
  data: TData;
}

export type VerificationEventCallback<TData = Record<string, unknown>> = (event: VerificationEvent<TData>) => void;

export type VerificationCallback = (...args: never[]) => void;

interface ThirdPartyOmid {
  registerSessionObserver(callback: VerificationEventCallback, vendorKey?: string, injectionId?: string): void;
  addEventListener<TData>(eventType: string, callback: VerificationEventCallback<TData>, injectionId?: string): void;
}

/**
 * @const {string}
 * @ignore
 */
const VERIFICATION_CLIENT_VERSION = Version;

/**
 * @typedef {!ImpressionCallback|
 *           !GeometryChangeCallback|
 *           !VideoCallback}
 * @ignore
 */
/**
 * Checks for and returns the window.omid3p object, if it exists.
 * @return {?{registerSessionObserver: !Function,
 *           addEventListener: !Function}} The omid3p object.
 * @ignore
 */
// The bridge is the host's object, not ours. This still requires
// registerSessionObserver even though the shrink removed our own: loosening it
// widens which hosts GC accepts as an OM bridge — a behaviour change, and one
// that fails silently (discoverOmid swallows everything).
function getThirdPartyOmid(): ThirdPartyOmid | null {
  const omid3p = omidGlobal['omid3p'];
  if (
    omid3p &&
    typeof omid3p['registerSessionObserver'] === 'function' &&
    typeof omid3p['addEventListener'] === 'function'
  ) {
    return omid3p;
  }
  return null;
}

/**
 * Allows verification scripts to interact with the OM SDK Service.
 * @public
 */
class VerificationClient {
  private communication?: VerificationClientCommunication;
  private omid3p?: ThirdPartyOmid;
  private callbackMap_: Record<string, VerificationCallback> = {};
  private readonly injectionId_?: string;

  /**
   * @param {?Communication<?>=} communication This parameter is for OM SDK
   *    internal use only and should be omitted.
   */
  constructor(communication?: VerificationClientCommunication) {
    /**
     * Communication object that the VerificationClient will use to talk to the
     * VerificationService. This parameter is useful for testing. If left
     * unspecified, the correct Communication will be constructed and used.
     */
    this.communication =
      communication ||
      (startVerificationServiceCommunication(resolveGlobalContext()) as VerificationClientCommunication | undefined);
    if (this.communication) {
      this.communication.onMessage = this.handleMessage_.bind(this);
    } else {
      const omid3p = getThirdPartyOmid();
      if (omid3p) {
        this.omid3p = omid3p;
      }
    }

    /**
     * Map of callback guids to callbacks.
     * @type {!Object<string, function(?)>}
     * @private
     */
    this.callbackMap_ = {};

    const verificationProperties = omidGlobal['omidVerificationProperties'];

    /**
     * An ID injected by the OM SDK to uniquely identify this script.
     * @private @const {string|undefined}
     */
    this.injectionId_ = verificationProperties ? verificationProperties['injectionId'] : undefined;
  }

  /**
   * Checks if OMID is available.
   * @return {boolean}
   * @public
   */
  isSupported(): boolean {
    if (this.getEnvironment() === Environment.WEB && !this.injectionId_) {
      return false;
    }
    return Boolean(this.communication || this.omid3p);
  }

  /**
   * Returns the detected OM SDK service environment. Older services do not
   * identify their environment, in which case this deliberately returns null.
   * @return {string|null}
   */
  getEnvironment(): string | null {
    const globalContext = resolveGlobalContext();
    return (
      this.injectionSource() ||
      getOmidEnvironment(globalContext) ||
      getOmidEnvironment(resolveTopWindowContext(globalContext))
    );
  }

  /**
   * @return {string|undefined}
   */
  injectionSource(): string | undefined {
    const verificationProperties = omidGlobal['omidVerificationProperties'];
    return verificationProperties && verificationProperties['injectionSource'];
  }

  // TODO(OMSDK-718): Make the declarations in event-typedef.js compatible with
  // JSDoc, and remove the event handler field descriptions below.

  /**
   * Subscribes to ad lifecycle and metric events.
   * The event handler will be called with a single argument that has the
   * following fields:
   *   'adSessionId': string,
   *   'timestamp': number,
   *   'type': string,
   *   'data': object
   * @param {!AdEventType} eventType The event type to subscribe this listener
   *     to.
   * @param {!EventCallback} functionToExecute An event handler to be invoked
   *     when the given event type is triggered.
   * @throws error if the event type is undefined, null or blank.
   * @throws error if the function to execute is undefined or null.
   * @public
   */
  addEventListener<TData = Record<string, unknown>>(
    eventType: string,
    functionToExecute: VerificationEventCallback<TData>
  ): void {
    assertTruthyString('eventType', eventType);
    assertFunction('functionToExecute', functionToExecute);
    if (this.omid3p) {
      this.omid3p['addEventListener'](eventType, functionToExecute, this.injectionId_);
      return;
    }
    this.sendMessage_('addEventListener', functionToExecute, eventType, this.injectionId_);
  }

  /**
   * Handles an incomming post message.
   * @param {!InternalMessage} message
   * @param {?} from Who sent the message.
   * @private
   */
  private handleMessage_(message: VerificationMessage, _from?: unknown): void {
    const { method, guid, args } = message;
    if (method === 'response' && this.callbackMap_[guid]) {
      // Clients deserialize messages based on their own version, which is this
      // VERIFICATION_CLIENT_VERSION in this case.
      // The service will serde the message based on the clients' initiated
      // message version
      const deserializedArgs = deserializeMessageArgs(VERIFICATION_CLIENT_VERSION, args);
      (this.callbackMap_[guid] as (...args: unknown[]) => void).apply(this, deserializedArgs);
    }
    if (method === 'error') {
      if (window.console) logger.error(args);
    }
  }

  /**
   * Sends a message to the OMID VerificationService.
   * @param {string} method Name of the remote method to invoke.
   * @param {?function(...?)} responseCallback Callback to be called when
   *     a response is received.
   * @param {...?} args Arguments to use when invoking the remote function.
   * @private
   */
  private sendMessage_(method: string, responseCallback: VerificationCallback | null, ...args: unknown[]): void {
    if (!this.communication) return;

    const guid = generateGuid();
    if (responseCallback) {
      this.callbackMap_[guid] = responseCallback;
    }

    const message = new InternalMessage(
      guid,
      `VerificationService.${method}`,
      VERIFICATION_CLIENT_VERSION,
      serializeMessageArgs(VERIFICATION_CLIENT_VERSION, args)
    );
    this.communication.sendMessage(message as unknown as VerificationMessage);
  }
}

export default VerificationClient;
