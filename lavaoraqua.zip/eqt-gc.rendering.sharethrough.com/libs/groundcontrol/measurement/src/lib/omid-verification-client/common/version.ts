// @ts-nocheck
/**
 * The version of the OMID Verification Client JS API provided by this code.
 * @const {string}
 */
const ApiVersion = '1.0';

/**
 * The version of the OMID service code.
 * @const {string}
 */
const Version = '1.6.8';

export { ApiVersion, Version };
