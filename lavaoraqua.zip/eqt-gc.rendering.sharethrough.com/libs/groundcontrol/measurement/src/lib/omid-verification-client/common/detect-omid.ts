// @ts-nocheck
/**
 * The name of the iframe that lets other iframes detect that OMID can be used.
 * @const {string}
 */
const OMID_PRESENT_FRAME_NAME = 'omid_v1_present';
const OMID_PRESENT_FRAME_NAME_WEB = 'omid_v1_present_web';
const OMID_PRESENT_FRAME_NAME_APP = 'omid_v1_present_app';

function getEnvironmentIframeName(environment) {
  return {
    [Environment.APP]: OMID_PRESENT_FRAME_NAME_APP,
    [Environment.WEB]: OMID_PRESENT_FRAME_NAME_WEB
  }[environment];
}

function isIframePresent(globalObject, iframeName) {
  try {
    return Boolean(globalObject.frames && globalObject.frames[iframeName]);
  } catch {
    return false;
  }
}

/**
 * Determine if the OMID JS Service is available even if not in the same iframe
 * as the verification providers' code.
 * @param {!Window} globalObject the Window or other global object where the
 *     client is running
 * @return {boolean} true if OMID is present, false if OMID is not present
 */
function isOmidPresent(globalObject) {
  return [OMID_PRESENT_FRAME_NAME, OMID_PRESENT_FRAME_NAME_WEB, OMID_PRESENT_FRAME_NAME_APP].some((frameName) =>
    isIframePresent(globalObject, frameName)
  );
}

function getOmidEnvironment(globalObject) {
  for (const environment of Object.values(Environment)) {
    if (isIframePresent(globalObject, getEnvironmentIframeName(environment))) {
      return environment;
    }
  }
  return null;
}

/**
 * Set up the iframe that declares the presence of the OM SDK JS service to
 * clients in other frames.
 * @param {!Window} globalObject the Window or other global object where the
 *     service is running
 */
function declareOmidPresence(globalObject) {
  // We only need to declare presence in a webview, not a DOM-less context.
  if (!globalObject.frames || !globalObject.document) {
    return;
  }
  if (OMID_PRESENT_FRAME_NAME in globalObject.frames) {
    return;
  }
  if (globalObject.document.body == null && isMutationObserverAvailable_(globalObject)) {
    registerMutationObserver_(globalObject);
  } else if (globalObject.document.body) {
    appendPresenceIframe_(globalObject);
  } else {
    const frameTag =
      '<iframe style="display:none" ' +
      `id="${OMID_PRESENT_FRAME_NAME}"` +
      ` name="${OMID_PRESENT_FRAME_NAME}">` +
      '</iframe>';
    globalObject.document.write(frameTag);
  }
}

/**
 * Appends the presence iframe in the body of a window document.
 * @param {!Window} globalObject the Window or other global object where the
 *     client is running
 * @private
 */
function appendPresenceIframe_(globalObject) {
  const iframe = globalObject.document.createElement('iframe');
  iframe.id = OMID_PRESENT_FRAME_NAME;
  iframe.name = OMID_PRESENT_FRAME_NAME;
  iframe.style.display = 'none';
  globalObject.document.body.appendChild(iframe);
}

/**
 * Tests if Mutation Observer API exists.
 * @param {!Window} globalObject the Window or other global object where the
 *     client is running
 * @return {boolean} true if MO API is there, false otherwise.
 * @private
 */
function isMutationObserverAvailable_(globalObject) {
  return 'MutationObserver' in globalObject;
}

function registerMutationObserver_(globalObject) {
  const mutationObserver = new MutationObserver((mutations) => {
    mutations.forEach((mutation) => {
      if (mutation.addedNodes[0].nodeName === 'BODY') {
        appendPresenceIframe_(globalObject);
        mutationObserver.disconnect();
      }
    });
  });
  mutationObserver.observe(globalObject.document.documentElement, { childList: true });
}

export {
  OMID_PRESENT_FRAME_NAME,
  OMID_PRESENT_FRAME_NAME_APP,
  OMID_PRESENT_FRAME_NAME_WEB,
  appendPresenceIframe_,
  declareOmidPresence,
  getEnvironmentIframeName,
  getOmidEnvironment,
  isMutationObserverAvailable_,
  isOmidPresent,
  registerMutationObserver_
};
import { Environment } from './constants.js';
