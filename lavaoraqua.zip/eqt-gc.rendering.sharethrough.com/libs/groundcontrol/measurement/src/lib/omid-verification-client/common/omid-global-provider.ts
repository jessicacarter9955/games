// @ts-nocheck
/**
 * Returns the omidGlobal object. If the client is wrapped in a bootstrapper,
 * then the omidGlobal object is defined from the wrapping immediately invoked
 * function. For client integrations that use Google Closure Compiler, then it
 * resorts to the top-level this object.
 * @return {!Window}
 * @throws error when omidGlobal cannot be determined.
 */
function getOmidGlobal() {
  if (typeof omidGlobal !== 'undefined' && omidGlobal) {
    return omidGlobal;
  } else if (typeof global !== 'undefined' && global) {
    return global;
  } else if (typeof window !== 'undefined' && window) {
    return window;
  } else if (typeof globalThis !== 'undefined' && globalThis) {
    return globalThis;
  } else {
    // Supports older JavaScriptCore versions that predate globalThis. Browser
    // CSP does not affect this fallback because browsers define window above.
    const globalObject = /** @type {?Window} */ (Function('return this')());
    if (globalObject) return globalObject;
  }
  throw new Error('Could not determine global object context.');
}

/** @type {!Window} */
const resolvedOmidGlobal = getOmidGlobal();

export { resolvedOmidGlobal as omidGlobal };
