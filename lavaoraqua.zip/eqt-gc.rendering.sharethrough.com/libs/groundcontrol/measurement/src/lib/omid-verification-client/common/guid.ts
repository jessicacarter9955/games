// @ts-nocheck
/**
 * Checks whether secure random generation is available.
 * @return {boolean}
 */
function isCryptoAvailable() {
  return typeof crypto !== 'undefined' && typeof crypto.getRandomValues === 'function';
}

/**
 * Generates an RFC4122 version 4 GUID, preferring secure random values.
 * @return {string}
 */
function generateGuid() {
  return isCryptoAvailable() ? generateSecureGuid() : generateFallbackGuid();
}

/**
 * @return {string}
 */
function generateSecureGuid() {
  const bytes = new Uint8Array(16);
  crypto.getRandomValues(bytes);
  bytes[6] = (bytes[6] & 0x0f) | 0x40;
  bytes[8] = (bytes[8] & 0x3f) | 0x80;

  const hex = Array.from(bytes, (byte) => byte.toString(16).padStart(2, '0'));
  return `${hex.slice(0, 4).join('')}-${hex.slice(4, 6).join('')}-${hex.slice(6, 8).join('')}-${hex
    .slice(8, 10)
    .join('')}-${hex.slice(10).join('')}`;
}

/**
 * Retains compatibility with runtimes that do not expose Web Crypto.
 * @return {string}
 */
function generateFallbackGuid() {
  const digit = (containsClockSeqHiAndReserved) => {
    let randomNumber = (Math.random() * 16) | 0;
    // This digit contains the clock sequence high and reserved bits, so we
    // must set them in the return value.
    if (containsClockSeqHiAndReserved) {
      return ((randomNumber & 0x3) | 0x8).toString(16);
    }
    return randomNumber.toString(16);
  };

  // Mark the digit that contains the clock sequence high and reserved bits
  // so that the algorithm sets them appropriately. Also set version 4 in the
  // string directly.
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (character) => digit(character === 'y'));
}

export { generateFallbackGuid, generateGuid, generateSecureGuid, isCryptoAvailable };
