import { reportError } from '@web-rendering/groundcontrol-monitoring';

import { armMraid } from './capabilities/mraid';
import { armOmid } from './capabilities/omid';
import { armOnLoad } from './capabilities/on-load';

import type { Capability, FireUrl, MeasurementHost, MeasurementUrls } from './types';
import type { LifecycleScope } from '@web-rendering/groundcontrol-shared-types/lifecycle/lifecycle';

/** The consume-only core's lifecycle. Advances forward only; never re-arms (WR-2043 out of scope). */
export enum MeasurementState {
  Idle = 'idle',
  Armed = 'armed',
  /** The Counted Impression is out; per-session trackers may still be waiting on their signal. */
  Fired = 'fired',
  TornDown = 'torn_down'
}

/** Which path owns the single Counted Impression, in fallback order (FR-002). */
type Owner = 'mraid' | 'omid' | 'on-load';

/**
 * Consume-only measurement core (WR-2043). Joins whatever host measurement sessions are
 * actually present, fires the single Counted Impression exactly once, and tears down.
 *
 * Two decisions are independent here, per FR-002:
 * - **Per-session trackers** fire whenever their own session reports: MraidImpression
 *   (`10012`) at MRAID viewable, OmidImpression (`10013`) at OMID in-view. An ad whose host
 *   exposes both sessions fires both.
 * - **The Counted Impression** has exactly one owner, chosen by the runtime fallback order
 *   MRAID → OMID → on-load. Bid-request `api` flags never reach this class: presence is
 *   established by reading the host, so a hint that claims a session GC cannot see simply
 *   falls through the order.
 *
 * Never fires the first-party Viewable `41` (FR-011); never injects `mraid.js` (ADR-0007).
 */
export class MeasurementCore {
  private state: MeasurementState = MeasurementState.Idle;
  private readonly capabilities = new Set<Capability>();
  private readonly firedUrls = new Set<string>();

  /** @param fireUrl how a tracking URL reaches the network — the caller wraps `URLBeacon`. */
  constructor(
    private readonly fireUrl: FireUrl,
    private readonly scope: LifecycleScope
  ) {}

  get currentState(): MeasurementState {
    return this.state;
  }

  /** Arm against a host. Idempotent: only an IDLE core arms. */
  arm(host: MeasurementHost, urls: MeasurementUrls): void {
    if (this.state !== MeasurementState.Idle) return;
    this.state = MeasurementState.Armed;

    const mraid = host.mraid;
    const omid = this.isOmidSupported(host) ? host.omid : undefined;
    const owner: Owner = mraid ? 'mraid' : omid ? 'omid' : 'on-load';

    if (mraid) {
      this.attach((settle) =>
        armMraid({
          mraid,
          onViewable: () =>
            settle(() => {
              this.fireOnce(urls.mraidTrackingUrl);
              if (owner === 'mraid') this.fireCountedImpression(urls);
            }),
          onError: (error) => this.report(error)
        })
      );
    }

    if (omid) {
      this.attach((settle) =>
        armOmid({
          omid,
          onInView: () =>
            settle(() => {
              this.fireOnce(urls.omidTrackingUrl);
              if (owner === 'omid') this.fireCountedImpression(urls);
            }),
          onError: (error) => this.report(error)
        })
      );
    }

    // The fallback only arms when no session exists at all. A session that never reports is
    // not backfilled at load — that is the external script's behavior, and counting a
    // never-viewable MRAID ad at load would inflate against the SC-001 parity reference.
    if (owner === 'on-load') {
      this.attach((settle) =>
        armOnLoad({
          host,
          onLoaded: () => settle(() => this.fireCountedImpression(urls)),
          onError: (error) => this.report(error)
        })
      );
    }

    this.startAll();
  }

  /** Detach every path still listening. Safe to call at any point and more than once. */
  teardown(): void {
    if (this.state === MeasurementState.TornDown) return;
    [...this.capabilities].forEach((capability) => this.release(capability));
    this.state = MeasurementState.TornDown;
  }

  /**
   * Registers one path. The `settle` it hands the adapter fires that path's trackers and then
   * releases only that path, so a MRAID viewable signal never detaches a pending OMID
   * listener — each session is torn down when its own signal arrives.
   */
  private attach(build: (settle: (fire: () => void) => void) => Capability): void {
    // The adapter needs a `settle` that closes over the capability the adapter itself returns,
    // so the reference is handed over in a holder rather than read before it is assigned.
    const path: { capability?: Capability } = {};

    const settle = (fire: () => void): void => {
      fire();
      if (path.capability) this.release(path.capability);
      this.settleIfComplete();
    };

    path.capability = build(settle);
    this.capabilities.add(path.capability);
  }

  /**
   * Starts every registered path. Starting is separate from registering because a host that is
   * already viewable (or a page already loaded) fires synchronously from `start`: were the
   * paths started as they were built, that first signal would settle a core whose other paths
   * had not been registered yet, and the core would call itself torn down while a session was
   * still live.
   */
  private startAll(): void {
    [...this.capabilities].forEach((capability) => capability.start());
    this.settleIfComplete();
  }

  private release(capability: Capability): void {
    capability.detach();
    this.capabilities.delete(capability);
  }

  private settleIfComplete(): void {
    if (this.state === MeasurementState.Fired && this.capabilities.size === 0) {
      this.state = MeasurementState.TornDown;
    }
  }

  private isOmidSupported(host: MeasurementHost): boolean {
    try {
      return host.omid?.isSupported() === true;
    } catch (error) {
      this.report(error);
      return false;
    }
  }

  private fireCountedImpression(urls: MeasurementUrls): void {
    if (this.state !== MeasurementState.Armed) return;

    // A path reported, so this render is countable — but the caller gave us nothing to fire.
    // Reported rather than skipped: an unfirable Counted Impression is exactly the silent drop
    // US3 forbids, and the state stays ARMED because nothing was in fact counted.
    if (!urls.impressionTrackingUrl) {
      this.report(new Error('Measurement has no impressionTrackingUrl — the Counted Impression cannot fire'));
      return;
    }

    this.fireOnce(urls.impressionTrackingUrl);
    this.state = MeasurementState.Fired;
  }

  private fireOnce(url: string): void {
    if (!url || this.firedUrls.has(url)) return;
    this.firedUrls.add(url);
    this.fireUrl(url);
  }

  private report(error: unknown): void {
    reportError(error instanceof Error ? error : new Error(String(error)), {
      scope: this.scope,
      context: 'measurement-core'
    });
  }
}
