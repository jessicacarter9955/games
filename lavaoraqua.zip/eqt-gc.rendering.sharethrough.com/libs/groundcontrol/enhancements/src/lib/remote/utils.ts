import type { TemplateUrlEnhancementPayload } from '@sharethrough/groundcontrol-enhancement-flush';
import type { Dispatch, StateUpdater } from 'preact/hooks';
import { type EnhancementClickEvent, EnhancementClickEventType, type EnhancementErrorEvent } from '../common';
import { RemoteEventType, type IRemoteEvent } from './type';

const REMOTE_ERROR_EVENTS = [RemoteEventType.Error];

const REMOTE_CLICK_EVENTS = [
  RemoteEventType.ClickThrough,
  RemoteEventType.ContentClick,
  RemoteEventType.EngagementClick,
  RemoteEventType.ProductCardClick,
  RemoteEventType.ShoppableCarouselArrowClick
];

const getClickEventType = (event: RemoteEventType): EnhancementClickEventType => {
  switch (event) {
    case RemoteEventType.EngagementClick:
      return EnhancementClickEventType.ENGAGEMENT;
    case RemoteEventType.ProductCardClick:
      return EnhancementClickEventType.PRODUCTCARD;
    case RemoteEventType.ShoppableCarouselArrowClick:
      return EnhancementClickEventType.SHOPPABLECAROUSEL_ARROW;
    case RemoteEventType.ClickThrough:
      return EnhancementClickEventType.CLICKTHROUGH;
    default:
      return EnhancementClickEventType.CONTENT;
  }
};

function isRemoteEvent(obj: unknown): obj is IRemoteEvent {
  return typeof obj === 'object' && obj !== null && 'eventType' in obj && typeof obj.eventType === 'string';
}

export const remoteMessageHandler = (
  event: MessageEvent,
  enhancement: TemplateUrlEnhancementPayload,
  onLifecycleEvent: (
    event: RemoteEventType.Initialized | RemoteEventType.HealthCheckOk | RemoteEventType.HealthCheckFail
  ) => void,
  onClick: (event: EnhancementClickEvent) => void,
  onError: (event: EnhancementErrorEvent) => void,
  setHasError: Dispatch<StateUpdater<boolean>>,
  onEnhancementLoaded?: () => void
) => {
  const templateOrigin = new URL(enhancement.payload.templateUrl).origin;
  if (event.origin !== templateOrigin) return;

  let remoteEvent: unknown;
  try {
    remoteEvent = typeof event.data === 'string' ? JSON.parse(event.data) : event.data;
  } catch (error) {
    onError({
      error: new Error(
        `Error parsing remote enhancement event data: ${error instanceof Error ? error.message : String(error)}`
      ),
      data: event.data
    });
    return;
  }

  if (!isRemoteEvent(remoteEvent)) return;

  const { eventType } = remoteEvent;

  if (REMOTE_ERROR_EVENTS.includes(eventType)) {
    onError({
      error: new Error(`Remote enhancement error event: ${eventType}`),
      data: event.data,
      isPageFailure: true
    });
    setHasError(true);
    return;
  }

  if (REMOTE_CLICK_EVENTS.includes(eventType)) {
    onClick({
      enhancementType: enhancement.type,
      eventType: getClickEventType(eventType),
      productId: remoteEvent.data?.productId
    });

    return;
  }

  switch (eventType) {
    case RemoteEventType.Initialized:
    case RemoteEventType.HealthCheckOk:
      onLifecycleEvent(eventType);
      break;
    case RemoteEventType.HealthCheckFail:
      setHasError(true);
      onLifecycleEvent(eventType);
      break;
    case RemoteEventType.EnhancementLoaded:
      onEnhancementLoaded?.();
      break;
    default:
      break;
  }
};
