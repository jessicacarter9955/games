import type { TemplateUrlEnhancementPayload } from '@sharethrough/groundcontrol-enhancement-flush';
import { type FunctionComponent } from 'preact';
import { useCallback, useEffect, useRef, useState } from 'preact/hooks';
import { EnhancementContainer } from '../common/container/container.component';
import type { RemoteComponentProps } from '../common/type';
import { isTestEnvironment } from '@web-rendering/groundcontrol-utils';
import { checkEnhancementAvailability } from './preflight';
import { RemoteEventType } from './type';
import { remoteMessageHandler } from './utils';

// The whole window is exposure to a template that may never report, and anything abandoned inside
// it goes unreported entirely (ADR-0009). A live fetch that resolves at all resolves well inside 3s.
const ENHANCEMENT_LOADED_TIMEOUT_MS = 3000;

export const RemoteEnhancement: FunctionComponent<RemoteComponentProps<TemplateUrlEnhancementPayload>> = ({
  enhancement,
  onClick,
  onLoad,
  onError,
  language,
  publisherStyles,
  onLifecycleChange,
  hasPreflight = false
}) => {
  const [hasError, setHasError] = useState(false);
  const [listenerAdded, setListenerAdded] = useState(false);

  const iframeRef = useRef<HTMLIFrameElement>(null);
  const enhancementLoadedTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const [enhancementLoaded, setEnhancementLoaded] = useState<boolean | undefined>(undefined);

  const clearEnhancementLoadedTimeout = useCallback(() => {
    if (enhancementLoadedTimeoutRef.current !== null) {
      clearTimeout(enhancementLoadedTimeoutRef.current);
      enhancementLoadedTimeoutRef.current = null;
    }
  }, []);

  const onEnhancementLoadedFromMessage = useCallback(() => {
    clearEnhancementLoadedTimeout();
    setEnhancementLoaded(true);
  }, [clearEnhancementLoadedTimeout]);

  /**
   * A page that announces itself is one that speaks the lifecycle, so from here on its silence
   * means something: if it never reports its content, we serve the default enhancement instead.
   * A page that never announces is one published before the protocol — it can't report, so no
   * wait is armed and it behaves exactly as it always has.
   */
  const armEnhancementLoadedWait = useCallback(() => {
    if (enhancementLoadedTimeoutRef.current !== null || isTestEnvironment()) return;

    enhancementLoadedTimeoutRef.current = setTimeout(() => {
      enhancementLoadedTimeoutRef.current = null;
      setEnhancementLoaded(false);

      onError({
        error: new Error('Remote enhancement did not send enhancementLoaded message within timeout'),
        isPageFailure: true
      });
    }, ENHANCEMENT_LOADED_TIMEOUT_MS);
  }, [onError]);

  const handleLifecycleEvent = useCallback(
    (event: RemoteEventType.Initialized | RemoteEventType.HealthCheckOk | RemoteEventType.HealthCheckFail) => {
      if (event === RemoteEventType.Initialized) armEnhancementLoadedWait();

      onLifecycleChange(event);
    },
    [armEnhancementLoadedWait, onLifecycleChange]
  );

  const messageHandler = useCallback(
    (e: MessageEvent) => {
      remoteMessageHandler(
        e,
        enhancement,
        handleLifecycleEvent,
        onClick,
        onError,
        setHasError,
        onEnhancementLoadedFromMessage
      );
    },
    [enhancement, handleLifecycleEvent, onClick, onError, onEnhancementLoadedFromMessage]
  );

  useEffect(() => {
    if (!enhancement?.payload.templateUrl) return;

    window.addEventListener('message', messageHandler);
    setListenerAdded(true);

    return () => {
      window.removeEventListener('message', messageHandler);
    };
  }, [enhancement?.payload.templateUrl, messageHandler]);

  const validateTemplateUrl = async (url: string) => {
    if (hasPreflight) {
      try {
        const isAvailable = await checkEnhancementAvailability(url);

        if (!isAvailable) {
          setEnhancementLoaded(false);

          onError({
            error: new Error(`Remote enhancement preflight: enhancement not available at ${url}`),
            isPageFailure: true
          });

          return;
        }
      } catch (err) {
        const data = err instanceof Error ? err : null;

        setEnhancementLoaded(false);

        onError({
          error: new Error(`Preflight check failed for remote enhancement: ${url}`),
          data,
          isPageFailure: true
        });

        return;
      }
    }

    let response: Response;
    try {
      response = await fetch(url, { method: 'GET' });
    } catch (err) {
      const data = err instanceof Error ? err : null;

      setEnhancementLoaded(false);

      onError({
        error: new Error(`Failed to fetch remote enhancement templateUrl: ${url}`),
        data,
        isPageFailure: true
      });

      return;
    }

    if (!response.ok) {
      setEnhancementLoaded(false);

      onError({
        error: new Error(`Remote enhancement templateUrl returned status ${response.status}`),
        isPageFailure: true
      });

      return;
    }

    setEnhancementLoaded(true);

    onLoad({
      enhancementType: enhancement.type
    });
  };

  useEffect(() => {
    if (!enhancement) return;

    if (!enhancement.payload.templateUrl) {
      setEnhancementLoaded(false);

      onError({
        error: new Error('Remote enhancement templateUrl is missing')
      });

      return;
    }

    validateTemplateUrl(enhancement.payload.templateUrl);

    return () => {
      clearEnhancementLoadedTimeout();
    };
  }, [enhancement, hasPreflight]);

  return (
    <EnhancementContainer
      enhancement={enhancement}
      enhancementLoaded={enhancementLoaded && !hasError}
      language={language}
      onClick={onClick}
      onError={onError}
      onLoad={onLoad}
      publisherStyles={publisherStyles}
    >
      <iframe
        data-listener={listenerAdded ? 'true' : 'false'}
        ref={iframeRef}
        src={enhancement.payload.templateUrl}
        style={{ borderWidth: 0, width: '100%', height: '100%', overflow: 'hidden' }}
        scrolling="no"
      />
    </EnhancementContainer>
  );
};
