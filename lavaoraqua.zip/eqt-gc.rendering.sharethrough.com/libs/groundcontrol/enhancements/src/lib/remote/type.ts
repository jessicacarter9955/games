export enum RemoteEventType {
  Error = 'error',
  ClickThrough = 'enhancementClickThrough',
  EngagementClick = 'engagementClick',
  ContentClick = 'contentClick',
  ProductCardClick = 'productCardClick',
  ShoppableCarouselArrowClick = 'shoppableCarouselArrowClick',
  HealthCheckFail = 'healthCheckFail',
  HealthCheckOk = 'healthCheckOk',
  Initialized = 'initialized',
  EnhancementLoaded = 'enhancementLoaded'
}

export interface IRemoteEvent {
  eventType: RemoteEventType;
  data?: { productId: string };
}
