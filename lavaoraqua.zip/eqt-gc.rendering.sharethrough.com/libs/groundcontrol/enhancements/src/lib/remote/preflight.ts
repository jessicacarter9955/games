export const checkEnhancementAvailability = async (url: string): Promise<boolean> => {
  const response = await fetch(url, { method: 'HEAD' });
  return response.ok && response.status !== 204;
};
