import type { PublisherStyles } from '@ad-rendering/publisher-style';
import { GCEnhancementType } from '@sharethrough/groundcontrol-enhancement-flush';
import type { RefObject } from 'preact';
import { useLayoutEffect } from 'preact/hooks';
import type { EnhancementType, FallbackEnhancementPayload } from './type';

export const enhancementFallback = (enhancement: EnhancementType): FallbackEnhancementPayload => {
  switch (enhancement.type) {
    case GCEnhancementType.BannerCountdown:
    case GCEnhancementType.BannerDailyWeatherOutlook:
    case GCEnhancementType.BannerHeadline:
    case GCEnhancementType.BannerShoppable:
    case GCEnhancementType.BannerSportsTicker:
    case GCEnhancementType.BannerWeather:
    case GCEnhancementType.BannerShoppableOverlay:
    case GCEnhancementType.BannerMedalCount:
    case GCEnhancementType.BannerWorldTournament:
    case GCEnhancementType.BannerCustom:
    case GCEnhancementType.BannerSofiaPulseBettingOdds:
    case GCEnhancementType.BannerSofiaPulseQuiz:
    case GCEnhancementType.BannerSofiaPulseSportsHeadlines:
    case GCEnhancementType.BannerSofiaPulseStockTicker:
      return {
        type: GCEnhancementType.BannerHeadline,
        enhancement_version_id: enhancement.enhancement_version_id
      };
    case GCEnhancementType.OutstreamCaptions:
    case GCEnhancementType.OutstreamCountdown:
    case GCEnhancementType.OutstreamDailyWeatherOutlook:
    case GCEnhancementType.OutstreamHeadline:
    case GCEnhancementType.OutstreamShoppable:
    case GCEnhancementType.OutstreamSportsTicker:
    case GCEnhancementType.OutstreamWeather:
    case GCEnhancementType.OutstreamMedalCount:
    case GCEnhancementType.OutstreamBrandedHeadline:
    case GCEnhancementType.OutstreamWorldTournament:
    case GCEnhancementType.OutstreamCustom:
      return {
        type: GCEnhancementType.OutstreamHeadline,
        enhancement_version_id: enhancement.enhancement_version_id
      };
    default:
      return enhancement;
  }
};

export const useClampMaxHeight = (ref: RefObject<HTMLElement>, styles: PublisherStyles | undefined) => {
  useLayoutEffect(() => {
    const { current } = ref;
    if (!current) return;
    const { webkitLineClamp, lineHeight } = window.getComputedStyle(current);
    const clamp = parseFloat(webkitLineClamp);
    const lh = parseFloat(lineHeight);
    if (!isNaN(clamp) && clamp > 0 && !isNaN(lh) && lh > 0) {
      current.style.maxHeight = `${clamp * lh}px`;
    }
  }, [ref, styles]);
};

export const hideAsset = (hide: boolean | undefined, value: unknown) => {
  return hide && !!value;
};
