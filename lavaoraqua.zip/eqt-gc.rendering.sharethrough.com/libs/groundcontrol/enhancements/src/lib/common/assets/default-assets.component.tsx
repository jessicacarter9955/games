import type { FunctionComponent } from 'preact';
import type { DefaultAssetsProps } from './type';
import { Price } from '../price';
import { RatingStars } from '../rating';
import './default-assets.scss';

export const DefaultAssets: FunctionComponent<DefaultAssetsProps> = ({ assets }) => {
  if (!assets || (!assets.rating && !assets.price)) return null;

  return (
    <div className="gc-default-assets">
      {assets.rating && <RatingStars rating={assets.rating} />}
      {assets.price && <Price price={assets.price} />}
    </div>
  );
};
