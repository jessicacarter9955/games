import { Fragment, type FunctionComponent } from 'preact';
import './advertiser.scss';
import type { AdvertiserProps } from './type';

export const Advertiser: FunctionComponent<AdvertiserProps> = ({ advertiser, publisherStyles }) => {
  const { promotedByText, name: advertiserName, brandLogoUrl } = advertiser;

  const fontStyles = publisherStyles?.promotedBy?.font?.toStyle();
  const backgroundStyle = publisherStyles?.promotedBy?.background?.toStyle();

  return (
    <div className="str-advertiser-container advertiser-container" style={backgroundStyle}>
      <Fragment>
        <span className="str-promoted-by promoted-by" data-shadow={promotedByText} style={fontStyles}>
          {promotedByText}
        </span>
        <span className="str-advertiser advertiser" data-shadow={advertiserName} style={fontStyles}>
          {advertiserName}
        </span>
        {brandLogoUrl && <img alt="Brand Logo" className="brand-logo" src={brandLogoUrl} />}
      </Fragment>
    </div>
  );
};
