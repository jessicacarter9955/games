import type { FunctionComponent } from 'preact';
import { useRef } from 'preact/hooks';
import './isi.scss';
import { useAnchorClickHandler } from './use-anchor-click-handler';
import { useAutoScroll } from './use-auto-scroll';
import { I18N, useTranslation } from '@web-rendering/groundcontrol-i18n';

export interface ISIProps {
  text: string;
  header?: string;
  subheader?: string;
  autoscroll?: boolean;
}

const ISI: FunctionComponent<ISIProps> = ({ autoscroll = false, text, header, subheader }) => {
  const { t } = useTranslation();
  const textRef = useRef(null);
  useAutoScroll(textRef, autoscroll);
  useAnchorClickHandler(textRef);

  return (
    <div className="str-isi-bundle-2">
      <div data-testid="isi-headline" className="str-isi-headline">
        {header ?? t(I18N.ISI)}
      </div>
      {subheader && <div dangerouslySetInnerHTML={{ __html: subheader }} />}
      <div ref={textRef} dangerouslySetInnerHTML={{ __html: text }} className="str-isi-text" />
    </div>
  );
};

export default ISI;
