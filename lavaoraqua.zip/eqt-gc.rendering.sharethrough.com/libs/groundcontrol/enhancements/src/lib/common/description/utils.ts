import type { GCEnhancementPayload } from '@sharethrough/groundcontrol-enhancement-flush';
import type { NativeAssets } from '@web-rendering/groundcontrol-ortb';

export const getEnhancementDescription = (payload: GCEnhancementPayload['payload'] | undefined): string | null => {
  if (!payload || !('description' in payload) || typeof payload.description !== 'string') return null;

  return payload.description;
};

export const getAssetsDescription = (assets: NativeAssets | undefined | null): string | null => {
  if (!assets) return null;

  return assets?.description?.data.value || null;
};
