import { useEffect } from 'preact/hooks';

export type HintVariant = 'B' | 'C' | 'D';

// --- Variant B: Card Peek ---
const PEEK_CONFIG = {
  peekDistance: 56,
  peekDelay: 700,
  peekHoldTime: 550,
  retreatTime: 320,
  loopInterval: 2800,
  slideEasing: 'cubic-bezier(0.25, 0.46, 0.45, 0.94)',
  retreatEasing: 'cubic-bezier(0.25, 0.46, 0.45, 0.94)'
};

function runCardPeek(root: HTMLElement, panel: HTMLElement, onEngage: () => void): () => void {
  let loopTimer: number | null = null;
  let peekTimer: number | null = null;
  let engaged = false;

  const clearTimers = () => {
    if (loopTimer != null) {
      clearTimeout(loopTimer);
      loopTimer = null;
    }
    if (peekTimer != null) {
      clearTimeout(peekTimer);
      peekTimer = null;
    }
  };

  const peekIn = () => {
    if (engaged) return;
    panel.style.transition = `transform ${PEEK_CONFIG.peekHoldTime}ms ${PEEK_CONFIG.slideEasing}`;
    panel.style.transform = `translateX(calc(-100% + ${PEEK_CONFIG.peekDistance}px))`;
    peekTimer = window.setTimeout(peekOut, PEEK_CONFIG.peekHoldTime);
  };

  const peekOut = () => {
    if (engaged) return;
    panel.style.transition = `transform ${PEEK_CONFIG.retreatTime}ms ${PEEK_CONFIG.retreatEasing}`;
    panel.style.transform = 'translateX(-100%)';
    loopTimer = window.setTimeout(peekIn, PEEK_CONFIG.loopInterval);
  };

  const handleEngage = () => {
    engaged = true;
    clearTimers();
    panel.style.transition = '';
    panel.style.transform = '';
    onEngage();
  };

  const handleDisengage = () => {
    engaged = false;
    loopTimer = window.setTimeout(peekIn, PEEK_CONFIG.loopInterval);
  };

  root.addEventListener('mouseenter', handleEngage);
  root.addEventListener('mouseleave', handleDisengage);
  root.addEventListener('touchstart', handleEngage, { passive: true });

  loopTimer = window.setTimeout(peekIn, PEEK_CONFIG.peekDelay);

  return () => {
    clearTimers();
    engaged = true;
    panel.style.transition = '';
    panel.style.transform = '';
    root.removeEventListener('mouseenter', handleEngage);
    root.removeEventListener('mouseleave', handleDisengage);
    root.removeEventListener('touchstart', handleEngage);
  };
}

// --- Variant C: Chevron Pulse ---
const CHEVRON_CONFIG = {
  chevronCount: 3,
  animDuration: 1800,
  animDelay: 180,
  travelDistance: 7,
  baseOpacities: [1, 0.65, 0.3]
};

const CHEVRON_SVG = `<svg xmlns="http://www.w3.org/2000/svg" width="12" height="18" viewBox="0 0 12 18" fill="none"><path d="M2 2l8 7-8 7" stroke="rgba(0,0,0,0.5)" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/></svg>`;

function runChevronPulse(root: HTMLElement, _panel: HTMLElement, onEngage: () => void): () => void {
  const prevPosition = root.style.position;
  root.style.position = 'relative';

  const wrapper = document.createElement('div');
  wrapper.className = 'gc-hint-chevrons';
  wrapper.setAttribute('aria-hidden', 'true');

  const style = document.createElement('style');
  style.textContent = `
    .gc-hint-chevrons {
      position: absolute;
      left: 10px;
      top: 50%;
      transform: translateY(-50%);
      z-index: 7;
      pointer-events: none;
      transition: opacity 0.3s;
      display: flex;
      align-items: center;
    }
    .gc-hint-chevron {
      position: absolute;
      top: 0;
      left: 0;
      display: flex;
      align-items: center;
      animation: gc-hint-chevron-pulse ${CHEVRON_CONFIG.animDuration}ms ease-in-out infinite;
    }
    @keyframes gc-hint-chevron-pulse {
      0% { opacity: 0; transform: translateX(0); }
      20% { opacity: var(--gc-hint-chevron-opacity); }
      50% { opacity: var(--gc-hint-chevron-opacity); transform: translateX(${CHEVRON_CONFIG.travelDistance}px); }
      80% { opacity: 0; transform: translateX(${CHEVRON_CONFIG.travelDistance}px); }
      100% { opacity: 0; transform: translateX(0); }
    }
  `;

  for (let i = 0; i < CHEVRON_CONFIG.chevronCount; i++) {
    const chevron = document.createElement('div');
    chevron.className = 'gc-hint-chevron';
    chevron.innerHTML = CHEVRON_SVG;
    chevron.style.setProperty('--gc-hint-chevron-opacity', String(CHEVRON_CONFIG.baseOpacities[i]));
    chevron.style.animationDelay = `${i * CHEVRON_CONFIG.animDelay}ms`;
    chevron.style.left = `${i * 10}px`;
    wrapper.appendChild(chevron);
  }

  root.appendChild(style);
  root.appendChild(wrapper);

  const handleEngage = () => {
    wrapper.style.opacity = '0';
    onEngage();
  };

  root.addEventListener('mouseenter', handleEngage);
  root.addEventListener('touchstart', handleEngage, { passive: true });

  return () => {
    root.removeEventListener('mouseenter', handleEngage);
    root.removeEventListener('touchstart', handleEngage);
    wrapper.remove();
    style.remove();
    root.style.position = prevPosition;
  };
}

// --- Variant D: Swipe Ghost ---
const GHOST_CONFIG = {
  travelDistance: 200,
  cycleDuration: 3800,
  fadeInEnd: 12,
  sweepEnd: 62,
  fadeOutEnd: 78,
  trailMaxWidth: 48
};

const HAND_SVG = `<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="rgba(0,0,0,0.45)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M8 14.5V8a2.5 2.5 0 0 1 5 0v5"/><path d="M13 12.5a2 2 0 0 1 4 0v1.5"/><path d="M17 13.5a2 2 0 0 1 4 0V16a8 8 0 0 1-8 8h-1a8 8 0 0 1-6.73-3.67L3.1 17.1A1.5 1.5 0 0 1 5.66 15L8 17"/><path d="M5 2l3 3M2 5l3 3" opacity="0.5"/></svg>`;

function runSwipeGhost(root: HTMLElement, _panel: HTMLElement, onEngage: () => void): () => void {
  const prevPosition = root.style.position;
  root.style.position = 'relative';

  const wrapper = document.createElement('div');
  wrapper.className = 'gc-hint-ghost';
  wrapper.setAttribute('aria-hidden', 'true');

  const trail = document.createElement('div');
  trail.className = 'gc-hint-ghost-trail';

  const hand = document.createElement('div');
  hand.className = 'gc-hint-ghost-hand';
  hand.innerHTML = HAND_SVG;

  wrapper.appendChild(trail);
  wrapper.appendChild(hand);

  const style = document.createElement('style');
  style.textContent = `
    .gc-hint-ghost {
      position: absolute;
      left: 0;
      top: 50%;
      transform: translateY(-50%);
      z-index: 7;
      pointer-events: none;
      transition: opacity 0.3s;
    }
    .gc-hint-ghost-hand {
      position: relative;
      animation: gc-hint-ghost-sweep ${GHOST_CONFIG.cycleDuration}ms ease-in-out infinite;
    }
    .gc-hint-ghost-trail {
      position: absolute;
      top: 50%;
      left: 12px;
      height: 2px;
      background: linear-gradient(to right, transparent, rgba(0,0,0,0.2));
      transform: translateY(-50%);
      animation: gc-hint-ghost-trail ${GHOST_CONFIG.cycleDuration}ms ease-in-out infinite;
    }
    @keyframes gc-hint-ghost-sweep {
      0% { transform: translateX(10px); opacity: 0; }
      ${GHOST_CONFIG.fadeInEnd}% { opacity: 0.9; }
      ${GHOST_CONFIG.sweepEnd}% { transform: translateX(${GHOST_CONFIG.travelDistance}px); opacity: 0.9; }
      ${GHOST_CONFIG.fadeOutEnd}% { transform: translateX(${GHOST_CONFIG.travelDistance}px); opacity: 0; }
      100% { transform: translateX(10px); opacity: 0; }
    }
    @keyframes gc-hint-ghost-trail {
      0% { width: 0; opacity: 0; }
      ${GHOST_CONFIG.fadeInEnd}% { opacity: 0.6; }
      ${GHOST_CONFIG.sweepEnd}% { width: ${GHOST_CONFIG.trailMaxWidth}px; opacity: 0.6; }
      ${GHOST_CONFIG.fadeOutEnd}% { width: ${GHOST_CONFIG.trailMaxWidth}px; opacity: 0; }
      100% { width: 0; opacity: 0; }
    }
  `;

  root.appendChild(style);
  root.appendChild(wrapper);

  const handleEngage = () => {
    wrapper.style.opacity = '0';
    onEngage();
  };

  root.addEventListener('mouseenter', handleEngage);
  root.addEventListener('touchstart', handleEngage, { passive: true });

  return () => {
    root.removeEventListener('mouseenter', handleEngage);
    root.removeEventListener('touchstart', handleEngage);
    wrapper.remove();
    style.remove();
    root.style.position = prevPosition;
  };
}

// --- Main Hook ---
const VARIANT_RUNNERS: Record<HintVariant, typeof runCardPeek> = {
  B: runCardPeek,
  C: runChevronPulse,
  D: runSwipeGhost
};

function isHintVariant(v: string): v is HintVariant {
  return v in VARIANT_RUNNERS;
}

const EDGE_PEEK_PX = 48;
const PEEK_CLASS = 'gc-hint-edge-peek';

export function useOverlayHintAnimation(
  rootRef: preact.RefObject<HTMLElement>,
  panelSelector: string,
  variant: string | undefined | null
) {
  useEffect(() => {
    const root = rootRef.current;
    if (!root || !variant || !isHintVariant(variant)) return;

    const panel = root.querySelector<HTMLElement>(panelSelector);
    if (!panel) return;

    const style = document.createElement('style');
    style.textContent = `.str-adunit-overlay ${panelSelector}.${PEEK_CLASS}:not(.is-open) { transform: translateX(calc(-100% + ${EDGE_PEEK_PX}px)); }`;
    document.head.appendChild(style);

    // Set peek position instantly (skip the base CSS transition)
    const prevTransition = panel.style.transition;
    panel.style.transition = 'none';
    panel.classList.add(PEEK_CLASS);
    panel.getBoundingClientRect(); // force reflow
    panel.style.transition = prevTransition;

    const cleanupRunner = VARIANT_RUNNERS[variant](root, panel, () => {
      /* noop — engagement tracked by useOverlayHoverTracker */
    });

    return () => {
      cleanupRunner();
      panel.classList.remove(PEEK_CLASS);
      style.remove();
    };
  }, [rootRef, panelSelector, variant]);
}
