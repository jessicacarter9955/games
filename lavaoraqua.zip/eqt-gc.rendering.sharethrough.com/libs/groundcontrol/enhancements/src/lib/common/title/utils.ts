import type { GCEnhancementPayload } from '@sharethrough/groundcontrol-enhancement-flush';
import type { NativeAssets } from '@web-rendering/groundcontrol-ortb';

export const getEnhancementTitle = (payload: GCEnhancementPayload['payload'] | undefined): string | null => {
  if (!payload || !('title' in payload) || typeof payload.title !== 'string') return null;

  return payload.title;
};

export const getAssetsTitle = (assets: NativeAssets | undefined | null): string | null => {
  if (!assets) return null;

  return assets?.title?.title.text || null;
};
