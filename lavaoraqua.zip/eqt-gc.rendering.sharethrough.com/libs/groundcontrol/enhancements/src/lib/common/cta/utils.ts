import type { PublisherStyles } from '@ad-rendering/publisher-style';
import type { GCEnhancementPayload } from '@sharethrough/groundcontrol-enhancement-flush';
import type { NativeAssets } from '@web-rendering/groundcontrol-ortb';
import type { RefObject } from 'preact';
import { useEffect, useState } from 'preact/hooks';

export const getEnhancementCtaText = (payload: GCEnhancementPayload['payload'] | undefined): string | null => {
  if (!payload || !('cta' in payload) || typeof payload.cta !== 'object') return null;

  return payload.cta.text;
};

export const getAssetsCtaText = (assets: NativeAssets | undefined | null): string | null => {
  if (!assets) return null;
  return assets?.cta?.data?.value || null;
};

export const getStyle = (payload: GCEnhancementPayload['payload'] | undefined, styles?: PublisherStyles) => {
  if (typeof payload === 'object' && 'cta' in payload && typeof payload.cta === 'object' && payload.cta !== null) {
    const cta = payload.cta;

    const payloadStyles: { [key: string]: string | undefined } = {
      '--cta-text-color':
        typeof cta === 'object' && 'textColor' in cta && typeof cta.textColor === 'string' ? cta.textColor : undefined,
      '--cta-background-color':
        typeof cta === 'object' && 'backgroundColor' in cta && typeof cta.backgroundColor === 'string'
          ? cta.backgroundColor
          : undefined,
      '--cta-text-hover-color':
        typeof cta === 'object' && 'textHoverColor' in cta && typeof cta.textHoverColor === 'string'
          ? cta.textHoverColor
          : undefined,
      '--cta-background-hover-color':
        typeof cta === 'object' && 'backgroundHoverColor' in cta && typeof cta.backgroundHoverColor === 'string'
          ? cta.backgroundHoverColor
          : undefined
    };
    return Object.fromEntries(Object.entries(payloadStyles).filter(([_, value]) => value !== undefined));
  }

  if (styles && styles.cta) {
    const { cta } = styles;

    const publisherStyles: { [key: string]: string | undefined } = {
      '--cta-text-color': cta.font?.color,
      '--cta-background-color': cta.background?.color,
      '--cta-text-hover-color': cta.font?.hoverColor,
      '--cta-background-hover-color': cta.background?.hoverColor,
      '--cta-border-width': cta.border?.width ? `${cta.border.width}px` : undefined,
      '--cta-border-color': cta.border?.color,
      '--cta-border-style': cta.border?.style,
      '--cta-border-radius': cta.border?.radius !== undefined ? `${cta.border.radius}px` : undefined
    };
    return Object.fromEntries(Object.entries(publisherStyles).filter(([_, value]) => value !== undefined));
  }

  return {};
};

export const useTextOverflow = (spanRef: RefObject<HTMLSpanElement>, width: number): boolean => {
  const [textOverflow, setTextOverflow] = useState(false);

  useEffect(() => {
    if (!spanRef.current) return;

    const textWidth = spanRef.current.clientWidth;
    const divWidth = spanRef.current.parentElement?.clientWidth || 0;

    if (divWidth - textWidth < width) {
      setTextOverflow(true);
    }
  }, [spanRef, width]);

  return textOverflow;
};
