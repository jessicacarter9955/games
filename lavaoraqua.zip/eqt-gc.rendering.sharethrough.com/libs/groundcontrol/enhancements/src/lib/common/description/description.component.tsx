import type { FunctionalComponent } from 'preact';
import './description.scss';
import { useRef } from 'preact/hooks';
import { useClampMaxHeight } from '../utils';
import type { TextProps } from '../type';
import { clsx } from 'clsx';

const Description: FunctionalComponent<TextProps> = ({ text, publisherStyles }) => {
  const descriptionRef = useRef<HTMLDivElement | null>(null);

  useClampMaxHeight(descriptionRef, publisherStyles);

  let fontStyle = publisherStyles?.description?.font?.toStyle();
  const backgroundStyle = publisherStyles?.description?.background?.toStyle();

  const hoverColor = publisherStyles?.description?.font?.hoverColor;

  if (hoverColor) {
    const { color: _, ...fontStyleWithoutColor } = fontStyle || {};
    fontStyle = {
      ...fontStyleWithoutColor,
      '--hover-color': hoverColor
    };
  }

  return (
    <div className={clsx('gc-description', publisherStyles && 'str-enhanced-description')}>
      <span style={{ ...fontStyle, ...backgroundStyle }} title={text} ref={descriptionRef}>
        {text}
      </span>
    </div>
  );
};

export default Description;
