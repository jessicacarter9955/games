import type { FunctionalComponent } from 'preact';
import { Advertiser } from '../advertiser/advertiser.component';
import { CallToAction } from '../cta/cta.component';
import './footer.scss';
import type { EnhancementFooterProps } from './type';
import { useEnhancementFooterData } from '../../headline/enhancement-data.util';
import { hideAsset } from '../utils';

export const EnhancementFooter: FunctionalComponent<EnhancementFooterProps> = ({
  assets,
  enhancement,
  publisherStyles,
  hideAdvertiser,
  hideCallToAction
}) => {
  const { advertiser, ctaText, ctaStyle } = useEnhancementFooterData({
    assets,
    enhancement,
    publisherStyles
  });

  const hideAdv =
    hideAdvertiser || !advertiser || hideAsset(publisherStyles?.promotedBy?.hide, !assets?.sponsored?.data.value);
  const hideCta = hideCallToAction || !ctaText || hideAsset(publisherStyles?.cta?.hide, !assets?.cta?.data.value);

  return (
    <div className="gc-bottom str-enhancement-footer">
      {hideAdv ? <div /> : <Advertiser publisherStyles={publisherStyles} advertiser={advertiser} />}
      {hideCta ? <div /> : <CallToAction ctaText={ctaText} ctaStyle={ctaStyle} />}
    </div>
  );
};
