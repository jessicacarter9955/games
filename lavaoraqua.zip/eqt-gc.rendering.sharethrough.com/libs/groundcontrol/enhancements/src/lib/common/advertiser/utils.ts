import type { GCEnhancementPayload } from '@sharethrough/groundcontrol-enhancement-flush';
import type { NativeAssets } from '@web-rendering/groundcontrol-ortb';

export const getEnhancementAdvertiser = (
  payload: GCEnhancementPayload['payload'] | undefined
): { name: string; promotedByText: string; brandLogoUrl?: string } | null | undefined => {
  if (!payload || !('advertiser' in payload) || typeof payload.advertiser !== 'object') return;

  if (payload.advertiser === null) return null;

  const {
    // nested destructuring to extract advertiser properties
    advertiser: { name, promotedByText, brandLogoUrl }
  } = payload;

  return { name, promotedByText, brandLogoUrl };
};

export const getAssetsAdvertiser = (
  assets?: NativeAssets | null
): { name: string; promotedByText: string; brandLogoUrl?: string } | null => {
  if (!assets) return null;

  const name = assets?.sponsored?.data.value;
  const brandLogoUrl = getAssetBrandLogo(assets);

  return {
    name: name || '',
    promotedByText: '',
    brandLogoUrl: brandLogoUrl || undefined
  };
};

const getAssetBrandLogo = (assets: NativeAssets) => {
  const mainImageUrl = assets?.mainImage?.img.url;
  const iconUrl = assets?.icon?.img.url;

  const isMatch = mainImageUrl === iconUrl;
  if (isMatch || !iconUrl) return null;

  return iconUrl;
};
