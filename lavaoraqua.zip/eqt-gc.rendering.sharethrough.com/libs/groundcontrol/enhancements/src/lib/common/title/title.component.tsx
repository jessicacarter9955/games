import type { FunctionalComponent } from 'preact';
import type { CSSProperties } from 'preact/compat';
import { useRef } from 'preact/compat';
import { useClampMaxHeight } from '../utils';
import './title.scss';
import type { TextProps } from '../type';
import { clsx } from 'clsx';

const Title: FunctionalComponent<TextProps> = ({ text, publisherStyles }) => {
  const titleRef = useRef<HTMLDivElement | null>(null);

  useClampMaxHeight(titleRef, publisherStyles);

  const backgroundStyle: CSSProperties | undefined = publisherStyles?.title?.background?.toStyle();

  let fontStyle: CSSProperties | undefined = publisherStyles?.title?.font?.toStyle();
  const hoverColor = publisherStyles?.title?.font?.hoverColor;

  if (hoverColor) {
    const { color: _, ...fontStyleWithoutColor } = fontStyle || {};
    fontStyle = {
      ...fontStyleWithoutColor,
      '--hover-color': hoverColor
    };
  }

  return (
    <div className={clsx('gc-title', publisherStyles && 'str-enhanced-title')}>
      <span title={text} ref={titleRef} style={{ ...fontStyle, ...backgroundStyle }}>
        {text}
      </span>
    </div>
  );
};

export default Title;
