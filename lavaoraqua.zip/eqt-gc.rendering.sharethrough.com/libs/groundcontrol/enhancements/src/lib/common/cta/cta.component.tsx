import type { FunctionComponent } from 'preact';
import { useRef } from 'preact/hooks';
import './cta.scss';
import { useTextOverflow } from './utils';
import { I18N, useTranslation } from '@web-rendering/groundcontrol-i18n';

interface SimplifiedCallToActionProps {
  ctaText: string;
  ctaStyle: { [key: string]: string | undefined };
}

export const CallToAction: FunctionComponent<SimplifiedCallToActionProps> = ({ ctaText, ctaStyle }) => {
  const { t } = useTranslation();

  const spanRef = useRef<HTMLSpanElement>(null);
  const textOverflow = useTextOverflow(spanRef, 10);

  return (
    <div>
      <div className="gc-cta" style={ctaStyle}>
        <span ref={spanRef}>{textOverflow ? t(I18N.CTA_TEXT) : ctaText}</span>
      </div>
    </div>
  );
};
