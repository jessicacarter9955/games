import type { FunctionComponent } from 'preact';
import type { PriceProps } from './type';
import './price.scss';

export const Price: FunctionComponent<PriceProps> = ({ price }) => {
  if (!price) return null;

  const match = price.data.value.match(/([$€£¥]?)(\d+)\.(\d+)/);
  if (!match) return null;

  const [, currency, whole, fraction] = match;
  if (!currency || !whole || !fraction) return null;

  return (
    <div className="gc-price">
      <div className="gc-price-currency">{currency}</div>
      <div className="gc-price-amount">{whole}</div>
      <div className="gc-price-decimal">{fraction}</div>
    </div>
  );
};
