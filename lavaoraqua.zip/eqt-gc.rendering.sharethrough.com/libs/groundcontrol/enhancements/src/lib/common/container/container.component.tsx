import { I18NProvider } from '@web-rendering/groundcontrol-i18n';
import { clsx } from 'clsx';
import { type FunctionalComponent } from 'preact';
import { DefaultHeadlineEnhancement } from '../../headline/default.enhancement';
import { EnhancementClickEventType } from '../type';
import { enhancementFallback } from '../utils';
import './container.scss';
import type { IEnhancementContainer } from './type.ts';

export const EnhancementContainer: FunctionalComponent<IEnhancementContainer> = ({
  assets,
  children,
  className,
  enhancement,
  enhancementLoaded,
  language,
  onClick,
  onError,
  onLoad,
  publisherStyles,
  style
}) => {
  const fallbackEnhancement = enhancementFallback(enhancement);

  if (enhancementLoaded === undefined) return null;

  return (
    <I18NProvider language={language}>
      <div
        className={clsx(
          className,
          'gc-enhancement-main-container',
          enhancement.type && `gc-enhancement-main-container-${enhancement.type}`,
          !enhancementLoaded && 'gc-enhancement-main-container-fallback'
        )}
        onClick={() => {
          onClick({
            enhancementType: enhancementLoaded ? enhancement.type : fallbackEnhancement.type,
            eventType: EnhancementClickEventType.CONTENT
          });
        }}
        style={style}
      >
        <div className="gc-enhancement-container">
          {enhancementLoaded ? (
            children
          ) : (
            <DefaultHeadlineEnhancement
              publisherStyles={publisherStyles}
              assets={assets}
              enhancement={fallbackEnhancement}
              fallback={true}
              onLoad={onLoad}
              onClick={onClick}
              onError={onError}
            />
          )}
        </div>
      </div>
    </I18NProvider>
  );
};
