import type { DataAsset } from '@web-rendering/groundcontrol-shared-types/assets';

export interface RatingProps {
  rating?: DataAsset;
}

export enum StarType {
  Full = 'full',
  Half = 'half',
  Empty = 'empty'
}

export interface StarProps {
  type: StarType;
}
