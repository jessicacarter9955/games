import { useEffect, useState } from 'preact/hooks';
import { extractPrimaryColorFromBanner, observeIframeForColor } from '../../../headline/utils/color-extraction';
import { calculateTextColor, generateLightTint } from '../../../headline/utils/text-contrast';

const HEADLINE_ALT_CLASS = 'gc-exp-headline-alt';

export function useExtractedColors(className?: string): {
  textColor?: string;
  secondaryColor?: string;
  backgroundColor?: string;
} {
  const [extractedColor, setExtractedColor] = useState<string | null>(null);

  const isActive = !!className && className.includes(HEADLINE_ALT_CLASS);

  useEffect(() => {
    if (!isActive) return;

    let isMounted = true;

    let stopObserving: (() => void) | null = null;

    const extractColor = async () => {
      try {
        const result = await extractPrimaryColorFromBanner({ timeout: 3000, minConfidence: 0.5 });
        if (isMounted && result.confidence >= 0.5) {
          setExtractedColor(result.color);
          return;
        }
      } catch {
        // Color extraction failed
      }

      // Initial extraction missed — observe iframe for late-loading images
      if (isMounted) {
        stopObserving = observeIframeForColor((result) => {
          if (isMounted && result.confidence >= 0.5) {
            setExtractedColor(result.color);
          }
        });
      }
    };

    extractColor();

    return () => {
      isMounted = false;
      stopObserving?.();
    };
  }, [isActive]);

  // Don't apply color experiment when extraction failed — fall back to default appearance
  if (!isActive || !extractedColor) {
    return { textColor: undefined, secondaryColor: undefined, backgroundColor: undefined };
  }

  // Wrap color derivation in try-catch to prevent render crashes from unexpected inputs
  try {
    const secondaryColor = generateLightTint(extractedColor, 0.4);
    const textColor = calculateTextColor(extractedColor);

    return { textColor, secondaryColor, backgroundColor: extractedColor };
  } catch {
    return { textColor: undefined, secondaryColor: undefined, backgroundColor: undefined };
  }
}
