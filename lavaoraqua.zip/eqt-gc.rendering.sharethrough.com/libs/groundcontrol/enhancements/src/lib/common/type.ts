import type { PublisherStyles } from '@ad-rendering/publisher-style';
import type {
  BannerCountdownPayload,
  BannerHeadlinePayload,
  OutstreamCaptionsPayload,
  OutstreamCountdownPayload,
  OutstreamHeadlinePayload,
  TemplateUrlEnhancementPayload,
  WeatherPayload
} from '@sharethrough/groundcontrol-enhancement-flush';
import type { ValidEnhancementType } from '@web-rendering/groundcontrol-shared-types';
import type { SupportedLanguage } from '@web-rendering/groundcontrol-i18n';
import type { NativeAssets } from '@web-rendering/groundcontrol-ortb';
import type { RemoteEventType } from '../remote/type';

export enum EnhancementClickEventType {
  CLICKTHROUGH = 'enhancement_click_through',
  CONTENT = 'enhancement_content',
  ENGAGEMENT = 'enhancement_engagement',
  SHOPPABLECAROUSEL_ARROW = 'enhancement_shoppable_carousel_arrow',
  PRODUCTCARD = 'enhancement_product_card'
}

export interface EnhancementLoadedEvent {
  enhancementType: ValidEnhancementType;
  fallback?: boolean;
}

export interface EnhancementErrorEvent {
  error: Error;
  data?: unknown;
  /** The page or its host failed, not us — count it, but keep it out of error reporting. */
  isPageFailure?: boolean;
}

export interface EnhancementClickEvent {
  enhancementType: ValidEnhancementType;
  eventType: EnhancementClickEventType;
  productId?: string;
}

export interface IEnhancementEvents {
  onLoad: (event: EnhancementLoadedEvent) => void;
  onClick: (event: EnhancementClickEvent) => void;
  onError: (event: EnhancementErrorEvent) => void;
}

export interface RemoteComponentProps<T> extends EnhancementComponentProps<T> {
  onLifecycleChange: (
    event: RemoteEventType.Initialized | RemoteEventType.HealthCheckOk | RemoteEventType.HealthCheckFail
  ) => void;
  /**
   * HEAD the template url before mounting the iframe. Only catches a template service answering
   * "nothing to serve right now" with a 204 — every other bad status is caught by the GET.
   */
  hasPreflight?: boolean;
}

export type FallbackEnhancementPayload =
  | (Omit<BannerHeadlinePayload, 'payload'> & { payload?: BannerHeadlinePayload['payload'] })
  | (Omit<OutstreamHeadlinePayload, 'payload'> & { payload?: OutstreamHeadlinePayload['payload'] });

export interface EnhancementComponentProps<T> extends EnhancementCommonComponentPropsBase<T>, IEnhancementEvents {
  language?: SupportedLanguage;
}

export interface EnhancementCommonComponentPropsBase<T> {
  assets?: NativeAssets | null;
  enhancement: T;
  publisherStyles?: PublisherStyles;
  className?: string;
}

export type EnhancementType =
  | BannerCountdownPayload
  | BannerHeadlinePayload
  | OutstreamCaptionsPayload
  | OutstreamCountdownPayload
  | OutstreamHeadlinePayload
  | TemplateUrlEnhancementPayload
  | WeatherPayload
  | FallbackEnhancementPayload;

export interface TextProps {
  text: string;
  publisherStyles?: PublisherStyles;
}
