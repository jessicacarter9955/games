import type { FunctionComponent } from 'preact';
import { type RatingProps, StarType } from './type';
import './rating.scss';

export const RatingStars: FunctionComponent<RatingProps> = ({ rating }) => {
  if (!rating) return null;

  const ratingValue = parseFloat(rating.data.value);
  if (isNaN(ratingValue) || ratingValue < 0) return null;

  const stars = Array.from({ length: 5 }, (_, index) => {
    const type = index < Math.floor(ratingValue) ? StarType.Full : index < ratingValue ? StarType.Half : StarType.Empty;

    return (
      <span key={index} class={`gc-star gc-star-${type}`}>
        ★
      </span>
    );
  });

  return <div className="gc-rating-stars">{stars}</div>;
};
