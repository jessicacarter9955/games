import type { FunctionalComponent } from 'preact';
import { Fragment } from 'preact';
import WeatherDay from '../day/weather-day.component';
import type { Weather } from '../models';

const WEEKLY_FORECAST_DAYS = 5;

interface ThreeDaysProps {
  weatherData: Weather | undefined;
}

const WeatherForecastWeek: FunctionalComponent<ThreeDaysProps> = ({ weatherData }) => {
  const props = { city: weatherData?.city, type: weatherData?.type };
  const days = weatherData?.forecast?.slice(0, WEEKLY_FORECAST_DAYS) ?? [];
  const [first, ...rest] = days;

  const mainClass = 'str-weather-container-main';
  const infoClass = 'str-weather-container-information';

  return (
    <Fragment>
      <div className="str-weather-main">
        <WeatherDay className={mainClass} {...props} forecast={first} />
      </div>
      <div className="str-weather-information">
        {rest.map((day) => (
          <WeatherDay key={day.time} className={infoClass} {...props} forecast={day} />
        ))}
      </div>
    </Fragment>
  );
};

export default WeatherForecastWeek;
