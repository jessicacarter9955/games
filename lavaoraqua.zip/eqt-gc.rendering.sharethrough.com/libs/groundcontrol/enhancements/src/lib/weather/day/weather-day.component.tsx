import { stringToClassName } from '@web-rendering/groundcontrol-utils';
import type { FunctionalComponent } from 'preact';
import { useRef } from 'preact/hooks';
import type { Forecast } from '../models';
import type { WeatherDegreesType } from '../types';
import { WeatherIcon } from '../weather-icons.component';
import './weather-day.scss';
import { clsx } from 'clsx';

interface WeatherDayProps {
  city: string | undefined;
  forecast: Forecast | undefined;
  type: WeatherDegreesType | undefined;
  className?: string;
}

const MapMarkerIcon = () => {
  return (
    <svg
      role="img"
      aria-label="Map marker icon"
      width="19"
      height="19"
      viewBox="0 0 19 19"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className="str-map-marker"
    >
      <path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M15.125 6.6875C15.125 3.5809 12.6066 1.0625 9.5 1.0625C6.3934 1.0625 3.875 3.5809 3.875 6.6875C3.875 9.24275 7.6805 15.65 9.03125 17.6863C9.13547 17.8434 9.31146 17.9378 9.5 17.9378C9.68854 17.9378 9.86453 17.8434 9.96875 17.6863C11.3195 15.65 15.125 9.24275 15.125 6.6875ZM12.3125 6.6875C12.3125 8.2408 11.0533 9.5 9.5 9.5C7.9467 9.5 6.6875 8.2408 6.6875 6.6875C6.6875 5.1342 7.9467 3.875 9.5 3.875C11.0533 3.875 12.3125 5.1342 12.3125 6.6875Z"
        fill="#ffffff"
      />
    </svg>
  );
};

const WeatherDay: FunctionalComponent<WeatherDayProps> = ({ city, forecast, type, className }) => {
  const refMain = useRef<HTMLDivElement>(null);

  if (!forecast || !city || !type) {
    return (
      <div className="str-weather-container">
        <span className="loading"></span>
      </div>
    );
  }

  const { description, icon, temperature, temperatureMax, temperatureMin, dayName, main } = forecast;

  return (
    <div
      ref={refMain}
      className={clsx('str-weather-container', `str-weather-container-${stringToClassName(main)}`, className)}
    >
      <div className="str-city">
        <MapMarkerIcon />
        <div>{city}</div>
      </div>
      <div className="str-forecast">
        <span className="str-forecast-weekday">{dayName}</span>
        <span> {description}</span>
      </div>
      <div className="str-information-container">
        <div className="str-forecast-icon">
          <WeatherIcon icon={icon} />
          <div className="str-forecast str-forecast-condensed">
            <div className="str-forecast-city">{city}</div>
            <span className="str-forecast-weekday">{dayName},</span>
            <span className="str-forecast-description"> {description}</span>
          </div>
        </div>
        <div className="str-temperature">
          {temperature}°<span>{type}</span>
        </div>
        <div className="str-temperature-variation">
          <div className="str-temperature-high">
            <span className="icon icon-up"></span>
            <span>{temperatureMax}°</span>
          </div>
          <div className="str-temperature-low">
            <span className="icon icon-down"></span>
            <span>{temperatureMin}°</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default WeatherDay;
