export enum WeatherDegreesType {
  Fahrenheit = 'F',
  Celsius = 'C'
}
