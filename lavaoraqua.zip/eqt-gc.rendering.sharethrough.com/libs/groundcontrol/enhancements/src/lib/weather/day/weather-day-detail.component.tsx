import type { FunctionalComponent } from 'preact';
import { useRef } from 'preact/hooks';
import { WeatherIcon } from '../weather-icons.component';
import './weather-day.scss';

interface WeatherHumidityProps {
  value: string | number | undefined;
  icon: string | undefined;
  className: string | undefined;
  description: string | undefined;
}

const WeatherDayDetail: FunctionalComponent<WeatherHumidityProps> = ({ value, icon, className, description }) => {
  const refMain = useRef<HTMLDivElement>(null);

  if (!value || !icon || !className || !description) {
    return (
      <div className="str-weather-container">
        <span className="loading"></span>
      </div>
    );
  }
  return (
    <div ref={refMain} className={`str-weather-container str-weather-container-${className}`}>
      <div className="str-information-container">
        <div className="str-forecast-icon">
          <WeatherIcon icon={icon} />
          <div className="str-forecast str-forecast-condensed">
            <span className="str-forecast-weekday">{description}</span>
          </div>
        </div>
        <div className="str-information">{value}</div>
      </div>
    </div>
  );
};

export default WeatherDayDetail;
