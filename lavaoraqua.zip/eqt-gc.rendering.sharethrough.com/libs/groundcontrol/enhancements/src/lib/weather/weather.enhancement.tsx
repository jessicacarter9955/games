import { useErrorHandler } from '@web-rendering/groundcontrol-core';
import { GCEnhancementType } from '@sharethrough/groundcontrol-enhancement-flush';
import type { WeatherPayload } from '@sharethrough/groundcontrol-enhancement-flush/src/lib/interface/weather-payload.interface';
import type { FunctionComponent } from 'preact';
import { useEffect } from 'preact/hooks';
import { EnhancementContainer } from '../common/container/container.component';
import type { EnhancementComponentProps } from '../common/type';
import WeatherForecastDetails from './forecast/forecast-details.component';
import WeatherForecastWeek from './forecast/forecast-week.component';
import { useWeatherData } from './utils';
import { WeatherIconsProvider } from './weather-icons-context';
import './weather.scss';
import { SupportedLanguage } from '@web-rendering/groundcontrol-i18n';
import { clsx } from 'clsx';

export const WeatherEnhancement: FunctionComponent<EnhancementComponentProps<WeatherPayload>> = ({
  enhancement,
  language,
  onClick,
  onError,
  onLoad,
  publisherStyles
}) => {
  const [error] = useErrorHandler('Weather Component Error');

  const isWeeklyForecast =
    enhancement?.type === GCEnhancementType.BannerWeather || enhancement?.type === GCEnhancementType.OutstreamWeather;

  const [weatherData, icons, weatherDataError, isLoading] = useWeatherData(
    language || SupportedLanguage.ENGLISH,
    isWeeklyForecast,
    enhancement?.payload.coordinates,
    enhancement?.payload.units
  );

  const enhancementLoaded = !error && !weatherDataError;
  useEffect(() => {
    if (isLoading) return;

    if (error || weatherDataError) {
      const source = error ?? weatherDataError;
      onError({
        error: new Error(source?.message ?? 'Weather data is not available'),
        data: source
      });
    } else {
      onLoad({
        enhancementType: enhancement.type
      });
    }
  }, [weatherData, weatherDataError, isLoading, error, onError, onLoad]);

  return (
    <EnhancementContainer
      className={clsx('str-enhanced-info', enhancementLoaded && 'weather')}
      enhancement={enhancement}
      enhancementLoaded={enhancementLoaded}
      language={language}
      onClick={onClick}
      onError={onError}
      onLoad={onLoad}
      publisherStyles={publisherStyles}
    >
      {!isLoading && weatherData && (
        <WeatherIconsProvider icons={icons}>
          <div className="str-weather">
            {isWeeklyForecast ? (
              <WeatherForecastWeek weatherData={weatherData} />
            ) : (
              <WeatherForecastDetails weatherData={weatherData} />
            )}
          </div>
        </WeatherIconsProvider>
      )}
    </EnhancementContainer>
  );
};
