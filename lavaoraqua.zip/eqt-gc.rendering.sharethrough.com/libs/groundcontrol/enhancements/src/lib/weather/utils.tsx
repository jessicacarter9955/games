import type { GCWeatherUnit } from '@sharethrough/groundcontrol-enhancement-flush/src/lib/constants';
import type { SupportedLanguage } from '@web-rendering/groundcontrol-i18n';
import { useEffect, useMemo, useState } from 'preact/hooks';
import { fetchWeatherIcons } from './fetch-weather-icons';
import { Weather } from './models';
import { useLifecycleScope } from '@web-rendering/groundcontrol-core';

const DAILY_DETAIL_ICONS = ['humidity', 'air', 'wind', 'uv'] as const;

const WEATHER_HARDCODED_URLS = ['playground.rendering.sharethrough.com', 'chromatic.com'];

interface WeatherRequest {
  url: string;
  method: 'GET' | 'POST';
  headers: boolean;
  body: boolean;
}

// to use hardcoded weather data only in RPG
const getWeatherRequest = (): WeatherRequest => {
  let origin: string | null = null;

  try {
    origin = window.top?.location?.origin || window.location.origin;
  } catch {
    // silent fail, do nothing
  }

  if (origin && WEATHER_HARDCODED_URLS.some((url) => origin.includes(url))) {
    return {
      url: '/assets/json/weather.json',
      method: 'GET',
      headers: false,
      body: false
    };
  }

  return {
    url: 'https://cdn.rendering.sharethrough.com/weather',
    method: 'POST',
    headers: true,
    body: true
  };
};

export const useWeatherData = (
  language: SupportedLanguage,
  isWeeklyForecast: boolean,
  coordinates?: string | string[],
  units?: GCWeatherUnit
): [Weather | null, Map<string, string>, Error | null, boolean] => {
  const [weatherData, setWeatherData] = useState<Weather | null>(null);
  const [icons, setIcons] = useState<Map<string, string>>(new Map());
  const [error, setError] = useState<Error | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  const request = useMemo(() => getWeatherRequest(), []);
  const scope = useLifecycleScope();

  useEffect(() => {
    let isMounted = true;

    const jsonBodyRequest = JSON.stringify({
      coordinates,
      units,
      lang: language
    });

    const fetchWeatherData = async () => {
      try {
        const response = await fetch(request.url, {
          method: request.method,
          ...(request.headers
            ? {
                headers: {
                  'Content-Type': 'application/json'
                }
              }
            : {}),
          ...(request.body
            ? {
                body: jsonBodyRequest
              }
            : {})
        });

        if (!response.ok) {
          throw new Error(`Weather API error: ${response.status}`);
        }

        const jsonResponse = await response.json();

        if (jsonResponse && isMounted) {
          const weather = new Weather(jsonResponse, language);
          setWeatherData(weather);
          setError(null);

          const iconCodes = isWeeklyForecast
            ? weather.forecast.slice(0, 5).map((f) => f.icon)
            : [weather.forecast[0]?.icon, ...DAILY_DETAIL_ICONS].filter(Boolean);
          const iconMap = await fetchWeatherIcons(iconCodes, scope);
          if (isMounted) {
            setIcons(iconMap);
          }
        } else if (isMounted) {
          setError(new Error('Weather data is null'));
        }
      } catch (err) {
        if (isMounted) {
          setError(err instanceof Error ? err : new Error('Failed to fetch weather data'));
        }
      } finally {
        if (isMounted) {
          setIsLoading(false);
        }
      }
    };

    fetchWeatherData();

    return () => {
      isMounted = false;
    };
  }, [coordinates, units, language, isWeeklyForecast, request.url, request.method, request.headers, request.body]);

  return [weatherData, icons, error, isLoading];
};
