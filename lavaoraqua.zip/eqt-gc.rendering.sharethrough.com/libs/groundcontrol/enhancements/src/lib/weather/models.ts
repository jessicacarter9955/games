import type { SupportedLanguage } from '@web-rendering/groundcontrol-i18n';
import { WeatherDegreesType } from './types';

export class Weather {
  lat: number;
  lon: number;
  city: string;
  aqi: number;
  forecast: Forecast[];
  type: WeatherDegreesType;

  /* eslint-disable-next-line @typescript-eslint/no-explicit-any */
  constructor(apiResponse: any, language: SupportedLanguage) {
    this.lat = apiResponse.lat;
    this.lon = apiResponse.lon;
    this.city = apiResponse.location.name;
    this.type = apiResponse.units === 'imperial' ? WeatherDegreesType.Fahrenheit : WeatherDegreesType.Celsius;
    this.aqi = apiResponse.aqi;
    if (apiResponse.daily && apiResponse.current) {
      /* eslint-disable-next-line @typescript-eslint/no-explicit-any */
      this.forecast = apiResponse.daily.map((dailyWeather: any) => new Forecast(dailyWeather, language));
      this.forecast[0].temperature = Math.round(apiResponse.current.temp);
    }
  }
}

export class Forecast {
  date: Date;
  humidity: number;
  description: string;
  icon: string;
  main: string;
  dayName: string;
  temperatureMax: number;
  temperatureMin: number;
  temperature: number;
  time: number;
  wind: number;
  uvIndex: number;

  /* eslint-disable-next-line @typescript-eslint/no-explicit-any */
  constructor(apiResponse: any, language: SupportedLanguage) {
    const date = new Date(apiResponse.dt * 1000);
    this.date = date;
    this.time = date.getTime();
    this.dayName = date.toLocaleDateString(language, { weekday: 'long' });
    this.humidity = apiResponse.humidity;
    this.description = apiResponse.weather[0].description;
    this.icon = apiResponse.weather[0].icon;
    this.main = apiResponse.weather[0].main;
    this.temperatureMax = Math.round(apiResponse.temp.max);
    this.temperatureMin = Math.round(apiResponse.temp.min);
    this.temperature = Math.round(apiResponse.temp.day);
    this.wind = Math.round(apiResponse.wind_speed);
    this.uvIndex = apiResponse.uvi;
  }
}
