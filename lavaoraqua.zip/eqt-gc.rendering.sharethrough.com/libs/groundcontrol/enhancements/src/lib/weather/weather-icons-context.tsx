import type { FunctionComponent } from 'preact';
import { createContext } from 'preact';
import { useContext } from 'preact/hooks';

const WeatherIconsContext = createContext<Map<string, string>>(new Map());

export const WeatherIconsProvider: FunctionComponent<{ icons: Map<string, string> }> = ({ icons, children }) => {
  return <WeatherIconsContext.Provider value={icons}>{children}</WeatherIconsContext.Provider>;
};

export const useWeatherIcons = () => {
  return useContext(WeatherIconsContext);
};
