import { reportError } from '@web-rendering/groundcontrol-monitoring';
import type { LifecycleScope } from '@web-rendering/groundcontrol-shared-types/lifecycle/lifecycle';

const WEATHER_ICON_CDN_BASE = 'https://cdn.rendering.sharethrough.com/weather-icons';

export const getWeatherIconUrl = (iconCode: string): string => {
  return `${WEATHER_ICON_CDN_BASE}/${iconCode}.svg`;
};

export const fetchWeatherIcons = async (iconCodes: string[], scope: LifecycleScope): Promise<Map<string, string>> => {
  const uniqueIconCodes = [...new Set(iconCodes)];
  const svgIconMap = new Map<string, string>();

  /**
   * `map` creates all fetch Promises immediately, so the requests run
   * concurrently. `Promise.allSettled` waits for all of them without throwing
   * if some fail, allowing partial success.
   */
  await Promise.allSettled(
    uniqueIconCodes.map(async (code) => {
      try {
        const response = await fetch(getWeatherIconUrl(code));
        if (!response.ok) {
          reportError(`Failed to fetch weather icon "${code}": ${response.status}`, {
            scope,
            context: 'weather/fetch-icons'
          });
          return;
        }
        const svg = await response.text();
        svgIconMap.set(code, svg);
      } catch (error) {
        reportError(error, { scope, context: 'weather/fetch-icons', iconCode: code });
      }
    })
  );

  return svgIconMap;
};
