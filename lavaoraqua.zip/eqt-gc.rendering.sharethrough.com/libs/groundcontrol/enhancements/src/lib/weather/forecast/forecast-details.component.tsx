import { stringToClassName } from '@web-rendering/groundcontrol-utils';
import { I18N, useTranslation } from '@web-rendering/groundcontrol-i18n';
import type { FunctionalComponent } from 'preact';
import { Fragment } from 'preact';
import { airQualityMap } from '../day/air-quality-to-text';
import WeatherDayDetail from '../day/weather-day-detail.component';
import WeatherDay from '../day/weather-day.component';
import type { Weather } from '../models';
import { WeatherDegreesType } from '../types';

interface ThreeDaysProps {
  weatherData: Weather | undefined;
}

const WeatherForecastDetails: FunctionalComponent<ThreeDaysProps> = ({ weatherData }) => {
  const { t } = useTranslation();

  const forecast = weatherData?.forecast?.[0];
  const city = weatherData?.city;
  const type = weatherData?.type;
  const mainClass = 'str-weather-container-main';
  return (
    <Fragment>
      <div className="str-weather-main">
        <WeatherDay className={mainClass} type={type} city={city} forecast={forecast} />
      </div>
      <div className="str-weather-information">
        <WeatherDayDetail
          description={weatherData ? t(I18N.HUMIDITY) : undefined}
          value={forecast ? `${forecast.humidity}%` : undefined}
          icon={forecast ? 'humidity' : undefined}
          className={forecast ? stringToClassName(forecast.main) : undefined}
        />
        <WeatherDayDetail
          description={weatherData ? t(I18N.AIR_QUALITY) : undefined}
          value={forecast ? t(airQualityMap[weatherData.aqi] || I18N.UNKNOWN) : undefined}
          icon={forecast ? 'air' : undefined}
          className={forecast ? stringToClassName(forecast.main) : undefined}
        />
        <WeatherDayDetail
          description={weatherData ? t(I18N.WIND) : undefined}
          value={forecast ? `${forecast.wind}${type === WeatherDegreesType.Celsius ? 'm/s' : 'mi/h'}` : undefined}
          icon={forecast ? 'wind' : undefined}
          className={forecast ? stringToClassName(forecast.main) : undefined}
        />
        <WeatherDayDetail
          description={weatherData ? t(I18N.UV_INDEX) : undefined}
          value={forecast ? `${forecast.uvIndex}` : undefined}
          icon={forecast ? 'uv' : undefined}
          className={forecast ? stringToClassName(forecast.main) : undefined}
        />
      </div>
    </Fragment>
  );
};

export default WeatherForecastDetails;
