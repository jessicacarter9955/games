import type { FunctionComponent } from 'preact';
import { clsx } from 'clsx';
import { useWeatherIcons } from './weather-icons-context';

interface WeatherIconProps {
  icon: string;
  color?: string;
  isCondensed?: boolean;
}

export const WeatherIcon: FunctionComponent<WeatherIconProps> = ({ icon, isCondensed, color = '#ffffff' }) => {
  const icons = useWeatherIcons();
  const svg = icons.get(icon);
  if (!svg) {
    return null;
  }

  return (
    <div className={clsx('str-weather-icon', isCondensed && 'condensed')}>
      {/* SVG content is fetched from our org-controlled CDN (cdn.rendering.sharethrough.com) */}
      <div style={{ color: color, display: 'flex', flex: 1 }} dangerouslySetInnerHTML={{ __html: svg }} />
    </div>
  );
};
