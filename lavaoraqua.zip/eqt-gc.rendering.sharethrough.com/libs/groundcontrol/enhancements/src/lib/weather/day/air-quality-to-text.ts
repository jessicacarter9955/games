import { I18N } from '@web-rendering/groundcontrol-i18n';

export const airQualityMap: { [key: number]: I18N } = {
  1: I18N.GOOD,
  2: I18N.FAIR,
  3: I18N.MODERATE,
  4: I18N.POOR,
  5: I18N.VERY_POOR
};
