import { clsx } from 'clsx';
import { type FunctionComponent } from 'preact';
import { useEffect, useRef, useState } from 'preact/hooks';
import { EnhancementContainer } from '../common/container/container.component';
import { EnhancementFooter } from '../common/footer/footer.component';
import './captions.scss';
import type { ICaptionsEnhancementProps } from './type';

// Scale factor for canvas rendering - larger size provides better quality for the blur effect
const CANVAS_SCALE_FACTOR = 3;

// Maximum number of captions to keep in history for animation purposes
const MAX_CAPTION_HISTORY = 5;

export const CaptionsEnhancement: FunctionComponent<ICaptionsEnhancementProps> = ({
  assets,
  captionInnerCreativeId,
  currentCaption: caption,
  enhancement,
  innerCreativeIds,
  language,
  onClick,
  onError,
  onLoad,
  publisherStyles,
  videoElement
}) => {
  const useBlurredBackground = enhancement.payload?.blurredBackground ?? false;

  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [captionArray, setCaption] = useState<string[]>(['']);
  const [enhancementLoaded, setEnhancementLoaded] = useState<boolean | undefined>(undefined);
  const [videoElementStarted, setVideoElementStarted] = useState<boolean>(false);

  useEffect(() => {
    if (!innerCreativeIds || !captionInnerCreativeId) return;

    const loaded = innerCreativeIds.includes(captionInnerCreativeId);

    setEnhancementLoaded(loaded);

    if (loaded) {
      onLoad({
        enhancementType: enhancement.type
      });
    }
  }, [captionInnerCreativeId, innerCreativeIds]);

  useEffect(() => {
    if (caption) {
      if (caption !== captionArray[captionArray.length - 1])
        setCaption((prevState) => {
          const newArray = [...prevState, caption];
          // Limit array size to prevent memory leaks in long-running ads
          return newArray.length > MAX_CAPTION_HISTORY ? newArray.slice(-MAX_CAPTION_HISTORY) : newArray;
        });
    } else {
      if (captionArray[captionArray.length - 1] !== '')
        setCaption((prevState) => {
          const newArray = [...prevState, ''];
          return newArray.length > MAX_CAPTION_HISTORY ? newArray.slice(-MAX_CAPTION_HISTORY) : newArray;
        });
    }
  }, [caption, captionArray]);

  // Set up video frame analysis (only needed for blurred background mode)
  useEffect(() => {
    if (!useBlurredBackground) return;

    const { current: canvas } = canvasRef;

    if (!videoElement || !canvas) return;

    const { clientHeight: height, clientWidth: width } = videoElement;
    let animationFrame: number;

    const analyzeFrame = () => {
      // Stop animation when video resets to beginning (handles video end/replay scenarios)
      if (videoElement.currentTime === 0 && animationFrame && videoElementStarted) {
        cancelAnimationFrame(animationFrame);
        return;
      }

      if (videoElement.currentTime > 0) setVideoElementStarted(true);

      const context = canvas.getContext('2d');
      if (!context || !videoElement) return;

      if (videoElement.parentElement?.style.display === 'none') {
        cancelAnimationFrame(animationFrame);
        return;
      }

      // Scale canvas for higher quality blur effect (CSS blur applied via captions.scss)
      const canvasWidth = width * CANVAS_SCALE_FACTOR;
      const canvasHeight = height * CANVAS_SCALE_FACTOR;

      canvas.width = canvasWidth;
      canvas.height = canvasHeight;

      context.drawImage(videoElement, 0, 0, canvasWidth, canvasHeight);

      animationFrame = requestAnimationFrame(analyzeFrame);
    };

    analyzeFrame();

    return () => {
      cancelAnimationFrame(animationFrame);
    };
  }, [useBlurredBackground, videoElement]);

  return (
    <EnhancementContainer
      assets={assets}
      className={clsx('str-enhanced-info str-enhanced-captions', !useBlurredBackground && 'str-solid-background')}
      enhancement={enhancement}
      enhancementLoaded={enhancementLoaded}
      language={language}
      onClick={onClick}
      onError={onError}
      onLoad={onLoad}
    >
      <div className="str-captions-background">
        {useBlurredBackground && <canvas className="str-caption-canvas" ref={canvasRef}></canvas>}
      </div>
      <div className="str-text str-captions">
        {captionArray.map((caption, index) => (
          <div
            className={clsx(
              'str-caption-container',
              index === captionArray.length - 1 ? 'str-current-caption' : 'str-prev-caption'
            )}
            key={index}
          >
            <span data-shadow={caption}>{caption}</span>
          </div>
        ))}
      </div>
      <EnhancementFooter
        assets={assets}
        enhancement={enhancement}
        publisherStyles={publisherStyles}
        hideCallToAction={true}
      />
    </EnhancementContainer>
  );
};
