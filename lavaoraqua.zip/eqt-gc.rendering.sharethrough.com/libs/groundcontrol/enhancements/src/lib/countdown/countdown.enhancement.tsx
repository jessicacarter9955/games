import { type CountdownConfig } from '@sharethrough/groundcontrol-enhancement-flush';
import type { FunctionComponent } from 'preact';
import { Fragment } from 'preact';
import { useEffect, useRef, useState } from 'preact/hooks';
import { EnhancementContainer } from '../common/container/container.component';
import { EnhancementClickEventType } from '../common/type';
import { ClockEnhancement } from './clock.component';
import './countdown.scss';
import type { ICountdownProps } from './type';
import { getActiveCountdown } from './utils';
import { EnhancementFooter } from '../common/footer/footer.component';
import { clsx } from 'clsx';

export const CountdownEnhancement: FunctionComponent<ICountdownProps> = ({
  assets,
  enhancement,
  language,
  layout = null,
  onClick,
  onError,
  onLoad,
  publisherStyles
}) => {
  const countdownContainerRef = useRef<HTMLDivElement>(null);
  const [countdown, setCountdown] = useState<CountdownConfig | null | undefined>(undefined);
  const [enhancementLoaded, setEnhancementLoaded] = useState<boolean | undefined>(undefined);

  // get active countdown config from enhancement payload
  const setActiveCountdownConfig = () => {
    if (!enhancement) return;

    const activeCountdown = getActiveCountdown(enhancement.payload.configs);

    setCountdown(activeCountdown);
    setEnhancementLoaded(!!activeCountdown);

    if (activeCountdown) {
      onLoad({
        enhancementType: enhancement.type
      });
    } else {
      onError({
        error: new Error('No active countdown found'),
        data: enhancement.payload.configs
      });
    }
  };
  useEffect(setActiveCountdownConfig, [enhancement]);

  // set ad unit background color
  const setBackgroundColor = () => {
    const countdownContainerEl = countdownContainerRef.current;

    if (!countdown || !countdownContainerEl) return;

    const adUnitElement = countdownContainerEl.closest('[data-str-arid]');
    if (adUnitElement && adUnitElement instanceof HTMLElement) {
      adUnitElement.style.backgroundColor = countdown.backgroundColor || '#FFFFFF';
    }
  };

  useEffect(setBackgroundColor, [countdown]);

  const cta = countdown?.cta;
  const textColor = countdown?.textColor || '#000000';
  const timestampColor = countdown?.timestampColor || '#000000';
  const backgroundColor = countdown?.backgroundColor || '#FFFFFF';

  return (
    <EnhancementContainer
      assets={assets}
      className="str-enhanced-info"
      enhancement={enhancement}
      enhancementLoaded={enhancementLoaded}
      language={language}
      onClick={onClick}
      onError={onError}
      onLoad={onLoad}
    >
      {countdown && (
        <Fragment>
          <div
            className="str-countdown-container"
            data-testid="countdown-container"
            style={{ backgroundColor }}
            ref={countdownContainerRef}
            onClick={() =>
              onClick({
                enhancementType: enhancement.type,
                eventType: EnhancementClickEventType.CONTENT
              })
            }
          >
            <div
              className={clsx('str-countdown-content', layout === 'horizontal' && 'nowrap')}
              data-testid="countdown-content"
              style={{ color: textColor }}
            >
              <div className="str-countdown-cta" data-testid="countdown-cta">
                <span>{cta}</span>
              </div>
              <ClockEnhancement
                autostart={enhancement?.enhancement_version_id !== 'test-evid'}
                countdown={countdown}
                timestampColor={timestampColor}
              />
            </div>
          </div>
          <EnhancementFooter assets={assets} enhancement={enhancement} publisherStyles={publisherStyles} />
        </Fragment>
      )}
    </EnhancementContainer>
  );
};
