import type { CountdownConfig } from '@sharethrough/groundcontrol-enhancement-flush';

export const getActiveCountdown = (configs: CountdownConfig[]): CountdownConfig | null => {
  for (const config of configs) {
    const startTime = config.startTime ? new Date(Date.parse(config.startTime)) : null;
    const endTime = new Date(Date.parse(config.endTime));

    if (isStarted(startTime) && !isExpired(endTime)) {
      return config;
    }
  }
  return null;
};

const isExpired = (expiryTime: Date) => {
  const currentTime = new Date();
  return expiryTime < currentTime;
};

const isStarted = (startTime: Date | null) => {
  if (!startTime) return true;

  const currentTime = new Date();
  return startTime < currentTime;
};
