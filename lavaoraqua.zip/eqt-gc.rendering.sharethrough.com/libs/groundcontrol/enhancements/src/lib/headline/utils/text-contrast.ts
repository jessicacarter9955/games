/**
 * Text contrast utilities for ensuring readability on colored backgrounds
 * Implements WCAG 2.0 luminance calculation
 */

/**
 * Convert hex color to RGB values
 * @param hex - Hex color string (e.g., "#1a73e8")
 * @returns RGB object with r, g, b values (0-255)
 */
function hexToRgb(hex: string): { r: number; g: number; b: number } | null {
  const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  return result
    ? {
        r: parseInt(result[1], 16),
        g: parseInt(result[2], 16),
        b: parseInt(result[3], 16)
      }
    : null;
}

/**
 * Convert RGB values to hex color string
 * @param r - Red value (0-255)
 * @param g - Green value (0-255)
 * @param b - Blue value (0-255)
 * @returns Hex color string (e.g., "#1a73e8")
 */
export function rgbToHex(r: number, g: number, b: number): string {
  const toHex = (n: number) => {
    const hex = Math.round(n).toString(16);
    return hex.length === 1 ? '0' + hex : hex;
  };
  return `#${toHex(r)}${toHex(g)}${toHex(b)}`;
}

/**
 * Calculate relative luminance of a color according to WCAG 2.0
 * @param r - Red value (0-255)
 * @param g - Green value (0-255)
 * @param b - Blue value (0-255)
 * @returns Relative luminance (0-1)
 */
function calculateLuminance(r: number, g: number, b: number): number {
  // Convert to 0-1 range
  const [rs, gs, bs] = [r / 255, g / 255, b / 255];

  // Apply gamma correction
  const [rLinear, gLinear, bLinear] = [rs, gs, bs].map((val) =>
    val <= 0.03928 ? val / 12.92 : Math.pow((val + 0.055) / 1.055, 2.4)
  );

  // Calculate luminance using WCAG formula
  return 0.2126 * rLinear + 0.7152 * gLinear + 0.0722 * bLinear;
}

/**
 * Determine optimal text color (black or white) based on background color
 * Uses luminance threshold to ensure WCAG AA contrast ratio of at least 4.5:1
 *
 * @param backgroundColor - Hex color string (e.g., "#1a73e8")
 * @returns "#ffffff" for white text or "#000000" for black text
 */
export function calculateTextColor(backgroundColor: string): string {
  const rgb = hexToRgb(backgroundColor);

  // Fallback to white text if hex parsing fails
  if (!rgb) {
    return '#ffffff';
  }

  const luminance = calculateLuminance(rgb.r, rgb.g, rgb.b);

  // Threshold of 0.5 provides good contrast in most cases
  // For darker backgrounds (luminance < 0.5), use white text
  // For lighter backgrounds (luminance >= 0.5), use black text
  return luminance < 0.5 ? '#ffffff' : '#000000';
}

/**
 * Calculate contrast ratio between two colors
 * Useful for testing and validation
 *
 * @param color1 - First hex color
 * @param color2 - Second hex color
 * @returns Contrast ratio (1-21)
 */
export function calculateContrastRatio(color1: string, color2: string): number {
  const rgb1 = hexToRgb(color1);
  const rgb2 = hexToRgb(color2);

  if (!rgb1 || !rgb2) {
    return 1;
  }

  const lum1 = calculateLuminance(rgb1.r, rgb1.g, rgb1.b);
  const lum2 = calculateLuminance(rgb2.r, rgb2.g, rgb2.b);

  const lighter = Math.max(lum1, lum2);
  const darker = Math.min(lum1, lum2);

  return (lighter + 0.05) / (darker + 0.05);
}

/**
 * Generates a lighter tint of a given color by blending it with white
 * This creates a color that can serve as an alternative to white in gradients
 *
 * @param baseColor - Hex color string (e.g., '#1a73e8')
 * @param tintAmount - How much to lighten (0-1), default 0.4 (40% lighter)
 * @returns Lighter hex color string
 *
 * @example
 * ```typescript
 * generateLightTint('#1a73e8') // Returns '#6fa9f0' (light blue)
 * generateLightTint('#ea4335', 0.5) // Returns '#f4a19a' (light red)
 * ```
 */
export function generateLightTint(baseColor: string, tintAmount = 0.4): string {
  const rgb = hexToRgb(baseColor);
  if (!rgb) return '#ffffff'; // Fallback to white if parsing fails

  // Blend with white by moving RGB values toward 255
  const r = Math.round(rgb.r + (255 - rgb.r) * tintAmount);
  const g = Math.round(rgb.g + (255 - rgb.g) * tintAmount);
  const b = Math.round(rgb.b + (255 - rgb.b) * tintAmount);

  return rgbToHex(r, g, b);
}
