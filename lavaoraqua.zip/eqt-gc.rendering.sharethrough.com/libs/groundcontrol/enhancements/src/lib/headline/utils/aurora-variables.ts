/**
 * Generates randomized CSS custom properties for the aurora background effect.
 * Extracted as a pure function so it can be tested and seeded independently.
 */
export function generateAuroraVariables(random: () => number = Math.random): Record<string, string> {
  const randPct = (min: number, max: number) => `${Math.round(min + random() * (max - min))}%`;
  const randPx = (min: number, max: number) => `${Math.round(min + random() * (max - min))}px`;

  return {
    '--aurora-delay-a': `${-(random() * 18).toFixed(1)}s`,
    '--aurora-delay-b': `${-(random() * 13).toFixed(1)}s`,
    '--aurora-p1x': randPct(10, 90),
    '--aurora-p1y': randPct(10, 90),
    '--aurora-p2x': randPct(10, 90),
    '--aurora-p2y': randPct(10, 90),
    '--aurora-p3x': randPct(10, 90),
    '--aurora-p3y': randPct(10, 90),
    '--aurora-edge1': randPct(40, 65),
    '--aurora-edge2': randPct(35, 60),
    '--aurora-edge3': randPct(35, 60),
    '--aurora-blur-a': randPx(6, 16),
    '--aurora-blur-b': randPx(8, 20)
  };
}
