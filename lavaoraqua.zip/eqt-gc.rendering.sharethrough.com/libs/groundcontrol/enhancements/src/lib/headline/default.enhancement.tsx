import { clsx } from 'clsx';
import { Fragment, type FunctionComponent } from 'preact';
import { useEffect } from 'preact/hooks';
import { DefaultAssets } from '../common/assets/default-assets.component';
import Description from '../common/description/description.component';
import { EnhancementFooter } from '../common/footer/footer.component';
import ISI from '../common/isi/isi.component';
import Title from '../common/title/title.component';
import { hideAsset } from '../common/utils';
import './default.enhancement.scss';
import { useEnhancementDescription, useEnhancementTitle } from './enhancement-data.util';
import type { IDefaultHeadlineEnhancementProps } from './type';

export const DefaultHeadlineEnhancement: FunctionComponent<IDefaultHeadlineEnhancementProps> = ({
  publisherStyles,
  assets,
  enhancement,
  isi,
  fallback,
  onLoad
}) => {
  const title = useEnhancementTitle({ assets, enhancement, publisherStyles });
  const description = useEnhancementDescription({ assets, enhancement, publisherStyles });

  useEffect(() => {
    onLoad({
      enhancementType: enhancement.type,
      fallback
    });
  }, []);

  const hideDescription = hideAsset(publisherStyles?.description?.hide, !assets?.description?.data.value);
  const hideTitle = hideAsset(publisherStyles?.title?.hide, !assets?.title?.title.text);

  return (
    <Fragment>
      <div className={clsx('gc-text', publisherStyles && 'str-enhanced-text')}>
        {title && !hideTitle ? <Title publisherStyles={publisherStyles} text={title} /> : <div />}
        {description && !hideDescription && <Description publisherStyles={publisherStyles} text={description} />}
        <DefaultAssets assets={assets} />
      </div>
      {isi && <ISI {...isi} />}
      <EnhancementFooter assets={assets} enhancement={enhancement} publisherStyles={publisherStyles} />
    </Fragment>
  );
};
