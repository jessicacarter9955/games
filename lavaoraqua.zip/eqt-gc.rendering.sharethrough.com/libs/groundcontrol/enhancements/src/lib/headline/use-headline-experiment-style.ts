import { useMemo } from 'preact/hooks';
import { useExtractedColors } from '../common/container/utils/hooks';
import { generateAuroraVariables } from './utils/aurora-variables';

export type HeadlineExperimentStyle = Record<string, string> | undefined;

/**
 * Encapsulates the headline color-extraction experiment.
 *
 * Returns a CSS custom-property map when the experiment is active
 * and a color was successfully extracted, or `undefined` otherwise.
 */
export function useHeadlineExperimentStyle(className?: string): HeadlineExperimentStyle {
  const { textColor, secondaryColor, backgroundColor } = useExtractedColors(className);

  const isActive = !!backgroundColor;

  return useMemo(() => {
    if (!isActive) return undefined;

    return {
      '--headlineTextColor': textColor,
      '--headlineSecondaryBgColor': secondaryColor,
      '--headlinePrimaryBgColor': backgroundColor,
      ...generateAuroraVariables()
    } as Record<string, string>;
  }, [isActive, textColor, secondaryColor, backgroundColor]);
}
