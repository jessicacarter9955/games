import { I18N, useTranslation } from '@web-rendering/groundcontrol-i18n';
import type { GCEnhancementPayload } from '@sharethrough/groundcontrol-enhancement-flush';
import type { NativeAssets } from '@web-rendering/groundcontrol-ortb';
import type { PublisherStyles } from '@ad-rendering/publisher-style';
import { getAssetsTitle, getEnhancementTitle } from '../common/title/utils';
import { getAssetsDescription, getEnhancementDescription } from '../common/description/utils';
import { getAssetsAdvertiser, getEnhancementAdvertiser } from '../common/advertiser/utils';
import { getAssetsCtaText, getEnhancementCtaText, getStyle } from '../common/cta/utils';

export interface EnhancementDataProps {
  assets: NativeAssets | null | undefined;
  enhancement: { type: string; payload?: GCEnhancementPayload['payload'] };
  publisherStyles?: PublisherStyles;
}

export interface EnhancementData {
  title: string;
  description: string;
  advertiser: {
    promotedByText: string | undefined;
    name: string | undefined;
    brandLogoUrl: string | undefined;
  } | null;
  ctaText: string;
  ctaStyle: { [key: string]: string | undefined };
}

export interface EnhancementFooterData {
  advertiser: {
    promotedByText: string | undefined;
    name: string | undefined;
    brandLogoUrl: string | undefined;
  } | null;
  ctaText: string;
  ctaStyle: { [key: string]: string | undefined };
}

export function useEnhancementTitle({ assets, enhancement }: EnhancementDataProps): string {
  const { t } = useTranslation();

  const enhancementTitle = getEnhancementTitle(enhancement?.payload);
  const assetTitle = getAssetsTitle(assets);
  return enhancementTitle || assetTitle || (!enhancement?.payload && t(I18N.TITLE)) || '';
}

export function useEnhancementDescription({ assets, enhancement }: EnhancementDataProps): string {
  const { t } = useTranslation();

  const enhancementDescription = getEnhancementDescription(enhancement?.payload);
  const assetDescription = getAssetsDescription(assets);
  return enhancementDescription || assetDescription || (!enhancement?.payload && t(I18N.DESCRIPTION)) || '';
}

export function useEnhancementFooterData({
  assets,
  enhancement,
  publisherStyles
}: EnhancementDataProps): EnhancementFooterData {
  const { t } = useTranslation();

  // Advertiser extraction
  const enhancementAdvertiser = getEnhancementAdvertiser(enhancement?.payload);
  const assetAdvertiser = getAssetsAdvertiser(assets);
  const advertiser =
    enhancementAdvertiser == null && assetAdvertiser == null && enhancement?.payload
      ? null
      : {
          promotedByText:
            enhancementAdvertiser?.promotedByText ||
            assetAdvertiser?.promotedByText ||
            (!enhancement?.payload && t(I18N.PROMOTED_BY_TEXT)) ||
            '',
          name:
            enhancementAdvertiser?.name || assetAdvertiser?.name || (!enhancement?.payload && t(I18N.ADVERTISER)) || '',
          brandLogoUrl: enhancementAdvertiser?.brandLogoUrl || assetAdvertiser?.brandLogoUrl
        };

  // CTA extraction
  const enhancementCtaText = getEnhancementCtaText(enhancement?.payload);
  const assetCtaText = getAssetsCtaText(assets);
  const ctaText = enhancementCtaText || assetCtaText || (!enhancement?.payload && t(I18N.CTA_TEXT)) || '';

  // CTA style extraction
  const ctaStyle = getStyle(enhancement?.payload, publisherStyles);

  return {
    advertiser,
    ctaText,
    ctaStyle
  };
}

export function useEnhancementData({ assets, enhancement, publisherStyles }: EnhancementDataProps): EnhancementData {
  const title = useEnhancementTitle({ assets, enhancement, publisherStyles });
  const description = useEnhancementDescription({ assets, enhancement, publisherStyles });
  const footerData = useEnhancementFooterData({ assets, enhancement, publisherStyles });

  return {
    title,
    description,
    ...footerData
  };
}
