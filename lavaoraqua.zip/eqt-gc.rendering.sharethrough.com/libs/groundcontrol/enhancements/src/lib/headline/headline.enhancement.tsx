import clsx from 'clsx';
import { type FunctionComponent } from 'preact';
import { EnhancementContainer } from '../common/container/container.component';
import { DefaultHeadlineEnhancement } from './default.enhancement';
import type { IHeadlineProps } from './type';
import { useHeadlineExperimentStyle } from './use-headline-experiment-style';

export const HeadlineEnhancement: FunctionComponent<IHeadlineProps> = ({
  assets,
  enhancement,
  isi,
  language,
  onClick,
  onError,
  onLoad,
  publisherStyles,
  className
}) => {
  const experimentStyle = useHeadlineExperimentStyle(className);

  return (
    <EnhancementContainer
      assets={assets}
      className={clsx('str-enhanced-info', `str-headline-${enhancement.type}`, className)}
      enhancement={enhancement}
      enhancementLoaded={true}
      onClick={onClick}
      onError={onError}
      onLoad={onLoad}
      publisherStyles={publisherStyles}
      language={language}
      style={experimentStyle}
    >
      <DefaultHeadlineEnhancement
        publisherStyles={publisherStyles}
        assets={assets}
        enhancement={enhancement}
        isi={isi}
        onLoad={onLoad}
        onClick={onClick}
        onError={onError}
      />
    </EnhancementContainer>
  );
};
