/**
 * Utility for extracting dominant colors from banner iframe content
 * Uses Canvas API to analyze pixels and determine the most prominent color
 */
import { rgbToHex } from './text-contrast';

/**
 * Result of color extraction with metadata
 */
export interface ColorExtractionResult {
  /** Primary hex color string (e.g., '#1a73e8') */
  color: string;
  /** Confidence score 0-1 indicating extraction reliability */
  confidence: number;
  /** Source of the color (e.g., 'banner-image', 'banner-background') */
  source: 'banner-image' | 'banner-background' | 'banner-element' | 'fallback';
}

/**
 * Options for color extraction
 */
export interface ColorExtractionOptions {
  /** Maximum time to wait for iframe to be ready (ms) */
  timeout?: number;
  /** Sample size for pixel analysis (higher = more accurate but slower) */
  sampleSize?: number;
  /** Minimum confidence threshold to accept extracted color */
  minConfidence?: number;
}

/**
 * Default options for color extraction
 */
const DEFAULT_OPTIONS: Required<ColorExtractionOptions> = {
  timeout: 2000,
  sampleSize: 100,
  minConfidence: 0.5
};

/**
 * Finds the banner iframe element in the DOM
 * Uses data-testid and class selectors that match the BannerIframe component output
 */
function findBannerIframe(): HTMLIFrameElement | null {
  const commonSelectors = ['iframe[data-testid="adm-iframe"]', 'iframe.str-thumbnail'];

  for (const selector of commonSelectors) {
    const iframe = document.querySelector<HTMLIFrameElement>(selector);
    if (iframe && isFriendlyIframe(iframe)) {
      return iframe;
    }
  }

  return null;
}

/**
 * Checks if an iframe is friendly (same-origin) and accessible
 */
function isFriendlyIframe(iframe: HTMLIFrameElement): boolean {
  try {
    // Try to access contentDocument - will throw if cross-origin
    const doc = iframe.contentDocument;
    return doc !== null;
  } catch (e) {
    return false;
  }
}

/**
 * Convert RGB to HSL
 * @returns h in [0, 360), s in [0, 1], l in [0, 1]
 */
function rgbToHsl(r: number, g: number, b: number): { h: number; s: number; l: number } {
  const rNorm = r / 255;
  const gNorm = g / 255;
  const bNorm = b / 255;

  const max = Math.max(rNorm, gNorm, bNorm);
  const min = Math.min(rNorm, gNorm, bNorm);
  const l = (max + min) / 2;

  if (max === min) {
    return { h: 0, s: 0, l };
  }

  const d = max - min;
  const s = l > 0.5 ? d / (2 - max - min) : d / (max + min);

  let h: number;
  if (max === rNorm) {
    h = ((gNorm - bNorm) / d + (gNorm < bNorm ? 6 : 0)) * 60;
  } else if (max === gNorm) {
    h = ((bNorm - rNorm) / d + 2) * 60;
  } else {
    h = ((rNorm - gNorm) / d + 4) * 60;
  }

  return { h, s, l };
}

/**
 * Extracts the dominant color from an image element using Canvas API.
 * Uses HSL-based hue bucketing to group perceptually similar colors together,
 * preventing fragmentation of natural colors (e.g., green grass across many RGB buckets).
 * Desaturated (gray) pixels are filtered out to focus on brand/content colors.
 */
function extractColorFromImage(img: HTMLImageElement, sampleSize: number): string | null {
  try {
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    if (!ctx) return null;

    // Scale down for performance
    const scale = Math.min(1, sampleSize / Math.max(img.width, img.height));
    canvas.width = img.width * scale;
    canvas.height = img.height * scale;

    // Draw image to canvas
    ctx.drawImage(img, 0, 0, canvas.width, canvas.height);

    // Get pixel data
    const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const pixels = imageData.data;

    // HSL-based hue bucketing (30-degree buckets = 12 groups)
    const hueBuckets: Record<number, { count: number; totalR: number; totalG: number; totalB: number }> = {};
    let saturatedPixelCount = 0;

    const step = 4; // Sample every Nth pixel for performance

    for (let i = 0; i < pixels.length; i += step * 4) {
      const r = pixels[i];
      const g = pixels[i + 1];
      const b = pixels[i + 2];
      const a = pixels[i + 3];

      // Skip transparent pixels
      if (a < 128) continue;

      // Skip very light colors (likely background/white)
      if (r > 240 && g > 240 && b > 240) continue;

      // Skip pure black (likely default/border)
      if (r < 15 && g < 15 && b < 15) continue;

      const { h, s, l } = rgbToHsl(r, g, b);

      // Skip desaturated pixels (grays) — they rarely represent brand colors
      if (s < 0.15) continue;

      // Skip very dark or very light pixels
      if (l < 0.08 || l > 0.92) continue;

      saturatedPixelCount++;

      // Bucket by hue in 30-degree ranges
      const hueBucket = Math.floor(h / 30) * 30;

      if (!hueBuckets[hueBucket]) {
        hueBuckets[hueBucket] = { count: 0, totalR: 0, totalG: 0, totalB: 0 };
      }

      // Weight by saturation — more saturated colors are more representative
      hueBuckets[hueBucket].count += s;
      hueBuckets[hueBucket].totalR += r * s;
      hueBuckets[hueBucket].totalG += g * s;
      hueBuckets[hueBucket].totalB += b * s;
    }

    // If very few saturated pixels, fall back to RGB quantization
    if (saturatedPixelCount < 10) {
      return extractDominantColorRgb(pixels, step);
    }

    // Find the dominant hue bucket
    let maxWeight = 0;
    let dominantBucket: (typeof hueBuckets)[number] | null = null;

    for (const bucket of Object.values(hueBuckets)) {
      if (bucket.count > maxWeight) {
        maxWeight = bucket.count;
        dominantBucket = bucket;
      }
    }

    if (!dominantBucket || maxWeight === 0) {
      return extractDominantColorRgb(pixels, step);
    }

    // Average color within the dominant hue bucket
    const avgR = Math.round(dominantBucket.totalR / dominantBucket.count);
    const avgG = Math.round(dominantBucket.totalG / dominantBucket.count);
    const avgB = Math.round(dominantBucket.totalB / dominantBucket.count);

    return rgbToHex(avgR, avgG, avgB);
  } catch {
    return null;
  }
}

/**
 * Fallback RGB quantization for images with no saturated colors (e.g., grayscale banners).
 */
function extractDominantColorRgb(pixels: Uint8ClampedArray, step: number): string | null {
  const colorCounts: Record<string, number> = {};

  for (let i = 0; i < pixels.length; i += step * 4) {
    const r = pixels[i];
    const g = pixels[i + 1];
    const b = pixels[i + 2];
    const a = pixels[i + 3];

    if (a < 128) continue;
    if (r > 240 && g > 240 && b > 240) continue;
    if (r < 15 && g < 15 && b < 15) continue;

    const quantizedR = Math.floor(r / 32) * 32;
    const quantizedG = Math.floor(g / 32) * 32;
    const quantizedB = Math.floor(b / 32) * 32;

    const colorKey = `${quantizedR},${quantizedG},${quantizedB}`;
    colorCounts[colorKey] = (colorCounts[colorKey] || 0) + 1;
  }

  let maxCount = 0;
  let dominantColor: string | null = null;

  for (const [colorKey, count] of Object.entries(colorCounts)) {
    if (count > maxCount) {
      maxCount = count;
      const [r, g, b] = colorKey.split(',').map(Number);
      dominantColor = rgbToHex(r, g, b);
    }
  }

  return dominantColor;
}

/**
 * Extracts background color from an element
 */
function getBackgroundColor(element: HTMLElement): string | null {
  const bgColor = window.getComputedStyle(element).backgroundColor;

  // Parse rgb/rgba to hex
  const match = bgColor.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*[\d.]+)?\)/);
  if (match) {
    const [, r, g, b] = match.map(Number);
    // Skip white/very light backgrounds AND pure black (likely default)
    if (r > 240 && g > 240 && b > 240) return null;
    if (r === 0 && g === 0 && b === 0) return null;
    return rgbToHex(r, g, b);
  }

  return null;
}

/**
 * Checks whether an element is a small icon positioned in a corner of its container.
 * Corner icons (AdChoices, mute buttons, close buttons, etc.) don't represent
 * the creative's brand color and should be excluded from extraction.
 */
function isCornerIcon(element: Element, container: HTMLElement): boolean {
  const elRect = element.getBoundingClientRect();
  const containerRect = container.getBoundingClientRect();

  // Must be small relative to the container (< 15% of either dimension)
  const relWidth = elRect.width / (containerRect.width || 1);
  const relHeight = elRect.height / (containerRect.height || 1);
  if (relWidth > 0.15 || relHeight > 0.15) return false;

  // Check if positioned near any corner (within 20% of edges)
  const edgeThreshold = 0.2;
  const nearLeft = (elRect.left - containerRect.left) / (containerRect.width || 1) < edgeThreshold;
  const nearRight = (containerRect.right - elRect.right) / (containerRect.width || 1) < edgeThreshold;
  const nearTop = (elRect.top - containerRect.top) / (containerRect.height || 1) < edgeThreshold;
  const nearBottom = (containerRect.bottom - elRect.bottom) / (containerRect.height || 1) < edgeThreshold;

  return (nearLeft || nearRight) && (nearTop || nearBottom);
}

/**
 * Extracts the dominant color from SVG elements
 * Returns the most common fill color found in SVG paths
 */
function extractColorFromSVG(svg: SVGElement): string | null {
  // Check fill colors on path elements
  const paths = Array.from(svg.querySelectorAll('path, rect, circle, polygon'));
  const colors: Record<string, number> = {};

  for (const path of paths) {
    const fill = path.getAttribute('fill') || window.getComputedStyle(path as Element).fill;
    if (fill && fill !== 'none' && fill !== 'transparent') {
      // Parse hex, rgb, or named colors
      const match = fill.match(/#([0-9a-f]{6})|rgba?\((\d+),\s*(\d+),\s*(\d+)/i);
      if (match) {
        let color: string;
        if (match[1]) {
          color = `#${match[1]}`;
        } else if (match[2]) {
          const r = parseInt(match[2]);
          const g = parseInt(match[3]);
          const b = parseInt(match[4]);
          // Skip white and black
          if ((r > 240 && g > 240 && b > 240) || (r === 0 && g === 0 && b === 0)) continue;
          color = rgbToHex(r, g, b);
        } else {
          continue;
        }
        colors[color] = (colors[color] || 0) + 1;
      }
    }
  }

  // Sort by count and return most common color
  const sortedColors = Object.entries(colors).sort((a, b) => b[1] - a[1]);

  if (sortedColors.length === 0) return null;

  return sortedColors[0][0];
}

/**
 * Extracts the primary color from banner iframe content
 *
 * @param options - Configuration options for extraction
 * @returns Promise resolving to color extraction result
 */
export async function extractPrimaryColorFromBanner(
  options: ColorExtractionOptions = {}
): Promise<ColorExtractionResult> {
  const opts = { ...DEFAULT_OPTIONS, ...options };

  try {
    // Find the banner iframe
    const iframe = findBannerIframe();
    if (!iframe) {
      return {
        color: '#2d2d2d', // Neutral dark gray fallback
        confidence: 0,
        source: 'fallback'
      };
    }

    // Wait for iframe content to be ready
    await waitForIframeReady(iframe, opts.timeout);

    const iframeDoc = iframe.contentDocument;
    if (!iframeDoc) {
      return {
        color: '#2d2d2d',
        confidence: 0,
        source: 'fallback'
      };
    }

    // Strategy 1: Extract from largest image in banner
    const images = Array.from(iframeDoc.querySelectorAll('img'));

    // Filter out tracking pixels, hidden images, and corner icons
    const visibleImages = images.filter((img) => {
      // Skip tiny images (tracking pixels are typically 1x1)
      if (img.naturalWidth <= 2 || img.naturalHeight <= 2) return false;
      if (img.width <= 2 || img.height <= 2) return false;

      // Skip hidden images
      const style = iframeDoc.defaultView?.getComputedStyle(img);
      if (style?.display === 'none' || style?.visibility === 'hidden') return false;

      // Skip small icons in corners (AdChoices, mute, close, etc.)
      if (isCornerIcon(img, iframeDoc.body)) return false;

      return true;
    });

    if (visibleImages.length > 0) {
      // Sort by size (area)
      visibleImages.sort((a, b) => b.width * b.height - a.width * a.height);

      for (const img of visibleImages) {
        if (img.complete && img.naturalWidth > 0) {
          // Try direct canvas extraction first
          const color = extractColorFromImage(img, opts.sampleSize);
          if (color) {
            return {
              color,
              confidence: 0.8,
              source: 'banner-image'
            };
          }

          // If direct extraction failed (likely cross-origin taint),
          // reload the image with CORS enabled
          const corsColor = await extractColorWithCors(img.src, opts.sampleSize);
          if (corsColor) {
            return {
              color: corsColor,
              confidence: 0.8,
              source: 'banner-image'
            };
          }
        }
      }
    }

    // Strategy 2: Extract from SVG elements (logos, icons), skipping corner icons
    const svgs = Array.from(iframeDoc.querySelectorAll('svg'));

    for (const svg of svgs) {
      if (isCornerIcon(svg, iframeDoc.body)) continue;

      const color = extractColorFromSVG(svg);
      if (color) {
        return {
          color,
          confidence: 0.75,
          source: 'banner-element'
        };
      }
    }

    // Strategy 3: Extract from body background (skip pure black)
    const bodyBg = getBackgroundColor(iframeDoc.body);

    if (bodyBg) {
      return {
        color: bodyBg,
        confidence: 0.6,
        source: 'banner-background'
      };
    }

    // Strategy 4: Extract from largest colored element
    // Scope to direct descendants of body to avoid scanning deeply nested elements
    const elements = Array.from(iframeDoc.body.querySelectorAll('body > *, body > * > *')) as HTMLElement[];

    const coloredElements: Array<{ element: HTMLElement; color: string; area: number }> = [];

    for (const el of elements) {
      const bgColor = getBackgroundColor(el);
      if (bgColor) {
        const rect = el.getBoundingClientRect();
        let area = rect.width * rect.height;

        // Fallback to computed style dimensions if getBoundingClientRect returns 0
        if (area === 0) {
          const computed = window.getComputedStyle(el);
          const width = parseFloat(computed.width) || 0;
          const height = parseFloat(computed.height) || 0;
          area = width * height;
        }

        if (area > 0) {
          coloredElements.push({ element: el, color: bgColor, area });
        }
      }
    }

    // Sort by area (largest first)
    coloredElements.sort((a, b) => b.area - a.area);

    if (coloredElements.length > 0) {
      const largest = coloredElements[0];
      return {
        color: largest.color,
        confidence: 0.5,
        source: 'banner-element'
      };
    }

    // Fallback
    return {
      color: '#2d2d2d',
      confidence: 0,
      source: 'fallback'
    };
  } catch {
    return {
      color: '#2d2d2d',
      confidence: 0,
      source: 'fallback'
    };
  }
}

/**
 * Attempts to extract a color from a cross-origin image by reloading it with CORS enabled.
 * Many ad servers support CORS, which allows canvas pixel access without tainting.
 *
 * A cache-busting parameter is appended because browsers may serve the cached non-CORS
 * response when the same URL is re-requested with crossOrigin='anonymous', causing the
 * canvas to remain tainted.
 */
async function extractColorWithCors(src: string, sampleSize: number): Promise<string | null> {
  return new Promise((resolve) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';

    const timeout = setTimeout(() => {
      resolve(null);
    }, 3000);

    img.onload = () => {
      clearTimeout(timeout);
      resolve(extractColorFromImage(img, sampleSize));
    };
    img.onerror = () => {
      clearTimeout(timeout);
      resolve(null);
    };

    // Append cache-busting param to force a fresh CORS-enabled request
    // instead of reusing the cached non-CORS response
    const separator = src.includes('?') ? '&' : '?';
    img.src = `${src}${separator}__cors=1`;
  });
}

/**
 * Waits for iframe document to be ready and its images to be loaded.
 * Some ad tech scripts inject images after document.readyState === 'complete',
 * so we also poll for visible images to finish loading.
 */
async function waitForIframeReady(iframe: HTMLIFrameElement, timeout: number): Promise<void> {
  const deadline = Date.now() + timeout;

  // Phase 1: wait for document readyState === 'complete'
  await new Promise<void>((resolve, reject) => {
    const checkReady = () => {
      if (Date.now() > deadline) {
        resolve(); // resolve on timeout so extraction can still attempt with what's available
        return;
      }

      try {
        const doc = iframe.contentDocument;
        if (doc && doc.readyState === 'complete') {
          resolve();
          return;
        }
      } catch (e) {
        reject(e);
        return;
      }

      setTimeout(checkReady, 100);
    };
    checkReady();
  });

  // Phase 2: wait for visible images inside the iframe to finish loading.
  // This handles cases where the creative image is in the HTML but still loading.
  const doc = iframe.contentDocument;
  if (!doc) return;

  const pollInterval = 150;
  await new Promise<void>((resolve) => {
    const checkImages = () => {
      if (Date.now() > deadline) {
        resolve();
        return;
      }

      const images = Array.from(doc.querySelectorAll('img'));
      const visibleImages = images.filter((img) => {
        if (img.width <= 2 || img.height <= 2) return false;
        const style = doc.defaultView?.getComputedStyle(img);
        if (style?.display === 'none' || style?.visibility === 'hidden') return false;
        return true;
      });

      // If there are visible images and all are loaded, we're ready
      if (visibleImages.length > 0 && visibleImages.every((img) => img.complete && img.naturalWidth > 0)) {
        resolve();
        return;
      }

      // If no visible images yet, wait a bit for scripts to inject them
      setTimeout(checkImages, pollInterval);
    };

    checkImages();
  });
}

/**
 * Observes the banner iframe for late-loading images and re-attempts color extraction.
 * Useful when the initial extraction fails because the creative hadn't loaded yet.
 *
 * @param onColorExtracted - Callback when a color is successfully extracted
 * @param options - Extraction options (sampleSize)
 * @param maxWait - Maximum observation time in ms (default 15s)
 * @returns Cleanup function to stop observing
 */
export function observeIframeForColor(
  onColorExtracted: (result: ColorExtractionResult) => void,
  options: ColorExtractionOptions = {},
  maxWait = 15000
): () => void {
  const opts = { ...DEFAULT_OPTIONS, ...options };
  let observer: MutationObserver | null = null;
  let stopped = false;

  const cleanup = () => {
    stopped = true;
    observer?.disconnect();
  };

  const maxTimer = setTimeout(cleanup, maxWait);

  const tryExtractFromImage = async (img: HTMLImageElement) => {
    if (stopped) return;
    if (img.width <= 2 || img.height <= 2) return;
    if (img.naturalWidth <= 2 || img.naturalHeight <= 2) return;

    const color = extractColorFromImage(img, opts.sampleSize);
    if (color) {
      onColorExtracted({ color, confidence: 0.8, source: 'banner-image' });
      clearTimeout(maxTimer);
      cleanup();
      return;
    }

    // Try CORS reload
    const corsColor = await extractColorWithCors(img.src, opts.sampleSize);
    if (!stopped && corsColor) {
      onColorExtracted({ color: corsColor, confidence: 0.8, source: 'banner-image' });
      clearTimeout(maxTimer);
      cleanup();
    }
  };

  const iframe = findBannerIframe();
  if (!iframe) {
    clearTimeout(maxTimer);
    return cleanup;
  }

  const iframeDoc = iframe.contentDocument;
  if (!iframeDoc) {
    clearTimeout(maxTimer);
    return cleanup;
  }

  // Watch for new nodes (images injected by scripts)
  observer = new MutationObserver((mutations) => {
    if (stopped) return;

    for (const mutation of mutations) {
      for (const node of Array.from(mutation.addedNodes)) {
        if (node instanceof HTMLImageElement) {
          if (node.complete && node.naturalWidth > 0) {
            tryExtractFromImage(node);
          } else {
            node.addEventListener('load', () => tryExtractFromImage(node), { once: true });
          }
        }
        // Also check img children of added containers
        if (node instanceof HTMLElement) {
          const imgs = node.querySelectorAll('img');
          for (const img of Array.from(imgs)) {
            if (img.complete && img.naturalWidth > 0) {
              tryExtractFromImage(img);
            } else {
              img.addEventListener('load', () => tryExtractFromImage(img), { once: true });
            }
          }
        }
      }
    }
  });

  observer.observe(iframeDoc.body, { childList: true, subtree: true });

  // Also listen for load events on images that are already in the DOM but not yet loaded
  const existingImages = Array.from(iframeDoc.querySelectorAll('img'));
  for (const img of existingImages) {
    if (img.width <= 2 || img.height <= 2) continue;
    if (!img.complete) {
      img.addEventListener('load', () => tryExtractFromImage(img), { once: true });
    }
  }

  return () => {
    clearTimeout(maxTimer);
    cleanup();
  };
}
