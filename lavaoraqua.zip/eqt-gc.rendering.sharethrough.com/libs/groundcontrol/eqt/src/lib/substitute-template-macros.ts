import { SAME_SIZE_ENHANCED_SCALE, isSameSizePinAllowedCombo } from '@web-rendering/groundcontrol-core';
import type { RawPayload } from '@web-rendering/groundcontrol-shared-types';

const ENCODED_MACRO_PATTERN = /%24%7B[^%]*%7D/gi;

const decodeEncodedMacros = (url: string): string =>
  url.replaceAll(ENCODED_MACRO_PATTERN, (match) => decodeURIComponent(match));

const UNRESOLVED_MACRO_PATTERN = /\$\{[^}]*\}/g;

export const substituteTemplateMacros = (url: string, rawPayload: RawPayload): string => {
  // Only a payload matching on BOTH axes AND on FR3's allowlist is the WR-2159 same-size case,
  // where GC pins the creative via the str-same-size-pinned CSS class instead of native (Tasks
  // 2-3, isSameSizePinAllowedCombo). A single matching axis (the tall/wide tests below), or a
  // same-size pair outside the allowlist, is a different, unrelated layout and keeps the
  // `|| networkSize` fallback: the enhancement spans that whole matching axis, so reporting the
  // full size there (not 0) is correct, not a bug.
  const isSameSize =
    rawPayload.network.size.width === rawPayload.creative.size.width &&
    rawPayload.network.size.height === rawPayload.creative.size.height &&
    isSameSizePinAllowedCombo(rawPayload.network.size.width, rawPayload.network.size.height);

  // The str-same-size-pinned CSS rule (flex: 0 0 75%, a flex-basis) only ever affects the flex
  // container's current MAIN axis; the cross axis stays at its natural full-size stretch (see
  // responsive.scss). All 3 of FR3's same-size combinations (300x250, 300x600, 160x600) fall in
  // the "square"/"tall"/"tallest" ratio buckets, which render in column direction, so height is
  // always the pinned axis for every allowlisted combo — not something to detect per-payload.
  // Width keeps the original `|| networkSize` fallback, which already reports the correct "full
  // network size, nothing freed" value for it.
  const macroMap: Record<string, string | undefined> = {
    '${AD_SUPPLY_WIDTH}': String(
      rawPayload.network.size.width - rawPayload.creative.size.width || rawPayload.network.size.width
    ),
    '${AD_SUPPLY_HEIGHT}': String(
      isSameSize
        ? rawPayload.network.size.height - Math.round(rawPayload.creative.size.height * SAME_SIZE_ENHANCED_SCALE)
        : rawPayload.network.size.height - rawPayload.creative.size.height || rawPayload.network.size.height
    ),
    '${AUCTION_ID}': rawPayload.id,
    '${IMP_ID}': rawPayload.id,
    '${CREATIVE_ID}': rawPayload.creative.creativeId,
    '${DEAL_ID}': rawPayload.creative.dealId ?? undefined,
    '${DOMAIN}': rawPayload.network.domain,
    '${CAMPAIGN_KEY}': rawPayload.creative.campaignId ?? undefined,
    '${ADVERTISER_KEY}': rawPayload.creative.advertiserId != null ? String(rawPayload.creative.advertiserId) : undefined
  };

  const normalizedUrl = decodeEncodedMacros(url);

  const substituted = Object.entries(macroMap).reduce(
    (result, [macro, value]) => (value != null ? result.replaceAll(macro, value) : result),
    normalizedUrl
  );

  return substituted.replace(UNRESOLVED_MACRO_PATTERN, '');
};
