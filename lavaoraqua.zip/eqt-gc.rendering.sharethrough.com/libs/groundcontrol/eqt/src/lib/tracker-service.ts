import { buildViewTrackedUnit, shouldSampleFriendlyIframe } from '@web-rendering/groundcontrol-utils';
import type { AttentionMetricsPayload, DurationKey } from '@web-rendering/groundcontrol-beacon';
import { QuartileKey, URLBeacon } from '@web-rendering/groundcontrol-beacon';
import type { GroundControlLoadedParams, Payload, SasConfig } from '@web-rendering/groundcontrol-core';
import type { ValidEnhancementType } from '@web-rendering/groundcontrol-shared-types';
import { CreativeType } from '@web-rendering/groundcontrol-shared-types';
import { TrackerService } from '@web-rendering/groundcontrol-core';
import { reportError } from '@web-rendering/groundcontrol-monitoring';
import { LifecycleStage } from '@web-rendering/groundcontrol-shared-types/lifecycle/lifecycle-stage';
import { OrtbEventType } from '@web-rendering/groundcontrol-ortb';
import { TrackerEventActionId } from '@web-rendering/groundcontrol-shared-types/tracker';
import type { ClickExtractionResult } from '@sharethrough/groundcontrol-types';
import { bindStage } from '@web-rendering/groundcontrol-shared-types/lifecycle/lifecycle';
import type { LifecycleScope } from '@web-rendering/groundcontrol-shared-types/lifecycle/lifecycle';

interface EqtBeaconServiceMetadata {
  payload: Payload;
}

export class EqtBeaconService extends TrackerService<Partial<EqtBeaconServiceMetadata>> {
  private hasPayload(metadata: Partial<EqtBeaconServiceMetadata>): metadata is EqtBeaconServiceMetadata {
    return metadata?.payload !== undefined;
  }

  constructor() {
    super();
  }

  trackImpression(placeholderEl: HTMLElement, scope: LifecycleScope): void {
    if (!this.hasPayload(this.metadata)) return;

    const { payload } = this.metadata;

    try {
      this.trackOrtbEvent(OrtbEventType.Impression, placeholderEl);

      this.trackVisibleImpression(placeholderEl);

      if (payload.reporting.countImpressionOnePixel) return;
      // A null trackerImpressionUrl is the ad server's deliberate "do not fire" signal: SSB's
      // GroundControlPayloadFactory leaves it null when the impression is counted outside the
      // markup, so this is normal traffic, not a dropped pixel, and must not be reported.
      if (!payload.reporting.trackerImpressionUrl) return;

      new URLBeacon({
        url: `${payload.reporting.trackerImpressionUrl}`
      });
    } catch (e) {
      if (e instanceof Error) {
        reportError(e, {
          // Firing the Counted Impression is the impression stage, wherever the caller is.
          scope: bindStage(scope, LifecycleStage.Impression),
          context: 'eqt/impression-beacon-failed'
        });
      }
    }
  }

  trackImpressionReceived(): void {
    // console.warn('Method trackImpressionReceived not implemented.');
  }

  trackVisibleImpression(placeholderEl: HTMLElement): void {
    if (!this.hasPayload(this.metadata)) return;

    const { payload } = this.metadata;

    if (payload.creative.type === CreativeType.Outstream) return;

    try {
      buildViewTrackedUnit(placeholderEl, payload.id);
    } catch {
      // console.warn('Failed to build view tracked unit');
    }
  }

  trackClick(): void {
    if (!this.hasPayload(this.metadata) || this.metadata.payload.reporting.disableClickCounting) return;

    const { payload } = this.metadata;

    // Disable for EQT Outstream, as it is handled by the VAST TAG/IMA SDK.
    if (payload.creative.type === CreativeType.Outstream) return;

    new URLBeacon({
      url: `${payload.reporting.trackerBaseUrl}&actionid=${TrackerEventActionId.TrackClick}`
    });
  }

  trackViewableImpression(): void {
    if (!this.hasPayload(this.metadata)) return;

    const { payload } = this.metadata;

    // Disable for EQT Outstream, as it is handled by the VAST TAG/IMA SDK.
    if (payload.creative.type === CreativeType.Outstream) return;

    new URLBeacon({
      url: `${payload.reporting.trackerBaseUrl}&actionid=${TrackerEventActionId.Viewable}`
    });
  }

  trackOrtbEvent(eventType: OrtbEventType, element: HTMLElement): void {
    if (!this.hasPayload(this.metadata)) return;

    const { payload } = this.metadata;

    if (payload.creative.trackers) {
      payload.creative.trackers.fireEventTrackerByType(eventType, element);
    }
  }

  trackVideoStart(_autoPlay: boolean): void {
    if (!this.hasPayload(this.metadata)) return;

    const { payload } = this.metadata;

    // Disable for EQT Outstream, as it is handled by the VAST TAG/IMA SDK.
    if (payload.creative.type === CreativeType.Outstream) return;

    new URLBeacon({
      url: `${payload.reporting.trackerBaseUrl}&actionid=${TrackerEventActionId.VideoStart}`
    });
  }

  trackVideoPlay(): void {
    if (!this.hasPayload(this.metadata)) return;

    const { payload } = this.metadata;

    // Disable for EQT Outstream, as it is handled by the VAST TAG/IMA SDK.
    if (payload.creative.type === CreativeType.Outstream) return;

    new URLBeacon({
      url: `${payload.reporting.trackerBaseUrl}&actionid=${TrackerEventActionId.VideoResume}`
    });
  }

  trackVideoQuartile(quartileKey: QuartileKey): void {
    if (!this.hasPayload(this.metadata)) return;
    const { payload } = this.metadata;

    // Disable for EQT Outstream, as it is handled by the VAST TAG/IMA SDK.
    if (payload.creative.type === CreativeType.Outstream) return;

    const quartileKeyMap = {
      [QuartileKey.Q25]: TrackerEventActionId.VideoFirstQuartile,
      [QuartileKey.Q50]: TrackerEventActionId.VideoMidpoint,
      [QuartileKey.Q75]: TrackerEventActionId.VideoThirdQuartile,
      [QuartileKey.Q95]: TrackerEventActionId.VideoComplete
    };
    new URLBeacon({
      url: `${payload.reporting.trackerBaseUrl}&actionid=${quartileKeyMap[quartileKey]}`
    });
  }

  trackVideoViewDuration(_currentTime: number, _muted: boolean): void {
    // console.warn('Method trackVideoViewDuration not implemented.');
  }

  trackVideoVolumeOn(_currentTime: number): void {
    if (!this.hasPayload(this.metadata)) return;

    const { payload } = this.metadata;

    if (payload.creative.type === CreativeType.Outstream) return;

    new URLBeacon({
      url: `${payload.reporting.trackerBaseUrl}&actionid=${TrackerEventActionId.AudioOn}`
    });
  }

  trackExperiment(): void {
    // console.warn('Method trackExperiment not implemented.');
  }

  trackIsEnhanced(enhancementType?: ValidEnhancementType): void {
    if (!this.hasPayload(this.metadata)) return;

    const { payload } = this.metadata;

    if (payload.creative.type === CreativeType.Native) return;

    new URLBeacon({
      url: `${payload.reporting.trackerBaseUrl}&actionid=${TrackerEventActionId.IsEnhanced}`
    });

    const intendedType = payload.enhancement?.type;
    if (intendedType && intendedType !== enhancementType) {
      new URLBeacon({
        url: `${payload.reporting.trackerBaseUrl}&actionid=${TrackerEventActionId.DecoEnhancementFallback}`
      });
    }
  }

  trackVpaidEnabled(_vpaidEnabled: boolean): void {
    // console.warn('Method trackVpaidEnabled not implemented.');
  }

  trackClickthroughFound(_found: boolean): void {
    // console.warn('Method trackClickthroughFound not implemented.');
  }

  trackImaClick(): void {
    // console.warn('Method trackImaClick not implemented.');
  }

  trackJsTrackerFailedToLoad(_sources: string): void {
    // console.warn('Method trackJsTrackerFailedToLoad not implemented.');
  }

  trackVastError(error: number, scope: LifecycleScope): void {
    if (!this.hasPayload(this.metadata)) return;

    const { payload } = this.metadata;

    // Disable for EQT Outstream, as it is handled by the VAST TAG/IMA SDK.
    if (payload.creative.type === CreativeType.Outstream) return;

    new URLBeacon({
      url: `${payload.reporting.trackerBaseUrl}&actionid=${TrackerEventActionId.VideoError}`,
      onFailure: () => {
        reportError(new Error(`Failed to fire VAST error beacon: ${error}`), {
          scope
        });
      }
    });
  }

  trackVideoFailedToPlay(): void {
    if (!this.hasPayload(this.metadata)) return;

    const { payload } = this.metadata;

    new URLBeacon({
      url: `${payload.reporting.trackerBaseUrl}&actionid=${TrackerEventActionId.VideoError}`
    });
  }

  trackBannerRendered(_clickable: boolean, _clickableRule: string, _disableAdChoices: boolean): void {
    // console.warn('Method trackBannerRendered not implemented.');
  }

  trackDoubleVerifyError(): void {
    // console.warn('Method trackDoubleVerifyError not implemented.');
  }

  trackDoubleVerifyRender(): void {
    // console.warn('Method trackDoubleVerifyRender not implemented.');
  }

  trackDoubleVerifySuccess(): void {
    // console.warn('Method trackDoubleVerifySuccess not implemented.');
  }

  trackDoubleVerifyFallback(): void {
    // console.warn('Method trackDoubleVerifyFallback not implemented.');
  }

  trackSilentAutoPlayDuration(_durationThreshold: DurationKey): void {
    // console.warn('Method trackSilentAutoPlayDuration not implemented.');
  }

  trackPixelVisible(): void {
    if (!this.hasPayload(this.metadata)) return;
    const { payload } = this.metadata;

    if (payload.reporting.countImpressionOnePixel && payload.creative.type === CreativeType.Outstream) {
      new URLBeacon({
        url: `${payload.reporting.trackerImpressionUrl}`
      });
    }
  }

  trackUserShare(): void {
    // console.warn('Method trackUserShare not implemented.');
  }

  trackAutoplayVideoEngagement(_currentTime: number): void {
    // console.warn('Method trackAutoplayVideoEngagement not implemented.');
  }

  trackGroundControlLoaded(params: GroundControlLoadedParams): void {
    if (params.env !== 'eqt') return;

    new URLBeacon({
      url: `${params.trackerBaseUrl}&actionid=${TrackerEventActionId.GroundControlLoaded}`
    });
  }

  trackAttentionMetrics(_payload: AttentionMetricsPayload): void {
    // console.warn('Method trackAutoplayVideoEngagement not implemented.');
  }

  trackEnhancedEngagementClick(): void {
    if (!this.hasPayload(this.metadata)) return;

    const { payload } = this.metadata;

    new URLBeacon({
      url: `${payload.reporting.trackerBaseUrl}&actionid=${TrackerEventActionId.EnhancedEngagement}`
    });
  }

  trackEnhancedContentClick(): void {
    if (!this.hasPayload(this.metadata)) return;

    const { payload } = this.metadata;

    new URLBeacon({
      url: `${payload.reporting.trackerBaseUrl}&actionid=${TrackerEventActionId.EnhancedContent}`
    });
  }

  trackProductCardClick(productId?: string): void {
    if (!this.hasPayload(this.metadata)) return;

    const { payload } = this.metadata;
    const productIdParam = productId ? `&shoppableProductId=${encodeURIComponent(productId)}` : '';

    new URLBeacon({
      url: `${payload.reporting.trackerBaseUrl}&actionid=${TrackerEventActionId.ProductCard}${productIdParam}`
    });
  }

  trackShoppableCarouselArrowClick(): void {
    if (!this.hasPayload(this.metadata)) return;

    const { payload } = this.metadata;

    new URLBeacon({
      url: `${payload.reporting.trackerBaseUrl}&actionid=${TrackerEventActionId.ShoppableCarouselArrow}`
    });
  }

  trackOverlayActive(): void {
    if (!this.hasPayload(this.metadata)) return;
    const { payload } = this.metadata;

    new URLBeacon({
      url: `${payload.reporting.trackerBaseUrl}&actionid=${TrackerEventActionId.OverlayActive}`
    });
  }

  trackHeavyAdIntervention(): void {
    if (!this.hasPayload(this.metadata)) return;

    const { payload } = this.metadata;

    new URLBeacon({
      url: `${payload.reporting.trackerBaseUrl}&actionid=${TrackerEventActionId.HeavyAdIntervention}`
    });
  }

  trackBannerClickable(extraction?: ClickExtractionResult, durationMs?: number): void {
    if (!this.hasPayload(this.metadata)) return;

    const { trackerBaseUrl } = this.metadata.payload.reporting;
    if (!trackerBaseUrl) return;

    if (extraction && durationMs !== undefined) {
      const params = new URLSearchParams({
        actionid: TrackerEventActionId.BannerClickable,
        extraction_success: String(extraction.url !== null),
        extraction_method: extraction.method,
        extraction_duration_ms: String(Math.round(durationMs))
      });

      new URLBeacon({
        url: `${trackerBaseUrl}&${params.toString()}`
      });
      return;
    }

    new URLBeacon({
      url: `${trackerBaseUrl}&actionid=${TrackerEventActionId.BannerClickable}`
    });
  }

  getSasConfig(): SasConfig | undefined {
    if (!this.hasPayload(this.metadata)) return;

    const { payload } = this.metadata;

    return {
      mraidTrackingUrl: `${payload.reporting.trackerBaseUrl}&actionid=${TrackerEventActionId.MraidImpression}`,
      omidTrackingUrl: `${payload.reporting.trackerBaseUrl}&actionid=${TrackerEventActionId.OmidImpression}`,
      impressionTrackingUrl: payload.reporting.trackerImpressionUrl ?? ''
    };
  }

  trackRemoteHealthCheckFail(): void {
    //
  }

  trackRemoteHealthCheckOk(): void {
    //
  }

  trackRemoteInitialized(): void {
    //
  }

  trackEnhancementLoadFailure(): void {
    if (!this.hasPayload(this.metadata)) return;

    const { payload } = this.metadata;

    new URLBeacon({
      url: `${payload.reporting.trackerBaseUrl}&actionid=${TrackerEventActionId.EnhancementLoadFailure}`
    });
  }

  trackAmazonNativeImpression(): void {
    if (!this.hasPayload(this.metadata)) return;

    const { payload } = this.metadata;

    new URLBeacon({
      url: `${payload.reporting.trackerBaseUrl}&actionid=${TrackerEventActionId.AmazonNativeImpression}`
    });
  }

  trackFriendlyIframeEnv(): void {
    if (!this.hasPayload(this.metadata)) return;

    // Sampling gate: only fire X% of FiF trackers
    if (!shouldSampleFriendlyIframe()) return;

    const { payload } = this.metadata;

    new URLBeacon({
      url: `${payload.reporting.trackerBaseUrl}&actionid=${TrackerEventActionId.friendlyIframeEnv}`
    });
  }

  trackDcoResolutionSuccess(): void {
    if (!this.hasPayload(this.metadata)) return;

    const { payload } = this.metadata;
    if (!payload.reporting.trackerBaseUrl) return;

    new URLBeacon({
      url: `${payload.reporting.trackerBaseUrl}&actionid=${TrackerEventActionId.DcoRequestSuccess}`
    });
  }

  trackDcoResolutionFailure(): void {
    if (!this.hasPayload(this.metadata)) return;

    const { payload } = this.metadata;
    if (!payload.reporting.trackerBaseUrl) return;

    new URLBeacon({
      url: `${payload.reporting.trackerBaseUrl}&actionid=${TrackerEventActionId.DcoRequestFailure}`
    });
  }

  trackPublisherStylingRequested(): void {
    if (!this.hasPayload(this.metadata)) return;

    const { payload } = this.metadata;
    if (!payload.reporting.trackerBaseUrl) return;

    new URLBeacon({
      url: `${payload.reporting.trackerBaseUrl}&actionid=${TrackerEventActionId.PublisherStylingRequested}`
    });
  }

  trackPublisherStylingLoaded(): void {
    if (!this.hasPayload(this.metadata)) return;

    const { payload } = this.metadata;
    if (!payload.reporting.trackerBaseUrl) return;

    new URLBeacon({
      url: `${payload.reporting.trackerBaseUrl}&actionid=${TrackerEventActionId.PublisherStylingLoaded}`
    });
  }
}
