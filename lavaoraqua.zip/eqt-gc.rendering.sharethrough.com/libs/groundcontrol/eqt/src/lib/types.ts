export enum Behaviors {
  GreenPMP = 'green-pmp'
}
