import { isSupportedLanguage } from '@web-rendering/groundcontrol-butler-helpers';
import type { Creative, Network, Payload } from '@web-rendering/groundcontrol-core';
import { CreativeType } from '@web-rendering/groundcontrol-shared-types';
import { isValidCreativeType, PayloadService } from '@web-rendering/groundcontrol-core';
import type { NativeType } from '@web-rendering/groundcontrol-core';
import type { LifecycleScope } from '@web-rendering/groundcontrol-shared-types/lifecycle/lifecycle';
import { OrtbEventTrackers, setNativeAssets } from '@web-rendering/groundcontrol-ortb';
import { setRawPayload } from '@web-rendering/groundcontrol-store';
import type { Enhancement, RawPayload } from '@web-rendering/groundcontrol-shared-types';
import { parseRawEnhancement } from './parse-raw-enhancement';

export class EquativPayloadService extends PayloadService {
  parse(rawPayload: RawPayload, scope: LifecycleScope): Payload {
    setRawPayload(rawPayload);

    try {
      return {
        id: rawPayload.id,
        creative: this.getCreative(rawPayload),
        network: this.getNetwork(rawPayload),
        reporting: this.getReporting(rawPayload),
        enhancement: this.getEnhancement(rawPayload, scope),
        scenario: rawPayload.scenario
      };
    } catch (error) {
      const errorMsg = error instanceof Error ? error.message : String(error);
      throw new Error('Error parsing payload: ' + errorMsg);
    }
  }

  getCreative(rawPayload: RawPayload): Creative {
    if (!isValidCreativeType(rawPayload.creative.type)) {
      throw new Error('Invalid creative type');
    }

    if (rawPayload.creative.type === CreativeType.Native) {
      const parsedContent = JSON.parse(rawPayload.creative.content);

      if (!Array.isArray(parsedContent)) {
        throw new Error('Content must be an array for native creatives');
      }

      setNativeAssets(parsedContent);

      return {
        type: CreativeType.Native,
        content: parsedContent,
        language: isSupportedLanguage(rawPayload.creative.language) ? rawPayload.creative.language : 'en',
        size: rawPayload.creative.size,
        behaviors: rawPayload.creative.behaviors ?? [],
        partnerId: rawPayload.creative.partnerId.toString(),
        seatId: rawPayload.creative.seatId,
        creativeId: rawPayload.creative.creativeId,
        dealId: rawPayload.creative.dealId,
        trackers: new OrtbEventTrackers(rawPayload.creative.eventtrackers ?? []),
        link: rawPayload.creative.link ?? '',
        clicktrackers: rawPayload.creative.clicktrackers ?? undefined,
        // TODO: Remove this once we stop supporting NAG creatives
        nativeType: (rawPayload.creative.nativeType ?? 'clickout') as `${NativeType}`,
        assetsurl: rawPayload.creative.assetsurl
      };
    }

    if (Array.isArray(rawPayload.creative.content)) {
      throw new Error('Content must be a string for banner and outstream creatives');
    }

    return {
      type: rawPayload.creative.type,
      content: rawPayload.creative.content,
      language: isSupportedLanguage(rawPayload.creative.language) ? rawPayload.creative.language : 'en',
      size: rawPayload.creative.size,
      behaviors: rawPayload.creative.behaviors ?? [],
      partnerId: rawPayload.creative.partnerId.toString(),
      seatId: rawPayload.creative.seatId,
      creativeId: rawPayload.creative.creativeId,
      dealId: rawPayload.creative.dealId,
      link: rawPayload.creative.link ?? ''
    };
  }

  getNetwork(rawPayload: RawPayload): Network {
    return {
      networkId: rawPayload.network.networkId.toString(),
      size: {
        width: rawPayload.network.size.width,
        height: rawPayload.network.size.height
      },
      bundleId: rawPayload.network.bundleId ?? undefined,
      domain: rawPayload.network.domain,
      callerId: rawPayload.network.callerId.toString(),
      country: rawPayload.network.country
    };
  }

  getEnhancement(rawPayload: RawPayload, scope: LifecycleScope): Enhancement {
    return parseRawEnhancement(rawPayload, scope);
  }

  getReporting(rawPayload: RawPayload) {
    return {
      trackerBaseUrl: rawPayload?.reporting?.trackerBaseUrl,
      trackerImpressionUrl: rawPayload?.reporting?.trackerImpressionUrl,
      countImpressionOnePixel: rawPayload?.reporting?.countImpressionOnePixel ?? false,
      disableClickCounting: rawPayload?.reporting?.disableClickCounting
    };
  }
}
