import type { Payload } from '@web-rendering/groundcontrol-core';
import { trackerService } from '@web-rendering/groundcontrol-core';
import { CreativeType } from '@web-rendering/groundcontrol-shared-types';
import { reportError } from '@web-rendering/groundcontrol-monitoring';
import type { LifecycleScope } from '@web-rendering/groundcontrol-shared-types/lifecycle/lifecycle';
import { OrtbEventType, parseDcoResponseFromPayload, setNativeAssets } from '@web-rendering/groundcontrol-ortb';

function replaceFallbackMacro(payload: Payload, isSuccess: boolean): void {
  if (!payload.creative.trackers?.length) return;

  const replacementValue = isSuccess ? '0' : '1';
  for (const tracker of payload.creative.trackers) {
    if (tracker.event === OrtbEventType.Impression) {
      tracker.url = tracker.url.replace('{isfallback}', replacementValue);
    }
  }
}

export async function resolveEqtDco(payload: Payload, scope: LifecycleScope): Promise<void> {
  const { assetsurl } = payload.creative;
  if (!assetsurl) return;
  if (payload.creative.type !== CreativeType.Native) return;

  try {
    const dcoAssets = await parseDcoResponseFromPayload(assetsurl);

    if (dcoAssets) {
      setNativeAssets(dcoAssets);
      trackerService.value?.trackDcoResolutionSuccess();
      replaceFallbackMacro(payload, true);
    } else {
      trackerService.value?.trackDcoResolutionFailure();
      replaceFallbackMacro(payload, false);
    }
  } catch (error) {
    trackerService.value?.trackDcoResolutionFailure();
    replaceFallbackMacro(payload, false);

    reportError(error, {
      scope,
      context: 'eqt/dco-handler',
      assetsurl
    });
  }
}
