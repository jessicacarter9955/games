import type { ConfigurationService } from '@web-rendering/groundcontrol-core';

export class EqtConfigurationSettings implements ConfigurationService {
  constructor() {
    this.optOutIconConfig = {
      default: 'https://equativ.com/privacy-policy/',
      french: 'https://equativ.com/fr/privacy-policy/'
    };
  }

  optOutIconConfig: { default: string; french: string | undefined };
}
