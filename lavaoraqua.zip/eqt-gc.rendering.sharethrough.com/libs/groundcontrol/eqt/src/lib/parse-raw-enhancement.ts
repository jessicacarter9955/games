import { GCEnhancementType } from '@sharethrough/groundcontrol-enhancement-flush';
import { parseEnhancementPayload, SOFIA_PULSE_ENHANCEMENT_TYPES } from '@web-rendering/groundcontrol-core';
import { reportError } from '@web-rendering/groundcontrol-monitoring';
import type { LifecycleScope } from '@web-rendering/groundcontrol-shared-types/lifecycle/lifecycle';
import {
  type Enhancement,
  type EnhancementType,
  RawEnhancementType,
  type RawPayload
} from '@web-rendering/groundcontrol-shared-types';
import { substituteTemplateMacros } from './substitute-template-macros';

const getEnhancementType = (rawEnhancementType: RawEnhancementType): EnhancementType => {
  switch (rawEnhancementType) {
    case RawEnhancementType.Disabled:
      return 'disabled';
    case RawEnhancementType.Default:
      return 'default';
    case RawEnhancementType.OutstreamCaptions:
      return GCEnhancementType.OutstreamCaptions;
    case RawEnhancementType.OutstreamCountdown:
      return GCEnhancementType.OutstreamCountdown;
    case RawEnhancementType.OutstreamHeadline:
      return GCEnhancementType.OutstreamHeadline;
    case RawEnhancementType.OutstreamDailyWeatherOutlook:
      return GCEnhancementType.OutstreamDailyWeatherOutlook;
    case RawEnhancementType.OutstreamSportsTicker:
      return GCEnhancementType.OutstreamSportsTicker;
    case RawEnhancementType.OutstreamWeather:
      return GCEnhancementType.OutstreamWeather;
    case RawEnhancementType.BannerCountdown:
      return GCEnhancementType.BannerCountdown;
    case RawEnhancementType.BannerHeadline:
      return GCEnhancementType.BannerHeadline;
    case RawEnhancementType.BannerDailyWeatherOutlook:
      return GCEnhancementType.BannerDailyWeatherOutlook;
    case RawEnhancementType.BannerWeather:
      return GCEnhancementType.BannerWeather;
    case RawEnhancementType.BannerSportsTicker:
      return GCEnhancementType.BannerSportsTicker;
    case RawEnhancementType.BannerShoppable:
      return GCEnhancementType.BannerShoppable;
    case RawEnhancementType.OutstreamShoppable:
      return GCEnhancementType.OutstreamShoppable;
    case RawEnhancementType.BannerMedalCount:
      return GCEnhancementType.BannerMedalCount;
    case RawEnhancementType.OutstreamMedalCount:
      return GCEnhancementType.OutstreamMedalCount;
    case RawEnhancementType.BannerBrandedHeadline:
      return GCEnhancementType.BannerBrandedHeadline;
    case RawEnhancementType.OutstreamBrandedHeadlines:
      return GCEnhancementType.OutstreamBrandedHeadline;
    case RawEnhancementType.BannerShoppableOverlay:
      return GCEnhancementType.BannerShoppableOverlay;
    case RawEnhancementType.BannerWorldTournament:
      return GCEnhancementType.BannerWorldTournament;
    case RawEnhancementType.OutstreamWorldTournament:
      return GCEnhancementType.OutstreamWorldTournament;
    case RawEnhancementType.BannerCustom:
      return GCEnhancementType.BannerCustom;
    case RawEnhancementType.OutstreamCustom:
      return GCEnhancementType.OutstreamCustom;
    case RawEnhancementType.BannerSofiaPulseSportsHeadlines:
      return GCEnhancementType.BannerSofiaPulseSportsHeadlines;
    case RawEnhancementType.BannerSofiaPulseQuiz:
      return GCEnhancementType.BannerSofiaPulseQuiz;
    case RawEnhancementType.BannerSofiaPulseBettingOdds:
      return GCEnhancementType.BannerSofiaPulseBettingOdds;
    case RawEnhancementType.BannerSofiaPulseStockTicker:
      return GCEnhancementType.BannerSofiaPulseStockTicker;
    default:
      return 'default';
  }
};

export const parseRawEnhancement = (rawPayload: RawPayload, scope: LifecycleScope): Enhancement => {
  const enhancementType = getEnhancementType(rawPayload.enhancement.type);
  const enhancementPayload = parseEnhancementPayload(rawPayload.enhancement.payload);
  if (enhancementPayload) {
    if (SOFIA_PULSE_ENHANCEMENT_TYPES.has(enhancementType) && 'templateUrl' in enhancementPayload) {
      return {
        type: enhancementType,
        payload: {
          ...enhancementPayload,
          templateUrl: substituteTemplateMacros(enhancementPayload.templateUrl, rawPayload)
        },
        enhancement_version_id: rawPayload.enhancement.evid
      };
    }
    return {
      type: enhancementType,
      payload: enhancementPayload,
      enhancement_version_id: rawPayload.enhancement.evid
    };
  }

  if (enhancementType !== 'default' && enhancementType !== 'disabled') {
    reportError('Enhancement payload mismatch', {
      scope,
      callerId: rawPayload.network.callerId.toString(),
      networkId: rawPayload.network.networkId.toString(),
      partnerId: rawPayload.creative.partnerId.toString(),
      enhancement: {
        type: rawPayload.enhancement.type,
        payload: rawPayload.enhancement.payload
      }
    });

    return {
      type: 'disabled'
    };
  }

  return {
    type: enhancementType
  };
};
