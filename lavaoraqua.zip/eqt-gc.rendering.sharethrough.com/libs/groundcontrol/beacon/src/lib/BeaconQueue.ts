import type { EnqueueProps } from './types';

interface BeaconBase {
  retries: number;
  fireOnce: boolean;
  cacheKey?: string;
  sendBeacon(): Promise<boolean>;
}

class BeaconQueue {
  private static instance: BeaconQueue;
  private _queue: BeaconBase[] = [];
  private readonly cache = new Set<string>();
  private readonly queueLock = new Set<string>();
  private isProcessing = false;

  private constructor(
    private readonly batchSize = 5,
    private readonly processingInterval = 300
  ) {
    // Process queue when page is hidden
    window.addEventListener('visibilitychange', () => {
      if (document.hidden) this.processQueue();
    });
  }

  get queue(): BeaconBase[] {
    return this._queue;
  }

  static getInstance(): BeaconQueue {
    if (!BeaconQueue.instance) {
      BeaconQueue.instance = new BeaconQueue();
    }
    return BeaconQueue.instance;
  }

  private isInQueue(beacon: BeaconBase): boolean {
    return this._queue.some((b) => b.cacheKey === beacon.cacheKey);
  }

  private isAlreadyFired(beacon: BeaconBase): boolean {
    return Boolean(beacon.fireOnce && beacon.cacheKey && this.cache.has(beacon.cacheKey));
  }

  private tryLock(beacon: BeaconBase): boolean {
    if (!beacon.cacheKey) return true;
    if (this.queueLock.has(beacon.cacheKey) || this.isAlreadyFired(beacon)) return false;
    this.queueLock.add(beacon.cacheKey);
    return true;
  }

  enqueue(beacon: BeaconBase, options?: EnqueueProps): void {
    if (options?.retry) {
      // delete the cache key from the queue lock when retrying failed beacon
      beacon.cacheKey && this.queueLock.delete(beacon.cacheKey);
    }
    if (beacon.cacheKey && beacon.fireOnce && (!this.tryLock(beacon) || this.isInQueue(beacon))) return;

    this._queue.push(beacon);

    if (!this.isProcessing) {
      this.processQueue();
    }
  }

  private async processQueue(): Promise<void> {
    if (this._queue.length === 0) {
      this.isProcessing = false;
      return;
    }

    this.isProcessing = true;

    const batch = this._queue.splice(0, this.batchSize);

    await Promise.all(
      batch.map(async (beacon) => {
        try {
          const success = await beacon.sendBeacon();
          if (beacon.cacheKey && beacon.fireOnce) {
            if (success) {
              this.cache.add(beacon.cacheKey);
            } else {
              if (beacon.retries <= 0) {
                // only delete the cache key from the queue lock when retries are exhausted
                this.queueLock.delete(beacon.cacheKey);
              }
            }
          }
        } catch (error) {
          console.error('[BeaconQueue] Failed to send beacon:', error);
          // if beacon is not sent successfully, delete the cache key from the queue lock
          if (beacon.cacheKey) {
            this.queueLock.delete(beacon.cacheKey);
          }
        }
      })
    );

    setTimeout(() => this.processQueue(), this.processingInterval);
  }

  reset(): void {
    this._queue = [];
    this.cache.clear();
    this.queueLock.clear();
    this.isProcessing = false;
  }
}

export default BeaconQueue.getInstance();
