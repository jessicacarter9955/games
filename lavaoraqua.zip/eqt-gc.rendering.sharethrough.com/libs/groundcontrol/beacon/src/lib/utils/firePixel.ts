import { isTestEnvironment } from '@web-rendering/groundcontrol-utils/environment-info';
import { debug } from '@web-rendering/groundcontrol-utils/log';
import type { BeaconParam } from '../types';
import { stringParamsToObject } from './stringParamsToObject';

export const firePixel = async (url: string): Promise<void> => {
  if (isTestEnvironment()) {
    const params = stringParamsToObject(url);
    if (
      params &&
      (() => {
        for (const key in params) {
          if (Object.prototype.hasOwnProperty.call(params, key)) return true;
        }
        return false;
      })()
    ) {
      debug(`Beacon - ${getBeaconType(params)}`, params);
    } else {
      debug(`Beacon - unknown`, url);
    }
  }

  return new Promise((resolve, _reject) => {
    const img = new Image();

    img.onload = () => {
      resolve();
    };

    img.onerror = () => {
      // The promise rejects when the image fails to load, even for successful 204 responses
      // (204 = successful request with no content). This means we can't distinguish between
      // actual failures and valid empty responses. Therefore we resolve the promise in both cases.
      resolve();
    };

    img.src = url;
  });
};

interface StxBeaconParams {
  type: string;
  arid: string;
  gcid: string;
  version: string;
  umtime: string;
  renderEnv: string;
  [key: string]: BeaconParam;
}

const isStxBeacon = (params: Record<string, BeaconParam>): params is StxBeaconParams => {
  return 'type' in params && 'arid' in params;
};

interface EqtBeaconParams {
  actionid: string;
  [key: string]: BeaconParam;
}

const isEqtBeacon = (params: Record<string, BeaconParam>): params is EqtBeaconParams => {
  return 'actionid' in params;
};

const getBeaconType = (params: Record<string, BeaconParam>): string => {
  if (isStxBeacon(params)) {
    return params.type;
  }

  if (isEqtBeacon(params)) {
    return params.actionid;
  }

  return 'unknown';
};
