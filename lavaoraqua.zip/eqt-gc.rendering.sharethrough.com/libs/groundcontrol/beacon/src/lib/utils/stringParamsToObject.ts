export const stringParamsToObject = (url: string): Record<string, string> | undefined => {
  try {
    // convert URL to object
    const urlObj = new URL(url);
    const params = urlObj.searchParams;
    const result: Record<string, string> = {};

    params.forEach((value, key) => {
      result[key] = value;
    });

    return result;
  } catch (e) {
    console.log('Error converting string params to object', e);
    return;
  }
};
