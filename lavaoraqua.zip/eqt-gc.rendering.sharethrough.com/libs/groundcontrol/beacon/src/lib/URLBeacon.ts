import { BeaconBase } from './BeaconBase';
import type { BeaconEvents } from './types';
import { firePixel } from './utils';

interface URLBeaconProps extends BeaconEvents {
  url: string;
}

export class URLBeacon extends BeaconBase {
  url: string;

  constructor(props: URLBeaconProps) {
    super();

    this.url = props.url;

    this.onSuccess = props.onSuccess;
    this.onFailure = props.onFailure;

    this.fireOnce = true;
    this.cacheKey = this.url;

    this.enqueue();
  }

  async fire(): Promise<void> {
    return firePixel(this.url);
  }
}
