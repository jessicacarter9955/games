export type BeaconParam = string | number | boolean;

export interface EnqueueProps {
  retry: boolean;
}
export type AdserverRequestId = string | 'no-arid';

export enum BeaconType {
  adPositionChanged = 'adPositionChanged',
  attentionMetrics = 'attentionMetrics',
  bannerRendered = 'banner.rendered',
  beaconError = 'beaconError',
  bundleIdWinTest = 'bundle_id_win_test',
  chromeTopics = 'chromeTopics',
  completionPercent = 'completionPercent',
  dcoRequest = 'DCORequest',
  doubleVerifyError = 'doubleVerifyError',
  doubleVerifyFallback = 'doubleVerifyFallback',
  doubleVerifyRender = 'doubleVerifyRender',
  doubleVerifySuccess = 'doubleVerifySuccess',
  experiment = 'is_experiment',
  groundControlPresent = 'groundControlPresent',
  heavyAdIntervention = 'heavyAdIntervention',
  imaClick = 'imaClick',
  imaNoCreativeIdFound = 'imaNoCreativeIdFound',
  impression = 'impression',
  impressionReceived = 'impressionReceived',
  isEnhanced = 'isEnhanced',
  jsTrackerFailedToLoad = 'jsTrackerFailedToLoad',
  nurlFail = 'winNotificationFail',
  pixelVisibleInApp = 'pixelVisibleInApp',
  silentAutoPlayDuration = 'silentAutoPlayDuration',
  subtitlesEnabled = 'subtitlesEnabled',
  userEvent = 'userEvent',
  vastClickthroughFound = 'vastClickthroughFound',
  vastClickthroughNotFound = 'vastClickthroughNotFound',
  vastErrorCode = 'vastErrorCode',
  vastVpaidEnabled = 'VastVpaidEnabled',
  vastVpaidNotEnabled = 'VastVpaidNotEnabled',
  videoPlay = 'videoPlay',
  videoStart = 'videoStart',
  videoViewDuration = 'videoViewDuration',
  videoVolumeOn = 'videoVolumeOn',
  viewableImpression = 'visible'
}

export enum UserEvent {
  AutoplayVideoEngagement = 'autoplayVideoEngagement',
  Clickout = 'clickout',
  Share = 'share',
  EnhancedEngagement = 'enhancedEngagement',
  EnhancedContent = 'enhancedContent',
  ProductCard = 'productCard',
  ShoppableCarouselArrow = 'shoppableCarouselArrow',
  OverlayActive = 'overlayActive'
}

export enum VideoTypes {
  clickToPlay = 'clickToPlay',
  instantPlay = 'instant'
}

export type BeaconData = {
  type: BeaconType;
  arid: AdserverRequestId;
  [key: string]: BeaconParam;
};

export interface BeaconEvents {
  onFailure?: () => void;
  onSuccess?: () => void;
}

export enum CreativeBeaconType {
  Click = 'click',
  Impression = 'impression',
  Play = 'play',
  Visible = 'visible',
  WinNotification = 'win-notification',
  VideoWinNotification = 'video-win-notification',
  VideoImpression = 'video-impression',
  FirstQuartile = 'first_quartile',
  Midpoint = 'midpoint',
  ThirdQuartile = 'third_quartile',
  CompletedSilentPlay = 'completed_silent_play',
  SilentPlay = 'silent_play',
  TenSecondSilentPlay = 'ten_second_silent_play',
  FifteenSecondSilentPlay = 'fifteen_second_silent_play',
  ThirtySecondSilentPlay = 'thirty_second_silent_play'
}

export type BeaconOptions = Omit<BeaconData, 'type' | 'arid'>;

export enum QuartileKey {
  Q25 = '25',
  Q50 = '50',
  Q75 = '75',
  Q95 = '95'
}
export type DurationKey = 3 | 10 | 15 | 30;

export interface AttentionMetricsRawSnapshot {
  timestamp: number;
  data: {
    top: number;
    bottom: number;
    left: number;
    right: number;
    vp_w: number;
    vp_h: number;
    zoom_ratio: number;
  } | null;
}
export interface AttentionMetricsSnapshot {
  ts_offset: number; // seconds after init_ts
  vp_w: number; // viewport width
  vp_h: number; // viewport height
  x: number; // x position of upper left hand corner of ad relative to viewport
  y: number; // y position of upper left hand corner of ad relative to viewport
  zoom_ratio: number; // device pixel ratio
}

export interface AttentionMetricsPayload {
  init_ts: number;
  wait: number;
  step: number;
  ad_w: number;
  ad_h: number;
  hovers: number;
  hover_cumulative_time: number;
  hover_consecutive_time: number;
  data: AttentionMetricsSnapshot[];
}
