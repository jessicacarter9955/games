import { getGroundControlInstanceId } from '@web-rendering/groundcontrol-store';
import { isTestEnvironment } from '@web-rendering/groundcontrol-utils/environment-info';
import { objToQueryString } from '@web-rendering/groundcontrol-utils/groundcontrol-utils';
import { renderEnv } from '@web-rendering/groundcontrol-utils/location-utils';
import { BeaconBase } from './BeaconBase';
import { BeaconError } from './BeaconError';
import type { BeaconData, BeaconEvents } from './types';
import { firePixel } from './utils';

const beaconPrioritizedParams: { [index: string]: number } = {
  type: 1,
  arid: 2,
  pkey: 3,
  supplyId: 4,
  ckey: 6,
  userEvent: 7,
  umtime: 8
};

interface BeaconProps extends BeaconEvents {
  data: BeaconData;
  fireOnce?: boolean;
  cacheKey?: string;
}

/**
 * @class Beacon
 * @extends BeaconBase
 * @description Instantiates a new beacon based on a data object to be added to the queue.
 */
export class Beacon extends BeaconBase {
  data: BeaconData;
  url: string;

  constructor(props: BeaconProps) {
    super();

    this.data = {
      renderEnv: renderEnv(),
      umtime: window.Date.now().toString(),
      version: VERSION,
      gcid: getGroundControlInstanceId(),
      ...props.data
    };

    this.url = this.getBeaconUrl();

    this.onSuccess = props.onSuccess;
    this.onFailure = props.onFailure;

    this.fireOnce = !!props.fireOnce;
    this.cacheKey = props.cacheKey || `${this.data.type}-${this.data.arid}`;

    this.enqueue();
  }

  getBeaconUrl(): string {
    // I tried to import dev Config from the config.development.json file
    // but raise errors in many testing files: Missing semicolon
    // mock json file in tests could be a way but it is too exhaustive
    const testTrackingDomain = 'https://b-staging.sharethrough.com';
    const trackingDomain = isTestEnvironment() ? testTrackingDomain : CONFIG.trackingDomain;
    const resource = 'butler';
    const queryString = objToQueryString(this.data, beaconPrioritizedParams);

    return `${trackingDomain}/${resource}?${queryString}`;
  }

  async fire(): Promise<void> {
    return firePixel(this.url).catch((error: unknown) => {
      if (error instanceof BeaconError) {
        error.details.arid = this.data.arid;
        error.details.url = this.url;
      }

      throw error;
    });
  }
}
