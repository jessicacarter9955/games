import type { EnqueueProps } from './types';
import BeaconQueue from './BeaconQueue';

export abstract class BeaconBase {
  retries = 3;
  fireOnce = false;
  cacheKey?: string;

  abstract url: string;
  abstract fire(): Promise<void>;

  onFailure?(): void;
  onSuccess?(): void;

  enqueue(options?: EnqueueProps): void {
    BeaconQueue.enqueue(this, options);
  }

  async sendBeacon(): Promise<boolean> {
    try {
      await this.fire();

      this.onSuccess && this.onSuccess();

      return true;
    } catch (error) {
      this.retries--;
      if (this.retries > 0) {
        // pass retry as an option if cacheKey is set. the signal is used to determine if should unlock first
        this.cacheKey ? this.enqueue({ retry: true }) : this.enqueue();
      } else {
        this.onFailure && this.onFailure();
      }

      return false;
    }
  }
}
