export type BeaconFailureReason = 'TIMEOUT' | 'INVALID_URL' | 'IMG_ON_ERROR';

// -- TODO: suppressing in bulk --
// eslint-disable-next-line @typescript-eslint/no-explicit-any
type BeaconErrorDetails = Record<string, any> & {
  failureReason: BeaconFailureReason;
  url?: string;
  arid?: string;
};

export class BeaconError extends Error {
  public override readonly name: string = 'BeaconError';
  public readonly details: BeaconErrorDetails;

  // -- TODO: suppressing in bulk --
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  constructor(failureReason: BeaconFailureReason, details?: Record<string, any>) {
    super(failureReason);
    this.details = {
      failureReason,
      ...details
    };

    Object.setPrototypeOf(this, BeaconError.prototype);
  }
}
