// Most types copied from legacy/**/dco
import { fetchWithTimeout } from '@web-rendering/groundcontrol-utils/fetch-with-timeout';
import { setNativeAssets } from './signal';
import type { RawNativeAssets } from './types/assets';

export type DcoDataAsset = {
  type: number;
  value: string;
};

export type DcoVideoAsset = {
  vasttag: string;
};

export type DcoLinkAsset = {
  url: string;
  clicktrackers: string[];
};

export type DcoImageAsset = {
  type: number;
  url: string;
  h: number;
  w: number;
};

export type DcoTitleAsset = {
  text: string;
};

export type DcoEventTracker = {
  url: string;
  event: number;
  method: number;
};

export type DcoAsset = {
  title?: DcoTitleAsset;
  img?: DcoImageAsset;
  data?: DcoDataAsset;
  video?: DcoVideoAsset;
  link?: DcoLinkAsset;
};

export type DcoAssetResponse = {
  assets: DcoAsset[];
  eventtrackers: DcoEventTracker[];
};

export const DCO_REQUEST_TIMEOUT = 1200;

export const getErrorMessage = (error: unknown): string => {
  if (error instanceof Error) {
    return error.message;
  }
  return typeof error === 'string' ? error : 'Unknown error';
};

export async function parseDcoResponseFromPayload(url: string): Promise<DcoAsset[] | null> {
  /** 
   * Comment out until we decide to fire beacon or not 
   *   if (!url) {
   *     DcoHandler.fireBeacon(
   *      {
   *        result: DcoStatus.Failure,
   *        name: 'No asset URL'
   *      },
   *        payload
   *      );
   *
   *      return null;
   *    }

   */

  try {
    let response: Response;
    try {
      response = await fetchWithTimeout(url, {
        timeout: DCO_REQUEST_TIMEOUT
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
    } catch (error) {
      const message = getErrorMessage(error);
      throw new Error(`DCO Request Failed : ${message}`);
    }

    const responseText = await response.text();
    if (responseText.trim().length === 0) {
      return null;
    }

    let assetResponse: DcoAssetResponse;
    try {
      assetResponse = JSON.parse(responseText);
    } catch {
      // Amazon answers an expired bid's assetsurl with an HTML document under a JSON
      // content-type (WR-2304); treat any non-JSON body as a clean fallback, not an error.
      return null;
    }

    if (Object.keys(assetResponse).length === 0) {
      return null;
    }

    return assetResponse.assets;
  } catch (error) {
    const message = getErrorMessage(error);
    console.error('Failed to parse Dco assets', message);
    /**
     * Comment out until we decide to fire beacon or not
     *     const result = message.includes('timeout') ? DcoStatus.RequestTimeout : DcoStatus.Failure;
     *
     *      DcoHandler.fireBeacon(
     *         {
     *           result,
     *           name: error instanceof Error ? error.message : error
     *         },
     *           payload
     *       );
     */

    throw error;
  }
}

export function replaceNativeAssetWithDco(url: string, nativeAssets: RawNativeAssets): void {
  parseDcoResponseFromPayload(url)
    .then((dcoNativeAssets) => {
      if (dcoNativeAssets) {
        setNativeAssets(dcoNativeAssets);
      }
    })
    .catch((_) => {
      setNativeAssets(nativeAssets);
    });
}
