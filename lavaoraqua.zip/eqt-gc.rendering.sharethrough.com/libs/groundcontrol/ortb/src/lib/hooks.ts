import { useContext } from 'preact/hooks';

import { NativeAssetsContext } from './context';
import { nativeAssets } from './signal';

export const useNativeAssets = () => {
  const scopedAssets = useContext(NativeAssetsContext);
  if (scopedAssets) {
    return scopedAssets;
  }

  if (!nativeAssets.value) {
    return null;
  }

  return nativeAssets.value;
};
