import { AssetIdMapEQT } from './assets-mapping-eqt';
import { AssetIdMapSTR } from './assets-mapping-str';

export const getAssetsMapping = () => {
  try {
    if (GC_INSTANCE_NAME === 'equativ') return AssetIdMapEQT;

    return AssetIdMapSTR;
  } catch (error) {
    console.error('Error getting assets mapping', error);
    return AssetIdMapSTR;
  }
};
