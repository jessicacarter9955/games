import { createContext } from 'preact';

import type { NativeAssets } from './parser';

// One ad's assets. The page-wide `nativeAssets` signal holds whichever ad parsed last, so a page
// with several native ads shows the last one's assets in every slot; an ad that provides this
// context reads its own instead.
export const NativeAssetsContext = createContext<NativeAssets | undefined>(undefined);
