import { DataAssetType, ImageAssetType } from '@web-rendering/groundcontrol-shared-types';

export const AssetIdMapEQT: Record<number, ImageAssetType | DataAssetType> = {
  2: ImageAssetType.MAIN,
  4: DataAssetType.CTATEXT,

  5: DataAssetType.SPONSORED,
  6: ImageAssetType.ICON,

  9: DataAssetType.DESC,
  10: DataAssetType.RATING,
  11: DataAssetType.PRICE,
  31: ImageAssetType.LOGO, // defaultNative12BrandLogoId

  403: DataAssetType.RATING, // ortbTypeRating
  404: DataAssetType.LIKES, // ortbTypeLikes
  406: DataAssetType.PRICE, // ortbTypePrice
  407: DataAssetType.SALEPRICE, // ortbTypeSalePrice

  // Amazon specific IDs
  507: DataAssetType.BADGE, // defaultAmazonDealBadgeId
  508: DataAssetType.REVIEW, // defaultAmazonCustomerReviewId
  511: DataAssetType.CLIMATE_PLEDGE, // defaultAmazonClimatePledgeId
  512: DataAssetType.COUPON, // defaultAmazonCouponSavingsId
  513: ImageAssetType.AVAILABLE_ON_AMAZON, // defaultAmazonAvailableId
  514: ImageAssetType.PRIME_LOGO // defaultAmazonPrimeLogoId
};
