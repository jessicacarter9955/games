import type { DataAssetType } from '@web-rendering/groundcontrol-shared-types';

import type { AssetBase } from './base';

export type ShoppableFormat = 'single_product' | 'single_product_carousel' | 'multi_product_carousel';

export type ShoppableImage = { url: string; w?: number; h?: number };

export type ShoppableProduct = {
  link: string;
  name?: string;
  salePrice?: string;
  originalPrice?: string;
  description?: string;
  images?: ShoppableImage[];
};

// CTA theming sent by MBMB. Field names mirror the enhancement CTA contract; values
// arrive as bare hex (no leading '#') and are normalized at parse time.
export type ShoppableCtaStyle = {
  textColor?: string;
  textHoverColor?: string;
  backgroundColor?: string;
  backgroundHoverColor?: string;
};

export type ShoppableExt = {
  format: ShoppableFormat;
  products: ShoppableProduct[];
  shuffle?: boolean;
  ctaStyle?: ShoppableCtaStyle;
  sponsoredBy?: string;
};

export type ShoppableMarkerAsset = AssetBase & {
  data: { type: DataAssetType.SHOPPABLE; ext: ShoppableExt };
};

const SHOPPABLE_FORMATS: readonly ShoppableFormat[] = [
  'single_product',
  'single_product_carousel',
  'multi_product_carousel'
];

export const isShoppableFormat = (value: unknown): value is ShoppableFormat =>
  typeof value === 'string' && SHOPPABLE_FORMATS.includes(value as ShoppableFormat);

// Accept 3/4/6/8-digit hex, with or without a leading '#'. Anything else (including
// CSS that could break out of the inline style) is rejected.
const HEX_COLOR = /^#?(?:[0-9a-fA-F]{3,4}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})$/;

const normalizeHexColor = (value: unknown): string | undefined => {
  if (typeof value !== 'string') return undefined;
  const trimmed = value.trim();
  if (!HEX_COLOR.test(trimmed)) return undefined;
  return trimmed.startsWith('#') ? trimmed : `#${trimmed}`;
};

export const normalizeCtaStyle = (style: ShoppableCtaStyle | undefined): ShoppableCtaStyle | undefined => {
  if (!style || typeof style !== 'object') return undefined;

  const normalized: ShoppableCtaStyle = {
    textColor: normalizeHexColor(style.textColor),
    textHoverColor: normalizeHexColor(style.textHoverColor),
    backgroundColor: normalizeHexColor(style.backgroundColor),
    backgroundHoverColor: normalizeHexColor(style.backgroundHoverColor)
  };

  return Object.values(normalized).some(Boolean) ? normalized : undefined;
};
