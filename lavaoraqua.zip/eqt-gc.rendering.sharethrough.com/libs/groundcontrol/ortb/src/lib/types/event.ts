export enum OrtbEventType {
  Impression = 1,
  ViewableMrc50 = 2
}

export enum OrtbEventMethod {
  Img = 1,
  Js = 2
}

export class OrtbEventTracker {
  constructor(event: { event: number; method: number; url: string }) {
    this.event = event.event;
    this.method = event.method;
    this.url = event.url;
  }

  event: OrtbEventType;
  method: OrtbEventMethod;
  url: string;
}

const isValidOrtbEventTracker = (obj: unknown): obj is OrtbEventTracker => {
  return (
    typeof obj === 'object' &&
    obj !== null &&
    'event' in obj &&
    typeof obj.event === 'number' &&
    Object.values(OrtbEventType).includes(obj.event) &&
    'method' in obj &&
    typeof obj.method === 'number' &&
    Object.values(OrtbEventMethod).includes(obj.method) &&
    'url' in obj &&
    typeof obj.url === 'string' &&
    obj.url !== ''
  );
};

export class OrtbEventTrackers extends Array<OrtbEventTracker> {
  constructor(trackers: unknown) {
    const array = Array.isArray(trackers) ? trackers : [];
    super(...array.filter((event) => isValidOrtbEventTracker(event)).map((tracker) => new OrtbEventTracker(tracker)));
  }

  private insertJsTracker(trackers: OrtbEventTracker[], containerHtmlElement: HTMLElement): void {
    const validTrackers = trackers
      .filter((tracker) => tracker.method === OrtbEventMethod.Js)
      .map((tracker) => tracker.url);

    for (const jsTracker of validTrackers) {
      const script = document.createElement('script');
      script.type = 'text/javascript';
      script.async = true;
      script.src = jsTracker;

      containerHtmlElement.appendChild(script);
    }
  }

  private insertImgTracker(trackers: OrtbEventTracker[]): void {
    const imgPromise = async (url: string): Promise<void> => {
      return new Promise((resolve, _reject) => {
        const img = new Image();
        img.onload = () => {
          resolve();
        };
        img.onerror = () => {
          resolve();
        };
        img.src = url;
      });
    };

    const validTrackers = trackers
      .filter((tracker) => tracker.method === OrtbEventMethod.Img)
      .map((tracker) => tracker.url);

    for (const imgTracker of validTrackers) {
      imgPromise(imgTracker).catch((error) => {
        console.error('Error loading image tracker:', error);
      });
    }
  }

  private getTrackersByType(eventType: OrtbEventType): {
    jsTrackers: OrtbEventTracker[];
    imgTrackers: OrtbEventTracker[];
  } {
    const jsTrackers = this.filter((tracker) => tracker.event === eventType && tracker.method === OrtbEventMethod.Js);
    const imgTrackers = this.filter((tracker) => tracker.event === eventType && tracker.method === OrtbEventMethod.Img);
    return { jsTrackers, imgTrackers };
  }

  fireEventTrackerByType(eventType: OrtbEventType, containerHtmlElement: HTMLElement): void {
    try {
      const { jsTrackers, imgTrackers } = this.getTrackersByType(eventType);
      this.insertJsTracker(jsTrackers, containerHtmlElement);
      this.insertImgTracker(imgTrackers);
    } catch (error) {
      console.error('Error firing impression trackers:', error);
    }
  }
}
