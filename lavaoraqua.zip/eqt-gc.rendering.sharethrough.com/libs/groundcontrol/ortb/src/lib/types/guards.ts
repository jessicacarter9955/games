import { getAssetsMapping } from '../get-assets-mapping';
import { DataAssetType, ImageAssetType } from '@web-rendering/groundcontrol-shared-types';
import { type Asset } from './assets';
import { type DataAsset } from './data';
import { type ImageAsset } from './image';
import { type AssetWithLink } from './link';
import { type ShoppableMarkerAsset } from './shoppable';
import { type TitleAsset } from './title';
import { type VideoAsset } from './video';

const AssetIdMap = getAssetsMapping();

// Helper function to get IDs for a specific type
const getAssetIdsByType = <T>(type: T): number[] => {
  return Object.entries(AssetIdMap)
    .filter(([_, assetType]) => assetType === type)
    .map(([id]) => Number(id));
};

// Prefer img.type when present; fall back to id mapping for payloads that omit it
const matchesImageType = (asset: ImageAsset, type: ImageAssetType): boolean =>
  asset.img.type !== undefined ? asset.img.type === type : getAssetIdsByType(type).includes(asset.id);

// Image Asset Type Guards
export const isIcon = (asset: Asset): asset is ImageAsset<ImageAssetType.ICON> => {
  return isImageAsset(asset) && matchesImageType(asset, ImageAssetType.ICON);
};

export const isLogo = (asset: Asset): asset is ImageAsset<ImageAssetType.LOGO> => {
  return isImageAsset(asset) && matchesImageType(asset, ImageAssetType.LOGO);
};

export const isMainImage = (asset: Asset): asset is ImageAsset<ImageAssetType.MAIN> => {
  return isImageAsset(asset) && matchesImageType(asset, ImageAssetType.MAIN);
};

export const isPrimeLogo = (asset: Asset): asset is ImageAsset<ImageAssetType.PRIME_LOGO> => {
  return isImageAsset(asset) && matchesImageType(asset, ImageAssetType.PRIME_LOGO);
};

export const isAvailableOnAmazon = (asset: Asset): asset is ImageAsset<ImageAssetType.AVAILABLE_ON_AMAZON> => {
  return isImageAsset(asset) && matchesImageType(asset, ImageAssetType.AVAILABLE_ON_AMAZON);
};

// Prefer data.type when present; fall back to id mapping for payloads that omit it
const matchesDataType = (asset: DataAsset, type: DataAssetType): boolean =>
  asset.data.type !== undefined ? asset.data.type === type : getAssetIdsByType(type).includes(asset.id);

// Data Asset Type Guards
export const isSponsored = (asset: Asset): asset is DataAsset<DataAssetType.SPONSORED> => {
  return isDataAsset(asset) && matchesDataType(asset, DataAssetType.SPONSORED);
};

export const isDescription = (asset: Asset): asset is DataAsset<DataAssetType.DESC> => {
  return isDataAsset(asset) && matchesDataType(asset, DataAssetType.DESC);
};

export const isRating = (asset: Asset): asset is DataAsset<DataAssetType.RATING> => {
  return isDataAsset(asset) && matchesDataType(asset, DataAssetType.RATING);
};

export const isCTA = (asset: Asset): asset is DataAsset<DataAssetType.CTATEXT> => {
  return isDataAsset(asset) && matchesDataType(asset, DataAssetType.CTATEXT);
};

export const isLikes = (asset: Asset): asset is DataAsset<DataAssetType.LIKES> => {
  return isDataAsset(asset) && matchesDataType(asset, DataAssetType.LIKES);
};

export const isDownloads = (asset: Asset): asset is DataAsset<DataAssetType.DOWNLOADS> => {
  return isDataAsset(asset) && matchesDataType(asset, DataAssetType.DOWNLOADS);
};

export const isPrice = (asset: Asset): asset is DataAsset<DataAssetType.PRICE> => {
  return isDataAsset(asset) && matchesDataType(asset, DataAssetType.PRICE);
};

export const isSalePrice = (asset: Asset): asset is DataAsset<DataAssetType.SALEPRICE> => {
  return isDataAsset(asset) && matchesDataType(asset, DataAssetType.SALEPRICE);
};

export const isPhone = (asset: Asset): asset is DataAsset<DataAssetType.PHONE> => {
  return isDataAsset(asset) && matchesDataType(asset, DataAssetType.PHONE);
};

export const isAddress = (asset: Asset): asset is DataAsset<DataAssetType.ADDRESS> => {
  return isDataAsset(asset) && matchesDataType(asset, DataAssetType.ADDRESS);
};

export const isDesc2 = (asset: Asset): asset is DataAsset<DataAssetType.DESC2> => {
  return isDataAsset(asset) && matchesDataType(asset, DataAssetType.DESC2);
};

export const isDisplayUrl = (asset: Asset): asset is DataAsset<DataAssetType.DISPLAYURL> => {
  return isDataAsset(asset) && matchesDataType(asset, DataAssetType.DISPLAYURL);
};

export const isBadge = (asset: Asset): asset is DataAsset<DataAssetType.BADGE> => {
  return isDataAsset(asset) && matchesDataType(asset, DataAssetType.BADGE);
};

export const isReview = (asset: Asset): asset is DataAsset<DataAssetType.REVIEW> & AssetWithLink => {
  return isDataAsset(asset) && matchesDataType(asset, DataAssetType.REVIEW);
};

export const isCoupon = (asset: Asset): asset is DataAsset<DataAssetType.COUPON> => {
  return isDataAsset(asset) && matchesDataType(asset, DataAssetType.COUPON);
};

// The 520 marker always carries data.type explicitly (internal GC ↔ MBMB contract) and has
// no id→type mapping, so match on type directly rather than via matchesDataType's id fallback.
export const isShoppableMarker = (asset: Asset): asset is ShoppableMarkerAsset =>
  isDataAsset(asset) && asset.data.type === DataAssetType.SHOPPABLE;

// Generic Type Guards
export const isDataAsset = (asset: unknown): asset is DataAsset => {
  return typeof asset === 'object' && asset !== null && 'data' in asset;
};

export const isImageAsset = (asset: unknown): asset is ImageAsset => {
  return typeof asset === 'object' && asset !== null && 'img' in asset;
};

export const isTitleAsset = (asset: unknown): asset is TitleAsset => {
  return typeof asset === 'object' && asset !== null && 'title' in asset;
};

export const isVideoAsset = (asset: unknown): asset is VideoAsset => {
  return typeof asset === 'object' && asset !== null && 'video' in asset;
};
