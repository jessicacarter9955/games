import { DataAssetType, ImageAssetType } from '@web-rendering/groundcontrol-shared-types';

export const AssetIdMapSTR = {
  // Default IDs to ORTB types
  1: 'title', // defaultTitleId
  2: ImageAssetType.ICON, // defaultMobileThumbnailId
  3: ImageAssetType.LOGO, // defaultBrandLogoId
  4: ImageAssetType.MAIN, // defaultDesktopThumbnailId
  5: DataAssetType.SPONSORED, // defaultSponsoredByMessageId
  6: DataAssetType.DESC, // defaultDescriptionId
  11: DataAssetType.OPT_OUT, // defaultOptoutTextId
  12: DataAssetType.OPT_OUT_URL, // defaultOptoutUrlId

  14: DataAssetType.CTATEXT, // defaultCallToActionTextId

  // Native 1.1 IDs
  21: ImageAssetType.LOGO, // defaultNative11BrandLogoId
  22: ImageAssetType.MAIN, // defaultNative11MobileThumbnailId
  23: ImageAssetType.MAIN, // defaultNative11DesktopThumbnailId

  // Native 1.2 IDs
  31: ImageAssetType.LOGO, // defaultNative12BrandLogoId
  32: ImageAssetType.MAIN, // defaultNative12MobileThumbnailId
  33: ImageAssetType.MAIN, // defaultNative12DesktopThumbnailId

  // Custom IDs
  503: DataAssetType.ISI, // defaultIsiTextId
  504: DataAssetType.BANNER, // defaultBannerAssetId

  // Amazon specific IDs
  507: DataAssetType.BADGE, // defaultAmazonDealBadgeId
  508: DataAssetType.REVIEW, // defaultAmazonCustomerReviewId
  511: DataAssetType.CLIMATE_PLEDGE, // defaultAmazonClimatePledgeId
  512: DataAssetType.COUPON, // defaultAmazonCouponSavingsId
  513: ImageAssetType.AVAILABLE_ON_AMAZON, // defaultAmazonAvailableId
  514: ImageAssetType.PRIME_LOGO, // defaultAmazonPrimeLogoId

  // ORTB standard types
  403: DataAssetType.RATING, // ortbTypeRating
  404: DataAssetType.LIKES, // ortbTypeLikes
  406: DataAssetType.PRICE, // ortbTypePrice
  407: DataAssetType.SALEPRICE // ortbTypeSalePrice
};
