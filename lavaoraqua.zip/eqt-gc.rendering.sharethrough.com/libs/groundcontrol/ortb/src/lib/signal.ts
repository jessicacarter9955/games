import { signal } from '@preact/signals';
import { NativeAssets } from './parser';
import type { RawNativeAssets } from './types/assets';

export const nativeAssets = signal<NativeAssets | undefined>(undefined);

export const setNativeAssets = (assets: RawNativeAssets) => {
  nativeAssets.value = new NativeAssets(assets);
};
