import type { DataAssetType, ImageAssetType } from '@web-rendering/groundcontrol-shared-types';
import type { RawNativeAssets } from './types/assets';
import type { DataAsset } from './types/data';
import {
  isAddress,
  isAvailableOnAmazon,
  isBadge,
  isCoupon,
  isCTA,
  isDesc2,
  isDescription,
  isDisplayUrl,
  isDownloads,
  isIcon,
  isLikes,
  isLogo,
  isMainImage,
  isPhone,
  isPrice,
  isPrimeLogo,
  isRating,
  isReview,
  isSalePrice,
  isShoppableMarker,
  isSponsored,
  isTitleAsset
} from './types/guards';
import type { ShoppableExt } from './types/shoppable';
import { isShoppableFormat, normalizeCtaStyle } from './types/shoppable';
import type { ImageAsset } from './types/image';
import type { TitleAsset } from './types/title';
import { shuffle } from './shuffle';

export class NativeAssets {
  constructor(private assets: RawNativeAssets) {}

  private _title: TitleAsset | undefined;
  get title() {
    if (!this._title) {
      this._title = this.assets.find(isTitleAsset);
    }

    return this._title;
  }

  private _mainImage: ImageAsset<ImageAssetType.MAIN> | undefined;
  get mainImage() {
    if (!this._mainImage) {
      this._mainImage = this.assets.find(isMainImage);
    }

    return this._mainImage;
  }

  private _logo: ImageAsset<ImageAssetType.LOGO> | undefined;
  get logo() {
    if (!this._logo) {
      this._logo = this.assets.find(isLogo);
    }

    return this._logo;
  }

  private _icon: ImageAsset<ImageAssetType.ICON> | undefined;
  get icon() {
    if (!this._icon) {
      this._icon = this.assets.find(isIcon);
    }

    // Some advertisers use the same image for the icon and the main image.
    // In this case, we should not use the icon asset.
    if (this._icon?.img.url === this.mainImage?.img.url) return;

    return this._icon;
  }

  private _primeLogo: ImageAsset<ImageAssetType.PRIME_LOGO> | undefined;
  get primeLogo() {
    if (!this._primeLogo) {
      this._primeLogo = this.assets.find(isPrimeLogo);
    }

    return this._primeLogo;
  }

  private _availableOnAmazon: ImageAsset<ImageAssetType.AVAILABLE_ON_AMAZON> | undefined;
  get availableOnAmazon() {
    if (!this._availableOnAmazon) {
      this._availableOnAmazon = this.assets.find(isAvailableOnAmazon);
    }
    return this._availableOnAmazon;
  }

  private _sponsored: DataAsset<DataAssetType.SPONSORED> | undefined;
  get sponsored() {
    if (!this._sponsored) {
      this._sponsored = this.assets.find(isSponsored);
    }

    return this._sponsored;
  }

  private _description: DataAsset<DataAssetType.DESC> | undefined;
  get description() {
    if (!this._description) {
      this._description = this.assets.find(isDescription);
    }

    return this._description;
  }

  private _rating: DataAsset<DataAssetType.RATING> | undefined;
  get rating() {
    if (!this._rating) {
      this._rating = this.assets.find(isRating);
    }

    return this._rating;
  }

  private _likes: DataAsset<DataAssetType.LIKES> | undefined;
  get likes() {
    if (!this._likes) {
      this._likes = this.assets.find(isLikes);
    }

    return this._likes;
  }

  private _downloads: DataAsset<DataAssetType.DOWNLOADS> | undefined;
  get downloads() {
    if (!this._downloads) {
      this._downloads = this.assets.find(isDownloads);
    }

    return this._downloads;
  }

  private _price: DataAsset<DataAssetType.PRICE> | undefined;
  get price() {
    if (!this._price) {
      this._price = this.assets.find(isPrice);
    }

    return this._price;
  }

  private _salePrice: DataAsset<DataAssetType.SALEPRICE> | undefined;
  get salePrice() {
    if (!this._salePrice) {
      this._salePrice = this.assets.find(isSalePrice);
    }

    return this._salePrice;
  }

  private _phone: DataAsset<DataAssetType.PHONE> | undefined;
  get phone() {
    if (!this._phone) {
      this._phone = this.assets.find(isPhone);
    }

    return this._phone;
  }

  private _address: DataAsset<DataAssetType.ADDRESS> | undefined;
  get address() {
    if (!this._address) {
      this._address = this.assets.find(isAddress);
    }

    return this._address;
  }

  private _desc2: DataAsset<DataAssetType.DESC2> | undefined;
  get desc2() {
    if (!this._desc2) {
      this._desc2 = this.assets.find(isDesc2);
    }

    return this._desc2;
  }

  private _displayUrl: DataAsset<DataAssetType.DISPLAYURL> | undefined;
  get displayUrl() {
    if (!this._displayUrl) {
      this._displayUrl = this.assets.find(isDisplayUrl);
    }

    return this._displayUrl;
  }

  private _cta: DataAsset<DataAssetType.CTATEXT> | undefined;
  get cta() {
    if (!this._cta) {
      this._cta = this.assets.find(isCTA);
    }

    return this._cta;
  }

  private _review: DataAsset<DataAssetType.REVIEW> | undefined;
  get review() {
    if (!this._review) {
      this._review = this.assets.find(isReview);
    }

    return this._review;
  }

  private _badge: DataAsset<DataAssetType.BADGE> | undefined;
  get badge() {
    if (!this._badge) {
      this._badge = this.assets.find(isBadge);
    }

    return this._badge;
  }

  private _coupon: DataAsset<DataAssetType.COUPON> | undefined;
  get coupon() {
    if (!this._coupon) {
      this._coupon = this.assets.find(isCoupon);
    }

    return this._coupon;
  }

  private _shoppable: ShoppableExt | null | undefined;
  get shoppable(): ShoppableExt | undefined {
    if (this._shoppable === undefined) {
      const ext = this.assets.find(isShoppableMarker)?.data.ext;
      if (!ext || !isShoppableFormat(ext.format)) {
        this._shoppable = null;
      } else {
        let products = ext.products ?? [];
        if (ext.shuffle) {
          if (ext.format === 'multi_product_carousel') {
            products = shuffle(products);
          } else if (ext.format === 'single_product_carousel' && products[0]?.images) {
            products = [{ ...products[0], images: shuffle(products[0].images) }, ...products.slice(1)];
          }
        }
        // ext is raw wire data, so sponsoredBy isn't guaranteed to be a string; guard
        // before calling .trim() to avoid crashing the render on a malformed payload.
        const sponsoredBy = typeof ext.sponsoredBy === 'string' ? ext.sponsoredBy.trim() || undefined : undefined;
        this._shoppable = { ...ext, products, ctaStyle: normalizeCtaStyle(ext.ctaStyle), sponsoredBy };
      }
    }
    return this._shoppable ?? undefined;
  }
}
