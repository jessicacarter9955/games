import type { Behaviors, ButlerResponse, Enhancement, RawResponse } from '@web-rendering/groundcontrol-shared-types';
import { CreativeType } from '@web-rendering/groundcontrol-shared-types';
import type { Creative, Payload } from '@web-rendering/groundcontrol-core';

const hasForceEnhancedBehavior = (behaviors: Behaviors | string[]): boolean => {
  if (Array.isArray(behaviors)) {
    return behaviors.includes('shouldForceEnhanced');
  }

  return behaviors.shouldForceEnhanced;
};

const hasForceUnenhancedBehavior = (behaviors: Behaviors | string[]): boolean => {
  if (Array.isArray(behaviors)) {
    return behaviors.includes('shouldForceUnenhanced');
  }

  return behaviors.shouldForceUnenhanced;
};

/**
 * Determines if a creative or payload can be enhanced based on its behaviors and deco decision
 * @param creative - The creative to check; only its type and behaviors are read, so a raw payload's creative fits too
 * @returns boolean indicating if the item can be enhanced
 */
export function isEnhanceable(
  creative: Pick<Creative, 'type' | 'behaviors'>,
  enhancement: Enhancement | undefined
): boolean {
  if (!creative || !enhancement) return false;

  const creativeType = creative.type;
  if (creativeType !== CreativeType.Banner && creativeType !== CreativeType.Outstream) return false;

  if (creative.behaviors) {
    if (hasForceEnhancedBehavior(creative.behaviors)) return true;
    if (hasForceUnenhancedBehavior(creative.behaviors)) return false;
  }

  return enhancement.type !== 'disabled';
}

export const isButlerResponse = (response: RawResponse | ButlerResponse | Payload): response is RawResponse => {
  return response && 'adserverRequestId' in response;
};
