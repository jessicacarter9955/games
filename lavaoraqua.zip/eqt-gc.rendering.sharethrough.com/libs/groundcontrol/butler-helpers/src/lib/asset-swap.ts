import type {
  BehaviorMap,
  Behaviors,
  ButlerCreative,
  ButlerResponse,
  SupportedLanguage
} from '@web-rendering/groundcontrol-shared-types';
import { getParameterByName } from '@web-rendering/groundcontrol-utils/groundcontrol-utils';
import { enableBehaviors } from './behaviors';
import { ASSETS_BY_LANGUAGE, COUNTRY_LANGUAGE_MAPPING, FRENCH_BUNDLES, FRENCH_DOMAINS } from './language';

export const OUT_OF_VIEW_PAUSE_THRESHOLD = 0.5;
const URL_BEHAVIOR_MAP: BehaviorMap = {
  shouldHideDescription: { shouldHideDescription: true },
  shouldHidePromotedByText: { shouldHidePromotedByText: true },
  p: { shouldPauseAtFiftyPercentOutOfView: true },
  dnp: { shouldNotPauseOutOfView: true },
  dv: { shouldEnableDoubleVerify: true }
};

export const getLanguage = ({ creative, placement, country }: ButlerResponse): SupportedLanguage => {
  // Check domain first
  if (placement.domain) {
    const isFrenchDomain = FRENCH_DOMAINS.some((dom) => placement.domain.includes(dom));
    if (isFrenchDomain) {
      return 'fr';
    }
  }

  // Check bundle identifier
  if (placement.bundleIdentifier && FRENCH_BUNDLES.some((bundle) => placement.bundleIdentifier?.includes(bundle))) {
    return 'fr';
  }

  // Check creative language
  if (creative.language && ASSETS_BY_LANGUAGE[creative.language as SupportedLanguage]) {
    return creative.language as SupportedLanguage;
  }

  // Check country mapping
  if (country && COUNTRY_LANGUAGE_MAPPING[country]) {
    return COUNTRY_LANGUAGE_MAPPING[country];
  }

  // Check browser language
  if (typeof navigator !== 'undefined' && navigator.language) {
    const code = navigator.language.substring(0, 2) as SupportedLanguage;
    if (ASSETS_BY_LANGUAGE[code]) {
      return code;
    }
  }

  return 'en';
};

const getAssetsByLanguage = (butlerResponse: ButlerResponse) => {
  const { creative } = butlerResponse;
  const language = getLanguage(butlerResponse);
  const assets = ASSETS_BY_LANGUAGE[language];
  if (!!creative.title && creative.title !== ASSETS_BY_LANGUAGE['en']['title']) {
    assets.title = creative.title;
  }

  if (!!creative.description && creative.description !== ASSETS_BY_LANGUAGE['en']['description']) {
    assets.description = creative.description;
  }

  if (!!creative.advertiser && creative.advertiser !== ASSETS_BY_LANGUAGE['en']['advertiser']) {
    assets.advertiser = creative.advertiser;
  }

  if (!!creative.promotedByText && language === 'en') {
    assets.promotedByText = creative.promotedByText;
  }

  if (creative.ctaText) {
    assets.ctaText = creative.ctaText;
  }

  return assets;
};

const getDealId = () => {
  const strModify: boolean = getParameterByName('str_modify') === 'true';
  const dealId = getParameterByName('dealId');

  if (strModify && !!dealId) {
    return { dealId };
  }

  return {};
};

const strModifyBehaviors = (): Partial<Behaviors> => {
  const behaviors: Partial<Behaviors> = {};

  const strModify: string | null = getParameterByName('str_modify');
  if (strModify !== 'true') {
    return behaviors;
  }

  const behaviorParam: string | null = getParameterByName('behaviors');
  if (!behaviorParam) {
    return behaviors;
  }

  const urlBehaviors: string[] = behaviorParam.split(',');

  return enableBehaviors(behaviors, urlBehaviors, URL_BEHAVIOR_MAP);
};

const behaviorsForCreative = (butlerResponse: ButlerResponse): Behaviors => {
  return {
    ...butlerResponse.creative.behaviors,
    ...strModifyBehaviors()
  };
};

export const swapCreativeAssets = (butlerResponse: ButlerResponse): ButlerCreative => {
  let partiallySwappedCreative = {
    ...butlerResponse.creative,
    ...getDealId(),
    ...getAssetsByLanguage(butlerResponse)
  };

  const behaviors = behaviorsForCreative({
    ...butlerResponse,
    creative: partiallySwappedCreative
  });

  if (behaviors.shouldHideDescription) {
    partiallySwappedCreative = {
      ...partiallySwappedCreative,
      description: ''
    };
  }

  // we do a two-step transformation here because we want the following
  // swaps/behaviors to use the (potentially-) overridden deal ID when
  // applicable
  return {
    ...partiallySwappedCreative,
    behaviors,
    beacons: partiallySwappedCreative.beacons
  };
};
