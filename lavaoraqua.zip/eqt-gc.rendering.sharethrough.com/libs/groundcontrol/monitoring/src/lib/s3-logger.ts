import { LAMBDA_URL } from './constants';

export const logContent = async (path: string, content: unknown, contentType: 'json' | 'html') => {
  try {
    if (navigator.sendBeacon) {
      navigator.sendBeacon(
        LAMBDA_URL,
        JSON.stringify({
          path,
          content,
          contentType
        })
      );
    } else {
      await fetch(LAMBDA_URL, {
        method: 'POST',
        body: JSON.stringify({
          path,
          content,
          contentType
        }),
        keepalive: true
      });
    }

    return true;
  } catch (error) {
    console.error('Failed to log content:', error);
    return false;
  }
};
