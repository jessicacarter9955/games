import type { SamplingOptions, SamplingRule } from './types';

const BAD_CALLERS_SAMPLING_RATE = 0.01;

/**
 * Sampling rules to override the default sampling rate based on
 * callerId / partnerId / networkId / domain.
 */
export const SAMPLING_RULES: SamplingRule[] = [
  // Thunder 143
  { callerId: '143', partnerId: '43', networkId: '5026', samplingRate: BAD_CALLERS_SAMPLING_RATE },
  { callerId: '143', partnerId: '76', networkId: '4762', samplingRate: BAD_CALLERS_SAMPLING_RATE },
  { callerId: '143', partnerId: '76', networkId: '5026', samplingRate: BAD_CALLERS_SAMPLING_RATE },
  { callerId: '143', samplingRate: BAD_CALLERS_SAMPLING_RATE },

  // PrebidServer 5
  { callerId: '5', partnerId: '22', networkId: '4111', samplingRate: BAD_CALLERS_SAMPLING_RATE },
  { callerId: '5', partnerId: '28', networkId: '4111', samplingRate: BAD_CALLERS_SAMPLING_RATE },
  { callerId: '5', partnerId: '67', networkId: '4111', samplingRate: BAD_CALLERS_SAMPLING_RATE },
  { callerId: '5', partnerId: '76', networkId: '4111', samplingRate: BAD_CALLERS_SAMPLING_RATE },
  { callerId: '5', partnerId: '420', networkId: '4111', samplingRate: BAD_CALLERS_SAMPLING_RATE },
  { callerId: '5', samplingRate: BAD_CALLERS_SAMPLING_RATE },

  // Adagio 43
  { callerId: '43', partnerId: '419', networkId: '3554', samplingRate: BAD_CALLERS_SAMPLING_RATE },
  { callerId: '43', partnerId: '76', networkId: '3554', samplingRate: BAD_CALLERS_SAMPLING_RATE },
  { callerId: '43', samplingRate: BAD_CALLERS_SAMPLING_RATE },

  // Gadsme 60
  { callerId: '60', partnerId: '100', networkId: '3837', samplingRate: BAD_CALLERS_SAMPLING_RATE },
  { callerId: '60', samplingRate: BAD_CALLERS_SAMPLING_RATE },

  // Gitberry 127
  { callerId: '127', partnerId: '419', networkId: '4039', samplingRate: BAD_CALLERS_SAMPLING_RATE },
  { callerId: '127', partnerId: '404', networkId: '4039', samplingRate: BAD_CALLERS_SAMPLING_RATE },
  { callerId: '127', partnerId: '342', networkId: '4039', samplingRate: BAD_CALLERS_SAMPLING_RATE },
  { callerId: '127', partnerId: '415', networkId: '4039', samplingRate: BAD_CALLERS_SAMPLING_RATE },
  { callerId: '127', samplingRate: BAD_CALLERS_SAMPLING_RATE },

  // BidMachine 63
  { callerId: '63', partnerId: '67', samplingRate: BAD_CALLERS_SAMPLING_RATE },
  { callerId: '63', partnerId: '43', samplingRate: BAD_CALLERS_SAMPLING_RATE },
  { callerId: '63', samplingRate: BAD_CALLERS_SAMPLING_RATE },

  // Rakuten 11
  { callerId: '11', partnerId: '76', networkId: '2491', samplingRate: BAD_CALLERS_SAMPLING_RATE },
  { callerId: '11', partnerId: '80', networkId: '2491', samplingRate: BAD_CALLERS_SAMPLING_RATE },
  { callerId: '11', partnerId: '26', networkId: '2491', samplingRate: BAD_CALLERS_SAMPLING_RATE },
  { callerId: '11', partnerId: '410', networkId: '2491', samplingRate: BAD_CALLERS_SAMPLING_RATE },
  { callerId: '11', samplingRate: BAD_CALLERS_SAMPLING_RATE },

  // Equativ Prebid Adapter 169
  { callerId: '169', networkId: '4932', samplingRate: BAD_CALLERS_SAMPLING_RATE },
  { callerId: '169', samplingRate: BAD_CALLERS_SAMPLING_RATE },

  // Adverty 121
  { callerId: '121', partnerId: '59', samplingRate: BAD_CALLERS_SAMPLING_RATE },
  { callerId: '121', partnerId: '326', samplingRate: BAD_CALLERS_SAMPLING_RATE },
  { callerId: '121', partnerId: '40', samplingRate: BAD_CALLERS_SAMPLING_RATE },
  { callerId: '121', partnerId: '68', samplingRate: BAD_CALLERS_SAMPLING_RATE },
  { callerId: '121', partnerId: '76', samplingRate: BAD_CALLERS_SAMPLING_RATE },
  { callerId: '121', partnerId: '419', samplingRate: BAD_CALLERS_SAMPLING_RATE },
  { callerId: '121', partnerId: '100', samplingRate: BAD_CALLERS_SAMPLING_RATE },
  { callerId: '121', samplingRate: BAD_CALLERS_SAMPLING_RATE },

  // Smilewanted 32
  { callerId: '32', samplingRate: BAD_CALLERS_SAMPLING_RATE },

  // Sharethrough Direct Publishers 176
  { callerId: '176', samplingRate: BAD_CALLERS_SAMPLING_RATE },

  // Seedtag 7
  { callerId: '7', samplingRate: BAD_CALLERS_SAMPLING_RATE }
];

export function matchSamplingRate(rules: SamplingRule[], options: SamplingOptions): number | undefined {
  const rule = rules.find(
    (r) =>
      (r.partnerId === undefined || r.partnerId === options.partnerId) &&
      (r.callerId === undefined || r.callerId === options.callerId) &&
      (r.networkId === undefined || r.networkId === options.networkId) &&
      (r.domain === undefined || r.domain === options.domain)
  );
  return rule ? rule.samplingRate : undefined;
}

// ------------------------------------------------------------------
// Cached production helper
// ------------------------------------------------------------------

const samplingRateCache = new Map<string, number | undefined>();

const buildKeyFromOptions = (options: SamplingOptions): string => {
  const { callerId, partnerId, networkId, domain } = options;

  return [callerId ?? '', partnerId ?? '', networkId ?? '', domain ? String(domain).toLowerCase() : ''].join('|');
};

export const getSamplingRateForOptions = (options: SamplingOptions): number | undefined => {
  const key = buildKeyFromOptions(options);

  if (samplingRateCache.has(key)) {
    return samplingRateCache.get(key);
  }

  const rate = matchSamplingRate(SAMPLING_RULES, options);
  samplingRateCache.set(key, rate);

  return rate;
};
