import type { Notifier } from '@airbrake/browser';
import type { INotice } from '@airbrake/browser/dist/notice';
import { AIRBRAKE_PROJECT_ID, AIRBRAKE_PROJECT_KEY } from './constants';

declare global {
  interface Window {
    __gcAirbrake?: { Notifier: typeof Notifier };
  }
}

const SCRIPT_LOAD_TIMEOUT_MS = 15_000;
const SCRIPT_MARKER_ATTR = 'data-gc-airbrake';

// Filter will add reference to sourcemap
const addSourceMaps = (notice: INotice): INotice | null => {
  const sourceMaps = notice.context.sourceMaps ?? {};

  // TODO: Pass this from app env or config service
  const eqtSource = 'https://eqt-gc.rendering.sharethrough.com/gc.js';

  notice.context.sourceMaps = {
    ...sourceMaps,
    [eqtSource]: `${eqtSource}.map`,
    [AIRBRAKE_PATH]: `${AIRBRAKE_PATH}.map`
  };

  return notice;
};

// Filter errors when in the dev environment
const filterDev = (notice: INotice): INotice | null => {
  return ENV === 'dev' ? null : notice;
};

// window.onerror/unhandledrejection notices are raised by the Notifier's own instrumentation
// and call notify() directly with `context: { windowError: true }` or
// `context: { unhandledRejection: true }`, bypassing buildErrorContext
// entirely. Without this filter they'd carry neither canarySlot nor our version string, making
// canary window errors indistinguishable from stable ones in Airbrake.
const tagCanarySlot = (notice: INotice): INotice | null => {
  if (CANARY_SLOT) {
    notice.context.canarySlot = CANARY_SLOT;
  }

  return notice;
};

// The same uncaught-error notices skip buildErrorContext, so they also miss the build every other
// report carries. They get no stage: an uncaught error belongs to no ad, and the Notifier's own
// windowError / unhandledRejection tags already tell them apart from Error Reports.
const tagUncaughtError = (notice: INotice): INotice | null => {
  if (notice.context.windowError || notice.context.unhandledRejection) {
    notice.context.build = GC_BUILD;
  }

  return notice;
};

const loadAirbrakeScript = (): Promise<typeof Notifier> => {
  if (window.__gcAirbrake?.Notifier) {
    return Promise.resolve(window.__gcAirbrake.Notifier);
  }

  return new Promise<typeof Notifier>((resolve, reject) => {
    const script = document.createElement('script');
    script.src = AIRBRAKE_PATH;
    script.async = true;
    script.setAttribute(SCRIPT_MARKER_ATTR, '');

    const timeoutId = window.setTimeout(() => {
      cleanup();
      reject(new Error('Airbrake script load timed out'));
    }, SCRIPT_LOAD_TIMEOUT_MS);

    const cleanup = () => {
      window.clearTimeout(timeoutId);
      script.removeEventListener('load', onLoad);
      script.removeEventListener('error', onError);
    };

    const onLoad = () => {
      cleanup();
      const Notifier = window.__gcAirbrake?.Notifier;
      if (Notifier) {
        resolve(Notifier);
      } else {
        reject(new Error('Airbrake script loaded but window.__gcAirbrake.Notifier is missing'));
      }
    };

    const onError = () => {
      cleanup();
      reject(new Error('Airbrake script failed to load'));
    };

    script.addEventListener('load', onLoad);
    script.addEventListener('error', onError);

    try {
      document.head.appendChild(script);
    } catch (appendErr) {
      // A restrictive publisher CSP can throw synchronously here. Translate to a
      // promise rejection so the provider drops the notice gracefully instead of
      // letting the throw escape into the caller of reportError().
      cleanup();
      reject(new Error(`Airbrake script append failed: ${String(appendErr)}`));
    }
  });
};

export const getAirbrakeClient = async (): Promise<Notifier> => {
  const Notifier = await loadAirbrakeScript();

  const client = new Notifier({
    projectId: AIRBRAKE_PROJECT_ID,
    projectKey: AIRBRAKE_PROJECT_KEY,
    environment: ENV
  });

  client.addFilter(addSourceMaps);
  client.addFilter(filterDev);
  client.addFilter(tagCanarySlot);
  client.addFilter(tagUncaughtError);

  return client;
};
