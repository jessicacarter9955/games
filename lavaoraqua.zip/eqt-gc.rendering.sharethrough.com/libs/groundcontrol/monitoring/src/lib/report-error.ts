import { createAirbrakeProvider } from './providers/airbrake-provider';
import { createDatadogProvider } from './providers/datadog-provider';
import { AIRBRAKE_REPORTING_RATE, MAX_ERROR_REPORTING_RATE, LOG_BASE_URL } from './constants';
import { tryConsumeDatadogLogBudget } from './datadog-log-budget';
import { getErrorSamplingFactor } from './error-sampling-factor';
import { getSamplingRateForOptions } from './sampling-rules';
import { loggingConfig } from './logging-config';
import { logContent } from './s3-logger';
import type { LifecycleScope } from '@web-rendering/groundcontrol-shared-types/lifecycle/lifecycle';
import type { MonitoringOptions, ReportOptions } from './types';
import { Scenario } from '@web-rendering/groundcontrol-shared-types';

import type { ErrorContext, MonitoringProvider } from './monitoring-provider';

const airbrakeProvider = createAirbrakeProvider();
const datadogProvider = createDatadogProvider();

const isRecord = (value: unknown): value is Record<string, unknown> => typeof value === 'object' && value !== null;

// WR-2053 Decision 10: Datadog Error Reporting runs behind payload.scenario until the Parity
// Check passes (WR-2205) - every other scenario value, including none, stays on Airbrake unchanged.
const hasDatadogErrorReporting = (payload: unknown): boolean => {
  const scenario = isRecord(payload) && 'scenario' in payload ? payload['scenario'] : undefined;

  return scenario === Scenario.DatadogErrorReporting;
};

// Not a UUID: GC targets es2015 and crypto.randomUUID isn't universally available across the
// older browsers/webviews GC runs in. Only needs to be unique enough to match the copies of one
// Error Report across Error Sinks (and to backend logs), not globally unique forever.
const generateErrorReportId = (): string => `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;

const logRawData = async (id: string): Promise<string | undefined> => {
  const rawData = loggingConfig.getData(id);

  if (rawData) {
    await logContent(`${loggingConfig.type}/${id}`, rawData, 'json');
    return `${LOG_BASE_URL}/${loggingConfig.type}/${id}`;
  }

  return undefined;
};

const buildErrorContext = (options: ReportOptions, scope: LifecycleScope): ErrorContext => {
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { payload: _payload, ...rest } = options;

  return {
    // Identifiers a call passes explicitly win over the lifecycle's.
    ...scope.identifiers,
    ...rest,
    ...(scope.stage ? { stage: scope.stage } : {}),
    version: VERSION,
    build: GC_BUILD,
    environment: ENV,
    // Spread conditionally so stable notices keep exactly today's context shape.
    ...(CANARY_SLOT ? { canarySlot: CANARY_SLOT } : {})
  };
};

const getReportId = (options: ReportOptions): string | undefined => {
  const payloadId = isRecord(options.payload) && 'id' in options.payload ? options.payload['id'] : undefined;

  return options.id || (typeof payloadId === 'string' ? payloadId : undefined);
};

const sendToProvider = async (
  error: Error,
  options: ReportOptions,
  scope: LifecycleScope,
  effectiveSamplingRate = 1
) => {
  const id = getReportId(options);

  let payloadLink: string | undefined;
  if (id && typeof id === 'string') {
    try {
      payloadLink = await logRawData(id);
    } catch (logErr) {
      console.error('[Monitoring] Failed to log raw data:', logErr);
    }
  }

  const context = buildErrorContext(payloadLink ? { ...options, payloadLink } : options, scope);

  console.error({ error, context });

  // MonitoringProvider is a public seam, and this path must never throw into the host page
  // (WR-2205 AC3). The try covers a notify() that throws synchronously; the await covers one
  // that rejects, and also accepts a plain non-promise return.
  const notifySafely = async (provider: MonitoringProvider, providerContext: ErrorContext): Promise<void> => {
    try {
      await provider.notify(error, providerContext);
    } catch (err) {
      console.error('[Monitoring] Failed to send error to provider:', err);
    }
  };

  if (!hasDatadogErrorReporting(options.payload)) {
    // Outside the Datadog Error Reporting population, Airbrake gets today's context shape exactly (AC2).
    await notifySafely(airbrakeProvider, context);
    return;
  }

  // One sampling decision (already made by the caller) covers both Error Sinks; every copy of this
  // Error Report shares its errorReportId, so the Parity Check matches copies instead of counts.
  const errorReportId = generateErrorReportId();
  // Checked only for reports that would really reach Datadog, so they alone spend the Boot's budget.
  const datadogSkipped = tryConsumeDatadogLogBudget() ? undefined : 'bootCap';

  if (datadogSkipped) {
    await notifySafely(airbrakeProvider, { ...context, errorReportId, datadogSkipped });
    return;
  }

  // Only the Datadog copy carries a weight to recompute true volume (WR-2053 Decision 6/9). It is
  // nested as Properties.DatadogIngestWeight, the backend/legacy convention the Datadog pipeline
  // reads to compute datadog.total.weight. Merged so a caller-supplied Properties survives.
  // Rounded to the integer "1 in N" the backend and legacy loggers send; MAX_ERROR_REPORTING_RATE keeps N at
  // 10000 or more, so rounding moves the weight by under 0.005%.
  const datadogProperties = {
    ...(isRecord(context['Properties']) ? context['Properties'] : {}),
    DatadogIngestWeight: Math.round(1 / effectiveSamplingRate)
  };

  await Promise.all([
    notifySafely(airbrakeProvider, { ...context, errorReportId }),
    notifySafely(datadogProvider, { ...context, errorReportId, Properties: datadogProperties })
  ]);
};

/**
 * Report an error to the configured monitoring provider with optional sampling and context
 *
 * @param error - The error to report. An Error is passed through unchanged (preserving its stack
 *   trace and constructor type); a string becomes a new Error; anything else (e.g. an unknown
 *   value from a catch block) is normalized into a new Error via String(error).
 * @param options - Additional context and configuration
 * @param options.scope - The lifecycle the error happened in: the report takes its stage and ad identifiers from it
 * @param options.id - Primary identifier for tracking (ARID/adserver request ID or payload ID)
 * @param options.context - Contextual information about where/why the error occurred (e.g., "butler/api", "dco/handler", "banner/render")
 * @param options.partnerId - Partner identifier (previously called sourceId)
 * @param options.callerId - Caller identifier (previously called supplyId)
 * @param options.networkId - Network identifier
 * @param options.creativeType - Creative type (banner, native, outstream, etc.)
 * @param options.payload - Large payload data to log to S3 (too big for Airbrake but critical for debugging).
 *   Also read for `payload.scenario`: under WR-2205's Datadog Error Reporting
 *   (`Scenario.DatadogErrorReporting`) the Error Report also goes to Datadog, at the same
 *   rate as Airbrake, within DATADOG_MAX_LOGS_PER_BOOT; Airbrake still receives every
 *   one, and both copies share an `errorReportId` for the Parity Check.
 * @param options.sampling - Sampling configuration:
 *   - undefined (default): Use default sampling rate (0.001%)
 *   - number (0-1): Custom sampling rate (e.g., 0.1 = 10%)
 *   - { alreadySampledAt }: the caller already made the sampling draw at this rate (e.g. to
 *     share it with a body dump); always report, weighted as sampled at that rate
 *   On every build, canary included, the rate is then scaled by the payload's Error Sampling Factor
 *   (WR-2247) and capped at MAX_ERROR_REPORTING_RATE, whichever mode picked it. The mode that
 *   have already drawn ({ alreadySampledAt }) are thinned by the factor and the cap, never boosted.
 * @param options.[key] - Any additional custom context fields
 *
 * @returns Promise that resolves when error is reported (or null if not sampled)
 *
 * @example
 * // Default sampling with context
 * reportError(error, { scope: lifecycle, context: 'butler/api', id: 'abc123' })
 *
 * // Custom 10% sampling with large payload
 * reportError(error, { scope: lifecycle, context: 'dco/handler', payload: largeData, sampling: 0.1 })
 *
 * // Example of traffic boosted by a sampling rule:
 *  If SAMPLING_RULES contains { callerId: 'debug-caller', samplingRate: 0.5 }
 *  this call will be reported at 50% sampling rate when options.sampling is undefined::
 *  reportError(error, { scope: lifecycle, callerId: 'debug-caller' })
 *
 * // Full impression context
 * reportError(error, {
 *   scope: lifecycle,
 *   id: payload.id,
 *   context: 'banner/render',
 *   partnerId: payload.creative.partnerId,
 *   callerId: butlerResponse.callerId,
 *   networkId: payload.network.id,
 *   creativeType: payload.creative.type,
 *   payload: payload,
 *   sampling: 0.05 // 5% sampling
 * })
 */
export const reportError = (error: unknown, options: MonitoringOptions): Promise<unknown> => {
  const errorObject = error instanceof Error ? error : new Error(typeof error === 'string' ? error : String(error));

  if (ENV === 'dev') {
    return Promise.resolve(console.error(errorObject));
  }

  const { sampling, scope, ...restOptions } = options;
  const errorSamplingFactor = getErrorSamplingFactor(getReportId(options));

  if (errorSamplingFactor === 0) {
    return Promise.resolve(null);
  }

  // The caller already made its draw, so only the factor and the cap can drop it, and neither can
  // reopen a draw the caller lost.
  const alreadySampledAt = typeof sampling === 'object' ? sampling.alreadySampledAt : undefined;

  if (alreadySampledAt !== undefined) {
    const keepProbability = Math.min(errorSamplingFactor, 1, MAX_ERROR_REPORTING_RATE / alreadySampledAt);

    return Math.random() < keepProbability
      ? sendToProvider(errorObject, restOptions, scope, alreadySampledAt * keepProbability)
      : Promise.resolve(null);
  }

  const explicitSamplingRate = typeof sampling === 'number' ? sampling : undefined;

  const ruleSamplingRate = getSamplingRateForOptions({ ...scope.identifiers, ...restOptions });

  const baseSamplingRate = explicitSamplingRate ?? ruleSamplingRate ?? AIRBRAKE_REPORTING_RATE;
  const samplingRate = Math.min(baseSamplingRate * errorSamplingFactor, MAX_ERROR_REPORTING_RATE);

  if (Math.random() < samplingRate) {
    return sendToProvider(errorObject, restOptions, scope, samplingRate);
  }

  return Promise.resolve(null);
};
