import { getLatestRawPayload, getRawPayload } from '@web-rendering/groundcontrol-store';

export const getErrorSamplingFactor = (id?: string): number => {
  const rawPayload = (id ? getRawPayload(id) : undefined) ?? getLatestRawPayload();
  const errorSamplingFactor = rawPayload?.reporting?.errorSamplingFactor;

  return typeof errorSamplingFactor === 'number' && Number.isFinite(errorSamplingFactor) && errorSamplingFactor >= 0
    ? errorSamplingFactor
    : 1;
};
