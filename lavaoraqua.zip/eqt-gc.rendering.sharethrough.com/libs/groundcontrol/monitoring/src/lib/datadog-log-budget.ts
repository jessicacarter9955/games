import { DATADOG_MAX_LOGS_PER_BOOT } from './constants';

// Module state: each gc.js execution (Boot) loads its own copy, so each gets its own budget.
let remainingLogs = DATADOG_MAX_LOGS_PER_BOOT;

/**
 * Claims one Datadog log from this Boot's budget (DATADOG_MAX_LOGS_PER_BOOT).
 *
 * @returns true if the log may be sent, false once the Boot has spent its budget
 */
export const tryConsumeDatadogLogBudget = (): boolean => {
  if (remainingLogs <= 0) {
    return false;
  }

  remainingLogs -= 1;
  return true;
};
