export const AIRBRAKE_PROJECT_ID = 217882;
export const AIRBRAKE_PROJECT_KEY = '6d7b08a83db80dc921bcdc71b3efa9e6';

/**
 * Default sampling rate for error reporting to Airbrake
 * 0.00001 = 0.001% of errors (1 in 100,000)
 */
export const AIRBRAKE_REPORTING_RATE = 0.00001;

/**
 * Highest rate any error report is sent at (0.01%, 10x the default), whatever sampling mode or
 * Error Sampling Factor produced it.
 */
export const MAX_ERROR_REPORTING_RATE = 0.0001;

/**
 * Equativ's Datadog org is on the EU site (equativ.datadoghq.eu), not the .com default.
 */
export const DATADOG_SITE = 'datadoghq.eu';

/**
 * Datadog's browser log intake endpoint, per https://docs.datadoghq.com/logs/log_collection/javascript/.
 */
export const DATADOG_INTAKE_URL = `https://browser-intake-${DATADOG_SITE}/api/v2/logs`;

export const DATADOG_SERVICE = 'groundcontrol';

/**
 * Most Datadog logs one Boot (one gc.js execution) sends. Sampling bounds volume across
 * pages; this bounds a single execution stuck in an error loop, the browser analogue of the
 * org's MaxLogsPerMinute burst guard (Confluence RND "Datadog Sampling Guidelines").
 * Logs dropped past it carry no weight, so a looping Boot is undercounted - acceptable,
 * since it is an anomaly rather than volume to reconstruct.
 */
export const DATADOG_MAX_LOGS_PER_BOOT = 5;

/**
 * AWS Lambda URL for S3 logging
 */
export const LAMBDA_URL = 'https://ljv37e7t7uuolmfy4tnog4w7za0auwrm.lambda-url.us-east-1.on.aws';

/**
 * S3 bucket base URL for accessing logged data
 */
export const LOG_BASE_URL = 'https://sfar-data-production.s3.amazonaws.com/logging';
