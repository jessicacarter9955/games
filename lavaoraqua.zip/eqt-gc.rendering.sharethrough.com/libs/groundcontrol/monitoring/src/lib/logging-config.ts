import { getRawPayload } from '@web-rendering/groundcontrol-store';
import type { LoggingConfig } from './types';

export const loggingConfig: LoggingConfig = {
  type: 'payload',
  getData: getRawPayload
};
