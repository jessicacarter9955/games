import { DATADOG_INTAKE_URL, DATADOG_SERVICE } from './constants';

export interface DatadogLogEvent {
  message: string;
  status: 'error' | 'info';
  [key: string]: unknown;
}

// dd-api-key as a query param (not a header) is what Datadog's browser log intake documents for
// posting without the SDK - see https://docs.datadoghq.com/logs/log_collection/javascript/.
const buildIntakeUrl = (): string => `${DATADOG_INTAKE_URL}?dd-api-key=${DATADOG_CLIENT_TOKEN}`;

export const sendDatadogLog = async (event: DatadogLogEvent): Promise<boolean> => {
  // No client token yet (WR-2205 T022 self-serve, still pending) - drop quietly rather than
  // POST to Datadog with an empty credential.
  if (!DATADOG_CLIENT_TOKEN) {
    return false;
  }

  const body = JSON.stringify({ service: DATADOG_SERVICE, ddsource: 'browser', ...event });

  try {
    if (navigator.sendBeacon) {
      return navigator.sendBeacon(buildIntakeUrl(), body);
    }

    await fetch(buildIntakeUrl(), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body,
      keepalive: true
    });

    return true;
  } catch (error) {
    console.error('[Datadog] Failed to send log:', error);
    return false;
  }
};
