import type { Notifier } from '@airbrake/browser';
import { getAirbrakeClient } from '../airbrake-client';
import type { MonitoringProvider, ErrorContext } from '../monitoring-provider';

const MAX_PENDING_NOTICES = 50;

interface PendingNotice {
  error: Error;
  context: ErrorContext;
  done: () => void;
}

export const createAirbrakeProvider = (): MonitoringProvider => {
  let clientPromise: Promise<Notifier> | undefined;
  let client: Notifier | undefined;
  const pending: PendingNotice[] = [];
  let droppedWhilePending = 0;

  const sendNow = async (error: Error, context: ErrorContext): Promise<void> => {
    if (!client) return;

    const enriched: ErrorContext =
      droppedWhilePending > 0 ? { ...context, droppedNotices: droppedWhilePending } : context;
    if (droppedWhilePending > 0) droppedWhilePending = 0;

    try {
      await client.notify({ error, context: enriched });
    } catch (notifyErr) {
      console.error('[Airbrake] Failed to send notification:', notifyErr);
    }
  };

  const initAndDrain = async (init: Promise<Notifier>): Promise<void> => {
    try {
      client = await init;
    } catch (initErr) {
      console.error('[Airbrake] Failed to initialize client:', initErr);
      clientPromise = undefined;
      const drained = pending.splice(0, pending.length);
      droppedWhilePending = 0;
      drained.forEach((item) => item.done());
      return;
    }

    const drained = pending.splice(0, pending.length);
    for (const item of drained) {
      await sendNow(item.error, item.context);
      item.done();
    }
  };

  return {
    name: 'airbrake',
    notify(error: Error, context: ErrorContext): Promise<void> {
      if (client) {
        return sendNow(error, context);
      }

      return new Promise<void>((resolve) => {
        if (pending.length >= MAX_PENDING_NOTICES) {
          const evicted = pending.shift();
          droppedWhilePending++;
          evicted?.done();
        }
        pending.push({ error, context, done: resolve });

        if (!clientPromise) {
          clientPromise = getAirbrakeClient();
          void initAndDrain(clientPromise);
        }
      });
    }
  };
};
