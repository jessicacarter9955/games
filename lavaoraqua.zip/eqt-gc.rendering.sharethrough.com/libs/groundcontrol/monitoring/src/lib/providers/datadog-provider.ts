import { sendDatadogLog } from '../datadog-client';
import type { MonitoringProvider, ErrorContext } from '../monitoring-provider';

export const createDatadogProvider = (): MonitoringProvider => ({
  name: 'datadog',
  // sendDatadogLog already swallows every failure (missing token, CSP-blocked intake, network
  // error) and resolves rather than rejects, so notify never throws into reportError's caller.
  async notify(error: Error, context: ErrorContext): Promise<void> {
    // error.kind / error.message / error.stack are Datadog's standard error attributes, the shape
    // Equativ's other Datadog log formatters use. Spread after the context so a caller field
    // can never replace the reported Error.
    await sendDatadogLog({
      message: error.message,
      status: 'error',
      ...context,
      error: { kind: error.name, message: error.message, stack: error.stack }
    });
  }
});
