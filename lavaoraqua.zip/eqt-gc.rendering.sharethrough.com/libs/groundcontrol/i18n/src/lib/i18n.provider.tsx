import type { FunctionComponent } from 'preact/compat';
import { createContext, useMemo } from 'preact/compat';
import type { I18N } from './translations/type';
import { SupportedLanguage } from './translations/type';
import {
  ar,
  bg,
  bn,
  cs,
  de,
  en,
  es,
  esMx,
  fr,
  hi,
  hr,
  hu,
  id,
  it,
  ja,
  ko,
  pl,
  ptBr,
  ro,
  sk,
  sr,
  ta,
  th,
  tl,
  tlEn,
  vi,
  zhCn,
  zhHk
} from './translations';

export interface I18NProviderProps {
  language?: SupportedLanguage;
}

const translationsMap = {
  en,
  es,
  ar,
  bg,
  bn,
  cs,
  de,
  'es-mx': esMx,
  fr,
  hi,
  hr,
  hu,
  id,
  it,
  ja,
  ko,
  pl,
  'pt-br': ptBr,
  ro,
  sk,
  sr,
  ta,
  th,
  tl,
  'tl-en': tlEn,
  vi,
  'zh-cn': zhCn,
  'zh-hk': zhHk
};

export const I18nContext = createContext<{ t: (key: I18N) => string }>({ t: (k) => k });

export const I18NProvider: FunctionComponent<I18NProviderProps> = ({
  language = SupportedLanguage.ENGLISH,
  children
}) => {
  const t = useMemo(() => {
    const dict = translationsMap[language] ?? {};
    return (key: I18N) => dict[key] ?? key;
  }, [language]);

  return <I18nContext.Provider value={{ t }}>{children}</I18nContext.Provider>;
};
