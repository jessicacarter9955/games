import { useContext } from 'preact/hooks';
import { I18nContext } from './i18n.provider';

export const useTranslation = () => useContext(I18nContext);
