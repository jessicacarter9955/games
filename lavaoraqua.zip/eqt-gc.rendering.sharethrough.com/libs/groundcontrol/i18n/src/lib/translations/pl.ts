import { I18N } from './type';

export const pl: { [key in I18N]: string } = {
  // AI generated
  [I18N.ADVERTISER]: 'Sponsor',
  [I18N.AIR_QUALITY]: 'Jakość powietrza',
  [I18N.CTA_TEXT]: 'Zobacz więcej',
  [I18N.DAYS]: 'Dni',
  [I18N.DESCRIPTION]: 'Nie przegap tej treści od naszego sponsora',
  [I18N.FAIR]: 'Zadowalająca',
  [I18N.GOOD]: 'Dobra',
  [I18N.HOURS]: 'Godziny',
  [I18N.HUMIDITY]: 'Wilgotność',
  [I18N.ISI]: 'Ważne informacje dotyczące bezpieczeństwa',
  [I18N.MINUTES_ABBREVIATION]: 'Min',
  [I18N.MODERATE]: 'Umiarkowana',
  [I18N.POOR]: 'Zła',
  [I18N.PROMOTED_BY_TEXT]: 'Reklama od',
  [I18N.SECONDS_ABBREVIATION]: 'Sek',
  [I18N.TITLE]: 'Kliknij tutaj, aby uzyskać więcej informacji',
  [I18N.UNKNOWN]: 'Nieznany',
  [I18N.UV_INDEX]: 'Indeks UV',
  [I18N.VERY_POOR]: 'Bardzo zła',
  [I18N.WIND]: 'Wiatr'
};
