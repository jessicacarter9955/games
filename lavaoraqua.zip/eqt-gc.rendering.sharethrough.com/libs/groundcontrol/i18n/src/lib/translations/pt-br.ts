import { I18N } from './type';

export const ptBr: { [key in I18N]: string } = {
  // AI generated
  [I18N.ADVERTISER]: 'Patrocinador',
  [I18N.AIR_QUALITY]: 'Qualidade do ar',
  [I18N.CTA_TEXT]: 'Ver mais',
  [I18N.DAYS]: 'Dias',
  [I18N.DESCRIPTION]: 'Não perca este conteúdo do nosso patrocinador',
  [I18N.FAIR]: 'Razoável',
  [I18N.GOOD]: 'Boa',
  [I18N.HOURS]: 'Horas',
  [I18N.HUMIDITY]: 'Umidade',
  [I18N.ISI]: 'Informações importantes de segurança',
  [I18N.MINUTES_ABBREVIATION]: 'Min',
  [I18N.MODERATE]: 'Moderada',
  [I18N.POOR]: 'Ruim',
  [I18N.PROMOTED_BY_TEXT]: 'Anúncio do',
  [I18N.SECONDS_ABBREVIATION]: 'Seg',
  [I18N.TITLE]: 'Clique aqui para obter mais informações',
  [I18N.UNKNOWN]: 'Desconhecido',
  [I18N.UV_INDEX]: 'Índice UV',
  [I18N.VERY_POOR]: 'Muito ruim',
  [I18N.WIND]: 'Vento'
};
