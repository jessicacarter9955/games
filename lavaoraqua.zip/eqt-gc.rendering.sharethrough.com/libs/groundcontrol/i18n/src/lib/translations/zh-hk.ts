import { I18N } from './type';

export const zhHk: { [key in I18N]: string } = {
  // AI generated
  [I18N.ADVERTISER]: '贊助商',
  [I18N.AIR_QUALITY]: '空氣質素',
  [I18N.CTA_TEXT]: '查看更多',
  [I18N.DAYS]: '日',
  [I18N.DESCRIPTION]: '不要錯過我們贊助商的內容',
  [I18N.FAIR]: '尚可',
  [I18N.GOOD]: '良好',
  [I18N.HOURS]: '小時',
  [I18N.HUMIDITY]: '濕度',
  [I18N.ISI]: '重要安全資訊',
  [I18N.MINUTES_ABBREVIATION]: '分',
  [I18N.MODERATE]: '中等',
  [I18N.POOR]: '差',
  [I18N.PROMOTED_BY_TEXT]: '廣告由',
  [I18N.SECONDS_ABBREVIATION]: '秒',
  [I18N.TITLE]: '點擊此處了解更多資訊',
  [I18N.UNKNOWN]: '未知',
  [I18N.UV_INDEX]: '紫外線指數',
  [I18N.VERY_POOR]: '非常差',
  [I18N.WIND]: '風'
};
