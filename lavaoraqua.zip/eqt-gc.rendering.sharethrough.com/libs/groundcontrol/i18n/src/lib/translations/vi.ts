import { I18N } from './type';

export const vi: { [key in I18N]: string } = {
  // AI generated
  [I18N.ADVERTISER]: 'Nhà tài trợ',
  [I18N.AIR_QUALITY]: 'Chất lượng không khí',
  [I18N.CTA_TEXT]: 'Xem thêm',
  [I18N.DAYS]: 'Ngày',
  [I18N.DESCRIPTION]: 'Đừng bỏ lỡ nội dung này từ nhà tài trợ của chúng tôi',
  [I18N.FAIR]: 'Tạm ổn',
  [I18N.GOOD]: 'Tốt',
  [I18N.HOURS]: 'Giờ',
  [I18N.HUMIDITY]: 'Độ ẩm',
  [I18N.ISI]: 'Thông tin an toàn quan trọng',
  [I18N.MINUTES_ABBREVIATION]: 'Phút',
  [I18N.MODERATE]: 'Trung bình',
  [I18N.POOR]: 'Kém',
  [I18N.PROMOTED_BY_TEXT]: 'Quảng cáo bởi',
  [I18N.SECONDS_ABBREVIATION]: 'Giây',
  [I18N.TITLE]: 'Nhấn vào đây để biết thêm thông tin',
  [I18N.UNKNOWN]: 'Không rõ',
  [I18N.UV_INDEX]: 'Chỉ số UV',
  [I18N.VERY_POOR]: 'Rất kém',
  [I18N.WIND]: 'Gió'
};
