import { I18N } from './type';

export const es: { [key in I18N]: string } = {
  [I18N.ADVERTISER]: 'Patrocinador',
  [I18N.AIR_QUALITY]: 'Calidad del aire',
  [I18N.CTA_TEXT]: 'Ver más',
  [I18N.DAYS]: 'Dias',
  [I18N.DESCRIPTION]: 'No te pierdas este contenido de nuestro patrocinador',
  [I18N.FAIR]: 'Aceptable',
  [I18N.GOOD]: 'Buena',
  [I18N.HOURS]: 'Horas',
  [I18N.HUMIDITY]: 'Humedad',
  [I18N.ISI]: 'Información de seguridad importante',
  [I18N.MINUTES_ABBREVIATION]: 'Min',
  [I18N.MODERATE]: 'Moderada',
  [I18N.POOR]: 'Mala',
  [I18N.PROMOTED_BY_TEXT]: 'Anuncio por',
  [I18N.SECONDS_ABBREVIATION]: 'Seg',
  [I18N.TITLE]: 'Haga clic aquí para más información',
  [I18N.UNKNOWN]: 'Desconocido',
  [I18N.UV_INDEX]: 'Índice UV',
  [I18N.VERY_POOR]: 'Muy mala',
  [I18N.WIND]: 'Viento'
};
