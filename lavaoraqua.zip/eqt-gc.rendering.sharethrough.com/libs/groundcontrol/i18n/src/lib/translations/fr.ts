import { I18N } from './type';

export const fr: { [key in I18N]: string } = {
  // AI generated
  [I18N.ADVERTISER]: 'Annonceur',
  [I18N.AIR_QUALITY]: "Qualité de l'air",
  [I18N.CTA_TEXT]: 'En savoir plus',
  [I18N.DAYS]: 'Jours',
  [I18N.DESCRIPTION]: 'Ne manquez pas ce contenu de notre annonceur',
  [I18N.FAIR]: 'Passable',
  [I18N.GOOD]: 'Bonne',
  [I18N.HOURS]: 'Heures',
  [I18N.HUMIDITY]: 'Humidité',
  [I18N.ISI]: 'Informations de sécurité importantes',
  [I18N.MINUTES_ABBREVIATION]: 'Min',
  [I18N.MODERATE]: 'Modérée',
  [I18N.POOR]: 'Mauvaise',
  [I18N.PROMOTED_BY_TEXT]: 'Publicité par',
  [I18N.SECONDS_ABBREVIATION]: 'Sec',
  [I18N.TITLE]: "Cliquez ici pour plus d'information",
  [I18N.UNKNOWN]: 'Inconnu',
  [I18N.UV_INDEX]: 'Indice UV',
  [I18N.VERY_POOR]: 'Très mauvaise',
  [I18N.WIND]: 'Vent'
};
