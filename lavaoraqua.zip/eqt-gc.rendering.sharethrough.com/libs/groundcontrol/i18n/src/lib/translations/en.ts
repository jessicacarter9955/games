import { I18N } from './type';

export const en: { [key in I18N]: string } = {
  [I18N.ADVERTISER]: 'Sponsor',
  [I18N.AIR_QUALITY]: 'Air Quality',
  [I18N.CTA_TEXT]: 'See More',
  [I18N.DAYS]: 'Days',
  [I18N.DESCRIPTION]: "Don't miss this content from our sponsor",
  [I18N.FAIR]: 'Fair',
  [I18N.GOOD]: 'Good',
  [I18N.HOURS]: 'Hours',
  [I18N.HUMIDITY]: 'Humidity',
  [I18N.ISI]: 'Important Safety Information',
  [I18N.MINUTES_ABBREVIATION]: 'Min',
  [I18N.MODERATE]: 'Moderate',
  [I18N.POOR]: 'Poor',
  [I18N.PROMOTED_BY_TEXT]: 'Ad by',
  [I18N.SECONDS_ABBREVIATION]: 'Sec',
  [I18N.TITLE]: 'Click Here for More Information',
  [I18N.UNKNOWN]: 'Unknown',
  [I18N.UV_INDEX]: 'UV Index',
  [I18N.VERY_POOR]: 'Very Poor',
  [I18N.WIND]: 'Wind'
};
