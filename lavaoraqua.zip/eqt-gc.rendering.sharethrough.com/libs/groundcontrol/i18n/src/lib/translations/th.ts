import { I18N } from './type';

export const th: { [key in I18N]: string } = {
  // AI generated
  [I18N.ADVERTISER]: 'ผู้สนับสนุน',
  [I18N.AIR_QUALITY]: 'คุณภาพอากาศ',
  [I18N.CTA_TEXT]: 'ดูเพิ่มเติม',
  [I18N.DAYS]: 'วัน',
  [I18N.DESCRIPTION]: 'อย่าพลาดเนื้อหานี้จากผู้สนับสนุนของเรา',
  [I18N.FAIR]: 'พอใช้',
  [I18N.GOOD]: 'ดี',
  [I18N.HOURS]: 'ชั่วโมง',
  [I18N.HUMIDITY]: 'ความชื้น',
  [I18N.ISI]: 'ข้อมูลด้านความปลอดภัยที่สำคัญ',
  [I18N.MINUTES_ABBREVIATION]: 'นาที',
  [I18N.MODERATE]: 'ปานกลาง',
  [I18N.POOR]: 'แย่',
  [I18N.PROMOTED_BY_TEXT]: 'โฆษณาโดย',
  [I18N.SECONDS_ABBREVIATION]: 'วินาที',
  [I18N.TITLE]: 'คลิกที่นี่เพื่อดูข้อมูลเพิ่มเติม',
  [I18N.UNKNOWN]: 'ไม่ทราบ',
  [I18N.UV_INDEX]: 'ดัชนีรังสียูวี',
  [I18N.VERY_POOR]: 'แย่มาก',
  [I18N.WIND]: 'ลม'
};
