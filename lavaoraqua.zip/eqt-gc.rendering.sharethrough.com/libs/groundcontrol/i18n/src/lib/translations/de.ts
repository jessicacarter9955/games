import { I18N } from './type';

export const de: { [key in I18N]: string } = {
  [I18N.ADVERTISER]: 'Sponsor',
  [I18N.AIR_QUALITY]: 'Luftqualität',
  [I18N.CTA_TEXT]: 'Mehr sehen',
  [I18N.DAYS]: 'Tages',
  [I18N.DESCRIPTION]: 'Verpassen Sie nicht diesen Inhalt von unserem Sponsor',
  [I18N.FAIR]: 'Zufriedenstellend',
  [I18N.GOOD]: 'Gut',
  [I18N.HOURS]: 'Std',
  [I18N.HUMIDITY]: 'Luftfeuchtigkeit',
  [I18N.ISI]: 'Wichtige Sicherheitsinformationen',
  [I18N.MINUTES_ABBREVIATION]: 'Min',
  [I18N.MODERATE]: 'Mäßig',
  [I18N.POOR]: 'Schlecht',
  [I18N.PROMOTED_BY_TEXT]: 'Anzeige von',
  [I18N.SECONDS_ABBREVIATION]: 'Sek',
  [I18N.TITLE]: 'Klicken Sie hier für weitere Informationen',
  [I18N.UNKNOWN]: 'Unbekannt',
  [I18N.UV_INDEX]: 'UV-Index',
  [I18N.VERY_POOR]: 'Sehr schlecht',
  [I18N.WIND]: 'Wind'
};
