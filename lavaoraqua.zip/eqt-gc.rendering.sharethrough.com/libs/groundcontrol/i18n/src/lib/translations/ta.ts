import { I18N } from './type';

export const ta: { [key in I18N]: string } = {
  // AI generated
  [I18N.ADVERTISER]: 'ஸ்பான்சர்',
  [I18N.AIR_QUALITY]: 'காற்று தரம்',
  [I18N.CTA_TEXT]: 'மேலும் பார்க்க',
  [I18N.DAYS]: 'நாட்கள்',
  [I18N.DESCRIPTION]: 'எங்கள் விளம்பரதாரரின் உள்ளடக்கத்தை தவறவிடாதீர்கள்',
  [I18N.FAIR]: 'சராசரி',
  [I18N.GOOD]: 'நன்று',
  [I18N.HOURS]: 'மணி',
  [I18N.HUMIDITY]: 'ஈரப்பதம்',
  [I18N.ISI]: 'முக்கியமான பாதுகாப்பு தகவல்',
  [I18N.MINUTES_ABBREVIATION]: 'நிமி',
  [I18N.MODERATE]: 'மிதமானது',
  [I18N.POOR]: 'மோசமானது',
  [I18N.PROMOTED_BY_TEXT]: 'விளம்பரம்:',
  [I18N.SECONDS_ABBREVIATION]: 'வினா',
  [I18N.TITLE]: 'மேலும் தகவலுக்கு இங்கே கிளிக் செய்யவும்',
  [I18N.UNKNOWN]: 'தெரியாதது',
  [I18N.UV_INDEX]: 'யூவி குறியீடு',
  [I18N.VERY_POOR]: 'மிக மோசமானது',
  [I18N.WIND]: 'காற்று'
};
