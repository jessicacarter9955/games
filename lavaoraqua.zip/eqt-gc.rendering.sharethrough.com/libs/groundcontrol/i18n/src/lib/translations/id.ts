import { I18N } from './type';

export const id: { [key in I18N]: string } = {
  // AI generated
  [I18N.ADVERTISER]: 'Sponsor',
  [I18N.AIR_QUALITY]: 'Kualitas udara',
  [I18N.CTA_TEXT]: 'Lihat Selengkapnya',
  [I18N.DAYS]: 'Hari',
  [I18N.DESCRIPTION]: 'Jangan lewatkan konten ini dari sponsor kami',
  [I18N.FAIR]: 'Cukup',
  [I18N.GOOD]: 'Baik',
  [I18N.HOURS]: 'Jam',
  [I18N.HUMIDITY]: 'Kelembaban',
  [I18N.ISI]: 'Informasi Keselamatan Penting',
  [I18N.MINUTES_ABBREVIATION]: 'Menit',
  [I18N.MODERATE]: 'Sedang',
  [I18N.POOR]: 'Buruk',
  [I18N.PROMOTED_BY_TEXT]: 'Iklan oleh',
  [I18N.SECONDS_ABBREVIATION]: 'Detik',
  [I18N.TITLE]: 'Klik di sini untuk informasi lebih lanjut',
  [I18N.UNKNOWN]: 'Tidak diketahui',
  [I18N.UV_INDEX]: 'Indeks UV',
  [I18N.VERY_POOR]: 'Sangat buruk',
  [I18N.WIND]: 'Angin'
};
