import { I18N } from './type';

export const ar: { [key in I18N]: string } = {
  // AI generated
  [I18N.ADVERTISER]: 'الراعي',
  [I18N.AIR_QUALITY]: 'جودة الهواء',
  [I18N.CTA_TEXT]: 'اعرف المزيد',
  [I18N.DAYS]: 'أيام',
  [I18N.DESCRIPTION]: 'لا تفوت هذا المحتوى من راعينا',
  [I18N.FAIR]: 'مقبولة',
  [I18N.GOOD]: 'جيدة',
  [I18N.HOURS]: 'ساعات',
  [I18N.HUMIDITY]: 'الرطوبة',
  [I18N.ISI]: 'معلومات السلامة الهامة',
  [I18N.MINUTES_ABBREVIATION]: 'دق',
  [I18N.MODERATE]: 'متوسطة',
  [I18N.POOR]: 'رديئة',
  [I18N.PROMOTED_BY_TEXT]: 'إعلان بواسطة',
  [I18N.SECONDS_ABBREVIATION]: 'ث',
  [I18N.TITLE]: 'انقر هنا لمزيد من المعلومات',
  [I18N.UNKNOWN]: 'غير معروف',
  [I18N.UV_INDEX]: 'مؤشر الأشعة فوق البنفسجية',
  [I18N.VERY_POOR]: 'سيئة للغاية',
  [I18N.WIND]: 'الرياح'
};
