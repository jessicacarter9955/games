import { I18N } from './type';

export const hr: { [key in I18N]: string } = {
  // AI generated
  [I18N.ADVERTISER]: 'Sponzor',
  [I18N.AIR_QUALITY]: 'Kvaliteta zraka',
  [I18N.CTA_TEXT]: 'Pogledaj više',
  [I18N.DAYS]: 'Dana',
  [I18N.DESCRIPTION]: 'Ne propustite ovaj sadržaj našeg sponzora',
  [I18N.FAIR]: 'Zadovoljavajuća',
  [I18N.GOOD]: 'Dobra',
  [I18N.HOURS]: 'Sati',
  [I18N.HUMIDITY]: 'Vlažnost',
  [I18N.ISI]: 'Važne sigurnosne informacije',
  [I18N.MINUTES_ABBREVIATION]: 'Min',
  [I18N.MODERATE]: 'Umjerena',
  [I18N.POOR]: 'Loša',
  [I18N.PROMOTED_BY_TEXT]: 'Oglas od',
  [I18N.SECONDS_ABBREVIATION]: 'Sek',
  [I18N.TITLE]: 'Kliknite ovdje za više informacija',
  [I18N.UNKNOWN]: 'Nepoznato',
  [I18N.UV_INDEX]: 'UV indeks',
  [I18N.VERY_POOR]: 'Vrlo loša',
  [I18N.WIND]: 'Vjetar'
};
