import { I18N } from './type';

export const ro: { [key in I18N]: string } = {
  // AI generated
  [I18N.ADVERTISER]: 'Sponsor',
  [I18N.AIR_QUALITY]: 'Calitatea aerului',
  [I18N.CTA_TEXT]: 'Află mai multe',
  [I18N.DAYS]: 'Zile',
  [I18N.DESCRIPTION]: 'Nu ratați acest conținut de la sponsorul nostru',
  [I18N.FAIR]: 'Acceptabilă',
  [I18N.GOOD]: 'Bună',
  [I18N.HOURS]: 'Ore',
  [I18N.HUMIDITY]: 'Umiditate',
  [I18N.ISI]: 'Informații importante privind siguranța',
  [I18N.MINUTES_ABBREVIATION]: 'Min',
  [I18N.MODERATE]: 'Moderată',
  [I18N.POOR]: 'Proastă',
  [I18N.PROMOTED_BY_TEXT]: 'Reclamă de la',
  [I18N.SECONDS_ABBREVIATION]: 'Sec',
  [I18N.TITLE]: 'Faceți clic aici pentru mai multe informații',
  [I18N.UNKNOWN]: 'Necunoscut',
  [I18N.UV_INDEX]: 'Indice UV',
  [I18N.VERY_POOR]: 'Foarte proastă',
  [I18N.WIND]: 'Vânt'
};
