import { I18N } from './type';

export const hi: { [key in I18N]: string } = {
  // AI generated
  [I18N.ADVERTISER]: 'प्रायोजक',
  [I18N.AIR_QUALITY]: 'वायु गुणवत्ता',
  [I18N.CTA_TEXT]: 'और देखें',
  [I18N.DAYS]: 'दिन',
  [I18N.DESCRIPTION]: 'हमारे प्रायोजक की इस सामग्री को न चूकें',
  [I18N.FAIR]: 'ठीक',
  [I18N.GOOD]: 'अच्छा',
  [I18N.HOURS]: 'घंटे',
  [I18N.HUMIDITY]: 'आर्द्रता',
  [I18N.ISI]: 'महत्वपूर्ण सुरक्षा जानकारी',
  [I18N.MINUTES_ABBREVIATION]: 'मिनट',
  [I18N.MODERATE]: 'मध्यम',
  [I18N.POOR]: 'खराब',
  [I18N.PROMOTED_BY_TEXT]: 'विज्ञापन द्वारा',
  [I18N.SECONDS_ABBREVIATION]: 'सेकंड',
  [I18N.TITLE]: 'अधिक जानकारी के लिए यहां क्लिक करें',
  [I18N.UNKNOWN]: 'अज्ञात',
  [I18N.UV_INDEX]: 'यूवी सूचकांक',
  [I18N.VERY_POOR]: 'बहुत खराब',
  [I18N.WIND]: 'हवा'
};
