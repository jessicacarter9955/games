import { I18N } from './type';

export const bg: { [key in I18N]: string } = {
  // AI generated
  [I18N.ADVERTISER]: 'Спонсор',
  [I18N.AIR_QUALITY]: 'Качество на въздуха',
  [I18N.CTA_TEXT]: 'Виж повече',
  [I18N.DAYS]: 'Дни',
  [I18N.DESCRIPTION]: 'Не пропускайте това съдържание от нашия спонсор',
  [I18N.FAIR]: 'Задоволително',
  [I18N.GOOD]: 'Добро',
  [I18N.HOURS]: 'Часа',
  [I18N.HUMIDITY]: 'Влажност',
  [I18N.ISI]: 'Важна информация за безопасността',
  [I18N.MINUTES_ABBREVIATION]: 'Мин',
  [I18N.MODERATE]: 'Умерено',
  [I18N.POOR]: 'Лошо',
  [I18N.PROMOTED_BY_TEXT]: 'Реклама от',
  [I18N.SECONDS_ABBREVIATION]: 'Сек',
  [I18N.TITLE]: 'Кликнете тук за повече информация',
  [I18N.UNKNOWN]: 'Неизвестно',
  [I18N.UV_INDEX]: 'UV индекс',
  [I18N.VERY_POOR]: 'Много лошо',
  [I18N.WIND]: 'Вятър'
};
