import { I18N } from './type';

export const hu: { [key in I18N]: string } = {
  // AI generated
  [I18N.ADVERTISER]: 'Szponzor',
  [I18N.AIR_QUALITY]: 'Levegőminőség',
  [I18N.CTA_TEXT]: 'Tovább',
  [I18N.DAYS]: 'Nap',
  [I18N.DESCRIPTION]: 'Ne hagyja ki ezt a tartalmat a szponzorunktól',
  [I18N.FAIR]: 'Elfogadható',
  [I18N.GOOD]: 'Jó',
  [I18N.HOURS]: 'Óra',
  [I18N.HUMIDITY]: 'Páratartalom',
  [I18N.ISI]: 'Fontos biztonsági információk',
  [I18N.MINUTES_ABBREVIATION]: 'Perc',
  [I18N.MODERATE]: 'Mérsékelt',
  [I18N.POOR]: 'Rossz',
  [I18N.PROMOTED_BY_TEXT]: 'Hirdetés:',
  [I18N.SECONDS_ABBREVIATION]: 'Mp',
  [I18N.TITLE]: 'Kattintson ide további információkért',
  [I18N.UNKNOWN]: 'Ismeretlen',
  [I18N.UV_INDEX]: 'UV-index',
  [I18N.VERY_POOR]: 'Nagyon rossz',
  [I18N.WIND]: 'Szél'
};
