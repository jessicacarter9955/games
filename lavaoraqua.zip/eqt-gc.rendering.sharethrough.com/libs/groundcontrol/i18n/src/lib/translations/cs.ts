import { I18N } from './type';

export const cs: { [key in I18N]: string } = {
  // AI generated
  [I18N.ADVERTISER]: 'Sponzor',
  [I18N.AIR_QUALITY]: 'Kvalita ovzduší',
  [I18N.CTA_TEXT]: 'Zjistit více',
  [I18N.DAYS]: 'Dny',
  [I18N.DESCRIPTION]: 'Nezmeškejte tento obsah od našeho sponzora',
  [I18N.FAIR]: 'Uspokojivá',
  [I18N.GOOD]: 'Dobrá',
  [I18N.HOURS]: 'Hodiny',
  [I18N.HUMIDITY]: 'Vlhkost',
  [I18N.ISI]: 'Důležité bezpečnostní informace',
  [I18N.MINUTES_ABBREVIATION]: 'Min',
  [I18N.MODERATE]: 'Střední',
  [I18N.POOR]: 'Špatná',
  [I18N.PROMOTED_BY_TEXT]: 'Reklama od',
  [I18N.SECONDS_ABBREVIATION]: 'Sek',
  [I18N.TITLE]: 'Klikněte zde pro více informací',
  [I18N.UNKNOWN]: 'Neznámá',
  [I18N.UV_INDEX]: 'UV index',
  [I18N.VERY_POOR]: 'Velmi špatná',
  [I18N.WIND]: 'Vítr'
};
