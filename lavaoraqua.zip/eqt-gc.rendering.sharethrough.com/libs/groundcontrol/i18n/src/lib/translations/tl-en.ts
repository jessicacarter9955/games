import { I18N } from './type';

export const tlEn: { [key in I18N]: string } = {
  // AI generated
  [I18N.ADVERTISER]: 'Sponsor',
  [I18N.AIR_QUALITY]: 'Air Quality',
  [I18N.CTA_TEXT]: 'Tingnan pa',
  [I18N.DAYS]: 'Araw',
  [I18N.DESCRIPTION]: 'Huwag palampasin ang nilalamang ito mula sa aming sponsor',
  [I18N.FAIR]: 'Fair',
  [I18N.GOOD]: 'Good',
  [I18N.HOURS]: 'Oras',
  [I18N.HUMIDITY]: 'Humidity',
  [I18N.ISI]: 'Important Safety Information',
  [I18N.MINUTES_ABBREVIATION]: 'Min',
  [I18N.MODERATE]: 'Moderate',
  [I18N.POOR]: 'Poor',
  [I18N.PROMOTED_BY_TEXT]: 'Ad mula sa',
  [I18N.SECONDS_ABBREVIATION]: 'Sec',
  [I18N.TITLE]: 'Click dito para sa karagdagang impormasyon',
  [I18N.UNKNOWN]: 'Unknown',
  [I18N.UV_INDEX]: 'UV Index',
  [I18N.VERY_POOR]: 'Very Poor',
  [I18N.WIND]: 'Wind'
};
