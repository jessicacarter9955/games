import { I18N } from './type';

export const zhCn: { [key in I18N]: string } = {
  [I18N.ADVERTISER]: '赞助商',
  [I18N.AIR_QUALITY]: '空气质量',
  [I18N.CTA_TEXT]: '查看更多',
  [I18N.DAYS]: '天',
  [I18N.DESCRIPTION]: '不要错过我们赞助商的内容',
  [I18N.FAIR]: '一般',
  [I18N.GOOD]: '良好',
  [I18N.HOURS]: '小时',
  [I18N.HUMIDITY]: '湿度',
  [I18N.ISI]: '重要安全信息',
  [I18N.MINUTES_ABBREVIATION]: '分',
  [I18N.MODERATE]: '中等',
  [I18N.POOR]: '差',
  [I18N.PROMOTED_BY_TEXT]: '广告来自',
  [I18N.SECONDS_ABBREVIATION]: '秒',
  [I18N.TITLE]: '点击此处了解更多资讯',
  [I18N.UNKNOWN]: '未知',
  [I18N.UV_INDEX]: '紫外线指数',
  [I18N.VERY_POOR]: '很差',
  [I18N.WIND]: '风'
};
