import { I18N } from './type';

export const ja: { [key in I18N]: string } = {
  // AI generated
  [I18N.ADVERTISER]: 'スポンサー',
  [I18N.AIR_QUALITY]: '空気の質',
  [I18N.CTA_TEXT]: 'もっと見る',
  [I18N.DAYS]: '日',
  [I18N.DESCRIPTION]: 'スポンサーのコンテンツをお見逃しなく',
  [I18N.FAIR]: 'まあまあ',
  [I18N.GOOD]: '良好',
  [I18N.HOURS]: '時間',
  [I18N.HUMIDITY]: '湿度',
  [I18N.ISI]: '重要な安全情報',
  [I18N.MINUTES_ABBREVIATION]: '分',
  [I18N.MODERATE]: '中程度',
  [I18N.POOR]: '悪い',
  [I18N.PROMOTED_BY_TEXT]: '広告：',
  [I18N.SECONDS_ABBREVIATION]: '秒',
  [I18N.TITLE]: '詳細はこちらをクリック',
  [I18N.UNKNOWN]: '不明',
  [I18N.UV_INDEX]: 'UV指数',
  [I18N.VERY_POOR]: '非常に悪い',
  [I18N.WIND]: '風'
};
