import { I18N } from './type';

export const ko: { [key in I18N]: string } = {
  // AI generated
  [I18N.ADVERTISER]: '스폰서',
  [I18N.AIR_QUALITY]: '대기 질',
  [I18N.CTA_TEXT]: '자세히 보기',
  [I18N.DAYS]: '일',
  [I18N.DESCRIPTION]: '스폰서의 콘텐츠를 놓치지 마세요',
  [I18N.FAIR]: '보통',
  [I18N.GOOD]: '좋음',
  [I18N.HOURS]: '시간',
  [I18N.HUMIDITY]: '습도',
  [I18N.ISI]: '중요한 안전 정보',
  [I18N.MINUTES_ABBREVIATION]: '분',
  [I18N.MODERATE]: '중간',
  [I18N.POOR]: '나쁨',
  [I18N.PROMOTED_BY_TEXT]: '광고:',
  [I18N.SECONDS_ABBREVIATION]: '초',
  [I18N.TITLE]: '자세한 내용을 보려면 여기를 클릭하세요',
  [I18N.UNKNOWN]: '알 수 없음',
  [I18N.UV_INDEX]: '자외선 지수',
  [I18N.VERY_POOR]: '매우 나쁨',
  [I18N.WIND]: '바람'
};
