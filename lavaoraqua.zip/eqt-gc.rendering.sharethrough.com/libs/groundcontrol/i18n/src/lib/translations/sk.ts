import { I18N } from './type';

export const sk: { [key in I18N]: string } = {
  // AI generated
  [I18N.ADVERTISER]: 'Sponzor',
  [I18N.AIR_QUALITY]: 'Kvalita ovzdušia',
  [I18N.CTA_TEXT]: 'Zobraziť viac',
  [I18N.DAYS]: 'Dni',
  [I18N.DESCRIPTION]: 'Nezmeškajte tento obsah od nášho sponzora',
  [I18N.FAIR]: 'Uspokojivá',
  [I18N.GOOD]: 'Dobrá',
  [I18N.HOURS]: 'Hodiny',
  [I18N.HUMIDITY]: 'Vlhkosť',
  [I18N.ISI]: 'Dôležité bezpečnostné informácie',
  [I18N.MINUTES_ABBREVIATION]: 'Min',
  [I18N.MODERATE]: 'Stredná',
  [I18N.POOR]: 'Zlá',
  [I18N.PROMOTED_BY_TEXT]: 'Reklama od',
  [I18N.SECONDS_ABBREVIATION]: 'Sek',
  [I18N.TITLE]: 'Kliknite sem pre viac informácií',
  [I18N.UNKNOWN]: 'Neznáme',
  [I18N.UV_INDEX]: 'Index UV',
  [I18N.VERY_POOR]: 'Veľmi zlá',
  [I18N.WIND]: 'Vietor'
};
