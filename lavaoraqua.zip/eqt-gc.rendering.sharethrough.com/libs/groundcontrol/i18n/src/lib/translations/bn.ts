import { I18N } from './type';

export const bn: { [key in I18N]: string } = {
  // AI generated
  [I18N.ADVERTISER]: 'স্পনসর',
  [I18N.AIR_QUALITY]: 'বায়ুর গুণমান',
  [I18N.CTA_TEXT]: 'আরও দেখুন',
  [I18N.DAYS]: 'দিন',
  [I18N.DESCRIPTION]: 'আমাদের স্পনসরের এই বিষয়বস্তুটি মিস করবেন না',
  [I18N.FAIR]: 'মোটামুটি',
  [I18N.GOOD]: 'ভাল',
  [I18N.HOURS]: 'ঘণ্টা',
  [I18N.HUMIDITY]: 'আর্দ্রতা',
  [I18N.ISI]: 'গুরুত্বপূর্ণ সুরক্ষা তথ্য',
  [I18N.MINUTES_ABBREVIATION]: 'মিনিট',
  [I18N.MODERATE]: 'মাঝারি',
  [I18N.POOR]: 'খারাপ',
  [I18N.PROMOTED_BY_TEXT]: 'প্রচারক',
  [I18N.SECONDS_ABBREVIATION]: 'সেকেন্ড',
  [I18N.TITLE]: 'আরও তথ্যের জন্য এখানে ক্লিক করুন',
  [I18N.UNKNOWN]: 'অজানা',
  [I18N.UV_INDEX]: 'ইউভি সূচক',
  [I18N.VERY_POOR]: 'অত্যন্ত খারাপ',
  [I18N.WIND]: 'বাতাস'
};
