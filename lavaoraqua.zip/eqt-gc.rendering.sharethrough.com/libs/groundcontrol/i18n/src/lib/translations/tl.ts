import { I18N } from './type';

export const tl: { [key in I18N]: string } = {
  // AI generated
  [I18N.ADVERTISER]: 'Tagasuporta',
  [I18N.AIR_QUALITY]: 'Kalidad ng hangin',
  [I18N.CTA_TEXT]: 'Tingnan pa',
  [I18N.DAYS]: 'Araw',
  [I18N.DESCRIPTION]: 'Huwag palampasin ang nilalamang ito mula sa aming sponsor',
  [I18N.FAIR]: 'Katamtaman',
  [I18N.GOOD]: 'Maganda',
  [I18N.HOURS]: 'Oras',
  [I18N.HUMIDITY]: 'Halumigmig',
  [I18N.ISI]: 'Mahalagang Impormasyon sa Kaligtasan',
  [I18N.MINUTES_ABBREVIATION]: 'Min',
  [I18N.MODERATE]: 'Tama lang',
  [I18N.POOR]: 'Masama',
  [I18N.PROMOTED_BY_TEXT]: 'Anunsyo mula sa',
  [I18N.SECONDS_ABBREVIATION]: 'Sec',
  [I18N.TITLE]: 'Mag-click dito para sa karagdagang impormasyon',
  [I18N.UNKNOWN]: 'Hindi alam',
  [I18N.UV_INDEX]: 'UV Index',
  [I18N.VERY_POOR]: 'Napakasama',
  [I18N.WIND]: 'Hangin'
};
