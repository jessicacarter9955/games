import { I18N } from './type';

export const it: { [key in I18N]: string } = {
  [I18N.ADVERTISER]: 'Sponsor',
  [I18N.AIR_QUALITY]: "Qualità dell'aria",
  [I18N.CTA_TEXT]: 'Vedi altro',
  [I18N.DAYS]: 'Giorni',
  [I18N.DESCRIPTION]: 'Non perdere questo contenuto del nostro sponsor',
  [I18N.FAIR]: 'Accettabile',
  [I18N.GOOD]: 'Buona',
  [I18N.HOURS]: 'Ore',
  [I18N.HUMIDITY]: 'Umidità',
  [I18N.ISI]: 'Informazioni di sicurezza importanti',
  [I18N.MINUTES_ABBREVIATION]: 'Min',
  [I18N.MODERATE]: 'Moderata',
  [I18N.POOR]: 'Scarsa',
  [I18N.PROMOTED_BY_TEXT]: 'Annuncio per',
  [I18N.SECONDS_ABBREVIATION]: 'Sec',
  [I18N.TITLE]: 'Clicca qui per maggiori informazioni',
  [I18N.UNKNOWN]: 'Sconosciuto',
  [I18N.UV_INDEX]: 'Indice UV',
  [I18N.VERY_POOR]: 'Molto scarsa',
  [I18N.WIND]: 'Vento'
};
