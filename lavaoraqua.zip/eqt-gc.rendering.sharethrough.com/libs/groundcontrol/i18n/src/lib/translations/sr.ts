import { I18N } from './type';

export const sr: { [key in I18N]: string } = {
  // AI generated
  [I18N.ADVERTISER]: 'Sponzor',
  [I18N.AIR_QUALITY]: 'Kvalitet vazduha',
  [I18N.CTA_TEXT]: 'Pogledaj više',
  [I18N.DAYS]: 'Dana',
  [I18N.DESCRIPTION]: 'Ne propustite ovaj sadržaj od našeg sponzora',
  [I18N.FAIR]: 'Zadovoljavajuća',
  [I18N.GOOD]: 'Dobra',
  [I18N.HOURS]: 'Sati',
  [I18N.HUMIDITY]: 'Vlažnost',
  [I18N.ISI]: 'Važne bezbednosne informacije',
  [I18N.MINUTES_ABBREVIATION]: 'Min',
  [I18N.MODERATE]: 'Umerena',
  [I18N.POOR]: 'Loša',
  [I18N.PROMOTED_BY_TEXT]: 'Oglas od',
  [I18N.SECONDS_ABBREVIATION]: 'Sek',
  [I18N.TITLE]: 'Kliknite ovde za više informacija',
  [I18N.UNKNOWN]: 'Nepoznato',
  [I18N.UV_INDEX]: 'UV indeks',
  [I18N.VERY_POOR]: 'Veoma loša',
  [I18N.WIND]: 'Vetar'
};
