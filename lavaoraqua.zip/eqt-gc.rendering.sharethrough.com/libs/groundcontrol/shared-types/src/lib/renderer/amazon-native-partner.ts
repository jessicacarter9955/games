import { DSP } from '../payload/dsp';

// Amazon's other EQT partner, 437, keeps the Clickout. The full build's ad unit, the Modular native bundle and the
// Display Tracker all read this, so a new Amazon Native partner reaches each of them.
export const isAmazonNativePartner = (partnerId: string): boolean =>
  partnerId === DSP.AMAZON || partnerId === DSP.AMAZON_NATIVE_B_EQT;
