import * as z from 'zod/mini';

export enum ImageAssetType {
  ICON = 1,
  LOGO = 2,
  MAIN = 3,

  // ! These are only used by Amazon DSP
  PRIME_LOGO = 512,
  AVAILABLE_ON_AMAZON = 513
}

export enum DataAssetType {
  SPONSORED = 1,
  DESC = 2,
  RATING = 3,
  LIKES = 4,
  DOWNLOADS = 5,
  PRICE = 6,
  SALEPRICE = 7,
  PHONE = 8,
  ADDRESS = 9,
  DESC2 = 10,
  DISPLAYURL = 11,
  CTATEXT = 12,

  // ! Custom assets
  OPT_OUT = 501,
  OPT_OUT_URL = 502,
  ISI = 503,
  BANNER = 504,
  CALL_TO_ACTION = 505,

  // ! These are only used by Amazon DSP
  BADGE = 507,
  REVIEW = 508,
  CLIMATE_PLEDGE = 511,
  COUPON = 512,

  // ! Shoppable native single-marker (GC ↔ MBMB contract). Carries data.ext, no value.
  SHOPPABLE = 520
}

// Zod schemas for the enums
export const ImageAssetTypeSchema = z.nativeEnum(ImageAssetType);
export const DataAssetTypeSchema = z.nativeEnum(DataAssetType);

export type ImageAssetTypeValue = z.infer<typeof ImageAssetTypeSchema>;
export type DataAssetTypeValue = z.infer<typeof DataAssetTypeSchema>;
