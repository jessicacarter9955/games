/**
 * Equativ Tracker Event Action ID constants
 *
 * These are string identifiers used by Equativ for tracking events.
 * Extracted to shared-types to avoid circular dependencies between
 * groundcontrol-utils and groundcontrol-eqt packages.
 */
export enum TrackerEventActionId {
  GroundControlLoaded = '10032',
  TrackClick = '10008',
  Viewable = '41',
  IsEnhanced = '10033',
  VideoStart = '2',
  AudioOn = '7',
  EnhancedEngagement = '10037',
  EnhancedContent = '10038',
  ProductCard = '10034',
  ShoppableCarouselArrow = '10035',
  VideoResume = '22',
  VideoFirstQuartile = '14',
  VideoMidpoint = '15',
  VideoThirdQuartile = '16',
  VideoComplete = '17',
  VideoError = '10009',
  BannerClickable = '10039',
  MraidImpression = '10012',
  OmidImpression = '10013',
  OverlayActive = '10041',
  AmazonNativeImpression = '10043',
  friendlyIframeEnv = '10044',
  HeavyAdIntervention = '10045',
  EnhancementLoadFailure = '10046',
  DcoRequestSuccess = '10047',
  DcoRequestFailure = '10048',
  DecoEnhancementFallback = '10050',
  PublisherStylingRequested = '10052',
  PublisherStylingLoaded = '10053'
}
