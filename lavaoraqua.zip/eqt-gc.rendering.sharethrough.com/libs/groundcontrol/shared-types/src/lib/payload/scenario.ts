/**
 * Every value GroundControl branches on when it reads `payload.scenario`.
 *
 * `payload.scenario` carries the value of the AB Scenario SSB already drew server-side, forwarded
 * verbatim. It is a single scalar field, so all consumers share one flat namespace: two
 * features that pick the same value cannot be told apart, and an AB test assigning that
 * value drives both of them at once. Declare new values here rather than as a loose constant
 * beside the feature that reads them — the collision this prevents is invisible at the call
 * site, where each feature only ever sees its own comparison.
 *
 * Lives in `shared-types` (with the other payload children — creative, network, enhancement)
 * rather than `groundcontrol-core`, even though `core` re-exports it and owns `isScenarioActive`:
 * `core` already depends on `groundcontrol-monitoring` (for `reportError`), and WR-2205 needs
 * `monitoring` to read this same registry, so keeping it in `core` would make that a cycle.
 *
 * Rules for adding a member:
 * - Append only. A value that has ever been emitted by a Delivery Admin AB Scenario must not be
 *   reused or renumbered; reporting for past traffic is keyed on it.
 * - Never 0. SSB sends 0 for "no scenario assigned", so it can never mean a real behavior.
 * - Register it in WR-2111's value registry, since Delivery Admin owns the AB Scenario that emits it.
 *
 * `groundcontrol-core`'s `scenario/helpers.spec.ts` enforces the first two mechanically.
 *
 * @see docs/contracts/scenario.md for the payload contract and how SSB forwards the value
 */
export enum Scenario {
  /**
   * WR-2043's embedded GC measurement path, in place of the external OnePixel script.
   * Live: AB test 281 already maps a traffic bucket to this value — see
   * docs/adr/0004-cutover-gated-by-scenario-field-not-new-flag.md.
   */
  GcMeasurement = 1,

  /**
   * WR-2116 click extraction, one AB Scenario per DSP. Provisional until the matching Delivery
   * Admin AB Scenarios are configured: until then no payload carries these values, so extraction
   * stays on the legacy `findClickoutUrl` path.
   */
  Dv360ClickExtraction = 2,
  AppnexusClickExtraction = 3,
  TradeDeskClickExtraction = 4,
  RubiconClickExtraction = 5,

  /**
   * WR-2205 Datadog Error Reporting: each Error Report from this population also goes to
   * Datadog while Airbrake keeps receiving it, both copies sharing an `errorReportId`, until
   * the Parity Check passes (WR-2053 Decision 10/13). Datadog then becomes the code default and
   * this value is retired. Delivery Admin AB Scenario `GC_DATADOG_ERRORS_06` on test 281.
   */
  DatadogErrorReporting = 6
}
