// The DSP partner ids GroundControl branches on, as `creative.partnerId` carries them. Defined here rather than in
// `groundcontrol-core` (which re-exports it) so the bundles that don't import core, the Display Tracker and the Modular
// native bundle, read the same ids as the full build.
export enum DSP {
  AMAZON = 'MR2ocDuaNCWP75ZJSgTEHjdB',
  AMAZON_EQT = '437',
  AMAZON_NATIVE_B_EQT = '490',
  NEXXEN_BANNER = '9d7CMfp2nZ18hckXmDwoFxbs',
  OPENX = '6E6dnPq1ztfkuxxNupdpgjDB',
  PUBMATIC = 't2DCBn66fGJXtaXNiotHoWdn'
}
