import type { GCEnhancementPayload, GCEnhancementType } from '@sharethrough/groundcontrol-enhancement-flush';
import * as z from 'zod/mini';

export type EnhancementType = 'default' | 'disabled' | GCEnhancementType;

export type ValidEnhancementType = 'default' | GCEnhancementType;

export type Enhancement = {
  type: EnhancementType;
  enhancement_version_id?: string;
  evid?: string;
  payload?: GCEnhancementPayload['payload'];
};

// Reference: https://gitlab.com/smartadserver/private/be/deco.protobuf/-/blob/main/protos/enhancement.proto?ref_type=heads#L21
export enum RawEnhancementType {
  Disabled = 0,
  Default = 1,
  OutstreamCaptions = 8,
  OutstreamCountdown = 9,
  OutstreamHeadline = 10,
  BannerCountdown = 11,
  BannerHeadline = 12,
  BannerDailyWeatherOutlook = 13,
  BannerWeather = 14,
  BannerSportsTicker = 15,
  OutstreamShoppable = 16,
  BannerShoppable = 17,
  OutstreamDailyWeatherOutlook = 18,
  OutstreamSportsTicker = 19,
  OutstreamWeather = 20,
  BannerShoppableOverlay = 22,
  BannerMedalCount = 23,
  OutstreamMedalCount = 24,
  BannerBrandedHeadline = 30,
  OutstreamBrandedHeadlines = 31,
  BannerWorldTournament = 36,
  OutstreamWorldTournament = 37,
  BannerCustom = 39,
  OutstreamCustom = 40,

  // Sofiapulse enhancements
  BannerSofiaPulseSportsHeadlines = 26,
  BannerSofiaPulseQuiz = 27,
  BannerSofiaPulseBettingOdds = 28,
  BannerSofiaPulseStockTicker = 29
}

export const RawEnhancementSchema = z.object({
  type: z.enum(RawEnhancementType),
  payload: z.optional(z.string()),
  evid: z.optional(z.string())
});

export type RawEnhancement = z.infer<typeof RawEnhancementSchema>;

export type DefaultEnhancementPayload = {
  type: 'default';
};

export type ValidEnhancementPayload = GCEnhancementPayload | DefaultEnhancementPayload;
