/**
 * Stages of the GC Ad Lifecycle, in order (see the "WR-2207 — GC Ad Lifecycle" Confluence page).
 * The values are what Error Sinks receive in the report's `stage` field.
 */
export enum LifecycleStage {
  Wrapper = 'wrapper',
  Load = 'load',
  Placeholder = 'placeholder',
  Payload = 'payload',
  Assets = 'assets',
  Creative = 'creative',
  Enhancement = 'enhancement',
  Impression = 'impression',
  Viewable = 'viewable',
  MeasuredImpression = 'measured_impression',
  Playback = 'playback',
  Interaction = 'interaction'
}
