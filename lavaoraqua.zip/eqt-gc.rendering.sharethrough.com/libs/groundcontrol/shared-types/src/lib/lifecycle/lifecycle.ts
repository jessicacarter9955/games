import type { LifecycleStage } from './lifecycle-stage';

/**
 * The ad an Error Report belongs to, merged into every report made through its lifecycle.
 */
export interface AdIdentifiers {
  id?: string;
  partnerId?: string;
  networkId?: string;
  callerId?: string;
  creativeType?: string;
}

/**
 * What an Error Report needs from the lifecycle: the stage to report and the ad it belongs to.
 * A scope never lets the reporting code choose the stage; it only carries one.
 */
export interface LifecycleScope {
  readonly stage: LifecycleStage | undefined;
  readonly identifiers: AdIdentifiers;
}

/**
 * A scope that keeps one stage while still reading the lifecycle's identifiers, so work that reports
 * after the ad has moved on (a fetch, an observer, a measurement session) keeps the stage it started in.
 */
export const bindStage = (scope: LifecycleScope, stage: LifecycleStage | undefined = scope.stage): LifecycleScope => ({
  stage,
  get identifiers() {
    return scope.identifiers;
  }
});

/**
 * The GC Ad Lifecycle of one ad, or of the GC instance before any ad exists. The code that drives
 * the ad enters each stage as it reaches it, and errors report whatever stage the lifecycle is in.
 */
export class Lifecycle implements LifecycleScope {
  private currentStage: LifecycleStage | undefined;
  private adIdentifiers: AdIdentifiers = {};

  constructor(stage?: LifecycleStage) {
    this.currentStage = stage;
  }

  get stage(): LifecycleStage | undefined {
    return this.currentStage;
  }

  get identifiers(): AdIdentifiers {
    return this.adIdentifiers;
  }

  enter(stage: LifecycleStage): void {
    this.currentStage = stage;
  }

  identify(identifiers: AdIdentifiers): void {
    this.adIdentifiers = { ...this.adIdentifiers, ...identifiers };
  }

  /**
   * Binds a stage for work that runs alongside or after the current one: a Measure stage, an
   * enhancement, or async work started now. Defaults to the current stage.
   */
  track(stage: LifecycleStage | undefined = this.currentStage): LifecycleScope {
    return bindStage(this, stage);
  }
}
