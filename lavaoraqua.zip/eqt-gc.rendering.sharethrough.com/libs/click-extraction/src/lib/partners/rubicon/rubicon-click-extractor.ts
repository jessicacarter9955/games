import type { RubiconClickExtractionResult } from '@sharethrough/groundcontrol-types';
import type { ClickExtractorProps } from '../../types';

const MIN_CLICKABLE_DIMENSION = 50;
const AD_INFO_PATTERN = /ad[-_]?choices|ad[-_]?info/i;

// Rubicon/Magnite creatives (Tier 2 — structured markup, no script injection)
// dispatch the click via an element's onclick that opens the MathTag clickthrough
// (pixel.mathtag.com/click…), which 302-redirects to the advertiser landing page
// while counting the click.
const MATHTAG_CLICK_URL_REGEX = /https?:\/\/pixel\.mathtag\.com\/click[/?][^"'\\\s)]+/i;

/**
 * Pulls the MathTag clickthrough URL out of an onclick handler string.
 * Matches the `/click` endpoint specifically so a MathTag impression/sync pixel
 * isn't mistaken for the click.
 */
function extractMathtagClickUrl(onclick: string): string | null {
  const match = new RegExp(MATHTAG_CLICK_URL_REGEX).exec(onclick);
  return match ? match[0] : null;
}

/**
 * Parses the MathTag click URL from the raw ad markup before render.
 * Works without DOM access or same-origin iframe restrictions.
 */
function extractMathtagClickFromMarkup(adm: string): string | null {
  return extractMathtagClickUrl(adm);
}

/**
 * Reads the MathTag click URL from a rendered `[onclick]` element.
 * Rubicon attaches the handler to the creative image (`img[onclick]`); checks the
 * container first, then the iframe document. Requires same-origin iframe access.
 */
function extractMathtagClickFromDom(
  container: { current: HTMLDivElement | null },
  bannerIframe: HTMLIFrameElement | null
): string | null {
  try {
    const roots: (Document | HTMLElement)[] = [];
    if (container.current) roots.push(container.current);
    const doc = bannerIframe?.contentDocument ?? bannerIframe?.contentWindow?.document;
    if (doc) roots.push(doc);

    for (const root of roots) {
      const elements = root.querySelectorAll<HTMLElement>('[onclick]');
      for (const element of Array.from(elements)) {
        const onclick = element.getAttribute('onclick');
        if (!onclick) continue;

        const url = extractMathtagClickUrl(onclick);
        if (url) return url;
      }
    }
  } catch {
    return null;
  }

  return null;
}

/**
 * Extracts click URL from anchor tags in the iframe document.
 * Filters out AdChoices/privacy icons by size and URL pattern.
 * Returns the URL of the largest qualifying anchor tag.
 */
function extractAnchorClickUrl(bannerIframe: HTMLIFrameElement | null): string | null {
  try {
    const doc = bannerIframe?.contentDocument ?? bannerIframe?.contentWindow?.document;
    if (!doc) return null;

    const anchors = doc.querySelectorAll<HTMLAnchorElement>('a[href]');
    let best: { url: string; area: number } | null = null;

    for (const anchor of Array.from(anchors)) {
      const href = anchor.getAttribute('href');

      if (!href || !href.startsWith('http') || AD_INFO_PATTERN.test(href)) continue;

      const rect = anchor.getBoundingClientRect();
      const img = anchor.querySelector('img');
      const imgRect = img?.getBoundingClientRect();

      const width = imgRect?.width || rect.width;
      const height = imgRect?.height || rect.height;

      if (width > MIN_CLICKABLE_DIMENSION || height > MIN_CLICKABLE_DIMENSION) {
        const area = width * height;
        if (!best || area > best.area) {
          best = { url: href, area };
        }
      }
    }

    return best?.url ?? null;
  } catch {
    return null;
  }
}

/**
 * Focused click URL extractor for Rubicon/Magnite (MathTag) creatives.
 *
 * Cascade ordered by reliability:
 * 1. creative.link          — OpenRTB payload (no parsing, no DOM)
 * 2. mathtag-onclick markup — parse pixel.mathtag.com/click URL from adm (no DOM)
 * 3. mathtag-onclick dom    — same, read from rendered [onclick] element (same-origin)
 * 4. anchor tag scan        — largest <a href> in iframe (same-origin, heuristic)
 *
 * When no URL can be parsed, the banner component falls back to dispatching the
 * element's own onclick (the legacy `rubicon-img-onclick` path), which guarantees
 * real redirection for creatives that compute the URL at click time.
 */
export function extractRubiconClickUrl(props: ClickExtractorProps): RubiconClickExtractionResult {
  const { container, bannerIframe, creativeLink, adm } = props;

  // Tier 1: Structured data — no DOM needed
  if (creativeLink) {
    return { url: creativeLink, method: 'creative-link' };
  }

  // Tier 2: Pre-render adm parsing — no DOM or iframe access needed
  if (adm) {
    const markupUrl = extractMathtagClickFromMarkup(adm);
    if (markupUrl) return { url: markupUrl, method: 'mathtag-onclick-markup' };
  }

  // Tier 3: Post-render inspection — requires same-origin
  const domUrl = extractMathtagClickFromDom(container, bannerIframe);
  if (domUrl) return { url: domUrl, method: 'mathtag-onclick-dom' };

  const anchorUrl = extractAnchorClickUrl(bannerIframe);
  if (anchorUrl) return { url: anchorUrl, method: 'anchor-tag' };

  return { url: null, method: 'not-found' };
}
