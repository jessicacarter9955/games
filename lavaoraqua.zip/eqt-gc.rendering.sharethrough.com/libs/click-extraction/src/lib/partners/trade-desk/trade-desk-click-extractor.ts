import type { TradeDeskClickExtractionResult } from '@sharethrough/groundcontrol-types';
import type { ClickExtractorProps } from '../../types';
import { extractClickTagParam, extractWindowClickTag } from '../../shared';

export function extractTradeDeskClickUrl(props: ClickExtractorProps): TradeDeskClickExtractionResult {
  const { bannerIframe, creativeLink, adm } = props;

  if (creativeLink) {
    return { url: creativeLink, method: 'creative-link' };
  }

  if (adm) {
    const clickTagUrl = extractClickTagParam(adm);
    if (clickTagUrl) return { url: clickTagUrl, method: 'click-tag-param' };
  }

  const windowClickTag = extractWindowClickTag(bannerIframe);
  if (windowClickTag) return { url: windowClickTag, method: 'window-click-tag' };

  return { url: null, method: 'not-found' };
}
