import type { Dv360ClickExtractionResult } from '@sharethrough/groundcontrol-types';
import type { ClickExtractorProps } from '../../types';
import { extractClickTagParam, extractWindowClickTag } from '../../shared';
import { isGWDWindow } from './gwd-types';

const MIN_CLICKABLE_DIMENSION = 50;
const AD_INFO_PATTERN = /ad[-_]?choices|ad[-_]?info/i;
const UNSUBSTITUTED_MACRO_PATTERN = /%%CLICK_URL|\$\{CLICK_URL/;
const GWD_EXIT_REGEX = /<gwd-exit[^>]*\burl=["']([^"']+)["'][^>]*>/gi;
const GWD_EXIT_METRIC_REGEX = /\bmetric=["']([^"']+)["']/i;

/**
 * Parses `<gwd-exit>` elements from the raw ad markup.
 * GWD embeds these in the HTML before the studioV2 runtime processes them,
 * so this works without DOM access or same-origin iframe restrictions.
 */
function extractGwdExitFromMarkup(adm: string): string | null {
  const matches: { url: string; metric: string }[] = [];
  let match: RegExpExecArray | null;

  while ((match = GWD_EXIT_REGEX.exec(adm)) !== null) {
    const url = match[1];
    const metricMatch = match[0].match(GWD_EXIT_METRIC_REGEX);
    const metric = metricMatch?.[1] ?? '';
    matches.push({ url, metric });
  }

  if (!matches.length) return null;

  const priority = ['mediaClickTag', 'clickTag', 'clickTag1'];
  for (const name of priority) {
    const found = matches.find((m) => m.metric === name);
    if (found) return found.url;
  }

  return matches[0].url;
}

/**
 * Reads the `studioV2.api` exit URLs from GWD runtime on the iframe window.
 * Requires same-origin iframe access.
 */
function extractGwdExitUrl(bannerIframe: HTMLIFrameElement | null): string | null {
  try {
    const win = bannerIframe?.contentWindow;
    if (!isGWDWindow(win)) return null;
    const creatives = win.studioV2.api.creatives;
    if (!creatives?.length) return null;

    const creative = creatives[0]['a'] ?? creatives[0]['j'];
    if (!creative || typeof creative !== 'object') return null;

    const exitObj = Object.values(creative).find((v) => v && typeof v === 'object' && v.Exit)?.Exit;
    if (!exitObj) return null;

    const priorityTags = ['mediaClickTag', 'clickTag1'];
    const priorityMap = new Map(priorityTags.map((tag, index) => [tag, index]));

    const tags = Object.keys(exitObj).sort((a, b) => {
      const aPriority = priorityMap.get(a);
      const bPriority = priorityMap.get(b);
      return (aPriority ?? Infinity) - (bPriority ?? Infinity);
    });

    for (const tagName of tags) {
      const tag = exitObj[tagName];
      if (tag && typeof tag === 'object' && tag.url) {
        return tag.url;
      }
    }
  } catch {
    return null;
  }

  return null;
}

/**
 * Extracts click URL from DCM `data-dcm-click-tracker` attribute on `.dcmads` elements
 * inside the iframe document (not the container — the INS tag renders inside the iframe).
 */
function extractDcmClickUrl(bannerIframe: HTMLIFrameElement | null): string | null {
  try {
    const doc = bannerIframe?.contentDocument ?? bannerIframe?.contentWindow?.document;
    if (!doc) return null;

    const dcmAd = doc.querySelector<HTMLElement>('.dcmads');
    const tracker = dcmAd?.dataset['dcmClickTracker'];

    if (!tracker) return null;
    if (UNSUBSTITUTED_MACRO_PATTERN.test(tracker)) return null;

    return tracker;
  } catch {
    return null;
  }
}

/**
 * Extracts click URL from anchor tags in the iframe document.
 * Filters out AdChoices/privacy icons by size and URL pattern.
 * Returns the URL of the largest qualifying anchor tag.
 */
function extractAnchorClickUrl(bannerIframe: HTMLIFrameElement | null): string | null {
  try {
    const doc = bannerIframe?.contentDocument ?? bannerIframe?.contentWindow?.document;
    if (!doc) return null;

    const anchors = doc.querySelectorAll('a[href]');
    let best: { url: string; area: number } | null = null;

    for (let i = 0; i < anchors.length; i++) {
      const anchor = anchors[i] as HTMLAnchorElement;
      const href = anchor.getAttribute('href');

      if (!href || !href.startsWith('http') || AD_INFO_PATTERN.test(href)) continue;

      const rect = anchor.getBoundingClientRect();
      const img = anchor.querySelector('img');
      const imgRect = img?.getBoundingClientRect();

      const width = imgRect?.width || rect.width;
      const height = imgRect?.height || rect.height;

      if (width > MIN_CLICKABLE_DIMENSION || height > MIN_CLICKABLE_DIMENSION) {
        const area = width * height;
        if (!best || area > best.area) {
          best = { url: href, area };
        }
      }
    }

    return best?.url ?? null;
  } catch {
    return null;
  }
}

/**
 * Focused click URL extractor for DV360 creatives.
 *
 * 7-rule cascade ordered by reliability:
 * 1. creative.link       — OpenRTB payload (no parsing, no DOM)
 * 2. gwd-exit markup     — parse <gwd-exit> from adm string (no DOM)
 * 3. clickTag param      — parse clickTag= from adm string (no DOM)
 * 4. studioV2.api        — GWD runtime on iframe (same-origin)
 * 5. window.clickTag     — HTML5 global on iframe (same-origin)
 * 6. DCM data-attr       — .dcmads in iframe document (same-origin)
 * 7. anchor tag scan     — largest <a href> in iframe (same-origin, heuristic)
 */
export function extractDv360ClickUrl(props: ClickExtractorProps): Dv360ClickExtractionResult {
  const { bannerIframe, creativeLink, adm } = props;

  // Tier 1: Structured data — no DOM needed
  if (creativeLink) {
    return { url: creativeLink, method: 'creative-link' };
  }

  // Tier 2: Pre-render adm parsing — no DOM or iframe access needed
  if (adm) {
    const gwdMarkupUrl = extractGwdExitFromMarkup(adm);
    if (gwdMarkupUrl) return { url: gwdMarkupUrl, method: 'gwd-exit-markup' };

    const clickTagUrl = extractClickTagParam(adm);
    if (clickTagUrl) return { url: clickTagUrl, method: 'click-tag-param' };
  }

  // Tier 3: Post-render iframe inspection — requires same-origin
  const gwdUrl = extractGwdExitUrl(bannerIframe);
  if (gwdUrl) return { url: gwdUrl, method: 'gwd-exit' };

  const clickTag = extractWindowClickTag(bannerIframe);
  if (clickTag) return { url: clickTag, method: 'window-click-tag' };

  const dcmUrl = extractDcmClickUrl(bannerIframe);
  if (dcmUrl) return { url: dcmUrl, method: 'dcm-data-attr' };

  const anchorUrl = extractAnchorClickUrl(bannerIframe);
  if (anchorUrl) return { url: anchorUrl, method: 'anchor-tag' };

  return { url: null, method: 'not-found' };
}
