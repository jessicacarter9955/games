export interface GWDWindow extends Window {
  studioV2: {
    api: {
      creatives: [
        {
          [key: string]: {
            [key: string]: {
              Exit: {
                [exitKey: string]: {
                  url: string;
                };
              };
            };
          };
        }
      ];
    };
  };
}

export const isGWDWindow = (window: Window | null | undefined): window is GWDWindow => {
  if (!window) return false;

  return (
    'studioV2' in window &&
    typeof window.studioV2 === 'object' &&
    window.studioV2 !== null &&
    'api' in window.studioV2 &&
    typeof window.studioV2.api === 'object' &&
    window.studioV2.api !== null &&
    'creatives' in window.studioV2.api &&
    Array.isArray(window.studioV2.api.creatives)
  );
};
