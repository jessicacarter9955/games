/**
 * DSPs we extract click URLs for.
 *
 * A DSP is identified at runtime by `payload.creative.partnerId`, not by name, and each one
 * reaches us under several ids (regional splits, curated marketplaces, test partners). This
 * enum gives the DSP a single stable handle so partner ids, the extractor, and the activation
 * scenario can all be keyed on the same thing.
 */
export enum ClickExtractionPartner {
  Dv360 = 'dv360',
  Appnexus = 'appnexus',
  TradeDesk = 'tradeDesk',
  Rubicon = 'rubicon'
}

/**
 * AdGestion partner ids per DSP — the single source of truth.
 *
 * Onboarding a newly-seen partner id is one edit here, with no change to the extractors or to
 * the banner components. Sets are confirmed against the WR-1858 partner volume analysis.
 *
 * Ids are strings because that is what the payload carries; comparing against numbers would
 * silently never match.
 */
export const CLICK_EXTRACTION_PARTNER_IDS: Readonly<Record<ClickExtractionPartner, readonly string[]>> = {
  // AdGestion partner names: 76 "Google DV360", 429 "Google DV360 B", 499 "Google DV360 B ROW"
  [ClickExtractionPartner.Dv360]: ['76', '429', '499'],

  // AppNexus demand reaches us as Xandr (Microsoft) — there is no partner literally named
  // "AppNexus". These are the Xandr-lineage ids whose creatives use the EBG.ads mechanism.
  [ClickExtractionPartner.Appnexus]: [
    '86', // Xandr (Microsoft)
    '447', // Xandr B
    '519', // Xandr Curated
    '33046', // Xandr
    '33091' // Xandr
  ],

  [ClickExtractionPartner.TradeDesk]: ['75'],

  // Rubicon demand reaches us as Magnite (Rubicon Project rebranded). These are the Magnite
  // display ids whose creatives use the MathTag click mechanism.
  [ClickExtractionPartner.Rubicon]: [
    '109', // Magnite DV+
    '376', // Magnite B
    '438', // Magnite ROW
    '507' // Test Magnite B
  ]
};

/** Every DSP handle, for callers that need to scan all partners. */
export const CLICK_EXTRACTION_PARTNERS: readonly ClickExtractionPartner[] = Object.values(ClickExtractionPartner);
