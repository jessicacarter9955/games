import type { AppnexusClickExtractionResult } from '@sharethrough/groundcontrol-types';
import type { ClickExtractorProps } from '../../types';

const MIN_CLICKABLE_DIMENSION = 50;
const AD_INFO_PATTERN = /ad[-_]?choices|ad[-_]?info/i;

// Xandr/AppNexus creatives are served through the EBG.ads runtime and dispatch the
// click via an element's onclick handler. The clickthrough itself is the adnxs
// `/click?` endpoint, which 302-redirects to the advertiser landing page while
// counting the click. The geo-prefixed subdomain varies (nym1-ib, ams1-ib, fra1-ib…).
const EBG_ADS_PATTERN = /EBG\.ads/;
const ADNXS_CLICK_URL_REGEX = /https?:\/\/[a-z0-9-]+\.adnxs\.com\/click\?[^"'\\\s)]+/i;

/**
 * Pulls the adnxs clickthrough URL out of an EBG.ads onclick handler string.
 * Only trusts the URL when the EBG.ads signature is present, so an unrelated
 * adnxs tracking pixel elsewhere in the markup isn't mistaken for the click.
 */
function extractAdnxsClickUrl(onclick: string): string | null {
  if (!EBG_ADS_PATTERN.test(onclick)) return null;

  const match = new RegExp(ADNXS_CLICK_URL_REGEX).exec(onclick);
  return match ? match[0] : null;
}

/**
 * Parses the EBG.ads click URL from the raw ad markup before render.
 * Works without DOM access or same-origin iframe restrictions.
 */
function extractEbgClickFromMarkup(adm: string): string | null {
  return extractAdnxsClickUrl(adm);
}

/**
 * Reads the EBG.ads click URL from a rendered `[onclick]` element.
 * Xandr attaches the handler to the creative image (`img[onclick]`); checks the
 * container first, then the iframe document. Requires same-origin iframe access.
 */
function extractEbgClickFromDom(
  container: { current: HTMLDivElement | null },
  bannerIframe: HTMLIFrameElement | null
): string | null {
  try {
    const roots: (Document | HTMLElement)[] = [];
    if (container.current) roots.push(container.current);
    const doc = bannerIframe?.contentDocument ?? bannerIframe?.contentWindow?.document;
    if (doc) roots.push(doc);

    for (const root of roots) {
      const elements = root.querySelectorAll<HTMLElement>('[onclick]');
      for (let i = 0; i < elements.length; i++) {
        const onclick = elements[i].getAttribute('onclick');
        if (!onclick) continue;

        const url = extractAdnxsClickUrl(onclick);
        if (url) return url;
      }
    }
  } catch {
    return null;
  }

  return null;
}

/**
 * Extracts click URL from anchor tags in the iframe document.
 * Filters out AdChoices/privacy icons by size and URL pattern.
 * Returns the URL of the largest qualifying anchor tag.
 */
function extractAnchorClickUrl(bannerIframe: HTMLIFrameElement | null): string | null {
  try {
    const doc = bannerIframe?.contentDocument ?? bannerIframe?.contentWindow?.document;
    if (!doc) return null;

    const anchors = doc.querySelectorAll<HTMLAnchorElement>('a[href]');
    let best: { url: string; area: number } | null = null;

    for (let i = 0; i < anchors.length; i++) {
      const anchor = anchors[i];
      const href = anchor.getAttribute('href');

      if (!href || !href.startsWith('http') || AD_INFO_PATTERN.test(href)) continue;

      const rect = anchor.getBoundingClientRect();
      const img = anchor.querySelector('img');
      const imgRect = img?.getBoundingClientRect();

      const width = imgRect?.width || rect.width;
      const height = imgRect?.height || rect.height;

      if (width > MIN_CLICKABLE_DIMENSION || height > MIN_CLICKABLE_DIMENSION) {
        const area = width * height;
        if (!best || area > best.area) {
          best = { url: href, area };
        }
      }
    }

    return best?.url ?? null;
  } catch {
    return null;
  }
}

/**
 * Focused click URL extractor for AppNexus/Xandr (EBG.ads) creatives.
 *
 * Cascade ordered by reliability:
 * 1. creative.link        — OpenRTB payload (no parsing, no DOM)
 * 2. ebg-onclick markup   — parse adnxs /click? URL from EBG.ads onclick in adm (no DOM)
 * 3. ebg-onclick dom      — same, read from rendered [onclick] element (same-origin)
 * 4. anchor tag scan      — largest <a href> in iframe (same-origin, heuristic)
 *
 * When no URL can be parsed, the banner component falls back to dispatching the
 * EBG.ads element's own onclick (the legacy `xandr-img-onclick` path), which
 * guarantees real redirection for creatives that compute the URL at click time.
 */
export function extractAppnexusClickUrl(props: ClickExtractorProps): AppnexusClickExtractionResult {
  const { container, bannerIframe, creativeLink, adm } = props;

  // Tier 1: Structured data — no DOM needed
  if (creativeLink) {
    return { url: creativeLink, method: 'creative-link' };
  }

  // Tier 2: Pre-render adm parsing — no DOM or iframe access needed
  if (adm) {
    const markupUrl = extractEbgClickFromMarkup(adm);
    if (markupUrl) return { url: markupUrl, method: 'ebg-onclick-markup' };
  }

  // Tier 3: Post-render inspection — requires same-origin
  const domUrl = extractEbgClickFromDom(container, bannerIframe);
  if (domUrl) return { url: domUrl, method: 'ebg-onclick-dom' };

  const anchorUrl = extractAnchorClickUrl(bannerIframe);
  if (anchorUrl) return { url: anchorUrl, method: 'anchor-tag' };

  return { url: null, method: 'not-found' };
}
