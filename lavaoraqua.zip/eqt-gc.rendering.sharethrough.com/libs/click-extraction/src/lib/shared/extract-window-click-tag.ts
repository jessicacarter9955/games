export function extractWindowClickTag(bannerIframe: HTMLIFrameElement | null): string | null {
  try {
    const win = bannerIframe?.contentWindow as (Window & { clickTag?: string }) | null;
    if (win?.clickTag && typeof win.clickTag === 'string' && win.clickTag.startsWith('http')) {
      return win.clickTag;
    }
  } catch {
    return null;
  }
  return null;
}
