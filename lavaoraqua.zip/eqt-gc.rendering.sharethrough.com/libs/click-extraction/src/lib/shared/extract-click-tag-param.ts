const CLICK_TAG_PARAM_REGEX = /clickTag=(.*?)["|'|&]/i;

export function extractClickTagParam(adm: string): string | null {
  const match = adm.match(CLICK_TAG_PARAM_REGEX);
  if (!match) return null;

  try {
    return decodeURIComponent(match[1]);
  } catch {
    return match[1];
  }
}
