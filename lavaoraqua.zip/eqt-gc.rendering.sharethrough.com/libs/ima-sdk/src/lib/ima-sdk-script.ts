const IMA_SDK_URL = 'https://imasdk.googleapis.com/js/sdkloader/ima3.js';

export const isImaSdkLoaded = () => typeof window.google !== 'undefined' && typeof window.google.ima !== 'undefined';

export const loadImaSDKScript = async () => {
  await downloadScript();
};

type PromiseCache = {
  [key: string]: Promise<string>;
};

const cache: PromiseCache = {};

// TODO: handle timeout? maybe an optional parameter?
// TODO: write tests for this code mang
export const downloadScript = (): Promise<string> => {
  if (cache[IMA_SDK_URL] != undefined) {
    return cache[IMA_SDK_URL];
  }

  /*  it's possible that our wait condition is already met, no need
   *  to download the script at all */
  if (isImaSdkLoaded()) {
    cache[IMA_SDK_URL] = Promise.resolve('');
    return cache[IMA_SDK_URL];
  }

  cache[IMA_SDK_URL] = new Promise((resolve, _) => {
    const script = document.createElement('script');
    script.src = IMA_SDK_URL;
    document.body.appendChild(script);

    const waitInterval = setInterval(() => {
      if (!isImaSdkLoaded()) {
        return;
      }

      clearInterval(waitInterval);
      resolve('');
    }, 100);
  });

  return cache[IMA_SDK_URL];
};
