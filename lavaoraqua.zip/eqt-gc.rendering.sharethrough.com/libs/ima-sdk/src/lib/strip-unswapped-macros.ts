const UNSWAPPED_MACRO_PATTERN = /%%[A-Z_]+%%/g;

export function stripUnswappedMacros(vast: string): string {
  return vast.replace(UNSWAPPED_MACRO_PATTERN, '');
}
