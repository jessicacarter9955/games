import type { ReadonlySignal, Signal } from '@preact/signals';

export interface IAd extends google.ima.Ad {}

export interface IAdEvent extends google.ima.AdEvent {}

export interface IAdsManager extends google.ima.AdsManager {}

export interface IAdError extends google.ima.AdError {}

export interface IAdErrorEvent extends google.ima.AdErrorEvent {}

export interface IAdDisplayContainer extends google.ima.AdDisplayContainer {}

export interface IAdsLoader extends google.ima.AdsLoader {}

export interface IAdsManagerLoadedEvent extends google.ima.AdsManagerLoadedEvent {}

export enum ImaVideoPercentage {
  P25 = '25',
  P50 = '50',
  P75 = '75',
  P95 = '95'
}

/**
 * Mutable internal state of the IMA SDK. Each property is a writable signal
 * that event handlers update as ad playback progresses.
 */
export interface IImaState {
  adVideoHtmlElement: Signal<HTMLVideoElement | undefined>;
  adVideoSource: Signal<string | undefined>;
  clickThroughUrl: Signal<string | undefined>;
  completed: Signal<boolean>;
  creativeId: Signal<string | undefined>;
  currentQuartile: Signal<ImaVideoPercentage | undefined>;
  currentTime: Signal<number | undefined>;
  duration: Signal<number | undefined>;
  muted: Signal<boolean>;
  playing: Signal<boolean>;
  rendered: Signal<boolean>;
  started: Signal<boolean>;
  vpaid: Signal<boolean | undefined>;
}

/**
 * Read-only view of IMA SDK state exposed to external consumers. Each property
 * is a ReadonlySignal that supports .subscribe() for reactive updates.
 */
export interface IImaObservableState {
  adVideoHtmlElement: ReadonlySignal<HTMLVideoElement | undefined>;
  adVideoSource: ReadonlySignal<string | undefined>;
  clickThroughUrl: ReadonlySignal<string | undefined>;
  completed: ReadonlySignal<boolean>;
  creativeId: ReadonlySignal<string | undefined>;
  currentQuartile: ReadonlySignal<ImaVideoPercentage | undefined>;
  currentTime: ReadonlySignal<number | undefined>;
  duration: ReadonlySignal<number | undefined>;
  muted: ReadonlySignal<boolean>;
  playing: ReadonlySignal<boolean>;
  rendered: ReadonlySignal<boolean>;
  started: ReadonlySignal<boolean>;
  vpaid: ReadonlySignal<boolean | undefined>;
}
