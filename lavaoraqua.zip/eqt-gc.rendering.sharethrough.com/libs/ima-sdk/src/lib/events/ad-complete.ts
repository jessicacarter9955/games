import type { IImaState } from '../types';

export const adCompleteHandler = (state: IImaState): void => {
  state.completed.value = true;
  state.playing.value = false;
};
