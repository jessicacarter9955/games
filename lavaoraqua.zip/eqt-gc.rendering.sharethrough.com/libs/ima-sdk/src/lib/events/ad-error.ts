import type { IAdError, IAdErrorEvent } from '../types';

export const adErrorHandler = (errEvent: IAdErrorEvent, onError: ((error: Error) => void) | undefined): void => {
  const error: IAdError | null = errEvent.getError();
  if (!error || !onError) return;
  onError(error);
};
