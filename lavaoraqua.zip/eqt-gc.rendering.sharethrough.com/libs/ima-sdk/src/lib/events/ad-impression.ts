import type { IImaState } from '../types';

export const adImpressionHandler = (state: IImaState) => {
  state.rendered.value = true;
};
