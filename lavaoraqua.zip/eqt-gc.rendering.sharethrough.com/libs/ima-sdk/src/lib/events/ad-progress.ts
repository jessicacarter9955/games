import { ImaVideoPercentage, type IAdEvent, type IImaState } from '../types';

export const adProgressHandler = (event: IAdEvent, state: IImaState) => {
  const data = event.getAdData();
  if (!data) return;

  if ('duration' in data && typeof data.duration === 'number') {
    if (state.duration.value !== data.duration) {
      state.duration.value = data.duration;
    }
  }

  if ('currentTime' in data && typeof data.currentTime === 'number') {
    if (state.currentTime.value !== data.currentTime) {
      state.currentTime.value = data.currentTime;
    }
  }

  if (state.adVideoSource.value === undefined) {
    const htmlVideoSelector = 'video:not(.blank-video)[src]';
    const htmlVideoElement: HTMLVideoElement | null = document.querySelector(htmlVideoSelector);
    if (htmlVideoElement && htmlVideoElement.src) state.adVideoSource.value = htmlVideoElement.src;
  }

  const adCurrentTime = state.currentTime.value;
  const duration = state.duration.value;

  if (adCurrentTime && duration && adCurrentTime / duration >= 0.95) {
    // Sometimes the first value of currentTime is higher than duration and would cause the 95% to fire too early.
    if (adCurrentTime > duration) {
      return;
    }
    if (state.currentQuartile.value !== ImaVideoPercentage.P95) {
      state.currentQuartile.value = ImaVideoPercentage.P95;
    }
  }
};
