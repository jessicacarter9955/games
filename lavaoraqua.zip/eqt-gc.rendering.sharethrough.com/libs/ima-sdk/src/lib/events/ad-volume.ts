import type { IAd, IAdEvent, IImaState } from '../types';

export const adVolumeChangeHandler = (e: IAdEvent, state: IImaState): void => {
  const ad: IAd | null = e.getAd();
  if (!ad) return;

  if ('data' in ad && ad.data && typeof ad.data === 'object') {
    const { data } = ad;
    if (data !== null && 'volume' in data && typeof data.volume === 'number') {
      state.muted.value = data.volume === 0;
    }
  }
};
