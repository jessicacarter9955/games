import type { IImaState } from '../types';

export const adPausedHandler = (state: IImaState, paused: boolean): void => {
  state.playing.value = paused;
};
