import type { IAdEvent, IImaState } from '../types';

export const adLoadedHandler = (event: IAdEvent, state: IImaState) => {
  const ad = event.getAd();
  if (!ad) return;
  const creativeId: string = ad.getCreativeId();
  const videoSrc: string | null = ad.getMediaUrl();

  if (creativeId !== state.creativeId.value) {
    state.creativeId.value = creativeId;
  }

  if (videoSrc && videoSrc !== state.adVideoSource.value) {
    state.adVideoSource.value = videoSrc;
  }
};
