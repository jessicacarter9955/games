import type { IImaState, ImaVideoPercentage } from '../types';

export const adQuartileChangeHandler = (state: IImaState, quartile: ImaVideoPercentage): void => {
  if (state.currentQuartile.value !== quartile) {
    state.currentQuartile.value = quartile;
  }
};
