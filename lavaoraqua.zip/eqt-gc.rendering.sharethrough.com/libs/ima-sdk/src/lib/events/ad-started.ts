import type { IAdEvent, IAdsManager, IImaState } from '../types';

export const adStartedHandler = (adsManager: IAdsManager, e: IAdEvent, state: IImaState): void => {
  /* We're re-muting the ad here. This has been done once
   * already, earlier in the ad's lifecycle, but it's possible
   * for VPAID ads to control their own volume, and we've run
   * into some of these unmuting themselves. This re-mutes as
   * soon as the video autoplays */
  if (adsManager.getVolume() > 0) adsManager.setVolume(0);

  state.completed.value = false;
  state.playing.value = true;
  state.started.value = true;

  const clickThroughUrl = getClickThroughUrl(e);
  if (clickThroughUrl && clickThroughUrl !== state.clickThroughUrl.value) state.clickThroughUrl.value = clickThroughUrl;

  const isVpaid = getIsVpaidCreative(e);
  if (state.vpaid.value !== isVpaid) state.vpaid.value = isVpaid;

  const videoElement: HTMLVideoElement | null = getVideoElement(state.adVideoSource.value);
  if (videoElement && videoElement !== state.adVideoHtmlElement.value) state.adVideoHtmlElement.value = videoElement;
};

const getVideoElement = (videoSrc: string | undefined): HTMLVideoElement | null => {
  if (!videoSrc) return null;
  return document.querySelector(`video[src="${videoSrc}"]`);
};

const getClickThroughUrl = (e: IAdEvent): string | undefined => {
  const ad = e.getAd();
  if (ad && 'data' in ad && typeof ad.data === 'object') {
    const { data } = ad;
    if (data && 'clickThroughUrl' in data && typeof data.clickThroughUrl === 'string') {
      return data.clickThroughUrl;
    }
  }
  return undefined;
};

const getIsVpaidCreative = (e: IAdEvent): boolean => {
  const ad = e.getAd();

  if (ad && 'data' in ad && typeof ad.data === 'object') {
    const { data } = ad;
    if (data && 'vpaid' in data) return Boolean(data.vpaid);
  }

  return false;
};
