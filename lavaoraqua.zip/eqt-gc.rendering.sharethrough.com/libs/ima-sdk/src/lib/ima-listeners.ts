import {
  adCompleteHandler,
  adLoadedHandler,
  adPausedHandler,
  adProgressHandler,
  adQuartileChangeHandler,
  adStartedHandler,
  adVolumeChangeHandler
} from './events';
import { adErrorHandler } from './events/ad-error';
import { adImpressionHandler } from './events/ad-impression';
import { ImaVideoPercentage, type IAdErrorEvent, type IAdEvent, type IAdsManager, type IImaState } from './types';

export const addAdsManagerListeners = (
  adsManager: IAdsManager,
  state: IImaState,
  onClick: () => void,
  onError: ((error: Error) => void) | undefined
) => {
  try {
    const AD_EVENT_TYPE = window.google.ima.AdEvent.Type;
    const AD_ERROR_TYPE = window.google.ima.AdErrorEvent.Type;

    adsManager.addEventListener(AD_EVENT_TYPE.LOADED, (e: IAdEvent) => {
      adLoadedHandler(e, state);
    });

    adsManager.addEventListener(AD_EVENT_TYPE.AD_PROGRESS, (e: IAdEvent) => {
      adProgressHandler(e, state);
    });

    adsManager.addEventListener(AD_EVENT_TYPE.FIRST_QUARTILE, () =>
      adQuartileChangeHandler(state, ImaVideoPercentage.P25)
    );
    adsManager.addEventListener(AD_EVENT_TYPE.MIDPOINT, () => adQuartileChangeHandler(state, ImaVideoPercentage.P50));
    adsManager.addEventListener(AD_EVENT_TYPE.THIRD_QUARTILE, () =>
      adQuartileChangeHandler(state, ImaVideoPercentage.P75)
    );

    adsManager.addEventListener(AD_EVENT_TYPE.COMPLETE, () => adCompleteHandler(state));
    adsManager.addEventListener(AD_EVENT_TYPE.PAUSED, () => adPausedHandler(state, true));
    adsManager.addEventListener(AD_EVENT_TYPE.RESUMED, () => adPausedHandler(state, false));
    adsManager.addEventListener(AD_EVENT_TYPE.STARTED, (e: IAdEvent) => adStartedHandler(adsManager, e, state));

    adsManager.addEventListener(AD_EVENT_TYPE.VOLUME_CHANGED, (e: IAdEvent) => {
      adVolumeChangeHandler(e, state);
    });

    adsManager.addEventListener(AD_ERROR_TYPE.AD_ERROR, (errEvent: IAdErrorEvent) => adErrorHandler(errEvent, onError));

    adsManager.addEventListener(AD_EVENT_TYPE.CLICK, (_e: IAdEvent) => onClick());

    adsManager.addEventListener(AD_EVENT_TYPE.IMPRESSION, () => adImpressionHandler(state));
  } catch (error) {
    if (!onError) return;
    onError(error instanceof Error ? error : new Error(String(error)));
  }
};

export const removeAdsManagerListeners = (
  adsManager: IAdsManager,
  state: IImaState,
  onClick: () => void,
  onError: ((error: Error) => void) | undefined
) => {
  try {
    const AD_EVENT_TYPE = window.google.ima.AdEvent.Type;
    const AD_ERROR_TYPE = window.google.ima.AdErrorEvent.Type;

    adsManager.removeEventListener(AD_EVENT_TYPE.LOADED, (e: IAdEvent) => {
      adLoadedHandler(e, state);
    });

    adsManager.removeEventListener(AD_EVENT_TYPE.AD_PROGRESS, (e: IAdEvent) => {
      adProgressHandler(e, state);
    });

    adsManager.removeEventListener(AD_EVENT_TYPE.FIRST_QUARTILE, () =>
      adQuartileChangeHandler(state, ImaVideoPercentage.P25)
    );
    adsManager.removeEventListener(AD_EVENT_TYPE.MIDPOINT, () =>
      adQuartileChangeHandler(state, ImaVideoPercentage.P50)
    );
    adsManager.removeEventListener(AD_EVENT_TYPE.THIRD_QUARTILE, () =>
      adQuartileChangeHandler(state, ImaVideoPercentage.P75)
    );

    adsManager.removeEventListener(AD_EVENT_TYPE.COMPLETE, () => adCompleteHandler(state));
    adsManager.removeEventListener(AD_EVENT_TYPE.PAUSED, () => adPausedHandler(state, true));
    adsManager.removeEventListener(AD_EVENT_TYPE.RESUMED, () => adPausedHandler(state, false));
    adsManager.removeEventListener(AD_EVENT_TYPE.STARTED, (e: IAdEvent) => adStartedHandler(adsManager, e, state));

    adsManager.removeEventListener(AD_EVENT_TYPE.VOLUME_CHANGED, (e: IAdEvent) => {
      adVolumeChangeHandler(e, state);
    });

    adsManager.removeEventListener(AD_ERROR_TYPE.AD_ERROR, (errEvent: IAdErrorEvent) =>
      adErrorHandler(errEvent, onError)
    );

    adsManager.removeEventListener(AD_EVENT_TYPE.CLICK, (_e: IAdEvent) => onClick);

    adsManager.removeEventListener(AD_EVENT_TYPE.IMPRESSION, () => adImpressionHandler(state));
  } catch (error) {
    if (!onError) return;
    onError(error instanceof Error ? error : new Error(String(error)));
  }
};
