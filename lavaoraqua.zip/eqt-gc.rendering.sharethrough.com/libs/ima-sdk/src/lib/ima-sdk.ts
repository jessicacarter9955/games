import { signal } from '@preact/signals';
import { addAdsManagerListeners, removeAdsManagerListeners } from './ima-listeners';
import { isImaSdkLoaded, loadImaSDKScript } from './ima-sdk-script';
import type {
  IAdErrorEvent,
  IAdsManagerLoadedEvent,
  IImaObservableState,
  IImaState,
  ImaVideoPercentage
} from './types';
import { stripUnswappedMacros } from './strip-unswapped-macros';
import { type IAdDisplayContainer, type IAdsLoader, type IAdsManager } from './types';

/**
 * ImaSDK is a wrapper class for integrating the Google IMA (Interactive Media Ads) SDK into a web application.
 * It manages the lifecycle and state of video ad playback, including initialization, ad requests, playback controls,
 * and error handling. The class exposes observable state for ad playback and provides methods for controlling ad video.
 *
 * @remarks
 * - This class is designed to work with the Google IMA SDK loaded globally on the `window` object.
 * - It uses `@preact/signals` for state management and exposes `ReadonlySignal<T>` properties for external subscription.
 * - Handles both VAST XML strings and ad tag URLs for ad requests.
 * - Provides methods for starting, pausing, resuming, replaying, and setting the volume of video ads.
 * - Automatically detects browser autoplay support and configures ad playback accordingly.
 *
 * @example
 * ```typescript
 * const imaSdk = new ImaSDK(
 *   videoElement,
 *   containerElement,
 *   vastUrl,
 *   () => { /* onInit callback *\/ },
 *   () => { /* onClick callback *\/ },
 *   (error) => { /* onError callback *\/ }
 * );
 *
 * imaSdk.video.start();
 * imaSdk.video.pause();
 * imaSdk.destroy();
 * ```
 *
 * @public
 * @class
 */
export class ImaSDK {
  // private properties
  private adDisplayContainer: IAdDisplayContainer;
  private adsLoader: IAdsLoader;
  private adsManager: IAdsManager | undefined;
  private browserSupportsAutoPlay = false;
  private get dimensions() {
    return {
      width: this.containerElement.clientWidth,
      height: this.containerElement.clientHeight
    };
  }
  private onInit: () => void;
  private onClick: () => void;
  private onError?: (error: Error) => void;
  private _state: IImaState = {
    adVideoHtmlElement: signal<HTMLVideoElement | undefined>(undefined),
    adVideoSource: signal<string | undefined>(undefined),
    clickThroughUrl: signal<string | undefined>(undefined),
    completed: signal<boolean>(false),
    creativeId: signal<string | undefined>(undefined),
    currentQuartile: signal<ImaVideoPercentage | undefined>(undefined),
    currentTime: signal<number | undefined>(undefined),
    duration: signal<number | undefined>(undefined),
    muted: signal<boolean>(true),
    playing: signal<boolean>(false),
    rendered: signal<boolean>(false),
    started: signal<boolean>(false),
    vpaid: signal<boolean | undefined>(undefined)
  };
  // end of private properties

  // public properties
  public containerElement: HTMLElement;
  public videoElement: HTMLVideoElement;
  public vastUrl: string;
  // end of public properties

  // ReadonlySignal view exposed to external consumers — Signal<T> satisfies ReadonlySignal<T>
  public state: IImaObservableState = this._state;

  constructor(
    videoElement: HTMLVideoElement,
    containerElement: HTMLElement,
    vastUrl: string,
    onInit: () => void,
    onClick: () => void,
    onError?: (error: Error) => void
  ) {
    this.containerElement = containerElement;
    this.vastUrl = stripUnswappedMacros(vastUrl);
    this.videoElement = videoElement;
    this.onInit = onInit;
    this.onClick = onClick;
    this.onError = onError;

    this.initialize();
  }

  private async initialize() {
    try {
      if (!isImaSdkLoaded()) await loadImaSDKScript();

      window.google.ima.settings.setVpaidMode(window.google.ima.ImaSdkSettings.VpaidMode.ENABLED);
      window.google.ima.settings.setDisableCustomPlaybackForIOS10Plus(true);

      this.buildAdDisplayContainer();
    } catch (error) {
      if (!this.onError) return;
      this.onError(error instanceof Error ? error : new Error(String(error)));
    }
  }

  private buildAdDisplayContainer() {
    try {
      this.adDisplayContainer = new window.google.ima.AdDisplayContainer(this.containerElement, this.videoElement);
      this.adsLoader = new window.google.ima.AdsLoader(this.adDisplayContainer);

      // ADS_MANAGER_LOADED: Fired when ad request succeeds and ads manager is created
      // This event will NOT fire if there are issues with VAST URL (301/302/303 redirects,
      // network errors, malformed VAST, etc.) - those trigger AD_ERROR instead
      this.adsLoader.addEventListener(
        window.google.ima.AdsManagerLoadedEvent.Type.ADS_MANAGER_LOADED,
        this.adsManagerLoaded,
        false
      );

      // AD_ERROR: Fired for any ad loading failures (network issues, invalid VAST, redirects, etc.)
      this.adsLoader.addEventListener(window.google.ima.AdErrorEvent.Type.AD_ERROR, this.adError, false);

      const isMuted = this._state.muted.value;

      this.videoElement.volume = isMuted ? 0 : 1;
      this.videoElement.muted = isMuted;

      const playPromise = this.videoElement.play();
      if (playPromise !== undefined) {
        playPromise.then(() => this.afterAutoPlay(true)).catch(() => this.afterAutoPlay(false));
      }
    } catch (error) {
      if (!this.onError) return;
      this.onError(error instanceof Error ? error : new Error(String(error)));
    }
  }

  private afterAutoPlay = (supportAutoPlay: boolean) => {
    this.browserSupportsAutoPlay = supportAutoPlay;
    this.requestAds();
  };

  private adError = (errorEvent: IAdErrorEvent) => {
    const error = errorEvent.getError();
    if (!this.onError) return;
    this.onError(error instanceof Error ? error : new Error(String(error)));
  };

  private requestAds = () => {
    try {
      this.videoElement.pause();
      const adsRequest = new window.google.ima.AdsRequest();

      if (this.vastUrl.match('</VAST>')) {
        adsRequest.adsResponse = this.vastUrl;
      } else {
        adsRequest.adTagUrl = this.vastUrl;
      }

      adsRequest.linearAdSlotWidth = this.dimensions.width;
      adsRequest.linearAdSlotHeight = this.dimensions.height;
      adsRequest.nonLinearAdSlotWidth = this.dimensions.width;
      adsRequest.nonLinearAdSlotHeight = this.dimensions.height;

      adsRequest.setAdWillAutoPlay(this.browserSupportsAutoPlay);
      adsRequest.setAdWillPlayMuted(true);

      this.adsLoader.requestAds(adsRequest);
    } catch (error) {
      if (!this.onError) return;
      this.onError(error instanceof Error ? error : new Error(String(error)));
    }
  };

  // This function only gets called when we receive the ADS_MANAGER_LOADED success event
  // If there are VAST URL issues (301/302/303 redirects, network errors, etc.),
  // the AD_ERROR event fires instead and this function is never called
  private adsManagerLoaded = (adsManagerLoaded: IAdsManagerLoadedEvent) => {
    try {
      const adsRenderingSettings = new window.google.ima.AdsRenderingSettings();
      adsRenderingSettings.uiElements = [];
      adsRenderingSettings.enablePreloading = true;
      // Partner 377/468 VPAID units (Dynadmic wrapper) fire AdLoaded late or never; IMA's
      // default 8s timeout produces VAST error 402 → event 10009. Doubling the window tests
      // the "AdLoaded is merely late" hypothesis (see docs/gc-outstream-vpaid-assessment.md).
      adsRenderingSettings.loadVideoTimeout = 16000;

      this.adsManager = adsManagerLoaded.getAdsManager(this.videoElement, adsRenderingSettings);
      if (!this.adsManager) {
        throw new Error('AdsManager is not defined');
      }

      this.adsManager.setVolume(0);

      addAdsManagerListeners(this.adsManager, this._state, this.onClick, this.onError);

      this.initializeAds();
    } catch (error) {
      if (!this.onError) return;
      this.onError(error instanceof Error ? error : new Error(String(error)));
    }
  };

  private assertAdsManager = (): IAdsManager => {
    if (!this.adsManager) {
      throw new Error('AdsManager not initialized. Wait for ADS_MANAGER_LOADED event.');
    }
    return this.adsManager;
  };

  private initializeAds = () => {
    try {
      this.adDisplayContainer.initialize();
      this.assertAdsManager().init(this.dimensions.width, this.dimensions.height, window.google.ima.ViewMode.NORMAL);
      this.onInit();
    } catch (error) {
      if (!this.onError) return;
      this.onError(error instanceof Error ? error : new Error(String(error)));
    }
  };

  private resetState = () => {
    this._state.adVideoHtmlElement.value = undefined;
    this._state.adVideoSource.value = undefined;
    this._state.clickThroughUrl.value = undefined;
    this._state.completed.value = false;
    this._state.vpaid.value = undefined;
    this._state.creativeId.value = undefined;
    this._state.currentQuartile.value = undefined;
    this._state.currentTime.value = undefined;
    this._state.duration.value = undefined;
    this._state.muted.value = true;
    this._state.playing.value = false;
    this._state.started.value = false;
  };

  public video = {
    start: () => {
      try {
        this.assertAdsManager().start();
      } catch (error) {
        if (!this.onError) return;
        this.onError(error instanceof Error ? error : new Error(String(error)));
      }
    },
    resume: () => {
      try {
        this.assertAdsManager().resume();
      } catch (error) {
        if (!this.onError) return;
        this.onError(error instanceof Error ? error : new Error(String(error)));
      }
    },
    pause: () => {
      try {
        this.assertAdsManager().pause();
      } catch (error) {
        if (!this.onError) return;
        this.onError(error instanceof Error ? error : new Error(String(error)));
      }
    },
    volume: (volume: number) => {
      try {
        this.assertAdsManager().setVolume(volume);
      } catch (error) {
        if (!this.onError) return;
        this.onError(error instanceof Error ? error : new Error(String(error)));
      }
    },
    replay: () => {
      try {
        this.destroy();
        this.resetState();
        this.buildAdDisplayContainer();
      } catch (error) {
        if (!this.onError) return;
        this.onError(error instanceof Error ? error : new Error(String(error)));
      }
    }
  };

  public destroy = (): void => {
    if (this.adsManager) {
      removeAdsManagerListeners(this.adsManager, this._state, this.onClick, this.onError);
      this.adsManager.destroy();
    }
    this.adDisplayContainer?.destroy();
    this.adsLoader?.destroy();
  };

  public get vpaid(): boolean | undefined {
    return this._state.vpaid.value;
  }
}
