import { setupHeavyAdInterventionObserver } from '@web-rendering/groundcontrol-utils';
import AdUnitComponent from '@web-rendering/groundcontrol-ad-unit/components/ad-unit/ad-unit.component';
import type { ButlerResponse } from '@web-rendering/groundcontrol-shared-types';
import type { ProviderWithProps } from '@web-rendering/groundcontrol-core';
import {
  ConfigurationProvider,
  getAdIdentifiers,
  LifecycleScopeProvider,
  PayloadProvider,
  registerAdLifecycle,
  TrackerServiceProvider,
  type InitOptions,
  type Payload
} from '@web-rendering/groundcontrol-core';
import { resolveEqtDco } from '@web-rendering/groundcontrol-eqt';
import { reportError } from '@web-rendering/groundcontrol-monitoring';
import { Lifecycle } from '@web-rendering/groundcontrol-shared-types/lifecycle/lifecycle';
import { LifecycleStage } from '@web-rendering/groundcontrol-shared-types/lifecycle/lifecycle-stage';
import { setRenderStart } from '@web-rendering/groundcontrol-store';
import {
  extractEqtExchangeMetadata,
  getRawPayload,
  isTestEnvironment,
  iterateAndObserveEquativTrackersPerformanceEntries,
  observeFirstPartyEquativTrackersPerformanceEntries
} from '@web-rendering/groundcontrol-utils';
import './ad-unit.scss';
import '@web-rendering/groundcontrol-ad-unit/tag/models/ad-experiences/responsive.scss';
import '@web-rendering/groundcontrol-ad-unit/tag/models/ad-experiences/responsive.outstream.scss';

const renderAdExperience = (
  placeholder: Element,
  response: ButlerResponse | null,
  payload: Payload,
  options: InitOptions,
  lifecycle: Lifecycle
): void => {
  const renderService = options.renderService;

  /* eslint-disable-next-line @typescript-eslint/no-explicit-any */
  const providers: ProviderWithProps<any>[] = [
    [ConfigurationProvider, { configuration: options.configurationService }],
    [PayloadProvider, { payload }],
    [TrackerServiceProvider, { id: payload.id, trackerService: options.trackerService }],
    [LifecycleScopeProvider, { scope: lifecycle }]
  ];
  renderService?.render(response, payload, placeholder, providers, AdUnitComponent, lifecycle);
};

const bootAd = async (placeholder: HTMLElement, options: InitOptions): Promise<void> => {
  const exchangeMetadata = extractEqtExchangeMetadata(placeholder) ?? {};
  const lifecycle = new Lifecycle(LifecycleStage.Placeholder);

  const id = placeholder.getAttribute('data-gc-id') ?? placeholder.getAttribute('data-stx-response-name');
  if (!id) {
    reportError(new Error('Missing data-gc-id or data-stx-response-name attribute'), {
      scope: lifecycle,
      context: 'tag/ad:bootAd/missing response name',
      placeholderAttributes: placeholder.dataset || 'missing',
      ...exchangeMetadata
    });

    return;
  }

  lifecycle.identify({ id });
  lifecycle.enter(LifecycleStage.Payload);

  let payload: Payload | null = null;
  try {
    setRenderStart();

    const rawPayload = getRawPayload(id, lifecycle);

    payload = options.payloadService.initialize(rawPayload, lifecycle);
    lifecycle.identify(getAdIdentifiers(payload));
    registerAdLifecycle(payload.id, lifecycle);

    // Heavy Ad Intervention fires long after this, so the observer keeps the creative stage it watches.
    setupHeavyAdInterventionObserver(id, placeholder, options.trackerService, lifecycle.track(LifecycleStage.Creative));
    options.trackerService.mergeMetadata({
      payload
    });

    if (isTestEnvironment()) {
      iterateAndObserveEquativTrackersPerformanceEntries(payload);
      observeFirstPartyEquativTrackersPerformanceEntries();
    }
  } catch (e) {
    if (e instanceof Error) {
      reportError(e, {
        scope: lifecycle,
        context: 'tag/ad:bootAd/fetch ad',
        id: id,
        payload,
        placeholderAttributes: placeholder.dataset || 'missing',
        ...exchangeMetadata
      });
    }
    return;
  }

  if (payload.creative.assetsurl) {
    lifecycle.enter(LifecycleStage.Assets);
    await resolveEqtDco(payload, lifecycle);
  }

  options.trackerService.trackImpressionReceived();

  lifecycle.enter(LifecycleStage.Creative);
  try {
    renderAdExperience(placeholder, null, payload, options, lifecycle);
  } catch (e) {
    if (e instanceof Error) {
      reportError(e, {
        scope: lifecycle,
        context: 'tag/ad:bootAd/ad rendering',
        payload,
        ...exchangeMetadata
      });
    }
  }
};

/* eslint-disable-next-line @typescript-eslint/no-explicit-any */
(window as any).bootAd = bootAd;

export default bootAd;
