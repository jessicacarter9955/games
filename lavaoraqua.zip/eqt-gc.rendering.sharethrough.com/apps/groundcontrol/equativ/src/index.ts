import type { InitOptions } from '@web-rendering/groundcontrol-core';
import { trackerService } from '@web-rendering/groundcontrol-core';
import { reportError } from '@web-rendering/groundcontrol-monitoring';
import { Lifecycle } from '@web-rendering/groundcontrol-shared-types/lifecycle/lifecycle';
import { LifecycleStage } from '@web-rendering/groundcontrol-shared-types/lifecycle/lifecycle-stage';
import { bootEquativPlaceholders, getGcDataset, queryParamsIncludes } from '@web-rendering/groundcontrol-utils';

import bootAd from './ad';

const setup = (options: InitOptions): void => {
  if (window.STR) return;
  window.STR = {
    debug: queryParamsIncludes('str_debug'),
    Tag: {
      boot: () => boot(options),
      singleAdBoot: () => console.log('singleAdBoot is not available in Equativ GroundControl instance')
    },
    Uid: {
      xandr: '',
      criteo: '',
      ttd: ''
    }
  };
};

// Errors before any ad exists (starting gc.js, the boot scan) belong to the GC instance, not to an ad.
const bootLifecycle = new Lifecycle(LifecycleStage.Load);

const boot = (options: InitOptions): Promise<void> => bootEquativPlaceholders(options, bootAd, bootLifecycle);

const main = async (options: InitOptions) => {
  setup(options);

  try {
    await boot(options);
  } catch (error) {
    if (error instanceof Error || typeof error === 'string') {
      reportError(error, {
        scope: bootLifecycle,
        function: 'tag/index:main'
      });
      console.error(error);
    }
  }
};

const gc = (options: InitOptions) => {
  let trackerBaseUrl = '';

  try {
    const gcDiv = document.querySelector<HTMLElement>('[data-gc-payload]');
    if (gcDiv) {
      const gcDataset = getGcDataset(gcDiv);
      trackerBaseUrl = gcDataset.trackerBaseUrl;
    } else {
      // Fallback to legacy window global
      trackerBaseUrl = window['tracker_base_url'];
    }
  } catch {
    // Fallback to legacy window global
    trackerBaseUrl = window['tracker_base_url'];
  }

  options.trackerService.trackGroundControlLoaded({
    env: 'eqt',
    trackerBaseUrl
  });

  trackerService.value = options.trackerService;

  try {
    /* eslint-disable-next-line @typescript-eslint/no-explicit-any */
    if ((document as any).attachEvent ? document.readyState === 'complete' : document.readyState !== 'loading') {
      main(options);
    } else {
      document.addEventListener('DOMContentLoaded', () => main(options));
    }
  } catch (error) {
    if (error instanceof Error || typeof error === 'string') {
      reportError(error, {
        scope: bootLifecycle,
        function: 'tag/index:gc'
      });
    }
  }
};

export default gc;
