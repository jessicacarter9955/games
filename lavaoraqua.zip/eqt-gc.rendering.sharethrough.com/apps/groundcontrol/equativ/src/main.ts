import { EnhancementService, RenderService } from '@web-rendering/groundcontrol-core';
import gc from './index';
import { EqtBeaconService, EqtConfigurationSettings, EquativPayloadService } from '@web-rendering/groundcontrol-eqt';
import '@web-rendering/groundcontrol-ad-unit/tag/models/common/template/enhanced/content/register-all-enhancements';

gc({
  payloadService: new EquativPayloadService(),
  trackerService: new EqtBeaconService(),
  configurationService: new EqtConfigurationSettings(),
  renderService: new RenderService(undefined),
  enhancementService: new EnhancementService(undefined)
});
