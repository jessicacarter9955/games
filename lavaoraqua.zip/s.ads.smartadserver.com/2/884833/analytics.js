(function () {
  var ozoki_tc = "BJZtcSwBhA-zu_JY",
    ozoki_os = "s.ads.smartadserver.com",
    ozoki_url =
      "https://s.ads.smartadserver.com/2/884833/analytics.js?dt\u003D8848331610101564891000\u0026di\u003Dcrazygames.com\u0026ui\u003D1471314912989038426\u0026md\u003D1\u0026ap\u003D\u0026sr\u003Dsmartadserver.com\u0026pp\u003D3888\u0026ti\u003D7e56ba4dce71459595b433bda0c04423\u0026de\u003D2\u0026to\u003D3\u0026pv\u003D97f2e34c-1ab5-4122-9607-a6925f07ba24\u0026si\u003D-1\u0026c1\u003D\u0026c2\u003D055698da-1401-4a86-9fc4-fa6aa490e9af\u0026c3\u003D0\u0026c4\u003D-1\u0026c5\u003D-1\u0026c6\u003Dtrue\u0026ci\u003D884833",
    ozoki_ct = {
      si: "-1",
      c1: "",
      c3: "0",
      c4: "-1",
      c5: "-1",
      dt: "8848331610101564891000",
      ui: "1471314912989038426",
      sr: "smartadserver.com",
      pv: "97f2e34c-1ab5-4122-9607-a6925f07ba24",
      c2: "055698da-1401-4a86-9fc4-fa6aa490e9af",
      di: "crazygames.com",
      md: "1",
      pp: "3888",
      de: "2",
      ci: "884833",
      ap: "",
      c6: true,
      ti: "7e56ba4dce71459595b433bda0c04423",
      to: "3",
    },
    ozoki_cf = 1,
    ozoki_sav = 1,
    ozoki_opt = {
      sm: 0.4069,
      tsm: 0.7119,
      chrext: 1,
      prb: 1,
      cpl: 1,
      bwk: 1,
      nvl: 1,
      ndm: 1,
      ecm: 1,
      wor: 1,
      hco: 1,
      dup: 1,
    };
  var PAGESPEED_VERSION = "2.229.0";
  !(function () {
    var o = function () {},
      n = "undefined" != typeof window ? window : null,
      i = null !== n ? n.document : null,
      t = encodeURIComponent,
      e = Date.now,
      f = JSON.stringify;
    function c(o) {
      !(function t() {
        i.body ? i.body.appendChild(o) : n.setTimeout(t, 4);
      })();
    }
    try {
      var u = Date.now();
      "undefined" == typeof ozoki_cf && (ozoki_cf = 0),
        "undefined" == typeof ozoki_sav && (ozoki_sav = 1),
        (function (n, u, r, s) {
          void 0 === r && (r = ""), void 0 === s && (s = !1);
          var a,
            _ = u.PAGESPEED_VERSION,
            k = u.ozoki_url,
            z = u.ozoki_os,
            d = u.ozoki_tc,
            p = u.ozoki_ct,
            v = u.ozoki_opt,
            l = u.ozoki_cf,
            m = u.ozoki_sav,
            E = u.ozoki_fsm,
            y = k.substr(0, k.indexOf(":")),
            S = y + "://" + z + "/2",
            x = S + "/" + p.ci + "/" + d,
            I = (function (o, n, i, t, e, f, c, u) {
              var r, s;
              if (t) s = t;
              else if (1 === e) {
                var a = void 0 === f ? 1 : f;
                (r = "fss0" + a), (s = o + "://cadmus2.script.ac/s/fs0" + a);
              } else s = n + "/" + i;
              return {
                mainSrc: s + "/main.js" + (u.oz_cb ? "?cb=" + c : ""),
                bucket: r,
              };
            })(y, S, _, r, l, m, d, p),
            N = I.mainSrc,
            g = I.bucket,
            P = (function () {
              var o = "oz_pl=1";
              for (var n in p)
                p.hasOwnProperty(n) && (o += "&" + t(n) + "=" + t(p[n]));
              return p.hasOwnProperty("psv") ? o : o + "&psv=" + _;
            })(),
            R =
              -1 !==
              (-1 !== (a = k.indexOf("?")) ? k.substring(0, a) : k).indexOf(
                "/vg.js"
              )
                ? "vg"
                : "postback",
            w = S + "/" + _ + "/" + p.ci + "/" + d + "/" + R + "?" + P;
          function O(n) {
            !(function (n) {
              try {
                var i = new XMLHttpRequest();
                i.open("POST", w + "&_x=1", !0),
                  (i.withCredentials = !1),
                  i.setRequestHeader("Content-Type", "text/plain"),
                  "function" == typeof i.overrideMimeType &&
                    i.overrideMimeType("text/plain"),
                  i.send(f(n));
              } catch (n) {
                o(n);
              }
            })({ loader: n });
          }
          if (
            ((o = function (o) {
              !(function (o) {
                if ("undefined" != typeof Image) {
                  var n = new Image();
                  (n.src = o),
                    (n.style.visibility = "hidden"),
                    (n.style.width = "1px"),
                    (n.style.height = "1px"),
                    document.body && document.body.appendChild(n);
                }
              })(
                x +
                  "/y.gif?en=" +
                  t(o.name) +
                  "&em=" +
                  t(o.message) +
                  "&es=" +
                  t(o.stack) +
                  "&ets=" +
                  t(e()) +
                  "&" +
                  P
              );
            }),
            null !== i && (i[d] ? v.dup : ((i[d] = !0), 0)))
          )
            O({ sm: v.sm, init: 0, dup: !0 });
          else {
            O({ sm: v.sm, init: 1, bkt: g });
            var h,
              D,
              b,
              A,
              V,
              C,
              G,
              j,
              T = e(),
              U = i.createElement("script"),
              q = {
                PAGESPEED_VERSION: _,
                API_VERSION: "2",
                is_vast: !(!p.vver || !p.vs),
                ozoki_st: n,
                ozoki_os: z,
                ozoki_url: k,
                ozoki_tc: d,
                ozoki_ct: p,
                ozoki_opt: v,
                ozoki_mn: N,
                ozoki_onf: U.onfocus,
              },
              H =
                ((D = (h = N).indexOf(".") + 1),
                (b = h.substring(D, D + 8)),
                isNaN(b) ? b : h.substring(0, 8)),
              J = (function (o) {
                var n = o.indexOf(".") + 1,
                  i = o.substring(n, n + 1);
                return isNaN(i) ? i : o.substring(0, 1);
              })(N),
              L = q.ozoki_onf,
              M = function (o) {
                return o ? L && L.call(this, o) : M;
              };
            (M.toString = function () {
              return L + "";
            }),
              (M[J] = function (o) {
                return o == H ? q : void 0;
              }),
              (U.onload = function () {
                return O({ load: e() - T });
              }),
              (U.onerror = function () {
                return O({ error: e() - T });
              }),
              (U.onfocus = M),
              (U.src = N),
              s &&
                ((U.integrity =
                  "sha256-jrTxeYl/1a7GFQFSPI+jPqzU5Jx7qWGTs8Aymf0Trto="),
                (U.crossOrigin = "anonymous")),
              c(U),
              1 !== l ||
                (0 !== E && 1 !== E) ||
                (function (o) {
                  if (o) {
                    var n = i.createElement("script");
                    (n.src = o), (n.async = !0), c(n);
                  }
                })(
                  ((A = k),
                  (V = String(p.ci)),
                  (C = 1 === E),
                  (G = d),
                  -1 ===
                  (j = (j = decodeURIComponent(A)).replace(
                    new RegExp(V, "g"),
                    "999" + V
                  )).indexOf("?")
                    ? null
                    : j + "&fsm=" + (C ? "1" : "0") + "&ptc=" + t(G))
                );
          }
        })(u, {
          PAGESPEED_VERSION: PAGESPEED_VERSION,
          ozoki_url: ozoki_url,
          ozoki_os: ozoki_os,
          ozoki_tc: ozoki_tc,
          ozoki_ct: ozoki_ct,
          ozoki_opt: ozoki_opt,
          ozoki_cf: ozoki_cf,
          ozoki_sav: ozoki_sav,
          ozoki_fsm: "undefined" != typeof ozoki_fsm ? ozoki_fsm : void 0,
        });
    } catch (n) {
      o(n);
    }
  })();
})();
