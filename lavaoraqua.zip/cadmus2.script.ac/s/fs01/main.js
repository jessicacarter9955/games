(function () {
  if (typeof globalThis === "object") return;
  Object.defineProperty(Object.prototype, "__magic__", {
    get: function () {
      return this;
    },
    configurable: true,
  });
  __magic__.globalThis = __magic__;
  delete Object.prototype.__magic__;
})();
(function (g) {
  var f = String.fromCharCode;
  function Zt(str) {
    var n = str.length,
      n3 = n - 3,
      o = "",
      i = 0;
    for (; i < n3; i += 4) {
      o +=
        f(str.charCodeAt(i) ^ 18) +
        f(str.charCodeAt(i + 1) ^ 14) +
        f(str.charCodeAt(i + 2) ^ 12) +
        f(str.charCodeAt(i + 3) ^ 18);
    }
    i < n && (o += f(str.charCodeAt(i++) ^ 18));
    i < n && (o += f(str.charCodeAt(i++) ^ 14));
    i < n && (o += f(str.charCodeAt(i++) ^ 12));
    return o;
  }
  g.Zt = Zt;
})(
  (function () {
    try {
      return globalThis;
    } catch (e) {}
    return Function("return this")();
  })()
);
function t(t) {
  var n = (function (t, n) {
    if (Zt("}lfwqz") != typeof t || !t) return t;
    var i = t[Symbol.toPrimitive];
    if (void 0 !== i) {
      var r = i.call(t, n || Zt("vkjsgbx"));
      if (Zt("}lfwqz") != typeof r) return r;
      throw new TypeError(
        Zt("RNx}B|e\x7f{zedw.agaz,`wzy`|.m2b|e\x7f{zedw.zs~{i<")
      );
    }
    return (Zt("az~{|i") === n ? String : Number)(t);
  })(t, Zt("az~{|i"));
  return Zt("awap}b") == typeof n ? n : n + "";
}
!(function (n, i, r) {
  var o,
    a,
    e,
    f =
      ((o =
        typeof Uint16Array === Zt("t{bqfgc|")
          ? function (t) {
              return new Uint16Array(t);
            }
          : function (t) {
              return new Array(t);
            }),
      (a = function (t) {
        return t.replace(/[wxyz'"\\\%]/g, function (t) {
          return {
            w: "'",
            x: '"',
            y: "%",
            z: "\\",
            "'": "w",
            '"': "x",
            "%": "y",
            "\\": "z",
          }[t];
        });
      }),
      (e = function (t, n, i) {
        var r,
          o,
          a,
          e = [0, 0, 0, 0, 0];
        for (r = 0; r < n; r += 2) {
          for (a = (((t[r] << 16) >>> 0) + t[r + 1]) >>> 0, o = 0; o < 5; ++o)
            (e[o] = (a % 85) + 33), (a = (a / 85) >>> 0);
          i.push(String.fromCharCode(e[4], e[3], e[2], e[1], e[0]));
        }
      }),
      {
        encode: function (t) {
          var n = [],
            i = t.length % 2,
            r = t.length - i;
          if ((e(t, r, n), i)) {
            e([t[r], 0], 2, n);
            var o = n.pop();
            n.push(o.substr(0, i + 2));
          }
          return a(n.join(""));
        },
        decode: function (t) {
          var n,
            i,
            r,
            e,
            f,
            u = (t = a(t)).length,
            c = [0, 0, 0, 0, 0],
            Z = o(2 * Math.ceil(u / 5));
          for (f = n = 0; n < u; n += 5) {
            for (i = 0; i < 5; ++i) c[i] = t.charCodeAt(n + i) - 33;
            if ((e = u - n) < 5) {
              for (i = e; i < 5; ++i) c[i] = 0;
              c[e] = 85;
            }
            (r = 85 * (85 * (85 * (85 * c[0] + c[1]) + c[2]) + c[3]) + c[4]),
              (Z[f++] = r >>> 16),
              (Z[f++] = 65535 & r);
          }
          return (
            u % 5 &&
              (Z instanceof Array
                ? Z.pop()
                : (Z = Z.subarray(0, Z.length - 1))),
            Z
          );
        },
      }),
    u = (function () {
      function t() {
        this.cache = void 0;
      }
      var n = t.prototype;
      return (
        (n.cssCheck = function () {
          var t,
            n,
            i = {},
            r = document.createElement(Zt("eo``g}"));
          for (n in r.style)
            (t = (/^([A-Za-z][a-z]*)[A-Z]/.exec(n) || [])[1]) &&
              ((t = t.toLowerCase()) in i ? i[t]++ : (i[t] = 1));
          return { prefixes: i };
        }),
        (n.guess = function () {
          var t,
            n = { trident: 0, gecko: 0, presto: 0, webkit: 0, unknown: -1 },
            i = Zt("g`g|}yb"),
            r = [],
            o = this.cssCheck();
          for (t in o.prefixes) r.push([t, o.prefixes[t]]);
          for (
            var a = r
                .sort(function (t, n) {
                  return n[1] - t[1];
                })
                .slice(0, 10),
              e = 0,
              f = Zt("\x7fav"),
              u = Zt("ukx"),
              c = Zt("ekny{z");
            e < a.length;
            ++e
          )
            (t = a[e][0]) === f && (n.gecko += 5),
              "ms" === t && (n.trident += 5),
              t === u && n.webkit++,
              t === c && (n.webkit += 5),
              "o" === t && (n.presto += 2),
              "xv" === t && (n.presto += 2);
          window[Zt("}`dw~~")] && n.trident++,
            window[Zt("\x7fotQ}`bwqze}|}\\w`]i`dk~")] && n.trident++;
          try {
            void 0 !== window.ActiveXObject.toString && (n.trident += 5);
          } catch (t) {}
          for (t in (void 0 !== function () {}.toSource && (n.gecko += 5), n))
            n[t] > n[i] && (i = t);
          return i;
        }),
        (n.VI = function () {
          return this.cache || (this.cache = this.guess()), this.cache;
        }),
        t
      );
    })(),
    c = (function () {
      function t() {}
      return (
        (t.QX = function (t) {
          return void 0 !== t;
        }),
        (t.mR = function (t) {
          return typeof {} == typeof t;
        }),
        (t.da = function (t, n, i, r, o, a, e) {
          try {
            Object.defineProperty(t, n, {
              value: i,
              writable: r,
              enumerable: o,
              configurable: a,
            }),
              e && Object.freeze && Object.freeze(e);
          } catch (r) {
            t[n] = i;
          }
        }),
        (t.Xu = function (n) {
          return t.QX(window.Uint8Array)
            ? new window.Uint8Array(n)
            : new Array(n);
        }),
        (t.bd = function (t) {
          return t instanceof Array ? t.slice() : new t.constructor(t);
        }),
        (t.clone = function (t) {
          return [void 0, null].indexOf(t) > -1 || t != t
            ? t
            : JSON.parse(JSON.stringify(t));
        }),
        (t.zn = function (t, n) {
          for (var i = 0; i < t.length; i++) if (t[i] === n) return !0;
          return !1;
        }),
        (t.uN = function (t, n) {
          var i = n.length,
            r = 0,
            o = t;
          try {
            for (; r < i; ++r) {
              if (typeof o !== Zt("}lfwqz")) return;
              o = o[n[r]];
            }
            return o;
          } catch (t) {}
        }),
        (t.hV = function (t, n) {
          return (function t(n, i, r) {
            for (var o = Object.keys(n), a = 0; a < o.length; ++a)
              r[o[a]] = n[o[a]];
            for (var e = Object.keys(i), f = 0; f < e.length; ++f) {
              var u = e[f];
              r[u] && typeof i[u] === Zt("}lfwqz")
                ? r[u] instanceof Array && i[u] instanceof Array
                  ? (r[u] = r[u].concat(i[u]))
                  : typeof r[u] === Zt("}lfwqz") &&
                    typeof i[u] === Zt("}lfwqz") &&
                    (r[u] = t(r[u], i[u], r[u]))
                : (r[u] = i[u]);
            }
            return r;
          })(t, n, {});
        }),
        (t.Kd = function (t, n, i) {
          t.hasOwnProperty(n) || (t[n] = []), t[n].push(i);
        }),
        (t.Mz = function (t) {
          var n = {};
          for (var i in t) null !== t[i] && void 0 !== t[i] && (n[i] = t[i]);
          return n;
        }),
        (t.mi = function (n) {
          var i = {};
          if (null != n)
            for (var r in n)
              switch (typeof n[r]) {
                case Zt("g`hwtgbwv"):
                  break;
                case Zt("az~{|i"):
                case Zt("|{apw|"):
                case Zt("pac~wob"):
                  i[r] = n[r];
                  break;
                case Zt("t{bqfgc|"):
                  i[r] = rt.IO.TU(n[r]);
                  break;
                case Zt("}lfwqz"):
                  i[r] = t.mi(n[r]);
              }
          return i;
        }),
        t
      );
    })(),
    Z = (function () {
      function t() {
        (this.guess = new u()), (this.cache = { version: {} });
      }
      t.KV = function () {
        return t._instance || (t._instance = new t()), t._instance;
      };
      var n = t.prototype;
      return (
        (n.isGecko = function () {
          return this.guess.VI() == Zt("ukoy}");
        }),
        (n.PC = function () {
          return this.guess.VI() == Zt("f|evw`x");
        }),
        (n.VI = function () {
          return this.guess.VI();
        }),
        (n.iD = function () {
          return this.guess.VI() == Zt("ekny{z");
        }),
        (n.isPresto = function () {
          return Zt("}~i`s") in window;
        }),
        (n.isSafari = function () {
          return (
            c.QX(this.cache.safari) ||
              (this.cache.safari =
                navigator.userAgent.indexOf(Zt("Aojs`g")) > -1 &&
                this.iD() &&
                navigator.vendor.indexOf(Zt("S~|~w")) > -1),
            this.cache.safari
          );
        }),
        (n.isFirefox = function () {
          return (
            c.QX(this.cache.firefox) ||
              (this.cache.firefox =
                navigator.userAgent.indexOf(Zt("Tg~wtat")) > -1 &&
                this.isGecko()),
            this.cache.firefox
          );
        }),
        (n.isFirefoxIOS = function () {
          return (
            c.QX(this.cache.firefoxIos) ||
              (this.cache.firefoxIos =
                navigator.userAgent.indexOf(Zt("Tve]A")) > -1 &&
                navigator.userAgent.indexOf(Zt("Ukoy}")) > -1),
            this.cache.firefoxIos
          );
        }),
        (n.isFirefoxMobile = function () {
          if (!c.QX(this.cache.firefoxMobile)) {
            var t = navigator.userAgent.match(/mobi|tablet/i);
            (this.cache.firefoxMobile =
              t && navigator.userAgent.indexOf(Zt("Ukoy}")) > -1),
              (this.cache.firefoxMobile =
                navigator.userAgent.indexOf(Zt("Tve]A")) > -1 &&
                navigator.userAgent.indexOf(Zt("Ukoy}")) > -1);
          }
          return this.cache.firefoxMobile;
        }),
        (n.QI = function () {
          return (
            c.QX(this.cache.chrome) ||
              (this.cache.chrome =
                void 0 !== window.chrome &&
                navigator.vendor != Zt("]~i`s._}tz{s`k,SAO") &&
                void 0 === navigator.msLaunchUri &&
                -1 === navigator.userAgent.indexOf(Zt("Wjk=")) &&
                -1 === navigator.userAgent.indexOf(Zt("Wjkw=")) &&
                this.iD()),
            this.cache.chrome
          );
        }),
        (n.isBlink = function () {
          if (!c.QX(this.cache.blink)) {
            var t = document.createElement(Zt("{`|gf"));
            (t.type = Zt("ekiy")),
              (this.cache.blink =
                t.type === Zt("ekiy") &&
                !(Zt("\x7fav[|`i`Am~ww`T") in window) &&
                !(Zt("S~|~w^mkW|~}`") in window));
          }
          return this.cache.blink;
        }),
        (n.isQQ = function () {
          return (
            c.QX(this.cache.qq) ||
              (this.cache.qq =
                Zt("clSwjzi`|o`") in window || Zt("clS\x7f{`ed{ji}") in window),
            this.cache.qq
          );
        }),
        (n.isEdge = function () {
          return (
            c.QX(this.cache.edge) ||
              (this.cache.edge =
                void 0 !== window.chrome &&
                (-1 !== navigator.userAgent.indexOf(Zt("Wjk=")) ||
                  -1 !== navigator.userAgent.indexOf(Zt("Wjkw="))) &&
                this.isBlink()),
            this.cache.edge
          );
        }),
        (n.isBrave = function () {
          return (
            c.QX(this.cache.brave) ||
              (this.cache.brave = !(
                !window.navigator[Zt("p|mdw")] ||
                typeof window.navigator[Zt("p|mdw")][Zt("{}N`sxi")] !==
                  Zt("t{bqfgc|")
              )),
            this.cache.brave
          );
        }),
        (n.guessWebOC = function () {
          return !(
            !this.PC() ||
            (window.external &&
              typeof window.external[Zt("SjhAwo~qz^~}dghw`")] !==
                Zt("g`hwtgbwv") &&
              typeof window.external[Zt("MvSkktv")] === Zt("g`hwtgbwv"))
          );
        }),
        (n.isWebOc = function () {
          return (
            c.QX(this.cache.webOc) || (this.cache.webOc = this.guessWebOC()),
            this.cache.webOc
          );
        }),
        (n.isWin8 = function () {
          return (
            c.QX(this.cache.win8) ||
              (this.cache.win8 = null != window.MSGesture && this.PC()),
            this.cache.win8
          );
        }),
        (n.isIos = function () {
          return (
            c.QX(this.cache.ios) ||
              (this.cache.ios =
                /iPad|iPhone|iPod/.test(navigator.userAgent) &&
                !window[Zt("_]_f`km\x7f")]),
            this.cache.ios
          );
        }),
        (n.iosWebViewType = function () {
          if (!c.QX(this.cache.iosWebviewType) && this.isIosWebView()) {
            var t = navigator.userAgent,
              n = /constructor/i.test(window[Zt("ZZA^Wbi\x7fw`x")]),
              i = !!window.indexedDB,
              r = window[Zt("ekny{z")],
              o = r ? r.messageHandlers : void 0;
            -1 !== t.indexOf(Zt("Aojs`g")) && -1 !== t.indexOf(Zt("Dk~a{ab"))
              ? (this.cache.iosWebviewType = "sf")
              : (!i && n) || !window.statusbar.visible
              ? (this.cache.iosWebviewType = "ui")
              : (this.cache.iosWebviewType = (r && o) || !n || i ? "wk" : null);
          }
          return this.cache.iosWebviewType;
        }),
        (n.isIosWebView = function () {
          if (!c.QX(this.cache.iosWebview)) {
            var t = navigator.userAgent;
            (this.cache.iosWebview = !1),
              -1 === t.indexOf(Zt("Q|e}]]")) &&
                this.isIos() &&
                !this.isFirefoxIOS() &&
                (this.cache.iosWebview = !0);
          }
          return this.cache.iosWebview;
        }),
        (n.isAndroidOs = function () {
          return (
            c.QX(this.cache.androidOs) ||
              (this.cache.androidOs =
                navigator.userAgent.indexOf(Zt("S`h`}gh")) > -1),
            this.cache.androidOs
          );
        }),
        (n.isMobile = function () {
          return (
            c.QX(this.cache.mobile) ||
              (this.cache.mobile =
                Zt("}|ew|zmf{ab") in window ||
                (this.PC() && !(Zt("b|c\x7fbz") in window)) ||
                (this.isFirefoxMobile() &&
                  Zt("}`x}gmdafo~f") in document.documentElement) ||
                Zt("}~i`sce|{") in window ||
                Zt("}~i`sce|{Q\x7fws|ozW`k{|k\x7fB`gzsfk") in window ||
                (this.isPresto() &&
                  Zt("`kbvw|e|uCcvw") in window[Zt("}~i`s")] &&
                  !(Zt("ukxGak~_wjes") in navigator))),
            this.cache.mobile
          );
        }),
        (n.Ac = function () {
          return (
            c.QX(this.cache.webview) ||
              (!this.isAndroidOs() ||
              navigator.userAgent.match(
                /Firefox|MxBrowser|UCBrowser|OPR|Opera/
              ) ||
              void 0 !== window[Zt("va`bzgb")]
                ? (this.cache.webview = !1)
                : (this.cache.webview = !c.QX(
                    window[Zt("ekny{z^wc{iafHe~w]uafka")]
                  ))),
            this.cache.webview
          );
        }),
        (n.isOpera = function () {
          return (
            c.QX(this.cache.opera) ||
              (this.cache.opera =
                (this.iD() &&
                  typeof window[Zt("}`cbw|mvwzmqzkhd{k{qzobuw")] ===
                    Zt("}lfwqz")) ||
                -1 !== navigator.userAgent.indexOf(Zt("]~i`s")) ||
                -1 !== navigator.userAgent.indexOf(Zt("]^^"))),
            this.cache.opera
          );
        }),
        (n.isMobileWebExperience = function () {
          return (
            c.QX(this.cache.isMobileWebExperience) ||
              (this.cache.isMobileWebExperience = !!navigator.userAgent.match(
                /FBAV|FBAN|Instagram|Pinterest|CriOS|FxiOS|GSA/
              )),
            this.cache.isMobileWebExperience
          );
        }),
        (n.version = function (t) {
          var n = 0;
          switch (t) {
            case 1:
              n = this.ieVersion();
              break;
            case 5:
              n = this.ffVersion();
              break;
            case 2:
              n = this.safariVersion();
              break;
            case 0:
              n = this.chromeVersion();
              break;
            case 3:
              n = this.edgeVersion();
          }
          return n;
        }),
        (n.ieVersion = function () {
          if (!c.QX(this.cache.version.ie))
            if (((this.cache.version.ie = null), navigator.language))
              this.cache.version.ie = 11;
            else {
              var t = Function(
                Zt(
                  "f|u2i|ifg|b=8NoqMab2RQfaq|ebfQzw`}e}|.L8=5q2qoxqz.$wj',i`kxg``,\"o5"
                )
              )();
              t >= 9
                ? (this.cache.version.ie = t)
                : 5.8 == t
                ? (this.cache.version.ie = 8)
                : 5.7 == t && window.XMLHttpRequest
                ? (this.cache.version.ie = 7)
                : (this.cache.version.ie = 6);
            }
          return this.cache.version.ie;
        }),
        (n.ffVersion = function () {
          return (
            c.QX(this.cache.version.ff) ||
              (this.isFirefox()
                ? (this.cache.version.ff = this.extractVersionFromUA(
                    Zt("Tg~wtat")
                  ))
                : (this.cache.version.ff = null)),
            this.cache.version.ff
          );
        }),
        (n.safariVersion = function () {
          return (
            c.QX(this.cache.version.safari) ||
              (this.isSafari()
                ? (this.cache.version.safari = this.extractVersionFromUA(
                    Zt("Dk~a{ab")
                  ))
                : (this.cache.version.safari = null)),
            this.cache.version.safari
          );
        }),
        (n.chromeVersion = function () {
          return (
            c.QX(this.cache.version.chrome) ||
              ((this.cache.version.chrome = null),
              this.QI() &&
                (this.cache.version.chrome = this.extractVersionFromUA(
                  Zt("Qf~}\x7fk")
                ))),
            this.cache.version.chrome
          );
        }),
        (n.edgeVersion = function () {
          if (!c.QX(this.cache.version.edge))
            if (this.isEdge()) {
              var t = this.extractVersionFromUA(Zt("Wjk"));
              this.cache.version.edge =
                t > -1 ? t : this.extractVersionFromUA(Zt("Wjkw"));
            } else this.cache.version.edge = null;
          return this.cache.version.edge;
        }),
        (n.extractVersionFromUA = function (t) {
          var n = new RegExp(t + Zt('=&W"?7Q8; ')).exec(navigator.userAgent);
          return n ? Number(n[1]) : -1;
        }),
        t
      );
    })();
  Z._instance = void 0;
  var s = (function () {
      function t() {}
      return (
        (t.Nk = function () {}),
        (t.Xr = function (t) {
          return typeof Function == typeof t;
        }),
        t
      );
    })(),
    w = (function () {
      function t() {}
      return (
        (t.Ig = function (n, i, r, o) {
          if (
            (void 0 === o && (o = !1),
            typeof n.addEventListener !== Zt("t{bqfgc|"))
          )
            return s.Nk;
          var a = function (n) {
              r.call(t, n || window.event);
            },
            e = function () {
              try {
                n.removeEventListener(i, a, o);
              } catch (t) {}
            };
          return t.removerFns.push(e), n.addEventListener(i, a, o), e;
        }),
        (t.dettachAll = function () {
          for (var n = 0; n < t.removerFns.length; ++n)
            typeof t.removerFns[n] === Zt("t{bqfgc|") &&
              t.removerFns[n].call(t);
        }),
        t
      );
    })();
  w.removerFns = [];
  var v = (function () {
    function t() {}
    return (
      (t.subscribe = function (n, i) {
        var r = t.topics[n] || (t.topics[n] = []);
        return (
          r.push(i),
          function () {
            var t = r.indexOf(i);
            t > -1 && r.splice(t, 1);
          }
        );
      }),
      (t.notify = function (n) {
        for (var i = c.bd(t.topics[n] || []), r = 0; r < i.length; r++) i[r]();
      }),
      t
    );
  })();
  v.topics = {};
  var h = (function () {
    function t() {}
    return (
      (t.Ig = function (n, i) {
        t.pJ.push(i.bind(n));
      }),
      (t.sayGoodbye = function () {
        if (!t.ran) {
          (t.ran = !0), v.notify(2);
          for (var n = 0, i = t.pJ.length; n < i; n++) t.pJ[n]();
          v.notify(4);
        }
      }),
      (t.bestEffortInit = function (n) {
        t.cEvents.Ig(n, Zt("}`nwta~wg``}sj"), function () {
          return t.sayGoodbye();
        }),
          t.cEvents.Ig(n, Zt("pkj}`ky|~amv"), function () {
            return t.sayGoodbye();
          }),
          t.cEvents.Ig(n, Zt("}`y|~amv"), function () {
            return t.sayGoodbye();
          }),
          t.cEvents.Ig(n, Zt("bokwzghw"), function () {
            return t.sayGoodbye();
          });
      }),
      (t.completeInit = function (n) {
        Z.KV().QI() &&
          (t.cEvents.Ig(n, Zt("}`nwta~wg``}sj"), function () {
            return t.sayGoodbye();
          }),
          t.cEvents.Ig(n, Zt("pkj}`ky|~amv"), function () {
            return t.sayGoodbye();
          }));
      }),
      t
    );
  })();
  (h.pJ = []), (h.ran = !1), (h.cEvents = w);
  var l,
    b = (function () {
      function t() {
        this.di = Object.keys || this.fillKeys;
      }
      var n = t.prototype;
      return (
        (n.sB = function (t) {
          var n,
            i,
            r,
            o,
            a,
            e,
            f,
            u,
            c,
            Z = {};
          try {
            for (i = 0, a = t.length; i < a; i++) Z[(n = t[i])] = 1;
          } catch (t) {}
          try {
            for (n in t) Z[n] = 1;
          } catch (t) {}
          try {
            for (
              u = Object.getOwnPropertyNames(t), r = 0, e = u.length;
              r < e;
              r++
            )
              Z[(n = u[r])] = 1;
          } catch (t) {}
          try {
            for (c = this.di(t), o = 0, f = c.length; o < f; o++)
              Z[(n = c[o])] = 1;
          } catch (t) {}
          return this.di(Z);
        }),
        (n.fillKeys = function (t) {
          var n = [];
          for (var i in t) n.hasOwnProperty.call(t, i) && n.push(i);
          return n;
        }),
        (n.map = function (t, n) {
          return (
            Array.prototype.map && Function.prototype.bind
              ? (this.map = Array.prototype.map.call.bind(Array.prototype.map))
              : (this.map = function (t, n) {
                  for (var i = t.length, r = new Array(i), o = 0; o < i; ++o)
                    r[o] = n(t[o]);
                  return r;
                }),
            this.map(t, n)
          );
        }),
        (n.BJ = function (t) {
          var n = {};
          return (
            c.QX(Object.getOwnPropertyDescriptors) &&
              (n = Object.getOwnPropertyDescriptors(t)),
            n
          );
        }),
        t
      );
    })(),
    d = function () {};
  (d.events = w),
    (d.object = new b()),
    (function (t) {
      (t[(t[Zt("@KBVW\\SPWIY\\")] = 1)] = Zt("@KBVW\\SPWIY\\")),
        (t[(t[Zt("SJST][BV")] = 2)] = Zt("SJST][BV")),
        (t[(t[Zt("]CEV")] = 3)] = Zt("]CEV")),
        (t[(t[Zt("D^M[VQMVMBCSVKH")] = 4)] = Zt("D^M[VQMVMBCSVKH")),
        (t[(t[Zt("D^M[VQMVMXEVWASAFO^F")] = 5)] = Zt("D^M[VQMVMXEVWASAFO^F")),
        (t[(t[Zt("DGIESLE^[ZUMBGZ")] = 6)] = Zt("DGIESLE^[ZUMBGZ"));
    })(l || (l = {}));
  var g,
    m = (function () {
      function t(t) {
        (this.start = void 0),
          (this.uC = {}),
          (this.start = void 0 !== t ? t : Date.now());
      }
      var n = t.prototype;
      return (
        (n.pageLoaded = function () {
          return this.start;
        }),
        (n.diff = function (t) {
          return void 0 === t && (t = Date.now()), t - this.start;
        }),
        (n.interval = function (t, n, i) {
          for (
            var r = arguments.length, o = new Array(r > 3 ? r - 3 : 0), a = 3;
            a < r;
            a++
          )
            o[a - 3] = arguments[a];
          var e;
          i && void 0 !== i.name && (e = i.name);
          var f = window.setInterval(function () {
              t.apply(i, o);
            }, n),
            u = function () {
              window.clearInterval(f);
            };
          return e && (this.uC[e] || (this.uC[e] = []), this.uC[e].push(u)), u;
        }),
        (n.timeout = function (t, n, i) {
          void 0 === n && (n = 10);
          for (
            var r = arguments.length, o = new Array(r > 3 ? r - 3 : 0), a = 3;
            a < r;
            a++
          )
            o[a - 3] = arguments[a];
          var e;
          i && void 0 !== i.name && (e = i.name);
          var f = window.setTimeout(function () {
              t.apply(i, o);
            }, n),
            u = function () {
              window.clearTimeout(f);
            };
          return e && (this.uC[e] || (this.uC[e] = []), this.uC[e].push(u)), u;
        }),
        (n.eD = function () {
          for (var t = Object.keys(this.uC), n = t.length, i = 0; i < n; ++i)
            this.GM(t[i]);
        }),
        (n.GM = function (t) {
          if (this.uC[t]) {
            for (var n = this.uC[t], i = 0; i < n.length; ++i) n[i]();
            delete this.uC[t];
          }
        }),
        t
      );
    })();
  !(function (t) {
    var n,
      i,
      r = typeof window !== Zt("g`hwtgbwv") && Boolean(window.document),
      o = !r,
      a = r ? document : null,
      e = [];
    function f() {
      var t;
      o ||
        ((t = e),
        (o = !0) &&
          t.length &&
          ((e = []),
          (function (t) {
            var n;
            for (n = 0; n < t.length; n += 1) t[n](a);
          })(t)));
    }
    if (r) {
      if (document.addEventListener)
        document.addEventListener(Zt("VAAQ}`xw|z@}sjiv"), f, !1),
          window.addEventListener(Zt("~amv"), f, !1);
      else if (window.attachEvent) {
        window.attachEvent(Zt("}``}sj"), f),
          (i = document.createElement(Zt("vgz")));
        try {
          n = null === window.frameElement;
        } catch (t) {}
        i.doScroll &&
          n &&
          window.external &&
          new m().timeout(function () {
            try {
              i.doScroll(), f();
            } catch (t) {}
          }, 30);
      }
      document.readyState === Zt("qaab~kxw") && f();
    }
    (t.dV = function t(n) {
      return o ? n(a) : e.push(n), t;
    }),
      Zt("  <<#");
  })(g || (g = {}));
  var k = (function () {
    function t() {}
    return (
      (t.TU = function (t) {
        return (typeof t === Zt("t{bqfgc|") ? function () {} : {})[
          Zt("fa_") + Zt("az~{|i").substr(1)
        ].call(t);
      }),
      (t.Ft = function (t, n) {
        return t.substr(0, n.length) === n;
      }),
      (t.iX = function (t, n) {
        for (var i = 5381, r = t.length, o = 0; o < r; o++)
          i = ((i << 5) + i) ^ t.charCodeAt(o);
        return n ? (Zt('"><""') + (i >>> 0).toString(32)).substr(-n) : i >>> 0;
      }),
      (t.jL = function (t) {
        return t.replace(/[-\/\\^$*+?.()|[\]{}]/g, Zt("N**"));
      }),
      (t.Dr = function (n, i) {
        for (var r in i)
          i.hasOwnProperty(r) &&
            (n = n.replace(new RegExp(t.jL("{" + r + "}"), "g"), i[r]));
        return n;
      }),
      (t.CF = function (t, n) {
        return t.slice(-n.length) == n;
      }),
      (t.Ir = function (t) {
        try {
          return btoa(
            encodeURIComponent(t).replace(/%([0-9A-F]{2})/g, function (t, n) {
              return String.fromCharCode(parseInt(n, 16));
            })
          );
        } catch (n) {
          return t;
        }
      }),
      (t.kD = function (t) {
        try {
          return decodeURIComponent(escape(atob(t)));
        } catch (n) {
          return t;
        }
      }),
      (t.Xl = function (n, i) {
        var r;
        if ((void 0 === i && (i = 3), Array.isArray(n))) r = n;
        else {
          var o = n.length;
          if (o < i) return t.iX(n);
          r = [];
          for (var a = 0; a <= o - i; a++) r.push(n.substr(a, i));
        }
        if (0 === r.length) return 0;
        for (var e = [], f = 0; f < 32; f++) e[f] = 0;
        for (var u = 0; u < r.length; u++)
          for (var c = t.iX(r[u]), Z = 0; Z < 32; Z++)
            e[Z] += c & (1 << Z) ? 1 : -1;
        for (var s = 0, w = 0; w < 32; w++) e[w] > 0 && (s |= 1 << w);
        return s >>> 0;
      }),
      t
    );
  })();
  k.fromCharCode = String.fromCharCode;
  var z = (function () {
    function t() {}
    return (
      (t.IG = function (t) {
        try {
          return !!k.TU(t).match(/\{\s*\[native code\]\s*\}$/m);
        } catch (t) {
          return !1;
        }
      }),
      (t.ox = function (t) {
        for (var n = [], i = this.object.di(t), r = 0; r < i.length; r++) {
          var o = i[r],
            a = [encodeURIComponent(o), encodeURIComponent(t[o])];
          n.push(a.join("="));
        }
        return n.join("&");
      }),
      (t.Gy = function (t) {
        return document.getElementsByTagName(t);
      }),
      (t.nY = function (t) {
        var n = document.createElement("a");
        return (
          (n.href = t),
          n.protocol + "//" + n.hostname + (n.port ? ":" + n.port : "")
        );
      }),
      (t.getViewport = function (t) {
        try {
          return { width: t.innerWidth, height: t.innerHeight };
        } catch (t) {}
      }),
      (t.NU = function (t) {
        var n = [],
          i = t.defaultView.innerWidth / 2,
          r = t.defaultView.innerHeight / 2;
        c.QX(t.elementsFromPoint) && (n = t.elementsFromPoint(i, r));
        var o = 0,
          a = 0;
        for (var e in n)
          if (
            (typeof n[e] === Zt("}lfwqz") &&
              (o = Math.max(o, 0 | n[e].scrollHeight)),
            a++ > 20)
          )
            break;
        return o;
      }),
      (t.qY = function (t) {
        return {
          scrollBarPosX: Math.round(t.scrollX || t.pageXOffset),
          scrollBarPosY: Math.round(t.scrollY || t.pageYOffset),
          pageHeight: Math.round(
            (t.document.documentElement || t.document.body)[Zt("am~}~bDw{idf")]
          ),
          pageWidth: Math.round(
            (t.document.documentElement || t.document.body)[Zt("am~}~b[{vzd")]
          ),
        };
      }),
      (t.gd = function (t) {
        var n = { x: 0, y: 0, width: 0, height: 0 };
        try {
          var i = t.ownerDocument.defaultView,
            r = t.getBoundingClientRect();
          (n.x = Math.round(i.scrollX + r.left)),
            (n.y = Math.round(i.scrollY + r.top)),
            (n.width = Math.round(r.width)),
            (n.height = Math.round(r.height));
        } catch (t) {}
        return n;
      }),
      (t.tk = function () {
        if (void 0 !== t.cache.Pj) return t.cache.Pj;
        var n,
          i,
          r,
          o = Zt("# <"),
          a = document.getElementsByTagName(Zt("am~{bz"))[0];
        for (i = 1; i <= 15; ++i) {
          if (
            ((r = i < 15 ? "1." + i.toString() : Zt("+><#<?")),
            (n = document.createElement(Zt("am~{bz"))),
            i > 5 && Zt("fa_}g|ow") in Object.prototype
              ? (n.type = Zt("s~|~{mmf{ab=xozsam~{bz7dw|\x7f{}`1") + r)
              : n.setAttribute(Zt("~obugokw"), Zt("XozsAm~{bz") + r),
            (n.text = Zt("egbv}yW0MQvcyQfadk~0O.120") + r + '";'),
            a.parentNode.insertBefore(n, a),
            a.parentNode.removeChild(n),
            !(o = window[Zt("MQvcyQfadk~")]))
          ) {
            o = "0";
            break;
          }
          if (o !== r) break;
        }
        try {
          delete window[Zt("MQvcyQfadk~")];
        } catch (t) {
          window[Zt("MQvcyQfadk~")] = void 0;
        }
        return (t.cache.Pj = parseFloat(o)), t.cache.Pj;
      }),
      (t.Sh = function (t) {
        var n = document.createElement("a");
        return (
          (n.href = t),
          n.protocol + "//" + n.hostname + (n.port ? ":" + n.port : "")
        );
      }),
      (t.tt = function (t, n) {
        void 0 === n && (n = null);
        var i = window.onerror;
        window.onerror = function () {
          return !0;
        };
        try {
          for (
            var r = arguments.length, o = new Array(r > 2 ? r - 2 : 0), a = 2;
            a < r;
            a++
          )
            o[a - 2] = arguments[a];
          t.apply(n, o);
        } catch (t) {}
        window.onerror = i;
      }),
      (t.dV = function (t) {
        g.dV(t);
      }),
      (t.kJ = function (t) {
        var n = decodeURIComponent(t).split("?")[1];
        if (!n) return {};
        for (
          var i = {}, r = (n = decodeURIComponent(n)).split("&"), o = 0;
          o < r.length;
          o++
        ) {
          var a = r[o].split("="),
            e = a[0],
            f = a[1];
          f && (i[e] = f);
        }
        return i;
      }),
      t
    );
  })();
  (z.VI = void 0), (z.MB = Z.KV()), (z.object = new b()), (z.cache = {});
  var y = (function () {
      function t() {
        (this.onload = void 0),
          (this.src = void 0),
          (this.name = void 0),
          (this.iframe = void 0);
      }
      var n = t.prototype;
      return (
        (n.attach = function (t) {
          var n = this,
            i = t.ownerDocument.createElement(Zt("{h~s\x7fk"));
          if ((i.dataset && (i.dataset.us = "us"), z.MB.PC())) {
            var r = function (t) {
              n.onload && n.onload(n, t || event);
            };
            (i.style.position = Zt("sl\x7f}~{xw")),
              (i.style.top = Zt('??<"">|j')),
              (i.style.height = Zt("'~t")),
              (i.style.width = Zt("'~t")),
              (i.src = this.src || Zt("xozsam~{bz6tsb\x7fw")),
              Zt("szxsqfIdw`x") in i
                ? i.attachEvent(Zt("}``}sj"), r)
                : (i.onload = r);
          } else
            (i.style.display = Zt("|abw")),
              this.onload &&
                (i.onload = function (t) {
                  n.onload(n, t);
                }),
              this.src && (i.src = this.src);
          this.name && (i.name = this.name),
            (this.iframe = i),
            t.appendChild(i);
        }),
        (n.detach = function () {
          this.iframe.parentNode.removeChild(this.iframe), (this.iframe = null);
        }),
        t
      );
    })(),
    p = (function () {
      function t() {}
      return (
        (t.Rk = function (t, n, i) {
          void 0 === i && (i = Zt("slcgf4n~s`g"));
          var r = document.createElement(Zt("vgz"));
          (r.style.position = Zt("sl\x7f}~{xw")),
            (r.style.top = Zt('?;<"">|j')),
            (r.style.height = Zt("'>|j")),
            (r.style.width = Zt("'>|j")),
            (r.style.visibility = Zt("zghvw`")),
            (r.innerHTML =
              Zt(".gj`sci2a|o/0") +
              i +
              Zt("0.m`{o!z{jhw|3.f`{i0,2#{t|m\x7fw0"));
          var o = r.firstElementChild;
          return (
            o.dataset && (o.dataset.us = "us"),
            (o.onload =
              o.onreadystatechange =
              o.readystatechange =
                function () {
                  n && n(o), (o.onload = void 0);
                }),
            t.appendChild(r),
            o
          );
        }),
        (t.Gz = function (t) {
          void 0 === t && (t = window);
          for (var n = -1; ++n <= 48 && t != top; ) t = t.parent;
          return 0 === n ? -1 : n;
        }),
        (t.qm = function (t) {
          var n = null;
          try {
            t.document, (n = typeof t.name);
          } catch (t) {}
          return null !== n;
        }),
        (t.YX = function () {
          return (
            c.QX(t.cache.aH) || (t.cache.aH = t.qm(window.top)), t.cache.aH
          );
        }),
        (t.Ns = function () {
          return new y();
        }),
        (t.RC = function (t) {
          void 0 === t && (t = window);
          try {
            return t !== t.top;
          } catch (t) {
            return !0;
          }
        }),
        (t.KI = function (n) {
          if (!t.qm(n.parent)) return null;
          for (
            var i = null,
              r = n.parent.document.getElementsByTagName(Zt("{h~s\x7fk")),
              o = 0;
            o < r.length;
            o++
          ) {
            var a = r[o];
            a.contentWindow === n && (i = a);
          }
          return i;
        }),
        (t.Pl = function (t) {
          return t && t.dataset && "us" === t.dataset.us;
        }),
        (t.Dv = function (n, i) {
          var r = (i || t.qm(n)) && t.qm(n.parent) && n.frameElement;
          return r || n.parent !== top || (r = t.KI(n)), r;
        }),
        t
      );
    })();
  p.cache = {};
  var x,
    j = (function () {
      function t() {}
      return (
        (t.interval = function (n, i, r) {
          return t.PA.interval(i, r, n);
        }),
        (t.timeout = function (n, i, r) {
          if (r) return t.PA.timeout(i, r, n);
          t.immediate(i);
        }),
        (t.Zo = function () {
          t.PA.eD();
        }),
        (t.Gr = function (n) {
          t.PA.GM(n);
        }),
        (t.NX = function (t, n) {
          void 0 === n && (n = null);
          var i,
            r,
            o = {},
            a = 1 / 0;
          for (i in t)
            i === Zt("|oaw") ||
              (n && !c.zn(n, i)) ||
              (typeof (r = t[i]) === Zt("|{apw|") &&
              (0 != r || i.indexOf(Zt("Agvw")) > 0)
                ? (r > 1e11 && r < a && (a = r), (o[i] = r))
                : typeof r === Zt("az~{|i") && (o[i] = r));
          for (i in o)
            typeof (r = o[i]) === Zt("|{apw|") &&
              (o[i] = Math.round(isFinite(a) ? r - a : r));
          return o;
        }),
        t
      );
    })();
  (n = j),
    (j.PA = new m()),
    (j.immediate = (function () {
      var t = Z.KV();
      if (
        (t.QI() && t.version(0) <= 62) ||
        (t.isSafari() && t.version(2) <= 10) ||
        typeof MessageChannel !== Zt("t{bqfgc|")
      )
        return function (t, i) {
          for (
            var r,
              o = arguments.length,
              a = new Array(o > 2 ? o - 2 : 0),
              e = 2;
            e < o;
            e++
          )
            a[e - 2] = arguments[e];
          (r = n.PA).timeout.apply(r, [t, i, !1].concat(a));
        };
      var i = {},
        r = new MessageChannel(),
        o = 0;
      return (
        (r.port1.onmessage = function (t) {
          (t = t.data), i[t](), delete i[t];
        }),
        function (t, n) {
          for (
            var a = arguments.length, e = new Array(a > 2 ? a - 2 : 0), f = 2;
            f < a;
            f++
          )
            e[f - 2] = arguments[f];
          var u;
          (u = e.length
            ? function () {
                return t.apply(null, e);
              }
            : t),
            n ? setTimeout(u, n) : ((i[++o] = u), r.port2.postMessage(o));
        }
      );
    })()),
    (function (t) {
      var n,
        i,
        r = Z.KV(),
        o = !1;
      (t.init = function () {
        if (r.QI() && r.version(0) <= 64)
          (n = Zt("vlkuwz")),
            (i = Date.now()),
            (f = function (t) {
              e(t);
            }),
            (u = 0),
            (c = Object.defineProperty(new Date(), Zt("fa_f`gbu"), {
              get: function () {
                return (
                  u++ && ((o = !0), f(n)),
                  function () {
                    return "";
                  }
                );
              },
            })),
            new Function("a", "b", Zt("s os~b$s>l%"))(console.debug, c);
        else if (r.PC() && 10 === r.version(1)) {
          (n = Zt("vlkwjk")), (i = Date.now());
          var t = new Image();
          Object.defineProperty(t, "id", {
            get: function () {
              throw (e(Zt("vlkwjk")), new Error(Zt("P{np~k,S|o`kfgoa")));
            },
          }),
            console.dir(Zt("P{np~k,S|o`kfgoa"), t);
        } else if (r.isGecko()) {
          (n = Zt("tjnu")), (i = Date.now());
          var a = [];
          a.__defineGetter__("0", function () {
            return (o = !0), e(n), Math.floor(256 * Math.random());
          }),
            console.log(Zt("P{np~k,S|o`kfgoa"), a);
        }
        var f, u, c;
      }),
        (t.ft = function () {
          return (
            null != window.__IE_DEVTOOLBAR_CONSOLE_COMMAND_LINE ||
            void 0 !== window.__BROWSERTOOLS_CONSOLE ||
            !(
              !window.console ||
              !window.console.log ||
              window.console.log.toString() !=
                Zt(
                  't{bqfgc|2&%2i.~wf{~|2Hy|qze}| mbbbu<qo`~:v"~}i 2j",s`iy\x7fw`xa;5,o'
                )
            ) ||
            !!o
          );
        });
      var a = [];
      function e(t) {
        for (var n = Date.now() - i, r = 0, o = a.length; r < o; r++)
          try {
            a[r](t, n);
          } catch (t) {}
      }
      t.rI = function (t) {
        a.push(t);
      };
    })(x || (x = {}));
  var q = function () {};
  (i = q),
    (q.VR = Zt("{~x,")),
    (q.ML = Zt(".}o`") + i.VR),
    (q.Ej = Zt(".!\x7fq`") + i.VR);
  var M = (function () {
      function t() {}
      return (
        (t.makeDedicatedWorker = function () {
          var t = Zt(
              '}`awa}muw3jg|mx{}`$\x7fai%ido~2g|`>pkj}`k \x7fwzd}v5y`~3aau hsfoW5g|`5O5awffcv/c\x7fu<jmfsU+\x7fwzd}v)Q)do~2jf~/|k{2JC@Zfz|@w\x7fywaz7jz|"}|k~`}|1tg`of{ab:;u|}azAwa}muw&wg`b6g`b agmowa}6tsb\x7fw>}xsf{\x7f(jf~I5}xsf{\x7f5O1tz`U+afoxga)Q(to`aw"nwta~w(lit}|i>shxw`4Hsfk"|}y$;o\'q)jf~<}``}sj1tg`of{ab:;u|}azAwa}muw&wg`b6g`b agmowa}6f`{i>azmfg}6jz|W5azmfg}+O-vd`I)\x7ffszya5S6f`{i>pahk(vd`<|iababawZijf \x7fgp}x`:> \'#<%>pkj}`k6pwhc`w"mtfk~(Voxw<`ce:\'q;o5tz` cbw`$\x7fwzd}v"y`~"x`gk%)pkj}`k1Vszi<|a{:;5tz` \x7fw|j$55\'q)'
            ),
            n = new Blob([t], { text: Zt("xozsam~{bz") }),
            i = window.URL || window.webkitURL;
          return new Worker(i.createObjectURL(n));
        }),
        t
      );
    })(),
    S = (function () {
      function t() {}
      return (
        (t.AY = function () {
          if (!c.QX(t.cache.Tn))
            try {
              var n = new Blob(["self.onmessage = function() {};"]),
                i = URL.createObjectURL(n);
              new Worker(i).terminate(), (t.cache.Tn = !0);
            } catch (n) {
              t.cache.Tn = !1;
            }
          return t.cache.Tn;
        }),
        (t.TI = function (t) {
          if ((void 0 === t && (t = !0), t)) return M.makeDedicatedWorker();
        }),
        t
      );
    })();
  S.cache = {};
  var A = (function () {
    function t() {}
    return (
      (t.yL = function (t, n, i) {
        var r = t.querySelector(Zt("I`m\x7fw3+") + n + "']");
        r
          ? (r.value = i)
          : ((r = document.createElement(Zt("{`|gf"))).setAttribute(
              Zt("fw|w"),
              Zt("zghvw`")
            ),
            r.setAttribute(Zt("|oaw"), n),
            r.setAttribute(Zt("do`gw"), i),
            t.appendChild(r));
      }),
      (t.EW = function (t) {
        return !!t.host && !!t.mode && t.nodeName === Zt("1jcqgci|f#j`siaw|z");
      }),
      (t.qu = function (t) {
        return (
          rt.object.QX(this.uE) ||
            (this.uE = Zt("sb`") in t ? t.all.length : -1),
          this.uE
        );
      }),
      (t.xm = function (t) {
        return (
          rt.object.QX(this.zY) ||
            (this.zY = t && t.innerText ? t.innerText.length : void 0),
          this.zY
        );
      }),
      (t.Cb = function () {
        return typeof window !== Zt("g`hwtgbwv") && null !== window
          ? window
          : null;
      }),
      (t.XK = function () {
        return typeof window !== Zt("g`hwtgbwv") && !!window.document;
      }),
      t
    );
  })();
  (A.uE = void 0), (A.zY = void 0);
  var O = (function () {
    function t() {}
    return (
      (t.jg = function (t, n) {
        var i = new Image();
        (i.onload = n), (i.src = t);
      }),
      (t.oZ = function (t) {
        return (
          -1 === document.createElement(t).toString().indexOf(Zt("|eb}e`"))
        );
      }),
      (t.ks = function (t, n) {
        try {
          var i = document.createElement(Zt("dghw}"));
          i.muted = !0;
          var r = i.play();
          i.pause(), r && r.then && r.then(t, n);
        } catch (t) {}
      }),
      (t.isolatedIFrame = function () {
        if (null === t.iFrame) {
          var n = document.createElement(Zt("vgz"));
          (n.style.position = Zt("sl\x7f}~{xw")),
            (n.style.top = Zt('?;<"">|j')),
            (n.style.height = Zt("'>|j")),
            (n.style.width = Zt("'>|j")),
            (n.style.visibility = Zt("zghvw`")),
            document.body.appendChild(n),
            (n.innerHTML = Zt(
              ".gj`sci2a|o/0on}gz6p~oby0.m`{o!z{jhw|3.f`{i0,2#{t|m\x7fw0"
            ));
          var i = n.firstElementChild;
          i.dataset && (i.dataset.us = "us"), (this.iFrame = i.contentWindow);
        }
        return t.iFrame;
      }),
      (t.initializeWorker = function () {
        var n = function () {
            self.onmessage = function (t) {
              var n = (function (t) {
                var n = !1,
                  i = new XMLHttpRequest();
                i.open("GET", t, !1);
                try {
                  i.send(null), 200 === i.status && (n = !0);
                } catch (t) {}
                return n;
              })(t.data.url);
              (t.data.returnFalseToo || n) &&
                self.postMessage({ url: t.data.url, probeReturn: n });
            };
          }.toString(),
          i = n.slice(n.indexOf("{") + 1, n.lastIndexOf("}")),
          r = new Blob([i], { type: Zt("s~|~{mmf{ab=xozsam~{bz") }),
          o = t.isolatedIFrame().URL.createObjectURL(r);
        t.workerToProbeExtensions ||
          ((t.arrayWithCallbacks = []),
          (t.workerToProbeExtensions = new (t.isolatedIFrame().Worker)(o)),
          t.workerToProbeExtensions.addEventListener(
            Zt("\x7fk\x7fasii"),
            function (n) {
              t.arrayWithCallbacks[n.data.url](n.data.probeReturn);
            }
          )),
          clearTimeout(t.timeoutToKillWorker),
          (t.timeoutToKillWorker = setTimeout(function () {
            t.workerToProbeExtensions &&
              (t.workerToProbeExtensions.terminate(),
              (t.workerToProbeExtensions = null),
              (t.arrayWithCallbacks = null));
          }, 3e3));
      }),
      (t.xO = function (n, i, r) {
        void 0 === r && (r = !1);
        try {
          window[Zt("qf~}\x7fk")] &&
            rt.object.QX(window.Worker) &&
            t.isWorkerToProbeExtensionSupported &&
            (t.initializeWorker(),
            (t.arrayWithCallbacks[n] = i),
            t.workerToProbeExtensions.postMessage({
              url: n,
              returnFalseToo: r,
            }));
        } catch (n) {
          t.isWorkerToProbeExtensionSupported = !1;
        }
      }),
      t
    );
  })();
  (O.nl = Zt("|oz{uox}`")),
    (O.UL = Zt("g}i`Sii|f")),
    (O.iFrame = null),
    (O.workerToProbeExtensions = null),
    (O.arrayWithCallbacks = null),
    (O.timeoutToKillWorker = 0),
    (O.isWorkerToProbeExtensionSupported = !0);
  var _ = (function () {
    function t() {}
    return (
      (t.getAdSizesWithTolerance = function (n) {
        var i = isNaN(n) ? t.tolerancePercentage : n,
          r = [];
        return c.QX(t.adsSizesWithTolerance[i])
          ? t.adsSizesWithTolerance[i]
          : (t.adsSizes.forEach(function (t) {
              var n = t.split("x"),
                o = Number(n[0]),
                a = Number(n[1]);
              r.push([
                { min: o - o * i, max: o + o * i },
                { min: a - a * i, max: a + a * i },
              ]);
            }),
            (t.adsSizesWithTolerance[i] = r));
      }),
      (t.sJ = function (n, i, r) {
        var o = t.getAdSizesWithTolerance(r),
          a = !1;
        return (
          (n = Number(n)),
          (i = Number(i)),
          o.forEach(function (t) {
            var r = t[0],
              o = t[1];
            n >= r.min && n <= r.max && i >= o.min && i <= o.max && (a = !0);
          }),
          a
        );
      }),
      (t.ix = function (n, i) {
        for (var r = n / i, o = 0; o < t.parsedAdsSizes.length; o++) {
          var a = t.parsedAdsSizes[o];
          if (a.w - 1 <= n && n <= a.w + 1 && a.h - 1 <= i && i <= a.h + 1)
            return !0;
        }
        for (var e = 0; e < t.parsedValidAspectRatios.length; e++) {
          var f = t.parsedValidAspectRatios[e];
          if (
            0.99 * f.aspect < r &&
            r < 1.01 * f.aspect &&
            f.minW <= n &&
            n <= f.maxW &&
            f.minH <= i &&
            i <= f.maxH
          )
            return !0;
        }
        return !1;
      }),
      (t.isAdDomain = function (n, i) {
        if (!i && !n) return !1;
        for (var r = 0; r < t.adsDomains.length; r++) {
          var o = t.adsDomains[r];
          if ((i && i.indexOf(o) > -1) || (n && n.indexOf(o) > -1)) return !0;
        }
        return !1;
      }),
      (t.isAdTitle = function (t) {
        if (!t || !t.substr) return !1;
        switch (!0) {
          case t.substr(0, 13) === Zt("sjzw`zeawci|f"):
          case t === Zt("!|h2bo~fk.mv2mc|fkbf"):
          case t === Zt("qabfw`ev}.hw2obg|me}a.hw2zi`qk~}a"):
            return !0;
          default:
            return !1;
        }
      }),
      (t.isAdName = function (t) {
        if (!t) return !1;
        var n,
          i = [
            Zt("qbidw|!q}|i?sj\x7f"),
            Zt("boSafgoykQmvMmc|foe|w|"),
            Zt("sjnwMohMt|m\x7fw"),
            Zt("t|m\x7fwQmvb{\x7fzg~S\x7fs}xw`"),
            Zt("sjSa~ax#"),
            Zt("t|m\x7fwQ\x7fzwciv{oS\x7fs}xw`"),
          ];
        switch (!0) {
          case t.substring(0, 18) === Zt("uacu~kSsv}S{t|m\x7fwQ"):
          case t.substring(0, 7) === Zt("s}{{tzS") && !isNaN(t.substring(7, 8)):
          case !!(n = new RegExp(Zt("ba\x7f/IP*O8(ev/UR4O$*zfc`/"))) &&
            !!n.exec(t):
          case t.substring(0, 3) === Zt("[BS") &&
            t.substring(5, 11) === Zt("MH^S_K") &&
            !isNaN(t.substring(t.length, t.length - 1)):
          case t.substring(0, 7) === Zt("`kzxwz!"):
          case i.indexOf(t) > -1:
            return !0;
          default:
            return !1;
        }
      }),
      (t.qc = function (n, i, r) {
        return !(
          isNaN(n.width) ||
          isNaN(n.height) ||
          n.width < 30 ||
          n.height < 30 ||
          (i && i.display == Zt("|abw")) ||
          (!t.sJ(n.width, n.height, r) &&
            !(
              t.isAdDomain(n.src, n.location) ||
              t.isAdTitle(n.title) ||
              t.isAdName(n.name)
            ))
        );
      }),
      t
    );
  })();
  (r = _),
    (_.adsDomains = [
      Zt("vayp~ko~{mg<|kx"),
      Zt("aojwt|m\x7fw k}}i`wawbv{mmf{ab<qaa"),
      Zt("aojwt|m\x7fw yaw|o}|zi|f k}}i"),
    ]),
    (_.adsSizes = [
      Zt(" ><j ><"),
      Zt(" :<j&><"),
      Zt(" ;<j ;<"),
      Zt(" ;<j!8<"),
      Zt("!><j ;<"),
      Zt("!=:j 6<"),
      Zt("'6<j&><"),
      Zt("#<<j$><"),
      Zt("#8<j$><"),
      Zt("!><j$><"),
      Zt('!><j#>9"'),
      Zt("&84j$>"),
      Zt("%<4j+>"),
      Zt("+=<j#6<"),
      Zt("+9<j+>"),
      Zt("+9<j ;<"),
      Zt("+6<j#<<"),
      Zt("!><j'>"),
      Zt("!<<j'>"),
      Zt("!<<j#><"),
      Zt("#<<j$>"),
      Zt("#<<j >"),
      Zt("#84j 6"),
      Zt(" ?:j!8"),
      Zt("$:<j#??$"),
      Zt("%;<j#=?&"),
      Zt('#>4"j?5 "'),
      Zt(" 7>j!>"),
      Zt("!><j+;"),
      Zt("!><j#><"),
      Zt("!><j 6?"),
      Zt("!><j!><"),
      Zt("!<<j!=:"),
      Zt("%<4j 6<"),
      Zt("+7<j'>"),
    ]),
    (_.adsSizesWithTolerance = {}),
    (_.validAspectRatios = [
      Zt(' N5""#=*">t&\'>!+">'),
      Zt(' N?""#8\'"v=\'"#> \''),
      Zt('&N5""#=*">t  ;!&\'>'),
      Zt('$N?""#8\'"v9"?99'),
      Zt('*N:""#= ">t%\'#=\'"'),
      Zt('#>L+">!#*><j+>!#*>'),
      Zt('" 9R!><?&;<j$><?+><'),
      Zt('" ?!!N?""#8\'"v5""#=!\'>'),
      Zt('" >\'R?:"?<8"j88"?7:"'),
      Zt('#N?""#8\'"v:""#5""'),
      Zt(' N>""#?""v=""#=\'"'),
      Zt('" : \'N:""#5""v="$9!#$><'),
      Zt('" :$$N4""#= ">t# 6<?#7>"'),
      Zt('" ;\'R8<"?7<"j6<"??>""'),
      Zt('# ;%%N9&"#4""v?""#8\'"'),
      Zt('# ;%%N="$9!$">t#$><?+><'),
      Zt('# :R#<4"??5 "v4""#= ">'),
      Zt("# 9R&;<?$99j!><?&;<"),
      Zt('# ?!!N4""#:""v= ">!+">'),
    ]),
    (_.parsedAdsSizes = []),
    (_.parsedValidAspectRatios = []),
    (function () {
      for (var t = 0; t < r.adsSizes.length; t++) {
        var n = r.adsSizes[t].split("x"),
          i = Number(n[0]),
          o = Number(n[1]);
        isNaN(i) || isNaN(o) || r.parsedAdsSizes.push({ w: i, h: o });
      }
      for (var a = 0; a < r.validAspectRatios.length; a++) {
        var e = r.validAspectRatios[a],
          f = e.indexOf("@"),
          u = e.indexOf("x");
        if (f > -1 && u > -1) {
          var c = Number(e.substring(0, f)),
            Z = e.substring(f + 1, u),
            s = e.substring(u + 1),
            w = Z.split("-"),
            v = s.split("-");
          2 !== w.length ||
            2 !== v.length ||
            isNaN(c) ||
            isNaN(Number(w[0])) ||
            isNaN(Number(w[1])) ||
            isNaN(Number(v[0])) ||
            isNaN(Number(v[1])) ||
            r.parsedValidAspectRatios.push({
              aspect: c,
              minW: Number(w[0]),
              maxW: Number(w[1]),
              minH: Number(v[0]),
              maxH: Number(v[1]),
            });
        }
      }
    })(),
    (_.tolerancePercentage = 0.05);
  var Q = (function () {
    function t() {}
    return (
      (t.fU = function (n) {
        var i = [];
        if (rt.object.QX(n[t.ga])) {
          var r = n[t.ga],
            o = Zt("(`m\x7fw"),
            a = Zt("({\x7fw`Gh"),
            e = Zt("Miev"),
            f = Zt("Mze"),
            u = Zt("(Qkq~gh"),
            c = Zt("(ohAw`\x7fw[j"),
            Z = Zt("(m`{w`x[v"),
            s = Zt("(z~sqee|uGh");
          if (r.getAll && typeof r.getAll().length === Zt("|{apw|"))
            for (var w = r.getAll().length, v = 0; v < w; v++)
              i[v] = {
                name: r.getAll()[v].model.data.ea[o],
                userId: r.getAll()[v].model.data.ea[a],
                gid: r.getAll()[v].model.data.ea[e],
                ti: r.getAll()[v].model.data.ea[f],
                gclid: r.getAll()[v].model.data.ea[u],
                adSenseId: r.getAll()[v].model.data.ea[c],
                clientId: r.getAll()[v].model.data.ea[Z],
                trackingId: r.getAll()[v].model.data.ea[s],
              };
        }
        return i;
      }),
      t
    );
  })();
  Q.ga = "ga";
  var T = (function () {
      function t() {}
      return (
        (t.create = function (t) {
          var n;
          return (
            (n = {}),
            {
              checkLimit: function (i) {
                return n.hasOwnProperty(i)
                  ? n[i] < t && (n[i]++, !0)
                  : ((n[i] = 1), !0);
              },
            }
          );
        }),
        t
      );
    })(),
    N = Zt("# :< "),
    D = Zt("~amvwj"),
    I = Zt("{c|`w}\x7f{}`"),
    E = Zt("azm`f"),
    F = Zt("tg~af_ys`ze~w"),
    C = Zt("\x7fghb}gbf"),
    B = Zt("ffe`v_ys`ze~w"),
    W = Zt("qaab~kxw"),
    P = Zt("aeebbkh"),
    V = Zt("boyaw"),
    R = Zt("`k\x7fg\x7fk"),
    H = Zt("p{jtw|_fs|x"),
    G = Zt("p{jtw|J{|g\x7fz"),
    U = Zt("bbmkw|_fsziQzobuw"),
    J = Zt("sjYaw|E|fk~sqze}|"),
    X = Zt("da`g\x7fkOzs`kw"),
    K = [I, D, Zt("ukc\x7fwz~kQfm|uk"), X, E, F, C, B, W, P, V, R, H, G, U, J];
  !(function (t, n, i) {
    if (typeof i === Zt("}lfwqz") && typeof i.nodeName !== Zt("az~{|i"))
      n(t, i);
    else {
      var r = function (t) {
          for (var n in t) t.hasOwnProperty(n) && (t[n] = r(t[n]));
          return Object.freeze(t);
        },
        o = ((i = {}), [Zt("# :< ")]);
      for (var a in (n(t, i), i))
        i.hasOwnProperty(a) &&
          (null == Object.getOwnPropertyDescriptor(t, a) &&
            Object.defineProperty(t, a, { value: {} }),
          o.forEach(function (n) {
            if (null == Object.getOwnPropertyDescriptor(t[a], n)) {
              var o = r(i[a]);
              Object.defineProperty(t[a], n, {
                get: function () {
                  return o;
                },
                enumerable: !0,
              });
            }
          }));
    }
  })(
    globalThis,
    function (t, n) {
      var i;
      function r(t) {
        var n = 0;
        return function () {
          return n < t.length ? { done: !1, value: t[n++] } : { done: !0 };
        };
      }
      function o(t) {
        var n =
          typeof Symbol != Zt("g`hwtgbwv") &&
          Symbol.iterator &&
          t[Symbol.iterator];
        if (n) return n.call(t);
        if (typeof t.length == Zt("|{apw|")) return { next: r(t) };
        throw Error(String(t) + Zt("2g\x7f2|ax2s`,{fk~spbi2}|,S`|mk^ggw"));
      }
      function a(t) {
        if (!(t instanceof Array)) {
          t = o(t);
          for (var n, i = []; !(n = t.next()).done; ) i.push(n.value);
          t = i;
        }
        return t;
      }
      var e,
        f =
          typeof Object.create == Zt("t{bqfgc|")
            ? Object.create
            : function (t) {
                function n() {}
                return (n.prototype = t), new n();
              },
        u =
          typeof Object.defineProperties == Zt("t{bqfgc|")
            ? Object.defineProperty
            : function (t, n, i) {
                return (
                  t == Array.prototype ||
                    t == Object.prototype ||
                    (t[n] = i.value),
                  t
                );
              },
        c = (function (t) {
          t = [
            typeof globalThis == Zt("}lfwqz") && globalThis,
            t,
            typeof window == Zt("}lfwqz") && window,
            typeof self == Zt("}lfwqz") && self,
            typeof global == Zt("}lfwqz") && global,
          ];
          for (var n = 0; n < t.length; ++n) {
            var i = t[n];
            if (i && i.Math == Math) return i;
          }
          throw Error(Zt("Qob|}z,t{`h2ubcpsb,}pdiqf"));
        })(this);
      if (typeof Object.setPrototypeOf == Zt("t{bqfgc|"))
        e = Object.setPrototypeOf;
      else {
        var Z;
        t: {
          var s = {};
          try {
            (s.__proto__ = { a: !0 }), (Z = s.a);
            break t;
          } catch (t) {}
          Z = !1;
        }
        e = Z
          ? function (t, n) {
              if (((t.__proto__ = n), t.__proto__ !== n))
                throw new TypeError(t + Zt("2g\x7f2|ax2wvxw|}ep~k"));
              return t;
            }
          : null;
      }
      var w = e;
      function v(t, n) {
        if (((t.prototype = f(n.prototype)), (t.prototype.constructor = t), w))
          w(t, n);
        else
          for (var i in n)
            if (i != Zt("b|cf}zubw"))
              if (Object.defineProperties) {
                var r = Object.getOwnPropertyDescriptor(n, i);
                r && Object.defineProperty(t, i, r);
              } else t[i] = n[i];
        t.D = n.prototype;
      }
      function h() {
        for (var t = Number(this), n = [], i = t; i < arguments.length; i++)
          n[i - t] = arguments[i];
        return n;
      }
      function l(t, n, i, r) {
        (this.h = t), (this.method = n), (this.version = i), (this.g = r);
      }
      function b(t) {
        return (
          !!t &&
          void 0 !== t.omid_message_guid &&
          void 0 !== t.omid_message_method &&
          void 0 !== t.omid_message_version &&
          typeof t.omid_message_guid === Zt("az~{|i") &&
          typeof t.omid_message_method === Zt("az~{|i") &&
          typeof t.omid_message_version === Zt("az~{|i") &&
          (void 0 === t.omid_message_args || void 0 !== t.omid_message_args)
        );
      }
      function d(t) {
        return new l(
          t.omid_message_guid,
          t.omid_message_method,
          t.omid_message_version,
          t.omid_message_args
        );
      }
      function g(t) {
        var n = {};
        return (
          (n.omid_message_guid = t.h),
          (n.omid_message_method = t.method),
          (n.omid_message_version = t.version),
          void 0 !== t.g && (n.omid_message_args = t.g),
          n
        );
      }
      !(function (t, n) {
        if (n)
          t: {
            var i = c;
            t = t.split(".");
            for (var r = 0; r < t.length - 1; r++) {
              var o = t[r];
              if (!(o in i)) break t;
              i = i[o];
            }
            (n = n((r = i[(t = t[t.length - 1])]))) != r &&
              null != n &&
              u(i, t, { configurable: !0, writable: !0, value: n });
          }
      })(Zt(']lfwqz"dsbywa'), function (t) {
        return (
          t ||
          function (t) {
            var n,
              i = [];
            for (n in t)
              Object.prototype.hasOwnProperty.call(t, n) && i.push(t[n]);
            return i;
          }
        );
      });
      var m = { B: Zt("s~|"), C: Zt("ekn") };
      function k(t) {
        this.h = t;
      }
      function z() {
        var t = h.apply(0, arguments);
        !(function (t, n) {
          typeof jasmine !== Zt("g`hwtgbwv") && jasmine
            ? t()
            : typeof console !== Zt("g`hwtgbwv") &&
              console &&
              console.error &&
              n();
        })(
          function () {
            throw new (Function.prototype.bind.apply(
              Error,
              [
                null,
                Zt("Qay~v.b}f.o}\x7f~`wfk,fzk,fw}x2a{oqw}\x7ftgb`k2#,"),
              ].concat(a(t))
            ))();
          },
          function () {
            return console.error.apply(console, a(t));
          }
        );
      }
      function y(t, n) {
        if (!n)
          throw Error(
            Zt("Do`gw.j}`.") + t + Zt('2g\x7f2g`hwtgbwv",|gb`2}|,p~oby<')
          );
        if (typeof n !== Zt("az~{|i") && !(n instanceof String))
          throw Error(Zt("Do`gw.j}`.") + t + Zt("2g\x7f2|ax2s.\x7ff`gbu<"));
        if ("" === n.trim())
          throw Error(Zt("Do`gw.j}`.") + t + Zt("2g\x7f2wc|fk.\x7ff`gbu<"));
      }
      function p(t, n) {
        if (null == n)
          throw Error(Zt("Do`gw.j}`.") + t + Zt("2g\x7f2g`hwtgbwv.c`2`y~~"));
      }
      function x(t, n) {
        if (!n) throw Error(t + Zt("2cyaf.b}f.nw2z~gffu<"));
      }
      function j(t, n) {
        if (null == n) throw Error(t + Zt('2cyaf.b}f.nw2`y~~.c`2{bvwhe|wj"'));
        if (typeof n !== Zt("|{apw|") || isNaN(n))
          throw Error(Zt("Do`gw.j}`.") + t + Zt("2g\x7f2|ax2s.bg\x7fli`"));
        if (0 > n) throw Error(t + Zt('2cyaf.nw2o,b}}ef{xi2|{apw|"'));
      }
      function q() {
        return /\d+\.\d+\.\d+(-.*)?/.test(Zt("# :< "));
      }
      function M() {
        for (var t = ["1", "6", "2"], n = ["1", "0", "3"], i = 0; 3 > i; i++) {
          var r = parseInt(t[i], 10),
            o = parseInt(n[i], 10);
          if (r > o) break;
          if (r < o) return !1;
        }
        return !0;
      }
      function S() {
        return Zt("jvtjjvtj?vtjj#8jjv!kjvt?jvtjjvtjjvtj").replace(
          /[xy]/g,
          function (t) {
            var n = (16 * Math.random()) | 0;
            return "y" === t ? ((3 & n) | 8).toString(16) : n.toString(16);
          }
        );
      }
      function A(t, n) {
        try {
          return t.frames && !!t.frames[n];
        } catch (t) {
          return !1;
        }
      }
      function O(t) {
        return [
          Zt("}cevMx=Mb|iaw`x"),
          Zt("}cevMx=Mb|iaw`xMekn"),
          Zt("}cevMx=Mb|iaw`xMs~|"),
        ].some(function (n) {
          return A(t, n);
        });
      }
      function _(t) {
        for (var n = o(Object.values(m)), i = n.next(); !i.done; i = n.next()) {
          i = i.value;
          var r = {};
          if (
            A(
              t,
              (r = ((r.app = Zt("}cevMx=Mb|iaw`xMs~|")),
              (r.web = Zt("}cevMx=Mb|iaw`xMekn")),
              r)[i])
            )
          )
            return i;
        }
        return null;
      }
      var Q = (function () {
        if (typeof t !== Zt("g`hwtgbwv") && t) return t;
        if (typeof global !== Zt("g`hwtgbwv") && global) return global;
        if (typeof window !== Zt("g`hwtgbwv") && window) return window;
        if (typeof globalThis !== Zt("g`hwtgbwv") && globalThis)
          return globalThis;
        var n = Function(Zt("`kxg``,fzg\x7f"))();
        if (n) return n;
        throw Error(Zt("Qay~v.b}f.hwfk~\x7f{`i2ubcpsb,}pdiqf.o}|zijf "));
      })();
      function T(t) {
        return null != t && typeof t.top !== Zt("g`hwtgbwv") && null != t.top;
      }
      function N(t) {
        if (t === Q) return !1;
        try {
          if (typeof t.location.hostname === Zt("g`hwtgbwv")) return !0;
        } catch (t) {
          return !0;
        }
        return !1;
      }
      function D() {
        var t;
        return (
          typeof t === Zt("g`hwtgbwv") &&
            typeof window !== Zt("g`hwtgbwv") &&
            window &&
            (t = window),
          T(t) ? t : Q
        );
      }
      function I(t) {
        (this.h = t), (this.handleExportedMessage = I.prototype.l.bind(this));
      }
      function E(t, n) {
        this.h = n = void 0 === n ? Q : n;
        var i = this;
        t.addEventListener(Zt("\x7fk\x7fasii"), function (t) {
          if (typeof t.data === Zt("}lfwqz")) {
            var n = t.data;
            b(n) && t.source && i.g && i.g(d(n), t.source);
          }
        });
      }
      v(I, k),
        (I.prototype.i = function (t) {
          var n = void 0 === n ? this.h : n;
          if (!n)
            throw Error(
              Zt(
                "_k\x7fasii2vk\x7ff{`mf{ab2\x7f{\x7ff2li2vkj{|kh2sz,q}`\x7ff`{of{ab2fgaw2a~2efi|2}i|vgbu2zdw2ciaaokw<"
              )
            );
          n.handleExportedMessage(g(t), this);
        }),
        (I.prototype.l = function (t, n) {
          b(t) && this.g && this.g(d(t), n);
        }),
        v(E, k),
        (E.prototype.i = function (t) {
          var n = void 0 === n ? this.h : n;
          if (!n)
            throw Error(
              Zt(
                "_k\x7fasii2vk\x7ff{`mf{ab2\x7f{\x7ff2li2vkj{|kh2sz,q}`\x7ff`{of{ab2fgaw2a~2efi|2}i|vgbu2zdw2ciaaokw<"
              )
            );
          n.postMessage(g(t), "*");
        });
      var F = [Zt("}cev"), Zt("d?SDw|et{mmf{abAw|z{qkO}\x7fcy|{mmf{ab")],
        C = [Zt("}cevDk~{tgosfgc|B|cbw|x{w}"), Zt("ak~d{miE{`h}e")];
      function B(t, n) {
        return n.reduce(function (t, n) {
          return t && t[n];
        }, t);
      }
      function W(t) {
        if (!t) {
          var n = void 0 === n ? O : n,
            i = [],
            r = B((t = D()), C);
          r && i.push(r), i.push(T(t) ? t.top : Q);
          t: {
            for (var a = (i = o(i)).next(); !a.done; a = i.next()) {
              n: {
                r = t;
                var e = n;
                if (!N((a = a.value)))
                  try {
                    var f = B(a, F);
                    if (f) {
                      var u = new I(f);
                      break n;
                    }
                  } catch (t) {}
                u = e(a) ? new E(r, a) : null;
              }
              if ((r = u)) {
                t = r;
                break t;
              }
            }
            t = null;
          }
        }
        (this.h = t)
          ? (this.h.g = this.s.bind(this))
          : (n =
              (n = Q.omid3p) &&
              typeof n.registerSessionObserver === Zt("t{bqfgc|") &&
              typeof n.addEventListener === Zt("t{bqfgc|")
                ? n
                : null) && (this.i = n),
          (this.u = this.v = 0),
          (this.l = {}),
          (this.m = []),
          (this.A =
            (this.g = (n = Q.omidVerificationProperties)
              ? n.injectionId
              : void 0) || S());
      }
      function P() {
        return (
          typeof Q.setTimeout === Zt("t{bqfgc|") &&
          typeof Q.clearTimeout === Zt("t{bqfgc|")
        );
      }
      function V() {
        return (
          typeof Q.setInterval === Zt("t{bqfgc|") &&
          typeof Q.clearInterval === Zt("t{bqfgc|")
        );
      }
      ((i = W.prototype).isSupported = function () {
        return !(
          (this.getEnvironment() === Zt("ekn") && !this.g) ||
          (!this.h && !this.i)
        );
      }),
        (i.getEnvironment = function () {
          var t = D();
          return this.injectionSource() || _(t) || _(T(t) ? t.top : Q);
        }),
        (i.injectionSource = function () {
          var t = Q.omidVerificationProperties;
          if (t && t.injectionSource) return t.injectionSource;
        }),
        (i.registerSessionObserver = function (t, n) {
          x(Zt("t{bqfgc|FaIjwmyfw"), t),
            this.i
              ? this.i.registerSessionObserver(t, n, this.g)
              : this.j(Zt("sjhAw}\x7f{}`@{azi|w|"), t, n, this.g);
        }),
        (i.attest = function (t, n) {
          p(Zt("`k}gw}xBsw`}sj"), t),
            y(Zt("\x7fkozs`ea\x7f"), t.mechanism),
            p(Zt("bou~}oh"), t.payload),
            x(Zt("qo`~pooy"), n),
            this.j(
              Zt("szxwaz"),
              n,
              t.mechanism,
              null == t.version ? "" : t.version,
              t.payload,
              this.A,
              this.g
            );
        }),
        (i.addEventListener = function (t, n) {
          y(Zt("wxi|fZubw"), t),
            x(Zt("t{bqfgc|FaIjwmyfw"), n),
            this.i
              ? this.i.addEventListener(t, n, this.g)
              : this.j(Zt("sjhWdkbf^g\x7ffw`i`"), n, t, this.g);
        }),
        (i.sendUrl = function (t, n, i) {
          y(Zt("g|`"), t),
            Q.document && Q.document.createElement
              ? (function (t, n, i, r) {
                  function o(n) {
                    var i = t.m.indexOf(a);
                    0 <= i && t.m.splice(i, 1), n && n();
                  }
                  var a = Q.document.createElement(Zt("{ck"));
                  t.m.push(a),
                    a.addEventListener(Zt("~amv"), o.bind(t, i)),
                    a.addEventListener(Zt("w|~}`"), o.bind(t, r)),
                    (a.src = n);
                })(this, t, n, i)
              : this.j(
                  Zt("akbvG|`"),
                  function (t) {
                    t && n ? n() : !t && i && i();
                  },
                  t
                );
        }),
        (i.injectJavaScriptResource = function (t, n, i) {
          y(Zt("g|`"), t),
            Q.document
              ? (function (t, n, i) {
                  var r = Q.document,
                    o = r.body;
                  ((r = r.createElement(Zt("am~{bz"))).onload = n),
                    (r.onerror = i),
                    (r.src = t),
                    (r.type = Zt("s~|~{mmf{ab=xozsam~{bz")),
                    o.appendChild(r);
                })(t, n, i)
              : this.j(
                  Zt("{`fwqzFsdo_q`g|f@k\x7f}g|ow"),
                  function (r, o) {
                    r
                      ? ((function (t, n) {
                          try {
                            throw new Error(Zt("\\a,wdo`"));
                          } catch (t) {
                            z(
                              Zt(
                                "W|~}`.idsbysfgbu2zdw2Dmds]o`{~x2`k\x7f}g|ow2h~}\x7f.."
                              ) +
                                n +
                                '".'
                            );
                          }
                        })(0, t),
                        n())
                      : (z(Zt('Ak~d{mi2toe~wj,f}.`}sj,XsxmAq|ebf.~waay`qk"')),
                        i());
                  },
                  t
                );
        }),
        (i.setTimeout = function (t, n) {
          if ((x(Zt("t{bqfgc|FaIjwmyfw"), t), j(Zt("fgaw[`A{~bea"), n), P()))
            return Q.setTimeout(t, n);
          var i = this.v++;
          return this.j(Zt("akxF{ci}gz"), t, i, n), i;
        }),
        (i.clearTimeout = function (t) {
          j(Zt("fgaw}{x[v"), t),
            P() ? Q.clearTimeout(t) : this.o(Zt("qbis`Ze\x7fwayf"), t);
        }),
        (i.setInterval = function (t, n) {
          if ((x(Zt("t{bqfgc|FaIjwmyfw"), t), j(Zt("fgaw[`A{~bea"), n), V()))
            return Q.setInterval(t, n);
          var i = this.u++;
          return this.j(Zt("akx[|zi`do`"), t, i, n), i;
        }),
        (i.clearInterval = function (t) {
          j(Zt("{`xw`xm~[j"), t),
            V() ? Q.clearInterval(t) : this.o(Zt("qbis`Gbfw|zs~"), t);
        }),
        (i.s = function (t) {
          var n = t.method,
            i = t.h;
          if (((t = t.g), n === Zt("`k\x7fb}`\x7fw") && this.l[i])) {
            var r =
              q() && M()
                ? t || []
                : t && typeof t === Zt("az~{|i")
                ? JSON.parse(t)
                : [];
            this.l[i].apply(this, r);
          }
          n === Zt("w|~}`") && window.console && z(t);
        }),
        (i.o = function (t) {
          this.j.apply(this, [t, null].concat(a(h.apply(1, arguments))));
        }),
        (i.j = function (t, n) {
          var i = h.apply(2, arguments);
          if (this.h) {
            var r = S();
            n && (this.l[r] = n);
            var o = Zt("Dk~{tgosfgc|Ak~d{mi<") + t;
            (i = q() && M() ? i : JSON.stringify(i)),
              this.h.i(new l(r, o, Zt("# :< "), i));
          }
        });
      var R = void 0;
      if ((R = void 0 === R ? (typeof n === Zt("g`hwtgbwv") ? null : n) : R)) {
        var H = [Zt("]cevDk~{tgosfgc|Qbew|zB}Wxm~")];
        H.slice(0, H.length - 1).reduce(function (t, n) {
          return t && (t[n] || (t[n] = {}));
        }, R)[H[H.length - 1]] = W;
      }
    },
    void 0
  );
  var L = {
      main: Zt("}cevMx=Mb|iaw`x"),
      web: Zt("}cevMx=Mb|iaw`xMekn"),
      app: Zt("}cevMx=Mb|iaw`xMs~|"),
    },
    Y = (function () {
      function t() {
        (this.verificationClient = void 0),
          (this.startTimeoutId = void 0),
          (this.startIntervalId = void 0),
          (this.verificationClient = new window.OmidVerificationClientNoEval[
            N
          ]()),
          this.init();
      }
      t.KV = function () {
        return t._instance || (t._instance = new t()), t._instance;
      };
      var n = t.prototype;
      return (
        (n.publish = function (t) {
          kt.KV().getCollector().pub(3, t);
        }),
        (n.retry = function () {
          var t = this;
          this.startIntervalId ||
            ((this.startIntervalId = setInterval(function () {
              t.init();
            }, 200)),
            (this.startTimeoutId = setTimeout(function () {
              clearInterval(t.startIntervalId);
            }, 6e4)));
        }),
        (n.init = function () {
          var t = this;
          if (this.verificationClient.isSupported()) {
            clearTimeout(this.startTimeoutId),
              clearInterval(this.startIntervalId);
            var n = kt.KV().ma().customerId();
            this.verificationClient.registerSessionObserver(
              this.publish.bind(this),
              n
            ),
              K.forEach(function (n) {
                t.verificationClient.addEventListener(n, t.publish.bind(t));
              }),
              this.publish({ isO: !0 });
          } else this.retry();
        }),
        (n.rL = function () {
          return this.verificationClient;
        }),
        (n.vf = function (t, n) {
          var i = this.rL();
          i && typeof i.attest === Zt("t{bqfgc|") && i.attest(t, n);
        }),
        (t.Rl = function () {
          var t = A.Cb();
          return (
            t &&
            t.omidVerificationProperties &&
            t.omidVerificationProperties.injectionId
          );
        }),
        (t.Md = function () {
          var t = A.Cb();
          return (
            t &&
            t.omidVerificationProperties &&
            t.omidVerificationProperties.injectionSource
          );
        }),
        (t.loadedByOmid = function () {
          return !!this.Rl();
        }),
        (t.Wa = function () {
          var t = 0;
          if (!A.XK()) return 0;
          for (var n = [L.main, L.app, L.web], i = 0; i < n.length; i++) {
            var r = n[i];
            t |= window.frames[r] ? 1 << i : 0;
          }
          return t;
        }),
        (t.lookForOmidFrames = function (t) {
          return (
            t &&
            t.frames &&
            (!!t.frames[L.app] || (t.frames[L.main] && !t.frames[L.web]))
          );
        }),
        (t.oY = function () {
          var t = A.Cb();
          if (this.lookForOmidFrames(t)) return !0;
          try {
            if (this.lookForOmidFrames(t.top)) return !0;
          } catch (t) {}
          try {
            for (var n = t.parent, i = 0; i < 20; i++) {
              if (!n) return !1;
              if (this.lookForOmidFrames(n)) return !0;
              n = n.parent;
            }
          } catch (t) {}
          return !1;
        }),
        (t.yo = function () {
          return typeof omidNative === Zt("}lfwqz");
        }),
        (t.UW = function () {
          if (!A.XK()) return !1;
          var t = A.Cb();
          return !(
            Z.KV().isMobileWebExperience() ||
            (!/ wv/.exec(t.navigator.userAgent) &&
              (/Version\/[\.\d]+/.exec(t.navigator.userAgent) ||
                !/ Mobile\//.exec(t.navigator.userAgent)))
          );
        }),
        (t.Jj = function () {
          return this.oY() || this.UW();
        }),
        (t.eN = function () {
          var n = t.KV().rL();
          return !(!n || !n.isSupported());
        }),
        (t.CL = function () {
          if (t.loadedByOmid() || t.yo() || t.oY()) return !0;
          var n = t.KV().rL();
          return n && n.isSupported() && n.getEnvironment() === Zt("s~|");
        }),
        (t.ZL = function () {
          return !!t.CL() || t.UW();
        }),
        t
      );
    })();
  (Y._instance = void 0), (Y.pk = [L.main, L.app, L.web]);
  var $ = [
      Zt("Sj@}u"),
      Zt("SjI``a~"),
      Zt("Sj\\sg}iv"),
      Zt("Sj@}sjiv"),
      Zt("Sj_fs|xwv"),
      Zt("Sj\\~swe|u"),
      Zt("Sj_f}~|wv"),
      Zt("Sj_y{~|wv"),
      Zt("SjYaw|O~}}i"),
      Zt("SjO~{mgFz|y"),
      Zt("SjE\x7fb|iaagc|"),
      Zt("SjZ{vkcAfo~f"),
      Zt("Sj_{hkOzs`kw"),
      Zt("SjE|fk~sqze}|"),
      Zt("SjYaw|A{|ga{hk"),
      Zt("Sj@{|km`Qfm|uk"),
      Zt("SjZ}~{awQfm|uk"),
      Zt("SjZ{vkc_{j|}{`x"),
      Zt("SjZ{vkcQ}c|~wzi"),
      Zt("SjHg`ox{}`Ozs`kw"),
      Zt("SjIjbobvwjOzs`kw"),
      Zt("SjZ{vkcT{|\x7ffC{m`fg`w"),
      Zt("SjZ{vkcFzg~vC{m`fg`w"),
      Zt("Sj^w\x7foe|{`kF{ciQzobuw"),
      Zt("SjYaw|Mqqk|f[`z{fox{}`"),
      Zt("Sj_y{~|spbiAfoxwQfm|uk"),
    ],
    tt = Zt("zcba"),
    nt = Zt("}`ZBSGH[|}xs|mi"),
    it = (function () {
      function t() {}
      return (
        (t.zV = function () {
          var t = kt.KV().ma().ki();
          return t && t.af === Zt("d~m{v");
        }),
        (t.Zk = function () {
          return (
            typeof window !== Zt("g`hwtgbwv") &&
            typeof window[tt] !== Zt("g`hwtgbwv") &&
            typeof window[tt][nt] === Zt("t{bqfgc|")
          );
        }),
        (t.OR = function (n) {
          t.Zk() && window[tt][nt](n);
        }),
        (t.RF = function () {
          return $;
        }),
        t
      );
    })(),
    rt = function () {};
  (rt.JSON = JSON),
    (rt.object = c),
    (rt.wX = z),
    (rt.iframe = p),
    (rt.IO = k),
    (rt.PA = j),
    (rt.rZ = x),
    (rt.script = q),
    (rt.pA = S),
    (rt.kM = s),
    (rt.dom = A),
    (rt.JS = O),
    (rt.ads = _),
    (rt.Ru = Q),
    (rt.eG = T),
    (rt.omid = Y),
    (rt.vpaid = it);
  var ot = function () {
      var t = rt.object.Xu(95),
        n = 51,
        i = 44;
      do {
        (t[n] = i), (n = (n + 62) % 95), (i = (i + 88) % 95);
      } while (51 !== n);
      return (
        (ot = function () {
          return t;
        }),
        t
      );
    },
    at = String.fromCharCode,
    et = (function () {
      function t(t, n) {
        (this.baseurl = kt.KV().ma().Ug()),
          (this.sid = kt.KV().ma().PR()),
          (this.sc = kt.KV().ma().clientToken()),
          (this.ct = kt.KV().ma().ki()),
          (this.iv = 27182818),
          (this.Pc = []),
          (this.strdata = void 0),
          (this.route = void 0),
          (this.Pc = t),
          (this.route =
            n || (kt.KV().ma().isVanaheim() ? "vg" : Zt("ba\x7ffpooy")));
      }
      var n = t.prototype;
      return (
        (n.__enc = function (t) {
          var n = rt.object.bd(ot()),
            i = 5,
            r = this.iv,
            o = "";
          for (this.iv = (this.iv + 2654435769) & 1048575; --i; )
            (o += at(48 + (31 & r))), (r >>= 5);
          var a,
            e,
            f,
            u = o + this.sid,
            c = u.length,
            Z = t.length,
            s = [];
          for (i = r = 95; r--; )
            (i = (i + n[r] + u.charCodeAt(r % c)) % 95),
              (a = n[r]),
              (n[r] = n[i]),
              (n[i] = a);
          for (r = i = e = 0; e < Z; ++e) {
            if (s.length > 0) (f = s.pop()), --e;
            else if ((f = t.charCodeAt(e)) < 32 || f > 125) {
              f > 2047 ? ((s[3] = 126), (s[2] = 80 + (f >> 11))) : (s[2] = 126),
                (s[1] = 48 + ((f >> 6) & 31)),
                (s[0] = 48 + (63 & f));
              continue;
            }
            (i = (i + n[(r = (r + 1) % 95)]) % 95),
              (a = n[r]),
              (n[r] = n[i]),
              (n[i] = a),
              (f += n[(n[r] + n[i]) % 95]) > 126 && (f -= 95),
              (o += at(f));
          }
          return o;
        }),
        (n.url = function () {
          this.strdata || (this.strdata = JSON.stringify(this.Pc));
          var t = this.strdata.length,
            n = rt.object.clone(this.ct);
          return (
            (n.sid = this.sid),
            (n.oz_sc = this.sc),
            (n.oz_df = Date.now()),
            (n.oz_l = t),
            (n.cv = 3),
            this.baseurl + "/" + this.sid + "/" + this.route + "?" + rt.wX.ox(n)
          );
        }),
        (n.toString = function () {
          if (this.Pc.length)
            return (
              this.strdata || (this.strdata = JSON.stringify(this.Pc)),
              this.__enc(this.strdata)
            );
        }),
        t
      );
    })(),
    ft = (function () {
      function t() {
        var t = this;
        (this.xhrConstructor = void 0),
          (this.emitterType = 0),
          c.QX(XMLHttpRequest) && (this.xhrConstructor = XMLHttpRequest),
          v.subscribe(2, function () {
            t.isBeaconEnabled() && (t.emitterType = 1);
          });
      }
      var n = t.prototype;
      return (
        (n.XN = function (t, n) {
          if (1 !== this.emitterType) {
            if (this.xhrConstructor)
              try {
                var i = new (0, this.xhrConstructor)();
                i.open(Zt("BA_F"), t.url(), !0),
                  i.setRequestHeader(Zt("Qabfw`x?Fw|w"), Zt("fktf=~`s{`")),
                  (i.withCredentials = !1),
                  s.Xr(i.overrideMimeType) &&
                    i.overrideMimeType(Zt("fktf=~`s{`")),
                  c.QX(n) &&
                    ((i.onreadystatechange = function () {
                      4 === i.readyState && n(0);
                    }),
                    (i.onerror = function () {
                      n(1);
                    })),
                  i.send(t.toString());
              } catch (t) {}
          } else
            try {
              navigator.sendBeacon(t.url(), t.toString());
            } catch (t) {}
        }),
        (n.isBeaconEnabled = function () {
          return !!navigator.sendBeacon;
        }),
        t
      );
    })(),
    ut = 9e4,
    ct = function (t) {
      return JSON.stringify(t).length;
    },
    st = function (t) {
      return typeof t === Zt("az~{|i") ? t.length : JSON.stringify(t).length;
    },
    wt = function (t) {
      var n = st(t.value),
        i = [],
        r = {};
      if (null === t.value || typeof t.value !== Zt("}lfwqz"))
        return [vt(t.name, n)];
      for (var o in t.value) {
        var a,
          e = {};
        for (var f in r) e[f] = r[f];
        (e[o] = st(t.value[o])),
          ct([{ pb_error: ((a = {}), (a[t.name] = e), a) }]) > ut
            ? (i.push(vt(t.name, r, n)), ((r = {})[o] = st(t.value[o])))
            : (r = e);
      }
      return (
        Object.keys(r).length
          ? i.push(vt(t.name, r, n))
          : i.push(vt(t.name, { size: n }, n)),
        i
      );
    },
    vt = function (t, n, i) {
      var r = { pb_error: {} };
      return (
        (r.pb_error[t] = n),
        ct([r]) <= ut ? r : { pb_error: { oversized: void 0 !== i ? i : n } }
      );
    },
    ht = (function () {
      function t() {}
      return (
        (t.prototype.batch = function (t) {
          if (ct(t) <= ut) return { batch: t, remainder: [] };
          for (
            var n = (function (t) {
                for (var n = [], i = 0; i < t.length; i++)
                  for (var r in t[i]) {
                    var o;
                    n.push({
                      name: r,
                      value: t[i][r],
                      data: ((o = {}), (o[r] = t[i][r]), o),
                    });
                  }
                return n;
              })(t),
              i = [],
              r = 0;
            r < n.length;
            r++
          )
            for (
              var o = n[r], a = o.data, e = ct([a]) > ut ? wt(o) : [a], f = 0;
              f < e.length;
              f++
            ) {
              var u = i.concat([e[f]]);
              if (ct(u) > ut)
                return {
                  batch: i,
                  remainder: e.slice(f).concat(
                    n.slice(r + 1).map(function (t) {
                      return t.data;
                    })
                  ),
                };
              i.push(e[f]);
            }
          return {
            batch: i,
            remainder: n.slice(r).map(function (t) {
              return t.data;
            }),
          };
        }),
        t
      );
    })(),
    lt = (function () {
      function t() {
        var t = this;
        (this.Mf = void 0),
          (this.batcher = void 0),
          (this.emitterFailed = !1),
          (this.queue = []),
          (this.__emitDelay = 250),
          (this.__emitTimeoutHandle = void 0),
          (this.Mf = new ft()),
          (this.batcher = new ht()),
          h.Ig(this, function () {
            for (
              t.__emitTimeoutHandle && clearTimeout(t.__emitTimeoutHandle),
                t.__emitTimeoutHandle = void 0;
              t.queue.length;

            )
              t.Mf.XN(t.__pop(), s.Nk);
          });
      }
      var n = t.prototype;
      return (
        (n.push = function (t) {
          if (!this.emitterFailed)
            for (
              var n = c.clone(Array.isArray(t) ? t : [t]), i = 0, r = n.length;
              i < r;
              this.queue.push(n[i++])
            );
        }),
        (n.setDebounce = function (t) {
          this.__emitDelay = t;
        }),
        (n.scheduleEmit = function () {
          this.__emitDelay
            ? void 0 === this.__emitTimeoutHandle &&
              (this.__emitTimeoutHandle = setTimeout(
                this.__emit.bind(this),
                this.__emitDelay
              ))
            : (this.__emitTimeoutHandle &&
                clearTimeout(this.__emitTimeoutHandle),
              this.__emit());
        }),
        (n.__emit = function () {
          var t = this;
          if (((this.__emitTimeoutHandle = void 0), this.queue.length))
            try {
              this.Mf.XN(this.__pop(), function (n) {
                (t.emitterFailed = 0 !== n),
                  t.emitterFailed
                    ? (t.queue = [])
                    : t.queue.length && t.scheduleEmit();
              });
            } catch (t) {}
        }),
        (n.__pop = function () {
          var t = this.batcher.batch(this.queue);
          return (this.queue = t.remainder), new et(t.batch);
        }),
        t
      );
    })(),
    bt = (function () {
      function t() {
        (this.subs = {}),
          (this.stored = {}),
          (this.queue = void 0),
          (this.subs = {}),
          (this.stored = {}),
          (this.queue = void 0);
      }
      var n = t.prototype;
      return (
        (n.setQueue = function (t) {
          this.queue = t;
        }),
        (n.push = function (t) {
          this.queue && this.queue(t);
        }),
        (n.pub = function (t, n) {
          this.stored[t] || (this.stored[t] = []),
            this.stored[t].push(n),
            this.subs[t] &&
              this.subs[t].forEach(function (t, i) {
                t && t(n, i);
              });
        }),
        (n.sub = function (t, n) {
          if (n) {
            this.subs[t] || (this.subs[t] = []), this.subs[t].push(n);
            var i = this.subs[t].length - 1;
            return (
              this.stored[t] &&
                this.stored[t].forEach(function (t) {
                  n(t, i);
                }),
              i
            );
          }
        }),
        (n.unsub = function (t, n) {
          this.subs[t] && (this.subs[t][n] = null);
        }),
        t
      );
    })(),
    dt = (function () {
      function t() {
        var t = this;
        (this.state = 0), (this.Ib = Z.KV());
        var n,
          i = document,
          r = i.documentMode;
        this.Ib.PC() && !this.Ib.isEdge()
          ? 11 == r
            ? (((n = i.createElement(Zt("}lfwqz"))).type = Zt("fktf=fx\x7f~")),
              (n.style.display = Zt("|abw")),
              g.dV(function () {
                (n.data = Zt("`k\x7f(=!ewt|m\x7fw h~~!mq` fa")),
                  i.body.appendChild(n),
                  (n.data = Zt("slcgf4n~s`g")),
                  (t.state = 1),
                  new m().timeout(function () {
                    typeof n.object === Zt("}lfwqz")
                      ? ((this.state = 2),
                        (this.poll = function () {
                          return n.object.createEventObject();
                        }))
                      : (this.state = 4);
                  }),
                  h.Ig(t, function () {
                    i.body.removeChild(n),
                      (n = null),
                      (t.poll = function () {
                        return null;
                      });
                  });
              }))
            : r < 11
            ? ((this.state = 2),
              (this.poll = function () {
                return i.createEventObject();
              }))
            : (this.state = 8)
          : (this.state = 8);
      }
      return (
        (t.prototype.poll = function () {
          return null;
        }),
        t
      );
    })(),
    gt = function () {
      var t = kt.KV(),
        n = t.ma(),
        i = Zt('  >!" <');
      t.sendCoreMessage({ orion: { ver: i, exp: void 0 } }),
        t.sendCoreMessage({
          orion: { run_ts: Date.now(), loader_ts: n.startTime() },
        });
      var r = function (i) {
        r = function () {};
        var o = Date.now(),
          a = { orion: { end_ts: o } },
          e = { postct: n.ki() };
        (e.postct[i] = o), t.sendCoreMessage([a, e]);
      };
      v.subscribe(2, function () {
        return r(Zt("fgaw"));
      }),
        v.subscribe(4, function () {
          return r(Zt("wa\x7f"));
        }),
        t.Bd().timeout(function () {
          return r(Zt("wa\x7f"));
        }, kt.iI - 1e4);
    },
    mt = (function () {
      function t(t) {
        (this._win = void 0),
          (this.iframeRef = void 0),
          (this.isIFrameAccessible = void 0),
          (this._win = t);
      }
      t.KV = function () {
        return (
          this._instance || (this._instance = new t(window)), this._instance
        );
      };
      var n = t.prototype;
      return (
        (n.createIFrame = function (t) {
          var n = this;
          this.iframeRef ||
            rt.iframe.Rk(this._win.document.body, function (i) {
              (n.iframeRef = i), t();
            });
        }),
        (n.checkIFrameAccessibility = function () {
          var t = this.iframeRef.contentWindow,
            n = null;
          try {
            t.document, (this.isIFrameAccessible = !0);
          } catch (i) {
            (this.isIFrameAccessible = !1),
              (n = {
                src: this.iframeRef.src,
                sbox:
                  this.iframeRef.src === Zt("slcgf4n~s`g") &&
                  /"null"|"allow-same-origin"/.test(i.message),
                nstd: Number(t.top !== t.parent),
                nstd_lvl: rt.iframe.Gz(t),
                ancr_orgn:
                  t.parent.location.ancestorOrigins &&
                  t.parent.location.ancestorOrigins[0],
                orgn: t.parent.location.origin,
                href: t.parent.location.href,
                rfrr: t.parent.document.referrer,
                e_msg: i.message,
              });
          }
          return n;
        }),
        (n.unmount = function () {
          this.iframeRef &&
            this.iframeRef.parentNode &&
            (this.iframeRef.parentNode.removeChild(this.iframeRef),
            (this.iframeRef = null));
        }),
        t
      );
    })();
  mt._instance = void 0;
  var kt = (function () {
    function n(t) {
      var n = this;
      (this.Ss = void 0),
        (this.PA = void 0),
        (this.Rn = void 0),
        (this.st = void 0),
        (this.iFrame = void 0),
        (this.QT = {}),
        (this.mouse = void 0),
        (this.EM = !1),
        (this.sessionExpired = !1),
        (this.win = void 0),
        (this.collector = void 0),
        (this.isFrameworkPaused = !1),
        (this.hasNextCallsCounter = 0),
        v.subscribe(4, function () {
          (n.sessionExpired = !0), n.iFrame && n.iFrame.unmount();
        }),
        (this.mouse = new dt()),
        (this.win = t),
        (this.Rn = new lt()),
        (this.collector = new bt());
    }
    n.KV = function () {
      return n._instance || (n._instance = new n(window)), n._instance;
    };
    var i,
      r,
      o = n.prototype;
    return (
      (o.isDown = function (t) {
        t &&
          (v.notify(8), j.Zo(), (this.isFrameworkPaused = !0), w.dettachAll());
      }),
      (o.startAllCheckers = function () {
        var t = this;
        this.Rn.setDebounce(250),
          this.PA.timeout(function () {
            return t.Rn.setDebounce(500);
          }, 3e3),
          gt();
        var n = function () {
          if (!t.sessionExpired) {
            var i = Date.now() + 5,
              r = function () {
                var n = t.Ss.fetch();
                if (!n) return 1;
                try {
                  n.JS.Iy(
                    function (i, r) {
                      n.iN &&
                        (t.Rn.push(i),
                        n.HL || t.Rn.scheduleEmit(),
                        r && t.Ss.stopChecker(n));
                    },
                    t.win,
                    t.iframeRef,
                    t.collector
                  );
                } catch (r) {
                  var i;
                  t.sendCoreMessage({
                    runner_err:
                      ((i = {}),
                      (i[n.JS.name] = {
                        en: r.name,
                        em: r.message,
                        es: r.stack,
                        ets: t.PA.diff(),
                      }),
                      i),
                  }),
                    t.Ss.stopChecker(n),
                    t.Ss.removeChecker(n);
                }
              };
            do {
              if (r()) break;
            } while (Date.now() < i);
            t.Ss.hasNext() &&
              (t.hasNextCallsCounter++,
              t.PA.timeout(n, t.hasNextCallsCounter > 200 ? 250 : 0)),
              t.Rn.scheduleEmit();
          }
        };
        n();
      }),
      (o.runSafely = function (t, n, i) {
        try {
          n(this.st, this.collector);
        } catch (n) {
          var r;
          this.sendCoreMessage({
            runner_err:
              ((r = {}),
              (r[t] = {
                en: n.name,
                em: n.message,
                es: n.stack,
                ets: this.PA && this.PA.diff(),
              }),
              r),
          }),
            i && i(n);
        }
      }),
      (n.DR = function (t, i, r) {
        n.KV().runSafely(t, i, r);
      }),
      (o.setConfig = function (t) {
        this.st || (this.st = t);
      }),
      (o.ma = function () {
        return this.st;
      }),
      (o.getCollector = function () {
        return this.collector;
      }),
      (o.setCheckerManager = function (t) {
        this.Ss = t;
      }),
      (o.Bd = function () {
        return this.PA;
      }),
      (o.init = function () {
        var t = this;
        (this.PA = new m(this.st.startTime())),
          v.subscribe(16, function () {
            t.sendCoreMessage({ orion: { domrts: t.PA.diff() } });
          }),
          h.bestEffortInit(this.win),
          this.sendCoreMessage({
            initdata: {
              location_href: location.href,
              document_referrer: document.referrer,
              t: Date.now(),
            },
            oz: { oz_st: this.st.startTime() },
          }),
          this.Ss.init(),
          this.PA.timeout(function () {
            v.notify(4);
          }, n.iI),
          this.PA.timeout(function () {
            v.notify(128), j.Zo(), w.dettachAll();
          }, n.lm),
          this.Ss.needsIsolatedIframe() &&
            this.PA.timeout(function () {
              (t.iFrame = mt.KV()),
                t.iFrame.createIFrame(function () {
                  var n = t.iFrame.checkIFrameAccessibility(),
                    i = t.iFrame.isIFrameAccessible;
                  n && t.sendCoreMessage({ orion: { frame: n } }),
                    i
                      ? (v.notify(32),
                        h.completeInit(t.iFrame.iframeRef.contentWindow))
                      : v.notify(64);
                });
            }, 50),
          this.startAllCheckers(),
          g.dV(function () {
            (t.EM = !0), v.notify(16);
          });
      }),
      (o.isContentLoaded = function () {
        return this.EM;
      }),
      (o.isIframeLoaded = function () {
        return !!this.iframeRef;
      }),
      (o.fetchPostbackUrl = function () {
        return new et([]).url();
      }),
      (o.UR = function (t, n) {
        var i = this.st.yj(),
          r = function () {
            return i.sm * t < 1;
          },
          o = i.sample;
        return c.QX(o)
          ? ((this.UR = function () {
              return o;
            }),
            o)
          : n
          ? n in this.QT
            ? this.QT[n]
            : 1 == i.sol || (void 0 !== i.sol && i.sol.indexOf(n) > -1)
            ? (this.QT[n] = !0)
            : (this.QT[n] = r())
          : r();
      }),
      (o.BN = function () {
        return this.mouse;
      }),
      (o.sendCoreMessage = function (t) {
        this.Rn.push(t), this.Rn.scheduleEmit();
      }),
      (i = n),
      (r = [
        {
          key: Zt("{h~s\x7fk^wt"),
          get: function () {
            return this.iFrame && this.iFrame.iframeRef;
          },
        },
      ]) &&
        (function (n, i) {
          for (var r = 0; r < i.length; r++) {
            var o = i[r];
            (o.enumerable = o.enumerable || !1),
              (o.configurable = !0),
              Zt("do`gw") in o && (o.writable = !0),
              Object.defineProperty(n, t(o.key), o);
          }
        })(i.prototype, r),
      Object.defineProperty(i, Zt("b|cf}zubw"), { writable: !1 }),
      i
    );
  })();
  function zt(t, n) {
    var i = new Image();
    n &&
      ((i.onload = function () {
        return n(!0);
      }),
      (i.onerror = function (t) {
        return n(!1, t);
      })),
      (i.src = t),
      (i.style.visibility = Zt("zghvw`")),
      (i.style.width = Zt("#~t")),
      (i.style.height = Zt("#~t")),
      document.body && document.body.appendChild(i);
  }
  (kt.iI = 12e4), (kt.lm = 534e4), (kt._instance = void 0);
  var yt = (function () {
      function t() {}
      return (
        (t.append = function (t, n, i, r, o, a, e) {
          var f,
            u = kt.KV().ma().PR(),
            c = Date.now(),
            Z = document.createElement(Zt("am~{bz"));
          (Z.onload = function () {
            return a && a({ onload: Date.now() - c });
          }),
            (Z.onerror = function () {
              return e && e({ onerror: Date.now() - c });
            }),
            (Z.src =
              r +
              Zt("(!#") +
              i.dm +
              "/" +
              i.v +
              "/" +
              i.f +
              "." +
              i.e +
              (i.qs ? "?" + i.qs : "")),
            Z.setAttribute("ce", u);
          var s = d.events.Ig(Z, u, function (t) {
            o && o(t.detail), s();
          });
          kt
            .KV()
            .sendCoreMessage({
              injector:
                ((f = {}),
                (f[n] = { inj: kt.KV().Bd().diff(), src: Z.src }),
                f),
            }),
            t.appendChild(Z);
        }),
        t
      );
    })(),
    pt = globalThis;
  (pt.lb = f),
    (pt.BF = Z),
    (pt.Bv = h),
    (pt.lo = d),
    (pt.cA = l),
    (pt.qN = kt),
    (pt.nA = ft),
    (pt.bI = et),
    (pt.Ue = zt),
    (pt.Oj = yt),
    (pt.kP = v),
    (pt.cg = rt);
  var xt,
    jt,
    qt = (function () {
      function t(t) {
        var n,
          i = this;
        (this.initialized = !1),
          (this.dW = {}),
          (this.le = void 0),
          (this.pendingCheckers =
            (((n = {})[1] = []), (n[2] = []), (n[4] = []), n)),
          (this.executionQueue = []),
          (this.modularCheckerOrder = []),
          (this.le = t),
          v.subscribe(4, function () {
            return i.stop();
          }),
          v.subscribe(128, function () {
            return i.stopAll();
          });
      }
      var n = t.prototype;
      return (
        (n.shouldAddChecker = function (t) {
          return !(8 & t.flags) || p.YX();
        }),
        (n.normalizeChecker = function (t, n) {
          var i,
            r = this,
            o = {},
            a = t.flags,
            e = 1;
          void 0 !== n ? (e = n) : 16 & a ? (e = 4) : 4 & a && (e = 2);
          var f = {
            name: t.name,
            flags: t.flags,
            WV: t.WV || [],
            Rd: t.Rd || [],
            lj: t.lj || [],
            TB: t.TB || [],
            bS: t.bS || [],
            gE: c.QX(t.gE) ? t.gE : 32768,
            Iy: function (n, a, e) {
              (o.iN = !0),
                v.subscribe(8, function () {
                  (n = s.Nk), (t.Iy = s.Nk), r.stopChecker(o);
                }),
                (o.HL = !0);
              var f = t.Iy.call(t, n, a, e);
              typeof f === Zt("t{bqfgc|") && (i = f), (o.HL = !1);
            },
          };
          o.stop = function () {
            if (o.iN) {
              o.iN = !1;
              try {
                t.stop && t.stop(r.le.sendCoreMessage.bind(r.le)),
                  i && i(r.le.sendCoreMessage.bind(r.le));
              } catch (t) {}
            }
            o.HL = !1;
          };
          var u = f.bS || [];
          if (u.length)
            for (var Z = 0; Z < u.length; ++Z) {
              var w = u[Z];
              v.subscribe(w.subject, w.observer.bind(t));
            }
          return (o.JS = f), (o.Um = e), (o.iN = !1), (o.HL = !1), o;
        }),
        (n.addChecker = function (t) {
          if (this.shouldAddChecker(t)) {
            var n = this.normalizeChecker(t);
            (this.dW[n.JS.name] = n),
              this.pendingCheckers[n.Um].push([n.JS.name, n.JS.gE]);
          }
        }),
        (n.setCheckerConfig = function (t) {
          var n = t[Zt("`{bBs}xAw}\x7f{}`I|v")] || [];
          this.addPhase(1, t[Zt("{cawvgmfw")], n),
            this.addPhase(2, t[Zt("vaa")], n),
            this.addPhase(4, t[Zt("{h~s\x7fk")], n);
        }),
        (n.addPhase = function (t, n, i) {
          for (var r = 0; r < n.length; r++) {
            var o = n[r],
              a = "#" + this.modularCheckerOrder.length,
              e = {
                name: a,
                Iy: o,
                flags: -1 !== i.indexOf(o) ? 8192 : void 0,
              },
              f = this.normalizeChecker(e, t);
            (this.dW[a] = f),
              this.pendingCheckers[t].push([a, f.JS.gE]),
              this.modularCheckerOrder.push(a);
          }
        }),
        (n.init = function () {
          for (
            var t = this,
              n = function (t, n) {
                return t[1] - n[1];
              },
              i = this.modularCheckerOrder,
              r = Object.keys(this.pendingCheckers),
              o = 0;
            o < r.length;
            o++
          ) {
            for (
              var a = this.pendingCheckers[r[o]], e = [], f = [], u = 0;
              u < a.length;
              u++
            )
              -1 !== i.indexOf(a[u][0]) ? e.push(a[u]) : f.push(a[u]);
            e.sort(function (t, n) {
              return i.indexOf(t[0]) - i.indexOf(n[0]);
            }),
              f.sort(n),
              (this.pendingCheckers[r[o]] = e.concat(f));
          }
          this.queuePendingCheckers(1),
            v.subscribe(16, function () {
              return t.queuePendingCheckers(2);
            }),
            v.subscribe(32, function () {
              return t.queuePendingCheckers(4);
            }),
            v.subscribe(64, function () {
              for (var n = 0, i = t.pendingCheckers[4]; n < i.length; n++) {
                var r = i[n][0];
                delete t.dW[r];
              }
              t.pendingCheckers[4] = [];
            }),
            (this.initialized = !0);
        }),
        (n.queuePendingCheckers = function (t) {
          var n = this.pendingCheckers[t];
          n.length > 0 &&
            (Array.prototype.push.apply(this.executionQueue, n),
            (this.pendingCheckers[t] = []));
        }),
        (n.consumeChecker = function (t) {
          var n = this.dW[t];
          return n ? (this.removeCheckerFromQueue(t, 0), n) : null;
        }),
        (n.removeCheckerFromQueue = function (t, n) {
          if (void 0 === n) {
            for (var i = 0; i < this.executionQueue.length; i++)
              if (this.executionQueue[i][0] === t) {
                this.executionQueue.splice(i, 1);
                break;
              }
          } else this.executionQueue.splice(n, 1);
        }),
        (n.fetch = function () {
          if (!this.initialized) return null;
          var t = this.executionQueue[0];
          if (t) {
            var n = t[0];
            return this.consumeChecker(n);
          }
          return null;
        }),
        (n.hasNext = function () {
          var t = this.pendingCheckers;
          return !!(
            this.executionQueue.length +
            t[1].length +
            t[2].length +
            t[4].length
          );
        }),
        (n.needsIsolatedIframe = function () {
          return !!this.pendingCheckers[4].length;
        }),
        (n.stop = function () {
          for (var t = 0, n = Object.keys(this.dW), i = n.length; t < i; ++t)
            8192 & (this.dW[n[t]].JS.flags || 0) ||
              this.stopChecker(this.dW[n[t]]);
        }),
        (n.stopAll = function () {
          for (var t = 0, n = Object.keys(this.dW), i = n.length; t < i; ++t)
            this.stopChecker(this.dW[n[t]]);
        }),
        (n.stopChecker = function (t) {
          var n = t.JS.name;
          t.stop(), j.Gr(n), this.removeChecker(t);
        }),
        (n.removeChecker = function (t) {
          var n = t.JS.name;
          this.removeCheckerFromQueue(n), delete this.dW[n];
        }),
        t
      );
    })(),
    Mt = Zt("MQS\x7fai(6bgivbg|w`Q("),
    St = Mt.length,
    At = (function () {
      function t() {
        var t = this;
        (this.pJ = []),
          w.Ig(window, Zt("\x7fk\x7fasii"), function (n) {
            if (typeof n.data === Zt("az~{|i") && n.data.slice(0, St) == Mt)
              for (var i = 0, r = t.pJ.length; i < r; ++i)
                t.pJ[i]({
                  data: JSON.parse(n.data.slice(St)),
                  origin: n.origin,
                  source: n.source,
                });
          });
      }
      var n = t.prototype;
      return (
        (n.postMessage = function (t, n, i) {
          void 0 === i && (i = "*"), t.postMessage(Mt + JSON.stringify(n), i);
        }),
        (n.addHandler = function (t, n) {
          this.pJ.push(t.bind(n));
        }),
        t
      );
    })(),
    Ot = (function () {
      function t() {
        if (
          ((this.xdm = void 0),
          (this.st = void 0),
          (this.st = t.qL()),
          !this.st)
        )
          throw new Error(Zt("Ffi2qabt{i,qs`lf2li2wc|fk"));
        this.xdm = window.postMessage && new At();
      }
      (t.DA = function (t) {
        var n = t && t.src;
        if (n) {
          var i,
            r = isNaN((i = n.substr(n.indexOf(".") + 1, 1)))
              ? i
              : n.substr(0, 1),
            o = isNaN((i = n.substr(n.indexOf(".") + 1, 8)))
              ? i
              : n.substr(0, 8);
          try {
            var a = t.onfocus && t.onfocus[r] && t.onfocus[r](o);
            if (a) return (t.onfocus = a.ozoki_onf), a;
          } catch (t) {}
        }
      }),
        (t.TL = function () {
          var t = function () {
            return Math.floor(65536 * (1 + Math.random()))
              .toString(16)
              .substring(1);
          };
          return t() + t() + t() + t() + t() + t();
        }),
        (t.qL = function () {
          for (
            var n = document.scripts.length,
              i = t.DA(document.currentScript || document.scripts[--n]),
              r = 0;
            !i && r < n;
            ++r
          )
            i = t.DA(document.scripts[r]);
          return (
            typeof i === Zt("}lfwqz") &&
              ((i.ozoki_opt = i.ozoki_opt || {}),
              (i.ozoki_opt.oz_mn = i.ozoki_mn),
              (i.ozoki_opt.oz_url = i.ozoki_url),
              (i.ozoki_sc = t.TL())),
            i
          );
        });
      var n = t.prototype;
      return (
        (n.clientToken = function () {
          return this.st.ozoki_sc;
        }),
        (n.getXdm = function () {
          return this.xdm;
        }),
        (n.protocol = function () {
          return this.st.ozoki_url.substr(0, this.st.ozoki_url.indexOf(":"));
        }),
        (n.apiVersion = function () {
          return this.st.API_VERSION;
        }),
        (n.pagespeedVersion = function () {
          return this.st.PAGESPEED_VERSION;
        }),
        (n.Ug = function () {
          return (
            this.protocol() +
            Zt("(!#") +
            this.st.ozoki_os +
            "/" +
            this.st.API_VERSION +
            "/" +
            this.st.PAGESPEED_VERSION +
            "/" +
            this.customerId()
          );
        }),
        (n.PR = function (t) {
          return t && (this.st.ozoki_tc = t), this.st.ozoki_tc;
        }),
        (n.startTime = function () {
          return this.st.ozoki_st;
        }),
        (n.customerId = function () {
          return this.st.ozoki_ct.ci;
        }),
        (n.ki = function (t) {
          if (t)
            for (var n = Object.keys(t), i = 0; i < n.length; ++i) {
              var r = n[i];
              this.st.ozoki_ct[r] = "" + t[r];
            }
          return c.clone(this.st.ozoki_ct);
        }),
        (n.yj = function () {
          return this.st.ozoki_opt || {};
        }),
        (n.domain = function () {
          return this.st.ozoki_os;
        }),
        (n.isVast = function () {
          return this.st.is_vast;
        }),
        (n.isVanaheim = function () {
          var t = this.st.ozoki_url;
          if (!t) return !1;
          var n = t.indexOf("?");
          return (
            -1 !== (-1 !== n ? t.substring(0, n) : t).indexOf(Zt("=xk<x}"))
          );
        }),
        (n.toString = function () {
          return JSON.stringify(this.st);
        }),
        t
      );
    })(),
    _t = Zt("bg="),
    Qt = {
      AdVideoStart: Zt("azm`f"),
      AdVideoFirstQuartile: Zt("tg~af_ys`ze~w"),
      AdVideoMidpoint: Zt("\x7fghb}gbf"),
      AdVideoThirdQuartile: Zt("ffe`v_ys`ze~w"),
      AdVideoComplete: Zt("qaab~kxw"),
      AdSkipped: Zt("aeebbkh"),
      AdStopped: Zt("azcbbkh"),
    },
    Tt = new ft();
  function Nt() {
    clearInterval(xt), clearTimeout(jt);
  }
  var Dt = Z.KV(),
    It = [
      Zt("voxs?}~q"),
      Zt("voxs?bmhk#\x7f`q"),
      Zt("voxs?a~{ugbs~"),
      Zt("voxs?{~~"),
      Zt("voxs?f~wt"),
    ],
    Et = [Zt("slcgf4n~s`g"), Zt("slcgf4\x7f`qjcq"), Zt("xozsam~{bz6")];
  function Ft(t) {
    return typeof t === Zt("az~{|i") && t.trim().length > 0;
  }
  function Ct(t) {
    if (!Ft(t)) return !0;
    var n,
      i = t.trim().toLowerCase();
    for (n = 0; n < Et.length; n++)
      if (i === Et[n] || 0 === i.indexOf(Et[n])) return !0;
    return !1;
  }
  function Bt(t, n) {
    if (!t || typeof t.getAttribute !== Zt("t{bqfgc|")) return null;
    var i;
    for (i = 0; i < n.length; i++) {
      var r = t.getAttribute(n[i]);
      if (Ft(r) && !Ct(r)) return r.trim();
    }
    return null;
  }
  function Wt(t) {
    if (!Ft(t)) return null;
    var n = t.split(",");
    if (!n.length) return null;
    var i = n[0].trim();
    if (!i) return null;
    var r = i.split(/\s+/)[0];
    return Ft(r) && !Ct(r) ? r.trim() : null;
  }
  function Pt(t) {
    return t == parseInt(String(t), 10) ? parseInt(String(t), 10) : null;
  }
  var Vt,
    Rt = function (t) {
      var n = null;
      try {
        Dt.isSafari()
          ? rt.wX.tt(function () {
              n = t.contentDocument || t.contentWindow.document;
            })
          : (n = t.contentDocument || t.contentWindow.document);
      } catch (t) {}
      return n;
    },
    Ht = function (t) {
      var n = t,
        i = n.offsetWidth || 0,
        r = n.offsetHeight || 0,
        o = 0,
        a = 0;
      try {
        var e = t.getBoundingClientRect();
        e && ((o = e.width || 0), (a = e.height || 0));
      } catch (t) {}
      var f = 0,
        u = 0;
      try {
        (f = parseInt(t.getAttribute(Zt("eghfz")), 0) || 0),
          (u = parseInt(t.getAttribute(Zt("zkeuzz")), 0) || 0);
      } catch (t) {}
      var c = 0,
        Z = 0;
      try {
        var s = t.ownerDocument,
          w = s && s.defaultView;
        if (w && typeof w.getComputedStyle === Zt("t{bqfgc|")) {
          var v = w.getComputedStyle(t);
          if (v) {
            var h = v.width,
              l = v.height;
            if (h && -1 !== h.indexOf("px")) {
              var b = parseFloat(h);
              b > 0 && (c = Math.round(b));
            }
            if (l && -1 !== l.indexOf("px")) {
              var d = parseFloat(l);
              d > 0 && (Z = Math.round(d));
            }
          }
        }
      } catch (t) {}
      return {
        width: Math.max(i, o, f, c, 0),
        height: Math.max(r, a, u, Z, 0),
        offsetWidth: i,
        offsetHeight: r,
        rectWidth: o,
        rectHeight: a,
        attrWidth: f,
        attrHeight: u,
        clientWidth: n.clientWidth || 0,
        clientHeight: n.clientHeight || 0,
        scrollWidth: n.scrollWidth || 0,
        scrollHeight: n.scrollHeight || 0,
      };
    },
    Gt = function (t) {
      if (!t || !t.tagName || typeof t.tagName !== Zt("az~{|i")) return null;
      switch (t.tagName.toUpperCase()) {
        case Zt("[CK"):
          return (function (t) {
            var n = Bt(t, It);
            return (
              n ||
              (t.currentSrc && !Ct(t.currentSrc)
                ? t.currentSrc
                : Bt(t, [Zt("a|o")]) ||
                  (t.src && !Ct(t.src)
                    ? t.src
                    : Wt(t.getAttribute && t.getAttribute(Zt("a|oawz"))) ||
                      null))
            );
          })(t);
        case Zt("[H^S_K"):
          return (function (t) {
            return Bt(t, [Zt("a|o")]) || (t.src && !Ct(t.src) ? t.src : null);
          })(t);
        case Zt("DGHW]"):
        case Zt("S[H[]"):
          return (function (t) {
            var n = (function (t) {
              if (!t || typeof t.querySelectorAll !== Zt("t{bqfgc|"))
                return null;
              var n,
                i = t.querySelectorAll(Zt("aay`qk"));
              if (!i || !i.length) return null;
              for (n = 0; n < i.length; n++) {
                var r = i[n],
                  o = Bt(r, [Zt("a|o"), Zt("voxs?}~q")].concat(It));
                if (o) return o;
                if (r.src && !Ct(r.src)) return r.src;
                var a = Wt(r.getAttribute && r.getAttribute(Zt("a|oawz")));
                if (a) return a;
              }
              return null;
            })(t);
            if (n) return n;
            var i = Bt(t, It);
            return (
              i ||
              Bt(t, [Zt("a|o")]) ||
              (t.src && !Ct(t.src)
                ? t.src
                : Wt(t.getAttribute && t.getAttribute(Zt("a|oawz"))) || null)
            );
          })(t);
        default:
          return null;
      }
    },
    Ut = function (t, n) {
      var i = {
          width: { min: null, max: null },
          height: { min: null, max: null },
        },
        r = Pt(t),
        o = Pt(n);
      return (
        null === r ||
          null === o ||
          ((i.width.min = 0.95 * r),
          (i.width.max = 1.05 * r),
          (i.height.min = 0.95 * o),
          (i.height.max = 1.05 * o),
          (i.width.actual = r),
          (i.height.actual = o)),
        i
      );
    },
    Jt = {
      body: "bd",
      div: "d",
      span: "s",
      p: "p",
      a: "a",
      img: "i",
      video: "v",
      audio: "au",
      canvas: "c",
      iframe: "if",
      button: "b",
      input: "in",
      form: "f",
      table: "t",
      tr: "tr",
      td: "td",
      th: "th",
      ul: "ul",
      ol: "ol",
      li: "li",
      h1: "h1",
      h2: "h2",
      h3: "h3",
      h4: "h4",
      h5: "h5",
      h6: "h6",
      section: Zt("ako"),
      article: Zt("s|x"),
      header: Zt("zj~"),
      footer: Zt("tz~"),
      nav: Zt("|oz"),
      main: Zt("\x7foe|"),
      aside: "as",
      figure: Zt("tgk"),
      figcaption: Zt("tgkq"),
      blockquote: "bq",
      code: Zt("qahw"),
      pre: Zt("b|i"),
      strong: Zt("az~"),
      em: "em",
      br: "br",
      hr: "hr",
      meta: "m",
      link: "l",
      script: "sc",
      style: Zt("azu~w"),
      title: Zt("fz`"),
      head: "hd",
      html: Zt("zza~"),
    },
    Xt = {
      style: "s",
      className: "c",
      id: "i",
      width: "w",
      height: "h",
      size: "sz",
      box: "b",
      offsetbox: "ob",
      rectbox: "rb",
      attrbox: "ab",
      clientbox: "cb",
      scrollbox: "sb",
      bgcolor: Zt("pio"),
      color: "c",
      background: "bg",
      src: Zt("a|o"),
      alt: Zt("sbx"),
      poster: Zt("ba\x7ff"),
      preload: Zt("b|i"),
      controls: Zt("qz~~"),
      autoplay: "ap",
      loop: "l",
      muted: "m",
      playsinline: "pi",
      crossorigin: "co",
      integrity: Zt("{`x"),
      naturalwidth: "w",
      naturalheight: "h",
      duration: Zt("v{~"),
      sandbox: Zt("alt"),
      srcdoc: "sd",
      backgroundimage: Zt("pie"),
    },
    Kt =
      (((Vt = {
        none: "n",
        block: "b",
        inline: "i",
        flex: "f",
        grid: "g",
        table: "t",
      })[Zt("{``{|k!p~aoy")] = "ib"),
      (Vt[Zt("{``{|k!t~kt")] = "if"),
      (Vt[Zt("{``{|k!u`gh")] = "ig"),
      (Vt[Zt("fon~w#~}e")] = "tr"),
      (Vt[Zt("fon~w#ow~b")] = "tc"),
      Vt),
    Lt = (function (t) {
      return (
        (t[Zt("h#e|vkt")] = { k: "z", ig: [Zt("s{x}")] }),
        (t[Zt("pooyu|cg|j!{\x7fokw")] = { k: Zt("pie") }),
        t
      );
    })({
      position: { k: Zt("ba\x7f"), ig: [Zt("azmf{m")] },
      visibility: { k: Zt("dg\x7f"), ig: [Zt("dg\x7f{pbi")] },
      opacity: { k: "op", ig: ["1", Zt("# <")] },
      display: {
        k: Zt("vg\x7fb"),
        igFn: function (t, n) {
          var i,
            r =
              ((i =
                n && n.tagName && n.tagName.toLowerCase
                  ? n.tagName.toLowerCase()
                  : ""),
              -1 !==
              [
                "a",
                Zt("a~m|"),
                "em",
                Zt("az~}|i"),
                Zt("qahw"),
                "b",
                "i",
                "u",
                Zt("acm~~"),
                Zt("a{n"),
                Zt("a{|"),
                Zt("~onw~"),
                Zt("sln`"),
                Zt("sm~}|wa"),
                Zt("qgxw"),
                Zt("vhb"),
                Zt("ylh"),
                Zt("aoab"),
                Zt("do~"),
                Zt("fgaw"),
                Zt("\x7fo~y"),
              ].indexOf(i)
                ? Zt("{``{|k")
                : Zt("pbcqy"));
          return t && t === r;
        },
      },
      background: { k: "bg" },
    });
  function Yt(t) {
    if (!t) return "";
    var n = t.toLowerCase();
    return Xt[n] || n;
  }
  function $t(t) {
    if (!t || typeof t !== Zt("az~{|i")) return t;
    0 === t.indexOf(Zt("voxs(")) &&
      (t = t.length > 50 ? t.substring(0, 50) : t);
    var n = t.indexOf("?");
    -1 !== n && (t = t.substring(0, n));
    var i = t.indexOf("#");
    return -1 !== i && (t = t.substring(0, i)), t;
  }
  function tn(t, n, i, r, o) {
    var a = "";
    if (1 === t.nodeType) {
      var e = t;
      (a +=
        "<" +
        (function (t) {
          if (!t) return "";
          var n = t.toLowerCase();
          return Jt[n] || n;
        })(e.tagName)),
        i && -1 !== i.indexOf(e) && (a += "*");
      var f = null;
      try {
        n &&
          typeof n.getComputedStyle === Zt("t{bqfgc|") &&
          (f = n.getComputedStyle(e));
      } catch (t) {}
      if (
        ((a += (function (t) {
          for (
            var n = "",
              i = t,
              r = [
                Zt("qbmaa@m\x7fw"),
                "id",
                Zt("a|o"),
                Zt("a|ov}m"),
                Zt("eghfz"),
                Zt("zkeuzz"),
                Zt("|oxg`o`E{jxz"),
                Zt("|oxg`o`Zwgkzf"),
                Zt("v{~sfgc|"),
                Zt("sbx"),
                Zt("ba\x7ffw|"),
                Zt("aobvpat"),
                Zt("qabf`a`a"),
                Zt("s{x}bbmk"),
                Zt("b|i~}oh"),
                Zt("~acb"),
                Zt("\x7f{xwv"),
                Zt("bbmkagb~{`i"),
                Zt("q|caaa~{ugb"),
                Zt("{`xwu|efk"),
              ],
              o = 0;
            o < r.length;
            o++
          ) {
            var a = r[o];
            try {
              var e = i[a];
              if (e) {
                if (a === Zt("a|o")) e = $t(e);
                else if (a === Zt("a|ov}m")) {
                  if (i.tagName !== Zt("[H^S_K")) continue;
                  e = e && e.length && e.length > 200 ? e.substring(0, 200) : e;
                }
                n += " " + Yt(a) + "=" + e;
              }
            } catch (t) {
              console.error(t);
            }
          }
          return n;
        })(e)),
        (a += (function (t) {
          try {
            var n = 0,
              i = 0;
            try {
              if (typeof t.getBoundingClientRect === Zt("t{bqfgc|")) {
                var r = t.getBoundingClientRect();
                r &&
                  ((n = Math.round(r.x || r.left || 0)),
                  (i = Math.round(r.y || r.top || 0)));
              }
            } catch (t) {}
            var o = Ht(t),
              a = o.width || 0,
              e = o.height || 0,
              f = "",
              u = "";
            (a > 0 || e > 0 || 0 !== n || 0 !== i) && (u += a + "," + e),
              (0 === n && 0 === i) || (u += "," + n + "," + i),
              u && (f += " " + Yt(Zt("pat")) + "=" + u);
            for (
              var c = [
                  {
                    n: Zt("}hjawzn}j"),
                    w: Zt("}hjawz[{vzd"),
                    h: Zt("}hjawzDw{idf"),
                  },
                  { n: Zt("`kofpat"), w: Zt("`kofEghfz"), h: Zt("`kofZkeuzz") },
                  { n: Zt("szx`pat"), w: Zt("szx`Eghfz"), h: Zt("szx`Zkeuzz") },
                  {
                    n: Zt("qbew|zn}j"),
                    w: Zt("qbew|z[{vzd"),
                    h: Zt("qbew|zDw{idf"),
                  },
                  {
                    n: Zt("am~}~bn}j"),
                    w: Zt("am~}~b[{vzdE{jxz"),
                    h: Zt("am~}~bDw{idf"),
                  },
                ],
                Z = 0;
              Z < c.length;
              Z++
            ) {
              var s = c[Z],
                w = o[s.w],
                v = o[s.h];
              (w || v) && (f += " " + Yt(s.n) + "=" + w + "," + v);
            }
            return f;
          } catch (t) {
            return t.msg;
          }
        })(e)),
        (a += (function (t) {
          try {
            var n = t.getAttribute(Zt("azu~w"));
            if (n && typeof n === Zt("az~{|i") && n.trim().length > 0)
              return (
                (n = (function (t) {
                  if (typeof t !== Zt("az~{|i")) return t;
                  var n = t.replace(
                    /url\s*\(\s*'(data:[^']+)'\s*\)/gi,
                    function (t, n) {
                      var i = $t(n);
                      return Zt("g|`:5") + i + "')";
                    }
                  );
                  return (n = n.replace(
                    /url\s*\(\s*"(data:[^"]+)"\s*\)/gi,
                    function (t, n) {
                      var i = $t(n);
                      return Zt("g|`:0") + i + '")';
                    }
                  )).replace(/url\s*\(\s*(data:[^)]+)\s*\)/gi, function (t, n) {
                    var i = $t(n);
                    return Zt("g|`:") + i + ")";
                  });
                })(n)).length > 200 && (n = Zt("fbh`")),
                " " + Yt(Zt("azu~w")) + "=" + n
              );
          } catch (t) {}
          return "";
        })(e)),
        (a += (function (t, n, i) {
          if (!n) return "";
          for (var r = [], o = Object.keys(Lt), a = 0; a < o.length; a++)
            try {
              var e = o[a],
                f = Lt[e];
              if (!f) continue;
              var u = n.getPropertyValue(e);
              if (
                !u ||
                (f.igFn && f.igFn(u, t)) ||
                (f.ig && -1 !== f.ig.indexOf(u))
              )
                continue;
              e === Zt("vg\x7fb~ou") && (u = Kt[u] || u),
                i &&
                  e === Zt("pooyu|cg|j!{\x7fokw") &&
                  (u = u.length > 30 ? u.substring(0, 30) : u),
                r.push(f.k + "=" + u);
            } catch (t) {
              console.error(t);
            }
          return r.length > 0 ? " " + r.join(" ") : "";
        })(e, f, o)),
        !1 !== r)
      ) {
        var u = e.children;
        if (u && u.length)
          for (var c = 0; c < u.length; c++) a += tn(u[c], n, i, !0, o);
      }
      a += ">";
    }
    return a;
  }
  function nn(t, n, i) {
    return t && 1 === t.nodeType ? tn(t, n, i, !1, !1) : "";
  }
  function rn(t, n) {
    return t && t.document && t.document.documentElement
      ? tn(t.document.documentElement, t, n, void 0, !0)
      : "";
  }
  var on = Zt("[CK"),
    an = Zt("[H^S_K"),
    en = Zt("DGHW]"),
    fn = Zt("PAHK"),
    un = Zt("AXK"),
    cn = Zt("QOBDS]"),
    Zn = Zt("I}xk~k&/0lmqyi~}g`h?{cmuw,Q"),
    sn = [on, an, en, un, cn, Zn],
    wn = [on, an, en, "A", un, cn, Zn];
  function vn(t) {
    if (!t) return !1;
    var n = Ht(t);
    return n.height >= 5 && n.width >= 5;
  }
  function hn(t, n) {
    for (var i = [t], r = 0, o = 0; i.length > 0 && r < 1e3 && o < 10; ) {
      for (var a = i.length, e = 0; e < a; e++) {
        r++;
        var f = i.shift();
        if (f) {
          if (n(f)) return f;
          var u = f.children;
          if (u) for (var c = 0; c < u.length; c++) i.push(u[c]);
        }
      }
      o++;
    }
  }
  function ln(t, n) {
    if (!t || typeof t.getComputedStyle !== Zt("t{bqfgc|") || !n) return !1;
    try {
      var i = t.getComputedStyle(n).getPropertyValue(Zt("pooyu|cg|j!{\x7fokw"));
      return (
        !(
          !i ||
          i === Zt("|abw") ||
          0 === i.trim().length ||
          i.includes(Zt("voxs(gasuk"))
        ) &&
        i.trim().length > 7 &&
        vn(n)
      );
    } catch (t) {
      return !1;
    }
  }
  function bn(t, n) {
    return (
      !(
        !(function (t) {
          return (
            !(!t || !t.tagName) && -1 !== sn.indexOf(t.tagName.toUpperCase())
          );
        })(n) && !ln(t, n)
      ) && dn(n, t)
    );
  }
  function dn(t, n) {
    if (!t) return !1;
    var i = t.tagName;
    if (i === an) {
      if (rt.iframe.Pl(t)) return !1;
      if (t.getAttribute && t.getAttribute(Zt("vg\x7fb~ou")) === Zt("|abw"))
        return !1;
    }
    if (t.getAttribute && t.getAttribute(Zt("s|es?fevvkb")) === Zt("f|yw"))
      return !1;
    if (i === on && t.src && t.src.includes && !t.src.includes(Zt("zzxb")))
      return !1;
    try {
      var r = n.getComputedStyle(t);
      if (r.getPropertyValue(Zt("dg\x7f{pg`{fw")) === Zt("zghvw`")) return !1;
      if (r.getPropertyValue(Zt("vg\x7fb~ou")) === Zt("|abw")) return !1;
      if (parseFloat(r.getPropertyValue(Zt("h#e|vkt"))) < -1) return !1;
      if (r.getPropertyValue(Zt("bae|fk~?wxi|f}")) === Zt("|abw")) return !1;
      var o = n.getComputedStyle(t).getPropertyValue(Zt("pooyu|cg|j!{\x7fokw"));
      if (!o || o === Zt("|abw") || 0 === o.trim().length) return !0;
      if (o && !o.includes(Zt("zzxb"))) return !1;
    } catch (t) {}
    return !0;
  }
  function gn(t, n) {
    var i = [];
    bn(t, n) && vn(n) && i.push(n);
    var r = [];
    n &&
      typeof n.querySelectorAll === Zt("t{bqfgc|") &&
      (r = Array.prototype.slice.call(
        n.querySelectorAll(sn.join(",").toLowerCase())
      ));
    for (var o = 0; o < r.length; o++) {
      var a = r[o],
        e = vn(a),
        f = -1 !== i.indexOf(a);
      e && !f && bn(t, a) && dn(a, t) && i.push(a);
    }
    var u = hn(n, function (n) {
      if (!n || typeof t.getComputedStyle !== Zt("t{bqfgc|")) return !1;
      try {
        return ln(t, n) && vn(n);
      } catch (t) {
        return !1;
      }
    });
    return u && -1 === i.indexOf(u) && dn(u, t) && i.push(u), i;
  }
  function mn(t, n, i, r, o, a) {
    var e = {};
    (e.el = t), (e.tagName = t.tagName), (e.id = t.id || null);
    var f = e.tagName,
      u = Ht(t),
      c = u.width,
      Z = u.height;
    (e.w = c), (e.h = Z);
    var s = t.naturalWidth || 0,
      w = t.naturalHeight || 0;
    (e.nw = s), (e.nh = w);
    var v = Math.max(c, s),
      h = Math.max(Z, w),
      l = c * Z;
    (e.area = l), (e.portionOfWindow = i > 0 ? l / i : 0);
    var b = 0;
    switch (
      ((e.bonusScore = 0),
      t.className &&
        (function (t) {
          if (typeof t !== Zt("az~{|i")) return !1;
          for (
            var n = [
                Zt("Uacu~kO`wox{dkO}|zm{|k~Q~o\x7fa"),
                Zt("vmasv}"),
                Zt("az~?sj!g|gx"),
                Zt("az~?sj!fk~i?pob|w|"),
                Zt("az~?`k\x7fb}`\x7f{dk!sv"),
                Zt("sj~}~b!p~aoy"),
                Zt("sj!q}`xw|z"),
                Zt("q|isfgzw?gasuk"),
              ],
              i = 0;
            i < n.length;
            i++
          )
            if (-1 !== t.indexOf(n[i])) return !0;
          return !1;
        })(t.className) &&
        (e.bonusScore += 5),
      a && t.id === a && (e.bonusScore += 100),
      f)
    ) {
      case on:
        b = 3;
        break;
      case an:
        (b = 2),
          t.id &&
            (function (t) {
              if (typeof t !== Zt("az~{|i")) return !1;
              for (
                var n = [
                    Zt("sjSg|gx"),
                    Zt("umoM"),
                    Zt("sjt[\x7fokw?"),
                    Zt("sji~bfeqMoha"),
                    Zt("pob|w|=M"),
                    Zt("scv|sj"),
                    Zt("~ob?~ij?qbeqy#i~wci|f"),
                    Zt("MQ~t{"),
                  ],
                  i = 0;
                i < n.length;
                i++
              )
                if (0 === t.indexOf(n[i])) return !0;
              return !1;
            })(t.id) &&
            (e.bonusScore += 2);
        var d = Gt(t);
        d &&
          (function (t) {
            if (typeof t !== Zt("az~{|i")) return !1;
            for (
              var n = [
                  Zt("scmh}`!sv}uafka<qaa"),
                  Zt("\x7fkh{s \x7f{\x7f~`{<he"),
                  Zt("a mv`a`~<mc\x7f"),
                ],
                i = 0;
              i < n.length;
              i++
            )
              if (-1 !== t.indexOf(n[i])) return !0;
            return !1;
          })(d) &&
          (e.bonusScore += 4);
        break;
      case un:
      case cn:
        b = 2.5;
        break;
      case "A":
        b = 1.5;
        break;
      case en:
        (b = 1.2), t.srcObject && (e.bonusScore += 2);
        break;
      case fn:
        b = 0.1;
        break;
      default:
        b = 1;
    }
    (e.tagScore = b),
      (e.goodSize = (function (t, n) {
        return rt.ads.ix(t, n);
      })(c, Z));
    var g = v >= 5 && h >= 5,
      m = v >= 40 && h >= 40,
      k = dn(t, n),
      z = m && k;
    (e.partSized = g),
      (e.adSized = m),
      (e.otherwiseAllowed = k),
      (e.allowed = z),
      (function (t, n) {
        var i;
        i = t.otherwiseAllowed
          ? t.allowed
            ? "ok"
            : t.partSized
            ? "pt"
            : "sm"
          : "na";
        var r = (t.tagName || "-").toLowerCase(),
          o = n.tags[r];
        o || ((o = {}), (n.tags[r] = o)), (o[i] = (o[i] || 0) + 1);
      })(e, o);
    var y,
      p = !1;
    r &&
      (y = r) &&
      y.width &&
      null !== y.width.max &&
      (p =
        c >= r.width.min &&
        c <= r.width.max &&
        Z >= r.height.min &&
        Z <= r.height.max),
      (e.matchesDm = p);
    var x = r && r.width && r.height && r.width.actual && r.height.actual,
      j = x ? r.width.actual : 0,
      q = x ? r.height.actual : 0,
      M = x ? j * q : 0;
    if (
      ((e.areaRelToDm = x ? Math.max(1 - Math.abs(l - M) / M, 0) : 0),
      (e.wRelToDm = Math.max(j && j > 40 ? 1 - Math.abs(c - j) / j : 0, 0)),
      (e.hRelToDm = Math.max(q && q > 40 ? 1 - Math.abs(Z - q) / q : 0, 0)),
      (e.score = 0),
      z &&
        (e.score =
          b +
          5 * e.areaRelToDm +
          3 * e.wRelToDm +
          3 * e.hRelToDm +
          10 * Number(e.matchesDm) +
          e.portionOfWindow +
          3 * Number(e.goodSize) +
          e.bonusScore),
      (e.className =
        (t.getAttribute && t.getAttribute(Zt("qbmaa"))) ||
        (typeof t.className === Zt("az~{|i") ? t.className : null)),
      (e.src = Gt(t) || null),
      f === an)
    ) {
      var S =
        (function (t) {
          return t &&
            t.tagName &&
            typeof t.tagName === Zt("az~{|i") &&
            t.tagName.toUpperCase() === Zt("[H^S_K")
            ? (function (t) {
                var n = t.getAttribute && t.getAttribute(Zt("a|ov}m"));
                return Ft(n) ? n.trim() : null;
              })(t)
            : null;
        })(t) || null;
      S && S.length > 200 && (S = S.substring(0, 200)), S && (e.srcdoc = S);
    }
    return e;
  }
  function kn(t, n) {
    for (var i = 0; i < t.length; i++)
      if (t[i].allowed) {
        var r = gn(n, t[i].el);
        if (r && Array.isArray(r) && 0 !== r.length) {
          for (var o = !1, a = 0; a < r.length; a++)
            if (bn(n, r[a])) {
              o = !0;
              break;
            }
          if (o) return { el: t[i], lbr: r };
        }
      }
  }
  function zn(t, n, i) {
    if (!t) return null;
    for (
      var r = {},
        o = [Zt("fok\\sci"), Zt("qbmaa@m\x7fw"), "id", Zt("a|o")],
        a = 0;
      a < o.length;
      a++
    ) {
      var e = o[a];
      Object.prototype.hasOwnProperty.call(t, e) && (r[e] = t[e]);
    }
    if (
      ((r.windowSource = n), (r.node = nn(t.el, i)), t.tagName === an && t.el)
    ) {
      var f = t.el;
      f.contentWindow && (r.qm = rt.iframe.qm(f.contentWindow));
    }
    return r;
  }
  function yn(t, n, i, r, o, a) {
    n = n || Zt("q{~`w`x");
    var e = {
      tags: {},
      win: { width: t.window.innerWidth, height: t.window.innerHeight },
    };
    if (i)
      try {
        var f = t.document.getElementById(i);
        if (f && vn(f)) {
          var u = Math.max(
              t.window.document.body.offsetWidth,
              t.window.innerWidth
            ),
            c = Math.max(
              t.window.document.body.offsetHeight,
              t.window.innerHeight
            ),
            Z = mn(f, t, (l = u * c), r, e, i);
          if (Z.allowed) {
            var s = { element: Z.el, best: zn(Z, n, t), metrics: e },
              w = gn(t, Z.el);
            return w && (s.lbr = w), s;
          }
        }
      } catch (t) {}
    var v = [];
    !0 === o && rt.iframe.RC() && v.push(t.document.body);
    var h = Array.prototype.slice
      .call(t.document.querySelectorAll(wn.join(",").toLowerCase()))
      .concat(v);
    a &&
      (h = h.filter(function (t) {
        return t !== a;
      }));
    var l =
        (u = Math.max(
          t.window.document.body.offsetWidth,
          t.window.innerWidth
        )) *
        (c = Math.max(
          t.window.document.body.offsetHeight,
          t.window.innerHeight
        )),
      b = h
        .map(function (n) {
          return mn(n, t, l, r, e, i);
        })
        .filter(function (t) {
          return t.tagName !== fn;
        })
        .sort(function (t, n) {
          return n.score - t.score;
        }),
      d = kn(b, t),
      g = d ? d.el : void 0;
    if (g) {
      g.portionOfWindow > 0.95 && g.goodSize && (g.earlyFind = !0);
      var m = { element: g.el, best: zn(g, n, t), metrics: e };
      return d.lbr && d.lbr.length > 0 && (m.lbr = d.lbr), m;
    }
    var k = t.document.body,
      z = k
        ? hn(k, function (n) {
            try {
              var o = mn(n, t, l, r, e, i);
              return o.goodSize && b.push(o), ln(t, n);
            } catch (t) {
              return !1;
            }
          })
        : null;
    if (z) {
      var y = mn(z, t, l, r, e, i);
      y.tagName = Zt("POOYU\\CG\\J");
      var p = { element: y.el, best: zn(y, n, t), metrics: e },
        x = gn(t, y.el);
      return x && (p.lbr = x), p;
    }
    var j = kn(
        b.sort(function (t, n) {
          return n.score - t.score;
        }),
        t
      ),
      q = j ? j.el : void 0;
    if (q) {
      q.earlyFind = !1;
      var M = { element: q.el, best: zn(q, n, t), metrics: e };
      return j.lbr && j.lbr.length > 0 && (M.lbr = j.lbr), M;
    }
    if (!1 !== o) {
      var S = mn(t.document.body, t, l, r, e, i);
      if (S.allowed) {
        var A = { element: S.el, best: zn(S, n, t), metrics: e },
          O = gn(t, S.el);
        return O && (A.lbr = O), A;
      }
    }
    return { metrics: e };
  }
  function pn(t, n, i, r) {
    n = n || Zt("q{~`w`x");
    var o,
      a,
      e,
      f,
      u = {
        win: { width: t.window.innerWidth, height: t.window.innerHeight },
        tags: {},
      };
    if (i)
      try {
        var c = t.document.getElementById(i);
        if (
          c &&
          c.tagName === en &&
          ((o = c),
          (a = Zt("}hjawz[{vzd")),
          (e = Zt("}hjawzDw{idf")),
          !(
            ((f = o).tagName &&
              typeof f.tagName === Zt("az~{|i") &&
              f.tagName.toLowerCase() === Zt("{h~s\x7fk") &&
              ((a = Zt("eghfz")), (e = Zt("zkeuzz")), !Rt(o))) ||
            (o[a] < 5 && o[e] < 5)
          ))
        ) {
          var Z = Math.max(
              t.window.document.body.offsetWidth,
              t.window.innerWidth
            ),
            s = Math.max(
              t.window.document.body.offsetHeight,
              t.window.innerHeight
            ),
            w = mn(c, t, (b = Z * s), r, u, i);
          if (w.allowed) {
            var v = { element: w.el, best: zn(w, n, t), metrics: u },
              h = gn(t, w.el);
            return h && (v.lbr = h), v;
          }
        }
      } catch (t) {}
    var l = Array.prototype.slice.call(
      t.document.querySelectorAll(en.toLowerCase())
    );
    if (0 === l.length) return { metrics: u };
    var b =
        (Z = Math.max(
          t.window.document.body.offsetWidth,
          t.window.innerWidth
        )) *
        (s = Math.max(
          t.window.document.body.offsetHeight,
          t.window.innerHeight
        )),
      d = l
        .map(function (n) {
          return mn(n, t, b, r, u, i);
        })
        .sort(function (t, n) {
          return n.score - t.score;
        }),
      g = kn(d, t),
      m = g ? g.el : void 0;
    if (m) {
      m.portionOfWindow > 0.95 && m.goodSize && (m.earlyFind = !0);
      var k = { element: m.el, best: zn(m, n, t), metrics: u };
      return g.lbr && g.lbr.length > 0 && (k.lbr = g.lbr), k;
    }
    if (d.length > 0 && d[0].allowed) {
      var z = { element: d[0].el, best: zn(d[0], n, t), metrics: u },
        y = gn(t, d[0].el);
      return y && (z.lbr = y), z;
    }
    return { metrics: u };
  }
  var xn = Zt("qaab~kxw"),
    jn = Zt("{`xw`oof{xi"),
    qn = Zt("`kmvk}xsfkozs`kw"),
    Mn = Zt("}`~wsjuafoxwqfm|uk"),
    Sn = Zt("~amv"),
    An = Zt("}``}sj"),
    On = (function () {
      function t(t, n, i) {
        (this.measureMode = t),
          (this._listeners = []),
          (this._observers = []),
          (this._onMakeSafeError = n || null),
          (this._collector = i);
      }
      var n = t.prototype;
      return (
        (n._makeSafeErrorStop = function () {
          this.cleanUp(), this._onMakeSafeError && this._onMakeSafeError();
        }),
        (n.cleanUp = function () {
          for (var t = this._listeners, n = 0; n < t.length; n++) {
            var i = t[n];
            i.useAttachEvent
              ? i.element.detachEvent &&
                i.element.detachEvent(i.onEventName, i.listener)
              : i.element.removeEventListener &&
                i.element.removeEventListener(i.eventName, i.listener);
          }
          this._listeners = [];
          for (var r = this._observers, o = 0; o < r.length; o++) {
            try {
              r[o].observer.disconnect();
            } catch (t) {}
            r[o].timeoutId && clearTimeout(r[o].timeoutId);
          }
          this._observers = [];
        }),
        (n.measureSameOriginIframe = function (t, n) {
          var i = this;
          try {
            var r = new RegExp(Zt(":U8?'S<I\"#5O;"));
            if (
              (xn === t.readyState || jn === t.readyState) &&
              !r.test(t.title)
            )
              return void n(!0);
            if (t.readyState !== xn && t.readyState !== jn) {
              if (this._hasListenerFor(t, qn)) return;
              var o = null;
              o = this._addListener(t, qn, Mn, function () {
                kt.DR(
                  "aT",
                  function () {
                    (t.readyState !== xn && t.readyState !== jn) ||
                      (o && o(), !r.test(t.title) && n(!0));
                  },
                  function () {
                    i._makeSafeErrorStop();
                  }
                );
              });
            }
            return;
          } catch (t) {
            return;
          }
        }),
        (n._hasListenerFor = function (t, n) {
          for (var i = this._listeners, r = 0; r < i.length; r++)
            if (i[r].element === t && i[r].eventName === n) return !0;
          return !1;
        }),
        (n._removeListenerEntry = function (t, n, i) {
          for (var r = this._listeners, o = 0; o < r.length; o++)
            if (
              r[o].element === t &&
              r[o].eventName === n &&
              r[o].listener === i
            )
              return void r.splice(o, 1);
        }),
        (n._addListener = function (t, n, i, r) {
          var o = this,
            a = !1;
          if (t.addEventListener) t.addEventListener(n, r);
          else {
            if (!t.attachEvent) return null;
            t.attachEvent(i, r), (a = !0);
          }
          return (
            this._listeners.push({
              element: t,
              eventName: n,
              onEventName: i,
              listener: r,
              useAttachEvent: a,
            }),
            function () {
              a
                ? t.detachEvent && t.detachEvent(i, r)
                : t.removeEventListener && t.removeEventListener(n, r),
                o._removeListenerEntry(t, n, r);
            }
          );
        }),
        (n._hasObserverFor = function (t) {
          for (var n = this._observers, i = 0; i < n.length; i++)
            if (n[i].element === t) return !0;
          return !1;
        }),
        (n._removeObserverEntry = function (t) {
          for (var n = this._observers, i = 0; i < n.length; i++)
            if (n[i].observer === t) return void n.splice(i, 1);
        }),
        (n._setupResourceObserver = function (t, n, i) {
          if (!this._hasObserverFor(t)) {
            var r =
              (t.ownerDocument && t.ownerDocument.defaultView) ||
              (typeof window !== Zt("g`hwtgbwv") ? window : null);
            if (r && typeof r.PerformanceObserver === Zt("t{bqfgc|"))
              try {
                var o = this,
                  a = new r.PerformanceObserver(function () {
                    kt.DR(
                      "aT",
                      function (t, r) {
                        n() &&
                          (a.disconnect(), o._removeObserverEntry(a), i(!0));
                      },
                      function () {
                        o._makeSafeErrorStop();
                      }
                    );
                  });
                a.observe({ entryTypes: [Zt("`k\x7f}g|ow")] }),
                  this._observers.push({ element: t, observer: a });
              } catch (t) {}
          }
        }),
        (n.assume = function (n, i) {
          t.isImageSupported(this._collector, function (t) {
            1 === t.pixel && i(!0);
          });
        }),
        (n.measureCrossDomainIframe = function (t, n) {
          var i = this;
          if ((n(!0), !this._hasListenerFor(t, Sn))) {
            var r = null;
            r = this._addListener(t, Sn, An, function () {
              kt.DR(
                "aT",
                function () {
                  r && r(), n(null, { loadTs: Date.now() });
                },
                function () {
                  i._makeSafeErrorStop();
                }
              );
            });
          }
        }),
        (n.measureIframe = function (t, n) {
          var i = Rt(t);
          i
            ? this.measureSameOriginIframe(i, n)
            : this.measureCrossDomainIframe(t, n);
        }),
        (n.measureImage = function (t, n) {
          t.naturalHeight > 0 && t.naturalWidth > 0
            ? n(!0)
            : this._setupResourceObserver(
                t,
                function () {
                  return t.naturalHeight > 0 && t.naturalWidth > 0;
                },
                n
              );
        }),
        (n.measureVideo = function (t, n) {
          if (t.currentTime > 0) n(!0);
          else if (!this._hasListenerFor(t, Zt("fgawg~hsfk"))) {
            var i = this,
              r = null;
            r = this._addListener(
              t,
              Zt("fgawg~hsfk"),
              Zt("}`x{\x7fkybvoxw"),
              function () {
                kt.DR(
                  "aT",
                  function () {
                    t.currentTime <= 0 || (r && (r(), (r = null)), n(!0));
                  },
                  function () {
                    i._makeSafeErrorStop();
                  }
                );
              }
            );
          }
        }),
        (n.measureSvg = function (t, n) {
          this.assume(t, n);
        }),
        (n.measureCanvas = function (t, n) {
          (t.width > 0 && t.height > 0) ||
          (t.clientWidth > 0 && t.clientHeight > 0)
            ? n(!0)
            : this._setupResourceObserver(
                t,
                function () {
                  return (
                    (t.width > 0 && t.height > 0) ||
                    (t.clientWidth > 0 && t.clientHeight > 0)
                  );
                },
                n
              );
        }),
        (t._checkImageLoaded = function (t, n) {
          var i = new Image(),
            r = !1,
            o = function (t) {
              r || ((r = !0), n(t));
            };
          (i.onload = function () {
            o(i.naturalWidth > 0 && i.naturalHeight > 0);
          }),
            (i.onerror = function () {
              o(!1);
            }),
            (i.src = t),
            i.naturalWidth > 0 && i.naturalHeight > 0 && o(!0);
        }),
        (n.measureBackgroundImage = function (t, n) {
          this.assume(t, n);
        }),
        (t.isImageSupported = function (n, i) {
          var r = Zt("{}E\x7fsiiAg~|}`ziv?~ejwb");
          if (
            !(
              n.sub(r, function (t, o) {
                n.unsub(r, o), i(t);
              }) > 0
            )
          )
            if (typeof Image !== Zt("g`hwtgbwv")) {
              var o = Zt(
                'voxs(gasuk#u{h7ps}i$&"^"~ICV~fMCSLM[SOMSSOMB=!#kZ;NSWOMSSO@SSOMSSLMSWOMS[L^SS9'
              );
              try {
                t._checkImageLoaded(o, function (t) {
                  n.pub(Zt("{}E\x7fsiiAg~|}`ziv?~ejwb"), { pixel: t ? 1 : 0 });
                });
              } catch (t) {
                n.pub(Zt("{}E\x7fsiiAg~|}`ziv?~ejwb"), { pixel: -1 });
              }
            } else n.pub(Zt("{}E\x7fsiiAg~|}`ziv?~ejwb"), { pixel: -1 });
        }),
        (n.measure = function (t, n, i) {
          (Array.isArray(t) || null == t) && ((i = n), (n = t), (t = null)),
            t && this._observeAdContainer(t, i),
            this._measureCollection(n, i);
        }),
        (n._measureCollection = function (t, n) {
          if (t && 0 !== t.length) {
            for (var i = t.length, r = [], o = 0; o < i; o++) r[o] = !1;
            var a,
              e = 0;
            for (o = 0; o < t.length; o++) {
              var f = t[o],
                u = (f.tagName && String(f.tagName).toLowerCase()) || "",
                c = f.el;
              switch (u) {
                case Zt("pooyu|cg|j"):
                  a = this.measureBackgroundImage.bind(this);
                  break;
                case Zt("{h~s\x7fk"):
                  a = this.measureIframe.bind(this);
                  break;
                case Zt("{ck"):
                  a = this.measureImage.bind(this);
                  break;
                case Zt("dghw}"):
                  a = this.measureVideo.bind(this);
                  break;
                case Zt("axk"):
                  a = this.measureSvg.bind(this);
                  break;
                case Zt("qobds}"):
                  a = this.measureCanvas.bind(this);
                  break;
                default:
                  if (
                    ln(
                      (c.ownerDocument && c.ownerDocument.defaultView) ||
                        (typeof window !== Zt("g`hwtgbwv") ? window : null),
                      c
                    )
                  ) {
                    a = this.measureBackgroundImage.bind(this);
                    break;
                  }
                  a = this.measureImage.bind(this);
              }
              (function (t) {
                a(c, function (i, o) {
                  o && n(null, o),
                    i &&
                      (r[t] ||
                        ((r[t] = !0),
                        e++,
                        n(null, void 0, t),
                        e >= 1 && n(!0)));
                });
              })(o);
            }
          }
        }),
        (n._observeAdContainer = function (t, n) {
          if (t && 1 === t.nodeType && !this._hasObserverFor(t)) {
            var i =
              (t.ownerDocument && t.ownerDocument.defaultView) ||
              (typeof window !== Zt("g`hwtgbwv") ? window : null);
            if (i && typeof i.MutationObserver === Zt("t{bqfgc|")) {
              var r = this,
                o = null,
                a = [],
                e = !1,
                f = function () {
                  if (o) {
                    try {
                      o.observer.disconnect();
                    } catch (t) {}
                    o.timeoutId &&
                      (clearTimeout(o.timeoutId), (o.timeoutId = void 0)),
                      r._removeObserverEntry(o.observer),
                      (o = null);
                  }
                },
                u = function (t) {
                  if (t) {
                    if (e) return;
                    (e = !0), f();
                  }
                  n.apply(null, arguments);
                },
                c = new i.MutationObserver(function (t) {
                  kt.DR(
                    "aT",
                    function () {
                      for (var n = [], o = 0; o < t.length; o++) {
                        var e = t[o];
                        if (e.type !== Zt("szx`{lyfw}")) {
                          var f = e.addedNodes;
                          if (f)
                            for (var c = 0; c < f.length; c++) {
                              var Z = f[c];
                              Z &&
                                1 === Z.nodeType &&
                                -1 === n.indexOf(Z) &&
                                n.push(Z);
                            }
                        } else
                          e.target &&
                            -1 === n.indexOf(e.target) &&
                            n.push(e.target);
                      }
                      if (0 !== n.length) {
                        for (var s = [], w = 0; w < n.length; w++)
                          for (var v = gn(i, n[w]), h = 0; h < v.length; h++) {
                            var l = v[h];
                            -1 === a.indexOf(l) &&
                              (a.push(l),
                              s.push({ tagName: l.tagName, el: l }));
                          }
                        s.length > 0 && r._measureCollection(s, u);
                      }
                    },
                    function () {
                      r._makeSafeErrorStop();
                    }
                  );
                });
              try {
                c.observe(t, {
                  childList: !0,
                  subtree: !0,
                  attributes: !0,
                  attributeFilter: [
                    Zt("azu~w"),
                    Zt("eghfz"),
                    Zt("zkeuzz"),
                    Zt("qbmaa"),
                    Zt("zghvw`"),
                    Zt("s|es?fevvkb"),
                    Zt("a|o"),
                  ],
                });
              } catch (t) {
                return;
              }
              var Z = setTimeout(function () {
                f();
              }, 6e4);
              (o = { element: t, observer: c, timeoutId: Z }),
                this._observers.push(o);
            }
          }
        }),
        t
      );
    })(),
    _n = Zt("qay|fAb@w`hw`");
  function Qn(t) {
    return t.map(function (t) {
      return { tagName: t.tagName, el: t };
    });
  }
  function Tn() {
    return window.document;
  }
  var Nn = Zt("b|i`w`hw`gbuqfm|uk"),
    Dn = (function () {
      function t(t, n, i) {
        var r, o;
        (this.size = n),
          (this.adid =
            ((r = t),
            rt.object.QX(r.adid) &&
            ((o = r.adid), /^[A-Za-z]+[\w\-\:\.]*$/.test(o))
              ? r.adid
              : void 0)),
          (this.observer = null),
          (this.timeoutId = null),
          (this.previousReadyState = window.document.readyState),
          (this.readyStateChangeHandler = null),
          (this.previousSerializableBestElement = JSON.stringify(null)),
          (this.previousMetrics = JSON.stringify(null)),
          (this.elementCounter = 0),
          (this.measures = null),
          (this.attributeObserver = null),
          (this.observedElement = null),
          (this.queueCallback = null),
          (this.adFoundSent = !1),
          (this.renderBegunSent = !1),
          (this.pendingRenderBegunPrerender = !1),
          (this.omidImpressionRequired = !1),
          (this.omidImpressionReceived = !1),
          (this.pendingRenderBegunOmidImpression = !1),
          (this.everPrerenderedQueued = !1),
          (this.prerenderExitedQueued = !1),
          (this._prerenderingChangeHandler = null),
          (this._prerenderingChangeHandlerAttached = !1),
          (this.domStateFallbackTimeoutId = null),
          (this.shouldSample = !!i),
          (this.resizeObserver = null),
          (this.pollTimeoutId = null),
          (this.earlyDomStateFallbackTimeoutId = null),
          (this.firstFoundElements = []);
      }
      var n = t.prototype;
      return (
        (n.queueIfSampled = function (t, n) {
          var i;
          this.shouldSample && t((((i = {})[_n] = n), i));
        }),
        (n._onFrameworkMakeSafeError = function () {
          this.measures && (this.measures.cleanUp(), (this.measures = null)),
            this.stop();
        }),
        (n.maybeQueueEverPrerendered = function (t) {
          var n = Tn();
          typeof n.prerendering !== Zt("g`hwtgbwv") &&
            n.prerendering &&
            !this.everPrerenderedQueued &&
            (this.queueIfSampled(t, { everPrerendered: !0 }),
            (this.everPrerenderedQueued = !0));
        }),
        (n._detachPrerenderingChangeListener = function () {
          this._prerenderingChangeHandlerAttached &&
            this._prerenderingChangeHandler &&
            (window.document.removeEventListener(
              Nn,
              this._prerenderingChangeHandler
            ),
            (this._prerenderingChangeHandler = null),
            (this._prerenderingChangeHandlerAttached = !1));
        }),
        (n._ensurePrerenderingChangeListener = function (t) {
          var n = Tn();
          if (
            typeof n.prerendering !== Zt("g`hwtgbwv") &&
            n.prerendering &&
            !this._prerenderingChangeHandlerAttached
          ) {
            var i = this;
            (this._prerenderingChangeHandler = function () {
              kt.DR(
                "Rk",
                function () {
                  i.prerenderExitedQueued ||
                    (i.queueIfSampled(t, { prerenderExited: !0 }),
                    (i.prerenderExitedQueued = !0)),
                    i.pendingRenderBegunPrerender &&
                      !i.renderBegunSent &&
                      ((i.pendingRenderBegunPrerender = !1),
                      i.omidImpressionRequired && !i.omidImpressionReceived
                        ? (i.pendingRenderBegunOmidImpression = !0)
                        : i._emitRenderBegun(t)),
                    i._detachPrerenderingChangeListener();
                },
                function () {
                  i._onFrameworkMakeSafeError();
                }
              );
            }),
              n.addEventListener(Nn, this._prerenderingChangeHandler, {
                once: !0,
              }),
              (this._prerenderingChangeHandlerAttached = !0);
          }
        }),
        (n.requireOmidImpression = function () {
          this.omidImpressionRequired = !0;
        }),
        (n.notifyOmidImpression = function (t) {
          (this.omidImpressionReceived = !0),
            this.omidImpressionRequired &&
              !this.renderBegunSent &&
              this.pendingRenderBegunOmidImpression &&
              (this.pendingRenderBegunPrerender || this._emitRenderBegun(t));
        }),
        (n._emitRenderBegun = function (t) {
          var n;
          t((((n = {})[_n] = { renderBegun: !0 }), n)),
            (this.renderBegunSent = !0),
            (this.pendingRenderBegunPrerender = !1),
            (this.pendingRenderBegunOmidImpression = !1);
        }),
        (n.queueRenderBegunWhenAllowed = function (t) {
          if (!this.renderBegunSent) {
            var n = Tn();
            typeof n.prerendering !== Zt("g`hwtgbwv") &&
              n.prerendering &&
              (this.maybeQueueEverPrerendered(t),
              (this.pendingRenderBegunPrerender = !0),
              this._ensurePrerenderingChangeListener(t)),
              (this.pendingRenderBegunOmidImpression =
                this.omidImpressionRequired && !this.omidImpressionReceived),
              this.pendingRenderBegunPrerender ||
                this.pendingRenderBegunOmidImpression ||
                this._emitRenderBegun(t);
          }
        }),
        (n.runDomState = function (t, n) {
          this.shouldSample &&
            kt.DR(
              "Rk",
              function () {
                var i,
                  r = { current: rn(window, n) };
                window.parent &&
                  window.parent !== window &&
                  rt.iframe.qm(window.parent) &&
                  (r.parent = rn(window.parent)),
                  t((((i = {})[_n] = { domState: r }), i));
              },
              this._onFrameworkMakeSafeError.bind(this)
            );
        }),
        (n.getElementsToMeasure = function (t, n, i) {
          if (i && i.length > 0) return Qn(i);
          if (!t || !n) return [];
          var r = n.tagName ? n.tagName.toLowerCase() : "",
            o =
              -1 !==
              [
                Zt("{h~s\x7fk"),
                Zt("{ck"),
                Zt("dghw}"),
                Zt("axk"),
                Zt("qobds}"),
              ].indexOf(r),
            a = !1;
          if (!o) {
            var e =
              (t.ownerDocument && t.ownerDocument.defaultView) ||
              (typeof window !== Zt("g`hwtgbwv") ? window : null);
            if (e && typeof e.getComputedStyle === Zt("t{bqfgc|"))
              try {
                var f = e
                  .getComputedStyle(t)
                  .getPropertyValue(Zt("pooyu|cg|j!{\x7fokw"));
                f && f !== Zt("|abw") && f.trim().length > 0 && (a = !0);
              } catch (t) {}
          }
          if (o || a) return [{ tagName: n.tagName, el: t }];
          var u = gn(window, t);
          return u && Array.isArray(u) && u.length > 0
            ? Qn(u)
            : [{ tagName: n.tagName, el: t }];
        }),
        (n.runAdFindingAlt = function (t, n, i) {
          void 0 === i && (i = !1);
          var r = this;
          kt.DR(
            "Rk",
            function (o, a) {
              var e,
                f = (function (t, n, i, r, o) {
                  var a,
                    e = i ? pn : yn,
                    f = e(t, Zt("q{~`w`x"), o, r, n, void 0);
                  f && f.best && (a = f);
                  var u = { current: f.metrics },
                    c = null;
                  if (
                    (t.parent &&
                      t.parent !== t &&
                      rt.iframe.qm(t.parent) &&
                      (c = e(t.parent, Zt("bo~w|z"), o, r, n, t.frameElement)),
                    c &&
                      ((u.parent = c.metrics),
                      !c.best || (a && a.best) || (a = c)),
                    f && f.best)
                  ) {
                    var Z = { best: f.best, element: f.element, metrics: u };
                    return f.lbr && f.lbr.length > 0 && (Z.lbr = f.lbr), Z;
                  }
                  var s = a && a.element;
                  if (
                    s &&
                    s.tagName === an &&
                    s.contentWindow &&
                    rt.iframe.qm(s.contentWindow)
                  ) {
                    var w = e(
                      s.contentWindow,
                      (a.best && a.best.windowSource
                        ? a.best.windowSource
                        : Zt("q{~`w`x")) + Zt("1gj`sci"),
                      o,
                      r,
                      n,
                      void 0
                    );
                    w &&
                      w.best &&
                      ((u[w.best.windowSource || Zt("{h~s\x7fk")] = w.metrics),
                      (a = w));
                  }
                  if (!a || !a.best) {
                    var v,
                      h,
                      l = Zt("bo~w|z");
                    t.parent &&
                      t.parent !== t &&
                      rt.iframe.qm(t.parent) &&
                      (v = t.parent);
                    for (var b = 0; b < 3 && v; b++) {
                      var d =
                        v &&
                        v.parent &&
                        v.parent !== v &&
                        v.parent !== t &&
                        rt.iframe.qm(v.parent) &&
                        v.parent;
                      if (!d) break;
                      (h = e(
                        (v = d),
                        (l += Zt("1~m`w`x")),
                        o,
                        r,
                        n,
                        v.frameElement
                      )) &&
                        ((u[l] = h.metrics),
                        !h.best || (a && a.best) || (a = h));
                    }
                  }
                  if (!a || !a.best) return { metrics: u };
                  var g = { best: a.best, element: a.element, metrics: u };
                  return a.lbr && a.lbr.length > 0 && (g.lbr = a.lbr), g;
                })(window, !1, n, r.size, r.adid),
                u = f && f.best ? f.best : null,
                c = JSON.stringify(u),
                Z = f ? f.metrics : null,
                s = JSON.stringify(Z),
                w = r.previousSerializableBestElement !== c,
                v = r.previousMetrics !== s;
              if (
                (i &&
                  !w &&
                  r.runDomState(t, f && f.element ? [f.element] : void 0),
                w || v)
              ) {
                if (!w && v)
                  return (
                    (r.previousMetrics = s),
                    void r.queueIfSampled(t, { metrics: Z })
                  );
                if (f && f.best && f.element) {
                  var h = r.getElementsToMeasure(f.element, f.best, f.lbr);
                  if (!r.adFoundSent) {
                    var b;
                    if (
                      (t((((b = {})[_n] = { adFound: !0 }), b)), r.shouldSample)
                    ) {
                      var d,
                        g = { measures: {} };
                      if (h.length > 0) {
                        for (var m = {}, k = 0; k < h.length; k++) {
                          var z = h[k].el;
                          z &&
                            1 === z.nodeType &&
                            (m[String(k)] = { node: nn(z, window) });
                        }
                        Object.keys(m).length > 0 && (g.measures = m);
                      }
                      t((((d = {})[_n] = g), d));
                    }
                    (r.adFoundSent = !0), a.pub(l.AD_FOUND, f.element);
                  }
                  r.firstFoundElements.push(f.element),
                    (r.previousSerializableBestElement = c),
                    (r.previousMetrics = s);
                  var y = r.elementCounter++;
                  r.queueIfSampled(t, (((e = {})[y] = u), (e.metrics = Z), e)),
                    r.measures
                      ? r.runDomState(t, r.firstFoundElements)
                      : (h.length > 0 &&
                          ((r.measures = new On(
                            !1,
                            function () {
                              (r.measures = null), r.stop();
                            },
                            a
                          )),
                          r.measures.measure(f.element, h, function (n, i, o) {
                            if (
                              (i && r.queueIfSampled(t, { extra: i }),
                              r.shouldSample && typeof o === Zt("|{apw|"))
                            ) {
                              var a = {};
                              (a[String(o)] = { btr: !0 }),
                                r.queueIfSampled(t, { measures: a });
                            }
                            r.renderBegunSent ||
                              r.pendingRenderBegunPrerender ||
                              r.pendingRenderBegunOmidImpression ||
                              (n && r.queueRenderBegunWhenAllowed(t));
                          })),
                        r.runDomState(t, f.element ? [f.element] : void 0));
                }
              }
            },
            this._onFrameworkMakeSafeError.bind(this)
          );
        }),
        (n.handleReadyStateChange = function (t) {
          var n = this;
          kt.DR(
            "Rk",
            function () {
              var i = window.document.readyState;
              n.previousReadyState !== i &&
                ((n.previousReadyState = i),
                n.queueIfSampled(t, { readyState: i }));
            },
            this._onFrameworkMakeSafeError.bind(this)
          );
        }),
        (n.listenForChangesPolling = function (t, n) {
          var i = this;
          this.runAdFindingAlt(t, n, !0),
            this.shouldSample &&
              (this.queueIfSampled(t, {
                readyState: window.document.readyState,
              }),
              (this.readyStateChangeHandler = function () {
                i.handleReadyStateChange(t);
              })),
            this.maybeQueueEverPrerendered(t),
            this._ensurePrerenderingChangeListener(t),
            window.document.addEventListener(
              Zt("`kmvk}xsfkozs`kw"),
              this.readyStateChangeHandler
            );
          var r = Date.now(),
            o = this,
            a = function () {
              var i;
              null !== o.pollTimeoutId &&
                (clearTimeout(o.pollTimeoutId), (o.pollTimeoutId = null)),
                (!o.adFoundSent || o.shouldSample) &&
                  ((i = o.adFoundSent ? 1e3 : Date.now() - r < 5e3 ? 200 : 500),
                  (o.pollTimeoutId = setTimeout(function () {
                    (o.pollTimeoutId = null),
                      kt.DR(
                        "Rk",
                        function () {
                          o.runAdFindingAlt(t, n), a();
                        },
                        function () {
                          o._onFrameworkMakeSafeError();
                        }
                      );
                  }, i)));
            };
          a(),
            (this.earlyDomStateFallbackTimeoutId = setTimeout(function () {
              0 === o.elementCounter && o.runDomState(t, void 0),
                (o.earlyDomStateFallbackTimeoutId = null);
            }, 2e3)),
            (this.domStateFallbackTimeoutId = setTimeout(function () {
              0 === o.elementCounter && o.runDomState(t, void 0),
                (o.domStateFallbackTimeoutId = null);
            }, 6e4));
        }),
        (n.stop = function () {
          null !== this.timeoutId &&
            (clearTimeout(this.timeoutId), (this.timeoutId = null)),
            null !== this.pollTimeoutId &&
              (clearTimeout(this.pollTimeoutId), (this.pollTimeoutId = null)),
            null !== this.domStateFallbackTimeoutId &&
              (clearTimeout(this.domStateFallbackTimeoutId),
              (this.domStateFallbackTimeoutId = null)),
            this.readyStateChangeHandler &&
              (window.document.removeEventListener(
                Zt("`kmvk}xsfkozs`kw"),
                this.readyStateChangeHandler
              ),
              (this.readyStateChangeHandler = null)),
            this.observer &&
              (this.observer.disconnect(), (this.observer = null)),
            this.measures && this.measures.cleanUp(),
            this.resizeObserver &&
              (this.resizeObserver.disconnect(), (this.resizeObserver = null)),
            this._detachPrerenderingChangeListener();
        }),
        t
      );
    })(),
    In = [Zt("dghw}"), Zt("d~m{v"), Zt("a}m{"), "2"];
  function En(t) {
    return (
      !!t &&
      typeof t === Zt("}lfwqz") &&
      1 === t.nodeType &&
      typeof t.tagName === Zt("az~{|i")
    );
  }
  var Fn = Zt("bg="),
    Cn = [
      Zt("azm`f"),
      Zt("tg~af_ys`ze~w"),
      Zt("\x7fghb}gbf"),
      Zt("ffe`v_ys`ze~w"),
      Zt("qaab~kxw"),
      Zt("aeebbkh"),
    ],
    Bn = new ft();
  function Wn(t) {
    return null == t || -1 === t
      ? null
      : t >= 0 && t <= 1
      ? Math.round(100 * t)
      : t >= 0 && t <= 100
      ? Math.round(t)
      : null;
  }
  var Pn,
    Vn,
    Rn = {},
    Hn = {};
  function Gn(t, n) {
    var i = n();
    return i !== Hn[t] && ((Hn[t] = i), !0);
  }
  function Un(t) {
    rt.dom.Cb(),
      Pn ||
        ((Pn = setInterval(function () {
          Un(t);
        }, 200)),
        setTimeout(function () {
          clearInterval(Pn);
        }, 6e4)),
      [
        Gn(Zt("zo\x7fV}c"), rt.dom.XK),
        Gn(Zt("zo\x7f]\x7fgh\\szedw"), rt.omid.yo),
        Gn(Zt("}cevB|iaw`owT|m\x7fw}"), rt.omid.Wa),
        Gn(Zt("{`fwqze}|Gh"), rt.omid.Rl),
        Gn(Zt("{`fwqze}|]cg`mi"), rt.omid.Md),
        Gn(Zt("zo\x7f]\x7fgh!b"), function () {
          return typeof window !== Zt("g`hwtgbwv") && !!window.omid3p;
        }),
        Gn(Zt("zo\x7fEwlz{wyYs"), function () {
          return rt.omid.UW();
        }),
        Gn(Zt("{}_gb~c`fkh"), function () {
          return !!rt.omid.KV().rL() && rt.omid.KV().rL().isSupported();
        }),
        Gn(Zt("ukxW|xe`}`aw|z"), function () {
          return (
            !!rt.omid.KV().rL() &&
            rt.omid.KV().rL()[Zt("ukxW|xe`}`aw|z")] &&
            rt.omid.KV().rL()[Zt("ukxW|xe`}`aw|z")]()
          );
        }),
      ].some(function (t) {
        return t;
      }) && t({ omid2: { ctx: Hn } });
  }
  var Jn = 0,
    Xn = new ft(),
    Kn = {
      debounceTimer: 0,
      debounceState: {},
      interesting: 0,
      lastReported: 0,
      everReportedSession: !1,
      everReportedImpression: !1,
      everReportedMeasured: !1,
      everReportedViewable: !1,
      everReportedNonZeroTime: !1,
      everReportedOnScreen: !1,
      everReportedClick: !1,
      lastViewable: 0,
    },
    Ln = function (t) {
      (Jn += 1), (t[Zt("ak}gw`ow")] = Jn), (t[Zt("fgawazm\x7fb")] = Date.now());
      var n = new et([{ viewability: t }], "vw");
      Xn.XN(n, function () {});
    },
    Yn = Zt("|ac\x7f"),
    $n = Zt("|ac\x7fazm`fgab"),
    ti = {
      cachedMeasuredAd: null,
      getMeasuredAd: function () {
        return ti.cachedMeasuredAd;
      },
      setElement: function (t) {
        return (this.cachedMeasuredAd = t || Vn.document.documentElement), t;
      },
      getClaimedMediaType: function () {
        try {
          return "2" === kt.KV().ma().ki().md ? Zt("dghw}") : Zt("vg\x7fb~ou");
        } catch (t) {
          return Zt("vg\x7fb~ou");
        }
      },
    },
    ni = {
      ioGeometric: null,
      resizeObserver: null,
      startMeasuring: function () {
        if (ti.getMeasuredAd() === Vn.document.documentElement) {
          var t = Vn.document.documentElement.getBoundingClientRect();
          (t.width < Vn.innerWidth || t.height < Vn.innerHeight) &&
            ((Vn.document.documentElement.style.minWidth = Zt("#><7")),
            (Vn.document.documentElement.style.minHeight = Zt("#><7")));
        }
        document.hidden && (fi.lastTimestamp = Date.now()), ni.setListeners();
      },
      cbBrowserTabVisibilityChange: function () {
        document.hidden
          ? (ni.ioGeometric.unobserve(ti.getMeasuredAd()),
            fi.updateTimeAccumulator(0, Date.now(), Zt("pooy")))
          : ni.ioGeometric.observe(ti.getMeasuredAd());
      },
      cbAdViewabilityChange: function (t) {
        var n =
          document.hidden || !0 !== t[0][Zt("{}E|fk~awmx{|i")]
            ? 0
            : Math.round(100 * t[0][Zt("{`xw`}iqfgc|@ox{}")]);
        fi.lastViewablePctOnPausedVideo = n;
        var i = Zt("ukc\x7f");
        0 === n &&
          (document.hidden
            ? (i = Zt("pooy"))
            : t[0][Zt("{}E|fk~awmx{|i")] || (i = Zt("ukc\x7f"))),
          fi.updateTimeAccumulator(n, Date.now(), i);
      },
      cbAdSizeChange: function (t) {
        var n = Math.round(t[0].contentRect.width),
          i = Math.round(t[0].contentRect.height),
          r = n * i;
        if (
          (ri.ad.pixels ||
            ((ri.ad.pixels = r), (ri.ad.width = n), (ri.ad.height = i)),
          r !== ri.ad.pixels)
        ) {
          var o = n + "x" + i;
          -1 === ri.ad.altsizes.indexOf(o) && ri.ad.altsizes.push(o);
        }
        fi.MRC_MIN_PCT = r >= ei ? ai : oi;
      },
      cbAdClick: function (t) {
        t.isTrusted && fi.handleClick();
      },
      setListeners: function () {
        Vn.document.addEventListener(Zt("qbeqy"), ni.cbAdClick),
          Vn.document.addEventListener(
            Zt("dg\x7f{pg`{fwozs`kw"),
            ni.cbBrowserTabVisibilityChange
          ),
          (ni.ioGeometric = new IntersectionObserver(ni.cbAdViewabilityChange, {
            threshold: [0, 0.3, 0.5, 0.8, 0.99],
            rootMargin: Zt('"~t'),
          })),
          ni.ioGeometric.observe(ti.getMeasuredAd()),
          (ni.resizeObserver = new ResizeObserver(ni.cbAdSizeChange)),
          ni.resizeObserver.observe(ti.getMeasuredAd());
      },
      removeListeners: function () {
        Vn.document.removeEventListener(Zt("qbeqy"), ni.cbAdClick),
          Vn.document.removeEventListener(
            Zt("dg\x7f{pg`{fwozs`kw"),
            ni.cbBrowserTabVisibilityChange
          ),
          ti.getMeasuredAd() &&
            (ni.ioGeometric.unobserve(ti.getMeasuredAd()),
            ni.resizeObserver.unobserve(ti.getMeasuredAd()));
      },
    },
    ii = {
      _isVideoPlaying: !1,
      isVideoPlaying: function () {
        return ii._isVideoPlaying;
      },
      cbVideoPlay: function (t) {
        ii._isVideoPlaying ||
          ((ii._isVideoPlaying = !0),
          fi.updateTimeAccumulator(fi.lastViewablePctOnPausedVideo, t),
          (fi.lastTimestamp = t));
      },
      cbVideoPause: function (t) {
        ii._isVideoPlaying &&
          ((ii._isVideoPlaying = !1),
          fi.updateTimeAccumulator(0, t, Zt("azcb")));
      },
    },
    ri = {
      method: null,
      container: Zt("ak`t"),
      omidinfo: {},
      ad: {
        mrc: {},
        groupm: {},
        total_time: { 0: 0, 30: 0, 50: 0, 80: 0, 100: 0 },
        max_cont_time: { 0: 0, 30: 0, 50: 0, 80: 0, 100: 0 },
        total_not_view_time: { back: 0, obst: 0, geom: 0, stop: 0, unkn: 0 },
        video: {
          video_played_time: -1,
          quartile: -1,
          omsdk_duration: -1,
          omest_duration: -1,
          video_duration: -1,
        },
        altsizes: [],
      },
    },
    oi = 50,
    ai = 30,
    ei = 242500,
    fi = {
      mrcCurrentTimePeriod: 0,
      mrcMaxTimePeriod: 0,
      mrcTotalTime: 0,
      mrcPeriodsCounter: 0,
      MRC_MIN_PCT: oi,
      MRC_MIN_TIME: 1e3,
      groupmCurrentTimePeriod: 0,
      groupmMaxTimePeriod: 0,
      groupmTotalTime: 0,
      groupmPeriodsCounter: 0,
      videoStartTimestamp: null,
      GROUPM_MIN_PCT: 100,
      GROUPM_MIN_TIME: 1e3,
      lastTimestamp: 0,
      viewableTimestamp: 0,
      lastViewablePct: 0,
      lastViewablePctOnPausedVideo: 0,
      lastReason: Zt("g`g|"),
      sessionEndHandler: null,
      stopMrcViewableTimeout: null,
      session30SecondsTimeout: null,
      obuHandler: null,
      start: Date.now(),
      omidSessionStartEvent: !1,
      omidImpressionEvent: !1,
      startMeasuring: function () {
        if (((ri.startTime = kt.KV().ma().startTime()), rt.omid.ZL()))
          (ri.method = Zt("}cev")),
            (ri.norun = [$n]),
            rt.omid.CL() || ri.norun.push(Yn),
            aT.sub(l.OMID, function (t) {
              kt.DR("uv", function () {
                fi.omidParser(t);
              });
            });
        else if (rt.vpaid.zV())
          (ri.method = Zt("d~m{v")),
            (ri.mediatype = Zt("dghw}")),
            ni.startMeasuring();
        else {
          if (!fi.viewabilityCapable())
            return (ri.method = Zt("|abw")), void fi.reportNoViewability();
          (ri.method = Zt("{an#")),
            (ri.mediatype = Zt("vg\x7fb~ou")),
            ni.startMeasuring();
        }
        (fi.obuHandler = v.subscribe(2, fi.stopMeasuring)),
          (fi.sessionEndHandler = rt.PA.timeout(this, fi.stopMeasuring, kt.lm)),
          (fi.session30SecondsTimeout = rt.PA.timeout(
            this,
            function () {
              (fi.session30SecondsTimeout = null),
                fi.updateTimeAccumulator(
                  fi.lastViewablePct,
                  Date.now(),
                  fi.lastReason
                );
            },
            3e4
          )),
          fi.reportViewability();
      },
      stopMeasuring: function () {
        fi.sessionEndHandler(),
          fi.obuHandler(),
          fi.stopMrcViewableTimeout &&
            (fi.stopMrcViewableTimeout(), (fi.stopMrcViewableTimeout = null)),
          fi.session30SecondsTimeout &&
            (fi.session30SecondsTimeout(), (fi.session30SecondsTimeout = null)),
          ri.method === Zt("{an#") && ni.removeListeners(),
          fi.updateTimeAccumulator(0, Date.now(), Zt("g`g|")),
          fi.reportViewability();
      },
      viewabilityCapable: function () {
        var t = !1;
        return (
          (ri.norun = []),
          -1 === rt.iframe.Gz() && ri.norun.push(Zt("vk|fz")),
          (Vn.innerWidth < 5 || Vn.innerHeight < 5) &&
            (parent !== top &&
            rt.iframe.qm(parent) &&
            (parent.innerWidth > 5 || parent.innerHeight > 5)
              ? ((Vn = parent), (ri.container = Zt("bo~w|z")))
              : ri.norun.push(Zt("#v="))),
          null === ti.getMeasuredAd() && ri.norun.push(Zt("|ai~wci|f")),
          Vn[Zt("[`xw`}iqfgc|]l\x7fw`xi`")] || ri.norun.push(Zt("|ae}")),
          ti.getClaimedMediaType() === Zt("dghw}") &&
            ri.norun.push(Zt("{`zs~gh{|z")),
          0 === ri.norun.length && (delete ri.norun, (t = !0)),
          t
        );
      },
      omidParser: function (t) {
        if (
          (!0 === t[Zt("{}C")] &&
            (ri.norun = ri.norun.filter(function (t) {
              return t !== Yn;
            })),
          t.type === Zt("ukc\x7fwz~kQfm|uk") &&
            t.data.adView &&
            null !== t.data.adView.percentageInView)
        ) {
          var n = t.data.adView;
          !ri.ad.pixels_omid &&
            n.geometry &&
            n.geometry.pixels &&
            n.geometry.pixels > 0 &&
            ((ri.ad.width = Math.round(n.geometry.width)),
            (ri.ad.height = Math.round(n.geometry.height)),
            (ri.ad.pixels_omid = Math.round(n.geometry.pixels)),
            (ri.ad.pixels = ri.ad.width * ri.ad.height),
            ri.ad.pixels >= ei && (fi.MRC_MIN_PCT = ai)),
            (fi.lastViewablePctOnPausedVideo = n.percentageInView);
          var i = n.percentageInView,
            r = Zt("g`g|");
          Array.isArray(n.reasons) &&
            (n.reasons.some(function (t) {
              return t === Zt("dgieba~f") || t === Zt("qbebbkh");
            }) && (r = Zt("ukc\x7f")),
            n.reasons.some(function (t) {
              return (
                t === Zt("pooyu|cg|jiv") ||
                t === Zt("vkz{qk@}qeiv") ||
                t === Zt("|a[{|jceTaoga")
              );
            })
              ? (r = Zt("pooy"))
              : n.reasons.some(function (t) {
                  return t === Zt("zghvw`") || t === Zt("}l\x7ff`{ofwj");
                }) && (r = Zt("}l\x7ff"))),
            fi.updateTimeAccumulator(i, t.timestamp, r);
        } else if (t.type === Zt("sjYaw|E|fk~sqze}|"))
          t.data.interactionType &&
            t.data.interactionType === Zt("qbeqy") &&
            fi.videoStartTimestamp &&
            t.timestamp > fi.videoStartTimestamp + 100 &&
            fi.handleClick();
        else if (t.type === Zt("azm`f"))
          (ri.ad.video.quartile = 0),
            (fi.videoStartTimestamp = t.timestamp),
            void 0 !== t.data.duration &&
              (ri.ad.video.omsdk_duration = Math.round(1e3 * t.data.duration)),
            t.data.context &&
              t.data.context.videoElement &&
              (ri.ad.video.video_duration = Math.round(
                1e3 * t.data.context.videoElement.duration
              )),
            ii.cbVideoPlay(t.timestamp);
        else if (
          -1 !== [Zt("`k\x7fg\x7fk"), Zt("p{jtw|J{|g\x7fz")].indexOf(t.type)
        )
          ii.cbVideoPlay(t.timestamp);
        else if (
          -1 !==
          [
            Zt("boyaw"),
            Zt("p{jtw|_fs|x"),
            Zt("aeebbkh"),
            Zt("qaab~kxw"),
          ].indexOf(t.type)
        )
          ii.cbVideoPause(t.timestamp),
            t.type === Zt("qaab~kxw") && (ri.ad.video.quartile = 4);
        else if (t.type === Zt("tg~af_ys`ze~w")) {
          if (((ri.ad.video.quartile = 1), null !== fi.videoStartTimestamp)) {
            var o = t.timestamp - fi.videoStartTimestamp;
            ri.ad.video.omest_duration = Math.round(4 * o);
          }
        } else if (t.type === Zt("\x7fghb}gbf")) ri.ad.video.quartile = 2;
        else if (t.type === Zt("ffe`v_ys`ze~w")) ri.ad.video.quartile = 2;
        else if (
          -1 !== [Zt("ak\x7fa{abAfo~f"), Zt("{c|`w}\x7f{}`")].indexOf(t.type)
        ) {
          if (
            (t.data &&
              t.data.mediaType &&
              ((ri.mediatype = t.data.mediaType),
              t.data.mediaType === Zt("dghw}")
                ? (t.data.context &&
                    t.data.context.videoElement &&
                    (ri.ad.video.video_duration = Math.round(
                      1e3 * t.data.context.videoElement.duration
                    )),
                  (fi.MRC_MIN_TIME = 2e3))
                : (fi.MRC_MIN_TIME = 1e3)),
            t.type === Zt("ak\x7fa{abAfo~f") &&
              ((fi.omidSessionStartEvent = !0),
              (ri.omidSessionStartEvent = !0),
              fi.omidConfigPartner(t.data)),
            t.type === Zt("{c|`w}\x7f{}`") &&
              ((fi.omidImpressionEvent = !0),
              (ri.omidSessionStartEvent = !0),
              ri.omidinfo || (ri.omidinfo = {}),
              (ri.omidinfo.creativeType = t.data.creativeType),
              t.data &&
                t.data.mediaType === Zt("vg\x7fb~ou") &&
                t.data.creativeType === Zt("zza~Vg\x7fb~ou")))
          ) {
            var a = ti.getMeasuredAd();
            a &&
              typeof a.addEventListener === Zt("t{bqfgc|") &&
              a.addEventListener(Zt("qbeqy"), function (t) {
                t.isTrusted && fi.handleClick();
              });
          }
          fi.omidSessionStartEvent &&
            fi.omidImpressionEvent &&
            ri.norun &&
            (ri.norun = ri.norun.filter(function (t) {
              return t !== $n;
            })),
            fi.reportViewability();
        } else t.type === Zt("ak\x7fa{abT{`eaz") && fi.stopMeasuring();
      },
      omidConfigPartner: function (t) {
        var n = t.context,
          i = n.omidJsInfo,
          r = n.omidNativeInfo,
          o = n.deviceInfo;
        ri.omidinfo || (ri.omidinfo = {}),
          (ri.omidinfo.partnerName =
            (i && i.partnerName) || (r && r.partnerName) || ""),
          (ri.omidinfo.environment = n.environment),
          (ri.omidinfo.category = n.deviceCategory),
          (ri.omidinfo.adSessionType = n.adSessionType),
          (ri.omidinfo.sessionOwner = n.sessionOwner),
          (ri.omidinfo.creativeType = t.creativeType);
        var a = o ? o.os : null,
          e = n.environment,
          f = n.deviceCategory;
        a === Zt("{^mv]]")
          ? (ri.omidinfo.os = Zt("{A_"))
          : a === Zt("fxCA")
          ? (ri.omidinfo.os = Zt("QZZ?{A_"))
          : a === Zt("S`h`}gh") && f === Zt("qzz")
          ? (ri.omidinfo.os = Zt("QZZ?S`h`}gh"))
          : e === Zt("ekn")
          ? (ri.omidinfo.os = Zt("Ekn"))
          : (ri.omidinfo.os = a);
      },
      handleClick: function () {
        (ri.ad = ri.ad || {}),
          (ri.ad.mrc = ri.ad.mrc || {}),
          (ri.ad.mrc.click = 1 + (0 | ri.ad.mrc.click)),
          typeof ri.ad.mrc.only_click === Zt("g`hwtgbwv") &&
            typeof ri.ad.mrc.fulfilment_time === Zt("g`hwtgbwv") &&
            (ri.ad.mrc.only_click = !0),
          fi.reportViewability();
      },
      updateTimeAccumulator: function (t, n, i) {
        void 0 === i && (i = Zt("g`g|"));
        var r = t < 30 ? 0 : t < 50 ? 30 : t < 80 ? 50 : t < 100 ? 80 : 100,
          o = 0 === fi.lastTimestamp ? 0 : n - fi.lastTimestamp;
        (fi.lastViewablePctOnPausedVideo = r),
          ri.mediatype !== Zt("dghw}") ||
            ii.isVideoPlaying() ||
            ((r = 0), (i = Zt("azcb"))),
          (ri.ad.total_time[fi.lastViewablePct] += o),
          0 === fi.lastViewablePct &&
            (ri.ad.total_not_view_time[fi.lastReason] += o),
          (ri.ad.max_cont_time[fi.lastViewablePct] = Math.max(
            ri.ad.max_cont_time[fi.lastViewablePct],
            o
          )),
          fi.measureMRC(fi.lastViewablePct, o),
          fi.measureGroupM(fi.lastViewablePct, o),
          (fi.lastTimestamp = n),
          r !== fi.lastViewablePct && aT.pub(l.VIEWABILITY_PIV, { piv: r }),
          (fi.lastViewablePct = r),
          0 === r && (fi.lastReason = i),
          fi.manageMrcTimeout(r, n),
          fi.reportViewability();
      },
      manageMrcTimeout: function (t, n) {
        if (ri.ad.mrc.fulfilment_time || t < fi.MRC_MIN_PCT)
          return (
            fi.stopMrcViewableTimeout &&
              (fi.stopMrcViewableTimeout(), (fi.stopMrcViewableTimeout = null)),
            void (fi.viewableTimestamp = 0)
          );
        fi.viewableTimestamp || (fi.viewableTimestamp = n),
          fi.mrcCurrentTimePeriod >= fi.MRC_MIN_TIME &&
          ((ri.ad.mrc.fulfilment_time = Date.now() - fi.start),
          !0 === ri.ad.mrc.only_click)
            ? (ri.ad.mrc.only_click = !1)
            : fi.stopMrcViewableTimeout ||
              (fi.stopMrcViewableTimeout = rt.PA.timeout(
                this,
                function () {
                  (fi.stopMrcViewableTimeout = null),
                    fi.updateTimeAccumulator(
                      fi.lastViewablePct,
                      Date.now(),
                      fi.lastReason
                    );
                },
                fi.MRC_MIN_TIME
              ));
      },
      measureMRC: function (t, n) {
        t >= fi.MRC_MIN_PCT && (fi.mrcCurrentTimePeriod += n),
          fi.mrcCurrentTimePeriod >= fi.MRC_MIN_TIME &&
            ((fi.mrcTotalTime += fi.mrcCurrentTimePeriod),
            fi.mrcPeriodsCounter++,
            (fi.mrcMaxTimePeriod = Math.max(
              fi.mrcMaxTimePeriod,
              fi.mrcCurrentTimePeriod
            ))),
          t < fi.MRC_MIN_PCT && (fi.mrcCurrentTimePeriod = 0);
      },
      measureGroupM: function (t, n) {
        t >= fi.GROUPM_MIN_PCT && (fi.groupmCurrentTimePeriod += n),
          fi.groupmCurrentTimePeriod >= fi.GROUPM_MIN_TIME &&
            ((fi.groupmTotalTime += fi.groupmCurrentTimePeriod),
            fi.groupmPeriodsCounter++,
            (fi.groupmMaxTimePeriod = Math.max(
              fi.groupmMaxTimePeriod,
              fi.groupmCurrentTimePeriod
            ))),
          t < fi.GROUPM_MIN_PCT && (fi.groupmCurrentTimePeriod = 0);
      },
      reportNoViewability: function () {
        var t = { startTime: ri.startTime, norun: ri.norun };
        Ln(t);
      },
      reportViewability: function () {
        var t = fi.buildReportingSignals(ri);
        (Kn.interesting =
          Kn.interesting |
          (function (t) {
            var n = t && !t.norun,
              i = n && !!t.ad,
              r = i && !!t.ad.mrc,
              o =
                i &&
                t.ad.total_time[50] +
                  t.ad.total_time[80] +
                  t.ad.total_time[Zt("#><")],
              a =
                i &&
                t.ad.total_time[0] +
                  t.ad.total_time[30] +
                  t.ad.total_time[50] +
                  t.ad.total_time[80] +
                  t.ad.total_time[Zt("#><")] >
                  0,
              e =
                i &&
                t.ad.total_time[30] +
                  t.ad.total_time[50] +
                  t.ad.total_time[80] +
                  t.ad.total_time[Zt("#><")] >
                  0,
              f = i && !!t.ad.mrc && !!t.ad.mrc.click,
              u = 0;
            return (
              Kn.everReportedSession ||
                ((Kn.everReportedSession = !0), (u |= 2)),
              n &&
                !Kn.everReportedImpression &&
                ((Kn.everReportedImpression = !0), (u |= 4)),
              i &&
                !Kn.everReportedMeasured &&
                ((Kn.everReportedMeasured = !0), (u |= 8)),
              r &&
                !Kn.everReportedViewable &&
                ((Kn.everReportedViewable = !0), (u |= 16)),
              f &&
                !Kn.everReportedClick &&
                ((Kn.everReportedClick = !0), (u |= 32)),
              r &&
                Kn.lastViewable + 1e3 <= o &&
                ((Kn.lastViewable = o), (u |= 64)),
              a &&
                !Kn.everReportedNonZeroTime &&
                ((Kn.everReportedNonZeroTime = !0), (u |= 128)),
              e &&
                !Kn.everReportedOnScreen &&
                ((Kn.everReportedOnScreen = !0), (u |= 256)),
              u
            );
          })(t)),
          (t.interest = Kn.interesting),
          (Kn.debounceState = t),
          Kn.interesting &&
            (Kn.debounceTimer ||
              (Kn.debounceTimer = setTimeout(function () {
                Ln(Kn.debounceState),
                  (Kn.debounceTimer = 0),
                  (Kn.interesting = 0);
              }, 100)));
      },
      buildReportingSignals: function (t) {
        var n = JSON.parse(JSON.stringify(t));
        if (
          (fi.groupmMaxTimePeriod >= fi.GROUPM_MIN_TIME &&
            ((n.ad.groupm.max_time = fi.groupmMaxTimePeriod),
            (n.ad.groupm.avg_time = Math.round(
              fi.groupmTotalTime / fi.groupmPeriodsCounter
            ))),
          fi.mrcMaxTimePeriod >= fi.MRC_MIN_TIME &&
            ((n.ad.mrc.max_time = fi.mrcMaxTimePeriod),
            (n.ad.mrc.avg_time = Math.round(
              fi.mrcTotalTime / fi.mrcPeriodsCounter
            ))),
          n.mediatype !== Zt("dghw}"))
        )
          delete n.ad.video;
        else {
          for (var i in n.ad.video)
            -1 === n.ad.video[i] && delete n.ad.video[i];
          0 === Object.keys(n.ad.video).length && delete n.ad.video;
        }
        return (
          0 === Object.keys(n.omidinfo).length && delete n.omidinfo,
          0 === Object.keys(n.ad.mrc).length && delete n.ad.mrc,
          0 === Object.keys(n.ad.groupm).length && delete n.ad.groupm,
          0 === n.ad.altsizes.length && delete n.ad.altsizes,
          Array.isArray(n.norun) &&
            -1 !== n.norun.indexOf(Yn) &&
            (n.norun = n.norun.filter(function (t) {
              return t !== $n;
            })),
          Array.isArray(n.norun) &&
            (0 === n.norun.length
              ? delete n.norun
              : ((n[Zt("Moh")] = n.ad), delete n.ad)),
          n
        );
      },
    };
  function ui(t, n) {
    if (((Vn = n), (Jn = 0), Un(t), kt.KV().ma().yj()[Zt("dyn")])) {
      var i = aT.sub(l.AD_FOUND, function (t) {
        (ti.cachedMeasuredAd = t), fi.startMeasuring(), aT.unsub(l.AD_FOUND, i);
      });
      Ln({ norun: [Zt("|axafo~fwj")] }),
        kt
          .KV()
          .Bd()
          .timeout(function () {
            Ln = function () {};
          }, kt.lm);
    }
  }
  var ci,
    Zi = {
      immediate: [
        function (t) {
          if (!rt.vpaid.zV()) return Nt;
          var n = function (n, i, r) {
            if (n && typeof n.subscribe === Zt("t{bqfgc|")) {
              t({ vpaid: { events: i } });
              var o = (function (t) {
                var n = { piv: null, plv: null, seq: 0 };
                function i() {
                  if (t && typeof t.getAdVolume === Zt("t{bqfgc|")) {
                    var i,
                      r = t.getAdVolume();
                    -1 !== r &&
                      (n.plv =
                        null == (i = r) || -1 === i
                          ? null
                          : i >= 0 && i <= 1
                          ? Math.round(100 * i)
                          : i >= 0 && i <= 100
                          ? Math.round(i)
                          : null);
                  }
                }
                return {
                  updatePiv: function (t) {
                    t && typeof t.piv === Zt("|{apw|") && (n.piv = t.piv);
                  },
                  updateVolume: i,
                  sendIf: function (t) {
                    var r = (function (t) {
                      return Qt[t] || null;
                    })(t);
                    r &&
                      (i(),
                      (function (t, n, i, r) {
                        var o = {
                            schema: _t,
                            kind: 2,
                            src: 2,
                            seq: r,
                            ts: Date.now(),
                            evt: n,
                          },
                          a = (function () {
                            var t = kt.KV().ma().ki(),
                              n = t && t.vs;
                            return null == n || "" === n ? null : String(n);
                          })();
                        a && (o.vs = a);
                        var e = rt.object.Mz(Object.assign(o, i)),
                          f = new et([{ quartiles: e }], "qt");
                        Tt.XN(f, function () {});
                      })(0, r, { piv: n.piv, vol: n.plv }, n.seq),
                      (n.seq = n.seq + 1));
                  },
                };
              })(n);
              aT.sub(l.VIEWABILITY_PIV, function (t) {
                o.updatePiv(t);
              });
              var a = function (t) {
                  aT.pub(l.VPAID_AD_LOADED, {
                    width: n.getAdWidth(),
                    height: n.getAdHeight(),
                    timestamp: t.timestamp,
                    environmentVars: r,
                  });
                },
                e = function (t) {
                  aT.pub(l.VPAID_AD_VIDEO_START, { timestamp: t.timestamp });
                };
              i.forEach(function (t) {
                t.type === Zt("SjZ}~{awQfm|uk") && o.updateVolume(),
                  o.sendIf(t.type),
                  t.type === Zt("Sj@}sjiv")
                    ? a(t)
                    : t.type === Zt("SjZ{vkcAfo~f") && e(t);
              }),
                rt.vpaid.RF().forEach(function (i) {
                  n.subscribe(function (n) {
                    var r = Date.now(),
                      f = { type: i, data: n, timestamp: r };
                    t({ vpaid: { events: [f] } }),
                      i === Zt("SjZ}~{awQfm|uk") && o.updateVolume(),
                      o.sendIf(i),
                      i === Zt("Sj@}sjiv")
                        ? a(f)
                        : i === Zt("SjZ{vkcAfo~f") && e(f);
                  }, i);
                });
            }
          };
          return rt.vpaid.Zk()
            ? (rt.vpaid.OR(n), Nt)
            : ((xt = setInterval(function () {
                rt.vpaid.Zk() &&
                  (clearInterval(xt), clearTimeout(jt), rt.vpaid.OR(n));
              }, 200)),
              (jt = setTimeout(function () {
                clearInterval(xt);
              }, 6e4)),
              Nt);
        },
        function (t) {
          var n,
            i,
            r = kt.KV().ma().ki(),
            o = String(r.dm || "").toLowerCase();
          o.indexOf("x") > -1 &&
            ((n = o.slice(0, o.indexOf("x"))),
            (i = o.slice(o.indexOf("x") + 1)));
          var a = kt.KV().UR(100, Zt("qa~?vaa")),
            e = Ut(n, i),
            f = new Dn(r, e, a);
          return (
            kt.DR("Rk", function (n, i) {
              var r = (kt.KV().ma().ki().md + "").toLowerCase(),
                o = -1 !== In.indexOf(r),
                e = rt.omid.loadedByOmid() || rt.omid.yo();
              if (a) {
                var u,
                  c =
                    !(!window.parent || window.parent === window) &&
                    rt.iframe.qm(window.parent),
                  Z = -1 === rt.iframe.Gz();
                t(
                  (((u = {})[_n] = {
                    hasParentAccess: c,
                    isTopWindow: Z,
                    loadedByOmid: e,
                    isVideo: o,
                  }),
                  u)
                ),
                  On.isImageSupported(i, function (n) {
                    kt.DR("Rk", function (i, r) {
                      var o;
                      t((((o = {})[_n] = { isImageSupported: n }), o));
                    });
                  });
              }
              if (e) {
                var s;
                t((((s = {})[_n] = { adFound: !1, omid: !0 }), s));
                var w = o,
                  v = !1,
                  h = !1,
                  b = !1,
                  d = !1,
                  g = function (n) {
                    var i;
                    !d &&
                      v &&
                      ((w && !b) ||
                        ((w || h) &&
                          ((d = !0),
                          t((((i = {})[_n] = { renderBegun: !0 }), i)),
                          n.pub(l.AD_FOUND, window.document.body))));
                  };
                i.sub(l.OMID, function (t) {
                  kt.DR("Rk", function (n, i) {
                    t.type === Zt("ak\x7fa{abAfo~f")
                      ? ((v = !0),
                        t.data &&
                          t.data.creativeType === Zt("dghw}") &&
                          (w = !0),
                        g(i))
                      : t.type === Zt("{c|`w}\x7f{}`")
                      ? ((h = !0), g(i))
                      : t.type === Zt("azm`f") && ((b = !0), g(i));
                  });
                });
              } else {
                if (rt.vpaid && rt.vpaid.zV && rt.vpaid.zV()) {
                  var m = !1,
                    k = !1,
                    z = !1,
                    y = function () {
                      !z &&
                        m &&
                        k &&
                        ((z = !0), f.queueRenderBegunWhenAllowed(t));
                    };
                  return (
                    i.sub(l.VPAID_AD_LOADED, function (t) {
                      kt.DR("Rk", function (n, i) {
                        var r = t.environmentVars || {},
                          o = r.videoSlot,
                          a = r.slot,
                          e = null;
                        if (En(o) && o.tagName === Zt("DGHW]")) e = o;
                        else {
                          var f = window,
                            u = Zt("akm`qfOg`|i|f");
                          if (En(a)) {
                            var c =
                              a.ownerDocument && a.ownerDocument.defaultView;
                            c &&
                              rt.iframe.qm(c) &&
                              ((f = c), (u = Zt("abcfEgbv}y")));
                          }
                          var Z = pn(f, u, null, Ut(t.width, t.height));
                          Z && Z.element && (e = Z.element);
                        }
                        i.pub(l.AD_FOUND, e || window.document.body),
                          (m = !0),
                          y();
                      });
                    }),
                    void i.sub(l.VPAID_AD_VIDEO_START, function () {
                      kt.DR("Rk", function () {
                        (k = !0), y();
                      });
                    })
                  );
                }
                if (!o) {
                  var p = !1;
                  i.sub(l.OMID, function (n) {
                    kt.DR("Rk", function () {
                      n &&
                        n.type === Zt("{c|`w}\x7f{}`") &&
                        ((p = !0), f.notifyOmidImpression(t));
                    });
                  }),
                    rt.omid.eN() &&
                      (f.requireOmidImpression(),
                      p && f.notifyOmidImpression(t));
                }
                f.listenForChangesPolling(t, o);
              }
            }),
            function () {
              f.stop();
            }
          );
        },
        ui,
        function (t) {
          !(function (t) {
            var n,
              i = rt.eG.create(5),
              r =
                ((n = { piv: null, plv: null, dv: null, isApp: !1, seq: 0 }),
                {
                  updateState: function (t) {
                    if (t && t.type) {
                      if (
                        (t.type === Zt("ak\x7fa{abAfo~f") &&
                          t.data &&
                          t.data.context &&
                          ((n.isApp = t.data.context.environment === Zt("s~|")),
                          n.isApp || (n.dv = null)),
                        t.type === Zt("ukc\x7fwz~kQfm|uk") &&
                          t.data &&
                          t.data.adView)
                      ) {
                        var i = t.data.adView.percentageInView;
                        typeof i === Zt("|{apw|") && (n.piv = Math.round(i));
                      }
                      (t.type !== Zt("azm`f") &&
                        t.type !== Zt("da`g\x7fkOzs`kw")) ||
                        (function (t, n) {
                          n &&
                            (typeof n.mediaPlayerVolume === Zt("|{apw|") &&
                              (t.plv = Wn(n.mediaPlayerVolume)),
                            t.isApp &&
                              typeof n.deviceVolume === Zt("|{apw|") &&
                              (t.dv = Wn(n.deviceVolume)));
                        })(n, t.data);
                    }
                  },
                  sendIf: function (t) {
                    (function (t) {
                      return -1 !== Cn.indexOf(t);
                    })(t) &&
                      ((function (t, n, i, r) {
                        var o = {
                            schema: Fn,
                            kind: 2,
                            src: 1,
                            seq: r,
                            ts: Date.now(),
                            evt: n,
                          },
                          a = (function () {
                            var t = kt.KV().ma().ki(),
                              n = t && t.vs;
                            return null == n || "" === n ? null : String(n);
                          })();
                        a && (o.vs = a);
                        var e = rt.object.Mz(Object.assign(o, i)),
                          f = new et([{ quartiles: e }], "qt");
                        Bn.XN(f, function () {});
                      })(
                        0,
                        t,
                        (function (t) {
                          return {
                            piv: t.piv,
                            vol:
                              ((n = t.plv),
                              (i = t.dv),
                              (r = t.isApp),
                              null === n
                                ? null
                                : r
                                ? null === i
                                  ? null
                                  : Math.round((n / 100) * (i / 100) * 100)
                                : n),
                          };
                          var n, i, r;
                        })(n),
                        n.seq
                      ),
                      (n.seq = n.seq + 1));
                  },
                });
            aT.sub(l.OMID, function (n) {
              kt.DR("cj", function () {
                !(function (n) {
                  if (n)
                    if (n.hasOwnProperty(Zt("{}C"))) t({ omid2: n });
                    else {
                      if (
                        n.type &&
                        -1 !==
                          [Zt("ak\x7fa{abAfo~f"), Zt("{c|`w}\x7f{}`")].indexOf(
                            n.type
                          ) &&
                        !Rn[n.type]
                      ) {
                        var o = {};
                        (o[n.type] = n), (Rn[n.type] = n), t({ omid2: o });
                      }
                      i.checkLimit(n.type) && t({ omid2: { events: [n] } }),
                        r.updateState(n),
                        r.sendIf(n.type);
                    }
                })(n);
              });
            });
          })(t);
        },
      ],
      dom: [],
      iframe: [],
      runPastSessionEnd: [ui],
    },
    si = kt.KV();
  function wi(t) {
    ci.addChecker(t);
  }
  try {
    var vi = window,
      hi = new Ot(),
      li = (function (t, n) {
        var i = t.document,
          r = t.navigator,
          o = Zt("akbvPkmq}`") in r,
          a = Zt("[`x~") in t,
          e = Zt("\x7fav[|`i`Am~ww`T") in t,
          f = Zt("qf~}\x7fk") in t,
          u = Zt("EknSa}i\x7fpbu") in t;
        if (u) return !0;
        if (!e && o) return !0;
        if (!e && !f && a) return !0;
        try {
          var c = {
              ch: f,
              url: Zt("G\\@") in t,
              v8l: Zt("d6@}qo`w") in t,
              mpc: e,
              dct: !!i[Zt("qabfsgba")],
              hbe: Zt("ZZA^Pbcqy\x7fy}fkI~wci|f") in t,
              rph: Zt("`kk{azi`B|cf}mc~Zobv~k~") in r,
              dmo: Zt("vaog\x7fkbf_ahw") in i,
              sfe: !!t[Zt("AXKT{bxw`K`w\x7fkbf")],
              cgrv:
                !!t[Zt("q|ubfa")] &&
                !!t[Zt("q|ubfa")][Zt("ukx@s`h}\x7fXm~gk\x7f")],
              o: Zt("}|ew|zmf{ab") in t,
              vv: Zt("dg\x7fgsbZ{wy|}`z") in t,
              ex: 0,
              ts: Date.now(),
              was: u,
              intl: a,
              bea: o,
            },
            Z = "";
          try {
            Z = JSON.stringify(c);
          } catch (t) {}
          var s = n.protocol(),
            w = n.domain(),
            v = n.apiVersion(),
            h = s + Zt("(!#") + w + "/" + v,
            l = n.PR(),
            b = n.customerId(),
            d = n.pagespeedVersion(),
            g = h + "/" + b + "/" + l,
            m = (function () {
              var t = Zt("}tSb~3="),
                i = n.ki();
              for (var r in i)
                i.hasOwnProperty(r) &&
                  (t +=
                    "&" +
                    encodeURIComponent(r) +
                    "=" +
                    encodeURIComponent(i[r]));
              return i.hasOwnProperty(Zt("b}z")) ? t : t + Zt("4~\x7fd/") + d;
            })();
          zt(g + Zt('={"u{h3{|gx/"(\x7fgb3') + encodeURIComponent(Z) + "&" + m);
        } catch (t) {}
        return !1;
      })(vi, hi);
    li &&
      (si.setConfig(hi),
      (ci = new qt(si)).setCheckerConfig(Zi),
      si.setCheckerManager(ci),
      (globalThis.Sj = wi),
      (globalThis.aT = si.getCollector()),
      (globalThis.JW = function () {
        return si.init();
      }));
  } catch (t) {
    console.error(t);
  }
  function bi(t) {
    (this.queue = t), (this.zm = kt.KV());
  }
  kt.DR("Vl", function (t, n) {
    wi({
      name: "Vl",
      flags: 12,
      Iy: function (t, n) {
        var i = n.top;
        if (rt.iframe.YX()) {
          var r,
            o,
            a = i.document,
            e = rt.dom.qu(a);
          a.documentElement.scrollHeight < 5e3
            ? (o = rt.dom.xm(a.body))
            : (r = !0),
            t({ DOMcounters: { docAll: e, bodyiText: o, scrollTall: r } }, !0);
        }
      },
    });
  }),
    kt.DR("nk", function (t, n) {
      var i = rt.object.QX,
        r = kt.KV();
      wi({
        name: "nk",
        flags: 12,
        gE: 32768,
        Iy: function (t, n) {
          if (!r.ma().yj()[Zt("sj\x7f")]) {
            var o = r.UR(100, Zt("sj\x7f~")),
              a = n.top;
            if (rt.iframe.YX()) {
              var e = { list: [], metrics: {}, globals: {} };
              !(function (t, n) {
                var r = (function (n) {
                    var i = n.getElementsByTagName(Zt("{h~s\x7fk")),
                      r = [];
                    function o(t) {
                      var n = rt.wX.gd(t);
                      return {
                        name: (t.name || "").substr(0, 128) || void 0,
                        src: (t.src || "").substr(256) || void 0,
                        title: (t.title || "").substr(0, 64) || void 0,
                        x: n.x,
                        y: n.y,
                        width: n.width,
                        height: n.height,
                      };
                    }
                    function a(t, n) {
                      return (
                        (t[Zt("q}\x7f[v")] =
                          (n.id || "").substr(0, 128) || void 0),
                        (t[Zt("qbmaa")] =
                          (n.className || "").substr(0, 64) || void 0),
                        (t[Zt("voxs")] =
                          (Object.keys(n.dataset).length
                            ? JSON.stringify(n.dataset).substr(0, 256)
                            : "") || void 0),
                        (t[Zt("s|es")] =
                          (n.ariaLabel || "").substr(0, 64) || void 0),
                        (t[Zt("aobvpat")] =
                          n.getAttribute(Zt("aobvpat")) || void 0),
                        (t[Zt("azu~w")] =
                          n.getAttribute(Zt("azu~w")) || void 0),
                        (t[Zt("a|oV}m")] =
                          (n.srcdoc || "").substr(0, 256) || void 0),
                        (t[Zt("zza~")] = n.outerHTML.substr(0, 512)),
                        (t[Zt("sjO}|zm{|k~")] = Zt("{h~s\x7fk")),
                        t
                      );
                    }
                    for (var e = 0; e < i.length; e++) {
                      var f = o(i[e]);
                      if (rt.ads.qc(f)) {
                        var u = a(f, i[e]),
                          c = t.getComputedStyle(i[e]),
                          Z = parseFloat(c.opacity),
                          s = parseInt(c.zIndex, 10),
                          w = c.visibility;
                        (0 === Z ||
                          (Z < 1 && !isNaN(s) && s < -100) ||
                          w === Zt("zghvw`")) &&
                          (u[Zt("{}E|dg\x7f{pbi")] = !0),
                          r.push(u);
                      }
                    }
                    return r;
                  })(t.document),
                  o = (function (t, n) {
                    var r,
                      o = t.document,
                      a = [],
                      e = [],
                      f = Zt("}{xp`oe|"),
                      u = Zt("Mzmp}a`s"),
                      c = Zt("`kzq}`xw|z"),
                      Z = Zt("`kbvw|ivEghuwz\x7f"),
                      s = Zt("@kzQ}`xw|z@}sji`"),
                      w = Zt("vgz"),
                      v = Zt("qabfsgbw`"),
                      h = Zt("voxs"),
                      l = !(!i(t[u]) || !t[u][Zt("`kk{azi`wj")]),
                      b = !!(i(t[u]) && t[u][0] && t[u][0][Zt("qabfsgbw`")]),
                      d = i(t[f]),
                      g = i(t[c]),
                      m = i(t[s]) && rt.object.mR(t[s]);
                    function k(t) {
                      for (var n = [], i = 0; i < t.length; i++) {
                        for (var r = t[i], o = !1, a = 0; a < t.length; a++)
                          if (i !== a && t[a].contains(r)) {
                            o = !0;
                            break;
                          }
                        o || n.push(r);
                      }
                      return n;
                    }
                    function z(t, n, i) {
                      var r = rt.wX.gd(i);
                      return {
                        cssId: (i.id || "").substr(0, 128) || void 0,
                        class: (i.className || "").substr(0, 64) || void 0,
                        style: i.getAttribute(Zt("azu~w")) || void 0,
                        html: i.outerHTML.substr(0, 512),
                        x: r.x,
                        y: r.y,
                        width: r.width,
                        height: r.height,
                        cssSel: t,
                        plat: n,
                        adContainer: Zt("|ox{dk"),
                      };
                    }
                    function y(t, n, i) {
                      for (var r = [], o = 0; o < i.length; o++)
                        r.push(z(t, n, i[o]));
                      return r;
                    }
                    return (
                      (l || b || d || g || m) &&
                        ((n.globals[u] = l),
                        (n.globals[u + Zt("Qabf")] = b),
                        (n.globals[f] = d),
                        (n.globals[c] = g),
                        (n.globals[s] = m)),
                      b &&
                        (a = y(8, u, [
                          o.getElementById(t[u][0][Zt("qabfsgbw`")]),
                        ])),
                      !a.length &&
                        (a = y(
                          1,
                          u,
                          k(
                            o.getElementsByClassName(
                              "trc" + Zt("M|i~szivM") + v
                            )
                          )
                        )),
                      !a.length &&
                        (a = y(
                          2,
                          u,
                          k(
                            o.querySelectorAll(
                              w + "[" + h + Zt("?hiwv#as{`!") + v + Zt("?ghO")
                            )
                          )
                        )),
                      (r = y(
                        3,
                        f,
                        k(o.getElementsByClassName(f.toUpperCase()))
                      )),
                      g && Array.isArray(t[c][Z]) && (e = y(6, c, t[c][Z])),
                      !e.length &&
                        m &&
                        Object.keys(t[s]).length > 0 &&
                        (e = y(7, c, [o.getElementById(Object.keys(t[s])[0])])),
                      !e.length &&
                        (e = y(
                          4,
                          c,
                          k(o.getElementsByClassName("rc" + Zt("?yo")))
                        )),
                      [].concat(r, e, a)
                    );
                  })(t, n);
                (n.list = [].concat(r, o)),
                  (function (n) {
                    var i = n.list,
                      r = {
                        adsAboveFoldCount: 0,
                        adsBelowFoldCount: 0,
                        adPixelsAboveFold: 0,
                        adPixelsBelowFold: 0,
                        highestAd: 0,
                        adPixelsOnPage: 0,
                        adsOnPageCount: 0,
                        invisibleAdsCount: 0,
                      };
                    function o(t, n, i) {
                      i[Zt("sjXkbk")] = Zt("g`hwfk~\x7f{`iv");
                      var r = i.y + Math.floor(i.height / 2),
                        o = i.x + Math.floor(i.width / 2);
                      r < t.innerHeight && r > 0 && o < t.innerWidth && o > 0
                        ? (n.adsAboveFoldCount++,
                          (i.adType = Zt("slcdwHc~v")),
                          (n.adPixelsAboveFold += i.width * i.height || 0))
                        : (n.adsBelowFoldCount++,
                          (n.adPixelsBelowFold += i.width * i.height || 0),
                          (i.adType = Zt("pk`}eHc~v")));
                    }
                    for (var a = 0; a < i.length; a++) {
                      var e = i[a];
                      e.isInvisible
                        ? r.invisibleAdsCount++
                        : (o(t, r, e),
                          (r.adPixelsOnPage += e.height * e.width),
                          (r.highestAd =
                            e.height > r.highestAd ? e.height : r.highestAd));
                    }
                    (r.adsOnPageCount = i.length - r.invisibleAdsCount),
                      (n.metrics = rt.object.hV(n.metrics, r));
                  })(n);
              })(a, e),
                (function (t, n) {
                  var i = {
                    height: window.innerHeight,
                    width: window.innerWidth,
                    location: t.location.href,
                    title: t.title || "",
                    name: t.name || "",
                  };
                  Object.assign && Object.assign(i, rt.wX.qY(t)),
                    (i.height = Math.max(
                      i.height || 0,
                      i.pageHeight || 0,
                      rt.wX.NU(t.document) || 0
                    )),
                    (i.width = Math.max(i.width || 0, i.pageWidth || 0));
                  var r,
                    o,
                    a,
                    e,
                    f,
                    u = i.width * i.height,
                    c = {
                      contentPixels: u,
                      adToContentRatio:
                        u > 0
                          ? Math.round((n.metrics.adPixelsOnPage / u) * 100)
                          : null,
                      accessToContent:
                        ((f = !1),
                        i.height < 40 || i.width < 40
                          ? ((f = !1), (r = Zt("qabfAcm~~")))
                          : rt.ads.qc(i, void 0, 0.1)
                          ? ((f = !1), (r = Zt("fa|Sv")))
                          : i.pageHeight < 1.2 * screen.availHeight
                          ? ((f = !1), (r = Zt("qabf.3\x7fq`ki|")))
                          : n.metrics.highestAd > 0 &&
                            i.pageHeight > 1.5 * n.metrics.highestAd
                          ? ((f = !0), (r = Zt("qabf,oh")))
                          : ((o = i.pageHeight),
                            (e = (
                              kt.KV().ma().ki().dm || ""
                            ).toLowerCase()).indexOf("x") > -1 &&
                              (a = e.slice(e.indexOf("x") + 1, e.length)),
                            o > 1.5 * parseFloat(a)
                              ? ((f = !0), (r = Zt("qz6v\x7f")))
                              : ((f = !1), (r = Zt("g`g")))),
                        { hasAccess: f, reason: r }),
                    };
                  n.metrics = rt.object.hV(n.metrics, c);
                })(a, e),
                o || delete e.list,
                t({ ads: e }, !0);
            }
          }
        },
      });
    }),
    kt.DR("wS", function (t, n) {
      var i = rt.IO.TU,
        r = rt.object.QX,
        o = rt.kM.Nk,
        a = rt.kM.Nk,
        e = rt.PA.timeout;
      wi({
        name: "wS",
        flags: 4,
        Iy: function (t, n) {
          function f(t, n, i, r) {
            var o,
              a = setInterval(function () {
                try {
                  t() && (clearInterval(a), clearTimeout(o), n());
                } catch (t) {}
              }, i);
            o = setTimeout(function () {
              clearInterval(a);
            }, r);
          }
          if (rt.iframe.YX()) {
            f(
              function () {
                if (
                  typeof n.top[Zt("M}i|f|uVwlyu[j\x7f")] !== Zt("}lfwqz") ||
                  null === n.top[Zt("M}i|f|uVwlyu[j\x7f")]
                )
                  return !1;
                try {
                  return (
                    -1 !==
                    JSON.stringify(n.top[Zt("M}i|f|uVwlyu[j\x7f")]).indexOf(
                      Zt("ukf{vjczxicuwjkx|abp}hf{ub`bycnt")
                    )
                  );
                } catch (t) {
                  return !1;
                }
              },
              function () {
                var n;
                return t(
                  { ai: ((n = {}), (n[Zt("\x7f{\x7fwvle")] = 1), n) },
                  !1
                );
              },
              500,
              5e3
            );
            var u,
              c,
              Z,
              s,
              w = Zt("MQas|{\x7f]`gk{|"),
              h = Zt("MQas|{\x7f]`gk{|o`B}}x_w}\x7fsuk");
            (window.top[w] || window.top[h]) && t({ ai: { mns: 1 } }, !1),
              (w = Zt('{jo"M=8!')),
              window.top.document.documentElement.classList.contains(w) &&
                t({ ai: { bu1: 1 } }, !1),
              f(
                function () {
                  return r(window.top[Zt("MQog`}c`VkzF}a`a[`fwqziv")]);
                },
                function () {
                  var n;
                  return t({ ai: ((n = {}), (n[Zt("q|\x7f`")] = 1), n) }, !1);
                },
                1e3,
                1e4
              ),
              window.top[Zt("MQ_[UCMMM")] &&
                t({ ai: ((u = {}), (u[Zt("aias")] = 1), u) }, !1),
              null !==
                window.top.document.getElementById(
                  Zt("qbmgvk!sukbf?}x}b#o}|zm{|k~")
                ) && t({ ai: ((c = {}), (c[Zt("qbo`")] = 1), c) }, !1),
              null !==
                window.top.document.documentElement.getAttribute(
                  Zt("voxs?difaee?fon?{j")
                ) && t({ ai: ((Z = {}), (Z[Zt("s`xu`")] = 1), Z) }, !1),
              typeof window.top[Zt("_ahw~Mc|fktf")] === Zt("t{bqfgc|") &&
                t({ ai: ((s = {}), (s[Zt("\x7f{\x7fw\x7fmj")] = 1), s) }, !1);
          } else if (typeof n[Zt("_ahw~Mc|fktf")] === Zt("t{bqfgc|")) {
            var l;
            t({ ai: ((l = {}), (l[Zt("\x7f{\x7fw\x7fmj")] = 1), l) }, !1);
          }
          function b() {
            var i = {};
            r(n[Zt("Mkzw|z@{azi|w|X`smgw`Gb{fgm~{tiv")]) &&
              (i[Zt("p{\x7fw")] = 1),
              r(n[Zt("ML~}e}i`G}i}|ZmpDg\x7f{pg`{fwOzs`kw")]) &&
                (i[Zt("p{\x7fwq")] = 1),
              Object.keys(i).length && t({ ai: i }, !1);
          }
          f(
            function () {
              return (
                r(window[Zt("ubcpsbC|wZe\x7fwGbq`kaw|zI~wci|f}")]) ||
                r(window[Zt("ubcpsbH}\x7fJibffAsb")]) ||
                r(window[Zt("Ubcpsb_ykxi`|H~s\x7fkE|vkt")])
              );
            },
            function () {
              var n;
              return t({ ai: ((n = {}), (n[Zt("aez")] = 1), n) }, !1);
            },
            1e3,
            1e4
          ),
            (o = v.subscribe(2, b)),
            (a = e(this, b, kt.iI - 1e4));
          try {
            var d;
            r(Element.prototype.addEventListener) &&
              -1 !==
                i(Element.prototype.addEventListener).indexOf(
                  Zt("voxs?fma?gbfw|mqfgzw?beafkbw`")
                ) &&
              t({ ai: ((d = {}), (d[Zt("zlmu")] = 1), d) }, !1);
          } catch (t) {}
          if (
            (f(
              function () {
                var t = n[Zt("qaba}bi")] && n[Zt("qaba}bi")][Zt("~ak")],
                  r = i(t);
                return (
                  r.indexOf(Zt("qo|fg|i^}iM`u{aw|z\x7f")) > -1 &&
                  r.indexOf(Zt("tbyazZe\x7fwayf[j")) > -1
                );
              },
              function () {
                var n;
                return t({ ai: ((n = {}), (n[Zt("zlosu")] = 1), n) }, !1);
              },
              1e3,
              5e3
            ),
            r(Element.prototype.attachShadow))
          ) {
            var g,
              m = i(Element.prototype.attachShadow),
              k = Zt("f{~|aze~w"),
              z = Zt("zmmbfmds"),
              y = Zt('|ox{dkMffoozAfmv}y"qsb`:ffea'),
              p = Zt("{`hwj \x7fzsjce@acf:zd{a");
            k in window &&
              z in window &&
              (-1 !== m.indexOf(y) || -1 !== m.indexOf(p)) &&
              t({ ai: ((g = {}), (g[Zt("plmu")] = 1), g) }, !1);
          }
          try {
            if (OffscreenCanvas) {
              var x,
                j = new OffscreenCanvas(256, 256),
                q = Zt("eknu~"),
                M = j.getContext(q),
                S = i(M[Zt("ukxAg~|}`zivWvxw|}e}|}")]);
              S &&
                -1 !== S.indexOf(Zt("3ktfw`\x7f{}`\x7f<{`o~gjia:")) &&
                t({ ai: ((x = {}), (x[Zt("azmu")] = 1), x) }, !1);
            }
          } catch (t) {}
          var A;
          window.document.getElementById(Zt("ukbabo~y?h`}sz!ps|")) &&
            t({ ai: ((A = {}), (A[Zt("u}mu")] = 1), A) }, !1);
          try {
            var O = Zt('0HG2U|cfw}g2\\kyw0",as`\x7f?ak~{t'),
              _ = Zt("`in") + Zt(":<9'>.>'&\", '?%"),
              Q = document.createElement(Zt("vgz"));
            (Q.style.display = Zt("|abw")), document.body.appendChild(Q);
            var T = window.getComputedStyle(Q);
            if (T.fontFamily !== O && T.backgroundColor !== _) {
              Q.id = Zt('b~`j?okw|z!"M>!}dk~~sw!afa|?p{xf}`');
              var N,
                D = window.getComputedStyle(Q);
              D.fontFamily === O &&
                D.backgroundColor === _ &&
                t({ ai: ((N = {}), (N[Zt("qaawfok")] = 1), N) }, !1);
            }
            Q.parentNode.removeChild(Q);
          } catch (t) {}
          f(
            function () {
              return r(n[Zt("MQJW^BCGMZMPMGHMM")]);
            },
            function () {
              var n;
              return t({ ai: ((n = {}), (n[Zt("tlmu")] = 1), n) }, !1);
            },
            1e3,
            5e3
          );
          var I = 0;
          f(
            function () {
              return (
                I++,
                null !== document.getElementById(Zt("qahwj#muw`x?}xi`~ou?`acf"))
              );
            },
            function () {
              var n;
              return t({ ai: ((n = {}), (n[Zt("qjtq`")] = I), n) }, !1);
            },
            500,
            5e3
          );
          var E = 0;
          f(
            function () {
              return (
                E++,
                null !==
                  document.getElementById(
                    Zt("qahwj#n`}y\x7fw`#\x7f{vkns`#o}\x7fci|f}!`}ax")
                  )
              );
            },
            function () {
              var n;
              return t({ ai: ((n = {}), (n[Zt("qjtsu")] = E), n) }, !1);
            },
            500,
            5e3
          );
          try {
            var F =
              n[Zt("|oz{uox}`")] && n[Zt("|oz{uox}`")][Zt("q|ivw`x{sb\x7f")];
            if (r(F)) {
              var C,
                B = F[Zt("ukx")],
                W = F[Zt("q|isfk")],
                P = Zt("}(*}<~yp~goYww"),
                V = Zt("}~x{}`\x7f44a|f{aba<~yp~goYww"),
                R = function (t) {
                  var n = i(t).replace(/\s/g, "");
                  return -1 !== n.indexOf(P) || -1 !== n.indexOf(V);
                };
              ((typeof B === Zt("t{bqfgc|") && !rt.wX.IG(B) && R(B)) ||
                (typeof W === Zt("t{bqfgc|") && !rt.wX.IG(W) && R(W))) &&
                t({ ai: ((C = {}), (C[Zt("p|e|")] = 1), C) }, !1);
            }
          } catch (t) {}
        },
        stop: function () {
          o(), a();
        },
      });
    }),
    kt.DR("JT", function (t, n) {
      var i = [Zt("f|es|i`w"), Zt("agbw"), Zt("a\x7fys`k"), Zt("ao{f}axz")],
        r = new Array(i.length),
        o = new Array(i.length),
        a = new Array(i.length),
        e = new Array(i.length),
        f = null;
      function u(t, n) {
        f = t;
        var e =
          window[Zt("]hj~{`iSgje}Qabfwvx")] ||
          window[Zt("ekny{zCttbe|wOyv{aO}|zijf")];
        if (!rt.object.QX(e)) return t({ ac: { e: -1 } }), !1;
        (r[n] = new e(1, 44100, 44100)),
          (o[n] = r[n].createOscillator()),
          (o[n].type = i[n]),
          o[n].frequency.setValueAtTime(1e4, r[n].currentTime),
          (a[n] = r[n].createDynamicsCompressor());
        for (
          var u = [
              [Zt("ff~wafc~v"), -50],
              [Zt("y`iw"), 40],
              [Zt("`ox{}"), 12],
              [Zt("`khgqze}|"), -20],
              [Zt("szxsqe"), 0],
              [Zt("`k`ws}i"), 0.25],
            ],
            c = 0;
          c < u.length;
          c++
        )
          void 0 !== a[n][u[c][0]] &&
            typeof a[n][u[c][0]].setValueAtTime === Zt("t{bqfgc|") &&
            a[n][u[c][0]].setValueAtTime(u[c][1], r[n].currentTime);
        return !0;
      }
      function c(t) {
        o[t].connect(a[t]),
          a[t].connect(r[t].destination),
          o[t].start(0),
          r[t].startRendering();
      }
      function s(t) {
        try {
          l(t, 0), a[0].disconnect();
        } catch (t) {
          f({ ac: { e: -4 } });
        }
      }
      function w(t) {
        try {
          l(t, 1), a[1].disconnect();
        } catch (t) {
          f({ ac: { e: -4 } });
        }
      }
      function v(t) {
        try {
          l(t, 2), a[2].disconnect();
        } catch (t) {
          f({ ac: { e: -4 } });
        }
      }
      function h(t) {
        try {
          l(t, 3), a[3].disconnect();
        } catch (t) {
          f({ ac: { e: -4 } });
        }
      }
      function l(t, n) {
        clearTimeout(e[n]);
        for (
          var i = t.renderedBuffer.getChannelData(0), r = 0, o = 4500;
          o < 5e3;
          o++
        )
          r += Math.abs(i[o]);
        var a = {};
        (a["fp" + n] = r), f({ ac: a });
      }
      wi({
        name: "JT",
        Iy: function (t) {
          if (!Z.KV().PC() && !kt.KV().ma().yj()[Zt("s{hq")])
            for (var n = [s, w, v, h], o = 0; o < i.length; o++) {
              try {
                if (!u(t, o)) break;
              } catch (t) {
                f({ ac: { e: -2 } });
                break;
              }
              r[o].oncomplete = n[o];
              try {
                c(o);
              } catch (t) {
                f({ ac: { e: -3 } });
                continue;
              }
              e[o] = setTimeout(
                function (t) {
                  (r[o].oncomplete = function () {}),
                    (r[o] = null),
                    t({ ac: { e: -5 } });
                },
                1e3,
                t
              );
            }
        },
      });
    }),
    kt.DR("Ys", function (t, n) {
      var i = kt.KV(),
        r = Z.KV(),
        o = rt.IO.TU,
        a = rt.object.QX,
        e = rt.kM.Nk,
        f = rt.kM.Nk,
        u = rt.PA.timeout;
      wi({
        name: "Ys",
        flags: 32,
        gE: 1,
        Iy: function (t, n) {
          var e = {},
            f = n[Zt("|oz{uox}`")],
            c = Zt("Mxe`f{m~Qaba}bi"),
            Z = Zt("M|ia}{~qwBcsvk~");
          (n[c] || n[Z]) && (e[Zt("x}h}\x7f")] = 1),
            Date.prototype.toLocaleDateString.toString().indexOf(Zt("sbe")) >
              0 && (e[Zt("~`gabf")] = 1);
          var s = Zt("sbi`f"),
            w = Zt("Bbmk{`kT~ok"),
            v = Zt("ak`w|gy\x7f?ghw?gbv{mmf}|"),
            h = Zt("akevw"),
            l = function (t) {
              var n = !1;
              return (
                (("" + t[s]).indexOf(w) > 0 || t.document.getElementById(v)) &&
                  ((e[h] = 1), (n = !0)),
                n
              );
            };
          !l(n) && n !== top && rt.iframe.YX() && l(top);
          var b = Zt("syia}ceg\x7f");
          n[b] && (e[Zt("syia}ci")] = 1),
            (n[Zt("qo`~Bfm|faa")] || n[Zt("M~ds|zc\x7f")]) &&
              (e[Zt("bfm|faa")] = 1),
            n[Zt("ukn")] && (e[Zt("ukntv")] = 1),
            (n[Zt("vaaSgzc\x7fsze}|")] ||
              n[Zt("vaaSgzc\x7fsze}|Mc|f|c~~k~")]) &&
              (e[Zt("vamqv")] = 1),
            n[Zt("wvxw``m~")] &&
              n[Zt("wvxw``m~")].toString &&
              -1 !== n[Zt("wvxw``m~")].toString().indexOf(Zt("Ak}gw`xg\x7f")) &&
              (e[Zt("ak}gv")] = 1),
            rt.JS.oZ(Zt("s{h{}")) ||
              r.PC() ||
              r.isEdge() ||
              r.isOpera() ||
              (e[Zt("|amgv")] = 1);
          var d = Zt("EknU^<^w|ji`{`kQ}`xwjz"),
            g = Zt("b|cf}zubw"),
            m = Zt("pQngthi`Voxs"),
            k = Zt("pQkwfMc|fktf"),
            z = Zt("xozsW`mp~kh");
          if (
            (((n[d] && (n[d][g][m] || n[d][g][k])) ||
              -1 !== f[z].toString().indexOf(Zt("`kxg``,tsb\x7fw"))) &&
              (e[Zt("s`x{v")] = 1),
            n[Zt("MQb{ufx\x7fs|i")] && (e[Zt("|gkzf")] = 1),
            window[Zt("_{xsfgc|]l\x7fw`xi`")])
          ) {
            var y = document.createElement(Zt("vgz")),
              p = Zt("{cmq`a\x7f?zgkz~gkzf#h{d");
            (y.innerHTML = Zt(".jed2gh/0") + p + Zt("000{\x7fi2.=jed,")),
              (y.style.display = Zt("|abw")),
              document.body.appendChild(y);
            var x = new MutationObserver(function () {
              x.disconnect(), (e[Zt("{cmq`")] = 1), N();
            });
            x.observe(y, { childList: !0 });
          }
          if (
            (u(
              this,
              function () {
                var t = Zt("glcf"),
                  i = Zt("GLcfQacy{k\x7f");
                (n[t] || n[i]) && ((e[Zt("glcfa")] = 1), N());
              },
              5e3
            ),
            r.isGecko())
          ) {
            var j = Zt("qf~}\x7fk6==dyuubi`=mc|fkbf");
            try {
              new Worker(j), (e[Zt("x{ku~k~")] = 1);
            } catch (t) {}
          }
          var q = Zt("MQSp`a{aw|_k|mSMM");
          a(window[q]) && (e[Zt("p}u|q")] = 1);
          try {
            var M = document.createElement(Zt("a~m|"));
            (M.className = Zt("\x7f}|sv#d{vji|")),
              document.body.appendChild(M),
              getComputedStyle(M).display === Zt("|abw") &&
                (e[Zt("\x7f}|sv")] = 1),
              document.body.removeChild(M);
          } catch (t) {}
          var S = Zt("MQ|~sw{`{idfMQn{|je|uQS"),
            A = Zt("MQ|e[`efAm~{bz\x7f"),
            O = i.UR(100, Zt("byn"));
          a(window[S]) &&
            ((e[Zt("byn")] = 1),
            O &&
              (e[Zt("bynMt")] = {
                to: typeof window[S],
                str: o(window[S]).slice(0, 1024),
              })),
            a(window[A]) &&
              ((e[Zt("byn")] = 1),
              O &&
                (e[Zt("bynM}")] = {
                  to: typeof window[A],
                  wop:
                    !!window.hasOwnProperty(A) &&
                    Object.getOwnPropertyDescriptor(window, A),
                }));
          var _ = n[Zt("_ayawKzw|z")];
          if (_) {
            var Q = Object.getOwnPropertyDescriptor(_[g], Zt("am~ww`T"));
            Q &&
              Q.get &&
              ("" + Q.get).indexOf(Zt("qbew|zT")) > -1 &&
              (e[Zt("b|n")] = 1);
          }
          if (
            a(n[Zt("\\ax{tgosfgc|")]) &&
            n[Zt("\\ax{tgosfgc|")][Zt("bk~\x7f{}\x7f{}`")] === Zt("vkb{wj")
          ) {
            var T = f[Zt("bk~\x7f{}\x7f{}`\x7f")];
            a(T) &&
              a(T[Zt("c{i`k")]) &&
              T[Zt("c{i`k")]({ name: Zt("|ax{tgosfgc|a") })
                .then(function (t) {
                  a(t[Zt("azmfw")]) &&
                    t[Zt("azmfw")] === Zt("b|c\x7fbz") &&
                    ((e.hb = 1), N());
                })
                .catch(function () {});
          }
          function N() {
            Object.keys(e).length > 0 && t({ aubr: e }, !1);
          }
          rt.JS.ks(null, function (t) {
            /goo\.gl\.\w+\//.test(t && t.message) && ((e[Zt("qbgp")] = 1), N());
          }),
            N();
        },
        stop: function () {
          e(), f();
        },
      }),
        wi({
          name: "tu",
          flags: 16,
          gE: 1,
          Iy: function (t, n, i) {
            var r = i.contentWindow,
              o = {},
              a = Zt("ZZA^Ba|gbK`w\x7fkbf"),
              e = Zt("\\ox{dkE]Tg`w");
            (r[a] || r[e]) && (o[Zt("ua`}u")] = 1);
            var f = Zt("tox}`"),
              u = [],
              c = r.document.createElement(Zt("{h~s\x7fk"));
            (c.onload = function (t) {
              var n = t.target.contentWindow,
                i = n.String.prototype.toLowerCase;
              (n.String.prototype.toLowerCase = function () {
                var t = arguments.callee.caller.toString(),
                  n = Zt("dk~kffe|u");
                return t.indexOf(n) > 0 && u.push(Zt("ffe|u")), i.call(this);
              }),
                n.document.createElement(Zt("{h~s\x7fk")),
                (n.String.prototype.toLowerCase = i);
              var r = n.document.createElement;
              (n.document.createElement = 1),
                1 !== n.document.createElement && u.push(Zt("q|isfk")),
                (n.document.createElement = r);
            }),
              c.dataset && (c.dataset.us = "us"),
              (c.srcdoc = ""),
              r.document.body.appendChild(c);
            var Z = Zt("sjhQ}`xw|z[{|jceB|cjk");
            -1 !==
              (
                "" +
                (
                  Object.getOwnPropertyDescriptor(
                    document.createElement(Zt("{h~s\x7fk")),
                    Zt("a|ov}m")
                  ) || {}
                ).set
              ).indexOf(Z) && u.push(Zt("vk\x7fq")),
              u.length > 0 && (o[f] = { i: u }),
              Object.keys(o).length > 0 && t({ aubr: o }, !0);
          },
        });
    }),
    kt.DR("SW", function (t, n) {
      function i(t, n) {
        var i = {};
        typeof t[Zt("qfm`ugbu")] === Zt("pac~wob") &&
          (i[Zt("qfm`ugbu")] = t[Zt("qfm`ugbu")]),
          typeof t[Zt("~kzw~")] === Zt("|{apw|") &&
            (i[Zt("~kzw~")] = t[Zt("~kzw~")]),
          n({ battapi: { status: i } }, !0);
      }
      wi({
        name: "SW",
        Iy: function (t) {
          var n =
              navigator[Zt("poxfw|u")] ||
              navigator[Zt("ekny{zNsfzi`k")] ||
              navigator[Zt("\x7favPszxw`w")],
            r = typeof navigator[Zt("ukxPszxw`w")] === Zt("t{bqfgc|");
          n
            ? i(n, t)
            : r &&
              navigator[Zt("ukxPszxw`w")]()
                .then(function (n) {
                  i(n, t);
                })
                .catch(function (t) {});
        },
      });
    }),
    kt.DR("ny", function (t, n) {
      wi({
        name: "ny",
        flags: 32,
        gE: 16,
        Iy: function (t, n, i) {
          var r = Zt('c9g \x7f6<#"?>+'),
            o = Zt("z?p"),
            a = [200, 400, 900, 2500],
            e = !1,
            f = 0,
            u = Date.now(),
            c = null,
            Z = null,
            s = null,
            w = 0;
          try {
            s = i && i.contentWindow;
          } catch (t) {}
          function v() {
            return Math.floor(65536 * (1 + Math.random()))
              .toString(16)
              .substring(1);
          }
          var h = v() + v(),
            l = "";
          try {
            l = kt.KV().ma().PR() || "";
          } catch (t) {}
          function b(i) {
            e ||
              ((e = !0),
              (function () {
                c && (clearTimeout(c), (c = null));
                try {
                  n.removeEventListener(Zt("\x7fk\x7fasii"), d, !1);
                } catch (t) {}
              })(),
              (i.ic_count = w),
              t({ bd_bridge: i }, !0));
          }
          function d(t) {
            try {
              if (e) return;
              var n = t.data;
              if (typeof n !== Zt("az~{|i") || n.slice(0, o.length) !== o)
                return;
              if (Z && t.source != Z) return;
              var i = n.split("|");
              if (i.length < 5 || i[1] !== h) return;
              b({ v: i[2], a: i[3], u: i[4], ms: Date.now() - u });
            } catch (t) {}
          }
          if (
            typeof n.addEventListener === Zt("t{bqfgc|") &&
            typeof n.postMessage !== Zt("g`hwtgbwv")
          ) {
            try {
              n.addEventListener(Zt("\x7fk\x7fasii"), d, !1);
            } catch (t) {
              return void b({ f: 3 });
            }
            !(function t() {
              if (!e) {
                var i = (function () {
                  var t, i, o, a, e, f, u, c;
                  try {
                    t = [n.top];
                  } catch (t) {
                    return null;
                  }
                  for (i = [0], o = 0; t.length && o < 150; )
                    if (
                      ((a = t.shift()), (e = i.shift()), o++, !a || a !== s)
                    ) {
                      f = null;
                      try {
                        f = a[r];
                      } catch (t) {}
                      if (f) return (w = o), a;
                      if (!(e >= 7))
                        try {
                          for (u = a.length, c = 0; c < u; c++)
                            t.push(a[c]), i.push(e + 1);
                        } catch (t) {}
                    }
                  return (w = o), null;
                })();
                if (i) {
                  Z = i;
                  try {
                    i.postMessage(o + l + "|" + h, "*");
                  } catch (t) {}
                  c = setTimeout(function () {
                    b({ f: 2 });
                  }, 2e3);
                } else f < a.length ? (c = setTimeout(t, a[f++])) : b({ f: 1 });
              }
            })();
          } else b({ f: 3 });
        },
      });
    }),
    kt.DR("Kk", function (t, n) {
      wi({
        name: "Kk",
        gE: 16,
        Iy: function (t) {
          var n = Array(25),
            i = 0,
            r = {},
            o = function (t) {
              (r[t] = n.slice(0, i)), (i = 0);
            },
            a = function (t) {
              var r;
              if (typeof t === Zt("t{bqfgc|"))
                try {
                  r = Number(t());
                } catch (t) {}
              else r = t;
              (n[i] = r || 0), ++i;
            };
          a(function () {
            if (
              typeof top !== Zt("g`hwtgbwv") &&
              null !== top &&
              null != top.window &&
              !(
                null != document.location.ancestorOrigins &&
                document.location.ancestorOrigins.length > 0 &&
                document.location.ancestorOrigins[0] !==
                  document.location.protocol + "//" + document.location.host
              ) &&
              null != top.window.name
            )
              return top.window.name.indexOf(Zt("v|edw|")) > -1;
          }),
            a(-1),
            a(-1),
            a(-1),
            a(function () {
              return (
                document.documentElement.hasAttribute(Zt("eknv`gzw`")) ||
                null != window.domAutomation ||
                null != window.domAutomationController ||
                null != window[Zt("MYIPV\\EDW\\SW^KAMQOOZW")]
              );
            }),
            a(-1),
            a(function () {
              return null != window._phantom || null != window.callPhantom;
            }),
            a(function () {
              return null != window[Zt("MYIPV\\EDW\\SW^KAMQOOZW")];
            }),
            a(function () {
              return null != window.isExternalUrlSafeForNavigation;
            }),
            a(function () {
              return (
                null != window.opera &&
                null != window.opera._browserjsran &&
                0 === window.opera.browserjsran
              );
            }),
            a(function () {
              return (
                null != window.opera &&
                null != window.opera._browserjsran &&
                !1 === window.opera.browserjsran
              );
            }),
            a(-1),
            a(function () {
              return (
                null != window[Zt("eknv`gzw`")] ||
                null != document[Zt("eknv`gzw`")] ||
                document.documentElement.hasAttribute(Zt("eknv`gzw`"))
              );
            }),
            o("b"),
            a(-1),
            a(-1),
            a(-1),
            a(function () {
              return !1;
            }),
            a(function () {
              return !1;
            }),
            a(function () {
              return !1 === navigator.onLine;
            }),
            a(-1),
            a(-1),
            a(-1),
            a(function () {
              return (
                null != window.chrome &&
                (null != window.chrome.send ||
                  null != window.chrome.benchmarking)
              );
            }),
            a(function () {
              return null != window.chrome && null != window.chrome.extension;
            }),
            a(function () {
              return null != window.chrome && null != window.chrome.internals;
            }),
            a(function () {
              return (
                (null != window.chrome && null != window.chrome.send) ||
                null != window.chrome.benchmarking
              );
            }),
            a(-1),
            a(-1),
            a(-1),
            a(function () {
              return (
                null != window.external &&
                window.external.toString().indexOf(Zt("@{bf{ci]pdiqf")) > -1
              );
            }),
            a(function () {
              return window.FirefoxInterfaces(
                Zt("ejEQ}a~v{`mfw"),
                Zt("ejE_}{\x7fw"),
                Zt("ejEAfoxga")
              );
            }),
            a(function () {
              return null != window.XPCOMUtils;
            }),
            o("c"),
            t({ bts: r }, !0);
        },
      });
    }),
    kt.DR("zQ", function (t, n) {
      var i = rt.kM.Nk,
        r = rt.kM.Nk,
        o = rt.kM.Nk;
      wi({
        name: "zQ",
        flags: 4,
        gE: 16,
        Iy: function (t, n) {
          var a = Zt("s~e[|zi`toow"),
            e = Zt("ukxQ}`j{u"),
            f = Zt("QKHSFA"),
            u = f + Zt("MGB[F"),
            c = f + Zt("MJIPGI"),
            Z = f + Zt("MZMU"),
            s = f + Zt("MO\\["),
            w = kt.KV().UR(1e3, f),
            h = { gfound: !1, sfound: !1, cnt: 0 },
            l = { scr: void 0, glb: void 0 };
          function b(n, i) {
            n && Object.keys(n).length > 0 && t({ cdto: n }, i);
          }
          if (w) {
            try {
              l.enu = Object.keys(n).filter(function (t) {
                return -1 !== t.indexOf(f);
              });
            } catch (t) {
              l.enu_err = t.message;
            }
            b(l, !1);
          }
          function d(t, i) {
            for (
              var r = [],
                o = [],
                a =
                  n.document.scripts ||
                  (n.document.getElementsByTagName &&
                    n.document.getElementsByTagName(Zt("am~{bz"))),
                e = /player\/player/,
                f = /\?cachebuster=/,
                u = 0;
              u < a.length;
              u++
            ) {
              var c = a[u];
              c.src &&
                (e.test(c.src) && r.push(c.src),
                f.test(c.src) && ((t.sfound = !0), o.push(c.src)));
            }
            return (
              (r.length > 0 || o.length > 0) && (i.scr = { pl: r, cb: o }),
              t.sfound
            );
          }
          function g(t, i) {
            if (t.gfound) return t.gfound;
            var r = {};
            return (
              n[a] &&
                n[a][e] &&
                ((r[e] = n[a][e]),
                n[a][e](function (t) {
                  r.conf = t;
                })),
              n[f] && (r[f] = n[f]),
              n[u] && (r[u] = n[u]),
              n[c] && (r[c] = n[c]),
              n[Z] &&
                ((r[Z] = n[Z]),
                (r[Zt("bmbf")] = Array.isArray(r[Z][Zt("bbmkw|\x7f")])
                  ? r[Z][Zt("bbmkw|\x7f")].length
                  : -1)),
              n[s] && (r[s] = Object.keys(n[s])),
              Object.keys(r).length > 0 && ((t.gfound = !0), (i.glb = r)),
              t.gfound
            );
          }
          function m() {
            h.cnt++,
              g(h, l) && d(h, l) && b(l, !0),
              4 === h.cnt && (h.gfound && w ? b(l, !1) : o());
          }
          (o = rt.PA.interval(this, m, 2e3)),
            (r = rt.PA.timeout(this, m, kt.iI - 1e4)),
            (i = v.subscribe(2, function () {
              g(h, l) && d(h, l) && b(l, !0);
            }));
        },
        stop: function () {
          i(), r(), o();
        },
      });
    }),
    kt.DR("bo", function (t, n) {
      var i,
        r,
        o = kt.KV().ma().yj(),
        a = rt.IO.Xl,
        e = Z.KV(),
        f = rt.kM.Nk,
        u = rt.kM.Nk;
      function c() {
        var t = {};
        if ("undefined" == typeof navigator) return t;
        var n = navigator;
        return (
          "hardwareConcurrency" in n && (t.hc = n.hardwareConcurrency),
          "deviceMemory" in n && (t.dm = n.deviceMemory),
          "userAgent" in n && (t.ua = n.userAgent),
          "languages" in n &&
            (t.langs = n.languages
              ? Array.prototype.slice.call(n.languages)
              : null),
          "onLine" in n && (t.ol = n.onLine),
          "platform" in n && (t.plat = n.platform),
          "locks" in n && (t.lk = typeof n.locks),
          t
        );
      }
      function s(t, n) {
        var i,
          r,
          o,
          a,
          e,
          f,
          u,
          c = null,
          Z = null,
          s = {},
          w = { n: [], t: [] },
          v = new RegExp("^[A-Z_]+$"),
          h = [7936, 7937, 7938, 35724, 37445, 37446],
          l = ["webgl", "experimental-webgl", "moz-webgl"],
          b = { antialias: !1, preserveDrawingBuffer: !0 };
        for (i = 0, r = l.length; i < r; ++i) {
          o = Date.now();
          try {
            c = t.getContext(l[i], b);
          } catch (t) {}
          w.t.push(Date.now() - o),
            c && "function" == typeof c.getParameter && (w.n.push(i), (Z = c)),
            (c = null);
        }
        if (!w.n.length) return w;
        if (n)
          try {
            for (e in (a = Z.getExtension("WEBGL_debug_renderer_info")))
              v.test(e) && "number" == typeof a[e] && (s[a[e]] = 1);
          } catch (t) {}
        for (e in Z) v.test(e) && "number" == typeof Z[e] && (s[Z[e]] = 1);
        for (i = 0, r = h.length; i < r; ++i)
          if (s[(f = h[i])])
            try {
              null !== (u = Z.getParameter(f)) && (w[f.toString(16)] = u);
            } catch (t) {}
        return w;
      }
      function w(t, n, i, r) {
        var o,
          a,
          e,
          f,
          u,
          c,
          Z,
          s = null,
          w = !1,
          v = ["webgl2", "webgl", "experimental-webgl"];
        function h() {
          var t = Math.floor(0.75 * n),
            r = new Uint8Array(4 * i);
          s.readPixels(t, 0, 1, i, s.RGBA, s.UNSIGNED_BYTE, r);
          for (
            var o = Math.max(1, Math.floor(i / 26)), a = [], e = 0;
            e < 26;
            e++
          )
            a.push(r[4 * Math.floor(e * o)]);
          return a;
        }
        function l() {
          try {
            s.deleteProgram(f),
              s.deleteShader(u),
              s.deleteShader(c),
              s.deleteBuffer(Z);
          } catch (t) {}
        }
        for (o = 0, a = v.length; o < a; ++o)
          try {
            if (
              (s = t.getContext(v[o], {
                preserveDrawingBuffer: !0,
                antialias: !1,
              }))
            ) {
              w = "webgl2" === v[o];
              break;
            }
          } catch (t) {}
        if (s)
          try {
            if (
              ((u = s.createShader(s.VERTEX_SHADER)),
              s.shaderSource(
                u,
                "attribute vec2 p;void main(){gl_Position=vec4(p,0.,1.);}"
              ),
              s.compileShader(u),
              !s.getShaderParameter(u, s.COMPILE_STATUS))
            )
              return void r(null);
            if (
              ((c = s.createShader(s.FRAGMENT_SHADER)),
              s.shaderSource(
                c,
                "precision highp float;uniform vec2 res;const int ML=152;const int ME=120;void main(){float y=(gl_FragCoord.y/res.y)*32.0;float x=1.0-(gl_FragCoord.x/res.x);float fade=fract(pow(2.0,floor(y))+x);vec3 c=vec3(fade);float xx=x;int row=ME+int(floor(y));for(int i=0;i<ML;i++)if(i<row)xx*=0.5;for(int i=0;i<ML;i++)if(i<row)xx*=2.0;if(xx==0.0){c.r=clamp(c.r+0.5,0.0,1.0);}if(fract(y)>=0.9)c=vec3(0.0);gl_FragColor=vec4(c,1.0);}"
              ),
              s.compileShader(c),
              !s.getShaderParameter(c, s.COMPILE_STATUS))
            )
              return void r(null);
            if (
              ((f = s.createProgram()),
              s.attachShader(f, u),
              s.attachShader(f, c),
              s.linkProgram(f),
              !s.getProgramParameter(f, s.LINK_STATUS))
            )
              return void r(null);
            (Z = s.createBuffer()),
              s.bindBuffer(s.ARRAY_BUFFER, Z),
              s.bufferData(
                s.ARRAY_BUFFER,
                new Float32Array([-1, -1, 3, -1, -1, 3]),
                s.STATIC_DRAW
              );
            var b = s.getAttribLocation(f, "p");
            if (
              (s.viewport(0, 0, n, i),
              s.useProgram(f),
              s.uniform2f(s.getUniformLocation(f, "res"), n, i),
              s.enableVertexAttribArray(b),
              s.vertexAttribPointer(b, 2, s.FLOAT, !1, 0, 0),
              s.drawArrays(s.TRIANGLES, 0, 3),
              w && "function" == typeof s.fenceSync)
            )
              (e = s.fenceSync(s.SYNC_GPU_COMMANDS_COMPLETE, 0)),
                s.flush(),
                (function t() {
                  if (s.getSyncParameter(e, s.SYNC_STATUS) === s.SIGNALED) {
                    s.deleteSync(e);
                    var n = h();
                    l(), r(n);
                  } else setTimeout(t, 0);
                })();
            else {
              var d = h();
              l(), r(d);
            }
          } catch (t) {
            r(null);
          }
        else r(null);
      }
      var h = 256,
        l = 160;
      function b() {
        try {
          return document.createElement(Zt("qobds}"));
        } catch (t) {
          return null;
        }
      }
      wi({
        name: "bo",
        flags: 128,
        lj: [{ name: "ie" }],
        Iy: function (t, n) {
          if (!e.PC() || !rt.rZ.ft()) {
            r = !e.isFirefox() || (e.isFirefox() && e.version(5) < 92);
            var Z = b();
            Z && ((Z.width = h), (Z.height = l));
            var d,
              g = function (n, i, r, o) {
                var e = {};
                if (n.ob) {
                  var f = (function (t) {
                    if (!t || !t.length) return { hash: null, t: 0 };
                    for (var n = Date.now(), i = [], r = 0; r < t.length; r++)
                      i.push(String(t[r]));
                    return { hash: a(i), t: Date.now() - n };
                  })(n.ob);
                  n.ob = { hash: f.hash, t: f.t, raw: n.ob };
                }
                (n.th = r), (e[i] = n), t(e, o);
              };
            if (
              (d = Z) &&
              typeof d.transferControlToOffscreen === Zt("t{bqfgc|") &&
              o.bwk &&
              rt.pA.AY()
            ) {
              var m = c.toString(),
                k = s.toString(),
                z = w.toString(),
                y = new Blob([
                  Zt("}`awa}muw3jg|mx{}`$w;u") +
                    Zt("do~2qx1w<jmfs os|xma)") +
                    Zt("do~2q|1w<jmfs o}~biqf\\i|vk~w`5") +
                    Zt("do~2e3i<voxs<yevff7") +
                    Zt("do~2z3i<voxs<fi{ufx)") +
                    Zt("do~2`k\x7fg~z1uszdw`YipUB_{u`m~a&od>m~;)") +
                    Zt('`k\x7fg~z"|sx1uszdw`@md{imf}|_{u`m~a&%)') +
                    Zt('uoxzw|C~aabK}{ePs|\x7fSawbq:mz>e"d>t{bqfgc|:an;i') +
                    Zt('`k\x7fg~z"}p3cp)') +
                    Zt("ba\x7ff_k\x7fasii:`k\x7fg~z%)") +
                    Zt("o'7") +
                    Zt("o\x04\x06") +
                    Zt("uoxzw|Bsdgksfa~A{ibs~}1") +
                    m +
                    "\n\n" +
                    Zt("uoxzw|[wpI@A{ibs~}1") +
                    k +
                    "\n\n" +
                    Zt("uoxzw|C~aabK}{ePs|\x7fSawbq/") +
                    z,
                ]);
              (i = new Worker(n.URL.createObjectURL(y))).addEventListener(
                Zt("\x7fk\x7fasii"),
                function (t) {
                  g(t.data, Zt("ei`"), 1, !1),
                    (f = v.subscribe(2, x)),
                    (u = (function () {
                      return rt.PA.timeout(this, x, kt.iI - 1e4);
                    })());
                }
              );
              var p = Z.transferControlToOffscreen();
              i.postMessage(
                { canvas: p, collectRenderer: r, width: h, height: l },
                [p]
              );
            } else
              rt.PA.immediate(function () {
                if (Z && n.WebGLRenderingContext) {
                  var t = s(Z, r);
                  w(Z, h, l, function (n) {
                    (t.ob = n), g(t, Zt("ei`"), 0, !0);
                  });
                }
              });
          }
          function x() {
            var t = b();
            if (t && n.WebGLRenderingContext) {
              var i = s(t, r);
              (t.width = h),
                (t.height = l),
                w(t, h, l, function (t) {
                  (i.ob = t), g(i, Zt("ei`\x7f"), 0, !0);
                });
            }
          }
        },
        stop: function () {
          i && i.terminate(), f(), u();
        },
      });
    }),
    kt.DR("IW", function (t, n) {
      var i,
        r = rt.iframe.Gz(),
        o = !1,
        a = 0,
        e = [];
      function f(t) {
        return null != t && t === t.window;
      }
      var u = {
        name: "IW",
        flags: 4,
        Iy: function (t) {
          if (r > 0) {
            if (void 0 === window.IntersectionObserver)
              return void t({ cssData: { io: Zt("to`aw") } }, !0);
            ((i = document.createElement(Zt("vgz"))).style.position =
              Zt("sl\x7f}~{xw")),
              (i.style.visibility = Zt("zghvw`")),
              (i.style.left = Zt('"~t')),
              (i.style.top = Zt('"~t')),
              (i.style.width =
                (window.innerWidth ||
                  document.documentElement.clientWidth ||
                  document.body.clientWidth) + "px"),
              (i.style.height =
                (window.innerHeight ||
                  document.documentElement.clientHeight ||
                  document.body.clientHeight) + "px"),
              document.body.appendChild(i),
              new window.IntersectionObserver(function (n) {
                n[0].intersectionRatio > 0.25 &&
                  (function (t) {
                    !(function () {
                      var n = rt.PA.interval(
                        u,
                        function () {
                          (function () {
                            for (
                              var n = { w: window, p: window.parent },
                                i = [],
                                e = 0;
                              e < r;
                              e++
                            )
                              if (
                                rt.iframe.qm(n.p) &&
                                n.p !== n.w &&
                                rt.iframe.qm(n.w) &&
                                f(n.w) &&
                                n.w.frameElement
                              ) {
                                var u, c, Z;
                                try {
                                  u = getComputedStyle(n.w.frameElement);
                                } catch (n) {
                                  t({ cssData: { style: "e" } }, !1);
                                }
                                u &&
                                  (u.visibility === Zt("zghvw`")
                                    ? ((c = Zt("dg\x7f")), (Z = u.visibility))
                                    : "0" === u.opacity ||
                                      (!isNaN(u.opacity) && u.opacity < 0.01)
                                    ? ((c = Zt("}~m")), (Z = u.opacity))
                                    : u.display === Zt("|abw") &&
                                      ((c = Zt("vg\x7f")), (Z = u.display)),
                                  c &&
                                    i.push({
                                      id: n.w.frameElement.id,
                                      depth: e,
                                      class: c,
                                      classValue: Z,
                                    })),
                                  (n.w = n.w.parent),
                                  (n.p = n.p.parent);
                              }
                            i.length > 0
                              ? t({ cssData: { run: a++, stats: i } }, !1)
                              : ((o = !0),
                                a > 1 &&
                                  t({ cssData: { run: a, stats: "NA" } }, !0));
                          })(),
                            (a >= 10 || o) && n();
                        },
                        2e3
                      );
                      e.push(n);
                    })();
                  })(t);
              }).observe(i);
          }
        },
        stop: function () {
          for (var t = 0; t < e.length; t++) e[t]();
        },
      };
      wi(u);
    }),
    kt.DR("Bj", function (t, n) {
      var i,
        r = kt.KV().ma().yj();
      function o(t) {
        i.push(
          Number(
            (function () {
              try {
                return t();
              } catch (t) {}
            })()
          ) || 0
        );
      }
      wi({
        name: "Bj",
        Iy: function (t) {
          if (
            ((i = []),
            o(function () {
              return null != window[Zt("MQEWMJIDFAC^PO^MQABA]BIMQAA_S@HM^GBW")];
            }),
            o(function () {
              return null != window[Zt("MHe`wlyuQaa\x7fs`h^{`i")];
            }),
            o(function () {
              return null != window.chrome[Zt("Mmc\x7f\x7fobv^gbwS^E")];
            }),
            o(function () {
              return (
                null != window[Zt("Vkngu")] &&
                null != window[Zt("Vkngu")][Zt("vknguii`W`mp~kh")] &&
                1 === window[Zt("Vkngu")][Zt("vknguii`W`mp~kh")]
              );
            }),
            o(function () {
              return (
                null != window[Zt("Vkngu")] &&
                null != window[Zt("Vkngu")][Zt("vknguii`W`mp~kh")] &&
                !0 === window[Zt("Vkngu")][Zt("vknguii`W`mp~kh")]
              );
            }),
            o(function () {
              return void 0 !== window[Zt("MQN@]Y_W@ZC]^]SQ]@_]^K")];
            }),
            o(function () {
              return (
                window[Zt("qaba}bi")] &&
                window[Zt("qaba}bi")][Zt("~ak")] &&
                window[Zt("qaba}bi")][Zt("~ak")]
                  .toString()
                  .indexOf(Zt('j `}u",j>.m`u{aw|z\x7f')) > 0
              );
            }),
            t({ bts: { e: i } }, !1),
            r.cpl)
          ) {
            !(function (t) {
              rt.rZ.rI(function (n, i) {
                var r = {};
                (r[n] = { diff: i, status: !0 }), t(r, !1);
              });
            })(t);
            try {
              rt.rZ.init();
            } catch (t) {}
          }
          rt.PA.timeout(
            this,
            function () {
              !(function (t) {
                if (Z.KV().QI()) {
                  for (
                    var n = 0, i = 0, r = 0, o = 0, a = Date.now();
                    Date.now() == a;

                  );
                  for (var e = 0; e < 4; e++) {
                    for (a = Date.now(); Date.now() - a < 1; )
                      console.log(), n++;
                    for (
                      r = r < n ? n : r, a = Date.now();
                      Date.now() - a < 1;

                    )
                      console.groupEnd(), i++;
                    o = o < i ? i : o;
                  }
                  t({ dbg: { l: r, g: o } }, !1);
                }
              })(t);
            },
            10
          );
        },
      });
    }),
    (bi.prototype.setListener = function (t, n) {
      var i = kt.KV().UR(100, Zt("|ozWdzX}b"));
      (t !== top || i) &&
        t[Zt("|oz{uox{}`")].addEventListener(
          Zt("|oz{uoxw"),
          function (t) {
            var i = {};
            (i[n] = {
              it: t.isTrusted,
              sd: t.destination.sameDocument,
              ui: t.userInitiated,
              url: t.destination.url,
            }),
              this.queue({ deep: { ifrtree: { navEvt: i } } }, !1);
          }.bind(this)
        );
    }),
    kt.DR("dk", function (t, n) {
      var i = Z.KV(),
        r = {},
        o = null,
        a = null;
      function e() {
        Object.keys(r).length > 0 && (o({ deep: r }, !1), (r = {}));
      }
      wi({
        name: "dk",
        Iy: function (t, n) {
          (o = t),
            n[Zt("|oz{uox{}`")] && (a = new bi(o)),
            (function () {
              try {
                var t = rt.iframe.Rk(document.body),
                  n = t.contentWindow,
                  o = n.navigator.userAgent;
                if (
                  (o !== navigator.userAgent &&
                    (r[Zt("goS{t|Sv{hj")] = [o, navigator.userAgent]),
                  i.isGecko())
                ) {
                  t.outerHTML = "";
                  var a = n.navigator.userAgent;
                  o !== a && (r[Zt("goSvwohMvgjt")] = [o, a]);
                }
              } catch (t) {
                r[Zt("w|~v{hj")] = t.message;
              }
            })(),
            (function () {
              if (document[Zt("tkmfg|iB}beqk")]) {
                var t = document[Zt("tkmfg|iB}beqk")].allowedFeatures();
                r[Zt("vkztwo")] = t;
              }
            })();
          var f = n[rt.JS.nl] && n[rt.JS.nl][Zt("g}i`Sii|fJmfs")];
          f &&
            ((function (t) {
              var n = {};
              (n[Zt("\x7fan{~k")] = t[Zt("\x7fan{~k")]),
                (n[Zt("p|m|v}")] = t[Zt("p|m|v}")]),
                (n[Zt("bbmfta~\x7f")] = t[Zt("bbmfta~\x7f")]),
                (r[Zt("qfys")] = n);
            })(f),
            (function (t) {
              t[Zt("ukxZ{idW|z~}bwZs~{ia")]([
                Zt("s|oz{ziqf{~w"),
                Zt("pgx|w}\x7f"),
                Zt("\x7fahw~"),
                Zt("bbmfta~\x7f"),
                Zt("bbmfta~\x7fDk~a{ab"),
                Zt("goJg~bZw`}e}|"),
                Zt("t{`~Dk~a{ab^{}x"),
              ])
                .then(function (t) {
                  (r[Zt("zgkzw`x")] = t), e();
                })
                .catch(function (t) {
                  o({ deep: { h_err: t.toString().slice(0, 256) } }, !1);
                });
            })(f)),
            (function () {
              var t,
                n = kt.KV().UR(1e3, Zt("{h~")),
                i = 0,
                o = !1,
                e = {},
                f = {},
                u = {},
                c = -1,
                Z = [],
                s = [],
                w = {
                  adsNestedCount: 0,
                  adsAboveFoldCount: 0,
                  adsBelowFoldCount: 0,
                  iFramesCount: 0,
                  iFramesAccessibleCount: 0,
                  maxChildrenCount: 0,
                  iFramesOnPageCount: top.length,
                  exceptionList: [],
                  chOfTopRefList: [],
                },
                v = 0,
                h = 0;
              rt.iframe.YX() &&
                ((o = !0),
                (w.viewportAboveFoldPixels = top.innerHeight * top.innerWidth));
              var l = 10;
              function b(t, i, r, a) {
                var f = !1;
                r && (e = t);
                var u = rt.iframe.qm(t),
                  c = rt.iframe.Dv(t, u);
                if (((i[Zt("qfe~v|i|Qay|f")] = t.length), i.self))
                  for (
                    var Z = document.getElementsByTagName(Zt("{h~s\x7fk")),
                      s = 0;
                    s < Z.length;
                    s++
                  )
                    rt.iframe.Pl(Z[s]) && i.childrenCount--;
                if (
                  ((w.maxChildrenCount = Math.max(
                    w.maxChildrenCount,
                    i.childrenCount
                  )),
                  c && Object.assign && Object.assign(i, rt.wX.gd(c)),
                  u &&
                    ((i[Zt("zkeuzz")] = Math.max(
                      0 | i[Zt("zkeuzz")],
                      t.innerHeight,
                      0 | t.document.documentElement.offsetHeight
                    )),
                    (i[Zt("eghfz")] = i[Zt("eghfz")] || t.innerWidth)),
                  i[Zt("eghfz")] && i[Zt("zkeuzz")])
                ) {
                  var v = !!c && t.parent.getComputedStyle(c);
                  rt.ads.qc(i, v) && ((f = !0), w.adsOnPageCount++);
                }
                (r || n || i.ownBranch) &&
                  (function () {
                    if (
                      (c &&
                        ((i[Zt("q}\x7f[v")] =
                          (c.id || "").substr(0, 128) || void 0),
                        (i[Zt("qbmaa")] =
                          (c.className || "").substr(0, 64) || void 0),
                        (i[Zt("voxs")] =
                          (Object.keys(c.dataset).length
                            ? JSON.stringify(c.dataset).substr(0, 256)
                            : "") || void 0),
                        (i[Zt("s|es")] =
                          (c.ariaLabel || "").substr(0, 64) || void 0),
                        (i[Zt("fgx~w")] =
                          (c.title || "").substr(0, 64) || void 0),
                        (i[Zt("aobvpat")] =
                          c.getAttribute(Zt("aobvpat")) || void 0),
                        (i[Zt("azu~w")] =
                          c.getAttribute(Zt("azu~w")) || void 0),
                        (i[Zt("a|o")] = (c.src || "").substr(0, 256) || void 0),
                        (i[Zt("a|oV}m")] =
                          (c.srcdoc || "").substr(0, 256) || void 0),
                        (i[Zt("zza~")] =
                          (a && l-- ? c.outerHTML.substr(0, 1024) : "") ||
                          void 0)),
                      u &&
                        ((i[Zt("|oaw")] = t.name.substr(0, 128) || void 0),
                        (i[Zt("~aosfgc|")] = t.location.href),
                        (i[Zt("fgawAgbqwBcsvkh")] =
                          Date.now() - t.performance.timing.navigationStart),
                        (i[Zt("`kjw`|i`")] = t.document.referrer),
                        r &&
                          (Object.assign && Object.assign(i, rt.wX.qY(t)),
                          (i[Zt("zkeuzz")] = Math.max(
                            0 | i[Zt("zkeuzz")],
                            0 | rt.wX.NU(document)
                          ))),
                        Zt("\x7fav[|`i`Am~ww`U") in window &&
                          ((i[Zt("am~ww`U")] = t.mozInnerScreenY),
                          (i[Zt("am~ww`T")] = t.mozInnerScreenX)),
                        Zt("|oz{uox{}`") in window &&
                          (i[Zt("qobU}Lmqy")] = t.navigation.canGoBack)),
                      f)
                    )
                      if (a) {
                        if (
                          ((i[Zt("sjXkbk")] = Zt("g`hwfk~\x7f{`iv")),
                          (i[Zt("sjO}|zm{|k~")] = Zt("{h~s\x7fk")),
                          o && i.hasOwnProperty("x"))
                        ) {
                          var n = i.y + Math.floor(i[Zt("zkeuzz")] / 2),
                            e = i.x + Math.floor(i[Zt("eghfz")] / 2);
                          n < top.innerHeight &&
                          n > 0 &&
                          e < top.innerWidth &&
                          e > 0
                            ? (i[Zt("sjXkbk")] = Zt("slcdwHc~v"))
                            : (i[Zt("sjXkbk")] = Zt("pk`}eHc~v"));
                        }
                      } else i[Zt("sjXkbk")] = Zt("|k\x7ffwj");
                  })();
              }
              function d(t, r, o, f, u) {
                if ((o && (e = r), n && Z.push(r), u)) {
                  var c = rt.Ru.fU(t);
                  c && c.length > 0 && (r.ga = c), a && a.setListener(t, r.id);
                }
                switch (
                  (f &&
                    r.referrer &&
                    -1 == w.chOfTopRefList.indexOf(r.referrer) &&
                    w.chOfTopRefList.push(r.referrer),
                  (v += r[Zt("eghfz")] * r[Zt("zkeuzz")] || 0),
                  r[Zt("zkeuzz")] > h && (h = r[Zt("zkeuzz")]),
                  r[Zt("sjXkbk")])
                ) {
                  case Zt("slcdwHc~v"):
                    w.adsAboveFoldCount++,
                      (i += r[Zt("eghfz")] * r[Zt("zkeuzz")] || 0);
                    break;
                  case Zt("pk`}eHc~v"):
                    w.adsBelowFoldCount++;
                    break;
                  case Zt("|k\x7ffwj"):
                    w.adsNestedCount++;
                }
              }
              (function n(i, r) {
                var o = { id: ++c, parentId: r };
                if (i === window) {
                  o[Zt("ak`t")] = !0;
                  for (var a = (t = o); a && a.id > 0; )
                    (a[Zt("}ybP`obqz")] = !0), s.push(a), (a = f[a.parentId]);
                }
                (f[o.id] = o), (u[o.id] = i);
                for (var e = 0; e < i.length && c < 800; e++) n(i[e], o.id);
              })(top, -1),
                (w.iFramesCount = Object.keys(f).length);
              for (var g = 0; g < w.iFramesCount; g++) {
                var m = f[g],
                  k = u[g],
                  z = k === top,
                  y = k.parent == top,
                  p = rt.iframe.qm(k),
                  x = rt.iframe.Dv(k, p);
                if (((x || p) && w.iFramesAccessibleCount++, !rt.iframe.Pl(x)))
                  try {
                    b(k, m, z, y), d(k, m, z, y, p);
                  } catch (t) {
                    w.exceptionList.length < 11 &&
                      w.exceptionList.push(t.message.substr(0, 256));
                  }
              }
              (w.adsOnPageCount = w.adsBelowFoldCount + w.adsAboveFoldCount),
                o &&
                  ((w.adPixelsOnPage = v),
                  (w.adPixelsAboveFold = i),
                  (w.adsAboveFoldContentRatioPct = Math.round(
                    (i / w.viewportAboveFoldPixels) * 100
                  )));
              var j = { top: e, metrics: w, ownBranch: s, self: t };
              Z.length && (j[Zt("{h~s\x7fk\x7f")] = Z), (r[Zt("{h~f`ki")] = j);
            })(),
            (function () {
              try {
                if (rt.iframe.YX()) {
                  var t = {
                    act: getComputedStyle(
                      window.top.document.activeElement
                    ).outline.slice(0, 100),
                    zid: window.top.document.elementFromPoint(0, 0).id,
                    zcol: window.top.document.elementFromPoint(0, 0).style
                      .color,
                  };
                  r[Zt("}bmk")] = t;
                }
              } catch (t) {}
            })(),
            e();
        },
      });
    }),
    kt.DR("QL", function (t, n) {
      var i = window[Zt("[`xw`}iqfgc|]l\x7fw`xi`")],
        r = typeof i === Zt("g`hwtgbwv"),
        o = rt.IO.TU(i);
      wi({
        name: "QL",
        flags: 16,
        Iy: function (t, n, a) {
          var e = n.document,
            f = a.contentWindow,
            u = rt.iframe.Gz(),
            c = Z.KV().Ac(),
            s = [],
            w = 0;
          if (
            (r || rt.wX.IG(i) || t({ dwv: { io: o } }, !1),
            !(u > -1 || !c || r))
          ) {
            var v = e.createElement(Zt("vgz"));
            (v.style.position = Zt("sl\x7f}~{xw")),
              (v.style.visibility = Zt("zghvw`")),
              (v.style.width = v.style.height = Zt("#>|j")),
              (v.style.left = v.style.top = Zt('"~t')),
              document.body.appendChild(v),
              new f[Zt("[`xw`}iqfgc|]l\x7fw`xi`")](
                function (i) {
                  var r = i[0].intersectionRect,
                    o = r.width * r.height,
                    a =
                      n.innerWidth ||
                      e.documentElement.clientWidth ||
                      e.body.clientWidth,
                    f =
                      n.innerHeight ||
                      e.documentElement.clientHeight ||
                      e.body.clientHeight,
                    u = a < 1 && o < 1;
                  s.indexOf(u) < 0 &&
                    w < 2 &&
                    (t({ dwv: { d: u, ww: a, wh: f, vp: o } }, !!(w > 0)), w++);
                },
                { threshold: [0, 1] }
              ).observe(v);
          }
        },
      });
    });
  var di = Zt("Tg~wFXJ]AJMF"),
    gi = /(iPhone|iPad|iPod)/,
    mi = /Safari\/[\d.]*$/,
    ki = /Chrome|Firefox|Edg|OPR/,
    zi = /Macintosh/,
    yi = / AFT/;
  function pi() {
    var t = typeof window === Zt("}lfwqz") ? window : null;
    if (!t || !t.navigator) return !1;
    var n = t.navigator.userAgent,
      i = mi.test(n) && !ki.test(n),
      r = gi.test(n),
      o = zi.test(n);
    if (r) {
      var a = /(iPhone OS|iPad OS|CPU OS) (\d+[_.]\d+)/.exec(n);
      return !!a && parseInt(a[2], 10) >= 16;
    }
    if (i && o) {
      var e = /OS X (\d+(?:[_.]\d+)+)/.exec(n);
      if (!e) return !0;
      var f = (function (t) {
        if (t && t[1]) {
          var n = t[0].includes(".") ? "." : "_",
            i = t[1].split(n);
          if (3 === i.length) return parseInt(i[1], 10);
          if (2 === i.length) return parseInt(i[0], 10);
        }
        return null;
      })(e);
      return !!f && f >= 13;
    }
    return !1;
  }
  function xi() {
    return kt.KV().UR(10, Zt("vkzsfz"));
  }
  function ji(t) {
    var n = kt.KV().ma(),
      i = n.protocol(),
      r = n.domain(),
      o = n.apiVersion(),
      a = n.customerId(),
      e = n.PR(),
      f = n.ki(),
      u = new URLSearchParams(f).toString(),
      c = Zt("qfm~~kbuw");
    return (
      1 === t && (c = Zt("qf`|u?")),
      2 === t && (c = Zt("qf`|u<")),
      63770 === t && ((c = Zt("qf`|uh5#s")), (r = Zt("\x7fgbfsey<qaa"))),
      i +
        Zt("(!#") +
        r +
        "/" +
        o +
        "/" +
        a +
        "/" +
        e +
        "/" +
        c +
        Zt("<iet-") +
        u
    );
  }
  function qi(t) {
    t({ deviceattestation: { supported: !1 } });
  }
  function Mi(t) {
    var n = typeof window === Zt("}lfwqz") ? window : null;
    if (n && n.navigator) {
      var i = n.navigator.userAgent,
        r = mi.test(i) && !ki.test(i);
      if (gi.test(i) || r)
        return pi()
          ? void (function (t) {
              pi()
                ? xi()
                  ? (zt(ji(), function (n, i) {
                      var r = { success: n };
                      i && (r.error = JSON.stringify(i)),
                        t({ deviceattestation: r });
                    }),
                    t({ deviceattestation: { supported: !0, attempted: !0 } }))
                  : t({ deviceattestation: { supported: !0, attempted: !1 } })
                : qi(t);
            })(t)
          : void qi(t);
      yi.test(i)
        ? aT.sub(l.OMID, function (n) {
            n.type === Zt("ak\x7fa{abAfo~f") &&
              (function (t, n) {
                if (t.type === Zt("ak\x7fa{abAfo~f")) {
                  var i = t.data && t.data.supportedAttestationMechanisms;
                  if (i) {
                    var r = i.filter(function (t) {
                      return t.mechanism === di;
                    });
                    r &&
                      r.length > 0 &&
                      (function (t) {
                        if (xi()) {
                          t({
                            deviceattestation: { supported: !0, attempted: !0 },
                          });
                          var n = ji(63770),
                            i = {
                              mechanism: di,
                              version: Zt("# <"),
                              payload: { verifierUrl: n, version: Zt("# <") },
                            };
                          rt.omid.KV().vf(i, function (n, i) {
                            t({
                              deviceattestation: {
                                success: n,
                                responseCode: i,
                              },
                            });
                          });
                        } else
                          t({
                            deviceattestation: { supported: !0, attempted: !1 },
                          });
                      })(n),
                      qi(n);
                  }
                }
              })(n, t);
          })
        : qi(t);
    } else
      this.omidNative &&
        this.omidNative.attest &&
        (function (t) {
          xi()
            ? (this.omidNative.attest(ji()),
              t({ deviceattestation: { supported: !0, attempted: !0 } }))
            : t({ deviceattestation: { supported: !0, attempted: !1 } });
        })(t);
  }
  wi({
    name: "qF",
    Iy: function (t) {
      document.readyState !== Zt("~amv{`k")
        ? Mi(t)
        : document.addEventListener(Zt("VAAQ}`xw|z@}sjiv"), function () {
            Mi(t);
          });
    },
  }),
    kt.DR("Cv", function (t, n) {
      var i = [],
        r = [],
        o = {
          name: "Cv",
          Iy: function (t, n) {
            var a = n.document.hasFocus();
            if ((t({ docFocus: { init: a } }), !a)) {
              var e = Date.now();
              r.push(
                d.events.Ig(window, Zt("taoga"), function () {
                  var n = Date.now() - e;
                  t({ docFocus: { event: !0, time: n } }, !1);
                })
              ),
                i.push(
                  rt.PA.interval(
                    o,
                    function () {
                      if (document.hasFocus()) {
                        var n = Date.now() - e;
                        t({ docFocus: { interval: !0, time: n } }, !0);
                      }
                    },
                    2e3
                  )
                );
            }
          },
          stop: function () {
            var t = 0;
            for (t = 0; t < i.length; t++) i[t]();
            for (t = 0; t < r.length; t++) r[t]();
          },
        };
      wi(o);
    });
  var Si,
    Ai = Z.KV(),
    Oi = {
      cX: function (t, n) {
        if (Ai.PC() && t.postMessage) {
          var i = { a: function () {} },
            r = 0,
            o = n.length,
            a = t;
          try {
            for (; r < o; r++) a.postMessage(i, n[r]);
          } catch (t) {
            return n[r];
          }
        }
      },
      IA: function () {
        if (!rt.object.QX(Si)) {
          if (Ai.PC() && window.postMessage) {
            var t = rt.wX.Sh(location.href);
            if (
              Oi.cX(window, [t]) === t &&
              Oi.cX(window, [Zt("zzxb(!#p~od<qaa")]) !== Zt("zzxb(!#p~od<qaa")
            )
              return (Si = !0);
          }
          Si = !1;
        }
        return Si;
      },
    };
  kt.DR("hu", function (t, n) {
    var i = rt.wX.Sh,
      r = {
        name: "hu",
        Iy: function (t, n) {
          var r = i(n.document.referrer),
            o = {
              initdata: {
                location_ancestorOrigins: rt.object.clone(
                  n.location.ancestorOrigins
                ),
              },
            };
          if (n.opener && history.length <= 1 && Oi.IA()) {
            var a = Oi.cX(n.opener, [r]);
            o.opener = { mismatch: r !== a };
          }
          t(o, !0);
        },
      };
    wi({
      name: "Xh",
      flags: 32,
      Iy: function (t) {
        void 0 !== location &&
          location.ancestorOrigins &&
          t(
            {
              initdata: {
                location_ancestorOrigins: rt.object.clone(
                  location.ancestorOrigins
                ),
              },
            },
            !0
          );
      },
    }),
      wi(r);
  }),
    kt.DR("Hh", function (t, n) {
      wi({
        name: "Hh",
        flags: 128,
        Iy: function (t) {
          if (kt.KV().ma().yj().ecm && !(rt.iframe.Gz() > 0)) {
            var n = Z.KV();
            if (!n.isFirefox() && !n.isBrave()) {
              var i,
                r = [
                  Zt("qaa<eghwdgbw<o`bzo"),
                  Zt("qaa<\x7fgo`}}ctf |~sw~wsju"),
                  Zt('ekny{z!}`i"e! o~wo~yww'),
                  Zt('}|k<e="q~km`yku'),
                  Zt("qaa<sjcpw |`{cif{ci"),
                ],
                o = Zt("s{h{}!ab&5o}vkoa/"),
                a = [
                  o + Zt("0c|&s :$0"),
                  o + Zt("0c|&s :%0"),
                  o + Zt("0c|&s :+0"),
                  o + Zt("0h`sq,"),
                  Zt("s{h{}!j~sm7q}jiqa3.t~oo0"),
                ],
                e = Zt("dghw}!ab&5o}vkoa/"),
                f = Zt("dghw}!{wpc7q}jiqa3"),
                u = [
                  e + Zt("0ozq# 8 Q>=W0"),
                  e + Zt("0ozq# 9*S>=W0"),
                  e + Zt('0ozq# ;&">>*0'),
                  e + Zt('0ozq# 8 ">?&0'),
                  f + Zt("0x|*0"),
                  f + Zt("0x|+0"),
                ],
                c = [{ contentType: o + Zt('0c|&s 8"<<.') }],
                s = {
                  initDataTypes: [Zt("qkbq"), Zt("ekn\x7f"), Zt("yku{v}")],
                  audioCapabilities: [],
                  videoCapabilities: [],
                },
                w = [Zt("s{h{}"), Zt("dghw}")];
              i = function (n, i) {
                var r, o, a, e, f, u, c;
                try {
                  for (r = i.getConfiguration(), o = {}, u = 0; u < 2; ++u)
                    for (
                      f = r[w[u] + Zt("Qo|spg`{fgia")], a = 0, e = f.length;
                      a < e;
                      ++a
                    )
                      o[f[a].contentType] = !0;
                  ((c = { eme: { sys: {} } }).eme.sys[n.toString()] = o),
                    t(c, !1);
                } catch (t) {}
              };
              var v,
                h = 0,
                l = 0,
                b = 0,
                d = 0,
                g = 0,
                m = {},
                k = {},
                z = {};
              for (v = a.length; h < v; ++h)
                (m[h] = { contentType: a[h] }), s.audioCapabilities.push(m[h]);
              for (d = u.length; l < d; ++l)
                (k[l] = { contentType: u[l] }), s.videoCapabilities.push(k[l]);
              var y = rt.object.clone(s);
              for (
                y.audioCapabilities = c,
                  y.distinctiveIdentifier = Zt("|ax?sb`}ekh"),
                  l = 0,
                  d = (z = y.videoCapabilities).length;
                l < d;
                ++l
              )
                z[l].robustness = Zt("AYSAWMY@WQO@K^X]");
              if (
                typeof navigator.requestMediaKeySystemAccess === Zt("t{bqfgc|")
              )
                for (b = 0, g = r.length; b < g; ++b)
                  (function (t) {
                    try {
                      navigator
                        .requestMediaKeySystemAccess(t, [
                          3537913595 === rt.IO.iX(t) ? y : s,
                        ])
                        .then(function (n) {
                          i(t, n);
                        })
                        [Zt("qoxqz")](function () {});
                    } catch (t) {}
                  })(r[b]);
            }
          }
        },
      });
    }),
    kt.DR("ZN", function (t, n) {
      var i = Z.KV(),
        r = kt.KV().ma().yj(),
        o = kt.KV(),
        a = rt.pA.AY,
        e = rt.object.QX,
        f = rt.object.mi,
        u = rt.kM.Nk,
        c = rt.kM.Nk,
        s = Zt("eknd{k{");
      wi({
        name: "ZN",
        gE: 1,
        Iy: function (t, n) {
          if (!o.ma().isVast() || o.UR(1e3, Zt("dQi|dk"))) {
            var Z = n[rt.JS.nl],
              w = Z[rt.JS.UL],
              v = {},
              h = Zt("qf~}\x7fk!wjzi|agc|(!#");
            if (o.UR(30, Zt("~g|")) && n.fetch) {
              var l = Zt("zzxba4#=~aos~fcaf ouyzd|<mc\x7f=hmd{mc|<go}");
              n.fetch(l, { cache: Zt("|a!afa~w") })
                .then(function (t) {
                  if (t.ok) return t.text();
                  throw new Error("CF");
                })
                .then(function (t) {
                  try {
                    var n = atob(t);
                    if (!/^\d+\.\d+\.\d+\.\d+$/.test(n)) throw t;
                    (v[Zt("~g|")] = n), L();
                  } catch (n) {
                    v[Zt("~g|w`|")] = t;
                  }
                })
                .catch(function (t) {
                  v[Zt("~g|w`|")] = t.message || t;
                });
            }
            if (n.chrome) {
              var b = n.chrome[s];
              if (b) {
                var d = Zt("ykua");
                v[s] = {};
                try {
                  v[s][d] = Object.keys(b).toString();
                } catch (t) {
                  v[s][d] = Zt("w|~2") + t.message;
                }
              }
            } else Zt("aojs`g") in window && (v[Zt("aojvae")] = 1);
            var g = n[Zt("ekny{z")];
            if (g) {
              (v[s] = v[s] || {}), (v[s].wk = { to: typeof g });
              var m = g[Zt("\x7fk\x7fasiiZs`h~w|\x7f")];
              v[s].wk[Zt("eeaz")] = m ? 1 : 0;
            }
            var k = Zt("wvxw``m~"),
              z = Zt("ukxZ}}xW|xe`}`aw|zZs~{i");
            if (n[k] && n[k][z]) {
              var y = Zt("}}!s`md{fkofg|i"),
                p = Zt("}}!pgg`v"),
                x = Zt("}}!\x7f}ji"),
                j = Zt("}}!ay{"),
                q = n[k][z]([y, p, x, j]);
              (v[Zt("egbvv")] = JSON.parse(q)), (v[Zt("wjkev")] = 1);
            }
            -1 !== n.close.toString().indexOf(Zt("WBIQF\\C\\")) &&
              (v[Zt("wbiqf|c|")] = 1),
              !("gc" in window) &&
                Zt("}|eu{`Muw`xQ~{\x7ffw|") in window &&
                !window[Zt("}|eu{`Muw`xQ~{\x7ffw|")] &&
                Zt("}~i|Voxspo\x7fw") in window &&
                Zt("qf~}\x7fk") in window &&
                !(Zt("~amvFgawa") in window[Zt("qf~}\x7fk")]) &&
                Object.keys(window[Zt("qf~}\x7fk")]).length > 0 &&
                (v[Zt("wbiqf|c|") + "2"] = 1);
            var M = Zt("kobvwv");
            if (
              (n[M] && (v[M] = 1),
              i.isBlink() &&
                Z[Zt("g}i`Sii|fJmfs")] &&
                !Z[Zt("g}i`Sii|fJmfs")].mobile &&
                !n[Zt("qf~}\x7fk")] &&
                (v[Zt("|aoz`")] = 1),
              i.isQQ() && (v[Zt("c\x7fn`}y")] = 1),
              i.isBrave() && (v[Zt("p|mdw")] = 1),
              !i.PC())
            ) {
              var S = Zt("voxsakx"),
                A = Zt("ql\x7fq`g|fsb`}e"),
                O =
                  !!n.HTMLCanvasElement && n.HTMLCanvasElement.prototype.toBlob,
                _ = Zt("|aea");
              ((O && -1 !== O.toString().indexOf(_)) ||
                document.documentElement[S][A]) &&
                (v[Zt("qhhwt")] = 1);
            }
            var Q = Object.getOwnPropertyDescriptor(Z, rt.JS.UL);
            if (Q && Q.get) {
              var T = Q.get.toString();
              -1 !== T.indexOf(Zt("`kxg``,}GO"))
                ? (v[Zt("yoa}")] = 1)
                : -1 !== T.indexOf(Zt("g~hsfkJ{|ii`b|e|fYi{ufx")) &&
                  (v[Zt("sxk")] = 1);
            }
            if (
              (((navigator[Zt("ukxPszxw`w")] &&
                -1 !==
                  navigator[Zt("ukxPszxw`w")]
                    .toString()
                    .indexOf(Zt("f|euuk~"))) ||
                (n.AudioNode &&
                  AudioNode.prototype.connect
                    .toString()
                    .indexOf(Zt("}lfM|oaw")) > 0)) &&
                (v[Zt("w~eqv")] = 1),
              i.isBlink() && console.context)
            ) {
              var N = Zt("|oaw"),
                D = Zt("qfovb"),
                I = 0,
                E = new EvalError();
              Object.defineProperty(E, N, {
                get: function () {
                  return 2 === ++I && ((v[D] = 1), L()), "";
                },
              }),
                console.context().debug("%c", E);
            }
            if (
              i.isBlink() &&
              (Zt("z|itF|m|abmfw") in HTMLAnchorElement.prototype ||
                (v[Zt("z|x`")] = 1),
              (u = rt.PA.interval(
                this,
                function () {
                  var t = Zt("MQSvgc|K"),
                    n = Zt("f{~|[`x}Bo~w|zMa\\kivwj"),
                    i = Zt("MQSvgc|:}lfIMS%"),
                    r = !1;
                  n in window && ((v[Zt("alidf")] |= 1), (r = !0)),
                    t in window &&
                      -1 !== window[t].toString().indexOf(i) &&
                      ((v[Zt("alidf")] |= 2), (r = !0)),
                    r && (L(), u());
                },
                1500
              )),
              e(Element.prototype.insertAdjacentElement))
            ) {
              var F = Element.prototype.insertAdjacentElement,
                C = Zt("`{b|{`k2afce?~c{|zi`?ob{");
              (c = function () {
                Element.prototype.insertAdjacentElement = F;
              }),
                (Element.prototype.insertAdjacentElement = function (t, n) {
                  try {
                    return (
                      n &&
                        n.id &&
                        -1 !== n.style.cssText.indexOf(C) &&
                        ((v[Zt("alh{d")] = 1), L(), c()),
                      F.call(this, t, n)
                    );
                  } catch (t) {
                    c();
                  }
                });
            }
            if (i.isGecko()) {
              r.prb &&
                (rt.JS.jg(
                  Zt(
                    "qf~}\x7fk6==l~}e}i`=}g{|!mp}{xAw}\x7f{}`^wazc`w#{{|jce?go}| ||u"
                  ),
                  function () {
                    w.indexOf(Zt("szi`")) > 0
                      ? (v[Zt("ehtq`")] = 1)
                      : w.indexOf(Zt("sbi_")) > 0
                      ? (v[Zt("bo`w`")] = 1)
                      : (v[Zt("thog`")] = 1),
                      L();
                  }
                ),
                rt.JS.jg(
                  Zt(
                    'qf~}\x7fk6==l~}e}i`=}g{|!mpk}\x7f={ck=eoxw`hcj?onka}!b`kz{wy"adi'
                  ),
                  function () {
                    (v[Zt("ehtu`")] = 1), L();
                  }
                ),
                rt.JS.jg(
                  Zt(
                    "qf~}\x7fk6==mc\x7f\x7f{b{qox}`!\x7fy{`#fs}gps|#fs}g\x7fw`y?p|ceak~<b`k"
                  ),
                  function () {
                    (v[Zt("akm\x7f`")] = 1), L();
                  }
                ));
              var B = CSS.supports(Zt("`{nk?~ca{ze}|4m~fk~|szi")),
                W = Zt("}`hwdgow~gkzf") in n;
              B && W && (v[Zt("thzwv")] = 88);
              var P = Zt("EknSa}i\x7fpbu") in n,
                V = Zt("abeqw") in n[Zt("S|~skLyttk~")];
              P && V && (v[Zt("thzwv")] = 52);
              var R = new Image();
              (R.onerror = function () {
                -1 !== Error().stack.indexOf(Zt("Wxi|fFm|vbi`\\ab\\gb`")) &&
                  ((v[Zt("thovb")] = 1), L());
              }),
                (R.src = Zt("slcgf4n~s`g"));
            } else if (r.chrext && r.bwk && !i.isQQ() && n[Zt("qf~}\x7fk")]) {
              for (
                var H = Zt("z|c\x7fw"),
                  G = n[Zt("|oz{uox}`")][Zt("bbyu{`\x7f")],
                  U = !1,
                  J = 0,
                  X = Object.keys(G);
                J < X.length;
                J++
              ) {
                var K = X[J];
                if (G[K] && String(G[K].name).indexOf(H) > 0) {
                  U = !0;
                  break;
                }
              }
              Zt("azc`sii") in navigator &&
                Zt("w}x{\x7foxw") in navigator.storage &&
                navigator.storage.estimate().then(function (t) {
                  var n = t.usage,
                    i = t.quota;
                  (v[Zt("azSt`ki")] = i),
                    (v[Zt("azSgakh")] = n),
                    i < 2 * performance.memory.jsHeapSizeLimit &&
                      (v[Zt("{`o}u")] = 1);
                }),
                rt.iframe.YX() &&
                  document.getElementById(Zt("Mfc~sQ|}b{|M{h~s\x7fkSM")) &&
                  (v[Zt("za`sM{\x7fw")] = 1),
                a() &&
                  (rt.JS.xO(
                    h +
                      Zt(
                        "uecxted~weeuzggstm|xygg~tlb~\x7fke}=d\x7f=s`e\x7fsze}|Qm``a{<zza~"
                      ),
                    function () {
                      (v[Zt("za`sMktf")] = 1), L();
                    }
                  ),
                  U ||
                    (rt.JS.xO(
                      h +
                        Zt(
                          "xhjp}md{pemz~ln\x7fs`|\x7f|jbz\x7fk`{wmmz=mc|tgk<x}c|"
                        ),
                      function () {
                        (v[Zt("dgzsj")] = 1), L(), t({ chrext: 21 }, !1);
                      }
                    ),
                    rt.JS.xO(
                      h + Zt('vkdvzcntbdj{zi|wymi}ydhwwfi{|ej}=gbfw|owbz"xa'),
                      function () {
                        (v[Zt("w~eqj")] = 1), L(), t({ chrext: 22 }, !1);
                      }
                    )),
                  rt.JS.xO(
                    h +
                      Zt(
                        "w~|{}mi\x7fzcb~pffb~mky}ho{{kk}\x7fmc|=mc|fkbf=}mtwmdwqe!|}zet{mmf{ab=|ax{tgosfgc|?gj`sci={`hwj df\x7fb"
                      ),
                    function () {
                      (v[Zt("gx||j")] = 1), L(), t({ chrext: 24 }, !1);
                    }
                  ),
                  rt.JS.xO(
                    h +
                      Zt(
                        'ufn\x7f|`f}}kgb\x7faiq|`b{~`bpvbc~zed{=~muwQi\x7fpkhMam~{bz"xa'
                      ),
                    function (t) {
                      (v[Zt("ujcqa")] = +t), L();
                    },
                    !0
                  ),
                  rt.JS.xO(
                    h +
                      Zt("q~`y~`a|~lbb\x7fdcu|mjutgf}}~a|~kab=}g{|!`}ua>&<~bu"),
                    function () {
                      (v[Zt("{cmqj")] = 1), L(), t({ chrext: 23 }, !1);
                    }
                  ));
            }
            rt.PA.timeout(
              this,
              function () {
                n[Zt("bk~t}|as|mi")] &&
                  n[Zt("bk~t}|as|mi")][Zt("\x7fka}`w")] &&
                  ((v[Zt("bk~t}|as|mi") + "_" + Zt("\x7fka}`w")] = f(
                    n[Zt("bk~t}|as|mi")][Zt("\x7fka}`w")]
                  )),
                  L());
              },
              500
            ),
              L();
          }
          function L() {
            Object.keys(v).length > 0 && t({ enve: v }, !1);
          }
        },
        stop: function () {
          u(), c();
        },
      }),
        wi({
          name: "fh",
          flags: 16,
          gE: 1,
          Iy: function (t, n, i) {
            var r,
              o = i.contentWindow,
              a = (((r = {})[s] = {}), r);
            (o[Zt("vk|s`zJ}q{\x7f")] || o.gc) &&
              (o[Zt("vk|s`zJ}q{\x7f")] && (a[s][Zt("wjkwzza~")] = 1),
              o.gc && (a[s][Zt("wjk{gc")] = 1));
            var e = Zt("}~i`s");
            if (
              (o[Zt("}~~")] && (a[e] = 1),
              !(Zt("aojs`g") in window) && Zt("S~|~w^mkW|~}`") in window)
            ) {
              var f = document.createElement(Zt("{h~s\x7fk"));
              (f.style.display = Zt("|abw")),
                (f.style.width = f.style.height = Zt('"~t')),
                document.body.appendChild(f),
                f.contentDocument.write(Zt("#<??#<??#<?")),
                f.contentDocument.close(),
                0 === f.contentDocument.links.length
                  ? (a[s][Zt("{a\x7f")] = 1)
                  : (a[Zt("aoj{}}")] = 1),
                f.remove();
            }
            (a[Zt("bjj")] = navigator.pdfViewerEnabled),
              (a[Zt("bjjMf")] = typeof navigator.pdfViewerEnabled),
              Object.getOwnPropertyDescriptor(
                navigator,
                Zt("bjjD{k{w`Kbspbiv")
              ) && (a[Zt("bjjM\x7f")] = 1),
              0 === Object.keys(a[s]).length && delete a[s],
              Object.keys(a).length > 0 && t({ enve: a }, !0);
          },
        });
    });
  var _i = document.documentElement;
  _i || (_i = {});
  var Qi = {
      mousemove: 1,
      mousedown: 2,
      mouseclick: 3,
      click: 3,
      mouseup: 4,
      mousedblclick: 5,
      dblclick: 5,
      keydown: 6,
      keypress: 7,
      keyup: 8,
      scroll: 9,
      touchstart: 10,
      touchend: 11,
      touchcancel: 12,
      touchleave: 13,
      touchmove: 14,
      mousescroll: 15,
      wheel: 15,
      mousewheel: 15,
      global: 60,
    },
    Ti = 8180,
    Ni = -32768;
  kt.DR("RR", function (t, n) {
    var i,
      r,
      o = kt.KV(),
      a = [],
      e = [],
      f = !0,
      u = function () {
        if (!f) {
          var t = o.BN();
          if (t.state <= 2) {
            var n,
              a = 250;
            if (Date.now() - i.lastEventTime > 30) {
              var e = t.poll();
              e &&
                ((n = e.screenX + "," + e.screenY) !== r
                  ? ((a = 33), (e.type = Zt("ubcpsb")), i.recordEvent(e))
                  : a < 250
                  ? (a *= 1.5)
                  : (a = 250),
                (r = n));
            } else a = 33;
            rt.PA.timeout(Z, u, a);
          }
        }
      };
    function c(t) {
      var n;
      i.dataAvailable() &&
        t({
          evtlog: [
            {
              seq: (n = i.dumpBuffer())[Zt("ak}")],
              data: lb.encode(n[Zt("voxs")]),
            },
          ],
        });
    }
    var Z = {
      name: "RR",
      gE: 32768,
      Iy: function (t, n) {
        if ((!o.ma().isVast() || o.UR(1e3, Zt("dQidf"))) && f) {
          (f = !1),
            e.push(
              d.events.Ig(
                n,
                Zt("_]\\}{`xw`Azw`"),
                function (t) {
                  i.recordEvent(t, f);
                },
                !1
              )
            );
          var r = d.events.Ig.bind(d.events),
            s = this;
          (i = (function (t, n) {
            var i,
              r,
              o,
              a,
              e,
              f = -1,
              u = [],
              c = [];
            function Z(t, n, i, r) {
              var o;
              return (
                r
                  ? ((o = t & (4294967295 >>> (33 - n))),
                    t < 0 && (o |= 1 << (n - 1)))
                  : (o = t & (4294967295 >>> (32 - n))),
                i < 0 ? o >>> Math.abs(i) : o << i
              );
            }
            function s() {
              var t = { seq: f, data: u.slice(0) };
              return (
                (i = 0),
                (r = { t: [-1e5, -3e5], x: [-1e5, -3e5], y: [-1e5, -3e5] }),
                (f += 1),
                t[Zt("voxs")].length,
                (u = []),
                (o = NaN),
                (a = NaN),
                t
              );
            }
            function w(t) {
              v(61440 | Z(t, 11, 0, !1));
            }
            function v() {
              for (var t = [], n = 0; n < arguments.length; n++)
                t[n] = arguments[n];
              u.push.apply(u, t);
            }
            function h(t) {
              (t < 0 || t > Ti) && t >= Ni && t <= 32767
                ? (function (t) {
                    v(65280, Z(t, 16, 0, !0));
                  })(t)
                : v(32768 | Z(d(t), 13, 0, !1));
            }
            function l(t) {
              v(
                49152 | Z(Math.floor(t / 4294967296) % 2048, 12, 0, !0),
                Z(Math.floor((t / 65536) % 65536), 16, 0, !1),
                Z(Math.floor(t % 65536), 16, 0, !1)
              );
            }
            function b(t) {
              (t < 0 || t > Ti) && t >= Ni && t <= 32767
                ? (function (t) {
                    v(65281, Z(t, 16, 0, !0));
                  })(t)
                : v(40960 | Z(d(t), 13, 0, !1));
            }
            function d(t) {
              return t > Ti ? 8191 : t < Ni ? 8189 : t < 0 ? 8190 : t;
            }
            function g(t) {
              return t in Qi ? Qi[t] : 63;
            }
            function m(t, n, i, r, o, a, e, f, u) {
              (i *= 40),
                (r = Math.ceil(r / 4)),
                (o = Math.ceil(o / 4)),
                (a = Math.round(a / 12)),
                v(
                  65472 | Z(t, 3, 1, !1) | Z(n, 4, -3, !1),
                  Z(n, 3, 13, !1) | Z(i, 6, 7, !1) | Z(r, 9, -2, !1),
                  Z(r, 2, 14, !1) | Z(o, 9, 5, !1) | Z(a, 5, 0, !1),
                  Z(e, 10, 6, !1) | Z(f, 11, -5, !1),
                  Z(f, 5, 11, !1) | Z(u, 11, 0, !1)
                );
            }
            s();
            var k = function (t, n) {
              n ||
                (function (t) {
                  e = Date.now();
                  var n = t.timeStamp || e,
                    f = (function (t) {
                      var n;
                      return (
                        void 0 !== t.clientX
                          ? (n = t.clientX)
                          : void 0 !== t.x
                          ? (n = t.x)
                          : void 0 !== t.pageX &&
                            (n =
                              t.pageX -
                              (window.pageXOffset || _i.scrollLeft) -
                              (_i.clientLeft || 0)),
                        isNaN(n) ? void 0 : n
                      );
                    })(t),
                    c = (function (t) {
                      var n;
                      return (
                        void 0 !== t.clientY
                          ? (n = t.clientY)
                          : void 0 !== t.y
                          ? (n = t.y)
                          : void 0 !== t.pageY &&
                            (n =
                              t.pageY -
                              (window.pageYOffset || _i.scrollTop) -
                              (_i.clientTop || 0)),
                        isNaN(n) ? void 0 : n
                      );
                    })(t);
                  void 0 === f && (f = r.x[0]),
                    void 0 === c && (c = r.y[0]),
                    (f = Math.round(f)),
                    (c = Math.round(c)),
                    (n = Math.round(n));
                  var s,
                    k,
                    z,
                    y,
                    p,
                    x = t.type,
                    j =
                      ((s = t),
                      (k = Zt("{}X`g}xwv")) in s
                        ? typeof s[k] === Zt("pac~wob")
                          ? s[k]
                            ? 3
                            : 2
                          : 1
                        : 0),
                    q = !0,
                    M = x === Zt("\x7fayawccdw"),
                    S = null;
                  if (M) {
                    var A = kt.KV().BN();
                    2 === A.state
                      ? (S = A.poll())
                      : void 0 !== t.screenX && void 0 !== t.screenY && (S = t);
                  }
                  var O,
                    _ = n - r.t[0],
                    Q = f - r.x[0],
                    T = c - r.y[0];
                  if (
                    ((function (t, n, i) {
                      (r.t[1] = r.t[0]),
                        (r.t[0] = t),
                        (r.x[1] = r.x[0]),
                        (r.x[0] = n),
                        (r.y[1] = r.y[0]),
                        (r.y[0] = i);
                    })(n, f, c),
                    x == Zt("ubcpsb"))
                  )
                    0 === u.length
                      ? (l(n), h(f), b(c), (_ = 0))
                      : _ > 1023 && (_ < 2048 && _ > 0 ? w(_) : l(n), (_ = 0)),
                      (function (t, n, i) {
                        (n = d(n)),
                          (i = d(i)),
                          v(
                            65408 | Z(t, 10, -6, !1),
                            Z(t, 6, 10, !1) | Z(n, 13, -3, !1),
                            Z(n, 3, 13, !1) | Z(i, 13, 0, !1)
                          );
                      })(_, t.screenX, t.screenY);
                  else if (
                    ((z = !(0 !== u.length)) && ((q = !1), l(n)),
                    S &&
                      ((y = S.screenX - f),
                      (p = S.screenY - c),
                      (y == o && p == a) ||
                        ((O = p),
                        v(65282, Z(y, 16, 0, !0), Z(O, 16, 0, !0)),
                        (o = y),
                        (a = p))),
                    z
                      ? (h(f), b(c))
                      : _ < 256 && Q < 512 && Q > -513 && T < 512 && T > -513
                      ? (function (t, n, i) {
                          v(
                            53248 | Z(t, 8, 4, !1) | Z(n, 10, -6, !0),
                            Z(n, 6, 10, !1) | Z(i, 10, 0, !0)
                          );
                        })(_, Q, T)
                      : _ < 65536 && Q < 32 && Q > -33 && T < 32 && T > -33
                      ? (function (t, n, i) {
                          v(
                            57344 | Z(t, 16, -4, !1),
                            Z(t, 4, 12, !1) | Z(n, 6, 6, !0) | Z(i, 6, 0, !0)
                          );
                        })(_, Q, T)
                      : ((q = !1),
                        0 !== Q && h(f),
                        0 !== T && b(c),
                        0 !== _ && (_ < 2048 && _ > 0 ? w(_) : l(n))),
                    (i !== j || !M || !q) &&
                      ((i = j),
                      v(63488 | (q ? 512 : 0) | (j << 7) | g(x)),
                      rt.IO.Ft(x, Zt("fayqz"))))
                  )
                    try {
                      var N,
                        D,
                        I = t.changedTouches.length;
                      for (D = 0; D < I; ++D)
                        (N = t.changedTouches[D]),
                          m(
                            7 & g(x),
                            15 & (N.identifier || 0),
                            null == N.force
                              ? 1.575
                              : N.force > 1.55
                              ? 1.55
                              : N.force,
                            null == N.radiusX
                              ? 2044
                              : N.radiusX > 2040
                              ? 2040
                              : N.radiusX,
                            null == N.radiusY
                              ? 2044
                              : N.radiusY > 2040
                              ? 2040
                              : N.radiusY,
                            null == N.rotationAngle ? 372 : N.rotationAngle,
                            0,
                            N.clientX,
                            N.clientY
                          );
                    } catch (t) {}
                })(t);
            };
            for (var z in Qi) c.push(n(t, z, k));
            return {
              dataAvailable: function () {
                return 0 === f || u.length > 0;
              },
              dumpBuffer: s,
              recordEvent: k,
              tearDown: function () {
                for (var t = 0; t < c.length; t++) c[t] && c[t]();
              },
            };
          })(document, r)),
            u(),
            c(t),
            a.push(
              rt.PA.timeout(
                Z,
                function () {
                  c(t);
                },
                2e3
              )
            ),
            a.push(
              rt.PA.timeout(
                Z,
                function () {
                  c(t);
                },
                3e4
              )
            ),
            a.push(
              rt.PA.timeout(
                Z,
                function () {
                  c(t), s.stop();
                },
                9e4
              )
            );
        }
      },
      stop: function () {
        if (!f) {
          var t;
          for (
            f = !0, o.BN().state = 16, i.tearDown(), t = 0;
            t < a.length;
            t++
          )
            a[t] && a[t]();
          for (a = [], t = 0; t < e.length; t++) e[t] && e[t]();
          (e = []), (i = void 0);
        }
      },
    };
    wi(Z);
  }),
    kt.DR("VH", function (t, n) {
      function i(t, n, i) {
        var r = {};
        (r[Zt("qf~")] = 1), i && (r[Zt("qf~Mf")] = 1);
        var o = n.chrome.runtime;
        o.id && (r[Zt("qf~M{j")] = o.id),
          o.lastError && (r[Zt("qf~M~k")] = o.lastError),
          o.getManifest && (r[Zt("qf~M\x7f")] = o.getManifest()),
          t({ exch: r }, !1),
          o.getPlatformInfo &&
            o
              .getPlatformInfo()
              .then(function (n) {
                t({ exch: { chr_info: n } }, !0);
              })
              .catch(function (n) {
                var i = {};
                typeof Reflect === Zt("}lfwqz") &&
                Reflect.ownKeys &&
                Reflect.ownKeys(n).length > 0
                  ? Reflect.ownKeys(n).forEach(function (t) {
                      i[t] = n[t].toString().slice(0, 512);
                    })
                  : (i[Zt("agbu~k")] = n.toString().slice(0, 512)),
                  t({ exch: { chr_e: i } }, !0);
              });
      }
      wi({
        name: "VH",
        flags: 4,
        Iy: function (t, n) {
          n.chrome && n.chrome.runtime
            ? i(t, n)
            : n !== n.top &&
              rt.iframe.YX() &&
              n.top.chrome &&
              n.top.chrome.runtime &&
              i(t, n.top, 1);
        },
      });
    }),
    kt.DR("lw", function (t, n) {
      wi({
        name: "lw",
        Iy: function (t) {
          var n = {},
            i = Zt("wvxw|}e}|");
          function r(t, r) {
            for (
              var o = t + Zt("G|`a"),
                a = document.getElementsByTagName(t),
                e = 0,
                f = a.length;
              e < f;
              ++e
            ) {
              var u = a[e][r] || "",
                c = u.split(Zt("(!#"));
              c.length > 1 &&
                c[0].trim().indexOf(i) > -1 &&
                (n[o] || (n[o] = [])).push(u.trim());
            }
          }
          r(Zt("am~{bz"), Zt("a|o")),
            r(Zt("{h~s\x7fk"), Zt("a|o")),
            r(Zt("wcnwv"), Zt("a|o")),
            r(Zt("s{h{}"), Zt("a|o")),
            r(Zt("dghw}"), Zt("a|o")),
            r(Zt("f|mqy"), Zt("a|o")),
            r(Zt("aay`qk"), Zt("a|o")),
            r(Zt("{ck"), Zt("a|o")),
            r(Zt("}lfwqz"), Zt("voxs")),
            r("a", Zt("z|it")),
            Object.keys(n).length && t({ extens: n }, !0);
        },
      });
    }),
    kt.DR("lH", function (t, n) {
      var i = Z.KV(),
        r = null;
      function o(t) {
        return null !== r
          ? r
          : (r = (function (t) {
              var n,
                r,
                o,
                a,
                e,
                f,
                u,
                c,
                Z,
                s,
                w,
                v,
                h,
                l = {};
              try {
                n = d.object.sB(t.external);
                try {
                  for (f = 0, s = n.length; f < s; f++) l[(e = n[f])] = 1;
                } catch (t) {}
                r = [
                  Zt("SjhQzob|wb"),
                  Zt("SjhVw}gf}~O}\x7f~c|w`x"),
                  Zt("SjhTsxc`{zi"),
                  Zt("SjhAwo~qz^~}dghw`"),
                  Zt("SjhAw|z{qk"),
                  Zt("SjhF}Hmd}|efw}Ns`"),
                  Zt("S{x}Qaab~kxwAozwTa~\x7f"),
                  Zt("S{x}Amm|"),
                  Zt("p{np~kIdw`x"),
                  Zt("Qabfw`xV{}o}dk~k@k\x7fwf"),
                  Zt("[c|}`zIjba~fToz}`gxwa"),
                  Zt("[`\\`{xmfwHe~fk~{|iI|sl`wv"),
                  Zt("[}_ws|ozB|cd{ji`[`\x7ffsb`wv"),
                  Zt("[}_w`xeqwGbafo`~wj"),
                  Zt("[}_gp}o`{liv"),
                  Zt("\x7f}MqfgzwJHe~fk~{|iI|sl`wv"),
                  Zt("\x7f}Mvv]efwCcvw"),
                  Zt("\x7f}MvvZ~sqee|u^~}fkof{ab^{}x"),
                  Zt("\x7f}O~wo~F{bi"),
                  Zt("\x7f}I|sl`wFg`w\\ax{tgosfgc|C{igw"),
                  Zt("\x7f}I|sl`wFg`w\\ax{tgosfgc|C{igwHc`A\x7fys`k='\"v='\""),
                  Zt('\x7f}I|sl`wFg`w\\ax{tgosfgc|C{igwHc`A\x7fys`k?#"v?#"'),
                  Zt("\x7f}I|sl`wFg`w\\ax{tgosfgc|C{igwHc`Eghw!?<j#;<"),
                  Zt("\x7f}EaAgxw_ahw"),
                  Zt("\x7f}EaAgxw_ahwTg~af\\y|"),
                  Zt("\x7f}\\{|`ivAgxwAzmfw"),
                  Zt("\x7f}\\`}xea{ab\\wz{}`e\x7f"),
                  Zt("\x7f}^w\x7fazwAmdwv{`wvZe~w@cf{heqsze}|"),
                  Zt("\x7f}^wba~fAojwG|`"),
                  Zt("\x7f}_qzkhg~khF{bi\\}zet{mmf{ab"),
                  Zt("\x7f}_{fkA}vkMqfgzsfk"),
                  Zt("\x7f}_{fkA}vkMvvLyffabAfw`w"),
                  Zt("\x7f}_{fkA}vkMvvDy\x7fbBeafGxw\x7f"),
                  Zt("\x7f}_{fkA}vkMvvZdg\x7flNs`Lyffab"),
                  Zt("\x7f}_{fkA}vkO~wo~Psjkw"),
                  Zt("\x7f}_{fkA}vkO~wo~[qab]dk~~sw"),
                  Zt("\x7f}_{fkA}vkO~wo~Xgc|^{}x"),
                  Zt("\x7f}_{fkA}vkO`woxwX{ab^g\x7ff"),
                  Zt("\x7f}_{fkA}vk^wt|iazLmvuk"),
                  Zt("\x7f}_{fkA}vk_wfGo}|Azw`bmk"),
                  Zt("\x7f}_{fkA}vk_z}yNgfzc|Azu~w"),
                  Zt("\x7f}_{fkA}vk_z}yFg\x7f~@{az"),
                  Zt("\x7f}_{fkA}vk_z}yXzgcnPs|"),
                  Zt("\x7f}_{fkA}vkYbvoxwFfy\x7fpLm`P{xf}`"),
                  Zt("\x7f}_fs|xBw|e}vgoPsjkwG~hsfk"),
                  Zt("\x7f}_fs|xBw|e}vgoF{biGbjmfw"),
                  Zt("\x7f}_fs|xBw|e}vgoF{biGbjmfwLmfqf"),
                  Zt("\x7f}_f}~\\w`gcv{mNsviiGbjmfw"),
                  Zt("\x7f}_f}~\\w`gcv{mX{~kYbvoxw"),
                  Zt("\x7f}X`smg{|i\\`}ziqfgc|W`mp~kh"),
                  Zt("\\oz{uoxwS`hT{`h"),
                  Zt("`oeawKzw|z"),
                  Zt("akxQ}`xwjzAw|{"),
                  Zt("AfceP|ceak~G["),
                  Zt("\x7fkbgS|kg\x7fkbfa"),
                  Zt("}`z{agn{~gxkqfm|uk"),
                  Zt("am~}~bns`"),
                  Zt("ak`wqzmp~kO}|zi|f"),
                  Zt("dk~a{ab"),
                  Zt("dg\x7f{pg`{fw"),
                  Zt("\x7f}\x7f{fk|{|`iv"),
                  Zt("SjhG`bMgffi|fgosfgc|"),
                  Zt("Qbcaw\\iuBa|gb"),
                  Zt("Tkmfg|iW|on~wj"),
                  Zt("UkxXaabEwlHsfo"),
                  Zt("Ukx@wiZs~{i"),
                  Zt("^ak"),
                  Zt("^akAzk`~W|~}`}C|~w"),
                  Zt("]~i|Ba|gb"),
                  Zt("@kmvTg`w"),
                  Zt("@{bUgz\x7fAq|ebf"),
                  Zt("Aozw@kk[|hc"),
                  Zt("AkxSb~Asjga{hkX{\x7fkX}@k\x7ffs|x"),
                  Zt("AkxSb~A{|ga{hkX{\x7fkX}@k\x7ffs|x"),
                  Zt("AkxSgzcAfo~f"),
                  Zt("AkxSgzcAfo~f_gb{\x7fgvwv"),
                  Zt("Afm`wKzw|zJ`}cN`}y\x7fw`"),
                  Zt("AfceBa|gb"),
                  Zt("Afce@ohs`"),
                  Zt("E|efwHe~w"),
                  Zt("E|efw\\iuDo`gw"),
                  Zt("a{a\x7f}`[s~|ya"),
                ];
                try {
                  for (u = 0, w = r.length; u < w; u++)
                    (e = r[u]),
                      (typeof t.external[e] === Zt("g`g|}yb") ||
                        (i.isEdge() && e in t.external)) &&
                        (l[e] = 1);
                } catch (t) {}
                o = d.object.sB(t.external);
                try {
                  for (c = 0, v = o.length; c < v; c++) l[(e = o[c])] = 1;
                } catch (t) {}
                a = [
                  Zt("SjhAwo~qz^~}dghw`"),
                  Zt("[}_ws|ozB|cd{ji`[`\x7ffsb`wv"),
                  Zt("C{i`kGbfw|jsqk"),
                  Zt("sjhBs`i~"),
                  Zt("sjhBw|\x7f{azi|f^m|wb"),
                  Zt("sjhAwo~qzKbu{`i"),
                ];
                try {
                  for (Z = 0, h = a.length; Z < h; Z++)
                    (e = a[Z]),
                      (typeof t.external[e] === Zt("t{bqfgc|") ||
                        (i.isEdge() && e in t.external)) &&
                        (l[e] = 1);
                } catch (t) {}
              } catch (t) {}
              return d.object.di(l);
            })(t));
      }
      var a = {
          name: "LJ",
          flags: 32,
          Iy: function (t, n) {
            t({ initdata: { externalnames: o(n) } }, !0);
          },
        },
        e = {
          name: "lH",
          Iy: function (t, n) {
            var i;
            t(
              {
                initdata: {
                  externalnames: o(n),
                  external:
                    ((i = rt.object.clone(n.external)),
                    i &&
                      (i.jsWindow &&
                        i.jsWindow.ScreenNameHash &&
                        (i.jsWindow.ScreenNameHash = null),
                      i.jsWindow &&
                        i.jsWindow.FullScreenNameHash &&
                        (i.jsWindow.FullScreenNameHash = null),
                      i.FullScreenNameHash && (i.FullScreenNameHash = null),
                      i.ScreenNameHash && (i.ScreenNameHash = null)),
                    i),
                },
              },
              !0
            );
          },
        };
      wi(a), wi(e);
    }),
    kt.DR("gt", function (t, n) {
      function i(t) {
        var n,
          i,
          o,
          a,
          e,
          f = "",
          u = "",
          c = { Default: 0 },
          Z = String(Math.random()),
          s = [
            Z,
            Zt("Gly|f{"),
            Zt("Gzcb{o"),
            Zt("G\\[2Uaxz{m,^"),
            Zt("Pgxaf|is\x7f.Ozs|xw`"),
            Zt("T|iw_ab}"),
            Zt("VkfsD{,As`\x7f"),
            Zt("V|c{v._w`gj"),
            Zt("^gnw`ox{}`,As`\x7f"),
            Zt("D|e|vo"),
            Zt("Yo~f{em"),
            Zt("Aw`tskb"),
            Zt("Qa~v{oYBQ"),
            Zt("S`kas`m2\\k{2Pa`v2Gxs~go"),
            Zt("VHGs{#_P"),
            Zt("Wl~{\x7fo"),
            Zt("^oc2GG"),
            Zt("Akk}w.Y[2]u\x7fpa`"),
            Zt("Dgfsko"),
            Zt("@an}fa"),
            Zt("S~|~w.O}~a~2Wccx{"),
            Zt("Po\x7fyw|z{~bi"),
            Zt("_o~yw|,Twbx"),
            Zt("S~|~w._k\x7flc~a"),
            Zt("Qfm~ylcs`j"),
            Zt("Zk~qgbm|gc"),
            Zt("Aees"),
            Zt("Pod|amd`{hx"),
            Zt("S`hs~{\x7f"),
            Zt("K{,U}zd{q"),
            Zt("Sbhzsle"),
            Zt("Qo`{p|e2^gkzf"),
          ],
          w = t.createElement(Zt("vgz")),
          v = t.getElementsByTagName(Zt("pahk"))[0];
        for (o = s.length, i = 0; i < o; ++i)
          (e = s[i]),
            ((n = t.createElement(Zt("a~m|"))).id = Zt("MQj}|zS") + e),
            (n.style.fontFamily = e),
            (n.style.fontSize = Zt("%<|j")),
            (n.innerHTML = Zt("\x7fca\x7f\x7fca\x7f\x7fc`~{")),
            w.appendChild(n);
        for (v.appendChild(w), o = s.length, i = 0; i < o; ++i)
          (e = s[i]),
            (a = (n = t.getElementById(Zt("MQj}|zS") + e)).offsetWidth),
            (c[e !== Z ? e : Zt("Vkjsgbx")] = a !== c.Default ? a : 0);
        for (var h in c) c.hasOwnProperty(h) && (f += c[h] > 0 ? 1 : 0);
        v.removeChild(w);
        try {
          if (document.fonts && typeof document.fonts.check === Zt("t{bqfgc|"))
            for (o = s.length, i = 1; i < o; ++i)
              u += 0 | document.fonts.check(Zt("#<|j2") + s[i]);
          else u = "e";
        } catch (t) {
          u = (t + "").substring(0, 11);
        }
        return { h: r(f), v: "1", n: r(u) };
      }
      function r(t) {
        return parseInt(t, 2).toString(16);
      }
      wi({
        name: "gt",
        flags: 16,
        Iy: function (t, n, r) {
          t({ fonts: i(r.contentWindow.document) }, !0);
        },
      });
    }),
    kt.DR("Rh", function (t, n) {
      var i,
        r = kt.KV(),
        o = r.ma().yj();
      function a(t, n, i) {
        if (t.length !== n * i) return "";
        for (var r = [], o = 0, a = 0, e = 0; e < i; e++)
          for (var f = 0; f < n - 1; f++) {
            var u = e * n + f;
            t[u] > t[u + 1] && (o |= 1 << (7 - a)),
              8 === ++a && (r.push(o), (o = 0), (a = 0));
          }
        a > 0 && r.push(o);
        for (var c = "", Z = 0; Z < r.length; Z++)
          c += String.fromCharCode(r[Z]);
        return btoa(c);
      }
      function e(t) {
        var n = t.fonts,
          i = t.encode,
          r = t.width,
          o = t.height;
        function e(t, n) {
          var i = "monospace";
          n.font = "10px " + i;
          var r = n.measureText("MW").width;
          return (
            (n.font = "10px " + t + ", " + i), r !== n.measureText("MW").width
          );
        }
        function f(t) {
          var n = String.fromCharCode.apply(null, t);
          return btoa(n);
        }
        function u(t, n, i, r, o, a) {
          (t.fillStyle = "white"),
            t.fillRect(0, 0, r, o),
            (t.fillStyle = "black"),
            (t.font = a + "px " + n),
            t.fillText(i, r / 2, o / 2);
          for (
            var e = t.getImageData(0, 0, r, o).data,
              f = new Uint8Array(r * o),
              u = 0,
              c = 0;
            u < e.length;
            u += 4, c++
          )
            f[c] = 0.299 * e[u] + 0.587 * e[u + 1] + 0.114 * e[u + 2];
          return f;
        }
        var c = {},
          Z = i ? {} : null;
        try {
          var s = new OffscreenCanvas(r, o).getContext("2d", {
            willReadFrequently: !0,
          });
          for (var w in ((s.textBaseline = "middle"),
          (s.textAlign = "center"),
          n))
            if (n.hasOwnProperty(w)) {
              (c[w] = {}), i && (Z[w] = {});
              var v = e(w, s);
              for (var h in n[w])
                if (n[w].hasOwnProperty(h)) {
                  if (!v) {
                    (c[w][h] = null), i && (Z[w][h] = "na");
                    continue;
                  }
                  var l = u(s, w, h, r, o, 14);
                  (c[w][h] = a(l, r, o)), i && (Z[w][h] = f(l));
                }
            }
          return { fontr2: c, fontr2r: Z };
        } catch (t) {
          return { err: { message: t.message, name: t.name } };
        }
      }
      wi({
        name: "Rh",
        flags: 4,
        gE: 32767,
        Iy: function (t, n) {
          if (o.bwk)
            if (rt.pA.AY() && typeof OffscreenCanvas !== Zt("g`hwtgbwv")) {
              var f,
                u = e.toString(),
                c = a.toString(),
                Z = Zt("[c|sqz"),
                s = Zt("S|es~"),
                w = Zt("Qay`{k~2\\k{"),
                v =
                  (((f = {})[Z] = { 0: "" }),
                  (f[s] = { M: "", E: "" }),
                  (f[w] = { g: "" }),
                  f),
                h = r.UR(100, Zt("tabf`<~")),
                l = new Blob([
                  Zt("}`awa}muw3jg|mx{}`$MMh~Wdz%iba\x7ff_k\x7fasii:") +
                    e.name +
                    Zt(":QSt`Kzf<jmfs'%)o\x04\x06") +
                    e.name +
                    Zt("23,") +
                    u +
                    "\n\n" +
                    a.name +
                    Zt("23,") +
                    c,
                ]);
              (i = new Worker(n.URL.createObjectURL(l))).addEventListener(
                Zt("\x7fk\x7fasii"),
                function (n) {
                  var i = n.data;
                  if (i.err) t({ fontr2: i }, !0);
                  else {
                    var r = { fontr2: i.fontr2 };
                    h && i.fontr2r && (r.fontr2r = i.fontr2r), t(r, !0);
                  }
                }
              ),
                i.postMessage({ fonts: v, encode: h, width: 16, height: 16 });
            } else
              t(
                {
                  fontr2: {
                    err: {
                      message: Zt(
                        "]hjaq|iw|Mm|do\x7f2}|,P~anE}|gw`.ea2`cf2}ybba~fwj"
                      ),
                      name: Zt("G`\x7fgb~c`fkhW`|c`"),
                    },
                  },
                },
                !0
              );
        },
        stop: function () {
          i && i.terminate();
        },
      });
    }),
    kt.DR("xl", function (t, n) {
      var i = {};
      !(function () {
        for (
          var t = [
              "",
              [63914, 37419],
              [],
              [27274, 47709],
              HTMLElement,
              [37580, 54233],
            ],
            n = 0;
          n < t.length;
          n += 2
        ) {
          var r = t[n],
            o = t[n + 1],
            a = lb.encode(o);
          void 0 !== r[(a = a.slice(0, -1))] && (i[n] = !0);
        }
        for (var e = String, f = d.object.sB(e), u = 0; u < f.length; u++)
          2088075073 === rt.IO.iX(f[u]) && (i.e = { len: f.length, p: u });
      })(),
        wi({
          name: "xl",
          Iy: function (t) {
            Object.keys(i).length > 0 && t({ gex: i }, !0);
          },
        });
    }),
    kt.DR("Cr", function (t, n) {
      wi({
        name: "Cr",
        Iy: function (t) {
          if (rt.iframe.YX()) {
            var n = {};
            try {
              var i = window.top.performance.getEntriesByType(
                Zt("|oz{uox{}`")
              )[0];
              i &&
                ((n[Zt("f}ehw")] = i.transferSize),
                (n[Zt("p}ehw")] = i.encodedBodySize),
                (n[Zt("bzubw")] = i.type));
            } catch (t) {}
            try {
              n[Zt("vk|Mbzubw")] = window.top.performance.navigation.type;
            } catch (t) {}
            Object.keys(n).length && t({ hba: n }, !0);
          }
        },
      });
    }),
    kt.DR("Vu", function (t, n) {
      function i(t, n) {
        t.preventDefault && t.stopPropagation
          ? (t.preventDefault(), t.stopPropagation())
          : void 0 !== t.returnValue && (t.returnValue = !1),
          n({ hiddena: !0 }, !0);
      }
      wi({
        name: "Vu",
        flags: 4,
        Iy: function (t, n) {
          if (n !== n.top) {
            var r = document.getElementsByTagName(Zt("pahk"))[0],
              o = document.createElement("a"),
              a = [document.createElement(Zt("vgz")), o],
              e = null;
            (o.innerHTML = Zt("MQS")),
              o.setAttribute(Zt("fon{|jij"), "-1"),
              o.setAttribute(Zt("z|it"), "#"),
              o.addEventListener
                ? o.addEventListener(
                    Zt("qbeqy"),
                    function (n) {
                      i(n, t);
                    },
                    !1
                  )
                : o[Zt("szxsqfIdw`x")] &&
                  o[Zt("szxsqfIdw`x")](Zt("}`o~{mg"), function (n) {
                    i(n, t);
                  });
            for (var f = 0; f < a.length; ++f) {
              (e = a[f]).setAttribute(Zt("s|es?fevvkb"), Zt("f|yw")),
                (e.style.opacity = Zt('" <#')),
                (e.style.position = Zt("sl\x7f}~{xw")),
                (e.style.zIndex = -1 * (1e3 - f) + ""),
                (e.style.width = Zt("':|j")),
                (e.style.height = Zt(" <|j"));
              var u = Z.KV();
              u.PC() && u.version(1) < 9 && (e.style.visibility = Zt("zghvw`")),
                r.insertBefore(e, r.firstChild);
            }
          }
        },
      });
    }),
    kt.DR("aZ", function (t, n) {
      var i,
        r,
        o,
        a,
        e,
        f,
        u,
        c = kt.KV(),
        Z = [],
        s = {},
        w = !1,
        v = Zt("MQjazcb");
      wi({
        name: "aZ",
        Iy: function (t) {
          if (
            1 !== document[v] &&
            (!c.ma().isVast() || c.UR(1e3, Zt("dQdg\x7f")))
          ) {
            document[v] = 1;
            var n = 0,
              h = 0,
              l = {};
            w ||
              ((i = document[Zt("}`x}gmdafo~f")]),
              (r = document[Zt("}`x}gmdw|j")]),
              (o = document[Zt("}`a}g}iv}yb")]),
              (a = document[Zt("}`a}g}igb")]),
              (e = document[Zt("}`a}g}i\x7f}xi")]),
              (f = document[Zt("}`o~{mg")]),
              (u = document[Zt("}`|}{`xw`{|")])),
              (document[Zt("}`x}gmdafo~f")] = function (t) {
                h = Date.now();
                var n = t[Zt("qfm|ukhF}{ozw}")];
                if (n && n.length)
                  for (var r = 0, o = n.length; r < o; ++r) {
                    var a = n[r];
                    l[a.identifier] = {
                      identifier: a.identifier,
                      touchDownStart: h,
                      touchStartForce: a[Zt("ta~qw")],
                      touchStartRadiusX: a[Zt("`oh{g}T")],
                      touchStartRadiusY: a[Zt("`oh{g}U")],
                    };
                  }
                i && i(t);
              }),
              (document[Zt("}`x}gmdw|j")] = function (i) {
                var o = Date.now(),
                  a = {
                    prev: n && o - n,
                    len: o - h,
                    nt: i[Zt("{}X`g}xwv")] ? void 0 : 1,
                  };
                n = o;
                var e = i[Zt("qfm|ukhF}{ozw}")];
                if (e && e.length)
                  for (var f = 0, u = e.length, c = !1; f < u; ++f) {
                    var Z = e[f],
                      s = l[Z.identifier];
                    delete l[Z.identifier],
                      s &&
                        !c &&
                        ((c = !0),
                        (a.len = o - s.touchDownStart),
                        (a.tdfrc = s.touchStartForce),
                        (a.tdradx = s.touchStartRadiusX),
                        (a.tdrady = s.touchStartRadiusY),
                        (a.tufrc = Z[Zt("ta~qw")]),
                        (a.turadx = Z[Zt("`oh{g}T")]),
                        (a.turady = Z[Zt("`oh{g}U")]));
                  }
                t({ hmn: { tdu: [a] } }, !1), r && r(i);
              });
            var b = 0,
              d = 0;
            (document[Zt("}`a}g}iv}yb")] = function (t) {
              (d = Date.now()), o && o(t);
            }),
              (document[Zt("}`a}g}igb")] = function (n) {
                var i = Date.now(),
                  r = {};
                (r.prev = 0 === b ? 0 : i - b),
                  (b = i),
                  (r.len = i - d),
                  n[Zt("{}X`g}xwv")] || (r.nt = 1),
                  n.sourceCapabilities
                    ? (r.fte =
                        !0 === n.sourceCapabilities[Zt("tg~waZcgqfIdw`xa")]
                          ? 1
                          : 0)
                    : (r.fte = -1),
                  t({ hmn: { mdu: [r] } }, !1),
                  a && a(n);
              });
            var g = 0,
              m = 0,
              k = 0,
              z = 0,
              y = -1,
              p = 0,
              x = 0;
            document[Zt("}`a}g}i\x7f}xi")] = function (t) {
              ++y > 0 &&
                ((g = Math.abs(k - t.x)),
                (m = Math.abs(z - t.y)),
                0 === x &&
                ((g > 20 && 0 === m) || (m > 20 && (0 === g || g === m))) &&
                ++p === y
                  ? (s.cjmp = p)
                  : (x++, (s.cjmp = 0)),
                (s.cmme = y)),
                (k = t.x),
                (z = t.y),
                e && e(t);
            };
            var j = 0;
            Z.push(rt.PA.timeout(this, q, 2e3)),
              Z.push(rt.PA.interval(this, q, 15e3)),
              (document[Zt("}`o~{mg")] = function (n) {
                var i = n[Zt("fo~uwz")],
                  r = i[Zt("}hjawz[{vzd")],
                  o = i[Zt("}hjawzDw{idf")],
                  a = n[Zt("}hjawzT")],
                  e = n[Zt("}hjawzU")],
                  u = { width: r, height: o, x: a, y: e };
                u[Zt("fw|w")] = (function (t, n, i, r) {
                  if (!rt.object.QX(n) || !rt.object.QX(t) || t < 5 || n < 5)
                    return -1;
                  var o = Math.floor(n / 2),
                    a = Math.floor(t / 2);
                  switch (!0) {
                    case !(
                      (r !== o && r !== o + 1) ||
                      (i !== a && i !== a + 1)
                    ):
                      return 5;
                    case r <= 1 && i <= 1:
                      return 1;
                    case r <= 1 && i >= t - 1:
                      return 2;
                    case r >= n - 1 && i <= 1:
                      return 3;
                    case r >= n - 1 && i >= t - 1:
                      return 4;
                    default:
                      return 0;
                  }
                })(r, o, a, e);
                var c = i[Zt("fok\\sci")];
                i[Zt("fw|w")] && (c = c + "-" + i[Zt("fw|w")]),
                  (u[Zt("fok\\sci")] = c),
                  t({ hmn: { mck: [u] } }, !1),
                  f && f(n);
              }),
              (w = !0);
          }
          function q() {
            j < s.cmme && ((j = s.cmme), t({ hmn: { mmc: [s] } }, !1));
          }
        },
        stop: function () {
          (s = {}),
            w &&
              ((document[Zt("}`x}gmdafo~f")] = i),
              (document[Zt("}`x}gmdw|j")] = r),
              (document[Zt("}`a}g}iv}yb")] = o),
              (document[Zt("}`a}g}igb")] = a),
              (document[Zt("}`a}g}i\x7f}xi")] = e),
              (document[Zt("}`o~{mg")] = f),
              (document[Zt("}`|}{`xw`{|")] = u),
              delete document[v]),
            (w = !1);
          for (var t = 0; t < Z.length; t++) Z[t] && Z[t]();
        },
      });
    }),
    kt.DR("vr", function (t, n) {
      wi({
        name: "vr",
        flags: 16,
        gE: 10,
        Iy: function (t, n, i) {
          var r = i.contentWindow.document,
            o = Z.KV();
          if (o.PC()) {
            var a =
                Zt("xozsam~{bz65") +
                rt.script.ML +
                Zt("zzxbaGauW|~/to`aw5") +
                Zt("~amv@ob/to`aw5") +
                Zt('egbv}y"}|bcsv3jg|mx{}`$;ibcsv\\m|/z~gw5q') +
                rt.script.Ej +
                Zt(
                  ".gau2gh/zzxbaGau2}~q/fxfb}6==!,}|k~`}|1N5fxfb}E\x7fuK~`/z~gwR+,55"
                ),
              e = rt.iframe.Ns();
            (e.src = a),
              (e.onload = function (n) {
                try {
                  var i = n.iframe;
                  if (i.contentWindow.loadRan) {
                    var r = i.contentWindow.document.getElementById(
                        Zt("zzxbaGau")
                      ),
                      o = rt.object.QX(r.naturalWidth)
                        ? r.naturalWidth
                        : r.width;
                    t(
                      {
                        malformedHttpsImg: {
                          reachable: i.contentWindow.httpsImgErr,
                          w: o,
                        },
                      },
                      !1
                    );
                  }
                } catch (t) {}
              }),
              e.attach(r.body);
          }
          if (o.isGecko()) {
            var f = new Image();
            (f.style.display = Zt("|abw")),
              (f.src = kt.KV().ma().Ug() + Zt('=?"u{h')),
              (f.onload = function () {
                t({ normalImg: { reachable: f.height } }, !0);
              }),
              (f.onerror = function () {
                t({ normalImg: { reachable: !1 } }, !0);
              }),
              r.body.appendChild(f);
          }
        },
      });
    }),
    kt.DR("vw", function (t, n) {
      wi({
        name: "vw",
        flags: 4,
        Iy: function (t) {
          (rt.iframe.Gz() > 0 || Z.KV().Ac()) &&
            (function (n) {
              for (var i = 0; i < n.length; i++)
                if (rt.ads.sJ(n[i].clientWidth, n[i].clientHeight)) {
                  t({ imgAdSizeMatch: !0 }, !0);
                  break;
                }
            })(document.getElementsByTagName(Zt("{ck")));
        },
      });
    }),
    kt.DR("Pw", function (t, n) {
      var i,
        r,
        o,
        a,
        e = kt.KV().ma().yj(),
        f = Z.KV(),
        u = rt.object.QX,
        c = rt.iframe.YX,
        s = rt.object.mi,
        w = {},
        h = [];
      function l(t) {
        return function (n, i, r, o) {
          !(function (t, n, i, r, o) {
            void 0 === r && (r = {});
            try {
              typeof r === Zt("t{bqfgc|") && (o = r),
                typeof r !== Zt("az~{|i") && (r = n);
              var a = rt.object.uN(i, r.split("_"));
              switch ((o && (a = o(a)), typeof a)) {
                case Zt("g`hwtgbwv"):
                  break;
                case Zt("az~{|i"):
                case Zt("|{apw|"):
                case Zt("pac~wob"):
                  t[n] = a;
                  break;
                case Zt("t{bqfgc|"):
                  t[n] = rt.IO.TU(a);
                  break;
                case Zt("}lfwqz"):
                  if (null === a) break;
                default:
                  t[n] = rt.object.clone(a);
              }
            } catch (t) {}
          })(t, n, i, r, o);
        };
      }
      function b(t) {
        var n = a[Zt("|oz{uox}`")][Zt("g}i`Smx{dox{}`")],
          e = Zt("|oz{uox}`") + "_" + Zt("g}i`Smx{dox{}`");
        if (n) {
          var f = {};
          (f[e] = {}),
            (f[e][Zt("zo\x7fPwkbSqzedw")] = n.hasBeenActive),
            (f[e][Zt("{}Mqfgzw")] = n.isActive),
            o({ initdata: f }, !1);
        }
        1 === t ? r() : 2 === t && i();
      }
      var g = {
          name: "cu",
          flags: 32,
          gE: 3,
          Iy: function (t, n) {
            if (((a = n), (o = t), e.doQuickPost)) {
              var f = l(w);
              f(Zt("~aosfgc|Mf~wt"), n),
                f(Zt("vaog\x7fkbf") + "_" + Zt("`kjw`|i`"), n),
                f(Zt("\x7fotQ}`bwqze}|}\\w`]i`dk~"), n),
                (w[Zt("tg~afQ~g|")] = !0),
                t({ initdata: w }, !1);
            }
            b(0),
              (i = v.subscribe(2, function () {
                b(2);
              })),
              (r = rt.PA.timeout(
                this,
                function () {
                  b(1);
                },
                kt.iI - 1e4
              ));
          },
        },
        m = {
          name: "vt",
          gE: 2,
          Iy: function (t) {
            var n,
              i = (function () {
                var t,
                  n,
                  i,
                  r,
                  o,
                  a,
                  w,
                  v,
                  h,
                  b,
                  g,
                  m,
                  k,
                  z,
                  y = window;
                h = {};
                var p = [
                    Zt("xzfp"),
                    Zt("jga{z;\x7fvy"),
                    Zt("S`h`}ghP`ghuw"),
                    Zt("GO|\x7fX]N`{jkw"),
                    Zt("X}N`{jkw"),
                    Zt("S`h`}gh"),
                  ],
                  x = l(h),
                  j = function (t) {
                    return typeof t;
                  },
                  q = function (t) {
                    var n = typeof t;
                    if (t && n === Zt("}lfwqz"))
                      return { k: Object.keys(t).slice(0, 10), t: n };
                  };
                x(Zt("vaog\x7fkbf") + "_" + Zt("`kjw`|i`"), y),
                  x(Zt("\x7fotQ}`bwqze}|}\\w`]i`dk~"), y),
                  x(Zt("azmfg}"), y),
                  x(Zt("vkjsgbxAfoxga"), y),
                  x(Zt("bk~t}|as|mi") + "_" + Zt("\x7fka}`w"), y, s),
                  x(Zt("am~ww`"), y, function (t) {
                    return t || {};
                  }),
                  x(Zt("vkz{qk\\{jk`@sze}"), y),
                  x(Zt("\x7favBsgbfQay|f"), y),
                  f.isSafari() || x(Zt("azu~wCiv{oSfk~i"), y),
                  x(Zt("zg\x7ff}|u") + Zt("Mbi|uzd"), y),
                  x(Zt("}~i|w|"), y, Zt("fa|M") + Zt("}~i|w|"), function (t) {
                    return null !== t ? typeof t : Zt("|{`~");
                  }),
                  x(Zt("|oz{uox}`") + "_" + Zt("g}i`Sii|f"), y),
                  x(Zt("tg`wQ|isfkhVszi"), y),
                  x(Zt("tg`w_ah{tgivVoxw"), y),
                  x(Zt("tg`wG~hsfkhVszi"), y),
                  x(Zt("{}_wq{~wQabfwvx"), y),
                  x(Zt("~o\x7ff_ah{tgiv"), y),
                  x(Zt("~aosfgc|Mf~wt"), y),
                  x(Zt("@ka}fk\\~swnsqe"), y),
                  x(Zt("Bk~\x7f{}\x7f{}`\x7f"), y),
                  x(Zt("\\ax{tgosfgc|"), y),
                  x(Zt("_kh{s]iaagc|"), y),
                  x(Zt("|oaw"), y, function (t) {
                    return t.substr(0, 128);
                  }),
                  x(
                    Zt("vkjsgbxD{k{"),
                    y,
                    Zt("vaog\x7fkbf") + "_" + Zt("vkjsgbxD{k{"),
                    function (t) {
                      return u(t) ? t === window : Zt("g`hwtgbwv");
                    }
                  ),
                  l((h[Zt("qaba}bi")] = {}))(
                    Zt("\x7fka}`w"),
                    y[Zt("qaba}bi")] || {},
                    s
                  ),
                  x(Zt("~aos~]x}`okw"), y, j),
                  x(Zt("ekny{zB}fgj{qox{}`\x7f"), y, j),
                  x(Zt("ekny{zMgvgcQ}`xwjz"), y, j),
                  p.forEach(function (t) {
                    x(t, y, q);
                  }),
                  x(Zt("qf~}\x7fk"), y, d.object.di),
                  x(Zt("}~i`s"), y, d.object.di),
                  x(Zt("|oz{uox}`") + "_" + Zt("azm|vo`}|k"), y),
                  x(
                    Zt("|ozfk~i"),
                    y,
                    Zt("bk~t}|as|mi") + "_" + Zt("|oz{uox{}`Sfk~i")
                  ),
                  x(
                    Zt("|oz`wje`a"),
                    y,
                    Zt("bk~t}|as|mi") + "_" + Zt("|oz{uox{}`S`wje`wmxQ}{bf")
                  ),
                  x(Zt("~amvFgawa"), y, Zt("qf~}\x7fkS~}ohF{cia")),
                  x(Zt("dkbv}|"), y, Zt("|oz{uox}`") + "_" + Zt("dkbv}|")),
                  x(
                    Zt("qahw|oaw"),
                    y,
                    Zt("|oz{uox}`") + "_" + Zt("s~|Q}ji\\sci")
                  ),
                  x(
                    Zt("|ozSb~Zw`}e}|"),
                    y,
                    Zt("|oz{uox}`") + "_" + Zt("s~|dw|\x7f{}`")
                  ),
                  x(
                    Zt("|oz^s`kgsiia"),
                    y,
                    Zt("|oz{uox}`") + "_" + Zt("~obugokwa")
                  ),
                  x(Zt("|oz]|be|w"), y, Zt("|oz{uox}`") + "_" + Zt("}`@{|k")),
                  x(Zt("|oz]AM|g"), y, Zt("|oz{uox}`") + "_" + Zt("}}obg")),
                  x(
                    Zt("|ozB`ahgqz_gp"),
                    y,
                    Zt("|oz{uox}`") + "_" + Zt("b|cvgmxagl")
                  ),
                  x(Zt("|ozD{l~sfk"), y, Zt("|oz{uox}`") + "_" + Zt("dgn`szi")),
                  x(
                    Zt("|ozEwlh`{xi`"),
                    y,
                    Zt("|oz{uox}`") + "_" + Zt("eknv`gzw`")
                  ),
                  x(
                    Zt("|ozQs`K}Pooy"),
                    y,
                    Zt("|oz{uox{}`") + "_" + Zt("qobU}Lmqy")
                  ),
                  x(
                    Zt("|ozQB[\\w`h"),
                    y,
                    Zt("|oz{uox}`") + "_" + Zt("q~yBw|j}`cm|qk")
                  ),
                  x(Zt("Ak~d{miE}|gw`"), y),
                  x(Zt("S~|~w^mkAkxgb"), y),
                  x(Zt("Qoozw"), y),
                  x(Zt("Bou\x7fw`xSvj~wa}"), y),
                  x(Zt("_k~qzobfDo`{vox{}`Idw`x"), y),
                  x(
                    Zt("\x7fkh{sJid{mia"),
                    y,
                    Zt("|oz{uox}`") + "_" + Zt("\x7fkh{sJid{mia")
                  ),
                  x(Zt("afm`w"), y, Zt("|oz{uox}`") + "_" + Zt("afm`w")),
                  (h.io = void 0 !== y.IntersectionObserver),
                  x(Zt("sjkd"), y, Zt("sjkMdk~a{ab")),
                  e.hco &&
                    x(
                      Zt("|ozZs|hes|iQ}`o"),
                      y,
                      Zt("|oz{uox}`") + "_" + Zt("zo~veo~wQabqg|~w|mu")
                    ),
                  e.ndm &&
                    x(
                      Zt("|ozVwxAw\x7f"),
                      y,
                      Zt("|oz{uox}`") + "_" + Zt("vkz{qkAw\x7fa~k")
                    ),
                  e.nvl &&
                    x(
                      Zt("|oz^}mga") + "R",
                      y,
                      Zt("|oz{uox}`") + Zt("Mbcqy}S`w\x7fywaz"),
                      function (t) {
                        return typeof t === Zt("g`hwtgbwv")
                          ? Zt("g`hwtgbwv")
                          : t;
                      }
                    ),
                  e.wor && x(Zt("}|eu{`"), y, Zt("}|eu{`")),
                  typeof location === Zt("}lfwqz") &&
                    x(Zt("b|cf}mc~"), location),
                  typeof document === Zt("}lfwqz") &&
                    (x(Zt("zghvw`"), document),
                    x(Zt("vaog\x7fkbf_ahw"), document),
                    x(Zt("qaabszA}vk"), document),
                    x(Zt("dg\x7f{pg`{fw_fszi"), document),
                    x(Zt("vQc`{ie|"), document, Zt("}|eu{`")),
                    x(
                      Zt("vj`M}|eu{`"),
                      document,
                      Zt("vkjsgbxD{k{M~aosfgc|Ma~{ugb")
                    ));
                var M = c();
                h[Zt("fa|") + "_" + Zt("smowa}")] = M;
                try {
                  if (
                    (!u(top) ||
                      null === top ||
                      !top.window ||
                      (document.location.ancestorOrigins &&
                        document.location.ancestorOrigins.length > 0 &&
                        document.location.ancestorOrigins[0] !==
                          document.location.protocol +
                            "//" +
                            document.location.host) ||
                      (h[Zt("fa|M`kj")] = y.top.document.referrer),
                    M &&
                      ((h[Zt("fa|") + "_" + Zt("~aosfgc|Mf~wt")] =
                        top.location.href),
                      (h[Zt("fa|") + "_" + Zt("qobU}Lmqy")] = (top[
                        Zt("|oz{uox{}`")
                      ] || {})[Zt("qobU}Lmqy")]),
                      p.forEach(function (t) {
                        h[Zt("fa|") + "_" + t] = q(top[t]);
                      }),
                      top.PX && (h[Zt("fa|") + "_PX"] = !0),
                      top.document))
                  ) {
                    var S = top.document.querySelector(
                      Zt("~gbyI|i~/,os|ab{qo`0O")
                    );
                    if (S)
                      h[Zt("fa|") + Zt("Mmm|}`eqsb")] = S[Zt("z|it")].slice(
                        0,
                        512
                      );
                    else {
                      var A = top.document.querySelector(
                        Zt("\x7fkxsI~~}bk~fk3.}u4y`~,Q")
                      );
                      h[Zt("fa|") + Zt("MakG`b")] = A[Zt("qabfw`x")].slice(
                        0,
                        512
                      );
                    }
                    var O = top.document.querySelector(
                      Zt("\x7fkxsI`m\x7fw3.`}lcfa,Q")
                    );
                    O &&
                      (h[Zt("fa|") + Zt("M|cp}z\x7f")] = O[Zt("qabfw`x")].slice(
                        0,
                        128
                      ));
                  }
                } catch (t) {}
                h[Zt("fa_f`gbuS~|~k")] = Zt('is"f}]x`{`k<s~|~k&');
                try {
                  h[Zt("tzc")] = !!x.toString.prototype;
                } catch (t) {
                  h[Zt("tzc")] = !0;
                }
                try {
                  h[Zt("t~xa\\oaw")] = x.toString[Zt("|oaw")];
                } catch (t) {
                  h[Zt("t~xa\\oaw")] = Zt("g`hwt");
                }
                try {
                  Function.prototype.toString.call(x.toString);
                } catch (t) {
                  h[Zt("t~xa[}\\`}vu")] = t.message.substr(0, 512);
                }
                try {
                  h[Zt("ei`Ub]x`")] =
                    y.WebGLRenderingContext &&
                    !rt.wX.IG(y.WebGLRenderingContext.prototype.getParameter)
                      ? y.Function.prototype.toString
                          .call(y.WebGLRenderingContext.prototype.getParameter)
                          .slice(0, 512)
                      : void 0;
                } catch (t) {}
                try {
                  var _ = Object.keys(
                    Object.getOwnPropertyDescriptors(x.toString)
                  );
                  for (n = 0; n < _.length; n++)
                    /Symbol\(src\)_1\..*/.exec(_[n]) &&
                      (h[Zt("t~xaY`ce|Azw`y~{fk")] = !0);
                } catch (t) {}
                try {
                  h[Zt("`ah")] = {
                    lw: Math.round(0.49999999999999994),
                    hg: Math.round(Math.pow(2, 52)),
                  };
                } catch (t) {}
                try {
                  h[Zt("w`h")] =
                    new Uint16Array(new Uint8Array([1, 2]).buffer)[0] >> 9
                      ? "l"
                      : "b";
                } catch (t) {}
                for (
                  !0 === f.isGecko() &&
                    typeof navigator === Zt("}lfwqz") &&
                    x(Zt("\x7fav[aBcqsb`kSxm{~on~w"), navigator, j),
                    r = {},
                    o = {},
                    a = 0,
                    g = 0,
                    m = (z = navigator.plugins).length;
                  g < m;
                  g++
                ) {
                  (i = z[g]), (w = !1);
                  try {
                    r[i.filename] = 1;
                  } catch (t) {}
                  try {
                    (v = {
                      f: i.filename || typeof i.filename,
                      n: i.name || typeof i.name,
                    }),
                      (w =
                        i.description &&
                        i.description.match(/\s(\d+(?:\.\d+)+\b)/)),
                      Array.isArray(w) && (v.v = w[1].substring(0, 50)),
                      (o[a++] = v);
                  } catch (t) {}
                }
                try {
                  h[Zt("bbyu{`\x7f")] = rt.object.clone(d.object.di(r));
                } catch (t) {}
                h[Zt("bbyuwvx")] = o;
                try {
                  rt.object.QX(navigator.plugins.length) &&
                    (h[Zt("bbyu{`\x7f") + Zt("Mbi|")] =
                      navigator.plugins.length);
                } catch (t) {}
                try {
                  h[Zt("{h~s\x7fkSvw~xz")] = rt.iframe.Gz();
                } catch (t) {}
                (h[Zt("dgieba~f")] = rt.wX.getViewport(y)),
                  (z = d.object.sB(y.screen));
                var Q = d.object.BJ(y.screen);
                if (z.length)
                  for (h[Zt("am~ww`")] = {}, k = 0, m = z.length; k < m; k++) {
                    n = z[k];
                    try {
                      (b = y.screen[n]),
                        [Zt("|{apw|"), Zt("az~{|i"), Zt("pac~wob")].indexOf(
                          typeof b
                        ) > -1
                          ? ((h[Zt("am~ww`")][n] = b),
                            u(Q[n]) &&
                              (h[Zt("am~ww`")]["g_" + n] = rt.IO.TU(Q[n].get)))
                          : (h[Zt("am~ww`")][n] = typeof b);
                    } catch (t) {}
                  }
                (h[Zt("am~ww`TK")] = {
                  x: y.screenX,
                  y: y.screenY,
                  left: y.screenLeft,
                  top: y.screenTop,
                }),
                  c() && (h[Zt("bokwAgvw")] = rt.wX.qY(top)),
                  y.webkitNotifications
                    ? (h[Zt("|ax{tgosfgc|a")] = "wk")
                    : y.Notification
                    ? (h[Zt("|ax{tgosfgc|a")] = Zt("e=o"))
                    : (h[Zt("|ax{tgosfgc|a")] = Zt("g`hwt"));
                try {
                  var T =
                    window[Zt("q|ubfa")] || window[Zt("\x7f}O`k~x}")] || void 0;
                  u(T) &&
                    (h[Zt("q|ubfa_gpz`w")] = u(T.subtle)
                      ? typeof T.subtle
                      : Zt("g`hwt"));
                } catch (t) {}
                try {
                  navigator.platform
                    ? (h[Zt("bbmfta~\x7f")] = rt.object.clone(
                        navigator.platform
                      ))
                    : (h[Zt("bbmfta~\x7f")] = Zt("g`hwt"));
                } catch (t) {}
                try {
                  h[Zt("\x7fan{~kSp`a{aw|")] = f.isMobile();
                } catch (t) {}
                try {
                  void 0 !== navigator.maxTouchPoints
                    ? (h[Zt("\x7fz|")] = navigator.maxTouchPoints)
                    : (h[Zt("\x7fz|")] = Zt("g`hwt"));
                } catch (t) {}
                try {
                  var N = 0;
                  for (
                    z = [
                      Zt("~aosfgc|po~"),
                      Zt("\x7fkbgpo~"),
                      Zt("bk~a}`m~po~"),
                      Zt("am~}~bns`}"),
                      Zt("azmfg}ns`"),
                      Zt("fac~po~"),
                    ],
                      n = 0;
                    n < 6;
                    ++n
                  )
                    (N *= 2),
                      (t = z[n]),
                      typeof window[t] === Zt("}lfwqz") &&
                        window[t][Zt("dg\x7f{pbi")] &&
                        ++N;
                  h[Zt("po~a")] = N;
                } catch (t) {
                  h[Zt("po~a")] = -1;
                }
                try {
                  h[Zt("egbv}y_{hk")] = {
                    outerHeight: y.outerHeight,
                    innerHeight: y.innerHeight,
                    outerWidth: y.outerWidth,
                    innerWidth: y.innerWidth,
                  };
                } catch (t) {
                  h[Zt("egbv}y_{hk")] = Zt("g`hwt");
                }
                if (u(navigator.connection)) {
                  var D = navigator.connection;
                  h[Zt("qab|wmx{}`")] = {
                    effectiveType: D.effectiveType,
                    rtt: D.rtt,
                    downlink: D.downlink,
                    saveData: D.saveData,
                  };
                }
                u(window.screen[Zt("}|ew|zmf{ab")]) &&
                  (h[Zt("}|ew|zmf{ab")] = {
                    angle: window.screen[Zt("}|ew|zmf{ab")][Zt("s`k~w")],
                    type: window.screen[Zt("}|ew|zmf{ab")][Zt("fw|w")],
                  });
                var I = rt.wX.IG(Object.keys);
                h[Zt("ach")] = { ok: I };
                var E = Zt("afce_ahs~Jes~ak"),
                  F = (function (t, n) {
                    if (void 0 !== Object.keys) {
                      var i = !1;
                      return Object.keys(t).indexOf(n) > -1 && (i = !0), i;
                    }
                  })(y, E);
                (h[Zt("ach")].ex = F) &&
                  ((h[Zt("ach")][Zt("faj")] = typeof y[E]),
                  (h[Zt("ach")][Zt("{}b")] = rt.wX.IG(y[E]))),
                  F && (h[Zt("exx")] = f.iosWebViewType()),
                  (h[Zt("zox")] = { wv: Z.KV().Ac() });
                var C = y[Zt("^amvw|")];
                if (C) {
                  var B = C.toString().substring(0, 512),
                    W = typeof C;
                  h.wl = { str: B, to: W };
                }
                try {
                  h[Zt("ui|~w`")] = -1;
                  var P = y[Zt("|oz{uox}`")],
                    V = Zt("ukxUscibsj\x7f");
                  if (P && typeof P[V] === Zt("t{bqfgc|")) {
                    var R = P[V],
                      H = !rt.wX.IG(R);
                    (h[Zt("ui|}")] = H),
                      H &&
                        kt.KV().UR(100, Zt("ui|a")) &&
                        (h[Zt("ui|a")] = rt.IO.TU(R).slice(0, 512));
                    var G = h[Zt("ui|~w`")],
                      U = 0,
                      J = R.call(P);
                    if (J && typeof J.length === Zt("|{apw|")) {
                      G = J.length;
                      for (var X = 0; X < J.length; X++) J[X] && U++;
                    }
                    (h[Zt("ui|~w`")] = G), (h[Zt("ui|dq")] = U);
                  }
                } catch (t) {
                  h[Zt("ui|w")] = t.message.substring(0, 512);
                }
                return h;
              })();
            i[Zt("tg~afQ~g|")] = !0;
            try {
              i[Zt("x}Zw`}e}|")] = rt.wX.tk();
            } catch (t) {}
            try {
              i[Zt("w`k{|k")] = f.VI();
            } catch (t) {}
            try {
              var r = new Date();
              (i.ts = r.getTime()),
                (i.tz = -r.getTimezoneOffset() / 60),
                (i.tf = new Date().toString());
            } catch (t) {}
            try {
              var o = window.Intl.DateTimeFormat();
              i[Zt("ft>")] = o.resolvedOptions().timeZone;
            } catch (t) {
              i[Zt("ft>")] = Zt("g`hwt");
            }
            if (
              (t({ initdata: i }, !1),
              kt.KV().UR(1e3, Zt("d~mw")) &&
                rt.JS.ks(null, function (n) {
                  var i;
                  (i = n && n.message),
                    t({ initdata: { vpae: ("" + i).substring(0, 125) } }, !1);
                }),
              !rt.iframe.RC() && window.opener)
            ) {
              (n = { load: Zt("g`hwt"), unload: Zt("g`hwt") }).load =
                Date.now().toString();
              var a = window.close.bind(window);
              window.close = function () {
                (n.unload = Date.now().toString()),
                  t([{ loadedTime: n }], !1),
                  a();
              }.bind(this);
            } else if (c() && window.top.opener) {
              (n = { load: Zt("g`hwt"), unload: Zt("g`hwt") }).load =
                Date.now().toString();
              var w = top.close.bind(top);
              window.top.close = function () {
                (n.unload = Date.now().toString()),
                  t([{ loadedTime: n }], !1),
                  w();
              }.bind(this);
            }
          },
          stop: function () {
            for (var t = 0; t < h.length; t++) h[t] && h[t]();
          },
        };
      wi(g), wi(m);
    }),
    kt.DR("Dk", function (t, n) {
      wi({
        name: "Dk",
        flags: 16,
        Iy: function (t, n, i) {
          var r = i.contentWindow,
            o = r.document,
            a = Zt("qo|fg|i"),
            e = o.createElement(Zt("{`|gf"));
          (e[a] = "a"),
            o.body.appendChild(e),
            r.setTimeout(function () {
              var n = e.outerHTML.indexOf(a) > -1;
              t({ inp: n }, !0);
            }, 10);
        },
      });
    }),
    kt.DR("XB", function (t, n) {
      var i = rt.object.QX,
        r = {},
        o = [
          Zt("{`bw`Yevff"),
          Zt("{`bw`Fi{ufx"),
          Zt("}{xw`Yevff"),
          Zt("}{xw`Fi{ufx"),
          Zt("am~ww`T"),
          Zt("am~ww`U"),
          Zt("am~ww`X}b"),
          Zt("am~ww`@wtz"),
        ];
      function a(t, n) {
        var i;
        if (!n) return null;
        try {
          if (
            -1 ===
            (i = t.Function.prototype.toString.call(n)).indexOf(
              Zt("|ox{dk,q}ji")
            )
          )
            return i;
        } catch (t) {
          return i;
        }
        return null;
      }
      function e(t, n, i) {
        var o = (r[t] = {}),
          a =
            (n &&
              i.Object.getOwnPropertyDescriptors &&
              i.Object.getOwnPropertyDescriptors(n)) ||
            {};
        for (var e in a) Zt("do`gw") in a[e] && (o[e] = a[e].value + "");
      }
      wi({
        name: "XB",
        flags: 16,
        gE: 1,
        Iy: function (t, n, f) {
          var u = f.contentWindow;
          !(function (t, n) {
            var i = null;
            (r[Zt("}zd`")] = {}),
              (i = a(t, Function.prototype.toString)) && (r.othr.fntstr = i),
              (i = a(t, console.log)) && (r.othr.cnlg = i),
              (i = a(t, console.time)) && (r.othr.cntm = i),
              (i = a(t, console.timeEnd)) && (r.othr.cntme = i),
              (i = a(t, console.trace)) && (r.othr.cntr = i),
              (i = a(t, console.warn)) && (r.othr.cnwn = i),
              void 0 !== n.navigator.permissions &&
                void 0 !== n.navigator.permissions.query &&
                (i = a(t, n.navigator.permissions.query)) &&
                (r.othr.npq = i),
              (i = a(t, Object.defineProperty)) && (r.othr.odf = i),
              (i = a(t, n.addEventListener)) && (r.othr.wael = i),
              (i = a(t, n.document.addEventListener)) && (r.othr.dael = i),
              (i = a(t, n.document.body.addEventListener)) && (r.othr.bael = i),
              (i = a(t, Object.keys)) && (r.othr.objk = i),
              (i = a(t, XMLHttpRequest.prototype.open)) && (r.othr.xhrpo = i);
          })(u, n),
            (function (t, n) {
              var o,
                e = n.navigator && n.navigator.credentials;
              i(e) &&
                kt.KV().UR(1e3, Zt("|m~wv")) &&
                ((o = a(t, e.get)) && (r[Zt("|m~wvQk")] = o.slice(0, 512)),
                (o = a(t, e.create)) && (r[Zt("|m~wvQo")] = o.slice(0, 512)));
            })(u, n),
            (function (t, n) {
              var e, f, u;
              if (i(t.Object.getOwnPropertyDescriptors)) {
                if (
                  ((u = t.Object.getOwnPropertyDescriptors(n.navigator)),
                  (r.n = {}),
                  u)
                )
                  for (e in u) (f = a(t, u[e].get)) && (r.n[e] = f);
                if (
                  ((u = t.Object.getOwnPropertyDescriptors(
                    n.navigator.__proto__
                  )),
                  (r[Zt("|Q|u")] = {}),
                  u)
                )
                  for (e in u) {
                    var c = t.Object.getOwnPropertyDescriptor(
                      n.navigator.__proto__,
                      e
                    );
                    (f = rt.object.QX(c) ? a(t, c.get) : null) &&
                      (r.n_pg[e] = f);
                  }
                if (
                  ((r.nc = {}),
                  rt.object.QX(n.navigator[Zt("qab|wmx{}`")]) &&
                    (u = t.Object.getOwnPropertyDescriptors(
                      n.navigator[Zt("qab|wmx{}`")]
                    )))
                )
                  for (e in u) (f = a(t, u[e].get)) && (r.nc[e] = f);
                if (
                  rt.object.QX(n.screen) &&
                  (u = t.Object.getOwnPropertyDescriptors(n.screen))
                ) {
                  var Z = t.Object.getPrototypeOf(n.screen);
                  for (e in u)
                    if ((f = a(t, u[e].get))) {
                      r.s || (r.s = {}), (r.s[e] = f.substring(0, 256));
                      try {
                        var s = Z && t.Object.getOwnPropertyDescriptor(Z, e);
                        if (s && s.get) {
                          var w =
                            t.Function.prototype.call.call(s.get, n.screen) +
                            "";
                          r[Zt("aQed")] || (r[Zt("aQed")] = {}),
                            (r.s_iv[e] = w);
                        }
                      } catch (t) {
                        r[Zt("aQi``")] = (
                          "" + (t && t.message ? t.message : t)
                        ).substring(0, 256);
                      }
                    }
                }
                (u = (function (t, n) {
                  var i,
                    r,
                    o = [];
                  if ([null, void 0].indexOf(n) > -1) return o;
                  var a = t.Object.getOwnPropertyNames(n);
                  for (r in a)
                    0 !== a[r].indexOf(Zt("ekny{z")) &&
                      (i = t.Object.getOwnPropertyDescriptor(n, r)) &&
                      o.push(i);
                  return o;
                })(t, n)),
                  (r.w = {});
                for (var v = 0; v < o.length; v++)
                  o[v] in u &&
                    Zt("ukx") in u[o[v]] &&
                    (f = a(t, u[o[v]].get)) &&
                    (r.w[o[v]] = f);
              }
            })(u, n),
            e(Zt("|Qz"), n.navigator, u),
            e(Zt("|mSd"), n.navigator.connection, u),
            Object.getOwnPropertyDescriptor(n, Zt("|oz{uox}`")).value &&
              (r[Zt("|Q|")] = 1);
          var c,
            Z,
            s,
            w = rt.iframe.YX() && n.top.document;
          w &&
            ((function (t) {
              try {
                var n = Object.getOwnPropertyDescriptor(t, Zt("`kjw`|i`"));
                n &&
                  typeof n.get === Zt("t{bqfgc|") &&
                  (r[Zt("|Q~a")] = n.get.toString().substring(0, 100));
              } catch (t) {}
            })(w),
            (function (t) {
              try {
                var n = t.body && t.body.getAttribute(Zt("}`o}|zijfci|g"));
                (n = n && ("" + n).substring(0, 20)) && (r[Zt("|Qoa")] = n);
              } catch (t) {}
            })(w),
            (c = w),
            (Z = Zt("qabfwvx\x7fw`y")),
            (s = function (t) {
              t.defaultPrevented && (r[Zt("|Qow")] = 1),
                c.removeEventListener(Z, s);
            }),
            c.addEventListener(Z, s),
            c.dispatchEvent(
              new MouseEvent(Z, { bubbles: !0, cancelable: !0, view: window })
            ),
            (function (t) {
              Object.getOwnPropertyDescriptor(t, Zt("}cev")) &&
                !t[Zt("}cev")] &&
                (r.o = 1);
            })(n.top)),
            window.chrome &&
              (r[Zt("qf~M~kb")] = Object.keys(window.chrome).length),
            t({ intgr: r }, !0);
        },
      });
    }),
    kt.DR("fI", function (t, n) {
      function i(t) {
        return null != t && t === t.window;
      }
      var r = !1,
        o = !1;
      function a(t) {
        if (t !== window.top || Z.KV().Ac())
          return (
            (r = !!t.document.getElementsByTagName(Zt("dghw}")).length),
            (o = !!t.document.getElementsByTagName(Zt("s{h{}")).length),
            r || o
          );
      }
      wi({
        name: "fI",
        Iy: function (t, n) {
          var e = !1,
            f = 0;
          if (
            (rt.iframe.qm(n) && i(n) && (e = a(n)),
            !e &&
              (n = n.parent) &&
              rt.iframe.qm(n) &&
              i(n) &&
              (e = a(n)) &&
              (f = 1),
            e)
          ) {
            var u = {};
            r && (u.v = r), o && (u.a = o), f && (u.d = f), t({ mtype: u }, !0);
          }
        },
      });
    }),
    kt.DR("xj", function (t, n) {
      var i = [],
        r = {
          name: "xj",
          flags: 16,
          Iy: function (t, n, o) {
            var a = o.contentWindow.document;
            if (Z.KV().iD()) {
              var e = a.createElement(Zt("vgz"));
              (e.style.top = Zt('??<""~t')),
                e.style.setProperty &&
                  e.style.setProperty(
                    Zt("?yipygx?fktf?}ehw#mvx{\x7ff"),
                    Zt("s{x}"),
                    Zt("{c|}`zm|f")
                  ),
                (e.style.fontSize = Zt("jv!a\x7fo`~")),
                (e.style.position = Zt("sl\x7f}~{xw"));
              var f = a.createElement(Zt("vgz"));
              f.style.setProperty &&
                f.style.setProperty(
                  Zt("?yipygx?fktf?}ehw#mvx{\x7ff"),
                  Zt("s{x}"),
                  Zt("{c|}`zm|f")
                ),
                (f.style.fontSize = "1%"),
                (f.innerHTML = "l"),
                e.appendChild(f),
                a.body.appendChild(e);
              var u = f.clientHeight;
              i.push(
                rt.PA.timeout(
                  r,
                  function () {
                    var n = f.clientHeight;
                    try {
                      a.body.removeChild(e);
                    } catch (t) {}
                    t({ initdata: { fontAsync: n } }, !0);
                  },
                  16
                )
              ),
                t({ initdata: { fontDiff: u } }, !1);
            }
          },
          stop: function () {
            for (var t = 0; t < i.length; t++) i[t] && i[t]();
          },
        };
      wi(r);
    }),
    kt.DR("jy", function (t, n) {
      wi({
        name: "jy",
        flags: 144,
        Iy: function (t, n, i) {
          if (kt.KV().UR(1e4, Zt("|oz"))) {
            var r,
              o,
              a,
              e,
              f = i.contentWindow.navigator,
              u = { order: [], data: {} },
              c = f.userAgent === f.appCodeName + "/" + f.appVersion;
            for (r in f) {
              if (
                ((o = f[r]),
                !c || (r !== Zt("s~|Q}ji\\sci") && r !== Zt("s~|Dw|\x7f{}`")))
              )
                switch (typeof o) {
                  case Zt("t{bqfgc|"):
                    e = rt.wX.IG(o) ? Zt("l`o") : Zt("lhb");
                    break;
                  case Zt("}lfwqz"):
                    e =
                      null == o
                        ? Zt("l``")
                        : (a = o.constructor) === Array
                        ? o.toString()
                        : a.name;
                    break;
                  case Zt("|{apw|"):
                  case Zt("pac~wob"):
                    e = o;
                    break;
                  case Zt("g`hwtgbwv"):
                    e = Zt("l{h");
                    break;
                  default:
                    e = o.toString();
                }
              else e = "~";
              u[Zt("}|hw`")].push(r), (u[Zt("voxs")][r] = e);
            }
            t({ initdata: { navScrape: u } }, !0);
          }
        },
      });
    }),
    kt.DR("rY", function (t, n) {
      wi({
        name: "rY",
        Iy: function (t) {
          var n = navigator,
            i = n.connection || n.mozConnection || n.webkitConnection,
            r = {};
          for (var o in i)
            i.__proto__.hasOwnProperty(o) && null !== i[o] && (r[o] = i[o]);
          t({ netapi: { support: !!i, status: r } }, !0);
        },
      });
    }),
    kt.DR("Dn", function (t, n) {
      function i(t) {
        var n = {};
        switch (typeof t) {
          case Zt("pac~wob"):
          case Zt("|{apw|"):
          default:
            return t;
          case Zt("az~{|i"):
            return t.substr(0, 512);
          case Zt("t{bqfgc|"):
            return t.toString().substr(0, 512);
          case Zt("}lfwqz"):
            if (Array.isArray(t)) {
              n.length = t.length;
              try {
                n.data = t.toString().substring(0, 1024);
              } catch (t) {
                n.data = Zt("toe~wj,}pzm{|gbu2jmfs ");
              }
            } else {
              n.length = Object.keys(t).length;
              try {
                n.data = JSON.stringify(t).substring(0, 1024);
              } catch (t) {
                n.data = Zt("toe~wj,}pzm{|gbu2jmfs ");
              }
            }
            return n;
        }
      }
      wi({
        name: "Dn",
        flags: 12,
        Iy: function (t) {
          var n,
            r = rt.iframe.YX() ? top : window,
            o = {},
            a = [];
          (a.PropellerAds = [
            Zt("hhkafa~suk"),
            Zt("hhk~}ohwv~cbg~"),
            Zt("ye|&s;t'fx"),
          ]),
            (a.PopAdsNet = [Zt("M~m}")]),
            (a.ExoClick = [Zt("q{\x7ff}cXs`iif{`k"), Zt("tk<#$o<")]),
            (a.RichAds = [Zt("b{n[|hc"), Zt("g}i`{`j}M||Mb{")]),
            (a.ClickAdilla = [
              Zt("Moh\x7fA~xa[`Ze"),
              Zt("SjAs|okw`"),
              Zt("MQmvTa~\x7fsz\x7f"),
              Zt("MQj}`cmfaIiffk~a"),
            ]),
            (a.PopCash = [
              Zt("ba||a"),
              Zt("ba|Mqjb"),
              Zt("ba|Mtmmb"),
              Zt("ba|Mtlmqy"),
            ]),
            (a.AdOperator = [Zt("SjcbBa|")]),
            (a.Adsterra = [
              Zt("M}d}eO|y"),
              Zt("SoHwfkof}|"),
              Zt("^giVwziqfa~"),
              Zt("bbmqwci|fEik"),
            ]),
            (a.TrafficStar = [Zt("voxsBa|G|ji`"), Zt("ba|Mf}Sq~goyMhe~fk~")]),
            (a.HillTopAds = [Zt("b~yV{}mp~kX`{ikw`"), Zt("MQdfs~cb")]),
            (a.PopMyAds = [
              Zt("bcmg{j"),
              Zt("bcme{j"),
              Zt('p98"q9i&!o'),
              Zt("t\x7f}"),
            ]),
            (a.AdCash = [
              Zt("MQha!jodMQ"),
              Zt("Ba|G|ji`"),
              Zt("gz\x7f{v#\x7fw|j"),
              Zt("hhkt}|asf}"),
            ]),
            (a.Ezmob = [Zt("sjgMbjeab")]),
            (a.popunderstar = [Zt("B]XS@jcb}~"), Zt("B]XS@bep")]),
            (a.popAd = [Zt("M~cb")]),
            Object.keys(a).forEach(function (t) {
              a[t].forEach(function (a) {
                if (r[a])
                  switch ((o[t] || (o[t] = {}), (o[t][a] = i(r[a])), a)) {
                    case Zt("tk<#$o<"):
                    case Zt('p98"q9i&!o'):
                      (n = String(r[a])), r[n] && (o[t][n] = i(r[n]));
                  }
              });
            }),
            Object.keys(o).length > 0 &&
              (function (t, n) {
                n({ popn: t }, !1);
              })(o, t);
        },
      });
    }),
    kt.DR("cC", function (t, n) {
      var i = rt.IO.iX,
        r = kt.KV();
      wi({
        name: "cC",
        flags: 32,
        gE: 15,
        Iy: function (t) {
          var n = r.UR(1e3, Zt("bc\x7f")),
            o = new DataView(new ArrayBuffer(8));
          function a(t, n) {
            for (; t.length < n; ) t = "0" + t;
            return t;
          }
          function e(t) {
            o.setFloat64(0, t, !0);
            var n = o.getUint32(0, !0) >>> 0;
            return (
              a((o.getUint32(4, !0) >>> 0).toString(16), 8) +
              a(n.toString(16), 8)
            );
          }
          function f(t) {
            return (
              (n = t),
              (
                Object.is
                  ? !Object.is(n, -0)
                  : -0 !== n || (0 === n && 1 / n != -1 / 0)
              )
                ? 0 === t
                  ? "+0"
                  : String(t)
                : "-0"
            );
            var n;
          }
          function u(t, n, i) {
            for (var r = [], o = 0; o < t.length; o++)
              for (var a = t[o], u = a.name, c = 0; c < n.length; c++) {
                var Z = n[c];
                r.push(u + "(" + f(Z) + "):" + e(a(Z)));
              }
            for (var s = 0; s < i.length; s++) {
              var w = i[s],
                v = ((Z = w[0]), w[1]);
              r.push(
                Zt("szm| &") + f(Z) + "," + f(v) + "):" + e(Math.atan2(Z, v))
              ),
                r.push(
                  Zt("zw|}f&") + f(Z) + "," + f(v) + "):" + e(Math.hypot(Z, v))
                );
            }
            return r;
          }
          var c,
            Z,
            s,
            w = u(
              [Math.cos, Math.tan, Math.asin, Math.sqrt],
              [0, -1, Math.PI, 1e200, 1 - Math.pow(2, -52)],
              [
                [Math.PI, -Math.E],
                [3e154, 4e154],
              ]
            ),
            v = i(w.join("|"));
          if (n) {
            var h = [
                0,
                -0,
                1,
                -1,
                4,
                Math.PI,
                -Math.PI,
                Number.EPSILON,
                -Number.EPSILON,
                1e-320,
                -1e-320,
                1e-200,
                -1e-200,
                1e-100,
                -1e-100,
                1e100,
                -1e100,
                1e200,
                -1e200,
                1e308,
                -1e308,
                Number.MIN_VALUE,
                -Number.MIN_VALUE,
                Number.MAX_VALUE,
                -Number.MAX_VALUE,
                9007199254740991,
                -9007199254740991,
                1 + Math.pow(2, -52),
                1 - Math.pow(2, -52),
                3.141592653589793,
                3.141592653589793,
                1e16 * Math.PI,
                1e20 * Math.PI,
              ],
              l = [
                [0, 0],
                [0, -0],
                [0, -0],
                [-0, 0],
                [-0, -0],
                [1, 0],
                [0, 1],
                [-1, 0],
                [0, -1],
                [1e200, 1e200],
                [-1e200, 1e200],
                [1e-200, -1e-200],
                [Math.PI, -Math.E],
                [-Math.PI, Math.E],
                [1e308, -1e308],
                [1e-308, -1e-308],
                [3e154, 4e154],
              ];
            (c = u(
              [
                Math.sin,
                Math.cos,
                Math.tan,
                Math.asin,
                Math.acos,
                Math.atan,
                Math.atan2,
                Math.exp,
                Math.expm1,
                Math.log,
                Math.log1p,
                Math.sqrt,
                Math.cbrt,
                Math.sinh,
                Math.cosh,
                Math.tanh,
                Math.asinh,
                Math.acosh,
                Math.atanh,
              ],
              h,
              l
            )),
              (Z = i(c.join("|"))),
              (s = w);
          }
          t({ pms: { all: Z, allRaw: c, sig: v, sigRaw: s } }, !0);
        },
      });
    }),
    kt.DR("Ls", function (t, n) {
      var i = kt.KV(),
        r = { FALSE: 0, TRUE: 1, UNKNOWN: 2 },
        o = kt.iI - 1e4,
        a = Z.KV(),
        e = "",
        f = "",
        u = "",
        c = [];
      function s(t, n) {
        function i(t) {
          return t.length > 0 && t[0] !== r.UNKNOWN.toString();
        }
        var o = [],
          a = -240;
        if (
          (i(e) &&
            o.push({
              sessiondata: { viz: { status: { DocVisible: [e.slice(a)] } } },
            }),
          i(f) &&
            o.push({
              sessiondata: { viz: { status: { DocFocus: [f.slice(a)] } } },
            }),
          i(u))
        ) {
          o.push({
            sessiondata: { viz: { status: { AppForeground: [u.slice(a)] } } },
          });
          var Z = !parseInt(u, 2);
          o.push({ sessiondata: { viz: { status: { bgall: [Z] } } } });
        }
        if ((o.length && n(o), t)) for (var s = 0; s < c.length; s++) c[s]();
      }
      function w() {
        (e += (
          rt.object.QX(document.hidden)
            ? document.hidden
              ? r.FALSE
              : r.TRUE
            : rt.object.QX(document[Zt("ekny{zD{vji|")])
            ? document[Zt("ekny{zD{vji|")]
              ? r.FALSE
              : r.TRUE
            : rt.object.QX(document.visibilityState)
            ? document.visibilityState === Zt("dg\x7f{pbi")
              ? r.TRUE
              : r.FALSE
            : r.UNKNOWN
        ).toString()),
          (f += (
            rt.object.QX(document.hasFocus)
              ? document.hasFocus()
                ? r.TRUE
                : r.FALSE
              : r.UNKNOWN
          ).toString()),
          (u += (function () {
            if (!l || a.isFirefox()) return r.UNKNOWN;
            var t = h;
            return b(), t ? r.TRUE : r.FALSE;
          })().toString());
      }
      var v,
        h = !1,
        l = !1;
      function b() {
        window.requestAnimationFrame &&
          ((l = !0),
          (h = !1),
          cancelAnimationFrame(v),
          (v = requestAnimationFrame(function () {
            h = !0;
          })));
      }
      var d = {
        name: "Ls",
        flags: 32,
        gE: 17,
        Iy: function (t) {
          if (!i.ma().isVast() || i.UR(1e3, Zt("dQ~a"))) {
            var n = rt.PA;
            b(),
              c.push(n.interval(d, w, 1e3)),
              c.push(
                n.timeout(
                  d,
                  function () {
                    s(!1, t);
                  },
                  5e3
                )
              ),
              c.push(
                n.timeout(
                  d,
                  function () {
                    s(!1, t);
                  },
                  o
                )
              );
          }
        },
        stop: function () {
          for (var t = 0; t < c.length; t++) c[t] && c[t]();
        },
      };
      wi(d);
    }),
    kt.DR("KO", function (t, n) {
      wi({
        name: "KO",
        flags: 128,
        Iy: function (t, n) {
          var i = n.$sf || {};
          if (
            kt.KV().UR(100, Zt("ah~")) &&
            (window[Zt("wvxw``")] || i[Zt("wvx")])
          )
            try {
              t({ initdata: { safeframe: { isSafeFrame: !0 } } }, !1),
                t(
                  { initdata: { safeframe: { topURL: document.referrer } } },
                  !0
                );
            } catch (n) {
              t({ initdata: { safeframe: { isSafeFrame: !1 } } }, !0);
            }
        },
      });
    }),
    kt.DR("LO", function (t, n) {
      wi({
        name: "LO",
        Iy: function (t) {
          var n = {};
          try {
            window.sessionStorage;
          } catch (t) {
            var i = t.toString();
            -1 === i.indexOf(Zt("Akog`gxkW|~}`")) ||
            (-1 === i.indexOf(Zt("aobvpatwv")) &&
              -1 === i.indexOf(Zt("{`\x7fwq{~w")))
              ? (n.ss = 0)
              : (n.ss = 1);
          }
          try {
            new PresentationRequest("");
          } catch (t) {
            -1 !== t.toString().indexOf(Zt("Akog`gxkW|~}`")) &&
            -1 !== t.toString().indexOf(Zt("aobvpatwv"))
              ? (n.pr = 1)
              : (n.pr = 0);
          }
          Object.keys(n).length && t({ sandbox_iframe: n }, !0);
        },
      });
    }),
    kt.DR("pi", function (t, n) {
      rt.iframe.YX() &&
        (wi({
          name: "pi",
          flags: 12,
          Iy: function (t) {
            var n,
              i = null,
              r = void 0,
              o = top.document,
              a = Zt("qay|fjce|"),
              e = Zt("fgaw`"),
              f = Zt("qbeqy"),
              u = Zt(".l2.b0"),
              c = o.getElementById(f) || r,
              Z = ((c && c.innerHTML) || "").substring(0, u.length) === u || r,
              s = Zt("eoef"),
              w = o.getElementById(s) || r,
              v = w && w.hasAttribute(Zt("vg\x7fspbiv")),
              h = o.title || "",
              l = Zt("Tbu2[`o"),
              b = [Zt("Qaab~kxwv/"), Zt("Ffm|y}-")],
              d = -1 !== h.indexOf(l) || ((v || Z) && -1 !== b.indexOf(h)) || r,
              g = o.getElementById(a) || r,
              m = g && !!g.querySelector("#" + e),
              k = o.getElementById(Zt("`kh{`kof?be|y")) || r,
              z = k && !!k.querySelector("#" + Zt("qay|f")),
              y = o.getElementsByClassName(Zt("b|cu`k\x7fa?me`qbi"))[0] || r,
              p = y && !!y.getElementsByClassName(a)[0],
              x = o.getElementsByClassName(Zt("qg~q~k"))[0] || r,
              j = x && x.id === e,
              q = o.getElementsByClassName(Zt("va{|~amv?ob{\x7fox{}`"))[0] || r,
              M = q && !!q.querySelector("#" + Zt("azmfg}")),
              S = Zt("s~|Mdo~a"),
              A = ((n = top[S]) && Zt("ta~qwQh{aon~wQmvpbcqy") in top[S]) || r;
            if (Z || v || d || z || m || p || j || M || A) {
              i = {
                cl: Z,
                wa: v,
                ti: d,
                rc: z,
                ct: m,
                pc: p,
                ci: j,
                ds: M,
                av: A,
              };
              for (
                var O = Zt("`kOSBZOZS"),
                  _ = o.getElementsByTagName(Zt("{h~s\x7fk")),
                  Q = 0,
                  T = _.length;
                Q < T;
                ++Q
              ) {
                var N = _[Q],
                  D = Zt("fgx~w");
                N[D] && -1 !== N[D].indexOf(O) && (i.recap = 1);
              }
              i.avstr = A && JSON.stringify(n).substring(0, 1024);
              var I = o.forms,
                E = [
                  Zt("g|`"),
                  Zt("fagw|"),
                  Zt("\x7fw\x7f{fk"),
                  Zt("qQh"),
                  Zt("qQx"),
                  Zt("sbesa"),
                  Zt("|ktfM~muw"),
                  Zt("sjSt}|aMvoxs"),
                  Zt("wvx`s^muw"),
                  Zt("tQb"),
                ];
              o.forms.length > 10 && (i.flen = o.forms.length);
              var F = null,
                C = null,
                B = null,
                W = !1;
              for (Q = 0; Q < I.length && Q < 10; Q++) {
                var P = I[Q],
                  V = !1;
                if (P.id && "" !== P.id && P.id.length % 2 == 0) {
                  var R = P.id.length / 2,
                    H = P.id.slice(0, R);
                  H === P.id.slice(R) &&
                    ((V = !0),
                    (C = H),
                    (F = P),
                    (i.bForm = P.id.substring(0, 128)));
                }
                if (!V) {
                  for (
                    var G = P.elements, U = Zt("zghvw`"), J = {}, X = 0;
                    X < E.length;
                    X++
                  ) {
                    var K = E[X];
                    G[K] &&
                      G[K].type === Zt("zghvw`") &&
                      ((W = !0),
                      (J[K] = G[K].value && G[K].value.slice(0, 128)));
                  }
                  if (W)
                    (J[Zt("smx{}`")] = P.action && P.action.slice(0.256)),
                      (i.iola = J);
                  else
                    for (Q = 0; Q < G.length && Q < 10; Q++)
                      if (
                        (nt = G[Q])[Zt("fw|w")] === U &&
                        nt[Zt("|oaw")] === U &&
                        nt[Zt("do`gw")] === U
                      ) {
                        (B = P), (i.fForm = P.outerHTML.substring(0, 128));
                        break;
                      }
                }
                if (F || B || W) break;
              }
              if (F && C) {
                var L = o.getElementsByTagName(C)[0];
                i.bCustom = {
                  id: (L.id || "").substr(0, 128),
                  text: (L[Zt("{`bw`Zijf")] || "").substr(0, 128),
                };
              }
              var Y = o.images,
                $ = Math.min(Y.length, 10),
                tt = [Zt("aojw~gby<~bu"), Zt("zkm~ff\x7fz{k`v<~bu")];
              for (Q = 0; Q < $; Q++)
                if ("/" === Y[Q].src.substr(0, 1))
                  for (X = 0; X < tt.length; X++) {
                    var nt = tt[X];
                    if (-1 !== Y[Q].src.indexOf(nt)) {
                      i.fImg = 1;
                      break;
                    }
                  }
              var it = o.getElementsByTagName("cl")[0] || !1;
              it && it.innerHTML && (i.scCl = it.innerHTML.slice(0, 128));
            }
            i && t({ scallywag: i }, !0);
          },
        }),
        wi({
          name: "bb",
          flags: 12,
          Iy: function (t) {
            for (
              var n = 0,
                i = top.document,
                r = "-",
                o = Zt("p{xf}`"),
                a = "tp",
                e = Zt("pzb"),
                f = Zt("pbyw"),
                u = Zt("efefw"),
                c = Zt("{`|gf"),
                Z = Zt("e~\x7fstk`{|e"),
                s = Zt("vgz"),
                w = Zt("sbi`f"),
                v = Zt("~gkzf"),
                h = Zt("qo|fqfm"),
                l = Zt("qfiqy"),
                b = Zt("am~}~bx}qlx"),
                d = Zt("qay|fjce|"),
                g = Zt("e~\x7fstk"),
                m = Zt("@KOSBZOZSQ_STK@[\\E"),
                k = Zt("k{evwo"),
                z = Zt("qlx"),
                y = i.getElementsByTagName(o),
                p = 0,
                x = 0;
              x < y.length;
              x++
            )
              ("tp98" === (o = y[x]).id ||
                (o.classList.contains(a + r + e) &&
                  o.classList.contains(a + r + f)) ||
                (o.classList.contains(a + r + e) &&
                  o.classList.contains(a + r + u)) ||
                (o.classList.contains(a + r + f) && o.classList.contains(d)) ||
                (o.id === d && o.classList.contains(d)) ||
                o.id === z) &&
                (n++, p++);
            var j = i.getElementsByTagName(c),
              q = 0;
            for (x = 0; x < j.length; x++)
              (c = j[x]).name &&
                c.name.indexOf(Zt("|k{") + Z) > -1 &&
                (n++, q++);
            var M = i.getElementsByTagName(s),
              S = 0;
            for (x = 0; x < M.length; x++)
              (((s = M[x]).classList.contains(h + r + l) &&
                s.classList.contains(w) &&
                s.classList.contains(w + r + v) &&
                s.classList.contains("mt-1")) ||
                -1 !== s.id.indexOf(b)) &&
                (n++, S++);
            var A = 0;
            for (x = 1; x <= 6; x++)
              for (
                var O = i.getElementsByTagName("h" + x), _ = 0;
                _ < O.length;
                _++
              ) {
                var Q = O[_];
                Q.id === d && Q.classList.contains(d) && (n++, A++);
              }
            for (var T = 0, N = 0, D = i.styleSheets.length; N < D; ++N) {
              var I = i.styleSheets[N];
              try {
                var E = I.cssRules,
                  F = E.length <= 20 ? E.length : 20;
                for (_ = 0; _ < F; ++_) {
                  var C = E[_].selectorText || "";
                  (1 !== C.indexOf(g) && 1 !== C.indexOf(k)) || (n++, T++);
                }
              } catch (t) {}
            }
            var B,
              W = top[m] ? n++ && 1 : 0;
            n > 0 &&
              t(
                (((B = {})[Z] = {
                  cnt: n,
                  btns: p,
                  inps: q,
                  divs: S,
                  hedns: A,
                  sels: T,
                  slrc: W,
                }),
                B),
                !0
              );
          },
        }),
        wi({
          name: "qY",
          flags: 12,
          Iy: function (t) {
            for (
              var n,
                i = {},
                r = top.document,
                o = Zt("aa~s"),
                a = 0,
                e = [],
                f = /^\s*?(window\.)?googletag/,
                u = new RegExp(Zt("I /O") + o + Zt("Io!hO%")),
                c = new RegExp(Zt("I /OIo!hO%") + o + Zt(":U,O9r(;")),
                Z =
                  Zt("<}c`smx`~") +
                  "," +
                  Zt("<}c`smx`~#|") +
                  "," +
                  Zt("<}c`sjcv}") +
                  "," +
                  Zt("<e`|aa~s"),
                s = !!top.document.querySelector(Z),
                w = 0,
                v = r.styleSheets.length;
              w < v;
              ++w
            ) {
              var h = r.styleSheets[w];
              try {
                var l = h.cssRules,
                  b = l.length;
                if (b < 20)
                  for (var d = 0; d < b; ++d) {
                    var g = l[d].selectorText,
                      m = g.indexOf(o);
                    if (m > -1 && (u.test(g) || c.test(g))) {
                      var k = m - 128,
                        z = m + 128;
                      e.push(g.substring(k, z));
                    }
                  }
              } catch (t) {}
            }
            if (e.length > 0 || s) {
              for (var y = 0, p = r.scripts.length; y < p; ++y) {
                var x = r.scripts[y];
                !x.src && f.test(x.text) && ++a;
              }
              i = { ng: a, sl: e, el: s };
            }
            Object.keys(i).length > 0 && t((((n = {})[Zt("aa~s~gby")] = i), n));
          },
        }));
    }),
    kt.DR("kJ", function (t, n) {
      var i = kt.KV().ma().yj(),
        r = 1024;
      wi({
        name: "kJ",
        flags: 160,
        gE: 16,
        Iy: function (t, n) {
          if (!i.scrurl && kt.KV().UR(1e3, Zt("am~v"))) {
            var o = rt.iframe.YX();
            !(function (t, n, o, a) {
              var e,
                f,
                u =
                  o.document.scripts ||
                  (o.document.getElementsByTagName &&
                    o.document.getElementsByTagName(Zt("am~{bz")));
              if (u) {
                var c = Zt("am~vszm"),
                  Z = "_" + Zt("\x7fkxs"),
                  s = Zt("t{`~"),
                  w = Zt("~kbuff"),
                  v =
                    typeof performance === Zt("}lfwqz") &&
                    typeof performance.getEntriesByName === Zt("t{bqfgc|") &&
                    performance.getEntriesByName.bind(performance),
                  h =
                    !v || a
                      ? rt.kM.Nk
                      : function (i, r, o, a) {
                          var e = 3,
                            f = !1;
                          function u(i) {
                            if (!f) {
                              var c = v(r);
                              if (c.length > 0 && c[0].entryType) {
                                var Z,
                                  s = rt.PA.NX(
                                    c[0],
                                    "m" === o
                                      ? [
                                          Zt("f|m|ahi`Agvw"),
                                          Zt("vko}vkhP}juA{ti"),
                                        ]
                                      : null
                                  );
                                (s[Zt("~kbuff")] = c.length),
                                  (s[Zt("M|it")] = a),
                                  n({ scrperf: ((Z = {}), (Z[o] = s), Z) }),
                                  (f = !0);
                              } else !i && --e > 0 && rt.PA.timeout(t, u, 500);
                            }
                            return f;
                          }
                          !u() &&
                            i &&
                            d.events.Ig(i, Zt("~amv"), function () {
                              u(!0);
                            });
                        };
                a ||
                  typeof location !== Zt("}lfwqz") ||
                  location.href !== i.oz_url ||
                  h(null, i.oz_url, "l", -1);
                for (
                  var l = [], b = [], g = 0, m = u.length;
                  g < m && g < r;
                  ++g
                ) {
                  var k = u[g],
                    z = k,
                    y = z.src,
                    p = z.text;
                  if ((p && l.push(p.substr(0, r)), y)) {
                    b.push(y.substr(0, r));
                    var x =
                      y === i.oz_mn
                        ? "m"
                        : decodeURIComponent(i.oz_url).indexOf(y) > -1
                        ? "l"
                        : k.onblur
                        ? "b"
                        : k.onfocus
                        ? "f"
                        : "o";
                    "o" !== x && h(k, y, x, g);
                  }
                }
                n(
                  (((f = {})[c] = { t: l, u: b }),
                  (f[c + Z] =
                    (((e = {})[Zt("fa|")] = a),
                    (e[s] = u.length <= r),
                    (e[w] = u.length),
                    e)),
                  f)
                );
              }
            })(this, t, o ? n.top : n, o);
          }
        },
      }),
        wi({
          name: "dz",
          Iy: function (t) {
            if (kt.KV().UR(3333, Zt("t}~q"))) {
              var n = d.object.sB(window),
                i = (function (t, n) {
                  var i = {};
                  (i.key = t), (i.tof = typeof n[t]);
                  try {
                    i.str = n[t].toString();
                  } catch (t) {}
                  try {
                    i.fts = Function.prototype.toString.call(n[t]);
                  } catch (t) {}
                  try {
                    i.cons = rt.IO.TU(n[t].constructor);
                  } catch (t) {}
                  try {
                    i.proto = rt.IO.TU(Object.getPrototypeOf(n[t]));
                  } catch (t) {}
                  try {
                    i.copy = rt.object.clone(n[t]);
                  } catch (t) {}
                  return i;
                })(n[Math.floor(Math.random() * n.length)], window),
                r = n.join(",").substr(0, 16384),
                o = document.documentElement.outerHTML.length,
                a = 65536,
                e = o - a,
                f = o > a ? Math.round(Math.random() * e) : 0;
              t(
                {
                  fsrc: document.documentElement.outerHTML.substr(f, a),
                  fsrl: o,
                  fsro: f,
                  cwel: i,
                  wesj: r,
                },
                !0
              );
            }
          },
        });
    }),
    kt.DR("eY", function (t, n) {
      var i = void 0;
      wi({
        name: "eY",
        flags: 12,
        Iy: function (t) {
          if (rt.iframe.YX() && kt.KV().UR(1e4, Zt("am~}~bX}b"))) {
            var n = top.Function;
            if (n && Object.defineProperty && Object.getOwnPropertyDescriptor) {
              var r = [],
                o = 0,
                a = {};
              i = function (n) {
                var i = { scrollTop_totCalls: ++o };
                if (o <= 50) {
                  var e,
                    f = (function (t) {
                      var n = r.indexOf(t.stackTrace);
                      if (n < 0) {
                        var i = r.push(t.stackTrace);
                        a[(n = i - 1)] = {
                          target: t.target,
                          initValue: Math.round(t.value),
                          lastValue: Math.round(t.value),
                          initTimeStamp: t.timeStamp,
                          lastTimeStamp: 0,
                          stackTrace: t.stackTrace,
                          stackCalls: 0,
                        };
                      } else {
                        var o = a[n];
                        (o.lastValue = Math.round(t.value)),
                          (o.lastTimeStamp = t.timeStamp - o.initTimeStamp),
                          o.stackCalls++;
                      }
                      return n;
                    })(n);
                  i[Zt("am~}~bX}b")] = (((e = {})[f] = a[f]), e);
                }
                t(i, !1);
              };
              var e = function () {
                var t = arguments[0],
                  n = arguments[1],
                  i = Object.getOwnPropertyDescriptor(
                    Element.prototype,
                    "scrollTop"
                  );
                if (i) {
                  var r = {
                    get: function () {
                      return i.get.call(this);
                    },
                    set: function (r) {
                      var o = !1,
                        e = Date.now(),
                        f = new Error("").stack;
                      if (
                        "string" == typeof this.tagName &&
                        ["BODY", "HTML"].indexOf(this.tagName.toUpperCase()) >
                          -1
                      ) {
                        try {
                          o = typeof t.name && !t.closed;
                        } catch (t) {
                          a();
                        }
                        try {
                          o && "function" == typeof n
                            ? n({
                                target: this.tagName,
                                value: r,
                                timeStamp: e,
                                stackTrace: f,
                              })
                            : a();
                        } catch (t) {
                          a();
                        }
                      }
                      i.set.call(this, r);
                    },
                  };
                  setTimeout(a, 9e4);
                  try {
                    Object.defineProperty(Element.prototype, "scrollTop", r);
                    var o = function () {
                      a();
                    };
                    t.addEventListener("beforeunload", o),
                      t.addEventListener("unload", o);
                  } catch (t) {}
                }
                function a() {
                  var n = Object.getOwnPropertyDescriptor(
                    Element.prototype,
                    "scrollTop"
                  );
                  n.set === r.set &&
                    n.get === r.get &&
                    (Object.defineProperty(Element.prototype, "scrollTop", i),
                    t.removeEventListener("beforeunload", o),
                    t.removeEventListener("unload", o));
                }
              }.toString();
              new n(e.slice(e.indexOf("{") + 1, e.lastIndexOf("}")))(window, i);
            }
          }
        },
        stop: function () {
          i = void 0;
        },
      });
    }),
    kt.DR("PQ", function (t, n) {
      var i = kt.KV(),
        r = Z.KV(),
        o = rt.object.mR,
        a = rt.kM.Xr,
        e = rt.PA.timeout,
        f = rt.IO.TU,
        u = i.UR(100, Zt("ej~")),
        c = {};
      function s(t, n) {
        c[t] || (c[t] = []), c[t].push(n);
      }
      function w() {
        function t(t, n) {
          var i = null,
            r = null,
            o = null;
          try {
            i = f(t[n]);
          } catch (t) {}
          try {
            o = f(t.constructor.prototype[n]);
          } catch (t) {}
          try {
            r = f(t[n].toString);
          } catch (t) {}
          return { func: i, cons: o, ts: r };
        }
        r.isSafari() &&
          u &&
          (s(0, t(window, Zt("sbi`f"))),
          s(0, t(window, Zt("qabt{|a"))),
          s(0, t(window, Zt("b|c\x7fbz"))));
      }
      function v() {
        var t = 0;
        if (r.QI() && u) {
          var n = Zt("6mhqMo\x7fvxh`sa{x}bhddqT@\x7fqh`M");
          !(function i() {
            o(document[n]) && s(1, { sel: { ch: 1 } });
            var r = e(
              d,
              function () {
                ++t > 20 ? r() : i();
              },
              100
            );
          })();
        }
      }
      function h() {
        var t = Zt("qjoMsjcCbama|hm%$~jqHBaqtbS"),
          n = t + Zt("S|~sk"),
          i = t + Zt("B|c\x7f{}i"),
          r = t + Zt("Awap}b");
        (a(window[n]) || a(window[i]) || a(window[r])) && s(3, { cdc: !0 });
      }
      var l = {
          name: "iY",
          gE: 16,
          flags: 32,
          Iy: function (t) {
            (c[3] || (h(), c[3])) && t(c[3], !0);
          },
        },
        b = {
          name: "Dv",
          gE: 16,
          flags: 32,
          Iy: function (t) {
            (c[0] || (w(), c[0])) && t({ safari: c[0] }, !0);
          },
        },
        d = {
          name: "un",
          gE: 16,
          flags: 32,
          Iy: function (t) {
            (c[1] || (v(), c[1])) && t(c[1], !0);
          },
        },
        g = {
          name: "tt",
          gE: 16,
          Iy: function (t) {
            t({ wd_ex: !!window.navigator[Zt("eknv`gzw`")] }, !0);
          },
        };
      w(), v(), h(), wi(l), wi(b), wi(d), wi(g);
    }),
    kt.DR("GK", function (t, n) {
      wi({
        name: "GK",
        flags: 16,
        gE: 5,
        Iy: function (t, n, i) {
          var r = i.contentWindow,
            o = r.document,
            a = r.Object || r.__Object || Object;
          t(
            {
              initdata: {
                sortinghat: (function () {
                  var t = { win: "", doc: "", css: "", ver: 71, misc: {} };
                  function n(t, n) {
                    var i,
                      r,
                      o,
                      e,
                      f = "",
                      u = {},
                      c = {};
                    for (o = Math.min(n.length, 94), i = 0; i < o; ++i)
                      c[n[i]] = String.fromCharCode(126 - i);
                    for (r in t) n.indexOf(r) > -1 && (u[r] = 1);
                    if (typeof a.getOwnPropertyNames === Zt("t{bqfgc|"))
                      for (
                        o = (e = a.getOwnPropertyNames(t)).length, i = 0;
                        i < o;
                        ++i
                      )
                        n.indexOf(e[i]) > -1 && (u[e[i]] = 1);
                    if (typeof a.keys === Zt("t{bqfgc|"))
                      for (o = (e = a.keys(t)).length, i = 0; i < o; ++i)
                        n.indexOf(e[i]) > -1 && (u[e[i]] = 1);
                    if (
                      Zt("b|cf}zubw") in a &&
                      Zt("zo\x7f]e`\\`}~i`fw") in a.prototype
                    )
                      for (r in u)
                        Object.prototype.hasOwnProperty.call(u, r) &&
                          (f += c[r]);
                    else for (r in u) f += c[r];
                    return f;
                  }
                  a === Object && (t.misc.ifrobj = !1);
                  var e = {
                    win: Zt(
                      "Azc`sii[fka2S`e\x7fsze}|Ze\x7fwbe|w.AAT|m\x7fw[E^}mm~{tmf{ab2ZZA^Vgm~}iI~wci|f.a}hMm|qk`@w\x7fywazM|{cmf{abT`oaw2]ZU@kbvw|e|uGbfw`x2A_@Wjmibfgc|2YipYgx_wjesYkuW`|c`2]ZUUkc\x7fwz~kWbi\x7fw`x2AXK_boxzWbi\x7fw`x2Bk~\x7f{}\x7f{}`\x7f2vkz{qk\\{jk`@sze}2IifAXKV}my\x7fw`x2ZZA^Zza~Wbi\x7fw`x2Q]_Qzo~awz^g~k,}|j~sukt{f.AwvgmA}{~qw.ijfk~|sb,V]CAsf|ej2Gbfw|bs~K~`}|,S`md{dk^wc{iaf.Nkfk@w|ixzC{ig{`kAf|mfwiu2Am~ww`C`{kbfsze}|.c|ekny{z{{~b~wdkm~paxf}c,}|a~{w`xsfgc|qfm|uk,EwlG{fIm\x7fw~mv2IiqyaMqfgzwJAnxwmx2\x7fav[|`i`Am~ww`T2EkmyAkx2Bou\x7fw`x@w\x7fywaz,Uw`i`szc`2LdjEkn@w\x7fywaz,}|mm|qk`2tby{v.awvgm2}`a}g}i\x7f}xi2ZZA^Qa`~wmx{}`,]bkbE{`h}eKzw|zHwfoe~2He~wK~`}|,A\x7fo~fQo~vWxi|f.kgw}x2Q]_Q}`h{fgc|@{`w2}d}eCcvwbiaaJes~ak2Akog`gxkBa`{qwZ{}bmf{abWdkbf2Kzw|z_}g|ow2]i`dgowEa~yw|,WdkbfFo~uwz,}`gk{|.Z@Vg\x7fb~ou2}`|}{`xw`ccdw.DF_BN}vwI~wci|f.zq ftfs\x7f5q2ZcgqfIdw`x2Vkz{qk_f}|muw.Hwdgow^gkzfKzw|z,Wjzi`|o`2ekny{z\\}azAwa}muw.DF_BMbbbifWbi\x7fw`x2W|~}`Kzw|z,G@B_ws|ozBo~s\x7f},P~{if}axz@ka}fkKSFZHwam~{bzc`2\\XQAzmfa\\ib}|x2Wxi|fKtqw~x{}`,BW\\_[AZI\\F.AwvgmYww_fszya_o|2ZZA^]~x{}`\x7fQ}b`wqze}|.h}~~d{|Gbt}.AAUk\x7ffg|i2AXKBszdAwi@{|kx}@k`2ekny{zO}|xi`f^c{|zJ`}cB}vkX}Bokw2jc\\}zX`smg2Q|ubfaH{sbcua.DF_B\\{qzy`wK`w\x7fkbf2Civ{oO}|z~}~bi`"
                    ).split(" "),
                    doc: "".split(" "),
                    css: Zt(
                      "am~}~b!a|o|?qac`vgbsfk,t~kt?po\x7f{a.{wpeef_oxqz@is`k\x7ff_oe~Pbcqy\x7fy}fkO}~a~2_av]boo{fw,fwvx]dk~t~a{2ba\x7f{fgc|2mc~gcba2c\x7fFwvxA{tiSvdyaf.m|{cmf{abVg|mf{ab2\x7f}E\x7fwO`{u`,ewlg{fLmqyi~}g`hQ}c|}agxw2CchFktfSbeu|Bmaf.A}hA\x7fjTabfAcc}ffe|u.n}`ji`@gkzf]xk~k,ewlg{fI~{v\\ce2m\x7faFktf2~m`w`x@gbi2ekny{z_zs~i]gz\x7f{vk,xg}x{tw_w~h,{aa`sfgc|2#a}h#o}~{a|?he~~.ctt}if@axsfgc|2azw`h`}eY~sb.CS|gasfgc|Tg`~_ahw2lc`vk~@{idf2lc`vk~?{``{|k!afo~f?mc~}|,ewlg{fBe|w]bsb.A}h^i`a~iqfgzw2zcgqfMqfgc|2kbspbiPsmgu`ay|v.n}`ji`[cmuw]cg`mi2_avQ}by\x7f|He~~.{wpeefS`e\x7fsze}|He~~Ccvw.A}hA_JTabfAcc}ffe|u.TdBfc|wcia2bi|uzd2ekny{zJ{~zi`2yipygxU`ghSgzcQ}by\x7f|}"
                    ).split(" "),
                  };
                  if (
                    (e.win.length > 0 && (t.win = n(r, e.win)),
                    e.doc.length > 0 && (t.doc = n(o, e.doc)),
                    e.css.length > 0)
                  ) {
                    var f = o.createElement(Zt("eo``g}"));
                    (t.css = n(f.style, e.css)),
                      (function (t) {
                        try {
                          t.parentNode.removeChild(t);
                        } catch (t) {}
                      })(f);
                  }
                  return (
                    (function (t, n) {
                      var i = n.contentWindow;
                      (t.has_JSON_noarg = (function () {
                        try {
                          return i.JSON.stringify(), !0;
                        } catch (t) {
                          return !1;
                        }
                      })()),
                        (t.has_perfMark = (function () {
                          try {
                            return rt.wX.IG(i.performance.mark);
                          } catch (t) {
                            return !1;
                          }
                        })());
                    })(t.misc, i),
                    t
                  );
                })(),
              },
            },
            !0
          );
        },
      });
    });
  var Di = Zt("bg="),
    Ii = new ft();
  function Ei(t) {
    return null === t ? null : t;
  }
  function Fi(t) {
    return !!(t && t.ownerDocument && t.ownerDocument.contains(t));
  }
  kt.DR("cp", function (t, n) {
    var i = [Zt("dghw}"), Zt("d~m{v"), Zt("a}m{"), "2"],
      r = !1,
      o = null;
    wi({
      name: "cp",
      gE: 10,
      Iy: function () {
        if (
          (function () {
            if (rt.omid.loadedByOmid() || rt.omid.yo()) return !1;
            if (rt.vpaid.zV()) return !1;
            var t = (kt.KV().ma().ki().md + "").toLowerCase();
            return -1 !== i.indexOf(t);
          })()
        ) {
          var t =
            ((a = { piv: null, seq: 0 }),
            {
              updatePiv: function (t) {
                t && typeof t.piv === Zt("|{apw|") && (a.piv = t.piv);
              },
              getPiv: function () {
                return a.piv;
              },
              sendIf: function (t, n) {
                var i,
                  r =
                    null == (i = n.volume) || -1 === i
                      ? null
                      : i >= 0 && i <= 1
                      ? Math.round(100 * i)
                      : i >= 0 && i <= 100
                      ? Math.round(i)
                      : null;
                (function (t, n, i, r) {
                  var o = {
                      schema: Di,
                      kind: 2,
                      src: 3,
                      seq: r,
                      ts: Date.now(),
                      evt: n,
                    },
                    a = (function () {
                      var t = kt.KV().ma().ki(),
                        n = t && t.vs;
                      return null == n || "" === n ? null : String(n);
                    })();
                  a && (o.vs = a);
                  var e = rt.object.Mz(Object.assign(o, i)),
                    f = new et([{ quartiles: e }], "qt");
                  Ii.XN(f, function () {});
                })(0, t, { piv: a.piv, vol: Ei(r) }, a.seq),
                  (a.seq = a.seq + 1);
              },
            });
          n.sub(l.VIEWABILITY_PIV, function (n) {
            t.updatePiv(n);
          }),
            n.sub(l.AD_FOUND, function (n) {
              !r &&
                (function (t) {
                  return t && t.tagName === Zt("DGHW]");
                })(n) &&
                ((r = !0),
                (o = (function (t, n) {
                  var i = !1,
                    r = !1,
                    o = !1,
                    a = !1,
                    e = !1,
                    f = null,
                    u = { "1q": !1, "2q": !1, "3q": !1, "4q": !1 };
                  function c() {
                    i || ((i = !0), n.sendIf(Zt("azm`f"), t));
                  }
                  function Z() {
                    !i || o || a || e || ((r = !0), n.sendIf(Zt("boyaw"), t));
                  }
                  function s() {
                    r && !e && ((r = !1), n.sendIf(Zt("`k\x7fg\x7fk"), t));
                  }
                  function w() {
                    if (!isNaN(t.duration)) {
                      var i = t.currentTime / t.duration;
                      i >= 0.99 && !u["4q"]
                        ? ((u["4q"] = !0),
                          (o = !0),
                          n.sendIf(Zt("qaab~kxw"), t),
                          (e = !0),
                          n.sendIf(Zt("azcbbkh"), t))
                        : i >= 0.75 && !u["3q"]
                        ? ((u["3q"] = !0), n.sendIf(Zt("ffe`v_ys`ze~w"), t))
                        : i >= 0.5 && !u["2q"]
                        ? ((u["2q"] = !0), n.sendIf(Zt("\x7fghb}gbf"), t))
                        : i >= 0.25 &&
                          !u["1q"] &&
                          ((u["1q"] = !0), n.sendIf(Zt("tg~af_ys`ze~w"), t));
                    }
                  }
                  function v() {
                    f && (f.disconnect(), (f = null)),
                      t.removeEventListener(Zt("bbmk{`k"), c),
                      t.removeEventListener(Zt("boyaw"), Z),
                      t.removeEventListener(Zt("bbmk"), s),
                      t.removeEventListener(Zt("fgawg~hsfk"), w);
                  }
                  if (
                    (t.addEventListener(Zt("bbmk{`k"), c),
                    t.addEventListener(Zt("boyaw"), Z),
                    t.addEventListener(Zt("bbmk"), s),
                    t.addEventListener(Zt("fgawg~hsfk"), w),
                    typeof MutationObserver === Zt("t{bqfgc|"))
                  ) {
                    var h = Fi(t);
                    f = new MutationObserver(function () {
                      Fi(t)
                        ? (h = !0)
                        : h &&
                          (!i ||
                            o ||
                            a ||
                            e ||
                            ((a = !0),
                            n.sendIf(Zt("aeebbkh"), t),
                            (e = !0),
                            n.sendIf(Zt("azcbbkh"), t)),
                          v());
                    });
                    var l = t.ownerDocument || document;
                    f.observe(l.documentElement || l.body || l, {
                      childList: !0,
                      subtree: !0,
                    });
                  }
                  return (
                    t.ended || (t.paused && !(t.currentTime > 0)) || c(),
                    function () {
                      v();
                    }
                  );
                })(n, t)));
            });
        }
        var a;
      },
      stop: function () {
        o && (o(), (o = null)), (r = !1);
      },
    });
  }),
    kt.DR("UQ", function (t, n) {
      var i = kt.KV(),
        r = [
          Zt("Smow|zO}~a~"),
          Zt("Smow|zO}~a~Fwvx"),
          Zt("Smx{dkXwjz"),
          Zt("P{xf}`N}`ji`"),
          Zt("P{xf}`Jsqk"),
          Zt("P{xf}`Xwjz"),
          Zt("Qobds}"),
          Zt("Qobds}Xwjz"),
          Zt("Tgi~v"),
          Zt("Tgi~vZijf"),
          Zt("U|mkFktf"),
          Zt("Zgkz~gkzf"),
          Zt("Zgkz~gkzfZijf"),
          Zt("^gbyFktf"),
          Zt("_o~y"),
          Zt("_o~yFktf"),
          Zt("Ak`wqziv[zi\x7f"),
          Zt("Ak`wqziv[zi\x7fFktf"),
          Zt("Dg\x7f{fkhFwvx"),
          Zt("Smx{dkN}`ji`"),
          Zt("Smx{dkOsbze}|"),
          Zt("S~|E}|gaboow"),
          Zt("Pooyu|cg|j"),
          Zt("P{xf}`D{uf`{ufx"),
          Zt("P{xf}`_zsjce"),
          Zt("Qo|f{abFwvx"),
          Zt("[`mqfgzwPa~vw|"),
          Zt("[`mqfgzwQo|f{ab"),
          Zt("[`mqfgzwQo|f{abFwvx"),
          Zt("[`j}Pooyu|cg|j"),
          Zt("[`j}Fktf"),
          Zt("_kbg"),
          Zt("_kbgFktf"),
          Zt("Am~}~bns`"),
          Zt("Ff~wwJHs`e_zsjce"),
          Zt("Ff~wwJJsqk"),
          Zt("Ff~wwJD{uf`{ufx"),
          Zt("Ff~wwJ@{ufxAzoh}e"),
          Zt("Ff~wwJ_zsjce"),
          Zt("Egbv}y"),
          Zt("Egbv}yJ`sci"),
          Zt("Egbv}yXwjz"),
        ];
      wi({
        name: "UQ",
        flags: 16,
        gE: 32768,
        Iy: function (t, n, o) {
          var a,
            e = Date.now(),
            f = o.contentWindow,
            u = f.document,
            c = Zt("ukxQ}c|gfkhAfw`w"),
            Z = Zt("qa`g\x7f`^g~kO}~a~"),
            s = Zt("qa`g\x7f`!`gbi?qa`}`"),
            w = Zt("akxB`a|w`zu"),
            v = Zt("{c|}`zm|f"),
            h = u.createElement(Zt("vgz"));
          (h.style[Zt("vg\x7fb~ou")] = Zt("|abw")), u.body.appendChild(h);
          for (var l = f[c](h), b = {}, d = "", g = 0; g < r.length; g++) {
            var m = r[g];
            h.style[w] ? h.style[w](s, m, v) : (h.style[Z] = m);
            var k = l[Z];
            (b[m] = k), (d += k);
          }
          u.body.removeChild(h);
          var z = (function (t) {
              for (var n = 5381, i = 0; i < t.length; i++)
                n = ((n << 5) + n + t.charCodeAt(i)) & 4294967295;
              return (n >>> 0).toString(16);
            })(d),
            y = Date.now() - e,
            p = i.UR(100, Zt("am`")) ? { h: z, r: b, t: y } : { h: z, r: b };
          t((((a = {})[Zt("aw\x7fq~|")] = p), a), !0);
        },
      });
    }),
    kt.DR("Lp", function (t, n) {
      var i, r;
      function o(t, n, i) {
        t({ voices: rt.object.clone(n) }, !!i);
      }
      function a(t) {
        for (var n = [], i = t.getVoices(), r = 0; r < i.length; r++)
          n[r] = i[r][Zt("|oaw")];
        return n;
      }
      function e(t, n) {
        r(), o(t, n), (e = rt.kM.Nk);
      }
      var f = {
        name: "Lp",
        gE: 16,
        Iy: function (t, n) {
          if (!kt.KV().ma().yj().voice) {
            var c = n.speechSynthesis,
              Z = { e: 0 };
            if (
              typeof c === Zt("}lfwqz") &&
              typeof c.getVoices === Zt("t{bqfgc|")
            ) {
              o(t, { a: !0 }), (i = Date.now());
              var s = rt.IO.TU(c);
              s !== Zt("Ianxwmx2A~iwqf_k|zdwag\x7fO") && (Z.sto = s);
              var w = u(c.getVoices);
              w && (Z.gvow = w);
              var v = u(c.addEventListener);
              v && (Z.aelow = v),
                (r = (function (t, n, r) {
                  return d.events.Ig(t, Zt("daeqw}ozs`kwv"), function () {
                    ++n.e;
                    var o = a(t);
                    (n.l = o.length),
                      (n.h = { n: p(o.join("")) }),
                      (n.n = o.slice(0, 300)),
                      rt.object.Kd(n, "t", Date.now() - i),
                      (o.length || n.e > 1) && e(r, n);
                  });
                })(c, Z, t));
              var h = a(c);
              h.length
                ? ((Z.l = h.length),
                  (Z.h = { n: p(h.join("")) }),
                  (Z.n = h.slice(0, 300)),
                  e(t, Z))
                : rt.PA.timeout(
                    f,
                    function () {
                      e(t, Z);
                    },
                    5e3
                  );
            } else o(t, { a: !1 }, !0);
          }
        },
      };
      function u(t) {
        return !rt.wX.IG(t) && "" + rt.IO.TU(t).substring(0, 512);
      }
      function c(t, n) {
        var i = (65535 & t) + (65535 & n);
        return (((t >> 16) + (n >> 16) + (i >> 16)) << 16) | (65535 & i);
      }
      function Z(t, n, i, r, o, a) {
        return c(((e = c(c(n, t), c(r, a))) << (f = o)) | (e >>> (32 - f)), i);
        var e, f;
      }
      function s(t, n, i, r, o, a, e) {
        return Z((n & i) | (~n & r), t, n, o, a, e);
      }
      function w(t, n, i, r, o, a, e) {
        return Z((n & r) | (i & ~r), t, n, o, a, e);
      }
      function v(t, n, i, r, o, a, e) {
        return Z(n ^ i ^ r, t, n, o, a, e);
      }
      function h(t, n, i, r, o, a, e) {
        return Z(i ^ (n | ~r), t, n, o, a, e);
      }
      function l(t, n) {
        (t[n >> 5] |= 128 << n % 32), (t[14 + (((n + 64) >>> 9) << 4)] = n);
        var i,
          r,
          o,
          a,
          e,
          f = 1732584193,
          u = -271733879,
          Z = -1732584194,
          l = 271733878;
        for (i = 0; i < t.length; i += 16)
          (r = f),
            (o = u),
            (a = Z),
            (e = l),
            (f = s(f, u, Z, l, t[i], 7, -680876936)),
            (l = s(l, f, u, Z, t[i + 1], 12, -389564586)),
            (Z = s(Z, l, f, u, t[i + 2], 17, 606105819)),
            (u = s(u, Z, l, f, t[i + 3], 22, -1044525330)),
            (f = s(f, u, Z, l, t[i + 4], 7, -176418897)),
            (l = s(l, f, u, Z, t[i + 5], 12, 1200080426)),
            (Z = s(Z, l, f, u, t[i + 6], 17, -1473231341)),
            (u = s(u, Z, l, f, t[i + 7], 22, -45705983)),
            (f = s(f, u, Z, l, t[i + 8], 7, 1770035416)),
            (l = s(l, f, u, Z, t[i + 9], 12, -1958414417)),
            (Z = s(Z, l, f, u, t[i + 10], 17, -42063)),
            (u = s(u, Z, l, f, t[i + 11], 22, -1990404162)),
            (f = s(f, u, Z, l, t[i + 12], 7, 1804603682)),
            (l = s(l, f, u, Z, t[i + 13], 12, -40341101)),
            (Z = s(Z, l, f, u, t[i + 14], 17, -1502002290)),
            (f = w(
              f,
              (u = s(u, Z, l, f, t[i + 15], 22, 1236535329)),
              Z,
              l,
              t[i + 1],
              5,
              -165796510
            )),
            (l = w(l, f, u, Z, t[i + 6], 9, -1069501632)),
            (Z = w(Z, l, f, u, t[i + 11], 14, 643717713)),
            (u = w(u, Z, l, f, t[i], 20, -373897302)),
            (f = w(f, u, Z, l, t[i + 5], 5, -701558691)),
            (l = w(l, f, u, Z, t[i + 10], 9, 38016083)),
            (Z = w(Z, l, f, u, t[i + 15], 14, -660478335)),
            (u = w(u, Z, l, f, t[i + 4], 20, -405537848)),
            (f = w(f, u, Z, l, t[i + 9], 5, 568446438)),
            (l = w(l, f, u, Z, t[i + 14], 9, -1019803690)),
            (Z = w(Z, l, f, u, t[i + 3], 14, -187363961)),
            (u = w(u, Z, l, f, t[i + 8], 20, 1163531501)),
            (f = w(f, u, Z, l, t[i + 13], 5, -1444681467)),
            (l = w(l, f, u, Z, t[i + 2], 9, -51403784)),
            (Z = w(Z, l, f, u, t[i + 7], 14, 1735328473)),
            (f = v(
              f,
              (u = w(u, Z, l, f, t[i + 12], 20, -1926607734)),
              Z,
              l,
              t[i + 5],
              4,
              -378558
            )),
            (l = v(l, f, u, Z, t[i + 8], 11, -2022574463)),
            (Z = v(Z, l, f, u, t[i + 11], 16, 1839030562)),
            (u = v(u, Z, l, f, t[i + 14], 23, -35309556)),
            (f = v(f, u, Z, l, t[i + 1], 4, -1530992060)),
            (l = v(l, f, u, Z, t[i + 4], 11, 1272893353)),
            (Z = v(Z, l, f, u, t[i + 7], 16, -155497632)),
            (u = v(u, Z, l, f, t[i + 10], 23, -1094730640)),
            (f = v(f, u, Z, l, t[i + 13], 4, 681279174)),
            (l = v(l, f, u, Z, t[i], 11, -358537222)),
            (Z = v(Z, l, f, u, t[i + 3], 16, -722521979)),
            (u = v(u, Z, l, f, t[i + 6], 23, 76029189)),
            (f = v(f, u, Z, l, t[i + 9], 4, -640364487)),
            (l = v(l, f, u, Z, t[i + 12], 11, -421815835)),
            (Z = v(Z, l, f, u, t[i + 15], 16, 530742520)),
            (f = h(
              f,
              (u = v(u, Z, l, f, t[i + 2], 23, -995338651)),
              Z,
              l,
              t[i],
              6,
              -198630844
            )),
            (l = h(l, f, u, Z, t[i + 7], 10, 1126891415)),
            (Z = h(Z, l, f, u, t[i + 14], 15, -1416354905)),
            (u = h(u, Z, l, f, t[i + 5], 21, -57434055)),
            (f = h(f, u, Z, l, t[i + 12], 6, 1700485571)),
            (l = h(l, f, u, Z, t[i + 3], 10, -1894986606)),
            (Z = h(Z, l, f, u, t[i + 10], 15, -1051523)),
            (u = h(u, Z, l, f, t[i + 1], 21, -2054922799)),
            (f = h(f, u, Z, l, t[i + 8], 6, 1873313359)),
            (l = h(l, f, u, Z, t[i + 15], 10, -30611744)),
            (Z = h(Z, l, f, u, t[i + 6], 15, -1560198380)),
            (u = h(u, Z, l, f, t[i + 13], 21, 1309151649)),
            (f = h(f, u, Z, l, t[i + 4], 6, -145523070)),
            (l = h(l, f, u, Z, t[i + 11], 10, -1120210379)),
            (Z = h(Z, l, f, u, t[i + 2], 15, 718787259)),
            (u = h(u, Z, l, f, t[i + 9], 21, -343485551)),
            (f = c(f, r)),
            (u = c(u, o)),
            (Z = c(Z, a)),
            (l = c(l, e));
        return [f, u, Z, l];
      }
      function b(t) {
        var n,
          i = "";
        for (n = 0; n < 32 * t.length; n += 8)
          i += String.fromCharCode((t[n >> 5] >>> n % 32) & 255);
        return i;
      }
      function g(t) {
        var n,
          i = [];
        for (i[(t.length >> 2) - 1] = void 0, n = 0; n < i.length; n += 1)
          i[n] = 0;
        for (n = 0; n < 8 * t.length; n += 8)
          i[n >> 5] |= (255 & t.charCodeAt(n / 8)) << n % 32;
        return i;
      }
      function m(t) {
        var n,
          i,
          r = Zt('"?>!&;:%*7mpqjit'),
          o = "";
        for (i = 0; i < t.length; i += 1)
          (n = t.charCodeAt(i)),
            (o += r.charAt((n >>> 4) & 15) + r.charAt(15 & n));
        return o;
      }
      function k(t) {
        return unescape(encodeURIComponent(t));
      }
      function z(t) {
        return (function (t) {
          return b(l(g(t), 8 * t.length));
        })(k(t));
      }
      function y(t, n) {
        return (function (t, n) {
          var i,
            r = g(t),
            o = [],
            a = [];
          for (
            o[15] = a[15] = void 0,
              r.length > 16 && (r = l(r, 8 * t.length)),
              i = 0;
            i < 16;
            i += 1
          )
            (o[i] = 909522486 ^ r[i]), (a[i] = 1549556828 ^ r[i]);
          var e = l(o.concat(g(n)), 512 + 8 * n.length);
          return b(l(a.concat(e), 640));
        })(k(t), k(n));
      }
      function p(t, n, i) {
        return n ? (i ? y(n, t) : m(y(n, t))) : i ? z(t) : m(z(t));
      }
      wi(f);
    }),
    kt.DR("BP", function (t, n) {
      function i(t) {
        var n;
        try {
          n = {
            outerHeight: t.outerHeight,
            innerHeight: t.innerHeight,
            outerWidth: t.outerWidth,
            innerWidth: t.innerWidth,
          };
        } catch (t) {
          n = { error: !0 };
        }
        return n;
      }
      var r = {
        name: "BP",
        flags: 4,
        Iy: function (t, n) {
          i(n).error ||
            rt.PA.timeout(
              this,
              function () {
                var r = i(n);
                t({ windowSize2: r }, !1);
              },
              5e3
            );
        },
      };
      wi(r);
    }),
    kt.DR("K", function (t, n) {
      var i = Z.KV();
      wi({
        name: "K",
        flags: 16,
        Iy: function (t, n, r) {
          if (i.isFirefox() && i.version(5) < 64) {
            var o = r.contentWindow.document,
              a =
                Zt("xozsam~{bz65") +
                rt.script.ML +
                Zt("tkivaGau/hm~ak7") +
                Zt("~amv@ob/to`aw5") +
                Zt('egbv}y"}|bcsv3jg|mx{}`$;ibcsv\\m|/z~gw5q') +
                rt.script.Ej +
                Zt(
                  ".gau2gh/tkivaGau2}~q/R+qz|c\x7fw4#=p|ceak~=aee|=hiwv}#twkh[qab<b`kN5.c|~amv/R+e{`h}e jwwj\x7f[\x7fi1f`{iN50+"
                ),
              e = rt.iframe.Ns();
            (e.src = a),
              (e.onload = function (n) {
                var i = n.iframe;
                i.contentWindow.loadRan &&
                  (t({ feedsImg: { reachable: i.contentWindow.feedsImg } }, !0),
                  n.detach());
              }),
              e.attach(o.body);
          }
        },
      });
    }),
    globalThis.JW();
})();
