(() => {
  "use strict";
  var e = {
      490: (e, t) => {
        Object.defineProperty(t, "__esModule", { value: !0 });
        t.default = class {
          constructor(e) {
            (this.handlers = []), (this.byId = new Map()), (this.name = e);
          }
          executeHandlers(e, t) {
            var a;
            t &&
              (null === (a = this.byId.get(t)) ||
                void 0 === a ||
                a.handlers.forEach((a) => a(Object.assign({}, e), t))),
              this.handlers.forEach((a) => a(Object.assign({}, e), t));
          }
          removeHandler(e, t) {
            var a;
            const s =
                (null === (a = this.byId.get("" + t)) || void 0 === a
                  ? void 0
                  : a.handlers) || this.handlers,
              n = s.indexOf(e);
            n >= 0 && s.splice(n, 1);
          }
        };
      },
      833: function (e, t, a) {
        var s =
          (this && this.__importDefault) ||
          function (e) {
            return e && e.__esModule ? e : { default: e };
          };
        Object.defineProperty(t, "__esModule", { value: !0 });
        const n = s(a(490));
        t.default = class {
          constructor() {
            (this.isReady = !0),
              (this.events = new Map()),
              (this.eventHistory = []);
          }
          on(e, t, a) {
            let s = this.events.get(e);
            s || ((s = new n.default(e)), this.events.set(e, s));
            let i = s.handlers;
            if (a) {
              let e = s.byId.get(a);
              e || ((e = { handlers: [] }), s.byId.set(a, e)), (i = e.handlers);
            }
            i.push(t);
          }
          off(e, t, a) {
            var s;
            null === (s = this.events.get(e)) ||
              void 0 === s ||
              s.removeHandler(t, a);
          }
          fire(e, t, a) {
            var s;
            t &&
              Object.entries(t).forEach(([e, a]) => {
                void 0 === a && delete t[e];
              }),
              this.eventHistory.push({
                eventName: e,
                data: Object.assign({ timestamp: Date.now() }, t),
                id: a,
              }),
              null === (s = this.events.get(e)) ||
                void 0 === s ||
                s.executeHandlers(t, a);
          }
          history(e) {
            return e
              ? this.eventHistory.filter((t) => t.eventName === e)
              : this.eventHistory;
          }
        };
      },
      343: (e, t) => {
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.Global = void 0);
        t.Global = class {
          constructor() {
            (this.sas = window.sas = window.sas || {}),
              (this.isDebug = this._isDebug());
          }
          setEids(e) {
            "function" == typeof this.sas.setEids
              ? this.sas.setEids([e])
              : this.sas.cmd.unshift(() => this.sas.setEids([e]));
          }
          removeEids(e) {
            "function" == typeof this.sas.removeEids
              ? this.sas.removeEids(e)
              : this.sas.cmd.push(() => this.sas.removeEids(e));
          }
          _log(e, t, a = "") {
            (t || this.isDebug) &&
              console[null != t ? t : "log"](
                "%cequativ",
                "background:#fe5000; border-radius:2px; color:#feffff; font-family:lato,sans-serif; padding:1px 3px;",
                e,
                a
              );
          }
          isString(e) {
            return "string" == typeof e || e instanceof String;
          }
          isNonEmptyString(e) {
            return Boolean(e) && this.isString(e);
          }
          isObjectEmpty(e) {
            return (
              "object" == typeof e &&
              !Array.isArray(e) &&
              null !== e &&
              e &&
              0 === Object.keys(e).length &&
              Object.getPrototypeOf(e) === Object.prototype
            );
          }
          _isDebug() {
            return (
              "true" ===
              new URLSearchParams(window.location.search).get("sas_debug")
            );
          }
        };
      },
      683: function (e, t, a) {
        var s =
          (this && this.__awaiter) ||
          function (e, t, a, s) {
            return new (a || (a = Promise))(function (n, i) {
              function d(e) {
                try {
                  o(s.next(e));
                } catch (e) {
                  i(e);
                }
              }
              function r(e) {
                try {
                  o(s.throw(e));
                } catch (e) {
                  i(e);
                }
              }
              function o(e) {
                var t;
                e.done
                  ? n(e.value)
                  : ((t = e.value),
                    t instanceof a
                      ? t
                      : new a(function (e) {
                          e(t);
                        })).then(d, r);
              }
              o((s = s.apply(e, t || [])).next());
            });
          };
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.SasIabApi = void 0);
        const n = a(882);
        class i {
          constructor(e, t) {
            (this.apiWasFound = !1),
              (this.apiAnsweredOk = !1),
              (this.eventMessageListenerAdded = !1),
              (this.apiCallbacks = {}),
              (this.myCmpCallbackFinished = void 0),
              (this.maxSearchRetry = 50),
              (this.doubleCallbackTime = 10),
              (this.retryNumber = 0),
              (this.retryInterval = 0),
              (this.name = e.name),
              (this.sasCookieName = e.sasCookieName),
              (this.sasAddtlCookieName = e.sasAddtlCookieName),
              (this.version = e.version),
              (this.getConsentFunction = e.getConsentFunction),
              (this.apiFunctionName = e.apiFunctionName),
              (this.consentObjectConsentDataName =
                e.consentObjectConsentDataName),
              (this.consentObjectAdditionalConsentDataName =
                e.consentObjectAdditionalConsentDataName),
              (this.apiLocator = e.apiLocator),
              (this.sentMessage = e.sentMessage),
              (this.postMessageReturnObjectName =
                e.postMessageReturnObjectName),
              t && (this.myCmpCallbackFinished = () => t()),
              (this.lastCallbackResult = {
                id: "",
                addtlConsent: "",
                eventStatus: "",
                timeStamp: 0,
                vendor: { consents: {}, legitimateInterests: {} },
              });
          }
          get gdprApplies() {
            return this._gdprApplies;
          }
          cmpCallback(e, t) {
            var a;
            if (
              !t ||
              !e ||
              void 0 === e[this.consentObjectConsentDataName] ||
              null === e[this.consentObjectConsentDataName]
            )
              return void window.sas.events.fire(
                "ApiAnswered Wrong answer",
                {
                  consent: e,
                  success: t,
                  failType: "Wrong answer",
                  version: this.version,
                },
                this.name
              );
            if (
              "stub" === e.cmpStatus &&
              null !== window.sas.localStorage.getItem(this.sasCookieName)
            )
              return void window.sas.events.fire(
                "ApiAnswered Stub answer",
                {
                  consent: e,
                  success: t,
                  failType: "Ignoring stub data",
                  version: this.version,
                },
                this.name
              );
            (this.apiAnsweredOk = !0), (this._gdprApplies = e.gdprApplies);
            const s = {
              consentObject: e,
              name: this.consentObjectConsentDataName,
            };
            if (
              (e[this.consentObjectConsentDataName] &&
                window.sas.localStorage.setItem(
                  this.sasCookieName,
                  e[this.consentObjectConsentDataName]
                ),
              this.consentObjectAdditionalConsentDataName &&
                e[this.consentObjectAdditionalConsentDataName] &&
                this.sasAddtlCookieName)
            ) {
              let t = e[this.consentObjectAdditionalConsentDataName];
              Array.isArray(t) && (t = JSON.stringify(t)),
                window.sas.localStorage.setItem(this.sasAddtlCookieName, t),
                (s.additionalConsent =
                  this.consentObjectAdditionalConsentDataName);
            }
            window.sas.events.fire("ApiAnswered Valid answer", s, this.name),
              null === (a = this.myCmpCallbackFinished) ||
                void 0 === a ||
                a.call(this);
          }
          callApiLocal() {
            var e;
            return s(this, void 0, void 0, function* () {
              const t = window[this.apiFunctionName];
              if (
                void 0 !== t &&
                "[object Function]" === Object.prototype.toString.call(t)
              ) {
                if (
                  ((this.apiWasFound = !0),
                  window.sas.events.fire(
                    "ApiCalled",
                    { location: "Same Iframe", version: this.version },
                    this.name
                  ),
                  "__gpp" === this.apiFunctionName)
                ) {
                  const a = () => {
                      const e = t("getGPPData");
                      this.cmpCallback(e, null != e);
                    },
                    s = Number(
                      (null === (e = yield (0, n.betterGpp)("ping")) ||
                      void 0 === e
                        ? void 0
                        : e.gppVersion) || 1
                    );
                  s < 1.1 && a(),
                    t(this.getConsentFunction, (e) => {
                      s < 1.1
                        ? a()
                        : this.cmpCallback(
                            null == e ? void 0 : e.pingData,
                            null != (null == e ? void 0 : e.pingData)
                          );
                    });
                } else
                  t(this.getConsentFunction, this.version, (e, t) => {
                    this.cmpCallback(e, t);
                  });
                return !0;
              }
              return !1;
            });
          }
          callApiInFrame() {
            let e,
              t = window;
            for (; !e; ) {
              try {
                t.frames[this.apiLocator] && (e = t);
              } catch (e) {}
              if (t === window.top) break;
              t = t.parent;
            }
            if (e) {
              (this.apiWasFound = !0),
                window.sas.events.fire(
                  "ApiFrameFound",
                  { version: this.version },
                  this.name
                );
              const t = (t, a, s) => {
                const n = "smartjs" + Math.random();
                (this.apiCallbacks[n] = s), this.sendPostMessage(t, a, n, e);
              };
              if (
                (this.eventMessageListenerAdded ||
                  (window.addEventListener("message", (e) => {
                    this.readPostMessageResponse(e);
                  }),
                  (this.eventMessageListenerAdded = !0)),
                window.sas.events.fire(
                  "ApiCalled",
                  { location: "Different iframe", version: this.version },
                  this.name
                ),
                "__gpp" === this.apiFunctionName)
              ) {
                const a = "smartjsPing" + Math.random();
                (this.apiCallbacks[a] = (e) => {
                  var a, s;
                  ((
                    null === (a = e.returnValue) || void 0 === a
                      ? void 0
                      : a.gppVersion
                  )
                    ? Number(
                        null === (s = e.returnValue) || void 0 === s
                          ? void 0
                          : s.gppVersion
                      )
                    : 1) < 1.1 &&
                    t("getGPPData", void 0, (e, t) => {
                      this.cmpCallback(e, t);
                    });
                }),
                  this.sendPostMessage("ping", null, a, e);
              }
              return (
                t(this.getConsentFunction, void 0, (e, t) => {
                  this.cmpCallback(e, t);
                }),
                !0
              );
            }
            return !1;
          }
          sendPostMessage(e, t, a, s) {
            const n = {};
            (n[this.sentMessage] = {
              command: e,
              parameter: t,
              callId: a,
              version: this.version,
            }),
              null == s || s.postMessage(n, "*");
          }
          readPostMessageResponse(e) {
            const t =
              "string" == typeof e.data &&
              -1 !== e.data.indexOf(this.postMessageReturnObjectName)
                ? JSON.parse(e.data)
                : e.data;
            if (t[this.postMessageReturnObjectName]) {
              const a = t[this.postMessageReturnObjectName];
              "function" != typeof this.apiCallbacks[a.callId] ||
                this.isCallbackDouble(a.callId, e) ||
                (this.assignLastCallback(a.callId, e),
                this.apiCallbacks[a.callId](
                  a.returnValue,
                  a.success,
                  this.version
                ));
            }
          }
          isCallbackDouble(e, t) {
            var a, s, n;
            let i = !1;
            const d =
              null ===
                (s =
                  null === (a = null == t ? void 0 : t.data) || void 0 === a
                    ? void 0
                    : a.__tcfapiReturn) || void 0 === s
                ? void 0
                : s.returnValue;
            return (
              e === this.lastCallbackResult.id &&
                (null == t ? void 0 : t.timeStamp) -
                  this.lastCallbackResult.timeStamp <
                  this.doubleCallbackTime &&
                this.lastCallbackResult.addtlConsent ===
                  (null == d ? void 0 : d.addtlConsent) &&
                this.lastCallbackResult.eventStatus ===
                  (null == d ? void 0 : d.eventStatus) &&
                this.lastCallbackResult.gdprApplies ===
                  (null == d ? void 0 : d.gdprApplies) &&
                JSON.stringify(this.lastCallbackResult.vendor.consents) ===
                  JSON.stringify(
                    null === (n = null == d ? void 0 : d.vendor) || void 0 === n
                      ? void 0
                      : n.consents
                  ) &&
                (i = !0),
              i
            );
          }
          assignLastCallback(e, t) {
            var a, s;
            const n =
              null ===
                (s =
                  null === (a = null == t ? void 0 : t.data) || void 0 === a
                    ? void 0
                    : a.__tcfapiReturn) || void 0 === s
                ? void 0
                : s.returnValue;
            (this.lastCallbackResult.id = e),
              (this.lastCallbackResult.addtlConsent =
                null == n ? void 0 : n.addtlConsent),
              (this.lastCallbackResult.eventStatus =
                null == n ? void 0 : n.eventStatus),
              (this.lastCallbackResult.gdprApplies =
                null == n ? void 0 : n.gdprApplies),
              (this.lastCallbackResult.timeStamp =
                null == t ? void 0 : t.timeStamp),
              (null == n ? void 0 : n.vendor) &&
                (this.lastCallbackResult.vendor = Object.assign(
                  {},
                  null == n ? void 0 : n.vendor
                ));
          }
          tryCallApi(e) {
            return s(this, void 0, void 0, function* () {
              (yield this.callApiLocal()) ||
                (e % 10 == 0 &&
                  window.sas.events.fire(
                    "ApiNotFoundInFrame",
                    { retryNumber: e },
                    this.name
                  ),
                this.callApiInFrame());
            });
          }
          searchApiInterval() {
            return s(this, void 0, void 0, function* () {
              (this.apiWasFound && this.apiAnsweredOk) ||
                (this.retryNumber % 10 == 0 &&
                  window.sas.events.fire(
                    "ApiSearch",
                    { retryNumber: this.retryNumber },
                    this.name
                  ),
                yield this.tryCallApi(this.retryNumber)),
                (this.retryNumber > this.maxSearchRetry ||
                  (this.apiWasFound && this.apiAnsweredOk)) &&
                  clearInterval(this.retryInterval),
                this.retryNumber++;
            });
          }
          searchApi() {
            (this.retryInterval = window.setInterval(() => {
              this.searchApiInterval();
            }, 500)),
              this.searchApiInterval();
          }
        }
        (t.SasIabApi = i), (window.SasIabApi = i);
      },
      882: function (e, t) {
        var a,
          s =
            (this && this.__awaiter) ||
            function (e, t, a, s) {
              return new (a || (a = Promise))(function (n, i) {
                function d(e) {
                  try {
                    o(s.next(e));
                  } catch (e) {
                    i(e);
                  }
                }
                function r(e) {
                  try {
                    o(s.throw(e));
                  } catch (e) {
                    i(e);
                  }
                }
                function o(e) {
                  var t;
                  e.done
                    ? n(e.value)
                    : ((t = e.value),
                      t instanceof a
                        ? t
                        : new a(function (e) {
                            e(t);
                          })).then(d, r);
                }
                o((s = s.apply(e, t || [])).next());
              });
            };
        function n(e, t) {
          return new Promise((a) => {
            const s = window.__gpp(
              e,
              (e, t) => {
                t ? a(e) : !1 === t && a(null);
              },
              t
            );
            void 0 !== s && a(s);
          });
        }
        function i(e) {
          var t;
          return s(this, void 0, void 0, function* () {
            if (!1 === (yield n("hasSection", e)))
              return { hasSection: !1, data: null };
            let a = yield n("getSection", e);
            if (!a) {
              const s = yield n("ping"),
                i = null == s ? void 0 : s.parsedSections;
              a =
                null !== (t = null == i ? void 0 : i[e]) && void 0 !== t
                  ? t
                  : null;
            }
            return { hasSection: !0, data: Array.isArray(a) ? a[0] : a };
          });
        }
        function d(e) {
          return s(this, void 0, void 0, function* () {
            return (yield i(e)).data;
          });
        }
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.extendedGetSection =
            t.checkAndGetSection =
            t.getSectionData =
            t.betterGpp =
            t.isUsSection =
            t.ESection =
              void 0),
          (function (e) {
            (e[(e.tcfeuv2 = 2)] = "tcfeuv2"),
              (e[(e.tcfcav1 = 5)] = "tcfcav1"),
              (e[(e.uspv1 = 6)] = "uspv1"),
              (e[(e.usnat = 7)] = "usnat"),
              (e[(e.usca = 8)] = "usca"),
              (e[(e.usva = 9)] = "usva"),
              (e[(e.usco = 10)] = "usco"),
              (e[(e.usut = 11)] = "usut"),
              (e[(e.usct = 12)] = "usct"),
              (e[(e.usfl = 13)] = "usfl"),
              (e[(e.usmt = 14)] = "usmt"),
              (e[(e.usor = 15)] = "usor"),
              (e[(e.ustx = 16)] = "ustx"),
              (e[(e.usde = 17)] = "usde"),
              (e[(e.usia = 18)] = "usia"),
              (e[(e.usne = 19)] = "usne"),
              (e[(e.usnh = 20)] = "usnh"),
              (e[(e.usnj = 21)] = "usnj"),
              (e[(e.ustn = 22)] = "ustn"),
              (e[(e.usmn = 23)] = "usmn"),
              (e[(e.usmd = 24)] = "usmd"),
              (e[(e.usin = 25)] = "usin"),
              (e[(e.usky = 26)] = "usky"),
              (e[(e.usri = 27)] = "usri");
          })((a = t.ESection || (t.ESection = {}))),
          (t.isUsSection = function (e) {
            return e >= a.uspv1 && e <= a.usri;
          }),
          (t.betterGpp = n),
          (t.getSectionData = i),
          (t.checkAndGetSection = d),
          (t.extendedGetSection = function (e) {
            return s(this, void 0, void 0, function* () {
              return (yield d(e)) || d(e + "v1");
            });
          });
      },
      417: (e, t) => {
        Object.defineProperty(t, "__esModule", { value: !0 });
        t.default = class {
          isAvailable() {
            let e = !1;
            try {
              const t = "smart_is_localstorage_available";
              localStorage.setItem(t, "1"),
                "1" === localStorage.getItem(t) &&
                  (localStorage.removeItem(t), (e = !0));
            } catch (e) {}
            return (this.isAvailable = () => e), e;
          }
          getItem(e) {
            return this.isAvailable() ? localStorage.getItem(e) : null;
          }
          setItem(e, t) {
            return !!this.isAvailable() && (localStorage.setItem(e, t), !0);
          }
          removeItem(e) {
            return !!this.isAvailable() && (localStorage.removeItem(e), !0);
          }
        };
      },
      624: (e, t, a) => {
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.EKey = t.Tracing = void 0);
        const s = a(343);
        class n extends s.Global {
          constructor() {
            super(),
              (this.objMap = new Map()),
              (this.samplingRate = this._isDebug() ? 1 : 1e4),
              (this.apiEndpoint =
                "https://apm.smartadserver.com:443/v1/traces"),
              (this.sas.tracing.setTraceHeaders = (e, t) =>
                this.setTraceHeaders(e, t)),
              (this.sas.tracing.add = (e, t) => this.add(e, t)),
              (this.sas.tracing.addMany = (e, t) => this.addMany(e, t)),
              (this.sas.tracing.sendTrace = (e, t) => this.sendTrace(e, t));
          }
          sendTrace(e, t) {
            const a = this.objMap.get(e);
            if (
              !(
                a &&
                a[i.shouldSendTrace] &&
                a[i.traceId] &&
                a[i.parentId] &&
                a[i.adCallStart] &&
                a[i.adCallEnd] &&
                a[i.beforeRender] &&
                (a[i.onAd] || a[i.noAd])
              )
            )
              return;
            const s = this.getEvents(a),
              n = this.getTrace(
                s,
                { startTime: a[i.adCallStart], endTime: a[i.adCallEnd] },
                {
                  startTime: a[i.beforeRender],
                  endTime: a[i.onAd] || a[i.noAd],
                },
                t,
                a[i.traceId],
                a[i.parentId]
              );
            fetch(this.apiEndpoint, {
              method: "POST",
              body: JSON.stringify(n),
              headers: { "Content-type": "application/json" },
            }),
              this._log("trace", void 0, n);
          }
          getEvents(e) {
            return Object.entries(e)
              .filter(([e]) =>
                [i.beforeRender, i.load, i.noAd, i.onAd, i.render].includes(e)
              )
              .map(([e, t]) => ({ name: e, time: t }));
          }
          getTrace(e, t, a, s, n, i) {
            return {
              resourceSpans: [
                {
                  resource: {
                    attributes: [
                      {
                        key: "service.name",
                        value: { stringValue: "smartjs" },
                      },
                      {
                        key: "service.version",
                        value: { stringValue: "1.33.0" },
                      },
                    ],
                  },
                  scopeSpans: [
                    {
                      spans: [
                        {
                          name: "render",
                          traceId: n,
                          spanId: this.genRandomHex(16),
                          parentSpanId: i,
                          startTimeUnixNano: 1e6 * a.startTime,
                          endTimeUnixNano: 1e6 * a.endTime,
                          kind: 1,
                          attributes: [
                            { key: "site.id", value: { intValue: s.siteId } },
                            { key: "page.id", value: { intValue: s.pageId } },
                            {
                              key: "format.id",
                              value: { intValue: s.formatId },
                            },
                            { key: "tag.id", value: { stringValue: s.tagId } },
                            { key: "target", value: { stringValue: s.target } },
                          ],
                          events: e.map((e) => ({
                            name: e.name,
                            timeUnixNano: 1e6 * e.time,
                          })),
                        },
                        {
                          name: "adcall",
                          traceId: n,
                          spanId: i,
                          startTimeUnixNano: 1e6 * t.startTime,
                          endTimeUnixNano: 1e6 * t.endTime,
                          kind: 3,
                          attributes: [
                            {
                              key: "peer.service",
                              value: { stringValue: "delivery" },
                            },
                          ],
                        },
                      ],
                    },
                  ],
                },
              ],
            };
          }
          addMany(e, t) {
            const a = performance.timeOrigin + performance.now();
            for (const s of t) this.add(e, s.tagId, a);
          }
          genRandomHex(e) {
            return [...Array(e)]
              .map(() => Math.floor(16 * Math.random()).toString(16))
              .join("");
          }
          setTraceHeaders(e, t) {
            this.addMany(i.adCallStart, t);
            const a = this.genRandomHex(32),
              s = this.genRandomHex(16),
              n = this.isTraceEligible(a, this.samplingRate);
            this.addData(t, a, s, n),
              e.setRequestHeader(
                "traceparent",
                `00-${a}-${s}-${n ? "01" : "00"}`
              ),
              e.setRequestHeader(
                "tracestate",
                "eqtv-source=smartjs" +
                  (this._isDebug() ? ",eqtv-nosampling=true" : "")
              );
          }
          isTraceEligible(e, t) {
            return this.fnv1a(e) % t == 0;
          }
          fnv1a(e) {
            let t = 2166136261;
            for (let a = 0; a < e.length; a++)
              (t ^= e.charCodeAt(a)),
                (t += (t << 1) + (t << 4) + (t << 7) + (t << 8) + (t << 24));
            return t >>> 0;
          }
          addData(e, t, a, s) {
            for (const n of e)
              this.add(i.traceId, n.tagId, t),
                this.add(i.parentId, n.tagId, a),
                this.add(i.shouldSendTrace, n.tagId, s);
          }
          add(e, t, a) {
            this.objMap.set(
              t,
              Object.assign(Object.assign({}, this.objMap.get(t)), {
                [e]: null != a ? a : performance.timeOrigin + performance.now(),
              })
            );
          }
        }
        var i;
        (t.Tracing = n),
          (function (e) {
            (e.adCallStart = "adCallStart"),
              (e.adCallEnd = "adCallEnd"),
              (e.beforeRender = "beforeRender"),
              (e.noAd = "noAd"),
              (e.onAd = "onAd"),
              (e.load = "load"),
              (e.render = "render"),
              (e.shouldSendTrace = "shouldSendTrace"),
              (e.traceId = "traceId"),
              (e.parentId = "parentId");
          })((i = t.EKey || (t.EKey = {})));
      },
      418: function (e, t, a) {
        var s,
          n,
          i,
          d,
          r =
            (this && this.__createBinding) ||
            (Object.create
              ? function (e, t, a, s) {
                  void 0 === s && (s = a);
                  var n = Object.getOwnPropertyDescriptor(t, a);
                  (n &&
                    !("get" in n
                      ? !t.__esModule
                      : n.writable || n.configurable)) ||
                    (n = {
                      enumerable: !0,
                      get: function () {
                        return t[a];
                      },
                    }),
                    Object.defineProperty(e, s, n);
                }
              : function (e, t, a, s) {
                  void 0 === s && (s = a), (e[s] = t[a]);
                }),
          o =
            (this && this.__setModuleDefault) ||
            (Object.create
              ? function (e, t) {
                  Object.defineProperty(e, "default", {
                    enumerable: !0,
                    value: t,
                  });
                }
              : function (e, t) {
                  e.default = t;
                }),
          l =
            (this && this.__importStar) ||
            function (e) {
              if (e && e.__esModule) return e;
              var t = {};
              if (null != e)
                for (var a in e)
                  "default" !== a &&
                    Object.prototype.hasOwnProperty.call(e, a) &&
                    r(t, e, a);
              return o(t, e), t;
            },
          c =
            (this && this.__importDefault) ||
            function (e) {
              return e && e.__esModule ? e : { default: e };
            };
        Object.defineProperty(t, "__esModule", { value: !0 });
        const u = c(a(833)),
          h = c(a(417)),
          p = c(a(532)),
          g = l(a(581)),
          v = (window.sas = window.sas || {});
        (v.utils = v.utils || {}),
          (v.consent = v.consent || {}),
          (v.cmd = v.cmd || []),
          (v.livePreview = v.livePreview || {}),
          (v.tracing = v.tracing || {}),
          (v.debugMode = v.debugMode || {}),
          (v.debugMode.logsQueue = v.debugMode.logsQueue || []),
          (v.debugMode.bannersQueue = v.debugMode.bannersQueue || []),
          (v.events = (
            null === (s = v.events) || void 0 === s ? void 0 : s.isReady
          )
            ? v.events
            : new u.default()),
          (v.localStorage =
            null !== (n = v.localStorage) && void 0 !== n
              ? n
              : new h.default()),
          (v.Tag = null !== (i = v.Tag) && void 0 !== i ? i : p.default),
          (v.common = null !== (d = v.common) && void 0 !== d ? d : g),
          (t.default = v);
      },
      532: (e, t, a) => {
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.EScriptType = t.ECallType = void 0);
        const s = a(624),
          n = a(581);
        var i, d;
        (t.default = class {
          constructor(e) {
            (this.instances = []),
              (this.hbData = null),
              window.sas.events.on(
                "ad",
                (e) =>
                  this.onAd(
                    Object.assign(
                      Object.assign(
                        {},
                        e.placementuuid
                          ? { placementuuid: e.placementuuid }
                          : { formatId: e.formatId }
                      ),
                      { tagId: e.tagId }
                    )
                  ),
                e
              ),
              window.sas.events.on("load", () => this.onLoad(), e),
              window.sas.events.on(
                "noad",
                (e) => {
                  const t = Object.assign(
                    Object.assign(
                      {},
                      e.placementuuid
                        ? { placementuuid: e.placementuuid }
                        : { formatId: e.formatId }
                    ),
                    { tagId: e.tagId, hbRenderUrls: e.hbRenderUrls || void 0 }
                  );
                  t.hbRenderUrls || delete t.hbRenderUrls, this.onNoad(t);
                },
                e
              ),
              window.sas.events.on(
                "error",
                (e) =>
                  this.onError(
                    Object.assign(
                      Object.assign(
                        {},
                        e.placementuuid
                          ? { placementuuid: e.placementuuid }
                          : { formatId: e.formatId }
                      ),
                      { tagId: e.tagId, instance: e.instance }
                    )
                  ),
                e
              ),
              window.sas.events.on(
                "render",
                (e) =>
                  this.onRender({
                    formatId: e.formatId,
                    tagId: e.tagId,
                    instance: e.instance,
                  }),
                e
              ),
              window.sas.events.on(
                "beforeRender",
                (e) =>
                  this.onBeforeRender(
                    Object.assign(
                      Object.assign(
                        {},
                        e.placementuuid
                          ? { placementuuid: e.placementuuid }
                          : { formatId: e.formatId }
                      ),
                      { tagId: e.tagId }
                    )
                  ),
                e
              ),
              window.sas.events.on(
                "hbRender",
                (e) => this.onHbRender({ success: e.success }),
                e
              ),
              window.sas.events.on(
                "request",
                (e) =>
                  this.onRequest(
                    Object.assign(
                      Object.assign(
                        {},
                        e.placementuuid
                          ? { placementuuid: e.placementuuid }
                          : { formatId: e.formatId }
                      ),
                      { tagId: e.tagId, instance: e.instance }
                    )
                  ),
                e
              );
          }
          onAd(e) {
            var t;
            window.sas.tracing.add(s.EKey.onAd, e.tagId),
              (this.hasAd = !0),
              (null === (t = this.options) || void 0 === t ? void 0 : t.onAd) &&
                this.options.onAd(e);
          }
          onLoad() {
            var e, t, a;
            const n = document.getElementById(this.ad.tagId);
            n &&
              ((this.hasAd = this.hasAd || n.childNodes.length > 1),
              window.sas.tracing.add(s.EKey.load, this.ad.tagId),
              this.hasAd &&
                window.sas.tracing.sendTrace(this.ad.tagId, {
                  siteId: this.ad.siteId,
                  pageId: this.ad.pageId,
                  pageName:
                    null !== (e = this.ad.pageName) && void 0 !== e ? e : "",
                  formatId: this.ad.formatId,
                  tagId: this.ad.tagId,
                  target: this.ad.target,
                }),
              null ===
                (a =
                  null === (t = this.options) || void 0 === t
                    ? void 0
                    : t.onLoad) ||
                void 0 === a ||
                a.call(t, {
                  formatId: this.ad.formatId,
                  tagId: this.ad.tagId,
                  hasAd: this.hasAd,
                }));
          }
          onNoad(e) {
            var t, a, d;
            if (
              (window.sas.tracing.add(s.EKey.noAd, e.tagId),
              window.sas.tracing.sendTrace(e.tagId, {
                siteId: this.ad.siteId,
                pageId: this.ad.pageId,
                pageName:
                  null !== (t = this.ad.pageName) && void 0 !== t ? t : "",
                formatId: this.ad.formatId,
                tagId: this.ad.tagId,
                target: this.ad.target,
              }),
              this.displayData &&
                this.callType == i.ONECALL &&
                this.displayData.scriptNoad)
            ) {
              const e = this.getHeaderBiddingData();
              e &&
                (this.displayData.scriptNoad = (0, n.addHBDataToUrl)(
                  this.displayData.scriptNoad,
                  e
                )),
                (new Image().src = this.displayData.scriptNoad);
            }
            (null === (a = e.hbRenderUrls) || void 0 === a
              ? void 0
              : a.hbRenderFailedUrl) &&
              ((this.hbRenderUrls = e.hbRenderUrls), delete e.hbRenderUrls),
              (null === (d = this.options) || void 0 === d
                ? void 0
                : d.onNoad) && this.options.onNoad(e);
          }
          onError(e) {
            var t;
            (null === (t = this.options) || void 0 === t
              ? void 0
              : t.onError) && this.options.onError(e);
          }
          onRender(e) {
            window.sas.tracing.add(s.EKey.render, e.tagId);
          }
          onBeforeRender(e) {
            var t;
            window.sas.tracing.add(s.EKey.beforeRender, e.tagId),
              (null === (t = this.options) || void 0 === t
                ? void 0
                : t.beforeRender) && this.options.beforeRender(e);
          }
          onHbRender(e) {
            this.hbRenderUrls &&
              (e.success
                ? (new Image().src = this.hbRenderUrls.hbRenderSuccessUrl)
                : (new Image().src = this.hbRenderUrls.hbRenderFailedUrl),
              delete this.hbRenderUrls);
          }
          onRequest(e) {
            var t;
            (null === (t = this.options) || void 0 === t
              ? void 0
              : t.request) && this.options.request(e);
          }
          setHeaderBiddingWinner(e) {
            this.hbData = e;
          }
          getHeaderBiddingData() {
            if (this.hbData && !isNaN(this.hbData.cpm)) {
              const e = this.hbData;
              return (this.hbData = null), e;
            }
            return null;
          }
          clean() {
            var e;
            const t = document.getElementById(this.ad.tagId);
            (null === (e = this.options) || void 0 === e
              ? void 0
              : e.onClean) && this.options.onClean(this.ad.formatId, t),
              window.sas.events.fire(
                "clean",
                {
                  formatId: this.ad.formatId,
                  instance: this.ad.instance,
                  tagId: this.ad.tagId,
                },
                this.ad.tagId
              ),
              t && (t.innerHTML = "");
          }
          onCall(e, t, a) {
            (this.callType = e), (this.ad = t), (this.options = a);
          }
          reset(e, t) {
            delete this.displayData,
              delete this.hbRenderUrls,
              e
                ? (this.renderStatus = null)
                : "rendered" == this.renderStatus &&
                  (this.renderStatus = "pending"),
              window.sas.events.fire(
                "reset",
                {
                  formatId: this.ad.formatId,
                  instance: this.ad.instance,
                  tagId: this.ad.tagId,
                  hardReset: e,
                },
                this.ad.tagId
              ),
              t &&
                this.instances &&
                this.instances.forEach((t) => t.reset(e, !1));
          }
          render() {
            if ("rendered" === this.renderStatus) return;
            if (!this.displayData) return void (this.renderStatus = "pending");
            (this.renderStatus = "rendered"), this.clean();
            const e = this.ad._isPlacement
                ? this.ad.formatId
                : this.ad.placementUUID,
              t = Object.assign(
                Object.assign(
                  {},
                  e ? { placementuuid: e } : { formatId: this.ad.formatId }
                ),
                {
                  instance: this.ad.instance,
                  tagId: this.ad.tagId,
                  hbRenderUrls: this.displayData.hbRenderFailedUrl
                    ? {
                        hbRenderFailedUrl: this.displayData.hbRenderFailedUrl,
                        hbRenderSuccessUrl: this.displayData.hbRenderSuccessUrl,
                      }
                    : void 0,
                }
              );
            window.sas.events.fire("beforeRender", t, this.ad.tagId);
            const a = () => {
                window.sas.events.fire("load", t, this.ad.tagId);
              },
              s = document.getElementById(this.ad.tagId);
            if (
              (window.sas.debugMode.addBanner &&
                s &&
                window.sas.debugMode.addBanner({
                  adSlot: s,
                  adInfo: {
                    "Network ID": this.options.networkId,
                    "Site ID": this.ad.siteId,
                    "Page ID": this.ad.pageId,
                    "Format ID": this.ad.formatId,
                    "Tag ID": this.ad.tagId,
                    Targeting: this.ad.target,
                  },
                }),
              !this.displayData.scriptType)
            )
              return (
                a(),
                window.sas.events.fire("noad", t, this.ad.tagId),
                void (
                  window.sas.debugMode.addLog &&
                  s &&
                  window.sas.debugMode.addLog({
                    adObj: this.ad,
                    isAd: !1,
                    adSlot: s,
                  })
                )
              );
            window.sas.debugMode.addLog &&
              s &&
              window.sas.debugMode.addLog({
                adObj: this.ad,
                isAd: !0,
                adSlot: s,
              }),
              s
                ? (this.handleScriptType(s, a, () => {
                    window.sas.events.fire("error", t, this.ad.tagId),
                      window.sas.events.fire("noad", t, this.ad.tagId);
                  }),
                  (0, n.getLazyLoadingSignal)(String(this.ad.formatId)) &&
                    window.sas.events.fire("request", t, this.ad.tagId),
                  window.sas.events.fire("render", t, this.ad.tagId))
                : window.sas.events.fire("error", t, this.ad.tagId);
          }
          handleScriptType(e, t, a) {
            var s, i;
            switch (
              null === (s = this.displayData) || void 0 === s
                ? void 0
                : s.scriptType
            ) {
              case d.SCRIPT: {
                const s = this.getHeaderBiddingData();
                s &&
                  this.displayData.scriptNoad &&
                  (this.displayData.scriptNoad = (0, n.addHBDataToUrl)(
                    this.displayData.scriptNoad,
                    s
                  )),
                  (0, n.appendScript)(
                    e,
                    this.displayData.scriptSrc,
                    t,
                    a,
                    this.hbData,
                    (0, n.getLazyLoadingSignal)(String(this.ad.formatId)),
                    this.ad.tagId
                  );
                break;
              }
              case d.PASSBACK:
                window.sas.passback({
                  formatId: this.ad.formatId,
                  tagId: this.ad.tagId,
                  chain: this.displayData.chain,
                  noadUrl: this.ad.noadUrl,
                  pageId: this.ad.pageId,
                  siteId: this.ad.siteId,
                });
                break;
              case d.CONTENT:
                "application/javascript" === this.displayData.contentType &&
                  (0, n.appendScriptContent)(
                    e,
                    this.displayData.content,
                    this.ad.tagId
                  ),
                  t();
                break;
              default:
                throw new Error(
                  "Unsupported script type " +
                    (null === (i = this.displayData) || void 0 === i
                      ? void 0
                      : i.scriptType)
                );
            }
          }
        }),
          (function (e) {
            (e.STD = "std"),
              (e.IFRAME = "iframe"),
              (e.ONECALL = "onecall"),
              (e.PASSBACK = "passback");
          })((i = t.ECallType || (t.ECallType = {}))),
          (function (e) {
            (e.IFRAME = "iframe"),
              (e.SCRIPT = "script"),
              (e.PASSBACK = "passback"),
              (e.CONTENT = "content");
          })((d = t.EScriptType || (t.EScriptType = {})));
      },
      581: (e, t) => {
        function a(e, t) {
          return `${e}&hb_cpm=${t.cpm}&hb_bid=${t.bidder}&hb_ccy=${t.currency}${
            t.dealId ? `&hb_dealid=${t.dealId}` : ""
          }`;
        }
        function s() {
          return window.sas.localStorage.getItem("sas_usprivacy");
        }
        function n() {
          var e;
          return window.sas.publisherDefinedConsent
            ? window.sas.publisherDefinedConsent
            : null !==
                (e = window.sas.localStorage.getItem("sas_euconsent_v2")) &&
              void 0 !== e
            ? e
            : window.sas.localStorage.getItem("sas_euconsent");
        }
        function i() {
          return window.sas.utils.isAddtlConsentBlocked()
            ? null
            : window.sas.localStorage.getItem("sas_addtl_euconsent_v2");
        }
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.appendScriptContent =
            t.appendScript =
            t.updateConsentDataInUrl =
            t.getLazyLoadingSignal =
            t.getAddtlConsentData =
            t.getGdprConsentData =
            t.getUsPrivacyConsentData =
            t.addHBDataToUrl =
              void 0),
          (t.addHBDataToUrl = a),
          (t.getUsPrivacyConsentData = s),
          (t.getGdprConsentData = n),
          (t.getAddtlConsentData = i);
        const d =
          /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
        function r(e) {
          var t, a;
          let d;
          try {
            d = new URL(e);
          } catch (t) {
            return e;
          }
          const r = n();
          r && d.searchParams.set("gdpr_consent", r);
          const o = i();
          o && d.searchParams.set("addtl_consent", o);
          const l = s();
          l && d.searchParams.set("us_privacy", l);
          const c = window.sas.localStorage.getItem("sas_gpp_sid");
          if (c)
            try {
              const e = JSON.parse(c);
              if (e.length) {
                const t = window.sas.localStorage.getItem("sas_gpp");
                t &&
                  (d.searchParams.set("gpp", t),
                  d.searchParams.set("gpp_sid", e));
              }
            } catch (e) {}
          const u = window.sas.localStorage.getItem("eqtv_cmpvalid");
          u && d.searchParams.set("cmpvalid", u);
          const h = window.sas.updateTarget(
            null !== (t = d.searchParams.get("tgt")) && void 0 !== t
              ? t
              : void 0,
            null !== (a = d.searchParams.get("tag")) && void 0 !== a ? a : ""
          );
          return h && d.searchParams.set("tgt", h), d.toString();
        }
        (t.getLazyLoadingSignal = function (e) {
          if (!window.sas.lazyLoading) return !1;
          if (d.test(e)) {
            const { placements: t } = window.sas.lazyLoading;
            return !(!t || (0 !== t.length && -1 === t.indexOf(e)));
          }
          const { formats: t } = window.sas.lazyLoading;
          return !(!t || (0 !== t.length && -1 === t.indexOf(parseInt(e, 10))));
        }),
          (t.updateConsentDataInUrl = r),
          (t.appendScript = function (e, t, s, n, i, d, o) {
            const l = document.createElement("script");
            (l.id = "sas_script_" + o), (l.type = "text/javascript");
            let c = "function" == typeof t ? t() : t;
            i && (c = a(c, i)),
              d && (c = r(c)),
              (l.src = c),
              (l.async = !0),
              l.addEventListener("load", s),
              l.addEventListener("error", n),
              e.appendChild(l);
          }),
          (t.appendScriptContent = function (e, t, a) {
            const s = document.createElement("script");
            (s.id = "sas_script_" + a), (s.text = t), e.appendChild(s);
          });
      },
    },
    t = {};
  function a(s) {
    var n = t[s];
    if (void 0 !== n) return n.exports;
    var i = (t[s] = { exports: {} });
    return e[s].call(i.exports, i, i.exports, a), i.exports;
  }
  (() => {
    a(418);
    const e = a(683);
  })();
})();
