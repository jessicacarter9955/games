(function () {
  var aa;
  function ba(a) {
    var b = 0;
    return function () {
      return b < a.length ? { done: !1, value: a[b++] } : { done: !0 };
    };
  }
  var ca =
    "function" == typeof Object.defineProperties
      ? Object.defineProperty
      : function (a, b, c) {
          if (a == Array.prototype || a == Object.prototype) return a;
          a[b] = c.value;
          return a;
        };
  function da(a) {
    a = [
      "object" == typeof globalThis && globalThis,
      a,
      "object" == typeof window && window,
      "object" == typeof self && self,
      "object" == typeof global && global,
    ];
    for (var b = 0; b < a.length; ++b) {
      var c = a[b];
      if (c && c.Math == Math) return c;
    }
    throw Error("Cannot find global object");
  }
  var ea = da(this);
  function fa(a, b) {
    if (b)
      a: {
        for (var c = ea, d = a.split("."), e = 0; e < d.length - 1; e++) {
          var f = d[e];
          if (!(f in c)) break a;
          c = c[f];
        }
        d = d[d.length - 1];
        e = c[d];
        f = b(e);
        f != e &&
          null != f &&
          ca(c, d, { configurable: !0, writable: !0, value: f });
      }
  }
  fa("Symbol", function (a) {
    function b(f) {
      if (this instanceof b) throw new TypeError("Symbol is not a constructor");
      return new c(d + (f || "") + "_" + e++, f);
    }
    function c(f, g) {
      this.xd = f;
      ca(this, "description", { configurable: !0, writable: !0, value: g });
    }
    if (a) return a;
    c.prototype.toString = function () {
      return this.xd;
    };
    var d = "jscomp_symbol_" + ((1e9 * Math.random()) >>> 0) + "_",
      e = 0;
    return b;
  });
  fa("Symbol.iterator", function (a) {
    if (a) return a;
    a = Symbol("Symbol.iterator");
    for (
      var b =
          "Array Int8Array Uint8Array Uint8ClampedArray Int16Array Uint16Array Int32Array Uint32Array Float32Array Float64Array".split(
            " "
          ),
        c = 0;
      c < b.length;
      c++
    ) {
      var d = ea[b[c]];
      "function" === typeof d &&
        "function" != typeof d.prototype[a] &&
        ca(d.prototype, a, {
          configurable: !0,
          writable: !0,
          value: function () {
            return ha(ba(this));
          },
        });
    }
    return a;
  });
  function ha(a) {
    a = { next: a };
    a[Symbol.iterator] = function () {
      return this;
    };
    return a;
  }
  function n(a) {
    var b =
      "undefined" != typeof Symbol && Symbol.iterator && a[Symbol.iterator];
    if (b) return b.call(a);
    if ("number" == typeof a.length) return { next: ba(a) };
    throw Error(String(a) + " is not an iterable or ArrayLike");
  }
  function ia(a) {
    for (var b, c = []; !(b = a.next()).done; ) c.push(b.value);
    return c;
  }
  function ja(a) {
    return a instanceof Array ? a : ia(n(a));
  }
  var ka =
      "function" == typeof Object.create
        ? Object.create
        : function (a) {
            function b() {}
            b.prototype = a;
            return new b();
          },
    la;
  if ("function" == typeof Object.setPrototypeOf) la = Object.setPrototypeOf;
  else {
    var ma;
    a: {
      var na = { a: !0 },
        oa = {};
      try {
        oa.__proto__ = na;
        ma = oa.a;
        break a;
      } catch (a) {}
      ma = !1;
    }
    la = ma
      ? function (a, b) {
          a.__proto__ = b;
          if (a.__proto__ !== b) throw new TypeError(a + " is not extensible");
          return a;
        }
      : null;
  }
  var pa = la;
  function qa(a, b) {
    a.prototype = ka(b.prototype);
    a.prototype.constructor = a;
    if (pa) pa(a, b);
    else
      for (var c in b)
        if ("prototype" != c)
          if (Object.defineProperties) {
            var d = Object.getOwnPropertyDescriptor(b, c);
            d && Object.defineProperty(a, c, d);
          } else a[c] = b[c];
    a.Ve = b.prototype;
  }
  function ra() {
    for (var a = Number(this), b = [], c = a; c < arguments.length; c++)
      b[c - a] = arguments[c];
    return b;
  }
  var sa = {
      construct: "Metrika2",
      callbackPostfix: "2",
      version: "4tvkupd2vg89dwekd16jpvfdqys7vf",
      host: "mc.yandex.com",
    },
    ta = { 206555165: 1, 655012937: 1, 1269618038: 1, 1676263684: 1 };
  function r() {}
  var ua = [];
  function va(a, b) {
    if (!b || "function" !== typeof b) return !1;
    try {
      var c = "" + b;
    } catch (h) {
      return !1;
    }
    var d = c.length;
    if (d > 35 + a.length) return !1;
    for (var e = d - 13, f = 0, g = 8; g < d; g += 1) {
      f = "[native code]"[f] === c[g] || (7 === f && "-" === c[g]) ? f + 1 : 0;
      if (12 === f) return !0;
      if (!f && g > e) break;
    }
    return !1;
  }
  function wa(a, b) {
    var c = va(a, b);
    b && !c && ua.push([a, b]);
    return c;
  }
  function xa(a, b) {
    return wa(b, a) && a;
  }
  var ya = /\./g;
  function u(a) {
    return "string" === typeof a;
  }
  var za = xa(String.prototype.indexOf, "indexOf");
  function Aa(a, b) {
    for (var c = 0, d = a.length - b.length, e = 0; e < a.length; e += 1) {
      c = a[e] === b[c] ? c + 1 : 0;
      if (c === b.length) return e - b.length + 1;
      if (!c && e > d) break;
    }
    return -1;
  }
  var Ba = za
    ? function (a, b) {
        return za.call(a, b);
      }
    : Aa;
  function Ca(a, b) {
    return Ba(a, b);
  }
  var Da = xa(String.prototype.lastIndexOf, "lastIndexOf");
  function Ea(a, b) {
    var c = b.length,
      d = a.length;
    if (0 === c) return d;
    for (d -= c; 0 <= d; --d) {
      for (var e = !0, f = 0; f < c; f += 1)
        if (a[d + f] !== b[f]) {
          e = !1;
          break;
        }
      if (e) return d;
    }
    return -1;
  }
  var Fa = Da
    ? function (a, b) {
        return Da.call(a, b);
      }
    : Ea;
  function Ga(a, b) {
    return Fa(a, b);
  }
  function Ha(a, b) {
    return !(!a || -1 === Ba(a, b));
  }
  function Ia(a) {
    return "" + a;
  }
  function Ja(a) {
    return a
      .replace(/\^/g, "\\^")
      .replace(/\$/g, "\\$")
      .replace(ya, "\\.")
      .replace(/\[/g, "\\[")
      .replace(/\]/g, "\\]")
      .replace(/\|/g, "\\|")
      .replace(/\(/g, "\\(")
      .replace(/\)/g, "\\)")
      .replace(/\?/g, "\\?")
      .replace(/\*/g, "\\*")
      .replace(/\+/g, "\\+")
      .replace(/\{/g, "\\{")
      .replace(/\}/g, "\\}");
  }
  function Ka(a) {
    return "[object Array]" === Object.prototype.toString.call(a);
  }
  var La = xa(Array.isArray, "isArray"),
    w = La
      ? function (a) {
          return La(a);
        }
      : Ka;
  function Ma(a) {
    return function (b) {
      return function (c) {
        return a(b, c);
      };
    };
  }
  function Na(a) {
    return function (b) {
      return function (c) {
        return a(c, b);
      };
    };
  }
  var Oa = Ma(function (a, b) {
      return a === b;
    }),
    Pa = Ma(function (a, b) {
      a(b);
      return b;
    }),
    Qa = Ma(function (a, b) {
      return b(a);
    }),
    Ra = Oa(null);
  function y(a) {
    return "function" === typeof a;
  }
  var Sa = Oa(void 0);
  function z(a) {
    return Sa(a) || Ra(a);
  }
  function A(a) {
    return (
      !Ra(a) &&
      !Sa(a) &&
      "[object Object]" === Object.prototype.toString.call(a)
    );
  }
  var Ta = xa(Array.from, "from");
  function Ua(a) {
    for (var b = a.length, c = [], d = 0; d < b; d += 1) c.push(a[d]);
    return c;
  }
  function Va(a) {
    if (Ta)
      try {
        return Ta(a);
      } catch (b) {}
    return Ua(a);
  }
  function Wa(a, b, c) {
    b = void 0 === b ? [] : b;
    c = c || {};
    var d = b.length,
      e = a;
    y(e) && ((e = "d"), (c[e] = a));
    var f;
    d
      ? 1 === d
        ? (f = c[e](b[0]))
        : 2 === d
        ? (f = c[e](b[0], b[1]))
        : 3 === d
        ? (f = c[e](b[0], b[1], b[2]))
        : 4 === d && (f = c[e](b[0], b[1], b[2], b[3]))
      : (f = c[e]());
    return f;
  }
  var Xa = xa(Function.prototype.bind, "bind");
  function Ya() {
    var a = n(arguments),
      b = a.next().value,
      c = a.next().value,
      d = ia(a);
    return function () {
      var e = [].concat(ja(d), ja(arguments));
      if (Function.prototype.call)
        return Function.prototype.call.apply(b, [c].concat(e));
      if (c) {
        for (var f = "_b"; c[f]; ) f += "_" + f.length;
        c[f] = b;
        e = c[f] && Wa(f, e, c);
        delete c[f];
        return e;
      }
      return Wa(b, e);
    };
  }
  var B = Xa
    ? function () {
        var a = Va(arguments),
          b = n(a);
        a = b.next().value;
        var c = b.next().value;
        b = ia(b);
        return Xa.apply(a, [c].concat(b));
      }
    : Ya;
  function D(a, b) {
    return B.apply(null, [b, null].concat(ja(a)));
  }
  function F(a, b) {
    return B(b, null, a);
  }
  function Za(a, b) {
    return B(b[a], b);
  }
  function $a(a) {
    return Za("test", a);
  }
  var ab = xa(Array.prototype.reduce, "reduce");
  function bb(a, b, c) {
    for (var d = 0, e = c.length; d < e; ) (b = a(b, c[d], d)), (d += 1);
    return b;
  }
  var G = ab
    ? function (a, b, c) {
        return ab.call(c, a, b);
      }
    : bb;
  function cb(a, b) {
    return D([a, b], G);
  }
  var db = Object.prototype.hasOwnProperty;
  function H(a, b) {
    return z(a) ? !1 : db.call(a, b);
  }
  function I(a, b) {
    if (!a) return null;
    var c = b.split("."),
      d = c.length,
      e = a,
      f = 0;
    try {
      for (; f < d; ) {
        if (null === e || void 0 === e) return e;
        e = e[c[f]];
        f += 1;
      }
    } catch (g) {
      return null;
    }
    return e;
  }
  var J = Na(I),
    eb = J("length");
  function fb(a) {
    var b = void 0 === b ? {} : b;
    if (!a || 1 > a.length) return b;
    G(
      function (c, d, e) {
        if (e === a.length - 1) return c;
        e === a.length - 2 ? (c[d] = a[e + 1]) : H(c, d) || (c[d] = {});
        return c[d];
      },
      b,
      a
    );
    return b;
  }
  function gb(a, b) {
    for (var c = 0; c < b.length; c += 1) if (b[c] === a) return c;
    return -1;
  }
  var hb;
  function ib(a) {
    if (hb) return hb;
    var b = !1;
    try {
      b = [].indexOf && 0 === [void 0].indexOf(void 0);
    } catch (d) {}
    var c =
      a.Array && a.Array.prototype && xa(a.Array.prototype.indexOf, "indexOf");
    return (hb = a =
      b && c
        ? function (d, e) {
            return c.call(e, d);
          }
        : gb);
  }
  var jb = ib(window),
    kb = Na(jb);
  function lb(a) {
    return a;
  }
  function mb(a, b) {
    return b;
  }
  function nb(a) {
    return !a;
  }
  function K(a, b) {
    var c = [],
      d = [];
    var e = b ? b : lb;
    return function () {
      var f = Va(arguments),
        g = e.apply(null, ja(f)),
        h = jb(g, d);
      if (-1 !== h) return c[h];
      f = a.apply(null, ja(f));
      c.push(f);
      d.push(g);
      return f;
    };
  }
  var ob = K(function (a) {
    a = I(a, "navigator") || {};
    var b = I(a, "userAgent") || "";
    return { Jc: -1 < Ba(I(a, "vendor") || "", "Apple"), ud: b };
  });
  function pb(a, b) {
    return -1 !== (I(b, "navigator.userAgent") || "").toLowerCase().search(a);
  }
  var qb = K(J("navigator.userAgent"));
  function rb(a, b) {
    return (
      a.isFinite(b) &&
      !a.isNaN(b) &&
      "[object Number]" === Object.prototype.toString.call(b)
    );
  }
  function sb(a) {
    try {
      return parseInt(a, 10);
    } catch (b) {
      return null;
    }
  }
  var tb = Na(parseInt),
    ub = tb(10),
    vb = tb(2),
    wb = /Firefox\/([0-9]+)/i,
    xb = K(function (a) {
      var b = I(a, "document.documentElement.style"),
        c = I(a, "InstallTrigger");
      a = pb(wb, a);
      wb.lastIndex = 0;
      return !(!(b && "MozAppearance" in b) || z(c)) || a;
    });
  function yb(a) {
    return xb(a) ? ((a = qb(a).match(wb)) && a.length ? ub(a[1]) : 1) : 0;
  }
  function zb(a, b) {
    var c = I(b, a),
      d = I(b, "constructor.prototype." + a) || c;
    try {
      if (d && d.apply)
        return function () {
          return d.apply(b, arguments);
        };
    } catch (e) {
      return c;
    }
    return d;
  }
  function Ab() {
    var a = Array.prototype.map;
    if (!xb(window)) return !0;
    try {
      a.call({ 0: !0, length: -Math.pow(2, 32) + 1 }, function () {
        throw 1;
      });
    } catch (b) {
      return !1;
    }
    return !0;
  }
  var Bb = xa(Array.prototype.map, "map");
  function Cb(a, b) {
    return G(
      function (c, d, e) {
        c.push(a(d, e));
        return c;
      },
      [],
      b
    );
  }
  var L =
      Bb && Ab()
        ? function (a, b) {
            return b && 0 < b.length ? Bb.call(b, a) : [];
          }
        : Cb,
    Db = xa(Array.prototype.flatMap, "flatMap");
  function Eb(a, b) {
    return G(
      function (c, d, e) {
        d = a(d, e);
        return c.concat(w(d) ? d : [d]);
      },
      [],
      b
    );
  }
  var Fb = Db
      ? function (a, b) {
          return Db.call(b, a);
        }
      : Eb,
    Gb = Ma(L),
    Hb = Ma(L),
    Ib = Na(L);
  function M() {
    var a = arguments,
      b = a[0];
    return function () {
      for (var c = b.apply(null, arguments), d = a.length, e = 1; e < d; )
        (c = a[e](c)), (e += 1);
      return c;
    };
  }
  var Jb = Ma(D);
  function Kb(a, b, c) {
    return c ? a : b;
  }
  var Lb = D([1, null], Kb),
    Mb = D([1, 0], Kb),
    Nb = Boolean,
    Ob = xa(Array.prototype.filter, "filter");
  function Pb(a, b) {
    return bb(
      function (c, d, e) {
        a(d, e) && c.push(d);
        return c;
      },
      [],
      b
    );
  }
  var Qb = Ob
      ? function (a, b) {
          return Ob.call(b, a);
        }
      : Pb,
    Rb = F(Nb, Qb),
    Sb = Ma(Qb),
    Tb = xa(Array.prototype.includes, "includes");
  function Ub(a, b) {
    return 1 <= Pb(Oa(a), b).length;
  }
  var N = Tb
      ? function (a, b, c) {
          return Tb.call(b, a, c);
        }
      : Ub,
    Vb = Na(N),
    Wb = xa(Array.prototype.every, "every");
  function Xb(a, b) {
    return G(
      function (c, d, e) {
        return c ? !!a(d, e) : !1;
      },
      !0,
      b
    );
  }
  var Yb = Wb
    ? function (a, b) {
        return Wb.call(b, a);
      }
    : Xb;
  function Zb(a, b) {
    return Ra(b) || Sa(b) || rb(a, b) || u(b) || !!b === b;
  }
  var $b = xa(Object.keys, "keys");
  function ac(a) {
    var b = [],
      c;
    for (c in a) H(a, c) && b.push(c);
    return b;
  }
  var bc = xa(Object.entries, "entries");
  function cc(a) {
    return Sa(a)
      ? []
      : bb(
          function (b, c) {
            b.push([c, a[c]]);
            return b;
          },
          [],
          ac(a)
        );
  }
  var dc = bc
      ? function (a) {
          return a ? bc(a) : [];
        }
      : cc,
    ec = $b
      ? function (a) {
          return $b(a);
        }
      : ac,
    fc = xa(Object.values, "values"),
    gc = M(cc, F(J("1"), Cb)),
    hc = fc
      ? function (a) {
          return fc(a);
        }
      : gc;
  function ic() {
    var a = Va(arguments),
      b = n(a);
    a = b.next().value;
    for (b = ia(b); b.length; ) {
      var c = b.shift(),
        d;
      for (d in c) H(c, d) && (a[d] = c[d]);
      H(c, "toString") && (a.toString = c.toString);
    }
    return a;
  }
  var O = Object.assign || ic,
    jc = Ma(function (a, b) {
      return O({}, a, b);
    });
  function kc(a) {
    var b = this;
    this.W = [];
    this.size = 0;
    a &&
      L(function (c) {
        b.add(c);
      }, a);
  }
  aa = kc.prototype;
  aa.add = function (a) {
    -1 === jb(a, this.W) && (this.W.push(a), (this.size = this.W.length));
    return this;
  };
  aa.has = function (a) {
    return -1 !== jb(a, this.W);
  };
  aa["delete"] = function (a) {
    a = jb(a, this.W);
    if (-1 === a) return !1;
    this.W.splice(a, 1);
    this.size = this.W.length;
    return !0;
  };
  aa.clear = function () {
    this.W = [];
    this.size = 0;
  };
  aa.forEach = function (a) {
    var b = this;
    L(function (c) {
      a(c, c, b);
    }, this.W);
  };
  function lc(a) {
    var b = [];
    a.forEach(function (c) {
      b.push(c);
    });
    return b;
  }
  function mc(a) {
    if (!a) return [];
    if (w(a)) return a;
    if (a instanceof kc) return a.W.slice();
    if (Ta)
      try {
        return Ta(a);
      } catch (b) {}
    return "number" === typeof a.size && y(a.add)
      ? lc(a)
      : "number" === typeof a.length && 0 <= a.length
      ? Ua(a)
      : [];
  }
  var nc = K(ib),
    oc = J("0");
  function pc(a) {
    return a.splice(0, a.length);
  }
  var qc = xa(Array.prototype.some, "some");
  function rc(a, b) {
    for (var c = 0; c < b.length; c += 1)
      if (c in b && a.call(b, b[c], c)) return !0;
    return !1;
  }
  var sc = qc
      ? function (a, b) {
          return qc.call(b, a);
        }
      : rc,
    tc = K(M(J("String.fromCharCode"), F("fromCharCode", wa), nb)),
    uc = K(M(qb, $a(/ipad|iphone|ipod/i))),
    vc = K(function (a) {
      return I(a, "navigator.platform") || "";
    }),
    wc = K(function (a) {
      a = ob(a);
      var b = a.ud;
      return a.Jc && !b.match("CriOS");
    }),
    xc = $a(
      /Android.*Version\/[0-9][0-9.]*\sChrome\/[0-9][0-9.]|Android.*Version\/[0-9][0-9.]*\s(?:Mobile\s)?Safari\/[0-9][0-9.]*\sChrome\/[0-9][0-9.]*|; wv\).*Chrome\/[0-9][0-9.]*\sMobile/
    ),
    yc = $a(/; wv\)/),
    zc = K(function (a) {
      a = qb(a);
      return yc(a) || xc(a);
    }),
    Ac = /Chrome\/(\d+)\./,
    Bc = K(function (a) {
      return (a = (I(a, "navigator.userAgent") || "").match(Ac)) && a.length
        ? 76 <= ub(a[1])
        : !1;
    }),
    Cc = K(function (a) {
      a = (qb(a) || "").toLowerCase();
      return Ha(a, "android") && Ha(a, "mobile");
    }),
    Dc =
      "other none unknown wifi ethernet bluetooth cellular wimax mixed".split(
        " "
      ),
    Ec = K(function (a) {
      var b = I(a, "navigator.connection.type");
      if (Sa(b)) return null;
      a = nc(a)(b, Dc);
      return -1 === a ? b : "" + a;
    }),
    Fc = K(M(J("document.addEventListener"), nb)),
    Gc = K(function (a) {
      var b = I(a, "navigator") || {};
      return G(
        function (c, d) {
          return c || I(b, d);
        },
        "",
        ["language", "userLanguage", "browserLanguage", "systemLanguage"]
      );
    }),
    Hc = K(function (a) {
      var b = I(a, "navigator") || {};
      a = Gc(a);
      u(a) || ((a = ""), (b = I(b, "languages.0")), u(b) && (a = b));
      return a.toLowerCase().split("-")[0];
    }),
    Ic = K(function (a) {
      return (I(a, "top") || a) !== a;
    }),
    Jc = K(J("top.contentWindow")),
    Kc = K(function (a) {
      var b = !1;
      try {
        b = a.navigator.javaEnabled();
      } catch (c) {}
      return b;
    }),
    Lc = K(function (a) {
      var b =
          "__webdriver_evaluate __selenium_evaluate __webdriver_script_function __webdriver_script_func __webdriver_script_fn __fxdriver_evaluate __driver_unwrapped __webdriver_unwrapped __driver_evaluate __selenium_unwrapped __fxdriver_unwrapped".split(
            " "
          ),
        c = I(a, "external");
      c = -1 !== Ba(I(c, "toString") ? "" + c.toString() : "", "Sequentum");
      var d = I(a, "document.documentElement"),
        e = ["selenium", "webdriver", "driver"];
      return !!(
        sc(F(a, I), ["_selenium", "callSelenium", "_Selenium_IDE_Recorder"]) ||
        sc(F(I(a, "document"), I), b) ||
        c ||
        (d && sc(B(d.getAttribute, d), e))
      );
    }),
    Mc = K(function (a) {
      return !!(
        sc(F(a, I), ["_phantom", "__nightmare", "callPhantom"]) ||
        /(PhantomJS)|(HeadlessChrome)/.test(qb(a)) ||
        I(a, "navigator.webdriver") ||
        (I(a, "isChrome") && !I(a, "chrome"))
      );
    }),
    Nc = K(function (a) {
      return !(!I(a, "ia_document.shareURL") || !I(a, "ia_document.referrer"));
    });
  function Oc(a) {
    return (
      I(a, "document.prerendering") ||
      "prerender" === I(a, "document.webkitVisibilityState") ||
      "prerender" === I(a, "document.visibilityState")
    );
  }
  var Pc = K(function (a) {
      var b = qb(a) || "",
        c = b.match(/Mac OS X ([0-9]+)_([0-9]+)/);
      c = c ? [+c[1], +c[2]] : [0, 0];
      b = b.match(/iPhone OS ([1-9]+)_([0-9]+)/);
      return 14 <= (b ? +b[1] : 0)
        ? !0
        : (uc(a) || 10 < c[0] || (10 === c[0] && 13 <= c[1])) && wc(a);
    }),
    Qc = /Edg\/(\d+)\./;
  function Rc(a) {
    return (a = qb(a)) && (a = a.match(Qc)) && 1 < a.length
      ? 79 <= ub(a[1])
      : !1;
  }
  var Sc = K(function (a) {
      return Pc(a) || 68 <= yb(a) || Rc(a);
    }),
    Tc = K(function (a) {
      a = !(!a.addEventListener || !a.removeEventListener);
      return {
        ve: a,
        C: a ? "addEventListener" : "attachEvent",
        qa: a ? "removeEventListener" : "detachEvent",
      };
    });
  function Uc(a, b, c, d, e, f) {
    a = Tc(a);
    var g = a.C,
      h = a.qa;
    f = f ? h : g;
    if (b[f])
      if (a.ve)
        if (e) b[f](c, d, e);
        else b[f](c, d);
      else b[f]("on" + c, d);
  }
  var Vc = K(function (a) {
      var b = !1;
      if (!a.addEventListener) return b;
      try {
        var c = Object.defineProperty({}, "passive", {
          get: function () {
            b = !0;
            return 1;
          },
        });
        a.addEventListener("test", r, c);
      } catch (d) {}
      return b;
    }),
    Wc = Ma(function (a, b) {
      if (null !== b) return a ? O({ capture: !0, passive: !0 }, b || {}) : !!b;
    }),
    Xc = K(function (a) {
      var b = Vc(a),
        c = Wc(b),
        d = {};
      return O(d, {
        C: function (e, f, g, h) {
          L(function (k) {
            var l = c(h);
            Uc(a, e, k, g, l, !1);
          }, f);
          return B(d.ua, d, e, f, g, h);
        },
        ua: function (e, f, g, h) {
          L(function (k) {
            var l = c(h);
            Uc(a, e, k, g, l, !0);
          }, f);
        },
      });
    }),
    Zc = ["webkitvisibilitychange", "visibilitychange", "prerenderingchange"];
  function $c(a) {
    return {
      K: function (b, c) {
        var d = a.document,
          e = b.G;
        if (e && Oc(a)) {
          var f = Xc(a),
            g = function (h) {
              Oc(a) || (f.ua(d, Zc, g), c());
              return h;
            };
          f.C(d, Zc, g);
          e.B("pr", "1");
        } else c();
      },
    };
  }
  function ad(a, b) {
    L(M(lb, Za("push", a)), b);
    return a;
  }
  function bd(a) {
    a = a.Ya = a.Ya || {};
    var b = (a._metrika = a._metrika || {});
    return {
      V: function (c, d) {
        H(b, c) || (b[c] = d);
        return this;
      },
      B: function (c, d) {
        b[c] = d;
        return this;
      },
      o: function (c, d) {
        var e = b[c];
        return H(b, c) || Sa(d) ? e : d;
      },
    };
  }
  var P = K(bd);
  function cd(a, b, c) {
    return function () {
      var d = P(arguments[0]),
        e = c ? "global" : "m2720",
        f = d.o(e, {}),
        g = I(f, a);
      g || ((g = K(b)), (f[a] = g), d.B(e, f));
      return g.apply(null, arguments);
    };
  }
  var Q = K(function (a) {
      return a.id + ":" + a.M;
    }),
    dd = Vb([26812653]),
    ed = K(M(J("id"), dd), Q),
    fd = "hash host hostname href pathname port protocol search".split(" ");
  function R(a) {
    return G(
      function (b, c) {
        var d = I(a, "location." + c);
        b[c] = d ? "" + d : "";
        return b;
      },
      {},
      fd
    );
  }
  var gd =
      "ru by kz az kg lv md tj tm uz ee fr lt com co.il com.ge com.am com.tr com.ru".split(
        " "
      ),
    hd = /(?:^|\.)(?:(ya\.ru)|(?:yandex)\.(\w+|com?\.\w+))$/;
  function id(a) {
    if ((a = a.match(hd))) {
      var b = n(a);
      b.next();
      a = b.next().value;
      if ((b = b.next().value)) return N(b, gd) ? b : !1;
      if (a) return gd[0];
    }
    return !1;
  }
  var jd = K(function (a) {
      return (a ? a.replace(/^www\./, "") : "").toLowerCase();
    }),
    kd = K(function (a) {
      a = R(a).hostname;
      var b = !1;
      a && (b = -1 !== a.search(hd));
      return b;
    }),
    ld = M(R, J("protocol"), Oa("https:")),
    md = K(function (a) {
      return Bc(a) && ld(a) ? "SameSite=None;Secure;" : "";
    });
  function nd(a, b) {
    for (var c = "", d = 0; d < b.length; d += 1) c += "" + (d ? a : "") + b[d];
    return c;
  }
  var od = xa(Array.prototype.join, "join"),
    T = od
      ? function (a, b) {
          return od.call(b, a);
        }
      : nd,
    pd = Ma(T);
  function qd(a) {
    try {
      return encodeURIComponent(a);
    } catch (b) {}
    a = T(
      "",
      Qb(function (b) {
        return 55296 >= b.charCodeAt(0);
      }, a.split(""))
    );
    return encodeURIComponent(a);
  }
  function rd(a) {
    var b = "";
    try {
      b = decodeURIComponent(a);
    } catch (c) {}
    return b;
  }
  function sd(a) {
    return a
      ? M(
          Gb(function (b) {
            var c = n(b.split("="));
            b = c.next().value;
            c = c.next().value;
            return [b, z(c) ? void 0 : rd(c)];
          }),
          cb(function (b, c) {
            var d = n(c),
              e = d.next().value;
            d = d.next().value;
            b[e] = d;
            return b;
          }, {})
        )(a.split("&"))
      : {};
  }
  function td(a) {
    return a
      ? M(
          dc,
          cb(function (b, c) {
            var d = n(c),
              e = d.next().value;
            d = d.next().value;
            Sa(d) || z(d) || b.push(e + "=" + qd(d));
            return b;
          }, []),
          pd("&")
        )(a)
      : "";
  }
  var ud = /^\s+|\s+$/g,
    vd = xa(String.prototype.trim, "trim");
  function wd(a, b) {
    if (a) {
      var c = vd ? vd.call(a) : ("" + a).replace(ud, "");
      return b && c.length > b ? c.substring(0, b) : c;
    }
    return "";
  }
  var xd = Ma(function (a, b) {
      return b.replace(a, "");
    }),
    yd = xd(/\s/g),
    zd = xd(/\D/g),
    Ad = xd(/\d/g),
    Bd = ["metrika_enabled"],
    Cd = [];
  function Dd(a, b) {
    var c = Ed;
    return !Cd.length || N(b, Bd)
      ? !0
      : G(
          function (d, e) {
            return d && e(a, c, b);
          },
          !0,
          Cd
        );
  }
  function Fd(a) {
    try {
      var b = a.document.cookie;
      if (!z(b)) {
        var c = {};
        L(function (d) {
          var e = n(d.split("="));
          d = e.next().value;
          e = e.next().value;
          d = wd(d);
          e = wd(rd(e));
          if (H(c, d)) {
            var f = c[d];
            w(f) ? f.push(e) : (c[d] = [f, e]);
          } else c[d] = e;
        }, (b || "").split(";"));
        return c;
      }
    } catch (d) {}
    return null;
  }
  var Gd = cd("gsc", Fd);
  function Ed(a, b, c) {
    a = Gd(a);
    if (!a || !H(a, b)) return null;
    b = a[b];
    if (!w(b)) return c ? [b] : b;
    if (c) return b;
    c = b[b.length - 1];
    return z(c) ? null : c;
  }
  var Hd = /:\d+$/;
  function Id(a, b, c, d, e, f, g) {
    g = void 0 === g ? !1 : g;
    if (Dd(a, b)) {
      c = b + "=" + encodeURIComponent(c) + ";";
      c += "" + md(a);
      if (d) {
        var h = new Date();
        h.setTime(h.getTime() + 6e4 * d);
        c += "expires=" + h.toUTCString() + ";";
      }
      e && ((d = e.replace(Hd, "")), (c += "domain=" + d + ";"));
      try {
        if (((a.document.cookie = c + ("path=" + (f || "/"))), !g)) {
          var k = Gd(a);
          if (k) {
            var l = Fd(a);
            l && (H(l, b) ? (k[b] = l[b]) : delete k[b]);
          }
        }
      } catch (m) {}
    }
  }
  var Jd = K(function (a) {
    var b = (R(a).host || "").split(".");
    return 1 === b.length
      ? b[0]
      : G(
          function (c, d, e) {
            e += 1;
            2 <= e &&
              !c &&
              ((e = T(".", b.slice(-e))),
              Id(a, "metrika_enabled", "1", 0, e, void 0, !0),
              (d = (d = Fd(a)) && d.metrika_enabled) &&
                Id(a, "metrika_enabled", "", -100, e, void 0, !0),
              d && (c = e));
            return c;
          },
          "",
          b
        );
  });
  function Kd(a, b, c) {
    b = void 0 === b ? "_ym_" : b;
    c = void 0 === c ? "" : c;
    var d = Jd(a),
      e = 1 === (d || "").split(".").length ? d : "." + d,
      f = c ? "_" + c : "";
    return {
      wa: function (g, h, k) {
        Id(a, "" + b + g + f, "", -100, h || e, k, !1);
        return this;
      },
      o: function (g, h) {
        return Ed(a, "" + b + g + f, h);
      },
      B: function (g, h, k, l, m) {
        Id(a, "" + b + g + f, h, k, l || e, m);
        return this;
      },
    };
  }
  var Ld = K(Kd),
    Md = K(function (a) {
      var b = Ld(a),
        c = "1" === b.o("debug"),
        d =
          -1 < Ca(R(a).href, "_ym_debug=1") ||
          -1 < Ca(R(a).href, "_ym_debug=2"),
        e = a._ym_debug;
      (!e && !d) || c || ((a = R(a)), b.B("debug", "1", void 0, a.host));
      return !!(c || e || d);
    });
  function Nd() {
    return {};
  }
  function Od() {
    return [];
  }
  var Pd = cd("debuggerEvents", Od, !0);
  function Qd(a, b) {
    if (Md(a)) {
      var c = b.counterKey;
      if (c) {
        var d = n(c.split(":"));
        c = d.next().value;
        d = d.next().value;
        c = dd(sb(c));
        if ("1" === d || c) return;
      }
      c = Pd(a);
      1e3 === c.length && c.shift();
      c.push(b);
    }
  }
  var Rd = sa.construct,
    Sd = sa.host,
    Td = [
      "http.0.st..rt.",
      "network error occurred",
      "send beacon",
      "Content Security Policy",
      "DOM Exception 18",
    ];
  function Ud(a) {
    throw a;
  }
  var Vd;
  function Wd(a) {
    this.message = a;
  }
  var Xd = (function (a) {
    return function (b, c) {
      c = void 0 === c ? !1 : c;
      if (Vd) var d = new Vd(b);
      else
        wa("Error", a.Error)
          ? ((Vd = a.Error), (d = new a.Error(b)))
          : ((Vd = Wd), (d = new Vd(b)));
      c && (d.unk = !0);
      return d;
    };
  })(window);
  function Yd(a) {
    return Xd(
      "http." +
        a.status +
        ".st." +
        a.statusText +
        ".rt." +
        ("" + a.responseText).substring(0, 50)
    );
  }
  var Zd = $a(RegExp("^http."));
  function $d(a) {
    var b = "";
    w(a) ? (b = T(".", a)) : u(a) && (b = a);
    return Xd("err.kn(2720)" + b);
  }
  function ae() {
    var a = Va(arguments);
    Ud($d(a));
  }
  var be = $a(RegExp("^err.kn"));
  function ce(a, b) {
    return b ? a(b) : a();
  }
  var de = M(lb, ce),
    ee = [];
  function fe(a, b, c, d) {
    L(M(lb, Jb([a, b, c, d]), ce), ee);
  }
  function ge(a, b, c) {
    var d = "u.a.e",
      e = "";
    c &&
      ("object" === typeof c
        ? (c.unk && Ud(c),
          (d = c.message),
          (e =
            ("string" === typeof c.stack && c.stack.replace(/\n/g, "\\n")) ||
            "n.s.e.s"))
        : (d = "" + c));
    be(d) ||
      sc(F(d, Ha), Td) ||
      (Zd(d) && 0.1 <= a.Math.random()) ||
      fe("jserrs", d, b, e);
  }
  function he(a) {
    return I(a, "performance") || I(a, "webkitPerformance");
  }
  function ie(a) {
    a = he(a);
    var b = I(a, "timing.navigationStart"),
      c = I(a, "now");
    c && (c = B(c, a));
    return [b, c];
  }
  function je(a, b) {
    var c = n(b || ie(a)),
      d = c.next().value;
    c = c.next().value;
    return !isNaN(d) && y(c)
      ? Math.round(c() + d)
      : a.Date.now
      ? a.Date.now()
      : new a.Date().getTime();
  }
  function ke() {
    var a = [];
    return {
      Ke: a,
      push: function () {
        var b = a.push.apply(a, ja(ra.apply(0, arguments)));
        100 < a.length && a.splice(0, a.length - 100);
        return b;
      },
      flush: function () {
        return a.splice(0, a.length);
      },
      slice: function (b, c) {
        return a.slice(b, c);
      },
    };
  }
  var le = ke(),
    me = 0,
    ne = 0;
  function oe(a, b, c, d) {
    return function () {
      me += 1;
      var e = null,
        f = null,
        g = he(c),
        h = g ? wa("now", g.now) : !1;
      try {
        var k = h ? g.now() : 0;
        f = a.apply(d || null, arguments);
        var l = h ? g.now() : 0;
        g = l - k;
        var m = me > ne;
        300 <= g &&
          m &&
          ((ne = me),
          0.001 > c.Math.random() && fe("perf", "t.l.300", b, "" + g));
        h && 50 <= g && le.push({ scope: b, startTime: k, endTime: l });
      } catch (p) {
        e = p;
      }
      --me;
      me < ne && (ne = me);
      e && Ud(e);
      return f;
    };
  }
  function U(a, b, c, d, e, f) {
    var g = c || Ud;
    c && f && (g = oe(g, b, a, e));
    return function () {
      var h = d;
      try {
        h = g.apply(e || null, arguments);
      } catch (k) {
        ge(a, b, k);
      }
      return h;
    };
  }
  function V(a, b, c) {
    return function () {
      return U(arguments[0], a, b, c).apply(this, arguments);
    };
  }
  var pe = Ma(function (a, b) {
      var c = b || {};
      return {
        l: F(c, lb),
        o: function (d, e) {
          var f = c[d];
          return Sa(f) && !Sa(e) ? e : f;
        },
        B: function (d, e) {
          c[d] = e;
          return this;
        },
        wb: function (d, e) {
          return "" === e || z(e) ? this : this.B(d, e);
        },
        ra: F(c, a),
      };
    }),
    qe = pe(function (a) {
      a = dc(a);
      return T(
        "",
        L(function (b) {
          var c = n(b);
          b = c.next().value;
          c = c.next().value;
          return Ra(c) ? "" : b + "(" + c + ")";
        }, a)
      );
    });
  function re(a, b, c) {
    c = void 0 === c ? null : c;
    a.ba || (a.ba = qe());
    b && a.ba.wb(b, c);
    return a.ba;
  }
  var se =
      "A B BIG BODY BUTTON DD DIV DL DT EM FIELDSET FORM H1 H2 H3 H4 H5 H6 HR I IMG INPUT LI OL P PRE SELECT SMALL SPAN STRONG SUB SUP TABLE TBODY TD TEXTAREA TFOOT TH THEAD TR U UL ABBR AREA BLOCKQUOTE CAPTION CENTER CITE CODE CANVAS DFN EMBED FONT INS KBD LEGEND LABEL MAP OBJECT Q S SAMP STRIKE TT ARTICLE AUDIO ASIDE FOOTER HEADER MENU METER NAV PROGRESS SECTION TIME VIDEO NOINDEX NOBR MAIN svg circle clippath ellipse defs foreignobject g glyph glyphref image line lineargradient marker mask path pattern polygon polyline radialgradient rect set text textpath title".split(
        " "
      ),
    te = [],
    ue = /^\s*(data|javascript):/i,
    ve = new RegExp(
      T("", [
        "\\.(" +
          T(
            "|",
            "3gp 7z aac ac3 acs ai avi ape apk asf bmp bz2 cab cdr crc32 css csv cue divx dmg djvu? doc(x|m|b)? emf eps exe flac? flv iso swf gif t?gz jpe?g? js m3u8? m4a mp(3|4|e?g?) m4v md5 mkv mov msi ods og(g|m|v) psd rar rss rtf sea sfv sit sha1 svg tar tif?f torrent ts txt vob wave? wma wmv wmf webm ppt(x|m|b)? xls(x|m|b)? pdf phps png xpi g?zip".split(
              " "
            )
          ) +
          ")$",
      ]),
      "i"
    ),
    we = {},
    xe =
      ((we.hit = "h"),
      (we.params = "p"),
      (we.reachGoal = "g"),
      (we.userParams = "up"),
      (we.trackHash = "th"),
      (we.accurateTrackBounce = "atb"),
      (we.notBounce = "nb"),
      (we.addFileExtension = "fe"),
      (we.extLink = "el"),
      (we.file = "fc"),
      (we.trackLinks = "tl"),
      (we.destruct = "d"),
      (we.setUserID = "ui"),
      (we.getClientID = "ci"),
      (we.clickmap = "cm"),
      we),
    ye = Oa("1");
  function ze(a, b, c, d) {
    var e = {};
    return A(a)
      ? a
      : ((e.id = a), (e.type = c), (e.defer = d), (e.params = b), e);
  }
  function Ae(a) {
    return G(
      function (b, c) {
        var d = n(c),
          e = d.next().value,
          f = d.next().value;
        d = f.rb;
        f = a[f.T];
        b[e] = d ? d(f) : f;
        return b;
      },
      {},
      dc(Be)
    );
  }
  var Ce = M(
      Q,
      K(function () {
        var a = 0;
        return function () {
          return (a += 1);
        };
      }),
      ce
    ),
    De = {
      mc: function (a) {
        a = bd(a).o("mt", {});
        a = dc(a);
        return a.length
          ? G(
              function (b, c, d) {
                var e = n(c);
                c = e.next().value;
                e = e.next().value;
                return "" + b + (d ? "-" : "") + c + "-" + e;
              },
              "",
              a
            )
          : null;
      },
      clc: function (a) {
        var b = P(a).o("cls", { fb: 0, x: 0, y: 0 }),
          c = b.fb,
          d = b.x;
        b = b.y;
        return c
          ? c + "-" + a.Math.floor(d / c) + "-" + a.Math.floor(b / c)
          : c + "-" + d + "-" + b;
      },
      rqnt: function (a, b, c) {
        a = c.D;
        return !a || a.nohit ? null : Ce(b);
      },
    };
  function Ee(a, b) {
    if (!b) return null;
    try {
      return a.JSON.parse(b);
    } catch (c) {
      return null;
    }
  }
  function Fe(a, b) {
    try {
      return a.JSON.stringify(b, null, void 0);
    } catch (c) {
      return null;
    }
  }
  function Ge(a) {
    try {
      return a.localStorage;
    } catch (b) {}
    return null;
  }
  function He(a, b) {
    var c = Ge(a);
    try {
      c.removeItem(b);
    } catch (d) {}
  }
  function Ie(a, b) {
    var c = Ge(a);
    try {
      return Ee(a, c.getItem(b));
    } catch (d) {}
    return null;
  }
  function Je(a, b, c) {
    var d = Ge(a);
    a = Fe(a, c);
    if (!Ra(a))
      try {
        d.setItem(b, a);
      } catch (e) {}
  }
  var Ke = K(function (a) {
    Je(a, "_ymBRC", "1");
    var b = "1" !== Ie(a, "_ymBRC");
    b || He(a, "_ymBRC");
    return b;
  });
  function Le(a, b, c) {
    var d = "" + (void 0 === c ? "_ym" : c) + (void 0 === b ? "" : b);
    d && (d += "_");
    return {
      Lb: Ke(a),
      o: function (e, f) {
        var g = Ie(a, "" + d + e);
        return Ra(g) && !Sa(f) ? f : g;
      },
      B: function (e, f) {
        Je(a, "" + d + e, f);
        return this;
      },
      wa: function (e) {
        He(a, "" + d + e);
        return this;
      },
    };
  }
  var Me = K(Le),
    Ne = K(Le, function (a, b, c) {
      return "" + b + c;
    }),
    Oe = xa(Array.prototype.find, "find");
  function Pe(a, b) {
    for (var c = 0; c < b.length; c += 1) if (a.call(b, b[c], c)) return b[c];
  }
  var Qe = Oe
    ? function (a, b) {
        return Oe.call(b, a);
      }
    : Pe;
  function Re(a) {
    if (z(a)) return !1;
    a = a.nodeType;
    return 3 === a || 8 === a;
  }
  function Se(a) {
    return a ? a.innerText || "" : "";
  }
  var Te = K(function (a) {
      a = I(a, "document") || {};
      return ("" + (a.characterSet || a.charset || "")).toLowerCase();
    }),
    Ue = K(M(J("document"), F("createElement", zb)));
  function Ve(a) {
    var b = a && a.parentNode;
    b && b.removeChild(a);
  }
  function We(a, b) {
    var c;
    try {
      if ((c = b.target || b.srcElement))
        !c.ownerDocument && c.documentElement
          ? (c = c.documentElement)
          : c.ownerDocument !== a.document && (c = null);
    } catch (d) {}
    return c;
  }
  function Xe(a, b) {
    try {
      return new RegExp("(?:^|\\s)" + a + "(?:\\s|$)").test(b.className);
    } catch (c) {
      return !1;
    }
  }
  var Ye = K(function (a) {
    var b = I(a, "Element.prototype");
    return b
      ? (a = Qe(
          function (c) {
            var d = b[c];
            return !!d && wa(c, d);
          },
          [
            "matches",
            "webkitMatchesSelector",
            "mozMatchesSelector",
            "msMatchesSelector",
            "oMatchesSelector",
          ]
        ))
        ? b[a]
        : null
      : null;
  });
  function Ze(a) {
    a = I(a, "document");
    try {
      return a.getElementsByTagName("body")[0];
    } catch (b) {
      return null;
    }
  }
  function $e(a) {
    var b = I(a, "document") || {},
      c = b.documentElement;
    return "CSS1Compat" === b.compatMode ? c : Ze(a) || c;
  }
  function af(a) {
    var b = I(a, "visualViewport.width"),
      c = I(a, "visualViewport.height");
    a = I(a, "visualViewport.scale");
    return z(b) || z(c) ? null : [Math.floor(b), Math.floor(c), a];
  }
  function bf(a) {
    var b = af(a);
    if (b) {
      var c = n(b);
      b = c.next().value;
      var d = c.next().value;
      c = c.next().value;
      return [a.Math.round(b * c), a.Math.round(d * c)];
    }
    b = $e(a);
    return [
      I(b, "clientWidth") || a.innerWidth,
      I(b, "clientHeight") || a.innerHeight,
    ];
  }
  function cf(a) {
    var b = Ze(a),
      c = I(a, "document");
    return {
      x:
        a.pageXOffset ||
        (c.documentElement && c.documentElement.scrollLeft) ||
        (b && b.scrollLeft) ||
        0,
      y:
        a.pageYOffset ||
        (c.documentElement && c.documentElement.scrollTop) ||
        (b && b.scrollTop) ||
        0,
    };
  }
  function df(a) {
    var b = $e(a),
      c = n(bf(a));
    a = c.next().value;
    c = c.next().value;
    return [Math.max(b.scrollWidth, a), Math.max(b.scrollHeight, c)];
  }
  function ef(a) {
    try {
      return a.getBoundingClientRect && a.getBoundingClientRect();
    } catch (b) {
      return (
        (a = b),
        "object" === typeof a && null !== a && 16389 === (a.ee && a.ee & 65535)
          ? { top: 0, bottom: 0, left: 0, width: 0, height: 0, right: 0 }
          : null
      );
    }
  }
  function ff(a, b, c) {
    c = zb("dispatchEvent", c || a.document);
    var d = null,
      e = I(a, "Event.prototype.constructor");
    if (
      e &&
      (wa("(Event|Object|constructor)", e) ||
        (Fc(a) && "[object Event]" === "" + e))
    )
      try {
        d = new a.Event(b);
      } catch (f) {
        if ((a = zb("createEvent", I(a, "document"))) && y(a)) {
          try {
            d = a(b);
          } catch (g) {}
          d && d.initEvent && d.initEvent(b, !1, !1);
        }
      }
    d && c(d);
  }
  function gf(a) {
    if (a)
      try {
        var b = a.nodeName;
        if (u(b)) return b;
        b = a.tagName;
        if (u(b)) return b;
      } catch (c) {}
  }
  var hf = Oa("INPUT"),
    jf = M(gf, hf);
  function kf(a, b, c) {
    var d = Sa(c);
    Sa(b) && d ? ((d = 1), (b = 1073741824)) : d ? (d = 1) : ((d = b), (b = c));
    return a.Math.floor(a.Math.random() * (b - d)) + d;
  }
  function lf(a) {
    return (10 > a ? "0" : "") + a;
  }
  function mf(a) {
    var b = a.kc;
    return 0 !== b ? b : je(a.l, a.sb);
  }
  function nf(a) {
    return Math.floor(mf(a) / 1e3 / 60);
  }
  function of(a) {
    return Math.round(mf(a) / 1e3);
  }
  function pf(a) {
    var b = n(a.sb),
      c = b.next().value;
    b = b.next().value;
    a = c && b ? b() : mf(a) - a.kb;
    return Math.round(a);
  }
  var W = K(function (a) {
      var b = Xc(a),
        c = ie(a),
        d = { l: a, kc: 0, sb: c, kb: je(a, c) },
        e = n(c);
      c = e.next().value;
      e = e.next().value;
      (c && e) ||
        b.C(a, ["beforeunload", "unload"], function () {
          0 === d.kc && (d.kc = je(a, d.sb));
        });
      return Qa(d);
    }),
    qf = /\/$/;
  function rf(a) {
    var b = P(a),
      c = b.o("hitId");
    c || ((c = kf(a)), b.B("hitId", c));
    return c;
  }
  function sf(a, b) {
    var c = Me(a),
      d = Ld(a),
      e = b.Qb || "uid";
    return [c.o(e), d.o(e)];
  }
  var tf = cd("r", function (a, b) {
    var c = n(sf(a, b)),
      d = c.next().value;
    return !c.next().value && d;
  });
  function uf(a, b) {
    return !b.Aa && tf(a, b);
  }
  function vf(a, b) {
    var c = b.Qb,
      d = c || "uid";
    c = c ? a.location.hostname : void 0;
    var e = Ld(a),
      f = Me(a),
      g = W(a)(of),
      h = n(sf(a, b)),
      k = h.next().value;
    h = h.next().value;
    var l = e.o("d");
    tf(a, b);
    var m = !1;
    !h && k && ((h = k), (m = !0));
    if (!h) (h = T("", [g, kf(a, 1e6, 999999999)])), (m = !0);
    else if (!l || 15768e3 < g - ub(l)) m = !0;
    m && !b.Aa && (e.B(d, h, 525600, c), e.B("d", "" + g, 525600, c));
    f.B(d, h);
    return h;
  }
  function wf(a, b, c) {
    return zb("setTimeout", a)(b, c);
  }
  function xf(a, b) {
    return zb("clearTimeout", a)(b);
  }
  function yf(a, b, c, d) {
    return wf(a, U(a, d + ".d.err", b), c);
  }
  function zf(a, b, c, d) {
    return a.setInterval(U(a, d + ".i.err", b), c);
  }
  function Af(a, b) {
    return a.clearInterval(b);
  }
  function Bf(a, b) {
    return function (c) {
      return c(a, b);
    };
  }
  var Cf = Ma(function (a, b) {
    return Qa(function (c, d) {
      return b(c, function (e) {
        try {
          a(e)(Bf(c, d));
        } catch (f) {
          c(f);
        }
      });
    });
  });
  function Df(a) {
    return Qa(function (b, c) {
      a.then(c, b);
    });
  }
  function Ef(a) {
    return Qa(function (b, c) {
      c(a);
    });
  }
  function Ff(a, b) {
    function c(f) {
      I(d, e) && (d.nodeType ? d.src === I(d, "contentDocument.URL") : 1)
        ? f()
        : yf(a, F(f, c), 100, b + ".wfb");
    }
    var d = void 0 === d ? a : d;
    var e = (d.nodeType ? "contentWindow." : "") + "document.body";
    return Qa(function (f, g) {
      c(g);
    });
  }
  function Gf(a) {
    var b = [],
      c = { ae: b };
    c.C = M(Za("push", b), F(c, lb));
    c.qa = M(Na(ib(a))(b), Na(Za("splice", b))(1), F(c, lb));
    c.trigger = M(lb, Na(ce), Ib(b));
    return c;
  }
  function Hf(a, b) {
    var c = {};
    return {
      C: function (d, e) {
        L(function (f) {
          I(c, f) || (c[f] = Gf(a));
          c[f].C(e);
        }, d);
        return this;
      },
      qa: function (d, e) {
        L(function (f) {
          I(c, f) && c[f].qa(e);
        }, d);
        return this;
      },
      trigger: function (d, e) {
        return I(c, d) ? U(a, b + ".emt." + d, c[d].trigger, [])(e) : [];
      },
    };
  }
  var If = K(function () {
      return { ga: {}, pending: {}, children: {} };
    }),
    Jf = J("postMessage");
  function Kf(a, b) {
    return function (c, d) {
      var e = W(a)(mf),
        f;
      if ((f = a.crypto && xa(a.crypto.getRandomValues, "getRandomValues"))) {
        var g = new Uint32Array(1);
        f.call(a.crypto, g);
        f = g[0] / 4294967296;
      } else f = a.Math.random();
      e = { Cb: e, key: f, dir: 0 };
      c.length &&
        ((e.Cb = ub(c[0])), (e.key = parseFloat(c[1])), (e.dir = ub(c[2])));
      O(d, b);
      f = {};
      f =
        ((f.data = d),
        (f.__yminfo = T(":", ["__yminfo", e.Cb, e.key, e.dir])),
        f);
      return { oa: e, hd: Fe(a, f) || "" };
    };
  }
  var Lf = V("s.f", function (a, b, c, d, e) {
    b = b(d);
    var f = If(a),
      g = T(":", [b.oa.Cb, b.oa.key]);
    if (Jf(c)) {
      f.pending[g] = e;
      try {
        c.postMessage(b.hd, "*");
      } catch (h) {
        delete f.pending[g];
        return;
      }
      yf(
        a,
        function () {
          delete f.pending[g];
        },
        5e3,
        "if.s"
      );
    }
  });
  function Mf(a) {
    if (wa("MutationObserver", a.MutationObserver)) {
      var b = If(a).children,
        c = new a.MutationObserver(function () {
          L(function (d) {
            I(b[d], "window.window") || delete b[d];
          }, ec(b));
        });
      Ff(
        a,
        "if.wf"
      )(
        Bf(r, function () {
          c.observe(a.document.body, { subtree: !0, childList: !0 });
        })
      );
    }
  }
  function Nf(a, b) {
    var c = If(a);
    b.C(["initToParent"], function (d) {
      var e = n(d);
      d = e.next().value;
      e = e.next().value;
      window.window &&
        (c.children[e.counterId] = { info: e, window: d.source });
    })
      .C(["initToChild"], function (d) {
        var e = n(d);
        d = e.next().value;
        e = e.next().value;
        d.source === a.parent && b.trigger("parentConnect", [d, e]);
      })
      .C(["parentConnect"], function (d) {
        var e = n(d);
        d = e.next().value;
        e = e.next().value;
        e.counterId && (c.ga[e.counterId] = { info: e, window: d.source });
      });
  }
  var Of = V("s.fh", function (a, b, c, d, e, f) {
      var g = null,
        h = null,
        k = If(a),
        l = null;
      try {
        (g = Ee(a, f.data)), (h = g.__yminfo), (l = g.data);
      } catch (m) {
        return;
      }
      if (
        !z(h) &&
        h.substring &&
        "__yminfo" === h.substring(0, 8) &&
        !z(l) &&
        ((a = h.split(":")), 4 === a.length)
      )
        if (
          ((g = b.id),
          (h = n(a)),
          h.next(),
          (b = h.next().value),
          (a = h.next().value),
          (h = h.next().value),
          !w(l) && l.type && "0" === h && l.counterId)
        ) {
          if (!l.toCounter || l.toCounter == g) {
            k = null;
            try {
              k = f.source;
            } catch (m) {}
            !Ra(k) &&
              Jf(k) &&
              ((f = d.trigger(l.type, [f, l])),
              (e = L(M(lb, jc(e)), f.concat([void 0]))),
              (l = c([b, a, l.counterId], e)),
              k.postMessage(l.hd, "*"));
          }
        } else
          h === "" + g &&
            w(l) &&
            Qb(function (m) {
              return !(!m.hid || !m.counterId);
            }, l).length === l.length &&
            (c = k.pending[T(":", [b, a])]) &&
            c.apply(null, [f].concat(l));
    }),
    Pf = K(function (a, b) {
      var c = zb("getElementsByTagName", I(a, "document")),
        d = If(a),
        e = Jf(a),
        f = Hf(a, "ifc"),
        g = Xc(a);
      if (!c || !e) return null;
      c = c.call(a.document, "iframe");
      e = {};
      e = ((e.counterId = b.id), (e.hid = "" + rf(a)), e);
      Sc(a) && (e.duid = vf(a, b));
      Nf(a, f);
      Mf(a);
      var h = Kf(a, e),
        k = D([a, F([], h)], Lf);
      L(function (l) {
        var m = null;
        try {
          m = l.contentWindow;
        } catch (p) {}
        m &&
          k(m, { type: "initToChild" }, function (p, q) {
            f.trigger("initToParent", [p, q]);
          });
      }, c);
      Ic(a) &&
        k(a.parent, { type: "initToParent" }, function (l, m) {
          f.trigger("parentConnect", [l, m]);
        });
      g.C(a, ["message"], D([a, b, h, f, e], Of));
      return { ca: f, ga: d.ga, children: d.children, bc: k };
    }, M(mb, Q)),
    Qf = K(
      function (a, b) {
        if (!Sc(a) || !Ic(a)) return vf(a, b);
        var c = Pf(a, b);
        return c && c.ga[b.id] ? c.ga[b.id].info.duid || vf(a, b) : vf(a, b);
      },
      function (a, b) {
        return "" + b.Qb + b.Aa;
      }
    ),
    Rf = K(
      M(
        W,
        Qa(function (a) {
          return -new a.l.Date().getTimezoneOffset();
        })
      )
    ),
    Sf = M(
      W,
      Qa(function (a) {
        a = new a.l.Date();
        return T(
          "",
          L(lf, [
            a.getFullYear(),
            a.getMonth() + 1,
            a.getDate(),
            a.getHours(),
            a.getMinutes(),
            a.getSeconds(),
          ])
        );
      })
    ),
    Tf = M(W, Qa(of)),
    Uf = M(W, Qa(mf)),
    Vf = K(
      M(
        W,
        Qa(function (a) {
          return n(a.sb).next().value;
        })
      )
    ),
    Wf = K(function (a) {
      a = P(a);
      var b = a.o("counterNum", 0) + 1;
      a.B("counterNum", b);
      return b;
    }, M(mb, Q)),
    Xf = {},
    Yf =
      ((Xf.vf = F(sa.version, lb)),
      (Xf.nt = Ec),
      (Xf.fu = function (a, b, c) {
        var d = c.D;
        if (!d) return null;
        b = (I(a, "document.referrer") || "").replace(qf, "");
        c = (d["page-ref"] || "").replace(qf, "");
        d = d["page-url"];
        a = R(a).href !== d;
        b = b !== c;
        c = 0;
        a && b ? (c = 3) : b ? (c = 1) : a && (c = 2);
        return c;
      }),
      (Xf.en = Te),
      (Xf.la = Gc),
      (Xf.ut = function (a, b, c) {
        var d = c.H;
        c = c.D;
        d = d && d.qb;
        c && (kd(a) || b.oc || d) && (c.ut = "noindex");
        return null;
      }),
      (Xf.v = F("2720", lb)),
      (Xf.cn = Wf),
      (Xf.dp = function (a) {
        var b = P(a),
          c = b.o("bt", {});
        if (Sa(b.o("bt"))) {
          var d = I(a, "navigator.getBattery");
          try {
            c.p = d && d.call(a.navigator);
          } catch (e) {}
          b.B("bt", c);
          c.p &&
            c.p.then &&
            c.p.then(
              U(a, "bi:dp.p", function (e) {
                c.De = I(e, "charging") && 0 === I(e, "chargingTime");
              })
            );
        }
        return Mb(c.De);
      }),
      (Xf.ls = K(function (a, b) {
        var c = Ne(a, b.id),
          d = W(a),
          e = c.o("lsid");
        return +e ? e : ((d = kf(a, 0, d(mf))), c.B("lsid", d), d);
      }, mb)),
      (Xf.hid = rf),
      (Xf.phid = function (a, b) {
        if (!Ic(a)) return null;
        var c = Pf(a, b);
        if (!c) return null;
        var d = ec(c.ga);
        return d.length ? c.ga[d[0]].info.hid : null;
      }),
      (Xf.z = Rf),
      (Xf.i = Sf),
      (Xf.et = Tf),
      (Xf.etms = Uf),
      (Xf.c = M(J("navigator.cookieEnabled"), Lb)),
      (Xf.rn = M(lb, kf)),
      (Xf.rqn = function (a, b, c) {
        c = c.D;
        if (!c || c.nohit) return null;
        b = Q(b);
        a = Ne(a, b);
        b = (a.o("reqNum", 0) || 0) + 1;
        a.B("reqNum", b);
        if (a.o("reqNum") === b) return b;
        a.wa("reqNum");
        return null;
      }),
      (Xf.u = Qf),
      (Xf.w = function (a) {
        var b = n(bf(a));
        a = b.next().value;
        b = b.next().value;
        return a + "x" + b;
      }),
      (Xf.s = function (a) {
        return (a = I(a, "screen"))
          ? T("x", [
              I(a, "width"),
              I(a, "height"),
              I(a, "colorDepth") || I(a, "pixelDepth"),
            ])
          : null;
      }),
      (Xf.sk = J("devicePixelRatio")),
      (Xf.ifr = M(Ic, Lb)),
      (Xf.j = M(Kc, Lb)),
      (Xf.sti = function (a) {
        return Ic(a) && Jc(a) ? "1" : null;
      }),
      Xf),
    Zf = K(function () {
      return ad(ec(Yf), ec(De));
    });
  function $f(a) {
    return function (b, c) {
      return {
        K: function (d, e) {
          var f = d.G,
            g = d.D;
          f &&
            g &&
            L(function (h) {
              var k = Yf[h],
                l = "bi",
                m = f;
              k || ((k = De[h]), (l = "tel"), (m = re(d)));
              k && ((k = V(l + ":" + h, k, null)(b, c, d)), m.wb(h, k));
            }, a || Zf());
          e();
        },
      };
    };
  }
  function ag(a, b) {
    return {
      K: function (c, d) {
        var e = c.G;
        if (e && (!b || b.Zc)) {
          var f = a.document.title;
          c.H && c.H.title && (f = c.H.title);
          var g = zb("getElementsByTagName", a.document);
          "string" !== typeof f &&
            g &&
            ((f = g("title")), (f = (f = I(f, "0.innerHtml")) ? f : ""));
          f = f.slice(0, Fc(a) ? 100 : 400);
          e.B("t", f);
        }
        d();
      },
    };
  }
  var bg = K(Nd, Q);
  function cg(a, b, c) {
    if (Sc(a) && Ic(a)) {
      var d = bg(b);
      if (!d.Xd) {
        d.Xd = !0;
        b = Pf(a, b);
        if (!b) {
          c();
          return;
        }
        d.Y = [];
        var e = function () {
          d.Y && (L(ce, d.Y), (d.Y = null));
        };
        yf(a, e, 3e3, "w.p.d.p");
        b.ca.C(["initToChild"], e);
      }
      d.Y ? d.Y.push(c) : c();
    } else c();
  }
  var dg = K(function () {
    return { Gc: null, Y: [] };
  }, Q);
  function eg(a) {
    return (a = a.G) && a.o("pv") && !a.o("ar");
  }
  function fg(a, b, c) {
    var d = a.G;
    d ? (eg(a) ? ((b.Gc = d), c()) : b.Y ? b.Y.push(c) : c()) : c();
  }
  function gg(a, b) {
    return {
      K: function (c, d) {
        var e = dg(b);
        e = D([c, e, d], fg);
        cg(a, b, e);
      },
      S: function (c, d) {
        var e = c.G,
          f = dg(b);
        if (e) {
          var g = f.Y;
          f.Gc === e && g && (L(ce, g), (f.Y = null));
        }
        d();
      },
    };
  }
  var hg = /^[a-z][\w.+-]+:/i;
  function ig(a, b) {
    var c = R(a),
      d = c.href,
      e = c.host,
      f = -1;
    if (!u(b) || Sa(b)) return d;
    c = b.replace(ud, "");
    if (-1 !== c.search(hg)) return c;
    var g = c.charAt(0);
    if (
      ("?" === g && ((f = d.search(/\?/)), -1 === f)) ||
      ("#" === g && ((f = d.search(/#/)), -1 === f))
    )
      return d + c;
    if (-1 !== f) return d.substr(0, f) + c;
    if ("/" === g) {
      if (((f = Ba(d, e)), -1 !== f)) return d.substr(0, f + e.length) + c;
    } else return (d = d.split("/")), (d[d.length - 1] = c), T("/", d);
    return "";
  }
  function jg(a) {
    return {
      K: function (b, c) {
        var d = b.D;
        if (!b.G || !d) return c();
        var e = d["page-ref"],
          f = d["page-url"];
        e && f !== e ? (d["page-ref"] = ig(a, e)) : delete d["page-ref"];
        e = Fc(a) ? 512 : 2048;
        d["page-url"] = ig(a, f).slice(0, e);
        return c();
      },
    };
  }
  function kg(a, b, c) {
    for (var d = [b, c], e = -1e4, f = 0; f < a.length; f += 1) {
      var g = n(a[f]),
        h = g.next().value;
      g = g.next().value;
      if (c === g && h === b) return;
      if (c < g && c >= e) {
        a.splice(f, 0, d);
        return;
      }
      e = g;
    }
    a.push(d);
  }
  var lg = [
      [jg, -100],
      [$c, 1],
      [gg, 2],
      [$f(), 3],
      [ag, 4],
    ],
    mg = lg.slice(),
    ng = [],
    og = F(lg, kg),
    pg = {},
    qg = ((pg.h = mg), pg),
    X = F(qg, function (a, b, c, d) {
      a[b] || (a[b] = []);
      c && !z(d) && kg(a[b], c, d);
    });
  function rg(a, b, c) {
    b = w(b) ? b : qg[b] || lg;
    var d = L(oc, b);
    L(function (e) {
      return d.unshift(e);
    }, ng);
    return L(M(Jb([a, c]), ce), d);
  }
  var sg = [],
    tg = [],
    ug = [],
    vg = [],
    wg = [],
    xg = [],
    yg = setTimeout;
  function zg() {}
  function Ag(a, b) {
    return function () {
      a.apply(b, arguments);
    };
  }
  function Bg(a) {
    if (!(this instanceof Bg))
      throw new TypeError("Promises must be constructed via new");
    if ("function" !== typeof a) throw new TypeError("not a function");
    this.ia = 0;
    this.rc = !1;
    this.va = void 0;
    this.Oa = [];
    Cg(a, this);
  }
  function Dg(a, b) {
    for (; 3 === a.ia; ) a = a.va;
    0 === a.ia
      ? a.Oa.push(b)
      : ((a.rc = !0),
        Bg.sc(function () {
          var c = 1 === a.ia ? b.ge : b.ie;
          if (null === c) (1 === a.ia ? Eg : Fg)(b.promise, a.va);
          else {
            try {
              var d = c(a.va);
            } catch (e) {
              Fg(b.promise, e);
              return;
            }
            Eg(b.promise, d);
          }
        }));
  }
  function Eg(a, b) {
    try {
      if (b === a)
        throw new TypeError("A promise cannot be resolved with itself.");
      if (b && ("object" === typeof b || "function" === typeof b)) {
        var c = b.then;
        if (b instanceof Bg) {
          a.ia = 3;
          a.va = b;
          Gg(a);
          return;
        }
        if ("function" === typeof c) {
          Cg(Ag(c, b), a);
          return;
        }
      }
      a.ia = 1;
      a.va = b;
      Gg(a);
    } catch (d) {
      Fg(a, d);
    }
  }
  function Fg(a, b) {
    a.ia = 2;
    a.va = b;
    Gg(a);
  }
  function Gg(a) {
    2 === a.ia &&
      0 === a.Oa.length &&
      Bg.sc(function () {
        a.rc || Bg.zd(a.va);
      });
    for (var b = 0, c = a.Oa.length; b < c; b++) Dg(a, a.Oa[b]);
    a.Oa = null;
  }
  function Hg(a, b, c) {
    this.ge = "function" === typeof a ? a : null;
    this.ie = "function" === typeof b ? b : null;
    this.promise = c;
  }
  function Cg(a, b) {
    var c = !1;
    try {
      a(
        function (d) {
          c || ((c = !0), Eg(b, d));
        },
        function (d) {
          c || ((c = !0), Fg(b, d));
        }
      );
    } catch (d) {
      c || ((c = !0), Fg(b, d));
    }
  }
  Bg.prototype["catch"] = function (a) {
    return this.then(null, a);
  };
  Bg.prototype.then = function (a, b) {
    var c = new this.constructor(zg);
    Dg(this, new Hg(a, b, c));
    return c;
  };
  Bg.prototype["finally"] = function (a) {
    var b = this.constructor;
    return this.then(
      function (c) {
        return b.resolve(a()).then(function () {
          return c;
        });
      },
      function (c) {
        return b.resolve(a()).then(function () {
          return b.reject(c);
        });
      }
    );
  };
  Bg.all = function (a) {
    return new Bg(function (b, c) {
      function d(h, k) {
        try {
          if (k && ("object" === typeof k || "function" === typeof k)) {
            var l = k.then;
            if ("function" === typeof l) {
              l.call(
                k,
                function (m) {
                  d(h, m);
                },
                c
              );
              return;
            }
          }
          e[h] = k;
          0 === --f && b(e);
        } catch (m) {
          c(m);
        }
      }
      if (!a || "undefined" === typeof a.length)
        return c(new TypeError("Promise.all accepts an array"));
      var e = Array.prototype.slice.call(a);
      if (0 === e.length) return b([]);
      for (var f = e.length, g = 0; g < e.length; g++) d(g, e[g]);
    });
  };
  Bg.resolve = function (a) {
    return a && "object" === typeof a && a.constructor === Bg
      ? a
      : new Bg(function (b) {
          b(a);
        });
  };
  Bg.reject = function (a) {
    return new Bg(function (b, c) {
      c(a);
    });
  };
  Bg.race = function (a) {
    return new Bg(function (b, c) {
      if (!a || "undefined" === typeof a.length)
        return c(new TypeError("Promise.race accepts an array"));
      for (var d = 0, e = a.length; d < e; d++) Bg.resolve(a[d]).then(b, c);
    });
  };
  Bg.sc =
    ("function" === typeof setImmediate &&
      function (a) {
        setImmediate(a);
      }) ||
    function (a) {
      yg(a, 0);
    };
  Bg.zd = function (a) {
    "undefined" !== typeof console &&
      console &&
      console.warn("Possible Unhandled Promise Rejection:", a);
  };
  var Y = window.Promise,
    Ig = xa(Y, "Promise"),
    Jg = xa(I(Y, "resolve"), "resolve"),
    Kg = xa(I(Y, "reject"), "reject"),
    Lg = xa(I(Y, "all"), "all");
  if (Ig && Jg && Kg && Lg) {
    var Mg = function (a) {
      return new Promise(a);
    };
    Mg.resolve = B(Jg, Y);
    Mg.reject = B(Kg, Y);
    Mg.all = B(Lg, Y);
    Y = Mg;
  } else Y = Bg;
  function Ng(a) {
    return a.dc || a.za.length <= a.$;
  }
  function Og(a) {
    a.$ = a.za.length;
  }
  function Pg(a) {
    a.dc = !0;
  }
  function Qg(a) {
    a.dc = !1;
  }
  function Rg(a) {
    Ng(a) && Ud(Xd("i"));
    var b = a.Ob(a.za[a.$]);
    a.$ += 1;
    return b;
  }
  var Sg = Ma(function (a, b) {
      for (var c = []; !Ng(b); ) {
        var d = Rg(b);
        a(d, function (e) {
          return e(b);
        });
        c.push(d);
      }
      return c;
    }),
    Tg = Ma(function (a, b) {
      for (var c; b.za.length && !Ng(b); )
        (c = b.za.pop()), (c = b.Ob(c, b.za)), a(b);
      return c;
    });
  function Ug(a, b) {
    return function (c) {
      var d = W(a),
        e = d(mf);
      return Tg(function (f) {
        d(mf) - e >= b && Pg(f);
      })(c);
    };
  }
  function Vg(a, b) {
    return function (c) {
      var d = W(a),
        e = d(mf);
      return Sg(function (f, g) {
        d(mf) - e >= b && g(Pg);
      })(c);
    };
  }
  function Wg(a) {
    for (var b = !0, c = {}; !Ng(a) && b; c = { Vb: void 0 })
      (b = !1),
        (c.Vb = function () {
          b = !0;
          a.$ += 1;
        }),
        a.Ob(
          a.za[a.$],
          (function (d) {
            return function () {
              (0, d.Vb)();
            };
          })(c)
        ),
        b || ((a.$ += 1), (c.Vb = F(a, Wg)));
  }
  function Xg(a, b) {
    return Qa({ za: a, Ob: b || lb, dc: !1, $: 0 });
  }
  function Yg(a, b, c) {
    c = void 0 === c ? !1 : c;
    return new Y(function (d, e) {
      function f(k, l) {
        l();
        d();
      }
      var g = a.slice();
      g.push({ K: f, S: f });
      var h = Xg(g, function (k, l) {
        var m = c ? k.K : k.S;
        if (m)
          try {
            m(b, l);
          } catch (p) {
            h(Og), e(p);
          }
        else l();
      });
      h(Wg);
    });
  }
  function Zg(a, b, c) {
    var d = kf(a),
      e = c.N,
      f = c.O,
      g = c.Ca,
      h = c.Da;
    c = c.ab;
    var k = {},
      l = {},
      m = {};
    Qd(
      a,
      ((m.name = "request"),
      (m.data =
        ((l.url = b),
        (l.requestId = d),
        (l.senderParams =
          ((k.rBody = f),
          (k.debugStack = e),
          (k.rHeaders = g),
          (k.rQuery = h),
          (k.verb = c),
          k)),
        l)),
      m)
    );
    return d;
  }
  var $g = pe(function (a) {
    var b = "";
    a = G(
      function (c, d) {
        var e = n(d),
          f = e.next().value;
        e = e.next().value;
        e = "" + f + ":" + e;
        "t" === f ? (b = e) : c.push(e);
        return c;
      },
      [],
      dc(a)
    );
    b && a.push(b);
    return T(":", a);
  });
  function ah(a, b, c) {
    var d = O({}, b.D);
    a = W(a);
    b.G && (d["browser-info"] = $g(b.G.l()).B("st", a(of)).ra());
    !d.t && (b = b.ba) && (b.B("ti", c), (d.t = b.ra()));
    return d;
  }
  function bh(a, b, c, d, e, f) {
    e = void 0 === e ? 0 : e;
    f = void 0 === f ? 0 : f;
    var g = O({ N: [] }, d.J),
      h = n(b[f]),
      k = h.next().value;
    h = h.next().value;
    var l = c[e];
    if ((!g.Ca || !g.Ca["Content-Type"]) && g.O) {
      var m = {};
      g.Ca = O(
        {},
        g.Ca,
        ((m["Content-Type"] = "application/x-www-form-urlencoded"), m)
      );
      g.O = "site-info=" + qd(g.O);
    }
    g.ab || (g.ab = g.O ? "POST" : "GET");
    g.Da = ah(a, d, k);
    g.U = (d.ha || {}).U;
    g.N.push(k);
    O(d.J, g);
    k = "" + l + (d.ub && d.ub.de ? "/1" : "");
    var p = 0;
    p = Zg(a, k, g);
    return h(k, g)
      .then(function (q) {
        var v = p,
          t = {},
          x = {};
        Qd(
          a,
          ((x.name = "requestSuccess"),
          (x.data = ((t.body = q), (t.requestId = v), t)),
          x)
        );
        return { Ea: q, rd: e };
      })
      ["catch"](function (q) {
        var v = p,
          t = {},
          x = {};
        Qd(
          a,
          ((x.name = "requestFail"),
          (x.data = ((t.error = q), (t.requestId = v), t)),
          x)
        );
        v = f + 1 >= b.length;
        t = e + 1 >= c.length;
        v && t && Ud(q);
        return bh(a, b, c, d, !t && v ? e + 1 : e, v ? 0 : f + 1);
      });
  }
  function ch(a, b) {
    return function (c, d) {
      return bh(a, b, d, c);
    };
  }
  var dh = {
      id: "id",
      oc: "ut",
      M: "type",
      Qb: "ldc",
      Aa: "nck",
      Ga: "url",
      Hb: "referrer",
    },
    eh = /^\d+$/,
    fh = {
      id: function (a) {
        a = "" + (a || "0");
        eh.test(a) || (a = "0");
        try {
          var b = ub(a);
        } catch (c) {
          b = 0;
        }
        return b;
      },
      M: function (a) {
        return "" + (a || 0 === a ? a : "0");
      },
      Aa: Nb,
      oc: Nb,
    };
  dh.Ra = "defer";
  fh.Ra = Nb;
  dh.L = "params";
  fh.L = function (a) {
    return A(a) || w(a) ? a : null;
  };
  dh.nc = "userParams";
  dh.nd = "triggerEvent";
  fh.nd = Nb;
  dh.Zc = "sendTitle";
  fh.Zc = function (a) {
    return !!a || Sa(a);
  };
  dh.hc = "trackHash";
  fh.hc = Nb;
  dh.md = "trackLinks";
  var Be = G(
    function (a, b) {
      var c = n(b),
        d = c.next().value;
      c = c.next().value;
      a[d] = { T: c, rb: fh[d] };
      return a;
    },
    {},
    dc(dh)
  );
  function gh(a) {
    return G(
      function (b, c) {
        var d = n(c),
          e = d.next().value;
        d = d.next().value;
        b[Be[e].T] = d;
        return b;
      },
      {},
      dc(a)
    );
  }
  var hh = {},
    ih =
      ((hh.w = [
        [
          function (a, b) {
            return {
              K: function (c, d) {
                var e = c.D,
                  f = {};
                e =
                  ((f["page-url"] = (e && e["page-url"]) || ""),
                  (f.charset = "utf-8"),
                  f);
                "0" !== b.M && (e["cnt-class"] = b.M);
                c.G || (c.G = $g());
                f = c.G;
                e = {
                  ha: { U: "watch/" + b.id },
                  J: O(void 0 === c.J ? {} : c.J, {
                    Fa: !!f.o("pv") && !f.o("wh"),
                  }),
                  D: O(c.D || {}, e),
                };
                O(c, e);
                d();
              },
            };
          },
          1,
        ],
      ]),
      hh);
  function jh(a, b, c) {
    var d = ch(a, b);
    return function (e) {
      return Yg(c, e, !0)
        .then(function () {
          var f = e.ha || {},
            g = void 0 === f.Ud ? "" : f.Ud,
            h = void 0 === f.U ? "" : f.U;
          f = L(
            function (k) {
              return "https://" + ("" + g + k || Sd) + "/" + h;
            },
            void 0 === f.Hc ? [Sd] : f.Hc
          );
          return d(e, f);
        })
        .then(function (f) {
          var g = f.Ea;
          f = f.rd;
          e.Zb = g;
          e.Re = f;
          return Yg(c, e).then(F(g, lb));
        });
    };
  }
  function kh(a) {
    return function (b, c, d) {
      return function (e, f) {
        var g = L(M(oc, Jb([b, f]), ce), ih[a] || []);
        g = ad(g, d);
        return jh(b, c, g)(e);
      };
    };
  }
  var lh = kh("w");
  function mh(a, b, c, d) {
    return new Y(function (e, f) {
      if (!I(a, "navigator.onLine")) return f();
      var g = {};
      g = O(d.Da, ((g["force-urlencoded"] = 1), g));
      g = c + "?" + td(g) + (d.O ? "&" + d.O : "");
      return 2e3 < g.length ? f($d("sb.tlq")) : b(g) ? e("") : f();
    });
  }
  function nh(a, b) {
    var c = Ue(a);
    if (c) {
      var d = a.document,
        e = c("script");
      b.crossOrigin && (e.crossOrigin = "anonymous");
      e.src = b.src;
      e.type = b.type || "text/javascript";
      e.charset = b.charset || "utf-8";
      e.async = b.async || !0;
      b.wc && O(e.dataset, b.wc);
      try {
        var f = d.getElementsByTagName("head")[0];
        if (!f) {
          var g = d.getElementsByTagName("html")[0];
          f = c("head");
          g && g.appendChild(f);
        }
        f.insertBefore(e, f.firstChild);
        return e;
      } catch (h) {}
    }
  }
  var oh = K(function (a) {
    if ((a = Ue(a))) return a("a");
  });
  function ph(a, b) {
    var c = oh(a);
    return c
      ? ((c.href = b),
        {
          protocol: c.protocol,
          host: c.host,
          port: c.port,
          hostname: c.hostname,
          hash: c.hash,
          search: c.search,
          query: c.search.replace(/^\?/, ""),
          pathname: c.pathname || "/",
          path: (c.pathname || "/") + c.search,
          href: c.href,
        })
      : {};
  }
  function qh(a) {
    return (a.split(":")[1] || "")
      .replace(/^\/*/, "")
      .replace(/^www\./, "")
      .split("/")[0];
  }
  function rh(a, b) {
    if (!b || !b.length) return a;
    var c = n(a.split("#")),
      d = c.next().value;
    c = ia(c);
    c = (c = T("#", c)) ? "#" + c : "";
    return Ha(a, "?") ? d + "&" + b + c : d + "?" + b + c;
  }
  function sh(a, b, c) {
    (c = td(c)) && (a = rh(a, c));
    b.O && (a = rh(a, b.O));
    return a;
  }
  function th(a, b) {
    try {
      delete a[b];
    } catch (c) {
      a[b] = void 0;
    }
  }
  function uh(a, b, c) {
    return new Y(function (d, e) {
      var f = "_ymjsp" + kf(a),
        g = {};
      g = O(((g.callback = f), g), c.Da);
      var h = D([a, f], th);
      a[f] = function (l) {
        try {
          h(), Ve(k), d(l);
        } catch (m) {
          e(m);
        }
      };
      g.wmode = "5";
      f = {};
      var k = nh(a, ((f.src = sh(b, c, g)), f));
      if (!k) return h(), e(Xd("jp.s"));
      f = F(k, Ve);
      f = M(f, F($d(c.N), e));
      g = wf(a, f, c.sa || 1e4);
      g = D([a, g], xf);
      k.onload = g;
      k.onerror = M(h, g, f);
    });
  }
  function vh(a, b, c, d) {
    b = b ? new b() : void 0;
    var e = {};
    e = O(d.Fa ? ((e.wmode = "7"), e) : {}, d.Da);
    var f = b || { signal: void 0, abort: r },
      g = a.fetch(rh(c, td(e)), {
        method: d.ab,
        body: d.O,
        credentials: !1 === d.qc ? "omit" : "include",
        headers: d.Ca,
        signal: f.signal,
        cache: d.cache,
      }),
      h = F(d.N, $d),
      k = F(d.N.concat("timeout"), $d);
    return new Y(function (l, m) {
      var p;
      d.sa &&
        (p = wf(
          a,
          function () {
            try {
              f.abort();
            } catch (q) {}
            m(k());
          },
          d.sa
        ));
      return g
        .then(function (q) {
          if (!q.ok) {
            if (d.Uc) return Ud(Yd(q));
            ae(d.N);
          }
          return d.Uc ? q.text() : d.Fa ? q.json() : null;
        })
        .then(l)
        ["catch"](F(h(), m))
        .then(function () {
          p && xf(a, p);
        });
    });
  }
  var wh = /[^a-z0-9.:-]/;
  function xh(a, b, c, d, e, f, g, h) {
    if (4 === b.readyState)
      if ((200 === b.status || e || g(c), e))
        200 === b.status ? f(b.responseText) : g(Yd(b));
      else {
        e = null;
        if (d)
          try {
            (e = Ee(a, b.responseText)) || g(c);
          } catch (k) {
            g(c);
          }
        f(e);
      }
    return h;
  }
  function yh(a, b, c) {
    var d = new a.XMLHttpRequest(),
      e = c.O,
      f = {},
      g = O(c.Fa ? ((f.wmode = "7"), f) : {}, c.Da);
    return new Y(function (h, k) {
      d.open(c.ab || "GET", rh(b, td(g)), !0);
      d.withCredentials = !1 !== c.qc;
      c.sa && (d.timeout = c.sa);
      M(
        dc,
        Gb(function (m) {
          var p = n(m);
          m = p.next().value;
          p = p.next().value;
          d.setRequestHeader(m, p);
        })
      )(c.Ca);
      var l = D([a, d, $d(c.N), c.Fa, c.Uc, h, k], xh);
      d.onreadystatechange = l;
      try {
        d.send(e);
      } catch (m) {}
    });
  }
  function zh(a, b, c, d) {
    return new Y(function (e, f) {
      var g = $e(a),
        h = b("img"),
        k = M(F(h, Ve), F($d(d.N), f)),
        l = wf(a, k, d.sa || 3e3);
      h.onerror = k;
      h.onload = M(F(h, Ve), F(null, e), D([a, l], xf));
      k = O({}, d.Da);
      delete k.wmode;
      h.src = sh(c, d, k);
      wc(a) &&
        (O(h.style, {
          position: "absolute",
          visibility: "hidden",
          width: "0px",
          height: "0px",
        }),
        g.appendChild(h));
    });
  }
  var Ah = {},
    Bh =
      ((Ah.x = {
        id: 2,
        check: function (a) {
          var b;
          if ((b = I(a, "XMLHttpRequest")))
            if ((b = "withCredentials" in new a.XMLHttpRequest())) {
              a: {
                if (
                  wh.test(a.location.host) &&
                  a.opera &&
                  y(a.opera.version) &&
                  ((b = a.opera.version()),
                  "string" === typeof b && "12" === b.split(".")[0])
                ) {
                  b = !0;
                  break a;
                }
                b = !1;
              }
              b = !b;
            }
          return b ? F(a, yh) : !1;
        },
      }),
      (Ah.i = {
        id: 4,
        check: function (a) {
          var b = Ue(a);
          return b ? D([a, b], zh) : !1;
        },
      }),
      Ah);
  Bh.f = {
    id: 1,
    check: function (a) {
      return a.fetch ? D([a, I(a, "AbortController")], vh) : !1;
    },
  };
  Bh.b = {
    id: 0,
    check: function (a) {
      if (zc(a)) a = !1;
      else {
        var b = I(a, "navigator.sendBeacon");
        a = b && wa("sendBeacon", b) ? D([a, B(b, I(a, "navigator"))], mh) : !1;
      }
      return a;
    },
  };
  Bh.j = {
    id: 3,
    check: function (a) {
      return Ue(a) ? F(a, uh) : !1;
    },
  };
  var Ch = {};
  function Dh(a) {
    if (a)
      return G(
        function (b, c) {
          var d = Bh[c];
          d && b.push(d);
          return b;
        },
        [],
        a
      );
  }
  function Eh(a) {
    return Ch["*"] ? Dh(Ch["*"]) : a ? Dh(Ch[a]) : void 0;
  }
  var Fh = ["b", "f", "x", "j", "i"],
    Gh = ["x"];
  Gh.unshift("f");
  Gh.push("j");
  var Hh = ["i"],
    Ih = ["f", "i"],
    Jh = {},
    Kh = ((Jh.h = Gh), Jh),
    Lh = K(
      function (a, b, c, d) {
        (d = Eh(c) || Dh(d)) || (d = Dh(c ? Kh[c] : Fh));
        c = G(
          function (e, f) {
            var g = f.check,
              h = f.id;
            (g = g(a, b)) && e.push([h, g]);
            return e;
          },
          [],
          d || []
        );
        c.length || ae();
        return c;
      },
      function (a, b, c) {
        return c;
      }
    ),
    Mh = B(Y.reject, Y, $d()),
    Nh = {},
    Oh = ((Nh.h = lh), Nh),
    Ph = V(
      "g.sen",
      function (a, b, c) {
        var d = Lh(a, c, b);
        c = rg(a, b, c);
        var e = Oh[b],
          f = e ? e(a, d, c) : lh(a, d, c);
        return function () {
          var g = n(Va(arguments)),
            h = g.next().value;
          g = ia(g);
          h = O(h, { J: O(void 0 === h.J ? {} : h.J, { N: [b] }) });
          return f.apply(null, [h].concat(g));
        };
      },
      Mh
    );
  function Qh(a, b, c) {
    try {
      if (y(b)) {
        var d = n(Va(arguments));
        d.next();
        d.next();
        d.next();
        var e = ia(d);
        b.apply(z(c) ? null : c, e);
      }
    } catch (f) {
      wf(a, F(f, Ud), 0);
    }
  }
  function Rh(a, b, c, d, e) {
    var f = D([a, d, e], Qh);
    return c.then(f, function (g) {
      f();
      ge(a, b, g);
    });
  }
  function Sh(a, b) {
    function c(d, e, f) {
      var g = {},
        h = {};
      Qd(
        a,
        ((h.name = "log"),
        (h.counterKey = b),
        (h.data =
          ((g.args = w(e) ? e : [e]), (g.type = d), (g.variables = f), g)),
        h)
      );
    }
    return { log: F("log", c), error: F("error", c), warn: F("warn", c) };
  }
  var Th = K(
    V("dc.init", function (a, b) {
      return b && dd(sb(b.split(":")[0]))
        ? { log: r, warn: r, error: r }
        : Sh(a, b);
    }),
    mb
  );
  function Uh(a, b, c, d) {
    Th(a, b).log(c, d);
  }
  function Vh(a, b, c, d, e) {
    return D([a, Q(b), e ? [c + ".p", e] : c, d], Uh);
  }
  var Wh = K(Nd, Q);
  function Xh(a, b) {
    var c = P(a).o("counters", {}),
      d = Q(b);
    return c[d];
  }
  var Yh = /^[a-zA-Z0-9'!#$%&*+-/=?^_`{|}~]+$/;
  function Zh(a) {
    var b = a.length;
    return 1 > b || 64 < b
      ? !1
      : Yb(function (c) {
          var d = c.length;
          if (1 > d) c = !1;
          else if ('"' === c[0] && '"' === c[d - 1] && 2 < d)
            a: {
              for (d = 1; d + 2 < c.length; d += 1) {
                var e = c.charCodeAt(d);
                if (32 > e || 34 === e || 126 < e) {
                  c = !1;
                  break a;
                }
                if (92 === e) {
                  if (d + 2 === c.length || 32 > c.charCodeAt(d + 1)) {
                    c = !1;
                    break a;
                  }
                  d += 1;
                }
              }
              c = !0;
            }
          else c = Yh.test(c) ? !0 : !1;
          return c;
        }, a.split("."));
  }
  function $h(a) {
    var b = a.length;
    return 5 > b || 100 < b ? void 0 : a;
  }
  function ai(a) {
    var b = wd(a).replace(/^\++/gm, "").toLowerCase(),
      c = b.lastIndexOf("@");
    if (-1 === c) return $h(b);
    a = b.substr(0, c);
    c = b.substr(c + 1);
    if (!c || !Zh(a)) return $h(b);
    c = c.replace("googlemail.com", "gmail.com");
    id(c) && (c = "yandex.ru");
    "yandex.ru" === c
      ? (a = a.replace(ya, "-"))
      : "gmail.com" === c && (a = a.replace(ya, ""));
    b = Ba(a, "+");
    -1 !== b && (a = a.slice(0, b));
    return $h(a + "@" + c);
  }
  var bi = /^[0-9()\-+\s]+$/;
  function ci(a, b) {
    var c = zd(b),
      d = c.length,
      e = b[0],
      f = c[0];
    if (!(10 > d || 13 < d || "0" === f) && bi.test(b)) {
      if (10 === d && "+" !== e) return "7" + c;
      if (11 === d) {
        if ("+" === e && "8" === f) return;
        if ("8" === f) return "7" + c.slice(1);
      }
      if (!(12 <= d && "+" === e && "7" === f)) return c;
    }
  }
  var di = K(function (a) {
    return (
      !!I(a, "crypto.subtle.digest") &&
      !!I(a, "TextEncoder") &&
      !!I(a, "FileReader") &&
      !!I(a, "Blob")
    );
  });
  function ei(a, b) {
    return new Y(function (c, d) {
      var e = new a.TextEncoder().encode(b);
      a.crypto.subtle.digest("SHA-256", e).then(function (f) {
        f = new a.Blob([f], { type: "application/octet-binary" });
        var g = new a.FileReader();
        g.onload = function (h) {
          h = I(h, "target.result") || "";
          var k = Ba(h, ",");
          -1 !== k ? c(h.substring(k + 1)) : d(Xd("fpm.i"));
        };
        g.readAsDataURL(f);
      }, d);
    });
  }
  var fi = ["yandex_cid", "yandex_public_id"];
  function gi(a, b, c) {
    c = void 0 === c ? 0 : c;
    b = dc(b);
    b = G(
      function (d, e) {
        var f = n(e),
          g = f.next().value;
        f = f.next().value;
        var h = A(f);
        if (!h && (rb(a, f) && (f = "" + f), !u(f))) return d;
        if (h) f = gi(a, f, c + 1);
        else if (!c && N(g, fi)) f = Y.resolve(f);
        else {
          "phone_number" === g ? (f = ci(a, f)) : "email" === g && (f = ai(f));
          if (!f) return d;
          f = ei(a, f);
        }
        d.push(
          f.then(function (k) {
            return [g, k];
          })
        );
        return d;
      },
      [],
      b
    );
    return Y.all(b);
  }
  var hi = V("fpm", function (a, b) {
    if (!ld(a)) return r;
    var c = Q(b);
    if (!di(a)) return Uh(a, c, "ns"), r;
    var d = Xh(a, b);
    return d
      ? function (e) {
          return new Y(function (f, g) {
            return A(e)
              ? ec(e).length
                ? f(
                    gi(a, e).then(function (h) {
                      if (h && h.length) {
                        var k = {},
                          l = {};
                        d.params(((l.__ym = ((k.fpp = h), k)), l));
                      }
                    }, r)
                  )
                : g($d("fpm.l"))
              : g($d("fpm.o"));
          })["catch"](U(a, "fpm.en"));
        }
      : r;
  });
  function ii(a, b) {
    return G(
      function (c, d) {
        var e = n(d),
          f = e.next().value,
          g = e.next().value;
        e = g;
        g = A(g);
        if (!g && (rb(a, e) && (e = "" + e), !u(e))) return c;
        e = g ? ii(a, e) : e;
        eb(e) && c.push([f, e]);
        return c;
      },
      [],
      dc(b)
    );
  }
  function ji(a, b) {
    return function (c) {
      var d = Xh(a, b);
      if (d) {
        var e = Th(a, Q(b));
        if (A(c))
          if (eb(ec(c))) {
            if ((c = ii(a, c)) && eb(c)) {
              e = {};
              var f = {};
              d.params(((f.__ym = ((e.fpmh = c), e)), f));
            }
          } else e.log("fpeo");
        else e.log("fpno");
      }
    };
  }
  function ki(a, b, c, d) {
    var e = xe[c];
    return e
      ? function () {
          var f = Va(arguments);
          f = d.apply(null, ja(f));
          var g = P(a);
          g.V("mt", {});
          g = g.o("mt");
          var h = g[e];
          g[e] = h ? h + 1 : 1;
          return f;
        }
      : d;
  }
  function li(a) {
    a = P(a);
    var b = a.o("dsjf") || Qa({});
    a.V("dsjf", b);
    return b;
  }
  function mi(a, b, c) {
    li(a)(function (d) {
      d[b] = O(d[b] || {}, c);
    });
  }
  function ni(a, b) {
    li(a)(function (c) {
      delete c[b];
    });
  }
  function oi(a, b) {
    return function (c) {
      mi(a, b, c);
    };
  }
  var pi = Ma(function (a, b) {
      var c = {};
      li(a)(function (d) {
        c = d[b] || {};
      });
      return c;
    }),
    qi = V("c.c.cc", function (a) {
      var b = P(a),
        c = M(pi(a), function (d) {
          var e = {};
          e = ((e.clickmap = !!d.clickmap), e);
          return O({}, d, e);
        });
      return U(a, "g.c.cc", M(B(b.o, b, "counters", {}), ec, Gb(c)));
    }),
    ri = V("gt.c.rs", function (a, b) {
      var c = Q(b),
        d = b.id,
        e = b.M,
        f = b.Ed,
        g = b.hc,
        h = D([a, c], ni),
        k = {};
      mi(
        a,
        c,
        ((k.id = d), (k.type = +e), (k.clickmap = f), (k.trackHash = !!g), k)
      );
      return h;
    }),
    si = {};
  function ti(a, b) {
    var c = Q(a),
      d = I(b, "__ym.turbo_page"),
      e = I(b, "__ym.turbo_page_id");
    si[c] || (si[c] = {});
    if (d || e) (si[c].ye = d), (si[c].ze = e);
  }
  function ui(a) {
    a = Q(a);
    return si[a] && si[a].ye;
  }
  var vi = K(Od);
  function wi(a, b) {
    return {
      K: function (c, d) {
        var e = (c.H || {}).L,
          f = void 0 === c.J ? {} : c.J;
        if (e && (ti(b, e), !f.O && c.G && c.D)) {
          var g = Fe(a, e),
            h = vi(a),
            k = c.G.o("pv");
          if (g && !c.D.nohit) {
            var l = {},
              m = {};
            Qd(
              a,
              ((m.counterKey = Q(b)),
              (m.name = "params"),
              (m.data = ((l.val = e), l)),
              m)
            );
            k
              ? encodeURIComponent(g).length > (Fc(a) ? 512 : 2048)
                ? h.push([c.G, e])
                : (c.D["site-info"] = g)
              : ((f.O = g), (c.J = f), c.ub || (c.ub = {}), (c.ub.de = !0));
          }
        }
        d();
      },
      S: function (c, d) {
        var e = vi(a),
          f = Xh(a, b),
          g = f && f.params;
        g &&
          ((f = Qb(M(oc, Oa(c.G)), e)),
          L(function (h) {
            var k = n(h);
            k.next();
            k = k.next().value;
            g(k);
            h = nc(a)(h, e);
            e.splice(h, 1);
          }, f));
        d();
      },
    };
  }
  function xi(a) {
    var b = r,
      c = null,
      d = a.length;
    if (0 !== a.length && a[0]) {
      var e = a.slice(-1)[0];
      y(e) && ((b = e), (d = a.length + -1));
      var f = a.slice(-2)[0];
      y(f) && ((b = f), (c = e), (d = a.length + -2));
      d = a.slice(0, d);
      return { Jd: c, eb: b, L: 1 === d.length ? a[0] : fb(d) };
    }
  }
  var yi = V("pa.int", function (a, b) {
    var c = {};
    return (
      (c.params = function () {
        var d = Va(arguments),
          e = xi(d);
        if (!e) return null;
        d = e.Jd;
        var f = e.L;
        e = e.eb;
        if (!A(f) && !w(f)) return null;
        var g = Ph(a, "1", b),
          h = Wh(b).url,
          k = !ed(b),
          l = "pa",
          m = {};
        m = ((m.id = b.id), m);
        var p = f,
          q = "";
        if ((q = I(f, "__ym.user_id"))) (l = "pau"), (m.uid = q);
        N("__ymu", ec(f)) && (l = "paup");
        p.__ym &&
          ((p = O({}, f)),
          (p.__ym = G(
            function (v, t) {
              var x = I(f, "__ym." + t);
              x && (v[t] = x);
              return v;
            },
            {},
            te
          )),
          ec(p.__ym).length || delete p.__ym,
          (k = !!ec(p).length));
        p = q ? void 0 : Fe(a, p);
        l = Vh(a, b, l, m, p);
        m = {};
        p = {};
        g = g(
          {
            H: { L: f },
            G: $g(((m.pa = 1), (m.ar = 1), m)),
            D: ((p["page-url"] = h || R(a).href), p),
          },
          b
        ).then(k ? l : r);
        return Rh(a, "p.s", g, e, d);
      }),
      c
    );
  });
  function zi(a, b, c, d, e) {
    return new Y(function (f, g) {
      var h = ec(c),
        k = M(d.resolve || lb, Pa(f)),
        l = M(d.reject || lb, Pa(g));
      d.resolve = k;
      d.reject = l;
      L(function (m) {
        d.jc.push(+m);
        var p = c[m],
          q = yf(a, F($d(), l), 5100, "is.m"),
          v = {};
        b(p.window, O(e, ((v.toCounter = ub(m)), v)), function (t, x) {
          xf(a, q);
          d.cd.push(m);
          d.resolve && d.resolve(x);
        });
      }, h);
    })["catch"](U(a, "if.b"));
  }
  function Ai(a, b, c) {
    b = Qb(function (d) {
      return !N(c.info.counterId, d.jc);
    }, b);
    L(function (d) {
      if (c.info.counterId) {
        var e = {};
        a(((e[c.info.counterId] = c), e), d, d.data);
      }
    }, b);
  }
  function Bi(a, b) {
    var c = Pf(a, b);
    if (!c) return null;
    var d = [],
      e = [],
      f = D([a, c.bc], zi),
      g = F(f, Ai);
    c.ca
      .C(["initToParent"], function (h) {
        h = n(h);
        h.next();
        h = h.next().value;
        g(d, c.children[h.counterId]);
      })
      .C(["parentConnect"], function (h) {
        h = n(h);
        h.next();
        h = h.next().value;
        g(e, c.ga[h.counterId]);
      });
    return {
      ca: c.ca,
      Se: function (h, k) {
        return new Y(function (l, m) {
          c.bc(h, k, function (p, q) {
            l([p, q]);
          });
          yf(a, F($d(), m), 5100, "is.o");
        });
      },
      $c: function (h) {
        var k = { cd: [], jc: [], data: h };
        d.push(k);
        return f(c.children, k, h);
      },
      ad: function (h) {
        var k = { cd: [], jc: [], data: h };
        e.push(k);
        return f(c.ga, k, h);
      },
    };
  }
  var Ci = K(Bi, M(mb, Q));
  function Di(a, b) {
    if (!N(b, L(J("ymetrikaEvent.type"), a))) {
      var c = {},
        d = {};
      a.push(((d.ymetrikaEvent = ((c.type = b), c)), d));
    }
  }
  function Ei(a) {
    a = P(a);
    var b = a.o("dataLayer", []);
    a.B("dataLayer", b);
    return b;
  }
  function Fi(a, b, c, d) {
    c = void 0 === c ? r : c;
    d = void 0 === d ? !1 : d;
    var e = Gf(a);
    if (b && y(b.push)) {
      var f = b.push;
      b.push = function () {
        var g = Va(arguments),
          h = n(g).next().value;
        d && e.trigger(h);
        g = f.apply(b, g);
        d || e.trigger(h);
        return g;
      };
      a = {
        Ba: e,
        unsubscribe: function () {
          b.push = f;
        },
      };
      c(a);
      L(e.trigger, b);
      return a;
    }
  }
  function Gi(a, b) {
    var c = I(b, "ymetrikaEvent");
    c && a.trigger(I(c, "type"), c);
  }
  function Hi(a, b, c) {
    c = void 0 === c ? lb : c;
    var d = Hf(a, "idlo");
    c(d);
    var e = F(d, Gi);
    Fi(a, b, function (f) {
      f.Ba.C(e);
    });
    return d;
  }
  function Ii(a, b, c, d) {
    var e = Xh(a, c);
    if (e) {
      a = d.data;
      c = "" + c.id;
      var f = d.sended || [];
      d.sended || (d.sended = f);
      N(c, f) ||
        !e.params ||
        (d.counter && "" + d.counter !== c) ||
        (e.params(a),
        f.push(c),
        d.parent && ((d = {}), b.ad(((d.type = "params"), (d.data = a), d))));
    }
  }
  var Ji = V("y.p", function (a, b) {
    var c = Bi(a, b);
    if (c) {
      var d = Ei(a),
        e = D([a, c, b], Ii);
      Hi(a, d, function (f) {
        f.C(["params"], e);
      });
      c.ca.C(["params"], M(J("1"), e));
    }
  });
  function Ki(a, b, c, d) {
    var e = R(a),
      f = e.hostname;
    e = e.href;
    if ((b = Wh(b).url)) (a = ph(a, b)), (f = a.hostname), (e = a.href);
    return [d + "://" + f + "/" + c, e || ""];
  }
  var Li = { Pe: $a(/[/&=?#]/) },
    Mi = V("go.in", function (a, b, c, d) {
      c = void 0 === c ? "goal" : c;
      var e = {};
      return (
        (e.reachGoal = function (f, g, h, k) {
          if (!f || (Li[c] && Li[c](f))) return null;
          var l = g,
            m = h || r;
          y(g) && ((m = g), (l = void 0), (k = h));
          g = {};
          var p = Vh(a, b, "gr", ((g.id = b.id), (g.goal = f), g), l),
            q = "goal" === c;
          g = Ph(a, "g", b);
          var v = n(Ki(a, b, f, c));
          h = v.next().value;
          v = v.next().value;
          var t = {},
            x = {};
          g = g(
            {
              H: { L: l },
              G: $g(((t.ar = 1), t)),
              D: ((x["page-url"] = h), (x["page-ref"] = v), x),
            },
            b
          ).then(function () {
            q && p();
            var E = {},
              C = {};
            Qd(
              a,
              ((C.counterKey = Q(b)),
              (C.name = "event"),
              (C.data = ((E.schema = c), (E.name = f), (E.params = l), E)),
              C)
            );
            d && d();
          });
          return Rh(a, "g.s", g, m, k);
        }),
        e
      );
    }),
    Ni = V("guid.int", function (a, b) {
      var c = {};
      return (
        (c.getClientID = function (d) {
          var e = vf(a, b);
          d && Qh(a, d, null, e);
          return e;
        }),
        c
      );
    }),
    Oi;
  function Pi(a) {
    return (a = R(a).hash.split("#")[1]) ? a.split("?")[0] : "";
  }
  function Qi(a, b) {
    var c = Pi(a);
    Oi = zf(
      a,
      function () {
        var d = Pi(a);
        d !== c && (b(), (c = d));
      },
      200,
      "t.h"
    );
    return B(Af, null, a, Oi);
  }
  function Ri(a, b, c, d) {
    var e = b.M,
      f = b.oc,
      g = b.Ga,
      h = P(a),
      k = {};
    k = $g(((k.wh = 1), (k.pv = 1), k));
    var l = I(d, "isTrusted");
    d && !z(l) && k.B("ite", Mb(l));
    ye(e) && a.Ya && a.Ya.Direct && k.B("ad", "1");
    f && k.B("ut", "1");
    e = h.o("lastReferrer");
    d = R(a).href;
    f = {};
    g = { D: ((f["page-url"] = g || d), (f["page-ref"] = e), f), G: k };
    c(g, b)["catch"](U(a, "g.s"));
    h.B("lastReferrer", d);
  }
  var Si = V("th.e", function (a, b) {
    function c() {
      f ||
        (h = H(a, "onhashchange") ? Xc(a).C(a, ["hashchange"], g) : Qi(a, g));
    }
    var d = Ph(a, "t", b),
      e = oi(a, Q(b)),
      f = !1,
      g = U(a, "h.h.ch", B(Ri, null, a, b, d)),
      h = r;
    b.hc && (c(), (f = !0));
    d = {};
    return (
      (d.trackHash = U(a, "tr.hs.h", function (k) {
        k ? c() : h();
        f = !!k;
        k = {};
        e(((k.trackHash = f), k));
      })),
      (d.u = h),
      d
    );
  });
  function Ti(a) {
    var b = null;
    try {
      b = a.target || a.srcElement;
    } catch (c) {}
    if (b) {
      3 === b.nodeType && (b = b.parentNode);
      for (
        a = b && b.nodeName && ("" + b.nodeName).toLowerCase();
        I(b, "parentNode.nodeName") &&
        (("a" !== a && "area" !== a) ||
          (!b.href && !b.getAttribute("xlink:href")));

      )
        a = (b = b.parentNode) && b.nodeName && ("" + b.nodeName).toLowerCase();
      return b.href ? b : null;
    }
    return null;
  }
  function Ui(a, b) {
    var c = {};
    c =
      ((c.string = !0), (c.object = !0), (c["boolean"] = b), c)[typeof b] || !1;
    var d = {};
    a(((d.trackLinks = c), d));
  }
  function Vi(a, b, c) {
    var d = $g();
    void 0 !== c.pb && d.B("ite", Mb(c.pb));
    c.mb && d.B("dl", 1);
    c.Ja && d.B("ln", 1);
    var e = c.vd || {},
      f = {};
    d = {
      G: d,
      H: { title: e.title || c.title, qb: !!c.qb, L: e.params },
      D: ((f["page-url"] = c.url), (f["page-ref"] = b.Ga || R(a).href), f),
    };
    f = "Link";
    c.mb ? (f = c.Ja ? "Ext link - File" : "File") : c.Ja && (f = "Ext link");
    var g = {},
      h = {};
    Qd(
      a,
      ((h.counterKey = Q(b)),
      (h.name = "event"),
      (h.data =
        ((g.schema = "Link click"),
        (g.name = (c.Ja ? "external" : "internal") + " url: " + c.url),
        g)),
      h)
    );
    g = {};
    b = c
      .sender(d, b)
      .then(
        Vh(
          a,
          b,
          "lcl",
          ((g.prefix = f), (g.id = b.id), (g.url = c.url), g),
          c.vd
        )
      );
    Rh(a, "cl.p.s", b, e.callback || r, e.ctx);
  }
  function Wi(a, b) {
    if (a.Ae()) {
      var c = Ti(b);
      if (c && !Xe("ym-disable-tracklink", c)) {
        var d = a.l,
          e = a.Hd,
          f = a.Id,
          g = a.sender,
          h = a.Od,
          k = f.Ga,
          l = c.href;
        var m = wd(c.innerHTML && c.innerHTML.replace(/<\/?[^>]+>/gi, ""));
        m ||
          (m = (m = c.querySelector("img"))
            ? wd(m.getAttribute("title") || m.getAttribute("alt"))
            : "");
        m = l === m ? "" : m;
        var p = I(b, "isTrusted");
        if (Xe("ym-external-link", c))
          Vi(d, f, { url: l, Ja: !0, title: m, pb: p, sender: g });
        else {
          k = k ? ph(d, k).hostname : R(d).hostname;
          h = RegExp("\\.(" + T("|", L(Ja, h)) + ")$", "i");
          var q = c.protocol + "//" + c.hostname + c.pathname;
          h = ve.test(q) || ve.test(l) || h.test(l) || h.test(q);
          c = c.hostname;
          jd(k) === jd(c)
            ? h
              ? Vi(d, f, { url: l, mb: !0, pb: p, title: m, sender: g })
              : m && e.B("il", wd(m).slice(0, 100))
            : (l && ue.test(l)) ||
              Vi(d, f, {
                url: l,
                qb: !0,
                Ja: !0,
                mb: h,
                pb: p,
                title: m,
                sender: g,
              });
        }
      }
    }
  }
  var Xi = Ma(function (a, b) {
    u(b) ? a.push(b) : L(M(lb, Za("push", a)), b);
  });
  function Yi(a, b) {
    return function (c) {
      var d = c[a];
      d
        ? ((d.Yb = !0), d.Xb(b))
        : (c[a] = { promise: Y.resolve(b), Yb: !0, Xb: r });
    };
  }
  var Zi = Ma(function (a, b) {
      if (!b[a]) {
        var c,
          d = new Y(function (e) {
            c = e;
          });
        b[a] = { Xb: c, promise: d, Yb: !1 };
      }
      return b[a].promise;
    }),
    $i = K(M(Nd, Qa)),
    aj = K(Nd);
  function bj(a, b, c) {
    b = Q(b);
    aj(b).Pd = W(a)(mf);
    c = O({}, c);
    var d = {},
      e = {};
    Qd(
      a,
      ((e.counterKey = b),
      (e.name = "counterSettings"),
      (e.data = ((d.settings = c), d)),
      e)
    );
    return $i()(Yi(b, c));
  }
  function cj(a, b) {
    var c = Q(a);
    return $i()(Zi(c)).then(b);
  }
  function dj(a, b, c) {
    if (a.postMessage && !a.attachEvent) {
      var d = Xc(a),
        e = "__ym__promise_" + kf(a) + "_" + kf(a),
        f = r;
      f = d.C(
        a,
        ["message"],
        U(a, c, function (g) {
          try {
            var h = g.data;
          } catch (k) {
            return;
          }
          h === e && (f(), g.stopPropagation && g.stopPropagation(), b());
        })
      );
      a.postMessage(e, "*");
    } else yf(a, b, 0, c);
  }
  var ej = [],
    fj = !1,
    gj = !1;
  function hj(a, b) {
    if (ej.length) {
      var c = ej.shift();
      gj ? c() : yf(a, c, 100, b + ".ei.rnt");
    } else fj = !1;
  }
  function ij(a, b, c, d, e) {
    d = void 0 === d ? 1 : d;
    e = void 0 === e ? Vg : e;
    gj = Infinity === d;
    return Qa(function (f, g) {
      function h() {
        try {
          var l = b(e(a, d));
          k = k.concat(l);
        } catch (m) {
          return f(m);
        }
        b(Qg);
        if (b(Ng)) return g(k), hj(a, c);
        gj ? (b(e(a, 1e4)), g(k), hj(a, c)) : yf(a, h, 100, c + ".ei");
      }
      var k = [];
      fj ? ej.push(h) : ((fj = !0), h());
    });
  }
  function jj(a, b, c, d, e, f) {
    e = void 0 === e ? 1 : e;
    f = void 0 === f ? r : f;
    b = Xg(b, c);
    ij(a, b, d + ".itc", e)(Bf(U(a, d), f));
  }
  function kj(a, b, c) {
    function d(g) {
      var h = { id: g.counterId, M: g.M },
        k = {
          J: { O: g.je },
          G: $g(g.Bd),
          D: g.L,
          H: { Za: g.Za },
          ha: { U: g.U },
        };
      g.ba && (k.ba = qe(g.ba));
      return f(k, h).then(r, e);
    }
    var e = U(a, "rts.p"),
      f = Ph(a, "r", b);
    return cj(b, function () {
      dj(a, D([a, c, d, "rts.a", 1], jj), "rts.mr");
    }).then(r, e);
  }
  var lj = M(Ca, Oa(0)),
    mj = Na(lj),
    nj = [mj("watch"), mj("clmap")],
    oj = cd(
      "retryReqs",
      function (a) {
        return Me(a).o("retryReqs", {});
      },
      !0
    );
  function pj(a, b) {
    Me(a).B("retryReqs", b);
  }
  function qj(a, b) {
    var c = {
      protocol: b.protocol,
      host: b.host,
      U: b.resource,
      je: b.postParams,
      L: b.params,
      Bd: b.browserInfo,
      Ne: b.ghid,
      time: b.time,
      Za: ub(a),
      counterId: b.counterId,
      M: b.counterType,
    };
    b.telemetry && (c.ba = b.telemetry);
    return c;
  }
  function rj(a) {
    var b = oj(a);
    return {
      add: function (c) {
        for (var d = 1; b[d]; ) d += 1;
        b[d] = c;
        pj(a, b);
        return d;
      },
      delete: function (c) {
        delete b[c];
        pj(a, b);
      },
      Ce: function (c, d) {
        var e = b[c];
        e && e.browserInfo && ((e.browserInfo.rqnl = d), pj(a, b));
      },
      Rd: V("g.r", function () {
        var c = W(a)(mf),
          d = rf(a);
        return G(
          function (e, f) {
            var g = n(f),
              h = g.next().value;
            (g = g.next().value) &&
              sc(Qa(g.resource), nj) &&
              !g.d &&
              g.ghid &&
              g.ghid !== d &&
              g.time &&
              500 < c - g.time &&
              g.time + 864e5 > c &&
              g.browserInfo.rqnl &&
              2 >= g.browserInfo.rqnl &&
              ((g.d = 1), (h = qj(h, g)), e.push(h));
            return e;
          },
          [],
          dc(b)
        );
      }),
      Dd: function () {
        var c = W(a)(mf);
        L(function (d) {
          var e = n(d);
          d = e.next().value;
          e = e.next().value;
          (!e ||
            !e.time ||
            e.time + 864e5 < c ||
            (e.browserInfo.rqnl && 2 <= e.browserInfo.rqnl)) &&
            delete b[d];
        }, dc(b));
        pj(a, b);
      },
      length: function () {
        return ec(b).length;
      },
      clear: function () {
        pj(a, {});
        return G(
          function (c, d) {
            var e = n(d),
              f = e.next().value;
            e = e.next().value;
            c.push(qj(f, e));
            delete b[f];
            return c;
          },
          [],
          dc(b)
        );
      },
    };
  }
  function sj(a, b, c, d) {
    b.G &&
      b.H &&
      (d["delete"](b.H.Za),
      100 <= d.length() && ((b = d.clear()), kj(a, c, b)));
  }
  function tj(a, b) {
    var c = rj(a);
    return {
      K: function (d, e) {
        var f = d.G,
          g = d.ba,
          h = d.D,
          k = void 0 === d.J ? {} : d.J;
        if (f && h) {
          var l = W(a);
          f.wb("rqnl", 1);
          var m = {};
          f =
            ((m.protocol = "https:"),
            (m.host = Sd),
            (m.resource = d.ha.U),
            (m.postParams = k.O),
            (m.time = l(mf)),
            (m.counterType = b.M),
            (m.params = h),
            (m.browserInfo = f.l()),
            (m.counterId = b.id),
            (m.ghid = rf(a)),
            m);
          g && (f.telemetry = g.l());
          g = c.add(f);
          d.H || (d.H = {});
          d.H.Za = g;
        }
        e();
      },
      S: function (d, e) {
        sj(a, d, b, c);
        e();
      },
    };
  }
  function uj(a, b, c) {
    function d() {
      v || ((q = !0), (t = !1), (v = !0), f());
    }
    function e() {
      m = !0;
      k(!1);
      b();
    }
    function f() {
      xf(a, l);
      if (m) k(!1);
      else {
        var S = Math.max(0, c - (t ? x : x + p(mf) - E));
        S ? (l = yf(a, e, S, "u.t.d.c")) : e();
      }
    }
    function g() {
      t = q = v = !0;
      x += p(mf) - E;
      E = p(mf);
      f();
    }
    function h() {
      q || v || (x = 0);
      E = p(mf);
      q = v = !0;
      t = !1;
      f();
    }
    function k(S) {
      S = S ? C.C : C.ua;
      S(a, ["blur"], g);
      S(a, ["focus"], h);
      S(a.document, ["click", "mousemove", "keydown", "scroll"], d);
    }
    var l = 0,
      m = !1;
    if (Fc(a)) return (l = yf(a, b, c, "u.t.d")), D([a, l], xf);
    var p = W(a),
      q = !1,
      v = !1,
      t = !0,
      x = 0,
      E = p(mf),
      C = Xc(a);
    k(!0);
    f();
    return function () {
      xf(a, l);
      k(!1);
    };
  }
  var vj = V("nb.p", function (a, b) {
    function c(q) {
      h() ||
        ((q = "number" === typeof q ? q : 15e3), (p = uj(a, d(!1), q)), l());
    }
    function d(q) {
      return function (v) {
        var t = {};
        v = void 0 === v ? ((t.ctx = {}), (t.callback = r), t) : v;
        if (q || (!m && !g.Lb)) {
          m = !0;
          l();
          p && p();
          var x = W(a)(mf);
          t = (ub(g.o("lastHit")) || 0) < x - 18e5;
          var E = 0.1 > Math.random();
          g.B("lastHit", x);
          var C = aj(f);
          x = C.kb;
          C = C.Pd;
          var S = {};
          x = $g(
            ((S.nb = 1),
            (S.cl = rb(a, C) && rb(a, x) ? C - x : 0),
            (S.ar = 1),
            S)
          );
          C = Wh(b);
          S = {};
          x = {
            D: ((S["page-url"] = C.url || R(a).href), S),
            G: x,
            H: { force: q },
          };
          C = Th(a, Q(b)).warn;
          !v.callback && v.ctx && C("nbnc");
          (t = q || t || E) ||
            ((t = a.location.href),
            (E = a.document.referrer),
            (t = !(t && E ? qh(t) === qh(E) : !t && !E)));
          if (t) return (t = e(x, b)), Rh(a, "l.o.l", t, v.callback, v.ctx);
        }
        return null;
      };
    }
    var e = Ph(a, "n", b),
      f = Q(b),
      g = Ne(a, b.id),
      h = F(F(f, pi(a)), M(ce, J("accurateTrackBounce"))),
      k = {},
      l = F(((k.accurateTrackBounce = !0), k), oi(a, f)),
      m = !1,
      p;
    b.tc && c(b.tc);
    k = {};
    k = ((k.notBounce = d(!0)), (k.u = p), k);
    k.accurateTrackBounce = c;
    return k;
  });
  function wj(a) {
    return !(
      !wa("querySelectorAll", I(a, "Element.prototype.querySelectorAll")) ||
      !a.document.querySelectorAll
    );
  }
  function xj(a, b) {
    if (!b || !b.querySelectorAll) return [];
    var c = b.querySelectorAll(a);
    return c ? mc(c) : [];
  }
  function yj(a, b) {
    if (b.querySelector) return b.querySelector(a);
    var c = xj(a, b);
    return c && c.length ? c[0] : null;
  }
  var zj;
  var Aj = window.Set;
  if (xa(Aj, "Set")) {
    var Bj = xa(I(Aj.prototype, "add"), "add"),
      Cj = xa(I(Aj.prototype, "has"), "has"),
      Dj = xa(I(Aj.prototype, "delete"), "delete"),
      Ej = xa(I(Aj.prototype, "clear"), "clear"),
      Fj = xa(I(Aj.prototype, "forEach"), "forEach");
    zj = Bj && Cj && Dj && Ej && Fj ? Set : kc;
  } else zj = kc;
  var Gj = zj;
  function Hj(a, b, c) {
    if (!(b && b.Element && b.Element.prototype && b.document && c))
      return null;
    if (
      b.Element.prototype.closest &&
      wa("closest", b.Element.prototype.closest) &&
      c.closest
    )
      return c.closest(a);
    var d = Ye(b);
    if (d) {
      for (; c && 1 === c.nodeType && !d.call(c, a); )
        c = c.parentElement || c.parentNode;
      return c && 1 === c.nodeType ? c : null;
    }
    if (wj(b)) {
      for (
        a = new Gj(mc((b.document || b.ownerDocument).querySelectorAll(a)));
        c && 1 === c.nodeType && !a.has(c);

      )
        c = c.parentElement || c.parentNode;
      return c && 1 === c.nodeType ? c : null;
    }
    return null;
  }
  function Ij(a, b) {
    return H(b, "isConnected")
      ? !b.isConnected
      : Hj("html", a, b) !== a.document.documentElement;
  }
  function Jj(a, b) {
    var c = b,
      d = I(a, "document"),
      e = gf(c);
    if (
      !c ||
      !c.ownerDocument ||
      "PARAM" === e ||
      c === Ze(a) ||
      c === d.documentElement
    )
      return { left: 0, top: 0 };
    if ((d = ef(c)))
      return (
        (c = cf(a)),
        { left: Math.round(d.left + c.x), top: Math.round(d.top + c.y) }
      );
    for (e = d = 0; c; )
      (d += c.offsetLeft), (e += c.offsetTop), (c = c.offsetParent);
    return { left: d, top: e };
  }
  function Kj(a, b) {
    var c = I(a, "document");
    return b === Ze(a) || b === c.documentElement
      ? df(a)
      : (c = ef(b))
      ? [c.width, c.height]
      : [b.offsetWidth, b.offsetHeight];
  }
  var Lj = K(function () {
    for (var a = 59, b = {}, c = 0; c < se.length; c += 1)
      (b[se[c]] = String.fromCharCode(a)), (a += 1);
    return b;
  });
  function Mj(a, b, c) {
    for (
      var d = "", e = Lj(), f = gf(b) || "*";
      b && b.parentNode && !N(f, ["BODY", "HTML"]);

    ) {
      d += e[f] || "*";
      a: {
        f = I(a, "document");
        if (
          (f =
            b && b !== f.documentElement
              ? b === Ze(a)
                ? f.documentElement
                : I(b, "parentNode")
              : null)
        ) {
          f = f.childNodes;
          for (var g = b && b.nodeName, h = 0, k = 0; k < f.length; k += 1)
            if (g === (f[k] && f[k].nodeName)) {
              if (b === f[k]) {
                f = h;
                break a;
              }
              (c && f[k] === c) || (h += 1);
            }
        }
        f = 0;
      }
      d += f || "";
      b = b.parentElement;
      f = gf(b) || "*";
    }
    return wd(d, 128);
  }
  function Nj(a, b) {
    var c = $e(a),
      d = cf(a);
    return {
      x: b.pageX || b.clientX + d.x - (c.clientLeft || 0) || 0,
      y: b.pageY || b.clientY + d.y - (c.clientTop || 0) || 0,
    };
  }
  function Oj(a) {
    var b = a.which;
    a = a.button;
    return b || void 0 === a
      ? b
      : 1 === a || 3 === a
      ? 1
      : 2 === a
      ? 3
      : 4 === a
      ? 2
      : 0;
  }
  var Pj = Ma(Xe)("(ym-disable-clickmap|ym-clickmap-ignore)");
  function Qj(a, b, c, d, e) {
    if (H(a, "ymDisabledClickmap") || !b || !b.element) return !1;
    a = gf(b.element);
    if (
      (e && !e(b.element, a)) ||
      (N(b.button, [2, 3]) && "A" !== a) ||
      sc(Oa(a), d)
    )
      return !1;
    d = b.element;
    if (b && c) {
      if (50 > b.time - c.time) return !1;
      e = Math.abs(c.position.x - b.position.x);
      a = Math.abs(c.position.y - b.position.y);
      b = b.time - c.time;
      if (c.element === d && 2 > e && 2 > a && 1e3 > b) return !1;
    }
    for (; d; ) {
      if (Pj(d)) return !1;
      d = d.parentElement;
    }
    return !0;
  }
  function Rj(a, b, c, d, e) {
    var f = "clmap/" + e.id,
      g = {};
    b = ((g["page-url"] = b), (g["pointer-click"] = c), g);
    f = { G: $g(), D: b, ha: { U: f } };
    d(f, e)["catch"](U(a, "c.s.c"));
  }
  var Sj = V("clm.p", function (a, b) {
      if (tc(a)) return r;
      var c = Ph(a, "m", b),
        d = Q(b),
        e = W(a),
        f = e(mf),
        g = F(F(d, pi(a)), M(ce, J("clickmap"))),
        h,
        k = null;
      d = U(a, "clm.p.c", function (l) {
        var m = g();
        if (m) {
          var p = P(a),
            q = p.o("cls", { fb: 0, x: 0, y: 0 });
          p.B("cls", { fb: q.fb + 1, x: q.x + l.clientX, y: q.y + l.clientY });
          p = "object" === typeof m ? m : {};
          q = p.filter;
          m = p.isTrackHash || !1;
          var v = L(function (x) {
            return ("" + x).toUpperCase();
          }, p.ignoreTags || []);
          Sa(h) && (h = p.quota || null);
          var t = !!p.quota;
          l = {
            element: We(a, l),
            position: Nj(a, l),
            button: Oj(l),
            time: e(mf),
          };
          p = R(a).href;
          if (Qj(a, l, k, v, q)) {
            if (t) {
              if (!h) return;
              --h;
            }
            v = n(Kj(a, l.element));
            q = v.next().value;
            v = v.next().value;
            t = Jj(a, l.element);
            q = [
              "rn",
              kf(a),
              "x",
              Math.floor((65535 * (l.position.x - t.left)) / (q || 1)),
              "y",
              Math.floor((65535 * (l.position.y - t.top)) / (v || 1)),
              "t",
              Math.floor((l.time - f) / 100),
              "p",
              Mj(a, l.element),
              "X",
              l.position.x,
              "Y",
              l.position.y,
            ];
            q = T(":", q);
            m && (q += ":wh:1");
            Rj(a, p, q, c, b);
            k = l;
          }
        }
      });
      return Xc(a).C(I(a, "document"), ["click"], d);
    }),
    Tj = V("trigger.in", function (a, b) {
      b.nd && dj(a, D([a, "yacounter" + b.id + "inited"], ff), "t.i");
    });
  function Uj(a, b) {
    var c = {};
    a(((c.clickmap = Sa(b) ? !0 : b), c));
  }
  var Vj = V("c.m.p", function (a, b) {
    var c = Q(b),
      d = {};
    return (d.clickmap = F(oi(a, c), Uj)), d;
  });
  function Wj(a) {
    a = "" + a;
    for (var b = 2166136261, c = a.length, d = 0; d < c; d += 1)
      (b ^= a.charCodeAt(d)),
        (b += (b << 1) + (b << 4) + (b << 7) + (b << 8) + (b << 24));
    return b >>> 0;
  }
  var Xj = {},
    Yj = {};
  Xj.p = 500;
  var Zj = { i: "id", n: "name", h: "href", ty: "type" };
  Yj.h = !0;
  Yj.c = !0;
  var ak = {
    p: function (a, b, c) {
      if (b && Ij(a, b) && b._ymp) return b._ymp;
      a = Mj(a, b, c);
      b && (b._ymp = a);
      return a;
    },
    c: function (a, b, c) {
      (a = wd(I(b, "textContent"))) &&
        c &&
        ((c = c(b)),
        c.length && sc(M(J("textContent"), wd, Oa(a)), c) && (a = ""));
      jf(b) && (a = wd((b.getAttribute && b.getAttribute("value")) || a));
      return a;
    },
  };
  function bk(a, b, c, d) {
    return G(
      function (e, f) {
        var g = null;
        f in Zj
          ? (g = b.getAttribute && b.getAttribute(Zj[f]))
          : f in ak &&
            (g =
              "p" === f
                ? ak[f](a, b, void 0)
                : "c" === f
                ? ak[f](a, b, d)
                : ak[f](a, b));
        g && ((g = g.slice(0, Xj[f] || 100)), (e[f] = Yj[f] ? "" + Wj(g) : g));
        return e;
      },
      {},
      c
    );
  }
  var ck = F("form", Hj),
    dk = K(M(mb, Na(cj)(J("settings.form_goals"))), mb);
  function ek(a, b, c, d) {
    return dk(a, b).then(M(D([Vh(a, b, c, d), r], Kb), ce));
  }
  function fk(a, b, c, d, e, f) {
    var g = ib(b)(e, d),
      h = -1 !== g;
    if (a || h)
      h && d.splice(g, 1),
        (a = bk(b, e, ["i", "n", "p"])),
        (a = "?" + td(a)),
        (d = {}),
        (d = D([b, c, "fg", ((d.id = c.id), (d.query = a), d)], ek)),
        z(f)
          ? (f = void 0)
          : ((e = {}), (g = {}), (f = ((g.__ym = ((e.ite = Mb(f)), e)), g))),
        Mi(b, c, "form", d).reachGoal(a, f);
  }
  function gk(a, b, c, d) {
    var e = I(d, "target");
    e &&
      ((d = I(d, "isTrusted")),
      (e = Hj("button,input", a, e)) &&
        "submit" === e.type &&
        (e = ck(a, e))) &&
      (c.push(e), yf(a, D([!1, a, b, c, e, d], fk), 300, "s.t.s"));
  }
  var hk = V("s.f.i", function (a, b) {
    var c = [],
      d = [],
      e = Xc(a);
    c.push(e.C(a, ["click"], U(a, "s.f.c", D([a, b, d], gk))));
    c.push(
      e.C(
        a,
        ["submit"],
        U(a, "s.f.e", function (f) {
          fk(!0, a, b, d, I(f, "target"), I(f, "isTrusted"));
        })
      )
    );
    e = {};
    ek(a, b, "fgi", ((e.id = b.id), e));
    return D([de, c], L);
  });
  function ik(a, b, c, d) {
    return function () {
      if (Xh(a, b)) {
        var e = Va(arguments);
        return d.apply(null, ja(e));
      }
    };
  }
  var jk =
      "button," +
      T(
        ",",
        L(
          function (a) {
            return 'input[type="' + a + '"]';
          },
          ["button", "submit", "reset", "file"]
        )
      ) +
      ",a",
    kk = F(jk, xj),
    lk = {},
    mk =
      ((lk.A = "h"), (lk.BUTTON = "i"), (lk.DIV = "i"), (lk.INPUT = "ty"), lk);
  function nk(a, b, c) {
    var d = I(c, "target");
    if (d) {
      var e = Hj(jk, a, d);
      e || ((d = Hj("div", a, d)) && (xj(jk + ",div", d).length || (e = d)));
      if ((e = (d = gf(e)) && bk(a, e, Rb(["p", mk[d], "c"]), kk))) {
        e = "?" + td(e);
        d = {};
        d = Vh(a, b, "gbn", ((d.id = b.id), (d.query = e), d));
        c = I(c, "isTrusted");
        if (z(c)) c = void 0;
        else {
          var f = {},
            g = {};
          c = ((g.__ym = ((f.ite = Mb(c)), f)), g);
        }
        Mi(a, b, "btn", d).reachGoal(e, c);
      }
    }
  }
  var ok = V("s.f.i", function (a, b) {
      return cj(b, function (c) {
        if (I(c, "settings.button_goals")) {
          c = Xc(a).C(
            a,
            ["click"],
            U(a, "c.t.c", M(D([a, b], ik(a, b, "", nk))))
          );
          var d = {};
          Vh(a, b, "gbi", ((d.id = b.id), d))();
          return c;
        }
      });
    }),
    pk = {},
    qk =
      ((pk.transaction_id = "id"),
      (pk.item_brand = "brand"),
      (pk.index = "position"),
      (pk.item_variant = "variant"),
      (pk.value = "revenue"),
      (pk.item_category = "category"),
      (pk.item_list_name = "list"),
      pk),
    rk = {},
    sk =
      ((rk.item_id = "id"),
      (rk.item_name = "name"),
      (rk.promotion_name = "coupon"),
      rk),
    tk = {},
    uk = ((tk.promotion_name = "name"), tk),
    vk = {},
    wk =
      ((vk.promotion_name = "name"),
      (vk.promotion_id = "id"),
      (vk.item_id = "product_id"),
      (vk.item_name = "product_name"),
      vk),
    xk =
      "currencyCode add delete remove purchase checkout detail impressions click promoView promoClick".split(
        " "
      ),
    yk = {},
    zk =
      ((yk.view_item = { event: "detail", fa: sk, ta: "products" }),
      (yk.add_to_cart = { event: "add", fa: sk, ta: "products" }),
      (yk.remove_from_cart = { event: "remove", fa: sk, ta: "products" }),
      (yk.begin_checkout = { event: "checkout", fa: sk, ta: "products" }),
      (yk.purchase = { event: "purchase", fa: sk, ta: "products" }),
      (yk.view_item_list = { event: "impressions", fa: sk }),
      (yk.select_item = { event: "click", ta: "products", fa: sk }),
      (yk.view_promotion = { event: "promoView", ta: "promotions", fa: wk }),
      (yk.select_promotion = { event: "promoClick", ta: "promotions", fa: wk }),
      yk);
  function Ak(a, b) {
    var c = {};
    L(function (d) {
      var e = a[d] || qk[d] || d;
      -1 !== Ba(d, "item_category")
        ? ((e = qk.item_category), (c[e] = c[e] ? c[e] + ("/" + b[d]) : b[d]))
        : (c[e] = b[d]);
    }, ec(b));
    return c;
  }
  function Bk(a, b) {
    var c = u(a) ? zk[a] : a;
    if (c) {
      var d = c.event,
        e = c.ta,
        f = void 0 === c.Sd ? "items" : c.Sd,
        g = b.purchase || b,
        h = g[f];
      if (h) {
        c = L(F(c.fa, Ak), h);
        h = {};
        var k = {},
          l = ((k[d] = e ? ((h[e] = c), h) : c), k);
        c = ec(g);
        e &&
          1 < c.length &&
          (l[d].actionField = G(
            function (m, p) {
              if (p === f) return m;
              if ("currency" === p) return (l.currencyCode = g.currency), m;
              m[uk[p] || qk[p] || p] = g[p];
              return m;
            },
            {},
            c
          ));
        return l;
      }
    }
  }
  var Ck = V("dl.w", function (a, b, c) {
    function d() {
      var g = I(a, b);
      (e = w(g) && Fi(a, g, c)) || (f = yf(a, d, 1e3, "ec.dl"));
    }
    var e,
      f = 0;
    d();
    return function () {
      return xf(a, f);
    };
  });
  function Dk(a) {
    var b = I(a, "ecommerce");
    if (A(b))
      return (
        (a = Qb(Vb(xk), ec(b))),
        (a = G(
          function (c, d) {
            c[d] = b[d];
            return c;
          },
          {},
          a
        )),
        0 === ec(a).length ? void 0 : a
      );
  }
  function Ek(a, b) {
    return function (c) {
      var d = Xh(a, b);
      if (d && (d = d.params)) {
        var e = I(c, "ecommerce") || {};
        var f = I(c, "event") || "";
        e = A(e) && u(f) ? Bk(f, e) : void 0;
        if (!e)
          a: {
            e = c;
            !w(c) && rb(a, eb(c)) && (e = Va(e));
            if (w(e)) {
              var g = n(e);
              e = g.next().value;
              f = g.next().value;
              g = g.next().value;
              if (u(f) && A(g) && "event" === e) {
                e = Bk(f, g);
                break a;
              }
            }
            e = void 0;
          }
        if ((c = e || Dk(c)))
          (e = {}),
            Qd(
              a,
              ((e.counterKey = Q(b)), (e.name = "ecommerce"), (e.data = c), e)
            ),
            (e = {}),
            (f = {}),
            d(((f.__ym = ((e.ecommerce = [c]), e)), f));
      }
    };
  }
  function Fk(a, b, c) {
    var d;
    a = [
      Ck(a, b, function (e) {
        d = e;
        e.Ba.C(c);
      }),
      function () {
        d && d.unsubscribe();
      },
    ];
    return D([de, a], L);
  }
  var Gk = V("p.e", function (a, b) {
    if (Xh(a, b)) {
      var c = P(a),
        d = U(a, "h.ee", Ek(a, b));
      return b.Db
        ? (c.B("ecs", 0), Fk(a, b.Db, d))
        : cj(b, function (e) {
            if ((e = I(e, "settings.ecommerce")) && u(e))
              return c.B("ecs", 1), Fk(a, e, d);
          });
    }
  });
  function Hk(a, b, c, d, e, f) {
    e = void 0 === e ? -1 : e;
    f = void 0 === f ? !1 : f;
    d = y(d)
      ? d(b)
        ? a.NodeFilter.FILTER_ACCEPT
        : a.NodeFilter.FILTER_REJECT
      : a.NodeFilter.FILTER_ACCEPT;
    if (y(c) && (f || d === a.NodeFilter.FILTER_ACCEPT) && (d && c(b), !Re(b)))
      for (
        a = a.document.createTreeWalker(b, e, null, !1);
        a.nextNode() && !1 !== c(a.currentNode);

      );
  }
  var Ik = K(function (a) {
      a = R(a);
      a = sd(a.search.substring(1));
      return { id: ub(a["_ym_status-check"] || ""), lang: a._ym_lang || "ru" };
    }),
    Jk = cd("giss", Nd);
  function Kk(a, b, c) {
    c = void 0 === c ? {} : c;
    var d = Jk(a);
    d[b] || (d[b] = { qe: nh(a, O(c, { src: b })), state: 0 });
    return d[b];
  }
  function Lk(a, b, c, d, e) {
    function f() {
      h.state = 1;
      c();
    }
    function g() {
      h.state = 2;
      d && d();
    }
    e = void 0 === e ? {} : e;
    var h = Kk(a, b, e);
    b = h.qe;
    e = h.state;
    b && 2 !== e
      ? 1 === e
        ? f()
        : ((a = Xc(a)), a.C(b, ["load"], f), a.C(b, ["error"], g))
      : g();
  }
  var Mk = V("suid.int", function (a, b) {
    var c = {};
    return (
      (c.setUserID = function (d, e, f) {
        if (u(d) || rb(a, d)) {
          var g = Xh(a, b);
          d = fb(["__ym", "user_id", d]);
          g.params(d, e || r, f);
        } else Th(a, Q(b)).error("wuid");
      }),
      c
    );
  });
  function Nk(a, b) {
    return {
      S: function (c, d) {
        var e = Xh(a, b);
        e = e && e.userParams;
        var f = (c.H || {}).nc;
        e && f && e(f);
        d();
      },
    };
  }
  var Ok = V("up.int", function (a, b) {
      var c = {};
      return (
        (c.userParams = U(a, "up.c", function (d, e, f) {
          var g = Xh(a, b),
            h = Th(a, Q(b)).warn;
          g
            ? A(d)
              ? ((h = {}),
                (d = ((h.__ymu = d), h)),
                (g = g.params) && g(d, e || r, f))
              : h("wup")
            : h("nci");
        })),
        c
      );
    }),
    Pk = /[\*\.\?\(\)]/g,
    Qk = K(function (a, b, c) {
      try {
        var d = c.replace("\\s", " ").replace(Pk, "");
        b = {};
        Th(a, "").warn("nnw", ((b.name = d), b));
      } catch (e) {}
    }, mb),
    Rk = V("r.nn", function (a) {
      Md(a) &&
        Fi(a, ua, function (b) {
          b.Ba.C(function (c) {
            var d = n(c);
            c = d.next().value;
            d = d.next().value;
            Qk(a, d, c);
            ua.splice(100);
          });
        });
    });
  function Sk(a, b) {
    return {
      K: function (c, d) {
        eg(c)
          ? d()
          : cj(b, function (e) {
              if ((e = I(e, "settings.hittoken"))) {
                var f = {};
                e = ((f.hittoken = e), f);
                c.D = O(c.D || {}, e);
              }
              d();
            });
      },
    };
  }
  var Tk = K(Nd, Q),
    Uk = V("fpi", function (a) {
      var b = he(a);
      if (b && !a.document.hidden) {
        var c = P(a).V;
        c("fpe", 1);
        var d = Xc(a).C(
          a,
          ["visibilitychange", "webkitvisibilitychange"],
          function () {
            a.document.hidden && (c("fht", b.now()), d());
          }
        );
      }
    }),
    Vk = K(function (a) {
      a = I(a, "console");
      var b = I(a, "log");
      b = va("log", b) ? B(b, a) : r;
      var c = I(a, "warn");
      c = va("warn", c) ? B(c, a) : b;
      var d = I(a, "error");
      a = va("error", d) ? B(d, a) : b;
      return { log: b, error: a, warn: c };
    }),
    Wk = V("p.cd", function (a) {
      if (Cc(a) || uc(a)) {
        var b = Me(a);
        if (z(b.o("jn"))) {
          b.B("jn", !1);
          var c = a.chrome || wc(a) ? function () {} : /./;
          a = Vk(a);
          c.toString = function () {
            b.B("jn", !0);
            return "Yandex.Metrika counter is initialized";
          };
          a.log("%c%s", "color: inherit", c);
        }
      }
    });
  function Xk(a, b) {
    return Array.prototype.sort.call(b, a);
  }
  var Yk = K(function (a) {
      a = I(a, "navigator.plugins");
      return !!(a && eb(a) && sc(M(J("name"), $a(/Chrome PDF Viewer/)), a));
    }),
    Zk = Ma(function (a, b) {
      return P(b).o(a, null);
    }),
    $k = { "*": "+", "-": "/", Je: "=", "+": "*", "/": "-", "=": "_" };
  function al(a) {
    return a
      ? a.replace(/[+/=]/g, function (b) {
          return $k[b] || b;
        })
      : "";
  }
  function bl(a) {
    var b = "",
      c = 0;
    if (!a) return "";
    for (; a.length % 4; ) a += "=";
    do {
      var d = Ca(
          "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",
          a.charAt(c++)
        ),
        e = Ca(
          "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",
          a.charAt(c++)
        ),
        f = Ca(
          "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",
          a.charAt(c++)
        ),
        g = Ca(
          "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",
          a.charAt(c++)
        );
      if (0 > d || 0 > e || 0 > f || 0 > g) return "";
      var h = (d << 18) | (e << 12) | (f << 6) | g;
      d = (h >> 16) & 255;
      e = (h >> 8) & 255;
      h &= 255;
      b =
        64 === f
          ? b + String.fromCharCode(d)
          : 64 === g
          ? b + String.fromCharCode(d, e)
          : b + String.fromCharCode(d, e, h);
    } while (c < a.length);
    return b;
  }
  function cl(a) {
    var b = void 0 === b ? !1 : b;
    for (var c = a.length, d = c - (c % 3), e = [], f = 0; f < d; f += 3) {
      var g = (a[f] << 16) + (a[f + 1] << 8) + a[f + 2];
      e.push(
        "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/="[
          (g >> 18) & 63
        ],
        "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/="[
          (g >> 12) & 63
        ],
        "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/="[
          (g >> 6) & 63
        ],
        "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/="[
          g & 63
        ]
      );
    }
    switch (c - d) {
      case 1:
        a = a[d] << 4;
        e.push(
          "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/="[
            (a >> 6) & 63
          ],
          "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/="[
            a & 63
          ],
          "=",
          "="
        );
        break;
      case 2:
        (a = (a[d] << 10) + (a[d + 1] << 2)),
          e.push(
            "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/="[
              (a >> 12) & 63
            ],
            "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/="[
              (a >> 6) & 63
            ],
            "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/="[
              a & 63
            ],
            "="
          );
    }
    e = T("", e);
    return b ? al(e) : e;
  }
  function dl(a) {
    for (var b = "", c = 0; c < a.length; ) {
      var d = a.charCodeAt(c);
      128 > d
        ? ((b += String.fromCharCode(d)), c++)
        : 191 < d && 224 > d
        ? ((b += String.fromCharCode(
            ((d & 31) << 6) | (a.charCodeAt(c + 1) & 63)
          )),
          (c += 2))
        : ((b += String.fromCharCode(
            ((d & 15) << 12) |
              ((a.charCodeAt(c + 1) & 63) << 6) |
              (a.charCodeAt(c + 2) & 63)
          )),
          (c += 3));
    }
    return b;
  }
  function el(a) {
    for (var b = [], c = 0; c < a.length; c++) {
      var d = a.charCodeAt(c);
      128 > d
        ? b.push(d)
        : (127 < d && 2048 > d
            ? b.push((d >> 6) | 192)
            : (b.push((d >> 12) | 224), b.push(((d >> 6) & 63) | 128)),
          b.push((d & 63) | 128));
    }
    return b;
  }
  function fl(a) {
    return a ? cl(el(a)) : null;
  }
  var gl = K(function (a) {
    return pb(/tizen/i, a);
  });
  function hl(a) {
    if (!gl(a)) return null;
    a = I(a, "webapis.adinfo.getTIFA");
    if (y(a))
      try {
        return fl(a());
      } catch (b) {}
    return null;
  }
  function il(a) {
    if (!gl(a)) return null;
    a = I(a, "tizen.systeminfo.getCapability");
    if (y(a))
      try {
        return fl(a("http://tizen.org/system/tizenid"));
      } catch (b) {}
    return null;
  }
  function jl(a) {
    if (!gl(a)) return null;
    a = I(a, "tizen.systeminfo.getCapabilities");
    try {
      if (y(a)) return fl(I(a(), "duid"));
    } catch (b) {}
    return null;
  }
  var kl = K(function (a) {
    return pb(/webos|web0s/i, a);
  });
  function ll(a) {
    var b = I(a, "webOS.service.request");
    return y(b)
      ? new Y(function (c) {
          var d = {},
            e = {};
          b(
            "luna://com.webos.service.sm",
            ((e.method = "deviceid/getIDs"),
            (e.parameters = ((d.idType = ["LGUDID"]), d)),
            (e.onSuccess = function (f) {
              c(fl(I(f, "idList.0.idValue")));
            }),
            e)
          );
        })
      : Y.resolve(null);
  }
  function ml(a, b) {
    try {
      var c = b.localStorage.getItem(a);
      return c && cl(el(c));
    } catch (d) {}
    return null;
  }
  var nl = K(F("panoramaId", ml)),
    ol = K(function (a) {
      return ml("pubcid.org", a) || ml("_pubCommonId", a);
    }),
    pl = K(F("_sharedid", ml)),
    ql = K(function (a, b) {
      if (b.Aa) return null;
      var c = Kd(a, "").o("_ga");
      return c && cl(el(c));
    }, M(mb, Q)),
    rl = [
      ["domainLookupEnd", "domainLookupStart"],
      ["connectEnd", "connectStart"],
      ["responseStart", "requestStart"],
      ["responseEnd", "responseStart"],
      ["fetchStart", "navigationStart"],
      ["redirectEnd", "redirectStart"],
      [
        function (a, b) {
          return I(b, "redirectCount") || I(a, "navigation.redirectCount");
        },
      ],
      ["domInteractive", "domLoading"],
      ["domContentLoadedEventEnd", "domContentLoadedEventStart"],
      ["domComplete", "navigationStart"],
      ["loadEventStart", "navigationStart"],
      ["loadEventEnd", "loadEventStart"],
      ["domContentLoadedEventStart", "navigationStart"],
    ],
    sl = [
      ["domainLookupEnd", "domainLookupStart"],
      ["connectEnd", "connectStart"],
      ["responseStart", "requestStart"],
      ["responseEnd", "responseStart"],
      ["fetchStart"],
      ["redirectEnd", "redirectStart"],
      ["redirectCount"],
      ["domInteractive", "responseEnd"],
      ["domContentLoadedEventEnd", "domContentLoadedEventStart"],
      ["domComplete"],
      ["loadEventStart"],
      ["loadEventEnd", "loadEventStart"],
      ["domContentLoadedEventStart"],
    ],
    tl = {},
    ul =
      ((tl.responseEnd = 1),
      (tl.domInteractive = 1),
      (tl.domContentLoadedEventStart = 1),
      (tl.domContentLoadedEventEnd = 1),
      (tl.domComplete = 1),
      (tl.loadEventStart = 1),
      (tl.loadEventEnd = 1),
      (tl.unloadEventStart = 1),
      (tl.unloadEventEnd = 1),
      (tl.secureConnectionStart = 1),
      tl),
    vl = K(Od);
  function wl(a, b, c) {
    return L(function (d) {
      var e = n(d),
        f = e.next().value;
      e = e.next().value;
      if (y(f)) return f(a, b) || null;
      if (1 === d.length) return b[f] ? Math.round(b[f]) : null;
      var g;
      !(g = b[f] && b[e]) &&
        (g = 0 === b[f] && 0 === b[e]) &&
        ((g = n(d)),
        (d = g.next().value),
        (g = g.next().value),
        (g = !(ul[d] || ul[g])));
      if (!g) return null;
      f = Math.round(b[f]) - Math.round(b[e]);
      return 0 > f || 36e5 < f ? null : f;
    }, c);
  }
  function xl(a, b) {
    var c = a.length
      ? L(function (d, e) {
          var f = b[e];
          return f === d ? null : f;
        }, a)
      : b;
    a.length = 0;
    L(M(lb, Za("push", a)), b);
    return Qb(Oa(null), c).length === a.length ? null : c;
  }
  function yl(a, b, c) {
    if ((void 0 === c.D ? {} : c.D).nohit) return null;
    a = he(a);
    if (!a) return null;
    var d = (c = null);
    I(a, "getEntriesByType") &&
      (d = I(a.getEntriesByType("navigation"), "0")) &&
      (c = sl);
    if (!c) {
      var e = I(a, "timing");
      e && ((c = rl), (d = e));
    }
    if (!c) return null;
    a = wl(a, d, c);
    b = Q(b);
    b = vl(b);
    return (b = xl(b, a)) && T(",", b);
  }
  var zl = K(Nd),
    Al = K(function (a) {
      var b = I(a, "webkitRequestFileSystem");
      if (y(b) && !Cc(a))
        return new Y(B(b, a, 0, 0))
          .then(function () {
            var d = I(a, "navigator.storage") || {};
            return d.estimate ? d.estimate() : {};
          })
          .then(function (d) {
            return (d = d.quota) && 12e7 > d ? !0 : !1;
          })
          ["catch"](F(!0, lb));
      if (xb(a)) return Y.resolve(Sa(I(a, "navigator.serviceWorker")));
      b = I(a, "openDatabase");
      if (wc(a) && y(b)) {
        var c = !1;
        try {
          b(null, null, null, null);
        } catch (d) {
          c = !0;
        }
        return Y.resolve(c);
      }
      return Y.resolve(
        !I(a, "indexedDB") && (I(a, "PointerEvent") || I(a, "MSPointerEvent"))
      );
    });
  function Bl(a) {
    if (zc(a)) return null;
    var b = zl(a),
      c = b.Tc;
    Sa(c) &&
      ((b.Tc = null),
      Al(a).then(function (d) {
        b.Tc = d;
      }));
    return c ? 1 : null;
  }
  var Cl = /(\?|&)turbo_uid=([\w\d]+)($|&)/,
    Dl = K(function (a, b) {
      var c = Ld(a),
        d = R(a).search.match(Cl);
      return d && 2 <= d.length
        ? ((d = n(d)),
          d.next(),
          d.next(),
          (d = d.next().value),
          b.Aa || c.B("turbo_uid", d),
          d)
        : (c = c.o("turbo_uid"))
        ? c
        : "";
    });
  function El(a) {
    return !z(a) && 1 === a.nodeType;
  }
  function Fl(a, b) {
    if (z(b)) return !1;
    if (Re(b)) return Fl(a, b.parentNode);
    if (!El(b)) return !1;
    var c = Ye(a);
    if (!c) return !1;
    var d = c.call(b, ".ym-hide-content,.ym-hide-content *");
    return d &&
      c.call(b, ".ym-show-content,.ym-hide-content .ym-show-content *")
      ? !1
      : d;
  }
  var Gl = ["password", "passwd", "pswd"],
    Hl = xa(String.prototype.repeat, "repeat");
  function Il(a, b) {
    for (var c = "", d = 0; d < b; d += 1) c += a;
    return c;
  }
  var Jl = Hl
      ? function (a, b) {
          return Hl.call(a, b);
        }
      : Il,
    Kl = F(!0, function (a, b, c, d) {
      c = b.length && (c - d.length) / b.length;
      if (0 >= c) return d;
      b = Jl(b, c);
      return a ? b + d : d + b;
    });
  function Ll(a, b, c) {
    wa("requestIdleCallback", a.requestIdleCallback) &&
    wa("cancelIdleCallback", a.cancelIdleCallback)
      ? a.requestIdleCallback(U(a, c + ".sdl.ric", b), { timeout: 1e3 })
      : yf(a, b, 1e3, c + ".sdl");
  }
  var Ml = V("pa.plgn", function (a, b) {
      var c = Ci(a, b);
      c &&
        c.ca.C(
          ["pluginInfo"],
          U(a, "c.plgn", function () {
            var d = P(a);
            d.B("cmc", d.o("cmc", 0) + 1);
            return gh(b);
          })
        );
    }),
    Nl = K(function (a) {
      return { Me: a, Ha: null, Ka: [] };
    });
  function Ol(a, b, c, d) {
    var e = Pl;
    if (I(d, "settings.ifd"))
      return (
        (a = P(a)),
        (e = a.o("ifdp", {})),
        (c = Q(c)),
        e[c] || ((e[c] = 1), a.B("ifdp", e)),
        null
      );
    c = Nl(e);
    N(b, c.Ka) || c.Ka.push(b);
    if (Ra(c.Ha)) {
      b = Ue(a);
      if (!b) return null;
      b = b("iframe");
      O(b.style, {
        display: "none",
        width: "1px",
        height: "1px",
        visibility: "hidden",
      });
      b.src = e;
      a = $e(a);
      if (!a) return null;
      a.appendChild(b);
      c.Ha = b;
    } else (a = I(c.Ha, "contentWindow")) && a.postMessage("frameReinit", "*");
    return c.Ha;
  }
  function Ql(a) {
    var b = Nl(Pl);
    N(a, b.Ka) &&
      ((b.Ka = Qb(M(Oa(a), nb), b.Ka)),
      b.Ka.length || (Ve(b.Ha), (b.Ha = null)));
  }
  var Rl = M(u, D([1, null], Kb)),
    Sl = /^https?:\/\//,
    Tl = {
      1882689622: 1,
      2318205080: 1,
      3115871109: 1,
      1996539654: 1,
      2065498185: 1,
      823651274: 1,
      12282461: 1,
      1555719328: 1,
      1417229093: 1,
      138396985: 1,
    };
  function Ul(a) {
    a = n(a.replace(Sl, "").split("?")).next().value;
    var b = a + "?",
      c = Wj(b);
    if (ta[c]) return [b, c, !0];
    b = Wj(a);
    return ta[b] ? [a, b, !0] : [a, b, !1];
  }
  var Vl = K(function (a) {
    a = he(a);
    if (!a || !y(a.getEntriesByType)) return null;
    a = a.getEntriesByType("resource");
    return (a = Qe(M(J("name"), Ul, J("2")), a)) ? Mb(a.transferSize) : null;
  });
  function Wl(a, b) {
    var c = Xk(function (d, e) {
      return d[1].T > e[1].T ? 1 : -1;
    }, dc(Be));
    c = L(function (d) {
      var e = n(d);
      d = e.next().value;
      var f = e.next().value.rb;
      e = H(b, d) && !z(b[d]);
      d = b[d] !== (f || lb)(void 0);
      return Mb(e && d);
    }, c);
    return vb(T("", c));
  }
  var Xl = {},
    Yl =
      ((Xl.navigate = 0),
      (Xl.reload = 1),
      (Xl.back_forward = 2),
      (Xl.prerender = 3),
      Xl),
    Zl = K(function (a) {
      var b = he(a);
      if (!b) return null;
      var c = y(b.getEntriesByType)
        ? b.getEntriesByType("navigation")[0]
        : null;
      if (c) return (a = I(c, "type")) && H(Yl, a) ? Yl[a] : null;
      b = I(b, "navigation.type");
      return rb(a, b) && 2 >= b ? b : null;
    }),
    $l = "ar:1:pv:1:v:2720:vf:" + sa.version;
  function am(a, b, c) {
    var d = "https://" + Sd + "/watch/" + c;
    try {
      var e = n(b),
        f = n(e.next().value);
      f.next();
      var g = f.next().value;
    } catch (h) {
      return function () {
        return Y.resolve();
      };
    }
    return function (h) {
      var k = {};
      k =
        ((k["browser-info"] = $l),
        (k["page-url"] = a.location && "" + a.location.href),
        k);
      return g && (h = Fe(a, h))
        ? g(d, { Da: k, N: [], O: "site-info=" + qd(h) })["catch"](r)
        : Y.resolve();
    };
  }
  var bm = {};
  function cm(a, b) {
    return {
      K: function (c, d) {
        var e = c.D,
          f = c.G;
        !bm[b.id] &&
          f.o("pv") &&
          b.exp &&
          !e.nohit &&
          ((e.exp = b.exp), (bm[b.id] = !0));
        d();
      },
    };
  }
  var dm = V("exps.int", function (a, b) {
      var c = {};
      return (
        (c.experiments = function (d, e, f) {
          if (u(d) && !(0 >= d.length)) {
            var g = Ph(a, "e", b),
              h = Wh(b).url,
              k = {},
              l = {};
            d = g(
              {
                G: $g(((k.ex = 1), (k.ar = 1), k)),
                D: ((l["page-url"] = h || R(a).href), (l.exp = d), l),
              },
              b
            );
            return Rh(a, "exps.s", d, e || r, f);
          }
        }),
        c
      );
    }),
    em = [],
    fm = V("p.fh", function (a, b) {
      b = void 0 === b ? !0 : b;
      var c = Me(a),
        d = W(a),
        e = c.o("wasSynced"),
        f = { id: 3, M: "0" };
      if (b && e && e.time + 864e5 > d(mf)) return Y.resolve(e);
      e = {};
      var g = {};
      return Ph(
        a,
        "f",
        f
      )(
        {
          G: $g(((e.pv = 1), e)),
          D:
            ((g["page-url"] = R(a).href),
            (g["page-ref"] = a.document.referrer),
            g),
        },
        f
      )
        .then(function (h) {
          var k = {};
          h = ((k.time = d(mf)), (k.params = I(h, "settings")), k);
          c.B("wasSynced", h);
          return h;
        })
        ["catch"](U(a, "f.h"));
    }),
    gm = Ma(function (a, b) {
      var c,
        d = new Y(function (f) {
          c = f;
        }),
        e = {};
      d = ((e[a] = { Xb: c, promise: d, Yb: !1 }), e);
      b[a] = d[a];
      return Qa(d);
    });
  function hm(a, b) {
    $i("hidv2")(Zi(Q(a))).then(b);
  }
  function im(a, b) {
    return {
      K: function (c, d) {
        hm(b, function (e) {
          if (e) {
            c.D || (c.D = {});
            var f = {};
            O(c.D, ((f.hidv2 = e), f));
          }
          d();
        });
      },
    };
  }
  function jm(a, b) {
    return {
      K: function (c, d) {
        c.H || (c.H = {});
        var e = c.H;
        var f = $i("hidv2")(gm(Q(b)));
        e.Td = f;
        d();
      },
      S: function (c, d) {
        var e = I(c.Zb, "settings.hidv2"),
          f = c.H.Td;
        f(Yi(Q(b), e));
        d();
      },
    };
  }
  var km = "et etms w v z i u vf".split(" "),
    lm = Ma(function (a, b) {
      0 === parseFloat(I(b, "settings.c_recp")) &&
        (a.Rb.B("ymoo" + a.X, a.ld(nf)),
        a.Bb && a.Bb.destruct && a.Bb.destruct());
    });
  function mm(a, b) {
    return {
      K: function (c, d) {
        var e = c.D;
        e.wmode = "0";
        e["wv-hit"] = e["wv-hit"] || "" + rf(a);
        e["page-url"] = e["page-url"] || R(a).href;
        var f = {};
        e = {
          ha: { U: "webvisor/" + b.id },
          J: O(c.J || {}, {
            Ca: ((f["Content-Type"] = "text/plain"), f),
            ab: "POST",
          }),
          D: e,
        };
        O(c, e);
        d();
      },
    };
  }
  function nm(a, b, c) {
    var d = Lh(a, b, "p", ["f", "x"]);
    b = rg(a, c || "p", b);
    var e = jh(a, d, b);
    return function (f) {
      f = O({ J: { N: ["mms.p"] } }, f);
      return e(f);
    };
  }
  var om =
      "resize scroll mousemove mousedown click windowfocus keydown orientationchange change focus touchmove touchstart".split(
        " "
      ),
    pm =
      "id pageTitle stamp chars authors updateDate publicationDate pageUrlCanonical topics rubric".split(
        " "
      );
  function qm(a, b, c, d, e) {
    var f = this;
    this.ob = !1;
    this.oa = {};
    this.scroll = { x: 0, y: 0 };
    this.lb = this.Oc = 0;
    this.Ub = this.Sc = "";
    this.P = [];
    this.cc = this.yb = 0;
    this.Na = { jb: 0, w: 0 };
    this.buffer = [];
    this.yd = pm;
    this.flush = function () {
      f.cc = yf(f.l, f.flush, 2500, "pub.f");
      var g = f.Ib();
      if (f.buffer.length || g) {
        var h = pc(f.buffer);
        g && h.push(g);
        f.Sc = f.Ub;
        f.te.ra(h)(
          Bf(U(f.l, "p.b.st"), function (k) {
            k && f.se(k);
          })
        );
      }
    };
    this.se = d;
    this.te = c;
    this.bb = B(this.bb, this);
    this.Ib = B(this.Ib, this);
    this.flush = B(this.flush, this);
    this.l = a;
    this.X = e;
    this.vb = b;
    this.Pb = "pai" + b.id;
    rm(this);
    this.Bc = Xc(this.l);
    this.time = W(this.l);
    sm(this);
    this.Jb = P(this.l);
    this.lc = null;
  }
  aa = qm.prototype;
  aa.start = function () {
    this.cc = yf(this.l, this.flush, 2500, "pub.s");
    if (!this.ob) {
      this.Bc.C(this.l, om, this.bb);
      var a = this.Jb.o(this.Pb, []),
        b = !a.length;
      a.push(B(this.Zd, this));
      this.Jb.V(this.Pb, a);
      b && this.Vc();
      this.lc = Xc(this.l).C(this.l, ["click"], B(this.ue, this));
      this.bb({ type: "page", target: this.l });
    }
  };
  aa.stop = function () {
    this.lc && this.lc();
    this.Bc.ua(this.l, om, this.bb);
    this.ob = !0;
    this.flush();
    xf(this.l, this.cc);
  };
  aa.Vc = function () {
    var a = this;
    U(this.l, "p.ic" + this.vb.id, function () {
      if (!a.ob) {
        var b = a.Jb.o(a.Pb),
          c = tm(a.vb);
        L(function (d) {
          var e = L(function (f) {
            return O({}, f);
          }, c);
          y(d) && d(e);
        }, b);
        a.yb = yf(a.l, B(a.Vc, a), 1e3, "p");
      }
    })();
  };
  aa.Zd = function (a) {
    this.ob || (um(this, a), vm(this), wm(this));
  };
  aa.Fd = function (a, b) {
    return (a.ac || 0) <= (b.ac || 0) ? b : a;
  };
  aa.ue = function (a) {
    if (this.P.length) {
      a = Ti(a);
      var b = R(this.l).hostname;
      a &&
        jd(a.hostname) === jd(b) &&
        ((a = G(this.Fd, this.P[0], this.P).id),
        (b = rf(this.l)),
        Ne(this.l, this.X.split(":")[0]).B("pai", a + "-" + b));
    }
  };
  aa.bb = function (a) {
    var b = this;
    U(this.l, "p.ec." + this.vb.id, function () {
      try {
        var c = a.type;
        var d = a.target;
      } catch (h) {
        return;
      }
      var e = "page" === c;
      ("scroll" === c || e) &&
        N(d, [b.l, b.l.document, b.l.document.documentElement, Ze(b.l)]) &&
        rm(b);
      ("resize" === c || e) && sm(b);
      c = b.time(mf);
      var f = Math.min(c - b.Oc, 5e3);
      b.lb += Math.round(f);
      b.Oc = c;
      if (b.oa && b.scroll && b.Na) {
        var g = b.Na.jb * b.Na.w;
        b.P = L(function (h) {
          var k = O({}, h),
            l = b.oa[k.id],
            m = ef(h.Qa);
          if (
            !l ||
            Hj("html", b.l, k.element) !== b.l.document.documentElement ||
            !m
          )
            return k;
          h = b.l.Math;
          l = h.max((b.scroll.y + b.Na.jb - l.y) / l.height, 0);
          var p = m.height * m.width,
            q = b.Na,
            v = m.top,
            t = m.bottom,
            x = m.left,
            E = q.w;
          q = q.jb;
          var C = b.l.Math;
          m = C.min(C.max(m.right, 0), E) - C.min(C.max(x, 0), E);
          m *= C.min(C.max(t, 0), q) - C.min(C.max(v, 0), q);
          k.ac = m / g;
          k.visibility = m / p;
          if (0.9 <= k.visibility || 0.1 <= k.ac) k.involvedTime += f;
          k.maxScrolled = h.round(1e4 * l) / 1e4;
          return k;
        }, b.P);
        c = {};
        d = {};
        Qd(
          b.l,
          ((d.name = "publishers"),
          (d.counterKey = b.X),
          (d.data =
            ((c.involvedTime = b.lb),
            (c.contentItems = L(function (h) {
              var k = {};
              return O(((k.contentElement = h.Qa), k), h);
            }, b.P)),
            c)),
          d)
        );
      }
    })();
  };
  function um(a, b) {
    var c = L(function (d) {
      return d.id;
    }, a.P);
    a.P = a.P.concat(
      Qb(function (d) {
        return !N(d.id, c);
      }, b)
    );
  }
  function sm(a) {
    var b = n(af(a.l) || bf(a.l)),
      c = b.next().value;
    b = b.next().value;
    a.Na = { w: c, jb: b };
  }
  function vm(a) {
    U(a.l, "p.um." + a.vb.id, function () {
      var b = [];
      rm(a);
      a.oa = G(
        function (c, d) {
          if (Hj("html", a.l, d.element) !== a.l.document.documentElement)
            return b.push(d), delete c[d.id], c;
          var e = {};
          e =
            ((e.id = d.id),
            (e.involvedTime = Math.max(d.involvedTime, 0)),
            (e.maxScrolled = d.maxScrolled || 0),
            (e.chars = d.update ? d.update("chars") || 0 : 0),
            e);
          if (d.Qa) {
            var f = ef(d.Qa);
            f &&
              ((e.x = Math.max(Math.round(f.left) + a.scroll.x, 0)),
              (e.y = Math.max(Math.round(f.top) + a.scroll.y, 0)),
              (e.width = Math.round(f.width)),
              (e.height = Math.round(f.height)));
          }
          c[d.id] = e;
          return c;
        },
        {},
        a.P
      );
      L(function (c) {
        c = nc(a.l)(c, a.P);
        a.P.splice(c, 1);
      }, b);
    })();
  }
  aa.Ib = function () {
    var a = L(F(this.oa, I), ec(this.oa));
    if (a.length && ((this.Ub = Fe(this.l, a)), this.Sc !== this.Ub)) {
      var b = {},
        c = {};
      return (
        (c.type = "publishersHeader"),
        (c.data = ((b.articleMeta = a || []), (b.involvedTime = this.lb), b)),
        c
      );
    }
    return null;
  };
  function wm(a) {
    if (a.P.length) {
      var b = L(
        function (c) {
          var d = G(
            function (f, g) {
              c[g] && (f[g] = c[g]);
              return f;
            },
            {},
            a.yd
          );
          c.bd = !0;
          var e = {};
          return (e.type = "articleInfo"), (e.stamp = d.stamp), (e.data = d), e;
        },
        Qb(function (c) {
          return !c.bd;
        }, a.P)
      );
      b.length && ((a.buffer = a.buffer.concat(b)), Uh(a.l, a.X, ["pdf", b]));
    }
  }
  function rm(a) {
    a.scroll = {
      x: a.l.pageXOffset || I(a.l, "document.documentElement.scrollLeft") || 0,
      y: a.l.pageYOffset || I(a.l, "document.documentElement.scrollLeft") || 0,
    };
  }
  var xm = {},
    zm = ((xm[1] = 500), (xm[2] = 500), (xm[3] = 0), xm);
  function Am(a, b, c) {
    var d = b.getAttribute("itemtype");
    c = xj('[itemprop~="' + c + '"]', b);
    return d
      ? Qb(function (e) {
          return e.parentNode && Hj("[itemtype]", a, e.parentNode) === b;
        }, c)
      : c;
  }
  function Bm(a, b, c) {
    return (a = Am(a, b, c)) && a.length ? a[0] : null;
  }
  function Cm(a) {
    if (!a) return "";
    a = w(a) ? a : [a];
    return a.length ? a[0].getAttribute("content") || Se(a[0]) : "";
  }
  function Dm(a) {
    return a
      ? a.attributes && a.getAttribute("datetime")
        ? a.getAttribute("datetime")
        : Cm(a)
      : "";
  }
  var Em = ["topics", "rubric", "authors"];
  function Fm(a, b) {
    var c = this;
    this.id = "a";
    this.Kb = !1;
    this.Ta = {};
    this.Ma = {
      "schema.org":
        "Article NewsArticle Movie BlogPosting Review Recipe Answer".split(" "),
      Qc: ["article"],
    };
    var d = {};
    this.$a = ((d.Answer = 3), (d.Review = 2), d);
    this.Ec = K(
      function (e, f, g) {
        var h = {};
        Uh(
          c.l,
          c.X,
          "pfi",
          ((h.field = e), (h.itemField = f), (h.value = g), h)
        );
      },
      function (e, f, g) {
        return "" + e + f + g;
      }
    );
    this.Ee = function (e) {
      L(function (f) {
        e[f] &&
          (e[f] = G(
            function (g, h) {
              var k = h.name,
                l = h.position;
              if (!k) return c.Ec(f, "name", k), g;
              if ("string" === typeof l) {
                k = sb(l);
                if (null === k || c.l.isNaN(k))
                  return c.Ec(f, "position", l), g;
                h.position = k;
              }
              g.push(h);
              return g;
            },
            [],
            e[f]
          ));
      }, Em);
      return e;
    };
    this.Gd = K(function (e, f) {
      var g = {};
      Uh(
        c.l,
        c.X,
        ["pcs", f],
        ((g.chars = f.chars), (g.limit = zm[f.type]), g)
      );
    });
    this.l = a;
    this.root = $e(a);
    this.X = b;
  }
  Fm.prototype.ma = function (a) {
    return a.element;
  };
  function Gm(a, b, c) {
    var d;
    U(a.l, "P.s." + c, function () {
      d = a.Ta[c].call(a, b);
    })();
    return d;
  }
  function Hm(a, b) {
    var c = O({}, b);
    if (a.Kb && !c.id && N(b.type, [3, 2])) {
      var d = T(", ", L(J("name"), c.authors || []));
      c.pageTitle = d + ": " + c.pageTitle;
    }
    if (!c.pageTitle) {
      a: {
        d = c.Qa;
        for (var e = 1; 5 >= e; e += 1) {
          var f = Cm(yj("h" + e, d));
          if (f) {
            d = f;
            break a;
          }
        }
        d = void 0;
      }
      c.pageTitle = d;
    }
    c.pageUrlCanonical ||
      ((d = c.id),
      (d = ("string" !== typeof d ? 0 : /^(https?:)\/\//.test(d))
        ? c.id
        : (d = yj('[rel="canonical"]', a.root))
        ? d.href
        : void 0),
      (c.pageUrlCanonical = d));
    c.id || (c.id = c.pageTitle || c.pageUrlCanonical);
    return c;
  }
  Fm.prototype.ea = function (a) {
    var b = this,
      c = {},
      d = this.ma(a);
    if (!d) return null;
    c.type = a.type;
    L(function (f) {
      c[f] = Gm(b, a, f);
    }, ec(this.Ta));
    var e = W(this.l);
    c.stamp = e(pf);
    c.element = a.element;
    c.Qa = d;
    c = this.Ee(Hm(this, c));
    c.id = c.id ? Wj(c.id) : 1;
    c.update = function (f) {
      return b.ma(a) ? Gm(b, a, f) : void 0;
    };
    return c;
  };
  Fm.prototype.getType = function () {
    return 1;
  };
  Fm.prototype.ib = function () {
    return [];
  };
  function tm(a) {
    var b = a.ib(),
      c = 1;
    return G(
      function (d, e) {
        var f = a.ea({ element: e, type: a.getType(e) }) || [];
        w(f) || (f = [f]);
        f = G(
          function (g, h) {
            var k = g.values,
              l = g.Ic;
            h && h.chars > zm[h.type] && !N(h.id, l)
              ? (k.push(h), l.push(h.id))
              : h && h.chars <= zm[h.type] && a.Gd(h.id, h);
            return { values: k, Ic: l };
          },
          { values: [], Ic: L(J("id"), d) },
          f
        ).values;
        return d.concat(
          L(function (g) {
            var h = {};
            g = O(((h.index = c), (h.bd = !1), (h.involvedTime = 0), h), g);
            c += 1;
            return g;
          }, f)
        );
      },
      [],
      b
    );
  }
  function Im() {
    Fm.apply(this, arguments);
    this.id = "j";
    this.Kb = !0;
    this.xc = T(",", [
      'script[type="application/ld+json"]',
      'script[type="application/json+ld"]',
      'script[type="ld+json"]',
      'script[type="json+ld"]',
    ]);
    var a = {};
    this.Ta =
      ((a.id = function (b) {
        var c = b.data["@id"];
        b = b.data.mainEntity || b.data.mainEntityOfPage;
        !c && A(b) && (c = b["@id"]);
        return c;
      }),
      (a.chars = function (b) {
        var c = b.data;
        return u(c.text) ? c.text.length : Se(this.ma(b)).length;
      }),
      (a.authors = function (b) {
        b = b.data;
        var c = [];
        c = c.concat(Jm(b, "author"));
        c = c.concat(Jm(b.mainEntity, "author"));
        return c.concat(Jm(b.mainEntityOfPage, "author"));
      }),
      (a.pageTitle = function (b) {
        var c = b.data,
          d = c.headline || "";
        c.alternativeHeadline && (d += " " + c.alternativeHeadline);
        "" === d &&
          (c.name ? (d = c.name) : c.itemReviewed && (d = c.itemReviewed));
        3 === b.type && A(c.parentItem) && (d = c.parentItem.text);
        return d;
      }),
      (a.updateDate = function (b) {
        return b.data.dateModified || "";
      }),
      (a.publicationDate = function (b) {
        return b.data.datePublished || "";
      }),
      (a.pageUrlCanonical = function (b) {
        return b.data.url;
      }),
      (a.topics = function (b) {
        return Jm(b.data, "about", ["name", "alternateName"]);
      }),
      (a.rubric = function (b) {
        var c = this,
          d = this.ma(b);
        b = Rb(
          L(function (e) {
            e = Ee(c.l, Se(e));
            if (A(e) || w(e)) {
              var f = Km(e);
              if (f)
                return G(
                  function (g, h) {
                    return g
                      ? g
                      : A(h) && "BreadcrumbList" === h["@type"]
                      ? h
                      : g;
                  },
                  null,
                  f
                );
              if ("BreadcrumbList" === e["@type"]) return e;
            }
            return null;
          }, [b.element].concat(
            xj(
              this.xc,
              this.l.document.body === d ? this.l.document.documentElement : d
            )
          ))
        );
        return b.length && ((b = b[0].itemListElement), w(b))
          ? Rb(
              L(function (e) {
                return A(e) && e.item && A(e.item) && !c.l.isNaN(e.position)
                  ? { name: e.item.name || e.name, position: e.position }
                  : null;
              }, b)
            )
          : [];
      }),
      a);
  }
  qa(Im, Fm);
  function Jm(a, b, c) {
    c = void 0 === c ? ["name"] : c;
    if (!A(a) || !a[b]) return [];
    a = a[b];
    a = w(a) ? a : [a];
    a = Rb(
      L(function (d) {
        return d
          ? "string" === typeof d
            ? d
            : A(d)
            ? G(
                function (e, f) {
                  return e || "" + d[f];
                },
                "",
                c
              )
            : null
          : null;
      }, a)
    );
    return L(function (d) {
      var e = {};
      return (e.name = d), e;
    }, a);
  }
  Im.prototype.ma = function (a) {
    var b = a.element,
      c = a.data || {};
    a = c["@id"];
    var d = c.url;
    c = null;
    d && u(d) && (c = Lm(this, d));
    !c && a && u(a) && (c = Lm(this, a));
    c ||
      ((c = a = b.parentNode),
      !Hj("head", this.l, b) && a && 0 !== Se(a).length) ||
      (c = this.l.document.body);
    return c;
  };
  function Lm(a, b) {
    try {
      var c = ph(a.l, b).hash;
      if (c) {
        var d = a.l.document.getElementById(c.slice(1));
        if (d) return d;
      }
    } catch (e) {}
    return null;
  }
  Im.prototype.ea = function (a) {
    var b = this,
      c = a.element,
      d = a.data;
    if (
      !d &&
      ((d = Ee(this.l, Se(c))),
      !d || (!/schema\.org/.test(d["@context"]) && !w(d)))
    )
      return null;
    var e = Km(d);
    if (e)
      return L(function (g) {
        return A(g) && N(g["@type"], b.Ma["schema.org"])
          ? Fm.prototype.ea.call(b, {
              element: c,
              data: g,
              type: b.$a[g["@type"]] || 1,
            })
          : null;
      }, e);
    a.data = d;
    if ("QAPage" === a.data["@type"]) {
      var f = a.data.mainEntity || a.data.mainEntityOfPage;
      if (!f) return null;
    }
    "Question" === a.data["@type"] && (f = a.data);
    return f
      ? ((a = Fb(F(f, I), ["acceptedAnswer", "suggestedAnswer"])),
        L(function (g) {
          if (!A(g) || !N(g["@type"], b.Ma["schema.org"])) return null;
          var h = {};
          g = {
            element: c,
            type: b.$a[g["@type"]] || 1,
            data: O(((h.parentItem = f), h), g),
          };
          return Fm.prototype.ea.call(b, g);
        }, a))
      : N(a.data["@type"], this.Ma["schema.org"])
      ? Fm.prototype.ea.call(
          this,
          O(a, { type: this.$a[a.data["@type"]] || 1 })
        )
      : null;
  };
  Im.prototype.ib = function () {
    return xj(this.xc, this.root);
  };
  function Km(a) {
    if (w(a)) return a;
    if (a && w(a["@graph"])) return a["@graph"];
  }
  function Mm() {
    Fm.apply(this, arguments);
    this.id = "s";
    this.Kb = !0;
    this.Be = Za(
      "exec",
      new RegExp("schema.org\\/(" + T("|", ec(this.$a)) + ")$")
    );
    var a = {};
    this.Ta =
      ((a.id = function (b) {
        b = b.element;
        var c = Bm(this.l, b, "identifier");
        return c
          ? Cm(c)
          : (c = Bm(this.l, b, "mainEntityOfPage")) && c.getAttribute("itemid")
          ? c.getAttribute("itemid")
          : null;
      }),
      (a.chars = function (b) {
        var c = 0;
        b = b.element;
        for (
          var d = [
              "articleBody",
              "reviewBody",
              "recipeInstructions",
              "description",
              "text",
            ],
            e = 0;
          e < d.length;
          e += 1
        ) {
          var f = Bm(this.l, b, d[e]);
          if (f) {
            c = Cm(f).length;
            break;
          }
        }
        b = Se(b);
        0 === c && b && (c += b.length);
        return c;
      }),
      (a.topics = function (b) {
        var c = this,
          d = Am(this.l, b.element, "about");
        return L(function (e) {
          var f = { name: Cm(e) };
          if ((d = Bm(c.l, e, "name"))) f.name = Cm(d);
          return f;
        }, d);
      }),
      (a.rubric = function (b) {
        var c = this;
        (b = yj('[itemtype$="schema.org/BreadcrumbList"]', b.element)) ||
          (b = yj('[itemtype$="schema.org/BreadcrumbList"]', this.root));
        return b
          ? L(function (d) {
              return {
                name: Cm(Bm(c.l, d, "name")),
                position: Cm(Bm(c.l, d, "position")),
              };
            }, Am(this.l, b, "itemListElement"))
          : [];
      }),
      (a.updateDate = function (b) {
        return (b = Bm(this.l, b.element, "dateModified")) ? Dm(b) : "";
      }),
      (a.publicationDate = function (b) {
        return (b = Bm(this.l, b.element, "datePublished")) ? Dm(b) : "";
      }),
      (a.pageUrlCanonical = function (b) {
        b = Am(this.l, b.element, "url");
        if (b.length) {
          var c = b[0];
          return c.href ? c.href : Cm(b);
        }
        return null;
      }),
      (a.pageTitle = function (b) {
        var c = "",
          d = b.element,
          e = Bm(this.l, d, "headline");
        e && (c += Cm(e));
        (e = Bm(this.l, d, "alternativeHeadline")) && (c += " " + Cm(e));
        "" === c &&
          ((e = Bm(this.l, d, "name")) || (e = Bm(this.l, d, "itemReviewed")),
          e && (c += Cm(e)));
        3 === b.type &&
          (b = Hj('[itemtype$="schema.org/Question"]', this.l, d)) &&
          (b = Bm(this.l, b, "text")) &&
          (c += Cm(b));
        return c;
      }),
      (a.authors = function (b) {
        var c = this;
        b = Am(this.l, b.element, "author");
        return L(function (d) {
          var e = {};
          e = ((e.name = ""), e);
          if (
            /.+schema.org\/(Person|Organization)/.test(
              d.getAttribute("itemtype") || ""
            )
          ) {
            var f = Bm(c.l, d, "name");
            f && (e.name = Cm(f));
          }
          e.name ||
            (e.name =
              d.getAttribute("content") || Se(d) || d.getAttribute("href"));
          return e;
        }, b);
      }),
      a);
  }
  qa(Mm, Fm);
  Mm.prototype.getType = function (a) {
    a = a.getAttribute("itemtype") || "";
    return (a = this.Be(a)) ? this.$a[a[1]] : 1;
  };
  Mm.prototype.ea = function (a) {
    return a.element && Se(a.element).length
      ? Fm.prototype.ea.call(this, a)
      : null;
  };
  Mm.prototype.ib = function () {
    var a = T(
      ",",
      L(function (b) {
        return '[itemtype$="schema.org/' + b + '"]';
      }, this.Ma["schema.org"])
    );
    return xj(a, this.root);
  };
  function Nm(a, b) {
    Fm.call(this, a, b);
    this.id = "o";
    var c = {};
    this.Ta =
      ((c.chars = function (d) {
        d = this.ma(d);
        return Se(d).length;
      }),
      (c.authors = function (d) {
        return Om(d.data.author);
      }),
      (c.pageTitle = function (d) {
        return Pm(d.data.title) || "";
      }),
      (c.updateDate = function (d) {
        return Pm(d.data.modified_time);
      }),
      (c.publicationDate = function (d) {
        return Pm(d.data.published_time);
      }),
      (c.pageUrlCanonical = function (d) {
        return Pm(d.data.url);
      }),
      (c.rubric = function (d) {
        return Om(d.data.section);
      }),
      (c.topics = function (d) {
        return Om(d.data.tag);
      }),
      c);
    this.Nd = new RegExp("^(og:)?((" + T("|", this.Ma.Qc) + "):)?");
  }
  qa(Nm, Fm);
  function Om(a) {
    if (a) {
      if (w(a))
        return L(function (c) {
          var d = {};
          return (d.name = c ? "" + c : null), d;
        }, a);
      var b = {};
      return [((b.name = a ? "" + a : null), b)];
    }
    return [];
  }
  function Pm(a) {
    return w(a) ? (a.length ? "" + a[0] : null) : a ? "" + a : null;
  }
  Nm.prototype.ib = function () {
    var a = xj('meta[property="og:type"]', this.l.document.body);
    return [this.l.document.head].concat(a);
  };
  function Qm(a, b) {
    var c = b.element,
      d = {},
      e = a.ma(b);
    c = xj("meta[property]", c === a.l.document.head ? c : e);
    if (c.length)
      L(function (f) {
        try {
          if (f.parentNode === e || f.parentNode === a.l.document.head) {
            var g = f.getAttribute("property").replace(a.Nd, ""),
              h = Cm(f);
            d[g] ? (w(d[g]) ? d[g].push(h) : (d[g] = [d[g], h])) : (d[g] = h);
          }
        } catch (k) {
          ge(a.l, "og.ed", k);
        }
      }, c);
    else return null;
    return N(d.type, a.Ma.Qc) ? O(b, { data: d }) : null;
  }
  Nm.prototype.ma = function (a) {
    a = a.element;
    var b = this.l.document;
    return a === b.head ? b.body : a.parentNode;
  };
  Nm.prototype.ea = function (a) {
    return (a = Qm(this, a)) ? Fm.prototype.ea.call(this, a) : null;
  };
  function Rm(a) {
    this.l = a;
    this.type = "8";
  }
  Rm.isEnabled = function (a) {
    return !!a.JSON;
  };
  Rm.prototype.ra = function (a) {
    return Ef(Fe(this.l, a));
  };
  var Sm = {};
  Im && (Sm.json_ld = Im);
  Mm && ((Sm.schema = Mm), (Sm.microdata = Mm));
  Nm && (Sm.opengraph = Nm);
  var Tm = V("p.p", function (a, b) {
      var c = new Rm(a);
      if (wa("querySelectorAll", a.document.querySelectorAll) && c) {
        var d = [
          [mm, 0],
          [$f(km), 1],
          [gg, 2],
        ];
        d.push([im, 3]);
        var e = nm(a, b, d);
        d = $g();
        var f = Ne(a, b.id),
          g = f.o("pai");
        g && (f.wa("pai"), d.B("pai", g));
        f = {};
        var h = { D: ((f["wv-type"] = c.type), f), G: d, J: {} },
          k = function (l) {
            for (
              var m = O({}, h), p = l.length, q = 0, v = 255, t = 255, x, E, C;
              p;

            ) {
              x = 21 < p ? 21 : p;
              p -= x;
              do
                (E = "string" === typeof l ? l.charCodeAt(q) : l[q]),
                  (q += 1),
                  255 < E && ((C = E >> 8), (E &= 255), (E ^= C)),
                  (v += E),
                  (t += v);
              while (--x);
              v = (v & 255) + (v >> 8);
              t = (t & 255) + (t >> 8);
            }
            p = (((v & 255) + (v >> 8)) << 8) | ((t & 255) + (t >> 8));
            m.D["wv-check"] = "" + (65535 === p ? 0 : p);
            m.J.O = l;
            return e(m)["catch"](U(a, "s.ww.p"));
          };
        Df(cj(b, J("settings")))(
          Bf(
            U(a, "ps.s"),
            U(a, "ps.sh", function (l) {
              if ((l = I(l, "publisher.schema"))) {
                ui(b) && (l = "microdata");
                var m = Sm[l];
                if (m && c) {
                  var p = Q(b);
                  m = new m(a, p);
                  m = new qm(a, m, c, k, p);
                  m.start();
                  var q = {};
                  Uh(a, p, "ps", ((q.schema = l), q));
                  return B(m.stop, m);
                }
              }
            })
          )
        );
      }
    }),
    Um = xa(Array.prototype.reverse, "reverse");
  function Vm(a) {
    for (var b = [], c = a.length - 1; 0 <= c; --c) b[a.length - 1 - c] = a[c];
    return b;
  }
  var Wm = Um
    ? function (a) {
        return Um.call(a);
      }
    : Vm;
  function Xm() {
    return Math.floor(65536 * (1 + Math.random()))
      .toString(16)
      .substring(1);
  }
  function Ym() {
    return (
      Xm() +
      Xm() +
      "-" +
      Xm() +
      "-" +
      Xm() +
      "-" +
      Xm() +
      "-" +
      Xm() +
      Xm() +
      Xm()
    );
  }
  var Zm = Ma(function (a, b) {
    var c = Math.pow(10, a);
    return Math.round(b * c) / c;
  });
  function $m(a, b, c, d) {
    var e = null;
    return {
      fn: function () {
        var f = ra.apply(0, arguments);
        Ra(e) || xf(a, e);
        e = yf(
          a,
          function () {
            b.apply(null, ja(f));
            e = null;
          },
          c,
          d + ".deb"
        );
      },
      clear: function () {
        Ra(e) || (xf(a, e), (e = null));
      },
    };
  }
  var an = V("fbq.o", function (a, b, c) {
      var d = I(a, "fbq");
      if (d && d.callMethod) {
        var e = function () {
          var g = arguments,
            h = d.apply(null, ja(g));
          b(g);
          return h;
        };
        O(e, d);
        c && L(b, c);
        a.fbq = e;
      } else {
        c = I(d, "queue");
        var f = yf(a, D([a, b, c && mc(c)], an), 1e3, "fbq.d");
      }
      return B(xf, null, a, f);
    }),
    bn = {},
    cn =
      ((bn.add_to_wishlist = "add-to-wishlist"),
      (bn.begin_checkout = "begin-checkout"),
      (bn.generate_lead = "submit-lead"),
      (bn.add_payment_info = "add-payment-info"),
      bn),
    dn = {},
    en =
      ((dn.AddToCart = "add-to-cart"),
      (dn.Lead = "submit-lead"),
      (dn.InitiateCheckout = "begin-checkout"),
      (dn.Purchase = "purchase"),
      (dn.CompleteRegistration = "register"),
      (dn.Contact = "submit-contact"),
      (dn.AddPaymentInfo = "add-payment-info"),
      (dn.AddToWishlist = "add-to-wishlist"),
      (dn.Subscribe = "subscribe"),
      dn),
    fn = {},
    gn = ((fn["1"] = cn), (fn["2"] = cn), (fn["3"] = cn), (fn["0"] = en), fn),
    hn = [en.AddToCart, en.Purchase];
  function jn(a, b) {
    return function (c) {
      if (c) {
        var d = c.version;
        (c = I(gn, d + "." + c.gb)) &&
          ((b && N(c, hn)) || a("ym-" + c + "-" + d));
      }
    };
  }
  var kn = Ma(function (a, b) {
      var c = I(b, "event") || "";
      if (!(c = I(b, "ecommerce") && c && { version: "3", gb: c }))
        a: {
          if (w(b) || eb(b)) {
            var d = n(Va(b));
            c = d.next().value;
            d = d.next().value;
            if ("event" === c && d) {
              c = { version: "2", gb: d };
              break a;
            }
          }
          c = void 0;
        }
      c || (c = (c = I(b, "ecommerce")) && { version: "1", gb: T(",", ec(c)) });
      c && a(c);
    }),
    ln = Ma(function (a, b) {
      if (b) {
        var c = n(Va(b)),
          d = c.next().value;
        c = c.next().value;
        "track" === d && a({ version: "0", gb: c });
      }
    });
  function mn(a, b) {
    if (!b) return "";
    var c = [],
      d = I(a, "document");
    Hk(a, b, function (e) {
      if (e.nodeType === d.TEXT_NODE) var f = e.textContent;
      else
        e instanceof a.HTMLImageElement
          ? (f = e.alt)
          : e instanceof a.HTMLInputElement && (f = e.value);
      (f = f && wd(f)) && c.push(f);
    });
    return 0 === c.length ? "" : T(" ", c);
  }
  var nn = /[^\d.,]/g,
    on = /[.,]$/;
  function pn(a) {
    a = mc(bl(a));
    return L(function (b) {
      b = b.charCodeAt(0).toString(2);
      return Kl("0", 8, b);
    }, a);
  }
  function qn(a, b) {
    var c = null;
    try {
      c = b ? yj(b, a) : c;
    } catch (d) {}
    return c;
  }
  function rn(a, b, c) {
    if ((b = Xh(a, b)))
      (a = fb(["dr", c || "" + kf(a, 10, 99)])), b.params(fb(["__ym", a]));
  }
  var sn = V("ep.pp", function (a, b) {
      if (!b) return 0;
      a: {
        var c = b.replace(nn, "").replace(on, "");
        for (
          var d = "0" === c[c.length - 1], e = c.length;
          0 < e && !(3 < c.length - e + 1 && d);
          --e
        ) {
          var f = c[e - 1];
          if (N(f, [",", "."])) {
            c = f;
            break a;
          }
        }
        c = "";
      }
      c = (d = c) ? b.split(d) : [b];
      d = d ? c[1] : "00";
      c = parseFloat(zd(c[0]) + "." + zd(d));
      d = Math.pow(10, 8) - 0.01;
      a.isNaN(c) ? (c = 0) : ((c = a.Math.min(c, d)), (c = a.Math.max(c, 0)));
      return c;
    }),
    tn = [
      [["EUR", "\u20ac"], "978"],
      [["USD", "\u0423\\.\u0415\\.", "\\$"], "840"],
      [["UAH", "\u0413\u0420\u041d", "\u20b4"], "980"],
      [
        "\u0422\u0413 KZT \u20b8 \u0422\u04a2\u0413 TENGE \u0422\u0415\u041d\u0413\u0415".split(
          " "
        ),
        "398",
      ],
      [["GBP", "\u00a3", "UKL"], "826"],
      [
        "RUR RUB \u0420 \u0420\u0423\u0411 \u20bd P \u0420UB P\u0423\u0411 P\u0423B PY\u0411 \u0420Y\u0411 \u0420\u0423B P\u0423\u0411".split(
          " "
        ),
        "643",
      ],
    ],
    un = K(function (a) {
      return new RegExp(T("|", a), "i");
    }),
    vn = K(function () {
      function a() {
        var k = h + "0",
          l = h + "1";
        f[k]
          ? f[l]
            ? ((h = h.slice(0, -1)), --g)
            : ((e[l] = c(8)), (f[l] = 1))
          : ((e[k] = c(8)), (f[k] = 1));
      }
      function b() {
        var k = h + "1";
        f[h + "0"]
          ? f[k]
            ? ((h = h.slice(0, -1)), --g)
            : ((h += "1"), (f[h] = 1))
          : ((h += "0"), (f[h] = 1));
      }
      function c(k) {
        k = void 0 === k ? 1 : k;
        var l = d.slice(g, g + k);
        g += k;
        return l;
      }
      for (
        var d = T(
            "",
            pn(
              "Cy2FcreLJLpYXW3BXFJqldVsGMwDcBw2BGnHL5uj1TKstzse3piMo3Osz+EqDotgqs1TIoZvKtMKDaSRFztgUS8qkqZcaETgKWM54tCpTXjV5vW5OrjBpC0jF4mspUBQGd95fNSfv+vz+g+Hze33Hg8by+Yen1PP6zsdl7PQCwX9mf+f7FMb9x/Pw+v2Pp8Xy74eTwuBwTt913u4On1XW6hxOO5nIzFam00tC218S0kaeugpqST+XliLOlMoTpRQkuewUxoy4CT3efWtdFjSAAm+1BkjIhyeU4vGOf13a6U8wzNY4bGo6DIUemE7N3SBojDr7ezXahpWF022y8mma1NuTnZbq8XZZlPStejfG/CsbPhV6/bSnA=="
            )
          ),
          e = {},
          f = {},
          g = 1,
          h = "";
        g < d.length - 1;

      )
        ("0" === c() ? b : a)();
      return e;
    }),
    wn = V("ep.dec", function (a, b) {
      if (!b || tc(a)) return [];
      var c = n(pn(b)),
        d = c.next().value,
        e = c.next().value,
        f = c.next().value;
      c = ia(c);
      if (2 !== vb(d)) return [];
      d = vn();
      c = T("", c);
      e = vb(e + f);
      for (var g = (f = ""), h = 0; g.length < e && c[h]; )
        (f += c[h]),
          d[f] && ((g += String.fromCharCode(vb(d[f]))), (f = "")),
          (h += 1);
      d = Ee(a, dl(g));
      return w(d) ? L(Ia, d) : [];
    }),
    xn = V("ep.ent", function (a, b, c) {
      a = "" + kf(a, 10, 99);
      c = "" + 100 * b + c + a;
      if (16 < eb(c)) return "";
      c = Kl("0", 16, c);
      b = c.slice(0, 8);
      c = c.slice(-8);
      b = (+b ^ 92844).toString(35);
      c = (+c ^ 92844).toString(35);
      return "" + b + "z" + c;
    });
  function yn(a, b) {
    var c = qn(a.document.body, b);
    return c ? mn(a, c) : "";
  }
  function zn(a, b) {
    var c = yn(a, b);
    return sn(a, c);
  }
  var An = M(
    yn,
    V("ep.cp", function (a) {
      if (!a) return "643";
      var b = yd(a);
      return (a = Qe(function (c) {
        c = n(c).next().value;
        return un(c).test(b);
      }, tn))
        ? a[1]
        : "643";
    })
  );
  function Bn(a, b, c, d) {
    (c = xn(a, d, c)) && rn(a, b, c);
  }
  var Cn = V("ep.ctp", function (a, b, c, d) {
    var e = An(a, c),
      f = zn(a, d);
    Bn(a, b, e, f);
    wa("MutationObserver", a.MutationObserver) &&
      new a.MutationObserver(function () {
        var g = An(a, c),
          h = zn(a, d);
        if (e !== g || f !== h) (e = g), (f = h), Bn(a, b, e, f);
      }).observe(a.document.body, {
        attributes: !0,
        childList: !0,
        subtree: !0,
        characterData: !0,
      });
  });
  function Dn(a, b, c, d, e) {
    c = qn(a.document.body, c);
    d = qn(a.document.body, d);
    N(e.target, [c, d]) && rn(a, b);
  }
  var En = V("ep.chp", function (a, b, c, d, e) {
    c && rn(a, b);
    return d || e
      ? Xc(a).C(a.document, ["click"], U(a, "ep.chp.cl", D([a, b, d, e], Dn)))
      : r;
  });
  function Fn(a, b) {
    return cj(b, function (c) {
      return {
        Md: wn(a, I(c, "settings.dr")),
        isEnabled: I(c, "settings.auto_goals"),
      };
    });
  }
  function Gn(a, b) {
    if (!b) return !1;
    var c = R(a);
    return new RegExp(b).test("" + c.pathname + c.hash + c.search);
  }
  var Hn = V("ep.i", function (a, b) {
    if (wj(a))
      return Fn(a, b).then(function (c) {
        var d = n(c.Md),
          e = d.next().value,
          f = d.next().value,
          g = d.next().value,
          h = d.next().value,
          k = d.next().value,
          l = d.next().value,
          m = d.next().value,
          p = d.next().value,
          q = d.next().value,
          v = d.next().value,
          t = d.next().value,
          x = d.next().value,
          E = d.next().value,
          C = d.next().value,
          S = d.next().value,
          Z = d.next().value;
        if (!c.isEnabled) return Y.resolve(r);
        var Yc = Gn(a, e),
          Tq = Gn(a, h),
          Uq = Gn(a, m),
          Vq = Gn(a, q),
          Wq = "" + e + f + g === "" + h + k + l;
        return new Y(function (Xq, Yq) {
          Ff(
            a,
            "ecp"
          )(
            Bf(Yq, function () {
              Yc && Cn(a, b, f, g, t, x, E);
              Tq && !Wq && Cn(a, b, k, l, C, S, Z);
              Xq(En(a, b, Uq || Vq, p, v));
            })
          );
        });
      });
  });
  function In(a, b) {
    var c = We(a, b),
      d = bd(a);
    if (c && Xe("ym-advanced-informer", c)) {
      var e = d.o("ifc", 0) + 1;
      d.B("ifc", e);
      e = c.getAttribute("data-lang");
      var f = ub(c.getAttribute("data-cid") || "");
      if (f || 0 === f) {
        var g = I(a, "Ya." + Rd + ".informer");
        g
          ? ((d = {}), g(((d.i = c), (d.id = f), (d.lang = e), d)))
          : d.B("ib", !0);
        c = b || window.event;
        c.preventDefault ? c.preventDefault() : (c.returnValue = !1);
      }
    }
  }
  function Jn(a) {
    var b = U(a, "i.clch", In);
    Xc(a).C(a.document, ["click"], F(a, b), { passive: !1 });
    return function (c) {
      var d = a.Ya[Rd],
        e = !!d._informer;
      d._informer = O({ domain: Sd }, c);
      e || Lk(a, "https://" + Sd + "/metrika/informer.js", r);
    };
  }
  var Kn = V("pr.p", function (a, b) {
      if (Oc(a)) {
        var c = Ph(a, "5", b),
          d = {};
        d = $g(((d.pq = 1), (d.ar = 1), d));
        var e = {};
        c(
          {
            G: d,
            D:
              ((e["page-url"] = R(a).href),
              (e["page-ref"] = I(a, "document.referrer") || ""),
              e),
          },
          b
        )["catch"](U(a, "pr.p.s"));
      }
    }),
    Ln = !1;
  function Mn(a) {
    return {
      K: function (b, c) {
        if (!b.G) return c();
        var d = P(a).o("fid");
        !Ln && d && (re(b, "fid", d), (Ln = !0));
        return c();
      },
    };
  }
  var Nn = V("fid", function (a) {
      var b = r;
      if (!y(a.PerformanceObserver)) return b;
      var c = P(a);
      if (c.o("fido")) return b;
      c.B("fido", !0);
      var d = new a.PerformanceObserver(
        U(a, "fid", function (f) {
          f = f.getEntries()[0];
          c.B("fid", a.Math.round(100 * (f.processingStart - f.startTime)));
          b();
        })
      );
      b = function () {
        return d.disconnect();
      };
      try {
        var e = {};
        d.observe(((e.type = "first-input"), (e.buffered = !0), e));
      } catch (f) {}
      return b;
    }),
    On = K(
      function (a) {
        var b = P(a),
          c = b.o("isEU");
        if (Sa(c)) {
          var d = ub(Ed(a, "is_gdpr") || "");
          if (N(d, [0, 1])) b.B("isEU", d), (c = !!d);
          else if (((a = Me(a).o("wasSynced")), (a = I(a, "params.eu"))))
            b.B("isEU", a), (c = !!a);
        }
        return c;
      },
      function (a) {
        return P(a).o("isEU");
      }
    ),
    Pn = V("i.e", On),
    Qn = V("i.ep", function (a) {
      On(a);
    });
  function Rn(a, b, c, d, e) {
    if (!wj(a)) return r;
    var f = [],
      g = [],
      h = Xc(a),
      k;
    Ff(
      a,
      "doe"
    )(
      Bf(r, function () {
        var l = xj(b, a.document.body);
        e && (l = Qb(e, l));
        L(function (p) {
          f.push(p);
          g.push(h.C(p, c, d));
        }, l);
        if (wa("MutationObserver", a.MutationObserver)) {
          var m = b.toUpperCase();
          l = new a.MutationObserver(
            U(a, "de.m", function (p) {
              L(function (q) {
                var v = q.addedNodes;
                q = q.removedNodes;
                v &&
                  v.length &&
                  L(function (t) {
                    Hk(
                      a,
                      t,
                      function (x) {
                        x.nodeName !== m ||
                          (e && !e(x)) ||
                          Qe(Oa(x), f) ||
                          (f.push(x), g.push(h.C(x, c, d)));
                      },
                      void 0,
                      a.NodeFilter.SHOW_ELEMENT,
                      !0
                    );
                  }, v);
                q &&
                  q.length &&
                  L(function (t) {
                    Hk(
                      a,
                      t,
                      function (x) {
                        x.nodeName !== m ||
                          (e && !e(x)) ||
                          ((x = nc(a)(x, f)),
                          -1 !== x && (g[x](), g.splice(x, 1), f.splice(x, 1)));
                      },
                      void 0,
                      a.NodeFilter.SHOW_ELEMENT,
                      !0
                    );
                  }, q);
              }, p);
            })
          );
          l.observe(a.document.body, { childList: !0, subtree: !0 });
          k = B(l.disconnect, l);
        }
      })
    );
    return function () {
      k && k();
      L(ce, g);
      pc(g);
      pc(f);
    };
  }
  var Sn = "https://" + Sd + "/metrika",
    Pl = Sn + "/match.html",
    Tn = Sn + "/tag_phono.js",
    Un = cd(
      "appl",
      function (a) {
        return new Y(function (b, c) {
          Lk(a, Tn, b, c, { crossOrigin: !0 });
        });
      },
      !0
    ),
    Vn = ["cc-", "name", "shipping"];
  function Wn(a, b, c) {
    var d = c.Ia,
      e = wd(c.Ua);
    if (e && !(100 <= eb(e))) {
      var f = "tel" === I(d, "type"),
        g = 0 < Ba(e, "@") && !f,
        h = zd(e);
      h = eb(h);
      if (g || (!g && (f || h)))
        if (((b = 1 === b ? bd(a).o("app") : ci), (a = g ? ai(e) : b(a, e))))
          return {
            Ia: d,
            Yd: g,
            Ua: a,
            source: void 0,
            isTrusted: I(c, "isTrusted"),
            Nb: c.Nb,
          };
    }
  }
  function Xn(a, b, c, d, e, f) {
    var g = b.Yd,
      h = b.Ua,
      k = b.source,
      l = b.isTrusted,
      m = b.Nb;
    b = b.Ia.readOnly;
    var p = {},
      q = {};
    c =
      ((q.fi = qe(
        ((p.a = g ? 1 : 0),
        (p.b = c),
        (p.c = f || 0),
        (p.d = b ? 1 : null),
        (p.e = m ? 1 : null),
        p)
      ).ra()),
      (q.fit = d),
      q);
    z(l) || (c.ite = Mb(l));
    e &&
      (g
        ? ((e = n(h.split("@"))),
          (g = e.next().value),
          (h = e.next().value.split(".")),
          (e = h[h.length - 1]),
          (h = T(".", h.slice(0, -1))),
          (d = eb(g)),
          (l = eb(h)),
          (g =
            3 >= d
              ? "***"
              : 4 === d
              ? g[0] + "***"
              : g[0] + Jl("*", d - 2) + g[d - 1]),
          2 >= l
            ? (h = Jl("*", l))
            : 3 === l
            ? (h = h[0] + "**")
            : ((l = Math.floor(l / 2) + (l % 2)),
              (h = "" + h[0] + Jl("*", l) + h.slice(l + 1))),
          (e = "e:" + (g + "@" + h + "." + e)))
        : ((e = zd(h)), (g = e.slice(-4)), (e = "p:" + Kl("*", eb(e), g))),
      (c.mfpd = e));
    z(k) || (c.pfv = k);
    k = {};
    a.params(((k.__ym = c), k));
  }
  function Yn(a, b) {
    return function (c) {
      var d = Xh(a, b);
      if (d && (c = Wn(a, 0, c))) {
        var e = Mj(a, c.Ia);
        Xn(d, c, e, 0, !1);
        return !0;
      }
    };
  }
  function Zn(a, b, c, d) {
    return function (e) {
      var f = Xh(a, b);
      if (f && (e = Wn(a, d, e))) {
        var g = Mj(a, e.Ia);
        ei(a, e.Ua).then(D([f, e, g, d, c], Xn), U(a, "ice.s"));
        return !0;
      }
    };
  }
  function $n(a, b, c, d, e) {
    var f = e.target;
    a = ib(a)(f, c);
    f = -1 !== a;
    if (b || f) f && c.splice(a, 1), d(e);
  }
  function ao(a, b, c, d, e) {
    var f = I(e, "target");
    e = I(e, "isTrusted") || !1;
    f &&
      (f = Hj("button,input", a, f)) &&
      "submit" === f.type &&
      (f = ck(a, f)) &&
      ((d = d(f)),
      b.push(f),
      yf(
        a,
        D([a, !1, b, c, { target: f, isTrusted: e, formData: d }], $n),
        300,
        "i.c.l"
      ));
  }
  function bo(a, b) {
    var c = co,
      d = [],
      e = [];
    d.push(
      Rn(
        a,
        "form",
        ["submit"],
        U(a, "ltfs.s", function (f) {
          var g = I(f, "target");
          g &&
            $n(a, !0, e, b, {
              target: g,
              isTrusted: I(f, "isTrusted") || !1,
              formData: c(g),
            });
        })
      )
    );
    d.push(Rn(a, "button", ["click"], U(a, "ltfs.bc", D([a, e, b, c], ao))));
    d.push(
      Rn(
        a,
        "input",
        ["click"],
        U(a, "ltfs.ic", D([a, e, b, c], ao)),
        function (f) {
          return "submit" === f.type;
        }
      )
    );
    return D([de, d], L);
  }
  var eo = ["text", "email", "tel"];
  function co(a) {
    a = xj("input", a);
    return L(function (b) {
      return [b, b.value];
    }, a);
  }
  var fo = V("icei", function (a, b) {
      if (di(a)) {
        var c = !1,
          d = r,
          e = r;
        cj(b, function (f) {
          if (!(Pn(a) || I(f, "settings.eu") || c)) {
            var g = !!I(f, "settings.mcf");
            (I(f, "settings.cf")
              ? Df(
                  Un(a).then(
                    function () {
                      return U(a, "ice", Zn(a, b, g, 1), void 0, void 0, !1);
                    },
                    function () {
                      return U(a, "ice", Zn(a, b, g, 2), void 0, void 0, !1);
                    }
                  )
                )
              : Ef(U(a, "ice", Yn(a, b), void 0, void 0, !1)))(
              Bf(
                U(a, "ice.tt"),
                U(a, "ice.tc", function (h) {
                  if (!c) {
                    var k = function (l) {
                      var m;
                      if ((m = N(l.type, eo)))
                        (m = jf(l)
                          ? "password" === l.type ||
                            (l.name && N(l.name.toLowerCase(), Gl)) ||
                            (l.id && N(l.id.toLowerCase(), Gl))
                          : !1) ||
                          (m =
                            l &&
                            (Ha(l.className, "ym-disable-keys") ||
                              Ha(l.className, "-metrika-nokeys"))),
                          (m =
                            !(m || Fl(a, l)) &&
                            !sc(Nb, L(F(l.autocomplete, Ha), Vn)));
                      return m;
                    };
                    d = Rn(
                      a,
                      "input",
                      ["blur"],
                      function (l) {
                        (l = I(l, "target")) &&
                          h({ Ia: l, Ua: I(l, "value") || "" });
                      },
                      k
                    );
                    e = bo(a, function (l) {
                      var m = l.isTrusted,
                        p = 0;
                      L(function (q) {
                        var v = n(q);
                        q = v.next().value;
                        v = v.next().value;
                        20 <= p ||
                          !k(q) ||
                          (h({ Ia: q, Ua: v, isTrusted: m, Nb: !0 }) &&
                            (p += 1));
                      }, l.formData);
                    });
                  }
                })
              )
            );
          }
        })["catch"](U(a, "ice.t"));
        return function () {
          c = !0;
          d();
          e();
        };
      }
    }),
    go =
      "FB_IAB FBAV OKApp GSA/ yandex yango uber EatsKit YKeyboard iOSAppUslugi YangoEats PassportSDK".split(
        " "
      ),
    ho = K(function (a) {
      var b = ob(a);
      a = b.ud;
      if (!b.Jc) return !1;
      b = Za("indexOf", a);
      b = sc(M(b, Oa(-1), nb), go);
      var c = /CFNetwork\/[0-9][0-9.]*.*Darwin\/[0-9][0-9.]*/.test(a),
        d = /YaBrowser\/[\d.]+/.test(a),
        e = /Mobile/.test(a);
      return b || c || (d && e) || (!/Safari/.test(a) && e);
    }),
    io = K(function (a) {
      var b = qb(a);
      return b ? Ha(b, "YangoEats") || zc(a) : !1;
    }),
    jo;
  function ko(a, b, c) {
    var d = I(a, "AppMetricaInitializer"),
      e = I(d, "init");
    if (e)
      try {
        B(e, d)(Fe(a, b));
      } catch (f) {}
    else jo = yf(a, D([a, b, 2 * c], ko), c, "ai.d");
    return function () {
      return xf(a, jo);
    };
  }
  var lo = V("p.ai", function (a, b) {
      if (zc(a) || ho(a))
        return cj(b, function (c) {
          if ((c = I(c, "settings.sbp"))) {
            var d = {};
            return ko(a, O({}, c, ((d.c = b.id), d)), 10);
          }
        });
    }),
    mo =
      "architecture bitness model platformVersion uaFullVersion fullVersionList".split(
        " "
      ),
    no = cd("uah", function (a) {
      if (
        !wa(
          "getHighEntropyValues",
          I(a, "navigator.userAgentData.getHighEntropyValues")
        )
      )
        return Y.reject("0");
      try {
        return a.navigator.userAgentData.getHighEntropyValues(mo).then(
          function (b) {
            if (!A(b)) throw "2";
            return b;
          },
          function () {
            throw "1";
          }
        );
      } catch (b) {
        return Y.reject("3");
      }
    }),
    oo = new RegExp(
      T(
        "|",
        "yandex.com/bots;Googlebot;APIs-Google;Mediapartners-Google;AdsBot-Google;FeedFetcher-Google;Google-Read-Aloud;DuplexWeb-Google;Google Favicon;googleweblight;Lighthouse;Mail.RU_Bot;StackRambler;Slurp;msnbot;bingbot;www.baidu.com/search/spi_?der.htm".split(
          ";"
        )
      ).replace(/[./]/g, "\\$&")
    ),
    po = K(function (a) {
      var b = qb(a);
      return (b = oo.test(b))
        ? Y.resolve(b)
        : no(a).then(function (c) {
            try {
              return G(
                function (d, e) {
                  return d || oo.test(e.brand);
                },
                !1,
                c.brands
              );
            } catch (d) {
              return !1;
            }
          }, F(!1, lb));
    }),
    qo = ["default", "update"],
    ro = cd(
      "ycs",
      function (a) {
        function b(e) {
          if ("region" === e) return !0;
          if (H(c, e)) {
            e = c[e];
            if (!Sa(e.current)) return e.current;
            if (!Sa(e["default"])) return e["default"];
          }
          return !0;
        }
        var c = {},
          d = Hf(a, "ytm.cs");
        a = {};
        return (
          (a.set = function (e, f) {
            if (N(e, qo) && A(f)) {
              var g = H(f, "region") ? f.region : void 0,
                h = u(g) && g ? ("" + g).toUpperCase() : void 0,
                k;
              L(function (l) {
                var m = n(l);
                l = m.next().value;
                m = m.next().value;
                if ("region" !== l && !h) {
                  var p = "granted" === m;
                  m = b(l);
                  var q = H(c, l) ? c[l] : {};
                  if ("default" === e) {
                    if (!Sa(q.current)) {
                      k = "cdau";
                      return;
                    }
                    q["default"] = p;
                  } else q.current = p;
                  c[l] = q;
                  p = b(l);
                  p !== m && d.trigger(l, [l, p]);
                }
              }, dc(f));
              return k;
            }
          }),
          (a.get = b),
          (a.on = function (e, f) {
            d.C([e], function (g) {
              var h = n(g);
              g = h.next().value;
              h = h.next().value;
              return f(g, h);
            });
          }),
          a
        );
      },
      !0
    ),
    so = ["0", "1", "2", "3"],
    to = so[0],
    uo = so[1],
    vo = so[2],
    wo = [
      "GDPR-ok-view-detailed-0",
      "GDPR-ok-view-detailed-1",
      "GDPR-ok-view-detailed-2",
      "GDPR-ok-view-detailed-3",
    ],
    xo = ["GDPR-ok-view-default", "GDPR-ok-view-detailed"].concat(ja(wo));
  function yo(a) {
    if (N(a, ["GDPR-ok-view-default", "GDPR-ok-view-detailed"])) return to;
    a = a.replace("GDPR-ok-view-detailed-", "");
    return N(a, so) ? a : to;
  }
  var zo =
      "GDPR-ok GDPR-cross GDPR-cancel 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 GDPR-settings GDPR-ok-view-default GDPR-ok-view-detailed 21 22 23"
        .split(" ")
        .concat(wo)
        .concat(["28", "29", "30", "31"]),
    Ao = "3 13 14 31 15 16 17 28".split(" "),
    Bo = M(Gb(J("ymetrikaEvent.type")), Sb(Vb(zo))),
    Co =
      "az be en es et fi fr hy ka kk ky lt lv no pt ro ru sl tg tr uz ar he sr uk zh".split(
        " "
      );
  function Do(a) {
    if (
      /(^|\w+\.)yango(\.yandex)?\.com$/.test(a) &&
      !/(^|\w+\.)drive\.yango\.com$/.test(a)
    )
      return {
        url: "https://yastatic.net/s3/taxi-front/yango-gdpr-popup/",
        version: 2,
        Nc: Co,
        Rc: "_inversed_buttons",
      };
  }
  var Eo = RegExp(
      "^(.*\\.)?((yandex(-team)?)\\.(com?\\.)?[a-z]+|(auto|kinopoisk|beru|bringly)\\.ru|ya\\.(ru|cc)|yadi\\.sk|yastatic\\.net|.*\\.yandex|turbopages\\.org|turbo\\.site|diplodoc\\.(com|tech)|datalens\\.tech|white-label\\.yango-tech\\.com|al-sadhan\\.com|spar\\.sa|^order\\.grandhyper\\.com|^tst\\.order\\.grandhyper\\.com|^pre\\.order\\.grandhyper\\.com|^tuvio\\.kz|^pragmahome\\.kz|^commo\\.kz|^junion\\.kz|^nocord-tools\\.kz|^cubits\\.kz|drive\\.yango\\.com)$"
    ),
    Fo = K(function (a) {
      a = R(a).hostname;
      var b = !1;
      a && (b = -1 !== a.search(Eo));
      return b;
    });
  function Go(a, b) {
    var c = Ci(a, b);
    c &&
      c.ca.C(["isYandex"], function () {
        var d = {};
        return (d.type = "isYandex"), (d.isYandex = Fo(a)), d;
      });
  }
  function Ho(a, b, c) {
    var d = Ci(a, c);
    return new Y(function (e) {
      if (d) {
        var f = d.ca,
          g = M(F("4", b), F(null, e)),
          h = yf(a, g, 2e3, "gdp.f.t"),
          k = {};
        d.ad(((k.type = "isYandex"), k))
          .then(function (l) {
            l.isYandex
              ? (b("5"),
                f.C(xo, function (m) {
                  m = n(m);
                  m.next();
                  m = m.next().value.type;
                  e({ value: yo(m) });
                }))
              : (b("6"), e(null));
          })
          ["catch"](g)
          .then(D([a, h], xf));
      } else e({ value: uo, Mb: !0 });
    });
  }
  var Io = {},
    Jo =
      ((Io["GDPR-ok"] = "ok"),
      (Io["GDPR-ok-view-default"] = "ok-default"),
      (Io["GDPR-ok-view-detailed"] = "ok-detailed"),
      (Io["GDPR-ok-view-detailed-0"] = "ok-detailed-all"),
      (Io["GDPR-ok-view-detailed-1"] = "ok-detailed-tech"),
      (Io["GDPR-ok-view-detailed-2"] = "ok-detailed-tech-analytics"),
      (Io["GDPR-ok-view-detailed-3"] = "ok-detailed-tech-other"),
      Io);
  function Ko(a, b) {
    if (Fo(a)) {
      var c = Ei(a),
        d = Xh(a, b);
      d = d && d.params;
      c = L(F(Jo, I), Bo(c));
      d && c.length && d("gdpr", Rb(c));
    }
  }
  function Lo(a, b, c) {
    a = c || Hc(a);
    return N(a, b) ? a : "en";
  }
  var Mo = {
      $d: !0,
      url: "https://yastatic.net/s3/gdpr/v3/gdpr",
      Rc: "",
      Nc: "az be en es et fi fr hy ka kk ky lt lv no pt ro ru sl tg tr uz cs da de el hr it nl pl sk sv".split(
        " "
      ),
    },
    No = cd("gdpr", function (a, b, c, d, e) {
      function f(p) {
        b("10");
        c.C(xo, function (q) {
          q = q.type;
          var v = {};
          l.$c(((v.type = q), v));
          p({ value: yo(q) });
        });
      }
      var g = void 0 === e ? Mo : e;
      e = g.url;
      var h = g.Rc,
        k = g.$d;
      g = Lo(a, g.Nc, d.He);
      var l = Ci(a, d);
      if (!l) return Y.resolve({ value: to, Mb: !0 });
      if (a._yaGdprLoaded)
        return new Y(function (p) {
          b("7");
          f(p);
        });
      var m = "" + e + (k ? "" : g) + h + ".js";
      return new Y(function (p) {
        b("7");
        Lk(a, m, F(p, f), function () {
          b("9");
          var q = {};
          l.$c(((q.type = "GDPR-ok-view-default"), q));
          p(null);
        });
      });
    });
  function Oo(a, b) {
    var c = P(a),
      d = P(a).o("gqp", [0, 0, 0, 0, 0, 0, 0, 0]);
    d[b] += 1;
    c.B("gqp", d);
  }
  function Po(a) {
    return T(
      ",",
      L(function (b) {
        return b || "";
      }, P(a).o("gqp", [0, 0, 0, 0, 0, 0, 0, 0]))
    );
  }
  var Qo = [],
    Ro = Za("push", Qo),
    So = K(function (a, b) {
      var c = b("gdpr");
      return N(c, so) ? a + "-" + c : a;
    }),
    To = Sd.split("."),
    Uo = To.pop(),
    Vo = T(".", To),
    Wo =
      /^([^.]+\.)?(boost|appmetrica|metrika|metrica|direct|ads)\.yandex\.([a-z.]+)$/,
    Xo = {},
    Yo =
      ((Xo.brands = "chu"),
      (Xo.architecture = "cha"),
      (Xo.bitness = "chb"),
      (Xo.uaFullVersion = "chf"),
      (Xo.fullVersionList = "chl"),
      (Xo.mobile = "chm"),
      (Xo.model = "cho"),
      (Xo.platform = "chp"),
      (Xo.platformVersion = "chv"),
      Xo);
  function Zo(a) {
    return u(a)
      ? a
      : w(a)
      ? T(
          ",",
          L(function (b) {
            return '"' + b.brand + '";v="' + b.version + '"';
          }, a)
        )
      : z(a)
      ? ""
      : a
      ? "?1"
      : "?0";
  }
  function $o(a) {
    return "che\n" + a;
  }
  function ap(a) {
    var b = G(
      function (c, d) {
        var e = n(d),
          f = e.next().value;
        e = e.next().value;
        (f = Zo(a[f])) && c.push("" + e + "\n" + f);
        return c;
      },
      [],
      dc(Yo)
    );
    return T("\n", b);
  }
  var bp = K(function (a) {
    return no(a).then(ap, $o);
  });
  function cp(a) {
    return {
      K: function (b, c) {
        bp(a).then(function (d) {
          b.D || (b.D = {});
          b.D.uah = d;
          c();
        }, c);
      },
    };
  }
  function dp(a, b, c) {
    Ff(
      a,
      "pbjs"
    )(
      Bf(r, function () {
        var d = L(function (g) {
          var h = {};
          h = ((h.auc = g), h);
          g =
            yj("[id='" + g + "']", a.document.body) ||
            yj("[id='" + g.slice(1) + "']", a.document.body);
          if (!g) return h;
          var k = ef(g);
          if (k) {
            var l = {};
            O(
              h,
              ((l.y = "" + k.top),
              (l.x = "" + k.left),
              (l.w = "" + k.width),
              (l.h = "" + k.height),
              l)
            );
          }
          if ((g = yj("iframe", g)))
            (k = {}),
              O(h, ((k.wi = g.width), (k.hi = g.height), (k.si = g.src), k));
          return h;
        }, c);
        if (0 < d.length) {
          var e = {},
            f = {};
          b(((f.__ym = ((e.adi = d), e)), f));
        }
      })
    );
  }
  var ep =
      "pbjsInit bidRequested bidAdjustment bidWon bidResponse bidTimeout auctionInit auctionEnd adRenderSucceeded adRenderFailed".split(
        " "
      ),
    fp = [
      "cpm",
      "currency",
      "netRevenue",
      "requestTimestamp",
      "responseTimestamp",
    ],
    gp = {},
    hp =
      ((gp.netRevenue = function (a) {
        return u(a) ? "net" === a : !!a;
      }),
      gp),
    ip = {},
    jp;
  function kp(a) {
    var b = ip[a],
      c = b.xb,
      d = b.Ac,
      e = b.pe;
    return L(function (f) {
      var g = n(f);
      f = g.next().value;
      g = g.next().value;
      var h = g.Sb,
        k = g.timeout,
        l = g.Sa,
        m = {};
      return O(
        ((m.renderState = g.Xa),
        (m.mediaTypes = h),
        (m.auctionId = a),
        (m.adUnitCode = f),
        (m.startStamp = c),
        (m.endStamp = d),
        (m.requestedBidders = e),
        (m.bidTimeout = k),
        m),
        l
      );
    }, dc(b.tb));
  }
  function lp(a, b, c) {
    var d = ip[c];
    d.Yc = !1;
    d.yb && xf(a, d.yb);
    d.yb = yf(
      a,
      function () {
        var e = kp(c),
          f = {},
          g = {};
        b(((g.__ym = ((f.pbjsv = jp), (f.pbjs = e), f)), g));
        delete ip[c];
      },
      2e3,
      "pbjs.t"
    );
  }
  function mp(a, b) {
    var c = Xh(a, b);
    c &&
      L(function (d) {
        ip[d].Yc && lp(a, c.params, d);
      }, ec(ip));
  }
  function np(a, b) {
    a.tb[b] || (a.tb[b] = { Sa: {} });
    return a.tb[b];
  }
  function op(a, b, c) {
    var d = c.adUnitCode,
      e = c.bidderCode || c.bidder;
    if (e && d) {
      var f = np(b, d);
      !f.Sb &&
        c.mediaTypes &&
        ((f.Sb = {}),
        L(function (g) {
          var h = n(g);
          g = h.next().value;
          h = h.next().value;
          var k;
          w(h)
            ? (k = h)
            : h.sizes
            ? (k = h.sizes)
            : h.playerSize && (k = h.playerSize);
          k && (f.Sb[g] = k);
        }, dc(c.mediaTypes)));
      "bidTimeout" === a
        ? (f.timeout || (f.timeout = {}), (f.timeout[e] = !0))
        : (f.Sa[a] || (f.Sa[a] = {}),
          (f.Sa[a][e] = G(
            function (g, h) {
              z(c[h]) || (g[h] = hp[h] ? hp[h](c[h]) : c[h]);
              return g;
            },
            {},
            fp
          )),
          (b = I(c, "meta.advertiserDomains")),
          w(b) && (f.Sa[a][e].advertiserDomains = b));
    }
  }
  function pp(a, b, c) {
    var d = c.bid,
      e = d.bidderCode || d.bidder;
    d = d.adUnitCode;
    e &&
      d &&
      ((b = np(b, d)),
      b.Xa || (b.Xa = {}),
      (a = "adRenderSucceeded" === a),
      (d = {}),
      (b.Xa[e] = ((d.success = a), d)),
      a || ((b.Xa[e].reason = c.reason), (b.Xa[e].message = c.message)));
  }
  function qp(a, b) {
    if (N(a, ep))
      if ("pbjsInit" === a) jp = b.version;
      else {
        var c = I(b, "auctionId") || I(b, "bid.auctionId") || void 0;
        if (c) {
          ip[c] || (ip[c] = { tb: {} });
          c = ip[c];
          var d = "auctionInit" === a,
            e = "auctionEnd" === a,
            f = "adRenderFailed" === a || "adRenderSucceeded" === a;
          f ||
            (c.xb && !d) ||
            ((c.xb = I(b, "auctionStart") || void 0),
            !c.xb && d && (c.xb = b.timestamp));
          var g = D([a, c], op);
          "bidRequested" === a
            ? L(g, b.bids)
            : f
            ? pp(a, c, b)
            : e
            ? ((c.Ac = b.auctionEnd || b.timestamp),
              (c.pe = Qb(function (h, k, l) {
                return jb(h, l) === k;
              }, L(J("bidderCode"), b.bidderRequests))))
            : d || g(b);
          c.Ac && (c.Yc = !0);
        }
      }
  }
  function rp(a, b) {
    var c = !1;
    return function (d) {
      var e = Xh(a, b);
      e &&
        !c &&
        ((c = !0),
        (d = D([a, e.params, d], dp)),
        yf(a, d, 5e3, "pbjs.fr"),
        yf(a, d, 2e4, "pbjs.sr"));
    };
  }
  function sp(a, b) {
    L(function (c) {
      var d = c.event,
        e = c.data,
        f = F(d, qp);
      "bidTimeout" === d ? L(f, e) : f(e);
      "auctionEnd" === d && (c = I(c, "data.adUnitCodes")) && b(c);
    }, a);
  }
  var tp = V("pj", function (a, b) {
      var c = rp(a, b),
        d = {};
      return (
        (d.pbjs = function (e) {
          w(e) &&
            ((e = Qb(
              Nb,
              L(function (f) {
                if (A(f) && f.data && f.event && (A(f.data) || w(f.data))) {
                  var g = I(f, "data.args");
                  return g ? { event: f.event, data: g } : f;
                }
              }, e)
            )),
            sp(e, c),
            mp(a, b));
        }),
        d
      );
    }),
    up = K(function () {
      var a = Lj();
      return G(
        function (b, c) {
          b[a[c]] = c;
          return b;
        },
        {},
        ec(a)
      );
    }),
    vp = /(\D\d*)/g;
  function wp(a) {
    if (!a) return "";
    a = a.match(vp);
    if (!a || 0 === a.length) return "";
    var b = up();
    return (
      "//HTML/BODY/" +
      G(
        function (c, d) {
          var e = d[0],
            f = ub(d.slice(1));
          return "/" + b[e] + (f ? "[" + (f + 1) + "]" : "") + c;
        },
        "",
        a
      )
    );
  }
  function xp(a, b) {
    var c = wp(b);
    return c
      ? I(a, "document.evaluate")
        ? a.document.evaluate(
            c,
            a.document,
            null,
            a.XPathResult.FIRST_ORDERED_NODE_TYPE,
            null
          ).singleNodeValue
        : null
      : null;
  }
  var yp = K(Nd);
  function zp(a) {
    return { ke: Se(a.element), Gb: a.Gb };
  }
  function Ap(a, b) {
    var c = a.document.body;
    if (c) {
      var d = b.price_patterns,
        e = yp(b.id);
      if (e.Pa) {
        if (!Ij(a, e.Pa.element)) return zp(e.Pa);
        e.Pa = void 0;
      }
      d = G(
        function (h, k) {
          var l = n(k),
            m = l.next().value;
          l = l.next().value;
          h[m] = l;
          return h;
        },
        {},
        d
      );
      var f = null,
        g = null;
      d.cs && wj(a) && ((f = yj(d.cs, c)), (g = "c"));
      d.p && !f && ((f = xp(a, d.p)), (g = "x"));
      if (f && g) return (e.Pa = { element: f, Gb: g }), zp(e.Pa);
    }
  }
  function Bp(a, b) {
    var c = a[b[0]];
    return !(!c || c !== b[1]);
  }
  function Cp(a, b) {
    var c = b.patterns;
    if (0 === c.length) return !1;
    if (1 === c.length) return Bp(a, c[0]);
    c = G(
      function (f, g) {
        var h = n(g),
          k = h.next().value;
        h = h.next().value;
        var l = a[k];
        if (l === h) {
          if (((f.Fb += 1), "i" === k || "c" === k)) f.Kc = !0;
        } else l && "p" === k && Ad(l) === Ad(h) && (f.Mc = !0);
        return f;
      },
      { Fb: 0, Kc: !1, Mc: !1 },
      c
    );
    var d = c.Kc,
      e = c.Mc;
    return 2 <= c.Fb || (d && e);
  }
  function Dp(a, b) {
    var c = b.patterns;
    return 0 === c.length ? !1 : sc(F(a, Bp), c);
  }
  function Ep(a, b, c, d) {
    c = L(function (e) {
      if (!d(b, e)) return !1;
      var f = {};
      f = ((f.rg = e.id), f);
      if ((e = Ap(a, e))) (f.gp = fl(e.ke)), (f.mg = e.Gb);
      return f;
    }, c);
    return Rb(c);
  }
  var Fp = Na(lj)("btn:"),
    Gp = Na(lj)("form:");
  function Hp(a) {
    var b = n(a),
      c = b.next().value;
    b = b.next().value;
    return "bp" === c ? ["p", dl(bl(b))] : a;
  }
  var Ip = Gb(function (a) {
    a.patterns = L(Hp, a.patterns);
    a.price_patterns = L(Hp, a.price_patterns);
    return a;
  });
  function Jp(a, b) {
    var c = Xd(a);
    b && (c.yen = b);
    return c;
  }
  function Kp(a) {
    return Jp(a, "yue");
  }
  function Lp(a, b) {
    if (z(b) || !!b === b || rb(a, b) || u(b)) return b;
  }
  function Mp(a, b) {
    if (z(b)) return b;
    var c = Lp(a, b);
    if (!z(c)) return c;
    if (A(b))
      return G(
        function (d, e) {
          var f = n(e),
            g = f.next().value;
          f = f.next().value;
          d[g] = Mp(a, f);
          return d;
        },
        {},
        dc(b)
      );
    if (w(b)) return L(F(a, Mp), b);
  }
  var Np =
    "clientInformation globalThis this caches console cookieStore credentialless crypto customElements document documentPictureInPicture event external fence frameElement frames history indexedDB launchQueue localStorage location mozInnerScreenX mozInnerScreenY navigation navigator opener orientation origin originAgentCluster parent performance scheduler self sessionStorage sharedStorage speechSynthesis top trustedTypes visualViewport window alert atob back blur btoa cancelAnimationFrame cancelIdleCallback captureEvents clearImmediate clearInterval clearTimeout close confirm dump execScript fetch fetchLater find focus forward getComputedStyle getDefaultComputedStyle getScreenDetails getSelection matchMedia moveBy moveTo open postMessage print prompt queryLocalFonts queueMicrotask releaseEvents reportError requestAnimationFrame requestFileSystem requestIdleCallback resizeBy resizeTo scroll scrollBy scrollByLines scrollByPages scrollTo setImmediate setInterval setTimeout showDirectoryPicker showModalDialog showOpenFilePicker showSaveFilePicker sizeToContent stop structuredClone".split(
      " "
    );
  function Op(a) {
    if (!u(a)) throw Kp("gppns");
    if (N(a.split(".")[0], Np)) throw Kp("rwp");
    if (lj(a, "on")) throw Kp("rwp");
  }
  function Pp(a, b) {
    var c = b.split("."),
      d = c.pop();
    c = c.length ? I(a, T(".", c)) : a;
    if (!c) throw Kp("noma");
    return { value: I(c, d), parent: c, Wa: d };
  }
  var Qp = {},
    Rp =
      ((Qp.akna = "The property of the value is not an array"),
      (Qp["ca.p.uns"] = "The url is not a string"),
      (Qp.noma = "Cannot access member of null or undefined object"),
      (Qp.rwp = "Access to restricted window property is denied"),
      (Qp.vnd = "Variable is not defined"),
      (Qp.tenf = "Called value is not a function"),
      (Qp.cva = "Cannot assign to constant variable"),
      (Qp.iat = "Invalid assignment target"),
      (Qp["ca.c.wenf"] = "Window element is not a function"),
      (Qp["ca.c.mann"] = "Cookie's max age is not a number"),
      (Qp["ca.c.ssuop"] = "SameSite cookie has an unknown option"),
      (Qp.gppns = "Window property path is not a string"),
      (Qp.vr = "Variable redeclaration"),
      (Qp.da = "Duplicate argument"),
      (Qp.stce = "Error creating script tag"),
      (Qp.wenf = "Window element is not a function"),
      (Qp.uns = "The url is not a string"),
      (Qp.ict = "Consent type is not a string"),
      (Qp.icl = "Consent listener is not a function"),
      (Qp["ca.akna"] = "The property of the value is not an array"),
      (Qp["ca.c.cinf"] = "Callback is not a function"),
      (Qp["ca.c.ia"] = "Invalid arguments"),
      (Qp.ies = "Invalid element selector"),
      (Qp["t.a.s.ev"] = "Element visibility tag was already started"),
      (Qp["t.a.s.g"] = "Group tag was already started"),
      (Qp["t.a.s.sd"] = "Scroll depth tag was already started"),
      (Qp["t.a.s.t"] = "Timer tag was already started"),
      (Qp.cdau = "Consent default arrived after the value was updated"),
      Qp),
    Sp = {},
    Tp =
      ((Sp.c = "Container"),
      (Sp.t = "Tag"),
      (Sp.tr = "Trigger"),
      (Sp.v = "Variable"),
      Sp);
  function Up(a) {
    if (!a) return "";
    var b = a.id;
    return "[" + Tp[a.type] + (b ? ":" + b : "") + "]";
  }
  function Vp(a) {
    a = a.message;
    return u(a) ? Rp[a] || a : "Unknown error";
  }
  var Wp = r,
    Xp,
    Yp = K(function (a, b, c) {
      Wp = b;
      c && (Xp = c);
    });
  function Zp(a, b, c, d) {
    return function () {
      var e = b || Ud;
      try {
        return e.apply(null, arguments);
      } catch (f) {
        (e = y(d) ? d.apply(null, arguments) : d), Wp(a, f, e);
      }
      return c;
    };
  }
  function $p(a, b) {
    return function (c) {
      Wp(a, c, b);
    };
  }
  function aq(a, b, c) {
    c
      ? Yp(
          a,
          function (d, e, f) {
            z(e) ||
              (Vk(a).error("[YTM Error]" + Up(f) + " " + Vp(e)),
              Xp &&
                ((d = {}),
                (e = ((d.event = "ee"), (d.m = Vp(e)), d)),
                f &&
                  ((e.et = f.type), (e.eid = f.eventId), f.id && (e.ei = f.id)),
                Xp(e)));
          },
          c
        )
      : Yp(a, function (d, e, f) {
          d = "ytm." + d;
          z(e) ||
            (H(e, "yen")
              ? (Vh(a, b, "[YTM Error]" + Up(f) + " " + Vp(e))(),
                "yme" === e.yen && fe("mod", I(e, "message") || "ue", d))
              : ge(a, d, e));
        });
  }
  function bq(a, b, c, d) {
    var e = Ue(a)("img");
    e.src = b;
    b = F(e, Ve);
    var f = F(void 0, lb);
    e.onerror = M(b, f, d);
    e.onload = M(b, f, c);
    wc(a) &&
      ((a = Ze(a)),
      O(e.style, {
        position: "absolute",
        visibility: "hidden",
        width: "0px",
        height: "0px",
      }),
      a.appendChild(e));
  }
  var cq = K(function (a, b) {
    return G(
      function (c, d) {
        c[d] = a[d];
        return c;
      },
      {},
      b
    );
  });
  function dq(a, b, c) {
    c = void 0 === c ? !0 : c;
    return G(
      function (d, e) {
        var f = n(e.split("=")),
          g = f.next().value;
        f = ia(f);
        wd(g) === b && ((g = wd(T("=", f))), d.push(c ? rd(g) : g));
        return d;
      },
      [],
      a.document.cookie.split(";")
    );
  }
  function eq(a, b) {
    if (Sa(b)) var c = "undefined";
    else if (Ra(b)) c = "null";
    else {
      try {
        c = rb(a, b);
      } catch (d) {
        c = !1;
      }
      c = c
        ? "number"
        : u(b)
        ? "string"
        : !0 === b || !1 === b
        ? "boolean"
        : y(b)
        ? "function"
        : w(b)
        ? "array"
        : "object";
    }
    return c;
  }
  function fq(a, b, c, d) {
    d = void 0 === d ? !1 : d;
    return "query" === b
      ? a.query
      : "queryVar" === b
      ? ((a = c ? sd(a.query)[c] : void 0), a)
      : "protocol" === b
      ? a.protocol
      : "host" === b
      ? d
        ? jd(a.host)
        : a.host
      : "port" === b
      ? ((b = a.protocol),
        (a = ub(a.port)
          ? a.port
          : "http:" === b
          ? "80"
          : "https:" === b
          ? "443"
          : void 0),
        a)
      : "path" === b
      ? a.pathname
      : "fragment" === b
      ? a.hash.replace("#", "")
      : "extension" === b
      ? ((a = a.pathname.split(".")),
        ((1 < a.length ? a.pop() : void 0) || "").split("/")[0])
      : a.href;
  }
  var gq =
      "protocol host port path query queryVar extension fragment href".split(
        " "
      ),
    hq = K(function (a) {
      var b = R(a).search;
      b = sd(b.substring(1))._ytm_preview;
      var c = Kd(a, "");
      a = c.B;
      c = c.o;
      return b ? (a("_ytm_preview", b, 10), b) : c("_ytm_preview");
    });
  function iq(a) {
    switch (a) {
      case 2:
        return "read";
      case 1:
        return "write";
      default:
        throw Xd("usoc");
    }
  }
  function jq(a) {
    switch (a) {
      case "read":
        return 2;
      case "write":
        return 1;
      case "execute":
        return 4;
    }
  }
  function kq(a, b, c, d, e) {
    if (!d) return !1;
    c = (a = "set_cookies" === c) ? 1 : 2;
    return a && !A(e)
      ? !1
      : b.R({
          permissionType: "cookies",
          F: { name: d, operation: c, options: e },
        });
  }
  function lq(a, b, c, d) {
    if (!d) return !1;
    a = "iframe";
    "load_script" === c
      ? (a = "loadScript")
      : "send_pixel" === c && (a = "pixel");
    return b.R({ permissionType: a, F: { url: d } });
  }
  function mq(a, b, c, d, e) {
    return b.R({
      permissionType: "get_url" === c ? "url" : "referrer",
      F: { urlComponent: d || "href", variableName: u(e) ? e : void 0 },
    });
  }
  var nq = {},
    oq =
      ((nq.access_consent = function (a, b, c, d, e) {
        return d && u(d) && e && u(e)
          ? (a = jq(e)) && 4 !== a
            ? b.R({
                permissionType: "accessConsent",
                F: { key: d, operation: a },
              })
            : !1
          : !1;
      }),
      (nq.access_globals = function (a, b, c, d, e) {
        return d && u(d) && u(e)
          ? (a = jq(d))
            ? b.R({ permissionType: "globals", F: { key: e, operation: a } })
            : !1
          : !1;
      }),
      (nq.access_local_storage = function (a, b, c, d, e) {
        return d && u(d) && u(e)
          ? (a = jq(d)) && 4 !== a
            ? b.R({
                permissionType: "localStorage",
                F: { key: e, operation: a },
              })
            : !1
          : !1;
      }),
      (nq.access_template_storage = function (a, b) {
        return b.R({ permissionType: "templateStorage", F: null });
      }),
      (nq.get_cookies = kq),
      (nq.get_referrer = mq),
      (nq.get_url = mq),
      (nq.inject_hidden_iframe = lq),
      (nq.load_script = lq),
      (nq.logging = function (a, b) {
        return b.R({ permissionType: "log", F: { logLevel: hq(a) ? 1 : 0 } });
      }),
      (nq.read_data_layer = function (a, b, c, d) {
        return d
          ? b.R({ permissionType: "dataLayer", F: { key: d, operation: 2 } })
          : !1;
      }),
      (nq.read_title = function (a, b) {
        return b.R({ permissionType: "readTitle", F: null });
      }),
      (nq.send_pixel = lq),
      (nq.set_cookies = kq),
      nq),
    pq = "protocol host port path query queryVar extension href".split(" "),
    qq = K(Nd, function (a, b) {
      return a + "_" + b;
    }),
    rq = /\+/g,
    sq = /^\?/,
    tq = /[/:]|^[#?]/;
  function uq(a) {
    return (a = a ? a.replace(sq, "") : "")
      ? G(
          function (b, c) {
            var d = n(c.split("=")),
              e = d.next().value;
            d = ia(d);
            d = T("=", d);
            e = rd(e.replace(rq, " "));
            d = rd(d.replace(rq, " "));
            if (H(b, e)) {
              var f = b[e];
              w(f) ? f.push(d) : (b[e] = [f, d]);
            } else b[e] = d;
            return b;
          },
          {},
          a.split("&")
        )
      : {};
  }
  var vq = {},
    wq =
      ((vq.callInWindow = function (a) {
        var b = a.l,
          c = a.I;
        return function (d) {
          var e = ra.apply(1, arguments);
          Op(d);
          c.checkPermission({
            permissionType: "globals",
            F: { key: d, operation: 4 },
          });
          var f = Pp(b, d),
            g = f.value;
          f = f.parent;
          if (!y(g)) throw Kp("ca.c.wenf");
          e = g.apply(f, e);
          return Mp(b, e);
        };
      }),
      (vq.callLater = function (a) {
        var b = a.l;
        return function (c) {
          if (!y(c)) throw Jp("ca.c.cinf");
          yf(b, c, 0, "cr.cl");
        };
      }),
      (vq.copyFromDataLayer = function (a) {
        var b = a.l,
          c = a.I,
          d = a.event;
        return function (e) {
          if (!d) throw Jp("No dataLayer data");
          c.checkPermission({
            permissionType: "dataLayer",
            F: { key: e, operation: 2 },
          });
          return Mp(b, I(d, e));
        };
      }),
      (vq.copyFromWindow = function (a) {
        var b = a.l,
          c = a.I;
        return function (d) {
          Op(d);
          c.checkPermission({
            permissionType: "globals",
            F: { operation: 2, key: d },
          });
          return Mp(b, I(b, d));
        };
      }),
      (vq.createArgumentsQueue = function (a) {
        var b = a.l,
          c = a.I;
        return function (d, e) {
          function f() {
            return g.push(arguments);
          }
          c.checkPermission({
            permissionType: "globals",
            F: { key: d, operation: 2 },
          });
          c.checkPermission({
            permissionType: "globals",
            F: { key: d, operation: 1 },
          });
          c.checkPermission({
            permissionType: "globals",
            F: { key: e, operation: 2 },
          });
          c.checkPermission({
            permissionType: "globals",
            F: { key: e, operation: 1 },
          });
          Op(d);
          Op(e);
          var g = [],
            h = Pp(b, d);
          h.value || (h.parent[h.Wa] = f);
          h = Pp(b, e);
          if (h.value) {
            if (!w(h.value)) throw Kp("ca.akna");
            g = h.value;
          } else h.parent[h.Wa] = g;
          return f;
        };
      }),
      (vq.createQueue = function (a) {
        var b = a.l,
          c = a.I;
        return function (d) {
          c.checkPermission({
            permissionType: "globals",
            F: { key: d, operation: 2 },
          });
          c.checkPermission({
            permissionType: "globals",
            F: { key: d, operation: 1 },
          });
          Op(d);
          var e = Pp(b, d);
          d = e.value;
          var f = e.parent;
          e = e.Wa;
          if (!d) f[e] = [];
          else if (!w(d)) throw Kp("akna");
          return B(f[e].push, f[e]);
        };
      }),
      (vq.decodeUri = function (a) {
        var b = a.l;
        return function (c) {
          try {
            return b.decodeURI(c);
          } catch (d) {}
        };
      }),
      (vq.decodeUriComponent = function (a) {
        var b = a.l;
        return function (c) {
          try {
            return b.decodeURIComponent(c);
          } catch (d) {}
        };
      }),
      (vq.encodeUri = function (a) {
        var b = a.l;
        return function (c) {
          try {
            return b.encodeURI(c);
          } catch (d) {}
        };
      }),
      (vq.encodeUriComponent = function (a) {
        var b = a.l;
        return function (c) {
          try {
            return b.encodeURIComponent(c);
          } catch (d) {}
        };
      }),
      (vq.fromBase64 = function (a) {
        var b = a.l;
        return function (c) {
          try {
            return b.atob(c);
          } catch (d) {}
        };
      }),
      (vq.getCookieValues = function (a) {
        var b = a.l,
          c = a.I;
        return function (d, e) {
          c.checkPermission({
            permissionType: "cookies",
            F: { name: d, operation: 2 },
          });
          return dq(b, d, e);
        };
      }),
      (vq.getTimestamp = function (a) {
        var b = a.l;
        return function () {
          return W(b)(mf);
        };
      }),
      (vq.getType = function (a) {
        return F(a.l, eq);
      }),
      (vq.getReferrerUrl = function (a) {
        var b = a.l,
          c = a.I;
        return function (d, e) {
          var f = N(d, pq) ? d : "href";
          c.checkPermission({
            permissionType: "referrer",
            F: { urlComponent: f, variableName: e },
          });
          var g = I(b, "document.referrer");
          if (g) return (g = ph(b, g)), fq(g, f, e);
        };
      }),
      (vq.getUrl = function (a) {
        var b = a.l,
          c = a.I;
        return function (d, e) {
          var f = N(d, gq) ? d : "href";
          c.checkPermission({
            permissionType: "url",
            F: { urlComponent: f, variableName: e },
          });
          var g = R(b);
          g.query = g.search.replace(/^\?/, "");
          return fq(g, f, e);
        };
      }),
      (vq.injectHiddenIframe = function (a) {
        var b = a.l,
          c = a.I;
        return function (d, e) {
          e = void 0 === e ? r : e;
          c.checkPermission({ permissionType: "iframe", F: { url: d } });
          var f = Ue(b)("iframe");
          O(f.style, {
            display: "none",
            width: "1px",
            height: "1px",
            visibility: "hidden",
          });
          f.src = d;
          f.onload = function () {
            return e();
          };
          f.onerror = r;
          Ze(b).appendChild(f);
        };
      }),
      (vq.JSON = function (a) {
        var b = a.l;
        return {
          parse: function (c) {
            try {
              return b.JSON.parse("" + c);
            } catch (d) {}
          },
          stringify: function (c) {
            try {
              return b.JSON.stringify(c);
            } catch (d) {}
          },
        };
      }),
      (vq.loadScript = function (a) {
        var b = a.l,
          c = a.I;
        return function (d, e, f) {
          c.checkPermission({ permissionType: "loadScript", F: { url: d } });
          Lk(
            b,
            d,
            y(e)
              ? Zp("ls.ol", function () {
                  return e.apply(null);
                })
              : r,
            y(f)
              ? Zp("ls.oe", function () {
                  return f.apply(null);
                })
              : void 0
          );
        };
      }),
      (vq.localStorage = function (a) {
        var b = a.I,
          c = a.l.localStorage;
        return {
          getItem: function (d) {
            b.checkPermission({
              permissionType: "localStorage",
              F: { key: d, operation: 2 },
            });
            return c.getItem(d);
          },
          setItem: function (d, e) {
            b.checkPermission({
              permissionType: "localStorage",
              F: { key: d, operation: 1 },
            });
            c.setItem(d, e);
          },
          removeItem: function (d) {
            b.checkPermission({
              permissionType: "localStorage",
              F: { key: d, operation: 1 },
            });
            c.removeItem(d);
          },
        };
      }),
      (vq.logToConsole = function (a) {
        var b = a.l,
          c = a.I,
          d = Vk(b).log,
          e = hq(b) ? 1 : 0;
        return function () {
          var f = ra.apply(0, arguments);
          c.R({ permissionType: "log", F: { logLevel: e } }) &&
            d.apply(null, ja(f));
        };
      }),
      (vq.makeNumber = function () {
        return function (a, b) {
          return Sa(a) ? +b : +a;
        };
      }),
      (vq.makeTableMap = function () {
        return function (a, b, c) {
          if (!w(a) || !u(b) || !u(c)) throw Kp("ca.c.ia");
          a = G(
            function (d, e) {
              A(e) && H(e, b) && H(e, c) && (d["" + e[b]] = e[c]);
              return d;
            },
            {},
            a
          );
          return ec(a).length ? a : null;
        };
      }),
      (vq.Math = function (a) {
        return cq(a.l.Math, "abs floor ceil round max min pow sqrt".split(" "));
      }),
      (vq.Object = function (a) {
        var b = a.l;
        return {
          keys: ec,
          values: hc,
          freeze: function (c) {
            return b.Object.freeze(c);
          },
          entries: dc,
          delete: function (c, d) {
            if (!c || !H(c, d) || w(c) || c === b) return !1;
            try {
              return delete c[d];
            } catch (e) {
              return !1;
            }
          },
        };
      }),
      (vq.parseUrl = function (a) {
        var b = a.l;
        return function (c) {
          if (u(c) && c && tq.test(c)) {
            c = ph(b, c);
            var d = c.protocol,
              e = c.host;
            if (d && ":" !== d)
              return {
                href: c.href,
                origin: e ? d + "//" + e : "null",
                protocol: d,
                host: e || "",
                hostname: c.hostname,
                port: c.port,
                pathname: c.pathname,
                search: c.search,
                searchParams: uq(c.search),
                hash: c.hash,
              };
          }
        };
      }),
      (vq.queryPermission = function (a) {
        var b = a.l,
          c = a.I;
        return function (d, e, f) {
          return (Sa(e) || u(e)) && H(oq, d) ? (0, oq[d])(b, c, d, e, f) : !1;
        };
      }),
      (vq.readTitle = function (a) {
        var b = a.l,
          c = a.I;
        return function () {
          c.checkPermission({ permissionType: "readTitle", F: null });
          return b.document.title;
        };
      }),
      (vq.sendPixel = function (a) {
        var b = a.I,
          c = a.l;
        return function (d, e, f) {
          e = void 0 === e ? r : e;
          f = void 0 === f ? r : f;
          if (!u(d)) throw Kp("ca.p.uns");
          b.checkPermission({ permissionType: "pixel", F: { url: d } });
          bq(c, d, e, f);
        };
      }),
      (vq.setCookie = function (a) {
        var b = a.l,
          c = a.I;
        return function (d, e, f, g) {
          f = void 0 === f ? {} : f;
          g = void 0 === g ? !0 : g;
          c.checkPermission({
            permissionType: "cookies",
            F: { name: d, operation: 1, options: f },
          });
          e = g ? qd(e) : e;
          d = d + "=" + e + ";";
          if (f) {
            H(f, "domain") && (d += " Domain=" + f.domain + ";");
            H(f, "path") && (d += " Path=" + f.path + ";");
            H(f, "expires") && (d += " Expires=" + f.expires + ";");
            if (H(f, "max-age")) {
              if (!rb(b, f["max-age"])) throw Kp("ca.c.mann");
              d += " Max-Age=" + f["max-age"] + ";";
            }
            if (H(f, "sameSite")) {
              if (!N(f.sameSite, ["Lax", "Strict", "None"]))
                throw Kp("ca.c.ssuop");
              d += " Same-Site=" + f.sameSite + ";";
            }
            H(f, "secure") && f.secure && (d += " Secure;");
          }
          b.document.cookie = d;
        };
      }),
      (vq.setInWindow = function (a) {
        var b = a.l,
          c = a.I;
        return function (d, e, f) {
          f = void 0 === f ? !1 : f;
          c.checkPermission({
            permissionType: "globals",
            F: { key: d, operation: 1 },
          });
          Op(d);
          try {
            var g = Pp(b, d),
              h = g.parent,
              k = g.Wa;
            if (!f && H(h, k)) return !1;
            h[k] = e;
            return !0;
          } catch (l) {
            return !1;
          }
        };
      }),
      (vq.checkInWindow = function (a) {
        var b = a.l,
          c = a.I;
        return function (d, e) {
          Op(d);
          c.checkPermission({
            permissionType: "globals",
            F: { operation: 2, key: d },
          });
          try {
            var f = Pp(b, d),
              g = f.value,
              h = H(f.parent, f.Wa);
            if (!e || !h) return h;
            var k = eq(b, g);
            return h && k === e;
          } catch (l) {
            if ("noma" === I(l, "message")) return !1;
            throw l;
          }
        };
      }),
      (vq.templateStorage = function (a) {
        function b(e) {
          c.checkPermission({ permissionType: "templateStorage", F: null });
          delete d[e];
        }
        var c = a.I,
          d = qq(a.containerId, a.le);
        return {
          getItem: function (e) {
            c.checkPermission({ permissionType: "templateStorage", F: null });
            return d[e];
          },
          setItem: function (e, f) {
            c.checkPermission({ permissionType: "templateStorage", F: null });
            d[e] = f;
          },
          removeItem: b,
          clear: function () {
            c.checkPermission({ permissionType: "templateStorage", F: null });
            L(b, ec(d));
          },
        };
      }),
      vq);
  function xq(a) {
    return function (b) {
      var c = b.Wb,
        d = b.I;
      return function (e) {
        A(e) &&
          (L(function (f) {
            "region" !== f &&
              d.checkPermission({
                permissionType: "accessConsent",
                F: { key: f, operation: 1 },
              });
          }, ec(e)),
          c.cb({
            event: "ytm.consent",
            ytm: { action: a, La: e, eventId: Ym() },
          }));
      };
    };
  }
  var yq = xq("default"),
    zq = xq("update");
  function Aq(a) {
    if (!a) return a;
    if (!u(a) && "function" === typeof a[Symbol.iterator]) {
      var b = w(a) ? a : Ta(a);
      return L(Aq, b);
    }
    if (A(a)) {
      var c = {};
      L(function (d) {
        c[d] = Aq(a[d]);
      }, ec(a));
      return c;
    }
    return a;
  }
  function Bq(a) {
    return {
      compilerVersion: a.compilerVersion,
      containerId: a.containerId,
      containerVersion: a.containerVersion,
      counter: Aq(a.counter),
      permissions: Aq(a.permissions),
      tags: Aq(a.tags),
      triggers: Aq(a.triggers),
      variables: Aq(a.variables),
    };
  }
  function Cq(a) {
    a = H(wq, a) ? wq[a] : void 0;
    if (z(a)) throw Jp("uca");
    return a;
  }
  function Dq(a, b) {
    for (var c = a.length; 0 < c; ) {
      var d = a[--c];
      if (H(d.pc, b)) return d.pc[b];
    }
  }
  function Eq(a, b) {
    a = void 0 === a ? {} : a;
    b = void 0 === b ? {} : b;
    return { pc: a, methods: b, hb: !0 };
  }
  function Fq(a, b, c) {
    b = void 0 === b ? {} : b;
    c = void 0 === c ? {} : c;
    return a.concat(Eq(b, c));
  }
  function Gq(a, b, c, d) {
    for (var e = a.length - 1; 0 <= e; --e) {
      var f = a[e];
      f.hb = !1;
      if (H(f.methods, b)) {
        f.methods[b](d ? d() : void 0);
        return;
      }
    }
    throw Jp(c);
  }
  var Hq =
      "charAt concat indexOf lastIndexOf match replace search slice split substring toLowerCase toLocaleLowerCase toString toUpperCase toLocaleUpperCase trim toString".split(
        " "
      ),
    Iq = xa(Array.prototype.reduceRight, "reduceRight");
  function Jq(a, b, c) {
    for (var d = c.length - 1; 0 <= d; ) (b = a(b, c[d], d)), --d;
    return b;
  }
  var Kq = Iq
      ? function (a, b, c) {
          return Iq.call(c, a, b);
        }
      : Jq,
    Lq =
      "concat every filter forEach indexOf join map pop push reduce reduceRight reverse shift slice some sort splice toString unshift".split(
        " "
      );
  function Mq(a, b) {
    var c = {};
    return ((c.concat = B(Array.prototype.concat, a)),
    (c.every = Na(Yb)(a)),
    (c.filter = Na(Qb)(a)),
    (c.forEach = Na(L)(a)),
    (c.indexOf = Na(jb)(a)),
    (c.join = Na(T)(a)),
    (c.map = Na(L)(a)),
    (c.pop = B(Array.prototype.pop, a)),
    (c.push = B(Array.prototype.push, a)),
    (c.reduce = function (d, e) {
      return G(d, e, a);
    }),
    (c.reduceRight = function (d, e) {
      return Kq(d, e, a);
    }),
    (c.reverse = F(a, Wm)),
    (c.shift = B(Array.prototype.shift, a)),
    (c.slice = B(Array.prototype.slice, a)),
    (c.some = Na(sc)(a)),
    (c.sort = Na(Xk)(a)),
    (c.splice = B(Array.prototype.splice, a)),
    (c.toString = F(a, Ia)),
    (c.unshift = B(Array.prototype.unshift, a)),
    c)[b];
  }
  function Nq(a) {
    return w(a) && 35 === a[0];
  }
  function Oq(a, b, c) {
    var d = n(b);
    d.next();
    b = d.next().value;
    d = d.next().value;
    b = Pq(a, b);
    a = Pq(a, d);
    if (z(b)) throw Kp("noma");
    if ("number" === typeof b)
      c = c && "toString" === a ? B(Number.prototype.toString, b) : void 0;
    else if (b === !!b) c = c && "toString" === a ? F(b, Ia) : void 0;
    else if (w(b)) c = c && N(a, Lq) ? Mq(b, a) : H(b, "" + a) ? b[a] : void 0;
    else if (u(b))
      c && N(a, Hq)
        ? ((c = {}),
          (c = ((c.charAt = B(String.prototype.charAt, b)),
          (c.concat = B(String.prototype.concat, b)),
          (c.indexOf = F(b, Ca)),
          (c.lastIndexOf = F(b, Ga)),
          (c.match = B(String.prototype.match, b)),
          (c.replace = B(String.prototype.replace, b)),
          (c.search = B(String.prototype.search, b)),
          (c.slice = B(String.prototype.slice, b)),
          (c.split = B(String.prototype.split, b)),
          (c.substring = B(String.prototype.substring, b)),
          (c.toLocaleLowerCase = B(String.prototype.toLocaleLowerCase, b)),
          (c.toLocaleUpperCase = B(String.prototype.toLocaleUpperCase, b)),
          (c.toLowerCase = B(String.prototype.toLowerCase, b)),
          (c.toUpperCase = B(String.prototype.toUpperCase, b)),
          (c.trim = F(b, wd)),
          (c.toString = F(b, Ia)),
          c)[a]))
        : (c = H(b, "" + a) ? b[a] : void 0);
    else if (A(b))
      a: {
        if (c) {
          if ("toString" === a) {
            c = F(b, Ia);
            break a;
          }
          if ("hasOwnProperty" === a) {
            c = F(b, H);
            break a;
          }
        }
        c = H(b, "" + a) ? b[a] : void 0;
      }
    else c = b["" + a];
    return c;
  }
  function Qq(a, b) {
    var c = n(b);
    c.next();
    var d = c.next().value,
      e = c.next().value,
      f = c.next().value,
      g = L(lb, a);
    return function () {
      var h = arguments,
        k = G(
          function (m, p, q) {
            if (m[p]) throw Kp("da");
            m[p] = { kind: 1, value: h[q] };
            return m;
          },
          {},
          e
        );
      d && !N(d, e) && (k[d] = { kind: 0, value: d });
      var l;
      Rq(g, f, k, {
        return: function (m) {
          l = m;
        },
      });
      return l;
    };
  }
  function Sq(a) {
    return w(a) && 42 === a[0];
  }
  function Zq(a, b) {
    var c = n(b);
    c.next();
    c = ia(c);
    return G(
      function (d, e) {
        var f = n(e),
          g = f.next().value;
        f = f.next().value;
        g = Pq(a, g);
        f = Pq(a, f);
        d["" + g] = f;
        return d;
      },
      {},
      c
    );
  }
  function $q(a) {
    return w(a) && 40 === a[0];
  }
  function ar(a, b) {
    var c = n(b);
    c.next();
    c = ia(c);
    return L(function (d) {
      return Pq(a, d);
    }, c);
  }
  function br(a, b) {
    var c = n(b);
    c.next();
    var d = c.next().value,
      e = c.next().value;
    c = c.next().value;
    e = Pq(a, e);
    c = Pq(a, c);
    switch (d) {
      case "==":
        return e == c;
      case "!=":
        return e != c;
      case "===":
        return e === c;
      case "!==":
        return e !== c;
      case "<":
        return e < c;
      case "<=":
        return e <= c;
      case ">":
        return e > c;
      case ">=":
        return e >= c;
      case "<<":
        return e << c;
      case ">>":
        return e >> c;
      case ">>>":
        return e >>> c;
      case "+":
        return e + c;
      case "-":
        return e - c;
      case "*":
        return e * c;
      case "/":
        return e / c;
      case "%":
        return e % c;
      case "|":
        return e | c;
      case "^":
        return e ^ c;
      case "&":
        return e & c;
      case "in":
        return e in c;
      case "instanceof":
        return e instanceof c;
      default:
        throw Jp("uo");
    }
  }
  function cr(a, b) {
    var c = n(b);
    c.next();
    var d = c.next().value;
    c = c.next().value;
    c = Pq(a, c);
    switch (d) {
      case "+":
        return +c;
      case "!":
        return !c;
      case "-":
        return -c;
      case "~":
        return ~c;
      default:
        throw Jp("uo");
    }
  }
  function dr(a, b, c) {
    c = void 0 === c ? [] : c;
    if ($q(b)) {
      b = n(b);
      b.next();
      b = b.next().value;
      a = Dq(a, b);
      if (!a) throw Kp("vnd");
      if (0 === a.kind && 0 === c.length) throw Kp("cva");
      return { me: c, Fe: a };
    }
    if (Nq(b)) {
      var d = n(b);
      d.next();
      b = d.next().value;
      d = d.next().value;
      d = Pq(a, d);
      c.unshift("" + d);
      return dr(a, b, c);
    }
    throw Kp("iat");
  }
  function er(a, b, c, d) {
    b = dr(a, b);
    a = b.Fe;
    var e = b.me;
    e.unshift("value");
    b = e.pop();
    a = G(
      function (f, g) {
        return f[g];
      },
      a,
      e
    );
    switch (d) {
      case "=":
        return (a[b] = c);
      case "+=":
        return (a[b] += c);
      case "-=":
        return (a[b] -= c);
      case "*=":
        return (a[b] *= c);
      case "/=":
        return (a[b] /= c);
      case "%=":
        return (a[b] %= c);
      case "<<=":
        return (a[b] <<= c);
      case ">>=":
        return (a[b] >>= c);
      case ">>>=":
        return (a[b] >>>= c);
      case "|=":
        return (a[b] |= c);
      case "^=":
        return (a[b] ^= c);
      case "&=":
        return (a[b] &= c);
      default:
        throw Jp("uo");
    }
  }
  function fr(a, b) {
    var c = n(b);
    c.next();
    var d = c.next().value,
      e = c.next().value;
    c = c.next().value;
    c = Pq(a, c);
    return er(a, e, c, d);
  }
  function Pq(a, b) {
    if (
      u(b) ||
      "[object Number]" === Object.prototype.toString.call(b) ||
      !!b === b ||
      Sq(b)
    )
      return Sq(b) ? null : b;
    if ($q(b)) {
      var c = n(b);
      c.next();
      c = c.next().value;
      c = Dq(a, c);
      if (!c) throw Kp("vnd");
      return c.value;
    }
    if (w(b) && 37 === b[0]) {
      var d = n(b);
      d.next();
      c = d.next().value;
      d = ia(d);
      c = Nq(c) ? Oq(a, c, !0) : Pq(a, c);
      if (!y(c)) throw Kp("tenf");
      d = L(F(a, Pq), d);
      return c.apply(null, d);
    }
    if (w(b) && 24 === b[0]) return Qq(a, b);
    if (Nq(b)) return Oq(a, b);
    if (w(b) && 23 === b[0]) return Zq(a, b);
    if (w(b) && 22 === b[0]) return ar(a, b);
    if (w(b) && 29 === b[0]) return br(a, b);
    if (w(b) && 25 === b[0]) return cr(a, b);
    if (w(b) && 27 === b[0]) {
      d = n(b);
      d.next();
      var e = d.next().value;
      c = d.next().value;
      d = d.next().value;
      switch (e) {
        case "++":
          e = "+=";
          break;
        case "--":
          e = "-=";
          break;
        default:
          throw Jp("uo");
      }
      c ? (c = er(a, d, 1, e)) : ((c = Pq(a, d)), er(a, d, 1, e));
      return c;
    }
    if (w(b) && 31 === b[0]) return fr(a, b);
    if (w(b) && 33 === b[0]) {
      c = n(b);
      c.next();
      d = c.next().value;
      e = c.next().value;
      c = c.next().value;
      if ("&&" === d) c = (d = Pq(a, e)) ? Pq(a, c) : d;
      else if ("||" === d) c = (d = Pq(a, e)) ? d : Pq(a, c);
      else throw Jp("uo");
      return c;
    }
    if (w(b) && 36 === b[0])
      return (
        (e = n(b)),
        e.next(),
        (d = e.next().value),
        (c = e.next().value),
        (e = e.next().value),
        (d = Pq(a, d)),
        Pq(a, d ? c : e)
      );
  }
  function gr(a) {
    return w(a) && (18 === a[0] || 19 === a[0]);
  }
  function hr(a, b) {
    var c = n(b),
      d = c.next().value;
    c = ia(c);
    var e = 18 === d;
    L(function (f) {
      var g = n(f),
        h = g.next().value;
      g = g.next().value;
      if (e && 1 === f.length) throw Jp("mca");
      f = a[a.length - 1].pc;
      if (H(f, h)) throw Kp("vr");
      g = Sa(g) ? g : Pq(a, g);
      f[h] = { kind: e ? 0 : 1, value: g };
    }, c);
  }
  function ir(a, b) {
    var c = n(b);
    c.next();
    var d = c.next().value;
    Gq(a, "return", "irs", function () {
      return Sa(d) ? d : Pq(a, d);
    });
  }
  function jr(a) {
    var b = { Ab: !1 };
    a = Fq(a, void 0, {
      continue: function () {
        b.Ab = !0;
      },
      break: r,
    });
    b.stack = a;
    b.vc = a[a.length - 1];
    return b;
  }
  function kr(a, b) {
    var c = a.vc;
    lr(a.stack, b);
    a.Ab && ((c.hb = !0), (a.Ab = !1));
    return c.hb;
  }
  function mr(a, b) {
    b = void 0 === b ? !1 : b;
    if (z(a)) return [];
    var c = Qb(function (f) {
        return (f = Object.getOwnPropertyDescriptor(a, f)) ? f.enumerable : !1;
      }, Object.getOwnPropertyNames(a)),
      d = Object.getPrototypeOf(a),
      e = d ? c.concat(mr(d, !0)) : c;
    return b
      ? e
      : Qb(function (f, g) {
          return jb(f, e) === g;
        }, e);
  }
  function lr(a, b) {
    if (w(b) && 3 === b[0]) Rq(a, b);
    else if (gr(b)) hr(a, b);
    else if (w(b) && 2 === b[0]) {
      var c = n(b);
      c.next();
      c = c.next().value;
      Pq(a, c);
    } else if (w(b) && 7 === b[0]) {
      var d = n(b);
      d.next();
      c = d.next().value;
      var e = d.next().value;
      d = d.next().value;
      Pq(a, c) ? lr(a, e) : d && lr(a, d);
    } else if (8 === b[0]) {
      c = n(b);
      c.next();
      var f = c.next().value;
      c = ia(c);
      d = e = !1;
      var g = [],
        h = [];
      f = Pq(a, f);
      for (var k = 0; k < c.length; k += 1) {
        var l = n(c[k]);
        l.next();
        var m = l.next().value;
        l = ia(l);
        var p = Ra(m);
        d = d || p;
        p || (e = e || Pq(a, m) === f);
        e && (g = g.concat(l));
        d && (h = h.concat(l));
      }
      Rq(a, [3].concat(ja(e ? g : h)), {}, { break: r });
    } else if (w(b) && 4 === b[0]) ir(a, b);
    else if (w(b) && 5 === b[0]) Gq(a, "break", "ibs");
    else if (w(b) && 6 === b[0]) Gq(a, "continue", "ics");
    else if (w(b) && 15 === b[0])
      for (
        g = n(b),
          g.next(),
          d = g.next().value,
          c = g.next().value,
          e = g.next().value,
          g = g.next().value,
          h = jr(a),
          d && (gr(d) ? hr(h.stack, d) : Pq(h.stack, d)),
          d = !0;
        d && (!c || Pq(h.stack, c));

      )
        (d = kr(h, g)), e && d && Pq(h.stack, e);
    else if (w(b) && 16 === b[0])
      for (
        e = n(b),
          e.next(),
          c = e.next().value,
          g = e.next().value,
          e = e.next().value,
          d = jr(a),
          g = Pq(d.stack, g),
          g = mr(g),
          f = !0,
          h = 0;
        f && h < g.length;
        h += 1
      )
        (f = g[h]),
          gr(c)
            ? ((k = Eq()),
              0 < h && d.stack.pop(),
              d.stack.push(k),
              (d.vc = k),
              (m = n(c)),
              (k = m.next().value),
              (m = n(m.next().value).next().value),
              hr(d.stack, [k, [m, f]]))
            : fr(d.stack, [31, "=", c, f]),
          (f = kr(d, e));
  }
  function Rq(a, b, c, d) {
    b = n(b);
    b.next();
    b = ia(b);
    a = Fq(a, c, d);
    c = a[a.length - 1];
    for (d = 0; d < b.length && c.hb; d += 1) lr(a, b[d]);
  }
  function nr(a, b, c, d, e) {
    b = n(b);
    b.next();
    var f = b.next().value;
    b = ia(b);
    a = {
      I: c.I,
      Wb: c.Wb,
      l: a,
      le: f,
      containerId: c.containerId,
      event: c.event,
    };
    f = {};
    c = O(
      c.data,
      ((f.ytmOnFailure = function () {
        return e();
      }),
      (f.ytmOnSuccess = function () {
        return d();
      }),
      f)
    );
    var g;
    f = {};
    c = Fq(
      [],
      ((f.undefined = { kind: 0, value: void 0 }),
      (f.require = { kind: 0, value: M(Cq, Na(ce)(a)) }),
      (f.data = { kind: 0, value: c }),
      f),
      {
        return: function (h) {
          g = h;
        },
      }
    );
    Rq(c, [3].concat(ja(b)));
    return g;
  }
  function or(a, b, c, d) {
    var e = b.defaultValue,
      f = c(b.key);
    if (f)
      return (
        d.checkPermission({
          ja: b,
          permissionType: "dataLayer",
          F: { key: f, operation: 2 },
        }),
        (a = I(a, f)),
        z(a) ? (e ? c(e) : void 0) : a
      );
  }
  var pr = K(function (a, b, c) {
    b = void 0 === c.min ? 0 : c.min;
    b = a.Math.random() * ((void 0 === c.max ? 2147483647 : c.max) - b + 1) + b;
    return (void 0 === c.isInt ? 0 : c.isInt) ? a.Math.floor(b) : b;
  }, mb);
  function qr(a, b) {
    var c = a(b);
    return z(c) ? void 0 : "" + c;
  }
  var rr = /^[\s\xa0]+/g,
    sr = /[\s\xa0]+$/g,
    tr = /(\xa0+|\s{2,}|\n|\r|\t)/g;
  function ur(a) {
    return (a = a.innerText || a.textContent || "")
      ? a.replace(rr, "").replace(sr, "").replace(tr, " ")
      : a;
  }
  function vr(a, b) {
    try {
      return xj(a, b);
    } catch (c) {
      throw Kp("ies");
    }
  }
  function wr(a, b, c) {
    var d = b.multi,
      e = b.dataType,
      f = c(b.selector);
    if (!f) return null;
    a = vr(f, a.document);
    a = L(function (g) {
      if ("text" === e) return ur(g);
      var h = c(b.attr);
      return h ? g.getAttribute && g.getAttribute(h) : ur(g);
    }, a);
    return d ? a : a.length ? a[0] : null;
  }
  function xr(a, b) {
    return b.length > a.length ? !1 : a.substring(a.length - b.length) === b;
  }
  function yr(a, b) {
    return u(a) && u(b) ? xr(a, b) : !1;
  }
  function zr(a, b) {
    return a === b;
  }
  function Ar(a, b) {
    return w(a) ? N(b, a) : u(a) ? Ha(a, "" + b) : !1;
  }
  function Br(a, b, c) {
    return Zb(a, b) && Zb(a, c) ? b < c : !1;
  }
  function Cr(a, b, c) {
    a = Ye(a);
    if (!a || !u(c) || !El(b)) return !1;
    try {
      return a.call(b, c);
    } catch (d) {
      return !1;
    }
  }
  function Dr(a, b, c) {
    return Zb(a, b) && Zb(a, c) ? b > c : !1;
  }
  function Er(a, b, c) {
    if (!u(b) || !u(c)) return !1;
    try {
      return new RegExp(c, a ? "i" : "").test(b);
    } catch (d) {
      return !1;
    }
  }
  function Fr(a, b) {
    return u(a) && u(b) ? lj(a, b) : !1;
  }
  function Gr(a, b) {
    if ("eq" === b) return zr;
    if ("more" === b) return F(a, Dr);
    if ("less" === b) return F(a, Br);
    if ("regex" === b) return F(!1, Er);
    if ("iRegex" === b) return F(!0, Er);
    if ("css" === b) return F(a, Cr);
    if ("inc" === b) return Ar;
    if ("start" === b) return Fr;
    if ("end" === b) return yr;
    throw Xd("fn: " + b);
  }
  function Hr(a) {
    return wa("escape", CSS.escape) ? "#" + CSS.escape(a) : "[id='" + a + "']";
  }
  function Ir(a, b) {
    if (a.document.hidden) return !1;
    var c = ef(b);
    if (z(c) || c.top === c.bottom || c.left === c.right || !a.getComputedStyle)
      return !1;
    var d = a.getComputedStyle(b);
    if ("hidden" === d.visibility) return !1;
    for (c = b; c; ) {
      if ("none" === d.display || "0" === d.opacity || "0%" === d.opacity)
        return !1;
      (c = c.parentElement) && (d = a.getComputedStyle(c));
    }
    return !0;
  }
  function Jr(a, b) {
    var c = ef(b);
    if (z(c)) return 0;
    var d = c.right - c.left,
      e = c.bottom - c.top;
    if (!d || !e) return 0;
    var f = n(bf(a)),
      g = f.next().value;
    f = f.next().value;
    return (
      (1 -
        Math.min((Math.max(0 - c.left, 0) + Math.max(c.right - g, 0)) / d, 1)) *
      (1 -
        Math.min((Math.max(0 - c.top, 0) + Math.max(c.bottom - f, 0)) / e, 1))
    );
  }
  function Kr(a) {
    try {
      return parseFloat(a);
    } catch (b) {
      return null;
    }
  }
  function Lr(a) {
    var b = [],
      c = [],
      d = !1;
    return {
      cb: function (e) {
        c.push(e);
      },
      add: function (e) {
        b.push(e);
      },
      aa: function () {
        if (!d) {
          d = !0;
          for (var e; (e = 0 < c.length ? c.shift() : b.shift()); ) a(e);
          d = !1;
        }
      },
    };
  }
  var Nr = Zp(
    "v.e.r",
    function (a, b, c, d) {
      var e = a.l,
        f = a.I,
        g = a.Tb,
        h = F(c, qr);
      if ("event" === d.type)
        return or(
          b,
          { type: "dataLayer", key: "event", permissions: d.permissions },
          h,
          f
        );
      if ("dataLayer" === d.type) return or(b, d, h, f);
      if ("cnst" === d.type) return c(d.value);
      if ("counterId" === d.type) return a.counterId;
      if ("rand" === d.type) return pr(e, b, d);
      if ("url" === d.type || "ref" === d.type) {
        a: {
          a = !1;
          b = d.component;
          var k =
            "url" === d.type
              ? (k = d.urlSource)
                ? h(k)
                : I(e, "location.href")
              : I(e, "document.referrer");
          if (k) {
            if ("queryVar" === b) {
              var l = h(d.key);
              if (!l) {
                d = void 0;
                break a;
              }
            }
            "host" === b && (a = d.Ue);
            f.checkPermission({
              ja: d,
              permissionType: "url" === d.type ? "url" : "referrer",
              F: { urlComponent: b, variableName: l },
            });
            d = ph(e, k);
            d = fq(d, b, l, a);
          } else d = void 0;
        }
        return d;
      }
      if ("cookie" === d.type)
        return (
          "null" === e.origin
            ? (d = "")
            : (h = h(d.cookieName))
            ? (f.checkPermission({
                ja: d,
                permissionType: "cookies",
                F: { name: h, operation: 2 },
              }),
              (d = dq(e, h, d.decode)[0] || ""))
            : (d = ""),
          d
        );
      if ("js" === d.type)
        return (
          (h = h(d.key))
            ? (f.checkPermission({
                ja: d,
                permissionType: "globals",
                F: { key: h, operation: 2 },
              }),
              (d = I(e, h)))
            : (d = void 0),
          d
        );
      if ("dom" === d.type) return wr(e, d, h);
      if ("pro" === d.type) {
        e = g.gd();
        try {
          return (
            (k = Mr(a, b, d, { cb: r, add: r, aa: r }, r, F(Jp("v.e.of"), Ud))),
            e("success"),
            k
          );
        } catch (m) {
          throw (e("failure"), m);
        }
      }
      if ("table" === d.type) {
        a: {
          f = h(d.input);
          l = d.rows;
          for (a = 0; a < l.length; a += 1)
            if (((b = l[a]), (k = h(b.target)), Gr(e, b.fn)(f, k))) {
              d = h(b.output);
              break a;
            }
          d = h(d["default"]);
        }
        return d;
      }
      if ("ev" === d.type) {
        a: {
          f = d.ot;
          if ("id" === d.sm) {
            l = h(d.id);
            if (!u(l) || !l) {
              d = void 0;
              break a;
            }
            l = Hr(l);
          } else if (((l = h(d.selector)), !u(l) || !l)) {
            d = void 0;
            break a;
          }
          (l = yj(l, e.document)) && Ir(e, l)
            ? ((l = Math.round(1e4 * Jr(e, l)) / 100),
              "b" === f
                ? ((f = null),
                  (d = h(d.srp)),
                  z(d) ||
                    ((f = Kr(d)),
                    (f = !rb(e, f) || 0 > f || 100 < f ? null : f)),
                  (d = l >= (f || 50)))
                : (d = l))
            : (d = void 0);
        }
        return d;
      }
      if ("contDbm" === d.type) return !0 === a.config.isPreview;
    },
    void 0,
    function (a, b, c, d) {
      b = { type: "v", eventId: b.ytm.eventId };
      !0 === a.config.isPreview && (b.id = d.id);
      return b;
    }
  );
  function Or(a, b, c) {
    var d = a.config.variables[c];
    if (!d) throw Jp("var: " + c);
    c = D([a, b], Pr);
    return Nr(a, b, c, d);
  }
  var Qr =
      /^(?!-*(?:expression|(?:moz-)?binding))(?:\s*|(?:[.#]?-?(?:[_a-z0-9-]+)(?:-[_a-z0-9-]+)*-?|-?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)(?:[a-z]{1,4}|%)?|[a-z-]+\([^)]*\)|"[^"]*"|'[^']*')(?:\s*!important)?)$/i,
    Rr =
      /[\x00\x08-\x0d\x22\x26-\x2a/\x3a-\x3e@\\\x7b\x7d\x85\xa0\u2028\u2029]/g,
    Sr = {
      "\x00": "\\0 ",
      "\b": "\\8 ",
      "\t": "\\9 ",
      "\n": "\\a ",
      "\v": "\\b ",
      "\f": "\\c ",
      "\r": "\\d ",
      '"': "\\22 ",
      "&": "\\26 ",
      "'": "\\27 ",
      "(": "\\28 ",
      ")": "\\29 ",
      "*": "\\2a ",
      "/": "\\2f ",
      ":": "\\3a ",
      ";": "\\3b ",
      "<": "\\3c ",
      "=": "\\3d ",
      ">": "\\3e ",
      "@": "\\40 ",
      "\\": "\\5c ",
      "{": "\\7b ",
      "}": "\\7d ",
      "\u0085": "\\85 ",
      "\u00a0": "\\a0 ",
      "\u2028": "\\2028 ",
      "\u2029": "\\2029 ",
    };
  function Tr(a) {
    return a.replace(Rr, function (b) {
      return Sr[b];
    });
  }
  var Ur =
      /[\x00\x09-\x0d\x22\x26\x27\x2d\x2f\x3c\x3e\x3d\x60\x85\xa0\u2028\u2029]/g,
    Vr = {
      "\x00": "&#0;",
      '"': "&quot;",
      "&": "&amp;",
      "'": "&#39;",
      "<": "&lt;",
      ">": "&gt;",
      "\t": "&#9;",
      "\n": "&#10;",
      "\v": "&#11;",
      "\f": "&#12;",
      "\r": "&#13;",
      "-": "&#45;",
      "/": "&#47;",
      "=": "&#61;",
      "`": "&#96;",
      "\u0085": "&#133;",
      "\u00a0": "&#160;",
      "\u2028": "&#8232;",
      "\u2029": "&#8233;",
    };
  function Wr(a) {
    return a.replace(Ur, function (b) {
      return Vr[b];
    });
  }
  var Xr =
      /[\x00\x08-\x0d\x22\x24\x26-\x29\x2a-\x2e/\x3a\x3c-\x3f\x5b-\x5e\x7b-\x7d\\\x85\u2028\u2029]/g,
    Yr = {
      "\x00": "\\x00",
      "\b": "\\x08",
      "\t": "\\t",
      "\n": "\\n",
      "\v": "\\x0b",
      "\f": "\\f",
      "\r": "\\r",
      '"': "\\x22",
      "&": "\\x26",
      "'": "\\x27",
      "/": "\\/",
      "<": "\\x3c",
      "=": "\\x3d",
      ">": "\\x3e",
      "\\": "\\\\",
      "\u0085": "\\x85",
      "\u2028": "\\u2028",
      "\u2029": "\\u2029",
      Ie: "\\x24",
      "(": "\\x28",
      ")": "\\x29",
      "*": "\\x2a",
      "+": "\\x2b",
      ",": "\\x2c",
      "-": "\\x2d",
      ".": "\\x2e",
      ":": "\\x3a",
      "?": "\\x3f",
      "[": "\\x5b",
      "]": "\\x5d",
      "^": "\\x5e",
      "{": "\\x7b",
      "|": "\\x7c",
      "}": "\\x7d",
    };
  function Zr(a) {
    return a.replace(Xr, function (b) {
      return Yr[b];
    });
  }
  var $r = /['()]/g;
  function as(a) {
    return "%" + a.charCodeAt(0).toString(16);
  }
  var bs = /^(?:(?:https?|mailto|tel):|[^&:/?#]*(?:[/?#]|$))/i,
    cs =
      /[\x00-\x22\x27-\x29\x3c\x3e\\\x7b\x7d\x7f\x85\xa0\u2028\u2029\uff01\uff03\uff04\uff06-\uff0c\uff0f\uff1a\uff1b\uff1d\uff1f\uff20\uff3b\uff3d]/g,
    ds = {
      "\x00": "%00",
      "\u0001": "%01",
      "\u0002": "%02",
      "\u0003": "%03",
      "\u0004": "%04",
      "\u0005": "%05",
      "\u0006": "%06",
      "\u0007": "%07",
      "\b": "%08",
      "\t": "%09",
      "\n": "%0A",
      "\v": "%0B",
      "\f": "%0C",
      "\r": "%0D",
      "\u000e": "%0E",
      "\u000f": "%0F",
      "\u0010": "%10",
      "\u0011": "%11",
      "\u0012": "%12",
      "\u0013": "%13",
      "\u0014": "%14",
      "\u0015": "%15",
      "\u0016": "%16",
      "\u0017": "%17",
      "\u0018": "%18",
      "\u0019": "%19",
      "\u001a": "%1A",
      "\u001b": "%1B",
      "\u001c": "%1C",
      "\u001d": "%1D",
      "\u001e": "%1E",
      "\u001f": "%1F",
      " ": "%20",
      '"': "%22",
      "'": "%27",
      "(": "%28",
      ")": "%29",
      "<": "%3C",
      ">": "%3E",
      "\\": "%5C",
      "{": "%7B",
      "}": "%7D",
      "\u007f": "%7F",
      "\u0085": "%C2%85",
      "\u00a0": "%C2%A0",
      "\u2028": "%E2%80%A8",
      "\u2029": "%E2%80%A9",
      "\uff01": "%EF%BC%81",
      "\uff03": "%EF%BC%83",
      "\uff04": "%EF%BC%84",
      "\uff06": "%EF%BC%86",
      "\uff07": "%EF%BC%87",
      "\uff08": "%EF%BC%88",
      "\uff09": "%EF%BC%89",
      "\uff0a": "%EF%BC%8A",
      "\uff0b": "%EF%BC%8B",
      "\uff0c": "%EF%BC%8C",
      "\uff0f": "%EF%BC%8F",
      "\uff1a": "%EF%BC%9A",
      "\uff1b": "%EF%BC%9B",
      "\uff1d": "%EF%BC%9D",
      "\uff1f": "%EF%BC%9F",
      "\uff20": "%EF%BC%A0",
      "\uff3b": "%EF%BC%BB",
      "\uff3d": "%EF%BC%BD",
    };
  function es(a) {
    bs.lastIndex = 0;
    return bs.test(a)
      ? a.replace(cs, function (b) {
          return ds[b];
        })
      : "#sYTMs";
  }
  function Pr(a, b, c) {
    if (w(c)) {
      if ("template" === c[0])
        return T(
          "",
          L(function (e) {
            return Pr(a, b, e);
          }, c.slice(1))
        );
      if ("var" === c[0])
        return (c = n(c)), c.next(), (c = c.next().value), Or(a, b, c);
      if ("escape" === c[0]) {
        var d = n(c);
        d.next();
        c = d.next().value;
        d = ia(d);
        c = Pr(a, b, c);
        return G(
          function (e, f) {
            if (7 === f) var g = a.Eb(e);
            else
              (g = "" + e),
                4 === f
                  ? (g = Zr(g))
                  : 3 === f
                  ? (g = Wr(g))
                  : 2 === f
                  ? (g = es(g))
                  : 6 === f
                  ? z(e)
                    ? (g = "")
                    : ((g = "" + e), (g = Qr.test(g) ? g : "sYTMs"))
                  : 5 === f
                  ? (g = Tr(g))
                  : 1 === f &&
                    ((g = qd(g)),
                    ($r.lastIndex = 0),
                    (g = $r.test(g) ? g.replace($r, as) : g));
            return g;
          },
          c,
          d
        );
      }
      if ("table" === c[0])
        return (
          (c = n(c)),
          c.next(),
          (c = ia(c)),
          L(function (e) {
            return G(
              function (f, g) {
                f[g] = Pr(a, b, e[g]);
                return f;
              },
              {},
              ec(e)
            );
          }, c)
        );
      if ("list" === c[0])
        return (
          (c = n(c)),
          c.next(),
          (c = ia(c)),
          L(function (e) {
            return Pr(a, b, e);
          }, c)
        );
    } else return c;
  }
  function fs(a, b) {
    return {
      checkPermission: function (c) {
        b.checkPermission(O({ ja: a }, c));
      },
      R: function (c) {
        return b.R(O({ ja: a }, c));
      },
    };
  }
  function Mr(a, b, c, d, e, f) {
    var g = a.l,
      h = a.config,
      k = a.I,
      l = c.data;
    if (!w(l)) {
      if (!H(h, "code") || !w(h.code) || !h.code[l]) throw Xd("mp");
      l = h.code[l];
    }
    k = fs(c, k);
    c = G(
      function (m, p) {
        var q = n(p),
          v = q.next().value;
        q = q.next().value;
        q = Pr(a, b, q);
        m[v] = Mp(g, q);
        return m;
      },
      {},
      dc(c.settings || {})
    );
    return nr(
      g,
      l,
      { containerId: h.containerId, I: k, Wb: d, data: c, event: b },
      e,
      f
    );
  }
  function gs(a, b) {
    var c = O({}, b, { eventId: Ym() });
    return { event: a, ytm: c };
  }
  function hs(a) {
    var b = G(
        function (e, f) {
          return e + f;
        },
        0,
        hc(a.data.tm)
      ),
      c = O({}, a.data.tm),
      d = b;
    return {
      update: function (e) {
        if (!H(c, "" + e)) return !1;
        var f = c[e];
        if (0 >= f) return !1;
        c[e] = f - 1;
        --d;
        return 0 === d;
      },
      reset: function () {
        c = O({}, a.data.tm);
        d = b;
      },
    };
  }
  function is(a, b, c) {
    a = a.qd;
    var d = hs(c);
    a.C(function (e) {
      d.update(e) &&
        (b(gs("ytm.group", { trigger: c.data.trigger })), d.reset());
    });
  }
  var js = K(Nd),
    ks = {},
    ls =
      ((ks.group = function (a, b, c, d, e, f) {
        b = c.data.trigger;
        var g = js(a);
        if (g[b]) f(Kp("t.a.s.g"));
        else {
          try {
            is(a, M(d.cb, d.aa), c);
          } catch (h) {
            f(h);
            return;
          }
          g[b] = !0;
          e();
        }
      }),
      (ks.paused = r),
      (ks.pro = Mr),
      ks);
  function ms(a, b, c, d) {
    return new Y(function (e, f) {
      if (H(ls, c.type)) (0, ls[c.type])(a, b, c, d, e, f);
      else f(Jp("y.u.t." + c.type, "yme"));
    });
  }
  function ns(a, b, c, d, e) {
    var f = a.config,
      g = a.Tb,
      h = !0 === f.isPreview;
    c = L(
      function (k) {
        function l() {
          return Y.all(
            L(function (q) {
              return ms(a, b, f.tags[q], e);
            }, m.ft || [])
          );
        }
        var m = f.tags[k];
        if (!m) return Y.reject(Xd("i.conf." + f.containerVersion + "-" + k));
        var p = g.ed(m.type, m.id);
        return ms(a, b, m, e)
          .then(
            function () {
              p("success");
              return Y.all(
                L(function (q) {
                  return ms(a, b, f.tags[q], e);
                }, m.ct || [])
              );
            },
            function (q) {
              p("failure");
              var v = { eventId: b.ytm.eventId, type: "t" };
              h && (v.id = m.id);
              $p("t.e.r", v)(q);
            }
          )
          .then(l, l);
      },
      Xk(function (k, l) {
        return k - l;
      }, c)
    );
    L(Zp("t.e.m", de), d);
    Y.all(c)["catch"]($p("t.e", { type: "c", eventId: b.ytm.eventId }));
  }
  var os = ["ytm.consent", "consent"],
    ps = ["default", "update"];
  function qs(a) {
    var b = Ta(a.classList),
      c = ur(a),
      d = a.getAttribute("id");
    var e =
      a.getAttribute("formAction") ||
      a.getAttribute("action") ||
      a.getAttribute("href") ||
      a.getAttribute("src") ||
      a.getAttribute("code") ||
      a.getAttribute("codebase") ||
      "";
    return {
      element: a,
      elementClasses: b,
      elementText: c,
      elementId: d,
      elementUrl: e,
      elementTarget:
        a.getAttribute("formTarget") || a.getAttribute("target") || "",
    };
  }
  var rs = ["ytm.click", "ytm.linkClick", "ytm.formSubmit"];
  function ss(a, b, c) {
    return N(b, rs) && c
      ? gs(b, qs(c))
      : "ytm.init" === b || "ytm.init_consent" === b
      ? gs(b, { timestamp: W(a)(mf) })
      : gs(b, {});
  }
  function ts(a, b) {
    var c = a.data;
    c = "id" === c.Xc ? Hr(c.id) : c.selector;
    var d = [];
    El(b) && b.matches(c) && d.push(b);
    return d.concat(vr(c, b));
  }
  function us() {
    return { na: !1, ya: !1, Z: null, zb: 0 };
  }
  function vs(a, b, c) {
    function d(t, x, E) {
      var C = qs(t);
      x = gs("ytm.elementVisibility", {
        element: t,
        elementClasses: C.elementClasses,
        elementText: C.elementText,
        elementId: C.elementId,
        visibleRatioPercent: Math.round(1e4 * x) / 100,
        visibleDuration: E / 1e3,
        trigger: c.data.trigger,
      });
      E = g(t);
      "opp" === p
        ? E.ya ||
          (q.disconnect(), h && h.disconnect(), (E.ya = !0), (E.na = !1), b(x))
        : "ope" === p
        ? E.na && !E.ya && (q.unobserve(t), (E.ya = !0), (E.na = !1), b(x))
        : b(x);
    }
    function e(t) {
      q.unobserve(t);
      t = g(t);
      t.Z && (f.clearInterval(t.Z), (t.Z = null));
      t.na = !1;
    }
    var f = a.l;
    a = a.uc;
    var g = K(us),
      h = null,
      k = c.data,
      l = k.Wc,
      m = k.$b,
      p = k.Fc;
    k = k.Pc;
    var q = new f.IntersectionObserver(
        U(f, "ytm.ev.ioc", function (t) {
          return L(function (x) {
            var E = x.target;
            x = x.intersectionRatio;
            var C = g(E);
            C.Z && (f.clearInterval(C.Z), (C.Z = null));
            if (!(x < m / 100 || !C.na || C.ya))
              if (0 === l) d(E, x, 0);
              else {
                var S = C.zb,
                  Z = W(f)(mf);
                C.Z = zf(
                  f,
                  function () {
                    var Yc = W(f)(mf);
                    C.zb = S + Yc - Z;
                    C.zb < l ||
                      ("mpe" === p
                        ? ((C.zb = 0), (Z = W(f)(mf)))
                        : C.Z && (f.clearInterval(C.Z), (C.Z = null)),
                      C.ya || d(E, Jr(f, E), l));
                  },
                  100,
                  "yt.ev"
                );
              }
          }, t);
        }),
        { threshold: [c.data.$b / 100] }
      ),
      v = Hb(function (t) {
        var x = g(t);
        x.ya || x.na || (q.observe(t), (x.na = !0));
      });
    v(ts(c, f.document));
    k &&
      wa("MutationObserver", f.MutationObserver) &&
      ((h = new f.MutationObserver(
        U(f, "c.io.ev", function (t) {
          return L(function (x) {
            switch (x.type) {
              case "childList":
                L(function (Z) {
                  El(Z) && v(ts(c, Z));
                }, x.addedNodes);
                L(function (Z) {
                  El(Z) && ((Z = ts(c, Z)), L(e, Z));
                }, x.removedNodes);
                break;
              case "attributes":
                var E = x.target,
                  C = x.attributeName;
                x = x.oldValue;
                if (El(E) && C && x !== E.getAttribute(C)) {
                  var S = ts(c, E);
                  v(S);
                  Hk(f, E, function (Z) {
                    El(Z) && g(Z).na && !N(Z, S) && e(Z);
                  });
                }
            }
          }, t);
        })
      )),
      h.observe(f.document.body, {
        childList: !0,
        subtree: !0,
        attributes: !0,
        attributeOldValue: !0,
      }));
    a(function () {
      q.disconnect();
      h && h.disconnect();
    });
  }
  function ws(a, b, c, d) {
    d = void 0 === d ? !1 : d;
    var e = a.l,
      f = null;
    z(c) ||
      ((a = "" + Pr(a, b, c)), (f = d ? Kr(a) : sb(a)), rb(e, f) || (f = null));
    return f;
  }
  var xs = K(Nd),
    ys = K(function (a) {
      return (a = I(a, "trustedTypes"))
        ? a.createPolicy("ytm#policy", {
            createHTML: lb,
            createScript: lb,
            createScriptURL: lb,
          })
        : null;
    });
  function zs(a) {
    for (var b = []; a.firstChild; ) b.push(a.removeChild(a.firstChild));
    return b;
  }
  function As(a) {
    return (a = Qe(function (b) {
      return !!b.nonce;
    }, xj("style, link, script", a.document)))
      ? a.nonce
      : void 0;
  }
  function Bs(a, b, c, d, e, f, g) {
    b = b("script");
    b.type = "text/javascript";
    b.async = g.async;
    g.src &&
      ((b.src = c ? c.createScriptURL(g.src) : g.src),
      (b.onload = function () {
        return e();
      }));
    g.text && (b.text = c ? c.createScript(g.text) : g.text);
    wj(a) && (a = As(a)) && b.setAttribute("nonce", a);
    b.charset = g.charset;
    b.id = g.id;
    b.onerror = function () {
      return f();
    };
    d(b, null);
    z(g.src) && e();
  }
  function Cs(a, b, c, d, e) {
    try {
      if (0 === b.length) d();
      else {
        var f = b.shift();
        if (f) {
          var g = zb("insertBefore", a);
          if (Ra(g)) e();
          else {
            var h = D([a, b, c, d, e], Cs);
            if ("SCRIPT" === gf(f) && "text/ytmscript" === f.type)
              c(g, h, e, {
                text: f.text || f.textContent || f.innerText || "",
                charset: f.charset || "",
                async: !1,
                id: f.id,
                src: f.getAttribute("data-ytmsrc"),
              });
            else if (
              f.innerHTML &&
              -1 < Ba(f.innerHTML.toLowerCase(), "<script")
            ) {
              var k = zs(f);
              g(f, null);
              Cs(f, k, c, h, e);
            } else g(f, null), h();
          }
        } else e();
      }
    } catch (l) {
      e();
    }
  }
  function Ds(a, b, c, d) {
    u(b)
      ? Ff(
          a,
          "ytm"
        )(
          Bf(d, function () {
            var e = "<div>" + b + "</div>",
              f = Ue(a),
              g = f("div"),
              h = ys(a);
            g.innerHTML = h ? h.createHTML(e) : e;
            z(g.lastChild)
              ? c()
              : ((e = zs(g.lastChild)),
                (f = D([a, f, h], Bs)),
                Cs(a.document.body, e, f, c, d));
          })
        )
      : d();
  }
  function Es(a) {
    return u(a)
      ? G(
          function (b, c) {
            var d = sb(c);
            !z(d) && 0 <= d && 100 >= d && b.push(d);
            return b;
          },
          [],
          a.split(",")
        )
      : [];
  }
  var Fs = K(Nd),
    Gs = K(function (a, b) {
      function c() {
        L(function (t) {
          t = +t;
          if (!(t > k)) {
            var x = h[t];
            x &&
              b(
                gs("ytm.scrollDepth", {
                  direction: "vertical",
                  units: "percent",
                  threshold: t,
                  tags: x,
                })
              );
            delete h[t];
          }
        }, ec(h));
        0 === ec(h).length && e();
      }
      function d() {
        var t = f.scrollY,
          x = n(bf(f));
        x.next();
        x = x.next().value;
        var E = n(df(f));
        E.next();
        x = E.next().value - x;
        0 >= x ||
          !f.isFinite(x) ||
          ((t = Math.max(0, Math.min(100, Math.round((t / x) * 100)))),
          t > k && (k = t),
          c());
      }
      function e() {
        m.ua(f, [q], v);
        m.ua(f, ["resize"], d);
        l = !1;
      }
      var f = a.l,
        g = a.uc,
        h = {},
        k = 0,
        l = !1,
        m = Xc(f),
        p = H(f, "onscrollend"),
        q = p ? "scrollend" : "scroll",
        v = p ? d : $m(f, d, 100, "ytm.sd").fn;
      g(e);
      return function (t, x) {
        L(function (E) {
          H(h, "" + E) || (h[E] = []);
          (E = h[E]) && !N(t, E) && E.push(t);
        }, x);
        !l &&
          0 < ec(h).length &&
          (m.C(f, [q], v), m.C(f, ["resize"], d), (l = !0));
        d();
      };
    });
  function Hs(a, b) {
    var c = a.l,
      d = a.dispatchEvent;
    if (b.limit && b.sequence >= b.limit && b.id) c.clearInterval(b.id);
    else {
      b.sequence += 1;
      c = W(c)(mf);
      var e = {};
      c = gs(
        "ytm.timer",
        ((e.id = +b.id),
        (e.sequence = b.sequence),
        (e.interval = b.interval),
        (e.limit = b.limit),
        (e.startTime = b.startTime),
        (e.currentTime = c),
        (e.elapsedTime = c - b.startTime),
        (e.timer = b.xe),
        e)
      );
      d(c);
    }
  }
  var Is = K(Nd);
  function Js(a, b, c, d) {
    if (!H(b, c)) return !1;
    a = b[c];
    if (H(a, "allKeys") && a.allKeys & d.operation) return !0;
    if (!H(a, "keys")) return !1;
    a = a.keys;
    b = d.key;
    return H(a, b) ? !!(a[b] & d.operation) : !1;
  }
  function Ks(a, b, c, d) {
    if (!H(b, c)) return !1;
    b = b[c];
    if (H(b, "allUrls")) return !!b.allUrls;
    if (!H(b, "allow")) return !1;
    var e = d.url;
    return sc(function (f) {
      var g = ph(a, e);
      if (!g.protocol || "https:" !== g.protocol) return !1;
      f = ph(a, f);
      return g.host &&
        f.host &&
        (lj(f.host, "*.") ? xr(g.host, f.host.substring(2)) : g.host === f.host)
        ? "/" === f.pathname
          ? !0
          : xr(f.pathname, "/*")
          ? lj(g.pathname, f.pathname.substring(0, f.pathname.length - 2))
          : f.pathname === g.pathname
        : !1;
    }, b.allow);
  }
  function Ls(a, b, c, d) {
    if (!H(b, c)) return !1;
    a = b[c];
    b = d.urlComponent;
    if ("queryVar" === b) {
      if (H(a, "query") && a.query) return !0;
      d = d.variableName;
      return H(a, "queryVars") && d ? N(d, a.queryVars) : !1;
    }
    return !!a[b];
  }
  var Ms = {},
    Ns =
      ((Ms.cookies = function (a, b, c, d) {
        if (!H(b, "cookies")) return !1;
        b = b.cookies;
        a = d.operation;
        if (H(b, "allKeys") && 2 === a) return !!(b.allKeys.access & a);
        if (!H(b, "keys")) return !1;
        c = b.keys;
        var e = d.name;
        b = H(c, e) ? c[e] : { access: 0 };
        if (2 === a) return !!(b.access & a);
        if (1 === a) {
          d = d.options;
          if (!H(c, e) || !d) return !1;
          c = b.access;
          e = b.domain;
          var f = b.path,
            g = b.secure,
            h = b.Te,
            k = !z(d.expires) || !z(d["max-age"]);
          if (H(b, "session") && h)
            if (1 === h) {
              if (k) return !1;
            } else if (!k) return !1;
          return !(c & a) ||
            (H(b, "domain") && e !== d.domain) ||
            (H(b, "path") && f !== d.path) ||
            (H(b, "secure") &&
              ((1 === g && !d.secure) || (2 === g && d.secure)))
            ? !1
            : !0;
        }
        return !1;
      }),
      (Ms.dataLayer = Js),
      (Ms.globals = Js),
      (Ms.iframe = Ks),
      (Ms.loadScript = Ks),
      (Ms.localStorage = Js),
      (Ms.log = function (a, b, c, d) {
        return H(b, "log") ? d.logLevel >= b.log : !1;
      }),
      (Ms.pixel = Ks),
      (Ms.readTitle = function (a, b) {
        return H(b, "readTitle") ? b.readTitle : !1;
      }),
      (Ms.referrer = Ls),
      (Ms.templateStorage = function (a, b) {
        return H(b, "templateStorage") ? !!b.templateStorage : !1;
      }),
      (Ms.url = Ls),
      Ms);
  function Os(a, b, c) {
    var d = a.permissionType,
      e = a.F;
    a = { counterId: b, containerId: c, permissionType: a.permissionType };
    if ("globals" === d) {
      d = e.key;
      a: switch (e.operation) {
        case 2:
          e = "read";
          break a;
        case 1:
          e = "write";
          break a;
        case 4:
          e = "execute";
          break a;
        default:
          throw Xd("uvac");
      }
      return O(a, { data: { key: d, operation: e } });
    }
    return "dataLayer" === d || "localStorage" === d
      ? O(a, { data: { key: e.key, operation: iq(e.operation) } })
      : "url" === d || "referrer" === d
      ? O(a, {
          data:
            "queryVar" === e.urlComponent
              ? { component: e.urlComponent, key: e.variableName }
              : { component: e.urlComponent },
        })
      : "iframe" === d || "loadScript" === d || "pixel" === d
      ? O(a, { data: { url: e.url } })
      : "cookies" === d
      ? ((d = iq(e.operation)),
        (b = e.name),
        (c = e.options),
        (e =
          1 === e.operation && c
            ? { operation: d, name: b, options: O({}, c) }
            : { operation: d, name: b }),
        O(a, { data: e }))
      : O(a, { data: null });
  }
  var Ps =
      "cookies dataLayer globals iframe loadScript localStorage log pixel readTitle referrer url html".split(
        " "
      ),
    Qs = K(function () {
      var a = {};
      return {
        Ad: function (b, c) {
          N(b, Ps) && y(c) && (H(a, b) || (a[b] = []), a[b].push(c));
        },
        Cd: function (b, c, d) {
          var e = H(a, b.permissionType) && a[b.permissionType];
          if (!e) return !0;
          var f = Os(b, c, d);
          return !sc(function (g) {
            try {
              return !1 === g(f);
            } catch (h) {
              return !0;
            }
          }, e);
        },
      };
    }),
    Rs = Sn + "-tags/_/ytm-debugger.js",
    Ss = /(?:^|\.)dzen\.ru$/,
    Ts = K(function (a) {
      a = R(a).hostname;
      var b = !1;
      a && (b = -1 !== a.search(Ss));
      return b;
    }),
    Us = /(?:^|\.)vk\.link$/,
    Vs = K(function (a) {
      a = R(a).hostname;
      var b = !1;
      a && (b = -1 !== a.search(Us));
      return b;
    }),
    Ws = RegExp(
      "^(.*\\.)?((yandex(-team)?)\\.(?:\\w+|com?\\.\\w+)|ya\\.(ru|cc)|dzen\\.ru|vk\\.(ru|com)|ok\\.ru|pikabu\\.ru|vc\\.ru|avito\\.ru)$"
    ),
    Xs = K(function (a) {
      a = R(a).hostname;
      return !!a && -1 !== a.search(Ws);
    });
  function Ys(a, b) {
    var c = P(a),
      d = {};
    d = c.o("ydeb", ((d.ctydl = []), (d.ypc = b), d));
    c.B("ydeb", d);
    return d;
  }
  var Zs = V("ytm.d.dl", function (a, b) {
    var c = Bq(b),
      d = Ys(a, c);
    return {
      trigger: U(a, "ytm.d.tr", function (e) {
        100 <= d.ctydl.length && pc(d.ctydl);
        d.ctydl.push(e);
      }),
    };
  });
  function $s(a, b) {
    var c = Ne(a, "", "ytm-debugger");
    b
      ? c.o("nonce") !== b && (c.B("nonce", b), c.wa("data"))
      : (c.wa("nonce"), c.wa("data"));
  }
  var at =
      "ytm.init_consent ytm.init ytm.js ytm.dom ytm.load ytm.click ytm.linkClick ytm.formSubmit ytm.timer ytm.scrollDepth ytm.elementVisibility ytm.group ytm.historyChange ytm.consent".split(
        " "
      ),
    bt = ["ytm.js"],
    ct = ["ytm.js", "ytm.dom", "ytm.load"];
  function dt(a) {
    a = I(a, "id");
    return !(!a || "ytm-debugger-script-root" !== a);
  }
  function et(a, b) {
    return Xc(a).C(a.document, ["click"], function (c) {
      (c = Ti(c)) && !dt(c) && b(ss(a, "ytm.linkClick", c));
    });
  }
  function ft(a, b, c, d, e) {
    e = void 0 === e ? a.document : e;
    return Xc(a).C(e, d, function (f) {
      dt(f.target) || b(ss(a, c, f.target));
    });
  }
  function gt(a, b, c) {
    return N(a.document.readyState, ["complete", "interactive"])
      ? (b(ss(a, c)), r)
      : ft(a, b, c, ["DOMContentLoaded"]);
  }
  function ht(a) {
    var b = n(a.split("#"));
    a = b.next().value;
    b = b.next().value;
    if (b)
      try {
        var c = decodeURIComponent(b);
      } catch (d) {
        c = b;
      }
    else c = "";
    return [a || "", c];
  }
  function it(a, b, c) {
    var d = I(a, "history." + b);
    if (y(d)) {
      var e = U(a, "p.h.m." + ("pushState" === b ? "ps" : "rs"), function (f) {
        var g = n(ht(a.location.href)),
          h = g.next().value;
        g = g.next().value;
        c({
          source: "pushState" === b ? "pushState" : "replaceState",
          state: f,
          url: h,
          xa: g,
        });
      });
      try {
        a.history[b] = function (f, g, h) {
          d.call(a.history, f, g, h);
          e(f);
        };
      } catch (f) {}
    }
  }
  var jt = K(function (a) {
    var b = Gf(a),
      c = Xc(a);
    it(a, "pushState", b.trigger);
    it(a, "replaceState", b.trigger);
    c.C(
      a,
      ["hashchange"],
      U(a, "ho.hc", function (d) {
        var e = n(ht(I(d, "target.location.href") || a.location.href));
        d = e.next().value;
        e = e.next().value;
        b.trigger({ source: "hashchange", state: null, url: d, xa: e });
      })
    );
    c.C(
      a,
      ["popstate"],
      U(a, "ho.ps", function (d) {
        var e = n(ht(I(d, "target.location.href") || a.location.href)),
          f = e.next().value;
        e = e.next().value;
        b.trigger({ source: "popstate", state: d.state, url: f, xa: e });
      })
    );
    return b;
  });
  function kt(a, b) {
    var c = n(ht(a.location.href)),
      d = c.next().value;
    c = c.next().value;
    var e = { source: null, state: a.history.state, url: d, xa: c };
    d = $m(
      a,
      function (f) {
        var g = "popstate" === e.source || "popstate" === f.source,
          h = "hashchange" === e.source || "hashchange" === f.source;
        if (e.xa !== f.xa || !g || !h) {
          g = O({}, e);
          e = f;
          h = f.source;
          if (Ra(h)) throw Jp("m.e.hc");
          f = gs("ytm.historyChange", {
            historyChangeSource: h,
            oldUrlFragment: g.xa,
            newUrlFragment: f.xa,
            oldHistoryState: g.state,
            newHistoryState: f.state,
            oldUrl: g.url,
            newUrl: f.url,
          });
          b(f);
        }
      },
      50,
      "hc"
    ).fn;
    c = jt(a);
    c.C(d);
    return F(d, c.qa);
  }
  function lt(a, b, c) {
    if ("ytm.linkClick" === b) return et(a, c);
    if ("ytm.js" === b) return gt(a, c, "ytm.js");
    if ("ytm.dom" === b) return gt(a, c, "ytm.dom");
    if ("ytm.load" === b)
      return (
        "complete" === a.document.readyState
          ? (c(ss(a, "ytm.load")), (a = r))
          : (a = ft(a, c, "ytm.load", ["load"], a)),
        a
      );
    if ("ytm.click" === b) return ft(a, c, "ytm.click", ["click"]);
    if ("ytm.formSubmit" === b)
      return ft(a, c, "ytm.formSubmit", ["submit"], a);
    if ("ytm.historyChange" === b) return kt(a, c);
  }
  function mt(a, b) {
    var c = a[b["var"]];
    c = c && "event" === c.type;
    var d = "regex" === b.fn || "eq" === b.fn;
    if (u(b.target) && c && d) return b;
  }
  function nt(a) {
    return Fb(M(J("conditions"), Gb(F(a.variables, mt)), Rb), a.triggers);
  }
  function ot(a, b, c) {
    var d = void 0 === d ? "dataLayer" : d;
    c = nt(c);
    var e = G(
        function (h, k) {
          var l = k.target;
          "eq" === k.fn && N(l, at) && -1 === jb(l, h) && h.push(l);
          return h;
        },
        [],
        c
      ),
      f = G(
        function (h, k) {
          var l = k.target;
          "eq" === k.fn
            ? h.push(F(l, zr))
            : Zp("dl.ee", function () {
                h.push($a(new RegExp(l)));
              })();
          return h;
        },
        [],
        Qb(function (h) {
          h = h.target;
          return !N(h, at) || N(h, bt);
        }, c)
      ),
      g = [];
    L(
      function (h) {
        (h = lt(a, h, M(b.add, b.aa))) && g.push(h);
      },
      Xk(function (h, k) {
        var l = nc(a)(h, ct),
          m = nc(a)(k, ct);
        return -1 === l ? 1 : -1 === m ? -1 : l - m;
      }, e)
    );
    c = I(a, d);
    c || ((c = []), (a[d] = c));
    Fi(a, c, function (h) {
      h.Ba.C(function (k) {
        var l = I(k, "event");
        if (A(k) && l && sc(Qa(l), f))
          (l = b.add),
            A(k) &&
              (A(k.ytm) ? (k.ytm.eventId = Ym()) : (k.ytm = { eventId: Ym() })),
            l.call(b, k),
            b.aa();
        else if (k) {
          var m = n(Va(k));
          k = m.next().value;
          l = m.next().value;
          m = m.next().value;
          "consent" === k &&
            N(l, qo) &&
            A(m) &&
            (b.cb({
              event: "consent",
              ytm: { action: l, La: m, eventId: Ym() },
            }),
            b.aa());
        }
      });
      g.push(h.unsubscribe);
    });
    return function () {
      return L(ce, g);
    };
  }
  function pt(a, b) {
    var c = ec(b);
    return G(
      function (d, e) {
        d[e] = a(b[e]);
        return d;
      },
      {},
      c
    );
  }
  function qt(a, b) {
    return L(function (c) {
      if ("pro" === c.type) return (c = c.settings), z(c) ? {} : pt(a, c);
      c = c.data;
      return A(c) ? pt(a, c) : {};
    }, b);
  }
  function rt(a, b) {
    return L(function (c) {
      return a(c.target);
    }, b.conditions);
  }
  var st = Zp("d.t.ve", function (a, b, c) {
      var d = {};
      return (d.i = c), (d.ct = rt(a, b)), d;
    }),
    tt = Zp("d.t.ie", function (a, b, c, d) {
      var e = G(
          function (g, h, k) {
            b(h) && g.push(k);
            return g;
          },
          [],
          c.conditions
        ),
        f = {};
      return (f.i = d), (f.ct = rt(a, c)), (f.fci = e), f;
    });
  function ut(a, b, c) {
    return L(
      Zp(
        "d.ev.e",
        function (d) {
          return "generated" === I(d, "source") ? "" : "" + Nr(b, c, a, d);
        },
        "Error during value computation"
      ),
      b.config.variables
    );
  }
  var vt = Zp(
    "c.ch",
    function (a, b, c) {
      var d = a.l,
        e = Or(a, b, c["var"]),
        f = c.target,
        g = c.not;
      c = Gr(d, c.fn);
      a = Pr(a, b, f);
      return g ? !c(e, a) : c(e, a);
    },
    !1,
    function (a, b) {
      return { type: "tr", eventId: b.ytm.eventId };
    }
  );
  function wt(a, b, c) {
    return (c = a.config.tags[c].fc) && c.length
      ? Yb(function (d) {
          return vt(a, b, d);
        }, c)
      : !0;
  }
  function xt(a) {
    var b = a.Tb,
      c = a.Kd,
      d = a.qd,
      e = a.config.triggers,
      f = Lr(function (g) {
        var h = Zp("d.ev.c", D([a, g], Pr)),
          k = new Gj(),
          l = G(
            function (v, t, x) {
              var E = !sc(function (S) {
                return !vt(a, g, S);
              }, t.conditions);
              if (c)
                if (E) {
                  var C = st(h, t, x);
                  v.ic.Cc.push(C);
                } else (C = tt(h, D([a, g], vt), t, x)), v.ic.Dc.push(C);
              E &&
                ((E = b.fd(g.event, t.tags)),
                v.od.push(E),
                L(function (S) {
                  k.has(S) || (wt(a, g, S) && v.kd.push(S), k.add(S));
                }, t.tags),
                d.trigger(x));
              return v;
            },
            { kd: [], od: [], ic: { Cc: [], Dc: [] } },
            e
          ),
          m = l.kd,
          p = l.od;
        l = l.ic;
        if (c) {
          var q = {};
          l =
            ((q.event = "t"),
            (q.ev = g.event),
            (q.e = l.Cc),
            (q.vv = ut(h, a, g)),
            (q.ne = l.Dc),
            (q.et = qt(h, a.config.tags)),
            (q.fe = g),
            (q.eid = g.ytm.eventId),
            q);
          c.trigger(l);
        }
        m.length && ns(a, g, m, p, f);
      });
    return f;
  }
  var yt = Zp("p.ss", function (a) {
    var b = 0.99 >= a.Math.random(),
      c = Lh(a, { id: 102974846, M: "0" }, "er"),
      d = am(a, c, 102974846);
    return [
      b,
      function (e, f) {
        var g = {},
          h = {};
        if ("tgExec" === e) {
          var k = {};
          var l = {},
            m = {};
          k =
            ((m[f.status] = ((l[f.tagType] = ((k[f.counterId] = f), k)), l)),
            m);
        } else
          "trExec" === e
            ? ((k = {}),
              (l = {}),
              (k = ((l[f.event] = ((k[f.counterId] = f), k)), l)))
            : ((k = {}),
              (l = {}),
              (k = ((l[f.status] = ((k[f.counterId] = f), k)), l)));
        g = ((h[e] = ((g["2720"] = k), g)), h);
        d(g);
      },
    ];
  });
  function zt(a) {
    if ((a = he(a))) {
      var b = I(a, "timing.navigationStart") || I(a, "timeOrigin");
      if (!z(b)) {
        var c = xa(a.now, "now");
        if (y(c)) return (c = B(c, a)), [b, c];
      }
    }
  }
  function At(a) {
    if (!a) return 0;
    var b = n(a);
    a = b.next().value;
    b = b.next().value;
    return Math.round(b() + a);
  }
  function Bt(a, b, c, d) {
    function e(m) {
      k(m.type, m.La);
    }
    var f = Hf(a, "ytm.mon"),
      g = n(yt(a)),
      h = g.next().value,
      k = g.next().value;
    if (h || d)
      return {
        ed: function () {
          return r;
        },
        fd: function () {
          return r;
        },
        gd: function () {
          return r;
        },
        zc: r,
      };
    var l = zt(a);
    f.C(["PRIVATE"], e);
    return {
      ed: function (m, p) {
        var q = {
          start: At(l),
          tagType: m,
          We: p,
          counterId: b,
          containerId: c.containerId,
          containerVersion: c.containerVersion,
          compilerVersion: c.compilerVersion,
        };
        return function (v) {
          v = O(q, { status: v, finish: At(l) });
          f.trigger("PRIVATE", { type: "tgExec", La: v });
        };
      },
      fd: function (m, p) {
        var q = {
          start: At(l),
          tags: p,
          counterId: b,
          containerId: c.containerId,
          containerVersion: c.containerVersion,
          compilerVersion: c.compilerVersion,
          event: m.slice(0, 150),
        };
        return function () {
          var v = O(q, { finish: At(l) });
          f.trigger("PRIVATE", { type: "trExec", La: v });
        };
      },
      gd: function () {
        var m = {
          start: At(l),
          counterId: b,
          containerId: c.containerId,
          containerVersion: c.containerVersion,
          compilerVersion: c.compilerVersion,
        };
        return function (p) {
          p = O(m, { status: p, finish: At(l) });
          f.trigger("PRIVATE", { type: "varExec", La: p });
        };
      },
      zc: D([["PRIVATE"], e], f.qa),
    };
  }
  function Ct(a, b, c, d) {
    function e(g) {
      var h;
      if ((h = f(g, c, d))) {
        h = g.permissionType;
        if (!H(Ns, h)) throw Jp("y.u.p." + h);
        var k = g.ja;
        g = g.F;
        k =
          !Sa(k.permissions) && H(b, "" + k.permissions)
            ? b[k.permissions]
            : {};
        h = (0, Ns[h])(a, k, h, g);
      }
      return h;
    }
    var f = Qs(a).Cd;
    return {
      checkPermission: function (g) {
        if (!e(g)) {
          g = Os(g, c, d);
          var h = Jp("Permission denied for " + g.permissionType, "yue");
          h.cause = g;
          Ud(h);
        }
      },
      R: e,
    };
  }
  function Dt(a, b) {
    var c = P(a),
      d = {};
    c.V("ytm_s", ((d.cm = {}), d));
    var e = 0,
      f = c.o("ytm_s").cm;
    return {
      Eb: function (g) {
        if (H(f, b)) f[b][e] = g;
        else {
          var h = {};
          f[b] = ((h[e] = g), h);
        }
        g = 'Ya["_metrika"]["ytm_s"]["cm"]["' + b + '"][' + e + "]";
        e += 1;
        return g;
      },
    };
  }
  var Et = M(ec, oc);
  function Ft(a, b) {
    return b.Ld || Ts(a) || Vs(a) ? Ef(!1) : Df(cj(b, J("settings.aytm")));
  }
  var Gt = K(Nd, Q);
  function Ht(a, b, c, d) {
    var e = Gt(c).oe;
    if (!e) throw Xd("im.no");
    Lk(a, Sn + "/" + b + ".js?ver=2720&b=e", function () {
      var f = P(a).o("ytmm");
      (f = I(f, b + ".init")) && f(e, d, "2720");
    });
  }
  var It = V("p.ips", function (a, b) {
      cj(b, function (c) {
        (I(c, "settings.phchange") || I(c, "settings.phhide")) &&
          Ht(a, "tag_phone", b, c);
      });
    }),
    Jt = V("p.tv", function (a) {
      if (kl(a)) {
        var b = P(a);
        ll(a).then(function (c) {
          b.B("lgguid", c);
        }, U(a, "p.tv.p"));
      }
    }),
    Kt = {},
    Lt = K(Nd),
    Mt = M(Za("exec", /counterID=(\d+)/), J("1")),
    Nt = Ma(function (a, b) {
      var c = mc(b),
        d = n(c),
        e = d.next().value;
      d = ia(d);
      var f = "" + e;
      var g = Mt(f);
      g
        ? (f = { id: g, M: "0" })
        : -1 === Ba(f, ":")
        ? (f = (f = ub(f)) ? { id: f, M: "0" } : void 0)
        : ((g = n(f.split(":"))),
          (f = g.next().value),
          (g = g.next().value),
          (f = (f = ub(f)) ? { id: f, M: ye(g) ? "1" : "0" } : void 0));
      g = a.Ya[Rd];
      if (f) {
        var h = n(c);
        h.next();
        d = h.next().value;
        h = ia(h);
        if (d) {
          var k = Xh(a, f),
            l = Q(f),
            m = Lt(a);
          m[l] || (m[l] = {});
          l = m[l];
          if (!b.ym_xqd) {
            if ((m = Kt[d]))
              for (var p = 0; p < m.length; p += 1)
                if ((0, m[p])(a, f, h, k)) return;
            "init" === d
              ? ((b.ym_xqd = !0),
                k
                  ? ((c = {}), Uh(a, "" + e, "dc", ((c.key = e), c)))
                  : (a["yaCounter" + f.id] = new g(O({}, h[0], f))))
              : k && k[d] && l.Vd
              ? (k[d].apply(k, ja(h)), (b.ym_xqd = !0))
              : ((e = l.dd), e || ((e = []), (l.dd = e)), e.push(c));
          }
        }
      } else (c = P(a).o("staticMethods", {})[e]), y(c) && c.apply(null, ja(d));
    }),
    Ot =
      "telefone phone phone_number customer_phone mobile_phone cell_phone contact_phone phone_contact primary_phone telephone user_mobile customer_contact_number mobile_number user_telephone phone_no contact_number subscriber_phone clientPhone tel".split(
        " "
      ),
    Pt =
      "email_name user_email email email_address customer_email contact_email primary_email emailID user_emailID mail user_mail subscriber_email user_contact_email clientEmail".split(
        " "
      ),
    Qt = ["visitorContactInfo"];
  function Rt(a, b, c) {
    (a = ci(a, b)) && c.push(["phone", a]);
    return a;
  }
  function St(a, b, c) {
    L(function (d) {
      u(d) && !Rt(a, d, c) && (d = ai(d)) && c.push(["email", d]);
    }, b);
  }
  function Tt(a, b, c, d) {
    c = void 0 === c ? [] : c;
    d = void 0 === d ? 1 : d;
    if (!(3 < d) && A(b))
      return (
        (b = dc(b)),
        L(function (e) {
          var f = n(e);
          e = f.next().value;
          f = f.next().value;
          u(f)
            ? N(e, Ot)
              ? Rt(a, f, c)
              : N(e, Pt) && ((e = c), (f = ai(f)) && e.push(["email", f]))
            : w(f) && N(e, Qt)
            ? St(a, f, c)
            : A(f) && Tt(a, f, c, d + 1);
        }, b),
        c
      );
  }
  function Ut(a, b, c) {
    b &&
      A(c) &&
      ((c = Tt(a, c) || []),
      L(function (d) {
        d = n(d);
        var e = d.next().value;
        d = d.next().value;
        return ei(a, d).then(function (f) {
          var g = {},
            h = {},
            k = {};
          return b(
            ((k.__ym =
              ((h.fpdlh = qe(
                ((g.a = "email" === e ? 1 : 0), (g.c = f || 0), g)
              ).ra()),
              h)),
            k)
          );
        });
      }, c));
  }
  var Vt = V("fpdlc", function (a, b) {
      var c = Xh(a, b);
      if (c && di(a))
        return cj(b, function (d) {
          if (I(d, "settings.cf")) {
            var e = c.params,
              f;
            d = [
              Ck(a, "dataLayer", function (g) {
                f = g;
                g.Ba.C(D([a, e], Ut));
              }),
              function () {
                f && f.unsubscribe();
              },
            ];
            return D([de, d], L);
          }
        });
    }),
    Wt = V("ymc.g", function (a, b) {
      var c = {};
      return (
        (c.getYmclid = function (d) {
          d &&
            cj(b, function (e) {
              Qh(a, d, null, I(e, "settings.ymclid"));
            });
        }),
        c
      );
    }),
    Xt = Sn + "-tags/_/tag_ec.js",
    Yt = Sn + "-tags/_/tag_ec_test.js",
    Zt = V("ecl.h", function (a, b) {
      return cj(b, function (c) {
        var d = I(c, "settings.zero_code"),
          e = Ee(a, d);
        if (A(e) && (H(e, "ec") || H(e, "ect"))) {
          c = P(a);
          var f = c.o("ecrs", []),
            g = {};
          f.push(((g.counterKey = Q(b)), (g.settings = d), g));
          c.B("ecrs", f);
          d = e.em;
          z(d) ||
            ((f = c.o("ecmv", {})), (g = Q(b)), (f[g] = d), c.B("ecmv", f));
          d = !!e.ec;
          e = !!e.ect;
          !c.o("ecl") && d && (c.B("ecl", !0), Lk(a, Xt, r));
          !c.o("ectl") && e && (c.B("ectl", !0), Lk(a, Yt, r));
        }
      })["catch"](U(a, "ecl.hs"));
    }),
    $t = V("rsa.i", function (a, b) {
      if (!Xs(a))
        return cj(b, function (c) {
          var d = I(c, "settings.rspi");
          I(c, "settings.rse") &&
            d &&
            (Lk(
              a,
              "https://yandex.ru/ads/system/context.js",
              r,
              U(a, "rsa.cl")
            ),
            (c = {}),
            (d = ((c.pageId = d), c)),
            Lk(
              a,
              "https://yandex.ru/ads/system/ap-loader.js",
              r,
              U(a, "rsa.apl"),
              { wc: d }
            ));
        })["catch"](U(a, "rsa.hs"));
    }),
    au = V("wm.p", function (a) {
      var b = P(a),
        c = {},
        d = Gf(a);
      b.B("wmg", {
        add: function (e, f, g, h, k) {
          k = void 0 === k ? !1 : k;
          if (!c[e]) {
            var l = function (m) {
              m.wd !== e && (m.Lc ? f(m.yc) : g());
            };
            c[e] = function () {
              d.qa(l);
            };
            d.C(l);
            k && d.trigger({ wd: e, Lc: k, yc: h });
          }
        },
        remove: function (e) {
          var f = c[e];
          f && f();
          delete c[e];
        },
        update: function (e, f, g) {
          c[e] && d.trigger({ wd: e, yc: g, Lc: f });
        },
      });
    });
  function bu(a, b) {
    var c = r;
    Oc(a) ? (c = Xc(a).C(a, ["prerenderingchange"], b, !0)) : b();
    return c;
  }
  function cu(a, b, c) {
    var d = I(c, "scripts");
    if (!z(d) && 0 !== d.length) {
      var e = Zm(3);
      L(function (f) {
        if (!(300 >= f.duration || 0.999 >= a.Math.random())) {
          var g = f.sourceURL;
          g &&
            qh(g) === sa.host &&
            ((g = {}),
            (f =
              ((g.d = e(f.duration)),
              (g.st = e(f.startTime)),
              (g.pd = e(f.pauseDuration)),
              (g.scp = f.sourceCharPosition),
              (g.sfn = f.sourceFunctionName),
              (g.td = e(c.blockingDuration)),
              (g.fut = e(c.firstUIEventTimestamp)),
              (g.rs = e(c.renderStart)),
              (g.sls = e(c.styleAndLayoutStart)),
              (g.e = []),
              (g.f = []),
              g)),
            b.push(f));
        }
      }, d);
    }
  }
  function du(a, b, c) {
    b = c.flush();
    if (0 !== b.length) {
      var d = le.slice();
      L(function (e) {
        var f = e.st,
          g = e.st + e.d,
          h = new Gj();
        L(function (l) {
          l.startTime < g && l.endTime > f && h.add(l.scope);
        }, d);
        if (0 !== h.size) {
          var k = {};
          O(e, ((k.f = lc(h)), k));
          fe("longtask", Fe(a, e) || "uns", "laf");
        }
      }, b);
    }
  }
  function eu(a, b, c, d) {
    "long-animation-frame" === d.entryType && cu(a, c, d);
  }
  var fu = V("lt", function (a) {
    var b = [],
      c = D([ce, b], L);
    if (y(a.PerformanceObserver)) {
      var d = ke(),
        e = ke(),
        f = function (h) {
          dj(
            a,
            D(
              [
                a,
                h.getEntries(),
                D([a, d, e], eu),
                "lt.i",
                50,
                D([a, d, e], du),
              ],
              jj
            ),
            "lt.r"
          );
        },
        g = bu(
          a,
          U(a, "lt.a", function () {
            var h = new a.PerformanceObserver(U(a, "lt.p", f));
            b.push(function () {
              return h.disconnect();
            });
            try {
              H(a, "PerformanceLongAnimationFrameTiming") &&
                h.observe({ type: "long-animation-frame", buffered: !0 }),
                H(a, "PerformanceEventTiming") &&
                  h.observe({ type: "event", buffered: !0, Le: 300 });
            } catch (k) {}
          })
        );
      b.push(g);
      return c;
    }
  });
  function gu(a) {
    return {
      K: function (b, c) {
        var d = b.G;
        if (d) {
          var e = P(a).o("adBlockEnabled");
          e && d.B("adb", e);
        }
        c();
      },
    };
  }
  function hu(a, b) {
    var c = a.document;
    if (N(c.readyState, ["interactive", "complete"])) dj(a, b, "adb.r.cor");
    else {
      var d = Xc(a),
        e = d.C,
        f = d.ua,
        g = function () {
          f(c, ["DOMContentLoaded"], g);
          f(a, ["load"], g);
          b();
        };
      e(c, ["DOMContentLoaded"], g);
      e(a, ["load"], g);
    }
  }
  var iu = F("9-d5ve+.r%7", lb),
    ju = V("adb", function (a, b) {
      if (!b.Aa) {
        var c = P(a);
        if (!c.o("adBlockEnabled")) {
          var d = function (m) {
              N(m, ["2", "1"]) && c.B("adBlockEnabled", m);
            },
            e = Ld(a),
            f = e.o("isad");
          if (f) d(f);
          else {
            var g = F("adStatus", c.B),
              h = function (m) {
                m = m ? "1" : "2";
                d(m);
                g("complete");
                e.B("isad", m, 1200);
                return m;
              },
              k = Ph(a, "adb", b);
            if (!c.o("adStatus")) {
              g("process");
              var l = "metrika/a" + iu().replace(/[^a-v]+/g, "") + "t.gif";
              hu(a, function () {
                return k({ ha: { U: l } })
                  .then(F(!1, h))
                  ["catch"](F(!0, h));
              });
            }
          }
        }
      }
    });
  F($d("ccf"), Ud);
  var ku = /\sYptp\/\d\.(\d+)\s/,
    lu = K(function (a) {
      var b;
      a: {
        if ((b = qb(a)) && (b = ku.exec(b)) && 1 < b.length) {
          b = ub(b[1]);
          break a;
        }
        b = 0;
      }
      return (50 <= b && 99 >= b) || Rc(a) ? !1 : !Pc(a) || ho(a);
    });
  function mu(a, b, c, d, e, f, g, h) {
    var k = c.o(f);
    z(k) && (c.B(f, g), e(a, b, c, d), (k = c.o(f, g)));
    Sa(h) || h.wb(f, "" + k);
    return k;
  }
  var nu = K(function (a) {
    return y(I(a, "yandex.getSiteUid")) ? a.yandex.getSiteUid() : null;
  });
  function ou(a, b) {
    var c = Me(a),
      d = c.o,
      e = c.B;
    if ("" === d("cc")) {
      e("cc", 0);
      var f = W(a),
        g = P(a);
      Ph(
        a,
        "6",
        b
      )({ J: { Fa: !0, qc: !1 } }, ["https://mc.yandex.md/cc"])
        .then(function (h) {
          h = I(h.Ea, "c");
          e("cc", h + "&" + f(nf));
          g.B("cc", h);
        })
        ["catch"](function (h) {
          var k = f(nf);
          e("cc", "&" + k);
          ge(a, "cc", h);
        });
    }
  }
  var pu = V("cc.i", function (a, b) {
    var c = D([a, b], ou);
    c = D([a, c, 300, void 0], yf);
    cj(b, c);
  });
  function qu(a, b, c) {
    if ("complete" === I(a, "document.readyState")) b();
    else {
      var d = U(a, c + ".wfd.l", function () {
        Xc(a).ua(a, ["load"], d);
        b();
      });
      Xc(a).C(a, ["load"], d);
    }
  }
  var ru = {},
    su =
      ((ru.ka = "ge"),
      (ru.ro = "md"),
      (ru.tg = "tj"),
      (ru.tk = "tm"),
      (ru.et = "ee"),
      (ru.hy = "com.am"),
      (ru.he = "co.li"),
      (ru.ky = "kg"),
      (ru.be = "by"),
      (ru.tr = "com.tr"),
      (ru.kk = "kz"),
      ru);
  function tu(a, b, c) {
    var d = !1;
    return function (e) {
      var f = e.data;
      e = e.source;
      if (u(f)) {
        var g = n(f.split("*"));
        f = g.next().value;
        var h = g.next().value,
          k = g.next().value;
        g = g.next().value;
        "sc.frame" === f && e
          ? d ||
            ((d = !0),
            e.postMessage((b ? "sc.bl" : "sc.images") + "*" + a, "*"))
          : b
          ? "sc.blr" === f &&
            h === a.split("?")[0] &&
            c(k, u(g) ? dl(bl(g)) : null)
          : "sc.image" === f && h === a && c(k, null);
      }
    };
  }
  function uu(a, b, c, d, e, f) {
    f = void 0 === f ? "isp" : f;
    return new Y(function (g, h) {
      cj(e, function (k) {
        if (Ol(a, f, e, k)) {
          var l = r;
          k = function (m, p) {
            "1" === m ? g({ Ea: p, rd: 0 }) : h(m);
            l();
            Ql(f);
          };
          l = Xc(a).C(a, ["message"], U(a, d + ".m.mir", tu(b, c, k)));
          yf(a, F("7", k), 3e3, d + ".t.mir");
        } else h(6);
      })["catch"](F(6, h));
    });
  }
  function vu(a, b, c, d, e, f) {
    return function (g, h) {
      return cj(h, function (k) {
        var l = P(g),
          m = l.o,
          p = l.B,
          q = Kd(g, "");
        if (!m(c)) {
          var v = I(k, "settings." + a);
          if (v)
            return (
              p(c, 1),
              p(b, 1),
              qu(
                g,
                function () {
                  Ll(
                    g,
                    function () {
                      uu(g, v, !0, d, h, e)
                        .then(
                          U(g, d + ".pt", function () {
                            f && q.B("mdd", "1", 1440);
                            p(b, 2);
                          })
                        )
                        ["catch"](
                          U(g, d + ".pc", function (t) {
                            "7" === t || 6 === t
                              ? p(b, 4)
                              : (f && q.B("mdd", "0", 1440), p(b, 3));
                          })
                        );
                    },
                    d
                  );
                },
                d
              )
            );
          p(b, 0);
        }
      })["catch"](U(g, d));
    };
  }
  var wu = V("p.cac", vu("mdd", "cac", "cacp", "cac", "cac.mdd", !0)),
    xu = V("p.cac.e", vu("mdde", "cae", "caep", "cac.e", "cac.mdde", !1)),
    yu = K(Nd);
  function zu(a) {
    var b = yu();
    b.jd || (b.jd = a);
  }
  var Au = K(Od);
  function Bu(a) {
    a = Hc(a);
    return su[a] || "com";
  }
  var Cu = K(function () {
    var a = G(
      function (b, c) {
        "ru" !== c && (b[c] = Vo + "." + c);
        return b;
      },
      {},
      gd
    );
    a.com = Vo + ".com";
    return a;
  });
  function Du(a, b) {
    var c = Bu(a),
      d = [!0];
    d.push(c);
    d.unshift("com");
    var e = W(a);
    c = Me(a);
    var f = c.o("synced", {});
    d = Qb(function (g) {
      if (b[g]) {
        var h = (f[g] || 1) + 1440 < e(nf);
        h && delete f[g];
        return h;
      }
    }, d);
    c.B("synced", f);
    return L(function (g) {
      return { we: b[g], ce: g };
    }, d);
  }
  var Eu = (function (a, b) {
    return function (c, d) {
      if (Pc(c) || xb(c)) return {};
      var e = Q(d);
      e = Cu(e);
      var f = Du(c, e),
        g = P(c),
        h = Ic(c);
      return {
        K: function (k, l) {
          var m = k.G;
          m = !(m && m.o("pv"));
          if (h || m || !f.length) return l();
          g.o("startSync")
            ? Au(c).push(l)
            : (g.B("startSync", !0),
              D([c, d, f, r, !1], a)()
                .then(l, M(Pa(l), U(c, b)))
                ["catch"](r));
        },
        S: function (k, l) {
          if (!I(k.Zb, "settings.nss")) return l();
          var m = k.G;
          m = !(m && m.o("pv"));
          if (h || m || !f.length) return l();
          if (g.o("startSync")) Au(c).push(l);
          else
            return (
              g.B("startSync", !0), a(c, d, f, r, !0).then(l, M(Pa(l), U(c, b)))
            );
        },
      };
    };
  })(function (a, b, c, d, e) {
    var f = W(a),
      g = P(a),
      h = Me(a);
    d = Lh(a, b, "c");
    var k = ch(a, d),
      l = Ym();
    zu(l);
    return G(
      function (m, p) {
        function q() {
          var x = h.o("synced");
          g.B("startSync", !1);
          x && ((x[p.ce] = v), h.B("synced", x));
          x = Au(a);
          L(ce, x);
          pc(x);
        }
        var v,
          t = {};
        t = k(
          {
            J: { N: ["sync.cook"], sa: 1500 },
            D: ((t.scid = l), (t.cid = "" + b.id), t),
          },
          [
            "https://" +
              p.we +
              "/sync_cookie_image_check" +
              (e ? "_secondary" : ""),
          ]
        )
          .then(function () {
            v = f(nf);
            q();
          })
          ["catch"](function () {
            v = f(nf) - 1435;
            q();
          });
        t = F(t, lb);
        return m.then(t);
      },
      Y.resolve(),
      c
    )["catch"](U(a, "ctl"));
  }, "sy.c");
  function Fu(a, b, c) {
    var d = I(a, "location.host");
    a = Qf(a, b);
    c.B("pu", "" + Wj(d) + a);
  }
  function Gu(a, b, c) {
    var d = Pf(a, b);
    if (d) {
      d.ca.C(["gpu-get"], function () {
        var g = {};
        return (g.type = "gpu-get"), (g.pu = c.o("pu")), g;
      });
      var e = I(a, "opener");
      if (e) {
        var f = yf(a, D([a, b, c], Fu), 200, "pu.m");
        b = {};
        d.bc(e, ((b.type = "gpu-get"), b), function (g, h) {
          var k = I(h, "pu");
          k && (xf(a, f), c.B("pu", k));
        });
      } else Fu(a, b, c);
    }
  }
  var Hu = M(J("settings.pcs"), Oa("1"));
  function Iu(a, b, c, d) {
    return cj(b, function (e) {
      if (!Hu(e) && !tc(a))
        if (((e = d.o("zzlc")), Sa(e) || Ra(e) || "na" === e)) {
          var f = Ue(a);
          if (f && (e = $e(a))) {
            var g = f("iframe");
            O(g.style, {
              display: "none",
              width: "1px",
              height: "1px",
              visibility: "hidden",
            });
            f = 68 <= yb(a);
            var h = Rc(a);
            g.src =
              "https://mc.yandex." +
              (f || h ? "md" : "ru") +
              bl("L21ldHJpa2EvenpsYy5odG1s");
            e.appendChild(g);
            var k = 0,
              l = Xc(a).C(
                a,
                ["message"],
                U(a, "zz.m", function (m) {
                  (m = I(m, "data")) &&
                    m.substr &&
                    "__ym__zz" === m.substr(0, 8) &&
                    (Ve(g),
                    (m = m.substr(8)),
                    d.B("zzlc", m),
                    c.B("zzlc", m),
                    l(),
                    xf(a, k));
                })
              );
            k = yf(a, M(l, F(g, Ve)), 3e3, "c.d.z");
          }
        } else c.B("zzlc", e);
    });
  }
  function Ju(a, b, c, d) {
    b = d.o("cc");
    d = D(["cc", ""], d.B);
    if (b) {
      var e = n(b.split("&"));
      b = e.next().value;
      (e = (e = e.next().value) && ub(e)) && 1440 < W(a)(nf) - e
        ? d()
        : c.B("cc", b);
    } else Oa(0)(b) || d();
  }
  var Ku = K(function (a, b) {
      var c = P(a),
        d = Me(a),
        e = [],
        f = D([a, b, c, d], mu),
        g = !lu(a) || 68 <= yb(a);
      g && e.push(D([Gu, "pu", ""], f));
      !g ||
        d.Lb ||
        Pc(a) ||
        (e.push(D([Iu, "zzlc", "na"], f)), e.push(D([Ju, "cc", ""], f)));
      return e.length
        ? {
            S: function (h, k) {
              if (0 === c.o("isEU"))
                try {
                  L(de, e);
                } catch (l) {}
              k();
            },
            K: function (h, k) {
              var l = h.G;
              if (l && 0 === c.o("isEU"))
                try {
                  L(Qa(l), e);
                } catch (m) {}
              k();
            },
          }
        : {};
    }, M(mb, Q)),
    Lu = M(Ee, J("cid"));
  function Mu(a, b, c) {
    return function (d, e) {
      return cj(e, function (f) {
        if (I(f, "settings." + a)) {
          var g = P(d),
            h = g.o,
            k = g.B;
          if (Sa(h("oms"))) {
            var l = Qf(d, e);
            g = {};
            var m = Fe(d, ((g.counterId = e.id), (g["cnt-class"] = e.M), g));
            if ((f = b(d, m, f, l)))
              return (
                k("oms", 1),
                uu(d, f, !!c, "isp.stat", e)
                  .then(function (p) {
                    p = p.Ea;
                    if (u(p)) {
                      if ((p = c && c(d, p))) {
                        var q = cl(el(p));
                        k("oms", 8);
                        p = { id: 99742118, M: "0" };
                        var v = Ph(d, "pi", p),
                          t = {};
                        q = $g(((t[a] = q), (t.u = l), t));
                        t = {};
                        t =
                          ((t["page-url"] = R(d).href),
                          (t["page-ref"] = d.document.referrer),
                          (t["site-info"] = m),
                          t);
                        return v({ G: q, D: t }, p).then(
                          D(["oms", 4], k),
                          F(9, Ud)
                        );
                      }
                      k("oms", 3);
                    } else k("oms", 2);
                  })
                  ["catch"](function (p) {
                    p = rb(d, p) || u(p) ? p : 5;
                    k("oms", p);
                  })
              );
          }
        }
      })["catch"](U(d, "l.isp." + a));
    };
  }
  function Nu() {
    return T(
      "",
      L(function (a) {
        return String.fromCharCode(a.charCodeAt(0) + 15);
      }, dl(bl("VCNUKCkkUiMeIlUjVx4lIydVHiohJyEeVyZWKFNVVSEmIyoj")))
    );
  }
  function Ou(a, b) {
    if (
      "https://oauth.yandex.ru" === I(b, "origin") &&
      I(b, "source.window") &&
      "_ym_uid_request" === I(b.data, "_ym")
    ) {
      var c = b.source,
        d = {};
      d = ((d._ym_uid = a), d);
      c.postMessage(d, "https://oauth.yandex.ru");
    }
  }
  var Pu = cd("ot", function (a, b) {
    if (Sc(a)) {
      var c = Xc(a);
      return cj(
        b,
        U(a, "ot.s", function (d) {
          if (I(d, "settings.oauth")) {
            var e = [],
              f = Qf(a, b);
            e.push(c.C(a, ["message"], U(a, "ot.m", F(f, Ou))));
            Ff(
              a,
              "ot"
            )(
              Bf(
                r,
                U(a, "ot.b", function () {
                  function g(p) {
                    var q = p.href;
                    if (
                      q &&
                      lj(q, "https://oauth.yandex.ru/") &&
                      !Ha(q, "_ym_uid=")
                    ) {
                      q = Ha(q, "?") ? "&" : "?";
                      var v = {};
                      p.href += "" + q + td(((v._ym_uid = f), (v.mc = "v"), v));
                      c.C(
                        p,
                        ["click"],
                        U(a, "ot.click", function () {
                          var t = "et=" + k(mf);
                          p.href += "&" + t;
                        })
                      );
                    }
                  }
                  var h = a.document.body,
                    k = W(a),
                    l = xj("a", h);
                  L(g, l);
                  if (wa("MutationObserver", a.MutationObserver)) {
                    l = new a.MutationObserver(
                      U(
                        a,
                        "ot.m",
                        F(function (p) {
                          p = p.addedNodes;
                          for (var q = 0; q < p.length; q += 1) {
                            var v = p[q];
                            "A" === v.nodeName && g(v);
                          }
                        }, L)
                      )
                    );
                    var m = {};
                    m = ((m.childList = !0), (m.subtree = !0), m);
                    l.observe(h, m);
                    e.push(B(l.disconnect, l));
                  }
                })
              )
            );
            return D([de, e], L);
          }
        })
      );
    }
  });
  function Qu(a, b, c) {
    if (I(c, "settings.ins")) {
      var d = P(a);
      if (!d.o("scip")) {
        var e = Me(a),
          f = W(a)(nf);
        c = sb(e.o("sci"));
        if (!(c && 1440 >= f - c)) {
          c = Ph(a, "ci", b);
          var g = ["sync.cook.int"],
            h = function (p) {
              p = d.o("scip", "") + p;
              d.B("scip", p);
            },
            k = F("a", h);
          d.B("scip", "0");
          var l = {};
          l =
            ((l.tag = "cm-urls"),
            (l.stage = "mc-yandex-com"),
            (l["mc-id"] = "" + b.id),
            (l.duid = Qf(a, b)),
            l);
          var m = yu().jd;
          m && (l.scid = m);
          return c({ J: { N: g, sa: 3e3, Fa: !0 }, D: l }, [
            "https://eu.asas.yango.com/mapuid",
          ])
            .then(function (p) {
              p = I(p.Ea, "CookieMatchUrls");
              if (w(p) && eb(p)) {
                h("1");
                var q = Ph(a, "c", b);
                p = L(function (v, t) {
                  return q({ J: { N: g, sa: 3e3 } }, ["https://" + v])
                    .then(M(F("c", h), F("" + t, h)))
                    ["catch"](M(F("b", h), F("" + t, h)));
                }, Qb(u, p));
                return Y.all(p);
              }
              k();
            }, k)
            .then(function () {
              var p = d.o("scip");
              !p || Ha(p, "a") || Ha(p, "b") || (e.B("sci", f), h("d"));
            }, r);
        }
      }
    }
  }
  function Ru(a, b) {
    return V("p.suid", function (c) {
      var d = c.r;
      c = c.u;
      var e = {};
      d = ((e.fsr = u(d) ? d : null), (e.fsu = u(c) ? c : null), e);
      c = {};
      d = ((c.__ym = d), c);
      (c = Xh(a, b)) && c.params && c.params(d);
    });
  }
  var Su = V("p.suic", function (a, b) {
    return cj(b, function (c) {
      var d = P(a),
        e = d.o,
        f = d.B;
      e = e("pic");
      d = Ru(a, b);
      if (y(e)) return e(d);
      if ((c = I(c, "settings.pic"))) {
        e = Gf(a);
        var g = e.C,
          h = e.qa,
          k = e.trigger;
        e = function (l) {
          g(l);
          return function () {
            h(l);
          };
        };
        f("pic", e);
        d = e(d);
        f("prs", 3);
        Ph(
          a,
          "pic",
          b
        )({ J: { qc: !1, N: ["pic"] } }, [c]).then(function (l) {
          l = l.Ea;
          if (z(l)) f("prs", 5);
          else if (A(l)) {
            var m = l.h;
            u(m) && m
              ? (Id(a, "_ym_fa", m, 43200), f("prs", 8), k(l))
              : f("prs", 7);
          } else f("prs", 6);
        }, D(["prs", 4], f));
        return d;
      }
      f("prs", 2);
    })["catch"](U(a, "pic"));
  });
  function Tu(a, b) {
    try {
      if (z(b)) return { location: 4, Va: null };
      if (H(b, "webdriver")) return { location: 1, Va: b };
      for (
        var c = I(a, "Navigator.prototype"), d = Object.getPrototypeOf(b);
        d;

      ) {
        if (H(d, "webdriver")) return { location: d === c ? 0 : 2, Va: d };
        d = Object.getPrototypeOf(d);
      }
      return { location: 3, Va: null };
    } catch (e) {
      return { location: 4, Va: null };
    }
  }
  function Uu(a, b, c) {
    return new Y(function (d) {
      if (Ol(a, "wd", b, c)) {
        var e = r,
          f = 0,
          g = !1,
          h = function (k) {
            g || ((g = !0), e(), xf(a, f), Ql("wd"), d(k));
          };
        e = Xc(a).C(a, ["message"], function (k) {
          var l = I(k, "data");
          if (u(l))
            if (((l = l.split("*")), "sc.frame" === l[0] && k.source))
              k.source.postMessage("sc.wdp*2", "*");
            else if ("sc.wdpr" === l[0]) {
              var m = n(L(sb, l.slice(1)));
              k = m.next().value;
              l = m.next().value;
              var p = m.next().value;
              m = m.next().value;
              k =
                2 !== k ||
                z(l) ||
                z(p) ||
                z(m) ||
                !(0 <= k && 0 <= l && 0 <= p && 0 <= m)
                  ? null
                  : [k, l, p, m];
              h(k);
            }
        });
        f = yf(
          a,
          function () {
            return h(null);
          },
          3e3,
          "wd"
        );
      } else d(null);
    });
  }
  var Vu = V("p.wd", function (a, b) {
      if (ld(a))
        return cj(
          b,
          U(a, "wd.s", function (c) {
            if (I(c, "settings.ewd")) {
              var d = P(a),
                e = d.o,
                f = d.B;
              e("wdsp", !1) ||
                (f("wdsp", !0),
                Ll(
                  a,
                  function () {
                    Uu(a, b, c)
                      .then(
                        U(a, "wd.p", function (g) {
                          if (ld(a)) {
                            var h = I(a, "navigator"),
                              k = Tu(a, h);
                            var l = k.location;
                            k = k.Va;
                            if (z(h)) var m = 2;
                            else
                              try {
                                var p = h.webdriver;
                                m = Sa(p) ? 2 : !0 === p ? 1 : !1 === p ? 0 : 4;
                              } catch (v) {
                                m = 3;
                              }
                            h = m;
                            b: {
                              try {
                                var q = Ra(k)
                                  ? void 0
                                  : Object.getOwnPropertyDescriptor(
                                      k,
                                      "webdriver"
                                    );
                              } catch (v) {
                                q = null;
                                break b;
                              }
                              k = 0;
                              Sa(q)
                                ? (k |= 2)
                                : (H(q, "value") && (k |= 1),
                                  y(q.get) || (k |= 2),
                                  y(q.set) && (k |= 4),
                                  !0 !== q.enumerable && (k |= 8),
                                  !0 !== q.configurable && (k |= 16));
                              q = k;
                            }
                            k = 5;
                            Ra(g) ||
                              ((k = n(g)),
                              k.next(),
                              (g = k.next().value),
                              k.next(),
                              (m = k.next().value),
                              (k = g),
                              Ra(q) || q === m || (q |= 64));
                            l = T("-", [2, h, l, Ra(q) ? 0 : q, k]);
                          } else l = null;
                          Ra(l) || f("wds", l);
                        })
                      )
                      ["catch"](U(a, "wd"));
                  },
                  "wd.i"
                ));
            }
          })
        )["catch"](U(a, "wd"));
    }),
    Wu = [
      "yandex_metrika_callback" + sa.callbackPostfix,
      "yandex_metrika_callbacks" + sa.callbackPostfix,
    ],
    Xu = V("cb.i", function (a) {
      var b = n(Wu),
        c = b.next().value,
        d = b.next().value;
      if (y(a[c])) a[c]();
      "object" === typeof a[d] &&
        L(function (e, f) {
          a[d][f] = null;
          Qh(a, e);
        }, a[d]);
      L(function (e) {
        try {
          delete a[e];
        } catch (f) {
          a[e] = void 0;
        }
      }, Wu);
    }),
    Yu = V("h.p", function (a, b) {
      var c = Ph(a, "h", b),
        d = b.Ga || "" + R(a).href,
        e = b.Hb || a.document.referrer,
        f = {},
        g = {};
      f = {
        G: $g(((f.pv = 1), f)),
        D: ((g["page-url"] = d), (g["page-ref"] = e), g),
        H: {},
      };
      var h = aj(Q(b));
      g = h.kb;
      h = h.Wd;
      var k = {};
      f.ba = qe(((k.clt = rb(a, h) && rb(a, g) ? g - h : null), k));
      f.H.L = b.L;
      f.H.nc = b.nc;
      b.Ra && f.D && (f.D.nohit = "1");
      return c(f, b)
        .then(function (l) {
          if (l) {
            if (!b.Ra) {
              var m = {};
              Vh(
                a,
                b,
                "h",
                ((m.id = b.id), (m.url = d), (m.ref = e), m),
                b.L
              )();
            }
            dj(a, D([a, b, l], bj), "h.ss");
          }
        })
        ["catch"](U(a, "h.g.s"));
    }),
    Zu = V("destruct.e", function (a, b, c) {
      return function () {
        var d = P(a),
          e = b.id;
        L(function (f, g) {
          return y(f) && U(a, "dest.fr." + g, f)();
        }, c);
        delete d.o("counters")[Q(b)];
        delete a["yaCounter" + e];
      };
    });
  function $u(a, b, c, d, e) {
    if (!c.length) return e;
    c = L(function (f) {
      return D([a, b, d], f);
    }, c);
    return M.apply(null, ja(c))(e);
  }
  function av(a, b, c, d) {
    return U(a, "cm." + c, d);
  }
  function bv(a, b, c, d) {
    return function () {
      var e = Va(arguments);
      e = d.apply(null, ja(e));
      return Sa(e) ? Xh(a, b) : e;
    };
  }
  var cv = P(window);
  cv.V("hitParam", {});
  cv.V("lastReferrer", window.location.href);
  ug.push(
    V("p.ar", function (a, b) {
      var c = Ph(a, "a", b),
        d = {};
      return (
        (d.hit = function (e, f, g, h, k, l) {
          var m = {};
          m = { D: {}, G: $g(((m.pv = 1), (m.ar = 1), m)) };
          f = A(f)
            ? {
                title: f.title,
                referrer: f.referrer || f.referer,
                L: f.params,
                eb: f.callback,
                l: f.ctx,
              }
            : { title: f, referrer: g, L: h, eb: k, l: l };
          h = Wh(b);
          g = R(a).href;
          k = b.Ra ? b.Ga || g : g;
          g = Sa(h.url) ? k : g;
          g = e || g;
          h.url !== g && ((h.ref = h.url), (h.url = e));
          e = b.Ra ? b.Hb || a.document.referrer : a.document.referrer;
          e = f.referrer || h.ref || e;
          h = {};
          h = Vh(a, b, "pv", ((h.id = b.id), (h.url = g), (h.ref = e), h), f.L);
          k = O(m.H || {}, { L: f.L, title: f.title });
          l = {};
          m = c(
            O(m, {
              H: k,
              D: O(m.D || {}, ((l["page-url"] = g), (l["page-ref"] = e), l)),
            }),
            b
          ).then(h);
          return Rh(a, "p.ar.s", m, f.eb || r, f.l);
        }),
        d
      );
    })
  );
  Oh.a = lh;
  qg.a = [
    [jg, -100],
    [$c, 1],
    [gg, 2],
    [$f(), 3],
    [ag, 4],
  ];
  Kh.a = Gh;
  ug.push(function (a, b) {
    var c = {};
    return (
      (c.firstPartyParams = hi(a, b)), (c.firstPartyParamsHashed = ji(a, b)), c
    );
  });
  te.push("fpp");
  te.push("fpmh");
  (function () {
    var a = P(window);
    a.V("getCounters", qi(window));
    tg.push(ri);
    xe["counters.c"] = "cntc";
    xe["counters.s"] = "cnts";
    wg.push(function (b, c, d) {
      var e = a.o("getCounters");
      e &&
        ((c.counters = ki(b, {}, "counters.c", e)),
        (d.counters = ki(b, {}, "counters.s", e)));
    });
  })();
  Oh["1"] = lh;
  ug.push(yi);
  Kh["1"] = Fh;
  og(wi, -1);
  X("h", wi, -1);
  X("a", wi, -1);
  qg["1"] = [
    [wi, -1],
    [$c, 1],
    [gg, 2],
    [$f(), 3],
    [jg, 4],
  ];
  ug.push(Ji);
  ug.push(Mi);
  Oh.g = lh;
  Kh.g = Fh;
  qg.g = lg;
  ug.push(Ni);
  ug.push(Si);
  qg.t = lg;
  Oh.t = lh;
  Kh.t = Fh;
  ug.push(
    V("cl.p", function (a, b) {
      function c(p, q, v, t) {
        t = void 0 === t ? {} : t;
        v
          ? Vi(a, b, { url: v, Ja: !0, mb: p, qb: q, sender: d, vd: t })
          : g.warn("clel");
      }
      var d = Ph(a, "2", b),
        e = [],
        f = Q(b),
        g = Th(a, f),
        h = U(a, "s.s.tr", F(oi(a, f), Ui));
      f = {
        l: a,
        Id: b,
        Od: e,
        sender: d,
        Oe: P(a),
        Hd: Ne(a, b.id),
        Qe: rf(a),
        Ae: F(F(f, pi(a)), M(ce, J("trackLinks"))),
      };
      f = U(a, "cl.p.c", F(f, Wi));
      f = Xc(a).C(a, ["click"], f);
      b.md && h(b.md);
      var k = U(a, "file.clc", D([!0, !1], c)),
        l = U(a, "e.l.l.clc", D([!1, !0], c));
      e = U(a, "add.f.e.clc", Xi(e));
      var m = {};
      return (
        (m.file = k),
        (m.extLink = l),
        (m.addFileExtension = e),
        (m.trackLinks = h),
        (m.u = f),
        m
      );
    })
  );
  qg["2"] = lg;
  Oh["2"] = lh;
  Kh["2"] = Fh;
  Oh.r = kh("r");
  Kh.r = ["f", "x", "j", "i"];
  vg.push(
    V("p.r", function (a, b) {
      var c = rj(a);
      c.Dd();
      return kj(a, b, c.Rd());
    })
  );
  X(
    "r",
    function (a, b) {
      var c = rj(a);
      return {
        K: function (d, e) {
          var f = void 0 === d.G ? $g() : d.G,
            g = d.H.Za,
            h = f.o("rqnl", 0) + 1;
          f.B("rqnl", h);
          g && c.Ce(g, h);
          e();
        },
        S: function (d, e) {
          sj(a, d, b, c);
          e();
        },
      };
    },
    1
  );
  og(tj, 100);
  X("h", tj, 100);
  X("a", tj, 100);
  X("1", tj, 100);
  X("n", tj, 100);
  X("m", tj, 100);
  ug.push(vj);
  X("n", $c, 1);
  X("n", gg, 2);
  X("n", $f(), 3);
  X("n", jg, 3);
  Oh.n = lh;
  Kh.n = Fh;
  O(Be, { tc: { T: "accurateTrackBounce" } });
  ug.push(Sj);
  Oh.m = kh("cm");
  Kh.m = Ih;
  X("m", $f(["u", "v", "vf"]), 1);
  O(Be, { Ed: { T: "clickmap" } });
  ug.push(Tj);
  ug.push(Vj);
  ug.push(hk);
  ug.push(ok);
  vg.push(Gk);
  te.push("ecommerce");
  O(Be, {
    Db: {
      T: "ecommerce",
      rb: function (a) {
        if (a) return !0 === a ? "dataLayer" : "" + a;
      },
    },
  });
  ug.push(Mk);
  te.push("user_id");
  ug.push(Ok);
  og(Nk, 0);
  X("h", Nk, 0);
  X("a", Nk, 0);
  Bd.push("_ym_debug");
  xg.unshift(Rk);
  var dv = {},
    ev =
      ((dv.tp = M(mb, ui, Lb)),
      (dv.tpid = M(mb, function (a) {
        a = Q(a);
        return (si[a] && si[a].ze) || null;
      })),
      dv);
  O(Yf, ev);
  og(Sk, 20);
  X("h", Sk, 20);
  X("a", Sk, 20);
  X("n", Sk, 20);
  X("1", Sk, 20);
  xg.unshift(Uk);
  Yf.fp = function (a, b, c) {
    if (c.D && c.D.nohit) return null;
    c = P(a).o;
    if (!c("fpe")) return null;
    b = Tk(b);
    if (b.Qd) return null;
    c = c("fht", Infinity);
    a: {
      var d = I(a, "performance.getEntriesByType");
      if (y(d)) {
        if (
          ((a = Qb(
            M(lb, J("name"), Oa("first-contentful-paint")),
            d.call(a.performance, "paint")
          )),
          a.length)
        ) {
          a = a[0].startTime;
          break a;
        }
      } else {
        var e = I(a, "chrome.loadTimes");
        d = Vf(a);
        if (
          y(e) &&
          ((e = e.call(a.chrome)), (e = I(e, "firstPaintTime")), d && e)
        ) {
          a = 1e3 * e - d;
          break a;
        }
        if ((a = I(a, "performance.timing.msFirstPaint"))) {
          a -= d;
          break a;
        }
      }
      a = void 0;
    }
    return a && c > a ? ((b.Qd = a), Math.round(a)) : null;
  };
  (function () {
    var a = {
        pri: Bl,
        ds: yl,
        co: function (c) {
          return Mb(P(c).o("jn"));
        },
        td: Dl,
      },
      b = {};
    O(
      a,
      ((b.iss = M(Lc, Lb)),
      (b.hdl = M(Mc, Lb)),
      (b.iia = M(Nc, Lb)),
      (b.cpf = M(Yk, Lb)),
      (b.ntf = K(function (c) {
        c = I(c, "Notification.permission");
        c = "denied" === c ? !1 : "granted" === c ? !0 : null;
        return Ra(c) ? null : c ? 2 : 1;
      })),
      (b.eu = Zk("isEU")),
      (b.ns = Vf),
      (b.np = function (c) {
        return kf(c, 0, 100) ? null : fl(wd(vc(c), 100));
      }),
      b)
    );
    a.pani = nl;
    a.pci = ol;
    a.si = pl;
    a.gi = ql;
    a.stlgg = Zk("lgguid");
    a.sttdi = jl;
    a.stti = il;
    a.sttifa = hl;
    O(Yf, a);
  })();
  (function () {
    var a = {};
    a.oo = Zk("oo");
    a.pmc = Zk("cmc");
    a.re = M(uf, Lb);
    a.aw = function (b) {
      b = Qe(M(z, nb), [
        b.document.hidden,
        b.document.msHidden,
        b.document.webkitHidden,
      ]);
      return z(b) ? null : Mb(!b);
    };
    a.nvt = Zl;
    a.rcm = Vl;
    a.yu = function (b) {
      return (b = Kd(b, "").o("yandexuid")) && b.substring(0, 25);
    };
    a.ifc = Zk("ifc");
    a.ifb = Zk("ifb");
    a.ecs = Zk("ecs");
    a.cdl = Zk("cdl");
    a.eco = K(Wl, M(mb, Q));
    a.ucs = function (b) {
      return (b = Kd(b).o("ucs")) && b.substring(0, 25);
    };
    De.ifd = function (b, c) {
      return P(b).o("ifdp", {})[Q(c)] || null;
    };
    De.rfs = function (b, c) {
      return Rl(c.Hb);
    };
    De.ufs = function (b, c) {
      return Rl(c.Ga);
    };
    O(De, a);
  })();
  Kh.er = Hh;
  (function () {
    var a = window;
    try {
      var b = Lh(a, { id: 26302566, M: "0" }, "er"),
        c = am(a, b, 26302566);
      ee.push(function (d, e, f, g) {
        var h = {},
          k = {},
          l = {},
          m = {},
          p = {};
        c(
          ((p[d] =
            ((m["2720"] =
              ((l[e] =
                ((k[f] = g ? ((h[a.location.href] = g), h) : a.location.href),
                k)),
              l)),
            m)),
          p)
        );
      });
    } catch (d) {}
  })();
  sg.push(function (a, b) {
    if (I(a, "disableYaCounter" + b.id) || I(a, "Ya.disableMetrica")) {
      var c = Q(b);
      delete P(a).o("counters", {})[c];
      Ud($d("oo.e"));
    }
  });
  ng.unshift(function (a) {
    return {
      K: function (b, c) {
        P(a).o("oo") || c();
      },
    };
  });
  og(cm, -99);
  X("h", cm, -99);
  X("a", cm, -99);
  ug.push(dm);
  qg.e = lg;
  Oh.e = lh;
  Kh.e = Fh;
  O(Be, { exp: { T: "experiments" } });
  xe.experiments = "ex";
  em.push(fm);
  Oh.f = lh;
  var fv = {};
  O(Kh, ((fv.f = Gh), fv));
  X("f", $f(), 1);
  X("f", ag, 2);
  X("f", Sk, 20);
  X("h", jm, -10);
  X("a", jm, -10);
  X("1", im, 19);
  X("n", im, 19);
  X("m", im, 2);
  og(im, 19);
  sg.push(function (a, b) {
    var c = { X: Q(b), Bb: Xh(a, b), ld: W(a), Rb: Me(a) },
      d = c.ld(nf);
    if (!c.Rb.Lb) {
      var e = c.Rb.o("ymoo" + c.X);
      e && 30 > d - e
        ? ((c = c.X), delete P(a).o("counters", {})[c], Ud($d("uws")))
        : cj(b, lm(c))["catch"](U(a, "d.f"));
    }
  });
  vg.push(Tm);
  ug.push(
    V("ag.e", function (a, b) {
      if (!ye(Q(b))) {
        var c = [];
        Df(cj(b, J("settings")))(
          Bf(
            U(a, "ag.s"),
            U(a, "ag.i", function (d) {
              if (
                I(d, "auto_goals") &&
                Xh(a, b) &&
                (d = Mi(a, b, "autogoal").reachGoal)
              ) {
                d = jn(d, !!b.Db);
                var e = kn(d);
                d = ln(d);
                c.push(an(a, d));
                c.push(
                  Ck(a, "dataLayer", function (f) {
                    f.Ba.C(e);
                  })
                );
              }
            })
          )
        );
        return function () {
          return L(de, c);
        };
      }
    })
  );
  ug.push(Hn);
  ug.push(Ml);
  xe["informer.c"] = "ifc";
  xe["informer.s"] = "ifs";
  wg.push(function (a, b, c) {
    var d = Jn(a);
    b.informer = ki(a, {}, "informer.c", d);
    c.informer = ki(a, {}, "informer.s", d);
  });
  Kh["5"] = Fh;
  Oh["5"] = lh;
  ug.push(Kn);
  X("5", jg, -100);
  X("5", $f(), 3);
  X("5", ag, 4);
  og(Mn, 7);
  X("h", Mn, 7);
  X("a", Mn, 7);
  X("n", Mn, 6);
  vg.push(Nn);
  Oh.d = lh;
  X("d", $f(["hid", "u", "v", "vf"]), 1);
  Kh.d = Hh;
  X(
    "n",
    function (a, b) {
      return {
        S: function (c, d) {
          if (!c.H || !c.H.force) {
            var e = 24226447 === b.id ? 1 : 0.002,
              f = he(a);
            if (f && y(f.getEntriesByType)) {
              var g = 0.002 < Math.random(),
                h = Math.random() > (void 0 === e ? 1 : e);
              if (!g || !h) {
                var k = f.getEntriesByType("resource"),
                  l = {},
                  m = {};
                f = {};
                e = R(a).href;
                for (var p = 0; p < k.length; p += 1) {
                  var q = k[p],
                    v = n(Ul(q.name)),
                    t = v.next().value,
                    x = v.next().value;
                  v = v.next().value;
                  var E = {};
                  E =
                    ((E.dns = Math.round(
                      q.domainLookupEnd - q.domainLookupStart
                    )),
                    (E.tcp = Math.round(q.connectEnd - q.connectStart)),
                    (E.duration = Math.round(q.duration)),
                    (E.response = Math.round(q.responseEnd - q.requestStart)),
                    E);
                  if ("script" === q.initiatorType && !g) {
                    var C = {};
                    m[t] = O(
                      E,
                      ((C.name = q.name),
                      (C.decodedBodySize = q.decodedBodySize),
                      (C.transferSize = Math.round(q.transferSize)),
                      C)
                    );
                  }
                  (!v && !Tl[x]) ||
                    l[t] ||
                    h ||
                    ((q = {}), (l[t] = O(E, ((q.pages = e), q))));
                }
                ec(l).length && (f.timings8 = l);
                ec(m).length && (f.scripts = m);
                ec(f).length &&
                  ((g = {}),
                  (h = {}),
                  Ph(
                    a,
                    "d",
                    b
                  )(
                    {
                      G: $g(((g.ar = 1), (g.pv = 1), g)),
                      J: { O: Fe(a, f) || void 0 },
                      D: ((h["page-url"] = e), h),
                    },
                    { id: 51533966, M: "0" }
                  )["catch"](U(a, "r.tim.ng2")));
              }
            }
          }
          d();
        },
      };
    },
    7
  );
  vg.push(Wk);
  X(
    "h",
    function (a) {
      return {
        S: function (b, c) {
          var d = b.Zb;
          eg(b) && d && P(a).B("isEU", I(d, "settings.eu"));
          c();
        },
      };
    },
    3
  );
  tg.push(Qn);
  vg.push(fo);
  ug.push(lo);
  O(Be, { Ge: { T: "yaDisableGDPR" }, He: { T: "yaGDPRLang" } });
  ng.push(function (a, b) {
    function c(q) {
      f(q);
      return {
        K: function (v, t) {
          d(v);
          t();
        },
      };
    }
    function d(q) {
      var v = T(",", L(kb(zo), Bo(e)));
      v = So(v, h);
      re(q, "gdpr", v);
      re(q, "gqp", Po(a));
    }
    if (ye(b.M) || 3 === b.id) return {};
    var e = Ei(a),
      f = F(e, Di),
      g = Kd(a, ""),
      h = g.o;
    if (b.Ge) return c("31");
    var k = Fo(a),
      l = R(a),
      m = l.href,
      p = Do(l.hostname);
    return k || p
      ? ho(a) || io(a)
        ? c("17")
        : g.o("yandex_login")
        ? (g.B("gdpr", to, 525600), c("13"))
        : {
            K: function (q, v) {
              if (q.G) {
                var t = function () {
                    d(q);
                    v();
                  },
                  x = P(a),
                  E = x.o("f1");
                E
                  ? E(t)
                  : ((E = Bo(e)),
                    sc(Vb(zo), E)
                      ? t()
                      : ((E = h("gdpr")),
                        N(E, so)
                          ? (f(E === uo ? "12" : "3"), t())
                          : po(a)
                              .then(lb, r)
                              .then(function (C) {
                                C
                                  ? (f("28"), t())
                                  : (Ro(t),
                                    x.B("f1", Ro),
                                    (C = n(em).next().value),
                                    C(a)
                                      .then(J("params.eu"))
                                      .then(function (S) {
                                        if (
                                          S ||
                                          Ha(m, "yagdprcheck=1") ||
                                          g.o("yaGdprCheck")
                                        ) {
                                          g.B("gdpr_popup", uo);
                                          Go(a, b);
                                          if (Ic(a)) return Ho(a, f, b);
                                          var Z = Hi(a, e);
                                          if (Z) {
                                            S = {};
                                            var Yc = {};
                                            e.push(
                                              ((Yc.ymetrikaEvent =
                                                ((S.type =
                                                  "GDPR-popup-request"),
                                                S)),
                                              Yc)
                                            );
                                            Oo(a, 1);
                                            Z = No(a, f, Z, b, p);
                                            Z.then(D([a, b], Ko));
                                            return Z;
                                          }
                                        }
                                        S || f("8");
                                        return Y.resolve({ value: to, Mb: !0 });
                                      })
                                      .then(function (S) {
                                        g.wa("gdpr_popup");
                                        if (S) {
                                          var Z = S.value;
                                          S = S.Mb;
                                          N(Z, so) &&
                                            (g.B(
                                              "gdpr",
                                              Z,
                                              S ? void 0 : 525600
                                            ),
                                            Oo(a, 7));
                                        }
                                        Z = Xg(Qo, ce);
                                        ij(
                                          a,
                                          Z,
                                          "gdp.t",
                                          20,
                                          Ug
                                        )(Bf(U(a, "gdr"), r));
                                        x.B("f1", ce);
                                      })
                                      ["catch"](U(a, "gdp.a")));
                              })));
              } else v();
            },
          }
      : c("14");
  });
  Bd.push("gdpr");
  Bd.push("gdpr_popup");
  Cd.push(function (a, b) {
    var c = Ei(a);
    c = Bo(c);
    if (Qb(Vb(Ao), c).length) return !0;
    c = b(a, "gdpr");
    return N(c, [to, vo]);
  });
  ng.push(function (a) {
    return {
      K: function (b, c) {
        var d = b.ha || {},
          e;
        b: {
          if ((e = R(a).hostname))
            if ((e = e.match(Wo))) if (((e = e[3]), N(e, gd))) break b;
          e = !1;
        }
        e
          ? (e = Vo + "." + e)
          : (e = I(a, "document.referrer"))
          ? ((e = ph(a, e).hostname), (e = id(e)), (e = Vo + "." + (e || Uo)))
          : (e = Sd);
        b.ha = O(d, { Hc: [e] });
        c();
      },
    };
  });
  X("h", cp, 7);
  X("a", cp, 7);
  X("5", cp, 7);
  X("1", cp, 7);
  og(cp, 7);
  ug.push(tp);
  X(
    "g",
    function (a, b) {
      return {
        K: function (c, d) {
          var e = c.D;
          if (e && e["page-url"]) {
            var f = e["page-url"];
            Fp(f) || Gp(f)
              ? cj(b, function (g) {
                  var h = I(g, "settings.goal_values");
                  if (h) {
                    var k = (g = ph(a, f).query) ? sd(g) : void 0;
                    if (k) {
                      g = c.H || {};
                      g.L || (g.L = {});
                      g.L.__ym || (g.L.__ym = {});
                      var l = Fp(f) ? Cp : Dp;
                      h = Ip(h);
                      h = Ep(a, k, h, l);
                      0 !== h.length &&
                        ((k = {}),
                        (h = ((k.cgd = h[0]), (k.cmg = h), k)),
                        O(g.L.__ym, h),
                        (c.H = O(c.H || {}, g)));
                    }
                  }
                  d();
                })["catch"](M(Pa(d), U(a, "a.g.v")))
              : d();
          } else d();
        },
      };
    },
    -2
  );
  xg.push(
    V("cdl", function (a) {
      var b = P(a).V;
      if ((a = I(a, "navigator.cookieDeprecationLabel")))
        try {
          a.getValue().then(F("cdl", b), D(["cdl", "e"], b));
        } catch (c) {
          b("cdl", "d");
        }
      else b("cdl", "na");
    })
  );
  O(Be, { Ld: { T: "disableYtm", rb: Nb } });
  Kh.ytm = ["f", "x"];
  tg.push(
    V("p.ytm", function (a, b) {
      var c = !1,
        d = [
          function () {
            c = !0;
          },
        ],
        e = D([ce, d], L),
        f = hq(a);
      Ft(
        a,
        b
      )(
        Cf(function (g) {
          if (c || !g) return Ef();
          g = Lh(a, b, "ytm");
          var h = {};
          return Df(
            ch(a, g)(
              { J: { N: ["ytm"], Fa: !0 }, D: f ? ((h.nonce = f), h) : void 0 },
              ["https://" + Sd + "/ytm-config/" + b.id]
            ).then(J(Et({ Ea: 1 })))
          );
        })
      )(
        Bf(U(a, "ytm.s"), function (g) {
          if (!c && A(g)) {
            var h = !(!f || !0 !== g.isPreview);
            $s(a, f);
            if (h) {
              var k = Zs(a, g);
              Lk(a, Rs, r, U(a, "ytm.d.in"));
            }
            aq(a, b, k && k.trigger);
            h = Bt(a, b.id, g, h);
            var l = Q(b);
            l = Dt(a, l).Eb;
            var m = Ct(a, g.permissions, b.id, g.containerId),
              p = Gf(a),
              q = xt({
                l: a,
                counterId: b.id,
                config: g,
                I: m,
                Tb: h,
                Kd: k,
                Eb: l,
                qd: p,
                uc: B(d.push, d),
              });
            d.push(h.zc, F(p.ae, pc));
            q.add(ss(a, "ytm.init_consent"));
            q.aa();
            Ef()(
              Bf(U(a, "ytm.r"), function () {
                c || (q.add(ss(a, "ytm.init")), d.push(ot(a, q, g)), q.aa());
              })
            );
          }
        })
      );
      return function () {
        return e();
      };
    })
  );
  wg.push(function (a, b, c) {
    c.policy = Qs(a).Ad;
  });
  Bd.push("_ytm_preview");
  ls.html = function (a, b, c, d, e, f) {
    d = a.l;
    a.I.checkPermission({ ja: c, permissionType: "html", F: null });
    a = Pr(a, b, c.data.html);
    Ds(d, a, e, f);
  };
  Ns.html = function (a, b) {
    return H(b, "html") ? !!b.html.unsafeSet : !1;
  };
  ls.pix = function (a, b, c, d, e, f) {
    d = a.l;
    var g = a.I;
    a = Pr(a, b, c.data.pixelUrl);
    u(a)
      ? (g.checkPermission({ ja: c, permissionType: "pixel", F: { url: a } }),
        bq(d, a, e, f))
      : f(Kp("ca.p.uns"));
  };
  Ns.pixel = Ks;
  wq.addConsentListener = function (a) {
    var b = a.l,
      c = a.I;
    return function (d, e) {
      if (!u(d)) throw Kp("ict");
      if (!y(e)) throw Kp("icl");
      c.checkPermission({
        permissionType: "accessConsent",
        F: { key: d, operation: 2 },
      });
      ro(b).on(d, e);
    };
  };
  wq.isConsentGranted = function (a) {
    var b = a.l,
      c = a.I;
    return function (d) {
      if (!u(d)) throw Kp("ict");
      c.checkPermission({
        permissionType: "accessConsent",
        F: { key: d, operation: 2 },
      });
      return ro(b).get(d);
    };
  };
  wq.setDefaultConsentState = yq;
  wq.updateConsentState = zq;
  ls.consent = function (a, b, c, d, e, f) {
    if (N(b.event, os)) {
      c = b.ytm.action;
      if (N(c, ps) && (a = ro(a.l).set(c, b.ytm.La))) {
        f(Kp(a));
        return;
      }
      e();
    } else f(Jp("t.c.e"));
  };
  Ns.accessConsent = function (a, b, c, d) {
    if (!H(b, c)) return !1;
    a = b[c];
    if (!H(a, "categories")) return !1;
    a = a.categories;
    b = d.key;
    return H(a, b) ? !!(a[b] & d.operation) : !1;
  };
  ls.timer = function (a, b, c, d, e, f) {
    var g = a.l,
      h = c.data.trigger,
      k = Is(a);
    if (k[h]) f(Kp("t.a.s.t"));
    else {
      var l = Pr(a, b, c.data.interval);
      u(l)
        ? ((l = Kr(l)),
          z(l)
            ? f(Jp("t.i.nn"))
            : ((a = ws(a, b, c.data.limit)),
              (d = {
                l: g,
                dispatchEvent: M(d.add, d.aa),
                interval: l,
                limit: a,
              }),
              (g = d.l),
              (a = 1e3 * d.interval),
              (b = {
                id: null,
                interval: a,
                sequence: 0,
                limit: d.limit || 0,
                startTime: W(g)(mf),
                xe: h,
              }),
              (b.id = zf(g, D([d, b], Hs), a, "yt.t")),
              (k[h] = !0),
              e()))
        : f(Jp("t.i.ns"));
    }
  };
  ls.elementVisibility = function (a, b, c, d, e, f) {
    var g = a.l,
      h = c.data.trigger,
      k = xs(a);
    if (k[h]) f(Kp("t.a.s.ev"));
    else if (wa("IntersectionObserver", g.IntersectionObserver)) {
      var l = c.data;
      g = l.sm;
      var m = l.srp,
        p = l.lfd,
        q = l.ff,
        v = l.trigger,
        t = ws(a, b, l.sd, !0);
      z(t) || ((t = 0 > t ? null : t), z(t) || (t *= 1e3));
      m = ws(a, b, m, !0);
      z(m) || (m = 0 > m || 100 < m ? null : m);
      "id" === g
        ? ((b = Pr(a, b, l.id)),
          (c =
            u(b) && b
              ? O({}, c, {
                  data: {
                    Xc: g,
                    id: b,
                    Wc: t || 0,
                    $b: m || 50,
                    Pc: p,
                    Fc: q,
                    trigger: v,
                  },
                })
              : null))
        : ((b = Pr(a, b, l.selector)),
          (c =
            u(b) && b
              ? O({}, c, {
                  data: {
                    Xc: g,
                    selector: b,
                    Wc: t || 0,
                    $b: m || 50,
                    Pc: p,
                    Fc: q,
                    trigger: v,
                  },
                })
              : null));
      if (z(c)) f(Jp("p.f.ev"));
      else {
        try {
          vs(a, M(d.add, d.aa), c);
        } catch (x) {
          f(x);
          return;
        }
        k[h] = !0;
        e();
      }
    } else f(Jp("n.io.ev"));
  };
  ls.scrollDepth = function (a, b, c, d, e, f) {
    var g = Fs(a),
      h = c.data;
    c = h.index;
    var k = h.vpt,
      l = h.mode;
    h = h.ps;
    if (g[c]) f(Kp("t.a.s.sd"));
    else {
      if ("pt" === l) {
        if (!k) {
          f(Jp("t.a.s.sd.t"));
          return;
        }
        b = Pr(a, b, k);
        b = Es(b);
      } else {
        if (!h) {
          f(Jp("t.a.s.sd.s"));
          return;
        }
        b = Pr(a, b, h);
        if (u(b))
          if (((b = sb(b)), z(b) || 0 >= b || 100 < b)) b = [];
          else {
            f = [];
            for (k = b; 100 >= k; ) f.push(k), (k += b);
            b = f;
          }
        else b = [];
      }
      Gs(a, M(d.add, d.aa))(c, b);
      g[c] = !0;
      e();
    }
  };
  vg.push(It);
  xg.push(Jt);
  Kt.init || (Kt.init = []);
  Kt.init.push(function (a, b, c) {
    return !!I(c, "0.ssr");
  });
  vg.push(Vt);
  ug.push(Wt);
  xe.getYmclid = "yc";
  vg.push(Zt);
  vg.push($t);
  xg.push(au);
  vg.push(fu);
  og(gu, 6);
  X("h", gu, 6);
  X("a", gu, 6);
  X("5", gu, 6);
  X("1", gu, 6);
  X("adb");
  X("n", gu, 4);
  Kh.adb = Hh;
  Oh.adb = jh;
  tg.push(ju);
  var gv = {};
  O(Yf, ((gv.bu = nu), gv));
  Kh["6"] = ["f", "x"];
  Oh["6"] = ch;
  ug.push(pu);
  (function () {
    var a = {};
    O(
      Yf,
      ((a.mdd = function (b) {
        return Ed(b, "mdd");
      }),
      a)
    );
    a = {};
    O(De, ((a.cac = Zk("cac")), (a.cae = Zk("cae")), a));
    vg.push(wu, xu);
  })();
  og(Eu, 5);
  X("h", Eu, 5);
  X("a", Eu, 5);
  X("5", Eu, 5);
  X("1", Eu, 6);
  Kh.c = Hh;
  Oh.c = ch;
  og(Ku, 8);
  X("h", Ku, 8);
  X("a", Ku, 8);
  X("f", Ku, 3);
  X("n", Ku, 5);
  X("5", Ku, 8);
  Kh.csu = ["i"];
  Oh.csu = ch;
  vg.push(
    V("p.gss", function (a, b) {
      return cj(b, function (c) {
        var d = bd(a),
          e = d.o,
          f = d.B;
        if (!e("csup"))
          if (((d = I(c, "settings.csu")), kd(a) || ye(b.M) || (!u(d) && !d)))
            f("csu", 0);
          else if (Hu(c)) f("csu", 5);
          else {
            var g = Me(a),
              h = W(a)(nf);
            if ((c = sb(g.o("csu"))) && 1440 >= h - c) f("csu", 1);
            else
              return (
                f("csup", 1),
                f("csu", 2),
                Ph(
                  a,
                  "csu",
                  b
                )({ J: { N: ["csu"] } }, [d]).then(function () {
                  f("csu", 4);
                  g.B("csu", h);
                }, D(["csu", 3], f))
              );
          }
      })["catch"](U(a, "s.csu"));
    })
  );
  var hv = {};
  O(De, ((hv.csu = Zk("csu")), hv));
  Kh.pi = Fh;
  Oh.pi = lh;
  X("pi", $f());
  var iv = {};
  O(Yf, ((iv.bl = Zk("bl")), iv));
  var jv = {};
  O(De, ((jv.oms = Zk("oms")), jv));
  ug.push(
    V(
      "isp.bl",
      Mu(
        "bl",
        function () {
          return T("=", ["https://fcpe.beeline.ru/sync/me?guid", Nu()]);
        },
        Lu
      )
    )
  );
  ug.push(
    V(
      "isp.mf",
      Mu("mf", function (a, b, c, d) {
        b = R(a);
        b = qd(b.protocol + "//" + b.hostname + b.pathname);
        c = "";
        do c += kf(a);
        while (c.length < d.length);
        c = c.slice(0, d.length);
        a = "";
        for (var e = 0; e < d.length; e += 1)
          a += (d.charCodeAt(e) + c.charCodeAt(e) - 96) % 10;
        d = n([c, a]);
        a = d.next().value;
        return (
          "https://adstat.yandex.ru/track?service=metrika&id=" +
          d.next().value +
          "&mask=" +
          a +
          "&ref=" +
          b
        );
      })
    )
  );
  ug.push(
    V(
      "isp.rt",
      Mu("rt", function (a, b, c, d) {
        c = "" + Wj(d);
        var e = {};
        d = $g(((e.rt = 1), (e.u = d), e)).ra();
        e = {};
        a = td(
          ((e["browser-info"] = d),
          (e["page-url"] = R(a).href),
          (e["page-ref"] = a.document.referrer),
          (e["site-info"] = b),
          e)
        );
        return "https://" + c + ".mc.yandex.ru/watch/99742118/1?" + a;
      })
    )
  );
  ug.push(
    V(
      "isp.tl2",
      Mu("tl2", function (a, b, c, d) {
        if ((c = I(c, "settings.tl2"))) {
          var e = {};
          d = $g(((e.tl2 = 1), (e.u = d), e)).ra();
          e = {};
          a = td(
            ((e["browser-info"] = d),
            (e["page-url"] = R(a).href),
            (e["page-ref"] = a.document.referrer),
            (e["site-info"] = b),
            e)
          );
          return "https://" + c + ".mc.yandex.ru/watch/99742118/1?" + a;
        }
      })
    )
  );
  var kv = {};
  O(De, ((kv.mfs = Zk("mfs")), kv));
  vg.push(V("p.ot", Pu));
  Kh.ci = ["x"];
  Oh.ci = ch;
  vg.push(
    V("p.sci", function (a, b) {
      return cj(b, D([a, b], Qu))["catch"](U(a, "ins.cs"));
    })
  );
  var lv = {};
  O(De, ((lv.csi = Zk("scip")), lv));
  Kh.pis = Ih;
  Oh.pis = ch;
  vg.push(
    V("p.sci", function (a, b) {
      return cj(b, function (c) {
        var d = I(c, "settings.pis");
        if (d && !Hu(c)) {
          c = P(a);
          var e = c.o;
          c = c.B;
          e = e("pis");
          if (z(e))
            return (
              (e = Ph(a, "pis", b)),
              c("pis", "0"),
              e({ J: { N: ["pis"] } }, [d]).then(
                D(["pis", "1"], c),
                Pa(D(["pis", "a"], c))
              )
            );
        }
      })["catch"](U(a, "pis"));
    })
  );
  var mv = {};
  O(De, ((mv.pis = Zk("pis")), mv));
  (function () {
    Kh.pic = ["j"];
    Oh.pic = ch;
    vg.push(Su);
    var a = {};
    O(
      Yf,
      ((a.pic = function (b) {
        return Ed(b, "_ym_fa");
      }),
      a)
    );
    a = {};
    O(De, ((a.prs = Zk("prs")), a));
  })();
  De.wds = Zk("wds");
  vg.push(Vu);
  ug.push(function (a, b) {
    var c = Lt(a),
      d = Q(b),
      e = c[d];
    e || ((e = {}), (c[d] = e));
    e.Vd = !0;
    if ((c = e.dd)) (d = Nt(a)), L(d, c);
  });
  vg.unshift(function (a, b) {
    cj(b, function (c) {
      var d = Md(a),
        e = Ik(a);
      (d || e.id) && Ht(a, "tag_debug", b, c);
    });
  });
  function nv(a, b, c, d) {
    var e = this;
    return U(window, "c.i", function () {
      function f(C) {
        (C = ik(k, m, "", C)(k, m)) && (y(C.then) ? C.then(g) : g(C));
        return C;
      }
      function g(C) {
        C &&
          (y(C)
            ? p.push(C)
            : A(C) &&
              L(function (S) {
                var Z = n(S);
                S = Z.next().value;
                Z = Z.next().value;
                y(Z) && ("u" === S ? p.push(Z) : h(Z, S));
              }, dc(C)));
      }
      function h(C, S, Z) {
        e[S] = $u(k, m, Z || q, S, C);
      }
      var k = window;
      (!k || (isNaN(a) && !a)) && ae();
      var l = ze(a, b, c, d),
        m = Ae(l);
      Gt(m).oe = l;
      ti(m, m.L || {});
      var p = [],
        q = [av, ik, bv];
      q.unshift(ki);
      var v = L(lb, vg);
      l = Q(m);
      m.id || Ud(Xd("Invalid Metrika id: " + m.id, !0));
      var t = cv.o("counters", {});
      if (t[l]) return (v = {}), Uh(k, l, "dc", ((v.key = l), v)), t[l];
      var x = aj(l),
        E = I(k, "ym.l");
      rb(k, E) && (x.Wd = E);
      x.kb = W(k)(mf);
      t[l] = e;
      cv.B("counters", t);
      cv.V("counter", e);
      L(function (C) {
        C(k, m);
      }, sg);
      U(k, "c.i.bh", function () {
        L(f, tg);
      })();
      f(Yu);
      h(Zu(k, m, p), "destruct", [av, bv]);
      dj(k, D([k, v, f, "a.i", 1], jj), "a.ra");
      U(k, "c.i.ps", function () {
        L(f, ug);
      })();
      l = {};
      Qd(k, ((l.counterKey = Q(m)), (l.name = "counter"), (l.data = gh(m)), l));
    })();
  }
  U(window, "wp.i", function () {
    L(Na(ce)(window), xg);
  })();
  if (window.Ya && nv) {
    window.Ya[Rd] = nv;
    Xu(window);
    var ov = window.Ya[Rd];
    cv.V("staticMethods", {});
    var pv = cv.o("staticMethods");
    L(M(Jb([window, ov, pv]), ce), wg);
  }
  (function (a) {
    var b = I(a, "ym");
    if (b) {
      var c = I(b, "a");
      c || ((b.a = []), (c = b.a));
      var d = Nt(a);
      Fi(
        a,
        c,
        function (e) {
          e.Ba.C(d);
        },
        !0
      );
    }
  })(window);
}.call(this));
