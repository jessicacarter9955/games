try {
  var dv_win = window._dv_win || window.parent._dv_win;
  dv_win["dvCallback_1795529478554176"](
    $dv,
    window,
    "844b267d36a84c8a9289723f99c050de",
    "maestro-ew1.tps.dv.tech",
    { ee: { cvs: { size: 80, dur: 1000, cons: 1 } }, ce: { ddt: 1, dt: 1 } }
  );
} catch (e) {
  try {
    var image = window.document.createElement("img");
    image.src =
      ("https://tps.doubleverify.com/visit.jpg" ||
        window.location.protocol + "//tps30.doubleverify.com/visit.jpg") +
      "?ctx=818052&cmp=1619415&dvtagver=6.1.src&dvp_cbError=" +
      encodeURIComponent(e.message);
  } catch (e) {}
}
try {
  $dv.pubSub.publish("ImpressionServed", $uid);
  $dv.pubSub.publish("ImpressionServed", $frmId);
} catch (e) {}
