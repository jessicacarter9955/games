var __IntegralASDiagnosticCall = (function () {
  try {
    var alreadySent = {};
    return function (code, err, config) {
      try {
        if (!__IASScope.isDomless) {
          try {
            __IASScope.postMessage(
              {
                code,
                name: "jsdiag",
                origin: "ias",
              },
              "*"
            );
          } catch (_) {}
        }

        var gen = function (code, err, config) {
          var url = "//diag.adsafeprotected.com/js?";
          try {
            var errMsg =
              err && err.message
                ? encodeURIComponent(err.message.replace(/ /g, "-")).substring(
                    0,
                    200
                  )
                : "";
            url += "code:fwjs-diag-" + code;
            url += "&err:" + errMsg;
            url += "&codeanderr:" + code + "_" + errMsg;
            if (config) {
              // `store` may be undeclared when this file is concatenated into joinJsDiagnostic.js (imports stripped).
              let diagAsid = "";
              if (
                typeof store !== "undefined" &&
                store.adTag &&
                store.adTag.asid
              ) {
                diagAsid = String(store.adTag.asid);
              }
              url += "&version:" + config.version || "";
              url += "&server:" + config.mn || "";
              url += "&region:" + config.region || "";
              url += "&mode:" + config.mode || "";
              url += "&forceAppend:" + config.forceAppend || "";
              // Blank asid is fine: e.g. pre-init or stripped bundle without store.
              url += "&asid:" + diagAsid;
              url += "&anId:" + config.anId || "";
              url += "&advEntityId:" + config.advEntityId || "";
              url += "&pubEntityId:" + config.pubEntityId || "";
              url += "&mobOrTab:" + config.mobOrTab || "";
              url += "&app:" + config.app || "";
              url += "&mobAppWebview:" + config.mobAppWebview || "";
            }
            url += "&domless:" + __IASScope.isDomless;
          } catch (e) {
            url +=
              "&diagx:" +
              (e && e.message ? e.message.toString().replace(/ /g, "-") : "");
          }
          return url;
        };

        var send = function (url) {
          if (
            __IASScope.isDomless &&
            __IASOmidVerificationClient &&
            __IASOmidVerificationClient.sendUrl
          ) {
            __IASOmidVerificationClient.sendUrl(url);
          } else {
            var img = new Image();
            img.src = url;
          }
        };
        if (!alreadySent[code] && Math.random() < 0.01) {
          alreadySent[code] = true;
          send(gen(code, err, config));
        }
      } catch (e) {}
    };
  } catch (e) {
    return function () {};
  }
})();

try {
  var __IntegralASConfig = {
    jsDoSplit: false,
    debug: "false",
    jsDiag: "true",
    version: "19.8.744",
    exchList: {
      e1: "nqzryq",
      e2: "tbbtyrnqf.t.qbhoyrpyvpx",
      e3: "ehovpbacebwrpg",
      e4: "chozngvp",
      e5: "bcrak",
      e6: "nqoevgr.pbz",
      e7: "tynz.pbz",
      e8: "lvryqznantre.pbz",
      e9: "yvwvg",
      e10: "nqakf",
      p11: "ghea.pbz",
      p12: "zngugnt",
      p13: "vaivgrzrqvn",
      p14: "qngnkh",
      n15: "zrqvn6qrterrf",
      n16: "dhnagfreir",
      n17: "esvuho.arg",
      a18: "napubeserr",
      a19: "eff2frnepu",
      a20: "mgfgngvp.pbz",
      n21: "ovq.npr.nqiregvfvat",
      e22: "wnfba",
      v23: "fcbgkpqa",
      v24: "ogeyy",
      v25: "yvirenvy",
      v26: "nqncgi",
      v27: "nqnc.gi",
      n29: "qbzqrk.pbz",
      n30: "ernyih.arg",
      d31: "cvengronl",
      d32: "cebklonl",
      d33: "onlcebkl",
      d34: "cvengrcebkl",
      d35: "cebklcvengr",
      d36: "onlcvengr",
      n37: "tjnyyrg",
      p39: "j55p.arg",
      p40: "c0l.pa",
      p41: "vcvalbh.pbz",
      p42: "c0lwferaqre",
    },
    sp_cdnDomain: "cdn.adsafeprotected.com",
    sp_cdnScripts: {
      xsca: "static.adsafeprotected.com/xsca.17.4.85.js",
      sca: "static.adsafeprotected.com/sca.17.6.4.js",
      main: "static.adsafeprotected.com/main.19.8.744.js",
    },
    protocol: "https",
    jsref:
      "https://ac5483e22bed3c79565c7a5f3e0d98e9.safeframe.googlesyndication.com/",
    asid: "6b6b8cd0-e80f-11f1-ae48-8e3c22363d47",
    allowViewability: "true",
    jsFeatures:
      "viewabilityready,rattie,exch,usedtdomain,resolution,usetpl,idMap,offscreen,everySecond:1,slid,fm2:1,largeAd,chromeNativeIO,ios,ancestor,avmm,avgrn,swapids,pIntervals:10,usesca,bustediframe,impFailSafe,yieldmo,sfdetect,pmdetect,novidnodeerr:5,viewabilityOptimization,usehaps,customMetric,sizmek,celtra,groupmCM,avidPropertiesInImpression,abcAudit,mrcAudit:1,bbs,bas,spg,exitOASRSEarly:1,encodeInvalidUrlChars,recoverOmidLostTime,forceKeepGoogleAdNode",
    minimizeCalls: "false",
    adWidth: "300",
    adHeight: "250",
    forceAppend: "false",
    forceNoIframe: false,
    sp_imp_maxLength: 10000,
    sp_imp_jsInfo_minLength: 200,
    _onInViewMRC15: __IntegralASConfig && __IntegralASConfig.onInViewMRC15,
    _onInViewMRC: __IntegralASConfig && __IntegralASConfig.onInViewMRC,
    _onMeasurable: __IntegralASConfig && __IntegralASConfig.onMeasurable,
    _onAPIResult: __IntegralASConfig && __IntegralASConfig.onAPIResult,
    _onInViewFull: __IntegralASConfig && __IntegralASConfig.onInViewFull,
    _onSuspicious: __IntegralASConfig && __IntegralASConfig.onSuspicious,
    _onInViewMRC5: __IntegralASConfig && __IntegralASConfig.onInViewMRC5,
    reqquery: "",
    mode: "rjss",
    requrl: "",
    dtBaseURL: "https://dt.adsafeprotected.com/dt?advEntityId=3131935",
    adsafeSrc:
      "https://fw.adsafeprotected.com/rfw/cdn.flashtalking.com/3131935/97089382/armada/tags/placement-ft-inserts/11266281-ftInsert.js",
    tpiLookupURL: "",
    getTpl: "false",
    use100v: false,
    useBapiCallback: "",
    useViewabilityNotification: "",
    scriptUrl:
      "https://fw.adsafeprotected.com/rjss/cdn.flashtalking.com/3131935/97089382/armada/tags/placement-ft-inserts/11266281-ftInsert.js",
    accountForSadImps: "",
    fwMonitoring: "false",
    mn: "jsserver-primary-f8954df68-pl6v6",
    mobOrTab: false,
    app: false,
    mobAppWebview: false,
    mobFwUrl:
      "https://mobile.adsafeprotected.com/internal/blocking/app/initial/3131935/97089382?redirectUrl=https%3A%2F%2Fcdn.flashtalking.com%2Farmada%2Ftags%2Fplacement-ft-inserts%2F11266281-ftInsert.js",
    anId: "",
    advEntityId: "3131935",
    pubEntityId: "97089382",
    videoId: "",
    rts: {},
    customViewability: [],
    serverSideAppDetection: [],
    groupm_native_publisher: false,
    integration: null,
    staticServer: "//static.adsafeprotected.com/",
    passback: "",
    iasProxyPartnerDomain: "",
    region: "ie",
  };

  try {
    __IASScope = typeof window !== "undefined" ? window : this;

    __IntegralASConfig.isResolved = !!__IntegralASConfig.jsFeatures;
    __IntegralASConfig.staticMode = !__IntegralASConfig.isResolved;
    __IntegralASConfig.birthdate = new Date().getTime();
    __IntegralASConfig.perfBirth =
      typeof __IASScope.performance !== "undefined" &&
      typeof __IASScope.performance.now === "function"
        ? __IASScope.performance.now()
        : null;

    (function (omidGlobal, factory, exports) {
      // CommonJS support
      if (typeof exports === "object" && typeof exports.nodeName !== "string") {
        factory(omidGlobal, exports);

        // If neither AMD nor CommonJS are used, export to a versioned name in the
        // global context.
      } else {
        var exports = {};
        var versions = ["1.5.3-iab4563"];
        var additionalVersionString = "";
        if (!!additionalVersionString) {
          versions.push(additionalVersionString);
        }

        factory(omidGlobal, exports);

        function deepFreeze(object) {
          for (var key in object) {
            if (object.hasOwnProperty(key)) {
              object[key] = deepFreeze(object[key]);
            }
          }
          return Object.freeze(object);
        }

        // Inject and freeze the exported components of omid.
        for (var key in exports) {
          if (exports.hasOwnProperty(key)) {
            if (Object.getOwnPropertyDescriptor(omidGlobal, key) == null) {
              // Define the top level property in the global scope
              Object.defineProperty(omidGlobal, key, {
                //			value: {},       Removed trailing comma for build
                value: {},
              });
            }
            versions.forEach(function (version) {
              if (
                Object.getOwnPropertyDescriptor(omidGlobal[key], version) ==
                null
              ) {
                var frozenObject = deepFreeze(exports[key]);
                // Define the object exports keyed-off versions
                Object.defineProperty(omidGlobal[key], version, {
                  get: function () {
                    return frozenObject;
                  },
                  //            enumerable: true,       Removed trailing comma for build
                  enumerable: true,
                });
              }
            });
          }
        }
      }
    })(
      typeof global === "undefined" ? this : global,
      function (omidGlobal, omidExports) {
        var $jscomp = $jscomp || {};
        $jscomp.scope = {};
        $jscomp.createTemplateTagFirstArg = function (a) {
          return (a.raw = a);
        };
        $jscomp.createTemplateTagFirstArgWithRaw = function (a, b) {
          a.raw = b;
          return a;
        };
        $jscomp.arrayIteratorImpl = function (a) {
          var b = 0;
          return function () {
            return b < a.length ? { done: !1, value: a[b++] } : { done: !0 };
          };
        };
        $jscomp.arrayIterator = function (a) {
          return { next: $jscomp.arrayIteratorImpl(a) };
        };
        $jscomp.makeIterator = function (a) {
          var b =
            "undefined" != typeof Symbol &&
            Symbol.iterator &&
            a[Symbol.iterator];
          if (b) {
            return b.call(a);
          }
          if ("number" == typeof a.length) {
            return $jscomp.arrayIterator(a);
          }
          throw Error(String(a) + " is not an iterable or ArrayLike");
        };
        $jscomp.arrayFromIterator = function (a) {
          for (var b, c = []; !(b = a.next()).done; ) {
            c.push(b.value);
          }
          return c;
        };
        $jscomp.arrayFromIterable = function (a) {
          return a instanceof Array
            ? a
            : $jscomp.arrayFromIterator($jscomp.makeIterator(a));
        };
        $jscomp.ASSUME_ES5 = !1;
        $jscomp.ASSUME_NO_NATIVE_MAP = !1;
        $jscomp.ASSUME_NO_NATIVE_SET = !1;
        $jscomp.SIMPLE_FROUND_POLYFILL = !1;
        $jscomp.ISOLATE_POLYFILLS = !1;
        $jscomp.FORCE_POLYFILL_PROMISE = !1;
        $jscomp.FORCE_POLYFILL_PROMISE_WHEN_NO_UNHANDLED_REJECTION = !1;
        $jscomp.objectCreate =
          $jscomp.ASSUME_ES5 || "function" == typeof Object.create
            ? Object.create
            : function (a) {
                var b = function () {};
                b.prototype = a;
                return new b();
              };
        $jscomp.defineProperty =
          $jscomp.ASSUME_ES5 || "function" == typeof Object.defineProperties
            ? Object.defineProperty
            : function (a, b, c) {
                if (a == Array.prototype || a == Object.prototype) {
                  return a;
                }
                a[b] = c.value;
                return a;
              };
        $jscomp.getGlobal = function (a) {
          a = [
            "object" == typeof globalThis && globalThis,
            a,
            "object" == typeof window && window,
            "object" == typeof self && self,
            "object" == typeof global && global,
          ];
          for (var b = 0; b < a.length; ++b) {
            var c = a[b];
            if (c && c.Math == Math) {
              return c;
            }
          }
          throw Error("Cannot find global object");
        };
        $jscomp.global = $jscomp.getGlobal(this);
        $jscomp.IS_SYMBOL_NATIVE =
          "function" === typeof Symbol && "symbol" === typeof Symbol("x");
        $jscomp.TRUST_ES6_POLYFILLS =
          !$jscomp.ISOLATE_POLYFILLS || $jscomp.IS_SYMBOL_NATIVE;
        $jscomp.polyfills = {};
        $jscomp.propertyToPolyfillSymbol = {};
        $jscomp.POLYFILL_PREFIX = "$jscp$";
        var $jscomp$lookupPolyfilledValue = function (a, b, c) {
          if (!c || null != a) {
            c = $jscomp.propertyToPolyfillSymbol[b];
            if (null == c) {
              return a[b];
            }
            c = a[c];
            return void 0 !== c ? c : a[b];
          }
        };
        $jscomp.polyfill = function (a, b, c, d) {
          b &&
            ($jscomp.ISOLATE_POLYFILLS
              ? $jscomp.polyfillIsolated(a, b, c, d)
              : $jscomp.polyfillUnisolated(a, b, c, d));
        };
        $jscomp.polyfillUnisolated = function (a, b, c, d) {
          c = $jscomp.global;
          a = a.split(".");
          for (d = 0; d < a.length - 1; d++) {
            var e = a[d];
            if (!(e in c)) {
              return;
            }
            c = c[e];
          }
          a = a[a.length - 1];
          d = c[a];
          b = b(d);
          b != d &&
            null != b &&
            $jscomp.defineProperty(c, a, {
              configurable: !0,
              writable: !0,
              value: b,
            });
        };
        $jscomp.polyfillIsolated = function (a, b, c, d) {
          var e = a.split(".");
          a = 1 === e.length;
          d = e[0];
          d = !a && d in $jscomp.polyfills ? $jscomp.polyfills : $jscomp.global;
          for (var f = 0; f < e.length - 1; f++) {
            var g = e[f];
            if (!(g in d)) {
              return;
            }
            d = d[g];
          }
          e = e[e.length - 1];
          c = $jscomp.IS_SYMBOL_NATIVE && "es6" === c ? d[e] : null;
          b = b(c);
          null != b &&
            (a
              ? $jscomp.defineProperty($jscomp.polyfills, e, {
                  configurable: !0,
                  writable: !0,
                  value: b,
                })
              : b !== c &&
                (void 0 === $jscomp.propertyToPolyfillSymbol[e] &&
                  ((c = (1e9 * Math.random()) >>> 0),
                  ($jscomp.propertyToPolyfillSymbol[e] =
                    $jscomp.IS_SYMBOL_NATIVE
                      ? $jscomp.global.Symbol(e)
                      : $jscomp.POLYFILL_PREFIX + c + "$" + e)),
                $jscomp.defineProperty(d, $jscomp.propertyToPolyfillSymbol[e], {
                  configurable: !0,
                  writable: !0,
                  value: b,
                })));
        };
        $jscomp.getConstructImplementation = function () {
          function a() {
            function c() {}
            new c();
            Reflect.construct(c, [], function () {});
            return new c() instanceof c;
          }
          if (
            $jscomp.TRUST_ES6_POLYFILLS &&
            "undefined" != typeof Reflect &&
            Reflect.construct
          ) {
            if (a()) {
              return Reflect.construct;
            }
            var b = Reflect.construct;
            return function (c, d, e) {
              c = b(c, d);
              e && Reflect.setPrototypeOf(c, e.prototype);
              return c;
            };
          }
          return function (c, d, e) {
            void 0 === e && (e = c);
            e = $jscomp.objectCreate(e.prototype || Object.prototype);
            return Function.prototype.apply.call(c, e, d) || e;
          };
        };
        $jscomp.construct = {
          valueOf: $jscomp.getConstructImplementation,
        }.valueOf();
        $jscomp.underscoreProtoCanBeSet = function () {
          var a = { a: !0 },
            b = {};
          try {
            return (b.__proto__ = a), b.a;
          } catch (c) {}
          return !1;
        };
        $jscomp.setPrototypeOf =
          $jscomp.TRUST_ES6_POLYFILLS &&
          "function" == typeof Object.setPrototypeOf
            ? Object.setPrototypeOf
            : $jscomp.underscoreProtoCanBeSet()
            ? function (a, b) {
                a.__proto__ = b;
                if (a.__proto__ !== b) {
                  throw new TypeError(a + " is not extensible");
                }
                return a;
              }
            : null;
        $jscomp.inherits = function (a, b) {
          a.prototype = $jscomp.objectCreate(b.prototype);
          a.prototype.constructor = a;
          if ($jscomp.setPrototypeOf) {
            var c = $jscomp.setPrototypeOf;
            c(a, b);
          } else {
            for (c in b) {
              if ("prototype" != c) {
                if (Object.defineProperties) {
                  var d = Object.getOwnPropertyDescriptor(b, c);
                  d && Object.defineProperty(a, c, d);
                } else {
                  a[c] = b[c];
                }
              }
            }
          }
          a.superClass_ = b.prototype;
        };
        $jscomp.getRestArguments = function () {
          for (var a = Number(this), b = [], c = a; c < arguments.length; c++) {
            b[c - a] = arguments[c];
          }
          return b;
        };
        $jscomp.polyfill(
          "Reflect",
          function (a) {
            return a ? a : {};
          },
          "es6",
          "es3"
        );
        $jscomp.polyfill(
          "Reflect.construct",
          function (a) {
            return $jscomp.construct;
          },
          "es6",
          "es3"
        );
        $jscomp.polyfill(
          "Reflect.setPrototypeOf",
          function (a) {
            if (a) {
              return a;
            }
            if ($jscomp.setPrototypeOf) {
              var b = $jscomp.setPrototypeOf;
              return function (c, d) {
                try {
                  return b(c, d), !0;
                } catch (e) {
                  return !1;
                }
              };
            }
            return null;
          },
          "es6",
          "es5"
        );
        $jscomp.owns = function (a, b) {
          return Object.prototype.hasOwnProperty.call(a, b);
        };
        $jscomp.polyfill(
          "Object.values",
          function (a) {
            return a
              ? a
              : function (b) {
                  var c = [],
                    d;
                  for (d in b) {
                    $jscomp.owns(b, d) && c.push(b[d]);
                  }
                  return c;
                };
          },
          "es8",
          "es3"
        );
        var module$exports$omid$common$constants = {
          AdEventType: {
            IMPRESSION: "impression",
            LOADED: "loaded",
            GEOMETRY_CHANGE: "geometryChange",
            SESSION_START: "sessionStart",
            SESSION_ERROR: "sessionError",
            SESSION_FINISH: "sessionFinish",
            MEDIA: "media",
            VIDEO: "video",
            START: "start",
            FIRST_QUARTILE: "firstQuartile",
            MIDPOINT: "midpoint",
            THIRD_QUARTILE: "thirdQuartile",
            COMPLETE: "complete",
            PAUSE: "pause",
            RESUME: "resume",
            BUFFER_START: "bufferStart",
            BUFFER_FINISH: "bufferFinish",
            SKIPPED: "skipped",
            VOLUME_CHANGE: "volumeChange",
            PLAYER_STATE_CHANGE: "playerStateChange",
            AD_USER_INTERACTION: "adUserInteraction",
            STATE_CHANGE: "stateChange",
          },
          MediaEventType: {
            LOADED: "loaded",
            START: "start",
            FIRST_QUARTILE: "firstQuartile",
            MIDPOINT: "midpoint",
            THIRD_QUARTILE: "thirdQuartile",
            COMPLETE: "complete",
            PAUSE: "pause",
            RESUME: "resume",
            BUFFER_START: "bufferStart",
            BUFFER_FINISH: "bufferFinish",
            SKIPPED: "skipped",
            VOLUME_CHANGE: "volumeChange",
            PLAYER_STATE_CHANGE: "playerStateChange",
            AD_USER_INTERACTION: "adUserInteraction",
          },
          ImpressionType: {
            DEFINED_BY_JAVASCRIPT: "definedByJavaScript",
            UNSPECIFIED: "unspecified",
            LOADED: "loaded",
            BEGIN_TO_RENDER: "beginToRender",
            ONE_PIXEL: "onePixel",
            VIEWABLE: "viewable",
            AUDIBLE: "audible",
            OTHER: "other",
          },
          ErrorType: { GENERIC: "generic", VIDEO: "video", MEDIA: "media" },
          AdSessionType: {
            NATIVE: "native",
            HTML: "html",
            JAVASCRIPT: "javascript",
          },
          EventOwner: {
            NATIVE: "native",
            JAVASCRIPT: "javascript",
            NONE: "none",
          },
          SessionOwner: { JAVASCRIPT: "javascript", NATIVE: "native" },
          AccessMode: { FULL: "full", DOMAIN: "domain", LIMITED: "limited" },
          AppState: {
            BACKGROUNDED: "backgrounded",
            FOREGROUNDED: "foregrounded",
          },
          DeviceLockState: { LOCKED: "locked", UNLOCKED: "unlocked" },
          Environment: { APP: "app", WEB: "web" },
          DeviceCategory: {
            CTV: "ctv",
            DESKTOP: "desktop",
            MOBILE: "mobile",
            OTHER: "other",
          },
          InteractionType: {
            CLICK: "click",
            INVITATION_ACCEPT: "invitationAccept",
          },
          CreativeType: {
            DEFINED_BY_JAVASCRIPT: "definedByJavaScript",
            HTML_DISPLAY: "htmlDisplay",
            NATIVE_DISPLAY: "nativeDisplay",
            VIDEO: "video",
            AUDIO: "audio",
          },
          MediaType: { DISPLAY: "display", VIDEO: "video" },
          Reason: {
            NOT_FOUND: "notFound",
            HIDDEN: "hidden",
            BACKGROUNDED: "backgrounded",
            PICTURE_IN_PICTURE: "pictureInPicture",
            DEVICE_LOCKED: "deviceLocked",
            VIEWPORT: "viewport",
            OBSTRUCTED: "obstructed",
            CLIPPED: "clipped",
            UNMEASURABLE: "unmeasurable",
            NO_WINDOW_FOCUS: "noWindowFocus",
            NO_OUTPUT_DEVICE: "noOutputDevice",
          },
          SupportedFeatures: { CONTAINER: "clid", VIDEO: "vlid" },
          VideoPosition: {
            PREROLL: "preroll",
            MIDROLL: "midroll",
            POSTROLL: "postroll",
            STANDALONE: "standalone",
          },
          VideoPlayerState: {
            MINIMIZED: "minimized",
            COLLAPSED: "collapsed",
            NORMAL: "normal",
            EXPANDED: "expanded",
            FULLSCREEN: "fullscreen",
          },
          NativeViewKeys: {
            X: "x",
            LEFT: "left",
            Y: "y",
            TOP: "top",
            WIDTH: "width",
            HEIGHT: "height",
            AD_SESSION_ID: "adSessionId",
            IS_FRIENDLY_OBSTRUCTION_FOR: "isFriendlyObstructionFor",
            CLIPS_TO_BOUNDS: "clipsToBounds",
            CHILD_VIEWS: "childViews",
            END_X: "endX",
            END_Y: "endY",
            OBSTRUCTIONS: "obstructions",
            OBSTRUCTION_CLASS: "obstructionClass",
            OBSTRUCTION_PURPOSE: "obstructionPurpose",
            OBSTRUCTION_REASON: "obstructionReason",
            PIXELS: "pixels",
            HAS_WINDOW_FOCUS: "hasWindowFocus",
          },
          MeasurementStateChangeSource: {
            CONTAINER: "container",
            CREATIVE: "creative",
          },
          ElementMarkup: { OMID_ELEMENT_CLASS_NAME: "omid-element" },
          CommunicationType: {
            NONE: "NONE",
            DIRECT: "DIRECT",
            POST_MESSAGE: "POST_MESSAGE",
          },
          OmidImplementer: { OMSDK: "omsdk" },
          MessageMethod: { IDENTIFY_SERVICE_WINDOW: "identifyServiceWindow" },
        };
        var module$contents$omid$common$InternalMessage_GUID_KEY =
            "omid_message_guid",
          module$contents$omid$common$InternalMessage_METHOD_KEY =
            "omid_message_method",
          module$contents$omid$common$InternalMessage_VERSION_KEY =
            "omid_message_version",
          module$contents$omid$common$InternalMessage_ARGS_KEY =
            "omid_message_args",
          module$exports$omid$common$InternalMessage = function (a, b, c, d) {
            this.guid = a;
            this.method = b;
            this.version = c;
            this.args = d;
          };
        module$exports$omid$common$InternalMessage.isValidSerializedMessage =
          function (a) {
            return (
              !!a &&
              void 0 !==
                a[module$contents$omid$common$InternalMessage_GUID_KEY] &&
              void 0 !==
                a[module$contents$omid$common$InternalMessage_METHOD_KEY] &&
              void 0 !==
                a[module$contents$omid$common$InternalMessage_VERSION_KEY] &&
              "string" ===
                typeof a[
                  module$contents$omid$common$InternalMessage_GUID_KEY
                ] &&
              "string" ===
                typeof a[
                  module$contents$omid$common$InternalMessage_METHOD_KEY
                ] &&
              "string" ===
                typeof a[
                  module$contents$omid$common$InternalMessage_VERSION_KEY
                ] &&
              (void 0 ===
                a[module$contents$omid$common$InternalMessage_ARGS_KEY] ||
                void 0 !==
                  a[module$contents$omid$common$InternalMessage_ARGS_KEY])
            );
          };
        module$exports$omid$common$InternalMessage.deserialize = function (a) {
          return new module$exports$omid$common$InternalMessage(
            a[module$contents$omid$common$InternalMessage_GUID_KEY],
            a[module$contents$omid$common$InternalMessage_METHOD_KEY],
            a[module$contents$omid$common$InternalMessage_VERSION_KEY],
            a[module$contents$omid$common$InternalMessage_ARGS_KEY]
          );
        };
        module$exports$omid$common$InternalMessage.prototype.serialize =
          function () {
            var a = {};
            a =
              ((a[module$contents$omid$common$InternalMessage_GUID_KEY] =
                this.guid),
              (a[module$contents$omid$common$InternalMessage_METHOD_KEY] =
                this.method),
              (a[module$contents$omid$common$InternalMessage_VERSION_KEY] =
                this.version),
              a);
            void 0 !== this.args &&
              (a[module$contents$omid$common$InternalMessage_ARGS_KEY] =
                this.args);
            return a;
          };
        var module$exports$omid$common$Communication = function (a) {
          this.to = a;
          this.communicationType_ =
            module$exports$omid$common$constants.CommunicationType.NONE;
        };
        module$exports$omid$common$Communication.prototype.sendMessage =
          function (a, b) {};
        module$exports$omid$common$Communication.prototype.handleMessage =
          function (a, b) {
            if (this.onMessage) {
              this.onMessage(a, b);
            }
          };
        module$exports$omid$common$Communication.prototype.serialize =
          function (a) {
            return JSON.stringify(a);
          };
        module$exports$omid$common$Communication.prototype.deserialize =
          function (a) {
            return JSON.parse(a);
          };
        module$exports$omid$common$Communication.prototype.isDirectCommunication =
          function () {
            return (
              this.communicationType_ ===
              module$exports$omid$common$constants.CommunicationType.DIRECT
            );
          };
        module$exports$omid$common$Communication.prototype.isCrossOrigin =
          function () {};
        var module$exports$omid$common$logger = {};
        function module$contents$omid$common$logger_error() {
          var a = $jscomp.getRestArguments.apply(0, arguments);
          module$contents$omid$common$logger_executeLog(
            function () {
              throw new (Function.prototype.bind.apply(
                Error,
                [null, "Could not complete the test successfully - "].concat(
                  $jscomp.arrayFromIterable(a)
                )
              ))();
            },
            function () {
              return console.error.apply(console, $jscomp.arrayFromIterable(a));
            }
          );
        }
        function module$contents$omid$common$logger_debug() {
          var a = $jscomp.getRestArguments.apply(0, arguments);
          module$contents$omid$common$logger_executeLog(
            function () {},
            function () {
              return console.error.apply(console, $jscomp.arrayFromIterable(a));
            }
          );
        }
        function module$contents$omid$common$logger_executeLog(a, b) {
          "undefined" !== typeof jasmine && jasmine
            ? a()
            : "undefined" !== typeof console && console && console.error && b();
        }
        module$exports$omid$common$logger.error =
          module$contents$omid$common$logger_error;
        module$exports$omid$common$logger.debug =
          module$contents$omid$common$logger_debug;
        var module$exports$omid$common$eventTypedefs = {};
        var module$exports$omid$common$version = {
          ApiVersion: "1.0",
          Version: "1.5.3-iab4563",
        };
        var module$exports$omid$common$argsChecker = {};
        function module$contents$omid$common$argsChecker_assertTruthyString(
          a,
          b
        ) {
          if (!b) {
            throw Error("Value for " + a + " is undefined, null or blank.");
          }
          if ("string" !== typeof b && !(b instanceof String)) {
            throw Error("Value for " + a + " is not a string.");
          }
          if ("" === b.trim()) {
            throw Error("Value for " + a + " is empty string.");
          }
        }
        function module$contents$omid$common$argsChecker_assertNotNullObject(
          a,
          b
        ) {
          if (null == b) {
            throw Error("Value for " + a + " is undefined or null");
          }
        }
        function module$contents$omid$common$argsChecker_assertNumber(a, b) {
          if (null == b) {
            throw Error(a + " must not be null or undefined.");
          }
          if ("number" !== typeof b || isNaN(b)) {
            throw Error("Value for " + a + " is not a number");
          }
        }
        function module$contents$omid$common$argsChecker_assertNumberBetween(
          a,
          b,
          c,
          d
        ) {
          module$contents$omid$common$argsChecker_assertNumber(a, b);
          if (b < c || b > d) {
            throw Error(
              "Value for " + a + " is outside the range [" + c + "," + d + "]"
            );
          }
        }
        function module$contents$omid$common$argsChecker_assertFunction(a, b) {
          if (!b) {
            throw Error(a + " must not be truthy.");
          }
        }
        function module$contents$omid$common$argsChecker_assertPositiveNumber(
          a,
          b
        ) {
          module$contents$omid$common$argsChecker_assertNumber(a, b);
          if (0 > b) {
            throw Error(a + " must be a positive number.");
          }
        }
        module$exports$omid$common$argsChecker.assertTruthyString =
          module$contents$omid$common$argsChecker_assertTruthyString;
        module$exports$omid$common$argsChecker.assertNotNullObject =
          module$contents$omid$common$argsChecker_assertNotNullObject;
        module$exports$omid$common$argsChecker.assertNumber =
          module$contents$omid$common$argsChecker_assertNumber;
        module$exports$omid$common$argsChecker.assertNumberBetween =
          module$contents$omid$common$argsChecker_assertNumberBetween;
        module$exports$omid$common$argsChecker.assertFunction =
          module$contents$omid$common$argsChecker_assertFunction;
        module$exports$omid$common$argsChecker.assertPositiveNumber =
          module$contents$omid$common$argsChecker_assertPositiveNumber;
        var module$exports$omid$common$VersionUtils = {},
          module$contents$omid$common$VersionUtils_SEMVER_DIGITS_NUMBER = 3;
        function module$contents$omid$common$VersionUtils_isValidVersion(a) {
          return /\d+\.\d+\.\d+(-.*)?/.test(a);
        }
        function module$contents$omid$common$VersionUtils_versionGreaterOrEqual(
          a,
          b
        ) {
          a = a.split("-")[0].split(".");
          b = b.split("-")[0].split(".");
          for (
            var c = 0;
            c < module$contents$omid$common$VersionUtils_SEMVER_DIGITS_NUMBER;
            c++
          ) {
            var d = parseInt(a[c], 10),
              e = parseInt(b[c], 10);
            if (d > e) {
              break;
            } else if (d < e) {
              return !1;
            }
          }
          return !0;
        }
        module$exports$omid$common$VersionUtils.isValidVersion =
          module$contents$omid$common$VersionUtils_isValidVersion;
        module$exports$omid$common$VersionUtils.versionGreaterOrEqual =
          module$contents$omid$common$VersionUtils_versionGreaterOrEqual;
        var module$exports$omid$common$ArgsSerDe = {},
          module$contents$omid$common$ArgsSerDe_ARGS_NOT_SERIALIZED_VERSION =
            "1.0.3";
        function module$contents$omid$common$ArgsSerDe_serializeMessageArgs(
          a,
          b
        ) {
          return module$contents$omid$common$VersionUtils_isValidVersion(a) &&
            module$contents$omid$common$VersionUtils_versionGreaterOrEqual(
              a,
              module$contents$omid$common$ArgsSerDe_ARGS_NOT_SERIALIZED_VERSION
            )
            ? b
            : JSON.stringify(b);
        }
        function module$contents$omid$common$ArgsSerDe_deserializeMessageArgs(
          a,
          b
        ) {
          return module$contents$omid$common$VersionUtils_isValidVersion(a) &&
            module$contents$omid$common$VersionUtils_versionGreaterOrEqual(
              a,
              module$contents$omid$common$ArgsSerDe_ARGS_NOT_SERIALIZED_VERSION
            )
            ? b
              ? b
              : []
            : b && "string" === typeof b
            ? JSON.parse(b)
            : [];
        }
        module$exports$omid$common$ArgsSerDe.serializeMessageArgs =
          module$contents$omid$common$ArgsSerDe_serializeMessageArgs;
        module$exports$omid$common$ArgsSerDe.deserializeMessageArgs =
          module$contents$omid$common$ArgsSerDe_deserializeMessageArgs;
        var module$exports$omid$common$guid = {};
        function module$contents$omid$common$guid_generateGuid() {
          return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(
            /[xy]/g,
            function (a) {
              var b = (16 * Math.random()) | 0;
              a = "y" === a ? ((b & 3) | 8).toString(16) : b.toString(16);
              return a;
            }
          );
        }
        module$exports$omid$common$guid.generateGuid =
          module$contents$omid$common$guid_generateGuid;
        var module$exports$omid$common$DetectOmid = {
          OMID_PRESENT_FRAME_NAME: "omid_v1_present",
          OMID_PRESENT_FRAME_NAME_WEB: "omid_v1_present_web",
          OMID_PRESENT_FRAME_NAME_APP: "omid_v1_present_app",
          getEnvironmentIframeName: function (a) {
            var b = {};
            return ((b[module$exports$omid$common$constants.Environment.APP] =
              module$exports$omid$common$DetectOmid.OMID_PRESENT_FRAME_NAME_APP),
            (b[module$exports$omid$common$constants.Environment.WEB] =
              module$exports$omid$common$DetectOmid.OMID_PRESENT_FRAME_NAME_WEB),
            b)[a];
          },
        };
        function module$contents$omid$common$DetectOmid_isIframePresent(a, b) {
          try {
            return a.frames && !!a.frames[b];
          } catch (c) {
            return !1;
          }
        }
        module$exports$omid$common$DetectOmid.isOmidPresent = function (a) {
          return [
            module$exports$omid$common$DetectOmid.OMID_PRESENT_FRAME_NAME,
            module$exports$omid$common$DetectOmid.OMID_PRESENT_FRAME_NAME_WEB,
            module$exports$omid$common$DetectOmid.OMID_PRESENT_FRAME_NAME_APP,
          ].some(function (b) {
            return module$contents$omid$common$DetectOmid_isIframePresent(a, b);
          });
        };
        module$exports$omid$common$DetectOmid.getOmidEnvironment = function (
          a
        ) {
          for (
            var b = $jscomp.makeIterator(
                Object.values(module$exports$omid$common$constants.Environment)
              ),
              c = b.next();
            !c.done;
            c = b.next()
          ) {
            c = c.value;
            var d =
              module$exports$omid$common$DetectOmid.getEnvironmentIframeName(c);
            if (module$contents$omid$common$DetectOmid_isIframePresent(a, d)) {
              return c;
            }
          }
          return null;
        };
        function module$contents$omid$common$DetectOmid_writePresenceIframe_(
          a,
          b
        ) {
          a.document.write(
            '<iframe style="display:none" id="' +
              (b + '" name="' + b + '" sandbox></iframe>')
          );
        }
        module$exports$omid$common$DetectOmid.declareOmidPresence = function (
          a,
          b
        ) {
          a.frames &&
            a.document &&
            ![
              module$exports$omid$common$DetectOmid.OMID_PRESENT_FRAME_NAME,
              module$exports$omid$common$DetectOmid.OMID_PRESENT_FRAME_NAME_WEB,
              module$exports$omid$common$DetectOmid.OMID_PRESENT_FRAME_NAME_APP,
            ].some(function (c) {
              return !!a.frames[c];
            }) &&
            (null == a.document.body &&
            module$exports$omid$common$DetectOmid.isMutationObserverAvailable_(
              a
            )
              ? module$exports$omid$common$DetectOmid.registerMutationObserver_(
                  a,
                  b
                )
              : ((b =
                  module$exports$omid$common$DetectOmid.getEnvironmentIframeName(
                    b
                  )),
                a.document.body
                  ? (module$exports$omid$common$DetectOmid.appendPresenceIframe_(
                      a,
                      module$exports$omid$common$DetectOmid.OMID_PRESENT_FRAME_NAME
                    ),
                    module$exports$omid$common$DetectOmid.appendPresenceIframe_(
                      a,
                      b
                    ))
                  : (module$contents$omid$common$DetectOmid_writePresenceIframe_(
                      a,
                      module$exports$omid$common$DetectOmid.OMID_PRESENT_FRAME_NAME
                    ),
                    module$contents$omid$common$DetectOmid_writePresenceIframe_(
                      a,
                      b
                    ))));
        };
        module$exports$omid$common$DetectOmid.appendPresenceIframe_ = function (
          a,
          b
        ) {
          var c = a.document.createElement("iframe");
          c.id = b;
          c.name = b;
          c.style.display = "none";
          c.sandbox = "";
          a.document.body.appendChild(c);
        };
        module$exports$omid$common$DetectOmid.isMutationObserverAvailable_ =
          function (a) {
            return "MutationObserver" in a;
          };
        module$exports$omid$common$DetectOmid.registerMutationObserver_ =
          function (a, b) {
            var c = new MutationObserver(function (d) {
              d.forEach(function (e) {
                "BODY" === e.addedNodes[0].nodeName &&
                  ((e =
                    module$exports$omid$common$DetectOmid.getEnvironmentIframeName(
                      b
                    )),
                  module$exports$omid$common$DetectOmid.appendPresenceIframe_(
                    a,
                    module$exports$omid$common$DetectOmid.OMID_PRESENT_FRAME_NAME
                  ),
                  module$exports$omid$common$DetectOmid.appendPresenceIframe_(
                    a,
                    e
                  ),
                  c.disconnect());
              });
            });
            c.observe(a.document.documentElement, { childList: !0 });
          };
        var module$exports$omid$common$serviceMethodUtils = {},
          module$contents$omid$common$serviceMethodUtils_ServiceMethodPrefix = {
            SESSION_SERVICE: "SessionService.",
            VERIFICATION_SERVICE: "VerificationService.",
          };
        function module$contents$omid$common$serviceMethodUtils_getPrefixedSessionServiceMethod(
          a
        ) {
          return module$contents$omid$common$serviceMethodUtils_getPrefixedMethod(
            a,
            module$contents$omid$common$serviceMethodUtils_ServiceMethodPrefix.SESSION_SERVICE
          );
        }
        function module$contents$omid$common$serviceMethodUtils_getUnprefixedSessionServiceMethod(
          a
        ) {
          return module$contents$omid$common$serviceMethodUtils_getUnprefixedMethod(
            a,
            module$contents$omid$common$serviceMethodUtils_ServiceMethodPrefix.SESSION_SERVICE
          );
        }
        function module$contents$omid$common$serviceMethodUtils_isPrefixedSessionServiceMethod(
          a
        ) {
          return (
            null !=
            module$contents$omid$common$serviceMethodUtils_getUnprefixedSessionServiceMethod(
              a
            )
          );
        }
        function module$contents$omid$common$serviceMethodUtils_getPrefixedVerificationServiceMethod(
          a
        ) {
          return module$contents$omid$common$serviceMethodUtils_getPrefixedMethod(
            a,
            module$contents$omid$common$serviceMethodUtils_ServiceMethodPrefix.VERIFICATION_SERVICE
          );
        }
        function module$contents$omid$common$serviceMethodUtils_getUnprefixedVerificationServiceMethod(
          a
        ) {
          return module$contents$omid$common$serviceMethodUtils_getUnprefixedMethod(
            a,
            module$contents$omid$common$serviceMethodUtils_ServiceMethodPrefix.VERIFICATION_SERVICE
          );
        }
        function module$contents$omid$common$serviceMethodUtils_isPrefixedVerificationServiceMethod(
          a
        ) {
          return (
            null !=
            module$contents$omid$common$serviceMethodUtils_getUnprefixedVerificationServiceMethod(
              a
            )
          );
        }
        function module$contents$omid$common$serviceMethodUtils_getPrefixedMethod(
          a,
          b
        ) {
          return b + a;
        }
        function module$contents$omid$common$serviceMethodUtils_getUnprefixedMethod(
          a,
          b
        ) {
          return (a = a.match(new RegExp("^" + b + "(.*)"))) && a[1];
        }
        module$exports$omid$common$serviceMethodUtils.getPrefixedSessionServiceMethod =
          module$contents$omid$common$serviceMethodUtils_getPrefixedSessionServiceMethod;
        module$exports$omid$common$serviceMethodUtils.getPrefixedVerificationServiceMethod =
          module$contents$omid$common$serviceMethodUtils_getPrefixedVerificationServiceMethod;
        module$exports$omid$common$serviceMethodUtils.getUnprefixedSessionServiceMethod =
          module$contents$omid$common$serviceMethodUtils_getUnprefixedSessionServiceMethod;
        module$exports$omid$common$serviceMethodUtils.getUnprefixedVerificationServiceMethod =
          module$contents$omid$common$serviceMethodUtils_getUnprefixedVerificationServiceMethod;
        module$exports$omid$common$serviceMethodUtils.isPrefixedSessionServiceMethod =
          module$contents$omid$common$serviceMethodUtils_isPrefixedSessionServiceMethod;
        module$exports$omid$common$serviceMethodUtils.isPrefixedVerificationServiceMethod =
          module$contents$omid$common$serviceMethodUtils_isPrefixedVerificationServiceMethod;
        var module$exports$omid$common$OmidGlobalProvider = {};
        function module$contents$omid$common$OmidGlobalProvider_getOmidGlobal() {
          if ("undefined" !== typeof omidGlobal && omidGlobal) {
            return omidGlobal;
          }
          if ("undefined" !== typeof global && global) {
            return global;
          }
          if ("undefined" !== typeof window && window) {
            return window;
          }
          if ("undefined" !== typeof globalThis && globalThis) {
            return globalThis;
          }
          var a = Function("return this")();
          if (a) {
            return a;
          }
          throw Error("Could not determine global object context.");
        }
        module$exports$omid$common$OmidGlobalProvider.omidGlobal =
          module$contents$omid$common$OmidGlobalProvider_getOmidGlobal();
        var module$exports$omid$common$exporter = {};
        function module$contents$omid$common$exporter_getOmidExports() {
          return "undefined" === typeof omidExports ? null : omidExports;
        }
        function module$contents$omid$common$exporter_getOrCreateName(a, b) {
          return a && (a[b] || (a[b] = {}));
        }
        function module$contents$omid$common$exporter_packageExport(a, b, c) {
          if (
            (c =
              void 0 === c
                ? module$contents$omid$common$exporter_getOmidExports()
                : c)
          ) {
            (a = a.split(".")),
              (a
                .slice(0, a.length - 1)
                .reduce(
                  module$contents$omid$common$exporter_getOrCreateName,
                  c
                )[a[a.length - 1]] = b);
          }
        }
        module$exports$omid$common$exporter.packageExport =
          module$contents$omid$common$exporter_packageExport;
        var module$exports$omid$common$windowUtils = {};
        function module$contents$omid$common$windowUtils_isValidWindow(a) {
          return null != a && "undefined" !== typeof a.top && null != a.top;
        }
        function module$contents$omid$common$windowUtils_isCrossOrigin(a) {
          if (a === module$exports$omid$common$OmidGlobalProvider.omidGlobal) {
            return !1;
          }
          try {
            if ("undefined" === typeof a.location.hostname) {
              return !0;
            }
            module$contents$omid$common$windowUtils_isSameOriginForIE(a);
          } catch (b) {
            return !0;
          }
          return !1;
        }
        function module$contents$omid$common$windowUtils_isSameOriginForIE(a) {
          return "" === a.x || "" !== a.x;
        }
        function module$contents$omid$common$windowUtils_resolveGlobalContext(
          a
        ) {
          "undefined" === typeof a &&
            "undefined" !== typeof window &&
            window &&
            (a = window);
          return module$contents$omid$common$windowUtils_isValidWindow(a)
            ? a
            : module$exports$omid$common$OmidGlobalProvider.omidGlobal;
        }
        function module$contents$omid$common$windowUtils_resolveTopWindowContext(
          a
        ) {
          return module$contents$omid$common$windowUtils_isValidWindow(a)
            ? a.top
            : module$exports$omid$common$OmidGlobalProvider.omidGlobal;
        }
        function module$contents$omid$common$windowUtils_isTopWindowAccessible(
          a
        ) {
          try {
            return a.top.location.href ? !0 : !1;
          } catch (b) {
            return !1;
          }
        }
        function module$contents$omid$common$windowUtils_removeDomElements(a) {
          a.type ===
            module$exports$omid$common$constants.AdEventType.SESSION_START &&
            ("undefined" !== typeof a.data.context.videoElement &&
              (a.data.context.videoElement =
                "Video Element (" + a.data.context.videoElement.id + ")"),
            "undefined" !== typeof a.data.context.slotElement &&
              (a.data.context.slotElement =
                "Slot Element (" + a.data.context.slotElement.id + ")"));
          return a;
        }
        function module$contents$omid$common$windowUtils_evaluatePageUrl(a) {
          if (!module$contents$omid$common$windowUtils_isValidWindow(a)) {
            return null;
          }
          try {
            var b = a.top;
            return module$contents$omid$common$windowUtils_isCrossOrigin(b)
              ? null
              : b.location.href;
          } catch (c) {
            return null;
          }
        }
        module$exports$omid$common$windowUtils.evaluatePageUrl =
          module$contents$omid$common$windowUtils_evaluatePageUrl;
        module$exports$omid$common$windowUtils.isCrossOrigin =
          module$contents$omid$common$windowUtils_isCrossOrigin;
        module$exports$omid$common$windowUtils.removeDomElements =
          module$contents$omid$common$windowUtils_removeDomElements;
        module$exports$omid$common$windowUtils.resolveGlobalContext =
          module$contents$omid$common$windowUtils_resolveGlobalContext;
        module$exports$omid$common$windowUtils.resolveTopWindowContext =
          module$contents$omid$common$windowUtils_resolveTopWindowContext;
        module$exports$omid$common$windowUtils.isTopWindowAccessible =
          module$contents$omid$common$windowUtils_isTopWindowAccessible;
        var module$exports$omid$common$DirectCommunication = function (a) {
          module$exports$omid$common$Communication.call(this, a);
          this.communicationType_ =
            module$exports$omid$common$constants.CommunicationType.DIRECT;
          this.handleExportedMessage =
            module$exports$omid$common$DirectCommunication.prototype.handleExportedMessage.bind(
              this
            );
        };
        $jscomp.inherits(
          module$exports$omid$common$DirectCommunication,
          module$exports$omid$common$Communication
        );
        module$exports$omid$common$DirectCommunication.prototype.sendMessage =
          function (a, b) {
            b = void 0 === b ? this.to : b;
            if (!b) {
              throw Error(
                "Message destination must be defined at construction time or when sending the message."
              );
            }
            b.handleExportedMessage(a.serialize(), this);
          };
        module$exports$omid$common$DirectCommunication.prototype.handleExportedMessage =
          function (a, b) {
            module$exports$omid$common$InternalMessage.isValidSerializedMessage(
              a
            ) &&
              this.handleMessage(
                module$exports$omid$common$InternalMessage.deserialize(a),
                b
              );
          };
        module$exports$omid$common$DirectCommunication.prototype.isCrossOrigin =
          function () {
            return !1;
          };
        var module$exports$omid$common$PostMessageCommunication = function (
          a,
          b
        ) {
          b =
            void 0 === b
              ? module$exports$omid$common$OmidGlobalProvider.omidGlobal
              : b;
          module$exports$omid$common$Communication.call(this, b);
          var c = this;
          this.communicationType_ =
            module$exports$omid$common$constants.CommunicationType.POST_MESSAGE;
          a.addEventListener("message", function (d) {
            if ("object" === typeof d.data) {
              var e = d.data;
              module$exports$omid$common$InternalMessage.isValidSerializedMessage(
                e
              ) &&
                ((e =
                  module$exports$omid$common$InternalMessage.deserialize(e)),
                d.source && c.handleMessage(e, d.source));
            }
          });
        };
        $jscomp.inherits(
          module$exports$omid$common$PostMessageCommunication,
          module$exports$omid$common$Communication
        );
        module$exports$omid$common$PostMessageCommunication.isCompatibleContext =
          function (a) {
            return !!(a && a.addEventListener && a.postMessage);
          };
        module$exports$omid$common$PostMessageCommunication.prototype.sendMessage =
          function (a, b) {
            b = void 0 === b ? this.to : b;
            if (!b) {
              throw Error(
                "Message destination must be defined at construction time or when sending the message."
              );
            }
            b.postMessage(a.serialize(), "*");
          };
        module$exports$omid$common$PostMessageCommunication.prototype.isCrossOrigin =
          function () {
            return this.to
              ? module$contents$omid$common$windowUtils_isCrossOrigin(this.to)
              : !0;
          };
        var module$exports$omid$common$serviceCommunication = {},
          module$contents$omid$common$serviceCommunication_EXPORTED_SESSION_COMMUNICATION_NAME =
            ["omid", "v1_SessionServiceCommunication"],
          module$contents$omid$common$serviceCommunication_EXPORTED_VERIFICATION_COMMUNICATION_NAME =
            ["omid", "v1_VerificationServiceCommunication"],
          module$contents$omid$common$serviceCommunication_EXPORTED_SERVICE_WINDOW_NAME =
            ["omidVerificationProperties", "serviceWindow"];
        function module$contents$omid$common$serviceCommunication_getValueForKeypath(
          a,
          b
        ) {
          return b.reduce(function (c, d) {
            return c && c[d];
          }, a);
        }
        function module$contents$omid$common$serviceCommunication_startServiceCommunication(
          a,
          b,
          c,
          d
        ) {
          if (!module$contents$omid$common$windowUtils_isCrossOrigin(b)) {
            try {
              var e =
                module$contents$omid$common$serviceCommunication_getValueForKeypath(
                  b,
                  c
                );
              if (e) {
                return new module$exports$omid$common$DirectCommunication(e);
              }
            } catch (f) {}
          }
          return d(b)
            ? new module$exports$omid$common$PostMessageCommunication(a, b)
            : null;
        }
        function module$contents$omid$common$serviceCommunication_startServiceCommunicationFromCandidates(
          a,
          b,
          c,
          d
        ) {
          b = $jscomp.makeIterator(b);
          for (var e = b.next(); !e.done; e = b.next()) {
            if (
              (e =
                module$contents$omid$common$serviceCommunication_startServiceCommunication(
                  a,
                  e.value,
                  c,
                  d
                ))
            ) {
              return e;
            }
          }
          return null;
        }
        function module$contents$omid$common$serviceCommunication_startSessionServiceCommunication(
          a,
          b,
          c
        ) {
          c =
            void 0 === c
              ? module$exports$omid$common$DetectOmid.isOmidPresent
              : c;
          var d = [
            a,
            module$contents$omid$common$windowUtils_resolveTopWindowContext(a),
          ];
          b && d.unshift(b);
          return module$contents$omid$common$serviceCommunication_startServiceCommunicationFromCandidates(
            a,
            d,
            module$contents$omid$common$serviceCommunication_EXPORTED_SESSION_COMMUNICATION_NAME,
            c
          );
        }
        function module$contents$omid$common$serviceCommunication_startVerificationServiceCommunication(
          a,
          b
        ) {
          b =
            void 0 === b
              ? module$exports$omid$common$DetectOmid.isOmidPresent
              : b;
          var c = [],
            d =
              module$contents$omid$common$serviceCommunication_getValueForKeypath(
                a,
                module$contents$omid$common$serviceCommunication_EXPORTED_SERVICE_WINDOW_NAME
              );
          d && c.push(d);
          c.push(
            module$contents$omid$common$windowUtils_resolveTopWindowContext(a)
          );
          return module$contents$omid$common$serviceCommunication_startServiceCommunicationFromCandidates(
            a,
            c,
            module$contents$omid$common$serviceCommunication_EXPORTED_VERIFICATION_COMMUNICATION_NAME,
            b
          );
        }
        module$exports$omid$common$serviceCommunication.startSessionServiceCommunication =
          module$contents$omid$common$serviceCommunication_startSessionServiceCommunication;
        module$exports$omid$common$serviceCommunication.startVerificationServiceCommunication =
          module$contents$omid$common$serviceCommunication_startVerificationServiceCommunication;
        var module$contents$omid$verificationClient$VerificationClient_VERIFICATION_CLIENT_VERSION =
            module$exports$omid$common$version.Version,
          module$contents$omid$verificationClient$VerificationClient_EventCallback;
        function module$contents$omid$verificationClient$VerificationClient_getThirdPartyOmid() {
          var a =
            module$exports$omid$common$OmidGlobalProvider.omidGlobal.omid3p;
          return a &&
            "function" === typeof a.registerSessionObserver &&
            "function" === typeof a.addEventListener
            ? a
            : null;
        }
        var module$exports$omid$verificationClient$VerificationClient =
          function (a) {
            if (
              (this.communication =
                a ||
                module$contents$omid$common$serviceCommunication_startVerificationServiceCommunication(
                  module$contents$omid$common$windowUtils_resolveGlobalContext()
                ))
            ) {
              this.communication.onMessage = this.handleMessage_.bind(this);
            } else {
              if (
                (a =
                  module$contents$omid$verificationClient$VerificationClient_getThirdPartyOmid())
              ) {
                this.omid3p = a;
              }
            }
            //----------this.remoteIntervals_ = this.remoteTimeouts_ = 0;
            this.callbackMap_ = {};
            this.imgCache_ = [];
            this.injectionId_ = (a =
              module$exports$omid$common$OmidGlobalProvider.omidGlobal
                .omidVerificationProperties)
              ? a.injectionId
              : void 0;
          };
        module$exports$omid$verificationClient$VerificationClient.prototype.isSupported =
          function () {
            return this.getEnvironment() !==
              module$exports$omid$common$constants.Environment.WEB ||
              this.injectionId_
              ? !(!this.communication && !this.omid3p)
              : !1;
          };
        module$exports$omid$verificationClient$VerificationClient.prototype.getEnvironment =
          function () {
            var a =
              module$contents$omid$common$windowUtils_resolveGlobalContext();
            return (
              this.injectionSource() ||
              (0, module$exports$omid$common$DetectOmid.getOmidEnvironment)(
                a
              ) ||
              (0, module$exports$omid$common$DetectOmid.getOmidEnvironment)(
                module$contents$omid$common$windowUtils_resolveTopWindowContext(
                  a
                )
              )
            );
          };
        module$exports$omid$verificationClient$VerificationClient.prototype.injectionSource =
          function () {
            var a =
              module$exports$omid$common$OmidGlobalProvider.omidGlobal
                .omidVerificationProperties;
            if (a && a.injectionSource) {
              return a.injectionSource;
            }
          };
        module$exports$omid$verificationClient$VerificationClient.prototype.registerSessionObserver =
          function (a, b) {
            module$contents$omid$common$argsChecker_assertFunction(
              "functionToExecute",
              a
            );
            this.omid3p
              ? this.omid3p.registerSessionObserver(a, b, this.injectionId_)
              : this.sendMessage_(
                  "addSessionListener",
                  a,
                  b,
                  this.injectionId_
                );
          };
        module$exports$omid$verificationClient$VerificationClient.prototype.addEventListener =
          function (a, b) {
            module$contents$omid$common$argsChecker_assertTruthyString(
              "eventType",
              a
            );
            module$contents$omid$common$argsChecker_assertFunction(
              "functionToExecute",
              b
            );
            this.omid3p
              ? this.omid3p.addEventListener(a, b, this.injectionId_)
              : this.sendMessage_("addEventListener", b, a, this.injectionId_);
          };
        module$exports$omid$verificationClient$VerificationClient.prototype.sendUrl =
          function (a, b, c) {
            module$contents$omid$common$argsChecker_assertTruthyString(
              "url",
              a
            );
            module$exports$omid$common$OmidGlobalProvider.omidGlobal.document &&
            module$exports$omid$common$OmidGlobalProvider.omidGlobal.document
              .createElement
              ? this.sendUrlWithImg_(a, b, c)
              : this.sendMessage_(
                  "sendUrl",
                  function (d) {
                    d && b ? b() : !d && c && c();
                  },
                  a
                );
          };
        module$exports$omid$verificationClient$VerificationClient.prototype.sendUrlWithImg_ =
          function (a, b, c) {
            var d = this,
              e =
                module$exports$omid$common$OmidGlobalProvider.omidGlobal.document.createElement(
                  "img"
                );
            this.imgCache_.push(e);
            var f = function (g) {
              var h = d.imgCache_.indexOf(e);
              0 <= h && d.imgCache_.splice(h, 1);
              g && g();
            };
            e.addEventListener("load", f.bind(this, b));
            e.addEventListener("error", f.bind(this, c));
            e.src = a;
          };
        module$exports$omid$verificationClient$VerificationClient.prototype.injectJavaScriptResource =
          function (a, b, c) {
            var d = this;
            module$contents$omid$common$argsChecker_assertTruthyString(
              "url",
              a
            );
            module$exports$omid$common$OmidGlobalProvider.omidGlobal.document
              ? this.injectJavascriptResourceUrlInDom_(a, b, c)
              : this.sendMessage_(
                  "injectJavaScriptResource",
                  function (e, f) {
                    e
                      ? (d.evaluateJavaScript_(f, a), b())
                      : (module$contents$omid$common$logger_error(
                          "Service failed to load JavaScript resource."
                        ),
                        c());
                  },
                  a
                );
          };
        module$exports$omid$verificationClient$VerificationClient.prototype.injectJavascriptResourceUrlInDom_ =
          function (a, b, c) {
            var d =
                module$exports$omid$common$OmidGlobalProvider.omidGlobal
                  .document,
              e = d.body;
            d = d.createElement("script");
            d.onload = b;
            d.onerror = c;
            d.src = a;
            d.type = "application/javascript";
            e.appendChild(d);
          };
        module$exports$omid$verificationClient$VerificationClient.prototype.evaluateJavaScript_ =
          function (a, b) {
            try {
              eval(a);
            } catch (c) {
              module$contents$omid$common$logger_error(
                'Error evaluating the JavaScript resource from "' + b + '".'
              );
            }
          };
        module$exports$omid$verificationClient$VerificationClient.prototype.setTimeout =
          function (a, b) {
            module$contents$omid$common$argsChecker_assertFunction(
              "functionToExecute",
              a
            );
            module$contents$omid$common$argsChecker_assertPositiveNumber(
              "timeInMillis",
              b
            );
            if (this.hasTimeoutMethods_()) {
              return module$exports$omid$common$OmidGlobalProvider.omidGlobal.setTimeout(
                a,
                b
              );
            }
            //----------var c = this.remoteTimeouts_++;
            var c =
              new Date().getTime() * 1000000 +
              Math.floor(Math.random() * 1000000);
            this.sendMessage_("setTimeout", a, c, b);
            return c;
          };
        module$exports$omid$verificationClient$VerificationClient.prototype.clearTimeout =
          function (a) {
            module$contents$omid$common$argsChecker_assertPositiveNumber(
              "timeoutId",
              a
            );
            this.hasTimeoutMethods_()
              ? module$exports$omid$common$OmidGlobalProvider.omidGlobal.clearTimeout(
                  a
                )
              : this.sendOneWayMessage_("clearTimeout", a);
          };
        module$exports$omid$verificationClient$VerificationClient.prototype.setInterval =
          function (a, b) {
            module$contents$omid$common$argsChecker_assertFunction(
              "functionToExecute",
              a
            );
            module$contents$omid$common$argsChecker_assertPositiveNumber(
              "timeInMillis",
              b
            );
            if (this.hasIntervalMethods_()) {
              return module$exports$omid$common$OmidGlobalProvider.omidGlobal.setInterval(
                a,
                b
              );
            }
            //----------var c = this.remoteIntervals_++;
            var c =
              new Date().getTime() * 1000000 +
              Math.floor(Math.random() * 1000000);
            this.sendMessage_("setInterval", a, c, b);
            return c;
          };
        module$exports$omid$verificationClient$VerificationClient.prototype.clearInterval =
          function (a) {
            module$contents$omid$common$argsChecker_assertPositiveNumber(
              "intervalId",
              a
            );
            this.hasIntervalMethods_()
              ? module$exports$omid$common$OmidGlobalProvider.omidGlobal.clearInterval(
                  a
                )
              : this.sendOneWayMessage_("clearInterval", a);
          };
        module$exports$omid$verificationClient$VerificationClient.prototype.hasTimeoutMethods_ =
          function () {
            return (
              "function" ===
                typeof module$exports$omid$common$OmidGlobalProvider.omidGlobal
                  .setTimeout &&
              "function" ===
                typeof module$exports$omid$common$OmidGlobalProvider.omidGlobal
                  .clearTimeout
            );
          };
        module$exports$omid$verificationClient$VerificationClient.prototype.hasIntervalMethods_ =
          function () {
            return (
              "function" ===
                typeof module$exports$omid$common$OmidGlobalProvider.omidGlobal
                  .setInterval &&
              "function" ===
                typeof module$exports$omid$common$OmidGlobalProvider.omidGlobal
                  .clearInterval
            );
          };
        module$exports$omid$verificationClient$VerificationClient.prototype.handleMessage_ =
          function (a, b) {
            b = a.method;
            var c = a.guid;
            a = a.args;
            if ("response" === b && this.callbackMap_[c]) {
              var d =
                module$contents$omid$common$ArgsSerDe_deserializeMessageArgs(
                  module$exports$omid$common$version.Version,
                  a
                );
              this.callbackMap_[c].apply(this, d);
            }
            "error" === b &&
              window.console &&
              module$contents$omid$common$logger_error(a);
          };
        module$exports$omid$verificationClient$VerificationClient.prototype.sendOneWayMessage_ =
          function (a) {
            var b = $jscomp.getRestArguments.apply(1, arguments);
            this.sendMessage_.apply(
              this,
              [a, null].concat($jscomp.arrayFromIterable(b))
            );
          };
        module$exports$omid$verificationClient$VerificationClient.prototype.sendMessage_ =
          function (a, b) {
            var c = $jscomp.getRestArguments.apply(2, arguments);
            if (this.communication) {
              var d = module$contents$omid$common$guid_generateGuid();
              b && (this.callbackMap_[d] = b);
              c = new module$exports$omid$common$InternalMessage(
                d,
                module$contents$omid$common$serviceMethodUtils_getPrefixedVerificationServiceMethod(
                  a
                ),
                module$exports$omid$common$version.Version,
                module$contents$omid$common$ArgsSerDe_serializeMessageArgs(
                  module$exports$omid$common$version.Version,
                  c
                )
              );
              this.communication.sendMessage(c);
            }
          };
        module$contents$omid$common$exporter_packageExport(
          "OmidVerificationClient",
          module$exports$omid$verificationClient$VerificationClient
        );
      },
      typeof exports === "undefined" ? undefined : exports
    );
  } catch (e) {
    __IntegralASDiagnosticCall("thirdparty", e);
  }

  __IASScope.isDomless = typeof window === "undefined";
  __IASOmidVerificationClient = {
    isSupported: function () {
      return false;
    },
  };

  if (typeof __IASScope.OmidVerificationClient !== "undefined") {
    try {
      __IASOmidVerificationClient = new __IASScope.OmidVerificationClient[
        "1.5.3-iab4563"
      ](); //try standard in-browser instantiation
    } catch (e) {
      try {
        __IASOmidVerificationClient = new __IASScope.OmidVerificationClient(); //try domless version which has no version
      } catch (e) {}
    }
  }

  function isStaticCampaignMonitoringTag(scriptUrl) {
    var isLegacyJloadTag = /\/jload(?:[/?#]|$)/.test(scriptUrl);
    var isStaticFwJsTag = /\/fw\.js(?:[?#]|$)/.test(scriptUrl);
    var hasCampaignMonitoringId = /(?:[?&])anId=/.test(scriptUrl);
    var hasRjssIds =
      /(?:[?&])advEntityId=/.test(scriptUrl) &&
      /(?:[?&])pubEntityId=/.test(scriptUrl);
    var hasAmtIds =
      /(?:[?&])ias_tId=/.test(scriptUrl) && /(?:[?&])ias_cId=/.test(scriptUrl);
    var isStaticCMFwJsTag =
      isStaticFwJsTag && hasCampaignMonitoringId && !hasRjssIds && !hasAmtIds;

    return isLegacyJloadTag || isStaticCMFwJsTag;
  }

  var isStaticCMTag = false;

  if (
    !__IASScope.isDomless &&
    document.currentScript &&
    document.currentScript.src
  ) {
    isStaticCMTag = isStaticCampaignMonitoringTag(document.currentScript.src);
  }

  function IASBaseTrustedTypesPolicy(scope) {
    this.policy = null;

    if (
      scope &&
      !scope.isDomless &&
      scope.trustedTypes &&
      scope.trustedTypes.createPolicy
    ) {
      try {
        this.policy = scope.trustedTypes.createPolicy(
          "IASBaseTrustedTypesPolicy",
          {
            createHTML: function (input) {
              return input;
            },
            createScriptURL: function (input) {
              return input;
            },
            createScript: function (input) {
              return input;
            },
          }
        );
      } catch (e) {}
    }

    this.createHTML = function (input) {
      return this.policy && this.policy.createHTML
        ? this.policy.createHTML(input)
        : input;
    };
    this.createScriptURL = function (input) {
      return this.policy && this.policy.createScriptURL
        ? this.policy.createScriptURL(input)
        : input;
    };
    this.createScript = function (input) {
      return this.policy && this.policy.createScript
        ? this.policy.createScript(input)
        : input;
    };
  }

  if (__IASScope && !__IASScope.iasBaseTrustedTypesPolicy) {
    __IASScope.iasBaseTrustedTypesPolicy = new IASBaseTrustedTypesPolicy(
      __IASScope
    );
  }

  __IntegralASConfig.useFIF =
    __IASScope &&
    !!__IASScope.__IntegralASUseFIF &&
    (__IntegralASConfig.mode === "jload" || isStaticCMTag);
  __IntegralASConfig.adRefreshThreshold =
    __IASScope && __IASScope.__IntegralASAdRefreshThreshold;

  __IntegralASConfig.getContextNode = function (win, topWin) {
    "use strict";

    if (__IASScope.isDomless) {
      return;
    }

    if (
      win.location &&
      win.location.href &&
      (win.location.href.includes("fw.html") ||
        win.location.href.includes("/rjsi/"))
    ) {
      return {
        dataset: {},
        parentNode: win.document.body,
        src: win.location.href,
      };
    }

    if (__IntegralASConfig.useFIF) {
      return __IASScope.frameElement; // Early exit if using FIF
    }

    if (document.currentScript) {
      return document.currentScript;
    }

    var getScripts = function (shouldSearchShadowDom) {
      var scripts = [];

      if (!shouldSearchShadowDom) {
        scripts = [...document.getElementsByTagName("script")];
      } else {
        if (!document.body) {
          return scripts;
        }

        function traverse(node) {
          if (node.tagName === "SCRIPT") {
            scripts.push(node);
          }

          var shadowRoot = node.shadowRoot;
          if (shadowRoot) {
            traverse(shadowRoot);
          }

          var children = node.children;
          for (var i = 0; i < children.length; i++) {
            traverse(children[i]);
          }
        }

        traverse(document.body);
      }

      return scripts;
    };

    var tempScript;
    var scriptUrl = __IntegralASConfig.scriptUrl;
    var shouldSearchShadowDom =
      scriptUrl && scriptUrl.includes("ias_searchshadowdom=true");
    var candidateScripts;

    // Static FWJS has no bootstrapper URL, and currentScript is unavailable in some browsers.
    if (!scriptUrl) {
      candidateScripts = getScripts(true);
      var candidateIndex = candidateScripts.length;

      while (--candidateIndex >= 0) {
        tempScript = candidateScripts[candidateIndex];

        if (
          tempScript.src &&
          tempScript.src.includes("ias_searchshadowdom=true") &&
          tempScript.getAttribute("data-ias-script-tag") === null
        ) {
          scriptUrl = tempScript.src;
          shouldSearchShadowDom = true;
          break;
        }
      }
    }

    var scripts =
      shouldSearchShadowDom && candidateScripts
        ? candidateScripts
        : getScripts(shouldSearchShadowDom);
    var result = scripts[scripts.length - 1];
    var scriptIndex = scripts.length;

    try {
      // If you encounter strange behavior with this node traversal (FWJS not selecting the expected script tag),
      // check ContextNodeHelper.js where this code is duplicated and can silently overwrite the context node later.
      while (--scriptIndex >= 0) {
        tempScript = scripts[scriptIndex];
        if (
          tempScript.src &&
          tempScript.src.indexOf(scriptUrl) === 0 &&
          tempScript.getAttribute("data-ias-script-tag") === null
        ) {
          result = tempScript;
          tempScript.setAttribute("data-ias-script-tag", "found");
          break;
        }
      }
    } catch (e) {} // TODO: maybe a jsDiagnostic?

    return result;
  };
  __IntegralASConfig.getCurrentScript = function () {
    if (document.currentScript) {
      return document.currentScript;
    }
  };

  __IntegralASConfig.contextNode = __IASScope.isDomless
    ? undefined
    : __IntegralASConfig.getContextNode(window, top);
  __IntegralASConfig.currentScript = __IASScope.isDomless
    ? undefined
    : __IntegralASConfig.getCurrentScript();

  __IntegralASConfig.perfFactory = function () {
    "use strict";

    var _marks = {};
    var START_CODE = "A";
    var END_CODE = "Z";

    function _addMark(codeName, time) {
      _marks[codeName] = time;
    }

    function mark(codeName) {
      _addMark(codeName, Math.round(__IASScope.performance.now()));
    }

    function markStart(baseName) {
      mark(baseName + START_CODE);
    }

    function markEnd(baseName) {
      mark(baseName + END_CODE);
    }

    // Returns the newest resource timing subset we use for downstream perf marks and static-fw cache classification.
    function getResourceTiming(url) {
      var entry;
      var entries;
      var resourceTiming = null;

      if (!url) {
        return resourceTiming;
      }

      entries = __IASScope.performance.getEntriesByName(url);
      if (entries && entries.length) {
        entry = entries[entries.length - 1];
        resourceTiming = {
          startTime: entry.startTime,
          responseEnd: entry.responseEnd,
          transferSize: entry.transferSize,
          encodedBodySize: entry.encodedBodySize,
          decodedBodySize: entry.decodedBodySize,
          deliveryType: entry.deliveryType,
        };
      }

      return resourceTiming;
    }

    function markResource(baseName, url) {
      var entry;

      entry = getResourceTiming(url);
      if (entry && entry.startTime > 0 && entry.responseEnd > 0) {
        _addMark(baseName + START_CODE, Math.round(entry.startTime));

        _addMark(baseName + END_CODE, Math.round(entry.responseEnd));
      }
    }

    function getData() {
      return _marks;
    }

    function getStart(baseName) {
      return _marks[baseName + START_CODE];
    }

    function getEnd(baseName) {
      return _marks[baseName + END_CODE];
    }

    function noop() {}

    function noopGetResourceTiming() {
      return null;
    }

    function setNoops() {
      _addMark = noop;
      mark = noop;
      markStart = noop;
      markEnd = noop;
      markResource = noop;
      getResourceTiming = noopGetResourceTiming;
    }

    function isFunc(obj) {
      return typeof obj === "function";
    }

    function _init() {
      var canUsePerformanceAPIs = false;
      var PERF_MARK_BOOTSTRAPPER_EXECUTION = "be";
      var PERF_MARK_BOOTSTRAPPER_SCRIPT_DOWNLOAD = "bd";
      var PERF_MARK_MAIN_SCRIPT_DOWNLOAD = "md"; // note: this code is intentionally the same as the one in globalConstants.js
      var downloadMark;

      try {
        canUsePerformanceAPIs =
          __IASScope.performance &&
          isFunc(__IASScope.performance.getEntriesByName) &&
          isFunc(__IASScope.performance.now) &&
          __IntegralASConfig.perfBirth !== null; // initialized to null or a time in jsAddOns1-birthdate.js

        if (canUsePerformanceAPIs) {
          downloadMark = __IntegralASConfig.jsDoSplit
            ? PERF_MARK_BOOTSTRAPPER_SCRIPT_DOWNLOAD
            : PERF_MARK_MAIN_SCRIPT_DOWNLOAD;

          markResource(downloadMark, __IntegralASConfig.scriptUrl); // in split mode, this captures download time for the bootstrapper script, in bundled mode, the bundled/main script
          _addMark(
            PERF_MARK_BOOTSTRAPPER_EXECUTION + START_CODE,
            Math.round(__IntegralASConfig.perfBirth)
          ); // put the birthdate that we already captured into our list of marks
          markEnd(PERF_MARK_BOOTSTRAPPER_EXECUTION); // roughly the end time of execution for the bootstrapper script in split mode, in bundled mode, end of the bootstrapper part of the script and start of the module definition part
        } else {
          setNoops();
        }
      } catch (err) {
        // TODO: remove if we never get here?
        setNoops();
        if (isFunc(__IASScope.__IntegralASDiagnosticCall)) {
          __IASScope.__IntegralASDiagnosticCall(
            "perf",
            err,
            __IntegralASConfig
          );
        }
      }
    }

    _init();

    return {
      mark: mark,
      markStart: markStart,
      markEnd: markEnd,
      markResource: markResource,
      getResourceTiming: getResourceTiming,
      getData: getData,
      getStart: getStart,
      getEnd: getEnd,
    };
  };
  __IntegralASConfig.perf = __IntegralASConfig.perfFactory();
} catch (err) {
  __IntegralASConfig = {};
  __IntegralASDiagnosticCall("bootstrapper", err);
}
__IntegralASConfig.initialize = function (e, t, n) {
  var i = {};
  if (Object.assign) e = Object.assign({}, e);
  else {
    for (var r in e) i[r] = e[r];
    e = i;
  }
  const o = ({ stringOrObject: e }) => {
    let t = null;
    if ("object" == typeof e) t = e;
    else if ("string" == typeof e)
      try {
        t = JSON.parse(e);
      } catch (e) {}
    return t;
  };
  class s {
    constructor() {
      this.logs = [];
    }
    add({ storeModelName: e, key: t, value: n, timeStamp: i }) {
      this.logs.push({ storeModelName: e, key: t, value: n, timeStamp: i });
    }
    getHistory() {
      return this.logs;
    }
    logHistory() {}
  }
  class a {
    constructor({ storeModelName: e }) {
      (this.storeModelName = e), (this.storeModelHistory = new s());
    }
    set(e, t, n = { locked: !0 }) {
      try {
        Object.defineProperty(this, e, {
          value: t,
          writable: !n.locked,
          configurable: !1,
        }),
          this.storeModelHistory.add({
            storeModelName: this.storeModelName,
            key: e,
            value: t,
            timeStamp: Date.now(),
          });
      } catch (e) {}
    }
    get(e) {
      return this[e];
    }
    getHistory() {
      return this.storeModelHistory.getHistory();
    }
    logHistory() {
      this.storeModelHistory.logHistory();
    }
  }
  class c extends a {
    constructor() {
      super({ storeModelName: "singleEventImpressionJsInfo" });
    }
    setPieces(e) {
      this.set("pieces", e, { locked: !1 });
    }
    getPieces() {
      return this.pieces;
    }
  }
  class d extends a {
    constructor({ currentWindow: e }) {
      super({ storeModelName: "trustedTypesPolicy" }),
        (this.baseTrustedTypesPolicy =
          null == e ? void 0 : e.iasBaseTrustedTypesPolicy);
    }
    createHTML(e) {
      var t, n;
      return null !==
        (n =
          null === (t = this.baseTrustedTypesPolicy) || void 0 === t
            ? void 0
            : t.createHTML(e)) && void 0 !== n
        ? n
        : e;
    }
    createScriptURL(e) {
      var t, n;
      return null !==
        (n =
          null === (t = this.baseTrustedTypesPolicy) || void 0 === t
            ? void 0
            : t.createScriptURL(e)) && void 0 !== n
        ? n
        : e;
    }
    createScript(e) {
      var t, n;
      return null !==
        (n =
          null === (t = this.baseTrustedTypesPolicy) || void 0 === t
            ? void 0
            : t.createScript(e)) && void 0 !== n
        ? n
        : e;
    }
  }
  const u = { useSingleEvent: 0 };
  class l extends a {
    constructor() {
      super({ storeModelName: "staticFeatures" }),
        (this.useSingleEvent = (function ({ percentage: e }) {
          return e > 100 * _i.random();
        })({ percentage: u.useSingleEvent }));
    }
  }
  const g = (e) =>
    !!(!0 === e || "true" === e || 1 === e) ||
    (!(!1 === e || "false" === e || 0 === e) && void 0);
  class m extends a {
    constructor({ windowObj: e, now: t, enabled: n, isDomless: i }) {
      super({ storeModelName: "mraidLifecycleTracker" }),
        (this.active = !1),
        (this.eligibility = "unknown"),
        (this.availability = "absent"),
        (this.mraidEverObserved = !1),
        (this.readyObserved = !1),
        (this.readyInferred = !1),
        (this.defaultObserved = !1),
        (this.stateChangeCount = 0),
        (this.viewableChangeCount = 0),
        (this.objectReplaced = !1),
        (this.usableTransitionObserved = !1),
        (this.usableNotifiedForCurrentBridge = !1),
        (this.readyListenerAttached = !1),
        (this.stateChangeListenerAttached = !1),
        (this.viewableChangeListenerAttached = !1),
        (this.listeners = []),
        (this.maxListeners = 20),
        (this.readyHandler = () => {
          this.runSafely("ready", () => {
            var e;
            const t = this.getTime();
            try {
              this.readyListenerAttached &&
                this.isFunction(
                  null === (e = this.mraid) || void 0 === e
                    ? void 0
                    : e.removeEventListener
                ) &&
                (this.mraid.removeEventListener("ready", this.readyHandler),
                (this.readyListenerAttached = !1));
            } catch (e) {}
            (this.readyObserved = !0),
              (this.readyTime = void 0 === this.readyTime ? t : this.readyTime),
              this.captureCapabilitiesAndState(),
              this.attachLifecycleListeners(),
              this.updateAvailability("ready_event"),
              this.notifyReady(t);
          });
        }),
        (this.stateChangeHandler = (e) => {
          this.runSafely("state_change", () => {
            const t = this.getTime(),
              n = this.normalizeState(e);
            this.stateChangeCount < 100 && (this.stateChangeCount += 1),
              (this.lastStateChangeTime = t),
              n && ((this.currentState = n), this.captureDefaultState(n, t)),
              this.captureCapabilitiesAndState(),
              this.updateAvailability("state_change"),
              this.notifyStateChange(n, t);
          });
        }),
        (this.viewableChangeHandler = (e) => {
          this.runSafely("viewable_change", () => {
            const t = this.getTime(),
              n = g(e);
            this.viewableChangeCount < 100 && (this.viewableChangeCount += 1),
              (this.lastViewableChangeTime = t),
              void 0 !== n && (this.currentViewable = n),
              this.updateAvailability("viewable_change"),
              this.notifyViewableChange(e, t);
          });
        }),
        (this.windowObj = e),
        (this.now = t),
        (this.enabled = n),
        (this.isDomless = i);
    }
    init() {
      this.runSafely("init", () => {
        this.enabled &&
          !this.isDomless &&
          ((this.active = !0),
          (this.trackerStartTime = this.getTime()),
          this.attachToCurrentMraid("initial"));
      });
    }
    confirmEligibility(e) {
      this.runSafely("eligibility", () => {
        (this.eligibility = e ? "eligible" : "ineligible"), e || this.destroy();
      });
    }
    refresh(e = "strategy") {
      this.runSafely("refresh", () => {
        if (!this.active) return;
        if (this.getWindowMraid() !== this.mraid)
          return (
            this.detachFromMraid(),
            (this.objectReplaced = void 0 !== this.mraid),
            this.objectReplaced && this.resetBridgeObservationLatches(),
            void this.attachToCurrentMraid(e)
          );
        this.captureCapabilitiesAndState(),
          this.attachReadyOrLifecycleListeners(),
          this.updateAvailability(e);
      });
    }
    refreshPending() {
      try {
        this.active &&
          "eligible" === this.eligibility &&
          "usable" !== this.availability &&
          this.refresh("viewability_loop");
      } catch (e) {}
    }
    subscribe(e) {
      try {
        this.listeners.length < this.maxListeners && this.listeners.push(e);
      } catch (e) {}
      return () => {
        try {
          const t = this.listeners.indexOf(e);
          t >= 0 && this.listeners.splice(t, 1);
        } catch (e) {}
      };
    }
    getSnapshot() {
      const e = this.isObject(this.mraid);
      return {
        active: this.active,
        eligibility: this.eligibility,
        availability: this.availability,
        mraidExists: e,
        mraidEverObserved: this.mraidEverObserved,
        getStateAvailable: e && this.isFunction(this.mraid.getState),
        addEventListenerAvailable:
          e && this.isFunction(this.mraid.addEventListener),
        removeEventListenerAvailable:
          e && this.isFunction(this.mraid.removeEventListener),
        isViewableAvailable: e && this.isFunction(this.mraid.isViewable),
        initialState: this.initialState,
        currentState: this.currentState,
        initialViewable: this.initialViewable,
        currentViewable: this.currentViewable,
        trackerStartTime: this.trackerStartTime,
        readyObserved: this.readyObserved,
        readyInferred: this.readyInferred,
        readyTime: this.readyTime,
        defaultObserved: this.defaultObserved,
        defaultTime: this.defaultTime,
        stateChangeCount: this.stateChangeCount,
        viewableChangeCount: this.viewableChangeCount,
        lastStateChangeTime: this.lastStateChangeTime,
        lastViewableChangeTime: this.lastViewableChangeTime,
        readyListenerAttached: this.readyListenerAttached,
        stateChangeListenerAttached: this.stateChangeListenerAttached,
        viewableChangeListenerAttached: this.viewableChangeListenerAttached,
        objectReplaced: this.objectReplaced,
        firstUsableTime: this.firstUsableTime,
        firstUsableSource: this.firstUsableSource,
        failureStage: this.failureStage,
      };
    }
    destroy() {
      this.runSafely("destroy", () => {
        this.detachFromMraid(),
          (this.listeners = []),
          (this.active = !1),
          (this.eligibility = "ineligible");
      });
    }
    attachToCurrentMraid(e) {
      this.runSafely("attach", () => {
        (this.mraid = this.getWindowMraid()),
          this.resetAttachmentFlags(),
          this.isObject(this.mraid)
            ? ((this.mraidEverObserved = !0),
              this.captureCapabilitiesAndState(),
              void 0 === this.initialState &&
                (this.initialState = this.currentState),
              void 0 === this.initialViewable &&
                (this.initialViewable = this.currentViewable),
              this.attachReadyOrLifecycleListeners(),
              this.updateAvailability(e))
            : this.updateAvailability(e);
      });
    }
    attachReadyOrLifecycleListeners() {
      this.runSafely("attach_listener", () => {
        if (
          this.isObject(this.mraid) &&
          this.isFunction(this.mraid.addEventListener)
        ) {
          if (
            !(
              (this.currentState && "loading" !== this.currentState) ||
              this.readyObserved ||
              this.readyInferred
            )
          )
            return (
              this.readyListenerAttached ||
                (this.mraid.addEventListener("ready", this.readyHandler),
                (this.readyListenerAttached = !0)),
              void this.attachLifecycleListeners()
            );
          (this.readyInferred = !0),
            (this.readyTime =
              void 0 === this.readyTime ? this.getTime() : this.readyTime),
            this.attachLifecycleListeners();
        }
      });
    }
    attachLifecycleListeners() {
      this.runSafely("attach_lifecycle", () => {
        if (
          this.isObject(this.mraid) &&
          this.isFunction(this.mraid.addEventListener)
        ) {
          if (!this.stateChangeListenerAttached)
            try {
              this.mraid.addEventListener(
                "stateChange",
                this.stateChangeHandler
              ),
                (this.stateChangeListenerAttached = !0);
            } catch (e) {
              this.failureStage = "attach_state_change";
            }
          if (
            !this.viewableChangeListenerAttached &&
            this.isFunction(this.mraid.isViewable)
          )
            try {
              this.mraid.addEventListener(
                "viewableChange",
                this.viewableChangeHandler
              ),
                (this.viewableChangeListenerAttached = !0);
            } catch (e) {
              this.failureStage = "attach_viewable_change";
            }
        }
      });
    }
    captureCapabilitiesAndState() {
      this.runSafely("capture_state", () => {
        if (this.isObject(this.mraid)) {
          if (this.isFunction(this.mraid.getState)) {
            const e = this.normalizeState(this.mraid.getState());
            e &&
              ((this.currentState = e),
              this.captureDefaultState(e, this.getTime()));
          }
          if (
            this.currentState &&
            "loading" !== this.currentState &&
            this.isFunction(this.mraid.isViewable)
          ) {
            const e = g(this.mraid.isViewable());
            void 0 !== e && (this.currentViewable = e);
          }
        }
      });
    }
    detachFromMraid() {
      try {
        if (
          this.isObject(this.mraid) &&
          this.isFunction(this.mraid.removeEventListener)
        ) {
          try {
            this.readyListenerAttached &&
              this.mraid.removeEventListener("ready", this.readyHandler);
          } catch (e) {}
          try {
            this.stateChangeListenerAttached &&
              this.mraid.removeEventListener(
                "stateChange",
                this.stateChangeHandler
              );
          } catch (e) {}
          try {
            this.viewableChangeListenerAttached &&
              this.mraid.removeEventListener(
                "viewableChange",
                this.viewableChangeHandler
              );
          } catch (e) {}
        }
      } catch (e) {
        this.failureStage = "detach";
      }
      this.resetAttachmentFlags();
    }
    notifyReady(e) {
      this.notify((t) => t.onReady && t.onReady(e));
    }
    notifyUsable(e, t) {
      this.notify((n) => n.onUsable && n.onUsable(e, t));
    }
    notifyStateChange(e, t) {
      this.notify((n) => n.onStateChange && n.onStateChange(e, t));
    }
    notifyViewableChange(e, t) {
      this.notify((n) => n.onViewableChange && n.onViewableChange(e, t));
    }
    notify(e) {
      try {
        const t = this.listeners.slice(0, this.maxListeners);
        for (let n = 0; n < t.length; n += 1)
          try {
            e(t[n]);
          } catch (e) {}
      } catch (e) {}
    }
    getWindowMraid() {
      try {
        return this.windowObj && this.windowObj.mraid;
      } catch (e) {
        return void (this.failureStage = "read_mraid");
      }
    }
    getTime() {
      try {
        return this.now();
      } catch (e) {
        return (this.failureStage = "time"), 0;
      }
    }
    runSafely(e, t) {
      try {
        t();
      } catch (t) {
        this.failureStage = e;
      }
    }
    resetAttachmentFlags() {
      (this.readyListenerAttached = !1),
        (this.stateChangeListenerAttached = !1),
        (this.viewableChangeListenerAttached = !1);
    }
    resetBridgeObservationLatches() {
      (this.readyObserved = !1),
        (this.readyInferred = !1),
        (this.readyTime = void 0),
        (this.defaultObserved = !1),
        (this.defaultTime = void 0),
        (this.currentState = void 0),
        (this.currentViewable = void 0),
        (this.usableNotifiedForCurrentBridge = !1);
    }
    updateAvailability(e) {
      try {
        const t = this.isObject(this.mraid);
        let n = "absent";
        if (t) {
          n =
            this.isFunction(this.mraid.getState) &&
            this.isFunction(this.mraid.isViewable) &&
            this.isFunction(this.mraid.addEventListener) &&
            this.currentState
              ? "loading" === this.currentState
                ? "loading"
                : "boolean" == typeof this.currentViewable
                ? "usable"
                : "incomplete"
              : "incomplete";
        }
        if (
          ((this.availability = n),
          "usable" === n && !this.usableNotifiedForCurrentBridge)
        ) {
          this.usableNotifiedForCurrentBridge = !0;
          const t = this.getTime();
          this.usableTransitionObserved ||
            ((this.usableTransitionObserved = !0),
            (this.firstUsableTime = t),
            (this.firstUsableSource = e)),
            this.notifyUsable(t, e);
        }
      } catch (e) {
        this.failureStage = "availability";
      }
    }
    isObject(e) {
      return "object" == typeof e && null !== e && !Array.isArray(e);
    }
    isFunction(e) {
      return "function" == typeof e;
    }
    captureDefaultState(e, t) {
      try {
        "default" === e &&
          ((this.defaultObserved = !0),
          (this.defaultTime =
            void 0 === this.defaultTime ? t : this.defaultTime));
      } catch (e) {}
    }
    normalizeState(e) {
      return "string" == typeof e && e.length > 0 ? e : void 0;
    }
  }
  const p = () => {
      let e = null;
      try {
        e =
          "string" == typeof __IASTagUrl && __IASTagUrl.length > 0
            ? __IASTagUrl
            : null;
      } catch (t) {
        e = null;
      }
      return e;
    },
    h = (e) => {
      let t;
      try {
        t = decodeURIComponent(e);
      } catch (n) {
        t = e;
      }
      return t;
    },
    f = ({ search: e }) => {
      const t = {};
      return (
        e.startsWith("?") &&
          e
            .slice(1)
            .split("&")
            .forEach((e) => {
              const n = e.indexOf("="),
                i = -1 === n ? e : e.slice(0, n),
                r = -1 === n ? "" : e.slice(n + 1);
              i && (t[h(i)] = h(r));
            }),
        t
      );
    },
    v = ({ url: e }) => {
      const t = (e.startsWith("//") ? `https:${e}` : e).match(
        /^(https?):\/\/([^/:?#]+)(:\d+)?(\/[^?#]*)?(\?[^#]*)?(#.*)?$/
      );
      if (!t) return;
      const n = t[1],
        i = t[2],
        r = t[3] ? t[3].slice(1) : "",
        o = t[4] || "/",
        s = t[5] || "",
        a = t[6] || "",
        c = r ? i + ":" + r : i,
        d = n + "://" + c,
        u = d + o + (s || "") + (a || ""),
        l = f({ search: s }),
        g = {};
      Object.defineProperties(g, {
        get: {
          enumerable: !1,
          writable: !1,
          configurable: !1,
          value: (e) =>
            Object.prototype.hasOwnProperty.call(l, e) ? l[e] : null,
        },
        has: {
          enumerable: !1,
          writable: !1,
          configurable: !1,
          value: (e) => Object.prototype.hasOwnProperty.call(l, e),
        },
        toString: {
          enumerable: !1,
          writable: !1,
          configurable: !1,
          value() {
            if (s && "?" === s.charAt(0)) return s.slice(1);
            return Object.keys(l)
              .map(
                (e) =>
                  encodeURIComponent(e) + "=" + encodeURIComponent(l[e] || "")
              )
              .join("&");
          },
        },
      });
      for (const e in l)
        if (Object.prototype.hasOwnProperty.call(l, e))
          try {
            g[e] = l[e];
          } catch (e) {}
      return {
        href: u,
        origin: d,
        protocol: n + ":",
        host: c,
        hostname: i,
        port: r,
        pathname: o,
        search: s,
        hash: a,
        searchParams: g,
      };
    },
    y = (e) =>
      "string" == typeof e && e
        ? e
            .replace(/^[?&]+/, "")
            .split("&")
            .filter(Boolean)
        : [],
    b = (e) => {
      const t = e.indexOf("="),
        n = -1 === t ? e : e.slice(0, t);
      return h(n);
    },
    w = ({ isDomless: e, contextNode: t, verificationParameters: n }) => {
      var i;
      return (({ tagStaticFwjsMacros: e, verificationStaticFwjsMacros: t }) => {
        const n = y(e),
          i = y(t);
        if (0 === n.length && 0 === i.length) return;
        const r = Object.create(null);
        for (const e of n) r[b(e)] = !0;
        const o = i.filter((e) => !r[b(e)]);
        return [...n, ...o].join("&");
      })({
        tagStaticFwjsMacros: e
          ? ie({ url: null !== (i = p()) && void 0 !== i ? i : void 0 })
          : null == t
          ? void 0
          : t.staticFwjsMacros,
        verificationStaticFwjsMacros: null == n ? void 0 : n.staticFwjsMacros,
      });
    },
    A = (e) => {
      const t = e.split("/").slice(1);
      return "/" + B({ pathParts: t }).join("/");
    };
  class I extends a {
    constructor({ contextNode: e, adTag: t }) {
      super({ storeModelName: "jsConfigRequest" }),
        (this.url = ""),
        (this.contentType = ""),
        (this.verificationParameters = {}),
        (this.contentType = ""),
        (this.contextNode = e),
        (this.adTag = t),
        this.buildRequestUrlFromParameters({ contextNode: e, adTag: t });
    }
    buildRequestUrlFromParameters({
      contextNode: e,
      omidParameters: t,
      adTag: n,
    }) {
      this.setParameters({ contextNode: e, omidParameters: t }),
        this.buildRequestUrl({ contextNode: e, adTag: n });
    }
    setParameters({ contextNode: t, omidParameters: n }) {
      if (n)
        if ("string" == typeof n)
          try {
            const e = JSON.parse(n);
            this.set("verificationParameters", e, { locked: !1 });
          } catch (e) {}
        else this.set("verificationParameters", n, { locked: !1 });
      else {
        const n = null == t ? void 0 : t.dataAttributes,
          i = (null == n ? void 0 : n.iasParameters) || e.iasParameters;
        if ("string" == typeof i)
          try {
            this.set("verificationParameters", JSON.parse(i), { locked: !1 });
          } catch (e) {}
        else
          void 0 !== i && this.set("verificationParameters", i, { locked: !1 });
      }
      this.set("contentType", this.verificationParameters.contentType || "", {
        locked: !1,
      });
    }
    buildRequestUrl({ contextNode: t, adTag: n } = {}) {
      const i = null != n ? n : this.adTag,
        r = w({
          isDomless: Xn.isDomless(),
          contextNode: t,
          verificationParameters: this.verificationParameters,
        }),
        o = (({ contextNode: t, verificationParameters: n } = {}) => {
          var i, r;
          const o = null == t ? void 0 : t.queryParameters,
            s = Xn.isDomless(),
            a = p(),
            c = s && a ? v({ url: a }) : void 0,
            d =
              (null == o ? void 0 : o.get("iasConfigHost")) ||
              (null === (i = null == c ? void 0 : c.searchParams) ||
              void 0 === i
                ? void 0
                : i.get("iasConfigHost")) ||
              void 0;
          let u = null;
          const l = null == n ? void 0 : n.config;
          if (l) u = /iasProxyPartnerId=([\d]+)/g.exec(l);
          else
            try {
              const e =
                (null === (r = null == t ? void 0 : t.srcUrl) || void 0 === r
                  ? void 0
                  : r.href) ||
                (s && null != a ? a : "") ||
                "";
              (u = /iasProxyPartnerId=([\d]+)/g.exec(e)),
                u || (u = /iasProxyPartnerId%3D([\d]+)/g.exec(e));
            } catch (e) {}
          const g = null == u ? void 0 : u[1];
          return (
            (e.proxyPartnerId = g),
            (null == n ? void 0 : n.host) ||
              d ||
              {
                37103: "https://vfw.amazon-adsystem.com/ias/ivt/j",
                2: "https://g.bing.com/p/tpv-ias",
              }[g] ||
              "https://jsconfig.adsafeprotected.com"
          );
        })({
          contextNode: t,
          verificationParameters: this.verificationParameters,
        }),
        s = (({ contextNode: e, verificationParameters: t, adTag: n } = {}) => {
          var i, r, o, s, a, c, d, u, l, g, m, h, f, y, b;
          let w = null == t ? void 0 : t.config;
          const I = Xn.isDomless();
          if (!w) {
            (null == n ? void 0 : n.tagType) === T.Jload &&
              (null == n ? void 0 : n.anId) &&
              (w = `/jload/${n.anId}`),
              (null == n ? void 0 : n.tagType) === T.Rjss &&
                (null == n ? void 0 : n.creativeDomain) &&
                (null == n ? void 0 : n.advEntityId) &&
                (null == n ? void 0 : n.pubEntityId) &&
                (null == n ? void 0 : n.creativePath) &&
                ((w = `/rjss/${n.creativeDomain}/${n.advEntityId}/${n.pubEntityId}${n.creativePath}`),
                (null == n ? void 0 : n.creativeSearch) &&
                  (w += n.creativeSearch)),
              (null == n ? void 0 : n.tagType) === T.Amt &&
                (null == n ? void 0 : n.tagId) &&
                (null == n ? void 0 : n.contractId) &&
                (w = `/amtjs?ias_tId=${n.tagId}&ias_cId=${n.contractId}`);
            try {
              const t = p();
              let n;
              if (t)
                try {
                  n = v({ url: t });
                } catch (e) {}
              const S = null == e ? void 0 : e.srcUrl,
                T = S || (I ? n : void 0),
                C =
                  I &&
                  t &&
                  n &&
                  (null === (i = null == n ? void 0 : n.pathname) ||
                  void 0 === i
                    ? void 0
                    : i.includes("/jload")),
                O =
                  I &&
                  t &&
                  n &&
                  (null === (r = null == n ? void 0 : n.href) || void 0 === r
                    ? void 0
                    : r.includes("/fwjsvid")),
                E =
                  I &&
                  t &&
                  n &&
                  (null === (o = null == n ? void 0 : n.href) || void 0 === o
                    ? void 0
                    : o.includes("/jsvid")),
                D =
                  I &&
                  t &&
                  n &&
                  (null === (s = null == n ? void 0 : n.pathname) ||
                  void 0 === s
                    ? void 0
                    : s.includes("/amtjs")),
                M =
                  I &&
                  t &&
                  n &&
                  (null === (a = null == n ? void 0 : n.pathname) ||
                  void 0 === a
                    ? void 0
                    : a.includes("/rjss")),
                x =
                  !(null === (c = null == S ? void 0 : S.href) || void 0 === c
                    ? void 0
                    : c.includes("/fw.js")) &&
                  (null === (d = null == S ? void 0 : S.href) || void 0 === d
                    ? void 0
                    : d.includes("/jload")),
                P =
                  !(null === (u = null == S ? void 0 : S.href) || void 0 === u
                    ? void 0
                    : u.includes("/fw.js")) &&
                  (null === (l = null == S ? void 0 : S.href) || void 0 === l
                    ? void 0
                    : l.includes("/fwjsvid")),
                V =
                  !(null === (g = null == S ? void 0 : S.href) || void 0 === g
                    ? void 0
                    : g.includes("/fw.js")) &&
                  (null === (m = null == S ? void 0 : S.href) || void 0 === m
                    ? void 0
                    : m.includes("/jsvid")),
                N =
                  !(null === (h = null == S ? void 0 : S.href) || void 0 === h
                    ? void 0
                    : h.includes("/fw.js")) &&
                  (null === (f = null == S ? void 0 : S.href) || void 0 === f
                    ? void 0
                    : f.includes("/amtjs")),
                k =
                  !(null === (y = null == S ? void 0 : S.href) || void 0 === y
                    ? void 0
                    : y.includes("/fw.js")) &&
                  (null === (b = null == S ? void 0 : S.href) || void 0 === b
                    ? void 0
                    : b.includes("/rjss"));
              if (C) {
                const e = null == n ? void 0 : n.searchParams,
                  t = (null == e ? void 0 : e.get("anId")) || void 0;
                t &&
                  ((w = `/jload/${t}`),
                  (null == n ? void 0 : n.search) && (w += n.search));
              } else if (O) {
                const e = null == n ? void 0 : n.pathname;
                e &&
                  ((w = A(e)),
                  (null == n ? void 0 : n.search) && (w += n.search));
              } else if (E) {
                const e = null == n ? void 0 : n.searchParams,
                  t = (null == e ? void 0 : e.get("anId")) || void 0;
                t &&
                  ((w = `/jload/${t}`),
                  (null == n ? void 0 : n.search) && (w += n.search));
              } else if (x) {
                const t = null == e ? void 0 : e.queryParameters,
                  n = null == t ? void 0 : t.get("anId");
                n && ((w = `/jload/${n}`), t && (w += `?${t.toString()}`));
              } else if (P) {
                const t = null == S ? void 0 : S.pathname;
                if (t) {
                  const n = null == e ? void 0 : e.queryParameters;
                  (w = A(t)),
                    (null == n ? void 0 : n.toString()) &&
                      (w += `?${n.toString()}`);
                }
              } else if (V) {
                const t = null == e ? void 0 : e.queryParameters,
                  n = null == t ? void 0 : t.get("anId");
                n &&
                  ((w = `/jload/${n}`),
                  (null == t ? void 0 : t.toString()) &&
                    (w += `?${t.toString()}`));
              } else if (D)
                (w = "/amtjs"),
                  (null == n ? void 0 : n.search) && (w += n.search);
              else if (N) {
                const t = null == e ? void 0 : e.queryParameters;
                (w = "/amtjs"), t && (w += `?${t.toString()}`);
              } else if (M) {
                const e = null == n ? void 0 : n.pathname;
                e &&
                  ((w = e), (null == n ? void 0 : n.search) && (w += n.search));
              } else if (k) {
                const t = null == S ? void 0 : S.pathname;
                if (t) {
                  const n = null == e ? void 0 : e.queryParameters;
                  (w = t),
                    (null == n ? void 0 : n.toString()) &&
                      (w += `?${n.toString()}`);
                }
              } else if (T) {
                const e =
                  /iasConfig=([^&#]*)/g.exec(T.href) ||
                  /config=([^&#]*)/g.exec(T.href);
                e && "string" == typeof e[1] && (w = decodeURIComponent(e[1]));
              }
            } catch (e) {}
          }
          return w;
        })({
          contextNode: t,
          verificationParameters: this.verificationParameters,
          adTag: i,
        });
      if (s) {
        const e = (({ host: e, path: t, queryParams: n }) => {
          const i = t.includes("?");
          let r = `${e}/jsconfig${t}`;
          return n && (r += `${i ? "&" : "?"}${n}`), r;
        })({ host: o, path: s, queryParams: r });
        this.set("url", e, { locked: !1 });
      }
    }
  }
  var S, T;
  !(function (e) {
    e.StaticAdsafeprotected = "static.adsafeprotected.com";
  })(S || (S = {})),
    (function (e) {
      (e.Rjss = "rjss"),
        (e.Rjsi = "rjsi"),
        (e.JsVid = "jsvid"),
        (e.FwjsVid = "fwjsvid"),
        (e.JsApi = "jsapi"),
        (e.Jload = "jload"),
        (e.Jss = "jss"),
        (e.Jsi = "jsi"),
        (e.Amt = "amtjs");
    })(T || (T = {}));
  const C = {
      Firewall: [T.Jss, T.Jsi, T.Rjss, T.Rjsi, T.FwjsVid, T.JsApi],
      CampaignMonitoring: [T.Jload, T.JsVid],
      Amt: [T.Amt],
    },
    O = ({ contextNode: e, measurementConfig: t }) => {
      let n = N({ contextNode: e, measurementConfig: t });
      return n || (n = E({ contextNode: e, measurementConfig: t })), n;
    },
    E = ({ contextNode: e, measurementConfig: t }) => {
      let n = null;
      const i = x({ contextNode: e, measurementConfig: t });
      return i && (n = D({ tagUrl: i })), n;
    },
    D = ({ tagUrl: e }) => {
      let t,
        n = null,
        i = null,
        r = null;
      try {
        (i = e ? new URL(e) : null),
          (t = null == i ? void 0 : i.pathname),
          (r = Y({ pathname: t }));
      } catch (e) {}
      return (
        i && t && "Firewall" === r && (n = z({ parsedUrl: i })),
        i && t && "CampaignMonitoring" === r && (n = $({ parsedUrl: i })),
        i && t && "Amt" === r && (n = X({ parsedUrl: i })),
        n
      );
    },
    M = ({ tagUrl: e }) => {
      let t = null;
      try {
        let n = null,
          i = null,
          r = null;
        if (
          ((n = e ? v({ url: e }) : null),
          (r = null == n ? void 0 : n.pathname),
          (i = Y({ pathname: r })),
          "/fw.js" === (null == n ? void 0 : n.pathname))
        ) {
          const e =
            n.searchParams.get("config") || n.searchParams.get("iasConfig");
          (t = j({ configPath: e })),
            t || (t = J({ queryParameters: n.searchParams }));
        } else
          n && r && "Firewall" === i
            ? (t = z({ parsedUrl: n }))
            : n && r && "CampaignMonitoring" === i
            ? (t = $({ parsedUrl: n }))
            : n && r && "Amt" === i && (t = X({ parsedUrl: n }));
      } catch (e) {}
      return t;
    },
    x = ({ contextNode: e, measurementConfig: t }) => {
      let n = null;
      const {
        currentScript: i,
        isFrameInFrame: r,
        isLegacyTagRedirectedToStatic: o,
      } = t;
      return (
        (n = r ? V({ currentScript: i }) : P({ contextNode: e })),
        n &&
          !(null == n ? void 0 : n.startsWith("http")) &&
          (n = G({ url: n })),
        n
      );
    },
    P = ({ contextNode: e }) => {
      let t = null;
      const n = null == e ? void 0 : e.src;
      return n && (t = n), t;
    },
    V = ({ currentScript: e }) => {
      let t = null;
      const n = null == e ? void 0 : e.getAttribute("src");
      return n && (t = n), t;
    },
    N = ({ contextNode: e, measurementConfig: t }) => {
      let n = null;
      const i = k({ contextNode: e, measurementConfig: t });
      return i && (n = j({ configPath: i })), n;
    },
    k = ({ contextNode: e, measurementConfig: t }) => {
      let n = null;
      const {
        isStaticMode: i,
        iasParameters: r,
        isSingleInstance: o,
        isStaticIframeTag: s,
      } = t;
      return (
        o
          ? (n = F({ iasParameters: r }))
          : (i || s) && (n = R({ contextNode: e })),
        n
      );
    },
    F = ({ iasParameters: e }) => {
      let t = null;
      if (e) {
        const n = H({ jsonOrObject: e });
        if (n) {
          const { config: e } = n;
          e && (t = e);
        }
      }
      return t;
    },
    R = ({ contextNode: e }) => {
      const t = _({ contextNode: e });
      return (null == t ? void 0 : t.config) || null;
    },
    j = ({ configPath: e }) => {
      let t = null;
      const n = (({ configPath: e }) => {
          if (!e || e.startsWith("?")) return null;
          const t = e.startsWith("/") ? e : `/${e}`,
            n = v({ url: `https://config-path.invalid${t}` });
          if (!n) return null;
          const i = { pathname: n.pathname };
          return (
            n.search.length > 1 &&
              ((i.search = n.search), (i.searchParams = n.searchParams)),
            i
          );
        })({ configPath: e }),
        i = null == n ? void 0 : n.pathname,
        r = Y({ pathname: i });
      return (
        i && "Firewall" === r && (t = z({ parsedUrl: n })),
        i && "CampaignMonitoring" === r && (t = $({ parsedUrl: n })),
        i && "Amt" === r && (t = X({ parsedUrl: n })),
        t
      );
    },
    _ = ({ contextNode: e }) => {
      let t = {};
      const n = L({ contextNode: e }),
        i = U({ contextNode: e });
      return (t = n || i), t;
    },
    L = ({ contextNode: e }) => {
      var t;
      let n = null;
      const i =
        null === (t = null == e ? void 0 : e.dataAttributes) || void 0 === t
          ? void 0
          : t.iasParameters;
      if (i) {
        const e = H({ jsonOrObject: i });
        n = (null == e ? void 0 : e.config) ? e : null;
      }
      return n;
    },
    U = ({ contextNode: e }) => {
      let t = null;
      if (null == e ? void 0 : e.queryParameters) {
        const n = q({ queryParams: e.queryParameters });
        t = (null == n ? void 0 : n.config) ? n : null;
      }
      return t;
    },
    q = ({ queryParams: e }) => ({
      config: e.get("config") || e.get("iasConfig"),
      host: e.get("host") || e.get("iasConfigHost"),
      contentType: e.get("iasConfigContentType"),
      sca: e.get("iasSca"),
      xsca: e.get("iasXsca"),
      h: e.get("iasHeight"),
      w: e.get("iasWidth"),
    }),
    W = ({
      creativeDomain: e,
      creativePath: t,
      creativeSearch: n,
      creativeHash: i,
      protocol: r = "https:",
    }) => {
      if (!e || !t) return null;
      const o = r ? (r.endsWith(":") ? r : `${r}:`) : "https:",
        s = ((e) => ("st" === e ? S.StaticAdsafeprotected : e))(e);
      return `${o}//${s}${t}${(({ creativeSearch: e }) => {
        const t = /["'<>{}[\]\\^`|\s]/,
          n = e.indexOf("?");
        if (-1 === n) return e;
        const i = e.slice(n + 1);
        if (!t.test(i)) return e;
        try {
          const r = i
            .split("&")
            .map((e) => {
              if (!t.test(e)) return e;
              const n = e.indexOf("=");
              return -1 === n
                ? encodeURIComponent(e)
                : `${encodeURIComponent(e.slice(0, n))}=${encodeURIComponent(
                    e.slice(n + 1)
                  )}`;
            })
            .join("&");
          return `${e.slice(0, n)}?${r}`;
        } catch (t) {
          return e;
        }
      })({ creativeSearch: n || "" })}${i || ""}`;
    },
    B = ({ pathParts: e }) => {
      const t = Object.values(T),
        n = new Set(t),
        i = e.findIndex((e) => n.has(e));
      let r = [...e];
      return -1 !== i && (r = e.slice(i)), r;
    },
    G = ({ url: e }) => `https:${e}`,
    H = ({ jsonOrObject: e }) => {
      let t = null;
      if ("string" == typeof e)
        try {
          t = JSON.parse(e);
        } catch (e) {}
      else t = e;
      return t;
    },
    $ = ({ parsedUrl: e }) => {
      var t;
      let n;
      const i = e.pathname.split("/").splice(1),
        r = B({ pathParts: i }),
        [o, s] = r;
      return (
        (n =
          s ||
          (null === (t = e.searchParams) || void 0 === t
            ? void 0
            : t.get("anId"))),
        { anId: n, tagType: o }
      );
    },
    z = ({ parsedUrl: e }) => {
      const t = e.search,
        n = e.pathname.split("/").splice(1),
        i = B({ pathParts: n }),
        [r, o, s, a, ...c] = i,
        d = `/${c.join("/")}`;
      return {
        tagType: r,
        advEntityId: s,
        pubEntityId: a,
        creativeDomain: o,
        creativePath: d,
        creativeUrl: W({
          creativeDomain: o,
          creativePath: d,
          creativeSearch: t,
        }),
      };
    },
    X = ({ parsedUrl: e }) => {
      var t, n;
      const i = e.pathname.split("/").splice(1),
        r = B({ pathParts: i }),
        [o] = r;
      return {
        tagType: o,
        contractId:
          (null === (t = e.searchParams) || void 0 === t
            ? void 0
            : t.get("ias_cId")) || "",
        tagId:
          (null === (n = e.searchParams) || void 0 === n
            ? void 0
            : n.get("ias_tId")) || "",
      };
    },
    Y = function ({ pathname: e }) {
      let t = null;
      const n = Object.keys(C).find((t) =>
        C[t].some((t) => (null == e ? void 0 : e.includes(t)))
      );
      return n && (t = n), t;
    },
    J = ({ queryParameters: e }) => {
      let t = null,
        n = null;
      const i = e.get("anId"),
        r = e.get("advEntityId"),
        o = e.get("pubEntityId"),
        s = e.get("creativeUrl"),
        a = e.get("ias_tId"),
        c = e.get("ias_cId"),
        d = e.get("iasWidth"),
        u = e.get("iasHeight");
      if ((i && (t = { anId: i, tagType: T.Jload }), r && o))
        if (
          ((t = {
            advEntityId: r,
            pubEntityId: o,
            creativeUrl: s,
            tagType: T.Rjss,
          }),
          s)
        ) {
          const e = v({ url: s });
          (t.creativeDomain = (null == e ? void 0 : e.hostname) || null),
            (t.creativePath = (null == e ? void 0 : e.pathname) || null),
            (t.creativeSearch = (null == e ? void 0 : e.search) || null),
            (t.creativeUrl = e
              ? W({
                  creativeDomain: e.host,
                  creativePath: e.pathname,
                  creativeSearch: e.search,
                  creativeHash: e.hash,
                  protocol: e.protocol,
                })
              : s);
        } else
          (t.creativeDomain = "st"),
            (t.creativePath = "/skeleton.js"),
            (t.creativeUrl = W({
              creativeDomain: "st",
              creativePath: "/skeleton.js",
            }));
      return (
        a && c && (t = { tagId: a, contractId: c, tagType: T.Amt }),
        (d || u) &&
          ((n = {}),
          d && (n.w = d),
          u && (n.h = u),
          t && (t.staticTagParams = n)),
        t
      );
    },
    Q = ({ contextNode: e, measurementConfig: t }) => {
      const n = null == e ? void 0 : e.queryParameters;
      return t.isStaticMode && n ? J({ queryParameters: n }) : null;
    };
  class K extends a {
    constructor({ isDomless: t, contextNode: i, measurementConfig: r }) {
      super({ storeModelName: "adTag" }),
        (this.asid = mi()),
        (this.anId = null),
        (this.pubEntityId = null),
        (this.advEntityId = null),
        (this.tagId = null),
        (this.contractId = null),
        (this.tagType = null),
        (this.creativeDomain = null),
        (this.creativePath = null),
        (this.creativeSearch = null),
        (this.creativeUrl = null),
        (this.staticTagParams = null),
        (this.isScriptAsync = !1);
      const o = (({ isDomless: e, contextNode: t, measurementConfig: n }) => {
        let i = null;
        const r = p();
        return (
          e && r && (i = M({ tagUrl: r })),
          e || i || (i = O({ contextNode: t, measurementConfig: n })),
          e || i || (i = Q({ contextNode: t, measurementConfig: n })),
          i
        );
      })({ isDomless: t, contextNode: i, measurementConfig: r });
      (this.isScriptAsync =
        !t &&
        (() => {
          let e = !1;
          try {
            const t = n.currentScript;
            e = !t || t.async || t.defer;
          } catch (e) {}
          return e;
        })()),
        (this.anId = null == o ? void 0 : o.anId),
        (this.pubEntityId = null == o ? void 0 : o.pubEntityId),
        (this.advEntityId = null == o ? void 0 : o.advEntityId),
        (this.tagId = null == o ? void 0 : o.tagId),
        (this.contractId = null == o ? void 0 : o.contractId),
        (this.tagType = (null == o ? void 0 : o.tagType) || e.mode),
        (this.creativeDomain = null == o ? void 0 : o.creativeDomain),
        (this.creativePath = null == o ? void 0 : o.creativePath),
        (this.creativeSearch = null == o ? void 0 : o.creativeSearch),
        (this.creativeUrl = null == o ? void 0 : o.creativeUrl),
        (this.staticTagParams = null == o ? void 0 : o.staticTagParams);
    }
    updateWithVerificationParameters({ verificationParameters: e }) {
      var t, n, i, r, o, s, a, c, d, u;
      const l = (({ verificationParameters: e }) => {
        let t = null,
          n = null;
        const i = H({ jsonOrObject: e });
        if (i) {
          const { config: e } = i;
          e && (t = e), t && (n = j({ configPath: t }));
        }
        return n;
      })({ verificationParameters: e });
      (this.anId =
        null !== (t = this.anId) && void 0 !== t
          ? t
          : null == l
          ? void 0
          : l.anId),
        (this.pubEntityId =
          null !== (n = this.pubEntityId) && void 0 !== n
            ? n
            : null == l
            ? void 0
            : l.pubEntityId),
        (this.advEntityId =
          null !== (i = this.advEntityId) && void 0 !== i
            ? i
            : null == l
            ? void 0
            : l.advEntityId),
        (this.tagId =
          null !== (r = this.tagId) && void 0 !== r
            ? r
            : null == l
            ? void 0
            : l.tagId),
        (this.contractId =
          null !== (o = this.contractId) && void 0 !== o
            ? o
            : null == l
            ? void 0
            : l.contractId),
        (this.tagType =
          null !== (s = this.tagType) && void 0 !== s
            ? s
            : null == l
            ? void 0
            : l.tagType),
        (this.creativeDomain =
          null !== (a = this.creativeDomain) && void 0 !== a
            ? a
            : null == l
            ? void 0
            : l.creativeDomain),
        (this.creativePath =
          null !== (c = this.creativePath) && void 0 !== c
            ? c
            : null == l
            ? void 0
            : l.creativePath),
        (this.creativeSearch =
          null !== (d = this.creativeSearch) && void 0 !== d
            ? d
            : null == l
            ? void 0
            : l.creativeSearch),
        (this.creativeUrl =
          null !== (u = this.creativeUrl) && void 0 !== u
            ? u
            : null == l
            ? void 0
            : l.creativeUrl);
    }
    updateWithResolvedJsConfig({ jsConfig: e, measurementConfig: t }) {
      t.isStaticMode &&
        !this.tagType &&
        (this.tagType = null == e ? void 0 : e.mode);
    }
  }
  class Z extends a {
    constructor({ bootstrapper: e }) {
      super({ storeModelName: "baseUrls" }),
        (this.ctvPlatformFromVp = !1),
        (this.dtBaseUrl = null == e ? void 0 : e.dtBaseURL),
        (this.cmEventBaseUrl = null == e ? void 0 : e.requrl),
        (this.fwEventBaseUrl = null == e ? void 0 : e.adsafeSrc),
        (this.mobileAppEventBaseUrl = null == e ? void 0 : e.mobFwUrl),
        (this.eventBaseUrl = this.fwEventBaseUrl || this.cmEventBaseUrl),
        (null == e ? void 0 : e.impressionBaseUrl) &&
          (this.impressionBaseUrl = e.impressionBaseUrl.replace(/\/$/, "")),
        (null == e ? void 0 : e.enrichmentBaseUrl) &&
          (this.enrichmentBaseUrl = e.enrichmentBaseUrl.replace(/\/$/, ""));
    }
    updateWithVerificationParameters({ verificationParameters: e }) {
      const t = o({ stringOrObject: e });
      if ("object" == typeof t) {
        const e = null == t ? void 0 : t.iasImpBaseUrl,
          n = null == t ? void 0 : t.iasDtBaseUrl,
          i = null == t ? void 0 : t.iasMobileAppImpBaseUrl;
        n && (this.dtBaseUrl = n),
          e &&
            ((this.cmEventBaseUrl = e),
            (this.fwEventBaseUrl = e),
            (this.eventBaseUrl = e)),
          (i || e) && (this.mobileAppEventBaseUrl = i || e),
          "ctv" === (null == t ? void 0 : t.platform) &&
            ((this.ctvPlatformFromVp = !0),
            !this.ctvImpressionUrl &&
              !this.ctvEnrichmentUrl &&
              this.impressionBaseUrl &&
              this.enrichmentBaseUrl &&
              ((this.ctvImpressionUrl =
                this.impressionBaseUrl + "/event/jsctv"),
              (this.ctvEnrichmentUrl =
                this.enrichmentBaseUrl + "/event/jsctv")));
      }
    }
    updateWithResolvedJsConfig({ jsConfig: e }) {
      this.dtBaseUrl || (this.dtBaseUrl = null == e ? void 0 : e.dtBaseURL),
        this.cmEventBaseUrl ||
          (this.cmEventBaseUrl = null == e ? void 0 : e.requrl),
        this.fwEventBaseUrl ||
          (this.fwEventBaseUrl = null == e ? void 0 : e.adsafeSrc),
        this.mobileAppEventBaseUrl ||
          (this.mobileAppEventBaseUrl = null == e ? void 0 : e.mobFwUrl),
        this.eventBaseUrl ||
          (this.eventBaseUrl = this.fwEventBaseUrl || this.cmEventBaseUrl),
        (null == e ? void 0 : e.impressionBaseUrl) &&
          (this.impressionBaseUrl ||
            (this.impressionBaseUrl = e.impressionBaseUrl.replace(/\/$/, ""))),
        (null == e ? void 0 : e.enrichmentBaseUrl) &&
          (this.enrichmentBaseUrl ||
            (this.enrichmentBaseUrl = e.enrichmentBaseUrl.replace(/\/$/, ""))),
        !this.ctvImpressionUrl &&
          !this.ctvEnrichmentUrl &&
          this.ctvPlatformFromVp &&
          this.impressionBaseUrl &&
          this.enrichmentBaseUrl &&
          ((this.ctvImpressionUrl = this.impressionBaseUrl + "/event/jsctv"),
          (this.ctvEnrichmentUrl = this.enrichmentBaseUrl + "/event/jsctv"));
    }
    isCtvSession() {
      return this.ctvPlatformFromVp;
    }
  }
  class ee extends a {
    constructor({
      isDomless: e,
      currentWindow: t,
      defaultBootstrapperConfig: n,
    }) {
      super({ storeModelName: "measurementConfig" }),
        this.setDefaultProps(),
        this.setBaseProps({ defaultBootstrapperConfig: n }),
        this.setVideoIdFromScriptUrl({
          currentScript: this.currentScript,
          isDomless: e,
        }),
        e ||
          this.setDomOnlyProps({
            currentWindow: t,
            isStaticMode: this.isStaticMode,
            currentScript: this.currentScript,
          });
    }
    setDefaultProps() {
      this.set("tagDeliveryType", "s", { locked: !1 });
    }
    setBaseProps({ defaultBootstrapperConfig: e }) {
      this.set("adRefreshThreshold", e.adRefreshThreshold),
        this.set("birthdate", e.birthdate),
        this.set("isResolved", e.isResolved, { locked: !1 }),
        this.set("perfBirth", e.perfBirth),
        this.set("staticMode", e.staticMode),
        this.set("useFIF", e.useFIF),
        this.set("currentScript", e.currentScript),
        this.set("iasParameters", e.iasParameters),
        this.set("jsDiag", !0),
        this.set("spImpJsInfoMinLength", 200),
        this.set("spImpMaxLength", 1e4),
        this.set("isStaticMode", e.staticMode, { locked: !1 }),
        this.set("isFrameInFrame", e.useFIF),
        this.set(
          "isStaticFrameInFrame",
          this.get("isStaticMode") && this.get("isFrameInFrame")
        ),
        this.setDebugProp();
    }
    setDomOnlyProps({ currentWindow: e, isStaticMode: t, currentScript: n }) {
      this.setSingleInstanceProps(),
        this.setTagDeliveryTypeProps({ currentWindow: e }),
        this.setStaticRedirectProps({ isStaticMode: t, currentScript: n });
    }
    setSingleInstanceProps() {
      try {
        this.set(
          "adSlots",
          null === top || void 0 === top ? void 0 : top.iasAdSlots,
          { locked: !1 }
        ),
          this.set(
            "isSingleInstance",
            null === top || void 0 === top ? void 0 : top.isSingleIASInstance,
            { locked: !1 }
          );
      } catch (e) {}
    }
    setTagDeliveryTypeProps({ currentWindow: e }) {
      var t, n;
      const i = (
          null ===
            (n =
              null === (t = null == e ? void 0 : e.location) || void 0 === t
                ? void 0
                : t.href) || void 0 === n
            ? void 0
            : n.includes("fw.html")
        )
          ? "i"
          : "s",
        r = i ? "i" === i : void 0,
        o = i ? "s" === i : void 0;
      this.set("tagDeliveryType", i),
        this.set("isStaticIframeTag", r, { locked: !1 }),
        this.set("isStaticScriptTag", o, { locked: !1 });
    }
    setStaticRedirectProps({ isStaticMode: e, currentScript: t }) {
      e &&
        (null == t ? void 0 : t.src) &&
        (t.src.includes("/jload") &&
          (this.set("isJloadRedirect", !0),
          this.set("isLegacyTagRedirectedToStatic", !0)),
        t.src.includes("/jsvid") &&
          (this.set("isJsvidRedirect", !0),
          this.set("isLegacyTagRedirectedToStatic", !0)),
        t.src.includes("/rjss") &&
          (this.set("isRjssRedirect", !0),
          this.set("isLegacyTagRedirectedToStatic", !0)),
        t.src.includes("/fwjsvid") &&
          (this.set("isFwjsvidRedirect", !0),
          this.set("isLegacyTagRedirectedToStatic", !0)),
        t.src.includes("/amt.js") &&
          (this.set("isAmtRedirect", !0),
          this.set("isLegacyTagRedirectedToStatic", !0)));
    }
    setDebugProp() {
      this.set("debug", !1);
    }
    setVideoIdFromScriptUrl({ currentScript: e, isDomless: t }) {
      var n;
      const i = (({ url: e }) => {
        let t;
        if (e)
          try {
            const n = v({ url: e });
            if (n) {
              const e = n.searchParams,
                i = null == e ? void 0 : e.get("videoId");
              t = null == i ? void 0 : i;
            }
          } catch (e) {}
        return t;
      })({ url: (null == e ? void 0 : e.src) || (t ? p() : null) || null });
      if (i) return void this.set("videoId", i);
      const r =
          (null === (n = null == e ? void 0 : e.dataset) || void 0 === n
            ? void 0
            : n.iasParameters) || this.iasParameters,
        s = o({ stringOrObject: r });
      null !== s &&
        "object" == typeof s &&
        "string" == typeof s.videoId &&
        this.set("videoId", s.videoId);
    }
    updateWithVerificationParameters({ verificationParameters: e }) {
      const t = o({ stringOrObject: e });
      "object" == typeof t &&
        ((null == t ? void 0 : t.iasImpBaseUrl) &&
          (this.impressionNodeType = "img"),
        (null == t ? void 0 : t.iasImpNodeType) &&
          (this.impressionNodeType = null == t ? void 0 : t.iasImpNodeType));
    }
  }
  const te = new (class {
      constructor() {
        this.eventMap = {};
      }
      on(e, t) {
        this.eventMap[e] || (this.eventMap[e] = new Set()),
          this.eventMap[e].add(t);
      }
      off(e, t) {
        this.eventMap[e] && this.eventMap[e].delete(t);
      }
      emit(e, ...t) {
        this.eventMap[e] && this.eventMap[e].forEach((e) => e(...t));
      }
    })(),
    ne = ({ url: e, paramsToStrip: t = [] }) => {
      var n;
      let i;
      if (e)
        try {
          const r =
            (null === (n = v({ url: e })) || void 0 === n
              ? void 0
              : n.search.slice(1).split("&")) || [];
          i =
            r
              .filter((e) => {
                const n = e.replace(/=.*/, ""),
                  i = h(n);
                return !t.includes(i);
              })
              .join("&") || void 0;
        } catch (e) {}
      return i;
    },
    ie = ({ url: e }) => {
      if (e && e.includes("fw.js"))
        return ne({
          url: e,
          paramsToStrip: ["config", "iasConfig", "creativeUrl"],
        });
    };
  class re extends a {
    constructor({ contextNodeElement: e }) {
      var t;
      if ((super({ storeModelName: "contextNode" }), e)) {
        const n = new URL(e.src);
        this.set("element", e),
          this.set("srcUrl", n),
          this.set("src", n.href),
          this.set("path", n.pathname),
          this.set("protocol", n.protocol),
          this.set("dataAttributes", e.dataset),
          this.set("queryParameters", n.searchParams),
          this.set(
            "staticFwjsMacros",
            (({ url: e, iasParametersStr: t }) => {
              let n = ie({ url: e.href });
              const i = o({ stringOrObject: t });
              if (null !== i && "object" == typeof i) {
                n ||
                  "string" != typeof i.staticFwjsMacros ||
                  (n = i.staticFwjsMacros);
                const e = "string" == typeof i.videoId ? i.videoId : void 0;
                if (e && !(null == n ? void 0 : n.includes("videoId="))) {
                  const t = `videoId=${e}`,
                    i = null == n ? void 0 : n.replace(/^&/, "");
                  n = i ? `${t}&${i}` : t;
                }
              }
              return n;
            })({
              url: n,
              iasParametersStr:
                null === (t = e.dataset) || void 0 === t
                  ? void 0
                  : t.iasParameters,
            })
          );
      }
    }
  }
  const oe = new (class {
    addModel(e) {
      try {
        Object.defineProperty(this, e.storeModelName, {
          value: e,
          writable: !1,
          configurable: !1,
          enumerable: !0,
        });
      } catch (e) {}
      return this[e.storeModelName];
    }
    getHistory() {
      return Object.keys(this).reduce((e, t) => {
        const n = this[t].getHistory();
        return e.concat(n);
      }, []);
    }
    logHistory() {}
  })();
  function se() {
    let t = null;
    const n = oe.measurementConfig && oe.measurementConfig.currentScript,
      i = oe.contextNode && oe.contextNode.element;
    return (
      n && n.src
        ? (t = n.src)
        : e.currentScript && e.currentScript.src
        ? (t = e.currentScript.src)
        : i && i.src
        ? (t = i.src)
        : e.contextNode && e.contextNode.src && (t = e.contextNode.src),
      t || null
    );
  }
  function ae() {
    let t, n;
    const i = oe.measurementConfig;
    e.isSplitMode &&
      ((n = e.protocol + "://" + e.sp_cdnScripts.main),
      e.perf.markResource(ft, n)),
      e.impUrl && e.perf.markResource(vt, e.impUrl),
      (t = e.perf.getData()),
      i &&
        i.isStaticMode &&
        (t = Object.assign(
          {},
          t,
          (function () {
            let t,
              n,
              i,
              r,
              o,
              s = 0,
              a = 0,
              c = "u";
            const d = se(),
              u = e.perf.getResourceTiming(d);
            return (
              u &&
                ((r = Number(u.transferSize) || 0),
                (i = Number(u.encodedBodySize) || 0),
                (t = Number(u.decodedBodySize) || 0),
                (n = u.deliveryType),
                (o = t || i),
                (a = r > 0 || i > 0 || t > 0 ? 1 : 0),
                r > 0
                  ? (c = "n")
                  : o > 0 && 0 === r
                  ? (c = "l")
                  : "cache" === n && (c = "c"),
                a || "cache" === n || (c = "u"),
                (s = "u" !== c ? 1 : 0)),
              { rt: s, bc: c }
            );
          })()
        )),
      at
        .getAggregator()
        .trigger("addThrottledProp", "im", "prf", Ze(t).toION());
  }
  function ce() {
    if (e.executedContinueMain) return;
    oe.measurementConfig.isStaticMode &&
      oe.baseUrls.updateWithResolvedJsConfig({ jsConfig: e }),
      oe.adTag.updateWithResolvedJsConfig({
        jsConfig: e,
        measurementConfig: oe.measurementConfig,
      }),
      (e.executedContinueMain = !0),
      e.perf.markStart(dt),
      yt(e).verifyContextNode();
    const t = (function () {
        let t;
        const n = {};
        e.perf.markStart(ut), sr();
        const i = at.getAggregator();
        (function () {
          const t = at.getAggregator().request("omidAdSessionContext"),
            n = t.app && t.isDisplay && !t.isWeb,
            i = e.mobFwUrl && e.mobFwUrl.indexOf("/blocking/") > -1;
          i &&
            t.isLimitedSandbox &&
            "1" === e.adWidth &&
            "1" === e.adHeight &&
            (t.isLimitedSandbox = !1);
          n && i && (t.delayingViewabilityEvents = !0);
          ("app" !== t.environment && !0 !== e.mobAppWebview) ||
            ((e.origMobOrTab = e.mobOrTab), (e.mobOrTab = !0));
        })(),
          (n.mFeatures = i.request("features")),
          n.mFeatures || (n.mFeatures = i.provide("features", ui()));
        e.integration &&
          n.mFeatures.setReportedBootstrapFeatures("intblk", "integration");
        e.autotagSizeSet &&
          n.mFeatures.setReportedBootstrapFeatures("ats", "autotagSizeSet");
        (e.encodeInvalidUrlChars =
          !Xn.isDomless() && n.mFeatures.on("encodeInvalidUrlChars")),
          i.provide("mobileApp", function () {
            return (t = t || new Us(n.mFeatures)), t;
          }),
          i.provide("context", Xn),
          (n.mBrowser = i.request("browser")),
          (n.mErrors = i.request("mErrors")),
          (n.mIds = i.request("ids")),
          (n.iOutput = Zt(i));
        i.request("mJsonp");
        (n.mComm = i.request("mComm")),
          (n.viewabilityMeasurement = new So(
            To(n.mIds),
            n.mFeatures,
            n.mBrowser
          ).create());
        (function (e, t) {
          if (e && e.queuedOutputItems)
            for (let n = 0; n < e.queuedOutputItems.length; n++)
              t.trigger(
                "addOutputItem",
                { output: e.queuedOutputItems[n].value },
                e.queuedOutputItems[n].code,
                { type: "impression" }
              );
        })(i.request("omidAdSessionContext"), i),
          (n.mAdTalk = new yr().createInstance(n.mFeatures));
        const r = Ht(),
          o = $i(i),
          s = i.provide("mPage", new Ui().createInstance());
        (n.mAncestorOrigins = i.request("ancestorOrigins")),
          (n.mPageUrls = i.request("pageUrls")),
          (n.mAncestorOrigins = Mn()),
          (n.mPageUrls = i.provide(
            "pageUrls",
            new Bi().createInstance(n.mAncestorOrigins, _i)
          ));
        const a = i.provide("mScreenEvents", zi()),
          c = li(n.mBrowser),
          d = (function (t, n) {
            const i = Xn.isVideo() && !Xn.isOmid() && !Xn.isInMobiMraidVideo();
            i &&
              (at
                .getAggregator()
                .trigger("addOutputItem", { output: "v" }, "mtp", {
                  type: "impression",
                }),
              at
                .getAggregator()
                .trigger("addOutputItem", { output: "1" }, "xmvv", {
                  type: "impression",
                }));
            const r = oe.measurementConfig,
              o = (r && r.videoId) || e.videoId;
            return i ? ua(o, t, n) : {};
          })(n.mFeatures, a);
        (n.mVideo = i.provide("video", d)), ha(va.build());
        const u = new js().createInstance(n.mErrors, c, n.mFeatures),
          l = new yn().createInstance(u, n.mErrors, s, Xn),
          g = i.provide("jobFactory", Ai());
        n.mDataTransfer = Zn(
          u,
          n.mErrors,
          n.mFeatures,
          n.mIds,
          n.iOutput,
          n.mBrowser,
          a,
          r
        );
        const m = Pn(n.mErrors, n.mFeatures, i, o);
        return (
          (n.mMode = Ri(
            m,
            n.mFeatures,
            n.viewabilityMeasurement.isImmediate()
          )),
          (n.mViewability = i.provide(
            "viewability",
            is(
              zt(),
              n.viewabilityMeasurement,
              n.mBrowser,
              n.mDataTransfer,
              n.mFeatures,
              i,
              n.iOutput,
              l,
              a,
              n.mVideo
            )
          )),
          (function (t, n, i, r) {
            const o = (function (t) {
              const n = new Go(t, Xn),
                i = new Bo(),
                r = new $o(t, Xn),
                o = Ho(t, Xn),
                s = new Yo(e, Xn, t).resolve(),
                a = [n],
                c = [];
              o.applies() && a.push(o);
              r.applies() && a.push(r);
              i.applies(t, Xn) && a.push(i);
              s.forEach(function (e) {
                a.push(new Xo(e, Xn)), c.push(e.id);
              }),
                c.length > 0 &&
                  (at
                    .getAggregator()
                    .trigger("addOutputItem", { output: c.join(".") }, "scm", {
                      type: "impression",
                    }),
                  at
                    .getAggregator()
                    .trigger("addOutputItem", { output: c }, "metricIdList", {
                      type: "u",
                      asION: !0,
                    }));
              return a;
            })(t);
            at.getAggregator().provide("viewabilityDefinitions", o);
            const s = o.map(
              (function (e, t, n, i) {
                return function (r) {
                  let o, s, a, c;
                  const d = ns(r, t),
                    u = Wo(n, e, r.rts).getCallbacks(),
                    l = Jt(
                      i.createPingJobs(
                        r.type,
                        r.timeInViewThresholds,
                        u,
                        r.metricId
                      )
                    );
                  return (
                    r.sendOtherwiseInViewSignal &&
                      ((c = ns(r, t, r.sendOtherwiseInViewSignal)),
                      (a = Jt(
                        i.createPingJobs(
                          r.type,
                          r.timeInViewThresholds,
                          u,
                          r.metricId,
                          r.sendOtherwiseInViewSignal
                        )
                      ))),
                    (r.rtsCallbacks = u),
                    "grpmMobPassThru" === r.thresholdType
                      ? (o = ts(d, r, l, Xn.isVideo()))
                      : ((o = es(d, Cn(r.minUnit), l)),
                        r.sendOtherwiseInViewSignal &&
                          ((s = es(
                            c,
                            Cn(r.minUnit),
                            a,
                            r.sendOtherwiseInViewSignal
                          )),
                          s.start())),
                    o.start(),
                    o
                  );
                };
              })(t, n, i, r)
            );
            Xn.isVideo() && new ki().init();
          })(n.mFeatures, n.mViewability, o, g),
          (n.loopDelay = Nr()),
          (n.renderDetector = Lt()),
          n.mDataTransfer.setViewabilityMod(n.mViewability),
          e.perf.markEnd(ut),
          n
        );
      })(),
      n = (function (t, n, i, r, o, s, a, c, d, u, l) {
        let g, m, p;
        try {
          new Ja({
            contextNode: e.contextNode,
            features: d,
            bootstrapper: e,
          }).start();
        } catch (e) {
          o.add("A2");
        }
        e.perf.markStart(lt),
          (e.b11 = "1" === e.adHeight && "1" === e.adWidth ? "true" : "false"),
          (e.cnod = e.contextNode ? "true" : "false"),
          at
            .getAggregator()
            .trigger(
              "addOutputItem",
              { output: oe.measurementConfig.mainBirthdate },
              "mtim",
              { type: "impression" }
            );
        const h = e.hasOwnProperty("origMobOrTab")
          ? e.origMobOrTab
          : e.mobOrTab;
        at
          .getAggregator()
          .trigger("addOutputItem", { output: h ? "1" : "0" }, "mot", {
            type: "impression",
          }),
          at
            .getAggregator()
            .trigger("addOutputItem", { output: e.app ? "1" : "0" }, "app", {
              type: "impression",
            }),
          at
            .getAggregator()
            .trigger(
              "addOutputItem",
              { output: e.mobAppWebview ? "1" : "0" },
              "maw",
              { type: "impression" }
            ),
          at
            .getAggregator()
            .trigger(
              "addOutputItem",
              { output: oe.measurementConfig.tagDeliveryType },
              "tdt",
              { type: "impression" }
            );
        const f = Nn().getUserAgent(),
          v = at.getAggregator().request("mobileApp");
        !(v && v.isMobileAppEnvironment && v.isMobileAppEnvironment()) &&
          f.indexOf("IMDb-flg") > -1 &&
          (at
            .getAggregator()
            .trigger("addOutputItem", { output: "1" }, "mapp", {
              type: "impression",
            }),
          at
            .getAggregator()
            .trigger("addOutputItem", { output: "a_imdb" }, "drul", {
              type: "impression",
            }));
        ue(i, r, d, o);
        try {
          s.isApplicable(a, u) && s.start(),
            (p = c.detectTopURL()),
            d.on("exch") && ((g = ai().createInstance(o, r)), g.parse(p)),
            (m = Fa()),
            m.isApplicable(d) && m.start(d),
            u.usesGroupMCustomMetric() && Gt(),
            l.start();
        } catch (e) {
          o.add("L");
        }
        return e.perf.markEnd(lt), p;
      })(
        t.mDataTransfer,
        t.mViewability,
        t.mAdTalk,
        t.iOutput,
        t.mErrors,
        t.mAncestorOrigins,
        t.mBrowser,
        t.mPageUrls,
        t.mFeatures,
        Xn,
        t.renderDetector
      );
    try {
      t.mFeatures.on("consentDetection") &&
        (at.getAggregator().trigger("dtEnterQueuingMode"),
        te.on("measurementStatus", ({ canSendMeasurementData: e }) => {
          e
            ? at.getAggregator().trigger("dtExitQueuingMode")
            : at.getAggregator().trigger("dtEnterQueuingMode");
        })),
        te.emit("consentDetection");
    } catch (e) {}
    !(function (t, n, i, r, o, s, a, c, d) {
      try {
        Ia(t, n, i, r, o, s, a).send(c),
          Je(d.triggerInitializationEvents) && d.triggerInitializationEvents();
      } catch (t) {
        __IntegralASDiagnosticCall("impsend", t, e);
      }
    })(
      t.mErrors,
      t.mFeatures,
      t.mIds,
      t.mMode,
      t.iOutput,
      t.mBrowser,
      t.mViewability,
      n,
      t.mVideo
    ),
      (function (t, n, i, r, o, s, a, c, d, u, l, g, m) {
        var p;
        try {
          e.perf.markStart(gt),
            (function () {
              const e = ga();
              e.start(), e.addFieldTypes(["im", "sca", "env", "xsca"]);
            })();
          try {
            if (
              (Ie(),
              "eligible" ===
                (null === (p = oe.mraidLifecycleTracker) || void 0 === p
                  ? void 0
                  : p.getSnapshot().eligibility))
            ) {
              const e = oe.mraidLifecycleTracker,
                t = () => {
                  try {
                    ke(e.getSnapshot());
                  } catch (e) {}
                };
              t(),
                e.subscribe({
                  onReady: t,
                  onStateChange: () => {
                    1 === e.getSnapshot().stateChangeCount && t();
                  },
                  onViewableChange: () => {
                    1 === e.getSnapshot().viewableChangeCount && t();
                  },
                }),
                at.getAggregator().on("altAdSessionComplete", () => {
                  try {
                    t();
                  } catch (e) {}
                });
            }
          } catch (e) {}
          Qa(m),
            (function (e, t, n, i) {
              const r = jr(e, t, n);
              r.isApplicable(i) && r.start();
            })(t, n, i, r),
            (function (e, t, n, i, r, o) {
              let s;
              e.bootstrapOn("getTpl") &&
                e.on("usetpl") &&
                ((s = xn(t, n, i, r, o)), s.init());
            })(r, o, s, a, n, c),
            (function (t, n, i, r, o, s, a, c, d) {
              let u;
              "true" !== e.minimizeCalls &&
                ((u = new Date().getTime()),
                _i.execAtEndOfThread(function () {
                  de(t, n, i, r, u, o, s, a, c, d);
                }));
            })(c, d, u, a, r, o, s, n, g),
            (function (e) {
              e && e.start && e.start();
            })(l),
            ((e, t) => {
              if (!e.isDomless()) {
                const n = _a();
                let i = ["sca", "xsca", "rsrch"];
                e && e.isAMZN() && (i = []), n.start(i, t);
              }
            })(m, r),
            En(),
            at.runTier(7),
            (function (t) {
              const n = ma();
              n.isApplicable(t) &&
                (n.start(),
                ba.recordBlockingTime(),
                e.perf.mark(mt),
                ba.setupOnLoadTracking(),
                ba.setupBrowserDelayTracking());
            })(r),
            ka(),
            e.perf.markEnd(gt);
        } catch (e) {
          a.add("E");
        }
      })(
        t.mBrowser,
        t.mIds,
        t.mViewability,
        t.mFeatures,
        t.mComm,
        t.mDataTransfer,
        t.mErrors,
        t.iOutput,
        t.loopDelay,
        t.mAdTalk,
        t.viewabilityMeasurement,
        t.mAncestorOrigins,
        Xn
      ),
      oe && oe.pageMetrics && oe.pageMetrics.sendPageMetricsData(),
      e.perf.markEnd(dt);
  }
  function de(t, n, i, r, o, s, a, c, d, u) {
    try {
      if ((e.perf.markStart(pt), e.tpiLookupURL)) {
        bi(a, c).init(e.tpiLookupURL);
      }
      Xn.isDomless() || (u.isStarted() && u.sendOriginList()),
        at.runAll(),
        _i.execAtEndOfThread(function () {
          !(function (t, n, i, r, o, s) {
            let a;
            try {
              e.perf.markStart(ht),
                (a = { output: new Date().getTime() - o }),
                t.addItem(a, "sinceFw", { type: "a" }),
                Ye(n.loopStarted()) &&
                  t.addItem({ output: n.loopStarted() }, "readyFired", {
                    type: "a",
                  }),
                e.perf.markEnd(ht),
                ae(),
                i.isApplicable(Xn) && i.sendAdTalkCall();
            } catch (e) {
              r.add("f");
            }
          })(t, n, i, r, o);
        }),
        e.perf.markEnd(pt);
    } catch (e) {
      r.add("O");
    }
  }
  function ue(e, t, n, i) {
    let r;
    try {
      e.isApplicable(Xn) &&
        (e.start(),
        t.addItem(e.getFrameMap(), "fm"),
        n.on("fm2") && t.addItem(e.getFrameMapIncludingPeerCase(), "fm2"),
        n.on("idMap") && ((r = e.getIdMap()), r && t.addItem(r, "idMap")));
    } catch (e) {
      i.add("c");
    }
  }
  const le = new Map(),
    ge = new Map();
  let me = !1,
    pe = !1;
  const he = (e) => {
      try {
        e();
      } catch (e) {}
    },
    fe = ({ fieldName: e, value: t }) => {
      he(() => {
        at.getAggregator().trigger("addThrottledProp", "im", e, t);
      });
    },
    ve = (e) =>
      !0 === e ||
      1 === e ||
      "1" === e ||
      "true" === e ||
      (!1 !== e && 0 !== e && "0" !== e && "false" !== e && void 0),
    ye = (e) => {
      const t = ve(e);
      return void 0 === t ? void 0 : t ? 1 : 0;
    },
    be = (e) =>
      null === e
        ? "null"
        : "string" == typeof e
        ? e.trim().length > 0
          ? "present"
          : "blank"
        : void 0,
    we = () => {
      try {
        const e = {};
        return (
          le.forEach((t, n) => {
            e[n] = t;
          }),
          e
        );
      } catch (e) {
        return {};
      }
    },
    Ae = (e) => {
      if (Array.isArray(e)) return e.length > 0;
      if ("string" == typeof e) {
        const t = e.trim();
        if (!t) return;
        return "[]" !== t;
      }
    },
    Ie = () => {
      he(() => {
        (pe = !0),
          ge.forEach((e, t) => fe({ fieldName: t, value: e })),
          ge.clear();
      });
    },
    Se = () => {
      he(() => {
        (me = !0), le.clear();
      });
    },
    Te = (e) =>
      null == e || "" === e
        ? "missing"
        : "string" != typeof e
        ? "unsupported"
        : "script" === e || "img" === e
        ? "supported"
        : "unknown" === e
        ? "unknown"
        : "unsupported",
    Ce = ve,
    Oe = (e) => ("string" == typeof e && e.length > 0 ? e : void 0),
    Ee = (e, t) => {
      he(() => {
        null != t &&
          "" !== t &&
          ("number" != typeof t || (t == t && t !== 1 / 0 && t !== -1 / 0)) &&
          ("string" == typeof t && (nn(t) || on(t)) && (t = sn(t)),
          me
            ? pe
              ? fe({ fieldName: e, value: t })
              : ge.set(e, t)
            : le.set(e, t));
      });
    },
    De = he,
    Me = () => we(),
    xe = () => {
      var e, t, n, i, r;
      return (
        !!(null === (e = oe.measurementConfig) || void 0 === e
          ? void 0
          : e.staticMode) &&
        !!(null === (t = oe.staticFeatures) || void 0 === t
          ? void 0
          : t.useSingleEvent) &&
        "rjss" ===
          (null === (n = oe.adTag) || void 0 === n ? void 0 : n.tagType) &&
        !(null ===
          (r =
            null === (i = oe.baseUrls) || void 0 === i
              ? void 0
              : i.isCtvSession) || void 0 === r
          ? void 0
          : r.call(i))
      );
    },
    Pe = (e) => {
      De(() => {
        Ee("seia", e), Ee("seiat", Xn.getTagTime());
      });
    },
    Ve = (e, t, n, i) => {
      De(() => {
        Ee("semeg", null == e ? void 0 : e.eligibility),
          Ee("semhv", null == e ? void 0 : e.availability),
          Ee("semus", null == e ? void 0 : e.firstUsableSource),
          Ee("semut", null == e ? void 0 : e.firstUsableTime),
          Ee("semhs", (null == e ? void 0 : e.currentState) || "missing"),
          Ee("semhu", ye(t)),
          Ee("semhf", n || "none"),
          "eligible" === (null == e ? void 0 : e.eligibility) &&
            "usable" !== e.availability &&
            Ee("semds", 1),
          Ee("semht", i),
          Ee("semhe", ye(null == e ? void 0 : e.mraidExists)),
          Ee("semhg", ye(null == e ? void 0 : e.getStateAvailable)),
          Ee("semha", ye(null == e ? void 0 : e.addEventListenerAvailable)),
          Ee("semhr", ye(null == e ? void 0 : e.removeEventListenerAvailable)),
          Ee("semhi", ye(null == e ? void 0 : e.isViewableAvailable)),
          Ee("semfs", null == e ? void 0 : e.failureStage);
      });
    },
    Ne = (e) => {
      De(() => {
        Ee("semrx", e);
      });
    },
    ke = (e) => {
      De(() => {
        e &&
          (Ee("sempa", e.availability),
          Ee("semus", e.firstUsableSource),
          Ee("semut", e.firstUsableTime),
          (e.mraidExists || e.initialState || e.objectReplaced) &&
            (Ee("semps", (null == e ? void 0 : e.currentState) || "missing"),
            Ee("semro", ye(null == e ? void 0 : e.readyObserved)),
            Ee("semri", ye(null == e ? void 0 : e.readyInferred)),
            Ee("semrt", null == e ? void 0 : e.readyTime),
            Ee("semdo", ye(null == e ? void 0 : e.defaultObserved)),
            Ee("semdt", null == e ? void 0 : e.defaultTime),
            Ee("semsc", null == e ? void 0 : e.stateChangeCount),
            Ee("semvc", null == e ? void 0 : e.viewableChangeCount),
            Ee("semst", null == e ? void 0 : e.lastStateChangeTime),
            Ee("semvt", null == e ? void 0 : e.lastViewableChangeTime),
            Ee("semrl", ye(null == e ? void 0 : e.readyListenerAttached)),
            Ee("semsl", ye(null == e ? void 0 : e.stateChangeListenerAttached)),
            Ee(
              "semvl",
              ye(null == e ? void 0 : e.viewableChangeListenerAttached)
            ),
            Ee("semlv", ye(null == e ? void 0 : e.currentViewable)),
            Ee("semor", ye(null == e ? void 0 : e.objectReplaced)),
            Ee("semfs", null == e ? void 0 : e.failureStage)));
      });
    },
    Fe = (e) => {
      De(() => {
        if (!e || "eligible" !== e.eligibility) return;
        const t = "usable" === e.availability ? "none" : e.availability;
        Ee("semtp", t),
          Ee("semus", e.firstUsableSource),
          Ee("semut", e.firstUsableTime),
          Ee("semsc", e.stateChangeCount),
          Ee("semvc", e.viewableChangeCount),
          Ee("semro", ye(e.readyObserved)),
          Ee("semdo", ye(e.defaultObserved)),
          Ee("semst", e.lastStateChangeTime),
          Ee("semvt", e.lastViewableChangeTime);
      });
    };
  function Re(t) {
    const n = t && t.sca,
      i = t && t.xsca,
      r = t && t.w,
      o = t && t.h;
    return function (t) {
      at.getAggregator().trigger(
        "addOutputItem",
        { output: Xn.getTagTime() },
        "scs",
        { type: "impression" }
      );
      let s = "string" == typeof t ? JSON.parse(t) : t;
      try {
        if (xe()) {
          const e = oe.mraidLifecycleTracker;
          null == e || e.refresh("response"),
            ke(null == e ? void 0 : e.getSnapshot());
        }
      } catch (e) {}
      try {
        if (xe()) {
          const e =
            s && "object" == typeof s.config && null !== s.config
              ? s.config
              : s;
          (a = {
            creativeUrl: s && s.creativeUrl,
            returnedNodeType: s && s.nodeType,
            serverMapp: e && e.mapp,
            deviceApp: e && e.app,
            mobileOrTablet: e && e.mobOrTab,
            mobileAppWebview: e && e.mobAppWebview,
            serverSideAppDetection: e && e.serverSideAppDetection,
          }),
            De(() => {
              Ee("secs", be(a.creativeUrl)),
                Ee("sent", Oe(a.returnedNodeType)),
                Ee("sents", Te(a.returnedNodeType)),
                Ee("sems", ye(a.serverMapp)),
                Ee("seda", ye(a.deviceApp)),
                Ee("semot", ye(a.mobileOrTablet)),
                Ee("seaw", ye(a.mobileAppWebview)),
                Ee("sesd", ye(Ae(a.serverSideAppDetection)));
            });
        }
      } catch (e) {}
      var a;
      if (
        xe() &&
        s &&
        "object" == typeof s &&
        Object.prototype.hasOwnProperty.call(s, "creativeUrl") &&
        Object.prototype.hasOwnProperty.call(s, "nodeType")
      ) {
        const { creativeUrl: e, nodeType: t } = s;
        if ("string" == typeof e && e.trim().length > 0) {
          let n,
            i = "unchanged";
          try {
            (n = decodeURIComponent(e)),
              (i = n === e ? "unchanged" : "decoded");
          } catch (t) {
            (n = e), (i = "decode_error");
          }
          const r = "img" === t ? "img" : "script",
            o = "i" === oe.measurementConfig.tagDeliveryType ? "iframe" : r;
          try {
            ((e) => {
              De(() => {
                Ee("seut", e);
              });
            })(i);
          } catch (e) {}
          try {
            at.getAggregator().trigger("addNode", o, n);
            try {
              Pe("dispatched");
            } catch (e) {}
          } catch (e) {
            try {
              Pe("exception");
            } catch (e) {}
          }
        } else
          try {
            Pe("skipped_no_creative");
          } catch (e) {}
      }
      if (
        (s &&
          "object" == typeof s &&
          Object.prototype.hasOwnProperty.call(s, "config") &&
          (s = s.config),
        Object.assign)
      )
        Object.assign(e, s);
      else for (const t in s) e[t] = s[t];
      oe.measurementConfig.set("isResolved", !0),
        (e.sp_cdnScripts = e.sp_cdnScripts || {}),
        n && (e.sp_cdnScripts.sca = n),
        i && (e.sp_cdnScripts.xsca = i),
        r && o && ((e.adWidth = r), (e.adHeight = o), (e.autotagSizeSet = !0)),
        ce();
    };
  }
  const je = "https://jsconfig.adsafeprotected.com/event",
    _e = ["config", "iasConfig"],
    Le = [
      "advEntityId",
      "pubEntityId",
      "creativeUrl",
      "format",
      "dmls",
      "ome",
      "mrd",
      "mad",
    ],
    Ue = ["adsafe_jsinfo", "adsafe_url", "adsafe_type"],
    qe = ({
      name: e,
      isDomless: t,
      queryParameters: n,
      domlessSearchParams: i,
      staticFwjsMacroParams: r,
    }) => {
      var o, s;
      let a = null;
      if (t) {
        const t = null == i ? void 0 : i[e];
        a = "string" == typeof t ? t : null;
      } else
        a =
          null !== (o = null == n ? void 0 : n.get(e)) && void 0 !== o
            ? o
            : null;
      return null !== (s = null != a ? a : null == r ? void 0 : r[e]) &&
        void 0 !== s
        ? s
        : null;
    },
    We = ({ queryParts: e, key: t, value: n }) => {
      e.push(`${encodeURIComponent(t)}=${encodeURIComponent(n)}`);
    },
    Be = /^[A-Za-z0-9._-]{1,64}$/,
    Ge = "&adsafe_jsinfo=,",
    He = (e) =>
      e.replace(/%/g, "%25").replace(/&/g, "%26").replace(/#/g, "%23"),
    $e = (e) => {
      const t = null == e ? void 0 : e.queuedOutputItems;
      if (!Array.isArray(t)) return [];
      const n = Object.create(null),
        i = [];
      for (let e = 0; e < t.length && e < 1e3; e += 1) {
        const r = t[e];
        "string" == typeof (null == r ? void 0 : r.code) &&
          0 !== r.code.length &&
          void 0 !== r.value &&
          null !== r.value &&
          (Object.prototype.hasOwnProperty.call(n, r.code) || i.push(r.code),
          (n[r.code] = String(r.value)));
      }
      return i.map((e) => `${He(e)}:${He(String(n[e]))}`);
    },
    ze = () => {
      var e, t, n, i, r, o, s, a, c;
      const d = Xn.isDomless(),
        u =
          null !==
            (t =
              null === (e = oe.jsConfigRequest) || void 0 === e
                ? void 0
                : e.contextNode) && void 0 !== t
            ? t
            : oe.contextNode,
        l = null == u ? void 0 : u.queryParameters,
        g = d
          ? (() => {
              try {
                const e = p();
                if (e) {
                  const t = v({ url: e });
                  return t ? f({ search: t.search }) : void 0;
                }
              } catch (e) {}
            })()
          : void 0,
        m = w({
          isDomless: d,
          contextNode: u,
          verificationParameters:
            null === (n = oe.jsConfigRequest) || void 0 === n
              ? void 0
              : n.verificationParameters,
        }),
        h = m ? f({ search: "?" + m }) : void 0,
        y = at.getAggregator().request("omidAdSessionContext"),
        b = (y && y.environment) || "",
        A = d ? "1" : "0",
        I = Xn.isMraid() ? "1" : "0",
        S = Gs(),
        T = Hs(),
        C = !d && oi.containsScriptTagWithSrc("mraid.js");
      try {
        const e = oe.mraidLifecycleTracker;
        null == e || e.refresh("initial_request");
        const t = null == e ? void 0 : e.getSnapshot(),
          n = null === (i = oe.adTag) || void 0 === i ? void 0 : i.creativeUrl,
          o =
            "string" == typeof n && n.trim().length > 0 ? "present" : "missing",
          s = d || null == l ? void 0 : l.get("creativeUrl");
        ((e, t, n) => {
          De(() => {
            Ee("seqcs", t),
              Ee("seqcu", n),
              Ee("semta", ye(null == e ? void 0 : e.active)),
              Ee("semia", null == e ? void 0 : e.availability),
              (null == e ? void 0 : e.mraidExists) &&
                (Ee("sepaf", 0),
                Ee("semme", 0),
                Ee("semis", (null == e ? void 0 : e.initialState) || "missing"),
                Ee("semgs", ye(null == e ? void 0 : e.getStateAvailable)),
                Ee(
                  "semae",
                  ye(null == e ? void 0 : e.addEventListenerAvailable)
                ),
                Ee(
                  "semre",
                  ye(null == e ? void 0 : e.removeEventListenerAvailable)
                ),
                Ee("semiv", ye(null == e ? void 0 : e.isViewableAvailable)),
                Ee("semvv", ye(null == e ? void 0 : e.initialViewable)),
                Ee("semt0", null == e ? void 0 : e.trackerStartTime),
                Ee("semfs", null == e ? void 0 : e.failureStage));
          });
        })(
          t,
          o,
          s
            ? "explicit"
            : "string" ==
                typeof (null === (r = oe.adTag) || void 0 === r
                  ? void 0
                  : r.creativePath) &&
              -1 !== oe.adTag.creativePath.indexOf("skeleton.js")
            ? "skeleton"
            : n
            ? "reconstructed"
            : "missing"
        );
      } catch (e) {}
      try {
        (O = {
          clientDetectionSignal: S,
          clientOmidEnvironment: b,
          clientDomless: A,
          clientMraid: I,
          clientMraidShape: T,
          clientMraidScriptTag: C,
        }),
          De(() => {
            Ee("semad", Oe(O.clientDetectionSignal) || "none"),
              Ee("seome", Oe(O.clientOmidEnvironment) || "none"),
              Ee("sedml", ye(O.clientDomless)),
              Ee("semrd", ye(O.clientMraid)),
              Ee("semsh", Oe(O.clientMraidShape) || "absent"),
              Ee("semjs", ye(O.clientMraidScriptTag));
          });
      } catch (e) {}
      var O;
      const E = at.getAggregator().request("ancestorOrigins");
      E.isApplicable(at.getAggregator().request("browser"), Xn) && E.start();
      const D = at.getAggregator().request("pageUrls").detectTopURL(),
        M =
          null !==
            (s =
              null === (o = oe.measurementConfig) || void 0 === o
                ? void 0
                : o.spImpMaxLength) && void 0 !== s
            ? s
            : 1e4,
        x =
          M -
          je.length -
          (null !==
            (c =
              null === (a = oe.measurementConfig) || void 0 === a
                ? void 0
                : a.spImpJsInfoMinLength) && void 0 !== c
            ? c
            : 200),
        P = (({
          isDomless: e,
          queryParameters: t,
          domlessSearchParams: n,
          staticFwjsMacroParams: i,
          pageUrlCandidates: r,
          domlessFlag: o,
          omidEnvironment: s,
          mraidFlag: a,
          appDetectionSignal: c,
        }) => {
          var d, u, l;
          const g = [],
            m = Object.create(null),
            p = (e) => _e.includes(e) || Le.includes(e) || Ue.includes(e),
            h = (e, t) => {
              We({ queryParts: g, key: e, value: t }), (m[e] = !0);
            };
          if (e) {
            if (n) {
              const e = 1e3,
                t = Object.keys(n);
              for (let i = 0; i < t.length && i < e; i += 1) {
                const e = t[i];
                if (p(e)) continue;
                const r = n[e];
                h(e, String(r));
              }
            }
          } else if (t) {
            const e = 1e3;
            let n = 0;
            t.forEach((t, i) => {
              n >= e || ((n += 1), p(i) || h(i, t));
            });
          }
          if (i) {
            const e = 1e3,
              t = Object.keys(i);
            for (let n = 0; n < t.length && n < e; n += 1) {
              const e = t[n];
              p(e) || m[e] || h(e, i[e]);
            }
          }
          We({
            queryParts: g,
            key: "advEntityId",
            value:
              (null === (d = oe.adTag) || void 0 === d
                ? void 0
                : d.advEntityId) || "",
          }),
            We({
              queryParts: g,
              key: "pubEntityId",
              value:
                (null === (u = oe.adTag) || void 0 === u
                  ? void 0
                  : u.pubEntityId) || "",
            }),
            We({
              queryParts: g,
              key: "creativeUrl",
              value:
                (null === (l = oe.adTag) || void 0 === l
                  ? void 0
                  : l.creativeUrl) || "",
            }),
            We({ queryParts: g, key: "format", value: "jsonp" }),
            We({ queryParts: g, key: "dmls", value: o }),
            We({ queryParts: g, key: "ome", value: s }),
            We({ queryParts: g, key: "mrd", value: a }),
            We({ queryParts: g, key: "mad", value: c });
          for (const e of r) g.push(e);
          return g;
        })({
          isDomless: d,
          queryParameters: l,
          domlessSearchParams: g,
          staticFwjsMacroParams: h,
          pageUrlCandidates: xa(D, x, je.length, !0),
          domlessFlag: A,
          omidEnvironment: b,
          mraidFlag: I,
          appDetectionSignal: S,
        }),
        V = (({
          maxUrlLength: e,
          queryParts: t,
          isDomless: n,
          queryParameters: i,
          domlessSearchParams: r,
          staticFwjsMacroParams: o,
          appDetectionSignal: s,
          omidAdSessionContext: a,
        }) => {
          var c, d, u, l;
          const g =
              (null === (c = oe.adTag) || void 0 === c ? void 0 : c.asid) || "",
            m =
              (null === (d = oe.adTag) || void 0 === d ? void 0 : d.tagType) ||
              "",
            p =
              (null === (u = oe.measurementConfig) || void 0 === u
                ? void 0
                : u.tagDeliveryType) || "",
            h = Xn.embedded.toString(),
            f = Xn.friendly.toString(),
            v = at.getAggregator().request("ids").getCacheBustId(),
            y = Ze.stringifyTriState(Li()),
            b = `mu:${e}`,
            w = at.getAggregator().request("browser"),
            A = Object.entries(w.params()).map(([e, t]) => `${e}:${String(t)}`),
            I = at.getAggregator().request("mErrors").toString(),
            S = `et:${Xn.getTagTime()}`,
            T = (e) => (null != e && Be.test(e) ? e : void 0),
            C = qe({
              name: "xmtp",
              isDomless: n,
              queryParameters: i,
              domlessSearchParams: r,
              staticFwjsMacroParams: o,
            }),
            O = "v" === C || "a" === C ? C : void 0,
            E = T(
              qe({
                name: "iasProxyPartnerId",
                isDomless: n,
                queryParameters: i,
                domlessSearchParams: r,
                staticFwjsMacroParams: o,
              })
            ),
            D = T(
              qe({
                name: "ias_xpc",
                isDomless: n,
                queryParameters: i,
                domlessSearchParams: r,
                staticFwjsMacroParams: o,
              })
            ),
            M = [
              `id:${g}`,
              `c:${v}`,
              "sse:1",
              "st:1",
              `tt:${m}`,
              "v:19.8.744",
              `em:${h}`,
              `fr:${f}`,
              `thd:${y}`,
              b,
              ...A,
              S,
            ],
            x = [
              { shouldEmit: Boolean(I), code: `e:${I}` },
              { shouldEmit: Boolean(O), code: `xmtp:${null != O ? O : ""}` },
              { shouldEmit: "a" === O, code: "vau:1" },
              { shouldEmit: Boolean(E), code: `ppi:${null != E ? E : ""}` },
              { shouldEmit: Boolean(D), code: `x_xpc:${null != D ? D : ""}` },
            ];
          for (const { shouldEmit: e, code: t } of x) e && M.push(t);
          const P = [...M],
            V = null == a ? void 0 : a.mediaType,
            N = "display" === (k = V) ? "d" : "video" === k ? "v" : "";
          var k;
          const F =
              "web" === (null == a ? void 0 : a.environment)
                ? "a_oweb"
                : "app" === (null == a ? void 0 : a.environment)
                ? s
                : "",
            R = [
              ...(F ? [`drul:${F}`] : []),
              ...(N ? [`mtp:${N}`] : []),
              ...$e(a),
              `tdt:${p}`,
            ],
            j = je.length + t.join("&").length + 1;
          let _ = Ge.length + P.join(",").length,
            L = 0;
          for (const t of R)
            j + _ + t.length + 5 <= e
              ? (P.push(t), (_ += t.length + 1))
              : (L += 1);
          return (
            P.push(`ov:${L}`),
            null === (l = oe.singleEventImpressionJsInfo) ||
              void 0 === l ||
              l.setPieces(P),
            `&adsafe_jsinfo=,${P.join(",")}`
          );
        })({
          maxUrlLength: M,
          queryParts: P,
          isDomless: d,
          queryParameters: l,
          domlessSearchParams: g,
          staticFwjsMacroParams: h,
          appDetectionSignal: S,
          omidAdSessionContext: y,
        });
      return `${je}?${P.join("&")}${V}`;
    };
  const Xe = () => {
    var e;
    (
      null === (e = oe.measurementConfig) || void 0 === e
        ? void 0
        : e.isResolved
    )
      ? ce()
      : xe()
      ? (() => {
          var e, t;
          const n =
              null === (e = oe.jsConfigRequest) || void 0 === e
                ? void 0
                : e.verificationParameters,
            i =
              null === (t = oe.jsConfigRequest) || void 0 === t
                ? void 0
                : t.contentType,
            r = ze();
          at
            .getAggregator()
            .trigger("addOutputItem", { output: Xn.getTagTime() }, "scq", {
              type: "impression",
            }),
            at
              .getAggregator()
              .trigger("addOutputItem", { output: 1 }, "scb", {
                type: "impression",
              }),
            "application/json" === i
              ? at.getAggregator().trigger("getJSON", r, Re(n))
              : at.getAggregator().trigger("jsonp", r, Re(n), !1, "cbName");
        })()
      : (() => {
          var e, t, n;
          const i =
              null === (e = oe.jsConfigRequest) || void 0 === e
                ? void 0
                : e.url,
            r =
              null === (t = oe.jsConfigRequest) || void 0 === t
                ? void 0
                : t.contentType,
            o =
              null === (n = oe.jsConfigRequest) || void 0 === n
                ? void 0
                : n.verificationParameters;
          if (i) {
            at.getAggregator().trigger(
              "addOutputItem",
              { output: Xn.getTagTime() },
              "scq",
              { type: "impression" }
            );
            const e = "cbName";
            "application/json" === r
              ? at.getAggregator().trigger("getJSON", i, Re(o))
              : at.getAggregator().trigger("jsonp", i, Re(o), !1, e);
          }
        })();
  };
  const Ye = (e) => void 0 !== e,
    Je = (e) => "function" == typeof e,
    Qe = (e) => "string" == typeof e,
    Ke = (e) => (!0 === e ? 1 : !1 === e ? 0 : "na");
  var Ze = function (e) {
      "use strict";
      return new et(e);
    },
    et = function (e) {
      "use strict";
      this.iterable = e;
    };
  (et.prototype.isObj = function (e) {
    "use strict";
    var t = "object" == typeof this.iterable,
      n = null === this.iterable,
      i = t && !n,
      r = !this.isArray() && i;
    return e ? i : r;
  }),
    (et.prototype.isArray = function () {
      "use strict";
      return this.iterable instanceof Array;
    }),
    (et.prototype.isEmpty = function (e) {
      "use strict";
      return 0 === this.keys(e).length;
    }),
    (et.prototype.each = function (e, t) {
      "use strict";
      var n = this.iterable;
      if (n.length === +n.length)
        for (var i = 0, r = n.length; i < r; ++i) e(i, n[i]);
      else for (var o in n) (n.hasOwnProperty(o) || t) && e(o, n[o]);
    }),
    (et.prototype.map = function (e, t) {
      "use strict";
      var n = [];
      return (
        this.each(function (i, r) {
          var o = e(i, r);
          (void 0 !== o || t) && (n[n.length] = o);
        }),
        n
      );
    }),
    (et.prototype.stringify = function (e, t) {
      "use strict";
      t = t || ",";
      var n = [];
      return (
        this.each(function (t, i) {
          var r = e(t, i);
          Ye(r) && n.push(r);
        }),
        n.join(t)
      );
    }),
    (et.prototype.toION = function (e, t) {
      "use strict";
      var n,
        i = "[",
        r = "]";
      return (
        (t = t || 0),
        (e = e || {}),
        ++t > 4
          ? "object"
          : !this.isObj(!0) || this.iterable.hasOwnProperty("toString")
          ? "" + this.iterable
          : (this.isArray()
              ? (n = this.map(function (n, i) {
                  return Ze(i).toION(e, t);
                }))
              : ((i = "{"),
                (r = "}"),
                (n = this.map(function (n, i) {
                  var r = "string" == typeof n && -1 !== n.indexOf("NULL"),
                    o = Ze(i).toION(e, t);
                  return r ? o : (e[n] || n) + ":" + o;
                }))),
            i + n.join(",") + r)
      );
    }),
    (et.prototype.compareTo = function (e) {
      "use strict";
      var t = !1;
      return (
        this.each(function (n, i) {
          e[n] !== i && (t || (t = {}), (t[n] = i));
        }),
        t
      );
    }),
    (et.prototype.toParams = function (e) {
      "use strict";
      return this.stringify(function (e, t) {
        return "string" == typeof e && -1 !== e.indexOf("NULL")
          ? t
          : e + ":" + t;
      }, e);
    }),
    (et.prototype._privateMixin = function (e, t, n) {
      "use strict";
      var i;
      for (i in t) Ye(t[i]) && (n || t.hasOwnProperty(i)) && (e[i] = t[i]);
      return e;
    }),
    (et.prototype.mapToObj = function (e) {
      "use strict";
      var t = {},
        n = this;
      return (
        this.each(function (i, r) {
          var o = e(i, r);
          Ze(o).isObj() && n._privateMixin(t, o);
        }),
        t
      );
    }),
    (et.prototype.mixin = function (e, t) {
      "use strict";
      return this._privateMixin(this.iterable, e, t);
    }),
    (et.prototype.find = function (e) {
      "use strict";
      var t;
      return (
        this.each(function (n, i) {
          e(n, i) && (t = i);
        }),
        t
      );
    }),
    (et.prototype.findFirst = function (e) {
      "use strict";
      var t, n;
      return (
        this.each(function (i, r) {
          !n && e(i, r) && ((t = r), (n = !0));
        }),
        t
      );
    }),
    (et.prototype.keys = function (e) {
      "use strict";
      var t = [];
      return (
        this.each(function (e) {
          t.push(e);
        }, e),
        t
      );
    }),
    (et.prototype.asStrings = function () {
      "use strict";
      var e = {};
      return (
        this.each(function (t, n) {
          e[t] = "" + n;
        }),
        e
      );
    }),
    (et.prototype.selectProperties = function (e) {
      "use strict";
      var t = {},
        n = this;
      return (
        Ze(e).each(function (e, i) {
          Ye(n.iterable[i]) && (t[i] = n.iterable[i]);
        }),
        t
      );
    }),
    (et.prototype.filter = function (e, t) {
      "use strict";
      return this.map(function (t, n) {
        var i;
        return (void 0 === e || rt(e, t, n)) && (i = n), i;
      }, t);
    }),
    (et.prototype.toArray = function () {
      "use strict";
      return this.map(function (e, t) {
        return t;
      });
    });
  const tt = (e, t) => {
      var n,
        i = e < 0,
        r =
          "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ".split(
            ""
          ),
        o = [];
      e = i ? -e : e;
      do {
        (n = e % t), o.push(r[n]), (e = (e - n) / t);
      } while (e > 0);
      return (o = o.reverse().join("")), i ? "-" + o : o;
    },
    nt = () => {},
    it = (e) => {
      var t = parseInt(e);
      return isFinite(t) || (t = -1), t;
    };
  function rt(e, ...t) {
    return Je(e) ? e.apply({}, t) : e;
  }
  const ot = (e) => Ye(e) && null !== e && !isNaN(e),
    st = (e, t) => {
      var n = {
          $: "%24",
          "[": "%5B",
          "]": "%5D",
          "{": "%7B",
          "}": "%7D",
          "|": "%7C",
        },
        i = e;
      return (
        t &&
          "string" == typeof e &&
          (i = (i = e.replace(/%(?![0-9A-F][0-9A-F])/gi, "%25")).replace(
            /\$|\[|\]|\{|\}|\|/gi,
            function (e) {
              return n[e];
            }
          )),
        i
      );
    };
  (Ze.toBase = tt),
    (Ze.isDef = Ye),
    (Ze.noop = nt),
    (Ze.isFunction = Je),
    (Ze.isStr = Qe),
    (Ze.stringifyTriState = Ke),
    (Ze.getNum = it),
    (Ze.resolve = rt),
    (Ze.isNumeric = ot),
    (Ze.encodeInvalidUrlChars = st);
  const at = (function () {
      "use strict";
      let e,
        t = {},
        n = [],
        i = [];
      const r = function (...e) {
          const t = {},
            n = Ze(arguments).toArray();
          return n.unshift(t), i.push(n), t;
        },
        o = function (i, r, o, s, a) {
          let c, d;
          a = a || {};
          const u = function () {
            if (!c) {
              let r = [];
              const u = !0;
              (c = !0),
                (t = ["features", "browser", "context"]),
                0 === n.length &&
                  (n = Ze(t).map(function (t, n) {
                    return e.request(n);
                  })),
                a.emits && (i.events = new zt()),
                (a.applies && !a.applies.apply(a, n)) ||
                  ((d = !0),
                  (r = Ze(o).map(function (t, n) {
                    return e.request(n);
                  }, u)),
                  r.push(i),
                  Ze(i).mixin(s.apply({}, r)));
            }
            var t;
          };
          return (
            (function () {
              const e = a.tier;
              Ye(e) && ((t[e] = t[e] || new Yt()), t[e].push(u));
            })(),
            e.provide(r, function () {
              let e;
              return u(), d && (e = i), e;
            }),
            i
          );
        };
      return (
        (r.runAll = function () {
          const e = Ze(t)
            .keys()
            .sort(function (e, t) {
              return e - t;
            });
          Ze(e).each(function (e, t) {
            r.runTier(t);
          });
        }),
        (r.runTier = function (e) {
          t[e].run(), delete t[e];
        }),
        (r.startSystem = function () {
          (e = e || new $t()),
            Ze(i).each(function (e, t) {
              o.apply({}, t);
            });
        }),
        (r.getAggregator = function () {
          return e;
        }),
        r
      );
    })(),
    ct = "mf",
    dt = "cm",
    ut = "in",
    lt = "pr",
    gt = "po",
    mt = "bl",
    pt = "lo",
    ht = "lt",
    ft = "md",
    vt = "id";
  const yt = function (e) {
      "use strict";
      return {
        verifyContextNode: function () {
          !(
            __IASScope.isDomless ||
            (e.contextNode && null !== e.contextNode.parentNode)
          ) &&
            (e.contextNode = (function () {
              let t;
              const i = n.getElementsByTagName("script");
              let r = i.length,
                o = i[r - 1];
              const s = e.scriptUrl;
              try {
                for (; --r >= 0; )
                  if (
                    ((t = i[r]),
                    t.src &&
                      0 === t.src.indexOf(s) &&
                      null === t.getAttribute("data-ias-script-tag"))
                  ) {
                    (o = t), t.setAttribute("data-ias-script-tag", "found");
                    break;
                  }
              } catch (e) {}
              return o;
            })());
        },
      };
    },
    bt = {
      getMessageHandler: (e, t) => {
        const n = bt.getCallId(),
          i = (r) => {
            try {
              r &&
                r.data &&
                r.data[e] &&
                r.data[e].callId === n &&
                r.data[e].returnValue &&
                (t(r.data[e].returnValue),
                Jn.removeEvent(_i.getWindow(), "message", i));
            } catch (e) {
              at.getAggregator().trigger("error", "g");
            }
          };
        return i;
      },
      getCallId: () => "ias_" + (oe.adTag && oe.adTag.asid),
      send: (e, t) => {
        at.getAggregator().trigger("addThrottledProp", "env", e, t);
      },
    },
    wt = {
      name: "CCPAConsentDetector",
      dependencies: [],
      creator: function () {
        "use strict";
        const e = (e) => {
          e && bt.send("ccd", Ze(e).toION());
        };
        (() => {
          const t = Ft({
            apiFunctionName: "__uspapi",
            apiFrameLocatorName: "__uspapiLocator",
          });
          bt.send("cca", !!t),
            t &&
              ((t) => {
                let n, i;
                Je(t)
                  ? t("getUSPData", 1, e)
                  : ((n = {
                      __uspapiCall: {
                        command: "getUSPData",
                        version: 1,
                        callId: bt.getCallId(),
                      },
                    }),
                    (i = bt.getMessageHandler("__uspapiReturn", e)),
                    Jn.addEvent(_i.getWindow(), "message", i),
                    t.postMessage(n, "*"));
              })(t);
        })();
      },
      settings: {
        tier: 8,
        applies: (e, t, n) => {
          "use strict";
          return t.hasPostMessage() && !n.isDomless();
        },
      },
    },
    At = {
      name: "GDPRConsentDetector",
      dependencies: [],
      creator: function () {
        "use strict";
        const e = 278,
          t = (e) => {
            const t =
                Ye(e) && Ye(e.vendorConsents) && Ye(e.vendorConsents[278])
                  ? e.vendorConsents[278]
                  : void 0,
              n = {
                appl: Ke(e.gdprApplies),
                cnst: Ke(t),
                glbl: Ke(e.hasGlobalScope),
                mtdt: encodeURIComponent(e.metadata),
              },
              i = e && e.tcString;
            at.getAggregator().provide("tcString", () => i),
              bt.send("gcd", Ze(n).toION());
          };
        (() => {
          const n = Ft({
            apiFunctionName: "__cmp",
            apiFrameLocatorName: "__cmpLocator",
          });
          bt.send("gca", !!n),
            n &&
              ((n) => {
                let i, r;
                Je(n)
                  ? n("getVendorConsents", [e], t)
                  : ((i = {
                      __cmpCall: {
                        command: "getVendorConsents",
                        parameter: [e],
                        callId: bt.getCallId(),
                      },
                    }),
                    (r = bt.getMessageHandler("__cmpReturn", t)),
                    Jn.addEvent(_i.getWindow(), "message", r),
                    n.postMessage(i, "*"));
              })(n);
        })();
      },
      settings: {
        tier: 8,
        applies: (e, t, n) => {
          "use strict";
          return t.hasPostMessage() && !n.isDomless();
        },
      },
    },
    It = {
      name: "GDPRV2ConsentDetector",
      dependencies: [],
      creator: () => {
        const e = (e) => {
          const t =
              Ye(e) &&
              Ye(e.vendor) &&
              Ye(e.vendor.consents) &&
              Ye(e.vendor.consents[278])
                ? e.vendor.consents[278]
                : void 0,
            n = { appl: Ke(null == e ? void 0 : e.gdprApplies), cnst: Ke(t) };
          bt.send("gcd2", Ze(n).toION());
        };
        (() => {
          const t = Ft({
            apiFunctionName: "__tcfapi",
            apiFrameLocatorName: "__tcfapiLocator",
          });
          bt.send("gca2", !!t),
            t &&
              ((t) => {
                let n, i;
                if (Je(t))
                  try {
                    t("addEventListener", 2, e);
                  } catch (n) {
                    try {
                      t("getTCData", 2, e);
                    } catch (e) {}
                  }
                else
                  (n = {
                    __tcfapiCall: {
                      command: "addEventListener",
                      callId: bt.getCallId(),
                      version: 2,
                    },
                  }),
                    (i = bt.getMessageHandler("__tcfapiReturn", e)),
                    Jn.addEvent(_i.getWindow(), "message", i, !1),
                    t.postMessage(n, "*");
              })(t);
        })();
      },
      settings: {
        tier: 8,
        applies: (e, t, n) => t.hasPostMessage() && !n.isDomless(),
      },
    };
  class St extends a {
    constructor() {
      super(...arguments), (this.failed = !1), (this.callbacks = []);
    }
    onConsentFrameworkChange(e) {
      this.callbacks.push(e);
    }
    emitConsentFrameworkChange() {
      this.callbacks.forEach((e) => {
        e();
      });
    }
  }
  class Tt extends a {
    constructor() {
      super({ storeModelName: "ConsentDetection" }),
        (this.consentDetection = !1),
        (this.isAbleToMeasure = !1),
        (this.previousConsentState = !1),
        (this.hasGottenAllUserInputs = !1),
        (this.hasSentInitialMinDT = !1),
        (this.consentFrameworkRecords = {}),
        (this.sendMinimalDTCall = ({ fields: e }) => {
          this.consentDetection &&
            at
              .getAggregator()
              .trigger("sendMinDt", "e", -5, { field: "tv", value: e });
        }),
        (this.updateMeasurementStatus = ({ newIsAbleToMeasure: e }) => {
          e !== this.isAbleToMeasure &&
            (this.set("isAbleToMeasure", e, { locked: !1 }),
            te.emit("measurementStatus", {
              canSendMeasurementData: this.isAbleToMeasure,
            }));
        }),
        (this.consentFrameworkRecords.tcf = {
          framework: new Ot(),
          isAbleToMeasure: !1,
          DTFields: {},
          evaluator: Ct,
        }),
        this.startOnPubSubCD();
    }
    startOnPubSubCD() {
      te.on("consentDetection", () => {
        try {
          this.start();
        } catch (e) {}
      });
    }
    start() {
      Object.values(this.consentFrameworkRecords).forEach((e) => {
        const t = e.framework;
        if (t.applies()) {
          const e = this.checkFrameworks.bind(this);
          t.onConsentFrameworkChange(e), t.start();
        }
      });
      at.getAggregator().request("features").on("consentDetection") &&
        this.set("consentDetection", !0, { locked: !1 }),
        this.checkFrameworks();
    }
    checkFrameworks() {
      try {
        let e = !0;
        const t = {},
          n = Object.values(this.consentFrameworkRecords);
        n.forEach((n) => {
          const { DTFields: i, isAbleToMeasure: r } = n.evaluator(n.framework);
          e && (e = r), Object.assign(t, i), this.sendDTFields(i);
        }),
          !this.hasGottenAllUserInputs &&
            n.every((e) => e.evaluator(e.framework).hasUserInput) &&
            (this.hasGottenAllUserInputs = !0),
          ((this.hasGottenAllUserInputs && !this.hasSentInitialMinDT) ||
            (this.previousConsentState && !e)) &&
            (this.sendMinimalDTCall({ fields: t }),
            (this.hasSentInitialMinDT = !0)),
          (this.previousConsentState = e),
          this.updateMeasurementStatus({ newIsAbleToMeasure: e });
      } catch (e) {}
    }
    sendDTFields(e) {
      Object.entries(e).forEach(([e, t]) => {
        at.getAggregator().trigger("addOutputItem", { output: t }, e);
      });
    }
  }
  const Ct = (e) => {
    let t = !0,
      n = !1,
      i = {};
    if (!e.failed) {
      const r = e.consentData;
      (n = kt({ consentData: r })),
        (t = Et({ consentData: r })),
        (i = Pt({ consentData: r, isAbleToMeasure: t }));
    }
    return { isAbleToMeasure: t, DTFields: i, hasUserInput: n };
  };
  class Ot extends St {
    constructor() {
      super({ storeModelName: "TransparencyConsentFramework" }),
        (this.consentData = null),
        (this.listenerIDs = []),
        (this.messageHandlers = []);
    }
    applies() {
      return !Xn.isDomless();
    }
    start() {
      (this.apiEntrance = Ft({
        apiFunctionName: "__tcfapi",
        apiFrameLocatorName: "__tcfapiLocator",
      })),
        this.addTCFAPIEventListener(),
        this.onUnloadRemoveTCF();
    }
    messageHandler(e) {
      e &&
        (this.set("consentData", e, { locked: !1 }),
        this.emitConsentFrameworkChange()),
        Nt({
          consentData: e,
          listenerIDs: this.listenerIDs,
          messageHandlers: this.messageHandlers,
        });
    }
    onUnloadRemoveTCF() {
      at.getAggregator().on("unload", () => {
        this.end();
      });
    }
    end() {
      Vt({
        apiEntrance: this.apiEntrance,
        listenerIDs: this.listenerIDs,
        messageHandlers: this.messageHandlers,
      });
    }
    addTCFAPIEventListener() {
      this.apiEntrance
        ? Mt({
            apiEntrance: this.apiEntrance,
            command: "addEventListener",
            tcfv: 2,
            action: this.messageHandler.bind(this),
          })
        : (this.failed = !0);
    }
  }
  const Et = ({ consentData: e }) => {
      let t = !1;
      try {
        const n = null == e ? void 0 : e.gdprApplies;
        if (n) {
          if (
            n &&
            "useractioncomplete" === (null == e ? void 0 : e.eventStatus)
          ) {
            Dt({ consentData: e }) && (t = !0);
          }
        } else t = !0;
      } catch (e) {}
      return t;
    },
    Dt = ({ consentData: e }) => {
      const { vendor: t, purpose: n } = e,
        i = null == t ? void 0 : t.consents,
        r = (null == i ? void 0 : i[278]) || !1,
        o = null == t ? void 0 : t.legitimateInterests,
        s = (null == o ? void 0 : o[278]) || !1,
        a = null == n ? void 0 : n.legitimateInterests,
        c = [10, 7].every((e) => (null == a ? void 0 : a[e]) || !1);
      return r || (s && c);
    },
    Mt = ({ apiEntrance: e, command: t, tcfv: n, action: i, id: r }) => {
      if (e)
        if ("function" == typeof e)
          try {
            e(
              t,
              n,
              (e, t) => {
                t && i(e);
              },
              r
            );
          } catch (e) {}
        else if (e && "function" == typeof e.postMessage) {
          const r = (e) => {
              var t, n;
              const o = e.data;
              if (
                1 ===
                  (null === (t = null == o ? void 0 : o.__tcfapiReturn) ||
                  void 0 === t
                    ? void 0
                    : t.callId) &&
                (null === (n = null == o ? void 0 : o.__tcfapiReturn) ||
                void 0 === n
                  ? void 0
                  : n.success)
              ) {
                const e = o.__tcfapiReturn.returnValue;
                (e.messageHandler = r), i(e);
              }
            },
            o = { __tcfapiCall: { command: t, callId: 1, version: n } };
          Jn.addEvent(_i.getWindow(), "message", r, !1), e.postMessage(o, "*");
        }
    },
    xt = { error: -1, useractioncomplete: 1, cmpuishown: 2, tcloaded: 3 },
    Pt = ({ consentData: e, isAbleToMeasure: t }) => {
      var n, i, r, o, s, a, c, d;
      const u = {},
        l = [];
      return (
        (null ===
          (i =
            null === (n = null == e ? void 0 : e.purpose) || void 0 === n
              ? void 0
              : n.legitimateInterests) || void 0 === i
          ? void 0
          : i[7]) && l.push(7),
        (null ===
          (o =
            null === (r = null == e ? void 0 : e.purpose) || void 0 === r
              ? void 0
              : r.legitimateInterests) || void 0 === o
          ? void 0
          : o[10]) && l.push(10),
        (u.cpli = l),
        (u.cgc = (
          null ===
            (a =
              null === (s = null == e ? void 0 : e.vendor) || void 0 === s
                ? void 0
                : s.consents) || void 0 === a
            ? void 0
            : a[278]
        )
          ? 1
          : 0),
        (u.cvli = (
          null ===
            (d =
              null === (c = null == e ? void 0 : e.vendor) || void 0 === c
                ? void 0
                : c.legitimateInterests) || void 0 === d
            ? void 0
            : d[278]
        )
          ? 1
          : 0),
        (null == e ? void 0 : e.eventStatus) &&
          (u.ccmp = xt[null == e ? void 0 : e.eventStatus]),
        (u.cdop = (null == e ? void 0 : e.gdprApplies) ? 1 : 0),
        (u.cttd = t ? 1 : 0),
        u
      );
    },
    Vt = ({ apiEntrance: e, listenerIDs: t, messageHandlers: n }) => {
      t.forEach((t) => {
        Mt({
          apiEntrance: e,
          command: "removeEventListener",
          tcfv: 2,
          action: () => {},
          id: t,
        });
      }),
        n.forEach((e) => {
          Jn.removeEvent(window, "message", e);
        });
    },
    Nt = ({ consentData: e, listenerIDs: t, messageHandlers: n }) => {
      (null == e ? void 0 : e.listenerId) && t.push(e.listenerId),
        (null == e ? void 0 : e.messageHandler) && n.push(e.messageHandler);
    },
    kt = ({ consentData: e }) =>
      !(
        !(null == e ? void 0 : e.gdprApplies) ||
        "useractioncomplete" !== (null == e ? void 0 : e.eventStatus)
      ),
    Ft = ({ apiFunctionName: e, apiFrameLocatorName: t }) => {
      try {
        let n,
          i,
          r = _i.getWindow();
        const o = _i.getTop();
        try {
          n = null == o ? void 0 : o[e];
        } catch (e) {
          for (; !i; ) {
            try {
              if (r.frames[t]) {
                const e = r.frames[t];
                i = null == e ? void 0 : e.parent;
              }
            } catch (e) {}
            if (r === o) break;
            r = r.parent;
          }
        }
        return n || i;
      } catch (e) {}
    },
    Rt = ["A", "DIV", "IFRAME", "INS"],
    jt = function () {
      "use strict";
      let t;
      const n = ["STYLE", "SCRIPT", "HEAD", "META"],
        i = ti.concat(Rt);
      let r = 0;
      const o =
        (oe.measurementConfig.useFIF && Xn.friendlyIframe) ||
        Xn.isSpecifiedAd();
      let s = 0,
        a = [];
      const c = function (t) {
          let n,
            i = t,
            o = t;
          const s = Xn.friendly
            ? _i.getTop().document.body
            : e.contextNode.ownerDocument.body;
          function a() {
            const e =
              "[data-integralas-id-" + (oe.adTag && oe.adTag.asid) + "]";
            return oi.crossQuerySelector(e);
          }
          for (; r < 3; ) {
            if (s && i === s) {
              (o = i), (r = 3);
              break;
            }
            oi.isWindow(i) && ((n = a()), (i = Ye(n) ? n : i)),
              (i = (Ye(i) && i.parentNode) || i),
              (o = i),
              r++;
          }
          return o;
        },
        d = function (e) {
          const t = (function (e) {
            const t = [],
              r = e && e.getElementsByTagName && e.getElementsByTagName("*"),
              o = r && r.length;
            let s, a;
            if (r)
              for (let e = 0; e < o; e++)
                (s = r[e]),
                  (a = s && s.nodeName && s.nodeName.toUpperCase()),
                  s.children &&
                    0 === s.children.length &&
                    -1 === i.indexOf(a) &&
                    -1 === n.indexOf(a) &&
                    -1 === t.indexOf(a) &&
                    t.push(a);
            return t;
          })(e);
          return i.concat(t);
        },
        u = function (t) {
          let n;
          const i = o ? c(t) : t;
          return (
            oi.isWindow(i)
              ? (n = (function (t) {
                  let n;
                  try {
                    n = t.document;
                  } catch (t) {
                    n = e.contextNode.ownerDocument;
                  }
                  return n;
                })(i))
              : "IFRAME" === oi.getNodeName(i)
              ? (a.push(t), (n = t.contentWindow.document))
              : (n = i),
            n
          );
        },
        l = function (n) {
          const i = oi.isNodeXDomainIframe(n) || oi.isNodeCreative(n),
            r = !n;
          if (((t = r ? e.contextNode.parentNode : n), i || r))
            !(function () {
              const e = a.length;
              e > 0 && (s < e ? (s = e) : ((s = 0), (a = [])));
            })(),
              at.getAggregator().trigger("evaluateCreativeFinderResult", n);
          else {
            const e = u(n),
              t = d(e);
            new _t(t, a).searchDescendants(e);
          }
        };
      return (
        at.getAggregator().on("creativeFinderBatchCompleted", l),
        {
          find: l,
          getClosestContainerName: function () {
            return oi.getNodeName(t);
          },
        }
      );
    },
    _t = function (t, n) {
      "use strict";
      const i = t,
        r = function (e) {
          let t = 0,
            i = null,
            r = -1;
          function o(e) {
            if (
              (function (e) {
                const t = oi.getNodeName(e),
                  n = oi.isNodeCreative(e) || "IFRAME" === t;
                return t && n;
              })(e) &&
              !oi.isEmptyFriendlyFrame(e)
            ) {
              const t = oi.getNodeArea(e);
              t > r && -1 === n.indexOf(e) && ((i = e), (r = t));
            }
          }
          e.length && at.getAggregator().request("useYieldSearch")
            ? (function n() {
                do {
                  o(e[t]), (t += 1);
                } while (t % 500 != 0 && t < e.length);
                t < e.length
                  ? _i.execAtEndOfThread(n, 0)
                  : at
                      .getAggregator()
                      .trigger("creativeFinderBatchCompleted", i);
              })()
            : (function () {
                for (; t < e.length; t++) o(e[t]);
                at.getAggregator().trigger("creativeFinderBatchCompleted", i);
              })();
        };
      return {
        searchDescendants: function (t) {
          const n = t || e.contextNode.parentNode,
            o = oi.collectCandidateElements(n, i);
          r(o);
        },
      };
    },
    Lt = function () {
      "use strict";
      let e,
        t = !1,
        n = !1,
        i = !1,
        r = !1;
      const o = { status: "0", details: "na" },
        s = { status: "1", details: "env" },
        a = "rend",
        c = "renddet",
        d = at.getAggregator().request("omidAdSessionContext"),
        u = function () {
          let e = !1;
          return Xn.isOmid() && d && d.useOMID13Logic && (e = !0), e;
        },
        l = function () {
          (t = !0), (i = !0);
        },
        g = function (n) {
          const i = e.build(),
            s = n.status || o.status,
            d = i || o.details;
          if ("1" === s) {
            at.getAggregator().trigger("perfCheckpoint", {
              type: "render",
              timestamp: _i.now(),
              code: "tdr",
            });
            try {
              xe() &&
                !r &&
                ((r = !0),
                (u = Xn.getTagTime()),
                De(() => {
                  Ee("sert", u);
                }));
            } catch (e) {}
          }
          var u;
          t && "1" === s
            ? (at.getAggregator().trigger("addThrottledOutputItem", a, s),
              at.getAggregator().trigger("addThrottledOutputItem", c, d))
            : (at.getAggregator().trigger("addOutputItem", { output: s }, a),
              at.getAggregator().trigger("addOutputItem", { output: d }, c));
        },
        m = function () {
          const t = d && !!d.isVideo,
            i = !u() || (d && !!d.videoStartArrived),
            r = !u() || (d && !!d.geometryArrived),
            o = !d.omidEarlyExit || d.omidImpressionArrived,
            a = !(d.omidEarlyExit && u()) || d.omidLoadedArrived;
          return (
            !(n || !r || !o || !a || (t && !i)) &&
            (at
              .getAggregator()
              .trigger("addOutputItem", { output: Xn.getTagTime() }, "oren"),
            at.getAggregator().trigger("eligiblerender"),
            e.save("env"),
            e.save("or"),
            at.getAggregator().trigger("adRendered"),
            g(s),
            (n = !0),
            !0)
          );
        };
      return {
        start: function () {
          let t = !1;
          at
            .getAggregator()
            .trigger("perfCheckpoint", {
              type: "render",
              timestamp: _i.now(),
              code: "initial",
            }),
            at.getAggregator().on("adRendered", function () {
              t = !0;
            }),
            at.getAggregator().provide("adRenderStatus", function () {
              return t;
            }),
            at.getAggregator().provide("useYieldSearch", function () {
              return i;
            }),
            (e = new qt()),
            new Wt(),
            at.getAggregator().on("impressionsent", l),
            u() || d.omidEarlyExit
              ? m() ||
                (e.save("env"),
                e.save("ou"),
                g(o),
                at.getAggregator().on("omidrendgeoupdate", function () {
                  m();
                }),
                at.getAggregator().on("omidrendvideostart", function () {
                  m();
                }),
                d.omidEarlyExit &&
                  (at.getAggregator().on("omidimpressionarrived", function () {
                    m();
                  }),
                  at.getAggregator().on("omidloadedarrived", function () {
                    m();
                  })))
              : Xn.isOmid() || Xn.isVideo()
              ? (at.getAggregator().trigger("eligiblerender"),
                e.save(s.details),
                at.getAggregator().trigger("adRendered"),
                g(s))
              : (g(o), Ut(g, o, e));
        },
      };
    },
    Ut = function (e, t, n) {
      at.getAggregator().on("primaryadfound", function (i) {
        var r, o;
        try {
          const e =
            null === (r = oe.mraidLifecycleTracker) || void 0 === r
              ? void 0
              : r.getSnapshot();
          "eligible" === (null == e ? void 0 : e.eligibility) &&
            e.mraidExists &&
            ((o = Xn.getTagTime()),
            De(() => {
              Ee("sepaf", 1), Ee("sepat", o);
            }));
        } catch (e) {}
        let s;
        const a = jt();
        let c = !0;
        const d = "data-ias-rend-bi",
          u = function (e) {
            e && (e.status = "1"), at.getAggregator().trigger("adRendered");
          },
          l = function (e) {
            let t = !0;
            const i = Ye(e.naturalWidth) ? e.naturalHeight * e.naturalWidth : 0,
              r = getComputedStyle(e),
              o = 0 === e.src.length && Xi.contains(r.content, "url"),
              s = e.getAttribute && e.getAttribute(d);
            return (
              i > 0 && !o && (t = !1),
              "false" === s && (n.save("cs"), (t = !1)),
              o &&
                !s &&
                (function (e, t) {
                  n.save("cs");
                  const i = /url(?:\(['"]?)(.*?)(?:['"]?\))/.exec(t.content),
                    r = i && i[1],
                    o = oi.createImage(),
                    s = e;
                  (o.onload = function () {
                    o.naturalHeight * o.naturalWidth > 0 &&
                      s.setAttribute &&
                      s.setAttribute(d, !1);
                  }),
                    (o.src = r),
                    s.setAttribute(d, !0);
                })(e, r),
              t
            );
          },
          g = function () {
            s ? _i.clearInterval(s) : (c = !1);
          };
        at.getAggregator().on("evaluateCreativeFinderResult", function (i) {
          let r;
          oi.isNodeXDomainIframe(i)
            ? (g(),
              (t = (function (t) {
                const i = {},
                  r = "readystatechange",
                  o = "load",
                  s = _i.getDoc(),
                  a = "complete" === s.readyState,
                  c = function (a) {
                    const d = a && a.type;
                    ((d === r && "complete" === a.target.readyState) ||
                      d === o) &&
                      (u(i),
                      n.saveNode(t),
                      "readystatechange" === d
                        ? n.save("dr")
                        : "load" === d && n.save("lf"),
                      e(i),
                      Jn.removeEvent(t, o, c),
                      Jn.removeEvent(s, r, c));
                  };
                return (
                  a
                    ? (u(i), n.saveNode(t), n.save("dr"))
                    : (Jn.addEvent(t, o, c, void 0),
                      Jn.addEvent(s, r, c, void 0)),
                  i
                );
              })(i)))
            : i
            ? ((function (e) {
                let t = !1;
                const i = oi.getRect(e);
                return (
                  e &&
                    "IMG" === oi.getNodeName(e) &&
                    l(e) &&
                    ((t = !0), n.save("bi")),
                  !t && i.width >= 20 && i.height >= 8
                );
              })(i) && (u(t), g()),
              n.saveNode(i))
            : ((r =
                a.getClosestContainerName() || n.getAdNodeName(i) || t.details),
              n.save(r)),
            e(t);
        });
        const m = function () {
            const e = i && i.getAdNode();
            try {
              a.find(e);
            } catch (e) {
              at.getAggregator().trigger("renderdiag", e);
            }
          },
          p = at.getAggregator().request("mobileApp");
        p &&
        p.isMobileAppEnvironment &&
        p.isMobileAppEnvironment() &&
        Xn.isMraid()
          ? (function (e, n) {
              var i, r;
              const o = _i.getWindow().mraid,
                s = o && o.getState && o.getState(),
                a = "ready",
                c = t;
              let d,
                u = !1;
              const l = function (t, i) {
                  var r;
                  if (!u) {
                    (u = !0),
                      n.save(i),
                      at.getAggregator().trigger("adRendered");
                    try {
                      "eligible" ===
                        (null === (r = oe.mraidLifecycleTracker) || void 0 === r
                          ? void 0
                          : r.getSnapshot().eligibility) && Ne(t);
                    } catch (e) {}
                    d && d(), e({ status: "1" });
                  }
                },
                g = function () {
                  Jn.removeEvent(o, a, g),
                    n.save("env"),
                    l("ready_event", "mr");
                };
              let m;
              n.save("env");
              let p = !1;
              try {
                const e = oe.mraidLifecycleTracker;
                null == e || e.refresh("render"),
                  (m = null == e ? void 0 : e.getSnapshot()),
                  (p = !!(
                    e &&
                    "eligible" === (null == m ? void 0 : m.eligibility) &&
                    (null == m ? void 0 : m.mraidExists) &&
                    (m.defaultObserved ||
                      m.readyObserved ||
                      m.readyListenerAttached ||
                      m.stateChangeListenerAttached)
                  )),
                  p &&
                    e &&
                    (m.defaultObserved
                      ? l("cached_default", "md")
                      : m.readyObserved
                      ? (n.save("env"), l("cached_ready", "mr"))
                      : (d = e.subscribe({
                          onReady: () => {
                            n.save("env"), l("tracked_ready", "mr");
                          },
                          onStateChange: (e) => {
                            "default" === e && l("tracked_default", "md");
                          },
                        })));
              } catch (e) {}
              if (!u)
                if ("default" === s) l("current_default", "md");
                else if ("loading" === s) {
                  p || Jn.addEvent(o, a, g, void 0), n.save("ml");
                  try {
                    "eligible" ===
                      (null === (i = oe.mraidLifecycleTracker) || void 0 === i
                        ? void 0
                        : i.getSnapshot().eligibility) && Ne("current_loading");
                  } catch (e) {}
                  e(c);
                } else {
                  p || Jn.addEvent(o, a, g, void 0), n.save("mu");
                  try {
                    "eligible" ===
                      (null === (r = oe.mraidLifecycleTracker) || void 0 === r
                        ? void 0
                        : r.getSnapshot().eligibility) && Ne("current_unknown");
                  } catch (e) {}
                  e(c);
                }
            })(e, n)
          : (m(), c && (s = _i.setInterval(m, 500))),
          at.getAggregator().trigger("eligiblerender");
      });
    },
    qt = function () {
      "use strict";
      let e = [],
        t = [];
      const n = function (e) {
          let t;
          if (oi.isWindow(e)) t = "WINDOW";
          else if (oi.isNodeXDomainIframe(e)) t = "XIFRAME";
          else
            try {
              t = oi.getNodeName(e);
            } catch (e) {
              i("nen");
            }
          return t;
        },
        i = function (t) {
          e.push(t);
        };
      return {
        build: function () {
          const n = [];
          return (
            t.forEach(function (e) {
              n.push(e);
            }),
            e.forEach(function (e) {
              n.push(e);
            }),
            (t = []),
            (e = []),
            n.join(".")
          );
        },
        getAdNodeName: n,
        save: i,
        saveNode: function (e) {
          try {
            const i = e && n(e),
              r = e && oi.getRect(e),
              o = e && oi.hasBackgroundImage(e),
              s = e && e.children && 0 === e.children.length,
              a = e && e.innerText && e.innerText.length > 0,
              c = s && a,
              d = r && r.width >= 20 && r.height >= 8 ? "qs" : "us";
            t.push(i), t.push(d), o && t.push("sn"), c && t.push("tn");
          } catch (e) {
            i("sne");
          }
        },
      };
    },
    Wt = function () {
      "use strict";
      let t,
        n = !1,
        i = !1;
      const r = "1",
        o = "0",
        s = function () {
          (n = !0), c();
        },
        a = function (e) {
          (t = e), c();
        },
        c = function () {
          at
            .getAggregator()
            .trigger("addOutputItem", { output: !t && n ? r : o }, "rmeas"),
            t &&
              t.message &&
              !i &&
              (__IntegralASDiagnosticCall("renderloop", t, e),
              at.getAggregator().trigger("addThrottledProp", "env", "rle", 1),
              (i = !0));
        };
      at.getAggregator().on("eligiblerender", s),
        at.getAggregator().on("renderdiag", a),
        c();
    },
    Bt = function () {
      "use strict";
      return {
        applies: function (e, t, n) {
          const i = at.getAggregator().request("mobileApp");
          return (
            (e.browserIs("c") ||
              e.isAndroidWebViewBrowser() ||
              e.browserIs("w") ||
              e.browserIs("e")) &&
            !i.isMobileAppEnvironment() &&
            e.hasIntersectionObserver()
          );
        },
      };
    },
    Gt = function () {
      "use strict";
      let e,
        t,
        n = !1;
      const i = at.getAggregator().request("mPage"),
        r = function () {
          !n &&
            t &&
            e &&
            !i.isHidden() &&
            ((n = !0), at.getAggregator().trigger("sendDt", "l"));
        };
      at.getAggregator().on("primaryadfound", function (t) {
        (e = t.getDims().area() >= 242500), r();
      }),
        at.getAggregator().on("impressionsent", function () {
          (t = !0), r();
        }),
        i.onHiddenChange(r);
    },
    Ht = function () {
      "use strict";
      const e = [],
        t = {},
        n = {
          percentInView: "piv",
          sl: "vs",
          reason: "r",
          width: "w",
          height: "h",
          omidObstructions: "oobs",
        },
        i = { omidObstructions: ["sl", "percentInView", "reason"] };
      at.getAggregator().on("newScreenEvent", function (i) {
        const o = Ze(i).selectProperties(Ze(n).keys()),
          s = Ze(o).asStrings();
        let a = Ze(s).compareTo(t);
        (a = r(a)),
          a &&
            JSON.stringify(a) !== JSON.stringify({}) &&
            ((a.t = Xn.getTagTime()), e.push(a)),
          Ze(t).mixin(s);
      });
      const r = function (e) {
        return (
          Ze(i).each(function (t, n) {
            let i = !1;
            Ze(n).each(function (t, n) {
              e[n] && (i = !0);
            }),
              !1 === i && delete e[t];
          }),
          e
        );
      };
      return {
        toString: function () {
          return Ze(e).toION(n);
        },
      };
    };
  const $t = function () {
      "use strict";
      const e = new vn(),
        t = new zt();
      return Ze(e).mixin(t);
    },
    zt = function () {
      "use strict";
      const e = {},
        t = {},
        n = function (e, n) {
          (t[e] = t[e] || []), t[e].push(n);
        },
        i = function (t, n) {
          const i = e[t];
          i && i.run.apply({}, n);
        },
        r = function (e, n, i) {
          let r = t[e];
          if (r && 0 !== r)
            return (
              i && (r = r.slice(0, 1)),
              Ze(r).each(function (e, t) {
                n.apply({}, t);
              }),
              !0
            );
        },
        o = function (t, n, i) {
          (e[t] = e[t] || new Yt()), e[t].push(n, i);
        };
      return {
        on: function (e, t) {
          let n = {};
          t ? (n[e] = t) : (n = e), Ze(n).each(o), Ze(n).each(r);
        },
        once: function (e, t) {
          r(e, t, !0) || o(e, t, 1);
        },
        trigger: function (e) {
          const t = Ze(arguments).toArray();
          t.shift(), i(e, t);
        },
        persistentTrigger: function (e) {
          const t = Ze(arguments).toArray();
          t.shift(), n(e, t), i(e, t);
        },
      };
    },
    Xt = function () {
      "use strict";
      const e = (t, n, i) => {
          const r = oi.isWindow(t) ? t.frames : oi.getChildWindowsOf(t);
          if ((i && i(t, n), r && r.length)) {
            const t = n.length;
            for (let o = 0; o < r.length; o++) {
              const s = r[o];
              s && oi.isWindow(s) && ((n[t] = o), e(s, n, i));
            }
            n.pop();
          }
        },
        t = (t, n) => {
          try {
            e(n || top, [0], t);
          } catch (e) {}
        };
      return {
        traverse: t,
        getFrames: (e, n) => {
          const i = [];
          return (
            t((e) => {
              oi.isWindow(e) &&
                ((e, t) => {
                  let n = !0;
                  for (let i = 0; i < e.length; i++)
                    if (e[i] === t) {
                      n = !1;
                      break;
                    }
                  return n;
                })(i, e) &&
                i.push(e);
            }, n),
            Ze(i).filter(e)
          );
        },
      };
    },
    Yt = function () {
      "use strict";
      const e = [];
      return {
        push: function (t, n) {
          let i = 0;
          n = n || Number.MAX_VALUE;
          e[e.length] = function () {
            i < n && (i++, t.apply({}, arguments));
          };
        },
        run: function () {
          const t = arguments;
          e.forEach(function (e) {
            e.apply({}, t);
          });
        },
      };
    },
    Jt = function (e) {
      "use strict";
      const t = {};
      return {
        doEligibleJobs: function (n) {
          (e || []).forEach(function (e) {
            const i = e && e.getTime();
            Ye(i) && n >= i && !t[i] && (e.getTask().call(), (t[i] = !0));
          });
        },
      };
    },
    Qt = function () {
      "use strict";
      let e;
      const n = Kt();
      return {
        listen: (i, r, o) => {
          (e = (e) => {
            ((e, t, i, r) => {
              let o, s;
              if (JSON && JSON.parse)
                try {
                  o = JSON.parse(e.data);
                  const a = e.source;
                  if (((s = nt), t(o))) {
                    if (r) {
                      const e = r(a, o);
                      e &&
                        (s = () => {
                          n.send(() => e, a);
                        });
                    }
                    i(e, o, s);
                  }
                } catch (e) {
                  o && at.getAggregator().trigger("error", "m");
                }
            })(e, i, r, o);
          }),
            Jn.addEvent(t, "message", e);
        },
        stop: () => {
          e && Jn.removeEvent(t, "message", e), (e = null);
        },
      };
    },
    Kt = function () {
      "use strict";
      return {
        send: (e, t) => {
          if (!JSON || !JSON.stringify) return;
          const n = ((e) => (Ze(e).isObj() ? [e] : Xt().getFrames(e)))(t);
          Ze(n).each((t, n) => {
            const i = rt(e, n) || {};
            i.sentTime = _i.now();
            const r = ((e) =>
              Ze(e).mapToObj((e, t) => {
                let n;
                return Je(t) || ((n = {}), (n[e] = t)), n;
              }))(i);
            n.postMessage(JSON.stringify(r), "*");
          });
        },
      };
    },
    Zt = function (e) {
      "use strict";
      let t = 0;
      const n = {},
        i = function (e, n, i) {
          if (void 0 === e.output)
            throw new Error("item with id " + n + ' must have "output" method');
          (this.item = e),
            (this.id = n || ++t),
            (this.props = i || {}),
            (this.output = function () {
              let t = rt(e.output);
              return this.props.asION && (t = Ze(t).toION()), t;
            });
        },
        r = (e) => {
          const t = [];
          for (const i in n)
            if (n.hasOwnProperty(i)) {
              const r = e(i, n[i]);
              r && t.push(r);
            }
          return t;
        },
        o = (e, t, r) => {
          r = "string" != typeof (r = r || t) ? r : {};
          const o = Ze(e.output).isObj() && !r.asION,
            s = (e, t, r) => {
              const o = new i(e, t, r);
              n[o.id] = o;
            };
          o
            ? Ze(e.output).each((e, t) => {
                s({ output: t }, e, r);
              })
            : s(e, t, r);
        };
      return (
        e.on("addOutputItem", (e, t, n) => {
          o(e, t, n);
        }),
        {
          addItem: o,
          filterOutput: (e, t) =>
            r((n, i) => {
              const r = i.props;
              let o;
              e(r) &&
                ((o = i.output()),
                r.encode &&
                  ((n = encodeURIComponent(n)), (o = encodeURIComponent(o))),
                Je(t) ? t(n, o) : (t[n] = o));
            }),
          iterate: r,
          cleanup: () => {
            r((e, t) => {
              t.props.flagForRemoval && delete n[e];
            });
          },
          getItem: (e) => n[e],
        }
      );
    },
    en = /[,:={}[\]'"]/,
    tn = /^\{[\s\S]*\}$|^\[[\s\S]*\]$/,
    nn = (e) => en.test(e),
    rn = /[^\x20-\x7E]/,
    on = (e) => rn.test(e),
    sn = (e) => "'" + e.split("'").join("") + "'",
    an = ({ value: e }) => {
      if ("string" == typeof (t = e) && (nn(t) || on(t)) && !tn.test(t))
        return sn(e);
      var t;
      if (Array.isArray(e)) return e.map((e) => an({ value: e }));
      if (null !== e && "object" == typeof e) {
        const t = {};
        return (
          Object.keys(e).forEach((n) => {
            const i = e[n];
            t[n] = -1 !== n.indexOf("NULL") ? i : an({ value: i });
          }),
          t
        );
      }
      return e;
    },
    cn = /^,+|,+$/g,
    dn = /^id:[^,]*(?:,|$)/,
    un = /^id:/,
    ln = (e) => e.replace(/&/g, "%26").replace(/#/g, "%23"),
    gn = (e) => ln(((e) => nn(e) || on(e))(e) ? sn(e) : e),
    mn = (e) => {
      let t = e;
      for (let e = 0; e < 10; e += 1) {
        const e = h(t);
        if (e === t) break;
        t = e;
      }
      return t;
    },
    pn = ({ impressionUrl: e }) => {
      const t = Ca({ impressionUrl: e });
      if (t) return mn(t).replace(cn, "").replace(dn, "");
    },
    hn = ({ impressionUrl: e, recordedPieces: t }) => {
      const n = pn({ impressionUrl: e });
      if (void 0 === n || !Array.isArray(t)) return;
      const i = t.map((e) => mn(e)),
        r = i[0],
        o = void 0 !== r && un.test(r) ? i.slice(1) : i;
      return o.join(",") === n ? o : void 0;
    },
    fn = ({ impressionUrl: e, recordedPieces: t }) => {
      const n = pn({ impressionUrl: e });
      if (void 0 === n) return;
      const i = hn({ impressionUrl: e, recordedPieces: t });
      return i
        ? i
            .map((e) =>
              ((e) => {
                const t = e.indexOf(":");
                if (-1 === t) return e;
                const n = e.slice(0, t),
                  i = e.slice(t + 1);
                return n + ":" + gn(i);
              })(e)
            )
            .join(",")
        : ln(n);
    },
    vn = function () {
      "use strict";
      const e = {},
        t = (t, n) => {
          e[t] = n;
        };
      return {
        request: function (t) {
          let n;
          const i = e[t],
            r = Ze(arguments).toArray();
          return r.shift(), void 0 === i || (n = Je(i) ? i.apply({}, r) : i), n;
        },
        provide: (e, n) => (n ? t(e, n) : Ze(e).each(t), n),
      };
    },
    yn = function () {
      "use strict";
      return {
        createInstance: function (e, t, n, i) {
          return Xn.isDomless() ? new wn() : new bn(e, t, n, i);
        },
      };
    },
    bn = function (e, t, n, i) {
      "use strict";
      let r;
      const o = function (e, t) {
        return {
          viewState: "na",
          posViewState: "na",
          embedded: Xn.embedded,
          winDimensions: e,
          adDimensions: t,
        };
      };
      return {
        collect: function () {
          const t = e.find(),
            s = t.getOutOfViewReasons(),
            a = n.isHidden(),
            c = i.isDeviceTypeGroupMobile() && r ? r : ei(oi.calcWinDims()),
            d = t.getDims();
          return (
            (r = c),
            t.hasAd() && c.hasValidDims() && d.hasValidDims()
              ? (!0 === a && s.push("f"),
                {
                  winDimensions: c,
                  adDimensions: d,
                  containerDimensions: t.getContainerDims(),
                  method: t.getDetectionMethod(),
                  viewState: s.length ? "outOfView" : t.getViewState(),
                  viewStateIgnoringRender: t.getViewStateIgnoringRender(),
                  percentInView: t.getPercentInView(),
                  percentInViewIgnoringRender:
                    t.getPercentInViewIgnoringRender(),
                  reason: s.join("."),
                  obstructed: Ke(t.isObstructed()),
                  isHidden: Ke(t.isHidden()),
                  tabHidden: Ke(a),
                  posViewState: t.getViewState(),
                  adCompCount: t.getComponentCount(),
                  sliceStatus: t.getSliceStatus(),
                })
              : o(c, d)
          );
        },
      };
    },
    wn = function () {
      "use strict";
      return {
        collect: function () {
          return {};
        },
      };
    },
    An = function (e) {
      "use strict";
      const t = e || ((e) => e);
      let n = [],
        i = _i.now();
      const r = () => {
        const e = _i.now();
        n.length > 0 && ((n[n.length - 1].duration += e - i), (i = e));
      };
      return {
        clear: () => {
          r(), (n = []);
        },
        fastForward: r,
        get: () => n,
        hasAlwaysBeen: (e) => 1 === n.length && n[0].state === e,
        addState: (e) => {
          const i = t(e);
          r(),
            (0 !== n.length && i === n[n.length - 1].state) ||
              n.push({ state: i, duration: 0 });
        },
      };
    },
    In = function (e, t) {
      "use strict";
      const n = e || 1;
      let i,
        r = 0,
        o = 0,
        s = 0;
      return {
        start: () => {
          r % n == 0 && (i = _i.now());
        },
        stop: () => {
          const e = i || t;
          r % n == 0 && ((s += _i.now() - e), o++), r++;
        },
        getTime: () => s,
        getCount: () => o,
      };
    },
    Sn = function () {
      "use strict";
      let e,
        t = 0,
        n = 0;
      const i = new zt(),
        r = () => {
          (e = !1), (t = 0);
        },
        o = () => {
          e &&
            (t++, i.trigger(String(t)), n > t ? _i.execAtEndOfThread(o) : r());
        };
      return {
        onTick: (e, t) => {
          const r = t ? { [e]: t } : e;
          Object.keys(r).forEach((e) => {
            const t = parseInt(e);
            n = t > n ? t : n;
          }),
            i.on(r);
        },
        start: () => {
          e || ((e = !0), _i.execAtEndOfThread(o));
        },
        kill: r,
        isActive: () => e,
      };
    },
    Tn = function (e, t) {
      "use strict";
      let n,
        i = t;
      const r = (t) => {
          n || (t && e(), (n = _i.setInterval(e, i)));
        },
        o = (t) => {
          n && (t && e(), _i.clearInterval(n), (n = null));
        };
      return {
        start: r,
        stop: o,
        updateFrequency: (e, t) => {
          (i = e), n && (o(), r(t));
        },
      };
    },
    Cn = function (e) {
      "use strict";
      let t,
        n,
        i = 0,
        r = Xn.getTagTime(),
        o = 0,
        s = !1;
      return {
        getTotalTime: () => o,
        stop: () => {
          (i = 0), (r = Xn.getTagTime()), (s = !1);
        },
        mark: () => {
          (t = s ? Xn.getTagTime() - r : 0),
            (i += t),
            i >= e && ((n = i - t < e), (o += n ? i : t)),
            (r = Xn.getTagTime()),
            (s = !0);
        },
      };
    },
    On = function (t, n) {
      "use strict";
      const i = oe.baseUrls;
      let r = t || i.fwEventBaseUrl || i.cmEventBaseUrl;
      (r && 0 === r.indexOf("http")) ||
        (r =
          0 === r.indexOf("//")
            ? e.protocol + ":" + r
            : e.protocol + "://" + r);
      const o =
          /((http|https):\/\/(([^\/\.]*)\.([^\/]*)))(?:\/(.[^?]*)\??(.+)?)*/.exec(
            r
          ) || [],
        s = o[1] ? o[1] : "",
        a = o[2] ? o[2] : "",
        c = o[3] ? o[3] : "";
      let d = o[4] ? o[4] : "",
        u = o[5] ? o[5] : "",
        l = t && o[6] ? o[6] : "",
        g = o[7] && n ? o[7] : "";
      const m = {},
        p = function (e) {
          return "string" == typeof e && (d = e), d;
        },
        h = function (e) {
          return "string" == typeof e && (u = e), u;
        },
        f = function (t, n) {
          const i = t + "=" + Ze(n).toION();
          return st(i, e.encodeInvalidUrlChars);
        },
        v = function () {
          const e = Ze(m).isEmpty() ? "" : Ze(m).stringify(f, "&");
          return "?" + g + (g && e ? "&" + e : e);
        };
      g = g ? g.replace(/&$/, "") : "";
      return {
        appendToParamValue: function (e, t) {
          let i, r, o, s;
          const a = m[e];
          a
            ? (m[e] = a + t)
            : n &&
              g.length &&
              ((i = g.split(e)),
              (s = i.length > 1),
              s &&
                ((r = i[1].split("&")[0]),
                (o = [i[0], r].join(e)),
                (g = g.replace(o, o + t))));
        },
        fullDom: s,
        hostname: c,
        sub: p,
        master: h,
        setParam: function (e, t) {
          (m[e] = m[e] || {}),
            "string" == typeof t || "number" == typeof t
              ? (m[e] = t)
              : Ze(m[e]).mixin(t);
        },
        path: function (e) {
          l = e;
        },
        toString: function () {
          const e = p() ? p() + "." : "",
            t = l ? "/" + l : "",
            n = g || !Ze(m).isEmpty() ? v() : "";
          return a + "://" + e + h() + t + n;
        },
      };
    },
    En = function () {
      "use strict";
      const e = (e) => {
          const t = [];
          return (
            e.forEach((e) => {
              t.concat(e).join("").length <= 400 && t.push(e);
            }),
            t
          );
        },
        t = (e) =>
          oi
            .getAncestorNodes(e)
            .map(n)
            .filter((e) => void 0 !== e),
        n = (e) => {
          let t;
          return e && e.id && (t = e.id.replace(/[^\w-_.>/]/g, "")), t;
        };
      return (() => {
        let n, i;
        try {
          return (
            Xn.friendly &&
              !Xn.isMobileApp() &&
              ((n = at.getAggregator().request("adSlotIds")),
              n
                ? (i = n)
                : ((n = (() => {
                    const n = oi.getOurNodeInTop();
                    let i;
                    return n && (i = t(n)), (i = i && e(i)), i;
                  })()),
                  n &&
                    (at
                      .getAggregator()
                      .trigger("addOutputItem", { output: n }, "slid", {
                        type: "a",
                        asION: !0,
                      }),
                    at.getAggregator().provide("adSlotIds", n),
                    (i = n)))),
            i
          );
        } catch (e) {
          at.getAggregator().trigger("error", "A");
        }
      })();
    },
    Dn = {
      name: "AdRefreshDetection",
      dependencies: [],
      creator: function () {
        "use strict";
        const t = [15, 20, 30, 45, 60, 90],
          n = {
            start: function () {
              const e = this,
                t = oe.adTag && oe.adTag.asid,
                n = e.parseQuery(),
                i = e.getCacheId(n);
              t &&
                n.chanId &&
                (this.recordAdSlotImpression(t, n.chanId, i, (t, n) => {
                  t
                    ? at.getAggregator().trigger("error", "r")
                    : e.sendRefreshSession(n);
                }),
                e.registerInternalViewabilityListener(n.chanId, i));
            },
            getCacheId: (t) => {
              if (t && t.cacheId) return t.cacheId;
              if (e && e.contextNode) {
                try {
                  const n = e.contextNode.ownerDocument.querySelector(
                    "#ias-" + t.cb
                  );
                  if (n) return n.id;
                } catch (e) {}
                if (e.contextNode.nextSibling && e.contextNode.nextSibling.id)
                  return e.contextNode.nextSibling.id;
              }
              return null;
            },
            adRefreshIntervalIsValid: (e) => -1 !== t.indexOf(e),
            parseQuery: () => {
              const t = e.reqquery.split("&"),
                n = {};
              for (let e = 0; e < t.length; e += 1) {
                const [i, r] = t[e].split("=", 2);
                "" !== i && (n[i] = r);
              }
              return n;
            },
            sendRefreshSession: (e) => {
              const t =
                (0 === e.refreshCount ? "self" : e.refreshSessionId) +
                "." +
                e.refreshCount;
              at.getAggregator().trigger("addThrottledProp", "env", "ar", t);
            },
            recordAdSlotImpression: (e, t, n, i) => {
              const r = _i.getTop(),
                o = {
                  requestTop: "recordAdSlotImpression",
                  asid: e,
                  adUnitId: t,
                  cacheId: n,
                };
              window.addEventListener(
                "message",
                (e) => {
                  if (/refreshSession/g.test(e.data))
                    try {
                      const t = e && e.data && JSON.parse(e.data);
                      i(null, t);
                    } catch (e) {
                      i(e);
                    }
                },
                !1
              ),
                r.postMessage(JSON.stringify(o), "*");
            },
            registerInternalViewabilityListener: function (e, t) {
              const n = this,
                i =
                  (oe.measurementConfig.adRefreshThreshold &&
                    parseInt(oe.measurementConfig.adRefreshThreshold)) ||
                  null,
                r = _i.getTop();
              i &&
                this.adRefreshIntervalIsValid(i) &&
                at.getAggregator().on("sendDt", (o, s) => {
                  ("p" !== o && "c" !== o) ||
                    s !== i ||
                    (_i.execAtEndOfThread(() => {
                      r.postMessage(
                        JSON.stringify({
                          requestTop: "refreshAd",
                          adUnitId: e,
                          cacheId: t,
                        }),
                        "*"
                      );
                    }),
                    n.sendAutoRefreshProp(i));
                });
            },
            sendAutoRefreshProp: (e) => {
              at.getAggregator().trigger("addThrottledProp", "env", "ir", e),
                at.getAggregator().trigger("adSessionComplete");
            },
          };
        return (
          Xn.isRefreshable((e, t) => {
            let i;
            if (!e && t)
              try {
                (i = JSON.parse(t)),
                  i.isRefreshable && i.adServerName && n.start();
              } catch (e) {
                at.getAggregator().trigger("error", "r");
              }
          }),
          n
        );
      },
      settings: {
        tier: 8,
        applies: (e, t, n) => {
          "use strict";
          return n.isPossiblyRefreshable();
        },
      },
    },
    Mn = function () {
      "use strict";
      let e, t;
      const n = function (e) {
          return (
            -1 !== e.indexOf("https") && (e += "*"),
            e.replace(/^https?:\/\//, "")
          );
        },
        i = function () {
          if (at.getAggregator().request("adNode"))
            return parseFloat(at.getAggregator().request("videoVersion"));
        };
      return {
        isApplicable: function (e, t) {
          return (
            !(function (e) {
              return e.isVideo() && !(e.isMraid() || e.isOmid()) && i() < 3.7;
            })(t) &&
            e.hasAncestorOrigins &&
            e.hasAncestorOrigins() &&
            t.xDomainIframe
          );
        },
        isStarted: function () {
          return !!t;
        },
        start: function () {
          try {
            (e = _i.getWindow().location.ancestorOrigins), (t = !0);
          } catch (e) {
            at.getAggregator().trigger("error", "o");
          }
        },
        getMyFrameDepth: function () {
          return (e && e.length) || 0;
        },
        getTopDomain: function () {
          return e[e.length - 1];
        },
        sendOriginList: function () {
          const t =
            "ao:" +
            (e ? Array.prototype.map.call(e, n).reverse() : []).join(",");
          at
            .getAggregator()
            .trigger("addOutputItem", { output: t }, "tpiLookup", {
              type: "i",
              standalone: !0,
              encode: !0,
            }),
            at.getAggregator().trigger("sendDt", "i");
        },
      };
    },
    xn = function (e, t, n, i, r) {
      "use strict";
      const o = function (e, t, n) {
          r.addItem({ output: e + "." + t + "." + n }, "ctpl");
        },
        s = function (r) {
          try {
            const n = "c";
            t.diagnostic(n);
            const s = r.length;
            let a = 0,
              c = 0;
            o(s, 0, 0),
              r.forEach(function (t) {
                e.send(
                  (function (e) {
                    return e.replace("%%CBS%%", i.getCacheBustId());
                  })(t),
                  function () {
                    o(s, a, ++c);
                  },
                  !0
                ),
                  o(s, ++a, c);
              });
          } catch (e) {
            n.add("S");
          }
        };
      return {
        init: function () {
          try {
            let t = new On().fullDom;
            "/" !== t.slice(-1) && (t += "/"),
              (t += "tpl?asId=" + (oe.adTag && oe.adTag.asid)),
              e.jsonp(t, s);
          } catch (e) {
            n.add("N");
          }
        },
      };
    },
    Pn = function (t, n, i, r) {
      "use strict";
      return {
        enabled: "true" === e.useBapiCallback,
        callback: function (n) {
          i.trigger("sendDiag");
          try {
            "true" === e.accountForSadImps && r.measure(n),
              e._onAPIResult && e._onAPIResult(n);
          } catch (e) {
            t.add("b"), i.trigger("sendDiag", "bapiClient");
          }
        },
      };
    },
    Vn = function () {
      "use strict";
      return {
        createInstance: function (e, t, n, i) {
          return Xn.isDomless() ? new kn() : new Nn();
        },
      };
    },
    Nn = function () {
      "use strict";
      const e = function () {
          let e = "u";
          const t = _i.getWindow();
          try {
            (Ye(t.opr) && t.opr.addons) ||
            (Ye(t.opera) && Ye(t.opera.buildNumber))
              ? (e = "o")
              : Ye(t.mozInnerScreenY)
              ? (e = "g")
              : Ye(t.chrome) && Ye(t.chrome.csi)
              ? (e = "c")
              : Ye(t.msWriteProfilerMark) && Ye(t.crypto)
              ? (e = "e")
              : Ye(t.WebKitPoint)
              ? (e = "w")
              : (Ye(t.attachEvent) || Ye(t.msCrypto)) && (e = "i");
          } catch (e) {}
          return e;
        },
        t = function () {
          let e = "";
          try {
            const t = _i.getWindow();
            Ye(t.navigator) &&
              Ye(t.navigator.userAgent) &&
              (e = t.navigator.userAgent);
          } catch (e) {}
          return e;
        },
        n = function () {
          let e = "u";
          const n = t().toLowerCase();
          return (
            (e =
              n.indexOf(" opr/") > -1
                ? "o"
                : n.indexOf("firefox") > -1
                ? "g"
                : n.indexOf("edg") > -1
                ? "e"
                : n.indexOf("chrome") > -1
                ? "c"
                : n.indexOf("webkit") > -1
                ? "w"
                : n.indexOf("msie") > -1
                ? "i"
                : encodeURIComponent(n) || "_"),
            e
          );
        },
        i = function () {
          let e = "na";
          const t = _i.getWindow();
          return (
            Ye(t.navigator) &&
              Ye(t.navigator.appName) &&
              (e = t.navigator.appName.toLowerCase()[0]),
            e
          );
        };
      return {
        browserIs: function (t) {
          return e() === t;
        },
        hasIntersectionObserver: function () {
          return "function" == typeof IntersectionObserver;
        },
        hasMutationObserver: function () {
          return "function" == typeof MutationObserver;
        },
        hasResizeObserver: function () {
          return "function" == typeof ResizeObserver;
        },
        hasAncestorOrigins: function () {
          const e = _i.getWindow().location;
          return !(!e || !e.ancestorOrigins);
        },
        hasPostMessage: function () {
          const e = _i.getWindow();
          return !(!e || !Je(e.postMessage));
        },
        getBrowserType: e,
        getBrowserTypeByUA: n,
        getUserAgent: t,
        params: function () {
          return { br: e(), bru: n(), an: i() };
        },
        isAndroidWebViewBrowser: function () {
          const e = t(),
            n = Xi.contains(e, "Android");
          return (
            n &&
            ["Line", "SamsungBrowser", "FB_IAB", "Silk"].find(function (t) {
              return Xi.contains(e, t);
            })
          );
        },
        getIOSVersion: function () {
          let e, n, i;
          const r = t();
          return (
            r &&
              ((e = r.match(/OS\s\d+/)),
              e &&
                e.length > 0 &&
                ((n = e.toString().match(/\d+/)),
                (i = n && n.length > 0 && parseInt(n.toString())))),
            i
          );
        },
      };
    },
    kn = function () {
      "use strict";
      const e = function () {
        return !1;
      };
      return {
        getBrowserType: () => "u",
        getBrowserTypeByUA: () => "d",
        getIOSVersion: () => {},
        params: () => ({ br: "u", bru: "d", an: "na" }),
        browserIs: e,
        getUserAgent: e,
        hasPostMessage: e,
        hasAncestorOrigins: e,
        hasIntersectionObserver: e,
        hasMutationObserver: e,
        isAndroidWebViewBrowser: e,
      };
    },
    Fn = function () {
      "use strict";
      return {
        createInstance: (e, t) => (Xn.isDomless() ? new Un(t) : new _n(e, t)),
      };
    },
    Rn = function () {
      "use strict";
      let t;
      return {
        isApplicable: (n) => {
          t = at.getAggregator().request("omidAdSessionContext");
          const i = !(!t.app || !t.isDisplay || t.isWeb),
            r =
              n &&
              n.indexOf("/blocking/") > -1 &&
              !Xn.integratedBlockingApplies(n),
            o = 1 != e.forceNoIframe;
          return i && r && o;
        },
        deployBlockingScriptIntoIframe: (n, i) => {
          t = at.getAggregator().request("omidAdSessionContext");
          const r = "iasbi" + (oe.adTag && oe.adTag.asid),
            o = ((t, n) => {
              const i = e.contextNode.parentNode,
                r = "about:blank",
                o = e.adWidth && e.adWidth > 0 ? e.adWidth : 0,
                s = e.adHeight && e.adHeight > 0 ? e.adHeight : 0,
                a = _i.getDoc().getElementsByTagName("ins");
              let c,
                d = 0,
                u = 0;
              a &&
                a.length > 0 &&
                ((c = a[0]),
                (d = parseInt(c.style.width)),
                (u = parseInt(c.style.height)));
              const l = d || o || window.innerWidth,
                g = u || s || window.innerHeight;
              if (
                ("complete" === _i.getDoc().readyState &&
                  (e.forceAppend = "true"),
                "true" === e.forceAppend)
              ) {
                const e = _i.getDoc().createElement("IFRAME");
                (e.id = t), (e.src = r), i.appendChild(e);
              } else
                _i.getDoc().write(
                  oe.trustedTypesPolicy.createHTML(
                    '<iframe id="' + t + '" src="' + r + '"></iframe>'
                  )
                );
              const m = _i.getDoc().getElementById(t);
              return (
                m &&
                  ((m.style.width = l + "px"),
                  (m.style.height = g + "px"),
                  (m.scrolling = "no"),
                  (m.frameborder = 0),
                  (m.tabIndex = -1),
                  (m.style.position = "absolute"),
                  (m.style.padding = m.style.margin = m.style.border = "0px")),
                m
              );
            })(r);
          if (o) {
            const e = o.contentWindow.document;
            if (e) {
              e.open().write(
                ((e, t) => {
                  let n = "",
                    i = "";
                  const r = _i.getDoc().getElementsByTagName("ins");
                  let o;
                  if (r && r.length > 0) {
                    (o = r[0]), (n = "<ins");
                    for (let e = 0; e < o.attributes.length; e++)
                      n +=
                        " " +
                        o.attributes[e].nodeName +
                        '="' +
                        o.attributes[e].nodeValue +
                        '"';
                    (n += ">"), (i = "</ins>");
                  }
                  return (
                    '<!doctype html><html><head></head><body style="margin:0px;border:0px;padding:0px;font-size:0px"><script>var IASid = "' +
                    e +
                    '", largestSize = 0;var IASmonitorDom = function () {  var DOM_MONITOR_PERIOD = 100;  var i, us, thisSize, thisWidth, thisHeight;  var elems = document.body.getElementsByTagName("*");  for (i = 0; i < elems.length; i++) {    if (elems[i].tagName && elems[i].tagName.toLowerCase() === "ins")      continue;    thisWidth = elems[i].offsetWidth;    thisHeight = elems[i].offsetHeight;    thisSize = thisWidth * thisHeight;    if (thisSize > largestSize) {      largestSize = thisSize;      us = parent.document.getElementById(IASid);      if (us) {        us.setAttribute("CreativeLoaded","true");        if (elems[i].style.left !== "") {          us.style.left = elems[i].style.left;          elems[i].style.left = "0px";        }        if (elems[i].style.top !== "") {          us.style.top = elems[i].style.top;          elems[i].style.top = "0px";        }      }    }  }  setTimeout(IASmonitorDom, DOM_MONITOR_PERIOD);};setTimeout(IASmonitorDom,50);</script>' +
                    n +
                    '<script src="' +
                    t +
                    '" referrerpolicy="no-referrer-when-downgrade"></script>' +
                    i +
                    "</body></html>"
                  );
                })(r, n)
              ),
                e.close();
              const t = e.querySelector && e.querySelector("script[src]");
              t && i && (t.onload = i);
            }
          }
        },
      };
    },
    jn = ({ trimmedString: e, iasImpId: t }) => {
      const n = e.match(/^function\s*\(([^)]*)\)\s*\{([\s\S]*)\}$/);
      if (n && void 0 !== n[1] && void 0 !== n[2]) {
        const e = n[1],
          i = n[2];
        new Function(e, i)({ iasImpId: t });
      }
    },
    _n = function (i, r) {
      "use strict";
      const o = (t, i, r, o) => {
          let s;
          const a = Hn({ url: i });
          if (((i = a || i), "script" !== t)) {
            const e = n.createElement("DIV");
            (e.innerHTML = oe.trustedTypesPolicy.createHTML(r)),
              (s = e.childNodes[0]);
          } else
            (s = n.createElement("SCRIPT")),
              (s.src = oe.trustedTypesPolicy.createScriptURL(i)),
              o && (s.onload = o);
          e.contextNode.parentNode.appendChild(s);
        },
        s = function (i, r, s) {
          let a,
            c,
            d = "";
          const u = ((e) => {
              const t = Hn({ url: e });
              return ' src="' + (e = t || e) + '"';
            })(r),
            l = ' referrerpolicy="no-referrer-when-downgrade"';
          if (Xn.doesPageAllowAppendedScripts() && s) {
            const e = oe.adTag && oe.adTag.asid;
            (c =
              "__IntegralASEventLoadHandler_" + (e ? e.replace(/-/g, "") : "")),
              (t[c] = s),
              (d = ` ${"onload"}="${(g = c)} && ${g}()"`);
          }
          var g;
          const m = {
            script: ['<script type="text/javascript"', d, u, l, "></script>"],
            iframe: [
              '<iframe width="100%" height="100%" frameborder="0" vspace="0" hspace="0" scrolling="no" marginheight="0" marginwidth="0"',
              d,
              u,
              l,
              "></iframe>",
            ],
            img: ["<img", d, u, l, "/>"],
          }[i].join("");
          Xn.isOmid()
            ? ((a = new Rn()),
              a.isApplicable(r)
                ? a.deployBlockingScriptIntoIframe(r, s)
                : o(i, r, m, s))
            : ("loading" !== _i.getDoc().readyState && (e.forceAppend = "true"),
              "true" === e.forceAppend
                ? o(i, r, m, s)
                : n.write(oe.trustedTypesPolicy.createHTML(m)));
        },
        a = (e, t, n) => {
          let i;
          const r = !n && Jn.getXHR2(),
            o = Hn({ url: e });
          (e = o || e),
            r
              ? (r.open("POST", e),
                (r.onreadystatechange = () => {
                  4 === r.readyState && 200 === r.status && t && t();
                }),
                r.send())
              : ((i = oi.createImage()),
                t && (i.onload = t),
                (i.src = oe.trustedTypesPolicy.createScriptURL(e.toString())));
        },
        c = (e, t) => {
          const n = Jn.getXHR2(),
            i = Hn({ url: e });
          (e = i || e),
            n &&
              (n.open("GET", e),
              (n.onreadystatechange = () => {
                if (4 === n.readyState && 200 === n.status && t)
                  try {
                    const e = JSON.parse(n.responseText);
                    t(e);
                  } catch (e) {
                    return;
                  }
              }),
              n.send());
        },
        d = (e, t, i, r) => {
          const o = oe.contextNode,
            s = oe.measurementConfig,
            a = "text/javascript";
          let c = _i.getDoc();
          const d = c && "loading" === c.readyState,
            u = s && s.isStaticMode,
            l = n.createElement("script"),
            g = Hn({ url: e }),
            m = o && o.dataAttributes,
            p = "true" === (m && m.iasForceAppend);
          let h = o && o.element && o.element.parentNode;
          if (
            (s &&
              s.isStaticFrameInFrame &&
              o &&
              o.element &&
              o.element.contentDocument &&
              ((c = o.element.contentDocument), (h = c.body)),
            (i = i || h),
            (e = g || e),
            (l.type = a),
            (l.src = oe.trustedTypesPolicy.createScriptURL(e)),
            (l.referrerPolicy = "no-referrer-when-downgrade"),
            t && (l.onload = t),
            r && (l.setAttribute("defer", ""), l.setAttribute("async", "")),
            u && !oe.adTag.isScriptAsync && d && !p)
          ) {
            const t = "ias_dw_" + Math.random().toString(36).substring(2, 11),
              n =
                '<script id="' +
                t +
                '" type="' +
                a +
                '" src="' +
                e +
                '"></script>',
              r = oe.trustedTypesPolicy.createHTML(n);
            c.write(r);
            !c.getElementById(t) && Ye(i) && i.appendChild(l);
          } else Ye(i) && i.appendChild(l);
        },
        u = (e) => {
          const t = oe.adTag && oe.adTag.asid;
          if (Je(e)) e({ iasImpId: t });
          else if (e && "string" == typeof e) {
            const n = "function" == typeof e.trim ? e.trim() : e;
            if (0 === n.indexOf("function"))
              try {
                jn({ trimmedString: n, iasImpId: t });
              } catch (e) {}
            else {
              const t = new On(e, !0).toString();
              a(t, void 0, !0);
            }
          }
        },
        l = (e, t, n, i) => {
          d(r.wrap(e, t, n, i));
        };
      return (
        at
          .getAggregator()
          .on({
            addNode: s,
            send: a,
            exec: d,
            notify: u,
            getJSON: c,
            jsonp: l,
          }),
        { addNode: s, send: a, exec: d, notify: u, getJSON: c, jsonp: l }
      );
    },
    Ln = (e) => encodeURI(e).replace(/%25([0-9a-f]{2})/gi, "%$1"),
    Un = function (e) {
      "use strict";
      const t = function (e, t, n) {
          (t = t || e), (e = arguments.length > 1 ? e : "script");
          const i = Hn({ url: t });
          (t = i || t), (t = Ln(String(t)));
          const r = at.getAggregator().request("omidVerificationClient");
          r["script" === e ? "injectJavaScriptResource" : "sendUrl"](
            t,
            n || (() => {})
          );
        },
        n = (e, t) => {
          const n = Hn({ url: e });
          e = Ln((e = n || e));
          at.getAggregator()
            .request("omidVerificationClient")
            .sendUrl(e.toString(), t || (() => {}));
        },
        i = (e, t) => {
          const n = at.getAggregator().request("omidVerificationClient"),
            i = Hn({ url: e });
          (e = Ln((e = i || e))),
            n.injectJavaScriptResource(e, t || (() => {}));
        },
        r = (e) => {
          const t = oe.adTag && oe.adTag.asid;
          if (Je(e)) e({ iasImpId: t });
          else if (e && "string" == typeof e) {
            const i = "function" == typeof e.trim ? e.trim() : e;
            if (0 === i.indexOf("function"))
              try {
                jn({ trimmedString: i, iasImpId: t });
              } catch (e) {}
            else {
              const t = new On(e, !0).toString();
              n(t);
            }
          }
        },
        o = (t, n, r, o) => {
          i(e.wrap(t, n, r, o));
        };
      return (
        at
          .getAggregator()
          .on({ addNode: t, send: n, exec: i, notify: r, jsonp: o }),
        { addNode: t, send: n, exec: i, notify: r, jsonp: o }
      );
    };
  class qn {
    static checkIfFirstPartyBlockingApplies({ impressionUrl: e }) {
      let t = !1;
      if (e && Xn.isBlocking() && !Xn.isDomless() && Xn.isAMZN())
        try {
          const n = new URL(e);
          let i = n.searchParams.get("fpb");
          if (!i || "true" !== i) {
            const e = n.searchParams.get("redirectUrl");
            if (e) {
              const t = decodeURIComponent(e);
              i = new URL(t).searchParams.get("fpb");
            }
          }
          t = "true" === i;
        } catch (e) {}
      return t;
    }
    static modifyUrlForFirstPartyBlocking({ impressionUrl: e }) {
      let t;
      if (e) {
        const n = at.getAggregator().request("mobileApp"),
          i = Xn.isAMZN(),
          r = n.isMobileAppEnvironment()
            ? Gn({ impressionUrl: e, isAMZN: i })
            : Bn({ impressionUrl: e, isAMZN: i });
        t = r ? `${r.toString()}&` : void 0;
      }
      return t;
    }
  }
  const Wn = ({ isAMZN: e }) => ({
      hostName: e ? "vfw.amazon-adsystem.com" : "static.adsafeprotected.com",
      passPath: e ? "ias/s/111.js" : "111.js",
      failPath: e ? "ias/s/111a.js" : "111a.js",
      pathSegment: e ? "amazon" : "st",
    }),
    Bn = ({ impressionUrl: e, isAMZN: t }) => {
      let n;
      try {
        const i = (({ url: e }) => {
          var t, n;
          const i = new URL(e),
            r = i.protocol.replace(":", ""),
            o = i.host,
            s = i.search,
            a = i.pathname.split("/"),
            c = a.indexOf("rfw");
          return {
            protocol: r,
            host: o,
            upToRfwPath: a.slice(0, c + 1).join("/"),
            advEntityId: null !== (t = a[c + 2]) && void 0 !== t ? t : "",
            pubEntityId: null !== (n = a[c + 3]) && void 0 !== n ? n : "",
            search: s,
          };
        })({ url: e });
        if (i) {
          const {
            protocol: r,
            host: o,
            upToRfwPath: s,
            advEntityId: a,
            pubEntityId: c,
            search: d,
          } = i;
          if (r && o && s && a && c) {
            const {
                hostName: i,
                passPath: u,
                failPath: l,
                pathSegment: g,
              } = Wn({ isAMZN: t }),
              m = `${r}://${o}${s}/${g}/${a}/${c}/${u}${d}`,
              p = `${r}://${i}/${l}`,
              h = new URL(m),
              f = new URL(p),
              v = new URL(e).searchParams.get("fpbmn");
            v && "fpba" !== v && f.searchParams.set("fpbmn", v),
              h.searchParams.set("adsafe_pb", f.toString()),
              (n = h);
          }
        }
      } catch (e) {}
      return n;
    },
    Gn = ({ impressionUrl: e, isAMZN: t }) => {
      let n;
      try {
        n = new URL(e);
        const i = n.protocol,
          { hostName: r, passPath: o, failPath: s } = Wn({ isAMZN: t }),
          a = `${i}//${r}/${o}`,
          c = `${i}//${r}/${s}`,
          d = new URL(c),
          u = new URL(a),
          l = n.searchParams.get("fpbmn");
        l &&
          "fpba" !== l &&
          (d.searchParams.set("fpbmn", l), u.searchParams.set("fpbmn", l)),
          n.searchParams.set("redirectUrl", u.toString()),
          n.searchParams.set("passback", d.toString());
      } catch (e) {}
      return n;
    },
    Hn = ({ url: t }) => {
      const n = e.iasProxyPartnerDomain;
      let i, r, o;
      if ("string" == typeof t) r = t;
      else
        try {
          r = t.toString();
        } catch (e) {}
      if (
        r &&
        ((o = r.includes("jsconfig.adsafeprotected.com/jsconfig")),
        Xn.isMSFT() && !o && n && "string" == typeof n)
      ) {
        i = `https://${n}${encodeURIComponent(r)}`;
      }
      return i;
    },
    $n = () => ({
      advEntityId: (oe.adTag && oe.adTag.advEntityId) || "",
      pubEntityId: (oe.adTag && oe.adTag.pubEntityId) || "",
    }),
    zn = ({ search: e }) => {
      try {
        return f({ search: `?${e}` }).xsId || "";
      } catch (e) {
        return "";
      }
    },
    Xn = (function (t) {
      let n = "undefined" == typeof window;
      const i = function () {
          return n;
        },
        r = void 0 !== t && "undefined" != typeof top && t !== top,
        o = (function () {
          let e = !1;
          if (i()) e = !0;
          else
            try {
              e = !!top.document;
            } catch (e) {}
          return e;
        })(),
        s = function () {
          return i() || Ye(_i.getWindow().mraid);
        },
        a = function () {
          return !i() && Ye(_i.getWindow().mraid);
        },
        c = function () {
          const e = at.getAggregator(),
            t = e.request("omidVerificationClient");
          let n = !1;
          const i = e.request("omidAdSessionContext");
          return t && i && (n = "video" === i.mediaType), n;
        },
        d = function () {
          let e = !1;
          if (!i()) {
            const t = "inmobi",
              n = "IASDocumentVideoBuffer",
              i = "addVideoEventListener",
              r = _i.getWindow()[t],
              o = r && r[n],
              s = r && o && Je(o[i]);
            e = a() && !!s;
          }
          return e;
        },
        u = function () {
          return e && e.adsafeSrc && e.adsafeSrc.indexOf("xmtp=v") > -1;
        },
        l = function () {
          const t =
              (e.mode && e.mode.includes("jsvid")) ||
              (oe.adTag.tagType && oe.adTag.tagType.includes("jsvid")),
            n =
              ((e.mode && e.mode.includes("amtjs")) ||
                (oe.adTag.tagType && oe.adTag.tagType.includes("amtjs"))) &&
              e.videoId &&
              "" !== e.videoId,
            i =
              "jload" === oe.adTag.tagType &&
              ((e.videoId && "" !== e.videoId) ||
                (oe.measurementConfig &&
                  oe.measurementConfig.videoId &&
                  "" !== oe.measurementConfig.videoId));
          return Boolean(t || n || i || c() || d() || u());
        },
        g = function () {
          return !1 === e.fwMonitoring || "false" === e.fwMonitoring;
        },
        m = function () {
          return e.mobOrTab;
        },
        p = function (t) {
          if (!(e.customViewability instanceof Array)) return !1;
          return (
            Ze(e.customViewability).filter(function (e, n) {
              return Xi.contains(n.id, t);
            }).length > 0
          );
        },
        h = function () {
          return e.use100v;
        },
        f = function () {
          return p("grpm") || h();
        },
        v = function () {
          return (
            Qe(e.iasProxyPartnerDomain) &&
            -1 !== e.iasProxyPartnerDomain.indexOf("bing")
          );
        };
      return {
        embedded: r,
        friendly: o,
        isFriendlyToParent: function (e) {
          let t, n, r;
          if (i()) t = !0;
          else {
            try {
              (r = On(e.document.referrer)),
                (n = r.hostname === e.location.hostname);
            } catch (e) {}
            t = n;
          }
          return t;
        },
        friendlyIframe: r && o,
        xDomainIframe: r && !o,
        getTagTime: function () {
          return _i.now() - oe.measurementConfig.birthdate;
        },
        getPageTime: function () {
          let e = "na";
          return (
            !i() &&
              Ye(t.chrome) &&
              Ye(t.chrome.csi) &&
              Je(t.chrome.csi) &&
              (e = _i.round(t.chrome.csi().pageT)),
            e
          );
        },
        isVideo: l,
        isMobileApp: s,
        isSpecifiedAd: function () {
          let t = !1;
          if (!i()) {
            const n =
              (Je(e.contextNode.getAttribute) &&
                e.contextNode.getAttribute("data-ias-container")) ||
              e._cl_adpath;
            t = n && Qe(n);
          }
          return t;
        },
        isCompoundAd: function () {
          let t = !1;
          const n = /\[(.*)\]/;
          if (!i()) {
            const i = e._cl_adpath,
              r = n.exec(i);
            t = null !== r && 0 !== r[1].length && r[1].split(",").length > 1;
          }
          return t;
        },
        isOmid: function () {
          const t = at.getAggregator().request("omidVerificationClient");
          return t && t.isSupported() && !e.videoId;
        },
        isOmidNative: function () {
          return new ko().accepts();
        },
        isOmidSandboxedEnvironment: function () {
          return new ko().accepts();
        },
        isOmidForWeb: function () {
          return new Zr().accepts();
        },
        isOmidVideo: c,
        isOmidAudio: function () {
          const e = at.getAggregator(),
            t = e.request("omidVerificationClient");
          let n = !1;
          const i = e.request("omidAdSessionContext");
          return t && i && (n = "audio" === i.creativeType), n;
        },
        isDomless: i,
        isBustedIframe: function () {
          let e = !1;
          return i() || (e = void 0 !== ys()), e;
        },
        isMraid: a,
        isSafeFrame: function () {
          let e = !1;
          return (
            i() ||
              (e =
                Ze(_i.getWindow().$sf).isObj(!1) &&
                Ze(_i.getWindow().$sf.ext).isObj(!1)),
            e
          );
        },
        isInMobiMraidVideo: d,
        isDeviceTypeGroupMobile: m,
        usesIASFullyInViewCustomMetric: function () {
          return p("fiv") || h() || !f();
        },
        usesGroupMCustomMetric: f,
        isCeltra: function () {
          let e = !1;
          return i() || (e = Ts().isApplicable()), e;
        },
        usesGroupMCustomMetricMobilePassThru: function () {
          return f() && m();
        },
        usesZeroPivCustomMetric: function () {
          if (!(e.customViewability instanceof Array)) return !1;
          return (
            Ze(e.customViewability).filter(function (e, t) {
              return !!Ze(t.thresholds).findFirst(function (e, t) {
                return 0 === t.piv;
              });
            }).length > 0
          );
        },
        isRefreshable: function (e) {
          try {
            const t = _i.getTop();
            window.addEventListener(
              "message",
              function (t) {
                /isRefreshable/g.test(t.data) && e(null, t && t.data);
              },
              !1
            ),
              t.postMessage(
                JSON.stringify({ requestTop: "isRefreshable" }),
                "*"
              );
          } catch (t) {
            e(t);
          }
        },
        isPossiblyRefreshable: function () {
          return !i() && !s() && !l() && r && "jload" === oe.adTag.tagType;
        },
        integratedBlockingApplies: function (t) {
          let n,
            i,
            r,
            o,
            s = !1;
          e.contextNode &&
            Je(e.contextNode.getAttribute) &&
            ((n = e.contextNode.getAttribute("data-ias-check-tag")),
            (i = e.contextNode.getAttribute("data-ias-check-done")),
            (r = e.contextNode.getAttribute("data-ias-callback".toString())),
            (o = r && Je(_i.getWindow()[r])));
          const a = Ye(JSON) && Je(JSON.parse),
            c =
              e.integration &&
              (t.indexOf("skeleton.js") > 0 || t.indexOf("/internal/") > 0),
            d = !0 === e.fwMonitoring || "true" === e.fwMonitoring;
          return (
            a &&
              c &&
              ("true" === n && "true" !== i && o
                ? ((s = !0),
                  d &&
                    at
                      .getAggregator()
                      .trigger("addOutputItem", { output: "imgb" }, "smm", {
                        type: "impression",
                      }))
                : ((s = !1),
                  d ||
                    at
                      .getAggregator()
                      .trigger("addOutputItem", { output: "ibgm" }, "smm", {
                        type: "impression",
                      }))),
            s
          );
        },
        isBlocking: g,
        isBlockingSizmekTag: function () {
          return g() && Xi.contains(e.scriptUrl, "bs.serving-sys.com");
        },
        isVastAudio: function () {
          return e && e.adsafeSrc && e.adsafeSrc.indexOf("xmtp=a") > -1;
        },
        isVastVideo: u,
        isAMZN: function () {
          return (
            Qe(e.iasProxyPartnerDomain) &&
            -1 !== e.iasProxyPartnerDomain.indexOf("amazon")
          );
        },
        isMSFT: v,
        isPageOnShadowDomWhitelist: function () {
          let t = !1;
          return (
            (v() ||
              (function () {
                var t;
                const n =
                  (null === (t = oe.contextNode) || void 0 === t
                    ? void 0
                    : t.src) ||
                  (e.contextNode && e.contextNode.src);
                return (
                  (Qe(e.scriptUrl) &&
                    e.scriptUrl.includes("ias_searchshadowdom=true")) ||
                  (Qe(n) && n.includes("ias_searchshadowdom=true"))
                );
              })() ||
              (Qe(e.iasProxyPartnerDomain) &&
                -1 !== e.iasProxyPartnerDomain.indexOf("integral.local"))) &&
              (t = !0),
            t
          );
        },
        doesPageAllowAppendedScripts: function () {
          let e = !0;
          return v() && (e = !1), e;
        },
      };
    })(t),
    Yn = (e) => {
      "use strict";
      return function (t) {
        const n = t.relatedTarget;
        this === n ||
          ((e, t) => {
            if (e === t) return !1;
            let n = t;
            for (; n && n !== e; ) n = n.parentNode;
            return n === e;
          })(this, n) ||
          e.call(this, t);
      };
    },
    Jn = {
      addEvent: (e, t, n, i) => {
        "use strict";
        Ye(e.addEventListener) &&
          ("mouseenter" === t
            ? e.addEventListener("mouseover", Yn(n), i)
            : "mouseleave" === t
            ? e.addEventListener("mouseout", Yn(n), i)
            : e.addEventListener(t, n, i));
      },
      removeEvent: (e, t, n) => {
        "use strict";
        Ye(e.removeEventListener) &&
          ("mouseenter" === t
            ? ((t = "mouseover"), (n = Yn))
            : "mouseleave" === t && ((t = "mouseout"), (n = Yn)),
          e.removeEventListener(t, n));
      },
      getStyle: (e, t, i) => {
        "use strict";
        let r,
          o = "";
        if (((i = i || ""), n.defaultView && n.defaultView.getComputedStyle)) {
          try {
            r = n.defaultView.getComputedStyle(e, i);
          } catch (e) {}
          o = r ? r.getPropertyValue(t) : o;
        } else
          e.currentStyle &&
            ((t = t.replace(/-(\w)/g, (e, t) => t.toUpperCase())),
            (o = e.currentStyle[t]));
        return o;
      },
      getXHR2: () => {
        "use strict";
        let e, n;
        return (
          Ye(t.XMLHttpRequest)
            ? ((n = new XMLHttpRequest()), "withCredentials" in n && (e = n))
            : Ye(window.XDomainRequest) && (e = new window.XDomainRequest()),
          e
        );
      },
      whenReady: (e, t) => {
        "use strict";
        if (Xn.isDomless())
          return void _i.setTimeout(() => {
            e();
          }, 50);
        const i = t || (Xn.xDomainIframe ? n : _i.getTop().document);
        ((e) => {
          const t = () => {
            e(!0);
          };
          Je(n.addEventListener)
            ? "complete" == i.readyState ||
              "loaded" == i.readyState ||
              "interactive" == i.readyState
              ? _i.execAtEndOfThread(t)
              : Jn.addEvent(i, "DOMContentLoaded", t, !1)
            : ((e) => {
                const t = _i.setInterval(() => {
                  i.body && (_i.clearInterval(t), e());
                }, 50);
              })(e);
        })(e);
      },
      isSandboxed: (e) => {
        "use strict";
        let t;
        const n = _i.getWindow();
        let i = !1;
        if ("sandbox" in _i.getDoc().createElement("iframe")) {
          try {
            t = n.frameElement;
          } catch (e) {
            t = null;
          }
          i = t
            ? t.hasAttribute("sandbox")
            : (() => {
                let t = !1;
                const n = _i.getDoc();
                if (e.browserIs("c"))
                  try {
                    n.domain = "hol@#3+~";
                  } catch (e) {
                    /Assignment is forbidden for sandboxed iframes/.test(
                      e.message
                    ) && (t = !0);
                  }
                return t;
              })();
        }
        return i;
      },
      styleElement: (e, t) => {
        "use strict";
        if (!e || !Ze(e.style).isObj() || !Ze(t).isObj()) return;
        let n = "";
        Ze(t).each((e, t) => {
          n += e + ": " + t + " !important;";
        }),
          (e.style.cssText = n);
      },
    },
    Qn = function (e) {
      "use strict";
      const t = Qn.callTypeCounter,
        n = ["a"],
        i = -1,
        r = -2,
        o = -3,
        s = -4,
        a = -5,
        c = -6,
        d = -7,
        u = -8,
        l = -10,
        g = -11,
        m = (() => {
          let m = {
            u: i,
            a: r,
            v: o,
            m: s,
            b: a,
            i: c,
            qf: d,
            l: u,
            s: l,
            as: g,
          }[e];
          const p = t && t[e];
          return (
            Ye(p) && 0 !== p && -1 !== n.indexOf(e) && (m = m + "." + p),
            (() => {
              const n = t[e];
              t[e] = Ye(n) ? n + 1 : 1;
            })(),
            m
          );
        })();
      return { callType: e, enumerator: m };
    };
  Qn.callTypeCounter = {};
  const Kn = ({ url: t }) => {
      const { advEntityId: n, pubEntityId: i } = $n(),
        r = (() => {
          let t = "";
          return (
            e.staticFwjsMacros && (t = zn({ search: e.staticFwjsMacros })),
            !t &&
              e.adsafeSrc &&
              (t = zn({ search: e.adsafeSrc.split("?")[1] || "" })),
            t
          );
        })();
      t.setParam("advEntityId", n),
        t.setParam("pubEntityId", i),
        r && t.setParam("xsId", r);
    },
    Zn = function (e, t, n, i, r, o, s, a) {
      "use strict";
      let c,
        d,
        u = 0,
        l = 0,
        g = !1,
        m = !1,
        p = !1;
      let h = !1;
      const f = (e, t, o, a, c, f) => {
          var v, y;
          let A = !1;
          o = o || !n.on("postDts");
          const I =
            "b" === e ||
            "a" === e ||
            "s" === e ||
            "xs" === e ||
            "x" === e ||
            "l" === e ||
            "as" === e ||
            (h && "e" === e);
          if (i.impressionIsIdentifiable() && (I || "n" !== s.getCurrentLoc()))
            try {
              const i =
                  null === (v = oe.baseUrls) || void 0 === v
                    ? void 0
                    : v.ctvEnrichmentUrl,
                s =
                  i ||
                  (null === (y = oe.baseUrls) || void 0 === y
                    ? void 0
                    : y.dtBaseUrl),
                I = new On(s, !0),
                S = _i.now(),
                T = h
                  ? (() => {
                      const e = [];
                      return (
                        r.iterate((t, n) => {
                          var i;
                          (null === (i = null == n ? void 0 : n.props) ||
                          void 0 === i
                            ? void 0
                            : i.singleEventMarkerItem) &&
                            e.push({ outputKey: t, markerItem: n });
                        }),
                        e
                      );
                    })()
                  : [];
              at.getAggregator().trigger("preSendDt", e),
                T.length &&
                  T.forEach(({ outputKey: e, markerItem: t }) => {
                    var n, i, o;
                    const s =
                      null === (n = r.getItem) || void 0 === n
                        ? void 0
                        : n.call(r, e);
                    if (!s || s === t) return;
                    const a =
                        null === (i = t.item) || void 0 === i
                          ? void 0
                          : i.output,
                      c =
                        null === (o = s.item) || void 0 === o
                          ? void 0
                          : o.output;
                    a &&
                      "object" == typeof a &&
                      c &&
                      "object" == typeof c &&
                      at
                        .getAggregator()
                        .trigger(
                          "addOutputItem",
                          { output: Object.assign(Object.assign({}, a), c) },
                          e,
                          Object.assign({}, t.props)
                        );
                  }),
                s || (I.path("dt"), n.on("usedtdomain") && I.sub("dt")),
                b(I, e, t),
                c && c.field && I.setParam(c.field, c.value),
                a || w(I, e),
                i && Kn({ url: I }),
                m && !a
                  ? (d.push({
                      url: I,
                      dtCallTime: _i.now() - S,
                      additionalCallback: f,
                      useImg: o,
                    }),
                    (A = !0))
                  : p ||
                    (at.getAggregator().trigger(
                      "send",
                      I,
                      () => {
                        (l += 1), (u = _i.now() - S), Je(f) && f();
                      },
                      o
                    ),
                    (A = !0)),
                "u" === e && (g = !0),
                r.cleanup();
            } catch (t) {
              __IntegralASDiagnosticCall("dt-" + e, t),
                at.getAggregator().trigger("error", "h");
            }
          return A;
        },
        v = () => {
          if (g) return;
          f("u", -1, !0);
        },
        y = (e, t) => {
          const i = {
              bapi: "a",
              bapiClient: "b",
              jload: "c",
              jss: "d",
              jsi: "e",
            },
            r = i[e] || i[oe.adTag.tagType];
          (t = t || oe.adTag.tagType + "Diag"),
            n.on(t) && r && f("b", -5, !0, !0, { field: "bkp", value: r });
        },
        b = (e, t, n) => {
          const o = new Qn(t),
            s = Ye(n) ? n : o.enumerator;
          e.setParam("asId", oe.adTag && oe.adTag.asid);
          const a = {
            c: i.getCacheBustId(),
            pingTime: s,
            time: Xn.getTagTime(),
            type: t,
          };
          m && (a.qd = 1);
          r.filterOutput((e) => {
            const n = e.minDt && (!e.type || e.type === t);
            return n && e.oneTime && (e.flagForRemoval = !0), n;
          }, a),
            e.setParam("tv", h ? an({ value: a }) : a);
        },
        w = (e, i) => {
          let c, d;
          const g = {};
          r.filterOutput(
            (e) => e.standalone && !e.minDt && e.type === i,
            (t, n) => {
              e.setParam(t, n.replace(/%3A/g, ":"));
            }
          ),
            s.fastForward(),
            ((e) =>
              "c" === e ||
              "u" === e ||
              "m" === e ||
              "pf" === e ||
              "p" === e ||
              "v" === e ||
              "a" === e)(i) &&
              ((g.clog = a),
              Xn.isVideo() &&
                ((d = Xn.isOmid()
                  ? "omidVideoEventsString"
                  : "videoEventsString"),
                (c = at.getAggregator().request(d)),
                c && !c.isEmpty() && (g.ve = c))),
            "u" === i && (g.ndt = l),
            oe.adTag &&
              -1 !== oe.adTag.tagType.indexOf("jsvid") &&
              (g.vv = at.getAggregator().request("videoVersion")),
            (g.NULL1 = n.output()),
            (g.NULL2 = s.stringify(10)),
            (g.em = Xn.embedded),
            (g.fr = Xn.friendly),
            (g.e = t.toString()),
            (g.tt = oe.adTag.tagType),
            (g.dtt = u),
            r.filterOutput((e) => {
              const t = !(e.standalone || e.minDt || (e.type && e.type !== i));
              return t && e.oneTime && (e.flagForRemoval = !0), t;
            }, g),
            e.setParam("tv", h ? an({ value: g }) : g),
            e.setParam("br", o.getBrowserType());
        };
      return (
        at.getAggregator().on({
          sendDt: (e, t, n) => {
            f(e, rt(t), void 0, void 0, void 0, n);
          },
          sendMinDt: (e, t, n) => {
            f(e, t, void 0, !0, n);
          },
          sendSanitizedDt: (e, t, n) => {
            h = !0;
            try {
              f(e, rt(t), void 0, void 0, void 0, n)
                ? Se()
                : (r.iterate((e, t) => {
                    var n;
                    (null === (n = null == t ? void 0 : t.props) || void 0 === n
                      ? void 0
                      : n.singleEventMarkerItem) &&
                      (t.props.flagForRemoval = !0);
                  }),
                  r.cleanup());
            } finally {
              h = !1;
            }
          },
          sendDiag: y,
          updateDtCount: () => {
            l++;
          },
          unload: v,
          dtEnterQueuingMode: () => {
            (d = []), (m = !0);
          },
          dtExitQueuingMode: () => {
            d &&
              d.forEach((e) => {
                at.getAggregator().trigger(
                  "send",
                  e.url,
                  () => {
                    (l += 1), (u = e.dtCallTime);
                  },
                  e.useImg
                );
              }),
              (m = !1),
              (d = void 0);
          },
          dtReportDtsNotAllowed: ({
            tcfData: e,
            gdprApplies: t,
            canMeasure: n,
          }) => {
            (p = !0), (m = !1), (d = []);
            const i =
              "https://fw.adsafeprotected.com/tc-data/asId=" +
              (oe.adTag && oe.adTag.asid) +
              "&tcfData=" +
              e +
              "&gdprApplies=" +
              t +
              "&canMeasure=" +
              n;
            at.getAggregator().trigger("send", i, !1, !0);
          },
        }),
        {
          send: f,
          unload: v,
          diagnostic: y,
          setViewabilityMod: (e) => {
            c = e;
          },
        }
      );
    },
    ei = function (e) {
      "use strict";
      let n = {},
        i = !1;
      const r = (e) => 1 === e.nodeType,
        o = () => {
          const t = r(e) ? oi.nodeIsHidden(e) : 0 === e.width || 0 === e.height;
          return !i && t;
        },
        s = () => {
          const e = {};
          return (
            Ze(n).each((t, n) => {
              e[t] = _i.round(n);
            }),
            e
          );
        },
        a = (e) => ot(e) || void 0 === e,
        c = () => _i.round(n.width) * _i.round(n.height);
      return (
        (() => {
          if (e !== t.parent)
            if (r(e)) {
              if (Ye(e.getBoundingClientRect)) {
                const t = oi.getRect(e);
                Ze(n).mixin({
                  x: t.x || t.scrX,
                  y: t.y || t.scrY,
                  scrX: t.scrX,
                  scrY: t.scrY,
                  width: t.width,
                  height: t.height,
                });
              }
            } else n = e;
        })(),
        {
          hasValidDims: () =>
            a(n.scrX) && a(n.scrY) && ot(n.width) && ot(n.height),
          toString: () => {
            const e = s();
            return [e.scrX, e.scrY, e.width, e.height].join(".");
          },
          getRounded: s,
          getRoundedGeometry: () => {
            const e = {};
            return (
              Ze(n).each((t, n) => {
                const i = t;
                e[i] =
                  "x" === i || "y" === i || "width" === i || "height" === i
                    ? _i.round(n)
                    : n;
              }),
              e
            );
          },
          set: (e, t) => {
            n[e] = t;
          },
          isHidden: o,
          treatAsPlaceholder: () => {
            i = !0;
          },
          area: c,
          isMrcLarge: () => c() >= 242500,
          isOneByOne: () => o() && c() <= 1,
        }
      );
    },
    ti = ["CANVAS", "EMBED", "IMG", "OBJECT", "PICTURE", "SVG", "VIDEO"],
    ni = (e, t) => {
      "use strict";
      return e.getAttribute(t);
    },
    ii = (e, t) => {
      "use strict";
      let n;
      const i = t || _i.getDoc();
      try {
        n = i.getElementsByTagName(e);
      } catch (e) {
        n = null;
      }
      return n;
    },
    ri = (e, t) => {
      const n = [];
      try {
        if (e.querySelectorAll) {
          const i = e.querySelectorAll(t);
          i.length && n.push(...Array.from(i));
        }
        const i = e.shadowRoot;
        if (null == i ? void 0 : i.querySelectorAll) {
          const e = i.querySelectorAll(t);
          e.length && n.push(...Array.from(e));
        }
        if (e.children)
          for (const i of Array.from(e.children)) {
            const e = i.shadowRoot;
            if (e && e.querySelectorAll) {
              const i = e.querySelectorAll(t);
              i.length && n.push(...Array.from(i));
            }
          }
      } catch (e) {}
      return n;
    },
    oi = {
      findElementsWithSize: (e) => {
        "use strict";
        const t = [],
          n = (e) => {
            oi.getNodeArea(e) < 1
              ? Array.prototype.forEach.call(e.children, (e) => {
                  n(e);
                })
              : t.push(e);
          };
        return n(e), t;
      },
      nodeIsHidden: function (e) {
        "use strict";
        const t = this.getRect(e),
          n = 0 !== parseInt(Jn.getStyle(e, "width")) && 0 === t.width,
          i = 0 === t.width || 0 === t.height,
          r = "hidden" === Jn.getStyle(e, "visibility");
        return n || i || r;
      },
      calcWinDims: () => {
        "use strict";
        let e;
        try {
          const t = oi.browserWindowPosition(),
            n = oi.windowSize();
          e = {
            scrX: _i.round(t.scrX),
            scrY: _i.round(t.scrY),
            width: _i.round(n.width),
            height: _i.round(n.height),
          };
        } catch (t) {
          at.getAggregator().trigger("error", "w"), (e = {});
        }
        return e;
      },
      windowSize: () => {
        "use strict";
        const e = {};
        if (Xn.isDomless()) return { width: 0, height: 0 };
        if (Xn.friendly) {
          const t = top.document,
            n = t.documentElement,
            i = t.body;
          if (Ye(top.innerWidth))
            (e.width = top.innerWidth), (e.height = top.innerHeight);
          else if (Ye(n.clientWidth))
            (e.width = n.clientWidth), (e.height = n.clientHeight);
          else {
            if (!Ye(i.clientWidth))
              throw (
                ((e.width = e.height = 0),
                "Can't find window size; set width and height to 0")
              );
            (e.width = i.clientWidth), (e.height = i.clientHeight);
          }
        } else
          Ye(t.outerWidth) &&
            ((e.width = t.outerWidth), (e.height = t.outerHeight));
        return e;
      },
      browserWindowPosition: () => {
        "use strict";
        let e = t.screenX,
          n = t.screenY;
        return (
          at.getAggregator().request("browser").browserIs("g") &&
            -8 == e &&
            -8 == n &&
            ((e += 8), (n += 8)),
          { scrX: e, scrY: n }
        );
      },
      getNodeArea: (e) => {
        "use strict";
        let t = -1;
        if (e) {
          const n = oi.getRect(e);
          t = n.width * n.height;
        }
        return t;
      },
      getRect: (e) => {
        "use strict";
        const t = {},
          n = oi.browserWindowPosition(),
          i = e.getBoundingClientRect();
        return (
          void 0 === i.x && ((t.x = i.left), (t.y = i.top)),
          void 0 === i.width &&
            ((t.width = i.right - i.left), (t.height = i.bottom - i.top)),
          Ze(t).mixin(i, !0),
          (t.scrX = n.scrX + t.x),
          (t.scrY = n.scrY + t.y),
          t
        );
      },
      getPlaceholderSpan: () => {
        "use strict";
        const e = n.createElement("span");
        return (
          Ze(e.style).mixin({
            width: "0px",
            height: "0px",
            display: "block",
            overflow: "hidden",
            visibiility: "hidden",
          }),
          (e.innerHTML = oe.trustedTypesPolicy.createHTML(".")),
          e
        );
      },
      createImage: () => {
        "use strict";
        const e = Xn.friendly && _i.getTop().Image;
        return Je(e) ? new e() : new Image();
      },
      createHiddenIframe: (e) => {
        "use strict";
        const t = _i.getDoc().createElement("iframe"),
          n = e
            ? { display: "none" }
            : {
                width: "0px",
                height: "0px",
                border: "0",
                position: "absolute",
                top: "-10000px",
                left: "-10000px",
              };
        return Jn.styleElement(t, n), (t.tabIndex = -1), t;
      },
      tagNameIs: (e, t) => {
        "use strict";
        return e.tagName.toUpperCase() === t.toUpperCase();
      },
      getClippedDimensions: (e, t) => {
        "use strict";
        let i = 1e4,
          r = 1e4;
        const o =
            "absolute" === Jn.getStyle(e, "position") ||
            !(!e.style || "absolute" !== e.style.position),
          s = !oi.tagNameIs(e, "OBJECT");
        if (null !== e.parentNode && !o && s && !oi.tagNameIs(t, "BODY")) {
          let o = e;
          do {
            o = o.parentNode;
            const e = !oi.tagNameIs(o, "OBJECT"),
              t = "inline" !== Jn.getStyle(o, "display");
            if (e && t) {
              const e = oi.getRect(o);
              (i = e.width < i ? e.width : i),
                (r = e.height < r ? e.height : r);
            }
          } while (o.parentNode !== n && o !== t);
        }
        return { width: _i.round(i), height: _i.round(r) };
      },
      hasBackgroundImage: (e) => {
        const t = Jn.getStyle(e, "background-image");
        return "" !== t && "none" !== t;
      },
      isEmptyFriendlyFrame: (e) => {
        try {
          let t = !1;
          if (e && e.document) {
            const n = e && "IFRAME" === e.nodeName && e.contentDocument;
            if (n) {
              const e = n.body;
              e && e.childElementCount < 1 && (t = !0);
            }
          }
          return t;
        } catch (e) {
          return !1;
        }
      },
      findChildWithLargestContent: (e, t) => {
        const n = at
            .getAggregator()
            .request("mobileApp")
            .isMobileAppEnvironment(),
          i = at.getAggregator().request("omidAdSessionContext"),
          r = i && i.hasOwnProperty("ignoreDivAsCandidate"),
          o = oi.hasBackgroundImage,
          s = (e) => {
            let t = !0;
            return (
              ("visible" === Jn.getStyle(e, "overflow") ||
                ("visible" === Jn.getStyle(e, "overflowX") &&
                  "visible" === Jn.getStyle(e, "overflowY"))) &&
                (t = !1),
              t
            );
          },
          a = ((t) => {
            let n = null,
              i = -1,
              s = null;
            if (t.length)
              for (let c = 0, d = t.length; c < d; c++) {
                const d = t[c],
                  u = oi.getNodeArea(d);
                let l = !(
                  (a = d).parentNode === e &&
                  "DIV" === a.nodeName &&
                  !o(a) &&
                  ("0" === Jn.getStyle(a, "opacity") ||
                    "hidden" === Jn.getStyle(a, "visibility") ||
                    (() => {
                      let e = !1;
                      const t = a.childNodes;
                      for (let n = 0; n < t.length; n++)
                        1 === t[n].nodeType && (e = !0);
                      return !e;
                    })())
                );
                l && r && "DIV" === d.nodeName && (l = !1);
                const g = oi.isEmptyFriendlyFrame(d),
                  m =
                    "A" === d.nodeName &&
                    0 === d.childElementCount &&
                    !o(d) &&
                    "IMG" === s;
                u > i && l && !g && !m && ((n = d), (i = u), (s = d.nodeName));
              }
            var a;
            return n && (n.hasValidSizeForMobileApp = i > 1), n;
          })(
            oi.collectCandidateElements(
              e,
              t || "iframe,img,a,object,embed,div".split(",")
            )
          );
        let c = null;
        return (
          a &&
            ((c = ((t) => {
              let i = t,
                o = t;
              for (
                ;
                o.parentNode !== e &&
                "inline" !== Jn.getStyle(o.parentNode, "display");

              )
                (!n || (s(o.parentNode) && oi.getNodeArea(o.parentNode) > 0)) &&
                  ((n && r && "DIV" === o.parentNode.nodeName) ||
                    (i = o.parentNode)),
                  (o = o.parentNode);
              return i;
            })(a)),
            (c.hasValidSizeForMobileApp = a.hasValidSizeForMobileApp)),
          c
        );
      },
      screenSize: () => {
        "use strict";
        if (Xn.isDomless()) return { width: 0, height: 0 };
        let e = { width: -1, height: -1 };
        try {
          Ye(t.screen) &&
            (e = { width: t.screen.width, height: t.screen.height });
        } catch (e) {}
        return e;
      },
      calcMonDims: () => {
        "use strict";
        let e = Ze(oi.screenSize()).mixin({ scrX: 0, scrY: 0 });
        return (
          Ye(screen.availLeft) &&
            (e = {
              scrX: t.screen.availLeft,
              scrY: t.screen.availTop,
              width: t.screen.availWidth,
              height: t.screen.availHeight,
            }),
          e
        );
      },
      getOurNodeInTop: () => {
        "use strict";
        let t;
        if (Xn.friendly)
          if (Xn.embedded) {
            const e = (() => {
              let e;
              const t = _i.getTop();
              let n = _i.getWindow();
              for (; n != t; ) (e = n), (n = e.parent);
              return e;
            })();
            t = e && e.frameElement;
          } else t = e.contextNode;
        return t;
      },
      getAncestorNodes: (e) => {
        "use strict";
        const t = [],
          n = e.ownerDocument && e.ownerDocument.documentElement;
        let i = e;
        if (n)
          for (; (i.parentNode || i.host) !== n; )
            t.push(i), (i = i.parentNode || i.host);
        return t;
      },
      containsScriptTagWithSrc: (e) => {
        "use strict";
        return !!Array.prototype.find.call(ii("script") || [], (t) => {
          const n = t.src;
          return Je(e) ? e(n) : n === e;
        });
      },
      querySelector: (e, t) => {
        "use strict";
        let n;
        try {
          n = e.querySelector(t);
        } catch (e) {
          n = null;
        }
        return n;
      },
      nodeIsInWindow: (e, t) => {
        "use strict";
        if (!e.ownerDocument) return !1;
        const n = e.ownerDocument;
        return (n.defaultView || n.parentWindow) === t;
      },
      setAttributeOf: (e, t, n) => {
        "use strict";
        e && Je(e.setAttribute) && e.setAttribute(t, n);
      },
      removeAttributeOf: (e, t) => {
        "use strict";
        e && Je(e.removeAttribute) && e.removeAttribute(t);
      },
      crossQuerySelector: (t, n) => {
        "use strict";
        let i;
        const r = [e.contextNode.parentNode, _i.getDoc()];
        if ((Xn.friendly && r.push(_i.getTop().document), n && Xn.embedded))
          try {
            r.push(_i.getWindow().frameElement.ownerDocument);
          } catch (e) {}
        return (
          r.forEach((e) => {
            try {
              const n = oi.querySelector(e, t);
              !i && n && (i = n);
            } catch (e) {}
          }),
          i
        );
      },
      getNodeName: (e) => {
        "use strict";
        return e && e.nodeName;
      },
      isWindow: (e) => {
        "use strict";
        let t = !1;
        try {
          t = !!e && "object" == typeof e && "setInterval" in e;
        } catch (e) {
          t = !0;
        }
        return !!t;
      },
      getChildWindowsOf: (e) => {
        "use strict";
        let t = [];
        const n = ii("iframe", e);
        return n && (t = Ze(n).map((e, t) => t.contentWindow)), t;
      },
      getFrameId: () => {
        "use strict";
        const e = _i.getWindow().frameElement;
        return e && e.id;
      },
      isViewportVisible: (e, t) => {
        "use strict";
        const n = e.innerWidth,
          i = e.innerHeight,
          r = n * i > t.width * t.height,
          o = n > t.width && i > t.height;
        return r && o;
      },
      attributeMatches: (e, t, n) => {
        "use strict";
        const i = e && ni(e, t);
        return n.test(i);
      },
      isImageTag: (e) => {
        "use strict";
        return !!(e && e.src && oi.tagNameIs(e, "img"));
      },
      getDimensionFromStyle: (e) => {
        "use strict";
        let t;
        const n = Jn.getStyle(e, "width"),
          i = Jn.getStyle(e, "height");
        return n && i && (t = { width: it(n), height: it(i) }), t;
      },
      getDimensionFromAttributes: (e) => {
        "use strict";
        let t;
        const n = ni(e, "width"),
          i = ni(e, "height");
        return n && i && (t = { width: it(n), height: it(i) }), t;
      },
      traverseAndFindFirstMatchingNode: function e(t, n) {
        "use strict";
        let i;
        if (n(t)) i = t;
        else {
          const r = t.children;
          if (r) for (let t = 0; t < r.length && ((i = e(r[t], n)), !i); t++);
        }
        return i;
      },
      isClippable: (e, t) => {
        "use strict";
        let n = !0;
        const i = "fixed" === Jn.getStyle(e, "position"),
          r = !("hidden" === Jn.getStyle(t, "overflow")) && !i;
        return Xn.isSpecifiedAd() && (i || r) && (n = !1), n;
      },
      isNodeCreative: (e) => {
        "use strict";
        const t = oi.getNodeName(e),
          n = e && e.children && 0 === e.children.length,
          i = e && e.innerText && e.innerText.length > 0,
          r = n && i,
          o = t && -1 !== ti.indexOf(t.toUpperCase());
        return !!t && !!(o || oi.hasBackgroundImage(e) || r);
      },
      getElementsWindow: (e) => {
        "use strict";
        const t = ((e) => {
          return e.ownerDocument || e;
        })(e);
        return t.defaultView || t.parentWindow || e;
      },
      elementIsEmbedded: (e) => {
        "use strict";
        return oi.getElementsWindow(e) !== _i.getTop();
      },
      getParent: (e) => {
        "use strict";
        return e.parentNode || e.parent;
      },
      isNodeXDomainIframe: (e) => {
        "use strict";
        let t = !1;
        if (e && "IFRAME" === oi.getNodeName(e))
          try {
            t = !e.contentWindow.document;
          } catch (e) {
            t = !0;
          }
        return t;
      },
      collectCandidateElements: (e, t) => {
        const n = [],
          i = t,
          r = Xn.isPageOnShadowDomWhitelist();
        for (let t = 0, o = i.length; t < o; t++) {
          const o = i[t].toLowerCase();
          let s = Array.from(
            (e.getElementsByTagName && e.getElementsByTagName(o)) || []
          );
          if (r) {
            const t = ri(e, o);
            t && t.length && (s = [...new Set([...s, ...t])]);
          }
          for (let e = 0, t = s.length; e < t; e++) n.push(s[e]);
        }
        return n;
      },
    },
    si = function () {
      "use strict";
      const e = {},
        t = (t) => {
          Ye(e[t]) ? (e[t] = e[t] + 1) : (e[t] = 1);
        };
      return (
        at.getAggregator().on("error", (e) => {
          const n =
            "object" != typeof e || null === e || e instanceof Array
              ? e
              : e.errorCode;
          t(n);
        }),
        {
          list: e,
          add: t,
          toString: () => {
            let t = "";
            for (const n in e) e.hasOwnProperty(n) && (t += n);
            return t;
          },
          hasErrors: () => {
            for (const t in e) return !0;
            return !1;
          },
        }
      );
    },
    ai = function () {
      "use strict";
      return {
        createInstance: function (e, t) {
          return Xn.isDomless() ? new di() : new ci(e, t);
        },
      };
    },
    ci = function (t, n) {
      "use strict";
      return {
        parse: function (i) {
          try {
            const t = (function (t) {
                if (t && t instanceof Array) {
                  const n = oe.baseUrls,
                    i = n.cmEventBaseUrl,
                    r = n.fwEventBaseUrl,
                    o = t.map(function (e) {
                      return e.val;
                    });
                  return o.push(r, i, e.reqquery), o;
                }
                throw new Error(
                  "Unexpected data type in ExchangeParser.getUrlList"
                );
              })(i),
              r = t && t.length && t.join("|"),
              o = e.exchList;
            if (r) {
              const e = Object.keys(o).filter(function (e) {
                return r.indexOf(Xi.rot(o[e])) >= 0;
              });
              e.length &&
                n.addItem({ output: e.join(".") }, "ex", {
                  type: "impression",
                });
            }
          } catch (e) {
            t.add("x");
          }
        },
      };
    },
    di = function () {
      "use strict";
      return { parse: function (e) {} };
    },
    ui = function () {
      "use strict";
      const t = {},
        n = function (n) {
          let i, r, o, s;
          return (
            void 0 === t[n] &&
              ((i = e.jsFeatures),
              (t[n] = !1),
              -1 !== i.indexOf(n) &&
                ((r = new RegExp(
                  n + "(?=$|,)|" + n + ":(?!,|$)(.?\\d*(?=,|$))"
                ).exec(i)),
                r &&
                  ((o = r[1]), (s = !o), (t[n] = s || o > 100 * _i.random())))),
            t[n]
          );
        },
        i = {
          es: "everySecond",
          sc: "usesca",
          ha: "usehaps",
          fgad: "forceKeepGoogleAdNode",
        },
        r = {
          fif: "useFIF",
          gmnp: "groupm_native_publisher",
          for: "forceAppend",
          b11: "b11",
          cnod: "cnod",
        },
        o = function (t) {
          const n = e[t];
          return -1 !== ["integration"].indexOf(t)
            ? !!n
            : !0 === n || "true" === n || Je(n);
        };
      Ze(i).each(function (e, t) {
        n(t);
      });
      return {
        on: n,
        bootstrapOn: o,
        bootstrapperHas: function (t) {
          const n = Qe(t) ? [t] : t;
          return (
            Ze(n).map(function (t, n) {
              if (n && Ye(e[n])) return 1;
            }).length === n.length
          );
        },
        getEnabledScriptUrl: function (t) {
          const i = n("use" + t),
            r = e.sp_cdnScripts && e.sp_cdnScripts[t];
          return i && r;
        },
        setReportedBootstrapFeatures: function (e, t) {
          r[e] = t;
        },
        reportedBootstrapFeatures: r,
        output: function () {
          return Ze(
            (function () {
              const e = Ze(i).mapToObj(function (e, n) {
                  const i = {};
                  return (i[e] = +!!t[n]), i;
                }),
                n = Ze(r).mapToObj(function (e, t) {
                  const n = {};
                  return (n[e] = +!!o(t)), n;
                });
              return (n.gm = +!!Xn.usesGroupMCustomMetric()), Ze(e).mixin(n);
            })()
          ).toParams();
        },
      };
    },
    li = function () {
      const e = function (e, t) {
        const n = e.getRounded(),
          i = t.getRounded(),
          r = Math.max(n.scrX, i.scrX),
          o = Math.max(n.scrY, i.scrY),
          s = Math.min(n.scrX + n.width, i.scrX + i.width) - r,
          a = Math.min(n.scrY + n.height, i.scrY + i.height) - o;
        return ei({
          scrX: r,
          scrY: o,
          width: s > 0 ? s : 0,
          height: a > 0 ? a : 0,
        });
      };
      return {
        calcInitialViewState: function (e, t) {
          let n = "na";
          const i = t
            ? { IN_VIEW: 65, OUT_OF_VIEW: 25, PARTIAL_VIEW: 30 }
            : { IN_VIEW: 75, OUT_OF_VIEW: 25, PARTIAL_VIEW: 50 };
          return (
            Ye(e) &&
              "na" !== e &&
              e > -1 &&
              (n =
                e >= i.IN_VIEW
                  ? "inView"
                  : e <= i.OUT_OF_VIEW
                  ? "outOfView"
                  : e >= i.PARTIAL_VIEW
                  ? "partialViewPlus"
                  : "partialViewMinus"),
            n
          );
        },
        calcPercentInView: function (t, n, i, r) {
          let o = 0,
            s = t;
          return (
            t.hasValidDims() &&
              !t.isHidden() &&
              ([n, i, r].forEach(function (t) {
                t.hasValidDims() && (s = e(s, t));
              }),
              (o = _i.round((s.area() / t.area()) * 100))),
            o
          );
        },
      };
    },
    gi = 5381,
    mi = () => {
      const e = vi();
      return pi(e);
    },
    pi = (e) =>
      [
        e.slice(0, 8),
        e.slice(8, 12),
        e.slice(12, 16),
        e.slice(16, 20),
        e.slice(20),
      ].join("-");
  let hi;
  const fi = () => {
      var e;
      if (hi) return hi;
      const n = t,
        i =
          (null === (e = n.navigator) || void 0 === e ? void 0 : e.userAgent) ||
          "" ||
          (({ scope: e }) => {
            var t, n, i, r;
            const o =
                (null === (t = e.navigator) || void 0 === t
                  ? void 0
                  : t.userAgent) || "",
              s =
                (null === (n = e.screen) || void 0 === n ? void 0 : n.width) ||
                0,
              a =
                (null === (i = e.screen) || void 0 === i ? void 0 : i.height) ||
                0,
              c =
                (null === (r = e.screen) || void 0 === r
                  ? void 0
                  : r.colorDepth) || 0,
              d = e.devicePixelRatio || 0;
            return `${o}${s * gi}${a * gi}${c * gi}${d * gi}`;
          })({ scope: n });
      let r = gi;
      for (let e = 0; e < i.length; e++) r = (33 * r + i.charCodeAt(e)) >>> 0;
      const o = String(r % 1e4);
      return (hi = ("0000" + o).slice(-4)), hi;
    },
    vi = function () {
      var e;
      let n = "";
      try {
        let i;
        const r = 16,
          o = 32,
          s = t,
          a = !!(s.Uint32Array && s.crypto && s.crypto.getRandomValues);
        for (; n.length < o; )
          a
            ? ((i = new Uint32Array(1)),
              null === (e = s.crypto) || void 0 === e || e.getRandomValues(i),
              void 0 !== i[0] && (n += i[0].toString(r)))
            : (n += ((_i.random() * r) | 0).toString(r));
        (n = n.slice(0, o)), (n = n.slice(0, 12) + fi() + n.slice(16));
      } catch (e) {
        const t = at.getAggregator();
        t && t.trigger("error", "i");
      }
      return n;
    };
  class yi {
    constructor() {
      (this.impIsIdentifiable = !1),
        (this.getCacheBustId = () => {
          const e = new Date(),
            t = Date.parse(`Jan 1 ${e.getFullYear()}`),
            n = e.getTime() - t;
          return tt(n, 62);
        }),
        (this.impressionIsIdentifiable = (e) => (
          e && (this.impIsIdentifiable = !0), this.impIsIdentifiable
        )),
        (this.getAsid = () => {
          var e;
          return (null === (e = oe.adTag) || void 0 === e ? void 0 : e.asid)
            ? String(oe.adTag.asid)
            : "";
        }),
        (this.getAnId = () => (oe.adTag && oe.adTag.anId) || ""),
        (this.getFwId = () => {
          const e = (oe.adTag && oe.adTag.advEntityId) || "",
            t = (oe.adTag && oe.adTag.pubEntityId) || "";
          return this.getAnId() || e + "-" + t;
        });
    }
    get unq() {
      return this.getAsid();
    }
  }
  const bi = function (e, t) {
      "use strict";
      return {
        init: function (n) {
          e.jsonp(
            n,
            function (e) {
              t.send("i", void 0, !1, !0, { field: "tpiLookup", value: e });
            },
            !1,
            "callback"
          );
        },
      };
    },
    wi = function (e, n, i, r, o) {
      "use strict";
      return {
        getTime: function () {
          return 1e3 * e.getTimeInViewInSeconds();
        },
        getTask: function () {
          return o
            ? function () {
                const t = at.getAggregator().request("adRenderStatus"),
                  i = r || n,
                  o = e.getTimeInViewInSeconds();
                t ||
                  at
                    .getAggregator()
                    .trigger("addThrottledProp", "env", "nr_" + i, o);
              }
            : function () {
                const o = e.getTimeInViewInSeconds(),
                  s = e.getTimeInViewForRts();
                if (
                  (Ye(r) &&
                    (at
                      .getAggregator()
                      .trigger("addOutputItem", { output: r }, "metricId", {
                        type: n,
                      }),
                    at
                      .getAggregator()
                      .trigger("addOutputItem", { output: "t" }, "cmr", {
                        type: n,
                      })),
                  Xn.isMSFT() && o > 0)
                )
                  try {
                    t.postMessage(
                      { name: "pingTime", origin: "ias", value: o },
                      "*"
                    );
                  } catch (e) {}
                at.getAggregator().trigger("sendDt", n, o), i[s] && i[s]();
              };
        },
      };
    },
    Ai = function () {
      "use strict";
      return {
        createPingJobs: function (e, t, n, i, r) {
          return t.getTimeThresholds().map(function (t) {
            return new wi(t, e, n, i, r);
          });
        },
      };
    },
    Ii = function () {
      let e;
      const t = [],
        n = function (e) {
          const t = (null == e ? void 0 : e.videoEvent) || e,
            n = "type",
            i = "t",
            r = "timestamp";
          return {
            type: t["tp"] || t[n] || "",
            time: t[i] || (t[r] && t[r] - oe.measurementConfig.birthdate) || "",
          };
        },
        i = function () {
          e || (e = at.getAggregator().request("viewabilityDefinitions")),
            e &&
              0 == t.length &&
              e.forEach(function (e) {
                e.qivThreshold && t.push(e);
              });
        },
        r = function (e, t) {
          at
            .getAggregator()
            .trigger("addOutputItem", { output: e.metricId }, "metricId", {
              type: "c",
            }),
            at
              .getAggregator()
              .trigger("addOutputItem", { output: "q" }, "cmr", { type: "c" }),
            at.getAggregator().trigger("sendDt", "c", t),
            e.rtsCallbacks && Je(e.rtsCallbacks.qiv) && e.rtsCallbacks.qiv();
        };
      return {
        init: function () {
          i(),
            at.getAggregator().on("videoQuartileEvent", function (e) {
              i(),
                (function (e) {
                  const i = new n(e),
                    o = [
                      "_",
                      "firstQuartile",
                      "midpoint",
                      "thirdQuartile",
                      "complete",
                    ],
                    s = o.indexOf(
                      o.find(function (e) {
                        return (
                          -1 !== i.type.toLowerCase().indexOf(e.toLowerCase())
                        );
                      })
                    ),
                    a = at
                      .getAggregator()
                      .request("mScreenEvents")
                      .getCurrentEvent(),
                    c = Math.floor(i.time / 1e3);
                  t.forEach(function (e) {
                    let t = !1;
                    const n = e.qivThreshold.indexOf(s);
                    -1 !== n &&
                      e.isInView(a) &&
                      e.qivThreshold.length > 0 &&
                      (e.qivThreshold.splice(n, 1),
                      (t = 0 == e.qivThreshold.length),
                      t && r(e, c));
                  });
                })(e);
            });
        },
      };
    },
    Si = function (e) {
      const t = e && (e.tp || e.type);
      return t ? t.toLowerCase() : "";
    },
    Ti = function (e) {
      let t;
      return (
        e && "number" == typeof e.t
          ? (t = e.t)
          : e &&
            "number" == typeof e.timestamp &&
            (t = e.timestamp - oe.measurementConfig.birthdate),
        "number" != typeof t || Number.isNaN(t) ? Xn.getTagTime() : t
      );
    },
    Ci = function (e, t) {
      return Si(e).includes(t.toLowerCase());
    },
    Oi = function (e, t) {
      return Si(e) === t.toLowerCase();
    },
    Ei = function (e, t) {
      return !!t && e.isInView(t);
    },
    Di = function (e) {
      return !!e && !0 === e.iasCached;
    },
    Mi = function (e) {
      let t;
      if ("number" == typeof e) t = e;
      else if ("string" == typeof e) {
        const n = Number.parseFloat(e);
        Number.isNaN(n) || (t = n);
      }
      return t;
    },
    xi = function (e, t) {
      var n, i, r;
      let o = null == t ? void 0 : t.isSoundOn;
      const s = (null == e ? void 0 : e.data) || {},
        a = Mi(
          null !==
            (r =
              null !==
                (i =
                  null !== (n = s.mediaPlayerVolume) && void 0 !== n
                    ? n
                    : s.videoPlayerVolume) && void 0 !== i
                ? i
                : null == e
                ? void 0
                : e.volume) && void 0 !== r
            ? r
            : null == e
            ? void 0
            : e.adVolume
        ),
        c = Mi(s.deviceVolume);
      return (
        "number" == typeof a
          ? (o = a > 0 && (null == c || c > 0))
          : "number" == typeof c && (o = c > 0),
        o
      );
    },
    Pi = function () {
      var e;
      const t = at.getAggregator().request("ids");
      return !!(null ===
        (e = null == t ? void 0 : t.impressionIsIdentifiable) || void 0 === e
        ? void 0
        : e.call(t));
    },
    Vi = function (e, t) {
      return -1 !== (e.segments || []).indexOf(t);
    },
    Ni = function (e) {
      var t;
      return (
        (null === (t = null == e ? void 0 : e.indicatesCompletion) ||
        void 0 === t
          ? void 0
          : t.call(e)) ||
        Oi(e, "adStopped") ||
        Oi(e, "stopAd") ||
        Oi(e, "stopped") ||
        Oi(e, "adSkipped") ||
        Oi(e, "skipped") ||
        Oi(e, "adError") ||
        Oi(e, "error") ||
        Oi(e, "adUserClose")
      );
    },
    ki = function () {
      "use strict";
      const e = "seconds",
        t = "percentage",
        n = [],
        i = {};
      let r;
      const o = function () {
          const e = at.getAggregator().request("viewabilityDefinitions");
          (n.length = 0),
            e &&
              ((r = e),
              r.forEach(function (e) {
                e.videoPlaybackSegmentRequirements &&
                  e.videoPlaybackSegmentRequirements.length > 0 &&
                  n.push(e);
              }));
        },
        s = function (e) {
          const t = e.metricId;
          return (
            i[t] ||
              (i[t] = {
                hasStarted: !1,
                hasFired: !1,
                activeSegment: 0,
                requirementStates: {},
              }),
            i[t]
          );
        },
        a = function (e) {
          const t = s(e);
          (t.hasStarted = !0),
            (t.hasFired = !1),
            (t.activeSegment = 0),
            (t.requirementStates = {}),
            e.videoPlaybackSegmentRequirements.forEach(function (e, n) {
              (t.requirementStates[n] = {}),
                e.segments.forEach(function (e) {
                  t.requirementStates[n][e] = {
                    isSatisfied: !1,
                    accumulatedTimeInView: 0,
                    consecutiveTimeInView: 0,
                    maxConsecutiveTimeInView: 0,
                    lastMeasurementTime: 0,
                    segmentStartTime: 0,
                    segmentDuration: 0,
                    wasInView: !1,
                  };
                });
            });
        },
        c = function (e, t, n) {
          var i;
          return null === (i = s(e).requirementStates[t]) || void 0 === i
            ? void 0
            : i[n];
        },
        d = function (n, i) {
          const r =
            n.requirementType === t
              ? i.segmentDuration * (n.requirementValue / 100)
              : 1e3 * n.requirementValue;
          if (n.requirementType === t) {
            const e = r - Math.min(250, 0.1 * r);
            i.isSatisfied =
              i.segmentDuration > 0 && i.accumulatedTimeInView >= e;
          } else
            n.requirementType === e &&
              (i.isSatisfied = i.maxConsecutiveTimeInView >= r - 250);
        },
        u = function (t, n, i) {
          const r = s(t);
          r.hasStarted &&
            !r.hasFired &&
            t.videoPlaybackSegmentRequirements.forEach(function (o, s) {
              if (Vi(o, r.activeSegment)) {
                const a = c(t, s, r.activeSegment);
                !(function (e, t, n, i) {
                  const r = Ei(e, n);
                  if (t.wasInView) {
                    const e = i - t.lastMeasurementTime;
                    (t.accumulatedTimeInView += e),
                      (t.consecutiveTimeInView += e),
                      (t.maxConsecutiveTimeInView = Math.max(
                        t.maxConsecutiveTimeInView,
                        t.consecutiveTimeInView
                      ));
                  }
                  r || (t.consecutiveTimeInView = 0),
                    (t.wasInView = r),
                    (t.lastMeasurementTime = i);
                })(t, a, n, i),
                  o.requirementType === e && d(o, a);
              }
            });
        },
        l = function (e, t, n, i) {
          (s(e).activeSegment = t),
            e.videoPlaybackSegmentRequirements.forEach(function (r, o) {
              if (Vi(r, t)) {
                const r = c(e, o, t);
                r &&
                  ((r.segmentStartTime = i),
                  (r.lastMeasurementTime = i),
                  (r.wasInView = Ei(e, n)));
              }
            });
        },
        g = function (e, t, n) {
          const i = s(e).activeSegment;
          u(e, t, n),
            e.videoPlaybackSegmentRequirements.forEach(function (t, r) {
              if (Vi(t, i)) {
                const o = c(e, r, i);
                (o.segmentDuration = n - o.segmentStartTime), d(t, o);
              }
            });
        },
        m = function (e) {
          let t = !0;
          return (
            e.videoPlaybackSegmentRequirements.forEach(function (n, i) {
              (function (e, t, n) {
                let i = !1;
                return (
                  t.segments.forEach(function (t) {
                    const r = c(e, n, t);
                    (null == r ? void 0 : r.isSatisfied) && (i = !0);
                  }),
                  i
                );
              })(e, n, i) || (t = !1);
            }),
            t
          );
        },
        p = function (e, t) {
          const n = s(e);
          !n.hasFired &&
            m(e) &&
            ((n.hasFired = !0),
            (function (e, t) {
              at
                .getAggregator()
                .trigger("addOutputItem", { output: e.metricId }, "metricId", {
                  type: "c",
                }),
                at
                  .getAggregator()
                  .trigger("addOutputItem", { output: "q" }, "cmr", {
                    type: "c",
                  }),
                at.getAggregator().trigger("sendDt", "c", Math.floor(t / 1e3)),
                e.rtsCallbacks &&
                  Je(e.rtsCallbacks.qiv) &&
                  e.rtsCallbacks.qiv();
            })(e, t));
        },
        h = function (e) {
          const t = s(e);
          (t.hasStarted = !1), (t.activeSegment = 0);
        },
        f = function (e) {
          const t = (null == e ? void 0 : e.videoEvent) || e,
            i =
              (null == e ? void 0 : e.screenEvent) ||
              at.getAggregator().request("mScreenEvents").getCurrentEvent();
          if (Di(t) && !(null == e ? void 0 : e.screenEvent)) return;
          o();
          const r = (function (e, t) {
              return e
                ? Object.assign(Object.assign({}, e), {
                    isVideoPlaying: !0,
                    isSoundOn: xi(t, e),
                  })
                : e;
            })(i, t),
            s = Ti(t);
          n.forEach(function (e) {
            a(e), l(e, 1, r, s);
          });
        },
        v = function (e) {
          o();
          const t = Xn.getTagTime();
          n.forEach(function (n) {
            u(n, e, t), p(n, t);
          });
        },
        y = function (e) {
          const t = (null == e ? void 0 : e.videoEvent) || e;
          if (Di(t)) return;
          o();
          const i =
              (null == e ? void 0 : e.screenEvent) ||
              at.getAggregator().request("mScreenEvents").getCurrentEvent(),
            r = Ti(t),
            a = (function (e) {
              let t;
              return (
                Ci(e, "firstQuartile")
                  ? (t = 2)
                  : Ci(e, "midpoint")
                  ? (t = 3)
                  : Ci(e, "thirdQuartile") && (t = 4),
                t
              );
            })(t);
          n.forEach(function (e) {
            const n = s(e);
            n.hasStarted &&
              ((a && a <= n.activeSegment) ||
                (g(e, i, r),
                p(e, r),
                a ? l(e, a, i, r) : Ci(t, "complete") && h(e)));
          });
        },
        b = function (e) {
          const t = at.getAggregator().request("omidAdSessionContext"),
            i = null == t ? void 0 : t.cachedVideoSegmentEvents,
            r = i ? i.indexOf(e) : -1;
          if (!Pi()) return;
          r > -1 && i.splice(r, 1);
          const c = (function (e) {
              return e && (e.videoEvent || e);
            })(e),
            d = (function (e) {
              return null == e ? void 0 : e.screenEvent;
            })(e);
          if (Oi(c, "start")) {
            o();
            const e = Ti(c);
            n.forEach(function (t) {
              a(t), l(t, 1, d, e);
            });
          } else if (
            (function (e) {
              return (
                Oi(e, "start") ||
                Oi(e, "firstQuartile") ||
                Oi(e, "midpoint") ||
                Oi(e, "thirdQuartile") ||
                Oi(e, "complete")
              );
            })(c)
          )
            y(
              Object.assign(Object.assign({}, c), {
                iasCached: !1,
                screenEvent: d,
              })
            );
          else if (Ni(c)) {
            o();
            const e = Ti(c);
            n.forEach(function (t) {
              s(t).hasStarted && (g(t, d, e), p(t, e), h(t));
            });
          } else {
            const e = Ti(c);
            n.forEach(function (t) {
              u(t, d, e), p(t, e);
            });
          }
        },
        w = function (e) {
          const t = (null == e ? void 0 : e.videoEvent) || e,
            i =
              (null == e ? void 0 : e.screenEvent) ||
              at.getAggregator().request("mScreenEvents").getCurrentEvent(),
            r = Ti(t);
          o(),
            n.forEach(function (e) {
              const n = s(e);
              if (Ni(t) && n.hasStarted) return g(e, i, r), p(e, r), void h(e);
              u(e, i, r), p(e, r);
            });
        },
        A = function () {
          const e = at.getAggregator().request("omidAdSessionContext"),
            t = null == e ? void 0 : e.cachedVideoSegmentEvents;
          if (t && t.length > 0) {
            if (!Pi()) return;
            t.slice().forEach(function (e) {
              b(e);
            });
          }
        };
      return {
        init: function () {
          o(),
            at.getAggregator().on("videoStartEvent", f),
            at.getAggregator().on("newScreenEvent", v),
            at.getAggregator().on("videoPlaybackStateEvent", w),
            at.getAggregator().on("videoQuartileEvent", y),
            at.getAggregator().on("cachedOmidVideoSegmentEvent", b),
            at.getAggregator().on("impressionsent", A),
            Pi() && A();
        },
      };
    },
    Fi = function () {
      "use strict";
      const e = () => {
        const e = oe.adTag && oe.adTag.asid;
        return (
          "__IntegralAS_" +
          ((e && e.replace(/-/g, "")) || "") +
          "_" +
          _i.round(1e4 * Math.random())
        );
      };
      return {
        wrap: (n, i, r, o) => {
          const s = e();
          let a, c, d;
          ((e, t) => new RegExp(t).test(e))(
            (n = "" + n),
            (o = o || "ias_callback")
          ) &&
            ((a = ((e, t) => new RegExp("(" + t + "=)(.[^&]*)").exec(e)[0])(
              n,
              o
            )),
            (c = a.split("=")[1]),
            (d = Xi.stringToFn(c)),
            (n = ((e, t) => (
              -1 !== e.indexOf(t + "&") && (t += "&"), e.replace(t, "")
            ))(n, a)));
          const u = oe.measurementConfig.isStaticFrameInFrame
            ? oe.contextNode.element.contentWindow
            : t;
          return (
            (u[s] = (e) => {
              i(e), r && d && d(e), (u[s] = void 0);
            }),
            (n = ((e, t, n) => {
              const i = e.indexOf("?"),
                r = t + "=" + n;
              if (-1 === i) return e + "?" + r;
              {
                const t = i + 1;
                return e.slice(0, t) + r + "&" + e.slice(t);
              }
            })(n, o, s)),
            n
          );
        },
        wrapToGlobal: (n) => {
          const i = e();
          return (
            (t[i] = (e) => {
              n(e), (t[i] = void 0);
            }),
            i
          );
        },
      };
    },
    Ri = function (t, n, i) {
      "use strict";
      const r = (t, n) => {
        let i = t;
        if (n) {
          const r = "," + Ze(n).stringify((e, t) => e + ":" + t, ",");
          (i = On(t, !0)),
            i.appendToParamValue(
              "adsafe_jsinfo",
              st(r, e.encodeInvalidUrlChars)
            ),
            (i = i.toString());
        }
        return i;
      };
      let o = !1;
      try {
        const t =
          (void 0 !== e.videoId && e.videoId && "" !== e.videoId) ||
          (oe.measurementConfig &&
            oe.measurementConfig.videoId &&
            "" !== oe.measurementConfig.videoId);
        o = Xn.isVideo() && !Xn.isOmid() && t;
      } catch (e) {}
      const s = {
        jss: {
          isFW: !0,
          nodeType: Xn.doesPageAllowAppendedScripts() ? "script" : "img",
        },
        rjss: {
          isFW: !0,
          onloadCallback: Sa,
          impressionMethod: function (e) {
            var t, n, i, r;
            if (xe()) {
              const o = {
                  type: "e",
                  oneTime: !0,
                  minDt: !0,
                  singleEventMarkerItem: !0,
                },
                s = ((e) => {
                  const t = hn(e);
                  if (!t) return;
                  const n = {};
                  for (const e of t) {
                    const t = e.indexOf(":");
                    if (-1 === t) return;
                    n[e.slice(0, t)] = gn(e.slice(t + 1));
                  }
                  return Object.keys(n).length > 0 ? n : void 0;
                })({
                  impressionUrl: e,
                  recordedPieces:
                    null === (t = oe.singleEventImpressionJsInfo) ||
                    void 0 === t
                      ? void 0
                      : t.getPieces(),
                });
              if (s)
                Object.keys(s).forEach((e) => {
                  at.getAggregator().trigger(
                    "addOutputItem",
                    { output: s[e] },
                    e,
                    o
                  );
                });
              else {
                const t = fn({
                  impressionUrl: e,
                  recordedPieces:
                    null === (n = oe.singleEventImpressionJsInfo) ||
                    void 0 === n
                      ? void 0
                      : n.getPieces(),
                });
                t &&
                  at
                    .getAggregator()
                    .trigger(
                      "addOutputItem",
                      { output: t },
                      "NULL_SINGLE_EVENT_IMPRESSION_JSINFO",
                      o
                    );
              }
              let a = {};
              try {
                null === (i = oe.mraidLifecycleTracker) ||
                  void 0 === i ||
                  i.refresh("recovery"),
                  (a = Me());
              } catch (e) {}
              try {
                const e =
                  null === (r = oe.mraidLifecycleTracker) || void 0 === r
                    ? void 0
                    : r.getSnapshot();
                (null == e ? void 0 : e.mraidEverObserved) &&
                  at
                    .getAggregator()
                    .trigger(
                      "addOutputItem",
                      { output: e.mraidExists ? "0" : "1" },
                      "mi",
                      o
                    );
              } catch (e) {}
              at
                .getAggregator()
                .trigger(
                  "addOutputItem",
                  { output: Object.assign({ seir: 1 }, a) },
                  "im",
                  Object.assign(Object.assign({}, o), { asION: !0 })
                ),
                at.getAggregator().trigger("sendSanitizedDt", "e", 0);
            } else if (
              Xn.isAMZN() &&
              Xn.isBlocking() &&
              oe.measurementConfig.staticMode
            )
              at
                .getAggregator()
                .trigger("addOutputItem", { output: !0 }, "ablk"),
                at.getAggregator().trigger(
                  "jsonp",
                  e + "&format=jsonp",
                  (e) => {
                    const { nodeType: t, creativeUrl: n } = e,
                      i =
                        "i" === oe.measurementConfig.tagDeliveryType
                          ? "iframe"
                          : "unknown" === t
                          ? "script"
                          : t;
                    at.getAggregator().trigger("addNode", i, n);
                  },
                  !1,
                  "cbName"
                );
            else {
              let t = "script";
              const n = oe.measurementConfig.impressionNodeType,
                i = "i" === oe.measurementConfig.tagDeliveryType,
                r =
                  !Xn.doesPageAllowAppendedScripts() ||
                  ("string" == typeof n && "img" === n);
              i ? (t = "iframe") : r && (t = "img"),
                at.getAggregator().trigger("addNode", t, e, Sa);
            }
          },
        },
        amtjs: {
          isFW: !0,
          manualDefer: Xn.isVideo(),
          impressionMethod: function (t) {
            Xn.isVideo()
              ? at.getAggregator().on("adImpression", (n, i) => {
                  let o;
                  try {
                    (o = r(t, i)),
                      at.getAggregator().trigger("send", o, nt, !0);
                  } catch (t) {
                    __IntegralASDiagnosticCall("amtjsvidimp", t, e);
                  }
                })
              : at.getAggregator().trigger("addNode", "img", t);
          },
        },
        jsi: { isFW: !0, nodeType: "iframe" },
        rjsi: { isFW: !0, nodeType: "iframe" },
        jload: {
          manualDefer: o,
          impressionMethod: function (i) {
            o
              ? at.getAggregator().on("adImpression", (o, s) => {
                  let a;
                  try {
                    (a = r(i, s)),
                      t.enabled
                        ? at.getAggregator().trigger("jsonp", a, t.callback, !0)
                        : at
                            .getAggregator()
                            .trigger("send", a, nt, !n.on("postMon"));
                  } catch (t) {
                    __IntegralASDiagnosticCall("jloadvidimp", t, e);
                  }
                })
              : t.enabled
              ? at.getAggregator().trigger("jsonp", i, t.callback, !0)
              : at.getAggregator().trigger(
                  "send",
                  i,
                  () => {
                    Sa(), at.getAggregator().trigger("sendDiag");
                  },
                  !n.on("postMon")
                );
          },
        },
        bapi: {
          impressionMethod: function (e) {
            const n = t.enabled ? t.callback : nt,
              i = !!t.enabled;
            at.getAggregator().trigger("jsonp", e, n, i);
          },
        },
        jsapi: {
          isFW: !0,
          impressionMethod: function (e) {
            const n = t.enabled ? t.callback : nt,
              i = !!t.enabled;
            at.getAggregator().trigger("jsonp", e, n, i);
          },
        },
        jsvid: {
          manualDefer: !0,
          impressionMethod: function (i) {
            at.getAggregator().on("adImpression", (o, s) => {
              let a;
              try {
                (a = r(i, s)),
                  t.enabled
                    ? at.getAggregator().trigger("jsonp", a, t.callback, !0)
                    : at
                        .getAggregator()
                        .trigger("send", a, nt, !n.on("postMon"));
              } catch (t) {
                __IntegralASDiagnosticCall("jsvidimp", t, e);
              }
            });
          },
        },
        fwjsvid: {
          isFW: !0,
          manualDefer: !0,
          impressionMethod: function (t) {
            const n = "false" === e.fwMonitoring;
            n &&
              at.getAggregator().trigger(
                "jsonp",
                ((e) => {
                  const t = e.split("/");
                  return (
                    Xn.isAMZN()
                      ? ((t[6] = "fw"), (t[7] = "db2"), (t[8] = "video"))
                      : ((t[3] = "db2"), (t[4] = "video")),
                    t.join("/")
                  );
                })(t),
                (e) => {
                  at.getAggregator().trigger("videoBlockResult", e);
                }
              ),
              at.getAggregator().on("adImpression", (i, o) => {
                let s;
                try {
                  n &&
                    (a = i) &&
                    "boolean" == typeof a.integral_didBlock &&
                    a.integral_timeToDecision >= 0 &&
                    (t = ((e) => {
                      const n =
                        "$1$2,abc:" +
                        (e.integral_didBlock ? 1 : 0) +
                        ",abct:" +
                        e.integral_timeToDecision;
                      return t.replace(/(adsafe_jsinfo=)([^&]*)/, n);
                    })(i)),
                    (s = r(t, o)),
                    at.getAggregator().trigger("send", s, nt, !0);
                } catch (t) {
                  __IntegralASDiagnosticCall("fwjsvidimp", t, e);
                }
                var a;
              });
          },
        },
        jspix: { nodeType: "img" },
      };
      return new (function () {
        const t = s[oe.adTag.tagType],
          n = !!t.isFW,
          r = ((t) => {
            let n;
            const i = oe.baseUrls;
            return (
              (n =
                at
                  .getAggregator()
                  .request("mobileApp")
                  .isMobileAppEnvironment() && i.mobileAppEventBaseUrl
                  ? i.mobileAppEventBaseUrl
                  : t
                  ? i.fwEventBaseUrl
                  : i.cmEventBaseUrl),
              t || (n += "?" + e.reqquery),
              n
            );
          })(n),
          o = r.indexOf("BEGIN__ADSAFE"),
          a = -1 !== o,
          c = a ? r.slice(o) : "";
        return {
          isFW: n,
          baseUrl: a
            ? r.slice(0, o)
            : ((e) => {
                const t = -1 === e.indexOf("?") ? "?" : "&";
                return e + t;
              })(r),
          macroUrl: c,
          sendImpression: (e) => {
            const n = (e) => {
              at
                .getAggregator()
                .trigger("addOutputItem", { output: Xn.getTagTime() }, "siq"),
                t.nodeType
                  ? at
                      .getAggregator()
                      .trigger("addNode", t.nodeType, e, t.onloadCallback)
                  : t.impressionMethod(e);
            };
            i || t.manualDefer
              ? n(e)
              : t.manualDefer ||
                at.getAggregator().on("adImpression", () => {
                  n(e);
                });
          },
        };
      })();
    },
    ji = function () {
      "use strict";
      return Xn.isDomless() && Xn.isOmid()
        ? at.getAggregator().request("omidVerificationClient")
        : t;
    };
  var _i = {
    execAtEndOfThread: function (e) {
      "use strict";
      _i.setTimeout(e, 0);
    },
    now: function () {
      "use strict";
      return Date.now();
    },
    random: function () {
      "use strict";
      return Math.random();
    },
    round: function (e) {
      "use strict";
      return Math.round(e);
    },
    floor: function (e) {
      "use strict";
      return Math.floor(e);
    },
    min: function () {
      "use strict";
      return Math.min.apply(null, arguments);
    },
    max: function () {
      "use strict";
      return Math.max.apply(null, arguments);
    },
    getWindow: function () {
      "use strict";
      return t;
    },
    setInterval: function (e, t) {
      "use strict";
      return ji().setInterval(e, t);
    },
    setTimeout: function (e, t) {
      "use strict";
      return ji().setTimeout(e, t);
    },
    clearInterval: function (e) {
      "use strict";
      ji().clearInterval(e);
    },
    getTop: function () {
      "use strict";
      return Xn.isDomless(), top;
    },
    getDoc: function () {
      "use strict";
      return Xn.isDomless(), n;
    },
    getIntersectionObserver: function (e, t) {
      "use strict";
      return Xn.isDomless(), new IntersectionObserver(e, t);
    },
    getMutationObserver: function (e) {
      "use strict";
      return Xn.isDomless(), new MutationObserver(e);
    },
    getResizeObserver: function (e) {
      "use strict";
      return Xn.isDomless(), new ResizeObserver(e);
    },
    getTopmostAccessibleWindow: function () {
      "use strict";
      let e = _i.getWindow();
      const t = _i.getTop();
      let n = 0;
      for (; n < 20 && (!t || e !== t); ) {
        try {
          const n = e.parent;
          if (!n || n === e) break;
          if ((n.document, (e = n), t && e === t)) break;
        } catch (e) {
          break;
        }
        n += 1;
      }
      return e;
    },
  };
  const Li = () => {
      if (Xn.isDomless()) return !0;
      const e = _i.getDoc();
      return (
        void 0 !== e.hidden ||
        void 0 !== e.mozHidden ||
        void 0 !== e.msHidden ||
        void 0 !== e.webkitHidden
      );
    },
    Ui = function () {
      "use strict";
      return { createInstance: () => (Xn.isDomless() ? new Wi() : new qi()) };
    },
    qi = function () {
      "use strict";
      let e = !1,
        t = !1;
      at.getAggregator().request("features");
      const n = new Yt(),
        i = () => (Ye(r.prop) ? _i.getDoc()[r.prop] : null),
        r = (() => {
          let t = "hidden",
            n = "visibilitychange";
          const i = _i.getDoc();
          return (
            void 0 === i.hidden
              ? Ze(["moz", "ms", "webkit"]).each((r, o) => {
                  const s = o + "Hidden";
                  Ye(i[s]) && ((t = s), (n = o + n), (e = !0));
                })
              : (e = !0),
            e ? { prop: t, event: n } : {}
          );
        })();
      return {
        isHidden: i,
        onHiddenChange: (e) => {
          e && n.push(e),
            t ||
              ((t = !0),
              (() => {
                const e = _i.getWindow(),
                  t = () => {
                    n.run(i());
                  };
                Jn.addEvent(e, "focus", t, !0),
                  Jn.addEvent(e, "blur", t, !0),
                  r.event && Jn.addEvent(_i.getDoc(), r.event, t, !0);
              })());
        },
        supportsVisAPI: () => e,
      };
    },
    Wi = function () {
      "use strict";
      return {
        isHidden: () => !1,
        onHiddenChange: (e) => {},
        supportsVisAPI: () => !0,
      };
    },
    Bi = function () {
      "use strict";
      return {
        createInstance: function (e, t) {
          return Xn.isDomless() ? new Hi() : new Gi(e, t);
        },
      };
    },
    Gi = function (n, i) {
      "use strict";
      let r;
      const o = function (e) {
          const t = [
            ["ab", "about%3A"],
            ["da", "data%3A"],
            ["js", "javascript%3A"],
            ["fi", "file%3A"],
            ["uu", "uuid-in-package"],
            ["cx", "chrome-extension%3A"],
            ["lo", "http%3A%2F%2Flocalhost"],
            ["lo", "https%3A%2F%2Flocalhost"],
          ];
          if (
            "string" == typeof e &&
            "null" !== e &&
            "" !== e &&
            "undefined" !== e
          ) {
            for (let n = 0; n < t.length; n++)
              if (e.startsWith(t[n][1])) return "";
            if (-1 === e.indexOf("."))
              return (
                at
                  .getAggregator()
                  .trigger(
                    "addOutputItem",
                    { output: e.substring(0, 40) },
                    "bunp",
                    { type: "impression" }
                  ),
                ""
              );
          }
          return e;
        },
        s = function () {
          let s = {};
          try {
            s.a = encodeURIComponent(top.location.href);
          } catch (e) {}
          try {
            s.b = encodeURIComponent(parent.location.href);
          } catch (e) {}
          if (Xn.embedded) {
            try {
              s.c = encodeURIComponent(parent.document.referrer);
            } catch (e) {}
            try {
              s.e = encodeURIComponent(t.document.referrer);
            } catch (e) {}
          }
          try {
            "jsi" !== oe.adTag.tagType &&
              (s.d = encodeURIComponent(t.location.href));
          } catch (e) {}
          try {
            s.f = encodeURIComponent(e.jsref);
          } catch (e) {}
          try {
            const e = i.getWindow();
            s.q = encodeURIComponent(
              e.parent.parent.parent.parent.parent.parent.parent.parent.parent
                .parent.location.href || ""
            );
          } catch (e) {}
          try {
            n.isStarted() &&
              n.getMyFrameDepth() > 1 &&
              (s.g = encodeURIComponent(n.getTopDomain())),
              n.isStarted() &&
                Xn.xDomainIframe &&
                1 === n.getMyFrameDepth() &&
                (s.y = encodeURIComponent(n.getTopDomain()));
          } catch (e) {}
          let a = "not-set";
          try {
            if (Xn.isSafeFrame()) {
              const e = i.getWindow(),
                t = e && e.$sf && e.$sf.ext && e.$sf.ext.hostURL,
                n = "function" == typeof t && t();
              if ("string" == typeof n) {
                a = encodeURIComponent(n);
                let e = !1;
                "function" == typeof URL
                  ? (new URL(n), (e = !0))
                  : n.startsWith("http") && (e = !0),
                  e
                    ? ((s.x = a),
                      at
                        .getAggregator()
                        .trigger("addOutputItem", { output: a }, "sfhu", {
                          type: "impression",
                        }))
                    : at
                        .getAggregator()
                        .trigger("addOutputItem", { output: a }, "sfiv", {
                          type: "impression",
                        });
              }
            }
          } catch (e) {
            at.getAggregator().trigger("addOutputItem", { output: a }, "sfiv", {
              type: "impression",
            });
          }
          (s = (function (e) {
            for (const t in e)
              if (e.hasOwnProperty(t)) {
                const n = o(e[t]);
                ("" !== n && "null" !== n && "undefined" !== n && null != n) ||
                  delete e[t];
              }
            return e;
          })(s)),
            (s = (function (e) {
              const t = {};
              let n, i;
              for (i in e)
                e.hasOwnProperty(i) &&
                  ((n = e[i]), void 0 === t[n] ? (t[n] = i) : (t[n] += i));
              const r = {};
              for (i in t) t.hasOwnProperty(i) && ((n = t[i]), (r[n] = i));
              return r;
            })(s));
          const c = [];
          for (const e in s)
            s.hasOwnProperty(e) && c.push({ key: e, val: s[e] });
          return (
            c.sort(function (e, t) {
              return e.val.length > t.val.length
                ? 1
                : e.val.length < t.val.length
                ? -1
                : 0;
            }),
            (r = c),
            c
          );
        };
      return {
        detectTopURL: s,
        getDetectedURLs: function () {
          return r || s();
        },
      };
    },
    Hi = function () {
      "use strict";
      return {
        detectTopURL: function () {
          return [];
        },
        getDetectedURLs: function () {
          return [];
        },
      };
    },
    $i = function (t) {
      "use strict";
      let n = !1;
      return {
        measure: function (i) {
          (n = 0 === i.rsa), n && t.trigger("notify", e._onSuspicious);
        },
        skipAsFraudulent: function () {
          return n;
        },
      };
    },
    zi = function () {
      "use strict";
      const e = [],
        t = {},
        n = { sl: "n" };
      let i,
        r,
        o,
        s = 0;
      const a = { i: 0, o: 0, n: 0, pp: 0, pm: 0 },
        c = function (e) {
          const t = at.getAggregator().request("features");
          if (t && t.on("recoverOmidLostTime")) {
            const t = a.ri;
            a.ri = t ? t + e : e;
          }
        },
        d = function (e, n) {
          const i = new An(n);
          return (t[e] = i), i;
        },
        u = function (e, t) {
          return (
            (t = t || "") +
            {
              inView: "i",
              outOfView: "o",
              na: "n",
              partialViewMinus: "pm",
              partialViewPlus: "pp",
            }[e]
          );
        },
        l = function () {
          Ze(n).each(function (t, n) {
            const i = e.length ? o - s : o;
            a[n] += i;
          }),
            (s = o);
        },
        g = function (t) {
          e.length && l(),
            Ze(t).each(function (e, t) {
              var i, r;
              (i = t),
                (r = n[e]) !== i && "n" === r && (a[i] += a.n),
                (n[e] = t);
            }),
            e.length || l();
        },
        m = function (e) {
          const n = e.adDimensions
              ? e.adDimensions.getRounded()
              : { width: 0, height: 0 },
            i = (function (e) {
              const t = {},
                n = e.winDimensions,
                i = e.adDimensions;
              Ye(n) && n.hasValidDims() && (t.wc = n),
                Ye(i) &&
                  i.hasValidDims() &&
                  ((t.ac = i),
                  (t.am = e.method),
                  (t.cc = e.containerDimensions)),
                Ze({
                  piv: "percentInView",
                  obst: "obstructed",
                  th: "tabHidden",
                  reas: "reason",
                }).each(function (n, i) {
                  const r = e[i];
                  Ye(r) && (t[n] = r);
                });
              const r = Ze(t).toParams();
              return "" === r ? "" : "," + r;
            })(e),
            s = e.omidObstructions,
            a = { sl: u(e.viewState) };
          (o = Xn.getTagTime()), g(a), (a.t = o);
          const c = Ze({
            toString: function () {
              return (
                Ze(t).each(function (e, t) {
                  t.fastForward();
                }),
                "{" + Ze(a).toParams() + this.details + this.breakdowns + "}"
              );
            },
            details: i,
            breakdowns: {
              piv: [],
              as: [],
              toString: function () {
                let e = "";
                const t = function (e, t) {
                  return t.duration + "~" + t.state;
                };
                return (
                  (e += "piv:[" + Ze(this.piv).stringify(t) + "]"),
                  (e += ",as:[" + Ze(this.as).stringify(t) + "]"),
                  ",bkn:{" + e + "}"
                );
              },
            },
          }).mixin(a);
          return (
            Ze(c).mixin(e),
            (c.width = n.width),
            (c.height = n.height),
            void 0 === c.percentInView && (c.percentInView = -1),
            void 0 === c.reason && (c.reason = ""),
            Ye(s) && "" !== s && (c.omidObstructions = s),
            (r = c),
            c
          );
        };
      return (
        (function () {
          d("piv", function (e) {
            let t;
            const n = e.percentInView,
              i = [1, 25, 30, 50, 75];
            return (
              100 === n || 0 === n
                ? (t = n)
                : (Ze(i).each(function (e, r) {
                    void 0 === t && n < r && (t = i[e - 1]);
                  }),
                  void 0 === t && (t = i[i.length - 1])),
              t
            );
          }),
            d("as", function (e) {
              const t = e.adDimensions
                ? e.adDimensions.getRounded()
                : { width: "na", height: "na" };
              return t.width + "." + t.height;
            });
          const e = at.getAggregator().request("omidAdSessionContext");
          e && e.recoveredTime > -1 && c(e.recoveredTime);
        })(),
        {
          fastForward: function () {
            (o = Xn.getTagTime()), l();
          },
          registerLocation: function (r) {
            let o,
              s = !1;
            return (
              n.sl == u(r.viewState) && e.length
                ? ((o = new m(r)), (e[e.length - 1].details = o.details))
                : ((o = new m(r)), e.push(o), (i = r.viewState), (s = !0)),
              at.getAggregator().trigger("newScreenEvent", o),
              Ze(t).each(function (t, n) {
                -1 !== "piv|as".indexOf(t)
                  ? (s && n.clear(),
                    n.addState(o),
                    (e[e.length - 1].breakdowns[t] = n.get()))
                  : n.addState(o);
              }),
              o
            );
          },
          stringify: function (t) {
            let n = "";
            return (
              e.length &&
                (n = Ze({
                  slTimes: "{" + Ze(a).toParams() + "}",
                  slEvents: "[" + e.slice(-t).join(",") + "]",
                  slEventCount: e.length,
                }).toParams()),
              n
            );
          },
          createViewabilityTracker: d,
          getCurrentLoc: function () {
            return u(i);
          },
          getCurrentEvent: function () {
            return r;
          },
          setRecoveredTimeInSlTimes: c,
          getLatestEvent: function () {
            let t;
            return e && e.length > 0 && (t = e[e.length - 1]), t;
          },
        }
      );
    },
    Xi = {
      hashCode: function (e) {
        "use strict";
        let t,
          n,
          i,
          r = 0;
        if (0 === e.length) return r;
        for (t = 0, i = e.length; t < i; t++)
          (n = e.charCodeAt(t)), (r = (r << 5) - r + n), (r |= 0);
        return r;
      },
      rot: function (e) {
        "use strict";
        return e.replace(/[a-zA-Z]/g, function (e) {
          return String.fromCharCode(
            (e <= "Z" ? 90 : 122) >= (e = e.charCodeAt(0) + 13) ? e : e - 26
          );
        });
      },
      stringToFn: function (e) {
        "use strict";
        let n,
          i,
          r = t;
        const o = e.split(".");
        for (n = 0; n < o.length; n++)
          if (
            ((i = r),
            (r = r[o[n]]),
            void 0 === r || (n === o.length - 1 && !Je(r)))
          )
            return !1;
        return function () {
          r.apply(i, arguments);
        };
      },
      stringToProp: function (e) {
        "use strict";
        let t,
          n,
          i = _i.getWindow();
        const r = e.split(".");
        for (
          t = 0;
          t < r.length && ((n = i), (i = i[r[t]]), void 0 !== i);
          t++
        );
        return i;
      },
      contains: function (e, t) {
        "use strict";
        return !!Qe(e) && -1 !== e.indexOf(t);
      },
    },
    Yi = function () {
      "use strict";
      const e = (function () {
          const e = function (e) {
              return e && e.width && e.width > 30 && e.height && e.height > 30;
            },
            t = function (t) {
              const n = oi.getDimensionFromAttributes(t);
              return e(n);
            };
          return {
            hasValidDimensions: function (n) {
              return (
                t(n) ||
                (function (t) {
                  const n = oi.getDimensionFromStyle(t);
                  return e(n);
                })(n)
              );
            },
            hasValidDimentionAttributes: t,
          };
        })(),
        t = /GoogleActiveViewElement/,
        n = /DfaVisibilityIdentifier_/,
        i = /doubleclick.net\/pcs\/click?/,
        r = /_blank/,
        o = function (e) {
          const t = e && oi.tagNameIs(e, "a"),
            n = oi.attributeMatches(e, "href", i),
            o = oi.attributeMatches(e, "target", r);
          return t && n && o;
        },
        s = function (e) {
          const i = oi.tagNameIs(e, "div"),
            r = oi.attributeMatches(e, "class", t),
            o = oi.attributeMatches(e, "id", n);
          return i && r && o;
        };
      return {
        getDFPGoogleDiv: function (e) {
          return oi.traverseAndFindFirstMatchingNode(e, s);
        },
        getClickableImage: function (t) {
          let n, i;
          const r = oi.traverseAndFindFirstMatchingNode(t, o);
          return (
            r &&
              ((i = r && r.children && r.children[0]),
              oi.isImageTag(i) && e.hasValidDimentionAttributes(i) && (n = i)),
            n
          );
        },
        getNodeMatchingMinimumSize: function (t) {
          return oi.traverseAndFindFirstMatchingNode(t, e.hasValidDimensions);
        },
      };
    },
    Ji = function () {
      "use strict";
      const e = Yi(),
        t = function (e, t) {
          (t.tag = e.tagName.toLowerCase()),
            (t.size =
              oi.getDimensionFromAttributes(e) || oi.getDimensionFromStyle(e));
        };
      return {
        getDFPValue: function (n) {
          let i;
          const r = e.getDFPGoogleDiv(n);
          return (
            (i = r
              ? (function (n) {
                  let i, r;
                  const o = { type: 0 };
                  return (
                    n &&
                      ((o.type = 1),
                      (i = e.getClickableImage(n)),
                      i
                        ? ((o.type = 2), t(i, o))
                        : ((r = e.getNodeMatchingMinimumSize(n)),
                          r && ((o.type = 3), t(r, o)))),
                    o
                  );
                })(r)
              : (function (n) {
                  const i = { type: 0 },
                    r = e.getNodeMatchingMinimumSize(n);
                  return r && ((i.type = 4), t(r, i)), i;
                })(n)),
            i
          );
        },
      };
    },
    Qi = {
      name: "hB",
      dependencies: [],
      creator: function () {
        try {
          const e = Nn().getUserAgent(),
            t = e.length > 0 && -1 !== e.indexOf("HeadlessChrome"),
            n = _i.getWindow(),
            i = _i.getTop(),
            r = !(!i || !i.document) && Object.getOwnPropertyNames(i),
            o = () => {
              var e, t;
              const i = null == n ? void 0 : n.navigator,
                r =
                  null === (e = null == i ? void 0 : i.userAgentData) ||
                  void 0 === e
                    ? void 0
                    : e.brands;
              return (
                (null ===
                  (t =
                    null == r
                      ? void 0
                      : r.map((e) => (null == e ? void 0 : e.brand))) ||
                void 0 === t
                  ? void 0
                  : t.includes("HeadlessChrome")) || !1
              );
            },
            s = {
              cdcP: Ke(
                r && -1 !== r.indexOf("cdc_adoQpoasnfa76pfcZLmcfl_Promise")
              ),
              cdcA: Ke(
                r && -1 !== r.indexOf("cdc_adoQpoasnfa76pfcZLmcfl_Array")
              ),
              cdcS: Ke(
                r && -1 !== r.indexOf("cdc_adoQpoasnfa76pfcZLmcfl_Symbol")
              ),
              cyp: Ke(r && -1 !== r.indexOf("Cypress")),
              wd: Ke(Ye(n.navigator.webdriver) && !0 === n.navigator.webdriver),
              uaHC: Ke(t),
              chHC: Ke(o()),
            },
            a = 1,
            c = (e) => -1 !== Object.values(e).indexOf(a),
            d = function (e) {
              at.getAggregator().trigger(
                "addThrottledProp",
                "sca",
                "hbs",
                Ze(e).toION()
              );
            };
          c(s) && d(s);
        } catch (e) {}
      },
      settings: {
        tier: 4,
        applies: function () {
          "use strict";
          return !0;
        },
      },
    },
    Ki = {
      name: "viewport",
      dependencies: [],
      creator: function () {
        "use strict";
        const e = { width: 4, height: 4 },
          t = function (t) {
            return !oi.isViewportVisible(t, e);
          },
          n = function (e, i) {
            return e !== i && t(e)
              ? e
              : e !== i && Xn.isFriendlyToParent(e)
              ? n(e.parent, i)
              : void 0;
          },
          i = function () {
            const e = _i.getWindow();
            return n(e, _i.getWindow().top);
          },
          r = function () {
            return void 0 !== i();
          };
        return {
          MIN_VISIBLE_DIM: e,
          isHidden: r,
          isCurrentIframeTheHiddenFrame: function () {
            let e;
            const n = _i.getWindow();
            return t(n) ? (e = !0) : r() && (e = !1), e;
          },
          getWindowWithHiddenViewport: i,
        };
      },
    },
    Zi = function (e) {
      "use strict";
      let t, n;
      const i = function (i) {
          (t = e.setInterval(i, 100)),
            (n = e.setTimeout(function () {
              r();
            }, 42e4));
        },
        r = function () {
          t && (e.clearInterval(t), (t = null)),
            n && (e.clearTimeout(n), (n = null));
        };
      return {
        onResize: function (t) {
          let n = e.innerWidth,
            o = e.innerHeight,
            s = !1;
          i(function () {
            const i = (function () {
              const t = e.innerWidth,
                i = e.innerHeight;
              return t !== n || i !== o;
            })();
            i && (s = !0),
              s && !i && (t(), r(), (s = !1)),
              (n = e.innerWidth),
              (o = e.innerHeight);
          });
        },
      };
    },
    er = {
      name: "AS_Finder",
      dependencies: ["viewport"],
      creator: function (e, t) {
        "use strict";
        let n;
        const i = function () {
          try {
            !(function (i) {
              let r;
              const o = {};
              i !== n &&
                ((r = Ke(i)),
                (o.res1 = r),
                (o.ps = r),
                (o.ts = _i.now()),
                (o.psfr = Ke(e.isCurrentIframeTheHiddenFrame())),
                t.events.trigger("newState", o)),
                (n = i);
            })(e.isHidden());
          } catch (e) {
            at.getAggregator().trigger("error", "H2");
          }
        };
        return {
          start: function () {
            e.isHidden() &&
              (i(),
              (function () {
                const t = e.getWindowWithHiddenViewport();
                t && Zi(t).onResize(i);
              })());
          },
        };
      },
      settings: {
        emits: !0,
        applies: function (e, t, n) {
          "use strict";
          return n.embedded && !n.isBustedIframe() && !n.isSpecifiedAd();
        },
      },
    },
    tr = {
      name: "hA",
      dependencies: ["AS_Finder"],
      creator: function (t) {
        "use strict";
        let n = 0;
        const i = function (e, t) {
            at.getAggregator().trigger(
              "addThrottledProp",
              "sca",
              e,
              Ze(t).toION()
            );
          },
          r = function (e) {
            n < 2 && i("ha1", e), n++;
          };
        !(function () {
          let n, o;
          if (Xn.embedded)
            try {
              (o = e.contextNode.parentNode),
                (n = Ji().getDFPValue(o)),
                i(
                  "dfp",
                  (function (e) {
                    const t = {};
                    return (
                      (t.df = e.type),
                      e.size && (t.sz = e.size.width + "." + e.size.height),
                      e.tag && (t.dom = e.tag),
                      t
                    );
                  })(n)
                ),
                n.size && t && (t.events.on("newState", r), t.start());
            } catch (e) {
              at.getAggregator().trigger("error", "H1");
            }
        })();
      },
      settings: {
        tier: 4,
        applies: function (e) {
          "use strict";
          return e.on("usehaps");
        },
      },
    },
    nr = {
      name: "thresholdDetector",
      dependencies: [],
      creator: function () {
        "use strict";
        return {
          create: (e, t, n) => {
            let i;
            let r = t();
            const o = () => {
              const o = t();
              o !== r && !0 && (n(e, o), _i.clearInterval(i)), (r = o);
            };
            r && (n(e, r), (i = _i.setInterval(o, 50)));
          },
        };
      },
    },
    ir = {
      name: "invisibleAds",
      dependencies: ["thresholdDetector"],
      creator: function (t) {
        "use strict";
        const n = { width: 4, height: 4 },
          i = () => {
            const e = Jn.getStyle(_i.getWindow().frameElement, "opacity");
            return parseFloat(e) < 0.2;
          },
          r = () =>
            "hidden" === Jn.getStyle(_i.getWindow().frameElement, "visibility"),
          o = (e, t) => {
            const n = { res1: Ke(t) };
            at.getAggregator().trigger(
              "addThrottledProp",
              "sca",
              e,
              Ze(n).toION()
            );
          };
        try {
          const s = e.contextNode.parentNode,
            a = Ji().getDFPValue(s);
          oi.isViewportVisible(_i.getWindow(), n) &&
            2 === a.type &&
            (i() && t.create("ha2", i, o), r() && t.create("ha3", r, o));
        } catch (e) {}
      },
      settings: {
        tier: 4,
        applies: function (e, t, n) {
          "use strict";
          return n.embedded && !n.isBustedIframe() && !n.isSpecifiedAd();
        },
      },
    },
    rr = function (e, n, i, r) {
      "use strict";
      let o,
        s = 0,
        a = 0;
      const c = e && e.body;
      let d = !1;
      const u = function () {
          if (((o = Math.round(oi.getNodeArea(e.body))), o >= r)) {
            const t = o + (20 * o) / 100,
              c = e.querySelectorAll("iframe"),
              u = Array.from(c);
            for (; u.length && (a < t || s < i); ) {
              const e = u.shift(),
                t = Math.round(oi.getNodeArea(e));
              t >= r && (s++, (a += t));
            }
            a >= t &&
              s >= i &&
              (function () {
                const e = { va: o, bia: a, bin: s };
                at
                  .getAggregator()
                  .trigger("addThrottledProp", "sca", n, Ze(e).toION()),
                  (d = !0);
              })();
          }
        },
        l = function () {
          new MutationObserver(function (e, t) {
            d
              ? t.disconnect()
              : _i.execAtEndOfThread(function () {
                  Ze(e).each(function (e, t) {
                    if (t.addedNodes.length) {
                      const e = t.addedNodes[0];
                      e &&
                        1 === e.nodeType &&
                        oi.tagNameIs(e, "IFRAME") &&
                        ((e, t) => {
                          let n;
                        })(u, 10);
                    }
                  });
                });
          }).observe(e.body, {
            attributes: !1,
            childList: !0,
            characterData: !1,
          });
        };
      c && (_i.execAtEndOfThread(u), !d && Ye(t.MutationObserver) && l());
    },
    or = {
      name: "BS_Browser",
      dependencies: [],
      creator: function () {
        "use strict";
        const e = _i.getWindow().document,
          t = e.body ? Math.round(oi.getNodeArea(e.body)) : null;
        !at.getAggregator().request("mobileApp").isMobileAppEnvironment() &&
          t &&
          rr(e, "bs2", 10, t);
      },
      settings: {
        tier: 7,
        applies: function (e, t, n) {
          "use strict";
          const i = !e.bootstrapOn("app") && !n.isDomless();
          return e.on("bbs") && n.embedded && i;
        },
      },
    },
    sr = () => {
      try {
        new cr();
      } catch (e) {}
    },
    ar = ({ context: e, topMostDims: t }) => {
      setTimeout(() => {
        at.getAggregator().trigger(
          "addThrottledProp",
          "env",
          "bs_monitor_inapp",
          Ze({
            images: JSON.stringify(dr({ context: e, max_output_length: 300 })),
            topMostDims: t,
          }).toION()
        );
      }, 1e3);
    };
  class cr {
    constructor() {
      (this.omidFullyLoaded = !1),
        (this.omidInfo = {
          adSessionType: "",
          environment: "",
          creativeType: "",
          mediaType: "",
        }),
        (this.onOmidPartiallyLoaded = (e) => {
          this.omidInfo = (({ omidInfo: e, event: t }) => {
            const n = t.data || {},
              i = n.context || {};
            return Object.assign(Object.assign({}, e), {
              adSessionType: i.adSessionType || "",
              environment: i.environment || "",
              creativeType: n.creativeType || "",
              mediaType: n.mediaType || "",
            });
          })({ omidInfo: this.omidInfo, event: e });
        }),
        (this.onOmidFullyLoadedOnce = () => {
          try {
            (({ omidFullyLoaded: e, omidInfo: t }) =>
              !e && "app" === t.environment)({
              omidFullyLoaded: this.omidFullyLoaded,
              omidInfo: this.omidInfo,
            }) &&
              ((this.omidFullyLoaded = !0),
              ((e) => {
                var t;
                const n =
                  null === (t = _i.getTop()) || void 0 === t
                    ? void 0
                    : t.window;
                if (n) {
                  const t = pr({ node: n.document.body });
                  vr({
                    callback: e,
                    win: n,
                    topMostDims: t,
                    maxIframeDepth: 1,
                    currIframeDepth: 0,
                  });
                }
              })(ar));
          } catch (e) {}
        });
      try {
        if (
          (() => {
            var e, t, n;
            const i = at.getAggregator().request("mobileApp");
            return !!(
              !Xn.isDomless() &&
              Xn.friendly &&
              (null ===
                (n =
                  null ===
                    (t =
                      null === (e = _i.getTop()) || void 0 === e
                        ? void 0
                        : e.window) || void 0 === t
                    ? void 0
                    : t.document) || void 0 === n
                ? void 0
                : n.body) &&
              i.isMobileAppEnvironment() &&
              Xn.isOmid()
            );
          })()
        ) {
          const e = (() => {
            try {
              const e = _i.getWindow(),
                t = at.getAggregator().request("omidVerificationClient"),
                n = e && e.omid3p;
              return n &&
                Je(n.registerSessionObserver) &&
                Je(n.addEventListener)
                ? n
                : t;
            } catch (e) {
              return null;
            }
          })();
          if (!e) return;
          e.registerSessionObserver(
            this.onOmidPartiallyLoaded.bind(this),
            "IAS"
          ),
            e.addEventListener("loaded", this.onOmidFullyLoadedOnce.bind(this));
        }
      } catch (e) {}
    }
  }
  const dr = ({ context: e, max_output_length: t }) => {
      var n;
      let i = { info: e.info, imgs: e.images };
      return (
        (i.origImgsLen =
          null === (n = e.images) || void 0 === n ? void 0 : n.length),
        (i = lr({ context: i, max_output_length: t })),
        (i = ur({ context: i, max_output_length: t })),
        i
      );
    },
    ur = ({ context: e, max_output_length: t }) => {
      for (let n = e.imgs.length; n > 0 && Ze(e).toION().length > t; n--)
        e.imgs.pop();
      return e;
    },
    lr = ({ context: e, max_output_length: t }) => {
      for (let n = e.imgs.length - 1; n >= 1; n--) {
        const i = e.imgs[n];
        if (!(Ze(e).toION().length > t && (null == i ? void 0 : i.src))) break;
        i.src = gr({ string: i.src, maxCharacterCount: 15 });
      }
      return e;
    },
    gr = ({ string: e, maxCharacterCount: t }) =>
      e.length > t ? e.slice(-t) : e,
    mr = {
      info: { w: -1, h: -1, left: -1, top: -1 },
      isSuspicious: !1,
      impressionShouldBeDisqualified: !1,
    },
    pr = ({ node: e }) => {
      const t = e.getBoundingClientRect(),
        n = {
          left: Math.round(t.left),
          top: Math.round(t.top),
          w: Math.round(t.width),
          h: Math.round(t.height),
        };
      if (e.hasAttribute("src")) {
        const t = e.getAttribute("src");
        t &&
          (n.src = (({ src: e }) => {
            const t = e.indexOf("?");
            return -1 === t ? e : e.slice(0, t);
          })({ src: t }));
      }
      return n;
    },
    hr = ({ image: e }) => {
      if (!e || !e.src) return !1;
      const t = e.src.toLowerCase();
      return (
        e.src.startsWith("/") ||
        e.src.startsWith("./") ||
        ["assets/", "logo", "icon"].some((e) => t.includes(e))
      );
    },
    fr = ({ win: e, topMostDims: t }) => {
      const n = (({ win: e, topMostDims: t }) => {
          let n;
          try {
            const i = e.document,
              r = i.body,
              o = Array.from(i.querySelectorAll("img"));
            n = {
              info: pr({ node: r }),
              images: o
                .map((e) => pr({ node: e }))
                .filter((e) =>
                  (({ imageNode: e, topMostDims: t }) =>
                    e.h >= t.h && e.w >= t.w)({ imageNode: e, topMostDims: t })
                ),
              isSuspicious: !1,
              impressionShouldBeDisqualified: !1,
            };
          } catch (e) {
            n = mr;
          }
          return n;
        })({ win: e, topMostDims: t }),
        i = (({ context: e }) =>
          !!e.images && e.images.some((e) => hr({ image: e })))({ context: n });
      return (
        i
          ? ((n.impressionShouldBeDisqualified = !0), (n.isSuspicious = !1))
          : ((n.impressionShouldBeDisqualified = !1),
            (n.isSuspicious = (({ context: e }) =>
              !!(e.images && e.images.length >= 10))({ context: n }))),
        n
      );
    },
    vr = ({
      callback: e,
      win: t,
      topMostDims: n,
      maxIframeDepth: i,
      currIframeDepth: r,
    }) => {
      const o = fr({ win: t, topMostDims: n });
      if (
        (({ context: e }) =>
          e.isSuspicious && !e.impressionShouldBeDisqualified)({ context: o })
      )
        return e({ context: o, topMostDims: n }), o;
      if (
        (({ currIframeDepth: e, maxIframeDepth: t, context: n }) =>
          e >= t || n.impressionShouldBeDisqualified)({
          currIframeDepth: r,
          maxIframeDepth: i,
          context: o,
        })
      )
        return o;
      try {
        const s = Array.from(t.document.getElementsByTagName("iframe"));
        for (const t of s.slice(0, 3)) {
          const s = null == t ? void 0 : t.contentWindow;
          if (!s || !s.document || !s.document.body) continue;
          const a = vr({
            callback: e,
            win: s,
            topMostDims: n,
            maxIframeDepth: i,
            currIframeDepth: r + 1,
          });
          (o.iframes = o.iframes || []), o.iframes.push(a);
        }
      } catch (e) {}
      return o;
    },
    yr = function () {
      "use strict";
      return { createInstance: (e) => (Xn.isDomless() ? new wr() : new br(e)) };
    },
    br = function (e) {
      "use strict";
      let n, i, r;
      const o = new $t(),
        s = new Xt(),
        a = new Tr(o),
        c = new Ir(),
        d = new xr(),
        u = new Dr(o, e),
        l = () => (void 0 === r && (r = new Or(o)), r);
      return {
        isApplicable: (e) =>
          Ye(t.JSON) &&
          Ye(t.postMessage) &&
          (!e.isOmidNative() || e.isOmidForWeb()),
        start: () => {
          o.provide({
            frameCollection: () => a,
            adProxy: () => d,
            adTalkMessage: (e) => new Ar(e, o),
            adTalkMessageCollection: () => c,
            idMapModule: l,
            interFrameQuerySelector: (e) => new Er(e),
          }),
            s.traverse(a.addFrame),
            u.startListening(),
            u.sendToKnownFrames(),
            at.getAggregator().once("stopAdTalk", () => {
              u.stopListening();
            }),
            at.getAggregator().provide("adTalkEventAggregator", o);
        },
        sendAdTalkCall: u.sendAdTalkCall,
        getFrameMap: () => (void 0 === n && (n = new Cr(o)), n),
        getFrameMapIncludingPeerCase: () => (
          void 0 === i && (i = new Cr(o, true)), i
        ),
        getIdMap: l,
      };
    },
    wr = function () {
      "use strict";
      return { isApplicable: () => !1, start: () => {} };
    },
    Ar = function (e, t) {
      "use strict";
      const n = oe.adTag && oe.adTag.asid,
        i = fi(),
        r = t.request("adProxy").myIdCard,
        o = t.request("frameCollection").getMe().getStringifiedPosition();
      return {
        messageContent: e || {},
        srcAsid: n,
        srcTagId: r.tagId,
        srcIsEmbedded: Xn.embedded,
        srcIsFriendly: Xn.friendly,
        srcBirthdate: oe.measurementConfig.birthdate,
        iasCommonId: i,
        nodeSelector: Xn.friendly
          ? "[data-integralas-id-" + n + "]"
          : (() => {
              const e = _i.getWindow(),
                t = e.location && e.location.href;
              return (
                'iframe[src*="' + (t && t.replace(/^https?:\/\//i, "")) + '"]'
              );
            })(),
        positionStr: o,
        version: "0.1",
      };
    },
    Ir = function () {
      "use strict";
      const e = {};
      return {
        add: (t) => {
          const n = t && t.srcAsid;
          n && (e[n] = t);
        },
        map: (t) =>
          Object.keys(e)
            .map((n) => t(n, e[n]))
            .filter((e) => void 0 !== e),
        has: (t) => {
          const n = t && t.srcAsid;
          return e[n];
        },
      };
    },
    Sr = function (e, n, i, r) {
      "use strict";
      const o = e == t,
        s = {
          position: n.slice(0),
          id: n.join("-"),
          isMe: o,
          isLeaf: !e.frames.length,
          adProxies: o ? i : [],
          selfDescription: void 0,
          unifiedId: oe.measurementConfig.birthdate,
          srcIsEmbedded: r ? r.srcIsEmbedded : void 0,
          inbox: r ? [r] : [],
          getDomObj: () => e,
          getStringifiedPosition: () =>
            Ze(s.position)
              .map((e, t) => tt(Number(t) + 1, 36))
              .join(""),
          isValidForMapping: () => s.isLeaf || s.isMe || Ye(s.selfDescription),
        },
        a = (e, t) =>
          !Ze(e).find((e, n) => n.adSafeId && n.adSafeId === t.adSafeId);
      return (
        (s.addInformationFromSrc = (e, t) => {
          ((e) => {
            const t = s.adProxies,
              n = e.adProxies;
            let i = [];
            t.length && n.length
              ? Ze(n).each((e, n) => {
                  a(t, n) && i.push(n);
                })
              : (i = n),
              (s.adProxies = t.concat(i));
          })(t),
            ((e) => {
              Ze(s.inbox).find(
                (t, n) => n.srcAsid && n.srcAsid === e.srcAsid
              ) || s.inbox.push(e);
            })(e),
            (s.srcIsEmbedded = e.srcIsEmbedded),
            (s.selfDescription = t);
        }),
        s
      );
    },
    Tr = function (e) {
      "use strict";
      const t = [],
        n = {};
      let i = { noMe: !0 };
      return {
        addFrame: (r, o, s) => {
          const a = e.request("adProxy").getAll(),
            c = new Sr(r, o, a, s);
          return t.push(c), (n[c.id] = c), c.isMe && (i = c), c;
        },
        getFrame: (e) => n[e],
        list: t,
        dictionary: n,
        getMe: () => i,
      };
    },
    Cr = function (e, t) {
      "use strict";
      const n = (e, n) => {
          const o = n.adProxies;
          let s = "";
          if (n.isValidForMapping())
            return (s += t ? r(o, n.getStringifiedPosition()) : i(o, n)), s;
        },
        i = (e, t) => {
          let n = "";
          return (
            (n += t.getStringifiedPosition()),
            (n += t.isMe ? "*" : ""),
            (n += e.length ? "." + e[0].tagId : ""),
            n
          );
        },
        r = (e, t) => {
          let n = "";
          return (
            e.length
              ? (n += Ze(e).stringify((e, n) => o(n, t), "|"))
              : (n += t),
            n
          );
        },
        o = (e, t) =>
          t +
          ((oe.adTag && oe.adTag.asid) === e.adSafeId ? "*" : "") +
          "." +
          e.tagId;
      return {
        output: () => {
          const t = e.request("frameCollection"),
            i = Ze(t.list).stringify(n, "|");
          return tt(t.getMe().unifiedId, 62) + "+" + i;
        },
      };
    },
    Or = function (t) {
      "use strict";
      const n = t.request("frameCollection").getMe().getStringifiedPosition(),
        i = e.contextNode.parentNode,
        r = t.request("interFrameQuerySelector", i),
        o = (e) => {
          let t = !1;
          const o = !Xn.embedded,
            s = "BODY" !== oi.getNodeName(i) && "HEAD" !== oi.getNodeName(i),
            a =
              e.srcIsEmbedded &&
              !((e) => {
                const t = "0.1" !== e.version,
                  n =
                    e.nodeSelector &&
                    -1 === e.nodeSelector.indexOf("data-integralas-id");
                return t ? n : !e.srcIsFriendly;
              })(e);
          return (
            (t =
              o && s && !a
                ? !!((e) => r.queryFor(e.nodeSelector))(e)
                : !!((e) => {
                    const t = e.positionStr,
                      i = e.srcIsEmbedded && Xn.embedded,
                      r = 0 === n.indexOf(t) || 0 === t.indexOf(n);
                    return i && r;
                  })(e)),
            t
          );
        };
      return {
        output: () => {
          let e;
          const i = n + "*",
            r = t.request("adTalkMessageCollection").map((e, t) => {
              let n;
              return (
                e !== (oe.adTag && oe.adTag.asid) &&
                  o(t) &&
                  (n = ((e) =>
                    e.positionStr +
                    "." +
                    e.srcAsid +
                    "." +
                    e.transferDuration +
                    "_" +
                    e.srcTagId)(t)),
                n
              );
            });
          return (
            r.push(i),
            (e = r.join("|")),
            e.length > 120 &&
              ((e = ((e) => e && e.substr(0, 120) + ".of" + e.length)(e)),
              at.getAggregator().trigger("stopAdTalk")),
            e
          );
        },
        isCandidateForMyIdMap: o,
      };
    },
    Er = function (e) {
      "use strict";
      const t = new Xt(),
        n = (e, t) =>
          oi.querySelector(
            ((e) => {
              let t = e;
              const n = "IFRAME" === oi.getNodeName(e),
                i = oi.isWindow(e);
              return (
                n ? (t = e.contentWindow.document) : i && (t = e.document), t
              );
            })(e),
            t
          );
      return {
        queryFor: (i) => {
          let r = null;
          return (
            i &&
              (r = ((i, r) => {
                let o, s, a;
                try {
                  (s = n(i, r)),
                    s ||
                      ((o = t.getFrames(!0, e)),
                      o.find((e) => ((a = n(e, r)), a)));
                } catch (e) {}
                return s || a || null;
              })(e, i)),
            r
          );
        },
      };
    },
    Dr = function (e) {
      "use strict";
      let t,
        n = !1;
      const i = oe.adTag && oe.adTag.asid,
        r = (t) => {
          const n =
            !e.request("adTalkMessageCollection").has(t) && t.srcAsid !== i;
          return (
            t.hasOwnProperty("messageContent") && fi() === t.iasCommonId && n
          );
        },
        o = () => {
          const t = e.request("frameCollection").getMe(),
            n = { self: t, unifiedId: t.unifiedId };
          return e.request("adTalkMessage", n);
        },
        s = () => {
          e.request("frameCollection");
          n || (n = !0), at.getAggregator().trigger("sendDt", "a");
        },
        a = (t, i, r) => {
          let o, a, c, d, u;
          try {
            (o = e.request("frameCollection")),
              (a = e.request("adTalkMessageCollection")),
              (c = i.messageContent.self),
              a.add(i),
              (g = o.getMe()),
              (m = c),
              g.unifiedId > m.unifiedId && (g.unifiedId = m.unifiedId),
              (i.transferDuration = ((e) => _i.now() - e.sentTime)(i)),
              (d = o.getFrame(c.id)),
              void 0 === (l = d) || void 0 === l.selfDescription
                ? ((d = d || o.addFrame(t.source, c.id.split("-"), i)),
                  d.addInformationFromSrc(i, c),
                  r())
                : d.addInformationFromSrc(i, c),
              (u = n && e.request("idMapModule").isCandidateForMyIdMap(i)),
              u && s();
          } catch (e) {
            at.getAggregator().trigger("error", "D");
          }
          var l, g, m;
        };
      return {
        sendAdTalkCall: s,
        sendToKnownFrames: () => {
          new Kt().send(o);
        },
        startListening: () => {
          (t = new Qt()), t.listen(r, a, o);
        },
        stopListening: () => {
          t && t.stop();
        },
        validateMessage: r,
        processMessage: a,
        createMessage: o,
      };
    },
    Mr = function () {
      "use strict";
      const e = at.getAggregator().request("ids"),
        t = e.getAsid();
      return { tagId: e.getFwId(), adSafeId: t };
    },
    xr = function () {
      "use strict";
      const e = [],
        t = (t) => {
          const n = new Mr(t);
          return e.push(n), n;
        },
        n = t();
      return { createNew: t, getAll: () => e, myIdCard: n };
    },
    Pr = [0, 0.01, 0.2, 0.25, 0.3, 0.5, 0.7, 0.75, 0.8, 0.99, 1],
    Vr = function (e, t) {
      "use strict";
      let n,
        i,
        r = "na",
        o = r,
        s = !1,
        a = !1,
        c = !1;
      const d = !t,
        u = at.getAggregator().request("browser"),
        l = function (e, t) {
          if (
            (function (e) {
              const t = at.getAggregator().request("mobileApp");
              return (
                (e.browserIs("c") ||
                  e.isAndroidWebViewBrowser() ||
                  e.browserIs("w") ||
                  e.browserIs("e")) &&
                !t.isMobileAppEnvironment() &&
                e.hasResizeObserver()
              );
            })(u)
          ) {
            _i.getResizeObserver(function (n, i) {
              const r = n.pop();
              r.contentRect.height * r.contentRect.width > 0 &&
                (t.unobserve(e), t.observe(e), i.disconnect());
            }).observe(e);
          }
        },
        g = function () {
          const t = _i.getIntersectionObserver(
            function (e, t) {
              const i = e.pop();
              let s =
                ((i.intersectionRect.width * i.intersectionRect.height) /
                  (i.boundingClientRect.width * i.boundingClientRect.height)) *
                100;
              isNaN(s) && (l(i.target, t), (s = 0)),
                (r = Math.min(s, 100)),
                (n = i.boundingClientRect),
                r !== o &&
                  _i.execAtEndOfThread(function () {
                    at.getAggregator().trigger("IOPivChange", r);
                  }),
                (o = r);
            },
            { threshold: Pr }
          );
          d &&
            _i.execAtEndOfThread(function () {
              "na" === r && (r = 0);
            }),
            t.observe(h(e)),
            d &&
              _i.execAtEndOfThread(function () {
                Xn.isBustedIframe() ||
                  at.getAggregator().trigger("delayedViewabilityReady");
              }),
            (s = !0);
        },
        m = function (e) {
          g();
          try {
            const t = _i.getIntersectionObserver(function (e) {
              e.forEach(function (e) {
                e.isIntersecting ||
                  ((r = 0),
                  (o = 0),
                  (n = new DOMRectReadOnly(0, 0, 0, 0)),
                  t.disconnect());
              });
            });
            t.observe(e);
          } catch (e) {}
        },
        p = function () {
          try {
            let t;
            return (
              e &&
                e.ownerDocument &&
                e.ownerDocument.defaultView &&
                (t = e.ownerDocument.defaultView.frameElement),
              t
            );
          } catch (e) {}
        },
        h = function (t) {
          if (void 0 !== t) {
            if (c) {
              const n = e.document,
                i = n.createElement("div");
              Ze(i.style).mixin({
                position: "absolute",
                width: "100%",
                opacity: "0",
                height: "100%",
                zIndex: -999,
                top: "0px",
                left: "0px",
              }),
                (i.iasdetector = !0),
                n.body.appendChild(i),
                (t = i);
            }
            return (i = t), t;
          }
        };
      return {
        start: function () {
          const t = (function () {
              let t;
              try {
                e.document &&
                  ((c = !0),
                  (t = { bodyElement: e.document.body, document: e.document }));
              } catch (e) {
                a = !0;
              }
              return t;
            })(),
            n = p();
          t && null !== t.bodyElement
            ? g()
            : t && t.document
            ? Jn.whenReady(g, t.document)
            : a
            ? at.getAggregator().request("mErrors").add("y")
            : n && Xn.isCeltra()
            ? m(n)
            : g();
        },
        isReady: function () {
          return "na" !== r;
        },
        isStarted: function () {
          return s;
        },
        getAdNodeDimensions: function () {
          let e;
          return (
            n &&
              (e = ei({
                scrX: void 0,
                scrY: void 0,
                width: n.width,
                height: n.height,
              })),
            e
          );
        },
        getObservedNode: function () {
          return i;
        },
        getPiv: function () {
          return r;
        },
      };
    },
    Nr = function () {
      "use strict";
      let e = !1;
      return (
        Jn.whenReady(function () {
          at.getAggregator().trigger("startViewabilityLoop"), (e = !0);
        }),
        {
          loopStarted: function () {
            return e;
          },
        }
      );
    },
    kr = {
      name: "loopDelay",
      dependencies: [],
      creator: Nr,
      settings: {
        applies: function (e, t, n) {
          "use strict";
          return e.bootstrapOn("allowViewability");
        },
        tier: 7,
      },
    },
    Fr = function () {
      "use strict";
      return {
        start: function (e) {
          at.getAggregator().on("measurable", function () {
            e();
          });
        },
        isApplicable: function (e, t) {
          return !t.browserIs("w") || !e.isImmediatelyMeasurable();
        },
      };
    },
    Rr = function () {
      "use strict";
      return {
        start: function (e) {
          e();
        },
        isApplicable: function (e) {
          return e.isImmediatelyMeasurable();
        },
      };
    },
    jr = function (t, n, i) {
      "use strict";
      let r = !1;
      const o = function () {
        try {
          n.impressionIsIdentifiable() && !r
            ? ((r = !0), at.getAggregator().trigger("notify", e._onMeasurable))
            : n.impressionIsIdentifiable() ||
              __IntegralASDiagnosticCall("rtsmeas_imp_not_iden", {}, e);
        } catch (t) {
          __IntegralASDiagnosticCall("rtsmeas_send_noti_error", t, e);
        }
      };
      return {
        start: function () {
          try {
            const n = [Lr(), _r(), Rr(), Fr()].find(function (e) {
              return e.isApplicable(i, t);
            });
            n
              ? n.start(o)
              : __IntegralASDiagnosticCall("rtsmeas_no_chosen_strategy", {}, e);
          } catch (t) {
            __IntegralASDiagnosticCall("rtsmeas_start_error", t, e);
          }
        },
        isApplicable: function (t) {
          return (
            t.bootstrapOn("useViewabilityNotification") && Ye(e._onMeasurable)
          );
        },
      };
    },
    _r = function () {
      "use strict";
      return {
        start: function (e) {
          var t, n;
          ((t = at.getAggregator()),
          (n = ["adImpression", "measurable"]),
          {
            onAll: (e) => {
              let i = {};
              n.forEach((r) => {
                t.on(r, () => {
                  (i[r] = 1),
                    Object.keys(i).length === n.length && ((i = {}), e());
                });
              });
            },
          }).onAll(function () {
            e();
          });
        },
        isApplicable: function (e, t) {
          const n = t.getIOSVersion() >= 9;
          return (!t.browserIs("w") || n) && Xn.isVideo();
        },
      };
    },
    Lr = function () {
      "use strict";
      return {
        start: function (e) {
          at.getAggregator().once("adImpression", function () {
            e();
          });
        },
        isApplicable: function (e) {
          return e.isImmediatelyMeasurable() && Xn.isVideo();
        },
      };
    },
    Ur = function (e, t, n) {
      "use strict";
      return {
        accepts: function () {
          const e = Ye(
            $r.find(function (e) {
              return e === n;
            })
          );
          return t.accepts() && t.isMediaType("display") && e;
        },
        isImmediate: function () {
          return !0;
        },
        isMediaType: t.isMediaType,
        supportsAdContainerGeometry: function () {
          return t.supportsAdContainerGeometry();
        },
        start: function () {},
      };
    },
    qr = function (t) {
      "use strict";
      const n = _i.getWindow(),
        i = n && n.omid3p,
        r = at.getAggregator().request("omidAdSessionContext"),
        o = !!(t && t.isSupported && t.isSupported()),
        s = !!(i && Je(i.registerSessionObserver) && Je(i.addEventListener));
      return {
        accepts: function () {
          return (o || s) && !e.videoId && !e._cl_adpath;
        },
        isMediaType: function (e) {
          return e === r.mediaType;
        },
        supportsAdContainerGeometry: function () {
          return !0;
        },
      };
    },
    Wr = function (e, t, n) {
      "use strict";
      const i = at.getAggregator().request("omidAdSessionContext"),
        r = i.isHtml && i.isWeb ? zr : $r,
        o = Xr(e);
      return {
        accepts: function () {
          const e = Ye(
            r.find(function (e) {
              return e === n;
            })
          );
          return t.accepts() && t.isMediaType("video") && e;
        },
        isImmediate: function () {
          return !0;
        },
        isMediaType: t.isMediaType,
        supportsAdContainerGeometry: function () {
          return t.supportsAdContainerGeometry();
        },
        start: function () {
          o.addEventListener("start", function (e) {
            at.getAggregator().trigger("adImpression");
          });
        },
      };
    },
    Br = [
      "start",
      "firstQuartile",
      "midpoint",
      "thirdQuartile",
      "resume",
      "bufferFinish",
    ],
    Gr = ["complete", "pause", "bufferStart", "skipped"],
    Hr = ["playerStateChange", "loaded", "volumeChange"],
    $r = [T.Rjss, T.Amt, T.Jss, T.Jload],
    zr = [...$r, T.JsVid, T.FwjsVid],
    Xr = (e) => {
      const t = _i.getWindow(),
        n = t && t.omid3p;
      return !!(n && Je(n.registerSessionObserver) && Je(n.addEventListener))
        ? n
        : e;
    },
    Yr = [
      { root: "omidNativeInfo", code: "onpn", field: "partnerName" },
      { root: "omidNativeInfo", code: "onpv", field: "partnerVersion" },
      { root: "omidJsInfo", code: "ojpn", field: "partnerName" },
      { root: "omidJsInfo", code: "ojpv", field: "partnerVersion" },
      { root: "omidJsInfo", code: "osev", field: "serviceVersion" },
      { root: "omidJsInfo", code: "oscv", field: "sessionClientVersion" },
      { root: "app", code: "applv", field: "libraryVersion" },
      { root: "app", code: "appid", field: "appId" },
      { root: "deviceInfo", code: "dty", field: "deviceType", encode: !0 },
      { root: "deviceInfo", code: "osn", field: "os" },
      { root: "deviceInfo", code: "osv", field: "osVersion" },
    ],
    Jr = function (e) {
      "use strict";
      return {
        resolve: function () {
          return e.find(function (e) {
            return e.environment.accepts();
          });
        },
      };
    },
    Qr = function (n) {
      "use strict";
      let i = !1,
        r = !1,
        o = !1,
        s = !1;
      const a = at.getAggregator().request("omidAdSessionContext");
      (a.queuedOutputItems = []),
        (a.cachedEvents = []),
        (a.cachedGeometryEventsReceived = !1),
        (a.cachedVideoEventsReceived = !1),
        (a.recoveredTime = -1),
        (a.grnd = "u");
      const c = new ia();
      let d = at.getAggregator().request("omidAdSessionVerificationParameters");
      const u = at.getAggregator().request("features"),
        l = Xr(n);
      let g = !1;
      (a.omidEarlyExit = !1), (a.mediaType = "display");
      let m = !1;
      const p = function () {
          return d && d.IAS && Object.keys(d.IAS).length > 0 ? d.IAS : d;
        },
        h = function (e, t) {
          a.queuedOutputItems.push({ code: e, value: t });
        },
        f = function (e, t, n) {
          at.getAggregator().trigger(e, t, n);
        },
        v = function (e, t) {
          e &&
            e.data &&
            e.data.hasOwnProperty("creativeType") &&
            ((!t && a.hasOwnProperty("creativeType")) ||
              (a.creativeType = e.data.creativeType));
        },
        y = function (e) {
          at.getAggregator().trigger(e);
        },
        b = function () {
          if (i && r && (!s || o)) {
            (t.omidSupported = !0),
              a.hasOwnProperty("impressionType") && h("oiet", a.impressionType),
              a.hasOwnProperty("creativeType") && h("oct", a.creativeType),
              a.underEvaluation && h("oef", !0),
              (a.exitedOASRS = !0),
              (g = !0);
            const e = p();
            e &&
              (oe.baseUrls &&
                oe.baseUrls.updateWithVerificationParameters({
                  verificationParameters: e,
                }),
              oe.measurementConfig &&
                oe.measurementConfig.updateWithVerificationParameters({
                  verificationParameters: e,
                }),
              oe.adTag &&
                oe.adTag.updateWithVerificationParameters({
                  verificationParameters: e,
                })),
              oe &&
                oe.jsConfigRequest &&
                oe.jsConfigRequest.buildRequestUrlFromParameters &&
                oe.jsConfigRequest.buildRequestUrlFromParameters({
                  contextNode: oe.jsConfigRequest.contextNode,
                  omidParameters: p(),
                }),
              Xe();
          }
        },
        w = function (e) {
          if (e && "start" === e.type)
            return (a.videoStartArrived = !0), void y("omidrendvideostart");
          "loaded" !== e.type ||
            a.omidLoadedArrived ||
            (h("oloa", Xn.getTagTime()),
            (o = !0),
            (a.omidLoadedArrived = !0),
            y("omidloadedarrived"),
            v(e, !0),
            "audio" === a.creativeType &&
              ((a.accessMode = "limited"), (a.isLimitedSandbox = !0)),
            e.data.hasOwnProperty("impressionType") &&
              (a.impressionType = e.data.impressionType),
            !0 === a.omidEarlyExit &&
              (m ||
                (f("addThrottledOutputItem", "oiet", a.impressionType),
                f("addThrottledOutputItem", "oct", a.creativeType),
                (m = !0))),
            b());
        },
        A = function (t) {
          if ("sessionStart" === t.type) {
            !(function (e, t, n, i) {
              const r = e.data.context;
              (t.adSessionType = r.adSessionType || "undefined"),
                (t.environment = r.environment),
                (t.accessMode = r.accessMode || "limited"),
                (t.omidNativeInfo = r.omidNativeInfo),
                (t.omidJsInfo = r.omidJsInfo),
                (t.deviceInfo = r.deviceInfo),
                (t.app = r.app),
                (t.supports = r.supports),
                (t.element = r.videoElement || r.slotElement || null),
                t.app &&
                  "string" == typeof t.app.appId &&
                  t.app.appId.toLowerCase().indexOf("pandora") > -1 &&
                  (t.ignoreDivAsCandidate = !0),
                e.data.hasOwnProperty("contentUrl") &&
                  (t.contentUrl = e.data.contentUrl),
                r.hasOwnProperty("underEvaluation") &&
                  (t.underEvaluation = r.underEvaluation),
                r.hasOwnProperty("podSequence") &&
                  ((t.podSequence = r.podSequence), i("opds", t.podSequence)),
                r.hasOwnProperty("adCount") &&
                  ((t.adCount = r.adCount), i("oadc", t.adCount)),
                r.hasOwnProperty("transactionId") &&
                  ((t.transactionId = r.transactionId),
                  i("otid", t.transactionId)),
                r.hasOwnProperty("friendlyToTop") &&
                  ((t.friendlyToTop = r.friendlyToTop),
                  i("oftt", t.friendlyToTop)),
                r.hasOwnProperty("deviceCategory") &&
                  ((t.deviceCategory = r.deviceCategory),
                  i("ocat", t.deviceCategory)),
                r.hasOwnProperty("universalAdId") &&
                  ((t.universalAdId = r.universalAdId),
                  i("uadid", t.universalAdId)),
                (t.isJavaScript = "javascript" === t.adSessionType),
                (t.isNative =
                  "native" === t.adSessionType ||
                  "javascript" === t.adSessionType),
                (t.isLimitedSandbox =
                  "app" === t.environment
                    ? n.embedded
                    : "full" !== r.accessMode),
                t.app &&
                  "string" == typeof t.app.appId &&
                  t.app.appId.toLowerCase().indexOf("pinterest") > -1 &&
                  "limited" === t.accessMode &&
                  (t.isLimitedSandbox = !0),
                (t.isHtml = "html" === r.adSessionType),
                (t.isWeb = "web" === r.environment),
                (t.partnerName =
                  t.omidNativeInfo &&
                  t.omidNativeInfo.partnerName &&
                  t.omidNativeInfo.partnerName.toLowerCase()),
                (t.isOmidForWebEnvironment = t.isHtml && t.isWeb);
              for (let e = 0; e < Yr.length; e++) {
                const n = Yr[e].root,
                  r = Yr[e].field,
                  o = Yr[e].code,
                  s = t[n];
                if ("object" == typeof s && void 0 !== s[r]) {
                  const t = s[r];
                  i(
                    o,
                    Yr[e].encode && "string" == typeof t
                      ? encodeURIComponent(t)
                      : t
                  );
                }
              }
              i("oast", t.adSessionType),
                i("oacm", t.accessMode),
                i("oenv", t.environment),
                t.hasOwnProperty("contentUrl") &&
                  i("ocon", encodeURIComponent(t.contentUrl || ""));
            })(t, a, Xn, h),
              (d = t.data.verificationParameters),
              v(t, !1);
            const n = (function (e) {
              return (
                Xn.isOmidForWeb() ||
                (e.data.hasOwnProperty("supportsLoadedEvent") &&
                  ("true" === e.data.supportsLoadedEvent ||
                    !0 === e.data.supportsLoadedEvent) &&
                  "string" == typeof e.data.creativeType &&
                  "" !== e.data.creativeType)
              );
            })(t);
            n
              ? ((s = !0),
                (a.useOMID13Logic = !0),
                h("ohand", "13"),
                l.addEventListener("media", w))
              : h("ohand", "12");
            const c = (function (t, n) {
              let i = "0";
              return (
                e.omidLeaveEarly
                  ? (e && e.mobFwUrl && e.mobFwUrl.indexOf("xmtp=v") > -1
                      ? (a.mediaType = "video")
                      : (a.mediaType =
                          "web" === a.environment
                            ? t.data.mediaType || "video"
                            : t.data.mediaType),
                    a.mediaType &&
                      t.data.creativeType &&
                      ((a.omidEarlyExit = !0),
                      (i = "1"),
                      (r = o = !0),
                      h("omtp", a.mediaType)),
                    "video" === a.mediaType &&
                      ((a.isVideo = !0), (a.isNativeVideo = a.isNative)),
                    (a.isDisplay = "display" === a.mediaType))
                  : (a.isOmidForWebEnvironment ||
                      ((a.integratedBlocking =
                        oe.measurementConfig.isResolved &&
                        Xn.integratedBlockingApplies(e.mobFwUrl)),
                      a.integratedBlocking &&
                        u &&
                        u.on("exitOASRSEarly") &&
                        ((a.omidEarlyExit = !0),
                        (i = "1"),
                        a.omidEarlyExit &&
                          e.mobFwUrl.indexOf("xmtp=v") > -1 &&
                          (a.mediaType = "video")),
                      !t.data.mediaType ||
                        ("display" !== t.data.mediaType &&
                          "video" !== t.data.mediaType) ||
                        (a.mediaType = t.data.mediaType)),
                    a.omidEarlyExit &&
                      ((r = !0),
                      h("omtp", a.mediaType),
                      (o = !!n || o),
                      (a.isVideo = "video" === a.mediaType || a.isVideo),
                      (a.isNativeVideo = a.isNative && a.isVideo),
                      (a.isDisplay = "display" === a.mediaType))),
                i
              );
            })(t, n);
            if (
              ("audio" === t.data.creativeType &&
                ((a.accessMode = "limited"), (a.isLimitedSandbox = !0)),
              t.data.hasOwnProperty("lastActivity") &&
                t.data.lastActivity.hasOwnProperty("timestamp") &&
                oe &&
                oe.measurementConfig &&
                oe.measurementConfig.birthdate)
            ) {
              const e = t.data.lastActivity.timestamp;
              (a.lastActivity = e),
                h("olas", e - oe.measurementConfig.birthdate);
            }
            h("oerl", c), h("oses", Xn.getTagTime()), (i = !0), b();
          }
          if ("sessionError" === t.type) {
            const e =
                "string" == typeof t.data.errorType
                  ? t.data.errorType
                  : "NoErrType",
              n =
                "string" == typeof t.data.message
                  ? t.data.message
                  : "NoMessage",
              i = e + "_" + encodeURIComponent(n);
            g ? f("addOutputItem", { output: i }, "oser") : h("oser", i);
          }
        },
        I = function (e) {
          "impression" === e.type &&
            ((a.omidImpressionArrived = !0),
            y("omidimpressionarrived"),
            (a.mediaType =
              "web" === a.environment
                ? e.data.mediaType || "video"
                : e.data.mediaType),
            h("omtp", a.mediaType),
            v(e, !0),
            "audio" === e.data.creativeType &&
              ((a.accessMode = "limited"), (a.isLimitedSandbox = !0)),
            h("oimp", Xn.getTagTime()),
            "video" === e.data.mediaType && (a.isVideo = !0),
            (function (e) {
              return e.data.adView && (e.data.viewport || a.isWeb);
            })(e) &&
              ((a.impressionViewabilityMeasurement = {
                type: "geometryChange",
                data: { viewport: e.data.viewport, adView: e.data.adView },
                timestamp: e.timestamp,
              }),
              void 0 === a.geometryArrived &&
                c.checkForViewAttachmentBasedOnAdSessionType(
                  a,
                  e.data.adView
                ) &&
                ((a.geometryArrived = !0), y("omidrendgeoupdate"))),
            e.data.hasOwnProperty("impressionType") &&
              !o &&
              (a.impressionType = e.data.impressionType),
            (a.isNativeVideo = a.isNative && "video" === e.data.mediaType),
            (a.isDisplay = "display" === e.data.mediaType),
            (r = !0),
            b());
        },
        S = function (e) {
          e &&
            e.data &&
            e.data.interactionType &&
            "click" === e.data.interactionType &&
            go.omid.trackClick(e);
        };
      return {
        start: function () {
          l.registerSessionObserver(A, "IAS"),
            l.addEventListener("impression", I),
            l.addEventListener("adUserInteraction", S);
        },
      };
    },
    Kr = function () {
      "use strict";
      return {
        accepts: function () {
          return !0;
        },
      };
    },
    Zr = function () {
      "use strict";
      const e = at.getAggregator().request("omidAdSessionContext"),
        t = at.getAggregator().request("omidVerificationClient"),
        n = new qr(t),
        i = e.isHtml && e.isWeb;
      return {
        accepts: function () {
          return n.accepts() && i;
        },
      };
    },
    eo = function () {
      "use strict";
      return {
        start: function () {
          Xe();
        },
      };
    };
  class to {
    static maxScrollDepth({ maxScrollDepth: e }) {
      at.getAggregator().trigger("addOutputItem", { output: e }, "msd");
    }
    static pageHeight({ pageHeight: e }) {
      at.getAggregator().trigger("addOutputItem", { output: e }, "ph");
    }
    static notAvailableOrApplicableMaxScrollDepth({ reason: e }) {
      at.getAggregator().trigger("addOutputItem", { output: e }, "nmsd");
    }
    static notAvailableOrApplicablePageHeight({ reason: e }) {
      at.getAggregator().trigger("addOutputItem", { output: e }, "nph");
    }
  }
  class no extends a {
    constructor() {
      super({ storeModelName: "pageMetrics" }),
        (this.maxScrollDepth = 0),
        (this.ticking = !1),
        (this.scrollHandler = () => {
          var e;
          this.ticking ||
            (null === (e = this.topWindow) ||
              void 0 === e ||
              e.requestAnimationFrame(() => {
                this.sendPageMetricsData(), (this.ticking = !1);
              }),
            (this.ticking = !0));
        }),
        (this.topWindow = (() => {
          let e;
          try {
            Xn.friendly && !Xn.isDomless() && (e = _i.getTop() || void 0);
          } catch (e) {}
          return e;
        })()),
        this.topWindow && this.initScrollListener();
    }
    sendPageMetricsData() {
      const e = this.getPageMetrics({ topWindow: this.topWindow });
      if (void 0 !== e) {
        const { pageHeight: t, maxScrollDepth: n } = e;
        void 0 !== n && to.maxScrollDepth({ maxScrollDepth: n }),
          void 0 !== t && to.pageHeight({ pageHeight: t });
      } else
        to.notAvailableOrApplicableMaxScrollDepth({ reason: -1 }),
          to.notAvailableOrApplicablePageHeight({ reason: -1 });
    }
    initScrollListener() {
      var e;
      try {
        null === (e = this.topWindow) ||
          void 0 === e ||
          e.addEventListener("scroll", this.scrollHandler),
          this.prepareScrollListenerCleanup();
      } catch (e) {}
    }
    prepareScrollListenerCleanup() {
      Jn.whenReady(() => {
        const e = at.getAggregator();
        e &&
          e.on &&
          e.on("altAdSessionComplete", () => {
            var e;
            try {
              null === (e = this.topWindow) ||
                void 0 === e ||
                e.removeEventListener("scroll", this.scrollHandler);
            } catch (e) {}
          });
      });
    }
    getPageMetrics({ topWindow: e }) {
      let t;
      if (e)
        try {
          const n = e.document.documentElement.scrollHeight,
            i = e.scrollY || e.document.documentElement.scrollTop;
          (this.maxScrollDepth = Math.max(this.maxScrollDepth, Math.round(i))),
            (t = { pageHeight: n, maxScrollDepth: this.maxScrollDepth });
        } catch (e) {
          to.notAvailableOrApplicableMaxScrollDepth({ reason: -1 }),
            to.notAvailableOrApplicablePageHeight({ reason: -1 });
        }
      return t;
    }
  }
  const io = ({ jsInfoCode: e, output: t, errorCode: n }) => {
    try {
      at.getAggregator().trigger("addOutputItem", { output: t }, e),
        at.getAggregator().trigger("sendDt", "e");
    } catch (e) {
      at.getAggregator().trigger("error", n);
    }
  };
  class ro {
    constructor() {
      (this.mousedOver = !1), (this.clicked = !1);
    }
    mouseOver() {
      this.mousedOver = !0;
    }
    mouseOut() {
      this.mousedOver = !1;
    }
    click() {
      this.clicked = !0;
    }
    isMousedOver() {
      return this.mousedOver;
    }
    wasClicked() {
      return this.clicked;
    }
  }
  class oo {
    constructor({ tagStartTime: e, adState: t }) {
      (this.initClickTracking = ({ clickSource: e }) => {
        this.clickData[e] || (this.clickData[e] = []);
      }),
        (this.getClicks = ({ clickSource: e }) => this.clickData[e]),
        (this.setupTrackAndBroadcastClick = ({
          clientX: e,
          clientY: t,
          clickSource: n,
        }) => {
          const i = [e, t, Xn.getTagTime()];
          this.getClicks({ clickSource: n }).push(i),
            io({
              output: Ze(this.clickData).toION(),
              errorCode: "Q",
              jsInfoCode: "clks",
            });
        }),
        (this.trackClick = ({ event: e, clickSource: t }) => {
          const { clientX: n, clientY: i } = e;
          this.adState.click(),
            this.setupTrackAndBroadcastClick({
              clientX: n,
              clientY: i,
              clickSource: t,
            });
        }),
        (this.trackBlur = ({ clickSource: e }) => {
          this.setupTrackAndBroadcastClick({
            clientX: -1,
            clientY: -1,
            clickSource: e,
          });
        }),
        (this.trackTouch = ({ clientX: e, clientY: t, clickSource: n }) => {
          this.setupTrackAndBroadcastClick({
            clientX: e,
            clientY: t,
            clickSource: n,
          });
        }),
        (this.trackOmidClick = () => {
          this.initClickTracking({ clickSource: "om" }),
            this.trackClick({
              event: { clientX: 0, clientY: 0 },
              clickSource: "om",
            });
        }),
        (this.isProxyClick = () =>
          !this.adState.wasClicked() &&
          this.adState.isMousedOver() &&
          n.activeElement instanceof HTMLIFrameElement),
        (this.trackBlurClick = () => {
          if (this.isProxyClick()) {
            const e = "blr";
            this.adState.mouseOut(),
              this.initClickTracking({ clickSource: e }),
              this.trackBlur({ clickSource: e });
          }
        }),
        (this.trackAdComponentClick = (e) => {
          this.initClickTracking({ clickSource: "ac" }),
            this.trackClick({ event: e, clickSource: "ac" });
        }),
        (this.trackMobileTouchStart = (e) => {
          if (e.changedTouches && e.changedTouches[0]) {
            const t = e.changedTouches[0],
              { clientX: n, clientY: i } = {
                clientX: Math.round(null == t ? void 0 : t.clientX),
                clientY: Math.round(null == t ? void 0 : t.clientY),
              };
            this.mobileClickVerify.trackMobileTimeAndCoords({
              clientX: n,
              clientY: i,
            });
          }
        }),
        (this.trackMobileTouchEnd = (e) => {
          if (e.changedTouches && e.changedTouches[0]) {
            const t = e.changedTouches[0],
              { clientX: n, clientY: i } = {
                clientX: Math.round(t.clientX),
                clientY: Math.round(t.clientY),
              };
            if (
              this.mobileClickVerify.isMobileLinkClick({
                clientX: n,
                clientY: i,
              })
            ) {
              const e = "mt";
              this.initClickTracking({ clickSource: e }),
                this.trackTouch({ clientX: n, clientY: i, clickSource: e });
            }
          }
        }),
        (this.trackPointerUp = (e) => {
          if ("pen" === e.pointerType && e.clientX && e.clientY) {
            const { clientX: t, clientY: n } = {
              clientX: Math.round(e.clientX),
              clientY: Math.round(e.clientY),
            };
            if (
              this.mobileClickVerify.isMobileLinkClick({
                clientX: t,
                clientY: n,
              })
            ) {
              const e = "mt";
              this.initClickTracking({ clickSource: e }),
                this.trackTouch({ clientX: t, clientY: n, clickSource: e });
            }
          }
        }),
        (this.trackPointerDown = (e) => {
          if ("pen" === e.pointerType && e.clientX && e.clientY) {
            const { clientX: t, clientY: n } = {
              clientX: Math.round(e.clientX),
              clientY: Math.round(e.clientY),
            };
            this.mobileClickVerify.trackMobileTimeAndCoords({
              clientX: t,
              clientY: n,
            });
          }
        }),
        (this.clickData = {}),
        (this.tagStartTime = e),
        (this.adState = t),
        (this.mobileClickVerify = new so());
    }
  }
  class so {
    constructor() {
      (this.trackMobileTimeAndCoords = ({ clientX: e, clientY: t }) => {
        this.mobileTouchTimer.startTimer(),
          (this.lastClientX = e),
          (this.lastClientY = t);
      }),
        (this.isMobileLinkClick = ({ clientX: e, clientY: t }) => {
          const n = this.mobileTouchTimer.endTimer();
          let i = !1;
          if (
            (this.mobileTouchTimer.startTimer(),
            n && n <= 200 && this.lastClientX && this.lastClientY)
          ) {
            const n = Math.abs(e - this.lastClientX),
              r = Math.abs(t - this.lastClientY),
              o = 10;
            n <= o && r <= o && (i = !0);
          }
          return i;
        }),
        (this.mobileTouchTimer = new uo()),
        this.mobileTouchTimer.startTimer();
    }
  }
  class ao {
    constructor({ adState: e, tagStartTime: t }) {
      (this.trackAdComponentMouseOver = () => {
        this.adState.mouseOver(),
          this.hoverData.timeToFirstHover ||
            (this.hoverData.timeToFirstHover = Xn.getTagTime()),
          (this.hoverData.hoverCount += 1),
          this.hoverTimer.startTimer(),
          io({
            output: Ze(this.hoverData.getData()).toION(),
            errorCode: "he",
            jsInfoCode: "hov",
          });
      }),
        (this.trackAdComponentMouseOut = () => {
          this.adState.mouseOut();
          const e = this.hoverTimer.endTimer();
          (e || 0 === e) &&
            ((this.hoverData.totalHoverTime += e),
            io({
              output: Ze(this.hoverData.getData()).toION(),
              errorCode: "he",
              jsInfoCode: "hov",
            }));
        }),
        (this.adState = e),
        (this.tagStartTime = t),
        (this.hoverData = new co()),
        (this.hoverTimer = new uo());
    }
  }
  class co {
    constructor() {
      (this.getData = () => [
        this.timeToFirstHover,
        this.hoverCount,
        this.totalHoverTime,
      ]),
        (this.hoverCount = 0),
        (this.totalHoverTime = 0),
        (this.timeToFirstHover = 0);
    }
  }
  class uo {
    constructor() {
      this.startTime = 0;
    }
    startTimer() {
      this.startTime = new Date().getTime();
    }
    endTimer() {
      let e;
      return (
        this.startTime && (e = new Date().getTime() - this.startTime),
        (this.startTime = 0),
        e
      );
    }
  }
  const { birthdate: lo } = e,
    go = new (class {
      constructor({ tagStartTime: e }) {
        (this.finalizeAllCollectedData = () => {
          this.hover.trackAdComponentMouseOut();
        }),
          (this.adState = new ro()),
          (this.tagStartTime = e),
          (this.click = new oo({ tagStartTime: e, adState: this.adState })),
          (this.hover = new ao({ tagStartTime: e, adState: this.adState }));
      }
      get adComponent() {
        return {
          trackClick: this.click.trackAdComponentClick,
          trackBlur: this.click.trackBlurClick,
          trackMouseOver: this.hover.trackAdComponentMouseOver,
          trackMouseOut: this.hover.trackAdComponentMouseOut,
        };
      }
      get mobile() {
        return {
          trackTouchEnd: this.click.trackMobileTouchEnd,
          trackTouchStart: this.click.trackMobileTouchStart,
          trackPointerUp: this.click.trackPointerUp,
          trackPointerDown: this.click.trackPointerDown,
        };
      }
      get omid() {
        return { trackClick: this.click.trackOmidClick };
      }
    })({ tagStartTime: lo }),
    mo = ({ omidVerificationClient: e, eventManager: n }) => {
      const i = "videoPlaybackEvent",
        r = at.getAggregator().request("omidAdSessionContext"),
        o = Xr(e),
        s = [],
        a = ((e) => ({
          isEmpty: () => 0 === e.length,
          toString: () => {
            let t = "{vEventCount:" + e.length + ",vEvents:[";
            for (let n = 0; n < e.length; n++) {
              const i = e[n];
              let r =
                (n > 0 ? ",{" : "{") +
                "t:" +
                i.t +
                ",rt:" +
                i.rt +
                ",tp:" +
                i.tp +
                ",sl:" +
                i.sl +
                ",ad_duration:" +
                i.ad_duration +
                ",volume:" +
                i.volume +
                ",devol:" +
                i.devol;
              void 0 !== i.avoc && (r += i.avoc >= 0 ? ",avoc:" + i.avoc : ""),
                void 0 !== i.grnd && (r += ",grnd:" + i.grnd),
                (t += r + "}");
            }
            return (t += "]}"), t;
          },
        }))(s);
      let c = new Date().getTime(),
        d = 0,
        u = 1,
        l = 0,
        g = !1,
        m = !1,
        p = !1,
        h = !1,
        f = null,
        v = !1;
      const y = function () {
          var e, t;
          const n =
              null ===
                (t =
                  null === (e = at.getAggregator().request("mScreenEvents")) ||
                  void 0 === e
                    ? void 0
                    : e.getCurrentEvent) || void 0 === t
                ? void 0
                : t.call(e),
            i = d > 0 && (null == u || u > 0);
          return n
            ? Object.assign(Object.assign({}, n), {
                percentInView: m ? 100 : n.percentInView,
                fullPercentInView: m ? 100 : n.fullPercentInView,
                isVideoPlaying: !0,
                isVideoPlayingInFullscreen: m,
                isSoundOn: i,
              })
            : n;
        },
        b = function (e) {
          if ([...Br, ...Gr, ...Hr].includes(e.type))
            try {
              h && (e.iasCached = !0);
              const t = e.hasOwnProperty("timestamp")
                  ? e.timestamp
                  : new Date().getTime(),
                o = t - (oe.measurementConfig.birthdate || t + 1),
                a = [];
              let b,
                w = !1;
              switch (e.type) {
                case "start":
                  a.push("adVideoStart"),
                    (r.videoStartArrived = !0),
                    at.getAggregator().trigger("omidrendvideostart"),
                    (c = t),
                    (l = e.data.duration || "0"),
                    l > 1e3 && (l /= 1e3),
                    (d =
                      null != e.data.mediaPlayerVolume
                        ? e.data.mediaPlayerVolume
                        : e.data.videoPlayerVolume),
                    (u = null != e.data.deviceVolume ? e.data.deviceVolume : 1),
                    "audio" === r.creativeType &&
                      0 === d &&
                      at
                        .getAggregator()
                        .trigger("addThrottledProp", "env", "smu", 1);
                  break;
                case "volumeChange":
                  a.push("volumeChanged"),
                    (d =
                      null != e.data.mediaPlayerVolume
                        ? e.data.mediaPlayerVolume
                        : e.data.videoPlayerVolume),
                    (u = null != e.data.deviceVolume ? e.data.deviceVolume : 1);
                  break;
                case "firstQuartile":
                  a.push("adVideoFirstQuartile"),
                    (w = !0),
                    at
                      .getAggregator()
                      .trigger("videoQuartileEvent", {
                        videoEvent: e,
                        screenEvent: y(),
                      });
                  break;
                case "midpoint":
                  a.push("adVideoMidpoint"),
                    (w = !0),
                    at
                      .getAggregator()
                      .trigger("videoQuartileEvent", {
                        videoEvent: e,
                        screenEvent: y(),
                      });
                  break;
                case "thirdQuartile":
                  a.push("adVideoThirdQuartile"),
                    (w = !0),
                    at
                      .getAggregator()
                      .trigger("videoQuartileEvent", {
                        videoEvent: e,
                        screenEvent: y(),
                      });
                  break;
                case "complete":
                  a.push("adVideoComplete"),
                    (w = !0),
                    at
                      .getAggregator()
                      .trigger("videoQuartileEvent", {
                        videoEvent: e,
                        screenEvent: y(),
                      });
                  break;
                case "bufferStart":
                  a.push("bufferStart");
                case "pause":
                  a.push("pauseAd");
                  break;
                case "bufferFinish":
                  a.push("bufferFinish");
                case "resume":
                  a.push("resumeAd");
                  break;
                case "skipped":
                  a.push("adSkipped");
              }
              if (
                ((d = d > 0 && d < 0.1 ? 0.1 : parseInt(10 * d) / 10),
                (u = u > 0 && u < 0.1 ? 0.1 : parseInt(10 * u) / 10),
                a.length > 0)
              ) {
                const e = at.getAggregator().request("mScreenEvents");
                let n,
                  i = "n";
                e && (i = e.getCurrentLoc() || i);
                try {
                  const t = e.getLatestEvent();
                  n =
                    d > 0 &&
                    ((Ye(u) && u > 0) || void 0 === u) &&
                    t &&
                    t.percentInView &&
                    t.percentInView >= 50
                      ? 1
                      : 0;
                } catch (e) {}
                const g = null != (null == r ? void 0 : r.grnd) ? r.grnd : "u";
                for (let e = 0; e < a.length; e++) {
                  const r = a[e],
                    m = {
                      t: t - c,
                      rt: o,
                      tp: r,
                      sl: i,
                      ad_duration: l,
                      volume: d,
                      devol: u,
                      grnd: g,
                    };
                  "adVideoComplete" === r && (m.avoc = n), s.push(m);
                }
              }
              if (
                ("loaded" === e.type &&
                  Ye(e.data) &&
                  ((e, t, n) => {
                    const i = [
                        "preroll",
                        "midroll",
                        "postroll",
                        "standalone",
                      ].indexOf(e.data.position),
                      r = -1 !== i ? i + 1 : void 0,
                      o = [];
                    o.push(
                      !0 === e.data.autoPlay ? "autoplayed" : "clicktoplay"
                    ),
                      !0 === e.data.skippable && o.push("skippable");
                    const s = "fullscreen" === e.data.state;
                    s && ((n.loadedInFullscreen = !0), o.push("fullscreen"));
                    const a = o.join(".");
                    return (
                      t
                        ? (Ye(r) &&
                            at
                              .getAggregator()
                              .trigger("addThrottledProp", "env", "vbp", r),
                          at
                            .getAggregator()
                            .trigger("addThrottledProp", "env", "vps", a))
                        : (Ye(r) &&
                            at
                              .getAggregator()
                              .trigger("addOutputItem", { output: r }, "vbp", {
                                type: "impression",
                              }),
                          at
                            .getAggregator()
                            .trigger("addOutputItem", { output: a }, "vps", {
                              type: "impression",
                            })),
                      s
                    );
                  })(e, p, r) &&
                  (m = !0),
                "start" === e.type &&
                  (at
                    .getAggregator()
                    .trigger("omidAdDuration", { ad_duration: l }),
                  (r.adDuration = l)),
                "playerStateChange" === e.type
                  ? ((m = "fullscreen" === e.data.state),
                    (b =
                      "fullscreen" === e.data.state
                        ? "AdEnteredFullscreen"
                        : "AdExitedFullscreen"))
                  : Br.includes(e.type)
                  ? ((b = "AdPlaying"), (g = !0))
                  : Gr.includes(e.type) && ((b = "AdPaused"), (g = !1)),
                "audio" === r.creativeType && !v)
              ) {
                g && d > 0 && u > 0
                  ? null === f && (f = t)
                  : (null !== f &&
                      t - f >= 1990 &&
                      (at
                        .getAggregator()
                        .trigger("addThrottledProp", "env", "aco", 1),
                      (v = !0)),
                    (f = null));
              }
              if ("audio" === r.creativeType && a.length > 0) {
                const e = ((e, t, n, i, r) => {
                  const o = {
                    type: "geometryChange",
                    timestamp: i,
                    internallyGenerated: !0,
                    treatAsCached: r,
                    data: {
                      viewport: { width: e, height: t },
                      adView: {
                        measuringElement: !1,
                        percentageInView: n,
                        geometry: {
                          x: 0,
                          y: 0,
                          width: e,
                          height: t,
                          obstructions: [],
                          reasons: [],
                        },
                        reasons: [],
                      },
                    },
                  };
                  return (
                    (o.data.adView.onScreenGeometry =
                      o.data.adView.containerGeometry =
                      o.data.adView.onScreenContainerGeometry =
                        o.data.adView.geometry),
                    o
                  );
                })(20, 20, 100, t, h);
                (g && 0 !== u && 0 !== d) ||
                  ((e.data.adView.geometry.width =
                    e.data.adView.geometry.height =
                      0),
                  (e.data.adView.percentageInView = 0)),
                  at
                    .getAggregator()
                    .trigger("internallyGeneratedGeometryEvent", e);
              }
              h &&
                "loaded" !== e.type &&
                ((r.cachedVideoEventsReceived = !0),
                "start" === e.type &&
                  (r.cachedStartEventIndex = r.cachedEvents.length),
                r.cachedEvents.push(e)),
                Ye(b) && n.trigger(i, { eventType: b, eventData: null }),
                "start" === e.type &&
                  at
                    .getAggregator()
                    .trigger(
                      "videoStartEvent",
                      h ? e : { videoEvent: e, screenEvent: y() }
                    ),
                w && at.getAggregator().trigger("sendDt", "m");
            } catch (e) {
              __IntegralASDiagnosticCall("omidvideo", e, t.bootstrapper);
            }
        },
        w = function () {
          "audio" !== r.creativeType ||
            v ||
            null === f ||
            (new Date().getTime() - f >= 1990 &&
              (at.getAggregator().trigger("addThrottledProp", "env", "aco", 1),
              (v = !0)));
        };
      return {
        start: function () {
          at.getAggregator().on("impressionsent", function () {
            p = !0;
          }),
            at.getAggregator().provide({ omidVideoEventsString: a }),
            (h = !0),
            "audio" === r.creativeType
              ? o.addEventListener("media", b)
              : o.addEventListener("video", b),
            (h = !1),
            "audio" === r.creativeType && at.getAggregator().on("preSendDt", w),
            (r.cachedVideoEventsChecked = !0),
            r.cachedVideoEventsReceived && r.processCachedEvents();
        },
        addVideoPlaybackEventListener: function (e) {
          n.on(i, e);
        },
      };
    },
    po = (e, t) =>
      e && t && "number" == typeof e.x
        ? t.reduce((t, n) => {
            if (n && "number" == typeof n.x) {
              const i = Math.max(n.x, e.x),
                r = Math.max(n.y, e.y),
                o = Math.min(n.x + n.width, e.x + e.width) - i,
                s = Math.min(n.y + n.height, e.y + e.height) - r;
              o > 0 && s > 0 && t.push({ x: i, y: r, width: o, height: s });
            }
            return t;
          }, [])
        : t || [],
    ho = (e) => {
      const t = () => {
        const n = _i
          .getDoc()
          .getElementById("iasbi" + (oe.adTag && oe.adTag.asid));
        n && n.hasAttribute("CreativeLoaded") ? e() : _i.setTimeout(t, 50);
      };
      return t;
    },
    fo = (e) => (e && e.indexOf("backgrounded") > -1 ? "b" : "f"),
    vo = function (e) {
      const t = {
          inactive: "f",
          viewport: "l",
          clipped: "l",
          obstructed: "o",
          backgrounded: "f",
          notFound: "h",
          hidden: "h",
          noWindowFocus: "w",
          noOutputDevice: "u",
          unmeasurable: "m",
          pictureInPicture: "p",
          deviceLocked: "k",
        },
        n = [];
      return e
        ? (e.forEach(function (e) {
            const i = t[e];
            i && n.indexOf(i) < 0 && n.push(i);
          }),
          n.join("."))
        : "";
    },
    yo = function (e, t) {
      var n, i, r;
      let o = t;
      const s = e.data || {},
        a =
          null !==
            (r =
              null !==
                (i =
                  null !== (n = s.mediaPlayerVolume) && void 0 !== n
                    ? n
                    : s.videoPlayerVolume) && void 0 !== i
                ? i
                : e.volume) && void 0 !== r
            ? r
            : e.adVolume,
        c = s.deviceVolume;
      return (
        "number" == typeof a
          ? (o = a > 0 && (null == c || c > 0))
          : "number" == typeof c && (o = c > 0),
        o
      );
    },
    bo = function (e, t, n, i, r) {
      const o = r ? 100 : e,
        s = {
          percentInView: o,
          fullPercentInView: o,
          tabHidden: 0,
          isVideoPlaying: t,
          isVideoPlayingInFullscreen: r,
          isSoundOn: n,
        };
      return i && (s.adDimensions = new ei(i)), s;
    },
    wo = function (e, t) {
      "use strict";
      const n = new Ii(),
        i = mo({ omidVerificationClient: e, eventManager: t });
      return {
        start: function () {
          i.start(), n.init();
        },
        addVideoPlaybackEventListener: i.addVideoPlaybackEventListener,
      };
    },
    Ao = function (e, t) {
      "use strict";
      const n = "measurementChanged";
      let i = !1;
      const r = function (e) {
          return e >= 50;
        },
        o = function (e) {
          const o = e.percentageInView;
          (i = !0),
            (e.viewState = (function (e) {
              return r(e) ? "inView" : "outOfView";
            })(o)),
            (e.outOfViewReason = r(o) ? "" : "l"),
            t.trigger(n, e);
        };
      return {
        start: function () {
          at
            .getAggregator()
            .trigger("addOutputItem", { output: "d" }, "mtp", {
              type: "impression",
            }),
            e.addScreenLocationChangedListener(o),
            e.start();
        },
        getStrategyName: function () {
          return "display";
        },
        addMeasurementChangedListener: function (e) {
          t.on(n, e);
        },
        isMeasurable: function () {
          return i;
        },
      };
    },
    Io = function (e, t, n) {
      "use strict";
      const i = Ye(e) ? e.environment : void 0,
        r = Ye(e) ? e.measurementStrategy : void 0,
        o = function () {
          return Ye(r);
        };
      Ye(t) && t.start();
      return {
        hasMeasurementStrategy: o,
        getScreenLocationInfo: function (e) {
          return t.create(e);
        },
        isImmediate: function () {
          return !o() || i.isImmediate();
        },
        isMeasurable: function () {
          return !!o() && r.isMeasurable();
        },
        isMediaType: function (e) {
          return !!o() && i.isMediaType(e);
        },
        supportsAdContainerGeometry: function () {
          return e.environment.supportsAdContainerGeometry();
        },
        start: function () {
          o() && i.start();
        },
        requiresDelayedViewabilityEvent: function () {
          o() && t.requiresDelayedViewabilityEvent();
        },
      };
    },
    So = function (e, t, n) {
      "use strict";
      const i = at.getAggregator().request("mobileApp");
      return {
        create: function () {
          let t = [];
          (t = t.concat(e.getOmidMeasurementStrategies())),
            (t = t.concat(e.getMraidMeasurementStrategies()));
          const n = new Co(t).resolve();
          n ||
            at
              .getAggregator()
              .trigger("addOutputItem", { output: "0" }, "oam", {
                type: "impression",
              });
          const r = new Oo(n);
          return new Io(n, r, i.isMobileAppEnvironment());
        },
      };
    },
    To = function (e) {
      "use strict";
      const t = at.getAggregator().request("mobileApp");
      return {
        getOmidMeasurementStrategies: function () {
          const e = at.getAggregator().request("omidVerificationClient"),
            t = new qr(e),
            n = [];
          if (t.accepts()) {
            const i = new ko(),
              r = new Ro(),
              o = new Zr(),
              s = at.getAggregator().request("omidAdSessionContext"),
              a = new No(e, new zt()),
              c = [
                { environment: i, measurementStrategy: new Fo(e, new zt()) },
                {
                  environment: o,
                  measurementStrategy: new jo(
                    new gs(),
                    _i.getWindow(),
                    new zt()
                  ),
                },
                {
                  environment: r,
                  measurementStrategy: new Lo(
                    new Cs(),
                    _i.getWindow(),
                    new zt()
                  ),
                },
              ],
              d = new Co(c).resolve(),
              u = d ? d.measurementStrategy : {},
              l = new xo(new Vo(new Qs()), new Qs(), s.isHtml),
              g = new Ur(e, t, oe.adTag.tagType),
              m = new Po(a, u, new zt(), l),
              p = new Wr(e, t, oe.adTag.tagType),
              h = new _o(a, u, new wo(e, new zt()), new zt(), l);
            n.push({ environment: g, measurementStrategy: m }),
              n.push({ environment: p, measurementStrategy: h });
          }
          return n;
        },
        getMraidMeasurementStrategies: function () {
          const e = [],
            n = t.isSafeToInjectMraid(),
            i = t.isMobileAppEnvironment(),
            r = oe.mraidLifecycleTracker;
          null == r || r.refresh("strategy");
          let o = null == r ? void 0 : r.getSnapshot();
          const s = Boolean(
            xe() &&
              i &&
              !Xn.isOmid() &&
              !Xn.isVideo() &&
              (null == o ? void 0 : o.mraidEverObserved)
          );
          null == r || r.confirmEligibility(s),
            (o = null == r ? void 0 : r.getSnapshot());
          const a = new Uo(_i.getWindow(), n, i, s);
          if (a.accepts()) {
            const t = at.getAggregator().request("context"),
              n = new Do(_i.getWindow(), t),
              i = new qo(_i.getWindow(), new zt(), {
                useLifecycleTracker:
                  "eligible" === (null == o ? void 0 : o.eligibility),
              });
            let r;
            if (n.accepts()) {
              const e = new Mo(_i.getWindow(), new zt());
              r = {
                environment: n,
                measurementStrategy: new Eo(i, e, new zt()),
              };
            } else if (Xn.isVideo()) {
              (r = {
                environment: a,
                measurementStrategy: new Eo(i, void 0, new zt()),
              }),
                at
                  .getAggregator()
                  .trigger("addOutputItem", { output: "1" }, "xmvd", {
                    type: "impression",
                  });
            } else {
              r = { environment: a, measurementStrategy: new Ao(i, new zt()) };
            }
            e.push(r);
          }
          return e;
        },
      };
    },
    Co = function (e) {
      "use strict";
      return {
        resolve: function () {
          const t = e.find(function (e) {
            return e.environment.accepts();
          });
          if (Ye(t)) return t;
        },
      };
    },
    Oo = function (e) {
      "use strict";
      let t,
        n,
        i = !1;
      const r = {
          winDimensions: ei({ scrX: 0, scrY: 0, width: 0, height: 0 }),
          adDimensions: ei({ scrX: 0, scrY: 0, width: 0, height: 0 }),
          containerDimensions: ei({ scrX: 0, scrY: 0, width: 0, height: 0 }),
          method: "na",
          viewState: "na",
          percentInView: -1,
          reason: "",
          obstructed: "na",
          isHidden: "na",
          tabHidden: "na",
          posViewState: "na",
          adCompCount: 1,
        },
        o = function (e) {
          return e
            ? new ei({ scrX: e.x, scrY: e.y, width: e.width, height: e.height })
            : ei({ scrX: 0, scrY: 0, width: 0, height: 0 });
        },
        s = function (e) {
          n = {
            winDimensions: o(e.windowDimensions),
            adDimensions: o(e.adDimensions),
            containerDimensions: o(e.containerDimensions),
            method: e.detectionMethod || "na",
            viewState: e.viewState || "na",
            percentInView: Ye(e.percentageInView) ? e.percentageInView : -1,
            reason: e.outOfViewReason || "",
            obstructed: Ke(e.isObstructed),
            isHidden: "na",
            tabHidden: "na",
            posViewState: e.viewState || "na",
            adCompCount: 1,
            shouldDelegateToDomBasedViewability:
              e.shouldDelegateToDomBasedViewability,
            sliceStatus: e.sliceStatus,
            isVideoPlaying: e.isVideoPlaying,
            isVideoPlayingInFullscreen: e.isVideoPlayingInFullscreen,
            isSoundOn: e.isSoundOn,
          };
          const r = e.omidObstructions;
          Ye(r) && "" !== r && (n.omidObstructions = r),
            e.isMeasurable &&
              ((t = !0),
              i &&
                ((i = !1),
                at.getAggregator().trigger("delayedViewabilityReady")));
        };
      return {
        create: function (t) {
          let i = r;
          return (
            Ye(n) &&
              (e.environment.supportsAdContainerGeometry()
                ? (i = n)
                : n.shouldDelegateToDomBasedViewability
                ? ((i = Ye(t) ? t : r),
                  (i.method = Ye(i.method) ? i.method : "na"))
                : (0 === n.percentInView || n.percentInView >= 75) && (i = n)),
            i
          );
        },
        start: function () {
          let t;
          Ye(e) &&
            Ye(e.measurementStrategy) &&
            ((t = e.measurementStrategy),
            t.addMeasurementChangedListener(s),
            t.start());
        },
        requiresDelayedViewabilityEvent: function () {
          i = !0;
        },
      };
    },
    Eo = function (e, t, n) {
      "use strict";
      const i = "measurementChanged";
      let r,
        o,
        s,
        a,
        c = !1,
        d = !1,
        u = !1;
      const l = function (e) {
          return e < 50;
        },
        g = function () {
          if (void 0 === o) return;
          const e = [];
          let t, g;
          c
            ? (d ? ((g = !1), (t = 100)) : ((g = a), (t = s)),
              l(t) && e.push("l"))
            : ((g = !1), (t = 0), e.push("v")),
            (u = !0),
            (o.shouldDelegateToDomBasedViewability = g),
            (o.percentageInView = t),
            (o.viewState = (function (e) {
              return l(e) ? "outOfView" : "inView";
            })(t)),
            (o.outOfViewReason = e.join(".")),
            (r = o),
            n.trigger(i, r);
        },
        m = function (e) {
          (o = e),
            (s = e.percentageInView),
            (a = e.shouldDelegateToDomBasedViewability),
            g();
        },
        p = function (e) {
          const t = e.eventType;
          "AdEnteredFullscreen" === t
            ? (d = !0)
            : "AdExitedFullscreen" === t
            ? (d = !1)
            : -1 !== "AdStarted|AdVideoStart|AdPlaying".indexOf(t)
            ? (c = !0)
            : -1 !==
                "AdSkipped|AdUserClose|AdPaused|AdVideoComplete|AdStopped".indexOf(
                  t
                ) && (c = !1),
            g();
        };
      return {
        start: function () {
          at
            .getAggregator()
            .trigger("addOutputItem", { output: "v" }, "mtp", {
              type: "impression",
            }),
            e && (e.addScreenLocationChangedListener(m), e.start()),
            t && (t.addVideoPlaybackEventListener(p), t.start());
        },
        getStrategyName: function () {
          return "video";
        },
        addMeasurementChangedListener: function (e) {
          n.on(i, e);
        },
        isMeasurable: function () {
          return u;
        },
      };
    },
    Do = function (e, t) {
      "use strict";
      return {
        accepts: function () {
          return t.isInMobiMraidVideo();
        },
        isImmediate: function () {
          return !1;
        },
        supportsAdContainerGeometry: function () {
          return !1;
        },
        start: function () {
          try {
            let t;
            e.inmobi.IASDocumentVideoBuffer.addVideoEventListener(function (e) {
              "AdVideoStart" !== e.type ||
                t ||
                ((t = !0), at.getAggregator().trigger("adImpression"));
            });
          } catch (e) {}
        },
      };
    },
    Mo = function (e, t) {
      "use strict";
      const n = "inMobiMraidVideoPlaybackEvent",
        i = function (e) {
          try {
            const i = e.type;
            t.trigger(n, { eventType: i });
          } catch (e) {}
        };
      return {
        start: function () {
          try {
            const t = e.inmobi;
            t.IASDocumentVideoBuffer.addVideoEventListener(i);
          } catch (e) {}
        },
        addVideoPlaybackEventListener: function (e) {
          t.on(n, e);
        },
      };
    },
    xo = function (e, t, n) {
      "use strict";
      const i = function (e, t) {
          const n = Math.max(e.x, t.x),
            i = Math.max(e.y, t.y),
            r = Math.min(e.x + e.width, t.x + t.width) - n,
            o = Math.min(e.y + e.height, t.y + t.height) - i;
          return { x: n, y: i, width: r > 0 ? r : 0, height: o > 0 ? o : 0 };
        },
        r = function (e, t, n) {
          const r = i(t, e);
          return i(n, { x: 0, y: 0, width: r.width, height: r.height });
        },
        o = function (e, t) {
          const n = Xn.isOmidForWeb(),
            i = !Xn.isOmidSandboxedEnvironment(),
            r = n && i;
          return {
            x: r ? t.x : e.x + t.x,
            y: r ? t.y : e.y + t.y,
            width: t.width,
            height: t.height,
          };
        },
        s = function (e, t) {
          return {
            x: t.x - e.x,
            y: t.y - e.y,
            width: t.width,
            height: t.height,
          };
        };
      function a(e, t, n) {
        const i = s(t, n),
          o = r(e, t, i);
        return o.width * o.height;
      }
      const c = function (e) {
          return d(e) ? "inView" : "outOfView";
        },
        d = function (e) {
          return e >= 50;
        };
      return {
        calculateGeometricMeasurement: function (i, u) {
          if (!Ye(i) || !Ye(u)) return;
          const l = i.viewport,
            g = i.computedAdContainer,
            m = g.obstructions,
            p = i.omidObstructions,
            h = m && m.length > 0,
            f = i.originalAdContainer,
            v = u.adGeometry;
          let y = u.adFound;
          const b = i.detectionMethod;
          let w = 0;
          const A = { x: 0, y: 0, width: l.width, height: l.height },
            I = o(f, v);
          let S,
            T = i.outOfViewReason,
            C = 0,
            O = 0,
            E = h || !1;
          const D = v.width * v.height <= 1,
            M = !(
              !i.preserveOmidViewabilityOnZeroViewportFallback ||
              0 !== l.width ||
              0 !== l.height
            );
          n &&
            D &&
            ((y = !1),
            (T = (function (e, t) {
              let n = e || "";
              return (
                t ||
                  -1 !== n.indexOf("l") ||
                  (n = "l" + ("" !== n ? "." + n : "")),
                n
              );
            })(T, y))),
            y && M
              ? ((w = i.percentageInView),
                (S = (function (e, n) {
                  return t
                    .getConfig(e)
                    .percentInViewSliceArray.map(function (e) {
                      return e > 1 ? n >= e : n >= 100 * e;
                    });
                })(v, w)))
              : y && i.percentageInView > 0
              ? ((C = a(A, g, I)),
                (O = h
                  ? (function (t, n, i, a) {
                      const c = s(n, i),
                        d = r(t, n, c),
                        u = o(n, d);
                      return e.calculateObstructedArea(u, a);
                    })(A, g, I, m)
                  : 0),
                (w = Math.round(((C - O) / (I.width * I.height)) * 100)),
                h && 0 === O && (E = !1),
                (S = (function (n, i, r, o) {
                  let s,
                    c = 0;
                  const d = t.getConfig(r).numberOfSlices;
                  let u = _i.floor(r.height / d) || 1;
                  const l = [],
                    g = o ? e.getObstructionStatusBySlice(d) : [];
                  let m, p, h, f;
                  for (c = 0; c < d; c++)
                    (f = r.y + u * c),
                      c == d - 1 && (u = r.y + r.height - f),
                      (s = { x: r.x, y: f, width: r.width, height: u }),
                      (m = a(n, i, s)),
                      (p = m / (s.width * s.height) == 1),
                      l.push(p);
                  if (o)
                    for (h = _i.min(g.length, d), c = 0; c < h; c++)
                      l[c] = l[c] && !g[c];
                  return l;
                })(A, g, new ei(I).getRoundedGeometry(), E)))
              : (S = t.getConfig(v).defaultSliceArray);
          const x = {
            windowDimensions: A,
            containerDimensions: f,
            adDimensions: I,
            percentageInView: w,
            viewState: c(w),
            outOfViewReason: d(w) ? "" : T || "l",
            detectionMethod: b,
            isObstructed: E,
            sliceStatus: S,
          };
          return Ye(p) && "" !== p && (x.omidObstructions = p), x;
        },
      };
    },
    Po = function (e, t, n, i) {
      "use strict";
      const r = "geometryMeasurementChanged";
      let o, s, a;
      const c = function () {
          if (Ye(o) && Ye(s)) {
            const e = i.calculateGeometricMeasurement(o, s);
            (e.isMeasurable = !0), (a = !0), n.trigger(r, e);
          }
        },
        d = function (e) {
          (o = e), c();
        },
        u = function (e) {
          (s = e), c();
        };
      return {
        start: function () {
          at
            .getAggregator()
            .trigger("addOutputItem", { output: "d" }, "mtp", {
              type: "impression",
            }),
            e.addAdContainerGeometryMeasurementChangedListener(d),
            e.start(),
            t.addAdGeometryMeasurementChangedListener(u),
            t.start();
        },
        addMeasurementChangedListener: function (e) {
          n.on(r, e);
        },
        getStrategyName: function () {
          return "display";
        },
        isMeasurable: function () {
          return a;
        },
      };
    },
    Vo = function (e) {
      "use strict";
      const t = [];
      let n;
      const i = function (e, t) {
          const n = o(e, t),
            i = n.x - e.x,
            r = n.y - e.y,
            s = i + n.width,
            a = r + n.height;
          for (let t = Math.round(i); t < Math.round(s); t++)
            for (let n = Math.round(r); n < Math.round(a); n++)
              void 0 !== e.matrix[t] &&
                void 0 === e.matrix[t][n] &&
                ((e.matrix[t][n] = 1), (e.obscuredPixelCount += 1));
          return e;
        },
        r = function (e) {
          const t = Math.round(e.width),
            n = Math.round(e.height),
            i = new Array(t);
          let r = 0;
          for (; r < t; r++) i[r] = new Array(n);
          return {
            matrix: i,
            obscuredPixelCount: 0,
            x: Math.round(e.x),
            y: Math.round(e.y),
            width: t,
            height: n,
          };
        },
        o = function (e, t) {
          const n = Math.max(e.x, t.x),
            i = Math.max(e.y, t.y),
            r = Math.min(e.x + e.width, t.x + t.width) - n,
            o = Math.min(e.y + e.height, t.y + t.height) - i;
          return { x: n, y: i, width: r > 0 ? r : 0, height: o > 0 ? o : 0 };
        },
        s = function (e, t, n) {
          return e + (t - n);
        },
        a = function (e, t, n, i) {
          return e == t || n === i - 1;
        },
        c = function (t) {
          if (void 0 === t.matrix || 0 === t.matrix.length) return [];
          let n = 0,
            i = !1;
          const r = t.matrix[0].length,
            o = t.matrix.length,
            c = e.getConfig({ height: r }).numberOfSlices,
            d = _i.floor(r / c) || 1,
            u = [];
          for (let e = 0; e < r; e++) {
            i = !1;
            for (let n = 0; n < o; n++)
              if (1 === t.matrix[n][e]) {
                i = !0;
                break;
              }
            n++,
              i && ((e = s(e, d, n)), (n = d)),
              a(n, d, e, r) && (u.push(i), (n = 0), (i = !1));
          }
          return u;
        };
      return {
        calculateObstructedArea: function (e, o) {
          const s = o && o.length > 0;
          let a,
            d = s ? r(e) : {},
            u = 0,
            l = 0;
          if (s) {
            for (; u < o.length; u++) (a = o[u]), (d = i(d, a));
            (l = d.obscuredPixelCount), (n = c(d));
          } else n = t;
          return l;
        },
        getObstructionStatusBySlice: function () {
          return n;
        },
      };
    },
    No = function (e, t) {
      "use strict";
      const n = at.getAggregator().request("omidAdSessionContext");
      n.geometryChangeEvents = [];
      let i = null,
        r = !1;
      const o = Xr(e),
        s = new ia();
      let a = !1,
        c = !1;
      const d = function (e, t) {
          const i = { videoEvent: e, screenEvent: t };
          (n.cachedVideoSegmentEvents = n.cachedVideoSegmentEvents || []),
            n.cachedVideoSegmentEvents.push(i),
            at.getAggregator().trigger("cachedOmidVideoSegmentEvent", i);
        },
        u = ho(function () {
          (n.delayingViewabilityEvents = !1), (r = !1), i && (l(i), (i = null));
        }),
        l = function (e) {
          if (!(e && "geometryChange" === e.type && e.data && e.data.adView))
            return;
          const o = e.data.adView;
          if (
            (o.onScreenGeometry &&
              o.onScreenGeometry.obstructions &&
              o.onScreenGeometry.obstructions.length > 0 &&
              ((o.onScreenGeometry.obstructions = po(
                o.geometry,
                o.onScreenGeometry.obstructions
              )),
              0 === o.onScreenGeometry.obstructions.length &&
                o.reasons.indexOf("obstructed") > -1 &&
                (o.reasons = o.reasons.filter((e) => "obstructed" !== e))),
            o.onScreenContainerGeometry &&
              o.onScreenContainerGeometry.obstructions &&
              o.onScreenContainerGeometry.obstructions.length > 0 &&
              ((o.onScreenContainerGeometry.obstructions = po(
                o.geometry,
                o.onScreenContainerGeometry.obstructions
              )),
              0 === o.onScreenContainerGeometry.obstructions.length &&
                o.reasons.indexOf("obstructed") > -1 &&
                (o.reasons = o.reasons.filter((e) => "obstructed" !== e))),
            e.internallyGenerated || (n.grnd = fo(o.reasons)),
            "audio" === n.creativeType && !e.internallyGenerated)
          )
            return;
          const c = a || e.treatAsCached;
          c &&
            (n.cachedGeometryEventsReceived ||
              (n.cachedFirstGeometricIndex = n.cachedEvents.length),
            (n.cachedGeometryEventsReceived = !0),
            n.cachedEvents.push(e));
          const d = !!(
            o.measuringElement &&
            o.containerGeometry &&
            o.onScreenContainerGeometry
          );
          o.hasOwnProperty("pixelsInView") && (n.pixelsInView = o.pixelsInView);
          const l = n.cachedStartEventIndex;
          if (
            !c &&
            n.unrecoveredPlayTime &&
            "number" == typeof l &&
            l > -1 &&
            o.percentageInView >= 50 &&
            "audio" !== n.creativeType
          ) {
            const e = _i.now() - n.cachedEvents[l].timestamp,
              t = at.getAggregator().request("mScreenEvents");
            t && t.setRecoveredTimeInSlTimes && t.setRecoveredTimeInSlTimes(e);
          }
          if (
            (n.geometryChangeEvents.length < 10 &&
              (n.geometryChangeEvents.push(
                e.timestamp -
                  oe.measurementConfig.birthdate +
                  "." +
                  o.percentageInView
              ),
              at
                .getAggregator()
                .trigger(
                  "addOutputItem",
                  { output: n.geometryChangeEvents.join("_") },
                  "og"
                )),
            n.delayingViewabilityEvents)
          )
            (i = e), r || ((r = !0), u());
          else {
            const i = [];
            o.onScreenGeometry &&
              o.onScreenGeometry.obstructions &&
              o.onScreenGeometry.obstructions.length > 0 &&
              (!d ||
                (o.onScreenContainerGeometry.obstructions &&
                  0 !== o.onScreenContainerGeometry.obstructions.length) ||
                (o.onScreenContainerGeometry.obstructions =
                  o.onScreenGeometry.obstructions),
              o.reasons &&
                o.reasons.indexOf("obstructed") > -1 &&
                o.percentageInView < 100 &&
                ((o.onScreenGeometry.obstructions =
                  o.onScreenGeometry.obstructions.slice(0, 4)),
                o.onScreenGeometry.obstructions.forEach(function (e) {
                  i.push(
                    Math.round(e.x) +
                      "." +
                      Math.round(e.y) +
                      "." +
                      Math.round(e.width) +
                      "." +
                      Math.round(e.height)
                  );
                })));
            const r = Xn.isOmidForWeb()
                ? oi.calcWinDims()
                : { width: 0, height: 0 },
              a = (function (e) {
                const t = new ei(e || {}).getRoundedGeometry();
                return {
                  width: ot(t.width) ? t.width : 0,
                  height: ot(t.height) ? t.height : 0,
                };
              })(e.data.viewport),
              c = 0 === a.width && 0 === a.height,
              u = !(
                !(
                  Xn.isOmidForWeb() &&
                  c &&
                  0 === r.width &&
                  0 === r.height &&
                  o.percentageInView >= 50
                ) ||
                (o.reasons && 0 !== o.reasons.length)
              ),
              l = new ei(c ? r : e.data.viewport),
              g = new ei(
                d
                  ? o.containerGeometry
                  : o.geometry || { x: 0, y: 0, width: 0, height: 0 }
              ),
              m = new ei(
                d
                  ? o.onScreenContainerGeometry
                  : o.onScreenGeometry || { x: 0, y: 0, width: 0, height: 0 }
              ),
              p = {
                viewport: l.getRoundedGeometry(),
                originalAdContainer: g.getRoundedGeometry(),
                computedAdContainer: m.getRoundedGeometry(),
                percentageInView: o.percentageInView,
                detectionMethod: "o1",
                outOfViewReason: vo(o.reasons),
                omidObstructions: i.join("_"),
              };
            u && (p.preserveOmidViewabilityOnZeroViewportFallback = !0),
              void 0 === n.geometryArrived &&
                s.checkForViewAttachmentBasedOnAdSessionType(
                  n,
                  e.data.adView
                ) &&
                ((n.geometryArrived = !0),
                at.getAggregator().trigger("omidrendgeoupdate")),
              t.trigger("containerGeometryMeasurementChanged", p);
          }
        };
      n.processCachedEvents = function () {
        c ||
          (c = (function (e, t) {
            var n;
            const i = "video" === e.mediaType,
              r = e.supports && e.supports.join().indexOf("clid") > -1,
              o = "limited" === e.accessMode,
              s = "full" === e.accessMode,
              a = o || (s && r),
              c = !i || e.cachedVideoEventsChecked,
              d = e.cachedGeometryEventsChecked;
            if (a && d && c && e.cachedEvents.length > 0) {
              let r,
                o = "o",
                s = "o",
                a = 0,
                c = 0,
                d = 0,
                l = !i,
                g = !0,
                m = !!e.loadedInFullscreen,
                p = !1;
              const h = _i.now();
              let f;
              if (i) {
                const t = e.cachedStartEventIndex,
                  n = e.cachedFirstGeometricIndex;
                f = void 0 !== n ? e.cachedEvents[n] : void 0;
                const i = void 0 !== t ? e.cachedEvents[t] : void 0;
                f &&
                  i &&
                  f.timestamp > i.timestamp &&
                  (f.timestamp = i.timestamp);
              }
              for (let f = 0; f < e.cachedEvents.length; f++) {
                let f = h,
                  v = -1;
                for (let t = 0; t < e.cachedEvents.length; t++) {
                  const n = e.cachedEvents[t],
                    i = v > -1 ? e.cachedEvents[v] : void 0,
                    r = "geometryChange" === n.type,
                    o = "geometryChange" === (null == i ? void 0 : i.type);
                  !n.alreadyOrdered &&
                    (n.timestamp < f ||
                      (n.timestamp === f && (-1 === v || (r && !o)))) &&
                    ((f = n.timestamp), (v = t));
                }
                if (-1 === v) continue;
                const y = e.cachedEvents[v];
                y.alreadyOrdered = !0;
                const b = l;
                "geometryChange" === y.type && y.data && y.data.adView
                  ? ((a = y.data.adView.percentageInView),
                    (r =
                      (u = y.data.adView).geometry ||
                      u.onScreenGeometry ||
                      u.containerGeometry),
                    (p = !0))
                  : ((g = yo(y, g)),
                    "playerStateChange" === y.type &&
                      (m =
                        "fullscreen" ===
                        (null === (n = y.data) || void 0 === n
                          ? void 0
                          : n.state)),
                    Br.includes(y.type)
                      ? (l = !0)
                      : Gr.includes(y.type) && (l = !1)),
                  (s = (m || (a && a >= 50)) && l ? "i" : "o"),
                  "o" === o && "i" === s
                    ? (c = y.timestamp)
                    : "i" === o && "o" === s
                    ? (d += y.timestamp - c)
                    : "i" === o &&
                      "i" === s &&
                      ((d += y.timestamp - c), (c = y.timestamp)),
                  (o = s),
                  i && t(y, bo(a, "complete" === y.type ? b : l, g, r, m));
              }
              if (
                ("i" === o
                  ? (d += h - c)
                  : i &&
                    !p &&
                    void 0 !== e.cachedStartEventIndex &&
                    (e.unrecoveredPlayTime = !0),
                d > 0)
              ) {
                "audio" === e.creativeType &&
                  (d = Math.min(d, h - f.timestamp)),
                  (e.recoveredTime = d);
                const t = at.getAggregator().request("mScreenEvents");
                t &&
                  t.setRecoveredTimeInSlTimes &&
                  (t.setRecoveredTimeInSlTimes(d), (e.recoveredTime = -1));
              }
              return !0;
            }
            var u;
            return !1;
          })(n, d));
      };
      return {
        start: function () {
          (a = !0),
            void 0 !== n.impressionViewabilityMeasurement &&
              l(n.impressionViewabilityMeasurement),
            o.addEventListener("geometryChange", l),
            (a = !1),
            (n.cachedGeometryEventsChecked = !0),
            n.cachedGeometryEventsReceived && n.processCachedEvents(),
            at.getAggregator().on("internallyGeneratedGeometryEvent", l);
        },
        addAdContainerGeometryMeasurementChangedListener: function (e) {
          t.on("containerGeometryMeasurementChanged", e);
        },
        translateOmidOutOfViewReasons: vo,
      };
    },
    ko = function () {
      "use strict";
      const e = at.getAggregator().request("omidAdSessionContext");
      return {
        accepts: function () {
          return e && (e.isNative || e.isLimitedSandbox);
        },
      };
    },
    Fo = function (e, t) {
      "use strict";
      let n;
      const i = at.getAggregator().request("omidAdSessionContext");
      let r = null,
        o = !1;
      const s = Xr(e),
        a = new ia(),
        c = ho(function () {
          (i.delayingViewabilityEvents = !1), (o = !1), r && (d(r), (r = null));
        }),
        d = function (e) {
          if (!(e && "geometryChange" === e.type && e.data && e.data.adView))
            return;
          if (
            (e.internallyGenerated || (i.grnd = fo(e.data.adView.reasons)),
            "audio" === i.creativeType && !e.internallyGenerated)
          )
            return;
          const s = e.data.adView;
          if (
            (s.onScreenGeometry &&
              s.onScreenGeometry.obstructions &&
              s.onScreenGeometry.obstructions.length > 0 &&
              ((s.onScreenGeometry.obstructions = po(
                s.geometry,
                s.onScreenGeometry.obstructions
              )),
              0 === s.onScreenGeometry.obstructions.length &&
                s.reasons.indexOf("obstructed") > -1 &&
                (s.reasons = s.reasons.filter((e) => "obstructed" !== e))),
            s.onScreenContainerGeometry &&
              s.onScreenContainerGeometry.obstructions &&
              s.onScreenContainerGeometry.obstructions.length > 0 &&
              ((s.onScreenContainerGeometry.obstructions = po(
                s.geometry,
                s.onScreenContainerGeometry.obstructions
              )),
              0 === s.onScreenContainerGeometry.obstructions.length &&
                s.reasons.indexOf("obstructed") > -1 &&
                (s.reasons = s.reasons.filter((e) => "obstructed" !== e))),
            i.delayingViewabilityEvents)
          )
            (r = e), o || ((o = !0), c());
          else {
            const r = e.data.adView.geometry,
              o = e.data.adView.containerGeometry,
              s = !!r,
              c = e.data.adView.measuringElement && !!o,
              d = new ei({
                x: s && c ? r.x - o.x : 0,
                y: s && c ? r.y - o.y : 0,
                width: s ? r.width : 0,
                height: s ? r.height : 0,
              }).getRoundedGeometry();
            (n = d),
              void 0 === i.geometryArrived &&
                a.checkForViewAttachmentBasedOnAdSessionType(
                  i,
                  e.data.adView
                ) &&
                ((i.geometryArrived = !0),
                at.getAggregator().trigger("omidrendgeoupdate")),
              t.trigger("omidGeometryChanged", { adGeometry: d, adFound: s });
          }
        };
      return {
        start: function () {
          void 0 !== i.impressionViewabilityMeasurement &&
            d(i.impressionViewabilityMeasurement),
            s.addEventListener("geometryChange", d),
            at.getAggregator().on("internallyGeneratedGeometryEvent", d);
        },
        addAdGeometryMeasurementChangedListener: function (e) {
          t.on("omidGeometryChanged", e);
        },
      };
    },
    Ro = function () {
      "use strict";
      const e = at.getAggregator().request("omidAdSessionContext");
      return {
        accepts: function () {
          return e && !e.isNative;
        },
      };
    },
    jo = function (e, t, n) {
      "use strict";
      let i;
      const r = function () {
        const t = e.find();
        let r,
          o,
          s,
          a = !1;
        Ye(t) && null !== t
          ? ((s = !0),
            (o = t.getBoundingClientRect()),
            (r = {
              x: o.x || o.left,
              y: o.y || o.top,
              width: o.width,
              height: o.height,
            }),
            t.hasOwnProperty("adWasClipped") && (r.adWasClipped = !0))
          : (i && ((a = !0), (r = { x: 0, y: 0, width: 0, height: 0 })),
            (s = !1)),
          ((s &&
            (function (e) {
              return !Ye(i) || !1 !== Ze(e).compareTo(i);
            })(r)) ||
            a) &&
            ((i = r),
            n.trigger("omidGeometryChanged", { adGeometry: r, adFound: s }));
      };
      return {
        start: function () {
          r(), t.setInterval(r, 50);
        },
        addAdGeometryMeasurementChangedListener: function (e) {
          n.on("omidGeometryChanged", e);
        },
      };
    },
    _o = function (e, t, n, i, r) {
      "use strict";
      const o = "videoGeometryMeasurementChanged";
      let s,
        a,
        c,
        d,
        u,
        l = !1,
        g = !1;
      const m = function () {
          if (void 0 === a || void 0 === c || void 0 === d) return;
          u = !0;
          const e = r.calculateGeometricMeasurement(a, c),
            t = l && g,
            n = l && e.percentageInView >= 50,
            m = {
              windowDimensions: e.windowDimensions,
              containerDimensions: e.containerDimensions,
              adDimensions: e.adDimensions,
              percentageInView: e.percentageInView,
              detectionMethod: e.detectionMethod,
              isMeasurable: !0,
              isObstructed: e.isObstructed,
              sliceStatus: e.sliceStatus,
              isVideoPlaying: l,
              isVideoPlayingInFullscreen: t,
              isSoundOn: !0,
            },
            p = e.omidObstructions;
          Ye(p) && "" !== p && (m.omidObstructions = p),
            t && (m.percentageInView = 100),
            t || n
              ? (m.viewState = "inView")
              : ((m.viewState = "outOfView"),
                (m.outOfViewReason = e.outOfViewReason || "v")),
            (s = m),
            i.trigger(o, s);
        },
        p = function (e) {
          (a = e), m();
        },
        h = function (e) {
          (c = e), m();
        },
        f = function (e) {
          d = e;
          const t = e.eventType;
          "AdEnteredFullscreen" === t
            ? (g = !0)
            : "AdExitedFullscreen" === t
            ? (g = !1)
            : -1 !== "AdStarted|AdVideoStart|AdPlaying".indexOf(t)
            ? (l = !0)
            : -1 !==
                "AdSkipped|AdUserClose|AdPaused|AdVideoComplete|AdStopped|AdError".indexOf(
                  t
                ) && (l = !1),
            m();
        };
      return {
        start: function () {
          at
            .getAggregator()
            .trigger("addOutputItem", { output: "v" }, "mtp", {
              type: "impression",
            }),
            e.addAdContainerGeometryMeasurementChangedListener(p),
            e.start(),
            t.addAdGeometryMeasurementChangedListener(h),
            t.start(),
            n.addVideoPlaybackEventListener(f),
            n.start();
        },
        getStrategyName: function () {
          return "video";
        },
        addMeasurementChangedListener: function (e) {
          i.on(o, e);
        },
        isMeasurable: function () {
          return u;
        },
      };
    },
    Lo = function (e, t, n) {
      "use strict";
      let i;
      const r = function () {
        const t = e.find();
        let r,
          o,
          s,
          a = !1;
        Ye(t)
          ? ((s = !0),
            (o = t.getBoundingClientRect()),
            (r = { x: o.left, y: o.top, width: o.width, height: o.height }),
            t.hasOwnProperty("adWasClipped") && (r.adWasClipped = !0))
          : (i && ((a = !0), (r = { x: 0, y: 0, width: 0, height: 0 })),
            (s = !1)),
          ((s &&
            (function (e) {
              return !Ye(i) || !1 !== Ze(e).compareTo(i);
            })(r)) ||
            a) &&
            ((i = r),
            n.trigger("omidGeometryChanged", { adGeometry: r, adFound: s }));
      };
      return {
        start: function () {
          r(), t.setInterval(r, 50);
        },
        addAdGeometryMeasurementChangedListener: function (e) {
          n.on("omidGeometryChanged", e);
        },
      };
    },
    Uo = function (e, t, n, i) {
      "use strict";
      return {
        accepts: function () {
          const r = e.mraid;
          return !(
            !n ||
            !(
              ("object" == typeof r && null !== r && !(r instanceof Array)) ||
              t ||
              i
            )
          );
        },
        isImmediate: function () {
          return !0;
        },
        supportsAdContainerGeometry: function () {
          return !1;
        },
        start: function () {},
      };
    },
    qo = function (e, t, n) {
      "use strict";
      const i = !!(null == n ? void 0 : n.useLifecycleTracker),
        r = "mraidScreenLocationChanged",
        o = "mraid.js";
      let s,
        a = !1,
        c = !1,
        d = !1,
        u = !1,
        l = !1,
        g = 0;
      const m = function (e) {
          var t;
          if ((s && (s.stop(), (s = void 0)), e))
            try {
              Fe(
                null === (t = oe.mraidLifecycleTracker) || void 0 === t
                  ? void 0
                  : t.getSnapshot()
              );
            } catch (e) {}
        },
        p = function () {
          try {
            if (d || l || u) return;
            u = !0;
            const e = { x: 0, y: 0, width: 0, height: 0 };
            t.trigger(r, {
              windowDimensions: e,
              adDimensions: e,
              containerDimensions: e,
              shouldDelegateToDomBasedViewability: !0,
              isMeasurable: !0,
              isObstructed: !1,
              isHidden: !1,
              percentageInView: 100,
              detectionMethod: "m",
              sliceStatus: [!0],
            }),
              De(() => {
                Ee("semfd", 1);
              });
          } catch (e) {}
        },
        h = function () {
          try {
            if (d) return void m(!1);
            const e = oe.mraidLifecycleTracker,
              t = null == e ? void 0 : e.getSnapshot();
            if (!(null == t ? void 0 : t.active)) return void m(!1);
            null == e || e.refreshPending(), (g += 1), g >= 10 && m(!0);
          } catch (e) {
            m(!1);
          }
        },
        f = function (n) {
          var o;
          let s, a, c;
          try {
            if (i) {
              s = (void 0 !== n ? n : e.mraid.isViewable()) ? 100 : 0;
            } else s = e.mraid.isViewable() ? 100 : 0;
            const u = { x: 0, y: 0, width: 0, height: 0 };
            if (
              ((c = 100 === s ? [!0] : [!1]),
              (a = {
                windowDimensions: u,
                adDimensions: u,
                containerDimensions: u,
                shouldDelegateToDomBasedViewability: !1,
                isMeasurable: !0,
                isObstructed: !1,
                isHidden: !1,
                percentageInView: s,
                detectionMethod: "m",
                sliceStatus: c,
              }),
              t.trigger(r, a),
              !l &&
                "eligible" ===
                  (null === (o = oe.mraidLifecycleTracker) || void 0 === o
                    ? void 0
                    : o.getSnapshot().eligibility))
            ) {
              l = !0;
              try {
                (d = Xn.getTagTime()),
                  De(() => {
                    Ee("semac", 1), Ee("semme", 1), Ee("semmt", d);
                  });
              } catch (e) {}
            }
            return !0;
          } catch (e) {}
          var d;
          return !1;
        },
        v = function () {
          try {
            const t = e.mraid;
            (a = !0),
              f(),
              Je(null == t ? void 0 : t.addEventListener) &&
                t.addEventListener("viewableChange", f);
          } catch (e) {}
        },
        y = function () {
          try {
            const t = e.mraid;
            (function () {
              const t = e.mraid;
              return (
                "object" == typeof t &&
                null !== t &&
                !(t instanceof Array) &&
                Je(t.isViewable)
              );
            })() &&
              ((c = !0),
              Je(null == t ? void 0 : t.getState) && "loading" === t.getState()
                ? Je(null == t ? void 0 : t.addEventListener) &&
                  t.addEventListener("ready", function () {
                    v();
                  })
                : v());
          } catch (e) {}
        },
        b = function () {
          c || y();
        },
        w = function () {
          if (!i) return !1;
          let e = "tracker_unavailable";
          try {
            const t = oe.mraidLifecycleTracker;
            null == t || t.refresh("handoff");
            const n = null == t ? void 0 : t.getSnapshot();
            if (t && "eligible" === (null == n ? void 0 : n.eligibility)) {
              const i = (e) => {
                try {
                  if (d) return;
                  f(e) &&
                    ((d = !0),
                    u &&
                      De(() => {
                        Ee("semtt", 1);
                      }),
                    m(!0));
                } catch (e) {}
              };
              t.subscribe({
                onUsable: () => {
                  i();
                },
                onViewableChange: (e) => {
                  d ? f(e) : i(e);
                },
              }),
                (e =
                  "usable" === n.availability
                    ? "none"
                    : `pending_${n.availability}`),
                "usable" === n.availability &&
                  (i(), d || (e = "activation_failed")),
                d || (p(), s || ((g = 0), (s = Tn(h, 500)), s.start()));
            } else e = "tracker_inactive";
            try {
              Ve(n, !0, e, Xn.getTagTime());
            } catch (e) {}
          } catch (t) {
            e = "tracker_error";
            try {
              Ve(void 0, !1, e, Xn.getTagTime());
            } catch (e) {}
          }
          return !0;
        };
      return {
        start: function () {
          w() ||
            (!(function () {
              let t = !0;
              return (
                (Ye(e.mraid) || oi.containsScriptTagWithSrc(o)) && (t = !1),
                at
                  .getAggregator()
                  .trigger("addOutputItem", { output: Ke(t) }, "mi", {
                    type: "impression",
                  }),
                t
              );
            })()
              ? y()
              : at.getAggregator().trigger("exec", o, b));
        },
        addScreenLocationChangedListener: function (e) {
          t.on(r, e);
        },
      };
    },
    Wo = function (e, t, n) {
      "use strict";
      const i = {};
      return (
        n &&
          Ze(n).map(function (n, r) {
            i[n] = (function (n) {
              let i = nt;
              return (
                t.bootstrapOn("useViewabilityNotification") &&
                  (i = function () {
                    e.skipAsFraudulent() ||
                      at.getAggregator().trigger("notify", n);
                  }),
                i
              );
            })(r);
          }),
        {
          getCallbacks: function () {
            return i;
          },
        }
      );
    },
    Bo = function () {
      "use strict";
      const t = new Jo({ tiv: [1e4] }),
        n = ["inView", "partialViewPlus"];
      return {
        timeInViewThresholds: t,
        type: "pf",
        rts: {},
        isInView: function (e) {
          const t = _i.max(e.fullPercentInView || 0, e.percentInView);
          return -1 !== n.indexOf(e.viewState) && 100 === t;
        },
        applies: function (t, n) {
          return (
            t.on("abcAudit") &&
            925955 == e.anId &&
            n.usesIASFullyInViewCustomMetric()
          );
        },
        minUnit: 1e3,
        shouldIncludeSound: !1,
      };
    },
    Go = function (t, n) {
      "use strict";
      let i, r, o;
      const s = t.on("everySecond"),
        a = n.isVideo(),
        c = [
          1e3, 2e3, 3e3, 4e3, 5e3, 6e3, 7e3, 8e3, 9e3, 1e4, 11e3, 12e3, 13e3,
          14e3, 15e3,
        ],
        d = [1e3, 5e3, 15e3, 3e4, 45e3, 6e4, 9e4],
        u = [2e3, 5e3, 15e3],
        l = function (e, t) {
          return (
            -1 !==
            "inView|partialViewPlus".indexOf(
              e[t ? "viewStateIgnoringRender" : "viewState"]
            )
          );
        };
      return (
        s
          ? ((i = new Jo({ tiv: c })), (r = c[0]))
          : a
          ? ((i = new Jo({ tiv: u })), (r = u[0]))
          : ((i = new Jo({ tiv: d })), (r = d[0])),
        (o = { 5e3: e._onInViewMRC5, 15e3: e._onInViewMRC15 }),
        (o[r] = e._onInViewMRC),
        {
          timeInViewThresholds: i,
          type: "p",
          rts: o,
          isInView: l,
          isInViewIgnoringRender: function (e) {
            return l(e, !0);
          },
          applies: !0,
          minUnit: 1e3,
          shouldIncludeSound: !1,
          sendOtherwiseInViewSignal: !0,
        }
      );
    },
    Ho = function (e, t) {
      "use strict";
      let n;
      const i = e.on("everySecond"),
        r = t.isVideo(),
        o = t.usesIASFullyInViewCustomMetric(),
        s = function (e) {
          const t = _i.max(e.fullPercentInView || 0, e.percentInView);
          return (
            -1 !== "inView|partialViewPlus".indexOf(e.viewState) && 100 === t
          );
        };
      return (
        (n = new Jo(
          i
            ? {
                tiv: [
                  1e3, 2e3, 3e3, 4e3, 5e3, 6e3, 7e3, 8e3, 9e3, 1e4, 11e3, 12e3,
                  13e3, 14e3, 15e3,
                ],
              }
            : r
            ? { tiv: [2e3, 5e3, 15e3] }
            : { tiv: [1e3, 5e3, 15e3] }
        )),
        at
          .getAggregator()
          .provide("isFullyInViewProvider", { isFullyInView: s }),
        {
          timeInViewThresholds: n,
          type: "pf",
          isInView: s,
          applies: function () {
            return o;
          },
          minUnit: 1e3,
          shouldIncludeSound: !1,
        }
      );
    },
    $o = function (t, n) {
      "use strict";
      return {
        timeInViewThresholds: new Jo({ tiv: [0] }),
        type: "pf",
        rts: { 0: e._onInViewFull },
        isInView: function (e) {
          const t = _i.max(e.fullPercentInView || 0, e.percentInView);
          return (
            -1 !== "inView|partialViewPlus".indexOf(e.viewState) && 100 === t
          );
        },
        applies: function () {
          return n.usesGroupMCustomMetric();
        },
        minUnit: 1e3,
        shouldIncludeSound: !1,
      };
    },
    zo = /^q[1-4](?:\|q[1-4])*:(?:[1-9]\d*|(?:[1-9]\d?|100)%)$/i,
    Xo = function (t, n) {
      "use strict";
      let i, r, o;
      const s = Number.MAX_VALUE,
        a = n.isVideo();
      let c;
      const d = t.id,
        u = t.sound && "on" === t.sound,
        l =
          !(
            t.soundExcl &&
            "groupm_native" === t.soundExcl &&
            e.groupm_native_publisher
          ) && u,
        g = t.qiv || [];
      let m, p, h;
      const f = function () {
          (m = []), (p = []), (h = !1);
          let e = !1;
          g.forEach(function (t) {
            if (a && "string" == typeof t) {
              h = !0;
              const n = (function (e) {
                if ("string" != typeof e || !zo.test(e)) return;
                const t = e.split(":"),
                  n = t[1],
                  i = -1 !== n.indexOf("%"),
                  r = t[0]
                    .split("|")
                    .map((e) =>
                      Number.parseInt(e.toLowerCase().replace("q", ""), 10)
                    ),
                  o = Number.parseInt(n.replace("%", ""), 10);
                return {
                  segments: r,
                  requirement: n,
                  requirementType: i ? "percentage" : "seconds",
                  requirementValue: o,
                };
              })(t);
              n ? p.push(n) : (e = !0);
            } else "number" == typeof t && m.push(t);
          });
          const t = h && m.length > 0;
          (e || t) && ((p = []), (m = []));
        },
        v = function (e, n) {
          if (!e.adDimensions) return !1;
          const i = n ? "percentInViewIgnoringRender" : "percentInView";
          let r, o, c;
          const d = e.adDimensions.area(),
            u = 1 === e.tabHidden,
            g = _i.max(e.fullPercentInView || 0, e[i]),
            m = t.thresholds.find(function (e) {
              if (((r = e.lb || 0), (o = e.ub || s), d >= r && d <= o))
                return !0;
            });
          return (
            (c = !u && g >= m.piv),
            (function (e) {
              return "s" == e.method;
            })(e) &&
              (function (e) {
                return 0 === e.tiv;
              })(t) &&
              (c = !1),
            a && ((c = c && e.isVideoPlaying), l && (c = c && e.isSoundOn)),
            c
          );
        };
      return (
        f(),
        (function () {
          const e = h || p.length > 0;
          i = new Jo(e ? {} : t);
        })(),
        (r = m.length > 0 && 0 === p.length ? m : void 0),
        (function () {
          let t, n;
          (o = {}),
            Ye(e.rts) &&
              Ye(e.rts[d]) &&
              ((t = i && Je(i.getTimeThresholds) && i.getTimeThresholds()[0]),
              (n = Ye(t)
                ? Je(t.getTimeInViewForRts) && t.getTimeInViewForRts()
                : "qiv"),
              (o[n] = e.rts[d]));
        })(),
        (c = t.minunit ? 1e3 * t.minunit : 1e3),
        {
          timeInViewThresholds: i,
          qivThreshold: r,
          type: "c",
          rts: o,
          isInView: v,
          isInViewIgnoringRender: function (e) {
            return v(e, !0);
          },
          metricId: d,
          minUnit: c,
          thresholdType: t.thresholdType,
          videoPlaybackSegmentRequirements: p,
          shouldIncludeSound: l,
          sendOtherwiseInViewSignal: !0,
        }
      );
    },
    Yo = function (e, t, n) {
      "use strict";
      const i = "groupmCM",
        r = t.isVideo() ? "video" : "display",
        o = t.isMobileApp() ? "app" : "web",
        s = t.isDeviceTypeGroupMobile() ? "mobile" : "desktop",
        a =
          e.customViewability instanceof Array &&
          e.customViewability.length > 0,
        c = n.on("customMetric"),
        d = n.on(i),
        u = function (e) {
          let t;
          const n = -1 !== e.mediaTypes.indexOf(r),
            a = -1 !== e.distributionChannels.indexOf(o),
            c = !Ye(e.deviceGroups) || -1 !== e.deviceGroups.indexOf(s);
          return (
            (t = !Xi.contains(e.id, "fiv")),
            Xi.contains(e.id, i) && (t = d),
            t && n && a && c
          );
        };
      return {
        resolve: function () {
          const t = [];
          let n;
          return (
            c &&
              a &&
              ((n = e.customViewability.filter(u)),
              n.forEach(function (e) {
                t.push(e);
              })),
            t
          );
        },
      };
    },
    Jo = function (e) {
      "use strict";
      const t = 1e3,
        n = [];
      if (e.tiv instanceof Array)
        e.tiv.forEach(function (e) {
          n.push(new Ko(e));
        });
      else if ("string" == typeof e.tiv) {
        const i = e.tiv.split("|");
        if (2 === i.length) {
          const e = new Qo();
          n.push(new Zo(e, parseInt(i[1].replace("%")))),
            n.push(new Ko(parseInt(i[0]) * t));
        } else n.push(new Ko(parseInt(e.tiv) * t));
      } else Ye(e.tiv) && n.push(new Ko(e.tiv * t));
      return {
        getTimeThresholds: function () {
          return n;
        },
      };
    },
    Qo = function () {
      "use strict";
      let e =
        at.getAggregator().request("omidAdSessionContext").adDuration || -1;
      const t = function (t) {
          if (n()) return;
          const i = Ye(t.ad_duration) ? t.ad_duration : t.adRemainingTime;
          (function (e) {
            return void 0 !== e && e > 0;
          })(i) && (e = Math.ceil(i));
        },
        n = function () {
          return e > 0;
        };
      return (
        at
          .getAggregator()
          .on({ omidAdDuration: t, adVideoStart: t, adDurationChange: t }),
        {
          getAdDuration: function () {
            return e;
          },
          isVideoDurationResolved: n,
        }
      );
    },
    Ko = function (e) {
      "use strict";
      let t,
        n = 0;
      return (
        e > 0 && (n = e / 1e3),
        (t = 1e3 * n),
        {
          getTimeInViewInSeconds: function () {
            return n;
          },
          getTimeInViewForRts: function () {
            return t;
          },
        }
      );
    },
    Zo = function (e, t) {
      "use strict";
      let n = 0,
        i = !1;
      const r = function (e) {
        (n = 0), t > 0 && e > 0 && (n = Math.ceil(e * (t / 100)));
      };
      return (
        r(15),
        {
          getTimeInViewInSeconds: function () {
            return (
              !i &&
                e.isVideoDurationResolved() &&
                ((i = !0), r(e.getAdDuration())),
              n
            );
          },
          getTimeInViewForRts: function () {
            return 0;
          },
        }
      );
    },
    es = function (e, t, n, i) {
      "use strict";
      const r = i ? "isInViewIgnoringRender" : "isInView",
        o = function (i) {
          e[r](i) ? (t.mark(), n.doEligibleJobs(t.getTotalTime())) : t.stop();
        };
      return {
        start: function () {
          e.addMeasurementChangedListener(o);
        },
      };
    },
    ts = function (e, t, n, i) {
      "use strict";
      let r, o, s, a, c, d;
      const u = function (e, t) {
          return !t && e;
        },
        l = function (e, t, n, i) {
          let r = !1;
          return (r = !!i || (!t && (e || i) && n)), r;
        },
        g = function (e) {
          let u = 0;
          const g = 1 === e.tabHidden,
            p = e.isVideoPlaying,
            h = e.isSoundOn,
            f = e.isVideoPlayingInFullscreen;
          e.sliceStatus.forEach(function (e, t) {
            s(e, g, p, f) ? r[t].mark() : r[t].stop(),
              (a[t] = r[t].getTotalTime());
          }),
            m("slcVt", a),
            i &&
              (e.sliceStatus.forEach(function (e, t) {
                !(function (e, t, n, i, r) {
                  return l(e, t, n, i) && r;
                })(e, g, p, f, h)
                  ? o[t].stop()
                  : o[t].mark(),
                  (c[t] = o[t].getTotalTime());
              }),
              m("slcVtVol", c)),
            (d = i && t && t.shouldIncludeSound ? c : a);
          void 0 ===
            d.find(function (e) {
              return (u = Math.max(u, e)), e <= 0;
            }) && n.doEligibleJobs(u);
        },
        m = function (e, t) {
          const n = {};
          (n[e] = t),
            at
              .getAggregator()
              .trigger("addOutputItem", { output: n }, { minDt: !1 });
        },
        p = function (e) {
          void 0 !== e.sliceStatus &&
            (r ||
              (function (e) {
                !r &&
                  e.sliceStatus &&
                  ((r = []),
                  (o = []),
                  (a = []),
                  (c = []),
                  e.sliceStatus.forEach(function () {
                    r.push(new Cn(1)),
                      a.push(0),
                      i && (o.push(new Cn(1)), c.push(0));
                  }));
              })(e),
            g(e));
        };
      return {
        start: function () {
          (s = i ? l : u), e.addMeasurementChangedListener(p);
        },
      };
    },
    ns = function (e, t, n) {
      "use strict";
      return {
        isInView: e.isInView,
        isInViewIgnoringRender: e.isInViewIgnoringRender,
        addMeasurementChangedListener: function (e) {
          t.addMeasurementChangedListener(e, n);
        },
      };
    },
    is = function (e, t, n, i, r, o, s, a, c, d) {
      "use strict";
      const u = "measurementChanged";
      let l = !1;
      const g = Xn.isVideo(),
        m = o.request("mobileApp"),
        p = Bt().applies(n, r),
        h = n.browserIs("g") || p,
        f = Xn.xDomainIframe && !h,
        v = new In(10),
        y = function () {
          r.on("viewabilityready") &&
            !l &&
            (i.send("v"), o.trigger("measurable"), (l = !0));
        };
      o.on("delayedViewabilityReady", function () {
        b(), y();
      }),
        o.on("delayedViewabilityReadyCallOnly", y);
      const b = function (n) {
        n = n || !1;
        try {
          let i;
          v.start(),
            t.hasMeasurementStrategy()
              ? (i =
                  (m.isMobileAppEnvironment() || Xn.isOmidNative()) &&
                  t.supportsAdContainerGeometry()
                    ? t.getScreenLocationInfo({}, n)
                    : t.getScreenLocationInfo(a.collect(), n))
              : ((i = a.collect()),
                m.isMobileAppEnvironment()
                  ? ((i.viewState = "na"),
                    (i.method = "na"),
                    (i.percentInView = "na"))
                  : f && ((i.viewState = "na"), (i.percentInView = -1)),
                g && d.setVideoSpecificScreenEventFields(i));
          const r = c.registerLocation(i);
          n || e.trigger(u, i), v.stop();
          const o = _i.round(v.getTime() / v.getCount());
          return s.addItem({ output: o }, "lt", { type: "u" }), r;
        } catch (e) {
          o.trigger("error", "V");
        }
      };
      return {
        checkScreenLoc: b,
        stringifyPingTimes: function () {
          let e;
          return (
            (e = r.on("everySecond")
              ? "1-2-3-4-5-6-7-8-9-10-11-12-13-14-15"
              : g
              ? "2-5-15"
              : "1-5-15"),
            e
          );
        },
        isImmediatelyMeasurable: function () {
          const e = Xn.xDomainIframe,
            i = e && n.browserIs("w"),
            r = e && n.browserIs("e");
          let o = !i && !r && !(e && p);
          return (
            Xn.isOmid() && (o = !0),
            m.isMobileAppEnvironment() ? t.isMeasurable() : o
          );
        },
        requiresDelayedViewabilityEvent: function () {
          m.isMobileAppEnvironment() &&
            t.hasMeasurementStrategy() &&
            t.requiresDelayedViewabilityEvent();
        },
        addMeasurementChangedListener: function (t) {
          e.on(u, t);
        },
      };
    },
    rs = {
      name: "viewabilityLoopLifecycle",
      dependencies: ["viewability", "features", "context", "browser"],
      creator: function (n, i, r, o) {
        "use strict";
        let s;
        const a = os(r),
          c = [new as(), new ss(a)],
          d = function (e) {
            "sessionFinish" === e.type &&
              (at
                .getAggregator()
                .trigger("addOutputItem", { output: Xn.getTagTime() }, "osef"),
              at.getAggregator().trigger("adSessionComplete"));
          },
          u = function () {
            let e;
            const t = at
              .getAggregator()
              .request("mobileApp")
              .isMobileAppEnvironment();
            if (at.getAggregator().request("ids").impressionIsIdentifiable()) {
              if (
                ((s = Tn(function () {
                  var e;
                  try {
                    null === (e = oe.mraidLifecycleTracker) ||
                      void 0 === e ||
                      e.refreshPending();
                  } catch (e) {}
                  n.checkScreenLoc();
                }, a.getPollingFrequency())),
                (e = c.find(function (e) {
                  return e.applies(o, i, r) ? e : void 0;
                })),
                e ? e.start(s) : s.start(!0),
                Xn.isOmid())
              ) {
                at.getAggregator()
                  .request("omidVerificationClient")
                  .registerSessionObserver(d, "IAS");
              } else
                t
                  ? l("MOBILE_APP_TEST_EVENT_AD_SESSION_COMPLETE")
                  : (l("beforeunload"), g("pagehide"));
            }
          },
          l = function (e) {
            Jn.addEvent(
              t,
              e,
              function () {
                at.getAggregator().trigger("adSessionComplete");
              },
              !1
            );
          },
          g = function (e) {
            Jn.addEvent(
              t,
              e,
              function () {
                at.getAggregator().trigger("altAdSessionComplete"),
                  at.getAggregator().trigger("adSessionComplete");
              },
              !1
            );
          },
          m = function () {
            try {
              const e = oe.mraidLifecycleTracker;
              Fe(null == e ? void 0 : e.getSnapshot()),
                null == e || e.destroy();
            } catch (e) {}
            r.isVideo() && !r.isOmid() && p(),
              at.getAggregator().trigger("unload"),
              s && s.stop(),
              at.getAggregator().trigger("endAdSession"),
              at.getAggregator().trigger("stopAdTalk");
          },
          p = function () {
            const t = new Qn("m");
            at.getAggregator().trigger(
              "sendDt",
              t.callType,
              t.enumerator,
              function () {
                const t = {
                  id: e.videoId,
                  msg: "unloadComplete",
                  messageType: "misc",
                };
                _i.getWindow().postMessage(JSON.stringify(t), "*");
              }
            );
          };
        at.getAggregator().once("startViewabilityLoop", u),
          at.getAggregator().once("adSessionComplete", m);
      },
      settings: { tier: 7 },
    },
    os = function (e) {
      "use strict";
      return {
        getPollingFrequency: function () {
          return e.isVideo() ? 200 : 100;
        },
        getOptimizedPollingFrequency: function () {
          return 1e3;
        },
      };
    },
    ss = function (e) {
      "use strict";
      const t = !0;
      let n, i, r, o, s;
      const a = function (c) {
          if (r && !s && c < 1)
            return (
              (s = !0),
              void _i.setTimeout(function () {
                a(c);
              }, 1e3)
            );
          (o = c < 1),
            !i && o
              ? ((i = !0),
                n.updateFrequency(e.getOptimizedPollingFrequency(), t))
              : i &&
                !o &&
                ((i = !1), n.updateFrequency(e.getPollingFrequency(), t));
        },
        c = function (e) {
          a(e.percentInView);
        };
      return {
        applies: function (e, t, n) {
          const i = t.on("viewabilityOptimization");
          return (r = n.usesZeroPivCustomMetric()), i;
        },
        start: function (e) {
          (n = e),
            n.start(t),
            at.getAggregator().on("IOPivChange", a),
            at.getAggregator().on("newScreenEvent", c);
        },
      };
    },
    as = function () {
      "use strict";
      const e = !0;
      let t,
        n,
        i,
        r = !1;
      const o = function (s) {
          return i && !r && s < 1
            ? ((r = !0),
              void _i.setTimeout(function () {
                o(s);
              }, 1e3))
            : (s < 1 ? (t || n.stop(e), (t = !0)) : t && ((t = !1), n.start(e)),
              t);
        },
        s = function () {
          n.start(e);
        };
      return {
        applies: function (e, t, n) {
          i = n.usesZeroPivCustomMetric();
          const r = Bt();
          return (
            t.on("viewabilityOptimization") &&
            r.applies(e, t, n) &&
            n.isDeviceTypeGroupMobile()
          );
        },
        start: function (t) {
          (n = t),
            n.start(e),
            at.getAggregator().on("IOPivChange", o),
            at.getAggregator().on("nodesAdded", s);
        },
      };
    },
    cs = function (i, r, o, s, a, c, d) {
      "use strict";
      let u, l, g, m, p, h, f, v, y;
      const b = oi.getElementsWindow(r),
        w =
          (at.getAggregator().provide("iframeCalculatorHelper", Rs(b)),
          Ps(r, s)),
        A = "data-integralas-id-" + (oe.adTag && oe.adTag.asid);
      let I = !1;
      const S = ei({}),
        T = Xn.isDeviceTypeGroupMobile(),
        C = Xn.usesGroupMCustomMetricMobilePassThru();
      let O;
      const E = function () {
          if (!u) {
            u = w.calcDims(r, s, g);
            const t = e.autotagSizeSet && e.adWidth > 1 && e.adHeight > 1,
              n = oe && oe.adTag && oe.adTag.staticTagParams,
              i = n && n.w > 1 && n.h > 1;
            t && (u.set("width", e.adWidth), u.set("height", e.adHeight)),
              i && (u.set("width", n.w), u.set("height", n.h)),
              D() ? M(u) : "s" === o && u.treatAsPlaceholder();
          }
          return u;
        },
        D = function () {
          return "v" === o && Xn.embedded;
        },
        M = function (e) {
          const t = new ei(r).getRounded();
          try {
            e.set("width", t.width), e.set("height", t.height);
          } catch (e) {
            at.getAggregator().trigger("error", "F");
          }
        },
        x = function () {
          return !1;
        },
        P = function () {
          let e;
          const n = k(),
            r = w.getClippedDims && (D() || Xn.isCeltra());
          return (
            n
              ? (l = g.getPiv())
              : void 0 === l &&
                ((e =
                  !T &&
                  (Xn.friendly || Ye(t.mozInnerScreenX)) &&
                  a.on("offscreen")),
                (v = E()),
                (f = new ei(oi.calcWinDims())),
                (h = new ei(e ? oi.calcMonDims() : {})),
                (y = r ? w.getClippedDims() : S),
                (l = i.calcPercentInView(v, f, h, y))),
            l
          );
        },
        V = function () {
          return i.calcInitialViewState(P());
        },
        N = function () {
          return r !== t && E().isHidden();
        },
        k = function () {
          const e = !!g,
            t = Xn.xDomainIframe && I,
            n = T && I && g.isReady(),
            i = Xn.isPageOnShadowDomWhitelist();
          return e && (i || t || n);
        };
      return (
        (function () {
          const e = _i.getWindow(),
            t = _i.getDoc(),
            n = r === e,
            s = t.body,
            a = at.getAggregator(),
            c = new Bt(),
            u = a.request("browser"),
            l = a.request("features"),
            h = a.request("context"),
            f = !Xn.xDomainIframe,
            v = n && s ? t.body : r;
          if (
            ((O = Xn.friendlyIframe && !d ? e.frameElement : v),
            Jn.addEvent(v, "pointerdown", function (e) {
              at.getAggregator().trigger("adComponentPointerDown", e);
            }),
            Jn.addEvent(v, "pointerup", function (e) {
              at.getAggregator().trigger("adComponentPointerUp", e);
            }),
            Jn.addEvent(v, "click", function (e) {
              at.getAggregator().trigger("adComponentClicked", e);
            }),
            Jn.addEvent(window, "blur", function (e) {
              at.getAggregator().trigger("blur", e);
            }),
            Jn.addEvent(v, "touchstart", function (e) {
              at.getAggregator().trigger("adComponentTouchStart", e);
            }),
            Jn.addEvent(v, "touchend", function (e) {
              at.getAggregator().trigger("adComponentTouchEnd", e);
            }),
            Jn.addEvent(v, "mouseover", function (e) {
              at.getAggregator().trigger("adComponentMousedOver", e);
            }),
            Jn.addEvent(v, "mouseout", function (e) {
              at.getAggregator().trigger("adComponentMousedOut", e);
            }),
            c.applies(u, l, h))
          ) {
            if (((g = Vr(r, f)), g.start(), (I = !0), C && "s" !== o)) {
              const e = new Ys(E().getRounded()),
                t = new ta(),
                n = new na(g.getObservedNode(), t);
              m = new Ks(e.getSlices(), n);
            }
          } else C && (p = new Zs(i));
        })(),
        {
          mark: function () {
            oi.setAttributeOf(O, A, "");
          },
          cleanup: function () {
            oi.removeAttributeOf(O, A);
          },
          isNode: function (e) {
            return r === e;
          },
          isHidden: N,
          isObstructed: x,
          getDims: E,
          getPercentInView: P,
          getLocationState: V,
          getOnPageViewability: function () {
            return N() ? "outOfView" : V();
          },
          getDetectionMethod: function () {
            return o;
          },
          getContainerDims: function () {
            return w.allowsOptimization ? u : ei(s);
          },
          refresh: function () {
            (u = void 0),
              (l = void 0),
              (h = void 0),
              (f = void 0),
              (v = void 0),
              (y = void 0),
              c &&
                (function () {
                  let e, i;
                  if (!Xn.isDomless() && ((i = r.parentNode), i)) {
                    for (; r !== t && i && i !== n && !e; )
                      (e = i === s), (i = i.parentNode);
                    e || (s = r.parentNode);
                  }
                })();
          },
          getAdNode: function () {
            return r;
          },
          getSliceStatus: function () {
            let e;
            return (
              m && m.isReadyToMeasure()
                ? (e = m.getSliceStatus())
                : Xn.friendly &&
                  p &&
                  Ye(v) &&
                  (e = p.getSliceStatus(v, f, h, y)),
              e
            );
          },
        }
      );
    },
    ds = function (e, t) {
      "use strict";
      let n,
        i = [];
      const r = function () {
          return i[0] && "s" === i[0].getDetectionMethod();
        },
        o = function (o, s, a, c, d) {
          const u = r() || 0 === i.length,
            l = cs(e, o, s, a, t, c, d);
          !(function () {
            let e;
            r() && ((e = i.shift()), e.cleanup(), (n = void 0));
          })(),
            i.push(l),
            u && l.mark(),
            u && "s" !== s && at.getAggregator().trigger("primaryadfound", l);
        },
        s = function () {
          if (n) return n;
          let e,
            t = !1,
            r = 0,
            o = 0;
          return (
            i.forEach(function (n) {
              let i;
              const s = n.getDims();
              s.hasValidDims() &&
                ((e = n.getPercentInView()),
                (t = "na" !== e),
                (i = s.area()),
                (r += i),
                (o += (e / 100) * i));
            }),
            (n = { totalArea: r, totalInView: o, hasMeasurement: t }),
            n
          );
        },
        a = function (e) {
          const t = at.getAggregator().request("adRenderStatus");
          return !e && !t;
        },
        c = function (e) {
          let t;
          const n = s();
          return (
            (t = n.hasMeasurement
              ? _i.round((n.totalInView / n.totalArea) * 100)
              : -1),
            (isNaN(t) || a(e)) && (t = 0),
            t
          );
        },
        d = function (n) {
          const i = t.bootstrapOn("mobOrTab"),
            r =
              s().totalArea >= 242500 && t.on("largeAd") && !i && !Xn.isVideo();
          return e.calcInitialViewState(c(n), r);
        },
        u = function (e) {
          let t = -1;
          return (
            i.forEach(function (n, i) {
              n.isNode(e) && (t = i);
            }),
            t
          );
        },
        l = function (e) {
          return function () {
            return i[0] && i[0][e]();
          };
        },
        g = function (e) {
          Array.prototype.forEach.call(e, function (e) {
            const t = -1 === u(e),
              n =
                "object" == typeof e &&
                "IMG" === e.nodeName &&
                1 === e.height &&
                1 === e.width;
            t && !n && o(e, "c");
          });
        };
      return (
        at.getAggregator().on("adComponentAdded", g),
        at.getAggregator().on("adComponentRemoved", function (e) {
          Array.prototype.forEach.call(e, function (e) {
            const t = u(e);
            t > -1 && i.splice(t, 1);
          });
        }),
        {
          addNodeToAdComponents: g,
          getDims: l("getDims"),
          isObstructed: l("isObstructed"),
          getDetectionMethod: l("getDetectionMethod"),
          getContainerDims: l("getContainerDims"),
          getViewState: d,
          getViewStateIgnoringRender: function () {
            return d(!0);
          },
          getPercentInView: c,
          getPercentInViewIgnoringRender: function () {
            return c(!0);
          },
          isHidden: l("isHidden"),
          isUsingPlaceholder: r,
          hasAd: function () {
            return !!i.length;
          },
          refresh: function () {
            (n = void 0),
              i.forEach(function (e) {
                e.refresh();
              });
          },
          addAdComponent: o,
          clearCollection: function () {
            i.forEach(function (e) {
              e.cleanup();
            }),
              (i = []),
              (n = void 0);
          },
          getOutOfViewReasons: function (e) {
            let t;
            const r = [],
              o = i[0];
            return (
              o &&
                ((t = n || d()),
                a(e)
                  ? r.push("r")
                  : ("outOfView" !== t && "partialViewMinus" !== t) ||
                    r.push("l"),
                o.isHidden() && r.push("h"),
                o.isObstructed() && r.push("o")),
              r
            );
          },
          getComponentCount: function () {
            return i.length;
          },
          getComponents: function () {
            return i;
          },
          getSliceStatus: l("getSliceStatus"),
        }
      );
    },
    us = function () {
      "use strict";
      let e, t, n;
      const i = function (e) {
        e
          ? e &&
            n &&
            (_i.execAtEndOfThread(function () {
              at.getAggregator().trigger("delayedViewabilityReadyCallOnly");
            }),
            (n = !1))
          : (n = !0);
      };
      return {
        detectionMethod: function () {
          return t && t.detectionMethod;
        },
        isApplicable: function (e) {
          return e.isBustedIframe();
        },
        find: function () {
          t = t || ys();
          const n = ys(),
            r = oi.crossQuerySelector(n.getCssSelector(), !0);
          return (e = r ? r.parentNode : e), i(r), r;
        },
        getAdContainer: function () {
          return e;
        },
        allowForAdContainerChange: !0,
        noIframeAdNode: function () {
          return t && t.noIframeAdNode;
        },
      };
    },
    ls = function (t, n) {
      "use strict";
      let i;
      const r = t || e.contextNode.parentNode,
        o = oi.findChildWithLargestContent(r, n);
      return oi.getNodeArea(o) > 1 && !o.iasdetector && (i = o), i;
    },
    gs = function () {
      "use strict";
      const e = at.getAggregator().request("omidAdSessionContext");
      return {
        usePlaceholder: !0,
        detectionMethod: "o1",
        isApplicable: function () {
          return Xn.isOmidForWeb() && !Xn.isOmidNative();
        },
        find: function () {
          return (
            e.element || e.queuedOutputItems.push({ code: "oea", value: !0 }),
            e.element
          );
        },
        getAdContainer: function () {
          return e.element && e.element.parentNode;
        },
        allowForAdContainerChange: !0,
      };
    },
    ms = function () {
      "use strict";
      return {
        detectionMethod: "i",
        find: function () {
          return t;
        },
        isApplicable: function () {
          return Xn.embedded;
        },
        getAdContainer: function () {
          return e.contextNode.parentNode;
        },
        allowForAdContainerChange: !0,
      };
    },
    ps = function () {
      "use strict";
      let e;
      const t = _i.getDoc().scripts,
        n = function () {
          return (
            e ||
              (e = Array.prototype.find.call(t, function (e) {
                return Xi.contains(e.src, "servedby.flashtalking");
              })),
            e
          );
        };
      return {
        detectionMethod: "bf",
        isApplicable: function (e, t) {
          return t.on("bustediframe") && e.embedded && void 0 !== n();
        },
        getCssSelector: function () {
          let t;
          const i = (function () {
              let t;
              const i = e || n(),
                r = /;(\d+);/;
              return i && i.src && (t = i.src.match(r)[1]), t;
            })(),
            r = "#ftdiv" + i,
            o = "#ftframe" + i;
          try {
            t = [r, o].find(function (e) {
              return !!oi.crossQuerySelector(e, true);
            });
          } catch (e) {}
          return t;
        },
      };
    },
    hs = function () {
      "use strict";
      const e = "_tpi";
      return {
        isApplicable: function (t, n) {
          let i;
          try {
            i = oi.getFrameId();
          } catch (e) {}
          return (
            n.on("yieldmo") &&
            i &&
            Xi.contains(i, e) &&
            oi.crossQuerySelector("[data-href*='ads.yieldmo.com']", !0)
          );
        },
        getCssSelector: function () {
          return "[id='" + oi.getFrameId().replace(e, "") + "']";
        },
        detectionMethod: "by",
      };
    },
    fs = function () {
      "use strict";
      let e, t;
      const n = _i.getDoc(),
        i = function () {
          let t, i;
          const r = "ebDiv";
          return (
            e ||
              ((t = oi.querySelector(n, "div[id*='ebDiv']")),
              (i = t && t.id),
              (e = i && i.split(r)[1])),
            e
          );
        },
        r = function () {
          const e = oi.crossQuerySelector(
            "iframe[id*='ebAd'][id$='" + i() + "']",
            !0
          );
          return e && e.id;
        },
        o = function () {
          let e;
          return (
            t ||
              ((e = r()
                ? r()
                : (function () {
                    const e = oi.crossQuerySelector(
                      "iframe[id*='ebBannerIFrame_'][id$='" + i() + "']",
                      !0
                    );
                    return e && e.id;
                  })()),
              (t = e && "#" + e)),
            t
          );
        };
      return {
        detectionMethod: "bs",
        isApplicable: function (e, t) {
          const n = _i.getWindow(),
            r = e.friendlyIframe && _i.getWindow().frameElement,
            s = r && ei(r).isOneByOne(),
            a = (function () {
              const e = [
                  "bs.serving-sys.com/BurstingPipe/adServer",
                  "secure-ds.serving-sys.com/BurstingCachedScripts",
                ],
                t = _i.getDoc().scripts;
              return Array.prototype.find.call(t, function (t) {
                return !!e.find(function (e) {
                  return Xi.contains(t.src, e);
                });
              });
            })(),
            c = n.EBG && n.EBG.ads && Object.keys(n.EBG.ads).length > 0;
          return t.on("sizmek") && a && c && s && i() && o();
        },
        getCssSelector: o,
      };
    },
    vs = function () {
      "use strict";
      let e;
      const t = () => {
        const e = _i.getWindow(),
          t = e.IAS_OGURY_CONFIG && e.IAS_OGURY_CONFIG.REVEAL_DIV_ID;
        return t ? "[id='" + t + "']" : "";
      };
      return {
        isApplicable: () => !!t(),
        getCssSelector: t,
        detectionMethod: "bo",
        find: () => {
          const t = _i.getWindow(),
            n = t.IAS_OGURY_CONFIG && t.IAS_OGURY_CONFIG.REVEAL_DIV_ID;
          let i;
          if (n)
            try {
              const t = _i.getTop();
              if (t && t.document) {
                const r = t.document.getElementById(n);
                (e = r || void 0), (i = e);
              }
            } catch (e) {}
          return i;
        },
        getAdContainer: () => e,
        allowForAdContainerChange: !1,
        noIframeAdNode: !0,
      };
    },
    ys = function () {
      "use strict";
      let e;
      const t = at.getAggregator().request("features");
      return (
        e || (e = [fs(), hs(), vs(), ps()]),
        e.find(function (e) {
          return e.isApplicable(Xn, t);
        })
      );
    },
    bs = function () {
      const t = e && e.contextNode,
        n = t && t.getAttribute && t.getAttribute("data-ias-container");
      if (!n || 0 !== n.indexOf("gcc_")) return;
      const i = oi.crossQuerySelector("#" + n);
      return i && oi.getNodeArea(i) < 1 ? i : void 0;
    },
    ws = function () {
      const e = bs();
      return (
        e &&
        e.ownerDocument &&
        (oi.querySelector(e.ownerDocument, ".celtra-banner") || void 0)
      );
    },
    As = function () {
      const e = ws();
      return e && oi.getNodeArea(e) >= 1 ? e : void 0;
    },
    Is = function () {
      const e = bs();
      return !(!e || !oi.querySelector(e, ".celtra-ad-v3, .celtra-ad-v4"));
    },
    Ss = function () {
      "use strict";
      let e, t, n;
      const i = function () {
          t && (t.disconnect(), (t = void 0)),
            n && (n.disconnect(), (n = void 0));
        },
        r = function () {
          i(), at.getAggregator().trigger("celtraCreativeReady");
        },
        o = function () {
          _i.execAtEndOfThread(function () {
            at.getAggregator().trigger("delayedViewabilityReadyCallOnly");
          });
        };
      return {
        get usePlaceholder() {
          return Is();
        },
        detectionMethod: "vc",
        isApplicable: function (e, t) {
          return Is() || (t.on("celtra") && e.isCeltra());
        },
        find: function () {
          let s;
          const a = Ts().find();
          return (
            a &&
              a.celtra &&
              a.celtra.loaded &&
              (s = a.celtra.viewabilityObservee),
            !s && Is() && (s = As()),
            s
              ? (i(),
                (e = oi.getElementsWindow(s).frameElement || s.parentNode),
                o())
              : (function () {
                  if (t || !Is()) return;
                  const e = function () {
                    const e = ws();
                    if (e && !n)
                      try {
                        (n = _i.getResizeObserver(function () {
                          As() && r();
                        })),
                          n.observe(e);
                      } catch (e) {
                        n = void 0;
                      }
                  };
                  try {
                    const n = bs(),
                      i = n && n.ownerDocument && n.ownerDocument.body;
                    if (!i) return;
                    (t = _i.getMutationObserver(function () {
                      As() ? r() : e();
                    })),
                      t.observe(i, {
                        childList: !0,
                        subtree: !0,
                        attributes: !0,
                      }),
                      As() ? r() : e();
                  } catch (e) {
                    i();
                  }
                })(),
            s
          );
        },
        getAdContainer: function () {
          return e;
        },
        allowForAdContainerChange: !1,
      };
    },
    Ts = function () {
      "use strict";
      let t;
      const n = "celtra-ad-v3",
        i = "celtra-ad-v4",
        r = function () {
          let r;
          const o = e.contextNode.parentNode;
          return (
            o && (Xi.contains(o.className, n) || Xi.contains(o.className, i))
              ? (t = o)
              : ((r =
                  o &&
                  (oi.querySelector(o, ".celtra-ad-v3") ||
                    oi.querySelector(o, ".celtra-ad-v4"))),
                r && (t = r)),
            t
          );
        };
      return {
        find: r,
        isApplicable: function () {
          return void 0 !== r();
        },
      };
    },
    Cs = function () {
      "use strict";
      return {
        usePlaceholder: !0,
        detectionMethod: "a",
        isApplicable: at.getAggregator().request("mobileApp")
          .isMobileAppEnvironment,
        find: function () {
          return (function () {
            const e = oi.findChildWithLargestContent(_i.getDoc().body);
            return e && e.hasValidSizeForMobileApp && !e.iasdetector
              ? e
              : void 0;
          })();
        },
        getAdContainer: function () {
          return e.contextNode.parentNode;
        },
        allowForAdContainerChange: !0,
      };
    };
  const Os = new (class {
      constructor() {
        this.cachedIsFoundOnPage = !1;
      }
      getDocument() {
        let e;
        try {
          e = _i.getDoc();
        } catch (e) {}
        return e;
      }
      hasBrowserSupport() {
        let e = !1;
        const t = this.getDocument(),
          n = !Xn.isDomless(),
          i = !(!t || "function" != typeof t.body.attachShadow);
        return n && i && (e = !0), e;
      }
      isFoundOnPage(e) {
        const t = _i.getDoc(),
          n = e || t.body;
        let i = !1;
        if (this.cachedIsFoundOnPage) i = !0;
        else if (this.hasBrowserSupport())
          if (n.shadowRoot) (i = !0), (this.cachedIsFoundOnPage = !0);
          else {
            const e = n.querySelectorAll("*");
            for (let t = 0; t < e.length; t++) {
              const n = e[t];
              if (n && n.shadowRoot) {
                (i = !0), (this.cachedIsFoundOnPage = !0);
                break;
              }
            }
          }
        else i = !1;
        return i;
      }
      findElement({ root: e, selector: t }) {
        var n;
        if (
          "matches" in e &&
          (null === (n = e.matches) || void 0 === n ? void 0 : n.call(e, t)) &&
          e.matches(t)
        )
          return e;
        if ("shadowRoot" in e && e.shadowRoot) {
          const n = this.findElement({ root: e.shadowRoot, selector: t });
          if (n) return n;
        }
        for (const n of Array.from(e.children)) {
          const e = this.findElement({ root: n, selector: t });
          if (e) return e;
        }
        return null;
      }
      querySelector({ customRootElement: e, selector: t }) {
        const n = _i.getDoc(),
          i = e || n.body;
        return this.findElement({ root: i, selector: t });
      }
    })(),
    Es = function () {
      "use strict";
      let t,
        n = !1;
      const i = function (e) {
          const t =
            Je(e.contextNode.getAttribute) &&
            e.contextNode.getAttribute("data-ias-container");
          return (t && "#" + t) || e._cl_adpath;
        },
        r = function () {
          const t = at.getAggregator().request("features"),
            n = e && 4 === e.integration;
          return !t.on("forceKeepGoogleAdNode") || !n;
        },
        o = function () {
          const t = at.getAggregator().request("features");
          if (!t || !t.on("celtra") || !Xn.isCeltra()) return;
          const n = oi.crossQuerySelector(i(e));
          if (n && oi.getNodeArea(n) >= 1) return;
          const r = Ts().find(),
            o =
              r && r.celtra && r.celtra.loaded && r.celtra.viewabilityObservee;
          if (o && oi.getNodeArea(o) >= 1) return o;
          const s =
            n &&
            n.ownerDocument &&
            oi.querySelector(n.ownerDocument, ".celtra-banner");
          return s && oi.getNodeArea(s) >= 1 ? s : void 0;
        };
      return {
        getAdSelectorId: i,
        detectionMethod: "sp",
        isApplicable: function () {
          const e = Is();
          return Xn.isSpecifiedAd() && !e;
        },
        find: function () {
          const s = i(e);
          let a = oi.crossQuerySelector(s);
          const c = Xn.isPageOnShadowDomWhitelist(),
            d = (function (e) {
              return r() && oi.getNodeArea(e) < 1;
            })(a),
            u = o();
          return u
            ? ((n = !0),
              (t = oi.getElementsWindow(u).frameElement || oi.getParent(u)),
              u)
            : ((n = !1),
              a
                ? ((t = oi.getParent(a)),
                  d && ((t = a), (a = oi.findElementsWithSize(a))))
                : c &&
                  Os.isFoundOnPage() &&
                  ((a = Os.querySelector({ selector: s })),
                  (t = oi.getParent(a))),
              a);
        },
        getAdContainer: function () {
          return t;
        },
        get allowForAdContainerChange() {
          return !n;
        },
        shouldValidateAdNode: r,
      };
    },
    Ds = function () {
      "use strict";
      let t;
      return {
        detectionMethod: "spc",
        isApplicable: function () {
          return Xn.isCompoundAd();
        },
        find: function () {
          const n = [];
          var i;
          let r;
          return (
            ((i = e._cl_adpath), /\[(.*)\]/.exec(i)[1].split(",")).forEach(
              function (e) {
                (r = oi.crossQuerySelector(e)),
                  r &&
                    ((t = oi.getParent(r)),
                    oi.getNodeArea(r) < 1 &&
                      ((t = r), (r = oi.findElementsWithSize(r)))),
                  n.push(r);
              }
            ),
            n
          );
        },
        getAdContainer: function () {
          return t;
        },
        allowForAdContainerChange: !0,
      };
    },
    Ms = function () {
      "use strict";
      return {
        usePlaceholder: !0,
        detectionMethod: "a",
        isApplicable: function () {
          return !0;
        },
        find: ls,
        getAdContainer: function () {
          return e.contextNode.parentNode;
        },
        allowForAdContainerChange: !0,
      };
    },
    xs = function () {
      "use strict";
      return {
        detectionMethod: "v",
        find: at.getAggregator().request("video").findAdNode,
        isApplicable: Xn.isVideo,
        getAdContainer: function () {
          return e.contextNode.parentNode;
        },
        allowForAdContainerChange: !0,
      };
    },
    Ps = function (e, t) {
      "use strict";
      let n;
      n = [ks(), Ns(), Vs()].find(function (n) {
        return n.isApplicable(e, t);
      });
      const i = Fs();
      return i.isApplicable(t) && (i.setBaseStrategy(n), (n = i)), n;
    },
    Vs = function () {
      "use strict";
      return {
        calcDims: function (e, t) {
          let n, i;
          const r = new ei(e);
          return (
            oi.isClippable(e, t) &&
              ((n = oi.getClippedDimensions(e, t)),
              (i = r.getRounded()),
              r.set("height", n.height < i.height ? n.height : i.height || 1),
              r.set("width", n.width < i.width ? n.width : i.width || 1)),
            r
          );
        },
        allowsOptimization: !1,
        isApplicable: function (e) {
          const t =
              (Xn.isSpecifiedAd() || Xn.isBustedIframe()) &&
              oi.nodeIsInWindow(e, _i.getTop()),
            n = !oi.elementIsEmbedded(e);
          return t || n;
        },
      };
    },
    Ns = function () {
      "use strict";
      const e = at.getAggregator().request("iframeCalculatorHelper");
      return {
        calcDims: e.calcDims,
        getClippedDims: e.getClippedDims,
        allowsOptimization: !0,
        isApplicable: function (e) {
          return (
            !(Xn.isSpecifiedAd() || Xn.isBustedIframe()) &&
            oi.elementIsEmbedded(e)
          );
        },
      };
    },
    ks = function () {
      "use strict";
      const e = at.getAggregator().request("iframeCalculatorHelper");
      return {
        calcDims: function (t) {
          const n = at.getAggregator().request("features"),
            i = e.calcDims(),
            r = new ei(t).getRounded(),
            o =
              Is() || (n && n.on("celtra") && Xn.isCeltra())
                ? (function (e) {
                    try {
                      const t = oi.getElementsWindow(e).frameElement;
                      if (!t) return 1;
                      const n = oi.getRect(t).width,
                        i = t.contentWindow && t.contentWindow.innerWidth;
                      if (!n || !i) return 1;
                      const r = n / i;
                      return r >= 0.05 && r <= 1 ? r : 1;
                    } catch (e) {
                      return 1;
                    }
                  })(t)
                : 1,
            s = 1 !== o && Ze.isNumeric(r.width) && Ze.isNumeric(r.height);
          return (
            i.set("height", s ? _i.round(r.height * o) : r.height),
            i.set("width", s ? _i.round(r.width * o) : r.width),
            i
          );
        },
        getClippedDims: e.getClippedDims,
        allowsOptimization: !1,
        isApplicable: function (e, t) {
          const n =
              (Xn.isSpecifiedAd() || Xn.isBustedIframe()) &&
              Xn.embedded &&
              !oi.nodeIsInWindow(t, _i.getTop()),
            i = (Xn.isCeltra() || Is()) && oi.elementIsEmbedded(e);
          return n || i;
        },
      };
    },
    Fs = function () {
      "use strict";
      let e;
      return {
        calcDims: function (t, n, i) {
          let r = Ye(i) ? i.getAdNodeDimensions() : void 0;
          return e && void 0 === r && (r = e.calcDims(t, n)), r;
        },
        isApplicable: function (e) {
          const t = Bt(),
            n = at.getAggregator(),
            i = n.request("browser"),
            r = n.request("features"),
            o = n.request("context"),
            s = Xn.isPageOnShadowDomWhitelist();
          return (o.isDeviceTypeGroupMobile() || s) && t.applies(i, r, o);
        },
        allowsOptimization: !1,
        setBaseStrategy: function (t) {
          e = t;
        },
      };
    },
    Rs = function (e) {
      "use strict";
      e = e || _i.getWindow();
      const t = function (n, i) {
          let r;
          (n = n || e),
            (i = i || {
              top: 0,
              left: 0,
              width: Number.MAX_VALUE,
              height: Number.MAX_VALUE,
            });
          const o = n.parent.frames;
          let s = !1;
          for (let e = 0, t = o.length; e < t; e++)
            if (o[e] == n) {
              (r = o[e]), (s = !0);
              break;
            }
          if (s) {
            const e = oi.getRect(r.frameElement);
            (i.left += e.left), (i.top += e.top);
            try {
              (i.width = _i.min(i.width, e.width)),
                (i.height = _i.min(i.height, e.height));
            } catch (e) {
              at.getAggregator().trigger("error", "a");
            }
            n !== _i.getTop() && t(n.parent, i);
          }
          return i;
        },
        n = function () {
          let n,
            i = {};
          try {
            (i = (function () {
              let n,
                i,
                r,
                o,
                s,
                a,
                c = Number.MAX_VALUE,
                d = Number.MAX_VALUE;
              return (
                Xn.friendly
                  ? ((n = t()),
                    (r = n.left),
                    (o = n.top),
                    (c = n.width),
                    (d = n.height),
                    (i = oi.browserWindowPosition()),
                    (s = i.scrX + r),
                    (a = i.scrY + o))
                  : Ye(e.mozInnerScreenX) &&
                    ((s = _i.round(e.mozInnerScreenX)),
                    (a = _i.round(e.mozInnerScreenY))),
                {
                  scrX: s,
                  scrY: a,
                  iFrameClippingWidth: c,
                  iFrameClippingHeight: d,
                }
              );
            })()),
              (n = (function () {
                let t, n;
                return (
                  Ye(e.innerWidth)
                    ? ((t = e.innerWidth), (n = e.innerHeight))
                    : e.frameElement &&
                      Ye(e.frameElement.clientWidth) &&
                      ((t = e.frameElement.clientWidth),
                      (n = e.frameElement.clientHeight)),
                  { width: t, height: n }
                );
              })()),
              (i.height = n.height),
              (i.width = n.width);
          } catch (e) {
            at.getAggregator().trigger("error", "a");
          }
          return i;
        };
      return {
        calcDims: function () {
          return new ei(n());
        },
        getClippedDims: function () {
          const e = n();
          return new ei({
            scrX: e.scrX,
            scrY: e.scrY,
            width: e.iFrameClippingWidth,
            height: e.iFrameClippingHeight,
          });
        },
      };
    },
    js = function () {
      "use strict";
      return {
        createInstance: function (e, t, n) {
          return Xn.isDomless() ? new Ls() : new _s(e, t, n);
        },
      };
    },
    _s = function (i, r, o) {
      "use strict";
      let s, a;
      const c = at.getAggregator().request("browser"),
        d =
          e && e.contextNode && e.contextNode.parentNode
            ? e.contextNode.parentNode
            : null,
        u = ds(r, o),
        l = function () {
          let e, t, n, i;
          s =
            s ||
            (function (e, t) {
              const n =
                  oe &&
                  oe.measurementConfig &&
                  oe.measurementConfig.tagDeliveryType,
                i = e.isBustedIframe() && "i" === n,
                r = [Ds(), Es()],
                o = [gs(), Cs(), xs(), us(), Ss(), ms()],
                s = r.concat(o);
              return (
                i ? s.unshift(Ms()) : s.push(Ms()),
                s.find(function (n) {
                  return n.isApplicable(e, t);
                })
              );
            })(Xn, o);
          const r = s.find();
          Xn.friendlyIframe && Xn.isBlockingSizmekTag() && f(r),
            !r && s.usePlaceholder
              ? (g(), p())
              : r &&
                ((t = r instanceof Array ? r : [r]),
                (e = s.getAdContainer()),
                (n = s.allowForAdContainerChange),
                (i = s.noIframeAdNode && s.noIframeAdNode()),
                t.forEach(function (t) {
                  u.addAdComponent(t, rt(s.detectionMethod), e, n, i);
                }));
        },
        g = function () {
          let t;
          u.hasAd() ||
            ((t = oi.getPlaceholderSpan()),
            d.insertBefore(t, e.contextNode.nextSibling),
            u.addAdComponent(t, "s", oi.getParent(t)));
        },
        m = function (e, t) {
          let n = !1;
          e.forEach(function (e) {
            e.addedNodes && e.addedNodes.length > 0 && (n = !0);
          }),
            n && (at.getAggregator().trigger("nodesAdded"), t.disconnect());
        },
        p = function () {
          if (Xn.isDeviceTypeGroupMobile() && c.hasMutationObserver()) {
            _i.getMutationObserver(m).observe(d, { childList: !0 });
          }
        },
        h = function (e, t) {
          let n,
            i = !1;
          e.forEach(function (e) {
            switch (e.type) {
              case "childList":
                Array.prototype.forEach.call(e.addedNodes, function (e) {
                  e.nodeName &&
                    "script" === e.nodeName.toLowerCase() &&
                    (i = !0);
                });
                break;
              case "attributes":
                e.target.height * e.target.width <= 1 && (i = !0);
            }
          }),
            i &&
              ((n = fs()),
              n.isApplicable(Xn, o) &&
                (t.disconnect(),
                (s = us()),
                u.clearCollection(),
                at.getAggregator().trigger("nodesAdded")),
              setTimeout(function () {
                n.isApplicable(Xn, o) &&
                  (t.disconnect(),
                  (s = us()),
                  u.clearCollection(),
                  at.getAggregator().trigger("nodesAdded"));
              }, 0));
        },
        f = function (e) {
          let t, n;
          if (!a && c.hasMutationObserver() && oi.isWindow(e))
            try {
              (a = _i.getMutationObserver(h)),
                (t = e && e.frameElement),
                (n = e && e.document && e.document.body),
                a.observe(t, {
                  attributes: !0,
                  attributeFilter: ["height", "width"],
                }),
                a.observe(n, { childList: !0, subtree: !0 });
            } catch (e) {}
        },
        v = function () {
          return u.isUsingPlaceholder() || !u.hasAd() ? l() : u.refresh(), u;
        };
      return (
        (function (e) {
          let i = !1;
          if (void 0 === t.MutationObserver) return;
          const r = new t.MutationObserver(function (e) {
              _i.execAtEndOfThread(function () {
                i &&
                  e.forEach(function (e) {
                    e.addedNodes.length &&
                      at
                        .getAggregator()
                        .trigger("adComponentAdded", e.addedNodes),
                      e.removedNodes.length &&
                        at
                          .getAggregator()
                          .trigger("adComponentRemoved", e.removedNodes);
                  });
              });
            }),
            o = function () {
              (i = !0),
                _i.setTimeout(function () {
                  i = !1;
                }, 40);
            };
          at.getAggregator().on("adComponentClicked", o),
            at.getAggregator().on("adComponentTouchEnd", o),
            at.getAggregator().on("adComponentMousedOver", o),
            at
              .getAggregator()
              .on("adComponentClicked", go.adComponent.trackClick),
            at
              .getAggregator()
              .on("adComponentMousedOver", go.adComponent.trackMouseOver),
            at
              .getAggregator()
              .on("adComponentMousedOut", go.adComponent.trackMouseOut),
            at
              .getAggregator()
              .on("adComponentTouchEnd", go.mobile.trackTouchEnd),
            at
              .getAggregator()
              .on("adComponentTouchStart", go.mobile.trackTouchStart),
            at.getAggregator().on("blur", go.adComponent.trackBlur),
            at
              .getAggregator()
              .on("adComponentPointerDown", go.mobile.trackPointerDown),
            at
              .getAggregator()
              .on("adComponentPointerUp", go.mobile.trackPointerUp),
            Jn.addEvent(t, "beforeunload", go.finalizeAllCollectedData, !1),
            Jn.addEvent(t, "pagehide", go.finalizeAllCollectedData, !1),
            Jn.whenReady(function () {
              try {
                r.observe(n.body, {
                  attributes: !0,
                  childList: !0,
                  characterData: !0,
                });
              } catch (t) {
                e.add("W");
              }
            }, _i.getDoc());
        })(i),
        at.getAggregator().on("celtraCreativeReady", v),
        { find: v, getDetectionMethod: function () {} }
      );
    },
    Ls = function () {
      "use strict";
      const e = function () {
        return null;
      };
      return { find: e, getDetectionMethod: e };
    },
    Us = function (t) {
      "use strict";
      const n = new $s(),
        i = new zs();
      let r = Nn().getUserAgent().toLowerCase();
      const o = function () {
        const e = [
          "FBAN",
          "FBAV",
          "Twitter",
          "Instagram",
          "Flipboard",
          "Snapchat",
          "LinkedInApp",
          "Pinterest",
        ];
        let t,
          n = !1;
        for (t = 0; t < e.length; t++)
          if (r.indexOf(e[t].toLowerCase()) > -1) {
            (n = !0),
              at
                .getAggregator()
                .trigger(
                  "addOutputItem",
                  { output: e[t].substring(0, 2) },
                  "xlu",
                  { type: "impression" }
                );
            break;
          }
        return n;
      };
      return (
        (function () {
          let r = "";
          const s = at.getAggregator().request("omidAdSessionContext"),
            a = Xn.isDomless() || (s && "app" === s.environment),
            c = s && "web" === s.environment,
            d = t.bootstrapOn("mobOrTab"),
            u = t.bootstrapOn("mobAppWebview"),
            l = t.bootstrapOn("app"),
            g = (d && u) || l;
          try {
            a || (!c && g && !o())
              ? ((r = n.detect()),
                n.hasDetectedMobileApp() &&
                  (("s_serv" !== r && "u_cars" !== r) ||
                    (Xs[Xs.length - 1].detectionRules.userAgent[0] = "/"),
                  i.detect(),
                  at
                    .getAggregator()
                    .trigger("addOutputItem", { output: "1" }, "mapp", {
                      type: "impression",
                    }),
                  at
                    .getAggregator()
                    .trigger("addOutputItem", { output: r }, "drul", {
                      type: "impression",
                    })))
              : c &&
                at
                  .getAggregator()
                  .trigger("addOutputItem", { output: "a_oweb" }, "drul", {
                    type: "impression",
                  });
          } catch (e) {
            at.getAggregator().trigger("error", "M");
          }
          try {
            xe() &&
              ((m = n.hasDetectedMobileApp()),
              (p = e.mapp),
              De(() => {
                const e = Ce(m),
                  t = Ce(p);
                Ee("semc", ye(e)),
                  void 0 !== e && void 0 !== t && Ee("semm", e === t ? 0 : 1);
              }));
          } catch (e) {}
          var m, p;
        })(),
        {
          excludedByUserAgent: o,
          isMobileAppEnvironment: function () {
            return n.hasDetectedMobileApp();
          },
          isSafeToInjectMraid: function () {
            return i.isSafeToInjectMraid();
          },
        }
      );
    },
    qs = {
      url: {
        STRINGIFIED_METHOD: "u",
        detect: function (i) {
          "use strict";
          var r;
          if (Xn.isDomless()) return !1;
          const o = _i.getWindow().location.href,
            s = [o];
          try {
            s.push(top.location.href);
          } catch (e) {}
          try {
            s.push(parent.location.href);
          } catch (e) {}
          if (Xn.embedded) {
            try {
              s.push(parent.document.referrer);
            } catch (e) {}
            try {
              s.push(n.referrer);
            } catch (e) {}
          }
          try {
            "jsi" !==
              (null === (r = oe.adTag) || void 0 === r ? void 0 : r.tagType) &&
              s.push(t.location.href);
          } catch (e) {}
          try {
            s.push(e.jsref);
          } catch (e) {}
          return (
            s.sort(function (e, t) {
              return e.length > t.length ? 1 : e.length < t.length ? -1 : 0;
            }),
            !!i.find(function (e) {
              let t,
                n,
                i = !1;
              const r = "mobfox" === e ? s : [o];
              for (n = 0; n < r.length; n++) {
                t = r[n];
                const o = "string" == typeof e ? [e] : e;
                if (o instanceof Array && o)
                  for (
                    let e = 0;
                    e < o.length && ((i = t.indexOf(o[e]) > -1), !1 !== i);
                    e++
                  );
                if (i) break;
              }
              return i;
            })
          );
        },
      },
      userAgent: {
        STRINGIFIED_METHOD: "a",
        detect: function (e) {
          "use strict";
          return (
            !Xn.isDomless() &&
            !!e.find(function (e) {
              let t = !1;
              const n = Nn().getUserAgent();
              return "string" == typeof e && (t = -1 !== n.indexOf(e)), t;
            })
          );
        },
      },
      javascript: {
        STRINGIFIED_METHOD: "j",
        detect: function (e) {
          "use strict";
          return !!e.find(function (e) {
            let t = !1;
            return (t = Ye(Xi.stringToProp(e))), t;
          });
        },
      },
      scriptSrc: {
        STRINGIFIED_METHOD: "s",
        detect: function (e) {
          "use strict";
          return (
            !Xn.isDomless() &&
            !!e.find(function (e) {
              return oi.containsScriptTagWithSrc(function (t) {
                let n = !1;
                return (n = Ye(t) && -1 !== t.indexOf(e)), n;
              });
            })
          );
        },
      },
    },
    Ws = function () {
      "use strict";
      return {
        process: function (e) {
          return Object.keys(e)
            .map((t) =>
              (function (e, t) {
                let n;
                const i = qs[e];
                return i.detect(t) && (n = i.STRINGIFIED_METHOD), n;
              })(t, e[t])
            )
            .join("");
        },
      };
    },
    Bs = [
      {
        STRINGIFIED_APPDET: "omid",
        detectionRules: { javascript: ["omidSupported"] },
      },
      {
        STRINGIFIED_APPDET: "file",
        detectionRules: { url: ["file:"], scriptSrc: ["file:"] },
      },
      { STRINGIFIED_APPDET: "cont", detectionRules: { url: ["content:"] } },
      {
        STRINGIFIED_APPDET: "appl",
        detectionRules: { url: ["applewebdata:"] },
      },
      {
        STRINGIFIED_APPDET: "adma",
        detectionRules: { javascript: ["ADMARVEL"] },
      },
      {
        STRINGIFIED_APPDET: "admb",
        detectionRules: { userAgent: ["afma-sdk"], url: ["afma-sdk"] },
      },
      {
        STRINGIFIED_APPDET: "imbi",
        detectionRules: { javascript: ["InmobiObj"] },
      },
      {
        STRINGIFIED_APPDET: "mopb",
        detectionRules: {
          url: ["ads.mopub.com"],
          javascript: ["mopubFinishLoad"],
        },
      },
      {
        STRINGIFIED_APPDET: "pand",
        detectionRules: { javascript: ["PandoraApp"] },
      },
      {
        STRINGIFIED_APPDET: "sads",
        detectionRules: { javascript: ["mraid.sasSendMessage"] },
      },
      {
        STRINGIFIED_APPDET: "ogry",
        detectionRules: { url: ["ogury.io"], scriptSrc: ["OguryFR"] },
      },
      {
        STRINGIFIED_APPDET: "cnvt",
        detectionRules: {
          url: ["adsx.greystripe.com/openx/www/delivery/ia.php"],
        },
      },
      {
        STRINGIFIED_APPDET: "mobf",
        safeToInjectMraid: !0,
        detectionRules: { url: ["mobfox"] },
      },
      {
        STRINGIFIED_APPDET: "innr",
        detectionRules: { url: ["inner-active.mobi"] },
      },
      { STRINGIFIED_APPDET: "apnx", detectionRules: { javascript: ["anjam"] } },
      {
        STRINGIFIED_APPDET: "aers",
        detectionRules: { userAgent: ["AerServ"] },
      },
      {
        STRINGIFIED_APPDET: "tapj",
        detectionRules: { url: [["tapjoyads", "app_id"]] },
      },
      {
        STRINGIFIED_APPDET: "quan",
        detectionRules: { userAgent: ["QuantcastSDK"] },
      },
      {
        STRINGIFIED_APPDET: "cars",
        safeToInjectMraid: !0,
        detectionRules: {
          url: [
            ["carsales", ".android"],
            ["carsales", ".ios"],
          ],
        },
      },
      {
        STRINGIFIED_APPDET: "kkao",
        detectionRules: { userAgent: ["KAKAOTALK"] },
      },
      { STRINGIFIED_APPDET: "mrai", detectionRules: { javascript: ["mraid"] } },
    ],
    Gs = () => {
      const e = Ws();
      for (const t of Bs)
        try {
          const n = e.process(t.detectionRules);
          if (n) return n + "_" + t.STRINGIFIED_APPDET;
        } catch (e) {}
      return "";
    },
    Hs = () => {
      try {
        const e = Xi.stringToProp("mraid");
        if (null == e) return "absent";
        if ("object" != typeof e || Array.isArray(e)) return "non_obj";
        const t = "function" == typeof e.getState,
          n = "function" == typeof e.addEventListener,
          i = "function" == typeof e.isViewable;
        return t && n && i ? "full" : "partial";
      } catch (e) {
        return "error";
      }
    },
    $s = function () {
      "use strict";
      let t;
      const n = function (e) {
        let t;
        const n = Ws().process(e.detectionRules);
        return n && (t = n + "_" + e.STRINGIFIED_APPDET), t;
      };
      return {
        detect: function () {
          return (
            (t = Bs.map(n).filter((e) => void 0 !== e)),
            (t = t.length > 0 ? t[0] : ""),
            "" === t &&
              e.hasOwnProperty("serverSideAppDetection") &&
              0 !== e.serverSideAppDetection.length &&
              (t = "s_serv"),
            t
          );
        },
        hasDetectedMobileApp: function () {
          return void 0 !== t && "" !== t;
        },
      };
    },
    zs = function () {
      "use strict";
      const e = [];
      let t = [];
      const n = function (t) {
        let n;
        const i = Ws().process(t.detectionRules);
        return i && (e.push(t.STRINGIFIED_SDK + "*" + i), (n = t)), n;
      };
      return {
        detect: function () {
          return (
            (t = Xs.map(n).filter((e) => void 0 !== e)),
            t.length > 0 &&
              at.getAggregator().trigger(
                "addOutputItem",
                {
                  output: function () {
                    return e.join(".");
                  },
                },
                "sdk",
                { type: "impression" }
              ),
            t.length > 0
          );
        },
        isSafeToInjectMraid: function () {
          return (
            1 === t.length &&
            Ye(t[0].safeToInjectMraid) &&
            t[0].safeToInjectMraid
          );
        },
      };
    },
    Xs = [
      {
        STRINGIFIED_SDK: "adma",
        safeToInjectMraid: !0,
        detectionRules: { javascript: ["ADMARVEL"], url: ["AdMarvel"] },
      },
      {
        STRINGIFIED_SDK: "admb",
        safeToInjectMraid: !0,
        detectionRules: { userAgent: ["afma-sdk"], url: ["afma-sdk"] },
      },
      {
        STRINGIFIED_SDK: "imbi",
        safeToInjectMraid: !0,
        detectionRules: { javascript: ["InmobiObj"] },
      },
      {
        STRINGIFIED_SDK: "mmed",
        detectionRules: { url: ["mmsdk"], scriptSrc: ["mmsyscache"] },
      },
      {
        STRINGIFIED_SDK: "mopb",
        safeToInjectMraid: !0,
        detectionRules: {
          javascript: ["mopubFinishLoad"],
          url: ["ads.mopub.com"],
        },
      },
      {
        STRINGIFIED_SDK: "pand",
        detectionRules: { javascript: ["PandoraApp"] },
      },
      {
        STRINGIFIED_SDK: "ambe",
        safeToInjectMraid: !0,
        detectionRules: { url: ["amobee"] },
      },
      {
        STRINGIFIED_SDK: "smat",
        safeToInjectMraid: !0,
        detectionRules: { javascript: ["smaato_bridge"] },
      },
      {
        STRINGIFIED_SDK: "afrm",
        safeToInjectMraid: !0,
        detectionRules: { javascript: ["Adform"] },
      },
      {
        STRINGIFIED_SDK: "vrve",
        safeToInjectMraid: !0,
        detectionRules: { javascript: ["vrvsdk"] },
      },
      {
        STRINGIFIED_SDK: "sads",
        detectionRules: {
          javascript: ["mraid.sasSendMessage"],
          url: ["smartadserver.com"],
        },
      },
      {
        STRINGIFIED_SDK: "ogry",
        safeToInjectMraid: !0,
        detectionRules: { url: ["ogury.io"], scriptSrc: ["OguryFR"] },
      },
      {
        STRINGIFIED_SDK: "cnvt",
        detectionRules: {
          url: ["adsx.greystripe.com/openx/www/delivery/ia.php"],
        },
      },
      {
        STRINGIFIED_SDK: "mobf",
        safeToInjectMraid: !0,
        detectionRules: { url: ["mobfox"] },
      },
      {
        STRINGIFIED_SDK: "innr",
        detectionRules: { url: ["inner-active.mobi"] },
      },
      { STRINGIFIED_SDK: "apnx", detectionRules: { javascript: ["anjam"] } },
      {
        STRINGIFIED_SDK: "aers",
        safeToInjectMraid: !0,
        detectionRules: { userAgent: ["AerServ"] },
      },
      {
        STRINGIFIED_SDK: "tapj",
        detectionRules: { url: [["tapjoyads", "app_id"]] },
      },
      {
        STRINGIFIED_SDK: "quan",
        detectionRules: { userAgent: ["QuantcastSDK"] },
      },
      { STRINGIFIED_SDK: "kkao", detectionRules: { userAgent: ["KAKAOTALK"] } },
      {
        STRINGIFIED_SDK: "mrad",
        safeToInjectMraid: !0,
        detectionRules: { userAgent: ["unmatchabledetectionstring"] },
      },
    ],
    Ys = function (e) {
      "use strict";
      const t = [],
        n = function (e, t, n) {
          return new ea(0, e, n, n + t);
        };
      return (
        (function () {
          if (e.height < 10)
            t.push({
              geometry: new ea(0, e.width, 0, e.height),
              percentageInViewContribution: 100,
              isInView: !1,
            });
          else {
            const i = Math.floor(e.height),
              r = i % 10,
              o = (i - r) / 10;
            let s;
            const a = 10;
            for (let i = 0; i < 10; i++) {
              const c = i < r ? o + 1 : o,
                d = {
                  geometry: n(e.width, c, s || 0),
                  percentageInViewContribution: a,
                  isInView: !1,
                };
              t.push(d), (s = d.geometry.value().bottomY);
            }
          }
        })(),
        {
          getSlices: function () {
            return t;
          },
        }
      );
    },
    Js = [0, 0.1, 0.2, 0.25, 0.3, 0.4, 0.5, 0.6, 0.7, 0.75, 0.8, 0.9, 1],
    Qs = function () {
      "use strict";
      let e = Js.length,
        t = Js;
      const n = [];
      let i;
      return {
        getConfig: function (r) {
          if (i) return i;
          r.height < e && ((e = 1), (t = [100]));
          for (let t = 0; t < e; t++) n.push(!1);
          return (
            (i = {
              numberOfSlices: e,
              defaultSliceArray: n,
              percentInViewSliceArray: t,
            }),
            i
          );
        },
      };
    },
    Ks = function (e, t) {
      "use strict";
      const n = {
          mbrd: !1,
          mbvs: [],
          mbe: "n",
          mbv: 9,
          mbs: [],
          mbm: 1,
          mbivs: [],
        },
        i = function (e, t) {
          let n = 0;
          const i = (function (e, t) {
            const n = [],
              i = e.geometry.value();
            return (
              t.forEach(function (t) {
                if (e.geometry.doesIntersect(t)) {
                  const e = t.value(),
                    r = Math.max(i.leftX, e.leftX),
                    o = Math.min(i.rightX, e.rightX),
                    s = Math.max(i.topY, e.topY),
                    a = Math.min(i.bottomY, e.bottomY);
                  n.push(new ea(r, o, s, a));
                }
              }),
              n
            );
          })(e, t);
          let r;
          return (
            i.forEach(function (e) {
              (r = e.value()), (n += r.area);
            }),
            n
          );
        },
        r = function (t) {
          e.forEach(function (e) {
            e.isInView = i(e, t) >= e.geometry.value().area;
          });
        };
      return (
        t.addListener(r),
        {
          getPercentInView: function () {
            const t = (function () {
              let t = 0;
              return (
                (n.mbs = []),
                e.forEach(function (e) {
                  n.mbs.push(e.isInView),
                    e.isInView && (t += e.percentageInViewContribution);
                }),
                t
              );
            })();
            return (
              (n.mbrd = 1),
              t !== n.mbp && n.mbivs.push([Xn.getTagTime(), t]),
              (n.mbp = t),
              t
            );
          },
          removePixels: function () {
            void 0 !== t && t.stop();
          },
          getPixelStateForDebug: function () {
            return (
              (n.mbm = 1),
              (n.mbpr = []),
              (n.mbir = []),
              e.forEach(function () {
                n.mbpr.push("na"), n.mbir.push(!1);
              }),
              n
            );
          },
          isReadyToMeasure: function () {
            return !0;
          },
          getSliceStatus: function () {
            const t = [];
            return (
              e.forEach(function (e) {
                t.push(e.isInView);
              }),
              t
            );
          },
        }
      );
    },
    Zs = function (e) {
      "use strict";
      const t = Qs();
      return {
        getSliceStatus: function (n, i, r, o) {
          const s = [],
            a = n.getRounded(),
            c = a.height,
            d = a.scrY,
            u = new ei({ scrX: a.scrX, width: a.width }),
            l = t.getConfig(a).numberOfSlices;
          let g;
          u.set("height", _i.floor(c / l));
          for (let t = 0; t < l; t++)
            u.set("scrY", Math.ceil(d + (c / l) * t)),
              (g = 100 === e.calcPercentInView(u, i, r, o)),
              s.push(g);
          return s;
        },
      };
    },
    ea = function (e, t, n, i) {
      "use strict";
      const r = Math.ceil(e),
        o = Math.ceil(t),
        s = Math.ceil(n),
        a = Math.ceil(i),
        c = o - r,
        d = a - s,
        u = c * d,
        l = function () {
          return {
            leftX: r,
            rightX: o,
            topY: s,
            bottomY: a,
            width: c,
            height: d,
            area: u,
          };
        };
      return {
        value: l,
        doesIntersect: function (e) {
          const t = l(),
            n = e.value();
          return (
            n.leftX < t.rightX &&
            n.rightX > t.leftX &&
            n.topY < t.bottomY &&
            n.bottomY > t.topY
          );
        },
      };
    },
    ta = function () {
      "use strict";
      return {
        createInstance: function (e, t) {
          return new IntersectionObserver(e, t);
        },
      };
    },
    na = function (e, t) {
      "use strict";
      let n;
      const i = [];
      let r = [];
      const o = function (e, t) {
          -1 === e.indexOf(t) && e.push(t);
        },
        s = function (e) {
          const t = (function () {
            let e = [];
            return (
              r.forEach(function (t) {
                const n = t.value();
                o(e, n.topY), o(e, n.bottomY);
              }),
              (e = e.sort(function (e, t) {
                return e - t;
              })),
              e
            );
          })();
          r = [];
          for (let i = 0; t.length > i && ((n = i), t.length !== n + 1); i++) {
            const n = t[i],
              o = t[i + 1];
            r.push(new ea(0, e, n, o));
          }
          var n;
        },
        a = function (e, t) {
          r.push(e),
            s(t),
            i.forEach(function (e) {
              e(r);
            });
        },
        c = function () {
          n.unobserve(e), n.disconnect();
        };
      return (
        (n = t.createInstance(
          function (e) {
            const t = e.pop(),
              n = t.boundingClientRect,
              i = n.width,
              r = t.intersectionRatio,
              o = (function (e, t) {
                const n = t.left - e.left,
                  i = n + t.width,
                  r = t.top - e.top,
                  o = r + t.height;
                return new ea(n, i, r, o);
              })(n, t.intersectionRect);
            a(o, i), 1 === r && c();
          },
          { threshold: [0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1] }
        )),
        n.observe(e),
        {
          addListener: function (e) {
            i.push(e);
          },
        }
      );
    },
    ia = function () {
      "use strict";
      const e = function (e) {
          let t = !1;
          return (
            ra.forEach(function (n) {
              e === n.PARTNER_NAME && (t = !0);
            }),
            t
          );
        },
        t = function (t, i) {
          return t.omidNativeInfo &&
            t.omidNativeInfo.partnerName &&
            e(t.omidNativeInfo.partnerName)
            ? i && n(i.onScreenContainerGeometry)
            : i && n(i.onScreenGeometry);
        },
        n = function (e) {
          return (
            e &&
            e.hasOwnProperty("x") &&
            e.hasOwnProperty("y") &&
            e.hasOwnProperty("width") &&
            e.hasOwnProperty("height")
          );
        };
      return {
        detect: e,
        checkAdViewGeometryBasedOnWhitelist: t,
        checkGeometryObject: n,
        checkForViewAttachmentBasedOnAdSessionType: function (e, n) {
          if (
            n &&
            n.reasons &&
            n.reasons.indexOf("notFound") < 0 &&
            e.adSessionType &&
            (e.adSessionType.indexOf("native") > -1 ||
              e.adSessionType.indexOf("javascript") > -1 ||
              (e.adSessionType.indexOf("html") > -1 && t(e, n)))
          )
            return !0;
        },
      };
    },
    ra = [
      { PARTNER_NAME: "IAB" },
      { PARTNER_NAME: "IAS" },
      { PARTNER_NAME: "com.integralads.omid.iassdk" },
    ],
    oa = function () {
      "use strict";
      return {
        listenForResult: function () {
          at.getAggregator().on("videoBlockResult", function (t) {
            const n = at.getAggregator().request("adNode");
            let i = !1;
            const r = "blockAd" + e.videoId;
            "failed" === t.action && (i = !0),
              n && Ye(n.blockAd) ? n.blockAd(i) : n && Ye(n[r]) && n[r](i);
          });
        },
      };
    },
    sa = function () {
      "use strict";
      const e = [];
      return {
        registerEvent: (t, n) => {
          const i = (function (e, t) {
            var n, i;
            const r = (e) => e.getVolumeFromContext(s),
              o = at
                .getAggregator()
                .request("videoTranslator")
                .translate(e.messageType),
              s = ((e) => {
                const t = e.eventData || {},
                  n = Ze({}).mixin(t);
                return n.ext_passthrough && delete n.ext_passthrough, n;
              })(e),
              a = ((e) => {
                let t;
                const n = e.eventData && e.eventData.ext_passthrough,
                  i = (e, t) => {
                    const n = {};
                    return (n[`x_${e}`] = t), n;
                  };
                return n && (t = Ze(n).mapToObj(i)), t;
              })(e),
              c =
                null === (n = oe.measurementConfig) || void 0 === n
                  ? void 0
                  : n.birthdate,
              d = { t: e.time - c, tp: o, sl: t };
            try {
              if (void 0 !== e.volumeHandler) {
                const t = r(e.volumeHandler);
                if (void 0 !== t) {
                  const n = parseFloat(t),
                    r =
                      null === (i = null == e ? void 0 : e.latestScreenEvent) ||
                      void 0 === i
                        ? void 0
                        : i.percentInView,
                    o = "number" == typeof r,
                    s = "AdVideoComplete" === e.messageType;
                  o && s && n > 0 && r >= 50
                    ? (d.avoc = 1)
                    : o && s && (d.avoc = 0);
                }
              }
            } catch (e) {}
            Ze(d).mixin(s), Ze(d).mixin(a);
            const u = Ze({
              indicatesPlaying: () =>
                -1 !== "showAd|adImpression|adVideoStart|resumeAd".indexOf(o),
              indicatesNotPlaying: () =>
                -1 !== "adVideoComplete|adStopped|stopAd|pauseAd".indexOf(o),
              indicatesFullscreen: () => {
                const e = _i.getWindow();
                return !(
                  ("resizeAd" !== o && "initAd" !== o) ||
                  ("fullscreen" !== s.viewMode && s.width !== e.screen.width)
                );
              },
              indicatesNormalSize: () =>
                "resizeAd" === o && "normal" === s.viewMode,
              indicatesQuartile: () =>
                -1 !==
                "adVideoFirstQuartile|adVideoMidpoint|adVideoThirdQuartile|adVideoComplete".indexOf(
                  o
                ),
              indicatesCompletion: () =>
                -1 !== "adStopped|adVideoComplete|adSkipped|adError".indexOf(o),
              getVolume: r,
              updateScreenLoc: (e) => {
                (d.sl = e), (u.sl = e);
              },
              trigger: () => {
                "adImpression" === o
                  ? at.getAggregator().persistentTrigger(o, s, a)
                  : at.getAggregator().trigger(o, s, a);
              },
              toString: () => "{" + Ze(d).toParams() + "}",
            }).mixin(d);
            return u;
          })(t, n);
          return e.push(i), i;
        },
        toString: () =>
          "{" +
          Ze({
            vEventCount: e.length,
            vEvents: "[" + e.join(",") + "]",
          }).toParams() +
          "}",
        isEmpty: () => 0 === e.length,
      };
    },
    aa = function () {
      "use strict";
      let e, t, n;
      const i = function (i) {
          (n = Ye(i) ? 0 === i : n),
            t &&
              n &&
              e.addState({
                isFullyInView: function () {
                  return !1;
                },
              });
        },
        r = function () {
          e &&
            e.hasAlwaysBeen(!0) &&
            at.getAggregator().trigger("sendDt", "qf");
        },
        o = function () {
          (t = !0), i();
        },
        s = function (e) {
          const t = new da().getVolumeFromContext(e);
          i(t);
        };
      return {
        isApplicable: function (e) {
          return e.usesGroupMCustomMetric();
        },
        start: function (n) {
          at
            .getAggregator()
            .on({
              adVideoStart: o,
              adImpression: o,
              volumeChanged: s,
              adVideoMidpoint: r,
            }),
            (e = n.createViewabilityTracker("mpt", function (e) {
              const n = at.getAggregator().request("isFullyInViewProvider");
              return !t || (n && n.isFullyInView(e));
            }));
        },
      };
    },
    ca = function () {
      "use strict";
      const e = {
        AdPaused: "pauseAd",
        AdVolumeChange: "volumeChanged",
        AdPlaying: "resumeAd",
      };
      return {
        translate: function (t) {
          let n = t.charAt(0).toLowerCase() + t.slice(1);
          return t in e && (n = e[t]), n;
        },
      };
    },
    da = function () {
      "use strict";
      return {
        getVolumeFromContext: (e) => {
          let t,
            n = -1;
          return (
            Ye(e) &&
              (Ye(e.volume)
                ? (n = e.volume)
                : Ye(e.adVolume) && (n = e.adVolume)),
            -1 !== n && (t = n),
            t
          );
        },
      };
    },
    ua = function (t, n, i) {
      "use strict";
      const r = "IASid" + t,
        o = "getIasVidBridgeVersion" + t;
      let s,
        a,
        c,
        d = [],
        u = "outOfView",
        l = !1,
        g = !1,
        m = !1,
        p = !0,
        h = !1;
      const f = new sa(),
        v = aa(),
        y = new oa(),
        b = new da(),
        w = new Ii(),
        A = function (e) {
          l = !0;
          const t = I(e);
          return (
            t && (t.iasPlaybackStateSnapshot = E()), d.push(t), c && M(), t
          );
        },
        I = function (e) {
          let n,
            r,
            o = {};
          try {
            o = JSON.parse(unescape(e && e.data ? e.data : e));
          } catch (e) {
            o = {};
          }
          if (o.id == t)
            if (Xn && Xn.isVastAudio() && o.messageType && o.eventData) {
              const e = !!o.eventData.volume,
                t =
                  -1 ===
                  "AdVideoComplete|AdStopped|AdSkipped|AdPaused|AdError|AdUserClose".indexOf(
                    o.messageType
                  ),
                i = e && t;
              (o.eventData.width = i ? 20 : 0),
                (o.eventData.height = i ? 20 : 0),
                (p = e),
                (g = t),
                (u = !!i && "inView"),
                (n = f.registerEvent(o, i ? "i" : "o"));
            } else
              (o.latestScreenEvent = i.getLatestEvent()),
                (o.volumeHandler = b),
                (n = f.registerEvent(o, i.getCurrentLoc())),
                n.indicatesPlaying()
                  ? ((g = !0), (u = !!m && "inView"))
                  : n.indicatesNotPlaying()
                  ? ((g = !1), (u = "outOfView"))
                  : n.indicatesFullscreen()
                  ? ((m = !0), (u = g ? "inView" : "outOfView"))
                  : n.indicatesNormalSize() &&
                    ((m = !1), (u = !g && "outOfView")),
                (r = parseFloat(n.getVolume(b))),
                r > 0 ? (p = !0) : 0 === r && (p = !1);
          return n;
        },
        S = function (n) {
          let i, s;
          const a = Fi().wrapToGlobal(A);
          try {
            (s = n[o] || n.getIasVidBridgeVersion),
              (i =
                Je(s) && "2" === s.call(n)
                  ? unescape(n[r].call(n, t, a))
                  : unescape(n[r].call(n, t))),
              (l = !0),
              (function (e) {
                Qe(e) &&
                  (at.getAggregator().provide("vc", function () {
                    return e;
                  }),
                  at
                    .getAggregator()
                    .trigger("addOutputItem", { output: e }, "vc", {
                      type: "impression",
                    }));
              })(i || "n");
          } catch (t) {
            __IntegralASDiagnosticCall("handshakefailure", t, e);
          }
        },
        T = function () {
          if (
            !s &&
            (Ze([
              "*[data-integralas-vid-" + t + "]",
              ".integral-vid-" + t,
              "ias-ad",
              "object",
              "embed",
            ]).findFirst(function (e, t) {
              const n = _i.getDoc().querySelectorAll(t);
              return (
                (s = (function (e) {
                  return Ze(Ze(e).toArray()).findFirst(function (e, t) {
                    return Je(t[r]);
                  });
                })(n)),
                s
              );
            }),
            !s && n.on("novidnodeerr"))
          ) {
            Math.random() < 0.1 &&
              __IntegralASDiagnosticCall(
                "novidnode",
                { message: "node not found*10" },
                e
              );
          }
          return s;
        },
        C = function () {
          const e = T();
          return e && !l && S(e), e;
        },
        O = function (e) {
          const t = b.getVolumeFromContext(e);
          p = !!Ye(t) && t > 0;
        },
        E = function () {
          return { isPlaying: g, isSoundOn: p, isFullscreen: m };
        },
        D = function (e) {
          var t;
          const n =
              null === (t = i.getCurrentEvent) || void 0 === t
                ? void 0
                : t.call(i),
            r = e || E(),
            o = r.isFullscreen && r.isPlaying;
          return n
            ? Object.assign(Object.assign({}, n), {
                percentInView: o ? 100 : n.percentInView,
                fullPercentInView: o ? 100 : n.fullPercentInView,
                isVideoPlaying: r.isPlaying,
                isSoundOn: r.isSoundOn,
                isVideoPlayingInFullscreen: o,
              })
            : n;
        },
        M = function () {
          w.init(),
            Ze(d).each(function (e, t) {
              t &&
                (void 0 === t.sl && t.updateScreenLoc(i.getCurrentLoc()),
                t.trigger(),
                t.indicatesCompletion() &&
                  at.getAggregator().trigger("adSessionComplete"),
                (function (e) {
                  return (
                    e.indicatesCompletion() ||
                    "adUserClose" === e.tp ||
                    "stopAd" === e.tp ||
                    "adStopped" === e.tp ||
                    "adSkipped" === e.tp ||
                    "adError" === e.tp
                  );
                })(t) && (h = !1),
                t.indicatesQuartile() &&
                  ("adVideoComplete" !== t.tp &&
                    at.getAggregator().trigger("sendDt", "m"),
                  at
                    .getAggregator()
                    .trigger("videoQuartileEvent", {
                      videoEvent: t,
                      screenEvent: D(t.iasPlaybackStateSnapshot),
                    })),
                !h &&
                (function (e) {
                  return e.indicatesPlaying();
                })(t)
                  ? ((h = !0),
                    at
                      .getAggregator()
                      .trigger("videoStartEvent", {
                        videoEvent: t,
                        screenEvent: D(t.iasPlaybackStateSnapshot),
                      }))
                  : t.indicatesQuartile() ||
                    at
                      .getAggregator()
                      .trigger("videoPlaybackStateEvent", {
                        videoEvent: t,
                        screenEvent: D(t.iasPlaybackStateSnapshot),
                      }));
            }),
            (d = []),
            (c = !0);
        },
        x = function () {
          return m && g;
        };
      return (
        Jn.addEvent(_i.getWindow(), "message", function (e) {
          A(e);
        }),
        at.getAggregator().on({ volumeChanged: O }),
        at.getAggregator().provide({
          videoEventsString: f,
          videoVersion: function () {
            let e;
            const t = C();
            try {
              e = t.getVersion();
            } catch (t) {
              (e = -1), at.getAggregator().trigger("error", "u");
            }
            return e;
          },
          videoTranslator: function () {
            return (a = a || new ca()), a;
          },
          adNode: C,
        }),
        C(),
        y.listenForResult(),
        v.isApplicable(Xn) && v.start(i),
        {
          findAdNode: C,
          getViewStateOverride: function () {
            return u;
          },
          isHandshakeComplete: function () {
            return l;
          },
          triggerInitializationEvents: M,
          setVideoSpecificScreenEventFields: function (e) {
            const t = "na" === e.viewState;
            if (
              ((e.isVideoPlaying = !0),
              (e.isSoundOn = p),
              (e.isVideoPlayingInFullscreen = !1),
              u)
            ) {
              if ("outOfView" === u) {
                const t = e.reason ? e.reason.split(".") : [];
                (t[t.length] = "v"), (e.reason = t.join("."));
              }
              (e.viewState = t ? e.viewState : u),
                (e.isVideoPlaying = "inView" === u);
            }
            if (
              (x() &&
                ((e.percentInView = 100), (e.isVideoPlayingInFullscreen = !0)),
              Xn && Xn.isVastAudio && Xn.isVastAudio())
            ) {
              const t = 20,
                n = 20,
                i = g && p,
                r = new ei({
                  scrX: 0,
                  scrY: 0,
                  width: i ? t : 0,
                  height: i ? n : 0,
                });
              (e.adDimensions = r),
                (e.containerDimensions = r),
                (e.viewState = i ? "inView" : "outOfView"),
                (e.viewStateIgnoringRender = i ? "inView" : "outOfView"),
                (e.posViewState = i ? "inView" : "outOfView"),
                (e.percentInView = i ? 100 : 0),
                (e.percentInViewIgnoringRender = i ? 100 : 0),
                (e.isHidden = i ? 0 : 1),
                (e.tabHidden = i ? 0 : 1);
            }
          },
        }
      );
    },
    la = function () {
      "use strict";
      return new fa("flwrapper", 9);
    },
    ga = function () {
      "use strict";
      let e, t;
      const n = {};
      let i = 0;
      const r = (n) => {
          (n || e) &&
            ((i += 5),
            t.onTick(i, () => {
              e ? r() : at.getAggregator().trigger("sendDt", "e");
            }),
            (e = !1));
        },
        o = () => {
          (t = new Sn()), (i = 0), r(!0), t.start();
        },
        s = (i, r, s, a) => {
          const c = n[i];
          a ? (Ye(c[r]) || (c[r] = []), c[r].push(s)) : (c[r] = s),
            (t && t.isActive()) || o(),
            (e = !0);
        },
        a = (n, i, r) => {
          at.getAggregator().trigger("addOutputItem", { output: i }, n, r),
            (t && t.isActive()) || o(),
            (e = !0);
        },
        c = (t) => {
          Object.keys(n).forEach((i) => {
            ((t, i) => {
              const r = n[t],
                o = { type: i, oneTime: !0, minDt: !0, asION: !0 };
              0 !== Object.keys(r).length &&
                (at
                  .getAggregator()
                  .trigger("addOutputItem", { output: r }, t, o),
                (n[t] = {})),
                (e = !1);
            })(i, t);
          });
        };
      return {
        start: () => {
          at.getAggregator().on("preSendDt", (e) => {
            c(e), t && t.kill();
          }),
            at.getAggregator().on("addThrottledProp", s),
            at.getAggregator().on("addThrottledOutputItem", a);
        },
        addFieldTypes: (e) => {
          e.forEach((e) => {
            n[e] = {};
          });
        },
      };
    },
    ma = function () {
      "use strict";
      const e = {},
        t = (t) => (
          !e[t] && (e[t] = new In(1, oe.measurementConfig.birthdate)), e[t]
        ),
        n = (e) => {
          t(e).start();
        },
        i = (e) => {
          const n = t(e);
          n.stop(),
            at
              .getAggregator()
              .trigger("addThrottledProp", "im", e, n.getTime());
        };
      return {
        start: () => {
          at.getAggregator().on({ markTime: n, measureTime: i });
        },
        isApplicable: (e) => e.on("pIntervals"),
      };
    },
    pa = function () {
      "use strict";
      return new fa("jswrapper", 15);
    },
    ha = function (e) {
      "use strict";
      const t = {},
        n = e instanceof Array && e.length > 0;
      return (
        n &&
          (e.forEach(function (e) {
            var n;
            t[(n = e).getType()] = n;
          }),
          at.getAggregator().on("perfCheckpoint", function (e) {
            const n = t[e.type];
            if (n)
              try {
                n.addPoint(e),
                  n.isFinished() &&
                    at
                      .getAggregator()
                      .trigger("addThrottledProp", "im", "pci", n.toString());
              } catch (e) {}
          })),
        at.getAggregator().provide("perfActive", function () {
          return n;
        }),
        { isActive: n }
      );
    },
    fa = function (e, t) {
      "use strict";
      let n = 0;
      const i = [],
        r = function () {
          let e;
          const t = {};
          return (
            i.sort(function (e, t) {
              return e.timestamp - t.timestamp;
            }),
            Ze(i).each(function (i, r) {
              e && (t[r.code] = r.timestamp - e), i === n && (e = r.timestamp);
            }),
            t
          );
        };
      return {
        addPoint: function (e) {
          i.push(e);
        },
        toString: function () {
          return Ze(r()).toION();
        },
        getType: function () {
          return e;
        },
        setBaseOrdinal: function (e) {
          n = e;
        },
        isFinished: function () {
          return i.length === t;
        },
      };
    },
    va = (function () {
      "use strict";
      function e() {}
      return (
        (e.build = function () {
          const e = [];
          e.push(new fa("render", 2));
          const t = (function () {
            const e = at.getAggregator().request("vc");
            return e ? { jv3: ya, av3: ya, jvw: pa, avw: la }[e] : void 0;
          })();
          return t && e.push(t()), e;
        }),
        e
      );
    })(),
    ya = function () {
      "use strict";
      return new fa("vans", 4);
    },
    ba = {
      IDS: { BLOCK_TIME: "pBlk", ON_LOAD: "pLoad", IN_BROWSER_DELAY: "pWait" },
      recordBlockingTime: () => {
        "use strict";
        at.getAggregator().trigger("measureTime", ba.IDS.BLOCK_TIME);
      },
      setupOnLoadTracking: () => {
        "use strict";
        Jn.addEvent(t, "load", () => {
          at.getAggregator().trigger("measureTime", ba.IDS.ON_LOAD);
        });
      },
      setupBrowserDelayTracking: () => {
        "use strict";
        const e = new Sn();
        e.onTick({
          4: () => {
            at.getAggregator().trigger("markTime", ba.IDS.IN_BROWSER_DELAY);
          },
          5: () => {
            at.getAggregator().trigger("measureTime", ba.IDS.IN_BROWSER_DELAY);
          },
        }),
          e.start();
      },
    },
    wa = {
      name: "postMessageDetector",
      dependencies: [],
      creator: function () {
        "use strict";
        let e = !1;
        const t = "pmdetector" + (oe.adTag && oe.adTag.asid),
          n = (n) => {
            (n && n.data) === t && (e = !0);
          };
        (() => {
          const i = _i.getWindow();
          Jn.addEvent(i, "message", n),
            i.postMessage(t, "*"),
            _i.execAtEndOfThread(() => {
              at
                .getAggregator()
                .trigger("addThrottledProp", "im", "pom", Ke(e)),
                Jn.removeEvent(i, "message", n);
            });
        })();
      },
      settings: {
        tier: 8,
        applies: (e, t, n) => {
          "use strict";
          return e.on("pmdetect") && t.hasPostMessage();
        },
      },
    },
    Aa = {
      name: "safeFrameDetector",
      dependencies: [],
      creator: function () {
        "use strict";
        at.getAggregator().trigger(
          "addThrottledProp",
          "im",
          "sf",
          Ke(Xn.isSafeFrame())
        );
      },
      settings: {
        tier: 8,
        applies: (e, t, n) => {
          "use strict";
          return e.on("sfdetect");
        },
      },
    },
    Ia = function (t, n, i, r, o, s, a) {
      "use strict";
      const c = "adsafe_jsinfo=",
        d = (e) => ("&" === e.slice(-1) ? "" : "&"),
        u = (u) => {
          var l;
          const g =
              null === (l = oe.baseUrls) || void 0 === l
                ? void 0
                : l.ctvImpressionUrl,
            m = !!g;
          let h = m
            ? (({ ctvImpressionUrl: t }) => {
                var n, i, r, o, s, a;
                const { advEntityId: c, pubEntityId: d } = $n(),
                  u =
                    null !==
                      (i =
                        null === (n = oe.adTag) || void 0 === n
                          ? void 0
                          : n.creativeUrl) && void 0 !== i
                      ? i
                      : "",
                  l = u.indexOf("?"),
                  g = -1 === l ? u : u.slice(0, l),
                  m = Xn.isDomless()
                    ? ne({ url: p() || void 0 })
                    : (null === (r = oe.contextNode) || void 0 === r
                        ? void 0
                        : r.staticFwjsMacros) ||
                      e.staticFwjsMacros ||
                      ne({
                        url:
                          null === (o = oe.contextNode) || void 0 === o
                            ? void 0
                            : o.src,
                        paramsToStrip: ["config", "iasConfig", "creativeUrl"],
                      }),
                  h =
                    (null ===
                      (a =
                        null === (s = oe.jsConfigRequest) || void 0 === s
                          ? void 0
                          : s.verificationParameters) || void 0 === a
                      ? void 0
                      : a.staticFwjsMacros) || m,
                  f = g.replace(/^https?:/i, ""),
                  v = [
                    "advEntityId=" + c,
                    "pubEntityId=" + d,
                    "creativeUrl=" + encodeURIComponent(f),
                  ];
                return h && v.push(h), t + "?" + v.join("&") + "&";
              })({ ctvImpressionUrl: g })
            : r.baseUrl;
          const f = oe.measurementConfig.spImpMaxLength;
          if (
            (m ||
              (qn.checkIfFirstPartyBlockingApplies({ impressionUrl: h })
                ? (h = qn.modifyUrlForFirstPartyBlocking({ impressionUrl: h }))
                : Xn.integratedBlockingApplies(h) &&
                  (h = ((t) => {
                    const n = at.getAggregator().request("mobileApp"),
                      i =
                        n &&
                        n.isMobileAppEnvironment &&
                        n.isMobileAppEnvironment();
                    let r =
                      t +
                      "adContainerId=" +
                      e.contextNode.getAttribute("data-ias-container") +
                      "&cbFunctionName=" +
                      e.contextNode.getAttribute(
                        "data-ias-callback".toString()
                      );
                    r = i
                      ? r.replace("monitoring", "blocking")
                      : r.replace("skeleton.js", e.integration + ".js");
                    const o =
                        e.protocol +
                        ":" +
                        e.staticServer +
                        e.integration +
                        "a.js",
                      s =
                        e.protocol +
                        ":" +
                        e.staticServer +
                        e.integration +
                        ".js";
                    return (
                      r +
                      "&true_pb=" +
                      encodeURIComponent(e.passback) +
                      (i ? "&redirectUrl=" + encodeURIComponent(s) : "") +
                      (i ? "&passback=" : "&adsafe_pb=") +
                      encodeURIComponent(o) +
                      "&"
                    );
                  })(h)),
              (h = h.replace("[IAS_ASID]", oe.adTag && oe.adTag.asid))),
            (h += ((e, i, r) => {
              let o,
                s,
                a = "";
              try {
                (o = i - e - oe.measurementConfig.spImpJsInfoMinLength),
                  o > 0 &&
                    ((s = xa(r, o, c.length, n.on("partialUrls"))),
                    (a += s.join("&")));
              } catch (e) {
                t.add("I");
              }
              return a;
            })(h.length, f, u)),
            (h += d(h)),
            (h += ((e, r) => {
              let d = "";
              try {
                d += Oa(r - e, c, t, n, i, o, s, a, r);
              } catch (e) {
                t.add("J"), (d += "adsafe_jsinfo=e:" + t.toString());
              }
              return d;
            })(h.length, f)),
            r.macroUrl && ((h += d(h)), (h += r.macroUrl)),
            !m &&
              e.staticFwjsMacros &&
              ((h += d(h)), (h += e.staticFwjsMacros)),
            Xn.isAMZN() && -1 === h.indexOf("gdpr_consent"))
          ) {
            const e = at.getAggregator().request("tcString");
            Ye(e) && ((h += d(h)), (h += "gdpr_consent=" + e));
          }
          return h;
        };
      return {
        send: (t) => {
          try {
            const n = u(t);
            (e.impUrl = n),
              r.sendImpression(n),
              at.getAggregator().trigger("impressionsent"),
              (() => {
                if (e.rts && e.rts.tracked) {
                  const t = e.rts.tracked;
                  at.getAggregator().trigger("notify", t);
                }
              })();
          } catch (t) {
            __IntegralASDiagnosticCall("impsend", t, e);
          }
        },
      };
    },
    Sa = () => {
      try {
        const n = e.perf;
        at.getAggregator().trigger(
          "addOutputItem",
          { output: Xn.getTagTime() },
          "sis"
        );
        const i = () =>
            t.performance &&
            "function" == typeof t.performance.getEntriesByName &&
            t.performance.getEntriesByName(e.impUrl)[0],
          r = (t) => {
            const i = n.getStart("bd"),
              r = n.getStart(ft);
            return e.jsDoSplit ? Math.round(t - i) : Math.round(t - r);
          },
          o = (e) => Math.round(e && e.duration),
          s = (e, t) => {
            const n = t && t.responseEnd;
            return Math.round(e - n);
          };
        n.markEnd("ec");
        const a = n.getEnd("ec"),
          c = i(),
          d = r(a),
          u = o(c),
          l = s(a, c);
        if (ot(d) && ot(u) && ot(l)) {
          const e = { ttecl: d, ecd: u, tsecr: l };
          at.getAggregator().trigger(
            "addThrottledProp",
            "im",
            "imprf",
            Ze(e).toION()
          );
        }
      } catch (e) {
        at.getAggregator().trigger("error", "e");
      }
    },
    Ta = /(?:^|[?&])adsafe_jsinfo=/,
    Ca = ({ impressionUrl: e }) => {
      if ("string" != typeof e || 0 === e.length) return;
      const t = Ta.exec(e);
      if (!t) return;
      const n = e.substring(t.index + t[0].length),
        i = n.indexOf("&");
      return -1 === i ? n : n.substring(0, i);
    },
    Oa = (t, n, i, r, o, s, a, c, d) => {
      "use strict";
      const u = (e) => {
          let t = "";
          return e && (t = `,${e}`), t;
        },
        l = (e, n) => e.length + n.length + 5 <= t;
      return ((t) => {
        let i = "";
        const s =
          !Xn.isDomless() &&
          (({ apiFunctionName: e, apiFrameLocatorName: t }) => {
            let n = !1;
            try {
              n = !!Ft({ apiFunctionName: e, apiFrameLocatorName: t });
            } catch (e) {}
            return n;
          })({
            apiFunctionName: "__tcfapi",
            apiFrameLocatorName: "__tcfapiLocator",
          });
        return (
          s && r.on("consentDetection")
            ? (i += ((e) => {
                let t = n;
                const { primary: i } = e,
                  r = i.find((e) => e.includes("id:"));
                return (
                  (t += u("cmpApi:1")),
                  (t += u(r)),
                  o.impressionIsIdentifiable(!0),
                  t
                );
              })(t))
            : (i += ((t) => {
                const i = st(t.primary.join(","), e.encodeInvalidUrlChars);
                let r = 0,
                  s = n;
                return (
                  l(s, i)
                    ? ((s += u(i)),
                      o.impressionIsIdentifiable(!0),
                      t.secondary.forEach((t) => {
                        const n = st(t, e.encodeInvalidUrlChars);
                        l(s, n) ? (s += u(n)) : (r += 1);
                      }))
                    : (r += t.primary.length),
                  (s += ",ov:" + r)
                );
              })(t)),
          i
        );
      })(
        (() => {
          const e = (() => {
              const e = { viewState: "na" };
              let t,
                n = e;
              return (
                Xn.isDomless()
                  ? (n = c.checkScreenLoc(!0) || e)
                  : r.on("impFailSafe")
                  ? _i.getDoc().body &&
                    ((t = c.checkScreenLoc(!0)), (n = t || e))
                  : Ye(_i.getDoc().body) && (n = c.checkScreenLoc(!0)),
                c.isImmediatelyMeasurable() ||
                  c.requiresDelayedViewabilityEvent(),
                n
              );
            })(),
            t = Ea(e.viewState, o, r),
            n = Ma(e, i, r, s, a, c, d);
          return (
            at.getAggregator().trigger("eligiblerender"),
            { primary: t, secondary: n }
          );
        })()
      );
    },
    Ea = function (e, t, n) {
      "use strict";
      const i = at.getAggregator().request("mPage");
      return [
        "id:" + (oe.adTag && oe.adTag.asid),
        "c:" + t.getCacheBustId(),
        "sl:" + e,
        "em:" + Xn.embedded,
        "fr:" + Xn.friendly,
        "thd:" + Ke(i.supportsVisAPI()),
      ];
    },
    Da = /\/fw\.js(?:[?#]|$)/,
    Ma = function (t, n, i, r, o, s, a) {
      "use strict";
      var c, d, u, l, g;
      const { measurementConfig: m } = oe,
        h = "NotFound",
        f = [];
      if (
        (f.push("mn:" + e.mn),
        f.push("rg:" + e.region),
        e.iasProxyPartnerDomain &&
          f.push("ipp:" + encodeURIComponent(e.iasProxyPartnerDomain)),
        f.push(
          "pt:" +
            (() => {
              let e = s.stringifyPingTimes();
              return "na" !== t.viewState && (e += t.details), e;
            })()
        ),
        f.push("mu:" + a),
        f.push(Ze(o.params()).toParams()),
        i.on("mrcAudit") &&
          !Xn.isDomless() &&
          f.push("dvs:" + _i.getDoc().visibilityState),
        r.iterate((e, t) => {
          const n = !t.props || void 0 === t.props.type,
            i = !t.props || "impression" === t.props.type;
          (n || i) && f.push(e + ":" + t.output());
        }),
        n.toString() && f.push("e:" + n.toString()),
        f.push(i.output()),
        f.push("tt:" + oe.adTag.tagType),
        Xn && Xn.isVastAudio && Xn.isVastAudio() && f.push("vau:1"),
        Xn)
      ) {
        let e;
        Xn.isVideo() && (e = "v"),
          (Xn.isVastAudio() || Xn.isOmidAudio()) && (e = "a"),
          e && f.push(`xmtp:${e}`);
      }
      if (
        (f.push("et:" + (_i.now() - m.birthdate)),
        e.perf.mark("si"),
        f.push("v:19.8.744"),
        f.push("sp:" + (e.isSplitMode ? 1 : 0)),
        f.push("st:" + (m.staticMode ? 1 : 0)),
        f.push("fwm:" + ("true" === e.fwMonitoring ? 1 : 0)),
        "rjss" === oe.adTag.tagType)
      ) {
        const e =
            null === (c = oe.jsConfigRequest) || void 0 === c
              ? void 0
              : c.verificationParameters,
          t = se(),
          n = !!t && Da.test(t),
          i = Xn && Xn.isDomless && Xn.isDomless() ? p() : t,
          r =
            !ie({ url: null != i ? i : void 0 }) &&
            !!(null == e ? void 0 : e.staticFwjsMacros);
        n && f.push("rjd:1"), r && f.push("rjc:1");
      }
      !!(null ===
        (u =
          null === (d = oe.jsConfigRequest) || void 0 === d
            ? void 0
            : d.verificationParameters) || void 0 === u
        ? void 0
        : u.config) && f.push("ipc:1");
      !!(null ===
        (g =
          null === (l = oe.jsConfigRequest) || void 0 === l
            ? void 0
            : l.verificationParameters) || void 0 === g
        ? void 0
        : g.useCacheableStatic) && f.push("cst:1"),
        i.on("resolution") &&
          (f.push("wr:" + Ze(oi.windowSize()).toArray().join(".")),
          f.push("sr:" + Ze(oi.screenSize()).toArray().join(".")));
      const v = /iasProxyPartnerId=([\d]+)/g.exec(e.scriptUrl),
        y = v && v[1],
        b = e.proxyPartnerId || y || "";
      b && f.push("ppi:" + b);
      const w = (() => {
        const t = "ias_xpc",
          n = (e) => {
            if (!e || "string" != typeof e) return h;
            const n = String(e).toLowerCase(),
              i = n.indexOf(t);
            if (-1 === i) return h;
            const r = n.substring(i + t.length + 1),
              o = r.indexOf("&");
            return o > -1 ? r.substring(0, o) : r;
          },
          i = n(e.scriptUrl);
        if (i !== h) return i || "";
        let r = "";
        try {
          const e = _i.getDoc();
          e &&
            e.location &&
            "string" == typeof e.location.href &&
            (r = e.location.href);
        } catch (e) {
          r = "";
        }
        const o = n(r);
        return o !== h && "" !== o ? o : h;
      })();
      return h !== w && f.push("x_xpc:" + w), f;
    },
    xa = function (e, t, n, i) {
      "use strict";
      let r, o;
      const s = "adsafe_url=",
        a = "&adsafe_type=",
        c = [],
        d = (e) => -1 !== e.key.indexOf("q") || -1 !== e.key.indexOf("g"),
        u = (e) => {
          let r = e.val;
          const o = e.key,
            d = ((e) => {
              const i = s.length + a.length + c.join("&").length + e.length + n;
              return t - i;
            })(o);
          if (
            (i && d < r.length && d > 0 && (r = r.substr(0, d)),
            r.length || "" === e.val || "" === e.type)
          ) {
            const e = s + r + a + o;
            ((e) => {
              const n = c.join("&").length;
              return e.length + n <= t;
            })(e) && c.push(e);
          }
        };
      return (
        e &&
          e.length &&
          ((r = e.filter((e) => d(e))),
          (o = e.filter((e) => !d(e))),
          r.concat(o).forEach((e) => {
            u(e);
          })),
        c
      );
    };
  var Pa =
    (this && this.__awaiter) ||
    function (e, t, n, i) {
      return new (n || (n = Promise))(function (r, o) {
        function s(e) {
          try {
            c(i.next(e));
          } catch (e) {
            o(e);
          }
        }
        function a(e) {
          try {
            c(i.throw(e));
          } catch (e) {
            o(e);
          }
        }
        function c(e) {
          var t;
          e.done
            ? r(e.value)
            : ((t = e.value),
              t instanceof n
                ? t
                : new n(function (e) {
                    e(t);
                  })).then(s, a);
        }
        c((i = i.apply(e, t || [])).next());
      });
    };
  const Va = (e) => Math.round(e / 1048576) < 2 * Math.round(Na() / 1048576),
    Na = () => {
      var e;
      const t = _i.getWindow().performance;
      return (
        (null === (e = null == t ? void 0 : t.memory) || void 0 === e
          ? void 0
          : e.jsHeapSizeLimit) || 1073741824
      );
    },
    ka = () =>
      Pa(void 0, void 0, void 0, function* () {
        const e = (yield Pa(void 0, void 0, void 0, function* () {
          let e = !1;
          try {
            if (at.getAggregator().request("browser").browserIs("c")) {
              const t = (yield navigator.storage.estimate()).quota || 0;
              e = Va(t);
            }
          } catch (e) {}
          return e;
        }))
          ? "1"
          : "0";
        at.getAggregator().trigger("addOutputItem", { output: e }, "igt");
      }),
    Fa = function () {
      "use strict";
      return {
        isApplicable: function (e) {
          const t = _i.getWindow();
          return !(!t.navigator || !t.navigator.plugins);
        },
        start: function (e) {
          const t = _i.getWindow(),
            n = La(t.navigator.plugins),
            i = n.hash();
          var r, o;
          if (
            ((r = i.join(".")),
            at
              .getAggregator()
              .trigger("addOutputItem", { output: r }, "pl", {
                type: "impression",
              }),
            i.length)
          ) {
            const e = n.decode(i);
            (o = e.join(".")),
              at
                .getAggregator()
                .trigger("addOutputItem", { output: o }, "pd", { type: "a" });
          }
        },
      };
    },
    Ra = function (e, t) {
      "use strict";
      return {
        start: function () {
          try {
            const n = ja(),
              i = n.getMethodName(e),
              r = new On(t.getEnabledScriptUrl(e) || "");
            new Ua(
              (function () {
                const e = _i.getDoc();
                return e.body || e.head || e.documentElement;
              })(),
              r
            ).getWindow()[i] = n.getMethod(t);
          } catch (e) {
            at.getAggregator().trigger("error", "H");
          }
        },
      };
    },
    ja = function () {
      "use strict";
      const e = function (e, t, n) {
          e === (oe.adTag && oe.adTag.asid) &&
            (n.unshift(t), at.getAggregator().trigger.apply(null, n));
        },
        t = {
          DT_CODES: { SCA: "s", XSCA: "xs" },
          DT_SLOT: { FF_EXP: "xsca" },
          ERROR_CODES: { SCA: "X", XSCA: "Z" },
        };
      return {
        getMethod: function (n) {
          return function (i) {
            const r = {
              asid: oe.adTag && oe.adTag.asid,
              constant: t,
              features: n,
              context: Xn,
              dtBaseURL: oe.baseUrls.dtBaseUrl,
              spg: qa,
            };
            "function" == typeof i && i(e, r);
          };
        },
        getMethodName: function (e) {
          return "register_" + e;
        },
      };
    },
    _a = function () {
      "use strict";
      return {
        start: function (e, t) {
          e.forEach(function (e) {
            t.getEnabledScriptUrl(e) && Ra(e, t).start();
          });
        },
      };
    },
    La = function (e) {
      "use strict";
      const t = function (e) {
        return e.filename.replace(/\.plugin$/, "");
      };
      return {
        hash: function () {
          let n = 0;
          const i = e.length,
            r = [];
          let o, s, a;
          for (; n < i; n++)
            (s = t(e[n])),
              (a = Xi.hashCode(s)),
              (o = tt(a, 62).slice(-4)),
              r.push(o);
          return r;
        },
        decode: function (n) {
          const i = _i.floor(_i.random() * n.length),
            r = encodeURIComponent(t(e[i]));
          return [n[i], r];
        },
      };
    },
    Ua = function (t, n) {
      "use strict";
      let i;
      return (
        (function (n) {
          (i = oi.createHiddenIframe()),
            i.setAttribute(
              "src",
              oe.trustedTypesPolicy.createScriptURL("about:blank")
            ),
            i.setAttribute("class", "_ntnrjf7826-hj"),
            i.setAttribute("tabindex", "-1");
          (t || e.contextNode.parentNode).appendChild(i);
          const r = (function (e) {
              return e.contentWindow.document;
            })(i),
            o = [
              "<head></head>",
              '<body onload="',
              "var d = document;",
              "var s = d.createElement('script');",
              "d.getElementsByTagName('head')[0].",
              "appendChild(s).src",
              "='" + n + "'\">",
            ].join("");
          r.open().write(oe.trustedTypesPolicy.createHTML(o)), r.close();
        })(n),
        {
          getWindow: function () {
            return i.contentWindow;
          },
        }
      );
    },
    qa = function (e) {
      "use strict";
      const t = new Qt();
      t.listen(
        function (t) {
          return (
            t &&
            t.scaInfoOriginatorASID &&
            t.scaInfoOriginatorASID !== (oe.adTag && oe.adTag.asid) &&
            t.cache &&
            e.allExpectedKeysPresent(t.cache)
          );
        },
        function (n, i) {
          t.stop(),
            _i.setTimeout(function () {
              e.isDtCallAlreadySent() ||
                (at
                  .getAggregator()
                  .trigger(
                    "addThrottledProp",
                    "sca",
                    "spg",
                    i.scaInfoOriginatorASID
                  ),
                Object.keys(i.cache).forEach(function (t) {
                  e.addToCache(t, i.cache[t]);
                }));
            }, _i.round(1e3 * _i.random()));
        }
      ),
        at.getAggregator().on("addToSpg", function (t, n) {
          e.addToCache(n, t),
            e.isFull() &&
              (e.sendToOtherTags(),
              _i.setTimeout(e.sendToOtherTags, 1300),
              _i.setTimeout(e.sendToOtherTags, 3200));
        });
    },
    Wa = {
      name: "spg",
      dependencies: ["spgCache"],
      creator: qa,
      settings: {
        tier: 4,
        applies: function (e) {
          "use strict";
          return e.on("spg");
        },
      },
    },
    Ba = {
      name: "spgCache",
      dependencies: [],
      creator: function () {
        "use strict";
        const e = ["asp", "ch", "fsc", "mvn", "no", "sd"],
          t = {};
        let n = !1;
        const i = function (t) {
            return Object.keys(t).sort().toString() === e.toString();
          },
          r = function () {
            return i(t);
          };
        return {
          allExpectedKeysPresent: i,
          isDtCallAlreadySent: function () {
            return n;
          },
          addToCache: function (e, i) {
            i && i.output && !r() && (t[e] = i),
              r() &&
                (n ||
                  ((n = !0),
                  Object.keys(t).forEach(function (e) {
                    at.getAggregator().trigger("addOutputItem", t[e], e, {
                      type: "s",
                      minDt: !0,
                      sendOnce: !0,
                    });
                  }),
                  at.getAggregator().trigger("sendMinDt", "s")));
          },
          isFull: r,
          sendToOtherTags: function () {
            new Kt().send({
              scaInfoOriginatorASID: oe.adTag && oe.adTag.asid,
              cache: t,
            });
          },
        };
      },
      settings: {},
    },
    Ga = function () {
      const e = [
        At,
        wt,
        It,
        or,
        er,
        tr,
        Qi,
        ir,
        nr,
        Ki,
        wa,
        Aa,
        Dn,
        kr,
        rs,
        Ba,
        Wa,
      ];
      for (let t = 0; t < e.length; t += 1) {
        const n = e[t];
        at(n.name, n.dependencies, n.creator, n.settings);
      }
    },
    Ha = new RegExp("^(ft|ftias)_?.*_(\\d+)$"),
    $a = "?iasend?",
    za = ({ aggregator: e, ftInstance: t, macros: n }) => {
      try {
        const i = (({ ftInstance: e, macros: t }) => {
          const n = Object.keys(t),
            i = n.map((e) => `${e}=${t[e]}`).join("&") + $a;
          let r = e.replaceMacros(i);
          const o = r.indexOf($a);
          return (
            o > 0 && (r = r.substring(0, o)),
            r.split("&").reduce((e, t) => {
              const i = t.split("="),
                r = i ? i[0] : void 0,
                o = i ? i[1] : void 0;
              return r && n.includes(r) && r && o && (e[r] = o), e;
            }, {})
          );
        })({ ftInstance: t, macros: n });
        for (const [t, n] of Object.entries(i)) {
          const i =
            "string" == typeof n ? n : "number" == typeof n ? n.toString() : n;
          e.trigger("addOutputItem", { output: i }, t, {
            type: "as",
            standalone: !0,
          });
        }
        Object.keys(i).length > 0 && e.trigger("sendDt", "as");
      } catch (e) {}
    },
    Xa = ({
      checkInterval: e,
      collectorTimeout: t,
      aggregator: n,
      macros: i,
      contextNode: r,
      scopedWindow: o,
    }) => {
      const s = _i.setInterval(() => {
        const e = (({ contextNode: e, scopedWindow: t }) => {
          var n;
          const i =
            null ===
              (n =
                null == e
                  ? void 0
                  : e.getAttribute("data-ias-callback".toString())) ||
            void 0 === n
              ? void 0
              : n.match(Ha);
          if (!i || i.length < 3) return;
          const r = i[2],
            o = t ? t[`ft${r}`] : null;
          return o && "function" == typeof o.replaceMacros ? o : void 0;
        })({ contextNode: r, scopedWindow: o });
        e &&
          (_i.clearInterval(s),
          za({ aggregator: n, ftInstance: e, macros: i }));
      }, e);
      _i.setTimeout(() => {
        _i.clearInterval(s);
      }, t);
    };
  class Ya {
    constructor({
      macros: e,
      collectorTimeout: t,
      checkInterval: n,
      aggregator: i,
      scopedWindow: r,
    }) {
      (this.macros = {}),
        (this.collectorTimeout = 5e3),
        (this.checkInterval = 500),
        (this.aggregator = at.getAggregator()),
        (this.collectorTimeout = null != t ? t : this.collectorTimeout),
        (this.checkInterval = null != n ? n : this.checkInterval),
        (this.aggregator = i || this.aggregator),
        (this.scopedWindow =
          r || ("undefined" != typeof window ? window : void 0)),
        (this.macros = e || this.macros);
    }
    applies({ contextNode: e, features: t }) {
      var n;
      const i = null != this.scopedWindow,
        r = null != t && 1 == t.on("ftPostRedirectMacros"),
        o =
          null != e &&
          null != e.getAttribute("data-ias-callback".toString()) &&
          Ha.test(
            null !==
              (n =
                null == e
                  ? void 0
                  : e.getAttribute("data-ias-callback".toString())) &&
              void 0 !== n
              ? n
              : ""
          );
      return !!(i && r && o);
    }
    start({ contextNode: e }) {
      this.aggregator.on("impressionsent", () => {
        Xa({
          checkInterval: this.checkInterval,
          collectorTimeout: this.collectorTimeout,
          aggregator: this.aggregator,
          macros: this.macros,
          contextNode: e,
          scopedWindow: this.scopedWindow,
        });
      });
    }
  }
  class Ja {
    constructor({
      contextNode: e,
      features: t,
      bootstrapper: n,
      macroCollector: i,
    }) {
      (this.contextNode = e),
        (this.features = t),
        (this.macroCollectors = i || [new Ya({ macros: n.ftMacros })]);
    }
    start() {
      for (const e of this.macroCollectors)
        e.applies({ contextNode: this.contextNode, features: this.features }) &&
          e.start({ contextNode: this.contextNode });
    }
  }
  const Qa = (e) => {
    try {
      new Ka(e);
    } catch (e) {}
  };
  class Ka {
    constructor(e) {
      (this.context = e),
        (this.extractSignalsTriggered = !1),
        at.getAggregator().on("startViewabilityLoop", () => {
          this.extractSignalsTriggered ||
            ((this.extractSignalsTriggered = !0),
            _i.setTimeout(() => {
              this.extractSignals();
            }, 250));
        });
    }
    extractSignals() {
      const e = this.detectEngine();
      this.executeDomlessSafeFunctions(),
        this.context.isDomless() || this.executeDomDependentFunctions(e);
    }
    executeDomlessSafeFunctions() {
      try {
        ec();
      } catch (e) {}
    }
    executeDomDependentFunctions(e) {
      try {
        Za(e);
      } catch (e) {}
    }
    detectEngine() {
      return sc(this.context.isDomless());
    }
  }
  const Za = (e) => {
      const t = [() => oc(e), dc, lc, pc, uc, ac, gc, mc, fc, hc];
      ("b" !== e && "e" !== e && "o" !== e) || t.push(Tc), t.push(Oc, Ec, Dc);
      const n = (e) => {
        if (e >= t.length) return;
        const i = t[e];
        if (i)
          try {
            i();
          } catch (e) {}
        _i.setTimeout(() => n(e + 1), 10);
      };
      n(0);
    },
    ec = () => {
      cc();
    },
    tc = function (e, t) {
      at.getAggregator().trigger("addThrottledProp", "sca", e, t);
    },
    nc = (e, t) => {
      try {
        const n = Object.getOwnPropertyDescriptor(e, t);
        return !!n && "function" == typeof n.get;
      } catch (e) {
        return !1;
      }
    },
    ic = (e, t) => {
      try {
        const n = (e) => {
            try {
              return void Date.prototype.getYear.call(e);
            } catch (e) {
              let t = e.message + "";
              t = t.replace(/\r?\n/g, "");
              const n = t.indexOf("function");
              return -1 !== n ? t.substring(n).trim() : t.trim();
            }
          },
          i = n(function () {
            return !0;
          });
        if (!((null == i ? void 0 : i.includes("RANDOM_STRING")) || !1)) {
          let n = Function.prototype.toString.call(e);
          return (n = n.replace(/\r?\n/g, "")), !t.test(n);
        }
        const r = n(e);
        return !(!r || t.test(r));
      } catch (e) {
        return !1;
      }
    },
    rc = (e) => e.replace(/[^A-Za-z0-9\-._~/|+*%]/g, ""),
    oc = (e) => {
      try {
        let t, n;
        const i = Error.prepareStackTrace,
          r = () => {
            let e = !1,
              r = !1;
            try {
              (t = new Error()),
                Object.defineProperty(t, "stack", {
                  configurable: !1,
                  enumerable: !1,
                  get: () => ((e = !0), ""),
                });
              try {
                (Error.prepareStackTrace = function () {
                  return (r = !0), "";
                }),
                  (Error.stackTraceLimit = 0),
                  (n = new Error()),
                  console.debug(t, n);
              } catch (e) {
              } finally {
                (Error.prepareStackTrace = i), (Error.stackTraceLimit = 10);
              }
            } catch (e) {}
            return { cdpDetected: e, cdpUpdatedDetected: r };
          },
          o = () => {
            try {
              throw new Error("");
            } catch (e) {
              return (e.stack + "").includes("*");
            }
          },
          s = {};
        if ("g" !== e) {
          const { cdpDetected: e, cdpUpdatedDetected: t } = r();
          e && (s.cdp = Ke(!0)),
            t && (s.ndp = Ke(!0)),
            (e || t) && tc("bdp", Ze(s).toION());
        }
        "g" === e && o() && ((s.rdp = Ke(!0)), tc("bdp", Ze(s).toION()));
      } catch (e) {}
    },
    sc = (e) => {
      var t, n, i, r, o;
      let s;
      if (e) s = "d";
      else {
        s = "u";
        try {
          const e = _i.getWindow(),
            a = _i.getDoc();
          s = Ye(a.documentMode)
            ? "t"
            : Ye(e.netscape) && "MozAppearance" in a.documentElement.style
            ? "g"
            : Ye(e.opera) ||
              Ye(e.opr) ||
              Ye(null === (t = e.chrome) || void 0 === t ? void 0 : t.search)
            ? "o"
            : Ye(e.Blob) &&
              -1 !== e.Blob.prototype.toString().indexOf("BlobPrototype")
            ? "h"
            : Ye(
                null === (n = e.external) || void 0 === n
                  ? void 0
                  : n.getHostEnvironmentValue
              ) ||
              (Ye(
                null === (i = a.documentElement) || void 0 === i
                  ? void 0
                  : i.style
              ) &&
                -1 !==
                  Object.getOwnPropertyNames(a.documentElement.style).indexOf(
                    "msHighContrastAdjust"
                  )) ||
              Ye(
                null === (r = e.speechSynthesis) || void 0 === r
                  ? void 0
                  : r.preload
              )
            ? "e"
            : (Ye(e.chrome) ||
                Ye(e.PERSISTENT) ||
                Ye(
                  null === (o = e.google) || void 0 === o ? void 0 : o.gears
                )) &&
              -1 ===
                Object.prototype.toString
                  .call(HTMLElement)
                  .indexOf("Constructor")
            ? "b"
            : "webkitAppearance" in a.documentElement.style
            ? "w"
            : "u";
        } catch (e) {
          s = "u";
        }
      }
      return tc("eng", s), s;
    },
    ac = () => {
      const e = {
        exs: (() => {
          let e = "";
          try {
            (e = "" + _i.getWindow().external),
              (e = "" === e ? "empty" : e.replace(/[[\]\s]/g, "")),
              (e = rc(e.substring(0, 50)));
          } catch (t) {
            e = "err";
          }
          return e;
        })(),
      };
      tc("exr", Ze(e).toION());
    },
    cc = () => {
      const e = {
        lts: (() => {
          try {
            const e = new Date(),
              t = e.getFullYear().toString(),
              n = ("0" + (e.getMonth() + 1)).slice(-2),
              i = ("0" + e.getDate()).slice(-2),
              r = ("0" + e.getHours()).slice(-2),
              o = ("0" + e.getMinutes()).slice(-2);
            return `${t}-${n}-${i}${r}.${o}.${("0" + e.getSeconds()).slice(
              -2
            )}`;
          } catch (e) {
            return "err";
          }
        })(),
        tzo: (() => {
          try {
            return new Date().getTimezoneOffset();
          } catch (e) {
            return -1;
          }
        })(),
        tzn: (() => {
          try {
            return rc(Intl.DateTimeFormat().resolvedOptions().timeZone);
          } catch (e) {
            return "err";
          }
        })(),
      };
      tc("tss", Ze(e).toION());
    },
    dc = () => {
      const e = {
        ori: Ke(
          (() => {
            let e = !1;
            try {
              e = Ye(_i.getWindow().orientation);
            } catch (t) {
              e = !1;
            }
            return e;
          })()
        ),
        ges: Ke(
          (() => {
            let e = !1;
            try {
              const t = _i.getWindow();
              e = Ye(t.GestureEvent);
            } catch (t) {
              e = !1;
            }
            return e;
          })()
        ),
        tch: Ke(
          (() => {
            let e = !1;
            try {
              e =
                Ye(_i.getWindow().ontouchstart) || navigator.maxTouchPoints > 1;
            } catch (t) {
              e = !1;
            }
            return e;
          })()
        ),
      };
      tc("mob", Ze(e).toION());
    },
    uc = () => {
      const e = _i.getWindow(),
        t = [
          {
            key: "not",
            check: () => !(!e.Notification && !e.webkitNotifications),
          },
          {
            key: "csi",
            check: () => {
              var t;
              return !!(null === (t = e.chrome) || void 0 === t
                ? void 0
                : t.csi);
            },
          },
          { key: "msl", check: () => !!navigator.msLaunchUri },
          { key: "hdl", check: () => !!e.HTMLDataListElement },
          { key: "aps", check: () => !!e.ApplePaySession },
          { key: "hae", check: () => !!e.HTMLAudioElement },
          { key: "ito", check: () => !!e.IntersectionObserver },
          { key: "sec", check: () => !!e.isSecureContext },
          {
            key: "pha",
            check: () => !(!e.callPhantom && !e._phantom),
            sendIfTrue: !0,
          },
          {
            key: "plr",
            check: () => !(!e.__pwInitScripts && !e.__playwright__binding__),
            sendIfTrue: !0,
          },
        ],
        n = {};
      for (const { key: e, check: i, sendIfTrue: r } of t)
        try {
          const t = i();
          if (r && !t) continue;
          n[e] = Ke(t);
        } catch (t) {
          n[e] = Ke(!1);
        }
      tc("prp", Ze(n).toION());
    },
    lc = () => {
      try {
        const e = () => {
            try {
              const e = Object.getOwnPropertyDescriptor(
                Navigator.prototype,
                "appName"
              );
              return !(!e || !e.get) && (e.get.call(navigator), !1);
            } catch (e) {
              return !0;
            }
          },
          t = {};
        navigator !== clientInformation && (t.nci = String(Ke(!0))),
          e() && (t.anc = String(Ke(!0))),
          (function (e) {
            try {
              return Date.prototype.getFullYear.call(e), !0;
            } catch (e) {
              return !!e.stack.includes("Proxy.getFullYear");
            }
          })(navigator) && (t.npx = String(Ke(!0))),
          Object.keys(t).length > 0 && tc("nic", Ze(t).toION());
      } catch (e) {}
    },
    gc = () => {
      var e;
      let t,
        n = !1;
      try {
        const i =
            null === (e = _i.getTop()) || void 0 === e ? void 0 : e.document,
          r = Object.getOwnPropertyDescriptor(i, "referrer");
        r &&
          "function" == typeof r.get &&
          ((n = !0),
          (t = r.get
            .toString()
            .replace(/[\n\r]/g, "")
            .substring(0, 50)),
          (t = rc(t)));
      } catch (e) {
        n = !1;
      }
      const i = {};
      n && ((i.tam = String(Ke(n))), t && (i.ref = t)),
        Object.keys(i).length > 0 && tc("ret", Ze(i).toION());
    },
    mc = () => {
      try {
        const e = _i.getDoc(),
          t = nc(e, "visibilityState"),
          n = nc(e, "hidden");
        let i = !1;
        if ("undefined" != typeof IntersectionObserverEntry) {
          const e = Object.getOwnPropertyDescriptor(
            IntersectionObserverEntry.prototype,
            "isIntersecting"
          );
          if (e && "function" == typeof e.get) {
            const t = /isIntersecting\s*\(\)\s*\{\s*\[native\s+code\]\s*\}/;
            i = ic(e.get, t);
          }
        }
        const r = {};
        t && (r.vis = String(Ke(t))),
          n && (r.hid = String(Ke(n))),
          i && (r.itt = String(Ke(i))),
          Object.keys(r).length > 0 && tc("viw", Ze(r).toION());
      } catch (e) {}
    },
    pc = () => {
      try {
        const e = () => {
            try {
              const e = Object.getOwnPropertyDescriptor(
                Navigator.prototype,
                "webdriver"
              );
              if (e && "function" == typeof e.get) {
                const t =
                  /^function\s+(?:get\s+)?webdriver\(\)\s*{\s*\[native code\]\s*}$/;
                return ic(e.get, t);
              }
              return !1;
            } catch (e) {
              return !1;
            }
          },
          t = {};
        (() => {
          try {
            return navigator.hasOwnProperty("webdriver");
          } catch (e) {
            return !1;
          }
        })() && (t.wop = String(Ke(!0))),
          e() && (t.wgt = String(Ke(!0))),
          Object.keys(t).length > 0 && tc("wdt", Ze(t).toION());
      } catch (e) {}
    },
    hc = () => {
      try {
        const e = "ias-sb-10px",
          t = (t) => {
            var n;
            let i = null;
            try {
              const r =
                null === (n = _i.getTopmostAccessibleWindow()) || void 0 === n
                  ? void 0
                  : n.document;
              if (!r) return null;
              const o = r.createElement("style");
              (o.textContent =
                "." + e + "::-webkit-scrollbar { width: 10px !important; }"),
                (r.head || r.documentElement).appendChild(o);
              const s = r.createElement("div");
              s.classList.add(e);
              const a = {
                left: "-10000px",
                top: "-10000px",
                width: "100px",
                height: "20px",
                visibility: "hidden",
              };
              t && (a.overflow = "scroll"), Jn.styleElement(s, a);
              const c = r.createElement("div"),
                d = { width: "100%", height: "1000px" };
              Jn.styleElement(c, d), s.appendChild(c), r.body.appendChild(s);
              const u = s.offsetWidth,
                l = s.clientWidth;
              ot(u) && ot(l) && (i = u - l),
                s.parentNode && s.parentNode.removeChild(s),
                o.parentNode && o.parentNode.removeChild(o);
            } catch (e) {}
            return i;
          },
          n = t(!0),
          i = t(!1);
        if (ot(n) || ot(i)) {
          const e = { wit: ot(n) ? n : "na", wot: ot(i) ? i : "na" };
          tc("dvw", Ze(e).toION());
        }
      } catch (e) {}
    },
    fc = () => {
      let e = 0,
        t = 0;
      try {
        let n = _i.getWindow();
        const i = _i.getTop();
        do {
          if (!n) break;
          if (n === i) break;
          const r = n.parent;
          e += 1;
          try {
            r.document;
          } catch (e) {
            t += 1;
          }
          n = r;
        } while (e < 20);
      } catch (n) {
        (e = -2), (t = -2);
      }
      tc("ifr", Ze({ act: e, eff: t }).toION());
    },
    vc = ["brands", "mobile", "platform"];
  function yc(e, t) {
    return Object.prototype.hasOwnProperty.call(e, t);
  }
  function bc(e) {
    return null == e ? "" : rc(String(e));
  }
  function wc(e) {
    return Object.keys(e)
      .sort()
      .map((t) => `${bc(t)}~${bc(e[t])}`)
      .join("~");
  }
  function Ac(e) {
    return Array.isArray(e)
      ? (function (e) {
          return e
            .map((e) => (e && "object" == typeof e ? wc(e) : bc(e)))
            .join("/");
        })(e)
      : e && "object" == typeof e
      ? wc(e)
      : bc(e);
  }
  function Ic(e) {
    return vc.every((t) => {
      return (
        !yc(e, t) ||
        null == (n = e[t]) ||
        "" === n ||
        (!!Array.isArray(n) && 0 === n.length)
      );
      var n;
    });
  }
  function Sc() {
    const e = _i.getWindow().navigator.userAgentData;
    if (e)
      return (function (e) {
        if (Je(e.toJSON)) return e.toJSON();
        const t = {};
        return (
          vc.forEach((n) => {
            yc(e, n) && (t[n] = e[n]);
          }),
          t
        );
      })(e);
  }
  function Tc() {
    const e = Sc();
    if (!e) return;
    const t = {},
      n =
        ((i = e),
        vc
          .filter((e) => yc(i, e))
          .map((e) => `${e}~${Ac(i[e])}`)
          .join("|"));
    var i;
    n && (t.uad = n),
      Ic(e) && (t.ent = String(Ke(!0))),
      Object.keys(t).length > 0 && tc("uai", Ze(t).toION());
  }
  const Cc = (e) =>
      new Promise((t) => {
        var n;
        try {
          const i =
            null === (n = e.Notification) || void 0 === n
              ? void 0
              : n.permission;
          t(null != i ? i : "na");
        } catch (e) {
          t("na");
        }
      }),
    Oc = () => {
      const e = _i.getWindow();
      (null == e ? void 0 : e.isSecureContext) &&
        Promise.all([
          new Promise((e) => {
            navigator.permissions && Je(navigator.permissions.query)
              ? navigator.permissions
                  .query({ name: "notifications" })
                  .then((t) => e(t.state))
                  .catch(() => e("na"))
              : e("na");
          }),
          Cc(e),
        ])
          .then(([e, t]) => {
            tc("nit", Ze({ pqr: e, ntr: t }).toION());
          })
          .catch(() => {});
    },
    Ec = () => {
      try {
        const e = _i.getDoc();
        if (!e) return;
        const t = ((e) => {
          const t = { probably: 2, maybe: 1, "": 0 },
            n = e.createElement("video");
          return [
            'video/mp4;codecs="avc1.42E01E, mp4a.40.2"',
            'video/mp4;codecs="avc1.58A01E, mp4a.40.2"',
            'video/mp4;codecs="avc1.4D401E, mp4a.40.2"',
            'video/mp4;codecs="avc1.64001E, mp4a.40.2"',
            'video/mp4;codecs="mp4v.20.8, mp4a.40.2"',
            'video/mp4;codecs="mp4v.20.240, mp4a.40.2"',
            'video/3gpp;codecs="mp4v.20.8, samr"',
            'video/ogg;codecs="theora, vorbis"',
            'video/ogg;codecs="theora, speex"',
            "audio/ogg;codecs=vorbis",
            "audio/ogg;codecs=speex",
            "audio/ogg;codecs=flac",
            'video/ogg;codecs="dirac, vorbis"',
            'video/x-matroska;codecs="theora, vorbis"',
            'video/mp4; codecs="avc1.42E01E"',
            'audio/mp4; codecs="mp4a.40.2"',
            'audio/mpeg;codecs="mp3"',
            'video/webm; codecs="vorbis,vp8"',
          ].map((e) => {
            var i;
            const r = n.canPlayType(e);
            return null !== (i = t[r]) && void 0 !== i ? i : 0;
          });
        })(e);
        tc("cdc", Ze(t).toION());
      } catch (e) {}
    },
    Dc = () => {
      try {
        if (void 0 === window.speechSynthesis) return;
        let e = 0,
          t = 0,
          n = 0,
          i = !1,
          r = !1,
          o = !1;
        const s = window.speechSynthesis,
          a = (o, s = !1) => {
            if (o.length > 0) {
              const a = new Set();
              (t = o.filter((e) => !e.localService).length),
                (i = o.some((e) => e.name.includes("Chrome OS"))),
                (e = o.length),
                o.forEach((e) => a.add(e.lang)),
                (n = a.size),
                (r = s),
                c();
            }
          },
          c = () => {
            if (o) return;
            (o = !0), (s.onvoiceschanged = null);
            const a = { vct: e, rct: t, lct: n, cos: Ke(i), evt: Ke(r) };
            tc("spc", Ze(a).toION());
          },
          d = (e = !1) => {
            const t = s.getVoices();
            (t.length > 0 || e) && a(t, e);
          };
        d(),
          0 === e &&
            ((s.onvoiceschanged = () => d(!0)),
            _i.setTimeout(() => {
              o || d(!0);
            }, 3e3));
      } catch (e) {}
    };
  try {
    !(function () {
      "use strict";
      try {
        (() => {
          const t = Xn.isDomless(),
            n = _i.getWindow(),
            i = new re({
              contextNodeElement: null == e ? void 0 : e.contextNode,
            });
          oe.addModel(i);
          const r = new ee({
            isDomless: t,
            currentWindow: n,
            defaultBootstrapperConfig: e,
          });
          oe.addModel(r);
          const o = new l();
          oe.addModel(o);
          const s = r.isStaticFrameInFrame
              ? new re({
                  contextNodeElement: null == e ? void 0 : e.currentScript,
                })
              : i,
            a = new K({ isDomless: t, contextNode: s, measurementConfig: r });
          oe.addModel(a);
          const u = new I({ contextNode: s, adTag: a });
          oe.addModel(u);
          const g = new no();
          oe.addModel(g);
          const p = new Z({ bootstrapper: e });
          oe.addModel(p);
          const h = new Tt();
          oe.addModel(h);
          const f = new d({ currentWindow: n });
          oe.addModel(f);
          const v = new c();
          oe.addModel(v);
          const y = new m({
            windowObj: n,
            now: () => Xn.getTagTime(),
            enabled: Boolean(o.useSingleEvent && r.isStaticMode),
            isDomless: t,
          });
          oe.addModel(y), y.init();
        })();
      } catch (e) {}
      e.perf.markStart(ct),
        oe.measurementConfig.set(
          "mainBirthdate",
          oe.measurementConfig.birthdate
            ? new Date().getTime() - oe.measurementConfig.birthdate
            : -1
        ),
        Ga(),
        at.startSystem();
      const t = at.getAggregator();
      t.provide({ omidAdSessionContext: {} }),
        t.provide({ omidAdSessionVerificationParameters: {} }),
        oe.measurementConfig.isResolved && t.provide("features", ui()),
        t.provide("browser", new Vn().createInstance());
      const n = t.provide("ancestorOrigins", Mn());
      t.provide("pageUrls", new Bi().createInstance(n, _i));
      const i = si(),
        r = Fi(),
        o = new Fn().createInstance(i, r),
        s = new yi();
      t.provide({ mErrors: i, mJsonp: r, mComm: o, ids: s });
      const a = __IASOmidVerificationClient;
      t.provide({ omidVerificationClient: a });
      const u = [
        { environment: qr(a), adSessionReadyStrategy: Qr(a) },
        { environment: Kr(), adSessionReadyStrategy: eo() },
      ];
      new Jr(u).resolve().adSessionReadyStrategy.start(), e.perf.markEnd(ct);
    })();
  } catch (t) {
    __IntegralASDiagnosticCall("main", t, e);
  }
};
try {
  !(function () {
    var e = __IntegralASConfig.useFIF ? __IASScope.parent : __IASScope;
    try {
      (top.__IntegralASAdPush = function (t) {
        (t || (top.isSingleIASInstance && top.iasAdSlots)).forEach(function (
          t
        ) {
          (__IntegralASConfig._cl_adpath = t.adSelector),
            (__IntegralASConfig.iasParameters = t.iasParameters),
            __IntegralASConfig.initialize(__IntegralASConfig, e, e.document);
        });
      }),
        top.isSingleIASInstance && top.iasAdSlots
          ? top.__IntegralASAdPush()
          : __IntegralASConfig.initialize(__IntegralASConfig, e, e.document);
    } catch (t) {
      __IntegralASConfig.initialize(__IntegralASConfig, e, e.document);
    }
  })();
} catch (e) {
  __IntegralASDiagnosticCall("initialize", e, __IntegralASConfig);
}
