var ftInsert = {
    version: "0.0.9",
    config: {
      placement: {
        id: 11266281,
        name: "Web_Wi mIAS_23October26_LANDCROS_Group A - Italy_IT_English_B_DSP_DSPbanner_300x250",
      },
      campaign: {
        id: 335759,
        name: "Outbound DJIB LANDCROS Display October 2026",
        servedByDomain: "https://servedby.flashtalking.com",
        logsplitBucket: 1,
        isMobileEnhanced: false,
        cookielessAdServing: {
          authenticatedIdentities: [
            {
              id: 1,
              name: "LiveRamp ID",
              isPersonalizationEnabled: false,
              isMeasurementEnabled: false,
            },
          ],
          probabilisticIdentities: [
            {
              id: 3,
              name: "Flashtalking Cookieless ID",
              isPersonalizationEnabled: false,
              isMeasurementEnabled: false,
            },
            {
              id: 4,
              name: "Flashtalking Household ID",
              isPersonalizationEnabled: false,
              isMeasurementEnabled: false,
            },
          ],
          standardIdentities: [
            {
              id: -1,
              name: "Cookie ID",
              isPersonalizationEnabled: true,
              isMeasurementEnabled: true,
            },
          ],
        },
      },
      campaignSite: { id: 680743, site: { id: 23680, name: "MiQ - Global" } },
      impressions: [],
      surveys: [],
      mutations: [],
    },
    ins: document.currentScript.parentNode,
    isFtInsert: function (t) {
      var e = !1;
      return (e =
        this.ins &&
        "ins" === this.ins.tagName.toLowerCase() &&
        this.ins.dataset.placementId &&
        "" !== this.ins.dataset.placementId
          ? !0
          : e);
    },
    go: async function () {
      this.isFtInsert() &&
        ((this.data = Object.assign({}, this.ins.dataset)),
        (this.data.ft_referrer =
          this.data.ft_referrer || this.getReferrer(this.data.ft_referrer)),
        (this.data.ftRandom = self.crypto
          .randomUUID()
          .replace(/-/g, "")
          .substring(0, 10)),
        this.setInsAttributes(),
        this.appendMraid(),
        this.requestImpression());
    },
    getReferrer: function () {
      let t;
      if (window == top) t = window.location.href;
      else {
        try {
          t = window.parent.location.href;
        } catch (t) {}
        t = t || document.referrer;
      }
      return (t =
        1e3 < encodeURIComponent(t).length
          ? encodeURIComponent(t).substring(0, 1e3)
          : t);
    },
    setInsAttributes: function () {
      this.ins.classList.add("flashtalking_ads"),
        (this.ins.dataset.state = "pre-impression"),
        this.ins.setAttribute(
          "id",
          "flashtalking_insert_" + this.data.placementId
        ),
        (this.ins.style.display = "inline-block"),
        (this.ins.style.height = this.data.placementHeight + "px"),
        (this.ins.style.width = this.data.placementWidth + "px");
    },
    appendMraid: function () {
      "1" === this.data.mraidEnabled &&
        ((this.data.ft_agentEnv = 1), this.addElement("script", "mraid.js"));
    },
    encodeClick: function (t = "", e = 0) {
      return (
        0 < (e = +e) && (t = encodeURIComponent(t)),
        (t = 1 < e ? encodeURIComponent(t) : t)
      );
    },
    requestImpression: async function () {
      let n = this,
        t = [
          "expandTracking",
          "ftOba",
          "networkConversionMeta",
          "ftX",
          "ftY",
          "ftZ",
          "ftContentWidth",
          "mraidEnabled",
          "clickEncoding",
          "ftClick",
        ],
        e = [
          "impressionBase",
          "placementId",
          "placementHeight",
          "placementWidth",
          "oobClickTrack",
          "ftPartnerIdentityId",
          "mraidEnabled",
          "placementType",
          "siteName",
          "placementName",
          "expandTracking",
          "renderingMode",
        ],
        a = {
          ftClick: "ftClick",
          networkConversionMeta: "ft_custom",
          ftX: "ftx",
          ftY: "fty",
          ftZ: "ftadz",
          ftContentWidth: "ftscw",
          expandTracking: "ftExpTrack",
        },
        i = [],
        d = [],
        s = `${n.config.campaign.servedByDomain}/imp/${n.config.campaign.logsplitBucket}/`;
      if (
        (n.config.mutations &&
          0 < n.config.mutations.length &&
          (n.populateSettings(n.data),
          n.config.mutations.forEach(function (e) {
            try {
              new Function(e).apply(n);
            } catch (t) {
              console.log("Unsupported Mutation will not be executed"),
                console.log("Mutation code: ", e),
                console.log(t),
                n.completedMutationCount++;
            }
          })),
        await n.haveAllMutationsCompleted(n.config.mutations?.length || "yes"),
        (window["ftClick_" + this.data.placementId] = this.data.ftClick =
          this.data.ftClick || this.data.ftclick || ""),
        (n.data.renderingMode = n.data.renderingMode || "jsappend"),
        (n.data.renderingMode = n.verify("renderingMode", n.data.renderingMode)
          ? n.data.renderingMode
          : i.push(
              `Rendering Mode: "${n.data.renderingMode}" is not supported`
            )),
        (s += `${n.config.campaign.id};${n.data.placementId};201;${n.data.renderingMode};${n.config.campaignSite.site.id};${n.data.placementId}/`),
        (n.data.ft_agentEnv = n.data.ft_agentEnv || 0),
        (this.data.ftClick = this.encodeClick(
          this.data.ftClick,
          this.data.clickEncoding
        )),
        delete this.data.ftclick,
        n.data.gdpr &&
          /gdpr=/.test(n.data.gdpr) &&
          (n.data.gdpr = n.data.gdpr.replace("gdpr=", "")),
        n.data.gdpr_consent &&
          /gdpr_consent=/.test(n.data.gdpr_consent) &&
          (n.data.gdpr_consent = n.data.gdpr_consent.replace(
            "gdpr_consent=",
            ""
          )),
        n.data.gpp &&
          /gpp=/.test(n.data.gpp) &&
          (n.data.gpp = n.data.gpp.replace("gpp=", "")),
        n.data.gpp_sid &&
          /gpp_sid=/.test(n.data.gpp_sid) &&
          (n.data.gpp_sid = n.data.gpp_sid.replace("gpp_sid=", "")),
        0 <
          n.config.campaign.cookielessAdServing?.probabilisticIdentities
            ?.length)
      ) {
        let e = !1,
          a = !1;
        var o;
        n.config.campaign.cookielessAdServing.probabilisticIdentities.forEach(
          function (t) {
            "Flashtalking Cookieless ID" === t.name &&
              (e = t.isPersonalizationEnabled),
              "Flashtalking Household ID" === t.name &&
                (a = t.isPersonalizationEnabled);
          }
        ),
          (e || a) &&
            ((o = await n.getFtrackId()) ? (n.data.fts = o) : (n.data.cas = 0));
      }
      for (var r in ("jsiframe" !== n.data.renderingMode
        ? delete n.data.expandTracking
        : (n.data.expandTracking = encodeURIComponent(n.data.expandTracking)),
      n.data.targetingLocation &&
        (d.push("MII_IP=" + n.data.targetingLocation),
        delete n.data.targetingLocation),
      n.data.targetingTime &&
        (d.push("virtualDateTime=" + n.data.targetingTime),
        delete n.data.targetingTime),
      n.data))
        t.includes(r) || e.includes(r)
          ? Object.keys(a).includes(r) && d.push(a[r] + "=" + n.data[r])
          : d.push(r + "=" + encodeURIComponent(n.data[r]));
      if (
        (n.data.hasOwnProperty("ftOba") &&
          0 < n.data.ftOba.length &&
          (n.verify("oba", n.data.ftOba)
            ? d.push("ftOBA=" + +n.data.ftOba)
            : i.push(`OBA value: "${n.data.ftOba}" is not supported`)),
        n.data.hasOwnProperty("oobClickTrack") &&
          0 < n.data.oobClickTrack.length &&
          n.data.placementHeight &&
          n.data.placementWidth &&
          d.push(
            `ft${n.data.placementWidth}x${n.data.placementHeight}_OOBclickTrack=` +
              n.data.oobClickTrack
          ),
        d.push("cachebuster=" + n.data.ftRandom),
        0 < d.length && (s += "?" + d.join("&")),
        0 !== i.length)
      )
        throw new Error(i.join("; "));
      "jsiframe" === n.data.renderingMode
        ? n.addElement(
            "iframe",
            s,
            "ft_servedby_" + n.data.placementId,
            "ft_servedby_" + n.data.placementId
          )
        : n.addElement(
            "script",
            s,
            "ft_servedby_" + n.data.placementId,
            "ft_servedby_" + n.data.placementId
          );
    },
    verify: function (t, e) {
      var a = !1;
      switch (t) {
        case "renderingMode":
          ["jsappend", "jsiframe"].includes(e) && (a = !0);
          break;
        case "placementType":
          ["script", "async", "iframe"].includes(e) && (a = !0);
          break;
        case "oba":
          "number" == typeof (e = +e) && -1 < e && e < 2 && (a = !0);
      }
      return a;
    },
    addElement: function (t, e, a, n, i) {
      var d = this,
        s = document.createElement(t);
      (s.src = e),
        a && s.setAttribute("id", a),
        n && s.setAttribute("name", n),
        i && s.setAttribute("class", i),
        "iframe" === t &&
          ((s.style.height = d.data.placementHeight + "px"),
          (s.style.width = d.data.placementWidth + "px"),
          s.setAttribute("width", d.data.placementWidth),
          s.setAttribute("height", d.data.placementHeight),
          s.setAttribute("frameborder", 0),
          s.setAttribute("margin", 0),
          s.setAttribute("allowtransparency", !0),
          s.setAttribute("allowfullscreen", ""),
          s.setAttribute("scrolling", "no")),
        this.ins.appendChild(s);
    },
    getFtrackId: async function () {
      let a = this,
        n = "d9-core-3f4f3476-b53a-4039-b585-9ac99c6a1f31",
        i = document.querySelector("#" + n),
        d;
      return new Promise(function (e, t) {
        i
          ? (d = function () {
              window.d9api ? e(window.d9api()) : window.setTimeout(d, 50);
            })()
          : ((i = document.createElement("script")).setAttribute("id", n),
            i.setAttribute("src", "https://d9.flashtalking.com/d9core"),
            (i.dataset.d9PlacementId = a.config.placement.id),
            i.addEventListener("load", function () {
              e(window.d9api());
            }),
            i.addEventListener("error", function (t) {
              (window.d9api = function () {
                return console.warn("D9 could not be loaded"), null;
              }),
                e(window.d9api());
            }),
            document.body.appendChild(i));
      });
    },
    populateSettings: function (t) {
      var e,
        a = this,
        n = {
          pID: a.config.placement.id,
          width: a.data.placementHeight,
          height: a.data.placementHeight,
        };
      for (e in n) n.hasOwnProperty(e) && n[e] && (settings[e] = n[e]);
    },
    completedMutationCount: 0,
    haveAllMutationsCompleted: function (n) {
      return (
        (ftInsert.mutationPollCount = ftInsert.mutationPollCount || 0),
        new Promise((t, e) => {
          ("yes" !== n && 0 !== n) || t();
          function a() {
            (ftInsert.mutationPollCount += 100),
              n <= ftInsert.completedMutationCount ||
              ftInsert.mutationPollCount >= settings.DTimeout
                ? t()
                : window.setTimeout(a, 100);
          }
          a();
        })
      );
    },
  },
  settings = {
    params: { cachebuster: 1e6 * Math.random() },
    winVars: {},
    DTimeout: 1e3,
    GTimeout: 1e3,
  },
  callback = function (t) {
    if (!(t instanceof Event)) {
      let e, a, n, i, d;
      t.forEach((t) => {
        if (t.p || t.v) {
          for (
            a = t.p,
              e = t.hasOwnProperty("n") && t.n ? t.n + ":" + t.v : t.v,
              n = t.hasOwnProperty("e") ? t.e : 1,
              i = t.hasOwnProperty("m") && "o" === t.m ? "overwrite" : "append",
              d = t.t && "w" === t.t ? window : ftInsert.data;
            n;

          )
            (e = encodeURIComponent(e)), n--;
          "append" == i &&
            (e = (d.hasOwnProperty(a) && d[a] ? d[a] + ";" : "") + e),
            (d[a] = e);
        }
      }),
        ftInsert.completedMutationCount++;
    }
  };
ftInsert.go();
