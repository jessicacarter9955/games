var EquativVerificationScript;
(() => {
  var __webpack_modules__ = {
      488: function (__unused_webpack_module, exports, __webpack_require__) {
        !(function (e, o, t) {
          if ("object" == typeof t && "string" != typeof t.nodeName) o(e, t);
          else {
            t = {};
            var i = ["1.5.0-dev"];
            function n(e) {
              for (var o in e) e.hasOwnProperty(o) && (e[o] = n(e[o]));
              return Object.freeze(e);
            }
            for (var m in (o(e, t), t))
              t.hasOwnProperty(m) &&
                (null == Object.getOwnPropertyDescriptor(e, m) &&
                  Object.defineProperty(e, m, { value: {} }),
                i.forEach(function (o) {
                  if (null == Object.getOwnPropertyDescriptor(e[m], o)) {
                    var i = n(t[m]);
                    Object.defineProperty(e[m], o, {
                      get: function () {
                        return i;
                      },
                      enumerable: !0,
                    });
                  }
                }));
          }
        })(
          void 0 === __webpack_require__.g ? this : __webpack_require__.g,
          function (omidGlobal, omidExports) {
            var $jscomp = $jscomp || {};
            ($jscomp.scope = {}),
              ($jscomp.createTemplateTagFirstArg = function (e) {
                return (e.raw = e);
              }),
              ($jscomp.createTemplateTagFirstArgWithRaw = function (e, o) {
                return (e.raw = o), e;
              }),
              ($jscomp.arrayIteratorImpl = function (e) {
                var o = 0;
                return function () {
                  return o < e.length
                    ? { done: !1, value: e[o++] }
                    : { done: !0 };
                };
              }),
              ($jscomp.arrayIterator = function (e) {
                return { next: $jscomp.arrayIteratorImpl(e) };
              }),
              ($jscomp.makeIterator = function (e) {
                var o =
                  "undefined" != typeof Symbol &&
                  Symbol.iterator &&
                  e[Symbol.iterator];
                if (o) return o.call(e);
                if ("number" == typeof e.length)
                  return $jscomp.arrayIterator(e);
                throw Error(String(e) + " is not an iterable or ArrayLike");
              }),
              ($jscomp.arrayFromIterator = function (e) {
                for (var o, t = []; !(o = e.next()).done; ) t.push(o.value);
                return t;
              }),
              ($jscomp.arrayFromIterable = function (e) {
                return e instanceof Array
                  ? e
                  : $jscomp.arrayFromIterator($jscomp.makeIterator(e));
              }),
              ($jscomp.ASSUME_ES5 = !1),
              ($jscomp.ASSUME_NO_NATIVE_MAP = !1),
              ($jscomp.ASSUME_NO_NATIVE_SET = !1),
              ($jscomp.SIMPLE_FROUND_POLYFILL = !1),
              ($jscomp.ISOLATE_POLYFILLS = !1),
              ($jscomp.FORCE_POLYFILL_PROMISE = !1),
              ($jscomp.FORCE_POLYFILL_PROMISE_WHEN_NO_UNHANDLED_REJECTION = !1),
              ($jscomp.objectCreate =
                $jscomp.ASSUME_ES5 || "function" == typeof Object.create
                  ? Object.create
                  : function (e) {
                      var o = function () {};
                      return (o.prototype = e), new o();
                    }),
              ($jscomp.defineProperty =
                $jscomp.ASSUME_ES5 ||
                "function" == typeof Object.defineProperties
                  ? Object.defineProperty
                  : function (e, o, t) {
                      return (
                        e == Array.prototype ||
                          e == Object.prototype ||
                          (e[o] = t.value),
                        e
                      );
                    }),
              ($jscomp.getGlobal = function (e) {
                e = [
                  "object" == typeof globalThis && globalThis,
                  e,
                  "object" == typeof window && window,
                  "object" == typeof self && self,
                  "object" == typeof __webpack_require__.g &&
                    __webpack_require__.g,
                ];
                for (var o = 0; o < e.length; ++o) {
                  var t = e[o];
                  if (t && t.Math == Math) return t;
                }
                throw Error("Cannot find global object");
              }),
              ($jscomp.global = $jscomp.getGlobal(this)),
              ($jscomp.IS_SYMBOL_NATIVE =
                "function" == typeof Symbol && "symbol" == typeof Symbol("x")),
              ($jscomp.TRUST_ES6_POLYFILLS =
                !$jscomp.ISOLATE_POLYFILLS || $jscomp.IS_SYMBOL_NATIVE),
              ($jscomp.polyfills = {}),
              ($jscomp.propertyToPolyfillSymbol = {}),
              ($jscomp.POLYFILL_PREFIX = "$jscp$");
            var $jscomp$lookupPolyfilledValue = function (e, o, t) {
              if (!t || null != e)
                return null == (t = $jscomp.propertyToPolyfillSymbol[o])
                  ? e[o]
                  : void 0 !== (t = e[t])
                  ? t
                  : e[o];
            };
            ($jscomp.polyfill = function (e, o, t, i) {
              o &&
                ($jscomp.ISOLATE_POLYFILLS
                  ? $jscomp.polyfillIsolated(e, o, t, i)
                  : $jscomp.polyfillUnisolated(e, o, t, i));
            }),
              ($jscomp.polyfillUnisolated = function (e, o, t, i) {
                for (
                  t = $jscomp.global, e = e.split("."), i = 0;
                  i < e.length - 1;
                  i++
                ) {
                  var n = e[i];
                  if (!(n in t)) return;
                  t = t[n];
                }
                (o = o((i = t[(e = e[e.length - 1])]))) != i &&
                  null != o &&
                  $jscomp.defineProperty(t, e, {
                    configurable: !0,
                    writable: !0,
                    value: o,
                  });
              }),
              ($jscomp.polyfillIsolated = function (e, o, t, i) {
                var n = e.split(".");
                (e = 1 === n.length),
                  (i = n[0]),
                  (i =
                    !e && i in $jscomp.polyfills
                      ? $jscomp.polyfills
                      : $jscomp.global);
                for (var m = 0; m < n.length - 1; m++) {
                  var r = n[m];
                  if (!(r in i)) return;
                  i = i[r];
                }
                (n = n[n.length - 1]),
                  null !=
                    (o = o(
                      (t =
                        $jscomp.IS_SYMBOL_NATIVE && "es6" === t ? i[n] : null)
                    )) &&
                    (e
                      ? $jscomp.defineProperty($jscomp.polyfills, n, {
                          configurable: !0,
                          writable: !0,
                          value: o,
                        })
                      : o !== t &&
                        (void 0 === $jscomp.propertyToPolyfillSymbol[n] &&
                          ((t = (1e9 * Math.random()) >>> 0),
                          ($jscomp.propertyToPolyfillSymbol[n] =
                            $jscomp.IS_SYMBOL_NATIVE
                              ? $jscomp.global.Symbol(n)
                              : $jscomp.POLYFILL_PREFIX + t + "$" + n)),
                        $jscomp.defineProperty(
                          i,
                          $jscomp.propertyToPolyfillSymbol[n],
                          { configurable: !0, writable: !0, value: o }
                        )));
              }),
              ($jscomp.getConstructImplementation = function () {
                if (
                  $jscomp.TRUST_ES6_POLYFILLS &&
                  "undefined" != typeof Reflect &&
                  Reflect.construct
                ) {
                  if (
                    (function () {
                      function e() {}
                      return (
                        new e(),
                        Reflect.construct(e, [], function () {}),
                        new e() instanceof e
                      );
                    })()
                  )
                    return Reflect.construct;
                  var e = Reflect.construct;
                  return function (o, t, i) {
                    return (
                      (o = e(o, t)),
                      i && Reflect.setPrototypeOf(o, i.prototype),
                      o
                    );
                  };
                }
                return function (e, o, t) {
                  return (
                    void 0 === t && (t = e),
                    (t = $jscomp.objectCreate(t.prototype || Object.prototype)),
                    Function.prototype.apply.call(e, t, o) || t
                  );
                };
              }),
              ($jscomp.construct = $jscomp.getConstructImplementation()),
              ($jscomp.underscoreProtoCanBeSet = function () {
                var e = {};
                try {
                  return (e.__proto__ = { a: !0 }), e.a;
                } catch (e) {}
                return !1;
              }),
              ($jscomp.setPrototypeOf =
                $jscomp.TRUST_ES6_POLYFILLS &&
                "function" == typeof Object.setPrototypeOf
                  ? Object.setPrototypeOf
                  : $jscomp.underscoreProtoCanBeSet()
                  ? function (e, o) {
                      if (((e.__proto__ = o), e.__proto__ !== o))
                        throw new TypeError(e + " is not extensible");
                      return e;
                    }
                  : null),
              ($jscomp.inherits = function (e, o) {
                if (
                  ((e.prototype = $jscomp.objectCreate(o.prototype)),
                  (e.prototype.constructor = e),
                  $jscomp.setPrototypeOf)
                ) {
                  var t = $jscomp.setPrototypeOf;
                  t(e, o);
                } else
                  for (t in o)
                    if ("prototype" != t)
                      if (Object.defineProperties) {
                        var i = Object.getOwnPropertyDescriptor(o, t);
                        i && Object.defineProperty(e, t, i);
                      } else e[t] = o[t];
                e.superClass_ = o.prototype;
              }),
              ($jscomp.getRestArguments = function () {
                for (
                  var e = Number(this), o = [], t = e;
                  t < arguments.length;
                  t++
                )
                  o[t - e] = arguments[t];
                return o;
              }),
              $jscomp.polyfill(
                "Reflect",
                function (e) {
                  return e || {};
                },
                "es6",
                "es3"
              ),
              $jscomp.polyfill(
                "Reflect.construct",
                function (e) {
                  return $jscomp.construct;
                },
                "es6",
                "es3"
              ),
              $jscomp.polyfill(
                "Reflect.setPrototypeOf",
                function (e) {
                  if (e) return e;
                  if ($jscomp.setPrototypeOf) {
                    var o = $jscomp.setPrototypeOf;
                    return function (e, t) {
                      try {
                        return o(e, t), !0;
                      } catch (e) {
                        return !1;
                      }
                    };
                  }
                  return null;
                },
                "es6",
                "es5"
              ),
              ($jscomp.owns = function (e, o) {
                return Object.prototype.hasOwnProperty.call(e, o);
              }),
              $jscomp.polyfill(
                "Object.values",
                function (e) {
                  return (
                    e ||
                    function (e) {
                      var o,
                        t = [];
                      for (o in e) $jscomp.owns(e, o) && t.push(e[o]);
                      return t;
                    }
                  );
                },
                "es8",
                "es3"
              );
            var module$exports$omid$common$constants = {
                AdEventType: {
                  IMPRESSION: "impression",
                  LOADED: "loaded",
                  GEOMETRY_CHANGE: "geometryChange",
                  SESSION_START: "sessionStart",
                  SESSION_ERROR: "sessionError",
                  SESSION_FINISH: "sessionFinish",
                  MEDIA: "media",
                  VIDEO: "video",
                  START: "start",
                  FIRST_QUARTILE: "firstQuartile",
                  MIDPOINT: "midpoint",
                  THIRD_QUARTILE: "thirdQuartile",
                  COMPLETE: "complete",
                  PAUSE: "pause",
                  RESUME: "resume",
                  BUFFER_START: "bufferStart",
                  BUFFER_FINISH: "bufferFinish",
                  SKIPPED: "skipped",
                  VOLUME_CHANGE: "volumeChange",
                  PLAYER_STATE_CHANGE: "playerStateChange",
                  AD_USER_INTERACTION: "adUserInteraction",
                  STATE_CHANGE: "stateChange",
                },
                MediaEventType: {
                  LOADED: "loaded",
                  START: "start",
                  FIRST_QUARTILE: "firstQuartile",
                  MIDPOINT: "midpoint",
                  THIRD_QUARTILE: "thirdQuartile",
                  COMPLETE: "complete",
                  PAUSE: "pause",
                  RESUME: "resume",
                  BUFFER_START: "bufferStart",
                  BUFFER_FINISH: "bufferFinish",
                  SKIPPED: "skipped",
                  VOLUME_CHANGE: "volumeChange",
                  PLAYER_STATE_CHANGE: "playerStateChange",
                  AD_USER_INTERACTION: "adUserInteraction",
                },
                ImpressionType: {
                  DEFINED_BY_JAVASCRIPT: "definedByJavaScript",
                  UNSPECIFIED: "unspecified",
                  LOADED: "loaded",
                  BEGIN_TO_RENDER: "beginToRender",
                  ONE_PIXEL: "onePixel",
                  VIEWABLE: "viewable",
                  AUDIBLE: "audible",
                  OTHER: "other",
                },
                ErrorType: {
                  GENERIC: "generic",
                  VIDEO: "video",
                  MEDIA: "media",
                },
                AdSessionType: {
                  NATIVE: "native",
                  HTML: "html",
                  JAVASCRIPT: "javascript",
                },
                EventOwner: {
                  NATIVE: "native",
                  JAVASCRIPT: "javascript",
                  NONE: "none",
                },
                SessionOwner: { JAVASCRIPT: "javascript", NATIVE: "native" },
                AccessMode: {
                  FULL: "full",
                  DOMAIN: "domain",
                  LIMITED: "limited",
                },
                AppState: {
                  BACKGROUNDED: "backgrounded",
                  FOREGROUNDED: "foregrounded",
                },
                DeviceLockState: { LOCKED: "locked", UNLOCKED: "unlocked" },
                Environment: { APP: "app", WEB: "web" },
                DeviceCategory: {
                  CTV: "ctv",
                  DESKTOP: "desktop",
                  MOBILE: "mobile",
                  OTHER: "other",
                },
                InteractionType: {
                  CLICK: "click",
                  INVITATION_ACCEPT: "invitationAccept",
                },
                CreativeType: {
                  DEFINED_BY_JAVASCRIPT: "definedByJavaScript",
                  HTML_DISPLAY: "htmlDisplay",
                  NATIVE_DISPLAY: "nativeDisplay",
                  VIDEO: "video",
                  AUDIO: "audio",
                },
                MediaType: { DISPLAY: "display", VIDEO: "video" },
                Reason: {
                  NOT_FOUND: "notFound",
                  HIDDEN: "hidden",
                  BACKGROUNDED: "backgrounded",
                  PICTURE_IN_PICTURE: "pictureInPicture",
                  DEVICE_LOCKED: "deviceLocked",
                  VIEWPORT: "viewport",
                  OBSTRUCTED: "obstructed",
                  CLIPPED: "clipped",
                  UNMEASURABLE: "unmeasurable",
                  NO_WINDOW_FOCUS: "noWindowFocus",
                  NO_OUTPUT_DEVICE: "noOutputDevice",
                },
                SupportedFeatures: { CONTAINER: "clid", VIDEO: "vlid" },
                VideoPosition: {
                  PREROLL: "preroll",
                  MIDROLL: "midroll",
                  POSTROLL: "postroll",
                  STANDALONE: "standalone",
                },
                VideoPlayerState: {
                  MINIMIZED: "minimized",
                  COLLAPSED: "collapsed",
                  NORMAL: "normal",
                  EXPANDED: "expanded",
                  FULLSCREEN: "fullscreen",
                },
                NativeViewKeys: {
                  X: "x",
                  LEFT: "left",
                  Y: "y",
                  TOP: "top",
                  WIDTH: "width",
                  HEIGHT: "height",
                  AD_SESSION_ID: "adSessionId",
                  IS_FRIENDLY_OBSTRUCTION_FOR: "isFriendlyObstructionFor",
                  CLIPS_TO_BOUNDS: "clipsToBounds",
                  CHILD_VIEWS: "childViews",
                  END_X: "endX",
                  END_Y: "endY",
                  OBSTRUCTIONS: "obstructions",
                  OBSTRUCTION_CLASS: "obstructionClass",
                  OBSTRUCTION_PURPOSE: "obstructionPurpose",
                  OBSTRUCTION_REASON: "obstructionReason",
                  PIXELS: "pixels",
                  HAS_WINDOW_FOCUS: "hasWindowFocus",
                },
                MeasurementStateChangeSource: {
                  CONTAINER: "container",
                  CREATIVE: "creative",
                },
                ElementMarkup: { OMID_ELEMENT_CLASS_NAME: "omid-element" },
                CommunicationType: {
                  NONE: "NONE",
                  DIRECT: "DIRECT",
                  POST_MESSAGE: "POST_MESSAGE",
                },
                OmidImplementer: { OMSDK: "omsdk" },
                MessageMethod: {
                  IDENTIFY_SERVICE_WINDOW: "identifyServiceWindow",
                },
              },
              module$contents$omid$common$InternalMessage_GUID_KEY =
                "omid_message_guid",
              module$contents$omid$common$InternalMessage_METHOD_KEY =
                "omid_message_method",
              module$contents$omid$common$InternalMessage_VERSION_KEY =
                "omid_message_version",
              module$contents$omid$common$InternalMessage_ARGS_KEY =
                "omid_message_args",
              module$exports$omid$common$InternalMessage = function (
                e,
                o,
                t,
                i
              ) {
                (this.guid = e),
                  (this.method = o),
                  (this.version = t),
                  (this.args = i);
              };
            (module$exports$omid$common$InternalMessage.isValidSerializedMessage =
              function (e) {
                return (
                  !!e &&
                  void 0 !==
                    e[module$contents$omid$common$InternalMessage_GUID_KEY] &&
                  void 0 !==
                    e[module$contents$omid$common$InternalMessage_METHOD_KEY] &&
                  void 0 !==
                    e[
                      module$contents$omid$common$InternalMessage_VERSION_KEY
                    ] &&
                  "string" ==
                    typeof e[
                      module$contents$omid$common$InternalMessage_GUID_KEY
                    ] &&
                  "string" ==
                    typeof e[
                      module$contents$omid$common$InternalMessage_METHOD_KEY
                    ] &&
                  "string" ==
                    typeof e[
                      module$contents$omid$common$InternalMessage_VERSION_KEY
                    ] &&
                  (void 0 ===
                    e[module$contents$omid$common$InternalMessage_ARGS_KEY] ||
                    void 0 !==
                      e[module$contents$omid$common$InternalMessage_ARGS_KEY])
                );
              }),
              (module$exports$omid$common$InternalMessage.deserialize =
                function (e) {
                  return new module$exports$omid$common$InternalMessage(
                    e[module$contents$omid$common$InternalMessage_GUID_KEY],
                    e[module$contents$omid$common$InternalMessage_METHOD_KEY],
                    e[module$contents$omid$common$InternalMessage_VERSION_KEY],
                    e[module$contents$omid$common$InternalMessage_ARGS_KEY]
                  );
                }),
              (module$exports$omid$common$InternalMessage.prototype.serialize =
                function () {
                  var e = {};
                  return (
                    (e[module$contents$omid$common$InternalMessage_GUID_KEY] =
                      this.guid),
                    (e[module$contents$omid$common$InternalMessage_METHOD_KEY] =
                      this.method),
                    (e[
                      module$contents$omid$common$InternalMessage_VERSION_KEY
                    ] = this.version),
                    void 0 !== this.args &&
                      (e[module$contents$omid$common$InternalMessage_ARGS_KEY] =
                        this.args),
                    e
                  );
                });
            var module$exports$omid$common$Communication = function (e) {
              (this.to = e),
                (this.communicationType_ =
                  module$exports$omid$common$constants.CommunicationType.NONE);
            };
            (module$exports$omid$common$Communication.prototype.sendMessage =
              function (e, o) {}),
              (module$exports$omid$common$Communication.prototype.handleMessage =
                function (e, o) {
                  this.onMessage && this.onMessage(e, o);
                }),
              (module$exports$omid$common$Communication.prototype.serialize =
                function (e) {
                  return JSON.stringify(e);
                }),
              (module$exports$omid$common$Communication.prototype.deserialize =
                function (e) {
                  return JSON.parse(e);
                }),
              (module$exports$omid$common$Communication.prototype.isDirectCommunication =
                function () {
                  return (
                    this.communicationType_ ===
                    module$exports$omid$common$constants.CommunicationType
                      .DIRECT
                  );
                }),
              (module$exports$omid$common$Communication.prototype.isCrossOrigin =
                function () {});
            var module$exports$omid$common$logger = {};
            function module$contents$omid$common$logger_error() {
              var e = $jscomp.getRestArguments.apply(0, arguments);
              module$contents$omid$common$logger_executeLog(
                function () {
                  throw new (Function.prototype.bind.apply(
                    Error,
                    [
                      null,
                      "Could not complete the test successfully - ",
                    ].concat($jscomp.arrayFromIterable(e))
                  ))();
                },
                function () {
                  return console.error.apply(
                    console,
                    $jscomp.arrayFromIterable(e)
                  );
                }
              );
            }
            function module$contents$omid$common$logger_debug() {
              var e = $jscomp.getRestArguments.apply(0, arguments);
              module$contents$omid$common$logger_executeLog(
                function () {},
                function () {
                  return console.error.apply(
                    console,
                    $jscomp.arrayFromIterable(e)
                  );
                }
              );
            }
            function module$contents$omid$common$logger_executeLog(e, o) {
              "undefined" != typeof jasmine && jasmine
                ? e()
                : "undefined" != typeof console &&
                  console &&
                  console.error &&
                  o();
            }
            (module$exports$omid$common$logger.error =
              module$contents$omid$common$logger_error),
              (module$exports$omid$common$logger.debug =
                module$contents$omid$common$logger_debug);
            var module$exports$omid$common$eventTypedefs = {},
              module$exports$omid$common$version = {
                ApiVersion: "1.0",
                Version: "1.5.0-dev",
              },
              module$exports$omid$common$argsChecker = {};
            function module$contents$omid$common$argsChecker_assertTruthyString(
              e,
              o
            ) {
              if (!o)
                throw Error("Value for " + e + " is undefined, null or blank.");
              if ("string" != typeof o && !(o instanceof String))
                throw Error("Value for " + e + " is not a string.");
              if ("" === o.trim())
                throw Error("Value for " + e + " is empty string.");
            }
            function module$contents$omid$common$argsChecker_assertNotNullObject(
              e,
              o
            ) {
              if (null == o)
                throw Error("Value for " + e + " is undefined or null");
            }
            function module$contents$omid$common$argsChecker_assertNumber(
              e,
              o
            ) {
              if (null == o) throw Error(e + " must not be null or undefined.");
              if ("number" != typeof o || isNaN(o))
                throw Error("Value for " + e + " is not a number");
            }
            function module$contents$omid$common$argsChecker_assertNumberBetween(
              e,
              o,
              t,
              i
            ) {
              if (
                (module$contents$omid$common$argsChecker_assertNumber(e, o),
                o < t || o > i)
              )
                throw Error(
                  "Value for " +
                    e +
                    " is outside the range [" +
                    t +
                    "," +
                    i +
                    "]"
                );
            }
            function module$contents$omid$common$argsChecker_assertFunction(
              e,
              o
            ) {
              if (!o) throw Error(e + " must not be truthy.");
            }
            function module$contents$omid$common$argsChecker_assertPositiveNumber(
              e,
              o
            ) {
              if (
                (module$contents$omid$common$argsChecker_assertNumber(e, o),
                0 > o)
              )
                throw Error(e + " must be a positive number.");
            }
            (module$exports$omid$common$argsChecker.assertTruthyString =
              module$contents$omid$common$argsChecker_assertTruthyString),
              (module$exports$omid$common$argsChecker.assertNotNullObject =
                module$contents$omid$common$argsChecker_assertNotNullObject),
              (module$exports$omid$common$argsChecker.assertNumber =
                module$contents$omid$common$argsChecker_assertNumber),
              (module$exports$omid$common$argsChecker.assertNumberBetween =
                module$contents$omid$common$argsChecker_assertNumberBetween),
              (module$exports$omid$common$argsChecker.assertFunction =
                module$contents$omid$common$argsChecker_assertFunction),
              (module$exports$omid$common$argsChecker.assertPositiveNumber =
                module$contents$omid$common$argsChecker_assertPositiveNumber);
            var module$exports$omid$common$VersionUtils = {},
              module$contents$omid$common$VersionUtils_SEMVER_DIGITS_NUMBER = 3;
            function module$contents$omid$common$VersionUtils_isValidVersion(
              e
            ) {
              return /\d+\.\d+\.\d+(-.*)?/.test(e);
            }
            function module$contents$omid$common$VersionUtils_versionGreaterOrEqual(
              e,
              o
            ) {
              (e = e.split("-")[0].split(".")),
                (o = o.split("-")[0].split("."));
              for (
                var t = 0;
                t <
                module$contents$omid$common$VersionUtils_SEMVER_DIGITS_NUMBER;
                t++
              ) {
                var i = parseInt(e[t], 10),
                  n = parseInt(o[t], 10);
                if (i > n) break;
                if (i < n) return !1;
              }
              return !0;
            }
            (module$exports$omid$common$VersionUtils.isValidVersion =
              module$contents$omid$common$VersionUtils_isValidVersion),
              (module$exports$omid$common$VersionUtils.versionGreaterOrEqual =
                module$contents$omid$common$VersionUtils_versionGreaterOrEqual);
            var module$exports$omid$common$ArgsSerDe = {},
              module$contents$omid$common$ArgsSerDe_ARGS_NOT_SERIALIZED_VERSION =
                "1.0.3";
            function module$contents$omid$common$ArgsSerDe_serializeMessageArgs(
              e,
              o
            ) {
              return module$contents$omid$common$VersionUtils_isValidVersion(
                e
              ) &&
                module$contents$omid$common$VersionUtils_versionGreaterOrEqual(
                  e,
                  module$contents$omid$common$ArgsSerDe_ARGS_NOT_SERIALIZED_VERSION
                )
                ? o
                : JSON.stringify(o);
            }
            function module$contents$omid$common$ArgsSerDe_deserializeMessageArgs(
              e,
              o
            ) {
              return module$contents$omid$common$VersionUtils_isValidVersion(
                e
              ) &&
                module$contents$omid$common$VersionUtils_versionGreaterOrEqual(
                  e,
                  module$contents$omid$common$ArgsSerDe_ARGS_NOT_SERIALIZED_VERSION
                )
                ? o || []
                : o && "string" == typeof o
                ? JSON.parse(o)
                : [];
            }
            (module$exports$omid$common$ArgsSerDe.serializeMessageArgs =
              module$contents$omid$common$ArgsSerDe_serializeMessageArgs),
              (module$exports$omid$common$ArgsSerDe.deserializeMessageArgs =
                module$contents$omid$common$ArgsSerDe_deserializeMessageArgs);
            var module$exports$omid$common$guid = {};
            function module$contents$omid$common$guid_generateGuid() {
              return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(
                /[xy]/g,
                function (e) {
                  var o = (16 * Math.random()) | 0;
                  return "y" === e
                    ? ((3 & o) | 8).toString(16)
                    : o.toString(16);
                }
              );
            }
            module$exports$omid$common$guid.generateGuid =
              module$contents$omid$common$guid_generateGuid;
            var module$exports$omid$common$DetectOmid = {
              OMID_PRESENT_FRAME_NAME: "omid_v1_present",
              OMID_PRESENT_FRAME_NAME_WEB: "omid_v1_present_web",
              OMID_PRESENT_FRAME_NAME_APP: "omid_v1_present_app",
              getEnvironmentIframeName: function (e) {
                var o = {};
                return ((o[
                  module$exports$omid$common$constants.Environment.APP
                ] =
                  module$exports$omid$common$DetectOmid.OMID_PRESENT_FRAME_NAME_APP),
                (o[module$exports$omid$common$constants.Environment.WEB] =
                  module$exports$omid$common$DetectOmid.OMID_PRESENT_FRAME_NAME_WEB),
                o)[e];
              },
            };
            function module$contents$omid$common$DetectOmid_isIframePresent(
              e,
              o
            ) {
              try {
                return e.frames && !!e.frames[o];
              } catch (e) {
                return !1;
              }
            }
            function module$contents$omid$common$DetectOmid_writePresenceIframe_(
              e,
              o
            ) {
              e.document.write(
                '<iframe style="display:none" id="' +
                  o +
                  '" name="' +
                  o +
                  '" sandbox></iframe>'
              );
            }
            (module$exports$omid$common$DetectOmid.isOmidPresent = function (
              e
            ) {
              return [
                module$exports$omid$common$DetectOmid.OMID_PRESENT_FRAME_NAME,
                module$exports$omid$common$DetectOmid.OMID_PRESENT_FRAME_NAME_WEB,
                module$exports$omid$common$DetectOmid.OMID_PRESENT_FRAME_NAME_APP,
              ].some(function (o) {
                return module$contents$omid$common$DetectOmid_isIframePresent(
                  e,
                  o
                );
              });
            }),
              (module$exports$omid$common$DetectOmid.getOmidEnvironment =
                function (e) {
                  for (
                    var o = $jscomp.makeIterator(
                        Object.values(
                          module$exports$omid$common$constants.Environment
                        )
                      ),
                      t = o.next();
                    !t.done;
                    t = o.next()
                  )
                    if (
                      ((t = t.value),
                      module$contents$omid$common$DetectOmid_isIframePresent(
                        e,
                        module$exports$omid$common$DetectOmid.getEnvironmentIframeName(
                          t
                        )
                      ))
                    )
                      return t;
                  return null;
                }),
              (module$exports$omid$common$DetectOmid.declareOmidPresence =
                function (e, o) {
                  e.frames &&
                    e.document &&
                    ![
                      module$exports$omid$common$DetectOmid.OMID_PRESENT_FRAME_NAME,
                      module$exports$omid$common$DetectOmid.OMID_PRESENT_FRAME_NAME_WEB,
                      module$exports$omid$common$DetectOmid.OMID_PRESENT_FRAME_NAME_APP,
                    ].some(function (o) {
                      return !!e.frames[o];
                    }) &&
                    (null == e.document.body &&
                    module$exports$omid$common$DetectOmid.isMutationObserverAvailable_(
                      e
                    )
                      ? module$exports$omid$common$DetectOmid.registerMutationObserver_(
                          e,
                          o
                        )
                      : ((o =
                          module$exports$omid$common$DetectOmid.getEnvironmentIframeName(
                            o
                          )),
                        e.document.body
                          ? (module$exports$omid$common$DetectOmid.appendPresenceIframe_(
                              e,
                              module$exports$omid$common$DetectOmid.OMID_PRESENT_FRAME_NAME
                            ),
                            module$exports$omid$common$DetectOmid.appendPresenceIframe_(
                              e,
                              o
                            ))
                          : (module$contents$omid$common$DetectOmid_writePresenceIframe_(
                              e,
                              module$exports$omid$common$DetectOmid.OMID_PRESENT_FRAME_NAME
                            ),
                            module$contents$omid$common$DetectOmid_writePresenceIframe_(
                              e,
                              o
                            ))));
                }),
              (module$exports$omid$common$DetectOmid.appendPresenceIframe_ =
                function (e, o) {
                  var t = e.document.createElement("iframe");
                  (t.id = o),
                    (t.name = o),
                    (t.style.display = "none"),
                    (t.sandbox = ""),
                    e.document.body.appendChild(t);
                }),
              (module$exports$omid$common$DetectOmid.isMutationObserverAvailable_ =
                function (e) {
                  return "MutationObserver" in e;
                }),
              (module$exports$omid$common$DetectOmid.registerMutationObserver_ =
                function (e, o) {
                  var t = new MutationObserver(function (i) {
                    i.forEach(function (i) {
                      "BODY" === i.addedNodes[0].nodeName &&
                        ((i =
                          module$exports$omid$common$DetectOmid.getEnvironmentIframeName(
                            o
                          )),
                        module$exports$omid$common$DetectOmid.appendPresenceIframe_(
                          e,
                          module$exports$omid$common$DetectOmid.OMID_PRESENT_FRAME_NAME
                        ),
                        module$exports$omid$common$DetectOmid.appendPresenceIframe_(
                          e,
                          i
                        ),
                        t.disconnect());
                    });
                  });
                  t.observe(e.document.documentElement, { childList: !0 });
                });
            var module$exports$omid$common$serviceMethodUtils = {},
              module$contents$omid$common$serviceMethodUtils_ServiceMethodPrefix =
                {
                  SESSION_SERVICE: "SessionService.",
                  VERIFICATION_SERVICE: "VerificationService.",
                };
            function module$contents$omid$common$serviceMethodUtils_getPrefixedSessionServiceMethod(
              e
            ) {
              return module$contents$omid$common$serviceMethodUtils_getPrefixedMethod(
                e,
                module$contents$omid$common$serviceMethodUtils_ServiceMethodPrefix.SESSION_SERVICE
              );
            }
            function module$contents$omid$common$serviceMethodUtils_getUnprefixedSessionServiceMethod(
              e
            ) {
              return module$contents$omid$common$serviceMethodUtils_getUnprefixedMethod(
                e,
                module$contents$omid$common$serviceMethodUtils_ServiceMethodPrefix.SESSION_SERVICE
              );
            }
            function module$contents$omid$common$serviceMethodUtils_isPrefixedSessionServiceMethod(
              e
            ) {
              return (
                null !=
                module$contents$omid$common$serviceMethodUtils_getUnprefixedSessionServiceMethod(
                  e
                )
              );
            }
            function module$contents$omid$common$serviceMethodUtils_getPrefixedVerificationServiceMethod(
              e
            ) {
              return module$contents$omid$common$serviceMethodUtils_getPrefixedMethod(
                e,
                module$contents$omid$common$serviceMethodUtils_ServiceMethodPrefix.VERIFICATION_SERVICE
              );
            }
            function module$contents$omid$common$serviceMethodUtils_getUnprefixedVerificationServiceMethod(
              e
            ) {
              return module$contents$omid$common$serviceMethodUtils_getUnprefixedMethod(
                e,
                module$contents$omid$common$serviceMethodUtils_ServiceMethodPrefix.VERIFICATION_SERVICE
              );
            }
            function module$contents$omid$common$serviceMethodUtils_isPrefixedVerificationServiceMethod(
              e
            ) {
              return (
                null !=
                module$contents$omid$common$serviceMethodUtils_getUnprefixedVerificationServiceMethod(
                  e
                )
              );
            }
            function module$contents$omid$common$serviceMethodUtils_getPrefixedMethod(
              e,
              o
            ) {
              return o + e;
            }
            function module$contents$omid$common$serviceMethodUtils_getUnprefixedMethod(
              e,
              o
            ) {
              return (e = e.match(new RegExp("^" + o + "(.*)"))) && e[1];
            }
            (module$exports$omid$common$serviceMethodUtils.getPrefixedSessionServiceMethod =
              module$contents$omid$common$serviceMethodUtils_getPrefixedSessionServiceMethod),
              (module$exports$omid$common$serviceMethodUtils.getPrefixedVerificationServiceMethod =
                module$contents$omid$common$serviceMethodUtils_getPrefixedVerificationServiceMethod),
              (module$exports$omid$common$serviceMethodUtils.getUnprefixedSessionServiceMethod =
                module$contents$omid$common$serviceMethodUtils_getUnprefixedSessionServiceMethod),
              (module$exports$omid$common$serviceMethodUtils.getUnprefixedVerificationServiceMethod =
                module$contents$omid$common$serviceMethodUtils_getUnprefixedVerificationServiceMethod),
              (module$exports$omid$common$serviceMethodUtils.isPrefixedSessionServiceMethod =
                module$contents$omid$common$serviceMethodUtils_isPrefixedSessionServiceMethod),
              (module$exports$omid$common$serviceMethodUtils.isPrefixedVerificationServiceMethod =
                module$contents$omid$common$serviceMethodUtils_isPrefixedVerificationServiceMethod);
            var module$exports$omid$common$OmidGlobalProvider = {};
            function module$contents$omid$common$OmidGlobalProvider_getOmidGlobal() {
              if (void 0 !== omidGlobal && omidGlobal) return omidGlobal;
              if (void 0 !== __webpack_require__.g && __webpack_require__.g)
                return __webpack_require__.g;
              if ("undefined" != typeof window && window) return window;
              if ("undefined" != typeof globalThis && globalThis)
                return globalThis;
              var e = Function("return this")();
              if (e) return e;
              throw Error("Could not determine global object context.");
            }
            module$exports$omid$common$OmidGlobalProvider.omidGlobal =
              module$contents$omid$common$OmidGlobalProvider_getOmidGlobal();
            var module$exports$omid$common$exporter = {};
            function module$contents$omid$common$exporter_getOmidExports() {
              return void 0 === omidExports ? null : omidExports;
            }
            function module$contents$omid$common$exporter_getOrCreateName(
              e,
              o
            ) {
              return e && (e[o] || (e[o] = {}));
            }
            function module$contents$omid$common$exporter_packageExport(
              e,
              o,
              t
            ) {
              (t =
                void 0 === t
                  ? module$contents$omid$common$exporter_getOmidExports()
                  : t) &&
                ((e = e.split("."))
                  .slice(0, e.length - 1)
                  .reduce(
                    module$contents$omid$common$exporter_getOrCreateName,
                    t
                  )[e[e.length - 1]] = o);
            }
            module$exports$omid$common$exporter.packageExport =
              module$contents$omid$common$exporter_packageExport;
            var module$exports$omid$common$windowUtils = {};
            function module$contents$omid$common$windowUtils_isValidWindow(e) {
              return null != e && void 0 !== e.top && null != e.top;
            }
            function module$contents$omid$common$windowUtils_isCrossOrigin(e) {
              if (
                e === module$exports$omid$common$OmidGlobalProvider.omidGlobal
              )
                return !1;
              try {
                if (void 0 === e.location.hostname) return !0;
                module$contents$omid$common$windowUtils_isSameOriginForIE(e);
              } catch (e) {
                return !0;
              }
              return !1;
            }
            function module$contents$omid$common$windowUtils_isSameOriginForIE(
              e
            ) {
              return "" === e.x || "" !== e.x;
            }
            function module$contents$omid$common$windowUtils_resolveGlobalContext(
              e
            ) {
              return (
                void 0 === e &&
                  "undefined" != typeof window &&
                  window &&
                  (e = window),
                module$contents$omid$common$windowUtils_isValidWindow(e)
                  ? e
                  : module$exports$omid$common$OmidGlobalProvider.omidGlobal
              );
            }
            function module$contents$omid$common$windowUtils_resolveTopWindowContext(
              e
            ) {
              return module$contents$omid$common$windowUtils_isValidWindow(e)
                ? e.top
                : module$exports$omid$common$OmidGlobalProvider.omidGlobal;
            }
            function module$contents$omid$common$windowUtils_isTopWindowAccessible(
              e
            ) {
              try {
                return !!e.top.location.href;
              } catch (e) {
                return !1;
              }
            }
            function module$contents$omid$common$windowUtils_removeDomElements(
              e
            ) {
              return (
                e.type ===
                  module$exports$omid$common$constants.AdEventType
                    .SESSION_START &&
                  (void 0 !== e.data.context.videoElement &&
                    (e.data.context.videoElement =
                      "Video Element (" + e.data.context.videoElement.id + ")"),
                  void 0 !== e.data.context.slotElement &&
                    (e.data.context.slotElement =
                      "Slot Element (" + e.data.context.slotElement.id + ")")),
                e
              );
            }
            function module$contents$omid$common$windowUtils_evaluatePageUrl(
              e
            ) {
              if (!module$contents$omid$common$windowUtils_isValidWindow(e))
                return null;
              try {
                var o = e.top;
                return module$contents$omid$common$windowUtils_isCrossOrigin(o)
                  ? null
                  : o.location.href;
              } catch (e) {
                return null;
              }
            }
            (module$exports$omid$common$windowUtils.evaluatePageUrl =
              module$contents$omid$common$windowUtils_evaluatePageUrl),
              (module$exports$omid$common$windowUtils.isCrossOrigin =
                module$contents$omid$common$windowUtils_isCrossOrigin),
              (module$exports$omid$common$windowUtils.removeDomElements =
                module$contents$omid$common$windowUtils_removeDomElements),
              (module$exports$omid$common$windowUtils.resolveGlobalContext =
                module$contents$omid$common$windowUtils_resolveGlobalContext),
              (module$exports$omid$common$windowUtils.resolveTopWindowContext =
                module$contents$omid$common$windowUtils_resolveTopWindowContext),
              (module$exports$omid$common$windowUtils.isTopWindowAccessible =
                module$contents$omid$common$windowUtils_isTopWindowAccessible);
            var module$exports$omid$common$DirectCommunication = function (e) {
              module$exports$omid$common$Communication.call(this, e),
                (this.communicationType_ =
                  module$exports$omid$common$constants.CommunicationType.DIRECT),
                (this.handleExportedMessage =
                  module$exports$omid$common$DirectCommunication.prototype.handleExportedMessage.bind(
                    this
                  ));
            };
            $jscomp.inherits(
              module$exports$omid$common$DirectCommunication,
              module$exports$omid$common$Communication
            ),
              (module$exports$omid$common$DirectCommunication.prototype.sendMessage =
                function (e, o) {
                  if (!(o = void 0 === o ? this.to : o))
                    throw Error(
                      "Message destination must be defined at construction time or when sending the message."
                    );
                  o.handleExportedMessage(e.serialize(), this);
                }),
              (module$exports$omid$common$DirectCommunication.prototype.handleExportedMessage =
                function (e, o) {
                  module$exports$omid$common$InternalMessage.isValidSerializedMessage(
                    e
                  ) &&
                    this.handleMessage(
                      module$exports$omid$common$InternalMessage.deserialize(e),
                      o
                    );
                }),
              (module$exports$omid$common$DirectCommunication.prototype.isCrossOrigin =
                function () {
                  return !1;
                });
            var module$exports$omid$common$PostMessageCommunication = function (
              e,
              o
            ) {
              (o =
                void 0 === o
                  ? module$exports$omid$common$OmidGlobalProvider.omidGlobal
                  : o),
                module$exports$omid$common$Communication.call(this, o);
              var t = this;
              (this.communicationType_ =
                module$exports$omid$common$constants.CommunicationType.POST_MESSAGE),
                e.addEventListener("message", function (e) {
                  if ("object" == typeof e.data) {
                    var o = e.data;
                    module$exports$omid$common$InternalMessage.isValidSerializedMessage(
                      o
                    ) &&
                      ((o =
                        module$exports$omid$common$InternalMessage.deserialize(
                          o
                        )),
                      e.source && t.handleMessage(o, e.source));
                  }
                });
            };
            $jscomp.inherits(
              module$exports$omid$common$PostMessageCommunication,
              module$exports$omid$common$Communication
            ),
              (module$exports$omid$common$PostMessageCommunication.isCompatibleContext =
                function (e) {
                  return !!(e && e.addEventListener && e.postMessage);
                }),
              (module$exports$omid$common$PostMessageCommunication.prototype.sendMessage =
                function (e, o) {
                  if (!(o = void 0 === o ? this.to : o))
                    throw Error(
                      "Message destination must be defined at construction time or when sending the message."
                    );
                  o.postMessage(e.serialize(), "*");
                }),
              (module$exports$omid$common$PostMessageCommunication.prototype.isCrossOrigin =
                function () {
                  return (
                    !this.to ||
                    module$contents$omid$common$windowUtils_isCrossOrigin(
                      this.to
                    )
                  );
                });
            var module$exports$omid$common$serviceCommunication = {},
              module$contents$omid$common$serviceCommunication_EXPORTED_SESSION_COMMUNICATION_NAME =
                ["omid", "v1_SessionServiceCommunication"],
              module$contents$omid$common$serviceCommunication_EXPORTED_VERIFICATION_COMMUNICATION_NAME =
                ["omid", "v1_VerificationServiceCommunication"],
              module$contents$omid$common$serviceCommunication_EXPORTED_SERVICE_WINDOW_NAME =
                ["omidVerificationProperties", "serviceWindow"];
            function module$contents$omid$common$serviceCommunication_getValueForKeypath(
              e,
              o
            ) {
              return o.reduce(function (e, o) {
                return e && e[o];
              }, e);
            }
            function module$contents$omid$common$serviceCommunication_startServiceCommunication(
              e,
              o,
              t,
              i
            ) {
              if (!module$contents$omid$common$windowUtils_isCrossOrigin(o))
                try {
                  var n =
                    module$contents$omid$common$serviceCommunication_getValueForKeypath(
                      o,
                      t
                    );
                  if (n)
                    return new module$exports$omid$common$DirectCommunication(
                      n
                    );
                } catch (e) {}
              return i(o)
                ? new module$exports$omid$common$PostMessageCommunication(e, o)
                : null;
            }
            function module$contents$omid$common$serviceCommunication_startServiceCommunicationFromCandidates(
              e,
              o,
              t,
              i
            ) {
              for (
                var n = (o = $jscomp.makeIterator(o)).next();
                !n.done;
                n = o.next()
              )
                if (
                  (n =
                    module$contents$omid$common$serviceCommunication_startServiceCommunication(
                      e,
                      n.value,
                      t,
                      i
                    ))
                )
                  return n;
              return null;
            }
            function module$contents$omid$common$serviceCommunication_startSessionServiceCommunication(
              e,
              o,
              t
            ) {
              t =
                void 0 === t
                  ? module$exports$omid$common$DetectOmid.isOmidPresent
                  : t;
              var i = [
                e,
                module$contents$omid$common$windowUtils_resolveTopWindowContext(
                  e
                ),
              ];
              return (
                o && i.unshift(o),
                module$contents$omid$common$serviceCommunication_startServiceCommunicationFromCandidates(
                  e,
                  i,
                  module$contents$omid$common$serviceCommunication_EXPORTED_SESSION_COMMUNICATION_NAME,
                  t
                )
              );
            }
            function module$contents$omid$common$serviceCommunication_startVerificationServiceCommunication(
              e,
              o
            ) {
              o =
                void 0 === o
                  ? module$exports$omid$common$DetectOmid.isOmidPresent
                  : o;
              var t = [],
                i =
                  module$contents$omid$common$serviceCommunication_getValueForKeypath(
                    e,
                    module$contents$omid$common$serviceCommunication_EXPORTED_SERVICE_WINDOW_NAME
                  );
              return (
                i && t.push(i),
                t.push(
                  module$contents$omid$common$windowUtils_resolveTopWindowContext(
                    e
                  )
                ),
                module$contents$omid$common$serviceCommunication_startServiceCommunicationFromCandidates(
                  e,
                  t,
                  module$contents$omid$common$serviceCommunication_EXPORTED_VERIFICATION_COMMUNICATION_NAME,
                  o
                )
              );
            }
            (module$exports$omid$common$serviceCommunication.startSessionServiceCommunication =
              module$contents$omid$common$serviceCommunication_startSessionServiceCommunication),
              (module$exports$omid$common$serviceCommunication.startVerificationServiceCommunication =
                module$contents$omid$common$serviceCommunication_startVerificationServiceCommunication);
            var module$exports$omid$verificationClient$VerificationClient = {},
              module$contents$omid$verificationClient$VerificationClient_VERIFICATION_CLIENT_VERSION =
                module$exports$omid$common$version.Version,
              module$contents$omid$verificationClient$VerificationClient_EventCallback;
            function module$contents$omid$verificationClient$VerificationClient_getThirdPartyOmid() {
              var e =
                module$exports$omid$common$OmidGlobalProvider.omidGlobal.omid3p;
              return e &&
                "function" == typeof e.registerSessionObserver &&
                "function" == typeof e.addEventListener
                ? e
                : null;
            }
            (module$exports$omid$verificationClient$VerificationClient.VerificationClient =
              function (e) {
                (this.communication =
                  e ||
                  module$contents$omid$common$serviceCommunication_startVerificationServiceCommunication(
                    module$contents$omid$common$windowUtils_resolveGlobalContext()
                  ))
                  ? (this.communication.onMessage =
                      this.handleMessage_.bind(this))
                  : (e =
                      module$contents$omid$verificationClient$VerificationClient_getThirdPartyOmid()) &&
                    (this.omid3p = e),
                  (this.remoteIntervals_ = this.remoteTimeouts_ = 0),
                  (this.callbackMap_ = {}),
                  (this.imgCache_ = []),
                  (this.injectionId_ = (e =
                    module$exports$omid$common$OmidGlobalProvider.omidGlobal
                      .omidVerificationProperties)
                    ? e.injectionId
                    : void 0);
              }),
              (module$exports$omid$verificationClient$VerificationClient.VerificationClient.prototype.isSupported =
                function () {
                  return !(
                    (this.getEnvironment() ===
                      module$exports$omid$common$constants.Environment.WEB &&
                      !this.injectionId_) ||
                    (!this.communication && !this.omid3p)
                  );
                }),
              (module$exports$omid$verificationClient$VerificationClient.VerificationClient.prototype.getEnvironment =
                function () {
                  var e =
                    module$contents$omid$common$windowUtils_resolveGlobalContext();
                  return (
                    this.injectionSource() ||
                    (0,
                    module$exports$omid$common$DetectOmid.getOmidEnvironment)(
                      e
                    ) ||
                    (0,
                    module$exports$omid$common$DetectOmid.getOmidEnvironment)(
                      module$contents$omid$common$windowUtils_resolveTopWindowContext(
                        e
                      )
                    )
                  );
                }),
              (module$exports$omid$verificationClient$VerificationClient.VerificationClient.prototype.injectionSource =
                function () {
                  var e =
                    module$exports$omid$common$OmidGlobalProvider.omidGlobal
                      .omidVerificationProperties;
                  if (e && e.injectionSource) return e.injectionSource;
                }),
              (module$exports$omid$verificationClient$VerificationClient.VerificationClient.prototype.registerSessionObserver =
                function (e, o) {
                  module$contents$omid$common$argsChecker_assertFunction(
                    "functionToExecute",
                    e
                  ),
                    this.omid3p
                      ? this.omid3p.registerSessionObserver(
                          e,
                          o,
                          this.injectionId_
                        )
                      : this.sendMessage_(
                          "addSessionListener",
                          e,
                          o,
                          this.injectionId_
                        );
                }),
              (module$exports$omid$verificationClient$VerificationClient.VerificationClient.prototype.addEventListener =
                function (e, o) {
                  module$contents$omid$common$argsChecker_assertTruthyString(
                    "eventType",
                    e
                  ),
                    module$contents$omid$common$argsChecker_assertFunction(
                      "functionToExecute",
                      o
                    ),
                    this.omid3p
                      ? this.omid3p.addEventListener(e, o, this.injectionId_)
                      : this.sendMessage_(
                          "addEventListener",
                          o,
                          e,
                          this.injectionId_
                        );
                }),
              (module$exports$omid$verificationClient$VerificationClient.VerificationClient.prototype.sendUrl =
                function (e, o, t) {
                  module$contents$omid$common$argsChecker_assertTruthyString(
                    "url",
                    e
                  ),
                    module$exports$omid$common$OmidGlobalProvider.omidGlobal
                      .document &&
                    module$exports$omid$common$OmidGlobalProvider.omidGlobal
                      .document.createElement
                      ? this.sendUrlWithImg_(e, o, t)
                      : this.sendMessage_(
                          "sendUrl",
                          function (e) {
                            e && o ? o() : !e && t && t();
                          },
                          e
                        );
                }),
              (module$exports$omid$verificationClient$VerificationClient.VerificationClient.prototype.sendUrlWithImg_ =
                function (e, o, t) {
                  var i = this,
                    n =
                      module$exports$omid$common$OmidGlobalProvider.omidGlobal.document.createElement(
                        "img"
                      );
                  this.imgCache_.push(n);
                  var m = function (e) {
                    var o = i.imgCache_.indexOf(n);
                    0 <= o && i.imgCache_.splice(o, 1), e && e();
                  };
                  n.addEventListener("load", m.bind(this, o)),
                    n.addEventListener("error", m.bind(this, t)),
                    (n.src = e);
                }),
              (module$exports$omid$verificationClient$VerificationClient.VerificationClient.prototype.injectJavaScriptResource =
                function (e, o, t) {
                  var i = this;
                  module$contents$omid$common$argsChecker_assertTruthyString(
                    "url",
                    e
                  ),
                    module$exports$omid$common$OmidGlobalProvider.omidGlobal
                      .document
                      ? this.injectJavascriptResourceUrlInDom_(e, o, t)
                      : this.sendMessage_(
                          "injectJavaScriptResource",
                          function (n, m) {
                            n
                              ? (i.evaluateJavaScript_(m, e), o())
                              : (module$contents$omid$common$logger_error(
                                  "Service failed to load JavaScript resource."
                                ),
                                t());
                          },
                          e
                        );
                }),
              (module$exports$omid$verificationClient$VerificationClient.VerificationClient.prototype.injectJavascriptResourceUrlInDom_ =
                function (e, o, t) {
                  var i =
                      module$exports$omid$common$OmidGlobalProvider.omidGlobal
                        .document,
                    n = i.body;
                  ((i = i.createElement("script")).onload = o),
                    (i.onerror = t),
                    (i.src = e),
                    (i.type = "application/javascript"),
                    n.appendChild(i);
                }),
              (module$exports$omid$verificationClient$VerificationClient.VerificationClient.prototype.evaluateJavaScript_ =
                function (a, b) {
                  try {
                    eval(a);
                  } catch (e) {
                    module$contents$omid$common$logger_error(
                      'Error evaluating the JavaScript resource from "' +
                        b +
                        '".'
                    );
                  }
                }),
              (module$exports$omid$verificationClient$VerificationClient.VerificationClient.prototype.setTimeout =
                function (e, o) {
                  if (
                    (module$contents$omid$common$argsChecker_assertFunction(
                      "functionToExecute",
                      e
                    ),
                    module$contents$omid$common$argsChecker_assertPositiveNumber(
                      "timeInMillis",
                      o
                    ),
                    this.hasTimeoutMethods_())
                  )
                    return module$exports$omid$common$OmidGlobalProvider.omidGlobal.setTimeout(
                      e,
                      o
                    );
                  var t = this.remoteTimeouts_++;
                  return this.sendMessage_("setTimeout", e, t, o), t;
                }),
              (module$exports$omid$verificationClient$VerificationClient.VerificationClient.prototype.clearTimeout =
                function (e) {
                  module$contents$omid$common$argsChecker_assertPositiveNumber(
                    "timeoutId",
                    e
                  ),
                    this.hasTimeoutMethods_()
                      ? module$exports$omid$common$OmidGlobalProvider.omidGlobal.clearTimeout(
                          e
                        )
                      : this.sendOneWayMessage_("clearTimeout", e);
                }),
              (module$exports$omid$verificationClient$VerificationClient.VerificationClient.prototype.setInterval =
                function (e, o) {
                  if (
                    (module$contents$omid$common$argsChecker_assertFunction(
                      "functionToExecute",
                      e
                    ),
                    module$contents$omid$common$argsChecker_assertPositiveNumber(
                      "timeInMillis",
                      o
                    ),
                    this.hasIntervalMethods_())
                  )
                    return module$exports$omid$common$OmidGlobalProvider.omidGlobal.setInterval(
                      e,
                      o
                    );
                  var t = this.remoteIntervals_++;
                  return this.sendMessage_("setInterval", e, t, o), t;
                }),
              (module$exports$omid$verificationClient$VerificationClient.VerificationClient.prototype.clearInterval =
                function (e) {
                  module$contents$omid$common$argsChecker_assertPositiveNumber(
                    "intervalId",
                    e
                  ),
                    this.hasIntervalMethods_()
                      ? module$exports$omid$common$OmidGlobalProvider.omidGlobal.clearInterval(
                          e
                        )
                      : this.sendOneWayMessage_("clearInterval", e);
                }),
              (module$exports$omid$verificationClient$VerificationClient.VerificationClient.prototype.hasTimeoutMethods_ =
                function () {
                  return (
                    "function" ==
                      typeof module$exports$omid$common$OmidGlobalProvider
                        .omidGlobal.setTimeout &&
                    "function" ==
                      typeof module$exports$omid$common$OmidGlobalProvider
                        .omidGlobal.clearTimeout
                  );
                }),
              (module$exports$omid$verificationClient$VerificationClient.VerificationClient.prototype.hasIntervalMethods_ =
                function () {
                  return (
                    "function" ==
                      typeof module$exports$omid$common$OmidGlobalProvider
                        .omidGlobal.setInterval &&
                    "function" ==
                      typeof module$exports$omid$common$OmidGlobalProvider
                        .omidGlobal.clearInterval
                  );
                }),
              (module$exports$omid$verificationClient$VerificationClient.VerificationClient.prototype.handleMessage_ =
                function (e, o) {
                  o = e.method;
                  var t = e.guid;
                  if (
                    ((e = e.args), "response" === o && this.callbackMap_[t])
                  ) {
                    var i =
                      module$contents$omid$common$ArgsSerDe_deserializeMessageArgs(
                        module$exports$omid$common$version.Version,
                        e
                      );
                    this.callbackMap_[t].apply(this, i);
                  }
                  "error" === o &&
                    window.console &&
                    module$contents$omid$common$logger_error(e);
                }),
              (module$exports$omid$verificationClient$VerificationClient.VerificationClient.prototype.sendOneWayMessage_ =
                function (e) {
                  var o = $jscomp.getRestArguments.apply(1, arguments);
                  this.sendMessage_.apply(
                    this,
                    [e, null].concat($jscomp.arrayFromIterable(o))
                  );
                }),
              (module$exports$omid$verificationClient$VerificationClient.VerificationClient.prototype.sendMessage_ =
                function (e, o) {
                  var t = $jscomp.getRestArguments.apply(2, arguments);
                  if (this.communication) {
                    var i = module$contents$omid$common$guid_generateGuid();
                    o && (this.callbackMap_[i] = o),
                      (t = new module$exports$omid$common$InternalMessage(
                        i,
                        module$contents$omid$common$serviceMethodUtils_getPrefixedVerificationServiceMethod(
                          e
                        ),
                        module$exports$omid$common$version.Version,
                        module$contents$omid$common$ArgsSerDe_serializeMessageArgs(
                          module$exports$omid$common$version.Version,
                          t
                        )
                      )),
                      this.communication.sendMessage(t);
                  }
                }),
              module$contents$omid$common$exporter_packageExport(
                "OmidVerificationClient",
                module$exports$omid$verificationClient$VerificationClient.VerificationClient
              ),
              module$contents$omid$common$exporter_packageExport(
                "AdEventType",
                module$exports$omid$common$constants.AdEventType
              ),
              (module$exports$omid$verificationClient$VerificationClient.AdEventType =
                module$exports$omid$common$constants.AdEventType);
          },
          exports
        );
      },
    },
    __webpack_module_cache__ = {};
  function __webpack_require__(e) {
    var o = __webpack_module_cache__[e];
    if (void 0 !== o) return o.exports;
    var t = (__webpack_module_cache__[e] = { exports: {} });
    return (
      __webpack_modules__[e].call(t.exports, t, t.exports, __webpack_require__),
      t.exports
    );
  }
  __webpack_require__.g = (function () {
    if ("object" == typeof globalThis) return globalThis;
    try {
      return this || new Function("return this")();
    } catch (e) {
      if ("object" == typeof window) return window;
    }
  })();
  var __webpack_exports__ = {};
  (() => {
    "use strict";
    var e = __webpack_exports__;
    Object.defineProperty(e, "__esModule", { value: !0 }),
      (e.EquativVerificationClient = void 0);
    const o = __webpack_require__(488);
    class t {
      constructor() {
        (this.MEASURE_TIME = 2e3),
          (this.measureTimer = 0),
          (this.paused = !0),
          (this.viewabilityCounted = !1),
          (this.percentageInView = 0),
          (this.viewcountPixa = ""),
          (this.omidVerificationClient = new o.OmidVerificationClient()),
          this.omidVerificationClient.registerSessionObserver((e) => {
            e.type === o.AdEventType.SESSION_START &&
              ((this.viewcountPixa = this.parseViewcountPixa(
                e.data.verificationParameters
              )),
              this.viewcountPixa &&
                Object.values(o.AdEventType).forEach((e) => {
                  this.omidVerificationClient.addEventListener(e, (e) =>
                    this.onEvent(e)
                  );
                }));
          });
      }
      onEvent(e) {
        (e.type !== o.AdEventType.START && e.type !== o.AdEventType.RESUME) ||
          ((this.paused = !1),
          this.percentageInView >= 50 && this.startTimeout()),
          (e.type !== o.AdEventType.PAUSE &&
            e.type !== o.AdEventType.SKIPPED &&
            e.type !== o.AdEventType.COMPLETE) ||
            (this.resetTimeout(), (this.paused = !0)),
          e.type === o.AdEventType.GEOMETRY_CHANGE &&
            e.data &&
            (e.data, 1) &&
            ((this.percentageInView = e.data.adView.percentageInView),
            this.percentageInView >= 50 && !this.paused
              ? this.startTimeout()
              : this.resetTimeout());
      }
      startTimeout() {
        0 !== this.measureTimer ||
          this.viewabilityCounted ||
          (this.measureTimer = window.setTimeout(
            () => this.trackViewability(),
            this.MEASURE_TIME
          ));
      }
      resetTimeout() {
        0 !== this.measureTimer &&
          (window.clearTimeout(this.measureTimer), (this.measureTimer = 0));
      }
      trackViewability() {
        (this.viewabilityCounted = !0),
          this.resetTimeout(),
          this.sendPixa(this.viewcountPixa);
      }
      parseViewcountPixa(e) {
        let o = "";
        return (
          e.split("||").forEach((e) => {
            const [t, ...i] = e.split("="),
              n = i.join("=");
            "viewcount" === t && (o = n);
          }),
          o
        );
      }
      sendPixa(e) {
        e && this.omidVerificationClient.sendUrl(e);
      }
    }
    (e.EquativVerificationClient = t), new t();
  })(),
    (EquativVerificationScript = __webpack_exports__);
})();
