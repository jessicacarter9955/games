window.addEventListener("load", () => {
  window.adWidth = Number(
    document
      .getElementsByClassName("meta")[0]
      .getAttribute("content")
      .split(",")[0]
      .substr(6)
  );
  window.adHeight = Number(
    document
      .getElementsByClassName("meta")[0]
      .getAttribute("content")
      .split(",")[1]
      .substr(7)
  );

  document.getElementsByTagName("title")[0].innerHTML =
    adWidth + "x" + adHeight;

  const ctaTL = gsap.timeline({ paused: true }).to(".cta", {
    duration: 0.2,
    background: props.bg_color == "" ? "#000" : props.bg_color,
    color: props.cta_bg_color,
    ease: "sine.inOut",
  });

  const exitBtn = document.querySelector(".exitBtn");
  exitBtn.onclick = () => window.open(window.clickTag);
  exitBtn.onpointerover = () => ctaTL.play();
  exitBtn.onpointerout = () => ctaTL.reverse();

  window.tlMain = gsap
    .timeline()
    .set(".group", {
      left: 0,
      top: 0,
      overflow: "hidden",
      width: adWidth,
      height: adHeight,
      attr: { width: adWidth, height: adHeight },
    })
    .set(".ad", {
      backgroundColor: props.bg_color == "" ? "#000" : props.bg_color,
    })
    .set(".f4_bg", {
      attr: { fill: props.bg_color == "" ? "#000" : props.bg_color },
    })
    .set(".border", {
      borderColor: props.border_color == "" ? "#000" : props.border_color,
    })
    .set(".logo", { attr: { href: props.f1_logo || props.logo_img } })
    .set(".f1_bg", { attr: { href: props.f1_bg } })
    .set(".f1_geo", { attr: { href: props.f1_geo } })
    .set(".f1_txt", { attr: { href: props.f1_txt } })
    .set(".f2_bg", { attr: { href: props.f2_bg } })
    .set(".f2_geo", { attr: { href: props.f2_geo }, x: adWidth })
    .set(".f2_txt", { attr: { href: props.f2_txt } })
    .set(".f3_bg", { attr: { href: props.f3_bg } })
    .set(".f3_geo", { attr: { href: props.f3_geo }, x: adWidth })
    .set(".f3_txt", { attr: { href: props.f3_txt } })
    .set(".f4_bg_img", { attr: { href: props.f4_bg } })
    .set(".f4_txt", { attr: { href: props.f4_txt } })
    .set(".cta", {
      x: () =>
        props.cta_center_xy == "" ? 197 : props.cta_center_xy.split(",")[0],
      y: () =>
        props.cta_center_xy == "" ? 209 : props.cta_center_xy.split(",")[1],
      xPercent: -50,
      yPercent: -50,
      fontSize: "27px",
      lineHeight: "27px",
      textAlign: "center",
      innerHTML: () => (props.cta_txt == "" ? "DONATE NOW" : props.cta_txt),
      background: props.cta_bg_color,
      color: () => props.cta_txt_color,
      padding: "6px 18px 9px 18px",
      border: "2.5px solid " + props.cta_bg_color,
      borderRadius: "40px",
      transformOrigin: "50%",
      scale: 0.4,
      opacity: 0,
    })

    .to(".ad", { duration: 0.01, autoAlpha: 1 }, 0)
    .add(() => {
      if (props.box_anim == "") {
        tlMain.set(".box, .sticker-svg", { display: "none" }).add(step1());
      } else {
        tlMain.add(step0()).add(step1(), "-=0.7");
      }

      if (props.truck_anim == "") gsap.set(".truck, .line", { opacity: 0 });

      tlMain.add(step2(), "-=0.5");
      tlMain.add(step3(), "-=0.5");
      tlMain.add(step4(), "-=0.5");

      // tlMain.play(15)
      // console.log( tlMain.duration() )
    });

  function step0() {
    return gsap
      .timeline({ defaults: { duration: 2, ease: "power3.in" } })
      .set(".box", {
        width: 300,
        height: 300,
        perspective: 250,
        y: -25,
      })
      .set(".box div", {
        width: 300,
        height: 150,
        background: "#000",
        y: (i) => [-1, 151][i % 2],
        transformOrigin: (i) => ["50% 0", "50% 100%"][i % 2],
      })

      .fromTo(".sticker-back path", { x: 47, y: 47 }, { x: -60, y: -60 }, 0)
      .to("#sticker-mask path", { x: -50, y: -50 }, 0)
      .to(
        "feGaussianBlur",
        { attr: { stdDeviation: 3 }, ease: "power1.inOut", duration: 1.6 },
        0.9
      )
      .to(
        ".shadow",
        {
          transformOrigin: "99% 0",
          scale: 1.05,
          ease: "sine.inOut",
          duration: 1.4,
        },
        0.6
      )
      .to(
        "#sheenFill",
        { attr: { x1: 30, y1: 30, x2: 50, y2: 50 }, duration: 1.4 },
        0.4
      )
      .to(
        "#sheenFill stop",
        { attr: { "stop-color": "#eee" }, ease: "sine.inOut", duration: 1.5 },
        1
      )
      .to(".sticker", { duration: 1, scale: 1.25, ease: "power4.in" }, 0.8)
      .fromTo(
        ".sticker",
        { x: 118, y: 90 },
        { duration: 0.7, x: -40, y: 20, rotate: -40, ease: "power3.in" },
        1.3
      )
      .to(
        ".box1 div",
        {
          duration: 0.6,
          stagger: 0.3,
          rotateX: (i) => [99, -99][i],
          filter: "blur(8px)",
          ease: "expo.in",
        },
        1.5
      )
      .to(
        ".box1 img",
        { duration: 0.6, stagger: 0.3, opacity: 0.3, ease: "expo.in" },
        1.5
      )
      .from(".logo", { duration: 0.7, opacity: 0, ease: "power2.in" }, 1.5)
      .to(".box1 div", { duration: 0.1, display: "none", stagger: 0.3 }, 2.1);
  }

  function step1() {
    return gsap
      .timeline()
      .from(
        ".f1_bg",
        {
          duration: 4,
          scale: 1.1,
          rotate: 0.1,
          transformOrigin: "50%",
          ease: "none",
        },
        0
      )
      .from(".f1_bg", { duration: 0.7, opacity: 0, ease: "sine.inOut" }, 0.1)
      .from(
        ".f1_txt",
        { duration: 0.7, x: -adWidth, skewX: -90, ease: "expo" },
        0.5
      )
      .from(".f1_geo", { duration: 0.7, x: adWidth, ease: "expo" }, 0.5);
  }

  function step2() {
    return gsap
      .timeline()
      .add(() => {
        const curLogo = props.f1_logo || props.logo_img;
        const nextLogo = props.f2_logo || props.logo_img;
        if (curLogo !== nextLogo) {
          gsap
            .timeline()
            .to(".logo", { duration: 0.3, opacity: 0 }, 0)
            .add(() => gsap.set(".logo", { attr: { href: nextLogo } }))
            .to(".logo", { duration: 0.3, opacity: 1 }, 0.35);
        }
      })
      .add(() => {
        if (props.f1_geo != props.f2_geo) {
          // only change geo if different from previous
          gsap
            .timeline()
            .to(".f1_geo", { duration: 0.3, opacity: 0 }, 0)
            .to(".f2_geo", { duration: 0.7, x: 0, ease: "expo" }, 0.5);
        }
      })
      .to(".f1_txt", { duration: 0.3, opacity: 0 }, 0)
      .from("#m2 path", { duration: 1, x: -500, ease: "power3.inOut" }, 0)
      .from(
        ".f2_bg",
        {
          duration: 4,
          scale: 1.1,
          rotate: 0.1,
          transformOrigin: "50%",
          ease: "none",
        },
        0
      )
      .from(
        ".f2_txt",
        { duration: 0.7, x: -adWidth, skewX: -90, ease: "expo" },
        0.5
      );
  }

  function step3() {
    if (props.f3_bg != "")
      return gsap
        .timeline()
        .add(() => {
          const curLogo = props.f2_logo || props.logo_img;
          const nextLogo = props.f3_logo || props.logo_img;
          if (curLogo !== nextLogo) {
            gsap
              .timeline()
              .to(".logo", { duration: 0.3, opacity: 0 }, 0)
              .add(() => gsap.set(".logo", { attr: { href: nextLogo } }))
              .to(".logo", { duration: 0.3, opacity: 1 }, 0.35);
          }
        })
        .add(() => {
          if (props.f2_geo != props.f3_geo) {
            // only change geo if different from previous
            gsap
              .timeline()
              .to(".f2_geo", { duration: 0.3, opacity: 0 }, 0)
              .to(".f3_geo", { duration: 0.7, x: 0, ease: "expo" }, 0.5);
          }
        })
        .to(".f2_txt", { duration: 0.3, opacity: 0 }, 0)
        .from("#m3 path", { duration: 1, x: -500, ease: "power3.inOut" }, 0)
        .from(
          ".f3_bg",
          {
            duration: 4,
            scale: 1.1,
            rotate: 0.1,
            transformOrigin: "50%",
            ease: "none",
          },
          0
        )
        .from(
          ".f3_txt",
          { duration: 0.7, x: -adWidth, skewX: -90, ease: "expo" },
          0.5
        );
  }

  function step4() {
    return gsap
      .timeline()
      .add(() => {
        const curLogo = props.f3_logo || props.logo_img;
        const nextLogo = props.f4_logo || props.logo_img;
        if (curLogo !== nextLogo) {
          gsap
            .timeline()
            .to(".logo", { duration: 0.3, opacity: 0 }, 0)
            .add(() => gsap.set(".logo", { attr: { href: nextLogo } }))
            .to(".logo", { duration: 0.3, opacity: 1 }, 0.35);
        }
      })
      .to(".f3_txt", { duration: 0.35, x: -adWidth, ease: "power3.in" }, 0)
      .to(".f3_geo", { duration: 0.35, x: adWidth, ease: "power3.in" }, 0)
      .from(".f4", { duration: 0.3, opacity: 0, ease: "power2.inOut" }, 0.2)
      .from(
        ".f4_txt",
        {
          duration: 0.6,
          scale: 1.3,
          transformOrigin: "50% 45%",
          opacity: 0,
          ease: "power2.inOut",
        },
        0.35
      )
      .from(".line", { scaleX: 0, ease: "power2.inOut" }, 0.3)
      .fromTo(
        ".truck",
        { x: -150 },
        { duration: 1, x: 25, ease: "power3" },
        0.4
      )
      .to(".truck", { duration: 0.7, x: 0, ease: "power2.inOut" }, 1.1)
      .to(".cta", { duration: 0.35, opacity: 1, scale: 0.8, ease: "back" }, 1.4)
      .add(() => ctaTL.play(), 2.2)
      .add(() => ctaTL.reverse(), 3);
  }
});
