window.clickTag =
  "https://www.unicefusa.org/stories/5-ways-conflict-middle-east-impacts-children?form=FUNPUTLWGMA&utm_source=dv360&utm_medium=display&utm_campaign=202509_eme-rv_eme-na&utm_content=htmlmodule_customintent_prospect_en_300x250_menacrisisrrv2&initialms=dv360__display__202509_eme-rv_eme-na__htmlmodule_customintent_prospect_en_300x250_menacrisisrrv2"; // exit URL

var props = {
  border_color: "#ddd",
  bg_color: "#000",
  logo_img: "logo.svg",
  f1_logo: "",
  f2_logo: "",
  f3_logo: "",
  f4_logo: "",
  box_anim: "",
  truck_anim: "",
  f1_bg: "f1_bg.jpg",
  f1_txt: "f1_txt.svg",
  f1_geo: "",
  f2_bg: "f2_bg.jpg",
  f2_txt: "f2_txt.svg",
  f2_geo: "",
  f3_bg: "f3_bg.jpg",
  f3_txt: "f3_txt.svg",
  f3_geo: "",
  f4_bg: "f4_bg.jpg",
  f4_txt: "f4_txt.svg",
  cta_txt: "ACT NOW",
  cta_center_xy: "218,209",
  cta_txt_color: "white",
  cta_bg_color: "red",
};
