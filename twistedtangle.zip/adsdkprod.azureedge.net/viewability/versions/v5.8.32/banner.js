/*!
 * SDK version: 5.8.32
 * Commit: 088fb3f4d
 */
(() => {
  "use strict";
  var e = {
      946: (e, t, i) => {
        i.d(t, {
          X7: () => Le,
          Jf: () => v,
          qD: () => w,
          m2: () => A,
          aV: () => _,
          fZ: () => N,
          fV: () => S,
          Ch: () => f,
          hA: () => et,
          AU: () => Qe,
          $K: () => Te,
          LK: () => Ze,
          eH: () => Ye,
          Hn: () => ct,
          E0: () => X,
          rZ: () => V,
          Rk: () => L,
          Zx: () => c,
          Z0: () => mt,
          gC: () => Tt,
          UI: () => Et,
          ko: () => gt,
          ws: () => ae,
          Rw: () => I,
          OV: () => it,
          k8: () => ut,
          dv: () => re,
          J_: () => Q,
          qO: () => Z,
          r0: () => l,
          Lm: () => $e,
          f6: () => De,
          O$: () => O,
          xC: () => C,
          G: () => h,
          p6: () => y,
          HF: () => M,
          Kq: () => ye,
          qE: () => ot,
          b9: () => Ee,
          in: () => Oe,
          h_: () => st,
          h$: () => dt,
          wO: () => Re,
          N: () => we,
          ip: () => je,
          lV: () => qe,
          LU: () => ge,
          em: () => m,
          H6: () => ue,
          dO: () => D,
          d9: () => de,
          W7: () => Ne,
          iT: () => Se,
          kz: () => lt,
          X8: () => ce,
          NL: () => oe,
          gj: () => he,
          jM: () => b,
          bR: () => T,
          yX: () => ne,
          An: () => ee,
          Ki: () => ie,
          sb: () => te,
          rJ: () => Ie,
          $O: () => Ce,
          y: () => Me,
          al: () => He,
          QS: () => Be,
          Ed: () => xe,
          Xi: () => Ue,
          GA: () => We,
          ZC: () => Fe,
          wk: () => ke,
          hD: () => Xe,
          lH: () => Ve,
          A3: () => pe,
          wB: () => g,
          sv: () => E,
          G7: () => le,
          vw: () => be,
          w: () => Pe,
          $J: () => Ke,
          Ad: () => _e,
          M4: () => u,
          iv: () => F,
          AW: () => z,
          Gr: () => ze,
          Tracking: () => Nt,
          oW: () => k,
          Xe: () => H,
          hC: () => B,
          gm: () => x,
          ie: () => U,
          HM: () => W,
          Iu: () => K,
          iJ: () => G,
          V$: () => q,
          jb: () => j,
          wi: () => at,
          O7: () => d,
          hS: () => rt,
          j6: () => fe,
          Cq: () => nt,
          cP: () => Ge,
          NN: () => me,
          RG: () => tt,
          JP: () => ve,
          qi: () => ht,
          NY: () => P,
          En: () => Ae,
          Y1: () => R,
          $Z: () => se,
          fu: () => $,
          Zl: () => J,
          kO: () => Y,
          G3: () => St,
          i5: () => ft,
          _C: () => It,
          dC: () => n,
          $t: () => p,
          s5: () => s,
          V: () => r,
        });
        const s = (e) => {
            let t = 0;
            for (let i = 0; i < e.length; i++)
              (t = (t << 5) - t + e.charCodeAt(i)), (t |= 0);
            return t;
          },
          n = (e) => {
            let t = e.parentNode;
            return (t && 1 === t.nodeType) || (t = null), t;
          },
          r = () => {
            const e = globalThis._lntv;
            return e && "boolean" == typeof e.isJsContext
              ? e.isJsContext
              : "undefined" == typeof window || "undefined" == typeof document;
          };
        var a, o;
        class c {
          static getWindowOuterSize(e) {
            const t = e.outerWidth,
              i = e.outerHeight;
            return new T(t, i);
          }
          static initVisibilityAPI() {
            const e = a.getWindow().document;
            let t = null,
              i = null;
            void 0 !== e.hidden
              ? ((t = "hidden"), (i = "visibilitychange"))
              : void 0 !== e.mozHidden
              ? ((t = "mozHidden"), (i = "mozvisibilitychange"))
              : void 0 !== e.msHidden
              ? ((t = "msHidden"), (i = "msvisibilitychange"))
              : void 0 !== e.webkitHidden &&
                ((t = "webkitHidden"), (i = "webkitvisibilitychange")),
              (a.documentHiddenVarName = t),
              (a.visibilityChangeEventName = i);
          }
          static getPageSize(e) {
            const t = e.document,
              i = t.body,
              s = t.documentElement,
              n = s ? s.scrollHeight : 0,
              r = s ? s.offsetHeight : 0,
              a = s ? s.scrollWidth : 0,
              o = s ? s.offsetWidth : 0,
              c = i ? i.scrollHeight : 0,
              l = i ? i.offsetHeight : 0,
              h = i ? i.scrollWidth : 0,
              d = i ? i.offsetWidth : 0,
              u = Math.max(n, r, c, l),
              g = Math.max(a, o, h, d);
            return new T(Math.round(g), Math.round(u));
          }
          static getWindowScroll(e) {
            const t =
                e.pageXOffset ||
                e.document.documentElement.scrollLeft ||
                e.document.body.scrollLeft,
              i =
                e.pageYOffset ||
                e.document.documentElement.scrollTop ||
                e.document.body.scrollTop;
            return new T(t, i);
          }
          static getClientSize(e) {
            const t = e.document.documentElement.clientWidth,
              i = e.document.documentElement.clientHeight;
            return new T(t, i);
          }
          static getBodyElement(e) {
            return e.document.body;
          }
          static getBodyElementTagNameChecked(e) {
            const t = this.getBodyElement(e);
            return t && "BODY" === se.getAttribute(t, "tagName") ? t : null;
          }
          static getLocation(e) {
            return e.location.href;
          }
          static getScreenWidth() {
            return screen.width;
          }
          static getScreenHeight() {
            return screen.height;
          }
          static getScreenSize() {
            return r() || "undefined" == typeof screen
              ? T.minusOne
              : new T(this.getScreenWidth(), this.getScreenHeight());
          }
          static hasFocus(e) {
            return !e.document.hasFocus || e.document.hasFocus();
          }
          static isHiddenWithWindow(e) {
            return (
              this.documentHiddenVarName &&
              e.document[this.documentHiddenVarName]
            );
          }
          static isHidden() {
            return this.isHiddenWithWindow(this.getTopAccessibleWindow());
          }
          static isDisplayNoneFrame(e) {
            try {
              let t = e.frameElement;
              for (; t; ) {
                if ("none" === t.style.display) return !0;
                t = t.parent;
              }
            } catch (e) {
              C.notify(C.EXCEPTION_40);
            }
            return !1;
          }
          static isCompatMode(e) {
            return "CSS1Compat" !== e.document.compatMode;
          }
          static getDocument(e) {
            return e.document;
          }
          shouldFlushOnPageHide() {
            return !1;
          }
          getSingleFlushSpecificDelay() {
            return 0;
          }
          static getScreenX() {
            return screenX;
          }
          static getScreenY() {
            return screenY;
          }
          static getWindowSize(e) {
            const t = e.innerWidth,
              i = e.innerHeight;
            return new T(t, i);
          }
          static getScreenPosition() {
            return new T(this.getScreenX(), this.getScreenY());
          }
          static getWindow() {
            return a.getNamespace().$wnd;
          }
          static getJSNaminglnt() {
            return "_lntv";
          }
          static getNamespace() {
            return globalThis[a.getJSNaminglnt()];
          }
          static getTopAccessibleWindow() {
            return this.topAccessibleWindow;
          }
          static setTopAccessibleWindow(e) {
            this.topAccessibleWindow = e;
          }
          static getVisibilityChangeEventName() {
            return this.visibilityChangeEventName;
          }
          static isAppUserAgent() {
            const e = this.isSpotify();
            return e && C.notify(C.EXCEPTION_1312), e;
          }
          static isSpotify() {
            return (
              "undefined" != typeof navigator &&
              -1 !== navigator.userAgent.toLowerCase().indexOf("spotify")
            );
          }
        }
        (a = c), r() || a.initVisibilityAPI();
        class l {
          static debug(e) {
            l.debugNative(this.getTimeStamp(g.getCurrentTime()) + " " + e);
          }
          static debugNative(e) {
            const t = c.getNamespace();
            t.debug ? (t.debug += "\n") : (t.debug = ""),
              (t.debug += e),
              "undefined" != typeof console && console.log(e);
          }
          static getTimeStamp(e) {
            const t = c.getWindow();
            if (t.performance && t.performance.now) {
              let e = "[" + t.performance.now();
              return (e = e.substring(0, e.indexOf(".") + 4)), e + "]";
            }
            const i = new Date(e);
            let s = "[";
            const n = i.getHours(),
              r = i.getMinutes(),
              a = i.getSeconds(),
              o = i.getMilliseconds();
            return (
              (s += (n < 10 ? "0" : "") + n + ":"),
              (s += (r < 10 ? "0" : "") + r + ":"),
              (s += (a < 10 ? "0" : "") + a + "."),
              (s += (o < 10 ? "00" : o < 100 ? "0" : "") + o + "]"),
              s
            );
          }
          static debugDelayed(e) {
            l.delayedDebug || (l.delayedDebug = []), l.delayedDebug.push(e);
          }
          static flushDelayedDebug() {
            for (let e = 0; e < l.delayedDebug.length; e++)
              l.debug(l.delayedDebug[e]);
            l.delayedDebug.length = 0;
          }
        }
        class h {
          constructor(e, t) {
            (this.exceptionCode = e), (this.cb = t);
          }
          execute() {
            try {
              this.callback();
            } catch (e) {
              C.notify(this.exceptionCode);
            }
          }
          callback() {
            "function" == typeof this.cb && this.cb();
          }
        }
        class d {
          static isSafariMobile() {
            return "iOS" === g.getPlatform();
          }
          static isAndroidMobile() {
            return "android" === g.getPlatform();
          }
          static isIEMobile() {
            return "winphone" === g.getPlatform();
          }
          static isMobile() {
            return (
              r() || d.isSafariMobile() || d.isAndroidMobile() || d.isIEMobile()
            );
          }
          static isSafari() {
            return -1 !== g.getUserAgent().indexOf("safari");
          }
          static getSecondsFromMillisWith1Decimal(e) {
            return "" + Math.round(e / 100) / 10;
          }
          static getSecondsFromMillisWith2Decimal(e) {
            return "" + Math.round(e / 10) / 100;
          }
          static collectionToArray(e) {
            const t = [];
            for (let i = 0, s = e.length; i < s; i++) t.push(e[i]);
            return t;
          }
          static percent(e) {
            const t = "number" == typeof e ? String(e) : e;
            let i = "00",
              s = t;
            const n = t.indexOf(".");
            return (
              -1 !== n &&
                ((i = t.substring(n + 1, n + 3)),
                1 === i.length && (i += "0"),
                (s = t.substring(0, n))),
              "0" === s ? ("00" === i ? "0%" : i + "%") : s + i + "%"
            );
          }
          static rounded2Decimals(e) {
            return Math.round(100 * e) / 100;
          }
          static decodeURIComponent(e) {
            return decodeURIComponent(e);
          }
          static createJsMapFromStringToString() {
            return new Map();
          }
          static splitString(e, t, i) {
            const s = e.split(t);
            if (s.length <= i) return s;
            const n = s.splice(0, i - 1);
            return n.push(s.join(t)), n;
          }
          static splitStringByRegexp(e, t) {
            return e.split(new RegExp(t));
          }
          static getRandomId() {
            return Math.floor(82e7 * Math.random() + 1e8) + "";
          }
          static getRandom() {
            return Math.random();
          }
          static parseInt(e) {
            try {
              return parseInt(e, 10);
            } catch (e) {
              return C.notify(C.EXCEPTION_6), 0;
            }
          }
          static isNumeric(e) {
            try {
              const t = parseFloat(e);
              return !isNaN(t) && isFinite(t);
            } catch (e) {
              return !1;
            }
          }
          static parseFloat(e) {
            return parseFloat(e);
          }
          static elementHasDefined(e, t) {
            return void 0 !== e[t];
          }
          static isSupOrEqualVersion(e, t) {
            if ("" === e || "" === t) return !1;
            const i = e.split("."),
              s = t.split("."),
              n = Math.max(i.length, s.length);
            for (let e = 0; e < n; e++) {
              const t = i.length > e ? d.parseInt(i[e]) : 0,
                n = s.length > e ? d.parseInt(s[e]) : 0;
              if (t > n) return !0;
              if (t < n) return !1;
            }
            return s.length >= i.length;
          }
          static isStrictlyInferiorVersion(e, t) {
            return !d.isSupOrEqualVersion(e, t);
          }
        }
        class u {
          constructor(e, t) {
            (this.isRepeating = !1),
              (this.timerId = 0),
              (this.millis = 0),
              (this.timerCallback = e),
              (this.exceptionCode = t);
          }
          static getDefaultTimerNamespace() {
            return c.getWindow();
          }
          static setTimerNamespace(e) {
            (u.timerNamespace = e), u.recreateTimers();
          }
          static clearInterval(e) {
            u.timerNamespace.clearInterval(e);
          }
          static clearTimeout(e) {
            u.timerNamespace.clearTimeout(e);
          }
          static createInterval(e, t) {
            return u.timerNamespace.setInterval(() => {
              e.fire();
            }, t);
          }
          static createTimeout(e, t) {
            return u.timerNamespace.setTimeout(() => {
              e.fire();
            }, t);
          }
          cancel() {
            this.isRepeating
              ? u.clearInterval(this.timerId)
              : u.clearTimeout(this.timerId),
              (u.timers = u.timers.filter((e) => e !== this));
          }
          schedule(e) {
            if (e <= 0)
              throw new Error(
                "Cannot schedule a repeating timer with a period of zero or less."
              );
            this.cancel(),
              (this.millis = e),
              (this.isRepeating = !1),
              (this.timerId = u.createTimeout(this, e)),
              u.timers.push(this);
          }
          scheduleRepeating(e) {
            if (e <= 0)
              throw new Error(
                "Cannot schedule a repeating timer with a period of zero or less."
              );
            this.cancel(),
              (this.millis = e),
              (this.isRepeating = !0),
              (this.timerId = u.createInterval(this, e)),
              u.timers.push(this);
          }
          fire() {
            this.isRepeating || (u.timers = u.timers.filter((e) => e !== this));
            try {
              this.timerCallback();
            } catch (e) {
              this.exceptionCode && C.notify(this.exceptionCode);
            }
          }
          static closeRemainingTimers() {
            for (; u.timers.length > 0; ) u.timers[0].cancel();
          }
          static recreateTimers() {
            for (let e = 0; e < u.timers.length; e++)
              u.timers[e].recreateTimer();
          }
          recreateTimer() {
            this.isRepeating
              ? this.scheduleRepeating(this.millis)
              : this.schedule(this.millis);
          }
        }
        (u.timers = []), (u.timerNamespace = u.getDefaultTimerNamespace());
        class g {
          static getScriptId() {
            return c.getNamespace().si;
          }
          static getPlatform() {
            return c.getNamespace().plt;
          }
          static getInitializationTime() {
            return c.getNamespace().it;
          }
          static getUserAgent() {
            return c.getNamespace().ua;
          }
          static getRequestSentList() {
            return c.getNamespace().rqs;
          }
          static getTagList() {
            return c.getNamespace().ts;
          }
          static getScriptVersion() {
            return "5042";
          }
          static isInSecureProtocol() {
            return "https:" === c.getWindow().document.location.protocol;
          }
          static getProtocol() {
            return g.isInSecureProtocol() ? "https" : "http";
          }
          static getCurrentTime() {
            return new Date().getTime();
          }
          static getBaseURL() {
            return `${g.getProtocol()}:${c.getNamespace().base}`;
          }
          static getBrowserIdentifier() {
            return `${g.getScriptVersion()}-${g.getPlatform()}-${g.getOSVersion()}-${g.getUserAgent()}`;
          }
          static getOSVersion() {
            const e = new RegExp("Windows NT ([0-9]+)", "ig").exec(
              navigator.userAgent
            );
            return e && 2 === e.length ? e[1] : "-";
          }
        }
        class E {
          static registerOrUpdateSessionId() {
            try {
              if (!r()) {
                const e = c.getWindow().top;
                E.scanWindowsForSharedSession(e);
              }
              E.sessionId || (E.sessionId = E.genSessionId()),
                E.setSessionIdInNamespace(E.sessionId);
              for (let e = 0; e < E.allSeenWindows.length; ++e)
                E.updateLocalWindowSessionId(E.allSeenWindows[e], E.sessionId);
            } catch (e) {
              C.notify(C.EXCEPTION_166);
            }
            E.allSeenWindows = [];
          }
          static pushWindow(e) {
            E.allSeenWindows.push(e);
            const t = E.getOrCreateNullSharedIdSession(e);
            t && (E.sessionId = t);
          }
          static getOrCreateNullSharedIdSession(e) {
            const t = e.document._lntsh;
            return (
              void 0 !== t
                ? void 0 === t.ids && (e.document._lntsh.ids = null)
                : (e.document._lntsh = { ids: null }),
              e.document._lntsh.ids
            );
          }
          static scanWindowsForSharedSession(e) {
            M.isWindowDocumentAccessible(e) && E.pushWindow(e),
              E.scanFramesForSharedSession(e);
          }
          static scanFramesForSharedSession(e) {
            const t = e.frames;
            for (let e = 0; e < t.length; e++)
              E.scanWindowsForSharedSession(t[e]);
          }
          static genSessionId() {
            return (
              Math.floor(82e7 * Math.random() + 1e8) +
              "" +
              Math.floor(1e9 * Math.random() + 1e9)
            );
          }
          static setSessionIdInNamespace(e) {
            c.getNamespace().idSession = e;
          }
          static updateLocalWindowSessionId(e, t) {
            e.document._lntsh.ids = t;
          }
          static getSessionId() {
            return E.sessionId ? E.sessionId : "";
          }
        }
        (E.sessionId = null), (E.allSeenWindows = []);
        class T {
          constructor(e, t) {
            (this.x = e), (this.y = t);
          }
          div(e) {
            return new T(this.x / e.x, this.y / e.y);
          }
          equals(e) {
            if (!(e instanceof T)) return !1;
            const t = e;
            return this.x === t.x && this.y === t.y;
          }
          getX() {
            return this.x;
          }
          getY() {
            return this.y;
          }
          minus(e) {
            return new T(this.x - e.x, this.y - e.y);
          }
          mult(e) {
            return new T(this.x * e.x, this.y * e.y);
          }
          plus(e) {
            return new T(this.x + e.x, this.y + e.y);
          }
          toString() {
            return `Point(${this.x},${this.y})`;
          }
          middle(e) {
            return new T((this.x + e.x) / 2, (this.y + e.y) / 2);
          }
          opposite() {
            return new T(-this.x, -this.y);
          }
          surface() {
            return this.x * this.y;
          }
          max(e) {
            return new T(
              this.x > e.x ? this.x : e.x,
              this.y > e.y ? this.y : e.y
            );
          }
          min(e) {
            return new T(
              this.x < e.x ? this.x : e.x,
              this.y < e.y ? this.y : e.y
            );
          }
        }
        (T.zero = new T(0, 0)), (T.minusOne = new T(-1, -1));
        class m {
          static getJsModule(e) {
            return "OmidVerificationClient" === e
              ? this.getOmidVerificationClientModule()
              : this.getJsModuleNative(e);
          }
          static getOmidVerificationClientModule() {
            return "undefined" != typeof OmidVerificationClient
              ? OmidVerificationClient
              : null;
          }
          static getJsModuleNative(e) {
            return c.getNamespace().myo[e];
          }
        }
        function p() {
          const e = c.getNamespace();
          if (e.isJsContext) return (e.ua = "safari9"), (e.plt = "iOS"), e.ua;
          const t = navigator.userAgent.toLowerCase();
          let i,
            s = "unknown";
          return (
            -1 !== t.indexOf("edge")
              ? (s = "edge15")
              : -1 !== t.indexOf("msie") || -1 !== t.indexOf("trident")
              ? (s =
                  "function" == typeof IntersectionObserver &&
                  -1 !== (IntersectionObserver + "").indexOf("native")
                    ? "edge15"
                    : "ie11")
              : -1 !== t.indexOf("webkit")
              ? -1 !== t.indexOf("chrome")
                ? (s = "chrome52")
                : -1 !== t.indexOf("safari") && (s = "safari9")
              : -1 !== t.indexOf("gecko") && (s = "gecko40"),
            (i =
              -1 !== t.indexOf("android")
                ? "android"
                : -1 !== t.indexOf("linux")
                ? "linux"
                : -1 !== t.indexOf("ipod") ||
                  -1 !== t.indexOf("iphone") ||
                  -1 !== t.indexOf("ipad")
                ? "iOS"
                : -1 !== t.indexOf("macintosh")
                ? "mac"
                : -1 !== t.indexOf("windows")
                ? "win"
                : -1 !== navigator.userAgent.indexOf("CrOS")
                ? "chromeos"
                : "unknown"),
            (e.ua = s),
            (e.plt = i),
            s
          );
        }
        class O extends h {
          constructor(e, t) {
            super(e), (this.callbackFun = t);
          }
          getEvent() {
            return this.event;
          }
          callback() {
            this.handleEvent(this.event);
          }
          handleEvent(e) {
            "function" == typeof this.callbackFun && this.callbackFun(e);
          }
          setEvent(e) {
            this.event = e;
          }
        }
        class I {
          static getContainerType() {
            const e = W.getContainer();
            if (!e) return I.REGULAR_WEB;
            {
              const t = e.getContainerType();
              switch (t) {
                case I.NOT_INITIALIZED_SDK:
                  return I.REGULAR_WEB;
                case I.APPNEXUS_SDK:
                case I.MICROSOFT_SDK:
                case I.NOT_SUPPORTED_SDK:
                case I.HYBRID_APP:
                case I.SMAATO_SDK:
                case I.MOPUB_SDK:
                case I.OM_SDK_UNKNOWN:
                case I.OM_SDK_FULL:
                case I.OM_SDK_LIMITED:
                  return t;
                default:
                  return I.OTHER_SDK;
              }
            }
          }
          static canUseBeforeUnloadCallback() {
            return (
              !d.isAndroidMobile() ||
              (!Te.hasAnjamNamespaceNative(c.getTopAccessibleWindow()) &&
                (I.isOmidSdk()
                  ? !W.getContainer().isAppnexusPartner()
                  : !(
                      _e.isInAppSupplyType() &&
                      M.isCrossDomain() &&
                      W.trackingLoader.isTrackingSupported()
                    )))
            );
          }
          static isOmidSdk() {
            return (
              I.OM_SDK_UNKNOWN === I.getContainerType() ||
              I.OM_SDK_FULL === I.getContainerType() ||
              I.OM_SDK_LIMITED === I.getContainerType()
            );
          }
          static isOMIDContextWithoutCreativeAccess() {
            return (
              !!I.isOmidSdk() &&
              W.getContainer().isOMIDContextWithoutCreativeAccess()
            );
          }
          static cleanPartnerNameCharacters(e) {
            return e.replace(/[^a-zA-Z0-9._-]/g, "_").substring(0, 50);
          }
          static isAsync(e) {
            return !!I.isOmidSdk() && W.getContainer().isAsync(e);
          }
          static registerNewTag(e) {
            I.isOmidSdk() && W.getContainer().registerNewTag(e);
          }
        }
        (I.REGULAR_WEB = 0),
          (I.NOT_SUPPORTED_SDK = 1),
          (I.NOT_INITIALIZED_SDK = 2),
          (I.OTHER_SDK = 3),
          (I.APPNEXUS_SDK = 4),
          (I.MICROSOFT_SDK = 5),
          (I.HYBRID_APP = 6),
          (I.SMAATO_SDK = 7),
          (I.MOPUB_SDK = 8),
          (I.OM_SDK_UNKNOWN = 10),
          (I.OM_SDK_FULL = 11),
          (I.OM_SDK_LIMITED = 12);
        class C {
          static init() {
            (C.exceptions = []), C.createJSO(C.exceptions);
          }
          static createJSO(e) {
            c.getNamespace().e = e;
          }
          static notify(e) {
            const t = e.toString();
            -1 === C.exceptions.indexOf(t) && C.exceptions.push(t);
          }
          static getRequestPart() {
            return C.exceptions.length > 0 ? C.exceptions.join("|") : "";
          }
          static notifyWithException(e, t) {
            C.notify(e);
          }
        }
        (C.EXCEPTION_2 = 2),
          (C.EXCEPTION_3 = 3),
          (C.EXCEPTION_4 = 4),
          (C.EXCEPTION_5 = 5),
          (C.EXCEPTION_6 = 6),
          (C.EXCEPTION_9 = 9),
          (C.EXCEPTION_11 = 11),
          (C.EXCEPTION_13 = 13),
          (C.EXCEPTION_16 = 16),
          (C.EXCEPTION_19 = 19),
          (C.EXCEPTION_21 = 21),
          (C.EXCEPTION_23 = 23),
          (C.EXCEPTION_24 = 24),
          (C.EXCEPTION_28 = 28),
          (C.EXCEPTION_32 = 32),
          (C.EXCEPTION_33 = 33),
          (C.EXCEPTION_36 = 36),
          (C.EXCEPTION_37 = 37),
          (C.EXCEPTION_38 = 38),
          (C.EXCEPTION_39 = 39),
          (C.EXCEPTION_40 = 40),
          (C.EXCEPTION_41 = 41),
          (C.EXCEPTION_53 = 53),
          (C.EXCEPTION_57 = 57),
          (C.EXCEPTION_61 = 61),
          (C.EXCEPTION_72 = 72),
          (C.EXCEPTION_73 = 73),
          (C.EXCEPTION_75 = 75),
          (C.EXCEPTION_76 = 76),
          (C.EXCEPTION_79 = 79),
          (C.EXCEPTION_80 = 80),
          (C.EXCEPTION_81 = 81),
          (C.EXCEPTION_82 = 82),
          (C.EXCEPTION_83 = 83),
          (C.EXCEPTION_84 = 84),
          (C.EXCEPTION_85 = 85),
          (C.EXCEPTION_86 = 86),
          (C.EXCEPTION_88 = 88),
          (C.EXCEPTION_90 = 90),
          (C.EXCEPTION_93 = 93),
          (C.EXCEPTION_95 = 95),
          (C.EXCEPTION_99 = 99),
          (C.EXCEPTION_100 = 100),
          (C.EXCEPTION_103 = 103),
          (C.EXCEPTION_104 = 104),
          (C.EXCEPTION_107 = 107),
          (C.EXCEPTION_109 = 109),
          (C.EXCEPTION_110 = 110),
          (C.EXCEPTION_111 = 111),
          (C.EXCEPTION_112 = 112),
          (C.EXCEPTION_113 = 113),
          (C.EXCEPTION_114 = 114),
          (C.EXCEPTION_120 = 120),
          (C.EXCEPTION_121 = 121),
          (C.EXCEPTION_122 = 122),
          (C.EXCEPTION_124 = 124),
          (C.EXCEPTION_125 = 125),
          (C.EXCEPTION_126 = 126),
          (C.EXCEPTION_127 = 127),
          (C.EXCEPTION_128 = 128),
          (C.EXCEPTION_129 = 129),
          (C.EXCEPTION_142 = 142),
          (C.EXCEPTION_147 = 147),
          (C.EXCEPTION_148 = 148),
          (C.EXCEPTION_152 = 152),
          (C.EXCEPTION_153 = 153),
          (C.EXCEPTION_154 = 154),
          (C.EXCEPTION_155 = 155),
          (C.EXCEPTION_161 = 161),
          (C.EXCEPTION_162 = 162),
          (C.EXCEPTION_163 = 163),
          (C.EXCEPTION_166 = 166),
          (C.EXCEPTION_167 = 167),
          (C.EXCEPTION_168 = 168),
          (C.EXCEPTION_169 = 169),
          (C.EXCEPTION_171 = 171),
          (C.EXCEPTION_172 = 172),
          (C.EXCEPTION_173 = 173),
          (C.EXCEPTION_174 = 174),
          (C.EXCEPTION_175 = 175),
          (C.EXCEPTION_176 = 176),
          (C.EXCEPTION_180 = 180),
          (C.EXCEPTION_181 = 181),
          (C.EXCEPTION_182 = 182),
          (C.EXCEPTION_183 = 183),
          (C.EXCEPTION_185 = 185),
          (C.EXCEPTION_186 = 186),
          (C.EXCEPTION_187 = 187),
          (C.EXCEPTION_188 = 188),
          (C.EXCEPTION_189 = 189),
          (C.EXCEPTION_190 = 190),
          (C.EXCEPTION_191 = 191),
          (C.EXCEPTION_192 = 192),
          (C.EXCEPTION_200 = 200),
          (C.EXCEPTION_201 = 201),
          (C.EXCEPTION_202 = 202),
          (C.EXCEPTION_401 = 401),
          (C.EXCEPTION_402 = 402),
          (C.EXCEPTION_403 = 403),
          (C.EXCEPTION_404 = 404),
          (C.EXCEPTION_405 = 405),
          (C.EXCEPTION_406 = 406),
          (C.EXCEPTION_407 = 407),
          (C.EXCEPTION_408 = 408),
          (C.EXCEPTION_409 = 409),
          (C.EXCEPTION_204 = 204),
          (C.EXCEPTION_205 = 205),
          (C.EXCEPTION_206 = 206),
          (C.EXCEPTION_207 = 207),
          (C.EXCEPTION_1001 = 1001),
          (C.EXCEPTION_1003 = 1003),
          (C.EXCEPTION_1005 = 1005),
          (C.EXCEPTION_1006 = 1006),
          (C.EXCEPTION_1008 = 1008),
          (C.EXCEPTION_1009 = 1009),
          (C.EXCEPTION_1010 = 1010),
          (C.EXCEPTION_1012 = 1012),
          (C.EXCEPTION_1013 = 1013),
          (C.EXCEPTION_1014 = 1014),
          (C.EXCEPTION_1015 = 1015),
          (C.EXCEPTION_1016 = 1016),
          (C.EXCEPTION_1017 = 1017),
          (C.EXCEPTION_1018 = 1018),
          (C.EXCEPTION_1019 = 1019),
          (C.EXCEPTION_1020 = 1020),
          (C.EXCEPTION_1021 = 1021),
          (C.EXCEPTION_1022 = 1022),
          (C.EXCEPTION_1035 = 1035),
          (C.EXCEPTION_1030 = 1030),
          (C.EXCEPTION_1097 = 1097),
          (C.EXCEPTION_1135 = 1135),
          (C.EXCEPTION_1134 = 1134),
          (C.EXCEPTION_1140 = 1140),
          (C.EXCEPTION_1141 = 1141),
          (C.EXCEPTION_1143 = 1143),
          (C.EXCEPTION_1144 = 1144),
          (C.EXCEPTION_1145 = 1145),
          (C.EXCEPTION_1146 = 1146),
          (C.EXCEPTION_1150 = 1150),
          (C.EXCEPTION_1151 = 1151),
          (C.EXCEPTION_1160 = 1160),
          (C.EXCEPTION_1161 = 1161),
          (C.EXCEPTION_1162 = 1162),
          (C.EXCEPTION_1165 = 1165),
          (C.EXCEPTION_1170 = 1170),
          (C.EXCEPTION_1171 = 1171),
          (C.EXCEPTION_1172 = 1172),
          (C.EXCEPTION_1173 = 1173),
          (C.EXCEPTION_1174 = 1174),
          (C.EXCEPTION_1175 = 1175),
          (C.EXCEPTION_1179 = 1179),
          (C.EXCEPTION_1180 = 1180),
          (C.EXCEPTION_1181 = 1181),
          (C.EXCEPTION_1182 = 1182),
          (C.EXCEPTION_1184 = 1184),
          (C.EXCEPTION_1185 = 1185),
          (C.EXCEPTION_1186 = 1186),
          (C.EXCEPTION_1187 = 1187),
          (C.EXCEPTION_1190 = 1190),
          (C.EXCEPTION_1201 = 1201),
          (C.EXCEPTION_1202 = 1202),
          (C.EXCEPTION_1203 = 1203),
          (C.EXCEPTION_1205 = 1205),
          (C.EXCEPTION_1206 = 1206),
          (C.EXCEPTION_1207 = 1207),
          (C.EXCEPTION_1208 = 1208),
          (C.EXCEPTION_1209 = 1209),
          (C.EXCEPTION_1210 = 1210),
          (C.EXCEPTION_1211 = 1211),
          (C.EXCEPTION_1212 = 1212),
          (C.EXCEPTION_1213 = 1213),
          (C.EXCEPTION_1214 = 1214),
          (C.EXCEPTION_1215 = 1215),
          (C.EXCEPTION_1300 = 1300),
          (C.EXCEPTION_1304 = 1304),
          (C.EXCEPTION_1305 = 1305),
          (C.EXCEPTION_1306 = 1306),
          (C.EXCEPTION_1307 = 1307),
          (C.EXCEPTION_1308 = 1308),
          (C.EXCEPTION_1309 = 1309),
          (C.EXCEPTION_1310 = 1310),
          (C.EXCEPTION_1311 = 1311),
          (C.EXCEPTION_1312 = 1312),
          (C.EXCEPTION_1313 = 1313),
          (C.EXCEPTION_1314 = 1314),
          (C.EXCEPTION_1315 = 1315),
          (C.EXCEPTION_1316 = 1316),
          (C.EXCEPTION_1317 = 1317),
          (C.EXCEPTION_1318 = 1318),
          (C.EXCEPTION_1320 = 1320),
          (C.EXCEPTION_1330 = 1330),
          (C.EXCEPTION_1340 = 1340),
          (C.EXCEPTION_1341 = 1341),
          (C.EXCEPTION_1400 = 1400),
          (C.EXCEPTION_1420 = 1420),
          (C.EXCEPTION_1421 = 1421),
          (C.EXCEPTION_1422 = 1422),
          (C.EXCEPTION_1423 = 1423),
          (C.EXCEPTION_1500 = 1500),
          (C.EXCEPTION_1501 = 1501),
          (C.EXCEPTION_1502 = 1502),
          (C.EXCEPTION_1503 = 1503),
          (C.EXCEPTION_1504 = 1504),
          (C.EXCEPTION_1505 = 1505);
        class _ {
          registerActivity(e) {
            this.scanNregisterFocusHandlerOnWindows(e);
            const t = c.getDocument(e),
              i = c.getVisibilityChangeEventName();
            i && se.addEventListenerWithExceptionSafeCommand(t, i, new P(e)),
              M.isInIframe() ||
                se.addEventListenerWithEventListenerWrapper(
                  e,
                  t,
                  "keydown",
                  new O(C.EXCEPTION_80, (e) => {
                    this.isKeyCodeFromHuman(e) && A.onActiveEvent();
                  })
                );
          }
          scanNregisterFocusHandlerOnWindows(e) {
            if (M.isWindowDocumentAccessible(e))
              if (c.getBodyElementTagNameChecked(e))
                this.registerHandlerOnWindow(e);
              else {
                const t = new u(() => {
                  const i = c.getBodyElement(e);
                  i &&
                    (t.cancel(),
                    "BODY" === se.getAttribute(i, "nodeName") &&
                      this.registerHandlerOnWindow(e));
                }, C.EXCEPTION_84);
                t.scheduleRepeating(80);
              }
            try {
              this.scanFrames(e);
            } catch (e) {
              C.notify(C.EXCEPTION_167);
            }
          }
          scanFrames(e) {
            const t = e.frames;
            for (let e = 0; e < t.length; e++)
              this.scanNregisterFocusHandlerOnWindows(t[e]);
          }
          registerWindowUnloadHandler() {
            const e = c.getWindow(),
              t = new h(C.EXCEPTION_93, () => {
                A.isUnloadEventCatched() ||
                  (A.setUnloadEventCatched(!0),
                  W.trkFinalize(Qe.RR_BEFORE_UNLOAD_REQUEST));
              });
            I.canUseBeforeUnloadCallback() &&
              se.addEventListenerWithExceptionSafeCommand(e, "beforeunload", t);
            const i = new h(C.EXCEPTION_93, () => {
              A.isUnloadEventCatched() ||
                (A.setUnloadEventCatched(!0),
                W.trkFinalize(Qe.RR_PAGE_HIDE_REQUEST));
            });
            se.addEventListenerWithExceptionSafeCommand(e, "pagehide", i);
          }
          registerHandlerOnWindow(e) {
            try {
              const t = c.getDocument(e),
                i = new v(),
                s = W.trackingLoader.getMousePositionTracker();
              se.addEventListenerWithEventListenerWrapper(e, t, "mousemove", s),
                se.addEventListenerWithExceptionSafeCommand(t, "click", i),
                se.addEventListenerWithExceptionSafeCommand(e, "scroll", i),
                se.addEventListenerWithExceptionSafeCommand(
                  e,
                  "focus",
                  new b()
                );
            } catch (e) {
              C.notify(C.EXCEPTION_168);
            }
          }
          isKeyCodeFromHuman(e) {
            const t = e;
            return (t.charCode || t.keyCode) > 31;
          }
        }
        class f extends _ {
          registerHandlerOnWindow(e) {
            super.registerHandlerOnWindow(e),
              this.addBlurEventHandler(e, new y());
          }
          addBlurEventHandler(e, t) {
            e.addEventListener(
              "blur",
              (e) => {
                "object" == typeof e.target && t.execute();
              },
              !1
            );
          }
        }
        class S extends _ {
          registerActivity(e) {
            super.registerActivity(e), this.registerFocusEvents(e);
          }
          registerFocusEvents(e) {
            se.addEventListenerWithExceptionSafeCommand(
              e,
              "focus",
              new h(C.EXCEPTION_95, () => {
                c.hasFocus(c.getTopAccessibleWindow()) && A.onPageShowEvent();
              })
            );
            const t = c.getDocument(e);
            se.addEventListenerWithExceptionSafeCommand(t, "focusout", new y());
          }
        }
        class N extends _ {
          registerHandlerOnWindow(e) {
            super.registerHandlerOnWindow(e);
            const t = c.getDocument(e);
            this.addBlurEventHandler(t, new y());
          }
          addBlurEventHandler(e, t) {
            e.addEventListener(
              "blur",
              (e) => {
                "object" == typeof e.target && t.execute();
              },
              !1
            );
          }
        }
        class A {
          constructor() {
            const e = p();
            (A.impl =
              "ie11" === e || "edge15" === e
                ? new S()
                : "gecko40" === e
                ? new N()
                : new f()),
              A.registerActivity(c.getTopAccessibleWindow()),
              r() || A.impl.registerWindowUnloadHandler();
          }
          static registerActivity(e) {
            try {
              r() || A.impl.registerActivity(e);
            } catch (e) {
              C.notify(C.EXCEPTION_82);
            }
          }
          static registerHandlers() {
            try {
              new A();
            } catch (e) {
              C.notify(C.EXCEPTION_83);
            }
          }
          static isUnloadEventCatched() {
            return A.unloadEventCatched;
          }
          static setUnloadEventCatched(e) {
            A.unloadEventCatched = e;
          }
          static onActiveEvent() {
            A.focusOutDelayTimer.cancel(),
              W.trackingLoader.onBrowserActiveEvent();
          }
          static onPageShowEvent() {
            A.focusOutDelayTimer.cancel(),
              W.trackingLoader.onBrowserActiveEvent();
          }
          static onFocusoutEvent() {
            A.focusOutDelayTimer.schedule(A.INACTIVITY_THREADHOLD);
          }
          static onPageHideEvent() {
            A.focusOutDelayTimer.cancel(),
              A.unloadEventCatched || W.trackingLoader.onBrowserInactiveEvent();
          }
        }
        (A.unloadEventCatched = !1),
          (A.INACTIVITY_THREADHOLD = 100),
          (A.focusOutDelayTimer = new u(() => {
            W.trackingLoader && W.trackingLoader.onBrowserInactiveEvent();
          }, C.EXCEPTION_86));
        class v extends h {
          constructor() {
            super(C.EXCEPTION_88);
          }
          callback() {
            A.onActiveEvent();
          }
        }
        class P extends h {
          constructor(e) {
            super(C.EXCEPTION_99), (this.window = e);
          }
          callback() {
            c.isHiddenWithWindow(this.window)
              ? (A.onPageHideEvent(),
                d.isMobile() && W.sendIntermediateRequest())
              : A.onPageShowEvent();
          }
        }
        class b extends h {
          constructor() {
            super(C.EXCEPTION_104);
          }
          callback() {
            A.onPageShowEvent();
          }
        }
        class D extends O {
          constructor() {
            super(C.EXCEPTION_75),
              (this.lastMousePosition = null),
              (this.lastMousePositionOnScreen = null);
          }
          handleEvent(e) {
            if (e) {
              let t,
                i,
                s = 0,
                n = 0,
                r = null,
                a = null;
              try {
                const o = e;
                (t = o.screenX),
                  (i = o.screenY),
                  (s = o.clientX),
                  (n = o.clientY),
                  (r = o.target),
                  r || (r = o.srcElement),
                  (a = o.view);
              } catch (e) {
                (t = 0), (i = 0);
              }
              !this.lastMousePositionOnScreen ||
                (this.lastMousePositionOnScreen.getX() === t &&
                  this.lastMousePositionOnScreen.getY() === i) ||
                A.onActiveEvent(),
                (this.lastMousePositionOnScreen = new T(t, i)),
                M.isCrossDomain() ||
                  (!a && r && r.ownerDocument && (a = se.getElementWindow(r)),
                  a &&
                    ((this.lastMousePosition = new T(s, n)),
                    (this.lastMousePosition = M.getPositionRelativeToViewport(
                      this.lastMousePosition,
                      a
                    ))));
            }
          }
        }
        class y extends h {
          constructor() {
            super(C.EXCEPTION_103);
          }
          callback() {
            c.hasFocus(c.getTopAccessibleWindow()) || A.onFocusoutEvent();
          }
        }
        class w {
          constructor(e) {
            (this.active = !c.isHidden() && w.hasFocus()),
              (this.lastShotTime = g.getInitializationTime()),
              (this.lastEventTime = g.getInitializationTime());
          }
          static hasFocus() {
            return (
              !(!M.isCrossDomain() && !W.getContainer()) ||
              c.hasFocus(c.getTopAccessibleWindow())
            );
          }
          onActiveEvent() {
            this.setLastEventTime(g.getCurrentTime()),
              this.active ||
                (this.setActive(!0), this.setLastShotTime(this.lastEventTime));
          }
          setLastShotTime(e) {
            this.lastShotTime = e;
          }
          setLastEventTime(e) {
            this.lastEventTime = e;
          }
          setActive(e) {
            this.active = e;
          }
          onInactiveEvent() {
            this.isActive() && this._onInactiveEvent(g.getCurrentTime());
          }
          _onInactiveEvent(e) {
            this.setActive(!1), this.setLastEventTime(e);
          }
          isActive() {
            return I.isOMIDContextWithoutCreativeAccess() || this.active;
          }
          updateActivity() {
            const e = g.getCurrentTime();
            this.setLastShotTime(e);
          }
          getLastEventTime() {
            return this.lastEventTime;
          }
          getLastShotTime() {
            return this.lastShotTime;
          }
        }
        class R {
          static init(e) {
            R.windows = e;
            for (let e = 0; e < R.windows.length; e++)
              R.windows[e][R.INDEX_KEY] = R.windows.length - e;
          }
          static isReliable() {
            try {
              let e = 0;
              for (; e < R.windows.length - 1; ) {
                const t = R.windows[e];
                if (
                  !t ||
                  !R.getFrameElement(this.getAccessibleParentWindow(t), t)
                )
                  return !1;
                e++;
              }
              return !!R.windows[e];
            } catch (e) {
              return !1;
            }
          }
          static getTagWindow() {
            return R.windows[0];
          }
          static debug() {
            for (let e = 0; e < R.windows.length; e++) {
              const t = R.windows[e];
              l.debug(`Lvl ${e}: ${c.getLocation(t)}`);
            }
          }
          static getAccessibleParentWindow(e) {
            const t = R.windows.indexOf(e) + 1;
            return t < R.windows.length ? R.windows[t] : null;
          }
          static indexOf(e) {
            if (!e) return -1;
            let t;
            return (t = e[R.INDEX_KEY] || 0), R.windows.length - t;
          }
          static getAccessibleChildWindow(e) {
            const t = R.windows.indexOf(e) - 1;
            return t >= 0 ? R.windows[t] : null;
          }
          static getFrameElement(e, t) {
            return R.getFrameElementNative(e, t);
          }
          static getFrameElementNative(e, t) {
            if (t.parent === e) return t.frameElement;
            const i = e.document.getElementsByTagName("IFRAME");
            for (let e = 0; e < i.length; e++)
              if (R.isFrameWindowContainingWindow(i[e].contentWindow, t))
                return i[e];
            return null;
          }
          static isFrameWindowContainingWindow(e, t) {
            for (let i = 0; i < e.frames.length; i++)
              return (
                e.frames[i] === t ||
                R.isFrameWindowContainingWindow(e.frames[i], t)
              );
            return !1;
          }
          static isTop(e) {
            const t = R.indexOf(e);
            return -1 === t || t === R.windows.length - 1;
          }
          static getTopAccessibleWindow() {
            return R.windows[R.windows.length - 1];
          }
        }
        (R.INDEX_KEY = "lnt_z"), (R.windows = []);
        class M {
          static init() {
            const e = [];
            let t = c.getWindow();
            if ((e.push(t), (M.frameType = M.SIMPLE_PAGE), M.isInAFrame()))
              for (; t !== t.parent; )
                (t = t.parent),
                  M.isWindowDocumentAccessible(t)
                    ? (e.push(t),
                      c.getBodyElementTagNameChecked(t)
                        ? (M.frameType = M.IFRAME_WITH_PARENT_ACCESS)
                        : (M.frameType = M.FRAME_WITH_PARENT_ACCESS))
                    : (M.frameType = M.FRAME_OR_IFRAME_WITH_NO_PARENT_ACCESS);
            R.init(e), c.setTopAccessibleWindow(R.getTopAccessibleWindow());
          }
          static getFrameType() {
            return M.frameType;
          }
          static getWindowFrameOffset(e, t) {
            try {
              const i = R.getFrameElement(e, t);
              return ne.getWindowAbsolutePosition(e, i);
            } catch (e) {
              return C.notify(C.EXCEPTION_72), T.zero;
            }
          }
          static isInHead(e) {
            return e
              ? !(!e.parentNode || "HEAD" !== e.parentNode.tagName)
              : (C.notify(C.EXCEPTION_1317), !1);
          }
          static isInAFrame() {
            try {
              return document.location !== window.parent.location;
            } catch (e) {
              return !0;
            }
          }
          static isWindowDocumentAccessible(e) {
            try {
              return void 0 !== e.location.href;
            } catch (e) {
              return !1;
            }
          }
          static searchByIdInAllFrames(e, t, i) {
            const s = re.getWindowElementsById(e, i);
            return s.length > 0 ? s : M.recursiveDomIdSearch(t, i);
          }
          static recursiveDomIdSearch(e, t) {
            const i = re.getWindowElementsById(e, t);
            return i.length > 0 ? i : M.scanFrames(e, t);
          }
          static scanFrames(e, t) {
            const i = e.frames;
            for (let e = 0; e < i.length; e++)
              if (M.isWindowDocumentAccessible(i[e])) {
                const s = M.recursiveDomIdSearch(i[e], t);
                if (s.length > 0) return s;
              }
            return [];
          }
          static searchByCssSelectorInAllFrames(e, t, i) {
            return re.querySelector(e, i) || M.recursiveCssSelectorSearch(t, i);
          }
          static recursiveCssSelectorSearch(e, t) {
            return re.querySelector(e, t) || M.scanFramesCssSelector(e, t);
          }
          static scanFramesCssSelector(e, t) {
            const i = e.frames;
            for (let e = 0; e < i.length; e++)
              if (M.isWindowDocumentAccessible(i[e])) {
                const s = M.recursiveCssSelectorSearch(i[e], t);
                if (s) return s;
              }
            return null;
          }
          static isCrossDomain() {
            return M.frameType === M.FRAME_OR_IFRAME_WITH_NO_PARENT_ACCESS;
          }
          static isInIframeSameDomain() {
            return M.frameType === M.IFRAME_WITH_PARENT_ACCESS;
          }
          static isInIframe() {
            return M.isInIframeSameDomain() || M.isCrossDomain();
          }
          static isSimplePage() {
            return M.frameType === M.SIMPLE_PAGE;
          }
          static getContentWindow(e) {
            return e.contentWindow;
          }
          static getPositionRelativeToViewport(e, t) {
            let i = t,
              s = i.parent;
            if (!M.isWindowDocumentAccessible(s)) return null;
            let n = 0;
            for (; s && s !== i; ) {
              const t = M.getWindowFrameOffset(s, i).minus(
                c.getWindowScroll(s)
              );
              if (
                ((e = e.plus(t)),
                (i = s),
                (s = i.parent),
                !M.isWindowDocumentAccessible(s))
              )
                return null;
              if ((n++, n > 10)) return C.notify(C.EXCEPTION_61), null;
            }
            return e;
          }
        }
        (M.SIMPLE_PAGE = 0),
          (M.FRAME_WITH_PARENT_ACCESS = 1),
          (M.IFRAME_WITH_PARENT_ACCESS = 2),
          (M.FRAME_OR_IFRAME_WITH_NO_PARENT_ACCESS = 3),
          (M.frameType = 0);
        class L {
          static getCurrentScroll(e) {
            const t = e.document.createEvent("MouseEvents"),
              i = e.top;
            return (
              t.initMouseEvent("mouseover", !0, !0, i), new T(t.pageX, t.pageY)
            );
          }
        }
        class V {
          static getScreenLeft() {
            return c.getWindow().screenLeft;
          }
          static hasScreenLeft() {
            const e = c.getWindow().screenLeft;
            return void 0 !== e && "unknown" != typeof e;
          }
          static getScreenTop() {
            return c.getWindow().screenTop;
          }
          static hasScreenTop() {
            const e = c.getWindow().screenTop;
            return void 0 !== e && "unknown" != typeof e;
          }
          static getScreenX() {
            return c.getWindow().screenX;
          }
          static getScreenY() {
            return c.getWindow().screenY;
          }
        }
        class X {
          static getIframePosition(e) {
            const t = Math.round(e.mozInnerScreenX - e.screen.left),
              i = Math.round(e.mozInnerScreenY - e.screen.top);
            return new T(t, i);
          }
        }
        class k {
          createTrackingLoader() {
            return new W();
          }
          createTrackingLoaderXD() {
            return this.createTrackingLoader();
          }
        }
        class F {
          constructor() {
            this.durationDelayed = 0;
          }
          createViewPortFromTop(e) {
            return null;
          }
          getPercentVisible() {
            const e = W.getContainer();
            return e ? e.getVisibleRatio() : 1;
          }
          static isRealEvent() {
            return F._isRealEvent;
          }
          beforeShotCheck(e) {
            return (
              (e += this.durationDelayed),
              this.isTrackingInitialized()
                ? (this.durationDelayed = 0)
                : ((this.durationDelayed = e), (e = 0)),
              e
            );
          }
          afterCheckDuration() {}
          isTrackingInitialized() {
            const e = W.getContainer();
            return !e || e.isTrackingInitialized();
          }
          isTrackingSupported() {
            return !0;
          }
        }
        F._isRealEvent = !0;
        class W {
          getContentPanel() {
            return this.contentPanel;
          }
          constructor() {
            (this.contentPanel = null),
              (this.shotTimer = new u(() => {
                this.checkDurationAfterShot();
              }, C.EXCEPTION_2)),
              (this.shotTimerInterval = Nt.getUseIntersectionObserver()
                ? W.SHOT_TIMER_INTERVAL
                : W.SHOT_TIMER_INTERVAL_FAST),
              (this._isActiveAtLeastOne = !1),
              (this.mousePositionTracker = new D()),
              (W.trackingLoader = this);
          }
          start() {
            E.registerOrUpdateSessionId(),
              this.initInAppContext(),
              (this.activityHolder = new w(c.getTopAccessibleWindow())),
              A.registerHandlers(),
              this.initTrackDisplay(),
              St.processTags(),
              this.checkDuration(),
              this.shotTimer.scheduleRepeating(this.shotTimerInterval);
            const e = c.getWindow();
            je.registerNewScript(),
              je.registerScriptStatusFunction(e),
              je.registerActivityStatusFunction(e),
              je.registerTrkFinalize(),
              je.registerTrkForceIntermediateRequest(),
              r() ? C.notify(C.EXCEPTION_1309) : je.checkJsSignals();
          }
          initTrackDisplay() {
            this.trackDisplay = new F();
          }
          checkDurationAfterShot() {
            St.refreshContent(), this.searchElements(), this.checkDuration();
          }
          searchElements() {
            for (let e = 0; e < Pe.getTagCount(); e++) {
              const t = Pe.getTagAtIndex(e);
              try {
                t.searchElements();
              } catch (e) {
                C.notify(C.EXCEPTION_4);
              }
            }
          }
          checkDuration() {
            try {
              const e = W.isActive();
              e && (this._isActiveAtLeastOne = !0);
              const t = this.activityHolder.getLastShotTime();
              this.activityHolder.updateActivity();
              const i = this.activityHolder.getLastShotTime();
              W.container && W.container.refreshSdkStatus();
              for (let s = 0; s < Pe.getTagCount(); s++) {
                const n = Pe.getTagAtIndex(s);
                if (e) {
                  let e = i - t;
                  e < 0 &&
                    ((e = this.shotTimerInterval), C.notify(C.EXCEPTION_53)),
                    this.shotOnTag(n, e);
                } else if (!n.isFlushed()) {
                  let e = this.activityHolder.getLastEventTime() - t;
                  e < 0 && (e = 0), this.shotOnTag(n, e);
                }
              }
              for (let e = 0; e < Pe.getTagCount(); e++)
                Pe.getTagAtIndex(e).flushContentIfNeeded();
              Pe.postFlushCleanup(),
                this.contentPanel && this.contentPanel.updatePanel(),
                this.trackDisplay.afterCheckDuration();
            } catch (e) {
              C.notify(C.EXCEPTION_32);
            }
          }
          shotOnTag(e, t) {
            (t = this.trackDisplay.beforeShotCheck(t)),
              e.shot(),
              e.commitDuration(t);
          }
          onBrowserActiveEvent() {
            this.activityHolder.onActiveEvent();
          }
          onBrowserInactiveEvent() {
            this.activityHolder.onInactiveEvent(), this.checkDuration();
          }
          static sendIntermediateRequest() {
            if (!W.softRequestSent) {
              (W.softRequestSent = !0), W.trackingLoader.checkDuration();
              for (let e = Pe.getTagCount() - 1; e >= 0; e--)
                Pe.getTagAtIndex(e).sendIntermediateRequest(
                  Qe.RR_MOBILE_INTERMEDIATE_REQUEST
                );
            }
          }
          static sendNonMeasurableWebviewRequest() {
            W.trackingLoader.checkDuration();
            for (let e = Pe.getTagCount() - 1; e >= 0; e--)
              Pe.getTagAtIndex(e).sendIntermediateRequest(Qe.RR_NM_REQUEST);
          }
          static trkFinalize(e) {
            W.trackingLoader.checkDuration();
            for (let t = Pe.getTagCount() - 1; t >= 0; t--)
              Pe.getTagAtIndex(t).shutdown(e);
            try {
              u.closeRemainingTimers();
            } catch (e) {
              C.notify(C.EXCEPTION_11);
            }
          }
          getLastShotTime() {
            return this.activityHolder.getLastShotTime();
          }
          refreshActivity() {
            c.isHiddenWithWindow(c.getWindow()) || this.onBrowserActiveEvent();
          }
          static isActive() {
            return W.trackingLoader.activityHolder.isActive();
          }
          static inactiveEvent() {
            W.trackingLoader.onBrowserInactiveEvent();
          }
          isTrackingSupported() {
            return (
              (!W.container || W.container.isAppSupported()) &&
              (!this.trackDisplay || this.trackDisplay.isTrackingSupported())
            );
          }
          isActiveAtLeastOne() {
            return this._isActiveAtLeastOne;
          }
          getCrossDomainIframePosition() {
            return T.minusOne;
          }
          getMousePositionTracker() {
            return this.mousePositionTracker;
          }
          static getContainer() {
            return W.container;
          }
          static setContainer(e) {
            W.container = e;
          }
          static checkDurationStatic() {
            W.trackingLoader.checkDurationUnplanned();
          }
          checkDurationUnplanned() {
            this.shotTimer.cancel(),
              this.shotTimer.scheduleRepeating(this.shotTimerInterval),
              this.checkDuration();
          }
          initInAppContext() {
            try {
              const e = c.getTopAccessibleWindow();
              if (ge.isMicrosoftSDK(e)) {
                const e = new ge();
                e.init(), W.setContainer(e);
              } else if (he.isOmidSupported()) {
                const e = new he();
                W.setContainer(e), e.init();
              } else if (Te.hasAnjamNamespaceNative(e))
                Te.initAppNexusSDKMraidContainer();
              else if (le.isAvailable(e)) W.setContainer(new le());
              else if (ue.isAvailable(e)) {
                const e = new ue();
                e.init(), W.setContainer(e);
              } else if (_e.isInAppSupplyType() || c.isAppUserAgent()) {
                const e = Oe.getHybridAppContainerIfAvailable();
                if (e) W.setContainer(e);
                else if (M.isCrossDomain() && this.isTrackingSupported())
                  Te.checkAppNexusSDKContext();
                else {
                  const e = new oe();
                  W.setContainer(e);
                }
              }
            } catch (e) {
              C.notify(C.EXCEPTION_176);
            }
          }
          static getLastReferenceElement() {
            return W.lastReferenceElement;
          }
          static setLastReferenceElement(e) {
            W.lastReferenceElement = e;
          }
        }
        (W.softRequestSent = !1),
          (W.SHOT_TIMER_INTERVAL = 1e3),
          (W.SHOT_TIMER_INTERVAL_FAST = 100),
          (W.lastReferenceElement = null),
          (W.container = null);
        class U extends k {
          createTrackingLoaderXD() {
            return new j();
          }
        }
        class x extends k {
          createTrackingLoaderXD() {
            return new q();
          }
        }
        class B extends k {
          createTrackingLoaderXD() {
            return new G();
          }
        }
        class H extends k {
          createTrackingLoaderXD() {
            return new K();
          }
        }
        class z extends F {
          constructor() {
            super(),
              (this.lastScroll = T.zero),
              (this.hasReceivedOneEventAtLeast = !1);
            const e = c.getTopAccessibleWindow();
            (this.divElement = this.getOrCreateReferenceElement(e)),
              se.addEventListenerWithEventListenerWrapper(
                e,
                this.divElement,
                "click",
                new O(C.EXCEPTION_180, (e) => {
                  e && this.refreshScrollPosition(e);
                })
              );
            try {
              this.doClick(this.divElement);
            } catch (e) {
              C.notify(C.EXCEPTION_181);
            }
          }
          getOrCreateReferenceElement(e) {
            let t = W.getLastReferenceElement();
            return t || (t = be.createFakeImageElementNative(e, null, !0)), t;
          }
          getAvailableScreenSize(e) {
            return new T(e.outerWidth, e.outerHeight);
          }
          refreshScrollPosition(e) {
            let t = null;
            V.hasScreenLeft() &&
              V.hasScreenTop() &&
              ((t = new T(e.x + V.getScreenLeft(), e.y + V.getScreenTop())),
              t.equals(this.lastScroll) ||
                (A.onActiveEvent(), (this.lastScroll = t))),
              e.stopPropagation(),
              e.preventDefault(),
              (this.hasReceivedOneEventAtLeast = !0);
          }
          doClick(e) {
            e.click();
          }
          getPercentVisible() {
            try {
              this.doClick(this.divElement);
            } catch (e) {
              C.notify(C.EXCEPTION_181);
            }
            let e = this.getAvailableScreenSize(c.getTopAccessibleWindow());
            e = e.minus(new T(z.SCREEN_MARGIN_RIGHT, z.SCREEN_MARGIN_BOTTOM));
            const t = c.getWindowSize(c.getTopAccessibleWindow());
            let i = null;
            if (!V.hasScreenLeft() || !V.hasScreenTop()) return 0;
            i = new T(
              V.getScreenLeft() - z.IFRAME_MARGIN_LEFT - V.getScreenX(),
              V.getScreenTop() - z.IFRAME_MARGIN_TOP - V.getScreenY()
            );
            const s = T.zero.max(
                i
                  .plus(t)
                  .min(e.plus(this.lastScroll))
                  .minus(i.max(this.lastScroll))
              ),
              n = t.getX() * t.getY(),
              r = n > 0 ? (s.getX() * s.getY()) / n : 0;
            return super.getPercentVisible() * r;
          }
          isTrackingInitialized() {
            return (
              this.hasReceivedOneEventAtLeast && super.isTrackingInitialized()
            );
          }
        }
        (z.IFRAME_MARGIN_LEFT = 8),
          (z.IFRAME_MARGIN_TOP = 92),
          (z.SCREEN_MARGIN_RIGHT = 33),
          (z.SCREEN_MARGIN_BOTTOM = 102);
        class j extends W {
          constructor() {
            super(...arguments), (this.scrollPosition = T.zero);
          }
          checkDuration() {
            try {
              const e = L.getCurrentScroll(c.getTopAccessibleWindow());
              e.equals(this.scrollPosition) ||
                ((this.scrollPosition = e), A.onActiveEvent());
            } catch (e) {
              C.notify(C.EXCEPTION_109);
            }
            super.checkDuration();
          }
        }
        class q extends W {
          initTrackDisplay() {
            this.trackDisplay = new z();
          }
          getCrossDomainIframePosition() {
            if (V.hasScreenLeft() && V.hasScreenTop()) {
              const e = V.getScreenTop(),
                t = V.getScreenLeft();
              return new T(t, e);
            }
            return T.minusOne;
          }
        }
        class G extends W {
          constructor() {
            super(...arguments),
              (this.iframePosition = X.getIframePosition(
                c.getTopAccessibleWindow()
              ));
          }
          initTrackDisplay() {
            super.initTrackDisplay(),
              (this.originalIframePosition = X.getIframePosition(
                c.getTopAccessibleWindow()
              )),
              (this.iframePosition = this.originalIframePosition);
          }
          getCrossDomainIframePosition() {
            return this.originalIframePosition;
          }
          checkDuration() {
            const e = X.getIframePosition(c.getTopAccessibleWindow());
            this.iframePosition.equals(e) ||
              ((this.iframePosition = e), A.onActiveEvent()),
              super.checkDuration();
          }
        }
        class K extends W {
          getCrossDomainIframePosition() {
            const e = V.getScreenTop(),
              t = V.getScreenLeft();
            return new T(t, e);
          }
        }
        class $ {
          isCSSvisible(e, t) {
            try {
              const i = e.getComputedStyle;
              if (se.isFunctionNative(i)) {
                const e = i(t, "");
                return !(!e || !e.visibility) && "visible" === e.visibility;
              }
              C.notify(C.EXCEPTION_1035);
            } catch (e) {
              return C.notify(C.EXCEPTION_23), !1;
            }
            return !0;
          }
          getElementWindow(e) {
            return e.ownerDocument.defaultView;
          }
          addEventListenerActive(e, t, i) {
            e.addEventListener(t, (e) => {
              i.setEvent(e), i.execute();
            });
          }
          addEventListenerWithEventListenerWrapper(e, t, i, s) {
            t.addEventListener(
              i,
              (e) => {
                s.setEvent(e), s.execute();
              },
              { passive: !0 }
            );
          }
          addEventListenerWithExceptionSafeCommand(e, t, i) {
            e.addEventListener(
              t,
              (e) => {
                i.execute();
              },
              { passive: !0 }
            );
          }
        }
        class Y extends $ {}
        class J extends Y {
          addEventListenerWithEventListenerWrapper(e, t, i, s) {
            t.addEventListener(i, (e) => {
              s.setEvent(e), s.execute();
            });
          }
          addEventListenerWithExceptionSafeCommand(e, t, i) {
            e.addEventListener(t, () => {
              i.execute();
            });
          }
        }
        class Q {
          getElementAttribute(e, t) {
            return e.getAttribute(t) || null;
          }
          getWindowElementsById(e, t) {
            const i = [],
              s = e.document.getElementsByTagName("*");
            for (let e = 0; e < s.length; e++) s[e].id === t && i.push(s[e]);
            return i;
          }
          getWindowElementById(e, t) {
            return e.document.getElementById(t) || null;
          }
          getElementProperty(e, t) {
            const i = e[t];
            return i ? String(i) : null;
          }
          getFirstChild(e) {
            return e.firstElementChild;
          }
          getLastChild(e) {
            return e.lastElementChild;
          }
          getNextSibling(e) {
            return e.nextElementSibling;
          }
          getPreviousSibling(e) {
            return e.previousElementSibling;
          }
          getParent(e) {
            let t = e.parentNode;
            return t ? (1 !== t.nodeType && (t = null), t || null) : null;
          }
          querySelector(e, t) {
            return e.document.querySelector(t);
          }
        }
        class Z extends Q {}
        class ee {
          getWindowAbsolutePosition(e, t) {
            let i = 0,
              s = 0,
              n = t;
            for (; n.offsetParent; )
              (i -= n.scrollLeft), (s -= n.scrollTop), (n = n.parentNode);
            for (; t; )
              (i += t.offsetLeft), (s += t.offsetTop), (t = t.offsetParent);
            return new T(Math.round(i), Math.round(s));
          }
        }
        class te extends ee {
          getWindowAbsolutePosition(e, t) {
            if (null === t.offsetLeft || void 0 === t.offsetLeft)
              return new T(0, 0);
            let i = 0,
              s = t.parentNode;
            if (s)
              for (; s.offsetParent; ) (i -= s.scrollLeft), (s = s.parentNode);
            let n = t;
            for (; n; ) {
              i += n.offsetLeft;
              const e = n.offsetParent;
              if (e && "BODY" === e.tagName && "absolute" === n.style.position)
                break;
              n = e;
            }
            const r = e.getComputedStyle(e.document.documentElement, ""),
              a = Math.round(
                t.getBoundingClientRect().top +
                  parseInt(r.borderTopWidth, 10) +
                  e.scrollY
              );
            return new T(Math.round(i), Math.round(a));
          }
        }
        class ie extends ee {
          getWindowAbsolutePosition(e, t) {
            const i = e.document.documentElement,
              s = e.getComputedStyle(i, "");
            let n = 0,
              r = 0;
            if (s) {
              const e = t.getBoundingClientRect();
              (n = Math.round(
                e.left + parseInt(s.borderLeftWidth, 10) + i.scrollLeft
              )),
                (r = Math.round(
                  e.top + parseInt(s.borderTopWidth, 10) + i.scrollTop
                ));
            }
            return new T(n, r);
          }
        }
        class se {
          static setAttribute(e, t, i) {
            e[t] = i;
          }
          static getAttribute(e, t) {
            return e[t] ? e[t] : "";
          }
          static getElementsByTagName(e, t) {
            const i = [],
              s = e.document.getElementsByTagName(t);
            for (let e = 0; e < s.length; e++) i.push(s.item(e));
            return i;
          }
          static isNullOrParentNull(e) {
            if (!e) return !0;
            const t = se.getAttribute(e, "nodeName").toUpperCase();
            if ("BODY" === t || "HEAD" === t) return !1;
            let i = n(e);
            return (
              i || (i = se.getWebComponentHostIfExist(e)),
              se.isNullOrParentNull(i)
            );
          }
          static getWebComponentHostIfExist(e) {
            return e.parentNode && e.parentNode.host ? e.parentNode.host : null;
          }
          static isCSSvisible(e, t) {
            return se.impl.isCSSvisible(e, t);
          }
          static getElementWindow(e) {
            return se.impl.getElementWindow(e);
          }
          static addEventListenerActive(e, t, i) {
            se.impl.addEventListenerActive(e, t, i);
          }
          static addEventListenerWithEventListenerWrapper(e, t, i, s) {
            se.impl.addEventListenerWithEventListenerWrapper(e, t, i, s);
          }
          static addEventListenerWithExceptionSafeCommand(e, t, i) {
            se.impl.addEventListenerWithExceptionSafeCommand(e, t, i);
          }
          static isFunctionNative(e) {
            return void 0 !== e && -1 !== ("" + e).indexOf("native");
          }
          static getOffsetSize(e) {
            const t = e,
              i = t.offsetWidth || 0,
              s = t.offsetHeight || 0;
            return new T(i, s);
          }
          static getSize(e) {
            const t = parseInt(e.width, 10) || 0,
              i = parseInt(e.height, 10) || 0;
            return new T(t, i);
          }
          static getMaxSize(e) {
            return se.getOffsetSize(e).max(se.getSize(e));
          }
          static getAccessibleParentWindow(e) {
            let t = e;
            for (; t !== t.parent; ) {
              if (M.isWindowDocumentAccessible(t.parent)) return t.parent;
              t = t.parent;
            }
            return null;
          }
        }
        (() => {
          const e = p();
          se.impl = "ie11" === e ? new J() : new Y();
        })();
        class ne {
          static getWindowAbsolutePosition(e, t) {
            return ne.impl.getWindowAbsolutePosition(e, t);
          }
        }
        (() => {
          const e = p();
          ne.impl = "gecko40" === e || "ie11" === e ? new ie() : new te();
        })();
        class re {
          static getElementAttribute(e, t) {
            return re.impl.getElementAttribute(e, t);
          }
          static getWindowElementById(e, t) {
            return re.impl.getWindowElementById(e, t);
          }
          static getWindowElementsById(e, t) {
            return re.impl.getWindowElementsById(e, t);
          }
          static getElementProperty(e, t) {
            return re.impl.getElementProperty(e, t);
          }
          static getFirstChild(e) {
            return re.impl.getFirstChild(e);
          }
          static getLastChild(e) {
            return re.impl.getLastChild(e);
          }
          static getNextSibling(e) {
            return re.impl.getNextSibling(e);
          }
          static getPreviousSibling(e) {
            return re.impl.getPreviousSibling(e);
          }
          static getParent(e) {
            return re.impl.getParent(e);
          }
          static querySelector(e, t) {
            return re.impl.querySelector(e, t);
          }
        }
        re.impl = new Z();
        class ae {
          constructor() {
            (this.partnerName = null),
              (this.adSize = T.minusOne),
              (this.adPosition = T.minusOne),
              (this.isSdkContainerUsableCache = !1),
              (this.visibleRatio = 0);
          }
          isTrackingInitialized() {
            return this.isSdkContainerUsableCache;
          }
          getVisibleRatio() {
            return this.visibleRatio;
          }
          shutDown() {
            this.isAppSupported() &&
              !this.isTrackingInitialized() &&
              C.notify(C.EXCEPTION_1160);
          }
          static hasMraidNamespace(e) {
            return void 0 !== e.mraid && "function" == typeof e.mraid.getState;
          }
          getPartnerName() {
            return this.partnerName;
          }
          getAdSize() {
            return this.adSize;
          }
          getAdPosition() {
            return this.adPosition;
          }
          getDebugGeometricInfo(e) {
            return [];
          }
        }
        class oe extends ae {
          init() {}
          isAppSupported() {
            return !1;
          }
          isTrackingInitialized() {
            return !1;
          }
          getContainerType() {
            return I.NOT_SUPPORTED_SDK;
          }
          isUsable() {
            return !1;
          }
          getVisibleRatioRefreshed() {
            return 0;
          }
          refreshSdkStatus() {}
        }
        class ce extends ae {
          init() {}
          isAppSupported() {
            return !0;
          }
          isTrackingInitialized() {
            return !1;
          }
          getContainerType() {
            return I.NOT_INITIALIZED_SDK;
          }
          isUsable() {
            return !1;
          }
          getVisibleRatioRefreshed() {
            return 0;
          }
          refreshSdkStatus() {}
        }
        class le extends oe {
          getContainerType() {
            return I.SMAATO_SDK;
          }
          static isAvailable(e) {
            return d.elementHasDefined(e, "smaato_bridge");
          }
        }
        class he extends ae {
          constructor() {
            super(...arguments),
              (this.hasReceivedGeometryChangeEventAtLeastOnce = !1),
              (this.sessionStart = null),
              (this.verificationClient = null),
              (this.hasRegisteredNewTag = !1),
              (this.adLastObstructionSize = T.minusOne),
              (this.adLastObstructionPosition = T.minusOne),
              (this.nbObstruction = 0),
              (this.nonVisibleReasons = ""),
              (this.callBackGeometryChange = new O(C.EXCEPTION_201, (e) => {
                if (this.hasEventTimestamp(e)) {
                  const t = this.extractEventTimestamp(e);
                  this.isPastEvent(t) || W.checkDurationStatic();
                }
                (this.hasReceivedGeometryChangeEventAtLeastOnce = !0),
                  this.sessionStart &&
                  this.sessionStart.isOMSDKForWeb() &&
                  this.sessionStart.getCreativeElement()
                    ? ((this.visibleRatio = 1), C.notify(C.EXCEPTION_1341))
                    : this.hasPercentageInView(e) &&
                      (this.visibleRatio = this.extractPercentageInView(e)),
                  this.refreshAdSizeAndPosition(e),
                  this.refreshObstruction(e),
                  this.refreshReasons(e);
              })),
              (this.sessionObserverCallback = new O(C.EXCEPTION_202, (e) => {
                const t = this.getEventType(e);
                if ("sessionStart" === t) {
                  if (
                    ((this.sessionStart = new pe(e)),
                    this.sessionStart.getOmidParameters().length > 0)
                  ) {
                    const e = this.sessionStart
                      .getOmidParameters()
                      .replace(g.getScriptId(), "");
                    St.handleNewTagURL(
                      this.sessionStart.getCreativeElement(),
                      e
                    );
                  }
                  if (Pe.getTagCount() > 0)
                    for (let e = 0; e < Pe.getTagCount(); e++)
                      this.registerNewTag(Pe.getTagAtIndex(e));
                } else
                  "sessionFinish" === t
                    ? W.trkFinalize(Qe.RR_OMID_SESSION_FINISH)
                    : "sessionError" === t && C.notify(C.EXCEPTION_207);
              }));
          }
          isOMIDContextWithoutCreativeAccess() {
            return (
              !!this.sessionStart &&
              this.sessionStart.isOMIDContextWithoutCreativeAccess()
            );
          }
          getEventType(e) {
            return void 0 !== e && void 0 !== e.type ? e.type : null;
          }
          registerNewTag(e) {
            this.sessionStart &&
              !this.hasRegisteredNewTag &&
              ((this.hasRegisteredNewTag = !0),
              this.sessionStart.isSupportedPartner()
                ? (se.addEventListenerActive(
                    this.verificationClient,
                    "geometryChange",
                    this.callBackGeometryChange
                  ),
                  se.addEventListenerActive(
                    this.verificationClient,
                    "impression",
                    this.callBackGeometryChange
                  ),
                  (this.isSdkContainerUsableCache = !0))
                : (C.notify(C.EXCEPTION_1306),
                  e.sendIntermediateRequest(Qe.RR_NM_REQUEST)));
          }
          init() {
            try {
              (this.verificationClient = this.initVerificationClient(
                he.getOmidVerificationClientModule()
              )),
                this.registerSessionObserver(
                  this.verificationClient,
                  this.sessionObserverCallback,
                  he.VENDOR_KEY
                ),
                "iOS" === g.getPlatform() &&
                  this.registerTimerFunction(this.verificationClient);
            } catch (e) {
              C.notify(C.EXCEPTION_200);
            }
          }
          refreshSdkStatus() {}
          registerTimerFunction(e) {
            e && u.setTimerNamespace(e);
          }
          registerSessionObserver(e, t, i) {
            e.registerSessionObserver((e) => {
              t.setEvent(e), t.execute();
            }, i);
          }
          static getOmidVerificationClientModule() {
            return m.getJsModule("OmidVerificationClient");
          }
          initVerificationClient(e) {
            const t = Object.keys(e)[0],
              i = c.getNamespace();
            globalThis.omidVerificationProperties;
            try {
              i.omc = new e[t]();
            } finally {
            }
            return i.omc;
          }
          hasPercentageInView(e) {
            return (
              void 0 !== e &&
              void 0 !== e.data &&
              void 0 !== e.data.adView &&
              void 0 !== e.data.adView.percentageInView
            );
          }
          hasEventTimestamp(e) {
            return void 0 !== e && void 0 !== e.timestamp;
          }
          extractEventTimestamp(e) {
            return e.timestamp;
          }
          isPastEvent(e) {
            return new Date().valueOf() - e > 100;
          }
          extractPercentageInView(e) {
            return 0.01 * e.data.adView.percentageInView;
          }
          refreshAdSizeAndPosition(e) {
            if (void 0 !== e && void 0 !== e.data && void 0 !== e.data.adView) {
              const t = e.data.adView.geometry;
              if (void 0 !== t) {
                const e = t.width,
                  i = t.height,
                  s = t.x,
                  n = t.y;
                void 0 !== e &&
                  void 0 !== i &&
                  (this.adSize = new T(Math.round(e), Math.round(i))),
                  void 0 !== s &&
                    void 0 !== n &&
                    (this.adPosition = new T(Math.round(s), Math.round(n)));
              }
            }
          }
          refreshReasons(e) {
            if (void 0 !== e && void 0 !== e.data && void 0 !== e.data.adView) {
              const t = e.data.adView.reasons;
              if (void 0 !== t && t.length > 0) {
                let e = "";
                for (let i = 0; i < t.length; i++)
                  (e += t[i]), i + 1 < t.length && (e += "-");
                this.nonVisibleReasons = e;
              }
            }
          }
          refreshObstruction(e) {
            if (void 0 !== e && void 0 !== e.data && void 0 !== e.data.adView) {
              const t = e.data.adView.onScreenGeometry;
              if (void 0 !== t && void 0 !== t.obstructions) {
                const e = t.obstructions,
                  i = e.length;
                if (i > 0) {
                  const t = e[i - 1],
                    s = t.width,
                    n = t.height,
                    r = t.x,
                    a = t.y;
                  void 0 !== s &&
                    void 0 !== n &&
                    (this.adLastObstructionSize = new T(
                      Math.round(s),
                      Math.round(n)
                    )),
                    void 0 !== r &&
                      void 0 !== a &&
                      (this.adLastObstructionPosition = new T(
                        Math.round(r),
                        Math.round(a)
                      )),
                    (this.nbObstruction = i);
                }
              }
            }
          }
          isAppSupported() {
            return !this.sessionStart || this.sessionStart.isSupportedPartner();
          }
          static isOmidSupported() {
            return (
              !!he.getOmidVerificationClientModule() &&
              (r()
                ? he.isOmidSupportedNativeJSContext()
                : !(
                    It.isXdrViewApiHasBeenUsedAlready() &&
                    !St.isBannerOrNativeCreative()
                  ) &&
                  (!!St.isOmidByDefault() ||
                    (!!he.isOmidAvailableNative(c.getTopAccessibleWindow()) &&
                      St.canHandleOmsdk())))
            );
          }
          static isOmidSupportedNativeJSContext() {
            return void 0 !== globalThis.omid;
          }
          static isOmidAvailableNative(e) {
            return (
              void 0 !== e.omid ||
              void 0 !== globalThis.omidVerificationProperties
            );
          }
          isUsable() {
            return !0;
          }
          getPartnerName() {
            return this.sessionStart
              ? this.sessionStart.getPartnerName()
              : null;
          }
          getContainerType() {
            return this.sessionStart
              ? this.sessionStart.isOMIDContextWithoutCreativeAccess()
                ? I.OM_SDK_LIMITED
                : I.OM_SDK_FULL
              : I.OM_SDK_UNKNOWN;
          }
          getVisibleRatioRefreshed() {
            return this.visibleRatio;
          }
          shutDown() {
            super.shutDown(),
              this.sessionStart || C.notify(C.EXCEPTION_1304),
              this.hasReceivedGeometryChangeEventAtLeastOnce ||
                C.notify(C.EXCEPTION_1305);
          }
          isAppnexusPartner() {
            return !!this.sessionStart && this.sessionStart.isAppnexusPartner();
          }
          setVideoListener(e) {
            se.addEventListenerActive(this.verificationClient, "video", e);
          }
          isAsync(e) {
            return !!this.sessionStart && this.sessionStart.isAsync(e);
          }
          getLastAdObstructionSize() {
            return this.adLastObstructionSize;
          }
          getLastAdObstructionPosition() {
            return this.adLastObstructionPosition;
          }
          getNbObstruction() {
            return this.nbObstruction;
          }
          getNonVisibleOmsdkReason() {
            return this.nonVisibleReasons;
          }
          getDebugGeometricInfo(e) {
            const t = [];
            return (
              t.push("obsn" + e + this.nbObstruction),
              this.nbObstruction > 0 &&
                (t.push("obsx" + e + this.adLastObstructionPosition.getX()),
                t.push("obsy" + e + this.adLastObstructionPosition.getY()),
                t.push("obsw" + e + this.adLastObstructionSize.getX()),
                t.push("obsh" + e + this.adLastObstructionSize.getY())),
              t.push("adx" + e + this.adPosition.getX()),
              t.push("ady" + e + this.adPosition.getY()),
              t.push("adw" + e + this.adSize.getX()),
              t.push("adh" + e + this.adSize.getY()),
              "" !== this.getNonVisibleOmsdkReason() &&
                t.push("nvomr" + e + this.getNonVisibleOmsdkReason()),
              t
            );
          }
        }
        he.VENDOR_KEY = "appnexus.com-omid";
        class de {
          static addMraidEventListenerNative(e, t, i) {
            const s = (e) => {
              i.execute();
            };
            return e.mraid.addEventListener(t, s), s;
          }
          static addMraidEventListenerNativeWithEvent(e, t, i) {
            const s = (e) => {
              i.setEvent(e), i.execute();
            };
            return e.mraid.addEventListener(t, s), s;
          }
          static isLoadingState(e) {
            return "loading" === e.mraid.getState();
          }
          static hasPositionUsableNative(e) {
            if (!de.isUsableNative(e)) return !1;
            const t = e.mraid.getCurrentPosition(),
              i = e.mraid.getScreenSize();
            return (
              !!t &&
              !!i &&
              void 0 !== t.x &&
              void 0 !== t.y &&
              void 0 !== t.width &&
              void 0 !== t.height &&
              void 0 !== i.width &&
              void 0 !== i.height
            );
          }
          static isUsableNative(e) {
            return (
              void 0 !== e.mraid &&
              "function" == typeof e.mraid.getState &&
              "function" == typeof e.mraid.getCurrentPosition &&
              "function" == typeof e.mraid.getScreenSize &&
              "function" == typeof e.mraid.isViewable &&
              !de.isLoadingState(e)
            );
          }
          static isMraidViewable(e) {
            return e.mraid.isViewable();
          }
          static getVisibleRatioRefreshed() {
            const e = c.getTopAccessibleWindow();
            if ("hidden" === e.mraid.getState()) return 0;
            if (!de.isMraidViewable(e)) return 0;
            if (!de.hasPositionUsableNative(e)) return 0;
            const t = e.mraid.getCurrentPosition(),
              i = e.mraid.getScreenSize();
            return (
              (Math.max(
                0,
                Math.min(t.x + t.width, i.width) - Math.max(t.x, 0)
              ) *
                Math.max(
                  0,
                  Math.min(t.y + t.height, i.height) - Math.max(t.y, 0)
                )) /
              (t.width * t.height)
            );
          }
        }
        class ue extends ae {
          constructor() {
            super(...arguments),
              (this.callBackMraidReady = new h(C.EXCEPTION_169, () => {
                this.onReadyEvent();
              })),
              (this.callBackViewableDataChange = new h(C.EXCEPTION_174, () => {
                this.refreshSdkStatus(), W.checkDurationStatic();
              }));
          }
          init() {
            if (this.isAppSupported()) {
              const e = c.getTopAccessibleWindow();
              de.isLoadingState(e)
                ? de.addMraidEventListenerNative(
                    e,
                    "ready",
                    this.callBackMraidReady
                  )
                : de.addMraidEventListenerNative(
                    e,
                    "viewableDataChange",
                    this.callBackViewableDataChange
                  );
            }
          }
          onReadyEvent() {
            de.addMraidEventListenerNative(
              c.getTopAccessibleWindow(),
              "viewableDataChange",
              this.callBackViewableDataChange
            );
          }
          getContainerType() {
            return I.MOPUB_SDK;
          }
          isAppSupported() {
            return (
              d.isSafariMobile() &&
              ue.hasMraidNamespace(c.getTopAccessibleWindow())
            );
          }
          static isAvailable(e) {
            return (
              !!d.elementHasDefined(e, "mopubFinishLoad") ||
              (!M.isCrossDomain() &&
                -1 !== e.location.href.indexOf("//ads.mopub.com/"))
            );
          }
          refreshSdkStatus() {
            if (
              (this.isSdkContainerUsableCache ||
                (this.isAppSupported() &&
                  (M.isCrossDomain() ||
                    (this.isUsable() &&
                      (this.isSdkContainerUsableCache = !0)))),
              this.isSdkContainerUsableCache)
            )
              try {
                this.visibleRatio = this.getVisibleRatioRefreshed();
              } catch (e) {
                C.notify(C.EXCEPTION_161), (this.visibleRatio = 0);
              }
          }
          isUsable() {
            return de.isUsableNative(c.getTopAccessibleWindow());
          }
          getVisibleRatioRefreshed() {
            return de.getVisibleRatioRefreshed();
          }
        }
        class ge extends ae {
          constructor() {
            super(...arguments),
              (this.appHasFocus = !1),
              (this.adOccluded = !1),
              (this.adOnScreenPercentage = 0),
              (this.adOpacity = 0),
              (this.hasBeenVisibleOnce = !1),
              (this.hasBeenInFocusOnce = !1),
              (this.hasReceivedViewableDataChangeEventOnce = !1),
              (this.callBackOnReady = new h(C.EXCEPTION_173, () => {
                this.onReadyEvent();
              })),
              (this.callBackViewableDataChange = new O(C.EXCEPTION_175, (e) => {
                C.notify(C.EXCEPTION_1174),
                  (this.hasReceivedViewableDataChangeEventOnce = !0),
                  this.refreshMicrosoftMraidStatus(
                    e,
                    c.getTopAccessibleWindow()
                  );
              }));
          }
          init() {
            if (this.isAppSupported()) {
              const e = c.getTopAccessibleWindow();
              if (de.isLoadingState(e))
                try {
                  de.addMraidEventListenerNative(
                    e,
                    "ready",
                    this.callBackOnReady
                  );
                } catch (e) {
                  C.notify(C.EXCEPTION_169);
                }
              else this.onReadyEvent();
            }
          }
          refreshSdkStatus() {
            if (
              (!this.isSdkContainerUsableCache &&
                this.isAppSupported() &&
                (this.isSdkContainerUsableCache = !0),
              this.isSdkContainerUsableCache)
            )
              try {
                !this.hasBeenVisibleOnce &&
                  this.adOnScreenPercentage > 0 &&
                  ((this.hasBeenVisibleOnce = !0), C.notify(C.EXCEPTION_1172)),
                  !this.hasBeenInFocusOnce &&
                    this.appHasFocus &&
                    ((this.hasBeenInFocusOnce = !0),
                    C.notify(C.EXCEPTION_1173)),
                  (this.visibleRatio = this.getVisibleRatioRefreshed());
              } catch (e) {
                C.notify(C.EXCEPTION_161), (this.visibleRatio = 0);
              }
          }
          onReadyEvent() {
            if (this.isSdkVersionSupported(c.getTopAccessibleWindow()))
              try {
                de.addMraidEventListenerNativeWithEvent(
                  c.getTopAccessibleWindow(),
                  "viewableDataChange",
                  this.callBackViewableDataChange
                );
              } catch (e) {
                C.notify(C.EXCEPTION_174);
              }
            else W.sendNonMeasurableWebviewRequest();
          }
          getMapleDataForDebug() {
            return `appHasFocus=${this.appHasFocus}&adOccluded=${
              this.adOccluded
            }&adOnScreenPercentage=${this.adOnScreenPercentage}&adOpacity=${
              this.adOpacity
            }&is_basic_visi=${this.isMraidBasicVisible(
              c.getTopAccessibleWindow()
            )}&get_perc=${this.getVisibleRatio()}`;
          }
          refreshMicrosoftMraidStatus(e, t) {
            const i = JSON.parse(e);
            (this.appHasFocus = i.appHasFocus),
              (this.adOccluded = i.adOccluded),
              (this.adOnScreenPercentage = i.adOnScreenPercentage),
              (this.adOpacity = i.adOpacity),
              (this.visibleRatio = this.getVisibleRatioRefreshed()),
              W.checkDurationStatic();
          }
          isAppSupported() {
            const e = c.getTopAccessibleWindow();
            return (
              !this.hasSdkVersionAvailable(e) || this.isSdkVersionSupported(e)
            );
          }
          hasSdkVersionAvailable(e) {
            try {
              return void 0 !== e.maple.getSdkVersion();
            } catch (e) {
              return !1;
            }
          }
          isSdkVersionSupported(e) {
            try {
              return (
                void 0 !== e.maple.getSdkVersion() &&
                e.maple.getSdkVersion().sdkVersion.split(".")[0] >= 8
              );
            } catch (e) {
              return !1;
            }
          }
          static isMicrosoftSDK(e) {
            return (
              void 0 !== e.maple &&
              "function" == typeof e.maple.getSdkVersion &&
              void 0 !== e.mraid &&
              "function" == typeof e.mraid.getState &&
              "function" == typeof e.mraid.addEventListener
            );
          }
          getVisibleRatioRefreshed() {
            return !this.adOccluded &&
              this.appHasFocus &&
              0 !== this.adOpacity &&
              this.isMraidBasicVisible(c.getTopAccessibleWindow())
              ? this.adOnScreenPercentage
              : 0;
          }
          isMraidBasicVisible(e) {
            return "hidden" !== e.mraid.getState();
          }
          isUsable() {
            return !0;
          }
          getContainerType() {
            return I.MICROSOFT_SDK;
          }
          shutDown() {
            super.shutDown(),
              this.isAppSupported() &&
                this.isTrackingInitialized() &&
                !this.hasReceivedViewableDataChangeEventOnce &&
                C.notify(C.EXCEPTION_1175);
          }
        }
        class Ee extends ae {
          init() {
            this.visibleRatio = 1;
          }
          isAppSupported() {
            return !0;
          }
          isTrackingInitialized() {
            return !0;
          }
          getContainerType() {
            return I.HYBRID_APP;
          }
          isUsable() {
            return !0;
          }
          refreshSdkStatus() {}
          getVisibleRatioRefreshed() {
            return 1;
          }
        }
        class Te extends ae {
          constructor() {
            super(...arguments),
              (this.callBackInitWithMraidFrequencyUpdate = new h(
                C.EXCEPTION_186,
                () => {
                  this.refreshSdkStatus(),
                    this.updateMraidRefreshFrequency(
                      c.getTopAccessibleWindow(),
                      Te.mraidRefreshFrequency
                    );
                }
              )),
              (this.callBackInitWithoutMraidFrequencyUpdate = new h(
                C.EXCEPTION_186,
                () => {
                  this.refreshSdkStatus();
                }
              )),
              (this.callbackReadyEvent = null),
              (this.callbackStateChangedEvent = null);
          }
          static initAppNexusSDKMraidContainer() {
            Te.setMraidRefreshFrequency(Te.DEFAULT_MRAID_REFRESH_FREQUENCY);
            const e = new Te();
            e.init(), W.setContainer(e);
          }
          init() {
            M.isCrossDomain() || this.insertMraid();
            const e = c.getTopAccessibleWindow(),
              t = Te.hasMraidNamespace(e) && de.isLoadingState(e);
            0 !== Te.mraidRefreshFrequency && d.isSafariMobile()
              ? t
                ? ((this.callbackReadyEvent = de.addMraidEventListenerNative(
                    e,
                    "ready",
                    this.callBackInitWithMraidFrequencyUpdate
                  )),
                  (this.callbackStateChangedEvent =
                    de.addMraidEventListenerNative(
                      e,
                      "stateChange",
                      this.callBackInitWithoutMraidFrequencyUpdate
                    )))
                : Te.hasMraidNamespace(e) &&
                  (this.updateMraidRefreshFrequency(
                    e,
                    Te.mraidRefreshFrequency
                  ),
                  (this.callbackStateChangedEvent =
                    de.addMraidEventListenerNative(
                      e,
                      "stateChange",
                      this.callBackInitWithoutMraidFrequencyUpdate
                    )))
              : t &&
                ((this.callbackReadyEvent = de.addMraidEventListenerNative(
                  e,
                  "ready",
                  this.callBackInitWithoutMraidFrequencyUpdate
                )),
                (this.callbackStateChangedEvent =
                  de.addMraidEventListenerNative(
                    e,
                    "stateChange",
                    this.callBackInitWithoutMraidFrequencyUpdate
                  )));
          }
          refreshSdkStatus() {
            if (
              (this.isSdkContainerUsableCache ||
                (this.isAppSupported() &&
                  this.isUsable() &&
                  (this.isSdkContainerUsableCache = !0)),
              this.isSdkContainerUsableCache)
            )
              try {
                this.visibleRatio = this.getVisibleRatioRefreshed();
              } catch (e) {
                C.notify(C.EXCEPTION_161), (this.visibleRatio = 0);
              }
          }
          static checkAppNexusSDKContext() {
            const e = new ce();
            W.setContainer(e), (Te.randomKey = d.getRandomId());
            const t = new O(C.EXCEPTION_172, (e) => {
                if (e) {
                  const t = e;
                  Te.processAppNexusSdkPostMessage(t);
                }
              }),
              i = c.getWindow();
            se.addEventListenerWithEventListenerWrapper(i, i, "message", t);
            try {
              i.top.postMessage(`anjam:Ping?cb=${Te.randomKey}`, "*");
            } catch (e) {
              C.notify(C.EXCEPTION_171);
            }
            new u(() => {
              if (!Te.hasInsertedAnjam()) {
                const e = new oe();
                W.setContainer(e), W.sendNonMeasurableWebviewRequest();
              }
            }, C.EXCEPTION_172).schedule(Te.MAXIMUM_INIT_TIME_FOR_ANJAM);
          }
          insertMraid() {
            try {
              this.isAppSupported() &&
                this.shouldInsertMraid(c.getTopAccessibleWindow()) &&
                (this.insertMraidNative(c.getTopAccessibleWindow()),
                C.notify(C.EXCEPTION_1165));
            } catch (e) {
              C.notify(C.EXCEPTION_162);
            }
          }
          insertMraidNative(e) {
            const t = document.createElement("script");
            t.setAttribute("src", this.getMraidUrl()),
              (t.async = !0),
              (
                e.document.head || e.document.documentElement.childNodes[0]
              ).appendChild(t);
          }
          shouldInsertMraid(e) {
            return (
              void 0 === e.mraid ||
              void 0 === e.mraid.getState ||
              "loading" === e.mraid.getState()
            );
          }
          isAppSupported() {
            const e = Te.hasAnjamNamespaceNative(c.getTopAccessibleWindow()),
              t =
                M.isCrossDomain() &&
                g.getCurrentTime() - g.getInitializationTime() <
                  Te.MAXIMUM_INIT_TIME_FOR_ANJAM;
            return e || t;
          }
          isUsable() {
            try {
              return this.isUsableNative(c.getTopAccessibleWindow());
            } catch (e) {
              C.notify(C.EXCEPTION_163);
            }
            return !1;
          }
          hasPositionUsableNative(e) {
            if (!this.isUsableNative(e)) return !1;
            const t = e.mraid.getCurrentPosition(),
              i = e.mraid.getScreenSize();
            return (
              !!t &&
              !!i &&
              void 0 !== t.x &&
              void 0 !== t.y &&
              void 0 !== t.width &&
              void 0 !== t.height &&
              void 0 !== i.width &&
              void 0 !== i.height
            );
          }
          isUsableNative(e) {
            return (
              void 0 !== e.mraid &&
              "function" == typeof e.mraid.getState &&
              "function" == typeof e.mraid.getCurrentPosition &&
              "function" == typeof e.mraid.getScreenSize &&
              "function" == typeof e.mraid.isViewable &&
              !de.isLoadingState(e)
            );
          }
          getVisibleRatioRefreshed() {
            const e = c.getTopAccessibleWindow();
            if ("hidden" === e.mraid.getState()) return 0;
            if (!e.mraid.isViewable()) return 0;
            if (!this.hasPositionUsableNative(e)) return 0;
            const t = e.mraid.getCurrentPosition(),
              i = e.mraid.getScreenSize();
            return (
              (Math.max(
                0,
                Math.min(t.x + t.width, i.width) - Math.max(t.x, 0)
              ) *
                Math.max(
                  0,
                  Math.min(t.y + t.height, i.height) - Math.max(t.y, 0)
                )) /
              (t.width * t.height)
            );
          }
          static hasAnjamNamespaceNative(e) {
            return (
              void 0 !== e.anjam && "function" == typeof e.anjam.GetVersion
            );
          }
          getMraidUrl() {
            return Te.MRAID_URL;
          }
          static getAnjamUrl() {
            return Te.ANJAM_URL;
          }
          static processAppNexusSdkPostMessage(e) {
            `sdkjs:result?caller=Ping&answer=1&cb=${Te.randomKey}` === e.data
              ? Te.isAnjamInserted ||
                Te.hasAnjamNamespaceNative(c.getTopAccessibleWindow()) ||
                (Te.insertAnjamNative(),
                (Te.isAnjamInserted = !0),
                C.notify(C.EXCEPTION_1170),
                Te.initAppNexusSDKMraidContainer())
              : "sdkjs:ready?" === e.data && W.checkDurationStatic();
          }
          static insertAnjamNative() {
            const e = document.createElement("script");
            e.setAttribute("src", this.getAnjamUrl()),
              (
                document.head || document.documentElement.childNodes[0]
              ).appendChild(e);
          }
          static hasInsertedAnjam() {
            return Te.isAnjamInserted;
          }
          getContainerType() {
            return I.APPNEXUS_SDK;
          }
          static setMraidRefreshFrequency(e) {
            Te.mraidRefreshFrequency = e;
          }
          updateMraidRefreshFrequency(e, t) {
            void 0 !== e.anjam.SetMRAIDRefreshFrequency
              ? e.anjam.SetMRAIDRefreshFrequency(t)
              : C.notify(C.EXCEPTION_1171);
          }
          removeMraidListeners() {
            const e = c.getTopAccessibleWindow();
            this.callbackReadyEvent &&
              this.removeMraidListenerNative(
                e,
                "ready",
                this.callbackReadyEvent
              ),
              this.callbackStateChangedEvent &&
                this.removeMraidListenerNative(
                  e,
                  "stateChange",
                  this.callbackStateChangedEvent
                );
          }
          removeMraidListenerNative(e, t, i) {
            e.mraid.removeEventListener(t, i);
          }
          shutDown() {
            super.shutDown();
            try {
              this.removeMraidListeners();
            } catch (e) {
              C.notify(C.EXCEPTION_189);
            }
          }
        }
        (Te.MAXIMUM_INIT_TIME_FOR_ANJAM = 500),
          (Te.DEFAULT_MRAID_REFRESH_FREQUENCY = 100),
          (Te.MRAID_URL = "https://adsdk.bing.net/assets/mraid/v1/mraid.js"),
          (Te.ANJAM_URL = "https://adsdk.bing.net/assets/anjam/v1.1/anjam.js"),
          (Te.mraidRefreshFrequency = 0),
          (Te.isAnjamInserted = !1),
          (Te.randomKey = null);
        class me {
          constructor(e) {
            (this.data = null),
              (this.eventType = ""),
              (this.eventTimestamp = -1),
              (this.eventType = this.getNativeEventType(e)),
              (this.eventTimestamp = this.getNativeEventTimestamp(e)),
              (this.data = this.getNativeEventData(e));
          }
          getNativeEventData(e) {
            return void 0 !== e && void 0 !== e.data ? e.data : null;
          }
          getNativePlayerStateChange(e) {
            return e && void 0 !== e.state ? e.state : "";
          }
          getNativeDuration(e) {
            return e && void 0 !== e.duration ? e.duration : -1;
          }
          getNativeInterationType(e) {
            return e && void 0 !== e.interactionType ? e.interactionType : "";
          }
          getNativeVolume(e) {
            return e &&
              "undefined" !== e.deviceVolume &&
              "undefined" !== e.videoPlayerVolume
              ? e.deviceVolume * e.videoPlayerVolume
              : -1;
          }
          getNativeEventType(e) {
            return e.type;
          }
          getNativeEventTimestamp(e) {
            return e.timestamp;
          }
          getDuration() {
            return this.getNativeDuration(this.data);
          }
          getPlayerStateChange() {
            return this.getNativePlayerStateChange(this.data);
          }
          getInterationType() {
            return this.getNativeInterationType(this.data);
          }
          getVolume() {
            return this.getNativeVolume(this.data);
          }
          getType() {
            return this.eventType;
          }
          getTimestamp() {
            return this.eventTimestamp;
          }
        }
        class pe {
          constructor(e) {
            if (
              ((this.partnerName = ""),
              (this.adSessionType = ""),
              (this.accessMode = ""),
              (this.omidParameters = ""),
              (this.sessionStartTimestampReal = -1),
              (this.creativeElement = null),
              (this._isOMSDKForWeb = !1),
              (this.partnerVersion = ""),
              this.isValidSessionEvent(e))
            ) {
              this.setPartnerName(e),
                this.setPartnerVersion(e),
                this.setAdSessionType(e),
                this.setOmidParameters(e),
                (this.accessMode = this.getAccessMode(e)),
                (this.sessionStartTimestampReal = g.getCurrentTime()),
                "limited" === this.accessMode && C.notify(C.EXCEPTION_1308),
                "native" === this.adSessionType && C.notify(C.EXCEPTION_1313);
              const t = this.getVideoElement(e);
              t && (this.creativeElement = t),
                this.isOMIDContextWithoutCreativeAccess() &&
                  C.notify(C.EXCEPTION_1307);
            } else C.notify(C.EXCEPTION_204);
          }
          getPartnerName() {
            return this.partnerName;
          }
          getAdSessionType() {
            return this.adSessionType;
          }
          getOmidParameters() {
            return this.omidParameters;
          }
          isValidSessionEvent(e) {
            return (
              void 0 !== e &&
              void 0 !== e.data &&
              void 0 !== e.data.context &&
              void 0 !== e.data.context.accessMode &&
              void 0 !== e.data.context.adSessionType &&
              ((void 0 !== e.data.context.omidNativeInfo &&
                void 0 !== e.data.context.omidNativeInfo.partnerName) ||
                (void 0 !== e.data.context.omidJsInfo &&
                  void 0 !== e.data.context.omidJsInfo.partnerName))
            );
          }
          setPartnerName(e) {
            let t = e.data.context.omidNativeInfo;
            void 0 === t &&
              ((t = e.data.context.omidJsInfo),
              void 0 !== t && (this._isOMSDKForWeb = !0)),
              (this.partnerName = t.partnerName);
          }
          setPartnerVersion(e) {
            let t = e.data.context.omidNativeInfo;
            void 0 === t && (t = e.data.context.omidJsInfo);
            const i = t.partnerVersion;
            this.partnerVersion = void 0 !== i ? i : "";
          }
          setAdSessionType(e) {
            this.adSessionType = e.data.context.adSessionType;
          }
          getAccessMode(e) {
            return e.data.context.accessMode;
          }
          setOmidParameters(e) {
            const t = e.data.verificationParameters;
            this.omidParameters = void 0 === t ? "" : t;
          }
          isSupportedPartner() {
            return !(
              this.isInvalidAppnexusAndroidSdk() ||
              this.isInvalidAppnexusIosSdk()
            );
          }
          isAppnexusPartner() {
            return (
              "Appnexus" === this.partnerName ||
              "appnexus.com-omios" === this.partnerName ||
              "appnexus.com-omandroid" === this.partnerName ||
              "Xandr" === this.partnerName ||
              "Microsoft" === this.partnerName
            );
          }
          isInvalidAppnexusIosSdk() {
            return !(
              "appnexus.com-omios" !== this.partnerName ||
              !this.creativeElement ||
              !d.isStrictlyInferiorVersion(
                this.partnerVersion,
                pe.MIN_IOS_APPNEXUS_SDK_VERSION_SUPPORTED
              ) ||
              (C.notify(C.EXCEPTION_1310), 0)
            );
          }
          isInvalidAppnexusAndroidSdk() {
            return !(
              "appnexus.com-omandroid" !== this.partnerName ||
              !this.creativeElement ||
              !d.isStrictlyInferiorVersion(
                this.partnerVersion,
                pe.MIN_ANDROID_APPNEXUS_SDK_VERSION_SUPPORTED
              ) ||
              (C.notify(C.EXCEPTION_1311), 0)
            );
          }
          isOMIDContextWithoutCreativeAccess() {
            return St.isBannerOrNativeCreative()
              ? "native" === this.adSessionType
              : "limited" === this.accessMode || !this.creativeElement;
          }
          getVideoElement(e) {
            return void 0 !== e.data.context.videoElement
              ? e.data.context.videoElement
              : null;
          }
          getCreativeElement() {
            return this.creativeElement;
          }
          isAsync(e) {
            return e < this.sessionStartTimestampReal;
          }
          isOMSDKForWeb() {
            return this._isOMSDKForWeb;
          }
        }
        (pe.MIN_IOS_APPNEXUS_SDK_VERSION_SUPPORTED = "6.1"),
          (pe.MIN_ANDROID_APPNEXUS_SDK_VERSION_SUPPORTED = "6.1.1");
        class Oe {
          static checkOuterMetrics() {
            if (Oe.outerWindowMetricsAreNotSetOnLoad) {
              let e = !1;
              try {
                e =
                  c.getWindowOuterSize(c.getTopAccessibleWindow()).surface() >
                  0;
              } catch (e) {
                C.notify(C.EXCEPTION_73);
              }
              e &&
                (C.notify(C.EXCEPTION_1214),
                (Oe.outerWindowMetricsAreNotSetOnLoad = !1));
            }
          }
          static getHybridAppContainerIfAvailable() {
            let e = 0;
            try {
              e = Oe.getBrowserSurface();
            } catch (e) {
              C.notify(C.EXCEPTION_79);
            }
            if (e >= 0.7 && e <= 1.15) {
              e > 1 ? C.notify(C.EXCEPTION_1212) : C.notify(C.EXCEPTION_1202);
              const t = new Ee();
              return t.init(), t;
            }
            return (
              0 === e
                ? C.notify(C.EXCEPTION_1201)
                : e > 1.15
                ? C.notify(C.EXCEPTION_1211)
                : C.notify(C.EXCEPTION_1203),
              null
            );
          }
          static getBrowserSurface() {
            const e = c.getScreenSize().surface();
            if (e <= 0) return C.notify(C.EXCEPTION_1215), 0;
            const t = c.getWindowOuterSize(c.getTopAccessibleWindow());
            if (t.surface() > 0)
              return C.notify(C.EXCEPTION_1205), t.surface() / e;
            if (!M.isCrossDomain()) {
              Oe.outerWindowMetricsAreNotSetOnLoad = !0;
              const t = Oe.needInitialScaleMultiplication();
              if (Oe.getMetaViewportContent()) {
                const i = Oe.getViewportWidth(),
                  s = Oe.getViewportInitialScale();
                if (("" !== i && "device-width" === i) || -1 === s) {
                  if (s > 0) {
                    const i =
                      c.getClientSize(c.getTopAccessibleWindow()).surface() / e;
                    return s >= 1
                      ? (C.notify(C.EXCEPTION_1208), i)
                      : (C.notify(C.EXCEPTION_1209), t ? i * s * s : i);
                  }
                  return C.notify(C.EXCEPTION_1207), 0;
                }
                {
                  C.notify(C.EXCEPTION_1210);
                  const i = c.getWindowSize(c.getTopAccessibleWindow());
                  return t ? (i.surface() * s * s) / e : i.surface() / e;
                }
              }
              return C.notify(C.EXCEPTION_1206), 0;
            }
            return 0;
          }
          static needInitialScaleMultiplication() {
            try {
              const e = c.getWindow(),
                t =
                  void 0 !== e.statusbar &&
                  !e.statusbar.visible &&
                  void 0 === e.PerformanceMeasure;
              return t && C.notify(C.EXCEPTION_1213), !t;
            } catch (e) {
              return !0;
            }
          }
          static getMetaViewportContent() {
            const e = c
              .getTopAccessibleWindow()
              .document.getElementsByTagName("meta");
            for (let t = 0; t < e.length; t++)
              if (
                "viewport" === e[t].getAttribute("property") ||
                "viewport" === e[t].getAttribute("name")
              )
                return e[t].hasAttribute("content")
                  ? e[t].getAttribute("content")
                  : "";
            return "";
          }
          static getViewportMeta(e) {
            const t = Oe.getMetaViewportContent();
            if (!t || -1 === t.indexOf(e)) return "";
            const i = t.split(" ").join("").split(",");
            for (let t = 0; t < i.length; t++)
              if (-1 !== i[t].indexOf(e)) {
                const e = i[t].split("=");
                if (e.length > 1) return e[1];
              }
            return "";
          }
          static getViewportWidth() {
            return Oe.getViewportMeta("width");
          }
          static getViewportInitialScale() {
            const e = Oe.getViewportMeta("initial-scale");
            return "" === e ? -1 : d.isNumeric(e) ? d.parseFloat(e) : -1;
          }
        }
        Oe.outerWindowMetricsAreNotSetOnLoad = !1;
        class Ie {
          static manageReferrerDetection(e) {
            try {
              const t = Ie.injectReferrerDetection(),
                i = e.getParameter("rdcb");
              i
                ? (C.notify(C.EXCEPTION_1320),
                  Ce.sendRequestWithoutCookieAndReplaceSessionId(
                    i + "&" + t,
                    !1
                  ))
                : C.notify(C.EXCEPTION_126);
            } catch (e) {
              C.notify(C.EXCEPTION_127);
            }
          }
          static injectReferrerDetection() {
            const e = function (e) {
              this.rdParams = e;
            };
            return (
              (e.prototype = {
                constructor: e,
                walkAncestors: function (e) {
                  try {
                    if (!window.location.ancestorOrigins) return;
                    for (
                      let t = 0, i = window.location.ancestorOrigins.length;
                      t < i;
                      t++
                    )
                      e.call(null, window.location.ancestorOrigins[t], t);
                  } catch (e) {
                    C.notify(C.EXCEPTION_120);
                  }
                },
                walkUpWindows: function (e) {
                  const t = [];
                  let i = null;
                  do {
                    try {
                      (i = i ? i.parent : window), e.call(null, i, t);
                    } catch (e) {
                      return (
                        t.push({ referrer: null, location: null, isTop: !1 }), t
                      );
                    }
                  } while (i !== window.top);
                  return t;
                },
                getPubUrlStack: function (e) {
                  const t = [];
                  let i = null,
                    s = null,
                    n = null,
                    r = null,
                    a = null,
                    o = null;
                  for (let c = e.length - 1; c >= 0; c--) {
                    try {
                      s = e[c].location;
                    } catch (e) {
                      C.notify(C.EXCEPTION_121);
                    }
                    if (s) (i = encodeURIComponent(s)), t.push(i), o || (o = i);
                    else if (0 !== c) {
                      n = e[c - 1];
                      try {
                        (r = n.referrer), (a = n.ancestor);
                      } catch (e) {
                        C.notify(C.EXCEPTION_122);
                      }
                      r
                        ? ((i = encodeURIComponent(r)), t.push(i), o || (o = i))
                        : a
                        ? ((i = encodeURIComponent(a)), t.push(i), o || (o = i))
                        : t.push(null);
                    } else t.push(null);
                  }
                  return { stack: t, detectUrl: o };
                },
                getLevels: function () {
                  const e = this.walkUpWindows(function (e, t) {
                    try {
                      t.push({
                        referrer: e.document.referrer || null,
                        location: e.location.href || null,
                        isTop: e === window.top,
                      });
                    } catch (i) {
                      t.push({
                        referrer: null,
                        location: null,
                        isTop: e === window.top,
                      });
                    }
                  });
                  return (
                    this.walkAncestors(function (t, i) {
                      e[i].ancestor = t;
                    }),
                    e
                  );
                },
                getRefererInfo: function () {
                  let e = "";
                  try {
                    const t = this.getLevels(),
                      i = t.length - 1,
                      s = !!t[i].location || (i > 0 && !!t[i - 1].referrer),
                      n = this.getPubUrlStack(t);
                    e =
                      this.rdParams.rdRef +
                      "=" +
                      n.detectUrl +
                      "&" +
                      this.rdParams.rdTop +
                      "=" +
                      s +
                      "&" +
                      this.rdParams.rdIfs +
                      "=" +
                      i +
                      "&" +
                      this.rdParams.rdStk +
                      "=" +
                      n.stack;
                  } catch (t) {
                    (e = ""), C.notify(C.EXCEPTION_124);
                  }
                  return e;
                },
              }),
              (function () {
                let t = "";
                try {
                  return new e({
                    rdRef: "bdref",
                    rdTop: "bdtop",
                    rdIfs: "bdifs",
                    rdStk: "bstk",
                  }).getRefererInfo();
                } catch (e) {
                  (t = ""), C.notify(C.EXCEPTION_125);
                }
                return t;
              })()
            );
          }
        }
        class Ce {
          static sendRequestWithoutCookieAndReplaceSessionId(e, t) {
            (e = e.replace("[alenty_sessionid]", E.getSessionId())),
              Ce.sendRequestWithoutCookie(e, t);
          }
          static useOmidToSendRequest() {
            return (
              r() || (I.isOmidSdk() && _e.hasConfigToSendRequestWithOmidApi())
            );
          }
          static sendRequestWithoutCookie(e, t) {
            try {
              Ce.useOmidToSendRequest()
                ? Ce.sendRequestWithOMSDK(e)
                : Ce.sendWithBeaconAPI(e) ||
                  Ce.sendRequestWithoutCookieNative(
                    c.getTopAccessibleWindow(),
                    e,
                    t
                  );
            } catch (e) {
              C.notify(C.EXCEPTION_37);
            }
            g.getRequestSentList().push(e);
          }
          static sendWithBeaconAPI(e) {
            return (
              !("undefined" == typeof navigator || !navigator.sendBeacon) &&
              navigator.sendBeacon(e)
            );
          }
          static sendRequestWithOMSDK(e) {
            const t = e.replace(/\|/g, "%7C");
            c.getNamespace().omc.sendUrl(t);
          }
          static sendRequestWithoutCookieNative(e, t, i) {
            const s = new XMLHttpRequest();
            try {
              s.open("GET", t, !i);
            } catch (i) {
              return void Ce.sendRequestNative(e, t);
            }
            try {
              s.send(null);
            } catch (e) {
              C.notify(C.EXCEPTION_76);
            }
          }
          static sendRequestNative(e, t) {
            e.document.createElement("img").src = t;
          }
          static sendRequestJavascript(e, t) {
            const i = e.document.createElement("script");
            (i.type = "text/javascript"),
              (i.src = t),
              e.document.head.appendChild(i);
          }
        }
        class _e {
          constructor(e, t) {
            if (
              ((this.parameters = new Map()),
              (this.impressionId = g.getCurrentTime()),
              (this.tagIdentifier = ++_e.globalTagCount),
              (this.auctionTimestampSecond = 0),
              (this.splitSeparator = ";"),
              (this.partnerName = null),
              (this.referenceElement = null),
              (this.executeViewCb = !1),
              (this.referenceElement = t),
              this.readParametersOnQueryString(e),
              this.initABTesting(),
              this.hasParameter("st") &&
                (_e.supplyTypeParameter = this.getParameter("st")),
              this.hasParameter("ts") &&
                (this.auctionTimestampSecond = this.getParameterInt("ts")),
              this.hasParameter("omrqs") &&
                (_e._hasConfigToSendRequestWithOmidApi =
                  "1" === this.getParameter("omrqs")),
              this.hasParameter("native_event") &&
                "${VIEW_NATIVE_EVENTS}" !== this.getParameter("native_event"))
            ) {
              C.notify(C.EXCEPTION_1400);
              try {
                _e.viewNativeEvents = new Se(this.getParameter("native_event"));
              } catch (e) {
                C.notify(C.EXCEPTION_405);
              }
            }
            this.hasParameter("fire_vcb") && (this.executeViewCb = !0);
          }
          readParametersOnQueryString(e) {
            const t = d.splitStringByRegexp(e, this.splitRegexp());
            for (let e = 0; e < t.length; e++) {
              const i = t[e],
                s = d.splitString(i, "=", 2),
                n = s[0];
              if (0 === n.length) continue;
              let r;
              if (s.length > 1) {
                if (((r = s[1]), 0 === r.length)) continue;
              } else r = "1";
              this.addParameter(n, r);
            }
          }
          splitRegexp() {
            return ";";
          }
          addParameter(e, t) {
            let i = this.parameters.get(e);
            if ((i || ((i = []), this.parameters.set(e, i)), t)) {
              let e;
              try {
                e = d.decodeURIComponent(t);
              } catch (i) {
                (e = t),
                  "%native_dom_id%" !== t ||
                    I.isOMIDContextWithoutCreativeAccess() ||
                    C.notify(C.EXCEPTION_113);
              }
              i.push(e);
            }
          }
          getParameter(e) {
            const t = this.parameters.get(e);
            return t ? t[t.length - 1] : null;
          }
          getParameters(e) {
            return this.parameters.get(e);
          }
          getReferenceElement() {
            return this.referenceElement;
          }
          getCommonId() {
            return this.tagIdentifier + "_" + this.impressionId;
          }
          getParameterInt(e) {
            const t = this.getParameter(e);
            return t ? d.parseInt(t) : 0;
          }
          hasParameter(e) {
            return this.parameters.has(e);
          }
          setParameter(e, t) {
            this.parameters.delete(e);
            const i = [];
            this.parameters.set(e, i), t && i.push(t);
          }
          getDeclaredCreativeSize() {
            let e = T.minusOne;
            const t = this.getParameter("d");
            if (t && -1 !== t.indexOf("x"))
              try {
                const i = t.split("x");
                2 === i.length
                  ? (e = new T(parseInt(i[0], 10), parseInt(i[1], 10)))
                  : C.notify(C.EXCEPTION_1186);
              } catch (e) {
                C.notify(C.EXCEPTION_1185);
              }
            return e;
          }
          initABTesting() {
            if (
              !_e.isABTestingInitialized &&
              ((_e.isABTestingInitialized = !0), this.hasParameter("ab"))
            ) {
              const e = this.getParameterInt("ab"),
                t = 100 * d.getRandom();
              t < 2 * e &&
                ((_e._isABTestingCaseA = t < e),
                (_e._isABTestingCaseB = !_e._isABTestingCaseA));
            }
          }
          static isABTestingCaseA() {
            return _e._isABTestingCaseA;
          }
          static isABTestingCaseB() {
            return _e._isABTestingCaseB;
          }
          static isInAppSupplyType() {
            return "2" === _e.supplyTypeParameter;
          }
          getAuctionTimestampSecond() {
            return this.auctionTimestampSecond;
          }
          static hasConfigToSendRequestWithOmidApi() {
            return _e._hasConfigToSendRequestWithOmidApi;
          }
          getViewNativeEvents() {
            return _e.viewNativeEvents;
          }
          getPartnerName() {
            if (this.partnerName) return this.partnerName;
            if (W.getContainer()) {
              const e = W.getContainer();
              return e ? e.getPartnerName() : null;
            }
            return null;
          }
          shouldExecuteViewCb() {
            return this.executeViewCb;
          }
        }
        (_e.globalTagCount = 0),
          (_e.isABTestingInitialized = !1),
          (_e._isABTestingCaseA = !1),
          (_e._isABTestingCaseB = !1),
          (_e._hasConfigToSendRequestWithOmidApi = !1),
          (_e.supplyTypeParameter = null),
          (_e.viewNativeEvents = null);
        class fe extends _e {
          constructor(e, t, i, s, n, r, a) {
            const o = fe.isXdrViewApiInit(t);
            if (
              (super(o ? t.p : e, null),
              (this.duration = -1),
              (this.fullscreen = !1),
              (this.soundOn = !1),
              fe.isElement(t))
            )
              (this.adNode = t), (this.domID = ""), (this.adUID = "");
            else if (
              "string" == typeof t &&
              "string" == typeof i &&
              "number" == typeof n &&
              "boolean" == typeof r &&
              "boolean" == typeof a
            )
              (this.domID = t),
                (this.adUID = i),
                (this.duration = n),
                (this.soundOn = r),
                (this.fullscreen = a),
                (this.partnerName =
                  "anxvvapi" + (s && "" !== s ? "_" + s : ""));
            else if (
              "string" == typeof t &&
              "string" == typeof i &&
              "number" == typeof n
            )
              (this.domID = t),
                (this.adUID = i),
                (this.duration = n),
                (this.partnerName =
                  "anxvvapi" + (s && "" !== s ? "_" + s : ""));
            else if (o) {
              (this.adNode = t.an),
                (this.domID = t.id),
                (this.adUID = t.a),
                (this.duration = t.d ? t.d : 0),
                (this.fullscreen = !!t.fs && t.fs),
                (this.soundOn = !!t.so && t.so);
              const e = t.imn;
              this.partnerName = "xdrviewapi" + (e && "" !== e ? "_" + e : "");
            }
          }
          static isElement(e) {
            return (
              ("undefined" != typeof Element && e instanceof Element) ||
              (!!e &&
                "object" == typeof e &&
                1 === e.nodeType &&
                "string" == typeof e.nodeName)
            );
          }
          static isXdrViewApiInit(e) {
            return "object" == typeof e && null !== e && "p" in e;
          }
          splitRegexp() {
            return this.splitSeparator;
          }
          getDomID() {
            return this.domID;
          }
          setDomID(e) {
            this.domID = e;
          }
          getAdUID() {
            return this.adUID;
          }
          getDuration() {
            return this.duration;
          }
          isFullscreen() {
            return this.fullscreen;
          }
          isSoundOn() {
            return this.soundOn;
          }
          readParametersOnQueryString(e) {
            const t = e.indexOf("&");
            if (t > -1) {
              const i = e.indexOf(";");
              (-1 === i || t < i) && (this.splitSeparator = "&");
            }
            super.readParametersOnQueryString(e),
              "&" === this.splitSeparator &&
                this.hasParameter("vc") &&
                ((this.splitSeparator = ";"),
                super.readParametersOnQueryString(this.getParameter("vc")),
                (this.splitSeparator = "&"),
                this.parameters.delete("vc"));
          }
          getAdNode() {
            return this.adNode;
          }
        }
        class Se {
          constructor(e) {
            (this.rawConfigString = null),
              (this.nativeEventList = []),
              (this.rawConfigString = e),
              this.parseNativeEventParameter(this.rawConfigString);
          }
          parseNativeEventParameter(e) {
            const t = d.splitStringByRegexp(e, "(\\||%7C)+");
            for (let e = 0; e < t.length; e++) {
              const i = t[e];
              if ("|" === i || "%7C" === i) continue;
              const s = d.splitStringByRegexp(i, "~"),
                n = s[0];
              if (0 === n.length) {
                C.notify(C.EXCEPTION_401);
                continue;
              }
              let r, a;
              s.length > 2
                ? ((r = s[1]),
                  (a = s[2]),
                  0 !== r.length
                    ? 0 !== a.length
                      ? this.addNativeEvent(n, r, a)
                      : C.notify(C.EXCEPTION_403)
                    : C.notify(C.EXCEPTION_402))
                : C.notify(C.EXCEPTION_404);
            }
          }
          addNativeEvent(e, t, i) {
            const s = new Ne(t, e, i);
            this.nativeEventList.push(s);
          }
          postShot(e) {
            for (let t = 0; t < this.nativeEventList.length; t++)
              this.nativeEventList[t].postShot(e);
          }
          getNbEvents() {
            return this.nativeEventList.length;
          }
        }
        !(function (e) {
          (e[(e.JAVASCRIPT = 0)] = "JAVASCRIPT"), (e[(e.IMAGE = 1)] = "IMAGE");
        })(o || (o = {}));
        class Ne {
          constructor(e, t, i) {
            (this.method = null),
              (this.callback = null),
              (this.jsSignalWhenReachDefinition = -1),
              (this.trigger = null),
              (this.triggered = !1),
              "2" === e
                ? (this.method = o.JAVASCRIPT)
                : "1" === e
                ? (this.method = o.IMAGE)
                : ((this.method = null), C.notify(C.EXCEPTION_406)),
              "1" === t
                ? (this.jsSignalWhenReachDefinition = C.EXCEPTION_1420)
                : "2" === t
                ? ((this.trigger = new st()),
                  (this.jsSignalWhenReachDefinition = C.EXCEPTION_1421))
                : "3" === t
                ? ((this.trigger = new ot(null)),
                  (this.jsSignalWhenReachDefinition = C.EXCEPTION_1422))
                : "4" === t
                ? ((this.trigger = new nt()),
                  (this.jsSignalWhenReachDefinition = C.EXCEPTION_1423))
                : C.notify(C.EXCEPTION_407),
              (this.callback = i);
          }
          isValid() {
            return (
              null !== this.method &&
              this.jsSignalWhenReachDefinition > 0 &&
              null !== this.callback
            );
          }
          postShot(e) {
            this.triggered ||
              (this.isDefinitionReached(e) &&
                (this.sendUrl(),
                this.jsSignalWhenReachDefinition > 0 &&
                  C.notify(this.jsSignalWhenReachDefinition)));
          }
          sendUrl() {
            if (this.triggered) return;
            const e = this.callback.replace(
              "[alenty_sessionid]",
              E.getSessionId()
            );
            if (r())
              return Ce.useOmidToSendRequest()
                ? (C.notify(C.EXCEPTION_409),
                  Ce.sendRequestWithoutCookie(e, !1),
                  void (this.triggered = !0))
                : void C.notify(C.EXCEPTION_408);
            (this.triggered = !0),
              this.method === o.JAVASCRIPT
                ? Ce.sendRequestJavascript(c.getTopAccessibleWindow(), e)
                : this.method === o.IMAGE &&
                  Ce.sendRequestNative(c.getTopAccessibleWindow(), e);
          }
          isDefinitionReached(e) {
            if (!this.trigger) return !0;
            if (!e) return !1;
            if (e.isMeasurementInitialized()) {
              let t = null,
                i = -1;
              const s = e.getTag();
              for (let e = 0; e < s.getTrackedObjectCount(); e++) {
                const n = s.getTrackedObject(e),
                  r = this.trigger.getDurationThreshold(n),
                  a = this.trigger.getTrackedObjectDuration(n);
                n.isInitialized() &&
                  a >= i &&
                  a >= r &&
                  r > 0 &&
                  ((i = a), (t = n));
              }
              if (t) return !0;
            }
            return !1;
          }
        }
        class Ae {
          constructor() {
            (this.highPriorityElements = []),
              (this.declaredCreativeSize = T.zero);
          }
          searchVisibleElementsInSiblingAndChildren(e, t) {
            const i = n(e),
              s = (i && i.getAttribute("class")) || "";
            i &&
              -1 !== s.indexOf("anx_cr_loc") &&
              (this.highPriorityElements.push(i), C.notify(C.EXCEPTION_1190));
            let r = this.getMeasurableChildren(e, t);
            return (r = r.concat(this.searchVisibleElementsInSibling(e, t))), r;
          }
          searchVisibleElementsInSibling(e, t) {
            const i = this.lookAllNodes(e, Ae.DIR_BACKWARD, t),
              s = this.lookAllNodes(e, Ae.DIR_FORWARD, t);
            return i.concat(s);
          }
          searchVisibleElementsVisuallyNear(e) {
            const t = se.getElementWindow(e),
              i = [];
            let s = se.getElementsByTagName(t, "img");
            (s = s.concat(se.getElementsByTagName(t, "iframe"))),
              (s = s.concat(se.getElementsByTagName(t, "video"))),
              (s = s.concat(se.getElementsByTagName(t, "canvas"))),
              (s = s.concat(se.getElementsByTagName(t, "object"))),
              (s = s.concat(se.getElementsByTagName(t, "embed"))),
              (s = s.concat(se.getElementsByTagName(t, "ft-carousel")));
            const n = se.getOffsetSize(e),
              r = ne.getWindowAbsolutePosition(t, e).minus(Ae.VISUAL_TOLERANCE),
              a = r.plus(n).plus(Ae.VISUAL_TOLERANCE).plus(Ae.VISUAL_TOLERANCE);
            for (let n = 0; n < s.length; n++) {
              const o = s[n];
              o !== e &&
                this.isElementSizeRelevant(o) &&
                this.isVisuallyNear(o, t, r, a) &&
                i.push(o);
            }
            return i;
          }
          isVisuallyNear(e, t, i, s) {
            const n = ne.getWindowAbsolutePosition(t, e),
              r = n.getX();
            if (r < s.getX()) {
              const t = n.getY();
              if (t < s.getY()) {
                const s = se.getOffsetSize(e);
                if (r + s.getX() > i.getX() && t + s.getY() > i.getY())
                  return !0;
              }
            }
            return !1;
          }
          getMeasurableChildren(e, t) {
            return this.getMeasurableChildrenInternal(e, Ae.DIR_BACKWARD, t);
          }
          getMeasurableChildrenInternal(e, t, i) {
            let s = [],
              n = se.getAttribute(e, "nodeName").toUpperCase();
            const r = e.getAttribute("class") || "";
            if ("IMG" === n) {
              if ("" !== se.getAttribute(e, "lntfi")) return s;
              this.isElementSizeRelevant(e) && s.push(e);
            } else if (
              -1 !==
              [
                "EMBED",
                "OBJECT",
                "IFRAME",
                "VIDEO",
                "CANVAS",
                "FT-CAROUSEL",
              ].indexOf(n)
            )
              this.isElementSizeRelevant(e) && s.push(e);
            else if (-1 !== r.indexOf("anx_cr_loc"))
              C.notify(C.EXCEPTION_1097), this.highPriorityElements.push(e);
            else if (
              -1 !== r.indexOf("celtra-ad-v3") ||
              -1 !== r.indexOf("celtra-ad-v4")
            ) {
              C.notify(C.EXCEPTION_1181);
              const t = this.getCeltraObservee(e);
              if (t) C.notify(C.EXCEPTION_1182), s.push(t);
              else if (i && !e["anxceltralistener-" + i.getControlKey()]) {
                const t = i,
                  s = new O(C.EXCEPTION_188, () => {
                    t.doSearchElements(), W.checkDurationStatic();
                  }),
                  n = c.getWindow();
                se.addEventListenerWithEventListenerWrapper(
                  n,
                  e,
                  "celtraLoaded",
                  s
                ),
                  (e["anxceltralistener-" + i.getControlKey()] = !0);
              }
            } else {
              let r = t ? re.getFirstChild(e) : re.getLastChild(e);
              if (!r && this.getShadowRootNode(e)) {
                C.notify(C.EXCEPTION_1187);
                const i = this.getShadowRootNode(e);
                r = t
                  ? this.findFirstShadowChild(i)
                  : this.findLastShadowChild(i);
              }
              for (; r; ) {
                if (
                  ((n = se.getAttribute(r, "nodeName").toUpperCase()),
                  this.isNodeRelevant(n))
                ) {
                  const e = this.getMeasurableChildrenInternal(r, t, i);
                  s = s.concat(e);
                }
                r = t ? re.getNextSibling(r) : re.getPreviousSibling(r);
              }
            }
            return s;
          }
          getShadowRootNode(e) {
            return e.shadowRoot;
          }
          findFirstShadowChild(e) {
            return e.firstElementChild;
          }
          findLastShadowChild(e) {
            return e.lastElementChild;
          }
          lookAllNodes(e, t, i) {
            let s = [],
              n = e;
            for (; n && s.length < Ae.MAX_NODES_PARSED; )
              if (
                ((n = t ? re.getNextSibling(n) : re.getPreviousSibling(n)), n)
              ) {
                const e = se.getAttribute(n, "nodeName").toUpperCase();
                if (this.isNodeRelevant(e)) {
                  const e = this.getMeasurableChildrenInternal(n, t, i);
                  s = s.concat(e);
                }
              }
            return s;
          }
          lookForHtmlOnlyCreativeInIframeBody(e) {
            const t = [],
              i = c.getBodyElement(e);
            let s = null,
              n = T.zero;
            if (i) {
              let e = re.getFirstChild(i);
              for (; e; ) {
                let t = se.getAttribute(e, "nodeName").toUpperCase();
                if (this.isNodeRelevant(t)) {
                  let i = se.getMaxSize(e);
                  if (i.surface() > n.surface()) (n = i), (s = e);
                  else if ("A" === t) {
                    let r = re.getFirstChild(e);
                    for (; r; )
                      (t = se.getAttribute(r, "nodeName").toUpperCase()),
                        this.isNodeRelevant(t) &&
                          ((i = se.getMaxSize(r)),
                          i.surface() > n.surface() && ((n = i), (s = r))),
                        (r = re.getNextSibling(r));
                  }
                }
                e = re.getNextSibling(e);
              }
            }
            return s && this.isElementSizeRelevant(s) && t.push(s), t;
          }
          isNodeRelevant(e) {
            return (
              -1 === ["SCRIPT", "NOSCRIPT", "LINK", "BR", "STYLE"].indexOf(e)
            );
          }
          isElementSizeRelevant(e) {
            const t = se.getMaxSize(e);
            let i = Ae.MIN_HEIGHT;
            const s = this.declaredCreativeSize.getY();
            return (
              s < Ae.MIN_HEIGHT && s >= Ae.CRITICAL_MIN_HEIGHT && (i = s - 2),
              t.getX() > Ae.MIN_WIDTH && t.getY() > i
            );
          }
          clean() {
            this.highPriorityElements = [];
          }
          getHighPriorityElements() {
            return this.highPriorityElements;
          }
          getCeltraObservee(e) {
            return e.celtra && e.celtra.loaded
              ? e.celtra.viewabilityObservee
              : null;
          }
          setDeclaredCreativeSize(e) {
            this.declaredCreativeSize = e;
          }
        }
        (Ae.MIN_HEIGHT = 25),
          (Ae.CRITICAL_MIN_HEIGHT = 10),
          (Ae.MIN_WIDTH = 50),
          (Ae.MAX_NODES_PARSED = 10),
          (Ae.DIR_FORWARD = !0),
          (Ae.DIR_BACKWARD = !1),
          (Ae.VISUAL_TOLERANCE = new T(5, 5));
        class ve {
          constructor() {
            (this.topLeftCorner = T.zero),
              (this.bottomRightCorner = T.zero),
              (this.topOffset = T.zero),
              (this.window = null),
              (this.child = null);
          }
          refresh(e) {
            try {
              if (this.window && this.window === e) return;
            } catch (e) {
              C.notify(C.EXCEPTION_24);
            }
            (this.window = e), this.calculateVisibleViewportPart();
          }
          initParentViewPort(e) {
            this.window = se.getAccessibleParentWindow(e);
            const t = M.getWindowFrameOffset(this.window, e),
              i = c.getWindowScroll(e);
            return (
              (this.topOffset = t.minus(i)),
              this.calculateVisibleViewportPart(),
              this
            );
          }
          calculateVisibleViewportPart() {
            const e = c.getWindowScroll(this.window);
            this.topLeftCorner = e.minus(this.topOffset);
            const t = c.getWindowSize(this.window);
            this.bottomRightCorner = this.topLeftCorner.plus(t);
          }
          createExtendedViewPort(e) {
            const t = new ve();
            return t.setChild(this), t.initParentViewPort(e);
          }
          debug() {
            l.debug(
              "x1:y1 x2:y2  - " +
                this.topLeftCorner +
                ":" +
                this.bottomRightCorner
            );
          }
          getX1() {
            return this.topLeftCorner.getX();
          }
          getY1() {
            return this.topLeftCorner.getY();
          }
          getX2() {
            return this.bottomRightCorner.getX();
          }
          getY2() {
            return this.bottomRightCorner.getY();
          }
          clearCache() {
            this.window = null;
          }
          getIframeOffset() {
            return this.topOffset;
          }
          getChildIframeOffset() {
            return this.child ? this.child.getIframeOffset() : T.zero;
          }
          setChild(e) {
            this.child = e;
          }
          getWindow() {
            return this.window;
          }
        }
        class Pe {
          static addTag(e) {
            this.tags.push(e), e.start();
          }
          static getTagCount() {
            return this.tags.length;
          }
          static removeTag(e) {
            this.tags = this.tags.filter((t) => t !== e);
          }
          static postFlushCleanup() {
            for (let e = this.tags.length - 1; e >= 0; e--) {
              const t = this.tags[e];
              if (0 === t.getTrackedObjectCount()) {
                const e = t.getTagURL().getReferenceElement();
                !e || se.isNullOrParentNull(e)
                  ? t.shutdown(Qe.RR_DELETE)
                  : (C.notify(C.EXCEPTION_1008), t.start());
              }
            }
          }
          static getTagAtIndex(e) {
            return this.tags[e];
          }
        }
        Pe.tags = [];
        class be {
          constructor(e, t) {
            (this.fakeImageElement = null),
              (this.trackedObjectList = []),
              (this.tagCreationTime = 0),
              (this.flushed = !1),
              (this.creationTime = g.getCurrentTime()),
              (this.timeoutShutdown = new u(() => {
                this.shutdown(Qe.RR_TIMEOUT);
              })),
              (this.atLeastOneObjectInitialized = !1),
              (this.timerFirstObjectInitialized = 0),
              (this.trackedElements = []),
              (this.requestTimedToSend = []),
              (this.viewCbFired = !1),
              (this.tagURL = e),
              (this.searchStrategy = t),
              (this.scriptElement = e.getReferenceElement()),
              (this.triggerManager = this.createTriggerManager()),
              this.initialize(),
              (this.tagCreationTime = g.getCurrentTime()),
              (this.requestFormatter = this.createRequestFormatter()),
              this.initTimeoutShutdown(),
              (this.tagMetricAgregator = new Ke(this)),
              (this.trackedElements = []);
            const i = this.tagURL.getParameter("cb");
            i && (g.getTagList()[i] = this.trackedElements),
              this.triggerManager.init(this, this.createIABTrigger()),
              d.isSafari() &&
                (this.requestTimedToSend =
                  this.createListOfRequestTimedToSend()),
              I.registerNewTag(this);
          }
          createListOfRequestTimedToSend() {
            return [3, 20, 60, 120];
          }
          createTriggerManager() {
            return new at();
          }
          initialize() {
            be.warnExtenalScriptTagCreated(c.getWindow());
          }
          initTimeoutShutdown() {
            let e = be.MAX_EXECUTION_TIME_MILLIS;
            const t = this.tagURL.getAuctionTimestampSecond();
            0 !== t &&
              ((e -= g.getInitializationTime() - 1e3 * t),
              (e > be.MAX_EXECUTION_TIME_MILLIS || e < 1e4) &&
                (e = be.MAX_EXECUTION_TIME_MILLIS)),
              this.timeoutShutdown.schedule(e);
          }
          static warnExtenalScriptTagCreated(e) {
            "function" == typeof e.lnttr && e.lnttr();
          }
          getTrackedObjectCount() {
            return this.trackedObjectList.length;
          }
          getTrackedObject(e) {
            return this.trackedObjectList[e];
          }
          addTrackedObject(e) {
            this.trackedObjectList.push(e);
            try {
              let t;
              (t = I.isOMIDContextWithoutCreativeAccess()
                ? new we()
                : Nt.getUseIntersectionObserver()
                ? new Re()
                : new De()),
                e.setVisibilityCalculator(t),
                e.applyInitialization();
              const i = W.trackingLoader.getContentPanel();
              i && i.addContent(e);
            } catch (e) {
              C.notify(C.EXCEPTION_41);
            }
          }
          addTrackedObjectAndInitialize(e, t) {
            this.trackedObjectList.length < be.MAX_TRACKED_OBJECTS_NUMBER &&
              (this.addTrackedObject(e), e.initVisibleElement(t));
          }
          shot() {
            for (let e = 0; e < this.trackedObjectList.length; e++) {
              const t = this.trackedObjectList[e];
              try {
                t.shot();
              } catch (e) {
                t.deleteAfterFlush(), C.notify(C.EXCEPTION_19);
              }
            }
          }
          commitDuration(e) {
            e > 0 && this.setFlushed(!1);
            for (let t = 0; t < this.trackedObjectList.length; t++)
              this.trackedObjectList[t].calculateAdvertising(e);
            this.triggerManager.postShot();
          }
          getScriptElement() {
            return this.scriptElement;
          }
          getFakeImageElement() {
            if (!this.fakeImageElement) {
              const e = this.getScriptElement(),
                t = M.isInHead(e) || se.isNullOrParentNull(e);
              this.fakeImageElement = be.createFakeImageElementNative(
                c.getWindow(),
                e,
                t
              );
            }
            return this.fakeImageElement;
          }
          static createFakeImageElementNative(e, t, i) {
            try {
              const s = e.document.createElement("IMG");
              return (
                (s.width = 0),
                (s.height = 0),
                (s.style.display = "block"),
                (s.style.margin = "0"),
                (s.style.padding = "0"),
                (s.style.width = "0"),
                (s.lntfi = "true"),
                i
                  ? e.document.body.insertBefore(s, e.document.body.firstChild)
                  : t.parentNode?.insertBefore(s, t),
                s
              );
            } catch (e) {
              return C.notify(C.EXCEPTION_57), null;
            }
          }
          getTriggerManager() {
            return this.triggerManager;
          }
          getTagURL() {
            return this.tagURL;
          }
          getCommonId() {
            return this.tagURL.getCommonId();
          }
          isFlushed() {
            return this.flushed;
          }
          setFlushed(e) {
            this.flushed = e;
          }
          flushContentIfNeeded() {
            for (let e = this.requestTimedToSend.length - 1; e >= 0; e--) {
              const t = this.requestTimedToSend[e],
                i = g.getCurrentTime() - this.tagCreationTime;
              if (
                (!W.trackingLoader.isTrackingSupported() ||
                  W.trackingLoader.trackDisplay.isTrackingInitialized()) &&
                i > 1e3 * t
              ) {
                let i = Qe.RR_XX_SECONDS_UPDATE + t;
                i > Qe.MAX_RR_XX_SECONDS_UPDATE
                  ? (i = Qe.MAX_RR_XX_SECONDS_UPDATE)
                  : i < Qe.RR_XX_SECONDS_UPDATE &&
                    (i = Qe.RR_XX_SECONDS_UPDATE),
                  this.requestFormatter.requestFlushWithFullData(i),
                  this.requestTimedToSend.splice(e, 1);
              }
            }
            this.requestFormatter.flushIfNecessary(), this.setFlushed(!0);
            for (let e = this.trackedObjectList.length - 1; e >= 0; e--) {
              const t = this.trackedObjectList[e];
              t.postFlushCleanup(),
                t.hasDeleteAfterFlush() &&
                  (this.getTagMetricsAggregator().setLastDeletedTrackedObjectData(
                    new $e(t)
                  ),
                  this.trackedObjectList.splice(e, 1));
            }
          }
          getSearchStrategy() {
            return this.searchStrategy;
          }
          getDetectionMethod() {
            return this.searchStrategy.getDetectionMethodCode();
          }
          isAlreadyTrackedForThisTag(e) {
            return !!e && "" !== se.getAttribute(e, this.getControlKey());
          }
          getControlKey() {
            return be.LNT_CONTROL_KEY + "#" + s(this.tagURL.getCommonId());
          }
          start() {
            (this.atLeastOneObjectInitialized = !1),
              this.addTrackedObject(this.createTrackedObject()),
              this.searchElements(),
              this.triggerManager.start();
          }
          sendIntermediateRequest(e) {
            this.updateMetrics(),
              (W.trackingLoader.isTrackingSupported() &&
                !W.trackingLoader.trackDisplay.isTrackingInitialized()) ||
                (this.requestFormatter.requestFlushWithFullData(e),
                this.hasAtLeastOneObjectInitialized() &&
                  this.flushContentIfNeeded());
          }
          updateMetrics() {
            this.triggerManager.postShot();
          }
          shutdown(e) {
            this.updateMetrics(), this.triggerManager.shutDown();
            const t = W.getContainer();
            t && t.shutDown(),
              this.requestFormatter.requestFlushWithFullData(e),
              this.flushContentIfNeeded(),
              (this.trackedObjectList.length = 0),
              Pe.removeTag(this),
              this.timeoutShutdown.cancel();
          }
          createRequestFormatter() {
            return new Qe(this);
          }
          getFirstObject() {
            return this.getTrackedObjectCount() > 0
              ? this.getTrackedObject(0)
              : null;
          }
          getRequestFormatter() {
            return this.requestFormatter;
          }
          getTagMetricsAggregator() {
            return this.tagMetricAgregator;
          }
          getTimeFromCreation() {
            return g.getCurrentTime() - this.creationTime;
          }
          isUnderUltimateTimeoutLimit() {
            return (
              this.getTimeFromCreation() <= be.MAX_LAST_REQUEST_TIME_MILLIS
            );
          }
          hasAtLeastOneObjectInitialized() {
            return this.atLeastOneObjectInitialized;
          }
          getTimeToHaveAtLeastOneObjectInitialized() {
            return this.timerFirstObjectInitialized - this.tagCreationTime;
          }
          getTagCreationTime() {
            return this.tagCreationTime;
          }
          getTrackedElements() {
            return this.trackedElements;
          }
          getDeclaredCreativeSize() {
            return this.tagURL.getDeclaredCreativeSize();
          }
          hasViewCbFired() {
            return this.viewCbFired;
          }
          setViewCbFired(e) {
            this.viewCbFired = e;
          }
        }
        (be.LNT_CONTROL_KEY = c.getJSNaminglnt() + "Control"),
          (be.MAX_TRACKED_OBJECTS_NUMBER = 10),
          (be.MAX_EXECUTION_TIME_MILLIS = 29e4),
          (be.MAX_LAST_REQUEST_TIME_MILLIS = 42e4);
        class De {
          constructor() {
            (this.percentVisible = 0),
              (this.isHiddenOnScreen = !1),
              (this._isOutOfViewport = !1),
              (this.position = T.minusOne),
              (this.relativePositionTopLeft = T.zero),
              (this.relativePositionBottomRight = T.zero),
              (this.bannerSize = T.minusOne),
              (this.visibleBannerSize = T.zero),
              (this._isElementRemoved = !1),
              (this.totalSurface = 0);
          }
          startMeasurement(e) {
            (this.element = e),
              (this._isElementRemoved = !1),
              this.refreshBannerSize();
          }
          refresh() {
            if (
              ((this.percentVisible = 1),
              (this.isHiddenOnScreen = !1),
              (this._isOutOfViewport = !1),
              !R.isReliable() || se.isNullOrParentNull(this.element))
            )
              return (
                C.notify(C.EXCEPTION_1021),
                (this._isElementRemoved = !0),
                (this.percentVisible = 0),
                void (this.isHiddenOnScreen = !0)
              );
            let e = se.getElementWindow(this.element);
            if (this.isDocumentElementNotAvailable(e))
              return (
                (this.percentVisible = 0), void (this.isHiddenOnScreen = !0)
              );
            if (!se.isCSSvisible(e, this.element))
              return (
                (this.percentVisible = 0), void (this.isHiddenOnScreen = !0)
              );
            if (
              (this.refreshBannerSize(),
              (this.relativePositionTopLeft = this.calcBannerPosition(
                e,
                this.element
              )),
              (this.relativePositionBottomRight =
                this.relativePositionTopLeft.plus(this.visibleBannerSize)),
              (this.totalSurface = this.visibleBannerSize.surface()),
              1 === this.totalSurface && (this.totalSurface = 0),
              (this.position = this.relativePositionTopLeft),
              0 === this.totalSurface)
            )
              return (
                (this.percentVisible = 0), void (this.isHiddenOnScreen = !0)
              );
            let t = new ve();
            for (
              t.refresh(e), this.theEyeOfAlenty(t);
              this.percentVisible > 0 && !R.isTop(e);

            )
              (t = t.createExtendedViewPort(e)),
                this.theEyeOfAlenty(t),
                (e = t.getWindow());
            this.percentVisible > 0 &&
              R.isTop(e) &&
              ((t = W.trackingLoader.trackDisplay.createViewPortFromTop(t)),
              t && this.theEyeOfAlenty(t)),
              (this.percentVisible *=
                W.trackingLoader.trackDisplay.getPercentVisible()),
              this.percentVisible <= 0 && (this._isOutOfViewport = !0);
          }
          calcBannerPosition(e, t) {
            return ne.getWindowAbsolutePosition(e, t);
          }
          theEyeOfAlenty(e) {
            (this.position = this.position.plus(e.getIframeOffset())),
              (this.relativePositionTopLeft = this.relativePositionTopLeft.plus(
                e.getChildIframeOffset()
              )),
              (this.relativePositionBottomRight =
                this.relativePositionBottomRight.plus(
                  e.getChildIframeOffset()
                ));
            let t = this.relativePositionTopLeft.getX(),
              i = this.relativePositionTopLeft.getY(),
              s = this.relativePositionBottomRight.getX(),
              n = this.relativePositionBottomRight.getY();
            s <= e.getX1() || t >= e.getX2() || n <= e.getY1() || i >= e.getY2()
              ? ((this.percentVisible = 0), (this._isOutOfViewport = !0))
              : ((t = t < e.getX1() ? e.getX1() : t),
                (s = s > e.getX2() ? e.getX2() : s),
                (i = i < e.getY1() ? e.getY1() : i),
                (n = n > e.getY2() ? e.getY2() : n),
                (this.relativePositionTopLeft = new T(t, i)),
                (this.relativePositionBottomRight = new T(s, n)),
                (this.percentVisible =
                  ((s - t) * (n - i)) / this.totalSurface));
          }
          getPercentVisible() {
            return this.percentVisible;
          }
          getPosition() {
            const e = W.trackingLoader.getCrossDomainIframePosition();
            let t;
            return (
              (t =
                M.isCrossDomain() && !T.minusOne.equals(e)
                  ? this.position.equals(T.minusOne)
                    ? e
                    : e.plus(this.position)
                  : this.position),
              t
            );
          }
          isDocumentElementNotAvailable(e) {
            return !e.document;
          }
          isElementRemoved() {
            return this._isElementRemoved;
          }
          refreshBannerSize() {
            (this.bannerSize = se.getMaxSize(this.element)),
              (this.visibleBannerSize = se.getOffsetSize(this.element)),
              this.visibleBannerSize.equals(T.zero) &&
                (this.isHiddenOnScreen = !0);
          }
          getBannerSize() {
            return this.bannerSize;
          }
          isIABVisible() {
            return this.getPercentVisible() >= this.getIABThreshold();
          }
          getIABThreshold() {
            return this.bannerSize.surface() >= De.IAB_LARGE_FORMAT_SURFACE
              ? 0.3
              : 0.5;
          }
          isInitialized() {
            return !0;
          }
          isHiddenCreative() {
            return this.isHiddenOnScreen;
          }
          isOutOfViewport() {
            return this._isOutOfViewport;
          }
        }
        De.IAB_LARGE_FORMAT_SURFACE = 242500;
        class ye extends De {
          refresh() {}
          getPercentVisible() {
            return 1;
          }
          isInitialized() {
            return !0;
          }
        }
        class we extends De {
          refresh() {
            const e = W.getContainer();
            e &&
              ((this.percentVisible = e.getVisibleRatio()),
              (this.position = e.getAdPosition())),
              this.refreshBannerSize(),
              (this._isOutOfViewport = this.percentVisible <= 0);
          }
          refreshBannerSize() {
            (this.bannerSize = W.getContainer().getAdSize()),
              (this.isHiddenOnScreen = this.bannerSize.equals(T.zero));
          }
          getPercentVisible() {
            return this.percentVisible;
          }
          getPosition() {
            return this.position;
          }
          isInitialized() {
            return !0;
          }
        }
        class Re extends De {
          constructor() {
            super(),
              (this.intersectionObserverViewabilityRate = 0),
              (this.intersectionObserver = null),
              (this._isInitialized = !0),
              (this.initTimeout = new u(() => {
                (this._isInitialized = !0),
                  (this.intersectionObserverViewabilityRate = 0),
                  (this._isOutOfViewport = !0),
                  W.checkDurationStatic();
              }, C.EXCEPTION_109)),
              C.notify(C.EXCEPTION_1003);
          }
          startMeasurement(e) {
            if (this.intersectionObserver)
              this.unobserve(this.intersectionObserver, this.element);
            else {
              const t = se.getElementWindow(e);
              this.intersectionObserver = this.setupNative(t);
            }
            (this.element = e),
              (this._isElementRemoved = !1),
              super.refresh(),
              (this.percentVisible = 0),
              (this._isInitialized = !1),
              this.observe(this.intersectionObserver, e),
              -1 !== g.getUserAgent().indexOf("gecko") &&
                this.requestAnimationFrame(),
              this.initTimeout.schedule(100);
          }
          requestAnimationFrame() {
            window.requestAnimationFrame(() => {});
          }
          observe(e, t) {
            e.observe(t);
          }
          unobserve(e, t) {
            e.unobserve(t);
          }
          refresh() {
            if (
              ((this.isHiddenOnScreen = !1),
              (this._isOutOfViewport = !1),
              !R.isReliable() || se.isNullOrParentNull(this.element))
            )
              return (
                C.notify(C.EXCEPTION_1018),
                (this._isElementRemoved = !0),
                (this.isHiddenOnScreen = !0),
                void (this.percentVisible = 0)
              );
            const e = se.getElementWindow(this.element);
            return this.isDocumentElementNotAvailable(e)
              ? ((this.percentVisible = 0), void (this.isHiddenOnScreen = !0))
              : se.isCSSvisible(e, this.element)
              ? (this.refreshBannerSize(),
                (this.percentVisible =
                  this.intersectionObserverViewabilityRate *
                  W.trackingLoader.trackDisplay.getPercentVisible()),
                void (this._isOutOfViewport = this.percentVisible <= 0))
              : ((this.percentVisible = 0), void (this.isHiddenOnScreen = !0));
          }
          static initOptions() {
            const e = [];
            let t = 101;
            for (; t--; ) e[t] = t / 100;
            return { threshold: e };
          }
          setupNative(e) {
            return new e.IntersectionObserver((e) => {
              try {
                e.forEach((e) => {
                  this.processChange(e.intersectionRatio + 0);
                }),
                  W.checkDurationStatic();
              } catch (e) {
                C.notify(C.EXCEPTION_21);
              }
            }, Re.options);
          }
          processChange(e) {
            this.initTimeout.cancel(),
              (this._isInitialized = !0),
              e > 0.99 ? (e = 1) : e < 0.01 && (e = 0),
              (this.intersectionObserverViewabilityRate = e);
          }
          isInitialized() {
            return this._isInitialized;
          }
        }
        Re.options = Re.initOptions();
        class Me {
          constructor() {
            this.detectionMethodAdvanced =
              Me.DETECTION_METHOD_ADVANCED_NOTFOUND;
          }
          searchNewVisibleElements(e) {
            const t = this.searchNewVisibleElementsImpl(e);
            return (
              this.detectionMethodAdvanced ===
                Me.DETECTION_METHOD_ADVANCED_NOTFOUND &&
                t.length > 0 &&
                (this.detectionMethodAdvanced =
                  Me.DETECTION_METHOD_ADVANCED_DEFAULT),
              t
            );
          }
          ensureValidity(e) {
            try {
              const t = e.getVisibleElement();
              if (t) {
                const i = this.pointRollHack(
                  c.getWindow(),
                  c.getTopAccessibleWindow(),
                  t
                );
                i && (e.initVisibleElement(i), C.notify(C.EXCEPTION_28));
              }
            } catch (e) {
              C.notifyWithException(C.EXCEPTION_13, e);
            }
          }
          pointRollHack(e, t, i) {
            const s = i.id;
            if (s && 0 === s.indexOf("pradi")) {
              const i = "prf" + s.substr(5);
              let n = e.document.getElementById(i);
              if ((n || (n = t.document.getElementById(i)), n)) {
                const e = n.getElementsByClassName("prWrapper");
                if (e.length > 0) return e[0];
              }
            }
            return null;
          }
          setDetectionMethodAdvanced(e) {
            this.detectionMethodAdvanced = e;
          }
          getDetectionMethodCode() {
            return (
              (this.detectionMethodAdvanced !==
              Me.DETECTION_METHOD_ADVANCED_NOTFOUND
                ? "" + this.detectionMethodAdvanced
                : "") + this.getDetectionMethod()
            );
          }
          isWorking() {
            return !0;
          }
        }
        (Me.DETECTION_METHOD_ADVANCED_NOTFOUND = 0),
          (Me.DETECTION_METHOD_ADVANCED_DOUBLE_PARENTS = 1),
          (Me.DETECTION_METHOD_ADVANCED_PARENT_IFRAME = 4),
          (Me.DETECTION_METHOD_ADVANCED_VISUAL = 5),
          (Me.DETECTION_METHOD_ADVANCED_VISUAL_PARENT_IFRAME = 6),
          (Me.DETECTION_METHOD_ADVANCED_HTML_SIBLING = 8),
          (Me.DETECTION_METHOD_ADVANCED_DEFAULT = 9),
          (Me.DETECTION_METHOD_AUTO = 0),
          (Me.DETECTION_METHOD_NODEID = 1),
          (Me.DETECTION_METHOD_NODEIDCHILDREN = 2),
          (Me.DETECTION_METHOD_NODE = 3),
          (Me.DETECTION_METHOD_VIDEO = 5),
          (Me.DETECTION_METHOD_CSS_SELECTOR = 6),
          (Me.DETECTION_METHOD_OMID_LIMITED = 7),
          (Me.DETECTION_METHOD_PREBID_NATIVE = 8),
          (Me.DETECTION_METHOD_DOM_ELT_VAR = 9),
          (Me.visibleElementSeeker = new Ae());
        class Le extends Me {
          searchNewVisibleElementsImpl(e) {
            const t = this.getReferenceElement(e);
            let i = [];
            for (let s = 0; s < t.length; s++) {
              let n = t[s];
              if (!se.isNullOrParentNull(n)) {
                if (M.isInIframe() && M.isInHead(n)) {
                  const e = c.getWindow();
                  n = c.getBodyElementTagNameChecked(e);
                }
                n && (i = i.concat(this.searchElementsImpl(e, n)));
              }
            }
            return i;
          }
          mayFindManyElements() {
            return !0;
          }
        }
        class Ve extends Me {
          constructor(e) {
            super(), (this.domID = e);
          }
          searchNewVisibleElementsImpl(e) {
            let t = null;
            const i = c.getWindow();
            Ve.visibleElementSeeker.setDeclaredCreativeSize(
              e.getDeclaredCreativeSize()
            ),
              this.domID &&
                ((t = re.getWindowElementById(i, this.domID)),
                t &&
                  this.setDetectionMethodAdvanced(
                    Ve.DETECTION_METHOD_ADVANCED_DEFAULT
                  ));
            const s = [];
            return t && s.push(t), s;
          }
          mayFindManyElements() {
            return !1;
          }
          getDetectionMethod() {
            return Ve.DETECTION_METHOD_VIDEO;
          }
        }
        class Xe extends Me {
          constructor(e, t) {
            super(), (this.adIdParam = e), (this.adUnitCodeParam = t);
          }
          static escapeCssSelector(e) {
            return e.replace(/([!"#$%&'()*+,./:;<=>?@[\\\]^`{|}~])/g, "\\$1");
          }
          searchNewVisibleElementsImpl(e) {
            const t = [];
            let i = null;
            const s = c.getWindow(),
              n = c.getTopAccessibleWindow();
            if (this.adIdParam && "" !== this.adIdParam)
              try {
                const e = `.${Xe.AD_ANCHOR_CLASS_NAME}[${Xe.AD_DATA_ADID_ATTRIBUTE}='${this.adIdParam}']`;
                i = M.searchByCssSelectorInAllFrames(s, n, e);
              } catch (e) {
                C.notify(C.EXCEPTION_191);
              }
            if (this.adUnitCodeParam && "" !== this.adUnitCodeParam && !i)
              try {
                if (
                  ((i = M.searchByIdInAllFrames(s, n, this.adUnitCodeParam)[0]),
                  i)
                )
                  C.notify(C.EXCEPTION_1314);
                else {
                  const e = Xe.escapeCssSelector(this.adUnitCodeParam),
                    t = `iframe#${Xe.GPT_ID_PREFIX}${e}${Xe.GPT_ID_SUFFIX}`;
                  (i = M.searchByCssSelectorInAllFrames(s, n, t)),
                    i && C.notify(C.EXCEPTION_1315);
                }
              } catch (e) {
                C.notify(C.EXCEPTION_192);
              }
            return i && t.push(i), t;
          }
          getDetectionMethod() {
            return Me.DETECTION_METHOD_PREBID_NATIVE;
          }
          mayFindManyElements() {
            return !1;
          }
        }
        (Xe.AD_ANCHOR_CLASS_NAME = "pb-click"),
          (Xe.AD_DATA_ADID_ATTRIBUTE = "pbadid"),
          (Xe.GPT_ID_PREFIX = "google_ads_iframe_"),
          (Xe.GPT_ID_SUFFIX = "_0");
        class ke extends Le {
          constructor(e) {
            super(), (this.domId = e);
          }
          getDetectionMethod() {
            return ke.DETECTION_METHOD_NODEIDCHILDREN;
          }
          searchElementsImpl(e, t) {
            ke.visibleElementSeeker.setDeclaredCreativeSize(
              e.getDeclaredCreativeSize()
            );
            let i = ke.visibleElementSeeker.getMeasurableChildren(t, e);
            const s = ke.visibleElementSeeker.getHighPriorityElements();
            return (
              s.length > 0 && (i = [].concat(s)),
              ke.visibleElementSeeker.clean(),
              i
            );
          }
          getReferenceElement(e) {
            const t = c.getWindow(),
              i = c.getTopAccessibleWindow();
            return M.searchByIdInAllFrames(t, i, this.domId);
          }
          mayFindManyElements() {
            return !1;
          }
        }
        class Fe extends Me {
          constructor(e) {
            super(),
              (this.nativeDomIdWasReplaced = !1),
              (this.domId = e),
              (this.nativeDomIdWasReplaced =
                -1 === this.domId.indexOf("native_dom_id"));
          }
          isWorking() {
            return this.nativeDomIdWasReplaced;
          }
          searchNewVisibleElementsImpl(e) {
            if (this.nativeDomIdWasReplaced) {
              const t = c.getWindow(),
                i = c.getTopAccessibleWindow();
              Fe.visibleElementSeeker.setDeclaredCreativeSize(
                e.getDeclaredCreativeSize()
              );
              const s = M.searchByIdInAllFrames(t, i, this.domId),
                n = [];
              for (let e = 0; e < s.length; e++) {
                const t = s[e];
                n.push(t);
              }
              return n;
            }
            return [];
          }
          getDetectionMethod() {
            return Me.DETECTION_METHOD_NODEID;
          }
          mayFindManyElements() {
            return !1;
          }
          ensureValidity(e) {
            if (se.isNullOrParentNull(e.getVisibleElement())) {
              const t = re.getWindowElementById(c.getWindow(), this.domId);
              t && (C.notify(C.EXCEPTION_1019), e.initVisibleElement(t));
            }
          }
        }
        class We extends Me {
          constructor(e) {
            super(), (this.element = e);
          }
          searchNewVisibleElementsImpl(e) {
            const t = [];
            return (
              We.visibleElementSeeker.setDeclaredCreativeSize(
                e.getDeclaredCreativeSize()
              ),
              t.push(this.element),
              t
            );
          }
          getDetectionMethod() {
            return Me.DETECTION_METHOD_NODE;
          }
          mayFindManyElements() {
            return !1;
          }
          ensureValidity(e) {
            const t = e.getVisibleElement();
            if (t) {
              const i = t.id;
              if (i) {
                let t = null;
                if (
                  (se.isNullOrParentNull(e.getVisibleElement()) &&
                    (t = re.getWindowElementById(c.getWindow(), i)),
                  i.endsWith("_html5_api"))
                ) {
                  C.notify(C.EXCEPTION_1022);
                  let e = re.getWindowElementById(
                    c.getWindow(),
                    i.replace("_html5_api", "")
                  );
                  if (!e) {
                    const t = M.searchByIdInAllFrames(
                      c.getWindow(),
                      c.getTopAccessibleWindow(),
                      i.replace("_html5_api", "")
                    );
                    t.length > 0 && (e = t[0]);
                  }
                  e && (t = e);
                }
                t && (C.notify(C.EXCEPTION_1020), e.initVisibleElement(t));
              }
            }
          }
        }
        class Ue extends Me {
          constructor() {
            super(), (this.hasAlreadyFindElement = !1);
          }
          searchNewVisibleElementsImpl(e) {
            this.setDetectionMethodAdvanced(
              Ue.DETECTION_METHOD_ADVANCED_DEFAULT
            );
            const t = [];
            return (
              this.hasAlreadyFindElement ||
                (t.push(null), (this.hasAlreadyFindElement = !0)),
              t
            );
          }
          mayFindManyElements() {
            return !1;
          }
          getDetectionMethod() {
            return Ue.DETECTION_METHOD_OMID_LIMITED;
          }
        }
        class xe extends Me {
          constructor(e) {
            super(), (this.varName = e);
          }
          searchNewVisibleElementsImpl(e) {
            const t = [],
              i = this.getElementFromVarName();
            return i ? t.push(i) : C.notify(C.EXCEPTION_1318), t;
          }
          getElementFromVarName() {
            let e = null,
              t = c.getWindow();
            for (; !e && t; )
              (e = this.getNativeElementFromVarName(t, this.varName)),
                (t = R.getAccessibleParentWindow(t));
            return e;
          }
          getNativeElementFromVarName(e, t) {
            return void 0 !== e && void 0 !== e[t] ? e[t] : null;
          }
          getDetectionMethod() {
            return Me.DETECTION_METHOD_DOM_ELT_VAR;
          }
          mayFindManyElements() {
            return !1;
          }
          ensureValidity(e) {
            if (se.isNullOrParentNull(e.getVisibleElement())) {
              const t = this.getElementFromVarName();
              t && (C.notify(C.EXCEPTION_1019), e.initVisibleElement(t));
            }
          }
        }
        class Be extends Me {
          constructor(e) {
            super(), (this.cssSelectorParam = e);
          }
          searchNewVisibleElementsImpl(e) {
            let t = null;
            const i = c.getWindow(),
              s = c.getTopAccessibleWindow();
            try {
              t = M.searchByCssSelectorInAllFrames(i, s, this.cssSelectorParam);
            } catch (e) {
              C.notify(C.EXCEPTION_190);
            }
            if (t) {
              const e = [];
              return e.push(t), e;
            }
            return [];
          }
          getDetectionMethod() {
            return Me.DETECTION_METHOD_CSS_SELECTOR;
          }
          mayFindManyElements() {
            return !1;
          }
        }
        class He extends Le {
          getDetectionMethod() {
            return He.DETECTION_METHOD_AUTO;
          }
          searchElementsImpl(e, t) {
            const i = c.getWindow();
            He.visibleElementSeeker.setDeclaredCreativeSize(
              e.getDeclaredCreativeSize()
            );
            let s =
              He.visibleElementSeeker.searchVisibleElementsInSiblingAndChildren(
                t,
                e
              );
            const n = He.visibleElementSeeker.getHighPriorityElements();
            n.length > 0
              ? ((s = [].concat(n)),
                this.setDetectionMethodAdvanced(
                  He.DETECTION_METHOD_ADVANCED_DEFAULT
                ))
              : s.length > 0 &&
                this.setDetectionMethodAdvanced(
                  He.DETECTION_METHOD_ADVANCED_DEFAULT
                ),
              0 === s.length &&
                (M.isInIframe() || W.getContainer()) &&
                ((s =
                  He.visibleElementSeeker.lookForHtmlOnlyCreativeInIframeBody(
                    i
                  )),
                s.length > 0 &&
                  this.setDetectionMethodAdvanced(
                    He.DETECTION_METHOD_ADVANCED_HTML_SIBLING
                  ));
            const r = e.getFakeImageElement();
            if (
              (0 === s.length &&
                r &&
                ((s =
                  He.visibleElementSeeker.searchVisibleElementsVisuallyNear(r)),
                s.length > 0 &&
                  this.setDetectionMethodAdvanced(
                    He.DETECTION_METHOD_ADVANCED_VISUAL
                  )),
              t && !M.isInHead(t) && 0 === s.length)
            ) {
              if (
                ((s =
                  He.visibleElementSeeker.searchVisibleElementsInSiblingAndChildren(
                    re.getParent(t),
                    e
                  )),
                s.length > be.MAX_TRACKED_OBJECTS_NUMBER / 2)
              )
                return C.notify(C.EXCEPTION_16), (s = []), s;
              s.length > 0 &&
                this.setDetectionMethodAdvanced(
                  He.DETECTION_METHOD_ADVANCED_DOUBLE_PARENTS
                );
            }
            if (0 === s.length && M.isInIframeSameDomain()) {
              const t = R.getAccessibleParentWindow(i);
              if (t) {
                const n = R.getFrameElement(t, i);
                n &&
                  ((s = He.visibleElementSeeker.searchVisibleElementsInSibling(
                    n,
                    e
                  )),
                  s.length > 0
                    ? this.setDetectionMethodAdvanced(
                        He.DETECTION_METHOD_ADVANCED_PARENT_IFRAME
                      )
                    : ((s =
                        He.visibleElementSeeker.searchVisibleElementsVisuallyNear(
                          n
                        )),
                      s.length > 0 &&
                        this.setDetectionMethodAdvanced(
                          He.DETECTION_METHOD_ADVANCED_VISUAL_PARENT_IFRAME
                        )));
              }
            }
            return He.visibleElementSeeker.clean(), s;
          }
          getReferenceElement(e) {
            const t = e.getScriptElement(),
              i = [];
            return (
              se.isNullOrParentNull(t)
                ? i.push(e.getFakeImageElement())
                : i.push(t),
              i
            );
          }
        }
        class ze {
          constructor(e) {
            (this.visibleElement = null),
              (this.visibleElementInitialized = !1),
              (this._deleteAfterFlush = !1),
              (this.lastShotVisiblePercent = 0),
              (this._isOutOfViewportLastShot = !1),
              (this._isHiddenCreativeLastShot = !1),
              (this._isFirstInitializedFlushDone = !1),
              (this.metricsAggregator = new qe(this)),
              (this.commitedDurationCache = 0),
              (this.tag = e);
          }
          getIABDurationThreshold() {
            return 1e3;
          }
          applyInitialization() {}
          shot() {
            this.visibleElementInitialized &&
              (this.setLastShotVisiblePercent(this.getPercentVisible()),
              this.setLastShotIsOutOfViewport(
                this.getVisibilityCalculator().isOutOfViewport()
              ),
              this.setIsHiddenCreativeLastShot(
                this.getVisibilityCalculator().isHiddenCreative()
              ),
              this.tag.getSearchStrategy().ensureValidity(this),
              this.visibilityCalculator.refresh(),
              this.visibilityCalculator.isElementRemoved() &&
                this.deleteAfterFlush());
          }
          calculateAdvertising(e) {
            e < 0 && (C.notify(C.EXCEPTION_9), (e = 0)),
              this.visibilityCalculator.isInitialized()
                ? ((e += this.commitedDurationCache),
                  (this.commitedDurationCache = 0))
                : ((this.commitedDurationCache += e), (e = 0)),
              this.getMetricsAggregator().calculateAdvertising(e);
          }
          initVisibleElement(e) {
            (this.visibleElementInitialized = !0),
              (this._isFirstInitializedFlushDone = !1),
              (this.visibleElement = e),
              this.tag.getTrackedElements().push(e),
              e && se.setAttribute(e, this.tag.getControlKey(), "y"),
              this.visibilityCalculator.startMeasurement(e),
              this.tag.setFlushed(!1);
          }
          postFlushCleanup() {
            this.visibleElementInitialized &&
              (this._isFirstInitializedFlushDone = !0);
          }
          hasDeleteAfterFlush() {
            return this._deleteAfterFlush;
          }
          deleteAfterFlush() {
            this._deleteAfterFlush = !0;
            const e = this.tag
              .getTrackedElements()
              .indexOf(this.visibleElement);
            e > -1 && this.tag.getTrackedElements().splice(e, 1);
          }
          getVisibleElement() {
            return this.visibleElement;
          }
          getTag() {
            return this.tag;
          }
          isFirstInitializedFlushDone() {
            return this._isFirstInitializedFlushDone;
          }
          getPercentVisible() {
            return this.visibilityCalculator.getPercentVisible();
          }
          isInitialized() {
            return this.visibleElementInitialized;
          }
          getMetricsAggregator() {
            return this.metricsAggregator;
          }
          getVisibilityCalculator() {
            return this.visibilityCalculator;
          }
          setVisibilityCalculator(e) {
            this.visibilityCalculator = e;
          }
          isIabVisible() {
            return this.visibilityCalculator.isIABVisible();
          }
          getLastShotVisiblePercent() {
            return this.lastShotVisiblePercent;
          }
          setLastShotVisiblePercent(e) {
            this.lastShotVisiblePercent = e;
          }
          isOutOfViewportLastShot() {
            return this._isOutOfViewportLastShot;
          }
          setLastShotIsOutOfViewport(e) {
            this._isOutOfViewportLastShot = e;
          }
          isHiddenCreativeLastShot() {
            return this._isHiddenCreativeLastShot;
          }
          setIsHiddenCreativeLastShot(e) {
            this._isHiddenCreativeLastShot = e;
          }
        }
        class je {
          static checkSafeframeSignals() {
            try {
              je.checkSafeFrameSupport();
            } catch (e) {
              C.notify(C.EXCEPTION_142);
            }
          }
          static checkJsSignals() {
            je.checkGoogleDataAvailability(),
              je.checkMetaRefreshTag(),
              se.isFunctionNative(je.getDocumentWriteFunctionNative()) ||
                C.notify(C.EXCEPTION_1030);
            const e = c.getTopAccessibleWindow();
            je.checkAmp(e),
              je.hasMraid3Env(e) && C.notify(C.EXCEPTION_1010),
              d.elementHasDefined(e, "ADMARVEL") && C.notify(C.EXCEPTION_1012),
              d.elementHasDefined(e, "InmobiObj") && C.notify(C.EXCEPTION_1013),
              d.elementHasDefined(e, "PandoraApp") &&
                C.notify(C.EXCEPTION_1014),
              d.elementHasDefined(e, "Adform") && C.notify(C.EXCEPTION_1015),
              d.elementHasDefined(c.getWindow(), "omid3p") &&
                C.notify(C.EXCEPTION_1016),
              d.elementHasDefined(
                c.getWindow(),
                "omidVerificationProperties"
              ) && C.notify(C.EXCEPTION_1017),
              d.elementHasDefined(c.getWindow(), "ADNXSMediation") &&
                C.notify(C.EXCEPTION_1161),
              M.isInIframeSameDomain() &&
                new u(() => {
                  this.isProbablyCollapsedAstAd() && C.notify(C.EXCEPTION_1162);
                }, C.EXCEPTION_5).schedule(700);
          }
          static isProbablyCollapsedAstAd() {
            try {
              return "none" === window.frameElement.parentElement.style.display;
            } catch (e) {
              return !1;
            }
          }
          static checkAmp(e) {
            ((void 0 !== e.location.host &&
              -1 !== e.location.host.indexOf("ampproject.net")) ||
              (void 0 !== e.document.referrer &&
                -1 !== e.document.referrer.indexOf("ampproject.net"))) &&
              C.notify(C.EXCEPTION_1001);
          }
          static hasMraid3Env(e) {
            return (
              "object" == typeof e.MRAID_ENV &&
              "string" == typeof e.MRAID_ENV.version &&
              "3" === e.MRAID_ENV.version.charAt(0) &&
              "." === e.MRAID_ENV.version.charAt(1)
            );
          }
          static registerScriptStatusFunction(e) {
            const t = e.document.lntIsScriptStatusOK;
            e.document.lntIsScriptStatusOK = function () {
              return (void 0 === t || t()) && je.isScriptStatusOk();
            };
            const i = c.getNamespace();
            (i.ss = je.isScriptStatusOk),
              (i.st = je.getTimeToFindOneObjectAtLeast);
          }
          static registerNewScript() {
            c.getNamespace().n = St.refreshContent;
          }
          static registerActivityStatusFunction(e) {
            (e.document.lntActive = W.isActive),
              (e.document.lntInactiveEvent = W.inactiveEvent);
          }
          static registerTrkFinalize() {
            c.getNamespace().ff = function () {
              W.trkFinalize(Qe.RR_API_FINALIZE);
            };
          }
          static registerTrkForceIntermediateRequest() {
            c.getNamespace().fir = W.sendIntermediateRequest;
          }
          static getDocumentWriteFunctionNative() {
            return window.document.write;
          }
          static isScriptStatusOk() {
            for (let e = 0; e < Pe.getTagCount(); e++)
              if (!Pe.getTagAtIndex(e).hasAtLeastOneObjectInitialized())
                return !1;
            return !0;
          }
          static getTimeToFindOneObjectAtLeast() {
            for (let e = 0; e < Pe.getTagCount(); e++) {
              const t = Pe.getTagAtIndex(e);
              if (t.hasAtLeastOneObjectInitialized())
                return t.getTimeToHaveAtLeastOneObjectInitialized();
            }
            return -1;
          }
          static hasGoogleContainer() {
            try {
              const e = /^([^;]+);(\d+);([\s\S]*)$/.exec(window.name);
              return (
                !(void 0 === e || !e) && !(parseInt(e[2], 10) > e[3].length)
              );
            } catch (e) {
              return !1;
            }
          }
          static checkGoogleEvent(e) {
            if (!je.hasGoogleSafeframeWithGeometry) {
              const t = e.data.toString();
              if (t && -1 !== t.indexOf("goog_update_data")) {
                C.notify(C.EXCEPTION_1145);
                let e = t.indexOf("\n7=");
                if (-1 !== e) {
                  e += 3;
                  const i = t.substring(e).indexOf("\n");
                  if (-1 !== i) {
                    const s = t.substring(e, e + i);
                    try {
                      parseFloat(s),
                        C.notify(C.EXCEPTION_1146),
                        (je.hasGoogleSafeframeWithGeometry = !0);
                    } catch (e) {}
                  }
                }
              }
            }
          }
          static checkGoogleDataAvailability() {
            try {
              je.hasGoogleContainer() && C.notify(C.EXCEPTION_1144);
              const e = c.getTopAccessibleWindow();
              se.addEventListenerWithEventListenerWrapper(
                e,
                e,
                "message",
                new O(C.EXCEPTION_147, (e) => {
                  if (e) {
                    const t = e;
                    je.checkGoogleEvent(t);
                  }
                })
              );
            } catch (e) {
              C.notify(C.EXCEPTION_148);
            }
          }
          static hasSafeFrameApi() {
            return void 0 !== window.$sf;
          }
          static getSafeFrameApi() {
            return window.$sf.ext;
          }
          static checkGeom(e) {
            return void 0 === e.geom || void 0 === e.geom().self;
          }
          static checkHasWinHasFocus(e) {
            return void 0 === e.winHasFocus;
          }
          static checkIsAst() {
            return window.$sf.ast;
          }
          static checkSafeFrameSupport() {
            if (je.hasSafeFrameApi()) {
              const e = je.getSafeFrameApi();
              if (!e) return;
              if ((C.notify(C.EXCEPTION_1140), je.checkGeom(e))) return;
              if ((C.notify(C.EXCEPTION_1141), je.checkHasWinHasFocus(e)))
                return;
              if ((C.notify(C.EXCEPTION_1143), !je.checkIsAst())) return;
              C.notify(C.EXCEPTION_1006);
            }
          }
          static getMetaRefreshContentTag() {
            const e = [];
            let t = c.getWindow();
            if (!t) return e;
            if (!M.isWindowDocumentAccessible(t)) return e;
            je.findMetaRefreshTags(t, e);
            let i = t.parent,
              s = 0;
            for (; i && i !== t; ) {
              if (((t = i), (i = t.parent), !M.isWindowDocumentAccessible(t)))
                return e;
              if ((je.findMetaRefreshTags(t, e), s++, s > 10))
                return C.notify(C.EXCEPTION_153), e;
            }
            return e;
          }
          static findMetaRefreshTags(e, t) {
            const i = se.getElementsByTagName(e, "meta");
            for (let e = 0; e < i.length; e++) {
              const s = i[e],
                n = s.getAttribute("http-equiv");
              n && "refresh" === n && t.push(s);
            }
          }
          static checkMetaRefreshTag() {
            try {
              if (!je.hasFoundMetaRefreshTagLess60s) {
                const e = je.getMetaRefreshContentTag();
                if (e.length > 0) {
                  C.notify(C.EXCEPTION_1150);
                  for (let t = 0; t < e.length; t++) {
                    const i = e[t].getAttribute("content");
                    if (i) {
                      const e = je.getMetaRefreshTimer(i);
                      e &&
                        parseInt(e, 10) <= 60 &&
                        (C.notify(C.EXCEPTION_1151),
                        (je.hasFoundMetaRefreshTagLess60s = !0));
                    }
                  }
                }
              }
            } catch (e) {
              C.notify(C.EXCEPTION_152);
            }
          }
          static getMetaRefreshTimer(e) {
            const t = /^(\s*)(\d+)/.exec(e);
            return t && t.length >= 2 ? t[2] : null;
          }
        }
        (je.hasGoogleSafeframeWithGeometry = !1),
          (je.hasFoundMetaRefreshTagLess60s = !1);
        class qe {
          constructor(e) {
            (this.pageDuration = 0),
              (this.time000PercentVisible = 0),
              (this.time025PercentVisible = 0),
              (this.time050PercentVisible = 0),
              (this.time075PercentVisible = 0),
              (this.time100PercentVisible = 0),
              (this.iabDuration = 0),
              (this.iabConsecutiveDuration = 0),
              (this.iabDurationSinceLastIAB = 0),
              (this.iabInviewCount = 0),
              (this.hasBeenIABViewable = !1),
              (this.maxBannerSize = T.minusOne),
              (this.maxVisibleSurface = -1),
              (this.maxPosition = null),
              (this.trackedObject = e);
          }
          calculateAdvertising(e) {
            if (!this.trackedObject.isInitialized()) return;
            if (e > 0) {
              const t = this.trackedObject.getPercentVisible();
              t > this.maxVisibleSurface && (this.maxVisibleSurface = t),
                (this.pageDuration += e),
                t > 0 &&
                  ((this.time000PercentVisible += e),
                  t >= 0.25 &&
                    ((this.time025PercentVisible += e),
                    t >= 0.5 &&
                      ((this.time050PercentVisible += e),
                      t >= 0.75 &&
                        ((this.time075PercentVisible += e),
                        t >= 1 && (this.time100PercentVisible += e))))),
                this.trackedObject.isIabVisible() && (this.iabDuration += e),
                this.computedConsecutiveIABViewability(e);
            }
            const t = this.trackedObject.getVisibilityCalculator(),
              i = t.getBannerSize();
            this.maxBannerSize = this.maxBannerSize.max(i);
            const s = this.maxPosition;
            this.maxPosition = s ? s.max(t.getPosition()) : t.getPosition();
          }
          getIABVisible() {
            return this.iabDuration > 0;
          }
          computedConsecutiveIABViewability(e) {
            this.trackedObject.isIabVisible()
              ? (this.iabDurationSinceLastIAB += e)
              : ((this.iabDurationSinceLastIAB = 0),
                (this.hasBeenIABViewable = !1)),
              this.iabDurationSinceLastIAB >=
                this.trackedObject.getIABDurationThreshold() &&
                (this.hasBeenIABViewable
                  ? (this.iabConsecutiveDuration += e)
                  : (this.iabInviewCount++,
                    (this.iabConsecutiveDuration +=
                      this.iabDurationSinceLastIAB)),
                (this.hasBeenIABViewable = !0));
          }
          getPageDuration() {
            return this.pageDuration;
          }
          getTime000PercentVisible() {
            return this.time000PercentVisible;
          }
          getTime025PercentVisible() {
            return this.time025PercentVisible;
          }
          getTime050PercentVisible() {
            return this.time050PercentVisible;
          }
          getTime075PercentVisible() {
            return this.time075PercentVisible;
          }
          getTime100PercentVisible() {
            return this.time100PercentVisible;
          }
          getIABDuration() {
            return this.iabDuration;
          }
          getConsecutiveIABDuration() {
            return this.iabConsecutiveDuration;
          }
          getIABInviewCount() {
            return this.iabInviewCount;
          }
          getMaxBannerSize() {
            return this.maxBannerSize;
          }
          getMaxVisibleSurface() {
            return this.maxVisibleSurface;
          }
          getPosition() {
            return this.maxPosition;
          }
        }
        class Ge extends qe {
          constructor(e) {
            super(e),
              (this.videoGroupMVisibleDuration = 0),
              (this.audio100PercentDuration = 0);
          }
          calculateAdvertising(e) {
            super.calculateAdvertising(e),
              rt.isGroupMVisible(this.getVideoTrackedObject()) &&
                (this.videoGroupMVisibleDuration += e),
              this.trackedObject.getPercentVisible() >= 1 &&
                1 === this.getVideoTrackedObject().getTag().getSoundState() &&
                (this.audio100PercentDuration += e);
          }
          getVideoTrackedObject() {
            return this.trackedObject;
          }
          getVideoGroupMVisibleDuration() {
            return this.videoGroupMVisibleDuration;
          }
          getAudio100PercentDuration() {
            return this.audio100PercentDuration;
          }
        }
        class Ke {
          constructor(e) {
            (this.pageDuration = 0),
              (this.lastDeletedTrackedObjectData = null),
              (this.tag = e);
          }
          calculateAdvertising(e) {
            e < 0 && (C.notify(C.EXCEPTION_129), (e = 0)),
              (this.pageDuration += e);
          }
          getPageDuration() {
            return this.pageDuration;
          }
          getTrackingDuration() {
            let e = g.getCurrentTime() - this.tag.getTagCreationTime();
            return e < 0 && (C.notify(C.EXCEPTION_128), (e = 0)), e;
          }
          getLastDeletedTrackedObjectData() {
            return this.lastDeletedTrackedObjectData;
          }
          setLastDeletedTrackedObjectData(e) {
            this.lastDeletedTrackedObjectData = e;
          }
        }
        class $e {
          constructor(e) {
            (this._isHiddenCreative = e.isHiddenCreativeLastShot()),
              (this._isOutOfViewport = e.isOutOfViewportLastShot());
            const t = e.getMetricsAggregator(),
              i = e.getTag().getTriggerManager().getIabTrigger(),
              s = i.getDurationThreshold(e),
              n = i.getTrackedObjectDuration(e),
              r = t.getTime000PercentVisible(),
              a = e.getLastShotVisiblePercent();
            (this._isIABVisibleWithoutDurationThreshold =
              n > 0 && n < s && a > 0),
              (this._isVisibleWithoutIABSurfaceThreshold =
                0 === n && r > 0 && a > 0 && a < s);
          }
          isHiddenCreative() {
            return this._isHiddenCreative;
          }
          isOutOfViewport() {
            return this._isOutOfViewport;
          }
          isIABVisibleWithoutDurationThreshold() {
            return this._isIABVisibleWithoutDurationThreshold;
          }
          isVisibleWithoutIABSurfaceThreshold() {
            return this._isVisibleWithoutIABSurfaceThreshold;
          }
        }
        class Ye extends be {
          constructor(e, t) {
            super(e, t),
              (this.soundState = -1),
              (this.creativeDuration = 0),
              (this.adUID = e.getAdUID()),
              this.onDurationReceived(e.getDuration()),
              e.isSoundOn() && (this.soundState = 1),
              Ie.manageReferrerDetection(e);
          }
          createTriggerManager() {
            return new ct();
          }
          createRequestFormatter() {
            return new Ze(this);
          }
          createTrackedObject() {
            return new tt(this);
          }
          searchElements() {
            this.doSearchElements();
          }
          doSearchElements() {
            if (
              !this.atLeastOneObjectInitialized &&
              this.getTrackedObjectCount() > 0
            ) {
              const e = this.searchStrategy.searchNewVisibleElements(this);
              if (e.length > 0) {
                const t = e[0];
                this.isAlreadyTrackedForThisTag(t) ||
                  (this.getFirstObject().initVisibleElement(t),
                  (this.atLeastOneObjectInitialized = !0),
                  (this.timerFirstObjectInitialized = g.getCurrentTime()));
              }
            }
          }
          getAdUID() {
            return this.adUID;
          }
          createIABTrigger() {
            return new nt();
          }
          getTagURL() {
            return this.tagURL;
          }
          onSoundOnEvent() {
            this.soundState = 1;
          }
          onSoundOffEvent() {
            this.soundState = 0;
          }
          getSoundState() {
            return this.soundState;
          }
          hasReceivedSoundState() {
            return -1 !== this.soundState;
          }
          onDurationReceived(e) {
            this.creativeDuration = e;
          }
          hasCreativeDuration() {
            return this.creativeDuration > 0;
          }
          getCreativeDuration() {
            return this.creativeDuration;
          }
          getCreativeDurationMilliseconds() {
            return 1e3 * this.creativeDuration;
          }
        }
        function Je(e) {
          return "function" == typeof e;
        }
        class Qe {
          constructor(e) {
            (this.shouldFlush = !1),
              (this._isFirstRequest = !0),
              (this.shouldIncludeFullData = !1),
              (this.trackedObject = null),
              (this.lastTrackedObject = null),
              (this.requestReason = -1),
              (this.tag = e),
              (this.callbackUrl = e.getTagURL().getParameter("cb") || "");
          }
          getDimensionParameters() {
            const e = c.getTopAccessibleWindow(),
              t = c.getScreenSize(),
              i = c.getPageSize(e),
              s = c.getWindowSize(e);
            return `&sw=${t.getX()}&sh=${t.getY()}&pw=${i.getX()}&ph=${i.getY()}&ww=${s.getX()}&wh=${s.getY()}`;
          }
          getContextParameters() {
            const e = g.getScriptVersion(),
              t = g.getUserAgent(),
              i = this.tag.getTagURL();
            let s = `&sv=${e}&tv=${
              i.getParameter("tv") || ""
            }&ua=${t}&pl=${g.getPlatform()}&x=${g.getScriptId()}`;
            const n = i.getParameter("tag_id");
            return n && (s += `&tag_id=${n}`), s;
          }
          formatDimensionParameters(e) {
            const t = e.getMetricsAggregator();
            let i = "";
            const s = t.getPosition();
            s &&
              !s.equals(T.minusOne) &&
              (i += `&px=${s.getX()}&py=${s.getY()}`);
            const n = t.getMaxBannerSize();
            if (
              (n.equals(T.minusOne) || (i += `&bw=${n.getX()}&bh=${n.getY()}`),
              W.trackingLoader.isTrackingSupported())
            ) {
              const e = d.rounded2Decimals(t.getMaxVisibleSurface());
              e >= 0 && (i += `&sf=${e}`);
            }
            return i;
          }
          getDurationParameters() {
            const e = this.tag.getTagMetricsAggregator(),
              t = e.getPageDuration(),
              i = e.getTrackingDuration(),
              s = this.trackedObject.getMetricsAggregator();
            let n = `&pd=${d.getSecondsFromMillisWith2Decimal(
              t
            )}&d=${d.getSecondsFromMillisWith2Decimal(i)}`;
            return (
              this.tag.getTriggerManager().isMeasurementInitialized() &&
                (n += `&id=${d.getSecondsFromMillisWith2Decimal(
                  s.getConsecutiveIABDuration()
                )}&ic=${s
                  .getIABInviewCount()
                  .toString()}&d0=${d.getSecondsFromMillisWith2Decimal(
                  s.getTime000PercentVisible()
                )}&d25=${d.getSecondsFromMillisWith2Decimal(
                  s.getTime025PercentVisible()
                )}&d50=${d.getSecondsFromMillisWith2Decimal(
                  s.getTime050PercentVisible()
                )}&d75=${d.getSecondsFromMillisWith2Decimal(
                  s.getTime075PercentVisible()
                )}&d100=${d.getSecondsFromMillisWith2Decimal(
                  s.getTime100PercentVisible()
                )}`),
              n
            );
          }
          shouldExecuteViewCb(e) {
            return (
              this.tag.getTagURL().shouldExecuteViewCb() &&
              !this.tag.hasViewCbFired() &&
              e === ht.VISIBLE
            );
          }
          static parseViewResult(e) {
            if (-1 !== e.indexOf("&")) {
              const t = e.split("&");
              return { viewState: t[0], type: t[1].split("=")[1] };
            }
            return { viewState: e, type: null };
          }
          static findAllCallbacksInWindowChain(e, t) {
            const i = [];
            let s = e;
            for (; s; ) {
              try {
                const e = s[t];
                Je(e) && i.push(e);
              } catch {
                return i;
              }
              if (s === s.parent || !s.parent) break;
              s = s.parent;
            }
            return i;
          }
          static triggerViewStateChange(e, t, i, s) {
            const n = Qe.findAllCallbacksInWindowChain(
              e,
              "_lntViewStateChange"
            );
            if (0 === n.length) return void C.notify(C.EXCEPTION_1502);
            const { viewState: r, type: a } = Qe.parseViewResult(i),
              o = {
                tagId: t,
                viewState: r,
                type: a,
                exceptions: c.getNamespace().e,
                requestReason: s,
              };
            for (const e of n)
              try {
                e({ ...o }), C.notify(C.EXCEPTION_1500);
              } catch {
                C.notify(C.EXCEPTION_1501);
              }
          }
          static triggerViewDiagnostics(e, t, i, s) {
            const n = Qe.findAllCallbacksInWindowChain(
              e,
              "_lntViewDiagnostics"
            );
            if (0 === n.length) return void C.notify(C.EXCEPTION_1505);
            const { viewState: r, type: a } = Qe.parseViewResult(i),
              o = {
                tagId: t,
                viewState: r,
                type: a,
                exceptions: c.getNamespace().e,
                requestReason: s,
              };
            for (const e of n)
              try {
                e({ ...o }), C.notify(C.EXCEPTION_1503);
              } catch {
                C.notify(C.EXCEPTION_1504);
              }
          }
          sendRequest() {
            let e = "";
            this.trackedObject ||
              (this.trackedObject = this.tag.getFirstObject());
            const t = C.getRequestPart();
            "" !== t && (e += `&jm=${t}`),
              this.trackedObject &&
                (e += this.formatDimensionParameters(this.trackedObject)),
              (e += `&sid=${E.getSessionId()}${this.getViewabilityDataParameter()}${this.getContextParameters()}`);
            const i = this.tag.getTriggerManager(),
              s = i.getViewResult(),
              n = i.getCustomViewResult();
            if (
              (n && (e += `&cid=${i.getCustomTrigger().getId()}&cr=${n}`),
              this._isFirstRequest &&
                ((this._isFirstRequest = !1),
                (this.requestReason = Qe.RR_FIRST_REQUEST),
                r() || (e += this.getDimensionParameters())),
              (e += this.getAllRequestsExtraParameters()),
              this.shouldIncludeFullData &&
                (d.isMobile() &&
                  (this.lastTrackedObject
                    ? (this.trackedObject = this.lastTrackedObject)
                    : (this.lastTrackedObject = this.trackedObject)),
                (e += this.getDurationParameters())),
              "" === this.callbackUrl)
            )
              C.notify(C.EXCEPTION_111);
            else {
              const t = M.getFrameType().toString();
              Ce.sendRequestWithoutCookie(
                `${this.callbackUrl}&type=${s}${e}&ft=${t}`,
                this.shouldIncludeFullData
              );
            }
            this.shouldExecuteViewCb(s) &&
              (Qe.triggerViewStateChange(
                c.getWindow(),
                this.tag.getTagURL().getParameter("tag_id") || "",
                s,
                this.requestReason
              ),
              this.tag.setViewCbFired(!0)),
              this.tag.getTagURL().shouldExecuteViewCb() &&
                Qe.triggerViewDiagnostics(
                  c.getWindow(),
                  this.tag.getTagURL().getParameter("tag_id") || "",
                  s,
                  this.requestReason
                ),
              (this.shouldFlush = !1),
              (this.requestReason = -1);
          }
          getAllRequestsExtraParameters() {
            return "";
          }
          getViewabilityDataParameter() {
            const e = [],
              t = this.tag.getTagURL();
            _e.isABTestingCaseA()
              ? e.push("ab~1")
              : _e.isABTestingCaseB() && e.push("ab~2"),
              e.push(`ct~${I.getContainerType()}`);
            let i = "";
            const s = W.getContainer();
            if (
              s &&
              this.tag.getTriggerManager().getViewResult() !== ht.VISIBLE
            ) {
              const e = s.getDebugGeometricInfo("~");
              e.length > 0 && (i = `|${e.join("|")}`);
            }
            const n = t.getPartnerName();
            if (n)
              try {
                e.push(`pn~${I.cleanPartnerNameCharacters(n)}`);
              } catch (e) {
                C.notify(C.EXCEPTION_205);
              }
            return (
              e.push(`rr~${this.requestReason}`),
              this.shouldIncludeFullData &&
                e.push(`dm~${this.tag.getDetectionMethod()}`),
              `&vd=${e.join("|")}${i}`
            );
          }
          requestFlushWithFullData(e) {
            (this.shouldIncludeFullData = !0), this.requestFlush(e);
          }
          setTrackedObject(e) {
            this.trackedObject = e;
          }
          flushIfNecessary() {
            this.shouldFlush &&
              this.tag.isUnderUltimateTimeoutLimit() &&
              this.sendRequest();
          }
          requestFlush(e) {
            (this.requestReason = e), (this.shouldFlush = !0);
          }
          isFirstRequest() {
            return this._isFirstRequest;
          }
        }
        (Qe.RR_FIRST_REQUEST = 0),
          (Qe.RR_NM_REQUEST = 2),
          (Qe.RR_CUSTOM_NM_REQUEST = 3),
          (Qe.RR_PV_REQUEST = 5),
          (Qe.RR_CUSTOM_PV_REQUEST = 6),
          (Qe.RR_MOBILE_INTERMEDIATE_REQUEST = 8),
          (Qe.RR_XX_SECONDS_UPDATE = 100),
          (Qe.MAX_RR_XX_SECONDS_UPDATE = 299),
          (Qe.RR_DELETE = 314),
          (Qe.RR_API_FINALIZE = 316),
          (Qe.RR_CLIP_INTERRUPT = 317),
          (Qe.RR_CLIP_STOP = 318),
          (Qe.RR_PAGE_HIDE_REQUEST = 319),
          (Qe.RR_BEFORE_UNLOAD_REQUEST = 320),
          (Qe.RR_TIMEOUT = 322),
          (Qe.RR_OMID_SESSION_FINISH = 323);
        class Ze extends Qe {
          constructor(e) {
            super(e);
          }
          getAllRequestsExtraParameters() {
            let e = super.getAllRequestsExtraParameters();
            const t = this.tag;
            return (
              t.hasCreativeDuration() &&
                (e +=
                  "&cd=" +
                  d.getSecondsFromMillisWith2Decimal(
                    t.getCreativeDurationMilliseconds()
                  )),
              e
            );
          }
          getDurationParameters() {
            let e = super.getDurationParameters();
            if (
              this.trackedObject &&
              this.trackedObject.isInitialized() &&
              W.trackingLoader.isTrackingSupported() &&
              this.tag.hasReceivedSoundState()
            ) {
              const t = this.trackedObject
                .getMetricsAggregator()
                .getAudio100PercentDuration();
              e += "&a100=" + d.getSecondsFromMillisWith2Decimal(t);
            }
            return e;
          }
        }
        class et extends be {
          constructor(e, t) {
            super(e, t), (this.lastSearchTime = 0), (this.searchCount = 0);
          }
          searchElements() {
            const e = this.hasAtLeastOneObjectInitialized() ? 950 : 450;
            g.getCurrentTime() - this.lastSearchTime > e &&
              this.doSearchElements(),
              1 !== this.searchCount ||
                this.hasAtLeastOneObjectInitialized() ||
                c.isHiddenWithWindow(c.getTopAccessibleWindow()) ||
                new u(() => {
                  this.doSearchElements(), W.checkDurationStatic();
                }, C.EXCEPTION_39).schedule(1);
          }
          doSearchElements() {
            if (
              ((this.lastSearchTime = g.getCurrentTime()),
              this.searchCount++,
              !R.isReliable())
            )
              return;
            if (
              this.hasAtLeastOneObjectInitialized() &&
              (!this.searchStrategy.mayFindManyElements() ||
                this.lastSearchTime - this.getTagCreationTime() >= 5e3)
            )
              return;
            const e = this.searchStrategy.searchNewVisibleElements(this);
            if (0 !== e.length) {
              if (this.getTrackedObjectCount() > 0)
                for (
                  ;
                  !this.hasAtLeastOneObjectInitialized() && e.length > 0;

                ) {
                  const t = e.shift();
                  this.isAlreadyTrackedForThisTag(t) ||
                    (this.getFirstObject().initVisibleElement(t),
                    (this.atLeastOneObjectInitialized = !0),
                    (this.timerFirstObjectInitialized = g.getCurrentTime()));
                }
              this.createTrackedObjects(e);
            }
          }
          createTrackedObjects(e) {
            for (; e.length > 0; ) {
              const t = e.shift();
              this.isAlreadyTrackedForThisTag(t) ||
                this.addTrackedObjectAndInitialize(
                  this.createTrackedObject(),
                  t
                );
            }
          }
          createTrackedObject() {
            return new ze(this);
          }
          createIABTrigger() {
            return new st();
          }
          commitDuration(e) {
            super.commitDuration(e),
              this.tagMetricAgregator.calculateAdvertising(e);
          }
        }
        class tt extends ze {
          constructor(e) {
            super(e),
              (this.lastPlayDate = 0),
              (this.userActive = !0),
              (this.playing = !1),
              (this.durationPart = 0),
              (this.lastDurationAddedDate = 0),
              (this.oldVisibilityCalculator = null),
              (this.metricsAggregator = new Ge(this)),
              (this.firstShot = !0),
              tt.instreamAPITrackedObjectList.push(this),
              W.trackingLoader.refreshActivity();
          }
          onClipPlayEvent(e) {
            this.playing ||
              (this.tag.getTriggerManager().onPlay(),
              (this.playing = !0),
              (this.lastPlayDate = e),
              (this.userActive = W.isActive()),
              (this.lastDurationAddedDate = 0));
          }
          onClipResumeEvent(e) {
            this.playing ||
              ((this.playing = !0),
              (this.lastPlayDate = e),
              (this.userActive = W.isActive()),
              (this.lastDurationAddedDate = 0));
          }
          getVideoGroupMTrigger() {
            return this.tag.getTriggerManager().getVideoGroupMTrigger();
          }
          onClipPauseEvent(e) {
            this.playing && ((this.playing = !1), this.manageStopPlaying(e));
          }
          onClipStopEvent(e, t) {
            this.playing &&
              ((this.playing = !1),
              this.manageStopPlaying(e),
              this.deleteAfterFlush(),
              t || this.tag.shutdown(Qe.RR_CLIP_STOP));
          }
          onClipInterruptEvent(e, t) {
            this.playing &&
              ((this.playing = !1),
              this.manageStopPlaying(e),
              this.deleteAfterFlush(),
              t || this.tag.shutdown(Qe.RR_CLIP_INTERRUPT));
          }
          manageStopPlaying(e) {
            0 === this.lastDurationAddedDate
              ? this.lastPlayDate > 0 &&
                (this.durationPart += e - this.lastPlayDate)
              : (this.durationPart += e - this.lastDurationAddedDate);
          }
          calculateAdvertising(e) {
            let t = e;
            this.playing
              ? (this.lastPlayDate > 0 &&
                  ((t =
                    this.durationPart + g.getCurrentTime() - this.lastPlayDate),
                  (this.lastPlayDate = 0),
                  (this.durationPart = 0)),
                this.firstShot && !this.userActive && (t = 0))
              : this.durationPart > 0
              ? ((t = this.durationPart), (this.durationPart = 0))
              : (t = 0),
              this.getTag().getTagMetricsAggregator().calculateAdvertising(t),
              super.calculateAdvertising(t),
              t > 0 &&
                ((this.firstShot = !1),
                (this.lastDurationAddedDate =
                  W.trackingLoader.getLastShotTime()));
          }
          onFullscreenOn() {
            (this.oldVisibilityCalculator = this.getVisibilityCalculator()),
              this.setVisibilityCalculator(new ye()),
              (this.userActive = !0),
              A.onActiveEvent();
          }
          onFullscreenOff() {
            this.oldVisibilityCalculator &&
              (this.setVisibilityCalculator(this.oldVisibilityCalculator),
              (this.userActive = W.isActive()));
          }
          getTag() {
            return this.tag;
          }
          static getInstreamAPITrackedObjectList() {
            return tt.instreamAPITrackedObjectList;
          }
          deleteAfterFlush() {
            super.deleteAfterFlush();
            const e = tt.instreamAPITrackedObjectList.indexOf(this);
            e > -1 && tt.instreamAPITrackedObjectList.splice(e, 1);
          }
          getIABDurationThreshold() {
            return 2e3;
          }
          getMetricsAggregator() {
            return this.metricsAggregator;
          }
        }
        tt.instreamAPITrackedObjectList = [];
        class it {
          constructor(e) {
            this.id = e;
          }
          getTrackedObjectDuration(e) {
            throw new Error("Method not implemented.");
          }
          getDurationThreshold(e) {
            throw new Error("Method not implemented.");
          }
          getId() {
            return this.id;
          }
          isMeasurable(e) {
            return !0;
          }
        }
        class st {
          getDurationThreshold(e) {
            return st.DURATION_THRESHOLD;
          }
          getTrackedObjectDuration(e) {
            return e.getMetricsAggregator().getIABDuration();
          }
        }
        st.DURATION_THRESHOLD = 1e3;
        class nt extends st {
          getDurationThreshold(e) {
            return nt.DURATION_THRESHOLD_VIDEO;
          }
        }
        nt.DURATION_THRESHOLD_VIDEO = 2e3;
        class rt extends it {
          constructor(e) {
            super(e);
          }
          getDurationThreshold(e) {
            const t = e;
            if (t.getTag().hasCreativeDuration()) {
              const e =
                rt.SPOT_DURATION_FRACTION_REQUIRED *
                t.getTag().getCreativeDurationMilliseconds();
              return e > rt.FIFTEEN_SECONDS_IN_MILLI
                ? rt.FIFTEEN_SECONDS_IN_MILLI
                : e;
            }
            return 0;
          }
          getTrackedObjectDuration(e) {
            return e.getMetricsAggregator().getVideoGroupMVisibleDuration();
          }
          isMeasurable(e) {
            const t = e;
            return (
              !rt.isInstreamOrUnknownContext(t) || t.hasReceivedSoundState()
            );
          }
          static isGroupMVisible(e) {
            const t = e.getTag().hasCreativeDuration(),
              i = e.getPercentVisible(),
              s = e.getTag();
            let n = rt.SURFACE_FRACTION_REQUIRED;
            if (
              (e.getVisibilityCalculator().getBannerSize().surface() >=
                rt.GROUPM_LARGE_FORMAT_SURFACE &&
                !d.isMobile() &&
                (n = rt.SURFACE_FRACTION_REQUIRED_LARGE_FORMAT),
              rt.isInstreamOrUnknownContext(s))
            ) {
              const s = 1 === e.getTag().getSoundState();
              return i >= n && t && s;
            }
            return i >= n && t;
          }
          static isInstreamOrUnknownContext(e) {
            if (e.getTagURL().hasParameter("vctx")) {
              const t = e.getTagURL().getParameterInt("vctx");
              return (
                -1 !==
                [
                  rt.PREROLL_METHOD_ID_VIDEO_CONTEXT,
                  rt.MIDROLL_METHOD_ID_VIDEO_CONTEXT,
                  rt.POSTROLL_METHOD_ID_VIDEO_CONTEXT,
                  rt.UNKNOWN_METHOD_ID_VIDEO_CONTEXT,
                ].indexOf(t)
              );
            }
            return !1;
          }
          isPreRollContext(e) {
            return (
              e.getTagURL().hasParameter("vctx") &&
              e.getTagURL().getParameterInt("vctx") ===
                rt.PREROLL_METHOD_ID_VIDEO_CONTEXT
            );
          }
        }
        (rt.SPOT_DURATION_FRACTION_REQUIRED = 0.5),
          (rt.FIFTEEN_SECONDS_IN_MILLI = 15e3),
          (rt.GROUPM_LARGE_FORMAT_SURFACE = 3e5),
          (rt.SURFACE_FRACTION_REQUIRED = 1),
          (rt.SURFACE_FRACTION_REQUIRED_LARGE_FORMAT = 0.8),
          (rt.UNKNOWN_METHOD_ID_VIDEO_CONTEXT = 0),
          (rt.PREROLL_METHOD_ID_VIDEO_CONTEXT = 1),
          (rt.MIDROLL_METHOD_ID_VIDEO_CONTEXT = 2),
          (rt.POSTROLL_METHOD_ID_VIDEO_CONTEXT = 3);
        class at {
          constructor() {
            (this.iabTrigger = null),
              (this.iabState = new dt(this)),
              (this.customTrigger = null),
              (this.customViewResult = new ut(this)),
              (this.clearingEventsManager = null),
              (this.nativeEventsManager = null);
          }
          init(e, t) {
            (this.tag = e),
              (this.requestFormatter = this.tag.getRequestFormatter()),
              (this.iabTrigger = t),
              this.createCustomTrigger(e),
              this.initClearingEventManager(),
              (this.nativeEventsManager = new lt(this));
          }
          start() {
            this.updateIABViewResult(),
              this.updateCustomViewResult(),
              this.requestFormatter.requestFlush(Qe.RR_FIRST_REQUEST);
          }
          initClearingEventManager() {
            gt.hasClearingEvent(this) &&
              (this.clearingEventsManager = new gt(this));
          }
          createCustomTrigger(e) {
            const t = e.getTagURL().getParameter("cid");
            t && "3" === t && this.setCustomTrigger(new ot(t));
          }
          postShot() {
            this.clearingEventsManager && this.clearingEventsManager.postShot(),
              this.nativeEventsManager?.postShot(this),
              this.updateIABViewResult(),
              this.updateCustomViewResult(),
              at.postShotCheckJsSignals();
          }
          isMeasurementInitialized() {
            const e = this.tag.getSearchStrategy().isWorking(),
              t = W.trackingLoader.isTrackingSupported(),
              i = W.trackingLoader.trackDisplay.isTrackingInitialized(),
              s =
                this.tag.getTimeFromCreation() <=
                at.MIN_ACCEPTABLE_TIME_FOR_ADS_TO_LOAD;
            return (
              !!(e && t && i) &&
              (this.tag.hasAtLeastOneObjectInitialized() ||
                s ||
                !!this.tag
                  .getTagMetricsAggregator()
                  .getLastDeletedTrackedObjectData())
            );
          }
          setCustomTrigger(e) {
            this.customTrigger = e;
          }
          updateIABViewResult() {
            const e =
              this.iabState.updateIABViewResultAndReturnTrackedObjectWhenItBecomesVisible();
            e &&
              (this.requestFormatter.setTrackedObject(e),
              this.requestFormatter.requestFlush(Qe.RR_PV_REQUEST));
          }
          updateCustomViewResult() {
            this.customTrigger &&
              this.customViewResult.updateCustomViewResultAndReturnTrackedObjectWhenItBecomesVisible() &&
              this.requestFormatter.requestFlush(Qe.RR_CUSTOM_PV_REQUEST);
          }
          shutDown() {}
          isFirstRequest() {
            return this.requestFormatter.isFirstRequest();
          }
          getCustomViewResult() {
            return this.customTrigger
              ? this.customViewResult.getViewResult()
              : null;
          }
          getViewResult() {
            return this.iabState.getViewResult();
          }
          getCustomTrigger() {
            return this.customTrigger;
          }
          static postShotCheckJsSignals() {
            const e = c.getTopAccessibleWindow();
            ae.hasMraidNamespace(e) && C.notify(C.EXCEPTION_1005),
              _e.isInAppSupplyType() && Oe.checkOuterMetrics(),
              d.elementHasDefined(e, "omid") && C.notify(C.EXCEPTION_1300),
              Ce.useOmidToSendRequest() && C.notify(C.EXCEPTION_1340);
          }
          getTag() {
            return this.tag;
          }
          getIabTrigger() {
            return this.iabTrigger;
          }
        }
        at.MIN_ACCEPTABLE_TIME_FOR_ADS_TO_LOAD = 5e3;
        class ot extends it {
          constructor(e) {
            super(e);
          }
          getDurationThreshold(e) {
            return ot.DURATION_THRESHOLD;
          }
          getTrackedObjectDuration(e) {
            return e.getMetricsAggregator().getTime100PercentVisible();
          }
        }
        ot.DURATION_THRESHOLD = 1e3;
        class ct extends at {
          constructor() {
            super(...arguments),
              (this.videoGroupMTrigger = null),
              (this.hasPlayedAtLeastOnce = !1);
          }
          initClearingEventManager() {
            Et.hasClearingEvent(this) &&
              (this.clearingEventsManager = new Et(this));
          }
          createCustomTrigger(e) {
            const t = e.getTagURL().getParameter("cid");
            t &&
              (("1" !== t && "2" !== t && "3" !== t) ||
                this.setCustomTrigger(new rt(t)));
          }
          isMeasurementInitialized() {
            return (
              W.trackingLoader.trackDisplay.isTrackingInitialized() &&
              this.tag.hasAtLeastOneObjectInitialized()
            );
          }
          setCustomTrigger(e) {
            super.setCustomTrigger(e), (this.videoGroupMTrigger = e);
          }
          getVideoGroupMTrigger() {
            return this.videoGroupMTrigger;
          }
          getTag() {
            return this.tag;
          }
          onPlay() {
            this.videoGroupMTrigger &&
              (this.customViewResult.isFinalState() ||
                this.getTag().hasCreativeDuration() ||
                (C.notify(C.EXCEPTION_1135),
                this.customViewResult.setNonMeasurableFinal(),
                this.requestFormatter.requestFlush(Qe.RR_CUSTOM_NM_REQUEST))),
              (this.hasPlayedAtLeastOnce = !0);
          }
          shutDown() {
            this.videoGroupMTrigger &&
              rt.isInstreamOrUnknownContext(this.getTag()) &&
              this.hasPlayedAtLeastOnce &&
              !this.getTag().hasReceivedSoundState() &&
              C.notify(C.EXCEPTION_1134);
          }
        }
        class lt {
          constructor(e) {
            (this.triggerManager = null),
              (this.triggerManager = e),
              (this.nativeEventList = this.triggerManager
                .getTag()
                .getTagURL()
                .getViewNativeEvents()),
              this.hasNativeEvent() && this.nativeEventList.postShot(e);
          }
          hasNativeEvent() {
            return (
              this.nativeEventList && this.nativeEventList.getNbEvents() > 0
            );
          }
          postShot(e) {
            this.hasNativeEvent() && this.nativeEventList.postShot(e);
          }
        }
        class ht {}
        (ht.NOT_VISIBLE = "nv"),
          (ht.VISIBLE = "pv"),
          (ht.NOT_MEASURABLE = "nm");
        class dt {
          constructor(e) {
            (this._isFinalState = !1),
              (this.currentState = ht.NOT_VISIBLE),
              (this.nonViewableType = dt.NOT_VIEWABLE_REASON_TRACKING_ON),
              (this.nonMeasurableType = -1),
              (this.triggerManager = e);
          }
          setNonVisible() {
            this._isFinalState ||
              ((this.currentState = ht.NOT_VISIBLE),
              this.updateIABNonViewableType());
          }
          setViewable() {
            this._isFinalState ||
              ((this.currentState = ht.VISIBLE), (this._isFinalState = !0));
          }
          setNonMeasurableTemporary(e) {
            this._isFinalState ||
              ((this.currentState = ht.NOT_MEASURABLE),
              (this.nonMeasurableType = e));
          }
          setNonMeasurableFinal(e) {
            this._isFinalState ||
              ((this.currentState = ht.NOT_MEASURABLE),
              (this.nonMeasurableType = e),
              (this._isFinalState = !0));
          }
          isFinalState() {
            return this._isFinalState;
          }
          isViewable() {
            return this.currentState === ht.VISIBLE;
          }
          isNonMeasurable() {
            return this.currentState === ht.NOT_MEASURABLE;
          }
          getViewResult() {
            return this.isViewable()
              ? ht.VISIBLE
              : this.isNonMeasurable()
              ? `${ht.NOT_MEASURABLE}&nmt=${this.nonMeasurableType}`
              : `${this.currentState}&nvt=${this.nonViewableType}`;
          }
          hasChangedStateToVisible() {
            if (this._isFinalState) return null;
            let e = null,
              t = -1;
            const i = this.triggerManager.getTag();
            for (let s = 0; s < i.getTrackedObjectCount(); s++) {
              const n = i.getTrackedObject(s),
                r = this.triggerManager.getIabTrigger().getDurationThreshold(n),
                a = this.triggerManager
                  .getIabTrigger()
                  .getTrackedObjectDuration(n);
              a >= t && a >= r && ((t = a), (e = n));
            }
            return e ? (this.setViewable(), e) : null;
          }
          updateIABViewResultAndReturnTrackedObjectWhenItBecomesVisible() {
            if (this._isFinalState) return null;
            return (
              this.hasChangedStateToVisible() ||
              (W.getContainer() && !W.getContainer().isAppSupported()
                ? this.setNonMeasurableFinal(dt.NOT_MEASURABLE_WEBVIEW)
                : this.triggerManager.getTag().getSearchStrategy().isWorking()
                ? this.triggerManager.isFirstRequest()
                  ? W.trackingLoader.isTrackingSupported() ||
                    this.setNonMeasurableFinal(dt.NOT_MEASURABLE_XD)
                  : W.trackingLoader.isTrackingSupported()
                  ? this.triggerManager.isMeasurementInitialized()
                    ? this.setNonVisible()
                    : W.trackingLoader.trackDisplay.isTrackingInitialized() &&
                      !this.triggerManager
                        .getTag()
                        .hasAtLeastOneObjectInitialized()
                    ? this.setNonMeasurableTemporary(
                        dt.NOT_MEASURABLE_NO_OBJECT
                      )
                    : this.setNonMeasurableTemporary(
                        dt.NOT_MEASURABLE_NOT_INITIALIZED
                      )
                  : this.setNonMeasurableTemporary(dt.NOT_MEASURABLE_XD)
                : this.setNonMeasurableTemporary(
                    dt.NOT_MEASURABLE_NATIVE_MACRO_NOT_REPLACED
                  ),
              null)
            );
          }
          isIABVisibleWithoutDurationThreshold() {
            const e = this.triggerManager.getTag(),
              t = e.getTagMetricsAggregator().getLastDeletedTrackedObjectData();
            if (0 === e.getTrackedObjectCount() && t)
              return t.isIABVisibleWithoutDurationThreshold();
            for (let t = 0; t < e.getTrackedObjectCount(); t++) {
              const e = this.triggerManager.getTag().getTrackedObject(t),
                i = this.triggerManager.getIabTrigger(),
                s = i.getDurationThreshold(e),
                n = i.getTrackedObjectDuration(e);
              if (
                n >= 0 &&
                n < s &&
                e.getVisibilityCalculator().getPercentVisible() > 0
              )
                return !0;
            }
            return !1;
          }
          isVisibleWithoutIABSurfaceThreshold() {
            const e = this.triggerManager.getTag(),
              t = e.getTagMetricsAggregator().getLastDeletedTrackedObjectData();
            if (t) return t.isVisibleWithoutIABSurfaceThreshold();
            for (let t = 0; t < e.getTrackedObjectCount(); t++) {
              const i = e.getTrackedObject(t),
                s = i.getMetricsAggregator().getTime000PercentVisible(),
                n = i.getVisibilityCalculator().getPercentVisible();
              if (
                0 ===
                  this.triggerManager
                    .getIabTrigger()
                    .getTrackedObjectDuration(i) &&
                s > 0 &&
                n > 0 &&
                n < i.getVisibilityCalculator().getIABThreshold()
              )
                return !0;
            }
            return !1;
          }
          updateIABNonViewableType() {
            const e = this.triggerManager.getTag(),
              t = e.getTagMetricsAggregator(),
              i =
                e.getTrackedObjectCount() > 0
                  ? e.getFirstObject().getVisibilityCalculator()
                  : null,
              s = t.getLastDeletedTrackedObjectData();
            this.triggerManager.isFirstRequest()
              ? (this.nonViewableType = dt.NOT_VIEWABLE_REASON_TRACKING_ON)
              : e.getTimeFromCreation() <=
                  at.MIN_ACCEPTABLE_TIME_FOR_ADS_TO_LOAD &&
                !e.hasAtLeastOneObjectInitialized()
              ? (this.nonViewableType =
                  dt.NOT_VIEWABLE_REASON_SHORT_SESSION_NO_CREATIVE_FOUND)
              : W.getContainer() &&
                i &&
                W.getContainer().getVisibleRatio() <= i.getIABThreshold()
              ? (this.nonViewableType =
                  dt.NOT_VIEWABLE_REASON_SDK_SAY_NOT_VISIBLE)
              : W.isActive()
              ? (i && i.isHiddenCreative()) || (s && s.isHiddenCreative())
                ? (this.nonViewableType =
                    dt.NOT_VIEWABLE_REASON_HIDDEN_CREATIVE)
                : (i && i.isOutOfViewport()) || (s && s.isOutOfViewport())
                ? (this.nonViewableType =
                    dt.NOT_VIEWABLE_REASON_OUT_OF_VIEWPORT)
                : this.isVisibleWithoutIABSurfaceThreshold()
                ? (this.nonViewableType =
                    dt.NOT_VIEWABLE_REASON_SMALL_SURFACE_EXPOSITION)
                : ((this.nonViewableType =
                    dt.NOT_VIEWABLE_REASON_SHORT_DURATION_EXPOSTION),
                  this.isIABVisibleWithoutDurationThreshold() ||
                    C.notify(C.EXCEPTION_187))
              : c.isHidden()
              ? (this.nonViewableType = dt.NOT_VIEWABLE_REASON_PAGE_HIDDEN)
              : w.hasFocus()
              ? (C.notify(C.EXCEPTION_90),
                (this.nonViewableType = dt.NOT_VIEWABLE_REASON_INACTIVE_60S))
              : (this.nonViewableType = dt.NOT_VIEWABLE_REASON_NO_FOCUS);
          }
        }
        (dt.NOT_VIEWABLE_REASON_TRACKING_ON = 5),
          (dt.NOT_VIEWABLE_REASON_SHORT_SESSION_NO_CREATIVE_FOUND = 7),
          (dt.NOT_VIEWABLE_REASON_SDK_SAY_NOT_VISIBLE = 8),
          (dt.NOT_VIEWABLE_REASON_PAGE_HIDDEN = 9),
          (dt.NOT_VIEWABLE_REASON_NO_FOCUS = 10),
          (dt.NOT_VIEWABLE_REASON_INACTIVE_60S = 11),
          (dt.NOT_VIEWABLE_REASON_HIDDEN_CREATIVE = 12),
          (dt.NOT_VIEWABLE_REASON_OUT_OF_VIEWPORT = 13),
          (dt.NOT_VIEWABLE_REASON_SMALL_SURFACE_EXPOSITION = 14),
          (dt.NOT_VIEWABLE_REASON_SHORT_DURATION_EXPOSTION = 15),
          (dt.NOT_MEASURABLE_XD = 2),
          (dt.NOT_MEASURABLE_NO_OBJECT = 3),
          (dt.NOT_MEASURABLE_NOT_INITIALIZED = 4),
          (dt.NOT_MEASURABLE_WEBVIEW = 5),
          (dt.NOT_MEASURABLE_NATIVE_MACRO_NOT_REPLACED = 6);
        class ut {
          constructor(e) {
            (this._isFinalState = !1),
              (this.currentState = ht.NOT_VISIBLE),
              (this.triggerManager = e);
          }
          setNonVisible() {
            this._isFinalState || (this.currentState = ht.NOT_VISIBLE);
          }
          setViewable() {
            this._isFinalState ||
              ((this.currentState = ht.VISIBLE), (this._isFinalState = !0));
          }
          setNonMeasurableTemporary() {
            this._isFinalState || (this.currentState = ht.NOT_MEASURABLE);
          }
          setNonMeasurableFinal() {
            this._isFinalState ||
              ((this.currentState = ht.NOT_MEASURABLE),
              (this._isFinalState = !0));
          }
          isFinalState() {
            return this._isFinalState;
          }
          getViewResult() {
            return this.currentState;
          }
          updateCustomViewResultAndReturnTrackedObjectWhenItBecomesVisible() {
            if (this._isFinalState) return null;
            if (this.triggerManager.isFirstRequest())
              (this.triggerManager.getTag().getSearchStrategy().isWorking() &&
                W.trackingLoader.isTrackingSupported()) ||
                this.setNonMeasurableFinal();
            else if (this.triggerManager.isMeasurementInitialized()) {
              this.setNonVisible();
              const e = this.triggerManager.getTag(),
                t = this.triggerManager.getCustomTrigger();
              let i = null,
                s = -1;
              for (let n = 0; n < e.getTrackedObjectCount(); n++) {
                const r = e.getTrackedObject(n),
                  a = t.getDurationThreshold(r),
                  o = t.getTrackedObjectDuration(r);
                r.isFirstInitializedFlushDone() &&
                  !t.isMeasurable(e) &&
                  this.setNonMeasurableTemporary(),
                  o >= s && o >= a && a > 0 && ((s = o), (i = r));
              }
              if (i) return this.setViewable(), i;
            } else this.setNonMeasurableTemporary();
            return null;
          }
        }
        class gt {
          constructor(e) {
            (this.triggerManager = null),
              (this.clearingTrigger = null),
              (this.clearingEventSent = !1),
              (this.triggerManager = e),
              (this.clearingTrigger = this.getTriggerFromClearingEventType()),
              this.clearingTrigger
                ? C.notify(C.EXCEPTION_1180)
                : C.notify(C.EXCEPTION_183);
          }
          getTriggerFromClearingEventType() {
            const e = this.triggerManager
              ?.getTag()
              .getTagURL()
              .getParameter("cet");
            return gt.CLEARING_EVENT_TYPE_50PV1S === e
              ? new st()
              : gt.CLEARING_EVENT_TYPE_100PV1S === e
              ? new mt(e)
              : null;
          }
          static isValidClearingEventCallback(e) {
            const t = e.getTag().getTagURL().getParameter("cecb");
            return !(!t || -1 !== t.indexOf("AUCTION_EVENT_TYPE_CB"));
          }
          static hasClearingEvent(e) {
            const t = e.getTag().getTagURL();
            return (
              t.hasParameter("cet") &&
              "0" !== t.getParameter("cet") &&
              gt.isValidClearingEventCallback(e)
            );
          }
          postShot() {
            if (
              this.clearingTrigger &&
              !this.clearingEventSent &&
              this.triggerManager?.isMeasurementInitialized()
            ) {
              let e = null,
                t = -1;
              const i = this.triggerManager.getTag();
              for (let s = 0; s < i.getTrackedObjectCount(); s++) {
                const n = i.getTrackedObject(s),
                  r = this.clearingTrigger.getDurationThreshold(n),
                  a = this.clearingTrigger.getTrackedObjectDuration(n);
                n.isInitialized() &&
                  a >= t &&
                  a >= r &&
                  r > 0 &&
                  ((t = a), (e = n));
              }
              e && (this.sendClearingEvent(), (this.clearingEventSent = !0));
            }
          }
          sendClearingEvent() {
            try {
              const e =
                this.triggerManager?.getTag().getTagURL().getParameter("cecb") +
                "";
              Ce.sendRequestWithoutCookieAndReplaceSessionId(e, !1),
                C.notify(C.EXCEPTION_1179);
            } catch (e) {
              C.notify(C.EXCEPTION_182);
            }
          }
        }
        (gt.CLEARING_EVENT_TYPE_50PV1S = "2"),
          (gt.CLEARING_EVENT_TYPE_100PV1S = "6");
        class Et extends gt {
          constructor(e) {
            super(e);
          }
          getTriggerFromClearingEventType() {
            let e = super.getTriggerFromClearingEventType();
            if (!e) {
              const t = this.triggerManager
                .getTag()
                .getTagURL()
                .getParameter("cet");
              Et.CLEARING_EVENT_TYPE_50PV2S === t
                ? (e = new Tt())
                : Et.CLEARING_EVENT_TYPE_100PV50PD === t && (e = new rt(t));
            }
            return e;
          }
          postShot() {
            if (
              this.clearingTrigger &&
              !this.clearingEventSent &&
              this.triggerManager.isMeasurementInitialized()
            ) {
              let e = null,
                t = -1;
              const i = this.triggerManager.getTag();
              for (let s = 0; s < i.getTrackedObjectCount(); s++) {
                const n = i.getTrackedObject(s),
                  r = this.clearingTrigger.getDurationThreshold(n),
                  a = this.clearingTrigger.getTrackedObjectDuration(n);
                n.isInitialized() &&
                  a >= t &&
                  a >= r &&
                  r > 0 &&
                  ((t = a), (e = n));
              }
              e && (this.sendClearingEvent(), (this.clearingEventSent = !0));
            }
          }
        }
        (Et.CLEARING_EVENT_TYPE_50PV2S = "8"),
          (Et.CLEARING_EVENT_TYPE_100PV50PD = "9");
        class Tt {
          getDurationThreshold(e) {
            return Tt.DURATION_THRESHOLD;
          }
          getTrackedObjectDuration(e) {
            return e.getMetricsAggregator().getIABDuration();
          }
        }
        Tt.DURATION_THRESHOLD = 2e3;
        class mt extends it {
          constructor(e) {
            super(e);
          }
          getDurationThreshold(e) {
            return mt.DURATION_THRESHOLD;
          }
          getTrackedObjectDuration(e) {
            return e.getMetricsAggregator().getTime100PercentVisible();
          }
        }
        mt.DURATION_THRESHOLD = 1e3;
        class pt {
          refreshContent() {
            this.readTags(), this.processTags();
          }
          getScriptListLength() {
            return c.getNamespace().scs.length;
          }
          getAndRemoveFirstScript() {
            return c.getNamespace().scs.shift() || null;
          }
          loadIframe(e) {}
          handleNewTagURL(e, t) {}
          isOmidByDefault() {
            return !1;
          }
          canHandleOmsdk() {
            return !0;
          }
          initXDRDisplayApi() {}
        }
        class Ot {
          init() {
            Ot.initializeApiNative(c.getWindow()), Ot.readInits();
          }
          readTags() {
            Ot.synchronous || (Ot.readInits(), (Ot.synchronous = !0));
          }
          static initializeApiNative(e) {
            let t = e.xdrViewDisplay;
            t || ((t = { inits: [] }), (e.xdrViewDisplay = t)),
              (Ot.inits = t.inits),
              (t.inits.push = function (e) {
                Array.prototype.push.call(this, e), Ot.readInits();
              });
          }
          static readInits() {
            let e;
            for (; (e = Ot.inits.shift()); ) {
              C.notify(C.EXCEPTION_1316);
              const t = e.p;
              St.handleNewTagURL(null, t);
            }
          }
        }
        (Ot.inits = []), (Ot.synchronous = !1);
        class It {
          init() {
            (It.isXdrViewApiCreatedBefore = It.hasXdrViewApi()),
              It.initializeApiNative(c.getWindow()),
              It.readInits();
          }
          processTags() {
            It.synchronous ||
              (It.processNewVideoTagUrls(),
              It.readEvents(),
              (It.synchronous = !0));
          }
          static hasXdrViewApi() {
            let e = !1,
              t = c.getWindow();
            for (; !e && t; )
              (e = It.hasXdrViewApiNative(t)),
                (t = R.getAccessibleParentWindow(t));
            return e;
          }
          static hasXdrViewApiNative(e) {
            return void 0 !== e.xdrViewApi;
          }
          static initializeApiNative(e) {
            let t = e.xdrViewApi;
            t || (t = { inits: [], events: [] }),
              (It.inits = t.inits),
              (It.events = t.events),
              (t.inits.push = function (e) {
                Array.prototype.push.call(this, e),
                  It.readInits(),
                  It.processNewVideoTagUrls();
              }),
              (t.events.push = function (e) {
                Array.prototype.push.call(this, e), It.readEvents();
              });
          }
          static onClipEvent(e, t, i, s) {
            t === It.START
              ? (e.onClipPlayEvent(i),
                e.getTag().getTagURL().isFullscreen() && e.onFullscreenOn())
              : t === It.RESUME
              ? e.onClipResumeEvent(i)
              : t === It.PAUSE
              ? e.onClipPauseEvent(i)
              : t === It.COMPLETE
              ? e.onClipStopEvent(i, s)
              : t === It.SKIP
              ? e.onClipInterruptEvent(i, s)
              : t === It.FULLSCREEN_ON
              ? e.onFullscreenOn()
              : t === It.FULLSCREEN_OFF
              ? e.onFullscreenOff()
              : t === It.SOUND_ON
              ? e.getTag().onSoundOnEvent()
              : t === It.SOUND_OFF && e.getTag().onSoundOffEvent();
          }
          static readEvents() {
            let e;
            for (; (e = It.events.shift()); ) {
              It.synchronous && W.checkDurationStatic();
              const t = tt.getInstreamAPITrackedObjectList();
              for (let i = t.length - 1; i >= 0; i--) {
                const s = t[i];
                s.getTag().getAdUID() === e.a &&
                  It.onClipEvent(s, e.c, e.d, !It.synchronous);
              }
            }
          }
          static readInits() {
            let e;
            for (; (e = It.inits.shift()); )
              It.videoTagUrlCache.push(new fe("", e));
          }
          static processNewTagVideoUrl(e) {
            let t;
            (It._hasProcessedOneTagAtLeast = !0),
              C.notify(C.EXCEPTION_1330),
              (t = e.getAdNode()
                ? new We(e.getAdNode())
                : new Ve(e.getDomID())),
              Pe.addTag(new Ye(e, t));
          }
          static processNewVideoTagUrls() {
            let e = It.videoTagUrlCache.shift();
            for (; e; )
              It.processNewTagVideoUrl(e), (e = It.videoTagUrlCache.shift());
          }
          static hasProcessedOneTagAtLeast() {
            return It._hasProcessedOneTagAtLeast;
          }
          static isXdrViewApiHasBeenUsedAlready() {
            return (
              It.hasProcessedOneTagAtLeast() || It.isXdrViewApiCreatedBefore
            );
          }
        }
        (It.START = "start"),
          (It.PAUSE = "pause"),
          (It.RESUME = "resume"),
          (It.COMPLETE = "complete"),
          (It.SKIP = "skip"),
          (It.SOUND_ON = "sound_on"),
          (It.SOUND_OFF = "sound_off"),
          (It.FULLSCREEN_ON = "fullscreen_on"),
          (It.FULLSCREEN_OFF = "fullscreen_off"),
          (It.videoTagUrlCache = []),
          (It._hasProcessedOneTagAtLeast = !1),
          (It.isXdrViewApiCreatedBefore = !1),
          (It.synchronous = !1);
        class Ct {
          init() {
            Ct.readTagsNative(c.getWindow());
          }
          processTags() {
            Ct.processNewVideoTagUrls(), this.readCachedEvents(c.getWindow());
          }
          static readTagsNative(e) {
            e.anxVVAPI = {
              initializeFromParams: function (e, t, i, s, n, r, a, o, c) {
                Ct.readTagsFromParamsNative(e, t, i, s, n, r, a, o, c),
                  Ct.processNewVideoTagUrls();
              },
              notifyEvent: function (e, t) {
                const i = g.getCurrentTime();
                Ct.notifyEvent(e, t, i, !1);
              },
            };
            const t = e.anxVVAPICache;
            if (t) {
              const e = t.init;
              if (e) {
                let t;
                for (; (t = e.shift()); )
                  Ct.readTagsFromParamsNative(
                    t.params,
                    t.id,
                    t.a,
                    t.v,
                    t.dur,
                    t.w,
                    t.h,
                    t.x,
                    t.y
                  );
              }
            }
          }
          static onClipEvent(e, t, i, s) {
            t === Ct.START
              ? e.onClipPlayEvent(i)
              : t === Ct.RESUME
              ? e.onClipResumeEvent(i)
              : t === Ct.PAUSE
              ? e.onClipPauseEvent(i)
              : t === Ct.STOP
              ? e.onClipStopEvent(i, s)
              : t === Ct.INTERRUPT
              ? e.onClipInterruptEvent(i, s)
              : t === Ct.EXPAND
              ? e.onFullscreenOn()
              : t === Ct.SOUND_ON
              ? e.getTag().onSoundOnEvent()
              : t === Ct.SOUND_OFF
              ? e.getTag().onSoundOffEvent()
              : t === Ct.COLLAPSE && e.onFullscreenOff();
          }
          static readTagsFromParamsNative(e, t, i, s, n, r, a, o, c) {
            n || (n = 0),
              r || (r = -1),
              a || (a = -1),
              o || (o = 0),
              c || (c = 0),
              Ct.readTagsFromParams(e, t, i, s, n, r, a, o, c);
          }
          static readTagsFromParams(e, t, i, s, n, r, a, o, c) {
            Ct.tagsVideoUrlCache.push(new fe(e, t, i, s, n));
          }
          readCachedEvents(e) {
            const t = e.anxVVAPICache;
            if (t) {
              const e = t.events;
              if (e) {
                let t;
                for (; (t = e.shift()); ) Ct.notifyEvent(t.a, t.c, t.d, !0);
              }
            }
          }
          static processNewVideoTagUrls() {
            let e = Ct.tagsVideoUrlCache.shift();
            for (; e; )
              Ct.processNewTagVideoUrl(e), (e = Ct.tagsVideoUrlCache.shift());
          }
          static processNewTagVideoUrl(e) {
            const t = new Ve(e.getDomID());
            Pe.addTag(new Ye(e, t));
          }
          static notifyEvent(e, t, i, s) {
            s || W.checkDurationStatic();
            const n = tt.getInstreamAPITrackedObjectList();
            for (let r = n.length - 1; r >= 0; r--) {
              const a = n[r];
              a.getTag().getAdUID() === e && Ct.onClipEvent(a, t, i, s);
            }
          }
        }
        (Ct.START = "start"),
          (Ct.PAUSE = "pause"),
          (Ct.RESUME = "resume"),
          (Ct.STOP = "stop"),
          (Ct.CLICK = "click"),
          (Ct.INTERRUPT = "interrupt"),
          (Ct.SOUND_ON = "sound_on"),
          (Ct.SOUND_OFF = "sound_off"),
          (Ct.EXPAND = "expand"),
          (Ct.COLLAPSE = "collapse"),
          (Ct.tagsVideoUrlCache = []);
        class _t {
          constructor() {
            this.videoEventListener = new O(C.EXCEPTION_206, (e) => {
              const t = new me(e),
                i = I.isAsync(t.getTimestamp());
              i || W.checkDurationStatic();
              const s = tt.getInstreamAPITrackedObjectList();
              for (let e = s.length - 1; e >= 0; e--) {
                const n = s[e],
                  r = t.getTimestamp(),
                  a = t.getType();
                if (a === _t.START)
                  n.getTag().onDurationReceived(t.getDuration()),
                    n.onClipPlayEvent(r),
                    t.getVolume() > 0
                      ? n.getTag().onSoundOnEvent()
                      : n.getTag().onSoundOffEvent();
                else if (a === _t.RESUME) n.onClipResumeEvent(r);
                else if (a === _t.PAUSE) n.onClipPauseEvent(r);
                else if (a === _t.COMPLETE) n.onClipStopEvent(r, i);
                else if (a === _t.SKIPPED) n.onClipInterruptEvent(r, i);
                else if (a === _t.SOUND_CHANGE)
                  t.getVolume() > 0
                    ? n.getTag().onSoundOnEvent()
                    : n.getTag().onSoundOffEvent();
                else if (a === _t.PLAYER_STATE_CHANGE) {
                  const e = t.getPlayerStateChange();
                  e === _t.PLAYER_STATE_MINIMIZED ||
                  e === _t.PLAYER_STATE_COLLAPSED
                    ? n.onFullscreenOff()
                    : e === _t.PLAYER_STATE_EXPANDED ||
                      e === _t.PLAYER_STATE_FULLSCREEN
                    ? n.onFullscreenOn()
                    : n.onFullscreenOff();
                }
              }
            });
          }
          processTags() {
            let e = _t.tagsVideoUrlCache.shift();
            for (; e; )
              this.processNewTagUrl(e), (e = _t.tagsVideoUrlCache.shift());
          }
          handleNewTagURL(e, t) {
            const i = new fe(t, e);
            _t.tagsVideoUrlCache.push(i), W.setLastReferenceElement(e);
          }
          processNewTagUrl(e) {
            let t = null;
            (t = I.isOMIDContextWithoutCreativeAccess()
              ? new Ue()
              : e.getAdNode()
              ? new We(e.getAdNode())
              : new He()),
              Pe.addTag(new Ye(e, t)),
              W.getContainer().setVideoListener(this.videoEventListener);
          }
        }
        (_t.tagsVideoUrlCache = []),
          (_t.START = "start"),
          (_t.PAUSE = "pause"),
          (_t.RESUME = "resume"),
          (_t.COMPLETE = "complete"),
          (_t.SKIPPED = "skipped"),
          (_t.SOUND_CHANGE = "volumeChange"),
          (_t.PLAYER_STATE_CHANGE = "playerStateChange"),
          (_t.PLAYER_STATE_MINIMIZED = "minimized"),
          (_t.PLAYER_STATE_COLLAPSED = "collapsed"),
          (_t.PLAYER_STATE_EXPANDED = "expanded"),
          (_t.PLAYER_STATE_FULLSCREEN = "fullscreen");
        class ft extends pt {
          constructor() {
            super(...arguments),
              (this.scriptFound = !1),
              (this.xdrDisplayApi = new Ot());
          }
          initXDRDisplayApi() {
            this.xdrDisplayApi.init();
          }
          readTags() {
            const e = this.getScriptListLength();
            for (; !r() && 0 !== this.getScriptListLength(); ) {
              let e = !1;
              const t = this.getAndRemoveFirstScript();
              if (t) {
                const i = t.getAttribute("src") || "";
                if (-1 !== i.indexOf("#")) {
                  const s = i.substring(i.indexOf("#") + 1);
                  e = this.addScriptAddon(s, t);
                }
                if (!e) {
                  const i = n(t);
                  e = this.readParametersOnDivElement(i);
                }
              }
              e || (e = this.searchForDivTagInTheWholeWindow(c.getWindow()));
            }
            this.xdrDisplayApi.readTags(),
              e !== ft.tagsUrlCache.length &&
                (he.isOmidSupported() || C.notify(C.EXCEPTION_110));
          }
          readParametersOnDivElement(e) {
            const t = e.getAttribute(ft.TAG_ATTRIBUTE_NAME);
            if (t && t.startsWith(g.getScriptId())) {
              const i = t.replace(g.getScriptId(), "");
              return (
                e.setAttribute(ft.TAG_ATTRIBUTE_NAME, i),
                this.handleNewTagURL(e, i),
                !0
              );
            }
            return !1;
          }
          addScriptAddon(e, t) {
            if (!re.getElementProperty(t, ft.TAG_ATTRIBUTE_NAME)) {
              t.setAttribute(ft.TAG_ATTRIBUTE_NAME, "1");
              const i = e.replace(g.getScriptId(), "");
              return this.handleNewTagURL(t, i), !0;
            }
            return !1;
          }
          searchForDivTagInTheWholeWindow(e) {
            const t = se.getElementsByTagName(e, "div");
            for (let e = 0; e < t.length; e++) {
              const i = t[e];
              if (this.readParametersOnDivElement(i)) return !0;
            }
            return !1;
          }
          loadIframeNewlyFoundFrame(e) {
            this.processTags(),
              A.registerActivity(e),
              W.trackingLoader.searchElements(),
              W.checkDurationStatic();
          }
          handleNewTagURL(e, t) {
            const i = new _e(t, e);
            ft.tagsUrlCache.push(i), W.setLastReferenceElement(e);
          }
          processTags() {
            let e = ft.tagsUrlCache.pop();
            for (; e; ) this.processNewTagUrl(e), (e = ft.tagsUrlCache.pop());
          }
          processNewTagUrl(e) {
            let t = null;
            if (I.isOMIDContextWithoutCreativeAccess()) t = new Ue();
            else {
              const i = e.getParameter("dom_id");
              if (i) t = new Fe(i);
              else {
                const i = e.getParameter("dom_id_child");
                if (i) t = new ke(i);
                else {
                  const i = e.getParameter("css_selector");
                  if (i) t = new Be(i);
                  else {
                    const i = e.getParameter("dom_elt_var");
                    if (i) t = new xe(i);
                    else {
                      const i = e.getParameter("pbjs_adid") || "",
                        s = e.getParameter("pbjs_auc") || "";
                      (i || s) && (t = new Xe(i, s));
                    }
                  }
                }
              }
            }
            t || (t = new He()), Pe.addTag(new et(e, t));
          }
          isBannerOrNativeCreative() {
            return !0;
          }
          canHandleOmsdk() {
            return !1;
          }
        }
        (ft.tagsUrlCache = []), (ft.TAG_ATTRIBUTE_NAME = "lnttag");
        class St {
          static init() {
            St.impl || ((St.impl = new ft()), St.impl.initXDRDisplayApi());
          }
          static refreshContent() {
            St.init();
            try {
              St.impl.refreshContent();
            } catch (e) {
              C.notify(C.EXCEPTION_81);
            }
          }
          static processTags() {
            St.init();
            try {
              St.impl.processTags();
            } catch (e) {
              C.notify(C.EXCEPTION_33);
            }
          }
          static readTags() {
            St.init();
            try {
              St.impl.readTags();
            } catch (e) {
              C.notify(C.EXCEPTION_36);
            }
          }
          static handleNewTagURL(e, t) {
            St.init();
            try {
              St.impl.handleNewTagURL(e, t);
            } catch (e) {
              C.notify(C.EXCEPTION_38);
            }
          }
          static isBannerOrNativeCreative() {
            return St.init(), St.impl.isBannerOrNativeCreative();
          }
          static isOmidByDefault() {
            return St.init(), St.impl.isOmidByDefault();
          }
          static canHandleOmsdk() {
            return St.init(), St.impl.canHandleOmsdk();
          }
        }
        class Nt {
          constructor() {
            M.init(), C.init();
          }
          onModuleLoad() {
            c.getBodyElement(c.getWindow()) || r()
              ? this.initializeTracking()
              : this.delayedInitialization();
          }
          initializeTracking() {
            try {
              St.readTags();
              const e = p();
              let t, i;
              (t =
                "gecko40" === e
                  ? new B()
                  : "edge15" === e
                  ? new H()
                  : "ie11" === e
                  ? new x()
                  : new U()),
                je.checkSafeframeSignals(),
                (Nt.useIntersectionObserver = se.isFunctionNative(
                  Nt.getIntersectionObserverFunction()
                )),
                (i =
                  M.isCrossDomain() && !Nt.useIntersectionObserver
                    ? t.createTrackingLoaderXD()
                    : t.createTrackingLoader()),
                i.start();
            } catch (e) {
              C.notifyWithException(C.EXCEPTION_107, e);
            }
          }
          static getIntersectionObserverFunction() {
            return c.getWindow().IntersectionObserver;
          }
          delayedInitialization() {
            let e = 0;
            const t = new u(() => {
              if (!c.getBodyElement(c.getWindow())) {
                if (5 !== e) return void (e += 1);
                C.notify(C.EXCEPTION_1184);
              }
              t.cancel(), this.initializeTracking();
            }, C.EXCEPTION_85);
            t.scheduleRepeating(80);
          }
          static getUseIntersectionObserver() {
            return Nt.useIntersectionObserver;
          }
        }
        Nt.useIntersectionObserver = !1;
      },
      242: (e, t) => {},
    },
    t = {};
  function i(s) {
    var n = t[s];
    if (void 0 !== n) return n.exports;
    var r = (t[s] = { exports: {} });
    return e[s](r, r.exports, i), r.exports;
  }
  (i.d = (e, t) => {
    for (var s in t)
      i.o(t, s) &&
        !i.o(e, s) &&
        Object.defineProperty(e, s, { enumerable: !0, get: t[s] });
  }),
    (i.o = (e, t) => Object.prototype.hasOwnProperty.call(e, t));
  let s = {
    scriptHostBaseURI: "//adsdkdevstand.azureedge.net/viewability",
    scriptHostBaseURIConsentLess: "//adsdkdevstand.azureedge.net/viewability",
  };
  i(242),
    (function (e, t) {
      void 0 === globalThis[e] && (globalThis[e] = {});
      const i = globalThis[e],
        { scriptHostBaseURI: n, scriptHostBaseURIConsentLess: r } = s;
      i[t] = function () {
        const e = n,
          s = r;
        let a, o, c;
        const l =
          "undefined" != typeof window &&
          "undefined" != typeof document &&
          !!document.createElement;
        (i.isJsContext = !l),
          i.isJsContext
            ? ((o = {}),
              (a = {
                parent: null,
                body: {},
                document: o,
                setTimeout:
                  globalThis.omidNative && globalThis.omidNative.setTimeout,
                setInterval:
                  globalThis.omidNative && globalThis.omidNative.setInterval,
                clearTimeout:
                  globalThis.omidNative && globalThis.omidNative.clearTimeout,
                clearInterval:
                  globalThis.omidNative && globalThis.omidNative.clearInterval,
                location: { href: "" },
                navigator: { userAgent: "iPhone" },
                Error: {},
              }),
              (a.top = a),
              (a.parent = a))
            : ((a = window), (o = document)),
          (i.$wnd = a),
          (i.base = e),
          i.scs ||
            ((i.scs = []),
            (i.si = "v"),
            (i.it = new Date().getTime()),
            (i.rqs = []),
            (i.ts = {}),
            (i.myo = {}));
        let h = o.currentScript;
        if (!i.isJsContext && !h) {
          const t = document.getElementsByTagName("script");
          for (let i = t.length - 1; i >= 0; i--) {
            const n = t[i];
            if (
              !n.fnd &&
              n.src &&
              (-1 !== n.src.indexOf(e) || -1 !== n.src.indexOf(s))
            ) {
              (h = n), (n.fnd = !0);
              break;
            }
          }
        }
        h && (i.it = new Date().getTime()),
          i.scs.push(h),
          (i[t].onScriptLoad = function (e) {
            (i[t] = null),
              (c = e),
              c && (i.n ? i.n() : c(void 0, t, "", void 0));
          });
      };
      try {
        i[t]();
      } catch (e) {}
      return i[t].onScriptLoad;
    })(
      "_lntv",
      "s"
    )(() => {
      Promise.resolve()
        .then(i.bind(i, 946))
        .then(({ Tracking: e }) => {
          new e().onModuleLoad();
        })
        .catch((e) => {
          console.log("Error loading tracking module", e);
        });
    });
})();
