! function() {
    try {
        var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof globalThis ? globalThis : "undefined" != typeof self ? self : {},
            n = (new e.Error).stack;
        n && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[n] = "0354817d-b855-5c34-a8a0-fba3cd50e09e")
    } catch (e) {}
}();
(function() {
    try {
        var e = typeof window < `u` ? window : typeof global < `u` ? global : typeof globalThis < `u` ? globalThis : typeof self < `u` ? self : {};
        e._sentryModuleMetadata = e._sentryModuleMetadata || {}, e._sentryModuleMetadata[new e.Error().stack] = function(e) {
            for (var t = 1; t < arguments.length; t++) {
                var n = arguments[t];
                if (n != null)
                    for (var r in n) n.hasOwnProperty(r) && (e[r] = n[r])
            }
            return e
        }({}, e._sentryModuleMetadata[new e.Error().stack], {
            "_sentryBundlerPluginAppKey:crazygames-gameframe": !0
        });
        var t = new e.Error().stack;
        t && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[t] = `5ea52ba7-1096-444c-94c2-3875f86a339f`, e._sentryDebugIdIdentifier = `sentry-dbid-5ea52ba7-1096-444c-94c2-3875f86a339f`)
    } catch {}
})();
import {
    H as e,
    W as t,
    cn as n,
    gn as r,
    rt as i,
    yn as a
} from "../../bundle.js";
var o = n();
a();
var s = r(),
    c = n => {
        let r = (0, o.c)(7),
            {
                warning: a,
                close: c,
                showCrazyLogo: l
            } = n,
            u = l === void 0 ? !0 : l,
            d;
        r[0] === Symbol.for(`react.memo_cache_sentinel`) ? (d = t(), r[0] = d) : d = r[0];
        let f;
        r[1] !== c || r[2] !== a ? (f = (0, s.jsx)(e, {
            close: c,
            warning: a
        }), r[1] = c, r[2] = a, r[3] = f) : f = r[3];
        let p;
        return r[4] !== u || r[5] !== f ? (p = (0, s.jsx)(i, {
            showCrazyLogo: u,
            showGDPRNotice: d,
            children: f
        }), r[4] = u, r[5] = f, r[6] = p) : p = r[6], p
    };
export {
    c as t
};
//# debugId=0354817d-b855-5c34-a8a0-fba3cd50e09e