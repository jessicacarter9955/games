! function() {
    try {
        var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof globalThis ? globalThis : "undefined" != typeof self ? self : {},
            n = (new e.Error).stack;
        n && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[n] = "bc6568ce-a01f-53c8-84cc-0c0b0df700ac")
    } catch (e) {}
}();
(function() {
    try {
        var e = typeof window < `u` ? window : typeof global < `u` ? global : typeof globalThis < `u` ? globalThis : typeof self < `u` ? self : {};
        e._sentryModuleMetadata = e._sentryModuleMetadata || {}, e._sentryModuleMetadata[new e.Error().stack] = function(e) {
            for (var t = 1; t < arguments.length; t++) {
                var n = arguments[t];
                if (n != null)
                    for (var r in n) n.hasOwnProperty(r) && (e[r] = n[r])
            }
            return e
        }({}, e._sentryModuleMetadata[new e.Error().stack], {
            "_sentryBundlerPluginAppKey:crazygames-gameframe": !0
        });
        var t = new e.Error().stack;
        t && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[t] = `5d32055f-8c87-4bdf-9dff-dc02800f3145`, e._sentryDebugIdIdentifier = `sentry-dbid-5d32055f-8c87-4bdf-9dff-dc02800f3145`)
    } catch {}
})();
var e = {
    container: `_container_hyuno_7`,
    code: `_code_hyuno_28`,
    canvas: `_canvas_hyuno_38`,
    progress: `_progress_hyuno_42`,
    title: `_title_hyuno_46`,
    subtitle: `_subtitle_hyuno_55`,
    gameTitle: `_gameTitle_hyuno_62`
};
export {
    e as t
};
//# debugId=bc6568ce-a01f-53c8-84cc-0c0b0df700ac