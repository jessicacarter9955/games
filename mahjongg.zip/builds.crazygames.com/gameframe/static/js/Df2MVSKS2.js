! function() {
    try {
        var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof globalThis ? globalThis : "undefined" != typeof self ? self : {},
            n = (new e.Error).stack;
        n && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[n] = "9470a2d3-c270-5367-ab63-efc79abbe14b")
    } catch (e) {}
}();
(function() {
    try {
        var e = typeof window < `u` ? window : typeof global < `u` ? global : typeof globalThis < `u` ? globalThis : typeof self < `u` ? self : {};
        e._sentryModuleMetadata = e._sentryModuleMetadata || {}, e._sentryModuleMetadata[new e.Error().stack] = function(e) {
            for (var t = 1; t < arguments.length; t++) {
                var n = arguments[t];
                if (n != null)
                    for (var r in n) n.hasOwnProperty(r) && (e[r] = n[r])
            }
            return e
        }({}, e._sentryModuleMetadata[new e.Error().stack], {
            "_sentryBundlerPluginAppKey:crazygames-gameframe": !0
        });
        var t = new e.Error().stack;
        t && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[t] = `36f3b5c6-b383-4505-b5bb-cba7d288dbbb`, e._sentryDebugIdIdentifier = `sentry-dbid-36f3b5c6-b383-4505-b5bb-cba7d288dbbb`)
    } catch {}
})();
import {
    At as e,
    Ft as t,
    Jt as n,
    Kt as r,
    Lt as i,
    Sn as a,
    St as o,
    _ as s,
    _t as c,
    at as l,
    b as u,
    bt as d,
    c as f,
    cn as p,
    ct as m,
    ft as h,
    g,
    gn as _,
    gt as v,
    h as y,
    in as b,
    it as x,
    m as S,
    mt as C,
    nt as w,
    on as T,
    st as E,
    tn as D,
    vt as O,
    wt as k,
    xt as A,
    y as j,
    yn as M,
    yt as N
} from "../../bundle.js";
var P = a(M()),
    F = p(),
    I = {
        content: `_content_pctpg_7`,
        closeIcon: `_closeIcon_pctpg_13`,
        title: `_title_pctpg_17`,
        body: `_body_pctpg_27`,
        actions: `_actions_pctpg_34`,
        button: `_button_pctpg_40`
    },
    L = _(),
    R = e => {
        let t = (0, F.c)(19),
            {
                title: n,
                body: r,
                action: i
            } = e,
            a;
        t[0] === i ? a = t[1] : (a = () => i(!1), t[0] = i, t[1] = a);
        let o;
        t[2] === Symbol.for(`react.memo_cache_sentinel`) ? (o = (0, L.jsx)(h, {
            name: `close`,
            size: 20,
            className: I.closeIcon
        }), t[2] = o) : o = t[2];
        let s;
        t[3] === a ? s = t[4] : (s = (0, L.jsx)(E, {
            onClick: a,
            children: o
        }), t[3] = a, t[4] = s);
        let c;
        t[5] === n ? c = t[6] : (c = (0, L.jsx)(`h2`, {
            className: I.title,
            children: n
        }), t[5] = n, t[6] = c);
        let u;
        t[7] === r ? u = t[8] : (u = (0, L.jsx)(`p`, {
            className: I.body,
            children: r
        }), t[7] = r, t[8] = u);
        let d;
        t[9] === i ? d = t[10] : (d = () => i(!1), t[9] = i, t[10] = d);
        let f;
        t[11] === Symbol.for(`react.memo_cache_sentinel`) ? (f = (0, L.jsx)(x, {
            id: `aps.tooltip.button`
        }), t[11] = f) : f = t[11];
        let p;
        t[12] === d ? p = t[13] : (p = (0, L.jsx)(`div`, {
            className: I.actions,
            children: (0, L.jsx)(w, {
                variant: `contained`,
                color: `purple`,
                height: 40,
                className: I.button,
                onClick: d,
                children: f
            })
        }), t[12] = d, t[13] = p);
        let g;
        return t[14] !== s || t[15] !== c || t[16] !== u || t[17] !== p ? (g = (0, L.jsx)(l, {
            children: (0, L.jsxs)(m, {
                className: I.content,
                children: [s, c, u, p]
            })
        }), t[14] = s, t[15] = c, t[16] = u, t[17] = p, t[18] = g) : g = t[18], g
    },
    z = () => {
        let n = (0, F.c)(4),
            {
                accountId: r
            } = (0, P.useContext)(t),
            {
                gameLoadStatus: i
            } = (0, P.useContext)(e),
            [a, o] = P.useState(!1);
        if (!r || i !== `NOT_STARTED`) return null;
        if (a) {
            let e;
            return n[0] === Symbol.for(`react.memo_cache_sentinel`) ? (e = (0, L.jsx)(R, {
                title: (0, L.jsx)(x, {
                    id: `aps.tooltip.crazyAccount.title`
                }),
                body: (0, L.jsx)(x, {
                    id: `aps.tooltip.crazyAccount.body`
                }),
                action: o
            }), n[0] = e) : e = n[0], e
        }
        let c;
        n[1] === Symbol.for(`react.memo_cache_sentinel`) ? (c = C(s.info, s.infoSuccess), n[1] = c) : c = n[1];
        let l;
        n[2] === Symbol.for(`react.memo_cache_sentinel`) ? (l = (0, L.jsx)(`div`, {
            children: (0, L.jsx)(x, {
                id: `aps.info.base`,
                values: {
                    highlight: (0, L.jsx)(`span`, {
                        className: s.highlightSuccess,
                        children: (0, L.jsx)(x, {
                            id: `aps.info.base.enabled`
                        })
                    })
                }
            })
        }), n[2] = l) : l = n[2];
        let u;
        return n[3] === Symbol.for(`react.memo_cache_sentinel`) ? (u = (0, L.jsx)(`div`, {
            className: s.wrapper,
            children: (0, L.jsxs)(`div`, {
                className: c,
                children: [l, (0, L.jsx)(h, {
                    name: `question-bubble`,
                    size: 16,
                    className: s.questionBubble,
                    onClick: () => o(!0)
                })]
            })
        }), n[3] = u) : u = n[3], u
    },
    B = e => {
        let t = (0, F.c)(15),
            {
                onContinueAsGuest: n,
                onLogin: r
            } = e,
            i;
        t[0] === Symbol.for(`react.memo_cache_sentinel`) ? (i = T(), t[0] = i) : i = t[0];
        let {
            gameName: a
        } = i, o;
        t[1] === Symbol.for(`react.memo_cache_sentinel`) ? (o = (0, L.jsx)(`div`, {
            className: f.welcomeBackOverlay
        }), t[1] = o) : o = t[1];
        let s;
        t[2] === Symbol.for(`react.memo_cache_sentinel`) ? (s = (0, L.jsx)(`div`, {
            className: f.welcomeBackZiggy,
            children: (0, L.jsx)(`img`, {
                src: v(`gameframe/ziggy.svg`, {
                    width: 100
                }),
                alt: `ziggy`
            })
        }), t[2] = s) : s = t[2];
        let c;
        t[3] === Symbol.for(`react.memo_cache_sentinel`) ? (c = (0, L.jsx)(`div`, {
            className: f.welcomeBackTitle,
            children: (0, L.jsx)(x, {
                id: `aps.welcomeback.title`
            })
        }), t[3] = c) : c = t[3];
        let l;
        t[4] === Symbol.for(`react.memo_cache_sentinel`) ? (l = (0, L.jsxs)(`div`, {
            className: f.welcomeBackText,
            children: [c, (0, L.jsx)(`div`, {
                className: f.welcomeBackMessage,
                children: (0, L.jsx)(x, {
                    id: `aps.welcomeback.subtitle`,
                    values: {
                        game: (0, L.jsx)(`span`, {
                            className: f.welcomeBackGameName,
                            children: a
                        })
                    }
                })
            })]
        }), t[4] = l) : l = t[4];
        let u;
        t[5] === Symbol.for(`react.memo_cache_sentinel`) ? (u = C(f.welcomeBackButton, f.welcomeBackGuest), t[5] = u) : u = t[5];
        let d;
        t[6] === Symbol.for(`react.memo_cache_sentinel`) ? (d = (0, L.jsx)(x, {
            id: `aps.welcomeback.asguest`
        }), t[6] = d) : d = t[6];
        let p;
        t[7] === n ? p = t[8] : (p = (0, L.jsx)(w, {
            className: u,
            variant: `contained`,
            color: `grey`,
            height: 50,
            onClick: n,
            children: d
        }), t[7] = n, t[8] = p);
        let m;
        t[9] === Symbol.for(`react.memo_cache_sentinel`) ? (m = (0, L.jsx)(x, {
            id: `aps.welcomeback.login`
        }), t[9] = m) : m = t[9];
        let h;
        t[10] === r ? h = t[11] : (h = (0, L.jsx)(w, {
            className: f.welcomeBackButton,
            variant: `contained`,
            color: `purple`,
            height: 50,
            onClick: r,
            children: m
        }), t[10] = r, t[11] = h);
        let g;
        return t[12] !== h || t[13] !== p ? (g = (0, L.jsxs)(L.Fragment, {
            children: [o, (0, L.jsx)(`div`, {
                className: f.welcomeBackContainer,
                children: (0, L.jsxs)(`div`, {
                    className: f.welcomeBackShell,
                    children: [s, (0, L.jsxs)(`div`, {
                        className: f.welcomeBackPanel,
                        children: [l, (0, L.jsxs)(`div`, {
                            className: f.welcomeBackActions,
                            children: [p, h]
                        })]
                    })]
                })
            })]
        }), t[12] = h, t[13] = p, t[14] = g) : g = t[14], g
    },
    V = 2,
    H = 7,
    U = 1440 * 60 * 1e3,
    W = `apsnotice_hidden_day`;

function G(e) {
    n.getInstance().sendEvent({
        type: `notificationAction`,
        notificationSource: `dont-lose-progress`,
        action: e
    })
}
var K = () => {
        let {
            gameLoadStatus: t
        } = (0, P.useContext)(e), {
            gfInit: n
        } = (0, P.useContext)(u), {
            shouldShowWelcomeBack: a,
            canShowSplashNotice: o,
            reportWelcomeBackGuestNoticeAction: c
        } = (0, P.useContext)(j), {
            isAppTrueFullscreen: l
        } = S(), d = D(), f = (0, P.useRef)(null), p = b(), [m, h] = (0, P.useState)(!1), [_, v] = (0, P.useState)(!1), [T, E] = (0, P.useState)(!1), [O] = (0, P.useState)(() => Date.now()), k = r.Instance.getItem(W), A = k ? O - Number(k) : null, M = !m && !(A && A < U), N = M && t === `GAME_LOADED`, F = M && o, I = g(`aps-login-pill`, y.apsLoginPill, N), R = e => {
            e.stopPropagation(), e.preventDefault(), h(!0);
            let t = Date.now();
            r.Instance.setItem(W, `${t}`)
        };
        P.useEffect(() => {
            let e;
            if (!d || !p) return;
            let t = new IntersectionObserver(([t]) => {
                t.isIntersecting && !e && (e = window.setTimeout(() => {
                    v(!0)
                }, V * 1e3))
            });
            return f && f.current && t.observe(f.current),
                function() {
                    t.disconnect(), e && window.clearTimeout(e)
                }
        }, [d, f, t, I]), P.useEffect(() => {
            if (!_) return;
            let e = window.setTimeout(() => {
                v(!1), h(!0)
            }, H * 1e3);
            return () => {
                window.clearTimeout(e)
            }
        }, [_]), P.useEffect(() => {
            if (!F) return;
            let e = window.setTimeout(() => {
                h(!0)
            }, (V + H) * 1e3);
            return () => {
                window.clearTimeout(e)
            }
        }, [F]);
        let z = (0, P.useRef)(!1);
        P.useEffect(() => {
            z.current || !n || !p || n.state === `success` && n.data.wasUserLoggedIn && (z.current = !0, G(`shown`))
        }, [n, p]);
        let K = () => {
            i(!0)
        };
        return a && !T ? (0, L.jsx)(B, {
            onContinueAsGuest: () => {
                E(!0), c(`ignored`)
            },
            onLogin: () => {
                i(!0), E(!0), c(`login`)
            }
        }) : F ? (0, L.jsx)(`div`, {
            className: C(s.loginSplash, {
                [s.loginSplashPadded]: d,
                [s.inAppTrueFullscreen]: l
            }),
            onClick: K,
            children: (0, L.jsxs)(`div`, {
                className: s.loginActions,
                children: [(0, L.jsx)(x, {
                    id: `aps.splash.loginPrompt`
                }), (0, L.jsx)(w, {
                    variant: `outlined`,
                    color: `white`,
                    height: 32,
                    onClick: R,
                    className: s.loginClose,
                    children: (0, L.jsx)(x, {
                        id: `aps.info.loginPrompt.close`
                    })
                }), (0, L.jsx)(w, {
                    variant: `contained`,
                    color: `white`,
                    height: 32,
                    onClick: K,
                    children: (0, L.jsx)(x, {
                        id: `aps.info.loginPrompt.cta`
                    })
                })]
            })
        }) : N && I ? (0, L.jsx)(`div`, {
            className: C(s.mobileLogin, _ ? s.mobileLoginVisible : s.mobileLoginPending, {
                [s.inAppTrueFullscreen]: l
            }),
            ref: f,
            children: (0, L.jsxs)(`div`, {
                children: [(0, L.jsx)(x, {
                    id: `aps.info.loginPrompt`
                }), (0, L.jsxs)(`div`, {
                    children: [(0, L.jsx)(w, {
                        variant: `outlined`,
                        color: `white`,
                        height: 28,
                        onClick: R,
                        children: (0, L.jsx)(x, {
                            id: `aps.info.loginPrompt.close`
                        })
                    }), (0, L.jsx)(w, {
                        variant: `contained`,
                        color: `white`,
                        height: 28,
                        onClick: K,
                        className: s.loginCta,
                        children: (0, L.jsx)(x, {
                            id: `aps.info.loginPrompt.cta`
                        })
                    })]
                })]
            })
        }) : null
    },
    q = () => {
        let t = (0, F.c)(3),
            {
                gameLoadStatus: n
            } = (0, P.useContext)(e),
            r = D(),
            [i, a] = P.useState(!1);
        if (n !== `NOT_STARTED` || r) return null;
        if (i) {
            let e;
            return t[0] === Symbol.for(`react.memo_cache_sentinel`) ? (e = (0, L.jsx)(R, {
                title: (0, L.jsx)(x, {
                    id: `aps.tooltip.account.title`
                }),
                body: (0, L.jsx)(x, {
                    id: `aps.tooltip.account.body`
                }),
                action: a
            }), t[0] = e) : e = t[0], e
        }
        let o;
        t[1] === Symbol.for(`react.memo_cache_sentinel`) ? (o = (0, L.jsx)(`div`, {
            children: (0, L.jsx)(x, {
                id: `aps.info.ingame`,
                values: {
                    highlight: (0, L.jsx)(`span`, {
                        className: s.highlightWarning,
                        children: (0, L.jsx)(x, {
                            id: `aps.info.ingame.highlight`
                        })
                    })
                }
            })
        }), t[1] = o) : o = t[1];
        let c;
        return t[2] === Symbol.for(`react.memo_cache_sentinel`) ? (c = (0, L.jsx)(`div`, {
            className: s.wrapper,
            children: (0, L.jsxs)(`div`, {
                className: s.info,
                children: [o, (0, L.jsx)(h, {
                    name: `question-bubble`,
                    size: 16,
                    className: s.questionBubble,
                    onClick: () => a(!0)
                })]
            })
        }), t[2] = c) : c = t[2], c
    },
    J = () => {
        let t = (0, F.c)(3),
            {
                gameLoadStatus: n
            } = (0, P.useContext)(e),
            [r, i] = P.useState(!1);
        if (n !== `NOT_STARTED`) return null;
        if (r) {
            let e;
            return t[0] === Symbol.for(`react.memo_cache_sentinel`) ? (e = (0, L.jsx)(R, {
                title: (0, L.jsx)(x, {
                    id: `aps.tooltip.locally.title`
                }),
                body: (0, L.jsx)(x, {
                    id: `aps.tooltip.locally.body`
                }),
                action: i
            }), t[0] = e) : e = t[0], e
        }
        let a;
        t[1] === Symbol.for(`react.memo_cache_sentinel`) ? (a = (0, L.jsx)(`div`, {
            children: (0, L.jsx)(x, {
                id: `aps.info.base`,
                values: {
                    highlight: (0, L.jsx)(`span`, {
                        className: s.highlightWarning,
                        children: (0, L.jsx)(x, {
                            id: `aps.info.base.local`
                        })
                    })
                }
            })
        }), t[1] = a) : a = t[1];
        let o;
        return t[2] === Symbol.for(`react.memo_cache_sentinel`) ? (o = (0, L.jsx)(`div`, {
            className: s.wrapper,
            children: (0, L.jsxs)(`div`, {
                className: s.info,
                children: [a, (0, L.jsx)(h, {
                    name: `question-bubble`,
                    size: 16,
                    className: s.questionBubble,
                    onClick: () => i(!0)
                })]
            })
        }), t[2] = o) : o = t[2], o
    },
    Y = () => {
        let e = T().loader,
            t = k[e];
        return N() ? t.type === `unity` && t.supportsAps ? o() : t.type === `other` && t.supportsIFrameApsLoader ? d() : e === `ruffle` ? A() : !1 : !1
    },
    X = () => {
        let e = (0, F.c)(4),
            {
                accountId: n,
                hasUserLoaded: r
            } = (0, P.useContext)(t);
        if (T().gameStatus === `unavailable`) return null;
        let i = O(),
            a = c();
        if (i === `ingame`) {
            let t;
            return e[0] === Symbol.for(`react.memo_cache_sentinel`) ? (t = (0, L.jsx)(q, {}), e[0] = t) : t = e[0], t
        }
        if (i === `local`) {
            let t;
            return e[1] === Symbol.for(`react.memo_cache_sentinel`) ? (t = (0, L.jsx)(J, {}), e[1] = t) : t = e[1], t
        }
        if (i === `cloud`) {
            if (!r || a === `aps` && !Y()) return null;
            if (n) {
                let t;
                return e[2] === Symbol.for(`react.memo_cache_sentinel`) ? (t = (0, L.jsx)(z, {}), e[2] = t) : t = e[2], t
            }
            let t;
            return e[3] === Symbol.for(`react.memo_cache_sentinel`) ? (t = (0, L.jsx)(K, {}), e[3] = t) : t = e[3], t
        }
        return null
    };
export {
    X as
    default
};
//# debugId=9470a2d3-c270-5367-ab63-efc79abbe14b