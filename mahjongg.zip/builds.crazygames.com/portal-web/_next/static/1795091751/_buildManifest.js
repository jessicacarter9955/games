self.__BUILD_MANIFEST = function(s, c, a, e, t, i, n, d, f, b, p, r, g, u, h, o, k, j, m, l, y, _, v, I, w, B, F, x, A, N, D) {
    return {
        __rewrites: {
            afterFiles: [],
            beforeFiles: [{
                has: void 0,
                source: "/portal-web/_next/:path+",
                destination: "/_next/:path+"
            }],
            fallback: []
        },
        __routerFilterStatic: {
            numItems: 0,
            errorRate: 1e-4,
            numBits: 0,
            numHashes: v,
            bitArray: []
        },
        __routerFilterDynamic: {
            numItems: 0,
            errorRate: 1e-4,
            numBits: 0,
            numHashes: v,
            bitArray: []
        },
        "/": ["static/css/032e52a9102e1bc7.css", s, c, a, e, t, u, I, p, "static/css/19f0432684284af0.css", "static/chunks/pages/index-4a54f395426b9158.js"],
        "/10-anniversary": [s, c, a, e, t, "static/chunks/pages/10-anniversary-0172ff7cd762c3b6.js"],
        "/_error": [s, c, a, e, t, "static/chunks/pages/_error-d8d82773a04e7b44.js"],
        "/app-login": [w, B, s, c, a, e, t, "static/chunks/pages/app-login-af7e89a19530e180.js"],
        "/c/[tag]/[[...page]]": [s, c, a, e, t, i, n, d, r, g, p, h, o, "static/chunks/pages/c/[tag]/[[...page]]-5db1aed52219fbdc.js"],
        "/competitions": [f, b, s, c, a, e, t, k, "static/chunks/pages/competitions-715f323e584f8158.js"],
        "/dev/offline-gaming": [j, F, s, c, a, e, t, u, m, l, x, A, N, "static/css/13311b9e1b3be0d4.css", "static/chunks/pages/dev/offline-gaming-b95b9b6805714d76.js"],
        "/dev/save-cache-inspector": [j, F, s, c, a, e, t, u, l, "static/chunks/pages/dev/save-cache-inspector-6ca7b330a759d550.js"],
        "/email-handler": [w, B, s, c, a, e, t, "static/css/7998c5168b3b01e4.css", "static/chunks/pages/email-handler-b1713e52f9c58e65.js"],
        "/game/[game]": [s, c, a, e, t, D, "static/chunks/pages/game/[game]-ad1c3e8dbd589296.js"],
        "/hot/[[...page]]": [s, c, a, e, t, i, n, d, y, _, "static/chunks/pages/hot/[[...page]]-0bc05167a049b3de.js"],
        "/index-capacitor": [s, c, a, e, t, "static/chunks/pages/index-capacitor-a3cfa7a90bb4d97f.js"],
        "/information-for-parents": [f, b, s, c, a, e, t, k, "static/chunks/pages/information-for-parents-d9c3cc6b3a7accac.js"],
        "/leaderboards": [s, c, a, e, t, i, n, d, r, g, p, h, o, "static/chunks/pages/leaderboards-9255d6de4add43a6.js"],
        "/multiplayer/[[...page]]": [s, c, a, e, t, i, r, g, "static/css/6a2c84d8c3976fe7.css", "static/chunks/pages/multiplayer/[[...page]]-2bd1625ca24c38e1.js"],
        "/mygames": [s, c, a, e, t, m, "static/chunks/90002-168f480e6cc7d1f6.js", "static/css/91f4b48f90d625cc.css", "static/css/955649055b5c2e01.css", "static/chunks/pages/mygames-024d76a09b4597d6.js"],
        "/new/[[...page]]": [s, c, a, e, t, i, n, d, y, _, "static/chunks/pages/new/[[...page]]-b2351d4dd643947a.js"],
        "/offline-mode": [j, s, c, a, e, t, u, m, l, I, x, A, N, "static/chunks/13014-2834f766fd2e3451.js", "static/css/3004e2c7168c02ba.css", "static/chunks/pages/offline-mode-897f9cfd10139056.js"],
        "/originals/[[...page]]": [s, c, a, e, t, i, n, d, r, g, p, "static/css/294b92d0611f363e.css", "static/chunks/pages/originals/[[...page]]-0676784b3911ffdd.js"],
        "/preview/[submissionId]": [s, c, a, e, t, D, "static/chunks/pages/preview/[submissionId]-4b07d79709d096fb.js"],
        "/privacy-policy": [f, b, s, c, a, e, t, "static/css/7b096f40b22e81c8.css", "static/chunks/pages/privacy-policy-9ee5f90d51ad8bf6.js"],
        "/privacy-policy-inline": [f, b, s, c, a, e, t, "static/css/fa22a5e0d00795ae.css", "static/chunks/pages/privacy-policy-inline-3f4c60f9b2bfd233.js"],
        "/recent": [s, c, a, e, t, i, n, d, "static/css/4d6b1fdb9003c4f5.css", "static/chunks/pages/recent-52295a5a7f7ef8ff.js"],
        "/scholarship": [f, b, s, c, a, e, t, "static/css/d7dd1176aeed6e3f.css", "static/chunks/pages/scholarship-37241dfd6ed95a05.js"],
        "/search": [s, c, a, e, t, "static/chunks/33297-74b8dca86dff2137.js", "static/css/7deffa60fe068947.css", "static/css/ca62cd4785478bad.css", "static/chunks/pages/search-8e73a0df517eff66.js"],
        "/sitemap/games/[[...page]]": [s, c, a, e, t, i, n, d, "static/css/7d8f135f372b64cd.css", "static/chunks/pages/sitemap/games/[[...page]]-5f8fd4b5df9924e7.js"],
        "/t/[tag]/[[...page]]": [s, c, a, e, t, i, n, d, r, g, p, h, o, "static/chunks/pages/t/[tag]/[[...page]]-1dc04a8190683156.js"],
        "/tags": [s, c, a, e, t, "static/css/92e79a6070a2ce2e.css", "static/chunks/pages/tags-e5b32ee0dacc71b5.js"],
        "/terms-and-conditions": [f, b, s, c, a, e, t, k, "static/chunks/pages/terms-and-conditions-016d40382df66c4f.js"],
        "/u/[username]": [s, c, a, e, t, "static/css/1d0607eebf063935.css", "static/chunks/pages/u/[username]-d25381d5e49221a4.js"],
        "/uid/[uid]": [s, c, a, e, t, "static/chunks/pages/uid/[uid]-cdcda7fed08a1243.js"],
        "/updated/[[...page]]": [s, c, a, e, t, i, n, d, y, _, "static/chunks/pages/updated/[[...page]]-a043d9e410fa1585.js"],
        sortedPages: ["/", "/10-anniversary", "/_app", "/_error", "/app-login", "/c/[tag]/[[...page]]", "/competitions", "/dev/offline-gaming", "/dev/save-cache-inspector", "/email-handler", "/game/[game]", "/hot/[[...page]]", "/index-capacitor", "/information-for-parents", "/leaderboards", "/multiplayer/[[...page]]", "/mygames", "/new/[[...page]]", "/offline-mode", "/originals/[[...page]]", "/preview/[submissionId]", "/privacy-policy", "/privacy-policy-inline", "/recent", "/scholarship", "/search", "/sitemap/games/[[...page]]", "/t/[tag]/[[...page]]", "/tags", "/terms-and-conditions", "/u/[username]", "/uid/[uid]", "/updated/[[...page]]"]
    }
}("static/chunks/6847-aefee112308b4d28.js", "static/css/e844aa76c7b000fa.css", "static/chunks/89247-b71493a621fcc168.js", "static/css/c4a72e6084fc69c3.css", "static/chunks/88823-2d8457dd7fbe1da5.js", "static/chunks/67088-05ab2c5f781ccb02.js", "static/css/bb049e94b3a41c66.css", "static/chunks/67473-5dd0336526fe0fa5.js", "static/chunks/63877-c2d40d30009765f7.js", "static/chunks/21421-04047272f8c6f639.js", "static/chunks/32627-060b16dedf2b72b6.js", "static/css/1ab95fe96c545eb4.css", "static/chunks/22694-386e7a60bcf73603.js", "static/chunks/8603-33d388bd4bc2131e.js", "static/css/3c8d18e0ad190a5b.css", "static/chunks/19954-becc5b1acca1b924.js", "static/css/a695ccffdb6aef8d.css", "static/chunks/9690-e20dda3addafa762.js", "static/chunks/89837-94227bbb7509f614.js", "static/chunks/3601-fb6730aea8343501.js", "static/css/34f5317aca7e1df6.css", "static/chunks/96671-c575ca45be8101f2.js", NaN, "static/chunks/81259-21731c1f89c2cea2.js", "static/chunks/1bd5887b-aeda1d4dc1d4c5d6.js", "static/chunks/14434-c17bcbafd5b6f726.js", "static/chunks/58707-464970154b16ee0f.js", "static/chunks/39565-c5b03d859dee9be4.js", "static/chunks/6404-98bcb016c20dca63.js", "static/css/7298308bc3878c18.css", "static/chunks/73066-ee4e2d0ab88fd850.js"), self.__BUILD_MANIFEST_CB && self.__BUILD_MANIFEST_CB();