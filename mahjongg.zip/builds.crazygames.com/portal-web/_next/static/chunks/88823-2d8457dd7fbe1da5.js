! function() {
    try {
        var t = "u" > typeof window ? window : "u" > typeof global ? global : "u" > typeof globalThis ? globalThis : "u" > typeof self ? self : {};
        t._sentryModuleMetadata = t._sentryModuleMetadata || {}, t._sentryModuleMetadata[(new t.Error).stack] = function(t) {
            for (var e = 1; e < arguments.length; e++) {
                var n = arguments[e];
                if (null != n)
                    for (var o in n) n.hasOwnProperty(o) && (t[o] = n[o])
            }
            return t
        }({}, t._sentryModuleMetadata[(new t.Error).stack], {
            "_sentryBundlerPluginAppKey:crazygames-portal": !0
        });
        var e = (new t.Error).stack;
        e && (t._sentryDebugIds = t._sentryDebugIds || {}, t._sentryDebugIds[e] = "e828b1ac-10d2-4f88-a29f-bcc267f940af", t._sentryDebugIdIdentifier = "sentry-dbid-e828b1ac-10d2-4f88-a29f-bcc267f940af")
    } catch (t) {}
}(), (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [57280, 88823], {
        13184: (t, e, n) => {
            "use strict";
            n.d(e, {
                A: () => r
            });
            var o = n(55729);

            function r(t) {
                let [e, n] = o.useState(!1), r = t.replace("@media ", "");
                return o.useEffect(() => {
                    let t = window.matchMedia(r);
                    n(t.matches);
                    let e = t => n(t.matches);
                    return t.addEventListener("change", e), () => t.removeEventListener("change", e)
                }, [r]), e
            }
        },
        26981: t => {
            t.exports = {
                czyButton: "Error_czyButton__0TeNR",
                "czyButton--contained--purple": "Error_czyButton--contained--purple__uJt_h",
                "czyButton--contained--white": "Error_czyButton--contained--white__c3d3F",
                "czyButton--contained--grey": "Error_czyButton--contained--grey__odOqX",
                "czyButton--contained--warning": "Error_czyButton--contained--warning__ElcT4",
                "czyButton--contained--alert": "Error_czyButton--contained--alert___Vc3H",
                "czyButton--contained--success": "Error_czyButton--contained--success__aSZDK",
                "czyButton--contained--black": "Error_czyButton--contained--black__b_xuF",
                "czyButton--contained--green-gradient": "Error_czyButton--contained--green-gradient__SezpV",
                "czyButton--contained--animated-green-gradient": "Error_czyButton--contained--animated-green-gradient__RvthS",
                "scroll-gradient": "Error_scroll-gradient__vLUS_",
                "czyButton--outlined--purple": "Error_czyButton--outlined--purple__p_Ih2",
                "czyButton--link--purple": "Error_czyButton--link--purple__bdJ7o",
                "czyButton--outlined--white": "Error_czyButton--outlined--white__nOdDU",
                "czyButton--link--white": "Error_czyButton--link--white__0qSuK",
                "czyButton--outlined--grey": "Error_czyButton--outlined--grey__vj4y2",
                "czyButton--link--grey": "Error_czyButton--link--grey__ebRtY",
                "czyButton--outlined--warning": "Error_czyButton--outlined--warning__EZwtJ",
                "czyButton--link--warning": "Error_czyButton--link--warning__8xdme",
                "czyButton--outlined--alert": "Error_czyButton--outlined--alert__nx4QA",
                "czyButton--link--alert": "Error_czyButton--link--alert__shxc_",
                "czyButton--outlined--success": "Error_czyButton--outlined--success__LT2vw",
                "czyButton--link--success": "Error_czyButton--link--success__aLnkL",
                "czyButton--outlined": "Error_czyButton--outlined__AohI2",
                "czyButton--disabled": "Error_czyButton--disabled__py6To",
                "czyButton--height50": "Error_czyButton--height50__rAybD",
                "czyButton--height34": "Error_czyButton--height34__T0YvD",
                "czyButton--height28": "Error_czyButton--height28___bbRt",
                "czyButton--fullWidth": "Error_czyButton--fullWidth__vvIRf",
                "czyButton--headerIcon": "Error_czyButton--headerIcon__cjSMQ",
                "czyButton--headerIcon--desktop": "Error_czyButton--headerIcon--desktop__XXAvn",
                "czyButton--headerIcon--mobile": "Error_czyButton--headerIcon--mobile__chep8",
                "czyButton--headerIcon--withLabel": "Error_czyButton--headerIcon--withLabel__6VP_T",
                errorWrapper: "Error_errorWrapper__veiu7",
                errorContainer: "Error_errorContainer__NF_Cc",
                error500: "Error_error500__o8syc",
                title: "Error_title__qPFfw",
                gridContainer: "Error_gridContainer__KYAuX",
                error404MainButton: "Error_error404MainButton__5Ybng",
                error500button: "Error_error500button__KSvFl",
                reload: "Error_reload__k2Fp9",
                contentNotAvailableButton: "Error_contentNotAvailableButton__bq9Z5",
                errorMessage: "Error_errorMessage__Vsocp",
                errorContentNotAvailable: "Error_errorContentNotAvailable__gSmR4",
                ziggyNotFoundIcon: "Error_ziggyNotFoundIcon__yJex1"
            }
        },
        29403: (t, e, n) => {
            "use strict";
            n.d(e, {
                A: () => B
            });
            var o = n(6029),
                r = n(75155),
                i = n(55729),
                c = n(79942),
                a = n(50212),
                u = n(71684),
                _ = n(83980),
                s = n(73119),
                l = n.n(s);
            let d = () => {
                let t, e = (0, r.c)(1);
                return e[0] === Symbol.for("react.memo_cache_sentinel") ? (t = (0, o.jsxs)("div", {
                    className: l().root,
                    children: [(0, o.jsx)("h1", {
                        className: l().text,
                        "data-title": "GAME",
                        children: "GAME"
                    }), (0, o.jsx)("h1", {
                        className: l().text,
                        "data-title": "OVER",
                        children: "OVER"
                    })]
                }), e[0] = t) : t = e[0], t
            };
            var y = n(26981),
                g = n.n(y);
            let B = () => {
                let t, e, n, s, l, y = (0, r.c)(6),
                    {
                        crazyAnalyticsService: B
                    } = i.useContext(u.A).services;
                return y[0] !== B ? (t = () => {
                    B.trackGenericError("gameOver", {
                        path: window.location.pathname
                    })
                }, e = [B], y[0] = B, y[1] = t, y[2] = e) : (t = y[1], e = y[2]), i.useEffect(t, e), y[3] === Symbol.for("react.memo_cache_sentinel") ? (n = (0, a.A)(g().errorContainer), s = (0, o.jsx)(d, {}), y[3] = n, y[4] = s) : (n = y[3], s = y[4]), y[5] === Symbol.for("react.memo_cache_sentinel") ? (l = (0, o.jsxs)("div", {
                    className: g().errorWrapper,
                    children: [(0, o.jsxs)("div", {
                        className: n,
                        children: [s, (0, o.jsxs)("div", {
                            className: g().errorMessage,
                            children: [(0, o.jsx)(c.x6, {
                                id: "error.404.deadEnd"
                            }), (0, o.jsx)("br", {}), (0, o.jsx)(c.x6, {
                                id: "error.404.pageDoesNotExist"
                            })]
                        })]
                    }), (0, o.jsx)(_.A, {
                        clickOriginPrefix: "errorPage"
                    })]
                }), y[5] = l) : l = y[5], l
            }
        },
        58261: t => {
            t.exports = {
                czyButton: "SuggestionFooter_czyButton__gqeRc",
                "czyButton--contained--purple": "SuggestionFooter_czyButton--contained--purple__apW2h",
                "czyButton--contained--white": "SuggestionFooter_czyButton--contained--white__8BBp2",
                "czyButton--contained--grey": "SuggestionFooter_czyButton--contained--grey__ZlhFv",
                "czyButton--contained--warning": "SuggestionFooter_czyButton--contained--warning__6A4EX",
                "czyButton--contained--alert": "SuggestionFooter_czyButton--contained--alert__1Wp0v",
                "czyButton--contained--success": "SuggestionFooter_czyButton--contained--success__wS84k",
                "czyButton--contained--black": "SuggestionFooter_czyButton--contained--black__BYsNE",
                "czyButton--contained--green-gradient": "SuggestionFooter_czyButton--contained--green-gradient__TegRA",
                "czyButton--contained--animated-green-gradient": "SuggestionFooter_czyButton--contained--animated-green-gradient__I3OVf",
                "scroll-gradient": "SuggestionFooter_scroll-gradient__ldlTO",
                "czyButton--outlined--purple": "SuggestionFooter_czyButton--outlined--purple__tsj4k",
                "czyButton--link--purple": "SuggestionFooter_czyButton--link--purple__S3mP9",
                "czyButton--outlined--white": "SuggestionFooter_czyButton--outlined--white__duQRA",
                "czyButton--link--white": "SuggestionFooter_czyButton--link--white__ykgmI",
                "czyButton--outlined--grey": "SuggestionFooter_czyButton--outlined--grey__Sb5HT",
                "czyButton--link--grey": "SuggestionFooter_czyButton--link--grey__XgWZW",
                "czyButton--outlined--warning": "SuggestionFooter_czyButton--outlined--warning__apI5m",
                "czyButton--link--warning": "SuggestionFooter_czyButton--link--warning__mub3N",
                "czyButton--outlined--alert": "SuggestionFooter_czyButton--outlined--alert__q6pbV",
                "czyButton--link--alert": "SuggestionFooter_czyButton--link--alert__WL_6H",
                "czyButton--outlined--success": "SuggestionFooter_czyButton--outlined--success__WQcdr",
                "czyButton--link--success": "SuggestionFooter_czyButton--link--success__tW0lO",
                "czyButton--outlined": "SuggestionFooter_czyButton--outlined___aCeV",
                "czyButton--disabled": "SuggestionFooter_czyButton--disabled__z4GOh",
                "czyButton--height50": "SuggestionFooter_czyButton--height50__b6Xob",
                "czyButton--height34": "SuggestionFooter_czyButton--height34__T7RAL",
                "czyButton--height28": "SuggestionFooter_czyButton--height28__BT_ip",
                "czyButton--fullWidth": "SuggestionFooter_czyButton--fullWidth__y3xrs",
                "czyButton--headerIcon": "SuggestionFooter_czyButton--headerIcon__rERV2",
                "czyButton--headerIcon--desktop": "SuggestionFooter_czyButton--headerIcon--desktop__pv_02",
                "czyButton--headerIcon--mobile": "SuggestionFooter_czyButton--headerIcon--mobile__5MDW_",
                "czyButton--headerIcon--withLabel": "SuggestionFooter_czyButton--headerIcon--withLabel__WsK1H",
                root: "SuggestionFooter_root__Vt_0G",
                suggestionLinksWrapper: "SuggestionFooter_suggestionLinksWrapper__wiTvE",
                gridContainer: "SuggestionFooter_gridContainer__QuQdm",
                isMobile: "SuggestionFooter_isMobile__HdlEI",
                fluidButton: "SuggestionFooter_fluidButton__5aqLC",
                suggestionLinkButton: "SuggestionFooter_suggestionLinkButton__abkRr",
                orTryContainer: "SuggestionFooter_orTryContainer__MrJbJ"
            }
        },
        66670: (t, e, n) => {
            "use strict";
            n.d(e, {
                A: () => f
            });
            var o = n(6029),
                r = n(75155),
                i = n(55729),
                c = n(81278),
                a = n(33770),
                u = n(68168),
                _ = n(29403),
                s = n(79942),
                l = n(50212),
                d = n(81930),
                y = n(67988),
                g = n(93389),
                B = n(43711),
                z = n(46996),
                h = n(93800),
                m = n(37434),
                p = n(26981),
                G = n.n(p);
            let x = () => {
                let t, e, n, c, a, u, _, p, x, k, w, b, f, E, A, S, C, j, I = (0, r.c)(28),
                    {
                        routeHelper: F
                    } = i.useContext(g.A),
                    {
                        openMainFeedbackDrawer: O
                    } = i.useContext(z.d);
                I[0] !== F ? (t = F.homePageLink(), I[0] = F, I[1] = t) : t = I[1];
                let L = t,
                    {
                        spacing: N
                    } = (0, y.D)();
                return I[2] === Symbol.for("react.memo_cache_sentinel") ? (e = (0, l.A)(G().errorContainer, G().error500), n = (0, o.jsx)("img", {
                    src: (0, d.Ay)("assets/SVG/icons/ziggy-not-found.svg", {}, !1),
                    alt: "",
                    className: G().ziggyNotFoundIcon
                }), c = (0, o.jsx)("h2", {
                    children: (0, o.jsx)(s.x6, {
                        id: "error.500.wrong"
                    })
                }), I[2] = e, I[3] = n, I[4] = c) : (e = I[2], n = I[3], c = I[4]), I[5] === Symbol.for("react.memo_cache_sentinel") ? (a = (0, o.jsx)("div", {
                    className: G().title,
                    children: (0, o.jsx)(s.x6, {
                        id: "error.500.reload"
                    })
                }), I[5] = a) : a = I[5], I[6] === Symbol.for("react.memo_cache_sentinel") ? (u = (0, l.A)(G().error500button, G().reload), I[6] = u) : u = I[6], I[7] === Symbol.for("react.memo_cache_sentinel") ? (_ = (0, o.jsx)(h.A, {
                    name: "refresh"
                }), I[7] = _) : _ = I[7], I[8] === Symbol.for("react.memo_cache_sentinel") ? (p = (0, o.jsxs)(m.A, {
                    height: 50,
                    variant: "contained",
                    className: u,
                    onClick: v,
                    children: [_, " ", (0, o.jsx)(s.x6, {
                        id: "error.500.reloadBtn"
                    })]
                }), I[8] = p) : p = I[8], I[9] === Symbol.for("react.memo_cache_sentinel") ? (x = (0, o.jsx)(h.A, {
                    name: "home"
                }), I[9] = x) : x = I[9], I[10] === Symbol.for("react.memo_cache_sentinel") ? (k = (0, o.jsxs)(m.A, {
                    height: 50,
                    variant: "outlined",
                    className: G().error500button,
                    color: "white",
                    children: [x, " ", (0, o.jsx)(s.x6, {
                        id: "common.footer.goBackHome"
                    })]
                }), I[10] = k) : k = I[10], I[11] !== L ? (w = (0, o.jsx)(B.A, {
                    prefetch: !0,
                    ...L,
                    children: k
                }), I[11] = L, I[12] = w) : w = I[12], I[13] !== N ? (b = N(4), I[13] = N, I[14] = b) : b = I[14], I[15] !== b ? (f = {
                    marginTop: b
                }, I[15] = b, I[16] = f) : f = I[16], I[17] !== O ? (E = () => {
                    O("errorPage")
                }, I[17] = O, I[18] = E) : E = I[18], I[19] === Symbol.for("react.memo_cache_sentinel") ? (A = (0, o.jsx)(s.x6, {
                    id: "error.500.contactUs"
                }), I[19] = A) : A = I[19], I[20] !== E ? (S = (0, o.jsx)(s.x6, {
                    id: "error.500.notWorking",
                    values: {
                        link: (0, o.jsx)(m.A, {
                            variant: "link",
                            onClick: E,
                            children: A
                        })
                    }
                }), I[20] = E, I[21] = S) : S = I[21], I[22] !== f || I[23] !== S ? (C = (0, o.jsx)("div", {
                    style: f,
                    children: S
                }), I[22] = f, I[23] = S, I[24] = C) : C = I[24], I[25] !== w || I[26] !== C ? (j = (0, o.jsx)("div", {
                    className: G().errorWrapper,
                    children: (0, o.jsxs)("div", {
                        className: e,
                        children: [n, c, a, p, w, C]
                    })
                }), I[25] = w, I[26] = C, I[27] = j) : j = I[27], j
            };

            function v() {
                return location.reload()
            }
            var k = n(12097),
                w = n(95267),
                b = n(61411);
            let f = function(t) {
                class e extends i.Component {
                    static async getInitialProps(e) {
                        try {
                            let n = t.getInitialProps ? await t.getInitialProps(e) : {};
                            return n.statusCode && e.res && (e.res.statusCode = n.statusCode), n
                        } catch (n) {
                            let t = 500;
                            return console.error(n.message), n instanceof u.A && (t = n.statusCode), e.res && (e.res.statusCode = t, t >= 500 && e.res.setHeader("Cache-Control", (0, a.TA)())), {
                                statusCode: t
                            }
                        }
                    }
                    static getDerivedStateFromError(t) {
                        return {
                            hasError: !0
                        }
                    }
                    constructor(t) {
                        super(t);
                        const {
                            statusCode: e
                        } = t;
                        this.state = {
                            hasError: !!(e && e >= 400)
                        }
                    }
                    componentDidMount() {
                        let t = (0, b.cy)(window.location.hostname),
                            {
                                analyticsService: e
                            } = (0, k.K)(t);
                        this.props.statusCode && e.trackGAEvent({
                            eventCategory: "error-page",
                            eventAction: "error-page",
                            eventLabel: `${this.props.statusCode}`,
                            nonInteraction: !0
                        })
                    }
                    componentDidUpdate() {
                        let {
                            hasError: t
                        } = this.state;
                        if (!this.props.statusCode || this.props.statusCode < 400) {
                            t && this.setState({
                                hasError: !1
                            });
                            return
                        }
                        if (!t) {
                            let t = (0, b.cy)(window.location.hostname),
                                {
                                    analyticsService: e
                                } = (0, k.K)(t);
                            e.trackGAEvent({
                                eventCategory: "error-page",
                                eventAction: "error-page",
                                eventLabel: `${this.props.statusCode}`,
                                nonInteraction: !0
                            }), this.setState({
                                hasError: !0
                            })
                        }
                    }
                    render() {
                        let {
                            statusCode: e,
                            router: n,
                            handleOfflineError: r
                        } = this.props;
                        return this.hasError() ? n ? r && r(e) ? void 0 : e >= 400 && e < 500 ? this.render404() : this.render500() : this.renderCouldNotRenderErrorPage() : (0, o.jsx)(t, { ...this.props
                        })
                    }
                    render404() {
                        return (0, o.jsx)(_.A, {})
                    }
                    render500() {
                        return (0, o.jsx)(x, {})
                    }
                    renderCouldNotRenderErrorPage() {
                        return (0, o.jsx)(i.Fragment, {
                            children: (0, o.jsx)("article", {
                                children: (0, o.jsx)("main", {
                                    children: "An error has occured"
                                })
                            })
                        })
                    }
                    hasError() {
                        let {
                            hasError: t
                        } = this.state;
                        return t
                    }
                }
                let n = (0, c.withRouter)(t => {
                    let n, i = (0, r.c)(3),
                        c = (0, w.t)();
                    return i[0] !== c || i[1] !== t ? (n = (0, o.jsx)(e, { ...t,
                        handleOfflineError: c
                    }), i[0] = c, i[1] = t, i[2] = n) : n = i[2], n
                });
                return n.getInitialProps = e.getInitialProps, n
            }
        },
        69395: (t, e, n) => {
            "use strict";
            n.d(e, {
                A: () => r
            });
            var o = n(13184);
            let r = () => (0, o.A)("@media (orientation: landscape), (min-width: 481px)")
        },
        70930: (t, e, n) => {
            "use strict";
            n.d(e, {
                A: () => y
            });
            var o = n(6029),
                r = n(75155),
                i = n(55729),
                c = n(98417),
                a = n(50212),
                u = n(89247),
                _ = n(59126),
                s = n(71684),
                l = n(86907),
                d = n.n(l);
            let y = t => {
                let e, n, l, y, g, B, z, h, m = (0, r.c)(42),
                    {
                        games: p,
                        justifyContent: G,
                        slidesToLoadEagerly: x,
                        contentVisibility: v,
                        containIntrinsicSize: k,
                        customStyles: w,
                        thumbIconFn: b,
                        thumbIcon: f,
                        loading: E,
                        enableInstantJoin: A,
                        className: S,
                        removeThumbLabels: C,
                        twoColumnHoverScale: j,
                        disableHoverScale: I
                    } = t,
                    {
                        crazyAnalyticsService: F
                    } = i.useContext(s.A).services;
                m[0] !== F ? (e = t => {
                    F.sendClickOnGame(t)
                }, m[0] = F, m[1] = e) : e = m[1];
                let O = e;
                m[2] !== v ? (n = v ? {
                    "--content-visibility": v
                } : {}, m[2] = v, m[3] = n) : n = m[3], m[4] !== k ? (l = void 0 !== k ? {
                    "--contain-intrinsic-size": `${k}px`
                } : {}, m[4] = k, m[5] = l) : l = m[5], m[6] !== n || m[7] !== l ? (y = { ...n,
                    ...l
                }, m[6] = n, m[7] = l, m[8] = y) : y = m[8];
                let L = y,
                    N = "auto" === v,
                    W = void 0 !== k;
                if (m[9] !== S || m[10] !== N || m[11] !== W ? (g = (0, a.A)(d().gameContainer, {
                        [d().contentVisibilityAuto]: N,
                        [d().hasContainIntrinsicSize]: W
                    }, S), m[9] = S, m[10] = N, m[11] = W, m[12] = g) : g = m[12], m[13] !== L || m[14] !== w || m[15] !== G ? (B = { ...L,
                        ...w,
                        justifyContent: G
                    }, m[13] = L, m[14] = w, m[15] = G, m[16] = B) : B = m[16], m[17] !== I || m[18] !== A || m[19] !== p || m[20] !== E || m[21] !== O || m[22] !== C || m[23] !== x || m[24] !== f || m[25] !== b || m[26] !== j) {
                    let t;
                    m[28] !== I || m[29] !== A || m[30] !== E || m[31] !== O || m[32] !== C || m[33] !== x || m[34] !== f || m[35] !== b || m[36] !== j ? (t = (t, e) => t.loading || E ? (0, o.jsx)(_.A, {}, t.slug) : (0, o.jsx)(u.A, {
                        game: t,
                        enableInstantJoin: A,
                        eagerLoading: x ? e < x : void 0,
                        iconFn: b,
                        icon: f,
                        onClickAction: O,
                        isResponsiveGrid: !0,
                        removeThumbLabels: C,
                        hoverScaleOrigin: function(t, e) {
                            if ((0, c.O)(t)) return t && e % 2 == 0 ? "left" : "right"
                        }(j, e),
                        disableHoverScale: I
                    }, t.slug), m[28] = I, m[29] = A, m[30] = E, m[31] = O, m[32] = C, m[33] = x, m[34] = f, m[35] = b, m[36] = j, m[37] = t) : t = m[37], z = p.map(t), m[17] = I, m[18] = A, m[19] = p, m[20] = E, m[21] = O, m[22] = C, m[23] = x, m[24] = f, m[25] = b, m[26] = j, m[27] = z
                } else z = m[27];
                return m[38] !== g || m[39] !== B || m[40] !== z ? (h = (0, o.jsx)("div", {
                    className: g,
                    style: B,
                    children: z
                }), m[38] = g, m[39] = B, m[40] = z, m[41] = h) : h = m[41], h
            }
        },
        73119: t => {
            t.exports = {
                czyButton: "GameOver_czyButton__K7nDv",
                "czyButton--contained--purple": "GameOver_czyButton--contained--purple__uPfZ9",
                "czyButton--contained--white": "GameOver_czyButton--contained--white__GxmTy",
                "czyButton--contained--grey": "GameOver_czyButton--contained--grey__bJS63",
                "czyButton--contained--warning": "GameOver_czyButton--contained--warning__fR8qd",
                "czyButton--contained--alert": "GameOver_czyButton--contained--alert__IgIiD",
                "czyButton--contained--success": "GameOver_czyButton--contained--success__rM4EY",
                "czyButton--contained--black": "GameOver_czyButton--contained--black__BMaFH",
                "czyButton--contained--green-gradient": "GameOver_czyButton--contained--green-gradient__4AxCW",
                "czyButton--contained--animated-green-gradient": "GameOver_czyButton--contained--animated-green-gradient__hwD9T",
                "scroll-gradient": "GameOver_scroll-gradient___9z7i",
                "czyButton--outlined--purple": "GameOver_czyButton--outlined--purple__7iqt4",
                "czyButton--link--purple": "GameOver_czyButton--link--purple__5OZPf",
                "czyButton--outlined--white": "GameOver_czyButton--outlined--white__GnUpE",
                "czyButton--link--white": "GameOver_czyButton--link--white__w8d8S",
                "czyButton--outlined--grey": "GameOver_czyButton--outlined--grey__Yew6O",
                "czyButton--link--grey": "GameOver_czyButton--link--grey__pB9E7",
                "czyButton--outlined--warning": "GameOver_czyButton--outlined--warning__hyWwy",
                "czyButton--link--warning": "GameOver_czyButton--link--warning__jVgLS",
                "czyButton--outlined--alert": "GameOver_czyButton--outlined--alert__8zIVb",
                "czyButton--link--alert": "GameOver_czyButton--link--alert__P3kmV",
                "czyButton--outlined--success": "GameOver_czyButton--outlined--success__ZmyGe",
                "czyButton--link--success": "GameOver_czyButton--link--success__mi9l8",
                "czyButton--outlined": "GameOver_czyButton--outlined__gTBoW",
                "czyButton--disabled": "GameOver_czyButton--disabled__BaCFX",
                "czyButton--height50": "GameOver_czyButton--height50__lKpjh",
                "czyButton--height34": "GameOver_czyButton--height34__o_poh",
                "czyButton--height28": "GameOver_czyButton--height28__u_Myz",
                "czyButton--fullWidth": "GameOver_czyButton--fullWidth__4ibmO",
                "czyButton--headerIcon": "GameOver_czyButton--headerIcon__TyqvW",
                "czyButton--headerIcon--desktop": "GameOver_czyButton--headerIcon--desktop__BpDci",
                "czyButton--headerIcon--mobile": "GameOver_czyButton--headerIcon--mobile__EAz7o",
                "czyButton--headerIcon--withLabel": "GameOver_czyButton--headerIcon--withLabel__BfnQL",
                root: "GameOver_root__21XeV",
                text: "GameOver_text__TPUvW",
                glitch: "GameOver_glitch__01D2Z"
            }
        },
        83980: (t, e, n) => {
            "use strict";
            n.d(e, {
                A: () => b
            });
            var o = n(6029),
                r = n(55729),
                i = n(79942),
                c = n(50212),
                a = n(52461),
                u = n(50293),
                _ = n(93389),
                s = n(4230),
                l = n(43711),
                d = n(70930),
                y = n(6847),
                g = n(93800),
                B = n(71684),
                z = n(37434),
                h = n(71237),
                m = n(21233),
                p = n(61827),
                G = n(74532),
                x = n(58261),
                v = n.n(x);
            let k = r.memo(t => {
                    let {
                        routeHelper: e,
                        clickOriginPrefix: n
                    } = t, c = e.newPageLink(), u = e.hotPageLink(), _ = r.useContext(s.A), {
                        countryCode: d
                    } = r.useContext(G.A), {
                        services: y
                    } = r.useContext(B.A), {
                        likedGames: m
                    } = h.O0(), x = n || "suggestionFooter", {
                        clusterMap: k
                    } = h.lF(), {
                        crazyRouterChange: w
                    } = r.useContext(p.Gl);
                    return (0, o.jsxs)(o.Fragment, {
                        children: [(0, o.jsx)(a.x, {
                            newClickOrigin: `${x}-newGames`,
                            children: (0, o.jsx)(l.A, { ...c,
                                children: (0, o.jsxs)(z.A, {
                                    height: 50,
                                    variant: "contained",
                                    color: "white",
                                    className: v().suggestionLinkButton,
                                    children: [(0, o.jsx)(g.A, {
                                        name: "new"
                                    }), (0, o.jsx)(i.x6, {
                                        id: "common.footer.newGames"
                                    })]
                                })
                            })
                        }), (0, o.jsx)(a.x, {
                            newClickOrigin: `${x}-trendingGames`,
                            children: (0, o.jsx)(l.A, { ...u,
                                children: (0, o.jsxs)(z.A, {
                                    height: 50,
                                    variant: "contained",
                                    color: "white",
                                    className: v().suggestionLinkButton,
                                    children: [(0, o.jsx)(g.A, {
                                        name: "trending"
                                    }), (0, o.jsx)(i.x6, {
                                        id: "common.footer.trendingGames"
                                    })]
                                })
                            })
                        }), (0, o.jsxs)(z.A, {
                            height: 50,
                            variant: "contained",
                            color: "white",
                            onClick: () => {
                                let {
                                    randomGamesService: t
                                } = y;
                                t.getRandomGame(m, _, d, k).then(t => w(e.gamePageLink(t.slug).href, !1, !1, !0, `${x}-randomGame`)).catch(t => {
                                    console.error("Suggestion links footer error: ", t.message || t)
                                })
                            },
                            className: v().suggestionLinkButton,
                            children: [(0, o.jsx)(g.A, {
                                name: "random"
                            }), (0, o.jsx)(i.x6, {
                                id: "common.footer.randomGame"
                            })]
                        })]
                    })
                }),
                w = (0, m.A)(k),
                b = r.memo(t => {
                    let {
                        clickOriginPrefix: e
                    } = t, {
                        routeHelper: n
                    } = r.useContext(_.A), h = r.useContext(s.A), m = (0, u.xl)(h), p = n.homePageLink(), G = (() => {
                        let t = r.useContext(s.A),
                            [e, n] = r.useState([]),
                            {
                                api: o
                            } = r.useContext(B.A).services,
                            i = (0, u.Dw)(t),
                            c = r.useCallback(async () => {
                                n((await o.getFilteredGames({
                                    sorting: "default",
                                    device: i
                                }, {
                                    page: 1,
                                    size: 12
                                })).games.items)
                            }, [o, i]);
                        return r.useEffect(() => {
                            c()
                        }, [c]), e
                    })();
                    return (0, o.jsxs)("div", {
                        className: v().root,
                        children: [(0, o.jsx)(l.A, {
                            prefetch: !0,
                            ...p,
                            children: (0, o.jsx)(a.x, {
                                newClickOrigin: e,
                                children: (0, o.jsxs)(z.A, {
                                    height: 50,
                                    variant: "contained",
                                    className: v().fluidButton,
                                    children: [(0, o.jsx)(g.A, {
                                        name: "home"
                                    }), " ", (0, o.jsx)(i.x6, {
                                        id: "common.footer.goBackHome"
                                    })]
                                })
                            })
                        }), (0, o.jsxs)("div", {
                            className: v().orTryContainer,
                            children: [(0, o.jsx)(i.x6, {
                                id: "common.footer.orTry"
                            }), ":"]
                        }), (0, o.jsx)("div", {
                            className: (0, c.A)(v().gridContainer, !m && v().isMobile),
                            children: (0, o.jsx)(a.x, {
                                newClickOrigin: e,
                                children: m ? (0, o.jsx)(d.A, {
                                    games: G,
                                    justifyContent: "center"
                                }) : (0, o.jsx)(y.A, {
                                    games: G,
                                    expectedSize: 12
                                })
                            })
                        }), (0, o.jsx)("div", {
                            className: v().suggestionLinksWrapper,
                            children: (0, o.jsx)(w, {
                                clickOriginPrefix: e
                            })
                        })]
                    })
                })
        },
        86907: t => {
            t.exports = {
                czyButton: "GameGrid_czyButton__hezmb",
                "czyButton--contained--purple": "GameGrid_czyButton--contained--purple__9nnAG",
                "czyButton--contained--white": "GameGrid_czyButton--contained--white__pWTxf",
                "czyButton--contained--grey": "GameGrid_czyButton--contained--grey__K0Ve0",
                "czyButton--contained--warning": "GameGrid_czyButton--contained--warning__E7hEe",
                "czyButton--contained--alert": "GameGrid_czyButton--contained--alert__eVUcw",
                "czyButton--contained--success": "GameGrid_czyButton--contained--success__oe9zW",
                "czyButton--contained--black": "GameGrid_czyButton--contained--black__0MMcw",
                "czyButton--contained--green-gradient": "GameGrid_czyButton--contained--green-gradient__QQGvz",
                "czyButton--contained--animated-green-gradient": "GameGrid_czyButton--contained--animated-green-gradient__3rPgx",
                "scroll-gradient": "GameGrid_scroll-gradient__huYpq",
                "czyButton--outlined--purple": "GameGrid_czyButton--outlined--purple__YfVBB",
                "czyButton--link--purple": "GameGrid_czyButton--link--purple__p__rW",
                "czyButton--outlined--white": "GameGrid_czyButton--outlined--white___CitW",
                "czyButton--link--white": "GameGrid_czyButton--link--white__Je1SH",
                "czyButton--outlined--grey": "GameGrid_czyButton--outlined--grey__QCOrk",
                "czyButton--link--grey": "GameGrid_czyButton--link--grey__kVF9R",
                "czyButton--outlined--warning": "GameGrid_czyButton--outlined--warning__F7McC",
                "czyButton--link--warning": "GameGrid_czyButton--link--warning__X_XIi",
                "czyButton--outlined--alert": "GameGrid_czyButton--outlined--alert__AC5FN",
                "czyButton--link--alert": "GameGrid_czyButton--link--alert__BcGcr",
                "czyButton--outlined--success": "GameGrid_czyButton--outlined--success__XYkLe",
                "czyButton--link--success": "GameGrid_czyButton--link--success__GLGA8",
                "czyButton--outlined": "GameGrid_czyButton--outlined__MlmtF",
                "czyButton--disabled": "GameGrid_czyButton--disabled__QKe4B",
                "czyButton--height50": "GameGrid_czyButton--height50__hnNo1",
                "czyButton--height34": "GameGrid_czyButton--height34__Jx7io",
                "czyButton--height28": "GameGrid_czyButton--height28__TfeAA",
                "czyButton--fullWidth": "GameGrid_czyButton--fullWidth__tVUMs",
                "czyButton--headerIcon": "GameGrid_czyButton--headerIcon__xTym6",
                "czyButton--headerIcon--desktop": "GameGrid_czyButton--headerIcon--desktop__QCQ7v",
                "czyButton--headerIcon--mobile": "GameGrid_czyButton--headerIcon--mobile__LxSrQ",
                "czyButton--headerIcon--withLabel": "GameGrid_czyButton--headerIcon--withLabel__dcX_U",
                fullWidth: "GameGrid_fullWidth__UKlzK",
                fullWidthExperiment: "GameGrid_fullWidthExperiment__XtGaY",
                gameContainer: "GameGrid_gameContainer__2YwGl",
                contentVisibilityAuto: "GameGrid_contentVisibilityAuto__uqI1C",
                hasContainIntrinsicSize: "GameGrid_hasContainIntrinsicSize__JbOzK",
                fixedGameGridContainer: "GameGrid_fixedGameGridContainer__k4eyQ"
            }
        },
        95267: (t, e, n) => {
            "use strict";
            n.d(e, {
                t: () => a
            });
            var o = n(75155),
                r = n(81278),
                i = n(15911),
                c = n(23070);
            let a = () => {
                let t, e, n = (0, o.c)(8),
                    a = (0, r.useRouter)(),
                    u = (() => {
                        let t, e = (0, o.c)(2),
                            {
                                showOfflineOverlay: n
                            } = (0, c.H)();
                        return e[0] !== n ? (t = t => (n(t), !0), e[0] = n, e[1] = t) : t = e[1], t
                    })(),
                    _ = (0, i.Q)();
                n[0] !== a ? (t = () => {
                    let t = a.asPath;
                    a.push(`/offline?returnTo=${encodeURIComponent(t)}`)
                }, n[0] = a, n[1] = t) : t = n[1];
                let s = t;
                return n[2] !== _ || n[3] !== u || n[4] !== s || n[5] !== a.asPath || n[6] !== a.pathname ? (e = t => {
                    var e;
                    let n;
                    return e = _.current, n = !e, !((void 0 === t ? !n : !n || 404 !== t && t) || a.pathname.includes("/offline")) && (s(), !0)
                }, n[2] = _, n[3] = u, n[4] = s, n[5] = a.asPath, n[6] = a.pathname, n[7] = e) : e = n[7], e
            }
        }
    }
]);