! function() {
    try {
        var e = "u" > typeof window ? window : "u" > typeof global ? global : "u" > typeof globalThis ? globalThis : "u" > typeof self ? self : {};
        e._sentryModuleMetadata = e._sentryModuleMetadata || {}, e._sentryModuleMetadata[(new e.Error).stack] = function(e) {
            for (var t = 1; t < arguments.length; t++) {
                var n = arguments[t];
                if (null != n)
                    for (var r in n) n.hasOwnProperty(r) && (e[r] = n[r])
            }
            return e
        }({}, e._sentryModuleMetadata[(new e.Error).stack], {
            "_sentryBundlerPluginAppKey:crazygames-portal": !0
        });
        var t = (new e.Error).stack;
        t && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[t] = "871af64f-8b60-4e0d-9291-106f2d1f4262", e._sentryDebugIdIdentifier = "sentry-dbid-871af64f-8b60-4e0d-9291-106f2d1f4262")
    } catch (e) {}
}(), (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [11591, 76683, 85915], {
        10862: (e, t, n) => {
            "use strict";
            n.d(t, {
                Ff: () => c,
                oq: () => s,
                po: () => i
            });
            let r = null,
                o = new Set;

            function s(e) {
                return (null === r || r === e) && (r = e, !0)
            }

            function i(e) {
                r === e && (r = null, o.forEach(e => e()))
            }

            function c(e) {
                return o.add(e), () => {
                    o.delete(e)
                }
            }
        },
        11591: (e, t, n) => {
            "use strict";
            n.d(t, {
                A: () => d
            });
            var r = n(6029),
                o = n(75155);
            n(55729);
            var s = n(50212),
                i = n(56760),
                c = n(69386),
                l = n(85893),
                a = n(82026),
                u = n.n(a);
            let d = e => {
                let t, n, a, d, f = (0, o.c)(12),
                    {
                        open: _,
                        blurred: p,
                        onClose: m,
                        children: h,
                        className: y
                    } = e;
                if ((0, c.K)(_), !_) return null;
                let A = void 0 !== p && p && u().blurred;
                if (f[0] !== y || f[1] !== A ? (t = (0, s.A)(u().modal, A, y), f[0] = y, f[1] = A, f[2] = t) : t = f[2], f[3] !== m || f[4] !== _ ? (n = (0, r.jsx)(l.k, {
                        open: _,
                        onClick: m
                    }), f[3] = m, f[4] = _, f[5] = n) : n = f[5], f[6] !== h ? (a = (0, r.jsx)("div", {
                        className: u().modalContent,
                        children: h
                    }), f[6] = h, f[7] = a) : a = f[7], f[8] !== t || f[9] !== n || f[10] !== a) {
                    let e = (0, r.jsxs)("div", {
                        className: t,
                        children: [n, a]
                    });
                    d = (0, i.createPortal)(e, document.body), f[8] = t, f[9] = n, f[10] = a, f[11] = d
                } else d = f[11];
                return d
            }
        },
        17151: e => {
            e.exports = {
                czyButton: "AdFreeOfferSessionPrompt_czyButton__U4p1K",
                "czyButton--contained--purple": "AdFreeOfferSessionPrompt_czyButton--contained--purple__l1okn",
                "czyButton--contained--white": "AdFreeOfferSessionPrompt_czyButton--contained--white__fDcrY",
                "czyButton--contained--grey": "AdFreeOfferSessionPrompt_czyButton--contained--grey__pF1xd",
                "czyButton--contained--warning": "AdFreeOfferSessionPrompt_czyButton--contained--warning__gOdOT",
                "czyButton--contained--alert": "AdFreeOfferSessionPrompt_czyButton--contained--alert__1XZo0",
                "czyButton--contained--success": "AdFreeOfferSessionPrompt_czyButton--contained--success__TGlUH",
                "czyButton--contained--black": "AdFreeOfferSessionPrompt_czyButton--contained--black__7tNvO",
                "czyButton--contained--green-gradient": "AdFreeOfferSessionPrompt_czyButton--contained--green-gradient__hP_Ql",
                "czyButton--contained--animated-green-gradient": "AdFreeOfferSessionPrompt_czyButton--contained--animated-green-gradient__cR6Xx",
                "scroll-gradient": "AdFreeOfferSessionPrompt_scroll-gradient__TP9Jt",
                "czyButton--outlined--purple": "AdFreeOfferSessionPrompt_czyButton--outlined--purple__x5Zhq",
                "czyButton--link--purple": "AdFreeOfferSessionPrompt_czyButton--link--purple__ozEr9",
                "czyButton--outlined--white": "AdFreeOfferSessionPrompt_czyButton--outlined--white__w4pZN",
                "czyButton--link--white": "AdFreeOfferSessionPrompt_czyButton--link--white___oUS5",
                "czyButton--outlined--grey": "AdFreeOfferSessionPrompt_czyButton--outlined--grey___xKll",
                "czyButton--link--grey": "AdFreeOfferSessionPrompt_czyButton--link--grey__e8LZ3",
                "czyButton--outlined--warning": "AdFreeOfferSessionPrompt_czyButton--outlined--warning__rBBdc",
                "czyButton--link--warning": "AdFreeOfferSessionPrompt_czyButton--link--warning__cc_xz",
                "czyButton--outlined--alert": "AdFreeOfferSessionPrompt_czyButton--outlined--alert__t_gDH",
                "czyButton--link--alert": "AdFreeOfferSessionPrompt_czyButton--link--alert__JPXgB",
                "czyButton--outlined--success": "AdFreeOfferSessionPrompt_czyButton--outlined--success__hzVyv",
                "czyButton--link--success": "AdFreeOfferSessionPrompt_czyButton--link--success__KrX23",
                "czyButton--outlined": "AdFreeOfferSessionPrompt_czyButton--outlined__JaAoJ",
                "czyButton--disabled": "AdFreeOfferSessionPrompt_czyButton--disabled__gzufU",
                "czyButton--height50": "AdFreeOfferSessionPrompt_czyButton--height50__5ktLn",
                "czyButton--height34": "AdFreeOfferSessionPrompt_czyButton--height34__MWi_b",
                "czyButton--height28": "AdFreeOfferSessionPrompt_czyButton--height28__q7b3g",
                "czyButton--fullWidth": "AdFreeOfferSessionPrompt_czyButton--fullWidth__jzB24",
                "czyButton--headerIcon": "AdFreeOfferSessionPrompt_czyButton--headerIcon__ddI40",
                "czyButton--headerIcon--desktop": "AdFreeOfferSessionPrompt_czyButton--headerIcon--desktop__CfFVx",
                "czyButton--headerIcon--mobile": "AdFreeOfferSessionPrompt_czyButton--headerIcon--mobile__CMQTf",
                "czyButton--headerIcon--withLabel": "AdFreeOfferSessionPrompt_czyButton--headerIcon--withLabel__aHMuU",
                modalContainer: "AdFreeOfferSessionPrompt_modalContainer__iPx0K",
                prompt: "AdFreeOfferSessionPrompt_prompt__6rqNx",
                illustration: "AdFreeOfferSessionPrompt_illustration__3a1p_",
                copy: "AdFreeOfferSessionPrompt_copy__fS6WB",
                title: "AdFreeOfferSessionPrompt_title__fpsiT",
                description: "AdFreeOfferSessionPrompt_description__H9cEs",
                actions: "AdFreeOfferSessionPrompt_actions__qSn11",
                dontShowAgain: "AdFreeOfferSessionPrompt_dontShowAgain___UgLK"
            }
        },
        43461: (e, t, n) => {
            "use strict";
            n.d(t, {
                DO: () => S,
                Gr: () => w,
                HX: () => l,
                Lh: () => m,
                Mf: () => a,
                Nl: () => y,
                PQ: () => d,
                iS: () => A,
                sB: () => _,
                wR: () => F,
                zC: () => u
            });
            var r = n(11027),
                o = n(75651);
            let s = n(28478).A.LocalStorage,
                i = "czy_ad_free_offer_state",
                c = {
                    promptShownAt: [],
                    promptShownInSession: null,
                    promptDontShowAgain: !1,
                    preAdShownAt: [],
                    preAdDontShowAgain: !1,
                    offerOpened: !1
                };

            function l() {
                return window.location.search.includes("forceAdFreeSessionPrompt")
            }

            function a() {
                return window.location.search.includes("forceAdFreePreAdMessage")
            }

            function u(e) {
                return (0, o.B5)(e) || (0, o.pC)(e) || e === r.kl3.isoCode
            }

            function d(e, t, n) {
                if (e.offerOpened || e.promptDontShowAgain || e.promptShownAt.length >= 3) return !1;
                if (null === e.promptShownInSession) return t >= 5;
                let r = Math.max(...e.promptShownAt);
                return t - e.promptShownInSession >= 5 && n - r >= 864e5
            }

            function f(e, t) {
                return e.filter(e => t - e < 6048e5)
            }

            function _(e, t, n) {
                return !e.offerOpened && !e.preAdDontShowAgain && !t && f(e.preAdShownAt, n).length < 3
            }

            function p(e) {
                return Array.isArray(e) ? e.filter(Number.isFinite) : []
            }

            function m() {
                try {
                    let e = JSON.parse(s.getItem(i) || "{}");
                    return {
                        promptShownAt: p(e.promptShownAt),
                        promptShownInSession: Number.isFinite(e.promptShownInSession) ? e.promptShownInSession : null,
                        promptDontShowAgain: !0 === e.promptDontShowAgain,
                        preAdShownAt: p(e.preAdShownAt),
                        preAdDontShowAgain: !0 === e.preAdDontShowAgain,
                        offerOpened: !0 === e.offerOpened
                    }
                } catch {
                    return c
                }
            }

            function h(e) {
                s.setItem(i, JSON.stringify({ ...m(),
                    ...e
                }))
            }

            function y(e, t) {
                h({
                    promptShownAt: [...m().promptShownAt, t],
                    promptShownInSession: e
                })
            }

            function A() {
                h({
                    promptDontShowAgain: !0
                })
            }

            function F(e) {
                h({
                    preAdShownAt: [...f(m().preAdShownAt, e), e]
                })
            }

            function S() {
                h({
                    preAdDontShowAgain: !0
                })
            }

            function w() {
                h({
                    offerOpened: !0
                })
            }
        },
        45364: (e, t, n) => {
            "use strict";
            n.d(t, {
                A: () => o
            });
            class r {
                removeFullscreenListener(e) {
                    this.eventKeys.forEach(t => {
                        document.removeEventListener(t, e)
                    })
                }
                addFullscreenListener(e) {
                    this.eventKeys.forEach(t => {
                        document.addEventListener(t, e)
                    })
                }
                addFakeFullscreenListener(e) {
                    this.fakeFullscreenListeners.push(e)
                }
                removeFakeFullscreenListener(e) {
                    this.fakeFullscreenListeners = this.fakeFullscreenListeners.filter(t => t !== e)
                }
                isFullscreen() {
                    let e = window.document;
                    return !!(e.fullscreenElement || e.mozFullScreenElement || e.webkitFullscreenElement || e.msFullscreenElement)
                }
                isFakeFullscreen() {
                    return this.isInFakeFullscreen
                }
                enteredFakeFullscreen() {
                    this.isInFakeFullscreen || (this.isInFakeFullscreen = !0, this.fakeFullscreenListeners.forEach(e => e()))
                }
                exitFakeFullscreen() {
                    this.isInFakeFullscreen && (this.isInFakeFullscreen = !1, this.fakeFullscreenListeners.forEach(e => e()))
                }
                exitNativeFullscreen() {
                    let e = window.document,
                        t = e.exitFullscreen || e.mozCancelFullScreen || e.webkitExitFullscreen || e.msExitFullscreen;
                    return !!t && (window.document.fullscreenElement && t.call(e), !0)
                }
                constructor() {
                    this.fakeFullscreenListeners = [], this.eventKeys = ["fullscreenchange", "webkitfullscreenchange", "mozfullscreenchange", "MSFullscreenChange"], this.isInFakeFullscreen = !1, this.forceLockOrientation = async (e, t) => {
                        if (!t || "BOTH" === t || !("screen" in window) || !window.screen || !window.screen.orientation || !window.screen.orientation.lock) return;
                        let n = null;
                        try {
                            await Promise.race([window.screen.orientation.lock("PORTRAIT" === t ? "portrait" : "landscape"), new Promise((t, r) => {
                                n = setTimeout(() => {
                                    e.trackGenericError("timeoutError", {
                                        message: "Error in orientation lock timeout"
                                    }), r(Error("Orientation lock timeout"))
                                }, 1e3)
                            })])
                        } catch (e) {} finally {
                            n && clearTimeout(n)
                        }
                    }
                }
            }
            let o = new r
        },
        76683: (e, t, n) => {
            "use strict";
            n.r(t), n.d(t, {
                default: () => P
            });
            var r = n(6029),
                o = n(75155),
                s = n(55729),
                i = n(97324),
                c = n(77650),
                l = n(79942),
                a = n(71024),
                u = n.n(a),
                d = n(71855),
                f = n(81930),
                _ = n(83576),
                p = n(11591),
                m = n(4230),
                h = n(50293),
                y = n(14886),
                A = n(45364),
                F = n(71684),
                S = n(10862),
                w = n(43461),
                g = n(56919);
            let z = "ad-free-session-prompt",
                B = !1;

            function k() {
                return (0, S.po)(z)
            }
            var O = n(17151),
                x = n.n(O);
            let b = u()(() => Promise.all([n.e(61019), n.e(16688), n.e(28930)]).then(n.bind(n, 28930)), {
                    loadableGenerated: {
                        webpack: () => [28930]
                    },
                    loading: () => null,
                    ssr: !1
                }),
                P = () => {
                    let e, t, n, a, u, O, P, C, v, I, E, L, N, j, D, M = (0, o.c)(31),
                        T = (0, d.U)("czyExpClientAdFree_CZY_21530"),
                        K = "disabled" === T ? null : T,
                        {
                            promptOpen: R,
                            offerOpen: H,
                            onGoAdFree: U,
                            onDismiss: q,
                            onOfferClose: J
                        } = function(e) {
                            let t, n, r, i, c, l, a, u, d, f, _, p = (0, o.c)(25),
                                {
                                    loadingUser: O
                                } = s.useContext(y.R),
                                {
                                    crazyAnalyticsService: x
                                } = s.useContext(F.A).services,
                                b = s.useContext(m.A),
                                P = (0, g.Q)(e, "session_prompt"),
                                [C, v] = s.useState(!1),
                                [I, E] = s.useState(!1),
                                L = s.useRef(!1);
                            p[0] !== b ? (t = (0, h.Fr)(b), p[0] = b, p[1] = t) : t = p[1];
                            let N = t;
                            p[2] !== x || p[3] !== N || p[4] !== O || p[5] !== e ? (n = () => {
                                if (!e || O) return;
                                let t = !1,
                                    n = null,
                                    r = window.matchMedia("(orientation: landscape)"),
                                    o = () => {
                                        t || null === n || N && r.matches || !(A.A.isFullscreen() || A.A.isFakeFullscreen()) && (0, S.oq)(z) && ((0, w.Nl)(n, Date.now()), n = null, v(!0))
                                    };
                                if (!B) {
                                    B = !0;
                                    let e = x.getSessionCount();
                                    ((0, w.HX)() || (0, w.PQ)((0, w.Lh)(), e, Date.now())) && (n = e, o())
                                }
                                A.A.addFullscreenListener(o), A.A.addFakeFullscreenListener(o);
                                let s = (0, S.Ff)(o);
                                return () => {
                                    t = !0, A.A.removeFullscreenListener(o), A.A.removeFakeFullscreenListener(o), s()
                                }
                            }, r = [e, O, x, N], p[2] = x, p[3] = N, p[4] = O, p[5] = e, p[6] = n, p[7] = r) : (n = p[6], r = p[7]), s.useEffect(n, r), p[8] !== C ? (i = () => {
                                if (C) return k
                            }, c = [C], p[8] = C, p[9] = i, p[10] = c) : (i = p[9], c = p[10]), s.useEffect(i, c), p[11] !== C || p[12] !== P ? (l = () => {
                                C && !L.current && (L.current = !0, P("shown", "entry_point"))
                            }, a = [C, P], p[11] = C, p[12] = P, p[13] = l, p[14] = a) : (l = p[13], a = p[14]), s.useEffect(l, a), p[15] !== P ? (u = () => {
                                P("clicked", "entry_point"), v(!1), E(!0)
                            }, p[15] = P, p[16] = u) : u = p[16];
                            let j = u;
                            p[17] !== P ? (d = e => {
                                e && (0, w.iS)(), P("closed", e ? "dont_show_again" : "ignore"), v(!1)
                            }, p[17] = P, p[18] = d) : d = p[18];
                            let D = d;
                            return p[19] === Symbol.for("react.memo_cache_sentinel") ? (f = () => E(!1), p[19] = f) : f = p[19], p[20] !== I || p[21] !== D || p[22] !== j || p[23] !== C ? (_ = {
                                promptOpen: C,
                                offerOpen: I,
                                onGoAdFree: j,
                                onDismiss: D,
                                onOfferClose: f
                            }, p[20] = I, p[21] = D, p[22] = j, p[23] = C, p[24] = _) : _ = p[24], _
                        }(K),
                        [X, Q] = s.useState(!1);
                    if (H && K) {
                        let e;
                        return M[0] !== J || M[1] !== K ? (e = (0, r.jsx)(b, {
                            variant: K,
                            entryPoint: "session_prompt",
                            onClose: J
                        }), M[0] = J, M[1] = K, M[2] = e) : e = M[2], e
                    }
                    if (!R) return null;
                    M[3] !== X || M[4] !== q ? (e = () => q(X), M[3] = X, M[4] = q, M[5] = e) : e = M[5];
                    let W = e;
                    return M[6] === Symbol.for("react.memo_cache_sentinel") ? (t = (0, r.jsx)("img", {
                        className: x().illustration,
                        src: (0, f.Ay)("ad-free-offer.png", {
                            width: 400
                        }),
                        alt: ""
                    }), M[6] = t) : t = M[6], M[7] === Symbol.for("react.memo_cache_sentinel") ? (n = (0, r.jsx)("h2", {
                        className: x().title,
                        children: (0, r.jsx)(l.x6, {
                            id: "common.adFreeOffer.title"
                        })
                    }), M[7] = n) : n = M[7], M[8] === Symbol.for("react.memo_cache_sentinel") ? (a = (0, r.jsxs)("div", {
                        className: x().copy,
                        children: [n, (0, r.jsx)("p", {
                            className: x().description,
                            children: (0, r.jsx)(l.x6, {
                                id: "common.adFreeOffer.prompt.description"
                            })
                        })]
                    }), M[8] = a) : a = M[8], M[9] === Symbol.for("react.memo_cache_sentinel") ? (u = c.Ru._("common.adFreeOffer.prompt.goAdFree"), M[9] = u) : u = M[9], M[10] !== U ? (O = (0, r.jsx)(i.$, {
                        label: u,
                        size: "m",
                        tone: "white",
                        onClick: U
                    }), M[10] = U, M[11] = O) : O = M[11], M[12] === Symbol.for("react.memo_cache_sentinel") ? (P = c.Ru._("common.adFreeOffer.prompt.ignore"), M[12] = P) : P = M[12], M[13] !== W ? (C = (0, r.jsx)(i.$, {
                        label: P,
                        size: "m",
                        tone: "alphaWhite",
                        onClick: W
                    }), M[13] = W, M[14] = C) : C = M[14], M[15] !== O || M[16] !== C ? (v = (0, r.jsxs)("div", {
                        className: x().actions,
                        children: [O, C]
                    }), M[15] = O, M[16] = C, M[17] = v) : v = M[17], M[18] === Symbol.for("react.memo_cache_sentinel") ? (I = e => Q(e.target.checked), M[18] = I) : I = M[18], M[19] !== X ? (E = (0, r.jsx)(_.A, {
                        checked: X,
                        onChange: I
                    }), M[19] = X, M[20] = E) : E = M[20], M[21] === Symbol.for("react.memo_cache_sentinel") ? (L = (0, r.jsx)(l.x6, {
                        id: "common.adFreeOffer.prompt.dontShowAgain"
                    }), M[21] = L) : L = M[21], M[22] !== E ? (N = (0, r.jsxs)("label", {
                        className: x().dontShowAgain,
                        children: [E, L]
                    }), M[22] = E, M[23] = N) : N = M[23], M[24] !== t || M[25] !== N || M[26] !== v ? (j = (0, r.jsxs)("section", {
                        className: x().prompt,
                        children: [t, a, v, N]
                    }), M[24] = t, M[25] = N, M[26] = v, M[27] = j) : j = M[27], M[28] !== W || M[29] !== j ? (D = (0, r.jsx)(p.A, {
                        open: !0,
                        blurred: !0,
                        onClose: W,
                        className: x().modalContainer,
                        children: j
                    }), M[28] = W, M[29] = j, M[30] = D) : D = M[30], D
                }
        },
        82880: e => {
            e.exports = {
                root: "Checkbox_root__P7HDL",
                input: "Checkbox_input__8xpFL",
                icon: "Checkbox_icon__cfxCj",
                box: "Checkbox_box__nLxYz",
                check: "Checkbox_check__cU8Bn",
                success: "Checkbox_success__rmjwK"
            }
        },
        83576: (e, t, n) => {
            "use strict";
            n.d(t, {
                A: () => a
            });
            var r = n(6029),
                o = n(55729),
                s = n(50212),
                i = n(82880),
                c = n.n(i);
            let l = o.forwardRef((e, t) => {
                let {
                    className: n,
                    color: o = "default",
                    ...i
                } = e;
                return (0, r.jsxs)("span", {
                    className: (0, s.A)(c().root, c()[o]),
                    children: [(0, r.jsx)("input", {
                        ref: t,
                        type: "checkbox",
                        className: (0, s.A)(c().input, n),
                        ...i
                    }), (0, r.jsxs)("svg", {
                        className: c().icon,
                        viewBox: "0 0 24 24",
                        "aria-hidden": "true",
                        children: [(0, r.jsx)("rect", {
                            x: "3.5",
                            y: "3.5",
                            width: "17",
                            height: "17",
                            rx: "3",
                            className: c().box
                        }), (0, r.jsx)("path", {
                            d: "M7 12.5l3 3 7-7",
                            className: c().check
                        })]
                    })]
                })
            });
            l.displayName = "Checkbox";
            let a = l
        }
    }
]);