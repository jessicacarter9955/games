! function() {
    try {
        var e = "u" > typeof window ? window : "u" > typeof global ? global : "u" > typeof globalThis ? globalThis : "u" > typeof self ? self : {};
        e._sentryModuleMetadata = e._sentryModuleMetadata || {}, e._sentryModuleMetadata[(new e.Error).stack] = function(e) {
            for (var n = 1; n < arguments.length; n++) {
                var t = arguments[n];
                if (null != t)
                    for (var s in t) t.hasOwnProperty(s) && (e[s] = t[s])
            }
            return e
        }({}, e._sentryModuleMetadata[(new e.Error).stack], {
            "_sentryBundlerPluginAppKey:crazygames-portal": !0
        });
        var n = (new e.Error).stack;
        n && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[n] = "23c43f9c-afa8-4428-ad36-046f76c828fd", e._sentryDebugIdIdentifier = "sentry-dbid-23c43f9c-afa8-4428-ad36-046f76c828fd")
    } catch (e) {}
}(), (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [54135], {
        10862: (e, n, t) => {
            "use strict";
            t.d(n, {
                Ff: () => a,
                oq: () => i,
                po: () => l
            });
            let s = null,
                r = new Set;

            function i(e) {
                return (null === s || s === e) && (s = e, !0)
            }

            function l(e) {
                s === e && (s = null, r.forEach(e => e()))
            }

            function a(e) {
                return r.add(e), () => {
                    r.delete(e)
                }
            }
        },
        28967: (e, n, t) => {
            "use strict";
            t.d(n, {
                A: () => l
            });
            var s = t(50293),
                r = t(51159),
                i = t(45364);
            let l = async function(e) {
                let n = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
                    l = arguments.length > 2 && void 0 !== arguments[2] && arguments[2],
                    a = arguments.length > 3 && void 0 !== arguments[3] && arguments[3];
                if (i.A.isFullscreen() && !a || (0, s.Kg)(e)) return;
                let o = await t.e(74461).then(t.bind(t, 74461)),
                    c = o.default || o,
                    u = c.create(void 0, {
                        resize: !0,
                        useWorker: !0
                    });
                if (l && !n) {
                    let e = ["#FF6B1A", "#9D4EDD", "#000000", "#FFA500"],
                        n = c.shapeFromPath({
                            path: "M0 -10 L2.5 -2.5 L10 0 L2.5 2.5 L0 10 L-2.5 2.5 L-10 0 L-2.5 -2.5 Z"
                        }),
                        t = c.shapeFromPath({
                            path: "M0 -8 C-4 -8 -6 -6 -6 -2 L-6 6 L-4 4 L-2 6 L0 4 L2 6 L4 4 L6 6 L6 -2 C6 -6 4 -8 0 -8 Z"
                        }),
                        s = c.shapeFromPath({
                            path: "M0 0 L-2 -2 C-4 -3 -6 -2 -8 0 C-6 1 -5 2 -3 2 L-1 1 L-1 3 L1 3 L1 1 L3 2 C5 2 6 1 8 0 C6 -2 4 -3 2 -2 Z"
                        });
                    u({
                        particleCount: 80,
                        angle: 60,
                        spread: 70,
                        origin: {
                            x: 0
                        },
                        colors: e,
                        shapes: [n, t, s],
                        scalar: 1.2,
                        zIndex: 1405
                    }), u({
                        particleCount: 80,
                        angle: 120,
                        spread: 70,
                        origin: {
                            x: 1
                        },
                        colors: e,
                        shapes: [n, t, s],
                        scalar: 1.2,
                        zIndex: 1405
                    })
                } else if (n) {
                    let e = c.shapeFromText({
                        text: "\uD83C\uDFC6",
                        scalar: 5
                    });
                    u({
                        particleCount: 30,
                        spread: 130,
                        origin: {
                            x: 0
                        },
                        shapes: [e],
                        scalar: 5,
                        zIndex: 1405
                    }), u({
                        particleCount: 30,
                        spread: 130,
                        origin: {
                            x: 1
                        },
                        shapes: [e],
                        scalar: 5,
                        zIndex: 1405
                    })
                } else u({
                    particleCount: 100,
                    angle: 60,
                    spread: 65,
                    origin: {
                        x: 0
                    },
                    colors: r.x,
                    zIndex: 1405
                }), u({
                    particleCount: 100,
                    angle: 120,
                    spread: 65,
                    origin: {
                        x: 1
                    },
                    colors: r.x,
                    zIndex: 1405
                })
            }
        },
        34489: e => {
            e.exports = {
                aboveBottomNavigation: "CelebrationNudge_aboveBottomNavigation__Ow1_a"
            }
        },
        45364: (e, n, t) => {
            "use strict";
            t.d(n, {
                A: () => r
            });
            class s {
                removeFullscreenListener(e) {
                    this.eventKeys.forEach(n => {
                        document.removeEventListener(n, e)
                    })
                }
                addFullscreenListener(e) {
                    this.eventKeys.forEach(n => {
                        document.addEventListener(n, e)
                    })
                }
                addFakeFullscreenListener(e) {
                    this.fakeFullscreenListeners.push(e)
                }
                removeFakeFullscreenListener(e) {
                    this.fakeFullscreenListeners = this.fakeFullscreenListeners.filter(n => n !== e)
                }
                isFullscreen() {
                    let e = window.document;
                    return !!(e.fullscreenElement || e.mozFullScreenElement || e.webkitFullscreenElement || e.msFullscreenElement)
                }
                isFakeFullscreen() {
                    return this.isInFakeFullscreen
                }
                enteredFakeFullscreen() {
                    this.isInFakeFullscreen || (this.isInFakeFullscreen = !0, this.fakeFullscreenListeners.forEach(e => e()))
                }
                exitFakeFullscreen() {
                    this.isInFakeFullscreen && (this.isInFakeFullscreen = !1, this.fakeFullscreenListeners.forEach(e => e()))
                }
                exitNativeFullscreen() {
                    let e = window.document,
                        n = e.exitFullscreen || e.mozCancelFullScreen || e.webkitExitFullscreen || e.msExitFullscreen;
                    return !!n && (window.document.fullscreenElement && n.call(e), !0)
                }
                constructor() {
                    this.fakeFullscreenListeners = [], this.eventKeys = ["fullscreenchange", "webkitfullscreenchange", "mozfullscreenchange", "MSFullscreenChange"], this.isInFakeFullscreen = !1, this.forceLockOrientation = async (e, n) => {
                        if (!n || "BOTH" === n || !("screen" in window) || !window.screen || !window.screen.orientation || !window.screen.orientation.lock) return;
                        let t = null;
                        try {
                            await Promise.race([window.screen.orientation.lock("PORTRAIT" === n ? "portrait" : "landscape"), new Promise((n, s) => {
                                t = setTimeout(() => {
                                    e.trackGenericError("timeoutError", {
                                        message: "Error in orientation lock timeout"
                                    }), s(Error("Orientation lock timeout"))
                                }, 1e3)
                            })])
                        } catch (e) {} finally {
                            t && clearTimeout(t)
                        }
                    }
                }
            }
            let r = new s
        },
        54135: (e, n, t) => {
            "use strict";
            t.r(n), t.d(n, {
                default: () => b
            });
            var s = t(6029),
                r = t(75155),
                i = t(55729),
                l = t(77650),
                a = t(79942),
                o = t(8023),
                c = t(54944),
                u = t(4230),
                d = t(45364),
                g = t(28967),
                m = t(71684),
                h = t(10862),
                _ = t(74021),
                y = t(3540);
            let f = {
                birthday: "birthday-nudge",
                anniversary: "anniversary-nudge"
            };

            function v(e) {
                console.error(e)
            }
            var x = t(34489),
                F = t.n(x);
            let b = () => {
                let e, n, t, x, b, w = (0, r.c)(14),
                    {
                        open: p,
                        occasion: N,
                        years: L,
                        username: k,
                        onAction: E,
                        onClose: A
                    } = function() {
                        let e, n, t, s, l, a, o, c = (0, r.c)(24),
                            {
                                occasion: x,
                                forced: F,
                                years: b,
                                username: w,
                                userId: p
                            } = (0, y.v)(),
                            {
                                crazyAnalyticsService: N
                            } = i.useContext(m.A).services,
                            L = i.useContext(u.A),
                            [k, E] = i.useState(!1),
                            A = i.useRef(!1);
                        k && !x && E(!1), c[0] !== N || c[1] !== L || c[2] !== F || c[3] !== x || c[4] !== p ? (e = () => {
                            if (!x) return;
                            let e = f[x],
                                n = !1,
                                t = () => {
                                    !n || A.current || !p || !F && (0, _.Am)(x, p, new Date) || !(d.A.isFullscreen() || d.A.isFakeFullscreen()) && (0, h.oq)(e) && (A.current = !0, (0, _.Lx)(x, p, new Date), E(!0), N.notificationActionEvent(e, "shown"), (0, g.A)(L).catch(v))
                                },
                                s = window.setTimeout(() => {
                                    n = !0, t()
                                }, F ? 0 : _.Yr);
                            d.A.addFullscreenListener(t), d.A.addFakeFullscreenListener(t);
                            let r = (0, h.Ff)(t);
                            return () => {
                                window.clearTimeout(s), d.A.removeFullscreenListener(t), d.A.removeFakeFullscreenListener(t), r()
                            }
                        }, n = [x, F, N, L, p], c[0] = N, c[1] = L, c[2] = F, c[3] = x, c[4] = p, c[5] = e, c[6] = n) : (e = c[5], n = c[6]), i.useEffect(e, n), c[7] !== x || c[8] !== k ? (t = () => {
                            if (!k || !x) return;
                            let e = f[x];
                            return () => (0, h.po)(e)
                        }, s = [k, x], c[7] = x, c[8] = k, c[9] = t, c[10] = s) : (t = c[9], s = c[10]), i.useEffect(t, s), c[11] !== N || c[12] !== x ? (l = () => {
                            x && N.notificationActionEvent(f[x], "clicked"), E(!1)
                        }, c[11] = N, c[12] = x, c[13] = l) : l = c[13];
                        let C = l;
                        c[14] !== N || c[15] !== x ? (a = e => {
                            x && N.notificationActionEvent(f[x], "timeout" === e ? "ignored" : "closed"), E(!1)
                        }, c[14] = N, c[15] = x, c[16] = a) : a = c[16];
                        let I = a;
                        return c[17] !== x || c[18] !== C || c[19] !== I || c[20] !== k || c[21] !== w || c[22] !== b ? (o = {
                            open: k,
                            occasion: x,
                            years: b,
                            username: w,
                            onAction: C,
                            onClose: I
                        }, c[17] = x, c[18] = C, c[19] = I, c[20] = k, c[21] = w, c[22] = b, c[23] = o) : o = c[23], o
                    }(),
                    C = (0, o.d)(),
                    I = "anniversary" === N;
                w[0] !== I || w[1] !== k || w[2] !== L ? (e = I ? (0, s.jsx)(a.x6, {
                    id: "common.celebrationNudge.anniversary.title",
                    values: {
                        username: k,
                        years: L
                    }
                }) : (0, s.jsxs)(s.Fragment, {
                    children: [(0, s.jsx)(a.x6, {
                        id: "common.celebrationNudge.birthday.title"
                    }), "\xa0\uD83C\uDF89"]
                }), n = I ? (0, s.jsx)(a.x6, {
                    id: "common.celebrationNudge.anniversary.body",
                    values: {
                        username: k,
                        years: L
                    }
                }) : (0, s.jsx)(a.x6, {
                    id: "common.celebrationNudge.birthday.body",
                    values: {
                        username: k
                    }
                }), w[0] = I, w[1] = k, w[2] = L, w[3] = e, w[4] = n) : (e = w[3], n = w[4]), w[5] === Symbol.for("react.memo_cache_sentinel") ? (t = (0, s.jsx)(a.x6, {
                    id: "common.celebrationNudge.action"
                }), w[5] = t) : t = w[5], w[6] === Symbol.for("react.memo_cache_sentinel") ? (x = l.Ru._("common.celebrationNudge.close"), w[6] = x) : x = w[6];
                let j = C ? F().aboveBottomNavigation : void 0;
                return w[7] !== E || w[8] !== A || w[9] !== p || w[10] !== e || w[11] !== n || w[12] !== j ? (b = (0, s.jsx)(c.A, {
                    open: p,
                    title: e,
                    body: n,
                    actionLabel: t,
                    actionIcon: "play-triangle",
                    closeLabel: x,
                    className: j,
                    onAction: E,
                    onClose: A
                }), w[7] = E, w[8] = A, w[9] = p, w[10] = e, w[11] = n, w[12] = j, w[13] = b) : b = w[13], b
            }
        },
        54944: (e, n, t) => {
            "use strict";
            t.d(n, {
                A: () => m
            });
            var s = t(6029),
                r = t(75155),
                i = t(55729),
                l = t(50212),
                a = t(56760),
                o = t(81930),
                c = t(93800),
                u = t(95848),
                d = t.n(u);
            let g = "crazygames/ziggy_nudge3x.png",
                m = e => {
                    let n, t, u, m, h, _, y, f, v, x, F, b, w, p, N, L, k, E, A, C = (0, r.c)(48),
                        {
                            open: I,
                            title: j,
                            body: Z,
                            actionLabel: z,
                            actionIcon: S,
                            closeLabel: M,
                            autoCloseMs: T,
                            className: B,
                            onAction: D,
                            onClose: P
                        } = e,
                        O = i.useId(),
                        [R, q] = i.useState(I),
                        [H, K] = i.useState(I);
                    if (I !== H && (K(I), I && q(!0)), C[0] !== I ? (n = () => {
                            if (I) return;
                            let e = window.setTimeout(() => q(!1), 200);
                            return () => window.clearTimeout(e)
                        }, t = [I], C[0] = I, C[1] = n, C[2] = t) : (n = C[1], t = C[2]), i.useEffect(n, t), !R || "u" < typeof document) return null;
                    let V = !I && d().leaving;
                    C[3] !== B || C[4] !== V ? (u = (0, l.A)(d().nudge, V, B), C[3] = B, C[4] = V, C[5] = u) : u = C[5];
                    let G = `${void 0===T?2e4:T}ms`;
                    C[6] !== G ? (m = {
                        "--nudge-auto-close-duration": G,
                        "--nudge-transition-duration": "200ms"
                    }, C[6] = G, C[7] = m) : m = C[7];
                    let W = m;
                    return C[8] !== j || C[9] !== O ? (h = (0, s.jsx)("div", {
                        id: O,
                        className: d().title,
                        children: j
                    }), C[8] = j, C[9] = O, C[10] = h) : h = C[10], C[11] !== Z ? (_ = (0, s.jsx)("div", {
                        className: d().body,
                        children: Z
                    }), C[11] = Z, C[12] = _) : _ = C[12], C[13] !== _ || C[14] !== h ? (y = (0, s.jsxs)("div", {
                        className: d().text,
                        children: [h, _]
                    }), C[13] = _, C[14] = h, C[15] = y) : y = C[15], C[16] !== S ? (f = S && (0, s.jsx)(c.A, {
                        name: S,
                        size: 20
                    }), C[16] = S, C[17] = f) : f = C[17], C[18] !== z ? (v = (0, s.jsx)("span", {
                        children: z
                    }), C[18] = z, C[19] = v) : v = C[19], C[20] !== D || C[21] !== f || C[22] !== v ? (x = (0, s.jsxs)("button", {
                        type: "button",
                        className: d().action,
                        onClick: D,
                        children: [f, v]
                    }), C[20] = D, C[21] = f, C[22] = v, C[23] = x) : x = C[23], C[24] !== y || C[25] !== x ? (F = (0, s.jsxs)("div", {
                        className: d().bubble,
                        children: [y, x]
                    }), C[24] = y, C[25] = x, C[26] = F) : F = C[26], C[27] === Symbol.for("react.memo_cache_sentinel") ? (b = (0, s.jsx)("svg", {
                        className: d().tail,
                        width: "26",
                        height: "13",
                        viewBox: "0 0 25.7783 12.9639",
                        "aria-hidden": !0,
                        children: (0, s.jsx)("path", {
                            d: "M25.7783 0C22.7099 4.3149 16.3804 12.13 12.9082 12.9531V12.9629C12.902 12.9615 12.8959 12.9594 12.8896 12.958C12.8821 12.9597 12.8747 12.9622 12.8672 12.9639V12.9521C9.39437 12.1253 3.06752 4.31366 0 0H25.7783Z"
                        })
                    }), C[27] = b) : b = C[27], C[28] !== F ? (w = (0, s.jsxs)("div", {
                        className: d().speech,
                        children: [F, b]
                    }), C[28] = F, C[29] = w) : w = C[29], C[30] !== P ? (p = () => P("dismissed"), C[30] = P, C[31] = p) : p = C[31], C[32] !== P || C[33] !== I ? (N = (0, s.jsx)("svg", {
                        className: d().countdown,
                        viewBox: "0 0 30 30",
                        "aria-hidden": !0,
                        children: (0, s.jsx)("circle", {
                            className: d().countdownRing,
                            cx: "15",
                            cy: "15",
                            r: "12",
                            pathLength: 100,
                            onAnimationEnd: () => {
                                I && P("timeout")
                            }
                        })
                    }), C[32] = P, C[33] = I, C[34] = N) : N = C[34], C[35] === Symbol.for("react.memo_cache_sentinel") ? (L = (0, s.jsx)(c.A, {
                        name: "close",
                        className: d().closeIcon
                    }), C[35] = L) : L = C[35], C[36] !== M || C[37] !== p || C[38] !== N ? (k = (0, s.jsxs)("button", {
                        type: "button",
                        className: d().close,
                        "aria-label": M,
                        onClick: p,
                        children: [N, L]
                    }), C[36] = M, C[37] = p, C[38] = N, C[39] = k) : k = C[39], C[40] === Symbol.for("react.memo_cache_sentinel") ? (E = (0, s.jsx)("img", {
                        className: d().ziggy,
                        src: (0, o.Ay)(g, {
                            width: 153
                        }),
                        srcSet: (0, o.Wn)(g, {
                            width: 153
                        }),
                        width: 153,
                        height: 111,
                        alt: ""
                    }), C[40] = E) : E = C[40], C[41] !== w || C[42] !== k || C[43] !== E || C[44] !== u || C[45] !== W || C[46] !== O ? (A = (0, a.createPortal)((0, s.jsxs)("div", {
                        className: u,
                        role: "dialog",
                        "aria-labelledby": O,
                        style: W,
                        children: [w, k, E]
                    }), document.body), C[41] = w, C[42] = k, C[43] = E, C[44] = u, C[45] = W, C[46] = O, C[47] = A) : A = C[47], A
                }
        },
        95848: e => {
            e.exports = {
                nudge: "ZiggyNudge_nudge__Hr6EJ",
                "nudge-enter": "ZiggyNudge_nudge-enter__e1VRF",
                leaving: "ZiggyNudge_leaving__s_TOI",
                "nudge-leave": "ZiggyNudge_nudge-leave__7qVlB",
                speech: "ZiggyNudge_speech___HOo3",
                bubble: "ZiggyNudge_bubble__ES82b",
                text: "ZiggyNudge_text__Ee_LI",
                title: "ZiggyNudge_title__NaEz3",
                body: "ZiggyNudge_body__ZgC_6",
                action: "ZiggyNudge_action__dgUoI",
                tail: "ZiggyNudge_tail__fibSq",
                close: "ZiggyNudge_close__xqem1",
                closeIcon: "ZiggyNudge_closeIcon__HNDZu",
                countdown: "ZiggyNudge_countdown__a6rBS",
                countdownRing: "ZiggyNudge_countdownRing__gB_vQ",
                "nudge-countdown": "ZiggyNudge_nudge-countdown__SEeGv",
                ziggy: "ZiggyNudge_ziggy__vp6ly"
            }
        }
    }
]);