! function() {
    try {
        var e = "u" > typeof window ? window : "u" > typeof global ? global : "u" > typeof globalThis ? globalThis : "u" > typeof self ? self : {};
        e._sentryModuleMetadata = e._sentryModuleMetadata || {}, e._sentryModuleMetadata[(new e.Error).stack] = function(e) {
            for (var t = 1; t < arguments.length; t++) {
                var r = arguments[t];
                if (null != r)
                    for (var n in r) r.hasOwnProperty(n) && (e[n] = r[n])
            }
            return e
        }({}, e._sentryModuleMetadata[(new e.Error).stack], {
            "_sentryBundlerPluginAppKey:crazygames-portal": !0
        });
        var t = (new e.Error).stack;
        t && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[t] = "43f819c2-e492-4bc1-ac23-d7e8cb1734c0", e._sentryDebugIdIdentifier = "sentry-dbid-43f819c2-e492-4bc1-ac23-d7e8cb1734c0")
    } catch (e) {}
}();
"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [14434], {
        11286: (e, t, r) => {
            let n, i, a;
            r.d(t, {
                MF: () => N,
                j6: () => M,
                xZ: () => k,
                om: () => B,
                Sx: () => H,
                Wp: () => x,
                KO: () => W
            });
            var s = r(68381),
                o = r(42402),
                l = r(23390);
            let c = new WeakMap,
                h = new WeakMap,
                d = new WeakMap,
                u = new WeakMap,
                p = new WeakMap,
                f = {
                    get(e, t, r) {
                        if (e instanceof IDBTransaction) {
                            if ("done" === t) return h.get(e);
                            if ("objectStoreNames" === t) return e.objectStoreNames || d.get(e);
                            if ("store" === t) return r.objectStoreNames[1] ? void 0 : r.objectStore(r.objectStoreNames[0])
                        }
                        return g(e[t])
                    },
                    set: (e, t, r) => (e[t] = r, !0),
                    has: (e, t) => e instanceof IDBTransaction && ("done" === t || "store" === t) || t in e
                };

            function g(e) {
                if (e instanceof IDBRequest) {
                    let t;
                    return (t = new Promise((t, r) => {
                        let n = () => {
                                e.removeEventListener("success", i), e.removeEventListener("error", a)
                            },
                            i = () => {
                                t(g(e.result)), n()
                            },
                            a = () => {
                                r(e.error), n()
                            };
                        e.addEventListener("success", i), e.addEventListener("error", a)
                    })).then(t => {
                        t instanceof IDBCursor && c.set(t, e)
                    }).catch(() => {}), p.set(t, e), t
                }
                if (u.has(e)) return u.get(e);
                let t = function(e) {
                    if ("function" == typeof e) return e !== IDBDatabase.prototype.transaction || "objectStoreNames" in IDBTransaction.prototype ? (i || (i = [IDBCursor.prototype.advance, IDBCursor.prototype.continue, IDBCursor.prototype.continuePrimaryKey])).includes(e) ? function(...t) {
                        return e.apply(b(this), t), g(c.get(this))
                    } : function(...t) {
                        return g(e.apply(b(this), t))
                    } : function(t, ...r) {
                        let n = e.call(b(this), t, ...r);
                        return d.set(n, t.sort ? t.sort() : [t]), g(n)
                    };
                    return e instanceof IDBTransaction && function(e) {
                        if (h.has(e)) return;
                        let t = new Promise((t, r) => {
                            let n = () => {
                                    e.removeEventListener("complete", i), e.removeEventListener("error", a), e.removeEventListener("abort", a)
                                },
                                i = () => {
                                    t(), n()
                                },
                                a = () => {
                                    r(e.error || new DOMException("AbortError", "AbortError")), n()
                                };
                            e.addEventListener("complete", i), e.addEventListener("error", a), e.addEventListener("abort", a)
                        });
                        h.set(e, t)
                    }(e), (n || (n = [IDBDatabase, IDBObjectStore, IDBIndex, IDBCursor, IDBTransaction])).some(t => e instanceof t) ? new Proxy(e, f) : e
                }(e);
                return t !== e && (u.set(e, t), p.set(t, e)), t
            }
            let b = e => p.get(e),
                m = ["get", "getKey", "getAll", "getAllKeys", "count"],
                v = ["put", "add", "delete", "clear"],
                y = new Map;

            function E(e, t) {
                if (!(e instanceof IDBDatabase && !(t in e) && "string" == typeof t)) return;
                if (y.get(t)) return y.get(t);
                let r = t.replace(/FromIndex$/, ""),
                    n = t !== r,
                    i = v.includes(r);
                if (!(r in (n ? IDBIndex : IDBObjectStore).prototype) || !(i || m.includes(r))) return;
                let a = async function(e, ...t) {
                    let a = this.transaction(e, i ? "readwrite" : "readonly"),
                        s = a.store;
                    return n && (s = s.index(t.shift())), (await Promise.all([s[r](...t), i && a.done]))[0]
                };
                return y.set(t, a), a
            }
            f = { ...a = f,
                get: (e, t, r) => E(e, t) || a.get(e, t, r),
                has: (e, t) => !!E(e, t) || a.has(e, t)
            };
            class C {
                constructor(e) {
                    this.container = e
                }
                getPlatformInfoString() {
                    return this.container.getProviders().map(e => {
                        let t;
                        if (t = e.getComponent(), t ? .type !== "VERSION") return null; {
                            let t = e.getImmediate();
                            return `${t.library}/${t.version}`
                        }
                    }).filter(e => e).join(" ")
                }
            }
            let w = "@firebase/app",
                _ = "0.14.8",
                I = new o.Vy("@firebase/app"),
                A = "[DEFAULT]",
                S = {
                    [w]: "fire-core",
                    "@firebase/app-compat": "fire-core-compat",
                    "@firebase/analytics": "fire-analytics",
                    "@firebase/analytics-compat": "fire-analytics-compat",
                    "@firebase/app-check": "fire-app-check",
                    "@firebase/app-check-compat": "fire-app-check-compat",
                    "@firebase/auth": "fire-auth",
                    "@firebase/auth-compat": "fire-auth-compat",
                    "@firebase/database": "fire-rtdb",
                    "@firebase/data-connect": "fire-data-connect",
                    "@firebase/database-compat": "fire-rtdb-compat",
                    "@firebase/functions": "fire-fn",
                    "@firebase/functions-compat": "fire-fn-compat",
                    "@firebase/installations": "fire-iid",
                    "@firebase/installations-compat": "fire-iid-compat",
                    "@firebase/messaging": "fire-fcm",
                    "@firebase/messaging-compat": "fire-fcm-compat",
                    "@firebase/performance": "fire-perf",
                    "@firebase/performance-compat": "fire-perf-compat",
                    "@firebase/remote-config": "fire-rc",
                    "@firebase/remote-config-compat": "fire-rc-compat",
                    "@firebase/storage": "fire-gcs",
                    "@firebase/storage-compat": "fire-gcs-compat",
                    "@firebase/firestore": "fire-fst",
                    "@firebase/firestore-compat": "fire-fst-compat",
                    "@firebase/ai": "fire-vertex",
                    "fire-js": "fire-js",
                    firebase: "fire-js-all"
                },
                D = new Map,
                O = new Map,
                L = new Map;

            function P(e, t) {
                try {
                    e.container.addComponent(t)
                } catch (r) {
                    I.debug(`Component ${t.name} failed to register with FirebaseApp ${e.name}`, r)
                }
            }

            function B(e) {
                let t = e.name;
                if (L.has(t)) return I.debug(`There were multiple attempts to register component ${t}.`), !1;
                for (let r of (L.set(t, e), D.values())) P(r, e);
                for (let t of O.values()) P(t, e);
                return !0
            }

            function M(e, t) {
                let r = e.container.getProvider("heartbeat").getImmediate({
                    optional: !0
                });
                return r && r.triggerHeartbeat(), e.container.getProvider(t)
            }

            function k(e) {
                return null != e && void 0 !== e.settings
            }
            let T = new l.FA("app", "Firebase", {
                "no-app": "No Firebase App '{$appName}' has been created - call initializeApp() first",
                "bad-app-name": "Illegal App name: '{$appName}'",
                "duplicate-app": "Firebase App named '{$appName}' already exists with different options or config",
                "app-deleted": "Firebase App named '{$appName}' already deleted",
                "server-app-deleted": "Firebase Server App has been deleted",
                "no-options": "Need to provide options, when not being deployed to hosting via source.",
                "invalid-app-argument": "firebase.{$appName}() takes either no argument or a Firebase App instance.",
                "invalid-log-argument": "First argument to `onLog` must be null or a function.",
                "idb-open": "Error thrown when opening IndexedDB. Original error: {$originalErrorMessage}.",
                "idb-get": "Error thrown when reading from IndexedDB. Original error: {$originalErrorMessage}.",
                "idb-set": "Error thrown when writing to IndexedDB. Original error: {$originalErrorMessage}.",
                "idb-delete": "Error thrown when deleting from IndexedDB. Original error: {$originalErrorMessage}.",
                "finalization-registry-not-supported": "FirebaseServerApp deleteOnDeref field defined but the JS runtime does not support FinalizationRegistry.",
                "invalid-server-app-environment": "FirebaseServerApp is not for use in browser environments."
            });
            class R {
                constructor(e, t, r) {
                    this._isDeleted = !1, this._options = { ...e
                    }, this._config = { ...t
                    }, this._name = t.name, this._automaticDataCollectionEnabled = t.automaticDataCollectionEnabled, this._container = r, this.container.addComponent(new s.uA("app", () => this, "PUBLIC"))
                }
                get automaticDataCollectionEnabled() {
                    return this.checkDestroyed(), this._automaticDataCollectionEnabled
                }
                set automaticDataCollectionEnabled(e) {
                    this.checkDestroyed(), this._automaticDataCollectionEnabled = e
                }
                get name() {
                    return this.checkDestroyed(), this._name
                }
                get options() {
                    return this.checkDestroyed(), this._options
                }
                get config() {
                    return this.checkDestroyed(), this._config
                }
                get container() {
                    return this._container
                }
                get isDeleted() {
                    return this._isDeleted
                }
                set isDeleted(e) {
                    this._isDeleted = e
                }
                checkDestroyed() {
                    if (this.isDeleted) throw T.create("app-deleted", {
                        appName: this._name
                    })
                }
            }
            let N = "12.9.0";

            function x(e, t = {}) {
                let r = e;
                "object" != typeof t && (t = {
                    name: t
                });
                let n = {
                        name: A,
                        automaticDataCollectionEnabled: !0,
                        ...t
                    },
                    i = n.name;
                if ("string" != typeof i || !i) throw T.create("bad-app-name", {
                    appName: String(i)
                });
                if (r || (r = (0, l.T9)()), !r) throw T.create("no-options");
                let a = D.get(i);
                if (a)
                    if ((0, l.bD)(r, a.options) && (0, l.bD)(n, a.config)) return a;
                    else throw T.create("duplicate-app", {
                        appName: i
                    });
                let o = new s.h1(i);
                for (let e of L.values()) o.addComponent(e);
                let c = new R(r, n, o);
                return D.set(i, c), c
            }

            function H(e = A) {
                let t = D.get(e);
                if (!t && e === A && (0, l.T9)()) return x();
                if (!t) throw T.create("no-app", {
                    appName: e
                });
                return t
            }

            function W(e, t, r) {
                let n = S[e] ? ? e;
                r && (n += `-${r}`);
                let i = n.match(/\s|\//),
                    a = t.match(/\s|\//);
                if (i || a) {
                    let e = [`Unable to register library "${n}" with version "${t}":`];
                    i && e.push(`library name "${n}" contains illegal characters (whitespace or "/")`), i && a && e.push("and"), a && e.push(`version name "${t}" contains illegal characters (whitespace or "/")`), I.warn(e.join(" "));
                    return
                }
                B(new s.uA(`${n}-version`, () => ({
                    library: n,
                    version: t
                }), "VERSION"))
            }
            let $ = "firebase-heartbeat-store",
                j = null;

            function F() {
                return j || (j = (function(e, {
                    blocked: t,
                    upgrade: r,
                    blocking: n,
                    terminated: i
                } = {}) {
                    let a = indexedDB.open(e, 1),
                        s = g(a);
                    return r && a.addEventListener("upgradeneeded", e => {
                        r(g(a.result), e.oldVersion, e.newVersion, g(a.transaction), e)
                    }), t && a.addEventListener("blocked", e => t(e.oldVersion, e.newVersion, e)), s.then(e => {
                        i && e.addEventListener("close", () => i()), n && e.addEventListener("versionchange", e => n(e.oldVersion, e.newVersion, e))
                    }).catch(() => {}), s
                })("firebase-heartbeat-database", {
                    upgrade: (e, t) => {
                        if (0 === t) try {
                            e.createObjectStore($)
                        } catch (e) {
                            console.warn(e)
                        }
                    }
                }).catch(e => {
                    throw T.create("idb-open", {
                        originalErrorMessage: e.message
                    })
                })), j
            }
            async function U(e) {
                try {
                    let t = (await F()).transaction($),
                        r = await t.objectStore($).get(z(e));
                    return await t.done, r
                } catch (e) {
                    if (e instanceof l.g) I.warn(e.message);
                    else {
                        let t = T.create("idb-get", {
                            originalErrorMessage: e ? .message
                        });
                        I.warn(t.message)
                    }
                }
            }
            async function V(e, t) {
                try {
                    let r = (await F()).transaction($, "readwrite"),
                        n = r.objectStore($);
                    await n.put(t, z(e)), await r.done
                } catch (e) {
                    if (e instanceof l.g) I.warn(e.message);
                    else {
                        let t = T.create("idb-set", {
                            originalErrorMessage: e ? .message
                        });
                        I.warn(t.message)
                    }
                }
            }

            function z(e) {
                return `${e.name}!${e.options.appId}`
            }
            class G {
                constructor(e) {
                    this.container = e, this._heartbeatsCache = null;
                    const t = this.container.getProvider("app").getImmediate();
                    this._storage = new J(t), this._heartbeatsCachePromise = this._storage.read().then(e => (this._heartbeatsCache = e, e))
                }
                async triggerHeartbeat() {
                    try {
                        let e = this.container.getProvider("platform-logger").getImmediate().getPlatformInfoString(),
                            t = Z();
                        if (this._heartbeatsCache ? .heartbeats == null && (this._heartbeatsCache = await this._heartbeatsCachePromise, this._heartbeatsCache ? .heartbeats == null) || this._heartbeatsCache.lastSentHeartbeatDate === t || this._heartbeatsCache.heartbeats.some(e => e.date === t)) return;
                        if (this._heartbeatsCache.heartbeats.push({
                                date: t,
                                agent: e
                            }), this._heartbeatsCache.heartbeats.length > 30) {
                            let e = function(e) {
                                if (0 === e.length) return -1;
                                let t = 0,
                                    r = e[0].date;
                                for (let n = 1; n < e.length; n++) e[n].date < r && (r = e[n].date, t = n);
                                return t
                            }(this._heartbeatsCache.heartbeats);
                            this._heartbeatsCache.heartbeats.splice(e, 1)
                        }
                        return this._storage.overwrite(this._heartbeatsCache)
                    } catch (e) {
                        I.warn(e)
                    }
                }
                async getHeartbeatsHeader() {
                    try {
                        if (null === this._heartbeatsCache && await this._heartbeatsCachePromise, this._heartbeatsCache ? .heartbeats == null || 0 === this._heartbeatsCache.heartbeats.length) return "";
                        let e = Z(),
                            {
                                heartbeatsToSend: t,
                                unsentEntries: r
                            } = function(e, t = 1024) {
                                let r = [],
                                    n = e.slice();
                                for (let i of e) {
                                    let e = r.find(e => e.agent === i.agent);
                                    if (e) {
                                        if (e.dates.push(i.date), K(r) > t) {
                                            e.dates.pop();
                                            break
                                        }
                                    } else if (r.push({
                                            agent: i.agent,
                                            dates: [i.date]
                                        }), K(r) > t) {
                                        r.pop();
                                        break
                                    }
                                    n = n.slice(1)
                                }
                                return {
                                    heartbeatsToSend: r,
                                    unsentEntries: n
                                }
                            }(this._heartbeatsCache.heartbeats),
                            n = (0, l.Uj)(JSON.stringify({
                                version: 2,
                                heartbeats: t
                            }));
                        return this._heartbeatsCache.lastSentHeartbeatDate = e, r.length > 0 ? (this._heartbeatsCache.heartbeats = r, await this._storage.overwrite(this._heartbeatsCache)) : (this._heartbeatsCache.heartbeats = [], this._storage.overwrite(this._heartbeatsCache)), n
                    } catch (e) {
                        return I.warn(e), ""
                    }
                }
            }

            function Z() {
                return new Date().toISOString().substring(0, 10)
            }
            class J {
                constructor(e) {
                    this.app = e, this._canUseIndexedDBPromise = this.runIndexedDBEnvironmentCheck()
                }
                async runIndexedDBEnvironmentCheck() {
                    return !!(0, l.zW)() && (0, l.eX)().then(() => !0).catch(() => !1)
                }
                async read() {
                    if (!await this._canUseIndexedDBPromise) return {
                        heartbeats: []
                    }; {
                        let e = await U(this.app);
                        return e ? .heartbeats ? e : {
                            heartbeats: []
                        }
                    }
                }
                async overwrite(e) {
                    if (await this._canUseIndexedDBPromise) {
                        let t = await this.read();
                        return V(this.app, {
                            lastSentHeartbeatDate: e.lastSentHeartbeatDate ? ? t.lastSentHeartbeatDate,
                            heartbeats: e.heartbeats
                        })
                    }
                }
                async add(e) {
                    if (await this._canUseIndexedDBPromise) {
                        let t = await this.read();
                        return V(this.app, {
                            lastSentHeartbeatDate: e.lastSentHeartbeatDate ? ? t.lastSentHeartbeatDate,
                            heartbeats: [...t.heartbeats, ...e.heartbeats]
                        })
                    }
                }
            }

            function K(e) {
                return (0, l.Uj)(JSON.stringify({
                    version: 2,
                    heartbeats: e
                })).length
            }
            B(new s.uA("platform-logger", e => new C(e), "PRIVATE")), B(new s.uA("heartbeat", e => new G(e), "PRIVATE")), W(w, _, ""), W(w, _, "esm2020"), W("fire-js", "")
        },
        14434: (e, t, r) => {
            r.r(t), r.d(t, {
                ActionCodeOperation: () => n.A,
                ActionCodeURL: () => n.aj,
                AuthCredential: () => n.M,
                AuthErrorCodes: () => n.J,
                EmailAuthCredential: () => n.N,
                EmailAuthProvider: () => n.W,
                FacebookAuthProvider: () => n.X,
                FactorId: () => n.F,
                GithubAuthProvider: () => n.Z,
                GoogleAuthProvider: () => n.Y,
                OAuthCredential: () => n.Q,
                OAuthProvider: () => n._,
                OperationType: () => n.O,
                PhoneAuthCredential: () => n.U,
                PhoneAuthProvider: () => n.P,
                PhoneMultiFactorGenerator: () => n.n,
                ProviderId: () => n.q,
                RecaptchaVerifier: () => n.R,
                SAMLAuthProvider: () => n.$,
                SignInMethod: () => n.S,
                TotpMultiFactorGenerator: () => n.T,
                TotpSecret: () => n.o,
                TwitterAuthProvider: () => n.a0,
                applyActionCode: () => n.a8,
                beforeAuthStateChanged: () => n.y,
                browserCookiePersistence: () => n.a,
                browserLocalPersistence: () => n.b,
                browserPopupRedirectResolver: () => n.m,
                browserSessionPersistence: () => n.c,
                checkActionCode: () => n.a9,
                confirmPasswordReset: () => n.a7,
                connectAuthEmulator: () => n.L,
                createUserWithEmailAndPassword: () => n.ab,
                debugErrorMap: () => n.H,
                deleteUser: () => n.G,
                fetchSignInMethodsForEmail: () => n.ag,
                getAdditionalUserInfo: () => n.ar,
                getAuth: () => n.p,
                getIdToken: () => n.ao,
                getIdTokenResult: () => n.ap,
                getMultiFactorResolver: () => n.at,
                getRedirectResult: () => n.k,
                inMemoryPersistence: () => n.V,
                indexedDBLocalPersistence: () => n.i,
                initializeAuth: () => n.K,
                initializeRecaptchaConfig: () => n.v,
                isSignInWithEmailLink: () => n.ae,
                linkWithCredential: () => n.a3,
                linkWithPhoneNumber: () => n.l,
                linkWithPopup: () => n.e,
                linkWithRedirect: () => n.h,
                multiFactor: () => n.au,
                onAuthStateChanged: () => n.z,
                onIdTokenChanged: () => n.x,
                parseActionCodeURL: () => n.ak,
                prodErrorMap: () => n.I,
                reauthenticateWithCredential: () => n.a4,
                reauthenticateWithPhoneNumber: () => n.r,
                reauthenticateWithPopup: () => n.f,
                reauthenticateWithRedirect: () => n.j,
                reload: () => n.as,
                revokeAccessToken: () => n.E,
                sendEmailVerification: () => n.ah,
                sendPasswordResetEmail: () => n.a6,
                sendSignInLinkToEmail: () => n.ad,
                setPersistence: () => n.t,
                signInAnonymously: () => n.a1,
                signInWithCredential: () => n.a2,
                signInWithCustomToken: () => n.a5,
                signInWithEmailAndPassword: () => n.ac,
                signInWithEmailLink: () => n.af,
                signInWithPhoneNumber: () => n.s,
                signInWithPopup: () => n.d,
                signInWithRedirect: () => n.g,
                signOut: () => n.D,
                unlink: () => n.aq,
                updateCurrentUser: () => n.C,
                updateEmail: () => n.am,
                updatePassword: () => n.an,
                updatePhoneNumber: () => n.u,
                updateProfile: () => n.al,
                useDeviceLanguage: () => n.B,
                validatePassword: () => n.w,
                verifyBeforeUpdateEmail: () => n.ai,
                verifyPasswordResetCode: () => n.aa
            });
            var n = r(61252);
            r(11286), r(23390), r(42402), r(68381)
        },
        23390: (e, t, r) => {
            r.d(t, {
                cY: () => g,
                FA: () => P,
                g: () => L,
                u: () => h,
                Uj: () => c,
                tD: () => x,
                bD: () => function e(t, r) {
                    if (t === r) return !0;
                    let n = Object.keys(t),
                        i = Object.keys(r);
                    for (let a of n) {
                        if (!i.includes(a)) return !1;
                        let n = t[a],
                            s = r[a];
                        if (k(n) && k(s)) {
                            if (!e(n, s)) return !1
                        } else if (n !== s) return !1
                    }
                    for (let e of i)
                        if (!n.includes(e)) return !1;
                    return !0
                },
                hp: () => N,
                T9: () => p,
                Tj: () => u,
                XA: () => f,
                Ku: () => $,
                ZQ: () => C,
                sr: () => I,
                zJ: () => b,
                c1: () => _,
                Im: () => M,
                lT: () => S,
                zW: () => D,
                jZ: () => w,
                lV: () => A,
                gE: () => m,
                Am: () => T,
                I9: () => R,
                P1: () => E,
                eX: () => O
            });
            var n = r(29143);
            let i = function(e) {
                    let t = [],
                        r = 0;
                    for (let n = 0; n < e.length; n++) {
                        let i = e.charCodeAt(n);
                        i < 128 ? t[r++] = i : (i < 2048 ? t[r++] = i >> 6 | 192 : ((64512 & i) == 55296 && n + 1 < e.length && (64512 & e.charCodeAt(n + 1)) == 56320 ? (i = 65536 + ((1023 & i) << 10) + (1023 & e.charCodeAt(++n)), t[r++] = i >> 18 | 240, t[r++] = i >> 12 & 63 | 128) : t[r++] = i >> 12 | 224, t[r++] = i >> 6 & 63 | 128), t[r++] = 63 & i | 128)
                    }
                    return t
                },
                a = function(e) {
                    let t = [],
                        r = 0,
                        n = 0;
                    for (; r < e.length;) {
                        let i = e[r++];
                        if (i < 128) t[n++] = String.fromCharCode(i);
                        else if (i > 191 && i < 224) {
                            let a = e[r++];
                            t[n++] = String.fromCharCode((31 & i) << 6 | 63 & a)
                        } else if (i > 239 && i < 365) {
                            let a = ((7 & i) << 18 | (63 & e[r++]) << 12 | (63 & e[r++]) << 6 | 63 & e[r++]) - 65536;
                            t[n++] = String.fromCharCode(55296 + (a >> 10)), t[n++] = String.fromCharCode(56320 + (1023 & a))
                        } else {
                            let a = e[r++],
                                s = e[r++];
                            t[n++] = String.fromCharCode((15 & i) << 12 | (63 & a) << 6 | 63 & s)
                        }
                    }
                    return t.join("")
                },
                s = {
                    byteToCharMap_: null,
                    charToByteMap_: null,
                    byteToCharMapWebSafe_: null,
                    charToByteMapWebSafe_: null,
                    ENCODED_VALS_BASE: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",
                    get ENCODED_VALS() {
                        return this.ENCODED_VALS_BASE + "+/="
                    },
                    get ENCODED_VALS_WEBSAFE() {
                        return this.ENCODED_VALS_BASE + "-_."
                    },
                    HAS_NATIVE_SUPPORT: "function" == typeof atob,
                    encodeByteArray(e, t) {
                        if (!Array.isArray(e)) throw Error("encodeByteArray takes an array as a parameter");
                        this.init_();
                        let r = t ? this.byteToCharMapWebSafe_ : this.byteToCharMap_,
                            n = [];
                        for (let t = 0; t < e.length; t += 3) {
                            let i = e[t],
                                a = t + 1 < e.length,
                                s = a ? e[t + 1] : 0,
                                o = t + 2 < e.length,
                                l = o ? e[t + 2] : 0,
                                c = i >> 2,
                                h = (3 & i) << 4 | s >> 4,
                                d = (15 & s) << 2 | l >> 6,
                                u = 63 & l;
                            !o && (u = 64, a || (d = 64)), n.push(r[c], r[h], r[d], r[u])
                        }
                        return n.join("")
                    },
                    encodeString(e, t) {
                        return this.HAS_NATIVE_SUPPORT && !t ? btoa(e) : this.encodeByteArray(i(e), t)
                    },
                    decodeString(e, t) {
                        return this.HAS_NATIVE_SUPPORT && !t ? atob(e) : a(this.decodeStringToByteArray(e, t))
                    },
                    decodeStringToByteArray(e, t) {
                        this.init_();
                        let r = t ? this.charToByteMapWebSafe_ : this.charToByteMap_,
                            n = [];
                        for (let t = 0; t < e.length;) {
                            let i = r[e.charAt(t++)],
                                a = t < e.length ? r[e.charAt(t)] : 0,
                                s = ++t < e.length ? r[e.charAt(t)] : 64,
                                l = ++t < e.length ? r[e.charAt(t)] : 64;
                            if (++t, null == i || null == a || null == s || null == l) throw new o;
                            let c = i << 2 | a >> 4;
                            if (n.push(c), 64 !== s) {
                                let e = a << 4 & 240 | s >> 2;
                                if (n.push(e), 64 !== l) {
                                    let e = s << 6 & 192 | l;
                                    n.push(e)
                                }
                            }
                        }
                        return n
                    },
                    init_() {
                        if (!this.byteToCharMap_) {
                            this.byteToCharMap_ = {}, this.charToByteMap_ = {}, this.byteToCharMapWebSafe_ = {}, this.charToByteMapWebSafe_ = {};
                            for (let e = 0; e < this.ENCODED_VALS.length; e++) this.byteToCharMap_[e] = this.ENCODED_VALS.charAt(e), this.charToByteMap_[this.byteToCharMap_[e]] = e, this.byteToCharMapWebSafe_[e] = this.ENCODED_VALS_WEBSAFE.charAt(e), this.charToByteMapWebSafe_[this.byteToCharMapWebSafe_[e]] = e, e >= this.ENCODED_VALS_BASE.length && (this.charToByteMap_[this.ENCODED_VALS_WEBSAFE.charAt(e)] = e, this.charToByteMapWebSafe_[this.ENCODED_VALS.charAt(e)] = e)
                        }
                    }
                };
            class o extends Error {
                constructor() {
                    super(...arguments), this.name = "DecodeBase64StringError"
                }
            }
            let l = function(e) {
                    let t = i(e);
                    return s.encodeByteArray(t, !0)
                },
                c = function(e) {
                    return l(e).replace(/\./g, "")
                },
                h = function(e) {
                    try {
                        return s.decodeString(e, !0)
                    } catch (e) {
                        console.error("base64Decode failed: ", e)
                    }
                    return null
                },
                d = () => {
                    try {
                        return function() {
                            if ("u" > typeof self) return self;
                            if ("u" > typeof window) return window;
                            if (void 0 !== r.g) return r.g;
                            throw Error("Unable to locate global object.")
                        }().__FIREBASE_DEFAULTS__ || (() => {
                            if (void 0 === n || void 0 === n.env) return;
                            let e = n.env.__FIREBASE_DEFAULTS__;
                            if (e) return JSON.parse(e)
                        })() || (() => {
                            let e;
                            if ("u" < typeof document) return;
                            try {
                                e = document.cookie.match(/__FIREBASE_DEFAULTS__=([^;]+)/)
                            } catch (e) {
                                return
                            }
                            let t = e && h(e[1]);
                            return t && JSON.parse(t)
                        })()
                    } catch (e) {
                        console.info(`Unable to get __FIREBASE_DEFAULTS__ due to: ${e}`);
                        return
                    }
                },
                u = e => d() ? .emulatorHosts ? .[e],
                p = () => d() ? .config,
                f = e => d() ? .[`_${e}`];
            class g {
                constructor() {
                    this.reject = () => {}, this.resolve = () => {}, this.promise = new Promise((e, t) => {
                        this.resolve = e, this.reject = t
                    })
                }
                wrapCallback(e) {
                    return (t, r) => {
                        t ? this.reject(t) : this.resolve(r), "function" == typeof e && (this.promise.catch(() => {}), 1 === e.length ? e(t) : e(t, r))
                    }
                }
            }

            function b(e) {
                try {
                    return (e.startsWith("http://") || e.startsWith("https://") ? new URL(e).hostname : e).endsWith(".cloudworkstations.dev")
                } catch {
                    return !1
                }
            }
            async function m(e) {
                return (await fetch(e, {
                    credentials: "include"
                })).ok
            }
            let v = {},
                y = !1;

            function E(e, t) {
                if ("u" < typeof window || "u" < typeof document || !b(window.location.host) || v[e] === t || v[e] || y) return;

                function r(e) {
                    return `__firebase__banner__${e}`
                }
                v[e] = t;
                let n = "__firebase__banner",
                    i = function() {
                        let e = {
                            prod: [],
                            emulator: []
                        };
                        for (let t of Object.keys(v)) v[t] ? e.emulator.push(t) : e.prod.push(t);
                        return e
                    }().prod.length > 0;

                function a() {
                    let e, t, a = (e = document.getElementById(n), t = !1, e || ((e = document.createElement("div")).setAttribute("id", n), t = !0), {
                            created: t,
                            element: e
                        }),
                        s = r("text"),
                        o = document.getElementById(s) || document.createElement("span"),
                        l = r("learnmore"),
                        c = document.getElementById(l) || document.createElement("a"),
                        h = r("preprendIcon"),
                        d = document.getElementById(h) || document.createElementNS("http://www.w3.org/2000/svg", "svg");
                    if (a.created) {
                        let e, t = a.element;
                        t.style.display = "flex", t.style.background = "#7faaf0", t.style.position = "fixed", t.style.bottom = "5px", t.style.left = "5px", t.style.padding = ".5em", t.style.borderRadius = "5px", t.style.alignItems = "center", c.setAttribute("id", l), c.innerText = "Learn more", c.href = "https://firebase.google.com/docs/studio/preview-apps#preview-backend", c.setAttribute("target", "__blank"), c.style.paddingLeft = "5px", c.style.textDecoration = "underline";
                        let r = ((e = document.createElement("span")).style.cursor = "pointer", e.style.marginLeft = "16px", e.style.fontSize = "24px", e.innerHTML = " &times;", e.onclick = () => {
                            let e;
                            y = !0, (e = document.getElementById(n)) && e.remove()
                        }, e);
                        d.setAttribute("width", "24"), d.setAttribute("id", h), d.setAttribute("height", "24"), d.setAttribute("viewBox", "0 0 24 24"), d.setAttribute("fill", "none"), d.style.marginLeft = "-6px", t.append(d, o, c, r), document.body.appendChild(t)
                    }
                    i ? (o.innerText = "Preview backend disconnected.", d.innerHTML = `<g clip-path="url(#clip0_6013_33858)">
<path d="M4.8 17.6L12 5.6L19.2 17.6H4.8ZM6.91667 16.4H17.0833L12 7.93333L6.91667 16.4ZM12 15.6C12.1667 15.6 12.3056 15.5444 12.4167 15.4333C12.5389 15.3111 12.6 15.1667 12.6 15C12.6 14.8333 12.5389 14.6944 12.4167 14.5833C12.3056 14.4611 12.1667 14.4 12 14.4C11.8333 14.4 11.6889 14.4611 11.5667 14.5833C11.4556 14.6944 11.4 14.8333 11.4 15C11.4 15.1667 11.4556 15.3111 11.5667 15.4333C11.6889 15.5444 11.8333 15.6 12 15.6ZM11.4 13.6H12.6V10.4H11.4V13.6Z" fill="#212121"/>
</g>
<defs>
<clipPath id="clip0_6013_33858">
<rect width="24" height="24" fill="white"/>
</clipPath>
</defs>`) : (d.innerHTML = `<g clip-path="url(#clip0_6083_34804)">
<path d="M11.4 15.2H12.6V11.2H11.4V15.2ZM12 10C12.1667 10 12.3056 9.94444 12.4167 9.83333C12.5389 9.71111 12.6 9.56667 12.6 9.4C12.6 9.23333 12.5389 9.09444 12.4167 8.98333C12.3056 8.86111 12.1667 8.8 12 8.8C11.8333 8.8 11.6889 8.86111 11.5667 8.98333C11.4556 9.09444 11.4 9.23333 11.4 9.4C11.4 9.56667 11.4556 9.71111 11.5667 9.83333C11.6889 9.94444 11.8333 10 12 10ZM12 18.4C11.1222 18.4 10.2944 18.2333 9.51667 17.9C8.73889 17.5667 8.05556 17.1111 7.46667 16.5333C6.88889 15.9444 6.43333 15.2611 6.1 14.4833C5.76667 13.7056 5.6 12.8778 5.6 12C5.6 11.1111 5.76667 10.2833 6.1 9.51667C6.43333 8.73889 6.88889 8.06111 7.46667 7.48333C8.05556 6.89444 8.73889 6.43333 9.51667 6.1C10.2944 5.76667 11.1222 5.6 12 5.6C12.8889 5.6 13.7167 5.76667 14.4833 6.1C15.2611 6.43333 15.9389 6.89444 16.5167 7.48333C17.1056 8.06111 17.5667 8.73889 17.9 9.51667C18.2333 10.2833 18.4 11.1111 18.4 12C18.4 12.8778 18.2333 13.7056 17.9 14.4833C17.5667 15.2611 17.1056 15.9444 16.5167 16.5333C15.9389 17.1111 15.2611 17.5667 14.4833 17.9C13.7167 18.2333 12.8889 18.4 12 18.4ZM12 17.2C13.4444 17.2 14.6722 16.6944 15.6833 15.6833C16.6944 14.6722 17.2 13.4444 17.2 12C17.2 10.5556 16.6944 9.32778 15.6833 8.31667C14.6722 7.30555 13.4444 6.8 12 6.8C10.5556 6.8 9.32778 7.30555 8.31667 8.31667C7.30556 9.32778 6.8 10.5556 6.8 12C6.8 13.4444 7.30556 14.6722 8.31667 15.6833C9.32778 16.6944 10.5556 17.2 12 17.2Z" fill="#212121"/>
</g>
<defs>
<clipPath id="clip0_6083_34804">
<rect width="24" height="24" fill="white"/>
</clipPath>
</defs>`, o.innerText = "Preview backend running in this workspace."), o.setAttribute("id", s)
                }
                "loading" === document.readyState ? window.addEventListener("DOMContentLoaded", a) : a()
            }

            function C() {
                return "u" > typeof navigator && "string" == typeof navigator.userAgent ? navigator.userAgent : ""
            }

            function w() {
                return "u" > typeof window && !!(window.cordova || window.phonegap || window.PhoneGap) && /ios|iphone|ipod|ipad|android|blackberry|iemobile/i.test(C())
            }

            function _() {
                return "u" > typeof navigator && "Cloudflare-Workers" === navigator.userAgent
            }

            function I() {
                let e = "object" == typeof chrome ? chrome.runtime : "object" == typeof browser ? browser.runtime : void 0;
                return "object" == typeof e && void 0 !== e.id
            }

            function A() {
                return "object" == typeof navigator && "ReactNative" === navigator.product
            }

            function S() {
                let e = C();
                return e.indexOf("MSIE ") >= 0 || e.indexOf("Trident/") >= 0
            }

            function D() {
                try {
                    return "object" == typeof indexedDB
                } catch (e) {
                    return !1
                }
            }

            function O() {
                return new Promise((e, t) => {
                    try {
                        let r = !0,
                            n = "validate-browser-context-for-indexeddb-analytics-module",
                            i = self.indexedDB.open(n);
                        i.onsuccess = () => {
                            i.result.close(), r || self.indexedDB.deleteDatabase(n), e(!0)
                        }, i.onupgradeneeded = () => {
                            r = !1
                        }, i.onerror = () => {
                            t(i.error ? .message || "")
                        }
                    } catch (e) {
                        t(e)
                    }
                })
            }
            class L extends Error {
                constructor(e, t, r) {
                    super(t), this.code = e, this.customData = r, this.name = "FirebaseError", Object.setPrototypeOf(this, L.prototype), Error.captureStackTrace && Error.captureStackTrace(this, P.prototype.create)
                }
            }
            class P {
                constructor(e, t, r) {
                    this.service = e, this.serviceName = t, this.errors = r
                }
                create(e, ...t) {
                    var r, n;
                    let i = t[0] || {},
                        a = `${this.service}/${e}`,
                        s = this.errors[e],
                        o = s ? (r = s, n = i, r.replace(B, (e, t) => {
                            let r = n[t];
                            return null != r ? String(r) : `<${t}?>`
                        })) : "Error",
                        l = `${this.serviceName}: ${o} (${a}).`;
                    return new L(a, l, i)
                }
            }
            let B = /\{\$([^}]+)}/g;

            function M(e) {
                for (let t in e)
                    if (Object.prototype.hasOwnProperty.call(e, t)) return !1;
                return !0
            }

            function k(e) {
                return null !== e && "object" == typeof e
            }

            function T(e) {
                let t = [];
                for (let [r, n] of Object.entries(e)) Array.isArray(n) ? n.forEach(e => {
                    t.push(encodeURIComponent(r) + "=" + encodeURIComponent(e))
                }) : t.push(encodeURIComponent(r) + "=" + encodeURIComponent(n));
                return t.length ? "&" + t.join("&") : ""
            }

            function R(e) {
                let t = {};
                return e.replace(/^\?/, "").split("&").forEach(e => {
                    if (e) {
                        let [r, n] = e.split("=");
                        t[decodeURIComponent(r)] = decodeURIComponent(n)
                    }
                }), t
            }

            function N(e) {
                let t = e.indexOf("?");
                if (!t) return "";
                let r = e.indexOf("#", t);
                return e.substring(t, r > 0 ? r : void 0)
            }

            function x(e, t) {
                let r = new H(e, t);
                return r.subscribe.bind(r)
            }
            class H {
                constructor(e, t) {
                    this.observers = [], this.unsubscribes = [], this.observerCount = 0, this.task = Promise.resolve(), this.finalized = !1, this.onNoObservers = t, this.task.then(() => {
                        e(this)
                    }).catch(e => {
                        this.error(e)
                    })
                }
                next(e) {
                    this.forEachObserver(t => {
                        t.next(e)
                    })
                }
                error(e) {
                    this.forEachObserver(t => {
                        t.error(e)
                    }), this.close(e)
                }
                complete() {
                    this.forEachObserver(e => {
                        e.complete()
                    }), this.close()
                }
                subscribe(e, t, r) {
                    let n;
                    if (void 0 === e && void 0 === t && void 0 === r) throw Error("Missing Observer.");
                    void 0 === (n = ! function(e, t) {
                        if ("object" != typeof e || null === e) return !1;
                        for (let r of t)
                            if (r in e && "function" == typeof e[r]) return !0;
                        return !1
                    }(e, ["next", "error", "complete"]) ? {
                        next: e,
                        error: t,
                        complete: r
                    } : e).next && (n.next = W), void 0 === n.error && (n.error = W), void 0 === n.complete && (n.complete = W);
                    let i = this.unsubscribeOne.bind(this, this.observers.length);
                    return this.finalized && this.task.then(() => {
                        try {
                            this.finalError ? n.error(this.finalError) : n.complete()
                        } catch (e) {}
                    }), this.observers.push(n), i
                }
                unsubscribeOne(e) {
                    void 0 !== this.observers && void 0 !== this.observers[e] && (delete this.observers[e], this.observerCount -= 1, 0 === this.observerCount && void 0 !== this.onNoObservers && this.onNoObservers(this))
                }
                forEachObserver(e) {
                    if (!this.finalized)
                        for (let t = 0; t < this.observers.length; t++) this.sendOne(t, e)
                }
                sendOne(e, t) {
                    this.task.then(() => {
                        if (void 0 !== this.observers && void 0 !== this.observers[e]) try {
                            t(this.observers[e])
                        } catch (e) {
                            "u" > typeof console && console.error && console.error(e)
                        }
                    })
                }
                close(e) {
                    this.finalized || (this.finalized = !0, void 0 !== e && (this.finalError = e), this.task.then(() => {
                        this.observers = void 0, this.onNoObservers = void 0
                    }))
                }
            }

            function W() {}

            function $(e) {
                return e && e._delegate ? e._delegate : e
            }
        },
        42402: (e, t, r) => {
            var n, i;
            r.d(t, {
                $b: () => n,
                Vy: () => h
            });
            let a = [];
            (i = n || (n = {}))[i.DEBUG = 0] = "DEBUG", i[i.VERBOSE = 1] = "VERBOSE", i[i.INFO = 2] = "INFO", i[i.WARN = 3] = "WARN", i[i.ERROR = 4] = "ERROR", i[i.SILENT = 5] = "SILENT";
            let s = {
                    debug: n.DEBUG,
                    verbose: n.VERBOSE,
                    info: n.INFO,
                    warn: n.WARN,
                    error: n.ERROR,
                    silent: n.SILENT
                },
                o = n.INFO,
                l = {
                    [n.DEBUG]: "log",
                    [n.VERBOSE]: "log",
                    [n.INFO]: "info",
                    [n.WARN]: "warn",
                    [n.ERROR]: "error"
                },
                c = (e, t, ...r) => {
                    if (t < e.logLevel) return;
                    let n = new Date().toISOString(),
                        i = l[t];
                    if (i) console[i](`[${n}]  ${e.name}:`, ...r);
                    else throw Error(`Attempted to log a message with an invalid logType (value: ${t})`)
                };
            class h {
                constructor(e) {
                    this.name = e, this._logLevel = o, this._logHandler = c, this._userLogHandler = null, a.push(this)
                }
                get logLevel() {
                    return this._logLevel
                }
                set logLevel(e) {
                    if (!(e in n)) throw TypeError(`Invalid value "${e}" assigned to \`logLevel\``);
                    this._logLevel = e
                }
                setLogLevel(e) {
                    this._logLevel = "string" == typeof e ? s[e] : e
                }
                get logHandler() {
                    return this._logHandler
                }
                set logHandler(e) {
                    if ("function" != typeof e) throw TypeError("Value assigned to `logHandler` must be a function");
                    this._logHandler = e
                }
                get userLogHandler() {
                    return this._userLogHandler
                }
                set userLogHandler(e) {
                    this._userLogHandler = e
                }
                debug(...e) {
                    this._userLogHandler && this._userLogHandler(this, n.DEBUG, ...e), this._logHandler(this, n.DEBUG, ...e)
                }
                log(...e) {
                    this._userLogHandler && this._userLogHandler(this, n.VERBOSE, ...e), this._logHandler(this, n.VERBOSE, ...e)
                }
                info(...e) {
                    this._userLogHandler && this._userLogHandler(this, n.INFO, ...e), this._logHandler(this, n.INFO, ...e)
                }
                warn(...e) {
                    this._userLogHandler && this._userLogHandler(this, n.WARN, ...e), this._logHandler(this, n.WARN, ...e)
                }
                error(...e) {
                    this._userLogHandler && this._userLogHandler(this, n.ERROR, ...e), this._logHandler(this, n.ERROR, ...e)
                }
            }
        },
        68381: (e, t, r) => {
            r.d(t, {
                h1: () => o,
                uA: () => i
            });
            var n = r(23390);
            class i {
                constructor(e, t, r) {
                    this.name = e, this.instanceFactory = t, this.type = r, this.multipleInstances = !1, this.serviceProps = {}, this.instantiationMode = "LAZY", this.onInstanceCreated = null
                }
                setInstantiationMode(e) {
                    return this.instantiationMode = e, this
                }
                setMultipleInstances(e) {
                    return this.multipleInstances = e, this
                }
                setServiceProps(e) {
                    return this.serviceProps = e, this
                }
                setInstanceCreatedCallback(e) {
                    return this.onInstanceCreated = e, this
                }
            }
            let a = "[DEFAULT]";
            class s {
                constructor(e, t) {
                    this.name = e, this.container = t, this.component = null, this.instances = new Map, this.instancesDeferred = new Map, this.instancesOptions = new Map, this.onInitCallbacks = new Map
                }
                get(e) {
                    let t = this.normalizeInstanceIdentifier(e);
                    if (!this.instancesDeferred.has(t)) {
                        let e = new n.cY;
                        if (this.instancesDeferred.set(t, e), this.isInitialized(t) || this.shouldAutoInitialize()) try {
                            let r = this.getOrInitializeService({
                                instanceIdentifier: t
                            });
                            r && e.resolve(r)
                        } catch (e) {}
                    }
                    return this.instancesDeferred.get(t).promise
                }
                getImmediate(e) {
                    let t = this.normalizeInstanceIdentifier(e ? .identifier),
                        r = e ? .optional ? ? !1;
                    if (this.isInitialized(t) || this.shouldAutoInitialize()) try {
                        return this.getOrInitializeService({
                            instanceIdentifier: t
                        })
                    } catch (e) {
                        if (r) return null;
                        throw e
                    }
                    if (r) return null;
                    throw Error(`Service ${this.name} is not available`)
                }
                getComponent() {
                    return this.component
                }
                setComponent(e) {
                    if (e.name !== this.name) throw Error(`Mismatching Component ${e.name} for Provider ${this.name}.`);
                    if (this.component) throw Error(`Component for ${this.name} has already been provided`);
                    if (this.component = e, this.shouldAutoInitialize()) {
                        if ("EAGER" === e.instantiationMode) try {
                            this.getOrInitializeService({
                                instanceIdentifier: a
                            })
                        } catch (e) {}
                        for (let [e, t] of this.instancesDeferred.entries()) {
                            let r = this.normalizeInstanceIdentifier(e);
                            try {
                                let e = this.getOrInitializeService({
                                    instanceIdentifier: r
                                });
                                t.resolve(e)
                            } catch (e) {}
                        }
                    }
                }
                clearInstance(e = a) {
                    this.instancesDeferred.delete(e), this.instancesOptions.delete(e), this.instances.delete(e)
                }
                async delete() {
                    let e = Array.from(this.instances.values());
                    await Promise.all([...e.filter(e => "INTERNAL" in e).map(e => e.INTERNAL.delete()), ...e.filter(e => "_delete" in e).map(e => e._delete())])
                }
                isComponentSet() {
                    return null != this.component
                }
                isInitialized(e = a) {
                    return this.instances.has(e)
                }
                getOptions(e = a) {
                    return this.instancesOptions.get(e) || {}
                }
                initialize(e = {}) {
                    let {
                        options: t = {}
                    } = e, r = this.normalizeInstanceIdentifier(e.instanceIdentifier);
                    if (this.isInitialized(r)) throw Error(`${this.name}(${r}) has already been initialized`);
                    if (!this.isComponentSet()) throw Error(`Component ${this.name} has not been registered yet`);
                    let n = this.getOrInitializeService({
                        instanceIdentifier: r,
                        options: t
                    });
                    for (let [e, t] of this.instancesDeferred.entries()) r === this.normalizeInstanceIdentifier(e) && t.resolve(n);
                    return n
                }
                onInit(e, t) {
                    let r = this.normalizeInstanceIdentifier(t),
                        n = this.onInitCallbacks.get(r) ? ? new Set;
                    n.add(e), this.onInitCallbacks.set(r, n);
                    let i = this.instances.get(r);
                    return i && e(i, r), () => {
                        n.delete(e)
                    }
                }
                invokeOnInitCallbacks(e, t) {
                    let r = this.onInitCallbacks.get(t);
                    if (r)
                        for (let n of r) try {
                            n(e, t)
                        } catch {}
                }
                getOrInitializeService({
                    instanceIdentifier: e,
                    options: t = {}
                }) {
                    var r;
                    let n = this.instances.get(e);
                    if (!n && this.component && (n = this.component.instanceFactory(this.container, {
                            instanceIdentifier: (r = e) === a ? void 0 : r,
                            options: t
                        }), this.instances.set(e, n), this.instancesOptions.set(e, t), this.invokeOnInitCallbacks(n, e), this.component.onInstanceCreated)) try {
                        this.component.onInstanceCreated(this.container, e, n)
                    } catch {}
                    return n || null
                }
                normalizeInstanceIdentifier(e = a) {
                    return this.component ? this.component.multipleInstances ? e : a : e
                }
                shouldAutoInitialize() {
                    return !!this.component && "EXPLICIT" !== this.component.instantiationMode
                }
            }
            class o {
                constructor(e) {
                    this.name = e, this.providers = new Map
                }
                addComponent(e) {
                    let t = this.getProvider(e.name);
                    if (t.isComponentSet()) throw Error(`Component ${e.name} has already been registered with ${this.name}`);
                    t.setComponent(e)
                }
                addOrOverwriteComponent(e) {
                    this.getProvider(e.name).isComponentSet() && this.providers.delete(e.name), this.addComponent(e)
                }
                getProvider(e) {
                    if (this.providers.has(e)) return this.providers.get(e);
                    let t = new s(e, this);
                    return this.providers.set(e, t), t
                }
                getProviders() {
                    return Array.from(this.providers.values())
                }
            }
        }
    }
]);