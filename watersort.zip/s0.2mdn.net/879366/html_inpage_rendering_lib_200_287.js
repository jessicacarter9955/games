(function () {
  var k,
    aa = function (a) {
      var b = 0;
      return function () {
        return b < a.length ? { done: !1, value: a[b++] } : { done: !0 };
      };
    },
    ba =
      typeof Object.defineProperties == "function"
        ? Object.defineProperty
        : function (a, b, c) {
            if (a == Array.prototype || a == Object.prototype) return a;
            a[b] = c.value;
            return a;
          },
    ea = function (a) {
      a = [
        "object" == typeof globalThis && globalThis,
        a,
        "object" == typeof window && window,
        "object" == typeof self && self,
        "object" == typeof global && global,
      ];
      for (var b = 0; b < a.length; ++b) {
        var c = a[b];
        if (c && c.Math == Math) return c;
      }
      throw Error("Cannot find global object");
    },
    fa = ea(this),
    p = function (a, b) {
      if (b)
        a: {
          var c = fa;
          a = a.split(".");
          for (var d = 0; d < a.length - 1; d++) {
            var e = a[d];
            if (!(e in c)) break a;
            c = c[e];
          }
          a = a[a.length - 1];
          d = c[a];
          b = b(d);
          b != d &&
            b != null &&
            ba(c, a, { configurable: !0, writable: !0, value: b });
        }
    };
  p("Symbol", function (a) {
    if (a) return a;
    var b = function (f, g) {
      this.g = f;
      ba(this, "description", { configurable: !0, writable: !0, value: g });
    };
    b.prototype.toString = function () {
      return this.g;
    };
    var c = "jscomp_symbol_" + ((Math.random() * 1e9) >>> 0) + "_",
      d = 0,
      e = function (f) {
        if (this instanceof e)
          throw new TypeError("Symbol is not a constructor");
        return new b(c + (f || "") + "_" + d++, f);
      };
    return e;
  });
  p("Symbol.iterator", function (a) {
    if (a) return a;
    a = Symbol("Symbol.iterator");
    for (
      var b =
          "Array Int8Array Uint8Array Uint8ClampedArray Int16Array Uint16Array Int32Array Uint32Array Float32Array Float64Array".split(
            " "
          ),
        c = 0;
      c < b.length;
      c++
    ) {
      var d = fa[b[c]];
      typeof d === "function" &&
        typeof d.prototype[a] != "function" &&
        ba(d.prototype, a, {
          configurable: !0,
          writable: !0,
          value: function () {
            return ha(aa(this));
          },
        });
    }
    return a;
  });
  var ha = function (a) {
      a = { next: a };
      a[Symbol.iterator] = function () {
        return this;
      };
      return a;
    },
    ia =
      typeof Object.create == "function"
        ? Object.create
        : function (a) {
            var b = function () {};
            b.prototype = a;
            return new b();
          },
    ja;
  if (typeof Object.setPrototypeOf == "function") ja = Object.setPrototypeOf;
  else {
    var ka;
    a: {
      var la = { a: !0 },
        na = {};
      try {
        na.__proto__ = la;
        ka = na.a;
        break a;
      } catch (a) {}
      ka = !1;
    }
    ja = ka
      ? function (a, b) {
          a.__proto__ = b;
          if (a.__proto__ !== b) throw new TypeError(a + " is not extensible");
          return a;
        }
      : null;
  }
  var oa = ja,
    q = function (a, b) {
      a.prototype = ia(b.prototype);
      a.prototype.constructor = a;
      if (oa) oa(a, b);
      else
        for (var c in b)
          if (c != "prototype")
            if (Object.defineProperties) {
              var d = Object.getOwnPropertyDescriptor(b, c);
              d && Object.defineProperty(a, c, d);
            } else a[c] = b[c];
      a.X = b.prototype;
    },
    ra = function (a) {
      var b =
        typeof Symbol != "undefined" && Symbol.iterator && a[Symbol.iterator];
      if (b) return b.call(a);
      if (typeof a.length == "number") return { next: aa(a) };
      throw Error(String(a) + " is not an iterable or ArrayLike");
    },
    sa = function (a) {
      if (!(a instanceof Array)) {
        a = ra(a);
        for (var b, c = []; !(b = a.next()).done; ) c.push(b.value);
        a = c;
      }
      return a;
    },
    ua = function (a) {
      return ta(a, a);
    },
    ta = function (a, b) {
      a.raw = b;
      Object.freeze && (Object.freeze(a), Object.freeze(b));
      return a;
    },
    va = function (a, b) {
      return Object.prototype.hasOwnProperty.call(a, b);
    },
    wa = function () {
      for (var a = Number(this), b = [], c = a; c < arguments.length; c++)
        b[c - a] = arguments[c];
      return b;
    };
  p("globalThis", function (a) {
    return a || fa;
  });
  p("Promise", function (a) {
    function b() {
      this.g = null;
    }
    function c(g) {
      return g instanceof e
        ? g
        : new e(function (h) {
            h(g);
          });
    }
    if (a) return a;
    b.prototype.j = function (g) {
      if (this.g == null) {
        this.g = [];
        var h = this;
        this.o(function () {
          h.A();
        });
      }
      this.g.push(g);
    };
    var d = fa.setTimeout;
    b.prototype.o = function (g) {
      d(g, 0);
    };
    b.prototype.A = function () {
      for (; this.g && this.g.length; ) {
        var g = this.g;
        this.g = [];
        for (var h = 0; h < g.length; ++h) {
          var l = g[h];
          g[h] = null;
          try {
            l();
          } catch (m) {
            this.v(m);
          }
        }
      }
      this.g = null;
    };
    b.prototype.v = function (g) {
      this.o(function () {
        throw g;
      });
    };
    var e = function (g) {
      this.g = 0;
      this.o = void 0;
      this.j = [];
      this.C = !1;
      var h = this.v();
      try {
        g(h.resolve, h.reject);
      } catch (l) {
        h.reject(l);
      }
    };
    e.prototype.v = function () {
      function g(m) {
        return function (n) {
          l || ((l = !0), m.call(h, n));
        };
      }
      var h = this,
        l = !1;
      return { resolve: g(this.L), reject: g(this.A) };
    };
    e.prototype.L = function (g) {
      if (g === this)
        this.A(new TypeError("A Promise cannot resolve to itself"));
      else if (g instanceof e) this.J(g);
      else {
        a: switch (typeof g) {
          case "object":
            var h = g != null;
            break a;
          case "function":
            h = !0;
            break a;
          default:
            h = !1;
        }
        h ? this.I(g) : this.B(g);
      }
    };
    e.prototype.I = function (g) {
      var h = void 0;
      try {
        h = g.then;
      } catch (l) {
        this.A(l);
        return;
      }
      typeof h == "function" ? this.K(h, g) : this.B(g);
    };
    e.prototype.A = function (g) {
      this.D(2, g);
    };
    e.prototype.B = function (g) {
      this.D(1, g);
    };
    e.prototype.D = function (g, h) {
      if (this.g != 0)
        throw Error(
          "Cannot settle(" +
            g +
            ", " +
            h +
            "): Promise already settled in state" +
            this.g
        );
      this.g = g;
      this.o = h;
      this.g === 2 && this.P();
      this.F();
    };
    e.prototype.P = function () {
      var g = this;
      d(function () {
        if (g.G()) {
          var h = fa.console;
          typeof h !== "undefined" && h.error(g.o);
        }
      }, 1);
    };
    e.prototype.G = function () {
      if (this.C) return !1;
      var g = fa.CustomEvent,
        h = fa.Event,
        l = fa.dispatchEvent;
      if (typeof l === "undefined") return !0;
      typeof g === "function"
        ? (g = new g("unhandledrejection", { cancelable: !0 }))
        : typeof h === "function"
        ? (g = new h("unhandledrejection", { cancelable: !0 }))
        : ((g = fa.document.createEvent("CustomEvent")),
          g.initCustomEvent("unhandledrejection", !1, !0, g));
      g.promise = this;
      g.reason = this.o;
      return l(g);
    };
    e.prototype.F = function () {
      if (this.j != null) {
        for (var g = 0; g < this.j.length; ++g) f.j(this.j[g]);
        this.j = null;
      }
    };
    var f = new b();
    e.prototype.J = function (g) {
      var h = this.v();
      g.gb(h.resolve, h.reject);
    };
    e.prototype.K = function (g, h) {
      var l = this.v();
      try {
        g.call(h, l.resolve, l.reject);
      } catch (m) {
        l.reject(m);
      }
    };
    e.prototype.then = function (g, h) {
      function l(D, K) {
        return typeof D == "function"
          ? function (ya) {
              try {
                m(D(ya));
              } catch (qa) {
                n(qa);
              }
            }
          : K;
      }
      var m,
        n,
        r = new e(function (D, K) {
          m = D;
          n = K;
        });
      this.gb(l(g, m), l(h, n));
      return r;
    };
    e.prototype.catch = function (g) {
      return this.then(void 0, g);
    };
    e.prototype.gb = function (g, h) {
      function l() {
        switch (m.g) {
          case 1:
            g(m.o);
            break;
          case 2:
            h(m.o);
            break;
          default:
            throw Error("Unexpected state: " + m.g);
        }
      }
      var m = this;
      this.j == null ? f.j(l) : this.j.push(l);
      this.C = !0;
    };
    e.resolve = c;
    e.reject = function (g) {
      return new e(function (h, l) {
        l(g);
      });
    };
    e.race = function (g) {
      return new e(function (h, l) {
        for (var m = ra(g), n = m.next(); !n.done; n = m.next())
          c(n.value).gb(h, l);
      });
    };
    e.all = function (g) {
      var h = ra(g),
        l = h.next();
      return l.done
        ? c([])
        : new e(function (m, n) {
            function r(ya) {
              return function (qa) {
                D[ya] = qa;
                K--;
                K == 0 && m(D);
              };
            }
            var D = [],
              K = 0;
            do
              D.push(void 0),
                K++,
                c(l.value).gb(r(D.length - 1), n),
                (l = h.next());
            while (!l.done);
          });
    };
    return e;
  });
  p("Symbol.dispose", function (a) {
    return a ? a : Symbol("Symbol.dispose");
  });
  p("WeakMap", function (a) {
    function b() {}
    function c(l) {
      var m = typeof l;
      return (m === "object" && l !== null) || m === "function";
    }
    function d(l) {
      if (!va(l, f)) {
        var m = new b();
        ba(l, f, { value: m });
      }
    }
    function e(l) {
      var m = Object[l];
      m &&
        (Object[l] = function (n) {
          if (n instanceof b) return n;
          Object.isExtensible(n) && d(n);
          return m(n);
        });
    }
    if (
      (function () {
        if (!a || !Object.seal) return !1;
        try {
          var l = Object.seal({}),
            m = Object.seal({}),
            n = new a([
              [l, 2],
              [m, 3],
            ]);
          if (n.get(l) != 2 || n.get(m) != 3) return !1;
          n.delete(l);
          n.set(m, 4);
          return !n.has(l) && n.get(m) == 4;
        } catch (r) {
          return !1;
        }
      })()
    )
      return a;
    var f = "$jscomp_hidden_" + Math.random();
    e("freeze");
    e("preventExtensions");
    e("seal");
    var g = 0,
      h = function (l) {
        this.g = (g += Math.random() + 1).toString();
        if (l) {
          l = ra(l);
          for (var m; !(m = l.next()).done; )
            (m = m.value), this.set(m[0], m[1]);
        }
      };
    h.prototype.set = function (l, m) {
      if (!c(l)) throw Error("Invalid WeakMap key");
      d(l);
      if (!va(l, f)) throw Error("WeakMap key fail: " + l);
      l[f][this.g] = m;
      return this;
    };
    h.prototype.get = function (l) {
      return c(l) && va(l, f) ? l[f][this.g] : void 0;
    };
    h.prototype.has = function (l) {
      return c(l) && va(l, f) && va(l[f], this.g);
    };
    h.prototype.delete = function (l) {
      return c(l) && va(l, f) && va(l[f], this.g) ? delete l[f][this.g] : !1;
    };
    return h;
  });
  p("Map", function (a) {
    if (
      (function () {
        if (
          !a ||
          typeof a != "function" ||
          !a.prototype.entries ||
          typeof Object.seal != "function"
        )
          return !1;
        try {
          var h = Object.seal({ x: 4 }),
            l = new a(ra([[h, "s"]]));
          if (
            l.get(h) != "s" ||
            l.size != 1 ||
            l.get({ x: 4 }) ||
            l.set({ x: 4 }, "t") != l ||
            l.size != 2
          )
            return !1;
          var m = l.entries(),
            n = m.next();
          if (n.done || n.value[0] != h || n.value[1] != "s") return !1;
          n = m.next();
          return n.done ||
            n.value[0].x != 4 ||
            n.value[1] != "t" ||
            !m.next().done
            ? !1
            : !0;
        } catch (r) {
          return !1;
        }
      })()
    )
      return a;
    var b = new WeakMap(),
      c = function (h) {
        this[0] = {};
        this[1] = f();
        this.size = 0;
        if (h) {
          h = ra(h);
          for (var l; !(l = h.next()).done; )
            (l = l.value), this.set(l[0], l[1]);
        }
      };
    c.prototype.set = function (h, l) {
      h = h === 0 ? 0 : h;
      var m = d(this, h);
      m.list || (m.list = this[0][m.id] = []);
      m.entry
        ? (m.entry.value = l)
        : ((m.entry = {
            next: this[1],
            ta: this[1].ta,
            head: this[1],
            key: h,
            value: l,
          }),
          m.list.push(m.entry),
          (this[1].ta.next = m.entry),
          (this[1].ta = m.entry),
          this.size++);
      return this;
    };
    c.prototype.delete = function (h) {
      h = d(this, h);
      return h.entry && h.list
        ? (h.list.splice(h.index, 1),
          h.list.length || delete this[0][h.id],
          (h.entry.ta.next = h.entry.next),
          (h.entry.next.ta = h.entry.ta),
          (h.entry.head = null),
          this.size--,
          !0)
        : !1;
    };
    c.prototype.clear = function () {
      this[0] = {};
      this[1] = this[1].ta = f();
      this.size = 0;
    };
    c.prototype.has = function (h) {
      return !!d(this, h).entry;
    };
    c.prototype.get = function (h) {
      return (h = d(this, h).entry) && h.value;
    };
    c.prototype.entries = function () {
      return e(this, function (h) {
        return [h.key, h.value];
      });
    };
    c.prototype.keys = function () {
      return e(this, function (h) {
        return h.key;
      });
    };
    c.prototype.values = function () {
      return e(this, function (h) {
        return h.value;
      });
    };
    c.prototype.forEach = function (h, l) {
      for (var m = this.entries(), n; !(n = m.next()).done; )
        (n = n.value), h.call(l, n[1], n[0], this);
    };
    c.prototype[Symbol.iterator] = c.prototype.entries;
    var d = function (h, l) {
        var m = l && typeof l;
        m == "object" || m == "function"
          ? b.has(l)
            ? (m = b.get(l))
            : ((m = "" + ++g), b.set(l, m))
          : (m = "p_" + l);
        var n = h[0][m];
        if (n && va(h[0], m))
          for (h = 0; h < n.length; h++) {
            var r = n[h];
            if ((l !== l && r.key !== r.key) || l === r.key)
              return { id: m, list: n, index: h, entry: r };
          }
        return { id: m, list: n, index: -1, entry: void 0 };
      },
      e = function (h, l) {
        var m = h[1];
        return ha(function () {
          if (m) {
            for (; m.head != h[1]; ) m = m.ta;
            for (; m.next != m.head; )
              return (m = m.next), { done: !1, value: l(m) };
            m = null;
          }
          return { done: !0, value: void 0 };
        });
      },
      f = function () {
        var h = {};
        return (h.ta = h.next = h.head = h);
      },
      g = 0;
    return c;
  });
  p("Array.prototype.find", function (a) {
    return a
      ? a
      : function (b, c) {
          a: {
            var d = this;
            d instanceof String && (d = String(d));
            for (var e = d.length, f = 0; f < e; f++) {
              var g = d[f];
              if (b.call(c, g, f, d)) {
                b = g;
                break a;
              }
            }
            b = void 0;
          }
          return b;
        };
  });
  p("Object.values", function (a) {
    return a
      ? a
      : function (b) {
          var c = [],
            d;
          for (d in b) va(b, d) && c.push(b[d]);
          return c;
        };
  });
  p("Object.is", function (a) {
    return a
      ? a
      : function (b, c) {
          return b === c ? b !== 0 || 1 / b === 1 / c : b !== b && c !== c;
        };
  });
  p("Array.prototype.includes", function (a) {
    return a
      ? a
      : function (b, c) {
          var d = this;
          d instanceof String && (d = String(d));
          var e = d.length;
          c = c || 0;
          for (c < 0 && (c = Math.max(c + e, 0)); c < e; c++) {
            var f = d[c];
            if (f === b || Object.is(f, b)) return !0;
          }
          return !1;
        };
  });
  p("String.prototype.includes", function (a) {
    return a
      ? a
      : function (b, c) {
          if (this == null)
            throw new TypeError(
              "The 'this' value for String.prototype.includes must not be null or undefined"
            );
          if (b instanceof RegExp)
            throw new TypeError(
              "First argument to String.prototype.includes must not be a regular expression"
            );
          return (this + "").indexOf(b, c || 0) !== -1;
        };
  });
  p("Array.from", function (a) {
    return a
      ? a
      : function (b, c, d) {
          c =
            c != null
              ? c
              : function (h) {
                  return h;
                };
          var e = [],
            f =
              typeof Symbol != "undefined" &&
              Symbol.iterator &&
              b[Symbol.iterator];
          if (typeof f == "function") {
            b = f.call(b);
            for (var g = 0; !(f = b.next()).done; )
              e.push(c.call(d, f.value, g++));
          } else
            for (f = b.length, g = 0; g < f; g++) e.push(c.call(d, b[g], g));
          return e;
        };
  });
  p("Number.isFinite", function (a) {
    return a
      ? a
      : function (b) {
          return typeof b !== "number"
            ? !1
            : !isNaN(b) && b !== Infinity && b !== -Infinity;
        };
  });
  p("Number.MAX_SAFE_INTEGER", function () {
    return 9007199254740991;
  });
  p("Number.MIN_SAFE_INTEGER", function () {
    return -9007199254740991;
  });
  var xa = function (a, b) {
    a instanceof String && (a += "");
    var c = 0,
      d = !1,
      e = {
        next: function () {
          if (!d && c < a.length) {
            var f = c++;
            return { value: b(f, a[f]), done: !1 };
          }
          d = !0;
          return { done: !0, value: void 0 };
        },
      };
    e[Symbol.iterator] = function () {
      return e;
    };
    return e;
  };
  p("Number.isNaN", function (a) {
    return a
      ? a
      : function (b) {
          return typeof b === "number" && isNaN(b);
        };
  });
  p("Array.prototype.keys", function (a) {
    return a
      ? a
      : function () {
          return xa(this, function (b) {
            return b;
          });
        };
  });
  p("Array.prototype.values", function (a) {
    return a
      ? a
      : function () {
          return xa(this, function (b, c) {
            return c;
          });
        };
  }); /*

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/
  var u = this || self,
    v = function (a, b, c) {
      a = a.split(".");
      c = c || u;
      for (var d; a.length && (d = a.shift()); )
        a.length || b === void 0
          ? c[d] && c[d] !== Object.prototype[d]
            ? (c = c[d])
            : (c = c[d] = {})
          : (c[d] = b);
    },
    za = function (a, b) {
      var c = y("CLOSURE_FLAGS");
      a = c && c[a];
      return a != null ? a : b;
    },
    y = function (a, b) {
      a = a.split(".");
      b = b || u;
      for (var c = 0; c < a.length; c++)
        if (((b = b[a[c]]), b == null)) return null;
      return b;
    },
    Aa = function (a) {
      var b = typeof a;
      return b != "object" ? b : a ? (Array.isArray(a) ? "array" : b) : "null";
    },
    Ba = function (a) {
      var b = Aa(a);
      return b == "array" || (b == "object" && typeof a.length == "number");
    },
    Ca = function (a) {
      var b = typeof a;
      return (b == "object" && a != null) || b == "function";
    },
    Ha = function (a) {
      return (
        (Object.prototype.hasOwnProperty.call(a, Da) && a[Da]) || (a[Da] = ++Ea)
      );
    },
    Da = "closure_uid_" + ((Math.random() * 1e9) >>> 0),
    Ea = 0,
    Ia = function (a, b, c) {
      return a.call.apply(a.bind, arguments);
    },
    Ja = function (a, b, c) {
      if (!a) throw Error();
      if (arguments.length > 2) {
        var d = Array.prototype.slice.call(arguments, 2);
        return function () {
          var e = Array.prototype.slice.call(arguments);
          Array.prototype.unshift.apply(e, d);
          return a.apply(b, e);
        };
      }
      return function () {
        return a.apply(b, arguments);
      };
    },
    z = function (a, b, c) {
      z =
        Function.prototype.bind &&
        Function.prototype.bind.toString().indexOf("native code") != -1
          ? Ia
          : Ja;
      return z.apply(null, arguments);
    },
    Ka = function (a, b) {
      var c = Array.prototype.slice.call(arguments, 1);
      return function () {
        var d = c.slice();
        d.push.apply(d, arguments);
        return a.apply(this, d);
      };
    },
    A = function () {
      return Date.now();
    },
    B = function (a, b) {
      function c() {}
      c.prototype = b.prototype;
      a.X = b.prototype;
      a.prototype = new c();
      a.prototype.constructor = a;
      a.Sf = function (d, e, f) {
        for (
          var g = Array(arguments.length - 2), h = 2;
          h < arguments.length;
          h++
        )
          g[h - 2] = arguments[h];
        return b.prototype[e].apply(d, g);
      };
    };
  function La(a, b) {
    if (Error.captureStackTrace) Error.captureStackTrace(this, La);
    else {
      var c = Error().stack;
      c && (this.stack = c);
    }
    a && (this.message = String(a));
    b !== void 0 && (this.cause = b);
  }
  B(La, Error);
  La.prototype.name = "CustomError";
  var Ma;
  var Na = function (a, b) {
      if (typeof a === "string")
        return typeof b !== "string" || b.length != 1 ? -1 : a.indexOf(b, 0);
      for (var c = 0; c < a.length; c++) if (c in a && a[c] === b) return c;
      return -1;
    },
    C = function (a, b, c) {
      for (
        var d = a.length, e = typeof a === "string" ? a.split("") : a, f = 0;
        f < d;
        f++
      )
        f in e && b.call(c, e[f], f, a);
    },
    Oa = function (a, b) {
      for (
        var c = a.length,
          d = [],
          e = 0,
          f = typeof a === "string" ? a.split("") : a,
          g = 0;
        g < c;
        g++
      )
        if (g in f) {
          var h = f[g];
          b.call(void 0, h, g, a) && (d[e++] = h);
        }
      return d;
    },
    Pa = function (a, b) {
      for (
        var c = a.length,
          d = Array(c),
          e = typeof a === "string" ? a.split("") : a,
          f = 0;
        f < c;
        f++
      )
        f in e && (d[f] = b.call(void 0, e[f], f, a));
      return d;
    },
    Qa = function (a, b) {
      for (
        var c = a.length, d = typeof a === "string" ? a.split("") : a, e = 0;
        e < c;
        e++
      )
        if (e in d && b.call(void 0, d[e], e, a)) return !0;
      return !1;
    },
    Ra = function (a, b) {
      for (
        var c = a.length, d = typeof a === "string" ? a.split("") : a, e = 0;
        e < c;
        e++
      )
        if (e in d && !b.call(void 0, d[e], e, a)) return !1;
      return !0;
    };
  function Sa(a, b) {
    a: {
      for (
        var c = a.length, d = typeof a === "string" ? a.split("") : a, e = 0;
        e < c;
        e++
      )
        if (e in d && b.call(void 0, d[e], e, a)) {
          b = e;
          break a;
        }
      b = -1;
    }
    return b < 0 ? null : typeof a === "string" ? a.charAt(b) : a[b];
  }
  function Ta(a, b) {
    b = Na(a, b);
    var c;
    (c = b >= 0) && Array.prototype.splice.call(a, b, 1);
    return c;
  }
  function Ua(a) {
    return Array.prototype.concat.apply([], arguments);
  }
  function Va(a) {
    var b = a.length;
    if (b > 0) {
      for (var c = Array(b), d = 0; d < b; d++) c[d] = a[d];
      return c;
    }
    return [];
  }
  function Wa(a, b) {
    C(a, function (c, d) {
      b.call(void 0, c, d, a);
    });
  }
  function Xa(a) {
    u.setTimeout(function () {
      throw a;
    }, 0);
  }
  function E(a) {
    return /^[\s\xa0]*$/.test(a);
  }
  var Ya = function (a) {
    return /^[\s\xa0]*([\s\S]*?)[\s\xa0]*$/.exec(a)[1];
  };
  function Za(a, b) {
    var c = 0;
    a = Ya(String(a)).split(".");
    b = Ya(String(b)).split(".");
    for (var d = Math.max(a.length, b.length), e = 0; c == 0 && e < d; e++) {
      var f = a[e] || "",
        g = b[e] || "";
      do {
        f = /(\d*)(\D*)(.*)/.exec(f) || ["", "", "", ""];
        g = /(\d*)(\D*)(.*)/.exec(g) || ["", "", "", ""];
        if (f[0].length == 0 && g[0].length == 0) break;
        c =
          $a(
            f[1].length == 0 ? 0 : parseInt(f[1], 10),
            g[1].length == 0 ? 0 : parseInt(g[1], 10)
          ) ||
          $a(f[2].length == 0, g[2].length == 0) ||
          $a(f[2], g[2]);
        f = f[3];
        g = g[3];
      } while (c == 0);
    }
    return c;
  }
  function $a(a, b) {
    return a < b ? -1 : a > b ? 1 : 0;
  }
  var ab = za(610401301, !1),
    bb = za(748402147, za(1, !0));
  function eb() {
    var a = u.navigator;
    return a && (a = a.userAgent) ? a : "";
  }
  var fb,
    gb = u.navigator;
  fb = gb ? gb.userAgentData || null : null;
  function hb(a) {
    if (!ab || !fb) return !1;
    for (var b = 0; b < fb.brands.length; b++) {
      var c = fb.brands[b].brand;
      if (c && c.indexOf(a) != -1) return !0;
    }
    return !1;
  }
  function F(a) {
    return eb().indexOf(a) != -1;
  }
  function ib() {
    return ab ? !!fb && fb.brands.length > 0 : !1;
  }
  function jb() {
    return ib() ? !1 : F("Opera");
  }
  function kb() {
    return ib() ? !1 : F("Trident") || F("MSIE");
  }
  function lb() {
    return F("Firefox") || F("FxiOS");
  }
  function mb() {
    return ib()
      ? hb("Chromium")
      : ((F("Chrome") || F("CriOS")) && !(ib() ? 0 : F("Edge"))) || F("Silk");
  }
  function nb() {
    var a = eb();
    if (kb()) {
      var b = /rv: *([\d\.]*)/.exec(a);
      if (b && b[1]) a = b[1];
      else {
        b = "";
        var c = /MSIE +([\d\.]+)/.exec(a);
        if (c && c[1])
          if (((a = /Trident\/(\d.\d)/.exec(a)), c[1] == "7.0"))
            if (a && a[1])
              switch (a[1]) {
                case "4.0":
                  b = "8.0";
                  break;
                case "5.0":
                  b = "9.0";
                  break;
                case "6.0":
                  b = "10.0";
                  break;
                case "7.0":
                  b = "11.0";
              }
            else b = "7.0";
          else b = c[1];
        a = b;
      }
    } else a = "";
    return a;
  }
  function ob() {
    if (ib()) {
      var a = fb.brands.find(function (b) {
        return b.brand === "Internet Explorer";
      });
      if (!a || !a.version) return NaN;
      a = a.version.split(".");
    } else {
      a = nb();
      if (a === "") return NaN;
      a = a.split(".");
    }
    return a.length === 0 ? NaN : Number(a[0]);
  }
  function pb() {
    return F("iPhone") && !F("iPod") && !F("iPad");
  }
  var rb = function (a, b) {
    var c = qb;
    return Object.prototype.hasOwnProperty.call(c, a) ? c[a] : (c[a] = b(a));
  };
  var sb = jb(),
    tb = kb(),
    ub = F("Edge"),
    vb =
      F("Gecko") &&
      !(eb().toLowerCase().indexOf("webkit") != -1 && !F("Edge")) &&
      !(F("Trident") || F("MSIE")) &&
      !F("Edge"),
    wb = eb().toLowerCase().indexOf("webkit") != -1 && !F("Edge"),
    xb = ab && fb && fb.platform ? fb.platform === "Android" : F("Android"),
    yb = pb(),
    zb = F("iPad"),
    Ab = function () {
      var a = u.document;
      return a ? a.documentMode : void 0;
    },
    Eb;
  a: {
    var Fb = "",
      Gb = (function () {
        var a = eb();
        if (vb) return /rv:([^\);]+)(\)|;)/.exec(a);
        if (ub) return /Edge\/([\d\.]+)/.exec(a);
        if (tb) return /\b(?:MSIE|rv)[: ]([^\);]+)(\)|;)/.exec(a);
        if (wb) return /WebKit\/(\S+)/.exec(a);
        if (sb) return /(?:Version)[ \/]?(\S+)/.exec(a);
      })();
    Gb && (Fb = Gb ? Gb[1] : "");
    if (tb) {
      var Hb = Ab();
      if (Hb != null && Hb > parseFloat(Fb)) {
        Eb = String(Hb);
        break a;
      }
    }
    Eb = Fb;
  }
  var Ib = Eb,
    qb = {},
    Jb = function (a) {
      return rb(a, function () {
        return Za(Ib, a) >= 0;
      });
    },
    Kb;
  if (u.document && tb) {
    var Lb = Ab();
    Kb = Lb ? Lb : parseInt(Ib, 10) || void 0;
  } else Kb = void 0;
  var Mb = Kb;
  var Nb = lb(),
    Ob = pb() || F("iPod"),
    Pb = F("iPad"),
    Qb = F("Android") && !(mb() || lb() || jb() || F("Silk")),
    Rb = mb(),
    Sb =
      F("Safari") &&
      !(
        mb() ||
        (ib() ? 0 : F("Coast")) ||
        jb() ||
        (ib() ? 0 : F("Edge")) ||
        (ib() ? hb("Microsoft Edge") : F("Edg/")) ||
        (ib() ? hb("Opera") : F("OPR")) ||
        lb() ||
        F("Silk") ||
        F("Android")
      ) &&
      !(pb() || F("iPad") || F("iPod"));
  var Tb = typeof structuredClone != "undefined";
  function Ub(a, b) {
    a.__closure__error__context__984382 ||
      (a.__closure__error__context__984382 = {});
    a.__closure__error__context__984382.severity = b;
  }
  var Vb = void 0;
  function Wb() {
    var a = Error("int32");
    Ub(a, "warning");
    return a;
  }
  var Xb = typeof Symbol === "function" && typeof Symbol() === "symbol";
  function Yb(a, b, c) {
    return typeof Symbol === "function" && typeof Symbol() === "symbol"
      ? (c === void 0 ? 0 : c) && Symbol.for && a
        ? Symbol.for(a)
        : a != null
        ? Symbol(a)
        : Symbol()
      : b;
  }
  var Zb = Yb("jas", void 0, !0),
    $b = Yb(void 0, "0actk"),
    ac = Yb("m_m", "Uf", !0);
  Math.max.apply(
    Math,
    sa(
      Object.values({
        hf: 1,
        df: 2,
        cf: 4,
        pf: 8,
        Hf: 16,
        mf: 32,
        te: 64,
        Qe: 128,
        Le: 256,
        Ef: 512,
        Me: 1024,
        Re: 2048,
        nf: 4096,
      })
    )
  );
  var bc = { Jd: { value: 0, configurable: !0, writable: !0, enumerable: !1 } },
    dc = Object.defineProperties,
    G = Xb ? Zb : "Jd";
  function ec(a, b) {
    Xb || G in a || dc(a, bc);
    a[G] |= b;
  }
  function fc(a, b) {
    Xb || G in a || dc(a, bc);
    a[G] = b;
  }
  var hc = {};
  function ic(a, b) {
    return b === void 0
      ? a.g !== jc && !!(2 & (a.aa[G] | 0))
      : !!(2 & b) && a.g !== jc;
  }
  var jc = {};
  var kc = typeof u.BigInt === "function" && typeof u.BigInt(0) === "bigint";
  var lc = Number.MIN_SAFE_INTEGER.toString(),
    mc = kc ? BigInt(Number.MIN_SAFE_INTEGER) : void 0,
    nc = Number.MAX_SAFE_INTEGER.toString(),
    oc = kc ? BigInt(Number.MAX_SAFE_INTEGER) : void 0;
  function pc(a, b) {
    if (a.length > b.length) return !1;
    if (a.length < b.length || a === b) return !0;
    for (var c = 0; c < a.length; c++) {
      var d = a[c],
        e = b[c];
      if (d > e) return !1;
      if (d < e) return !0;
    }
  }
  var qc = Number.isFinite;
  function rc(a) {
    return a.displayName || a.name || "unknown type name";
  }
  function sc(a) {
    if (typeof a !== "number") throw Wb();
    if (!qc(a)) throw Wb();
    return a | 0;
  }
  function tc(a) {
    if (a != null && typeof a !== "string") throw Error();
    return a;
  }
  function uc(a) {
    return a;
  }
  function vc(a, b, c, d) {
    var e = d !== void 0;
    d = !!d;
    var f = [],
      g = a.length,
      h = 4294967295,
      l = !1,
      m = !!(b & 64),
      n = m ? (b & 128 ? 0 : -1) : void 0;
    if (!(b & 1)) {
      var r = g && a[g - 1];
      r != null && typeof r === "object" && r.constructor === Object
        ? (g--, (h = g))
        : (r = void 0);
      if (m && !(b & 128) && !e) {
        l = !0;
        var D;
        h = ((D = wc) != null ? D : uc)(h - n, n, a, r, void 0) + n;
      }
    }
    b = void 0;
    for (e = 0; e < g; e++)
      if (((D = a[e]), D != null && (D = c(D, d)) != null))
        if (m && e >= h) {
          var K = e - n,
            ya = void 0;
          ((ya = b) != null ? ya : (b = {}))[K] = D;
        } else f[e] = D;
    if (r)
      for (var qa in r)
        Object.prototype.hasOwnProperty.call(r, qa) &&
          ((a = r[qa]),
          a != null &&
            (a = c(a, d)) != null &&
            ((g = +qa),
            (e = void 0),
            m && !Number.isNaN(g) && (e = g + n) < h
              ? (f[e] = a)
              : ((g = void 0), (((g = b) != null ? g : (b = {}))[qa] = a))));
    b && (l ? f.push(b) : (f[h] = b));
    return f;
  }
  function xc(a) {
    switch (typeof a) {
      case "number":
        return Number.isFinite(a) ? a : "" + a;
      case "bigint":
        return (kc ? a >= mc && a <= oc : a[0] === "-" ? pc(a, lc) : pc(a, nc))
          ? Number(a)
          : "" + a;
      case "boolean":
        return a ? 1 : 0;
      case "object":
        if (Array.isArray(a)) {
          var b = a[G] | 0;
          return a.length === 0 && b & 1 ? void 0 : vc(a, b, xc);
        }
        if (a != null && a[ac] === hc) return yc(a);
        return;
    }
    return a;
  }
  var zc = Tb
      ? structuredClone
      : function (a) {
          return vc(a, 0, xc);
        },
    wc;
  function yc(a) {
    a = a.aa;
    return vc(a, a[G] | 0, xc);
  }
  function Ac(a, b, c) {
    var d = d === void 0 ? 0 : d;
    if (a == null) {
      var e = 32;
      c ? ((a = [c]), (e |= 128)) : (a = []);
      b && (e = (e & -8380417) | ((b & 1023) << 13));
    } else {
      if (!Array.isArray(a)) throw Error("narr");
      e = a[G] | 0;
      if (bb && 1 & e) throw Error("rfarr");
      2048 & e && !(2 & e) && Bc();
      if (e & 256) throw Error("farr");
      if (e & 64) return d !== 0 || e & 2048 || fc(a, e | 2048), a;
      if (c && ((e |= 128), c !== a[0])) throw Error("mid");
      a: {
        c = a;
        e |= 64;
        var f = c.length;
        if (f) {
          var g = f - 1,
            h = c[g];
          if (h != null && typeof h === "object" && h.constructor === Object) {
            b = e & 128 ? 0 : -1;
            g -= b;
            if (g >= 1024) throw Error("pvtlmt");
            for (var l in h)
              Object.prototype.hasOwnProperty.call(h, l) &&
                ((f = +l), f < g && ((c[f + b] = h[l]), delete h[l]));
            e = (e & -8380417) | ((g & 1023) << 13);
            break a;
          }
        }
        if (b) {
          l = Math.max(b, f - (e & 128 ? 0 : -1));
          if (l > 1024) throw Error("spvt");
          e = (e & -8380417) | ((l & 1023) << 13);
        }
      }
    }
    e |= 64;
    d === 0 && (e |= 2048);
    fc(a, e);
    return a;
  }
  function Bc() {
    if (bb) throw Error("carr");
    if ($b != null) {
      var a;
      var b = (a = Vb) != null ? a : (Vb = {});
      a = b[$b] || 0;
      a >= 5 || ((b[$b] = a + 1), (b = Error()), Ub(b, "incident"), Xa(b));
    }
  }
  function Cc(a, b) {
    if (typeof a !== "object") return a;
    if (Array.isArray(a)) {
      var c = a[G] | 0;
      a.length === 0 && c & 1
        ? (a = void 0)
        : c & 2 ||
          (!b || 4096 & c || 16 & c
            ? (a = Dc(a, c, !1, b && !(c & 16)))
            : (ec(a, 34), c & 4 && Object.freeze(a)));
      return a;
    }
    if (a != null && a[ac] === hc) {
      b = a.aa;
      c = b[G] | 0;
      if (!ic(a, c)) {
        if (c & 2) var d = !0;
        else
          !(c & 32) || c & 4096
            ? (d = !1)
            : (fc(b, c | 2), (a.g = jc), (d = !0));
        d ? ((a = new a.constructor(b)), (a.j = jc)) : (a = Dc(b, c));
      }
      return a;
    }
  }
  function Dc(a, b, c, d) {
    d != null || (d = !!(34 & b));
    a = vc(a, b, Cc, d);
    d = 32;
    c && (d |= 2);
    b = (b & 8380609) | d;
    fc(a, b);
    return a;
  }
  function Ec(a) {
    if (a.g === jc) {
      var b = a.aa;
      b = Dc(b, b[G] | 0);
      ec(b, 2048);
      a.aa = b;
      a.g = void 0;
      a.j = void 0;
      b = !0;
    } else b = !1;
    if (!b && ic(a, a.aa[G] | 0)) throw Error();
  }
  var Gc = function (a, b, c) {
    Ec(a);
    a = a.aa;
    Fc(a, a[G] | 0, b, c);
  };
  function Fc(a, b, c, d) {
    var e = c + -1,
      f = a.length - 1;
    if (f >= 0 && e >= f) {
      var g = a[f];
      if (g != null && typeof g === "object" && g.constructor === Object) {
        g[c] = d;
        return;
      }
    }
    e <= f
      ? (a[e] = d)
      : d !== void 0 &&
        ((b = ((b != null ? b : a[G] | 0) >> 13) & 1023 || 536870912),
        c >= b
          ? d != null && ((e = {}), (a[b + -1] = ((e[c] = d), e)))
          : (a[e] = d));
  }
  function Hc(a, b, c, d) {
    Ec(a);
    var e = a.aa;
    Fc(e, e[G] | 0, b, (d === "0" ? Number(c) === 0 : c === d) ? void 0 : c);
    return a;
  }
  var Ic = function (a, b, c) {
    Gc(a, b, tc(c));
  };
  var Jc = function (a, b, c) {
    this.aa = Ac(a, b, c);
  };
  Jc.prototype.toJSON = function () {
    return yc(this);
  };
  var Kc = function (a) {
    return JSON.stringify(yc(a));
  };
  Jc.prototype[ac] = hc;
  Jc.prototype.toString = function () {
    return this.aa.toString();
  };
  function Lc(a, b) {
    if (b == null) return new a();
    if (!Array.isArray(b)) throw Error();
    if (Object.isFrozen(b) || Object.isSealed(b) || !Object.isExtensible(b))
      throw Error();
    ec(b, 32);
    return new a(b);
  }
  var Mc = function (a) {
    this.aa = Ac(a);
  };
  q(Mc, Jc);
  var Nc = function (a) {
    this.aa = Ac(a);
  };
  q(Nc, Jc);
  var Oc = function (a) {
    var b = "&rmfb=" + (typeof window.vv).substr(0, 3);
    return a.substring(a.length - 7) == "&adurl="
      ? a.substring(0, a.length - 7) + b + "&adurl="
      : a + b;
  };
  function Pc(a) {
    return (a = a === void 0 ? window : a);
  }
  var Qc = function () {},
    Rc = function () {
      var a = escape,
        b = 1;
      b = b || 0;
      return function () {
        return a.apply(this, Array.prototype.slice.call(arguments, 0, b));
      };
    },
    Sc = function (a) {
      var b = !1,
        c;
      return function () {
        b || ((c = a()), (b = !0));
        return c;
      };
    }; /*

 Copyright Google LLC
 SPDX-License-Identifier: Apache-2.0
*/
  var Xc = globalThis.trustedTypes,
    Yc;
  function Zc() {
    var a = null;
    if (!Xc) return a;
    try {
      var b = function (c) {
        return c;
      };
      a = Xc.createPolicy("goog#html", {
        createHTML: b,
        createScript: b,
        createScriptURL: b,
      });
    } catch (c) {}
    return a;
  }
  function $c() {
    Yc === void 0 && (Yc = Zc());
    return Yc;
  }
  var ad = function (a) {
    this.g = a;
  };
  ad.prototype.toString = function () {
    return this.g + "";
  };
  function bd(a) {
    var b = $c();
    a = b ? b.createScriptURL(a) : a;
    return new ad(a);
  }
  function cd(a) {
    if (a instanceof ad) return a.g;
    throw Error("");
  }
  var dd = /^\s*(?!javascript:)(?:[\w+.-]+:|[^:/?#]*(?:[/?#]|$))/i;
  var ed = function (a) {
    this.g = a;
  };
  ed.prototype.toString = function () {
    return this.g + "";
  };
  function fd(a) {
    var b = $c();
    a = b ? b.createHTML(a) : a;
    return new ed(a);
  }
  function gd(a) {
    if (a instanceof ed) return a.g;
    throw Error("");
  }
  function hd(a, b) {
    a.src = cd(b);
    var c;
    b = a.ownerDocument;
    b = b === void 0 ? document : b;
    var d;
    b =
      (d = (c = b).querySelector) == null ? void 0 : d.call(c, "script[nonce]");
    (c = b == null ? "" : b.nonce || b.getAttribute("nonce") || "") &&
      a.setAttribute("nonce", c);
  }
  function id(a, b) {
    if (a.nodeType === 1 && /^(script|style)$/i.test(a.tagName))
      throw Error("");
    a.innerHTML = gd(b);
  }
  var jd = String.prototype.repeat
      ? function (a, b) {
          return a.repeat(b);
        }
      : function (a, b) {
          return Array(b + 1).join(a);
        },
    H = function (a) {
      return a == null ? "" : String(a);
    },
    kd = function (a) {
      return String(a).replace(/\-([a-z])/g, function (b, c) {
        return c.toUpperCase();
      });
    },
    ld = function (a) {
      return a.replace(RegExp("(^|[\\s]+)([a-z])", "g"), function (b, c, d) {
        return c + d.toUpperCase();
      });
    };
  function md(a, b, c) {
    for (var d in a) b.call(c, a[d], d, a);
  }
  function nd(a, b) {
    var c = {},
      d;
    for (d in a) c[d] = b.call(void 0, a[d], d, a);
    return c;
  }
  function od(a, b) {
    for (var c in a) if (!b.call(void 0, a[c], c, a)) return !1;
    return !0;
  }
  function pd(a) {
    var b = [],
      c = 0,
      d;
    for (d in a) b[c++] = a[d];
    return b;
  }
  function qd(a) {
    for (var b in a) return !1;
    return !0;
  }
  var rd =
    "constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(
      " "
    );
  function sd(a, b) {
    for (var c, d, e = 1; e < arguments.length; e++) {
      d = arguments[e];
      for (c in d) a[c] = d[c];
      for (var f = 0; f < rd.length; f++)
        (c = rd[f]),
          Object.prototype.hasOwnProperty.call(d, c) && (a[c] = d[c]);
    }
  }
  function td(a) {
    if (a instanceof ed) return a;
    a = String(a)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&apos;");
    return fd(a);
  }
  function ud(a) {
    return vd(a);
  }
  function vd(a) {
    var b = td("");
    return fd(
      a
        .map(function (c) {
          return gd(td(c));
        })
        .join(gd(b).toString())
    );
  }
  var wd = /^[a-z][a-z\d-]*$/i,
    xd =
      "APPLET BASE EMBED IFRAME LINK MATH META OBJECT SCRIPT STYLE SVG TEMPLATE".split(
        " "
      ),
    yd = "AREA BR COL COMMAND HR IMG INPUT KEYGEN PARAM SOURCE TRACK WBR".split(
      " "
    ),
    zd = ["action", "formaction", "href"];
  function Ad(a) {
    var b;
    if (!wd.test("div")) throw Error("");
    if (xd.indexOf("DIV") !== -1) throw Error("");
    var c = "<div";
    a && (c += Bd(a));
    Array.isArray(b) || (b = b === void 0 ? [] : [b]);
    yd.indexOf("DIV") !== -1
      ? (c += ">")
      : ((a = ud(
          b.map(function (d) {
            return d instanceof ed ? d : td(String(d));
          })
        )),
        (c += ">" + a.toString() + "</div>"));
    return fd(c);
  }
  function Bd(a) {
    for (var b = "", c = Object.keys(a), d = 0; d < c.length; d++) {
      var e = c[d],
        f = a[e];
      if (!wd.test(e)) throw Error("");
      if (f !== void 0 && f !== null) {
        if (/^on./i.test(e)) throw Error("");
        zd.indexOf(e.toLowerCase()) !== -1 &&
          ((f = String(f)),
          (f = dd.test(f) ? f : void 0),
          (f = f || "about:invalid#zClosurez"));
        e = e + '="' + td(String(f)) + '"';
        b += " " + e;
      }
    }
    return b;
  }
  function Cd(a) {
    var b = wa.apply(1, arguments);
    if (b.length === 0) return bd(a[0]);
    for (var c = a[0], d = 0; d < b.length; d++)
      c += encodeURIComponent(b[d]) + a[d + 1];
    return bd(c);
  }
  var Dd = function (a, b) {
    b = b === void 0 ? document : b;
    return b.createElement(String(a).toLowerCase());
  };
  function Ed() {
    var a = a === void 0 ? window : a;
    if (a.interstitialAdFrame) {
      var b;
      return (b = a.interstitialAdFrame) != null ? b : null;
    }
    try {
      var c;
      return (c = a.parent.interstitialAdFrame) != null ? c : null;
    } catch (d) {}
    return null;
  }
  var Fd = function (a) {
    this.aa = Ac(a);
  };
  q(Fd, Jc);
  var Gd = function (a, b) {
      this.D = a;
      this.v = b;
      this.o = {};
      this.B = !1;
    },
    Jd = function (a) {
      a.B = !0;
      for (var b in a.o) a.o[b].handler && Hd(a, b), Id(a, b);
    },
    Ld = function (a, b) {
      var c = b.n;
      switch (b.t) {
        case 1:
          b = b.d;
          Kd(a, c).handler(b);
          break;
        case 2:
          (Kd(a, c).qb = !0), Id(a, c);
      }
    },
    Kd = function (a, b) {
      a.o[b] || (a.o[b] = { qb: !1, mb: [], handler: null });
      return a.o[b];
    },
    Id = function (a, b) {
      var c = Kd(a, b);
      if (c.qb) {
        for (var d = c.mb.length, e = 0; e < d; e++) a.sendMessage(b, c.mb[e]);
        c.mb = [];
      }
    },
    Hd = function (a, b) {
      if (a.B) {
        var c = {};
        b = ((c.t = 2), (c.s = a.v), (c.n = b), c);
        a.A(b);
      }
    };
  Gd.prototype.registerApplicationHandler = function (a, b) {
    Kd(this, a).handler = b;
    Hd(this, a);
  };
  Gd.prototype.sendMessage = function (a, b) {
    var c = Kd(this, a);
    this.B && c.qb
      ? ((c = {}),
        (a = ((c.t = 1), (c.s = this.v), (c.n = a), (c.d = b), c)),
        this.A(a))
      : c.mb.push(b);
  };
  Gd.prototype.isInitialized = function () {
    return this.B;
  };
  var Nd = function (a, b, c) {
    c = c === void 0 ? !0 : c;
    Gd.call(this, a, b);
    var d = this;
    this.F = c && !!window.MessageChannel;
    this.j = this.g = null;
    window.addEventListener &&
      ((this.C = function (e) {
        var f = e.data;
        f.s === d.v &&
          (d.F ? e.source === d.D : e.source.parent === d.D) &&
          (f.t === 0 ? Md(d, e) && Jd(d) : ((d.j = e), Ld(d, f)));
      }),
      window.addEventListener("message", this.C, !1),
      (this.G = !1));
  };
  q(Nd, Gd);
  Nd.prototype.A = function (a) {
    this.F
      ? this.g && this.g.postMessage(a)
      : this.j.source.parent.postMessage(a, "*");
  };
  var Md = function (a, b) {
    if (a.F) {
      a.g = b.ports && b.ports[0];
      if (!a.g) return !1;
      a.g.addEventListener(
        "message",
        z(function (c) {
          Ld(this, c.data);
        }, a),
        !1
      );
      a.g.start();
    } else a.j = b;
    return !0;
  };
  Nd.prototype.dispose = function () {
    window.removeEventListener("message", this.C, !1);
    delete this.C;
    delete this.g;
    delete this.j;
    this.G = !0;
  };
  Nd.prototype.L = function () {
    return this.G;
  };
  var Od = function (a, b) {
    this.x = a !== void 0 ? a : 0;
    this.y = b !== void 0 ? b : 0;
  };
  Od.prototype.ceil = function () {
    this.x = Math.ceil(this.x);
    this.y = Math.ceil(this.y);
    return this;
  };
  Od.prototype.floor = function () {
    this.x = Math.floor(this.x);
    this.y = Math.floor(this.y);
    return this;
  };
  Od.prototype.round = function () {
    this.x = Math.round(this.x);
    this.y = Math.round(this.y);
    return this;
  };
  var I = function (a, b) {
      this.width = a;
      this.height = b;
    },
    Pd = function (a, b) {
      return a == b
        ? !0
        : a && b
        ? a.width == b.width && a.height == b.height
        : !1;
    },
    Qd = function (a) {
      return new I(a.width, a.height);
    };
  I.prototype.aspectRatio = function () {
    return this.width / this.height;
  };
  I.prototype.ceil = function () {
    this.width = Math.ceil(this.width);
    this.height = Math.ceil(this.height);
    return this;
  };
  I.prototype.floor = function () {
    this.width = Math.floor(this.width);
    this.height = Math.floor(this.height);
    return this;
  };
  I.prototype.round = function () {
    this.width = Math.round(this.width);
    this.height = Math.round(this.height);
    return this;
  };
  var Td = function (a) {
      return a ? new Rd(Sd(a)) : Ma || (Ma = new Rd());
    },
    Ud = function (a, b) {
      return typeof b === "string" ? a.getElementById(b) : b;
    },
    Wd = function (a, b) {
      md(b, function (c, d) {
        d == "style"
          ? (a.style.cssText = c)
          : d == "class"
          ? (a.className = c)
          : d == "for"
          ? (a.htmlFor = c)
          : Vd.hasOwnProperty(d)
          ? a.setAttribute(Vd[d], c)
          : d.lastIndexOf("aria-", 0) == 0 || d.lastIndexOf("data-", 0) == 0
          ? a.setAttribute(d, c)
          : (a[d] = c);
      });
    },
    Vd = {
      cellpadding: "cellPadding",
      cellspacing: "cellSpacing",
      colspan: "colSpan",
      frameborder: "frameBorder",
      height: "height",
      maxlength: "maxLength",
      nonce: "nonce",
      role: "role",
      rowspan: "rowSpan",
      type: "type",
      usemap: "useMap",
      valign: "vAlign",
      width: "width",
    },
    Xd = function (a) {
      a = (a || window).document;
      a = a.compatMode == "CSS1Compat" ? a.documentElement : a.body;
      return new I(a.clientWidth, a.clientHeight);
    },
    Yd = function (a) {
      return a.scrollingElement
        ? a.scrollingElement
        : wb || a.compatMode != "CSS1Compat"
        ? a.body || a.documentElement
        : a.documentElement;
    },
    Zd = function (a, b, c) {
      function d(h) {
        h && b.appendChild(typeof h === "string" ? a.createTextNode(h) : h);
      }
      for (var e = 2; e < c.length; e++) {
        var f = c[e];
        if (!Ba(f) || (Ca(f) && f.nodeType > 0)) d(f);
        else {
          a: {
            if (f && typeof f.length == "number") {
              if (Ca(f)) {
                var g =
                  typeof f.item == "function" || typeof f.item == "string";
                break a;
              }
              if (typeof f === "function") {
                g = typeof f.item == "function";
                break a;
              }
            }
            g = !1;
          }
          C(g ? Va(f) : f, d);
        }
      }
    },
    $d = function (a, b) {
      b = String(b);
      a.contentType === "application/xhtml+xml" && (b = b.toLowerCase());
      return a.createElement(b);
    },
    ae = function (a) {
      a && a.parentNode && a.parentNode.removeChild(a);
    },
    be = function (a, b) {
      if (!a || !b) return !1;
      if (a.contains && b.nodeType == 1) return a == b || a.contains(b);
      if (typeof a.compareDocumentPosition != "undefined")
        return a == b || !!(a.compareDocumentPosition(b) & 16);
      for (; b && a != b; ) b = b.parentNode;
      return b == a;
    },
    Sd = function (a) {
      return a.nodeType == 9 ? a : a.ownerDocument || a.document;
    },
    Rd = function (a) {
      this.g = a || u.document || document;
    };
  Rd.prototype.T = function (a) {
    return Ud(this.g, a);
  };
  Rd.prototype.j = function (a, b, c) {
    var d = this.g,
      e = arguments,
      f = e[1],
      g = $d(d, String(e[0]));
    f &&
      (typeof f === "string"
        ? (g.className = f)
        : Array.isArray(f)
        ? (g.className = f.join(" "))
        : Wd(g, f));
    e.length > 2 && Zd(d, g, e);
    return g;
  };
  var ce = function (a, b) {
    return $d(a.g, b);
  };
  Rd.prototype.appendChild = function (a, b) {
    a.appendChild(b);
  };
  Rd.prototype.contains = be;
  var ee = function (a, b, c, d, e, f) {
    Gd.call(this, a, d);
    var g = this;
    try {
      var h = !!document.cookie;
    } catch (l) {
      h = !1;
    }
    if (
      h &&
      ((a =
        window.location.origin ||
        window.location.protocol + "//" + window.location.host),
      window.secureChannel_allowAnyParent !== !0 &&
        b !== a &&
        c.indexOf(a) === -1)
    )
      throw Error();
    this.I = e && !!window.MessageChannel;
    this.C = b;
    this.g = this.j = null;
    this.F = function (l) {
      var m = l.data;
      m.s !== g.v ||
        l.source !== window.parent ||
        (g.C !== "*" && l.origin !== g.C) ||
        Ld(g, m);
    };
    window.addEventListener("message", this.F, !1);
    f || u.document.readyState == "complete"
      ? de(this)
      : window.addEventListener(
          "load",
          function () {
            de(g);
          },
          !1
        );
    this.G = !1;
  };
  q(ee, Gd);
  var ge = function (a, b, c, d) {
    var e = fe;
    try {
      return new ee(a, b, e, c, d === void 0 ? !0 : d, !1);
    } catch (f) {
      return null;
    }
  };
  ee.prototype.A = function (a) {
    this.I
      ? this.j && this.j.postMessage(a)
      : this.g.contentWindow.postMessage(a, "*");
  };
  var de = function (a) {
    var b = { t: 0 };
    b.s = a.v;
    if (a.I) {
      var c = new MessageChannel();
      a.j = c.port1;
      a.j.onmessage = function (f) {
        Ld(a, f.data);
      };
      a.D.postMessage(b, a.C, [c.port2]);
      Jd(a);
    } else {
      a.g = $d(document, "IFRAME");
      a.g.style.display = "none";
      c =
        '<!doctype html><html><head><script>window.addEventListener("message",function(e){e.source.parent.postMessage(e.data,' +
        JSON.stringify(a.C) +
        ");},false);\x3c/script></head><body></body></html>";
      var d = a.g;
      var e = fd(c);
      d.srcdoc = gd(e);
      a.g.src = "javascript:'" + encodeURI(c) + "'";
      a.g.onload = function () {
        a.A(b);
        Jd(a);
      };
      document.body.appendChild(a.g);
    }
  };
  ee.prototype.dispose = function () {
    window.removeEventListener("message", this.F, !1);
    delete this.F;
    delete this.j;
    delete this.g;
    this.G = !0;
  };
  ee.prototype.L = function () {
    return this.G;
  };
  var he = function (a, b) {
    this.B = Math.random() < a;
    this.C = b;
    this.o = null;
    this.v = "";
  };
  he.prototype.isActive = function () {
    return this.B;
  };
  he.prototype.j = function () {
    return this.isActive() && null !== this.o
      ? (
          this.C +
          "//pagead2.googlesyndication.com/pagead/gen_204/?id=" +
          this.o +
          this.v
        ).substring(0, 2e3)
      : "";
  };
  var ie = function () {},
    le = function (a) {
      je |= a;
      ke(a);
    },
    ke = function (a) {
      ze(a, 2, 1);
      ze(a, 1, 2);
      ze(a, 4, 8);
      ze(a, 8, 4);
      ze(a, 128, 64);
      ze(a, 64, 128);
      ze(a, 256, 2);
    },
    ze = function (a, b, c) {
      (a & b) == b && ((je |= b), (je &= ~c));
    };
  v("studio.common.Environment", ie);
  ie.Type = {
    LIVE: 1,
    LOCAL: 2,
    BROWSER: 4,
    IN_APP: 8,
    LAYOUTS_PREVIEW: 16,
    CREATIVE_TOOLSET: 32,
    RENDERING_STUDIO: 64,
    RENDERING_TEST: 128,
    PREVIEW: 256,
  };
  var je = 6;
  ie.addType = le;
  ie.setType = function (a) {
    je = a | 6;
    ke(je);
  };
  ie.hasType = function (a) {
    return (je & a) == a;
  };
  ie.getValue = function () {
    return je;
  };
  var Ae = function (a, b) {
    this.g = a[u.Symbol.iterator]();
    this.j = b;
  };
  Ae.prototype[Symbol.iterator] = function () {
    return this;
  };
  Ae.prototype.next = function () {
    var a = this.g.next();
    return {
      value: a.done ? void 0 : this.j.call(void 0, a.value),
      done: a.done,
    };
  };
  var Be = function (a, b) {
    return new Ae(a, b);
  };
  var Ce = function () {};
  Ce.prototype.next = function () {
    return De;
  };
  var De = { done: !0, value: void 0 };
  Ce.prototype.va = function () {
    return this;
  };
  var He = function (a) {
      if (a instanceof Ee || a instanceof Fe || a instanceof Ge) return a;
      if (typeof a.next == "function")
        return new Ee(function () {
          return a;
        });
      if (typeof a[Symbol.iterator] == "function")
        return new Ee(function () {
          return a[Symbol.iterator]();
        });
      if (typeof a.va == "function")
        return new Ee(function () {
          return a.va();
        });
      throw Error("Not an iterator or iterable.");
    },
    Ee = function (a) {
      this.g = a;
    };
  Ee.prototype.va = function () {
    return new Fe(this.g());
  };
  Ee.prototype[Symbol.iterator] = function () {
    return new Ge(this.g());
  };
  Ee.prototype.j = function () {
    return new Ge(this.g());
  };
  var Fe = function (a) {
    this.g = a;
  };
  q(Fe, Ce);
  Fe.prototype.next = function () {
    return this.g.next();
  };
  Fe.prototype[Symbol.iterator] = function () {
    return new Ge(this.g);
  };
  Fe.prototype.j = function () {
    return new Ge(this.g);
  };
  var Ge = function (a) {
    Ee.call(this, function () {
      return a;
    });
    this.o = a;
  };
  q(Ge, Ee);
  Ge.prototype.next = function () {
    return this.o.next();
  };
  var Ie = function (a, b) {
    this.j = {};
    this.g = [];
    this.o = this.size = 0;
    var c = arguments.length;
    if (c > 1) {
      if (c % 2) throw Error("Uneven number of arguments");
      for (var d = 0; d < c; d += 2) this.set(arguments[d], arguments[d + 1]);
    } else if (a)
      if (a instanceof Ie)
        for (c = a.Qa(), d = 0; d < c.length; d++) this.set(c[d], a.get(c[d]));
      else for (d in a) this.set(d, a[d]);
  };
  k = Ie.prototype;
  k.pa = function () {
    Je(this);
    for (var a = [], b = 0; b < this.g.length; b++) a.push(this.j[this.g[b]]);
    return a;
  };
  k.Qa = function () {
    Je(this);
    return this.g.concat();
  };
  k.has = function (a) {
    return Ke(this.j, a);
  };
  k.clear = function () {
    this.j = {};
    this.o = this.size = this.g.length = 0;
  };
  k.delete = function (a) {
    return Ke(this.j, a)
      ? (delete this.j[a],
        --this.size,
        this.o++,
        this.g.length > 2 * this.size && Je(this),
        !0)
      : !1;
  };
  var Je = function (a) {
    if (a.size != a.g.length) {
      for (var b = 0, c = 0; b < a.g.length; ) {
        var d = a.g[b];
        Ke(a.j, d) && (a.g[c++] = d);
        b++;
      }
      a.g.length = c;
    }
    if (a.size != a.g.length) {
      b = {};
      for (d = c = 0; c < a.g.length; ) {
        var e = a.g[c];
        Ke(b, e) || ((a.g[d++] = e), (b[e] = 1));
        c++;
      }
      a.g.length = d;
    }
  };
  k = Ie.prototype;
  k.get = function (a, b) {
    return Ke(this.j, a) ? this.j[a] : b;
  };
  k.set = function (a, b) {
    Ke(this.j, a) || ((this.size += 1), this.g.push(a), this.o++);
    this.j[a] = b;
  };
  k.forEach = function (a, b) {
    for (var c = this.Qa(), d = 0; d < c.length; d++) {
      var e = c[d],
        f = this.get(e);
      a.call(b, f, e, this);
    }
  };
  k.keys = function () {
    return He(this.va(!0)).j();
  };
  k.values = function () {
    return He(this.va(!1)).j();
  };
  k.entries = function () {
    var a = this;
    return Be(this.keys(), function (b) {
      return [b, a.get(b)];
    });
  };
  k.va = function (a) {
    Je(this);
    var b = 0,
      c = this.o,
      d = this,
      e = new Ce();
    e.next = function () {
      if (c != d.o)
        throw Error("The map has changed since the iterator was created");
      if (b >= d.g.length) return De;
      var f = d.g[b++];
      return { value: a ? f : d.j[f], done: !1 };
    };
    return e;
  };
  var Ke = function (a, b) {
    return Object.prototype.hasOwnProperty.call(a, b);
  };
  var Le = function (a) {
      if (a.pa && typeof a.pa == "function") return a.pa();
      if (
        (typeof Map !== "undefined" && a instanceof Map) ||
        (typeof Set !== "undefined" && a instanceof Set)
      )
        return Array.from(a.values());
      if (typeof a === "string") return a.split("");
      if (Ba(a)) {
        for (var b = [], c = a.length, d = 0; d < c; d++) b.push(a[d]);
        return b;
      }
      return pd(a);
    },
    Me = function (a) {
      if (a.Qa && typeof a.Qa == "function") return a.Qa();
      if (!a.pa || typeof a.pa != "function") {
        if (typeof Map !== "undefined" && a instanceof Map)
          return Array.from(a.keys());
        if (!(typeof Set !== "undefined" && a instanceof Set)) {
          if (Ba(a) || typeof a === "string") {
            var b = [];
            a = a.length;
            for (var c = 0; c < a; c++) b.push(c);
            return b;
          }
          b = [];
          c = 0;
          for (var d in a) b[c++] = d;
          return b;
        }
      }
    },
    Oe = function (a) {
      var b = Ne.contains,
        c = Ne;
      if (typeof a.every == "function") return a.every(b, c);
      if (Ba(a) || typeof a === "string")
        return Array.prototype.every.call(a, b, c);
      for (var d = Me(a), e = Le(a), f = e.length, g = 0; g < f; g++)
        if (!b.call(c, e[g], d && d[g], a)) return !1;
      return !0;
    };
  var Pe = function () {
      this.g = new Ie();
      this.size = 0;
    },
    Qe = function (a) {
      var b = typeof a;
      return (b == "object" && a) || b == "function"
        ? "o" + Ha(a)
        : b.slice(0, 1) + a;
    };
  Pe.prototype.add = function (a) {
    this.g.set(Qe(a), a);
    this.size = this.g.size;
  };
  var Re = function (a) {
    var b = Ne;
    a = Le(a);
    for (var c = a.length, d = 0; d < c; d++) b.add(a[d]);
    b.size = b.g.size;
  };
  k = Pe.prototype;
  k.delete = function (a) {
    var b = this.g;
    a = Qe(a);
    b = b.delete(a);
    this.size = this.g.size;
    return b;
  };
  k.clear = function () {
    this.g.clear();
    this.size = 0;
  };
  k.has = function (a) {
    var b = this.g;
    a = Qe(a);
    return b.has(a);
  };
  k.contains = function (a) {
    var b = this.g;
    a = Qe(a);
    return b.has(a);
  };
  k.pa = function () {
    return this.g.pa();
  };
  k.values = function () {
    return this.g.values();
  };
  k.va = function () {
    return this.g.va(!1);
  };
  Pe.prototype[Symbol.iterator] = function () {
    return this.values();
  };
  v("studio.common.Feature.Type", {
    Cf: 1,
    SDK_EVENT_FORWARDER: 2,
    RL_EVENT_FORWARDER: 3,
  });
  var Ne = new Pe(),
    Se = function (a) {
      return Ne.has(a);
    };
  v("studio.common.Feature.hasFeature", Se);
  v("studio.common.Feature.hasFeatures", function (a) {
    return Oe(a);
  });
  var Te = function (a, b) {
    this.g = a;
    this.j = b != null ? b : 0;
  };
  Te.prototype.qd = function () {
    return this.g;
  };
  Te.prototype.nd = function () {
    return this.j;
  };
  Te.prototype.toString = function () {
    return this.g;
  };
  v("studio.common.Orientation", Te);
  Te.prototype.getDegrees = Te.prototype.nd;
  Te.prototype.getMode = Te.prototype.qd;
  Te.Mode = { PORTRAIT: "portrait", LANDSCAPE: "landscape" };
  var Ue = RegExp(
      "^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$"
    ),
    Ve = function (a) {
      var b = a.match(Ue);
      a = b[1];
      var c = b[2],
        d = b[3];
      b = b[4];
      var e = "";
      a && (e += a + ":");
      d && ((e += "//"), c && (e += c + "@"), (e += d), b && (e += ":" + b));
      return e;
    },
    We = function (a, b) {
      if (a) {
        a = a.split("&");
        for (var c = 0; c < a.length; c++) {
          var d = a[c].indexOf("="),
            e = null;
          if (d >= 0) {
            var f = a[c].substring(0, d);
            e = a[c].substring(d + 1);
          } else f = a[c];
          b(f, e ? decodeURIComponent(e.replace(/\+/g, " ")) : "");
        }
      }
    },
    Xe = function (a, b, c) {
      if (Array.isArray(b))
        for (var d = 0; d < b.length; d++) Xe(a, String(b[d]), c);
      else
        b != null &&
          c.push(a + (b === "" ? "" : "=" + encodeURIComponent(String(b))));
    },
    Ye = function (a, b) {
      if ((b += "")) {
        var c = a.indexOf("#");
        c < 0 && (c = a.length);
        var d = a.indexOf("?");
        if (d < 0 || d > c) {
          d = c;
          var e = "";
        } else e = a.substring(d + 1, c);
        a = [a.slice(0, d), e, a.slice(c)];
        c = a[1];
        a[1] = b ? (c ? c + "&" + b : b) : c;
        b = a[0] + (a[1] ? "?" + a[1] : "") + a[2];
      } else b = a;
      return b;
    },
    Ze = /#|$/;
  function $e(a, b, c, d, e) {
    if (!E(H(a)) && a.indexOf("?") > -1) {
      e = typeof e === "number" ? e : 1;
      for (var f = 0; f < e; f++) b = encodeURIComponent(b);
    }
    c &&
      ((a = c ? a.replace("[rm_exit_id]", c) : a),
      (b = d ? encodeURIComponent(d + b) : b));
    return a + b;
  }
  v("studio.common.Visibility.VISIBILITY_PARAMS_KEY", "visibilityParams");
  v("studio.common.Visibility.VISIBILITY_FRACTION_KEY", "visibilityFraction");
  v("studio.common.Visibility.VISIBLE_BOX_KEY", "visibleBox");
  function af(a, b) {
    return { visibilityFraction: a, visibleBox: b };
  }
  v("studio.common.Visibility.createVisibilityParams", af);
  v("studio.common.WhitelistedExternalObject", {
    CREATIVETOOLSET_CONFIG: "creativeToolsetConfig",
    CREATIVETOOLSET_INTERNALS: "creativeToolsetInternals",
    CREATIVETOOLSET_INTERNALS_GEN204: "creativeToolsetInternalsGen204",
    CREATIVE_REPORTER: "creativeReporter",
    CREATIVE_INNOVATION: "gcreativeinnovation",
    GOOGLE_AFMA_SUPPORT: "googleAfmaSupport",
  });
  var bf = function (a) {
    try {
      switch (a) {
        case "creativeToolsetConfig":
          return window.CreativeToolset.Mb().getConfig();
        case "creativeToolsetInternals":
          return window.CreativeToolset.internals;
        case "creativeToolsetInternalsGen204":
          return window.CreativeToolset.internals.gen204;
        case "creativeReporter":
          return window.googlecreative.reporting.sharedReporter;
        case "gcreativeinnovation":
          return window.gcreativeinnovation;
        case "googleAfmaSupport":
          return window.google.afma.support;
      }
    } catch (b) {}
    return null;
  };
  var cf = {};
  function L(a) {
    a && typeof a.dispose == "function" && a.dispose();
  }
  function df(a) {
    for (var b = 0, c = arguments.length; b < c; ++b) {
      var d = arguments[b];
      Ba(d) ? df.apply(null, d) : L(d);
    }
  }
  var M = function () {
    this.W = this.W;
    this.P = this.P;
  };
  M.prototype.W = !1;
  M.prototype.L = function () {
    return this.W;
  };
  M.prototype.dispose = function () {
    this.W || ((this.W = !0), this.H());
  };
  M.prototype[Symbol.dispose] = function () {
    this.dispose();
  };
  var ef = function (a, b) {
    b = Ka(L, b);
    a.W ? b() : (a.P || (a.P = []), a.P.push(b));
  };
  M.prototype.H = function () {
    if (this.P) for (; this.P.length; ) this.P.shift()();
  };
  var N = function (a, b) {
    this.type = a;
    this.g = this.target = b;
    this.defaultPrevented = !1;
  };
  N.prototype.v = function () {
    this.defaultPrevented = !0;
  };
  var ff = (function () {
    if (!u.addEventListener || !Object.defineProperty) return !1;
    var a = !1,
      b = Object.defineProperty({}, "passive", {
        get: function () {
          a = !0;
        },
      });
    try {
      var c = function () {};
      u.addEventListener("test", c, b);
      u.removeEventListener("test", c, b);
    } catch (d) {}
    return a;
  })();
  var gf = function (a, b) {
    N.call(this, a ? a.type : "");
    this.relatedTarget = this.g = this.target = null;
    this.button = this.screenY = this.screenX = this.clientY = this.clientX = 0;
    this.key = "";
    this.metaKey = this.shiftKey = this.altKey = this.ctrlKey = !1;
    this.state = null;
    this.pointerId = 0;
    this.pointerType = "";
    this.ra = null;
    a && this.init(a, b);
  };
  B(gf, N);
  gf.prototype.init = function (a, b) {
    var c = (this.type = a.type),
      d =
        a.changedTouches && a.changedTouches.length
          ? a.changedTouches[0]
          : null;
    this.target = a.target || a.srcElement;
    this.g = b;
    b = a.relatedTarget;
    b ||
      (c == "mouseover"
        ? (b = a.fromElement)
        : c == "mouseout" && (b = a.toElement));
    this.relatedTarget = b;
    d
      ? ((this.clientX = d.clientX !== void 0 ? d.clientX : d.pageX),
        (this.clientY = d.clientY !== void 0 ? d.clientY : d.pageY),
        (this.screenX = d.screenX || 0),
        (this.screenY = d.screenY || 0))
      : ((this.clientX = a.clientX !== void 0 ? a.clientX : a.pageX),
        (this.clientY = a.clientY !== void 0 ? a.clientY : a.pageY),
        (this.screenX = a.screenX || 0),
        (this.screenY = a.screenY || 0));
    this.button = a.button;
    this.key = a.key || "";
    this.ctrlKey = a.ctrlKey;
    this.altKey = a.altKey;
    this.shiftKey = a.shiftKey;
    this.metaKey = a.metaKey;
    this.pointerId = a.pointerId || 0;
    this.pointerType = a.pointerType;
    this.state = a.state;
    this.ra = a;
    a.defaultPrevented && gf.X.v.call(this);
  };
  gf.prototype.v = function () {
    gf.X.v.call(this);
    var a = this.ra;
    a.preventDefault ? a.preventDefault() : (a.returnValue = !1);
  };
  var hf = "closure_listenable_" + ((Math.random() * 1e6) | 0),
    jf = function (a) {
      return !(!a || !a[hf]);
    };
  var kf = 0;
  var lf = function (a, b, c, d, e) {
      this.listener = a;
      this.proxy = null;
      this.src = b;
      this.type = c;
      this.capture = !!d;
      this.handler = e;
      this.key = ++kf;
      this.Za = this.fb = !1;
    },
    mf = function (a) {
      a.Za = !0;
      a.listener = null;
      a.proxy = null;
      a.src = null;
      a.handler = null;
    };
  function nf(a) {
    this.src = a;
    this.g = {};
    this.j = 0;
  }
  nf.prototype.add = function (a, b, c, d, e) {
    var f = a.toString();
    a = this.g[f];
    a || ((a = this.g[f] = []), this.j++);
    var g = of(a, b, d, e);
    g > -1
      ? ((b = a[g]), c || (b.fb = !1))
      : ((b = new lf(b, this.src, f, !!d, e)), (b.fb = c), a.push(b));
    return b;
  };
  var pf = function (a, b) {
      var c = b.type;
      if (!(c in a.g)) return !1;
      var d = Ta(a.g[c], b);
      d && (mf(b), a.g[c].length == 0 && (delete a.g[c], a.j--));
      return d;
    },
    qf = function (a) {
      var b = 0,
        c;
      for (c in a.g) {
        for (var d = a.g[c], e = 0; e < d.length; e++) ++b, mf(d[e]);
        delete a.g[c];
        a.j--;
      }
    },
    rf = function (a, b, c, d, e) {
      a = a.g[b.toString()];
      b = -1;
      a && (b = of(a, c, d, e));
      return b > -1 ? a[b] : null;
    },
    of = function (a, b, c, d) {
      for (var e = 0; e < a.length; ++e) {
        var f = a[e];
        if (!f.Za && f.listener == b && f.capture == !!c && f.handler == d)
          return e;
      }
      return -1;
    };
  var sf = "closure_lm_" + ((Math.random() * 1e6) | 0),
    tf = {},
    uf = 0,
    O = function (a, b, c, d, e) {
      if (d && d.once) return vf(a, b, c, d, e);
      if (Array.isArray(b)) {
        for (var f = 0; f < b.length; f++) O(a, b[f], c, d, e);
        return null;
      }
      c = wf(c);
      return jf(a)
        ? a.ea.add(String(b), c, !1, Ca(d) ? !!d.capture : !!d, e)
        : xf(a, b, c, !1, d, e);
    },
    xf = function (a, b, c, d, e, f) {
      if (!b) throw Error("Invalid event type");
      var g = Ca(e) ? !!e.capture : !!e,
        h = yf(a);
      h || (a[sf] = h = new nf(a));
      c = h.add(b, c, d, g, f);
      if (c.proxy) return c;
      d = zf();
      c.proxy = d;
      d.src = a;
      d.listener = c;
      if (a.addEventListener)
        ff || (e = g),
          e === void 0 && (e = !1),
          a.addEventListener(b.toString(), d, e);
      else if (a.attachEvent) a.attachEvent(Af(b.toString()), d);
      else if (a.addListener && a.removeListener) a.addListener(d);
      else throw Error("addEventListener and attachEvent are unavailable.");
      uf++;
      return c;
    },
    zf = function () {
      var a = Bf,
        b = function (c) {
          return a.call(b.src, b.listener, c);
        };
      return b;
    },
    vf = function (a, b, c, d, e) {
      if (Array.isArray(b)) {
        for (var f = 0; f < b.length; f++) vf(a, b[f], c, d, e);
        return null;
      }
      c = wf(c);
      return jf(a)
        ? a.ea.add(String(b), c, !0, Ca(d) ? !!d.capture : !!d, e)
        : xf(a, b, c, !0, d, e);
    },
    Cf = function (a, b, c, d, e) {
      if (Array.isArray(b))
        for (var f = 0; f < b.length; f++) Cf(a, b[f], c, d, e);
      else
        (d = Ca(d) ? !!d.capture : !!d),
          (c = wf(c)),
          jf(a)
            ? ((a = a.ea),
              (b = String(b).toString()),
              b in a.g &&
                ((f = a.g[b]),
                (c = of(f, c, d, e)),
                c > -1 &&
                  (mf(f[c]),
                  Array.prototype.splice.call(f, c, 1),
                  f.length == 0 && (delete a.g[b], a.j--))))
            : a && (a = yf(a)) && (c = rf(a, b, c, d, e)) && Df(c);
    },
    Df = function (a) {
      if (typeof a === "number" || !a || a.Za) return !1;
      var b = a.src;
      if (jf(b)) return pf(b.ea, a);
      var c = a.type,
        d = a.proxy;
      b.removeEventListener
        ? b.removeEventListener(c, d, a.capture)
        : b.detachEvent
        ? b.detachEvent(Af(c), d)
        : b.addListener && b.removeListener && b.removeListener(d);
      uf--;
      (c = yf(b))
        ? (pf(c, a), c.j == 0 && ((c.src = null), (b[sf] = null)))
        : mf(a);
      return !0;
    },
    Ef = function (a, b, c, d, e) {
      c = wf(c);
      d = !!d;
      return jf(a)
        ? rf(a.ea, String(b), c, d, e)
        : a
        ? (a = yf(a))
          ? rf(a, b, c, d, e)
          : null
        : null;
    },
    Af = function (a) {
      return a in tf ? tf[a] : (tf[a] = "on" + a);
    },
    Bf = function (a, b) {
      if (a.Za) a = !0;
      else {
        b = new gf(b, this);
        var c = a.listener,
          d = a.handler || a.src;
        a.fb && Df(a);
        a = c.call(d, b);
      }
      return a;
    },
    yf = function (a) {
      a = a[sf];
      return a instanceof nf ? a : null;
    },
    Ff = "__closure_events_fn_" + ((Math.random() * 1e9) >>> 0),
    wf = function (a) {
      if (typeof a === "function") return a;
      a[Ff] ||
        (a[Ff] = function (b) {
          return a.handleEvent(b);
        });
      return a[Ff];
    };
  var Gf = function (a) {
    M.call(this);
    this.j = a;
    this.g = {};
  };
  B(Gf, M);
  var Hf = [],
    P = function (a, b, c, d) {
      Array.isArray(c) || (c && (Hf[0] = c.toString()), (c = Hf));
      for (var e = 0; e < c.length; e++) {
        var f = O(b, c[e], d || a.handleEvent, !1, a.j || a);
        if (!f) break;
        a.g[f.key] = f;
      }
    },
    If = function (a, b, c, d, e, f) {
      if (Array.isArray(c))
        for (var g = 0; g < c.length; g++) If(a, b, c[g], d, e, f);
      else
        (b = vf(b, c, d || a.handleEvent, e, f || a.j || a)) &&
          (a.g[b.key] = b);
    },
    Jf = function (a, b, c, d, e, f) {
      if (Array.isArray(c))
        for (var g = 0; g < c.length; g++) Jf(a, b, c[g], d, e, f);
      else if (
        (b = Ef(
          b,
          c,
          d || a.handleEvent,
          Ca(e) ? !!e.capture : !!e,
          f || a.j || a
        ))
      )
        Df(b), delete a.g[b.key];
    },
    Kf = function (a) {
      md(
        a.g,
        function (b, c) {
          this.g.hasOwnProperty(c) && Df(b);
        },
        a
      );
      a.g = {};
    };
  Gf.prototype.H = function () {
    Gf.X.H.call(this);
    Kf(this);
  };
  Gf.prototype.handleEvent = function () {
    throw Error("EventHandler.handleEvent not implemented");
  };
  var Lf =
    typeof AsyncContext !== "undefined" &&
    typeof AsyncContext.Snapshot === "function"
      ? function (a) {
          return a && AsyncContext.Snapshot.wrap(a);
        }
      : function (a) {
          return a;
        };
  var Mf = function (a, b) {
    this.o = a;
    this.v = b;
    this.j = 0;
    this.g = null;
  };
  Mf.prototype.get = function () {
    if (this.j > 0) {
      this.j--;
      var a = this.g;
      this.g = a.next;
      a.next = null;
    } else a = this.o();
    return a;
  };
  var Nf = function (a, b) {
    a.v(b);
    a.j < 100 && (a.j++, (b.next = a.g), (a.g = b));
  };
  var Of,
    Pf = function () {
      if (typeof MessageChannel !== "undefined") {
        var a = new MessageChannel(),
          b = {},
          c = b;
        a.port1.onmessage = function () {
          if (b.next !== void 0) {
            b = b.next;
            var d = b.Fb;
            b.Fb = null;
            d();
          }
        };
        return function (d) {
          c.next = { Fb: d };
          c = c.next;
          a.port2.postMessage(0);
        };
      }
      return function (d) {
        u.setTimeout(d, 0);
      };
    };
  var Qf = function () {
    this.j = this.g = null;
  };
  Qf.prototype.add = function (a, b) {
    var c = Rf.get();
    c.set(a, b);
    this.j ? (this.j.next = c) : (this.g = c);
    this.j = c;
  };
  var Tf = function () {
      var a = Sf,
        b = null;
      a.g &&
        ((b = a.g), (a.g = a.g.next), a.g || (a.j = null), (b.next = null));
      return b;
    },
    Rf = new Mf(
      function () {
        return new Uf();
      },
      function (a) {
        return a.reset();
      }
    ),
    Uf = function () {
      this.next = this.g = this.j = null;
    };
  Uf.prototype.set = function (a, b) {
    this.j = a;
    this.g = b;
    this.next = null;
  };
  Uf.prototype.reset = function () {
    this.next = this.g = this.j = null;
  };
  var Vf,
    Wf = !1,
    Sf = new Qf(),
    Yf = function (a, b) {
      Vf || Xf();
      Wf || (Vf(), (Wf = !0));
      Sf.add(a, b);
    },
    Xf = function () {
      var a = Promise.resolve(void 0);
      Vf = function () {
        a.then(Zf);
      };
    };
  function Zf() {
    for (var a; (a = Tf()); ) {
      try {
        a.j.call(a.g);
      } catch (b) {
        Xa(b);
      }
      Nf(Rf, a);
    }
    Wf = !1;
  }
  var $f = function (a) {
    if (!a) return !1;
    try {
      return !!a.$goog_Thenable;
    } catch (b) {
      return !1;
    }
  };
  var Q = function (a, b) {
      this.g = 0;
      this.C = void 0;
      this.v = this.j = this.o = null;
      this.A = this.B = !1;
      if (a != Qc)
        try {
          var c = this;
          a.call(
            b,
            function (d) {
              ag(c, 2, d);
            },
            function (d) {
              ag(c, 3, d);
            }
          );
        } catch (d) {
          ag(this, 3, d);
        }
    },
    bg = function () {
      this.next = this.context = this.j = this.v = this.g = null;
      this.o = !1;
    };
  bg.prototype.reset = function () {
    this.context = this.j = this.v = this.g = null;
    this.o = !1;
  };
  var cg = new Mf(
      function () {
        return new bg();
      },
      function (a) {
        a.reset();
      }
    ),
    dg = function (a, b, c) {
      var d = cg.get();
      d.v = a;
      d.j = b;
      d.context = c;
      return d;
    },
    eg = function (a) {
      if (a instanceof Q) return a;
      var b = new Q(Qc);
      ag(b, 2, a);
      return b;
    },
    fg = function () {
      var a = Error("Cannot go fullscreen, already in fullscreen");
      return new Q(function (b, c) {
        c(a);
      });
    },
    hg = function (a, b, c) {
      gg(a, b, c, null) || Yf(Ka(b, a));
    },
    ig = function (a) {
      return new Q(function (b, c) {
        var d = a.length,
          e = [];
        if (d)
          for (
            var f = function (m, n) {
                d--;
                e[m] = n;
                d == 0 && b(e);
              },
              g = function (m) {
                c(m);
              },
              h,
              l = 0;
            l < a.length;
            l++
          )
            (h = a[l]), hg(h, Ka(f, l), g);
        else b(e);
      });
    },
    kg = function () {
      var a,
        b,
        c = new Q(function (d, e) {
          a = d;
          b = e;
        });
      return new jg(c, a, b);
    };
  Q.prototype.then = function (a, b, c) {
    return lg(
      this,
      Lf(typeof a === "function" ? a : null),
      Lf(typeof b === "function" ? b : null),
      c
    );
  };
  Q.prototype.$goog_Thenable = !0;
  var ng = function (a, b, c) {
      b = Lf(b);
      c = dg(b, b, c);
      c.o = !0;
      mg(a, c);
    },
    og = function (a, b, c) {
      return lg(a, null, Lf(b), c);
    };
  Q.prototype.cancel = function (a) {
    if (this.g == 0) {
      var b = new pg(a);
      Yf(function () {
        qg(this, b);
      }, this);
    }
  };
  var qg = function (a, b) {
      if (a.g == 0)
        if (a.o) {
          var c = a.o;
          if (c.j) {
            for (
              var d = 0, e = null, f = null, g = c.j;
              g && (g.o || (d++, g.g == a && (e = g), !(e && d > 1)));
              g = g.next
            )
              e || (f = g);
            e &&
              (c.g == 0 && d == 1
                ? qg(c, b)
                : (f
                    ? ((d = f),
                      d.next == c.v && (c.v = d),
                      (d.next = d.next.next))
                    : rg(c),
                  sg(c, e, 3, b)));
          }
          a.o = null;
        } else ag(a, 3, b);
    },
    mg = function (a, b) {
      a.j || (a.g != 2 && a.g != 3) || tg(a);
      a.v ? (a.v.next = b) : (a.j = b);
      a.v = b;
    },
    lg = function (a, b, c, d) {
      var e = dg(null, null, null);
      e.g = new Q(function (f, g) {
        e.v = b
          ? function (h) {
              try {
                var l = b.call(d, h);
                f(l);
              } catch (m) {
                g(m);
              }
            }
          : f;
        e.j = c
          ? function (h) {
              try {
                var l = c.call(d, h);
                l === void 0 && h instanceof pg ? g(h) : f(l);
              } catch (m) {
                g(m);
              }
            }
          : g;
      });
      e.g.o = a;
      mg(a, e);
      return e.g;
    };
  Q.prototype.F = function (a) {
    this.g = 0;
    ag(this, 2, a);
  };
  Q.prototype.G = function (a) {
    this.g = 0;
    ag(this, 3, a);
  };
  var ag = function (a, b, c) {
      a.g == 0 &&
        (a === c &&
          ((b = 3), (c = new TypeError("Promise cannot resolve to itself"))),
        (a.g = 1),
        gg(c, a.F, a.G, a) ||
          ((a.C = c),
          (a.g = b),
          (a.o = null),
          tg(a),
          b != 3 || c instanceof pg || ug(a, c)));
    },
    gg = function (a, b, c, d) {
      if (a instanceof Q) return mg(a, dg(b || Qc, c || null, d)), !0;
      if ($f(a)) return a.then(b, c, d), !0;
      if (Ca(a))
        try {
          var e = a.then;
          if (typeof e === "function") return vg(a, e, b, c, d), !0;
        } catch (f) {
          return c.call(d, f), !0;
        }
      return !1;
    },
    vg = function (a, b, c, d, e) {
      var f = !1,
        g = function (l) {
          f || ((f = !0), c.call(e, l));
        },
        h = function (l) {
          f || ((f = !0), d.call(e, l));
        };
      try {
        b.call(a, g, h);
      } catch (l) {
        h(l);
      }
    },
    tg = function (a) {
      a.B || ((a.B = !0), Yf(a.D, a));
    },
    rg = function (a) {
      var b = null;
      a.j && ((b = a.j), (a.j = b.next), (b.next = null));
      a.j || (a.v = null);
      return b;
    };
  Q.prototype.D = function () {
    for (var a; (a = rg(this)); ) sg(this, a, this.g, this.C);
    this.B = !1;
  };
  var sg = function (a, b, c, d) {
      if (c == 3 && b.j && !b.o) for (; a && a.A; a = a.o) a.A = !1;
      if (b.g) (b.g.o = null), wg(b, c, d);
      else
        try {
          b.o ? b.v.call(b.context) : wg(b, c, d);
        } catch (e) {
          xg.call(null, e);
        }
      Nf(cg, b);
    },
    wg = function (a, b, c) {
      b == 2 ? a.v.call(a.context, c) : a.j && a.j.call(a.context, c);
    },
    ug = function (a, b) {
      a.A = !0;
      Yf(function () {
        a.A && xg.call(null, b);
      });
    },
    xg = Xa,
    pg = function (a) {
      La.call(this, a);
    };
  B(pg, La);
  pg.prototype.name = "cancel";
  var jg = function (a, b, c) {
    this.promise = a;
    this.resolve = b;
    this.reject = c;
  }; /*

 Copyright 2005, 2007 Bob Ippolito. All Rights Reserved.
 Copyright The Closure Library Authors.
 SPDX-License-Identifier: MIT
*/
  var R = function (a, b) {
    this.C = [];
    this.P = a;
    this.L = b || null;
    this.v = this.g = !1;
    this.o = void 0;
    this.G = this.J = this.F = !1;
    this.D = 0;
    this.j = null;
    this.A = 0;
  };
  R.prototype.cancel = function (a) {
    if (this.g) this.o instanceof R && this.o.cancel();
    else {
      if (this.j) {
        var b = this.j;
        delete this.j;
        a ? b.cancel(a) : (b.A--, b.A <= 0 && b.cancel());
      }
      this.P ? this.P.call(this.L, this) : (this.G = !0);
      this.g || this.B(new yg(this));
    }
  };
  R.prototype.I = function (a, b) {
    this.F = !1;
    zg(this, a, b);
  };
  var zg = function (a, b, c) {
      a.g = !0;
      a.o = c;
      a.v = !b;
      Ag(a);
    },
    Cg = function (a) {
      if (a.g) {
        if (!a.G) throw new Bg(a);
        a.G = !1;
      }
    };
  R.prototype.ca = function (a) {
    Cg(this);
    zg(this, !0, a);
  };
  R.prototype.B = function (a) {
    Cg(this);
    zg(this, !1, a);
  };
  var Eg = function (a, b, c) {
      Dg(a, b, null, c);
    },
    Dg = function (a, b, c, d) {
      var e = a.g;
      e || (b === c ? (b = c = Lf(b)) : ((b = Lf(b)), (c = Lf(c))));
      a.C.push([b, c, d]);
      e && Ag(a);
    };
  R.prototype.then = function (a, b, c) {
    var d,
      e,
      f = new Q(function (g, h) {
        e = g;
        d = h;
      });
    Dg(
      this,
      e,
      function (g) {
        g instanceof yg ? f.cancel() : d(g);
        return Fg;
      },
      this
    );
    return f.then(a, b, c);
  };
  R.prototype.$goog_Thenable = !0;
  var Gg = function (a, b) {
    b instanceof R
      ? Eg(a, z(b.K, b))
      : Eg(a, function () {
          return b;
        });
  };
  R.prototype.K = function (a) {
    var b = new R();
    Dg(this, b.ca, b.B, b);
    a && ((b.j = this), this.A++);
    return b;
  };
  var Hg = function (a) {
      return Qa(a.C, function (b) {
        return typeof b[1] === "function";
      });
    },
    Fg = {},
    Ag = function (a) {
      if (a.D && a.g && Hg(a)) {
        var b = a.D,
          c = Ig[b];
        c && (u.clearTimeout(c.g), delete Ig[b]);
        a.D = 0;
      }
      a.j && (a.j.A--, delete a.j);
      b = a.o;
      for (var d = (c = !1); a.C.length && !a.F; ) {
        var e = a.C.shift(),
          f = e[0],
          g = e[1];
        e = e[2];
        if ((f = a.v ? g : f))
          try {
            var h = f.call(e || a.L, b);
            h === Fg && (h = void 0);
            h !== void 0 &&
              ((a.v = a.v && (h == b || h instanceof Error)), (a.o = b = h));
            if (
              $f(b) ||
              (typeof u.Promise === "function" && b instanceof u.Promise)
            )
              (d = !0), (a.F = !0);
          } catch (l) {
            (b = l), (a.v = !0), Hg(a) || (c = !0);
          }
      }
      a.o = b;
      d &&
        ((h = z(a.I, a, !0)),
        (d = z(a.I, a, !1)),
        b instanceof R ? (Dg(b, h, d), (b.J = !0)) : b.then(h, d));
      c && ((b = new qh(b)), (Ig[b.g] = b), (a.D = b.g));
    },
    Bg = function () {
      La.call(this);
    };
  B(Bg, La);
  Bg.prototype.message = "Deferred has already fired";
  Bg.prototype.name = "AlreadyCalledError";
  var yg = function () {
    La.call(this);
  };
  B(yg, La);
  yg.prototype.message = "Deferred was canceled";
  yg.prototype.name = "CanceledError";
  var qh = function (a) {
    this.g = u.setTimeout(z(this.o, this), 0);
    this.j = a;
  };
  qh.prototype.o = function () {
    delete Ig[this.g];
    throw this.j;
  };
  var Ig = {};
  var rh = ["pu", "lru", "pru", "lpu", "ppu"],
    th = function () {
      for (var a = 10, b = sh, c = b.length, d = ""; a-- > 0; )
        d += b.charAt(Math.floor(Math.random() * c));
      return d;
    },
    sh = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
  var uh = function (a) {
    M.call(this);
    this.B = a || Td();
  };
  B(uh, M);
  var S = function () {
    M.call(this);
    this.ea = new nf(this);
    this.ce = this;
    this.Ba = null;
  };
  B(S, M);
  S.prototype[hf] = !0;
  S.prototype.addEventListener = function (a, b, c, d) {
    O(this, a, b, c, d);
  };
  S.prototype.removeEventListener = function (a, b, c, d) {
    Cf(this, a, b, c, d);
  };
  S.prototype.j = function (a) {
    var b = this.Ba;
    if (b) {
      var c = [];
      for (var d = 1; b; b = b.Ba) c.push(b), ++d;
    }
    b = this.ce;
    d = a.type || a;
    if (typeof a === "string") a = new N(a, b);
    else if (a instanceof N) a.target = a.target || b;
    else {
      var e = a;
      a = new N(d, b);
      sd(a, e);
    }
    e = !0;
    var f;
    if (c)
      for (f = c.length - 1; f >= 0; f--) {
        var g = (a.g = c[f]);
        e = vh(g, d, !0, a) && e;
      }
    g = a.g = b;
    e = vh(g, d, !0, a) && e;
    e = vh(g, d, !1, a) && e;
    if (c)
      for (f = 0; f < c.length; f++)
        (g = a.g = c[f]), (e = vh(g, d, !1, a) && e);
    return e;
  };
  S.prototype.H = function () {
    S.X.H.call(this);
    this.ea && qf(this.ea);
    this.Ba = null;
  };
  var vh = function (a, b, c, d) {
    b = a.ea.g[String(b)];
    if (!b) return !0;
    b = b.concat();
    for (var e = !0, f = 0; f < b.length; ++f) {
      var g = b[f];
      if (g && !g.Za && g.capture == c) {
        var h = g.listener,
          l = g.handler || g.src;
        g.fb && pf(a.ea, g);
        e = h.call(l, d) !== !1 && e;
      }
    }
    return e && !d.defaultPrevented;
  };
  var T = function (a, b) {
    S.call(this);
    this.A = a || 1;
    this.v = b || u;
    this.B = z(this.D, this);
    this.C = A();
  };
  B(T, S);
  T.prototype.o = !1;
  T.prototype.g = null;
  T.prototype.D = function () {
    if (this.o) {
      var a = A() - this.C;
      a > 0 && a < this.A * 0.8
        ? (this.g = this.v.setTimeout(this.B, this.A - a))
        : (this.g && (this.v.clearTimeout(this.g), (this.g = null)),
          this.j("tick"),
          this.o && (wh(this), this.start()));
    }
  };
  T.prototype.start = function () {
    this.o = !0;
    this.g || ((this.g = this.v.setTimeout(this.B, this.A)), (this.C = A()));
  };
  var wh = function (a) {
    a.o = !1;
    a.g && (a.v.clearTimeout(a.g), (a.g = null));
  };
  T.prototype.H = function () {
    T.X.H.call(this);
    wh(this);
    delete this.v;
  };
  var xh = function (a, b, c) {
    if (typeof a === "function") c && (a = z(a, c));
    else if (a && typeof a.handleEvent == "function") a = z(a.handleEvent, a);
    else throw Error("Invalid listener argument");
    return Number(b) > 2147483647 ? -1 : u.setTimeout(a, b || 0);
  };
  var Ah = function (a, b) {
    uh.call(this, b);
    this.g = a;
    this.G = new Gf(this);
    ef(this, this.G);
    this.C = new T(100, this.B.g.defaultView);
    ef(this, this.C);
    this.o = new R();
    this.v = new R();
    this.j = new R();
    this.F = th();
    this.D = null;
    this.A = {};
    this.J = this.g.name;
    yh(this.g, this.g.name + "_" + zh(this.g));
    this.I = !1;
    Gg(this.j, this.o);
    Gg(this.j, this.v);
    Eg(this.j, this.zc, this);
    this.j.ca(!0);
    P(this.G, this.C, "tick", this.zb);
  };
  q(Ah, uh);
  var Dh = function (a) {
    var b = new Bh(a.channelName, a.service, a.payload);
    a = b.g;
    var c = b.o;
    b = b.j;
    var d = cf[a];
    if (d) return d.bb(c, b), !0;
    d = Ch(b)[0];
    for (var e in cf) {
      var f = cf[e];
      if (zh(f) == 1 && !f.isConnected() && c == "tp" && d == "SETUP")
        return yh(f, a), f.bb(c, b), !0;
    }
    return !1;
  };
  k = Ah.prototype;
  k.fc = function (a) {
    a = Ch(a);
    var b = a[1];
    switch (a[0]) {
      case "SETUP_ACK":
        this.o.g || this.o.ca(!0);
        break;
      case "SETUP":
        this.ja("tp", "SETUP_ACK"),
          this.v.g || this.v.ca(!0),
          this.D != null && this.D != b && this.ja("tp", "SETUP," + this.F),
          (this.D = b);
    }
  };
  k.connect = function () {
    var a = this.B.g.defaultView;
    if (a) {
      var b = Ha(a);
      (Eh[b] || 0) == 0 &&
        y("crosswindowmessaging.channel", a) == null &&
        v("crosswindowmessaging.channel", Dh, a);
      Eh[b]++;
      this.I = !0;
      this.zb();
    }
  };
  k.zb = function () {
    this.g.isConnected()
      ? wh(this.C)
      : (this.C.start(), this.ja("tp", "SETUP," + this.F));
  };
  k.ja = function (a, b) {
    this.g.ba &&
      ((a = new Bh(this.J + "_" + (zh(this.g) == 0 ? 1 : 0), a, b)),
      this.g.getConfig().directSyncMode
        ? this.Jb(a)
        : (this.A[Ha(a)] = xh(z(this.Jb, this, a), 0)));
  };
  k.Jb = function (a) {
    var b = Ha(a);
    this.A[b] && delete this.A[b];
    try {
      var c = y("crosswindowmessaging.channel", this.g.ba);
    } catch (d) {
      return;
    }
    if (c !== null)
      try {
        c({ channelName: a.g, service: a.o, payload: a.j });
      } catch (d) {}
  };
  k.zc = function () {
    Fh(this.g, (this.g.getConfig(), 0));
  };
  k.H = function () {
    if (this.I) {
      var a = this.B.g.defaultView,
        b = Ha(a);
      --Eh[b] == 1 && v("crosswindowmessaging.channel", null, a);
    }
    this.A &&
      (md(this.A, function (c) {
        u.clearTimeout(c);
      }),
      (this.A = null));
    this.o && (this.o.cancel(), delete this.o);
    this.v && (this.v.cancel(), delete this.v);
    this.j && (this.j.cancel(), delete this.j);
    uh.prototype.H.call(this);
  };
  var Ch = function (a) {
      a = a.split(",");
      a[1] = a[1] || null;
      return a;
    },
    Eh = {},
    Bh = function (a, b, c) {
      this.g = a;
      this.o = b;
      this.j = c;
    };
  var Gh = function (a, b, c, d, e) {
    uh.call(this, c);
    this.A = a;
    this.C = e || 2;
    this.V = b || "*";
    this.I = new Gf(this);
    this.D = new T(100, this.B.g.defaultView);
    this.J = !!d;
    this.o = new R();
    this.v = new R();
    this.j = new R();
    this.R = th();
    this.G = null;
    this.J
      ? zh(this.A) == 1
        ? Gg(this.j, this.o)
        : Gg(this.j, this.v)
      : (Gg(this.j, this.o), this.C == 2 && Gg(this.j, this.v));
    Eg(this.j, this.S, this);
    this.j.ca(!0);
    this.U = ob() <= 10;
    P(this.I, this.D, "tick", this.M);
  };
  q(Gh, uh);
  var Jh = function (a) {
    var b = a.ra.data;
    if (typeof b !== "string") return !1;
    var c = b.indexOf("|"),
      d = b.indexOf(":");
    if (c == -1 || d == -1) return !1;
    var e = b.substring(0, c);
    c = b.substring(c + 1, d);
    b = b.substring(d + 1);
    if ((d = cf[e])) return d.bb(c, b, a.ra.origin), !0;
    d = Hh(b)[0];
    for (var f in cf) {
      var g = cf[f];
      if (
        zh(g) == 1 &&
        !g.isConnected() &&
        c == "tp" &&
        (d == "SETUP" || d == "SETUP_NTPV2") &&
        Ih(g, a.ra.origin)
      )
        return yh(g, e), g.bb(c, b), !0;
    }
    return !1;
  };
  Gh.prototype.fc = function (a) {
    var b = Hh(a);
    a = b[1];
    switch (b[0]) {
      case "SETUP_ACK":
        Kh(this, 1);
        this.o.g || this.o.ca(!0);
        break;
      case "SETUP_ACK_NTPV2":
        this.C == 2 && (Kh(this, 2), this.o.g || this.o.ca(!0));
        break;
      case "SETUP":
        Kh(this, 1);
        Lh(this, 1);
        break;
      case "SETUP_NTPV2":
        this.C == 2 &&
          ((b = this.g),
          Kh(this, 2),
          Lh(this, 2),
          (b != 1 && this.G == null) || this.G == a || Mh(this),
          (this.G = a));
    }
  };
  var Mh = function (a) {
      a.C != 2 || (a.g != null && a.g != 2) || a.ja("tp", "SETUP_NTPV2," + a.R);
      (a.g != null && a.g != 1) || a.ja("tp", "SETUP");
    },
    Lh = function (a, b) {
      if (a.C != 2 || (a.g != null && a.g != 2) || b != 2) {
        if ((a.g != null && a.g != 1) || b != 1) return;
        a.ja("tp", "SETUP_ACK");
      } else a.ja("tp", "SETUP_ACK_NTPV2");
      a.v.g || a.v.ca(!0);
    },
    Kh = function (a, b) {
      b > a.g && (a.g = b);
      a.g == 1 && (a.v.g || a.J || a.v.ca(!0), (a.G = null));
    };
  Gh.prototype.connect = function () {
    var a = this.B.g.defaultView,
      b = Ha(a),
      c = Nh[b];
    typeof c !== "number" && (c = 0);
    c == 0 && O(a.postMessage ? a : a.document, "message", Jh, !1, Gh);
    Nh[b] = c + 1;
    this.K = !0;
    this.M();
  };
  Gh.prototype.M = function () {
    var a = zh(this.A) == 0;
    (this.J && a) || this.A.isConnected() || this.L()
      ? wh(this.D)
      : (this.D.start(), Mh(this));
  };
  var Oh = function (a, b, c) {
    var d = a.A.ba,
      e = a.A.name;
    a.F = 0;
    try {
      var f = d.postMessage ? d : d.document;
      f.postMessage && f.postMessage(e + "|" + b + ":" + c, a.V);
    } catch (g) {}
  };
  Gh.prototype.ja = function (a, b) {
    var c = this;
    this.A.ba &&
      (this.U
        ? (this.F = xh(function () {
            return void Oh(c, a, b);
          }, 0))
        : Oh(this, a, b));
  };
  Gh.prototype.S = function () {
    Fh(this.A, this.C == 1 || this.g == 1 ? 200 : void 0);
  };
  Gh.prototype.H = function () {
    if (this.K) {
      var a = this.B.g.defaultView;
      if (a) {
        var b = Ha(a),
          c = Nh[b];
        Nh[b] = c - 1;
        c === 1 && Cf(a.postMessage ? a : a.document, "message", Jh, !1, Gh);
      }
    }
    this.F && (u.clearTimeout(this.F), (this.F = 0));
    L(this.I);
    delete this.I;
    L(this.D);
    delete this.D;
    this.o.cancel();
    delete this.o;
    this.v.cancel();
    delete this.v;
    this.j.cancel();
    delete this.j;
    delete this.ja;
    uh.prototype.H.call(this);
  };
  var Hh = function (a) {
    a = a.split(",");
    a[1] = a[1] || null;
    return a;
  };
  Gh.prototype.g = null;
  Gh.prototype.K = !1;
  var Nh = {};
  Gh.prototype.F = 0;
  function Ph(a, b, c) {
    M.call(this);
    this.g = a;
    this.v = b || 0;
    this.j = c;
    this.o = z(this.ed, this);
  }
  B(Ph, M);
  k = Ph.prototype;
  k.za = 0;
  k.H = function () {
    Ph.X.H.call(this);
    this.isActive() && u.clearTimeout(this.za);
    this.za = 0;
    delete this.g;
    delete this.j;
  };
  k.start = function (a) {
    this.isActive() && u.clearTimeout(this.za);
    this.za = 0;
    this.za = xh(this.o, a !== void 0 ? a : this.v);
  };
  k.isActive = function () {
    return this.za != 0;
  };
  k.ed = function () {
    this.za = 0;
    this.g && this.g.call(this.j);
  };
  var Sh = function (a) {
      var b = [];
      Qh(new Rh(), a, b);
      return b.join("");
    },
    Rh = function () {},
    Qh = function (a, b, c) {
      if (b == null) c.push("null");
      else {
        if (typeof b == "object") {
          if (Array.isArray(b)) {
            var d = b;
            b = d.length;
            c.push("[");
            for (var e = "", f = 0; f < b; f++)
              c.push(e), Qh(a, d[f], c), (e = ",");
            c.push("]");
            return;
          }
          if (
            b instanceof String ||
            b instanceof Number ||
            b instanceof Boolean
          )
            b = b.valueOf();
          else {
            c.push("{");
            e = "";
            for (d in b)
              Object.prototype.hasOwnProperty.call(b, d) &&
                ((f = b[d]),
                typeof f != "function" &&
                  (c.push(e), Th(d, c), c.push(":"), Qh(a, f, c), (e = ",")));
            c.push("}");
            return;
          }
        }
        switch (typeof b) {
          case "string":
            Th(b, c);
            break;
          case "number":
            c.push(isFinite(b) && !isNaN(b) ? String(b) : "null");
            break;
          case "boolean":
            c.push(String(b));
            break;
          case "function":
            c.push("null");
            break;
          default:
            throw Error("Unknown type: " + typeof b);
        }
      }
    },
    Uh = {
      '"': '\\"',
      "\\": "\\\\",
      "/": "\\/",
      "\b": "\\b",
      "\f": "\\f",
      "\n": "\\n",
      "\r": "\\r",
      "\t": "\\t",
      "\v": "\\u000b",
    },
    Vh = /\uffff/.test("\uffff")
      ? /[\\"\x00-\x1f\x7f-\uffff]/g
      : /[\\"\x00-\x1f\x7f-\xff]/g,
    Th = function (a, b) {
      b.push(
        '"',
        a.replace(Vh, function (c) {
          var d = Uh[c];
          d ||
            ((d = "\\u" + (c.charCodeAt(0) | 65536).toString(16).slice(1)),
            (Uh[c] = d));
          return d;
        }),
        '"'
      );
    };
  var Wh = function () {
    M.call(this);
    this.C = {};
  };
  B(Wh, M);
  Wh.prototype.connect = function (a) {
    a && a();
  };
  Wh.prototype.isConnected = function () {
    return !0;
  };
  Wh.prototype.Na = function (a, b, c) {
    this.C[a] = { ca: b, Ub: !!c };
  };
  Wh.prototype.ub = function (a) {
    this.v = a;
  };
  var Xh = function (a, b) {
    if (b && typeof a === "string")
      try {
        return JSON.parse(a);
      } catch (c) {
        return null;
      }
    else if (!b && typeof a !== "string") return Sh(a);
    return a;
  };
  Wh.prototype.H = function () {
    Wh.X.H.call(this);
    delete this.C;
    delete this.v;
  };
  var Yh = function (a) {
    this.g = this.C = this.o = "";
    this.D = null;
    this.A = this.j = "";
    this.v = !1;
    var b;
    a instanceof Yh
      ? ((this.v = a.v),
        Zh(this, a.o),
        (this.C = a.C),
        (this.g = a.g),
        $h(this, a.D),
        (this.j = a.j),
        ai(this, bi(a.B)),
        (this.A = a.A))
      : a && (b = String(a).match(Ue))
      ? ((this.v = !1),
        Zh(this, b[1] || "", !0),
        (this.C = ci(b[2] || "")),
        (this.g = ci(b[3] || "", !0)),
        $h(this, b[4]),
        (this.j = ci(b[5] || "", !0)),
        ai(this, b[6] || "", !0),
        (this.A = ci(b[7] || "")))
      : ((this.v = !1), (this.B = new di(null, this.v)));
  };
  Yh.prototype.toString = function () {
    var a = [],
      b = this.o;
    b && a.push(ei(b, fi, !0), ":");
    var c = this.g;
    if (c || b == "file")
      a.push("//"),
        (b = this.C) && a.push(ei(b, fi, !0), "@"),
        a.push(
          encodeURIComponent(String(c)).replace(/%25([0-9a-fA-F]{2})/g, "%$1")
        ),
        (c = this.D),
        c != null && a.push(":", String(c));
    if ((c = this.j))
      this.g && c.charAt(0) != "/" && a.push("/"),
        a.push(ei(c, c.charAt(0) == "/" ? gi : hi, !0));
    (c = this.B.toString()) && a.push("?", c);
    (c = this.A) && a.push("#", ei(c, ii));
    return a.join("");
  };
  Yh.prototype.resolve = function (a) {
    var b = new Yh(this),
      c = !!a.o;
    c ? Zh(b, a.o) : (c = !!a.C);
    c ? (b.C = a.C) : (c = !!a.g);
    c ? (b.g = a.g) : (c = a.D != null);
    var d = a.j;
    if (c) $h(b, a.D);
    else if ((c = !!a.j)) {
      if (d.charAt(0) != "/")
        if (this.g && !this.j) d = "/" + d;
        else {
          var e = b.j.lastIndexOf("/");
          e != -1 && (d = b.j.slice(0, e + 1) + d);
        }
      e = d;
      if (e == ".." || e == ".") d = "";
      else if (e.indexOf("./") != -1 || e.indexOf("/.") != -1) {
        d = e.lastIndexOf("/", 0) == 0;
        e = e.split("/");
        for (var f = [], g = 0; g < e.length; ) {
          var h = e[g++];
          h == "."
            ? d && g == e.length && f.push("")
            : h == ".."
            ? ((f.length > 1 || (f.length == 1 && f[0] != "")) && f.pop(),
              d && g == e.length && f.push(""))
            : (f.push(h), (d = !0));
        }
        d = f.join("/");
      } else d = e;
    }
    c ? (b.j = d) : (c = a.B.toString() !== "");
    c ? ai(b, bi(a.B)) : (c = !!a.A);
    c && (b.A = a.A);
    return b;
  };
  var Zh = function (a, b, c) {
      a.o = c ? ci(b, !0) : b;
      a.o && (a.o = a.o.replace(/:$/, ""));
    },
    $h = function (a, b) {
      if (b) {
        b = Number(b);
        if (isNaN(b) || b < 0) throw Error("Bad port number " + b);
        a.D = b;
      } else a.D = null;
    },
    ai = function (a, b, c) {
      b instanceof di
        ? ((a.B = b), ji(a.B, a.v))
        : (c || (b = ei(b, ki)), (a.B = new di(b, a.v)));
    },
    ci = function (a, b) {
      return a
        ? b
          ? decodeURI(a.replace(/%25/g, "%2525"))
          : decodeURIComponent(a)
        : "";
    },
    ei = function (a, b, c) {
      return typeof a === "string"
        ? ((a = encodeURI(a).replace(b, li)),
          c && (a = a.replace(/%25([0-9a-fA-F]{2})/g, "%$1")),
          a)
        : null;
    },
    li = function (a) {
      a = a.charCodeAt(0);
      return "%" + ((a >> 4) & 15).toString(16) + (a & 15).toString(16);
    },
    fi = /[#\/\?@]/g,
    hi = /[#\?:]/g,
    gi = /[#\?]/g,
    ki = /[#\?@]/g,
    ii = /#/g,
    di = function (a, b) {
      this.j = this.g = null;
      this.o = a || null;
      this.v = !!b;
    },
    mi = function (a) {
      a.g ||
        ((a.g = new Map()),
        (a.j = 0),
        a.o &&
          We(a.o, function (b, c) {
            a.add(decodeURIComponent(b.replace(/\+/g, " ")), c);
          }));
    };
  di.prototype.add = function (a, b) {
    mi(this);
    this.o = null;
    a = ni(this, a);
    var c = this.g.get(a);
    c || this.g.set(a, (c = []));
    c.push(b);
    this.j = this.j + 1;
    return this;
  };
  var oi = function (a, b) {
    mi(a);
    b = ni(a, b);
    a.g.has(b) &&
      ((a.o = null), (a.j = a.j - a.g.get(b).length), a.g.delete(b));
  };
  di.prototype.clear = function () {
    this.g = this.o = null;
    this.j = 0;
  };
  var pi = function (a, b) {
    mi(a);
    b = ni(a, b);
    return a.g.has(b);
  };
  k = di.prototype;
  k.forEach = function (a, b) {
    mi(this);
    this.g.forEach(function (c, d) {
      c.forEach(function (e) {
        a.call(b, e, d, this);
      }, this);
    }, this);
  };
  k.Qa = function () {
    mi(this);
    for (
      var a = Array.from(this.g.values()),
        b = Array.from(this.g.keys()),
        c = [],
        d = 0;
      d < b.length;
      d++
    )
      for (var e = a[d], f = 0; f < e.length; f++) c.push(b[d]);
    return c;
  };
  k.pa = function (a) {
    mi(this);
    var b = [];
    if (typeof a === "string")
      pi(this, a) && (b = b.concat(this.g.get(ni(this, a))));
    else {
      a = Array.from(this.g.values());
      for (var c = 0; c < a.length; c++) b = b.concat(a[c]);
    }
    return b;
  };
  k.set = function (a, b) {
    mi(this);
    this.o = null;
    a = ni(this, a);
    pi(this, a) && (this.j = this.j - this.g.get(a).length);
    this.g.set(a, [b]);
    this.j = this.j + 1;
    return this;
  };
  k.get = function (a, b) {
    if (!a) return b;
    a = this.pa(a);
    return a.length > 0 ? String(a[0]) : b;
  };
  k.toString = function () {
    if (this.o) return this.o;
    if (!this.g) return "";
    for (var a = [], b = Array.from(this.g.keys()), c = 0; c < b.length; c++) {
      var d = b[c],
        e = encodeURIComponent(String(d));
      d = this.pa(d);
      for (var f = 0; f < d.length; f++) {
        var g = e;
        d[f] !== "" && (g += "=" + encodeURIComponent(String(d[f])));
        a.push(g);
      }
    }
    return (this.o = a.join("&"));
  };
  var bi = function (a) {
      var b = new di();
      b.o = a.o;
      a.g && ((b.g = new Map(a.g)), (b.j = a.j));
      return b;
    },
    ni = function (a, b) {
      b = String(b);
      a.v && (b = b.toLowerCase());
      return b;
    },
    ji = function (a, b) {
      b &&
        !a.v &&
        (mi(a),
        (a.o = null),
        a.g.forEach(function (c, d) {
          var e = d.toLowerCase();
          d != e &&
            (oi(this, d),
            oi(this, e),
            c.length > 0 &&
              ((this.o = null),
              this.g.set(ni(this, e), Va(c)),
              (this.j = this.j + c.length)));
        }, a));
      a.v = b;
    };
  var ri = function (a, b) {
    Wh.call(this);
    for (var c, d = 0; (c = rh[d]); d++)
      if (c in a && !/^https?:\/\//.test(a[c]))
        throw Error("URI " + a[c] + " is invalid for field " + c);
    this.g = a;
    this.name = this.g.cn || th();
    this.j = b || Td();
    this.o = [];
    this.B = new Gf(this);
    a.lpu = a.lpu || Ve(this.j.g.defaultView.location.href) + "/robots.txt";
    a.ppu = a.ppu || Ve(a.pu || "") + "/robots.txt";
    cf[this.name] = this;
    Ef(window, "unload", qi) || vf(window, "unload", qi);
  };
  q(ri, Wh);
  k = ri.prototype;
  k.isConnected = function () {
    return this.Ma == 2;
  };
  k.getConfig = function () {
    return this.g;
  };
  k.connect = function (a) {
    this.A = a || function () {};
    this.Ma == 3 && (this.Ma = 1);
    this.Ka ? Eg(this.Ka, this.Gb) : this.Gb();
  };
  k.Gb = function () {
    this.Ka = null;
    this.g.ifrid && (this.cb = this.j.T(this.g.ifrid));
    if (this.cb) {
      var a = this.cb.contentWindow;
      a || (a = window.frames[this.g.ifrid]);
      this.ba = a;
    }
    if (!this.ba) {
      if (window == window.top)
        throw Error(
          "CrossPageChannel: Can't connect, peer window-object not set."
        );
      this.ba = window.parent;
    }
    if (!this.qa) {
      this.g.tp ||
        (this.g.tp =
          typeof document.postMessage === "function" ||
          typeof window.postMessage === "function" ||
          (tb && window.postMessage)
            ? 1
            : 0);
      if (typeof this.g.tp === "function")
        this.qa = new this.g.tp(this, this.j);
      else
        switch (this.g.tp) {
          case 1:
            this.qa = new Gh(
              this,
              this.g.ph,
              this.j,
              !!this.g.osh,
              this.g.nativeProtocolVersion || 2
            );
            break;
          case 2:
            if ((a = this.ba))
              try {
                a = window.document.domain == this.ba.document.domain;
              } catch (b) {
                a = !1;
              }
            a && (this.qa = new Ah(this, this.j));
        }
      if (!this.qa)
        throw Error(
          "CrossPageChannel: No suitable transport found! You may try injecting a Transport constructor directly via the channel config object."
        );
    }
    for (this.qa.connect(); this.o.length > 0; ) this.o.shift()();
  };
  k.close = function () {
    this.Ka && (this.Ka.cancel(), (this.Ka = null));
    this.o.length = 0;
    Kf(this.B);
    this.Ma = 3;
    L(this.qa);
    this.A = this.qa = null;
    L(this.wa);
    this.wa = null;
  };
  var Fh = function (a, b) {
    a.isConnected() ||
      (a.wa && a.wa.isActive()) ||
      ((a.Ma = 2),
      L(a.wa),
      b !== void 0
        ? ((a.wa = new Ph(a.A, b)), a.wa.start())
        : ((a.wa = null), a.A()));
  };
  ri.prototype.ua = function (a, b) {
    if (this.isConnected()) {
      try {
        var c = !!this.ba && !this.ba.closed;
      } catch (e) {
        c = !1;
      }
      if (c) {
        Ca(b) && (b = Sh(b));
        c = this.qa;
        var d = c.ja;
        si.test(a) && (a = "%" + a);
        a = a.replace(/[%:|]/g, encodeURIComponent);
        d.call(c, a, b);
      } else this.close();
    }
  };
  ri.prototype.bb = function (a, b, c) {
    this.Ka
      ? this.o.push(z(this.bb, this, a, b, c))
      : Ih(this, c) &&
        !this.L() &&
        this.Ma != 3 &&
        (a && a != "tp"
          ? this.isConnected() &&
            ((a = a.replace(/%[0-9a-f]{2}/gi, decodeURIComponent)),
            (a = ti.test(a) ? a.substring(1) : a),
            (a = (c = this.C[a])
              ? c
              : this.v
              ? { ca: Ka(this.v, a), Ub: Ca(b) }
              : null)) &&
            ((b = Xh(b, a.Ub)), b != null && a.ca(b))
          : this.qa.fc(b));
  };
  var zh = function (a) {
      var b = a.g.role;
      return typeof b === "number" ? b : window.parent == a.ba ? 1 : 0;
    },
    yh = function (a, b) {
      delete cf[a.name];
      a.name = b;
      cf[b] = a;
    },
    Ih = function (a, b) {
      var c = a.g.ph;
      return E(H(b)) || E(H(c)) || b == a.g.ph;
    };
  ri.prototype.H = function () {
    this.close();
    this.cb = this.ba = null;
    delete cf[this.name];
    L(this.B);
    delete this.B;
    Wh.prototype.H.call(this);
  };
  var qi = function () {
      for (var a in cf) L(cf[a]);
    },
    si = RegExp("^%*tp$"),
    ti = RegExp("^%+tp$");
  k = ri.prototype;
  k.wa = null;
  k.Ka = null;
  k.qa = null;
  k.Ma = 1;
  k.ba = null;
  k.cb = null;
  var ui = {
    Pc: "assetType",
    uc: "assets",
    xc: "exitEvents",
    vc: "click",
    Sc: "thirdPartyClickRedirect",
    Xe: "ise",
    ff: "isMouseOver",
    Qc: "varName",
    rc: "sn",
    qc: "sid",
    lc: "aid",
    nc: "pid",
    oc: "rid",
    mc: "cid",
    Lf: "ct",
    Nf: "st",
    Of: "zp",
    Kf: "bw",
    Jf: "ac",
    Mf: "dma",
    ef: "isMultiDirectional",
    wc: "dcData",
    Nc: "layoutsConfig",
    Ke: "features",
    yc: "experiments",
    Rc: "rum_config",
    Tc: "turtlex_ad_signals",
    Oc: "newton_ot2_token",
  };
  function vi(a) {
    var b = {};
    C(a.split("&"), function (c) {
      c = c.split("=");
      b[c[0]] = c[1];
    });
    return b;
  }
  function wi(a) {
    var b = [];
    md(a, function (c, d) {
      b.push(d + "=" + c);
    });
    return b.join("&");
  }
  var xi = {
      Ae: "devicemotion",
      Be: "deviceorientation",
      Te: "hostpageScroll",
      Ee: "enterViewport",
      Ge: "exitViewport",
      le: "adLocation",
    },
    yi = {},
    zi;
  for (zi in xi) yi[xi[zi]] = !0;
  var Ai = ["hostpageScroll", "enterViewport", "exitViewport", "adLocation"];
  function Bi(a, b, c, d) {
    this.top = a;
    this.right = b;
    this.bottom = c;
    this.left = d;
  }
  Bi.prototype.contains = function (a) {
    return this && a
      ? a instanceof Bi
        ? a.left >= this.left &&
          a.right <= this.right &&
          a.top >= this.top &&
          a.bottom <= this.bottom
        : a.x >= this.left &&
          a.x <= this.right &&
          a.y >= this.top &&
          a.y <= this.bottom
      : !1;
  };
  Bi.prototype.ceil = function () {
    this.top = Math.ceil(this.top);
    this.right = Math.ceil(this.right);
    this.bottom = Math.ceil(this.bottom);
    this.left = Math.ceil(this.left);
    return this;
  };
  Bi.prototype.floor = function () {
    this.top = Math.floor(this.top);
    this.right = Math.floor(this.right);
    this.bottom = Math.floor(this.bottom);
    this.left = Math.floor(this.left);
    return this;
  };
  Bi.prototype.round = function () {
    this.top = Math.round(this.top);
    this.right = Math.round(this.right);
    this.bottom = Math.round(this.bottom);
    this.left = Math.round(this.left);
    return this;
  };
  var Ci = function (a) {
    this.g = a;
  };
  Ci.prototype.toString = function () {
    return (this.g & 2 ? "b" : "t") + (this.g & 1 ? "r" : "l");
  };
  v("google3.javascript.ads.studio.common.mde.Direction.Direction", Ci);
  Ci.Corner = { Ff: 0, Gf: 1, oe: 2, pe: 3 };
  var Di = {
    wf: "s",
    lf: "l",
    we: "i",
    Af: "x",
    zf: "c",
    kf: "r",
    jf: "n",
    yf: "t",
    Bf: "m",
    If: "u",
  };
  function Ei(a, b, c, d, e) {
    this.name = a;
    this.reportingId = b;
    this.type = c;
    this.v = d;
    this.B = e;
    this.A = !1;
  }
  var Fi = function (a) {
    switch (a) {
      case "Exit":
        return "Exit";
      case "Count":
        return "Counter";
      case "Start":
      case "Stop":
        return "Timer";
      default:
        throw "Unsupported event action";
    }
  };
  var Gi = {
      DISPLAY_TIMER: { id: null, type: "Timer", N: !0, O: !0 },
      INTERACTION_TIMER: { id: null, type: "Timer", N: !0, O: !0 },
      INTERACTIVE_IMPRESSION: { id: null, type: "Counter", N: !0, O: !1 },
      MANUAL_CLOSE: { id: null, type: "Counter", N: !0, O: !0 },
      EXPAND_TIMER: { id: null, type: "Timer", N: !0, O: !1 },
      FULL_SCREEN: { id: null, type: "Counter", N: !0, O: !0 },
      SCROLL: { id: null, type: "Counter", N: !0, O: !0 },
      LARGE_SCROLL: { id: null, type: "Counter", N: !0, O: !0 },
      SMALL_SCROLL: { id: null, type: "Counter", N: !0, O: !0 },
      ENGAGEMENT: { id: null, type: "Counter", N: !0, O: !0 },
      VIDEO_PLAY: { id: null, type: "Counter", N: !0, O: !1 },
      VIDEO_VIEW_TIMER: { id: null, type: "Timer", N: !0, O: !0 },
      VIDEO_COMPLETE: { id: null, type: "Counter", N: !0, O: !1 },
      VIDEO_INTERACTION: { id: null, type: "Counter", N: !0, O: !0 },
      VIDEO_PAUSE: { id: null, type: "Counter", N: !0, O: !0 },
      VIDEO_MUTE: { id: null, type: "Counter", N: !0, O: !0 },
      VIDEO_REPLAY: { id: null, type: "Counter", N: !0, O: !0 },
      VIDEO_FIRST_QUARTILE: { id: null, type: "Counter", N: !0, O: !0 },
      VIDEO_MIDPOINT: { id: null, type: "Counter", N: !0, O: !0 },
      VIDEO_THIRD_QUARTILE: { id: null, type: "Counter", N: !0, O: !0 },
      VIDEO_STOP: { id: null, type: "Counter", N: !0, O: !0 },
      VIDEO_UNMUTE: { id: null, type: "Counter", N: !0, O: !0 },
      BACKUP_IMAGE_IMPRESSION: { id: null, type: "Counter", N: !0, O: !0 },
      HTML5_CREATIVE_IMPRESSION: { id: null, type: "Counter", N: !0, O: !0 },
    },
    Hi = function (a) {
      var b = Gi[a];
      return b ? new Ei(a, b.id, b.type, b.N, b.O) : null;
    };
  var Ii = {
    3: "INTERACTION_TIMER",
    EVENT_USER_INTERACTION: "INTERACTIVE_IMPRESSION",
    EVENT_MANUAL_CLOSE: "MANUAL_CLOSE",
    EVENT_VIDEO_PLAY: "VIDEO_PLAY",
    EVENT_VIDEO_VIEW_TIMER: "VIDEO_VIEW_TIMER",
    EVENT_VIDEO_COMPLETE: "VIDEO_COMPLETE",
    EVENT_VIDEO_INTERACTION: "VIDEO_INTERACTION",
    EVENT_VIDEO_PAUSE: "VIDEO_PAUSE",
    EVENT_VIDEO_MUTE: "VIDEO_MUTE",
    EVENT_VIDEO_REPLAY: "VIDEO_REPLAY",
    EVENT_VIDEO_FIRSTQUARTILE: "VIDEO_FIRST_QUARTILE",
    EVENT_VIDEO_MIDPOINT: "VIDEO_MIDPOINT",
    EVENT_VIDEO_THIRDQUARTILE: "VIDEO_THIRD_QUARTILE",
    EVENT_VIDEO_STOP: "VIDEO_STOP",
    EVENT_VIDEO_UNMUTE: "VIDEO_UNMUTE",
    EVENT_FULLSCREEN: "FULL_SCREEN",
    DISPLAY_TIMER: "DISPLAY_TIMER",
    INTERACTION_TIMER: "INTERACTION_TIMER",
    INTERACTIVE_IMPRESSION: "INTERACTIVE_IMPRESSION",
    MANUAL_CLOSE: "MANUAL_CLOSE",
    EXPAND_TIMER: "EXPAND_TIMER",
    FULL_SCREEN: "FULL_SCREEN",
    SCROLL: "SCROLL",
    LARGE_SCROLL: "LARGE_SCROLL",
    SMALL_SCROLL: "SMALL_SCROLL",
    ENGAGEMENT: "ENGAGEMENT",
    VIDEO_PLAY: "VIDEO_PLAY",
    VIDEO_VIEW_TIMER: "VIDEO_VIEW_TIMER",
    VIDEO_COMPLETE: "VIDEO_COMPLETE",
    VIDEO_INTERACTION: "VIDEO_INTERACTION",
    VIDEO_PAUSE: "VIDEO_PAUSE",
    VIDEO_MUTE: "VIDEO_MUTE",
    VIDEO_REPLAY: "VIDEO_REPLAY",
    VIDEO_FIRST_QUARTILE: "VIDEO_FIRST_QUARTILE",
    VIDEO_MIDPOINT: "VIDEO_MIDPOINT",
    VIDEO_THIRD_QUARTILE: "VIDEO_THIRD_QUARTILE",
    VIDEO_STOP: "VIDEO_STOP",
    VIDEO_UNMUTE: "VIDEO_UNMUTE",
    BACKUP_IMAGE_IMPRESSION: "BACKUP_IMAGE_IMPRESSION",
    HTML5_CREATIVE_IMPRESSION: "HTML5_CREATIVE_IMPRESSION",
  };
  var Ji = ua([
      "https://s0.2mdn.net/ads/richmedia/studio/mu/templates/hifi/hifi.js",
    ]),
    Ki = ua([
      "https://s0.2mdn.net/ads/richmedia/studio_canary/mu/templates/hifi/hifi_canary.js",
    ]);
  ({}[3] = Cd(Ji));
  ({}[3] = Cd(Ki));
  var Li = function (a) {
      if (a == 2 && u.googletag && u.googletag.hostpageLibraryTokens)
        return u.googletag.hostpageLibraryTokens;
      if (a == 0) return u.goog_safeframe_hlt;
      if (a == 1)
        try {
          return u.parent.googletag.hostpageLibraryTokens;
        } catch (b) {}
      return {};
    },
    Mi = function () {
      var a = Li(0);
      qd(a) && (a = Li(1));
      qd(a) && (a = Li(2));
      return a;
    };
  var fe = [
    "http://tpc.googlesyndication.com",
    "https://tpc.googlesyndication.com",
    "https://secureframe.doubleclick.net",
  ];
  var Ni = function () {
      this.A = 1;
      this.g = null;
      this.o = "*";
      this.j = "";
      this.v = !0;
    },
    Oi = function (a) {
      M.call(this);
      this.A = u;
      this.o = a.g || null;
      this.j = a.o;
      this.B = a.j;
      this.v = kg();
      this.g = null;
    };
  q(Oi, M);
  Oi.prototype.H = function () {
    this.v.promise.cancel();
    this.g && Df(this.g);
  };
  var Pi = function (a, b) {
      var c = "*" == a.j || a.j == b.origin;
      return (null == a.o || a.o == b.source) && c;
    },
    Qi = function (a) {
      return "REQ_BASE" == a || "REQ_BASE_USE_PM" == a;
    };
  Oi.prototype.C = function () {
    var a = this,
      b = null,
      c = null;
    this.g = O(this.A, "message", function (d) {
      var e = d.ra;
      Pi(a, e) &&
        ((d = b && (b.isInitialized() || c == e.source)),
        Qi(e.data) && !d
          ? (b && (b.dispose(), (b = null)),
            (d = e.data == "REQ_BASE"),
            (c = e.source),
            (b = new Nd(c, a.B, d)),
            b.registerApplicationHandler("connection", function (f) {
              "ACK" == f &&
                ((a.o = e.source), Df(a.g), (a.g = null), a.v.resolve(b));
            }),
            e.source.postMessage("BASE_Y", a.j),
            e.stopImmediatePropagation())
          : "REMOTE_Y" == e.data &&
            e.source == c &&
            (b.sendMessage("connection", "SYN"), e.stopImmediatePropagation()));
    });
    return this.v.promise;
  };
  var Ri = function (a) {
    M.call(this);
    this.D = u;
    this.v = a.g;
    this.o = a.o;
    this.F = a.j;
    this.B = a.v;
    this.A = kg();
    this.g = null;
    this.j = new T(200);
  };
  q(Ri, M);
  Ri.prototype.H = function () {
    this.A.promise.cancel();
    wh(this.j);
    this.j.dispose();
  };
  var Si = function (a, b) {
    ("*" != a.o && a.o != b.origin) ||
      a.v != b.source ||
      "BASE_Y" != b.data ||
      (a.g && (a.g.dispose(), (a.g = null)),
      (a.g = ge(a.v, b.origin, a.F, a.B)),
      a.g &&
        (a.g.registerApplicationHandler("connection", function (c) {
          "SYN" == c &&
            (a.g.sendMessage("connection", "ACK"), a.A.resolve(a.g));
        }),
        a.v.postMessage("REMOTE_Y", a.o)));
  };
  Ri.prototype.C = function () {
    var a = this,
      b = O(this.D, "message", function (d) {
        Si(a, d.ra);
      }),
      c = this.B ? "REQ_BASE" : "REQ_BASE_USE_PM";
    this.v.postMessage(c, this.o);
    O(this.j, "tick", function () {
      a.v.postMessage(c, a.o);
    });
    this.A.promise.then(function () {
      wh(a.j);
      var d = a.j;
      if (d)
        if (jf(d)) d.ea && qf(d.ea);
        else if ((d = yf(d))) {
          var e = 0,
            f;
          for (f in d.g)
            for (var g = d.g[f].concat(), h = 0; h < g.length; ++h)
              Df(g[h]) && ++e;
        }
      Df(b);
    });
    this.j.start();
    return this.A.promise;
  };
  var Ti = function (a) {
    M.call(this);
    this.o = a;
    this.j = kg();
    this.g = null;
  };
  q(Ti, M);
  k = Ti.prototype;
  k.H = function () {
    this.o.dispose();
    var a = this.g;
    a && a.dispose && a.dispose();
  };
  k.connect = function (a) {
    var b = this;
    this.o.C().then(function (c) {
      b.g = c;
      b.j.resolve(c);
      a && a();
    });
  };
  k.isConnected = function () {
    return this.g ? this.g.isInitialized() : !1;
  };
  k.Na = function (a, b) {
    this.j.promise.then(function (c) {
      c.registerApplicationHandler(a, function (d) {
        b(typeof d === "number" ? d + "" : d);
      });
    });
  };
  k.ub = function () {};
  k.ua = function (a, b) {
    this.g
      ? this.g.sendMessage(a, b)
      : this.j.promise.then(function (c) {
          c.sendMessage(a, b);
        });
  };
  var Ui = function (a) {
    return typeof a.className == "string"
      ? a.className
      : (a.getAttribute && a.getAttribute("class")) || "";
  };
  var Zi = function (a) {
      var b = {},
        c = b.document || document,
        d = cd(a).toString(),
        e = ce(new Rd(c), "SCRIPT"),
        f = { Zb: e, ec: void 0 },
        g = new R(Vi, f),
        h = null,
        l = b.timeout != null ? b.timeout : 5e3;
      l > 0 &&
        ((h = window.setTimeout(function () {
          Wi(e, !0);
          g.B(new Xi(1, "Timeout reached for loading script " + d));
        }, l)),
        (f.ec = h));
      e.onload = e.onreadystatechange = function () {
        (e.readyState &&
          e.readyState != "loaded" &&
          e.readyState != "complete") ||
          (Wi(e, b.Tf || !1, h), g.ca(null));
      };
      e.onerror = function () {
        Wi(e, !0, h);
        g.B(new Xi(0, "Error while loading script " + d));
      };
      f = b.attributes || {};
      sd(f, { type: "text/javascript", charset: "UTF-8" });
      Wd(e, f);
      hd(e, a);
      Yi(c).appendChild(e);
    },
    Yi = function (a) {
      var b = (a || document).getElementsByTagName("HEAD");
      return b && b.length !== 0 ? b[0] : a.documentElement;
    },
    Vi = function () {
      if (this && this.Zb) {
        var a = this.Zb;
        a && a.tagName == "SCRIPT" && Wi(a, !0, this.ec);
      }
    },
    Wi = function (a, b, c) {
      c != null && u.clearTimeout(c);
      a.onload = function () {};
      a.onerror = function () {};
      a.onreadystatechange = function () {};
      b &&
        window.setTimeout(function () {
          ae(a);
        }, 0);
    },
    Xi = function (a, b) {
      var c = "Jsloader error (code #" + a + ")";
      b && (c += ": " + b);
      La.call(this, c);
      this.code = a;
    };
  B(Xi, La);
  function $i(a) {
    a = aj(a);
    return fd(a);
  }
  function bj(a) {
    a = aj(a);
    return bd(a);
  }
  function aj(a) {
    return a === null ? "null" : a === void 0 ? "undefined" : a;
  }
  var cj = function (a, b, c, d, e) {
      this.C = a;
      this.g = "";
      b &&
        (this.g = /^(http[s]?:)?\/\//.test(b)
          ? b
          : "//pagead2.googlesyndication.com/activeview?avi=" + b);
      this.B = c || "";
      this.v = !1;
      this.A =
        d || "//www.googletagservices.com/activeview/js/current/lidar.js";
      this.j = e || null;
      this.o = e !== void 0 && !!e["data-google-av-turtlex"];
    },
    dj = function (a, b) {
      b.setAttribute("id", "DfaVisibilityIdentifier_" + A());
      if (b.classList) b.classList.add("GoogleActiveViewClass");
      else {
        if (b.classList) var c = !b.classList.contains("GoogleActiveViewClass");
        else
          (c = b.classList ? b.classList : Ui(b).match(/\S+/g) || []),
            (c = !(Na(c, "GoogleActiveViewClass") >= 0));
        c &&
          ((c = Ui(b)),
          (c +=
            c.length > 0 ? " GoogleActiveViewClass" : "GoogleActiveViewClass"),
          typeof b.className == "string"
            ? (b.className = c)
            : b.setAttribute && b.setAttribute("class", c));
      }
      b._avicxn_ = a.g;
      b._avm_ = a.B;
      if (a.j) {
        b.classList.add(a.j.active_view_class_name);
        for (var d in a.j)
          a.j.hasOwnProperty(d) &&
            d.indexOf("data-google-av") === 0 &&
            b.setAttribute(d, a.j[d]);
      }
      a.v || (Zi(bj(a.A)), (a.v = !0));
    },
    fj = function (a) {
      (a.g || a.o) && ej(a.C, a.g + "&id=lidar2&r=w&rs=5r&v=0");
    };
  var gj = function (a, b, c) {
    N.call(this, a);
    this.data = c;
  };
  B(gj, N);
  var hj = function (a, b, c, d) {
    N.call(this, a);
    this.j = b;
    this.C = c;
    this.G = !!d;
  };
  B(hj, N);
  var ij = function (a, b, c, d) {
    b == "Count" && (d = !0);
    hj.call(this, a, b, !0, d);
    this.o = c;
  };
  B(ij, hj);
  var jj = function (a, b, c, d) {
    ij.call(this, a, b, c);
    this.videoName = d;
  };
  B(jj, ij);
  var kj = function (a, b, c, d, e) {
    hj.call(this, a, b, !1, e);
    this.B = c;
    this.F = d;
  };
  B(kj, hj);
  var lj = function (a, b) {
    N.call(this, "reportCustomVariable");
    this.j = a;
    this.o = b;
  };
  B(lj, N);
  var mj = function (a, b, c, d, e, f) {
    kj.call(this, a, "Exit", b, !0);
    this.D = c != "null" ? c : null;
    this.o = d != "null" ? d : null;
    this.A = e;
    this.log = f;
  };
  B(mj, kj);
  var nj = function (a) {
    N.call(this, "invokeExternalJSFunction");
    this.j = a;
  };
  B(nj, N);
  var oj = function (a, b, c) {
    N.call(this, "setTimerAdjustment");
    this.j = a;
    this.o = b;
    this.A = c;
  };
  B(oj, N);
  var pj = function (a) {
    N.call(this, "registerChargeableEventName");
    this.j = a;
  };
  B(pj, N);
  var qj = function (a, b) {
    N.call(this, "updateVideoProgress");
    this.duration = a;
    this.currentTime = b;
  };
  B(qj, N);
  function rj(a, b) {
    switch (a) {
      case "logEvent":
        return sj(b);
      case "logVideoEvent":
        return new jj("logVideoEvent", b[0], Ii[b[2]], b[1]);
      case "updateVideoProgress":
        return new qj(b[1], b[2]);
      case "logEventFlushCounters":
        return (b[0] = "Exit"), sj(b, !0);
      case "logExitFlushEventsOpenPopup":
        return tj(b, !0);
      case "launchExit":
        return tj(b, !1);
      case "TURTLEX_AD_CLICKED":
        return new gj("TURTLEX_AD_CLICKED", null, b[0]);
      case "recordTimings":
        return new gj("recordTimings", null, b[0]);
      case "reportCustomVariable":
        return new lj(b[0], b[1]);
      case "flushCounters":
        return new N("flushCounters");
      case "conduitInitialized":
        return new gj("conduitInitialized", null, {
          features:
            b[1] && Array.isArray(b[1]) && b[1].length != 0 ? b[1] : null,
        });
      case "expandAsset":
        return new gj("expandAsset", null, b.length > 1 ? b[1] : null);
      case "expandRequested":
        return new gj("expandRequested", null, b.length > 1 ? b[1] : null);
      case "expandFinished":
      case "collapseAsset":
      case "collapseRequested":
      case "collapseFinished":
      case "tellAssetHide":
        return new gj(a);
      case "invokeExternalJSFunction":
        return new nj(b[0]);
      case "setTimerAdjustment":
        return new oj(Ii[b[0]], parseFloat(b[1]), parseFloat(b[2]));
      case "registerChargeableEventName":
        return new pj(b[0]);
      case "fullscreenExpandRequested":
        return new gj(a, null, b);
      case "setResponsiveBehavior":
        return new gj(a, null, { behavior: b[0], state: b[1] });
      case "responsiveResize":
        return new gj(a, null, { width: b[0], height: b[1] });
      case "isFullscreenSupported":
      case "queryFullscreenDimensions":
      case "fullscreenExpandFinished":
      case "fullscreenCollapseRequested":
      case "fullscreenCollapseFinished":
        return new gj(a);
      case "AD_CLICKED":
        return new N("AD_CLICKED");
      case "registerEventTypeListenerForType":
        return new gj(a, null, { type: b[0], Od: b[1] });
      case "getHostpageFeatures":
        return new gj("getHostpageFeatures", null, { type: b[0] });
    }
    return null;
  }
  function sj(a, b) {
    var c = a[0],
      d = a[1],
      e = uj(a[3]);
    return uj(a[4])
      ? new kj("logEvent", c, d, e, b)
      : new ij("logEvent", c, Ii[d], b);
  }
  function tj(a, b) {
    return new mj(
      "logExitFlushEventsOpenPopup",
      a[1],
      a[4],
      a[5] || null,
      a[6],
      b
    );
  }
  function uj(a) {
    return a != null ? a.toString().toLowerCase() == "true" : !1;
  }
  var vj = function (a) {
    a = a ? a.toLowerCase() : "";
    switch (a) {
      case "normal":
        return "normal";
      case "lightbox":
        return "lightbox";
      case "push_down":
        return "push_down";
    }
    return null;
  };
  var xj = function (a) {
      this.P = a.eventReportingUrl || "";
      this.A = a.clickUrl || "";
      this.L = a.clickUrlTimesToEscape || "1";
      this.g = a.clickEventTagUrl || "";
      this.j = a.impressionUrl || "";
      this.M = a.geoData || "";
      this.V = a.siteName || "";
      this.U = a.siteId || "";
      this.F = a.adId || "";
      this.I = a.buyId || "";
      this.creativeId = a.creativeId || "";
      this.R = a.placementId || "";
      this.G = a.advertiserId || "";
      this.W = a.keyValueOrdinal || "";
      this.S = a.renderingId || "";
      this.randomNumber = a.randomNumber || "";
      this.Y = a.stringReportingUrl || "";
      this.o = a.bookingTimeMetaData || {};
      this.C = new wj(a.tag || {});
      this.Z = a.urlToGetKeywordsFor || "";
      this.J = a.exitSuffix || "";
      this.B = a.dynamicData || "";
      this.K = a.exitUrlPatternMacroValues;
      this.D = a.activeViewClkStr || "";
      this.v = a.activeViewUrlPrefix || "";
    },
    wj = function (a) {
      this.j = a.adContainerElementId;
      this.g = a.runtimeMetaData || {};
      this.o = !!a.renderFloatInplace;
    };
  var yj = function (a, b) {
    this.g = a;
    this.j = b;
    this.o = b == "push_down";
  };
  function zj(a, b, c) {
    this.position = a;
    this.startTime = b;
    this.j = b > -1;
    this.endTime = c;
    this.g = c > -1;
  }
  function Aj(a, b) {
    this.j = a;
    this.g = E(H(b)) ? "0_0" : b;
  }
  var Bj = function () {
    this.g = !1;
  };
  var Dj = function (a, b) {
      this.top = parseInt(a, 10);
      this.j = Cj(a);
      this.left = parseInt(b, 10);
      this.g = Cj(b);
    },
    Cj = function (a) {
      return (
        Sa(Ej, function (b) {
          var c = String(b).toLowerCase();
          b = String(a.slice(a.length - b.length)).toLowerCase();
          return (c < b ? -1 : c == b ? 0 : 1) == 0;
        }) || "px"
      );
    },
    Ej = ["px", "%", "pxc"];
  var Fj = {
    ue: "ad_container_id",
    Se: "hideObjects",
    sf: "mtfTop",
    rf: "mtfLeft",
    Rf: "zindex",
    Ce: "mtfDuration",
    Qf: "wmode",
    tf: "preferFlash",
    Ne: "as_kw",
    Oe: "as_lat",
    Pe: "as_lng",
    We: "mtfIFPath",
    Je: "expansionMode",
    xf: "mtfRenderFloatInplace",
    ze: "debugjs",
    af: "dcapp",
    qe: "breakoutiframe",
    bf: "inMobileAdSdk",
  };
  (function () {
    var a = {};
    md(Fj, function (b) {
      a[b.toLowerCase()] = b;
    });
    return a;
  })();
  var Gj = function (a, b, c, d) {
    this.left = a;
    this.top = b;
    this.width = c;
    this.height = d;
  };
  Gj.prototype.contains = function (a) {
    return a instanceof Od
      ? a.x >= this.left &&
          a.x <= this.left + this.width &&
          a.y >= this.top &&
          a.y <= this.top + this.height
      : this.left <= a.left &&
          this.left + this.width >= a.left + a.width &&
          this.top <= a.top &&
          this.top + this.height >= a.top + a.height;
  };
  var Hj = function (a) {
    return new I(a.width, a.height);
  };
  Gj.prototype.ceil = function () {
    this.left = Math.ceil(this.left);
    this.top = Math.ceil(this.top);
    this.width = Math.ceil(this.width);
    this.height = Math.ceil(this.height);
    return this;
  };
  Gj.prototype.floor = function () {
    this.left = Math.floor(this.left);
    this.top = Math.floor(this.top);
    this.width = Math.floor(this.width);
    this.height = Math.floor(this.height);
    return this;
  };
  Gj.prototype.round = function () {
    this.left = Math.round(this.left);
    this.top = Math.round(this.top);
    this.width = Math.round(this.width);
    this.height = Math.round(this.height);
    return this;
  };
  var Ij = function (a, b, c, d, e) {
      this.id = a;
      this.A = b;
      this.v = c;
      this.L =
        c == "BANNER" ||
        c == "EXPANDABLE" ||
        c == "VPAID_LINEAR" ||
        c == "VPAID_NON_LINEAR";
      this.width = d.width;
      this.height = d.height;
      this.F = this.C = null;
      this.B = e;
      this.I = null;
      this.D = 0;
      this.layoutsConfig = this.G = this.g = this.j = this.o = null;
    },
    Jj = {
      adContainerElementId: "ad_container_id",
      zIndex: "zindex",
      expansionMode: "expansionMode",
      duration: "mtfDuration",
      wmode: "wmode",
      top: "mtfTop",
      left: "mtfLeft",
      renderFloatInplace: "mtfRenderFloatInplace",
    },
    Kj = function (a) {
      var b = a.g && a.g.g;
      if (b) {
        var c = b.left,
          d = b.top;
        Math.abs(c) <= 3 && (b.left = 0);
        Math.abs(d) <= 3 && (b.top = 0);
        Math.abs(c + b.width - a.width) <= 3 &&
          (b.left == 0 ? (b.width = a.width) : (b.left = a.width - b.width));
        Math.abs(d + b.height - a.height) <= 3 &&
          (b.top == 0 ? (b.height = a.height) : (b.top = a.height - b.height));
      }
    };
  Ij.prototype.toString = function () {
    return "[PrimaryFile " + this.id + "]";
  };
  var Lj = function (a, b) {
      var c = b.zindex;
      c != null && ((c = parseInt(c, 10)), isNaN(c) || (a.D = c));
      c = b.expansionMode;
      c == null ||
        E(H(c)) ||
        a.g === null ||
        ((c = vj(c)), c !== null && (a.g.j = c));
      if (a.j !== null) {
        c = parseInt(b.mtfDuration, 10);
        isNaN(c) || ((a.j.endTime = c), (a.j.g = !0));
        c = [];
        var d = b.mtfLeft;
        c[0] = b.mtfTop;
        c[1] = d;
        2 <= c.length &&
          ((d = parseInt(c[0], 10)),
          isNaN(d) || ((a.j.position.top = d), (a.j.position.j = Cj(c[0]))),
          (d = parseInt(c[1], 10)),
          isNaN(d) || ((a.j.position.left = d), (a.j.position.g = Cj(c[1]))));
      }
      c = b.mtfRenderFloatInplace;
      if (a.L || "true" == c) (b = b.ad_container_id), E(H(b)) || (a.F = b);
    },
    Mj = function (a) {
      return typeof a === "number" && !isNaN(a);
    };
  function Nj(a, b, c) {
    this.g = a;
    this.j = b;
    this.ac = !!c;
  }
  Nj.prototype.sa = function () {
    return this.g;
  };
  Nj.prototype.ping = function () {
    ej(this.j, this.g, this.ac);
  };
  var Oj = {
      se: "CLICK",
      Ze: "IMPRESSION_JS",
      Ye: "IMPRESSION_IMG",
      me: "ARTWORK_IMPRESSION",
      De: "ENGAGEMENT_IMG",
      Ie: "EXPANSION",
    },
    Pj = ["IMPRESSION_IMG", "ARTWORK_IMPRESSION"];
  v("THIRD_PARTY_TYPES_TO_PING_AT_IMPRESSION_TIME", Pj);
  var Qj = function (a) {
    a: {
      for (b in Oj)
        if (Oj[b] == a) {
          var b = !0;
          break a;
        }
      b = !1;
    }
    return b ? a : null;
  };
  function Rj() {
    return wb ? "-webkit" : vb ? "-moz" : null;
  }
  var Sj = {},
    Tj = function (a, b) {
      var c = Sj[b];
      if (!c) {
        var d = kd(b);
        c = d;
        a.style[d] === void 0 &&
          ((d = (wb ? "Webkit" : vb ? "Moz" : null) + ld(d)),
          a.style[d] !== void 0 && (c = d));
        Sj[b] = c;
      }
      return c;
    },
    Uj = function (a, b) {
      var c = a.style[kd(b)];
      return typeof c !== "undefined" ? c : a.style[Tj(a, b)] || "";
    },
    Vj = function (a, b) {
      var c = Sd(a);
      return c.defaultView &&
        c.defaultView.getComputedStyle &&
        (a = c.defaultView.getComputedStyle(a, null))
        ? a[b] || a.getPropertyValue(b) || ""
        : "";
    },
    Wj = function (a, b) {
      return (
        Vj(a, b) ||
        (a.currentStyle ? a.currentStyle[b] : null) ||
        (a.style && a.style[b])
      );
    },
    Yj = function (a, b, c) {
      if (b instanceof Od) {
        var d = b.x;
        b = b.y;
      } else (d = b), (b = c);
      a.style.left = Xj(d, !1);
      a.style.top = Xj(b, !1);
    },
    Zj = function (a) {
      try {
        return a.getBoundingClientRect();
      } catch (b) {
        return { left: 0, top: 0, right: 0, bottom: 0 };
      }
    },
    ak = function (a) {
      var b = Sd(a),
        c = new Od(0, 0);
      if (a == (b ? Sd(b) : document).documentElement) return c;
      a = Zj(a);
      var d = Td(b).g;
      b = Yd(d);
      d = d.defaultView;
      b = new Od(d.pageXOffset || b.scrollLeft, d.pageYOffset || b.scrollTop);
      c.x = a.left + b.x;
      c.y = a.top + b.y;
      return c;
    },
    bk = function (a, b, c) {
      if (b instanceof I) (c = b.height), (b = b.width);
      else if (c == void 0) throw Error("missing height argument");
      a.style.width = Xj(b, !0);
      a.style.height = Xj(c, !0);
    },
    Xj = function (a, b) {
      typeof a == "number" && (a = (b ? Math.round(a) : a) + "px");
      return a;
    },
    dk = function (a) {
      var b = ck;
      if (Wj(a, "display") != "none") return b(a);
      var c = a.style,
        d = c.display,
        e = c.visibility,
        f = c.position;
      c.visibility = "hidden";
      c.position = "absolute";
      c.display = "inline";
      a = b(a);
      c.display = d;
      c.position = f;
      c.visibility = e;
      return a;
    },
    ck = function (a) {
      var b = a.offsetWidth,
        c = a.offsetHeight,
        d = wb && !b && !c;
      return (b === void 0 || d) && a.getBoundingClientRect
        ? ((a = Zj(a)), new I(a.right - a.left, a.bottom - a.top))
        : new I(b, c);
    },
    ek = function (a) {
      var b = ak(a);
      a = dk(a);
      return new Gj(b.x, b.y, a.width, a.height);
    };
  function fk(a, b, c) {
    typeof a.addEventListener === "function" && a.addEventListener(b, c, !1);
  }
  function gk(a, b, c) {
    typeof a.removeEventListener === "function" &&
      a.removeEventListener(b, c, !1);
  }
  function hk(a, b, c, d, e) {
    e = e === void 0 ? !1 : e;
    a.google_image_requests || (a.google_image_requests = []);
    var f = Dd("IMG", a.document);
    if (d) {
      var g = function () {
        d && Ta(a.google_image_requests, f);
        gk(f, "load", g);
        gk(f, "error", g);
      };
      fk(f, "load", g);
      fk(f, "error", g);
    }
    c && (f.referrerPolicy = "no-referrer");
    e && (f.attributionSrc = "");
    f.src = b;
    a.google_image_requests.push(f);
  }
  var ik = Sc(function () {
    return "referrerPolicy" in Dd("IMG");
  });
  var jk = function (a) {
      this.g = !!a;
    },
    ej = function (a, b, c) {
      if (c) {
        if (!a.g && !E(H(b)) && b !== null) {
          var d = d === void 0 ? !1 : d;
          var e = e === void 0 ? !1 : e;
          ik()
            ? hk(window, b, !0, d, e)
            : ((a = u.document),
              a.body
                ? ((c = a.getElementById("goog-srcless-iframe")),
                  c ||
                    ((c = Dd("IFRAME")),
                    (c.style.display = "none"),
                    (c.id = "goog-srcless-iframe"),
                    a.body.appendChild(c)),
                  (a = c))
                : (a = null),
              a && a.contentWindow && hk(a.contentWindow, b, !0, d, e));
        }
      } else
        a.g ||
          E(H(b)) ||
          (window.studioV2_image_requests ||
            (window.studioV2_image_requests = []),
          (d = $d(document, "img")),
          (d.src = b),
          window.studioV2_image_requests.push(d));
    };
  function kk() {
    this.o =
      this.v =
      this.B =
      this.height =
      this.width =
      this.j =
      this.target =
      this.g =
        "";
    this.A = [];
  }
  var lk = function (a) {
    var b = Sa(a.primaryFiles, function (f) {
      return "BACKUP_IMAGE" == f.renderAs;
    });
    if (b === null) return null;
    var c = new kk();
    c.j = b.url || c.j;
    c.width = b.width || c.width;
    c.height = b.height || c.height;
    c.B = a.impressionUrl;
    b = Sa(a.exitEvents, function (f) {
      return !!f.backUpExit;
    });
    b !== null &&
      (b.destinationUrl &&
        (c.g = a.clickUrl
          ? $e(a.clickUrl, b.destinationUrl, b.reportingId)
          : b.destinationUrl),
      (c.target = b.targetWindow || c.target));
    b = Sa(a.thirdPartyUrls, function (f) {
      return "IMPRESSION_IMG" == f.type;
    });
    b !== null && (c.o = b.url || c.o);
    if (a.thirdPartyUrls != null) {
      b = a.thirdPartyUrls;
      for (var d = new jk(a.previewMode || !1), e = 0; e < b.length; e++)
        Qj(b[e].type) == "CLICK" &&
          c.A.push(new Nj(b[e].url, d, b[e].scrub == "true"));
    }
    a = a.eventTrackingBaseUrl;
    a != null &&
      (";" != a.charAt(a.length - 1) && (a += ";"),
      (c.v = a + "met=1;&timestamp=" + +new Date() + ";eid1=9;ecn1=1;etm1=0;"));
    return c;
  };
  var mk = function (a) {
    this.j = a.sourceFilename;
    this.quality = a.quality;
    this.o = a.mimetype;
    this.g = a.isTeaser;
  };
  function nk(a, b, c, d) {
    this.name = a;
    this.url = b;
    d != null &&
      (this.url =
        this.url.indexOf("/") != 0 ? d + "/" + this.url : d + this.url);
    c && (this.url = this.url.replace(/^http:\/\//, "https://"));
    this.o = !1;
    this.g = this.j = null;
  }
  var ok = function (a, b) {
    b = new nk(a.name, a.url, b);
    if (a.isVideo) {
      var c = a.streamingUrl;
      a = a.transcodeInformation;
      b.o = !0;
      b.j = c || null;
      b.g = a ? new mk(a) : null;
    }
    return b;
  };
  var pk = function (a) {
    this.id = a.id;
    this.uniqueId = a.uniqueId;
    this.j = new xj(a.adServerData || {});
    this.v = a.isPreviewEnvironment;
    this.g = a.thirdPartyImpressionUrls || [];
    this.B = a.thirdPartyArtworkImpressionUrl;
    this.D = a.hasHtmlAsset;
    this.A = a.requiresCss3Animations;
    this.I = a.renderingLibrary || "";
    this.F = a.httpMediaServer || "";
    this.G = a.httpsMediaServer || "";
    this.o = a.html5FeatureChecks;
    var b;
    if ((b = a.backupImage)) {
      a = a.backupImage;
      b = this.v;
      var c = this.j.g,
        d = this.j.j;
      if (a == null) b = null;
      else {
        var e = new kk();
        e.g = a.exitUrl || e.g;
        e.target = a.target || e.target;
        e.j = a.imageUrl || e.j;
        e.width = a.width || e.width;
        e.height = a.height || e.height;
        e.v = a.backupDisplayActivityUrl || e.v;
        e.o = a.thirdPartyBackupImpressionUrl || e.o;
        e.B = d;
        E(H(c)) || (e.A = [new Nj(c, new jk(b))]);
        b = e;
      }
    }
    this.C = b || null;
  };
  var qk = function (a, b, c) {
    Ei.call(this, a, b, "Exit", !1, !0);
    this.url = c;
    this.o = "_blank";
    this.eTldPlusOne = this.j = null;
  };
  B(qk, Ei);
  var rk = {
    Qc: "varName",
    xe: "creativeId",
    ne: "assetId",
    vc: "click",
    Fe: "clickN",
    uc: "assets",
    Pf: "vcData",
    xc: "exitEvents",
    Sc: "thirdPartyClickRedirect",
    ve: "googleDiscoveryUrl",
    Ve: "adSiteUrl",
    Df: "isGCNAd",
    Ue: "td",
    Pc: "assetType",
    re: "br",
    qf: "os",
    rc: "sn",
    qc: "sid",
    ge: "adv",
    he: "buy",
    nc: "pid",
    lc: "aid",
    mc: "cid",
    oc: "rid",
    ke: "kid",
    je: "geo",
    ie: "randomNumber",
    wc: "dcData",
    gf: "ispushdown",
    He: "expEnv",
    Nc: "layoutsConfig",
    vf: "rv",
    ye: "customMetaData",
    uf: "previewFrameId",
    yc: "experiments",
    Rc: "rum_config",
    Tc: "turtlex_ad_signals",
    Oc: "newton_ot2_token",
  };
  var sk = function (a, b) {
      this.Eb = a;
      this.eb = b;
    },
    uk = function (a) {
      var b = a.split(":");
      if (b.length == 2 && ((a = b[0]), (b = tk[b[1]]))) return new sk(a, b);
    },
    tk = {
      Complete: "VIDEO_COMPLETE",
      Interaction: "VIDEO_INTERACTION",
      MidPoint: "VIDEO_MIDPOINT",
      Mute: "VIDEO_MUTE",
      Pause: "VIDEO_PAUSE",
      Play: "VIDEO_PLAY",
      Replay: "VIDEO_REPLAY",
      Stop: "VIDEO_STOP",
      Unmute: "VIDEO_UNMUTE",
      ViewTime: "VIDEO_VIEW_TIMER",
    };
  function vk(a, b, c, d) {
    this.g = d;
    d = !1;
    this.g && this.g.eb && (d = Hi(this.g.eb).B);
    Ei.call(this, a, b, c, !1, d);
  }
  B(vk, Ei);
  var wk = function (a) {
    var b = a.toLowerCase();
    a = [];
    var c = 0;
    /^https?:\/\//.test(b)
      ? ((a[0] = 0), (c = "s" == b.charAt(4) ? 8 : 7))
      : (a[0] = -1);
    a[1] = c;
    b = [
      b.indexOf(":", c),
      b.indexOf("/", c),
      b.indexOf("?", c),
      b.indexOf("#", c),
    ];
    for (c = 0; c < b.length; ++c)
      if (-1 == b[c]) a[c + 2] = -1;
      else {
        for (var d = !0, e = c + 1; e < b.length; ++e)
          b[e] > -1 && b[c] > b[e] && (d = !1);
        a[c + 2] = d ? b[c] : -1;
      }
    this.g = a;
  };
  var xk = function (a, b, c) {
      this.C = a;
      this.v = b.j;
      this.B = b.o;
      this.j = b.g;
      this.o = c.j;
      this.A = c.o;
      this.g = c.g;
    },
    yk = function (a, b, c) {
      this.j = a || null;
      this.o = b || null;
      this.g = c || null;
    };
  function zk(a, b) {
    if (a.o && a.o.g) {
      if (a.o.g == "latest") return !0;
      var c = a.o.g.split("_");
      if (c.length === 2)
        return (
          (a = parseInt(c[0], 10)),
          (c = parseInt(c[1], 10)),
          a > 1 || (a === 1 && c >= b)
        );
    }
    return !1;
  }
  function Ak(a, b) {
    if (typeof a === "boolean") return a;
    if (typeof a === "string") {
      if (a === "true") return !0;
      if (a === "false") return !1;
    }
    return b ? b : !1;
  }
  var Bk = function () {
      this.ka = !1;
      this.C = this.B = this.A = this.Xa = "";
      this.j = !1;
      this.Ha = "";
      this.oa = [];
      this.Ca = this.ma = !1;
      this.ga = "";
      this.P = null;
      this.g = {};
      this.J = "";
      this.fa = this.Da = this.R = !1;
      this.S = { jb: "", kb: "" };
      this.v = {};
      this.D = this.U = this.Z = "";
      this.M = 1;
      this.da = this.I = "";
      this.na = null;
      this.o = [];
      this.Y = [];
      this.Ja = [];
      this.Ia = {};
      this.W = {};
      this.ya = {};
      this.la = {};
      this.G = {};
      this.V = !1;
      var a = {};
      this.Ya =
        ((a.Exit = this.W), (a.Timer = this.ya), (a.Counter = this.la), a);
      this.F = this.K = null;
      this.xa = !1;
      this.Wa = 0;
      this.Ba = !1;
      this.Va = "";
    },
    Ck = function (a, b) {
      if (E(H(a))) return "";
      var c = new wk(a);
      var d = c.g[3];
      if (-1 == d) return a;
      a: {
        for (var e = 4; e < c.g.length; ++e)
          if (-1 != c.g[e]) {
            c = c.g[e];
            break a;
          }
        c = -1;
      }
      e = -1 == c ? a.substring(d) : a.substring(d, c);
      if (-1 == e.toLowerCase().indexOf(";" + b.toLowerCase() + "="))
        e += (";" == e.charAt(e.length - 1) ? "" : ";") + b + "=1;";
      else {
        var f = e.toLowerCase().indexOf(";" + b.toLowerCase() + "="),
          g = e.indexOf("=", f),
          h = e.indexOf(";", f + 1);
        e = e.replace(
          e.substring(f, g + 1) +
            (-1 == h ? e.substring(g + 1) : e.substring(g + 1, h)),
          ";" + b + "=1"
        );
      }
      return a.substring(0, d) + e + (-1 == c ? "" : a.substring(c));
    };
  Bk.prototype.toString = function () {
    return "Creative_" + this.B;
  };
  var Dk = function (a, b) {
      return a.P && void 0 !== a.P[b] ? a.P[b] : !1;
    },
    Ek = function (a) {
      for (
        var b = {}, c = ra(Object.keys(a.g)), d = c.next();
        !d.done;
        d = c.next()
      )
        (d = d.value),
          Object.values(rk).includes(d) ||
            Object.values(Fj).includes(d) ||
            Object.values(ui).includes(d) ||
            (b[d] = a.g[d]);
      return b;
    },
    Fk = function (a) {
      if (!a.g.CREATIVE_PARAMETER_NEWTON_OT2_TOKEN) return !1;
      try {
        var b = new URL(a.D);
        var c = new URLSearchParams(b.search).has("crd");
      } catch (f) {
        return !1;
      }
      try {
        var d = new URL(a.I);
        var e = new URLSearchParams(d.search).has("crd");
      } catch (f) {
        return !1;
      }
      return c && e;
    },
    Gk = function (a) {
      return !!a.g.CREATIVE_PARAMETER_TURTLEX_AD_SIGNALS;
    },
    Hk = function (a) {
      return a.fa ? a.S.kb : a.S.jb;
    },
    Ik = function (a, b) {
      if (b !== void 0) return b in a.v ? Va(a.v[b]) : [];
      b = [];
      for (var c in a.v) b = Ua(b, a.v[c]);
      return b;
    },
    Jk = function (a) {
      var b = [];
      C(a.o, function (c) {
        c.A == "HTML5" && b.push(c);
      });
      return b;
    },
    Mk = function (a, b, c) {
      var d = Kk(a, b);
      d && ((d.reportingId = c), (a.Ia[b] = d), Lk(a, d));
    },
    Ok = function (a, b) {
      var c = a.V;
      Nk(a, "EXPAND_TIMER", b);
      a.V = c;
    },
    Nk = function (a, b, c) {
      return (b =
        a.G[Pk(b, "Counter") || ""] || a.G[Pk(b, "Timer") || ""] || Kk(a, b))
        ? ((b.A = c), (a.V = !0))
        : !1;
    },
    Lk = function (a, b) {
      if (b) {
        var c;
        (c = b.v
          ? Qk(a, b.name)
          : b.g
          ? Rk(a, b.g.eb, b.g.Eb)
          : Pk(b.name, b.type)) && (a.G[c] = b);
      }
    },
    Sk = function (a, b) {
      var c = b.url;
      for (f in a.na) {
        var d = a.na[f],
          e = "(%pKEY=!;|%%PATTERN:KEY%%)".replace(/KEY/g, f);
        c = c.replace(new RegExp(e, "g"), d);
      }
      b.url = c;
      if (!a.j) {
        c = a.da;
        d = H(c);
        var f = RegExp("http.*http", "i");
        if ((e = !E(d))) {
          e = b.url;
          a: {
            for (
              var g = e.search(Ze), h = 0, l = d.length;
              (h = e.indexOf(d, h)) >= 0 && h < g;

            ) {
              var m = e.charCodeAt(h - 1);
              if (m == 38 || m == 63)
                if (
                  ((m = e.charCodeAt(h + l)),
                  !m || m == 61 || m == 38 || m == 35)
                ) {
                  d = h;
                  break a;
                }
              h += l + 1;
            }
            d = -1;
          }
          e = !(d >= 0);
        }
        e && !f.test(b.url) && (b.url = Ye(b.url, c));
      }
      a.W[b.name] = b;
      Lk(a, b);
    },
    Qk = function (a, b) {
      return (a = Kk(a, b))
        ? [b, escape(""), escape(""), a.type].join(":")
        : null;
    },
    Pk = function (a, b) {
      return ["CUSTOM_EVENT", escape(a), escape(""), b].join(":");
    },
    Rk = function (a, b, c) {
      return (a = Kk(a, b)) && [b, escape(""), escape(c), a.type].join(":");
    },
    Uk = function (a, b) {
      if (!b) return null;
      if (b.type == "CUSTOM_EVENT" || b.videoName) {
        if (b.type == "CUSTOM_EVENT" && !b.videoName) {
          var c = b.name;
          b = b.trigger;
          a.Ya[b]
            ? ((a = a.Ya[b]), (a = (a[c] && a[c].reportingId) || null))
            : (a = null);
          return a;
        }
        if (b.type != "CUSTOM_EVENT" && b.videoName) {
          a: switch (((c = b.videoName), (b = Kk(a, b.type)), b.type)) {
            case "Timer":
              a = Tk(a.ya, b, c);
              a = a != null ? a.reportingId : null;
              break a;
            case "Counter":
              a = Tk(a.la, b, c);
              a = a != null ? a.reportingId : null;
              break a;
            default:
              a = null;
          }
          return a;
        }
      } else return (a = Kk(a, b.type)) ? a.reportingId : null;
      return null;
    },
    Kk = function (a, b) {
      return a.Ia[b] || (a.Ia[b] = Hi(b));
    },
    Tk = function (a, b, c) {
      for (var d in a) {
        var e = a[d];
        if (e.g && e.g.Eb == c && e.g.eb == b.name) return e;
      }
      return null;
    },
    Vk = function (a, b) {
      a.Y.push(b);
      a.L = null;
    },
    Wk = function (a) {
      if (!a.L) {
        a.L = {};
        for (var b = 0; b < a.Y.length; b++) {
          var c = a.Y[b],
            d = c.name.toLowerCase();
          if (c.g) {
            if (!c.g.g) {
              c = c.g;
              var e = c.j.toLowerCase(),
                f = a.L[e];
              f || ((f = {}), (a.L[e] = f));
              e = f[c.quality];
              e || ((e = {}), (f[c.quality] = e));
              e[c.o] = d;
            }
          } else a.L[d] || (a.L[d] = {});
        }
      }
      return a.L;
    };
  Bk.prototype.Ea = !1;
  function Xk() {
    S.call(this);
    this.C = new Gf(this);
    ef(this, this.C);
  }
  B(Xk, S);
  var Zk = function () {
    var a = Yk,
      b = "Ga";
    if (a.Ga && a.hasOwnProperty(b)) return a.Ga;
    var c = new a();
    a.Ga = c;
    a.hasOwnProperty(b);
    return c;
  };
  var Yk = function () {
    Xk.call(this);
    this.g = window.mraid || null;
    this.B = !1;
    this.o = null;
  };
  q(Yk, Xk);
  Yk.prototype.isVisible = function () {
    return this.g.isViewable();
  };
  Yk.prototype.close = function () {
    return this.g.close();
  };
  Yk.prototype.init = function () {
    this.g.getState() == "loading"
      ? this.g.addEventListener("ready", z(this.v, this))
      : this.v();
  };
  var $k = function (a) {
    return a.g != null && a.g.AFMA_LIDAR != null;
  };
  Yk.prototype.v = function () {
    try {
      this.g.removeEventListener("ready", z(this.v, this));
    } catch (a) {
      this.g.removeEventListener("ready");
    }
    this.g.addEventListener("viewableChange", z(this.A, this));
    this.g.addEventListener("stateChange", z(this.D, this));
    this.j("ready");
    this.g.isViewable() && this.A();
  };
  Yk.prototype.D = function () {
    this.j("state_change");
  };
  Yk.prototype.A = function () {
    this.g.isViewable() ? this.j("show") : this.j("hide");
    !this.B &&
      $k(this) &&
      (this.g.addEventListener(this.g.AFMA_LIDAR, z(this.F, this)),
      (this.B = !0));
  };
  Yk.prototype.F = function (a) {
    var b = this.g.getCurrentPosition();
    b = (a.width * a.height) / (b.width * b.height);
    var c = new N("viewable_change");
    c.visibleBox = new Bi(a.y, a.x + a.width, a.y + a.height, a.x);
    c.visibilityFraction = b;
    this.j(c);
  };
  var al = function (a) {
    return a.o && a.o.enable_use_custom_tabs ? a.o.enable_use_custom_tabs : !1;
  };
  Yk.prototype.H = function () {
    this.g = null;
    Xk.prototype.H.call(this);
  };
  var bl = /doubleclick.net\/(pf)?ad/;
  var cl = Sc(function () {
    var a = $d(document, "DIV"),
      b = Rj(),
      c = "transition:opacity 1s linear;";
    b && (c += b + "-transition:opacity 1s linear;");
    id(a, Ad({ style: c }));
    return Uj(a.firstChild, "transition") != "";
  });
  var dl = function (a) {
      return (a = a.exec(eb())) ? a[1] : "";
    },
    el = (function () {
      if (Nb) return dl(/Firefox\/([0-9.]+)/);
      if (tb || ub || sb) return Ib;
      if (Rb) {
        if (
          pb() ||
          F("iPad") ||
          F("iPod") ||
          (ab && fb && fb.platform ? fb.platform === "macOS" : F("Macintosh"))
        ) {
          var a = dl(/CriOS\/([0-9.]+)/);
          if (a) return a;
        }
        return dl(/Chrome\/([0-9.]+)/);
      }
      if (Sb && !(pb() || F("iPad") || F("iPod")))
        return dl(/Version\/([0-9.]+)/);
      if (Ob || Pb) {
        if ((a = /Version\/(\S+).*Mobile\/(\S+)/.exec(eb())))
          return a[1] + "." + a[2];
      } else if (Qb)
        return (a = dl(/Android\s+([0-9.]+)/)) ? a : dl(/Version\/([0-9.]+)/);
      return "";
    })();
  var fl = yb || zb,
    gl,
    hl = document.createElement("VIDEO");
  gl =
    hl &&
    hl.canPlayType &&
    (hl.canPlayType("video/mp4").replace(/no/, "") || xb)
      ? !0
      : !1;
  var il,
    jl = document.createElement("VIDEO");
  il =
    jl && jl.canPlayType && jl.canPlayType("video/webm").replace(/no/, "")
      ? !0
      : !1;
  function kl(a, b) {
    if (!u.postMessage) return !1;
    a = Array.isArray(a) ? Va(a) : [];
    Sa(a, function (c) {
      return c == "Modernizr.canvas";
    }) || a.push("Modernizr.canvas");
    b &&
      !Sa(a, function (c) {
        return c == "Modernizr.cssanimations";
      }) &&
      a.push("Modernizr.cssanimations");
    return Ra(a, function (c) {
      if ("svgFilters" == c) {
        if (
          !(
            (tb && Jb("10") && Number(Mb) >= 10) ||
            (Rb && Za(el, "18") >= 0) ||
            (Nb && Za(el, "11") >= 0)
          )
        )
          return !1;
      } else if ("svgFeImage" == c) {
        if (
          !((tb && Jb("10") && Number(Mb) >= 10) || (Rb && Za(el, "29") >= 0))
        )
          return !1;
      } else if (/Modernizr.canvas/.test(c)) {
        if (!document.createElement("canvas").getContext) return !1;
      } else if (/Modernizr.cssanimations/.test(c)) {
        if (
          ((c = Yd(document).style),
          c.animationName === void 0 &&
            c[(wb ? "Webkit" : vb ? "Moz" : null) + "AnimationName"] === void 0)
        )
          return !1;
      } else if (/Modernizr.cssgradients/.test(c)) {
        c = "";
        for (var d, e = ["", Rj() + "-"], f = 0; f < e.length; f++)
          (d = f === 0 ? "to " : ""),
            (c +=
              "background-image:" +
              e[f] +
              "linear-gradient(" +
              d +
              "left top, #9f9, white);");
        d = $d(document, "A");
        d.style.cssText =
          c +
          "background-image:-webkit-gradient(linear,left top,right bottom,from(#9f9),to(white));";
        if (!(Uj(d, "backgroundImage").indexOf("gradient") > -1)) return !1;
      } else if (/Modernizr.csstransitions/.test(c) && !cl()) return !1;
      return !0;
    });
  }
  function ll(a, b, c, d, e, f, g, h, l, m) {
    if (b) {
      var n = Ud(document, c);
      id(
        n,
        $i(
          (E(H(b.g))
            ? [
                '<div style="width: ',
                b.width,
                "px; height: ",
                b.height,
                'px;"></div>',
              ]
            : [
                '<a target="',
                b.target,
                '" href="',
                b.g,
                '">',
                '<img src="',
                b.j,
                '" ',
                'width="',
                b.width,
                '" height="',
                b.height,
                '" ',
                'border="0"></a>',
              ]
          ).join("")
        )
      );
      d = new jk(d);
      var r = H(b.B);
      E(r) || ej(d, r);
      ej(d, b.v);
      ej(d, b.o);
      for (r = 0; r < e.length; r++) ej(d, e[r]);
      ml(a);
      m != null && m.length > 0 && nl(m, c);
      a = new cj(d, f, g, h, l);
      (a.g || a.o) && (a.g || a.o ? dj(a, n) : a.v || fj(a));
      E(H(b.g)) ||
        O(n, "click", function () {
          for (var D = 0; D < b.A.length; D++) b.A[D].ping();
        });
    }
  }
  function nl(a, b) {
    var c = Ud(document, b);
    if (c == null) {
      var d;
      (b = document.getElementsByTagName("HEAD")) && b.length > 0
        ? (d = b[0])
        : (d = document.documentElement);
      C(a, function (e) {
        d.appendChild(ol(e));
      });
    } else
      C(a, function (e) {
        c.parentNode.insertBefore(ol(e), c.nextSibling);
      });
  }
  function ol(a) {
    var b = $d(document, "SCRIPT");
    hd(b, bj(a));
    b.type = "text/javascript";
    b.async = !1;
    return b;
  }
  function ml(a) {
    var b = window.DARTDebugEventHandler;
    if (b) {
      b = new b();
      try {
        b.handleEventActivity(
          "BACKUP_IMAGE_IMPRESSION",
          "Counter",
          1,
          0,
          !1,
          a
        );
      } catch (c) {}
    }
  }
  var pl = function (a, b) {
    N.call(this, a);
    this.j = b;
  };
  q(pl, N);
  var ql =
    "EXPAND EXPAND_REQUEST EXPAND_FINISH COLLAPSE COLLAPSE_REQUEST COLLAPSE_FINISH EXPAND_FULL_SCREEN COLLAPSE_FULL_SCREEN SHOW HIDE".split(
      " "
    );
  var U = function (a, b) {
    M.call(this);
    this.j = b;
    this.I = new Gf(this);
    P(this.I, this.j, ql, this.J);
    this.g = a;
    this.G = [];
    this.F = [];
    this.B = [];
    this.o = [];
    this.D = [];
    this.C = [];
    this.A = [];
    this.v = [];
  };
  q(U, M);
  U.prototype.H = function () {
    this.I.dispose();
    this.v =
      this.A =
      this.o =
      this.C =
      this.D =
      this.B =
      this.F =
      this.G =
        null;
    M.prototype.H.call(this);
  };
  U.prototype.J = function (a) {
    if (a.j == this.g) {
      var b = null;
      switch (a.type) {
        case "SHOW":
          b = this.G;
          break;
        case "HIDE":
          b = this.F;
          break;
        case "COLLAPSE_REQUEST":
          b = this.A;
          break;
        case "COLLAPSE_FINISH":
          b = this.v;
          break;
        case "COLLAPSE":
          b = this.o;
          break;
        case "EXPAND":
          b = this.B;
          break;
        case "EXPAND_REQUEST":
          b = this.D;
          break;
        case "EXPAND_FINISH":
          b = this.C;
      }
      b && rl(this, b);
    }
  };
  var rl = function (a, b) {
      C(
        b,
        function (c) {
          c(this);
        },
        a
      );
    },
    sl = function (a) {
      return a.j.o[a.g] || null;
    };
  k = U.prototype;
  k.Ec = function () {
    return this.g.v;
  };
  k.Dc = function () {
    return this.g.id;
  };
  k.sd = function () {
    var a = sl(this);
    return a && (a = a.T())
      ? ((a = new Od(a.offsetLeft, a.offsetTop)), { x: a.x, y: a.y })
      : null;
  };
  k.Hc = function (a, b) {
    var c = sl(this);
    c && Yj(c.T(), a, b);
  };
  k.Ic = function (a) {
    var b = sl(this);
    if (b)
      if (((b = b.T()), typeof a === "string"))
        (a = Tj(b, a)) && (b.style[a] = void 0);
      else
        for (var c in a) {
          var d = b,
            e = a[c],
            f = Tj(d, c);
          f && (d.style[f] = e);
        }
  };
  k.rd = function () {
    var a = sl(this);
    return a && (a = a.T()) ? ((a = ak(a)), { x: a.x, y: a.y }) : null;
  };
  k.Kb = function () {
    return { width: this.g.width, height: this.g.height };
  };
  k.Sa = function (a, b) {
    var c = sl(this);
    c && c.Sa(a, b);
  };
  k.kd = function () {
    var a = this.g.g && this.g.g.g;
    return a ? { width: a.width, height: a.height } : this.Kb();
  };
  k.Gc = function (a, b, c, d) {
    var e = sl(this);
    e &&
      ((e.T().style.clip = [
        "rect(",
        a,
        "px ",
        b,
        "px ",
        c,
        "px ",
        d,
        "px)",
      ].join("")),
      (e.T().style.position = "absolute"));
  };
  k.ld = function () {
    var a = sl(this);
    return a ? a.T() : null;
  };
  k.Cc = function () {
    var a = sl(this);
    return a ? a.o : null;
  };
  k.bd = function (a) {
    this.G.push(a);
  };
  k.Wd = function (a) {
    Ta(this.G, a);
  };
  k.ad = function (a) {
    this.F.push(a);
  };
  k.Vd = function (a) {
    Ta(this.F, a);
  };
  k.Xc = function (a) {
    this.B.push(a);
  };
  k.Sd = function (a) {
    Ta(this.B, a);
  };
  k.Zc = function (a) {
    this.D.push(a);
  };
  k.Ud = function (a) {
    Ta(this.D, a);
  };
  k.Yc = function (a) {
    this.C.push(a);
  };
  k.Td = function (a) {
    Ta(this.C, a);
  };
  k.Uc = function (a) {
    this.o.push(a);
  };
  k.Pd = function (a) {
    Ta(this.o, a);
  };
  k.Wc = function (a) {
    this.A.push(a);
  };
  k.Rd = function (a) {
    Ta(this.A, a);
  };
  k.Vc = function (a) {
    this.v.push(a);
  };
  k.Qd = function (a) {
    Ta(this.v, a);
  };
  k.Jc = function () {
    tl(this.j, this.g);
  };
  k.Fc = function () {
    this.j.M(this.g);
  };
  k.Bc = function () {
    ul(this.j, this.g);
  };
  k.Ac = function () {
    vl(this.j, this.g);
  };
  U.prototype.getType = U.prototype.Ec;
  U.prototype.getId = U.prototype.Dc;
  U.prototype.getPosition = U.prototype.sd;
  U.prototype.setPosition = U.prototype.Hc;
  U.prototype.setStyle = U.prototype.Ic;
  U.prototype.getPagePosition = U.prototype.rd;
  U.prototype.getDimension = U.prototype.Kb;
  U.prototype.setDimension = U.prototype.Sa;
  U.prototype.getCollapsedDimension = U.prototype.kd;
  U.prototype.setClip = U.prototype.Gc;
  U.prototype.getContainerElement = U.prototype.ld;
  U.prototype.getAssetElement = U.prototype.Cc;
  U.prototype.addShowCallback = U.prototype.bd;
  U.prototype.removeShowCallback = U.prototype.Wd;
  U.prototype.addHideCallback = U.prototype.ad;
  U.prototype.removeHideCallback = U.prototype.Vd;
  U.prototype.addExpandCallback = U.prototype.Xc;
  U.prototype.removeExpandCallback = U.prototype.Sd;
  U.prototype.addExpandRequestCallback = U.prototype.Zc;
  U.prototype.removeExpandRequestCallback = U.prototype.Ud;
  U.prototype.addExpandFinishCallback = U.prototype.Yc;
  U.prototype.removeExpandFinishCallback = U.prototype.Td;
  U.prototype.addCollapseCallback = U.prototype.Uc;
  U.prototype.removeCollapseCallback = U.prototype.Pd;
  U.prototype.addCollapseRequestCallback = U.prototype.Wc;
  U.prototype.removeCollapseRequestCallback = U.prototype.Rd;
  U.prototype.addCollapseFinishCallback = U.prototype.Vc;
  U.prototype.removeCollapseFinishCallback = U.prototype.Qd;
  U.prototype.show = U.prototype.Jc;
  U.prototype.hide = U.prototype.Fc;
  U.prototype.expand = U.prototype.Bc;
  U.prototype.collapse = U.prototype.Ac;
  var wl = function (a, b) {
    M.call(this);
    this.g = a;
    this.v = b;
  };
  q(wl, M);
  wl.prototype.j = function () {
    return this.g.name;
  };
  wl.prototype.sa = function () {
    var a = this.g.url;
    return (/^https?/.test(a) ? "" : this.v) + a;
  };
  wl.prototype.o = function () {
    return this.g.o;
  };
  wl.prototype.A = function () {
    return this.g.j;
  };
  wl.prototype.getName = wl.prototype.j;
  wl.prototype.getUrl = wl.prototype.sa;
  wl.prototype.isVideo = wl.prototype.o;
  wl.prototype.getStreamingUrl = wl.prototype.A;
  function xl(a, b) {
    this.g = a;
    this.j = b;
  }
  xl.prototype.o = function () {
    return this.g.name;
  };
  xl.prototype.getName = xl.prototype.o;
  xl.prototype.sa = function () {
    return this.g.url;
  };
  xl.prototype.getUrl = xl.prototype.sa;
  xl.prototype.v = function (a, b) {
    this.j.sb(
      new mj(
        "logExitFlushEventsOpenPopup",
        this.g.name,
        a || null,
        b || null,
        null,
        !0
      )
    );
  };
  xl.prototype.fireExit = xl.prototype.v;
  var V = function (a, b) {
    M.call(this);
    this.j = a;
    this.v = b;
    this.g = yl(a.o, b);
    Wa(this.g, function (c) {
      return c.g.id;
    });
    this.A = zl(a.Y, Hk(a) || "");
    this.o = Al(a.W, b);
    this.AssetTypes = Bl;
    wm(this);
  };
  q(V, M);
  var yl = function (a, b) {
      return Pa(a, function (c) {
        return new U(c, b);
      });
    },
    zl = function (a, b) {
      return Pa(a, function (c) {
        return new wl(c, b);
      });
    },
    Al = function (a, b) {
      return Pa(pd(a), function (c) {
        return new xl(c, b);
      });
    },
    wm = function (a) {
      var b = y("studioV2.api.creatives") || [];
      v("studioV2.api.creatives", b);
      b.push(a);
    };
  k = V.prototype;
  k.H = function () {
    var a = y("studioV2.api.creatives");
    a && Array.isArray(a) && Ta(a, this);
    df(this.g, this.A, this.o);
    M.prototype.H.call(this);
  };
  k.md = function () {
    return this.j.B;
  };
  k.fd = function () {
    return this.j.g.cid || "";
  };
  k.hd = function () {
    return this.g;
  };
  k.gd = function (a) {
    return this.g[a] || null;
  };
  k.pd = function (a) {
    return Sa(this.g, function (b) {
      return b.g.v == a;
    });
  };
  k.jd = function (a) {
    return Oa(this.g, function (b) {
      return b.g.v == a;
    });
  };
  k.od = function () {
    return this.o;
  };
  k.be = function () {
    this.v.dispose();
  };
  V.prototype.getApiVersion = function () {
    return "";
  };
  V.prototype.getCreativeId = V.prototype.md;
  V.prototype.getSiteId = function () {
    return "";
  };
  V.prototype.getSiteName = function () {
    return "";
  };
  V.prototype.getAdId = function () {
    return "";
  };
  V.prototype.getBuyId = function () {
    return "";
  };
  V.prototype.getAdserverCreativeId = V.prototype.fd;
  V.prototype.getPlacementId = function () {
    return "";
  };
  V.prototype.getAdvertiserId = function () {
    return "";
  };
  V.prototype.getAssets = V.prototype.hd;
  V.prototype.getChildAssets = function () {
    return [];
  };
  V.prototype.getAssetAt = V.prototype.gd;
  V.prototype.getAssetById = function () {
    return null;
  };
  V.prototype.getFirstAssetByType = V.prototype.pd;
  V.prototype.getAssetsByType = V.prototype.jd;
  V.prototype.getExits = V.prototype.od;
  V.prototype.unload = V.prototype.be;
  var Bl = {
    INPAGE: "BANNER",
    EXPANDING: "EXPANDABLE",
    FLOAT: "FLOATING",
    OVERLAY: "OVERLAY",
  };
  var xm = new I(-1, -1),
    ym = new Od(-1, -1);
  var zm = void 0,
    Cm = function () {
      zm === void 0 && (zm = Sa(Am, Bm) || "none");
      return zm;
    },
    Bm = function (a) {
      switch (a) {
        case "msn":
          a: {
            try {
              var b =
                window.$WLXRmAd || (window.parent && window.parent.$WLXRmAd);
              break a;
            } catch (c) {}
            b = void 0;
          }
          return !!b;
        case "safe":
          return !!y("$sf.ext");
        case "mraid":
          return !!window.mraid;
        default:
          return !1;
      }
    },
    Am = ["gdn", "mraid", "safe", "msn", "none"];
  var Em = function (a) {
    M.call(this);
    this.j = a;
    this.g = Dm(this);
  };
  q(Em, M);
  Em.prototype.H = function () {
    Df(this.g);
    M.prototype.H.call(this);
  };
  var Dm = function (a) {
    return O(
      u,
      "message",
      function (b) {
        b = b.ra.data;
        try {
          var c = b.indexOf("|"),
            d = b.indexOf(":", c),
            e = b.indexOf("SETUP", d);
          var f = c > -1 && d > -1 && e > -1;
        } catch (g) {
          f = !1;
        }
        f && (Fm(this.j, "r", A()), Df(this.g));
      },
      void 0,
      a
    );
  };
  var Gm = function () {
    M.call(this);
    this.g = Zk();
    this.v = this.A = this.B = null;
    this.j = new T(200);
    ef(this, this.j);
    this.o = 0;
  };
  q(Gm, M);
  Gm.prototype.D = function (a) {
    var b = this.g.g.getCurrentPosition();
    if (this.g.isVisible()) {
      var c = 1;
      b = new Bi(0, b.width, b.height, 0);
    } else (c = 0), (b = new Bi(0, 0, 0, 0));
    c = af(c, b);
    a(c);
    this.o++;
    this.o >= 25 && wh(this.j);
  };
  Gm.prototype.F = function (a, b) {
    b = af(b.visibilityFraction, b.visibleBox);
    a(b);
  };
  Gm.prototype.C = function (a) {
    this.o = 0;
    wh(this.j);
    var b = this.j;
    a = z(this.D, this, a);
    b.ea.add("tick", a, !1, void 0, void 0);
    this.j.start();
  };
  Gm.prototype.H = function () {
    this.B && Df(this.B);
    this.A && Df(this.A);
    this.v && Df(this.v);
    M.prototype.H.call(this);
  };
  var Im = function (a, b, c, d) {
    M.call(this);
    this.o = a;
    this.B = b;
    this.C = c;
    this.v = d;
    this.A = !1;
    this.g = {};
    this.g.l = !1;
    this.g.i = !1;
    this.g.x = !1;
    this.g.c = !1;
    this.g.r = !1;
    this.g.n = !1;
    this.g.t = !1;
    this.g.m = !1;
    this.j = Hm(this);
  };
  q(Im, M);
  var Hm = function (a) {
      return a.o.isActive() && Za(a.v.replace("_", "."), "01.226") != -1
        ? vf(
            u,
            "unload",
            function () {
              Fm(this, "u", A());
            },
            void 0,
            a
          )
        : null;
    },
    Jm = function (a) {
      ej(a.B, a.o.j());
      a.A = !0;
      a.j && Df(a.j);
    };
  Im.prototype.H = function () {
    this.j && Df(this.j);
  };
  var Km = function (a) {
      return (
        Za(a.v.replace("_", "."), "01.226") != -1 &&
        !a.A &&
        (a.g.u ||
          od(a.g, function (b) {
            return b;
          }))
      );
    },
    Lm = function (a, b) {
      a.v = b;
      a.o.A = b;
      a.j = Hm(a);
      Km(a) && Jm(a);
    },
    Fm = function (a, b, c) {
      a.o.g[b] = c - a.C;
      a.g[b] = !0;
      Km(a) && Jm(a);
    };
  function Mm(a) {
    if (a && (a.Type === "video" || a.DrmVideoData)) {
      var b = a.DrmVideoData || {};
      b =
        (fl ? b.hls_url : "") ||
        (il ? b.webm_url : "") ||
        (gl ? b.mp4_url : "") ||
        a.Progressive_Url ||
        a.Url ||
        "";
      a.Type = "video";
      a.Url = b;
      a.Progressive_Url = b;
      delete a.DrmVideoData;
    } else if (Ca(a) && typeof a !== "function") for (b in a) Mm(a[b]);
  }
  var Nm = function (a) {
    this.aa = Ac(a);
  };
  q(Nm, Jc);
  var Om = "undefined_type",
    Pm = 0,
    Qm = null;
  function Rm() {
    try {
      if (u.document.referrer != "") return u.document.referrer;
      if (u.location.ancestorOrigins && u.location.ancestorOrigins[0])
        return u.location.ancestorOrigins[0];
      if (top != u) return u.parent.location.href;
    } catch (a) {}
    return u.location.href;
  }
  var Tm = function (a, b) {
      var c = Array.prototype.slice.call(arguments),
        d = c.shift();
      if (typeof d == "undefined")
        throw Error("[goog.string.format] Template required");
      return d.replace(
        /%([0\- \+]*)(\d+)?(\.(\d+))?([%sfdiu])/g,
        function (e, f, g, h, l, m, n, r) {
          if (m == "%") return "%";
          var D = c.shift();
          if (typeof D == "undefined")
            throw Error("[goog.string.format] Not enough arguments");
          arguments[0] = D;
          return Sm[m].apply(null, arguments);
        }
      );
    },
    Sm = {
      s: function (a, b, c) {
        return isNaN(c) || c == "" || a.length >= Number(c)
          ? a
          : (a =
              b.indexOf("-", 0) > -1
                ? a + jd(" ", Number(c) - a.length)
                : jd(" ", Number(c) - a.length) + a);
      },
      f: function (a, b, c, d, e) {
        d = a.toString();
        isNaN(e) || e == "" || (d = parseFloat(a).toFixed(e));
        var f =
          Number(a) < 0
            ? "-"
            : b.indexOf("+") >= 0
            ? "+"
            : b.indexOf(" ") >= 0
            ? " "
            : "";
        Number(a) >= 0 && (d = f + d);
        if (isNaN(c) || d.length >= Number(c)) return d;
        d = isNaN(e)
          ? Math.abs(Number(a)).toString()
          : Math.abs(Number(a)).toFixed(e);
        a = Number(c) - d.length - f.length;
        return (d =
          b.indexOf("-", 0) >= 0
            ? f + d + jd(" ", a)
            : f + jd(b.indexOf("0", 0) >= 0 ? "0" : " ", a) + d);
      },
      d: function (a, b, c, d, e, f, g, h) {
        return Sm.f(parseInt(a, 10), b, c, d, 0, f, g, h);
      },
    };
  Sm.i = Sm.d;
  Sm.u = Sm.d;
  var Um = function (a) {
      this.g = a;
    },
    Vm = function (a) {
      switch (a) {
        case "BANNER":
          return "Inpage";
        case "FLOATING":
          return "Floating";
        case "EXPANDABLE":
          return "Expanding";
        case "OVERLAY":
          return "Overlay";
        default:
          return "";
      }
    },
    $m = function (a) {
      var b = [],
        c = a.g.Y,
        d = Wm(),
        e = Wk(a.g);
      C(
        c,
        function (r) {
          r.g &&
            r.g.g &&
            b.push(escape("VT_" + r.g.j) + "=" + escape(Xm(r.url)));
        },
        a
      );
      var f = {},
        g;
      for (g in e)
        if (
          ((f = { bc: void 0, ab: void 0 }),
          (f.bc = Ym(e, g, d) || g),
          (f.ab = null),
          C(
            c,
            (function (r) {
              return function (D) {
                D.name.toLowerCase() === r.bc && (r.ab = D);
              };
            })(f),
            a
          ),
          f.ab)
        ) {
          Zm(a, b, g, f.ab);
          for (var h in e[g]) {
            var l = e[g][h],
              m;
            for (m in l) {
              var n = l[m];
              e[n] || Zm(a, b, n, f.ab);
            }
          }
        }
      return escape(b.join("&"));
    },
    Zm = function (a, b, c, d) {
      if (d.o)
        b.push(escape("PRO_" + c) + "=" + escape(Xm(d.url))),
          d.j != null && b.push(escape("STR_" + c) + "=" + escape(Xm(d.j)));
      else {
        var e = b.push;
        a =
          escape(c) +
          "=" +
          escape(Xm(/^https?:/.test(d.url) ? d.url : Hk(a.g) + d.url));
        e.call(b, a);
      }
    },
    Wm = function () {
      var a = [];
      fl && a.push("application/x-mpegurls");
      il && a.push("video/webm");
      gl && a.push("video/mp4");
      return a;
    },
    Ym = function (a, b, c) {
      if (c.length && a[b] && !qd(a[b]))
        a: {
          for (var d = 6; d >= 1 && d <= 6; ) {
            var e = a[b][d];
            if (e)
              for (var f = 0; f < c.length; f++)
                if (e[c[f]]) {
                  a = e[c[f]];
                  break a;
                }
            d += -1;
          }
          a = null;
        }
      else a = null;
      return a;
    },
    an = function (a) {
      return encodeURIComponent(a).replace(/[!'()*]/g, Rc());
    },
    W = function (a, b, c) {
      c = Xm(c);
      a[b] = c;
    },
    bn = function (a, b, c) {
      c &&
        !qd(c) &&
        md(
          c,
          function (d, e) {
            W(b, e, d);
          },
          a
        );
    },
    Xm = function (a) {
      return a == null
        ? ""
        : Aa(a) == "object" || Array.isArray(a)
        ? JSON.stringify(a)
        : String(a);
    };
  function cn(a, b) {
    this.j = a;
    this.o = b;
    this.v = new Um(a);
  }
  var en = function (a, b) {
      var c = a.v,
        d = a.o,
        e = {};
      W(e, "varName", b);
      W(e, "creativeId", c.g.B);
      W(e, "assetId", d.id);
      W(e, "rv", "200_287");
      W(e, "assetType", Vm(d.v));
      W(e, "previewFrameId", c.g.g.PREVIEW_FRAME_NAME || "layoutsPreviewFrame");
      W(e, "layoutsConfig", d.layoutsConfig || "");
      W(e, "click", c.g.D);
      W(e, "clickN", c.g.M);
      b = Ik(c.g, "CLICK");
      W(e, "thirdPartyClickRedirect", 1 == b.length ? b[0].sa() : "");
      W(e, "assets", $m(c));
      b = [];
      for (var f = c.g.Ja, g = 0; g < f.length; g++) {
        var h = f[g];
        b.push(
          escape(
            Tm(
              "name:%s,vfp_low:%s,vfp_mid:%s,vfp_high:%s,pfp_low:%s,pfp_mid:%s,pfp_high:%s",
              escape(h.C),
              escape(h.v || ""),
              escape(h.B || ""),
              escape(h.j || ""),
              escape(h.o || ""),
              escape(h.A || ""),
              escape(h.g || "")
            )
          )
        );
      }
      W(e, "vcData", b.join("{DELIM}"));
      b = [];
      f = c.g.W;
      for (var l in f)
        (g = f[l]),
          (h = Tm(
            "name:%s,url:%s,target:%s,reportingId:%s",
            escape(g.name),
            escape(g.url).replace(/\+/g, "%2B"),
            g.j ? "popup" : escape(g.o),
            g.reportingId ? g.reportingId : "",
            g.eTldPlusOne ? g.eTldPlusOne : ""
          )),
          /,/.test(g.url) && (h = escape(h)),
          b.push(h);
      W(e, "exitEvents", b.join("{DELIM}"));
      W(e, "sn", c.g.g.sn || "");
      W(e, "sid", c.g.g.sid || "");
      W(e, "adv", c.g.g.adv || "");
      W(e, "buy", c.g.g.buy || "");
      W(e, "pid", c.g.g.pid || "");
      W(e, "aid", c.g.g.aid || "");
      W(e, "cid", c.g.g.cid || "");
      W(e, "rid", c.g.g.rid || "");
      l = vi(c.g.g.geo || "");
      bn(c, e, l);
      W(e, "br", vb ? "ff" : Rb ? "cr" : Sb ? "sf" : tb ? "ie" : "ot");
      if ((l = !/^http/.test(window.location.href))) {
        b = window.parent;
        f = window;
        try {
          l = b.document.domain == f.document.domain;
        } catch (D) {
          l = !1;
        }
      }
      l = new Yh(l ? window.parent.location.href : window.location.href);
      W(e, "td", l.o + "://" + l.g);
      a: {
        if (c.g.j) {
          if (!E(H(c.g.ga)) && c.g.ga.indexOf("%") != 0) {
            l = c.g.ga;
            break a;
          }
          if (
            (l = document.getElementsByTagName("base")) &&
            l.length &&
            !E(H(l[0].href))
          ) {
            l = l[0].href;
            break a;
          }
        }
        l = Rm();
      }
      W(e, "adSiteUrl", l);
      W(
        e,
        "googleDiscoveryUrl",
        c.g.j
          ? "http://pagead2.googlesyndication.com/pagead/ads?client=dclk-3pas-query&output=xml&geo=true&adtest=on"
          : "http://pagead2.googlesyndication.com/pagead/ads?client=dclk-3pas-query&output=xml&geo=true"
      );
      a: {
        l = c.g.C;
        try {
          var m = JSON.parse(l);
        } catch (D) {
          m = l;
          break a;
        }
        Ca(m) ? (Mm(m), (m = Sh(m))) : (m = l);
      }
      W(e, "dcData", m);
      m = Ek(c.g);
      l = [];
      for (var n in m)
        (b = l),
          (f = b.push),
          (g = m[n]),
          (g = an(n) + "=" + an(Xm(g))),
          f.call(b, g);
      W(e, "customMetaData", l.join("&"));
      W(e, "ispushdown", !(!d.g || !d.g.o));
      W(e, "expEnv", ("gdn" == Cm() ? "adsense" : "basic").toString());
      W(e, "experiments", c.g.P);
      var r;
      if (window.google_rum_config) {
        n = new Nm();
        m = Lc(Fd, zc(window.google_rum_config));
        if (m != null) {
          if (!(m instanceof Fd))
            throw Error(
              "Expected instanceof " +
                rc(Fd) +
                " but got " +
                (m && rc(m.constructor))
            );
        } else m = void 0;
        Gc(n, 1, m);
        m &&
          !ic(m) &&
          ((m = n.aa),
          r === void 0 && (r = m[G] | 0),
          r & 32 && !(r & 4096) && fc(m, r | 4096));
        r = Hc(
          n,
          2,
          tc("https://securepubads.g.doubleclick.net/pagead/js/rum.js"),
          ""
        );
        n = !!window.google_measure_js_timing;
        if (n != null && typeof n !== "boolean")
          throw Error("Expected boolean but got " + Aa(n) + ": " + n);
        r = Hc(r, 3, n, !1);
        r = yc(r);
      } else r = null;
      r != null && W(e, "rum_config", r);
      Fk(c.g) &&
        ((r = c.g.g.CREATIVE_PARAMETER_NEWTON_OT2_TOKEN),
        r != null && W(e, "newton_ot2_token", r));
      Gk(c.g) &&
        ((r = c.g.g.CREATIVE_PARAMETER_TURTLEX_AD_SIGNALS),
        r != null && W(e, "turtlex_ad_signals", r));
      zk(d, 117) &&
        Dk(c.g, "simplify_query_string") &&
        (W(e, "e", je),
        window.layoutsPreview &&
          (W(e, "layoutsRuntime", window.layoutsPreview.layoutsRuntime),
          W(e, "fillerContext", window.layoutsPreview.fillerContext)),
        d.g &&
          ((d = d.g),
          W(e, "leftOffset", d.g.left),
          W(e, "topOffset", d.g.top)));
      bn(c, e, Ek(c.g));
      return dn(a, e);
    },
    dn = function (a, b) {
      var c = {};
      md(
        b,
        function (d, e) {
          e = an(e);
          d = an(d.toString());
          c[e] = d;
        },
        a
      );
      return c;
    };
  var fn = function (a, b) {
    cn.call(this, a, b);
  };
  q(fn, cn);
  fn.prototype.g = function (a) {
    a = en(this, a);
    var b = gn(this);
    a.exitEvents = b;
    b = Array.from(Ne.values());
    a.features = b;
    return Sh(a);
  };
  var gn = function (a) {
    var b = {};
    md(
      a.j.W,
      function (c, d) {
        var e = {};
        e.name = c.name;
        e.url = c.url;
        e.target = c.j ? "popup" : c.o;
        e.reportingId = c.reportingId ? c.reportingId : "";
        e.eTldPlusOne = c.eTldPlusOne ? c.eTldPlusOne : "";
        b[d] = e;
      },
      a
    );
    return b;
  };
  var hn = function (a, b) {
    cn.call(this, a, b);
  };
  q(hn, cn);
  hn.prototype.g = function (a) {
    a = en(this, a);
    return wi(a);
  };
  var jn = function (a, b) {
      this.g = a;
      this.v = b ? b : null;
      this.j = {};
      this.o = [];
    },
    ln = function (a, b) {
      Na(Ai, b) >= 0 && a.v
        ? a.v.Na(
            "HIFI",
            function (c) {
              kn(a, c);
            },
            !0
          )
        : O(window, b, a.B, !1, a);
    },
    mn = function (a) {
      return new Q(function (b, c) {
        this.o.push(function (d) {
          if (d.type != "adLocation") return !1;
          b(d);
          return !0;
        });
        ln(this, "adLocation");
        window.setTimeout(function () {
          c({});
        }, 1e4);
      }, a);
    },
    kn = function (a, b) {
      if (typeof b !== "string") {
        var c = b.type;
        if (c) {
          switch (c) {
            case "hostpageScroll":
            case "enterViewport":
            case "exitViewport":
            case "adLocation":
              a.g(b);
          }
          var d = [];
          a.o.forEach(function (e) {
            e(b) || d.push(e);
          });
          a.o = d;
        }
      }
    };
  jn.prototype.B = function (a) {
    (this.j[a.type] && A() - this.j[a.type] < 50) ||
      ((this.j[a.type] = A()),
      (a = z(this.A, this, a)),
      (a = Lf(a)),
      Of || (Of = Pf()),
      Of(a));
  };
  jn.prototype.A = function (a) {
    a = a.ra;
    switch (a.type) {
      case "devicemotion":
        this.g({
          type: a.type,
          acceleration: a.acceleration,
          accelerationIncludingGravity: a.accelerationIncludingGravity,
          rotationRate: a.rotationRate,
          interval: a.interval,
        });
        break;
      case "deviceorientation":
        this.g({
          type: a.type,
          absolute: a.absolute,
          alpha: a.alpha,
          beta: a.beta,
          gamma: a.gamma,
        });
    }
  };
  var nn = function () {
    S.apply(this, arguments);
  };
  q(nn, S);
  var on = function () {
    nn.call(this);
    this.o = this.g = null;
  };
  q(on, nn);
  k = on.prototype;
  k.Lc = function () {
    this.o = this.g.responseText;
    this.j("success");
    pn(this);
  };
  k.Mc = function () {
    this.j("timeout");
  };
  k.Kc = function () {
    this.j("error");
  };
  k.Ab = function (a, b) {
    u.XDomainRequest &&
      tb &&
      !Jb(10) &&
      ((this.g = new u.XDomainRequest()),
      (this.g.onerror = z(this.Kc, this)),
      (this.g.ontimeout = z(this.Mc, this)),
      (this.g.onload = z(this.Lc, this)),
      (this.g.timeout = 6e4));
    this.g && (this.g.open(b, a.toString()), this.g.send());
  };
  k.Nb = function () {
    return this.o;
  };
  var pn = function (a) {
    a.g &&
      ((a.g.onerror = null),
      (a.g.ontimeout = null),
      (a.g.onload = null),
      (a.g = null));
  };
  on.prototype.H = function () {
    pn(this);
    nn.prototype.H.call(this);
  };
  var qn = function () {
    nn.call(this);
    this.v = this.g = null;
    this.o = -1;
  };
  q(qn, nn);
  qn.prototype.B = function () {
    if ((this.g ? this.g.readyState : 0) == 4) {
      try {
        var a = (this.g ? this.g.readyState : 0) > 2 ? this.g.status : -1;
      } catch (c) {
        a = -1;
      }
      a: switch (a) {
        case 200:
        case 201:
        case 202:
        case 204:
        case 206:
        case 304:
        case 1223:
          var b = !0;
          break a;
        default:
          b = !1;
      }
      b || a === 0
        ? ((this.v = this.g.responseText), this.j("success"), rn(this))
        : this.j("error");
    }
  };
  qn.prototype.A = function () {
    rn(this);
    this.j("timeout");
  };
  qn.prototype.Ab = function (a, b) {
    (this.g = new XMLHttpRequest()),
      (this.g.onreadystatechange = z(this.B, this)),
      (this.o = xh(this.A, 6e4, this));
    this.g && (this.g.open(b, String(a), !0), this.g.send(null));
  };
  qn.prototype.Nb = function () {
    return this.v;
  };
  var rn = function (a) {
    a.o && (u.clearTimeout(a.o), (a.o = -1));
    a.g && ((a.g.g = null), (a.g = null));
  };
  qn.prototype.H = function () {
    rn(this);
    nn.prototype.H.call(this);
  };
  var sn = function (a) {
      this.g = [];
      this.j = a;
    },
    un = function (a, b, c) {
      b = a.j.Ob(b);
      for (var d = 0; d < b.length; d++) {
        var e = b[d],
          f = e.element,
          g = e.La;
        e = e.attributes;
        c && tn(a, f, g, e);
        if (g) {
          var h = void 0;
          for (h in g) f.style[h] = g[h];
        }
        if (e) for (g in ((g = void 0), e)) f.setAttribute(g, e[g]);
      }
      return a;
    },
    tn = function (a, b, c, d) {
      var e = {};
      e.element = b;
      c &&
        (e.La = nd(c, function (f, g) {
          return b.style[g];
        }));
      d &&
        (e.attributes = nd(d, function (f, g) {
          return b.getAttribute(g);
        }));
      a.g.push(e);
    },
    vn = function (a) {
      for (var b; (b = a.g.pop()); ) {
        var c = b.element;
        if (b.La) for (var d in b.La) c.style[d] = b.La[d];
        if (b.attributes)
          for (var e in b.attributes) c.setAttribute(e, b.attributes[e]);
      }
    };
  var yn = function (a, b, c) {
    S.call(this);
    this.F = null;
    this.B = !1;
    this.G = new sn(a);
    this.S = !!c;
    this.o = new Gf(this);
    this.K = b;
    this.C = this.v = null;
    this.I = !1;
    this.g = this.A = null;
    this.J = wn();
    xn(this) && P(this.o, xn(this), "h", z(this.j, this));
  };
  q(yn, S);
  var An = function (a) {
      return new Q(function (b) {
        var c = xn(this);
        c && !c.B()
          ? b(!1)
          : ((c = og(
              zn(this).then(function (d) {
                return (d.width > 0 && d.height > 0) || Pd(d, xm);
              }),
              function () {
                return !1;
              }
            )),
            b(c));
      }, a);
    },
    zn = function (a) {
      return new Q(function (b, c) {
        var d = xn(this);
        d
          ? b(d.g())
          : this.S || window == window.top
          ? b(wn())
          : c("Could not get available dimensions (in sandboxed iframe)");
      }, a);
    };
  yn.prototype.R = function (a) {
    var b;
    if ((b = a.ia)) {
      b = a.ia;
      var c = a.Aa;
      b = !(b.width <= c.width && b.height <= c.height);
    }
    if (b)
      throw Error(
        "Cannot establish expanded rectangle (requested size too large)"
      );
    b = a.ia ? a.ia : a.Aa;
    c = new Od(
      Math.max(0, (a.Aa.width - b.width) / 2),
      Math.max(0, (a.Aa.height - b.height) / 2)
    );
    if (xn(this)) {
      var d = xn(this).o(a.collapsed, a.Aa);
      d =
        d == ym || (d && ym && d.x == ym.x && d.y == ym.y)
          ? ym
          : new Od(d.x - c.x, d.y - c.y);
    } else
      (d = this.K),
        d.nodeType == 1
          ? ((d = Zj(d)), (d = new Od(d.left, d.top)))
          : ((d = d.changedTouches ? d.changedTouches[0] : d),
            (d = new Od(d.clientX, d.clientY))),
        (d = new Od(d.x - c.x, d.y - c.y));
    b = new Gj(xn(this) ? 0 : c.x, xn(this) ? 0 : c.y, b.width, b.height);
    return { Aa: a.Aa, ia: a.ia, fixed: !!a.ia, jc: d, Pa: b };
  };
  var Bn = function (a, b, c) {
    return a.B
      ? fg()
      : zn(a)
          .then(function (d) {
            return { Aa: d, ia: c, collapsed: b };
          })
          .then(a.R, void 0, a)
          .then(
            function (d) {
              return xn(this)
                ? xn(this)
                    .A(d.Pa)
                    .then(function (e) {
                      d.Pa = e;
                      return d;
                    })
                : d;
            },
            void 0,
            a
          );
  };
  yn.prototype.M = function (a) {
    Pd(Hj(a.Pa), xm) || un(this.G, a.Pa, !0);
    this.A = a;
    Cn(this);
    this.v = z(this.U, this);
    Pb || Ob
      ? ((this.g = new T(50)),
        P(this.o, this.g, "tick", this.D),
        this.g.start())
      : P(this.o, window, ["resize", "orientationchange"], this.v);
    this.B = !0;
    return a;
  };
  var Cn = function (a) {
    a.v &&
      (Jf(a.o, window, ["resize", "orientationchange"], a.v), (a.v = null));
    a.g && (Jf(a.o, a.g, "tick", a.D), wh(a.g));
  };
  yn.prototype.D = function () {
    var a = new I(window.innerWidth, window.innerHeight);
    Pd(this.J, a) || this.v();
    this.J = a;
  };
  yn.prototype.U = function () {
    this.C = zn(this).then(
      function (a) {
        a = this.A.fixed
          ? new Gj(
              Math.max(0, (a.width - this.A.ia.width) / 2),
              Math.max(0, (a.height - this.A.ia.height) / 2),
              this.A.ia.width,
              this.A.ia.height
            )
          : new Gj(0, 0, a.width, a.height);
        Pd(Hj(a), xm) || un(this.G, a, !1);
      },
      void 0,
      this
    );
  };
  var xn = function (a) {
    a.F == null && (a.F = null);
    return a.F;
  };
  yn.prototype.H = function () {
    L(this.o);
    this.g && (Cf(this.g, "tick", this.D, !1, this), L(this.g));
    S.prototype.H.call(this);
  };
  var wn =
    Pb || Ob
      ? function () {
          return new I(window.innerWidth, window.innerHeight);
        }
      : Xd;
  var En = function (a, b, c, d) {
    M.call(this);
    this.j = a;
    this.o = {};
    this.A = [];
    a = dk(this.j);
    this.v = c || new Gj(0, 0, a.width, a.height);
    this.B = null;
    this.g = b;
    this.C = !1;
    this.D = !!d;
    (this.g & 2) == 2 && (Dn(this, !0, !0), (this.A = []));
  };
  q(En, M);
  var Gn = function (a) {
      a.B || Fn(a);
      return a.B;
    },
    Fn = function (a) {
      var b = ek(a.j);
      a.j.offsetLeft >= 0 && (b.left += a.v.left);
      a.j.offsetTop >= 0 && (b.top += a.v.top);
      b.width = Math.max(b.width, a.v.width);
      b.height = Math.max(b.height, a.v.height);
      a.B = b;
    },
    In = function (a, b) {
      (a.C && b) ||
        (b && a.D && Fn(a),
        (a.g & 1) == 1 && (Hn(a, "OBJECT", b), Hn(a, "embed", b)),
        ((a.g & 32) != 32 &&
          (a.g & 16) != 16 &&
          (a.g & 4) != 4 &&
          (a.g & 8) != 8) ||
          Dn(a, b),
        (a.C = b));
    },
    Dn = function (a, b, c) {
      if (b) {
        b = Sd(a.j);
        for (
          var d = a.j.parentElement || null;
          d && d != b;
          d = d.parentElement || null
        ) {
          var e = {};
          if (c) Jn(a, d, e);
          else {
            if ((a.g & 4) == 4) {
              var f = a,
                g = Wj(d, "zIndex");
              isNaN(parseInt(g, 10)) || (e.zIndex = f.j.style.zIndex);
            }
            (a.g & 8) == 8 && Jn(a, d, e);
            (a.g & 16) == 16 &&
              ((f = Kn(d, "backface-visibility")),
              f.value == "hidden" && (e[kd(f.xb)] = "visible"));
            (a.g & 32) == 32 &&
              ((f = Kn(d, "transform")),
              E(H(f.value)) || f.value == "none" || (e[kd(f.xb)] = "none"));
          }
          qd(e) ||
            a.A.push(un(new sn(new Ln([{ element: d, La: e }])), null, !0));
        }
      } else for (; a.A.length > 0; ) vn(a.A.pop());
    },
    Jn = function (a, b, c) {
      (Wj(b, "overflowX") != "hidden" && Wj(b, "overflowY") != "hidden") ||
        ek(b).contains(Gn(a)) ||
        ((c.overflowX = "visible"),
        (c.overflowY = "visible"),
        (c.overflow = "visible"));
    },
    Kn = function (a, b) {
      var c = Rj() + "-" + b,
        d = Vj(a, c);
      return d !== null ? { xb: c, value: d } : { xb: b, value: Vj(a, b) };
    },
    Hn = function (a, b, c) {
      if (c) {
        a.o[b] = a.o[b] || [];
        c = (c = b && b != "*" ? String(b).toUpperCase() : "")
          ? document.querySelectorAll(c + "")
          : document.getElementsByTagName("*");
        for (var d = 0; d < c.length; d++) {
          var e = c[d],
            f = Gn(a),
            g = ek(e);
          f.left <= g.left + g.width &&
            g.left <= f.left + f.width &&
            f.top <= g.top + g.height &&
            g.top <= f.top + f.height &&
            e != a.j &&
            !be(a.j, e) &&
            (a.o[b].push({ visibility: e.style.visibility, element: e }),
            (e.style.visibility = "hidden"));
        }
      } else
        for (; a.o[b] && a.o[b].length > 0; )
          (c = a.o[b].pop()), (c.element.style.visibility = c.visibility);
    };
  En.prototype.H = function () {
    In(this, !1);
    Dn(this, !1);
    M.prototype.H.call(this);
  };
  var Ln = function (a) {
    this.g = a;
  };
  Ln.prototype.Ob = function () {
    return this.g;
  };
  var Nn = function (a) {
    S.call(this);
    this.g = this.A = null;
    this.o = new Gf(this);
    this.C = !1;
    Mn ||
      ((this.g = new T(100)),
      P(this.o, this.g, "tick", this.v),
      this.g.start(),
      P(this.o, document, "DOMContentLoaded", this.v),
      P(this.o, document, "readystatechange", this.v),
      P(this.o, window, "load", this.B),
      this.v(),
      a != null && typeof a === "number" && xh(this.B, a, this));
  };
  q(Nn, S);
  Nn.prototype.v = function () {
    var a;
    if ((a = tb)) {
      a = !1;
      try {
        a = window.frameElement == null;
      } catch (c) {}
    }
    if (a && document.documentElement.doScroll)
      if (document.documentElement.doScroll)
        try {
          document.documentElement.doScroll("left");
          var b = !0;
        } catch (c) {
          b = !1;
        }
      else b = !1;
    else
      document.readyState === "undefined"
        ? document.getElementsByTagName
          ? ((b = document.getElementsByTagName("*")),
            (b = b.length > 0 ? b[b.length - 1] : null),
            this.A && b && this.A == b ? (b = !0) : ((this.A = b), (b = !1)))
          : (b = !1)
        : (b = document.readyState === "complete");
    b && this.B();
  };
  Nn.prototype.H = function () {
    On(this);
    S.prototype.H.call(this);
  };
  var On = function (a) {
    a.o.dispose();
    a.g && (a.g.dispose(), (a.g = null));
  };
  Nn.prototype.B = function () {
    this.C || ((Mn = this.C = !0), On(this), this.j(new N("ready")));
  };
  var Mn = !1;
  function Pn(a) {
    var b;
    a.visibilityState
      ? (b = "visibilitychange")
      : a.mozVisibilityState
      ? (b = "mozvisibilitychange")
      : a.webkitVisibilityState && (b = "webkitvisibilitychange");
    return b;
  }
  function Qn(a, b) {
    if (b.prerendering) b = 3;
    else {
      var c;
      b =
        (c = {
          visible: 1,
          hidden: 2,
          prerender: 3,
          preview: 4,
          unloaded: 5,
          "": 0,
        }[
          b.visibilityState ||
            b.webkitVisibilityState ||
            b.mozVisibilityState ||
            ""
        ]) != null
          ? c
          : 0;
    }
    if (b === 3) return !1;
    a();
    return !0;
  }
  function Rn(a) {
    function b() {
      !f && Qn(a, c) && ((f = !0), gk(c, g, b));
    }
    var c = document;
    var d = d === void 0 ? !1 : d;
    if (!Qn(a, c))
      if (d) {
        var e = function () {
          gk(c, "prerenderingchange", e);
          a();
        };
        fk(c, "prerenderingchange", e);
      } else {
        var f = !1,
          g = Pn(c);
        g && fk(c, g, b);
      }
  }
  var Sn = function () {};
  Sn.Ga = void 0;
  Sn.Mb = function () {
    return Sn.Ga ? Sn.Ga : (Sn.Ga = new Sn());
  };
  Sn.prototype.g = 0;
  var Tn = function (a) {
    S.call(this);
    this.Y = a || Td();
    this.S = null;
    this.Fa = !1;
    this.C = null;
    this.F = void 0;
    this.ma = this.fa = null;
  };
  B(Tn, S);
  Tn.prototype.sc = Sn.Mb();
  Tn.prototype.V = function () {
    return this.S || (this.S = ":" + (this.sc.g++).toString(36));
  };
  Tn.prototype.T = function () {
    return this.C;
  };
  var X = function (a) {
    a.F || (a.F = new Gf(a));
    return a.F;
  };
  Tn.prototype.U = function () {
    this.C = ce(this.Y, "DIV");
  };
  Tn.prototype.Ra = function (a) {
    Un(this, a);
  };
  Tn.prototype.Ea = function (a) {
    Un(this, a.parentNode, a);
  };
  var Un = function (a, b, c) {
    if (a.Fa) throw Error("Component already rendered");
    a.C || a.U();
    b ? b.insertBefore(a.C, c || null) : a.Y.g.body.appendChild(a.C);
    (a.fa && !a.fa.Fa) || a.Oa();
  };
  Tn.prototype.Ua = function (a) {
    this.C = a;
  };
  Tn.prototype.Oa = function () {
    this.Fa = !0;
    Vn(this, function (a) {
      !a.Fa && a.T() && a.Oa();
    });
  };
  Tn.prototype.ib = function () {
    Vn(this, function (a) {
      a.Fa && a.ib();
    });
    this.F && Kf(this.F);
    this.Fa = !1;
  };
  Tn.prototype.H = function () {
    this.Fa && this.ib();
    this.F && (this.F.dispose(), delete this.F);
    Vn(this, function (a) {
      a.dispose();
    });
    this.C && ae(this.C);
    this.fa = this.C = this.ma = null;
    Tn.X.H.call(this);
  };
  var Vn = function (a, b) {
    a.ma && a.ma.forEach(b, void 0);
  };
  function Wn(a, b) {
    Tn.call(this, b);
    this.kc = a;
    this.Ja = null;
  }
  B(Wn, Tn);
  Wn.prototype.Ra = function (a) {
    this.kc && Xn(this);
    Wn.X.Ra.call(this, a);
  };
  Wn.prototype.Ea = function (a) {
    this.kc && Xn(this);
    Wn.X.Ea.call(this, a);
  };
  var Xn = function (a) {
    a.T() || a.U();
    Vn(a, function (b) {
      b.Ra(a.T());
    });
  };
  Wn.prototype.V = function () {
    return (
      this.S ||
      (this.S = (Qm || (Qm = "200_287_" + Om)) + "_" + (Pm++).toString(36))
    );
  };
  Wn.prototype.toString = function () {
    return this.V();
  };
  var Yn = function (a) {
      Vn(a, function (b) {
        Yn(b);
      });
    },
    Zn = function (a) {
      Vn(a, function (b) {
        Zn(b);
      });
    },
    $n = function (a) {
      Vn(a, function (b) {
        $n(b);
      });
    };
  Wn.prototype.hb = function () {
    Vn(this, function (a) {
      a.hb();
    });
  };
  Wn.prototype.Sa = function (a, b) {
    bk(this.T(), a, b);
    Vn(this, function (c) {
      c.Sa("100%", "100%");
    });
  };
  function ao(a, b, c) {
    if (b instanceof I) (c = b.height), (b = b.width);
    else if (c == void 0) throw Error("missing height argument");
    b = parseInt(b, 10) > 0 ? b : "100%";
    c = parseInt(c, 10) > 0 ? c : "100%";
    bk(a, b, c);
  }
  function bo(a, b, c) {
    Wn.call(this, !1, c);
    this.g = a;
    this.Va = b;
    this.Ha = (a.g && a.g.g && Hj(a.g.g)) || new I(a.width, a.height);
    this.xa = !1;
    this.Da = [];
    this.Vb = null;
  }
  B(bo, Wn);
  k = bo.prototype;
  k.tb = function () {
    for (; this.Da.length > 0; ) {
      var a = this.Da.shift();
      co(this, "setParameter", [a.name, a.value]);
    }
  };
  k.Md = function () {
    this.xa = !0;
    this.tb();
  };
  k.Yd = function () {
    this.xa = !1;
  };
  k.Ua = function (a) {
    bo.X.Ua.call(this, a);
    a.style.position = "relative";
    ao(a, this.Ha);
    "boxSizing" in a.style && (a.style.boxSizing = "content-box");
    var b = this.Va.F;
    (null == b ? 0 : (b.g || b.o) && this.Va.o.length == 1)
      ? dj(b, a)
      : b != null && (b.g || b.o) && !b.v && fj(b);
  };
  k.Oa = function () {
    var a = X(this);
    P(a, this, "conduitInitialized", this.Md);
    P(a, this, "RESET", this.Yd);
    bo.X.Oa.call(this);
    var b = X(this);
    this.Vb = new Nn(5e3);
    Mn ? this.Pb() : P(b, this.Vb, "ready", this.Pb);
    if ((b = this.T()))
      P(a, b, "mouseover", this.Cd), P(a, b, "mouseout", this.Rb);
    P(a, this, "logEvent", this.Qb);
    P(a, this, "logExitFlushEventsOpenPopup", this.Qb);
  };
  k.Cd = function () {
    eo(this, "1");
  };
  k.Rb = function () {
    eo(this, "0");
  };
  k.Qb = function (a) {
    Fi(a.j) == "Exit" && this.Rb();
  };
  var eo = function (a, b) {
    a.xa
      ? co(a, "setParameter", ["isMouseOver", b])
      : a.Da.push({ name: "isMouseOver", value: b });
  };
  bo.prototype.oa = function (a, b) {
    (a = rj(a, b)) && this.j(a);
    return null;
  };
  var Y = function (a) {
    N.call(this, a);
  };
  q(Y, N);
  Y.prototype.Ta = function (a, b) {
    this[a] = b;
    return this;
  };
  v("studio.events.StudioEvent", Y);
  Y.prototype.addProperty = Y.prototype.Ta;
  Y.INIT = "init";
  Y.VISIBLE = "visible";
  Y.HIDDEN = "hidden";
  Y.VISIBILITY_CHANGE = "visibilityChange";
  Y.VISIBILITY_CHANGE_WITH_INFO = "visibilityChangeWithInfo";
  Y.EXIT = "exit";
  Y.INTERACTION = "interaction";
  Y.PAGE_LOADED = "pageLoaded";
  Y.ORIENTATION = "orientation";
  Y.ABOUT_TO_EXPAND = "aboutToExpand";
  Y.EXPAND_START = "expandStart";
  Y.EXPAND_FAILED = "expandFailed";
  Y.EXPAND_FINISH = "expandFinish";
  Y.COLLAPSE_START = "collapseStart";
  Y.COLLAPSE_FINISH = "collapseFinish";
  Y.COLLAPSE = "collapse";
  Y.FULLSCREEN_SUPPORT = "fullscreenSupport";
  Y.HOSTPAGE_FEATURES_LOADED = "hostpageFeaturesLoaded";
  Y.FULLSCREEN_DIMENSIONS = "fullscreenDimensions";
  Y.FULLSCREEN_EXPAND_START = "fullscreenExpandStart";
  Y.FULLSCREEN_EXPAND_FINISH = "fullscreenExpandFinish";
  Y.FULLSCREEN_COLLAPSE_START = "fullscreenCollapseStart";
  Y.FULLSCREEN_COLLAPSE_FINISH = "fullscreenCollapseFinish";
  Y.HOSTPAGE_SCROLL = "hostpageScroll";
  Y.OPTIONAL_HOSTPAGE_SCROLL = "optHostpageScroll";
  Y.SCROLL_INTERACTION = "scrollInteraction";
  Y.ENTER_VIEWPORT = "enterViewport";
  Y.OPTIONAL_ENTER_VIEWPORT = "optEnterViewport";
  Y.EXIT_VIEWPORT = "exitViewport";
  Y.OPTIONAL_EXIT_VIEWPORT = "optExitViewport";
  Y.VIDEO_START = "videoStart";
  var fo = ua(["about:blank"]),
    go = ua(["javascript:undefined"]),
    ho = Cd(fo);
  cd(ho);
  var io = Cd(go);
  cd(io);
  var jo = function (a) {
    M.call(this);
    this.j = a;
    this.g = {};
    this.j.ub(z(this.o, this));
  };
  B(jo, M);
  var lo = function (a, b) {
    if (b.indexOf(":") != -1)
      throw Error('Virtual channel name "' + b + '" should not contain colons');
    if (b in a.g)
      throw Error(
        'Virtual channel "' + b + '" was already created for this multichannel.'
      );
    var c = new ko(a, b);
    return (a.g[b] = c);
  };
  jo.prototype.o = function (a, b) {
    if ((a = a.match(/^([^:]*):(.*)/))) {
      var c = a[1];
      a = a[2];
      c in this.g && (c = this.g[c]) && c.o && c.o(a, b);
    }
  };
  jo.prototype.H = function () {
    md(this.g, function (a) {
      L(a);
    });
    L(this.j);
    delete this.g;
    delete this.j;
  };
  var ko = function (a, b) {
    M.call(this);
    this.g = a;
    this.j = b;
  };
  B(ko, M);
  k = ko.prototype;
  k.connect = function (a) {
    a && a();
  };
  k.isConnected = function () {
    return !0;
  };
  k.Na = function (a, b, c) {
    this.g.j.Na(this.j + ":" + a, z(this.Ib, this, b), c);
  };
  k.ub = function (a) {
    this.o = z(this.Ib, this, a);
  };
  k.ua = function (a, b) {
    if (this.L()) throw Error("#send called for disposed VirtualChannel.");
    this.g.j.ua(this.j + ":" + a, b);
  };
  k.Ib = function (a, b) {
    this.L() || a.apply({}, Array.prototype.slice.call(arguments, 1));
  };
  k.H = function () {
    this.g = this.g.g[this.j] = null;
  };
  function mo(a) {
    M.call(this);
    this.g = new jo(a);
    this.o = {};
    this.j = lo(this.g, "private");
    this.v = lo(this.g, "public");
    this.j.Na("mics", z(this.B, this), !0);
  }
  B(mo, M);
  mo.prototype.C = 0;
  mo.prototype.H = function () {
    L(this.g);
    delete this.g;
    delete this.v;
    delete this.j;
  };
  var no = function (a, b, c) {
    var d = a.C++;
    a.o[d] = c;
    c = { signature: d };
    c.data = b;
    a.v.ua("general", c);
  };
  mo.prototype.B = function (a) {
    var b = a.signature;
    a = a.data;
    b in this.o && ((0, this.o[b])(a), delete this.o[b]);
  };
  mo.prototype.A = function (a, b) {
    a = a(b.data);
    var c = b.signature;
    eg(a).then(
      z(function (d) {
        var e = {};
        e.data = d;
        e.signature = c;
        this.j && this.j.ua("mics", e);
      }, this)
    );
  };
  var Z = function (a, b, c, d, e) {
    bo.call(this, a, b, d);
    this.K = c;
    this.Xa = null;
    c && (this.Xa = new Em(c));
    this.Wb = this.V() + ".if";
    this.o = null;
    this.Yb = new hn(b, a);
    this.Ca = [];
    this.ka = null;
    this.ga = 0;
    this.la = th();
    this.v = this.M = this.ya = this.G = this.D = null;
    this.Ya = "";
    this.A = b;
    this.Z = null;
    this.da = Cm() == "safe" && !zk(this.g, 78);
    this.Ia = Cm() == "safe" && zk(this.g, 78) && !0;
    this.J = null;
    this.Ia &&
      ((this.J =
        document.getElementById("goog-messaging-iframe") ||
        document.createElement("iframe")),
      this.J.parentNode == null &&
        ((this.J.id = "goog-messaging-iframe"),
        (this.J.name = "goog-messaging-iframe"),
        (this.J.style.display = "none"),
        document.body.appendChild(this.J)));
    this.hc = this.na = !1;
    this.B = null;
    Re([3]);
    this.R = e ? e : null;
    this.Wa = new jn(z(this.I, this), this.R);
    this.dc = [];
  };
  q(Z, bo);
  k = Z.prototype;
  k.tb = function () {
    for (; this.Ca.length; ) {
      var a = this.Ca.shift();
      co(this, a.methodName, a.args);
    }
    bo.prototype.tb.call(this);
  };
  k.Pb = function () {
    this.I(new Y("pageLoaded"));
  };
  k.Oa = function () {
    bo.prototype.Oa.call(this);
    this.da || this.Hb();
    P(X(this), this, "conduitInitialized", this.xd);
    P(X(this), this, "recordTimings", this.Nd);
    P(X(this), window, ["resize", "orientationchange"], this.yb);
    var a = this.T();
    a &&
      (P(X(this), this, "isFullscreenSupported", this.Bd),
      P(X(this), this, "queryFullscreenDimensions", this.pb),
      P(X(this), this, "fullscreenExpandRequested", this.Sb),
      P(X(this), this, "fullscreenExpandFinished", this.zd),
      P(X(this), this, "fullscreenCollapseRequested", this.Gd),
      P(X(this), this, "fullscreenCollapseFinished", this.yd),
      P(X(this), this, "setResponsiveBehavior", this.Hd),
      P(X(this), this, "responsiveResize", this.Id),
      P(X(this), this, "getHostpageFeatures", this.Ad),
      (this.v = new yn(this, a, this.A.j)),
      (this.Z = new En(a, 56)),
      P(
        X(this),
        this.v,
        "h",
        z(this.j, this, new gj("fullscreenCollapseRequested"))
      ),
      P(X(this), this, "registerEventTypeListenerForType", z(this.Ed, this)));
    if (u.IN_ADSENSE_IFRAME && u.CreativeToolset) {
      this.ya = new Gm(window);
      a = this.ya;
      var b = z(this.Dd, this);
      a.g.g != null &&
        ($k(a.g)
          ? (a.B = O(a.g, "viewable_change", z(a.F, a, b)))
          : ((a.A = O(a.g, "show", z(a.C, a, b))),
            (a.v = O(a.g, "hide", z(a.C, a, b)))));
    }
    this.A.Ba ? oo(this, !1) : oo(this, !0);
  };
  k.Ob = function (a) {
    var b = [
      {
        element: this.T(),
        La: {
          clip: "auto",
          position: "fixed",
          left: a.left + "px",
          top: a.top + "px",
          overflow: "visible",
          width: a.width + "px",
          height: a.height + "px",
        },
      },
    ];
    b.push({
      element: this.o,
      La: {
        position: "fixed",
        left: a.left + "px",
        top: a.top + "px",
        width: a.width + "px",
        height: a.height + "px",
      },
      attributes: { width: a.width, height: a.height },
    });
    return b;
  };
  k.dd = function () {
    po(this, "n");
  };
  k.Hb = function () {
    this.G && this.G.dispose();
    this.D && this.D.dispose();
    var a = {};
    this.da ? ((a.tp = 2), (a.directSyncMode = !0)) : (a.tp = 1);
    a.ifrid = this.Wb;
    a.cn = this.la;
    a.role = 0;
    a.nativeProtocolVersion = 2;
    if (this.Ia) {
      var b = this.J;
      b = Td(b.contentDocument || b.contentWindow.document);
    } else b = Td();
    this.D = new ri(a, b);
    ef(this, this.D);
    if ((a = this.o.contentWindow)) this.D.ba = a;
    this.G = new mo(this.D);
    ef(this, this.G);
    a = this.G;
    b = z(this.de, this);
    a.v.Na("general", z(a.A, a, b), !0);
    this.D.connect(z(this.dd, this));
  };
  k.ib = function () {
    bo.prototype.ib.call(this);
    oo(this, !1);
  };
  var po = function (a, b) {
    a.K && Fm(a.K, b, A());
  };
  Z.prototype.U = function () {
    bo.prototype.U.call(this);
    this.Ua(this.T());
  };
  Z.prototype.Ua = function (a) {
    bo.prototype.Ua.call(this, a);
    this.da
      ? ((this.M = new (u.XDomainRequest && tb && !Jb(10) ? on : qn)()),
        qo(this),
        (a = X(this)),
        If(a, this.M, "success", this.fe, !1, this),
        (a = X(this)),
        If(a, this.M, "error", this.ee, !1, this),
        this.M.Ab(this.g.B, "get"))
      : ro(this);
  };
  var qo = function (a) {
      var b = a.T(),
        c = a.Y,
        d = c.j("IFRAME", {
          frameborder: 0,
          style: "border:0;vertical-align:bottom;",
        });
      d.src = cd(ho).toString();
      c.appendChild(b, d);
      a.o = d;
      so(a);
      b = a.T();
      b.style.position = "relative";
      b.style.margin = "0px";
      b.style.padding = "0px";
      b = a.o;
      b != null &&
        (ao(b, a.g.width, a.g.height),
        (c = { id: a.Wb, frameborder: "0", scrolling: "no" }),
        a.g.o && a.g.o.j && (c.allowtransparency = "true"),
        Wd(b, c),
        b.setAttribute("allowfullscreen", "true"),
        Yj(b, "0px", "0px"),
        (b.style.border = "0px"),
        (b.style.verticalAlign = "bottom"));
    },
    so = function (a) {
      var b = a.T();
      if (b != null) {
        var c;
        if ((c = a.g.g))
          (c = a.g.g.g),
            (c = new Bi(c.top, c.left + c.width, c.top + c.height, c.left));
        ao(
          b,
          c ? c.right - c.left : a.g.width,
          c ? c.bottom - c.top : a.g.height
        );
        Yj(b, 0, 0);
        b.style.top = "";
        b.style.bottom = "";
        b.style.left = "";
        b.style.right = "";
      }
    },
    ro = function (a) {
      qo(a);
      po(a, "i");
      a.A.xa &&
        !a.A.j &&
        typeof window.stcc === "function" &&
        a.o &&
        window.stcc(a.o);
      var b = a.o;
      a = a.g.B + to(a) + uo(a);
      b.src = a;
    };
  Z.prototype.ee = function () {
    ro(this);
  };
  Z.prototype.fe = function () {
    var a = this.M.Nb().toString();
    if (this.g.B) {
      var b = this.g.B;
      b = b.slice(0, b.lastIndexOf("/") + 1);
      /^\/+$/.test(b) || (b = b.replace(/\/+$/, ""));
    } else b = "";
    b = '<base href="' + b + '/">';
    var c =
      '<script>var STUDIO_ORIGINAL_ASSET_URL = "' +
      (this.g.B + to(this) + uo(this)) +
      '";\x3c/script>';
    a: {
      b += c;
      c = ["head", "body", "html"];
      for (var d = 0; d < c.length; d++) {
        var e = a.indexOf("<" + c[d]);
        if (e > -1 && ((e = a.indexOf(">", e)), e > -1)) {
          c = e + 1;
          a = a.substring(0, c) + b + a.substring(c);
          break a;
        }
      }
      a = b + a;
    }
    this.Ya = a;
    this.o &&
      (this.o.contentWindow || this.o.contentDocument) &&
      ((a = X(this)),
      If(a, this.o, "load", this.Hb, !1, this),
      (b = this.o),
      (a = $i(this.Ya)),
      (b = b.contentDocument || b.contentWindow.document),
      b.open(),
      b.write(gd(a)),
      b.close(),
      this.M.dispose());
  };
  Z.prototype.H = function () {
    L(this.Z);
    L(this.v);
    L(this.ya);
    L(this.Xa);
    L(this.K);
    bo.prototype.H.call(this);
  };
  var to = function (a) {
      var b = [];
      zk(a.g, 49) ||
        (b.push(["liveEnvironment", "true"]),
        window.layoutsPreview && b.push(["layoutsPreview", "true"]));
      b.push(["e", je]);
      a.g.I && b.push(["ssr", "true"]);
      var c = a.g.g,
        d = c ? c.g.top : 0;
      b.push(["leftOffset", c ? c.g.left : 0]);
      b.push(["topOffset", d]);
      a.A.j || b.push(["c", a.la]);
      c = a.Ia ? 4 : 1;
      a.da && (c = 2);
      b.push(["t", c]);
      b.push(["renderingType", "2"]);
      (zk(a.g, 117) && Dk(a.A, "simplify_query_string")) ||
        !window.layoutsPreview ||
        (b.push(["layoutsRuntime", window.layoutsPreview.layoutsRuntime]),
        b.push(["fillerContext", window.layoutsPreview.fillerContext]));
      (a = a.A.g.CREATIVE_PARAMETER_ENABLER_VERSION) && b.push(["ev", a]);
      return b.length
        ? "?" +
            b
              .map(function (e) {
                return e.join("=");
              })
              .join("&")
        : "";
    },
    uo = function (a) {
      var b = [];
      a.A.j && b.push(["c", a.la]);
      return b.length
        ? "#" +
            b
              .map(function (c) {
                return c.join("=");
              })
              .join("&")
        : "";
    };
  Z.prototype.Sa = function (a, b) {
    bo.prototype.Sa.call(this, a, b);
    bk(this.o, "100%", "100%");
  };
  Z.prototype.de = function (a) {
    return this.oa(a.methodName, a.args);
  };
  var oo = function (a, b) {
    zk(a.g, 23)
      ? co(a, "setAdVisibleInternal", [b])
      : a.I(new Y(b ? "visible" : "hidden"));
  };
  Z.prototype.hb = function () {
    bo.prototype.hb.call(this);
    so(this);
    zk(this.g, 23) && co(this, "finishCollapseInternal");
  };
  Z.prototype.I = function (a) {
    co(this, "dispatchEvent", [a]);
  };
  var co = function (a, b, c) {
      b = vo(b, Array.isArray(c) ? c : []);
      a.D && a.D.isConnected() && a.G
        ? no(a.G, b, function () {})
        : a.Ca.push(b);
    },
    vo = function (a, b) {
      return { methodName: a, args: b ? b : [] };
    };
  k = Z.prototype;
  k.xd = function (a) {
    po(this, "m");
    a && a.data && a.data.features && Re(a.data.features);
    Se(1) && (this.Yb = new fn(this.A, this.g));
    a = this.Yb.g(this.V());
    co(this, "setAdParameters", [a]);
    this.yb();
  };
  k.Nd = function (a) {
    this.K &&
      a.data &&
      (a.data.version && Lm(this.K, a.data.version),
      md(
        Di,
        function (b) {
          b in a.data && Fm(this.K, b, a.data[b]);
        },
        this
      ));
  };
  k.Hd = function (a) {
    a.type == "setResponsiveBehavior" &&
      a.data &&
      a.data.state == 2 &&
      ((this.v.I = a.data.behavior == 2), z(this.pb, this, null));
    this.hc = !0;
    wo(this);
  };
  k.Id = function (a) {
    a.type == "responsiveResize" &&
      a.data &&
      (this.B == null && (this.B = Qd(this.Ha)),
      (this.B.width = a.data.width || this.B.width),
      (this.B.height = a.data.height || this.B.height),
      wo(this));
  };
  k.Ad = function (a) {
    var b = this;
    if (a.type == "getHostpageFeatures") {
      a = {};
      var c =
        ((a.hostpageScroll = !1),
        (a.viewportAware = !1),
        (a.belowTheFold = !1),
        a);
      a = [];
      this.R &&
        ((c.hostpageScroll = !0),
        (c.viewportAware = !0),
        a.push(
          og(
            mn(this.Wa).then(function (d) {
              d &&
                d.hasOwnProperty("creativeFramePercentY") &&
                (c.belowTheFold = Number(d.creativeFramePercentY) <= 0);
            }),
            function () {}
          )
        ),
        this.R.ua("HIFI", {
          messageType: "registerEvent",
          registerEventType: "requestAdLocation",
        }));
      Promise.all(a).then(function () {
        var d = new Y("hostpageFeaturesLoaded");
        d.Ta("features", c);
        b.I(d);
      });
    }
  };
  k.Bd = function () {
    An(this.v).then(
      function (a) {
        co(this, "fullscreenSupportInternal", [a]);
      },
      void 0,
      this
    );
  };
  k.pb = function () {
    zn(this.v).then(
      function (a) {
        co(
          this,
          "fullscreenDimensionsInternal",
          Pd(xm, a) ? [] : [a.width, a.height]
        );
      },
      function () {
        co(this, "fullscreenDimensionsInternal", [0, 0]);
      },
      this
    );
  };
  var wo = function (a) {
    if (a.na && a.hc) {
      var b = a.v.I;
      b && a.B == null
        ? b && a.pb(null)
        : ((a.na = !1),
          a.Sb(
            new gj(
              "fullscreenExpandRequested",
              null,
              b ? [a.B.width, a.B.height] : []
            )
          ));
    }
  };
  k = Z.prototype;
  k.Sb = function (a) {
    In(this.Z, !0);
    a = a.data.length == 2 ? new I(a.data[0], a.data[1]) : null;
    this.na = !1;
    a != null && (this.B = Qd(a));
    og(
      Bn(this.v, Qd(this.Ha), a)
        .then(this.v.M, void 0, this.v)
        .then(
          function (b) {
            this.j(new gj("triggerOuterFullscreenExpand", null, b));
            co(this, "fullscreenExpandStartInternal", [
              b.Pa.width,
              b.Pa.height,
              b.jc.x,
              b.jc.y,
            ]);
          },
          void 0,
          this
        ),
      function () {
        co(this, "fullscreenExpandStartInternal", [0, 0, 0, 0]);
      },
      this
    );
  };
  k.zd = function () {
    co(this, "fullscreenExpandFinishInternal", []);
  };
  k.Gd = function () {
    co(this, "fullscreenCollapseStartInternal", []);
  };
  k.yd = function () {
    In(this.Z, !1);
    var a = this.v;
    a.B &&
      (a.C && a.C.cancel(),
      xn(a) && xn(a).v(),
      vn(a.G),
      Cn(a),
      (a.B = !1),
      (a.C = null));
    co(this, "fullscreenCollapseFinishInternal", []);
    this.yb();
  };
  k.Dd = function (a) {
    var b = new Y("visibilityChangeWithInfo");
    b.Ta("visibilityParams", a);
    this.I(b);
  };
  k.Ed = function (a) {
    if (
      a &&
      a.data.type &&
      (this.dc.push(a), !Dk(this.A, "use_event_sources"))
    ) {
      var b = a.data.type;
      b in yi &&
        (Na(Ai, b) >= 0 &&
          this.R &&
          this.R.ua("HIFI", {
            messageType: "registerEvent",
            registerEventType: b,
            registrationOptions: a.data.Od || {},
          }),
        ln(this.Wa, b));
    }
  };
  k.yb = function () {
    if (
      this.ka != xo(this) ||
      ("onorientationchange" in window && this.ga != window.orientation)
    ) {
      this.ka = xo(this);
      "onorientationchange" in window && (this.ga = window.orientation);
      var a = new Y("orientation");
      a.Ta("mode", this.ka);
      a.Ta("degrees", this.ga);
      this.I(a);
    }
  };
  var xo = function (a) {
    a = a.Y.g.defaultView;
    return a.innerWidth > a.innerHeight ? "landscape" : "portrait";
  };
  Z.prototype.oa = function (a, b) {
    switch (a) {
      case "invokeExternalJSFunctionWithReturn":
        return this.tc.apply(this, b);
      default:
        return bo.prototype.oa.call(this, a, b);
    }
  };
  Z.prototype.tc = function (a, b, c) {
    a = bf(a);
    if (!a) return null;
    var d = b.lastIndexOf(".");
    if (d > -1) {
      var e = b.substring(0, d);
      b = b.substring(d + 1);
      a = y(e, a);
    }
    b = y(b, a);
    return a == null && b == null
      ? null
      : typeof b === "function"
      ? b.apply(a, c)
      : b;
  };
  var yo = function () {
    this.g = [];
    this.j = [];
  };
  k = yo.prototype;
  k.addReporter = function (a) {
    C(this.g, function (b) {
      b.newReporterCallback(a);
      a.newReporterCallback(b);
    });
    C(this.j, function (b) {
      a.registerChargeableEventName(b);
    });
    this.g.push(a);
  };
  k.reportEvents = function (a) {
    C(this.g, function (b) {
      b.reportEvents(a);
    });
  };
  k.registerChargeableEventName = function (a) {
    C(this.g, function (b) {
      b.registerChargeableEventName(a);
    });
    this.j.push(a);
  };
  k.logCustomVariable = function (a, b) {
    C(this.g, function (c) {
      c.logCustomVariable(a, b);
    });
  };
  k.getType = function () {
    return "UNIFIED_DISPATCHER";
  };
  k.getConfig = function () {
    return { reportingApiVersion: 2 };
  };
  k.newReporterCallback = function () {};
  k.supportsChargeableEvents = function () {
    var a = !1;
    C(this.g, function (b) {
      b.supportsChargeableEvents() && (a = !0);
    });
    return a;
  };
  var zo = function (a, b) {
    this.v = a.Z;
    this.j = a.U;
    this.g = a;
    this.o = b;
  };
  zo.prototype.reportEvents = function (a) {
    a = Ao(this, a);
    if (a.length)
      for (var b = A(), c = 0; c < a.length; c++)
        $d(document, "img").src = this.v + "&timestamp=" + b + ";" + a[c];
  };
  zo.prototype.registerChargeableEventName = function (a) {
    var b = this.g.V;
    Nk(this.g, a, !0) && !b && Ok(this.g, !1);
  };
  var Ao = function (a, b) {
    for (var c = [], d = 0; d < b.length; d++) {
      var e = b[d],
        f = Uk(a.g, e.unifiedReportingEvent);
      if (f) {
        var g = c;
        e = [
          "eid",
          d + 1,
          "=",
          f,
          ";ecn",
          d + 1,
          "=",
          e.count,
          ";etm",
          d + 1,
          "=",
          e.time,
          ";",
        ].join("");
        g.length == 0 && g.push("");
        f = g.pop();
        f.length + e.length > 950 && (g.push(f), (f = ""));
        g.push(f + e);
      }
    }
    return c;
  };
  k = zo.prototype;
  k.logCustomVariable = function (a, b) {
    this.j &&
      this.j.length > 0 &&
      ej(
        this.o,
        [this.j, "&timestamp=", A(), ";str=", a, ";strtype=", b].join("")
      );
  };
  k.getType = function () {
    return "STUDIO";
  };
  k.getConfig = function () {
    return { reportingApiVersion: 2 };
  };
  k.newReporterCallback = function (a) {
    a.supportsChargeableEvents() && !this.g.V && Ok(this.g, !0);
  };
  k.supportsChargeableEvents = function () {
    return !1;
  };
  function Bo(a) {
    this.v = {};
    this.g = {};
    this.o = {};
    this.F = {};
    this.j = this.Lb(a);
    this.B = a;
    this.C = {};
    this.D = {};
    this.A = {};
  }
  B(Bo, M);
  var Do = function (a, b, c, d) {
      if (c || !a.F[b])
        a.F[b] || ((a.v[b] = 0), (a.F[b] = !0)), a.v[b]++, d && Co(a, d);
    },
    Co = function (a, b) {
      C(
        b,
        function (c) {
          C(
            Ik(this.B, c),
            function (d) {
              d.ping();
            },
            this
          );
        },
        a
      );
    },
    Eo = function (a, b, c, d) {
      if (!(b in a.o)) {
        for (var e = A(), f = a.C[b]; f && f.length > 0; ) e += f.pop();
        a.o[b] = e;
        c && ((a.A[c] = a.A[c] || []), a.A[c].push(b));
        Do(a, b, !1, d);
      }
    },
    Fo = function (a, b, c) {
      if (b in a.o) {
        for (var d = a.o[b], e = A(), f = a.D[b]; f && f.length > 0; )
          e += f.pop();
        d = e - d;
        d < 0 && (d = 0);
        a.g[b] = a.g[b] || 0;
        a.g[b] += d;
        delete a.o[b];
        c && a.A[c] && Ta(a.A[c], b);
      }
    },
    Go = function (a) {
      for (var b in a.o) Fo(a, b);
    },
    Ho = function (a) {
      for (var b in a.o) Fo(a, b), Eo(a, b);
      b = [];
      for (var c in a.v) {
        var d = 0,
          e = a.v[c];
        a.g[c] && ((d = Math.floor(a.g[c] / 1e3)), (a.g[c] -= d * 1e3));
        a.v[c] = 0;
        if (e > 0 || d > 0) {
          var f = b,
            g = f.push,
            h = c.match(/([^:]+):([^:]*):([^:]*):(.+)/);
          g.call(f, {
            unifiedReportingEvent:
              h && h.length == 5
                ? {
                    type: h[1],
                    name: unescape(h[2]),
                    videoName: unescape(h[3]),
                    trigger: h[4],
                  }
                : null,
            count: e,
            time: d,
          });
        }
      }
      if (Gk(a.B)) {
        if (
          ((c = a.j),
          (a = a.B.g.CREATIVE_PARAMETER_TURTLEX_AD_SIGNALS) && b.length != 0)
        ) {
          b = Ao(c, b).join(";");
          a = { Db: a, label: "rm_html5_event", Xb: b };
          var l = l === void 0 ? u : l;
          b = new Nc();
          a != null &&
            (a.Db != null && Ic(b, 1, a.Db),
            a.ae != null && Ic(b, 3, a.ae),
            a.label != null && Ic(b, 6, a.label),
            a.Kd != null && Ic(b, 7, a.Kd),
            a.cd != null && Ic(b, 8, a.cd),
            a.Xb != null && Ic(b, 11, a.Xb));
          var m;
          (m = Pc(l).fence) == null ||
            m.reportEvent({
              eventType: "interaction",
              eventData: Kc(b),
              destination: ["buyer"],
            });
        }
      } else a.j.reportEvents(b);
    };
  Bo.prototype.H = function () {
    Go(this);
    Bo.X.H.call(this);
  };
  var Io = function (a) {
    this.o = a;
    this.j = !1;
    this.g = new Pe();
  };
  k = Io.prototype;
  k.reportEvents = function (a) {
    this.j ||
      C(
        a,
        function (b) {
          this.g.has(b.unifiedReportingEvent.name) &&
            ((this.j = !0),
            C(Ik(this.o, "ENGAGEMENT_IMG"), function (c) {
              c.ping();
            }));
        },
        this
      );
  };
  k.registerChargeableEventName = function (a) {
    this.g.add(a);
  };
  k.logCustomVariable = function () {};
  k.getType = function () {
    return "THIRD_PARTY";
  };
  k.getConfig = function () {
    return { reportingApiVersion: 2 };
  };
  k.newReporterCallback = function () {};
  k.supportsChargeableEvents = function () {
    return !1;
  };
  function Jo(a, b) {
    this.G = b;
    Bo.call(this, a);
  }
  B(Jo, Bo);
  k = Jo.prototype;
  k.Lb = function (a) {
    if ("gdn" == Cm()) {
      var b = y("googlecreative.reporting.sharedReporter");
      b || ((b = new yo()), v("googlecreative.reporting.sharedReporter", b));
      b.addReporter(new zo(a, this.G));
      0 < Ik(a, "ENGAGEMENT_IMG").length && b.addReporter(new Io(a));
    } else b = new zo(a, this.G);
    return b;
  };
  k.nb = function () {};
  k.lb = function () {};
  k.Bb = function (a, b) {
    this.j.logCustomVariable(a, b);
  };
  k.Cb = function (a) {
    this.j.registerChargeableEventName(a);
  };
  var Ko = function (a) {
    M.call(this);
    this.A = a;
    this.v = null;
    this.C = !1;
    this.o = null;
    this.j = [];
  };
  q(Ko, M);
  k = Ko.prototype;
  k.wb = function () {};
  k.Tb = function () {};
  k.ha = function () {
    var a;
    if ((a = this.rb())) {
      a: {
        a = this.A;
        for (c in a.v) {
          var b = a.B.G[c];
          if (b && b.B) {
            var c = !0;
            break a;
          }
        }
        c = !1;
      }
      a = c || !this.ob();
    }
    a && (Ho(this.A), (this.o = A()));
  };
  k.ob = function () {
    return this.o != null && A() - this.o <= 5e3;
  };
  k.rb = function () {
    return this.v != null && A() - this.v <= 12e5;
  };
  k.H = function () {
    for (this.ha(); this.j.length > 0; ) {
      var a = this.j.pop();
      typeof a === "number" ? u.clearTimeout(a) : a.dispose();
    }
    M.prototype.H.call(this);
  };
  var Lo = function (a, b, c) {
    Ko.call(this, a);
    this.B = b;
    this.D = c;
    this.g = new T(this.B * 1e3);
    O(this.g, "tick", z(this.ha, this));
  };
  q(Lo, Ko);
  k = Lo.prototype;
  k.Tb = function () {
    this.g.o || this.g.start();
  };
  k.ha = function () {
    wh(this.g);
    Ko.prototype.ha.call(this);
  };
  k.rb = function () {
    return (this.v != null && this.D) || Ko.prototype.rb.call(this);
  };
  k.ob = function () {
    return !1;
  };
  k.H = function () {
    wh(this.g);
    this.g.dispose();
    Ko.prototype.H.call(this);
  };
  var Mo = function (a, b, c) {
    Ko.call(this, a);
    this.g = b;
    this.B = c && this.g.length > 0 ? this.g.pop() : null;
  };
  q(Mo, Ko);
  Mo.prototype.wb = function () {
    for (var a = 0; a < this.g.length; a++)
      this.j.push(xh(z(this.ha, this), this.g[a] * 1e3));
    this.B != null &&
      ((a = new T(this.B * 1e3)),
      O(a, "tick", z(this.ha, this)),
      a.start(),
      this.j.push(a));
  };
  var No = [10, 20, 50, 120];
  var Oo = function (a) {
    this.g = a;
    this.j =
      typeof DARTDebugEventHandler != "undefined" && DARTDebugEventHandler
        ? new DARTDebugEventHandler()
        : null;
    E(H(this.g.Ha)) || DARTDebugEventHandler.initPreviewSession(this.g.Ha);
  };
  k = Oo.prototype;
  k.nb = function (a, b, c) {
    a = this.g.G[a];
    if (this.j)
      try {
        this.j.handleEventAction(b, a.name, c, a.type, !a.v, this.g.A);
      } catch (d) {}
  };
  k.reportEvents = function (a) {
    if (this.j)
      for (var b = 0; b < a.length; ++b) {
        var c = a[b],
          d = c.unifiedReportingEvent;
        d =
          this.g.G[
            [d.type, escape(d.name), escape(d.videoName), d.trigger].join(":")
          ];
        try {
          this.j.handleEventActivity(
            d.name,
            d.type,
            c.count,
            c.time,
            !d.v,
            this.g.A
          );
        } catch (e) {}
      }
  };
  k.registerChargeableEventName = function () {};
  k.lb = function (a) {
    try {
      this.j.handleCustomJSExecution(a, this.g.A);
    } catch (b) {}
  };
  k.logCustomVariable = function (a, b) {
    try {
      this.j.handleCustomVariable(unescape(a), b, this.g.A);
    } catch (c) {}
  };
  k.getType = function () {
    return "OUTPUT_CONSOLE";
  };
  k.getConfig = function () {
    return { reportingApiVersion: 2 };
  };
  k.newReporterCallback = function () {};
  k.supportsChargeableEvents = function () {
    return !1;
  };
  var Po = function (a) {
    Bo.call(this, a);
  };
  q(Po, Bo);
  k = Po.prototype;
  k.Lb = function (a) {
    return new Oo(a);
  };
  k.nb = function (a, b, c) {
    this.j.nb(a, b, c);
  };
  k.lb = function (a) {
    this.j.lb(a);
  };
  k.Bb = function (a, b) {
    this.j.logCustomVariable(a, b);
  };
  k.Cb = function () {};
  var Qo = function (a, b, c) {
    Ko.call(this, a);
    this.g = b;
    this.B = c;
  };
  q(Qo, Ko);
  Qo.prototype.ob = function () {
    return this.B && Ko.prototype.ob.call(this);
  };
  Qo.prototype.wb = function () {
    var a = new T(this.g * 1e3);
    O(a, "tick", z(this.ha, this));
    a.start();
    this.j.push(a);
  };
  function Ro(a, b, c, d, e) {
    S.call(this);
    this.g = a;
    this.oa = b;
    this.Y = e;
    this.B = c;
    this.o = {};
    this.I = {};
    this.F = new Gf(this);
    this.R = this.S = !1;
    this.C = this.V = 0;
    this.D = [];
    this.J = {};
    this.da = new V(this.g, this);
    this.G = d;
    this.v = a.j ? new Po(a) : new Jo(a, this.G);
    this.A = So(a, this.v);
    this.K = {};
    tb && P(this.F, self, "unload", this.dispose);
    P(this.F, u, "pagehide", z(this.A.ha, this.A));
    this.B.g != null && (this.B.init(), (this.B.o = this.g.P));
    le(1);
    le(64);
    window.layoutsPreview && le(16);
    "gdn" == Cm() && le(32);
    this.g.j && le(256);
    this.B.g != null && le(8);
  }
  B(Ro, S);
  var To = {},
    So = function (a, b) {
      var c = !1;
      C(a.o, function (d) {
        d.g != null && d.g.j == "lightbox" && (c = !0);
      });
      return a.j ? new Qo(b, 2, !1) : c ? new Lo(b, 2, !0) : new Mo(b, No, !0);
    };
  Ro.prototype.la = function () {
    this.C++;
    Uo(this);
  };
  Ro.prototype.ga = function () {
    Vo(this, new ij("logEvent", "Count", "FULL_SCREEN"));
  };
  Ro.prototype.ma = function (a) {
    typeof a.C === "boolean" && a.C ? Vo(this, a) : Wo(this, a);
    a.G && this.A.ha();
  };
  Ro.prototype.fa = function () {
    this.A.ha();
  };
  var Wo = function (a, b) {
      var c = Fi(b.j);
      c = Pk(b.B, c);
      c != null && Xo(a, c, b.j, b.F, b.g);
    },
    Xo = function (a, b, c, d, e, f) {
      if (b !== null)
        switch ((a.v.nb(b, c, d), c)) {
          case "Exit":
            f || (f = []), f.push("CLICK");
          case "Count":
            Do(a.v, b, d, f);
            b = a.g.G[b];
            c = !1;
            b &&
              b.A &&
              ((b = a.A),
              b.C ? (c = !1) : (Ho(b.A), (b.o = A()), (c = b.C = !0)));
            c || a.A.Tb();
            break;
          case "Start":
            Eo(a.v, b, e, f);
            break;
          case "Stop":
            Fo(a.v, b, e);
        }
    },
    Vo = function (a, b) {
      if (b.o == "DISPLAY_TIMER")
        b.j == "Start" &&
          (a.S || (Yo(a).then(a.Z, void 0, a), (a.S = !0)),
          a.V++ == 0 && (b = Qk(a.g, "DISPLAY_TIMER")) && Xo(a, b, "Start", !1),
          a.C--);
      else {
        var c = Qk(a.g, b.o);
        if (c) {
          var d = [];
          (b.o == "FULL_SCREEN" || (b.o == "EXPAND_TIMER" && b.j == "Start")) &&
            d.push("EXPANSION");
          Xo(a, c, b.j, !1, b.g, d);
        }
      }
    };
  k = Ro.prototype;
  k.Ld = function (a) {
    Vo(this, a);
    var b = Rk(this.g, a.o, a.videoName);
    b != null && Xo(this, b, a.j, !1, a.g);
  };
  k.cc = function () {
    var a = Qk(this.g, "DISPLAY_TIMER");
    a && Xo(this, a, "Stop", !1);
  };
  k.sb = function (a) {
    var b = this.g.W[a.B] || {},
      c = a.D != null ? a.D : b.url;
    a.o == null || E(H(a.o)) || (c = Ye(c, a.o));
    var d = this.g.M,
      e = Ik(this.g, "CLICK"),
      f = 1 == e.length ? e[0].sa() : "",
      g = c;
    e = a.A != null ? a.A : this.g.D;
    "market" == (c.match(Ue)[1] || null) && xb
      ? ((c = $e(
          this.g.D,
          "http://ad.doubleclick.net/viewad/817-grey.gif",
          b.reportingId || null,
          f,
          d
        )),
        ej(this.G, c))
      : (g = $e(e, c, b.reportingId || null, f, d));
    c = g;
    d = b.o;
    b = b.j != null ? b.j : void 0;
    this.B.g != null
      ? ((b = this.B),
        bl.test(c)
          ? b.g.expand(c)
          : u.AFMA_Communicator &&
            u.AFMA_Communicator.sendMessage &&
            ((b.o &&
              b.o.enable_open_system_browser &&
              b.o.enable_open_system_browser) ||
              al(b))
          ? u.AFMA_Communicator.sendMessage("open", {
              a: "app",
              u: c,
              system_browser: !0,
              use_first_package: !0,
              use_running_process: !0,
              use_custom_tabs: al(b),
            })
          : b.g.open(c))
      : window.open(c, d || "_blank", b || "");
    a.log && e.indexOf("[rm_exit_id]") == -1 && Wo(this, a);
    this.A.ha();
  };
  k.Fd = function (a) {
    var b = this.I[a.g];
    switch (a.type) {
      case "expandAsset":
        ul(this, b);
        break;
      case "expandRequested":
        ul(this, b);
        break;
      case "expandFinished":
        if ((a = this.o[b])) Zn(a), this.j(new pl("EXPAND_FINISH", b));
        break;
      case "collapseAsset":
        vl(this, b);
        break;
      case "collapseRequested":
        vl(this, b);
        break;
      case "collapseFinished":
        if ((a = this.o[b])) a.hb(), this.j(new pl("COLLAPSE_FINISH", b));
        break;
      case "tellAssetHide":
        this.M(b);
    }
  };
  k.vd = function (a) {
    a = unescape(a.j);
    this.g.j && this.v.lb(a);
    try {
      eval(a);
    } catch (b) {}
  };
  k.ud = function (a) {
    var b = Qk(this.g, a.j);
    if (b) {
      var c = this.v,
        d = a.o;
      a = a.A;
      var e = c.C[b] || (c.C[b] = []);
      b = c.D[b] || (c.D[b] = []);
      d != 0 && e.push(d);
      a != 0 && b.push(a);
    }
  };
  k.wd = function (a) {
    this.v.Bb(a.j, a.o);
  };
  k.Xd = function (a) {
    var b = this.g.g.CREATIVE_PARAMETER_TURTLEX_AD_SIGNALS,
      c = this.g.g.CREATIVE_PARAMETER_TURTLEX_AD_METADATA,
      d = a.data.reportingId;
    if (b && d) {
      var e = a.data.clickX,
        f = a.data.clickY,
        g = a.data.creativeDims,
        h = a.data.bgResponse;
      a = new Nc();
      Ic(a, 1, b);
      Ic(a, 5, d);
      b = new Mc();
      e !== void 0 && Gc(b, 2, e == null ? e : sc(e));
      f !== void 0 && Gc(b, 3, f == null ? f : sc(f));
      g && Ic(b, 7, g);
      h && Ic(b, 4, h);
      e = Kc(b);
      Ic(a, 4, e);
      if (Rb && Za(el, 116) >= 0) {
        var l;
        (l = window.fence) == null ||
          l.setReportEventDataForAutomaticBeacons({
            eventType: "reserved.top_navigation",
            eventData: Kc(a),
            destination: ["buyer"],
            once: !0,
          });
      } else {
        var m;
        (m = window.fence) == null ||
          m.setReportEventDataForAutomaticBeacons({
            eventType: "reserved.top_navigation",
            eventData: Kc(a),
            destination: ["buyer"],
          });
      }
      var n;
      (n = window.fence) == null ||
        n.setReportEventDataForAutomaticBeacons({
          eventType: "reserved.top_navigation_start",
          eventData: Kc(a),
          destination: ["buyer"],
        });
      var r;
      (r = window.fence) == null ||
        r.reportEvent({
          eventType: "click",
          eventData: Kc(a),
          destination: ["buyer"],
        });
      c = c
        ? {
            eventType: "click",
            eventData: c,
            destination: ["component-seller"],
          }
        : { eventType: "click", destination: ["component-seller"] };
      var D;
      (D = window.fence) == null || D.reportEvent(c);
    }
  };
  k.init = function () {
    var a = Ik(this.g, "IMPRESSION_JS");
    a.length > 0 &&
      ((a = Pa(a, function (b) {
        return b.sa();
      })),
      nl(a, this.g.J));
    Zo(this);
  };
  var Zo = function (a) {
      for (var b = a.g.o, c = 0; c < b.length; c++) {
        var d = b[c],
          e = d.j;
        tl(
          a,
          d,
          e && !e.j
            ? -1
            : ((e && e.j && e.startTime > 0 && e.startTime) || 0) * 1e3
        );
      }
    },
    tl = function (a, b, c) {
      c ? c > 0 && (a.C++, a.D.push(xh(z(a.U, a, b), c))) : (a.C++, a.U(b));
    };
  Ro.prototype.U = function (a) {
    if (!(a in this.o)) {
      var b = this.oa;
      var c = this.g,
        d = this.Y;
      b.j(a)
        ? ((b.g = $o(b)),
          (d = new Z(a, c, d, void 0, b.g)),
          Dk(c, "use_event_sources") && b.g && ap(new bp(b.g), d),
          (b = d))
        : (b = null);
      if (b) {
        this.o[a] = b;
        this.I[b] = a;
        b = this.o[a];
        c = this.F;
        P(c, b, "logEvent", this.ma);
        P(c, b, "logVideoEvent", this.Ld);
        P(c, b, "logExitFlushEventsOpenPopup", this.sb);
        P(c, b, "launchExit", this.sb);
        Gk(this.g) && P(c, b, "TURTLEX_AD_CLICKED", this.Xd);
        P(
          c,
          b,
          "expandAsset expandRequested expandFinished collapseAsset collapseRequested collapseFinished tellAssetHide".split(
            " "
          ),
          this.Fd
        );
        P(c, b, "invokeExternalJSFunction", this.vd);
        P(c, b, "reportCustomVariable", this.wd);
        P(c, b, "setTimerAdjustment", this.ud);
        P(c, b, "flushCounters", this.fa);
        P(c, b, "RESET", this.la);
        P(c, b, "registerChargeableEventName", this.ka);
        P(c, b, "fullscreenExpandFinished", this.ga);
        if (a.L || this.g.R) {
          if (((b = a.F), (c = null), b && (c = Ud(document, b)), c)) {
            if ((d = this.g.R))
              (d = c),
                (d = !(
                  !E(H(Wj(d, "position"))) && "static" != Wj(d, "position")
                ));
            d && (c.style.position = "relative");
            this.g.Da &&
              ((c.style.display = "inline-block"),
              (c.style.verticalAlign = "top"));
            a.g &&
              a.g.o &&
              ((this.K[b] = c.style.height), (c.style.height = "auto"));
            this.o[a].Ra(c);
          }
        } else
          document.body && document.body.firstChild
            ? this.o[a].Ea(document.body.firstChild)
            : document.body
            ? this.o[a].Ra(document.body)
            : document.documentElement &&
              this.o[a].Ra(document.documentElement);
        this.j(new pl("SHOW", a));
      }
    }
    a.j &&
      ((b = a.j),
      (b = ((b && b.g && b.endTime > 0 && b.endTime) || -1) * 1e3),
      b > 0 &&
        ((b = xh(z(this.M, this, a), b)), this.D.push(b), (this.J[a] = b)));
    this.R || (Yo(this).then(this.na, void 0, this), (this.R = !0));
    this.g.Ba && cp(this);
  };
  var cp = function (a) {
      var b = a.g.Va;
      b
        ? ((b = u["bllsn" + b]),
          typeof b !== "function"
            ? setTimeout(function () {
                throw Error("atw: blockListenCallback is not a function");
              }, 0)
            : b(function (c) {
                if (c && !c.block) {
                  c = a.g.o;
                  for (var d = 0; d < c.length; d++) {
                    var e = a.o[c[d]];
                    (e = e instanceof Z ? e : null) && oo(e, !0);
                  }
                }
              }))
        : setTimeout(function () {
            throw Error("atw: eeid is missing");
          }, 0);
    },
    Yo = function (a) {
      var b = [];
      md(
        a.o,
        function (d, e) {
          d = b.push;
          e = this.o[e];
          if (e.Ja !== null) e = e.Ja;
          else {
            var f = kg();
            Rn(f.resolve);
            e = e.Ja = f.promise;
          }
          d.call(b, e);
        },
        a
      );
      if (a.g.Wa === 8)
        if (((a = Ed()), a == null))
          setTimeout(function () {
            throw Error("vignette: no interstitial API");
          }, 0);
        else {
          var c = kg();
          a.addViewListener(c.resolve);
          b.push(c.promise);
        }
      return ig(b);
    };
  Ro.prototype.M = function (a) {
    var b = this.o[a];
    if (b) {
      for (var c = this.v, d = c.A[b] || []; d.length > 0; ) Fo(c, d.pop(), b);
      delete this.I[b];
      b.dispose();
      delete this.o[a];
      this.J[a] && (u.clearTimeout(this.J[a]), delete this.J[a]);
      this.j(new pl("HIDE", a));
      Uo(this);
    }
  };
  var ul = function (a, b) {
      var c = a.o[b];
      c && (Yn(c), a.j(new pl("EXPAND", b)), a.j(new pl("EXPAND_REQUEST", b)));
    },
    vl = function (a, b) {
      var c = a.o[b];
      c &&
        ($n(c), a.j(new pl("COLLAPSE", b)), a.j(new pl("COLLAPSE_REQUEST", b)));
    };
  Ro.prototype.na = function () {
    dp(this);
  };
  var dp = function (a) {
    a.A.v = A();
    a.g.Ea && Vo(a, new ij("logEvent", "Count", "HTML5_CREATIVE_IMPRESSION"));
    Gk(a.g)
      ? typeof window.vv === "function" && window.vv()
      : a.g.Ca &&
        (a.g.xa && !a.g.j
          ? typeof window.vv === "function"
            ? window.vv()
            : ej(a.G, Oc(a.g.I))
          : ej(a.G, a.g.I));
    var b = [];
    Pj.forEach(function (c) {
      b.push.apply(b, sa(Ik(a.g, c)));
    });
    a.g.xa && typeof window.pdib3 === "function" && !a.g.j
      ? b.forEach(function (c) {
          var d = c.sa();
          E(H(d)) || (c.ac ? Pc().pdib3(d, !0) : Pc().pdib3(d, !1));
        })
      : b.forEach(function (c) {
          c.ping();
        });
  };
  Ro.prototype.Z = function () {
    this.A.wb();
    this.D.push(xh(z(this.cc, this), 24e4));
  };
  var Uo = function (a) {
    --a.V == 0 && (a.cc(), Go(a.v), a.C == 0 && a.dispose());
  };
  Ro.prototype.ka = function (a) {
    this.v.Cb(a.j);
  };
  Ro.prototype.H = function () {
    for (var a in this.K) Ud(document, a).style.height = this.K[a];
    this.F.dispose();
    for (this.da.dispose(); this.D.length > 0; )
      (a = this.D.pop()), u.clearTimeout(a);
    a = this.g.o;
    for (var b = 0; b < a.length; b++) {
      var c = a[b];
      c in this.o && (this.o[c].dispose(), delete this.o[c]);
    }
    this.I = null;
    this.v.dispose();
    this.v = null;
    a = this.g.B;
    To[a] !== void 0 && delete To[a];
    Ro.X.H.call(this);
  };
  var ep = function (a, b, c, d) {
    he.call(this, a, b);
    this.g = {};
    this.D = c;
    this.A = d;
    this.o = "rmad_perf";
  };
  q(ep, he);
  ep.prototype.j = function () {
    var a = "&rl=" + this.D + "&en=" + this.A;
    if (!qd(this.g)) {
      var b = this.g,
        c = [],
        d;
      for (d in b) Xe(d, b[d], c);
      a += "&" + c.join("&");
    }
    this.v = a;
    return he.prototype.j.call(this);
  };
  var fp = function (a, b) {
    he.call(this, a, "");
    this.A = b;
    this.o = "studio-rl-error";
    this.g = null;
  };
  q(fp, he);
  fp.prototype.j = function () {
    if (null === this.g) return "";
    var a = "&rl=" + this.A + "&err=",
      b = encodeURIComponent;
    if (typeof this.g === "string") var c = this.g;
    else if (this.g instanceof Error) {
      var d = this.g;
      c = d.toString();
      d.name && c.indexOf(d.name) == -1 && (c += ": " + d.name);
      d.message && c.indexOf(d.message) == -1 && (c += ": " + d.message);
      if (d.stack)
        a: {
          d = d.stack;
          var e = c;
          try {
            d.indexOf(e) == -1 && (d = e + "\n" + d);
            for (var f; d != f; )
              (f = d),
                (d = d.replace(
                  RegExp("((https?:/..*/)[^/:]*:\\d+(?:.|\n)*)\\2"),
                  "$1"
                ));
            c = d.replace(RegExp("\n *", "g"), "\n");
            break a;
          } catch (g) {
            c = e;
            break a;
          }
          c = void 0;
        }
    } else c = "Failed to capture error message from: " + this.g.toString();
    this.v = a + b(c);
    return he.prototype.j.call(this);
  };
  var gp = function (a) {
    M.call(this);
    this.A = a + ".js";
    this.j = new fp(0.001, a);
    this.g = this.o = null;
  };
  q(gp, M);
  gp.prototype.isActive = function () {
    return this.j.isActive();
  };
  gp.prototype.v = function (a) {
    var b;
    if ((b = a instanceof ErrorEvent)) {
      b = a.filename;
      var c = this.A,
        d = b.length - c.length;
      b = d >= 0 && b.indexOf(c, d) == d;
    }
    b &&
      ((this.j.g = a.error instanceof Error ? a.error : a.message),
      (a = this.j.j()),
      hk(u, a, !1, !1, !1));
  };
  gp.prototype.H = function () {
    this.g && this.o.removeEventListener("error", this.g, !1);
    M.prototype.H.call(this);
  };
  var hp = function (a) {
    this.g = a;
  };
  var ip = function () {
    M.call(this);
    this.C = {};
    this.j = this.g = null;
    this.o = [];
    this.v = !0;
  };
  q(ip, M);
  var jp = function (a, b, c) {
    a.v = !1;
    a.g === null &&
      (a.g = new Q(
        typeof (u.MutationObserver || u.WebKitMutationObserver) === "function"
          ? a.B
          : a.A,
        a
      ));
    ng(
      a.g.then(b, function () {}, c),
      function () {
        this.j !== null && this.j.disconnect();
        this.v = !0;
      },
      a
    );
  };
  ip.prototype.B = function (a) {
    kp(this)
      ? a()
      : ((this.j = new u.MutationObserver(
          z(function (b, c) {
            var d = !1;
            C(b, function (e) {
              "childList" == e.type && 0 != e.addedNodes.length && (d = !0);
            });
            d && kp(this) && (c.disconnect(), a());
          }, this)
        )),
        this.j.observe(u.document.documentElement, {
          childList: !0,
          subtree: !0,
        }));
  };
  ip.prototype.A = function (a) {
    var b = new Nn(1500);
    Mn
      ? kp(this) && a()
      : O(
          b,
          "ready",
          function () {
            kp(this)
              ? a()
              : xh(
                  function () {
                    kp(this) && a();
                  },
                  0,
                  this
                );
          },
          !1,
          this
        );
  };
  var kp = function (a) {
    for (var b = a.o.length - 1; b >= 0; --b) {
      var c = a.o[b];
      if (Ud(document, c) === null) {
        b: {
          var d = window;
          try {
            var e = d.parent.document;
            break b;
          } catch (f) {}
          e = void 0;
        }
        c = e ? e.getElementById(c) !== null : !1;
      } else c = !0;
      if (!c) return (a.o.length = b + 1), !1;
    }
    a.o = [];
    return !0;
  };
  ip.prototype.H = function () {
    this.g !== null && this.g.cancel();
    this.g = null;
    this.j !== null && this.j.disconnect();
    this.j = null;
  };
  var lp = null,
    mp = null,
    np = function (a, b) {
      return Pa(Ik(a, b), function (c) {
        return c.sa();
      });
    },
    op = function (a) {
      var b = Jk(a).length > 0,
        c = a.oa;
      a = a.ma;
      return b && kl(c, a);
    },
    qp = function (a) {
      var b = "",
        c = y("dclkStudioV3.startTimes." + a.B),
        d = Jk(a);
      d.length > 0 && (b = (b = d[0].o) && b.g ? b.g : "");
      d = !E(b) && "0_0" !== b;
      c && d
        ? ((a = pp(mp, a.j)),
          (c = new Im(new ep(4e-5, "https:", "200_287", b), a, c, b)))
        : (c = null);
      return c;
    },
    sp = function (a) {
      if (op(a)) {
        var b = qp(a);
        b && Fm(b, "l", A());
        var c = new ip();
        C(a.o, function (e) {
          e = e.F;
          e != null &&
            c.v &&
            ((e = new hp(e)), (c.g = null), (c.C["."] = e), c.o.push(e.g));
        });
        a = rp(a, b);
        jp(c, a.init, a);
      } else if (a.K) {
        b = np(a, "IMPRESSION_IMG");
        var d = np(a, "IMPRESSION_JS");
        ll(a.A, a.K, a.J, a.j, b, a.F.g, a.F.B, a.F.A, a.F.j, d);
      }
    },
    up = function () {
      tp().then(function (a) {
        C(a, sp);
      });
    },
    vp = function (a) {
      To[a] && To[a].dispose();
    };
  var wp = function (a, b) {
    if (a.videoData) {
      var c = a.videoData;
      c = new sk(
        c.associatedVideoEntryReportingIdentifier,
        c.associatedStandardVideoEvent
      );
    }
    return new vk(a.name, a.reportingId, b, c);
  };
  var xp = function (a) {
    return JSON.parse(a.replace(/\\"/g, '"'));
  };
  function yp() {}
  var tp = function () {
    var a = zp();
    return new Q(function (b) {
      var c = [],
        d = y("studioV2.creatives") || {},
        e;
      for (e in d) {
        var f = d[e],
          g = f.creativeDefinition;
        if (g)
          for (var h = f.adResponses; h.length > 0; ) {
            var l = h.shift(),
              m = l.creativeDto;
            if (m.rendererName == Om && m.templateVersion == "200_287") {
              var n = c,
                r = n.push,
                D = void 0,
                K = new Bk(),
                ya = new pk(l.creativeDto),
                qa = void 0,
                Jg = void 0,
                t = K,
                ca = ya;
              if (!t.ka) {
                t.ka = !0;
                var J = ca.j,
                  me = J.C;
                t.A = ca.id || t.A;
                t.B = ca.uniqueId || t.A || t.B;
                t.C = J.B || t.C;
                t.j = ca.v || t.j;
                t.oa = ca.o || t.oa;
                t.ma = ca.A || t.ma;
                t.ga = J.Z || t.ga;
                for (Jg in J.o) t.g[Jg] = J.o[Jg];
                t.g.sn = J.V;
                t.g.sid = J.U;
                t.g.aid = J.F;
                t.g.cid = J.creativeId;
                t.g.buy = J.I;
                t.g.pid = J.R;
                t.g.adv = J.G;
                t.g.kid = J.W;
                t.g.rid = J.S;
                t.g.geo = J.M;
                t.g.randomNumber = J.randomNumber;
                for (qa in me.g) t.g[qa] = me.g[qa];
                t.J = me.j || t.J;
                t.R = me.o || t.R;
                t.fa = "https" == (ca.I.match(Ue)[1] || null);
                t.S = { jb: ca.F || t.S.jb, kb: ca.G || t.S.kb };
                var ne = new jk(t.j);
                E(H(J.g)) || (t.v.CLICK = [new Nj(J.g, ne)]);
                if (Array.isArray(ca.g) && ca.g.length > 0) {
                  t.v.IMPRESSION_IMG = [];
                  for (var Kg = 0; Kg < ca.g.length; ++Kg)
                    t.v.IMPRESSION_IMG.push(new Nj(ca.g[Kg], ne));
                }
                E(H(ca.B)) || (t.v.ARTWORK_IMPRESSION = [new Nj(ca.B, ne)]);
                t.Z = J.P || t.Z;
                t.U = J.Y || t.U;
                t.D = J.A || t.D;
                var Cl = parseInt(J.L, 10);
                t.M = isNaN(Cl) ? t.M : Cl;
                t.I = J.j || t.I;
                t.da = J.J || t.da;
                t.na = J.K || t.na;
                t.K = ca.C || t.K;
                t.F = new cj(ne, J.v || J.D);
              }
              K.Ca = g.delayedImpression;
              var Dl = g.standardEventIds;
              for (D in Dl) Mk(K, D, Dl[D]);
              for (var El = g.exitEvents, Lg = 0; Lg < El.length; Lg++) {
                var Tc = El[Lg],
                  Mg = new qk(Tc.name, Tc.reportingId, Tc.url);
                Mg.o = Tc.targetWindow;
                Mg.j = Tc.windowProperties;
                Sk(K, Mg);
              }
              for (var Fl = g.timerEvents, Ng = 0; Ng < Fl.length; Ng++) {
                var Gl = K,
                  Og = wp(Fl[Ng], "Timer");
                Gl.ya[Og.name] = Og;
                Lk(Gl, Og);
              }
              for (var Hl = g.counterEvents, Pg = 0; Pg < Hl.length; Pg++) {
                var Il = K,
                  Qg = wp(Hl[Pg], "Counter");
                Il.la[Qg.name] = Qg;
                Lk(Il, Qg);
              }
              for (
                var Jl = K.fa, Kl = g.childFiles, Rg = 0;
                Rg < Kl.length;
                Rg++
              )
                Vk(K, ok(Kl[Rg], Jl));
              for (var Ll = g.videoFiles, Sg = 0; Sg < Ll.length; Sg++)
                Vk(K, ok(Ll[Sg], Jl));
              for (var Ml = g.videoEntries, Tg = 0; Tg < Ml.length; Tg++) {
                var Bb = Ml[Tg];
                K.Ja.push(
                  new xk(
                    Bb.reportingIdentifier,
                    new yk(
                      Bb.lowBandwidthVideo,
                      Bb.mediumBandwidthVideo,
                      Bb.highBandwidthVideo
                    ),
                    new yk(
                      Bb.lowBandwidthFallbackVideo,
                      Bb.mediumBandwidthFallbackVideo,
                      Bb.highBandwidthFallbackVideo
                    )
                  )
                );
              }
              var Qp = ya.D,
                Rp = kl(ya.o, ya.A);
              var Sp = Qp && Rp ? "HTML5" : null;
              for (var Nl = g.primaryAssets, Ug = 0; Ug < Nl.length; ++Ug) {
                var pa = Nl[Ug],
                  Tp = l.creativeDto.adServerData.tag,
                  Fa = new Ij(
                    pa.id,
                    pa.artworkType,
                    pa.displayType,
                    new I(
                      parseInt(pa.width, 10) || 0,
                      parseInt(pa.height, 10) || 0
                    ),
                    (Hk(K) || "") + pa.servingPath
                  );
                Fa.D = pa.zIndex;
                Fa.C = pa.location || Fa.C;
                Fa.layoutsConfig = pa.layoutsConfig;
                var Vg = pa.htmlArtworkTypeData;
                Vg && (Fa.o = new Aj(Vg.isTransparent, Vg.sdkVersion));
                var oe = pa.floatingDisplayTypeData;
                if (oe) {
                  var pe = oe.position,
                    Up = new Dj(pe.top + pe.topUnit, pe.left + pe.leftUnit);
                  Fa.j = new zj(Up, oe.startTime, oe.endTime);
                }
                var qe = pa.expandingDisplayTypeData;
                if (qe) {
                  var re = qe.collapsedRect;
                  Fa.g = new yj(
                    new Gj(re.left, re.top, re.width, re.height),
                    qe.isPushdown
                      ? "push_down"
                      : vj(qe.expansionMode) || "normal"
                  );
                }
                var Ol = pa.pageSettings,
                  Pl = new Bj();
                Ol && (Pl.g = Ol.updateZIndex || !1);
                Fa.G = Pl;
                var Wg = void 0,
                  Ql = Tp;
                if (Ql == null) var Rl = {};
                else {
                  var Sl = {};
                  for (Wg in Jj) {
                    var Tl = y(Wg, Ql);
                    Tl !== null && (Sl[Jj[Wg]] = Tl + "");
                  }
                  Rl = Sl;
                }
                Lj(Fa, Rl);
                Kj(Fa);
                var Ul = Fa;
                if (Ul.A == Sp) {
                  var Vl = K,
                    Wl = Ul;
                  Wl.A == "HTML5" && (Vl.Ea = !0);
                  Vl.o.push(Wl);
                }
              }
              r.call(n, K);
            } else {
              h.unshift(l);
              break;
            }
          }
      }
      for (
        var Xl = [],
          Xg = y("window.dclkStudioV3.creatives") || [],
          se = Xg.length - 1;
        se >= 0;
        --se
      ) {
        var w = Xg[se];
        if (w.previewMode) {
          var Cb = y("window.dclkStudioV3.creativeParametersOverrides");
          w &&
            Cb &&
            (Cb.CREATIVE_PARAMETER_LAYOUT_CONFIG &&
              (w.creativeParameters.CREATIVE_PARAMETER_LAYOUT_CONFIG =
                Cb.CREATIVE_PARAMETER_LAYOUT_CONFIG),
            Cb.PREVIEW_FRAME_NAME &&
              (w.creativeParameters.PREVIEW_FRAME_NAME = Cb.PREVIEW_FRAME_NAME),
            Cb.PREVIEW_FRAME_DEPTH &&
              (w.creativeParameters.PREVIEW_FRAME_DEPTH =
                Cb.PREVIEW_FRAME_DEPTH));
        }
        var Yg = void 0,
          da = new Bk(),
          x = da;
        if (!x.ka) {
          x.ka = !0;
          x.Xa = w.renderingLibraryData.version;
          var cb = w.creativeParameters;
          x.A = cb.cid || x.A;
          x.B = cb.creative_unique_id || x.B;
          x.j = Ak(w.previewMode, x.j);
          x.Ha = x.j ? w.previewEventsUrl : "";
          Array.isArray(w.html5Features) &&
            ((x.ma = Na(w.html5Features, "Modernizr.cssanimations") >= 0),
            (x.oa = w.html5Features));
          x.g = cb;
          x.J = cb.ad_container_id || x.J;
          x.R = Ak(cb.mtfRenderFloatInplace, x.R);
          x.Da = Ak(cb.generate_ad_slot, x.Da);
          x.da = cb.exit_suffix || x.da;
          x.fa =
            "https" ==
            ((w.renderingLibraryData.renderingLibrary || "").match(Ue)[1] ||
              null);
          var Zg = w.renderingLibraryData.renderingLibrary.match(Ue)[3] || null;
          var $g = Zg ? decodeURI(Zg) : Zg;
          x.S = { jb: "http://" + $g, kb: "https://" + $g };
          E(H(w.dynamicData)) ||
            ((x.C = w.dynamicData.replace(/\\"/g, '"')),
            (x.C = x.C.replace(/\\\\/g, "\\")),
            (x.C = x.C.replace(/\\'/g, "'")),
            (x.C = x.C.replace(/:\/\/s(0|1)\.2mdn\.net/g, "://" + $g)));
          var Yl = new jk(x.j);
          if (w.thirdPartyUrls != null)
            for (var te = w.thirdPartyUrls, Uc = 0; Uc < te.length; ++Uc) {
              var ue = Qj(te[Uc].type);
              ue != null &&
                (ue in x.v || (x.v[ue] = []),
                x.v[ue].push(new Nj(te[Uc].url, Yl, te[Uc].scrub == "true")));
            }
          x.Z = Ck(w.eventTrackingBaseUrl, "met") || x.Z;
          x.U = Ck(w.customEventTrackingBaseUrl, "stragg") || x.U;
          x.D = w.clickUrl || x.D;
          var Zl = parseInt(cb.clickN, 10);
          x.M = isNaN(Zl) ? x.M : Zl;
          x.I = w.impressionUrl || x.I;
          x.K = lk(w) || x.K;
          x.F = new cj(
            Yl,
            w.activeViewUrlPrefix || w.clickString,
            w.activeViewMetadata,
            w.lidarScriptUrl,
            w.activeViewAttributes
          );
          w.reactiveAdType && (x.Wa = w.reactiveAdType);
        }
        da.Ca = !E(H(w.impressionUrl));
        if (w.creativeParameters.CREATIVE_PARAMETER_EXPERIMENTS) {
          var Vp = xp(w.creativeParameters.CREATIVE_PARAMETER_EXPERIMENTS);
          da.P = Vp;
        }
        da.xa = Ak(w.creativeParameters.CREATIVE_PARAMETER_IS_B2R_ELIGIBLE);
        da.Ba = Ak(
          w.creativeParameters
            .CREATIVE_PARAMETER_AUTO_TAG_WRAPPING_BEHAVIOR_REQUIRED
        );
        da.Va = H(w.creativeParameters.CREATIVE_PARAMETER_EEID);
        for (var ah = 0; ah < w.standardEvents.length; ah++) {
          var $l = w.standardEvents[ah];
          Mk(da, $l.name, $l.reportingId);
        }
        for (var bh = 0; bh < w.exitEvents.length; bh++) {
          var db = w.exitEvents[bh];
          if (!db.backUpExit) {
            var ve = new qk(db.name, db.reportingId, db.destinationUrl);
            ve.o = db.targetWindow;
            ve.j = db.windowProperties;
            ve.eTldPlusOne = db.eTldPlusOne ? db.eTldPlusOne : "";
            Sk(da, ve);
          }
        }
        for (var ch = 0; ch < w.timerEvents.length; ch++) {
          var dh = w.timerEvents[ch],
            am = da,
            eh = new vk(dh.name, dh.reportingId, "Timer", uk(dh.name));
          am.ya[eh.name] = eh;
          Lk(am, eh);
        }
        for (var fh = 0; fh < w.counterEvents.length; fh++) {
          var gh = w.counterEvents[fh],
            bm = da,
            hh = new vk(gh.name, gh.reportingId, "Counter", uk(gh.name));
          bm.la[hh.name] = hh;
          Lk(bm, hh);
        }
        for (var Wp = w.primaryFiles, cm = 0; cm < Wp.length; cm++);
        var we = w.creativeParameters,
          dm = w.primaryFiles,
          em = null;
        "CREATIVE_PARAMETER_LAYOUT_CONFIG" in we &&
          (em = we.CREATIVE_PARAMETER_LAYOUT_CONFIG);
        for (var fm = [], Xp = we.cid || "", xe = 0; xe < dm.length; xe++) {
          var Ga = dm[xe],
            gm = we,
            Yp = em,
            ma = new Ij(
              Xp + "_" + xe,
              Ga.type,
              Ga.renderAs,
              new I(parseInt(Ga.width, 10) || 0, parseInt(Ga.height, 10) || 0),
              Ga.url
            );
          ma.I = Ga.content;
          ma.D = parseInt(Ga.zIndex, 10);
          ma.C = Ga.location || ma.C;
          ma.layoutsConfig = Yp || ma.layoutsConfig;
          var ih = Ga.htmlProperties;
          ih && (ma.o = new Aj(ih.transparent, ih.studioSdkVersion));
          var Vc = Ga.floatingDisplayProperties;
          if (Vc) {
            var Zp = new Dj(Vc.top, Vc.left);
            ma.j = new zj(
              Zp,
              parseInt(Vc.startTime, 10),
              parseInt(Vc.duration, 10)
            );
          }
          var cc = Ga.expandingDisplayProperties;
          if (cc) {
            var Wc = new Gj(
                parseInt(cc.collapsedRectLeft, 10),
                parseInt(cc.collapsedRectTop, 10),
                parseInt(cc.collapsedRectWidth, 10),
                parseInt(cc.collapsedRectHeight, 10)
              ),
              $p = vj(cc.expansionMode) || "normal";
            Mj(Wc.left) &&
              Mj(Wc.top) &&
              Mj(Wc.width) &&
              Mj(Wc.height) &&
              (ma.g = new yj(Wc, $p));
          }
          ma.G = new Bj();
          ma.G.g = !0;
          gm != null && Lj(ma, gm);
          Kj(ma);
          fm.push(ma);
        }
        var hm = fm;
        for (var jh = 0; jh < hm.length; jh++) {
          var im = hm[jh];
          if ("HTML5" == im.A) {
            var jm = da,
              km = im;
            km.A == "HTML5" && (jm.Ea = !0);
            jm.o.push(km);
          }
        }
        var lm = da.fa,
          mm = w.creativeParameters.CREATIVE_PARAMETER_ASSETS_DATA,
          nm = mm ? xp(mm) : {};
        for (Yg in nm) Vk(da, new nk(Yg, nm[Yg], lm, null));
        for (
          var om = w.creativeParameters.CREATIVE_PARAMETER_VIDEO_ASSETS_DATA,
            pm = om ? xp(om) : [],
            kh = 0;
          kh < pm.length;
          ++kh
        ) {
          var ye = pm[kh],
            qm = new nk(ye.name, ye.progressiveUrl, lm),
            lh = qm,
            aq = ye.streamingUrl,
            rm = ye.transcodeInformation;
          lh.o = !0;
          lh.j = aq || null;
          lh.g = rm ? new mk(rm) : null;
          Vk(da, qm);
        }
        for (
          var sm = w.creativeParameters.CREATIVE_PARAMETER_VIDEO_DATA,
            tm = sm ? xp(sm) : [],
            mh = 0;
          mh < tm.length;
          ++mh
        ) {
          var Db = tm[mh];
          da.Ja.push(
            new xk(
              Db.name,
              new yk(Db.vfp_low, Db.vfp_mid, Db.vfp_high),
              new yk(Db.pfp_low, Db.pfp_mid, Db.pfp_high)
            )
          );
        }
        var nh = da;
        a: {
          for (var um = nh.o, oh = 0; oh < um.length; oh++) {
            var ph = um[oh];
            if (ph.v != "BACKUP_IMAGE" && ph.v != "PRE_LOADER" && !lp.j(ph)) {
              var vm = !1;
              break a;
            }
          }
          vm = nh.Xa == "200_287";
        }
        vm && (Array.prototype.splice.call(Xg, se, 1), Xl.push(nh));
      }
      b(c.concat(Xl));
    }, a);
  };
  var Ap = function () {
    M.call(this);
    this.g = null;
    this.o = new Gf(this);
  };
  q(Ap, M);
  var ap = function (a, b) {
    a.g ||
      a.L() ||
      ((a.g = b),
      ef(b, a),
      P(a.o, b, "registerEventTypeListenerForType", a.j),
      b.dc.forEach(function (c) {
        return a.j(c);
      }));
  };
  Ap.prototype.j = function () {};
  Ap.prototype.H = function () {
    this.o.dispose();
    this.g = null;
  };
  var bp = function (a) {
    Ap.call(this);
    var b = this;
    this.v = a;
    this.A = new jn(function (c) {
      b.g && b.g.I(c);
    }, this.v);
  };
  q(bp, Ap);
  bp.prototype.j = function (a) {
    var b = a.data || {};
    a = b.type;
    if (a in yi) {
      b = b.registrationOptions;
      var c = {};
      this.v.ua(
        "HIFI",
        ((c.messageType = "registerEvent"),
        (c.registerEventType = a),
        (c.registrationOptions = b || {}),
        c)
      );
      ln(this.A, a);
    }
  };
  var Bp = function () {
      this.g = null;
    },
    pp = function (a, b) {
      a.g || (a.g = new jk(b));
      return a.g;
    };
  function Cp() {
    this.v = new Bp();
    this.o = null;
  }
  var Dp = function (a, b) {
    return Array.isArray(a) ? Na(a, b) >= 0 : a == b;
  };
  Cp.prototype.j = function () {
    return !1;
  };
  var rp = function (a, b) {
      var c = lp,
        d = pp(c.v, a.j),
        e = a.B;
      To[e] || (To[e] = new Ro(a, c, Zk(), d, b));
      return To[e];
    },
    zp = function () {
      var a = lp;
      a.o || (a.o = new yp());
      return a.o;
    },
    $o = function (a) {
      var b = Mi(),
        c = null;
      qd(b) ||
        md(
          b,
          function (d) {
            var e = new Ni();
            e.A = 2;
            e.g = u.parent;
            e.j = d;
            e.v = !1;
            if (E(H(e.j)))
              throw Error(
                "Cannot build secure channel: No secure token supplied."
              );
            if (2 == e.A) {
              if (null == e.g)
                throw Error(
                  "Cannot build secure channel: Must supply a peer window when requesting remote channel."
                );
              d = new Ri(e);
            } else d = new Oi(e);
            c = new Ti(d);
            c.connect();
          },
          a
        );
      return c;
    };
  var Ep = function () {
    Cp.call(this);
    this.g = null;
  };
  q(Ep, Cp);
  Ep.prototype.j = function (a) {
    var b;
    if ((b = a.B != ""))
      (b = Dp("BANNER", a.v)), (a = Dp("HTML5", a.A)), (b = b && a);
    return b;
  };
  var Fp = new Ep(),
    Gp = Fp.v;
  lp = Fp;
  mp = Gp;
  for (
    var Hp = document.getElementsByTagName("noscript"), Ip = 0;
    Ip < Hp.length;
    Ip++
  )
    Hp[Ip].style.display = "none";
  var Jp = y("studioV2.loadedLibraries.200_287.html_inpage");
  if (!Jp || !Jp.bootstrap) {
    v("studioV2.loadedLibraries.200_287.html_inpage.bootstrap", up);
    v("studioV2.loadedLibraries.200_287.html_inpage.unload", vp);
    var Kp;
    a: {
      var Lp = y("dclkStudioV3.renderingLibraries");
      if (Lp)
        for (var Mp = 0; Mp < Lp.length; ++Mp) {
          var Np = Lp[Mp];
          if (Np.version == "200_287" && Np.url.indexOf("/html_inpage") != -1) {
            Kp = Np;
            break a;
          }
        }
      Kp = null;
    }
    null !== Kp && ((Kp.bootstrapFunction = up), (Kp.unload = vp));
    Om = "html_inpage";
    var Op = Om === "undefined_type" ? null : Om + "_rendering_lib_200_287";
    if (
      Op != null &&
      !y("dclkStudioV3.rlErrorSampled") &&
      !y("studioV2.rlErrorSampled")
    ) {
      var Pp = new gp(Op);
      if (Pp.isActive()) {
        Pp.g = z(Pp.v, Pp);
        Pp.o = u;
        u.addEventListener("error", Pp.g);
        var bq = y("dclkStudioV3");
        bq ? (bq.Zd = Pp) : (y("studioV2").Zd = Pp);
      }
    }
    var cq = y("studioV2.defer");
    cq && typeof cq === "function" ? cq(up) : up();
  }
}.call(this));
