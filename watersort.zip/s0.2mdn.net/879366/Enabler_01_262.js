(function () {
  var DEPS_GRAPH = {
    enablermodule: [],
    configurablemodule: ["enablermodule"],
    gdnmodule: ["enablermodule"],
    layoutsmodule: ["enablermodule"],
    videomodule: ["enablermodule"],
    layoutsfillermodule: ["enablermodule", "layoutsmodule"],
    rad_ui_videomodule: ["videomodule"],
    $weak$: [
      "configurablemodule",
      "enablermodule",
      "gdnmodule",
      "layoutsfillermodule",
      "layoutsmodule",
      "rad_ui_videomodule",
      "videomodule",
    ],
  };
  window.STUDIO_SDK_START = +new Date();
  var h,
    aa = function (a) {
      var b = 0;
      return function () {
        return b < a.length ? { done: !1, value: a[b++] } : { done: !0 };
      };
    },
    ba =
      typeof Object.defineProperties == "function"
        ? Object.defineProperty
        : function (a, b, c) {
            if (a == Array.prototype || a == Object.prototype) return a;
            a[b] = c.value;
            return a;
          },
    ca = function (a) {
      a = [
        "object" == typeof globalThis && globalThis,
        a,
        "object" == typeof window && window,
        "object" == typeof self && self,
        "object" == typeof global && global,
      ];
      for (var b = 0; b < a.length; ++b) {
        var c = a[b];
        if (c && c.Math == Math) return c;
      }
      throw Error("Cannot find global object");
    },
    da = ca(this),
    k = function (a, b) {
      if (b)
        a: {
          var c = da;
          a = a.split(".");
          for (var d = 0; d < a.length - 1; d++) {
            var e = a[d];
            if (!(e in c)) break a;
            c = c[e];
          }
          a = a[a.length - 1];
          d = c[a];
          b = b(d);
          b != d &&
            b != null &&
            ba(c, a, { configurable: !0, writable: !0, value: b });
        }
    };
  k("Symbol", function (a) {
    if (a) return a;
    var b = function (f, g) {
      this.g = f;
      ba(this, "description", { configurable: !0, writable: !0, value: g });
    };
    b.prototype.toString = function () {
      return this.g;
    };
    var c = "jscomp_symbol_" + ((Math.random() * 1e9) >>> 0) + "_",
      d = 0,
      e = function (f) {
        if (this instanceof e)
          throw new TypeError("Symbol is not a constructor");
        return new b(c + (f || "") + "_" + d++, f);
      };
    return e;
  });
  k("Symbol.iterator", function (a) {
    if (a) return a;
    a = Symbol("Symbol.iterator");
    for (
      var b =
          "Array Int8Array Uint8Array Uint8ClampedArray Int16Array Uint16Array Int32Array Uint32Array Float32Array Float64Array".split(
            " "
          ),
        c = 0;
      c < b.length;
      c++
    ) {
      var d = da[b[c]];
      typeof d === "function" &&
        typeof d.prototype[a] != "function" &&
        ba(d.prototype, a, {
          configurable: !0,
          writable: !0,
          value: function () {
            return ea(aa(this));
          },
        });
    }
    return a;
  });
  var ea = function (a) {
      a = { next: a };
      a[Symbol.iterator] = function () {
        return this;
      };
      return a;
    },
    fa =
      typeof Object.create == "function"
        ? Object.create
        : function (a) {
            var b = function () {};
            b.prototype = a;
            return new b();
          },
    ha;
  if (typeof Object.setPrototypeOf == "function") ha = Object.setPrototypeOf;
  else {
    var ia;
    a: {
      var ja = { a: !0 },
        ka = {};
      try {
        ka.__proto__ = ja;
        ia = ka.a;
        break a;
      } catch (a) {}
      ia = !1;
    }
    ha = ia
      ? function (a, b) {
          a.__proto__ = b;
          if (a.__proto__ !== b) throw new TypeError(a + " is not extensible");
          return a;
        }
      : null;
  }
  var la = ha,
    p = function (a, b) {
      a.prototype = fa(b.prototype);
      a.prototype.constructor = a;
      if (la) la(a, b);
      else
        for (var c in b)
          if (c != "prototype")
            if (Object.defineProperties) {
              var d = Object.getOwnPropertyDescriptor(b, c);
              d && Object.defineProperty(a, c, d);
            } else a[c] = b[c];
      a.M = b.prototype;
    },
    ma = function (a) {
      var b =
        typeof Symbol != "undefined" && Symbol.iterator && a[Symbol.iterator];
      if (b) return b.call(a);
      if (typeof a.length == "number") return { next: aa(a) };
      throw Error(String(a) + " is not an iterable or ArrayLike");
    },
    oa = function (a) {
      return na(a, a);
    },
    na = function (a, b) {
      a.raw = b;
      Object.freeze && (Object.freeze(a), Object.freeze(b));
      return a;
    },
    pa = function (a, b) {
      return Object.prototype.hasOwnProperty.call(a, b);
    },
    ra =
      typeof Object.assign == "function"
        ? Object.assign
        : function (a, b) {
            if (a == null) throw new TypeError("No nullish arg");
            a = Object(a);
            for (var c = 1; c < arguments.length; c++) {
              var d = arguments[c];
              if (d) for (var e in d) pa(d, e) && (a[e] = d[e]);
            }
            return a;
          };
  k("Object.assign", function (a) {
    return a || ra;
  });
  var sa = function () {
      this.v = !1;
      this.h = null;
      this.o = void 0;
      this.g = 1;
      this.B = this.l = 0;
      this.j = null;
    },
    ta = function (a) {
      if (a.v) throw new TypeError("Generator is already running");
      a.v = !0;
    };
  sa.prototype.A = function (a) {
    this.o = a;
  };
  var ua = function (a, b) {
    a.j = { sc: b, we: !0 };
    a.g = a.l || a.B;
  };
  sa.prototype.return = function (a) {
    this.j = { return: a };
    this.g = this.B;
  };
  var va = function (a, b, c) {
      a.g = c;
      return { value: b };
    },
    wa = function (a) {
      a.l = 0;
      var b = a.j.sc;
      a.j = null;
      return b;
    },
    xa = function (a) {
      this.g = new sa();
      this.h = a;
    },
    Aa = function (a, b) {
      ta(a.g);
      var c = a.g.h;
      if (c)
        return ya(
          a,
          "return" in c
            ? c["return"]
            : function (d) {
                return { value: d, done: !0 };
              },
          b,
          a.g.return
        );
      a.g.return(b);
      return za(a);
    },
    ya = function (a, b, c, d) {
      try {
        var e = b.call(a.g.h, c);
        if (!(e instanceof Object))
          throw new TypeError("Iterator result " + e + " is not an object");
        if (!e.done) return (a.g.v = !1), e;
        var f = e.value;
      } catch (g) {
        return (a.g.h = null), ua(a.g, g), za(a);
      }
      a.g.h = null;
      d.call(a.g, f);
      return za(a);
    },
    za = function (a) {
      for (; a.g.g; )
        try {
          var b = a.h(a.g);
          if (b) return (a.g.v = !1), { value: b.value, done: !1 };
        } catch (c) {
          (a.g.o = void 0), ua(a.g, c);
        }
      a.g.v = !1;
      if (a.g.j) {
        b = a.g.j;
        a.g.j = null;
        if (b.we) throw b.sc;
        return { value: b.return, done: !0 };
      }
      return { value: void 0, done: !0 };
    },
    Ba = function (a) {
      this.next = function (b) {
        ta(a.g);
        a.g.h ? (b = ya(a, a.g.h.next, b, a.g.A)) : (a.g.A(b), (b = za(a)));
        return b;
      };
      this.throw = function (b) {
        ta(a.g);
        a.g.h
          ? (b = ya(a, a.g.h["throw"], b, a.g.A))
          : (ua(a.g, b), (b = za(a)));
        return b;
      };
      this.return = function (b) {
        return Aa(a, b);
      };
      this[Symbol.iterator] = function () {
        return this;
      };
    },
    Ca = function (a) {
      function b(d) {
        return a.next(d);
      }
      function c(d) {
        return a.throw(d);
      }
      return new Promise(function (d, e) {
        function f(g) {
          g.done ? d(g.value) : Promise.resolve(g.value).then(b, c).then(f, e);
        }
        f(a.next());
      });
    },
    Da = function (a) {
      return Ca(new Ba(new xa(a)));
    },
    Ea = function () {
      for (var a = Number(this), b = [], c = a; c < arguments.length; c++)
        b[c - a] = arguments[c];
      return b;
    };
  k("globalThis", function (a) {
    return a || da;
  });
  k("Promise", function (a) {
    function b() {
      this.g = null;
    }
    function c(g) {
      return g instanceof e
        ? g
        : new e(function (l) {
            l(g);
          });
    }
    if (a) return a;
    b.prototype.h = function (g) {
      if (this.g == null) {
        this.g = [];
        var l = this;
        this.j(function () {
          l.v();
        });
      }
      this.g.push(g);
    };
    var d = da.setTimeout;
    b.prototype.j = function (g) {
      d(g, 0);
    };
    b.prototype.v = function () {
      for (; this.g && this.g.length; ) {
        var g = this.g;
        this.g = [];
        for (var l = 0; l < g.length; ++l) {
          var m = g[l];
          g[l] = null;
          try {
            m();
          } catch (n) {
            this.l(n);
          }
        }
      }
      this.g = null;
    };
    b.prototype.l = function (g) {
      this.j(function () {
        throw g;
      });
    };
    var e = function (g) {
      this.g = 0;
      this.j = void 0;
      this.h = [];
      this.A = !1;
      var l = this.l();
      try {
        g(l.resolve, l.reject);
      } catch (m) {
        l.reject(m);
      }
    };
    e.prototype.l = function () {
      function g(n) {
        return function (q) {
          m || ((m = !0), n.call(l, q));
        };
      }
      var l = this,
        m = !1;
      return { resolve: g(this.ca), reject: g(this.v) };
    };
    e.prototype.ca = function (g) {
      if (g === this)
        this.v(new TypeError("A Promise cannot resolve to itself"));
      else if (g instanceof e) this.I(g);
      else {
        a: switch (typeof g) {
          case "object":
            var l = g != null;
            break a;
          case "function":
            l = !0;
            break a;
          default:
            l = !1;
        }
        l ? this.V(g) : this.o(g);
      }
    };
    e.prototype.V = function (g) {
      var l = void 0;
      try {
        l = g.then;
      } catch (m) {
        this.v(m);
        return;
      }
      typeof l == "function" ? this.J(l, g) : this.o(g);
    };
    e.prototype.v = function (g) {
      this.B(2, g);
    };
    e.prototype.o = function (g) {
      this.B(1, g);
    };
    e.prototype.B = function (g, l) {
      if (this.g != 0)
        throw Error(
          "Cannot settle(" +
            g +
            ", " +
            l +
            "): Promise already settled in state" +
            this.g
        );
      this.g = g;
      this.j = l;
      this.g === 2 && this.G();
      this.D();
    };
    e.prototype.G = function () {
      var g = this;
      d(function () {
        if (g.F()) {
          var l = da.console;
          typeof l !== "undefined" && l.error(g.j);
        }
      }, 1);
    };
    e.prototype.F = function () {
      if (this.A) return !1;
      var g = da.CustomEvent,
        l = da.Event,
        m = da.dispatchEvent;
      if (typeof m === "undefined") return !0;
      typeof g === "function"
        ? (g = new g("unhandledrejection", { cancelable: !0 }))
        : typeof l === "function"
        ? (g = new l("unhandledrejection", { cancelable: !0 }))
        : ((g = da.document.createEvent("CustomEvent")),
          g.initCustomEvent("unhandledrejection", !1, !0, g));
      g.promise = this;
      g.reason = this.j;
      return m(g);
    };
    e.prototype.D = function () {
      if (this.h != null) {
        for (var g = 0; g < this.h.length; ++g) f.h(this.h[g]);
        this.h = null;
      }
    };
    var f = new b();
    e.prototype.I = function (g) {
      var l = this.l();
      g.lb(l.resolve, l.reject);
    };
    e.prototype.J = function (g, l) {
      var m = this.l();
      try {
        g.call(l, m.resolve, m.reject);
      } catch (n) {
        m.reject(n);
      }
    };
    e.prototype.then = function (g, l) {
      function m(u, F) {
        return typeof u == "function"
          ? function (Y) {
              try {
                n(u(Y));
              } catch (qa) {
                q(qa);
              }
            }
          : F;
      }
      var n,
        q,
        t = new e(function (u, F) {
          n = u;
          q = F;
        });
      this.lb(m(g, n), m(l, q));
      return t;
    };
    e.prototype.catch = function (g) {
      return this.then(void 0, g);
    };
    e.prototype.lb = function (g, l) {
      function m() {
        switch (n.g) {
          case 1:
            g(n.j);
            break;
          case 2:
            l(n.j);
            break;
          default:
            throw Error("Unexpected state: " + n.g);
        }
      }
      var n = this;
      this.h == null ? f.h(m) : this.h.push(m);
      this.A = !0;
    };
    e.resolve = c;
    e.reject = function (g) {
      return new e(function (l, m) {
        m(g);
      });
    };
    e.race = function (g) {
      return new e(function (l, m) {
        for (var n = ma(g), q = n.next(); !q.done; q = n.next())
          c(q.value).lb(l, m);
      });
    };
    e.all = function (g) {
      var l = ma(g),
        m = l.next();
      return m.done
        ? c([])
        : new e(function (n, q) {
            function t(Y) {
              return function (qa) {
                u[Y] = qa;
                F--;
                F == 0 && n(u);
              };
            }
            var u = [],
              F = 0;
            do
              u.push(void 0),
                F++,
                c(m.value).lb(t(u.length - 1), q),
                (m = l.next());
            while (!m.done);
          });
    };
    return e;
  });
  k("Symbol.dispose", function (a) {
    return a ? a : Symbol("Symbol.dispose");
  });
  var Fa = function (a, b, c) {
    a instanceof String && (a = String(a));
    for (var d = a.length, e = 0; e < d; e++) {
      var f = a[e];
      if (b.call(c, f, e, a)) return { Gc: e, nd: f };
    }
    return { Gc: -1, nd: void 0 };
  };
  k("Array.prototype.find", function (a) {
    return a
      ? a
      : function (b, c) {
          return Fa(this, b, c).nd;
        };
  });
  k("WeakMap", function (a) {
    function b() {}
    function c(m) {
      var n = typeof m;
      return (n === "object" && m !== null) || n === "function";
    }
    function d(m) {
      if (!pa(m, f)) {
        var n = new b();
        ba(m, f, { value: n });
      }
    }
    function e(m) {
      var n = Object[m];
      n &&
        (Object[m] = function (q) {
          if (q instanceof b) return q;
          Object.isExtensible(q) && d(q);
          return n(q);
        });
    }
    if (
      (function () {
        if (!a || !Object.seal) return !1;
        try {
          var m = Object.seal({}),
            n = Object.seal({}),
            q = new a([
              [m, 2],
              [n, 3],
            ]);
          if (q.get(m) != 2 || q.get(n) != 3) return !1;
          q.delete(m);
          q.set(n, 4);
          return !q.has(m) && q.get(n) == 4;
        } catch (t) {
          return !1;
        }
      })()
    )
      return a;
    var f = "$jscomp_hidden_" + Math.random();
    e("freeze");
    e("preventExtensions");
    e("seal");
    var g = 0,
      l = function (m) {
        this.g = (g += Math.random() + 1).toString();
        if (m) {
          m = ma(m);
          for (var n; !(n = m.next()).done; )
            (n = n.value), this.set(n[0], n[1]);
        }
      };
    l.prototype.set = function (m, n) {
      if (!c(m)) throw Error("Invalid WeakMap key");
      d(m);
      if (!pa(m, f)) throw Error("WeakMap key fail: " + m);
      m[f][this.g] = n;
      return this;
    };
    l.prototype.get = function (m) {
      return c(m) && pa(m, f) ? m[f][this.g] : void 0;
    };
    l.prototype.has = function (m) {
      return c(m) && pa(m, f) && pa(m[f], this.g);
    };
    l.prototype.delete = function (m) {
      return c(m) && pa(m, f) && pa(m[f], this.g) ? delete m[f][this.g] : !1;
    };
    return l;
  });
  k("Map", function (a) {
    if (
      (function () {
        if (
          !a ||
          typeof a != "function" ||
          !a.prototype.entries ||
          typeof Object.seal != "function"
        )
          return !1;
        try {
          var l = Object.seal({ x: 4 }),
            m = new a(ma([[l, "s"]]));
          if (
            m.get(l) != "s" ||
            m.size != 1 ||
            m.get({ x: 4 }) ||
            m.set({ x: 4 }, "t") != m ||
            m.size != 2
          )
            return !1;
          var n = m.entries(),
            q = n.next();
          if (q.done || q.value[0] != l || q.value[1] != "s") return !1;
          q = n.next();
          return q.done ||
            q.value[0].x != 4 ||
            q.value[1] != "t" ||
            !n.next().done
            ? !1
            : !0;
        } catch (t) {
          return !1;
        }
      })()
    )
      return a;
    var b = new WeakMap(),
      c = function (l) {
        this[0] = {};
        this[1] = f();
        this.size = 0;
        if (l) {
          l = ma(l);
          for (var m; !(m = l.next()).done; )
            (m = m.value), this.set(m[0], m[1]);
        }
      };
    c.prototype.set = function (l, m) {
      l = l === 0 ? 0 : l;
      var n = d(this, l);
      n.list || (n.list = this[0][n.id] = []);
      n.entry
        ? (n.entry.value = m)
        : ((n.entry = {
            next: this[1],
            oa: this[1].oa,
            head: this[1],
            key: l,
            value: m,
          }),
          n.list.push(n.entry),
          (this[1].oa.next = n.entry),
          (this[1].oa = n.entry),
          this.size++);
      return this;
    };
    c.prototype.delete = function (l) {
      l = d(this, l);
      return l.entry && l.list
        ? (l.list.splice(l.index, 1),
          l.list.length || delete this[0][l.id],
          (l.entry.oa.next = l.entry.next),
          (l.entry.next.oa = l.entry.oa),
          (l.entry.head = null),
          this.size--,
          !0)
        : !1;
    };
    c.prototype.clear = function () {
      this[0] = {};
      this[1] = this[1].oa = f();
      this.size = 0;
    };
    c.prototype.has = function (l) {
      return !!d(this, l).entry;
    };
    c.prototype.get = function (l) {
      return (l = d(this, l).entry) && l.value;
    };
    c.prototype.entries = function () {
      return e(this, function (l) {
        return [l.key, l.value];
      });
    };
    c.prototype.keys = function () {
      return e(this, function (l) {
        return l.key;
      });
    };
    c.prototype.values = function () {
      return e(this, function (l) {
        return l.value;
      });
    };
    c.prototype.forEach = function (l, m) {
      for (var n = this.entries(), q; !(q = n.next()).done; )
        (q = q.value), l.call(m, q[1], q[0], this);
    };
    c.prototype[Symbol.iterator] = c.prototype.entries;
    var d = function (l, m) {
        var n = m && typeof m;
        n == "object" || n == "function"
          ? b.has(m)
            ? (n = b.get(m))
            : ((n = "" + ++g), b.set(m, n))
          : (n = "p_" + m);
        var q = l[0][n];
        if (q && pa(l[0], n))
          for (l = 0; l < q.length; l++) {
            var t = q[l];
            if ((m !== m && t.key !== t.key) || m === t.key)
              return { id: n, list: q, index: l, entry: t };
          }
        return { id: n, list: q, index: -1, entry: void 0 };
      },
      e = function (l, m) {
        var n = l[1];
        return ea(function () {
          if (n) {
            for (; n.head != l[1]; ) n = n.oa;
            for (; n.next != n.head; )
              return (n = n.next), { done: !1, value: m(n) };
            n = null;
          }
          return { done: !0, value: void 0 };
        });
      },
      f = function () {
        var l = {};
        return (l.oa = l.next = l.head = l);
      },
      g = 0;
    return c;
  });
  k("Object.values", function (a) {
    return a
      ? a
      : function (b) {
          var c = [],
            d;
          for (d in b) pa(b, d) && c.push(b[d]);
          return c;
        };
  });
  k("Object.is", function (a) {
    return a
      ? a
      : function (b, c) {
          return b === c ? b !== 0 || 1 / b === 1 / c : b !== b && c !== c;
        };
  });
  k("Array.prototype.includes", function (a) {
    return a
      ? a
      : function (b, c) {
          var d = this;
          d instanceof String && (d = String(d));
          var e = d.length;
          c = c || 0;
          for (c < 0 && (c = Math.max(c + e, 0)); c < e; c++) {
            var f = d[c];
            if (f === b || Object.is(f, b)) return !0;
          }
          return !1;
        };
  });
  var Ga = function (a, b, c) {
    if (a == null)
      throw new TypeError(
        "The 'this' value for String.prototype." +
          c +
          " must not be null or undefined"
      );
    if (b instanceof RegExp)
      throw new TypeError(
        "First argument to String.prototype." +
          c +
          " must not be a regular expression"
      );
    return a + "";
  };
  k("String.prototype.includes", function (a) {
    return a
      ? a
      : function (b, c) {
          return Ga(this, b, "includes").indexOf(b, c || 0) !== -1;
        };
  });
  k("Array.from", function (a) {
    return a
      ? a
      : function (b, c, d) {
          c =
            c != null
              ? c
              : function (l) {
                  return l;
                };
          var e = [],
            f =
              typeof Symbol != "undefined" &&
              Symbol.iterator &&
              b[Symbol.iterator];
          if (typeof f == "function") {
            b = f.call(b);
            for (var g = 0; !(f = b.next()).done; )
              e.push(c.call(d, f.value, g++));
          } else
            for (f = b.length, g = 0; g < f; g++) e.push(c.call(d, b[g], g));
          return e;
        };
  });
  k("Object.entries", function (a) {
    return a
      ? a
      : function (b) {
          var c = [],
            d;
          for (d in b) pa(b, d) && c.push([d, b[d]]);
          return c;
        };
  });
  k("Number.isFinite", function (a) {
    return a
      ? a
      : function (b) {
          return typeof b !== "number"
            ? !1
            : !isNaN(b) && b !== Infinity && b !== -Infinity;
        };
  });
  k("Number.MAX_SAFE_INTEGER", function () {
    return 9007199254740991;
  });
  k("Number.MIN_SAFE_INTEGER", function () {
    return -9007199254740991;
  });
  k("String.prototype.startsWith", function (a) {
    return a
      ? a
      : function (b, c) {
          var d = Ga(this, b, "startsWith");
          b += "";
          var e = d.length,
            f = b.length;
          c = Math.max(0, Math.min(c | 0, d.length));
          for (var g = 0; g < f && c < e; ) if (d[c++] != b[g++]) return !1;
          return g >= f;
        };
  });
  k("String.prototype.endsWith", function (a) {
    return a
      ? a
      : function (b, c) {
          var d = Ga(this, b, "endsWith");
          b += "";
          c === void 0 && (c = d.length);
          c = Math.max(0, Math.min(c | 0, d.length));
          for (var e = b.length; e > 0 && c > 0; )
            if (d[--c] != b[--e]) return !1;
          return e <= 0;
        };
  });
  var Ha = function (a, b) {
    a instanceof String && (a += "");
    var c = 0,
      d = !1,
      e = {
        next: function () {
          if (!d && c < a.length) {
            var f = c++;
            return { value: b(f, a[f]), done: !1 };
          }
          d = !0;
          return { done: !0, value: void 0 };
        },
      };
    e[Symbol.iterator] = function () {
      return e;
    };
    return e;
  };
  k("Array.prototype.entries", function (a) {
    return a
      ? a
      : function () {
          return Ha(this, function (b, c) {
            return [b, c];
          });
        };
  });
  k("Number.isNaN", function (a) {
    return a
      ? a
      : function (b) {
          return typeof b === "number" && isNaN(b);
        };
  });
  k("Array.prototype.keys", function (a) {
    return a
      ? a
      : function () {
          return Ha(this, function (b) {
            return b;
          });
        };
  });
  k("Array.prototype.values", function (a) {
    return a
      ? a
      : function () {
          return Ha(this, function (b, c) {
            return c;
          });
        };
  });
  k("Array.prototype.findIndex", function (a) {
    return a
      ? a
      : function (b, c) {
          return Fa(this, b, c).Gc;
        };
  }); /*

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/
  var r = this || self,
    v = function (a, b, c) {
      a = a.split(".");
      c = c || r;
      for (var d; a.length && (d = a.shift()); )
        a.length || b === void 0
          ? c[d] && c[d] !== Object.prototype[d]
            ? (c = c[d])
            : (c = c[d] = {})
          : (c[d] = b);
    },
    Ja = function (a, b) {
      var c = Ia("CLOSURE_FLAGS");
      a = c && c[a];
      return a != null ? a : b;
    },
    Ia = function (a, b) {
      a = a.split(".");
      b = b || r;
      for (var c = 0; c < a.length; c++)
        if (((b = b[a[c]]), b == null)) return null;
      return b;
    },
    Ka = function () {
      throw Error("unimplemented abstract method");
    },
    La = function (a) {
      a.Da = void 0;
      a.ob = function () {
        return a.Da ? a.Da : (a.Da = new a());
      };
    },
    Ma = function (a) {
      var b = typeof a;
      return b != "object" ? b : a ? (Array.isArray(a) ? "array" : b) : "null";
    },
    Na = function (a) {
      var b = Ma(a);
      return b == "array" || (b == "object" && typeof a.length == "number");
    },
    w = function (a) {
      var b = typeof a;
      return (b == "object" && a != null) || b == "function";
    },
    Qa = function (a) {
      return (
        (Object.prototype.hasOwnProperty.call(a, Oa) && a[Oa]) || (a[Oa] = ++Pa)
      );
    },
    Oa = "closure_uid_" + ((Math.random() * 1e9) >>> 0),
    Pa = 0,
    Ra = function (a, b, c) {
      return a.call.apply(a.bind, arguments);
    },
    Sa = function (a, b, c) {
      if (!a) throw Error();
      if (arguments.length > 2) {
        var d = Array.prototype.slice.call(arguments, 2);
        return function () {
          var e = Array.prototype.slice.call(arguments);
          Array.prototype.unshift.apply(e, d);
          return a.apply(b, e);
        };
      }
      return function () {
        return a.apply(b, arguments);
      };
    },
    x = function (a, b, c) {
      x =
        Function.prototype.bind &&
        Function.prototype.bind.toString().indexOf("native code") != -1
          ? Ra
          : Sa;
      return x.apply(null, arguments);
    },
    Ta = function (a, b) {
      var c = Array.prototype.slice.call(arguments, 1);
      return function () {
        var d = c.slice();
        d.push.apply(d, arguments);
        return a.apply(this, d);
      };
    },
    y = function (a, b) {
      function c() {}
      c.prototype = b.prototype;
      a.M = b.prototype;
      a.prototype = new c();
      a.prototype.constructor = a;
      a.fg = function (d, e, f) {
        for (
          var g = Array(arguments.length - 2), l = 2;
          l < arguments.length;
          l++
        )
          g[l - 2] = arguments[l];
        return b.prototype[e].apply(d, g);
      };
    };
  function Ua(a, b) {
    if (Error.captureStackTrace) Error.captureStackTrace(this, Ua);
    else {
      var c = Error().stack;
      c && (this.stack = c);
    }
    a && (this.message = String(a));
    b !== void 0 && (this.cause = b);
  }
  y(Ua, Error);
  Ua.prototype.name = "CustomError";
  var Va;
  function Wa(a) {
    r.setTimeout(function () {
      throw a;
    }, 0);
  }
  function Xa(a, b) {
    return a.lastIndexOf(b, 0) == 0;
  }
  function Ya(a) {
    return /^[\s\xa0]*$/.test(a);
  }
  var Za = String.prototype.trim
      ? function (a) {
          return a.trim();
        }
      : function (a) {
          return /^[\s\xa0]*([\s\S]*?)[\s\xa0]*$/.exec(a)[1];
        },
    $a = /&/g,
    ab = /</g,
    bb = />/g,
    cb = /"/g,
    db = /'/g,
    eb = /\x00/g,
    fb = /[\x00&<>"']/;
  function gb(a, b) {
    return a.indexOf(b) != -1;
  }
  function hb(a, b) {
    var c = 0;
    a = Za(String(a)).split(".");
    b = Za(String(b)).split(".");
    for (var d = Math.max(a.length, b.length), e = 0; c == 0 && e < d; e++) {
      var f = a[e] || "",
        g = b[e] || "";
      do {
        f = /(\d*)(\D*)(.*)/.exec(f) || ["", "", "", ""];
        g = /(\d*)(\D*)(.*)/.exec(g) || ["", "", "", ""];
        if (f[0].length == 0 && g[0].length == 0) break;
        c =
          ib(
            f[1].length == 0 ? 0 : parseInt(f[1], 10),
            g[1].length == 0 ? 0 : parseInt(g[1], 10)
          ) ||
          ib(f[2].length == 0, g[2].length == 0) ||
          ib(f[2], g[2]);
        f = f[3];
        g = g[3];
      } while (c == 0);
    }
    return c;
  }
  function ib(a, b) {
    return a < b ? -1 : a > b ? 1 : 0;
  }
  var jb = Ja(610401301, !1),
    kb = Ja(1331761403, !1),
    lb = Ja(748402147, Ja(1, !0));
  function mb() {
    var a = r.navigator;
    return a && (a = a.userAgent) ? a : "";
  }
  var nb,
    ob = r.navigator;
  nb = ob ? ob.userAgentData || null : null;
  function pb(a) {
    if (!jb || !nb) return !1;
    for (var b = 0; b < nb.brands.length; b++) {
      var c = nb.brands[b].brand;
      if (c && gb(c, a)) return !0;
    }
    return !1;
  }
  function z(a) {
    return gb(mb(), a);
  }
  function qb() {
    return jb ? !!nb && nb.brands.length > 0 : !1;
  }
  function rb() {
    return qb() ? !1 : z("Opera");
  }
  function sb() {
    return qb() ? !1 : z("Trident") || z("MSIE");
  }
  function tb() {
    return z("Firefox") || z("FxiOS");
  }
  function ub() {
    return qb()
      ? pb("Chromium")
      : ((z("Chrome") || z("CriOS")) && !(qb() ? 0 : z("Edge"))) || z("Silk");
  }
  function vb() {
    var a = mb();
    if (sb()) {
      var b = /rv: *([\d\.]*)/.exec(a);
      if (b && b[1]) a = b[1];
      else {
        b = "";
        var c = /MSIE +([\d\.]+)/.exec(a);
        if (c && c[1])
          if (((a = /Trident\/(\d.\d)/.exec(a)), c[1] == "7.0"))
            if (a && a[1])
              switch (a[1]) {
                case "4.0":
                  b = "8.0";
                  break;
                case "5.0":
                  b = "9.0";
                  break;
                case "6.0":
                  b = "10.0";
                  break;
                case "7.0":
                  b = "11.0";
              }
            else b = "7.0";
          else b = c[1];
        a = b;
      }
    } else a = "";
    return a;
  }
  function wb() {
    if (qb()) {
      var a = nb.brands.find(function (b) {
        return b.brand === "Internet Explorer";
      });
      if (!a || !a.version) return NaN;
      a = a.version.split(".");
    } else {
      a = vb();
      if (a === "") return NaN;
      a = a.split(".");
    }
    return a.length === 0 ? NaN : Number(a[0]);
  }
  function xb() {
    return z("iPhone") && !z("iPod") && !z("iPad");
  }
  function yb() {
    return xb() || z("iPad") || z("iPod");
  }
  var zb = Array.prototype.indexOf
      ? function (a, b) {
          return Array.prototype.indexOf.call(a, b, void 0);
        }
      : function (a, b) {
          if (typeof a === "string")
            return typeof b !== "string" || b.length != 1
              ? -1
              : a.indexOf(b, 0);
          for (var c = 0; c < a.length; c++) if (c in a && a[c] === b) return c;
          return -1;
        },
    A = Array.prototype.forEach
      ? function (a, b, c) {
          Array.prototype.forEach.call(a, b, c);
        }
      : function (a, b, c) {
          for (
            var d = a.length,
              e = typeof a === "string" ? a.split("") : a,
              f = 0;
            f < d;
            f++
          )
            f in e && b.call(c, e[f], f, a);
        },
    Ab = Array.prototype.filter
      ? function (a, b, c) {
          return Array.prototype.filter.call(a, b, c);
        }
      : function (a, b, c) {
          for (
            var d = a.length,
              e = [],
              f = 0,
              g = typeof a === "string" ? a.split("") : a,
              l = 0;
            l < d;
            l++
          )
            if (l in g) {
              var m = g[l];
              b.call(c, m, l, a) && (e[f++] = m);
            }
          return e;
        },
    Bb = Array.prototype.map
      ? function (a, b) {
          return Array.prototype.map.call(a, b, void 0);
        }
      : function (a, b) {
          for (
            var c = a.length,
              d = Array(c),
              e = typeof a === "string" ? a.split("") : a,
              f = 0;
            f < c;
            f++
          )
            f in e && (d[f] = b.call(void 0, e[f], f, a));
          return d;
        },
    Cb = Array.prototype.some
      ? function (a, b, c) {
          return Array.prototype.some.call(a, b, c);
        }
      : function (a, b, c) {
          for (
            var d = a.length,
              e = typeof a === "string" ? a.split("") : a,
              f = 0;
            f < d;
            f++
          )
            if (f in e && b.call(c, e[f], f, a)) return !0;
          return !1;
        };
  function Db(a) {
    var b = r.performance.getEntriesByType("resource");
    a = Eb(b, a);
    return a < 0 ? null : typeof b === "string" ? b.charAt(a) : b[a];
  }
  function Eb(a, b) {
    for (
      var c = a.length, d = typeof a === "string" ? a.split("") : a, e = 0;
      e < c;
      e++
    )
      if (e in d && b.call(void 0, d[e], e, a)) return e;
    return -1;
  }
  function Fb(a, b) {
    b = zb(a, b);
    var c;
    (c = b >= 0) && Gb(a, b);
    return c;
  }
  function Gb(a, b) {
    Array.prototype.splice.call(a, b, 1);
  }
  function Hb(a) {
    return Array.prototype.concat.apply([], arguments);
  }
  function Ib(a) {
    var b = a.length;
    if (b > 0) {
      for (var c = Array(b), d = 0; d < b; d++) c[d] = a[d];
      return c;
    }
    return [];
  }
  function Jb(a, b) {
    for (var c = 1; c < arguments.length; c++) {
      var d = arguments[c];
      if (Na(d)) {
        var e = a.length || 0,
          f = d.length || 0;
        a.length = e + f;
        for (var g = 0; g < f; g++) a[e + g] = d[g];
      } else a.push(d);
    }
  }
  function Kb(a, b, c, d) {
    Array.prototype.splice.apply(a, Lb(arguments, 1));
  }
  function Lb(a, b, c) {
    return arguments.length <= 2
      ? Array.prototype.slice.call(a, b)
      : Array.prototype.slice.call(a, b, c);
  }
  function Mb(a, b) {
    a.sort(b || Nb);
  }
  function Ob(a, b) {
    for (var c = Array(a.length), d = 0; d < a.length; d++)
      c[d] = { index: d, value: a[d] };
    var e = b || Nb;
    Mb(c, function (f, g) {
      return e(f.value, g.value) || f.index - g.index;
    });
    for (b = 0; b < a.length; b++) a[b] = c[b].value;
  }
  function Nb(a, b) {
    return a > b ? 1 : a < b ? -1 : 0;
  }
  var Pb = function (a) {
    Pb[" "](a);
    return a;
  };
  Pb[" "] = function () {};
  var Qb = rb(),
    Rb = sb(),
    Sb = z("Edge"),
    Tb =
      z("Gecko") &&
      !(gb(mb().toLowerCase(), "webkit") && !z("Edge")) &&
      !(z("Trident") || z("MSIE")) &&
      !z("Edge"),
    Ub = gb(mb().toLowerCase(), "webkit") && !z("Edge"),
    Vb;
  a: {
    var Wb = "",
      Xb = (function () {
        var a = mb();
        if (Tb) return /rv:([^\);]+)(\)|;)/.exec(a);
        if (Sb) return /Edge\/([\d\.]+)/.exec(a);
        if (Rb) return /\b(?:MSIE|rv)[: ]([^\);]+)(\)|;)/.exec(a);
        if (Ub) return /WebKit\/(\S+)/.exec(a);
        if (Qb) return /(?:Version)[ \/]?(\S+)/.exec(a);
      })();
    Xb && (Wb = Xb ? Xb[1] : "");
    if (Rb) {
      var Yb,
        Zb = r.document;
      Yb = Zb ? Zb.documentMode : void 0;
      if (Yb != null && Yb > parseFloat(Wb)) {
        Vb = String(Yb);
        break a;
      }
    }
    Vb = Wb;
  }
  var $b = Vb;
  var ac = tb(),
    bc = xb() || z("iPod"),
    cc = z("iPad"),
    dc = z("Android") && !(ub() || tb() || rb() || z("Silk")),
    ec = ub(),
    fc =
      z("Safari") &&
      !(
        ub() ||
        (qb() ? 0 : z("Coast")) ||
        rb() ||
        (qb() ? 0 : z("Edge")) ||
        (qb() ? pb("Microsoft Edge") : z("Edg/")) ||
        (qb() ? pb("Opera") : z("OPR")) ||
        tb() ||
        z("Silk") ||
        z("Android")
      ) &&
      !yb();
  function hc(a, b) {
    a.__closure__error__context__984382 ||
      (a.__closure__error__context__984382 = {});
    a.__closure__error__context__984382.severity = b;
  }
  var ic = void 0;
  var jc = typeof Symbol === "function" && typeof Symbol() === "symbol";
  function kc(a, b, c) {
    return typeof Symbol === "function" && typeof Symbol() === "symbol"
      ? (c === void 0 ? 0 : c) && Symbol.for && a
        ? Symbol.for(a)
        : a != null
        ? Symbol(a)
        : Symbol()
      : b;
  }
  var lc = kc("jas", void 0, !0),
    mc = kc(void 0, "0actk"),
    nc = kc("m_m", "hg", !0);
  var oc = { te: { value: 0, configurable: !0, writable: !0, enumerable: !1 } },
    pc = Object.defineProperties,
    B = jc ? lc : "te",
    qc,
    rc = [];
  sc(rc, 7);
  qc = Object.freeze(rc);
  function tc(a, b) {
    jc || B in a || pc(a, oc);
    a[B] |= b;
  }
  function sc(a, b) {
    jc || B in a || pc(a, oc);
    a[B] = b;
  }
  var uc = {};
  function vc(a, b) {
    return b === void 0
      ? a.h !== wc && !!(2 & (a.g[B] | 0))
      : !!(2 & b) && a.h !== wc;
  }
  var wc = {};
  var xc = typeof r.BigInt === "function" && typeof r.BigInt(0) === "bigint";
  var yc = Number.MIN_SAFE_INTEGER.toString(),
    zc = xc ? BigInt(Number.MIN_SAFE_INTEGER) : void 0,
    Ac = Number.MAX_SAFE_INTEGER.toString(),
    Bc = xc ? BigInt(Number.MAX_SAFE_INTEGER) : void 0;
  function Cc(a, b) {
    if (a.length > b.length) return !1;
    if (a.length < b.length || a === b) return !0;
    for (var c = 0; c < a.length; c++) {
      var d = a[c],
        e = b[c];
      if (d > e) return !1;
      if (d < e) return !0;
    }
  }
  var Dc = Number.isFinite;
  function Ec(a) {
    if (!Dc(a)) throw ((a = Error("enum")), hc(a, "warning"), a);
    return a | 0;
  }
  function Fc(a) {
    return a;
  }
  function Gc(a, b, c, d) {
    var e = d !== void 0;
    d = !!d;
    var f = [],
      g = a.length,
      l = 4294967295,
      m = !1,
      n = !!(b & 64),
      q = n ? (b & 128 ? 0 : -1) : void 0;
    if (!(b & 1)) {
      var t = g && a[g - 1];
      t != null && typeof t === "object" && t.constructor === Object
        ? (g--, (l = g))
        : (t = void 0);
      if (n && !(b & 128) && !e) {
        m = !0;
        var u;
        l = ((u = Hc) != null ? u : Fc)(l - q, q, a, t, void 0) + q;
      }
    }
    b = void 0;
    for (e = 0; e < g; e++)
      if (((u = a[e]), u != null && (u = c(u, d)) != null))
        if (n && e >= l) {
          var F = e - q,
            Y = void 0;
          ((Y = b) != null ? Y : (b = {}))[F] = u;
        } else f[e] = u;
    if (t)
      for (var qa in t)
        (a = t[qa]),
          a != null &&
            (a = c(a, d)) != null &&
            ((g = +qa),
            (e = void 0),
            n && !Number.isNaN(g) && (e = g + q) < l
              ? (f[e] = a)
              : ((g = void 0), (((g = b) != null ? g : (b = {}))[qa] = a)));
    b && (m ? f.push(b) : (f[l] = b));
    return f;
  }
  function Ic(a) {
    switch (typeof a) {
      case "number":
        return Number.isFinite(a) ? a : "" + a;
      case "bigint":
        return (xc ? a >= zc && a <= Bc : a[0] === "-" ? Cc(a, yc) : Cc(a, Ac))
          ? Number(a)
          : "" + a;
      case "boolean":
        return a ? 1 : 0;
      case "object":
        if (Array.isArray(a)) {
          var b = a[B] | 0;
          return a.length === 0 && b & 1 ? void 0 : Gc(a, b, Ic);
        }
        if (a != null && a[nc] === uc) return Jc(a);
        return;
    }
    return a;
  }
  var Kc =
      typeof structuredClone != "undefined"
        ? structuredClone
        : function (a) {
            return Gc(a, 0, Ic);
          },
    Hc;
  function Jc(a) {
    a = a.g;
    return Gc(a, a[B] | 0, Ic);
  }
  function Lc(a, b, c) {
    var d = d === void 0 ? 0 : d;
    if (a == null) {
      var e = 32;
      c ? ((a = [c]), (e |= 128)) : (a = []);
      b && (e = (e & -8380417) | ((b & 1023) << 13));
    } else {
      if (!Array.isArray(a)) throw Error("narr");
      e = a[B] | 0;
      if (lb && 1 & e) throw Error("rfarr");
      2048 & e && !(2 & e) && Mc();
      if (e & 256) throw Error("farr");
      if (e & 64) return d !== 0 || e & 2048 || sc(a, e | 2048), a;
      if (c && ((e |= 128), c !== a[0])) throw Error("mid");
      a: {
        c = a;
        e |= 64;
        var f = c.length;
        if (f) {
          var g = f - 1,
            l = c[g];
          if (l != null && typeof l === "object" && l.constructor === Object) {
            b = e & 128 ? 0 : -1;
            g -= b;
            if (g >= 1024) throw Error("pvtlmt");
            for (var m in l)
              (f = +m), f < g && ((c[f + b] = l[m]), delete l[m]);
            e = (e & -8380417) | ((g & 1023) << 13);
            break a;
          }
        }
        if (b) {
          m = Math.max(b, f - (e & 128 ? 0 : -1));
          if (m > 1024) throw Error("spvt");
          e = (e & -8380417) | ((m & 1023) << 13);
        }
      }
    }
    e |= 64;
    d === 0 && (e |= 2048);
    sc(a, e);
    return a;
  }
  function Mc() {
    if (lb) throw Error("carr");
    if (mc != null) {
      var a;
      var b = (a = ic) != null ? a : (ic = {});
      a = b[mc] || 0;
      a >= 5 || ((b[mc] = a + 1), (b = Error()), hc(b, "incident"), Wa(b));
    }
  }
  function Nc(a, b) {
    if (typeof a !== "object") return a;
    if (Array.isArray(a)) {
      var c = a[B] | 0;
      a.length === 0 && c & 1
        ? (a = void 0)
        : c & 2 ||
          (!b || 4096 & c || 16 & c
            ? (a = Oc(a, c, !1, b && !(c & 16)))
            : (tc(a, 34), c & 4 && Object.freeze(a)));
      return a;
    }
    if (a != null && a[nc] === uc)
      return (
        (b = a.g),
        (c = b[B] | 0),
        vc(a, c) ? a : Pc(a, b, c) ? Qc(a, b) : Oc(b, c)
      );
  }
  function Qc(a, b, c) {
    a = new a.constructor(b);
    c && (a.h = wc);
    a.j = wc;
    return a;
  }
  function Oc(a, b, c, d) {
    d != null || (d = !!(34 & b));
    a = Gc(a, b, Nc, d);
    d = 32;
    c && (d |= 2);
    b = (b & 8380609) | d;
    sc(a, b);
    return a;
  }
  function Rc(a) {
    if (a.h !== wc) return !1;
    var b = a.g;
    b = Oc(b, b[B] | 0);
    tc(b, 2048);
    a.g = b;
    a.h = void 0;
    a.j = void 0;
    return !0;
  }
  function Sc(a) {
    if (!Rc(a) && vc(a, a.g[B] | 0)) throw Error();
  }
  function Tc(a, b) {
    b === void 0 && (b = a[B] | 0);
    b & 32 && !(b & 4096) && sc(a, b | 4096);
  }
  function Pc(a, b, c) {
    return c & 2
      ? !0
      : c & 32 && !(c & 4096)
      ? (sc(b, c | 2), (a.h = wc), !0)
      : !1;
  }
  var Uc = function (a, b, c) {
    if (b === -1) return null;
    var d = b + -1,
      e = a.length - 1;
    if (!(e < 0)) {
      if (d >= e) {
        var f = a[e];
        if (f != null && typeof f === "object" && f.constructor === Object) {
          e = f[b];
          var g = !0;
        } else if (d === e) e = f;
        else return;
      } else e = a[d];
      if (c && e != null) {
        c = c(e);
        if (c == null) return c;
        if (!Object.is(c, e)) return g ? (f[b] = c) : (a[d] = c), c;
      }
      return e;
    }
  };
  function Vc(a, b, c, d) {
    var e = c + -1,
      f = a.length - 1;
    if (f >= 0 && e >= f) {
      var g = a[f];
      if (g != null && typeof g === "object" && g.constructor === Object)
        return (g[c] = d), b;
    }
    if (e <= f) return (a[e] = d), b;
    if (d !== void 0) {
      var l;
      f = (((l = b) != null ? l : (b = a[B] | 0)) >> 13) & 1023 || 536870912;
      c >= f
        ? d != null && ((e = {}), (a[f + -1] = ((e[c] = d), e)))
        : (a[e] = d);
    }
    return b;
  }
  function Wc(a) {
    return (!!(2 & a) && !!(4 & a)) || !!(256 & a);
  }
  function Xc(a, b, c) {
    var d = !1,
      e = Uc(a, 1, function (f) {
        if (f != null && f[nc] === uc) var g = f;
        else if (Array.isArray(f)) {
          g = f[B] | 0;
          var l = g | (b & 32);
          l |= b & 2;
          l !== g && sc(f, l);
          g = new c(f);
        } else g = void 0;
        d = g !== f && g != null;
        return g;
      });
    if (e != null) return d && !vc(e) && Tc(a, b), e;
  }
  var Yc = function (a, b) {
    var c = a.g,
      d = c[B] | 0;
    b = Xc(c, d, b);
    if (b == null) return b;
    d = c[B] | 0;
    if (!vc(a, d)) {
      var e = b;
      var f = e.g,
        g = f[B] | 0;
      e = vc(e, g)
        ? Pc(e, f, g)
          ? Qc(e, f, !0)
          : new e.constructor(Oc(f, g, !1))
        : e;
      e !== b &&
        (Rc(a) && ((c = a.g), (d = c[B] | 0)),
        (b = e),
        (d = Vc(c, d, 1, b)),
        Tc(c, d));
    }
    return b;
  };
  function Zc(a, b) {
    return (a = (2 & b ? a | 2 : a & -3) & -273);
  }
  var $c = function (a, b, c) {
    this.g = Lc(a, b, c);
  };
  $c.prototype.toJSON = function () {
    return Jc(this);
  };
  $c.prototype[nc] = uc;
  $c.prototype.toString = function () {
    return this.g.toString();
  };
  function ad(a, b) {
    if (b == null) return new a();
    if (!Array.isArray(b)) throw Error();
    if (Object.isFrozen(b) || Object.isSealed(b) || !Object.isExtensible(b))
      throw Error();
    tc(b, 32);
    return new a(b);
  }
  [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce(function (
    a,
    b
  ) {
    return a + b;
  });
  [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce(function (a, b) {
    return a + b;
  });
  [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce(function (
    a,
    b
  ) {
    return a + b;
  });
  [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce(function (
    a,
    b
  ) {
    return a + b;
  });
  [
    2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
    2, 2, 2, 2, 2, 2, 2,
  ].reduce(function (a, b) {
    return a + b;
  });
  [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce(function (a, b) {
    return a + b;
  });
  function bd(a, b, c) {
    for (var d in a) b.call(c, a[d], d, a);
  }
  function cd(a, b) {
    for (var c in a) if (b.call(void 0, a[c], c, a)) break;
  }
  function dd(a) {
    var b = 0,
      c;
    for (c in a) b++;
    return b;
  }
  function ed(a) {
    var b = [],
      c = 0,
      d;
    for (d in a) b[c++] = a[d];
    return b;
  }
  function fd(a, b) {
    var c = Na(b),
      d = c ? b : arguments;
    for (c = c ? 0 : 1; c < d.length; c++) {
      if (a == null) return;
      a = a[d[c]];
    }
    return a;
  }
  function gd(a, b) {
    return a !== null && b in a ? a[b] : void 0;
  }
  function hd(a, b, c) {
    b in a || (a[b] = c);
  }
  function jd(a) {
    var b = {},
      c;
    for (c in a) b[c] = a[c];
    return b;
  }
  var kd =
    "constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(
      " "
    );
  function ld(a, b) {
    for (var c, d, e = 1; e < arguments.length; e++) {
      d = arguments[e];
      for (c in d) a[c] = d[c];
      for (var f = 0; f < kd.length; f++)
        (c = kd[f]),
          Object.prototype.hasOwnProperty.call(d, c) && (a[c] = d[c]);
    }
  }
  var md = function (a) {
    this.g = Lc(a);
  };
  p(md, $c);
  var nd = function (a) {
    var b = new md();
    Sc(b);
    var c = b.g,
      d = c[B] | 0;
    var e = vc(b, d) ? 1 : 2;
    e === 2 && Rc(b) && ((c = b.g), (d = c[B] | 0));
    b = Uc(c, 1);
    var f = Array.isArray(b) ? b : qc;
    var g = f === qc ? 7 : f[B] | 0;
    b = g;
    2 & d && (b |= 2);
    var l = b | 1;
    b = 4 & l ? !1 : !0;
    if (b) {
      4 & l &&
        ((f = Array.prototype.slice.call(f)),
        (g = 0),
        (l = Zc(l, d)),
        (d = Vc(c, d, 1, f)));
      for (var m = 0, n = 0; m < f.length; m++) {
        var q = f[m];
        q = q == null ? q : Dc(q) ? q | 0 : void 0;
        q != null && (f[n++] = q);
      }
      n < m && (f.length = n);
      l = (l | 4) & -513;
      l &= -1025;
      l &= -4097;
    }
    l !== g && (sc(f, l), 2 & l && Object.freeze(f));
    l = g = l;
    e === 1 || (e !== 4 ? 0 : 2 & g || (!(16 & g) && 32 & d))
      ? Wc(g) ||
        ((g |=
          !f.length || (b && !(4096 & g)) || (32 & d && !(4096 & g || 16 & g))
            ? 2
            : 256),
        g !== l && sc(f, g),
        Object.freeze(f))
      : (e === 2 &&
          Wc(g) &&
          ((f = Array.prototype.slice.call(f)),
          (l = 0),
          (g = Zc(g, d)),
          (d = Vc(c, d, 1, f))),
        Wc(g) || (g !== l && sc(f, g)));
    2 & g || !(4096 & g || 16 & g) || Tc(c, d);
    e = f;
    if (Array.isArray(a))
      for (d = a.length, c = 0; c < d; c++) e.push(Ec(a[c]));
    else
      for (a = ma(a), d = a.next(); !d.done; d = a.next()) e.push(Ec(d.value));
  };
  function od(a) {
    var b = !1;
    b = b === void 0 ? !1 : b;
    var c = c === void 0 ? r : c;
    for (var d = 0; c && d++ < 40; ) {
      var e;
      if (!(e = b))
        try {
          var f;
          if ((f = !!c && c.location.href != null))
            b: {
              try {
                Pb(c.foo);
                f = !0;
                break b;
              } catch (l) {}
              f = !1;
            }
          e = f;
        } catch (l) {
          e = !1;
        }
      if (e && a(c)) break;
      a: {
        try {
          var g = c.parent;
          if (g && g != c) {
            c = g;
            break a;
          }
        } catch (l) {}
        c = null;
      }
    }
  }
  var pd = function () {}; /*

 Copyright Google LLC
 SPDX-License-Identifier: Apache-2.0
*/
  var qd = globalThis.trustedTypes,
    rd;
  function sd() {
    var a = null;
    if (!qd) return a;
    try {
      var b = function (c) {
        return c;
      };
      a = qd.createPolicy("goog#html", {
        createHTML: b,
        createScript: b,
        createScriptURL: b,
      });
    } catch (c) {}
    return a;
  }
  function td() {
    rd === void 0 && (rd = sd());
    return rd;
  }
  var ud = function (a) {
    this.g = a;
  };
  ud.prototype.toString = function () {
    return this.g + "";
  };
  function vd(a) {
    var b = td();
    a = b ? b.createScriptURL(a) : a;
    return new ud(a);
  }
  function wd(a) {
    if (a instanceof ud) return a.g;
    throw Error("");
  }
  var xd = function (a) {
    this.g = a;
  };
  xd.prototype.toString = function () {
    return this.g;
  };
  var yd = new xd("about:invalid#zClosurez");
  function zd(a) {
    if (a instanceof xd) return a.g;
    throw Error("");
  }
  var Ad = function (a) {
    this.Ae = a;
  };
  function Bd(a) {
    return new Ad(function (b) {
      return b.substr(0, a.length + 1).toLowerCase() === a + ":";
    });
  }
  var Cd = [
      Bd("data"),
      Bd("http"),
      Bd("https"),
      Bd("mailto"),
      Bd("ftp"),
      new Ad(function (a) {
        return /^[^:]*([/?#]|$)/.test(a);
      }),
    ],
    Dd = /^\s*(?!javascript:)(?:[\w+.-]+:|[^:/?#]*(?:[/?#]|$))/i;
  function Ed(a) {
    a instanceof xd ? (a = zd(a)) : (a = Dd.test(a) ? a : void 0);
    return a;
  }
  var Fd = function (a) {
    this.g = a;
  };
  Fd.prototype.toString = function () {
    return this.g + "";
  };
  function Gd(a, b, c, d) {
    b = Ed(b);
    return b !== void 0 ? a.open(b, c, d) : null;
  }
  function Hd(a, b) {
    b = b === void 0 ? document : b;
    var c, d;
    b = (d = (c = b).querySelector) == null ? void 0 : d.call(c, a + "[nonce]");
    return b == null ? "" : b.nonce || b.getAttribute("nonce") || "";
  }
  function Id(a, b) {
    a.src = wd(b);
    (b = Hd("script", a.ownerDocument)) && a.setAttribute("nonce", b);
  }
  var Jd = function (a) {
    this.g = a;
  };
  Jd.prototype.toString = function () {
    return this.g;
  };
  var Kd = function (a) {
      return decodeURIComponent(a.replace(/\+/g, " "));
    },
    Ld = function (a, b) {
      var c = a;
      0 < a.length && b > 0 && (c = a.slice(0, 0) + a.slice(0 + b));
      return c;
    },
    Md = function (a) {
      return a == null ? "" : String(a);
    },
    Nd = function (a) {
      for (var b = 0, c = 0; c < a.length; ++c)
        b = (31 * b + a.charCodeAt(c)) >>> 0;
      return b;
    },
    Od = function (a) {
      return String(a).replace(/\-([a-z])/g, function (b, c) {
        return c.toUpperCase();
      });
    },
    Pd = function (a) {
      return a.replace(RegExp("(^|[\\s]+)([a-z])", "g"), function (b, c, d) {
        return c + d.toUpperCase();
      });
    };
  function Qd(a) {
    for (var b = Ea.apply(1, arguments), c = a[0], d = 0; d < a.length - 1; d++)
      (c += String(b[d])), (c += a[d + 1]);
    b = document.implementation.createHTMLDocument("");
    d = b.createElement("style");
    b.head.appendChild(d);
    b = d.sheet;
    b.insertRule(c, 0);
    if (
      b.cssRules.length === 1 &&
      ((c = b.cssRules[0]), c instanceof CSSStyleRule)
    )
      return (c = c.cssText.replace(/</g, "\\3C ")), new Jd(c);
  }
  function Rd(a) {
    var b = Ea.apply(1, arguments);
    if (b.length === 0) return vd(a[0]);
    for (var c = a[0], d = 0; d < b.length; d++)
      c += encodeURIComponent(b[d]) + a[d + 1];
    return vd(c);
  }
  function Sd(a, b, c, d) {
    function e(g, l) {
      g != null &&
        (Array.isArray(g)
          ? g.forEach(function (m) {
              return e(m, l);
            })
          : ((b += f + encodeURIComponent(l) + "=" + encodeURIComponent(g)),
            (f = "&")));
    }
    var f = b.length ? "&" : "?";
    d.constructor === Object && (d = Object.entries(d));
    Array.isArray(d)
      ? d.forEach(function (g) {
          return e(g[1], g[0]);
        })
      : d.forEach(e);
    return vd(a + b + c);
  }
  var Td = function (a, b) {
    b = b === void 0 ? document : b;
    return b.createElement(String(a).toLowerCase());
  };
  var Ud = (function () {
    if (!r.addEventListener || !Object.defineProperty) return !1;
    var a = !1,
      b = Object.defineProperty({}, "passive", {
        get: function () {
          a = !0;
        },
      });
    try {
      var c = function () {};
      r.addEventListener("test", c, b);
      r.removeEventListener("test", c, b);
    } catch (d) {}
    return a;
  })();
  var Vd = function (a, b) {
    this.width = a;
    this.height = b;
  };
  Vd.prototype.aspectRatio = function () {
    return this.width / this.height;
  };
  Vd.prototype.ceil = function () {
    this.width = Math.ceil(this.width);
    this.height = Math.ceil(this.height);
    return this;
  };
  Vd.prototype.floor = function () {
    this.width = Math.floor(this.width);
    this.height = Math.floor(this.height);
    return this;
  };
  Vd.prototype.round = function () {
    this.width = Math.round(this.width);
    this.height = Math.round(this.height);
    return this;
  };
  var Yd = function (a) {
      return a ? new Wd(Xd(a)) : Va || (Va = new Wd());
    },
    $d = function (a, b) {
      bd(b, function (c, d) {
        d == "style"
          ? (a.style.cssText = c)
          : d == "class"
          ? (a.className = c)
          : d == "for"
          ? (a.htmlFor = c)
          : Zd.hasOwnProperty(d)
          ? a.setAttribute(Zd[d], c)
          : Xa(d, "aria-") || Xa(d, "data-")
          ? a.setAttribute(d, c)
          : (a[d] = c);
      });
    },
    Zd = {
      cellpadding: "cellPadding",
      cellspacing: "cellSpacing",
      colspan: "colSpan",
      frameborder: "frameBorder",
      height: "height",
      maxlength: "maxLength",
      nonce: "nonce",
      role: "role",
      rowspan: "rowSpan",
      type: "type",
      usemap: "useMap",
      valign: "vAlign",
      width: "width",
    },
    ae = function () {
      var a = window.document;
      a = a.compatMode == "CSS1Compat" ? a.documentElement : a.body;
      return new Vd(a.clientWidth, a.clientHeight);
    },
    C = function (a, b, c) {
      return be(document, arguments);
    },
    be = function (a, b) {
      var c = b[1],
        d = ce(a, String(b[0]));
      c &&
        (typeof c === "string"
          ? (d.className = c)
          : Array.isArray(c)
          ? (d.className = c.join(" "))
          : $d(d, c));
      b.length > 2 && de(a, d, b, 2);
      return d;
    },
    de = function (a, b, c, d) {
      function e(l) {
        l && b.appendChild(typeof l === "string" ? a.createTextNode(l) : l);
      }
      for (; d < c.length; d++) {
        var f = c[d];
        if (!Na(f) || (w(f) && f.nodeType > 0)) e(f);
        else {
          a: {
            if (f && typeof f.length == "number") {
              if (w(f)) {
                var g =
                  typeof f.item == "function" || typeof f.item == "string";
                break a;
              }
              if (typeof f === "function") {
                g = typeof f.item == "function";
                break a;
              }
            }
            g = !1;
          }
          A(g ? Ib(f) : f, e);
        }
      }
    },
    ce = function (a, b) {
      b = String(b);
      a.contentType === "application/xhtml+xml" && (b = b.toLowerCase());
      return a.createElement(b);
    },
    ee = function (a, b) {
      a.appendChild(b);
    },
    fe = function (a, b) {
      de(Xd(a), a, arguments, 1);
    },
    ge = function (a) {
      for (var b; (b = a.firstChild); ) a.removeChild(b);
    },
    he = function (a) {
      return a && a.parentNode ? a.parentNode.removeChild(a) : null;
    },
    Xd = function (a) {
      return a.nodeType == 9 ? a : a.ownerDocument || a.document;
    },
    ie = function (a, b) {
      a && (a = a.parentNode);
      for (var c = 0; a; ) {
        if (b(a)) return a;
        a = a.parentNode;
        c++;
      }
      return null;
    },
    Wd = function (a) {
      this.g = a || r.document || document;
    };
  Wd.prototype.getElement = function (a) {
    var b = this.g;
    return typeof a === "string" ? b.getElementById(a) : a;
  };
  var je = function (a, b) {
    a = a.g;
    return (b = b && b != "*" ? String(b).toUpperCase() : "")
      ? a.querySelectorAll(b + "")
      : a.getElementsByTagName("*");
  };
  Wd.prototype.h = function (a, b, c) {
    return be(this.g, arguments);
  };
  var ke = function (a, b) {
    return ce(a.g, b);
  };
  Wd.prototype.j = ee;
  Wd.prototype.contains = function (a, b) {
    if (!a || !b) return !1;
    if (a.contains && b.nodeType == 1) return a == b || a.contains(b);
    if (typeof a.compareDocumentPosition != "undefined")
      return a == b || !!(a.compareDocumentPosition(b) & 16);
    for (; b && a != b; ) b = b.parentNode;
    return b == a;
  };
  var me = function (a, b, c) {
      if (typeof b === "string") (b = le(a, b)) && (a.style[b] = c);
      else
        for (var d in b) {
          c = a;
          var e = b[d],
            f = le(c, d);
          f && (c.style[f] = e);
        }
    },
    ne = {},
    le = function (a, b) {
      var c = ne[b];
      if (!c) {
        var d = Od(b);
        c = d;
        a.style[d] === void 0 &&
          ((d = (Ub ? "Webkit" : Tb ? "Moz" : null) + Pd(d)),
          a.style[d] !== void 0 && (c = d));
        ne[b] = c;
      }
      return c;
    },
    oe = function (a) {
      typeof a == "number" && (a = Math.round(a) + "px");
      return a;
    },
    pe = function (a) {
      var b = a.offsetWidth,
        c = a.offsetHeight,
        d = Ub && !b && !c;
      if ((b === void 0 || d) && a.getBoundingClientRect) {
        try {
          var e = a.getBoundingClientRect();
        } catch (f) {
          e = { left: 0, top: 0, right: 0, bottom: 0 };
        }
        a = e;
        return new Vd(a.right - a.left, a.bottom - a.top);
      }
      return new Vd(b, c);
    },
    qe = function (a) {
      var b = Yd(),
        c = je(b, "HEAD")[0];
      if (!c) {
        var d = je(b, "BODY")[0];
        c = b.h("HEAD");
        d.parentNode.insertBefore(c, d);
      }
      d = b.h("STYLE");
      var e;
      (e = Hd("style", document)) && d.setAttribute("nonce", e);
      if (a instanceof Jd) a = a.g;
      else throw Error("");
      if (r.trustedTypes)
        if ("textContent" in d) d.textContent = a;
        else if (d.nodeType == 3) d.data = String(a);
        else if (d.firstChild && d.firstChild.nodeType == 3) {
          for (; d.lastChild != d.firstChild; ) d.removeChild(d.lastChild);
          d.firstChild.data = String(a);
        } else ge(d), d.appendChild(Xd(d).createTextNode(String(a)));
      else d.innerHTML = a;
      b.j(c, d);
      return d;
    },
    re = function (a) {
      he(a.ownerNode || a.owningElement || a);
    },
    se = function (a) {
      a = a.style;
      a.position = "relative";
      a.display = "inline-block";
    };
  function te(a, b) {
    typeof a.addEventListener === "function" &&
      a.addEventListener.call(a, "load", b, !1);
  }
  function D(a) {
    a && typeof a.dispose == "function" && a.dispose();
  }
  function ue(a) {
    for (var b = 0, c = arguments.length; b < c; ++b) {
      var d = arguments[b];
      Na(d) ? ue.apply(null, d) : D(d);
    }
  }
  var E = function () {
    this.ca = this.ca;
    this.V = this.V;
  };
  E.prototype.ca = !1;
  E.prototype.isDisposed = function () {
    return this.ca;
  };
  E.prototype.dispose = function () {
    this.ca || ((this.ca = !0), this.C());
  };
  E.prototype[Symbol.dispose] = function () {
    this.dispose();
  };
  var ve = function (a, b) {
    b = Ta(D, b);
    a.ca ? b() : (a.V || (a.V = []), a.V.push(b));
  };
  E.prototype.C = function () {
    if (this.V) for (; this.V.length; ) this.V.shift()();
  };
  var we = function (a, b, c, d, e, f, g) {
      var l = "";
      a && (l += a + ":");
      c && ((l += "//"), b && (l += b + "@"), (l += c), d && (l += ":" + d));
      e && (l += e);
      f && (l += "?" + f);
      g && (l += "#" + g);
      return l;
    },
    xe = RegExp(
      "^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$"
    ),
    ye = function (a) {
      var b = a.indexOf("#");
      return b < 0 ? null : a.slice(b + 1);
    },
    ze = function (a) {
      a = a.match(xe);
      return we(a[1], a[2], a[3], a[4]);
    },
    Be = function (a, b) {
      if (a) {
        a = a.split("&");
        for (var c = 0; c < a.length; c++) {
          var d = a[c].indexOf("="),
            e = null;
          if (d >= 0) {
            var f = a[c].substring(0, d);
            e = a[c].substring(d + 1);
          } else f = a[c];
          b(f, e ? Kd(e) : "");
        }
      }
    },
    Ce = /#|$/,
    De = function (a, b) {
      var c = a.search(Ce);
      a: {
        var d = 0;
        for (var e = b.length; (d = a.indexOf(b, d)) >= 0 && d < c; ) {
          var f = a.charCodeAt(d - 1);
          if (f == 38 || f == 63)
            if (
              ((f = a.charCodeAt(d + e)), !f || f == 61 || f == 38 || f == 35)
            )
              break a;
          d += e + 1;
        }
        d = -1;
      }
      if (d < 0) return null;
      e = a.indexOf("&", d);
      if (e < 0 || e > c) e = c;
      d += b.length + 1;
      return Kd(a.slice(d, e !== -1 ? e : 0));
    };
  nd([1, 8, 9, 10, 11, 12, 2, 3, 4, 5, 15, 16, 19, 20, 21, 23]);
  nd([1, 6, 7, 9, 10, 11, 12, 2, 3, 4, 5, 13, 14, 18, 19, 20, 21, 23]);
  nd([1, 6, 7, 9, 10, 11, 12, 22, 2, 3, 4, 5, 13, 14, 17, 18, 19, 20, 21, 23]);
  new md();
  var Ee = function (a) {
      return a.T && typeof a.T == "function"
        ? a.T()
        : Na(a) || typeof a === "string"
        ? a.length
        : dd(a);
    },
    Fe = function (a) {
      if (a.U && typeof a.U == "function") return a.U();
      if (
        (typeof Map !== "undefined" && a instanceof Map) ||
        (typeof Set !== "undefined" && a instanceof Set)
      )
        return Array.from(a.values());
      if (typeof a === "string") return a.split("");
      if (Na(a)) {
        for (var b = [], c = a.length, d = 0; d < c; d++) b.push(a[d]);
        return b;
      }
      return ed(a);
    },
    Ge = function (a) {
      if (a.Ba && typeof a.Ba == "function") return a.Ba();
      if (!a.U || typeof a.U != "function") {
        if (typeof Map !== "undefined" && a instanceof Map)
          return Array.from(a.keys());
        if (!(typeof Set !== "undefined" && a instanceof Set)) {
          if (Na(a) || typeof a === "string") {
            var b = [];
            a = a.length;
            for (var c = 0; c < a; c++) b.push(c);
            return b;
          }
          b = [];
          c = 0;
          for (var d in a) b[c++] = d;
          return b;
        }
      }
    },
    He = function (a, b) {
      if (a.contains && typeof a.contains == "function") a = a.contains(b);
      else if (a.Sa && typeof a.Sa == "function") a = a.Sa(b);
      else if (Na(a) || typeof a === "string") a = zb(a, b) >= 0;
      else
        a: {
          for (var c in a)
            if (a[c] == b) {
              a = !0;
              break a;
            }
          a = !1;
        }
      return a;
    },
    Ie = function (a, b, c) {
      if (typeof a.every == "function") return a.every(b, c);
      if (Na(a) || typeof a === "string")
        return Array.prototype.every.call(a, b, c);
      for (var d = Ge(a), e = Fe(a), f = e.length, g = 0; g < f; g++)
        if (!b.call(c, e[g], d && d[g], a)) return !1;
      return !0;
    };
  var Je = function (a) {
    this.j = this.A = this.l = "";
    this.B = null;
    this.o = this.g = "";
    this.v = !1;
    var b;
    a instanceof Je
      ? ((this.v = a.v),
        Ke(this, a.l),
        (this.A = a.A),
        (this.j = a.j),
        Le(this, a.B),
        (this.g = a.g),
        Me(this, Ne(a.h)),
        (this.o = a.o))
      : a && (b = String(a).match(xe))
      ? ((this.v = !1),
        Ke(this, b[1] || "", !0),
        (this.A = Oe(b[2] || "")),
        (this.j = Oe(b[3] || "", !0)),
        Le(this, b[4]),
        (this.g = Oe(b[5] || "", !0)),
        Me(this, b[6] || "", !0),
        (this.o = Oe(b[7] || "")))
      : ((this.v = !1), (this.h = new Pe(null, this.v)));
  };
  Je.prototype.toString = function () {
    var a = [],
      b = this.l;
    b && a.push(Qe(b, Re, !0), ":");
    var c = this.j;
    if (c || b == "file")
      a.push("//"),
        (b = this.A) && a.push(Qe(b, Re, !0), "@"),
        a.push(
          encodeURIComponent(String(c)).replace(/%25([0-9a-fA-F]{2})/g, "%$1")
        ),
        (c = this.B),
        c != null && a.push(":", String(c));
    if ((c = this.g))
      this.j && c.charAt(0) != "/" && a.push("/"),
        a.push(Qe(c, c.charAt(0) == "/" ? Se : Te, !0));
    (c = this.h.toString()) && a.push("?", c);
    (c = this.o) && a.push("#", Qe(c, Ue));
    return a.join("");
  };
  Je.prototype.resolve = function (a) {
    var b = new Je(this),
      c = !!a.l;
    c ? Ke(b, a.l) : (c = !!a.A);
    c ? (b.A = a.A) : (c = !!a.j);
    c ? (b.j = a.j) : (c = a.B != null);
    var d = a.g;
    if (c) Le(b, a.B);
    else if ((c = !!a.g)) {
      if (d.charAt(0) != "/")
        if (this.j && !this.g) d = "/" + d;
        else {
          var e = b.g.lastIndexOf("/");
          e != -1 && (d = b.g.slice(0, e + 1) + d);
        }
      e = d;
      if (e == ".." || e == ".") d = "";
      else if (gb(e, "./") || gb(e, "/.")) {
        d = Xa(e, "/");
        e = e.split("/");
        for (var f = [], g = 0; g < e.length; ) {
          var l = e[g++];
          l == "."
            ? d && g == e.length && f.push("")
            : l == ".."
            ? ((f.length > 1 || (f.length == 1 && f[0] != "")) && f.pop(),
              d && g == e.length && f.push(""))
            : (f.push(l), (d = !0));
        }
        d = f.join("/");
      } else d = e;
    }
    c ? (b.g = d) : (c = a.h.toString() !== "");
    c ? Me(b, Ne(a.h)) : (c = !!a.o);
    c && (b.o = a.o);
    return b;
  };
  var Ke = function (a, b, c) {
      a.l = c ? Oe(b, !0) : b;
      a.l && (a.l = a.l.replace(/:$/, ""));
    },
    Le = function (a, b) {
      if (b) {
        b = Number(b);
        if (isNaN(b) || b < 0) throw Error("Bad port number " + b);
        a.B = b;
      } else a.B = null;
    },
    Me = function (a, b, c) {
      b instanceof Pe
        ? ((a.h = b), Ve(a.h, a.v))
        : (c || (b = Qe(b, We)), (a.h = new Pe(b, a.v)));
    },
    Oe = function (a, b) {
      return a
        ? b
          ? decodeURI(a.replace(/%25/g, "%2525"))
          : decodeURIComponent(a)
        : "";
    },
    Qe = function (a, b, c) {
      return typeof a === "string"
        ? ((a = encodeURI(a).replace(b, Xe)),
          c && (a = a.replace(/%25([0-9a-fA-F]{2})/g, "%$1")),
          a)
        : null;
    },
    Xe = function (a) {
      a = a.charCodeAt(0);
      return "%" + ((a >> 4) & 15).toString(16) + (a & 15).toString(16);
    },
    Re = /[#\/\?@]/g,
    Te = /[#\?:]/g,
    Se = /[#\?]/g,
    We = /[#\?@]/g,
    Ue = /#/g,
    Pe = function (a, b) {
      this.h = this.g = null;
      this.j = a || null;
      this.l = !!b;
    },
    Ye = function (a) {
      a.g ||
        ((a.g = new Map()),
        (a.h = 0),
        a.j &&
          Be(a.j, function (b, c) {
            a.add(Kd(b), c);
          }));
    };
  Pe.prototype.T = function () {
    Ye(this);
    return this.h;
  };
  Pe.prototype.add = function (a, b) {
    Ye(this);
    this.j = null;
    a = Ze(this, a);
    var c = this.g.get(a);
    c || this.g.set(a, (c = []));
    c.push(b);
    this.h += 1;
    return this;
  };
  var $e = function (a, b) {
    Ye(a);
    b = Ze(a, b);
    a.g.has(b) && ((a.j = null), (a.h -= a.g.get(b).length), a.g.delete(b));
  };
  h = Pe.prototype;
  h.clear = function () {
    this.g = this.j = null;
    this.h = 0;
  };
  h.da = function (a) {
    Ye(this);
    a = Ze(this, a);
    return this.g.has(a);
  };
  h.Sa = function (a) {
    var b = this.U();
    return zb(b, a) >= 0;
  };
  h.forEach = function (a, b) {
    Ye(this);
    this.g.forEach(function (c, d) {
      c.forEach(function (e) {
        a.call(b, e, d, this);
      }, this);
    }, this);
  };
  h.Ba = function () {
    Ye(this);
    for (
      var a = Array.from(this.g.values()),
        b = Array.from(this.g.keys()),
        c = [],
        d = 0;
      d < b.length;
      d++
    )
      for (var e = a[d], f = 0; f < e.length; f++) c.push(b[d]);
    return c;
  };
  h.U = function (a) {
    Ye(this);
    var b = [];
    if (typeof a === "string")
      this.da(a) && (b = b.concat(this.g.get(Ze(this, a))));
    else {
      a = Array.from(this.g.values());
      for (var c = 0; c < a.length; c++) b = b.concat(a[c]);
    }
    return b;
  };
  h.set = function (a, b) {
    Ye(this);
    this.j = null;
    a = Ze(this, a);
    this.da(a) && (this.h -= this.g.get(a).length);
    this.g.set(a, [b]);
    this.h += 1;
    return this;
  };
  h.get = function (a, b) {
    if (!a) return b;
    a = this.U(a);
    return a.length > 0 ? String(a[0]) : b;
  };
  h.toString = function () {
    if (this.j) return this.j;
    if (!this.g) return "";
    for (var a = [], b = Array.from(this.g.keys()), c = 0; c < b.length; c++) {
      var d = b[c],
        e = encodeURIComponent(String(d));
      d = this.U(d);
      for (var f = 0; f < d.length; f++) {
        var g = e;
        d[f] !== "" && (g += "=" + encodeURIComponent(String(d[f])));
        a.push(g);
      }
    }
    return (this.j = a.join("&"));
  };
  var Ne = function (a) {
      var b = new Pe();
      b.j = a.j;
      a.g && ((b.g = new Map(a.g)), (b.h = a.h));
      return b;
    },
    Ze = function (a, b) {
      b = String(b);
      a.l && (b = b.toLowerCase());
      return b;
    },
    Ve = function (a, b) {
      b &&
        !a.l &&
        (Ye(a),
        (a.j = null),
        a.g.forEach(function (c, d) {
          var e = d.toLowerCase();
          d != e &&
            ($e(this, d),
            $e(this, e),
            c.length > 0 &&
              ((this.j = null),
              this.g.set(Ze(this, e), Ib(c)),
              (this.h += c.length)));
        }, a));
      a.l = b;
    };
  var af,
    bf,
    cf,
    df,
    ef,
    ff,
    gf = function () {
      return r.navigator ? r.navigator.userAgent : "";
    },
    hf = function (a) {
      return gb(gf(), a);
    },
    jf = hf("(iPad") || hf("(Macintosh") || hf("(iPod") || hf("(iPhone"),
    kf = hf("Android"),
    lf = function () {
      if (af === void 0) {
        var a = /Android\s+([0-9.]+)/.exec(gf());
        af = a && a.length == 2 ? a[1] : "";
      }
      return af;
    },
    mf = function () {
      if (cf === void 0) {
        if (jf) {
          var a = hf("Safari");
          var b = new Je(window.location.href).h.U("js");
          a: {
            if ((b = b.length ? b[0] : "") && Xa(b, "afma-")) {
              var c = b.lastIndexOf("v");
              if (
                c > -1 &&
                (b = b
                  .substr(c + 1)
                  .match(/^(\d+\.\d+\.\d+|^\d+\.\d+|^\d+)(-.*)?$/))
              ) {
                b = b[1];
                break a;
              }
            }
            b = "0.0.0";
          }
          if (!a || b !== "0.0.0") return (cf = !0);
        }
        cf = !1;
      }
      return cf;
    },
    nf = function () {
      df === void 0 && (df = hf("afma-sdk-a") ? !0 : !1);
      return df;
    },
    of = function () {
      ef === void 0 && (ef = mf() || nf());
      return ef;
    },
    qf = function (a) {
      var b = pf();
      return b ? hb(b, a) >= 0 : !1;
    },
    rf = function () {
      var a = pf();
      if (!a) return !1;
      a = Za(a).split(".");
      return a.length != 3 ? !1 : a[0].length < 5;
    },
    pf = function () {
      if (ff === void 0)
        if (nf()) {
          var a = gf().match(/afma\-sdk\-a\-v\.?([\d+\.]+)/);
          ff = a ? a[1] : "";
        } else ff = "";
      return ff;
    };
  var sf = function (a, b) {
    this.o = Math.random() < a;
    this.A = b;
    this.h = null;
    this.v = "";
  };
  sf.prototype.isActive = function () {
    return this.o;
  };
  sf.prototype.j = function () {
    return this.isActive() && null !== this.h
      ? (
          this.A +
          "//pagead2.googlesyndication.com/pagead/gen_204/?id=" +
          this.h +
          this.v
        ).substring(0, 2e3)
      : "";
  };
  var tf = function () {},
    wf = function (a) {
      uf = a | 6;
      vf(uf);
    },
    vf = function (a) {
      xf(a, 2, 1);
      xf(a, 1, 2);
      xf(a, 4, 8);
      xf(a, 8, 4);
      xf(a, 128, 64);
      xf(a, 64, 128);
      xf(a, 256, 2);
    },
    xf = function (a, b, c) {
      (a & b) == b && ((uf |= b), (uf &= ~c));
    };
  v("studio.common.Environment", tf);
  tf.Type = {
    LIVE: 1,
    LOCAL: 2,
    BROWSER: 4,
    IN_APP: 8,
    LAYOUTS_PREVIEW: 16,
    CREATIVE_TOOLSET: 32,
    RENDERING_STUDIO: 64,
    RENDERING_TEST: 128,
    PREVIEW: 256,
  };
  var uf = 6;
  tf.addType = function (a) {
    uf |= a;
    vf(a);
  };
  tf.setType = wf;
  var G = function (a) {
    return (uf & a) == a;
  };
  tf.hasType = G;
  tf.getValue = function () {
    return uf;
  };
  var yf = function (a, b) {
    sf.call(this, a, b);
    this.l = this.g = null;
    this.h = "rmad_mod";
  };
  p(yf, sf);
  yf.prototype.j = function () {
    return null !== this.g && null !== this.l
      ? ((this.v = "&status=" + this.g + "&type=" + this.l),
        sf.prototype.j.call(this))
      : "";
  };
  var zf = { Bf: "dcm", cg: "studio", yf: "clicktag" };
  var Af = function () {};
  Af.prototype.log = function () {};
  Af.prototype.info = function () {};
  Af.prototype.config = function () {};
  var H = new Af();
  v("studio.sdk.logger", H);
  var Bf = {
    ENABLER: "enabler",
    DCM_ENABLER: "dcmenabler",
    SSR_ENABLER: "ssrenabler",
    CLICK_TAG_ENABLER: "clicktagenabler",
    ENABLER_LOADER: "enablerloader",
    DCM_ENABLER_LOADER: "dcmenablerloader",
    CLICK_TAG_ENABLER_LOADER: "clicktagenablerloader",
    VIDEO: "video",
    CONFIGURABLE: "configurable",
    CONFIGURABLE_FILLER: "configurablefiller",
    LAYOUTS: "layouts",
    FILLER: "layoutsfiller",
    RAD_VIDEO: "rad_ui_video",
    GDN: "gdn",
  };
  v("studio.module.ModuleId", Bf);
  var Cf =
    typeof AsyncContext !== "undefined" &&
    typeof AsyncContext.Snapshot === "function"
      ? function (a) {
          return a && AsyncContext.Snapshot.wrap(a);
        }
      : function (a) {
          return a;
        };
  var Df = function (a, b) {
    this.j = a;
    this.l = b;
    this.h = 0;
    this.g = null;
  };
  Df.prototype.get = function () {
    if (this.h > 0) {
      this.h--;
      var a = this.g;
      this.g = a.next;
      a.next = null;
    } else a = this.j();
    return a;
  };
  var Ef = function (a, b) {
    a.l(b);
    a.h < 100 && (a.h++, (b.next = a.g), (a.g = b));
  };
  var Ff = function () {
    this.h = this.g = null;
  };
  Ff.prototype.add = function (a, b) {
    var c = Gf.get();
    c.set(a, b);
    this.h ? (this.h.next = c) : (this.g = c);
    this.h = c;
  };
  var If = function () {
      var a = Hf,
        b = null;
      a.g &&
        ((b = a.g), (a.g = a.g.next), a.g || (a.h = null), (b.next = null));
      return b;
    },
    Gf = new Df(
      function () {
        return new Jf();
      },
      function (a) {
        return a.reset();
      }
    ),
    Jf = function () {
      this.next = this.scope = this.g = null;
    };
  Jf.prototype.set = function (a, b) {
    this.g = a;
    this.scope = b;
    this.next = null;
  };
  Jf.prototype.reset = function () {
    this.next = this.scope = this.g = null;
  };
  var Kf,
    Lf = !1,
    Hf = new Ff(),
    Nf = function (a, b) {
      Kf || Mf();
      Lf || (Kf(), (Lf = !0));
      Hf.add(a, b);
    },
    Mf = function () {
      var a = Promise.resolve(void 0);
      Kf = function () {
        a.then(Of);
      };
    };
  function Of() {
    for (var a; (a = If()); ) {
      try {
        a.g.call(a.scope);
      } catch (b) {
        Wa(b);
      }
      Ef(Gf, a);
    }
    Lf = !1;
  }
  var Pf = function (a) {
    if (!a) return !1;
    try {
      return !!a.$goog_Thenable;
    } catch (b) {
      return !1;
    }
  };
  var Rf = function (a) {
      this.g = 0;
      this.A = void 0;
      this.l = this.h = this.j = null;
      this.v = this.o = !1;
      if (a != pd)
        try {
          var b = this;
          a.call(
            void 0,
            function (c) {
              Qf(b, 2, c);
            },
            function (c) {
              Qf(b, 3, c);
            }
          );
        } catch (c) {
          Qf(this, 3, c);
        }
    },
    Sf = function () {
      this.next = this.context = this.h = this.j = this.g = null;
      this.l = !1;
    };
  Sf.prototype.reset = function () {
    this.context = this.h = this.j = this.g = null;
    this.l = !1;
  };
  var Tf = new Df(
      function () {
        return new Sf();
      },
      function (a) {
        a.reset();
      }
    ),
    Uf = function (a, b, c) {
      var d = Tf.get();
      d.j = a;
      d.h = b;
      d.context = c;
      return d;
    },
    Vf = function (a) {
      if (a instanceof Rf) return a;
      var b = new Rf(pd);
      Qf(b, 2, a);
      return b;
    },
    Wf = function (a) {
      return new Rf(function (b, c) {
        c(a);
      });
    },
    Yf = function (a, b, c) {
      Xf(a, b, c, null) || Nf(Ta(b, a));
    },
    Zf = function (a) {
      return new Rf(function (b, c) {
        var d = a.length,
          e = [];
        if (d)
          for (
            var f = function (n, q) {
                d--;
                e[n] = q;
                d == 0 && b(e);
              },
              g = function (n) {
                c(n);
              },
              l,
              m = 0;
            m < a.length;
            m++
          )
            (l = a[m]), Yf(l, Ta(f, m), g);
        else b(e);
      });
    };
  Rf.prototype.then = function (a, b, c) {
    return $f(
      this,
      Cf(typeof a === "function" ? a : null),
      Cf(typeof b === "function" ? b : null),
      c
    );
  };
  Rf.prototype.$goog_Thenable = !0;
  var ag = function (a, b) {
    return $f(a, null, Cf(b));
  };
  Rf.prototype.cancel = function (a) {
    if (this.g == 0) {
      var b = new bg(a);
      Nf(function () {
        cg(this, b);
      }, this);
    }
  };
  var cg = function (a, b) {
      if (a.g == 0)
        if (a.j) {
          var c = a.j;
          if (c.h) {
            for (
              var d = 0, e = null, f = null, g = c.h;
              g && (g.l || (d++, g.g == a && (e = g), !(e && d > 1)));
              g = g.next
            )
              e || (f = g);
            e &&
              (c.g == 0 && d == 1
                ? cg(c, b)
                : (f
                    ? ((d = f),
                      d.next == c.l && (c.l = d),
                      (d.next = d.next.next))
                    : dg(c),
                  eg(c, e, 3, b)));
          }
          a.j = null;
        } else Qf(a, 3, b);
    },
    gg = function (a, b) {
      a.h || (a.g != 2 && a.g != 3) || fg(a);
      a.l ? (a.l.next = b) : (a.h = b);
      a.l = b;
    },
    $f = function (a, b, c, d) {
      var e = Uf(null, null, null);
      e.g = new Rf(function (f, g) {
        e.j = b
          ? function (l) {
              try {
                var m = b.call(d, l);
                f(m);
              } catch (n) {
                g(n);
              }
            }
          : f;
        e.h = c
          ? function (l) {
              try {
                var m = c.call(d, l);
                m === void 0 && l instanceof bg ? g(l) : f(m);
              } catch (n) {
                g(n);
              }
            }
          : g;
      });
      e.g.j = a;
      gg(a, e);
      return e.g;
    };
  Rf.prototype.D = function (a) {
    this.g = 0;
    Qf(this, 2, a);
  };
  Rf.prototype.F = function (a) {
    this.g = 0;
    Qf(this, 3, a);
  };
  var Qf = function (a, b, c) {
      a.g == 0 &&
        (a === c &&
          ((b = 3), (c = new TypeError("Promise cannot resolve to itself"))),
        (a.g = 1),
        Xf(c, a.D, a.F, a) ||
          ((a.A = c),
          (a.g = b),
          (a.j = null),
          fg(a),
          b != 3 || c instanceof bg || hg(a, c)));
    },
    Xf = function (a, b, c, d) {
      if (a instanceof Rf) return gg(a, Uf(b || pd, c || null, d)), !0;
      if (Pf(a)) return a.then(b, c, d), !0;
      if (w(a))
        try {
          var e = a.then;
          if (typeof e === "function") return ig(a, e, b, c, d), !0;
        } catch (f) {
          return c.call(d, f), !0;
        }
      return !1;
    },
    ig = function (a, b, c, d, e) {
      var f = !1,
        g = function (m) {
          f || ((f = !0), c.call(e, m));
        },
        l = function (m) {
          f || ((f = !0), d.call(e, m));
        };
      try {
        b.call(a, g, l);
      } catch (m) {
        l(m);
      }
    },
    fg = function (a) {
      a.o || ((a.o = !0), Nf(a.B, a));
    },
    dg = function (a) {
      var b = null;
      a.h && ((b = a.h), (a.h = b.next), (b.next = null));
      a.h || (a.l = null);
      return b;
    };
  Rf.prototype.B = function () {
    for (var a; (a = dg(this)); ) eg(this, a, this.g, this.A);
    this.o = !1;
  };
  var eg = function (a, b, c, d) {
      if (c == 3 && b.h && !b.l) for (; a && a.v; a = a.j) a.v = !1;
      if (b.g) (b.g.j = null), jg(b, c, d);
      else
        try {
          b.l ? b.j.call(b.context) : jg(b, c, d);
        } catch (e) {
          kg.call(null, e);
        }
      Ef(Tf, b);
    },
    jg = function (a, b, c) {
      b == 2 ? a.j.call(a.context, c) : a.h && a.h.call(a.context, c);
    },
    hg = function (a, b) {
      a.v = !0;
      Nf(function () {
        a.v && kg.call(null, b);
      });
    },
    kg = Wa,
    bg = function (a) {
      Ua.call(this, a);
    };
  y(bg, Ua);
  bg.prototype.name = "cancel"; /*

 Copyright 2005, 2007 Bob Ippolito. All Rights Reserved.
 Copyright The Closure Library Authors.
 SPDX-License-Identifier: MIT
*/
  var I = function (a, b) {
    this.A = [];
    this.G = a;
    this.ca = b || null;
    this.l = this.g = !1;
    this.j = void 0;
    this.F = this.I = this.D = !1;
    this.B = 0;
    this.h = null;
    this.v = 0;
  };
  I.prototype.cancel = function (a) {
    if (this.g) this.j instanceof I && this.j.cancel();
    else {
      if (this.h) {
        var b = this.h;
        delete this.h;
        a ? b.cancel(a) : (b.v--, b.v <= 0 && b.cancel());
      }
      this.G ? this.G.call(this.ca, this) : (this.F = !0);
      this.g || this.o(new lg(this));
    }
  };
  I.prototype.V = function (a, b) {
    this.D = !1;
    mg(this, a, b);
  };
  var mg = function (a, b, c) {
      a.g = !0;
      a.j = c;
      a.l = !b;
      ng(a);
    },
    pg = function (a) {
      if (a.g) {
        if (!a.F) throw new og(a);
        a.F = !1;
      }
    };
  I.prototype.callback = function (a) {
    pg(this);
    mg(this, !0, a);
  };
  I.prototype.o = function (a) {
    pg(this);
    mg(this, !1, a);
  };
  var rg = function (a, b, c) {
      qg(a, b, null, c);
    },
    qg = function (a, b, c, d) {
      var e = a.g;
      e || (b === c ? (b = c = Cf(b)) : ((b = Cf(b)), (c = Cf(c))));
      a.A.push([b, c, d]);
      e && ng(a);
    };
  I.prototype.then = function (a, b, c) {
    var d,
      e,
      f = new Rf(function (g, l) {
        e = g;
        d = l;
      });
    qg(
      this,
      e,
      function (g) {
        g instanceof lg ? f.cancel() : d(g);
        return sg;
      },
      this
    );
    return f.then(a, b, c);
  };
  I.prototype.$goog_Thenable = !0;
  var tg = function (a, b) {
    b instanceof I
      ? rg(a, x(b.J, b))
      : rg(a, function () {
          return b;
        });
  };
  I.prototype.J = function (a) {
    var b = new I();
    qg(this, b.callback, b.o, b);
    a && ((b.h = this), this.v++);
    return b;
  };
  var ug = function (a) {
      return Cb(a.A, function (b) {
        return typeof b[1] === "function";
      });
    },
    sg = {},
    ng = function (a) {
      if (a.B && a.g && ug(a)) {
        var b = a.B,
          c = vg[b];
        c && (r.clearTimeout(c.g), delete vg[b]);
        a.B = 0;
      }
      a.h && (a.h.v--, delete a.h);
      b = a.j;
      for (var d = (c = !1); a.A.length && !a.D; ) {
        var e = a.A.shift(),
          f = e[0],
          g = e[1];
        e = e[2];
        if ((f = a.l ? g : f))
          try {
            var l = f.call(e || a.ca, b);
            l === sg && (l = void 0);
            l !== void 0 &&
              ((a.l = a.l && (l == b || l instanceof Error)), (a.j = b = l));
            if (
              Pf(b) ||
              (typeof r.Promise === "function" && b instanceof r.Promise)
            )
              (d = !0), (a.D = !0);
          } catch (m) {
            (b = m), (a.l = !0), ug(a) || (c = !0);
          }
      }
      a.j = b;
      d &&
        ((l = x(a.V, a, !0)),
        (d = x(a.V, a, !1)),
        b instanceof I ? (qg(b, l, d), (b.I = !0)) : b.then(l, d));
      c && ((b = new wg(b)), (vg[b.g] = b), (a.B = b.g));
    },
    og = function () {
      Ua.call(this);
    };
  y(og, Ua);
  og.prototype.message = "Deferred has already fired";
  og.prototype.name = "AlreadyCalledError";
  var lg = function () {
    Ua.call(this);
  };
  y(lg, Ua);
  lg.prototype.message = "Deferred was canceled";
  lg.prototype.name = "CanceledError";
  var wg = function (a) {
    this.g = r.setTimeout(x(this.j, this), 0);
    this.h = a;
  };
  wg.prototype.j = function () {
    delete vg[this.g];
    throw this.h;
  };
  var vg = {};
  var Bg = function (a) {
      var b = {},
        c = b.document || document,
        d = wd(a).toString(),
        e = ke(new Wd(c), "SCRIPT"),
        f = { fd: e, md: void 0 },
        g = new I(xg, f),
        l = null,
        m = b.timeout != null ? b.timeout : 5e3;
      m > 0 &&
        ((l = window.setTimeout(function () {
          yg(e, !0);
          g.o(new zg(1, "Timeout reached for loading script " + d));
        }, m)),
        (f.md = l));
      e.onload = e.onreadystatechange = function () {
        (e.readyState &&
          e.readyState != "loaded" &&
          e.readyState != "complete") ||
          (yg(e, b.gg || !1, l), g.callback(null));
      };
      e.onerror = function () {
        yg(e, !0, l);
        g.o(new zg(0, "Error while loading script " + d));
      };
      f = b.attributes || {};
      ld(f, { type: "text/javascript", charset: "UTF-8" });
      $d(e, f);
      Id(e, a);
      Ag(c).appendChild(e);
      return g;
    },
    Ag = function (a) {
      var b;
      return (b = (a || document).getElementsByTagName("HEAD")) &&
        b.length !== 0
        ? b[0]
        : a.documentElement;
    },
    xg = function () {
      if (this && this.fd) {
        var a = this.fd;
        a && a.tagName == "SCRIPT" && yg(a, !0, this.md);
      }
    },
    yg = function (a, b, c) {
      c != null && r.clearTimeout(c);
      a.onload = function () {};
      a.onerror = function () {};
      a.onreadystatechange = function () {};
      b &&
        window.setTimeout(function () {
          he(a);
        }, 0);
    },
    zg = function (a, b) {
      var c = "Jsloader error (code #" + a + ")";
      b && (c += ": " + b);
      Ua.call(this, c);
      this.code = a;
    };
  y(zg, Ua);
  var Cg = function (a, b) {
    this.g = a[r.Symbol.iterator]();
    this.h = b;
  };
  Cg.prototype[Symbol.iterator] = function () {
    return this;
  };
  Cg.prototype.next = function () {
    var a = this.g.next();
    return {
      value: a.done ? void 0 : this.h.call(void 0, a.value),
      done: a.done,
    };
  };
  var Dg = function (a, b) {
    return new Cg(a, b);
  };
  var Eg = function () {};
  Eg.prototype.next = function () {
    return Fg;
  };
  var Fg = { done: !0, value: void 0 };
  Eg.prototype.ua = function () {
    return this;
  };
  var Jg = function (a) {
      if (a instanceof Gg || a instanceof Hg || a instanceof Ig) return a;
      if (typeof a.next == "function")
        return new Gg(function () {
          return a;
        });
      if (typeof a[Symbol.iterator] == "function")
        return new Gg(function () {
          return a[Symbol.iterator]();
        });
      if (typeof a.ua == "function")
        return new Gg(function () {
          return a.ua();
        });
      throw Error("Not an iterator or iterable.");
    },
    Gg = function (a) {
      this.g = a;
    };
  Gg.prototype.ua = function () {
    return new Hg(this.g());
  };
  Gg.prototype[Symbol.iterator] = function () {
    return new Ig(this.g());
  };
  Gg.prototype.h = function () {
    return new Ig(this.g());
  };
  var Hg = function (a) {
    this.g = a;
  };
  p(Hg, Eg);
  Hg.prototype.next = function () {
    return this.g.next();
  };
  Hg.prototype[Symbol.iterator] = function () {
    return new Ig(this.g);
  };
  Hg.prototype.h = function () {
    return new Ig(this.g);
  };
  var Ig = function (a) {
    Gg.call(this, function () {
      return a;
    });
    this.j = a;
  };
  p(Ig, Gg);
  Ig.prototype.next = function () {
    return this.j.next();
  };
  var J = function (a, b) {
    this.h = {};
    this.g = [];
    this.j = this.size = 0;
    var c = arguments.length;
    if (c > 1) {
      if (c % 2) throw Error("Uneven number of arguments");
      for (var d = 0; d < c; d += 2) this.set(arguments[d], arguments[d + 1]);
    } else if (a)
      if (a instanceof J)
        for (c = a.Ba(), d = 0; d < c.length; d++) this.set(c[d], a.get(c[d]));
      else for (d in a) this.set(d, a[d]);
  };
  h = J.prototype;
  h.T = function () {
    return this.size;
  };
  h.U = function () {
    Kg(this);
    for (var a = [], b = 0; b < this.g.length; b++) a.push(this.h[this.g[b]]);
    return a;
  };
  h.Ba = function () {
    Kg(this);
    return this.g.concat();
  };
  h.da = function (a) {
    return this.has(a);
  };
  h.has = function (a) {
    return Lg(this.h, a);
  };
  h.Sa = function (a) {
    for (var b = 0; b < this.g.length; b++) {
      var c = this.g[b];
      if (Lg(this.h, c) && this.h[c] == a) return !0;
    }
    return !1;
  };
  h.equals = function (a, b) {
    if (this === a) return !0;
    if (this.size != a.T()) return !1;
    b = b || Mg;
    Kg(this);
    for (var c, d = 0; (c = this.g[d]); d++)
      if (!b(this.get(c), a.get(c))) return !1;
    return !0;
  };
  var Mg = function (a, b) {
    return a === b;
  };
  J.prototype.clear = function () {
    this.h = {};
    this.j = this.size = this.g.length = 0;
  };
  J.prototype.delete = function (a) {
    return Lg(this.h, a)
      ? (delete this.h[a],
        --this.size,
        this.j++,
        this.g.length > 2 * this.size && Kg(this),
        !0)
      : !1;
  };
  var Kg = function (a) {
    if (a.size != a.g.length) {
      for (var b = 0, c = 0; b < a.g.length; ) {
        var d = a.g[b];
        Lg(a.h, d) && (a.g[c++] = d);
        b++;
      }
      a.g.length = c;
    }
    if (a.size != a.g.length) {
      b = {};
      for (d = c = 0; c < a.g.length; ) {
        var e = a.g[c];
        Lg(b, e) || ((a.g[d++] = e), (b[e] = 1));
        c++;
      }
      a.g.length = d;
    }
  };
  h = J.prototype;
  h.get = function (a, b) {
    return Lg(this.h, a) ? this.h[a] : b;
  };
  h.set = function (a, b) {
    Lg(this.h, a) || ((this.size += 1), this.g.push(a), this.j++);
    this.h[a] = b;
  };
  h.forEach = function (a, b) {
    for (var c = this.Ba(), d = 0; d < c.length; d++) {
      var e = c[d],
        f = this.get(e);
      a.call(b, f, e, this);
    }
  };
  h.keys = function () {
    return Jg(this.ua(!0)).h();
  };
  h.values = function () {
    return Jg(this.ua(!1)).h();
  };
  h.entries = function () {
    var a = this;
    return Dg(this.keys(), function (b) {
      return [b, a.get(b)];
    });
  };
  h.ua = function (a) {
    Kg(this);
    var b = 0,
      c = this.j,
      d = this,
      e = new Eg();
    e.next = function () {
      if (c != d.j)
        throw Error("The map has changed since the iterator was created");
      if (b >= d.g.length) return Fg;
      var f = d.g[b++];
      return { value: a ? f : d.h[f], done: !1 };
    };
    return e;
  };
  var Lg = function (a, b) {
    return Object.prototype.hasOwnProperty.call(a, b);
  };
  var K = function (a, b) {
    this.type = a;
    this.g = this.target = b;
    this.defaultPrevented = this.h = !1;
  };
  K.prototype.stopPropagation = function () {
    this.h = !0;
  };
  K.prototype.j = function () {
    this.defaultPrevented = !0;
  };
  var Ng = function (a) {
    a.j();
  };
  var Og = function (a, b) {
    K.call(this, a ? a.type : "");
    this.relatedTarget = this.g = this.target = null;
    this.button = this.screenY = this.screenX = this.clientY = this.clientX = 0;
    this.key = "";
    this.metaKey = this.shiftKey = this.altKey = this.ctrlKey = !1;
    this.state = null;
    this.pointerId = 0;
    this.pointerType = "";
    this.timeStamp = 0;
    this.Y = null;
    a && this.init(a, b);
  };
  y(Og, K);
  Og.prototype.init = function (a, b) {
    var c = (this.type = a.type),
      d =
        a.changedTouches && a.changedTouches.length
          ? a.changedTouches[0]
          : null;
    this.target = a.target || a.srcElement;
    this.g = b;
    b = a.relatedTarget;
    b ||
      (c == "mouseover"
        ? (b = a.fromElement)
        : c == "mouseout" && (b = a.toElement));
    this.relatedTarget = b;
    d
      ? ((this.clientX = d.clientX !== void 0 ? d.clientX : d.pageX),
        (this.clientY = d.clientY !== void 0 ? d.clientY : d.pageY),
        (this.screenX = d.screenX || 0),
        (this.screenY = d.screenY || 0))
      : ((this.clientX = a.clientX !== void 0 ? a.clientX : a.pageX),
        (this.clientY = a.clientY !== void 0 ? a.clientY : a.pageY),
        (this.screenX = a.screenX || 0),
        (this.screenY = a.screenY || 0));
    this.button = a.button;
    this.key = a.key || "";
    this.ctrlKey = a.ctrlKey;
    this.altKey = a.altKey;
    this.shiftKey = a.shiftKey;
    this.metaKey = a.metaKey;
    this.pointerId = a.pointerId || 0;
    this.pointerType = a.pointerType;
    this.state = a.state;
    this.timeStamp = a.timeStamp;
    this.Y = a;
    a.defaultPrevented && Og.M.j.call(this);
  };
  Og.prototype.stopPropagation = function () {
    Og.M.stopPropagation.call(this);
    this.Y.stopPropagation
      ? this.Y.stopPropagation()
      : (this.Y.cancelBubble = !0);
  };
  Og.prototype.j = function () {
    Og.M.j.call(this);
    var a = this.Y;
    a.preventDefault ? a.preventDefault() : (a.returnValue = !1);
  };
  Og.prototype.ce = function () {
    return this.Y;
  };
  var Pg = "closure_listenable_" + ((Math.random() * 1e6) | 0),
    Qg = function (a) {
      return !(!a || !a[Pg]);
    };
  var Rg = 0;
  var Sg = function (a, b, c, d, e) {
      this.listener = a;
      this.proxy = null;
      this.src = b;
      this.type = c;
      this.capture = !!d;
      this.handler = e;
      this.key = ++Rg;
      this.Ya = this.kb = !1;
    },
    Tg = function (a) {
      a.Ya = !0;
      a.listener = null;
      a.proxy = null;
      a.src = null;
      a.handler = null;
    };
  function Ug(a) {
    this.src = a;
    this.g = {};
    this.h = 0;
  }
  Ug.prototype.add = function (a, b, c, d, e) {
    var f = a.toString();
    a = this.g[f];
    a || ((a = this.g[f] = []), this.h++);
    var g = Vg(a, b, d, e);
    g > -1
      ? ((b = a[g]), c || (b.kb = !1))
      : ((b = new Sg(b, this.src, f, !!d, e)), (b.kb = c), a.push(b));
    return b;
  };
  var Wg = function (a, b) {
      var c = b.type;
      if (!(c in a.g)) return !1;
      var d = Fb(a.g[c], b);
      d && (Tg(b), a.g[c].length == 0 && (delete a.g[c], a.h--));
      return d;
    },
    Xg = function (a, b) {
      b = b && b.toString();
      var c = 0,
        d;
      for (d in a.g)
        if (!b || d == b) {
          for (var e = a.g[d], f = 0; f < e.length; f++) ++c, Tg(e[f]);
          delete a.g[d];
          a.h--;
        }
    },
    Yg = function (a, b, c, d, e) {
      a = a.g[b.toString()];
      b = -1;
      a && (b = Vg(a, c, d, e));
      return b > -1 ? a[b] : null;
    },
    Zg = function (a, b) {
      var c = b !== void 0,
        d = c ? b.toString() : "";
      cd(a.g, function (e) {
        for (var f = 0; f < e.length; ++f) if (!c || e[f].type == d) return !0;
        return !1;
      });
    },
    Vg = function (a, b, c, d) {
      for (var e = 0; e < a.length; ++e) {
        var f = a[e];
        if (!f.Ya && f.listener == b && f.capture == !!c && f.handler == d)
          return e;
      }
      return -1;
    };
  var $g = "closure_lm_" + ((Math.random() * 1e6) | 0),
    ah = {},
    bh = 0,
    eh = function (a, b, c, d, e) {
      if (d && d.once) return ch(a, b, c, d, e);
      if (Array.isArray(b)) {
        for (var f = 0; f < b.length; f++) eh(a, b[f], c, d, e);
        return null;
      }
      c = fh(c);
      return Qg(a)
        ? a.Ga(b, c, w(d) ? !!d.capture : !!d, e)
        : gh(a, b, c, !1, d, e);
    },
    gh = function (a, b, c, d, e, f) {
      if (!b) throw Error("Invalid event type");
      var g = w(e) ? !!e.capture : !!e,
        l = hh(a);
      l || (a[$g] = l = new Ug(a));
      c = l.add(b, c, d, g, f);
      if (c.proxy) return c;
      d = ih();
      c.proxy = d;
      d.src = a;
      d.listener = c;
      if (a.addEventListener)
        Ud || (e = g),
          e === void 0 && (e = !1),
          a.addEventListener(b.toString(), d, e);
      else if (a.attachEvent) a.attachEvent(jh(b.toString()), d);
      else if (a.addListener && a.removeListener) a.addListener(d);
      else throw Error("addEventListener and attachEvent are unavailable.");
      bh++;
      return c;
    },
    ih = function () {
      var a = kh,
        b = function (c) {
          return a.call(b.src, b.listener, c);
        };
      return b;
    },
    ch = function (a, b, c, d, e) {
      if (Array.isArray(b)) {
        for (var f = 0; f < b.length; f++) ch(a, b[f], c, d, e);
        return null;
      }
      c = fh(c);
      return Qg(a)
        ? a.v.add(String(b), c, !0, w(d) ? !!d.capture : !!d, e)
        : gh(a, b, c, !0, d, e);
    },
    lh = function (a, b, c, d, e) {
      if (Array.isArray(b))
        for (var f = 0; f < b.length; f++) lh(a, b[f], c, d, e);
      else
        (d = w(d) ? !!d.capture : !!d),
          (c = fh(c)),
          Qg(a)
            ? a.Oa(b, c, d, e)
            : a && (a = hh(a)) && (b = Yg(a, b, c, d, e)) && mh(b);
    },
    mh = function (a) {
      if (typeof a === "number" || !a || a.Ya) return !1;
      var b = a.src;
      if (Qg(b)) return Wg(b.v, a);
      var c = a.type,
        d = a.proxy;
      b.removeEventListener
        ? b.removeEventListener(c, d, a.capture)
        : b.detachEvent
        ? b.detachEvent(jh(c), d)
        : b.addListener && b.removeListener && b.removeListener(d);
      bh--;
      (c = hh(b))
        ? (Wg(c, a), c.h == 0 && ((c.src = null), (b[$g] = null)))
        : Tg(a);
      return !0;
    },
    nh = function (a, b, c, d, e) {
      c = fh(c);
      d = !!d;
      return Qg(a)
        ? Yg(a.v, String(b), c, d, e)
        : a
        ? (a = hh(a))
          ? Yg(a, b, c, d, e)
          : null
        : null;
    },
    oh = function (a, b) {
      Qg(a)
        ? Zg(a.v, b !== void 0 ? String(b) : void 0)
        : (a = hh(a)) && Zg(a, b);
    },
    jh = function (a) {
      return a in ah ? ah[a] : (ah[a] = "on" + a);
    },
    kh = function (a, b) {
      if (a.Ya) a = !0;
      else {
        b = new Og(b, this);
        var c = a.listener,
          d = a.handler || a.src;
        a.kb && mh(a);
        a = c.call(d, b);
      }
      return a;
    },
    hh = function (a) {
      a = a[$g];
      return a instanceof Ug ? a : null;
    },
    ph = "__closure_events_fn_" + ((Math.random() * 1e9) >>> 0),
    fh = function (a) {
      if (typeof a === "function") return a;
      a[ph] ||
        (a[ph] = function (b) {
          return a.handleEvent(b);
        });
      return a[ph];
    };
  var L = function () {
    E.call(this);
    this.v = new Ug(this);
    this.We = this;
    this.hb = null;
  };
  y(L, E);
  L.prototype[Pg] = !0;
  h = L.prototype;
  h.Vb = function (a) {
    this.hb = a;
  };
  h.addEventListener = function (a, b, c, d) {
    eh(this, a, b, c, d);
  };
  h.removeEventListener = function (a, b, c, d) {
    lh(this, a, b, c, d);
  };
  h.dispatchEvent = function (a) {
    var b,
      c = this.hb;
    if (c) for (b = []; c; c = c.hb) b.push(c);
    c = this.We;
    var d = a.type || a;
    if (typeof a === "string") a = new K(a, c);
    else if (a instanceof K) a.target = a.target || c;
    else {
      var e = a;
      a = new K(d, c);
      ld(a, e);
    }
    e = !0;
    var f;
    if (b)
      for (f = b.length - 1; !a.h && f >= 0; f--) {
        var g = (a.g = b[f]);
        e = qh(g, d, !0, a) && e;
      }
    a.h ||
      ((g = a.g = c),
      (e = qh(g, d, !0, a) && e),
      a.h || (e = qh(g, d, !1, a) && e));
    if (b)
      for (f = 0; !a.h && f < b.length; f++)
        (g = a.g = b[f]), (e = qh(g, d, !1, a) && e);
    return e;
  };
  h.C = function () {
    L.M.C.call(this);
    this.v && Xg(this.v);
    this.hb = null;
  };
  h.Ga = function (a, b, c, d) {
    return this.v.add(String(a), b, !1, c, d);
  };
  h.Oa = function (a, b, c, d) {
    var e = this.v;
    a = String(a).toString();
    if (a in e.g) {
      var f = e.g[a];
      b = Vg(f, b, c, d);
      b > -1
        ? (Tg(f[b]),
          Gb(f, b),
          f.length == 0 && (delete e.g[a], e.h--),
          (e = !0))
        : (e = !1);
    } else e = !1;
    return e;
  };
  var qh = function (a, b, c, d) {
    b = a.v.g[String(b)];
    if (!b) return !0;
    b = b.concat();
    for (var e = !0, f = 0; f < b.length; ++f) {
      var g = b[f];
      if (g && !g.Ya && g.capture == c) {
        var l = g.listener,
          m = g.handler || g.src;
        g.kb && Wg(a.v, g);
        e = l.call(m, d) !== !1 && e;
      }
    }
    return e && !d.defaultPrevented;
  };
  var rh = function (a, b) {
    L.call(this);
    this.h = a || 1;
    this.g = b || r;
    this.j = x(this.hf, this);
    this.l = Date.now();
  };
  y(rh, L);
  h = rh.prototype;
  h.Ha = !1;
  h.ea = null;
  h.setInterval = function (a) {
    this.h = a;
    this.ea && this.Ha ? (this.stop(), this.start()) : this.ea && this.stop();
  };
  h.hf = function () {
    if (this.Ha) {
      var a = Date.now() - this.l;
      a > 0 && a < this.h * 0.8
        ? (this.ea = this.g.setTimeout(this.j, this.h - a))
        : (this.ea && (this.g.clearTimeout(this.ea), (this.ea = null)),
          this.dispatchEvent("tick"),
          this.Ha && (this.stop(), this.start()));
    }
  };
  h.start = function () {
    this.Ha = !0;
    this.ea ||
      ((this.ea = this.g.setTimeout(this.j, this.h)), (this.l = Date.now()));
  };
  h.stop = function () {
    this.Ha = !1;
    this.ea && (this.g.clearTimeout(this.ea), (this.ea = null));
  };
  h.C = function () {
    rh.M.C.call(this);
    this.stop();
    delete this.g;
  };
  var sh = function (a, b, c) {
    if (typeof a === "function") c && (a = x(a, c));
    else if (a && typeof a.handleEvent == "function") a = x(a.handleEvent, a);
    else throw Error("Invalid listener argument");
    return Number(b) > 2147483647 ? -1 : r.setTimeout(a, b || 0);
  };
  function th(a) {
    return vd(a === null ? "null" : a === void 0 ? "undefined" : a);
  }
  var uh = {},
    vh = {},
    wh = new yf(0.001, "");
  wh.g = "load";
  var xh = new yf(0.1, "");
  xh.g = "fail";
  var yh = new J();
  yh.set("enabler", "enabler");
  yh.set("dcmenabler", "dcm");
  yh.set("video", "vid");
  yh.set("configurable", "cfg");
  yh.set("configurablefiller", "cfg_fill");
  yh.set("layouts", "lay");
  yh.set("layoutsfiller", "lay_fill");
  yh.set("gdn", "gdn");
  yh.set("rad_ui_video", "rad");
  var zh = function (a) {
      a = uh[a];
      return a !== void 0 && a >= 1;
    },
    Ah = function (a) {
      a: {
        var b = document.getElementsByTagName("script");
        for (var c = 0; c < b.length; c++) {
          var d = b[c];
          if (d.src || d.getAttribute("src"))
            if (((d = d.src || d.getAttribute("src")), /Enabler/.test(d))) {
              b = d.substring(0, d.lastIndexOf("/") + 1);
              break a;
            }
        }
        b = "";
      }
      return [b, "prod_studio_01_262_", [a, "module"].join(""), ".js"].join("");
    };
  v(
    "goog.exportSymbol",
    function (a, b, c) {
      v(a, b, c);
    },
    this
  );
  var Bh = function (a) {
      a +=
        "goog.exportSymbol('studioLoader.context.evalInContext', " +
        Bh.toString() +
        ");";
      eval(a);
    },
    Ch = function (a, b) {
      b = yh.get(b) || "unknown";
      a.l = b;
      a = a.j();
      !Ya(a) && G(1) && (ce(document, "IMG").src = a);
    },
    Dh = function (a) {
      uh[a] = 2;
      Ch(wh, a);
      for (var b = Ah(a), c = Bg(th(b)), d = 0; d < 2; ++d)
        c = c.then(void 0, function () {
          return Bg(th(b));
        });
      return c.then(
        function () {
          uh[a] = 3;
        },
        function () {
          Ch(xh, a);
          return Wf();
        }
      );
    },
    Eh = function (a) {
      if (zh(a)) return vh[a];
      uh[a] = 1;
      for (
        var b = [],
          c = DEPS_GRAPH ? DEPS_GRAPH[[a, "module"].join("")] : [],
          d = c.length - 1;
        d >= 0;
        d--
      ) {
        var e = c[d].replace(/module$/, "");
        if (e == a) break;
        zh(e) ? b.push(vh[e]) : b.push(Eh(e));
      }
      b = Zf(b).then(function () {
        return Dh(a);
      });
      return (vh[a] = b);
    },
    Fh = function (a, b) {
      a = Eh(a);
      typeof b === "function" && (a = a.then(b));
      a = a.then(
        function () {},
        function () {}
      );
    };
  v("studioLoader.context.evalInContext", Bh);
  var Gh = oa(["https://tpc.googlesyndication.com/sodar/", ".js"]),
    Hh = oa(["https://ep2.adtrafficquality.google/sodar/", ".js"]),
    Ih = oa(["https://www.google.com/recaptcha/api2/aframe"]);
  Rd(Ih);
  function Jh(a) {
    var b = window,
      c = !0;
    c = c === void 0 ? !1 : c;
    new Promise(function (d, e) {
      function f() {
        g.onload = null;
        g.onerror = null;
        var l;
        (l = g.parentElement) == null || l.removeChild(g);
      }
      var g = b.document.createElement("script");
      g.onload = function () {
        f();
        d();
      };
      g.onerror = function () {
        f();
        e(void 0);
      };
      g.type = "text/javascript";
      Id(g, a);
      c && b.document.readyState !== "complete"
        ? te(b, function () {
            b.document.body.appendChild(g);
          })
        : b.document.body.appendChild(g);
    });
  }
  var Kh = {},
    Lh =
      ((Kh["internal-error"] = -1),
      (Kh["non-recoverable-error"] = -2),
      (Kh["api-disabled-by-application"] = -3),
      (Kh["invalid-argument"] = -4),
      (Kh["token-provider-invalid"] = -5),
      Kh),
    Mh = function () {
      this.na = !1;
    },
    Nh,
    Oh = function () {
      Nh || (Nh = new Mh());
      return Nh;
    },
    Ph = function (a) {
      var b;
      Da(function (c) {
        if (c.g == 1)
          return (
            (c.l = 2),
            va(
              c,
              window.android.webview.getExperimentalMediaIntegrityTokenProvider(
                { cloudProjectNumber: 187810013193 }
              ),
              4
            )
          );
        if (c.g != 2) (a.h = c.o), (a.g = void 0), (c.g = 0), (c.l = 0);
        else {
          b = wa(c);
          var d = 0;
          b.mediaIntegrityErrorName
            ? d || (d = Lh[b.mediaIntegrityErrorName])
            : b.code && (d = b.code());
          a.g = d;
          c.g = 0;
        }
      });
    };
  function Qh(a) {
    var b, c, d, e, f, g, l, m;
    return Da(function (n) {
      switch (n.g) {
        case 1:
          return (
            (b = a.xa
              ? "https://ep1.adtrafficquality.google/getconfig/sodar"
              : "https://pagead2.googlesyndication.com/getconfig/sodar"),
            (c = b + "?sv=200&tid=" + a.g + ("&tv=" + a.h + "&st=") + a.Ea),
            (d = void 0),
            (n.l = 2),
            va(n, Rh(c), 4)
          );
        case 4:
          d = n.o;
          n.g = 3;
          n.l = 0;
          break;
        case 2:
          wa(n);
        case 3:
          if (!d) return n.return(void 0);
          e = a.sb || d.sodar_query_id;
          f = d.rc_enable !== void 0 ? d.rc_enable : "n";
          g = d.bg_snapshot_delay_ms === void 0 ? "0" : d.bg_snapshot_delay_ms;
          l = d.is_gen_204 === void 0 ? "1" : d.is_gen_204;
          return e && d.bg_hash_basename && d.bg_binary
            ? ((m = {
                context: a.j,
                Qd: d.bg_hash_basename,
                Pd: d.bg_binary,
                De: a.g + "_" + a.h,
                sb: e,
                Ea: a.Ea,
                qb: f,
                yb: g,
                pb: l,
                xa: a.xa,
              }),
              a.na ? n.return(Object.assign({}, m, { na: !0 })) : n.return(m))
            : n.return(void 0);
      }
    });
  }
  var Rh = function (a) {
    return new Promise(function (b, c) {
      var d = new XMLHttpRequest();
      d.onreadystatechange = function () {
        d.readyState === d.DONE &&
          (d.status >= 200 && d.status < 300
            ? b(JSON.parse(d.responseText))
            : c());
      };
      d.open("GET", a, !0);
      d.send();
    });
  };
  function Sh() {
    var a = Th(),
      b;
    Da(function (c) {
      if (c.g == 1) {
        if (a.na) {
          Oh().na = !0;
          var d = Oh();
          window.android &&
            window.android.webview &&
            window.android.webview.getExperimentalMediaIntegrityTokenProvider &&
            d.na &&
            Ph(d);
        }
        return va(c, Qh(a), 2);
      }
      if ((b = c.o)) {
        d = b;
        var e = "sodar2";
        e = e === void 0 ? "sodar2" : e;
        var f = window,
          g = f.GoogleGcLKhOms;
        (g && typeof g.push === "function") || (g = f.GoogleGcLKhOms = []);
        var l = {};
        l =
          ((l._ctx_ = d.context),
          (l._bgv_ = d.Qd),
          (l._bgp_ = d.Pd),
          (l._li_ = d.De),
          (l._jk_ = d.sb),
          (l._st_ = d.Ea),
          (l._rc_ = d.qb),
          (l._dl_ = d.yb),
          (l._g2_ = d.pb),
          (l._atqg_ = d.xa === void 0 ? "0" : d.xa ? "1" : "0"),
          l);
        if (d.na) {
          var m = {};
          g.push(Object.assign({}, l, ((m._wvp_ = "1"), m)));
        } else g.push(l);
        if ((g = f.GoogleDX5YKUSk)) (f.GoogleDX5YKUSk = void 0), g[1]();
        d = d.xa ? Rd(Hh, e) : Rd(Gh, e);
        Jh(d);
      }
      return c.return(b);
    });
  }
  var Uh = function (a) {
      this.g = a.g;
      this.h = a.h;
      this.j = a.j;
      this.sb = a.sb;
      this.Ea = a.Ea;
      this.qb = a.qb;
      this.yb = a.yb;
      this.pb = a.pb;
      this.xa = a.xa;
      this.na = a.na;
    },
    Vh = function () {
      this.g = "xfad";
      this.h = "01_262";
      this.j = "cr";
      this.Ea = "env";
      this.qb = "n";
      this.yb = "0";
      this.pb = "1";
      this.na = this.xa = !1;
    },
    Th = function () {
      var a = new Vh();
      a.Ea = "int";
      return new Uh(a);
    };
  var Wh = function (a) {
    this.g = Lc(a);
  };
  p(Wh, $c);
  var Xh = function (a) {
    this.g = Lc(a);
  };
  p(Xh, $c);
  var Zh = function (a) {
      this.g = new J();
      this.size = 0;
      a && Yh(this, a);
    },
    $h = function (a) {
      var b = typeof a;
      return (b == "object" && a) || b == "function"
        ? "o" + Qa(a)
        : b.slice(0, 1) + a;
    };
  Zh.prototype.T = function () {
    return this.g.size;
  };
  Zh.prototype.add = function (a) {
    this.g.set($h(a), a);
    this.size = this.g.size;
  };
  var Yh = function (a, b) {
    b = Fe(b);
    for (var c = b.length, d = 0; d < c; d++) a.add(b[d]);
    a.size = a.g.size;
  };
  h = Zh.prototype;
  h.delete = function (a) {
    var b = this.g;
    a = $h(a);
    b = b.delete(a);
    this.size = this.g.size;
    return b;
  };
  h.clear = function () {
    this.g.clear();
    this.size = 0;
  };
  h.has = function (a) {
    return this.g.da($h(a));
  };
  h.contains = function (a) {
    return this.g.da($h(a));
  };
  h.U = function () {
    return this.g.U();
  };
  h.values = function () {
    return this.g.values();
  };
  h.equals = function (a) {
    return this.T() == Ee(a) && ai(this, a);
  };
  var ai = function (a, b) {
    var c = Ee(b);
    if (a.T() > c) return !1;
    !(b instanceof Zh) && c > 5 && (b = new Zh(b));
    return Ie(a, function (d) {
      return He(b, d);
    });
  };
  Zh.prototype.ua = function () {
    return this.g.ua(!1);
  };
  Zh.prototype[Symbol.iterator] = function () {
    return this.values();
  };
  v("studio.common.Feature.Type", {
    Wf: 1,
    SDK_EVENT_FORWARDER: 2,
    RL_EVENT_FORWARDER: 3,
  });
  var bi = new Zh();
  v("studio.common.Feature.hasFeature", function (a) {
    return bi.has(a);
  });
  v("studio.common.Feature.hasFeatures", function (a) {
    return Ie(a, bi.contains, bi);
  });
  var ci = function (a, b) {
      this.h = a;
      this.g = b != null ? b : 0;
    },
    di = function () {
      var a = window;
      return a.innerWidth > a.innerHeight ? "landscape" : "portrait";
    },
    ei = function () {
      return "onorientationchange" in window;
    };
  ci.prototype.ke = function () {
    return this.h;
  };
  ci.prototype.je = function () {
    return this.g;
  };
  ci.prototype.toString = function () {
    return this.h;
  };
  v("studio.common.Orientation", ci);
  ci.prototype.getDegrees = ci.prototype.je;
  ci.prototype.getMode = ci.prototype.ke;
  ci.Mode = { PORTRAIT: "portrait", LANDSCAPE: "landscape" };
  function fi(a, b) {
    return b ? a.replace("[rm_exit_id]", b) : a;
  }
  function gi(a) {
    Ya(Md(a)) ||
      "market" != (a.match(xe)[1] || null) ||
      ((a = a.match(xe)),
      (a =
        "https://play.google.com/store/apps/details" +
        we(null, null, null, null, a[5], a[6], a[7])));
    return a;
  }
  var hi = {
    CREATIVETOOLSET_CONFIG: "creativeToolsetConfig",
    CREATIVETOOLSET_INTERNALS: "creativeToolsetInternals",
    CREATIVETOOLSET_INTERNALS_GEN204: "creativeToolsetInternalsGen204",
    CREATIVE_REPORTER: "creativeReporter",
    CREATIVE_INNOVATION: "gcreativeinnovation",
    GOOGLE_AFMA_SUPPORT: "googleAfmaSupport",
  };
  v("studio.common.WhitelistedExternalObject", hi);
  var ii = {};
  var M = function (a) {
    E.call(this);
    this.A = a;
    this.j = {};
  };
  y(M, E);
  var ji = [],
    N = function (a, b, c, d, e, f) {
      Array.isArray(c) || (c && (ji[0] = c.toString()), (c = ji));
      for (var g = 0; g < c.length; g++) {
        var l = eh(b, c[g], d || a.handleEvent, e || !1, f || a.A || a);
        if (!l) break;
        a.j[l.key] = l;
      }
    },
    ki = function (a, b, c, d, e, f) {
      if (Array.isArray(c))
        for (var g = 0; g < c.length; g++) ki(a, b, c[g], d, e, f);
      else
        (b = ch(b, c, d || a.handleEvent, e, f || a.A || a)) &&
          (a.j[b.key] = b);
    },
    li = function (a, b, c, d, e, f) {
      if (Array.isArray(c))
        for (var g = 0; g < c.length; g++) li(a, b, c[g], d, e, f);
      else if (
        (b = nh(
          b,
          c,
          d || a.handleEvent,
          w(e) ? !!e.capture : !!e,
          f || a.A || a
        ))
      )
        mh(b), delete a.j[b.key];
    },
    mi = function (a) {
      bd(
        a.j,
        function (b, c) {
          this.j.hasOwnProperty(c) && mh(b);
        },
        a
      );
      a.j = {};
    };
  M.prototype.C = function () {
    M.M.C.call(this);
    mi(this);
  };
  M.prototype.handleEvent = function () {
    throw Error("EventHandler.handleEvent not implemented");
  };
  var ni = { 1: "NativeMessagingTransport" },
    oi = ["pu", "lru", "pru", "lpu", "ppu"],
    qi = function () {
      for (var a = 10, b = pi, c = b.length, d = ""; a-- > 0; )
        d += b.charAt(Math.floor(Math.random() * c));
      return d;
    },
    pi = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
  var ri = function (a) {
    E.call(this);
    this.h = a || Yd();
  };
  y(ri, E);
  ri.prototype.G = 0;
  ri.prototype.getName = function () {
    return ni[String(this.G)] || "";
  };
  var si = function (a, b) {
    ri.call(this, b);
    this.g = a;
    this.F = new M(this);
    ve(this, this.F);
    this.A = new rh(100, this.h.g.defaultView);
    ve(this, this.A);
    this.l = new I();
    this.v = new I();
    this.j = new I();
    this.D = qi();
    this.B = null;
    this.o = {};
    this.J = this.g.name;
    this.g.Za(this.g.name + "_" + this.g.ha());
    this.I = !1;
    tg(this.j, this.l);
    tg(this.j, this.v);
    rg(this.j, this.vd, this);
    this.j.callback(!0);
    N(this.F, this.A, "tick", this.Xb);
  };
  p(si, ri);
  var vi = function (a) {
    var b = new ti(a.channelName, a.service, a.payload);
    a = b.g;
    var c = b.j;
    b = b.h;
    var d = ii[a];
    if (d) return d.pa(c, b), !0;
    d = ui(b)[0];
    for (var e in ii) {
      var f = ii[e];
      if (f.ha() == 1 && !f.isConnected() && c == "tp" && d == "SETUP")
        return f.Za(a), f.pa(c, b), !0;
    }
    return !1;
  };
  h = si.prototype;
  h.zb = function (a) {
    a = ui(a);
    var b = a[1];
    switch (a[0]) {
      case "SETUP_ACK":
        this.l.g || this.l.callback(!0);
        break;
      case "SETUP":
        this.R("tp", "SETUP_ACK"),
          this.v.g || this.v.callback(!0),
          this.B != null && this.B != b && this.R("tp", "SETUP," + this.D),
          (this.B = b);
    }
  };
  h.connect = function () {
    var a = this.h.g.defaultView;
    if (a) {
      var b = Qa(a);
      (wi[b] || 0) == 0 &&
        Ia("crosswindowmessaging.channel", a) == null &&
        v("crosswindowmessaging.channel", vi, a);
      wi[b]++;
      this.I = !0;
      this.Xb();
    }
  };
  h.Xb = function () {
    this.g.isConnected()
      ? this.A.stop()
      : (this.A.start(), this.R("tp", "SETUP," + this.D));
  };
  h.R = function (a, b) {
    this.g.W &&
      ((a = new ti(this.J + "_" + (this.g.ha() == 0 ? 1 : 0), a, b)),
      this.g.g.directSyncMode
        ? this.tc(a)
        : (this.o[Qa(a)] = sh(x(this.tc, this, a), 0)));
  };
  h.tc = function (a) {
    var b = Qa(a);
    this.o[b] && delete this.o[b];
    try {
      var c = Ia("crosswindowmessaging.channel", this.g.W);
    } catch (d) {
      return;
    }
    if (c !== null)
      try {
        c({ channelName: a.g, service: a.j, payload: a.h });
      } catch (d) {}
  };
  h.vd = function () {
    xi(this.g, 0);
  };
  h.C = function () {
    if (this.I) {
      var a = this.h.g.defaultView,
        b = Qa(a);
      --wi[b] == 1 && v("crosswindowmessaging.channel", null, a);
    }
    this.o &&
      (bd(this.o, function (c) {
        r.clearTimeout(c);
      }),
      (this.o = null));
    this.l && (this.l.cancel(), delete this.l);
    this.v && (this.v.cancel(), delete this.v);
    this.j && (this.j.cancel(), delete this.j);
    ri.prototype.C.call(this);
  };
  var ui = function (a) {
      a = a.split(",");
      a[1] = a[1] || null;
      return a;
    },
    wi = {};
  si.prototype.G = 2;
  var ti = function (a, b, c) {
    this.g = a;
    this.j = b;
    this.h = c;
  };
  var yi = function (a, b, c, d, e) {
    ri.call(this, c);
    this.o = a;
    this.A = e || 2;
    this.ga = b || "*";
    this.I = new M(this);
    this.B = new rh(100, this.h.g.defaultView);
    this.J = !!d;
    this.l = new I();
    this.v = new I();
    this.j = new I();
    this.X = qi();
    this.F = null;
    this.J
      ? this.o.ha() == 1
        ? tg(this.j, this.l)
        : tg(this.j, this.v)
      : (tg(this.j, this.l), this.A == 2 && tg(this.j, this.v));
    rg(this.j, this.ma, this);
    this.j.callback(!0);
    this.ta = wb() <= 10;
    N(this.I, this.B, "tick", this.S);
  };
  p(yi, ri);
  var Ai = function (a) {
    var b = a.Y.data;
    if (typeof b !== "string") return !1;
    var c = b.indexOf("|"),
      d = b.indexOf(":");
    if (c == -1 || d == -1) return !1;
    var e = b.substring(0, c);
    c = b.substring(c + 1, d);
    b = b.substring(d + 1);
    if ((d = ii[e])) return d.pa(c, b, a.Y.origin), !0;
    d = zi(b)[0];
    for (var f in ii) {
      var g = ii[f];
      if (
        g.ha() == 1 &&
        !g.isConnected() &&
        c == "tp" &&
        (d == "SETUP" || d == "SETUP_NTPV2") &&
        g.Va(a.Y.origin)
      )
        return g.Za(e), g.pa(c, b), !0;
    }
    return !1;
  };
  yi.prototype.zb = function (a) {
    var b = zi(a);
    a = b[1];
    switch (b[0]) {
      case "SETUP_ACK":
        Bi(this, 1);
        this.l.g || this.l.callback(!0);
        break;
      case "SETUP_ACK_NTPV2":
        this.A == 2 && (Bi(this, 2), this.l.g || this.l.callback(!0));
        break;
      case "SETUP":
        Bi(this, 1);
        Ci(this, 1);
        break;
      case "SETUP_NTPV2":
        this.A == 2 &&
          ((b = this.g),
          Bi(this, 2),
          Ci(this, 2),
          (b != 1 && this.F == null) || this.F == a || Di(this),
          (this.F = a));
    }
  };
  var Di = function (a) {
      a.A != 2 || (a.g != null && a.g != 2) || a.R("tp", "SETUP_NTPV2," + a.X);
      (a.g != null && a.g != 1) || a.R("tp", "SETUP");
    },
    Ci = function (a, b) {
      if (a.A != 2 || (a.g != null && a.g != 2) || b != 2) {
        if ((a.g != null && a.g != 1) || b != 1) return;
        a.R("tp", "SETUP_ACK");
      } else a.R("tp", "SETUP_ACK_NTPV2");
      a.v.g || a.v.callback(!0);
    },
    Bi = function (a, b) {
      b > a.g && (a.g = b);
      a.g == 1 && (a.v.g || a.J || a.v.callback(!0), (a.F = null));
    };
  yi.prototype.connect = function () {
    var a = this.h.g.defaultView,
      b = Qa(a),
      c = Ei[b];
    typeof c !== "number" && (c = 0);
    c == 0 && eh(a.postMessage ? a : a.document, "message", Ai, !1, yi);
    Ei[b] = c + 1;
    this.N = !0;
    this.S();
  };
  yi.prototype.S = function () {
    var a = this.o.ha() == 0;
    (this.J && a) || this.o.isConnected() || this.isDisposed()
      ? this.B.stop()
      : (this.B.start(), Di(this));
  };
  var Fi = function (a, b, c) {
    var d = a.o.W,
      e = a.o.name;
    a.D = 0;
    try {
      var f = d.postMessage ? d : d.document;
      f.postMessage && f.postMessage(e + "|" + b + ":" + c, a.ga);
    } catch (g) {}
  };
  yi.prototype.R = function (a, b) {
    var c = this;
    this.o.W &&
      (this.ta
        ? (this.D = sh(function () {
            return void Fi(c, a, b);
          }, 0))
        : Fi(this, a, b));
  };
  yi.prototype.ma = function () {
    xi(this.o, this.A == 1 || this.g == 1 ? 200 : void 0);
  };
  yi.prototype.C = function () {
    if (this.N) {
      var a = this.h.g.defaultView;
      if (a) {
        var b = Qa(a),
          c = Ei[b];
        Ei[b] = c - 1;
        c === 1 && lh(a.postMessage ? a : a.document, "message", Ai, !1, yi);
      }
    }
    this.D && (r.clearTimeout(this.D), (this.D = 0));
    D(this.I);
    delete this.I;
    D(this.B);
    delete this.B;
    this.l.cancel();
    delete this.l;
    this.v.cancel();
    delete this.v;
    this.j.cancel();
    delete this.j;
    delete this.R;
    ri.prototype.C.call(this);
  };
  var zi = function (a) {
    a = a.split(",");
    a[1] = a[1] || null;
    return a;
  };
  yi.prototype.g = null;
  yi.prototype.N = !1;
  yi.prototype.G = 1;
  var Ei = {};
  yi.prototype.D = 0;
  function Gi(a, b, c) {
    E.call(this);
    this.g = a;
    this.j = b || 0;
    this.h = c;
    this.l = x(this.Xd, this);
  }
  y(Gi, E);
  h = Gi.prototype;
  h.Pa = 0;
  h.C = function () {
    Gi.M.C.call(this);
    this.stop();
    delete this.g;
    delete this.h;
  };
  h.start = function (a) {
    this.stop();
    this.Pa = sh(this.l, a !== void 0 ? a : this.j);
  };
  h.stop = function () {
    this.isActive() && r.clearTimeout(this.Pa);
    this.Pa = 0;
  };
  h.isActive = function () {
    return this.Pa != 0;
  };
  h.Xd = function () {
    this.Pa = 0;
    this.g && this.g.call(this.h);
  };
  var Ji = function (a) {
      var b = [];
      Hi(new Ii(), a, b);
      return b.join("");
    },
    Ii = function () {},
    Hi = function (a, b, c) {
      if (b == null) c.push("null");
      else {
        if (typeof b == "object") {
          if (Array.isArray(b)) {
            var d = b;
            b = d.length;
            c.push("[");
            for (var e = "", f = 0; f < b; f++)
              c.push(e), Hi(a, d[f], c), (e = ",");
            c.push("]");
            return;
          }
          if (
            b instanceof String ||
            b instanceof Number ||
            b instanceof Boolean
          )
            b = b.valueOf();
          else {
            c.push("{");
            e = "";
            for (d in b)
              Object.prototype.hasOwnProperty.call(b, d) &&
                ((f = b[d]),
                typeof f != "function" &&
                  (c.push(e), Ki(d, c), c.push(":"), Hi(a, f, c), (e = ",")));
            c.push("}");
            return;
          }
        }
        switch (typeof b) {
          case "string":
            Ki(b, c);
            break;
          case "number":
            c.push(isFinite(b) && !isNaN(b) ? String(b) : "null");
            break;
          case "boolean":
            c.push(String(b));
            break;
          case "function":
            c.push("null");
            break;
          default:
            throw Error("Unknown type: " + typeof b);
        }
      }
    },
    Li = {
      '"': '\\"',
      "\\": "\\\\",
      "/": "\\/",
      "\b": "\\b",
      "\f": "\\f",
      "\n": "\\n",
      "\r": "\\r",
      "\t": "\\t",
      "\v": "\\u000b",
    },
    Mi = /\uffff/.test("\uffff")
      ? /[\\"\x00-\x1f\x7f-\uffff]/g
      : /[\\"\x00-\x1f\x7f-\xff]/g,
    Ki = function (a, b) {
      b.push(
        '"',
        a.replace(Mi, function (c) {
          var d = Li[c];
          d ||
            ((d = "\\u" + (c.charCodeAt(0) | 65536).toString(16).slice(1)),
            (Li[c] = d));
          return d;
        }),
        '"'
      );
    };
  var Ni = function () {
    E.call(this);
    this.A = {};
  };
  y(Ni, E);
  Ni.prototype.connect = function (a) {
    a && a();
  };
  Ni.prototype.isConnected = function () {
    return !0;
  };
  Ni.prototype.bb = function (a, b, c) {
    this.A[a] = { callback: b, Sc: !!c };
  };
  Ni.prototype.bd = function (a) {
    this.o = a;
  };
  var Oi = function (a, b, c) {
    var d = a.A[b];
    if ((a = d ? d : a.o ? { callback: Ta(a.o, b), Sc: w(c) } : null)) {
      a: {
        if ((b = a.Sc) && typeof c === "string")
          try {
            var e = JSON.parse(c);
            break a;
          } catch (f) {
            e = null;
            break a;
          }
        else if (!b && typeof c !== "string") {
          e = Ji(c);
          break a;
        }
        e = c;
      }
      c = e;
      c != null && a.callback(c);
    }
  };
  Ni.prototype.C = function () {
    Ni.M.C.call(this);
    delete this.A;
    delete this.o;
  };
  var Qi = function (a, b) {
    Ni.call(this);
    for (var c, d = 0; (c = oi[d]); d++)
      if (c in a && !/^https?:\/\//.test(a[c]))
        throw Error("URI " + a[c] + " is invalid for field " + c);
    this.g = a;
    this.name = this.g.cn || qi();
    this.j = b || Yd();
    this.l = [];
    this.v = new M(this);
    a.lpu = a.lpu || ze(this.j.g.defaultView.location.href) + "/robots.txt";
    a.ppu = a.ppu || ze(a.pu || "") + "/robots.txt";
    ii[this.name] = this;
    nh(window, "unload", Pi) || ch(window, "unload", Pi);
  };
  p(Qi, Ni);
  Qi.prototype.isConnected = function () {
    return this.Ia == 2;
  };
  Qi.prototype.connect = function (a) {
    this.h = a || function () {};
    this.Ia == 3 && (this.Ia = 1);
    this.ya ? rg(this.ya, this.B) : this.B();
  };
  Qi.prototype.B = function () {
    this.ya = null;
    this.g.ifrid && (this.ab = this.j.getElement(this.g.ifrid));
    if (this.ab) {
      var a = this.ab.contentWindow;
      a || (a = window.frames[this.g.ifrid]);
      this.W = a;
    }
    if (!this.W) {
      if (window == window.top)
        throw Error(
          "CrossPageChannel: Can't connect, peer window-object not set."
        );
      this.W = window.parent;
    }
    if (!this.fa) {
      this.g.tp ||
        (this.g.tp =
          typeof document.postMessage === "function" ||
          typeof window.postMessage === "function" ||
          (Rb && window.postMessage)
            ? 1
            : 0);
      if (typeof this.g.tp === "function")
        this.fa = new this.g.tp(this, this.j);
      else
        switch (this.g.tp) {
          case 1:
            this.fa = new yi(
              this,
              this.g.ph,
              this.j,
              !!this.g.osh,
              this.g.nativeProtocolVersion || 2
            );
            break;
          case 2:
            if ((a = this.W))
              try {
                a = window.document.domain == this.W.document.domain;
              } catch (b) {
                a = !1;
              }
            a && (this.fa = new si(this, this.j));
        }
      if (!this.fa)
        throw Error(
          "CrossPageChannel: No suitable transport found! You may try injecting a Transport constructor directly via the channel config object."
        );
    }
    for (this.fa.connect(); this.l.length > 0; ) this.l.shift()();
  };
  Qi.prototype.close = function () {
    this.ya && (this.ya.cancel(), (this.ya = null));
    this.l.length = 0;
    mi(this.v);
    this.Ia = 3;
    D(this.fa);
    this.h = this.fa = null;
    D(this.qa);
    this.qa = null;
  };
  var xi = function (a, b) {
    a.isConnected() ||
      (a.qa && a.qa.isActive()) ||
      ((a.Ia = 2),
      D(a.qa),
      b !== void 0
        ? ((a.qa = new Gi(a.h, b)), a.qa.start())
        : ((a.qa = null), a.h()));
  };
  h = Qi.prototype;
  h.Qa = function (a, b) {
    if (this.isConnected()) {
      try {
        var c = !!this.W && !this.W.closed;
      } catch (e) {
        c = !1;
      }
      if (c) {
        w(b) && (b = Ji(b));
        c = this.fa;
        var d = c.R;
        Ri.test(a) && (a = "%" + a);
        a = a.replace(/[%:|]/g, encodeURIComponent);
        d.call(c, a, b);
      } else this.close();
    }
  };
  h.pa = function (a, b, c) {
    this.ya
      ? this.l.push(x(this.pa, this, a, b, c))
      : this.Va(c) &&
        !this.isDisposed() &&
        this.Ia != 3 &&
        (a && a != "tp"
          ? this.isConnected() &&
            ((a = a.replace(/%[0-9a-f]{2}/gi, decodeURIComponent)),
            (a = Si.test(a) ? a.substring(1) : a),
            Oi(this, a, b))
          : this.fa.zb(b));
  };
  h.ha = function () {
    var a = this.g.role;
    return typeof a === "number" ? a : window.parent == this.W ? 1 : 0;
  };
  h.Za = function (a) {
    delete ii[this.name];
    this.name = a;
    ii[a] = this;
  };
  h.Va = function (a) {
    var b = this.g.ph;
    return Ya(Md(a)) || Ya(Md(b)) || a == this.g.ph;
  };
  h.C = function () {
    this.close();
    this.ab = this.W = null;
    delete ii[this.name];
    D(this.v);
    delete this.v;
    Ni.prototype.C.call(this);
  };
  var Pi = function () {
      for (var a in ii) D(ii[a]);
    },
    Ri = RegExp("^%*tp$"),
    Si = RegExp("^%+tp$");
  h = Qi.prototype;
  h.qa = null;
  h.ya = null;
  h.fa = null;
  h.Ia = 1;
  h.W = null;
  h.ab = null;
  var Ti = {
      Cf: "devicemotion",
      Df: "deviceorientation",
      Sf: "hostpageScroll",
      Hf: "enterViewport",
      If: "exitViewport",
      vf: "adLocation",
    },
    Ui = {},
    Vi;
  for (Vi in Ti) Ui[Ti[Vi]] = !0;
  var O = function (a) {
    K.call(this, a);
  };
  p(O, K);
  O.prototype.aa = function (a, b) {
    this[a] = b;
    return this;
  };
  v("studio.events.StudioEvent", O);
  O.prototype.addProperty = O.prototype.aa;
  O.INIT = "init";
  O.VISIBLE = "visible";
  O.HIDDEN = "hidden";
  O.VISIBILITY_CHANGE = "visibilityChange";
  O.VISIBILITY_CHANGE_WITH_INFO = "visibilityChangeWithInfo";
  O.EXIT = "exit";
  O.INTERACTION = "interaction";
  O.PAGE_LOADED = "pageLoaded";
  O.ORIENTATION = "orientation";
  O.ABOUT_TO_EXPAND = "aboutToExpand";
  O.EXPAND_START = "expandStart";
  O.EXPAND_FAILED = "expandFailed";
  O.EXPAND_FINISH = "expandFinish";
  O.COLLAPSE_START = "collapseStart";
  O.COLLAPSE_FINISH = "collapseFinish";
  O.COLLAPSE = "collapse";
  O.FULLSCREEN_SUPPORT = "fullscreenSupport";
  O.HOSTPAGE_FEATURES_LOADED = "hostpageFeaturesLoaded";
  O.FULLSCREEN_DIMENSIONS = "fullscreenDimensions";
  O.FULLSCREEN_EXPAND_START = "fullscreenExpandStart";
  O.FULLSCREEN_EXPAND_FINISH = "fullscreenExpandFinish";
  O.FULLSCREEN_COLLAPSE_START = "fullscreenCollapseStart";
  O.FULLSCREEN_COLLAPSE_FINISH = "fullscreenCollapseFinish";
  O.HOSTPAGE_SCROLL = "hostpageScroll";
  O.OPTIONAL_HOSTPAGE_SCROLL = "optHostpageScroll";
  O.SCROLL_INTERACTION = "scrollInteraction";
  O.ENTER_VIEWPORT = "enterViewport";
  O.OPTIONAL_ENTER_VIEWPORT = "optEnterViewport";
  O.EXIT_VIEWPORT = "exitViewport";
  O.OPTIONAL_EXIT_VIEWPORT = "optExitViewport";
  O.VIDEO_START = "videoStart";
  var Wi = {},
    Xi =
      ((Wi.optHostpageScroll = "hostpageScroll"),
      (Wi.optEnterViewport = "enterViewport"),
      (Wi.optExitViewport = "exitViewport"),
      Wi);
  var Yi = function () {
    M.call(this);
    this.g = new Map();
    this.l = this.o = !1;
    this.h = this.v = null;
    this.g.set("nx", null);
    this.g.set("ny", null);
    this.g.set("dim", null);
  };
  p(Yi, M);
  Yi.prototype.B = function () {
    return (
      Ea.apply(0, arguments).reduce(function (a, b) {
        return a + b.length;
      }, 0) < 2040
    );
  };
  var Zi = function () {
      var a = ae();
      return a.width + "x" + a.height;
    },
    $i = function (a) {
      a.h || (a.h = window.GoogleA13IjpGc);
      return a.h && typeof a.h.snapshotSync === "function"
        ? a.h.snapshotSync()
        : null;
    };
  Yi.prototype.D = function (a) {
    var b = a.clientX,
      c = a.clientY;
    a.changedTouches &&
      a.changedTouches[0] &&
      ((b = a.changedTouches[0].clientX), (c = a.changedTouches[0].clientY));
    this.g.set("nx", Math.round(b));
    this.g.set("ny", Math.round(c));
    this.l && (this.v = $i(this));
  };
  Yi.prototype.C = function () {
    this.o = !1;
    M.prototype.C.call(this);
  };
  var aj = function (a) {
    this.g = a;
  };
  aj.prototype.toString = function () {
    return (this.g & 2 ? "b" : "t") + (this.g & 1 ? "r" : "l");
  };
  v("google3.javascript.ads.studio.common.mde.Direction.Direction", aj);
  aj.Corner = { dg: 0, eg: 1, wf: 2, xf: 3 };
  var bj = { TL: new aj(0), TR: new aj(1), BL: new aj(2), BR: new aj(3) },
    cj = ed(bj);
  var dj = {
      bg: "startExpandInternal",
      ag: "startCollapseInternal",
      Kf: "finishCollapseInternal",
      uf: "aboutToExpandInternal",
      Xf: "setAdVisibleInternal",
      Yf: "setAdParameters",
      Ef: "dispatchEvent",
      Zf: "setParameter",
      Rf: "getParameter",
      Qf: "fullscreenSupportInternal",
      Nf: "fullscreenDimensionsInternal",
      Pf: "fullscreenExpandStartInternal",
      Of: "fullscreenExpandFinishInternal",
      Mf: "fullscreenCollapseStartInternal",
      Lf: "fullscreenCollapseFinishInternal",
      Tf: "invokeOnAllVideos",
      Uf: "livePreviewChannel",
      Ff: "dispatchPageLoaded",
    },
    ej = {},
    fj;
  for (fj in dj) ej[dj[fj]] = !0;
  var gj = [
    /s0(qa)?\.2mdn\.net/,
    /^.*\.(prod|corp)\.google\.com/,
    /localhost/,
    /tpc\.googlesyndication\.com/,
    /secureframe\.doubleclick\.net/,
    /imasdk\.googleapis\.com/,
    /^.*dot-expandable-ad-tool\.appspot\.com/,
  ];
  function hj() {
    var a = location.hostname;
    return G(2) && !G(16)
      ? !1
      : Cb(gj, function (b) {
          return b.test(a);
        });
  }
  var ij = function (a) {
    E.call(this);
    this.h = a;
    this.g = {};
    this.h.bd(x(this.j, this));
  };
  y(ij, E);
  var kj = function (a, b) {
    if (b.indexOf(":") != -1)
      throw Error('Virtual channel name "' + b + '" should not contain colons');
    if (b in a.g)
      throw Error(
        'Virtual channel "' + b + '" was already created for this multichannel.'
      );
    var c = new jj(a, b);
    return (a.g[b] = c);
  };
  ij.prototype.j = function (a, b) {
    if ((a = a.match(/^([^:]*):(.*)/))) {
      var c = a[1];
      a = a[2];
      c in this.g && (c = this.g[c]) && c.j && c.j(a, b);
    }
  };
  ij.prototype.C = function () {
    bd(this.g, function (a) {
      D(a);
    });
    D(this.h);
    delete this.g;
    delete this.h;
  };
  var jj = function (a, b) {
    E.call(this);
    this.g = a;
    this.h = b;
  };
  y(jj, E);
  h = jj.prototype;
  h.connect = function (a) {
    a && a();
  };
  h.isConnected = function () {
    return !0;
  };
  h.bb = function (a, b, c) {
    this.g.h.bb(this.h + ":" + a, x(this.qc, this, b), c);
  };
  h.bd = function (a) {
    this.j = x(this.qc, this, a);
  };
  h.Qa = function (a, b) {
    if (this.isDisposed())
      throw Error("#send called for disposed VirtualChannel.");
    this.g.h.Qa(this.h + ":" + a, b);
  };
  h.qc = function (a, b) {
    this.isDisposed() || a.apply({}, Array.prototype.slice.call(arguments, 1));
  };
  h.C = function () {
    this.g = this.g.g[this.h] = null;
  };
  function lj(a) {
    E.call(this);
    this.h = new ij(a);
    this.l = {};
    this.j = kj(this.h, "private");
    this.A = kj(this.h, "public");
    this.j.bb("mics", x(this.I, this), !0);
  }
  y(lj, E);
  lj.prototype.J = 0;
  lj.prototype.C = function () {
    D(this.h);
    delete this.h;
    delete this.A;
    delete this.j;
  };
  var mj = function (a, b, c, d) {
    var e = a.J++;
    a.l[e] = d;
    d = { signature: e };
    d.data = c;
    a.A.Qa(b, d);
  };
  lj.prototype.I = function (a) {
    var b = a.signature;
    a = a.data;
    b in this.l && ((0, this.l[b])(a), delete this.l[b]);
  };
  var nj = function (a, b, c) {
    a.A.bb(b, x(a.G, a, c), !0);
  };
  lj.prototype.G = function (a, b) {
    a = a(b.data);
    var c = b.signature;
    Vf(a).then(
      x(function (d) {
        var e = {};
        e.data = d;
        e.signature = c;
        this.j && this.j.Qa("mics", e);
      }, this)
    );
  };
  var oj = function (a, b) {
    var c = this;
    a = a === void 0 ? "" : a;
    b = b === void 0 ? null : b;
    this.g = this.o = this.B = null;
    this.D = !1;
    var d = {},
      e = 1,
      f = window.parent;
    if (b != null)
      switch (b) {
        case 3:
          f = window;
        case 2:
          e = 2;
          d.directSyncMode = !0;
          break;
        case 4:
          f = window.parent.frames["goog-messaging-iframe"];
      }
    d.tp = e;
    d.role = 1;
    d.nativeProtocolVersion = 2;
    a && (d.cn = a);
    this.v = new Qi(d);
    this.v.W = f;
    lj.call(this, this.v);
    nj(this, "general", function (g) {
      a: {
        var l = g.methodName;
        g = g.args;
        if (l in ej) {
          if (c.g) {
            var m = c.g[l];
            typeof m !== "function" &&
              ((m = c.g.defaultMessageHandler), (g = [l, g]));
            if (typeof m === "function") {
              l = m.apply(c.g, g);
              break a;
            }
          }
          l = null;
        } else l = void 0;
      }
      return l;
    });
  };
  y(oj, lj);
  oj.prototype.connect = function (a) {
    (this.D || hj()) &&
      this.o &&
      ((this.B = Date.now()), this.v.connect(x(this.F, this, a)));
  };
  oj.prototype.F = function (a) {
    P(this, "conduitInitialized", [this.o, Array.from(bi.values())]);
    var b = { version: "01_262" };
    b.x = window.STUDIO_SDK_START || null;
    b.c = this.B;
    b.t = Date.now();
    P(this, "recordTimings", [b]);
    a && a();
  };
  var P = function (a, b, c, d) {
    var e = {};
    e.methodName = b;
    e.args = c && Array.isArray(c) ? c : [];
    mj(a, "general", e, d || function () {});
  };
  v("studio.sdk.ContainerState", {
    COLLAPSING: "collapsing",
    COLLAPSED: "collapsed",
    EXPANDING: "expanding",
    EXPANDED: "expanded",
    FS_COLLAPSING: "fs_collapsing",
    FS_EXPANDING: "fs_expanding",
    FS_EXPANDED: "fs_expanded",
  });
  var pj = { NONE: 0, LOG_ONLY: 1 };
  v("studio.sdk.ExitFlag", pj);
  pj.NONE = 0;
  pj.LOG_ONLY = 1;
  v("studio.sdk.MraidMethod", {
    GET_CURRENT_POSITION: "getCurrentPosition",
    GET_DEFAULT_POSITION: "getDefaultPosition",
    GET_SCREEN_SIZE: "getScreenSize",
    CREATE_CALENDAR_EVENT: "createCalendarEvent",
    GET_MAX_SIZE: "getMaxSize",
    PLAY_VIDEO: "playVideo",
    STORE_PICTURE: "storePicture",
    SUPPORTS: "supports",
    USE_CUSTOM_CLOSE: "useCustomClose",
  });
  var qj = function () {};
  v("studio.sdk.IEnabler", qj);
  h = qj.prototype;
  h.gd = function () {};
  h.reportManualClose = function () {};
  h.cd = function () {};
  h.jd = function () {};
  h.hd = function () {};
  h.isVisible = function () {};
  h.ja = function () {};
  h.isPageLoaded = function () {};
  h.isInitialized = function () {};
  h.kc = function () {};
  h.getParameter = function () {};
  h.exit = function () {};
  h.Mb = function () {};
  h.xc = function () {};
  h.counter = function () {};
  h.startTimer = function () {};
  h.stopTimer = function () {};
  h.zc = function () {};
  h.Cc = function () {};
  h.wb = function () {};
  h.Pb = function () {};
  h.Na = function () {};
  h.Ob = function () {};
  h.close = function () {};
  h.Ta = function () {};
  h.Wa = function () {};
  h.addEventListener = function () {};
  h.removeEventListener = function () {};
  h.ad = function () {};
  h.Zc = function () {};
  h.dd = function () {};
  h.wc = function () {};
  h.Tb = function () {};
  h.vc = function () {};
  h.Ec = function () {};
  h.Jc = function () {};
  var rj = function (a) {
      this.g = a;
      this.h = "";
    },
    uj = function (a, b, c) {
      for (var d = c.split("&"), e = 0; e < d.length; e++) {
        var f = d[e].split("=");
        if (f.length > 1 && f[0].length && f[1].length) {
          var g = decodeURIComponent(f[0]);
          f = decodeURIComponent(f[1]);
          a.g.set(g, f);
        }
      }
      if (a.g != null && a.g.da("exitEvents")) {
        d = {};
        e = a.g.get("exitEvents").toString();
        g = e.split("{DELIM}");
        for (f = 0; f < g.length; f++) {
          var l = g[f];
          gb(e, "%2C") && (l = unescape(l));
          var m = {};
          l = l.split(",");
          for (var n = 0; n < l.length; n++)
            if (sj.test(l[n])) {
              l[n].replace(tj, "%25$1!");
              var q = l[n].split(":"),
                t = q.shift();
              m[t] = unescape(q.join(":"));
            }
          d[m.name] = m;
        }
        b.exitEvents = d;
      }
      a.h = c;
    };
  rj.prototype.get = function (a, b) {
    return this.g.get(a, b);
  };
  rj.prototype.set = function (a, b) {
    return this.g.set(a, b);
  };
  rj.prototype.da = function (a) {
    return this.g.da(a);
  };
  var sj = /:/,
    tj = /%(.+)!/;
  var vj = function (a) {
      this.g = {};
      this.h = new rj(a);
    },
    wj = function (a, b, c, d) {
      var e = c;
      d == "Number"
        ? (e = parseInt(c, 10))
        : d == "Boolean" && (e = c.toLowerCase() == "true" || c == "1");
      a.g[b] = e;
    },
    xj = function (a, b) {
      try {
        var c = JSON.parse(b);
        c != null && ld(a.g, c);
        var d = {};
        bd(
          a.g,
          function (e, f) {
            e &&
              !w(e) &&
              ((f = decodeURIComponent(f)), (e = decodeURIComponent(e)));
            f && e && (d[f] = e);
          },
          a
        );
        a.g = d;
      } catch (e) {
        uj(a.h, a.g, b);
      }
    },
    yj = function (a, b) {
      var c = a.g;
      return (c !== null && b in c) || a.h.da(b);
    };
  vj.prototype.getParameter = function (a, b) {
    var c = this.g;
    return c !== null && a in c ? gd(this.g, a) : this.h.get(a, b);
  };
  vj.prototype.P = function (a) {
    a = parseInt(this.getParameter(a), 10);
    return isNaN(a) ? null : a;
  };
  vj.prototype.Z = function (a) {
    a = this.getParameter(a);
    return Ya(Md(a)) ? null : a.toString();
  };
  var zj = function (a) {
    return (a = a.exec(mb())) ? a[1] : "";
  };
  (function () {
    if (ac) return zj(/Firefox\/([0-9.]+)/);
    if (Rb || Sb || Qb) return $b;
    if (ec) {
      if (
        yb() ||
        (jb && nb && nb.platform ? nb.platform === "macOS" : z("Macintosh"))
      ) {
        var a = zj(/CriOS\/([0-9.]+)/);
        if (a) return a;
      }
      return zj(/Chrome\/([0-9.]+)/);
    }
    if (fc && !yb()) return zj(/Version\/([0-9.]+)/);
    if (bc || cc) {
      if ((a = /Version\/(\S+).*Mobile\/(\S+)/.exec(mb())))
        return a[1] + "." + a[2];
    } else if (dc)
      return (a = zj(/Android\s+([0-9.]+)/)) ? a : zj(/Version\/([0-9.]+)/);
    return "";
  })();
  var Aj = function () {
      this.g = !1;
      this.l = [];
    },
    Bj = function (a, b, c) {
      a.h ? P(a.h, b, c) : a.l.push({ type: b, Od: c });
    },
    Cj = function (a, b, c, d, e, f) {
      Bj(a, f ? "logEventFlushCounters" : "logEvent", [b, c, a.j, !!d, !!e]);
    },
    Ej = function (a) {
      a.g || (Cj(a, "Count", "INTERACTIVE_IMPRESSION"), (a.g = !0), Dj(a));
    },
    Dj = function (a) {
      Bj(a, "flushCounters", [a.j]);
    };
  Aj.prototype.ga = function (a, b, c) {
    Bj(this, "logVideoEvent", [a, escape(b), c]);
  };
  var Fj = function (a) {
    M.call(this);
    this.B = a;
    this.g = this.l = null;
    this.G = !1;
    this.h = null;
    this.v = !1;
    this.o = -1;
    this.D = 0;
  };
  p(Fj, M);
  Fj.prototype.Qb = function () {
    return this.G;
  };
  Fj.prototype.J = function () {
    this.D = 1;
    this.g && (this.g.stop(), this.g.start());
  };
  Fj.prototype.I = function () {
    this.D = 0;
    this.g && this.g.stop();
  };
  Fj.prototype.F = function () {
    this.B.getParameter("isMouseOver") == "1" || this.D == 1
      ? this.v ||
        ((this.G = !0),
        this.o < 1
          ? (this.o = Date.now())
          : 1e3 < Date.now() - this.o &&
            ((this.v = !0),
            this.B.dispatchEvent(new O("interaction")),
            P(this.B.H, "setTimerAdjustment", ["INTERACTION_TIMER", -1e3, 0]),
            this.l && (Cj(this.l, "Start", "INTERACTION_TIMER"), Ej(this.l))))
      : (this.v && Gj(this), (this.o = -1));
  };
  var Gj = function (a) {
    a.v = !1;
    a.l && Cj(a.l, "Stop", "INTERACTION_TIMER");
  };
  Fj.prototype.C = function () {
    this.v && Gj(this);
    ue(this.h, this.g);
    M.prototype.C.call(this);
  };
  var Hj = function () {
      return new Je(
        (window.STUDIO_ORIGINAL_ASSET_URL
          ? window.STUDIO_ORIGINAL_ASSET_URL
          : window.location.href
        ).replace(/%(?![A-Fa-f0-9][A-Fa-f0-9])/g, "%25")
      );
    },
    Ij = function (a) {
      a && wf(parseInt(a, 10) || 0);
    };
  var Jj = function (a) {
    this.g = a;
  };
  Jj.prototype.j = function (a) {
    return (null === this.g || this.g.canPlayType) && Xa(a, "video/");
  };
  Jj.prototype.h = function (a) {
    return this.g ? "probably" == this.g.canPlayType(a.toLowerCase()) : !1;
  };
  function Kj(a) {
    this.g = a;
  }
  Kj.prototype.j = function (a) {
    return "image/webp" == a.toLowerCase();
  };
  Kj.prototype.h = function (a) {
    if (!this.g) return !1;
    a = a.toLowerCase();
    return Xa(this.g.toDataURL(a), "data:" + a);
  };
  var Lj = function (a) {
    this.g = Lc(a);
  };
  p(Lj, $c);
  var Mj = oa(["https://securepubads.g.doubleclick.net/pagead/js/rum.js"]);
  var Nj = oa([
      "body {\n    position: relative;\n    margin-left: ",
      "px !important;\n    margin-top: ",
      "px !important;\n  }",
    ]),
    Oj = oa([""]),
    Q = function (a) {
      window.AdobeEdge = window.AdobeEdge || {};
      window.AdobeEdge.bootstrapLoading = !0;
      H.info("");
      if (a != Pj) return !1;
      L.call(this);
      this.D = {};
      this.o = {};
      this.J = new ci(di(), ei() ? window.orientation : 0);
      this.N = new M(this);
      this.ib = !1;
      this.G = null;
      this.j = "collapsed";
      this.Fb = !1;
      this.ta = null;
      this.qf = 0;
      this.gb = {};
      this.ma = null;
      this.Eb = !1;
      this.S = new I();
      this.l = null;
      this.Db = [];
      this.La = {};
      this.Hb = [];
      this.h = new Aj();
      this.X = new Fj(this);
      a = C("CANVAS");
      (a.getContext && a.getContext("2d")) || (a = null);
      this.sd = new Kj(a);
      (a = C("VIDEO")) || (a = null);
      this.Uc = new Jj(a);
      this.g = new vj(Qj(this));
      a = this.F = new Yi();
      a.o = !0;
      N(a, document.body || window, "mousedown", a.D, {
        capture: !0,
        passive: !0,
      });
      N(a, document.body || window, "touchstart", a.D, {
        capture: !0,
        passive: !0,
      });
      this.jc = {};
    };
  y(Q, L);
  v("studio.Enabler", Q);
  var Rj = ["c"],
    Pj = Math.random(),
    Sj = !1,
    Tj = null,
    R = function () {
      Tj || (Tj = new Q(Pj));
      return Tj;
    };
  Q.getInstance = R;
  h = Q.prototype;
  h.Yc = -1;
  h.Jb = null;
  h.Yb = null;
  h.Wb = null;
  h.kd = !0;
  h.Ab = !1;
  h.Ma = !1;
  h.Vc = !1;
  h.Zb = !1;
  h.Aa = null;
  h.Bb = null;
  h.va = null;
  h.H = null;
  var Uj = function (a) {
      a.Wb || (a.Wb = Hj());
      return a.Wb;
    },
    Qj = function (a) {
      var b = Uj(a).h;
      (a = ye(Uj(a).toString())) &&
        Be(a, function (c, d) {
          Rj.indexOf(c) > -1 && b.set(c, d);
        });
      return b;
    };
  Q.prototype.init = function () {
    if (!this.Ab) {
      var a = this.g.getParameter("e", null);
      Ij(a);
      a = this.P("leftOffset") || 0;
      var b = this.P("topOffset") || 0;
      (a == 0 && b == 0) || Vj(this, a, b);
      a = this.Dc("ssr");
      b = [Uj(this).l, "://", Uj(this).j, Uj(this).g].join("");
      bi.clear();
      Yh(bi, [1, 2]);
      this.H = new oj(this.g.getParameter("c", void 0), this.g.P("t"));
      ve(this, this.H);
      this.H.g = this;
      this.H.o = b.split("?")[0];
      this.H.D = a;
      this.ja() ||
        ((a = 1e3),
        Sj && (a = 0),
        (this.Aa = Wj(this, this.jf, "a", a)),
        (a = 2e3),
        (b = 2500),
        Sj && (b = a = 0),
        Wj(this, this.fc, "b", a),
        Wj(this, Ta(this.Gb, !0), "c", b),
        N(this.N, window, ["resize", "orientationchange"], this.Lc),
        this.Lc());
      this.H.connect();
    }
  };
  var Xj = function (a) {
      return !!yj(a.g, "newton_ot2_token");
    },
    Yj = function (a) {
      if (/Chrome/.test(window.navigator.userAgent)) {
        var b = String(a.g.getParameter("newton_ot2_token"));
        od(function (c) {
          c = c.document;
          if (b && c.head) {
            var d = Td("META");
            c.head.appendChild(d);
            d.httpEquiv = "origin-trial";
            d.content = b;
          }
          return !1;
        });
      }
    },
    bk = function (a) {
      a.Ab = !0;
      a.Bb = a.Bc();
      a.va = a.Ac();
      if (a.H) {
        var b = a.h,
          c = a.Bb;
        b.h = a.H;
        b.j = c;
        for (c = Ib(b.l); c.length; ) {
          var d = c.shift();
          Bj(b, d.type, d.Od);
        }
      }
      a.g.getParameter("clickN") == null && wj(a.g, "clickN", 1);
      a.kd = a.g.getParameter("ise") != "true";
      b = a.g.getParameter("e", null);
      b != null && Ij(b);
      b = a.P("leftOffset") || 0;
      c = a.P("topOffset") || 0;
      (b == 0 && c == 0) || Vj(a, b, c);
      a.o = a.g.getParameter("exitEvents", {});
      yj(a.g, "assets") &&
        ((b = a.g.getParameter("assets").toString()), Zj(a, b));
      b = a.g.getParameter("features", []);
      Yh(bi, b);
      a.X.l = a.h;
      b = a.X;
      G(2) &&
        (N(b, document.body || window, "mouseover", b.J),
        N(b, document.body || window, "mouseout", b.I));
      window.ontouchstart !== void 0 &&
        ((b.g = new rh(1e3)),
        N(b, b.g, "tick", b.I),
        N(b, document, ["touchstart", "touchmove"], b.J));
      b.h && (li(b, b.h, "tick", b.F), b.h.dispose());
      b.h = new rh(80);
      N(b, b.h, "tick", b.F);
      b.h.start();
      ak(a);
      if ((b = a.getParameter("layoutsConfig"))) a.Yb = JSON.parse(String(b));
      if ((b = a.getParameter("experiments"))) a.jc = JSON.parse(String(b));
      if ((b = a.getParameter("rum_config")))
        try {
          var e = JSON.parse(String(b));
          b = window;
          if (!b.google_rum_config && e) {
            var f = ad(Lj, Kc(e)),
              g = Yc(f, Xh);
            if (g) {
              var l = Yc(g, Wh);
              if (l) {
                b.google_timing_url =
                  "https://securepubads.g.doubleclick.net/pagead/js/rum.js";
                var m = Ec(3);
                Sc(l);
                var n = l.g;
                Vc(n, n[B] | 0, 2, m === 0 ? void 0 : m);
                var q = Jc(g);
                b.google_rum_config = q;
                var t = t === void 0 ? !1 : t;
                var u = Uc(f.g, 3);
                var F = u !== null ? u : void 0;
                var Y =
                  F == null || typeof F === "boolean"
                    ? F
                    : typeof F === "number"
                    ? !!F
                    : void 0;
                b.google_measure_js_timing = Y != null ? Y : t;
                var qa = b.document,
                  id = Rd(Mj),
                  dh = Td("SCRIPT", qa);
                Id(dh, id);
                var Ae = qa.getElementsByTagName("script")[0];
                if (Ae && Ae.parentNode) {
                  Ae.parentNode.insertBefore(dh, Ae);
                  var ml = dh;
                } else ml = null;
                ml ||
                  ((b.google_timing_url = void 0),
                  (b.google_rum_config = void 0),
                  (b.google_measure_js_timing = void 0));
              }
            }
          }
        } catch (ip) {}
      a.dispatchEvent(new O("init"));
      a.S.g || a.S.callback();
      e = a.F;
      e.l = !!a.jc.add_sodar_interaction_signals;
      if (e.l)
        try {
          Sh();
        } catch (ip) {}
      Xj(a) && Yj(a);
    };
  Q.prototype.af = function (a) {
    typeof a === "number"
      ? ((this.Yc = a), H.info("enabler.setProfileId set to: " + a))
      : H.info("enabler.setProfileId invalid profile id value: " + a);
  };
  Q.prototype.setProfileId = Q.prototype.af;
  Q.prototype.me = function () {
    return this.Yc;
  };
  Q.prototype.getProfileId = Q.prototype.me;
  Q.prototype.Xe = function (a) {
    w(a)
      ? ((this.Jb = a), this.isInitialized() && ak(this))
      : H.info("enabler.setDevDynamicContent invalid dcData value: " + a);
  };
  Q.prototype.setDevDynamicContent = Q.prototype.Xe;
  var ak = function (a) {
    if (a.Z("dcData") != null || a.Jb)
      window.dynamicContent = a.Z("dcData") != null ? a.nb() : a.Jb;
  };
  Q.prototype.nb = function () {
    var a = this.getParameter("dcData");
    return a ? JSON.parse(String(a)) : null;
  };
  Q.prototype.getDynamicDataPayload = Q.prototype.nb;
  Q.prototype.Ca = function () {
    return this.Yb;
  };
  Q.prototype.getLayoutsConfig = Q.prototype.Ca;
  Q.prototype.sf = function () {
    return this.g.h.h || Ji(this.g);
  };
  Q.prototype.getAdParameters = Q.prototype.sf;
  Q.prototype.rd = function (a) {
    xj(this.g, a);
    this.Aa && mh(this.Aa);
    bk(this);
    H.info("Asset properties have been set by host.");
  };
  Q.prototype.setAdParameters = Q.prototype.rd;
  Q.prototype.jf = function () {
    this.Aa && mh(this.Aa);
    H.info(
      "Using default ad parameters in test environment. Simulating local events."
    );
    bk(this);
  };
  Q.setRushSimulatedLocalEvents = function (a) {
    Sj = !!a;
    if (a && Tj) {
      a = Tj;
      for (var b = 0; b < a.Db.length; ++b) a.dispatchEvent(a.Db[b]);
    }
  };
  var Wj = function (a, b, c, d) {
    d = d != null ? d : 0;
    a.Db.push(c);
    sh(
      function () {
        this.dispatchEvent(c);
      },
      d,
      a
    );
    return ch(a, c, b, !1, a);
  };
  Q.prototype.Lc = function () {
    var a = di(),
      b = this.J.g;
    if (this.J.h != a || (ei() && this.J.g != window.orientation)) {
      ei() && (b = window.orientation);
      var c = new O("orientation");
      c.aa("mode", a);
      c.aa("degrees", b);
      this.dispatchEvent(c);
    }
  };
  Q.prototype.B = function (a, b, c) {
    if (!this.ja()) {
      var d = x.apply(
        this,
        [a, this].concat(Array.prototype.slice.call(arguments, 2))
      );
      sh(d, b);
    }
  };
  var Zj = function (a, b) {
    b.length > 0 && b.indexOf("=") == -1 && (b = decodeURIComponent(b));
    b = b.split("&");
    if (!(b.length <= 2 && b[0] == ""))
      for (var c = 0; c < b.length; c++) {
        var d = b[c].split("=");
        a.D[d[0].toLowerCase()] = unescape(d[1]);
      }
  };
  Q.prototype.A = function () {
    Dj(this.h);
  };
  Q.prototype.reportActivitiesImmediately = Q.prototype.A;
  var ck = function (a) {
      a.h && Ej(a.h);
    },
    dk = function (a, b) {
      var c = a.g.getParameter("click", ""),
        d = parseInt(a.g.getParameter("clickN"), 10);
      a = a.g.getParameter("thirdPartyClickRedirect", "");
      a: {
        var e = c;
        c = b;
        if (!Ya(Md(e))) {
          e = fi(e, null);
          if (!Xa(b, e)) break a;
          c = Ld(c, e.length);
        }
        a && ((c = decodeURIComponent(c)), Xa(c, a) && (c = Ld(c, a.length)));
        if (!Ya(Md(e)) && e.indexOf("?") > -1)
          for (b = typeof d === "number" ? d : 1, d = 0; d < b; d++)
            c = unescape(c);
        b = c;
      }
      return b;
    },
    ek = function (a, b, c, d) {
      var e = [];
      dc && e.push("fullscreen");
      e.push("attributionsrc");
      Gd(window, b, c, e.join(","));
      d && a.A();
    },
    fk = function (a, b, c, d) {
      var e = {};
      e.target = c;
      dc && (e.fullscreen = !0);
      e || (e = {});
      c = window;
      if (b instanceof xd) var f = b;
      else {
        f = typeof b.href != "undefined" ? b.href : String(b);
        var g = g === void 0 ? Cd : g;
        b: if (((g = g === void 0 ? Cd : g), !(f instanceof xd))) {
          for (var l = 0; l < g.length; ++l) {
            var m = g[l];
            if (m instanceof Ad && m.Ae(f)) {
              f = new xd(f);
              break b;
            }
          }
          f = void 0;
        }
        f = f || yd;
      }
      l = self.crossOriginIsolated !== void 0;
      g = "strict-origin-when-cross-origin";
      window.Request && (g = new Request("/").referrerPolicy);
      m = e.noreferrer;
      if (l && m && g === "unsafe-url")
        throw Error(
          "Cannot use the noreferrer option on a page that sets a referrer-policy of `unsafe-url` in modern browsers!"
        );
      g = m && !l;
      b = e.target || b.target;
      m = [];
      var n = [],
        q = !1;
      for (u in e) {
        var t = e[u];
        switch (u) {
          case "width":
          case "height":
          case "top":
          case "left":
            m.push(u + "=" + t);
            break;
          case "target":
            break;
          case "noopener":
          case "noreferrer":
            t ? n.push(u) : ((q = !0), n.push(u + "=false"));
            break;
          case "attributionsrc":
            m.push(u + (t ? "=" + t : ""));
            break;
          default:
            m.push(u + "=" + (t ? 1 : 0));
        }
      }
      var u =
        b !== void 0 && !["_blank", "_self", "_top", "_parent", ""].includes(b);
      u = tb() && u;
      if (kb && l && m.length === 0 && n.length > 0 && !u && !q)
        n.length === 2 && (n = ["noreferrer"]), Gd(c, f, b, n[0]);
      else if (
        ((u = m.join(",")),
        yb() && c.navigator && c.navigator.standalone && b && b != "_self")
      )
        (u = ce(document, "A")),
          (f = Ed(f)),
          f !== void 0 && (u.href = f),
          (u.target = b),
          g && (u.rel = "noreferrer"),
          ((e = e.attributionsrc) || e === "") &&
            u.setAttribute("attributionsrc", e),
          (e = document.createEvent("MouseEvent")),
          e.initMouseEvent("click", !0, !0, c, 1),
          u.dispatchEvent(e);
      else if (g) {
        if (
          ((c = Gd(c, "", b, u)),
          (e = zd(f)),
          c &&
            ((c.opener = null),
            e === "" && (e = "javascript:''"),
            fb.test(e) &&
              (e.indexOf("&") != -1 && (e = e.replace($a, "&amp;")),
              e.indexOf("<") != -1 && (e = e.replace(ab, "&lt;")),
              e.indexOf(">") != -1 && (e = e.replace(bb, "&gt;")),
              e.indexOf('"') != -1 && (e = e.replace(cb, "&quot;")),
              e.indexOf("'") != -1 && (e = e.replace(db, "&#39;")),
              e.indexOf("\x00") != -1 && (e = e.replace(eb, "&#0;"))),
            (e =
              '<meta name="referrer" content="no-referrer"><meta http-equiv="refresh" content="0; url=' +
              e +
              '">'),
            (e = (u = td()) ? u.createHTML(e) : e),
            (e = new Fd(e)),
            (c = c.document) && c.write))
        ) {
          u = c.write;
          if (e instanceof Fd) e = e.g;
          else throw Error("");
          u.call(c, e);
          c.close();
        }
      } else
        (c = Gd(c, f, b, u)) && e.noopener && (c.opener = null),
          c && e.noreferrer && (c.opener = null);
      d && a.A();
    },
    gk = function (a, b, c, d, e) {
      P(a.H, e ? "logExitFlushEventsOpenPopup" : "launchExit", [
        "Count",
        b,
        a.Bb,
        !1,
        c,
        null,
        d,
      ]);
    },
    ik = function (a, b, c, d) {
      if (Ya(Md(b))) H.info("There was a problem with the exit call.");
      else if (a.isInitialized()) {
        var e = d !== void 0 ? d : 0;
        d = (a.o[b] && a.o[b].target) || "_blank";
        var f;
        if ((f = !G(8)))
          (f = a.g.getParameter("click", "")),
            (f = !(
              gb(f, "[rm_exit_id]") &&
              a.o[b] != null &&
              a.o[b].reportingId != null &&
              !Ya(a.o[b].reportingId)
            ));
        e = !(e & 1);
        var g = a.g.getParameter("click", ""),
          l = a.F;
        if (l.o) {
          var m = g;
          l.g.set("dim", Zi());
          for (var n = "", q = ma(l.g), t = q.next(); !t.done; t = q.next()) {
            var u = ma(t.value);
            t = u.next().value;
            u = u.next().value;
            n = u == null ? n + "&" + t + "=" : n + "&" + t + "=" + u;
          }
          l.l &&
            ((q = "bg="),
            typeof l.v === "string" && l.B(m, n, q, l.v) && (q = "" + q + l.v),
            (n = n + "&" + q));
          m = n;
          n = g.toLowerCase().indexOf("&adurl=");
          n > -1 && l.B(g, m) && (g = g.substr(0, n) + m + g.substr(n));
        }
        if (e) {
          if (a.o[b])
            if (G(8)) gk(a, b, c, g, !0);
            else {
              var F = gi(c);
              F = hk(a, F, g, b);
              var Y;
              Xj(a) &&
              ((Y = document.featurePolicy) == null
                ? 0
                : Y.allowedFeatures().includes("attribution-reporting"))
                ? ek(a, F, d, !f)
                : fk(a, F, d, !f);
            }
          else
            c &&
              (a.ja() && G(8)
                ? gk(a, b, c, g, !1)
                : ((f = gi(c)),
                  (f = hk(a, f, g, null)),
                  Xj(a) &&
                  ((F = document.featurePolicy) == null
                    ? 0
                    : F.allowedFeatures().includes("attribution-reporting"))
                    ? ek(a, f, d, !0)
                    : fk(a, f, d, !0),
                  (f = !1)));
          a.g.Z("turtlex_ad_signals") &&
            ((d = a.F),
            (d = { x: d.g.get("nx"), y: d.g.get("ny") }),
            (Y = Zi()),
            (F = $i(a.F)),
            P(a.H, "TURTLEX_AD_CLICKED", [
              {
                reportingId: a.o[b].reportingId,
                clickX: d.x,
                clickY: d.y,
                creativeDims: Y,
                bgResponse: F,
              },
            ]));
        }
        f && Cj(a.h, "Count", b, !0, !0, !0);
        P(a.H, "AD_CLICKED");
        d = new O("exit");
        d.aa("id", b);
        d.aa("url", c);
        a.dispatchEvent(d);
        H.info('Exit "' + b + '" invoked.');
      }
    },
    jk = function (a, b, c, d, e) {
      a = a.o[b];
      c = !d && a && a.url ? a.url : c;
      e == null || Ya(Md(e))
        ? (e = c)
        : (e += "")
        ? ((d = c.indexOf("#")),
          d < 0 && (d = c.length),
          (a = c.indexOf("?")),
          a < 0 || a > d ? ((a = d), (b = "")) : (b = c.substring(a + 1, d)),
          (c = [c.slice(0, a), b, c.slice(d)]),
          (d = c[1]),
          (c[1] = e ? (d ? d + "&" + e : e) : d),
          (e = c[0] + (c[1] ? "?" + c[1] : "") + c[2]))
        : (e = c);
      return e;
    },
    hk = function (a, b, c, d) {
      var e = null;
      d && ((e = a.o[d]), (e = e.reportingId != null ? e.reportingId : null));
      b = b || "";
      d = a.g.getParameter("thirdPartyClickRedirect", "");
      a = parseInt(a.g.getParameter("clickN"), 10);
      if (!Ya(Md(c)) && c.indexOf("?") > -1) {
        a = typeof a === "number" ? a : 1;
        for (var f = 0; f < a; f++) b = encodeURIComponent(b);
      }
      e && ((c = fi(c, e)), (b = d ? encodeURIComponent(d + b) : b));
      return c + b;
    };
  Q.prototype.reportManualClose = function () {
    H.info("Ad was closed by user action.");
    Cj(this.h, "Count", "EVENT_MANUAL_CLOSE");
  };
  Q.prototype.reportManualClose = Q.prototype.reportManualClose;
  Q.prototype.cd = function () {
    Cj(this.h, "Count", "ENGAGEMENT", !1, !1, !1);
    this.A();
  };
  Q.prototype.reportEngagement = Q.prototype.cd;
  var kk = function (a, b, c) {
      var d = b;
      d.length > 100 && (d = d.substr(0, 100));
      P(a.H, "reportCustomVariable", [escape(d), c]);
      H.info('Custom string "' + b + '" recorded.');
    },
    Vj = function (a, b, c) {
      a.ja() &&
        !G(8) &&
        (a.ma && re(a.ma), (a.ma = qe(Qd(Nj, -b, -c) || new Jd(Oj[0]))));
    };
  Q.prototype.Le = function (a, b, c) {
    wj(this.g, a, b, c);
  };
  Q.prototype.setParameter = Q.prototype.Le;
  Q.prototype.fc = function () {
    this.dispatchEvent(new O("pageLoaded"));
  };
  Q.prototype.dispatchPageLoaded = Q.prototype.fc;
  Q.prototype.dispatchEvent = function (a) {
    this.La[a.type] = (this.La[a.type] || 0) + 1;
    switch (a.type) {
      case "pageLoaded":
        window.AdobeEdge != null &&
          typeof window.AdobeEdge.loadResources === "function" &&
          window.AdobeEdge.loadResources();
        this.Vc = !0;
        break;
      case "orientation":
        (this.J.h = a.mode), (this.J.g = a.degrees);
    }
    return Q.M.dispatchEvent.call(this, a);
  };
  Q.prototype.dispatchEvent = Q.prototype.dispatchEvent;
  Q.prototype.Gb = function (a) {
    (this.Zb = a) && !this.La.visible
      ? (window.AdobeEdge != null &&
          typeof window.AdobeEdge.playWhenReady === "function" &&
          window.AdobeEdge.playWhenReady(),
        this.kd && Cj(this.h, "Start", "DISPLAY_TIMER"),
        this.dispatchEvent(new O("visible")))
      : this.La.hidden || this.dispatchEvent(new O("hidden"));
    this.dispatchEvent(new O("visibilityChange"));
  };
  Q.prototype.setAdVisibleInternal = Q.prototype.Gb;
  Q.prototype.rf = function () {
    this.Gb(!0);
  };
  Q.prototype.dispatchAdVisible = Q.prototype.rf;
  Q.prototype.gd = function (a, b, c, d, e, f) {
    if (c || d)
      this.G || (this.G = {}), (this.G.width = c), (this.G.height = d);
    e != null && (this.ib = !!e);
    f != null && wj(this.g, "isMultiDirectional", f ? "true" : "false");
  };
  Q.prototype.setExpandingPixelOffsets = Q.prototype.gd;
  Q.prototype.jd = function (a) {
    this.ib = !!a;
  };
  Q.prototype.setStartExpanded = Q.prototype.jd;
  Q.prototype.hd = function (a) {
    wj(this.g, "isMultiDirectional", a ? "true" : "false");
  };
  Q.prototype.setIsMultiDirectional = Q.prototype.hd;
  Q.prototype.df = function (a) {
    P(this.H, "invokeMraidMethod", ["useCustomClose", [a]]);
    this.Eb = a == 0;
  };
  Q.prototype.setUseCustomClose = Q.prototype.df;
  Q.prototype.Ye = function () {};
  Q.prototype.setFloatingPixelDimensions = Q.prototype.Ye;
  Q.prototype.isVisible = function () {
    return this.Zb;
  };
  Q.prototype.isVisible = Q.prototype.isVisible;
  Q.prototype.ja = function () {
    return G(1);
  };
  Q.prototype.isServingInLiveEnvironment = Q.prototype.ja;
  Q.prototype.isPageLoaded = function () {
    return this.Vc;
  };
  Q.prototype.isPageLoaded = Q.prototype.isPageLoaded;
  Q.prototype.isInitialized = function () {
    return this.Ab;
  };
  Q.prototype.isInitialized = Q.prototype.isInitialized;
  Q.prototype.kc = function (a) {
    typeof a === "function" && rg(this.S, a);
  };
  Q.prototype.callAfterInitialized = Q.prototype.kc;
  Q.prototype.getParameter = function (a) {
    return this.g.getParameter(a, null);
  };
  Q.prototype.getParameter = Q.prototype.getParameter;
  Q.prototype.getParameter = Q.prototype.getParameter;
  Q.prototype.P = function (a) {
    return this.g.P(a);
  };
  Q.prototype.getParameterAsInteger = Q.prototype.P;
  Q.prototype.Dc = function (a) {
    a = this.g.Z(a);
    return a != void 0 && (a.toLowerCase() == "true" || a == "1");
  };
  Q.prototype.getParameterAsBoolean = Q.prototype.Dc;
  Q.prototype.Z = function (a) {
    return this.g.Z(a);
  };
  Q.prototype.getParameterAsNullableString = Q.prototype.Z;
  Q.prototype.exit = function (a, b, c) {
    b !== void 0 && (b = dk(this, b));
    ck(this);
    ik(this, a, jk(this, a, b, !1), c);
  };
  Q.prototype.exit = Q.prototype.exit;
  Q.prototype.Mb = function (a, b, c) {
    b = dk(this, b);
    ck(this);
    ik(this, a, jk(this, a, b, !0), c);
  };
  Q.prototype.exitOverride = Q.prototype.Mb;
  Q.prototype.Yd = function (a, b, c, d, e) {
    e && !e.pIndex && (e.pIndex = c);
    b = dk(this, b);
    ck(this);
    ik(this, a, jk(this, a, b, !0), d);
  };
  Q.prototype.dynamicExit = Q.prototype.Yd;
  Q.prototype.Nb = function (a, b) {
    ik(this, a, jk(this, a, void 0, void 0, b || ""));
  };
  Q.prototype.exitQueryString = Q.prototype.Nb;
  Q.prototype.xc = function (a) {
    return hk(this, a, this.g.getParameter("click", ""), null);
  };
  Q.prototype.formExitUrlFromOverride = Q.prototype.xc;
  Q.prototype.counter = function (a, b) {
    H.info('Counter "' + a + '" invoked.');
    Cj(this.h, "Count", a, b, !0);
  };
  Q.prototype.counter = Q.prototype.counter;
  Q.prototype.startTimer = function (a) {
    H.info('Timer "' + a + '" started.');
    Cj(this.h, "Start", a, void 0, !0);
  };
  Q.prototype.startTimer = Q.prototype.startTimer;
  Q.prototype.stopTimer = function (a) {
    H.info('Timer "' + a + '" stopped.');
    Cj(this.h, "Stop", a, void 0, !0);
  };
  Q.prototype.stopTimer = Q.prototype.stopTimer;
  Q.prototype.Se = function (a) {
    kk(this, a, 1);
  };
  Q.prototype.reportCustomImpressionVariable = Q.prototype.Se;
  Q.prototype.Te = function (a) {
    kk(this, a, 1);
  };
  Q.prototype.reportCustomVariableCount1 = Q.prototype.Te;
  Q.prototype.Re = function (a) {
    kk(this, a, 2);
  };
  Q.prototype.reportCustomClickVariable = Q.prototype.Re;
  Q.prototype.Ue = function (a) {
    kk(this, a, 2);
  };
  Q.prototype.reportCustomVariableCount2 = Q.prototype.Ue;
  Q.prototype.zc = function () {
    return this.j;
  };
  Q.prototype.getContainerState = Q.prototype.zc;
  Q.prototype.Cc = function () {
    return this.ta;
  };
  Q.prototype.getExpandDirection = Q.prototype.Cc;
  Q.prototype.bf = function (a) {
    this.Fb || P(this.H, "setResponsiveBehavior", [a ? 2 : 0, 2]);
  };
  Q.prototype.setResponsiveExpanding = Q.prototype.bf;
  Q.prototype.cf = function (a, b) {
    P(this.H, "responsiveResize", [a, b]);
  };
  Q.prototype.setResponsiveSize = Q.prototype.cf;
  Q.prototype.wb = function () {
    if (this.j == "collapsed") {
      oh(this, "expandStart");
      this.Fb = !0;
      var a = [this.va];
      this.G && a.push(this.G);
      P(this.H, "expandRequested", a);
      lk(this, this.Na);
      this.B(this.Qc, 0);
    }
  };
  Q.prototype.requestExpand = Q.prototype.wb;
  var lk = function (a, b) {
      if (!a.ja() && a.Eb) {
        var c = document.getElementsByTagName("body")[0],
          d = C("IMG", {
            width: "15",
            height: "15",
            border: "0",
            src: "http://s0.2mdn.net/ads/studio/close.png",
          });
        a.l = {
          callback: b,
          element: C(
            "DIV",
            {
              style:
                "position: absolute;right: 5px;top: 5px;width: 15px;height: 15px;cursor: pointer;",
            },
            d
          ),
        };
        N(a.N, a.l.element, "click", b);
        fe(c, a.l.element);
      }
    },
    mk = function (a) {
      a.l &&
        (he(a.l.element),
        li(a.N, a.l.element, "click", a.l.callback),
        (a.l.element = null),
        (a.l.callback = null),
        (a.l = null));
    };
  Q.prototype.Me = function () {
    this.dispatchEvent(new O("aboutToExpand"));
  };
  Q.prototype.aboutToExpandInternal = Q.prototype.Me;
  Q.prototype.Qc = function (a) {
    a && (a = bj[a.toString().toUpperCase()]);
    var b = 0,
      c = 0;
    this.getParameter("isMultiDirectional") == "true" &&
      a &&
      (a.g & 2 && (c = this.P("topOffset")),
      a.g & 1 && (b = this.P("leftOffset")));
    Vj(this, b === null ? 0 : b, c === null ? 0 : c);
    a
      ? (this.ta = a)
      : (this.ta =
          this.ja() || this.getParameter("isMultiDirectional") != "true"
            ? null
            : cj[this.qf++ % cj.length]);
    this.ib ||
      (Cj(this.h, "Start", "EXPAND_TIMER"),
      ck(this),
      this.Ma || (this.A(), (this.Ma = !0)));
    this.ib = !1;
    this.j = "expanding";
    a = new O("expandStart");
    a.aa("direction", this.ta);
    this.dispatchEvent(a);
  };
  Q.prototype.startExpandInternal = Q.prototype.Qc;
  Q.prototype.Pb = function () {
    this.j == "expanding" &&
      (P(this.H, "expandFinished", [this.va]),
      (this.j = "expanded"),
      H.info("The creative has expanded."),
      this.dispatchEvent(new O("expandFinish")));
  };
  Q.prototype.finishExpand = Q.prototype.Pb;
  Q.prototype.expand = function (a, b) {
    Vj(this, 0, 0);
    var c = [this.va];
    b && c.push(b);
    this.Eb = !!b && b.useCustomClose == 0;
    P(this.H, "expandAsset", c);
    a || (Cj(this.h, "Start", "EXPAND_TIMER"), ck(this));
    this.Ma || (this.A(), (this.Ma = !0));
    H.info("The creative has expanded.");
  };
  Q.prototype.expand = Q.prototype.expand;
  Q.prototype.Na = function () {
    mk(this);
    oh(this, "collapseStart");
    P(this.H, "collapseRequested", [this.va]);
    this.B(this.Pc, 0);
  };
  Q.prototype.requestCollapse = Q.prototype.Na;
  Q.prototype.Pc = function () {
    this.j = "collapsing";
    this.dispatchEvent(new O("collapseStart"));
  };
  Q.prototype.startCollapseInternal = Q.prototype.Pc;
  Q.prototype.Ob = function () {
    this.j == "collapsing" &&
      (P(this.H, "collapseFinished", [this.va]), this.B(this.lc, 0));
  };
  Q.prototype.finishCollapse = Q.prototype.Ob;
  Q.prototype.lc = function () {
    var a = this.P("leftOffset") || 0,
      b = this.P("topOffset") || 0;
    Vj(this, a, b);
    Cj(this.h, "Stop", "EXPAND_TIMER");
    this.j = "collapsed";
    H.info("The creative has collapsed.");
    this.dispatchEvent(new O("collapseFinish"));
  };
  Q.prototype.finishCollapseInternal = Q.prototype.lc;
  Q.prototype.collapse = function () {
    oh(this, "collapse");
    var a = this.P("leftOffset") || 0,
      b = this.P("topOffset") || 0;
    Vj(this, a, b);
    P(this.H, "collapseAsset", [this.va]);
    this.dispatchEvent(new O("collapse"));
    Cj(this.h, "Stop", "EXPAND_TIMER");
  };
  Q.prototype.collapse = Q.prototype.collapse;
  Q.prototype.close = function () {
    this.X.dispose();
    P(this.H, "tellAssetHide", [this.va]);
    H.info(
      "Closing ad. If this was invoked by a user action, call Enabler.reportManualClose() as well."
    );
  };
  Q.prototype.close = Q.prototype.close;
  Q.prototype.Rd = function () {};
  Q.prototype.closeCompanion = Q.prototype.Rd;
  Q.prototype.Wd = function () {};
  Q.prototype.displayCompanion = Q.prototype.Wd;
  Q.prototype.ie = function () {
    return this.Z("sn");
  };
  Q.prototype.getDartSiteName = Q.prototype.ie;
  Q.prototype.he = function () {
    return this.P("sid");
  };
  Q.prototype.getDartSiteId = Q.prototype.he;
  Q.prototype.ee = function () {
    return this.P("aid");
  };
  Q.prototype.getDartAdId = Q.prototype.ee;
  Q.prototype.ge = function () {
    return this.P("pid");
  };
  Q.prototype.getDartPageId = Q.prototype.ge;
  Q.prototype.Bc = function () {
    return this.Z("rid");
  };
  Q.prototype.getDartRenderingId = Q.prototype.Bc;
  Q.prototype.fe = function () {
    return this.P("cid");
  };
  Q.prototype.getDartCreativeId = Q.prototype.fe;
  Q.prototype.Ac = function () {
    return this.Z("varName");
  };
  Q.prototype.getDartAssetId = Q.prototype.Ac;
  Q.prototype.pe = function () {
    return this.Z("ct");
  };
  Q.prototype.getUserCountry = Q.prototype.pe;
  Q.prototype.re = function () {
    return this.Z("st");
  };
  Q.prototype.getUserState = Q.prototype.re;
  Q.prototype.se = function () {
    return this.Z("zp");
  };
  Q.prototype.getUserZipCode = Q.prototype.se;
  Q.prototype.oe = function () {
    var a = this.P("bw");
    return a != null ? a : 0;
  };
  Q.prototype.getUserBandwidth = Q.prototype.oe;
  Q.prototype.ne = function () {
    return this.Z("ac");
  };
  Q.prototype.getUserAreaCode = Q.prototype.ne;
  Q.prototype.qe = function () {
    return this.P("dma");
  };
  Q.prototype.getUserDMACode = Q.prototype.qe;
  Q.prototype.getFilename = function (a) {
    return this.Ta(a);
  };
  Q.prototype.getFilename = Q.prototype.getFilename;
  Q.prototype.Ta = function (a) {
    var b = a.toLowerCase(),
      c = b.slice(b.lastIndexOf("/") + 1),
      d = encodeURIComponent(c),
      e = this.D[c];
    e =
      (e =
        (e =
          (e = (e = e || this.D["pro_" + c]) || this.D[b]) ||
          this.D["pro_" + b]) || this.D[d]) || this.D["pro_" + d];
    return e != null ? e : a;
  };
  Q.prototype.getUrl = Q.prototype.Ta;
  Q.prototype.le = function () {
    return this.J;
  };
  Q.prototype.getOrientation = Q.prototype.le;
  Q.prototype.ga = function (a, b, c) {
    this.h.ga(a, b, c);
    H.info('Video "' + b + '" dispatching "' + c + '" event.');
  };
  Q.prototype.od = function (a, b) {
    if (a)
      for (var c = 0; c < this.Hb.length; ++c) {
        var d = this.Hb[c];
        if (d != null)
          switch (a) {
            case "changevolume":
              b != null && (b > 0 && (d.muted = !1), (d.volume = b));
              break;
            case "pause":
              d.pause();
              break;
            case "resume":
              d.play();
          }
      }
  };
  Q.prototype.invokeOnAllVideos = Q.prototype.od;
  Q.prototype.Mc = function (a) {
    a != null && this.Hb.push(a);
  };
  Q.prototype.registerVideoElements = Q.prototype.Mc;
  Q.prototype.Ce = function (a, b) {
    a = Bg(th(a));
    b != null && rg(a, b);
  };
  Q.prototype.loadScript = Q.prototype.Ce;
  Q.prototype.Wa = function (a, b) {
    He(Bf, a) && rg(this.S, Ta(Fh, a, b));
  };
  Q.prototype.loadModule = Q.prototype.Wa;
  Q.prototype.Be = function (a, b) {
    for (var c = a.length, d = 0; d < a.length; ++d)
      this.Wa(a[d], function () {
        --c == 0 && b();
      });
  };
  Q.prototype.loadModules = Q.prototype.Be;
  Q.prototype.Ic = function (a) {
    H.info('Dispatching function invocation "' + a + '" on parent.');
    P(this.H, "invokeExternalJSFunction", [escape(a)]);
  };
  Q.prototype.invokeExternalJsFunction = Q.prototype.Ic;
  Q.prototype.Jc = function (a, b, c) {
    var d = 'Method "' + a + '" invoked';
    b && (d += 'with arguments "' + b.join(",") + '"');
    H.info(d + ".");
    P(this.H, "invokeMraidMethod", [a, b], c);
  };
  Q.prototype.invokeMraidMethod = Q.prototype.Jc;
  Q.prototype.tf = function () {};
  Q.prototype.invokeAdMobMethod = Q.prototype.tf;
  Q.prototype.I = function (a, b, c, d) {
    He(hi, a) && P(this.H, "invokeExternalJSFunctionWithReturn", [a, b, c], d);
  };
  Q.prototype.invokeExternalJsFunctionWithReturn = Q.prototype.I;
  Q.prototype.pd = function (a, b) {
    H.info("Dispatching function invocation openUrl on parent.");
    P(this.H, "invokeUrlOpen", [a], b);
  };
  Q.prototype.invokeUrlOpen = Q.prototype.pd;
  Q.prototype.C = function () {
    this.ma && re(this.ma);
    this.Aa && mh(this.Aa);
    ue(this.X, this.h, this.N, this.S, this.F);
    delete this.gb;
    Q.M.C.call(this);
  };
  Q.prototype.addEventListener = function (a, b, c, d, e) {
    a = Xi[a.toString()] || a;
    if (a.toString() in Ui) {
      if (!this.ja()) {
        e = b;
        typeof b === "function" &&
          (e = function (f) {
            f.ce ? b(f.Y) : b(f);
          });
        N(this.N, window, a, e, c, d);
        return;
      }
      P(this.H, "registerEventTypeListenerForType", [a, e]);
    }
    a == "hostpageFeaturesLoaded" && P(this.H, "getHostpageFeatures", [a]);
    eh(this, a, b, c, d);
  };
  Q.prototype.addEventListener = Q.prototype.addEventListener;
  Q.prototype.removeEventListener = function (a, b, c, d) {
    lh(this, a, b, c, d);
  };
  Q.prototype.removeEventListener = Q.prototype.removeEventListener;
  Q.prototype.Ib = function (a, b) {
    this.gb[a] = b;
  };
  Q.prototype.addMessageHandler = Q.prototype.Ib;
  Q.prototype.Pe = function (a) {
    delete this.gb[a];
  };
  Q.prototype.removeMessageHandler = Q.prototype.Pe;
  Q.prototype.mf = function (a, b) {
    a = this.gb[a];
    typeof a === "function" && a.apply(null, b);
  };
  Q.prototype.defaultMessageHandler = Q.prototype.mf;
  Q.prototype.ad = function () {
    oh(this, "fullscreenSupport");
    P(this.H, "isFullscreenSupported");
    this.B(this.Kc, 0, !0);
  };
  Q.prototype.queryFullscreenSupport = Q.prototype.ad;
  Q.prototype.Zc = function () {
    oh(this, "fullscreenDimensions");
    P(this.H, "queryFullscreenDimensions");
    if (!this.ja()) {
      var a = ae();
      this.B(this.yc, 0, a.width, a.height);
    }
  };
  Q.prototype.queryFullscreenDimensions = Q.prototype.Zc;
  Q.prototype.dd = function (a, b) {
    if (this.j == "collapsed") {
      oh(this, "fullscreenExpandStart");
      this.Fb = !0;
      var c = [];
      a && b && (c = [a, b]);
      P(this.H, "fullscreenExpandRequested", c);
      lk(this, this.Tb);
      this.B(this.Hc, 0, a, b);
    }
  };
  Q.prototype.requestFullscreenExpand = Q.prototype.dd;
  Q.prototype.wc = function () {
    this.j == "fs_expanding" &&
      (P(this.H, "fullscreenExpandFinished"),
      H.info("The creative has expanded."),
      this.B(this.Fc, 0));
  };
  Q.prototype.finishFullscreenExpand = Q.prototype.wc;
  Q.prototype.Tb = function () {
    this.j == "fs_expanded" &&
      (oh(this, "fullscreenCollapseStart"),
      mk(this),
      P(this.H, "fullscreenCollapseRequested"),
      this.B(this.uc, 0));
  };
  Q.prototype.requestFullscreenCollapse = Q.prototype.Tb;
  Q.prototype.vc = function () {
    this.j == "fs_collapsing" &&
      (P(this.H, "fullscreenCollapseFinished"), this.B(this.rc, 0));
  };
  Q.prototype.finishFullscreenCollapse = Q.prototype.vc;
  Q.prototype.Ne = function (a) {
    P(this.H, "registerChargeableEventName", [a]);
  };
  Q.prototype.registerChargeableEventName = Q.prototype.Ne;
  Q.prototype.Qb = function () {
    return this.X.Qb();
  };
  Q.prototype.hasUserInteracted = Q.prototype.Qb;
  Q.prototype.Kc = function (a) {
    var b = new O("fullscreenSupport");
    b.aa("supported", a);
    this.dispatchEvent(b);
  };
  Q.prototype.fullscreenSupportInternal = Q.prototype.Kc;
  Q.prototype.yc = function (a, b) {
    var c = new O("fullscreenDimensions");
    a != void 0 && b != void 0 && (c.aa("width", a), c.aa("height", b));
    this.dispatchEvent(c);
  };
  Q.prototype.fullscreenDimensionsInternal = Q.prototype.yc;
  Q.prototype.Hc = function (a, b, c, d) {
    Cj(this.h, "Start", "EXPAND_TIMER");
    ck(this);
    this.Ma || (this.A(), (this.Ma = !0));
    this.j = "fs_expanding";
    var e = new O("fullscreenExpandStart");
    e.aa("width", a);
    e.aa("height", b);
    e.aa("left", c);
    e.aa("top", d);
    this.dispatchEvent(e);
  };
  Q.prototype.fullscreenExpandStartInternal = Q.prototype.Hc;
  Q.prototype.Fc = function () {
    this.j = "fs_expanded";
    this.dispatchEvent(new O("fullscreenExpandFinish"));
  };
  Q.prototype.fullscreenExpandFinishInternal = Q.prototype.Fc;
  Q.prototype.uc = function () {
    this.j = "fs_collapsing";
    this.dispatchEvent(new O("fullscreenCollapseStart"));
  };
  Q.prototype.fullscreenCollapseStartInternal = Q.prototype.uc;
  Q.prototype.rc = function () {
    Cj(this.h, "Stop", "EXPAND_TIMER");
    this.j = "collapsed";
    this.dispatchEvent(new O("fullscreenCollapseFinish"));
  };
  Q.prototype.fullscreenCollapseFinishInternal = Q.prototype.rc;
  Q.prototype.ff = function () {
    return this.sd.h("image/webp");
  };
  Q.prototype.canRenderWebpImages = Q.prototype.ff;
  Q.prototype.Rc = function (a) {
    return this.Uc.j(a) ? this.Uc.h(a) : !1;
  };
  Q.prototype.supportsVideoFormat = Q.prototype.Rc;
  Q.prototype.Ze = function () {
    return this;
  };
  Q.prototype.setHint = Q.prototype.Ze;
  Q.prototype.Ec = function () {
    a: {
      for (a in zf)
        if (zf[a] == "studio") {
          var a = "studio";
          break a;
        }
      a = null;
    }
    return a || "studio";
  };
  Q.prototype.getSdk = Q.prototype.Ec;
  var nk = R();
  v("Enabler", nk);
  R().init();
  uh.enabler = 3;
  var ok = function (a) {
    var b = "Da";
    if (a.Da && a.hasOwnProperty(b)) return a.Da;
    b = new a();
    return (a.Da = b);
  };
  function S() {
    L.call(this);
    this.g = "loading";
    this.h = r.Enabler;
    this.h.isInitialized() ? this.j() : eh(this.h, "init", this.j, !1, this);
  }
  y(S, L);
  S.prototype.l = function () {
    return this.g;
  };
  S.prototype.getState = S.prototype.l;
  S.prototype.A = function () {
    return "1.0";
  };
  S.prototype.getVersion = S.prototype.A;
  S.prototype.open = function () {
    this.h.exit("MRAID default exit");
  };
  S.prototype.open = S.prototype.open;
  S.prototype.close = function () {
    this.g == "expanded"
      ? (this.h.Na(), (this.g = "default"), this.dispatchEvent("stateChange"))
      : this.g == "default" &&
        ((this.g = "hidden"),
        this.h.close(),
        this.dispatchEvent("stateChange"));
  };
  S.prototype.close = S.prototype.close;
  S.prototype.B = function () {
    return this.h.isVisible();
  };
  S.prototype.isViewable = S.prototype.B;
  S.prototype.expand = function () {
    this.g == "default" &&
      (this.h.wb(), (this.g = "expanded"), this.dispatchEvent("stateChange"));
  };
  S.prototype.expand = S.prototype.expand;
  S.prototype.j = function () {
    this.g = "default";
    eh(this.h, "collapseStart", this.o, !1, this);
    this.dispatchEvent("ready");
  };
  S.prototype.o = function () {
    this.g == "expanded" &&
      ((this.g = "default"), this.dispatchEvent("stateChange"));
  };
  if (!window.mraid) {
    var pk = ok(S);
    v("mraid", pk);
  }
  v("studio.sdk.hint.ExpansionMode", {
    NORMAL: "normal",
    LIGHTBOX: "lightbox",
  });
  v("studio.sdk.hint.ExpansionTrigger", {
    ON_CLICK: "onClick",
    ON_HOVER: "onHover",
  });
  v("studio.sdk.hint.Hint", {
    EXPANSION_MODE: "expansionMode",
    EXPANSION_TRIGGER: "expansionTrigger",
  });
  function qk(a) {
    return "Config type " + a + " does not exist";
  }
  function rk(a, b) {
    return (
      "Cannot handle description for property " + b + " on type " + a + "."
    );
  }
  function sk(a, b) {
    return (
      "Array property " +
      b +
      " on type " +
      a +
      " must have at least one element."
    );
  }
  function tk(a, b) {
    return "Invalid type for value of property " + b + " on type " + a + ".";
  }
  function uk(a, b) {
    return "Property " + b + " is not an array on type " + a + ".";
  }
  var vk = function () {},
    wk = function (a) {
      var b = R();
      b.isInitialized() ? a(b) : b.v.add("init", Ta(a, b), !0, void 0, void 0);
    },
    xk = function () {
      return new Rf(function (a) {
        var b = R();
        b.isInitialized()
          ? a(b)
          : b.v.add("init", Ta(a, b), !0, void 0, void 0);
      });
    };
  v("studio.utils.EnablerAccessor", vk);
  vk.loadModuleWhenReady = function (a, b) {
    wk(function (c) {
      c.Wa(a, b);
    });
  };
  vk.getInitializedEnabler = xk;
  vk.getInitializedEnablerByCallback = wk;
})();
