(function () {
  var m,
    aa =
      typeof Object.create == "function"
        ? Object.create
        : function (a) {
            var b = function () {};
            b.prototype = a;
            return new b();
          },
    n =
      typeof Object.defineProperties == "function"
        ? Object.defineProperty
        : function (a, b, c) {
            if (a == Array.prototype || a == Object.prototype) return a;
            a[b] = c.value;
            return a;
          },
    ba = function (a) {
      a = [
        "object" == typeof globalThis && globalThis,
        a,
        "object" == typeof window && window,
        "object" == typeof self && self,
        "object" == typeof global && global,
      ];
      for (var b = 0; b < a.length; ++b) {
        var c = a[b];
        if (c && c.Math == Math) return c;
      }
      throw Error("Cannot find global object");
    },
    ca = ba(this),
    q = function (a, b) {
      if (b)
        a: {
          var c = ca;
          a = a.split(".");
          for (var d = 0; d < a.length - 1; d++) {
            var e = a[d];
            if (!(e in c)) break a;
            c = c[e];
          }
          a = a[a.length - 1];
          d = c[a];
          b = b(d);
          b != d &&
            b != null &&
            n(c, a, { configurable: !0, writable: !0, value: b });
        }
    },
    da = function (a) {
      var b = 0;
      return function () {
        return b < a.length ? { done: !1, value: a[b++] } : { done: !0 };
      };
    },
    r = function (a) {
      var b =
        typeof Symbol != "undefined" && Symbol.iterator && a[Symbol.iterator];
      if (b) return b.call(a);
      if (typeof a.length == "number") return { next: da(a) };
      throw Error(String(a) + " is not an iterable or ArrayLike");
    },
    fa = function (a) {
      return ea(a, a);
    },
    ea = function (a, b) {
      a.raw = b;
      Object.freeze && (Object.freeze(a), Object.freeze(b));
      return a;
    },
    t = function (a, b) {
      var c;
      b && !b.done && (c = a["return"]) && c.call(a);
    },
    u = function (a, b) {
      return Object.prototype.hasOwnProperty.call(a, b);
    },
    ha = function () {
      for (var a = Number(this), b = [], c = a; c < arguments.length; c++)
        b[c - a] = arguments[c];
      return b;
    };
  q("globalThis", function (a) {
    return a || ca;
  });
  q("Symbol", function (a) {
    if (a) return a;
    var b = function (f, h) {
      this.h = f;
      n(this, "description", { configurable: !0, writable: !0, value: h });
    };
    b.prototype.toString = function () {
      return this.h;
    };
    var c = "jscomp_symbol_" + ((Math.random() * 1e9) >>> 0) + "_",
      d = 0,
      e = function (f) {
        if (this instanceof e)
          throw new TypeError("Symbol is not a constructor");
        return new b(c + (f || "") + "_" + d++, f);
      };
    return e;
  });
  q("Symbol.iterator", function (a) {
    if (a) return a;
    a = Symbol("Symbol.iterator");
    n(Array.prototype, a, {
      configurable: !0,
      writable: !0,
      value: function () {
        return v(da(this));
      },
    });
    return a;
  });
  var v = function (a) {
    var b =
        (typeof Iterator != "undefined" &&
        Iterator.prototype &&
        !Iterator.prototype.next
          ? Iterator.prototype
          : null) || Object.prototype,
      c = aa(b);
    c.next = a;
    b[Symbol.iterator] ||
      (c[Symbol.iterator] = function () {
        return this;
      });
    return c;
  };
  q("Symbol.dispose", function (a) {
    return a ? a : Symbol("Symbol.dispose");
  });
  q("Array.prototype.find", function (a) {
    return a
      ? a
      : function (b, c) {
          a: {
            var d = this;
            d instanceof String && (d = String(d));
            for (var e = d.length, f = 0; f < e; f++) {
              var h = d[f];
              if (b.call(c, h, f, d)) {
                b = h;
                break a;
              }
            }
            b = void 0;
          }
          return b;
        };
  });
  q("WeakMap", function (a) {
    function b() {}
    function c(k) {
      var l = typeof k;
      return (l === "object" && k !== null) || l === "function";
    }
    function d(k) {
      if (!u(k, f)) {
        var l = new b();
        n(k, f, { value: l });
      }
    }
    function e(k) {
      var l = Object[k];
      l &&
        (Object[k] = function (p) {
          if (p instanceof b) return p;
          Object.isExtensible(p) && d(p);
          return l(p);
        });
    }
    if (
      (function () {
        if (!a || !Object.seal) return !1;
        try {
          var k = Object.seal({}),
            l = Object.seal({}),
            p = new a([
              [k, 2],
              [l, 3],
            ]);
          if (p.get(k) != 2 || p.get(l) != 3) return !1;
          p.delete(k);
          p.set(l, 4);
          return !p.has(k) && p.get(l) == 4;
        } catch (E) {
          return !1;
        }
      })()
    )
      return a;
    var f = "$jscomp_hidden_" + Math.random();
    e("freeze");
    e("preventExtensions");
    e("seal");
    var h = 0,
      g = function (k) {
        this.h = (h += Math.random() + 1).toString();
        if (k) {
          k = r(k);
          for (var l; !(l = k.next()).done; )
            (l = l.value), this.set(l[0], l[1]);
        }
      };
    g.prototype.set = function (k, l) {
      if (!c(k)) throw Error("Invalid WeakMap key");
      d(k);
      if (!u(k, f)) throw Error("WeakMap key fail: " + k);
      k[f][this.h] = l;
      return this;
    };
    g.prototype.get = function (k) {
      return c(k) && u(k, f) ? k[f][this.h] : void 0;
    };
    g.prototype.has = function (k) {
      return c(k) && u(k, f) && u(k[f], this.h);
    };
    g.prototype.delete = function (k) {
      return c(k) && u(k, f) && u(k[f], this.h) ? delete k[f][this.h] : !1;
    };
    return g;
  });
  q("Map", function (a) {
    if (
      (function () {
        if (
          !a ||
          typeof a != "function" ||
          !a.prototype.entries ||
          typeof Object.seal != "function"
        )
          return !1;
        try {
          var g = Object.seal({ x: 4 }),
            k = new a(r([[g, "s"]]));
          if (
            k.get(g) != "s" ||
            k.size != 1 ||
            k.get({ x: 4 }) ||
            k.set({ x: 4 }, "t") != k ||
            k.size != 2
          )
            return !1;
          var l = k.entries(),
            p = l.next();
          if (p.done || p.value[0] != g || p.value[1] != "s") return !1;
          p = l.next();
          return !(
            p.done ||
            p.value[0].x != 4 ||
            p.value[1] != "t" ||
            !l.next().done
          );
        } catch (E) {
          return !1;
        }
      })()
    )
      return a;
    var b = new WeakMap(),
      c = function (g) {
        this[0] = {};
        this[1] = f();
        this.size = 0;
        if (g) {
          g = r(g);
          for (var k; !(k = g.next()).done; )
            (k = k.value), this.set(k[0], k[1]);
        }
      };
    c.prototype.set = function (g, k) {
      g = g === 0 ? 0 : g;
      var l = d(this, g);
      l.list || (l.list = this[0][l.id] = []);
      l.entry
        ? (l.entry.value = k)
        : ((l.entry = {
            next: this[1],
            G: this[1].G,
            head: this[1],
            key: g,
            value: k,
          }),
          l.list.push(l.entry),
          (this[1].G.next = l.entry),
          (this[1].G = l.entry),
          this.size++);
      return this;
    };
    c.prototype.delete = function (g) {
      g = d(this, g);
      return g.entry && g.list
        ? (g.list.splice(g.index, 1),
          g.list.length || delete this[0][g.id],
          (g.entry.G.next = g.entry.next),
          (g.entry.next.G = g.entry.G),
          (g.entry.head = null),
          this.size--,
          !0)
        : !1;
    };
    c.prototype.clear = function () {
      this[0] = {};
      this[1] = this[1].G = f();
      this.size = 0;
    };
    c.prototype.has = function (g) {
      return !!d(this, g).entry;
    };
    c.prototype.get = function (g) {
      return (g = d(this, g).entry) && g.value;
    };
    c.prototype.entries = function () {
      return e(this, function (g) {
        return [g.key, g.value];
      });
    };
    c.prototype.keys = function () {
      return e(this, function (g) {
        return g.key;
      });
    };
    c.prototype.values = function () {
      return e(this, function (g) {
        return g.value;
      });
    };
    c.prototype.forEach = function (g, k) {
      for (var l = this.entries(), p; !(p = l.next()).done; )
        (p = p.value), g.call(k, p[1], p[0], this);
    };
    c.prototype[Symbol.iterator] = c.prototype.entries;
    var d = function (g, k) {
        var l = k && typeof k;
        l == "object" || l == "function"
          ? b.has(k)
            ? (l = b.get(k))
            : ((l = "" + ++h), b.set(k, l))
          : (l = "p_" + k);
        var p = g[0][l];
        if (p && u(g[0], l))
          for (g = 0; g < p.length; g++) {
            var E = p[g];
            if ((k !== k && E.key !== E.key) || k === E.key)
              return { id: l, list: p, index: g, entry: E };
          }
        return { id: l, list: p, index: -1, entry: void 0 };
      },
      e = function (g, k) {
        var l = g[1];
        return v(function () {
          if (l) {
            for (; l.head != g[1]; ) l = l.G;
            for (; l.next != l.head; )
              return (l = l.next), { done: !1, value: k(l) };
            l = null;
          }
          return { done: !0, value: void 0 };
        });
      },
      f = function () {
        var g = {};
        return (g.G = g.next = g.head = g);
      },
      h = 0;
    return c;
  });
  q("Object.values", function (a) {
    return a
      ? a
      : function (b) {
          var c = [],
            d;
          for (d in b) u(b, d) && c.push(b[d]);
          return c;
        };
  });
  q("Array.from", function (a) {
    return a
      ? a
      : function (b, c, d) {
          c =
            c != null
              ? c
              : function (g) {
                  return g;
                };
          var e = [],
            f =
              typeof Symbol != "undefined" &&
              Symbol.iterator &&
              b[Symbol.iterator];
          if (typeof f == "function") {
            b = f.call(b);
            for (var h = 0; !(f = b.next()).done; )
              e.push(c.call(d, f.value, h++));
          } else
            for (f = b.length, h = 0; h < f; h++) e.push(c.call(d, b[h], h));
          return e;
        };
  });
  var ia = function (a, b) {
    a instanceof String && (a += "");
    var c = 0,
      d = !1;
    return v(function () {
      if (!d && c < a.length) {
        var e = c++;
        return { value: b(e, a[e]), done: !1 };
      }
      d = !0;
      return { done: !0, value: void 0 };
    });
  };
  q("Array.prototype.keys", function (a) {
    return a
      ? a
      : function () {
          return ia(this, function (b) {
            return b;
          });
        };
  });
  q("Array.prototype.values", function (a) {
    return a
      ? a
      : function () {
          return ia(this, function (b, c) {
            return c;
          });
        };
  }); /*

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/
  var ja = ja || {},
    w = this || self,
    ka = function (a) {
      var b = typeof a;
      b = b != "object" ? b : a ? (Array.isArray(a) ? "array" : b) : "null";
      return b == "array" || (b == "object" && typeof a.length == "number");
    },
    x = function (a) {
      var b = typeof a;
      return (b == "object" && a != null) || b == "function";
    },
    la = function (a, b) {
      function c() {}
      c.prototype = b.prototype;
      a.R = b.prototype;
      a.prototype = new c();
      a.prototype.constructor = a;
      a.Xa = function (d, e, f) {
        for (
          var h = Array(arguments.length - 2), g = 2;
          g < arguments.length;
          g++
        )
          h[g - 2] = arguments[g];
        return b.prototype[e].apply(d, h);
      };
    };
  var ma = function (a, b) {
      if (typeof a === "string")
        return typeof b !== "string" || b.length != 1 ? -1 : a.indexOf(b, 0);
      for (var c = 0; c < a.length; c++) if (c in a && a[c] === b) return c;
      return -1;
    },
    na = function (a, b) {
      for (
        var c = a.length, d = typeof a === "string" ? a.split("") : a, e = 0;
        e < c;
        e++
      )
        e in d && b.call(void 0, d[e], e, a);
    },
    oa = function (a, b) {
      for (
        var c = a.length,
          d = Array(c),
          e = typeof a === "string" ? a.split("") : a,
          f = 0;
        f < c;
        f++
      )
        f in e && (d[f] = b.call(void 0, e[f], f, a));
      return d;
    },
    pa = function (a, b) {
      var c = -1;
      na(a, function (d, e) {
        c = b.call(void 0, c, d, e, a);
      });
      return c;
    };
  function qa(a, b) {
    b = ma(a, b);
    var c;
    (c = b >= 0) && Array.prototype.splice.call(a, b, 1);
    return c;
  }
  function ra(a) {
    var b = a.length;
    if (b > 0) {
      for (var c = Array(b), d = 0; d < b; d++) c[d] = a[d];
      return c;
    }
    return [];
  }
  function sa(a) {
    for (var b = [], c = 0; c < a; c++) b[c] = "";
    return b;
  }
  var ta = function (a) {
    ta[" "](a);
    return a;
  };
  ta[" "] = function () {};
  function ua(a, b) {
    if (a)
      for (var c in a)
        Object.prototype.hasOwnProperty.call(a, c) && b(a[c], c, a);
  } /*

 Copyright Google LLC
 SPDX-License-Identifier: Apache-2.0
*/
  var va = globalThis.trustedTypes,
    wa;
  function xa() {
    var a = null;
    if (!va) return a;
    try {
      var b = function (c) {
        return c;
      };
      a = va.createPolicy("goog#html", {
        createHTML: b,
        createScript: b,
        createScriptURL: b,
      });
    } catch (c) {}
    return a;
  }
  function ya() {
    wa === void 0 && (wa = xa());
    return wa;
  }
  var za = function (a) {
    this.h = a;
  };
  za.prototype.toString = function () {
    return this.h + "";
  };
  function Aa(a) {
    var b = ya();
    a = b ? b.createScriptURL(a) : a;
    return new za(a);
  }
  var Ba = function (a) {
    this.h = a;
  };
  Ba.prototype.toString = function () {
    return this.h + "";
  };
  function Ca(a) {
    var b = ya();
    a = b ? b.createHTML(a) : a;
    return new Ba(a);
  }
  function Da(a) {
    if (a instanceof Ba) return a.h;
    throw Error("");
  }
  var Fa = function (a) {
      var b = { "&amp;": "&", "&lt;": "<", "&gt;": ">", "&quot;": '"' };
      var c = w.document.createElement("div");
      return a.replace(Ea, function (d, e) {
        var f = b[d];
        if (f) return f;
        e.charAt(0) == "#" &&
          ((e = Number("0" + e.slice(1))),
          isNaN(e) || (f = String.fromCharCode(e)));
        if (!f) {
          f = Ca(d + " ");
          if (c.nodeType === 1 && /^(script|style)$/i.test(c.tagName))
            throw Error("");
          c.innerHTML = Da(f);
          f = c.firstChild.nodeValue.slice(0, -1);
        }
        return (b[d] = f);
      });
    },
    Ga = function (a) {
      return a.replace(/&([^;]+);/g, function (b, c) {
        switch (c) {
          case "amp":
            return "&";
          case "lt":
            return "<";
          case "gt":
            return ">";
          case "quot":
            return '"';
          default:
            return c.charAt(0) != "#" ||
              ((c = Number("0" + c.slice(1))), isNaN(c))
              ? b
              : String.fromCharCode(c);
        }
      });
    },
    Ea = /&([^;\s<&]+);?/g;
  function Ha(a) {
    var b, c;
    return (c = (b = /https?:\/\/[^\/]+/.exec(a)) == null ? void 0 : b[0]) !=
      null
      ? c
      : "";
  }
  var Ia = function (a) {
    var b = b === void 0 ? document : b;
    return b.createElement(String(a).toLowerCase());
  };
  function Ja(a, b) {
    for (var c in a) b.call(void 0, a[c], c, a);
  }
  var Ka =
    "constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(
      " "
    );
  function La(a, b) {
    for (var c, d, e = 1; e < arguments.length; e++) {
      d = arguments[e];
      for (c in d) a[c] = d[c];
      for (var f = 0; f < Ka.length; f++)
        (c = Ka[f]),
          Object.prototype.hasOwnProperty.call(d, c) && (a[c] = d[c]);
    }
  }
  var Na = function (a, b) {
      Ja(b, function (c, d) {
        d == "style"
          ? (a.style.cssText = c)
          : d == "class"
          ? (a.className = c)
          : d == "for"
          ? (a.htmlFor = c)
          : Ma.hasOwnProperty(d)
          ? a.setAttribute(Ma[d], c)
          : d.lastIndexOf("aria-", 0) == 0 || d.lastIndexOf("data-", 0) == 0
          ? a.setAttribute(d, c)
          : (a[d] = c);
      });
    },
    Ma = {
      cellpadding: "cellPadding",
      cellspacing: "cellSpacing",
      colspan: "colSpan",
      frameborder: "frameBorder",
      height: "height",
      maxlength: "maxLength",
      nonce: "nonce",
      role: "role",
      rowspan: "rowSpan",
      type: "type",
      usemap: "useMap",
      valign: "vAlign",
      width: "width",
    },
    Pa = function (a, b, c) {
      var d = arguments,
        e = document,
        f = d[1];
      var h = String(d[0]);
      h = String(h);
      e.contentType === "application/xhtml+xml" && (h = h.toLowerCase());
      h = e.createElement(h);
      f &&
        (typeof f === "string"
          ? (h.className = f)
          : Array.isArray(f)
          ? (h.className = f.join(" "))
          : Na(h, f));
      d.length > 2 && Oa(e, h, d);
      return h;
    },
    Oa = function (a, b, c) {
      function d(g) {
        g && b.appendChild(typeof g === "string" ? a.createTextNode(g) : g);
      }
      for (var e = 2; e < c.length; e++) {
        var f = c[e];
        if (!ka(f) || (x(f) && f.nodeType > 0)) d(f);
        else {
          a: {
            if (f && typeof f.length == "number") {
              if (x(f)) {
                var h =
                  typeof f.item == "function" || typeof f.item == "string";
                break a;
              }
              if (typeof f === "function") {
                h = typeof f.item == "function";
                break a;
              }
            }
            h = !1;
          }
          na(h ? ra(f) : f, d);
        }
      }
    },
    y = function (a) {
      return a.nodeType == 9 ? a : a.ownerDocument || a.document;
    };
  var Qa = new (function (a, b) {
    b = b === void 0 ? !1 : b;
    this.h = a;
    this.defaultValue = b;
  })(45803173);
  var Ra = function (a) {
    var b = "T";
    if (a.T && a.hasOwnProperty(b)) return a.T;
    b = new a();
    return (a.T = b);
  };
  function Sa(a, b) {
    if (typeof ReportingObserver === "undefined")
      return { ja: null, destroy: function () {} };
    var c = function (f) {
        f = r(f);
        var h = f.next();
        try {
          for (; !h.done; h = f.next()) {
            var g = h.value;
            a(g) && b(g);
          }
        } finally {
          t(f, h);
        }
      },
      d = new ReportingObserver(c, { buffered: !0 }),
      e = function () {
        c(d.takeRecords(), d);
        d.disconnect();
      };
    w.addEventListener("pagehide", e);
    d.observe();
    return {
      ja: d,
      destroy: function () {
        d.disconnect();
        w.removeEventListener("pagehide", e);
      },
    };
  }
  var Ta = {
    xa: "AdClickThru",
    ya: "AdDurationChange",
    AD_ERROR: "AdError",
    za: "AdExpandedChange",
    Aa: "AdImpression",
    Ba: "AdInteraction",
    Ca: "AdLinearChange",
    Da: "AdLoaded",
    Ea: "AdLog",
    Fa: "AdPaused",
    Ga: "AdPlaying",
    Ha: "AdRemainingTimeChange",
    Ia: "AdSizeChange",
    Ka: "AdSkipped",
    La: "AdStarted",
    Ma: "AdStopped",
    Ja: "AdSkippableStateChange",
    Na: "AdUserAcceptInvitation",
    Oa: "AdUserClose",
    Pa: "AdUserMinimize",
    Qa: "AdVideoComplete",
    Ra: "AdVideoFirstQuartile",
    Sa: "AdVideoMidpoint",
    Ta: "AdVideoStart",
    Ua: "AdVideoThirdQuartile",
    Va: "AdVolumeChange",
    Wa: "Ping",
  };
  var Ua = RegExp("^https?://(\\w|-)+\\.cdn\\.ampproject\\.(net|org)(\\?|/|$)"),
    Ya = function (a) {
      a = a || Va();
      for (
        var b = new Wa(w.location.href, !1), c = null, d = a.length - 1, e = d;
        e >= 0;
        --e
      ) {
        var f = a[e];
        !c && Ua.test(f.url) && (c = f);
        if (f.url && !f.h) {
          b = f;
          break;
        }
      }
      e = null;
      f = a.length && a[d].url;
      b.depth !== 0 && f && (e = a[d]);
      return new Xa(b, e, c);
    },
    Va = function () {
      var a = w,
        b = [],
        c = null;
      do {
        var d = a;
        try {
          var e;
          if ((e = !!d && d.location.href != null))
            b: {
              try {
                ta(d.foo);
                e = !0;
                break b;
              } catch (g) {}
              e = !1;
            }
          var f = e;
        } catch (g) {
          f = !1;
        }
        if (f) {
          var h = d.location.href;
          c = (d.document && d.document.referrer) || null;
        } else (h = c), (c = null);
        b.push(new Wa(h || ""));
        try {
          a = d.parent;
        } catch (g) {
          a = null;
        }
      } while (a && d !== a);
      d = 0;
      for (a = b.length - 1; d <= a; ++d) b[d].depth = a - d;
      d = w;
      if (
        d.location &&
        d.location.ancestorOrigins &&
        d.location.ancestorOrigins.length === b.length - 1
      )
        for (a = 1; a < b.length; ++a)
          (h = b[a]),
            h.url ||
              ((h.url = d.location.ancestorOrigins[a - 1] || ""), (h.h = !0));
      return b;
    },
    Xa = function (a, b, c) {
      this.i = a;
      this.j = b;
      this.h = c;
    },
    Wa = function (a, b) {
      this.url = a;
      this.h = !!b;
      this.depth = null;
    };
  var $a = function (a, b, c, d, e) {
      var f = [];
      ua(a, function (h, g) {
        (h = Za(h, b, c, d, e)) && f.push(encodeURIComponent(g) + "=" + h);
      });
      return f.join(b);
    },
    Za = function (a, b, c, d, e) {
      if (a == null) return "";
      b = b || "&";
      c = c || ",$";
      typeof c === "string" && (c = c.split(""));
      if (a instanceof Array) {
        if ((d || (d = 0), d < c.length)) {
          for (var f = [], h = 0; h < a.length; h++)
            f.push(Za(a[h], b, c, d + 1, e));
          return f.join(c[d]);
        }
      } else if (typeof a === "object")
        return (
          e || (e = 0),
          e < 2 ? encodeURIComponent($a(a, b, c, d, e + 1)) : "..."
        );
      return encodeURIComponent(String(a));
    };
  var z = function (a, b) {
      this.h = a;
      this.depth = b;
    },
    bb = function () {
      var a = Va(),
        b = Math.max(a.length - 1, 0),
        c = Ya(a);
      a = c.i;
      var d = c.j,
        e = c.h,
        f = [];
      c = function (g, k) {
        return g == null ? k : g;
      };
      e && f.push(new z([e.url, e.h ? 2 : 0], c(e.depth, 1)));
      d && d != e && f.push(new z([d.url, 2], 0));
      a.url && a != e && f.push(new z([a.url, 0], c(a.depth, b)));
      var h = oa(f, function (g, k) {
        return f.slice(0, f.length - k);
      });
      !a.url ||
        ((e || d) && a != e) ||
        ((d = Ha(a.url)) && h.push([new z([d, 1], c(a.depth, b))]));
      h.push([]);
      return oa(h, function (g) {
        return ab(b, g);
      });
    };
  function ab(a, b) {
    var c = pa(b, function (e, f) {
        return Math.max(e, f.depth);
      }),
      d = sa(c + 2);
    d[0] = a;
    na(b, function (e) {
      return (d[e.depth + 1] = e.h);
    });
    return d;
  }
  function cb() {
    var a = a === void 0 ? bb() : a;
    return a.map(function (b) {
      return Za(b);
    });
  }
  function db(a) {
    if (typeof DOMParser != "undefined") {
      var b = new DOMParser();
      a = Ca(a === null ? "null" : a === void 0 ? "undefined" : a);
      return b.parseFromString(Da(a), "application/xml");
    }
    throw Error("Your browser does not support loading xml documents");
  }
  var eb =
    typeof AsyncContext !== "undefined" &&
    typeof AsyncContext.Snapshot === "function"
      ? function (a) {
          return a && AsyncContext.Snapshot.wrap(a);
        }
      : function (a) {
          return a;
        };
  function A() {
    this.o = this.o;
    this.v = this.v;
  }
  A.prototype.o = !1;
  A.prototype.dispose = function () {
    this.o || ((this.o = !0), this.m());
  };
  A.prototype[Symbol.dispose] = function () {
    this.dispose();
  };
  A.prototype.m = function () {
    if (this.v) for (; this.v.length; ) this.v.shift()();
  };
  var B = function (a, b) {
    this.type = a;
    this.currentTarget = this.target = b;
    this.defaultPrevented = !1;
  };
  B.prototype.preventDefault = function () {
    this.defaultPrevented = !0;
  };
  function C(a, b) {
    B.call(this, a ? a.type : "");
    this.relatedTarget = this.currentTarget = this.target = null;
    this.button = this.screenY = this.screenX = this.clientY = this.clientX = 0;
    this.key = "";
    this.keyCode = 0;
    this.metaKey = this.shiftKey = this.altKey = this.ctrlKey = !1;
    this.state = null;
    this.pointerId = 0;
    this.pointerType = "";
    this.h = null;
    a && this.init(a, b);
  }
  la(C, B);
  C.prototype.init = function (a, b) {
    var c = (this.type = a.type),
      d =
        a.changedTouches && a.changedTouches.length
          ? a.changedTouches[0]
          : null;
    this.target = a.target || a.srcElement;
    this.currentTarget = b;
    b = a.relatedTarget;
    b ||
      (c == "mouseover"
        ? (b = a.fromElement)
        : c == "mouseout" && (b = a.toElement));
    this.relatedTarget = b;
    d
      ? ((this.clientX = d.clientX !== void 0 ? d.clientX : d.pageX),
        (this.clientY = d.clientY !== void 0 ? d.clientY : d.pageY),
        (this.screenX = d.screenX || 0),
        (this.screenY = d.screenY || 0))
      : ((this.clientX = a.clientX !== void 0 ? a.clientX : a.pageX),
        (this.clientY = a.clientY !== void 0 ? a.clientY : a.pageY),
        (this.screenX = a.screenX || 0),
        (this.screenY = a.screenY || 0));
    this.button = a.button;
    this.keyCode = a.keyCode || 0;
    this.key = a.key || "";
    this.ctrlKey = a.ctrlKey;
    this.altKey = a.altKey;
    this.shiftKey = a.shiftKey;
    this.metaKey = a.metaKey;
    this.pointerId = a.pointerId || 0;
    this.pointerType = a.pointerType;
    this.state = a.state;
    this.h = a;
    a.defaultPrevented && C.R.preventDefault.call(this);
  };
  C.prototype.preventDefault = function () {
    C.R.preventDefault.call(this);
    var a = this.h;
    a.preventDefault ? a.preventDefault() : (a.returnValue = !1);
  };
  var fb = (function () {
    if (!w.addEventListener || !Object.defineProperty) return !1;
    var a = !1,
      b = Object.defineProperty({}, "passive", {
        get: function () {
          a = !0;
        },
      });
    try {
      var c = function () {};
      w.addEventListener("test", c, b);
      w.removeEventListener("test", c, b);
    } catch (d) {}
    return a;
  })();
  var D = "closure_listenable_" + ((Math.random() * 1e6) | 0);
  var gb = 0;
  function hb(a, b, c, d, e) {
    this.listener = a;
    this.proxy = null;
    this.src = b;
    this.type = c;
    this.capture = !!d;
    this.handler = e;
    this.key = ++gb;
    this.M = this.P = !1;
  }
  var F = function (a) {
    a.M = !0;
    a.listener = null;
    a.proxy = null;
    a.src = null;
    a.handler = null;
  };
  function G(a) {
    this.src = a;
    this.h = {};
    this.i = 0;
  }
  G.prototype.add = function (a, b, c, d, e) {
    var f = a.toString();
    a = this.h[f];
    a || ((a = this.h[f] = []), this.i++);
    var h = ib(a, b, d, e);
    h > -1
      ? ((b = a[h]), c || (b.P = !1))
      : ((b = new hb(b, this.src, f, !!d, e)), (b.P = c), a.push(b));
    return b;
  };
  var jb = function (a, b) {
      var c = b.type;
      c in a.h &&
        qa(a.h[c], b) &&
        (F(b), a.h[c].length == 0 && (delete a.h[c], a.i--));
    },
    ib = function (a, b, c, d) {
      for (var e = 0; e < a.length; ++e) {
        var f = a[e];
        if (!f.M && f.listener == b && f.capture == !!c && f.handler == d)
          return e;
      }
      return -1;
    };
  var kb = "closure_lm_" + ((Math.random() * 1e6) | 0),
    lb = {},
    mb = 0,
    ob = function (a, b, c, d, e) {
      if (d && d.once) nb(a, b, c, d, e);
      else if (Array.isArray(b))
        for (var f = 0; f < b.length; f++) ob(a, b[f], c, d, e);
      else
        (c = pb(c)),
          a && a[D]
            ? a.listen(b, c, x(d) ? !!d.capture : !!d, e)
            : qb(a, b, c, !1, d, e);
    },
    qb = function (a, b, c, d, e, f) {
      if (!b) throw Error("Invalid event type");
      var h = x(e) ? !!e.capture : !!e,
        g = rb(a);
      g || (a[kb] = g = new G(a));
      c = g.add(b, c, d, h, f);
      if (!c.proxy) {
        d = sb();
        c.proxy = d;
        d.src = a;
        d.listener = c;
        if (a.addEventListener)
          fb || (e = h),
            e === void 0 && (e = !1),
            a.addEventListener(b.toString(), d, e);
        else if (a.attachEvent) a.attachEvent(tb(b.toString()), d);
        else if (a.addListener && a.removeListener) a.addListener(d);
        else throw Error("addEventListener and attachEvent are unavailable.");
        mb++;
      }
    },
    sb = function () {
      var a = ub,
        b = function (c) {
          return a.call(b.src, b.listener, c);
        };
      return b;
    },
    nb = function (a, b, c, d, e) {
      if (Array.isArray(b))
        for (var f = 0; f < b.length; f++) nb(a, b[f], c, d, e);
      else
        (c = pb(c)),
          a && a[D]
            ? a.h.add(String(b), c, !0, x(d) ? !!d.capture : !!d, e)
            : qb(a, b, c, !0, d, e);
    },
    vb = function (a, b, c, d, e) {
      if (Array.isArray(b))
        for (var f = 0; f < b.length; f++) vb(a, b[f], c, d, e);
      else
        ((d = x(d) ? !!d.capture : !!d), (c = pb(c)), a && a[D])
          ? ((a = a.h),
            (b = String(b).toString()),
            b in a.h &&
              ((f = a.h[b]),
              (c = ib(f, c, d, e)),
              c > -1 &&
                (F(f[c]),
                Array.prototype.splice.call(f, c, 1),
                f.length == 0 && (delete a.h[b], a.i--))))
          : a &&
            (a = rb(a)) &&
            ((b = a.h[b.toString()]),
            (a = -1),
            b && (a = ib(b, c, d, e)),
            (c = a > -1 ? b[a] : null) && wb(c));
    },
    wb = function (a) {
      if (typeof a !== "number" && a && !a.M) {
        var b = a.src;
        if (b && b[D]) jb(b.h, a);
        else {
          var c = a.type,
            d = a.proxy;
          b.removeEventListener
            ? b.removeEventListener(c, d, a.capture)
            : b.detachEvent
            ? b.detachEvent(tb(c), d)
            : b.addListener && b.removeListener && b.removeListener(d);
          mb--;
          (c = rb(b))
            ? (jb(c, a), c.i == 0 && ((c.src = null), (b[kb] = null)))
            : F(a);
        }
      }
    },
    tb = function (a) {
      return a in lb ? lb[a] : (lb[a] = "on" + a);
    },
    ub = function (a, b) {
      if (a.M) a = !0;
      else {
        b = new C(b, this);
        var c = a.listener,
          d = a.handler || a.src;
        a.P && wb(a);
        a = c.call(d, b);
      }
      return a;
    },
    rb = function (a) {
      a = a[kb];
      return a instanceof G ? a : null;
    },
    xb = "__closure_events_fn_" + ((Math.random() * 1e9) >>> 0),
    pb = function (a) {
      if (typeof a === "function") return a;
      a[xb] ||
        (a[xb] = function (b) {
          return a.handleEvent(b);
        });
      return a[xb];
    };
  function H() {
    A.call(this);
    this.h = new G(this);
    this.L = this;
    this.F = null;
  }
  la(H, A);
  H.prototype[D] = !0;
  H.prototype.addEventListener = function (a, b, c, d) {
    ob(this, a, b, c, d);
  };
  H.prototype.removeEventListener = function (a, b, c, d) {
    vb(this, a, b, c, d);
  };
  var J = function (a, b) {
    var c,
      d = a.F;
    if (d) for (c = []; d; d = d.F) c.push(d);
    a = a.L;
    d = b.type || b;
    if (typeof b === "string") b = new B(b, a);
    else if (b instanceof B) b.target = b.target || a;
    else {
      var e = b;
      b = new B(d, a);
      La(b, e);
    }
    e = !0;
    var f;
    if (c)
      for (f = c.length - 1; f >= 0; f--) {
        var h = (b.currentTarget = c[f]);
        e = I(h, d, !0, b) && e;
      }
    h = b.currentTarget = a;
    e = I(h, d, !0, b) && e;
    e = I(h, d, !1, b) && e;
    if (c)
      for (f = 0; f < c.length; f++)
        (h = b.currentTarget = c[f]), (e = I(h, d, !1, b) && e);
  };
  H.prototype.m = function () {
    H.R.m.call(this);
    if (this.h) {
      var a = this.h,
        b = 0,
        c;
      for (c in a.h) {
        for (var d = a.h[c], e = 0; e < d.length; e++) ++b, F(d[e]);
        delete a.h[c];
        a.i--;
      }
    }
    this.F = null;
  };
  H.prototype.listen = function (a, b, c, d) {
    return this.h.add(String(a), b, !1, c, d);
  };
  var I = function (a, b, c, d) {
    b = a.h.h[String(b)];
    if (!b) return !0;
    b = b.concat();
    for (var e = !0, f = 0; f < b.length; ++f) {
      var h = b[f];
      if (h && !h.M && h.capture == c) {
        var g = h.listener,
          k = h.handler || h.src;
        h.P && jb(a.h, h);
        e = g.call(k, d) !== !1 && e;
      }
    }
    return e && !d.defaultPrevented;
  };
  var yb = RegExp(
    "^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$"
  );
  function zb(a, b) {
    if (a) {
      a = a.split("&");
      for (var c = 0; c < a.length; c++) {
        var d = a[c].indexOf("="),
          e = null;
        if (d >= 0) {
          var f = a[c].substring(0, d);
          e = a[c].substring(d + 1);
        } else f = a[c];
        b(f, e ? decodeURIComponent(e.replace(/\+/g, " ")) : "");
      }
    }
  }
  var K = function () {
    H.call(this);
    this.headers = new Map();
    this.i = !1;
    this.l = null;
    this.D = "";
    this.j = this.C = this.u = this.A = !1;
    this.H = null;
    this.J = "";
    this.K = !1;
  };
  la(K, H);
  var Ab = /^https?$/i,
    Bb = ["POST", "PUT"],
    Cb = [],
    Eb = function (a, b) {
      var c = new K();
      Cb.push(c);
      b && c.listen("complete", b);
      c.h.add("ready", c.N, !0, void 0, void 0);
      Db(c, a);
    };
  K.prototype.N = function () {
    this.dispose();
    qa(Cb, this);
  };
  var Db = function (a, b) {
      if (a.l)
        throw Error(
          "[goog.net.XhrIo] Object is active with another request=" +
            a.D +
            "; newUri=" +
            b
        );
      var c = c ? c.toUpperCase() : "GET";
      a.D = b;
      a.A = !1;
      a.i = !0;
      a.l = new XMLHttpRequest();
      a.l.onreadystatechange = eb(function () {
        return a.I();
      });
      try {
        (a.C = !0), a.l.open(c, String(b), !0), (a.C = !1);
      } catch (k) {
        Fb(a);
        return;
      }
      b = new Map(a.headers);
      var d = Array.from(b.keys()).find(function (k) {
          return "content-type" == k.toLowerCase();
        }),
        e = w.FormData && !1;
      !(ma(Bb, c) >= 0) ||
        d ||
        e ||
        b.set(
          "Content-Type",
          "application/x-www-form-urlencoded;charset=utf-8"
        );
      c = r(b);
      b = c.next();
      try {
        for (; !b.done; b = c.next()) {
          var f = r(b.value),
            h = f.next().value,
            g = f.next().value;
          a.l.setRequestHeader(h, g);
        }
      } finally {
        t(c, b);
      }
      a.J && (a.l.responseType = a.J);
      "withCredentials" in a.l &&
        a.l.withCredentials !== a.K &&
        (a.l.withCredentials = a.K);
      try {
        Gb(a), (a.u = !0), a.l.send(""), (a.u = !1);
      } catch (k) {
        Fb(a);
      }
    },
    Fb = function (a) {
      a.i = !1;
      a.l && ((a.j = !0), a.l.abort(), (a.j = !1));
      Hb(a);
      L(a);
    },
    Hb = function (a) {
      a.A || ((a.A = !0), J(a, "complete"), J(a, "error"));
    };
  K.prototype.abort = function () {
    this.l &&
      this.i &&
      ((this.i = !1),
      (this.j = !0),
      this.l.abort(),
      (this.j = !1),
      J(this, "complete"),
      J(this, "abort"),
      L(this));
  };
  K.prototype.m = function () {
    this.l &&
      (this.i && ((this.i = !1), (this.j = !0), this.l.abort(), (this.j = !1)),
      L(this, !0));
    K.R.m.call(this);
  };
  K.prototype.I = function () {
    this.o || (this.C || this.u || this.j ? Ib(this) : this.O());
  };
  K.prototype.O = function () {
    Ib(this);
  };
  var Ib = function (a) {
      if (a.i && typeof ja != "undefined")
        if (a.u && (a.l ? a.l.readyState : 0) == 4) setTimeout(a.I.bind(a), 0);
        else if ((J(a, "readystatechange"), (a.l ? a.l.readyState : 0) == 4)) {
          a.i = !1;
          try {
            Jb(a) ? (J(a, "complete"), J(a, "success")) : Hb(a);
          } finally {
            L(a);
          }
        }
    },
    L = function (a, b) {
      if (a.l) {
        Gb(a);
        var c = a.l;
        a.l = null;
        b || J(a, "ready");
        try {
          c.onreadystatechange = null;
        } catch (d) {}
      }
    },
    Gb = function (a) {
      a.H && (clearTimeout(a.H), (a.H = null));
    };
  K.prototype.isActive = function () {
    return !!this.l;
  };
  var Jb = function (a) {
      var b = Kb(a);
      a: switch (b) {
        case 200:
        case 201:
        case 202:
        case 204:
        case 206:
        case 304:
        case 1223:
          var c = !0;
          break a;
        default:
          c = !1;
      }
      if (!c) {
        if ((b = b === 0))
          (a = String(a.D).match(yb)[1] || null),
            !a &&
              w.self &&
              w.self.location &&
              (a = w.self.location.protocol.slice(0, -1)),
            (b = !Ab.test(a ? a.toLowerCase() : ""));
        c = b;
      }
      return c;
    },
    Kb = function (a) {
      try {
        return (a.l ? a.l.readyState : 0) > 2 ? a.l.status : -1;
      } catch (b) {
        return -1;
      }
    };
  var Lb = /^https?:\/\/ad.doubleclick.net\//,
    Mb = /;dc_qid=([^;]+)/,
    Nb = function () {
      this.statusText = "";
      this.error = !1;
      this.h = 0;
    },
    Pb = function (a, b, c) {
      if ((b = Ob(b)))
        (a.i = c),
          (a.h = 1),
          Eb(b, function (d) {
            a.h = 0;
            d = d.target;
            if (Jb(d)) {
              try {
                var e = d.l ? d.l.responseText : "";
              } catch (g) {
                e = "";
              }
              if (
                (e = db(e)) &&
                e.documentElement &&
                e.getElementsByTagName("parsererror").length === 0
              ) {
                if (typeof e.selectNodes != "undefined") {
                  var f = y(e);
                  typeof f.setProperty != "undefined" &&
                    f.setProperty("SelectionLanguage", "XPath");
                  e = e.selectNodes("/VAST/Ad");
                } else if (document.implementation.hasFeature("XPath", "3.0")) {
                  f = y(e);
                  d = f.createNSResolver(f.documentElement);
                  e = f.evaluate(
                    "/VAST/Ad",
                    e,
                    d,
                    XPathResult.ORDERED_NODE_SNAPSHOT_TYPE,
                    null
                  );
                  f = [];
                  d = e.snapshotLength;
                  for (var h = 0; h < d; h++) f.push(e.snapshotItem(h));
                  e = f;
                } else e = [];
                e.length === 0 && (a.h = 2);
              } else (a.statusText = "XML error"), (a.error = !0);
            } else {
              if (d == null) f = void 0;
              else
                try {
                  f = (d.l ? d.l.readyState : 0) > 2 ? d.l.statusText : "";
                } catch (g) {
                  f = "";
                }
              a.statusText = (d == null ? void 0 : Kb(d)) + " " + f;
              a.error = !0;
            }
            a.i && a.i();
          });
    },
    Ob = function (a) {
      try {
        if (!a) return null;
        var b = db(a),
          c,
          d;
        if (typeof b.selectSingleNode != "undefined") {
          var e = y(b);
          typeof e.setProperty != "undefined" &&
            e.setProperty("SelectionLanguage", "XPath");
          var f = b.selectSingleNode(
            "/VAST/Ad/*/Extensions/Extension[@type='DCMOriginalRequest']/RequestUrl"
          );
        } else if (document.implementation.hasFeature("XPath", "3.0")) {
          var h = y(b),
            g = h.createNSResolver(h.documentElement);
          f = h.evaluate(
            "/VAST/Ad/*/Extensions/Extension[@type='DCMOriginalRequest']/RequestUrl",
            b,
            g,
            XPathResult.FIRST_ORDERED_NODE_TYPE,
            null
          ).singleNodeValue;
        } else f = null;
        var k =
          (c = f) == null
            ? void 0
            : (d = c.firstChild) == null
            ? void 0
            : d.nodeValue;
        if (!k || !Lb.test(k)) return null;
        Mb.exec(k);
        return k + ";dc_rfl=" + cb()[0];
      } catch (l) {
        return null;
      }
    };
  function M(a, b) {
    this.j = this.v = this.m = "";
    this.A = null;
    this.u = this.i = "";
    this.o = !1;
    var c;
    a instanceof M
      ? ((this.o = b !== void 0 ? b : a.o),
        Qb(this, a.m),
        (this.v = a.v),
        (this.j = a.j),
        Rb(this, a.A),
        (this.i = a.i),
        Sb(this, Tb(a.h)),
        (this.u = a.u))
      : a && (c = String(a).match(yb))
      ? ((this.o = !!b),
        Qb(this, c[1] || "", !0),
        (this.v = N(c[2] || "")),
        (this.j = N(c[3] || "", !0)),
        Rb(this, c[4]),
        (this.i = N(c[5] || "", !0)),
        Sb(this, c[6] || "", !0),
        (this.u = N(c[7] || "")))
      : ((this.o = !!b), (this.h = new O(null, this.o)));
  }
  M.prototype.toString = function () {
    var a = [],
      b = this.m;
    b && a.push(P(b, Ub, !0), ":");
    var c = this.j;
    if (c || b == "file")
      a.push("//"),
        (b = this.v) && a.push(P(b, Ub, !0), "@"),
        a.push(
          encodeURIComponent(String(c)).replace(/%25([0-9a-fA-F]{2})/g, "%$1")
        ),
        (c = this.A),
        c != null && a.push(":", String(c));
    if ((c = this.i))
      this.j && c.charAt(0) != "/" && a.push("/"),
        a.push(P(c, c.charAt(0) == "/" ? Vb : Wb, !0));
    (c = this.h.toString()) && a.push("?", c);
    (c = this.u) && a.push("#", P(c, Xb));
    return a.join("");
  };
  M.prototype.resolve = function (a) {
    var b = new M(this),
      c = !!a.m;
    c ? Qb(b, a.m) : (c = !!a.v);
    c ? (b.v = a.v) : (c = !!a.j);
    c ? (b.j = a.j) : (c = a.A != null);
    var d = a.i;
    if (c) Rb(b, a.A);
    else if ((c = !!a.i)) {
      if (d.charAt(0) != "/")
        if (this.j && !this.i) d = "/" + d;
        else {
          var e = b.i.lastIndexOf("/");
          e != -1 && (d = b.i.slice(0, e + 1) + d);
        }
      e = d;
      if (e == ".." || e == ".") d = "";
      else if (e.indexOf("./") != -1 || e.indexOf("/.") != -1) {
        d = e.lastIndexOf("/", 0) == 0;
        e = e.split("/");
        for (var f = [], h = 0; h < e.length; ) {
          var g = e[h++];
          g == "."
            ? d && h == e.length && f.push("")
            : g == ".."
            ? ((f.length > 1 || (f.length == 1 && f[0] != "")) && f.pop(),
              d && h == e.length && f.push(""))
            : (f.push(g), (d = !0));
        }
        d = f.join("/");
      } else d = e;
    }
    c ? (b.i = d) : (c = a.h.toString() !== "");
    c ? Sb(b, Tb(a.h)) : (c = !!a.u);
    c && (b.u = a.u);
    return b;
  };
  var Qb = function (a, b, c) {
      a.m = c ? N(b, !0) : b;
      a.m && (a.m = a.m.replace(/:$/, ""));
    },
    Rb = function (a, b) {
      if (b) {
        b = Number(b);
        if (isNaN(b) || b < 0) throw Error("Bad port number " + b);
        a.A = b;
      } else a.A = null;
    },
    Sb = function (a, b, c) {
      b instanceof O
        ? ((a.h = b), Yb(a.h, a.o))
        : (c || (b = P(b, Zb)), (a.h = new O(b, a.o)));
    },
    N = function (a, b) {
      return a
        ? b
          ? decodeURI(a.replace(/%25/g, "%2525"))
          : decodeURIComponent(a)
        : "";
    },
    P = function (a, b, c) {
      return typeof a === "string"
        ? ((a = encodeURI(a).replace(b, $b)),
          c && (a = a.replace(/%25([0-9a-fA-F]{2})/g, "%$1")),
          a)
        : null;
    },
    $b = function (a) {
      a = a.charCodeAt(0);
      return "%" + ((a >> 4) & 15).toString(16) + (a & 15).toString(16);
    },
    Ub = /[#\/\?@]/g,
    Wb = /[#\?:]/g,
    Vb = /[#\?]/g,
    Zb = /[#\?@]/g,
    Xb = /#/g,
    O = function (a, b) {
      this.i = this.h = null;
      this.j = a || null;
      this.m = !!b;
    },
    Q = function (a) {
      a.h ||
        ((a.h = new Map()),
        (a.i = 0),
        a.j &&
          zb(a.j, function (b, c) {
            a.add(decodeURIComponent(b.replace(/\+/g, " ")), c);
          }));
    };
  O.prototype.add = function (a, b) {
    Q(this);
    this.j = null;
    a = R(this, a);
    var c = this.h.get(a);
    c || this.h.set(a, (c = []));
    c.push(b);
    this.i += 1;
    return this;
  };
  var ac = function (a, b) {
    Q(a);
    b = R(a, b);
    a.h.has(b) && ((a.j = null), (a.i -= a.h.get(b).length), a.h.delete(b));
  };
  O.prototype.clear = function () {
    this.h = this.j = null;
    this.i = 0;
  };
  var bc = function (a, b) {
    Q(a);
    b = R(a, b);
    return a.h.has(b);
  };
  O.prototype.forEach = function (a, b) {
    Q(this);
    this.h.forEach(function (c, d) {
      c.forEach(function (e) {
        a.call(b, e, d, this);
      }, this);
    }, this);
  };
  var cc = function (a, b) {
    Q(a);
    var c = [];
    if (typeof b === "string") bc(a, b) && (c = c.concat(a.h.get(R(a, b))));
    else
      for (a = Array.from(a.h.values()), b = 0; b < a.length; b++)
        c = c.concat(a[b]);
    return c;
  };
  O.prototype.set = function (a, b) {
    Q(this);
    this.j = null;
    a = R(this, a);
    bc(this, a) && (this.i -= this.h.get(a).length);
    this.h.set(a, [b]);
    this.i += 1;
    return this;
  };
  O.prototype.get = function (a, b) {
    if (!a) return b;
    a = cc(this, a);
    return a.length > 0 ? String(a[0]) : b;
  };
  O.prototype.toString = function () {
    if (this.j) return this.j;
    if (!this.h) return "";
    for (var a = [], b = Array.from(this.h.keys()), c = 0; c < b.length; c++) {
      var d = b[c],
        e = encodeURIComponent(String(d));
      d = cc(this, d);
      for (var f = 0; f < d.length; f++) {
        var h = e;
        d[f] !== "" && (h += "=" + encodeURIComponent(String(d[f])));
        a.push(h);
      }
    }
    return (this.j = a.join("&"));
  };
  var Tb = function (a) {
      var b = new O();
      b.j = a.j;
      a.h && ((b.h = new Map(a.h)), (b.i = a.i));
      return b;
    },
    R = function (a, b) {
      b = String(b);
      a.m && (b = b.toLowerCase());
      return b;
    },
    Yb = function (a, b) {
      b &&
        !a.m &&
        (Q(a),
        (a.j = null),
        a.h.forEach(function (c, d) {
          var e = d.toLowerCase();
          d != e &&
            (ac(this, d),
            ac(this, e),
            c.length > 0 &&
              ((this.j = null),
              this.h.set(R(this, e), ra(c)),
              (this.i += c.length)));
        }, a));
      a.m = b;
    };
  var dc = fa(["//imasdk.googleapis.com/js/sdkloader/ima3.js"]),
    ec = /Android|iPhone|iPod/i,
    fc = {
      qa: function (a) {
        return Sa(function (b) {
          var c;
          return (
            ((c = b.body) == null ? void 0 : c.id) === "HeavyAdIntervention"
          );
        }, a);
      },
    },
    S = function () {
      this.height = this.width = 0;
      this.J = !1;
      this.m = this.K = this.F = this.H = null;
      this.D = {};
      this.j = {};
      this.C = null;
      this.L = this.O = this.N = !1;
      this.u = hc();
      var a = Object.values(Ta);
      a = r(a);
      var b = a.next();
      try {
        for (; !b.done; b = a.next()) this.D[b.value] = [];
      } finally {
        t(a, b);
      }
      this.I = new Nb();
    },
    ic,
    jc;
  S.prototype.listen = function (a, b, c) {
    this.j[b] = c.bind(this);
    a.addEventListener
      ? a.addEventListener(b, this.j[b])
      : a.attachEvent(b, this.j[b]);
  };
  var T = function (a, b, c) {
      a.j[c] &&
        (b.removeEventListener
          ? b.removeEventListener(c, a.j[c])
          : b.detachEvent && b.detachEvent(c, a.j[c]),
        delete a.j[c]);
    },
    hc = function () {
      for (
        var a = w.document,
          b = RegExp(
            "//imasdk.googleapis.com/js/sdkloader/vpaid_adapter[_a-z]*.js(\\?.*)?$"
          ),
          c = null,
          d = 0;
        d < a.scripts.length;
        d++
      )
        if (b.test(a.scripts[d].src)) {
          c = a.scripts[d];
          break;
        }
      if (c == null) return null;
      a = new M(c.src, !0);
      b = a.h.get("adTagUrl");
      if (!b || (b.indexOf("http") !== 0 && b.indexOf("//") !== 0)) return null;
      b = new M(b, !0);
      c = b.h.get("channel");
      d = "vpaidadp_html5";
      c && (d = c + "+" + d);
      b.h.set("channel", d);
      (c = a.h.get("correlator")) && (kc = +c || -1);
      (c = a.h.get("scor")) && (lc = +c || -1);
      c = a.h.get("vpa");
      if (c === "1" || c === "0") ic = c === "1";
      c = a.h.get("vpmute");
      if (c === "1" || c === "0") jc = c === "1";
      mc(a, b);
      return b;
    },
    mc = function (a, b) {
      b.m === "https" &&
        ["rdid", "is_lat", "idtype"].forEach(function (c) {
          var d = a.h.get(c);
          d && b.h.set(c, d);
        });
    },
    V = function (a, b, c) {
      b = b === void 0 ? "Error" : b;
      if (c) {
        var d = c.toString();
        c.name && d.indexOf(c.name) == -1 && (d += ": " + c.name);
        c.message && d.indexOf(c.message) == -1 && (d += ": " + c.message);
        if (c.stack)
          a: {
            c = c.stack;
            var e = d;
            try {
              c.indexOf(e) == -1 && (c = e + "\n" + c);
              for (var f; c != f; )
                (f = c),
                  (c = c.replace(
                    RegExp("((https?:/..*/)[^/:]*:\\d+(?:.|\n)*)\\2"),
                    "$1"
                  ));
              d = c.replace(RegExp("\n *", "g"), "\n");
              break a;
            } catch (h) {
              d = e;
              break a;
            }
            d = void 0;
          }
        b += ": " + d;
      }
      a.L = !0;
      U(a, b);
      nc(a);
    },
    oc = function (a) {
      if (a.O && a.I.h === 0 && a.H && a.F && (a.u || a.m)) {
        var b = Ia("DIV");
        b.style.position = "absolute";
        b.style.zIndex = "99";
        b.style.width = "100%";
        b.style.height = "100%";
        a.v = b;
        var c;
        (c = a.H) == null || c.insertBefore(a.v, a.H.firstChild);
        a.A = new google.ima.AdDisplayContainer(a.v, a.F);
        a.A.initialize();
        a.o = new google.ima.AdsLoader(a.A);
        b = new google.ima.AdsRequest();
        c = ic;
        c != null && b.setAdWillAutoPlay(c);
        c = jc;
        c != null && b.setAdWillPlayMuted(c);
        a.u
          ? ((b.adTagUrl = a.u.toString()),
            (b.linearAdSlotHeight = a.height),
            (b.linearAdSlotWidth = a.width),
            (b.nonLinearAdSlotHeight = a.height),
            (b.nonLinearAdSlotWidth = a.width))
          : (b.adsResponse = a.m);
        a.listen(
          a.o,
          google.ima.AdsManagerLoadedEvent.Type.ADS_MANAGER_LOADED,
          a.la
        );
        a.listen(a.o, google.ima.AdErrorEvent.Type.AD_ERROR, a.U);
        a.o.requestAds(b);
      }
    };
  m = S.prototype;
  m.ga = function () {
    this.I.h === 2 ? ((this.L = !0), this.i("AdError")) : oc(this);
  };
  m.ha = function () {
    return "2.0";
  };
  m.ia = function (a, b, c, d, e, f) {
    this.width = a;
    this.height = b;
    a = f && f.slot;
    f = f && f.videoSlot;
    if (
      (e = (e = e && e.AdParameters)
        ? e.indexOf("&") != -1
          ? "document" in w
            ? Fa(e)
            : Ga(e)
          : e
        : null)
    )
      this.m = e;
    pc(this);
    a && f && (this.u || this.m)
      ? (Pb(this.I, this.m, this.ga.bind(this)),
        (this.H = a),
        (this.F = f),
        ec.test(w.navigator.userAgent) && this.F.load(),
        oc(this))
      : V(
          this,
          "Error during init:" +
            (a ? "" : " ad slot is missing") +
            (f ? "" : " video slot is missing") +
            (this.u || this.m ? "" : " no ad VAST or URL found")
        );
  };
  m.va = function () {
    if (W(this))
      try {
        var a;
        (a = this.h) == null || a.init(this.width, this.height);
        var b;
        (b = this.h) == null || b.start();
      } catch (c) {
        V(this, "", c);
      }
    else U(this);
  };
  m.wa = function () {
    if (this.N) qc(this);
    else if (W(this)) {
      var a;
      (a = this.h) == null || a.stop();
    } else U(this);
  };
  m.pa = function () {
    if (W(this)) {
      var a;
      (a = this.h) == null || a.pause();
    } else U(this);
  };
  m.sa = function () {
    if (W(this)) {
      var a;
      (a = this.h) == null || a.resume();
    } else U(this);
  };
  m.ra = function (a, b) {
    if (W(this)) {
      this.width = a;
      this.height = b;
      var c;
      (c = this.h) == null || c.resize(this.width, this.height);
      this.i("AdSizeChange");
    } else U(this);
  };
  m.W = function () {
    if (W(this)) {
      var a;
      (a = this.h) == null || a.expand();
      this.J = !0;
      this.i("AdExpandedChange");
    } else U(this);
  };
  m.V = function () {
    if (W(this)) {
      var a;
      (a = this.h) == null || a.collapse();
      this.J = !1;
      this.i("AdExpandedChange");
    } else U(this);
  };
  m.ua = function () {
    if (W(this)) {
      var a;
      if ((a = this.h) != null && a.getAdSkippableState()) {
        var b;
        (b = this.h) == null || b.skip();
      }
    } else U(this);
  };
  m.subscribe = function (a, b, c) {
    (b = this.D[b]) && b.push({ handler: a, scope: c });
  };
  m.unsubscribe = function (a, b) {
    var c = this.D[b],
      d = [];
    c &&
      (c.forEach(function (e) {
        e.handler !== a && d.push(e);
      }),
      (this.D[b] = d));
  };
  m.ca = function () {
    return !0;
  };
  m.fa = function () {
    return this.width;
  };
  m.aa = function () {
    return this.height;
  };
  m.Z = function () {
    return this.J;
  };
  m.getAdSkippableState = function () {
    if (!this.h) return !1;
    var a;
    return (a = this.h) == null ? void 0 : a.getAdSkippableState();
  };
  m.da = function () {
    var a = -2;
    this.h && ((a = this.h.getRemainingTime()), a === -1 && (a = -2));
    return a;
  };
  m.Y = function () {
    return this.K ? this.K.getDuration() : -2;
  };
  m.ea = function () {
    if (!this.h) return -1;
    var a;
    return (a = this.h) == null ? void 0 : a.getVolume();
  };
  m.ta = function (a) {
    if (this.h) {
      var b;
      (b = this.h) == null || b.setVolume(a);
    }
  };
  m.X = function () {
    return "";
  };
  m.ba = function () {
    return !1;
  };
  var W = function (a) {
      return !a.L && a.h != null;
    },
    nc = function (a) {
      a.h &&
        (a.h.destroy(),
        T(a, a.h, google.ima.AdEvent.Type.IMPRESSION),
        T(a, a.h, google.ima.AdEvent.Type.STARTED),
        T(a, a.h, google.ima.AdEvent.Type.CLICK),
        T(a, a.h, google.ima.AdEvent.Type.FIRST_QUARTILE),
        T(a, a.h, google.ima.AdEvent.Type.MIDPOINT),
        T(a, a.h, google.ima.AdEvent.Type.THIRD_QUARTILE),
        T(a, a.h, google.ima.AdEvent.Type.COMPLETE),
        T(a, a.h, google.ima.AdEvent.Type.PAUSED),
        T(a, a.h, google.ima.AdEvent.Type.RESUMED),
        T(a, a.h, google.ima.AdEvent.Type.SKIPPED),
        T(a, a.h, google.ima.AdEvent.Type.SKIPPABLE_STATE_CHANGED),
        T(a, a.h, google.ima.AdEvent.Type.VOLUME_CHANGED),
        T(a, a.h, google.ima.AdEvent.Type.VOLUME_MUTED),
        T(a, a.h, google.ima.AdEvent.Type.USER_CLOSE),
        T(a, a.h, google.ima.AdEvent.Type.LOADED),
        T(a, a.h, google.ima.AdEvent.Type.LOG),
        T(a, a.h, google.ima.AdEvent.Type.ALL_ADS_COMPLETED),
        T(a, a.h, google.ima.AdErrorEvent.Type.AD_ERROR),
        delete a.h);
      a.o && (a.o.destroy(), delete a.o);
      a.A && (a.A.destroy(), delete a.A);
      if (a.v) {
        var b = a.v;
        b && b.parentNode && b.parentNode.removeChild(b);
        delete a.v;
      }
    };
  S.prototype.i = function (a, b) {
    (a = this.D[a]) &&
      a.forEach(function (c) {
        c.handler.apply(c.scope, b);
      });
  };
  var U = function (a, b) {
      a.i("AdError", b ? [b] : void 0);
    },
    rc = function (a) {
      a.C == null &&
        (a.C = w.setInterval(
          S.prototype.i.bind(a, "AdRemainingTimeChange"),
          500
        ));
    },
    sc = function (a) {
      a.C != null && (w.clearInterval(a.C), (a.C = null));
    };
  m = S.prototype;
  m.na = function (a) {
    this.O = !0;
    a.target != null && (T(this, a.target, "load"), T(this, a.target, "error"));
    google.ima.settings.setVpaidMode(
      google.ima.ImaSdkSettings.VpaidMode.INSECURE
    );
    google.ima.settings.setIsVpaidAdapter(!0);
    kc > 0 && google.ima.settings.setPageCorrelator(kc);
    lc > 0 && google.ima.settings.setStreamCorrelator(lc);
    oc(this);
  };
  m.oa = function (a) {
    a.target && (T(this, a.target, "load"), T(this, a.target, "error"));
    V(this, "SdkLoadError");
  };
  m.la = function (a) {
    this.h = a.getAdsManager(this.F);
    this.listen(this.h, google.ima.AdEvent.Type.IMPRESSION, this.B);
    this.listen(this.h, google.ima.AdEvent.Type.STARTED, this.B);
    this.listen(this.h, google.ima.AdEvent.Type.CLICK, this.B);
    this.listen(this.h, google.ima.AdEvent.Type.FIRST_QUARTILE, this.B);
    this.listen(this.h, google.ima.AdEvent.Type.MIDPOINT, this.B);
    this.listen(this.h, google.ima.AdEvent.Type.THIRD_QUARTILE, this.B);
    this.listen(this.h, google.ima.AdEvent.Type.COMPLETE, this.B);
    this.listen(this.h, google.ima.AdEvent.Type.PAUSED, this.B);
    this.listen(this.h, google.ima.AdEvent.Type.RESUMED, this.B);
    this.listen(this.h, google.ima.AdEvent.Type.SKIPPED, this.B);
    this.listen(
      this.h,
      google.ima.AdEvent.Type.SKIPPABLE_STATE_CHANGED,
      this.B
    );
    this.listen(this.h, google.ima.AdEvent.Type.VOLUME_CHANGED, this.B);
    this.listen(this.h, google.ima.AdEvent.Type.VOLUME_MUTED, this.B);
    this.listen(this.h, google.ima.AdEvent.Type.USER_CLOSE, this.B);
    this.listen(this.h, google.ima.AdEvent.Type.LOADED, this.ka);
    this.listen(this.h, google.ima.AdEvent.Type.ALL_ADS_COMPLETED, this.ma);
    this.listen(this.h, google.ima.AdErrorEvent.Type.AD_ERROR, this.U);
    this.i("AdLoaded");
  };
  m.B = function (a) {
    switch (a.type) {
      case google.ima.AdEvent.Type.IMPRESSION:
        this.i("AdImpression");
        break;
      case google.ima.AdEvent.Type.STARTED:
        this.i("AdStarted");
        this.i("AdVideoStart");
        rc(this);
        break;
      case google.ima.AdEvent.Type.CLICK:
        this.i("AdClickThru", ["", "", !1]);
        break;
      case google.ima.AdEvent.Type.FIRST_QUARTILE:
        this.i("AdVideoFirstQuartile");
        break;
      case google.ima.AdEvent.Type.MIDPOINT:
        this.i("AdVideoMidpoint");
        break;
      case google.ima.AdEvent.Type.THIRD_QUARTILE:
        this.i("AdVideoThirdQuartile");
        break;
      case google.ima.AdEvent.Type.COMPLETE:
        this.i("AdVideoComplete");
        break;
      case google.ima.AdEvent.Type.PAUSED:
        this.i("AdPaused");
        sc(this);
        break;
      case google.ima.AdEvent.Type.RESUMED:
        this.i("AdPlaying");
        rc(this);
        break;
      case google.ima.AdEvent.Type.SKIPPED:
        this.i("AdSkipped");
        sc(this);
        break;
      case google.ima.AdEvent.Type.SKIPPABLE_STATE_CHANGED:
        this.i("AdSkippableStateChange");
        break;
      case google.ima.AdEvent.Type.VOLUME_CHANGED:
      case google.ima.AdEvent.Type.VOLUME_MUTED:
        this.i("AdVolumeChange");
        break;
      case google.ima.AdEvent.Type.USER_CLOSE:
        this.i("AdUserClose");
    }
  };
  m.ka = function (a) {
    this.K = a.getAd();
  };
  m.U = function (a) {
    a = a.getError ? a.getError() : null;
    var b =
      "AdError" +
      (a ? " " + a.getErrorCode() + " (" + a.getMessage() + ")" : "");
    V(this, b, a);
  };
  m.ma = function () {
    this.N = !0;
    sc(this);
    qc(this);
  };
  var qc = function (a) {
      w.setTimeout(function () {
        nc(a);
        a.i("AdStopped");
      }, 100);
    },
    pc = function (a) {
      fc.qa(function (b) {
        a.i("AdError", ["HeavyAdIntervention: " + b.body.message]);
      });
    },
    kc = -1,
    lc = -1;
  var X = Ra(S),
    tc = (function (a) {
      var b = ha.apply(1, arguments);
      if (b.length === 0) return Aa(a[0]);
      for (var c = a[0], d = 0; d < b.length; d++)
        c += encodeURIComponent(b[d]) + a[d + 1];
      return Aa(c);
    })(dc),
    Y;
  Y = Ra(function () {
    var a = {};
    this.h = function () {
      var b = Qa.h,
        c = Qa.defaultValue,
        d;
      a[b] != null ? (d = a[b]) : (d = c);
      return d;
    };
  }).h()
    ? Ia("SCRIPT")
    : Pa("SCRIPT");
  Y.type = "text/javascript";
  var uc;
  if (tc instanceof za) uc = tc.h;
  else throw Error("");
  Y.src = uc;
  var vc,
    Z = Y.ownerDocument;
  Z = Z === void 0 ? document : Z;
  var wc,
    xc,
    yc =
      (xc = (wc = Z).querySelector) == null
        ? void 0
        : xc.call(wc, "script[nonce]");
  (vc = yc == null ? "" : yc.nonce || yc.getAttribute("nonce") || "") &&
    Y.setAttribute("nonce", vc);
  X.listen(Y, "load", X.na);
  X.listen(Y, "error", X.oa);
  var zc = w.document;
  (zc.body || zc.head).appendChild(Y);
  S.prototype.handshakeVersion = S.prototype.ha;
  S.prototype.initAd = S.prototype.ia;
  S.prototype.resizeAd = S.prototype.ra;
  S.prototype.startAd = S.prototype.va;
  S.prototype.stopAd = S.prototype.wa;
  S.prototype.pauseAd = S.prototype.pa;
  S.prototype.resumeAd = S.prototype.sa;
  S.prototype.expandAd = S.prototype.W;
  S.prototype.collapseAd = S.prototype.V;
  S.prototype.skipAd = S.prototype.ua;
  S.prototype.subscribe = S.prototype.subscribe;
  S.prototype.unsubscribe = S.prototype.unsubscribe;
  S.prototype.getAdLinear = S.prototype.ca;
  S.prototype.getAdWidth = S.prototype.fa;
  S.prototype.getAdHeight = S.prototype.aa;
  S.prototype.getAdExpanded = S.prototype.Z;
  S.prototype.getAdSkippableState = S.prototype.getAdSkippableState;
  S.prototype.getAdRemainingTime = S.prototype.da;
  S.prototype.getAdDuration = S.prototype.Y;
  S.prototype.getAdVolume = S.prototype.ea;
  S.prototype.setAdVolume = S.prototype.ta;
  S.prototype.getAdCompanions = S.prototype.X;
  S.prototype.getAdIcons = S.prototype.ba;
  w.getVPAIDAd = function () {
    return Ra(S);
  };
}.call(this));
