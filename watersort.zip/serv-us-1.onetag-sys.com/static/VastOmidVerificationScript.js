(() => {
  "use strict";
  class t {
    static fromCreative(e) {
      var i;
      return new t(
        null === (i = e.debugInfo) || void 0 === i ? void 0 : i.version,
        e.isPreprod,
        e.maxLogLevel
      );
    }
    constructor(t = "", e = !1, i) {
      (this.version = t), (this._isPreprod = e), (this.maxLogLevel = i);
    }
    getVersion() {
      return this.version;
    }
    isPreprod() {
      return this._isPreprod;
    }
    getMaxLogLevel() {
      return null != this.maxLogLevel
        ? this.maxLogLevel
        : this._isPreprod
        ? 4
        : void 0;
    }
    toJSON() {
      return { version: this.version, isPreprod: this._isPreprod };
    }
  }
  class e {
    static fromCreative(t) {
      return new e({
        debugInfo: t.debugInfo,
        impressionId: t.impressionId,
        bidUUID: t.bidUUID,
      });
    }
    constructor(t) {
      var e;
      (this.debugInfo = t.debugInfo),
        (this.impressionId =
          null !== (e = t.impressionId) && void 0 !== e ? e : ""),
        (this.bidUUID = t.bidUUID);
    }
    getDspId() {
      var t;
      return null === (t = this.debugInfo) || void 0 === t ? void 0 : t.dspId;
    }
    getCrId() {
      var t;
      return null === (t = this.debugInfo) || void 0 === t ? void 0 : t.crId;
    }
    getAdomain() {
      var t;
      return null === (t = this.debugInfo) || void 0 === t ? void 0 : t.adomain;
    }
    getPubId() {
      var t;
      return null === (t = this.debugInfo) || void 0 === t ? void 0 : t.pubId;
    }
    getDomain() {
      var t;
      return null === (t = this.debugInfo) || void 0 === t ? void 0 : t.domain;
    }
    getImpressionId() {
      return this.impressionId;
    }
    getBidUUID() {
      return this.bidUUID;
    }
    toJSON() {
      var t, e, i, s, n;
      return {
        dspId: null === (t = this.debugInfo) || void 0 === t ? void 0 : t.dspId,
        crId: null === (e = this.debugInfo) || void 0 === e ? void 0 : e.crId,
        adomain:
          null === (i = this.debugInfo) || void 0 === i ? void 0 : i.adomain,
        pubId: null === (s = this.debugInfo) || void 0 === s ? void 0 : s.pubId,
        domain:
          null === (n = this.debugInfo) || void 0 === n ? void 0 : n.domain,
        bidUUID: this.bidUUID,
        impressionId: this.impressionId,
      };
    }
  }
  function i(t) {
    switch (t) {
      case "production":
        return "production";
      case "development":
        return "development";
    }
  }
  class s {
    static getCurrent() {
      return new s({ window });
    }
    constructor(t = { window }, e = null) {
      (this.source = t), (this.fallbackOrigin = e);
    }
    getType() {
      return this.isDetached()
        ? "DETACHED_FRAME"
        : this.isTopmost()
        ? "TOPMOST"
        : this.isFriendly()
        ? "FRIENDLY_FRAME"
        : this.isOpaque()
        ? "OPAQUE_FRAME"
        : "UNFRIENDLY_FRAME";
    }
    getWindow() {
      return this.source.window;
    }
    getDepth() {
      if (this.isDetached()) return -1;
      let t = 0,
        e = this.source.window;
      for (; e !== e.top; ) {
        if ((t++, null == e.parent)) return -1;
        e = e.parent;
      }
      return t;
    }
    isDetached() {
      return (
        null == this.source.window.top || null == this.source.window.parent
      );
    }
    isTopmost() {
      return (
        !this.isDetached() && this.source.window.top === this.source.window
      );
    }
    isNested() {
      return !this.isTopmost();
    }
    isAccessible() {
      try {
        return this.source.window.location.href, !0;
      } catch (t) {
        return !1;
      }
    }
    isFriendly() {
      return (
        !this.isDetached() &&
        (!!this.isTopmost() ||
          (this.isAccessible() &&
            this.getAncestors().every((t) => t.isAccessible())))
      );
    }
    isUnfriendly() {
      return !this.isFriendly();
    }
    isOpaque() {
      return this.isUnfriendly() && "null" === this.source.window.origin;
    }
    getOrigin() {
      return this.isAccessible()
        ? this.source.window.location.origin
        : this.fallbackOrigin;
    }
    getParent() {
      return this.isDetached() || this.isTopmost()
        ? null
        : new s(
            { window: this.source.window.parent },
            this.getAncestorOrigins()[0]
          );
    }
    getAncestorOrigins() {
      return this.isAccessible() && this.source.window.location.ancestorOrigins
        ? (function (t) {
            const e = [];
            for (let i = 0; i < t.length; i++) e.push(t[i]);
            return e;
          })(this.source.window.location.ancestorOrigins)
        : [];
    }
    getAncestors() {
      if (this.isDetached() || this.isTopmost()) return [];
      const t = this.getAncestorOrigins();
      let e = 0,
        i = this.source.window.parent;
      const n = [];
      for (; null != i && i !== i.top; )
        n.push(new s({ window: i }, t[e])), (i = i.parent), e++;
      return null != i && n.push(new s({ window: i }, t[e])), n;
    }
    getFrameElement() {
      return !this.isDetached() && this.isNested()
        ? this.source.window.frameElement
        : null;
    }
    getTopmostContext() {
      if (this.isDetached() || this.isTopmost()) return this;
      const t = this.getAncestors();
      return 0 === t.length ? null : t[t.length - 1];
    }
    getTopmostOrigin() {
      const t = this.getTopmostContext();
      return t ? t.getOrigin() : null;
    }
    getTopmostFriendlyContext() {
      let t = this;
      for (const e of this.getAncestors()) {
        if (!e.isAccessible()) break;
        t = e;
      }
      return t;
    }
    getTopmostIFrame() {
      if (this.isDetached() || this.isTopmost() || this.isUnfriendly())
        return null;
      let t = null;
      if (1 === this.getDepth()) t = this.getFrameElement();
      else {
        const e = this.getAncestors().slice(0, -1);
        e.length > 0 && (t = e[e.length - 1].getFrameElement());
      }
      return null != t && s.isHTMLFrameElement(t) ? t : null;
    }
    getFriendlyFrames() {
      const t = [];
      for (const e of this.getAncestors()) {
        if (!e.isAccessible()) break;
        {
          const i = e.getFrameElement();
          null != i && s.isHTMLFrameElement(i) && t.push(i);
        }
      }
      return t;
    }
    getTopmostFriendlyWindow() {
      return this.getTopmostFriendlyContext().getWindow();
    }
    getTopmostFriendlyHref() {
      return this.getTopmostFriendlyWindow().location.href;
    }
    toJSON() {
      return {
        localReferrer: this.getWindow().document.referrer,
        localFrameUrl: this.getWindow().location.href,
        topmostFriendlyHref: this.getTopmostFriendlyHref(),
        topmostOrigin: this.getTopmostOrigin(),
        nesting: { depth: this.getDepth(), type: this.getType() },
      };
    }
    static isHTMLFrameElement(t) {
      return "iframe" === t.tagName.toLowerCase();
    }
  }
  class n extends Error {
    getAttachments() {
      return [];
    }
  }
  class r extends n {
    constructor(t) {
      super(
        (function (t) {
          switch (t) {
            case "http-error":
              return "HttpClient: error status";
            case "http-timeout":
              return "HttpClient: timeout";
            case "http-aborted":
              return "HttpClient: aborted";
            case "http-offline":
              return "HttpClient: offline";
            case "http-transport-failure":
              return "HttpClient: transport failure";
          }
        })(t.kind)
      ),
        (this.context = t),
        (this.code = t.kind);
    }
    getAttachments() {
      return [this.context];
    }
  }
  class o {
    static isFetchSupported() {
      return (
        "function" == typeof fetch && "undefined" != typeof AbortController
      );
    }
    constructor(t) {
      (this.defaultTimeout = t),
        (this.defaultMethod = "POST"),
        (this.defaultCredentials = "include");
    }
    send(t, e = {}, i) {
      const {
        body: s,
        method: n = this.defaultMethod,
        credentials: r = this.defaultCredentials,
        timeout: o = this.defaultTimeout,
        keepalive: a = !1,
      } = e;
      if (!i)
        return new Promise((e, i) => {
          const l = (t) => e(t),
            c = (t) => i(t);
          this.sendInternal(t, n, s, r, o, a, l, c);
        });
      {
        const { onLoad: e, onError: l } = i;
        this.sendInternal(t, n, s, r, o, a, e, l);
      }
    }
    sendInternal(t, e, i, s, n, r, a, l) {
      o.isFetchSupported()
        ? this.sendWithFetch(t, e, i, s, n, r, a, l)
        : this.sendWithXHR(t, e, i, s, n, r, a, l);
    }
    sendWithFetch(t, e, i, s, n, r, o, c) {
      const h = new AbortController(),
        d = a("fetch", t, e, r),
        u = l(o, c);
      let g;
      const m = {
        method: e,
        credentials: "include" === s ? "include" : "omit",
        signal: h.signal,
        keepalive: r,
      };
      i && (m.body = i),
        void 0 !== n &&
          n > 0 &&
          (g = window.setTimeout(() => {
            u.error(d("http-timeout", { timeoutMs: n })), h.abort();
          }, n));
      const p = () => {
        void 0 !== g && window.clearTimeout(g);
      };
      fetch(t, m)
        .then((t) =>
          t.ok
            ? t.text().then((t) => {
                p(), u.load(t);
              })
            : (p(), void u.error(d("http-error", { status: t.status })))
        )
        .catch((t) => {
          p();
          const e = (function (t) {
              const { name: e, message: i } =
                null !== t && "object" == typeof t ? t : {};
              return {
                rawName: "string" == typeof e ? e : void 0,
                rawMessage: "string" == typeof i ? i : void 0,
              };
            })(t),
            i =
              "AbortError" === e.rawName
                ? "http-aborted"
                : !1 === navigator.onLine
                ? "http-offline"
                : "http-transport-failure";
          u.error(d(i, e));
        });
    }
    sendWithXHR(t, e, i, s, n, r, o, c) {
      const h = new XMLHttpRequest(),
        d = a("xhr", t, e, r),
        u = l(o, c);
      h.open(e, t, !0),
        void 0 !== n && n > 0 && (h.timeout = n),
        (h.withCredentials = "include" === s),
        (h.onload = () => {
          h.status >= 200 && h.status <= 299
            ? u.load(h.responseText)
            : u.error(d("http-error", { status: h.status }));
        }),
        (h.ontimeout = () => {
          u.error(d("http-timeout", { timeoutMs: n }));
        }),
        (h.onabort = () => {
          u.error(d("http-aborted"));
        }),
        (h.onerror = () => {
          u.error(
            d(
              !1 === navigator.onLine
                ? "http-offline"
                : "http-transport-failure"
            )
          );
        }),
        i ? h.send(i) : h.send();
    }
    get(t, e = {}, i) {
      const { timeout: s, credentials: n } = e;
      return i
        ? this.send(t, { method: "GET", timeout: s, credentials: n }, i)
        : this.send(t, { method: "GET", timeout: s, credentials: n });
    }
    post(t, e, i = {}, s) {
      const { timeout: n, credentials: r = "include" } = i;
      return s
        ? this.send(
            t,
            { method: "POST", body: e, timeout: n, credentials: r },
            s
          )
        : this.send(t, { method: "POST", body: e, timeout: n, credentials: r });
    }
  }
  function a(t, e, i, s) {
    const n = Date.now();
    return (o, a) =>
      new r(
        Object.assign(
          {
            type: "http",
            kind: o,
            transport: t,
            method: i,
            url: e.split(/[?#]/)[0],
            elapsedMs: Date.now() - n,
            onLine: navigator.onLine,
            keepalive: s,
          },
          a
        )
      );
  }
  function l(t, e) {
    let i = !1;
    return {
      load(s) {
        if (!i) {
          i = !0;
          try {
            t && t(s);
          } catch (t) {
            e && e(t);
          }
        }
      },
      error(t) {
        i || ((i = !0), e && e(t));
      },
    };
  }
  function c(t) {
    switch (t) {
      case 0:
        return "FATAL";
      case 1:
        return "ERROR";
      case 2:
        return "WARN";
      case 3:
        return "INFO";
      case 4:
        return "DEBUG";
      case 5:
        return "TRACE";
      case 6:
        return "SILLY";
    }
  }
  class h {
    static generate() {
      try {
        return crypto.randomUUID();
      } catch (t) {
        return String(Math.random());
      }
    }
  }
  const d = "onetagActivity";
  class u {
    constructor(t) {
      this.target = t;
    }
    publish(t) {
      try {
        const e = void 0 === this.target ? window.top : this.target;
        if (null == e) return;
        void 0 === this.instance && (this.instance = h.generate());
        const i = Object.assign(Object.assign({}, t), {
          instance: this.instance,
          sequence: ++u.sequence,
          time: Date.now(),
        });
        e.postMessage(JSON.stringify({ [d]: i }), "*");
      } catch (t) {}
    }
  }
  u.sequence = 0;
  const g = u;
  var m = function (t, e) {
    var i = {};
    for (var s in t)
      Object.prototype.hasOwnProperty.call(t, s) &&
        e.indexOf(s) < 0 &&
        (i[s] = t[s]);
    if (null != t && "function" == typeof Object.getOwnPropertySymbols) {
      var n = 0;
      for (s = Object.getOwnPropertySymbols(t); n < s.length; n++)
        e.indexOf(s[n]) < 0 &&
          Object.prototype.propertyIsEnumerable.call(t, s[n]) &&
          (i[s[n]] = t[s[n]]);
    }
    return i;
  };
  class p {
    static getCallerStack(t, e) {
      try {
        if (t > 2) return;
        const i = new Error();
        if (!this.hasStack(i)) return;
        const s = i.stack;
        try {
          if (this.hasCaptureStackTrace(Error))
            return (
              Error.captureStackTrace(i, e),
              this.hasFrames(i.stack, i) ? i.stack : s
            );
          const t = s.split("\n");
          return t.length > this.OWN_FRAMES
            ? t.slice(this.OWN_FRAMES).join("\n")
            : s;
        } catch (t) {
          return s;
        }
      } catch (t) {
        return;
      }
    }
    static getMessage(t) {
      switch (typeof t) {
        case "string":
          return t;
        case "undefined":
          return;
        case "object":
          if (null === t) return;
          if (this.hasMessage(t)) return t.message;
          try {
            return JSON.stringify(t);
          } catch (e) {
            try {
              return String(t);
            } catch (t) {
              return;
            }
          }
        default:
          return String(t);
      }
    }
    static hasMessage(t) {
      return (
        null !== t &&
        "object" == typeof t &&
        "message" in t &&
        "string" == typeof t.message
      );
    }
    static hasStack(t) {
      return (
        null !== t &&
        "object" == typeof t &&
        "stack" in t &&
        "string" == typeof t.stack
      );
    }
    static hasName(t) {
      return (
        null !== t &&
        "object" == typeof t &&
        "name" in t &&
        "string" == typeof t.name
      );
    }
    static hasCode(t) {
      return (
        null !== t &&
        "object" == typeof t &&
        "code" in t &&
        "string" == typeof t.code
      );
    }
    static hasAttachments(t) {
      return (
        null !== t &&
        "object" == typeof t &&
        "getAttachments" in t &&
        "function" == typeof t.getAttachments
      );
    }
    static hasCaptureStackTrace(t) {
      return null != t && "function" == typeof t.captureStackTrace;
    }
    static hasFrames(t, e) {
      return t.split("\n").some((t) => "" !== t && t !== String(e));
    }
    static draw(t) {
      return t >= 1 || Math.random() < t;
    }
    constructor(t, e, i = new g()) {
      (this.environment = t),
        (this.client = e),
        (this.channel = i),
        (this.activationTimestamp = new Date().toISOString()),
        (this.attachments = []),
        (this.maxLogLevel =
          t.isProduction() && !t.hasConsoleTelemetry() ? 3 : 5);
    }
    attach(t) {
      return this.attachments.push(t), this;
    }
    integrate(t) {
      let e = !0;
      for (let i = 0; i < this.attachments.length; i++)
        this.attachments[i].type === t.type &&
          ((this.attachments[i] = Object.assign(
            Object.assign({}, this.attachments[i]),
            t
          )),
          (e = !1));
      return e && this.attach(t), this;
    }
    fork() {
      const t = new p(this.environment, this.client, this.channel);
      return (
        (t.maxLogLevel = this.maxLogLevel),
        (t.attachments = [...this.attachments]),
        t
      );
    }
    log(t, e, i) {
      this.logFrom(this.log, t, e, i);
    }
    error(t, e) {
      this.logFrom(this.error, t, 1, e);
    }
    fatal(t, e) {
      this.logFrom(this.fatal, t, 0, e);
    }
    debug(t, e) {
      this.logFrom(this.debug, t, 4, e);
    }
    warn(t, e) {
      this.logFrom(this.warn, t, 2, e);
    }
    info(t, e) {
      this.logFrom(this.info, t, 3, e);
    }
    trace(t, e) {
      this.logFrom(this.trace, t, 5, e);
    }
    silly(t, e) {
      this.logFrom(this.silly, t, 6, e);
    }
    event(t, e) {
      this.publishActivity(() => ({ type: "event", id: t, name: e }));
    }
    logFrom(t, e, i, s) {
      try {
        i <= 2 &&
          this.publishActivity(() => ({
            type: "log",
            level: i,
            code: p.hasCode(e) ? e.code : void 0,
            name: p.hasName(e) ? e.name : void 0,
            message: p.getMessage(e) || void 0,
          }));
        const n = null == s || p.draw(s),
          r = n || i > 4 ? i : 4,
          o = n && null != s && s < 1 ? s : void 0,
          a = (!n && null != s) || void 0;
        if (r <= this.maxLogLevel)
          if (this.environment.sendsTelemetry())
            this.client.post(
              p.tslogURL,
              JSON.stringify(this.serialize(e, r, !1, o, a, t)),
              {}
            );
          else {
            const {
                message: i,
                name: s,
                code: n,
                levelName: l,
                stack: c,
                entries: h,
                timestamp: d,
              } = this.serialize(e, r, !0, o, a, t),
              u = ["color: #707070ff"];
            switch (r) {
              case 0:
                u.push("color: #a11eddff");
                break;
              case 1:
                u.push("color: #FF0000");
                break;
              case 2:
                u.push("color: #FF7F00");
                break;
              case 3:
                u.push("color: #FFD700");
                break;
              case 4:
                u.push("color: #1E90FF");
                break;
              case 5:
                u.push("color: #32CD32");
                break;
              case 6:
                u.push("color: #87CEFA");
            }
            u.push("color: #1B6EA3");
          }
      } catch (e) {}
    }
    publishActivity(t) {
      try {
        if (this.environment.sendsTelemetry()) return;
        const e = t(),
          i = this.lastAttachment("context"),
          s = this.lastAttachment("renderer");
        this.channel.publish(
          Object.assign(Object.assign({}, e), {
            artifact:
              "string" == typeof (null == i ? void 0 : i.artifactName)
                ? i.artifactName
                : void 0,
            version:
              "string" == typeof (null == s ? void 0 : s.version)
                ? s.version
                : void 0,
          })
        );
      } catch (t) {}
    }
    lastAttachment(t) {
      for (let e = this.attachments.length - 1; e >= 0; e--)
        if (this.attachments[e].type === t) return this.attachments[e];
    }
    serialize(t, e, i, s, n, r) {
      const o = p.getMessage(t),
        a = p.hasStack(t) ? t.stack : p.getCallerStack(e, r),
        l = p.hasName(t) ? t.name : void 0,
        h = p.hasCode(t) ? t.code : void 0;
      return {
        entries: this.attachments
          .concat(p.hasAttachments(t) ? t.getAttachments() : [])
          .reduce((t, e) => {
            var { type: i } = e,
              s = m(e, ["type"]);
            return (t[i] = Object.assign({}, s)), t;
          }, {}),
        message: i ? o : o ? o.substring(0, 500) : void 0,
        timestamp: i ? new Date().toLocaleString() : new Date().toISOString(),
        activationTimestamp: i
          ? new Date(this.activationTimestamp).toLocaleString()
          : this.activationTimestamp,
        level: e,
        levelName: c(e),
        stack: i ? a : a ? a.substring(0, 500) : void 0,
        name: l,
        code: h,
        sampleRate: s,
        sampledOut: n,
      };
    }
  }
  (p.OWN_FRAMES = 4), (p.tslogURL = "https://onetag-sys.com/tslog/");
  const f = p;
  class v {
    constructor() {
      this.events = {};
    }
    emit(t, ...e) {
      if (t in this.events)
        for (const { handler: i, context: s } of this.events[t].slice())
          null != s ? i.call(s, ...e) : i(...e);
    }
    on(t, e, i) {
      t in this.events || (this.events[t] = []),
        this.events[t].push({ handler: e, context: i });
    }
    off(t, e) {
      t in this.events &&
        (null != e &&
          (this.events[t] = this.events[t].filter((t) => t.handler !== e)),
        (null != e && 0 !== this.events[t].length) || delete this.events[t]);
    }
    once(t, e, i) {
      const s = (...n) => {
        this.off(t, s), null != i ? e.call(i, ...n) : e(...n);
      };
      this.on(t, s);
    }
    next(t) {
      return new Promise((e) => {
        this.once(t, (...t) => {
          0 === t.length ? e(void 0) : e(t);
        });
      });
    }
    handlerCount(t) {
      var e, i;
      return null !==
        (i =
          null === (e = this.events[t]) || void 0 === e ? void 0 : e.length) &&
        void 0 !== i
        ? i
        : 0;
    }
    clear() {
      for (const t in this.events) this.off(t);
    }
  }
  class w extends n {
    constructor(t, e) {
      super("OMID sessionError"),
        (this.containerMessage = e),
        (this.code = "omid-session-error"),
        (this.errorType = String(t).toLowerCase());
    }
    isVideo() {
      return "video" === this.errorType;
    }
    getAttachments() {
      return [
        {
          type: "omid",
          errorType: this.errorType,
          sessionError: this.containerMessage,
        },
      ];
    }
  }
  class y {
    constructor() {
      (this.shouldTriggerOneTagPixel = !0), (this.canBeFiredMultipleTimes = !0);
    }
    get name() {
      return Object.getPrototypeOf(this).constructor.name.replace(/Event$/, "");
    }
  }
  class b extends y {
    constructor() {
      super(...arguments), (this.id = 783), (this.canBeFiredMultipleTimes = !1);
    }
  }
  class I extends y {
    constructor() {
      super(...arguments), (this.id = 785), (this.canBeFiredMultipleTimes = !1);
    }
  }
  class T extends y {
    constructor() {
      super(...arguments), (this.id = 786), (this.canBeFiredMultipleTimes = !1);
    }
  }
  class E extends y {
    constructor() {
      super(...arguments), (this.id = 784), (this.canBeFiredMultipleTimes = !1);
    }
  }
  class F extends y {
    constructor() {
      super(...arguments), (this.id = 802), (this.canBeFiredMultipleTimes = !1);
    }
  }
  var O = function (t, e, i, s) {
    return new (i || (i = Promise))(function (n, r) {
      function o(t) {
        try {
          l(s.next(t));
        } catch (t) {
          r(t);
        }
      }
      function a(t) {
        try {
          l(s.throw(t));
        } catch (t) {
          r(t);
        }
      }
      function l(t) {
        var e;
        t.done
          ? n(t.value)
          : ((e = t.value),
            e instanceof i
              ? e
              : new i(function (t) {
                  t(e);
                })).then(o, a);
      }
      l((s = s.apply(t, e || [])).next());
    });
  };
  class x {
    constructor(
      t = document,
      e = window,
      i = "https://onetag-cdn.com/res/omid-verification-client-v1.js"
    ) {
      (this.doc = t), (this.win = e), (this.scriptUrl = i);
    }
    load() {
      return O(this, void 0, void 0, function* () {
        yield this.loadScript();
        const t = this.resolveCtor();
        return t ? new t() : void 0;
      });
    }
    loadScript() {
      return new Promise((t, e) => {
        const i = this.doc.createElement("script");
        (i.src = this.scriptUrl),
          (i.onload = () => t()),
          (i.onerror = () =>
            e(new Error("Failed to load OMID verification client script"))),
          this.doc.head.appendChild(i);
      });
    }
    resolveCtor() {
      const t = this.win.OmidVerificationClient;
      if (!t) return;
      const e = Object.keys(t);
      return e.length > 0 ? t[e[0]] : void 0;
    }
  }
  class S {
    constructor(t, e, i = 50) {
      (this.onFired = e),
        (this.minPercentageInView = i),
        (this.timerId = null),
        (this.fired = !1),
        (this.durationMs = t);
    }
    setDuration(t) {
      this.durationMs = t;
    }
    update(t) {
      this.fired ||
        (t >= this.minPercentageInView
          ? null === this.timerId &&
            (this.timerId = setTimeout(() => {
              (this.fired = !0), (this.timerId = null), this.onFired();
            }, this.durationMs))
          : null !== this.timerId &&
            (clearTimeout(this.timerId), (this.timerId = null)));
    }
    stop() {
      null !== this.timerId &&
        (clearTimeout(this.timerId), (this.timerId = null));
    }
  }
  var M = function (t, e, i, s) {
    return new (i || (i = Promise))(function (n, r) {
      function o(t) {
        try {
          l(s.next(t));
        } catch (t) {
          r(t);
        }
      }
      function a(t) {
        try {
          l(s.throw(t));
        } catch (t) {
          r(t);
        }
      }
      function l(t) {
        var e;
        t.done
          ? n(t.value)
          : ((e = t.value),
            e instanceof i
              ? e
              : new i(function (t) {
                  t(e);
                })).then(o, a);
      }
      l((s = s.apply(t, e || [])).next());
    });
  };
  class A {
    constructor(t, e, i = []) {
      (this.pingUrl = t),
        (this.logger = e),
        (this.thirdPartyEventPixels = i),
        (this.firedEvents = new Set());
    }
    setThirdPartyPixels(t = []) {
      this.thirdPartyEventPixels = t;
    }
    hasFired(t) {
      return this.firedEvents.has(t.id);
    }
    fire(t) {
      let e = Promise.resolve();
      if (!t.canBeFiredMultipleTimes && this.hasFired(t))
        this.logger.warn(
          `Event ${t.id} has already been fired and cannot be called multiple times.`
        );
      else {
        this.logger.trace(`Fire ad event ${t.name} (${t.id})`),
          this.logger.event(t.id, t.name),
          t.shouldTriggerOneTagPixel && (e = this.callOneTagPixel(t));
        const i = this.thirdPartyEventPixels.filter(
          ({ eventId: e }) => e === t.id
        );
        for (const { method: t, pixel: e } of i) {
          switch (t) {
            case 1:
              new Image().src = e;
              break;
            case 2:
              const i = document.createElement("script");
              (i.async = !0), (i.src = e), document.body.appendChild(i);
              break;
            default:
              this.logger.error(
                new Error(`Invalid third party pixel method ${t}`)
              );
          }
          this.logger.silly(
            `Called third party pixel ${e} (method: ${
              1 === t ? "<img>" : "<script>"
            })`
          );
        }
        this.firedEvents.add(t.id);
      }
      return e;
    }
    callOneTagPixel(t) {
      return new Promise((e) => {
        const i = new Image(),
          s = () => {
            window.clearTimeout(n), (i.onload = null), (i.onerror = null), e();
          },
          n = window.setTimeout(() => {
            this.logger.trace(
              `OneTag pixel of event ${t.id} did not answer within 1000 ms`
            ),
              s();
          }, 1e3);
        (i.onload = s),
          (i.onerror = s),
          (i.src = this.pingUrl.replace("ONETAG_EVENT_ID", String(t.id)));
      });
    }
  }
  const D = s.getCurrent(),
    L = new f(
      new (class {
        constructor(t, e, s, n) {
          (this.nodeEnv =
            null != t ? i(t) || "production" : i("production") || "production"),
            (this.testType =
              null != e
                ? !1 === e
                  ? null
                  : (function (t) {
                      switch (t) {
                        case "e2e":
                          return "e2e";
                        case "unit":
                          return "unit";
                      }
                    })(e) || null
                : null),
            (this.telemetrySink =
              (null != s &&
                (function (t) {
                  switch (t) {
                    case "remote":
                      return "remote";
                    case "console":
                      return "console";
                  }
                })(s)) ||
              "remote"),
            (this.artifactHost =
              (null != n &&
                (function (t) {
                  switch (t) {
                    case "cdn":
                      return "cdn";
                    case "self":
                      return "self";
                  }
                })(n)) ||
              "cdn");
        }
        isProduction() {
          return "production" === this.nodeEnv;
        }
        isDevelopment() {
          return "development" === this.nodeEnv;
        }
        isE2ETest() {
          return "e2e" === this.testType;
        }
        isUnitTest() {
          return "unit" === this.testType;
        }
        isTest() {
          return this.isE2ETest() || this.isUnitTest();
        }
        hasConsoleTelemetry() {
          return "console" === this.telemetrySink;
        }
        sendsTelemetry() {
          return (
            this.isProduction() && !this.isTest() && !this.hasConsoleTelemetry()
          );
        }
        hasSelfHostedArtifacts() {
          return "self" === this.artifactHost;
        }
      })(),
      new o()
    ).attach(
      Object.assign(
        { type: "context", artifactName: "VastOmidVerificationScript" },
        D.toJSON()
      )
    ),
    P = new (class extends v {
      constructor(t, e = new x(), i = !1) {
        super(),
          (this.loader = e),
          (this.adEventManager = null),
          (this.viewabilityTracker = null),
          (this.sessionStarted = !1),
          (this.mediaType = null),
          (this.measurableImpressionFired = !1),
          (this.lastPercentageInView = 0),
          (this.logger = t
            .fork()
            .integrate({ type: "renderer", context: "OmidHandler" })),
          (this.logFailure = i
            ? (t) => this.logger.fatal(t)
            : (t) => this.logger.warn(t)),
          (this.logUnsupportedEnvironment = i
            ? (t) => this.logger.fatal(t)
            : (t) => this.logger.debug(t));
      }
      integrateLogContext(t, e) {
        return (
          this.logger.integrate(t),
          null != e && (this.logger.maxLogLevel = e),
          this
        );
      }
      start(t) {
        return M(this, void 0, void 0, function* () {
          let e;
          try {
            e = yield this.loader.load();
          } catch (t) {
            return void this.logger.warn(
              new Error(`Failed to load OMID verification client: ${t.message}`)
            );
          }
          if (e)
            if (e.isSupported())
              try {
                e.registerSessionObserver((e) => {
                  switch (e.type) {
                    case "sessionStart":
                      this.onSessionStart(e, t);
                      break;
                    case "sessionError":
                      this.onSessionError(e);
                      break;
                    case "sessionFinish":
                      this.onSessionFinish();
                  }
                }, "onetag.com-omid"),
                  e.addEventListener("impression", () => {
                    var t;
                    null === (t = this.adEventManager) ||
                      void 0 === t ||
                      t.fire(new I()),
                      this.onImpression(),
                      this.emit("billableOmidImpression");
                  }),
                  e.addEventListener("geometryChange", (t) => {
                    var e, i, s, n;
                    (this.lastPercentageInView =
                      null !==
                        (s =
                          null ===
                            (i =
                              null === (e = t.data) || void 0 === e
                                ? void 0
                                : e.adView) || void 0 === i
                            ? void 0
                            : i.percentageInView) && void 0 !== s
                        ? s
                        : 0),
                      null === (n = this.viewabilityTracker) ||
                        void 0 === n ||
                        n.update(this.lastPercentageInView);
                  }),
                  this.logger.trace("OMID Handler started successfully");
              } catch (t) {
                this.logger.fatal(
                  `Failed to initialize OMID handler: ${t.message}`
                );
              }
            else
              this.logUnsupportedEnvironment(
                new Error(
                  "OMID verification client reports unsupported environment"
                )
              );
          else
            this.logFailure(
              new Error(
                "OMID verification client script loaded but no constructor found on window.OmidVerificationClient"
              )
            );
        });
      }
      onSessionStart(t, e) {
        var i;
        this.sessionStarted ||
          ((this.sessionStarted = !0),
          (this.mediaType = t.data.mediaType),
          this.logger.integrate({
            type: "context",
            omidEnvironment: t.data.context.environment,
            appId:
              null === (i = t.data.context.app) || void 0 === i
                ? void 0
                : i.appId,
          }),
          (this.adEventManager = e(t)),
          this.adEventManager &&
            ("video" !== this.mediaType && this.startViewabilityTracking(1e3),
            this.adEventManager.fire(new b())));
      }
      onImpression() {
        "video" === this.mediaType &&
          !this.measurableImpressionFired &&
          this.adEventManager &&
          ((this.measurableImpressionFired = !0),
          this.adEventManager.fire(new F()),
          this.startViewabilityTracking(2e3));
      }
      startViewabilityTracking(t) {
        (this.viewabilityTracker = new S(t, () => {
          this.adEventManager.fire(new T());
        })),
          this.viewabilityTracker.update(this.lastPercentageInView);
      }
      onSessionError(t) {
        const { errorType: e, message: i } = t.data,
          s = new w(e, i);
        s.isVideo() ? this.logger.debug(s) : this.logger.warn(s);
      }
      onSessionFinish() {
        var t;
        this.logger.trace("OMID sessionFinish received"),
          null === (t = this.adEventManager) || void 0 === t || t.fire(new E());
      }
    })(L, new x(), !0);
  P.start((i) => {
    var s, n;
    L.integrate({
      type: "context",
      omidEnvironment: i.data.context.environment,
      appId:
        null === (s = i.data.context.app) || void 0 === s ? void 0 : s.appId,
    });
    const r = i.data.verificationParameters;
    if (!r)
      return (
        L.fatal(new Error("OMID sessionStart missing verificationParameters")),
        null
      );
    try {
      const i = JSON.parse(r),
        s = new e({
          debugInfo: i.debugInfo,
          impressionId: i.impressionId,
          bidUUID: i.bidUUID,
        }),
        o = new t(
          null === (n = i.debugInfo) || void 0 === n ? void 0 : n.version,
          i.isPreprod,
          i.maxLogLevel
        ),
        a = Object.assign(
          Object.assign({ type: "renderer" }, s.toJSON()),
          o.toJSON()
        ),
        l = o.getMaxLogLevel();
      return (
        (L.maxLogLevel = null != l ? l : L.maxLogLevel),
        L.integrate({ type: "context", app: i.app }),
        L.integrate(a),
        P.integrateLogContext(a, l),
        i.pingUrl && "string" == typeof i.pingUrl
          ? new A(i.pingUrl, L)
          : (L.fatal(
              new Error(
                `verificationParameters missing or invalid pingUrl: ${i.pingUrl}`
              )
            ),
            null)
      );
    } catch (t) {
      return (
        L.fatal(
          new Error(`Failed to parse verificationParameters: ${t.message}`)
        ),
        null
      );
    }
  });
})();
