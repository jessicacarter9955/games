!(function () {
  try {
    var e =
        "undefined" != typeof window
          ? window
          : "undefined" != typeof global
          ? global
          : "undefined" != typeof globalThis
          ? globalThis
          : "undefined" != typeof self
          ? self
          : {},
      n = new e.Error().stack;
    n &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[n] = "ff11306a-af6f-5734-aa33-fbd14b3fdc6d"));
  } catch (e) {}
})();
(function () {
  try {
    var e =
      typeof window < `u`
        ? window
        : typeof global < `u`
        ? global
        : typeof globalThis < `u`
        ? globalThis
        : typeof self < `u`
        ? self
        : {};
    (e._sentryModuleMetadata = e._sentryModuleMetadata || {}),
      (e._sentryModuleMetadata[new e.Error().stack] = (function (e) {
        for (var t = 1; t < arguments.length; t++) {
          var n = arguments[t];
          if (n != null) for (var r in n) n.hasOwnProperty(r) && (e[r] = n[r]);
        }
        return e;
      })({}, e._sentryModuleMetadata[new e.Error().stack], {
        "_sentryBundlerPluginAppKey:crazygames-gameframe": !0,
      }));
    var t = new e.Error().stack;
    t &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[t] = `a8f0df67-d165-41dc-b43a-8caed2e5cd4f`),
      (e._sentryDebugIdIdentifier = `sentry-dbid-a8f0df67-d165-41dc-b43a-8caed2e5cd4f`));
  } catch {}
})();
import { Sn as e, cn as t, gn as n, pt as r, yn as i } from "../../bundle.js";
var a = t(),
  o = e(i()),
  s = n(),
  c = o.memo((e) => {
    let t = (0, a.c)(10),
      { name: n, width: i, height: o, className: c, style: l, alt: u } = e,
      d = u === void 0 ? `` : u,
      f;
    t[0] === n ? (f = t[1]) : ((f = r(n)), (t[0] = n), (t[1] = f));
    let p = d ? void 0 : !0,
      m;
    return (
      t[2] !== d ||
      t[3] !== c ||
      t[4] !== o ||
      t[5] !== l ||
      t[6] !== f ||
      t[7] !== p ||
      t[8] !== i
        ? ((m = (0, s.jsx)(`img`, {
            src: f,
            width: i,
            height: o,
            className: c,
            style: l,
            alt: d,
            "aria-hidden": p,
          })),
          (t[2] = d),
          (t[3] = c),
          (t[4] = o),
          (t[5] = l),
          (t[6] = f),
          (t[7] = p),
          (t[8] = i),
          (t[9] = m))
        : (m = t[9]),
      m
    );
  });
c.displayName = `IllustrationIcon`;
export { c as t };
//# debugId=ff11306a-af6f-5734-aa33-fbd14b3fdc6d
