!(function () {
  try {
    var e =
        "undefined" != typeof window
          ? window
          : "undefined" != typeof global
          ? global
          : "undefined" != typeof globalThis
          ? globalThis
          : "undefined" != typeof self
          ? self
          : {},
      n = new e.Error().stack;
    n &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[n] = "a8c7c412-b2d1-51e4-9961-b543bd59f2aa"));
  } catch (e) {}
})();
(function () {
  try {
    var e =
      typeof window < `u`
        ? window
        : typeof global < `u`
        ? global
        : typeof globalThis < `u`
        ? globalThis
        : typeof self < `u`
        ? self
        : {};
    (e._sentryModuleMetadata = e._sentryModuleMetadata || {}),
      (e._sentryModuleMetadata[new e.Error().stack] = (function (e) {
        for (var t = 1; t < arguments.length; t++) {
          var n = arguments[t];
          if (n != null) for (var r in n) n.hasOwnProperty(r) && (e[r] = n[r]);
        }
        return e;
      })({}, e._sentryModuleMetadata[new e.Error().stack], {
        "_sentryBundlerPluginAppKey:crazygames-gameframe": !0,
      }));
    var t = new e.Error().stack;
    t &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[t] = `12d90384-208a-4190-963a-d6ecb1a2166a`),
      (e._sentryDebugIdIdentifier = `sentry-dbid-12d90384-208a-4190-963a-d6ecb1a2166a`));
  } catch {}
})();
import {
  Gt as e,
  Jt as t,
  Sn as n,
  Wt as r,
  at as i,
  cn as a,
  ct as o,
  gn as s,
  it as c,
  nt as l,
  on as u,
  yn as d,
} from "../../bundle.js";
import { t as f } from "./DesdDbnn.js";
import { t as p } from "./DQIVArhv.js";
var m = n(d()),
  h = a(),
  g = {
    content: `_content_1ehu6_7`,
    icon: `_icon_1ehu6_13`,
    title: `_title_1ehu6_17`,
    body: `_body_1ehu6_22`,
    button: `_button_1ehu6_30`,
  },
  _ = s(),
  v = () => {
    let n = (0, h.c)(6),
      [r, a] = m.useState(!1),
      s,
      d;
    if (
      (n[0] === Symbol.for(`react.memo_cache_sentinel`)
        ? ((s = () => {
            let n = function (n) {
              bb3: switch (n.data.type) {
                case `unityCrashModalOpen`:
                  a(!0);
                  break bb3;
                case `unityCrashError`: {
                  let { error: r, errorMessage: i, origin: a } = n.data;
                  t
                    .getInstance()
                    .sendEvent({
                      type: `unityCrash`,
                      error: r,
                      errorMessage: i,
                      origin: a,
                    }),
                    t
                      .getInstance()
                      .sendEvent({
                        type: `gameError`,
                        slug: u().gameSlug,
                        errorName: r,
                        errorMessage: i,
                        pageVisitId: e(),
                        context: `unityCrash_${a}`,
                      });
                }
              }
            };
            return (
              window.addEventListener(`message`, n),
              () => {
                window.removeEventListener(`message`, n);
              }
            );
          }),
          (d = []),
          (n[0] = s),
          (n[1] = d))
        : ((s = n[0]), (d = n[1])),
      m.useEffect(s, d),
      !r)
    )
      return null;
    let f;
    n[2] === Symbol.for(`react.memo_cache_sentinel`)
      ? ((f = (0, _.jsx)(p, {
          name: `ziggy-error`,
          width: 93,
          height: 107,
          className: g.icon,
        })),
        (n[2] = f))
      : (f = n[2]);
    let v;
    n[3] === Symbol.for(`react.memo_cache_sentinel`)
      ? ((v = (0, _.jsx)(`h2`, {
          className: g.title,
          children: (0, _.jsx)(c, { id: `error.unity.crashed.title` }),
        })),
        (n[3] = v))
      : (v = n[3]);
    let b;
    n[4] === Symbol.for(`react.memo_cache_sentinel`)
      ? ((b = (0, _.jsx)(`p`, {
          className: g.body,
          children: (0, _.jsx)(c, { id: `error.unity.crashed.text` }),
        })),
        (n[4] = b))
      : (b = n[4]);
    let x;
    return (
      n[5] === Symbol.for(`react.memo_cache_sentinel`)
        ? ((x = (0, _.jsx)(i, {
            hideBackdrop: !0,
            children: (0, _.jsxs)(o, {
              className: g.content,
              children: [
                f,
                v,
                b,
                (0, _.jsx)(l, {
                  variant: `contained`,
                  color: `purple`,
                  className: g.button,
                  height: 45,
                  onClick: y,
                  children: (0, _.jsx)(c, { id: `error.unity.crashed.button` }),
                }),
              ],
            }),
          })),
          (n[5] = x))
        : (x = n[5]),
      x
    );
  };
function y() {
  return r.refreshGamePage();
}
var b = class extends f {
  trackProgress(e) {
    let t = super.trackProgress(e);
    return Math.min(t + 0.1, 1);
  }
};
export { v as n, b as t };
//# debugId=a8c7c412-b2d1-51e4-9961-b543bd59f2aa
