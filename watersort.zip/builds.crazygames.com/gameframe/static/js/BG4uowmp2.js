!(function () {
  try {
    var e =
        "undefined" != typeof window
          ? window
          : "undefined" != typeof global
          ? global
          : "undefined" != typeof globalThis
          ? globalThis
          : "undefined" != typeof self
          ? self
          : {},
      n = new e.Error().stack;
    n &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[n] = "108e274d-9ee4-5080-a750-874d775faf24"));
  } catch (e) {}
})();
(function () {
  try {
    var e =
      typeof window < `u`
        ? window
        : typeof global < `u`
        ? global
        : typeof globalThis < `u`
        ? globalThis
        : typeof self < `u`
        ? self
        : {};
    (e._sentryModuleMetadata = e._sentryModuleMetadata || {}),
      (e._sentryModuleMetadata[new e.Error().stack] = (function (e) {
        for (var t = 1; t < arguments.length; t++) {
          var n = arguments[t];
          if (n != null) for (var r in n) n.hasOwnProperty(r) && (e[r] = n[r]);
        }
        return e;
      })({}, e._sentryModuleMetadata[new e.Error().stack], {
        "_sentryBundlerPluginAppKey:crazygames-gameframe": !0,
      }));
    var t = new e.Error().stack;
    t &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[t] = `20a4f45b-1671-4396-82ad-93bac0be7818`),
      (e._sentryDebugIdIdentifier = `sentry-dbid-20a4f45b-1671-4396-82ad-93bac0be7818`));
  } catch {}
})();
import {
  $t as e,
  At as t,
  Bt as n,
  E as r,
  It as i,
  Jt as a,
  Pt as o,
  Sn as s,
  T as c,
  Vt as l,
  Xt as u,
  Zt as d,
  a as f,
  an as ee,
  cn as p,
  et as te,
  fn as m,
  gn as h,
  jt as g,
  nn as _,
  on as v,
  s as y,
  tn as b,
  yn as x,
} from "../../bundle.js";
import { t as S } from "./ByF0oZf9.js";
import { i as C, r as w, t as ne } from "./EOi5FIVR.js";
import { n as re, t as ie } from "./sazSNRXa2.js";
var T = s(x()),
  ae = p(),
  E = new y(`unity2020ready`),
  D = [
    `out of memory`,
    `out of executable memory`,
    `could not allocate`,
    `abort("oom")`,
    `aborted(oom)`,
    `abortoncannotgrowmemory`,
    `cannot enlarge memory arrays`,
    `invalid array buffer length`,
    `invalid typed array length`,
    `array buffer allocation failed`,
    `does not support webgl`,
    `does not support graphics api`,
    `does not support webassembly`,
  ];
function oe(e) {
  let t = e.toLowerCase();
  return D.some((e) => t.includes(e));
}
var O = h(),
  k = () => {
    let s = (0, ae.c)(24),
      { isGameDisabled: p } = (0, T.useContext)(t),
      { isIos: h } = (0, T.useContext)(te),
      { onLoadFinished: y } = (0, T.useContext)(g),
      { isFullscreen: x } = (0, T.useContext)(c),
      [D, k] = (0, T.useState)(0),
      [M, N] = (0, T.useState)(`loading`),
      [P, F] = (0, T.useState)(null),
      I = T.useRef(null),
      L = T.useRef(null);
    if (L.current === null) {
      let e;
      s[0] === Symbol.for(`react.memo_cache_sentinel`)
        ? ((e = new ie()), (s[0] = e))
        : (e = s[0]),
        (L.current = e);
    }
    let R;
    s[1] === Symbol.for(`react.memo_cache_sentinel`)
      ? ((R = v()), (s[1] = R))
      : (R = s[1]);
    let z = R,
      B = z.loaderOptions,
      V;
    s[2] === Symbol.for(`react.memo_cache_sentinel`)
      ? ((V = f()), (s[2] = V))
      : (V = s[2]);
    let H = V,
      U,
      W;
    s[3] === p
      ? ((U = s[4]), (W = s[5]))
      : ((U = () => {
          if (p) {
            I.current &&= (I.current.remove(), null);
            return;
          }
          let e = ne(H);
          (I.current = e), o(A), ee().appendChild(e);
        }),
        (W = [H, p]),
        (s[3] = p),
        (s[4] = U),
        (s[5] = W)),
      (0, T.useEffect)(U, W);
    let G, K;
    s[6] === h
      ? ((G = s[7]), (K = s[8]))
      : ((G = () => {
          let t = v().loaderOptions,
            { unityConfigOptions: r, unitySaveFileNames: a } = t,
            o = {
              ...r,
              companyName: `CrazyGames`,
              productName: e(),
              productVersion: `1.0`,
            };
          d() && (o.devicePixelRatio = u());
          let s = { gameLink: v().gameLink, userInfo: _() };
          E.sendMessage({
            type: `unity2020config`,
            loaderOptions: t,
            unityConfig: o,
            unitySaveFileNames: a,
            oldSdkInitObject: s,
            isIos: h,
            isOfflineGaming: l(),
          });
          let c = async () => {
              if (!w()) {
                m.error(`Unity WebGL is not available on this browser`),
                  C(`unity-unavailable`),
                  N(`error`);
                return;
              }
              L.current.trackLoadStarted(),
                await i.Instance.waitForAPS(),
                E.sendMessage({ type: `loadGame` });
            },
            f = j;
          return (
            c(),
            n().addAdFinishedListener(f),
            () => {
              n().removeAdFinishedListener(f);
            }
          );
        }),
        (K = [h]),
        (s[6] = h),
        (s[7] = G),
        (s[8] = K)),
      (0, T.useEffect)(G, K);
    let q, J;
    s[9] !== x || s[10] !== y || s[11] !== M
      ? ((q = () => {
          let e = function (e) {
            bb22: switch (e.data.type) {
              case `loadProgress`:
              case `loadprogress`:
                if (M !== `loading`) return;
                k(L.current.trackProgress(e.data.progress)),
                  e.data.progress === 1 &&
                    (L.current.trackLoadFinished(),
                    z.fullscreen === `REQUIRED` && !b() && !x
                      ? N(`fullscreen`)
                      : (N(`loaded`), y()));
                break bb22;
              case `syncUnityData`:
                i.Instance.autoSyncUnityData();
                break bb22;
              case `unityMemoryUsage`:
                a.getInstance().sendEvent(e.data.usageData);
                break bb22;
              case `unityError`:
                F(e.data), N(`error`), C(`unity-game-load-failed`, e.data);
            }
          };
          return (
            window.addEventListener(`message`, e),
            () => {
              window.removeEventListener(`message`, e);
            }
          );
        }),
        (J = [M, y, z, x]),
        (s[9] = x),
        (s[10] = y),
        (s[11] = M),
        (s[12] = q),
        (s[13] = J))
      : ((q = s[12]), (J = s[13])),
      (0, T.useEffect)(q, J);
    let Y;
    s[14] === y
      ? (Y = s[15])
      : ((Y = async () => {
          N(`loaded`), y();
        }),
        (s[14] = y),
        (s[15] = Y));
    let X = Y,
      Z;
    s[16] !== P || s[17] !== X || s[18] !== D || s[19] !== M
      ? ((Z = (() => {
          switch (M) {
            case `loading`:
              return (0, O.jsx)(r, {
                progress: D,
                showProgress: B.showProgress,
              });
            case `error`:
              return (0, O.jsx)(S, {
                warning:
                  P && !oe(P.errorMessage)
                    ? `unity-load-failed`
                    : `unity-unavailable`,
              });
            case `fullscreen`:
              return (0, O.jsx)(S, { warning: `force-fullscreen`, close: X });
            default:
              return null;
          }
        })()),
        (s[16] = P),
        (s[17] = X),
        (s[18] = D),
        (s[19] = M),
        (s[20] = Z))
      : (Z = s[20]);
    let Q;
    s[21] === Symbol.for(`react.memo_cache_sentinel`)
      ? ((Q = (0, O.jsx)(re, {})), (s[21] = Q))
      : (Q = s[21]);
    let $;
    return (
      s[22] === Z
        ? ($ = s[23])
        : (($ = (0, O.jsxs)(O.Fragment, { children: [Z, Q] })),
          (s[22] = Z),
          (s[23] = $)),
      $
    );
  };
function A() {
  E.sendMessage({ type: `focusGame` });
}
function j() {
  E.sendMessage({ type: `focusGame` });
}
export { k as default };
//# debugId=108e274d-9ee4-5080-a750-874d775faf24
