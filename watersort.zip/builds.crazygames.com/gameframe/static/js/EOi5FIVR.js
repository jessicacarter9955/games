!(function () {
  try {
    var e =
        "undefined" != typeof window
          ? window
          : "undefined" != typeof global
          ? global
          : "undefined" != typeof globalThis
          ? globalThis
          : "undefined" != typeof self
          ? self
          : {},
      n = new e.Error().stack;
    n &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[n] = "30352c89-e5c3-5727-a150-44e86a90ad4f"));
  } catch (e) {}
})();
(function () {
  try {
    var e =
      typeof window < `u`
        ? window
        : typeof global < `u`
        ? global
        : typeof globalThis < `u`
        ? globalThis
        : typeof self < `u`
        ? self
        : {};
    (e._sentryModuleMetadata = e._sentryModuleMetadata || {}),
      (e._sentryModuleMetadata[new e.Error().stack] = (function (e) {
        for (var t = 1; t < arguments.length; t++) {
          var n = arguments[t];
          if (n != null) for (var r in n) n.hasOwnProperty(r) && (e[r] = n[r]);
        }
        return e;
      })({}, e._sentryModuleMetadata[new e.Error().stack], {
        "_sentryBundlerPluginAppKey:crazygames-gameframe": !0,
      }));
    var t = new e.Error().stack;
    t &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[t] = `e8f12e04-b66d-4134-9b1a-1d061a9a180e`),
      (e._sentryDebugIdIdentifier = `sentry-dbid-e8f12e04-b66d-4134-9b1a-1d061a9a180e`));
  } catch {}
})();
import {
  Dt as e,
  Gt as t,
  Jt as n,
  Ot as r,
  en as i,
  on as a,
} from "../../bundle.js";
function o() {
  if (i()) return !1;
  try {
    let e = document.createElement(`canvas`);
    return `WebGLRenderingContext` in window && !!e.getContext(`webgl2`);
  } catch {
    return !1;
  }
}
function s() {
  if (i()) return !1;
  try {
    let e = document.createElement(`canvas`);
    return (
      `WebGLRenderingContext` in window &&
      (!!e.getContext(`webgl`) || !!e.getContext(`experimental-webgl`))
    );
  } catch {
    return !1;
  }
}
function c(t) {
  let n = document.createElement(`iframe`);
  return (
    (n.id = `game-iframe`),
    (n.src = t),
    (n.style.border = `0`),
    (n.style.backgroundColor = `#fff`),
    (n.style.width = `10px`),
    (n.style.height = `10px`),
    (n.style.minWidth = `100%`),
    (n.style.minHeight = `100%`),
    n.setAttribute(`allow`, r({ src: t, extra: [`gamepad`] })),
    n.setAttribute(`webkitallowfullscreen`, `true`),
    n.setAttribute(`mozallowfullscreen`, `true`),
    n.setAttribute(`msallowfullscreen`, `true`),
    n.setAttribute(`allowfullscreen`, `true`),
    n.setAttribute(`sandbox`, ``),
    n.sandbox.add(...e),
    n
  );
}
function l(e, r) {
  n.getInstance().sendEvent({
    type: `gameError`,
    slug: a().gameSlug,
    errorName: e,
    errorMessage: r?.errorMessage || `webGL check failed`,
    pageVisitId: t(),
    context: r?.phase || `unity-unavailable-webgl`,
  });
}
export { l as i, o as n, s as r, c as t };
//# debugId=30352c89-e5c3-5727-a150-44e86a90ad4f
