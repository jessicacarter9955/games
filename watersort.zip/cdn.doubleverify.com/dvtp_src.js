/*! v11365 3b834c84 */
var __webpack_exports__ = {},
  $dv,
  dvWindow;
(function () {
  const n = "data-injection-id",
    t = "scriptInjectionMode";
  function r() {
    return (
      ("object" == typeof omidVerificationProperties &&
        omidVerificationProperties.injectionId) ||
      null
    );
  }
  const e = r();
  function o() {
    try {
      return new Date().getTime();
    } catch (n) {
      return 0;
    }
  }
  var c = o(),
    i = {
      InjectTagError: { id: 1, message: "InjectTagError" },
      LoadTagError: { id: 2, message: "LoadTagError" },
      UnexpectedError: { id: 128, message: "UnexpectedError" },
      SecondaryScriptUnavailableError: {
        id: 262144,
        message: "SecondaryScriptUnavailableError",
      },
    },
    u = { None: 0, FoundInStack: 1, CurrentScriptNull: 2, StrictMode: 4 },
    a = function () {},
    d = D(),
    f =
      "undefined" == typeof window ||
      "function" != typeof window.addEventListener,
    v = (function () {
      var n, t;
      if (!f) {
        try {
          J((n = G("about:blank"))), (t = !K(n));
        } catch (n) {
          t = !0;
        }
        try {
          n && ("function" == typeof n.remove && n.remove(), (n = null));
        } catch {}
      }
      return t;
    })(),
    p = -1,
    m = (function () {
      try {
        if (f) return !1;
        if (
          "object" == typeof omidVerificationProperties &&
          "web" === omidVerificationProperties.injectionSource
        )
          return !0;
        for (var n = !1, t = window; !1 === n && t; )
          (n = null !== t.document.querySelector("script[src*=omweb-v1]")),
            (t = t === window.top ? null : t.parent),
            p++;
        return n;
      } catch (n) {
        return !1;
      }
    })(),
    s = -1,
    w = (function () {
      try {
        if (f || m) return !1;
        var n = !1,
          t = window;
        for (; !1 === n && t; )
          (n =
            (r = t.omid3p) &&
            "function" == typeof r.registerSessionObserver &&
            "function" == typeof r.addEventListener),
            (t = t === window.top ? null : t.parent),
            s++;
        return n;
      } catch (n) {
        return !1;
      }
      var r;
    })(),
    l = !(f || !document.currentScript),
    y = void 0 === this,
    _ = (function () {
      try {
        if (!f && document) {
          let n = document.currentScript;
          return (n.dvvisit = 1), n;
        }
      } catch {}
    })();
  function g(n) {
    const t = new URL(n),
      { hostname: r } = t;
    return r;
  }
  function R(n) {
    return (
      n &&
      [
        "*cdn*.doubleverify.com",
        "*cdn*.dv.tech",
        "localhost",
        "127.0.0.1",
      ].some((t) => E(t, n))
    );
  }
  function h(n) {
    return n.indexOf("/dvtp_src.js") > -1;
  }
  function E(n, t) {
    const r = n.replace(/[.+^${}()|[\]\\]/g, "\\$&");
    return new RegExp(
      `^${r.replace(/\*/g, ".*").replace(/\?/g, ".")}$`,
      "i"
    ).test(t);
  }
  var I = !f && k(),
    j = !f && !I,
    U = j && F(),
    L = j && !l && !U && H(),
    b = 11365,
    C = I
      ? I.substr(0, I.indexOf("/dvtp_src.js") + 1)
      : "https://cdn.doubleverify.com/",
    S = "https://tps.doubleverify.com/",
    $ = "visit.jpg",
    x = {
      loadScript: function n(t, r, e) {
        (r = r || a),
          (e = e || a),
          "object" == typeof omidNative &&
            ("function" == typeof omidNative.downloadJavaScriptResource
              ? omidNative.downloadJavaScriptResource(
                  t,
                  function n(t) {
                    try {
                      (dvWindow = q($dv, fn)), eval(t), r();
                    } catch (n) {
                      var o = (void 0 !== t && t && t.length) || 0;
                      e("OnEvalError_ResLen_" + o);
                    }
                  },
                  function () {
                    e("OnFailedToDownload");
                  }
                )
              : e("DownloadJavaScriptResourceNotExist"));
      },
      fire: function (n, t, r) {
        (t = t || a),
          (r = r || a),
          "object" == typeof omidNative &&
            "function" == typeof omidNative.sendUrl &&
            omidNative.sendUrl(n, t, r);
      },
    },
    T = {
      loadScript: function (n, t, r) {
        dvWindow = window;
        const e = W();
        return v || (w && !1) || m || e ? X(n, t, r, e) : Y(n);
      },
      fire: function (n, t, r) {
        var e = new Image(1, 1);
        (e.onerror = r || a), (e.onload = t || a), (e.src = n);
      },
    },
    M = f ? x : T,
    N,
    P;
  function O() {
    for (var n = 1, t = Math.floor(10 * Math.random()) + 1, r = 0; r < t; ++r)
      n *= Math.random();
    return n;
  }
  function D() {
    return (o() * O()).toString(10);
  }
  function A() {
    return _ && _.src;
  }
  function V() {
    return l && document.currentScript.src;
  }
  function k() {
    return V() || A();
  }
  function F() {
    try {
      for (
        var n = new RegExp(
            "(https?://[^\\s()]+/dvtp_src\\.js(?:[?#]\\S*?)?)(?::\\d+){1,2}\\)?$"
          ),
          t = new Error().stack,
          r = "string" == typeof t ? t.split("\n") : [],
          e = 0;
        e < r.length;
        e++
      ) {
        var o = n.exec(r[e].trim());
        if (o && R(g(o[1]))) return o[1];
      }
    } catch {}
  }
  function H() {
    try {
      var n = /https?:\/\/[^\s/()]+\/[^\s?#():]*/.exec(new Error().stack);
      return n && n[0].substring(0, 200);
    } catch {}
  }
  function Q() {
    try {
      var n = window.location.ancestorOrigins;
      if (n) return n.length ? n[n.length - 1] : window.location.origin;
    } catch {}
  }
  function W() {
    return f
      ? e
      : ("object" == typeof document &&
          document.currentScript &&
          "function" == typeof document.currentScript.getAttribute &&
          document.currentScript.getAttribute(n)) ||
          null;
  }
  function q(n, t) {
    var r = { location: { protocol: "https:" } },
      e = {
        getElementById: a,
        createElement: a,
        body: { insertBefore: a },
        querySelectorAll: function () {
          return [];
        },
      };
    return (
      (r.$dv = n),
      (r.$frmId = t),
      (r.parent = r),
      (r.top = r),
      (r.document = e),
      r
    );
  }
  function B(n, t) {
    const r = [t, en(), W()].map((n) => `"${n}"`).join(",");
    var e = K(n),
      o =
        '<html><head><script type="text/javascript">(' +
        function () {
          (window.$dv = window.parent.$dv),
            (window.$dv.isFrameSupported = !0),
            (window.$frmId =
              Math.random().toString(36) + Math.random().toString(36));
        }.toString() +
        ')();</script></head><body><script type="text/javascript">(' +
        function n(t, r, e) {
          var o;
          function c(n) {
            new Image(1, 1).src = n;
          }
          function i() {
            "function" == typeof window.clearTimeout &&
              RetrayLoader.timerRef &&
              window.clearTimeout(RetrayLoader.timerRef);
          }
          window.RetrayLoader ||
            (window.RetrayLoader = {
              MAX_NUM_OF_TRIES: 3,
              TIMEOUT: 400,
              numOfTries: 1,
              timerRef: null,
            }),
            t &&
              (((o = document.createElement("script")).src = t),
              (o.onload = function () {
                (window.isDVMLoaded = !0), i();
              }),
              e && o.setAttribute && o.setAttribute("data-injection-id", e),
              (o.onerror = function () {
                window.isDVMLoaded ||
                  (o &&
                    "function" == typeof o.remove &&
                    (o.remove(), (o = null)),
                  "function" == typeof window.setTimeout &&
                  RetrayLoader.MAX_NUM_OF_TRIES !== RetrayLoader.numOfTries
                    ? (++RetrayLoader.numOfTries,
                      i(),
                      (RetrayLoader.timerRef = window.setTimeout(function () {
                        n(t, r, e);
                      }, RetrayLoader.TIMEOUT)))
                    : "function" == typeof fetch
                    ? fetch(t)
                        .then(function (n) {
                          n.status >= 500
                            ? c(
                                r
                                  .replace(/cerrt=\d+/, "cerrt=262144")
                                  .replace(
                                    /napr=[^&]*/,
                                    "napr=" +
                                      encodeURIComponent(
                                        "LoadTagError__SecondaryScriptUnavailable__5xx"
                                      )
                                  )
                              )
                            : c(r);
                        })
                        .catch(function () {
                          c(r);
                        })
                    : c(r));
              }),
              document.body.appendChild(o));
        }.toString() +
        `)(${r});<\/script></body></html>`;
    if (e) e.open(), e.write(o), e.close();
    else {
      var c = encodeURIComponent(
        o.replace(/'/g, "\\'").replace(/\n|\r\n|\r/g, "")
      );
      n.src =
        'javascript: (function(){document.open();document.domain="' +
        window.document.domain +
        "\";document.write('" +
        c +
        "');})()";
    }
  }
  function G(n) {
    var t = Math.floor(1e12 * (Math.random() + "")),
      r = document.createElement("iframe");
    return (
      (r.name = r.id = "iframe_" + t),
      r.setAttribute("data-dv-frm", t),
      (r.width = "0"),
      (r.height = "0"),
      (r.style.display = "none"),
      (r.src = n),
      r
    );
  }
  function J(n) {
    if (document.currentScript) {
      var t = document.currentScript.parentNode;
      t && "function" == typeof t.insertBefore
        ? t.insertBefore(n, document.currentScript)
        : document.currentScript.appendChild(n);
    } else if (document.body && "function" == typeof document.body.insertBefore)
      document.body.firstChild
        ? document.body.insertBefore(n, document.body.firstChild)
        : document.body.appendChild(n);
    else {
      var r = document.getElementsByTagName("head")[0];
      r && "function" == typeof document.body.insertBefore && r.firstChild
        ? r.insertBefore(n, r.firstChild)
        : document.documentElement.appendChild(n);
    }
  }
  function K(n) {
    return (
      n &&
      (n.contentDocument ||
        (n.contentWindow && n.contentWindow.document) ||
        (frames && frames[n.name] && frames[n.name].document))
    );
  }
  function X(r, e, o, c) {
    var i = document.createElement("script");
    (i.onload = e || a),
      (i.onerror = o || a),
      (i.src = r),
      (i.type = "application/javascript"),
      !f && c && i.setAttribute(n, c),
      J(i);
    cn().tagData[d][t] = "injectedAsSibling";
  }
  function Y(n) {
    var r = G("about:blank");
    J(r), B(r, n);
    cn().tagData[d][t] = "injectedInIframe";
  }
  var z = S + $ + "?";
  function Z(n, t, r) {
    var e = (n && n.message) || "error undefined",
      o = [
        z,
        "ctx=818052&cmp=1619415&dvtagver=6.1.src",
        "&napr=",
        encodeURIComponent(e),
        "&cerrt=",
        t,
        "&tgjsver=",
        b,
        "&jsver=",
        b,
        "&flvr=",
        "0",
      ];
    r && o.push("&dvp_isLostImp=1");
    var c = 0;
    return (
      f && (c |= 4), v && (c |= 8), c > 0 && o.push("&tstype=" + c), o.join("")
    );
  }
  function nn(n, t, r) {
    var e = Z(n, t, r);
    M && M.fire(e);
  }
  try {
    (P = (function (n) {
      var t,
        r,
        e,
        o = {},
        c = {};
      return (
        (t = n) &&
          ((r = (function (n) {
            var t = n.indexOf("#"),
              r = n.indexOf("?"),
              e = "";
            e = t > -1 && r > -1 ? (r < t ? "?" : "#") : -1 == r ? "#" : "?";
            var o = "",
              c = n.trim().split(e);
            return 2 === c.length && (o = c[1]), o;
          })(t)),
          r &&
            ((e = {}),
            r.split(/[&?#]+/).forEach(function (n) {
              2 === (n = n.trim().split("=")).length &&
                (e[n[0].trim()] = n[1].trim());
            }),
            (c = (function (n) {
              var t = {};
              function r(r) {
                return function (e) {
                  n.hasOwnProperty(e) && (t[r + e] = n[e]);
                };
              }
              return (
                ["gdpr", "gdpr_consent"].forEach(r("dvp_")),
                ["ctx", "cmp", "sid", "plc"].forEach(r("ee_dp_")),
                t
              );
            })((o = e))))),
        {
          toQueryString: function (n) {
            var t,
              r = "";
            for (t in n)
              n.hasOwnProperty(t) &&
                (r && (r += "&"), (r = [r, t, "=", n[t]].join("")));
            return r;
          },
          getQueryStringParams: function () {
            return o;
          },
          getQueryStringClientParams: function () {
            return c;
          },
        }
      );
    })(I || U)),
      (N = (function () {
        var n,
          t = "",
          r = "__ERR_MSG_PLACEHOLDER__",
          e = "__CLIENT_ERROR_TYPE_PLACEHOLDER__",
          o = "__ERR_TRACE_PLACEHOLDER__",
          c = {
            ctx: 818052,
            cmp: 1619415,
            dvtagver: "6.1.src",
            tgjsver: b,
            jsver: b,
            napr: r,
            cerrt: e,
            flvr: "0",
            ee_dp_dvtptrace: o,
          },
          i = 0;
        if ((f && (i |= 4), v && (i |= 8), i > 0 && (c.tstype = i), j)) {
          c.ee_dp_dvtpurlrec =
            (U ? u.FoundInStack : u.None) |
            (l ? u.None : u.CurrentScriptNull) |
            (y ? u.StrictMode : u.None);
          var a = P.getQueryStringParams().turl;
          a && (c.ee_dp_turl = a.substring(0, 1e3).replace(/%[0-9a-f]?$/i, ""));
          var d = Q();
          d && (c.ee_dp_dvtptop = encodeURIComponent(d));
        }
        function p(n) {
          return n && n.trim().replace(/(\t|\n|\r|\|)/g, "");
        }
        function m(n, c, i) {
          c = ((c = c && p(c)) && encodeURIComponent(c)) || "";
          let u = n.trace && p(n.trace);
          u = (u && encodeURIComponent(u)) || "";
          var a = t.replace(new RegExp(r, "g"), [n.message, c].join("__"));
          return (
            (a = (a = a.replace(new RegExp(e, "g"), n.id)).replace(
              new RegExp(o, "g"),
              u
            )),
            i && (a += "&dvp_isLostImp=1"),
            a
          );
        }
        return (
          L && (c.ee_dp_dvtpcaller = encodeURIComponent(L)),
          (n = [
            P.toQueryString(c),
            P.toQueryString(P.getQueryStringClientParams()),
          ].join("&")),
          (t = [z, n].join("")),
          {
            report: function (n, t, r) {
              M.fire(m(n, t, r));
            },
            getReportUrl: m,
          }
        );
      })());
  } catch (n) {
    nn(n, i.UnexpectedError.id, !1);
  }
  function tn(n, t) {
    for (var r = 5; n[t] && --r; ) t = D();
    if (n[t]) throw new Error("failed to create tagUniqueKey");
    return t;
  }
  function rn(n, t, r, e, i, u) {
    (n.tagData = n.tagData || {}), (t = tn(n.tagData, t));
    var a = {};
    (a.dvtpScriptVersion = r),
      (a.dvtpScriptUrl = e),
      (a.restrictedAccess = i),
      (a.$frmId = u),
      (a.tagScriptElem = _),
      (a.tagLoadedMS = c),
      (a.isOmidForWeb = m),
      (a.isOmid3p = w),
      (a.omidWebHopCounter = p),
      (a.omid3pHopCounter = s),
      (a.tagExecTimeMs = o() - c),
      (a.flvr = "0"),
      (a.authorizedDomain = un(f, e)),
      (a.omidInjectionId = W()),
      f || (a.tagReadyState = document.readyState),
      (a.staticPrefix = C),
      (a.serverPrefix = S),
      (n.tagData[t] = a);
  }
  function en(n) {
    n = n || "NotFound";
    var t = i.LoadTagError;
    t.trace =
      "TagUrl=" +
      encodeURIComponent(I) +
      ";DvmUrl=" +
      encodeURIComponent(vn) +
      ";CurrentUrl=" +
      encodeURIComponent(document.location.href);
    var r = "failedToLoadDVM__" + n;
    return N
      ? N.getReportUrl(t, r, !0)
      : Z(new Error(t.message + "__" + r), t.id, !0);
  }
  function on(n) {
    var t = en(n);
    vn && "function" == typeof fetch
      ? fetch(vn)
          .then(function (n) {
            if (n.status >= 500) {
              var r = t
                .replace(
                  /cerrt=\d+/,
                  "cerrt=" + i.SecondaryScriptUnavailableError.id
                )
                .replace(
                  /napr=[^&]*/,
                  "napr=" +
                    encodeURIComponent(
                      i.SecondaryScriptUnavailableError.message + "__5xx"
                    )
                );
              M.fire(r);
            } else M.fire(t);
          })
          .catch(function () {
            M.fire(t);
          })
      : M.fire(t);
  }
  function cn() {
    return ($dv = (void 0 !== $dv && $dv) || { tags: {}, tagsCounter: 0 });
  }
  function un(n, t) {
    return n || an(t);
  }
  function an(n) {
    return R(g(n));
  }
  try {
    var dn = f || h(I);
    if (!dn) throw new Error("Invalid tag URL");
    $dv = cn();
    var fn = D();
    f || (window.$frmId = fn),
      $dv.tagsCounter++,
      ($dv.isDomlessEnvironment = f),
      ($dv.sharedUniqueKey = $dv.sharedUniqueKey || D()),
      ($dv.restrictedAccess = v),
      (z = S + $ + "?");
    var vn = [C, "dv-measurements11365", ".js"].join("");
    rn($dv, d, b, I, v, fn), M.loadScript(vn, a, on);
  } catch (n) {
    var pn = i.InjectTagError;
    N ? N.report(pn, n.message, !0) : nn(n, pn.id, !0);
  }
})();
