!(function () {
  "use strict";
  let d = document,
    u = window;
  if (void 0 === d || void 0 === u) return;
  var e = d.currentScript || d.getElementById("sa-ad-context-script");
  if (!e) return;
  let h = u.setTimeout || setTimeout,
    c = u.setInterval || setInterval,
    p = u.clearTimeout || clearTimeout,
    g = u.clearInterval || clearInterval,
    v = () => {
      var e = u.performance;
      return (e && "function" == typeof e.now ? e : Date).now();
    },
    m = v(),
    a = "sa-content-div-pSdBShew0A",
    n = 0.5,
    i = 0.3,
    r = 242500,
    s = 1e3,
    f = 6,
    o = 7,
    b = 5e3,
    y = 100,
    l = 32,
    w = 1024,
    k = -1;
  let O = 12e5;
  class I {
    constructor() {
      (this.iframeWidth = null),
        (this.iframeHeight = null),
        (this.visible = null),
        (this.topFrames = null);
    }
    hasDifferences(e) {
      var t;
      return (
        !(e && e instanceof I) ||
        (t = (e, t) =>
          !(
            (null === e && null === t) ||
            (null !== e && null !== t && e === t)
          ))(this.iframeWidth, e.iframeWidth) ||
        t(this.iframeHeight, e.iframeHeight)
      );
    }
    toParams() {
      var e = {};
      return (
        null !== this.iframeWidth && (e.w = Math.round(this.iframeWidth)),
        null !== this.iframeHeight && (e.h = Math.round(this.iframeHeight)),
        null !== this.visible && (e.vis = this.visible),
        this.topFrames && (e.tf = this.topFrames),
        e
      );
    }
  }
  let P = (e, t) => {
      var n = Object.keys(t);
      for (let i = 0; i < n.length; i++) e[n[i]] = t[n[i]];
      return e;
    },
    B = (e) => {
      var t = { fc: T() };
      try {
        u.$sf && u.$sf.ext && (t.sf = 1);
      } catch (e) {}
      try {
        u.navigator && u.navigator.webdriver && (t.wd = 1);
      } catch (e) {}
      var n = e.getScreenSize(),
        n =
          ((t.sw = Math.round(n.screenWidth)),
          (t.sh = Math.round(n.screenHeight)),
          e.getOrigins());
      return (
        (t.to = n.top),
        null !== n.depth && (t.od = n.depth),
        (t.oc = n.chain),
        "" !== n.bottom && (t.bo = n.bottom),
        t
      );
    };
  let E = new (class {
    constructor(e) {
      (this.purl = e.getAttribute("purl")),
        (this.auctionID = e.getAttribute("aid")),
        (this.impID = e.getAttribute("iid")),
        (this.networkID = e.getAttribute("nid")),
        (this.campaignID = e.getAttribute("cid")),
        (this.advertiserID = e.getAttribute("advid")),
        (this.nativeAdID = e.getAttribute("naid")),
        (this.brDomain = e.getAttribute("br_domain")),
        (this.expectedHeight = e.getAttribute("eh")),
        (this.expectedWidth = e.getAttribute("ew")),
        (this.adElement = null),
        (this.cleanupFns = []),
        (this.currentData = new I());
    }
    getPixelURL() {
      return (
        this.purl +
        "/adcontext/display?aid=" +
        encodeURIComponent(this.auctionID) +
        "&iid=" +
        encodeURIComponent(this.impID) +
        "&nid=" +
        this.networkID +
        "&cid=" +
        this.campaignID +
        "&advid=" +
        this.advertiserID +
        "&naid=" +
        this.nativeAdID +
        "&br_domain=" +
        encodeURIComponent(this.brDomain) +
        "&eh=" +
        this.expectedHeight +
        "&ew=" +
        this.expectedWidth
      );
    }
    getLogErrorPixelURL() {
      return (
        this.purl +
        "/log-error/display?aid=" +
        encodeURIComponent(this.auctionID) +
        "&iid=" +
        encodeURIComponent(this.impID) +
        "&nid=" +
        this.networkID +
        "&cid=" +
        this.campaignID +
        "&advid=" +
        this.advertiserID +
        "&naid=" +
        this.nativeAdID +
        "&br_domain=" +
        encodeURIComponent(this.brDomain) +
        "&eh=" +
        this.expectedHeight +
        "&ew=" +
        this.expectedWidth
      );
    }
    cleanup() {
      var e = this.cleanupFns;
      (this.cleanupFns = []),
        e.forEach((e) => {
          try {
            e();
          } catch (e) {}
        });
    }
  })(e);
  if (!E.purl) return;
  let z = (e = d) => e.createElement("img"),
    D = (t, n) => {
      var i = () => {
        try {
          t.img_requests || (t.img_requests = []);
          var e = z(t.document);
          (e.src = n), t.img_requests.push(e);
        } catch (e) {}
      };
      if (t.fetch)
        try {
          t.fetch(n, { keepalive: !0, method: "get", mode: "no-cors" }).catch(
            i
          );
        } catch (e) {
          i();
        }
      else i();
    },
    _ = 3,
    t = 0,
    L = (e) => {
      t >= _ || (t++, D(u, E.getLogErrorPixelURL() + e));
    },
    F = (e) =>
      function () {
        try {
          return e.apply(this, arguments);
        } catch (e) {
          E.cleanup(), L("&msg=" + encodeURIComponent(e.toString()));
        }
      };
  let S = ((r) => {
      let a = {},
        s = null,
        o = !1,
        l = () => {
          s && (p(s), (s = null));
          var e = a;
          a = {};
          let t;
          try {
            t = ((e) => {
              let t = "";
              var n = Object.keys(e);
              for (let a = 0; a < n.length; a++) {
                var i = n[a],
                  r = e[i];
                if (null != r)
                  if (Array.isArray(r))
                    for (let e = 0; e < r.length; e++)
                      t += "&" + i + "=" + encodeURIComponent(r[e]);
                  else t += "&" + i + "=" + encodeURIComponent(r);
              }
              return t;
            })(e);
          } catch (e) {
            return void L("&msg=" + encodeURIComponent(e.toString()));
          }
          t && D(u, E.getPixelURL() + t);
        };
      return {
        flush: l,
        report(e, t) {
          var n = Object.keys(e);
          for (let i = 0; i < n.length; i++) a[n[i]] = e[n[i]];
          t || o ? l() : (s = s || h(F(l), r));
        },
        beginUnload() {
          o = !0;
        },
      };
    })(
      (() => {
        try {
          var e = u.navigator || {},
            t = e.userAgent || "";
          return /iphone|ipad|ipod/i.test(t)
            ? !0
            : /macintosh/i.test(t) && 1 < e.maxTouchPoints;
        } catch (e) {
          return !1;
        }
      })()
        ? 1e3
        : 3e3
    ),
    U =
      (E.cleanupFns.push(() => S.flush()),
      F(() => {
        d.hidden && S.flush();
      }));
  try {
    d.addEventListener("visibilitychange", U),
      E.cleanupFns.push(() => d.removeEventListener("visibilitychange", U));
  } catch (e) {}
  let T = () => {
      try {
        if (u.top === u) return 1;
      } catch (e) {
        return 3;
      }
      return C() ? 2 : 3;
    },
    j = () => {
      try {
        return u.top.length || 0;
      } catch (e) {
        return 0;
      }
    },
    x = (e, t) => (e * t >= r ? i : n),
    C = () => {
      try {
        var e = u.top && u.top.document;
        if (e && "function" == typeof e.hasFocus) return e;
      } catch (e) {}
      return null;
    },
    R = (t) => {
      let n = null,
        i = !1;
      return {
        setInView(e) {
          i ||
            (e
              ? (n =
                  n ||
                  h(() => {
                    (n = null), i || ((i = !0), t());
                  }, s))
              : n && (p(n), (n = null)));
        },
        cancel() {
          n && (p(n), (n = null));
        },
      };
    },
    A = (c) => ({
      name: "web",
      init(e) {
        e();
      },
      getDimensions() {
        var e = d.documentElement,
          t = d.body;
        return {
          iframeWidth:
            u.innerWidth || (e && e.clientWidth) || (t && t.clientWidth) || 0,
          iframeHeight:
            u.innerHeight ||
            (e && e.clientHeight) ||
            (t && t.clientHeight) ||
            0,
        };
      },
      getScreenSize() {
        var e = u.screen || {};
        return { screenWidth: e.width || 0, screenHeight: e.height || 0 };
      },
      getOrigins() {
        var t = { top: "none", depth: k, chain: [], bottom: "" };
        let e;
        try {
          e = u.location.ancestorOrigins;
        } catch (e) {
          return t;
        }
        if (!e || "number" != typeof e.length) return t;
        if (0 === e.length)
          return { top: "none", depth: 0, chain: [], bottom: "" };
        var n = [];
        let i = 0;
        for (let a = e.length - 1; 0 <= a && n.length < l; a--) {
          var r = String(e[a]);
          if (i + r.length > w) break;
          n.push(r), (i += r.length);
        }
        return {
          top: e[e.length - 1],
          depth: e.length,
          chain: n,
          bottom: e[0],
        };
      },
      getVisible() {
        return d.hidden ? "0" : "1";
      },
      setUpViewability() {
        if (!c) return null;
        if (!("IntersectionObserver" in u)) return null;
        let e,
          t = R(() => {
            S.report({ view: 1, ttv: Math.round(v() - m) }, !0);
            try {
              e.disconnect();
            } catch (e) {}
          });
        var n = c.getBoundingClientRect();
        let i = x(n.width, n.height),
          r = C(),
          a = !1,
          s = () => t.setInView(a && !d.hidden && (!r || r.hasFocus())),
          o = !1;
        try {
          (e = new IntersectionObserver(
            (e) => {
              e.forEach((e) => {
                var t;
                o ||
                  ((t = { viewi: e.intersectionRatio.toFixed(4) }),
                  e.rootBounds &&
                    ((t.vw = Math.round(e.rootBounds.width)),
                    (t.vh = Math.round(e.rootBounds.height))),
                  S.report(t),
                  (o = !0)),
                  (a = e.intersectionRatio >= i);
              }),
                s();
            },
            { threshold: i }
          )).observe(c);
        } catch (e) {
          return t.cancel(), null;
        }
        let l = F(s),
          h = F(s);
        try {
          d.addEventListener("visibilitychange", l),
            r &&
              (u.top.addEventListener("focus", h),
              u.top.addEventListener("blur", h));
        } catch (e) {}
        return [
          () => t.cancel(),
          () => e.disconnect(),
          () => d.removeEventListener("visibilitychange", l),
          () => {
            r &&
              (u.top.removeEventListener("focus", h),
              u.top.removeEventListener("blur", h));
          },
        ];
      },
    }),
    q = (a) => {
      let o = (e, t, ...n) => {
          try {
            var i,
              r = a[e];
            return "function" != typeof r
              ? t
              : void 0 === (i = r.apply(a, n))
              ? t
              : i;
          } catch (e) {
            return t;
          }
        },
        l = (e, t) => {
          try {
            return (
              a.addEventListener(e, t),
              E.cleanupFns.push(() => o("removeEventListener", null, e, t)),
              !0
            );
          } catch (e) {
            return !1;
          }
        };
      var e = o("getVersion", "") || "";
      let s = 3 <= parseInt(e, 10);
      return {
        name: "mraid",
        init(r, a) {
          let s = (e, t) => {
              try {
                L(
                  "&code=" +
                    f +
                    "&msg=" +
                    encodeURIComponent("mraid: " + (e || ""))
                );
              } catch (e) {}
            },
            e =
              (l("error", s),
              () => {
                var e = o("getState", null);
                return (e && "loading" !== e) || !0 === o("isViewable", !1);
              });
          if (e()) r();
          else {
            let t = !1,
              n = null,
              i = (e) => {
                t || ((t = !0), n && g(n), (e && a ? a : r)());
              };
            if (
              ((n = c(
                F(() => {
                  e() && i(!1);
                }),
                y
              )),
              E.cleanupFns.push(() => {
                n && g(n);
              }),
              l("ready", () => i(!1)))
            )
              if (
                (l("stateChange", (e) => {
                  e && "loading" !== e && i(!1);
                }),
                e())
              )
                i(!1);
              else {
                let e = h(() => {
                  t || (s("SDK did not fire ready within " + b + "ms"), i(!0));
                }, b);
                E.cleanupFns.push(() => p(e));
              }
            else i(!0);
          }
        },
        getDimensions() {
          let e = o("getCurrentPosition", null);
          return {
            iframeWidth:
              ((e =
                e &&
                -1 !== e.width &&
                -1 !== e.height &&
                (0 !== e.width || 0 !== e.height)
                  ? e
                  : o("getMaxSize", null)) &&
                e.width) ||
              0,
            iframeHeight: (e && e.height) || 0,
          };
        },
        getScreenSize() {
          var e = o("getScreenSize", null) || {};
          return { screenWidth: e.width || 0, screenHeight: e.height || 0 };
        },
        getOrigins() {
          let e = "in-app";
          var t;
          return {
            top: (e = s && (t = o("getAppId", null)) ? t : e),
            depth: null,
            chain: [],
            bottom: "",
          };
        },
        getVisible() {
          return o("isViewable", !1) ? "1" : "0";
        },
        setUpViewability() {
          var e = o("getCurrentPosition", null) || {},
            t = o("getMaxSize", null) || {},
            n = o("isViewable", !1) ? 1 : 0;
          S.report({
            viewi: n.toFixed(4),
            vw: Math.round(t.width || e.width || 0),
            vh: Math.round(t.height || e.height || 0),
          });
          let i = R(() => S.report({ view: 1, ttv: Math.round(v() - m) }, !0)),
            r = x(e.width || t.width || 0, e.height || t.height || 0);
          return (
            s
              ? l(
                  "exposureChange",
                  F((e) => {
                    i.setInView(e >= 100 * r);
                  })
                ) ||
                l(
                  "viewableChange",
                  F((e) => {
                    i.setInView(!!e);
                  })
                )
              : l(
                  "viewableChange",
                  F((e) => {
                    i.setInView(!!e);
                  })
                ),
            i.setInView(1 === n),
            [() => i.cancel()]
          );
        },
      };
    },
    $ = (e) =>
      u.mraid && "function" == typeof u.mraid.getState ? q(u.mraid) : A(e),
    H = F((e) => {
      var t = E.adElement;
      t &&
        ((t = t.getBoundingClientRect()),
        S.report(
          {
            clkx: Math.round(e.clientX - t.left),
            clky: Math.round(e.clientY - t.top),
          },
          !0
        ));
    }),
    M = (t, n, i) => {
      let r = E.adElement;
      if (r) {
        let e = F(() => S.report({ [n]: Math.round(v() - i) }));
        try {
          r.addEventListener(t, e, { once: !0, passive: !0 }),
            E.cleanupFns.push(() => r.removeEventListener(t, e));
        } catch (e) {}
      }
    },
    K = () => {
      let e = E.adElement;
      if (e)
        try {
          e.addEventListener("click", H, { once: !0 }),
            E.cleanupFns.push(() => e.removeEventListener("click", H));
        } catch (e) {}
    },
    N = (i) => {
      let t = E.adElement,
        r = !1,
        n = (e, t) => {
          var n;
          r ||
            ((r = !0),
            (n = { ttu: Math.round(v() - i), ttus: e }),
            t && (n.ttup = 1),
            S.report(n, !0));
        };
      var e = (t) =>
        F((e) => {
          S.beginUnload(), t(e), S.flush();
        });
      let a = e((e) => n("ph", e && e.persisted ? 1 : 0)),
        s = e(() => n("bu", 0)),
        o = e(() => n("ul", 0));
      try {
        u.addEventListener("pagehide", a),
          u.addEventListener("beforeunload", s),
          u.addEventListener("unload", o),
          E.cleanupFns.push(() => {
            u.removeEventListener("pagehide", a),
              u.removeEventListener("beforeunload", s),
              u.removeEventListener("unload", o);
          });
      } catch (e) {}
      if (t && "MutationObserver" in u)
        try {
          var l = t.parentNode || d.body || d.documentElement || d;
          let e = new MutationObserver(
            F(() => {
              if (!d.contains(t)) {
                n("mo", 0);
                try {
                  e.disconnect();
                } catch (e) {}
              }
            })
          );
          e.observe(l, { childList: !0, subtree: !0 }),
            E.cleanupFns.push(() => {
              try {
                e.disconnect();
              } catch (e) {}
            });
        } catch (e) {}
    },
    W = () => {
      (E.adElement = d.getElementById(a)),
        E.adElement ||
          L(
            "&code=" + o + "&msg=" + encodeURIComponent("ad element not found")
          );
      let n = $(E.adElement),
        e =
          (K(),
          M("mouseover", "tth", m),
          M("touchstart", "ttt", m),
          N(m),
          h(
            F(() => E.cleanup()),
            O
          )),
        i = (E.cleanupFns.push(() => p(e)), {}),
        r = () => {
          var e = new I(),
            t = n.getDimensions();
          (e.iframeWidth = t.iframeWidth),
            (e.iframeHeight = t.iframeHeight),
            (e.visible = n.getVisible()),
            (e.topFrames = j()),
            e.hasDifferences(E.currentData) &&
              ((E.currentData = e),
              ((t = P(e.toParams(), i)).env = n.name),
              S.report(t));
        },
        t = () => {
          n.init(
            F(() => {
              (i = B(n)), r();
              let e = c(F(r), 1e3);
              E.cleanupFns.push(() => g(e));
              var t = n.setUpViewability() || [];
              E.cleanupFns.push(...t);
            }),
            F(() => {
              (n = A(E.adElement)), t();
            })
          );
        };
      t();
    },
    V = () => {
      "complete" === d.readyState
        ? h(F(W), 100)
        : u.addEventListener("load", () => h(F(W), 100));
    };
  if (d.prerendering)
    d.addEventListener(
      "prerenderingchange",
      F(() => {
        (m = v()), V();
      }),
      { once: !0 }
    );
  else if ("prerender" === d.visibilityState) {
    let e = F(() => {
      "prerender" !== d.visibilityState &&
        (d.removeEventListener("visibilitychange", e), (m = v()), V());
    });
    d.addEventListener("visibilitychange", e);
  } else V();
})();
