(() => {
  var e = {
    620(e, t, n) {
      var r = 1 / 0,
        i = 9007199254740991,
        s = 17976931348623157e292,
        a = NaN,
        o = "[object Arguments]",
        u = "[object Map]",
        d = "[object Promise]",
        c = "[object Set]",
        l = "[object String]",
        h = "[object Symbol]",
        f = "[object WeakMap]",
        g = "[object DataView]",
        p = /^\s+|\s+$/g,
        b = /^[-+]0x[0-9a-f]+$/i,
        y = /^0b[01]+$/i,
        v = /^\[object .+?Constructor\]$/,
        m = /^0o[0-7]+$/i,
        I = /^(?:0|[1-9]\d*)$/,
        w = "\\ud800-\\udfff",
        E = "\\u0300-\\u036f\\ufe20-\\ufe23",
        S = "\\u20d0-\\u20f0",
        k = "\\ufe0e\\ufe0f",
        A = "[" + w + "]",
        T = "[" + E + S + "]",
        L = "\\ud83c[\\udffb-\\udfff]",
        C = "[^" + w + "]",
        D = "(?:\\ud83c[\\udde6-\\uddff]){2}",
        z = "[\\ud800-\\udbff][\\udc00-\\udfff]",
        _ = "\\u200d",
        q = "(?:" + T + "|" + L + ")" + "?",
        j = "[" + k + "]?",
        O =
          j +
          q +
          ("(?:" + _ + "(?:" + [C, D, z].join("|") + ")" + j + q + ")*"),
        B = "(?:" + [C + T + "?", T, D, z, A].join("|") + ")",
        x = RegExp(L + "(?=" + L + ")|" + B + O, "g"),
        P = RegExp("[" + _ + w + E + S + k + "]"),
        M = parseInt,
        R = "object" == typeof n.g && n.g && n.g.Object === Object && n.g,
        N = "object" == typeof self && self && self.Object === Object && self,
        $ = R || N || Function("return this")();
      function F(e, t) {
        return (function (e, t) {
          for (var n = -1, r = e ? e.length : 0, i = Array(r); ++n < r; )
            i[n] = t(e[n], n, e);
          return i;
        })(t, function (t) {
          return e[t];
        });
      }
      function V(e) {
        var t = -1,
          n = Array(e.size);
        return (
          e.forEach(function (e, r) {
            n[++t] = [r, e];
          }),
          n
        );
      }
      function K(e) {
        var t = -1,
          n = Array(e.size);
        return (
          e.forEach(function (e) {
            n[++t] = e;
          }),
          n
        );
      }
      function G(e) {
        return (function (e) {
          return P.test(e);
        })(e)
          ? (function (e) {
              return e.match(x) || [];
            })(e)
          : (function (e) {
              return e.split("");
            })(e);
      }
      var U,
        Y,
        Z,
        Q = Function.prototype,
        W = Object.prototype,
        H = $["__core-js_shared__"],
        J = (U = /[^.]+$/.exec((H && H.keys && H.keys.IE_PROTO) || ""))
          ? "Symbol(src)_1." + U
          : "",
        X = Q.toString,
        ee = W.hasOwnProperty,
        te = W.toString,
        ne = RegExp(
          "^" +
            X.call(ee)
              .replace(/[\\^$.*+?()[\]{}|]/g, "\\$&")
              .replace(
                /hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g,
                "$1.*?"
              ) +
            "$"
        ),
        re = $.Symbol,
        ie = re ? re.iterator : void 0,
        se = W.propertyIsEnumerable,
        ae = Math.floor,
        oe =
          ((Y = Object.keys),
          (Z = Object),
          function (e) {
            return Y(Z(e));
          }),
        ue = Math.random,
        de = Se($, "DataView"),
        ce = Se($, "Map"),
        le = Se($, "Promise"),
        he = Se($, "Set"),
        fe = Se($, "WeakMap"),
        ge = Te(de),
        pe = Te(ce),
        be = Te(le),
        ye = Te(he),
        ve = Te(fe);
      function me(e, t) {
        var n =
            Ce(e) ||
            (function (e) {
              return (
                (function (e) {
                  return qe(e) && De(e);
                })(e) &&
                ee.call(e, "callee") &&
                (!se.call(e, "callee") || te.call(e) == o)
              );
            })(e)
              ? (function (e, t) {
                  for (var n = -1, r = Array(e); ++n < e; ) r[n] = t(n);
                  return r;
                })(e.length, String)
              : [],
          r = n.length,
          i = !!r;
        for (var s in e)
          (!t && !ee.call(e, s)) ||
            (i && ("length" == s || Ae(s, r))) ||
            n.push(s);
        return n;
      }
      function Ie(e) {
        if (
          !_e(e) ||
          (function (e) {
            return !!J && J in e;
          })(e)
        )
          return !1;
        var t =
          ze(e) ||
          (function (e) {
            var t = !1;
            if (null != e && "function" != typeof e.toString)
              try {
                t = !!(e + "");
              } catch (e) {}
            return t;
          })(e)
            ? ne
            : v;
        return t.test(Te(e));
      }
      function we(e) {
        if (
          ((n = (t = e) && t.constructor),
          (r = ("function" == typeof n && n.prototype) || W),
          t !== r)
        )
          return oe(e);
        var t,
          n,
          r,
          i = [];
        for (var s in Object(e))
          ee.call(e, s) && "constructor" != s && i.push(s);
        return i;
      }
      function Ee(e, t) {
        return e + ae(ue() * (t - e + 1));
      }
      function Se(e, t) {
        var n = (function (e, t) {
          return null == e ? void 0 : e[t];
        })(e, t);
        return Ie(n) ? n : void 0;
      }
      var ke = function (e) {
        return te.call(e);
      };
      function Ae(e, t) {
        return (
          !!(t = t ?? i) &&
          ("number" == typeof e || I.test(e)) &&
          e > -1 &&
          e % 1 == 0 &&
          e < t
        );
      }
      function Te(e) {
        if (null != e) {
          try {
            return X.call(e);
          } catch (e) {}
          try {
            return e + "";
          } catch (e) {}
        }
        return "";
      }
      function Le(e, t, n) {
        var i,
          o,
          d,
          f = -1,
          g = (function (e) {
            if (!e) return [];
            if (De(e))
              return (function (e) {
                return (
                  "string" == typeof e || (!Ce(e) && qe(e) && te.call(e) == l)
                );
              })(e)
                ? G(e)
                : (function (e, t) {
                    var n = -1,
                      r = e.length;
                    for (t || (t = Array(r)); ++n < r; ) t[n] = e[n];
                    return t;
                  })(e);
            if (ie && e[ie])
              return (function (e) {
                for (var t, n = []; !(t = e.next()).done; ) n.push(t.value);
                return n;
              })(e[ie]());
            var t = ke(e),
              n = t == u ? V : t == c ? K : je;
            return n(e);
          })(e),
          v = g.length,
          I = v - 1;
        for (
          (
            n
              ? (function (e, t, n) {
                  if (!_e(n)) return !1;
                  var r = typeof t;
                  return (
                    !!("number" == r
                      ? De(n) && Ae(t, n.length)
                      : "string" == r && (t in n)) &&
                    (function (e, t) {
                      return e === t || (e != e && t != t);
                    })(n[t], e)
                  );
                })(e, t, n)
              : void 0 === t
          )
            ? (t = 1)
            : ((i = (function (e) {
                var t = (function (e) {
                    return e
                      ? (e = (function (e) {
                          if ("number" == typeof e) return e;
                          if (
                            (function (e) {
                              return (
                                "symbol" == typeof e ||
                                (qe(e) && te.call(e) == h)
                              );
                            })(e)
                          )
                            return a;
                          if (_e(e)) {
                            var t =
                              "function" == typeof e.valueOf ? e.valueOf() : e;
                            e = _e(t) ? t + "" : t;
                          }
                          if ("string" != typeof e) return 0 === e ? e : +e;
                          e = e.replace(p, "");
                          var n = y.test(e);
                          return n || m.test(e)
                            ? M(e.slice(2), n ? 2 : 8)
                            : b.test(e)
                            ? a
                            : +e;
                        })(e)) === r || e === -1 / 0
                        ? (e < 0 ? -1 : 1) * s
                        : e == e
                        ? e
                        : 0
                      : 0 === e
                      ? e
                      : 0;
                  })(e),
                  n = t % 1;
                return t == t ? (n ? t - n : t) : 0;
              })(t)),
              (o = 0),
              (d = v),
              i == i &&
                (void 0 !== d && (i = i <= d ? i : d),
                void 0 !== o && (i = i >= o ? i : o)),
              (t = i));
          ++f < t;

        ) {
          var w = Ee(f, I),
            E = g[w];
          (g[w] = g[f]), (g[f] = E);
        }
        return (g.length = t), g;
      }
      ((de && ke(new de(new ArrayBuffer(1))) != g) ||
        (ce && ke(new ce()) != u) ||
        (le && ke(le.resolve()) != d) ||
        (he && ke(new he()) != c) ||
        (fe && ke(new fe()) != f)) &&
        (ke = function (e) {
          var t = te.call(e),
            n = "[object Object]" == t ? e.constructor : void 0,
            r = n ? Te(n) : void 0;
          if (r)
            switch (r) {
              case ge:
                return g;
              case pe:
                return u;
              case be:
                return d;
              case ye:
                return c;
              case ve:
                return f;
            }
          return t;
        });
      var Ce = Array.isArray;
      function De(e) {
        return (
          null != e &&
          (function (e) {
            return "number" == typeof e && e > -1 && e % 1 == 0 && e <= i;
          })(e.length) &&
          !ze(e)
        );
      }
      function ze(e) {
        var t = _e(e) ? te.call(e) : "";
        return "[object Function]" == t || "[object GeneratorFunction]" == t;
      }
      function _e(e) {
        var t = typeof e;
        return !!e && ("object" == t || "function" == t);
      }
      function qe(e) {
        return !!e && "object" == typeof e;
      }
      function je(e) {
        return e
          ? F(
              e,
              (function (e) {
                return De(e) ? me(e) : we(e);
              })(e)
            )
          : [];
      }
      e.exports = function (e) {
        return Le(e, 4294967295);
      };
    },
    112(e, t, n) {
      "use strict";
      var r =
        (this && this.__importDefault) ||
        function (e) {
          return e && e.__esModule ? e : { default: e };
        };
      Object.defineProperty(t, "__esModule", { value: !0 }),
        (t.INIT_STATE = void 0);
      const i = n(783),
        s = n(733),
        a = r(n(620));
      var o;
      !(function (e) {
        (e[(e.UNINITIALIZED = 0)] = "UNINITIALIZED"),
          (e[(e.REQUESTED = 1)] = "REQUESTED"),
          (e[(e.INITIALIZED = 2)] = "INITIALIZED");
      })(o || (t.INIT_STATE = o = {}));
      const u = [
        { width: 970, height: 90 },
        { width: 320, height: 50 },
        { width: 160, height: 600 },
        { width: 336, height: 280 },
        { width: 728, height: 90 },
        { width: 300, height: 600 },
        { width: 468, height: 60 },
        { width: 970, height: 250 },
        { width: 300, height: 250 },
        { width: 250, height: 250 },
        { width: 120, height: 600 },
      ];
      t.default = class {
        constructor() {
          (this.initState = o.UNINITIALIZED),
            (this.requestInProgress = !1),
            (this.eventListeners = {}),
            (this.adblockDetectionExecuted = !1),
            (this.hasAdblock = !1),
            (this.gameLink = null);
        }
        addEventListener(e, t) {
          if (!this.isValidCrazyEvent(e))
            return void console.error("[CrazySDK] Invalid Event", e);
          const n = this.eventListeners[e] || [];
          (this.eventListeners = { ...this.eventListeners, [e]: [...n, t] }),
            this.callListenersForTriggeredEvents(e, t);
        }
        removeEventListener(e, t) {
          if (!this.isValidCrazyEvent(e))
            return void console.error("[CrazySDK] Invalid Event", e);
          const n = this.eventListeners[e] || [];
          this.eventListeners = {
            ...this.eventListeners,
            [e]: n.filter((e) => e !== t),
          };
        }
        callListenersForTriggeredEvents(e, t) {
          switch (e) {
            case "adblockDetectionExecuted":
              return this.adblockDetectionEventCallback(t);
            case "initialized":
              return this.initEventCallback(t);
          }
        }
        adblockDetectionEventCallback(e) {
          this.adblockDetectionExecuted && e({ hasAdblock: this.hasAdblock });
        }
        inviteLink(e = {}) {
          (0, i.debug)("Requesting invite link"), this.ensureInit(!1);
          let t = "czy_invite=true&utm_source=invite";
          Object.keys(e).forEach((n) => {
            const r = `${n}=${e[n]}`;
            t = `${t}&${r}`;
          });
          const n =
              this.gameLink ||
              "https://www.crazygames.com/game/your-game-will-appear-here",
            r = n.includes("?") ? `${n}&${t}` : `${n}?${t}`;
          return (0, i.debug)(`Invite link is ${r}`), r;
        }
        async checkBannerContainers(e, t) {
          let n;
          (e && 0 !== e.length) || (0, i.debug)("Container id not specified"),
            (n = "string" == typeof e ? [e] : e);
          const r = [];
          for (const e of n) {
            const n = await this.checkVisible(e, t);
            n.isVisible &&
              r.push({ id: e, width: n.size.width, height: n.size.height });
          }
          return r;
        }
        async checkVisible(e, t = !1) {
          return (0, s.checkContainerVisible)(
            e,
            (t) => {
              this.callListeners("bannerError", { containerId: e, error: t });
            },
            t
          );
        }
        getBannerForContainers(e) {
          const t = [];
          return (
            e.forEach((e) => {
              const n = (0, a.default)(u).find(
                (t) => e.width >= t.width && e.height >= t.height
              );
              n
                ? t.push({ containerId: e.id, size: `${n.width}x${n.height}` })
                : (0, i.debug)(
                    `No available banner size has been found for container ${e.id}`
                  );
            }),
            t
          );
        }
        initEventCallback(e) {
          this.initState === o.INITIALIZED && e({ userInfo: this.userInfo });
        }
        callListeners(e, t) {
          (this.eventListeners[e] || []).forEach((e) => e(t));
        }
        isValidCrazyEvent(e) {
          switch (e) {
            case "adStarted":
            case "adFinished":
            case "adError":
            case "adblockDetectionExecuted":
            case "bannerRendered":
            case "bannerError":
            case "requestBanner":
            case "initialized":
              return !0;
            default:
              return !1;
          }
        }
        renderFakeBanner(e) {
          const [t, n] = e.size.split("x"),
            r = document.getElementById(e.containerId);
          if (!r) return;
          r.innerHTML = "";
          const i = document.createElement("img");
          i.setAttribute(
            "src",
            `https://images.crazygames.com/crazygames-sdk/${e.size}.png`
          ),
            i.setAttribute("width", `${t}px`),
            i.setAttribute("height", `${n}px`),
            r.appendChild(i),
            (r.style.backgroundColor = "rgb(191, 173, 255, 0.25)");
        }
      };
    },
    992(e, t, n) {
      "use strict";
      var r,
        i =
          (this && this.__createBinding) ||
          (Object.create
            ? function (e, t, n, r) {
                void 0 === r && (r = n);
                var i = Object.getOwnPropertyDescriptor(t, n);
                (i &&
                  !("get" in i
                    ? !t.__esModule
                    : i.writable || i.configurable)) ||
                  (i = {
                    enumerable: !0,
                    get: function () {
                      return t[n];
                    },
                  }),
                  Object.defineProperty(e, r, i);
              }
            : function (e, t, n, r) {
                void 0 === r && (r = n), (e[r] = t[n]);
              }),
        s =
          (this && this.__setModuleDefault) ||
          (Object.create
            ? function (e, t) {
                Object.defineProperty(e, "default", {
                  enumerable: !0,
                  value: t,
                });
              }
            : function (e, t) {
                e.default = t;
              }),
        a =
          (this && this.__importStar) ||
          ((r = function (e) {
            return (
              (r =
                Object.getOwnPropertyNames ||
                function (e) {
                  var t = [];
                  for (var n in e)
                    Object.prototype.hasOwnProperty.call(e, n) &&
                      (t[t.length] = n);
                  return t;
                }),
              r(e)
            );
          }),
          function (e) {
            if (e && e.__esModule) return e;
            var t = {};
            if (null != e)
              for (var n = r(e), a = 0; a < n.length; a++)
                "default" !== n[a] && i(t, e, n[a]);
            return s(t, e), t;
          });
      Object.defineProperty(t, "__esModule", { value: !0 });
      const o = a(n(112)),
        u = n(660),
        d = n(783);
      class c extends o.default {
        constructor() {
          super(),
            (this.queuedBanners = []),
            (this.initCallbacks = []),
            (this.rafvertizingUrl = ""),
            (this.clientInfo = {}),
            (this.inGameRenderedBannerIds = new Set()),
            (this.configCatValues = {}),
            (this.receiveMessage = (e) => {
              const { type: t, data: n } = e.data;
              if (t)
                return "initialized" === t
                  ? ((this.gfWindow = e.source), void this.initializeReply(n))
                  : void (
                      this.isValidCrazyEvent(t) && this.callListeners(t, e.data)
                    );
            }),
            (this.queuedRequest = null),
            this.registerDefaultListeners();
        }
        init() {
          this.initState === o.INIT_STATE.UNINITIALIZED &&
            ((0, d.debug)("Initializing"),
            this.registerMessageListener(),
            this.sendInit(),
            (this.initState = o.INIT_STATE.REQUESTED));
        }
        async requestAd(e = "midgame") {
          (0, d.debug)(`Requesting ${e} ad`),
            await this.ensureInit(),
            this.requestInProgress ||
              ((this.requestInProgress = !0),
              this.postMessage("requestAd", { adType: e }));
        }
        async requestBanner(e) {
          await this.ensureInit(!0),
            (0, d.debug)("Requesting banners to gameframe", e);
          const t = [];
          for (const n of e) {
            (await this.checkVisible(n.containerId)).isVisible && t.push(n);
          }
          t.length > 0 &&
            ((0, d.debug)("Valid banners", e),
            this.queuedBanners.push(...t),
            this.postMessage("requestBanner", t));
        }
        async requestResponsiveBanner(e) {
          await this.ensureInit(!0),
            (0, d.debug)("Requesting responsive banner to gameframe", e);
          const t = await this.checkBannerContainers(e, !0);
          t.length > 0 &&
            ((0, d.debug)("Valid containers", t),
            this.queuedBanners.push(...this.getBannerForContainers(t)),
            this.postMessage("requestResponsiveBanner", t));
        }
        clearBanner(e) {
          const t = document.querySelector(`#${e}`);
          if ((this.postMessage("clearBanner", {}), t)) {
            for (; t.firstChild; ) t.removeChild(t.firstChild);
            this.inGameRenderedBannerIds.delete(e);
          }
        }
        clearAllBanners() {
          const e = Array.from(this.inGameRenderedBannerIds.values());
          this.postMessage("clearAllBanners", {}),
            e.forEach((e) => {
              this.clearBanner(e);
            });
        }
        inviteLink(e = {}) {
          const t = super.inviteLink(e);
          return this.postMessage("inviteUrl", { inviteUrl: t }), t;
        }
        async happytime() {
          (0, d.debug)("Requesting happytime"),
            await this.ensureInit(),
            this.postMessage("happytime", {});
        }
        async gameplayStart() {
          (0, d.debug)("Requesting gameplay start"),
            await this.ensureInit(),
            this.postMessage("gameplayStart", {});
        }
        async gameplayStop() {
          (0, d.debug)("Requesting gameplay stop"),
            await this.ensureInit(),
            this.postMessage("gameplayStop", {});
        }
        async sdkGameLoadingStart() {
          (0, d.debug)("Requesting start of game loading from sdk"),
            await this.ensureInit(),
            this.postMessage("sdkGameLoadingStart", {});
        }
        async sdkGameLoadingStop() {
          (0, d.debug)("Requesting stop of game loading from sdk"),
            await this.ensureInit(),
            this.postMessage("sdkGameLoadingStop", {});
        }
        sendInit() {
          const e = {
            type: "init",
            data: { version: "1.30.0", sdkType: "js" },
          };
          window.parent.postMessage(e, "*"),
            window.parent.parent.postMessage(e, "*"),
            window.parent.parent.parent.postMessage(e, "*");
        }
        registerDefaultListeners() {
          (0, d.debug)("Registering default listeners"),
            this.addEventListener("adFinished", () => {
              this.requestInProgress = !1;
            }),
            this.addEventListener("adError", () => {
              this.requestInProgress = !1;
            }),
            this.addEventListener("adblockDetectionExecuted", (e) => {
              this.adblockDetectionExecuted = !0;
              const { hasAdblock: t } = e;
              this.hasAdblock = !!t;
            }),
            this.addEventListener("bannerError", (e) => {
              (0, d.debug)(e.error, e.containerId);
            }),
            this.addEventListener("bannerRendered", (e) => {
              this.inGameRenderedBannerIds.add(e.containerId),
                (0, d.debug)(`Banner rendered for container ${e.containerId}`);
            }),
            this.addEventListener("requestBanner", async (e) => {
              (0, d.debug)(
                "Banner request answer from gameframe received",
                e.request
              ),
                this.buildBannerRequestCallback(e.request),
                await (0, u.requestInGameBanner)(e.request);
            });
        }
        buildBannerRequestCallback(e) {
          e.options.banner = {
            callback: (e) => {
              if (e.empty) {
                if (this.useTestAds) {
                  const t = this.queuedBanners.find(
                    (t) => t.containerId === e.code
                  );
                  return void (
                    t &&
                    (this.renderFakeBanner(t),
                    this.removeBannerFromQueue(
                      e.code,
                      e.minPrice,
                      e.houseAd,
                      e.empty
                    ),
                    this.callListeners("bannerRendered", {
                      containerId: e.code,
                    }))
                  );
                }
                const t = `Sorry, no banner is available for the moment for ${e.code}, please retry`;
                this.callListeners("bannerError", {
                  containerId: e.code,
                  error: t,
                }),
                  this.removeBannerFromQueue(
                    e.code,
                    e.minPrice,
                    e.houseAd,
                    e.empty,
                    "UnitNotRendered" === e.type
                      ? "Unit ignored for rendering"
                      : t
                  );
              } else
                this.removeBannerFromQueue(
                  e.code,
                  e.minPrice,
                  e.houseAd,
                  e.empty
                ),
                  this.callListeners("bannerRendered", { containerId: e.code });
            },
          };
        }
        removeBannerFromQueue(e, t, n, r, i) {
          const s = this.queuedBanners.find((t) => t.containerId !== e);
          if (
            ((this.queuedBanners = this.queuedBanners.filter(
              (t) => t.containerId !== e
            )),
            s)
          ) {
            const [e, a] = s.size.split("x").map((e) => parseInt(e));
            this.postMessage("bannerProcessed", {
              containerId: s.containerId,
              width: e,
              height: a,
              error: i,
              minPrice: t,
              houseAd: n,
              empty: r,
            });
          }
        }
        registerMessageListener() {
          window.addEventListener("message", this.receiveMessage, !1);
        }
        async initializeReply(e) {
          var t;
          e && void 0 !== e.debug && (0, d.forceDebug)(e.debug),
            (0, d.debug)("Initialize reply received from gameframe", e),
            this.initState !== o.INIT_STATE.INITIALIZED &&
              (e &&
                ((this.gameLink = e.gameLink),
                (this.rafvertizingUrl = e.rafvertizingUrl),
                (this.useTestAds = e.useTestAds),
                (this.userInfo = e.userInfo),
                (this.clientInfo = e.clientInfo),
                (this.configCatValues =
                  null !== (t = e.configCatValues) && void 0 !== t ? t : {})),
              (this.initState = o.INIT_STATE.INITIALIZED),
              this.initCallbacks.length > 0 &&
                ((0, d.debug)("Calling init callbacks"),
                this.initCallbacks.forEach((e) => e()),
                (this.initCallbacks = [])),
              this.callListeners("initialized", { userInfo: this.userInfo }));
        }
        async ensureInit(e = !1) {
          return this.initState === o.INIT_STATE.INITIALIZED
            ? e
              ? (0, u.loadCrazyAdsIfNeeded)(
                  this.rafvertizingUrl,
                  this.clientInfo,
                  this.configCatValues
                )
              : Promise.resolve()
            : (this.init(),
              new Promise((t) => {
                this.initCallbacks.push(async () => {
                  e
                    ? (await (0, u.loadCrazyAdsIfNeeded)(
                        this.rafvertizingUrl,
                        this.clientInfo,
                        this.configCatValues
                      ),
                      t())
                    : t();
                });
              }));
        }
        postMessage(e, t) {
          this.gfWindow
            ? this.gfWindow.postMessage({ type: e, data: t }, "*")
            : (0, d.debug)("CrazyGames gameframe hasn't been detected");
        }
        isValidCrazyEvent(e) {
          switch (e) {
            case "adStarted":
            case "adFinished":
            case "adError":
            case "adblockDetectionExecuted":
            case "bannerRendered":
            case "bannerError":
            case "requestBanner":
            case "initialized":
              return !0;
            default:
              return !1;
          }
        }
      }
      t.default = c;
    },
    38(e, t, n) {
      "use strict";
      var r,
        i =
          (this && this.__createBinding) ||
          (Object.create
            ? function (e, t, n, r) {
                void 0 === r && (r = n);
                var i = Object.getOwnPropertyDescriptor(t, n);
                (i &&
                  !("get" in i
                    ? !t.__esModule
                    : i.writable || i.configurable)) ||
                  (i = {
                    enumerable: !0,
                    get: function () {
                      return t[n];
                    },
                  }),
                  Object.defineProperty(e, r, i);
              }
            : function (e, t, n, r) {
                void 0 === r && (r = n), (e[r] = t[n]);
              }),
        s =
          (this && this.__setModuleDefault) ||
          (Object.create
            ? function (e, t) {
                Object.defineProperty(e, "default", {
                  enumerable: !0,
                  value: t,
                });
              }
            : function (e, t) {
                e.default = t;
              }),
        a =
          (this && this.__importStar) ||
          ((r = function (e) {
            return (
              (r =
                Object.getOwnPropertyNames ||
                function (e) {
                  var t = [];
                  for (var n in e)
                    Object.prototype.hasOwnProperty.call(e, n) &&
                      (t[t.length] = n);
                  return t;
                }),
              r(e)
            );
          }),
          function (e) {
            if (e && e.__esModule) return e;
            var t = {};
            if (null != e)
              for (var n = r(e), a = 0; a < n.length; a++)
                "default" !== n[a] && i(t, e, n[a]);
            return s(t, e), t;
          });
      Object.defineProperty(t, "__esModule", { value: !0 });
      const o = a(n(112)),
        u = n(783);
      class d extends o.default {
        constructor() {
          super(...arguments),
            (this.overlay = null),
            (this.adDurationInMs = 5e3);
        }
        init() {
          this.initState !== o.INIT_STATE.INITIALIZED &&
            ((this.initState = o.INIT_STATE.INITIALIZED),
            (this.overlay = document.createElement("div")),
            this.createOverlayStyle(),
            document.body.appendChild(this.overlay),
            (0, u.debug)("initializing"));
        }
        async requestAd(e = "midgame") {
          await this.ensureInit(),
            this.requestInProgress || this.renderFakeAd(e);
        }
        happytime() {
          (0, u.debug)("happy time");
        }
        gameplayStart() {
          (0, u.debug)("gameplay start");
        }
        gameplayStop() {
          (0, u.debug)("gameplay stop");
        }
        sdkGameLoadingStart() {
          (0, u.debug)("game load start from sdk");
        }
        sdkGameLoadingStop() {
          (0, u.debug)("game load stop from sdk");
        }
        async requestBanner(e) {
          (0, u.debug)("Requesting banners to gameframe", e);
          const t = [];
          for (const n of e) {
            (await this.checkVisible(n.containerId)).isVisible && t.push(n);
          }
          t.length > 0 &&
            ((0, u.debug)("Valid banners", t), this.renderFakeBanners(t));
        }
        async requestResponsiveBanner(e) {
          (0, u.debug)("Requesting responsive banner", e);
          const t = await this.checkBannerContainers(e, !0);
          this.renderFakeBanners(this.getBannerForContainers(t));
        }
        async ensureInit(e = !1) {}
        initEventCallback(e) {
          (0, u.debug)("Cannot get user info outside of CrazyGames"),
            this.initState === o.INIT_STATE.INITIALIZED &&
              e({
                userInfo: {
                  browser: { name: "Chrome", version: "89.0.4389.82" },
                  countryCode: "FR",
                  locale: "en-US",
                  os: { name: "Windows", version: "10" },
                },
              });
        }
        renderFakeBanners(e) {
          e.forEach((e) => {
            this.renderFakeBanner(e);
          });
        }
        renderFakeAd(e) {
          (0, u.debug)(`requesting ${e} ad`),
            (this.requestInProgress = !0),
            this.showOverlay(),
            (this.overlay.innerHTML = `<h1>A ${e} ad would appear here</h1>`),
            this.callListeners("adStarted", {}),
            window.setTimeout(() => {
              (this.requestInProgress = !1),
                this.callListeners("adFinished", {}),
                this.hideOverlay();
            }, this.adDurationInMs);
        }
        showOverlay() {
          this.overlay.style.display = "flex";
        }
        hideOverlay() {
          (this.overlay.style.display = "none"), (this.overlay.innerHTML = "");
        }
        createOverlayStyle() {
          const e = {
            position: "fixed",
            display: "none",
            width: "100%",
            height: "100%",
            top: "0",
            left: "0",
            right: "0",
            bottom: "0",
            "align-items": "center",
            "justify-content": "center",
            "background-color": "rgba(0,0,0,0.5)",
            "z-index": "10000",
          };
          for (const t in e) this.overlay.style[t] = e[t];
        }
        clearBanner(e) {
          (0, u.debug)(`clearBanner ${e}`);
        }
        clearAllBanners() {
          (0, u.debug)("clearAllBanners");
        }
      }
      t.default = d;
    },
    960(e, t, n) {
      "use strict";
      var r,
        i =
          (this && this.__createBinding) ||
          (Object.create
            ? function (e, t, n, r) {
                void 0 === r && (r = n);
                var i = Object.getOwnPropertyDescriptor(t, n);
                (i &&
                  !("get" in i
                    ? !t.__esModule
                    : i.writable || i.configurable)) ||
                  (i = {
                    enumerable: !0,
                    get: function () {
                      return t[n];
                    },
                  }),
                  Object.defineProperty(e, r, i);
              }
            : function (e, t, n, r) {
                void 0 === r && (r = n), (e[r] = t[n]);
              }),
        s =
          (this && this.__setModuleDefault) ||
          (Object.create
            ? function (e, t) {
                Object.defineProperty(e, "default", {
                  enumerable: !0,
                  value: t,
                });
              }
            : function (e, t) {
                e.default = t;
              }),
        a =
          (this && this.__importStar) ||
          ((r = function (e) {
            return (
              (r =
                Object.getOwnPropertyNames ||
                function (e) {
                  var t = [];
                  for (var n in e)
                    Object.prototype.hasOwnProperty.call(e, n) &&
                      (t[t.length] = n);
                  return t;
                }),
              r(e)
            );
          }),
          function (e) {
            if (e && e.__esModule) return e;
            var t = {};
            if (null != e)
              for (var n = r(e), a = 0; a < n.length; a++)
                "default" !== n[a] && i(t, e, n[a]);
            return s(t, e), t;
          });
      Object.defineProperty(t, "__esModule", { value: !0 });
      const o = a(n(112)),
        u = n(660),
        d = n(783);
      class c extends o.default {
        constructor() {
          super(...arguments), (this.yandexPromise = null);
        }
        init() {
          this.installYandex();
        }
        async requestAd(e = "midgame") {
          if (((0, d.debug)(`Requesting ${e} ad`), !this.requestInProgress))
            return (
              (this.requestInProgress = !0),
              "rewarded" === e
                ? this.requestRewardedAd()
                : this.requestMidrollAd()
            );
        }
        async requestBanner(e) {
          (0, d.debug)("Banner not supported with YandexSDK");
        }
        async requestResponsiveBanner(e) {
          (0, d.debug)("Responsive banner not supported with YandexSDK");
        }
        inviteLink(e = {}) {
          return (0, d.debug)("Invite link not supported with YandexSDK"), "";
        }
        async happytime() {
          (0, d.debug)("Happytime not supported with YandexSDK");
        }
        async gameplayStart() {
          (0, d.debug)("Gameplay start not supported with YandexSDK");
        }
        async gameplayStop() {
          (0, d.debug)("Gameplay stop not supported with YandexSDK");
        }
        async sdkGameLoadingStart() {
          (0, d.debug)(
            "Game load start from SDK is not supported with YandexSDK"
          );
        }
        async sdkGameLoadingStop() {
          (0, d.debug)(
            "Game load stop from SDK is not supported with YandexSDK"
          );
        }
        async ensureInit() {
          return this.yandexSDKObj
            ? this.yandexSDKObj
            : this.initState !== o.INIT_STATE.UNINITIALIZED &&
              this.yandexPromise
            ? ((this.yandexSDKObj = await this.yandexPromise),
              this.yandexSDKObj)
            : this.installYandex();
        }
        async installYandex() {
          (0, d.debug)("Initializing"),
            (this.initState = o.INIT_STATE.REQUESTED),
            await (0, u.loadScript)("https://yandex.ru/games/sdk/v2");
          const e = window.YaGames.init();
          this.yandexPromise = e;
          const t = await Promise.race([
            e,
            new Promise((e, t) => {
              setTimeout(() => {
                t("Yandex SDK was unable to init within the timeout");
              }, 5e3);
            }),
          ]);
          return (
            (this.yandexSDKObj = t),
            (0, d.debug)("Yandex SDK initialized"),
            (this.initState = o.INIT_STATE.INITIALIZED),
            this.callListeners("initialized", {
              userInfo: void 0,
              locale: t.environment.i18n.lang,
            }),
            t
          );
        }
        async requestMidrollAd() {
          (await this.ensureInit()).adv.showFullscreenAdv({
            callbacks: {
              onOpen: () => {
                (this.requestInProgress = !1),
                  this.callListeners("adStarted", {});
              },
              onClose: () => {
                (this.requestInProgress = !1),
                  this.callListeners("adFinished", {});
              },
              onError: (e) => {
                (this.requestInProgress = !1), this.callListeners("adError", e);
              },
            },
          });
        }
        async requestRewardedAd() {
          (await this.ensureInit()).adv.showRewardedVideo({
            callbacks: {
              onOpen: () => {
                (this.requestInProgress = !1),
                  this.callListeners("adStarted", {});
              },
              onRewarded: () => {
                (this.requestInProgress = !1),
                  this.callListeners("adFinished", {});
              },
              onClose: () => {
                (this.requestInProgress = !1),
                  this.callListeners("adFinished", {});
              },
              onError: (e) => {
                (this.requestInProgress = !1), this.callListeners("adError", e);
              },
            },
          });
        }
        clearBanner(e) {
          (0, d.debug)("clearBanner not supported with YandexSDK");
        }
        clearAllBanners() {
          (0, d.debug)("clearAllBanners not supported with YandexSDK");
        }
      }
      t.default = c;
    },
    660(e, t, n) {
      "use strict";
      (t.requestInGameBanner = async function (e) {
        const { CrazygamesAds: t } = window;
        if (((0, r.debug)("Requesting banner to CrazyAds"), !t)) {
          const e = "CrazygamesAds not found, maybe using an adblocker.";
          throw ((0, r.debug)(e), new Error(e));
        }
        t.requestAds(e.request, e.options);
      }),
        (t.loadScript = i),
        (t.loadCrazyAdsIfNeeded = function (e, t, n) {
          if (window.CrazygamesAds) return Promise.resolve();
          return (function (e, t, n) {
            if (s) return s;
            return (
              (s = i(e).then(() => {
                const e = window.CrazygamesAds;
                if (!e) {
                  const e =
                    "CrazygamesAds not found, maybe using an adblocker.";
                  throw ((0, r.debug)(e), new Error(e));
                }
                e.initAds({
                  source: "sdk",
                  analyticsEventHandler: () => {},
                  clientInfo: t,
                  configCatValues: n,
                });
              })),
              s
            );
          })(e, t, n);
        });
      const r = n(783);
      function i(e) {
        return new Promise((t, n) => {
          const r = document.createElement("script");
          (r.onload = () => t()),
            (r.onerror = (e) => n(e)),
            (r.src = e),
            (r.async = !0),
            document.head.appendChild(r);
        });
      }
      let s;
    },
    783(e, t, n) {
      "use strict";
      var r =
        (this && this.__importDefault) ||
        function (e) {
          return e && e.__esModule ? e : { default: e };
        };
      Object.defineProperty(t, "__esModule", { value: !0 }),
        (t.CrazyEventTypeMap = t.CrazyAdTypeMap = void 0),
        (t.forceDebug = function (e) {
          o = e;
        }),
        (t.debug = d);
      const i = r(n(992)),
        s = r(n(38)),
        a = r(n(960));
      let o;
      class u {
        static getInstance() {
          if (!this.instance)
            try {
              const e = window.parent;
              window.location.origin.endsWith("yandex.net") ||
              "true" === c("useYandexSdk")
                ? (d("Running with YandexSDK"),
                  (this.instance = new a.default()))
                : e.Crazygames && e.Crazygames.load
                ? (d("Running with CrazySDK"),
                  (this.instance = new i.default()))
                : (d("Running with LocalSDK"),
                  (o = !0),
                  (this.instance = new s.default()));
            } catch {
              d("Falling back to CrazySDK"), (this.instance = new i.default());
            }
          return this.instance;
        }
      }
      function d(e, ...t) {
        void 0 === o && (o = "true" === c("sdk_debug")),
          o &&
            (t.length > 0
              ? console.log(`[JS-SDK] ${e}`, t)
              : console.log(`[JS-SDK] ${e}`));
      }
      function c(e) {
        return new URLSearchParams(window.location.search).get(e);
      }
      (u.instance = null),
        (t.CrazyAdTypeMap = { midgame: "midgame", rewarded: "rewarded" }),
        (t.CrazyEventTypeMap = {
          adStarted: "adStarted",
          adFinished: "adFinished",
          adError: "adError",
          adblockDetectionExecuted: "adblockDetectionExecuted",
        }),
        (window.CrazyGames = {
          CrazySDK: u,
          CrazyAdType: t.CrazyAdTypeMap,
          CrazyEventType: t.CrazyEventTypeMap,
        }),
        (function (e) {
          const t = document.createElement("style");
          (t.textContent = e), document.head.append(t);
        })(
          "\n.crazy-banner-container {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n}\n"
        ),
        (t.default = i.default);
    },
    733(e, t) {
      "use strict";
      t.checkContainerVisible = async function (e, t, n) {
        const r = document.getElementById(e);
        if (!r) {
          return (
            t(`The container ${e} is not present on the page`),
            { isVisible: !1, size: { width: 0, height: 0 } }
          );
        }
        const i = await (async function (e) {
          return new Promise((t) => {
            const n = new IntersectionObserver(([e]) => {
              t({
                isVisible: e.intersectionRatio > 0.95,
                size: {
                  width: Math.ceil(e.boundingClientRect.width),
                  height: Math.ceil(e.boundingClientRect.height),
                },
              }),
                n.disconnect();
            });
            n.observe(e);
          });
        })(r);
        if (!i.isVisible) {
          return t(`The container ${e} is not entirely visible on the page`), i;
        }
        if (n && (0 === i.size.width || 0 === i.size.height)) {
          return (
            t(
              `The container ${e} must have a non-null width and height to render a responsive banner.`
            ),
            { isVisible: !1, size: { width: 0, height: 0 } }
          );
        }
        return r.classList.add("crazy-banner-container"), i;
      };
    },
  };
  const t = {};
  function n(r) {
    const i = t[r];
    if (void 0 !== i) return i.exports;
    const s = (t[r] = { exports: {} });
    return e[r].call(s.exports, s, s.exports, n), s.exports;
  }
  n.g = (function () {
    if ("object" == typeof globalThis) return globalThis;
    try {
      return this || new Function("return this")();
    } catch (e) {
      if ("object" == typeof window) return window;
    }
  })();
  n(783);
})();
