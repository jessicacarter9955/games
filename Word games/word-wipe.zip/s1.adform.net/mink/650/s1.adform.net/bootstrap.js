(function (f) {
  function I(a, c, b) {
    b || ((b = c), (c = []));
    q = 0;
    (y[a] && "$ignore" !== a) ||
      ((y[a] = !0),
      r(c, function () {
        h[a] = b.apply(null, arguments);
      }));
  }
  function r() {
    p.push(arguments);
    B();
  }
  function B() {
    var a, c;
    if (p.length) {
      var b = p;
      p = [];
      var d = {};
      m = [];
      for (a = b.length; a--; ) {
        var e = [];
        var k = !0;
        for (c = b[a][0].length; c--; ) {
          var l = b[a][0][c];
          l in h
            ? (e[c] = h[l])
            : (d[l] || y[l] || (m.push(l), (d[l] = !0)),
              k && (p.push(b[a]), (k = !1)));
        }
        if (k) {
          var J = !0;
          try {
            b[a][1].apply(null, e);
          } catch (K) {
            t(K, "runtime");
          }
        }
      }
      J ? B() : p.length && !u && (u = z(C, 100));
    }
  }
  function C() {
    var a,
      c = [];
    u = D(u);
    if (!q) {
      A = D(A);
      for (a = m.length; a--; ) {
        var b = m[a];
        v[b] ? (m.splice(a, 1), 2 > v[b] && (v[b]++, c.push(b))) : (v[b] = 1);
      }
      q = m.length;
      c.length &&
        t(
          Error("Modules '" + c.join("', '") + "' failed to load"),
          "loadFailed"
        );
      if (q) {
        A = z(L, 6e4);
        try {
          var d = n.createElement("script");
          d.src =
            M +
            "//s1.adform.net/mink/650/s1.adform.net/load/v/0.0.299/e/" +
            h.$env.$hash() +
            "/i/" +
            h.$ignore +
            "/r:" +
            m.sort().join(":");
          var e = n.__gEBTN__("script")[0];
          d.onerror = N;
          e
            ? e.parentNode.insertBefore(d, e)
            : (n.body || n.head).appendChild(d);
        } catch (k) {
          t(k, "script_insert");
        }
      }
    }
  }
  function N() {
    w("response_error", this.src);
  }
  function L() {
    q = 0;
    C();
  }
  function w(a, c, b, d) {
    var e = [],
      k = f.Image;
    if (Math.random() < (b || 0.03)) {
      e.push(((x && x.host) || "//track.adform.net") + "/serving/jslog/");
      e.push("?src=");
      e.push(encodeURIComponent(a));
      e.push("&msg=");
      e.push(encodeURIComponent(c));
      e.push("&level=");
      e.push(encodeURIComponent(d || "error"));
      var l = k ? new k(1, 1) : n.createElement("img");
      l.src = e.join("");
    }
  }
  function t(a, c) {
    var b = "" + (a.stack || a);
    0 > b.indexOf(a.message || "") && (b = a + "\n" + b);
    z(function () {
      throw b;
    }, 0);
    w(c, b);
  }
  function E() {
    for (var a = arguments, c = 0, b = a.length, d = []; c < b; c++)
      O(a[c]) || d.push(a[c]);
    return d.length ? F.apply(g, d) : g.length;
  }
  function O(a) {
    function c(e) {
      e.apply(null, a.slice(1));
    }
    var b = a[0],
      d = h[b];
    d ? c(d) : r([b], c);
  }
  var F,
    u,
    A,
    m,
    g = f._adfq || (f._adfq = []),
    n = f.document,
    z = f.setTimeout,
    D = f.clearTimeout,
    x = f.Adform,
    M =
      (x && "https:" === (x.shost || "").split("/")[0]) ||
      "https:" === f.location.protocol
        ? "https:"
        : "http:",
    h = {
      require: r,
      $boot: {
        window: f,
        require: r,
        rethrow: t,
        log: w,
        deprecate: function (a, c, b) {
          var d = !1;
          return function () {
            d || (w("deprecate", c, b, "info"), (d = !0));
            return a.apply(this, arguments);
          };
        },
        updateIgnore: function (a) {
          if (!h.$ignore) return a;
          var c = h.$ignore,
            b = "",
            d,
            e = Math.max(a.length, c.length);
          for (d = 0; d < e; d++) b += G[(H[a[d]] || 0) | (H[c[d]] || 0)];
          return b;
        },
      },
      $collectTags: {},
    },
    q = 0,
    p = [],
    y = {},
    v = {},
    G = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789.-",
    H = G.split("").reduce(function (a, c, b) {
      a[c] = b;
      return a;
    }, {});
  n.__gEBTN__ = n.getElementsByTagName;
  (function () {
    if (!g.define) {
      F = g.push;
      g.define = I;
      g.push = E;
      var a = g.slice();
      g.length = 0;
      E.apply(g, a);
    }
  })();
})(window);
(function (
  a,
  i,
  c,
  K,
  fa,
  ba,
  ea,
  b,
  ga,
  e,
  L,
  ha,
  da,
  E,
  u,
  Z,
  x,
  y,
  ca,
  ia,
  G,
  aa,
  Y,
  f
) {
  a(i, [c], function (d) {
    var c = d.window,
      a = c.Adform || {},
      e = a.ET || {},
      b = a.RMB || {},
      f = b.Content || {};
    b.Type = b.Type || {};
    b.Content = f;
    a.ET = e;
    a.RMB = b;
    return (c.Adform = a);
  });
  a(K, function () {
    function g(a, b) {
      return m.call(a, b);
    }
    function n(a) {
      for (var b = 1; b < arguments.length; b++) {
        var d = arguments[b];
        if (d) for (var f in d) g(d, f) && (a[f] = d[f]);
      }
      return a;
    }
    function l(a, b, d) {
      for (var f = 5 >= d, h = 1; h < b.length; h++) {
        var e = b[h];
        if (e)
          for (var c in e)
            g(e, c) &&
              "__proto__" !== c &&
              "constructor" !== c &&
              "prototype" !== c &&
              (f && k(a[c]) && k(e[c])
                ? l(a[c], [null, e[c]], d + 1)
                : (a[c] = e[c]));
      }
      return a;
    }
    function k(a) {
      return (
        null !== a &&
        "object" === typeof a &&
        "[object Object]" === Object.prototype.toString.call(a)
      );
    }
    var m = Object.prototype.hasOwnProperty;
    return {
      assign: Object.assign || n,
      deepAssign: function (a) {
        return l(a, arguments, 0);
      },
      hop: g,
      isPlainObject: k,
      now: function () {
        return (Date.now && Date.now()) || +new Date();
      },
      once: function (a) {
        var b = !1;
        return function () {
          b || ((b = !0), a.apply(this, arguments));
        };
      },
    };
  });
  a(fa, [c, i, K], function (l, m, n) {
    function h(d) {
      return p(d).random();
    }
    function p(d) {
      var f = {
          random: q,
          int32: function () {
            var e,
              r = [0, 2567483615];
            if (624 <= a)
              for (e = a = 0; 624 > e; e++) {
                var c = (b[e] & 2147483648) | (b[(e + 1) % 624] & 2147483647);
                b[e] = b[(e + 397) % 624] ^ (c >>> 1) ^ r[c & 1];
              }
            c = b[a++];
            c ^= c >>> 11;
            c ^= (c << 7) & 2636928640;
            c ^= (c << 15) & 4022730752;
            return (c ^ (c >>> 18)) >>> 0;
          },
        },
        b = [],
        a,
        g;
      d || (d = Math.round(1e5 * (k() + Math.random())));
      b[0] = d >>> 0;
      for (a = 1; (g = a - 1), 624 > a; a++)
        (d = b[g] ^ (b[g] >>> 30)),
          (b[a] =
            ((1812433253 * ((d & 4294901760) >>> 16)) << 16) +
            1812433253 * (d & 65535) +
            a),
          (b[a] >>>= 0);
      return f;
    }
    function q() {
      return Math.floor(this.int32() / 65535);
    }
    var k = n.now;
    m.random = l.deprecate(
      h,
      "Adform.random is deprecated. Use h/random instead."
    );
    return {
      random: h,
      randomizeId: function (d) {
        var f = ("" + d).slice(0, 5),
          b = 5 === f.length && "92233" > f ? 19 : 18,
          a = "" + (k() % 72e5),
          g = b - f.length - a.length,
          e = 0 < g ? Math.random().toFixed(g).slice(2) : "";
        return (f + a + e).substring(0, b);
      },
    };
  });
  a(ba, [c, i], function (k, a) {
    function m(e, c) {
      var f = c ? (9 == c.nodeType ? c : c.document) : n;
      0 <= e.indexOf('"') && k.log("xss_detected", e);
      f.write('<script type="text/javascript" src="' + e + '">\x3c/script>');
    }
    function p(e) {
      for (
        var c = a._prepareBannerDataCB,
          f = {},
          d =
            "ADFVideoCDN ADFDomainCDN ADFDomain VideoCDN ADFVideoCDNList ADFcmpgnID ADFmembID ADFtagID ADFafbanID ADFBanVer ADFBanVerBak ADFbanID ADFbanPlacID ADFUnloadID ADFClientSiteId ADFGeoData ADFDeviceType ADFGroupId ADFTemplateVersion ADFTemplateId ADF_ClickEvent".split(
              " "
            ),
          g = d.length - 1;
        0 <= g;
        g--
      )
        d[g] in h && (f[d[g]] = h[d[g]]);
      var l = (a.RMBData = { clicktags: "" });
      a._prepareBannerDataCB = function () {
        for (var b = d.length - 1; 0 <= b; b--)
          d[b] in f && (h[d[b]] = f[d[b]]);
        a.prepareBannerData(e);
        for (b in l)
          a.RMBData[b] = "clicktags" != b ? l[b] : a.RMBData[b] + l[b];
        c && c();
      };
      c || m(a.scriptBase + "bootstrap/Adform.BannerData.js?v=" + a.cache);
    }
    var h = k.window,
      n = h.document;
    a.host && (ADFDynamicDomain = a.host + "/banners/");
    a.shost && (ADFTemplateDomain = a.shost + "/banners/");
    a.ENV = {
      akamaiHost:
        ("https:" == n.location.protocol ? "https://" : "http://") +
        "s2.adform.net/Banners",
    };
    a.Log = a.Log || { sendMessage: k.log };
    a.loadResource = a.loadResource || m;
    a.prepareBannerData = a.prepareBannerData || p;
    return {
      loadResource: a.loadResource,
      prepareBannerData: a.prepareBannerData,
    };
  });
  a(ea, function () {
    function h(a, d) {
      this.delimiter = d || ";";
      a = a || "";
      var c = a.split(";oobclicktrack=");
      c.shift();
      c.length && (this.tracks = c);
      var b = a.split("?");
      this._base = b.shift();
      var e = b.join("?");
      e.slice(0, g.length).toUpperCase() === g &&
        ((this._cc = g), (e = e.substring(g.length)));
      this._parts = e.split(this.delimiter);
      this.append = [];
    }
    function k(a, d, c) {
      var b = a.length,
        e = d + "=",
        m = e.length;
      for (c || (e = e.toLowerCase()); b--; ) {
        var l = a[b].slice(0, m);
        c || (l = l.toLowerCase());
        if (l === e) break;
      }
      return b;
    }
    var n = Object.prototype.hasOwnProperty,
      f = h.prototype;
    f.copy = function () {
      var a,
        d = new h();
      for (a in this)
        n.call(this, a) &&
          (d[a] = this[a] && this[a].slice ? this[a].slice(0) : this[a]);
      return d;
    };
    f.get = function (a, d) {
      var c = this._parts,
        b = k(c, a, d);
      if (~b) return c[b].slice(a.length + 1);
    };
    f.set = function (a, d, c) {
      var b = this._parts,
        e = k(b, a, c);
      0 > e ? b.push(a + "=" + d) : (b[e] = b[e].slice(0, a.length + 1) + d);
      return this;
    };
    f.unset = function (a, d) {
      var c = this._parts,
        b = k(c, a, d);
      ~b && c.splice(b, 1);
      return this;
    };
    f.toString = function () {
      return (
        this._base +
        "?" +
        (this._cc || "") +
        this._parts.join(this.delimiter) +
        this.append.join("")
      );
    };
    var g = "CC=1&";
    return h;
  });
  a(b, [c], function (T) {
    function Ea(k) {
      return k;
    }
    function Fa() {
      function k(b, c) {
        for (var f = l.length, m, n = 0; n < f; n++)
          l[n] && (m = b[c] || m), (b = b.parent);
        return m;
      }
      function A() {
        for (var b = 1, c = u; b < l.length && !l[b]; b++) c = c.parent;
        try {
          return c == c.Function("return window")();
        } catch (f) {}
      }
      function q(b, c) {
        var f = c.charAt(0).toUpperCase() + c.slice(1);
        return g(b, "ms" + f, "moz" + f, "webkit" + f, c);
      }
      function v(b) {
        try {
          return b.frames.omid_v1_present_app
            ? "app"
            : b.frames.omid_v1_present_web
            ? "web"
            : "";
        } catch (c) {}
      }
      function g(b) {
        for (var c = arguments, f = c.length; --f; ) if (c[f] in b) return c[f];
      }
      function e(b, c) {
        return 0 <= ("" + b).toLowerCase().indexOf(c.toLowerCase());
      }
      var a = T.window,
        h = a.document,
        Ga = h.documentElement,
        w = a.navigator,
        u = a.parent,
        I = w.vendor,
        d = w.userAgent,
        Ha = a.location || {},
        Ia = h.createElement("div"),
        l = (function (b) {
          for (
            var c, f = 100, m = b.top, n = [!0];
            --f && b && b != m && b != b.parent;

          ) {
            try {
              c = !!(b = b.parent).Image;
            } catch (Pa) {
              c = !1;
            }
            n.push(c);
          }
          return n;
        })(a),
        x = a != u,
        J = !x || l[1],
        r = !x || l[l.length - 1],
        U = x && A(),
        V = q(h, "hidden"),
        W = !!V,
        B = /MSIE|Trident/i.test(d),
        X =
          B &&
          (("Microsoft Internet Explorer" === w.appName &&
            /MSIE (\d+[\.\d]*)/i.exec(d)) ||
            /rv:(\d+[\.\d]*)/i.exec(d))
            ? parseFloat(RegExp.$1)
            : -1,
        Y = g(Ia, "addEventListener"),
        Z = e(d, "Macintosh"),
        C = e(I, "apple computer"),
        K = e(d, "ipad"),
        L = e(d, "iphone"),
        t = K || L;
      var D = t && (D = /\sos\s(\d+)_\d+/i.exec(d)) && 4 < D[1] >> 0;
      var E = e(I, "google"),
        F = !t && e(d, "android"),
        aa = "ontouchstart" in h || "ontouchstart" in a,
        G = (C || E) && /(chrome|crios)+\/[\d\.]+\s/i.test(d),
        Ja = G && /[chrome|crios]+\/([\d\.]+)\s/i.exec(d)[1],
        H = /Firefox\/[\d\.]+/i.test(d),
        ba = e(d, "opera"),
        ca = e(d, "opr") && e(I, "opera software"),
        y =
          !/Chrome|CriOS|Skyfire/i.test(d) && /Safari+\/[\.\d]+$/i.test(d) && C,
        M = B && (e(d, "IEMobile") || e(d, "WPDesktop")),
        da = y && !("webkitRequestAnimationFrame" in a),
        ea = "screenX" in a,
        fa = "outerWidth" in a,
        ha = "mozInnerScreenX" in a,
        ia = Ga.msContentZoomFactor,
        ja = !(!h.fireEvent || !h.attachEvent),
        Ka = q(a, "requestAnimationFrame"),
        N = t && !y && !w.standalone && !G && !E,
        ka = g(a, "IntersectionObserver") && !H,
        la =
          !!("srcdoc" in h.createElement("iframe")) &&
          e(Ha.href, "adform.com") &&
          !H,
        O = t || F,
        p = r ? a.top.omid3p : a.omid3p;
      if (!p)
        try {
          p = a.frames.omid_v1_present || a.top.frames.omid_v1_present;
        } catch (b) {}
      p = !!p;
      var La = v(a) || v(a.top),
        ma = !p && !O && !M && g(h, "hasFocus"),
        na = !r && 11 == X,
        z = a.wisp,
        oa = z && z.sdk && z.sdk.platform,
        pa = y && !r,
        qa = a._adform && a._adform.tagFrame,
        ra = !!qa,
        sa = k(a, "mraid"),
        P = !!sa,
        Ma = k(a, "MRAID_ENV"),
        Q = w.sendBeacon && !P,
        ta = !((!a.XMLHttpRequest && !Q) || !a.FormData) && !a.XDomainRequest,
        ua = !!a.fetch,
        Na = (function () {
          for (var b = a, c = u, f = l, m = 1, n = f.length; m < n; m++)
            f[m] && (b = c), (c = c.parent);
          return b;
        })(),
        R = J && u.getVPAIDAd && u.getVPAIDAd(),
        va = !(!R || !R.on),
        wa = !!a.chrome,
        xa = "" === h.referrer && "" === h.domain,
        ya = !!g(a, "onpagehide"),
        Oa = q(h, "visibilityState"),
        za =
          !r &&
          !N &&
          !(F && e(d, "; wv")) &&
          ("null" === a.origin || "" === h.domain);
      if ("android" == oa || "ios" == oa)
        for (var Aa in z)
          if (/^adObject.+/i.test(Aa)) {
            var Ba = z[Aa].inscreen;
            var Ca = !!Ba;
            break;
          }
      return {
        result: [
          x,
          J,
          r,
          U,
          W,
          B,
          Y,
          Z,
          C,
          K,
          L,
          t,
          D,
          E,
          F,
          aa,
          G,
          H,
          ba,
          ca,
          y,
          M,
          da,
          ea,
          fa,
          ha,
          ia,
          ja,
          !1,
          N,
          ka,
          la,
          O,
          p,
          ma,
          na,
          Ca,
          pa,
          ra,
          P,
          Q,
          ta,
          ua,
          va,
          wa,
          xa,
          ya,
          za,
        ],
        exports: {
          nop: function () {},
          access: l,
          frame: x,
          accParent: J,
          accTop: r,
          isolate: U,
          hidden: V,
          hasHidden: W,
          isIE: B,
          ieVersion: X,
          addEvent: Y,
          isMac: Z,
          isApple: C,
          isIPad: K,
          isIPhone: L,
          isIOS: t,
          isIOSF: D,
          isGoogle: E,
          isAndroid: F,
          isTouch: aa,
          isChrome: G,
          chromeVersion: Ja,
          isFirefox: H,
          isOpera: ba,
          isOperaWebkit: ca,
          isSafari: y,
          isIEMobile: M,
          isSafari5OrLess: da,
          screenX: ea,
          outerWidth: fa,
          mozInnerScreenX: ha,
          msZF: ia,
          ieDomEvents: ja,
          reqAni: Ka,
          isRad: !1,
          isIOSWebView: N,
          intersectionAPI: ka,
          hasSrcDoc: la,
          isIOSOrAndroid: O,
          isOMID: p,
          omidEnv: La,
          hasFocus: ma,
          IEVisibility: na,
          isWisp: Ca,
          wisp: Ba,
          RAFVisibility: pa,
          asyncFrame: qa,
          isAsyncFrame: ra,
          mraid: sa,
          isMraid: P,
          mraidEnv: Ma,
          hasBeacon: Q,
          usePOST: ta,
          hasFetch: ua,
          topAcc: Na,
          VPAID: R,
          isVPAID: va,
          isChromium: wa,
          forceBackupEdge: xa,
          usePageHide: ya,
          visibilityStateProp: Oa,
          iframeSandbox: za,
        },
      };
    }
    var Da = {
        $hash: function () {
          if (!S) {
            var k = Fa(),
              A = k.result,
              q = k.exports,
              v = [],
              g = 0,
              e = A.length,
              a = 0;
            for (e += (6 - (e % 6)) % 6; g < e; g++)
              (a = (a << 1) | !!A[g]),
                5 == g % 6 &&
                  (v.push(
                    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789.-".charAt(
                      a
                    )
                  ),
                  (a = 0));
            for (g in q) Da[g] = q[g];
            S = v.join("");
          }
          return S;
        },
      },
      S;
    try {
      if (!Function("return (" + Ea + ")(1)===1")())
        throw "Incorrect eval result";
    } catch (k) {
      T.log("function_constructor", k);
    }
    return Da;
  });
  a(ga, [b], function (a) {
    return function (c) {
      var b = c || a.omidEnv;
      return a.isMraid || a.mraidEnv || "app" == b
        ? 1
        : a.accTop || "web" == b
        ? 0
        : "";
    };
  });
  a(e, function () {
    function D(a, b) {
      try {
        var c = a.frames;
      } catch (e) {}
      if (c) {
        (b = b || []).push(a);
        for (var d = 0; c && d < c.length; d++) D(a.frames[d], b);
      }
      return b;
    }
    function E(a, b, c) {
      b = void 0 === b ? 1e4 : b;
      c = void 0 === c ? !1 : c;
      F();
      G();
      u || window.__tcfapi || m || window.__gpp
        ? (c ? k.push(a) : l.push(a),
          x(),
          R(function () {
            var d = [v(l, a), v(k, a)],
              e = n("Adform", {}),
              f = e.gdpr,
              p = e.gdpr_consent,
              g = e.adform_consent,
              h = e.gpp;
            e = e.gpp_sid;
            if (-1 < d[0])
              l.splice(d[0], 1)[0]({
                gdpr: f,
                gdpr_consent: p,
                adform_consent: g,
                gpp: h,
                gpp_sid: e,
              });
            if (-1 < d[1])
              k.splice(d[1], 1)[0]({
                gdpr: f,
                gdpr_consent: p,
                adform_consent: g,
                gpp: h,
                gpp_sid: e,
              });
          }, b))
        : a(null, "CMP not found.");
    }
    function F() {
      var a = H("tcfapi"),
        b = a.isCrossDomain;
      u = a.frame;
      w = b;
      return { cmpFrame: u, isCrossDomainCmp: w };
    }
    function G() {
      var a = H("gpp"),
        b = a.isCrossDomain;
      m = a.frame;
      q = b;
      return { gppFrame: m, isCrossDomainGpp: q };
    }
    function H(a) {
      if (!b && ((a = S("__" + a + "Locator")), a.frameRef))
        var b = a.frameRef,
          c = a.isCrossDomain;
      return { frame: b, isCrossDomain: c };
    }
    function x() {
      I("__tcfapi");
      I("__gpp");
    }
    function y(a, b) {
      var c = a.api,
        d = a.frame,
        e = a.command,
        f = a.callback,
        p = a.parameter,
        g = "__gpp" === c;
      c += "Call";
      var h = window,
        L = g ? J : K;
      h.removeEventListener
        ? h.removeEventListener("message", L, !1)
        : h.detachEvent && h.detachEvent("onmessage", L);
      h = window;
      g = g ? J : K;
      h.addEventListener
        ? h.addEventListener("message", g, !1)
        : h.attachEvent && h.attachEvent("onmessage", g);
      g = {};
      e = ((g[c] = { command: e, callId: z, parameter: p }), g);
      A[z] = "function" === typeof f ? f : b;
      z++;
      d.postMessage(e, "*");
    }
    function J(a) {
      if (
        (a =
          a.data &&
          "string" === typeof a.data &&
          -1 < a.data.indexOf("__gppReturn")
            ? JSON.parse(a.data)
            : a.data) &&
        a.__gppReturn &&
        a.__gppReturn.callId &&
        ((a = a.__gppReturn), A.hasOwnProperty(a.callId))
      )
        A[a.callId](a.returnValue);
    }
    function B(a, b) {
      var c = a.api,
        d = a.frame,
        e = a.command,
        f = a.callback,
        p = a.parameter,
        g = "__gpp" === c,
        h = g ? q : w;
      (c = d && !h ? d[c] : window[c]) &&
        (g
          ? T({
              __api: c,
              command: e,
              callback: f,
              parameter: p,
              resultCallback: b,
            })
          : U({ __api: c, command: e, callback: f }));
    }
    function T(a) {
      var b = a.__api,
        c = a.command,
        d = a.callback,
        e = a.parameter,
        f = a.resultCallback;
      r(function () {
        d ? b(c, d) : f(b(c, d, e));
      });
    }
    function U(a) {
      var b = a.__api,
        c = a.command,
        d = a.callback;
      r(function () {
        b(c, null, d);
      });
    }
    function I(a) {
      var b = "__gpp" === a,
        c = b ? m : u;
      (b ? q : w) && c && c.postMessage
        ? y({
            api: a,
            frame: c,
            command: "addEventListener",
            callback: b ? M : null,
          })
        : B({
            api: a,
            frame: c,
            command: "addEventListener",
            callback: b ? M : N,
          });
    }
    function M(a) {
      a &&
        ("sectionChange" === a.eventName ||
          (a.pingData && "loaded" === a.pingData.cmpStatus)) &&
        ((a = m),
        q && a && a.postMessage
          ? y({ api: "__gpp", frame: a, command: "getGPPData", callback: O })
          : B({ api: "__gpp", frame: a, command: "getGPPData", callback: O }));
    }
    function K(a) {
      var b = a.data;
      "string" === typeof b &&
        (b = r(function () {
          return window.JSON.parse(b);
        }));
      b && (b = (b.__tcfapiReturn || {}).returnValue);
      b &&
        null != b.gdprApplies &&
        ((a = b),
        N({
          gdprApplies: a.gdprApplies,
          tcString: a.tcString,
          purpose: a.purpose,
          vendor: a.vendor,
          restrictions: a.restrictions,
          eventStatus: a.eventStatus,
        }));
    }
    function N(a) {
      if ((a = void 0 === a ? {} : a) && "cmpuishown" !== a.eventStatus) {
        var b = P(a.gdprApplies),
          c = n("Adform", {});
        c.gdpr = b;
        c.gdpr_consent = a.tcString;
        if ((b = !(!a.purpose || !a.vendor) || 0 === b)) {
          var d = a;
          a = d.gdprApplies;
          var e = t(d, "purpose.consents.1", !1),
            f = t(d, "vendor.consents.50", !1);
          d = t(d, "restrictions.1.50", 1);
          a = 0 === P(a) ? !0 : e && f && 0 !== d;
          c.adform_consent = a;
        }
        a = c.gdpr;
        e = c.gdpr_consent;
        f = c.adform_consent;
        d = c.gpp;
        c = c.gpp_sid;
        if (void 0 !== f && b)
          for (; k.length; )
            k.shift()({
              gdpr: a,
              gdpr_consent: e,
              adform_consent: f,
              gpp: d,
              gpp_sid: c,
            });
        for (; l.length; )
          l.shift()({
            gdpr: a,
            gdpr_consent: e,
            adform_consent: f,
            gpp: d,
            gpp_sid: c,
          });
      }
    }
    function O(a) {
      if ((a = void 0 === a ? {} : a)) {
        var b = q,
          c = m,
          d = n("Adform", {});
        a &&
          ((d.gpp = a.gppString),
          (d.gpp_sid = a.applicableSections && a.applicableSections.join(",")));
        if (a && a.sectionList && 0 <= v(a.sectionList, 2))
          b && c && c.postMessage
            ? y({
                api: "__gpp",
                frame: c,
                command: "getSection",
                callback: Q,
                parameter: "tcfeuv2",
              })
            : B(
                {
                  api: "__gpp",
                  frame: c,
                  command: "getSection",
                  parameter: "tcfeuv2",
                },
                Q
              );
        else {
          void 0 === d.adform_consent && (d.adform_consent = !0);
          a = d.gdpr;
          b = d.gdpr_consent;
          c = d.adform_consent;
          var e = d.gpp;
          for (d = d.gpp_sid; k.length; )
            k.shift()({
              gdpr: a,
              gdpr_consent: b,
              adform_consent: c,
              gpp: e,
              gpp_sid: d,
            });
          for (; l.length; )
            l.shift()({
              gdpr: a,
              gdpr_consent: b,
              adform_consent: c,
              gpp: e,
              gpp_sid: d,
            });
        }
      }
    }
    function Q(a) {
      var b = n("Adform", {}),
        c = !!(a && a.PurposeConsents && a.VendorConsents);
      if (c) {
        var d = t(a, "PurposeConsents.1", !1),
          e = 0 <= v(a.VendorConsents, 50) || !1;
        a = t(a, "PublisherRestrictions.1.50", 1);
        b.adform_consent = d && e && 0 !== a;
      }
      d = b.gdpr;
      e = b.gdpr_consent;
      a = b.adform_consent;
      var f = b.gpp;
      b = b.gpp_sid;
      if (void 0 !== a && c)
        for (; k.length; )
          k.shift()({
            gdpr: d,
            gdpr_consent: e,
            adform_consent: a,
            gpp: f,
            gpp_sid: b,
          });
      for (; l.length; )
        l.shift()({
          gdpr: d,
          gdpr_consent: e,
          adform_consent: a,
          gpp: f,
          gpp_sid: b,
        });
    }
    function P(a) {
      if ("1" == a) return 1;
      if ("0" == a) return 0;
    }
    function v(a, b) {
      var c = a.length;
      if (a.indexOf) return a.indexOf(b);
      for (; c-- && a[c] !== b; );
      return c;
    }
    function t(a, b, c) {
      b = b.split(".");
      for (var d = 0; d < b.length; d++)
        if (((a = a[b[d]]), void 0 === a)) {
          a = c;
          break;
        }
      return a;
    }
    var n = function (a, b) {
        var c,
          d,
          e = D(window.top);
        for (c = e.length; c--; )
          try {
            if ((d = e[c]) && (d = d[a]) && (d = d.shared)) return d;
          } catch (f) {}
        return (window[a].shared = b);
      },
      r = function (a) {
        try {
          return a();
        } catch (b) {}
      },
      S = function (a) {
        for (var b, c, d = window; d; ) {
          if (
            r(function () {
              return d.frames[a];
            })
          ) {
            b = d;
            break;
          }
          if (d === V) break;
          d = d.parent;
        }
        b &&
          (c = !r(function () {
            return !!b.document.getElementById;
          }));
        return { frameRef: b, isCrossDomain: c };
      },
      V = window.top,
      R = window.setTimeout,
      u,
      w,
      m,
      q,
      A = {},
      z = 1,
      l = [],
      k = [],
      C = (window.Adform = window.Adform || {});
    C.getConsent = function () {
      x();
      var a = n("Adform", {});
      return {
        gdpr: a.gdpr,
        gdpr_consent: a.gdpr_consent,
        gpp: a.gpp,
        gpp_sid: a.gpp_sid,
      };
    };
    C.waitForConsent = E;
    C.hasConsent = function (a) {
      E(
        function (b) {
          a(null === b ? !0 : b.adform_consent);
        },
        1e4,
        !0
      );
    };
    F();
    G();
    n("Adform", {});
    x();
    return window.Adform;
  });
  a(L, [c], function (B) {
    function C(a) {
      B.window.adfjsonbanners.push(a);
    }
    function v(a) {
      var c,
        d,
        e,
        f = a.queue.length,
        b,
        k = a.queue,
        g = a.ready;
      for (c = 0; c < f; c++) {
        var h = k[c];
        for (d = 0; d < g.length; d++)
          if ((e = g[d]) && e.seqNo == h.seqNo) {
            e.xId = h.xId;
            for (b = 0; b < w.length; b++) delete e[w[b]];
            h.callback(e);
            k[c] = !1;
            g[d] = !1;
            break;
          }
      }
      a.queue = x(k, Boolean);
      a.ready = x(g, Boolean);
      a.ready.length || (a.empty = !0);
    }
    function x(a, c, d) {
      var e = 0,
        f = a.length;
      d = d || null;
      if (a.filter) var b = a.filter(c, d);
      else for (b = []; e < f; e++) c.call(d, a[e], e, a) && b.push(a[e]);
      return b;
    }
    var w = ["csImpressionUrl", "externalScripts", "trackingPixelUrls"];
    return {
      load: function (a, c, d, e) {
        var f,
          b = a.sync[c],
          k = b && b.loading;
        if (b) {
          for (f = 0; f < k.length; f++) {
            var g = k[f];
            var h,
              m = g,
              n = d;
            if (m.indexOf) var p = m.indexOf(n);
            else {
              for (h = m.length; h-- && m[h] !== n; );
              p = h;
            }
            if (-1 == p) {
              var r = !0;
              break;
            }
          }
          if (r) var l = !1;
          else (l = !0), (g = []), k.push(g);
        } else
          (b =
            a.sync[c] =
            a.sync[1001] =
              { queue: [], loading: [[]], ready: [] }),
            (l = !0),
            (g = b.loading[0]);
        b.queue.push({ seqNo: d, xId: e, callback: C });
        if (b.ready.length)
          for (f = 0; f < b.ready.length; f++) {
            var q = b.ready[f];
            if (q.seqNo == d) {
              v(b);
              l = !1;
              break;
            } else l = !0;
          }
        else b.empty && ((l = !0), (b.empty = !1));
        (l || g.length) && g.push(d);
        return l;
      },
      run: function (a, c) {
        var d = a.banner,
          e = d.innerBanners,
          f = e.length,
          b = c.loading;
        c.ready = c.ready || [];
        b.splice(0, 1);
        b.length || c.loading.push([]);
        for (var k = 0; k < f; k++) {
          var g = k + 1;
          var h = { seqNo: g };
          for (var m in a)
            if (a.hasOwnProperty(m))
              if ("banner" == m) {
                var n = (h.banner = {});
                for (var p in d) "innerBanners" != p && (h.banner[p] = d[p]);
                var r = e[k];
                for (var l in r) n[l] = r[l];
                n.id = d.id;
                n.innerBannerId = r.id;
                n.asset && (n.isRMB = !0);
              } else h[m] = a[m];
          c.empty = !1;
          c.ready.push(h);
        }
        var q = c.ready,
          t,
          u,
          y,
          z;
        for (t = 0; t < q.length; t++)
          if ((z = (y = e[t].floating) && y.fromBannerId))
            for (u = 0; u < q.length; u++)
              if (e[u].id == z) {
                var A = {};
                q[t]._floatFromLink = A;
                q[u]._floatFromLink = A;
                break;
              }
        v(c);
      },
    };
  });
  a(ha, [c, b], function (k, d) {
    d.$hash();
    var c = k.window,
      g = c.navigator,
      e = c.screen,
      f = c.document,
      m = (function () {
        try {
          return c.top.location.href.split("#")[0];
        } catch (l) {}
        try {
          var a = d.asyncFrame || c,
            b = a.location && a.location.ancestorOrigins;
          return (b && b[b.length - 1]) || a.document.referrer;
        } catch (l) {}
      })(),
      n = d.accTop
        ? { flags: "" === c.top.document.title ? 2 : 0, mask: 2 }
        : { flags: 0, mask: 0 },
      h = (function () {
        var a = f.documentElement,
          b = f.body;
        return {
          w: c.innerWidth || (a && a.clientWidth) || (b && b.clientWidth),
          h: c.innerHeight || (a && a.clientHeight) || (b && b.clientHeight),
        };
      })();
    return {
      set: (function (a) {
        var b = g.browserLanguage || g.language || 0;
        return [
          encodeURIComponent(g.systemLanguage || b),
          encodeURIComponent(b),
          e ? e.width + "X" + e.height : 0,
          "",
          50 * Math.round(a.w / 50),
          50 * Math.round(a.h / 50),
          e ? e.colorDepth : 0,
          8,
          3,
          7,
          d.accTop ? 0 : 1,
        ].join("|");
      })(h),
      windowSize: h,
      pageUrl: m,
      fd: n,
      isPrerenderState: function () {
        return "prerender" == f[d.visibilityStateProp] || f.prerendering;
      },
    };
  });
  a(da, [c, b], function (l, m) {
    function e(a) {
      var c = a.doc || (a.parent ? a.parent.ownerDocument : n),
        d = a.style,
        b = c.createElement("iframe"),
        f;
      for (f in k) b.setAttribute(f, k[f]);
      d && b.setAttribute("style", d);
      a.src && b.setAttribute("src", a.src);
      if (a.html)
        if (m.iframeSandbox)
          b.setAttribute(
            "srcdoc",
            "<!DOCTYPE html><html><head><title>ad</title></head><body>" +
              a.html +
              "</body></html>"
          ),
            g(b, a, c);
        else {
          g(b, a, c);
          var p = a.html,
            h = b.contentDocument || b.contentWindow.document;
          h.open();
          h.write(
            "<!DOCTYPE html><html><head><title>ad</title></head><body>" +
              p +
              "</body></html>"
          );
          h.close();
        }
      else g(b, a, c);
      return b;
    }
    function g(a, c, d) {
      if (c.parent)
        c.referenceNode
          ? c.parent.insertBefore(a, c.referenceNode)
          : c.parent.appendChild(a);
      else if (d.body) d.body.appendChild(a);
      else if (d.documentElement) {
        var b = d.createElement("body");
        b.appendChild(a);
        d.documentElement.appendChild(b);
      }
    }
    var n = l.window.document,
      k = {
        scrolling: "no",
        frameborder: "0",
        marginwidth: "0",
        marginheight: "0",
        hspace: "0",
        vspace: "0",
        allowtransparency: "true",
        allowfullscreen: "true",
        webkitallowfullscreen: "true",
        mozallowfullscreen: "true",
        width: "1",
        height: "1",
      };
    return {
      createIframe: e,
      createFriendlyIframe: function (a, c, d, b) {
        return e({ parent: a, html: c, style: d, referenceNode: b });
      },
      createCrossDomainIframe: function (a, c, d) {
        return e({ src: a, style: c, doc: d });
      },
    };
  });
  a(
    E,
    [c, i, fa, ba, ea, ga, e, L, ha, K, da],
    function (D, k, v, O, E, P, F, Q, r, G, R) {
      function w() {
        if (x) return x;
        this.banners = {};
        this.compoundBanners = {};
        try {
          t.body ||
            t.write(
              '<html><body style="margin:0px;padding:0px;overflow:hidden;"></body></html>'
            );
        } catch (a) {}
        this.settings = r.set;
      }
      function S(a, c) {
        var b = new E(a, "&"),
          d = b.get("gdpr"),
          f = b.get("gdpr_consent"),
          h = b.get("gpp");
        "0" == d || f || h
          ? c(a)
          : F.waitForConsent(function (e) {
              if (e) {
                if (e.gdpr || e.gdpr_consent)
                  b.set("gdpr", e.gdpr),
                    b.set("gdpr_consent", e.gdpr_consent || "");
                if (e.gpp || e.gpp_sid)
                  b.set("gpp", e.gpp || ""), b.set("gpp_sid", e.gpp_sid || "");
                c(b.toString());
              } else c(a);
            });
      }
      function T(a, c) {
        var b = [[[a], 0]];
        return function (d) {
          var f, h;
          for (d && (b = 0); !f && b; )
            if ((h = b[0])) {
              var e = h[0];
              var l = h[1]++;
              if (l < e.length) {
                try {
                  var p = ((f = e[l]) && f.frames) || [];
                  e[l] == c
                    ? (f = 0)
                    : f.Adform.ADFCommonUtilInstance.getRotSeed.call;
                } catch (y) {
                  (f = 0), (p = p || []);
                }
                b.unshift([p, 0]);
                p = 0;
              } else b.shift();
            } else b = 0;
          return f && f.Adform.ADFCommonUtilInstance;
        };
      }
      function H(a) {
        return v.random(a + this.id);
      }
      function I(a) {
        for (
          var c = a.geoLocation || {},
            b = [],
            d = 0,
            f = ["country", "region", "city"],
            h = f.length;
          d < h;
          d++
        ) {
          var e;
          (e = c[f[d]]) && "undefined" !== typeof e.id && b.unshift(e.id);
        }
        return 3 == b.length ? b.join(";") : m.ADFGeoData;
      }
      function J(a, c, b, d) {
        "string" == typeof c &&
          ((c = c.split(";")),
          3 == c.length &&
            (new z().src =
              a +
              "/jsmetrics/?sid=" +
              c[2] +
              "&rid=" +
              c[1] +
              "&cid=" +
              c[0] +
              b +
              (d ? "&deviceType=" + d : "")));
      }
      var x,
        n,
        A,
        m = D.window,
        t = m.document,
        z = m.Image,
        U = G.hop,
        B = G.now,
        K = R.createCrossDomainIframe,
        V = O.loadResource,
        L = m.encodeURIComponent,
        g = w.prototype;
      _adform = m._adform || [];
      if (k.ADFBannerUtils) return k.ADFBannerUtils;
      g.createBanner = function (a, c) {
        var b = this.getTagID(),
          d = this.addNewBanner(b, "undefined" == typeof k.ADFIframe ? 0 : 1),
          f = a;
        if ("undefined" != typeof a.URL) {
          var h = (h = r.pageUrl) ? L(h) : a.CREFURL;
          f = new E(a.URL);
          f.append.push("&CREFURL=" + h);
          f.CREFURL = h;
          f.BSURL = a.BSURL;
          f.BSDATA = a.BSDATA;
          f.BN = a.BN;
          f.READ_CONSENT = a.READ_CONSENT;
        }
        var e = (d.params = f),
          l = parseInt(e.get("compoundSeqNo"), 10),
          p = e.get("unloadid"),
          y = e.BN,
          M,
          C = !0,
          u = e.BSURL,
          W = e.READ_CONSENT;
        e.tracks && (d.OOBClickTracks = e.tracks);
        e.get("singleTag") &&
          ((d.singleTag = !0), (l = l || 1), e.set("compoundSeqNo", l));
        r.isPrerenderState() && e.set("prerender", 1);
        var X = this.getRotSeed();
        l &&
          ((d.compoundSeqNo = l),
          (C = Q.load(X, y, l, b)) ||
            t.write('<div id="+ADFP' + b + '"></div>'));
        (M = e.get("compoundImpr"))
          ? e.set("compoundImpr", 1)
          : 0 === M && D.log("sync_copy", y, 1);
        e.set("js", 1);
        e.set("adfxid", b);
        e.set(
          Math.floor(11e3 * Math.random()) + ";set",
          this.settings + "|" + P()
        );
        k.CDNHost && e.set("cdnhost", L(k.CDNHost));
        if (W) {
          var q = F.getConsent();
          e.set("cmpgdpr", void 0 == q.gdpr ? "" : q.gdpr);
          e.set(
            "cmpgdprconsent",
            void 0 == q.gdpr_consent ? "" : q.gdpr_consent
          );
          e.set("cmpgpp", void 0 == q.gpp ? "" : q.gpp);
          e.set("cmpgpp_sid", void 0 == q.gpp_sid ? "" : q.gpp_sid);
        }
        var N = r.fd;
        e.set("fd", N.flags + "|" + N.mask);
        e.get("studioid") && ((d.syncMembersCount = 1), (C = !0));
        p &&
          (e.set("unloadid", v.randomizeId(p)),
          e.set("cpbu", 1),
          u && (u = u.replace(p, e.get("unloadid"))));
        var Y = e.toString();
        u ? c(u, e) : C && V(Y);
        return d;
      };
      g.addNewBanner = function (a, c) {
        return (this.banners[a] = { id: a, type: c, adfserveLoadTime: B() });
      };
      g.copyBanner = function (a, c) {
        var b,
          d = this.banners[a];
        if ((d = (d && d.params) || null)) {
          d = d.copy();
          for (b in c) U(c, b) && d.set(b, c[b]);
          d = this.createBanner(d);
        }
        return d;
      };
      g.wipeOutBanner = function (a) {
        var c = this.banners[a];
        c &&
          (n && ((n.id = v.random()), n.compound && delete n.compound[c.bn]),
          delete this.compoundBanners["c" + c.bn],
          delete this.banners[a]);
      };
      g.addBannerAttribute = function (a, c, b) {
        var d = this.banners[a];
        d && (d[c] = b);
      };
      g.getBannerAttribute = function (a, c) {
        var b = this.banners[a];
        return b && b[c];
      };
      g.getTagID = function () {
        var a = this.getRotSeed();
        a.xId || (a.xId = 0);
        return ++a.xId + "x";
      };
      g.getRotSeed = function () {
        if (!n && !A) {
          A = !0;
          var a = T(m.top, m);
          var c = a();
          a(!0);
          c && (n = c.getRotSeed());
          n
            ? (n.gen = H)
            : (n = { sync: {}, compound: {}, id: v.random(), gen: H });
        }
        A = !1;
        return n;
      };
      g.getWin = function () {
        return r.windowSize;
      };
      g.getSettings = function () {
        return this.settings;
      };
      g.firePixel = function (a) {
        ("undefined" == typeof z ? t.createElement("img") : new z()).src = a;
      };
      g.fireTargAdPixel = function (a) {
        var c = this.TargAd || {};
        c[a] ||
          (((this.TargAd = c)[a] = !0),
          (a = a
            .replace("{gmtr}", Math.floor(9999999999 * Math.random()))
            .replace("{gmttzd}", new Date().getTimezoneOffset())),
          this.firePixel(a));
      };
      g.setBannerRegisteredStatus = function (a) {
        var c = B(),
          b = c - a.adfserveLoadTime,
          d = parseInt(a.serverTime, 10),
          f = k.ADFEventsInstance;
        a._host = k.host;
        a.adfserveLoadTime = b;
        d &&
          ((d += Math.round(0.5 * b)),
          (a.serverTime = d),
          (a.timeDiff = d - c));
        a.registered = 1;
        a.hash = this.getRotSeed().id;
        this.sendLoadMetrics(a);
        try {
          f && f.register(a);
        } catch (h) {}
      };
      g.getPropByBn = function (a, c) {
        var b,
          d = this.banners;
        for (b in d) {
          var f = d[b];
          if (f.bn == c && a in f) return f[a];
        }
      };
      g.now = B;
      g.getAdfscript = function (a) {
        var c,
          b,
          d = /\/adfscript/,
          f = k.ADFIframe && {
            src: m.location.href.replace(/cpjs=2/, "cpjs=0"),
          };
        if (!f) {
          var h = t.getElementsByTagName("script");
          for (c = h.length; c-- && !f; )
            (b = h[c]).src &&
              b.src.match(d) &&
              -1 < b.src.indexOf(a) &&
              (f = b);
        }
        return f || {};
      };
      g.sendLoadMetrics = function (a) {
        var c =
            (k.shost || "").split("/")[0] +
            "//" +
            "s1.adform.net/mink/650/s1.adform.net/load".replace("/load", "") +
            "/bootstrap.js",
          b = m.performance,
          d = b && b.getEntriesByName && b.getEntriesByName(c),
          f = d && d[0] && d[0].duration,
          h = I(a),
          e = a.deviceType || m.ADFDeviceType;
        if (!a.metricsSent && 0.1 > Math.random()) {
          var l =
            "&adfserve=" +
            a.adfserveLoadTime +
            (f ? "&asset=" + parseInt(f, 10) : "");
          J(k.host, h, l, e);
        }
        a.metricsSent = !0;
      };
      g.sendVideoMetrics = function (a, c) {
        var b = this.banners[a],
          d = I(b),
          f = b.deviceType || m.ADFDeviceType;
        0.3 > Math.random() && J(k.host, d, "&video=" + c, f);
      };
      g.loadFrame = K;
      g.loadTrackingIframes = function (a) {
        var c = this.getRotSeed();
        if (a && a.length && !c.framesLoaded) {
          c.framesLoaded = !0;
          for (var b = a.length; b--; )
            S(a[b], function (d) {
              K(d, "display:none");
            });
        }
      };
      k.ADFCommonUtilInstance = x = new w();
      return (k.ADFBannerUtils = w.getInstance = w);
    }
  );
  a(u, [c, b], function (c, d) {
    return function (a, e) {
      var b = c.window,
        f = b.navigator,
        g = b.Image;
      try {
        d.hasBeacon ? f.sendBeacon(a, "") : (new (e || b).Image().src = a);
      } catch (h) {
        (new g().src = a), c.log("beacon_failure", h + "_" + a, 0.1, "info");
      }
    };
  });
  a(Z, [c, i, E, u], function (q, c, y, z) {
    var r = Object.prototype.hasOwnProperty,
      A = q.window.document,
      g = {
        Initialized: !1,
        InitTime: new Date().getTime(),
        Host:
          c.host ||
          ("https:" == A.location.protocol ? "https://" : "http://") +
            "track.adform.net",
        callbacks: [],
        sendEvent: function (b, a, d, t, u) {
          var v,
            n = Math.round((new Date().getTime() - this.InitTime) / 1e3),
            k = B.banners[b] || {},
            e = k.banner || {},
            C = k.publisher || {},
            w = k.dsp || {},
            x = c.adRegister && c.adRegister[b];
          try {
            this.notifyAboutEvent.apply(this, arguments);
          } catch (E) {}
          if (!e.tagId && x) var f = x.sendEvent(a, d, t, u);
          else if (e && e.isEventEnabled) {
            var D = e.tagId;
            var p = [
              "bn",
              D,
              "event",
              a,
              "time",
              (0 > n ? 0 : n) + "",
              "baid",
              e.id,
              "innerbanner",
              e.innerBannerId,
              "asid",
              d,
              "name",
              t,
              "imprid",
              k.interactionId,
              "eData",
              k.eData,
              "adxvars",
              C.adxvars,
              "rtbdata",
              w.rtbdata,
              "rtbwp",
              w.rtbwp,
              "rnd",
              Math.floor(1e9 * Math.random()),
            ];
            var l = 0;
            for (f = []; l < p.length; l += 2)
              (v = p[l + 1]) && f.push(p[l] + "=" + encodeURIComponent(v));
            f =
              (c.host || this.Host) +
              "/Serving/Event/?" +
              f.join("&") +
              (u || "");
            86400 > n && z(f);
          }
          return f;
        },
        Initialize: q.deprecate(
          function () {
            this.Initialized = !0;
          },
          "initEvents",
          1
        ),
        registerCallback: function (b, a) {
          "function" == typeof b && this.callbacks.push([b, a]);
        },
        unregisterCallback: function (b) {
          var a = this.callbacks,
            d = a.length;
          if ("function" == typeof b)
            for (; d--; ) a[d][0] == b && a.splice(d, 1);
        },
        notifyAboutEvent: function () {
          for (var b = this.callbacks.slice(), a = 0, d = b.length; a < d; a++)
            b[a][0].apply(b[a][1] || this, arguments);
        },
      },
      B = y(),
      h = c.Events;
    if (h) {
      for (var m in g) r.call(g, m) && !r.call(h, m) && (h[m] = g[m]);
      h.sendEvent = g.sendEvent;
    } else h = c.Events = g;
    c.ADFEvents2 || (c.ADFEvents2 = h);
    return g;
  });
  a(x, [i], function (l) {
    function g() {}
    function h(b) {
      b
        ? this._events && this._events[b] && delete this._events[b]
        : delete this._events;
      return this;
    }
    function k(b) {
      var a = this._events;
      a || (this._events = a = {});
      return a[b] || (a[b] = []);
    }
    var m = Array.prototype.slice,
      f = g.prototype;
    l.RMB.EventEmitter = g;
    f.emit = function (b) {
      var a,
        c,
        d = this._events;
      if (d && (d = d[b]) && (c = d.length)) {
        var e = m.call(arguments, 1);
        d = d.slice();
        for (a = 0; a < c; a++) d[a].apply(this, e);
      }
      return this;
    };
    f.on = function (b, a) {
      this.emit("newListener", b, a);
      k.call(this, b).push(a);
      return this;
    };
    f.once = function (b, a) {
      var c = function () {
        return a.apply(this.off(b, c), arguments);
      };
      c._oncep = a;
      return this.on(b, c);
    };
    f.off = function (b, a) {
      var c,
        d = this._events,
        e = d && d[b];
      if (e) {
        for (c = e.length; c--; )
          (e[c] != a && e[c]._oncep != a) || e.splice(c, 1);
        e.length || h.call(this, b);
        this.emit("removeListener", b, a);
      }
      return this;
    };
    f.clear = h;
    f.list = k;
    return g;
  });
  a(y, [c], function (y) {
    function m(f, g) {
      for (var e in g)
        g.hasOwnProperty(e) &&
          ("object" == typeof g[e]
            ? ("object" != typeof f[e] && (f[e] = {}), m(f[e], g[e]))
            : (f[e] = g[e]));
    }
    var u = y.window,
      E = u.parent,
      v = {
        useClose: "expImage.useClose",
        overlay: "overlay",
        wallpaper: "options.wallpaper",
        x: "options.x",
        y: "options.y",
        hidden: "options.hidden",
        position: "options.position",
        adNotice: "options._adNotice",
        fixedBounding: "options.fixedBounding",
        resizeInFIF: "options.iabResize",
        panel: "panel",
        responsive: "options.responsive",
        testPlace: "options.testPlace",
      };
    return function (f, g) {
      var e,
        c,
        n,
        p,
        z,
        q,
        l,
        b = f.options,
        A = b.bn;
      try {
        var d = ((b.iab ? E : u)._adform || []).slice(0);
      } catch (B) {
        d = [];
      }
      var F = /(?:(\d+x|\d+#\d+|#[-_0-9a-z]+|\d+))?\.?(.*)/i,
        r = {};
      b.iab && d.push.apply(d, u._adform || []);
      b.multiPanel &&
        ("string" == typeof b.multiPanel &&
          (b.multiPanel = Function("return (" + b.multiPanel + ")")()),
        d.push.apply(d, b.multiPanel));
      if ((l = (b.userParams || {})._adform))
        try {
          if ((l = Function("return (" + l + ")")()) && "object" == typeof l)
            (d = d || []).push([b.xId, l]);
          else throw Error("_adform from userParams should be an object");
        } catch (B) {
          y.rethrow(B, "user_params");
        }
      if ("[object Array]" == Object.prototype.toString.call(d) && d.length) {
        var t = g || ["", A, "#" + b.seqNo, A + "#" + b.seqNo, b.xId];
        var a = 0;
        var C = t.length;
        for (z = d.length; a < C; a++) r[t[a]] = {};
        for (a = 0; a < z; a++) {
          var w = d[a][0].match(F);
          if ((e = r[w[1] || ""])) {
            var h = d[a][1];
            if (w[2]) {
              var k = w[2].split(".");
              for (n = c = {}; 1 < k.length; ) c = c[k.shift()] = {};
              c[k[0]] = h;
              h = n;
            }
            if ((p = h.on))
              for (q in p) {
                if ("function" == typeof p[q]) f.events.on(q, p[q]);
              }
            else if (h.init) f.events.on("init", h.init);
            var D = {};
            for (c in h) v[c] && (D[c] = h[c]);
            m(e, D);
          }
        }
        var x = r[t[0]];
        for (a = 1; a < C; a++) m(x, r[t[a]]);
        for (a in v)
          if (a in x) {
            k = v[a].split(".");
            for (n = c = {}; 1 < k.length; ) c = c[k.shift()] = {};
            c[k[0]] = x[a];
            m(f, n);
          }
      }
    };
  });
  a(ca, [c, b, x, y, u, da], function (l, w, G, H, I, J) {
    function K(a, c, b) {
      var e = w.iframeSandbox ? a : "<script>inFIF=true;\x3c/script>" + a,
        h = f.getElementById(b);
      if (h) {
        var d = x(
          h.parentNode,
          e,
          "width:" + c.width + "px;height:" + c.height + "px;",
          h
        );
        d.id = b + "-iframe";
      } else (d = x(f.body, e, "width:" + c.width + "px;height:" + c.height + "px;")), (d.id = b);
      d.className = "adf-iframe";
    }
    function L(a, c) {
      var b = f.createElement("div");
      b.innerHTML = a;
      var e = b.firstChild;
      e.innerHTML = c;
      return e.firstChild && 1 == e.firstChild.nodeType ? b.innerHTML : c;
    }
    var q = l.window,
      f = q.document,
      x = J.createFriendlyIframe;
    return function (a) {
      function c(g) {
        y(["3rdparty/vendor/Adform"], function (m) {
          m(a, g);
        });
      }
      var b = a.csImpressionUrl,
        e = !w.isOMID,
        h = (q._adform = q._adform || []),
        d = { options: a, events: new G() };
      H(d, [a.banner.tagId]);
      try {
        d.events.emit("setup", d);
      } catch (g) {
        l.rethrow(g, "setup");
      }
      var r = (a.placeId = "+ADFP" + a.xId),
        t = a.banner.vendorName,
        z = a.banner.vendorCreativeId,
        k = ["types/ThirdParty"],
        y = l.require,
        A = a.banner.dsa || {},
        B = !(!a.$tag && "loading" === f.readyState),
        M = "ias" === (a.params || {}).BSDATA;
      f.getElementById(r) ||
        B ||
        f.write('<i id="' + r + '" style="display:none"></i>');
      A.dsaBuyerRenderRequired && k.push("3rdparty/adNotice");
      t && k.push("3rdparty/vendor/" + t);
      "Adform" == t && z && h.push([z + ".on.setup", c]);
      y(k, function (g) {
        g(a, d);
        for (
          var m = ["Adnami", "Seenthis"],
            N = [].slice.call(arguments),
            n = {},
            u,
            p = 0;
          p < k.length;
          p++
        )
          (u = k[p].split("/")), (n[u[u.length - 1]] = N[p]);
        A.dsaBuyerRenderRequired && n.adNotice(a.banner);
        for (var v = 0; v < m.length; v++) {
          var C = m[v];
          if (n[C]) n[C](a);
        }
      });
      var D = a.banner.script,
        O = a.banner.size,
        E = a.wrapper,
        F = E ? L(E, D) : D;
      try {
        B || M ? K(F, O, r) : f.write(F);
      } catch (g) {
        l.rethrow(g, "thirdPartyWrite");
      }
      b && e && I(b);
    };
  });
  a(ia, [c, b], function (h, k) {
    function C(a) {
      for (var f, b = 0; b < a.length; b++)
        if ("politeSrc" === a[b].name) {
          f = a[b];
          break;
        }
      return f;
    }
    var p = h.window,
      c = p.document,
      D = p.setTimeout;
    k.$hash();
    return function (a) {
      var f = new Date(),
        b = k.isIE && 10 > k.ieVersion,
        g = a.banner,
        E = g.assets || [],
        q = g.type,
        e = q.type,
        r = q.subType,
        F = a.xId,
        t = (g.properties || {}).pushdown,
        u = g.size || {},
        v =
          { standard: 1, expanding: 1, singleExpanding: 1 }[e] &&
          ![0, 0, 0, 1, 1][t],
        G = v && "loading" === c.readyState,
        w = [
          "AdConstructor",
          "types/" +
            (4 == t ? "Slider" : e.charAt(0).toUpperCase() + e.slice(1)),
        ],
        x = C(E);
      x && ((e = "polite"), (r = x.type));
      var y = ({
        standard: { image: "contents/ImageTag", html: "contents/HTML" },
        mobileInline: { html: "contents/HTML" },
        floating: { image: "contents/ImageTag", html: "contents/HTML" },
        polite: { image: "contents/ImageTag" },
      }[e] || {})[r];
      y && w.push(y);
      var l = "+ADFP" + F;
      a.$tag
        ? (a.placeId = a.$tag.id)
        : v && c.getElementById(l)
        ? (a.placeId = l)
        : G &&
          ((a.placeId = l),
          c.getElementById(a.placeId) ||
            c.write(
              '<div id="' +
                a.placeId +
                '"' +
                (a.singleTag
                  ? ""
                  : ' style="width:' +
                    u.width +
                    "px;height:" +
                    u.height +
                    'px;"') +
                '></div><i style="display:none"></i>'
            ));
      h.require(w, function z(m, A) {
        var d,
          B = a.placeId,
          n = m.cbuild,
          H = "function" !== typeof A && A;
        B
          ? a.$tag
            ? ((a.placement = a.$tag), n(a))
            : (d = c.getElementById(B) || H)
            ? ((a.placement = d.nextSibling || d.previousSibling),
              a.placement ? d.parentNode.removeChild(d) : (a.placement = d),
              n(a))
            : 1e4 > new Date() - f
            ? D(function () {
                b && a.iab ? z(m, c.body.firstChild) : z(m);
              }, 0)
            : h.rethrow("Failed to find placement", "noplacement")
          : n(a);
      });
    };
  });
  a(G, [c, b, i, E, ca, ia, L, K], function (q, C, h, D, E, F, G, u) {
    function v(b) {
      for (var a = 0, c = b.length; a < c; a++)
        try {
          w(b[a]);
        } catch (d) {
          q.rethrow(d, "json_handle");
        }
    }
    function x() {
      H.apply(this, arguments);
      v(arguments);
    }
    function w(b) {
      h.host = h.host || b.adServerUrlBase;
      h.shost =
        h.shost ||
        (b.staticContentUrl && b.staticContentUrl.replace("/Banners/", ""));
      h.scriptBase =
        h.scriptBase || (b.staticContentUrl && b.staticContentUrl + "scripts/");
      I(b);
      var a = J(b);
      K(b, a, function () {
        k.loadTrackingIframes(b.trackingIframeUrls);
        switch (a.type) {
          case "synchronized":
            var c = k.getRotSeed().sync[a.banner.tagId];
            c._loaded && q.log("multiple_sync", a.banner.tagId, 1);
            c._loaded = !0;
            var d = a.banner.innerBanners;
            a.syncMembersCount = d.length;
            G.run(b, c);
            if (a.singleTag && 1 == a.compoundSeqNo)
              for (var e = 2, l = a.syncMembersCount; e <= l; e++)
                a.copy
                  ? a.copy(e)
                  : k.copyBanner(a.xId, { compoundSeqNo: e, compoundImpr: 0 });
            else
              for (var f = 0; f < a.syncMembersCount; f++) {
                var g = f + 1;
                d[f].floating &&
                  a.compoundSeqNo != g &&
                  (a.copy
                    ? a.copy(g)
                    : k.copyBanner(a.xId, {
                        compoundSeqNo: g,
                        compoundImpr: 0,
                      }));
              }
            break;
          case "thirdparty":
            E(a);
            break;
          default:
            F(a);
        }
        var m = b.trackingPixelUrls;
        if (m)
          for (var r = 0, L = m.length; r < L; r++) k.fireTargAdPixel(m[r]);
        b.trackingPixelUrls = null;
        var y = b.externalScripts || {},
          t = y.after;
        t && t.length && (z(a, t), (y.after = []));
        (b.visibility || {}).testMode &&
          A(h.scriptBase + "unload/Adform.Inscreen.js?" + h.cache);
      });
    }
    function I(b) {
      var a = b.banner,
        c = a.type,
        d = c.type || c;
      var e = a.type,
        l = a.assets;
      var f = e.subType ? e.subType : l ? l[0].type : void 0;
      a.type = { type: d, subType: f };
    }
    function J(b) {
      var a = k.banners[b.xId] || {},
        c = b.banner;
      M(a, b);
      a.bn = a.banner.tagId;
      a.xId = a.adfxid = b.xId;
      a.type = c.type.type;
      a.iab = !(!(n.inDapMgrIf || n.inDapIF || n.inFIF) || !C.accParent);
      var d = c.size || {};
      a.width = d.width;
      a.height = d.height;
      k.setBannerRegisteredStatus(a);
      return a;
    }
    function K(b, a, c) {
      var d = b.externalScripts || {},
        e = d.before;
      e && e.length
        ? ((a._beforeScript = !0), z(a, e, c), (d.before = []))
        : c();
    }
    function z(b, a, c) {
      var d = !b.params || "ias" === b.params.BSDATA;
      var e = p.getElementById("+ADFP" + b.adfxid);
      var l = e ? e.parentNode : void 0;
      for (
        var f = "loading" != p.readyState || d ? A : B, g = 0, m = a.length;
        g < m;
        g++
      )
        g === m - 1 && c ? f(a[g], l, c) : f(a[g], l);
    }
    function A(b, a, c) {
      if ((a = a || p.body || p.head)) {
        var d = p.createElement("script");
        c &&
          ((c = N(c)),
          (d.onload = c),
          (d.onerror = c),
          (d.onreadystatechange = function () {
            ("loaded" != this.readyState && "complete" != this.readyState) ||
              c();
          }));
        d.src = b;
        a.appendChild(d);
      } else B(b, a, c);
    }
    function B(b, a, c) {
      p.write('<script src="' + b + '">\x3c/script>');
      c && c();
    }
    var M = u.assign,
      N = u.once,
      n = q.window,
      p = n.document,
      H = Array.prototype.push,
      k = D();
    return function () {
      var b = n.adfjsonbanners;
      b
        ? ((b.push = x), v(b))
        : ((b = []), (b.push = x), (n.adfjsonbanners = b));
      return w;
    };
  });
  a(aa, [c, b, ba], function (u, v, A) {
    function B(c, a, f, d) {
      var g = "ADFP" + a.get("adfxid"),
        m = "+" + g,
        k = c.replace("__ADFPAGEURL__", a.CREFURL),
        h =
          '<div class="adServerCreativeContainer" id="' +
          g +
          '"><i id="' +
          m +
          '" style="display:none"></i></div>',
        l =
          '<script src="' +
          k +
          '" data-ias-check-tag="true" data-ias-check-done="false" data-ias-container="' +
          g +
          '" data-ias-callback="' +
          d +
          '">\x3c/script>';
      if (f) {
        w(m) ? b.write(h) : b.body.insertAdjacentHTML("beforeend", h);
        var n = r(k);
        n.setAttribute("data-ias-check-tag", "true");
        n.setAttribute("data-ias-check-done", "false");
        n.setAttribute("data-ias-container", g);
        n.setAttribute("data-ias-callback", d);
        b.getElementById(g).parentNode.appendChild(n);
      } else b.write(h + l);
    }
    function C(c, a, f, d) {
      if (f) D(c, a, d);
      else {
        var g =
          '<script type="text/adtag"><script>' +
          d +
          "({block:false});</scr+ipt>\x3c/script>";
        x &&
          (g +=
            '<script type="text/passback"><script>' +
            d +
            '({block:"P"});</scr+ipt>\x3c/script>');
        b.write(g);
        t(c);
        x || b.write("<script>" + d + '({block:"F"});\x3c/script>');
      }
    }
    function D(c, a, f) {
      var d = "ADFP" + a.get("adfxid"),
        g = "+" + d,
        m = '<div id="' + d + '" style="display:none"></div>',
        k =
          '<script type="text/adtag"><i id="' +
          (g + '" style="display:none"></i>\x3c/script>');
      w(g)
        ? (b.write(m), b.write(k), t(c))
        : (b.body.insertAdjacentHTML("beforeend", m),
          b.body.insertAdjacentHTML("beforeend", k),
          E(b.body, r(c)));
      var h = +new Date() + 3e3,
        l = F(function () {
          b.getElementById(g)
            ? (y(l), e[f]({ block: !1 }))
            : +new Date() > h && (y(l), e[f]({ block: "T" }));
        }, 200);
    }
    function w(c) {
      b.write('<i id="' + c + '-test" style="display:none"></i>');
      var a = b.getElementById(c + "-test");
      a: {
        if (a)
          for (var f = a.parentNode; f && f !== b; ) {
            if (f === b.body) {
              var d = !0;
              break a;
            }
            f = f.parentNode;
          }
        d = !1;
      }
      a && a.parentNode && a.parentNode.removeChild(a);
      return d;
    }
    function r(c) {
      var a = b.createElement("script");
      a.src = c;
      return a;
    }
    function E(c, a) {
      c.appendChild(a);
    }
    function G() {
      var c = b.write;
      if (!c || !c.toString || -1 === (c + "").indexOf("[native code]"))
        return !0;
      var a = (b.constructor && b.constructor.prototype) || b.__proto__;
      return a && a.write && a.write !== c ? !0 : !1;
    }
    var e = u.window,
      b = e.document,
      t = A.loadResource,
      x = v.isIE && 10 > v.ieVersion,
      H = e.setTimeout,
      I = e.clearTimeout,
      F = e.setInterval,
      y = e.clearInterval;
    return function (c, a) {
      function f(p, J, K) {
        I(L);
        p = !!p.block;
        e[h] = K ? g : m;
        e.removeEventListener && e.removeEventListener("pagehide", d, !0);
        p && a.set("bsdata", a.BSDATA);
        var q = a.toString();
        if (J) new e.Image().src = q;
        else if (n) {
          var M = "ADFP" + a.get("adfxid"),
            z = b.getElementById(M);
          if (z) {
            var N = r(q);
            z.appendChild(N);
          } else if (b.body) {
            var O = r(q);
            b.body.appendChild(O);
          } else t(q);
        } else t(q);
      }
      function d() {
        e[h]({ block: !0 }, !0, !0);
      }
      function g(p) {
        (p && p.block) || u.log("dv_not_blocked", a.BN, 1, "info");
      }
      function m() {}
      var k = a.BSDATA,
        h = "_adform_dv_" + +new Date() + "_" + (Math.random() + "").slice(2),
        l = "loading" !== b.readyState && G() && b.body,
        n = "ias" === k || l;
      e[h] = f;
      e.addEventListener && e.addEventListener("pagehide", d, !0);
      var L = H(function () {
        e[h]({ block: !1 }, !1, !0);
      }, 5e3);
      switch (k) {
        case "1":
          C(c, a, l, h);
          break;
        case "ias":
          B(c, a, l, h);
          break;
        default:
          f({ block: !1 });
      }
    };
  });
  a(Y, [c, i, Z, E, G, aa], function (f, a, g, d, h, k) {
    function c() {
      var b = a.ADFBannerParams,
        e = b && b.length ? b.shift() : a.ADFBannerData;
      if (e)
        try {
          d().createBanner(e, k);
        } catch (l) {
          f.rethrow(l, "create_banner");
        }
      b && b.length && c();
    }
    a.ADFUtilInstance = a.ADFUtilInstance || d();
    h();
    a.ADFBanner || ((a.ADFBanner = c), a.ADFBanner());
    g.IE = 9;
    return c;
  });
  a(f, [c], function (a) {
    return a.updateIgnore("tCAJ-9CAAAAAATgAAA");
  });
})(
  _adfq.define,
  "Adform",
  "$boot",
  "h/helpers",
  "h/random",
  "bootstrap/Global",
  "bootstrap/URL",
  "$env",
  "bootstrap/isAppView",
  "consent-amd",
  "bootstrap/Compound",
  "bootstrap/impressionData",
  "h/iframe",
  "bootstrap/Utils",
  "h/beacon",
  "bootstrap/Events",
  "common/EventEmitter",
  "api/ARMA",
  "bootstrap/ThirdParty",
  "bootstrap/typeLoader",
  "bootstrap/responseHandler",
  "bootstrap/tagMeasurement",
  "bootstrap/Banner",
  "$ignore"
);
