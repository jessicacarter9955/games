(function (window) {
  if (window.dhtml) {
    return;
  }
  var h = {};
  h.inherit = aa;
  h.define = ca;
  h.gid = da;
  h.byId = ea;
  h.byTag = fa;
  h.bind = ha;
  h.extend = ia;
  h.isMouseLeave = ja;
  h.singleCall = ka;
  h.onload = la;
  h.overlap = ma;
  h.overlapElem = na;
  h.hasClass = oa;
  h.addClass = pa;
  h.removeClass = qa;
  h.loadScript = ra;
  h.loadCSS = sa;
  h.navigator = window.navigator;
  h.isTMX = ta;
  h.isolate = ua;
  var va = Array.prototype.slice;
  h.addEvent = wa;
  h.removeEvent = xa;
  var ya = "addEventListener",
    za = "removeEventListener",
    Aa = "attachEvent",
    Ba = "detachEvent";
  function da(a) {
    var b = +new Date();
    return (a || "") + (b + b * ~~(Math.random() * 1e4)).toString(36);
  }
  function aa(a, b) {
    a.super_ = b;
    Ca.prototype = b.prototype;
    a.prototype = new Ca();
    a.prototype.constructor = a;
  }
  function Ca() {}
  function ca(a, b, c) {
    c && aa(a, b);
    c(a, a.prototype);
  }
  function ia(a, b) {
    for (var c in b) b.hasOwnProperty(c) && (a[c] = b[c]);
    return a;
  }
  function ha(a, b) {
    return function () {
      return b.apply(a, arguments);
    };
  }
  function ea(a, b) {
    return (b = b || document) && b.getElementById && b.getElementById(a);
  }
  function fa(a, b) {
    var c = b ? (a.substr ? ea(a) : a) : document;
    return c ? c.getElementsByTagName(b || a) : [];
  }
  function oa(a, b) {
    return ~(" " + a.className + " ").indexOf(" " + b + " ");
  }
  function pa(a, b) {
    oa(a, b) || (a.className += " " + b);
  }
  function qa(a, b) {
    oa(a, b) &&
      ((a.className = (" " + a.className + " ")
        .replace(" " + b + " ", " ")
        .slice(1, -1)),
      qa(a, b));
  }
  var Da = /([A-Z])/g,
    Ea = /^-?\d+(?:px)?$/i,
    Fa = /^-?\d/,
    Ha = document.defaultView;
  h.curCSS =
    Ha && Ha.getComputedStyle
      ? function (a, b) {
          var c = a.ownerDocument.defaultView;
          if (c && (c = c.getComputedStyle(a, null)))
            return (
              c.getPropertyValue(b.replace(Da, "-$1").toLowerCase()) ||
              a.style[b]
            );
        }
      : document.documentElement.currentStyle &&
        function (a, b) {
          var c,
            d,
            e = a.currentStyle && a.currentStyle[b];
          if (!Ea.test(e) && Fa.test(e)) {
            var g = (d = a.style).left;
            if ((c = a.runtimeStyle && a.runtimeStyle.left))
              a.runtimeStyle.left = a.currentStyle.left;
            d.left = b === "fontSize" ? "1em" : e || 0;
            e = d.pixelLeft + "px";
            d.left = g;
            c && (a.runtimeStyle.left = c);
          }
          return e === "" ? "auto" : e;
        };
  function Ia() {
    function a() {
      return a;
    }
    var b = document.body,
      c = document.createElement("div");
    var d = [
      "position:absolute;top:0;left:0;margin:0;padding:0;border:0;width:1px;height:1px;",
    ].pop();
    c.innerHTML =
      '<div style="' +
      d +
      'visibility:hidden"><div style="' +
      d +
      'border:5px solid #000"><div style="margin:0"></div></div><div style="' +
      d +
      '"><div style="' +
      d +
      'position:fixed;top:20px;"></div></div><div style="' +
      d +
      'position:relative;border:5px solid #000;overflow:hidden"><div style="margin:0"></div></div><table style="' +
      d +
      'border:5px solid #000" cellpadding="0" cellspacing="0"><tr><td></td></tr></table></div>';
    b.insertBefore((c = c.firstChild), b.firstChild);
    d = c.childNodes;
    a.dnab = d[0].firstChild.offsetTop !== 5;
    a.sfp = d[1].firstChild.offsetTop === 20;
    a.sbfonv = d[2].firstChild.offsetTop === -5;
    a.dabftac = fa(c, "td").offsetTop === 5;
    b.removeChild(c);
    b = c = d = null;
    return (Ia = a);
  }
  var Ja = /^t(?:able|d|h)$/i;
  function Ka(a) {
    var b = a.offsetTop,
      c = a.offsetLeft,
      d,
      e = h.curCSS,
      g = e(a, "position") != "static";
    b ||
      (b =
        (parseFloat(e(a, "marginTop")) || 0) +
        (g ? parseFloat(e(a, "top")) || 0 : 0));
    c ||
      (c =
        (parseFloat(e(a, "marginLeft")) || 0) +
        (g ? parseFloat(e(a, "left")) || 0 : 0));
    g && a.getBoundingClientRect && (d = h.offset(a, !0));
    !b && d && (b = d.top);
    !c && d && (c = d.left);
    return { top: b, left: c };
  }
  h.offsetFromWindow = function (a) {
    var b = a && a.ownerDocument;
    if (!b) return null;
    var c = b.documentElement;
    if ("getBoundingClientRect" in c) {
      try {
        var d = a.getBoundingClientRect();
        var e = c.getBoundingClientRect();
      } catch (g) {}
      if (!d) return { top: 0, left: 0 };
      if (e.left > 0 || e.top > 0) (d.top -= e.top), (d.left -= e.left);
      return { top: d.top, left: d.left };
    }
    d = b.defaultView || b.parentWindow;
    e = b.body;
    if (a === b.body) return Ka(a);
    a = h.offset(a);
    b = (d && d.pageYOffset) || c.scrollTop || e.scrollTop;
    c = (d && d.pageXOffset) || c.scrollLeft || e.scrollLeft;
    a.top -= b;
    a.left -= c;
    return a;
  };
  h.offset =
    "getBoundingClientRect" in document.documentElement
      ? function (a, b) {
          var c = a && a.ownerDocument;
          if (!c) return null;
          if (!b && a === c.body) return Ka(a);
          try {
            var d = a.getBoundingClientRect();
          } catch (e) {}
          if (!d) return { top: 0, left: 0 };
          a = c.body;
          c = c.documentElement;
          return {
            top:
              d.top +
              (c.scrollTop || a.scrollTop) -
              (c.clientTop || a.clientTop || 0),
            left:
              d.left +
              (c.scrollLeft || a.scrollLeft) -
              (c.clientLeft || a.clientLeft || 0),
          };
        }
      : function (a) {
          var b = a && a.ownerDocument;
          if (!b) return null;
          if (a === b.body) return Ka(a);
          var c = a.offsetParent,
            d = b.documentElement,
            e = b.body;
          var g = (b = b.defaultView)
            ? b.getComputedStyle(a, null)
            : a.currentStyle;
          for (
            var f = a.offsetTop, k = a.offsetLeft, m = Ia();
            (a = a.parentNode) &&
            a !== e &&
            a !== d &&
            (!m.sfp || g.position !== "fixed");

          )
            (g = b ? b.getComputedStyle(a, null) : a.currentStyle),
              (f -= a.scrollTop),
              (k -= a.scrollLeft),
              a === c &&
                ((f += a.offsetTop),
                (k += a.offsetLeft),
                !m.dnab ||
                  (m.dabftac && Ja.test(a.nodeName)) ||
                  ((f += parseFloat(g.borderTopWidth) || 0),
                  (k += parseFloat(g.borderLeftWidth) || 0)),
                (c = a.offsetParent)),
              m.sbfonv &&
                g.overflow !== "visible" &&
                ((f += parseFloat(g.borderTopWidth) || 0),
                (k += parseFloat(g.borderLeftWidth) || 0));
          if (g.position === "relative" || g.position === "static")
            (f += e.offsetTop), (k += e.offsetLeft);
          m.sfp &&
            g.position === "fixed" &&
            ((f += Math.max(d.scrollTop, e.scrollTop)),
            (k += Math.max(d.scrollLeft, e.scrollLeft)));
          return { top: f, left: k };
        };
  h.client = function (a) {
    a = a.ownerDocument || a;
    var b = a.defaultView || a.parentWindow;
    var c = a.documentElement;
    var d = a.body;
    if (b.innerWidth) {
      a = b.innerWidth;
      var e = b.innerHeight;
    } else
      c
        ? ((a = c.clientWidth),
          (e = c.clientHeight),
          (a && d.clientHeight == d.offsetHeight) ||
            ((a = Math.min(a || 123456789, d.clientWidth || 123456789)),
            (e = Math.min(e || 123456789, d.clientHeight || 123456789))))
        : ((a = d.clientWidth), (e = d.clientHeight));
    return {
      left:
        (b && b.pageXOffset) || (c && c.scrollLeft) || (d && d.scrollLeft) || 0,
      top:
        (b && b.pageYOffset) || (c && c.scrollTop) || (d && d.scrollTop) || 0,
      width: a,
      height: e,
    };
  };
  function wa(a, b, c, d) {
    return a[ya]
      ? a[ya](b, c, d === void 0 ? !1 : d)
      : a[Aa]
      ? a[Aa]("on" + b, c)
      : !1;
  }
  function xa(a, b, c) {
    return a[za] ? a[za](b, c, !1) : a[Ba] ? a[Ba]("on" + b, c) : !1;
  }
  h.isArray =
    Array.isArray ||
    function (a) {
      return Object.prototype.toString.call(a) == "[object Array]";
    };
  var La = [
    ["offsetX", "offsetY"],
    ["layerX", "layerY"],
  ];
  h.getMousePos = function (a) {
    for (var b; (b = La.shift()); )
      if (typeof a[b[0]] != "undefined") {
        La = b;
        break;
      }
    b || (La = ["x", "y"]);
    h.getMousePos = Ma;
    return Ma(a);
  };
  function Ma(a) {
    var b = { relativeX: a[La[0]], relativeY: a[La[1]] };
    if (a.pageX == null && a.clientX != null) {
      var c = document.documentElement,
        d = document.body;
      b.pageX = a.clientX + ((c && c.scrollLeft) || d.scrollLeft || 0);
      b.pageY = a.clientY + ((c && c.scrollTop) || d.scrollTop || 0);
    } else (b.pageX = a.pageX), (b.pageY = a.pageY);
    return b;
  }
  function ja(a, b) {
    if (!a || a.type != "mouseout") return !0;
    a = a.relatedTarget || a.toElement;
    for (var c, d = b.length; a; ) {
      for (c = 0; c < d; c++) if (b[c] == a) return !1;
      a = a.parentNode;
    }
    return !0;
  }
  var Na = document.createElement("div");
  h.html = function (a, b) {
    b = (!b && Na) || b.createElement("div");
    b.innerHTML = a;
    return b.firstChild && b.removeChild(b.firstChild);
  };
  var Oa = h.navigator,
    Pa = Oa.vendor,
    r = Oa.userAgent,
    Qa = /Apple Computer/i.test(Pa),
    Ra = /Google/i.test(Pa),
    Sa = (h.isIPad = /iPad/i.test(r)),
    Ta = (h.isIPhone = /iPhone/i.test(r)),
    Ua = (h.isIOS = Sa || Ta),
    Va = (h.isTouch =
      "ontouchstart" in document.documentElement || "ontouchstart" in window),
    Wa = (h.isOrientation = "orientation" in window),
    Za = (h.isAndroid = !Ua && /Android/i.test(r));
  h.isAndroidApp = Za && !/^(?:Opera|Mozilla)/i.test(r);
  var $a;
  h.isIOSF = Ua && ($a = /\sos\s(\d+)_\d+/i.exec(r)) && $a[1] >> 0 > 4;
  var ab = (h.isMobile = /Mobile|Mobi|Tablet|Nokia/i.test(r) || Va),
    bb = (h.isIE = /msie|Trident/i.test(r)),
    cb = (h.isFF = /Firefox[/.]+[^\s]/i.test(r));
  h.isMACOS = /Mac OS X/i.test(r);
  if ((h.isWinPhone = bb && ab && /Phone/gi.test(r))) {
    var db = /Windows Phone (OS )?(\d+[.\d]*)/i.exec(r);
    db && db[2] && (h.winPhoneVer = parseFloat(db[2]));
  }
  var eb = (h.isOpera = /Opera/i.test(r)),
    fb = (h.isOperaMobile = /Opera\s(?!Mini)/i.test(r)),
    gb = (h.isOperaMini = /Opera\sMini/i.test(r)),
    hb = (h.isOperaWebKit = /OPR/i.test(r) && /Opera Software/i.test(Pa)),
    ib = (h.isChrome = /(Chrome|CriOS)+\/[\d.]+\s/i.test(r) && (Ua ? Qa : Ra)),
    jb = (h.isSafari =
      !/Chrome|CriOS|Skyfire/i.test(r) && /Safari+\/[.\d]+$/i.test(r) && Qa),
    kb = (h.isInternet = Za && !ib && Wa && /Safari\/[.\d]+$/i.test(r) && Ra);
  h.isEdge = /Edge\/[.\d]+$/i.test(r);
  h.isAfmaSDK = /afma-sdk/i.test(r);
  var lb = bb
    ? "msie"
    : cb
    ? "firefox"
    : fb
    ? "operaMobile"
    : gb
    ? "operaMini"
    : eb
    ? "opera"
    : hb
    ? "operaWebKit"
    : ib
    ? "chrome"
    : jb
    ? "safari"
    : kb
    ? "internet"
    : !1;
  h.browser = function () {
    return lb;
  };
  h.isIE &&
    ((h.navigator.appName == "Microsoft Internet Explorer" &&
      /MSIE (\d+[.\d]*)/i.exec(r)) ||
      /rv:(\d+[.\d]*)/i.exec(r)) &&
    (h.ieVersion = parseFloat(RegExp.$1));
  h.testPlace =
    h.isIE && h.ieVersion < 8
      ? function () {
          return !1;
        }
      : nb;
  var ob;
  h.isSafari &&
    ((ob = /Version.([\d.]+)/.exec(r)),
    (h.safariVersion = parseFloat(ob && ob[1])));
  function nb(a, b) {
    if (!(a = a.parentNode)) return !1;
    var c = a.ownerDocument,
      d = c.body,
      e = h.curCSS,
      g;
    b && (b += 1);
    if (window.$sf) return !0;
    if (h.isIE && (c.documentMode < 8 || c.compatMode == "BackCompat"))
      return !1;
    for (; a && a != d; ) {
      if (e(a, "overflow") == "hidden") return !1;
      if (e(a, "position") == "fixed") break;
      else if (b && (g = parseInt(e(a, "z-index"), 10)) && g < b) return !1;
      a = a.parentNode;
    }
    return !0;
  }
  function ka(a) {
    function b() {
      g = !1;
      var f = d,
        k = c,
        m = e;
      c = d = e = null;
      f && f.apply(k, m);
    }
    var c, d, e, g;
    return function (f, k) {
      c = f;
      d = k;
      e = va.call(arguments, 2);
      k && !g ? (g = setTimeout(b, a)) : !k && g && (clearTimeout(g), (g = !1));
    };
  }
  var pb = [],
    qb = [],
    rb = "__adform_onload",
    sb,
    tb;
  function ub() {
    for (var a = 0, b = []; a < pb.length; a++)
      pb[a].document.readyState != "complete" && b.push(pb[a]);
    if (!(pb = b).length || new Date().getTime() - tb > 3e4) {
      sb = clearInterval(sb);
      for (a = 0; a < qb.length; a++) qb[a]();
      qb = [];
      pb = [];
    }
  }
  function la(a, b) {
    try {
      do {
        if (a[rb]) break;
        a[rb] = !0;
        a.document.readyState != "complete" &&
          (pb.push(a),
          sb || ((tb = new Date().getTime()), (sb = setInterval(ub, 200))));
      } while (a != a.parent && (a = a.parent));
    } catch (c) {}
    sb ? qb.push(b) : setTimeout(b, 0);
  }
  function ma(a, b) {
    var c = Math.max(a.x, b.x),
      d = Math.max(a.y, b.y),
      e = Math.min(a.x + a.width, b.x + b.width) - c;
    a = Math.min(a.y + a.height, b.y + b.height) - d;
    return e > 0 && a > 0
      ? { x: c, y: d, width: e, height: a }
      : { x: 0, y: 0, width: 0, height: 0 };
  }
  function na(a, b) {
    var c = h.offset(a),
      d = h.offset(b);
    return ma(
      { x: c.left, y: c.top, width: a.offsetWidth, height: a.offsetHeight },
      { x: d.left, y: d.top, width: b.offsetWidth, height: b.offsetHeight }
    );
  }
  var vb = {};
  function wb(a, b, c, d) {
    function e(F) {
      d && d.apply(F, arguments);
    }
    var g = fa(c, "head");
    g = g && g[0];
    if (!g)
      try {
        throw Error("Can't find head tag.");
      } catch (F) {
        e(F);
      }
    var f = b.src || b.href,
      k = f.replace(/[^\da-z_-]/gi, "_"),
      m = c.adformId || h.gid("doc_"),
      n = m + "|" + k,
      t = vb[n];
    k = h.byTag(c, a);
    var u = 0,
      z = k.length;
    c.adformId = c.adformId || m;
    if (t) t.loaded ? e() : t.callbacks.push(e);
    else {
      for (; u < z; ++u)
        if (k[u].src == f || k[u].href == f) {
          e();
          return;
        }
      vb[n] = t = { doc: c, src: f, callbacks: [e] };
      var q = c.createElement(a);
      ia(q, b);
      if (d) {
        var I = function (F) {
          q.onload = q.onreadystatechange = q.onerror = null;
          F ? (vb[n] = null) : (t.loaded = 1);
          var K = t.callbacks;
          u = 0;
          for (z = K.length; u < z; ++u) K[u](F);
        };
        q.onload = function () {
          I();
        };
        q.onreadystatechange = function () {
          q.readyState == "complete" && I();
        };
        q.onerror = function () {
          try {
            throw Error("Failed to load script: " + f);
          } catch (F) {
            I(F);
          }
        };
      }
      setTimeout(function () {
        g.insertBefore(q, g.firstChild);
      }, 400);
    }
  }
  function ra(a, b, c) {
    wb("script", { src: b, type: "text/javascript" }, a, c);
  }
  function sa(a, b) {
    wb("link", { href: b, type: "text/css", rel: "stylesheet" }, a);
  }
  function ta(a) {
    try {
      var b = a.document,
        c = b && b.body;
      return c && oa(c, "tmx");
    } catch (d) {}
    return !1;
  }
  function ua(a, b) {
    var c = a.__adform_isolate;
    if (!c) {
      var d = a.document;
      c = fa(d, "head")[0];
      d = d.createElement("script");
      d.type = "text/javascript";
      d.text =
        'function __adform_isolate(f){new Function("window","("+f+")(window)")(window)}';
      c.insertBefore(d, c.firstChild);
      c.removeChild(d);
      c = a.__adform_isolate;
    }
    c ? c(b) : new Function("window", "(" + b + ")(window)")(a);
  }
  var xb = Array.prototype.slice;
  function x() {}
  var yb = x.prototype;
  yb.emit = zb;
  yb.on = Ab;
  yb.once = Bb;
  yb.off = Cb;
  yb.clear = Db;
  yb.list = Eb;
  function zb(a) {
    var b = this._events,
      c = !1,
      d = arguments;
    if (b && (b = b[a]))
      if (typeof b == "function") {
        switch (d.length) {
          case 1:
            b.call(this);
            break;
          case 2:
            b.call(this, d[1]);
            break;
          case 3:
            b.call(this, d[1], d[2]);
            break;
          case 4:
            b.call(this, d[1], d[2], d[3]);
            break;
          default:
            b.apply(this, xb.call(d, 1));
        }
        c = !0;
      } else if (b.length) {
        d = xb.call(d, 1);
        b = b.slice();
        c = 0;
        for (var e = b.length; c < e; c++) b[c].apply(this, d);
        c = !0;
      } else delete this._events[a];
    return c;
  }
  function Ab(a, b) {
    this._events || (this._events = {});
    this.emit("newListener", a, b);
    var c = this._events;
    c[a]
      ? typeof c[a] == "function"
        ? (c[a] = [c[a], b])
        : c[a].push(b)
      : (c[a] = b);
    return this;
  }
  function Bb(a, b) {
    var c = b._once;
    c
      ? c._times++
      : ((c = b._once =
          function () {
            this.off(a, c);
            --c._times < 1 && delete b._once;
            return b.apply(this, arguments);
          }),
        (c._times = 1));
    return this.on(a, c);
  }
  function Cb(a, b) {
    if (!this._events || !this._events[a]) return this;
    var c = this._events,
      d = c[a];
    if (d == b) return delete c[a], this;
    b && b._once && this.off(b._once);
    if (typeof d == "function") return this;
    if (d.length < 2 && d[0] == b) return delete c[a], this;
    for (var e = 0, g = d.length, f = []; e < g; e++) d[e] != b && f.push(d[e]);
    f.length != g && (f.length ? (c[a] = f) : delete c[a]);
    return this;
  }
  function Db(a) {
    a
      ? this._events && this._events[a] && delete this._events[a]
      : delete this._events;
    return this;
  }
  function Eb(a) {
    this._events || (this._events = {});
    var b = this._events;
    b[a] ? typeof b[a] == "function" && (b[a] = [b[a]]) : (b[a] = []);
    return b[a];
  }
  var Gb = Fb,
    Hb = [],
    Ib = /adform-dom-(\S+)/,
    Jb = h.addEvent,
    Kb = h.removeEvent;
  function Fb() {}
  Fb.has = Lb;
  Fb.on = Mb;
  Fb.off = Nb;
  Fb.destroy = Ob;
  function Ob(a) {
    Pb(a)._destroy();
  }
  function Lb(a) {
    return !!{
      hover: 1,
      mousedown: 1,
      mouseup: 1,
      click: 1,
      swipe: 1,
      touchstart: 1,
      touchmove: 1,
      touchend: 1,
    }[a];
  }
  function Mb(a, b, c) {
    var d = a.ownerDocument;
    if (Qb(d, b, a)) {
      var e = Rb(a);
      h.addClass(a, "adform-dom-" + e);
      Pb(d)._.on(e + ":" + b, c);
      return !0;
    }
    return !1;
  }
  function Nb(a, b, c) {
    Pb(a.ownerDocument)._.off(Rb(a) + ":" + b, c);
  }
  function Pb(a) {
    for (var b = Hb.length; b-- > 0; ) if (Hb[b][0] == a) return Hb[b][1];
  }
  function Qb(a, b, c) {
    function d(l) {
      if (l && m) Kb(m, "touchstart", Sb);
      else if (!m)
        try {
          (m = a.defaultView.frameElement) && Jb(m, "touchstart", Sb);
        } catch (G) {}
    }
    var e = Pb(a),
      g,
      f;
    e
      ? (g = e._)
      : Hb.push([
          a,
          (e = {
            _: (g = new x()),
            _destroy: function () {
              g.clear();
              delete this._;
              delete this._destroy;
              for (var l in this) if (typeof this[l] == "function") this[l]();
              for (l = Hb.length; l-- > 0; )
                if (Hb[l][0] == a) {
                  Hb.splice(l, 1);
                  break;
                }
            },
          }),
        ]);
    var k, m, n, t, u, z, q, I;
    h.isIOS &&
      a.defaultView.frameElement &&
      { click: 1, mousedown: 1, mouseup: 1 }[b] &&
      Jb(c, b, Sb);
    if (!e[b])
      switch (b) {
        case "swipe":
          var F = function (l) {
            if ((k = Tb(g, l.target, "swipe")[0]))
              l.preventDefault(),
                (l = l && l.targetTouches) &&
                  (l = l[0]) &&
                  ((n = l.pageX), (u = l.pageY), (q = new Date().getTime()));
          };
          var K = function (l) {
            var G = l && l.targetTouches;
            k &&
              (l.preventDefault(),
              G &&
                (G = G[0]) &&
                q &&
                ((t = G.pageX),
                (z = G.pageY),
                (I = new Date().getTime()),
                Math.sqrt(Math.pow(t - n, 2) + Math.pow(z - u, 2)) / (I - q) >
                  0.2 &&
                  ((l = u - z),
                  (G = { type: "swipe" }),
                  (G.directionX = n - t > 0 ? "left" : "right"),
                  (G.directionY = l > 0 ? "up" : "down"),
                  (G.target = k[1]),
                  (q = 0),
                  Ub(g, k[1], G))));
          };
          Jb(a, "touchstart", F);
          Jb(a, "touchend", K);
          Jb(a, "touchmove", K);
          d();
          e[b] = function () {
            Kb(a, "touchstart", F);
            Kb(a, "touchend", K);
            Kb(a, "touchmove", K);
            d(!0);
          };
          break;
        case "hover":
          if (a.addEventListener) {
            var H = function (l) {
              l = l.target;
              f != l && Vb(g, f, (f = l));
            };
            var R = function (l) {
              l = l.relatedTarget;
              f != l && Vb(g, f, (f = l));
            };
          } else
            (H = function (l) {
              l = (a.defaultView || a.parentWindow).event.srcElement;
              f != l && Vb(g, f, (f = l));
            }),
              (R = function (l) {
                l = (a.defaultView || a.parentWindow).event.toElement;
                f != l && Vb(g, f, (f = l));
              });
          Jb(a, "mouseover", H);
          Jb(a, "mouseout", R);
          Jb(a, "mousemove", H);
          e[b] = function () {
            Kb(a, "mouseover", H);
            Kb(a, "mouseout", R);
            Kb(a, "mousemove", H);
            f = null;
          };
          break;
        case "click":
        case "mousedown":
        case "mouseup":
        case "touchstart":
        case "touchmove":
        case "touchend":
          (H = a.addEventListener
            ? function (l) {
                Ub(g, l.target, l);
              }
            : function (l) {
                l = (a.defaultView || a.parentWindow).event;
                Ub(g, l.srcElement, l);
              }),
            Jb(a, b, H),
            (e[b] = function () {
              Kb(a, b, H);
            });
      }
    return !!e[b];
  }
  function Vb(a, b, c) {
    c = Tb(a, c, "hover");
    b = Tb(a, b, "hover");
    for (
      var d = c.length, e = d, g = b.length, f = g - d;
      e-- > 0 && c[e][1] == (b[f + e] && b[f + e][1]);

    );
    c.length = d = e + 1;
    b.length = g = f + e + 1;
    var k,
      m = a._events;
    if (m) {
      for (f = e = -1; ++f < g; )
        m[(k = b[f][0])] && a.emit(k, b[f][1], "hoverout");
      for (; ++e < d; ) m[(k = c[e][0])] && a.emit(k, c[e][1], "hoverin");
    }
  }
  function Ub(a, b, c, d) {
    d = d || c;
    b = Tb(a, b, c.type);
    c = b.length;
    for (var e = 0, g; (g = b[e]), e++ < c; ) a.emit(g[0], g[1], d);
  }
  function Tb(a, b, c) {
    a = a._events;
    var d,
      e,
      g,
      f = [];
    if (a)
      for (; b && (g = typeof (e = b.className)) != "undefined"; )
        g == "string" &&
          ~e.indexOf("adform-dom-") &&
          a[(d = Rb(b) + ":" + c)] &&
          (f[f.length] = [d, b]),
          (b = b.parentNode);
    return f;
  }
  function Rb(a) {
    a = a.className;
    return ~a.indexOf("adform-dom-") ? a.match(Ib)[1] : h.gid();
  }
  function Sb() {} /*
 mustache.js - Logic-less {{mustache}} templates with JavaScript
 http://github.com/janl/mustache.js
*/
  var y = (typeof module !== "undefined" && module.exports) || {};
  y.name = "mustache.js";
  y.version = "0.5.0-dev";
  y.tags = ["{{", "}}"];
  y.parse = Wb;
  y.compile = Xb;
  y.render = Yb;
  y.clearCache = Zb;
  y.to_html = function (a, b, c, d) {
    a = Yb(a, b, c);
    if (typeof d === "function") d(a);
    else return a;
  };
  var $b = Object.prototype.toString,
    ac = Array.isArray,
    bc = Array.prototype.forEach,
    cc = String.prototype.trim,
    dc;
  dc = ac
    ? ac
    : function (a) {
        return $b.call(a) === "[object Array]";
      };
  var ec;
  ec = bc
    ? function (a, b, c) {
        return bc.call(a, b, c);
      }
    : function (a, b, c) {
        for (var d = 0, e = a.length; d < e; ++d) b.call(c, a[d], d, a);
      };
  var fc = /^\s*$/,
    hc;
  if (cc)
    hc = function (a) {
      return a == null ? "" : cc.call(a);
    };
  else {
    var ic, jc;
    fc.test("\u00a0")
      ? ((ic = /^\s+/), (jc = /\s+$/))
      : ((ic = /^[\s\xA0]+/), (jc = /[\s\xA0]+$/));
    hc = function (a) {
      return a == null ? "" : String(a).replace(ic, "").replace(jc, "");
    };
  }
  var kc = {
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;",
  };
  function lc(a) {
    return String(a).replace(/&(?!\w+;)|[<>"']/g, function (b) {
      return kc[b] || b;
    });
  }
  function mc(a, b, c, d) {
    d = d || "<template>";
    var e = b.split("\n"),
      g = Math.max(c - 3, 0);
    e = e.slice(g, Math.min(e.length, c + 3));
    for (var f, k = 0, m = e.length; k < m; ++k)
      (f = k + g + 1), (e[k] = (f === c ? " >> " : "    ") + e[k]);
    a.template = b;
    a.line = c;
    a.file = d;
    a.message = [d + ":" + c, e.join("\n"), "", a.message].join("\n");
    return a;
  }
  function nc(a, b, c) {
    if (a === ".") return b[b.length - 1];
    a = a.split(".");
    for (var d = a.length - 1, e = a[d], g, f, k = b.length, m, n; k; ) {
      n = b.slice(0);
      f = b[--k];
      for (m = 0; m < d; ) {
        f = f[a[m++]];
        if (f == null) break;
        n.push(f);
      }
      if (f && typeof f === "object" && e in f) {
        g = f[e];
        break;
      }
    }
    typeof g === "function" && (g = g.call(n[n.length - 1]));
    return g == null ? c : g;
  }
  function oc(a, b, c, d) {
    var e = "";
    a = nc(a, b);
    if (d) {
      if (a == null || a === !1 || (dc(a) && a.length === 0)) e += c();
    } else if (dc(a))
      ec(a, function (f) {
        b.push(f);
        e += c();
        b.pop();
      });
    else if (typeof a === "object") b.push(a), (e += c()), b.pop();
    else if (typeof a === "function") {
      var g = b[b.length - 1];
      e +=
        a.call(g, c(), function (f) {
          return Yb(f, g);
        }) || "";
    } else a && (e += c());
    return e;
  }
  function Wb(a, b) {
    function c(w) {
      q.push(
        '";',
        R,
        '\nbuffer += escapeHTML(lookup("' + hc(w) + '",stack,""));',
        '\nbuffer += "'
      );
    }
    function d(w) {
      q.push(
        '";',
        R,
        '\nbuffer += lookup("' + hc(w) + '",stack,"");',
        '\nbuffer += "'
      );
    }
    function e(w) {
      w = hc(w);
      var ba = H.length != 0 && H[H.length - 1].name;
      if (!ba || w != ba)
        throw mc(
          Error('Section named "' + w + '" was never opened'),
          a,
          X,
          b.file
        );
      w = H.pop();
      q.push('";', "\n    return buffer;", "\n  };", "\n})();");
      w.inverted
        ? q.push("\nbuffer += renderSection(name,stack,callback,true);")
        : q.push("\nbuffer += renderSection(name,stack,callback);");
      q.push('\nbuffer += "');
    }
    function g(w) {
      f(w, !0);
    }
    function f(w, ba) {
      w = hc(w);
      if (w === "")
        throw mc(Error("Section name may not be empty"), a, X, b.file);
      H.push({ name: w, inverted: ba });
      q.push(
        '";',
        R,
        '\nvar name = "' + w + '";',
        "\nvar callback = (function () {",
        "\n  return function () {",
        '\n    var buffer = "";',
        '\nbuffer += "'
      );
    }
    function k(w) {
      q.push(
        '";',
        R,
        '\nvar partial = partials["' + hc(w) + '"];',
        "\nif (partial) {",
        "\n  buffer += render(partial,stack[stack.length - 1],partials);",
        "\n}",
        '\nbuffer += "'
      );
    }
    function m(w) {
      t = hc(w).split(/\s+/);
      l = t[0];
      G = t[t.length - 1];
    }
    function n() {
      if (!F || K || b.space) I = [];
      else for (; I.length; ) q.splice(I.pop(), 1);
      K = F = !1;
    }
    b = b || {};
    for (
      var t = b.tags || y.tags,
        u = t[0],
        z = t[t.length - 1],
        q = ['var buffer = "";', "\nvar line = 1;", "\ntry {", '\nbuffer += "'],
        I = [],
        F = !1,
        K = !1,
        H = [],
        R,
        l,
        G,
        X = 1,
        P,
        A,
        B = 0,
        mb = a.length;
      B < mb;
      ++B
    )
      if (a.slice(B, B + u.length) === u) {
        B += u.length;
        P = a.substr(B, 1);
        R = "\nline = " + X + ";";
        l = u;
        G = z;
        F = !0;
        switch (P) {
          case "!":
            B++;
            A = null;
            break;
          case "=":
            B++;
            z = "=" + z;
            A = m;
            break;
          case ">":
            B++;
            A = k;
            break;
          case "#":
            B++;
            A = f;
            break;
          case "^":
            B++;
            A = g;
            break;
          case "/":
            B++;
            A = e;
            break;
          case "{":
            z = "}" + z;
          case "&":
            B++;
            K = !0;
            A = d;
            break;
          default:
            (K = !0), (A = c);
        }
        P = a.indexOf(z, B);
        if (P === -1)
          throw mc(
            Error('Tag "' + u + '" was not closed properly'),
            a,
            X,
            b.file
          );
        u = a.substring(B, P);
        A && A(u);
        for (A = 0; ~(A = u.indexOf("\n", A)); ) X++, A++;
        B = P + z.length - 1;
        u = l;
        z = G;
      } else
        switch (((P = a.substr(B, 1)), P)) {
          case '"':
          case "\\":
            K = !0;
            q.push("\\" + P);
            break;
          case "\r":
            break;
          case "\n":
            I.push(q.length);
            q.push("\\n");
            n();
            X++;
            break;
          default:
            fc.test(P) ? I.push(q.length) : (K = !0), q.push(P);
        }
    if (H.length != 0)
      throw mc(
        Error('Section "' + H[H.length - 1].name + '" was not closed properly'),
        a,
        X,
        b.file
      );
    n();
    q.push(
      '";',
      "\nreturn buffer;",
      "\n} catch (e) { throw {error: e, line: line}; }"
    );
    z = q.join("").replace(/buffer \+= "";\n/g, "");
    b.debug &&
      (typeof console != "undefined" && console.log
        ? console.log(z)
        : typeof print === "function" && print(z));
    return z;
  }
  function pc(a, b) {
    var c = Wb(a, b),
      d = new Function(
        "view,partials,stack,lookup,escapeHTML,renderSection,render",
        c
      );
    return function (e, g) {
      g = g || {};
      var f = [e];
      try {
        return d(e, g, f, nc, lc, oc, Yb);
      } catch (k) {
        throw mc(k.error, a, k.line, b.file);
      }
    };
  }
  var qc = {};
  function Zb() {
    qc = {};
  }
  function Xb(a, b) {
    b = b || {};
    return b.cache !== !1 ? (qc[a] || (qc[a] = pc(a, b)), qc[a]) : pc(a, b);
  }
  function Yb(a, b, c) {
    return Xb(a)(b, c);
  }
  var rc = { mobileInline: !0, mobileInterstitial: !0 },
    sc = {
      prog0: { id: "25", value: 0 },
      prog25: { id: "26", value: 0.25 },
      prog50: { id: "27", value: 0.5 },
      prog75: { id: "28", value: 0.75 },
      prog100: { id: "29", value: 1 },
    },
    tc = {
      PLAYING: "playing",
      STOPPED: "stopped",
      FINISHED: "finished",
      PAUSED: "paused",
    },
    uc =
      "timeupdate play pause playing seeking seeked stalled ended volumechange".split(
        " "
      ),
    vc = window.document,
    wc = h.addEvent,
    xc = h.removeEvent;
  var yc = typeof window !== "undefined" ? window : {},
    zc = yc.document,
    Ac = yc.JSON,
    Bc = 0,
    Cc = new x(),
    Dc = !!(zc && zc.documentMode < 10),
    Ic = { send: Ec, on: Fc, off: Gc, destroy: Hc };
  yc.addEventListener && yc.addEventListener("message", Jc);
  function Ec(a, b) {
    a = {
      channel: "adf-bridge",
      id: "adf-bridge-" + ++Bc,
      type: a,
      payload: b,
    };
    try {
      yc.parent.postMessage(Dc ? Ac.stringify(a) : a, "*");
    } catch (c) {}
  }
  function Fc(a, b) {
    Cc.on(a, b);
  }
  function Gc(a, b) {
    Cc.off(a, b);
  }
  function Hc() {
    yc.removeEventListener("message", Jc);
    Cc.clear();
  }
  function Jc(a) {
    if (a.source === yc.parent) {
      a = a.data;
      if (typeof a === "string")
        try {
          var b = Ac.parse(a);
        } catch (c) {
          b = null;
        }
      else b = a;
      b && b.channel === "adf-bridge" && Cc.emit(b.type, b.payload, b);
    }
  }
  for (
    var Kc =
        "close superClose expand resize setLayout rollOutAd initPoliteMode initVideoMode initCube3D initExtender initInScreen initScroll initSingleExpanding startDrag endDrag updateBox expandComplete collapseComplete toggleFullScreen videoPlayStartHandler videoCompleteHandler".split(
          " "
        ),
      Lc = {},
      Mc = 0;
    Mc < Kc.length;
    Mc++
  )
    Lc[Kc[Mc]] = Nc("external." + Kc[Mc]);
  function Nc(a) {
    return function () {
      Ic.send(a, [].slice.call(arguments));
    };
  }
  var Oc = new x(),
    Qc = Oc.emit;
  Oc.emit = function (a) {
    a !== "newListener" &&
      Ic.send("sharedEvent", { event: a, data: arguments[1] });
    return Qc.apply(this, arguments);
  };
  Ic.on("sharedEvent", function (a) {
    Qc.call(Oc, a.event, a.data);
  });
  Oc.on("newListener", function (a) {
    Ic.send("sharedEvent.newListener", { event: a });
  });
  for (
    var Rc = h.isArray,
      Sc = {},
      Tc,
      Uc = document.getElementsByTagName("script"),
      C = 0,
      Vc;
    C < Uc.length;
    C++
  )
    if ((Vc = (Uc[C].src || "").match(/(^.*)rmb\/Adform\.DHTML\.js/))) {
      Tc = Vc[1] + "components/";
      break;
    }
  var Wc = 0,
    D = (window.Adform = window.Adform || {}),
    Xc = window._AdformContent || {},
    Yc = Xc.data || {},
    Zc = Xc.options || {},
    E = Yc.flashvars,
    $c = D.tagData,
    ad,
    bd;
  if (!E && ((E = {}), $c)) {
    ad = $c.customVariables;
    bd = $c.clickUrls;
    if (ad) for (var cd in ad) E[cd] = ad[cd];
    for (var dd in bd) E[dd] = bd[dd];
  }
  var ed = new x();
  D.on =
    D.on ||
    function () {
      ed.on.apply(ed, arguments);
    };
  D.off =
    D.off ||
    function () {
      ed.off.apply(ed, arguments);
    };
  D.emit =
    D.emit ||
    function () {
      ed.emit.apply(ed, arguments);
    };
  var L = {
    151: "Previous Product Button Press",
    150: "Next Product Button Press",
    143: "Banner Collapse",
    22: "Other Expands",
    21: "First Expand",
    168: "Auto Expands",
    161: "Hide Expanding Banner Button Press",
    23: "Close Button Press",
    25: "Video Play Start",
    26: "Played 25% Of Video",
    27: "Played 50% Of Video",
    28: "Played 75% Of Video",
    29: "Video Playback Complete",
    30: "Play Button Press",
    31: "Pause Button Press",
    32: "Stop Button Press",
    33: "Sound On Button Press",
    34: "Sound Off Button Press",
    35: "Full Screen On Button Press",
    36: "Full Screen Off Button Press",
    38: "Rewind Button Press",
    "": "",
  };
  D.EVENT_FIRST_EXPAND = D.EVENT_FIRST_EXPAND || [21, L[21]];
  D.EVENT_OTHER_EXPAND = D.EVENT_OTHER_EXPAND || [22, L[22]];
  D.EVENT_CLOSE = D.EVENT_CLOSE || [23, L[23]];
  D.EVENT_COLLAPSE = D.EVENT_COLLAPSE || [143, L[143]];
  for (C = 1; C < 251; C++)
    if (C < 21 || C > 199) D["EVENT_CUSTOM_" + C] = [C, "Custom Event " + C];
  D.sendRequest =
    D.sendRequest ||
    function (a) {
      new Image().src = a;
    };
  D.sendEvent =
    D.sendEvent ||
    function (a) {
      var b,
        c,
        d = arguments;
      if ((b = Rc(a) && a.length > 1)) {
        for (b = 1; b < d.length && b < 256; b++)
          (c = c || {})["bv" + b] = d[b];
        b = fd(a[0], a[1], c);
      }
      return b;
    };
  D.getClickURL =
    D.getClickURL ||
    function (a, b) {
      return (a = gd(a || Yc.defaultClickTAG || "clickTAG"))
        ? a.indexOf("?") !== -1 && a.indexOf(";") !== -1
          ? a + ";cpdir="
          : a
        : b || null;
    };
  D.getLocation =
    D.getLocation ||
    function () {
      var a = gd("geoLocation", null),
        b = a && a.location;
      return b ? ((a.lat = b.latitude), (a.lng = b.longitude), a) : null;
    };
  D.getAsset =
    D.getAsset ||
    function (a) {
      return hd(a) || null;
    };
  D.getVar =
    D.getVar ||
    function (a) {
      return a && E[a] !== void 0 ? E[a] : null;
    };
  var M = {
      PREVIOUS_BUTTON_PRESS: 151,
      NEXT_BUTTON_PRESS: 150,
      CLOSE_BUTTON_PRESS: 23,
      COLLAPSE_EVENT: 143,
      EXPAND_EVENT: 22,
      FIRST_EXPAND_EVENT: 21,
      AUTO_EXPAND_EVENT: 168,
      SUPER_CLOSE_EVENT: 161,
      VIDEO_PROG_0: 25,
      VIDEO_PROG_25: 26,
      VIDEO_PROG_50: 27,
      VIDEO_PROG_75: 28,
      VIDEO_PROG_100: 29,
      PLAY_BUTTON_PRESS: 30,
      PAUSE_BUTTON_PRESS: 31,
      STOP_BUTTON_PRESS: 32,
      SOUND_ON_BUTTON_PRESS: 33,
      SOUND_OFF_BUTTON_PRESS: 34,
      FULL_SCREEN_ON_BUTTON_PRESS: 35,
      FULL_SCREEN_OFF_BUTTON_PRESS: 36,
      REWIND_BUTTON_PRESS: 38,
      byId: id,
      hasClass: h.hasClass,
      addClass: h.addClass,
      removeClass: h.removeClass,
      mustache: jd,
      sendEvent: kd,
      $sendEvent: fd,
      appendEvents: ld,
      getVar: gd,
      getAsset: hd,
      width: Yc.width,
      height: Yc.height,
      collapsedWidth: Zc.colWidth,
      collapsedHeight: Zc.colHeight,
      external: Xc.external || Lc,
      inscreen: new x(),
      sharedEvents: Xc.sharedEvents || Oc,
      scriptsBase: Zc.scriptsBase || Tc + "../",
      getState: function () {
        return Xc.state ? Xc.state() : "visible";
      },
      on: Gb.on,
      off: Gb.off,
      connect: md,
    },
    N = M,
    Q;
  try {
    Q = parent.parent.getVPAIDAd && parent.parent.getVPAIDAd();
  } catch (a) {}
  if (Q && Q.callDHTMLEvent) {
    M.vpaid = Q;
    var nd = M.external.close;
    M.external.close = function () {
      Q.callDHTMLEvent.call(Q, 23);
      return nd.apply(this, arguments);
    };
  }
  function md(a) {
    var b = window._Adform && _Adform.ADFUtilInstance;
    b = b ? b.getRotSeed() : {};
    a = a || E.bn || "x";
    b.localConnections || (b.localConnections = {});
    var c = b.localConnections[a];
    if (!c) {
      c = new x();
      var d = [];
      c.expect = function (e, g) {
        if (d.length >= e) g();
        else c.once("expect:" + e, g);
        return c;
      };
      c.join = function (e) {
        d.push(e);
        c.emit("member", e);
        c.emit("expect:" + d.length);
        return c;
      };
      c.members = d;
      b.localConnections[a] = c;
    }
    return c;
  }
  M.sharedEvents.on("newListener", function (a) {
    a == "pageLoadComplete" &&
      setTimeout(function () {
        M.external.initPoliteMode();
      }, 0);
  });
  M.adMessage = {
    setProperties: od,
    getProperties: od,
    getPage: od,
    getItems: od,
    getDefault: od,
  };
  var S = M.inscreen;
  M.external.initInScreen &&
    (M.sharedEvents.on("updateInScreen", function (a) {
      for (var b in a) S.emit(b, (S[b] = a[b]));
      S.emit("change");
    }),
    D.on("newListener", function c(b) {
      b === "visibilityData" &&
        (D.off("newListener", c),
        S.on("change", function () {
          S.visible && S.bxdTime && (S.bxdTime = Math.round(S.bxdTime));
          D.emit("visibilityData", {
            isVisible: S.visible,
            isViewable: S.visible,
            visibleArea: S.visible ? S.percent : 0,
            maxVisibleArea: S.maxVisibility,
            visibleTime: S.visibleTime,
            bxdTime: S.bxdTime || 0,
            bxdRatio: S.visible ? S.bxdRatio : 0,
            expandTime: S.expandTime || 0,
            videoTime: S.videoTime || 0,
            engagementTime: S.engagementTime || 0,
          });
        }));
    }),
    S.once("newListener", function () {
      setTimeout(function () {
        M.external.initInScreen();
      }, 0);
    }));
  var pd = window.preloadQueue || window.components || [],
    qd = pd.length;
  for (C = 0; C < pd.length; C++)
    document.write(
      '<script src="' +
        (Tc + "Adform." + pd[C] + ".js?bv=" + (E.bv || Math.random())) +
        '">\x3c/script>'
    );
  try {
    var rd = document.defaultView.frameElement;
    rd && h.addEvent(rd, "touchstart", function () {});
  } catch (a) {}
  M.registerComponent = function (a) {
    for (var b = 0; b < pd.length; b++) pd[b] == a && qd--;
    qd || sd();
  };
  qd || sd();
  (function (a, b) {
    function c(f) {
      function k() {
        var n = f.currentTime / f.duration,
          t;
        for (t in sc) {
          var u = sc[t];
          n >= u.value && (a.sendEvent(u.id), delete sc[t]);
        }
        n = f.paused;
        n = f.ended ? tc.FINISHED : n ? tc.PAUSED : tc.PLAYING;
        n !== e && (a.sharedEvents.emit("video:state", n), (e = n));
        n = f.muted || f.volume === 0;
        n !== g && (a.sharedEvents.emit("video:muted", n), (g = n));
        if (!sc.prog100) for (n = 0; n < uc.length; n++) xc(f, uc[n], k);
      }
      for (var m = 0; m < uc.length; m++) wc(f, uc[m], k);
    }
    function d() {
      var f = vc.querySelectorAll("video");
      f.length ? c(f[0]) : wc(vc, "DOMContentLoaded", d);
    }
    var e = tc.PAUSED,
      g = !1;
    rc[((b && b.flashvars) || {}).bannerType] && d();
  })(M, Yc);
  function sd() {
    if (window.Ready) for (var a = 0; a < Ready.length; a++) td(Ready[a]);
    window.Ready = { push: td };
  }
  var ud, vd;
  function gd(a, b) {
    if (!a) return E;
    var c = wd(E[a]),
      d = wd(Zc[a]),
      e = wd(Yc[a]);
    return c ? E[a] : d ? Zc[a] : e ? Yc[a] : b;
  }
  function wd(a) {
    return typeof a !== "undefined";
  }
  function hd(a) {
    a = parseInt(a, 10);
    var b = gd("videoSources");
    if (b)
      for (var c = b.length, d, e = 0; e < c; e++)
        if (((d = b[e]), d.id == a)) return d.file;
  }
  function td(a) {
    a.call(window);
    vd ||
      (clearTimeout(ud),
      (ud = setTimeout(function () {
        vd = !0;
        document.close();
      }, 1e3)));
  }
  function od(a, b) {
    typeof b == "function" && (a = b);
    try {
      throw Error("AdMessage template id is missing");
    } catch (c) {
      if (typeof a == "function") a(c);
      else throw c;
    }
  }
  function kd(a, b, c) {
    M.sharedEvents.emit(a + "", { id: a, name: b || L[a], vars: c });
    if (!(Q && Q.callDHTMLEvent && Q.callDHTMLEvent.call(Q, a)))
      return a in L && (c = null), fd(a, b, c);
  }
  function fd(a, b, c, d) {
    var e = window._Adform && _Adform.Events;
    if (a in L) b = L[a];
    else if (
      isNaN((a = parseInt(a, 10))) ||
      a < 1 ||
      (a > 20 && a < 200) ||
      a > 250
    )
      throw Error(
        "Custom event id=" +
          a +
          " must be between 1-20 for engaging and 200-250 for non-engaging events"
      );
    if (!b) throw Error("Event name is missing");
    var g = [""];
    if (c)
      for (var f in c) {
        var k = f.slice(0, 2),
          m = parseInt(f.slice(2), 10);
        k == "bv" &&
          m > 0 &&
          m < 256 &&
          g.push(f + "=" + encodeURIComponent(c[f]));
      }
    d && g.push(d);
    e && e.sendEvent
      ? e.sendEvent(Zc.xId, a, Yc.assetId, b, g.join("&"), "Standard HTML")
      : Ic.send("events.sendEvent", {
          xId: Zc.xId,
          eventId: a,
          assetId: Yc.assetId,
          name: b,
          vars: g.join("&"),
          type: "Standard HTML",
        });
    return !0;
  }
  function jd(a, b) {
    Sc[a] || (Sc[a] = y.compile(id(a).text));
    if (b) {
      if (Uc.length != Wc) {
        for (var c = 0; c < Uc.length; c++)
          Uc[c].type == "text/mustache" && jd(Uc[c].id);
        Wc = Uc.length;
      }
      return Sc[a](b, Sc);
    }
    return Sc[a];
  }
  function id(a) {
    return document.getElementById(a);
  }
  function ld(a) {
    for (var b in a) L.hasOwnProperty(b) || (L[b] = a[b]);
    return L;
  }
  var T = N.getVar,
    xd = T("geoLocation", null);
  if (xd) {
    var yd;
    xd.lat = (yd = xd.location) == null ? void 0 : yd.latitude;
    var zd;
    xd.lng = (zd = xd.location) == null ? void 0 : zd.longitude;
  }
  var Ad = {
      id: T("bn"),
      asset: T("assetId"),
      clientSite: T("cid"),
      scheduleMember: T("smid"),
      rotatorMemberSeqNo: T("rotseqno"),
      banner: T("ADFbanID"),
      imprid: T("unloadID"),
      dynamicAdContent: T("dynamicAdContent"),
      rtbData: T("rtbdata"),
      rtbwp: T("rtbwp"),
      adxVars: T("adxvars"),
      eData: T("eData"),
      trackingSetupId: T("trackingSetupId"),
      gdpr: T("gdpr"),
      gdpr_consent: T("gdpr_consent"),
      gpp: T("gpp"),
      gpp_sid: T("gpp_sid"),
      location: xd,
    },
    Bd = T("tid"),
    Cd = T("tv"),
    Dd = T("gid"),
    Ed = T("dcoEngineId");
  if (Bd || Cd || Dd || Ed)
    Ad.templateData = { id: Bd, version: Cd, group: Dd, dcoEngineId: Ed };
  var Fd = {
      UNKNOWN: "unknown",
      INLINE: "inline",
      INTERSTITIAL: "interstitial",
    },
    U = {
      LOADING: "loading",
      DEFAULT: "default",
      EXPANDED: "expanded",
      RESIZED: "resized",
      HIDDEN: "hidden",
    },
    V = {
      READY: "ready",
      ERROR: "error",
      STATE_CHANGE: "stateChange",
      VIEWABLE_CHANGE: "viewableChange",
      VIEWABLE_PERCENTAGE_CHANGE: "viewablePercentageChange",
      SIZE_CHANGE: "sizeChange",
    },
    Gd = { TOP_LEFT: "top-left", TOP_RIGHT: "top-right" };
  function Hd(a, b) {
    function c() {
      switch (a.getState()) {
        case U.EXPANDED:
        case U.RESIZED:
          d();
          break;
        default:
          e();
      }
    }
    function d() {
      a.getExpandProperties().useCustomClose
        ? e()
        : (f.parentNode ||
            (document.body ? g() : h.addEvent(document, "DOMContentLoaded", g)),
          (f.style.display = "block"));
    }
    function e() {
      f.style.display = "none";
    }
    function g() {
      document.body.appendChild(f);
    }
    h.addEvent(
      window,
      "click",
      function (m) {
        if (m.target && m.target.id === "adf-mraid-close-button")
          return a.close(m), !1;
      },
      !0
    );
    var f = h.html(
      '<img id="adf-mraid-close-button" src="' +
        b.scriptsBase +
        'assets/images/close-sprite.png" style="pointer-events:auto!important;width:50px!important;height:50px!important;position:absolute!important;top:5px!important;right:5px!important;padding:0!important;margin:0!important;z-index:10000!important;cursor:pointer;display:none;" alt="close" />'
    );
    h.addEvent(f, "click", a.close);
    a.addEventListener(V.STATE_CHANGE, c);
    a.addEventListener(V.SIZE_CHANGE, c);
    var k = { element: f, show: d, hide: e };
    a.getCloseButton = function () {
      return k;
    };
    b.isInterstitial && d();
    return k;
  }
  function Id(a, b, c) {
    function d() {
      switch (a.getState()) {
        case U.EXPANDED:
        case U.RESIZED:
          b.changePositioning(Gd.TOP_LEFT);
          break;
        default:
          b.changePositioning(Gd.TOP_RIGHT);
      }
    }
    c.isInterstitial && b.changePositioning(Gd.TOP_LEFT);
    a.addEventListener(V.STATE_CHANGE, d);
    a.addEventListener(V.SIZE_CHANGE, d);
  }
  function Jd(a, b) {
    var c = b.sendEvent,
      d = !1;
    a.addEventListener(V.STATE_CHANGE, function (e) {
      switch (e) {
        case U.EXPANDED:
        case U.RESIZED:
          c(d ? b.EVENT_OTHER_EXPAND : b.EVENT_FIRST_EXPAND);
          d = !0;
          break;
        case U.DEFAULT:
          d && c(b.EVENT_CLOSE);
          break;
        case U.HIDDEN:
          c(b.EVENT_CLOSE);
      }
    });
  }
  var Kd = window.document,
    Ld = window.Adform,
    W = U.LOADING,
    Md = Fd.UNKNOWN,
    Nd = !1,
    Od = !1,
    Y = {
      expandProperties: {
        width: "100%",
        height: "100%",
        useCustomClose: !1,
        isModal: !0,
      },
      resizeProperties: {
        width: 0,
        height: 0,
        offsetX: 0,
        offsetY: 0,
        customClosePosition: "top-right",
        allowOffscreen: !0,
      },
      orientationProperties: {
        allowOrientationChange: !0,
        forceOrientation: "none",
      },
      screenSize: { width: 0, height: 0 },
      maxSize: { width: 0, height: 0 },
      defaultPos: { x: 0, y: 0, width: 0, height: 0 },
      currentPos: { x: 0, y: 0, width: 0, height: 0 },
      isAdViewable: !1,
      viewablePercentage: 0,
      supportedFeatures: {
        sms: !1,
        tel: !1,
        calendar: !1,
        storePicture: !1,
        inlineVideo: !1,
        viewablePercentage: !0,
      },
    },
    Pd = { mobileInterstitial: Fd.INTERSTITIAL, mobileInline: Fd.INLINE },
    Qd = new x(),
    Rd = null;
  try {
    Rd = window.mraid || window.parent.mraid;
  } catch (a) {}
  var je = {
      addEventListener: Sd,
      removeEventListener: Td,
      getState: Ud,
      getVersion: Vd,
      getPlacementType: Wd,
      isViewable: Xd,
      getViewablePercentage: Yd,
      open: Zd,
      getExpandProperties: $d("expandProperties"),
      setExpandProperties: ae("expandProperties"),
      expand: be,
      close: ce,
      useCustomClose: de,
      getMaxSize: $d("maxSize"),
      getSceenSize: $d("screenSize"),
      getDefaultPosition: $d("defaultPos"),
      getCurrentPosition: $d("currentPos"),
      getResizeProperties: $d("resizeProperties"),
      setResizeProperties: ae("resizeProperties"),
      resize: ee,
      getOrientationProperties: $d("orientationProperties"),
      setOrientationProperties: ae("orientationProperties"),
      playVideo: fe,
      supports: ge,
      storePicture: he,
      createCalendarEvent: ie,
      unload: ce,
    },
    ke = Rd || window.mraid || je,
    le = ke.open;
  ke.open = function (a) {
    var b = Ld.trackingUrlBase,
      c = Ld.getClickURL();
    a &&
      a.length &&
      c &&
      a.indexOf("http") >= 0 &&
      a.indexOf(b) === -1 &&
      a.toLowerCase().indexOf(c.toLowerCase()) === -1 &&
      (a = c + a);
    le.call(this, a);
  };
  var me = ke;
  Rd
    ? Rd.addEventListener(
        V.SIZE_CHANGE,
        ne({ width: window.innerWidth, height: window.innerHeight })
      )
    : ((window.mraidReady = oe),
      window.dispatchEvent(new window.Event("mraidReady")),
      h.addEvent(window, "DOMContentLoaded", oe));
  function oe() {
    var a = window._AdformContent;
    if (a && !Od) {
      Od = !0;
      var b = window.screen,
        c = Y.screenSize,
        d = Y.maxSize,
        e = (
          typeof a.element === "function" ? a.element() : Kd.documentElement
        ).getBoundingClientRect(),
        g = a.options.type,
        f = window.parent,
        k = !!Kd.createElement("video").canPlayType,
        m = Y.supportedFeatures;
      m.hasOwnProperty("inlineVideo") && (m.inlineVideo = k);
      Md = Pd[g] || Fd.UNKNOWN;
      g = Md === Fd.INTERSTITIAL;
      c.height = b.height;
      c.width = b.width;
      Y.currentPos = e;
      Y.defaultPos = {
        width: e.width || 0,
        height: e.height || 0,
        y: e.y || 0,
        x: e.x || 0,
      };
      try {
        var n = f.innerWidth;
        var t = f.innerHeight;
      } catch (u) {
        (n = window.innerWidth), (t = window.innerHeight);
      }
      d.height = t;
      d.width = n;
      W = U.DEFAULT;
      Jd(ke, Ld);
      Hd(ke, { scriptsBase: a.options.scriptsBase, isInterstitial: g });
      a.adNotice && Id(ke, a.adNotice, { isInterstitial: g });
      N.inscreen.on("change", pe);
      Qd.emit(V.READY);
    }
  }
  function ne(a) {
    return function (b, c) {
      switch (Rd.getState()) {
        case U.RESIZED:
          N.external.resize(b, c);
          break;
        case U.EXPANDED:
          qe(b, c);
          break;
        case U.DEFAULT:
          (b = a.width && a.width < b ? a.width : b),
            (c = a.height && a.height < c ? a.height : c),
            re(b, c);
      }
    };
  }
  function pe() {
    var a = Nd !== N.inscreen.visible;
    Y.viewablePercentage = N.inscreen.percent;
    Nd = N.inscreen.visible;
    a && Qd.emit(V.VIEWABLE_CHANGE, Nd);
  }
  function se(a, b) {
    N.external.resize(a.width, a.height);
    var c = Y.currentPos;
    c.width = a.width;
    c.height = a.height;
    W = b;
    te({ width: a.width, height: a.height, state: W });
  }
  function $d(a) {
    return function () {
      return h.extend({}, Y[a]);
    };
  }
  function ae(a) {
    return function (b) {
      for (var c in b) b.hasOwnProperty(c) && (Y[a][c] = b[c]);
    };
  }
  function te(a) {
    var b = a.width,
      c = a.height;
    Qd.emit(V.STATE_CHANGE, a.state);
    Qd.emit(V.SIZE_CHANGE, b, c);
  }
  function qe(a, b) {
    N.external.setLayout(
      {
        width: a,
        height: b,
        from: window.parent,
        type: "fixed",
        position: "MC",
      },
      !0
    );
  }
  function re(a, b) {
    var c,
      d = (c = window._AdformContent) == null ? void 0 : c._adbox;
    N.external.setLayout({ width: a, height: b, position: "C" }, !0);
    d && d.css("margin:auto;");
  }
  function ee() {
    se(Y.resizeProperties, U.RESIZED);
  }
  function de(a) {
    Y.expandProperties.useCustomClose = a;
    var b;
    (b = ke.getCloseButton && ke.getCloseButton()) == null || b.show();
  }
  function ce(a) {
    a &&
      (a.preventDefault && a.preventDefault(),
      a.stopImmediatePropagation && a.stopImmediatePropagation(),
      a.stopPropagation && a.stopPropagation());
    switch (W) {
      case U.EXPANDED:
        if (W === U.EXPANDED) {
          var b = Y.defaultPos;
          a = b.width;
          b = b.height;
          re(a, b);
          W = U.DEFAULT;
          te({ width: a, height: b, state: U.DEFAULT });
        }
        break;
      case U.RESIZED:
        se(Y.defaultPos, U.DEFAULT);
        break;
      case U.DEFAULT:
        Md === Fd.INTERSTITIAL &&
          (N.external.close(), (W = U.HIDDEN), Qd.emit(V.STATE_CHANGE, W));
    }
  }
  function be() {
    if (Md === Fd.INLINE) {
      var a = Y.expandProperties,
        b = a.width;
      a = a.height;
      qe(b, a);
      W = U.EXPANDED;
      b = window._AdformContent;
      a = (
        b && typeof b.element === "function" ? b.element() : Kd.documentElement
      ).getBoundingClientRect();
      b = a.width;
      a = a.height;
      te({ width: b, height: a, state: U.EXPANDED });
    }
  }
  function Vd() {
    return "2.0";
  }
  function Ud() {
    return W;
  }
  function Wd() {
    return Md;
  }
  function Xd() {
    return Nd;
  }
  function Yd() {
    return Y.viewablePercentage;
  }
  function Zd(a) {
    window.open(a, "_blank");
  }
  function Sd(a, b) {
    Qd.on(a, b);
  }
  function Td(a, b) {
    Qd.off(a, b);
  }
  function ge(a) {
    return !!Y.supportedFeatures[a];
  }
  function fe(a) {
    ge("inlineVideo") && window.open(a, "_blank");
  }
  function he() {}
  function ie() {}
  var ue = {};
  ue.build = ve;
  ue.load = we;
  function ve(a) {
    function b() {
      var p = A ? A.length : 0;
      return {
        total: p,
        totalPages: Math.ceil(p / f),
        pageSize: f,
        ids: A || [],
        limit: g,
      };
    }
    function c(p, v, J) {
      ue.load(F[p] + "&" + v, function (O, Ga) {
        O ? J(O) : J(null, xe(Ga, q, z));
      });
    }
    function d(p) {
      if (p) for (var v in p) p.hasOwnProperty(v) && (P[v] = p[v]);
    }
    var e = (window.dhtml && window.dhtml.getVar()) || {},
      g = ye(a.limit) || 100,
      f = ye(a.pageSize) || 1,
      k = ye(a.cid || e.cid),
      m = ye(a.tid || e.tid),
      n = ye(a.tv || e.tv) || +new Date(),
      t = ye(a.bn || e.bn),
      u = a.gid || e.gid || 0,
      z = a.clickTAG || "",
      q = (a.statics || a.domain || e.staticDomain || e.domain).replace(
        /\/+$/,
        ""
      ),
      I = (a.domain || e.domain).replace(/(\w+:\/\/[^/]+\/).*/, "$1"),
      F = {
        adMessage: I + "Serving/AdMessage/?",
        recommendations: I + "dco/recommendations/?",
        products: I + "dco/products/?",
      };
    k = "aid=" + k + "&tid=" + m + "&tv=" + n;
    m = ye(a.icid || e.icid) || "0";
    n = e.unloadID || "0";
    I = e.geo || "0;0;0";
    var K = a.eshopId || e.trackingSetupId || "0",
      H = e.ADFbanID || "0",
      R = ye(a.rotseqno || e.rotseqno),
      l = a.smid || e.smid,
      G = a.dcoEngineId || e.dcoEngineId;
    e.versionListId && (k += "&versionListId=" + e.versionListId);
    e.versionId && (k += "&versionId=" + e.versionId);
    m && (k += "&icid=" + m);
    K && (k += "&eid=" + K);
    R && (k += "&rotseqno=" + R);
    l && (k += "&smid=" + l);
    G && (k += "&dco=" + G);
    H && (k += "&bnrid=" + H);
    n && (k += "&intid=" + n);
    I && (k += "&geo=" + I.split(";").join(","));
    for (var X in F) F[X] += k;
    var P = {},
      A,
      B = 0,
      mb = ze(
        100,
        function (p, v) {
          p *= f;
          var J = p + f * 2;
          B = Math.max(B, J);
          if (A)
            if (((p = A.slice(p, J)), p.length)) v(null, p, b());
            else
              try {
                throw Error("AdMessage page not found.");
              } catch (O) {
                v(O);
              }
        },
        function (p) {
          c(
            G ? "recommendations" : "adMessage",
            "bn=" + t + "&gcnt=" + g + "&pgsz=" + Math.min(B, g),
            function (v, J) {
              if (v) p(v);
              else if ((d(J.items), (A = J.ids) && A.length)) p();
              else
                try {
                  throw Error("AdMessage template doesn't contain groups.");
                } catch (O) {
                  p(O);
                }
            }
          );
          B = 0;
        }
      ),
      w = {},
      ba = [],
      Ya = ze(
        100,
        function (p, v) {
          for (
            var J = p._test || 0, O = [], Ga = 0, Ce = p.length, Xa, Pc;
            Ga < Ce;
            Ga++
          )
            (Pc = P[(Xa = p[Ga])])
              ? O.push(Pc)
              : w[Xa] || ((w[Xa] = !0), ba.push(Xa));
          p._test = ++J;
          if (O.length == p.length) v(null, O, b());
          else if (J > 4)
            try {
              throw Error(
                "AdMessage group" +
                  ((p.length > 1 ? 's "' : ' "') + p.join(", ")) +
                  '" not found.'
              );
            } catch (De) {
              v(De);
            }
        },
        function (p) {
          ba.length
            ? c(
                G ? "products" : "adMessage",
                "bn=" + t + "&gid=" + ba.join(","),
                function (v, J) {
                  w = {};
                  v ? p(v) : (d(J.items), p());
                }
              )
            : setTimeout(function () {
                p();
              }, 100);
          ba = [];
        }
      );
    e.dynamicAdContent && d(xe(e.dynamicAdContent, q, z).items);
    return {
      setProperties: function (p) {
        var v = p.pageSize >> 0 || f;
        p = p.limit >> 0 || g;
        p > 0 && (g = p);
        v > 0 && (f = Math.min(v, g));
      },
      getProperties: b,
      getPage: function (p, v) {
        mb((p >> 0) - 1, function (J, O) {
          J ? v(J) : (Ya(O.slice(0, f), v), Ya(O.slice(f), Ae));
        });
      },
      getItems: function (p, v) {
        Ya(h.isArray(p) ? p : [p], v);
      },
      getDefault: function (p) {
        Ya([u], function (v, J, O) {
          p(v, J && J[0], O);
        });
      },
    };
  }
  function ye(a) {
    return parseInt(a, 10) ? a : 0;
  }
  function Ae() {}
  function ze(a, b, c) {
    function d() {
      f = !1;
      var k = g;
      g = [];
      c(function (m) {
        for (var n = 0; n < k.length; n++)
          if (m) k[n][1](m);
          else e(k[n][0], k[n][1]);
      });
    }
    function e(k, m) {
      var n = !1;
      b(k, function () {
        n = !0;
        m.apply(this, arguments);
      });
      n || (g.push([k, m]), f || (f = setTimeout(d, a)));
    }
    var g = [],
      f = !1;
    return e;
  }
  function Be(a, b, c) {
    var d = a["@id"] || 0;
    var e = a["@pdata"] || "";
    var g = {
      $id: d,
      $name: a["@name"] || "default",
      $link: c.replace(/adfibeg=\d+/, e ? "pdata=" + e : "adfibeg=" + d),
      $pdata: e,
    };
    if (a.TextVars)
      for (
        c = 0,
          d = a.TextVars.TextVar,
          e = d.length,
          h.isArray(d) || ((d = [d]), (e = 1));
        c < e;
        c++
      ) {
        var f = d[c];
        var k = f["@name"];
        f = f["@value"];
        g[k] = f;
        k == "product_deeplink" &&
          (g.$link += ";cpdir=" + encodeURIComponent(f));
      }
    if (a.Graphics)
      for (
        c = 0,
          d = a.Graphics.Graphic,
          e = d.length,
          h.isArray(d) || ((d = [d]), (e = 1));
        c < e;
        c++
      )
        (f = d[c]),
          (g[f["@name"]] =
            b + f["@value"] + "?assetID=" + f["@assetID"] + "&av=" + f["@av"]);
    return g;
  }
  function xe(a, b, c) {
    var d = a.root;
    a = {};
    if (d.TextVars || d.Graphics) a[0] = a[""] = Be(d, b, c);
    if (d.Groups) {
      var e = 0,
        g = d.Groups.Group,
        f;
      h.isArray(g) || (g = [g]);
      for (f = g.length; e < f; e++) {
        var k = Be(g[e], b, c);
        a[k.$id] = k;
      }
    }
    b = d.GroupIds ? d.GroupIds.split(",") : [];
    return { ids: b, items: a, total: b.length };
  }
  function we(a, b) {
    function c(k) {
      e();
      b(null, k);
    }
    function d() {
      e();
      try {
        throw Error("AdMessage load error.");
      } catch (k) {
        b(k);
      }
    }
    function e() {
      f.parentNode.removeChild(f);
      window[g] = f.onerror = f.onload = d = c = e = f = null;
    }
    var g = h.gid("adform_com_"),
      f = document.createElement("script");
    f.type = "text/javascript";
    f.src = a + "&format=json&callback=" + encodeURIComponent(g);
    f.onload = f.onerror = function () {
      setTimeout(d, 1e3);
    };
    window[g] = c;
    a = h.byTag(document, "script")[0];
    a.parentNode.insertBefore(f, a);
  }
  var Z = (window.Adform = window.Adform || {});
  Z.tagData = Z.tagData || Ad;
  Z.trackingUrlBase =
    Z.trackingUrlBase || N.getVar("adServerUrlBase", "https://a1.adform.net");
  Z.assetsUrlBase = Z.assetsUrlBase || N.getVar("staticDomain");
  Z.Log || (Z.Log = {});
  Z.Log.pushMessage || (Z.Log.pushMessage = function () {});
  Z.Log.sendMessage || (Z.Log.sendMessage = function () {});
  Z.RMB = Z.RMB || {};
  var Ee = Z.RMB;
  Ee.EventEmitter = x;
  Ee.DOMEvents = Gb;
  Z.lib || (Z.lib = h);
  Ee.lib = Ee.lib || h;
  Z.AdMessage = Z.AdMessage || ue;
  Z.EventEmitter = Z.EventEmitter || x;
  window.dhtml = N;
  window.mraid = me;
  N.getVar("tid") && (N.adMessage = ue.build({ limit: 100, pageSize: 5 }));
})(window);
