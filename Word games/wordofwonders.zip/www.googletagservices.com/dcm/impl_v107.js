(function () {
  var ca =
      typeof Object.create == "function"
        ? Object.create
        : function (a) {
            var b = function () {};
            b.prototype = a;
            return new b();
          },
    da =
      typeof Object.defineProperties == "function"
        ? Object.defineProperty
        : function (a, b, c) {
            if (a == Array.prototype || a == Object.prototype) return a;
            a[b] = c.value;
            return a;
          },
    ea = function (a) {
      a = [
        "object" == typeof globalThis && globalThis,
        a,
        "object" == typeof window && window,
        "object" == typeof self && self,
        "object" == typeof global && global,
      ];
      for (var b = 0; b < a.length; ++b) {
        var c = a[b];
        if (c && c.Math == Math) return c;
      }
      throw Error("Cannot find global object");
    },
    fa = ea(this),
    q = function (a, b) {
      if (b)
        a: {
          var c = fa;
          a = a.split(".");
          for (var d = 0; d < a.length - 1; d++) {
            var e = a[d];
            if (!(e in c)) break a;
            c = c[e];
          }
          a = a[a.length - 1];
          d = c[a];
          b = b(d);
          b != d &&
            b != null &&
            da(c, a, { configurable: !0, writable: !0, value: b });
        }
    },
    ha;
  if (typeof Object.setPrototypeOf == "function") ha = Object.setPrototypeOf;
  else {
    var ia;
    a: {
      var ma = { a: !0 },
        na = {};
      try {
        na.__proto__ = ma;
        ia = na.a;
        break a;
      } catch (a) {}
      ia = !1;
    }
    ha = ia
      ? function (a, b) {
          a.__proto__ = b;
          if (a.__proto__ !== b) throw new TypeError(a + " is not extensible");
          return a;
        }
      : null;
  }
  var oa = ha,
    r = function (a, b) {
      a.prototype = ca(b.prototype);
      a.prototype.constructor = a;
      if (oa) oa(a, b);
      else
        for (var c in b)
          if (c != "prototype")
            if (Object.defineProperties) {
              var d = Object.getOwnPropertyDescriptor(b, c);
              d && Object.defineProperty(a, c, d);
            } else a[c] = b[c];
      a.qb = b.prototype;
    },
    pa = function (a) {
      var b = 0;
      return function () {
        return b < a.length ? { done: !1, value: a[b++] } : { done: !0 };
      };
    },
    t = function (a) {
      var b =
        typeof Symbol != "undefined" && Symbol.iterator && a[Symbol.iterator];
      if (b) return b.call(a);
      if (typeof a.length == "number") return { next: pa(a) };
      throw Error(String(a) + " is not an iterable or ArrayLike");
    },
    ra = function (a) {
      return qa(a, a);
    },
    qa = function (a, b) {
      a.raw = b;
      Object.freeze && (Object.freeze(a), Object.freeze(b));
      return a;
    },
    sa = function () {
      for (var a = Number(this), b = [], c = a; c < arguments.length; c++)
        b[c - a] = arguments[c];
      return b;
    };
  q("globalThis", function (a) {
    return a || fa;
  });
  q("Symbol", function (a) {
    if (a) return a;
    var b = function (h, k) {
      this.h = h;
      da(this, "description", { configurable: !0, writable: !0, value: k });
    };
    b.prototype.toString = function () {
      return this.h;
    };
    var c = "jscomp_symbol_" + ((Math.random() * 1e9) >>> 0) + "_",
      d = 0,
      e = function (h) {
        if (this instanceof e)
          throw new TypeError("Symbol is not a constructor");
        return new b(c + (h || "") + "_" + d++, h);
      };
    return e;
  });
  q("Symbol.iterator", function (a) {
    if (a) return a;
    a = Symbol("Symbol.iterator");
    da(Array.prototype, a, {
      configurable: !0,
      writable: !0,
      value: function () {
        return ta(pa(this));
      },
    });
    return a;
  });
  var ta = function (a) {
    a = { next: a };
    a[Symbol.iterator] = function () {
      return this;
    };
    return a;
  };
  q("Promise", function (a) {
    function b() {
      this.h = null;
    }
    function c(k) {
      return k instanceof e
        ? k
        : new e(function (f) {
            f(k);
          });
    }
    if (a) return a;
    b.prototype.i = function (k) {
      if (this.h == null) {
        this.h = [];
        var f = this;
        this.j(function () {
          f.m();
        });
      }
      this.h.push(k);
    };
    var d = fa.setTimeout;
    b.prototype.j = function (k) {
      d(k, 0);
    };
    b.prototype.m = function () {
      for (; this.h && this.h.length; ) {
        var k = this.h;
        this.h = [];
        for (var f = 0; f < k.length; ++f) {
          var g = k[f];
          k[f] = null;
          try {
            g();
          } catch (l) {
            this.l(l);
          }
        }
      }
      this.h = null;
    };
    b.prototype.l = function (k) {
      this.j(function () {
        throw k;
      });
    };
    var e = function (k) {
      this.i = 0;
      this.j = void 0;
      this.h = [];
      this.v = !1;
      var f = this.l();
      try {
        k(f.resolve, f.reject);
      } catch (g) {
        f.reject(g);
      }
    };
    e.prototype.l = function () {
      function k(l) {
        return function (m) {
          g || ((g = !0), l.call(f, m));
        };
      }
      var f = this,
        g = !1;
      return { resolve: k(this.H), reject: k(this.m) };
    };
    e.prototype.H = function (k) {
      if (k === this)
        this.m(new TypeError("A Promise cannot resolve to itself"));
      else if (k instanceof e) this.K(k);
      else {
        a: switch (typeof k) {
          case "object":
            var f = k != null;
            break a;
          case "function":
            f = !0;
            break a;
          default:
            f = !1;
        }
        f ? this.G(k) : this.u(k);
      }
    };
    e.prototype.G = function (k) {
      var f = void 0;
      try {
        f = k.then;
      } catch (g) {
        this.m(g);
        return;
      }
      typeof f == "function" ? this.L(f, k) : this.u(k);
    };
    e.prototype.m = function (k) {
      this.C(2, k);
    };
    e.prototype.u = function (k) {
      this.C(1, k);
    };
    e.prototype.C = function (k, f) {
      if (this.i != 0)
        throw Error(
          "Cannot settle(" +
            k +
            ", " +
            f +
            "): Promise already settled in state" +
            this.i
        );
      this.i = k;
      this.j = f;
      this.i === 2 && this.I();
      this.D();
    };
    e.prototype.I = function () {
      var k = this;
      d(function () {
        if (k.F()) {
          var f = fa.console;
          typeof f !== "undefined" && f.error(k.j);
        }
      }, 1);
    };
    e.prototype.F = function () {
      if (this.v) return !1;
      var k = fa.CustomEvent,
        f = fa.Event,
        g = fa.dispatchEvent;
      if (typeof g === "undefined") return !0;
      typeof k === "function"
        ? (k = new k("unhandledrejection", { cancelable: !0 }))
        : typeof f === "function"
        ? (k = new f("unhandledrejection", { cancelable: !0 }))
        : ((k = fa.document.createEvent("CustomEvent")),
          k.initCustomEvent("unhandledrejection", !1, !0, k));
      k.promise = this;
      k.reason = this.j;
      return g(k);
    };
    e.prototype.D = function () {
      if (this.h != null) {
        for (var k = 0; k < this.h.length; ++k) h.i(this.h[k]);
        this.h = null;
      }
    };
    var h = new b();
    e.prototype.K = function (k) {
      var f = this.l();
      k.X(f.resolve, f.reject);
    };
    e.prototype.L = function (k, f) {
      var g = this.l();
      try {
        k.call(f, g.resolve, g.reject);
      } catch (l) {
        g.reject(l);
      }
    };
    e.prototype.then = function (k, f) {
      function g(p, u) {
        return typeof p == "function"
          ? function (A) {
              try {
                l(p(A));
              } catch (y) {
                m(y);
              }
            }
          : u;
      }
      var l,
        m,
        n = new e(function (p, u) {
          l = p;
          m = u;
        });
      this.X(g(k, l), g(f, m));
      return n;
    };
    e.prototype.catch = function (k) {
      return this.then(void 0, k);
    };
    e.prototype.X = function (k, f) {
      function g() {
        switch (l.i) {
          case 1:
            k(l.j);
            break;
          case 2:
            f(l.j);
            break;
          default:
            throw Error("Unexpected state: " + l.i);
        }
      }
      var l = this;
      this.h == null ? h.i(g) : this.h.push(g);
      this.v = !0;
    };
    e.resolve = c;
    e.reject = function (k) {
      return new e(function (f, g) {
        g(k);
      });
    };
    e.race = function (k) {
      return new e(function (f, g) {
        for (var l = t(k), m = l.next(); !m.done; m = l.next())
          c(m.value).X(f, g);
      });
    };
    e.all = function (k) {
      var f = t(k),
        g = f.next();
      return g.done
        ? c([])
        : new e(function (l, m) {
            function n(A) {
              return function (y) {
                p[A] = y;
                u--;
                u == 0 && l(p);
              };
            }
            var p = [],
              u = 0;
            do
              p.push(void 0),
                u++,
                c(g.value).X(n(p.length - 1), m),
                (g = f.next());
            while (!g.done);
          });
    };
    return e;
  });
  var v = function (a, b) {
    return Object.prototype.hasOwnProperty.call(a, b);
  };
  q("Symbol.dispose", function (a) {
    return a ? a : Symbol("Symbol.dispose");
  });
  q("WeakMap", function (a) {
    function b() {}
    function c(g) {
      var l = typeof g;
      return (l === "object" && g !== null) || l === "function";
    }
    function d(g) {
      if (!v(g, h)) {
        var l = new b();
        da(g, h, { value: l });
      }
    }
    function e(g) {
      var l = Object[g];
      l &&
        (Object[g] = function (m) {
          if (m instanceof b) return m;
          Object.isExtensible(m) && d(m);
          return l(m);
        });
    }
    if (
      (function () {
        if (!a || !Object.seal) return !1;
        try {
          var g = Object.seal({}),
            l = Object.seal({}),
            m = new a([
              [g, 2],
              [l, 3],
            ]);
          if (m.get(g) != 2 || m.get(l) != 3) return !1;
          m.delete(g);
          m.set(l, 4);
          return !m.has(g) && m.get(l) == 4;
        } catch (n) {
          return !1;
        }
      })()
    )
      return a;
    var h = "$jscomp_hidden_" + Math.random();
    e("freeze");
    e("preventExtensions");
    e("seal");
    var k = 0,
      f = function (g) {
        this.h = (k += Math.random() + 1).toString();
        if (g) {
          g = t(g);
          for (var l; !(l = g.next()).done; )
            (l = l.value), this.set(l[0], l[1]);
        }
      };
    f.prototype.set = function (g, l) {
      if (!c(g)) throw Error("Invalid WeakMap key");
      d(g);
      if (!v(g, h)) throw Error("WeakMap key fail: " + g);
      g[h][this.h] = l;
      return this;
    };
    f.prototype.get = function (g) {
      return c(g) && v(g, h) ? g[h][this.h] : void 0;
    };
    f.prototype.has = function (g) {
      return c(g) && v(g, h) && v(g[h], this.h);
    };
    f.prototype.delete = function (g) {
      return c(g) && v(g, h) && v(g[h], this.h) ? delete g[h][this.h] : !1;
    };
    return f;
  });
  q("Map", function (a) {
    if (
      (function () {
        if (
          !a ||
          typeof a != "function" ||
          !a.prototype.entries ||
          typeof Object.seal != "function"
        )
          return !1;
        try {
          var f = Object.seal({ x: 4 }),
            g = new a(t([[f, "s"]]));
          if (
            g.get(f) != "s" ||
            g.size != 1 ||
            g.get({ x: 4 }) ||
            g.set({ x: 4 }, "t") != g ||
            g.size != 2
          )
            return !1;
          var l = g.entries(),
            m = l.next();
          if (m.done || m.value[0] != f || m.value[1] != "s") return !1;
          m = l.next();
          return m.done ||
            m.value[0].x != 4 ||
            m.value[1] != "t" ||
            !l.next().done
            ? !1
            : !0;
        } catch (n) {
          return !1;
        }
      })()
    )
      return a;
    var b = new WeakMap(),
      c = function (f) {
        this[0] = {};
        this[1] = h();
        this.size = 0;
        if (f) {
          f = t(f);
          for (var g; !(g = f.next()).done; )
            (g = g.value), this.set(g[0], g[1]);
        }
      };
    c.prototype.set = function (f, g) {
      f = f === 0 ? 0 : f;
      var l = d(this, f);
      l.list || (l.list = this[0][l.id] = []);
      l.entry
        ? (l.entry.value = g)
        : ((l.entry = {
            next: this[1],
            J: this[1].J,
            head: this[1],
            key: f,
            value: g,
          }),
          l.list.push(l.entry),
          (this[1].J.next = l.entry),
          (this[1].J = l.entry),
          this.size++);
      return this;
    };
    c.prototype.delete = function (f) {
      f = d(this, f);
      return f.entry && f.list
        ? (f.list.splice(f.index, 1),
          f.list.length || delete this[0][f.id],
          (f.entry.J.next = f.entry.next),
          (f.entry.next.J = f.entry.J),
          (f.entry.head = null),
          this.size--,
          !0)
        : !1;
    };
    c.prototype.clear = function () {
      this[0] = {};
      this[1] = this[1].J = h();
      this.size = 0;
    };
    c.prototype.has = function (f) {
      return !!d(this, f).entry;
    };
    c.prototype.get = function (f) {
      return (f = d(this, f).entry) && f.value;
    };
    c.prototype.entries = function () {
      return e(this, function (f) {
        return [f.key, f.value];
      });
    };
    c.prototype.keys = function () {
      return e(this, function (f) {
        return f.key;
      });
    };
    c.prototype.values = function () {
      return e(this, function (f) {
        return f.value;
      });
    };
    c.prototype.forEach = function (f, g) {
      for (var l = this.entries(), m; !(m = l.next()).done; )
        (m = m.value), f.call(g, m[1], m[0], this);
    };
    c.prototype[Symbol.iterator] = c.prototype.entries;
    var d = function (f, g) {
        var l = g && typeof g;
        l == "object" || l == "function"
          ? b.has(g)
            ? (l = b.get(g))
            : ((l = "" + ++k), b.set(g, l))
          : (l = "p_" + g);
        var m = f[0][l];
        if (m && v(f[0], l))
          for (f = 0; f < m.length; f++) {
            var n = m[f];
            if ((g !== g && n.key !== n.key) || g === n.key)
              return { id: l, list: m, index: f, entry: n };
          }
        return { id: l, list: m, index: -1, entry: void 0 };
      },
      e = function (f, g) {
        var l = f[1];
        return ta(function () {
          if (l) {
            for (; l.head != f[1]; ) l = l.J;
            for (; l.next != l.head; )
              return (l = l.next), { done: !1, value: g(l) };
            l = null;
          }
          return { done: !0, value: void 0 };
        });
      },
      h = function () {
        var f = {};
        return (f.J = f.next = f.head = f);
      },
      k = 0;
    return c;
  });
  q("Object.values", function (a) {
    return a
      ? a
      : function (b) {
          var c = [],
            d;
          for (d in b) v(b, d) && c.push(b[d]);
          return c;
        };
  });
  q("Object.is", function (a) {
    return a
      ? a
      : function (b, c) {
          return b === c ? b !== 0 || 1 / b === 1 / c : b !== b && c !== c;
        };
  });
  q("Array.prototype.includes", function (a) {
    return a
      ? a
      : function (b, c) {
          var d = this;
          d instanceof String && (d = String(d));
          var e = d.length;
          c = c || 0;
          for (c < 0 && (c = Math.max(c + e, 0)); c < e; c++) {
            var h = d[c];
            if (h === b || Object.is(h, b)) return !0;
          }
          return !1;
        };
  });
  var ua = function (a, b, c) {
    if (a == null)
      throw new TypeError(
        "The 'this' value for String.prototype." +
          c +
          " must not be null or undefined"
      );
    if (b instanceof RegExp)
      throw new TypeError(
        "First argument to String.prototype." +
          c +
          " must not be a regular expression"
      );
    return a + "";
  };
  q("String.prototype.includes", function (a) {
    return a
      ? a
      : function (b, c) {
          return ua(this, b, "includes").indexOf(b, c || 0) !== -1;
        };
  });
  q("Number.isFinite", function (a) {
    return a
      ? a
      : function (b) {
          return typeof b !== "number"
            ? !1
            : !isNaN(b) && b !== Infinity && b !== -Infinity;
        };
  });
  q("Number.MAX_SAFE_INTEGER", function () {
    return 9007199254740991;
  });
  q("Number.MIN_SAFE_INTEGER", function () {
    return -9007199254740991;
  });
  q("Number.isInteger", function (a) {
    return a
      ? a
      : function (b) {
          return Number.isFinite(b) ? b === Math.floor(b) : !1;
        };
  });
  q("Number.isSafeInteger", function (a) {
    return a
      ? a
      : function (b) {
          return Number.isInteger(b) && Math.abs(b) <= Number.MAX_SAFE_INTEGER;
        };
  });
  var va = function (a, b) {
    a instanceof String && (a += "");
    var c = 0,
      d = !1,
      e = {
        next: function () {
          if (!d && c < a.length) {
            var h = c++;
            return { value: b(h, a[h]), done: !1 };
          }
          d = !0;
          return { done: !0, value: void 0 };
        },
      };
    e[Symbol.iterator] = function () {
      return e;
    };
    return e;
  };
  q("Math.trunc", function (a) {
    return a
      ? a
      : function (b) {
          b = Number(b);
          if (isNaN(b) || b === Infinity || b === -Infinity || b === 0)
            return b;
          var c = Math.floor(Math.abs(b));
          return b < 0 ? -c : c;
        };
  });
  q("Number.isNaN", function (a) {
    return a
      ? a
      : function (b) {
          return typeof b === "number" && isNaN(b);
        };
  });
  q("Array.prototype.keys", function (a) {
    return a
      ? a
      : function () {
          return va(this, function (b) {
            return b;
          });
        };
  });
  q("Array.prototype.values", function (a) {
    return a
      ? a
      : function () {
          return va(this, function (b, c) {
            return c;
          });
        };
  });
  q("String.prototype.repeat", function (a) {
    return a
      ? a
      : function (b) {
          var c = ua(this, null, "repeat");
          if (b < 0 || b > 1342177279)
            throw new RangeError("Invalid count value");
          b |= 0;
          for (var d = ""; b; ) if ((b & 1 && (d += c), (b >>>= 1))) c += c;
          return d;
        };
  });
  q("String.prototype.padStart", function (a) {
    return a
      ? a
      : function (b, c) {
          var d = ua(this, null, "padStart");
          b -= d.length;
          c = c !== void 0 ? String(c) : " ";
          return (
            (b > 0 && c
              ? c.repeat(Math.ceil(b / c.length)).substring(0, b)
              : "") + d
          );
        };
  }); /*

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/
  var w = this || self,
    wa = function (a, b) {
      a: {
        var c = ["CLOSURE_FLAGS"];
        for (var d = w, e = 0; e < c.length; e++)
          if (((d = d[c[e]]), d == null)) {
            c = null;
            break a;
          }
        c = d;
      }
      a = c && c[a];
      return a != null ? a : b;
    },
    xa = function (a) {
      var b = typeof a;
      return (b == "object" && a != null) || b == "function";
    },
    ya = function (a, b) {
      var c = Array.prototype.slice.call(arguments, 1);
      return function () {
        var d = c.slice();
        d.push.apply(d, arguments);
        return a.apply(this, d);
      };
    };
  function za(a) {
    w.setTimeout(function () {
      throw a;
    }, 0);
  }
  var Aa = wa(610401301, !1),
    Ea = wa(748402147, !0);
  function Fa() {
    var a = w.navigator;
    return a && (a = a.userAgent) ? a : "";
  }
  var x,
    Ga = w.navigator;
  x = Ga ? Ga.userAgentData || null : null;
  function Ha(a) {
    if (!Aa || !x) return !1;
    for (var b = 0; b < x.brands.length; b++) {
      var c = x.brands[b].brand;
      if (c && c.indexOf(a) != -1) return !0;
    }
    return !1;
  }
  function B(a) {
    return Fa().indexOf(a) != -1;
  }
  function Ia() {
    return Aa ? !!x && x.brands.length > 0 : !1;
  }
  function Ja() {
    return Ia() ? !1 : B("Opera");
  }
  function Ka() {
    return B("Firefox") || B("FxiOS");
  }
  function La() {
    return Ia()
      ? Ha("Chromium")
      : ((B("Chrome") || B("CriOS")) && !(Ia() ? 0 : B("Edge"))) || B("Silk");
  }
  function Ma() {
    return Aa ? !!x && !!x.platform : !1;
  }
  function Na() {
    return B("iPhone") && !B("iPod") && !B("iPad");
  }
  function Oa() {
    Na() || B("iPad") || B("iPod");
  }
  var Pa = Array.prototype.indexOf
      ? function (a, b) {
          return Array.prototype.indexOf.call(a, b, void 0);
        }
      : function (a, b) {
          if (typeof a === "string")
            return typeof b !== "string" || b.length != 1
              ? -1
              : a.indexOf(b, 0);
          for (var c = 0; c < a.length; c++) if (c in a && a[c] === b) return c;
          return -1;
        },
    Qa = Array.prototype.forEach
      ? function (a, b) {
          Array.prototype.forEach.call(a, b, void 0);
        }
      : function (a, b) {
          for (
            var c = a.length,
              d = typeof a === "string" ? a.split("") : a,
              e = 0;
            e < c;
            e++
          )
            e in d && b.call(void 0, d[e], e, a);
        },
    Ra = Array.prototype.map
      ? function (a, b) {
          return Array.prototype.map.call(a, b, void 0);
        }
      : function (a, b) {
          for (
            var c = a.length,
              d = Array(c),
              e = typeof a === "string" ? a.split("") : a,
              h = 0;
            h < c;
            h++
          )
            h in e && (d[h] = b.call(void 0, e[h], h, a));
          return d;
        },
    Sa = Array.prototype.reduce
      ? function (a, b, c) {
          return Array.prototype.reduce.call(a, b, c);
        }
      : function (a, b, c) {
          var d = c;
          Qa(a, function (e, h) {
            d = b.call(void 0, d, e, h, a);
          });
          return d;
        };
  function Ta(a) {
    for (var b = [], c = 0; c < a; c++) b[c] = "";
    return b;
  }
  var Ua = function (a) {
    Ua[" "](a);
    return a;
  };
  Ua[" "] = function () {};
  Ja();
  Ia() || B("Trident") || B("MSIE");
  B("Edge");
  !B("Gecko") ||
    (Fa().toLowerCase().indexOf("webkit") != -1 && !B("Edge")) ||
    B("Trident") ||
    B("MSIE") ||
    B("Edge");
  var Va = Fa().toLowerCase().indexOf("webkit") != -1 && !B("Edge");
  Va && B("Mobile");
  Ma() || B("Macintosh");
  Ma() || B("Windows");
  (Ma() ? x.platform === "Linux" : B("Linux")) || Ma() || B("CrOS");
  Ma() || B("Android");
  Na();
  B("iPad");
  B("iPod");
  Oa();
  Fa().toLowerCase().indexOf("kaios");
  Ka();
  Na() || B("iPod");
  B("iPad");
  !B("Android") || La() || Ka() || Ja() || B("Silk");
  La();
  !B("Safari") ||
    La() ||
    (Ia() ? 0 : B("Coast")) ||
    Ja() ||
    (Ia() ? 0 : B("Edge")) ||
    (Ia() ? Ha("Microsoft Edge") : B("Edg/")) ||
    (Ia() ? Ha("Opera") : B("OPR")) ||
    Ka() ||
    B("Silk") ||
    B("Android") ||
    Oa();
  var Za = {},
    $a = null;
  function db(a) {
    var b = [];
    eb(a, function (c) {
      b.push(c);
    });
    return b;
  }
  function eb(a, b) {
    function c(g) {
      for (; d < a.length; ) {
        var l = a.charAt(d++),
          m = $a[l];
        if (m != null) return m;
        if (!/^[\s\xa0]*$/.test(l))
          throw Error("Unknown base64 encoding at char: " + l);
      }
      return g;
    }
    fb();
    for (var d = 0; ; ) {
      var e = c(-1),
        h = c(0),
        k = c(64),
        f = c(64);
      if (f === 64 && e === -1) break;
      b((e << 2) | (h >> 4));
      k != 64 &&
        (b(((h << 4) & 240) | (k >> 2)), f != 64 && b(((k << 6) & 192) | f));
    }
  }
  function fb() {
    if (!$a) {
      $a = {};
      for (
        var a =
            "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(
              ""
            ),
          b = ["+/=", "+/", "-_=", "-_.", "-_"],
          c = 0;
        c < 5;
        c++
      ) {
        var d = a.concat(b[c].split(""));
        Za[c] = d;
        for (var e = 0; e < d.length; e++) {
          var h = d[e];
          $a[h] === void 0 && ($a[h] = e);
        }
      }
    }
  }
  function gb(a, b) {
    a.__closure__error__context__984382 ||
      (a.__closure__error__context__984382 = {});
    a.__closure__error__context__984382.severity = b;
  }
  var hb = void 0;
  function ib(a) {
    a = Error(a);
    gb(a, "warning");
    return a;
  }
  function jb() {
    return typeof BigInt === "function";
  }
  var kb = typeof Symbol === "function" && typeof Symbol() === "symbol";
  function lb(a, b, c) {
    return typeof Symbol === "function" && typeof Symbol() === "symbol"
      ? (c === void 0 ? 0 : c) && Symbol.for && a
        ? Symbol.for(a)
        : a != null
        ? Symbol(a)
        : Symbol()
      : b;
  }
  var mb = lb("jas", void 0, !0),
    nb = lb(void 0, "0actk"),
    ob = lb("m_m", "pb", !0);
  var pb = { Ba: { value: 0, configurable: !0, writable: !0, enumerable: !1 } },
    qb = Object.defineProperties,
    D = kb ? mb : "Ba",
    rb,
    sb = [];
  E(sb, 7);
  rb = Object.freeze(sb);
  function tb(a, b) {
    kb || D in a || qb(a, pb);
    a[D] |= b;
  }
  function E(a, b) {
    kb || D in a || qb(a, pb);
    a[D] = b;
  }
  var ub = {};
  function F(a, b) {
    return b === void 0
      ? a.h !== vb && !!(2 & (a.o[D] | 0))
      : !!(2 & b) && a.h !== vb;
  }
  var vb = {},
    wb = Object.freeze({});
  function xb(a) {
    a.ob = !0;
    return a;
  }
  var yb = xb(function (a) {
      return typeof a === "number";
    }),
    zb = xb(function (a) {
      return typeof a === "string";
    }),
    Ab = xb(function (a) {
      return typeof a === "boolean";
    });
  var Bb = typeof w.BigInt === "function" && typeof w.BigInt(0) === "bigint";
  function Cb(a) {
    var b = a;
    if (zb(b)) {
      if (!/^\s*(?:-?[1-9]\d*|0)?\s*$/.test(b)) throw Error(String(b));
    } else if (yb(b) && !Number.isSafeInteger(b)) throw Error(String(b));
    return Bb
      ? BigInt(a)
      : (a = Ab(a) ? (a ? "1" : "0") : zb(a) ? a.trim() || "0" : String(a));
  }
  var Mb = xb(function (a) {
      return Bb ? a >= Db && a <= Fb : a[0] === "-" ? Gb(a, Kb) : Gb(a, Lb);
    }),
    Kb = Number.MIN_SAFE_INTEGER.toString(),
    Db = Bb ? BigInt(Number.MIN_SAFE_INTEGER) : void 0,
    Lb = Number.MAX_SAFE_INTEGER.toString(),
    Fb = Bb ? BigInt(Number.MAX_SAFE_INTEGER) : void 0;
  function Gb(a, b) {
    if (a.length > b.length) return !1;
    if (a.length < b.length || a === b) return !0;
    for (var c = 0; c < a.length; c++) {
      var d = a[c],
        e = b[c];
      if (d > e) return !1;
      if (d < e) return !0;
    }
  }
  var G = 0,
    H = 0;
  function Nb(a) {
    var b = a >>> 0;
    G = b;
    H = ((a - b) / 4294967296) >>> 0;
  }
  function Ob(a) {
    if (a < 0) {
      Nb(-a);
      var b = t(Pb(G, H));
      a = b.next().value;
      b = b.next().value;
      G = a >>> 0;
      H = b >>> 0;
    } else Nb(a);
  }
  function Qb(a, b) {
    b >>>= 0;
    a >>>= 0;
    if (b <= 2097151) var c = "" + (4294967296 * b + a);
    else
      jb()
        ? (c = "" + ((BigInt(b) << BigInt(32)) | BigInt(a)))
        : ((c = ((a >>> 24) | (b << 8)) & 16777215),
          (b = (b >> 16) & 65535),
          (a = (a & 16777215) + c * 6777216 + b * 6710656),
          (c += b * 8147497),
          (b *= 2),
          a >= 1e7 && ((c += (a / 1e7) >>> 0), (a %= 1e7)),
          c >= 1e7 && ((b += (c / 1e7) >>> 0), (c %= 1e7)),
          (c = b + Rb(c) + Rb(a)));
    return c;
  }
  function Rb(a) {
    a = String(a);
    return "0000000".slice(a.length) + a;
  }
  function Sb() {
    var a = G,
      b = H;
    b & 2147483648
      ? jb()
        ? (a = "" + ((BigInt(b | 0) << BigInt(32)) | BigInt(a >>> 0)))
        : ((b = t(Pb(a, b))),
          (a = b.next().value),
          (b = b.next().value),
          (a = "-" + Qb(a, b)))
      : (a = Qb(a, b));
    return a;
  }
  function Pb(a, b) {
    b = ~b;
    a ? (a = ~a + 1) : (b += 1);
    return [a, b];
  }
  function Tb(a) {
    return Array.prototype.slice.call(a);
  }
  var Ub = typeof BigInt === "function" ? BigInt.asIntN : void 0,
    Vb = Number.isSafeInteger,
    Wb = Number.isFinite,
    Xb = Math.trunc;
  function Yb(a) {
    if (a != null && typeof a !== "boolean") {
      var b = Error;
      var c = typeof a;
      c = c != "object" ? c : a ? (Array.isArray(a) ? "array" : c) : "null";
      throw b("Expected boolean but got " + c + ": " + a);
    }
    return a;
  }
  var Zb = /^-?([1-9][0-9]*|0)(\.[0-9]+)?$/;
  function $b(a) {
    switch (typeof a) {
      case "bigint":
        return !0;
      case "number":
        return Wb(a);
      case "string":
        return Zb.test(a);
      default:
        return !1;
    }
  }
  function ac(a) {
    if (!Wb(a)) throw ib("enum");
    return a | 0;
  }
  function bc(a) {
    return a == null ? a : Wb(a) ? a | 0 : void 0;
  }
  function cc(a) {
    if (typeof a !== "number") throw ib("int32");
    if (!Wb(a)) throw ib("int32");
    return a | 0;
  }
  function dc(a) {
    if (a == null) return a;
    if (typeof a === "string" && a) a = +a;
    else if (typeof a !== "number") return;
    return Wb(a) ? a | 0 : void 0;
  }
  function ec(a) {
    var b = void 0;
    b != null || (b = 1024);
    if (!$b(a)) throw ib("int64");
    var c = typeof a;
    switch (b) {
      case 512:
        switch (c) {
          case "string":
            return fc(a);
          case "bigint":
            return String(Ub(64, a));
          default:
            return hc(a);
        }
      case 1024:
        switch (c) {
          case "string":
            return (
              (b = Xb(Number(a))),
              Vb(b)
                ? (a = Cb(b))
                : ((b = a.indexOf(".")),
                  b !== -1 && (a = a.substring(0, b)),
                  (a = jb() ? Cb(Ub(64, BigInt(a))) : Cb(ic(a)))),
              a
            );
          case "bigint":
            return Cb(Ub(64, a));
          default:
            return Vb(a) ? Cb(jc(a)) : Cb(hc(a));
        }
      case 0:
        switch (c) {
          case "string":
            return fc(a);
          case "bigint":
            return Cb(Ub(64, a));
          default:
            return jc(a);
        }
      default:
        throw Error("Unknown format requested type for int64");
    }
  }
  function ic(a) {
    var b = a.length;
    if (
      a[0] === "-"
        ? b < 20 || (b === 20 && a <= "-9223372036854775808")
        : b < 19 || (b === 19 && a <= "9223372036854775807")
    )
      return a;
    if (a.length < 16) Ob(Number(a));
    else if (jb())
      (a = BigInt(a)),
        (G = Number(a & BigInt(4294967295)) >>> 0),
        (H = Number((a >> BigInt(32)) & BigInt(4294967295)));
    else {
      b = +(a[0] === "-");
      H = G = 0;
      for (
        var c = a.length, d = b, e = ((c - b) % 6) + b;
        e <= c;
        d = e, e += 6
      )
        (d = Number(a.slice(d, e))),
          (H *= 1e6),
          (G = G * 1e6 + d),
          G >= 4294967296 &&
            ((H += Math.trunc(G / 4294967296)), (H >>>= 0), (G >>>= 0));
      b &&
        ((b = t(Pb(G, H))),
        (a = b.next().value),
        (b = b.next().value),
        (G = a),
        (H = b));
    }
    return Sb();
  }
  function jc(a) {
    a = Xb(a);
    if (!Vb(a)) {
      Ob(a);
      var b = G,
        c = H;
      if ((a = c & 2147483648))
        (b = (~b + 1) >>> 0), (c = ~c >>> 0), b == 0 && (c = (c + 1) >>> 0);
      var d = c * 4294967296 + (b >>> 0);
      b = Number.isSafeInteger(d) ? d : Qb(b, c);
      a = typeof b === "number" ? (a ? -b : b) : a ? "-" + b : b;
    }
    return a;
  }
  function hc(a) {
    a = Xb(a);
    Vb(a) ? (a = String(a)) : (Ob(a), (a = Sb()));
    return a;
  }
  function fc(a) {
    var b = Xb(Number(a));
    if (Vb(b)) return String(b);
    b = a.indexOf(".");
    b !== -1 && (a = a.substring(0, b));
    return ic(a);
  }
  function kc(a) {
    if (a != null && typeof a !== "string") throw Error();
    return a;
  }
  function lc(a, b, c) {
    if (a != null && a[ob] === ub) return a;
    if (Array.isArray(a)) {
      var d = a[D] | 0;
      c = d | (c & 32) | (c & 2);
      c !== d && E(a, c);
      return new b(a);
    }
  }
  function mc(a) {
    return a;
  }
  function nc(a, b, c, d) {
    var e = d !== void 0;
    d = !!d;
    var h = [],
      k = a.length,
      f = 4294967295,
      g = !1,
      l = !!(b & 64),
      m = l ? (b & 128 ? 0 : -1) : void 0;
    if (!(b & 1)) {
      var n = k && a[k - 1];
      n != null && typeof n === "object" && n.constructor === Object
        ? (k--, (f = k))
        : (n = void 0);
      if (l && !(b & 128) && !e) {
        g = !0;
        var p;
        f = ((p = oc) != null ? p : mc)(f - m, m, a, n, void 0) + m;
      }
    }
    b = void 0;
    for (e = 0; e < k; e++)
      if (((p = a[e]), p != null && (p = c(p, d)) != null))
        if (l && e >= f) {
          var u = e - m,
            A = void 0;
          ((A = b) != null ? A : (b = {}))[u] = p;
        } else h[e] = p;
    if (n)
      for (var y in n)
        (a = n[y]),
          a != null &&
            (a = c(a, d)) != null &&
            ((k = +y),
            (e = void 0),
            l && !Number.isNaN(k) && (e = k + m) < f
              ? (h[e] = a)
              : ((k = void 0), (((k = b) != null ? k : (b = {}))[y] = a)));
    b && (g ? h.push(b) : (h[f] = b));
    return h;
  }
  function pc(a) {
    switch (typeof a) {
      case "number":
        return Number.isFinite(a) ? a : "" + a;
      case "bigint":
        return Mb(a) ? Number(a) : "" + a;
      case "boolean":
        return a ? 1 : 0;
      case "object":
        if (Array.isArray(a)) {
          var b = a[D] | 0;
          return a.length === 0 && b & 1 ? void 0 : nc(a, b, pc);
        }
        if (a != null && a[ob] === ub) return qc(a);
        return;
    }
    return a;
  }
  var oc;
  function qc(a) {
    a = a.o;
    return nc(a, a[D] | 0, pc);
  }
  function J(a, b, c, d) {
    d = d === void 0 ? 0 : d;
    if (a == null) {
      var e = 32;
      c ? ((a = [c]), (e |= 128)) : (a = []);
      b && (e = (e & -16760833) | ((b & 1023) << 14));
    } else {
      if (!Array.isArray(a)) throw Error("narr");
      e = a[D] | 0;
      if (Ea && 1 & e) throw Error("rfarr");
      2048 & e && !(2 & e) && rc();
      if (e & 256) throw Error("farr");
      if (e & 64) return (e | d) !== e && E(a, e | d), a;
      if (c && ((e |= 128), c !== a[0])) throw Error("mid");
      a: {
        c = a;
        e |= 64;
        var h = c.length;
        if (h) {
          var k = h - 1,
            f = c[k];
          if (f != null && typeof f === "object" && f.constructor === Object) {
            b = e & 128 ? 0 : -1;
            k -= b;
            if (k >= 1024) throw Error("pvtlmt");
            for (var g in f)
              (h = +g), h < k && ((c[h + b] = f[g]), delete f[g]);
            e = (e & -16760833) | ((k & 1023) << 14);
            break a;
          }
        }
        if (b) {
          g = Math.max(b, h - (e & 128 ? 0 : -1));
          if (g > 1024) throw Error("spvt");
          e = (e & -16760833) | ((g & 1023) << 14);
        }
      }
    }
    E(a, e | 64 | d);
    return a;
  }
  function rc() {
    if (Ea) throw Error("carr");
    if (nb != null) {
      var a;
      var b = (a = hb) != null ? a : (hb = {});
      a = b[nb] || 0;
      a >= 5 || ((b[nb] = a + 1), (b = Error()), gb(b, "incident"), za(b));
    }
  }
  function sc(a, b) {
    if (typeof a !== "object") return a;
    if (Array.isArray(a)) {
      var c = a[D] | 0;
      a.length === 0 && c & 1
        ? (a = void 0)
        : c & 2 ||
          (!b || 4096 & c || 16 & c
            ? (a = tc(a, c, !1, b && !(c & 16)))
            : (tb(a, 34), c & 4 && Object.freeze(a)));
      return a;
    }
    if (a != null && a[ob] === ub)
      return (
        (b = a.o),
        (c = b[D] | 0),
        F(a, c) ? a : uc(a, b, c) ? vc(a, b) : tc(b, c)
      );
  }
  function vc(a, b, c) {
    a = new a.constructor(b);
    c && (a.h = vb);
    a.i = vb;
    return a;
  }
  function tc(a, b, c, d) {
    d != null || (d = !!(34 & b));
    a = nc(a, b, sc, d);
    d = 32;
    c && (d |= 2);
    b = (b & 16769217) | d;
    E(a, b);
    return a;
  }
  function wc(a) {
    var b = a.o,
      c = b[D] | 0;
    return F(a, c)
      ? uc(a, b, c)
        ? vc(a, b, !0)
        : new a.constructor(tc(b, c, !1))
      : a;
  }
  function xc(a) {
    if (a.h !== vb) return !1;
    var b = a.o;
    b = tc(b, b[D] | 0);
    tb(b, 2048);
    a.o = b;
    a.h = void 0;
    a.i = void 0;
    return !0;
  }
  function yc(a) {
    if (!xc(a) && F(a, a.o[D] | 0)) throw Error();
  }
  function zc(a, b) {
    b === void 0 && (b = a[D] | 0);
    b & 32 && !(b & 4096) && E(a, b | 4096);
  }
  function uc(a, b, c) {
    return c & 2
      ? !0
      : c & 32 && !(c & 4096)
      ? (E(b, c | 2), (a.h = vb), !0)
      : !1;
  }
  var Bc = function (a, b) {
      a = Ac(a.o, b);
      if (a !== null) return a;
    },
    Ac = function (a, b, c, d) {
      if (b === -1) return null;
      var e = b + (c ? 0 : -1),
        h = a.length - 1;
      if (!(h < 1 + (c ? 0 : -1))) {
        if (e >= h) {
          var k = a[h];
          if (k != null && typeof k === "object" && k.constructor === Object) {
            c = k[b];
            var f = !0;
          } else if (e === h) c = k;
          else return;
        } else c = a[e];
        if (d && c != null) {
          d = d(c);
          if (d == null) return d;
          if (!Object.is(d, c)) return f ? (k[b] = d) : (a[e] = d), d;
        }
        return c;
      }
    },
    Cc = function (a, b, c) {
      yc(a);
      var d = a.o;
      K(d, d[D] | 0, b, c);
      return a;
    };
  function K(a, b, c, d) {
    var e = c + -1,
      h = a.length - 1;
    if (h >= 0 && e >= h) {
      var k = a[h];
      if (k != null && typeof k === "object" && k.constructor === Object)
        return (k[c] = d), b;
    }
    if (e <= h) return (a[e] = d), b;
    if (d !== void 0) {
      var f;
      h = (((f = b) != null ? f : (b = a[D] | 0)) >> 14) & 1023 || 536870912;
      c >= h
        ? d != null && ((e = {}), (a[h + -1] = ((e[c] = d), e)))
        : (a[e] = d);
    }
    return b;
  }
  function Dc(a, b, c) {
    var d = void 0 === wb ? 2 : 4,
      e = a.o,
      h = e[D] | 0,
      k = F(a, h) ? 1 : d;
    d = k === 3;
    k === 2 && xc(a) && ((e = a.o), (h = e[D] | 0));
    a = Ec(e, b);
    var f = a === rb ? 7 : a[D] | 0,
      g = Fc(f, h);
    var l = 4 & g ? !1 : !0;
    if (l) {
      4 & g && ((a = Tb(a)), (f = 0), (g = Gc(g, h)), (h = K(e, h, b, a)));
      for (var m = 0, n = 0; m < a.length; m++) {
        var p = c(a[m]);
        p != null && (a[n++] = p);
      }
      n < m && (a.length = n);
      c = (g | 4) & -513;
      g = c &= -1025;
      g &= -4097;
    }
    g !== f && (E(a, g), 2 & g && Object.freeze(a));
    return (a = Hc(a, g, e, h, b, k, l, d));
  }
  function Hc(a, b, c, d, e, h, k, f) {
    var g = b;
    h === 1 || (h !== 4 ? 0 : 2 & b || (!(16 & b) && 32 & d))
      ? Jc(b) ||
        ((b |=
          !a.length || (k && !(4096 & b)) || (32 & d && !(4096 & b || 16 & b))
            ? 2
            : 256),
        b !== g && E(a, b),
        Object.freeze(a))
      : (h === 2 &&
          Jc(b) &&
          ((a = Tb(a)), (g = 0), (b = Gc(b, d)), (d = K(c, d, e, a))),
        Jc(b) || (f || (b |= 16), b !== g && E(a, b)));
    2 & b || !(4096 & b || 16 & b) || zc(c, d);
    return a;
  }
  function Ec(a, b) {
    a = Ac(a, b);
    return Array.isArray(a) ? a : rb;
  }
  function Fc(a, b) {
    2 & b && (a |= 2);
    return a | 1;
  }
  function Jc(a) {
    return (!!(2 & a) && !!(4 & a)) || !!(256 & a);
  }
  function L(a, b, c, d) {
    yc(a);
    var e = a.o,
      h = e[D] | 0;
    if (c == null) return K(e, h, b), a;
    var k = c === rb ? 7 : c[D] | 0,
      f = k,
      g = Jc(k),
      l = g || Object.isFrozen(c);
    g || (k = 0);
    l || ((c = Tb(c)), (f = 0), (k = Gc(k, h)), (l = !1));
    k |= 5;
    g = 4 & k ? (512 & k ? 512 : 1024 & k ? 1024 : 0) : void 0;
    g = g != null ? g : 1024;
    k |= g;
    for (var m = 0; m < c.length; m++) {
      var n = c[m],
        p = d(n, g);
      Object.is(n, p) ||
        (l && ((c = Tb(c)), (f = 0), (k = Gc(k, h)), (l = !1)), (c[m] = p));
    }
    k !== f && (l && ((c = Tb(c)), (k = Gc(k, h))), E(c, k));
    K(e, h, b, c);
    return a;
  }
  function N(a, b, c, d) {
    yc(a);
    var e = a.o;
    K(e, e[D] | 0, b, (d === "0" ? Number(c) === 0 : c === d) ? void 0 : c);
    return a;
  }
  function Kc(a, b) {
    var c = cd,
      d = !1,
      e = Ac(a, 1, void 0, function (h) {
        var k = lc(h, c, b);
        d = k !== h && k != null;
        return k;
      });
    if (e != null) return d && !F(e) && zc(a, b), e;
  }
  var dd = function (a, b, c) {
    c == null && (c = void 0);
    Cc(a, b, c);
    c && !F(c) && zc(a.o);
    return a;
  };
  function Gc(a, b) {
    return (a = (2 & b ? a | 2 : a & -3) & -273);
  }
  var ed = function (a, b) {
      var c = c === void 0 ? !1 : c;
      a = Bc(a, b);
      a =
        a == null || typeof a === "boolean"
          ? a
          : typeof a === "number"
          ? !!a
          : void 0;
      return a != null ? a : c;
    },
    fd = function (a, b) {
      var c = c === void 0 ? 0 : c;
      a = bc(Bc(a, b));
      return a != null ? a : c;
    },
    Q = function (a, b, c) {
      return N(a, b, c == null ? c : cc(c), 0);
    };
  var R = function (a, b, c) {
    this.o = J(a, b, c, 2048);
  };
  R.prototype.toJSON = function () {
    var a = qc(this);
    return a;
  };
  R.prototype.clone = function () {
    var a = this.o,
      b = a[D] | 0;
    return uc(this, a, b)
      ? vc(this, a, !0)
      : new this.constructor(tc(a, b, !1));
  };
  R.prototype[ob] = ub;
  R.prototype.toString = function () {
    return this.o.toString();
  };
  var gd = function (a) {
    this.o = J(a, void 0, void 0, 2048);
  };
  r(gd, R);
  function hd(a) {
    return db(a.length % 4 !== 0 ? a + "A" : a)
      .map(function (b) {
        return b.toString(2).padStart(8, "0");
      })
      .join("");
  }
  function id(a) {
    if (!/^[0-1]+$/.test(a))
      throw Error("Invalid input [" + a + "] not a bit string.");
    return parseInt(a, 2);
  }
  function jd(a) {
    if (!/^[0-1]+$/.test(a))
      throw Error("Invalid input [" + a + "] not a bit string.");
    for (var b = [1, 2, 3, 5], c = 0, d = 0; d < a.length - 1; d++)
      b.length <= d && b.push(b[d - 1] + b[d - 2]),
        (c += parseInt(a[d], 2) * b[d]);
    return c;
  }
  function kd(a, b) {
    var c = a.indexOf("11");
    if (c === -1)
      throw Error(
        "Expected section bitstring but not found in [" +
          a +
          "] part of [" +
          b +
          "]"
      );
    return a.slice(0, c + 2);
  }
  [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce(function (
    a,
    b
  ) {
    return a + b;
  });
  [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce(function (a, b) {
    return a + b;
  });
  [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce(function (
    a,
    b
  ) {
    return a + b;
  });
  [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce(function (
    a,
    b
  ) {
    return a + b;
  });
  [
    2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
    2, 2, 2, 2, 2, 2, 2,
  ].reduce(function (a, b) {
    return a + b;
  });
  [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce(function (a, b) {
    return a + b;
  });
  var ld = function (a) {
    this.o = J(a, void 0, void 0, 2048);
  };
  r(ld, R);
  var md = function (a, b) {
    return L(a, 1, b, cc);
  };
  var nd = function (a) {
    this.o = J(a, void 0, void 0, 2048);
  };
  r(nd, R);
  var od = function (a) {
    this.o = J(a, void 0, void 0, 2048);
  };
  r(od, R);
  var pd = function (a, b) {
      return L(a, 1, b, ac);
    },
    qd = function (a, b) {
      return L(a, 2, b, ac);
    },
    rd = function (a, b) {
      return L(a, 3, b, cc);
    },
    sd = function (a, b) {
      L(a, 4, b, cc);
    };
  var td = function (a) {
    this.o = J(a, void 0, void 0, 2048);
  };
  r(td, R);
  var cd = function (a) {
    this.o = J(a, void 0, void 0, 2048);
  };
  r(cd, R);
  var ud = function (a, b) {
      return Q(a, 1, b);
    },
    vd = function (a, b) {
      return dd(a, 2, b);
    },
    wd = function (a, b) {
      return dd(a, 3, b);
    },
    xd = function (a, b) {
      return Q(a, 4, b);
    },
    yd = function (a, b) {
      return Q(a, 5, b);
    },
    zd = function (a, b) {
      return Q(a, 6, b);
    },
    Ad = function (a, b) {
      return N(a, 7, kc(b), "");
    },
    Bd = function (a, b) {
      return Q(a, 8, b);
    },
    Cd = function (a, b) {
      return Q(a, 9, b);
    },
    Dd = function (a, b) {
      return N(a, 10, Yb(b), !1);
    },
    Ed = function (a, b) {
      return N(a, 11, Yb(b), !1);
    },
    Fd = function (a, b) {
      return L(a, 12, b, ac);
    },
    Gd = function (a, b) {
      return L(a, 13, b, ac);
    },
    Hd = function (a, b) {
      return L(a, 14, b, ac);
    },
    Id = function (a, b) {
      return N(a, 15, Yb(b), !1);
    },
    Jd = function (a, b) {
      return N(a, 16, kc(b), "");
    },
    Kd = function (a, b) {
      return L(a, 17, b, cc);
    },
    Ld = function (a, b) {
      return L(a, 18, b, cc);
    },
    Md = function (a, b) {
      yc(a);
      var c = a.o,
        d = c[D] | 0;
      if (b == null) K(c, d, 19);
      else {
        for (
          var e = b === rb ? 7 : b[D] | 0,
            h = e,
            k = Jc(e),
            f = k || Object.isFrozen(b),
            g = !0,
            l = !0,
            m = 0;
          m < b.length;
          m++
        ) {
          var n = b[m];
          k || ((n = F(n)), g && (g = !n), l && (l = n));
        }
        k || ((e = g ? 13 : 5), (e = l ? e & -4097 : e | 4096));
        (f && e === h) || ((b = Tb(b)), (h = 0), (e = Gc(e, d)));
        e !== h && E(b, e);
        d = K(c, d, 19, b);
        2 & e || !(4096 & e || 16 & e) || zc(c, d);
      }
      return a;
    };
  var Nd = function (a) {
    this.o = J(a, void 0, void 0, 2048);
  };
  r(Nd, R);
  function Od(a) {
    var b = [],
      c = 0,
      d;
    for (d in a) b[c++] = a[d];
    return b;
  }
  var Pd = Od({
      hb: 0,
      gb: 1,
      cb: 2,
      Xa: 3,
      eb: 4,
      Ya: 5,
      fb: 6,
      ab: 7,
      bb: 8,
      Wa: 9,
      Za: 10,
      ib: 11,
    }).map(function (a) {
      return Number(a);
    }),
    Qd = Od({ kb: 0, lb: 1, jb: 2 }).map(function (a) {
      return Number(a);
    });
  var Rd = function (a) {
      this.i = a;
      this.h = 0;
      if (/[^01]/.test(this.i))
        throw Error("Input bitstring " + this.i + " is malformed!");
    },
    Sd = function (a) {
      a = T(a, 36);
      var b = new td();
      var c = Math.floor(a / 10);
      c = c == null ? c : ec(c);
      b = N(b, 1, c, "0");
      return Q(b, 2, (a % 10) * 1e8);
    },
    Td = function (a) {
      var b = function () {
        var c = T(a, 6);
        if (c > 25 || c < 0)
          throw Error(
            "Invalid character code, expected in range [0,25], got: " + c
          );
        return String.fromCharCode(97 + c);
      };
      return b() + b();
    },
    Wd = function (a) {
      var b = T(a, 16);
      if (!!T(a, 1) === !0) {
        a = Ud(a);
        var c = t(a),
          d = c.next(),
          e;
        try {
          for (; !d.done; d = c.next()) {
            var h = d.value;
            if (h > b)
              throw Error("ID " + h + " is past MaxVendorId " + b + "!");
          }
        } finally {
          d && !d.done && (e = c.return) && e.call(c);
        }
        return a;
      }
      return Vd(a, b);
    },
    Xd = function (a) {
      for (var b = [], c = T(a, 12); c--; ) {
        var d = T(a, 6),
          e = T(a, 2),
          h = Ud(a),
          k = b,
          f = k.push,
          g = new nd();
        d = N(g, 1, d == null ? d : ac(d), 0);
        e = N(d, 2, e == null ? e : ac(e), 0);
        h = L(e, 3, h, cc);
        f.call(k, h);
      }
      return b;
    },
    Ud = function (a) {
      for (var b = T(a, 12), c = []; b--; ) {
        var d = !!T(a, 1) === !0,
          e = T(a, 16);
        if (d) for (d = T(a, 16); e <= d; e++) c.push(e);
        else c.push(e);
      }
      c.sort(function (h, k) {
        return h - k;
      });
      return c;
    },
    Vd = function (a, b, c) {
      for (var d = [], e = 0; e < b; e++)
        if (T(a, 1)) {
          var h = e + 1;
          if (c && c.indexOf(h) === -1)
            throw Error("ID: " + h + " is outside of allowed values!");
          d.push(h);
        }
      return d;
    },
    T = function (a, b) {
      if (a.h + b > a.i.length)
        throw Error("Requested length " + b + " is past end of string.");
      var c = a.i.substring(a.h, a.h + b);
      a.h += b;
      return parseInt(c, 2);
    };
  function Yd(a) {
    try {
      var b = db(a)
          .map(function (d) {
            return d.toString(2).padStart(8, "0");
          })
          .join(""),
        c = new Rd(b);
      return T(c, 3) !== 1 ? null : md(new ld(), Wd(c));
    } catch (d) {
      return null;
    }
  }
  function Zd(a) {
    try {
      var b = db(a)
          .map(function (h) {
            return h.toString(2).padStart(8, "0");
          })
          .join(""),
        c = new Rd(b);
      if (T(c, 3) !== 3) return null;
      var d = qd(pd(new od(), Vd(c, 24, Pd)), Vd(c, 24, Pd)),
        e = T(c, 6);
      e !== 0 && sd(rd(d, Vd(c, e)), Vd(c, e));
      return d;
    } catch (h) {
      return null;
    }
  }
  function $d(a) {
    try {
      var b = db(a)
          .map(function (d) {
            return d.toString(2).padStart(8, "0");
          })
          .join(""),
        c = new Rd(b);
      return Md(
        Ld(
          Kd(
            Jd(
              Id(
                Hd(
                  Gd(
                    Fd(
                      Ed(
                        Dd(
                          Cd(
                            Bd(
                              Ad(
                                zd(
                                  yd(
                                    xd(
                                      wd(
                                        vd(ud(new cd(), T(c, 6)), Sd(c)),
                                        Sd(c)
                                      ),
                                      T(c, 12)
                                    ),
                                    T(c, 12)
                                  ),
                                  T(c, 6)
                                ),
                                Td(c)
                              ),
                              T(c, 12)
                            ),
                            T(c, 6)
                          ),
                          !!T(c, 1)
                        ),
                        !!T(c, 1)
                      ),
                      Vd(c, 12, Qd)
                    ),
                    Vd(c, 24, Pd)
                  ),
                  Vd(c, 24, Pd)
                ),
                !!T(c, 1)
              ),
              Td(c)
            ),
            Wd(c)
          ),
          Wd(c)
        ),
        Xd(c)
      );
    } catch (d) {
      return null;
    }
  }
  function ae(a) {
    if (!a) return null;
    a = a.split(".");
    if (a.length > 4) return null;
    var b = $d(a[0]);
    if (!b) return null;
    var c = new Nd();
    b = dd(c, 1, b);
    a.shift();
    a = t(a);
    c = a.next();
    var d;
    try {
      for (; !c.done; c = a.next()) {
        var e = c.value;
        switch (be(e)) {
          case 1:
            var h = Yd(e);
            if (!h) return null;
            dd(b, 3, h);
            break;
          case 2:
            break;
          case 3:
            var k = Zd(e);
            if (!k) return null;
            dd(b, 2, k);
            break;
          default:
            return null;
        }
      }
    } finally {
      c && !c.done && (d = a.return) && d.call(a);
    }
    return b;
  }
  function be(a) {
    try {
      var b = db(a)
        .map(function (c) {
          return c.toString(2).padStart(8, "0");
        })
        .join("");
      return T(new Rd(b), 3);
    } catch (c) {
      return -1;
    }
  }
  function ce(a) {
    try {
      var b;
      if ((b = !!a && a.location.href != null))
        a: {
          try {
            Ua(a.foo);
            b = !0;
            break a;
          } catch (c) {}
          b = !1;
        }
      return b;
    } catch (c) {
      return !1;
    }
  }
  function de(a, b, c) {
    b = b === void 0 ? !1 : b;
    c = c === void 0 ? w : c;
    for (var d = 0; c && d++ < 40 && ((!b && !ce(c)) || !a(c)); ) c = ee(c);
  }
  function ee(a) {
    try {
      var b = a.parent;
      if (b && b !== a) return b;
    } catch (c) {}
    return null;
  }
  var fe = function (a) {
      var b = !1,
        c;
      return function () {
        b || ((c = a()), (b = !0));
        return c;
      };
    },
    ge = function (a) {
      var b = a;
      return function () {
        if (b) {
          var c = b;
          b = null;
          c();
        }
      };
    }; /*

 Copyright Google LLC
 SPDX-License-Identifier: Apache-2.0
*/
  var he = globalThis.trustedTypes,
    ie;
  function je() {
    var a = null;
    if (!he) return a;
    try {
      var b = function (c) {
        return c;
      };
      a = he.createPolicy("goog#html", {
        createHTML: b,
        createScript: b,
        createScriptURL: b,
      });
    } catch (c) {}
    return a;
  }
  function ke() {
    ie === void 0 && (ie = je());
    return ie;
  }
  var le = function (a) {
    this.h = a;
  };
  le.prototype.toString = function () {
    return this.h + "";
  };
  function me(a) {
    var b = ke();
    a = b ? b.createScriptURL(a) : a;
    return new le(a);
  }
  var ne = ra([""]),
    oe = qa(["\x00"], ["\\0"]),
    pe = qa(["\n"], ["\\n"]),
    qe = qa(["\x00"], ["\\u0000"]);
  function re(a) {
    return a.toString().indexOf("`") === -1;
  }
  re(function (a) {
    return a(ne);
  }) ||
    re(function (a) {
      return a(oe);
    }) ||
    re(function (a) {
      return a(pe);
    }) ||
    re(function (a) {
      return a(qe);
    });
  var se = /^\s*(?!javascript:)(?:[\w+.-]+:|[^:/?#]*(?:[/?#]|$))/i;
  var te = function (a) {
    this.h = a;
  };
  te.prototype.toString = function () {
    return this.h + "";
  };
  function ue(a) {
    var b = ke();
    a = b ? b.createHTML(a) : a;
    return new te(a);
  }
  function ve(a) {
    if (a instanceof te) return a.h;
    throw Error("");
  }
  var xe = fe(function () {
    return we("MSIE");
  });
  function we(a) {
    return Fa().indexOf(a) != -1;
  }
  function ye(a) {
    var b, c;
    return (c = (b = /https?:\/\/[^\/]+/.exec(a)) == null ? void 0 : b[0]) !=
      null
      ? c
      : "";
  }
  var ze = fe(function () {
    var a = Math.random;
    return (
      [
        "Google Web Preview",
        "Mediapartners-Google",
        "Google-Read-Aloud",
        "Google-Adwords",
      ].some(we) || a() < 1e-4
    );
  });
  function Ae(a, b) {
    if (a)
      for (var c in a)
        Object.prototype.hasOwnProperty.call(a, c) && b(a[c], c, a);
  }
  function Be() {
    if (!globalThis.crypto) return Math.random();
    try {
      var a = new Uint32Array(1);
      globalThis.crypto.getRandomValues(a);
      return a[0] / 65536 / 65536;
    } catch (b) {
      return Math.random();
    }
  }
  function Ce(a) {
    return a instanceof te
      ? a
      : ue(
          String(a)
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&apos;")
        );
  }
  function De(a) {
    return Ee(a);
  }
  function Ee(a) {
    var b = Ce("");
    return ue(
      a
        .map(function (c) {
          return ve(Ce(c));
        })
        .join(ve(b).toString())
    );
  }
  var Fe = /^[a-z][a-z\d-]*$/i,
    Ge =
      "APPLET BASE EMBED IFRAME LINK MATH META OBJECT SCRIPT STYLE SVG TEMPLATE".split(
        " "
      ),
    He = "AREA BR COL COMMAND HR IMG INPUT KEYGEN PARAM SOURCE TRACK WBR".split(
      " "
    ),
    Ie = ["action", "formaction", "href"];
  function Je() {
    var a = { style: "display:none;" },
      b = "_";
    if (!Fe.test("b")) throw Error("");
    if (Ge.indexOf("B") !== -1) throw Error("");
    var c = "<b";
    a && (c += Ke(a));
    Array.isArray(b) || (b = b === void 0 ? [] : [b]);
    He.indexOf("B") !== -1
      ? (c += ">")
      : ((a = De(
          b.map(function (d) {
            return d instanceof te ? d : Ce(String(d));
          })
        )),
        (c += ">" + a.toString() + "</b>"));
    return ue(c);
  }
  function Ke(a) {
    for (var b = "", c = Object.keys(a), d = 0; d < c.length; d++) {
      var e = c[d],
        h = a[e];
      if (!Fe.test(e)) throw Error("");
      if (h !== void 0 && h !== null) {
        if (/^on./i.test(e)) throw Error("");
        Ie.indexOf(e.toLowerCase()) !== -1 &&
          ((h = String(h)),
          (h = se.test(h) ? h : void 0),
          (h = h || "about:invalid#zClosurez"));
        e = e + '="' + Ce(String(h)) + '"';
        b += " " + e;
      }
    }
    return b;
  }
  "ARTICLE SECTION NAV ASIDE H1 H2 H3 H4 H5 H6 HEADER FOOTER ADDRESS P HR PRE BLOCKQUOTE OL UL LH LI DL DT DD FIGURE FIGCAPTION MAIN DIV EM STRONG SMALL S CITE Q DFN ABBR RUBY RB RT RTC RP DATA TIME CODE VAR SAMP KBD SUB SUP I B U MARK BDI BDO SPAN BR WBR NOBR INS DEL PICTURE PARAM TRACK MAP TABLE CAPTION COLGROUP COL TBODY THEAD TFOOT TR TD TH SELECT DATALIST OPTGROUP OPTION OUTPUT PROGRESS METER FIELDSET LEGEND DETAILS SUMMARY MENU DIALOG SLOT CANVAS FONT CENTER ACRONYM BASEFONT BIG DIR HGROUP STRIKE TT"
    .split(" ")
    .concat(["BUTTON", "INPUT"]);
  function Le(a) {
    var b = sa.apply(1, arguments);
    if (b.length === 0) return me(a[0]);
    for (var c = a[0], d = 0; d < b.length; d++)
      c += encodeURIComponent(b[d]) + a[d + 1];
    return me(c);
  }
  var vf = function (a) {
      return w.getComputedStyle ? w.getComputedStyle(a, null) : a.currentStyle;
    },
    wf = /^([0-9.]+)px$/,
    Af = function (a, b) {
      try {
        return !(!a.frames || !a.frames[b]);
      } catch (c) {
        return !1;
      }
    },
    Bf = function (a, b) {
      for (var c = 0; c < 50; ++c) {
        if (Af(a, b)) return a;
        if (!(a = ee(a))) break;
      }
      return null;
    },
    Cf = function (a, b) {
      b = b === void 0 ? document : b;
      return b.createElement(String(a).toLowerCase());
    };
  function Df(a, b, c) {
    typeof a.addEventListener === "function" && a.addEventListener(b, c, !1);
  }
  function Ef(a, b, c) {
    typeof a.removeEventListener === "function" &&
      a.removeEventListener(b, c, !1);
  }
  var Ff = ra(["https://cdn.ampproject.org/rtv/", "/amp4ads-host-v0.js"]),
    Gf = ra(["https://cdn.ampproject.org/amp4ads-host-v0.js"]);
  function Hf(a, b) {
    var c = (a.ampInaboxIframes = a.ampInaboxIframes || []),
      d = function () {};
    b && c.push(b);
    if (!a.ampInaboxInitialized) {
      a.ampInaboxPendingMessages = a.ampInaboxPendingMessages || [];
      var e = function (h) {
        if (a.ampInaboxInitialized) var k = !0;
        else {
          var f,
            g = h.data === "amp-ini-load";
          if (
            a.ampInaboxPendingMessages &&
            !g &&
            (f = /^amp-(\d{15,20})?/.exec(h.data)) &&
            (a.ampInaboxPendingMessages.push(h),
            (f = f[1]),
            !(
              a.ampInaboxInitialized ||
              (f && !/^\d{15,20}$/.test(f)) ||
              a.document.querySelector('script[src$="amp4ads-host-v0.js"]')
            ))
          ) {
            h = a.document;
            g = f ? Le(Ff, f) : Le(Gf);
            f = Cf("SCRIPT", h);
            if (g instanceof le) g = g.h;
            else throw Error("");
            f.src = g;
            g = f.ownerDocument;
            g = g === void 0 ? document : g;
            var l;
            g =
              (l = (k = g).querySelector) == null
                ? void 0
                : l.call(k, "script[nonce]");
            (k = g == null ? "" : g.nonce || g.getAttribute("nonce") || "") &&
              f.setAttribute("nonce", k);
            (k = h.getElementsByTagName("script")[0]) &&
              k.parentNode &&
              k.parentNode.insertBefore(f, k);
          }
          k = !1;
        }
        k && d();
      };
      c.google_amp_listener_added ||
        ((c.google_amp_listener_added = !0),
        Df(a, "message", e),
        (d = function () {
          Ef(a, "message", e);
        }));
    }
  }
  var If = function (a, b) {
    var c = c === void 0 ? {} : c;
    this.error = a;
    this.meta = c;
    this.context = b.context;
    this.msg = b.message || "";
    this.id = b.id || "jserror";
  };
  function U() {
    this.v = this.v;
    this.C = this.C;
  }
  U.prototype.v = !1;
  U.prototype.dispose = function () {
    this.v || ((this.v = !0), this.j());
  };
  U.prototype[Symbol.dispose] = function () {
    this.dispose();
  };
  U.prototype.j = function () {
    if (this.C) for (; this.C.length; ) this.C.shift()();
  };
  var Jf = function (a, b, c, d) {
    U.call(this);
    this.H = b;
    this.G = c;
    this.F = d;
    this.D = new Map();
    this.I = 0;
    this.m = new Map();
    this.u = new Map();
    this.l = void 0;
    this.i = a;
  };
  r(Jf, U);
  Jf.prototype.j = function () {
    delete this.h;
    this.D.clear();
    this.m.clear();
    this.u.clear();
    this.l && (Ef(this.i, "message", this.l), delete this.l);
    delete this.i;
    delete this.F;
    U.prototype.j.call(this);
  };
  var Kf = function (a) {
      if (a.h) return a.h;
      a.G && a.G(a.i) ? (a.h = a.i) : (a.h = Bf(a.i, a.H));
      var b;
      return (b = a.h) != null ? b : null;
    },
    Mf = function (a, b, c) {
      if (Kf(a))
        if (a.h === a.i) (b = a.D.get(b)) && b(a.h, c);
        else {
          var d = a.m.get(b);
          if (d && d.ca) {
            Lf(a);
            var e = ++a.I;
            a.u.set(e, { Y: d.Y, va: d.ga(c), Ka: b === "addEventListener" });
            a.h.postMessage(d.ca(c, e), "*");
          }
        }
    },
    Lf = function (a) {
      a.l ||
        ((a.l = function (b) {
          if (b.source === a.h)
            try {
              var c = a.F ? a.F(b) : void 0;
              if (c) {
                var d = c.La,
                  e = a.u.get(d);
                if (e) {
                  e.Ka || a.u.delete(d);
                  var h;
                  (h = e.Y) == null || h.call(e, e.va, c.Ja);
                }
              }
            } catch (k) {}
        }),
        Df(a.i, "message", a.l));
    };
  function Nf(a, b, c, d, e) {
    Of(
      a,
      b,
      c === void 0 ? null : c,
      d === void 0 ? !1 : d,
      e === void 0 ? !1 : e
    );
  }
  function Of(a, b, c, d, e) {
    e = e === void 0 ? !1 : e;
    a.google_image_requests || (a.google_image_requests = []);
    var h = Cf("IMG", a.document);
    if (c || d) {
      var k = function (f) {
        c && c(f);
        if (d) {
          f = a.google_image_requests;
          var g = Pa(f, h);
          g >= 0 && Array.prototype.splice.call(f, g, 1);
        }
        Ef(h, "load", k);
        Ef(h, "error", k);
      };
      Df(h, "load", k);
      Df(h, "error", k);
    }
    e && (h.attributionSrc = "");
    h.src = b;
    a.google_image_requests.push(h);
  }
  function Pf(a) {
    var b = b === void 0 ? !1 : b;
    var c;
    if ((c = w.navigator))
      (c = w.navigator.userAgent),
        (c = /Chrome/.test(c) && !/Edge/.test(c) ? !0 : !1);
    c && typeof w.navigator.sendBeacon === "function"
      ? w.navigator.sendBeacon(a)
      : Nf(w, a, void 0, b);
  }
  function Qf(a) {
    var b = b === void 0 ? !1 : b;
    var c = "https://pagead2.googlesyndication.com/pagead/gen_204?id=tcfe";
    Ae(a, function (d, e) {
      if (d || d === 0) c += "&" + e + "=" + encodeURIComponent(String(d));
    });
    Rf(c, b);
  }
  function Rf(a, b) {
    var c = window;
    b = b === void 0 ? !1 : b;
    var d = d === void 0 ? !1 : d;
    c.fetch
      ? ((b = {
          keepalive: !0,
          credentials: "include",
          redirect: "follow",
          method: "get",
          mode: "no-cors",
        }),
        d &&
          ((b.mode = "cors"),
          "setAttributionReporting" in XMLHttpRequest.prototype
            ? (b.attributionReporting = {
                eventSourceEligible: "true",
                triggerEligible: "false",
              })
            : (b.headers = {
                "Attribution-Reporting-Eligible": "event-source",
              })),
        c.fetch(a, b))
      : Nf(c, a, void 0, b, d);
  }
  function Sf(a) {
    a.addtlConsent === void 0 ||
      zb(a.addtlConsent) ||
      (a.addtlConsent = void 0);
    a.gdprApplies === void 0 || Ab(a.gdprApplies) || (a.gdprApplies = void 0);
    return (a.tcString !== void 0 && !zb(a.tcString)) ||
      (a.listenerId !== void 0 && !yb(a.listenerId))
      ? 2
      : a.cmpStatus && a.cmpStatus !== "error"
      ? 0
      : 3;
  }
  var Tf = function (a, b) {
    b = b === void 0 ? {} : b;
    U.call(this);
    this.h = null;
    this.m = {};
    this.u = 0;
    this.l = null;
    this.i = a;
    var c;
    this.timeoutMs = (c = b.timeoutMs) != null ? c : 500;
    var d;
    this.N = (d = b.N) != null ? d : !1;
  };
  r(Tf, U);
  Tf.prototype.j = function () {
    this.m = {};
    this.l && (Ef(this.i, "message", this.l), delete this.l);
    delete this.m;
    delete this.i;
    delete this.h;
    U.prototype.j.call(this);
  };
  Tf.prototype.addEventListener = function (a) {
    var b = this,
      c = { internalBlockOnErrors: this.N },
      d = ge(function () {
        a(c);
      }),
      e = 0;
    this.timeoutMs !== -1 &&
      (e = setTimeout(function () {
        c.tcString = "tcunavailable";
        c.internalErrorState = 1;
        d();
      }, this.timeoutMs));
    var h = function (k, f) {
      clearTimeout(e);
      k
        ? ((c = k),
          (c.internalErrorState = Sf(c)),
          (c.internalBlockOnErrors = b.N),
          (f && c.internalErrorState === 0) ||
            ((c.tcString = "tcunavailable"), f || (c.internalErrorState = 3)))
        : ((c.tcString = "tcunavailable"), (c.internalErrorState = 3));
      a(c);
    };
    try {
      Uf(this, "addEventListener", h);
    } catch (k) {
      (c.tcString = "tcunavailable"),
        (c.internalErrorState = 3),
        e && (clearTimeout(e), (e = 0)),
        d();
    }
  };
  Tf.prototype.removeEventListener = function (a) {
    a && a.listenerId && Uf(this, "removeEventListener", null, a.listenerId);
  };
  var Wf = function (a, b) {
      var c = { internalErrorState: 0, internalBlockOnErrors: a.N },
        d = ge(function () {
          b(c);
        }),
        e = 0;
      a.timeoutMs !== -1 &&
        (e = setTimeout(function () {
          c.tcString = "tcunavailable";
          c.internalErrorState = 1;
          d();
        }, a.timeoutMs));
      Uf(a, "addEventListener", function (h, k) {
        var f = e;
        f && clearTimeout(f);
        k && (c = h);
        c.internalErrorState = Sf(c);
        c.internalBlockOnErrors = a.N;
        c.internalErrorState !== 0 && (c.tcString = "tcunavailable");
        if (a.N)
          Vf(c) && (Uf(a, "removeEventListener", null, c.listenerId), d());
        else if (c.internalErrorState !== 0 || Vf(c))
          Uf(a, "removeEventListener", null, c.listenerId), d();
      });
    },
    Xf = function (a) {
      return new Promise(function (b) {
        Wf(a, b);
      });
    },
    Uf = function (a, b, c, d) {
      c || (c = function () {});
      var e = a.i;
      typeof e.__tcfapi === "function"
        ? ((a = e.__tcfapi), a(b, 2, c, d))
        : Yf(a)
        ? (Zf(a),
          (e = ++a.u),
          (a.m[e] = c),
          a.h &&
            ((c = {}),
            a.h.postMessage(
              ((c.__tcfapiCall = {
                command: b,
                version: 2,
                callId: e,
                parameter: d,
              }),
              c),
              "*"
            )))
        : c({}, !1);
    },
    Yf = function (a) {
      if (a.h) return a.h;
      a.h = Bf(a.i, "__tcfapiLocator");
      return a.h;
    },
    Zf = function (a) {
      if (!a.l) {
        var b = function (c) {
          if (c.source === a.h)
            try {
              var d = (zb(c.data) ? JSON.parse(c.data) : c.data).__tcfapiReturn;
              a.m[d.callId](d.returnValue, d.success);
            } catch (e) {}
        };
        a.l = b;
        Df(a.i, "message", b);
      }
    },
    Vf = function (a) {
      if (a.gdprApplies === !1) return !0;
      a.internalErrorState === void 0 && (a.internalErrorState = Sf(a));
      return a.cmpStatus === "error" || a.internalErrorState !== 0
        ? a.internalBlockOnErrors
          ? (Qf({ e: String(a.internalErrorState) }), !1)
          : !0
        : a.cmpStatus !== "loaded" ||
          (a.eventStatus !== "tcloaded" &&
            a.eventStatus !== "useractioncomplete")
        ? !1
        : !0;
    };
  var $f = function (a, b) {
      b = b.listener;
      (a = (0, a.__gpp)("addEventListener", b)) && b(a, !0);
    },
    ag = function (a, b) {
      (0, a.__gpp)("removeEventListener", b.listener, b.listenerId);
    },
    bg = {
      ga: function (a) {
        return a.listener;
      },
      ca: function (a, b) {
        a = {};
        return (
          (a.__gppCall = {
            callId: b,
            command: "addEventListener",
            version: "1.1",
          }),
          a
        );
      },
      Y: function (a, b) {
        b = b.__gppReturn;
        a(b.returnValue, b.success);
      },
    },
    cg = {
      ga: function (a) {
        return a.listener;
      },
      ca: function (a, b) {
        var c = {};
        return (
          (c.__gppCall = {
            callId: b,
            command: "removeEventListener",
            version: "1.1",
            parameter: a.listenerId,
          }),
          c
        );
      },
      Y: function (a, b) {
        b = b.__gppReturn;
        var c = b.returnValue.data;
        a == null || a(c, b.success);
      },
    };
  function dg(a) {
    var b = {};
    zb(a.data) ? (b = JSON.parse(a.data)) : (b = a.data);
    return { Ja: b, La: b.__gppReturn.callId };
  }
  var eg = function (a, b) {
    b = (b === void 0 ? {} : b).timeoutMs;
    U.call(this);
    this.caller = new Jf(
      a,
      "__gppLocator",
      function (c) {
        return typeof c.__gpp === "function";
      },
      dg
    );
    this.caller.D.set("addEventListener", $f);
    this.caller.m.set("addEventListener", bg);
    this.caller.D.set("removeEventListener", ag);
    this.caller.m.set("removeEventListener", cg);
    this.timeoutMs = b != null ? b : 500;
  };
  r(eg, U);
  eg.prototype.j = function () {
    this.caller.dispose();
    U.prototype.j.call(this);
  };
  eg.prototype.addEventListener = function (a) {
    var b = this,
      c = ge(function () {
        a(fg, !0);
      }),
      d =
        this.timeoutMs === -1
          ? void 0
          : setTimeout(function () {
              c();
            }, this.timeoutMs);
    Mf(this.caller, "addEventListener", {
      listener: function (e, h) {
        clearTimeout(d);
        try {
          var k;
          if (
            ((k = e.pingData) == null ? void 0 : k.gppVersion) === void 0 ||
            e.pingData.gppVersion === "1" ||
            e.pingData.gppVersion === "1.0"
          ) {
            b.removeEventListener(e.listenerId);
            var f = {
              eventName: "signalStatus",
              data: "ready",
              pingData: {
                internalErrorState: 1,
                gppString: "GPP_ERROR_STRING_IS_DEPRECATED_SPEC",
                applicableSections: [-1],
              },
            };
          } else
            Array.isArray(e.pingData.applicableSections)
              ? (f = e)
              : (b.removeEventListener(e.listenerId),
                (f = {
                  eventName: "signalStatus",
                  data: "ready",
                  pingData: {
                    internalErrorState: 2,
                    gppString:
                      "GPP_ERROR_STRING_EXPECTED_APPLICATION_SECTION_ARRAY",
                    applicableSections: [-1],
                  },
                }));
          a(f, h);
        } catch (g) {
          if (e == null ? 0 : e.listenerId)
            try {
              b.removeEventListener(e.listenerId);
            } catch (l) {
              a(gg, !0);
              return;
            }
          a(hg, !0);
        }
      },
    });
  };
  eg.prototype.removeEventListener = function (a) {
    Mf(this.caller, "removeEventListener", {
      listener: function () {},
      listenerId: a,
    });
  };
  var hg = {
      eventName: "signalStatus",
      data: "ready",
      pingData: {
        internalErrorState: 2,
        gppString: "GPP_ERROR_STRING_UNAVAILABLE",
        applicableSections: [-1],
      },
      listenerId: -1,
    },
    fg = {
      eventName: "signalStatus",
      data: "ready",
      pingData: {
        gppString: "GPP_ERROR_STRING_LISTENER_REGISTRATION_TIMEOUT",
        internalErrorState: 2,
        applicableSections: [-1],
      },
      listenerId: -1,
    },
    gg = {
      eventName: "signalStatus",
      data: "ready",
      pingData: {
        gppString: "GPP_ERROR_STRING_REMOVE_EVENT_LISTENER_ERROR",
        internalErrorState: 2,
        applicableSections: [-1],
      },
      listenerId: -1,
    };
  function ig(a) {
    var b = a.toString();
    a.name && b.indexOf(a.name) == -1 && (b += ": " + a.name);
    a.message && b.indexOf(a.message) == -1 && (b += ": " + a.message);
    if (a.stack)
      a: {
        a = a.stack;
        var c = b;
        try {
          a.indexOf(c) == -1 && (a = c + "\n" + a);
          for (var d; a != d; )
            (d = a),
              (a = a.replace(
                RegExp("((https?:/..*/)[^/:]*:\\d+(?:.|\n)*)\\2"),
                "$1"
              ));
          b = a.replace(RegExp("\n *", "g"), "\n");
          break a;
        } catch (e) {
          b = c;
          break a;
        }
        b = void 0;
      }
    return b;
  }
  var jg = RegExp("^https?://(\\w|-)+\\.cdn\\.ampproject\\.(net|org)(\\?|/|$)"),
    ng = function (a) {
      a = a || kg();
      for (
        var b = new lg(w.location.href, !1), c = null, d = a.length - 1, e = d;
        e >= 0;
        --e
      ) {
        var h = a[e];
        !c && jg.test(h.url) && (c = h);
        if (h.url && !h.h) {
          b = h;
          break;
        }
      }
      e = null;
      h = a.length && a[d].url;
      b.depth !== 0 && h && (e = a[d]);
      return new mg(b, e, c);
    },
    kg = function () {
      var a = w,
        b = [],
        c = null;
      do {
        var d = a;
        if (ce(d)) {
          var e = d.location.href;
          c = (d.document && d.document.referrer) || null;
        } else (e = c), (c = null);
        b.push(new lg(e || ""));
        try {
          a = d.parent;
        } catch (h) {
          a = null;
        }
      } while (a && d !== a);
      d = 0;
      for (a = b.length - 1; d <= a; ++d) b[d].depth = a - d;
      d = w;
      if (
        d.location &&
        d.location.ancestorOrigins &&
        d.location.ancestorOrigins.length === b.length - 1
      )
        for (a = 1; a < b.length; ++a)
          (e = b[a]),
            e.url ||
              ((e.url = d.location.ancestorOrigins[a - 1] || ""), (e.h = !0));
      return b;
    },
    mg = function (a, b, c) {
      this.h = a;
      this.i = b;
      this.j = c;
    },
    lg = function (a, b) {
      this.url = a;
      this.h = !!b;
      this.depth = null;
    };
  var og = !1,
    pg = null,
    qg = function () {
      var a = a === void 0 ? [] : a;
      this.i = {};
      this.h = {};
      for (var b = 0; b < a.length; ++b) this.h[a[b]] = "";
    },
    rg = function (a) {
      a = a === void 0 ? window : a;
      if (pg === null) {
        pg = "";
        try {
          var b = "";
          try {
            b = a.top.location.hash;
          } catch (d) {
            b = a.location.hash;
          }
          if (b) {
            var c = b.match(/\bdeid=([\d,]+)/);
            pg = c ? c[1] : "";
          }
        } catch (d) {}
      }
      return pg;
    },
    sg = function (a, b, c) {
      b !== "" && (c ? a.h.hasOwnProperty(c) && (a.h[c] = b) : (a.i[b] = !0));
    },
    tg = function (a) {
      var b = [];
      Ae(a.i, function (c, d) {
        b.push(d);
      });
      Ae(a.h, function (c) {
        c !== "" && b.push(c);
      });
      return b;
    };
  var ug = w.performance,
    vg = !!(ug && ug.mark && ug.measure && ug.clearMarks),
    wg = fe(function () {
      var a;
      if ((a = vg)) (a = rg()), (a = !!a.indexOf && a.indexOf("1337") >= 0);
      return a;
    });
  var xg = function (a, b) {
      b = b === void 0 ? "&" : b;
      this.l = a === void 0 ? 4e3 : a;
      this.j = b;
      this.i = {};
      this.m = 0;
      this.h = [];
    },
    yg = function (a, b) {
      var c = {};
      c[a] = b;
      return [c];
    },
    Ag = function (a, b, c, d, e) {
      var h = [];
      Ae(a, function (k, f) {
        (k = zg(k, b, c, d, e)) && h.push(f + "=" + k);
      });
      return h.join(b);
    },
    zg = function (a, b, c, d, e) {
      if (a == null) return "";
      b = b || "&";
      c = c || ",$";
      zb(c) && (c = c.split(""));
      if (a instanceof Array) {
        if ((d || (d = 0), d < c.length)) {
          for (var h = [], k = 0; k < a.length; k++)
            h.push(zg(a[k], b, c, d + 1, e));
          return h.join(c[d]);
        }
      } else if (typeof a === "object")
        return (
          e || (e = 0),
          e < 2 ? encodeURIComponent(Ag(a, b, c, d, e + 1)) : "..."
        );
      return encodeURIComponent(String(a));
    },
    V = function (a, b, c) {
      a.h.push(b);
      a.i[b] = c;
    },
    W = function (a, b, c, d) {
      a.h.push(b);
      a.i[b] = yg(c, d);
    },
    Cg = function (a, b, c, d) {
      b = b + "//" + c + d;
      var e = Bg(a) - d.length;
      if (e < 0) return "";
      a.h.sort(function (m, n) {
        return m - n;
      });
      d = null;
      c = "";
      for (var h = 0; h < a.h.length; h++)
        for (var k = a.h[h], f = a.i[k], g = 0; g < f.length; g++) {
          if (!e) {
            d = d == null ? k : d;
            break;
          }
          var l = Ag(f[g], a.j, ",$");
          if (l) {
            l = c + l;
            if (e >= l.length) {
              e -= l.length;
              b += l;
              c = a.j;
              break;
            }
            d = d == null ? k : d;
          }
        }
      a = "";
      d != null && (a = c + "trn=" + d);
      return b + a;
    },
    Bg = function (a) {
      var b = 1,
        c;
      for (c in a.i) c.length > b && (b = c.length);
      return a.l - 3 - b - a.j.length - 1;
    };
  var Dg = RegExp(
    "^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$"
  );
  var Fg = function () {
      var a = Eg;
      var b = b === void 0 ? null : b;
      this.l = a;
      this.j = !0;
      this.i = b;
      this.m = this.h;
    },
    Gg = function (a, b, c, d) {
      try {
        if (a.i && a.i.h) {
          var e = a.i.start(b.toString(), 3);
          var h = c();
          a.i.end(e);
        } else h = c();
      } catch (g) {
        c = a.j;
        try {
          e &&
            ug &&
            wg() &&
            (ug.clearMarks("goog_" + e.label + "_" + e.uniqueId + "_start"),
            ug.clearMarks("goog_" + e.label + "_" + e.uniqueId + "_end")),
            (c = a.m(b, new If(g, { message: ig(g) }), void 0, d));
        } catch (l) {
          a.h(217, l);
        }
        if (c) {
          var k, f;
          (k = window.console) == null || (f = k.error) == null || f.call(k, g);
        } else throw g;
      }
      return h;
    },
    Hg = function (a, b, c, d) {
      return function () {
        var e = sa.apply(0, arguments);
        return Gg(
          a,
          b,
          function () {
            return c.apply(void 0, e);
          },
          d
        );
      };
    };
  Fg.prototype.h = function (a, b, c, d, e) {
    e = e || "dcmads-err";
    var h = void 0;
    try {
      var k = new xg();
      W(k, 1, "context", a);
      (b.error && b.meta && b.id) || (b = new If(b, { message: ig(b) }));
      b.msg && W(k, 2, "msg", b.msg.substring(0, 512));
      var f = b.meta || {};
      if (d)
        try {
          d(f);
        } catch (z) {}
      V(k, 3, [f]);
      h = ng();
      h.i && W(k, 4, "top", h.i.url || "");
      var g = { url: h.h.url || "" };
      if (h.h.url) {
        var l = h.h.url.match(Dg),
          m = l[1],
          n = l[3],
          p = l[4];
        d = "";
        m && (d += m + ":");
        n && ((d += "//"), (d += n), p && (d += ":" + p));
        var u = d;
      } else u = "";
      V(k, 5, [g, { url: u }]);
      Ig(this.l, e, k, c);
    } catch (z) {
      try {
        var A, y;
        Ig(
          this.l,
          e,
          {
            context: "ecmserr",
            rctx: a,
            msg: ig(z),
            url: (y = (A = h) == null ? void 0 : A.h.url) != null ? y : "",
          },
          c
        );
      } catch (Y) {}
    }
    return this.j;
  };
  var Jg = function (a, b) {
      this.h = a;
      this.depth = b;
    },
    Lg = function (a) {
      a = a || kg();
      var b = Math.max(a.length - 1, 0),
        c = ng(a);
      a = c.h;
      var d = c.i,
        e = c.j,
        h = [];
      c = function (f, g) {
        return f == null ? g : f;
      };
      e && h.push(new Jg([e.url, e.h ? 2 : 0], c(e.depth, 1)));
      d && d != e && h.push(new Jg([d.url, 2], 0));
      a.url && a != e && h.push(new Jg([a.url, 0], c(a.depth, b)));
      var k = Ra(h, function (f, g) {
        return h.slice(0, h.length - g);
      });
      !a.url ||
        ((e || d) && a != e) ||
        ((d = ye(a.url)) && k.push([new Jg([d, 1], c(a.depth, b))]));
      k.push([]);
      return Ra(k, function (f) {
        return Kg(b, f);
      });
    };
  function Mg(a, b) {
    b = b === void 0 ? Lg() : b;
    return b.map(function (c) {
      var d = {};
      d[a] = c;
      return d;
    });
  }
  function Kg(a, b) {
    var c = Sa(
        b,
        function (e, h) {
          return Math.max(e, h.depth);
        },
        -1
      ),
      d = Ta(c + 2);
    d[0] = a;
    Qa(b, function (e) {
      return (d[e.depth + 1] = e.h);
    });
    return d;
  }
  var Ig = function (a, b, c, d) {
    if (Math.random() < (d || 0.01))
      try {
        if (c instanceof xg) var e = c;
        else
          (e = new xg()),
            Ae(c, function (k, f) {
              var g = e,
                l = g.m++;
              V(g, l, yg(f, k));
            });
        var h = Cg(e, a.protocol, a.domain, a.path + b + "&");
        h && (a.h ? Pf(h) : Nf(w, h));
      } catch (k) {}
  };
  var Ng = function (a) {
    this.o = J(a, void 0, void 0, 2048);
  };
  r(Ng, R);
  function Og(a) {
    return ue(a === null ? "null" : a === void 0 ? "undefined" : a);
  }
  var Pg;
  if ((Pg = Va)) {
    var Qg = "IFRAME",
      Rg = document;
    Qg = String(Qg);
    Rg.contentType === "application/xhtml+xml" && (Qg = Qg.toLowerCase());
    Pg = "srcdoc" in Rg.createElement(Qg);
  }
  var Sg = Pg;
  var Eg, Tg;
  Eg = new (function () {
    var a = !0;
    a = a === void 0 ? !1 : a;
    this.domain = "pagead2.googlesyndication.com";
    this.path = "/pagead/gen_204?id=";
    this.h = a;
    this.protocol = "https:";
  })();
  Tg = new Fg();
  function Ug(a) {
    Tg.j = !1;
    throw Error(a);
  }
  var Vg = { mb: 1, Va: 4, 1: "UNIFORMITY", 4: "ASYNC_LOADING" },
    Wg = [],
    Xg = function (a) {
      this.id = a.id;
      this.M = a.M;
      this.S = a.S;
      Wg.push(this);
    },
    Yg = new Xg({ id: 1, M: { da: "40004000", T: "40004001" }, S: 1 }),
    Zg = new Xg({ id: 4, M: { da: "40004006", T: "40004007" }, S: 4 }),
    $g = new Xg({ id: 5, M: { da: "40004008", T: "40004009" }, S: 4 });
  function ah(a, b, c) {
    if ((a = a.dcmads && a.dcmads.expts && a.dcmads.expts[c.id])) {
      var d = Object.values(c.M);
      if ((c = c.S) ? b.h.hasOwnProperty(c) && b.h[c] === "" : 1) {
        var e = e === void 0 ? w : e;
        e = (e = rg(e))
          ? (e = e.match(new RegExp("\\b(" + d.join("|") + ")\\b")))
            ? e[0]
            : null
          : null;
        if (e) a = e;
        else if (og) a = null;
        else
          b: {
            if (!xe() && !ze() && ((e = Math.random()), e < a)) {
              e = Be();
              a = d[Math.floor(e * d.length)];
              break b;
            }
            a = null;
          }
        a && sg(b, a, c);
      }
    }
  }
  function bh(a, b) {
    if (b && b.split) {
      b = b.split(",");
      for (var c = 0; c < b.length; ++c) {
        var d = b[c].split("|");
        d.length > 1 ? sg(a, d[1], d[0]) : sg(a, d[0]);
      }
    }
  }
  var ch = function (a) {
      this.h = a;
    },
    dh = function (a, b) {
      b && (a.h.aacm = b);
      return a.h.aacm;
    },
    eh = function (a, b) {
      b && (a.h.corr = b);
      return a.h.corr;
    };
  ch.prototype.timestamp = function (a) {
    a && (this.h.ts = a);
    return this.h.ts;
  };
  var gh = function (a) {
    return (a = fh(a)) ? new ch(a) : null;
  };
  function hh(a, b) {
    Ae(a, function (c, d) {
      b[d] = c;
    });
  }
  function ih(a, b) {
    eh(b, eh(a));
    b.timestamp(a.timestamp());
    dh(b, {});
    dh(a) && hh(dh(a), dh(b));
  }
  function fh(a) {
    return xa(a)
      ? typeof a.corr === "string" && typeof a.ts === "number" && xa(a.aacm)
        ? a
        : null
      : null;
  }
  var jh = function (a) {
    this.m = {};
    this.u = this.register("addtl_consent");
    this.H = this.register("dc_adk");
    this.I = this.register("amp");
    this.appId = this.register("dc_msid");
    this.K = this.register("asnm");
    this.L = this.register(a === 2 ? "chd" : "tfcd");
    this.O = this.register("click");
    this.register("cesc");
    this.P = this.register("uach");
    this.R = this.register("chaa");
    this.U = this.register("cmpl");
    this.v = this.register("gcsr");
    this.C = this.register("crlt");
    this.V = this.register("xdt");
    this.W = this.register("mtfIFPath");
    this.aa = this.register("dsmd");
    this.h = this.register("dcopt");
    this.ba = this.register("deal_id");
    this.devicePixelRatio = this.register("u_sd");
    this.ia = this.register("mtfIFrameRequest");
    this.register("dv3_deal");
    this.ja = this.register("dc_eid");
    this.ka = this.register("dc_xid");
    this.D = this.register("gdpr_consent");
    this.gdprApplies = this.register("gdpr");
    this.F = this.register("gpp");
    this.G = this.register("gpp_sid");
    this.height = this.register("h");
    this.register("ifmf");
    this.la = this.register("pc");
    this.ma = this.register("dcapp");
    this.na = this.register("kw");
    this.oa = this.register("mtfLeft");
    this.pa = this.register(a === 1 ? "dc_lat" : "lat");
    this.qa = this.register("ltd");
    this.ra = this.register("msdk");
    this.sa = this.register("mtfBottomFloat");
    this.ta = this.register("mtfLeftFloat");
    this.ua = this.register("mtfRightFloat");
    this.wa = this.register("mtfTopFloat");
    this.register("npa");
    this.i = this.register("nel");
    this.xa = this.register("dc_omid_p");
    this.ya = this.register("ord");
    this.register("osdl");
    this.za = this.register("osda");
    this.Aa = this.register("output");
    this.Ca = this.register("pdid");
    this.Da = this.register("pdidtype");
    this.Ea = this.register("prcl");
    this.Fa = this.register("dc_ref");
    this.Ga = this.register("trt");
    this.j = this.register("rc");
    this.l = this.register("rcsrc");
    this.Ha = this.register("dc_rxp");
    this.Ia = this.register("dc_rdid");
    this.Ma = this.register("sttr");
    this.Na = this.register("dc_sdk_apis");
    this.size = this.register("sz");
    this.Oa = this.register("stc");
    this.Pa = this.register("dc_ver");
    this.Qa = this.register("mtfTop");
    this.Ra = this.register("url");
    this.Sa = this.register("dc_rfl");
    this.Ta = this.register("tfua");
    this.Ua = this.register("u");
    this.width = this.register("w");
  };
  jh.prototype.register = function (a) {
    this.m[a] = !0;
    return a;
  };
  jh.prototype.has = function (a) {
    return !!this.m[a];
  };
  var kh = /^data-d[bc]m-.+/i,
    lh = /^https?%3A.+/i,
    mh = /^N\d+\.[A-Za-z0-9._-]*[A-Za-z0-9_-]\.?\/B\d+\.\d+/;
  function nh(a) {
    a ? (a = (a = wf.exec(a)) ? +a[1] : null) : (a = null);
    return a;
  }
  function oh(a, b, c) {
    return (b = nh(a(b)))
      ? Math.round(b)
      : c && (a = nh(a(c)))
      ? Math.round(a)
      : null;
  }
  function ph(a) {
    var b = a.style,
      c = null;
    try {
      c = vf(a);
    } catch (d) {}
    a = oh(
      function (d) {
        return d.width;
      },
      b,
      c
    );
    b = oh(
      function (d) {
        return d.height;
      },
      b,
      c
    );
    return { width: a, height: b };
  }
  var qh = function (a) {
      this.O = !1;
      this.l = this.j = this.D = this.C = this.m = this.gdprApplies = null;
      this.L = this.U = !1;
      this.aa = a;
      var b = {},
        c = t(a.attributes),
        d = c.next(),
        e;
      try {
        for (; !d.done; d = c.next()) {
          var h = d.value;
          var k = h.name;
          if (kh.test(k)) {
            var f = k.toLowerCase();
            var g =
              f.indexOf("data-dcm-param-") === 0
                ? "data-dcm-param-" + k.substring(15)
                : f;
          } else g = null;
          var l = g;
          if (l) {
            var m = h.value;
            m = m != null ? m : "";
            l === "data-dcm-click-tracker" &&
              (m = lh.test(m) ? decodeURIComponent(m) : m);
            b[l] = m;
          }
        }
      } finally {
        d && !d.done && (e = c.return) && e.call(c);
      }
      this.attributes = b;
      b = this.attributes["data-dcm-placement"];
      c = this.attributes["data-dbm-deal"];
      b || c || Ug("No placement or deal attribute set on ins tag");
      b
        ? ((this.h = 1),
          (c = mh.exec(b)) || Ug("Invalid placement: " + b),
          (this.I = c ? c[0] : ""))
        : ((this.h = 2), (this.F = c));
      this.i = new jh(this.h);
      switch (this.attributes["data-dcm-rendering-mode"]) {
        case "iframe":
          this.u = "iframe";
          break;
        case "script":
          this.u = "script";
          break;
        default:
          this.u = this.h === 2 ? "script" : "iframe";
      }
      a = ph(a);
      b = a.width;
      this.height = a.height;
      this.width = b;
      this.R = kg();
      this.v = new Ng();
    },
    rh = function (a, b) {
      a = ae((b === void 0 ? null : b) || a.m);
      if (a == null) return !0;
      b = a.o;
      var c = b[D] | 0,
        d = Kc(b, c);
      if (d != null && ((c = b[D] | 0), !F(a, c))) {
        var e = wc(d);
        e !== d &&
          (xc(a) && ((b = a.o), (c = b[D] | 0)),
          (d = e),
          (c = K(b, c, 1, d)),
          zc(b, c));
      }
      a = d;
      if (!a) return !0;
      b = c = a.o;
      c = c[D] | 0;
      d = void 0 === wb ? 2 : 4;
      var h = F(a, c);
      e = h ? 1 : d;
      d = e === 3;
      var k = !h;
      (e === 2 || k) && xc(a) && ((b = a.o), (c = b[D] | 0));
      h = Ec(b, 19);
      var f = h === rb ? 7 : h[D] | 0,
        g = Fc(f, c),
        l = !(4 & g);
      if (l) {
        var m = h,
          n = c,
          p = !!(2 & g);
        p && (n |= 2);
        for (var u = !p, A = !0, y = 0, z = 0; y < m.length; y++) {
          var Y = lc(m[y], nd, n);
          if (Y instanceof nd) {
            if (!p) {
              var O = F(Y);
              u && (u = !O);
              A && (A = O);
            }
            m[z++] = Y;
          }
        }
        z < y && (m.length = z);
        g |= 4;
        g = A ? g & -4097 : g | 4096;
        g = u ? g | 8 : g & -9;
      }
      g !== f && (E(h, g), 2 & g && Object.freeze(h));
      if (
        k &&
        !(
          8 & g ||
          (!h.length &&
            (e === 1 || (e !== 4 ? 0 : 2 & g || (!(16 & g) && 32 & c))))
        )
      ) {
        Jc(g) && ((h = Tb(h)), (g = Gc(g, c)), (c = K(b, c, 19, h)));
        k = h;
        f = g;
        for (m = 0; m < k.length; m++)
          (g = k[m]), (n = wc(g)), g !== n && (k[m] = n);
        f |= 8;
        g = f = k.length ? f | 4096 : f & -4097;
        E(h, g);
      }
      h = Hc(h, g, b, c, 19, e, l, d);
      b = t(h);
      c = b.next();
      var C;
      try {
        for (; !c.done; c = b.next()) {
          var Z = c.value,
            P;
          if ((P = fd(Z, 1) === 1 && fd(Z, 2) === 0))
            P = Dc(Z, 3, dc).includes(755);
          if (P) return !1;
        }
      } finally {
        c && !c.done && (C = b.return) && C.call(b);
      }
      if (Dc(a, 17, dc).includes(755)) {
        if ((C = ed(a, 15))) {
          var I = I === void 0 ? "" : I;
          C = Bc(a, 16);
          C = C == null || typeof C === "string" ? C : void 0;
          C = (C != null ? C : I) === "ch";
        }
        (I = C) || (I = Dc(a, 13, bc).includes(1));
      } else I = !1;
      return I;
    },
    sh = function (a, b) {
      if (b) {
        a = a.v;
        var c = c === void 0 ? {} : c;
        if (Vf(b))
          if (b.gdprApplies === !1) var d = !0;
          else if (b.tcString === "tcunavailable") d = !c.idpcApplies;
          else if (
            (c.idpcApplies || b.gdprApplies !== void 0 || c.nb) &&
            (c.idpcApplies || (zb(b.tcString) && b.tcString.length))
          ) {
            var e = e === void 0 ? "755" : e;
            b: {
              if (
                b.publisher &&
                b.publisher.restrictions &&
                ((d = b.publisher.restrictions["1"]), d !== void 0)
              ) {
                d = d[e === void 0 ? "755" : e];
                break b;
              }
              d = void 0;
            }
            d === 0
              ? (d = !1)
              : b.purpose && b.vendor
              ? ((d = b.vendor.consents),
                (d = !(!d || !d[e === void 0 ? "755" : e])) &&
                b.purposeOneTreatment &&
                b.publisherCC === "CH"
                  ? (d = !0)
                  : d && ((d = b.purpose.consents), (d = !(!d || !d["1"]))))
              : (d = !0);
          } else d = !0;
        else d = !1;
        a = Cc(a, 5, Yb(d));
        a = Cc(a, 2, kc(b.tcString));
        Cc(a, 4, kc(b.addtlConsent || ""));
      } else if (
        a.l &&
        a.j &&
        (a.l.includes("%") ? decodeURIComponent(a.l) : a.l)
          .split(",")
          .includes((2).toString())
      ) {
        b = a.v;
        a: {
          try {
            if (!a.j) {
              d = null;
              break a;
            }
            var h = hd(a.j.split("~")[0]),
              k = h.slice(0, 6),
              f = id(k),
              g = h.slice(6, 12),
              l = id(g),
              m = new gd();
            var n = Q(m, 1, f);
            var p = Q(n, 2, l);
            var u = h.slice(12),
              A = u.slice(0, 12),
              y = id(A);
            e = [];
            var z = u.slice(12).replace(/0+$/, "");
            for (c = 0; c < y; c++) {
              if (z.length === 0)
                throw Error(
                  "Found " +
                    c +
                    " of " +
                    y +
                    " sections [" +
                    e +
                    "] but reached end of input [" +
                    u +
                    "]"
                );
              var Y = id(z[0]) === 0;
              z = z.slice(1);
              var O = kd(z, u),
                C = e.length === 0 ? 0 : e[e.length - 1],
                Z = jd(O) + C;
              z = z.slice(O.length);
              if (Y) e.push(Z);
              else {
                var P = kd(z, u),
                  I = jd(P);
                for (h = 0; h <= I; h++) e.push(Z + h);
                z = z.slice(P.length);
              }
            }
            if (z.length > 0)
              throw Error(
                "Found " +
                  y +
                  " sections [" +
                  e +
                  "] but has remaining input [" +
                  z +
                  "], entire input [" +
                  u +
                  "]"
              );
            var Wa = L(p, 3, e, cc);
            var Xa = a.j;
            var Eb = Xa.includes("~") ? Xa.split("~").slice(1) : [];
            var Ya = Dc(Wa, 3, dc);
            for (e = 0; e < Ya.length; ++e)
              if (Ya[e] === 2) {
                d = Eb[e];
                break a;
              }
          } catch (Ic) {}
          d = null;
        }
        a = rh(a, d);
        Cc(b, 5, Yb(a));
      } else
        a.gdprApplies === "1"
          ? ((b = a.v), (a = rh(a)), Cc(b, 5, Yb(a)))
          : Cc(a.v, 5, Yb(!0));
    },
    th = function (a) {
      var b;
      a.W && (b = a.W[1]);
      return b || null;
    };
  function uh(a, b, c, d, e) {
    try {
      for (var h = [], k, f = 0; (k = c(a)) && a !== b && ++f < 100; ) {
        for (var g = null, l = d(k), m = 0, n = 0; n < l.length; ++n) {
          if (l[n] === a) {
            g = n - m;
            break;
          }
          e(l[n]) && ++m;
        }
        if (g === null) return null;
        h.unshift(g);
        a = k;
      }
      return h;
    } catch (p) {
      return null;
    }
  }
  function vh(a) {
    return uh(
      a,
      a.top || a,
      function (b) {
        try {
          return b.parent;
        } catch (c) {
          return null;
        }
      },
      function (b) {
        return b.frames;
      },
      function () {
        return !1;
      }
    );
  }
  function wh(a) {
    return uh(
      a,
      document.documentElement,
      function (b) {
        return b.parentElement;
      },
      function (b) {
        return b.children;
      },
      function (b) {
        return b.nodeType === 8;
      }
    );
  }
  var xh = RegExp("https?://d-\\d+\\.ampproject\\.net");
  function yh(a) {
    return "data-dcm-http-only" in a ? "http:" : "https:";
  }
  function zh(a, b, c) {
    for (var d = 0; d < c.length; d++) {
      var e = c[d];
      V(a, e.priority, Ah(b, e));
    }
  }
  function Ah(a, b) {
    a = a[b.A];
    var c = b.Z;
    if (a == null || (!c && a.length == 0) || (b.fa != null && a === b.fa))
      return [];
    var d = {};
    d[b.B] = c != null ? c : a;
    return [d];
  }
  function Bh(a, b, c, d, e, h) {
    e = e === void 0 ? "1" : e;
    h = h === void 0 ? "0" : h;
    a = a[b];
    if (!a) return [];
    a = String(a).toLowerCase();
    b = {};
    if ((d === void 0 ? 0 : d) && ("0" == a || "false" == a)) b[c] = h;
    else if ("1" == a || "true" == a) b[c] = e;
    return b[c] ? [b] : [];
  }
  function Ch(a, b, c, d) {
    var e,
      h = !1,
      k = 0,
      f = a.__cmp ? 1 : 0;
    f |= a.__tcfapi ? 2 : 0;
    f |= a.__gpp ? 16 : 0;
    de(
      function (p) {
        Af(p, "google_osd_static_frame") && (k = p == a.top ? 2 : 1);
        Af(p, "__cmpLocator") && (f |= 4);
        Af(p, "__tcfapiLocator") && (f |= 8);
        Af(p, "__gppLocator") && (f |= 32);
        if (!ce(p)) return !1;
        if (p.mraid)
          try {
            e = p.mraid.getVersion();
          } catch (u) {}
        p.MRAID_ENV &&
          ((e = p.MRAID_ENV.version || void 0),
          (c.P = p.MRAID_ENV.sdk || void 0));
        p.omid_v1_present && (h = !0);
        return !1;
      },
      !0,
      a
    );
    var g = [];
    if (e) {
      var l = e.split(".")[0];
      l == "2" ? g.push(5) : l == "3" && g.push(6);
      c.P && W(b, 47, d.ra, c.P);
    }
    h && g.push(7);
    if ((l = c.attributes["data-dcm-api-frameworks"])) {
      l = l.split ? l.split(",") : [l];
      for (var m = 0; m < l.length; ++m) {
        var n = +l[m];
        n > 0 && g.indexOf(n) === -1 && g.push(n);
      }
    }
    g.length > 0 && W(b, 45, d.Na, g);
    k && W(b, 57, d.za, k);
    f && W(b, 49, d.U, f);
  }
  var Dh =
      /^(?:https?:)?\/\/(?:ad\.doubleclick\.net|pagead2\.googlesyndication\.com)(?:\/ddm)?\/ad[ij]\/(N[^;]+)/,
    Eh = /(^| )dcmads( |$)/,
    X;
  function Fh(a, b, c) {
    a = ya(Gh, a);
    return Hg(Tg, b, c, a);
  }
  function Gh(a, b) {
    X && X.version
      ? ((b.rm = X.u || ""),
        (b.mode = X.h ? X.h + "" : "0"),
        X.I ? (b.plcmt = X.I || "") : X.F && (b.deal = X.F || ""),
        Hh(b, X))
      : ((b.mode = "0"),
        (b.ver = "107." + (a.dcmads.version.loader || "?")),
        (b.rm = ""));
  }
  function Hh(a, b) {
    a.ver = b.version || "";
    b.O && (a.rxp = 1);
    (b = b.G && tg(b.G)) && b.length && (a.eids = b);
  }
  function Ih(a, b) {
    if (!a) return null;
    a = a.split(b + "=");
    a = a[1] || a[0];
    return new RegExp(
      "\\${" + (b === "gpp" ? "gpp_string" : b) + "(_[0-9]+)?}",
      "i"
    ).test(a)
      ? null
      : a;
  }
  function Jh(a, b, c, d) {
    var e = Fh(a, 672, function (h) {
      h.gdprApplies != null && (c.gdprApplies = h.gdprApplies ? "1" : "0");
      c.m = h.tcString || null;
      c.gdprApplies !== "1" || c.m || (c.m = "tcunavailable");
      c.D = h.addtlConsent || null;
      c.C = "a";
      sh(c, h);
      Kh(a, b, c, !0);
    });
    Xf(d)
      .then(e)
      .catch(function (h) {
        Tg.h(672, h, void 0, ya(Gh, a));
      });
  }
  function Lh(a, b, c, d) {
    var e = !1,
      h = Fh(a, 1313, function (k) {
        var f = k.pingData,
          g;
        (g = f.signalStatus === "ready") ||
          ((f = f.applicableSections),
          (g = !f || (f.length === 1 && f[0] === -1)));
        g &&
          !e &&
          ((e = !0),
          (c.j = k.pingData.gppString),
          (c.l = k.pingData.applicableSections.join(",")),
          (c.C = "a"),
          sh(c),
          Kh(a, b, c, !0),
          d.removeEventListener(k.listenerId));
      });
    d.addEventListener(h);
  }
  function Kh(a, b, c, d) {
    d = d === void 0 ? !1 : d;
    if (!Mh(a, b, c)) {
      a.document.featurePolicy &&
        a.document.featurePolicy.allowsFeature &&
        a.document.featurePolicy.allowsFeature("attribution-reporting") &&
        (c.U = !0);
      var e = d;
      if (c.u === "script") {
        var h = c.G;
        var k = h.h.hasOwnProperty(4) ? h.h[4] : "";
        if (k === Zg.M.T || k === $g.M.T || e) c.L = !0;
      }
      var f = new xg(15360, c.h === 1 ? ";" : void 0),
        g = c.i;
      var l = c.attributes,
        m = c.i,
        n = l["data-dcm-click-tracker"];
      if (n == null) var p = [];
      else {
        var u = l["data-dcm-landing-page-escapes"] || "";
        u !== "0" && u !== "1" && u !== "2" && (u = "");
        var A = {};
        A[m.O + u] = n;
        l["data-dcm-reverse-click-tracker"] != null && (A[m.h] = "rcl");
        p = [A];
      }
      V(f, 37, p);
      if (c.H) {
        var y = gh(c.H);
        var z = y ? eh(y) : "";
        W(f, 48, g.C, z);
      }
      var Y = c.attributes,
        O = [],
        C;
      for (C in Y) C.indexOf("data-dcm-param-") == 0 && O.push(C);
      if (O.length == 0) var Z = [];
      else {
        var P = [];
        O.sort();
        for (var I = 0; I < O.length; I++) {
          if (P.length > 0) {
            var Wa = void 0,
              Xa = P[0],
              Eb = {};
            for (Wa in Xa) Eb[Wa] = Xa[Wa];
            var Ya = Eb;
          } else Ya = {};
          var Ic = Ya,
            Me = O[I],
            Lc = encodeURIComponent(Me.substring(15));
          Lc && !c.i.has(Lc) && ((Ic[Lc] = Y[Me]), P.unshift(Ic));
        }
        Z = P;
      }
      V(f, 28, Z);
      b: {
        var Ba = Ba === void 0 ? w : Ba;
        var ab = Ba.context || Ba.AMP_CONTEXT_DATA;
        if (!ab)
          try {
            ab = Ba.parent.context || Ba.parent.AMP_CONTEXT_DATA;
          } catch (ji) {}
        var Ne, Oe;
        if (
          ((Ne = ab) == null ? 0 : Ne.pageViewId) &&
          ((Oe = ab) == null ? 0 : Oe.canonicalUrl) &&
          ab
        )
          var Mc = !0;
        else {
          for (var Pe = c.R, Nc = 0; Nc < Pe.length; Nc++)
            if (xh.test(Pe[Nc].url)) {
              Mc = !0;
              break b;
            }
          Mc = !1;
        }
      }
      Mc && W(f, 55, g.I, "1");
      var Qh = ce(a.top) ? 0 : 1;
      W(f, 43, g.V, Qh);
      var Qe = tg(c.G);
      Qe.length && W(f, 4, g.ja, Qe);
      c.O && W(f, 3, g.Ha, "1");
      W(f, 2, g.Pa, c.version || "?");
      var Re = c.ba || 0;
      if (Re) {
        var Oc = new Date().getTime() - Re;
        Oc > 99999 && (Oc = "M");
        var Se = Oc;
      } else Se = "";
      W(f, 58, g.Ma, Se);
      Ch(a, f, c, g);
      var Te;
      var Pc = Pc === void 0 ? w : Pc;
      var Ue = Pc.devicePixelRatio;
      (Te = yb(Ue) ? +Ue.toFixed(3) : null) && W(f, 13, g.devicePixelRatio, Te);
      var Ve = c.attributes["data-dcm-ssaid"];
      if (Ve) {
        var Qc = {};
        Qc[c.i.Ca] = Ve;
        Qc[c.i.Da] = "ssaid";
        var We = [Qc];
      } else We = [];
      V(f, 32, We);
      if (c.K) {
        for (
          var Rh = g.P, Xe = c.K, S = [], Ye = 0, Rc = 0;
          Rc < Xe.length;
          Rc++
        ) {
          var Hb = Xe.charCodeAt(Rc);
          Hb > 255 && ((S[Ye++] = Hb & 255), (Hb >>= 8));
          S[Ye++] = Hb;
        }
        var Sc = 3;
        Sc === void 0 && (Sc = 0);
        fb();
        for (
          var ja = Za[Sc],
            Tc = Array(Math.floor(S.length / 3)),
            Uc = ja[64] || "",
            ka = 0,
            Ze = 0;
          ka < S.length - 2;
          ka += 3
        ) {
          var $e = S[ka],
            af = S[ka + 1],
            bf = S[ka + 2],
            Sh = ja[$e >> 2],
            Th = ja[(($e & 3) << 4) | (af >> 4)],
            Uh = ja[((af & 15) << 2) | (bf >> 6)],
            Vh = ja[bf & 63];
          Tc[Ze++] = Sh + Th + Uh + Vh;
        }
        var Vc = 0,
          cf = Uc;
        switch (S.length - ka) {
          case 2:
            (Vc = S[ka + 1]), (cf = ja[(Vc & 15) << 2] || Uc);
          case 1:
            var df = S[ka];
            Tc[Ze] = ja[df >> 2] + ja[((df & 3) << 4) | (Vc >> 4)] + cf + Uc;
        }
        var Wh = Tc.join("");
        W(f, 39, Rh, Wh);
      }
      if (c.h === 1)
        W(f, 5, "sz", c.width && c.height ? c.width + "x" + c.height : "");
      else {
        W(f, 1, g.Aa, c.u == "iframe" ? "html" : "js");
        var Wc = {};
        Wc[g.width] = c.width;
        Wc[g.height] = c.height;
        V(f, 5, [Wc]);
      }
      var Xh = c.aa,
        Yh = vh(a) || ["?"],
        Zh = wh(Xh) || ["?"];
      var ef = Yh.join(",") + ":" + Zh.join(","),
        ff = ef.length;
      if (ff === 0) var Ca = 0;
      else {
        for (var Da = 305419896, Xc = 0; Xc < ff; Xc++)
          Da ^= ((Da << 5) + (Da >> 2) + ef.charCodeAt(Xc)) & 4294967295;
        Ca = Da > 0 ? Da : 4294967296 + Da;
      }
      W(f, 33, g.H, Ca);
      var Ib = c.i,
        gf = /^([0-9]+)$/.exec(c.attributes["data-dcm-refresh-count"]);
      if (c.H && c.V) {
        var $h = c.V,
          hf = gh(c.H);
        if (hf) {
          var Yc = dh(hf),
            jf = Yc[Ca] || 0;
          Yc[Ca] = jf + 1;
          var kf = gh($h);
          kf && (dh(kf)[Ca] = Yc[Ca]);
          var lf = jf;
        } else lf = 0;
        var mf = lf;
        gf
          ? (W(f, 34, Ib.j, gf[1]), W(f, 59, Ib.l, "p"))
          : mf && (W(f, 34, Ib.j, mf), W(f, 59, Ib.l, "h"));
      }
      var nf = w.navigator;
      nf.connection && nf.connection.saveData && W(f, 46, g.aa, "1");
      ed(c.v, 5) && W(f, 51, g.Oa, "1");
      c.L && W(f, 52, g.K, "1");
      var of, pf;
      typeof ((of = a.navigator) == null
        ? void 0
        : (pf = of.userAgentData) == null
        ? void 0
        : pf.getHighEntropyValues) === "function" && W(f, 54, g.R, "1");
      zh(f, c.attributes, [
        { priority: 42, A: "data-dcm-app-id", B: g.appId },
        { priority: 41, A: "data-dcm-publisher-url", B: g.Fa },
        { priority: 27, A: "data-dcm-keywords", B: g.na },
        { priority: 31, A: "data-dcm-impression-exchange-id", B: g.la },
        {
          priority: 44,
          A: "data-dcm-omid-partner",
          B: g.xa,
          fa: "[OMIDPARTNER]",
        },
      ]);
      V(f, 14, Bh(c.attributes, "data-dcm-underage", g.Ta));
      V(f, 15, Bh(c.attributes, "data-dcm-child-directed", g.L));
      V(f, 25, Bh(c.attributes, "data-dcm-limited-ads", g.qa));
      V(
        f,
        35,
        Bh(c.attributes, "data-dcm-purchased-traffic", g.Ga, !0, "1", "2")
      );
      if (c.h === 2 || yh(c.attributes) == "https:")
        V(f, 24, Bh(c.attributes, "data-dcm-limit-ad-tracking", g.pa)),
          V(
            f,
            23,
            Ah(c.attributes, { A: "data-dcm-resettable-device-id", B: g.Ia })
          );
      c.m && W(f, 18, g.D, c.m);
      c.gdprApplies != null && W(f, 19, g.gdprApplies, c.gdprApplies);
      c.C && W(f, 50, g.v, c.C);
      c.D && W(f, 20, g.u, c.D);
      c.j && W(f, 17, g.F, c.j);
      c.l && W(f, 16, g.G, c.l);
      if (c.U) W(f, 22, g.i, "1");
      else {
        var Zc, qf;
        ((Zc = a.document.featurePolicy) == null
          ? 0
          : (qf = Zc.features) == null
          ? 0
          : qf.call(Zc).includes("attribution-reporting")) &&
          W(f, 22, g.i, "0");
      }
      if (c.h === 2) {
        var rf = c.i;
        W(f, 0, rf.ba, c.F);
        var $c = ng(c.R);
        W(f, 40, rf.Ra, $c.i ? $c.i.url : $c.h.url);
      } else {
        var M = c.i,
          ai = Lg(c.R);
        V(f, 40, Mg(M.Sa, ai));
        var sf = c.attributes,
          bb = "";
        "data-dcm-http-only" in sf && (bb += "h");
        "data-dcm-https-only" in sf && (bb += "s");
        bb == "" && (bb = "n");
        W(f, 60, M.Ea, bb);
        W(
          f,
          36,
          M.ya,
          ("00000" + Math.floor(Math.random() * 2176782336).toString(36)).slice(
            -6
          )
        );
        var la = c.attributes;
        if ("data-dcm-multi-bottom-float" in la) {
          var cb = c.i.sa;
          var aa = la["data-dcm-multi-bottom-float"];
        } else
          "data-dcm-multi-left-float" in la
            ? ((cb = c.i.ta), (aa = la["data-dcm-multi-left-float"]))
            : "data-dcm-multi-right-float" in la
            ? ((cb = c.i.ua), (aa = la["data-dcm-multi-right-float"]))
            : "data-dcm-multi-top-float" in la &&
              ((cb = c.i.wa), (aa = la["data-dcm-multi-top-float"]));
        cb && aa && ((aa = aa.split ? aa.split(",") : aa), W(f, 11, cb, aa));
        zh(f, c.attributes, [
          {
            priority: 29,
            A: "data-dcm-anonymous-inventory",
            B: M.h,
            Z: "anid",
          },
          {
            priority: 8,
            A: "data-dcm-disable-iframe-breakout",
            B: M.ia,
            Z: "false",
          },
          { priority: 7, A: "data-dcm-dart-iframe-path", B: M.W },
          { priority: 26, A: "data-dcm-external-id", B: M.ka },
          { priority: 38, A: "data-dcm-in-app", B: M.ma, Z: "1" },
          { priority: 6, A: "data-dcm-interstitial", B: M.h, Z: "1_ist" },
          { priority: 9, A: "data-dcm-left-float", B: M.oa },
          { priority: 10, A: "data-dcm-top-float", B: M.Qa },
          { priority: 30, A: "data-dcm-user-defined", B: M.Ua },
        ]);
      }
      if (c.h === 2)
        var tf = Cg(f, "https:", "bid.g.doubleclick.net", "/xbbe/bid/xpub?");
      else {
        var bi = yh(c.attributes),
          ci = "/ddm/" + (c.u == "script" ? "adj" : "adi") + "/" + c.I + ";",
          di = ed(c.v, 5)
            ? "ad.doubleclick.net"
            : "pagead2.googlesyndication.com";
        tf = Cg(f, bi, di, ci);
      }
      var Jb = tf;
      if (c.h === 1 && !Dh.test(Jb)) throw Error("Invalid tag URL: " + Jb);
      var ad = a.document;
      if (c.u === "script") {
        var uf = '<script src="' + Jb + '">\x3c/script>';
        if (c.L) {
          var ba = Nh(ad);
          Oh(ba);
          b.appendChild(ba);
          var xf = ba,
            yf =
              '<head><meta http-equiv="origin-trial" content="' +
              ((th(c) || "") + '"/></head><body>' + uf + "</body>");
          if (Sg) {
            var ei = Og(yf);
            xf.srcdoc = ve(ei);
          } else {
            var zf = xf.contentWindow;
            if (zf) {
              var bd = zf.document;
              bd.open("text/html", "replace");
              var fi = Og(String(yf));
              bd.write(ve(fi));
              bd.close();
            }
          }
        } else {
          b.children.length > 1 ||
            (b.children.length == 1 &&
              b.children[0].tagName.toLowerCase() == "b") ||
            (b.style.display = "none");
          var gi = Og(uf);
          ad.write(ve(gi));
        }
      } else (ba = Nh(ad)), (ba.src = Jb), Oh(ba), b.appendChild(ba);
      ba && Hf(a, ba);
      b.style.textDecoration = "none";
      ((a.navigator && a.navigator.platform) || "").substr(0, 2) === "iP" &&
        c.P === "Google Mobile Ads" &&
        ((b.style.display = "block"),
        ce(a.top) &&
          a.top.document &&
          a.top.document.body &&
          (a.top.document.body.style.margin = "0"));
    }
  }
  function Ph(a, b) {
    if (/Chrome/.test(a.navigator.userAgent)) {
      var c = th(b);
      c &&
        de(function (d) {
          d = d.document;
          if (c && d.head) {
            var e = Cf("META");
            d.head.appendChild(e);
            e.httpEquiv = "origin-trial";
            e.content = c;
          }
          return !1;
        }, !1);
    }
  }
  function Oh(a) {
    a && (a.allow = "attribution-reporting");
  }
  function Nh(a) {
    a = a.createElement("iframe");
    var b = a.style;
    b.width = "100%";
    b.height = "100%";
    b.border = "0";
    b.margin = "0";
    b.padding = "0";
    a.marginWidth = "0";
    a.marginHeight = "0";
    a.scrolling = "no";
    a.frameBorder = "0";
    a.title = "advertisement";
    return a;
  }
  function hi(a, b) {
    if (a.ReportingObserver) {
      var c = function (e) {
          e = t(e);
          var h = e.next(),
            k;
          try {
            for (; !h.done; h = e.next()) {
              var f = h.value,
                g = f.type,
                l = f.body;
              if (l && g === "intervention") {
                var m = {
                  t: g,
                  rid: l.id,
                  tm: b.h,
                  inv: b.h === 1 ? b.I : b.F,
                  ln: l.lineNumber,
                  cn: l.columnNumber,
                  src: l.sourceFile,
                  msg: l.message,
                };
                Hh(m, b);
                Ig(Eg, "dcmror", m, 0.1);
              }
            }
          } finally {
            h && !h.done && (k = e.return) && k.call(e);
          }
        },
        d = new a.ReportingObserver(c, { buffered: !0 });
      d.observe();
      a.addEventListener("unload", function () {
        c(d.takeRecords());
        d.disconnect();
      });
    }
  }
  function Mh(a, b, c) {
    c.K = a.dcmads.uach || null;
    if (!c.K && a.dcmads.uachp) {
      var d = Fh(a, 986, function () {
          c.K = a.dcmads.uach || "_";
          Kh(a, b, c, !0);
        }),
        e = ya(Gh, a);
      a.dcmads.uachp.then(d).catch(function (h) {
        Tg.h(986, h, void 0, e);
        d();
      });
      return !0;
    }
    return !1;
  }
  var ii = window;
  ii.dcmads = ii.dcmads || {};
  ii.dcmads.version = ii.dcmads.version || {};
  Hg(
    Tg,
    529,
    function (a) {
      var b = a.document;
      og = !1;
      var c = new qg(),
        d = t(Object.values(Vg)),
        e = d.next(),
        h;
      try {
        for (; !e.done; e = d.next()) c.h[e.value] = "";
      } finally {
        e && !e.done && (h = d.return) && h.call(d);
      }
      try {
        bh(c, a.dcmads && a.dcmads.eids);
        var k = /.*#.*eids=([0-9,|]+)/.exec(a.location.href);
        k && bh(c, k[1]);
      } catch (p) {}
      ah(a, c, Yg);
      ah(a, c, $g);
      b.body ||
        ((d = Je()),
        b.write(ve(d)),
        b.body || Ug("Body element does not exist"));
      b = b.getElementsByClassName
        ? b.getElementsByClassName("dcmads")
        : b.getElementsByTagName("ins");
      for (d = 0; d < b.length; d++)
        if (
          ((e = b[d]),
          (e.getAttribute("data-dcm-placement") ||
            e.getAttribute("data-dbm-deal")) &&
            Eh.test(e.className) &&
            !e.getAttribute("data-dcm-processed"))
        ) {
          var f = e;
          f.setAttribute("data-dcm-processed", "y");
          break;
        }
      if (f) {
        X = new qh(f);
        X.G = c;
        X.O = !!a.dcmads.version.experiment;
        X.ba = a.dcmads.startTime || 0;
        X.W = a.dcmads.ots || {};
        X.version = "107." + (a.dcmads.version.loader || "?");
        d = fh(a.googDdmPs);
        c = null;
        e = !0;
        e = e === void 0 ? !1 : e;
        h = [w.top];
        b = [];
        k = 0;
        for (var g; (g = h[k++]); ) {
          (e && !ce(g)) || b.push(g);
          try {
            if (g.frames)
              for (var l = 0; l < g.frames.length && h.length < 1024; ++l)
                h.push(g.frames[l]);
          } catch (p) {}
        }
        e = t(b);
        h = e.next();
        var m;
        try {
          for (; !h.done; h = e.next()) {
            var n = h.value;
            if (n !== a && (c = fh(n.googDdmPs))) break;
          }
        } finally {
          h && !h.done && (m = e.return) && m.call(e);
        }
        if (d)
          (m = d),
            c &&
              ((n = new ch(m)),
              (d = new ch(c)),
              d.timestamp() > n.timestamp() ? ih(d, n) : ih(n, d));
        else if (c) (a.googDdmPs = m = {}), ih(new ch(c), new ch(m));
        else {
          m = "";
          for (n = 0; n < 10; ++n)
            m +=
              "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_.!*'()"[
                Math.floor(Math.random() * 70)
              ];
          a.googDdmPs = m = { corr: m, ts: Date.now(), aacm: {} };
        }
        c
          ? (n = c)
          : (n = b[0]) && n !== a
          ? ((n.googDdmPs = n = {}), ih(new ch(m), new ch(n)))
          : (n = m);
        X.H = m;
        X.V = n;
        m = X;
        hi(a, m);
        Ph(a, m);
        if ((n = Ih(m.attributes["data-dcm-gdpr-consent"], "gdpr_consent")))
          m.m = n;
        c = Ih(m.attributes["data-dcm-gdpr-applies"], "gdpr");
        /[01]/.test(c) && (m.gdprApplies = c);
        if (
          (b = Ih(m.attributes["data-dcm-additional-consent"], "addtl_consent"))
        )
          m.D = b;
        if ((b = Ih(m.attributes["data-dcm-gpp"], "gpp"))) m.j = b;
        if ((d = Ih(m.attributes["data-dcm-gpp-sid"], "gpp_sid"))) m.l = d;
        n || c != null || b || d ? ((m.C = "m"), (n = !0)) : (n = !1);
        if (n) n = {};
        else if (
          ((n = {}),
          (c = new eg(a)),
          Kf(c.caller) && (n.ea = c),
          (c = new Tf(a)),
          typeof c.i.__tcfapi === "function" || Yf(c) != null)
        )
          n.ha = c;
        n.ea
          ? Lh(a, f, m, n.ea)
          : n.ha
          ? Jh(a, f, m, n.ha)
          : (sh(m), Kh(a, f, m));
      } else Ug("No ad ins element found");
    },
    ya(Gh, ii)
  )(ii);
}.call(this));
