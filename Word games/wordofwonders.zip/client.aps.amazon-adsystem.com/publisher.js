window.__aps_slice = 4; /*! web-client-bundle - v26.1102.1713 - 2026-11-02 17:13:26 */
!(function () {
  "use strict";
  const t = new Uint8Array([
    42, 94, 79, 102, 182, 87, 18, 39, 206, 243, 126, 191, 4, 63, 77, 59, 162,
    241, 193, 101, 74, 1, 189, 21, 73, 186, 68, 154, 111, 81, 242, 165, 135,
    180, 163, 105, 50, 210, 243, 84, 28, 112, 180, 154, 121, 30, 77, 205, 244,
    40, 170, 162, 232, 228, 11, 227, 246, 206, 15, 66, 249, 209, 155, 230, 40,
    163, 9, 155, 225, 186, 136, 158, 220, 243, 29, 125, 108, 215, 138, 132, 162,
    138, 154, 50, 162, 121, 25, 242, 186, 30, 94, 86, 163, 178, 51, 115, 114,
    236, 70, 144, 3, 28, 80, 147, 126, 214, 189, 247, 91, 89, 174, 197, 197,
    183, 170, 91, 8, 14, 57, 223, 112, 162, 142, 158, 85, 114, 94, 54, 177, 225,
    193, 215, 183, 203, 176, 135, 119, 151, 106, 124, 147, 64, 185, 186, 154,
    65, 115, 229, 149, 248, 103, 83, 0, 185, 239, 180, 180, 9, 121, 175, 91,
    167, 210, 228, 224, 59, 152, 103, 84, 54, 29, 154, 26, 192, 30, 30, 230,
    189, 46, 31, 44, 247, 213, 82, 224, 87, 119, 243, 198, 63, 123, 158, 78, 91,
    6, 158, 34, 159, 215, 185, 65, 197, 90, 186, 113, 79, 40, 200, 209, 165,
    199, 128, 110, 19, 63, 125, 229, 20, 205, 93, 22, 177, 73, 126, 222, 207,
    218, 164, 126, 105, 197, 65, 146, 175, 93, 49, 99, 244, 146, 186, 117, 50,
    116, 237, 57, 73, 29, 194, 250, 216, 125, 160, 101, 201, 143, 48, 173, 154,
    169, 182, 163, 159, 150, 123, 175, 26, 29, 21, 75, 254, 6, 218, 88, 64, 9,
    238, 70, 40, 48, 251, 227, 255, 14, 252, 121, 116, 203, 193, 211, 50, 29,
    13, 120, 107, 88, 124, 129, 92, 214, 187, 203, 14, 234, 59, 113, 251, 68, 2,
    197, 99, 211, 134, 234, 215, 62, 106, 160, 163, 205, 103, 10, 244, 47, 67,
    229, 124, 164, 209, 86, 98, 250, 150, 19, 2, 48, 7, 217, 47, 108, 179, 137,
    29, 118, 253, 240, 198, 209, 169, 123, 234, 193, 55, 151, 183, 196, 133,
    243, 111, 68, 60, 109, 15, 222, 215, 190, 84, 32, 161, 155, 6, 221, 9, 91,
    244, 252, 231, 34, 70, 249, 254, 126, 47, 145, 125, 203, 199, 164, 76, 200,
    255, 242, 96, 213, 54, 245, 80, 152, 219, 38, 38, 88, 107, 171, 167, 140,
    205, 250, 85, 42, 240, 247, 239, 106, 49, 163, 88, 77, 71, 185, 215, 102,
    84, 142, 194, 238, 193, 69, 189, 200, 85, 4, 24, 127, 232, 164, 61, 27, 31,
    192, 160, 81, 62, 75, 2, 248, 252, 158, 31, 229, 142, 61, 109, 149, 222,
    245, 236, 130, 102, 181, 88, 110, 177, 25, 177, 190, 237, 122, 51, 60, 100,
    33, 47, 94, 199, 39, 135, 90, 14, 29, 181, 6, 103, 45, 93, 144, 131, 188,
    184, 179, 103, 222, 216, 182, 143, 162, 221, 15, 201, 102, 140, 100, 227,
    179, 120, 252, 193, 19, 93, 250, 0, 27, 52, 240, 252, 40, 142, 218, 208, 81,
    211, 133, 190, 65, 240, 215, 64, 205, 85, 247, 205, 210, 255, 193, 106, 149,
    155, 120, 62, 145, 81, 139, 227, 62, 75, 159, 37, 244, 102, 106, 117, 36,
    171, 31, 184, 50, 171, 235, 246, 36, 249, 88, 10, 214, 139, 224, 160, 86, 8,
    144, 218, 183, 238, 141, 252, 130, 111, 200, 38, 91, 55, 119, 105, 134, 219,
    12, 149, 106, 45, 35, 72, 102, 65, 91, 187, 244, 8, 73, 110, 250, 22, 186,
    33, 176, 44, 135, 12, 192, 62, 60, 255, 35, 253, 44, 113, 58, 242, 222, 60,
    145, 228, 207, 59, 23, 255, 173, 47, 234, 254, 254, 30, 171, 11, 60, 87, 79,
    218, 109, 175, 23, 255, 197, 111, 134, 83, 200, 250, 202, 117, 111, 156,
    243, 38, 157, 77, 88, 94, 63, 66, 101, 42, 51, 254, 208, 205, 13, 144, 240,
    191, 7, 88, 9, 41, 57, 85, 18, 75, 218, 18, 4, 51, 179, 93, 145, 234, 147,
    82, 72, 229, 77, 72, 78, 154, 75, 122, 93, 231, 240, 183, 141, 143, 122, 82,
    255, 217, 76, 184, 75, 190, 91, 255, 116, 77, 254, 146, 211, 148, 177, 170,
    158, 59, 112, 202, 57, 184, 41, 6, 139, 39, 65, 254, 166, 3, 217, 93, 41, 1,
    215, 16, 112, 238, 62, 246, 183, 159, 46, 115, 207, 175, 144, 241, 71, 60,
    233, 47, 94, 133, 51, 12, 63, 242, 171, 123, 235, 89, 106, 213, 255, 216,
    235, 111, 31, 143, 216, 217, 236, 13, 80, 251, 192, 159, 47, 174, 114, 161,
    77, 165, 139, 192, 238, 112, 134, 180, 106, 154, 56, 179, 162, 98, 57, 28,
    59, 92, 133, 227, 113, 249, 102, 176, 3, 19, 245, 141, 159, 48, 231, 90,
    228, 244, 229, 173, 100, 230, 33, 205, 22, 231, 123, 90, 139, 75, 252, 134,
    220, 243, 170, 7, 32, 136, 69, 9, 234, 125, 27, 204, 31, 251, 163, 218, 1,
    198, 246, 122, 98, 251, 1, 130, 98, 114, 236, 231, 115, 6, 233, 147, 232,
    73, 29, 207, 229, 241, 63, 60, 165, 178, 226, 159, 13, 124, 200, 114, 54,
    198, 102, 213, 255, 38, 213, 225, 4, 23, 105, 69, 166, 215, 113, 134, 2, 14,
    129, 76, 64, 74, 48, 98, 159, 219, 73, 75, 60, 237, 120, 114, 144, 81, 242,
    206, 66, 111, 175, 177, 86, 55, 129, 34, 198, 84, 63, 87, 242, 115, 43, 81,
    149, 49, 107, 213, 179, 233, 105, 210, 134, 53, 61, 248, 11, 73, 195, 244,
    184, 248, 93, 54, 242, 111, 65, 75, 63, 14, 180, 177, 71, 5, 55, 111, 129,
    179, 168, 80, 72, 214, 13, 25, 75, 0, 191, 190, 72, 172, 141, 70, 104, 241,
    169, 158, 104, 131, 130, 14, 249, 12, 42, 179, 87, 98, 173, 42, 195, 111,
    205, 218, 226, 240, 165, 81, 158, 27, 103, 161, 128, 85, 250, 152, 147, 145,
    116, 29, 119, 128, 252, 240, 95, 162, 6, 79, 188, 140, 183, 26, 150, 91,
    184, 180, 8, 27, 7, 3, 74, 93, 70, 57, 169, 210, 36, 82, 24, 116, 234, 217,
    241, 64, 24, 250, 172, 230, 109, 194, 235, 58, 37, 52, 127, 79, 77, 220, 86,
    231, 178, 202, 42, 176, 114, 135, 215, 196, 161, 72, 101, 252, 107, 45, 222,
    73, 102, 37, 205, 56, 177, 142, 100, 77, 183, 27, 245, 90, 2, 100, 38, 127,
    199, 201, 115, 183, 142, 121, 56, 185, 179, 90, 168, 120, 45, 167, 207, 107,
    182, 17, 85, 161, 78, 113, 92, 197, 213, 22, 210, 28, 189, 204, 118, 121,
    163, 88, 52, 27, 19, 242, 41, 82, 180, 81, 186, 185, 166, 161, 253, 230, 93,
    42, 154, 204, 123, 153, 128, 120, 17, 132, 49, 204, 55, 221, 213, 34, 121,
    118, 143, 207, 100, 55, 24, 42, 12, 158, 55, 40, 177, 238, 135, 243, 29,
    166, 26, 75, 99, 108, 190, 214, 17, 198, 250, 4, 14, 184, 180, 250, 160, 90,
    190, 27, 76, 93, 81, 245, 104, 185, 104, 237, 35, 141, 66, 214, 86, 238,
    166, 161, 207, 138, 195, 93, 9, 185, 67, 206, 174, 232, 109, 50, 107, 71,
    114, 64, 208, 88, 81, 162, 242, 139, 120, 24, 41, 124, 172, 154, 159, 83,
    112, 56, 54, 247, 211, 57, 20, 214, 42, 23, 19, 145, 84, 43, 126, 8, 212,
    27, 49, 225, 85, 23, 9, 17, 82, 21, 251, 63, 148, 247, 25, 103, 122, 5, 92,
    185, 231, 86, 161, 74, 83, 79, 88, 192, 168, 80, 110, 92, 183, 152, 96, 154,
    128, 46, 223, 53, 127, 186, 254, 57, 189, 102, 111, 208, 211, 84, 164, 113,
    114, 237, 75, 120, 78, 78, 198, 114, 208, 93, 125, 210, 183, 30, 18, 211,
    237, 6, 191, 143, 86, 209, 162, 47, 231, 19, 70, 162, 23, 120, 237, 205, 49,
    103, 117, 112, 64, 125, 12, 52, 112, 210, 225, 34, 14, 225, 72, 248, 198,
    122, 239, 103, 22, 112, 159, 187, 116, 52, 35, 249, 228, 152, 96, 143, 210,
    143, 75, 0,
  ]);
  function e(t) {
    const e = new TextEncoder().encode(t);
    let n = 2166136261;
    for (let t = 0; t < e.length; ++t)
      (n ^= e[t]), (n = Math.imul(n, 16777619));
    return n >>> 0;
  }
  const n = (t, e) => `${t}_${e}_salt`,
    s = (t, e = 200) => (t.length <= e ? t : `${t.substring(0, e)}...`);
  let o = !1;
  try {
    ((t, e) => {
      const n = new Set(),
        o = [];
      try {
        const e = t.top?.location.hostname;
        e && n.add(e);
      } catch (t) {
        const e = t;
        o.push(s(e.message));
      }
      try {
        n.add(t.location.hostname);
      } catch (t) {
        const e = t;
        o.push(s(e.message));
      }
      try {
        const e = t.location.href;
        n.add(new URL(e).hostname);
      } catch (t) {
        const e = t;
        o.push(s(e.message));
      }
      try {
        const t = e.URL;
        n.add(new URL(t).hostname);
      } catch (t) {
        const e = t;
        o.push(s(e.message));
      }
      if (0 === n.size)
        throw new Error(`Unable to determine hostname: ${JSON.stringify(o)}`);
      return n;
    })(window, document).forEach((s) => {
      o ||
        (o = ((t, s) => {
          for (let o = 0; o < 14; o++) {
            const a = e(n(t, o)) % 11033,
              r = a % 8;
            if (!(s[Math.floor(a / 8)] & (1 << r))) return !1;
          }
          return !0;
        })(s, t));
    });
  } catch (t) {
    const e = t;
    (window._aps_telemetry = window._aps_telemetry || {}),
      (window._aps_telemetry.alarms = window._aps_telemetry.alarms || []),
      window._aps_telemetry.alarms.push({
        hash: "5ba43c",
        context: { message: e?.message },
      });
  }
  if (o) throw new Error("Unauthorized");
  !(function () {
    "use strict";
    const t = "debugSession/end",
      e = "prepend/events",
      n = "populator/ran";
    var a, o, i, s, r;
    !(function (t) {
      (t.ManagedWeb = "mw"), (t.SelfServeWeb = "ssw");
    })(a || (a = {})),
      (function (t) {
        (t.push = "push"),
          (t.listenerSuccess = "listenerSuccess"),
          (t.direct = "direct");
      })(o || (o = {})),
      (function (t) {
        (t.internal = "internal"),
          (t.apstag = "apstag"),
          (t.webpage = "webpage"),
          (t.dtbm = "dtbm");
      })(i || (i = {})),
      (function (t) {
        (t.completed = "completed"),
          (t.waiting = "waiting"),
          (t.cancelled = "cancelled");
      })(s || (s = {})),
      (function (t) {
        (t.started = "started"),
          (t.error = "error"),
          (t.unknown = "unknown"),
          (t.deactivated = "deactivated"),
          (t.analytics = "analytics");
      })(r || (r = {}));
    const c = { ...s, ...r },
      d = { key: "consent/hasPurposeOneConsent", default: !1 };
    class l {
      constructor(t) {
        (this.getItem = (t) => {
          const e = this.globalContext.document.cookie
            .split("; ")
            .reduce((e, n) => {
              const a = n.split("=");
              return a[0] === t ? decodeURIComponent(a.slice(1).join("=")) : e;
            }, "");
          return e.length > 0 ? e : null;
        }),
          (this.removeItem = (t, e = "/") => {
            this.setItem(t, "", 0, e);
          }),
          (this.setItem = (t, e, n, a = "/") => {
            const o = new Date(n);
            if (!this.isValidDate(o))
              throw new Error("Invalid expiration date");
            this.globalContext.document.cookie = `${t}=${e}; expires=${o.toUTCString()}; path=${a};`;
          }),
          (this.globalContext = t);
      }
      isValidDate(t) {
        return t instanceof Date && !isNaN(t);
      }
    }
    const u = (t, e = window) => {
        let n,
          a = e;
        do {
          try {
            const e = a?.location?.hostname;
            if (e && t(e)) return !0;
          } catch (t) {
            if (
              !(
                (t instanceof DOMException && "SecurityError" === t.name) ||
                (t instanceof Error && t.message.includes("cross-origin frame"))
              )
            )
              throw t;
            if (Math.random() < 0.001) throw t;
          }
          if (a === e.top) break;
          (n = a), (a = a.parent);
        } while (n !== a && n !== e.top);
        return !1;
      },
      p = ["scope/objectName", t, e],
      m = ":";
    function f(t) {
      return null === t || "object" != typeof t
        ? t
        : t instanceof Date
        ? new Date(t.getTime())
        : t instanceof Array
        ? t.reduce((t, e) => (t.push(f(e)), t), [])
        : t instanceof Set
        ? Array.from(t.values()).reduce((t, e) => (t.add(f(e)), t), new Set())
        : t instanceof Map
        ? Array.from(t.entries()).reduce(
            (t, e) => (t.set(e[0], f(e[1])), t),
            new Map()
          )
        : t instanceof Object
        ? Object.keys(t).reduce((e, n) => ((e[n] = f(t[n])), e), {})
        : t;
    }
    class h {
      constructor(t, e) {
        const n = e.rootName;
        (this.globalContext = e.globalContext), (this.rootName = n);
        const a = this.globalContext[n].get(t);
        if (null == a)
          throw new Error(`Missing "${t}" account in userspace object`);
        (this.id = t),
          (this.store = a.store),
          (this.queue = a.queue),
          this.store.has("listeners") || this.store.set("listeners", new Map());
      }
      getResolvedHostname() {
        let t = "";
        return u((e) => ((t = e), !0), this.globalContext), t;
      }
      async record(t, e) {
        return await new Promise((n, a) => {
          this.queue.push(
            new CustomEvent(t, {
              detail: { resolve: n, reject: a, source: i.internal, ...e },
            })
          );
        });
      }
      async recordListener(t, e) {
        return await new Promise((n, a) => {
          this.queue.push(
            new CustomEvent(t.name, {
              detail: { resolve: n, reject: a, source: i.internal, ...e },
            })
          );
        });
      }
      recordListenerNonBlocking(t, e) {
        this.recordListener(t, e).catch((t) => {});
      }
      read(t, e) {
        const n = this.store.get(t);
        if (void 0 !== n) return n;
        if (void 0 !== e?.persist && e.persist) {
          const n = this.readLocalStorage(t, {
            usePrefix: !0,
            throwOnDisallowed: e.throwOnDisallowed,
          });
          if (void 0 !== n) return n;
        }
        const a = e?.default?.generators?.get(t);
        return void 0 !== a ? a(...(e?.default?.args ?? [])) : void 0;
      }
      write(t, e, n) {
        this.store.set(t, e),
          void 0 !== n?.persist &&
            n.persist &&
            this.writeLocalStorage(t, e, {
              usePrefix: !0,
              throwOnDisallowed: n.throwOnDisallowed,
            });
      }
      use(t, e) {
        let n;
        const a = this.store.get(t.key);
        if (void 0 !== a) n = a;
        else if (void 0 !== e?.persist && e.persist) {
          const a = this.readLocalStorage(t.key, {
            usePrefix: !0,
            throwOnDisallowed: e.throwOnDisallowed,
          });
          null != a && (n = a);
        }
        const o = n ?? t.default;
        if ("function" == typeof o || !1 === e?.structuredClone) return o;
        try {
          return structuredClone(o);
        } catch (t) {
          try {
            return f(o);
          } catch (t) {
            return (
              yt.logCoreError({
                id: "Core.library.Account.use",
                account: null,
                error: t,
              }),
              o
            );
          }
        }
      }
      useParent(t, e) {
        try {
          const n = this.globalContext.parent,
            a = n[this.rootName];
          if (!a || "function" != typeof a.get) return t.default;
          const o = a.get(e?.accountId ?? this.id);
          if (!o || !o.store) return t.default;
          let i;
          const s = o.store.get(t.key);
          if (void 0 !== s) i = s;
          else if (e?.persist) {
            const a = e?.accountId ?? this.id,
              o = `aps${m}${a}${m}${t.key}`;
            try {
              const t = n.localStorage.getItem(o);
              null != t && (i = t);
            } catch {}
          }
          const r = i ?? t.default;
          if ("function" == typeof r || !1 === e?.structuredClone) return r;
          try {
            return structuredClone(r);
          } catch {
            try {
              return f(r);
            } catch {
              return r;
            }
          }
        } catch {
          return t.default;
        }
      }
      update(t, e, n) {
        let a = e(
          this.use(t, { ...n, throwOnDisallowed: n?.throwOnDisallowed })
        );
        if (
          (void 0 !== t.postProcessor && (a = t.postProcessor(a)),
          this.store.set(t.key, a),
          void 0 !== n?.persist && n.persist)
        ) {
          if ("string" != typeof a)
            throw new Error(
              `${JSON.stringify(
                a
              )} must be a string to be writtable to browser storage`
            );
          this.writeLocalStorage(t.key, a, {
            usePrefix: !0,
            throwOnDisallowed: n.throwOnDisallowed,
          });
        }
      }
      delete(t, e) {
        this.store.delete(t),
          void 0 !== e?.persist &&
            e.persist &&
            this.deleteLocalStorage(t, {
              usePrefix: !0,
              throwOnDisallowed: e.throwOnDisallowed,
            });
      }
      remove(t, e) {
        this.store.delete(t.key),
          void 0 !== e?.persist &&
            e.persist &&
            this.deleteLocalStorage(t.key, {
              usePrefix: !0,
              throwOnDisallowed: e.throwOnDisallowed,
            });
      }
      executeFuncWithConsent(t, e) {
        if (!this.isAllowedToAccessInfoOnDevice())
          throw new Error(
            "Invalid consent. API requires consent before execution."
          );
        return e.apply(t);
      }
      recordErrorEvent(t) {
        yt.logError({ ...t, account: this });
      }
      recordStatusChangeEvent(t) {
        yt.logFeature({
          id: t.id,
          account: this,
          feature: t.status,
          analyticsSampleRateAdjustFactor: t.analyticsSampleRateAdjustFactor,
          libraryVersion: t.libraryVersion,
          props: { ...t.props },
        });
      }
      recordGenericEvent(t) {
        yt.logFeature({
          id: t.id,
          account: this,
          feature: t.id,
          analyticsSampleRateAdjustFactor: t.analyticsSampleRateAdjustFactor,
          libraryVersion: t.libraryVersion,
          props: { ...t.props },
        });
      }
      isAllowedToAccessInfoOnDevice() {
        return this.updateUserConsent(), this.use(d);
      }
      isAPStagAllowedToAccessInfoOnDevice() {
        return !0 === this.globalContext.apstag._atsaaiod();
      }
      updateUserConsent() {
        try {
          const t = this.isAPStagAllowedToAccessInfoOnDevice();
          this.update(d, () => t);
        } catch (t) {}
      }
      getPersistedItemName(t) {
        return `aps${m}${this.id}${m}${t}`;
      }
      isBrowserStorageAllowed(t) {
        let e = !1;
        try {
          e = this.isAllowedToAccessInfoOnDevice();
        } catch {}
        return e || p.includes(t);
      }
      setCookieStorage(t, e, n, a) {
        const o = a?.throwOnDisallowed ?? !0;
        if (!this.isBrowserStorageAllowed(t)) {
          if (o)
            throw new Error(`${t} is not allowed to be set on cookie storage`);
          return;
        }
        const i = a?.usePrefix ? this.getPersistedItemName(t) : t;
        return new l(this.globalContext).setItem(i, e, n, a?.path ?? "/");
      }
      readCookieStorage(t, e) {
        const n = e?.throwOnDisallowed ?? !0;
        if (!this.isBrowserStorageAllowed(t)) {
          if (n)
            throw new Error(
              `${t} is not allowed to be read from cookie storage`
            );
          return;
        }
        const a = e?.usePrefix ? this.getPersistedItemName(t) : t;
        return new l(this.globalContext).getItem(a);
      }
      readLocalStorage(t, e) {
        const n = e?.throwOnDisallowed ?? !0;
        if (!this.isBrowserStorageAllowed(t)) {
          if (n)
            throw new Error(
              `${t} is not allowed to be read from browser storage`
            );
          return;
        }
        const a = e?.usePrefix ? this.getPersistedItemName(t) : t;
        return this.globalContext.localStorage.getItem(a) ?? void 0;
      }
      writeLocalStorage(t, e, n) {
        const a = n?.throwOnDisallowed ?? !0;
        if (!this.isBrowserStorageAllowed(t)) {
          if (a)
            throw new Error(
              `${t} is not allowed to be written to browser storage`
            );
          return;
        }
        if ("string" != typeof e)
          throw new Error(
            `${JSON.stringify(
              e
            )} must be a string to be writtable to browser storage`
          );
        const o = n?.usePrefix ? this.getPersistedItemName(t) : t;
        this.globalContext.localStorage.setItem(o, e);
      }
      deleteLocalStorage(t, e) {
        const n = e?.throwOnDisallowed ?? !0;
        if (!this.isBrowserStorageAllowed(t)) {
          if (n)
            throw new Error(
              `${t} is not allowed to be touched/deleted in browser storage`
            );
          return;
        }
        const a = e?.usePrefix ? this.getPersistedItemName(t) : t;
        this.globalContext.localStorage.removeItem(a);
      }
      readSessionStorage(t, e) {
        const n = e?.throwOnDisallowed ?? !0;
        if (!this.isBrowserStorageAllowed(t)) {
          if (n)
            throw new Error(
              `${t} is not allowed to be read from browser storage`
            );
          return;
        }
        const a = e?.usePrefix ? this.getPersistedItemName(t) : t;
        if (a in this.globalContext.sessionStorage)
          return this.globalContext.sessionStorage.getItem(a);
      }
      writeSessionStorage(t, e, n) {
        const a = n?.throwOnDisallowed ?? !0;
        if (!this.isBrowserStorageAllowed(t)) {
          if (a)
            throw new Error(
              `${t} is not allowed to be written to browser storage`
            );
          return;
        }
        if ("string" != typeof e)
          throw new Error(
            `${JSON.stringify(
              e
            )} must be a string to be writable to browser storage`
          );
        const o = n?.usePrefix ? this.getPersistedItemName(t) : t;
        this.globalContext.sessionStorage.setItem(o, e);
      }
      deleteSessionStorage(t, e) {
        const n = e?.throwOnDisallowed ?? !0;
        if (!this.isBrowserStorageAllowed(t)) {
          if (n)
            throw new Error(
              `${t} is not allowed to be touched/deleted in browser storage`
            );
          return;
        }
        const a = e?.usePrefix ? this.getPersistedItemName(t) : t;
        this.globalContext.sessionStorage.removeItem(a);
      }
    }
    const v = "_system";
    class g extends h {
      constructor(t, e) {
        super(v, { globalContext: t, rootName: e });
      }
    }
    const y = "listeners",
      w = "_internal/history",
      b = "_internal/pageLoadID",
      x = "_internal/externalEventCount";
    class E {
      constructor(t, e, n) {
        (this.globalContext = t), (this.rootName = e), (this.dispatcher = n);
      }
      getAccounts() {
        return this.globalContext[this.rootName];
      }
      createUserspaceRoot() {
        null == this.getAccounts() &&
          (this.globalContext[this.rootName] = new Map());
      }
      createSystemAccount() {
        !1 === this.getAccounts().has(v) &&
          (this.getAccounts().set(v, { queue: [], store: new Map() }),
          new g(this.globalContext, this.rootName).store.set(b, Math.random()));
      }
      observeRootSet() {
        const t = this;
        this.getAccounts().set = function (e, n) {
          Map.prototype.set.apply(this, [e, n]), t.equip();
        };
      }
      observeAccountQueuesPush() {
        const t = this;
        this.getAccounts().forEach((e) => {
          e.queue.push = function (...e) {
            Array.prototype.push.apply(this, e),
              t.dispatcher.t({ reason: { method: o.push, events: e } });
          };
        });
      }
      overwriteAccountStoresGet() {
        this.getAccounts().forEach((t) => {
          t.store.get = function (...t) {
            return Map.prototype.get.apply(this, t);
          };
        });
      }
      defineConvenienceFunctions() {
        const t = (t, e, n) => {
            const a = this.getAccounts().get(t);
            void 0 !== a &&
              a.queue.push(new CustomEvent(e, { detail: n ?? {} }));
          },
          e = this.globalContext[this.rootName];
        (e.triggerFor = t),
          (e.trigger = (e, n) => {
            t(v, e, n);
          }),
          void 0 === e._private && (e._private = {}),
          (e._private.CookieStorage = l);
      }
      equip() {
        try {
          this.createUserspaceRoot(),
            this.createSystemAccount(),
            this.observeRootSet(),
            this.observeAccountQueuesPush(),
            this.overwriteAccountStoresGet(),
            this.defineConvenienceFunctions();
        } catch (t) {
          throw (
            (new g(this.globalContext, this.rootName).recordErrorEvent({
              id: "Core.library.Equiper.equip",
              error: t,
            }),
            t)
          );
        }
      }
    }
    var S;
    !(function (t) {
      (t.info = "info"), (t.warn = "warn"), (t.error = "error");
    })(S || (S = {}));
    class _ {
      static Instance() {
        return this.o;
      }
      static SessionId() {
        return this.i;
      }
      info(...t) {
        const e = new Date(Date.now()),
          n = S.info;
        return (
          console.log(this.getPrefix(e, n), ...t), { timestamp: e, logLevel: n }
        );
      }
      warn(...t) {
        const e = new Date(Date.now()),
          n = S.warn;
        return (
          console.warn(this.getPrefix(e, n), ...t),
          { timestamp: e, logLevel: n }
        );
      }
      error(...t) {
        const e = new Date(Date.now()),
          n = S.error;
        return (
          console.error(this.getPrefix(e, n), ...t),
          { timestamp: e, logLevel: n }
        );
      }
      getPrefix(t, e) {
        return `${t.toISOString()} | ${_.SessionId()} | [${e.toUpperCase()}]`;
      }
    }
    (_.o = new _()), (_.i = `${Date.now()}`);
    const R = _.Instance(),
      I = "26.1102.1713",
      A = (t) => void 0 === t || !Array.isArray(t) || u((e) => t.includes(e));
    function k(t) {
      return !(t >= 1 || Number.isNaN(t)) && (t <= 0 || Math.random() >= t);
    }
    function j() {
      try {
        return (
          !!new URLSearchParams(
            window.top?.location.search ?? window.location.search
          ).has("apscoredebug") ||
          (window._aps?.get("_system").store.get("_internal/coreDebugMode") ??
            !1)
        );
      } catch {
        return !1;
      }
    }
    const $ = { key: "_internal/eventSources", default: new Map() },
      C = { key: "_internal/processedEventSources", default: new Set() },
      O = { key: "_internal/commonAnalytics", default: {} },
      P = { key: "analytics/sampleRateFactors", default: void 0 },
      D = [c.completed, c.error, c.cancelled, c.analytics];
    class T {
      constructor(t, e) {
        (this.globalContext = t), (this.rootName = e);
      }
      l(t) {
        return t.store.get("_config/events/deactivations") ?? new Set();
      }
      p(t, e) {
        return (
          !0 === this.l(t).has(e.type) ||
          ((t, e) => {
            try {
              const e = t.detail?.restrictions?.allow?.hostnames;
              if (void 0 !== e && !A(e)) return !0;
              const n = t.detail?.restrictions?.block?.hostnames;
              if (void 0 !== n && A(n)) return !0;
            } catch (t) {
              return (
                e.recordErrorEvent({ id: "hostnames", error: new Error(t) }), !1
              );
            }
            return !1;
          })(e, t) ||
          ((t) => {
            const e = t?.detail?.restrictions?.allow?.libraryVersions,
              n = t?.detail?.restrictions?.block?.libraryVersions;
            return (
              !(!Array.isArray(n) || !n.includes(I)) ||
              !(!Array.isArray(e) || e.includes(I))
            );
          })(e) ||
          ((t, e) => {
            const n = t?.detail?.restrictions?.allow?.accounts,
              a = t?.detail?.restrictions?.block?.accounts;
            return (
              !(!Array.isArray(a) || !a.includes(e.id)) ||
              !(!Array.isArray(n) || n.includes(e.id))
            );
          })(e, t) ||
          ((t, e) => {
            const n = ((t) => {
              if (!t) return null;
              const e = Number(t);
              return !Number.isNaN(e) && Number.isInteger(e) && e >= 0
                ? a.ManagedWeb
                : a.SelfServeWeb;
            })(e.id);
            if (null === n) return !1;
            const o = t?.detail?.restrictions?.allow?.accountTypes,
              i = t?.detail?.restrictions?.block?.accountTypes;
            return (
              !(!Array.isArray(i) || !i.includes(n)) ||
              !(!Array.isArray(o) || o.includes(n))
            );
          })(e, t) ||
          ((t) => {
            const e = t?.detail?.restrictions?.allow?.rate ?? 1;
            return !(!k(t?.detail?.restrictions?.block?.rate ?? 1) && !k(e));
          })(e)
        );
      }
      m() {
        return (
          new g(this.globalContext, this.rootName).store.get(y) ?? new Map()
        );
      }
      v(t) {
        return t.store.get("listeners") ?? new Map();
      }
      S(t, e) {
        return this.m().get(e.type) || this.v(t).get(e.type);
      }
      _(t) {
        const e = this.R(x);
        return (
          (void 0 === t.externalEventCount || t.externalEventCount < e) &&
          ((t.externalEventCount = e), !0)
        );
      }
      I(t) {
        if (void 0 === t.status) return !0;
        if (t.status === c.started) return !1;
        if (D.includes(t.status)) return !1;
        if (t.status === c.waiting) return !!this._(t);
        if (t.status === c.unknown) return !1;
        if (t.status === c.deactivated) return !1;
        throw new Error(`Event status not explicitely handled: ${t.status}`);
      }
      A(t, e) {
        void 0 !== e.detail?.timeout &&
          t.push(
            new Promise((t, n) => {
              setTimeout(
                () => n(new Error(`Event "${e.type}" timed out`)),
                e.detail.timeout
              );
            })
          );
      }
      j(t, e) {
        const n = new g(this.globalContext, this.rootName),
          a = n.read(t) ?? 0;
        n.write(t, a + e);
      }
      $(t) {
        new g(this.globalContext, this.rootName).write(t, 0);
      }
      R(t) {
        return new g(this.globalContext, this.rootName).read(t) ?? 0;
      }
      C(t, e, n, a, i) {
        if (!(e in c))
          throw new Error(
            `Listener returned invalid status: ${t.type} returned ${e}`
          );
        if (
          (this.O(t, e, a, i), e !== c.waiting && void 0 !== t.detail?.resolve)
        )
          try {
            t.detail.resolve(n);
          } catch (t) {
            R.error(t);
          }
        e !== c.waiting && this.P(t, a),
          this.t({ reason: { method: o.listenerSuccess, events: [t] } });
      }
      P(t, e) {
        const n = this.S(e, t);
        !0 === n?.shouldFlushAnalytics && yt.flush();
      }
      D(t, e, n) {
        (void 0 !== e && "string" != typeof e) || (e = new Error(e)),
          this.O(t, c.error, n),
          this.T(t, e),
          (e.context = t.type),
          n.recordErrorEvent({
            id: t.type,
            analyticsSampleRateAdjustFactor: this.N(t),
            error: e,
          }),
          this.P(t, n);
      }
      L(t, e, n, a) {
        const o = this.S(n, e);
        if (void 0 === o)
          throw new Error(`No listener found for event: ${e.type}`);
        t.push(
          o({
            customEvent: e,
            account: n,
            systemAccount: a,
            detail: e.detail,
            context: n.globalContext,
          })
        );
      }
      M(t, e, n) {
        Promise.race(t)
          .then((t) => {
            let a, o, i;
            void 0 === t
              ? (a = s.completed)
              : "string" == typeof t
              ? (a = t)
              : "object" == typeof t &&
                ((a = t.status),
                (o = t.value),
                (i = t.analytics),
                !0 === e.detail?.surfaceAnalytics &&
                  (void 0 === o && (o = {}), (o.analytics = i))),
              this.C(e, a, o, n, i);
          })
          .catch((t) => {
            this.D(e, t, n);
          });
      }
      U(t, e, n) {
        const a = [];
        this.L(a, t, e, n), this.A(a, t), this.M(a, t, e);
      }
      q(t, e) {
        if (void 0 !== t.status) return;
        const n = t.detail?.error;
        if (void 0 !== n) {
          t.status = c.error;
          const a = this.V(n),
            o = {
              id: t.type,
              analyticsSampleRateAdjustFactor: this.N(t),
              error: a,
              props: {
                ...t.detail.analytics,
                eventDetailSource: t.detail.source,
              },
            };
          "string" == typeof t.detail.libraryVersion &&
            (o.libraryVersion = t.detail.libraryVersion),
            e.recordErrorEvent(o);
        }
      }
      V(t) {
        let e;
        if (t instanceof Error) e = t;
        else if ("string" == typeof t) e = new Error(t);
        else if ("object" == typeof t && null !== t) {
          let n = "Error object";
          if ("message" in t && "string" == typeof t.message) n = t.message;
          else if ("error" in t && "string" == typeof t.error) n = t.error;
          else
            try {
              (n = JSON.stringify(t)),
                n.length > 500 && (n = n.substring(0, 497) + "...");
            } catch {
              n = `Complex error object of type ${
                t.constructor?.name || "unknown"
              }`;
            }
          (e = new Error(n)), (e.originalError = t);
        } else e = new Error(`Error value: ${String(t)}`);
        return e;
      }
      F(t, e) {
        if (void 0 !== t.status) return;
        const n = t.detail?.analytics;
        if (void 0 !== n) {
          t.status = c.analytics;
          const a = {
            id: t.type,
            status: t.status,
            analyticsSampleRateAdjustFactor: this.N(t),
            props: { ...n },
          };
          "string" == typeof t.detail.libraryVersion &&
            (a.libraryVersion = t.detail.libraryVersion),
            e.recordStatusChangeEvent(a);
        }
      }
      B(t, e) {
        this.p(e, t) && this.O(t, c.deactivated, e);
      }
      J(t, e) {
        void 0 === t.status &&
          void 0 === this.S(e, t) &&
          this.O(t, c.unknown, e);
      }
      T(t, e) {
        if ((j() && R.error(e), void 0 !== t.detail?.reject))
          try {
            t.detail.reject(e);
          } catch (t) {
            R.error(t);
          }
      }
      H(t, e) {
        const n = new Error(`Invalid account ID: "${e.id}"`);
        this.D(t, n, e);
      }
      static G(t) {
        return (
          "string" == typeof t &&
          !["", "undefined", "true", "false"].includes(t.trim())
        );
      }
      K(t, e, n) {
        T.G(e.id)
          ? (this.q(t, e),
            this.F(t, e),
            this.J(t, e),
            this.B(t, e),
            this.I(t) &&
              (this.O(t, c.started, e),
              j() &&
                R.info(
                  `## Execute event: ${t.type} with initial status ${
                    t.status ?? "undefined"
                  }`
                ),
              this.U(t, e, n)))
          : this.H(t, e);
      }
      W(t) {
        const e = new g(this.globalContext, this.rootName).use($),
          n = t.use(C);
        e.forEach((e, a) => {
          if (n.has(a)) return;
          const o = e.map(([t, e]) => new CustomEvent(t, { detail: e }));
          t.queue.unshift(...o), t.update(C, (t) => t.add(a));
        });
      }
      Y(t, e, n) {
        this.W(t), t.queue.forEach((n) => this.K(n, t, e));
      }
      Z(t, e) {
        (t.status = e),
          (t.statusEvents = null != t.statusEvents ? t.statusEvents : []),
          t.statusEvents.push(new CustomEvent(e));
      }
      N(t) {
        if (t.detail?.analyticsSampleRateAdjustFactor)
          return t.detail.analyticsSampleRateAdjustFactor;
        const e = new g(this.globalContext, this.rootName).use(P);
        return e?.get(t.type);
      }
      X(t, e, n, a) {
        const o = new CustomEvent("now").timeStamp,
          i = t.statusEvents?.find((t) => t.type === c.started),
          s = null != i ? o - i.timeStamp : void 0;
        n.recordStatusChangeEvent({
          id: t.type,
          status: e,
          analyticsSampleRateAdjustFactor: this.N(t),
          props: {
            ...n.use(O),
            ...a,
            source: t.detail?.source,
            timers: { sinceCreated: o - t.timeStamp, sinceStarted: s },
          },
        });
      }
      O(t, e, n, a) {
        t.status !== e &&
          (j() &&
            R.info(
              `### Update ${t.type} from ${t.status ?? "undefined"} to ${e}`
            ),
          this.Z(t, e),
          this.X(t, e, n, a));
      }
      tt() {
        const t = new Map();
        return (
          this.globalContext[this.rootName].forEach((e, n) =>
            t.set(
              n,
              new h(n, {
                globalContext: this.globalContext,
                rootName: this.rootName,
              })
            )
          ),
          t
        );
      }
      et(t) {
        if (j()) return;
        const e = t.store.get(w) ?? [];
        if (e.length > 150) {
          const n = e.slice(-100);
          t.store.set(w, n);
        }
      }
      nt(t) {
        const e = t.store.get(w) ?? [];
        e.push(
          ...t.queue.filter((t) => void 0 !== t.status && D.includes(t.status))
        ),
          t.store.set(w, e);
      }
      ot(t) {
        t.queue.splice(
          0,
          t.queue.length,
          ...t.queue.filter((t) => void 0 === t.status || !D.includes(t.status))
        );
      }
      it() {
        this.tt().forEach((t) => {
          this.nt(t), this.et(t), this.ot(t);
        });
      }
      st(t) {
        return t?.filter(
          (t) =>
            t.detail?.source !== i.internal &&
            t.detail?.source !== i.apstag &&
            t.status !== c.waiting
        );
      }
      rt(t) {
        const e = this.st(t);
        return e?.length ?? 0;
      }
      ct(t) {
        const e = this.rt(t);
        this.j(x, e);
      }
      lt() {
        const t = "_internal/recentDispatches";
        this.j(t, 1);
        const e = this.R(t);
        if (e > 1e4) throw new Error("Too many dispatches. Aborting");
        e % 100 == 0 &&
          new g(this.globalContext, this.rootName).recordGenericEvent({
            id: "C.l.D.thr",
            props: { recentDispatchesCount: e },
          }),
          setTimeout(() => {
            this.$(t);
          }, 100);
      }
      t({ reason: t }) {
        try {
          this.lt(),
            j() &&
              R.info(
                `# Dispatch from method "${t.method}" on event "${
                  t.events?.[0].type ?? "undefined"
                }" with source "${
                  t.events?.[0].detail?.source ?? "undefined"
                }"\n_________________________________________`
              ),
            this.ct(t.events);
          const e = new g(this.globalContext, this.rootName);
          this.tt().forEach((n) => this.Y(n, e, t)), this.it();
        } catch (t) {
          throw (
            (new g(this.globalContext, this.rootName).recordErrorEvent({
              id: "C.l.D.dis",
              error: t,
            }),
            t)
          );
        }
      }
    }
    class N {
      constructor(t, e) {
        (this.globalContext = t), (this.rootName = e);
      }
      subscribe(t) {
        try {
          const e = new g(this.globalContext, this.rootName),
            n = null != e.store.get(y) ? e.store.get(y) : new Map();
          e.store.set(y, new Map([...n, ...t]));
        } catch (t) {
          throw (
            (new g(this.globalContext, this.rootName).recordErrorEvent({
              id: "Core.library.Subscriber.subscribe",
              error: t,
            }),
            t)
          );
        }
      }
    }
    class L {
      constructor(t, e) {
        (this.globalContext = t), (this.rootName = e);
      }
      populate() {
        try {
          const t = new g(this.globalContext, this.rootName);
          let e = !1;
          try {
            e = JSON.parse(t.read(n));
          } catch {}
          if (e) return;
          t.write(n, JSON.stringify(!0)), this.populateFromPrependStore();
        } catch (t) {
          new g(this.globalContext, this.rootName).recordErrorEvent({
            id: "Core.library.Populator.populate",
            error: t,
          });
        }
      }
      populateFromPrependStore() {
        this.globalContext[this.rootName].forEach((t, n) => {
          const a = new h(n, {
              globalContext: this.globalContext,
              rootName: this.rootName,
            }),
            o = a.read(e, { persist: !0 }) ?? "[]";
          a.write(e, JSON.stringify([]));
          try {
            const t = JSON.parse(o);
            if (0 === t.length) return;
            a.queue.push(...t.map(M));
          } catch (t) {
            console.error("Error processing prepended events", t);
          }
        });
      }
    }
    const M = (t) =>
        new CustomEvent(t.eventName, { detail: { ...(t.eventDetail ?? {}) } }),
      U = window;
    class q {
      constructor(t, e, n) {
        (this.ID = t),
          (this.rootName = n),
          (this.globalContext = e),
          this.clear();
      }
      clear() {
        new g(this.globalContext, this.rootName).update(
          $,
          (t) => (t.delete(this.ID), t)
        );
      }
      recordListener(t, e) {
        new g(this.globalContext, this.rootName).update($, (n) => {
          const a = n.get(this.ID);
          return (
            void 0 !== a ? a.push([t.name, e]) : n.set(this.ID, [[t.name, e]]),
            n
          );
        });
      }
    }
    class V {
      constructor(t = U, e = "_aps") {
        (this.dispatcher = new T(t, e)),
          (this.equiper = new E(t, e, this.dispatcher)),
          (this.subscriber = new N(t, e)),
          (this.populator = new L(t, e)),
          (this.globalContext = t),
          (this.rootName = e);
      }
      createAccount(t) {
        if (void 0 === t) throw new Error("accountID must be provided");
        this.globalContext[this.rootName] =
          this.globalContext[this.rootName] ?? new Map();
        const e = this.globalContext[this.rootName],
          n = { store: new Map(), queue: [] };
        return (
          !1 === e.has(t) && e.set(t, n),
          new h(t, {
            globalContext: this.globalContext,
            rootName: this.rootName,
          })
        );
      }
      subscribe(t) {
        this.subscriber.subscribe(t);
      }
      equip() {
        this.equiper.equip();
      }
      dispatch({ reason: t }) {
        this.dispatcher.t({ reason: t });
      }
      populate() {
        this.populator.populate();
      }
      load({ listeners: t }) {
        this.equip(),
          this.subscribe(t),
          this.dispatch({ reason: { method: o.direct } }),
          this.populate();
      }
      registerEventSource(t) {
        return this.equip(), new q(t, this.globalContext, this.rootName);
      }
    }
    var F;
    !(function (t) {
      (t.postulate = "postulate"), (t.genericError = "error");
    })(F || (F = {}));
    const B = "26.1102.1713";
    function z(t, e, n) {
      const a = new URL(
        "https://prod.tahoe-analytics.publishers.advertising.a2z.com/logevent/putRecord"
      );
      let o = t;
      try {
        "web-client-scenarios.aps.amazon.dev" === n?.hostname
          ? (o = t + "-debug-only")
          : window.Cypress && (o = t + "-integration-test");
      } catch (t) {}
      const i = {
        ...n,
        eventSource: "aps_web_client_library",
        eventCategory: o,
        eventName: e,
        libraryVersion: B,
      };
      Object.entries(i).forEach(([t, e]) => {
        a.searchParams.append(t, e);
      }),
        fetch(a.toString(), {
          method: "GET",
          keepalive: !0,
          headers: {
            "x-api-key":
              "79db72eb0b5c7255afa54a253df24fb4a5ac916bf40b51c730df8850aa5665ca",
          },
        }).catch(() => {});
    }
    const J = {
        ut: setInterval,
        ft: function () {
          return window[H]?.[G];
        },
        ht: function (t = window) {
          try {
            return t.top?.location || { href: "unknown", hostname: "unknown" };
          } catch (t) {
            return { href: "unknown", hostname: "unknown" };
          }
        },
        vt: z,
        gt: function (t, e) {
          return {
            eventTime: K(() => `${Date.now()}`),
            accountID: K(() => t?.accountID),
            libraryVersion: B,
            url: K(() => e().href),
            hostname: K(() => e().hostname),
            message: K(() => t?.message),
            condition: K(() => t?.condition),
          };
        },
        yt: function (t, e) {
          try {
            (e ?? z)(F.genericError, "telemetry_core_failure", {
              errorName: t?.name ?? "unknown",
              errorMessage: t?.message ?? "unknown",
            });
          } catch {
            (e ?? z)(F.genericError, "telemetry_core_failure");
          }
        },
      },
      H = "_aps_telemetry",
      G = "alarms";
    function K(t) {
      try {
        return t() ?? "undefined";
      } catch (t) {
        return (function (t) {
          try {
            return t instanceof Error
              ? `Access Error: ${t.name} - ${t.message}`
              : "Access Error: Unknown error type";
          } catch {
            return "Access Error: Unable to provide more information";
          }
        })(t);
      }
    }
    function W(t, e, n) {
      const a = () => !1;
      throw (
        (n ||
          (function (t, e, n) {
            const a = window;
            void 0 === a[H] && (a[H] = {}),
              void 0 === a[H][G] && (a[H][G] = []);
            const o = a[H][G],
              i = e.toString();
            o.push({ hash: t, context: { ...n, condition: i } });
          })(t, a, e),
        new Error(e?.message ?? `Postulate violation: ${t}, ${a}`))
      );
    }
    const Q = new WeakMap();
    function Y({ debugKey: t, obj: e, validators: n, root: a, separator: o }) {
      (a = a ?? "root"), (o = o ?? ".");
      const i = {
          nonModifiable: {
            set(t, e) {
              throw new Error(
                `Cannot set property "${String(
                  e
                )}": "${a}" is not marked as modifiable.`
              );
            },
            deleteProperty(t, e) {
              throw new Error(
                `Cannot delete property "${String(
                  e
                )}": "${a}" is not marked as modifiable.`
              );
            },
            defineProperty(t, e) {
              throw new Error(
                `Cannot define property "${String(
                  e
                )}": "${a}" is not marked as modifiable.`
              );
            },
            setPrototypeOf(t) {
              throw new Error(
                `Cannot set prototype: "${a}" is not marked as modifiable.`
              );
            },
          },
          modifiable: {
            set(t, e, n, a) {
              try {
                return Reflect.set(t, e, n, a);
              } catch (a) {
                if ("TypeError" === a.name) return (t[e] = n), !0;
                throw a;
              }
            },
          },
          validating: {
            get(e, i, s) {
              if ("raw" === i) return Q.get(s) || e;
              if ("symbol" == typeof i) return Reflect.get(e, i, s);
              if (
                ((t) => {
                  if (["asymmetricMatch", "nodeType"].includes(t)) return !0;
                })(i)
              )
                return Reflect.get(e, i, s);
              let r;
              try {
                r = Reflect.get(e, i, s);
              } catch (t) {
                if ("TypeError" !== t.name) throw t;
                r = e[i];
              }
              return Y({
                obj: r,
                validators: n,
                root: `${a}${o}${String(i)}`,
                debugKey: t,
              });
            },
            ownKeys: (t) =>
              Reflect.ownKeys(t).filter((t) => {
                const e = `${a}${o}${String(t)}`;
                return void 0 !== n[e];
              }),
          },
          function: {
            apply: (e, o, i) => {
              const s = Q.has(o) ? Q.get(o) : o;
              return Y({
                obj: e.apply(s, i),
                validators: n,
                root: `${a}()`,
                debugKey: t,
              });
            },
            get: (t, e, n) =>
              "raw" === e ? Q.get(n) || t : Reflect.get(t, e, n),
          },
        },
        s = (function (o) {
          if (!1 === o.verifiable) return e;
          if (e instanceof Set)
            return (
              e.forEach((e) => {
                Y({ obj: e, validators: n, root: `${a}.value`, debugKey: t });
              }),
              e
            );
          if (e instanceof Map)
            return (
              e.forEach((e, o) => {
                Y({ obj: o, validators: n, root: `${a}.key`, debugKey: t }),
                  Y({ obj: e, validators: n, root: `${a}.value`, debugKey: t });
              }),
              e
            );
          if (Array.isArray(e))
            return e.map((e) =>
              Y({ obj: e, validators: n, root: `${a}[]`, debugKey: t })
            );
          if ("function" == typeof e) {
            const t = new Proxy(e, i.function);
            return Q.set(t, e), t;
          }
          const s = {
            ...i.validating,
            ...(o?.modifiable ? i.modifiable : i.nonModifiable),
          };
          try {
            const t = new Proxy(e, s);
            return Q.set(t, e), t;
          } catch (t) {
            if ("TypeError" === t.name) return e;
            throw t;
          }
        })(
          (function () {
            const o = (t ?? "").length > 0 ? `Location: ${t} - ` : "",
              i = n[a ?? ""];
            if (void 0 === i) {
              const t =
                ".constructor" === (a ?? "").slice(-12) ||
                ".toString" === (a ?? "").slice(-9);
              W(
                "ea3914",
                {
                  message: `${o}Unauthorized usage for "${a}": No validator has been defined`,
                },
                t
              );
            }
            if (null === i) return { verifiable: !1 };
            let s;
            try {
              s = i(e, a);
            } catch (t) {
              let n = "Error, could not convert to string";
              try {
                n =
                  "string" == typeof e
                    ? '"' + e + '"'
                    : null != e && "function" == typeof e.toString
                    ? e.toString()
                    : Object.prototype.toString.call(e);
              } catch (t) {}
              throw new Error(
                `${o}Validation failed for "${a}": ${t.message} - Received: ${n}`
              );
            }
            return s ?? {};
          })()
        );
      return s;
    }
    const Z = (t) => {
        if ("number" != typeof t) throw new Error("must be a number");
      },
      X = (t) => {
        if ("string" != typeof t) throw new Error("must be a string");
      },
      tt = (t) => {
        if ("boolean" != typeof t) throw new Error("must be a boolean");
      },
      et = (t) => {
        if ("object" != typeof t || null === t || Array.isArray(t))
          throw new Error("must be a standard object");
      };
    function nt(t) {
      if (void 0 !== t?.min && (t.min < 0 || t.min > 1))
        throw new Error("min option must be between 0 and 1");
      if (void 0 !== t?.max && (t.max < 0 || t.max > 1))
        throw new Error("max option must be between 0 and 1");
      const e = t?.min ?? 0,
        n = t?.max ?? 1;
      if (e > n)
        throw new Error("min option cannot be greater than max option");
      return (t) => {
        if ("number" != typeof t) throw new Error("must be a number");
        if (t < e || t > n)
          throw new Error(
            `must be a percentage between ${e} and ${n} (where 1 = 100%)`
          );
      };
    }
    const at = (t) => (e) => {
        let n = !1;
        for (const a of t)
          try {
            a(e), (n = !0);
          } catch (t) {}
        if (!n) throw new Error("None of the validators passed");
      },
      ot = (t) => {
        if (!Array.isArray(t)) throw new Error("must be an array");
      };
    function it(t) {
      return (e) => {
        if (!1 === t.includes(e))
          throw new Error(
            `must be one of the following values: ${JSON.stringify(t)}`
          );
      };
    }
    function st(t) {
      return (e, n) => ({ modifiable: !0, ...t(e, n) });
    }
    function rt(t) {
      return (e, n) => {
        if (t === dt) throw new Error("isAny cannot be used within isOptional");
        if (null != e) return t(e, n);
      };
    }
    const ct = (t) => {
        if ("function" != typeof t) throw new Error("must be a function");
      },
      dt = () => {},
      lt = () => ({ verifiable: !1 }),
      ut = (t) => {
        if (void 0 !== t) throw new Error("must be undefined");
      };
    class pt {
      constructor(t) {
        const {
            scope: e,
            object: n,
            action: a,
            validators: o,
            handler: i,
            shouldFlushAnalytics: s,
          } = t,
          r = `${e}/${n}/${a}`;
        this.throwIfInvalid(e, n, a),
          (this.name = `${e}/${n}/${a}`),
          (this.handler = this.wrapHandler({
            handler: i,
            validators: o,
            debugKey: r,
          })),
          !0 === s && (this.handler.shouldFlushAnalytics = !0);
      }
      wrapHandler({ debugKey: t, handler: e, validators: n }) {
        return async (a) => {
          let o = a;
          return (
            (o = {
              ...o,
              detail: Y({
                obj: o.customEvent.detail,
                validators: this.getDetailValidators(n),
                root: "detail",
                debugKey: t,
              }),
              context: Y({
                obj: o.account.globalContext,
                validators: this.getContextValidators(n),
                root: "context",
                debugKey: t,
              }),
            }),
            await e(o)
          );
        };
      }
      getDetailValidators(t) {
        return t?.detail && 0 !== Object.keys(t.detail).length
          ? t.detail
          : { detail: dt };
      }
      getContextValidators(t) {
        return t?.context && 0 !== Object.keys(t.context).length
          ? t.context
          : { context: dt };
      }
      throwIfInvalid(t, e, n) {
        if (
          [
            "consent/gppapi/attemptSync",
            "consent/gppapi/didChange",
            "consent/gppapi/syncData",
            "consent/tcfapi/attemptSync",
            "consent/tcfapi/didChange",
            "log/analytics/setInterval",
            "analytics/sampling/set",
            "googletag/pubads/setConfig",
            "googletag/pubads/getConfig",
            "googletag/pubads/clearTargeting",
            "googletag/slot/setConfig",
            "googletag/slot/getConfig",
            "googletag/slot/clearTargeting",
          ].includes(`${t}/${e}/${n}`)
        )
          return;
        const a = /^[a-z0-9][a-zA-Z0-9]*$/;
        if (!a.test(t) || !a.test(e) || !a.test(n))
          throw new Error(
            `scope, object, and action must be alphanumeric and start with a lowercase. Received: ${t}, ${e}, ${n}`
          );
        if (/[A-Z]/.test(n) && !/^(will|did)/i.test(n))
          throw new Error(
            `action must be a single verb (or a single verb prefixed by 'will' or 'did'). Received: ${n}`
          );
      }
    }
    function mt(t) {
      if (new Set(t.map((t) => t.name)).size !== t.length)
        throw new Error("Duplicates found");
      return new Map(t.map((t) => [t.name, t.handler]));
    }
    class ft {
      constructor() {
        (this.wt = 300),
          (this.bt =
            "https://prod.tahoe-analytics.publishers.advertising.a2z.com/logevent/putRecords"),
          (this.xt =
            "79db72eb0b5c7255afa54a253df24fb4a5ac916bf40b51c730df8850aa5665ca"),
          (this.Et = 5e3),
          (this.St = []),
          this.clearAndUpdateEventProcessingInterval(5e3);
      }
      logEvent(t) {
        try {
          const n = `${Date.now()}`,
            a =
              null == (e = t.eventSampleRate) || isNaN(e) || e < 0
                ? 0
                : e >= 0 && e <= 1
                ? e
                : 1,
            o = {
              Data: {
                eventSource: "aps_web_client_library",
                eventTime: n,
                eventCategory: t.eventCategory,
                eventName: t.eventName,
                eventSampleRate: a,
                eventProperties: {
                  ...t.eventProperties,
                  eventSampleRate: `${a}`,
                },
              },
              PartitionKey: n,
            };
          this.St.push(o);
        } catch (t) {
          W("4daf34", { message: t.message });
        }
        var e;
        this.St.length > this.Et && this.safelyProcessRecordQueue();
      }
      flush() {
        this.safelyProcessRecordQueue();
      }
      clearAndUpdateEventProcessingInterval(t) {
        "number" != typeof t ||
          t <= 0 ||
          (t !== this._t &&
            (clearInterval(this.Rt),
            (this.Rt = setInterval(() => this.safelyProcessRecordQueue(), t)),
            (this._t = t)));
      }
      safelyProcessRecordQueue() {
        if (void 0 === this.St || this.St.length <= 0) return;
        const t = this.St.filter(
          (t) => void 0 !== t && t.Data.eventSampleRate >= Math.random()
        );
        (this.St.length = 0),
          t.length <= 0 ||
            this.batchSendRecords(t).catch((t) => {
              this.logEvent({
                eventCategory: "error",
                eventName: "tahoe/putRecords/didFail",
                eventSampleRate: 1,
                eventProperties: { error: { message: t?.message } },
              });
            });
      }
      batchSendRecords(t) {
        const e = [];
        for (let n = 0; n < t.length; n += this.wt) {
          const a = this.sendRecords(t.slice(n, n + this.wt));
          e.push(a);
        }
        return Promise.all(e);
      }
      sendRecords(t) {
        return fetch(`${this.bt}?encoded=${j() ? "false" : "true"}`, {
          method: "POST",
          headers: { "Content-Type": "application/json", "x-api-key": this.xt },
          body: JSON.stringify({
            Records: j()
              ? t
              : ((t) =>
                  t.map((t) => ({
                    ...t,
                    Data: window.btoa(JSON.stringify(t.Data)),
                  })))(t),
          }),
        });
      }
    }
    const ht = { key: "_config/requestViewer/countryCode", default: "unknown" },
      vt = { key: "video/analytics", default: void 0 },
      gt = (() => {
        try {
          const t = window?.__aps_slice ?? window?.top?.__aps_slice;
          return "number" == typeof t && Number.isInteger(t) && t > 0
            ? t
            : void 0;
        } catch {
          return;
        }
      })(),
      yt = new (class {
        constructor() {
          (this.STACK_MAX_LENGTH = 500),
            (this.It = 0.001),
            (this.At = 1e-4),
            (this.kt = new ft());
        }
        getVideoPlayerMetadata(t) {
          const e = t.account?.use(vt, { structuredClone: !1 }),
            n = "object" == typeof t.props?.legacyPlayerEventProps;
          return e?.getMetadata && !n
            ? { legacyPlayerEventProps: e.getMetadata() }
            : {};
        }
        fireReferencePixel(t, e) {
          this.logCoreError({
            id: `REFERENCE-${t}`,
            error: new Error(`REFERENCE-${t}`),
            analyticsSampleRateAdjustFactor: e ?? { status: 0.01, error: 0.01 },
            account: null,
          });
        }
        logCoreError(t) {
          this.logError({ ...t, isCore: !0 });
        }
        logCoreFeature(t) {
          this.logFeature({ ...t, isCore: !0 });
        }
        logError(t) {
          if (void 0 === t) return;
          const e = this.getEventSampleRate({
            eventCategory: "error",
            rateFactor: {
              error: t.analyticsSampleRateAdjustFactor?.error,
              status: t.analyticsSampleRateAdjustFactor?.status,
            },
          });
          this.kt.logEvent({
            eventCategory: "error",
            eventName: t.id ?? "unknown",
            eventSampleRate: e,
            eventProperties: {
              ...t.props,
              ...this.getSharedEventProperties(t),
              error: {
                name: this.getErrorName(t.error),
                message: this.getErrorMessage(t.error),
                stack: this.getStackTraceMessage(t.error),
                context: this.getErrorContext(t.error),
              },
            },
          });
        }
        logFeature(t) {
          if (void 0 === t) return;
          const e = this.getEventSampleRate({
            eventCategory: "feat",
            rateFactor: {
              error: t.analyticsSampleRateAdjustFactor?.error,
              status: t.analyticsSampleRateAdjustFactor?.status,
            },
          });
          this.kt.logEvent({
            eventCategory: "feat",
            eventName: t.id ?? "unknown",
            eventSampleRate: e,
            eventProperties: {
              ...t.props,
              ...this.getSharedEventProperties(t),
              status: t.feature,
            },
          });
        }
        flush() {
          this.kt.flush();
        }
        setEventProcessingInterval(t) {
          if ("number" != typeof t)
            throw new Error("Event processing interval must be a number.");
          this.kt.clearAndUpdateEventProcessingInterval(t);
        }
        setEventSamplingRates(t) {
          const e = (t) => (t < 0 ? 0 : t >= 0 && t <= 1 ? t : 1);
          "number" == typeof t?.error && (this.It = e(t.error)),
            "number" == typeof t?.feature && (this.At = e(t.feature));
        }
        getEventSampleRate(t) {
          let e = 0;
          return (
            (e =
              "error" === t.eventCategory
                ? this.It * (t.rateFactor?.error ?? 1)
                : this.At * (t.rateFactor?.status ?? 1)),
            Number.isNaN(e) || e < 0 ? 0 : e >= 0 && e <= 1 ? e : 1
          );
        }
        getSharedEventProperties(t) {
          return {
            isCore: t.isCore ?? !1,
            accountID: this.safelyGetAccountID(t.account),
            libraryVersion: t.libraryVersion ?? I,
            url: this.getLocationHref(),
            hostname: this.getLocationHostname(),
            viewerCountryCode: this.getViewerCountryCode(t.account),
            ...(void 0 !== gt && { slice: gt }),
            ...this.getVideoPlayerMetadata(t),
          };
        }
        safelyGetAccountID(t) {
          let e = "unknown";
          try {
            void 0 !== t?.id && (e = t.id);
          } catch (t) {
            try {
              e = `Client Error: ${t.name.toString()} - ${t.message}`;
            } catch {
              e = "Client Error: Unable to provide more information";
            }
          }
          return e;
        }
        getLocationHref() {
          let t = "";
          try {
            t = window.top?.location?.href ?? "";
          } catch (e) {
            try {
              t = `Client Error: ${e.name.toString()} - ${e.message}`;
            } catch {
              t = "Client Error: Unable to provide more information";
            }
          }
          return t;
        }
        getLocationHostname() {
          let t = "";
          try {
            t = window.top?.location?.hostname ?? "";
          } catch (e) {
            try {
              t = `Client Error: ${e.name.toString()} - ${e.message}`;
            } catch {
              t = "Client Error: Unable to provide more information";
            }
          }
          return t;
        }
        getViewerCountryCode(t) {
          let e = "unknown";
          try {
            null !== t && (e = t.use(ht));
          } catch (t) {
            try {
              e = `Client Error: ${t.name.toString()} - ${t.message}`;
            } catch {
              e = "Client Error: Unable to provide more information";
            }
          }
          return e;
        }
        getStackTraceMessage(t) {
          try {
            if ("string" == typeof t) return "NO STACK: ERROR PASSED AS STRING";
            if (void 0 === t.stack) return "NO STACK: error.stack IS UNDEFINED";
            if (t.stack.length > this.STACK_MAX_LENGTH) {
              const e = "[...]";
              return t.stack.substring(0, this.STACK_MAX_LENGTH - e.length) + e;
            }
            return t.stack;
          } catch (t) {
            return "NO STACK: ERROR ON RETRIEVAL";
          }
        }
        getErrorName(t) {
          let e = "unknown";
          try {
            "string" == typeof t ? (e = t) : void 0 !== t.name && (e = t.name);
          } catch (t) {
            try {
              e = `Client Error: ${t.name.toString()} - ${t.message}`;
            } catch {
              e = "Client Error: Unable to provide more information";
            }
          }
          return e;
        }
        getErrorMessage(t) {
          let e = "unknown";
          try {
            "string" == typeof t
              ? (e = t)
              : void 0 !== t.message && (e = t.message);
          } catch (t) {
            try {
              e = `Client Error: ${t.name.toString()} - ${t.message}`;
            } catch {
              e = "Client Error: Unable to provide more information";
            }
          }
          return e;
        }
        getErrorContext(t) {
          let e = "unknown";
          try {
            "string" != typeof t && "context" in t && (e = t.context ?? "");
          } catch (t) {
            try {
              e = `Client Error: ${t.name.toString()} - ${t.message}`;
            } catch {
              e = "Client Error: Unable to provide more information";
            }
          }
          return e;
        }
      })(),
      wt = new Map([
        [
          "_config/config/didLoad",
          async ({ account: t, customEvent: e }) => (
            t.write("config/loaded", !0), s.completed
          ),
        ],
        [
          "_config/requestViewerCountry/define",
          async ({ account: t, customEvent: e }) => {
            if (void 0 === e.detail?.code)
              throw new Error("Missing country code");
            const { code: n } = e.detail;
            if ("string" != typeof n || 0 === n.trim().length)
              throw new Error(`Invalid country code: "${n}"`);
            return t.update(ht, () => n), s.completed;
          },
        ],
      ]),
      bt = "apstag/configuration/fetch",
      xt = new Map([
        [
          bt,
          async ({ account: t, customEvent: e }) => {
            const n = t.globalContext.document.createElement("script");
            return (
              n.setAttribute(
                "src",
                `https://config.aps.amazon-adsystem.com/configs/${t.id}`
              ),
              n.setAttribute("type", "text/javascript"),
              n.setAttribute("async", "async"),
              t.globalContext.document.head.appendChild(n),
              await new Promise((t, e) => {
                n.addEventListener("load", () => {
                  t();
                }),
                  n.addEventListener("error", (t) => {
                    e(t);
                  });
              }),
              s.completed
            );
          },
        ],
      ]),
      Et = "consent/GPPData",
      St = "consent/isGPPListenerRegistered";
    var _t = new pt({
        scope: "consent",
        object: "gppapi",
        action: "syncData",
        validators: {
          detail: {
            detail: et,
            "detail.fromAddEvent": rt(tt),
            "detail.eventListener": rt(et),
            "detail.eventListener.pingData": rt(et),
            "detail.eventListener.pingData.gppString": rt(X),
            "detail.eventListener.pingData.gppVersion": rt(at([X, Z])),
            "detail.eventListener.pingData.cmpId": rt(at([X, Z])),
            "detail.eventListener.pingData.applicableSections": ot,
            "detail.eventListener.pingData.applicableSections[]": at([X, Z]),
          },
        },
        handler: async ({ account: t, detail: e }) => {
          let n, a, o, i;
          (e?.eventListener?.pingData?.gppString ?? "").length > 0
            ? ((n = e?.eventListener?.pingData), (i = "addEventListener"))
            : (([n, o] = ((t) => {
                let e, n;
                try {
                  const n = t.globalContext.__gpp("ping", (t, n) => {
                    n && "object" == typeof t && (e = t);
                  });
                  void 0 === e && (n?.gppString ?? "").length > 0 && (e = n);
                } catch (t) {
                  n = `E:ping: ${t}`;
                }
                return [e, n];
              })(t)),
              (i = "ping"),
              "object" != typeof n &&
                (([n, a] = ((t) => {
                  let e, n;
                  try {
                    const n = t.globalContext.__gpp("getGPPData");
                    e = { ...n, ...n.pingData };
                  } catch (t) {
                    n = `E:getGPPData: ${t}`;
                  }
                  return [e, n];
                })(t)),
                (i = "getGPPData")));
          const r = {
            gpp: {
              gppLength:
                "string" == typeof n?.gppString ? n.gppString.length : void 0,
              isGPPTilde: (n?.gppString ?? "").includes("~"),
              error10: a,
              error: o,
              gppVersion: n?.gppVersion,
              cmpId: n?.cmpId,
              method: i,
              fromAddEvent: e?.fromAddEvent,
            },
          };
          return t.write(Et, n), { status: s.completed, analytics: r };
        },
      }),
      Rt = new pt({
        scope: "consent",
        object: "gppapi",
        action: "didChange",
        validators: {
          detail: {
            detail: et,
            "detail.fromAddEvent": rt(tt),
            "detail.eventListener": rt(et),
            "detail.eventListener.pingData": rt(et),
            "detail.eventListener.pingData.type": dt,
            "detail.eventListener.pingData.gppString": rt(X),
            "detail.eventListener.pingData.gppVersion": rt(at([X, Z])),
            "detail.eventListener.pingData.cmpId": rt(at([X, Z])),
            "detail.eventListener.pingData.applicableSections": ot,
            "detail.eventListener.pingData.applicableSections[]": at([X, Z]),
          },
        },
        handler: async ({
          account: t,
          detail: { eventListener: e, fromAddEvent: n },
        }) => (
          await t.recordListener(_t, { eventListener: e, fromAddEvent: n }),
          { status: s.completed }
        ),
      }),
      It = new pt({
        scope: "consent",
        object: "gppapi",
        action: "attemptSync",
        handler: async ({ account: t }) => {
          if (void 0 === t.globalContext.__gpp || !0 === t.read(St))
            return { status: s.cancelled };
          await t.recordListener(_t);
          const e = t.globalContext.__gpp("addEventListener", (e) => {
            "error" !== e?.eventName &&
              t.recordListenerNonBlocking(Rt, {
                eventListener: e,
                fromAddEvent: !0,
              });
          });
          return (
            t.write(
              St,
              "listenerRegistered" === e?.eventName && !0 === e?.data
            ),
            { status: s.completed }
          );
        },
      });
    const At = { key: "consent/isTCFAPIListenerRegistered", default: !1 },
      kt = { key: "consent/TCData", default: void 0 };
    function jt(t, e) {
      return (
        ("string" == typeof e?.tcString && e?.tcString.length > 0) ||
        !0 === t?.globalContext?.apstag?.isGDPRRegion ||
        !0 === e?.gdprApplies
      );
    }
    function $t(t, e) {
      return (
        !0 === t.vendor?.consents?.[793] &&
        ((n = e),
        (a = t.purpose?.consents),
        (n ?? []).reduce((t, e) => t && !0 === a?.[e], !0))
      );
      var n, a;
    }
    var Ct = new pt({
      scope: "consent",
      object: "tcfapi",
      action: "didChange",
      validators: {
        detail: {
          detail: et,
          "detail.success": rt(tt),
          "detail.tcData": rt(lt),
        },
      },
      handler: async ({ account: t, detail: { success: e, tcData: n } }) => (
        t.update(At, (t) => t || !0 === e),
        t.update(kt, (t) => (void 0 !== n || !0 === e ? n : t)),
        "object" != typeof n
          ? { status: s.completed }
          : { status: s.completed, analytics: Ot(t, n) }
      ),
    });
    const Ot = (t, e) => {
      const n = { tcData: e, consents: [1] },
        a = (t) => {
          try {
            return t();
          } catch {
            return "error";
          }
        };
      return {
        tcT: a(() => t.isAPStagAllowedToAccessInfoOnDevice()),
        tcCC: a(() =>
          (function ({ account: t, tcData: e, consents: n }) {
            if (!jt(t, e)) return !0;
            if ("object" != typeof e) return !1;
            if ((e.tcfPolicyVersion ?? 0) < 2) return !1;
            if (e.useNonStandardStacks) return !1;
            if (!e.isServiceSpecific) return !1;
            let a = !1;
            return (
              n.forEach((t) => {
                const o = e.publisher?.restrictions?.[t]?.[793];
                switch (o) {
                  case 0:
                  case 2:
                    a = !0;
                    break;
                  default:
                    $t(e, n) || (a = !0);
                }
              }),
              !a
            );
          })({ ...n, account: t })
        ),
        tcCF: a(
          () =>
            0 ===
            (function ({ tcData: t, consents: e }) {
              if (0 === (e ?? []).length) return ["No consents param passed"];
              const n = [];
              try {
                if ("object" != typeof t) {
                  let e = "";
                  try {
                    e = JSON.stringify(t);
                  } catch {}
                  n.push(`Invalid tcData: ${e}`);
                }
                return !1 === t.gdprApplies
                  ? []
                  : ((t.tcfPolicyVersion ?? 0) < 2 &&
                      n.push(
                        `tcData version not supported: ${t.tcfPolicyVersion}`
                      ),
                    t.useNonStandardStacks &&
                      n.push(
                        "tcData's useNonStandardStacks should not be true"
                      ),
                    t.isServiceSpecific ||
                      n.push("tcData needs to be service specific"),
                    e.forEach((a) => {
                      const o = t.publisher?.restrictions?.[a]?.[793];
                      switch (o) {
                        case 0:
                          n.push(
                            `Invalid publisher restrictions 0, consent ${a}`
                          );
                          break;
                        case 2:
                          n.push(
                            `Invalid publisher restrictions 2, consent ${a}`
                          );
                          break;
                        default:
                          $t(t, e) ||
                            n.push(
                              `Invalid publisher restrictions default, consent ${a}`
                            );
                      }
                    }),
                    n);
              } catch (t) {
                if (n.length > 0) return n;
                throw t;
              }
            })(n).length
        ),
        PRA: a(() => jt(t, e)),
      };
    };
    var Pt = new pt({
      scope: "consent",
      object: "tcfapi",
      action: "attemptSync",
      handler: async ({ account: t }) => {
        const e = t.use(At);
        return void 0 === t.globalContext.__tcfapi || e
          ? { status: s.cancelled }
          : (t.globalContext.__tcfapi("addEventListener", 2, (e, n) => {
              t.recordListenerNonBlocking(Ct, { tcData: e, success: n });
            }),
            { status: s.completed });
      },
    });
    const Dt = mt([It, Rt, _t, Pt, Ct]),
      Tt = (t) => (et(t), { verifiable: !1 }),
      Nt = [
        "setConfig",
        "getConfig",
        "setTargeting",
        "getTargeting",
        "getTargetingMap",
        "clearTargeting",
      ],
      Lt = (t) => {
        const e = {};
        for (const n of Nt) (e[`${t}.${n}`] = rt(ct)), (e[`${t}.${n}()`] = lt);
        return e;
      },
      Mt = (t) => ({
        [`${t}.getSlotElementId`]: rt(ct),
        [`${t}.name`]: rt(X),
        ...Lt(t),
      }),
      Ut = {
        context: et,
        "context.googletag": et,
        "context.googletag.setConfig": rt(ct),
        "context.googletag.setConfig()": lt,
        "context.googletag.getConfig": rt(ct),
        "context.googletag.getConfig()": lt,
        "context.googletag.pubads": rt(ct),
        "context.googletag.pubads()": rt(et),
        ...Lt("context.googletag.pubads()"),
      },
      qt = { detail: et, "detail.slot": et, ...Mt("detail.slot") },
      Vt = {
        detail: et,
        "detail.slots": ot,
        "detail.slots[]": et,
        ...Mt("detail.slots[]"),
      },
      Ft = {
        detail: et,
        "detail.configs": ot,
        "detail.configs[]": et,
        "detail.configs[].slot": et,
        ...Mt("detail.configs[].slot"),
        "detail.configs[].targeting": Tt,
      };
    var Bt = new pt({
        scope: "googletag",
        object: "pubads",
        action: "setConfig",
        validators: {
          detail: { detail: et, "detail.targeting": Tt },
          context: { ...Ut },
        },
        handler: async ({ context: t, detail: { targeting: e } }) => {
          const n = t.googletag;
          if ("function" == typeof n.setConfig) n.setConfig({ targeting: e });
          else {
            const t = n.pubads();
            Object.keys(e).forEach((n) => {
              t.setTargeting(n, e[n]);
            });
          }
          return { status: s.completed };
        },
      }),
      zt = new pt({
        scope: "googletag",
        object: "pubads",
        action: "getConfig",
        validators: { detail: { detail: et }, context: { ...Ut } },
        handler: async ({ context: t }) => {
          const e = t.googletag;
          let n;
          if ("function" == typeof e.getConfig)
            n = e.getConfig("targeting")?.targeting ?? {};
          else {
            const t = e.pubads();
            n =
              "function" == typeof t.getTargetingMap
                ? t.getTargetingMap() ?? {}
                : {};
          }
          return { status: s.completed, value: { targeting: n } };
        },
      }),
      Jt = new pt({
        scope: "googletag",
        object: "pubads",
        action: "clearTargeting",
        validators: {
          detail: {
            detail: et,
            "detail.key": rt(X),
            "detail.keys": rt(ot),
            "detail.keys[]": X,
          },
          context: { ...Ut },
        },
        handler: async ({ context: t, detail: { key: e, keys: n } }) => {
          const a = t.googletag;
          if ("function" == typeof a.setConfig)
            if (void 0 !== n) {
              const t = {};
              n.forEach((e) => {
                t[e] = null;
              }),
                a.setConfig({ targeting: t });
            } else
              void 0 === e
                ? a.setConfig({ targeting: null })
                : a.setConfig({ targeting: { [e]: null } });
          else {
            const t = a.pubads();
            void 0 !== n
              ? n.forEach((e) => t.clearTargeting(e))
              : t.clearTargeting(e);
          }
          return { status: s.completed };
        },
      }),
      Ht = new pt({
        scope: "googletag",
        object: "slot",
        action: "setConfig",
        validators: {
          detail: {
            ...qt,
            ...Vt,
            ...Ft,
            detail: et,
            "detail.slot": rt(et),
            "detail.slots": rt(ot),
            "detail.configs": rt(ot),
            "detail.targeting": rt(Tt),
          },
        },
        handler: async ({
          detail: { slot: t, slots: e, configs: n, targeting: a },
        }) => (
          (
            n ?? (e ?? (t ? [t] : [])).map((t) => ({ slot: t, targeting: a }))
          ).forEach(({ slot: t, targeting: e }) => {
            e &&
              0 !== Object.keys(e).length &&
              ("function" == typeof t.setConfig
                ? t.setConfig({ targeting: e })
                : Object.keys(e).forEach((n) => {
                    t.setTargeting(n, e[n]);
                  }));
          }),
          { status: s.completed }
        ),
      }),
      Gt = new pt({
        scope: "googletag",
        object: "slot",
        action: "getConfig",
        validators: { detail: { ...qt } },
        handler: async ({ detail: { slot: t } }) => {
          let e;
          return (
            (e =
              "function" == typeof t.getConfig
                ? t.getConfig("targeting")?.targeting ?? {}
                : "function" == typeof t.getTargetingMap
                ? t.getTargetingMap() ?? {}
                : {}),
            { status: s.completed, value: { targeting: e } }
          );
        },
      }),
      Kt = new pt({
        scope: "googletag",
        object: "slot",
        action: "clearTargeting",
        validators: {
          detail: {
            ...qt,
            "detail.key": rt(X),
            "detail.keys": rt(ot),
            "detail.keys[]": X,
          },
        },
        handler: async ({ detail: { slot: t, key: e, keys: n } }) => {
          if ("function" == typeof t.setConfig)
            if (void 0 !== n) {
              const e = {};
              n.forEach((t) => {
                e[t] = null;
              }),
                t.setConfig({ targeting: e });
            } else
              void 0 === e
                ? t.setConfig({ targeting: null })
                : t.setConfig({ targeting: { [e]: null } });
          else
            void 0 !== n
              ? n.forEach((e) => t.clearTargeting(e))
              : t.clearTargeting(e);
          return { status: s.completed };
        },
      });
    const Wt = mt([Bt, zt, Jt, Ht, Gt, Kt]),
      Qt = "vnd_prx_segments",
      Yt = "aps_targeting_comscore";
    var Zt = new pt({
      scope: "cxm",
      object: "comscore",
      action: "set",
      handler: async ({ account: t }) => ({ status: Xt(t) }),
    });
    const Xt = (t) => {
        const e = t.readSessionStorage(Yt);
        if ((t.deleteSessionStorage(Yt), null == e)) return s.cancelled;
        let n, a;
        try {
          if (((n = JSON.parse(e)[Qt]), null == n)) throw new Error();
          a = t.globalContext.googletag.pubads().getSlots();
        } catch (t) {
          throw new Error(`Malformed targeting object at ${Yt}`);
        }
        return (
          t.recordListenerNonBlocking(Ht, { slots: a, targeting: { [Qt]: n } }),
          s.completed
        );
      },
      te = "aps_targeting_ias";
    var ee = new pt({
      scope: "cxm",
      object: "ias",
      action: "set",
      handler: async ({ account: t }) => ({ status: ne(t) }),
    });
    const ne = (t) => {
        const e = ((t) => {
          const { iasApsArtifact: e } = t.globalContext;
          if (e) return e;
          const n = t.readSessionStorage(te);
          return n ? (t.deleteSessionStorage(te), JSON.parse(n)) : void 0;
        })(t);
        if (null == e) return s.cancelled;
        try {
          const { googletag: n } = t.globalContext,
            a = n.pubads().getSlots(),
            o = [];
          a.forEach((t) => {
            const n = e.targeting.slots[t.getSlotElementId()];
            if (null != n) {
              const e = {};
              Object.keys(n).forEach((t) => {
                e[t] = n[t];
              }),
                Object.keys(e).length > 0 && o.push({ slot: t, targeting: e });
            }
          }),
            o.length > 0 && t.recordListenerNonBlocking(Ht, { configs: o });
          const { brandSafety: i, fr: s, custom: r } = e.targeting,
            c = {};
          null != i &&
            Object.keys(i).forEach((t) => {
              c[t] = i[t];
            }),
            null != r &&
              Object.keys(r).forEach((t) => {
                c[t] = r[t];
              }),
            null != s && (c.fr = s),
            Object.keys(c).length > 0 &&
              t.recordListenerNonBlocking(Bt, { targeting: c });
        } catch (t) {
          throw new Error(`Malformed targeting object at ${te}`);
        }
        return s.completed;
      },
      ae = "aps_targeting_illuma";
    var oe = new pt({
      scope: "cxm",
      object: "illuma",
      action: "set",
      handler: async ({ account: t }) => ({ status: ie(t) }),
    });
    const ie = (t) => {
      const e = t.readSessionStorage(ae);
      if ((t.deleteSessionStorage(ae), null == e)) return s.cancelled;
      const n = JSON.parse(e).results;
      if (null == n) throw new Error(`Malformed targeting object at ${ae}`);
      const a = Object.keys(n);
      if (0 === a.length) return s.cancelled;
      const o = {};
      return (
        a.forEach((t) => {
          const e = n[t];
          o[`illuma_${t}`] = JSON.stringify(e);
        }),
        t.recordListenerNonBlocking(Bt, { targeting: o }),
        s.completed
      );
    };
    var se = new pt({
      scope: "cxm",
      object: "contextual",
      action: "set",
      handler: async ({ account: t, customEvent: e }) => (
        await Promise.all([
          t.recordListener(Zt),
          t.recordListener(ee),
          t.recordListener(oe),
        ]),
        { status: s.completed }
      ),
    });
    const re = mt([Zt, se, ee, oe]),
      ce = { key: "customPlacement/hints", default: {} },
      de = { key: "customPlacement/bidResponses", default: {} };
    class le {
      constructor(t, e, n) {
        (this.CLICK_PREFIX_MACRO = "%%CLICK_URL_PREFIX%%"),
          (this.PROGRAM_CUSTOM_PLACEMENTS = "customPlacements"),
          (this.getPageStyles = (t = ["p", "h1", "h2"]) =>
            t
              .map(this.getTagStyle)
              .filter((t) => Object.keys(t).length > 0)
              .reduce((t, e) => ({ ...t, ...e }), {})),
          (this.getContainerStyles = (t) => {
            try {
              if (!t) return {};
              const e = window.getComputedStyle(t),
                n = "--aps-custom-container-",
                a = new Map();
              return (
                a.set(`${n}width`, e.width),
                a.set(`${n}margin`, e.margin),
                a.set(`${n}padding`, e.padding),
                Object.fromEntries(a.entries())
              );
            } catch (t) {
              return {};
            }
          }),
          (this.slotProps = t),
          (this.rawResponse = e),
          (this.jt = n);
      }
      getTagStyle(t) {
        const e = this.jt.getElementsByTagName(t);
        if (e && e[0]) {
          const e = window.getComputedStyle(this.jt.getElementsByTagName(t)[0]),
            n = new Map(),
            a = "--aps-custom-page-";
          return (
            n.set(`${a}${t}-color`, e.color),
            n.set(`${a}${t}-fontFamily`, e.fontFamily),
            n.set(`${a}${t}-fontSize`, e.fontSize),
            n.set(`${a}${t}-fontWeight`, e.fontWeight),
            n.set(`${a}${t}-lineHeight`, e.lineHeight),
            Object.fromEntries(n)
          );
        }
        return {};
      }
      getDynamicFrameBodyHeight(t, e, n) {
        if (e) {
          const n = e?.contentDocument || e?.contentWindow?.document,
            a = n?.body.scrollHeight;
          e.style.height = `${a}px`;
          try {
            const e = {
              ...this.getPageStyles(),
              ...this.getContainerStyles(t),
            };
            Object.keys(e).forEach((t) => {
              n?.documentElement.style.setProperty(t, e[t]);
            });
          } catch (t) {}
        }
      }
      render(t) {
        return this.$t(t);
      }
      $t(t) {
        if (!this.rawResponse || !this.slotProps) return !1;
        try {
          const e = this.rawResponse.size.split("x"),
            n = this.rawResponse.targeting?.amzniid || this.rawResponse.amzniid,
            a = this.rawResponse.targeting?.amznadm || this.rawResponse.amznadm;
          if (!n) return !1;
          let o = this.slotProps.Ct;
          if (this.slotProps.location && this.slotProps.id) {
            const t = this.jt.createElement("div");
            this.jt
              .getElementById(this.slotProps.id)
              ?.insertAdjacentElement(this.slotProps.location, t),
              (o = t);
          }
          if (!o) return !1;
          const i = this.jt.createElement("iframe");
          return (
            (i.style.marginLeft = "0"),
            (i.style.marginTop = "0"),
            (i.style.height = `${e[1]}px`),
            (i.style.width = "100%"),
            i.setAttribute("data-testid", "amzn-asr-ad"),
            i.setAttribute("scrolling", "no"),
            i.setAttribute("frameborder", "0"),
            (i.onload = () =>
              this.getDynamicFrameBodyHeight(o, i, a ? "amznadm" : "admi")),
            (i.srcdoc = a || ""),
            t &&
              t.clickPrefix &&
              (i.srcdoc = i.srcdoc.replace(
                this.CLICK_PREFIX_MACRO,
                t.clickPrefix
              )),
            o.appendChild(i),
            this.updateSlotAttribute("status", "rendered"),
            !0
          );
        } catch (t) {
          throw new Error("CustomPlacements: Error while rendering");
        }
      }
      updateSlotAttribute(t, e) {
        this.slotProps.Ct?.setAttribute(`data-aps-custom-${t}`, e);
      }
    }
    const ue = { key: "customPlacement/timings", default: [] },
      pe = (t, e, n = 0, a = 0) => {
        try {
          const o = {
              effectiveType: e?.effectiveType,
              rtt: e?.rtt,
              downlink: e?.downlink,
            },
            i = (function (t, e, n) {
              try {
                return `${isNaN(e) || 0 === e ? t.body.clientWidth : e}x${
                  isNaN(n) || 0 === n ? t.body.clientHeight : n
                }`;
              } catch (t) {}
              return "x";
            })(t, n, a);
          return { connection: o, screen: i };
        } catch (t) {
          return {};
        }
      },
      me = (t, e, n) => {
        t.update(
          ue,
          (t) => (t.push({ time: performance.now(), key: `${e}/${n}` }), t)
        );
      },
      fe = "customPlacements";
    var he = new pt({
        scope: "customPlacement",
        object: "hint",
        action: "process",
        validators: {},
        handler: async ({ account: t, detail: e, customEvent: n }) => {
          const a = (e) => {
              me(t, fe, `hint/process/${e}`);
              const n = t.use(ce),
                a = t.use(de);
              n[e].isRendered ||
                (Object.values(a).forEach((a) => {
                  if (a.isRendered) return;
                  const o = t.globalContext.document.getElementById(e);
                  if (null == o) return;
                  const i = new le(
                    { id: e, Ct: o },
                    a,
                    t.globalContext.document
                  );
                  me(t, fe, `widget/render/${e}`),
                    i.render(n[e].hintMetadata) &&
                      ((a.isRendered = !0), (n[e].isRendered = !0));
                }),
                t.update(ce, () => n),
                t.update(de, () => a));
            },
            o = t.use(ce);
          return (
            Object.keys(o)
              .filter((t) => o[t].default)
              .forEach(a),
            Object.keys(o)
              .filter((t) => !o[t].default)
              .forEach(a),
            {
              status: s.completed,
              analytics: {
                browserInfo: pe(
                  t.globalContext.document,
                  t.globalContext.navigator?.connection,
                  t.globalContext.innerWidth,
                  t.globalContext.innerHeight
                ),
              },
            }
          );
        },
      }),
      ve = new pt({
        scope: "customPlacement",
        object: "hint",
        action: "define",
        validators: {},
        handler: async ({ account: t, detail: e, customEvent: n }) => {
          if (void 0 === n.detail?.id)
            throw new Error("Hint `id` must be defined");
          const { id: a, isDefault: o, hintMetadata: i } = n.detail;
          me(t, fe, `hint/define/${a}`);
          const r = t.use(ce);
          return (
            (r[a] = {
              default: "default" === o,
              isRendered: !1,
              hintMetadata: i ?? {},
            }),
            t.update(ce, () => r),
            t.recordListenerNonBlocking(he),
            {
              status: s.completed,
              analytics: {
                browserInfo: pe(
                  t.globalContext.document,
                  t.globalContext.navigator?.connection,
                  t.globalContext.innerWidth,
                  t.globalContext.innerHeight
                ),
              },
            }
          );
        },
      });
    const ge = {
        key: "customPlacement/placementResponseDispatched",
        default: !1,
      },
      ye = { key: "customPlacement/placementResponse", default: void 0 },
      we = { key: "customPlacement/contextURL", default: void 0 },
      be = {
        key: "customPlacement/placementEndpoint",
        default: "https://c.aps.amazon-adsystem.com/e/placements",
      },
      xe = { key: "ad/context", default: void 0 };
    var Ee = new pt({
      scope: "customPlacement",
      object: "placement",
      action: "fetch",
      validators: {},
      handler: async ({ account: t, detail: e, customEvent: n }) => {
        me(t, fe, "placementFetch/start");
        const a = await (async function (t) {
          const e = { ortb2: Se(t) },
            n = t.use(we),
            a = t.use(be),
            o = (function (t, e) {
              try {
                const n =
                  e ??
                  (function (t) {
                    try {
                      if (void 0 !== t.globalContext.top?.location.href)
                        return t.globalContext.top?.location.href;
                    } catch (t) {}
                    try {
                      if (t.globalContext.top !== t.globalContext.self)
                        return t.globalContext.document.referrer;
                    } catch (t) {}
                  })(t);
                if (void 0 !== n) return encodeURIComponent(n);
              } catch (t) {}
              return "";
            })(t, n),
            i = encodeURIComponent(JSON.stringify(e)),
            s = await fetch(`${a}?account=${t.id}&u=${o}&sg=${i}`);
          return await s.json();
        })(t);
        return (
          me(t, fe, "placementFetch/end"),
          {
            status: s.completed,
            value: { placementResponse: a },
            analytics: {
              browserInfo: pe(
                t.globalContext.document,
                t.globalContext.navigator?.connection,
                t.globalContext.innerWidth,
                t.globalContext.innerHeight
              ),
            },
          }
        );
      },
    });
    function Se(t) {
      const e = t.use(xe);
      if (void 0 !== e && "user" in e) {
        const { user: t, ...n } = e;
        return n;
      }
      return e;
    }
    const _e = {
        key: "customPlacement/bidEndpoint",
        default: "c.aps.amazon-adsystem.com",
      },
      Re = {
        key: "customPlacement/bidIsKey",
        default: "86355855cc6ed9e335d0382c8563aa10",
      };
    var Ie = new pt({
        scope: "customPlacement",
        object: "bids",
        action: "fetch",
        validators: {},
        handler: async ({ account: t, detail: e, customEvent: n }) => {
          const a = pe(
            t.globalContext.document,
            t.globalContext.navigator?.connection,
            t.globalContext.innerWidth,
            t.globalContext.innerHeight
          );
          if (void 0 === t.globalContext.apstag?.clientFetchBids)
            return { status: s.waiting, analytics: { browserInfo: a } };
          me(t, fe, "fetchBids/start");
          const o = await (async function (t) {
            const e = {
                slots: [
                  {
                    slotID: "93b7dd52-a8ce-11ed-afa1-0242ac120002:1",
                    sizes: [[999, 999]],
                  },
                ],
                timeout: 6e4,
                _endpointDomain: t.use(_e),
                params: { program: "apscustom", is: t.use(Re) },
              },
              n = {
                pubID: t.id,
                isSelfServePub: 36 === t.id.length,
                deals: !0,
              },
              a = t.use(we);
            return await new Promise((o) => {
              t.globalContext.apstag?.clientFetchBids(
                e,
                (t) => {
                  o(t);
                },
                { initConfig: n, contextURL: a }
              );
            });
          })(t);
          return (
            me(t, fe, "fetchBids/end"),
            {
              status: s.completed,
              value: { bidResponses: o },
              analytics: { browserInfo: a },
            }
          );
        },
      }),
      Ae = new pt({
        scope: "customPlacement",
        object: "service",
        action: "enable",
        validators: {},
        handler: async ({ account: t, detail: e, customEvent: n }) => (
          me(t, fe, "service/enable"),
          t.update(ge, () => !1),
          await Promise.all([
            t.recordListener(Ee).then(({ placementResponse: e }) => {
              ke(t, !0, e), t.update(ye, () => e);
            }),
            t
              .recordListener(Ie)
              .then(({ bidResponses: e }) => {
                e.forEach((e) => {
                  const n = e.targeting?.amzniid ?? e.amzniid;
                  let a = !1;
                  if ("" !== n) {
                    const o = t.use(de);
                    (o[n] = e), t.update(de, () => o), (a = !0);
                  }
                  ke(t, !1, {
                    aps: [{ active: a, dispatchEventOnValidBid: !0 }],
                  });
                });
              })
              .then(() => {
                t.recordListenerNonBlocking(he);
              }),
          ]),
          {
            status: s.completed,
            analytics: {
              browserInfo: pe(
                t.globalContext.document,
                t.globalContext.navigator?.connection,
                t.globalContext.innerWidth,
                t.globalContext.innerHeight
              ),
            },
          }
        ),
      });
    function ke(t, e, n) {
      if (t.use(ge)) return;
      const a = n?.aps?.find((t) => t.dispatchEventOnValidBid);
      (e && void 0 !== a) ||
        (me(t, fe, "placementResponseEvent/dispatch"),
        t.record("customPlacement/placement/didRespond", n).catch((t) => {}),
        t.update(ge, () => !0));
    }
    const je = new Map([...mt([ve, Ie, he, Ae, Ee])]),
      $e = { key: "ortbVendors/vm", default: {} },
      Ce = "anonymised";
    var Oe = new pt({
        scope: "ortbVendors",
        object: "anonymised",
        action: "set",
        handler: async ({ account: t }) => {
          const e = (function (t) {
            const e = t.readLocalStorage("cohort_ids");
            if ("string" == typeof e) {
              const t = JSON.parse(e);
              let n = "";
              for (let e = 0; e < t.length; e++)
                (n += t[e]), (n += e < t.length - 1 ? "," : "");
              return { data: { default: { user: { keywords: n } } } };
            }
          })(t);
          return void 0 === e
            ? { status: s.cancelled }
            : (t.update($e, (t) => ({ ...t, [Ce]: e })),
              { status: s.completed });
        },
      }),
      Pe = new pt({
        scope: "ortbVendors",
        object: "arcspan",
        action: "set",
        handler: async ({ account: t }) => {
          const e = (function (t) {
            const e = t.globalContext[De],
              n = t.globalContext[Te];
            let a = [],
              o = [],
              i = [];
            if (void 0 !== e) {
              if (
                (void 0 !== e.page_iab_codes.text &&
                  (a = a.concat(e.page_iab_codes.text)),
                void 0 !== e.page_iab_codes.images &&
                  (a = a.concat(e.page_iab_codes.images)),
                void 0 !== e.page_keywords)
              ) {
                const t =
                  "string" == typeof e.page_keywords
                    ? e.page_keywords.split(",")
                    : e.page_keywords;
                (i = i.concat(t)),
                  void 0 !== n?.compcohorts && (i = i.concat(n.compcohorts));
              }
              void 0 !== e.page_iab_newcodes.text &&
                (o = [...new Set([...o, ...e.page_iab_newcodes.text])]),
                void 0 !== e.page_iab_newcodes.images &&
                  (o = [...new Set([...o, ...e.page_iab_newcodes.images])]);
              const s = { name: "arcspan", segment: [], ext: { segtax: 6 } };
              o.forEach(function (t) {
                s.segment = s.segment.concat({ id: t });
              });
              const r = { data: [] };
              return (
                (r.data = r.data.concat(s)),
                {
                  data: {
                    default: {
                      site: {
                        name: "arcspan",
                        cat: a,
                        sectioncat: a,
                        pagecat: a,
                        keywords: i.toString(),
                        content: r,
                        domain: new URL(t.globalContext.location.href).hostname,
                        page: t.globalContext.location.href,
                        ref: t.globalContext.document.referrer,
                      },
                    },
                  },
                }
              );
            }
          })(t);
          return void 0 === e
            ? { status: s.cancelled }
            : (t.update($e, (t) => ({ ...t, arcspan: e })),
              { status: s.completed });
        },
      });
    const De = "arcobj1",
      Te = "arcobj2",
      Ne = { key: "idVendors/ids", default: void 0 },
      Le = { key: "idVendors/metadata", default: void 0 };
    function Me(t, e) {
      const n = t(e);
      return null != n
        ? (e.update(Ne, (t) => ({ ...t, ...n })), { status: s.completed })
        : { status: s.cancelled };
    }
    class Ue {
      constructor(t) {
        return (
          (this.parser = null),
          (this.keys = null),
          (this.account = null),
          (this.read = (t) => null),
          (this.anyAttributesMissing = () =>
            [
              this.parser,
              this.keys,
              this.account,
              this.egressNodeKey,
              this.read,
            ].some((t) => null == t)),
          (this.egressNodeKey = t),
          this
        );
      }
      using(t) {
        return (this.parser = t), this;
      }
      fromCookieKeys(t) {
        return (
          (this.keys = t),
          (this.read = (t) => this.account?.readCookieStorage(t)),
          this
        );
      }
      fromLocalStorageKeys(t) {
        return (
          (this.keys = t),
          (this.read = (t) => this.account?.readLocalStorage(t)),
          this
        );
      }
      fromCookieOrLocalStorageKeys(t) {
        return (
          (this.keys = t),
          (this.read = (t) =>
            this.account?.readCookieStorage(t) ??
            this.account?.readLocalStorage(t)),
          this
        );
      }
      fromLocalStorageOrCookieKeys(t) {
        return (
          (this.keys = t),
          (this.read = (t) =>
            this.account?.readLocalStorage(t) ??
            this.account?.readCookieStorage(t)),
          this
        );
      }
      forAccount(t) {
        return (this.account = t), this;
      }
      getRunner() {
        if (this.anyAttributesMissing())
          throw new Error("Missing attribute(s) - unable to return a runner.");
        return () => {
          if (this.anyAttributesMissing())
            throw new Error("Missing attribute(s) - runner execution failed.");
          for (const t of this.keys) {
            const e = this.parser(this.read(t));
            if (null != e) return { [this.egressNodeKey]: e };
          }
          return null;
        };
      }
    }
    const qe = function (t) {
        return "string" == typeof t ? t : null;
      },
      Ve = function (t) {
        return "string" == typeof t ? atob(t) : null;
      };
    function Fe(t) {
      return function (e) {
        return "string" == typeof e ? t(JSON.parse(e)) : null;
      };
    }
    function Be(t) {
      return function (e) {
        if ("string" != typeof e) return null;
        let n = e,
          a = null;
        for (let e = 0; ++e <= 5; )
          try {
            (n = decodeURIComponent(n)), (a = Fe(t)(n));
            break;
          } catch (t) {
            if (e >= 5) throw t;
          }
        return a;
      };
    }
    const ze = "growthcode",
      Je = "temp",
      He = ["gceb"];
    var Ge = new pt({
      scope: "ortbVendors",
      object: "growthcode",
      action: "set",
      handler: async ({ account: t }) => {
        const e = new Ue(Je)
          .using(qe)
          .fromLocalStorageKeys(He)
          .forAccount(t)
          .getRunner()();
        if (!e) return { status: s.cancelled };
        const n = JSON.parse(e[Je]);
        if (!(n instanceof Array)) return { status: s.cancelled };
        const a = n.filter((t) => Ke(t));
        if (0 === a.length) return { status: s.cancelled };
        const o = { data: { default: { user: { ext: { eids: a } } } } };
        return (
          t.update($e, (t) => ({ ...t, [ze]: o })), { status: s.completed }
        );
      },
    });
    const Ke = (t) =>
        !!t &&
        !!t.source &&
        t.uids instanceof Array &&
        0 !== t.uids.length &&
        t.uids.every((t) => void 0 !== t?.id),
      We = "intentiq",
      Qe = "temp";
    var Ye = new pt({
      scope: "ortbVendors",
      object: "intentiq",
      action: "set",
      handler: async ({ account: t }) => {
        const e = new Ue(Qe)
          .using(qe)
          .fromLocalStorageOrCookieKeys(["_iiq_aps"])
          .forAccount(t)
          .getRunner()();
        if (!e) return { status: s.cancelled };
        const n = JSON.parse(
          (function (t) {
            const e = t.split(".");
            let n = "";
            for (const t of e) {
              if (!/^\d+$/.test(t))
                throw new Error("Invalid IntentIQ encoded payload");
              const e = Number(t);
              if (!Number.isSafeInteger(e) || e > 65535)
                throw new Error("Invalid IntentIQ encoded payload");
              n += String.fromCharCode(42 ^ e);
            }
            return n;
          })(e[Qe])
        );
        if (!Array.isArray(n?.eids)) return { status: s.cancelled };
        const a = n.eids.filter(Ze);
        if (0 === a.length) return { status: s.cancelled };
        const o = { data: { default: { user: { ext: { eids: a } } } } };
        return (
          t.update($e, (t) => ({ ...t, [We]: o })), { status: s.completed }
        );
      },
    });
    const Ze = (t) =>
        !!t?.source &&
        !(!Array.isArray(t.uids) || 0 === t.uids.length) &&
        t.uids.every((t) => void 0 !== t?.id),
      Xe = "liveintent",
      tn = {
        nonId: { noExtraDefaults: !0, source: "liveintent.com", atype: 3 },
        bidswitch: { source: "bidswitch.net", atype: 3 },
        openx: { source: "openx.net", atype: 3 },
        magnite: { source: "rubiconproject.com", atype: 3 },
        medianet: { source: "media.net", atype: 3 },
        pubmatic: { source: "pubmatic.com", atype: 3 },
        index: { source: "liveintent.indexexchange.com", atype: 3 },
        uid2: { source: "uidapi.com", atype: 3 },
        sovrn: { source: "liveintent.sovrn.com", atype: 3 },
        thetradedesk: { source: "adserver.org", atype: 1 },
        vidazoo: { source: "liveintent.vidazoo.com", atype: 3 },
        triplelift: { source: "liveintent.triplelift.com", atype: 3 },
        sharethrough: { source: "sharethrough.com", atype: 3 },
        sonobi: { source: "liveintent.sonobi.com", atype: 3 },
        nexxen: { source: "liveintent.unrulymedia.com", atype: 3 },
        zetassp: { source: "zeta-ssp.liveintent.com", atype: 3 },
      };
    var en = new pt({
      scope: "ortbVendors",
      object: "liveintent",
      action: "set",
      handler: async ({ account: t }) => {
        const e = (function (t) {
          const e = t.readLocalStorage("__tamLIResolveResult");
          if (
            null != e &&
            (void 0 === t.globalContext.liModuleEnabled &&
              ((t.globalContext.liModuleEnabled = Math.random() < 0.95),
              t.globalContext?.googletag?.cmd.push(() => {
                t.recordListenerNonBlocking(Bt, {
                  targeting: {
                    "li-module-enabled": t.globalContext.liModuleEnabled
                      ? ["on"]
                      : ["off"],
                  },
                });
              })),
            t.globalContext.liModuleEnabled)
          ) {
            let t;
            try {
              t = nn(JSON.parse(e));
            } catch (n) {
              t = nn(JSON.parse(decodeURIComponent(e)));
            }
            if (void 0 !== t) return { data: { default: t } };
          }
        })(t);
        return void 0 === e
          ? { status: s.cancelled }
          : (t.update($e, (t) => ({ ...t, [Xe]: e })), { status: s.completed });
      },
    });
    function nn(t) {
      const e = [],
        n = { user: { ext: { eids: e } } };
      return (
        Object.entries(tn).forEach((n) => {
          const a = n[0],
            o = n[1];
          if (void 0 === t[a]) return;
          const i = { source: o.source, uids: [{ id: t[a], atype: o.atype }] };
          !0 !== o.noExtraDefaults &&
            (i.uids[0].ext = { provider: "liveintent.com" }),
            e.push(i);
        }),
        n
      );
    }
    const an = "optable",
      on = "temp";
    var sn = new pt({
      scope: "ortbVendors",
      object: "optable",
      action: "set",
      handler: async ({ account: t }) => {
        const e = new Ue(on)
          .using(qe)
          .fromLocalStorageKeys(["OPTABLE_RESOLVED"])
          .forAccount(t)
          .getRunner()();
        if (!e) return { status: s.cancelled };
        const n = (function (t) {
            return t && t.ortb2 ? t.ortb2 : t;
          })(JSON.parse(e[on])),
          a = { data: { default: n } };
        return (
          t.update($e, (t) => ({ ...t, [an]: a })), { status: s.completed }
        );
      },
    });
    const rn = "permutive",
      cn = "permutive_temp",
      dn = ["_pamzn_ids"];
    var ln = new pt({
      scope: "ortbVendors",
      object: "permutive",
      action: "set",
      handler: async ({ account: t }) => {
        const e = new Ue(cn)
          .using(qe)
          .fromLocalStorageKeys(dn)
          .forAccount(t)
          .getRunner()();
        if (!e) return { status: s.cancelled };
        const n = JSON.parse(e[cn]);
        if (!Array.isArray(n)) return { status: s.cancelled };
        const a = n.filter((t) => un(t));
        if (0 === a.length) return { status: s.cancelled };
        const o = { data: { default: { user: { ext: { eids: a } } } } };
        return (
          t.update($e, (t) => ({ ...t, [rn]: o })), { status: s.completed }
        );
      },
    });
    const un = (t) =>
        !!t &&
        !!t.source &&
        !!Array.isArray(t.uids) &&
        0 !== t.uids.length &&
        t.uids.every((t) => void 0 !== t?.id),
      pn = "utiq",
      mn = "utiqtemp";
    var fn = new pt({
      scope: "ortbVendors",
      object: "utiq",
      action: "set",
      handler: async ({ account: t }) => {
        const e = new Ue(mn)
          .using(qe)
          .fromLocalStorageKeys(["utiq_openrtb_eids"])
          .forAccount(t)
          .getRunner()();
        if (!e) return { status: s.cancelled };
        const n = JSON.parse(e[mn]);
        if (!Array.isArray(n)) return { status: s.cancelled };
        const a = n.filter((t) => hn(t));
        if (0 === a.length) return { status: s.cancelled };
        const o = { data: { default: { user: { ext: { eids: a } } } } };
        return (
          t.update($e, (t) => ({ ...t, [pn]: o })), { status: s.completed }
        );
      },
    });
    const hn = (t) =>
      !!t &&
      !!t.source &&
      !!Array.isArray(t.uids) &&
      0 !== t.uids.length &&
      t.uids.every((t) => void 0 !== t?.id);
    var vn = new pt({
      scope: "ortbVendors",
      object: "all",
      action: "process",
      handler: async ({ account: t }) => (
        await Promise.all([
          t.recordListener(Oe),
          t.recordListener(Pe),
          t.recordListener(Ge),
          t.recordListener(Ye),
          t.recordListener(en),
          t.recordListener(sn),
          t.recordListener(ln),
          t.recordListener(fn),
        ]),
        { status: s.completed }
      ),
    });
    const gn = mt([Oe, Pe, Ge, Ye, en, sn, ln, fn, vn]),
      yn = "33across",
      wn = "33acrossId";
    var bn = new pt({
      scope: "idVendors",
      object: "33across",
      action: "get",
      handler: async ({ account: t, customEvent: e }) => {
        const n = Me(xn, t),
          a = t.readLocalStorage(wn);
        if (a && a.length > 1500) {
          const t = { idLength: 100 * Math.ceil(a.length / 100) };
          return { ...n, analytics: t };
        }
        return n;
      },
    });
    const xn = (t) => {
        const e = t.readLocalStorage(wn);
        return null != e ? { [yn]: decodeURIComponent(e) } : null;
      },
      En = ["amxId"];
    var Sn = new pt({
      scope: "idVendors",
      object: "amx",
      action: "get",
      handler: async ({ account: t, customEvent: e }) =>
        Me(
          new Ue("amx")
            .using(qe)
            .fromLocalStorageKeys(En)
            .forAccount(t)
            .getRunner(),
          t
        ),
    });
    const _n = "audigent";
    var Rn = new pt({
      scope: "idVendors",
      object: "audigent",
      action: "get",
      handler: async ({ account: t, customEvent: e }) => Me(In, t),
    });
    const In = (t) => {
        const e =
          t.readLocalStorage("hadronId") ?? t.readLocalStorage("auHadronId");
        return null != e ? { [_n]: e } : null;
      },
      An = ["cto_bidid"];
    var kn = new pt({
      scope: "idVendors",
      object: "criteo",
      action: "get",
      handler: async ({ account: t, customEvent: e }) =>
        Me(
          new Ue("criteo")
            .using(qe)
            .fromLocalStorageKeys(An)
            .forAccount(t)
            .getRunner(),
          t
        ),
    });
    const jn = "firstid",
      $n = ["firstid"];
    var Cn = new pt({
      scope: "idVendors",
      object: "firstid",
      action: "get",
      handler: async ({ account: t, customEvent: e }) =>
        Me(
          new Ue(jn).using(qe).fromCookieKeys($n).forAccount(t).getRunner(),
          t
        ),
    });
    const On = { key: "idVendors/enabled", default: void 0 },
      Pn = {
        "context.apstag": et,
        "context.apstag.bids": ct,
        "context.apstag.bids()": ut,
        "context.apstag._atsaaiod": at([ut, ct]),
        "context.apstag.setDisplayBids": ct,
        "context.apstag.setDisplayBids()": null,
        "context._apstag": rt(et),
        "context._apstag.bids": rt(ct),
        "context._apstag.bids()": rt(ut),
        "context._apstag._atsaaiod": rt(at([ut, ct])),
        "context._apstag.setDisplayBids": rt(ct),
        "context._apstag.setDisplayBids()": null,
      };
    var Dn = new pt({
      scope: "idVendors",
      object: "enabled",
      action: "set",
      handler: async ({ account: t, detail: e, context: n }) =>
        Tn(n)
          ? (t.update(On, () => JSON.stringify(e.bidParameterKeys), {
              persist: !0,
            }),
            { status: s.completed })
          : { status: s.waiting },
      validators: {
        detail: {
          detail: et,
          "detail.bidParameterKeys": ot,
          "detail.bidParameterKeys[]": X,
        },
        context: {
          context: et,
          ...Pn,
          "context.apstag": at([ut, et]),
          "context._apstag": rt(at([ut, et])),
        },
      },
    });
    const Tn = (t) => void 0 !== t.apstag?._atsaaiod,
      Nn = { key: "idVendors/newConfigFlowEnabled", default: !1 };
    var Ln = new pt({
      scope: "idVendors",
      object: "newConfigFlowEnabled",
      action: "set",
      validators: {
        detail: { detail: et, "detail.value": tt },
        context: { context: et },
      },
      handler: async ({ account: t, detail: e }) => (
        t.update(Nn, () => e.value),
        { status: s.completed, analytics: { enabled: e.value } }
      ),
    });
    const Mn = [
      "1ad7261b-91ea-4b6f-b9e9-b83522205b75",
      "3161",
      "0ab198dd-b265-462a-ae36-74e163ad6159",
    ];
    var Un = new pt({
      scope: "idVendors",
      object: "newConfigFlow",
      action: "initialize",
      validators: { detail: { detail: et }, context: { context: et } },
      handler: async ({ account: t }) => {
        const e = !Mn.includes(t.id);
        return t.update(Nn, () => e), { status: s.completed };
      },
    });
    const qn = "fabrick";
    var Vn = new pt({
      scope: "idVendors",
      object: "fabrick",
      action: "get",
      handler: async ({ account: t, customEvent: e }) => Me(Fn, t),
    });
    const Fn = (t) => {
        let e = null;
        const n = t.readCookieStorage("pbjs_fabrickId");
        if (null != n) {
          const t = decodeURIComponent(n);
          e = JSON.parse(t).fabrickId;
        }
        return null != e ? { [qn]: e } : null;
      },
      Bn = ["FTrackId"],
      zn = (t) => (t?.DeviceID?.pop ? t?.DeviceID?.pop() ?? null : null);
    var Jn = new pt({
      scope: "idVendors",
      object: "fTrack",
      action: "get",
      handler: async ({ account: t, customEvent: e }) =>
        Me(
          new Ue("fTrack")
            .using(Be(zn))
            .fromLocalStorageKeys(Bn)
            .forAccount(t)
            .getRunner(),
          t
        ),
    });
    const Hn = "id5",
      Gn = "id5id";
    var Kn = new pt({
      scope: "idVendors",
      object: "id5",
      action: "get",
      handler: async ({ account: t, customEvent: e }) => Me(Wn, t),
    });
    const Wn = (t) => {
        const e = t.readLocalStorage(Gn);
        return null != e
          ? { [Hn]: JSON.parse(decodeURIComponent(e)).universal_uid }
          : null;
      },
      Qn = ["IDP"];
    var Yn = new pt({
      scope: "idVendors",
      object: "idPlus",
      action: "get",
      handler: async ({ account: t, customEvent: e }) =>
        Me(
          new Ue("idPlus")
            .using(Ve)
            .fromCookieOrLocalStorageKeys(Qn)
            .forAccount(t)
            .getRunner(),
          t
        ),
    });
    const Zn = ["__im_uid", "__im_ppid"];
    var Xn = new pt({
      scope: "idVendors",
      object: "intimateMerger",
      action: "get",
      handler: async ({ account: t, customEvent: e }) =>
        Me(
          new Ue("intimateMerger")
            .using(qe)
            .fromLocalStorageKeys(Zn)
            .forAccount(t)
            .getRunner(),
          t
        ),
    });
    const ta = "liveRamp",
      ea = "_lr_env",
      na = "idl_env",
      aa = "apstagLiveRampTimestamp";
    var oa;
    !(function (t) {
      (t[(t.oldTimestamp = 0)] = "oldTimestamp"),
        (t[(t.newTimestamp = 1)] = "newTimestamp"),
        (t[(t.noTimestamp = 2)] = "noTimestamp");
    })(oa || (oa = {}));
    var ia = new pt({
      scope: "idVendors",
      object: "liveramp",
      action: "get",
      handler: async ({ account: t, customEvent: e }) => {
        const n = ra(sa(t), t),
          a = Me(() => (null != n ? { [ta]: n.id } : null), t);
        return a.status === s.completed
          ? (function (t, e) {
              const a = null != n ? { [ta]: n.newGen } : null;
              return null != a
                ? (e.update(Le, (t) => ({ ...t, ...a })),
                  { status: s.completed })
                : { status: s.cancelled };
            })(0, t)
          : a;
      },
    });
    const sa = (t) => {
        const e = t.readLocalStorage(ea);
        if (null != e) return e;
        const n = t.readCookieStorage(ea);
        if (null != n) return n;
        const a = t.readLocalStorage(na);
        if (null != a) return a;
        const o = t.readCookieStorage(na);
        return null != o ? o : null;
      },
      ra = (t, e) => {
        if (null != t && "" !== t)
          try {
            const n = JSON.parse(atob(decodeURIComponent(t))),
              a = Array.isArray(n.envelope) ? n.envelope[0] : n.envelope;
            if ("string" != typeof a) return null;
            const o = { id: a, newGen: oa.noTimestamp };
            if (null != n.timestamp) {
              const t = e.readLocalStorage(aa);
              null == t || t < n.timestamp
                ? ((o.newGen = oa.newTimestamp),
                  e.writeLocalStorage(aa, n.timestamp.toString()))
                : (o.newGen = oa.oldTimestamp);
            }
            return o;
          } catch (e) {
            return { id: decodeURIComponent(t), newGen: oa.noTimestamp };
          }
        return null;
      },
      ca = {},
      da = new Set([Gn, na, ea]),
      la = {};
    var ua = new pt({
      scope: "idVendors",
      object: "lockr",
      action: "get",
      handler: async ({ account: t, customEvent: e }) => Me(pa, t),
    });
    const pa = (t) => {
        const e = t.readLocalStorage("lockr_identity_providers");
        if (e) {
          const n = {};
          return (
            e
              .split(",")
              .filter((t) => !da.has(t))
              .forEach((e) => {
                const a = ma(t, e);
                null !== a && (n[ca[e] || e] = decodeURIComponent(a));
              }),
            n
          );
        }
        return null;
      },
      ma = (t, e) => {
        let n = t.readLocalStorage(e);
        if (!n) return null;
        if (la[e])
          try {
            (n = JSON.parse(decodeURIComponent(n))),
              la[e].split(".").forEach((t) => {
                n = n?.[t];
              });
          } catch (t) {
            throw new Error(`Malformed json at ${e}: ${t}`);
          }
        return n || null;
      },
      fa = "lotame";
    var ha = new pt({
      scope: "idVendors",
      object: "lotame",
      action: "get",
      handler: async ({ account: t, customEvent: e }) => Me(va, t),
    });
    const va = (t) => {
        const e = t.readLocalStorage("panoramaId");
        return null != e ? { [fa]: e } : null;
      },
      ga = ["pbjs-merkleId"],
      ya = (t) => (t?.merkleId?.pop ? t?.merkleId?.pop()?.id ?? null : null);
    var wa = new pt({
      scope: "idVendors",
      object: "merkle",
      action: "get",
      handler: async ({ account: t, customEvent: e }) =>
        Me(
          new Ue("merkle")
            .using(Be(ya))
            .fromLocalStorageKeys(ga)
            .forAccount(t)
            .getRunner(),
          t
        ),
    });
    const ba = "pair",
      xa = ["pairId"],
      Ea = ["_lr_pairId"],
      Sa = (t) => (t?.envelope?.pop ? t?.envelope?.pop() ?? null : null);
    var _a = new pt({
      scope: "idVendors",
      object: "pair",
      action: "get",
      handler: async ({ account: t, customEvent: e }) =>
        Me(
          (t) =>
            new Ue(ba)
              .using(Ve)
              .fromCookieOrLocalStorageKeys(xa)
              .forAccount(t)
              .getRunner()() ??
            new Ue(ba)
              .using(
                (function (t) {
                  return function (e) {
                    return "string" == typeof e
                      ? Fe(t)(atob(decodeURIComponent(e)))
                      : null;
                  };
                })(Sa)
              )
              .fromCookieOrLocalStorageKeys(Ea)
              .forAccount(t)
              .getRunner()(),
          t
        ),
    });
    const Ra = "pubcommon",
      Ia = ["_pubcid", "_sharedID"];
    var Aa = new pt({
      scope: "idVendors",
      object: "pubcommon",
      action: "get",
      handler: async ({ account: t, customEvent: e }) =>
        Me(
          new Ue(Ra)
            .using(qe)
            .fromLocalStorageOrCookieKeys(Ia)
            .forAccount(t)
            .getRunner(),
          t
        ),
    });
    const ka = "publink",
      ja = ["_publink_srv", "_publink", "pbjs_publink"];
    var $a = new pt({
      scope: "idVendors",
      object: "publink",
      action: "get",
      handler: async ({ account: t, customEvent: e }) => Me(Ca, t),
    });
    const Ca = (t) => {
        for (const e of ja) {
          const n = t.readCookieStorage(e);
          if (null != n) {
            let t;
            try {
              t = JSON.parse(n).publink;
            } catch {
              t = n;
            }
            if (null != t) return { [ka]: t };
          }
        }
        return null;
      },
      Oa = ["__qca"];
    var Pa = new pt({
      scope: "idVendors",
      object: "quantcast",
      action: "get",
      handler: async ({ account: t, customEvent: e }) =>
        Me(
          new Ue("quantcast")
            .using(qe)
            .fromCookieKeys(Oa)
            .forAccount(t)
            .getRunner(),
          t
        ),
    });
    const Da = ["__uid2_advertising_token"],
      Ta = (t) => t?.latestToken?.advertising_token ?? null;
    var Na = new pt({
      scope: "idVendors",
      object: "uid",
      action: "get",
      handler: async ({ account: t, customEvent: e }) =>
        Me(
          new Ue("uid")
            .using(Fe(Ta))
            .fromLocalStorageKeys(Da)
            .forAccount(t)
            .getRunner(),
          t
        ),
    });
    const La = ["pbjs_unifiedID", "pbjs-unifiedid"],
      Ma = (t) => t?.TDID ?? null;
    var Ua = new pt({
      scope: "idVendors",
      object: "unifiedid",
      action: "get",
      handler: async ({ account: t, customEvent: e }) =>
        Me(
          new Ue("unifiedid")
            .using(Be(Ma))
            .fromLocalStorageOrCookieKeys(La)
            .forAccount(t)
            .getRunner(),
          t
        ),
    });
    const qa = "yahoo",
      Va = ["connectId"],
      Fa = (t) => t?.connectid ?? t?.connectId ?? null;
    var Ba = new pt({
      scope: "idVendors",
      object: "yahoo",
      action: "get",
      handler: async ({ account: t }) =>
        Me(
          new Ue(qa)
            .using(Be(Fa))
            .fromLocalStorageKeys(Va)
            .forAccount(t)
            .getRunner(),
          t
        ),
    });
    const za = "liveRamp/envelope",
      Ja = { key: "liveRamp/envelope", default: void 0 },
      Ha = { key: "liveRamp/envelopeHost", default: "https://api.rlcdn.com" };
    var Ga = new pt({
        scope: "liveRamp",
        object: "envelope",
        action: "fetch",
        handler: async ({ account: t }) => {
          if (void 0 === t.globalContext.apstag?._atsaaiod)
            return { status: s.waiting };
          const e = t.use(Ha),
            n = new URL(`${e}/api/identity/envelope`);
          n.searchParams.append("pid", "13310");
          const a = t.use(kt),
            o = t.read(Et);
          !0 === a?.gdprApplies &&
            a.tcString &&
            (n.searchParams.append("gdpr", "1"),
            n.searchParams.append("gdpr_consent", a.tcString)),
            o?.gppString &&
              o.applicableSections?.length > 0 &&
              (n.searchParams.append("gpp", o.gppString),
              n.searchParams.append("gpp_sid", o.applicableSections.join(",")));
          const i = await t.globalContext.fetch(n.toString(), {
              method: "GET",
              credentials: "include",
            }),
            r = { statusCode: i.status, responseOk: i.ok };
          if (200 !== i.status)
            return {
              status: s.cancelled,
              analytics: {
                ...r,
                ...(204 === i.status && { reason: "No Content" }),
              },
            };
          const c = await i.json();
          if (!c.envelope)
            return {
              status: s.cancelled,
              analytics: { ...r, reason: "missing_envelope" },
            };
          const d = JSON.stringify({
            value: c.envelope,
            createdAt: Date.now(),
          });
          return (
            t.update(Ja, () => c.envelope),
            t.writeLocalStorage(za, d, { usePrefix: !0 }),
            { status: s.completed, analytics: r }
          );
        },
      }),
      Ka = new pt({
        scope: "liveRamp",
        object: "envelope",
        action: "sync",
        handler: async ({ account: t }) => {
          if (void 0 === t.globalContext.apstag?._atsaaiod)
            return { status: s.waiting };
          const e = t.readLocalStorage(za, { usePrefix: !0 });
          if (e) {
            const { createdAt: n, value: a } = JSON.parse(e);
            if (a && Wa(n, Date.now()) < 15)
              return t.update(Ja, () => a), { status: s.completed };
          }
          return await t.recordListener(Ga), { status: s.completed };
        },
      });
    const Wa = (t, e) => {
      const n = new Date(t),
        a = new Date(e);
      return (n.getTime() - a.getTime()) / 864e5;
    };
    var Qa = new pt({
      scope: "idVendors",
      object: "rtisLiveRamp",
      action: "get",
      handler: async ({ account: t }) => (
        t.recordListenerNonBlocking(Ka), { status: s.completed }
      ),
    });
    const Ya = {
        "33across": bn,
        amx: Sn,
        audigent: Rn,
        criteo: kn,
        ddb_key_638: ua,
        firstid: Cn,
        fabrick: Vn,
        fTrack: Jn,
        id5: Kn,
        idPlus: Yn,
        intimateMerger: Xn,
        liveRamp: ia,
        lotame: ha,
        merkle: wa,
        pair: _a,
        pubcommon: Aa,
        publink: $a,
        quantcast: Pa,
        uid: Na,
        unifiedid: Ua,
        yahoo: Ba,
        rtisLiveRamp: Qa,
      },
      Za = Object.keys(Ya);
    var Xa = new pt({
      scope: "idVendors",
      object: "ids",
      action: "get",
      handler: async ({ account: t }) => {
        let e = Object.values(Ya);
        const n = t.use(On, { persist: !0, throwOnDisallowed: !1 });
        if (n) {
          const t = JSON.parse(n);
          if (
            ((a = t),
            !Array.isArray(a) || !a.every((t) => "string" == typeof t))
          )
            throw new Error("Received invalid 3P bid param key");
          const o = new Set(t);
          e = Za.filter((t) => o.has(t)).map((t) => Ya[t]);
        } else if (!t.use(d))
          return {
            status: s.cancelled,
            analytics: { reason: "consent_pending", enabledIdVendors: `${n}` },
          };
        var a;
        const o = n ? e : e.filter((t) => t !== Qa);
        return (
          await Promise.all(o.map((e) => t.recordListener(e))),
          { status: s.completed, analytics: { enabledIdVendors: `${n}` } }
        );
      },
    });
    const to = { key: "idVendors/integration/executed", default: new Set() },
      eo = (t) =>
        t
          ? t
              .toLowerCase()
              .trim()
              .replace(/^www\./, "")
          : "";
    var no = new pt({
      scope: "idVendors",
      object: "integration",
      action: "execute",
      validators: {
        detail: {
          detail: et,
          "detail.vendorId": X,
          "detail.countryCode": X,
          "detail.allowedRegions": rt(ot),
          "detail.allowedRegions[]": X,
          "detail.blockedRegions": rt(ot),
          "detail.blockedRegions[]": X,
          "detail.domainPrecedence": ot,
          "detail.domainPrecedence[]": et,
          "detail.domainPrecedence[].hostnames": ot,
          "detail.domainPrecedence[].hostnames[]": X,
          "detail.domainPrecedence[].script": rt(ct),
          "detail.domainPrecedence[].script()": dt,
          "detail.domainPrecedence[].propertyId": rt(X),
          "detail.defaultScript": rt(ct),
          "detail.defaultScript()": dt,
          "detail.defaultPropertyId": rt(X),
        },
        context: { context: lt },
      },
      handler: async ({ detail: t, account: e, context: n }) => {
        const a = e.use(Nn);
        let o = eo(n.location.hostname);
        if (!a)
          return (
            j() &&
              R.info(
                `[idVendors/integration/execute] cancelled: vendorId=${t.vendorId} hostname=${o} reason=sdk-flow-disabled`
              ),
            {
              status: s.cancelled,
              analytics: {
                vendorId: t.vendorId,
                hostname: o,
                cancellationReason: "sdk-flow-disabled",
              },
            }
          );
        let i,
          r,
          c,
          d,
          l = "context";
        o || ((o = eo(e.getResolvedHostname())), o && (l = "frame-walk"));
        for (const e of t.domainPrecedence) {
          if (e.hostnames.includes(o)) {
            if (((d = o), void 0 === e.script))
              return (
                j() &&
                  R.info(
                    `[idVendors/integration/execute] cancelled: vendorId=${t.vendorId} hostname=${o} reason=script-undefined-exact-match matchedRoute=${o}`
                  ),
                {
                  status: s.cancelled,
                  analytics: {
                    vendorId: t.vendorId,
                    matchType: "blocked",
                    matchedRoute: o,
                    hostname: o,
                    hostnameSource: l,
                    cancellationReason: "script-undefined-exact-match",
                  },
                }
              );
            (i = e.script), (r = e.propertyId), (c = "exact");
            break;
          }
          const n = e.hostnames.find((t) => o.endsWith("." + t));
          if (n) {
            if (((d = n), void 0 === e.script))
              return (
                j() &&
                  R.info(
                    `[idVendors/integration/execute] cancelled: vendorId=${t.vendorId} hostname=${o} reason=script-undefined-configDomain-match matchedRoute=${n}`
                  ),
                {
                  status: s.cancelled,
                  analytics: {
                    vendorId: t.vendorId,
                    matchType: "blocked",
                    matchedRoute: n,
                    hostname: o,
                    hostnameSource: l,
                    cancellationReason: "script-undefined-configDomain-match",
                  },
                }
              );
            (i = e.script), (r = e.propertyId), (c = "configDomain");
            break;
          }
        }
        if (!i) {
          if (!t.defaultScript)
            return (
              j() &&
                R.info(
                  `[idVendors/integration/execute] cancelled: vendorId=${t.vendorId} hostname=${o} reason=no-route-no-default`
                ),
              {
                status: s.cancelled,
                analytics: {
                  vendorId: t.vendorId,
                  matchType: "none",
                  hostname: o,
                  hostnameSource: l,
                  cancellationReason: "no-route-no-default",
                },
              }
            );
          (i = t.defaultScript),
            (r = t.defaultPropertyId),
            (c = "default"),
            (d = "default");
        }
        const u = `${t.vendorId}::${r ?? "__NO_PROPERTY_ID__"}`;
        if (e.use(to).has(u))
          return (
            j() &&
              R.info(
                `[idVendors/integration/execute] cancelled: vendorId=${t.vendorId} hostname=${o} propertyId=${r} reason=already-executed`
              ),
            {
              status: s.cancelled,
              analytics: {
                vendorId: t.vendorId,
                propertyId: r,
                hostname: o,
                hostnameSource: l,
                cancellationReason: "already-executed",
              },
            }
          );
        const p = t.countryCode;
        if (t.allowedRegions?.length && !t.allowedRegions.includes(p))
          return {
            status: s.cancelled,
            analytics: { vendorId: t.vendorId, reason: "region_blocked" },
          };
        if (t.blockedRegions?.length && t.blockedRegions.includes(p))
          return {
            status: s.cancelled,
            analytics: { vendorId: t.vendorId, reason: "region_blocked" },
          };
        let m, f, h;
        try {
          i();
        } catch (t) {
          (m = "vendor-script-execution-error"),
            (f = t instanceof Error ? t.name : "Error"),
            (h = t instanceof Error ? t.message : String(t));
        }
        if ((m || e.update(to, (t) => (t.add(u), t)), m))
          throw (
            (j() &&
              R.error(
                `[idVendors/integration/execute] vendorId=${t.vendorId} hostname=${o} matchType=${c} matchedRoute=${d} propertyId=${r} failure=${m} errorName=${f} errorMessage=${h}`
              ),
            new Error(h))
          );
        return (
          j() &&
            R.info(
              `[idVendors/integration/execute] vendorId=${t.vendorId} hostname=${o} matchType=${c} matchedRoute=${d} propertyId=${r}`
            ),
          {
            status: s.completed,
            analytics: {
              vendorId: t.vendorId,
              propertyId: r,
              matchType: c,
              matchedRoute: d,
              hostname: o,
              hostnameSource: l,
            },
          }
        );
      },
    });
    const ao = mt([
      bn,
      Sn,
      Rn,
      kn,
      Cn,
      Dn,
      Ln,
      Un,
      Vn,
      Jn,
      Kn,
      Yn,
      Xa,
      no,
      Xn,
      ia,
      ua,
      ha,
      wa,
      _a,
      Aa,
      $a,
      Pa,
      Na,
      Ua,
      Ba,
      Qa,
    ]);
    var oo = new pt({
      scope: "analytics",
      object: "sampleRateFactors",
      action: "set",
      validators: { detail: { detail: dt, "detail.sampleRateFactors": lt } },
      handler: async ({ account: t, detail: { sampleRateFactors: e } }) => (
        t.update(P, () => e), { status: s.completed }
      ),
    });
    const io = mt([
      new pt({
        scope: "analytics",
        object: "sampling",
        action: "set",
        validators: {
          detail: {
            detail: dt,
            "detail.rates": dt,
            "detail.rates.error": dt,
            "detail.rates.status": dt,
          },
        },
        handler: async ({ detail: t }) =>
          void 0 === t?.rates
            ? { status: s.cancelled }
            : (void 0 !== t?.rates?.error &&
                yt.setEventSamplingRates({ error: t?.rates?.error }),
              void 0 !== t?.rates?.status &&
                yt.setEventSamplingRates({ feature: t?.rates?.status }),
              { status: s.completed }),
      }),
      new pt({
        scope: "log",
        object: "analytics",
        action: "setInterval",
        validators: { detail: { detail: et, "detail.interval": Z } },
        handler: async ({ detail: t }) => (
          yt.setEventProcessingInterval(t.interval), { status: s.completed }
        ),
      }),
      oo,
    ]);
    var so = new pt({
      scope: "debug",
      object: "version",
      action: "show",
      handler: async ({ account: t, customEvent: e }) => ({
        status: s.completed,
        value: { LIBRARY_VERSION: I },
      }),
    });
    const ro = "debug/events/show",
      co = "debug/prepend/add",
      lo = "debug/prepend/remove",
      uo = "debug/store/show",
      po = "ad/debugSession/start",
      mo = new Map([
        [
          ro,
          async ({ account: t }) => {
            const e = [
              ...(null != t.store.get(w) ? t.store.get(w) : []).map((t) => ({
                type: t.type,
                status: "created",
                detail: t.detail,
                timestamp: t.timeStamp,
              })),
              ...t.queue.map((t) => ({
                type: t.type,
                status: "created",
                detail: t.detail,
                timestamp: t.timeStamp,
              })),
              ...(null != t.store.get(w) ? t.store.get(w) : [])
                .map((t) =>
                  null != t.statusEvents
                    ? t.statusEvents.map((e) => ({
                        type: t.type,
                        status: e.type,
                        detail: t.detail,
                        timestamp: e.timeStamp,
                      }))
                    : []
                )
                .flat(),
              ...t.queue
                .map((t) =>
                  null != t.statusEvents
                    ? t.statusEvents.map((e) => ({
                        type: t.type,
                        status: e.type,
                        detail: t.detail,
                        timestamp: e.timeStamp,
                      }))
                    : []
                )
                .flat(),
            ].filter((t) => !t.type.startsWith("debug/"));
            return (
              e.sort((t, e) => t.timestamp - e.timestamp),
              console.groupCollapsed(`⌂ Account ID: ${t.id}`),
              console.table(e),
              console.groupEnd(),
              s.completed
            );
          },
        ],
        [
          co,
          async ({ account: t, customEvent: n }) => {
            if (void 0 === n.detail?.eventName)
              throw new Error("Missing event information");
            const a = t.read(e, { persist: !0 }) ?? "[]",
              o = JSON.parse(a),
              { eventName: i, eventDetail: r } = n.detail;
            return (
              o.unshift({ eventName: i, eventDetail: r }),
              t.write(e, JSON.stringify(o), { persist: !0 }),
              s.completed
            );
          },
        ],
        [
          "debug/prepend/clear",
          async ({ account: t }) => (t.delete(e, { persist: !0 }), s.completed),
        ],
        [
          lo,
          async ({ account: t, customEvent: n }) => {
            if (void 0 === n.detail?.eventName)
              throw new Error("Missing event information");
            const a = t.read(e, { persist: !0 }) ?? "[]",
              o = JSON.parse(a),
              { eventName: i } = n.detail,
              r = o.filter((t) => t.eventName !== i);
            return t.write(e, JSON.stringify(r), { persist: !0 }), s.completed;
          },
        ],
        [
          uo,
          async ({ account: t }) => {
            const e = [...t.store.entries()];
            return (
              console.groupCollapsed(`⌂ Account ID: ${t.id}`),
              console.table(e),
              console.groupEnd(),
              s.completed
            );
          },
        ],
        [
          po,
          async ({ account: e, customEvent: n }) =>
            (function (t) {
              return t.status !== s.waiting;
            })(n) &&
            ((function (e, n) {
              void 0 !== e.detail?.minutes &&
                (function (e, n) {
                  const a = new Date();
                  e.write(
                    t,
                    a
                      .setMinutes(
                        Number(a.getMinutes()) + Number(n.detail?.minutes)
                      )
                      .toString(),
                    { persist: !0 }
                  );
                })(n, e),
                (function (t) {
                  (t.globalContext.apstagDEBUG =
                    t.globalContext.apstagDEBUG ?? {}),
                    (t.globalContext.apstagDEBUG.url = (function (t) {
                      const e = new URL(
                        t?.top?.location?.href ?? t?.document?.referrer
                      );
                      return (
                        e.searchParams.set("amzn_debug_mode", "1"), e.toString()
                      );
                    })(t.globalContext));
                })(n);
            })(n, e),
            (function (t) {
              return t.queue.filter((t) => t.type === po).length > 1;
            })(e))
              ? s.completed
              : (function (e) {
                  const n = e.read(t, { persist: !0 });
                  return void 0 !== n && new Date() >= new Date(Number(n));
                })(e)
              ? ((function (e) {
                  e.delete(t, { persist: !0 }),
                    (function (t) {
                      delete t.globalContext.apstagDEBUG?.url;
                    })(e);
                })(e),
                s.completed)
              : ((function (t) {
                  t.record(ro).catch((t) => {}), t.record(uo).catch((t) => {});
                })(e),
                s.waiting),
        ],
        [
          "debug/listeners/show",
          async ({ systemAccount: t }) => {
            const e = [...t.store.get(y).entries()];
            return (
              console.groupCollapsed("⌂ Listeners"),
              console.table(e),
              console.groupEnd(),
              s.completed
            );
          },
        ],
      ]),
      fo = new Map([...mo, ...mt([so])]);
    var ho;
    !(function (t) {
      (t[(t.unspecifiedUnknown = 0)] = "unspecifiedUnknown"),
        (t[(t.lowEntropy = 1)] = "lowEntropy"),
        (t[(t.highEntropy = 2)] = "highEntropy");
    })(ho || (ho = {}));
    const vo = ["brands", "mobile", "platform"],
      go = [
        "architecture",
        "bitness",
        "fullVersionList",
        "model",
        "platformVersion",
      ];
    var yo = new pt({
      scope: "deviceSignal",
      object: "sua",
      action: "set",
      validators: {
        context: {
          context: et,
          ...Pn,
          "context.navigator": et,
          "context.navigator.userAgentData": et,
          "context.navigator.userAgentData.getHighEntropyValues": ct,
          "context.navigator.userAgentData.architecture": rt(X),
          "context.navigator.userAgentData.bitness": rt(X),
          "context.navigator.userAgentData.mobile": rt(tt),
          "context.navigator.userAgentData.model": rt(X),
          "context.navigator.userAgentData.platform": rt(X),
          "context.navigator.userAgentData.platformVersion": rt(X),
          "context.navigator.userAgentData.fullVersionList": rt(ot),
          "context.navigator.userAgentData.fullVersionList[]": et,
          "context.navigator.userAgentData.fullVersionList[].brand": X,
          "context.navigator.userAgentData.fullVersionList[].version": X,
          "context.navigator.userAgentData.brands": rt(ot),
          "context.navigator.userAgentData.brands[]": et,
          "context.navigator.userAgentData.brands[].brand": X,
          "context.navigator.userAgentData.brands[].version": X,
        },
      },
      handler: async ({ account: t }) => {
        if (void 0 === t.globalContext.apstag?.isGDPRRegion)
          return { status: s.waiting };
        const e = "deviceSignal/sua",
          n = t.globalContext.navigator?.userAgentData,
          a = t.read(e, { persist: !0, throwOnDisallowed: !1 });
        return (
          "string" == typeof a
            ? t.write(e, a)
            : n instanceof Object &&
              (function (t, e, n) {
                t.write(e, JSON.stringify(wo(n)));
              })(t, e, n),
          !1 !== t.globalContext.apstag?.isGDPRRegion ||
            ("function" == typeof n?.getHighEntropyValues &&
              (await (async function (t, e, n) {
                const a = await n.getHighEntropyValues([...vo, ...go]);
                return (
                  t.write(e, JSON.stringify(wo(a)), {
                    persist: !0,
                    throwOnDisallowed: !1,
                  }),
                  s.completed
                );
              })(t, e, n))),
          { status: s.completed }
        );
      },
    });
    function wo(t) {
      const e = {};
      let n;
      return (
        (e.architecture = t.architecture),
        (e.bitness = t.bitness),
        (e.mobile = t.mobile ? 1 : 0),
        (e.model = t.model),
        (e.source =
          ((a = t),
          go.some((t) => a[t])
            ? ho.highEntropy
            : vo.some((t) => a[t])
            ? ho.lowEntropy
            : ho.unspecifiedUnknown)),
        "string" == typeof t.platform &&
          (e.platform = {
            brand: t.platform,
            version: t.platformVersion?.split("."),
          }),
        Array.isArray(t.fullVersionList)
          ? (n = t.fullVersionList)
          : Array.isArray(t.brands) && (n = t.brands),
        n instanceof Array &&
          (e.browsers = n.map((t) => ({
            brand: t.brand,
            version: t.version?.split("."),
          }))),
        e
      );
      var a;
    }
    const bo = mt([yo]),
      xo = { key: "deviceSignal/cookieDeprecationLabel", default: void 0 };
    var Eo = new pt({
      scope: "deviceSignal",
      object: "cookieDeprecationLabel",
      action: "set",
      handler: async ({ account: t, customEvent: e }) => {
        const { cookieDeprecationLabel: n } = t.globalContext.navigator;
        if (void 0 === n?.getValue || "function" != typeof n.getValue)
          return { status: s.cancelled };
        const a = await t.executeFuncWithConsent(n, n.getValue);
        return void 0 === a || "" === a
          ? { status: s.cancelled }
          : (t.update(xo, () => a),
            { status: s.completed, analytics: { gcdl: a } });
      },
    });
    const So = mt([Eo]),
      _o = { key: "_monitoring/statusesByEventIdentifier", default: new Map() };
    var Ro = async ({ account: t, customEvent: e }) => {
        const n = e.detail?.eventIdentifier;
        if (void 0 === n) throw new Error("Missing eventIdentifier parameter");
        const a = t.use(_o),
          o = `${e.type}:${n}`,
          i = a.get(o);
        return void 0 !== i ? i : s.waiting;
      },
      Io = async ({ account: t, customEvent: e }) => {
        const n = e.detail?.eventIdentifier;
        if (void 0 === n) throw new Error("Missing eventIdentifier parameter");
        const a = e.detail?.statusUpdate;
        if (void 0 === a) throw new Error("Missing statusUpdate parameter");
        if (!(a in s))
          throw new Error(
            `Invalid statusUpdate parameter. Expected one of ${Object.values(
              s
            ).join(", ")}`
          );
        const o = e.detail?.pairedEvents;
        if (void 0 === o || o.length < 1 || o.some((t) => "string" != typeof t))
          throw new Error(
            "Parameter pairedEvents must be a non-empty array of string"
          );
        return (
          o.forEach((e) => {
            const o = `${e}:${n}`;
            t.update(_o, (t) => t.set(o, a));
          }),
          s.completed
        );
      };
    const Ao = new Map([
      ["_monitor/testing/only", Ro],
      ["_update/testing/only", Io],
      ["_legacy/bidRequest/monitor", Ro],
      ["_legacy/bidRequest/didComplete", Io],
    ]);
    var ko = new pt({
      scope: "prebid",
      object: "analyticsEvent",
      action: "track",
      handler: async ({ account: t, customEvent: e }) => {
        if (
          void 0 === e.detail?.eventType ||
          void 0 === e.detail?.eventArgs ||
          void 0 === e.detail?.config?.options?.accountID
        )
          return { status: s.cancelled };
        const n = {
            eventType: e.detail.eventType,
            metadata: e.detail.metadata,
            config: e.detail.config,
          },
          a = await t.globalContext.fetch(
            "https://prod.us-east-1.cxm-bcn.publisher-services.amazon.dev/v1/events/prebid",
            jo(e.detail)
          );
        return a.ok
          ? { status: s.completed, analytics: n }
          : {
              status: s.cancelled,
              analytics: { ...n, message: `Request failed: ${a.status}` },
            };
      },
    });
    const jo = (t) => {
        const e = {
          accountId: t.config.options.accountID,
          events: [{ eventArgs: t.eventArgs, eventType: t.eventType }],
        };
        return {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(e),
        };
      },
      $o = { key: "prebid/config", default: void 0 };
    var Co;
    !(function (t) {
      (t.NotStarted = "NOT STARTED"),
        (t.Loading = "LOADING"),
        (t.Complete = "COMPLETE");
    })(Co || (Co = {}));
    const Oo = { key: "prebid/configRequestState", default: Co.NotStarted };
    var Po = new pt({
      scope: "prebid",
      object: "config",
      action: "fetch",
      handler: async ({ account: t, customEvent: e }) => {
        const n = t.use(Oo);
        if (n === Co.Loading) return { status: s.waiting };
        const a = { metadata: e?.detail?.metadata };
        if (n === Co.Complete) {
          const e = t.use($o);
          if (void 0 !== e)
            return { status: s.completed, value: JSON.parse(e), analytics: a };
        }
        try {
          t.update(Oo, () => Co.Loading);
          const e = `https://c.amazon-adsystem.com/cdn/prod/config?src=${t.id}`,
            n = await t.globalContext.fetch(e);
          if ((t.update(Oo, () => Co.Complete), !n.ok))
            return {
              status: s.cancelled,
              analytics: { ...a, message: "Config request failed" },
            };
          const o = await n.json(),
            i = Do(t, o);
          return (
            t.update($o, () => JSON.stringify(i), { persist: !0 }),
            { status: s.completed, value: i, analytics: a }
          );
        } catch (t) {
          return {
            status: s.cancelled,
            analytics: { ...a, message: t.message },
          };
        }
      },
    });
    const Do = (t, e) => ({
        analyticsConfig: {
          options: { accountID: t.id, sampling: e.pbjs?.sampleRate },
          includeEvents: e.pbjs?.allowedEvents,
        },
        idConfig: {
          params: {
            accountID: t.id,
            enabled: e.pbjs?.enabled,
            treatments: e.pbjs?.treatments,
          },
        },
      }),
      To = { key: "prebid/eidsConfig", default: "{}" };
    var No;
    !(function (t) {
      (t.APSSignalIQ = "_apsIdTreatment"),
        (t.Audigent = "hadronId"),
        (t.FirstID = "firstId"),
        (t.ID5 = "id5id"),
        (t.Liveramp = "idl_env"),
        (t.Lotame = "lotamePanoramaId"),
        (t.Pubcommon = "pubcid"),
        (t.Publink = "publinkId"),
        (t.ThirtyThree = "33acrossId"),
        (t.Yahoo = "connectId");
    })(No || (No = {}));
    const Lo = new Map([
        [_n, No.Audigent],
        [jn, No.FirstID],
        ["id5", No.ID5],
        [ta, No.Liveramp],
        [fa, No.Lotame],
        [Ra, No.Pubcommon],
        [ka, No.Publink],
        [yn, No.ThirtyThree],
        [qa, No.Yahoo],
      ]),
      Mo = {
        [No.Audigent]: { source: "audigent.com", atype: 1 },
        [No.FirstID]: { source: "first-id.fr", atype: 1 },
        [No.ID5]: { source: "id5-sync.com", atype: 1 },
        [No.Liveramp]: { source: "liveramp.com", atype: 3 },
        [No.Lotame]: { source: "crwdcntrl.net", atype: 1 },
        [No.Pubcommon]: { source: "pubcid.org", atype: 1 },
        [No.Publink]: { source: "epsilon.com", atype: 3 },
        [No.ThirtyThree]: { source: "33across.com", atype: 1 },
        [No.Yahoo]: { source: "yahoo.com", atype: 3 },
      };
    var Uo = new pt({
      scope: "prebid",
      object: "eidsConfig",
      action: "get",
      handler: async ({ account: t, customEvent: e }) => {
        if (void 0 === t.globalContext.apstag?._atsaaiod)
          return { status: s.waiting };
        t.update(To, () => JSON.stringify({ ...Mo }), { persist: !0 });
        const n = { metadata: e?.detail?.metadata, config: e?.detail?.config };
        return { status: s.completed, analytics: n };
      },
    });
    const qo = new Set(["CONTROL_HOLD_OUT", "CLEAN", ...Lo.keys()]);
    const Vo = { key: "prebid/ids", default: void 0 };
    var Fo = new pt({
      scope: "prebid",
      object: "ids",
      action: "get",
      handler: async ({ account: t, customEvent: e }) => {
        if (void 0 === t.globalContext.apstag?._atsaaiod)
          return { status: s.waiting };
        t.recordListenerNonBlocking(Xa);
        const n = t.use(Ne);
        let a;
        void 0 !== n &&
          (a = Object.fromEntries(
            Object.entries(n).map(([t, e]) => [Lo.get(t), e])
          ));
        const o = await t.recordListener(Po, { metadata: e?.detail?.metadata }),
          i = { metadata: e?.detail?.metadata };
        return o.idConfig.params.enabled
          ? (null != o.idConfig.params.treatments &&
              (a = (function (t, e) {
                if (
                  !(function (t) {
                    const e = 100 === t.reduce((t, { percent: e }) => t + e, 0),
                      n = t.reduce((t, { treatment: e }) => t && qo.has(e), !0);
                    return e && n;
                  })(e)
                )
                  return t;
                const n = (function (t) {
                  const e = 100 * Math.random();
                  let n = 0;
                  for (const a of t)
                    if (((n += a.percent), e <= n)) return a.treatment;
                  throw new Error("Invalid treatment percentages");
                })(e);
                return (function (t, e) {
                  const n = { [No.APSSignalIQ]: e },
                    a = Lo.get(e);
                  switch (e) {
                    case "CONTROL_HOLD_OUT":
                      return { ...t, ...n };
                    case "CLEAN":
                      return n;
                    default:
                      return (
                        void 0 !== a && void 0 !== t?.[a] && (n[a] = t[a]), n
                      );
                  }
                })(t, n);
              })(a, o.idConfig.params.treatments)),
            t.update(Vo, () => a),
            { status: s.completed, value: a, analytics: i })
          : { status: s.cancelled, analytics: i };
      },
    });
    const Bo = mt([ko, Po, Uo, Fo]),
      zo = (t) => (t === Jo.noConsent ? "AMZN-NoCookieConsent" : "AMZN-Token");
    var Jo;
    !(function (t) {
      (t[(t.noConsent = 0)] = "noConsent"), (t[(t.token = 1)] = "token");
    })(Jo || (Jo = {}));
    const Ho = (t) => {
        t.setCookieStorage(zo(Jo.token), "", 0),
          t.setCookieStorage(zo(Jo.noConsent), "", 0);
      },
      Go = ({
        account: t,
        hashedRecords: e,
        ttl: n,
        isGDPRRegion: a,
        tcString: o,
        setToken: i,
      }) => (
        Ho(t),
        "boolean" != typeof i && (i = !0),
        Ko({
          account: t,
          hashedRecords: e,
          ttl: n,
          isGDPRRegion: a,
          tcString: o,
        }).then(({ AIPToken: e, cookieExpiry: n }) =>
          Wo({ AIPToken: e, cookieExpiry: n, account: t, setToken: i })
        )
      ),
      Ko = ({
        account: t,
        hashedRecords: e,
        ttl: n,
        isGDPRRegion: a,
        tcString: o,
      }) =>
        fetch("https://tk.amazon-adsystem.com/envelope", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(
            Qo({
              account: t,
              hashedRecords: e,
              ttl: n,
              isGDPRRegion: a,
              tcString: o,
            })
          ),
        }).then((t) => {
          if (!t.ok) throw new Error(`Token http status error: ${t.status}`);
          return t.json();
        }),
      Wo = ({ AIPToken: t, cookieExpiry: e, account: n, setToken: a }) => {
        if ("string" != typeof t || "number" != typeof e)
          throw new Error("Invalid AIPES response");
        if ("" === t)
          throw (
            (n.setCookieStorage(zo(Jo.noConsent), "1", e),
            new Error("Empty token"))
          );
        (a || "boolean" != typeof a) && n.setCookieStorage(zo(Jo.token), t, e);
      },
      Qo = ({
        account: t,
        hashedRecords: e,
        ttl: n,
        isGDPRRegion: a,
        tcString: o,
      }) => {
        const i = { publisherId: t.id, hashedRecords: e };
        return (
          void 0 !== n && (i.ttl = n),
          a ? ((i.gdpr = 1), o && (i.gdprConsent = o)) : (i.gdpr = 0),
          i
        );
      };
    var Yo = new pt({
      scope: "ad",
      object: "record",
      action: "delete",
      handler: async ({ account: t }) => {
        if (!t.globalContext.apstag?._atsaaiod) return { status: s.waiting };
        if (!t.isAllowedToAccessInfoOnDevice())
          throw new Error("Not allowed to access storage on device");
        return Ho(t), { status: s.completed };
      },
    });
    const Zo = {
      detail: et,
      "detail.setCookie": rt(tt),
      "detail.config": et,
      "detail.config.optOut": rt(tt),
      "detail.config.ttl": rt(Z),
      "detail.config.gdpr": rt(et),
      "detail.config.gdpr.cmpTimeout": rt(Z),
      "detail.config.gdpr.enabled": rt(lt),
      "detail.config.gdpr.consent": rt(X),
      "detail.config.gdpr.cmpGlobal": rt(X),
      "detail.config.gdpr.cmpGlobalv2": rt(X),
      "detail.config.hashedRecords": ot,
      "detail.config.hashedRecords[]": et,
      "detail.config.hashedRecords[].type": X,
      "detail.config.hashedRecords[].record": X,
      "detail.config.hashedRecords[].encrypted": rt(Z),
      "detail.config.hashedRecords[].toJSON": dt,
      "detail.config.hashedRecords[].$$typeof": dt,
      "detail.config.hashedRecords[].constructor": dt,
      "detail.config.hashedRecords[].tagName": dt,
      "detail.config.hashedRecords[].@@__IMMUTABLE_ITERABLE__@@": dt,
      "detail.config.hashedRecords[].@@__IMMUTABLE_RECORD__@@": dt,
    };
    var Xo,
      ti,
      ei = new pt({
        scope: "ad",
        object: "record",
        action: "renew",
        validators: { detail: Zo, context: { context: et } },
        handler: async ({ account: t, detail: e }) => {
          if (!t.globalContext.apstag?._atsaaiod) return { status: s.waiting };
          if (void 0 === e?.config)
            throw new Error("Missing tokenConfig object");
          if (!t.isAllowedToAccessInfoOnDevice())
            throw new Error("Not allowed to access storage on device");
          if ((t.readCookieStorage(zo(Jo.token)) ?? "").length > 0)
            return { status: s.cancelled };
          const n = t.globalContext.apstag.isGDPRRegion,
            a = t.use(kt);
          var o;
          return (
            await ((o = {
              account: t,
              hashedRecords: e.config.hashedRecords,
              ttl: e.config.ttl,
              isGDPRRegion: n,
              tcString: a?.tcString,
            }),
            Go(o)),
            { status: s.completed }
          );
        },
      });
    !(function (t) {
      t.email = "email";
    })(Xo || (Xo = {})),
      (function (t) {
        (t.Display = "display"),
          (t.Video = "video"),
          (t.MultiFormat = "multi-format");
      })(ti || (ti = {}));
    const ni = /^[0-9a-fA-F]{64}$/,
      ai = (t) => ni.test(t || ""),
      oi = (t) =>
        t
          .then((t) =>
            Array.from(new Uint8Array(t))
              .map((t) => t.toString(16).padStart(2, "0"))
              .join("")
          )
          .then((t) =>
            "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855" !==
            t
              ? t
              : ""
          ),
      ii = (t, e) =>
        "string" == typeof t &&
        (e === Xo.email
          ? /\S+@\S+\.\S+/.test(t) || ai(t)
          : t.trim().length > 0),
      si = (t, e, n) =>
        e instanceof HTMLInputElement || e instanceof HTMLTextAreaElement
          ? ii(e.value, n)
            ? oi(
                t.globalContext.crypto.subtle.digest(
                  "SHA-256",
                  new t.globalContext.TextEncoder().encode(e.value || "")
                )
              )
            : Promise.resolve("")
          : ii(e.innerText, n)
          ? oi(
              t.globalContext.crypto.subtle.digest(
                "SHA-256",
                new t.globalContext.TextEncoder().encode(e.innerText || "")
              )
            )
          : Promise.resolve(""),
      ri = (t, e, n) => {
        const a = t.readLocalStorage(e);
        return a && ii(a, n) ? a : "";
      },
      ci = (t, e, n) => {
        (n = n ?? t.globalContext.location.href),
          (e = e.replace(/[[\]]/g, "\\$&"));
        const a = new RegExp("[?&#]" + e + "(=([^&#?]*)|&|#|$)").exec(n);
        return Array.isArray(a) &&
          "string" == typeof a[2] &&
          0 !== decodeURIComponent(a[2].replace(/\+/g, " ")).trim().length &&
          ai(decodeURIComponent(a[2].replace(/\+/g, " ")))
          ? Promise.resolve(decodeURIComponent(a[2].replace(/\+/g, " ")))
          : new Promise((t) => t(""));
      };
    var di;
    !(function (t) {
      (t.LOCAL_STORAGE = "LOCAL"), (t.CSS_SELECTOR = "CSS"), (t.URL = "URL");
    })(di || (di = {}));
    const li = (t, e = {}, n) => {
        ((t) => {
          const e = {
              [di.LOCAL_STORAGE]: 5,
              [di.URL]: 4,
              [di.CSS_SELECTOR]: 3,
            },
            n = {};
          t.forEach((t) => {
            (n[t.method] = (n[t.method] || 0) + 1), (t.priority = n[t.method]);
          }),
            t.sort((t, n) =>
              t.method === n.method
                ? (t.priority || 0) > (n.priority || 0)
                  ? 1
                  : -1
                : e[t.method] > e[n.method]
                ? -1
                : 1
            );
        })(e.methods || []);
        const a = [];
        let o;
        for (const i of e.methods || []) {
          const { method: e, target: s, type: r } = i;
          let c = "";
          switch (e) {
            case di.LOCAL_STORAGE:
              c = ri(t, s, r);
              break;
            case di.URL:
              a.push(ci(t, s).then((t) => ({ type: r, value: t })));
              break;
            case di.CSS_SELECTOR:
              o = i;
          }
          if (c.length > 0) return void n({ value: c, type: r });
        }
        const i = () => {
          if (
            !o ||
            (!0 !== o.isGlobalSubmit &&
              ("string" != typeof o.eventTarget || "string" != typeof o.event))
          )
            return void n(!1);
          const { eventTarget: e, target: a, type: i, isGlobalSubmit: s } = o,
            r = s ? "submit" : o.event;
          if ("string" != typeof r || 0 === r.length) return void n(!1);
          const c = (o) =>
            (({
              account: t,
              e: e,
              eventTarget: n,
              event: a,
              isGlobalSubmit: o,
              target: i,
              type: s,
              onDone: r,
              listener: c,
            }) => {
              if (
                !(
                  o ||
                  "window" === n ||
                  (e.target &&
                    "function" == typeof e.target.matches &&
                    "string" == typeof n &&
                    e.target.matches(n))
                )
              )
                return void r(!1);
              let d;
              o &&
                e instanceof Event &&
                e.target &&
                (d = e.target.querySelectorAll('input[type="email"]')),
                ((t, e, n, a) => {
                  const o = a || t.globalContext.document.querySelectorAll(e);
                  if (0 === o.length) return new Promise((t) => t(""));
                  if (1 === o.length) return si(t, o[0], n);
                  const i = [];
                  for (const e of o) i.push(si(t, e, n));
                  return Promise.all(i).then((t) => {
                    let e = null;
                    for (const n of t)
                      if ("" !== n) {
                        if (null !== e && ("string" != typeof e || e !== n))
                          return "";
                        e = n;
                      }
                    return e ?? "";
                  });
                })(t, i, s, d).then((e) => {
                  "function" == typeof c &&
                    t.globalContext.removeEventListener(a, c),
                    r(!(e.length < 1) && { value: e, type: s });
                });
            })({
              account: t,
              e: o,
              event: r,
              eventTarget: e,
              isGlobalSubmit: s,
              target: a,
              type: i,
              onDone: n,
              listener: c,
            });
          t.globalContext.addEventListener(r, c);
        };
        if (0 !== a.length)
          return Promise.all(a).then((t) => {
            for (const e of t) if (e.value.length > 0) return void n(e);
            i();
          });
        i();
      },
      ui = { called: !1 };
    const pi = mt([
        Yo,
        ei,
        new pt({
          scope: "ad",
          object: "record",
          action: "rr",
          validators: {
            detail: {
              detail: et,
              "detail.config": et,
              "detail.config.$$typeof": dt,
              "detail.config.tagName": dt,
              "detail.config.@@__IMMUTABLE_ITERABLE__@@": dt,
              "detail.config.@@__IMMUTABLE_RECORD__@@": dt,
              "detail.config.accountID": rt(X),
              "detail.config.overrideLimit": rt(tt),
              "detail.config.methods": ot,
              "detail.config.methods[].tagName": dt,
              "detail.config.methods[]": st(et),
              "detail.config.methods[].$$typeof": dt,
              "detail.config.methods[].@@__IMMUTABLE_ITERABLE__@@": dt,
              "detail.config.methods[].@@__IMMUTABLE_RECORD__@@": dt,
              "detail.config.methods[].type": it(Object.values(Xo)),
              "detail.config.methods[].method": it(Object.values(di)),
              "detail.config.methods[].target": rt(X),
              "detail.config.methods[].event": rt(X),
              "detail.config.methods[].eventTarget": rt(X),
              "detail.config.methods[].isGlobalSubmit": rt(tt),
              "detail.config.methods[].priority": rt(Z),
            },
            context: {
              context: et,
              "context.Promise": ct,
              "context.crypto": et,
              "context.crypto.subtle": ct,
            },
          },
          handler: async ({ account: t, detail: e }) => {
            if (!t.globalContext.apstag?._atsaaiod)
              return { status: s.waiting };
            if (!t.isAllowedToAccessInfoOnDevice())
              throw new Error("Not allowed to access storage on device");
            const n = await (function (t, e) {
              return new Promise((n, a) => {
                if (ui.called && !e.overrideLimit)
                  throw new Error(
                    "rr should only be called once per page load"
                  );
                ui.called = !0;
                let o = 0;
                const i = () => {
                  const s = (() => {
                      const o = t.use(kt);
                      return (
                        (!t.globalContext.apstag?.isGDPRRegion ||
                          void 0 !== o) &&
                        (void 0 === o || t.isAllowedToAccessInfoOnDevice()
                          ? (li(t, e, (e) => {
                              if (!1 === e) return n("no retrieval");
                              Go({
                                account: t,
                                hashedRecords: [
                                  { type: e.type, record: e.value },
                                ],
                                source: "rr",
                                tcString: o?.tcString,
                              })
                                .then(() => {
                                  n("token generated");
                                })
                                .catch(a);
                            })?.catch(a),
                            !0)
                          : "canceled")
                      );
                    })(),
                    r = o > 6400;
                  if (s || r)
                    return (
                      "canceled" === s && a(new Error("tcf timeout")),
                      void (r && a(new Error("interval over")))
                    );
                  setTimeout(i, o), (o = 0 === o ? 200 : 2 * o);
                };
                i();
              });
            })(t, e.config);
            return { status: s.completed, analytics: { rr: n } };
          },
        }),
        new pt({
          scope: "ad",
          object: "record",
          action: "update",
          validators: { detail: Zo, context: { context: et } },
          handler: async ({ account: t, detail: e }) => {
            if (!t.globalContext.apstag?._atsaaiod)
              return { status: s.waiting };
            if (!t.isAllowedToAccessInfoOnDevice())
              throw new Error("Not allowed to access storage on device");
            const n = t.globalContext.apstag.isGDPRRegion,
              a = t.use(kt);
            return (
              e.config.optOut
                ? Ho(t)
                : await Go({
                    account: t,
                    hashedRecords: e.config.hashedRecords,
                    ttl: e.config.ttl,
                    isGDPRRegion: n,
                    tcString: a?.tcString,
                    setToken: e?.setCookie,
                  }),
              { status: s.completed }
            );
          },
        }),
      ]),
      mi = new Map([
        [
          "ad/ASRSlot/render",
          async ({ account: t, customEvent: e }) => {
            if (void 0 === e.detail?.id || void 0 === e.detail?.targeting)
              throw new Error("Missing event detail");
            return (
              ((t, e, n, a) => {
                const o = n.globalContext.document.createElement("iframe"),
                  i = e.get("amznsz")?.split("x"),
                  s = e.get("amzniid"),
                  r = t;
                if (
                  void 0 === s ||
                  void 0 === r ||
                  void 0 === i ||
                  i.length < 2
                )
                  return;
                (o.style.marginLeft = "0"),
                  (o.style.marginTop = "0"),
                  (o.style.height = `${i[1]}px`),
                  (o.style.width = "100%"),
                  o.setAttribute("scrolling", "no"),
                  o.setAttribute("frameborder", "0");
                const c = n.globalContext.document.createElement("div"),
                  d = a?.location ?? "afterend",
                  l = n.globalContext.document.getElementById(r);
                if (null == l) return;
                l.insertAdjacentElement(d, c), c.appendChild(o);
                const u = o?.contentWindow?.document;
                void 0 !== u &&
                  (u.open(),
                  u.write(
                    '<!DOCTYPE html><html><head><meta charset="UTF-8"><style>html{height:100%}body{height:100%;margin:0;overflow:hidden}</style></head><body><script>window.parent.apstag.renderImp(document, "' +
                      s +
                      '", {"inheritSize": true});</script></body></html>'
                  ),
                  u.close());
              })(e.detail.id, e.detail.targeting, t),
              s.completed
            );
          },
        ],
      ]);
    async function fi(t) {
      try {
        const e = await crypto.subtle.importKey(
            "jwk",
            {
              alg: "A128CTR",
              ext: !0,
              k: "ERTYQsuodPO_Um-5jFmOLg",
              key_ops: ["encrypt"],
              kty: "oct",
            },
            "AES-CTR",
            !0,
            ["encrypt"]
          ),
          n = new TextEncoder().encode(t),
          a = new Uint8Array(
            await crypto.subtle.encrypt(
              { name: "AES-CTR", counter: new Uint8Array(16), length: 128 },
              e,
              n
            )
          );
        return btoa(String.fromCharCode(...a));
      } catch (t) {
        return null;
      }
    }
    const hi = "google/secureSignals/initialize",
      vi = new Map([
        [
          "google/secureSignals/set",
          async ({ account: t, customEvent: e }) => (
            void 0 === t.globalContext.googletag &&
              (t.globalContext.googletag = {}),
            void 0 === t.globalContext.googletag.secureSignalProviders &&
              (t.globalContext.googletag.secureSignalProviders = []),
            t.globalContext.googletag.secureSignalProviders.push({
              networkCode: "amazon.com",
              collectorFunction: async () => {
                const { encryptedSignal: e } = await t.record(hi);
                return e;
              },
            }),
            s.completed
          ),
        ],
        [
          hi,
          async ({ account: t, customEvent: e }) => {
            const n = t.globalContext.apstag?._getSlotIdToNameMapping;
            let a;
            if (void 0 === n) return { status: s.waiting };
            if (((a = n()), 0 === Object.keys(a).length))
              return { status: s.waiting };
            let o = t.globalContext.location?.href;
            void 0 === o && (o = "");
            const i = `${o};${JSON.stringify(a)}`.substr(0, 225);
            return {
              status: s.completed,
              value: { encryptedSignal: await fi(i) },
            };
          },
        ],
      ]);
    var gi;
    !(function (t) {
      (t.Googletag = "googletag"), (t.AppNexus = "appnexus"), (t.SAS = "sas");
    })(gi || (gi = {}));
    const yi = [
        "187",
        "189",
        "306",
        "312",
        "313",
        "314",
        "317",
        "318",
        "290",
        "291",
        "292",
        "293",
        "294",
        "296",
        "297",
        "300",
        "301",
        "302",
        "303",
        "304",
        "305",
        "307",
        "308",
        "310",
        "311",
        "405",
        "454",
        "456",
        "457",
        "458",
        "459",
        "460",
        "461",
        "462",
        "463",
      ],
      wi = [
        "Rm3SiT",
        "Z7rJBM",
        "HxqYV1",
        "pg0WhF",
        "j9PaO9",
        "mm3UXx",
        "6i4dB6",
        "8FD8nI",
      ],
      bi = {
        3: [
          ...[
            "4-10",
            "5-14",
            "6-1",
            "7-6",
            "7-7",
            "6-7",
            "6-8",
            "7-2",
            "7-3",
            "7-8",
            "7-9",
            "7-10",
            "7-11",
            "7-12",
            "7-13",
            "7-14",
            "7-16",
            "7-18",
            "7-20",
            "7-21",
            "7-22",
            "7-23",
            "7-27",
            "7-28",
            "7-29",
            "7-30",
            "7-34",
            "7-36",
            "7-37",
            "7-39",
            "7-40",
            "7-41",
            "7-42",
            "7-43",
            "7-44",
            "13-2",
            "14-2",
            "14-3",
            "14-8",
            "15-1",
            "23-1",
            "23-2",
            "23-3",
            "23-4",
            "23-5",
            "23-6",
            "23-7",
            "23-8",
            "23-9",
            "23-10",
            "25",
            "25-1",
            "25-2",
            "25-3",
            "25-4",
            "25-5",
            "25-6",
            "25-7",
            "26",
            "26-1",
            "26-2",
            "26-3",
            "26-4",
          ].map((t) => `IAB${t}`),
        ],
        4: [...yi],
        5: [...yi],
        6: [...yi, ...wi],
        7: [...yi, ...wi],
      },
      xi = {
        site: {
          id: "id",
          name: "name",
          domain: "domain",
          cattax: 1,
          cat: ["1"],
          sectioncat: ["first", "second"],
          pagecat: ["first", "second"],
          page: "page",
          ref: "ref",
          search: "search",
          mobile: 1,
          privacypolicy: 1,
          publisher: {
            id: "id",
            name: "name",
            cattax: 1,
            cat: ["1"],
            domain: "domain",
            ext: {},
          },
          content: {
            id: "id",
            episode: 1,
            title: "title",
            series: "series",
            season: "season",
            artist: "artist",
            genre: "genre",
            album: "album",
            isrc: "isrc",
            producer: {
              id: "id",
              name: "name",
              cattax: 1,
              cat: ["1"],
              domain: "domain",
              ext: {},
            },
            url: "url",
            cattax: 1,
            cat: ["1"],
            prodq: 1,
            context: 1,
            contentrating: "contentrating",
            userrating: "userrating",
            qagmediarating: 1,
            keywords: "first, second",
            kwarray: ["first", "second"],
            livestream: 1,
            sourcerelationship: 1,
            len: 1,
            language: "language",
            langb: "langb",
            embeddable: 1,
            data: [
              {
                id: "id",
                name: "name",
                segment: [{ id: "id", name: "name", value: "value", ext: {} }],
                ext: {},
              },
            ],
            network: { id: "id", name: "name", domain: "domain", ext: {} },
            channel: { id: "id", name: "name", domain: "domain", ext: {} },
            ext: {},
          },
          keywords: "first, second",
          kwarray: ["first", "second"],
          ext: {},
        },
      },
      Ei = (t, e) =>
        Object.keys(t).reduce((n, a) => {
          const o = a;
          if (void 0 !== e?.[o]) {
            const a = t[o];
            "object" == typeof (i = a) &&
            !Array.isArray(i) &&
            Object.keys(i).length > 0
              ? (n[o] = Ei(a, e[o]))
              : (n[o] = ((t, e) => {
                  const n = e.cattax,
                    a = e[t];
                  return (bi[n] ?? []).length > 0 &&
                    ("cat" === t ||
                      "sectcat" === t ||
                      "sectioncat" === t ||
                      "pagecat" === t) &&
                    Array.isArray(a)
                    ? a.filter((t) => !bi[n].includes(`${t}`))
                    : a;
                })(o, e));
          }
          var i;
          return n;
        }, {});
    function Si(t) {
      return (
        (t.get = function (...t) {
          const e = Map.prototype.get.apply(this, t);
          return Map.prototype.delete.apply(this, t), e;
        }),
        t
      );
    }
    const _i = { key: "ad/targeting", default: new Map(), postProcessor: Si };
    var Ri = new pt({
      scope: "ad",
      object: "targeting",
      action: "attach",
      validators: {
        detail: {
          detail: et,
          "detail.itemIds": rt(ot),
          "detail.itemIds[]": X,
          "detail.adServer": it(Object.values(gi)),
        },
        context: { context: et, ...Pn },
      },
      handler: async ({ account: t, detail: e, context: n }) => {
        const a = { pubID: t.id };
        return (
          n.apstag.setDisplayBids(e.itemIds, {
            initConfig: a,
            adServer: e.adServer,
          }),
          Ii(t, { itemIds: e.itemIds }),
          { status: s.completed }
        );
      },
    });
    const Ii = (t, e) => {
        e.itemIds
          ? e.itemIds.forEach((e) => {
              t.update(_i, (t) => (t.delete(e), t));
            })
          : t.update(_i, (t) => (t.clear(), t));
      },
      Ai = { key: "ad/slots", default: new Map() },
      ki = { key: "cxm/isConfigLoadInitiated", default: !1 },
      ji = (t) => {
        const e = new Map(),
          n = (t) => {
            e.set(JSON.stringify(t), t);
          };
        return (
          t.w && t.h && n([t.w, t.h]),
          t.format?.forEach((t) => {
            t.w && t.h && n([t.w, t.h]);
          }),
          e.size > 0 ? Array.from(e.values()) : void 0
        );
      },
      $i = (t) => {
        if (t.bidfloor) {
          if (void 0 !== t.bidfloorcur && "USD" !== t.bidfloorcur)
            throw new Error(
              'imp.bidfloorcur: only "USD" is currently supported'
            );
          return { value: t.bidfloor, currency: "USD" };
        }
      },
      Ci = (t, e) => {
        const n = {};
        return (
          Object.keys(t).forEach((a) => {
            "object" == typeof t[a] &&
              null !== t[a] &&
              (a === e
                ? Object.assign(n, t[a])
                : Object.assign(n, Ci(t[a], e)));
          }),
          n
        );
      },
      Oi = (t) => {
        const e = Ci(t, "ext");
        return (
          Object.entries(e).forEach(([t, n]) => {
            "string" != typeof n && (e[t] = JSON.stringify(n));
          }),
          0 !== Object.keys(e).length ? e : void 0
        );
      },
      Pi = "ad/targeting/fetch",
      Di = "ad/signals/define",
      Ti = "cxm/config/load",
      Ni = new Map([
        [
          "ad_slot_import",
          async ({ account: t, customEvent: e }) => {
            if (void 0 === e.detail?.adServer)
              throw new Error("adServer: a valid value must be provided");
            if (e.detail.adServer === gi.Googletag)
              return t.write("ad/googletagSlotAutoImport", !0), s.completed;
            throw new Error(
              "adServer: value provided isn't currently supported"
            );
          },
        ],
        [
          "ad/schain/define",
          async ({ account: t, customEvent: e }) => {
            if (void 0 === e.detail?.schain)
              throw new Error("Missing schain object");
            return t.write("ad/schain", e.detail.schain), s.completed;
          },
        ],
        [
          Pi,
          async ({ account: e, customEvent: n }) => {
            if (
              void 0 === e.globalContext.apstag ||
              void 0 === e.globalContext.apstag.clientFetchBids
            )
              return s.waiting;
            const a = e.use(Nn);
            void 0 === a &&
              e
                .record("idVendors/legacy/didExecuteFirst", {
                  analytics: {
                    context: "ad_targeting_fetch",
                    timing: "legacy-first",
                  },
                })
                .catch(() => {}),
              !0 !== a &&
                (function (t) {
                  t.use(ki) ||
                    (t.update(ki, () => !0), t.record(Ti).catch((t) => {}));
                })(e),
              (function (e) {
                (function (e) {
                  if (
                    (function (t) {
                      for (const e of t.queue)
                        if (e.type === po && e.status === s.waiting) return !0;
                      return !1;
                    })(e)
                  )
                    return !1;
                  return void 0 !== e.read(t, { persist: !0 });
                })(e) && e.record(po).catch((t) => {});
              })(e);
            const o = (function (t) {
                return Array.from(t.use(Ai).values());
              })(e),
              i = (function (t, e) {
                let n = t;
                return (
                  void 0 !== e &&
                    e.length > 0 &&
                    (n = t.filter((t) => e.includes(t.id))),
                  n
                );
              })(o, n.detail?.itemIds),
              r = n.detail?.publisherParams,
              c = n.detail?.tid,
              d = n.detail?.tidBySlotId;
            return (
              await (async function ({
                account: t,
                selectedSlots: e,
                publisherParams: n,
                timeout: a,
                _endpointDomain: o,
                tid: i,
                tidBySlotId: s,
                initConfig: r,
              }) {
                const c = (function (t) {
                  return t.map((t) =>
                    ((t) => {
                      const e = {
                        slotID: t.id,
                        slotName: t.tagid,
                        floor: $i({
                          bidfloor: t.bidfloor,
                          bidfloorcur: t.bidfloorcur,
                        }),
                        slotParams: Oi(t),
                      };
                      if (t.banner && t.video) {
                        e.mediaType = ti.MultiFormat;
                        const n = ji({ w: t.video.w, h: t.video.h }),
                          a = ji({
                            w: t.banner.w,
                            h: t.banner.h,
                            format: t.banner.format,
                          });
                        a &&
                          (e.multiFormatProperties = {
                            ...e.multiFormatProperties,
                            display: { sizes: a },
                          }),
                          n &&
                            (e.multiFormatProperties = {
                              ...e.multiFormatProperties,
                              video: { sizes: n },
                            });
                      } else
                        t.video
                          ? ((e.mediaType = ti.Video),
                            (e.sizes = ji({ w: t.video.w, h: t.video.h })))
                          : t.banner &&
                            ((e.mediaType = ti.Display),
                            (e.sizes = ji({
                              w: t.banner.w,
                              h: t.banner.h,
                              format: t.banner.format,
                            })));
                      return (
                        t.video?.companionad &&
                          ((e.companions = []),
                          t.video.companionad.forEach((t) => {
                            t.id && e.companions?.push(t.id);
                          })),
                        e
                      );
                    })(t)
                  );
                })(e);
                return (
                  ((t, e) => {
                    e &&
                      t.forEach((t) => {
                        const n = e[t.slotID];
                        n && (t.tid = n);
                      });
                  })(c, s),
                  await (async function ({
                    account: t,
                    legacySlots: e,
                    publisherParams: n,
                    timeout: a,
                    _endpointDomain: o,
                    tid: i,
                    initConfig: s,
                  }) {
                    return await new Promise((r) => {
                      if (void 0 === t.globalContext.apstag)
                        throw new Error("apstag undefined in global scope");
                      t.globalContext.apstag.clientFetchBids(
                        {
                          slots: e,
                          params: n,
                          timeout: a ?? 6e4,
                          _endpointDomain: o,
                          tid: i,
                        },
                        (t) => {
                          r(t);
                        },
                        { initConfig: s }
                      );
                    });
                  })({
                    account: t,
                    legacySlots: c,
                    publisherParams: n,
                    timeout: a,
                    _endpointDomain: o,
                    tid: i,
                    initConfig: r,
                  })
                );
              })({
                account: e,
                selectedSlots: i,
                publisherParams: r,
                timeout: n.detail?.timeout,
                _endpointDomain: n.detail?._endpointDomain,
                tid: c,
                tidBySlotId: d,
                initConfig: {
                  pubID: e.id,
                  isSelfServePub: 36 === e.id.length,
                  deals: !0,
                },
              }),
              s.completed
            );
          },
        ],
        [
          Di,
          async ({ account: t, customEvent: e }) => {
            if (void 0 === e.detail || !("context" in e.detail))
              throw new Error("Missing detail object");
            const n =
              null != e.detail.context
                ? Ei(xi, e.detail.context)
                : e.detail.context;
            return t.update(xe, () => n), s.completed;
          },
        ],
        [
          Ti,
          async ({ account: t, customEvent: e }) => {
            if (void 0 === t.globalContext.apstag?._load3PLibraryConfig)
              return s.waiting;
            let n,
              a = t.id;
            return (
              36 === t.id.length && ((a = "600"), (n = t.id)),
              await new Promise((e, o) => {
                if (void 0 === t.globalContext.apstag?._load3PLibraryConfig)
                  throw new Error("apstag._load3PLibraryConfig is undefined");
                t.globalContext.apstag._load3PLibraryConfig(
                  t.id,
                  { sourceID: a, publisherUUID: n },
                  e,
                  o
                );
              }),
              s.completed
            );
          },
        ],
      ]),
      Li = new Map([...Ni, ...mt([Ri])]),
      Mi = "widget/toolbox/open",
      Ui = "widget/toolbox/start",
      qi = new Map([
        [
          "widget/toolbox/end",
          async ({ account: t }) => (
            t.record(lo, { eventName: Ui }).catch((t) => {}), s.completed
          ),
        ],
        [
          Mi,
          async ({ account: t, customEvent: e }) => (
            (function (t, e) {
              const n = e.globalContext.document.createElement("script");
              (n.src = "https://c.toolbox.aps.amazon-adsystem.com/toolbox.js"),
                (n.async = !0),
                e.globalContext.document.head.appendChild(n);
            })(0, t),
            s.completed
          ),
        ],
        [
          Ui,
          async ({ account: t, customEvent: e }) => (
            t.record(co, { eventName: e.type }).catch((t) => {}),
            t.record(Mi).catch((t) => {}),
            s.completed
          ),
        ],
      ]),
      Vi = "_config/events/activations",
      Fi = "_config/events/deactivations",
      Bi = new Map([
        [
          "_config/events/activate",
          async ({ customEvent: t, account: e }) => {
            const n = null != e.store.get(Vi) ? e.store.get(Vi) : new Set();
            return n.add(t.detail.name), e.store.set(Vi, n), s.completed;
          },
        ],
        [
          "_config/events/deactivate",
          async ({ customEvent: t, account: e }) => {
            const n = null != e.store.get(Fi) ? e.store.get(Fi) : new Set();
            return n.add(t.detail.name), e.store.set(Fi, n), s.completed;
          },
        ],
      ]),
      zi = { key: "sessionMarker/marker", default: void 0 },
      Ji = new Map([
        [
          "sessionMarker/marker/sync",
          async ({ account: t }) =>
            "object" != typeof t.globalContext.crypto ||
            "function" != typeof t.globalContext.crypto.randomUUID
              ? s.cancelled
              : (((t) => {
                  const e = t.use(zi, { persist: !0 });
                  if (0 === (e ?? "").length) return !1;
                  const n = e?.split("_")[1] ?? "";
                  if (0 === n.length) return !1;
                  const a = new Date(n);
                  return !(new Date().valueOf() - a.valueOf() >= 2592e6);
                })(t) ||
                  (((t) => {
                    t.delete(zi.key, { persist: !0 });
                  })(t),
                  ((t) => {
                    const e = t.globalContext.crypto.randomUUID();
                    if (36 !== e.length)
                      throw new Error(`Invalid PEID generated: ${e}`);
                    const n = `${e}_${new Date().toISOString()}`;
                    t.update(zi, () => n, { persist: !0 });
                  })(t)),
                ((t) => {
                  const e = t.use(zi, { persist: !0 });
                  t.update(zi, () => e);
                })(t),
                s.completed),
        ],
      ]);
    var Hi = new pt({
        scope: "legacy",
        object: "rpa",
        action: "enqueue",
        validators: {
          detail: {
            detail: et,
            "detail.tokenConfig": null,
            "detail.callback": null,
            "detail.setCookie": rt(tt),
          },
        },
        handler: async ({ account: t, detail: e }) =>
          void 0 === t.globalContext.apstag?.rpa ||
          void 0 === t.globalContext.apstag?.debug
            ? { status: s.waiting }
            : (t.globalContext.apstag.rpa(
                e.tokenConfig,
                e.callback,
                e.setCookie,
                t.id
              ),
              { status: s.completed }),
      }),
      Gi = new pt({
        scope: "legacy",
        object: "dpa",
        action: "enqueue",
        validators: { detail: { detail: et, "detail.callback": null } },
        handler: async ({ account: t, detail: e }) =>
          void 0 === t.globalContext.apstag?.dpa ||
          void 0 === t.globalContext.apstag?.debug
            ? { status: s.waiting }
            : (t.globalContext.apstag.dpa(e.callback), { status: s.completed }),
      }),
      Ki = new pt({
        scope: "legacy",
        object: "upa",
        action: "enqueue",
        validators: {
          detail: {
            detail: et,
            "detail.tokenConfig": null,
            "detail.callback": null,
            "detail.setCookie": rt(tt),
          },
        },
        handler: async ({ account: t, detail: e }) =>
          void 0 === t.globalContext.apstag?.upa ||
          void 0 === t.globalContext.apstag?.debug
            ? { status: s.waiting }
            : (t.globalContext.apstag.upa(
                e.tokenConfig,
                e.callback,
                e.setCookie,
                "bootstrap",
                t.id
              ),
              { status: s.completed }),
      }),
      Wi = new pt({
        scope: "legacy",
        object: "queue",
        action: "push",
        validators: { detail: { detail: et, "detail.callback": null } },
        handler: async ({ detail: t }) => (
          void 0 !== t.callback && null !== t.callback && t.callback(),
          { status: s.completed }
        ),
      });
    const Qi = new Map([
        [
          "legacy/init/enqueue",
          async ({ account: t, customEvent: e }) =>
            void 0 === t.globalContext.apstag?.init ||
            void 0 === t.globalContext.apstag?.debug
              ? s.waiting
              : (t.globalContext.apstag.init(
                  e.detail?.config,
                  e.detail?.callback
                ),
                s.completed),
        ],
        [
          "legacy/fetchBids/enqueue",
          async ({ account: t, customEvent: e }) =>
            void 0 === t.globalContext.apstag?.fetchBids ||
            void 0 === t.globalContext.apstag?.debug
              ? s.waiting
              : (t.globalContext.apstag.fetchBids(
                  e.detail?.bidConfig,
                  e.detail?.callback
                ),
                s.completed),
        ],
      ]),
      Yi = new Map([...Qi, ...mt([Ki, Gi, Hi, Wi])]),
      Zi = { key: "a3pes/isDeactivated", default: !1 };
    var Xi = new pt({
      scope: "adExchange",
      object: "a3pes",
      action: "deactivate",
      validators: { detail: { detail: et }, context: { context: et } },
      handler: async ({ account: t }) => (
        t.update(Zi, () => !0), { status: s.completed }
      ),
    });
    const ts = { key: "ad/attachTargeting", default: void 0 };
    var es = new pt({
      scope: "bidResponse",
      object: "targeting",
      action: "save",
      validators: {
        detail: {
          detail: et,
          "detail.aaxResp": et,
          "detail.aaxResp.cb": rt(X),
          "detail.aaxResp.slots": rt(ot),
          "detail.aaxResp.host": rt(X),
          "detail.aaxResp.slots[]": lt,
        },
      },
      handler: async ({ account: t, detail: e }) => {
        const n = e.aaxResp;
        return (
          (function (t, e) {
            t.update(
              _i,
              (t) => (
                (function (t, e) {
                  e?.slots?.forEach((e) => {
                    t.set(e.slotID, new Map());
                  });
                })(t, e),
                (function (t, e) {
                  e?.slots?.forEach((n) => {
                    n.targeting.forEach((e) => {
                      Map.prototype.get.apply(t, [n.slotID]).set(e, n[e]);
                    }),
                      e.host &&
                        Map.prototype.get
                          .apply(t, [n.slotID])
                          .set("amznhost", e.host);
                  });
                })(t, e),
                t
              )
            );
          })(t, n),
          (function (t) {
            const e = ({ adServer: e, itemIds: n }) => {
              t.recordListenerNonBlocking(Ri, { itemIds: n, adServer: e });
            };
            t.update(ts, () => e);
          })(t),
          n.slots ? { status: s.completed } : { status: s.cancelled }
        );
      },
    });
    const ns = {
        key: "a3pes/bidURL",
        default: "https://web-banner.ads.aps.amazon-adsystem.com/e/dtb/bid",
      },
      as = {
        key: "a3pes/videoBidURL",
        default: "https://web-video.ads.aps.amazon-adsystem.com/e/dtb/bid",
      },
      os = { key: "a3pes/mockBidder", default: void 0 };
    var is,
      ss = new pt({
        scope: "adExchange",
        object: "a3pes",
        action: "fetch",
        validators: {
          detail: {
            detail: et,
            "detail.requestBody": X,
            "detail.isBannerOnly": rt(tt),
          },
          context: {
            context: et,
            "context.fetch": ct,
            "context.fetch()": et,
            "context.fetch().ok": tt,
            "context.fetch().then": ct,
            "context.fetch().then()": lt,
            ...Pn,
          },
        },
        handler: async ({ account: t, context: e, detail: n }) => {
          const a = !0 === n.isBannerOnly;
          let o = a ? t.use(ns) : t.use(as);
          if (j()) {
            const e = t.use(os);
            if (void 0 !== e) {
              const t = new URL(o);
              t.searchParams.set("mockBidderIds", e.id),
                t.searchParams.set("mockBidderUrls", e.url),
                (o = t.toString());
            }
          }
          const i = await e.fetch(o, {
            method: "POST",
            credentials: "include",
            body: n.requestBody,
          });
          if (!i.ok) throw new Error(`Fetch failed with status: ${i.status}`);
          const r = i.status,
            c = i.statusText,
            d = i.type,
            l = await i.json(),
            { contextual: u } = l;
          if (!u) throw new Error("Bid response missing contextual object");
          return (
            t.recordListenerNonBlocking(es, { aaxResp: u }),
            e.apstag.bids(u),
            {
              status: s.completed,
              value: { slotCount: u.slots?.length ?? 0 },
              analytics: {
                statusCode: r,
                statusText: c,
                responseType: d,
                isBannerOnly: a,
              },
            }
          );
        },
      });
    !(function (t) {
      (t.DISPLAY = "d"), (t.VIDEO = "v"), (t.MULTI_FORMAT = "mf");
    })(is || (is = {}));
    const rs = (t) =>
        (void 0 === t.mt || t.mt === is.DISPLAY) && void 0 === t.native,
      cs = (t) => t.mt === is.VIDEO,
      ds = (t) => t.mt === is.MULTI_FORMAT,
      ls = (t) =>
        ds(t) ? is.MULTI_FORMAT : cs(t) ? is.VIDEO : rs(t) ? is.DISPLAY : null,
      us = (t) => t.sd || t.id,
      ps = "primary",
      ms = "canary",
      fs = ps;
    function hs(t, e, n = !1) {
      if ("object" == typeof t.aps_prebid && null !== t.aps_prebid) {
        if ("object" == typeof t.aps_prebid[e] && null !== t.aps_prebid[e])
          return t.aps_prebid[e];
        if (n) return (t.aps_prebid[e] = {}), t.aps_prebid[e];
      } else if (n)
        return (t.aps_prebid = {}), (t.aps_prebid[e] = {}), t.aps_prebid[e];
      return null;
    }
    function vs(t, e, n) {
      const a = t(`aps_prebid_${e}`);
      if (a)
        try {
          return JSON.parse(a);
        } catch (t) {
          n.push(
            `Failed to parse stored configuration for account '${e}': ${t}`
          );
        }
      return null;
    }
    function gs(t) {
      const e = Number(t);
      return isNaN(e) || e < 0 || e > 1 ? null : e;
    }
    function ys(t, e, n) {
      const a = hs(t, e);
      return a && a.currentRoles ? a.currentRoles[n] : void 0;
    }
    function ws(t, e, n, a, o) {
      if (a === ps) return !0;
      if (a === ms) {
        const a = (function (t, e, n, a) {
          const o = hs(t, e);
          if (
            o &&
            ("number" == typeof o.canaryRate || "string" == typeof o.canaryRate)
          ) {
            const t = gs(o.canaryRate);
            if (null !== t) return t;
          }
          const i = vs(n, e, a);
          if (
            i &&
            ("number" == typeof i.canaryRate || "string" == typeof i.canaryRate)
          ) {
            const t = gs(i.canaryRate);
            if (null !== t) return t;
          }
          return 0.02;
        })(t, e, n, o);
        return Math.random() < a;
      }
      return !1;
    }
    function bs({
      context: t,
      accountID: e,
      readFromStorage: n,
      currentLibrary: a = "webclient",
      otherLibrary: o = "prebid",
    }) {
      const i = [],
        s = (function (t, e, n, a, o, i) {
          const s = ys(t, e, a),
            r = (function (t, e, n, a, o) {
              const i = hs(t, e);
              if (
                i &&
                i.roleInstructions &&
                "string" == typeof i.roleInstructions[a]
              )
                return i.roleInstructions[a];
              const s = vs(n, e, o);
              return s &&
                s.roleInstructions &&
                "string" == typeof s.roleInstructions[a]
                ? s.roleInstructions[a]
                : fs;
            })(t, e, n, a, i);
          return s && s === ps && r === ms ? (ys(t, e, o) === ps ? ms : ps) : r;
        })(t, e, n, a, o, i);
      return (
        (function (t, e, n, a) {
          const o = hs(t, e, !0);
          (o.currentRoles = o.currentRoles || {}), (o.currentRoles[n] = a);
        })(t, e, a, s),
        { isValid: ws(t, e, n, s, i), errors: i }
      );
    }
    const xs = { key: "pathSelection/isPathBlocked", default: !1 };
    var Es = new pt({
      scope: "pathSelection",
      object: "path",
      action: "evaluate",
      validators: { context: { context: lt } },
      handler: async ({ account: t, context: e }) => {
        const n = bs({
            context: e,
            accountID: t.id,
            readFromStorage: (e) =>
              t.readLocalStorage(e, { throwOnDisallowed: !1 }),
          }),
          a = !n.isValid;
        return (
          t.update(xs, () => a),
          {
            status: s.completed,
            analytics: { isPathBlocked: a, errors: n.errors },
          }
        );
      },
    });
    const Ss = { key: "bidURL/pj", default: new Map(), postProcessor: Si };
    var _s = new pt({
      scope: "bidURL",
      object: "pj",
      action: "update",
      validators: {
        detail: { detail: et, "detail.bidRequestIndex": X, "detail.pj": rt(X) },
      },
      handler: async ({ account: t, detail: e }) => {
        let n = {};
        if (
          (void 0 !== e.pj && (n = JSON.parse(e.pj)),
          "object" != typeof n || Array.isArray(n))
        )
          throw new Error(`Unexpected value for search param pj: ${n}`);
        const a = t.use(Ja),
          o = { rtisAdded: !1 };
        return (
          a &&
            ((n = { ...n, apsRtisLiveRampCookieSync: a }), (o.rtisAdded = !0)),
          Object.keys(n).length > 0 &&
            t.update(Ss, (t) => t.set(e.bidRequestIndex, n)),
          { status: s.completed, analytics: o }
        );
      },
    });
    const Rs = { key: "bidURL/slots", default: new Map(), postProcessor: Si },
      Is = { key: "adExchangeBidRequests/slotIDs", default: new Set() };
    var As, ks, js, $s;
    !(function (t) {
      (t[(t.Sponsored = 1)] = "Sponsored"),
        (t[(t.Desc = 2)] = "Desc"),
        (t[(t.Rating = 3)] = "Rating"),
        (t[(t.Likes = 4)] = "Likes"),
        (t[(t.Downloads = 5)] = "Downloads"),
        (t[(t.Price = 6)] = "Price"),
        (t[(t.SalePrice = 7)] = "SalePrice"),
        (t[(t.Phone = 8)] = "Phone"),
        (t[(t.Address = 9)] = "Address"),
        (t[(t.Desc2 = 10)] = "Desc2"),
        (t[(t.DisplayUrl = 11)] = "DisplayUrl"),
        (t[(t.CTAText = 12)] = "CTAText"),
        (t[(t.AmazonDealBadge = 507)] = "AmazonDealBadge"),
        (t[(t.AmazonCustomerReview = 508)] = "AmazonCustomerReview"),
        (t[(t.AmazonClimatePledge = 511)] = "AmazonClimatePledge"),
        (t[(t.AmazonCoupon = 512)] = "AmazonCoupon");
    })(As || (As = {})),
      (function (t) {
        (t[(t.Img = 1)] = "Img"), (t[(t.JS = 2)] = "JS");
      })(ks || (ks = {})),
      (function (t) {
        (t[(t.Impression = 1)] = "Impression"),
          (t[(t.ViewableMRC50 = 2)] = "ViewableMRC50"),
          (t[(t.ViewableMRC100 = 3)] = "ViewableMRC100"),
          (t[(t.ViewableVideo50 = 4)] = "ViewableVideo50");
      })(js || (js = {})),
      (function (t) {
        (t[(t.Icon = 1)] = "Icon"),
          (t[(t.Main = 3)] = "Main"),
          (t[(t.AmazonPrimeLogo = 512)] = "AmazonPrimeLogo"),
          (t[(t.AmazonBrandingLogo = 513)] = "AmazonBrandingLogo");
      })($s || ($s = {}));
    const Cs = (t, e) => t.some((t) => t.event === e),
      Os = { key: "gpid/activation", default: !0 },
      Ps = { key: "gpid/optOut", default: !1 },
      Ds = { key: "gpid/cache", default: new Map() },
      Ts = { key: "gpid/delimiter", default: "#" },
      Ns = {
        context: et,
        "context.googletag": rt(et),
        "context.googletag.pubads": rt(ct),
        "context.googletag.pubads()": rt(et),
        "context.googletag.pubads().getSlots": rt(ct),
        "context.googletag.pubads().getSlots()": rt(ot),
        "context.googletag.pubads().getSlots()[]": rt(et),
        "context.googletag.pubads().getSlots()[].getAdUnitPath": rt(ct),
        "context.googletag.pubads().getSlots()[].getSlotElementId": rt(ct),
        "context.googletag.pubads().getSlots()[].getAdUnitPath()": rt(X),
        "context.googletag.pubads().getSlots()[].getSlotElementId()": rt(X),
      };
    var Ls = new pt({
      scope: "gpid",
      object: "generation",
      action: "attempt",
      validators: {
        detail: { detail: et, "detail.slotIds": ot, "detail.slotIds[]": X },
        context: Ns,
      },
      handler: async ({ account: t, detail: e, context: n }) => {
        const a = t.use(Os),
          o = t.use(Ps);
        if (!a || o) return { status: s.cancelled };
        const i = n.googletag?.pubads?.()?.getSlots;
        if (!i) return { status: s.cancelled };
        const r = t.use(Ts),
          c = t.use(Ds),
          d = i();
        return (
          e.slotIds.forEach((e) => {
            if (c.has(e)) return;
            const n = d.filter(
              (t) => t.getSlotElementId() === e || t.getAdUnitPath().includes(e)
            );
            if (0 === n.length) return;
            const a = n[0].getAdUnitPath();
            let o;
            if (1 === d.filter((t) => t.getAdUnitPath() === a).length) o = a;
            else {
              const t = n[0].getSlotElementId();
              o = `${a}${r}${t}`;
            }
            t.update(Ds, (t) => (t.set(e, o), t));
          }),
          { status: s.completed }
        );
      },
    });
    const Ms = { context: et };
    var Us = new pt({
      scope: "gpid",
      object: "slots",
      action: "enhance",
      validators: {
        detail: {
          detail: et,
          "detail.slots": ot,
          "detail.slots[]": st(et),
          "detail.slots[].id": rt(X),
          "detail.slots[].sd": rt(X),
          "detail.slots[].ext": rt(st(et)),
          "detail.slots[].ext.gpid": st(rt(X)),
        },
        context: Ms,
      },
      handler: async ({ account: t, detail: e }) => {
        const n = t.use(Os),
          a = t.use(Ps);
        if (!n || a) return { status: s.cancelled };
        const o = t.use(Ds),
          i = [];
        e.slots.forEach((t) => {
          const e = t.id || t.sd;
          e && (o.has(e) || i.push(e));
        }),
          i.length > 0 && t.recordListenerNonBlocking(Ls, { slotIds: i });
        const r = t.use(Ds);
        return (
          e.slots.forEach((t) => {
            const e = t.id || t.sd;
            if (!e) return;
            const n = r.get(e);
            n && (t.ext || (t.ext = {}), (t.ext.gpid = n));
          }),
          { status: s.completed }
        );
      },
    });
    const qs = { key: "gpid/mapping", default: {} };
    var Vs,
      Fs,
      Bs,
      zs,
      Js,
      Hs,
      Gs,
      Ks,
      Ws,
      Qs,
      Ys,
      Zs,
      Xs,
      tr,
      er,
      nr,
      ar,
      or,
      ir,
      sr;
    !(function (t) {
      (t[(t.VPAID_1_0 = 1)] = "VPAID_1_0"),
        (t[(t.VPAID_2_0 = 2)] = "VPAID_2_0"),
        (t[(t.MRAID_1_0 = 3)] = "MRAID_1_0"),
        (t[(t.ORMMA = 4)] = "ORMMA"),
        (t[(t.MRAID_2_0 = 5)] = "MRAID_2_0"),
        (t[(t.MRAID_3_0 = 6)] = "MRAID_3_0"),
        (t[(t.OMID_1_0 = 7)] = "OMID_1_0"),
        (t[(t.SIMID_1_0 = 8)] = "SIMID_1_0"),
        (t[(t.SIMID_1_1 = 9)] = "SIMID_1_1");
    })(Vs || (Vs = {})),
      (function (t) {
        (t[(t.VAST_1_0 = 1)] = "VAST_1_0"),
          (t[(t.VAST_2_0 = 2)] = "VAST_2_0"),
          (t[(t.VAST_3_0 = 3)] = "VAST_3_0"),
          (t[(t.VAST_1_0_WRAPPER = 4)] = "VAST_1_0_WRAPPER"),
          (t[(t.VAST_2_0_WRAPPER = 5)] = "VAST_2_0_WRAPPER"),
          (t[(t.VAST_3_0_WRAPPER = 6)] = "VAST_3_0_WRAPPER"),
          (t[(t.VAST_4_0 = 7)] = "VAST_4_0"),
          (t[(t.VAST_4_0_WRAPPER = 8)] = "VAST_4_0_WRAPPER"),
          (t[(t.DAAST_1_0 = 9)] = "DAAST_1_0"),
          (t[(t.DAAST_1_0_WRAPPER = 10)] = "DAAST_1_0_WRAPPER"),
          (t[(t.VAST_4_1 = 11)] = "VAST_4_1"),
          (t[(t.VAST_4_1_WRAPPER = 12)] = "VAST_4_1_WRAPPER"),
          (t[(t.VAST_4_2 = 13)] = "VAST_4_2"),
          (t[(t.VAST_4_2_WRAPPER = 14)] = "VAST_4_2_WRAPPER"),
          (t[(t.VAST_4_3 = 15)] = "VAST_4_3"),
          (t[(t.VAST_4_3_WRAPPER = 16)] = "VAST_4_3_WRAPPER");
      })(Fs || (Fs = {})),
      (function (t) {
        (t[(t.IABTechLabContentCategoryTaxonomy1_0 = 1)] =
          "IABTechLabContentCategoryTaxonomy1_0"),
          (t[(t.IABTechLabContentCategoryTaxonomy2_0 = 2)] =
            "IABTechLabContentCategoryTaxonomy2_0"),
          (t[(t.IABTechLabAdProductTaxonomy1_0 = 3)] =
            "IABTechLabAdProductTaxonomy1_0"),
          (t[(t.IABTechLabAudienceTaxonomy1_1 = 4)] =
            "IABTechLabAudienceTaxonomy1_1"),
          (t[(t.IABTechLabContentTaxonomy2_1 = 5)] =
            "IABTechLabContentTaxonomy2_1"),
          (t[(t.IABTechLabContentTaxonomy2_2 = 6)] =
            "IABTechLabContentTaxonomy2_2"),
          (t[(t.IABTechLabContentTaxonomy3_0 = 7)] =
            "IABTechLabContentTaxonomy3_0"),
          (t[(t.IABTechLabAdProductTaxonomy2_0 = 8)] =
            "IABTechLabAdProductTaxonomy2_0");
      })(Bs || (Bs = {})),
      (function (t) {
        (t[(t.NonClickable = 0)] = "NonClickable"),
          (t[(t.ClickableDetailsUnknown = 1)] = "ClickableDetailsUnknown"),
          (t[(t.ClickableEmbeddedBrowserOrWebview = 2)] =
            "ClickableEmbeddedBrowserOrWebview"),
          (t[(t.ClickableNativeBrowser = 3)] = "ClickableNativeBrowser");
      })(zs || (zs = {})),
      (function (t) {
        (t[(t.Static = 1)] = "Static"),
          (t[(t.HTML = 2)] = "HTML"),
          (t[(t.iFrame = 3)] = "iFrame");
      })(Js || (Js = {})),
      (function (t) {
        (t[(t.AudioAdAutoplay = 1)] = "AudioAdAutoplay"),
          (t[(t.AudioAdUserInitiated = 2)] = "AudioAdUserInitiated"),
          (t[(t.ExpandableAutomatic = 3)] = "ExpandableAutomatic"),
          (t[(t.ExpandableUserInitiatedClick = 4)] =
            "ExpandableUserInitiatedClick"),
          (t[(t.ExpandableUserInitiatedRollover = 5)] =
            "ExpandableUserInitiatedRollover"),
          (t[(t.InBannerVideoAdAutoplay = 6)] = "InBannerVideoAdAutoplay"),
          (t[(t.InBannerVideoAdUserInitiated = 7)] =
            "InBannerVideoAdUserInitiated"),
          (t[(t.Pop = 8)] = "Pop"),
          (t[(t.ProvocativeOrSuggestiveImagery = 9)] =
            "ProvocativeOrSuggestiveImagery"),
          (t[(t.ShakyFlashingFlickeringExtremeAnimationSmileys = 10)] =
            "ShakyFlashingFlickeringExtremeAnimationSmileys"),
          (t[(t.Surveys = 11)] = "Surveys"),
          (t[(t.TextOnly = 12)] = "TextOnly"),
          (t[(t.UserInteractive = 13)] = "UserInteractive"),
          (t[(t.WindowsDialogOrAlertStyle = 14)] = "WindowsDialogOrAlertStyle"),
          (t[(t.HasAudioOnOffButton = 15)] = "HasAudioOnOffButton"),
          (t[(t.AdProvidesSkipButton = 16)] = "AdProvidesSkipButton"),
          (t[(t.AdobeFlash = 17)] = "AdobeFlash"),
          (t[(t.Responsive = 18)] = "Responsive");
      })(Hs || (Hs = {})),
      (function (t) {
        (t[(t.Streaming = 1)] = "Streaming"),
          (t[(t.Progressive = 2)] = "Progressive"),
          (t[(t.Downloade = 3)] = "Downloade");
      })(Gs || (Gs = {})),
      (function (t) {
        (t[(t.ContentCentric = 10)] = "ContentCentric"),
          (t[(t.Article = 11)] = "Article"),
          (t[(t.Video = 12)] = "Video"),
          (t[(t.Audio = 13)] = "Audio"),
          (t[(t.Image = 14)] = "Image"),
          (t[(t.UserGenerated = 15)] = "UserGenerated"),
          (t[(t.Social = 20)] = "Social"),
          (t[(t.Email = 21)] = "Email"),
          (t[(t.Chat = 22)] = "Chat"),
          (t[(t.Product = 30)] = "Product"),
          (t[(t.Marketplace = 31)] = "Marketplace"),
          (t[(t.ProductReview = 32)] = "ProductReview");
      })(Ks || (Ks = {})),
      (function (t) {
        (t[(t.HTML = 1)] = "HTML"),
          (t[(t.AMPHTML = 2)] = "AMPHTML"),
          (t[(t.Image = 3)] = "Image"),
          (t[(t.Native = 4)] = "Native");
      })(Ws || (Ws = {})),
      (function (t) {
        (t[(t.InFeed = 1)] = "InFeed"),
          (t[(t.InAtomic = 2)] = "InAtomic"),
          (t[(t.Outside = 3)] = "Outside"),
          (t[(t.RecommendationWidget = 4)] = "RecommendationWidget");
      })(Qs || (Qs = {})),
      (function (t) {
        (t[(t.Left = 1)] = "Left"),
          (t[(t.Right = 2)] = "Right"),
          (t[(t.Up = 3)] = "Up"),
          (t[(t.Down = 4)] = "Down"),
          (t[(t.FullScreen = 5)] = "FullScreen"),
          (t[(t.Resize = 6)] = "Resize");
      })(Ys || (Ys = {})),
      (function (t) {
        (t[(t.Linear = 1)] = "Linear"), (t[(t.NonLinear = 2)] = "NonLinear");
      })(Zs || (Zs = {})),
      (function (t) {
        (t[(t.Unknown = 0)] = "Unknown"),
          (t[(t.AboveTheFold = 1)] = "AboveTheFold"),
          (t[(t.Locked = 2)] = "Locked"),
          (t[(t.BelowTheFold = 3)] = "BelowTheFold"),
          (t[(t.Header = 4)] = "Header"),
          (t[(t.Footer = 5)] = "Footer"),
          (t[(t.Sidebar = 6)] = "Sidebar"),
          (t[(t.Fullscreen = 7)] = "Fullscreen");
      })(Xs || (Xs = {})),
      (function (t) {
        (t[(t.VideoCompletion = 1)] = "VideoCompletion"),
          (t[(t.LeavingViewport = 2)] = "LeavingViewport"),
          (t[(t.LeavingViewportContinues = 3)] = "LeavingViewportContinues");
      })(tr || (tr = {})),
      (function (t) {
        (t[(t.PageLoadSoundOn = 1)] = "PageLoadSoundOn"),
          (t[(t.PageLoadSoundOff = 2)] = "PageLoadSoundOff"),
          (t[(t.ClickSoundOn = 3)] = "ClickSoundOn"),
          (t[(t.MouseOverSoundOn = 4)] = "MouseOverSoundOn"),
          (t[(t.EnterViewportSoundOn = 5)] = "EnterViewportSoundOn"),
          (t[(t.EnterViewportSoundOff = 6)] = "EnterViewportSoundOff"),
          (t[(t.Continuous = 7)] = "Continuous");
      })(er || (er = {})),
      (function (t) {
        (t[(t.Last = -1)] = "Last"),
          (t[(t.Any = 0)] = "Any"),
          (t[(t.First = 1)] = "First");
      })(nr || (nr = {})),
      (function (t) {
        (t[(t.DIPS = 1)] = "DIPS"),
          (t[(t.Inches = 2)] = "Inches"),
          (t[(t.Centimeters = 3)] = "Centimeters");
      })(ar || (ar = {})),
      (function (t) {
        (t[(t.Last = -1)] = "Last"),
          (t[(t.Any = 0)] = "Any"),
          (t[(t.First = 1)] = "First"),
          (t[(t.FirstOrLast = 2)] = "FirstOrLast");
      })(or || (or = {})),
      (function (t) {
        (t[(t.InStream = 1)] = "InStream"),
          (t[(t.InBanner = 2)] = "InBanner"),
          (t[(t.InArticle = 3)] = "InArticle"),
          (t[(t.InFeed = 4)] = "InFeed"),
          (t[(t.Interstitial = 5)] = "Interstitial");
      })(ir || (ir = {})),
      (function (t) {
        (t[(t.Instream = 1)] = "Instream"),
          (t[(t.Accompanying = 2)] = "Accompanying"),
          (t[(t.Interstitial = 3)] = "Interstitial"),
          (t[(t.Standalone = 4)] = "Standalone");
      })(sr || (sr = {}));
    const rr = { key: "window/initialViewportHeight", default: void 0 };
    var cr = new pt({
      scope: "ad",
      object: "slotPos",
      action: "detect",
      validators: {
        detail: { detail: et, "detail.slotIds": ot, "detail.slotIds[]": X },
        context: {
          context: et,
          "context.document": (t) => {
            if (!t || 9 !== t.nodeType) throw new Error("must be a Document");
            return { verifiable: !1 };
          },
          "context.window": et,
          "context.window.scrollY": Z,
        },
      },
      handler: async ({ account: t, detail: e, context: n }) => {
        if (0 === e.slotIds.length)
          return {
            status: s.cancelled,
            analytics: { reason: "no_slots_provided" },
          };
        const a = t.use(rr);
        if (void 0 === a)
          return {
            status: s.cancelled,
            analytics: { reason: "viewport_height_not_captured" },
          };
        const o = t.use(Ai);
        let i = 0,
          r = 0;
        const c = new Set(),
          d = {},
          l = new Map();
        e.slotIds.forEach((t) => {
          const e = o.get(t);
          if (!e) {
            const e = "slot_not_found";
            return c.add(e), void (d[t] = e);
          }
          if (!lr(e)) return void i++;
          const s = n.document.getElementById(t);
          if (!s) {
            const e = "dom_element_not_found";
            return c.add(e), void (d[t] = e);
          }
          const u =
              s.getBoundingClientRect().top + n.window.scrollY < a
                ? Xs.AboveTheFold
                : Xs.BelowTheFold,
            p = ur(e, u);
          if (p) l.set(t, p), r++;
          else {
            const e = "no_fields_to_update";
            c.add(e), (d[t] = e);
          }
        }),
          l.size > 0 &&
            t.update(
              Ai,
              (t) => (
                l.forEach((e, n) => {
                  t = t.set(n, e);
                }),
                t
              )
            );
        const u = Object.keys(d).length,
          p = c.size > 0 ? Array.from(c) : null,
          m = Object.keys(d).length > 0 ? d : null;
        return {
          status: s.completed,
          analytics: {
            slots: {
              successCount: r,
              failureCount: u,
              skippedCount: i,
              failureReasons: p,
              failedSlots: m,
            },
          },
        };
      },
    });
    const dr = (t) =>
        void 0 !== t && (void 0 === t.pos || t.pos === Xs.Unknown),
      lr = (t) => dr(t.banner) || dr(t.video),
      ur = (t, e) => {
        const n = {};
        return (
          dr(t.banner) && (n.banner = { ...t.banner, pos: e }),
          dr(t.video) && (n.video = { ...t.video, pos: e }),
          Object.keys(n).length > 0 ? { ...t, ...n } : null
        );
      };
    var pr = new pt({
      scope: "bidURL",
      object: "slots",
      action: "update",
      validators: {
        detail: {
          detail: et,
          "detail.bidRequestIndex": X,
          "detail.slots": rt(X),
        },
      },
      handler: async ({ account: t, detail: e }) => {
        let n = [];
        if (
          (void 0 !== e.slots && (n = JSON.parse(e.slots)), !Array.isArray(n))
        )
          throw new Error(
            `Unexpected value for search param slots: ${JSON.stringify(n)}`
          );
        t.recordListenerNonBlocking(Us, { slots: n });
        const a = n.flatMap((t) => {
          const e = t.sd || t.id;
          return e ? [e] : [];
        });
        return (
          a.length > 0 && t.recordListenerNonBlocking(cr, { slotIds: a }),
          n.forEach((e) => {
            mr(t, e),
              fr(t, e),
              hr(t, e),
              (e.native = ((t, e) => {
                const n = e.sd || e.id;
                if (!n) return;
                const a = t.use(Ai).get(n);
                return a && a.native
                  ? ((a.native.request.eventtrackers = ((t) => {
                      const e = t.request.eventtrackers ?? [];
                      return (
                        Cs(e, js.Impression) ||
                          e.push({
                            event: js.Impression,
                            methods: [ks.Img, ks.JS],
                          }),
                        Cs(e, js.ViewableMRC50) ||
                          e.push({
                            event: js.ViewableMRC50,
                            methods: [ks.Img, ks.JS],
                          }),
                        e
                      );
                    })(a.native)),
                    a.native)
                  : void 0;
              })(t, e));
          }),
          n.length > 0 && t.update(Rs, (t) => t.set(e.bidRequestIndex, n)),
          { status: s.completed }
        );
      },
    });
    const mr = (t, e) => {
        const n = e.sd || e.id;
        n && t.update(Is, (t) => t.add(n));
      },
      fr = (t, e) => {
        const n = t.use(Ai);
        if (void 0 === e.id && void 0 === e.sd) return;
        const a = n.get(e.id ?? "") ?? n.get(e.sd ?? "");
        if (!a) return;
        const { banner: o, video: i } = a;
        if (
          ("object" == typeof o &&
            void 0 !== o.pos &&
            (e.banner = { pos: o.pos }),
          "object" == typeof i)
        ) {
          const { pos: t, startdelay: n, plcmt: a, placement: o } = i;
          void 0 !== t && ((e.video = e.video ?? {}), (e.video.pos = t)),
            void 0 !== n &&
              ((e.video = e.video ?? {}), (e.video.startdelay = n)),
            void 0 !== a && ((e.video = e.video ?? {}), (e.video.plcmt = a)),
            void 0 !== o &&
              ((e.video = e.video ?? {}), (e.video.placement = o));
        }
      },
      hr = (t, e) => {
        const n = t.use(qs);
        if (void 0 === e.id && void 0 === e.sd) return;
        const a = n[e.id ?? e.sd ?? ""];
        a && ((e.ext = e.ext ?? {}), (e.ext.gpid = a));
      },
      vr = {
        key: "adExchangeBidFetching/bidURLs",
        default: new Map(),
        postProcessor: Si,
      },
      gr = { key: "regulations/regsString", default: "" },
      yr = { key: "regulations/dsa", default: void 0 };
    var wr;
    !(function (t) {
      (t[(t.CHILD = 1)] = "CHILD"),
        (t[(t.TEEN = 2)] = "TEEN"),
        (t[(t.ADULT = 3)] = "ADULT"),
        (t[(t.UNKNOWN = 0)] = "UNKNOWN");
    })(wr || (wr = {}));
    const br = { key: "regulations/agerange", default: void 0 },
      xr = { key: "regulations/coppa", default: void 0 };
    var Er = new pt({
        scope: "regulations",
        object: "regsString",
        action: "update",
        handler: async ({ account: t }) => {
          const e = {},
            n = t.use(yr),
            a = t.use(br),
            o = t.use(xr);
          return (
            null != n && (e.dsa = n),
            (e.coppa = null != o ? o : 0),
            null != a && ((e.ext = e.ext ?? {}), (e.ext.agerange = a)),
            t.update(gr, () => JSON.stringify(e)),
            { status: s.completed }
          );
        },
      }),
      Sr = new pt({
        scope: "adExchangeBidFetching",
        object: "bidURLs",
        action: "update",
        handler: async ({ account: t, customEvent: e }) => {
          if (void 0 === e.detail || void 0 === e.detail.legacyURL)
            throw new Error("Missing legacyURL");
          const n = e.detail?.bidRequestIndex,
            a = new URL(e.detail.legacyURL);
          t.recordListenerNonBlocking(Er);
          const o = t.use(gr);
          o.length > 0 && a.searchParams.set("regs", o),
            a.searchParams.set("rt", "j"),
            t.recordListenerNonBlocking(pr, {
              bidRequestIndex: n,
              slots: a.searchParams.get("slots") ?? void 0,
            });
          const i = t.use(Rs).get(n);
          null != i && a.searchParams.set("slots", JSON.stringify(i)),
            t.recordListenerNonBlocking(_s, {
              bidRequestIndex: n,
              pj: a.searchParams.get("pj") ?? void 0,
            });
          const r = t.use(Ss).get(n);
          null != r && a.searchParams.set("pj", JSON.stringify(r));
          const c = a.toString();
          t.update(vr, (t) => {
            if (void 0 === e.detail || void 0 === n)
              throw new Error("Missing bidRequestIndex");
            return t.set(e.detail.bidRequestIndex, c);
          });
          let d = { urlLength: c.length };
          const l = (function (t) {
            const e = {};
            try {
              const n = new URL(t);
              return (
                [...new URLSearchParams(n.search)].forEach(([t, n]) => {
                  e[t] = n.length;
                }),
                e
              );
            } catch (t) {}
          })(c);
          return (
            void 0 !== l && (d = { ...d, urlParamLengths: l }),
            { status: s.completed, analytics: d }
          );
        },
      });
    const _r = {
      key: "amazonAdExchange/basePostUrl",
      default: "https://aax.amazon-adsystem.com/e/dtb/bid",
    };
    var Rr = new pt({
      scope: "adExchangeBidFetching",
      object: "amazonAdExchange",
      action: "post",
      validators: {
        detail: { detail: et, "detail.requestBody": X },
        context: {
          context: et,
          "context.fetch": ct,
          "context.fetch()": et,
          "context.fetch().ok": tt,
          "context.fetch().then": ct,
          "context.fetch().then()": lt,
          ...Pn,
        },
      },
      handler: async ({ account: t, context: e, detail: n }) => {
        const a = t.use(_r),
          o = await e.fetch(a, {
            method: "POST",
            credentials: "include",
            headers: { "Content-Type": "application/json" },
            body: n.requestBody,
          });
        if (!o.ok) throw new Error(`Fetch failed with status: ${o.status}`);
        const i = o.status,
          r = o.statusText,
          c = o.type,
          d = await o.json(),
          { contextual: l } = d;
        return (
          void 0 !== l &&
            (t.recordListenerNonBlocking(es, { aaxResp: l }), e.apstag.bids(l)),
          {
            status: s.completed,
            value: { slotCount: l?.slots?.length ?? 0 },
            analytics: { statusCode: i, statusText: r, responseType: c },
          }
        );
      },
    });
    const Ir = { key: "a3pesBanner/isActivated", default: !0 },
      Ar = { key: "a3pesVideo/isActivated", default: !0 },
      kr = { key: "a3pesMultiFormat/isActivated", default: !0 },
      jr = { key: "bidResponses/slotIDs", default: new Set() },
      $r = { key: "bidRequest/sampleRate", default: 1 },
      Cr = { key: "bidRequest/sampleRateOverride", default: void 0 };
    var Or = new pt({
      scope: "adExchange",
      object: "bid",
      action: "fetch",
      validators: {
        detail: {
          detail: et,
          "detail.URL": X,
          "detail.fetchBidsConfig": rt(et),
          "detail.fetchBidsConfig.tid": rt(X),
          "detail.fetchBidsConfig.slots": rt(ot),
          "detail.fetchBidsConfig.slots[]": et,
          "detail.fetchBidsConfig.slots[].slotID": rt(X),
          "detail.fetchBidsConfig.slots[].tid": rt(X),
        },
        context: {
          context: et,
          "context.crypto": rt(et),
          "context.crypto.randomUUID": rt(ct),
          "context.crypto.randomUUID()": rt(X),
        },
      },
      handler: async ({ account: t, detail: e, context: n }) => {
        if ((t.recordListenerNonBlocking(Es), t.use(xs)))
          return { status: s.cancelled };
        const a = t.use($r),
          o = t.use(Cr),
          i = o ?? a;
        if (Math.random() >= i)
          return {
            status: s.cancelled,
            analytics: { sampleRate: a, sampleRateOverride: o },
          };
        const r = new URL(e.URL).searchParams.get("cb") || "unknown";
        await t.recordListener(Sr, { legacyURL: e.URL, bidRequestIndex: r });
        const c = t.use(vr).get(r);
        if (!c) throw new Error("Missing URL for provided bid request index");
        const d = ((t) => {
            const e = new URL(t),
              n = Array.from(e.searchParams.entries()),
              a = {};
            return (
              n.forEach(([t, e]) => {
                try {
                  a[t] = JSON.parse(e);
                } catch (n) {
                  a[t] = e;
                }
              }),
              a
            );
          })(c),
          l = {
            requestTid: Dr(d, {
              providedTid: e.fetchBidsConfig?.tid,
              crypto: n.crypto,
            }),
            slotTid: Tr(d.slots, {
              configSlots: e.fetchBidsConfig?.slots,
              crypto: n.crypto,
            }),
          },
          u = d.slots,
          p = JSON.stringify(d),
          m = t.use(Zi),
          f = t.use(Ir),
          h = t.use(Ar),
          v = t.use(kr),
          g = ((t, ...e) => {
            const n = new Set();
            for (const a of t) {
              const t = ls(a);
              if (null === t || !e.includes(t)) return !1;
              n.add(t);
            }
            return e.every((t) => n.has(t));
          })(u, is.DISPLAY),
          y = g ? f : u.every((t) => !!rs(t) || (cs(t) ? h : !!ds(t) && v));
        let w,
          b = "AAX";
        !m && y
          ? ((b = "3PES"),
            (w = await t.recordListener(ss, {
              requestBody: p,
              isBannerOnly: g,
            })))
          : (w = await t.recordListener(Rr, { requestBody: p }));
        const x = w?.slotCount ?? 0;
        x > 0 &&
          t
            .record("adExchange/slots/didReceive", {
              analytics: { slotCount: x },
            })
            .catch(() => {}),
          ((t) => {
            const e = new Set();
            return (
              t?.forEach((t) => {
                const n = us(t);
                n && e.add(n);
              }),
              e
            );
          })(u).forEach((e) => {
            t.update(jr, (t) => t.add(e));
          });
        const E = Nr(u);
        return {
          status: s.completed,
          analytics: {
            sampleRate: a,
            sampleRateOverride: o,
            adExchange: b,
            slotMetadata: E,
            tidMetadata: l,
          },
        };
      },
    });
    const Pr = (t) => {
        try {
          const e = t?.randomUUID();
          return e && 36 === e.length ? e : void 0;
        } catch (t) {
          return;
        }
      },
      Dr = (t, e) => {
        const { providedTid: n, crypto: a } = e;
        let o = n,
          i = "provided";
        return (
          o || ((o = Pr(a)), (i = o ? "autogenerated" : "failed")),
          o && ((t.source = t.source || {}), (t.source.tid = o)),
          i
        );
      },
      Tr = (t, e) => {
        const { configSlots: n, crypto: a } = e;
        if (!(void 0 !== (o = n) && o.length > 0 && "slotID" in o[0]))
          return "unsupported";
        var o;
        const i = new Map();
        n.forEach((t) => {
          t.tid && i.set(t.slotID, t.tid);
        });
        let s = 0,
          r = 0;
        return (
          t.forEach((t) => {
            const e = us(t);
            if (!e) return;
            let n = i.get(e);
            n || ((n = Pr(a)), n ? s++ : r++),
              n && ((t.ext = t.ext || {}), (t.ext.tid = n));
          }),
          r > 0
            ? "failed"
            : 0 === s
            ? "all-provided"
            : 0 === i.size
            ? "all-autogenerated"
            : "partial"
        );
      },
      Nr = (t) => {
        const e = {
            display: 0,
            video: 0,
            native: 0,
            multiFormat: 0,
            unknown: 0,
            total: t.length,
          },
          n = new Set();
        t.forEach((t) => {
          rs(t)
            ? (e.display++, n.add("display"))
            : cs(t)
            ? (e.video++, n.add("video"))
            : ((t) => void 0 !== t.native)(t)
            ? (e.native++, n.add("native"))
            : ds(t)
            ? (e.multiFormat++, n.add("multiFormat"))
            : (e.unknown++, n.add("unknown"));
        });
        const a = Array.from(n).sort(),
          o = a.join("+");
        return { typesPresent: a, combinationKey: o, counts: e };
      };
    var Lr = new pt({
        scope: "bidRequest",
        object: "sampleRate",
        action: "set",
        validators: {
          detail: { detail: et, "detail.rate": nt({ min: 0, max: 1 }) },
          context: { context: et },
        },
        handler: async ({ account: t, detail: e }) => (
          t.update($r, () => e.rate), { status: s.completed }
        ),
      }),
      Mr = new pt({
        scope: "bidRequest",
        object: "sampleRateOverride",
        action: "set",
        validators: {
          detail: { detail: et, "detail.rate": nt({ min: 0, max: 1 }) },
          context: { context: et },
        },
        handler: async ({ account: t, detail: e }) => (
          t.update(Cr, () => e.rate), { status: s.completed }
        ),
      }),
      Ur = new pt({
        scope: "a3pes",
        object: "banner",
        action: "deactivate",
        validators: {
          detail: { detail: et, "detail.bypassCountryCheck": rt(tt) },
          context: { context: et },
        },
        handler: async ({ account: t, detail: e }) => {
          const n = t.use(ht);
          return e.bypassCountryCheck || "US" !== n
            ? (t.update(Ir, () => !1), { status: s.completed })
            : { status: s.cancelled };
        },
      }),
      qr = new pt({
        scope: "a3pes",
        object: "video",
        action: "deactivate",
        validators: {
          detail: { detail: et, "detail.bypassCountryCheck": rt(tt) },
          context: { context: et },
        },
        handler: async ({ account: t, detail: e }) => {
          const n = t.use(ht);
          return e.bypassCountryCheck || "US" !== n
            ? (t.update(Ar, () => !1), { status: s.completed })
            : { status: s.cancelled };
        },
      }),
      Vr = new pt({
        scope: "a3pes",
        object: "multiFormat",
        action: "deactivate",
        validators: {
          detail: { detail: et, "detail.bypassCountryCheck": rt(tt) },
          context: { context: et },
        },
        handler: async ({ account: t, detail: e }) => {
          const n = t.use(ht);
          return e.bypassCountryCheck || "US" !== n
            ? (t.update(kr, () => !1), { status: s.completed })
            : { status: s.cancelled };
        },
      }),
      Fr = new pt({
        scope: "a3pes",
        object: "mockBidder",
        action: "set",
        validators: {
          detail: { detail: et, "detail.id": X, "detail.url": X },
          context: { context: et },
        },
        handler: async ({ account: t, detail: e }) => (
          t.update(os, () => ({ id: e.id, url: e.url })),
          { status: s.completed }
        ),
      }),
      Br = new pt({
        scope: "a3pes",
        object: "bidURL",
        action: "update",
        validators: {
          detail: { detail: et, "detail.url": X },
          context: { context: et },
        },
        handler: async ({ account: t, detail: e }) => (
          t.update(ns, () => e.url), { status: s.completed }
        ),
      }),
      zr = new pt({
        scope: "a3pes",
        object: "videoBidURL",
        action: "update",
        validators: {
          detail: { detail: et, "detail.url": X },
          context: { context: et },
        },
        handler: async ({ account: t, detail: e }) => (
          t.update(as, () => e.url), { status: s.completed }
        ),
      });
    const Jr = mt([
      Xi,
      ss,
      Fr,
      Or,
      Rr,
      Sr,
      es,
      Lr,
      Mr,
      _s,
      pr,
      Ur,
      qr,
      Vr,
      Br,
      zr,
    ]);
    var Hr = new pt({
      scope: "cellophane",
      object: "xhrBidOnLoad",
      action: "enter",
      handler: async () => ({ status: s.completed }),
    });
    const Gr = (t) => {
        const e = {
          id: t.slotID,
          tagid: t.slotName,
          bidfloor: t.floor?.value,
          bidfloorcur: t.floor?.currency,
          ext: { ...t.slotParams },
        };
        switch (t.mediaType) {
          case ti.MultiFormat:
            (e.video = Wr({
              sizes: t.multiFormatProperties?.video?.sizes ?? [],
              companions: t.companions ?? [],
            })),
              (e.banner = Qr({
                sizes: t.multiFormatProperties?.display?.sizes ?? [],
              }));
            break;
          case ti.Video:
            e.video = Wr({
              sizes: t.sizes ?? [],
              companions: t.companions ?? [],
            });
            break;
          default:
            e.banner = Qr({ sizes: t.sizes ?? [] });
        }
        return e;
      },
      Kr = (t) =>
        t
          .filter(
            (t) => Array.isArray(t) && t.every((t) => "number" == typeof t)
          )
          .map(([t, e]) => ({ w: t, h: e })),
      Wr = (t) => {
        const e = { mimes: [] },
          n = Kr(t.sizes);
        if (
          (n.length > 0 && ((e.w = n[0].w), (e.h = n[0].h)),
          t.companions.length > 0)
        ) {
          const n = [];
          t.companions.forEach((t) => {
            const e = { id: t };
            n.push(e);
          }),
            (e.companionad = n);
        }
        return e;
      },
      Qr = (t) => {
        const e = {},
          n = Kr(t.sizes);
        if (n.length > 0) {
          (e.w = n[0].w), (e.h = n[0].h);
          const t = [];
          n.forEach((e) => {
            t.push({ w: e.w, h: e.h });
          }),
            (e.format = t);
        }
        return e;
      },
      Yr = (t) => {
        const e = Zr({ display: t.spec.placement.display }),
          n = tc({ video: t.spec.placement.video });
        return {
          id: t.id,
          banner: e,
          video: n,
          displaymanager: t.spec.placement.sdk,
          displaymanagerver: t.spec.placement.sdkver,
          instl: t.spec.placement.display?.instl,
          tagid: t.spec.placement.tagid,
          bidfloor: t.flr,
          bidfloorcur: t.flrcur,
          secure: t.spec.placement.secure,
          iframebuster: t.spec.placement.display?.ifrbust,
          rwdd: t.spec.placement.reward,
          ssai: t.spec.placement.ssai,
          exp: t.exp,
          dt: t.dt,
          ext: { ...t.ext, ...t.spec.placement.ext },
        };
      },
      Zr = (t) => {
        if (void 0 !== t.display)
          return {
            format: Xr({ displayFmt: t.display.displayfmt }),
            w: t.display.w,
            h: t.display.h,
            pos: t.display.pos,
            mimes: t.display.mime,
            topframe: t.display.topframe,
            api: t.display.api,
            ext: t.display.ext,
          };
      },
      Xr = (t) => {
        if (void 0 === t.displayFmt || 0 === t.displayFmt.length) return;
        const e = [];
        return (
          t.displayFmt.forEach((t) => {
            e.push({
              w: t.w,
              h: t.h,
              wratio: t.wratio,
              hratio: t.hratio,
              ext: t.ext,
            });
          }),
          e
        );
      },
      tc = (t) => {
        if (void 0 === t.video) return;
        const e = {
          mimes: t.video.mime,
          minduration: t.video.mindur,
          maxduration: t.video.maxdur,
          startdelay: t.video.delay,
          maxseq: t.video.maxseq,
          poddur: t.video.poddur,
          protocols: t.video.ctype,
          w: t.video.w,
          h: t.video.h,
          podid: t.video.podid ? `${t.video.podid}` : void 0,
          podseq: t.video.podseq,
          rqddurs: t.video.rqddurs,
          plcmt: t.video.ptype,
          linearity: t.video.linear,
          skip: t.video.skip,
          skipmin: t.video.skipmin,
          skipafter: t.video.skipafter,
          slotinpod: t.video.slotinpod,
          mincpmpersec: t.video.mincpmpersec,
          maxextended: t.video.maxext,
          minbitrate: t.video.minbitr,
          maxbitrate: t.video.maxbitr,
          boxingallowed: t.video.boxing,
          playbackmethod: t.video.playmethod,
          playbackend: t.video.playend,
          delivery: t.video.delivery,
          pos: t.video.pos,
          api: t.video.api,
          ext: t.video.ext,
        };
        if (void 0 !== t.video.comp && t.video.comp.length > 0) {
          const n = t.video.comp.map((t) => ({ id: t.id }));
          e.companionad = n;
        }
        return e;
      },
      ec = {
        "detail.slots": rt(ot),
        "detail.slots[]": rt(et),
        "detail.slots[].slotID": X,
        "detail.slots[].slotName": rt(X),
        "detail.slots[].sizes": rt(ot),
        "detail.slots[].sizes[]": null,
        "detail.slots[].mediaType": rt(
          it([ti.Display, ti.Video, ti.MultiFormat])
        ),
        "detail.slots[].slotParams": lt,
        "detail.slots[].floor": rt(et),
        "detail.slots[].floor.currency": it(["USD"]),
        "detail.slots[].floor.value": Z,
        "detail.slots[].multiFormatProperties": rt(et),
        "detail.slots[].multiFormatProperties.display": rt(et),
        "detail.slots[].multiFormatProperties.display.sizes": rt(ot),
        "detail.slots[].multiFormatProperties.display.sizes[]": ot,
        "detail.slots[].multiFormatProperties.display.sizes[][]": Z,
        "detail.slots[].multiFormatProperties.video": rt(et),
        "detail.slots[].multiFormatProperties.video.sizes": rt(ot),
        "detail.slots[].multiFormatProperties.video.sizes[]": ot,
        "detail.slots[].multiFormatProperties.video.sizes[][]": Z,
        "detail.slots[].companions": rt(ot),
        "detail.slots[].companions[]": X,
      },
      nc = (t) => ({
        [`${t}.banner`]: rt(et),
        [`${t}.banner.format`]: rt(ot),
        [`${t}.banner.format[]`]: et,
        [`${t}.banner.format[].w`]: rt(Z),
        [`${t}.banner.format[].h`]: rt(Z),
        [`${t}.banner.format[].wratio`]: rt(Z),
        [`${t}.banner.format[].hratio`]: rt(Z),
        [`${t}.banner.format[].wmin`]: rt(Z),
        [`${t}.banner.format[].ext`]: lt,
        [`${t}.banner.w`]: rt(Z),
        [`${t}.banner.h`]: rt(Z),
        [`${t}.banner.btype`]: rt(ot),
        [`${t}.banner.btype[]`]: Z,
        [`${t}.banner.battr`]: rt(ot),
        [`${t}.banner.battr[]`]: it(Object.values(Hs)),
        [`${t}.banner.pos`]: rt(it(Object.values(Xs))),
        [`${t}.banner.mimes`]: rt(ot),
        [`${t}.banner.mimes[]`]: X,
        [`${t}.banner.topframe`]: rt(Z),
        [`${t}.banner.expdir`]: rt(ot),
        [`${t}.banner.expdir[]`]: it(Object.values(Ys)),
        [`${t}.banner.api`]: rt(ot),
        [`${t}.banner.api[]`]: it(Object.values(Vs)),
        [`${t}.banner.id`]: rt(X),
        [`${t}.banner.vcm`]: rt(Z),
        [`${t}.banner.ext`]: lt,
      }),
      ac = {
        "detail.imp": rt(ot),
        "detail.imp[]": et,
        "detail.imp[].id": X,
        ...nc("detail.imp[]"),
        "detail.imp[].valueOf": dt,
        "detail.imp[].valueOf()": dt,
        "detail.imp[].video": rt(et),
        "detail.imp[].video.valueOf": dt,
        "detail.imp[].video.valueOf()": dt,
        "detail.imp[].video.mimes": ot,
        "detail.imp[].video.mimes[]": X,
        "detail.imp[].video.minduration": rt(Z),
        "detail.imp[].video.maxduration": rt(Z),
        "detail.imp[].video.startdelay": rt(Z),
        "detail.imp[].video.maxseq": rt(Z),
        "detail.imp[].video.poddur": rt(Z),
        "detail.imp[].video.protocols": rt(ot),
        "detail.imp[].video.protocols[]": it(Object.values(Fs)),
        "detail.imp[].video.w": rt(Z),
        "detail.imp[].video.h": rt(Z),
        "detail.imp[].video.podid": rt(X),
        "detail.imp[].video.podseq": rt(it(Object.values(nr))),
        "detail.imp[].video.rqddurs": rt(ot),
        "detail.imp[].video.rqddurs[]": Z,
        "detail.imp[].video.placement": rt(Z),
        "detail.imp[].video.plcmt": rt(it(Object.values(sr))),
        "detail.imp[].video.linearity": rt(it(Object.values(Zs))),
        "detail.imp[].video.skip": rt(Z),
        "detail.imp[].video.skipmin": rt(Z),
        "detail.imp[].video.skipafter": rt(Z),
        "detail.imp[].video.sequence": rt(Z),
        "detail.imp[].video.slotinpod": rt(Z),
        "detail.imp[].video.mincpmpersec": rt(Z),
        "detail.imp[].video.battr": rt(ot),
        "detail.imp[].video.battr[]": it(Object.values(Hs)),
        "detail.imp[].video.maxextended": rt(Z),
        "detail.imp[].video.minbitrate": rt(Z),
        "detail.imp[].video.maxbitrate": rt(Z),
        "detail.imp[].video.boxingallowed": rt(Z),
        "detail.imp[].video.playbackmethod": rt(ot),
        "detail.imp[].video.playbackmethod[]": it(Object.values(er)),
        "detail.imp[].video.playbackend": rt(it(Object.values(tr))),
        "detail.imp[].video.delivery": rt(ot),
        "detail.imp[].video.delivery[]": it(Object.values(Gs)),
        "detail.imp[].video.pos": rt(it(Object.values(Xs))),
        "detail.imp[].video.companionad": rt(ot),
        "detail.imp[].video.companionad[]": et,
        ...nc("detail.imp[].video.companionad[]"),
        "detail.imp[].video.ext": lt,
        "detail.imp[].native": rt(et),
        "detail.imp[].native.request": st(et),
        "detail.imp[].native.request.ver": rt(X),
        "detail.imp[].native.request.context": rt(Z),
        "detail.imp[].native.request.contextsubtype": rt(Z),
        "detail.imp[].native.request.plcmttype": rt(Z),
        "detail.imp[].native.request.plcmtcnt": rt(Z),
        "detail.imp[].native.request.seq": rt(Z),
        "detail.imp[].native.request.assets": ot,
        "detail.imp[].native.request.assets[]": et,
        "detail.imp[].native.request.assets[].id": Z,
        "detail.imp[].native.request.assets[].required": rt(Z),
        "detail.imp[].native.request.assets[].title": rt(et),
        "detail.imp[].native.request.assets[].title.len": Z,
        "detail.imp[].native.request.assets[].title.ext": lt,
        "detail.imp[].native.request.assets[].img": rt(et),
        "detail.imp[].native.request.assets[].img.type": rt(Z),
        "detail.imp[].native.request.assets[].img.w": rt(Z),
        "detail.imp[].native.request.assets[].img.wmin": rt(Z),
        "detail.imp[].native.request.assets[].img.h": rt(Z),
        "detail.imp[].native.request.assets[].img.hmin": rt(Z),
        "detail.imp[].native.request.assets[].img.mimes": rt(ot),
        "detail.imp[].native.request.assets[].img.mimes[]": X,
        "detail.imp[].native.request.assets[].img.ext": lt,
        "detail.imp[].native.request.assets[].data": rt(et),
        "detail.imp[].native.request.assets[].data.type": Z,
        "detail.imp[].native.request.assets[].data.len": rt(Z),
        "detail.imp[].native.request.assets[].data.ext": lt,
        "detail.imp[].native.request.assets[].ext": lt,
        "detail.imp[].native.request.aurlsupport": rt(Z),
        "detail.imp[].native.request.durlsupport": rt(Z),
        "detail.imp[].native.request.eventtrackers": rt(ot),
        "detail.imp[].native.request.eventtrackers[]": et,
        "detail.imp[].native.request.eventtrackers[].event": Z,
        "detail.imp[].native.request.eventtrackers[].methods": ot,
        "detail.imp[].native.request.eventtrackers[].methods[]": Z,
        "detail.imp[].native.request.eventtrackers[].ext": lt,
        "detail.imp[].native.request.privacy": rt(Z),
        "detail.imp[].native.request.ext": lt,
        "detail.imp[].native.ver": rt(X),
        "detail.imp[].native.api": rt(ot),
        "detail.imp[].native.api[]": Z,
        "detail.imp[].native.battr": rt(ot),
        "detail.imp[].native.battr[]": Z,
        "detail.imp[].native.ext": lt,
        "detail.imp[].displaymanager": rt(X),
        "detail.imp[].displaymanagerver": rt(X),
        "detail.imp[].instl": rt(Z),
        "detail.imp[].tagid": rt(X),
        "detail.imp[].bidfloor": rt(Z),
        "detail.imp[].bidfloorcur": rt(X),
        "detail.imp[].clickbrowser": rt(Z),
        "detail.imp[].secure": rt(Z),
        "detail.imp[].iframebuster": rt(ot),
        "detail.imp[].iframebuster[]": X,
        "detail.imp[].rwdd": rt(Z),
        "detail.imp[].ssai": rt(Z),
        "detail.imp[].exp": rt(Z),
        "detail.imp[].dt": rt(Z),
        "detail.imp[].ext": lt,
      },
      oc = {
        "detail.item": rt(ot),
        "detail.item[]": rt(et),
        "detail.item[].version": rt(X),
        "detail.item[].id": X,
        "detail.item[].qty": rt(Z),
        "detail.item[].qtyflt": rt(Z),
        "detail.item[].seq": rt(Z),
        "detail.item[].flr": rt(Z),
        "detail.item[].flrcur": rt(X),
        "detail.item[].exp": rt(Z),
        "detail.item[].dt": rt(Z),
        "detail.item[].dlvy": rt(Z),
        "detail.item[].deal": rt(ot),
        "detail.item[].deal[]": rt(et),
        "detail.item[].deal[].id": rt(X),
        "detail.item[].private": rt(Z),
        "detail.item[].spec": et,
        "detail.item[].spec.placement": et,
        "detail.item[].spec.placement.tagid": rt(X),
        "detail.item[].spec.placement.ssai": rt(Z),
        "detail.item[].spec.placement.sdk": rt(X),
        "detail.item[].spec.placement.sdkver": rt(X),
        "detail.item[].spec.placement.reward": rt(X),
        "detail.item[].spec.placement.wlang": rt(ot),
        "detail.item[].spec.placement.wlang[]": X,
        "detail.item[].spec.placement.secure": rt(Z),
        "detail.item[].spec.placement.admx": rt(Z),
        "detail.item[].spec.placement.curlx": rt(Z),
        "detail.item[].spec.placement.display": rt(et),
        "detail.item[].spec.placement.display.pos": rt(Z),
        "detail.item[].spec.placement.display.instl": rt(Z),
        "detail.item[].spec.placement.display.topframe": rt(Z),
        "detail.item[].spec.placement.display.ifrbust": rt(ot),
        "detail.item[].spec.placement.display.ifrbust[]": X,
        "detail.item[].spec.placement.display.clktype": rt(
          it(Object.values(zs))
        ),
        "detail.item[].spec.placement.display.ampren": rt(Z),
        "detail.item[].spec.placement.display.ptype": rt(it(Object.values(Qs))),
        "detail.item[].spec.placement.display.context": rt(
          it(Object.values(Ks))
        ),
        "detail.item[].spec.placement.display.mime": rt(ot),
        "detail.item[].spec.placement.display.mime[]": X,
        "detail.item[].spec.placement.display.api": rt(ot),
        "detail.item[].spec.placement.display.api[]": it(Object.values(Vs)),
        "detail.item[].spec.placement.display.ctype": rt(ot),
        "detail.item[].spec.placement.display.ctype[]": it(Object.values(Ws)),
        "detail.item[].spec.placement.display.w": rt(Z),
        "detail.item[].spec.placement.display.h": rt(Z),
        "detail.item[].spec.placement.display.unit": rt(it(Object.values(ar))),
        "detail.item[].spec.placement.display.priv": rt(Z),
        "detail.item[].spec.placement.display.displayfmt": rt(ot),
        "detail.item[].spec.placement.display.displayfmt[]": rt(et),
        "detail.item[].spec.placement.display.displayfmt[].w": rt(Z),
        "detail.item[].spec.placement.display.displayfmt[].h": rt(Z),
        "detail.item[].spec.placement.display.displayfmt[].wratio": rt(Z),
        "detail.item[].spec.placement.display.displayfmt[].hratio": rt(Z),
        "detail.item[].spec.placement.display.displayfmt[].expdir": rt(ot),
        "detail.item[].spec.placement.display.displayfmt[].expdir[]": it(
          Object.values(Ys)
        ),
        "detail.item[].spec.placement.display.displayfmt[].ext": lt,
        "detail.item[].spec.placement.display.ext": lt,
        "detail.item[].spec.placement.video": rt(et),
        "detail.item[].spec.placement.video.ptype": rt(Z),
        "detail.item[].spec.placement.video.pos": rt(Z),
        "detail.item[].spec.placement.video.delay": rt(Z),
        "detail.item[].spec.placement.video.skip": rt(Z),
        "detail.item[].spec.placement.video.skipmin": rt(Z),
        "detail.item[].spec.placement.video.skipafter": rt(Z),
        "detail.item[].spec.placement.video.playmethod": rt(
          it(Object.values(er))
        ),
        "detail.item[].spec.placement.video.playend": rt(it(Object.values(tr))),
        "detail.item[].spec.placement.video.clktype": rt(it(Object.values(zs))),
        "detail.item[].spec.placement.video.mime": rt(ot),
        "detail.item[].spec.placement.video.mime[]": X,
        "detail.item[].spec.placement.video.api": rt(ot),
        "detail.item[].spec.placement.video.api[]": it(Object.values(Vs)),
        "detail.item[].spec.placement.video.ctype": rt(it(Object.values(Fs))),
        "detail.item[].spec.placement.video.w": rt(Z),
        "detail.item[].spec.placement.video.h": rt(Z),
        "detail.item[].spec.placement.video.unit": rt(it(Object.values(ar))),
        "detail.item[].spec.placement.video.mindur": rt(Z),
        "detail.item[].spec.placement.video.maxdur": rt(Z),
        "detail.item[].spec.placement.video.rqddurs": rt(ot),
        "detail.item[].spec.placement.video.rqddurs[]": Z,
        "detail.item[].spec.placement.video.maxext": rt(Z),
        "detail.item[].spec.placement.video.minbitr": rt(Z),
        "detail.item[].spec.placement.video.maxbitr": rt(Z),
        "detail.item[].spec.placement.video.delivery": rt(
          it(Object.values(Gs))
        ),
        "detail.item[].spec.placement.video.maxseq": rt(Z),
        "detail.item[].spec.placement.video.poddur": rt(Z),
        "detail.item[].spec.placement.video.podid": rt(Z),
        "detail.item[].spec.placement.video.podseq": rt(it(Object.values(nr))),
        "detail.item[].spec.placement.video.slotinpod": rt(
          it(Object.values(or))
        ),
        "detail.item[].spec.placement.video.mincpmpersec": rt(Z),
        "detail.item[].spec.placement.video.linear": rt(it(Object.values(Zs))),
        "detail.item[].spec.placement.video.boxing": rt(Z),
        "detail.item[].spec.placement.video.comp": rt(ot),
        "detail.item[].spec.placement.video.comp[]": et,
        "detail.item[].spec.placement.video.comp[].id": rt(X),
        "detail.item[].spec.placement.video.comp[].vcm": rt(Z),
        "detail.item[].spec.placement.video.comp[].ext": lt,
        "detail.item[].spec.placement.video.comptype": rt(
          it(Object.values(Js))
        ),
        "detail.item[].spec.placement.video.expdir": rt(ot),
        "detail.item[].spec.placement.video.expdir[]": it(Object.values(Ys)),
        "detail.item[].spec.placement.video.overlayexpdir": rt(ot),
        "detail.item[].spec.placement.video.overlayexpdir[]": it(
          Object.values(Ys)
        ),
        "detail.item[].spec.placement.video.ext": lt,
        "detail.item[].spec.placement.ext": lt,
        "detail.item[].ext": lt,
      },
      ic = (t) => {
        const e = { id: t.getSlotId().getDomId(), tagid: t.getAdUnitPath() };
        return (e.banner = sc({ sizes: t.getSizes() })), e;
      },
      sc = (t) => {
        const e = {},
          n = t.sizes
            .filter((t) => "string" != typeof t)
            .map(({ width: t, height: e }) => ({ w: t, h: e }));
        if (n.length > 0) {
          (e.w = n[0].w), (e.h = n[0].h);
          const t = [];
          n.forEach((e) => {
            t.push({ w: e.w, h: e.h });
          }),
            (e.format = t);
        }
        return e;
      },
      rc = {
        "detail.gamSlots": rt(ot),
        "detail.gamSlots[]": rt(et),
        "detail.gamSlots[].getAdUnitPath": rt(ct),
        "detail.gamSlots[].getAdUnitPath()": rt(X),
        "detail.gamSlots[].getSizes": rt(ct),
        "detail.gamSlots[].getSizes()": rt(ot),
        "detail.gamSlots[].getSizes()[]": rt(at([X, et])),
        "detail.gamSlots[].getSizes()[].width": rt(Z),
        "detail.gamSlots[].getSizes()[].height": rt(Z),
        "detail.gamSlots[].getSizes()[].name": rt(X),
        "detail.gamSlots[].getSlotId": rt(ct),
        "detail.gamSlots[].getSlotId()": rt(et),
        "detail.gamSlots[].getSlotId().getDomId": rt(ct),
        "detail.gamSlots[].getSlotId().getDomId()": rt(X),
      };
    var cc = new pt({
      scope: "ad",
      object: "slot",
      action: "define",
      validators: { detail: { detail: et, ...ec, ...ac, ...oc, ...rc } },
      handler: async ({ account: t, detail: e }) => {
        const n = [
          ...(e.imp ?? []),
          ...(e.item?.map(Yr) ?? []),
          ...(e.slots?.map(Gr) ?? []),
          ...(e.gamSlots?.map(ic) ?? []),
        ];
        if (0 === n.length)
          throw new Error(
            "Expecting a non-empty array for 'imp' (OpenRTB 2.6), 'item' (OpenRTB 3.0), or 'slots' (APS legacy)."
          );
        n.forEach((e) => {
          t.update(Ai, (t) => t.set(e.id, e));
        });
        const a = n.map((t) => t.id);
        return (
          t.recordListenerNonBlocking(cr, { slotIds: a }),
          t.recordListenerNonBlocking(Ls, { slotIds: a }),
          { status: s.completed }
        );
      },
    });
    const dc = { key: "simplerGPT/isActivated", default: !1 };
    var lc = new pt({
      scope: "cellophane",
      object: "fetchBids",
      action: "enter",
      validators: {
        detail: {
          detail: et,
          "detail.bidConfig": et,
          "detail.bidConfig.slots": at([ot, ut]),
          "detail.bidConfig.slots[]": null,
          "detail.bidConfig.timeout": rt(Z),
          "detail.bidConfig.params": lt,
          "detail.bidConfig.blockedBidders": rt(ot),
          "detail.bidConfig.blockedBidders[]": X,
          "detail.bidConfig._endpointDomain": rt(X),
        },
      },
      handler: async ({ account: t, detail: e }) => {
        const n = t.use(dc);
        let a;
        a =
          !e?.bidConfig?.slots?.length && n
            ? t.globalContext.googletag.pubads().getSlots()
            : [...(e.bidConfig.slots ?? [])];
        const { apsSlots: o, gamSlots: i } = (function (t) {
          const { apsSlots: e, gamSlots: n } = t.reduce(
            (t, e) => (
              (function (t) {
                return "slotID" in t;
              })(e)
                ? t.apsSlots.push(e)
                : t.gamSlots.push(e),
              t
            ),
            { apsSlots: [], gamSlots: [] }
          );
          return { apsSlots: e, gamSlots: n };
        })(a);
        return (
          await t.recordListener(cc, { slots: o, gamSlots: i }),
          { status: s.completed }
        );
      },
    });
    const uc = { key: "cellophane/config", default: void 0 };
    var pc = new pt({
        scope: "regulations",
        object: "agerange",
        action: "define",
        validators: {
          detail: {
            detail: et,
            "detail.agerange": it(
              Object.values(wr).filter((t) => "number" == typeof t)
            ),
          },
          context: {},
        },
        handler: async ({ account: t, detail: e }) => (
          t.update(br, () => e.agerange),
          { status: s.completed, analytics: { agerange: e.agerange } }
        ),
      }),
      mc = new pt({
        scope: "regulations",
        object: "coppa",
        action: "define",
        validators: {
          detail: { detail: et, "detail.value": it([0, 1]) },
          context: {},
        },
        handler: async ({ account: t, detail: e }) => (
          t.update(xr, () => e.value),
          { status: s.completed, analytics: { value: e.value } }
        ),
      }),
      fc = new pt({
        scope: "cellophane",
        object: "init",
        action: "enter",
        handler: async ({ account: t, customEvent: e }) => {
          const n = e.detail?.config,
            a = [];
          return (
            a.push(t.record(Di, { context: n?.signals?.ortb2 })),
            !0 !== n?.disableConfigCall && a.push(t.record(bt)),
            n?.simplerGPT && t.update(dc, () => n.simplerGPT),
            void 0 !== n?.bidRequestSampleRate &&
              a.push(t.record(Lr.name, { rate: n?.bidRequestSampleRate })),
            null != n?.agerange &&
              a.push(t.recordListener(pc, { agerange: n.agerange })),
            null != n?.coppa &&
              a.push(t.recordListener(mc, { value: n.coppa })),
            t.update(uc, () => n),
            await Promise.all(a),
            { status: s.completed }
          );
        },
      });
    const hc = { key: "ad/amzniidRenderHistory", default: new Set() },
      vc = mt([
        Hr,
        lc,
        fc,
        new pt({
          scope: "cellophane",
          object: "renderImp",
          action: "enter",
          handler: async ({ account: t, customEvent: e }) => {
            if (void 0 === e.detail?.renderImpArgs)
              throw new Error("renderImpArgs must be defined.");
            const { bidID: n, doc: a } = e.detail.renderImpArgs,
              o = n ?? a.amzniid;
            if (void 0 === o) throw new Error("Invalid bID.");
            if (t.use(hc).has(o)) throw new Error("Targeting reuse detected.");
            return t.update(hc, (t) => t.add(o)), { status: s.completed };
          },
        }),
        new pt({
          scope: "cellophane",
          object: "setDisplayBids",
          action: "enter",
          handler: async () => ({ status: s.completed }),
        }),
      ]);
    var gc = new pt({
      scope: "regulations",
      object: "dsa",
      action: "define",
      validators: {
        detail: {
          detail: et,
          "detail.dsa": rt((t) => {
            try {
              JSON.stringify(t);
            } catch (t) {
              throw new Error("must be JSON stringifiable");
            }
          }),
        },
      },
      handler: async ({ account: t, customEvent: e }) => {
        const n = e.detail;
        if (void 0 === n)
          throw new Error("A dsa object is expected as parameter");
        const { dsa: a } = n;
        return (
          t.update(yr, () => a),
          { status: s.completed, analytics: { dsa: null != a ? yc(a) : 0 } }
        );
      },
    });
    const yc = (t) => JSON.stringify(t).length,
      wc = mt([pc, mc, gc, Er]),
      bc = { key: "documentReady/readyState", default: void 0 };
    var xc = new pt({
        scope: "window",
        object: "initialViewportHeight",
        action: "capture",
        validators: {
          context: {
            context: et,
            "context.window": et,
            "context.window.innerHeight": Z,
          },
        },
        handler: async ({ account: t, context: e }) => {
          if (void 0 !== t.use(rr))
            return {
              status: s.cancelled,
              analytics: { reason: "already_captured" },
            };
          const n = t.use(bc);
          if (void 0 === n || "loading" === n)
            return {
              status: s.cancelled,
              analytics: { reason: "dom_still_loading", readyState: n ?? null },
            };
          const a = e.window.innerHeight;
          return a < 0
            ? {
                status: s.cancelled,
                analytics: {
                  reason: "invalid_viewport_height",
                  viewportHeight: a,
                },
              }
            : (t.update(rr, () => a), { status: s.completed });
        },
      }),
      Ec = new pt({
        scope: "documentReady",
        object: "readyState",
        action: "didChange",
        handler: async ({ account: t }) => {
          const e = t.globalContext.document.readyState;
          return (
            t.update(bc, () => e),
            "loading" !== e && t.recordListenerNonBlocking(xc),
            { status: s.completed }
          );
        },
      }),
      Sc = new pt({
        scope: "documentReady",
        object: "eventListeners",
        action: "add",
        handler: async ({ account: t }) => (
          t.recordListenerNonBlocking(Ec),
          t.globalContext.document.addEventListener("readystatechange", () =>
            t.recordListenerNonBlocking(Ec, { source: i.webpage })
          ),
          { status: s.completed }
        ),
      });
    const _c = mt([Sc, Ec]),
      Rc = { key: "nativeCommerceAds/timings", default: [] },
      Ic = (t) => {
        if ("string" != typeof t) return !1;
        try {
          const { protocol: e } = new URL(t.trim());
          return "https:" === e || "http:" === e;
        } catch {
          return !1;
        }
      },
      Ac = (t) => {
        const e = /(.*\/x\/c\/[a-zA-Z0-9_-]*\/)(.*)(https.*)/;
        try {
          if (e.test(t)) {
            const n = e.exec(t);
            return null !== n &&
              n.length >= 3 &&
              n[2].startsWith("{") &&
              n[2].endsWith("}")
              ? `${n[1]}${encodeURI(n[2])}${n[3]}`
              : t;
          }
        } catch (e) {
          return t;
        }
        return t;
      };
    function kc(t) {
      const e = new Image();
      return (e.src = t), e;
    }
    const jc = (t, e, n) => {
        t.update(
          Rc,
          (t) => (t.push({ time: performance.now(), key: `${e}/${n}` }), t)
        );
      },
      $c = async (t, e) =>
        await new Promise((e) => {
          setTimeout(e, t);
        }).then(async () => await e),
      Cc = "NCA",
      Oc = { key: "nativeCommerceAds/asinPerRequest", default: 14 },
      Pc = { key: "nativeCommerceAds/asinProcessIter", default: 5 },
      Dc = { key: "nativeCommerceAds/asinProcessDelay", default: 250 },
      Tc = { key: "nativeCommerceAds/contextURL", default: void 0 },
      Nc = {
        key: "nativeCommerceAds/getAdsEndpoint",
        default: "https://c.aps.amazon-adsystem.com/e/dtb/custombid",
      },
      Lc = {
        key: "nativeCommerceAds/getAdsIsKey",
        default: "082f8778403939df819c59b1e735a614",
      },
      Mc = { key: "nativeCommerceAds/bidParams", default: {} },
      Uc = { key: "nativeCommerceAds/recordMaps", default: new Map() };
    var qc = new pt({
        scope: "nativeCommerceAds",
        object: "adMarkup",
        action: "append",
        validators: {
          detail: {
            detail: et,
            "detail.response": null,
            "detail.iteration": Z,
          },
        },
        handler: async ({ account: t, detail: e, customEvent: n }) => {
          const a = e.response,
            o = pe(
              t.globalContext.document,
              t.globalContext.navigator?.connection,
              t.globalContext.innerWidth,
              t.globalContext.innerHeight
            );
          return "loading" === t.use(bc)
            ? { status: s.waiting, analytics: { browserInfo: o } }
            : (null != a?.amznadm &&
                "" !== a?.amznadm &&
                (jc(t, Cc, `${e.iteration}:appendAdMarkup/start`),
                (function (t, e) {
                  const n = t.querySelector("a[data-aps-asin]") ?? void 0;
                  if (null == n) return;
                  const a = t.createElement("iframe");
                  (a.style.marginLeft = "0"),
                    (a.style.marginTop = "0"),
                    (a.style.height = "1px"),
                    (a.style.width = "1px"),
                    a.setAttribute("data-testid", "amzn-nca-ad"),
                    a.setAttribute("scrolling", "no"),
                    a.setAttribute("frameborder", "0"),
                    (a.srcdoc = e ?? ""),
                    n?.insertAdjacentElement("afterend", a);
                })(t.globalContext.document, a?.amznadm),
                jc(t, Cc, `${e.iteration}:appendAdMarkup/end`)),
              { status: s.completed, analytics: { browserInfo: o } });
        },
      }),
      Vc = new pt({
        scope: "nativeCommerceAds",
        object: "krypton",
        action: "didRespond",
        validators: {
          detail: {
            detail: et,
            "detail.response": null,
            "detail.iteration": Z,
            "detail.map": null,
          },
        },
        handler: async ({ account: t, detail: e, customEvent: n }) => {
          jc(t, Cc, `${e.iteration}:processKryptonResponse/start`);
          const a = pe(
              t.globalContext.document,
              t.globalContext.navigator?.connection,
              t.globalContext.innerWidth,
              t.globalContext.innerHeight
            ),
            o = e.response,
            i = e.map;
          if ("loading" === t.use(bc))
            return {
              status: s.waiting,
              value: { didRespond: !1 },
              analytics: { browserInfo: a },
            };
          if (!Array.isArray(o?.slotBids) || 0 === o?.slotBids.length)
            return (
              jc(t, Cc, `${e.iteration}:processKryptonResponse/empty`),
              {
                status: s.cancelled,
                value: { didRespond: !1 },
                analytics: { browserInfo: a },
              }
            );
          const r = t.use(Uc);
          let c = 0;
          for (const e of o.slotBids) {
            const n = e.asin;
            if ("" !== n && null != n) {
              const t = r.get(n) ?? {
                apsAsin: "",
                apsAscTag: "",
                apsAscSubtag: "",
                response: void 0,
                elementStatus: new Map(),
              };
              r.set(n, {
                ...t,
                clickUrl: e.clickUrl,
                impUrl: e.impUrl,
                tqUrl: e.tqUrl,
              });
            }
            "r" === e.mode && (await Fc(t, e, i)) && c++;
          }
          return (
            t.update(Uc, () => r),
            jc(t, Cc, `${e.iteration}:processKryptonResponse/end`),
            {
              status: s.completed,
              value: { didRespond: !0 },
              analytics: { browserInfo: a, rejectedClickUrls: c },
            }
          );
        },
      });
    async function Fc(t, e, n) {
      const a = async (e, n) => {
        try {
          const a = "nativeCommerceAds/clickUrl/update",
            o = t.read("listeners"),
            i = o?.get(a);
          if (void 0 !== i) {
            const o = await t.record(a, { url: e, element: n });
            return Ic(o.url) ? o.url : e;
          }
        } catch (t) {}
        return e;
      };
      if (!Ic(e.clickUrl)) return !0;
      if (null == n) {
        n = new Map();
        const a = Array.from(
          t.globalContext.document.querySelectorAll("a[data-aps-asin]")
        ).filter((t) => t.dataset.apsAsin === e.asin);
        n.set(e.asin, a);
      }
      if (n.has(e.asin)) {
        const t = n.get(e.asin) ?? [];
        for (const n of t)
          Ic(e.impUrl) && kc(e.impUrl),
            (n.href = await a(Ac(e.clickUrl), n)),
            n.setAttribute("data-aps-status", "success");
      }
      return !1;
    }
    var Bc = new pt({
      scope: "nativeCommerceAds",
      object: "krypton",
      action: "fetch",
      validators: {
        detail: { detail: et, "detail.bidUrl": X, "detail.iteration": Z },
      },
      handler: async ({ account: t, detail: e, customEvent: n }) => {
        jc(t, Cc, `${e.iteration}:fetchKryptonResponse/start`);
        const a = await (
          await fetch(e.bidUrl, { credentials: "include" })
        ).json();
        return (
          jc(t, Cc, `${e.iteration}:fetchKryptonResponse/end`),
          {
            status: s.completed,
            value: { kryptonResponse: a },
            analytics: {
              browserInfo: pe(
                t.globalContext.document,
                t.globalContext.navigator?.connection,
                t.globalContext.innerWidth,
                t.globalContext.innerHeight
              ),
            },
          }
        );
      },
    });
    const zc = { key: "nativeCommerceAds/injectTQ", default: void 0 },
      Jc = {
        key: "nativeCommerceAds/tqLibUrl",
        default: "https://c.aps.amazon-adsystem.com/tqsmartpixel.js",
      };
    var Hc = new pt({
        scope: "nativeCommerceAds",
        object: "trafficQuality",
        action: "load",
        validators: { detail: { detail: et, "detail.iteration": Z } },
        handler: async ({ account: t, detail: e }) => {
          const n = pe(
              t.globalContext.document,
              t.globalContext.navigator?.connection,
              t.globalContext.innerWidth,
              t.globalContext.innerHeight
            ),
            a = t.use(Jc);
          return (
            null != t.use(zc) ||
              (jc(t, Cc, `${e.iteration}:loadTQModule/start`),
              await import(a).then((n) => {
                t.update(zc, () => n),
                  jc(t, Cc, `${e.iteration}:loadTQModule/end`);
              })),
            { status: s.completed, analytics: { browserInfo: n } }
          );
        },
      }),
      Gc = new pt({
        scope: "nativeCommerceAds",
        object: "trafficQualityUrls",
        action: "process",
        validators: {
          detail: {
            detail: et,
            "detail.response": null,
            "detail.iteration": Z,
          },
        },
        handler: async ({ account: t, detail: e, customEvent: n }) => {
          const a = pe(
              t.globalContext.document,
              t.globalContext.navigator?.connection,
              t.globalContext.innerWidth,
              t.globalContext.innerHeight
            ),
            o = e.response;
          if (!Array.isArray(o?.slotBids) || 0 === o?.slotBids.length)
            return {
              status: s.cancelled,
              value: { isProcessed: !1 },
              analytics: { browserInfo: a },
            };
          const i = o?.slotBids.map((t) => t.tqUrl);
          return (
            await t.recordListener(Hc, { iteration: e.iteration }).then(() => {
              jc(t, Cc, `${e.iteration}:injectTQ/start`);
              const n = t.use(zc);
              i.forEach((t) => n?.default?.(t)),
                jc(t, Cc, `${e.iteration}:injectTQ/end`);
            }),
            {
              status: s.completed,
              value: { isProcessed: !0 },
              analytics: { browserInfo: a },
            }
          );
        },
      }),
      Kc = new pt({
        scope: "nativeCommerceAds",
        object: "ads",
        action: "get",
        validators: {
          detail: {
            detail: et,
            "detail.nativeContentConfig": null,
            "detail.iteration": Z,
            "detail.asinMap": null,
          },
        },
        handler: async ({ account: t, detail: e, systemAccount: n }) => (
          await (async function (t, e, n, a, o) {
            const i = t.id,
              s = 36 === t.id.length;
            let r = {
              src: i,
              pubid: i,
              u: Qc(t, t.use(Tc)),
              sg: encodeURIComponent(JSON.stringify(Wc(t, e))),
              pj: encodeURIComponent(JSON.stringify({ is: t.use(Lc) })),
              pid: Yc(a),
            };
            s && (r.src = "600"), (r = { ...r, ...t.use(Mc) });
            const c = Object.keys(r)
                .filter(
                  (t) => "undefined" !== r[t] && "" !== r[t] && null !== r[t]
                )
                .map((t) => {
                  const e = r[t];
                  return void 0 !== e ? `${t}=${String(e)}` : null;
                })
                .filter((t) => null !== t)
                .join("&"),
              d = t.use(Uc);
            e.sourceAsins?.forEach((t) => {
              "object" == typeof t &&
                null !== t &&
                d.set(t.apsAsin, { ...t, elements: o?.get(t.apsAsin) });
            }),
              t.update(Uc, () => d);
            const { kryptonResponse: l } = await t.recordListener(Bc, {
              bidUrl: `${t.use(Nc)}?${c}`,
              iteration: n,
            });
            await Promise.all([
              t.recordListener(Vc, { response: l, iteration: n, map: o }),
              t.recordListener(Gc, { response: l, iteration: n }),
              t.recordListener(qc, { response: l, iteration: n }),
            ]);
          })(t, e.nativeContentConfig, e.iteration, n, e.asinMap),
          {
            status: s.completed,
            analytics: {
              browserInfo: pe(
                t.globalContext.document,
                t.globalContext.navigator?.connection,
                t.globalContext.innerWidth,
                t.globalContext.innerHeight
              ),
            },
          }
        ),
      });
    function Wc(t, e) {
      const n = { ortb2: {} },
        a = (function (t) {
          try {
            const e = t.use(xe);
            if (void 0 !== e && "user" in e) {
              const { user: t, ...n } = e;
              return { ortb2: n };
            }
            return { ortb2: e };
          } catch (t) {
            return {};
          }
        })(t);
      return (
        (n.ortb2 = a.ortb2),
        (n.ortb2 = {
          ...(n.ortb2 ?? {}),
          site: {
            ...(n.ortb2?.site ?? {}),
            ext: { ...(n.ortb2?.site?.ext ?? {}), ...e },
          },
        }),
        n
      );
    }
    function Qc(t, e) {
      try {
        const n =
          e ??
          (function (t) {
            try {
              if (void 0 !== t.globalContext.top?.location.href)
                return t.globalContext.top?.location.href;
            } catch (t) {}
            try {
              if (t.globalContext.top !== t.globalContext.self)
                return t.globalContext.document.referrer;
            } catch (t) {}
          })(t);
        if (void 0 !== n) return encodeURIComponent(n);
      } catch (t) {}
      return "";
    }
    function Yc(t) {
      return t.store.get(b);
    }
    const Zc = ["apsStatus"];
    var Xc = new pt({
      scope: "nativeCommerceAds",
      object: "service",
      action: "enable",
      validators: {},
      handler: async ({ account: t, detail: e, customEvent: n }) => {
        const a = pe(
          t.globalContext.document,
          t.globalContext.navigator?.connection,
          t.globalContext.innerWidth,
          t.globalContext.innerHeight
        );
        if ("loading" === t.use(bc))
          return { status: s.waiting, analytics: { browserInfo: a } };
        await td(t, 0);
        const o = t.use(Dc);
        for (let e = 1; e <= t.use(Pc); e++) await $c(o, td(t, e));
        return { status: s.completed, analytics: { browserInfo: a } };
      },
    });
    const td = async (t, e = 0) => {
        const n = nd(t, e);
        if (0 === n.size) return await Promise.resolve();
        const a = [];
        ((t, e) => {
          const n = [];
          for (let a = 0; a < t.length; a += e) n.push(t.slice(a, a + e));
          return n;
        })(Array.from(n.keys()), t.use(Oc)).forEach((t) =>
          a.push({ sourceAsins: t.map((t) => ed((n.get(t) ?? [])[0])) })
        );
        const o = [];
        for (const i of a)
          o.push(
            t.recordListener(Kc, {
              nativeContentConfig: i,
              iteration: e,
              asinMap: n,
            })
          );
        return await Promise.all(o).then(() => {});
      },
      ed = (t) => {
        const e = {};
        return (
          void 0 !== t &&
            Object.keys(t.dataset)
              .filter(
                (e) => e.startsWith("aps") && !Zc.includes(e) && t.dataset[e]
              )
              .forEach((n) => (e[n] = t.dataset[n])),
          e
        );
      },
      nd = (t, e = 0) => {
        jc(t, Cc, `${e}:fetchEligibleElements/start`);
        let n = 0;
        const a = Array.from(
          t.globalContext.document.querySelectorAll("a[data-aps-asin]")
        )
          .map((t) => t)
          .filter(
            (t) =>
              ((t) =>
                null !== t.dataset.apsAsin &&
                void 0 !== t.dataset.apsAsin &&
                "" !== t.dataset.apsAsin &&
                "null" !== t.dataset.apsAsin)(t) &&
              "read" !== t.dataset.apsStatus &&
              "success" !== t.dataset.apsStatus
          )
          .reduce((t, e) => {
            const a = e.dataset.apsAsin;
            return (
              void 0 !== a &&
                (void 0 === t.get(a) && t.set(a, []),
                t.get(a)?.push(e),
                e.setAttribute("data-aps-status", "read"),
                n++),
              t
            );
          }, new Map());
        return (
          0 === a.size
            ? jc(t, Cc, `${e}:fetchEligibleElements/empty`)
            : jc(
                t,
                Cc,
                `${e}:fetchEligibleElements/asins/${a.size}/elements/${n}`
              ),
          a
        );
      },
      ad = mt([Xc, Kc, qc, Vc, Gc, Bc, Hc]);
    var od = new pt({
        scope: "googleAdManagerSlotRequested",
        object: "slotRequestedEvent",
        action: "didTrigger",
        validators: {
          detail: {
            detail: et,
            "detail.event": et,
            "detail.event.slot": et,
            "detail.event.slot.getSizes": ct,
            "detail.event.slot.getSizes()": ot,
            "detail.event.slot.getSizes()[]": at([X, et]),
            "detail.event.slot.getSizes()[].width": Z,
            "detail.event.slot.getSizes()[].height": Z,
            "detail.event.slot.getSizes()[].name": rt(X),
            "detail.event.slot.getSlotId": ct,
            "detail.event.slot.getSlotId()": et,
            "detail.event.slot.getSlotId().getDomId": ct,
            "detail.event.slot.getSlotId().getDomId()": X,
            "detail.event.slot.getSlotId().getName": ct,
            "detail.event.slot.getSlotId().getName()": X,
            "detail.event.slot.getTargeting": ct,
          },
        },
        handler: async ({ account: t, detail: e }) => {
          const n = e.event.slot,
            a = t.use(Ai),
            o = n.getSlotId().getDomId(),
            i = n.getSlotId().getName(),
            r = n
              .getSizes()
              .map((t) =>
                "object" == typeof t &&
                null !== t &&
                "width" in t &&
                "height" in t
                  ? { ...t }
                  : t
              ),
            { mediaType: c, hasMatchingSlot: d } = (function (t, e) {
              const n = e.get(t),
                a = Boolean(n);
              if (!a) return { mediaType: "unknown", hasMatchingSlot: a };
              let o;
              return (
                (o =
                  n?.banner && n.video
                    ? ti.MultiFormat
                    : n?.video
                    ? ti.Video
                    : ti.Display),
                { mediaType: o, hasMatchingSlot: a }
              );
            })(o, a),
            l = { mediaType: c, slotId: o, slotName: i, slotSizes: r };
          return d
            ? (t.record(
                "googleAdManagerSlotRequested/matchingSlotDefinition/didExist",
                { analytics: l }
              ),
              (function (t, e) {
                return e.use(Is).has(t);
              })(o, t)
                ? (t.record(
                    "googleAdManagerSlotRequested/matchingBidRequest/didExist",
                    { analytics: l }
                  ),
                  (function (t, e) {
                    return e.use(jr).has(t);
                  })(o, t)
                    ? (t.record(
                        "googleAdManagerSlotRequested/matchingBidResponse/didExist",
                        { analytics: l }
                      ),
                      { status: s.completed })
                    : (t.record(
                        "googleAdManagerSlotRequested/matchingBidResponse/didNotExist",
                        { analytics: l }
                      ),
                      { status: s.completed }))
                : (t.record(
                    "googleAdManagerSlotRequested/matchingBidRequest/didNotExist",
                    { analytics: l }
                  ),
                  { status: s.completed }))
            : (t.record(
                "googleAdManagerSlotRequested/matchingSlotDefinition/didNotExist",
                { analytics: l }
              ),
              { status: s.completed });
        },
      }),
      id = new pt({
        scope: "googlePublisherTag",
        object: "slotRequestedEvent",
        action: "listen",
        handler: async ({ account: t }) =>
          void 0 === t.globalContext.googletag?.cmd
            ? { status: s.waiting }
            : (t.globalContext.googletag.cmd.push(function () {
                if (void 0 === t.globalContext.googletag?.pubads)
                  throw new Error("Undefined googletag.pubads");
                t.globalContext.googletag
                  ?.pubads()
                  .addEventListener("slotRequested", (e) => {
                    t.recordListener(od, { event: e });
                  });
              }),
              { status: s.completed }),
      });
    const sd = mt([id, od]),
      rd = mt([cc, cr]),
      cd = mt([Ga, Ka]),
      dd = mt([
        new pt({
          scope: "gpid",
          object: "autoGeneration",
          action: "disable",
          validators: { detail: { detail: et }, context: { context: et } },
          handler: async ({ account: t }) => (
            t.update(Ps, () => !0), { status: s.completed }
          ),
        }),
        Ls,
        Us,
      ]),
      ld = mt([
        new pt({
          scope: "ad",
          object: "gpid",
          action: "define",
          validators: { detail: { detail: et, "detail.map": lt } },
          handler: async ({ account: t, detail: e }) => {
            var n;
            return (
              (n = e.map),
              Object.entries(n).forEach(([t, e]) => {
                if ("string" != typeof t || "string" != typeof e)
                  throw new Error(
                    `Invalid GPID mapping: key and value must be strings. Got key: ${typeof t}, value: ${typeof e}`
                  );
              }),
              t.update(qs, (t) => ({ ...t, ...e.map })),
              { status: s.completed }
            );
          },
        }),
      ]),
      ud = ["primary", "canary"],
      pd = mt([
        new pt({
          scope: "prebidAdapter",
          object: "roleConfiguration",
          action: "update",
          validators: {
            detail: {
              detail: et,
              "detail.toJSON": ut,
              "detail.roleInstructions": et,
              "detail.roleInstructions.toJSON": ut,
              "detail.roleInstructions.prebid": it(ud),
              "detail.roleInstructions.prebid.toJSON": ut,
              "detail.roleInstructions.webclient": it(ud),
              "detail.roleInstructions.webclient.toJSON": ut,
              "detail.canaryRate": nt({ min: 0, max: 1 }),
            },
            context: { context: st(et), "context.aps_prebid": rt(lt) },
          },
          handler: async ({ detail: t, context: e, account: n }) => {
            e.aps_prebid || (e.aps_prebid = {});
            const a = {
              roleInstructions: {
                prebid: t.roleInstructions.prebid,
                webclient: t.roleInstructions.webclient,
              },
              canaryRate: t.canaryRate,
            };
            return (e.aps_prebid[n.id] = a), { status: s.completed };
          },
        }),
      ]),
      md = mt([Es]),
      fd = mt([xc]),
      hd = new (class {
        select(t) {
          return t.length ? t[Math.floor(Math.random() * t.length)] : void 0;
        }
      })();
    class vd {
      static getEnabledFormats(t, e) {
        const n = e
            .replace(/\/$/, "")
            .replace(/^https?:\/\//, "")
            .replace(/^www\./, "")
            .replace(/#.*$/, "")
            .toLowerCase(),
          a = Object.entries(t).sort(([t], [e]) => {
            const n = t.length - (t.match(/\*/g) || []).length;
            return e.length - (e.match(/\*/g) || []).length - n;
          });
        for (const [t, e] of a) {
          if ("*" === t) return [...e];
          const a = t
            .replace(/^https?:\/\//, "")
            .replace(/^www\./, "")
            .replace(/[.+?^${}()|[\]\\]/g, "\\$&")
            .replace(/^\*\\\./, "([^.]+\\.)*")
            .replace(/\/\*/g, "/.+")
            .replace(/\*/g, "[^/]*");
          if (new RegExp(`^${a}(?:\\?[^#]*)?(?:#.*)?$`).test(n)) return [...e];
        }
        return [];
      }
    }
    (vd.selectFormat = (t) => hd.select(t)),
      new pt({
        scope: "customFormats",
        object: "ad",
        action: "fetch",
        validators: {
          detail: {
            detail: et,
            "detail.amzniid": X,
            "detail.amznbid": X,
            "detail.amznp": X,
            "detail.amznhost": X,
          },
        },
        handler: async ({ account: t, systemAccount: e, detail: n }) => {
          const a = new URL(`${n.amznhost}/e/dtb/admi`),
            o = e.store.get(b);
          a.searchParams.set("b", n.amzniid),
            a.searchParams.set("rnd", o),
            a.searchParams.set("pp", n.amznbid),
            a.searchParams.set("p", n.amznp);
          const i = await t.globalContext.fetch(a.toString(), {
            method: "GET",
            headers: { Accept: "application/json" },
          });
          if (!i.ok)
            throw new Error(
              `Ad markup request failed with status ${i.status}.`
            );
          const r = await i.text();
          return { status: s.completed, value: { ad: { adHtml: r } } };
        },
      }),
      new pt({
        scope: "customFormats",
        object: "slot",
        action: "define",
        validators: {
          detail: {
            detail: et,
            "detail.slotID": X,
            "detail.w": Z,
            "detail.h": Z,
          },
        },
        handler: async ({ account: t, detail: e }) => {
          const n = { id: e.slotID, banner: { format: [{ w: e.w, h: e.h }] } };
          return (
            await t.recordListener(cc, { imp: [n] }), { status: s.completed }
          );
        },
      }),
      new pt({
        scope: "customFormats",
        object: "targeting",
        action: "fetch",
        validators: { detail: { detail: et, "detail.slotID": X } },
        handler: async ({ account: t, detail: e }) => (
          await t.record(Pi, { itemIds: [e.slotID] }), { status: s.completed }
        ),
      });
    const gd = { key: "customFormats/enabledFormats", default: [] },
      yd = {
        key: "customFormats/microClientUrl",
        default:
          "https://client.aps.amazon-adsystem.com/publisher-custom_formats.js",
      },
      wd = mt([
        new pt({
          scope: "customFormats",
          object: "client",
          action: "bootstrap",
          validators: {
            detail: {
              detail: et,
              "detail.config": et,
              "detail.config.pages": lt,
              "detail.config.pages.key()": X,
              "detail.config.pages.*": ot,
              "detail.config.pages.*[]": X,
            },
          },
          handler: async ({ account: t, detail: e }) => {
            const n = t.use(ht);
            if (!n) return { status: s.waiting };
            if ("US" !== n) return { status: s.cancelled };
            const a = e.config,
              o = vd.getEnabledFormats(a.pages, t.globalContext.location.href);
            if (0 === o.length)
              throw new Error("No enabled custom formats for this page.");
            return (
              t.update(gd, () => o),
              (function (t) {
                const e = t.globalContext.document,
                  n = e.createElement("script");
                (n.src = t.use(yd)), (n.async = !0), e.head.appendChild(n);
              })(t),
              { status: s.completed }
            );
          },
        }),
      ]),
      bd = "publisher";
    !(function (t = {}) {
      const { ut: e, yt: n } = { ...J, ...t };
      try {
        e(() => {
          !(function (t = {}) {
            const { ft: e, vt: n, gt: a, yt: o } = { ...J, ...t };
            try {
              const o = e();
              if (void 0 === o || 0 === o.length) return;
              !(function (t, e) {
                if (!e()) {
                  z(F.postulate, t);
                  let n = `Assertion failed: ${e.toString()}`;
                  throw (t && (n += ` - ${t}`), new Error(n));
                }
              })("5c098d", () => Array.isArray(o));
              const i = (function (t) {
                return t.shift();
              })(o);
              if (void 0 === i) return;
              n(F.postulate, i.hash, a(i.context, t.ht || J.ht));
            } catch (t) {
              o(t);
            }
          })({ ...J, ...t });
        }, 3e3);
      } catch (t) {
        n(t);
      }
    })();
    try {
      yt.fireReferencePixel(bd);
      const t = new Map([
          ...xt,
          ...qi,
          ...fo,
          ...Li,
          ...mi,
          ...wt,
          ...Bi,
          ...vi,
          ...je,
          ...Ao,
          ...Ji,
          ...Yi,
          ...gn,
          ...io,
          ...So,
          ...Dt,
          ...re,
          ...bo,
          ...ao,
          ...Jr,
          ...vc,
          ...Bo,
          ...pi,
          ...wc,
          ..._c,
          ...ad,
          ...sd,
          ...rd,
          ...cd,
          ...dd,
          ...ld,
          ...Wt,
          ...wd,
          ...pd,
          ...md,
          ...fd,
        ]),
        e = new V(),
        n = e.registerEventSource(bd);
      n.recordListener(Eo, { restrictions: { block: { accounts: [v] } } }),
        n.recordListener(Sc, { restrictions: { block: { accounts: [v] } } }),
        n.recordListener(id, { restrictions: { block: { accounts: [v] } } }),
        n.recordListener(Pt, { restrictions: { block: { accounts: [v] } } }),
        n.recordListener(It, { restrictions: { block: { accounts: [v] } } }),
        n.recordListener(yo, { restrictions: { block: { accounts: [v] } } }),
        n.recordListener(Un, { restrictions: { block: { accounts: [v] } } }),
        e.load({ listeners: t });
    } catch (t) {
      yt.logCoreError({ id: bd, error: t, account: null }), j() && R.error(t);
    }
  })();
  /*! @amzn/apswebapstaglibrary - apstag-legacy_eu - 26.1102.1713 */
  !(function (t) {
    var e = {};
    function n(r) {
      var o;
      return (
        e[r] ||
        ((o = e[r] = { i: r, l: !1, exports: {} }),
        t[r].call(o.exports, o, o.exports, n),
        (o.l = !0),
        o)
      ).exports;
    }
    (n.m = t),
      (n.c = e),
      (n.d = function (t, e, r) {
        n.o(t, e) || Object.defineProperty(t, e, { enumerable: !0, get: r });
      }),
      (n.r = function (t) {
        "undefined" != typeof Symbol &&
          Symbol.toStringTag &&
          Object.defineProperty(t, Symbol.toStringTag, { value: "Module" }),
          Object.defineProperty(t, "__esModule", { value: !0 });
      }),
      (n.t = function (t, e) {
        if ((1 & e && (t = n(t)), 8 & e)) return t;
        if (4 & e && "object" == typeof t && t && t.__esModule) return t;
        var r = Object.create(null);
        if (
          (n.r(r),
          Object.defineProperty(r, "default", { enumerable: !0, value: t }),
          2 & e && "string" != typeof t)
        )
          for (var o in t)
            n.d(
              r,
              o,
              function (e) {
                return t[e];
              }.bind(null, o)
            );
        return r;
      }),
      (n.n = function (t) {
        var e =
          t && t.__esModule
            ? function () {
                return t.default;
              }
            : function () {
                return t;
              };
        return n.d(e, "a", e), e;
      }),
      (n.o = function (t, e) {
        return Object.prototype.hasOwnProperty.call(t, e);
      }),
      (n.p = ""),
      n((n.s = 37));
  })([
    function (t, e, n) {
      "use strict";
      function r(t) {
        return (r =
          "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
            ? function (t) {
                return typeof t;
              }
            : function (t) {
                return t &&
                  "function" == typeof Symbol &&
                  t.constructor === Symbol &&
                  t !== Symbol.prototype
                  ? "symbol"
                  : typeof t;
              })(t);
      }
      function o(t) {
        try {
          var e = parseInt(t, 10);
          if (!isNaN(e))
            return !(e <= 0) && (100 <= e || 100 * Math.random() <= e);
        } catch (t) {}
        return !1;
      }
      function i() {
        return "".concat(Math.round(1e12 * Math.random())).concat(Date.now());
      }
      function a(t) {
        for (
          var e =
              "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",
            n = new Array(t),
            r = 0;
          r < t;
          r++
        )
          n[r] = e[Math.floor(Math.random() * e.length)];
        return n.join("");
      }
      function c(t) {
        return "object" === r(t) && null !== t;
      }
      function s(t) {
        return "[object Array]" === Object.prototype.toString.call(t);
      }
      function u(t, e) {
        return c(t) && void 0 !== t[e] && "" !== t[e];
      }
      function l(t, e) {
        return -1 !== t.indexOf(e);
      }
      function f(t) {
        var e = new Date();
        return e.setDate(e.getDate() + t), e.toUTCString();
      }
      function d(t) {
        try {
          var e =
              t.innerWidth ||
              t.document.documentElement.clientWidth ||
              t.document.body.clientWidth,
            n =
              t.innerHeight ||
              t.document.documentElement.clientHeight ||
              t.document.body.clientHeight;
          return "".concat(e, "x").concat(n);
        } catch (t) {}
        return "x";
      }
      function b(t, e) {
        return (
          decodeURIComponent(t).split("?")[0].split("#")[0] ===
          decodeURIComponent(e).split("?")[0].split("#")[0]
        );
      }
      function p(t) {
        var e = Object.keys(t);
        return (
          e.filter(function (e) {
            return t[e];
          }).length === e.length
        );
      }
      n.d(e, "k", function () {
        return o;
      }),
        n.d(e, "c", function () {
          return i;
        }),
        n.d(e, "d", function () {
          return a;
        }),
        n.d(e, "i", function () {
          return c;
        }),
        n.d(e, "h", function () {
          return s;
        }),
        n.d(e, "j", function () {
          return u;
        }),
        n.d(e, "g", function () {
          return l;
        }),
        n.d(e, "e", function () {
          return f;
        }),
        n.d(e, "f", function () {
          return d;
        }),
        n.d(e, "b", function () {
          return b;
        }),
        n.d(e, "a", function () {
          return p;
        });
    },
    function (t, e, n) {
      "use strict";
      n.d(e, "b", function () {
        return f;
      }),
        n.d(e, "c", function () {
          return d;
        }),
        n.d(e, "d", function () {
          return b;
        }),
        n.d(e, "a", function () {
          return p;
        });
      e = n(0);
      var r = n(2),
        o = n(7),
        i = n(8),
        a = n(15),
        c = n(3),
        s = Object(e.k)(10),
        u = [],
        l =
          (!0 === Object(o.c)("exposeErrors") && (window.apstagErrors = u),
          function (t, e, n) {
            try {
              var r = Date.now(),
                o = {
                  eventSource: "apstag",
                  eventTime: r,
                  eventCategory: "error",
                  eventName: null != n ? n : "unknown",
                  eventProperties: {
                    accountID: t,
                    libraryVersion: c.l,
                    url: Object(i.f)(window),
                    error: {
                      name: "string" == typeof e ? e : e.name,
                      message: "string" == typeof e ? e : e.message,
                    },
                  },
                },
                a = { Data: window.btoa(JSON.stringify(o)), PartitionKey: r };
              fetch(
                "https://prod.tahoe-analytics.publishers.advertising.a2z.com/logevent/putRecords?encoded=true",
                {
                  method: "POST",
                  headers: {
                    "Content-Type": "application/json",
                    "x-api-key":
                      "5e0b19374596b1c8abfb0560fcb956220131d0a7f7100979de5d18cfada355d5",
                  },
                  body: JSON.stringify({ Records: [a] }),
                }
              ).catch(function () {});
            } catch (t) {}
          });
      function f(t, e, n) {
        try {
          ((null != n && n.makeVisibleToAllUsers) || Object(o.d)("errors")) &&
            console.error(t);
          var c,
            f,
            d = {
              ts: Date.now(),
              url: encodeURIComponent(Object(i.f)(window)),
              r: encodeURIComponent(Object(i.g)(window)),
              _type: "apsLibraryError",
              e: { et: t.name, el: e, msg: t.message },
            };
          return (
            u.push(d),
            r.a.dispatch({ type: "LOG_ERROR", error: d }),
            Math.random() <= 0.001 &&
              ((f =
                null != (c = null == n ? void 0 : n.accountId)
                  ? c
                  : Object(a.unsafelyGuessAccountID)()),
              l(f, t, e)),
            !!s
          );
        } catch (t) {
          console.error(t);
        }
        return !1;
      }
      function d(t, e, n, r) {
        return f(
          {
            name: e,
            message: ""
              .concat(t, " was of type '")
              .concat(e, "' instead of '")
              .concat(n, "'"),
          },
          "TypeError-".concat(t),
          r
        );
      }
      function b(t, e) {
        return function () {
          try {
            return t.apply(null, arguments);
          } catch (t) {
            return f(t, e, { makeVisibleToAllUsers: !0 }), null;
          }
        };
      }
      function p(t) {
        ((1 < arguments.length && void 0 !== arguments[1] && arguments[1]) ||
          Object(o.d)("errors")) &&
          console.warn(t);
      }
    },
    function (t, e, n) {
      "use strict";
      n.d(e, "a", function () {
        return p;
      });
      var r,
        o = n(3),
        i = ((e = n(6)), n(0));
      n = n(7);
      function a(t) {
        return (a =
          "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
            ? function (t) {
                return typeof t;
              }
            : function (t) {
                return t &&
                  "function" == typeof Symbol &&
                  t.constructor === Symbol &&
                  t !== Symbol.prototype
                  ? "symbol"
                  : typeof t;
              })(t);
      }
      function c(t, e) {
        var n,
          r = Object.keys(t);
        return (
          Object.getOwnPropertySymbols &&
            ((n = Object.getOwnPropertySymbols(t)),
            e &&
              (n = n.filter(function (e) {
                return Object.getOwnPropertyDescriptor(t, e).enumerable;
              })),
            r.push.apply(r, n)),
          r
        );
      }
      function s(t) {
        for (var e = 1; e < arguments.length; e++) {
          var n = null != arguments[e] ? arguments[e] : {};
          e % 2
            ? c(Object(n), !0).forEach(function (e) {
                u(t, e, n[e]);
              })
            : Object.getOwnPropertyDescriptors
            ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n))
            : c(Object(n)).forEach(function (e) {
                Object.defineProperty(
                  t,
                  e,
                  Object.getOwnPropertyDescriptor(n, e)
                );
              });
        }
        return t;
      }
      function u(t, e, n) {
        return (
          (e = (function (t) {
            return (
              (t = (function (t, e) {
                if ("object" !== a(t) || null === t) return t;
                var n = t[Symbol.toPrimitive];
                if (void 0 === n) return String(t);
                if ("object" !== a((n = n.call(t, e)))) return n;
                throw new TypeError(
                  "@@toPrimitive must return a primitive value."
                );
              })(t, "string")),
              "symbol" === a(t) ? t : String(t)
            );
          })(e)) in t
            ? Object.defineProperty(t, e, {
                value: n,
                enumerable: !0,
                configurable: !0,
                writable: !0,
              })
            : (t[e] = n),
          t
        );
      }
      function l(t) {
        return (
          (function (t) {
            if (Array.isArray(t)) return f(t);
          })(t) ||
          (function (t) {
            if (
              ("undefined" != typeof Symbol && null != t[Symbol.iterator]) ||
              null != t["@@iterator"]
            )
              return Array.from(t);
          })(t) ||
          (function (t, e) {
            var n;
            if (t)
              return "string" == typeof t
                ? f(t, e)
                : "Map" ===
                    (n =
                      "Object" ===
                        (n = Object.prototype.toString.call(t).slice(8, -1)) &&
                      t.constructor
                        ? t.constructor.name
                        : n) || "Set" === n
                ? Array.from(t)
                : "Arguments" === n ||
                  /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)
                ? f(t, e)
                : void 0;
          })(t) ||
          (function () {
            throw new TypeError(
              "Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."
            );
          })()
        );
      }
      function f(t, e) {
        (null == e || e > t.length) && (e = t.length);
        for (var n = 0, r = new Array(e); n < e; n++) r[n] = t[n];
        return r;
      }
      var d = {
        AAXReqs: [],
        aaxViewabilityEnabled: !1,
        bidConfigs: {},
        bidReqs: {},
        bsPixels: {},
        cfg: {
          v: -1,
          CSM_JS: "//c.amazon-adsystem.com/aax2/csm.js.gz",
          CSM_RTB_COMMUNICATOR_JS: "".concat(
            o.v,
            "c.amazon-adsystem.com/bao-csm/aps-comm/aps_csm.js"
          ),
          DEBUG_APP_HTML: "//c.amazon-adsystem.com/aax2/debugApp.html",
          DEBUG_APP_HTML_V2: "//c.amazon-adsystem.com/aax2/debug_app_v2.html",
          DEFAULT_TIMEOUT: 2e3,
          DTB_PATH: "/e/dtb",
          TEST_PATH_FREQUENCY: 0,
          TEST_BID_ENDPOINT: null,
          TEST_PATH_LATENCY_SAMPLE_RATE: null,
          PIXEL_PATH: "/x/px/",
          LATENCY_SAMPLING_RATE: 1,
          COOKIE_MATCH_DELAY: 0,
          MAX_SLOTS_PER_REQUEST: 1,
          SLOT_RENDER_SAMPLING_RATE: 1,
          FEATURE_SAMPLING_RATE: 1,
          CONFIG_CALL_ENABLED: !1,
          LIB_CONFIG_PATH: "/cdn/prod/config",
        },
        cmpFired: !1,
        config: { pubID: "" },
        displayAdServer: {
          noBidSlotIDs: [],
          shouldSampleRender: !1,
          slotRenderEndedSet: !1,
        },
        errors: [],
        eventLog: [],
        experiments: {},
        gamSlotFetchLog: [],
        gamSlotRenderPixel: { aaxReqOffset: 0, gamSlotFetchLogOffset: 0 },
        hosts: {
          DEFAULT_AAX_BID_HOST: "aax.amazon-adsystem.com",
          DEFAULT_AAX_PIXEL_HOST: "aax.amazon-adsystem.com",
          DEFAULT_CXM_HOST: "c.amazon-adsystem.com",
        },
        identityState: {},
        libraryLoadCallLatency: 0,
        Q: [],
        slotBids: {},
        targetingKeys: {},
        tcfParseTime: 0,
        outstream: { renderStart: 0, shouldSample: !1 },
        consentManagementPlatform: {},
      };
      function b() {
        var t =
            0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : d,
          e = 1 < arguments.length ? arguments[1] : void 0;
        return {
          AAXReqs: (function (t, e) {
            switch (e.type) {
              case "RECORD_AAX_REQUEST":
                return [].concat(l(t), [e.data]);
              case "RECORD_AAX_REQ_PROP":
                return t.map(function (t) {
                  return (
                    (t = s({}, t)).bidReqID === e.bidReqID &&
                      (t[e.key] = e.value),
                    t
                  );
                });
              default:
                return l(t);
            }
          })(t.AAXReqs, e),
          aaxViewabilityEnabled: (function (t, e) {
            return "SET_VIEWABILITY" !== e.type ? t : e.viewability;
          })(t.aaxViewabilityEnabled, e),
          bidConfigs: (function (t, e) {
            return "RECORD_ORIGINAL_BID_CONFIG" !== e.type
              ? s({}, t)
              : s(s({}, t), {}, u({}, e.bidConfig.bidReqID, e.bidConfig));
          })(t.bidConfigs, e),
          bidReqs: (function (t, e) {
            var n;
            switch (e.type) {
              case "ADD_CHUNKED_REQUESTS":
                return s(
                  s({}, t),
                  {},
                  u(
                    {},
                    e.fid,
                    s(
                      s({}, t[e.fid]),
                      {},
                      { networkReqs: new Array(e.numChunks) }
                    )
                  )
                );
              case "NEW_FETCH_BID_REQUEST":
                return s(
                  s({}, t),
                  {},
                  u({}, e.fid, {
                    pto: e.pto,
                    hasCallbackExecuted: !1,
                    networkReqs: [],
                  })
                );
              case "RECORD_CALLBACK":
                return s(
                  s({}, t),
                  {},
                  u(
                    {},
                    e.fid,
                    s(s({}, t[e.fid]), {}, { hasCallbackExecuted: !0 })
                  )
                );
              case "RECORD_NETWORK_EXCHANGE":
                var r = t[e.fid].networkReqs;
                return (
                  (r[e.networkID] = s(
                    s({}, r[e.networkID]),
                    {},
                    (u(
                      (n = {}),
                      "".concat(e.exchangeType, "Time"),
                      e.timestamp
                    ),
                    u(n, "inFlight", "request" === e.exchangeType),
                    n)
                  )),
                  s(
                    s({}, t),
                    {},
                    u({}, e.fid, s(s({}, t[e.fid]), {}, { networkReqs: r }))
                  )
                );
              case "RECORD_TIMEOUT":
                return s(
                  s({}, t),
                  {},
                  u(
                    {},
                    e.fid,
                    s(
                      s({}, t[e.fid]),
                      {},
                      {
                        networkReqs: t[e.fid].networkReqs.map(function (t) {
                          return t.inFlight
                            ? s(s({}, t), {}, { timeOut: e.timeOut })
                            : t;
                        }),
                      }
                    )
                  )
                );
              default:
                return s({}, t);
            }
          })(t.bidReqs, e),
          bsPixels: (function (t, e) {
            return "RECORD_BID_INFO_SENT" !== e.type
              ? s({}, t)
              : s(s({}, t), {}, u({}, e.bidInfo.iid, e.bidInfo.state));
          })(t.bsPixels, e),
          cfg: (function (t, e) {
            return "SET_CFG" !== e.type ? s({}, t) : s(s({}, t), e.cfg);
          })(t.cfg, e),
          cmpFired: (function (t, e) {
            return "CMP_FIRED" === e.type || t;
          })(t.cmpFired, e),
          config: (function (t, e) {
            return "SET_CONFIG" !== e.type
              ? s({}, t)
              : s(
                  s({}, e.config),
                  {},
                  {
                    gdpr: s({ cmpTimeout: e.defaultCmpTimeout }, e.config.gdpr),
                    isSelfServePub:
                      void 0 !== e.config.pubID && 5 <= e.config.pubID.length,
                  }
                );
          })(t.config, e),
          displayAdServer: (function (t, e) {
            switch (e.type) {
              case "SLOT_RENDER_ENDED_SET":
                return s(s({}, t), {}, { slotRenderEndedSet: !0 });
              case "NO_BID_ON_ADSERVER_SLOTS":
                return s(
                  s({}, t),
                  {},
                  { noBidSlotIDs: t.noBidSlotIDs.concat(e.slotIDs) }
                );
              case "REQUESTED_BID_FOR_ADSERVER_SLOTS":
                return s(
                  s({}, t),
                  {},
                  {
                    noBidSlotIDs: t.noBidSlotIDs.filter(function (t) {
                      return !Object(i.g)(e.slotIDs, t);
                    }),
                  }
                );
              case "SHOULD_SAMPLE_SLOT_RENDER":
                return s(s({}, t), {}, { shouldSampleRender: e.value });
              default:
                return s(s({}, t), {}, { noBidSlotIDs: l(t.noBidSlotIDs) });
            }
          })(t.displayAdServer, e),
          errors: (function (t, e) {
            return "LOG_ERROR" !== e.type
              ? l(t)
              : [].concat(l(t), [s({}, e.error)]);
          })(t.errors, e),
          eventLog: (function (t, e) {
            return "LOG_EVENT" !== e.type
              ? l(t)
              : [].concat(l(t), [s({}, e.event)]);
          })(t.eventLog, e),
          experiments: (function (t, e) {
            switch (e.type) {
              case "SHOULD_CHUNK_REQUESTS":
                return s(
                  { chunkRequests: !0 === t.shouldSampleLatency && e.value },
                  t
                );
              case "SHOULD_SAMPLE_LATENCY":
                return s(s({}, t), {}, { shouldSampleLatency: e.value });
              case "SHOULD_SAMPLE_FEATURES":
                return s(s({}, t), {}, { shouldSampleFeatures: e.value });
              case "SHOULD_USE_TEST_BID_ENDPOINT":
                return s(s({}, t), {}, { shouldUseTestBidEndpoint: e.value });
              default:
                return s({}, t);
            }
          })(t.experiments, e),
          gamSlotFetchLog: (function (t, e) {
            return "LOG_GAM_EVENT" !== e.type
              ? l(t)
              : [].concat(l(t), [s({}, e.event)]);
          })(t.gamSlotFetchLog, e),
          gamSlotRenderPixel: (function (t, e) {
            return "UPDATE_RENDER_OFFSETS" !== e.type
              ? s({}, t)
              : s(s({}, t), e.offsets);
          })(t.gamSlotRenderPixel, e),
          hosts: (function (t, e) {
            return "SET_HOST" !== e.type
              ? s({}, t)
              : s(s({}, t), {}, u({}, e.hostName, e.hostValue));
          })(t.hosts, e),
          identityState: (function (t, e) {
            return "RECORD_IDENTITY_STATE" !== e.type
              ? t
              : s(
                  s({}, t),
                  {},
                  u(
                    {},
                    e.vendor,
                    Object(i.j)(t, e.vendor) ? t[e.vendor] : e.identityState
                  )
                );
          })(t.identityState, e),
          libraryLoadCallLatency: (function (t, e) {
            return "RECORD_LIBRARY_LOAD_CALL_LATENCY" !== e.type
              ? t
              : e.latency;
          })(t.libraryLoadCallLatency, e),
          Q: (function (t, e) {
            return "SET_Q" !== e.type ? l(t) : l(e.Q);
          })(t.Q, e),
          slotBids: (function (t, e) {
            switch (e.type) {
              case "BID_STATE_CHANGE":
                return s(
                  s({}, t),
                  {},
                  u(
                    {},
                    e.slotID,
                    t[e.slotID].map(function (t) {
                      return (
                        t._targetingSetID === e._targetingSetID &&
                          ((t.bidState = e.bidState),
                          e.bidState === o.c.rendered
                            ? (t.timing.renderTime = e.ts)
                            : e.bidState === o.c.set &&
                              t.timing.setAtTimes.push(e.ts)),
                        t
                      );
                    })
                  )
                );
              case "UPDATE_BID_INFO_PROP":
                return void 0 === t[e.slotID] ||
                  t[e.slotID].filter(function (t) {
                    return t.matchesBidCacheId(e.iid);
                  }).length < 1
                  ? s({}, t)
                  : s(
                      s({}, t),
                      {},
                      u(
                        {},
                        e.slotID,
                        t[e.slotID].map(function (t) {
                          return (
                            t.matchesBidCacheId(e.iid) && (t[e.key] = e.value),
                            t
                          );
                        })
                      )
                    );
              case "UPDATE_SLOT_BIDS":
                return s(
                  s({}, t),
                  e.bids.reduce(function (e, n) {
                    return (
                      Object(i.j)(e, n.slotID)
                        ? (e[n.slotID] = [].concat(l(e[n.slotID]), [n]))
                        : Object(i.j)(t, n.slotID)
                        ? (e[n.slotID] = [].concat(l(t[n.slotID]), [n]))
                        : (e[n.slotID] = [n]),
                      e
                    );
                  }, {})
                );
              default:
                return s({}, t);
            }
          })(t.slotBids, e),
          targetingKeys: (function (t, e) {
            return "UPDATE_SLOT_BIDS" !== e.type
              ? s({}, t)
              : s(
                  s({}, t),
                  e.bids.reduce(function (e, n) {
                    return (
                      Object(i.j)(t, n.slotID)
                        ? (e[n.slotID] = [].concat(
                            l(t[n.slotID]),
                            l(
                              (n.bidConfig.targeting || o.i).filter(function (
                                e
                              ) {
                                return -1 === t[n.slotID].indexOf(e);
                              })
                            )
                          ))
                        : (e[n.slotID] = n.bidConfig.targeting || o.i),
                      e
                    );
                  }, {})
                );
          })(t.targetingKeys, e),
          tcfParseTime: (function (t, e) {
            return "RECORD_TCF_PARSE_TIME" !== e.type ? t : e.time;
          })(t.tcfParseTime, e),
          outstream: (function (t, e) {
            switch (e.type) {
              case "RECORD_OUTSTREAM_RENDER_START_TIME":
                return s(s({}, t), {}, { renderStart: e.time });
              case "OUTSTREAM_SHOULD_SAMPLE":
                return s(s({}, t), {}, { shouldSample: e.shouldSample });
              default:
                return t;
            }
          })(t.outstream, e),
          consentManagementPlatform: (function (t, e) {
            switch (e.type) {
              case "RECORD_CMP_LISTENED_TO":
                return s(s({}, t), {}, { isListenedTo: e.isListenedTo });
              case "RECORD_CMP_CONSENT_DATA":
                return s(s({}, t), {}, { tcData: e.tcData });
              default:
                return t;
            }
          })(t.consentManagementPlatform, e),
        };
      }
      var p = {
        getState: function () {
          return r;
        },
        dispatch: function (t) {
          r = b(r, t);
        },
      };
      (p =
        Object(n.d)("redux") &&
        Object(e.b)() &&
        Object(i.j)(window, "__REDUX_DEVTOOLS_EXTENSION__")
          ? window.__REDUX_DEVTOOLS_EXTENSION__(b)
          : p).dispatch({ type: "NOOP" });
    },
    function (t, e, n) {
      "use strict";
      n.d(e, "m", function () {
        return a;
      }),
        n.d(e, "i", function () {
          return c;
        }),
        n.d(e, "x", function () {
          return s;
        }),
        n.d(e, "c", function () {
          return r;
        }),
        n.d(e, "h", function () {
          return u;
        }),
        n.d(e, "w", function () {
          return l;
        }),
        n.d(e, "f", function () {
          return f;
        }),
        n.d(e, "g", function () {
          return d;
        }),
        n.d(e, "d", function () {
          return b;
        }),
        n.d(e, "p", function () {
          return p;
        }),
        n.d(e, "n", function () {
          return y;
        }),
        n.d(e, "e", function () {
          return g;
        }),
        n.d(e, "o", function () {
          return o;
        }),
        n.d(e, "u", function () {
          return m;
        }),
        n.d(e, "j", function () {
          return h;
        }),
        n.d(e, "t", function () {
          return i;
        }),
        n.d(e, "s", function () {
          return O;
        }),
        n.d(e, "l", function () {
          return v;
        }),
        n.d(e, "r", function () {
          return j;
        }),
        n.d(e, "v", function () {
          return S;
        }),
        n.d(e, "b", function () {
          return w;
        }),
        n.d(e, "k", function () {
          return _;
        }),
        n.d(e, "a", function () {
          return E;
        }),
        n.d(e, "q", function () {
          return D;
        }),
        n.d(e, "y", function () {
          return T;
        });
      var r,
        o,
        i,
        a = 25,
        c = ["amznbid", "amzniid", "amznsz", "amznp"],
        s = [
          "amznbid",
          "amzniid",
          "amznp",
          "r_amznbid",
          "r_amzniid",
          "r_amznp",
        ],
        u =
          (((n = r = r || {}).new = "NEW"),
          (n.exposed = "EXPOSED"),
          (n.set = "SET"),
          (n.rendered = "RENDERED"),
          "apstagDebug"),
        l = [
          "redux",
          "fake_bids",
          "verbose",
          "console",
          "console_v2",
          "errors",
        ],
        f = "apstagDebugHeight",
        d = "apstagDEBUG",
        b = "apstagCfg",
        p = 0,
        y = 0,
        g = "apstagCxMEnabled",
        m =
          (((e = o = o || {}).amznbid = "testBid"),
          (e.amzniid = "testImpression"),
          (e.amznp = "testP"),
          (e.crid = "testCrid"),
          ["amznbid", "amznp"]),
        h = new Map([
          ["__apsid", "ck"],
          ["__aps_id_p", "ckp"],
        ]),
        O =
          (((n = i = i || {}).noRequest = "0"),
          (n.bidInFlight = "1"),
          (n.noBid = "2"),
          "600"),
        v = "26.1102.1713",
        j = "https://",
        S = "http".concat("s://"),
        w = "".concat(j, "aax.amazon-adsystem.com/e/dtb/vast?"),
        _ =
          "function" == typeof XMLHttpRequest &&
          void 0 !== new XMLHttpRequest().withCredentials,
        E = "apstagLOADED",
        D = 13,
        T =
          '<!DOCTYPE html>\n<html>\n  <head>\n    <title>APS Video Ads</title>\n    <script src="https://client.aps.amazon-adsystem.com/video-player.js" onerror="$$apsvidonerror$$"></script>\n  </head>\n  <body>\n    <div id="amazon-ads-container" style="height: 100%; width: 100%; position: absolute;">\n    </div>\n    <script type="text/javascript">\nconst adsContainer = document.querySelector("#amazon-ads-container")\nconst companionContainers =\n  window.AmazonVideoAds.findCompanionDivs($$apstagCompanionContainers$$)\nconst videoPlayerProps = $$videoPlayerProps$$\n\nconst amazonVideoAds = new window.AmazonVideoAds(adsContainer,\n{ ...videoPlayerProps,\n  companions: companionContainers });\nwindow.adsM;\n\nfunction addListeners(adsM, amazonVideoAds) {\n  adsM.addListener(amazonVideoAds.eventNames.AdVideoPlayerEvents.COMPLETED, (e) => {\n    window.top.postMessage({"apsVideoPlayer": true, "event": "completed"}, window.top.location.origin);\n  })\n  adsM.addListener(amazonVideoAds.eventNames.AdVideoPlayerEvents.LOADED, (e) => {\n    window.top.postMessage({"apsVideoPlayer": true, "event": "loaded"}, window.top.location.origin);\n  })\n}\n \nwindow.requestAndPlay = () => {\n  amazonVideoAds.fetchAdsFromUrl("$$apstagVastTag$$")\n    .then(adsManager => {\n      adsM = adsManager;\n \n      adsM.init({\n        fullscreen: true,\n        muted: true,\n        volume: .3,\n        autoplay: false,\n        controls: false,\n        preload: "auto"\n      })\n\n      addListeners(adsM, amazonVideoAds);\n      adsM.startAds(2000, {shouldVideoRemainAfterPlay: true});\n    })\n    .catch(function(err) {\n      console.log("apstag failed to get APS ads manager", err);\n    });\n  }\n \n  requestAndPlay();\n    </script>\n  </body>\n</html>';
    },
    function (t, e, n) {
      "use strict";
      var r, o;
      function i(t) {
        return void 0 !== t.amzniid;
      }
      function a(t) {
        return void 0 !== t.kvMap;
      }
      n.d(e, "a", function () {
        return r;
      }),
        n.d(e, "b", function () {
          return o;
        }),
        n.d(e, "d", function () {
          return i;
        }),
        n.d(e, "c", function () {
          return a;
        }),
        ((n = r = r || {}).DISPLAY = "display"),
        (n.VIDEO = "video"),
        (n.MULTI_FORMAT = "multi-format"),
        ((e = o = o || {}).MANAGED_WEB = "mw"),
        (e.SELF_SERVE_WEB = "ssw");
    },
    function (t, e, n) {
      "use strict";
      function r(t) {
        return (r =
          "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
            ? function (t) {
                return typeof t;
              }
            : function (t) {
                return t &&
                  "function" == typeof Symbol &&
                  t.constructor === Symbol &&
                  t !== Symbol.prototype
                  ? "symbol"
                  : typeof t;
              })(t);
      }
      function o(t, e) {
        var n,
          r = Object.keys(t);
        return (
          Object.getOwnPropertySymbols &&
            ((n = Object.getOwnPropertySymbols(t)),
            e &&
              (n = n.filter(function (e) {
                return Object.getOwnPropertyDescriptor(t, e).enumerable;
              })),
            r.push.apply(r, n)),
          r
        );
      }
      function i(t, e) {
        for (var n = 0; n < e.length; n++) {
          var r = e[n];
          (r.enumerable = r.enumerable || !1),
            (r.configurable = !0),
            "value" in r && (r.writable = !0),
            Object.defineProperty(t, c(r.key), r);
        }
      }
      function a(t, e, n) {
        (e = c(e)) in t
          ? Object.defineProperty(t, e, {
              value: n,
              enumerable: !0,
              configurable: !0,
              writable: !0,
            })
          : (t[e] = n);
      }
      function c(t) {
        return (
          (t = (function (t, e) {
            if ("object" !== r(t) || null === t) return t;
            var n = t[Symbol.toPrimitive];
            if (void 0 === n) return String(t);
            if ("object" !== r((n = n.call(t, e)))) return n;
            throw new TypeError("@@toPrimitive must return a primitive value.");
          })(t, "string")),
          "symbol" === r(t) ? t : String(t)
        );
      }
      n.d(e, "a", function () {
        return l;
      });
      var s = (function () {
          function t(e) {
            if (((e = e.accountID), !(this instanceof t)))
              throw new TypeError("Cannot call a class as a function");
            a(this, "accountID", void 0), (this.accountID = e), this.init();
          }
          var e, n;
          return (
            (e = t),
            (n = [
              {
                key: "queue",
                get: function () {
                  var t;
                  return null == (t = window._aps.get(this.accountID))
                    ? void 0
                    : t.queue;
                },
              },
              {
                key: "init",
                value: function () {
                  (window._aps = window._aps || new Map()),
                    window._aps.has(this.accountID) ||
                      window._aps.set(this.accountID, {
                        queue: [],
                        store: new Map(),
                      });
                },
              },
              {
                key: "safelyRecord",
                value: function (t, e) {
                  this.record(t, e).catch(function () {});
                },
              },
              {
                key: "record",
                value: function (t, e) {
                  var n = this;
                  return new Promise(function (r, i) {
                    window._aps.get(n.accountID).queue.push(
                      new window.CustomEvent(t, {
                        detail: (function (t) {
                          for (var e = 1; e < arguments.length; e++) {
                            var n = null != arguments[e] ? arguments[e] : {};
                            e % 2
                              ? o(Object(n), !0).forEach(function (e) {
                                  a(t, e, n[e]);
                                })
                              : Object.getOwnPropertyDescriptors
                              ? Object.defineProperties(
                                  t,
                                  Object.getOwnPropertyDescriptors(n)
                                )
                              : o(Object(n)).forEach(function (e) {
                                  Object.defineProperty(
                                    t,
                                    e,
                                    Object.getOwnPropertyDescriptor(n, e)
                                  );
                                });
                          }
                          return t;
                        })({ resolve: r, reject: i, source: "apstag" }, e),
                      })
                    );
                  });
                },
              },
              {
                key: "read",
                value: function (t) {
                  var e;
                  return null == (e = window._aps)
                    ? void 0
                    : e.get(this.accountID).store.get(t);
                },
              },
            ]) && i(e.prototype, n),
            Object.defineProperty(e, "prototype", { writable: !1 }),
            t
          );
        })(),
        u = {},
        l = function (t) {
          return (
            "string" != typeof t && (t = t.toString()),
            (window._aps && window._aps.has(t) && u[t]) ||
              (u[t] = new s({ accountID: t })),
            u[t]
          );
        };
    },
    function (t, e, n) {
      "use strict";
      n.d(e, "b", function () {
        return j;
      }),
        n.d(e, "a", function () {
          return D;
        });
      var r,
        o,
        i,
        a,
        c = n(1),
        s = n(16),
        u = n(25),
        l = n(2);
      function f(t) {
        return (f =
          "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
            ? function (t) {
                return typeof t;
              }
            : function (t) {
                return t &&
                  "function" == typeof Symbol &&
                  t.constructor === Symbol &&
                  t !== Symbol.prototype
                  ? "symbol"
                  : typeof t;
              })(t);
      }
      function d(t, e) {
        if ("function" != typeof e && null !== e)
          throw new TypeError(
            "Super expression must either be null or a function"
          );
        (t.prototype = Object.create(e && e.prototype, {
          constructor: { value: t, writable: !0, configurable: !0 },
        })),
          Object.defineProperty(t, "prototype", { writable: !1 }),
          e &&
            (function (t, e) {
              (Object.setPrototypeOf
                ? Object.setPrototypeOf.bind()
                : function (t, e) {
                    return (t.__proto__ = e), t;
                  })(t, e);
            })(t, e);
      }
      function b(t) {
        var e = (function () {
          if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
          if (Reflect.construct.sham) return !1;
          if ("function" == typeof Proxy) return !0;
          try {
            return (
              Boolean.prototype.valueOf.call(
                Reflect.construct(Boolean, [], function () {})
              ),
              !0
            );
          } catch (t) {
            return !1;
          }
        })();
        return function () {
          var n,
            r = y(t);
          (n = e
            ? ((n = y(this).constructor), Reflect.construct(r, arguments, n))
            : r.apply(this, arguments)),
            (r = this);
          if (n && ("object" === f(n) || "function" == typeof n)) return n;
          if (void 0 !== n)
            throw new TypeError(
              "Derived constructors may only return object or undefined"
            );
          return p(r);
        };
      }
      function p(t) {
        if (void 0 === t)
          throw new ReferenceError(
            "this hasn't been initialised - super() hasn't been called"
          );
        return t;
      }
      function y(t) {
        return (y = Object.setPrototypeOf
          ? Object.getPrototypeOf.bind()
          : function (t) {
              return t.__proto__ || Object.getPrototypeOf(t);
            })(t);
      }
      function g(t, e) {
        if (!(t instanceof e))
          throw new TypeError("Cannot call a class as a function");
      }
      function m(t, e) {
        for (var n = 0; n < e.length; n++) {
          var r = e[n];
          (r.enumerable = r.enumerable || !1),
            (r.configurable = !0),
            "value" in r && (r.writable = !0),
            Object.defineProperty(t, v(r.key), r);
        }
      }
      function h(t, e, n) {
        e && m(t.prototype, e),
          n && m(t, n),
          Object.defineProperty(t, "prototype", { writable: !1 });
      }
      function O(t, e, n) {
        (e = v(e)) in t
          ? Object.defineProperty(t, e, {
              value: n,
              enumerable: !0,
              configurable: !0,
              writable: !0,
            })
          : (t[e] = n);
      }
      function v(t) {
        return (
          (t = (function (t, e) {
            if ("object" !== f(t) || null === t) return t;
            var n = t[Symbol.toPrimitive];
            if (void 0 === n) return String(t);
            if ("object" !== f((n = n.call(t, e)))) return n;
            throw new TypeError("@@toPrimitive must return a primitive value.");
          })(t, "string")),
          "symbol" === f(t) ? t : String(t)
        );
      }
      function j() {
        try {
          var t, e, n, r;
          return !(
            null == (t = window) ||
            null == (e = t.localStorage) ||
            !e.setItem ||
            null == (n = window) ||
            null == (r = n.localStorage) ||
            !r.removeItem
          );
        } catch (t) {
          return !1;
        }
      }
      ((e = r = r || {}).sessionStorage = "sessionStorage"),
        (e.localStorage = "localStorage"),
        ((o = o || {}).document = "document"),
        ((n = i = i || {}).clear = "clear"),
        (n.getItem = "getItem"),
        (n.key = "key"),
        (n.removeItem = "removeItem"),
        (n.setItem = "setItem"),
        (n.length = "length"),
        ((a = a || {}).cookie = "cookie");
      var S = ["AMZN-NoCookieConsent"],
        w = (function () {
          function t(e, n) {
            g(this, t),
              O(this, "globalContext", void 0),
              O(this, "stateContainer", void 0),
              (this.globalContext = e),
              (this.stateContainer = n);
          }
          return (
            h(t, [
              {
                key: "privacyRegulationApplies",
                value: function () {
                  var t =
                      null ==
                      (e = u.a.readStoredConsentData(this.stateContainer))
                        ? void 0
                        : e.tcString,
                    e = null == e ? void 0 : e.gdprApplies;
                  return !!(
                    ("string" == typeof t && 0 < t.length) ||
                    (null != (t = this.globalContext.apstag) &&
                      t.isGDPRRegion) ||
                    e
                  );
                },
              },
              {
                key: "allowedToStoreAndAccessInformationOnDevice",
                value: function () {
                  if (this.privacyRegulationApplies()) {
                    var t;
                    if (
                      !(t =
                        null ==
                        (t = u.a.readStoredConsentData(this.stateContainer))
                          ? void 0
                          : t.tcString) ||
                      "string" != typeof t
                    )
                      return {
                        allowed: !1,
                        failures: ["Invalid tcString: ".concat(t)],
                      };
                    var e = Object(s.c)(t);
                    if (!e)
                      return {
                        allowed: !1,
                        failures: ["Invalid tcString: ".concat(t)],
                      };
                    if ((t = Object(s.b)(e)).length)
                      return { allowed: !1, failures: t };
                  }
                  return { allowed: !0, failures: [] };
                },
              },
              {
                key: "ensureStorageUsageIsAllowedOrThrowOnError",
                value: function (t, e, n) {
                  var r = (o =
                      this.allowedToStoreAndAccessInformationOnDevice())
                      .allowed,
                    o = o.failures;
                  if (!(r || (n && 0 < n.length && 0 <= S.indexOf(n[0]))))
                    throw new Error(
                      "Not allowed to store or access information on device: ".concat(
                        o
                      )
                    );
                  if (!(r = this.globalContext[t]))
                    throw new ReferenceError(
                      "Object ".concat(t, " isn't available")
                    );
                  if (void 0 === r[e])
                    throw new ReferenceError(
                      "Method ".concat(e, " isn't available")
                    );
                },
              },
              {
                key: "executeFunction",
                value: function (t, e, n, r, o) {
                  return (
                    (e = this.globalContext[e]),
                    (n = (r = r || e[n]).apply(e, t)) && null != o && o.isJson
                      ? JSON.parse(n)
                      : n
                  );
                },
              },
              {
                key: "executeFunctionOrThrowOnError",
                value: function (t, e, n, r, o) {
                  return (
                    this.ensureStorageUsageIsAllowedOrThrowOnError(e, n, t),
                    this.executeFunction(t, e, n, r, o)
                  );
                },
              },
              {
                key: "regulatedMethod",
                value: function (t, e, n, r) {
                  var o = this;
                  return function () {
                    try {
                      for (
                        var i = arguments.length, a = new Array(i), s = 0;
                        s < i;
                        s++
                      )
                        a[s] = arguments[s];
                      return o.executeFunctionOrThrowOnError(a, t, e, n, r);
                    } catch (i) {
                      if (null == r || !r.ignoreFailure)
                        throw (
                          (Object(c.b)(
                            i,
                            "RegulatedDataContainer-regulatedMethod"
                          ),
                          i)
                        );
                    }
                  };
                },
              },
            ]),
            t
          );
        })(),
        _ = (function () {
          d(e, w);
          var t = b(e);
          function e() {
            var n;
            g(this, e);
            for (var r = arguments.length, i = new Array(r), c = 0; c < r; c++)
              i[c] = arguments[c];
            return (
              O(
                p((n = t.call.apply(t, [this].concat(i)))),
                "_getItem",
                function (t) {
                  var e = n.globalContext.document.cookie
                    .split("; ")
                    .reduce(function (e, n) {
                      return (n = n.split("="))[0] === t
                        ? decodeURIComponent(n.slice(1).join("="))
                        : e;
                    }, "");
                  return 0 < e.length ? e : null;
                }
              ),
              O(p(n), "_removeItem", function (t) {
                n.setItem(
                  t,
                  "",
                  0,
                  1 < arguments.length && void 0 !== arguments[1]
                    ? arguments[1]
                    : "/"
                );
              }),
              O(p(n), "_setItem", function (t, e, r) {
                var o =
                  3 < arguments.length && void 0 !== arguments[3]
                    ? arguments[3]
                    : "/";
                r = new Date(r);
                if (!n.isValidDate(r))
                  throw new Error("Invalid expiration date");
                n.globalContext.document.cookie = ""
                  .concat(t, "=")
                  .concat(e, "; expires=")
                  .concat(r.toUTCString(), "; path=")
                  .concat(o, ";");
              }),
              O(p(n), "getItem", function (t, e) {
                return n.regulatedMethod(
                  o.document,
                  a.cookie,
                  n._getItem,
                  e
                )(t);
              }),
              O(p(n), "setItem", function (t, e, r) {
                var i =
                  3 < arguments.length && void 0 !== arguments[3]
                    ? arguments[3]
                    : "/";
                return n.regulatedMethod(
                  o.document,
                  a.cookie,
                  n._setItem,
                  4 < arguments.length ? arguments[4] : void 0
                )(t, e, r, i);
              }),
              O(p(n), "removeItem", function (t, e) {
                return n.regulatedMethod(
                  o.document,
                  a.cookie,
                  n._removeItem,
                  e
                )(t);
              }),
              n
            );
          }
          return (
            h(e, [
              {
                key: "isValidDate",
                value: function (t) {
                  return t instanceof Date && !isNaN(t);
                },
              },
            ]),
            e
          );
        })(),
        E = (function () {
          d(e, w);
          var t = b(e);
          function e(n, r, o) {
            var a;
            return (
              g(this, e),
              O(p((a = t.call(this, n, r))), "storageType", void 0),
              O(p(a), "clear", function (t) {
                return a.regulatedMethod(a.storageType, i.clear, null, t)();
              }),
              O(p(a), "getItem", function (t, e) {
                return a.regulatedMethod(a.storageType, i.getItem, null, e)(t);
              }),
              O(p(a), "key", function (t, e) {
                return a.regulatedMethod(a.storageType, i.key, null, e)(t);
              }),
              O(p(a), "removeItem", function (t, e) {
                return a.regulatedMethod(
                  a.storageType,
                  i.removeItem,
                  null,
                  e
                )(t);
              }),
              O(p(a), "setItem", function (t, e, n) {
                return a.regulatedMethod(
                  a.storageType,
                  i.setItem,
                  null,
                  n
                )(t, e);
              }),
              (a.storageType = o),
              a
            );
          }
          return (
            h(e, [
              {
                key: "length",
                get: function () {
                  return (
                    this.ensureStorageUsageIsAllowedOrThrowOnError(
                      this.storageType,
                      i.length
                    ),
                    this.globalContext[this.storageType].length
                  );
                },
              },
            ]),
            e
          );
        })(),
        D = (function () {
          function t(e) {
            g(this, t),
              O(this, "globalContext", void 0),
              O(this, "stateContainer", void 0),
              (this.globalContext = e.globalContext),
              (this.stateContainer = e.stateContainer);
          }
          return (
            h(
              t,
              [
                {
                  key: "sessionStorage",
                  get: function () {
                    try {
                      return new E(
                        this.globalContext,
                        this.stateContainer,
                        r.sessionStorage
                      );
                    } catch (t) {
                      throw (
                        (Object(c.b)(
                          t,
                          "RegulatedDataContainers-sessionStorage"
                        ),
                        t)
                      );
                    }
                  },
                },
                {
                  key: "localStorage",
                  get: function () {
                    try {
                      return new E(
                        this.globalContext,
                        this.stateContainer,
                        r.localStorage
                      );
                    } catch (t) {
                      throw (
                        (Object(c.b)(t, "RegulatedDataContainers-localStorage"),
                        t)
                      );
                    }
                  },
                },
                {
                  key: "cookie",
                  get: function () {
                    try {
                      return new _(this.globalContext, this.stateContainer);
                    } catch (t) {
                      throw (
                        (Object(c.b)(t, "RegulatedDataContainers-cookie"), t)
                      );
                    }
                  },
                },
                {
                  key: "indexedDB",
                  get: function () {
                    throw new ReferenceError("Interface isn't yet defined");
                  },
                },
                {
                  key: "allowedToStoreAndAccessInformationOnDevice",
                  value: function () {
                    try {
                      return new w(
                        this.globalContext,
                        this.stateContainer
                      ).allowedToStoreAndAccessInformationOnDevice().allowed;
                    } catch (t) {
                      return (
                        Object(c.b)(
                          t,
                          "RegulatedDataContainers-allowedToStoreAndAccessInformationOnDevice"
                        ),
                        !1
                      );
                    }
                  },
                },
              ],
              [
                {
                  key: "getDefault",
                  value: function () {
                    return new t({
                      globalContext: window,
                      stateContainer: l.a,
                    });
                  },
                },
              ]
            ),
            t
          );
        })();
    },
    function (t, e, n) {
      "use strict";
      n.d(e, "a", function () {
        return l;
      }),
        n.d(e, "b", function () {
          return g;
        }),
        n.d(e, "d", function () {
          return _;
        }),
        n.d(e, "c", function () {
          return D;
        }),
        n.d(e, "e", function () {
          return I;
        });
      var r = n(2),
        o = n(6),
        i = n(0),
        a = n(3),
        c = n(10),
        s = n(1),
        u = ["getLog", "getState"];
      function l(t, e, n) {
        try {
          switch (
            (Object(i.g)(u, t) &&
              (Object(s.b)(
                new Error("Debug call made: ".concat(t)),
                "debugPublicApi-call-".concat(t)
              ),
              (u = u.filter(function (e) {
                return e !== t;
              }))),
            t)
          ) {
            case "getLog":
              return r.a.getState().eventLog;
            case "getState":
              return r.a.getState();
            case "enable":
              return E("fake_bids", !0), "DEBUG MODE ENABLED";
            case "disable":
              return E("fake_bids", !1), "DEBUG MODE DISABLED";
            case "enableConsole":
              return g(!1, "command"), "Debug console enabled";
            case "enableConsoleV2":
              return g(!0, "command"), "Debug console v2 enabled";
            case "disableConsole":
              try {
                E("console", !1),
                  E("console_v2", !1),
                  null !== f && document.body.removeChild(f),
                  (y = !1),
                  Object(o.b)() &&
                    o.a.getDefault().localStorage.removeItem(a.f);
              } catch (e) {
                Object(s.b)(e, "disableDebugConsole", {
                  makeVisibleToAllUsers: !0,
                });
              }
              return "Debug console disabled";
            case "setDebug":
              return (
                E(e, n) ? "Set debug mode '" : "Failed to set debug mode '"
              )
                .concat(e, "' to '")
                .concat(n, "'");
            default:
              return "unknown debug argument";
          }
        } catch (e) {
          return (
            Object(s.b)(e, "debugPublicApi", { makeVisibleToAllUsers: !0 }),
            "error"
          );
        }
      }
      var f,
        d,
        b,
        p,
        y = !1;
      function g() {
        var t,
          e = 0 < arguments.length && void 0 !== arguments[0] && arguments[0];
        try {
          E(e ? "console_v2" : "console", !0),
            y ||
              ((t = {
                url: e
                  ? r.a.getState().cfg.DEBUG_APP_HTML_V2
                  : r.a.getState().cfg.DEBUG_APP_HTML,
                onload: m,
                onerror: function () {
                  return Object(s.b)(
                    new Error("Error Loading Debug Console"),
                    "enableDebugConsole-".concat(e ? "v2" : "v1", "-onerror"),
                    { makeVisibleToAllUsers: !0 }
                  );
                },
              }),
              Object(c.d)(t),
              setTimeout(function () {
                try {
                  Object(i.j)(r.a.getState().config, "pubID") &&
                    r.a.getState().config.pubID;
                } catch (t) {
                  Object(s.b)(t, "enableDebugConsole-setTimeout", {
                    makeVisibleToAllUsers: !0,
                  });
                }
              }, 5e3));
        } catch (t) {
          Object(s.b)(t, "enableDebugConsole", { makeVisibleToAllUsers: !0 });
        }
      }
      function m(t) {
        try {
          var e = t.responseText,
            n =
              ((f = document.createElement("div")),
              (d = document.createElement("div")),
              (b = document.createElement("iframe")),
              200);
          _("console_v2") && (n = 330),
            Object(o.b)() &&
              null !== o.a.getDefault().localStorage.getItem(a.f) &&
              (n = parseInt(o.a.getDefault().localStorage.getItem(a.f), 10)),
            (isNaN(n) || n > window.innerHeight) && (n = 200),
            (f.style.background = "#eaeded"),
            (f.style.zIndex = "2147483647"),
            (f.style.bottom = "0"),
            (f.style.position = "fixed !important"),
            (f.style.display = "block !important"),
            (f.style.left = "0"),
            (f.style.right = "0"),
            (f.style.height = "".concat(n, "px")),
            (d.style.cursor = "row-resize"),
            (d.style.height = "2px"),
            (d.style.position = "absolute"),
            (d.style.top = "0"),
            (d.style.left = "0"),
            (d.style.right = "0"),
            (d.style.backgroundColor = "RGBA(0,0,0,0)"),
            f.appendChild(d),
            (b.frameBorder = "0"),
            (b.marginHeight = "0"),
            (b.marginWidth = "0"),
            (b.scrolling = "no"),
            (b.id = "apstag-debug-iframe"),
            (b.src = "about:blank"),
            (b.style.display = "block"),
            (b.style.width = "100%"),
            (b.style.height = "".concat(n, "px")),
            f.appendChild(b),
            document.body.appendChild(f),
            null !== b.contentDocument &&
              (b.contentDocument.open(),
              b.contentDocument.write(e),
              b.contentDocument.close()),
            d.addEventListener("mousedown", v);
        } catch (t) {
          Object(s.b)(t, "renderDebugConsole", { makeVisibleToAllUsers: !0 });
        }
      }
      function h(t) {
        try {
          var e = window.innerHeight - t.clientY;
          return (
            e < 200 && (e = 200),
            (f.style.height = "".concat(e, "px")),
            (b.style.height = "".concat(e, "px")),
            e
          );
        } catch (t) {
          return (
            Object(s.b)(t, "resizeDebugConsole", { makeVisibleToAllUsers: !0 }),
            200
          );
        }
      }
      function O(t) {
        try {
          return (
            t.stopPropagation && t.stopPropagation(),
            t.preventDefault && t.preventDefault(),
            (t.cancelBubble = !0),
            (t.returnValue = !1)
          );
        } catch (t) {
          return (
            Object(s.b)(t, "preventEvent", { makeVisibleToAllUsers: !0 }), !1
          );
        }
      }
      function v() {
        try {
          void 0 === p &&
            (((p = document.createElement("div")).style.position = "fixed"),
            (p.style.left = "0"),
            (p.style.right = "0"),
            (p.style.top = "0"),
            (p.style.bottom = "0"),
            (p.style.zIndex = "9999999999")),
            f.appendChild(p),
            window.addEventListener("mouseup", S),
            window.addEventListener("mousemove", j);
        } catch (t) {
          Object(s.b)(t, "resizeBarMouseDownListener", {
            makeVisibleToAllUsers: !0,
          });
        }
      }
      function j(t) {
        try {
          return h(t), O(t);
        } catch (t) {
          return (
            Object(s.b)(t, "resizeBarMouseMoveListener", {
              makeVisibleToAllUsers: !0,
            }),
            !1
          );
        }
      }
      function S(t) {
        try {
          null !== p && f.removeChild(p),
            window.removeEventListener("mousemove", j),
            window.removeEventListener("mouseup", S);
          var e = h(t);
          return (
            Object(o.b)() &&
              o.a.getDefault().localStorage.setItem(a.f, "".concat(e)),
            O(t)
          );
        } catch (t) {
          return (
            Object(s.b)(t, "resizeBarMouseUpListener", {
              makeVisibleToAllUsers: !0,
            }),
            !1
          );
        }
      }
      function w() {
        try {
          if (!Object(o.b)()) return [];
          var t = o.a
              .getDefault()
              .localStorage.getItem(a.h, { ignoreFailure: !0 }),
            e =
              (null === t || "false" === t
                ? (t = "[]")
                : "true" === t && (t = '["fake_bids"]'),
              []);
          try {
            e = JSON.parse(t);
          } catch (t) {}
          return (e = Object(i.h)(e) ? e : []).filter(function (t) {
            return Object(i.g)(a.w, t);
          });
        } catch (t) {
          return [];
        }
      }
      function _(t) {
        try {
          return Object(i.g)(w(), t);
        } catch (t) {
          return !1;
        }
      }
      function E(t, e) {
        try {
          var n;
          if (Object(o.b)() && -1 !== a.w.indexOf(t))
            return (
              (n = w()),
              e && -1 === n.indexOf(t)
                ? n.push(t)
                : e ||
                  (n = n.filter(function (e) {
                    return e !== t;
                  })),
              0 === n.length
                ? o.a.getDefault().localStorage.removeItem(a.h)
                : o.a.getDefault().localStorage.setItem(a.h, JSON.stringify(n)),
              I(),
              1
            );
        } catch (e) {
          Object(s.b)(e, "setDebugMode");
        }
      }
      function D(t) {
        var e =
          1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : null;
        try {
          if (Object(i.j)(window, a.g) && Object(i.j)(window[a.g], t))
            return window[a.g][t];
        } catch (t) {
          Object(s.b)(t, "getDebugValue");
        }
        return e;
      }
      var T = [];
      function I() {
        try {
          w()
            .filter(function (t) {
              return -1 === T.indexOf(t);
            })
            .forEach(function (t) {
              Object(s.b)(
                new Error("Debug method enabled: ".concat(t)),
                "debugPublicApi-enabled-".concat(t),
                { makeVisibleToAllUsers: !0 }
              ),
                T.push(t);
            });
        } catch (t) {
          Object(s.b)(t, "pixelDebugModes");
        }
      }
    },
    function (t, e, n) {
      "use strict";
      n.d(e, "b", function () {
        return f;
      }),
        n.d(e, "f", function () {
          return d;
        }),
        n.d(e, "g", function () {
          return b;
        }),
        n.d(e, "c", function () {
          return p;
        }),
        n.d(e, "d", function () {
          return y;
        }),
        n.d(e, "e", function () {
          return g;
        }),
        n.d(e, "h", function () {
          return h;
        }),
        n.d(e, "a", function () {
          return O;
        }),
        n.d(e, "i", function () {
          return v;
        });
      var r = n(7),
        o = n(0),
        i = n(6),
        a = n(1),
        c = n(3),
        s = n(2),
        u = n(15);
      function l(t) {
        return (l =
          "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
            ? function (t) {
                return typeof t;
              }
            : function (t) {
                return t &&
                  "function" == typeof Symbol &&
                  t.constructor === Symbol &&
                  t !== Symbol.prototype
                  ? "symbol"
                  : typeof t;
              })(t);
      }
      function f(t) {
        try {
          return t.split("_").pop();
        } catch (t) {
          return Object(a.b)(t, "getAmpAmznBidValue"), "";
        }
      }
      function d(t) {
        try {
          var e,
            n = Object(r.c)("url");
          if (null !== n) return encodeURIComponent(n);
          try {
            v(t, !1)
              ? ((e = null),
                t.context &&
                  (e = t.context.canonicalUrl || t.context.sourceUrl))
              : (e = t.top.location.href);
          } catch (t) {
            e = null;
          }
          if (null === e || !e || void 0 === e) {
            e = "";
            try {
              t.top !== t.self && (e = t.document.referrer);
            } catch (t) {}
          }
          return encodeURIComponent(e);
        } catch (t) {
          return Object(a.b)(t, "getCurrentUrl"), "";
        }
      }
      function b(t) {
        try {
          var e,
            n = "",
            o = Object(r.c)("url");
          if (null !== o) return encodeURIComponent(o);
          try {
            try {
              e = ((v(t, !1) && t.context) || t.top.document).referrer;
            } catch (n) {
              e = t.document.referrer;
            }
            n = encodeURIComponent(e);
          } catch (n) {}
          return n;
        } catch (n) {
          return Object(a.b)(n, "getReferrerUrl"), "";
        }
      }
      function p() {
        try {
          var t = { cookiesParams: "" };
          return (
            c.j.forEach(function (e, n) {
              (n = i.a.getDefault().cookie.getItem(n)) &&
                (t.cookiesParams += "&".concat(e, "=").concat(n));
            }),
            t
          );
        } catch (t) {
          return (
            Object(a.b)(t, "getApsFirstPartyCookies"), { cookiesParams: "" }
          );
        }
      }
      function y(t, e) {
        try {
          var n = Object(u._getInitConfig)({
              overrides: null == e ? void 0 : e.initConfig,
            }).blockedBidders,
            r =
              (Object(o.j)(t, "blockedBidders") &&
                Object(o.h)(t.blockedBidders) &&
                (n = t.blockedBidders),
              "");
          return Object(o.h)(n) ? JSON.stringify(n) : r;
        } catch (t) {
          return (
            Object(a.b)(t, "getBlockedBidders", { makeVisibleToAllUsers: !0 }),
            ""
          );
        }
      }
      function g() {
        try {
          var t;
          return Object(i.b)()
            ? ((t = s.a.getState()),
              Object(o.j)(t, "cfg") && Object(o.j)(t.cfg, "v") && -1 !== t.cfg.v
                ? t.cfg.v
                : null)
            : c.p;
        } catch (t) {
          return Object(a.b)(t, "getCfgVersion"), null;
        }
      }
      function m(t) {
        try {
          if (-1 === ["string", "number"].indexOf(l(t))) return !1;
          var e = Math.floor(Number(t));
          if (e > c.n) return e;
        } catch (t) {
          Object(a.b)(t, "parseTimeout", { makeVisibleToAllUsers: !0 });
        }
        return !1;
      }
      function h(t, e) {
        try {
          var n = m(t.timeout);
          return !1 === (n = !1 === n ? m(e.config.bidTimeout) : n)
            ? m(e.cfg.DEFAULT_TIMEOUT)
            : n;
        } catch (t) {
          return (
            Object(a.b)(t, "getTimeout", { makeVisibleToAllUsers: !0 }), 2e3
          );
        }
      }
      function O(t, e) {
        var n,
          r = !1;
        function o(e) {
          if (!r)
            try {
              t(e);
            } catch (e) {
              Object(a.b)(e, "executeFunctionOnceWithTimeout-wrappedFunction", {
                makeVisibleToAllUsers: !0,
              });
            }
          clearTimeout(n), (r = !0);
        }
        try {
          return (n = setTimeout(o, e, !0)), o.bind(null, !1);
        } catch (e) {
          return (
            Object(a.b)(e, "executeFunctionOnceWithTimeout", {
              makeVisibleToAllUsers: !0,
            }),
            function () {}
          );
        }
      }
      function v(t, e) {
        try {
          var n = e ? t.AMP_CONTEXT_DATA : t.context;
          return Boolean(
            n && Object(o.j)(n, "tagName") && "AMP-AD" === n.tagName
          );
        } catch (t) {
          return Object(a.b)(t, "isInAmpAd"), !1;
        }
      }
    },
    function (t, e, n) {
      "use strict";
      n.d(e, "a", function () {
        return a;
      }),
        n.d(e, "b", function () {
          return c;
        });
      var r = n(1),
        o = n(0);
      function i(t) {
        return (i =
          "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
            ? function (t) {
                return typeof t;
              }
            : function (t) {
                return t &&
                  "function" == typeof Symbol &&
                  t.constructor === Symbol &&
                  t !== Symbol.prototype
                  ? "symbol"
                  : typeof t;
              })(t);
      }
      function a(t) {
        try {
          return (
            (function (t) {
              try {
                var e;
                return (
                  !!c(t, ["number", "string"]) &&
                  !(
                    isNaN(t) ||
                    ("number" != typeof t && ((e = parseInt(t, 10)), isNaN(e)))
                  )
                );
              } catch (t) {
                return Object(r.b)(t, "isNumber"), !0;
              }
            })(t) || void 0 === t
          );
        } catch (t) {
          return Object(r.b)(t, "isNumberOrUndefined"), !0;
        }
      }
      function c(t, e) {
        try {
          return Object(o.g)(e, i(t));
        } catch (t) {
          return Object(r.b)(t, "isVarOfTypes"), !0;
        }
      }
    },
    function (t, e, n) {
      "use strict";
      n.d(e, "d", function () {
        return i;
      }),
        n.d(e, "b", function () {
          return a;
        }),
        n.d(e, "a", function () {
          return c;
        }),
        n.d(e, "c", function () {
          return s;
        });
      var r = n(1);
      function o(t) {
        return (o =
          "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
            ? function (t) {
                return typeof t;
              }
            : function (t) {
                return t &&
                  "function" == typeof Symbol &&
                  t.constructor === Symbol &&
                  t !== Symbol.prototype
                  ? "symbol"
                  : typeof t;
              })(t);
      }
      function i(t) {
        var e,
          n = t.url,
          i = t.onload,
          a = t.onerror,
          c = t.ontimeout,
          s = t.withCredentials,
          u = void 0 === (u = t.body) ? null : u,
          l = void 0 === (e = t.headers) ? null : e,
          f =
            ((t = void 0 === (e = t.trustTokenParameter) ? null : e),
            new window.XMLHttpRequest());
        try {
          if ("" === n) void 0 !== a && a.call(f, "error");
          else {
            (f.onload = i.bind(null, f)),
              void 0 !== a && (f.onerror = a),
              void 0 !== c && (f.ontimeout = c),
              void 0 !== s && (f.withCredentials = s);
            var d = null !== u ? "POST" : "GET";
            f.open(d, n),
              null !== l &&
                "object" === o(l) &&
                Object.keys(l).forEach(function (t) {
                  f.setRequestHeader(t, l[t]);
                });
            try {
              null !== t &&
                "object" === o(t) &&
                window.location === window.parent.location &&
                f.setTrustToken(t);
            } catch (t) {
              Object(r.b)(t, "setTrustToken");
            }
            f.send(u);
          }
        } catch (t) {
          void 0 !== a && a.call(f, "error"), Object(r.b)(t, "xhrRequest");
        }
      }
      function a(t, e, n, o) {
        try {
          if ((void 0 === n && (n = document), void 0 === t))
            return "function" == typeof e && e(!0), !1;
          var i = n.getElementsByTagName("script")[0] || n.body.firstChild,
            a = n.createElement("script");
          if (
            ((a.type = "text/javascript"),
            (a.async = !0),
            (a.src = t),
            e && c(a, e),
            c(
              a,
              o ||
                function () {
                  Object(r.b)(
                    new Error("Error Loading Script Tag"),
                    "loadScriptTag-onerror"
                  );
                },
              [],
              "onerror"
            ),
            null !== i.parentNode)
          )
            return i.parentNode.insertBefore(a, i), !0;
        } catch (t) {
          Object(r.b)(t, "loadScriptTag", { makeVisibleToAllUsers: !0 });
        }
        return !1;
      }
      function c(t, e) {
        var n =
            2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : [],
          o =
            3 < arguments.length && void 0 !== arguments[3]
              ? arguments[3]
              : "onload";
        try {
          return (
            "function" == typeof e &&
            ((t[o] = function () {
              e.apply(null, n);
            }),
            !0)
          );
        } catch (t) {
          return Object(r.b)(t, "addCallbackFunction"), !1;
        }
      }
      function s(t) {
        try {
          return encodeURIComponent(JSON.stringify(t));
        } catch (t) {
          return Object(r.b)(t, "objToUrlParam"), "";
        }
      }
    },
    function (t, e, n) {
      "use strict";
      n.d(e, "b", function () {
        return i;
      }),
        n.d(e, "a", function () {
          return a;
        }),
        n.d(e, "d", function () {
          return c;
        }),
        n.d(e, "c", function () {
          return s;
        });
      var r = n(1),
        o = n(0);
      function i(t) {
        var e = [];
        try {
          t.hasAdServerObjectLoaded() && (e = t.getSlots());
        } catch (t) {
          Object(r.b)(t, "getDisplayAdServerSlots");
        }
        return e;
      }
      function a(t) {
        try {
          return (
            Object(o.j)(t, "sizes") &&
            Object(o.h)(t.sizes) &&
            0 !== t.sizes.length
          );
        } catch (t) {
          return Object(r.b)(t, "doesSlotHaveSizes"), !1;
        }
      }
      function c() {
        for (var t = arguments.length, e = new Array(t), n = 0; n < t; n++)
          e[n] = arguments[n];
        return function (t) {
          try {
            return !t.mediaType || -1 < e.indexOf(t.mediaType);
          } catch (t) {
            return Object(r.b)(t, "isSlotOfType"), !0;
          }
        };
      }
      function s(t) {
        try {
          return t.slotID;
        } catch (t) {
          return Object(r.b)(t, "getSlotID"), "";
        }
      }
    },
    function (t, e, n) {
      "use strict";
      n.d(e, "a", function () {
        return I;
      }),
        n.d(e, "g", function () {
          return A;
        }),
        n.d(e, "c", function () {
          return C;
        }),
        n.d(e, "f", function () {
          return k;
        }),
        n.d(e, "b", function () {
          return z;
        }),
        n.d(e, "e", function () {
          return L;
        }),
        n.d(e, "d", function () {
          return x;
        });
      var r = n(2),
        o = n(7),
        i = n(3),
        a = n(0),
        c = n(10),
        s = n(1),
        u = n(8),
        l = n(11),
        f = n(4),
        d = n(18),
        b = n(9),
        p = n(17),
        y = n(26),
        g = n(15),
        m = n(5);
      function h(t) {
        return (h =
          "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
            ? function (t) {
                return typeof t;
              }
            : function (t) {
                return t &&
                  "function" == typeof Symbol &&
                  t.constructor === Symbol &&
                  t !== Symbol.prototype
                  ? "symbol"
                  : typeof t;
              })(t);
      }
      function O(t) {
        return (
          (function (t) {
            if (Array.isArray(t)) return _(t);
          })(t) ||
          (function (t) {
            if (
              ("undefined" != typeof Symbol && null != t[Symbol.iterator]) ||
              null != t["@@iterator"]
            )
              return Array.from(t);
          })(t) ||
          w(t) ||
          (function () {
            throw new TypeError(
              "Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."
            );
          })()
        );
      }
      function v(t, e) {
        var n,
          r = Object.keys(t);
        return (
          Object.getOwnPropertySymbols &&
            ((n = Object.getOwnPropertySymbols(t)),
            e &&
              (n = n.filter(function (e) {
                return Object.getOwnPropertyDescriptor(t, e).enumerable;
              })),
            r.push.apply(r, n)),
          r
        );
      }
      function j(t) {
        for (var e = 1; e < arguments.length; e++) {
          var n = null != arguments[e] ? arguments[e] : {};
          e % 2
            ? v(Object(n), !0).forEach(function (e) {
                D(t, e, n[e]);
              })
            : Object.getOwnPropertyDescriptors
            ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n))
            : v(Object(n)).forEach(function (e) {
                Object.defineProperty(
                  t,
                  e,
                  Object.getOwnPropertyDescriptor(n, e)
                );
              });
        }
        return t;
      }
      function S(t, e) {
        return (
          (function (t) {
            if (Array.isArray(t)) return t;
          })(t) ||
          (function (t, e) {
            var n =
              null == t
                ? null
                : ("undefined" != typeof Symbol && t[Symbol.iterator]) ||
                  t["@@iterator"];
            if (null != n) {
              var r,
                o,
                i,
                a,
                c = [],
                s = !0,
                u = !1;
              try {
                if (((i = (n = n.call(t)).next), 0 === e)) {
                  if (Object(n) !== n) return;
                  s = !1;
                } else
                  for (
                    ;
                    !(s = (r = i.call(n)).done) &&
                    (c.push(r.value), c.length !== e);
                    s = !0
                  );
              } catch (t) {
                (u = !0), (o = t);
              } finally {
                try {
                  if (
                    !s &&
                    null != n.return &&
                    ((a = n.return()), Object(a) !== a)
                  )
                    return;
                } finally {
                  if (u) throw o;
                }
              }
              return c;
            }
          })(t, e) ||
          w(t, e) ||
          (function () {
            throw new TypeError(
              "Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."
            );
          })()
        );
      }
      function w(t, e) {
        var n;
        if (t)
          return "string" == typeof t
            ? _(t, e)
            : "Map" ===
                (n =
                  "Object" ===
                    (n = Object.prototype.toString.call(t).slice(8, -1)) &&
                  t.constructor
                    ? t.constructor.name
                    : n) || "Set" === n
            ? Array.from(t)
            : "Arguments" === n ||
              /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)
            ? _(t, e)
            : void 0;
      }
      function _(t, e) {
        (null == e || e > t.length) && (e = t.length);
        for (var n = 0, r = new Array(e); n < e; n++) r[n] = t[n];
        return r;
      }
      function E(t, e) {
        for (var n = 0; n < e.length; n++) {
          var r = e[n];
          (r.enumerable = r.enumerable || !1),
            (r.configurable = !0),
            "value" in r && (r.writable = !0),
            Object.defineProperty(t, T(r.key), r);
        }
      }
      function D(t, e, n) {
        (e = T(e)) in t
          ? Object.defineProperty(t, e, {
              value: n,
              enumerable: !0,
              configurable: !0,
              writable: !0,
            })
          : (t[e] = n);
      }
      function T(t) {
        return (
          (t = (function (t, e) {
            if ("object" !== h(t) || null === t) return t;
            var n = t[Symbol.toPrimitive];
            if (void 0 === n) return String(t);
            if ("object" !== h((n = n.call(t, e)))) return n;
            throw new TypeError("@@toPrimitive must return a primitive value.");
          })(t, "string")),
          "symbol" === h(t) ? t : String(t)
        );
      }
      var I = (function () {
          function t(e) {
            if (!(this instanceof t))
              throw new TypeError("Cannot call a class as a function");
            D(this, "bidConfig", void 0),
              D(this, "bidState", i.c.new),
              D(this, "_targetingSetID", void 0),
              D(this, "timing", { setAtTimes: [] }),
              D(this, "pixelSent", !1),
              D(this, "useSafeFrames", !1),
              D(this, "bidReqID", ""),
              D(this, "host", void 0),
              D(this, "ev", void 0),
              D(this, "cfe", void 0),
              D(this, "isAmp", !1),
              D(this, "doc", void 0),
              D(this, "inheritSize", void 0),
              (this.bidConfig = e),
              (this._targetingSetID = Object(a.c)()),
              r.a.getState().config.useSafeFrames && (this.useSafeFrames = !0),
              this.useSafeFrames &&
                Object(a.j)(e, "targeting") &&
                e.targeting.push("amznhost"),
              Object(a.j)(e, "meta")
                ? Object(a.h)(e.meta) ||
                  (this.reportError(
                    {
                      name: "TypeError",
                      message: "'meta' is not an 'array': ".concat(
                        JSON.stringify(e.meta)
                      ),
                    },
                    "constructor-meta"
                  ),
                  (e.meta = []))
                : (e.meta = []);
            try {
              var n = [];
              Object(a.j)(this.bidConfig, "amzndeals") &&
                (n = this.bidConfig.amzndeals.map(function (t) {
                  return "".concat(t, "amzniid");
                })),
                this.bidConfig.targeting.filter(function (t) {
                  return -1 !== t.indexOf("amzniid") && !Object(a.g)(n, t);
                });
            } catch (e) {
              this.reportError(e, "pixeling");
            }
          }
          var e, n;
          return (
            (e = t),
            (n = [
              {
                key: "reportError",
                value: function (t, e, n) {
                  Object(s.b)(t, "Bid-".concat(e), n);
                },
              },
              {
                key: "mediaType",
                get: function () {
                  var t = "d";
                  return this.bidConfig.mediaType !== f.a.VIDEO &&
                    "v" !== this.bidConfig.mediaType &&
                    "v" !== this.bidConfig.mediaType_sp
                    ? t
                    : f.a.VIDEO;
                },
              },
              {
                key: "targeting",
                get: function () {
                  var t = this;
                  try {
                    return this.bidConfig.targeting
                      .map(function (e) {
                        return "amznhost" === e
                          ? [e, encodeURIComponent(t.host)]
                          : Object(a.j)(t.bidConfig, e) &&
                            Object(a.h)(t.bidConfig[e])
                          ? [e, encodeURIComponent(t.bidConfig[e].join(","))]
                          : Object(a.j)(t.bidConfig, e)
                          ? [e, encodeURIComponent(t.bidConfig[e])]
                          : [e, ""];
                      })
                      .map(function (t) {
                        var e = (t = S(t, 2))[0];
                        t = t[1];
                        return "&".concat(e, "=").concat(t);
                      })
                      .join("");
                  } catch (t) {
                    return this.reportError(t, "targeting"), "";
                  }
                },
              },
              {
                key: "bidObject",
                get: function () {
                  try {
                    var t = {
                      slotID: this.bidConfig.slotID,
                      amzniid: this.bidConfig.amzniid,
                      amznbid: this.bidConfig.amznbid,
                      amznp: this.bidConfig.amznp,
                      amznsz: this.bidConfig.amznsz,
                      size: this.bidConfig.amznsz,
                    };
                    return (
                      this.bidConfig.amznactt &&
                        (t.amznactt = this.bidConfig.amznactt),
                      Object(a.j)(this.bidConfig, "amznadm") &&
                        (t.amznadm = this.bidConfig.amznadm),
                      this.mediaType === f.a.VIDEO &&
                        ((t.mediaType = f.a.VIDEO),
                        (t.qsParams = this.targeting),
                        (t.encodedQsParams = encodeURIComponent(
                          this.targeting
                        )),
                        (t.r_amznbid = this.bidConfig.r_amznbid),
                        (t.r_amzniid = this.bidConfig.r_amzniid),
                        (t.r_amznp = this.bidConfig.r_amznp)),
                      this.useSafeFrames && (t.amznhost = this.host),
                      t
                    );
                  } catch (t) {
                    return (
                      this.reportError(t, "bidObject", {
                        makeVisibleToAllUsers: !0,
                      }),
                      {
                        slotID: "",
                        amzniid: "error",
                        amznbid: "error",
                        amznp: "error",
                        amznsz: "error",
                        size: "error",
                      }
                    );
                  }
                },
              },
              {
                key: "newBidObject",
                get: function () {
                  var t = this;
                  try {
                    var e = {
                        slotID: this.bidConfig.slotID,
                        size: this.bidConfig.amznsz,
                        mediaType: this.mediaType,
                        targeting: {},
                        helpers: {
                          targetingKeys: this.bidConfig.targeting,
                          qsParams: function () {
                            return t.targeting;
                          },
                          encodedQsParams: function () {
                            return encodeURIComponent(t.targeting);
                          },
                        },
                      },
                      n = ["slotID", "size", "mediaType"];
                    return (
                      this.bidConfig.meta
                        .filter(function (t) {
                          return -1 === n.indexOf(t);
                        })
                        .forEach(function (n) {
                          e[n] = t.bidConfig[n];
                        }),
                      this.bidConfig.targeting.forEach(function (n) {
                        e.targeting[n] =
                          "amznhost" === n ? t.host : t.bidConfig[n];
                      }),
                      void 0 !== this.slotID &&
                        -1 !== this.slotID.indexOf("_") &&
                        (e.sasTargeting = e.helpers.targetingKeys
                          .map(function (n) {
                            return ""
                              .concat(n, "_")
                              .concat(t.slotID.split("_")[1], "=")
                              .concat(e.targeting[n]);
                          })
                          .join(";")),
                      e
                    );
                  } catch (t) {
                    return (
                      this.reportError(t, "newBidObject", {
                        makeVisibleToAllUsers: !0,
                      }),
                      {
                        slotID: "",
                        size: "",
                        mediaType: "d",
                        targeting: {},
                        helpers: {
                          targetingKeys: [],
                          qsParams: function () {
                            return "";
                          },
                          encodedQsParams: function () {
                            return "";
                          },
                        },
                      }
                    );
                  }
                },
              },
              {
                key: "slotID",
                get: function () {
                  try {
                    return this.bidConfig.slotID;
                  } catch (t) {
                    return this.reportError(t, "slotID"), "";
                  }
                },
              },
              {
                key: "matchesBidCacheId",
                value: function (t) {
                  var e = this;
                  try {
                    return this.bidConfig.targeting.reduce(function (n, r) {
                      return (
                        n ||
                        (-1 !== r.indexOf("amzniid") && e.bidConfig[r] === t)
                      );
                    }, !1);
                  } catch (t) {
                    return this.reportError(t, "matchesBidCacheId"), !1;
                  }
                },
              },
            ]) && E(e.prototype, n),
            Object.defineProperty(e, "prototype", { writable: !1 }),
            t
          );
        })(),
        P = Object(a.d)(i.q);
      function R(t, e, n) {
        try {
          var r = Object(a.i)(t.config.params) ? t.config.params : {},
            o = Object(a.i)(e.params) ? e.params : {},
            i =
              "string" == typeof n
                ? (function (t) {
                    if ((t = Object(m.a)(t).read("deviceSignal/sua")))
                      try {
                        return { device: { sua: JSON.parse(t) } };
                      } catch (t) {
                        Object(s.b)(t, "getDeviceNode");
                      }
                    return {};
                  })(n)
                : {},
            u = j(j(j({}, r), o), i);
          return 0 === Object.keys(u).length ? "" : Object(c.c)(u);
        } catch (t) {
          return (
            Object(s.b)(t, "getBidParams", { makeVisibleToAllUsers: !0 }), ""
          );
        }
      }
      function A(t) {
        var e = "validateSupplyChainObject",
          n = !1;
        function r(t, r) {
          return (
            Object(s.b)(
              { name: "TypeError", message: r },
              "".concat(e, "-").concat(t),
              { makeVisibleToAllUsers: !0 }
            ),
            !(n = !0)
          );
        }
        try {
          return Object(a.i)(t)
            ? (Object(a.j)(t, "complete")
                ? -1 === [1, 0].indexOf(t.complete) &&
                  r(
                    "schain-complete-type",
                    "The `schain.complete` property must be a `1` or `0`"
                  )
                : r(
                    "schain-complete",
                    "The `schain.complete` property must be provided"
                  ),
              Object(a.j)(t, "ver")
                ? Object(b.b)(t.ver, ["string"]) ||
                  r(
                    "schain-ver-type",
                    "The `schain.ver` property must be a string"
                  )
                : r("schain-ver", "The `schain.ver` property must be provided"),
              Object(a.j)(t, "nodes")
                ? Object(a.h)(t.nodes)
                  ? t.nodes.reduce(function (t, e) {
                      return Object(a.i)(e)
                        ? (Object(a.j)(e, "asi")
                            ? Object(b.b)(e.asi, ["string"]) ||
                              r(
                                "schain-node-asi-type",
                                "All `schain.nodes` items must have an `asi` property of type `string`"
                              )
                            : r(
                                "schain-node-asi",
                                "All `schain.nodes` items must have an `asi` property"
                              ),
                          Object(a.j)(e, "sid")
                            ? Object(b.b)(e.sid, ["string"]) ||
                              r(
                                "schain-node-sid-type",
                                "All `schain.nodes` items must have an `sid` property of type `string`"
                              )
                            : r(
                                "schain-node-sid",
                                "All `schain.nodes` items must have an `sid` property"
                              ),
                          Object(a.j)(e, "hp")
                            ? -1 === [1, 0].indexOf(e.hp) &&
                              r(
                                "schain-node-hp-type",
                                "All `schain.nodes` items must have an `hp` property which is `1` or `0`"
                              )
                            : r(
                                "schain-node-hp",
                                "All `schain.nodes` items must have an `hp` property"
                              ),
                          Object(b.b)(e.rid, ["string", "undefined"]) ||
                            r(
                              "schain-node-rid-type",
                              "If provided, the `rid` property on an `schain.nodes` item must be of type `string`"
                            ),
                          Object(b.b)(e.name, ["string", "undefined"]) ||
                            r(
                              "schain-node-name-type",
                              "If provided, the `name` property on an `schain.nodes` item must be of type `string`"
                            ),
                          Object(b.b)(e.domain, ["string", "undefined"]) ||
                            r(
                              "schain-node-domain-type",
                              "If provided, the `domain` property on an `schain.nodes` item must be of type `string`"
                            ),
                          t && !n)
                        : r(
                            "schain-node-type",
                            "All `schain.nodes` items must be objects"
                          );
                    }, !n)
                  : r(
                      "schain-nodes-type",
                      "The `schain.nodes` property must be an `Array`"
                    )
                : r(
                    "schain-nodes",
                    "The `schain.nodes` property must be provided"
                  ))
            : r("schain", "The `schain` value must be an object");
        } catch (t) {
          return Object(s.b)(t, e, { makeVisibleToAllUsers: !0 }), !1;
        }
      }
      function C(t, e, n, l, b) {
        try {
          var h,
            v,
            S,
            w,
            _ =
              null !=
              (h = null == b || null == (v = b.initConfig) ? void 0 : v.pubID)
                ? h
                : null == (S = r.a.getState().config)
                ? void 0
                : S.pubID,
            E = r.a.getState(),
            D =
              t._endpointDomain ||
              Object(o.c)("host", E.hosts.DEFAULT_AAX_BID_HOST),
            T = E.cfg.DTB_PATH,
            I = "bid",
            C =
              (E.experiments.shouldUseTestBidEndpoint &&
                null !== E.cfg.TEST_BID_ENDPOINT &&
                (I = E.cfg.TEST_BID_ENDPOINT),
              {
                src: Object(g._getInitConfig)({
                  overrides: null == b ? void 0 : b.initConfig,
                }).pubID,
                u:
                  null != b && b.contextURL
                    ? encodeURIComponent(b.contextURL)
                    : Object(u.f)(window),
                pr: Object(u.g)(window),
                pid: P,
                cb: t.bidReqID,
                ws: Object(a.f)(window),
                v: i.l,
                t: e,
                slots: (function (t) {
                  try {
                    return Object(c.c)(
                      t
                        .map(function (t) {
                          var e;
                          if (
                            (Object(a.j)(t, "mediaType") &&
                              t.mediaType === f.a.VIDEO) ||
                            t.mediaType === f.a.MULTI_FORMAT
                          )
                            e = t.aaxSlot;
                          else {
                            if (
                              !(
                                Object(a.j)(t, "sizes") &&
                                0 < t.sizes.length &&
                                Object(a.j)(t, "slotID")
                              )
                            )
                              return (
                                Object(s.b)(
                                  {
                                    name: "SlotError",
                                    message:
                                      "There was an error with the configuration for this slot: ".concat(
                                        JSON.stringify(t.rawSlot)
                                      ),
                                  },
                                  "buildSlotsUrlParam-invalidSlot",
                                  { makeVisibleToAllUsers: !0 }
                                ),
                                { id: "ERROR", mt: d.a.VIDEO, error: !0 }
                              );
                            var n = t.aaxSlot;
                            Object(a.j)(t, "slotName") &&
                              t.slotName !== t.slotID &&
                              ((n.sd = t.slotID), (n.sn = t.slotName)),
                              (e = n);
                          }
                          return e;
                        })
                        .filter(function (t) {
                          return !0 !== t.error;
                        })
                    );
                  } catch (t) {
                    return (
                      Object(s.b)(t, "buildSlotsUrlParam", {
                        makeVisibleToAllUsers: !0,
                      }),
                      ""
                    );
                  }
                })(t.validSlots),
                pj: R(E, t, _),
                sg: Object(y.a)(_),
                cfgv: Object(u.e)(),
                bb: Object(u.d)(t),
                schain: (function (t, e) {
                  try {
                    var n,
                      r = Object(m.a)(e).read("ad/schain");
                    if (Object(a.j)(t.config, "schain")) n = t.config.schain;
                    else {
                      if (!r || !A(r)) return "";
                      n = r;
                    }
                    return encodeURIComponent(
                      ["".concat(n.ver, ",").concat(n.complete)]
                        .concat(
                          O(
                            n.nodes.map(function (t) {
                              return [
                                "asi",
                                "sid",
                                "hp",
                                "rid",
                                "name",
                                "domain",
                              ]
                                .map(function (e) {
                                  return Object(a.j)(t, e) ? t[e] : "";
                                })
                                .map(function (t) {
                                  return encodeURIComponent(t);
                                })
                                .map(function (t) {
                                  return t.replace(/\!/g, "%21");
                                })
                                .join(",");
                            })
                          )
                        )
                        .join("!")
                    );
                  } catch (t) {
                    return (
                      Object(s.b)(t, "getSupplyChainObject", {
                        makeVisibleToAllUsers: !0,
                      }),
                      ""
                    );
                  }
                })(E, _),
              });
          try {
            var k = Object(m.a)(_).read("deviceSignal/cookieDeprecationLabel");
            k && "" !== k && (C.cdep = encodeURIComponent(k));
          } catch (t) {}
          try {
            var z = Object(m.a)(_).read("consent/GPPData") || {},
              L = z.gppString,
              x = z.applicableSections,
              U = 0 < (L || "").length,
              B = 0 < (x || []).length;
            U && (C.gpp = encodeURIComponent(L)),
              B && (C.gpp_sid = encodeURIComponent(JSON.stringify(x)));
          } catch (t) {
            Object(s.b)(t, "gpp");
          }
          if ("[]" === C.slots || "" === C.slots)
            throw new Error("No slots available for bid request");
          try {
            var M = Object(m.a)(_).read("sessionMarker/marker");
            0 < (null != M ? M : "").length &&
              (C.sm = encodeURIComponent(M.split("_")[0]));
          } catch (t) {}
          r.a.dispatch({
            type: "RECORD_AAX_REQUEST",
            data: {
              bidConfig: t,
              bidReqID: t.bidReqID,
              timeout: e,
              ws: C.ws,
              url: C.u,
              rqTs: Date.now(),
            },
          }),
            E.experiments.chunkRequests &&
              ((w = t.bidReqID.split("-")),
              r.a.dispatch({
                type: "RECORD_NETWORK_EXCHANGE",
                fid: w[0],
                networkID: parseInt(w[1], 10),
                timestamp: Date.now(),
                exchangeType: "request",
              })),
            Object(g._getInitConfig)({
              overrides: null == b ? void 0 : b.initConfig,
            }).isSelfServePub && ((C.pubid = C.src), (C.src = 600));
          var N = Object(u.c)(),
            V = Object(o.c)("bidParams"),
            F =
              (Object(a.i)(V) && (C = j(j({}, C), V)),
              Object(a.i)(n) &&
                (Object(a.j)(n, "enabled") &&
                  (C.gdpre = encodeURIComponent(n.enabled)),
                Object(a.j)(n, "consent") &&
                  (C.gdprc = encodeURIComponent(n.consent)),
                Object(a.j)(n, "log")) &&
                (C.gdprl = Object(c.c)(n.log)),
              Object(a.j)(
                Object(g._getInitConfig)({
                  overrides: null == b ? void 0 : b.initConfig,
                }),
                "useSafeFrames"
              ) &&
                Object(g._getInitConfig)({
                  overrides: null == b ? void 0 : b.initConfig,
                }).useSafeFrames &&
                (C.sf = "1"),
              Object(p.b)()),
            q =
              (F && (l.ids.at = F),
              (C.vm = (function (t, e) {
                var n = !t || 0 === Object.keys(t.ids).length,
                  r = n ? "" : Object(c.c)({ ids: t.ids, md: t.md });
                try {
                  Object(m.a)(e).safelyRecord("ortbVendors/all/process");
                  var o = Object(m.a)(e).read("ortbVendors/vm");
                  o &&
                    (r = n
                      ? Object(c.c)({ vendors: o })
                      : Object(c.c)({ ids: t.ids, md: t.md, vendors: o }));
                } catch (t) {
                  Object(s.b)(t, "getVmParam");
                }
                return r;
              })(l, _)),
              Object.keys(C)
                .filter(function (t) {
                  return (
                    Object(a.j)(C, t) &&
                    "undefined" !== C[t] &&
                    "" !== C[t] &&
                    null !== C[t]
                  );
                })
                .map(function (t) {
                  return "".concat(t, "=").concat(C[t]);
                })
                .join("&"));
          N.cookiesParams && (q += N.cookiesParams);
          var H = ""
            .concat(i.r)
            .concat(D)
            .concat(T, "/")
            .concat(I, "?")
            .concat(q);
          return (
            r.a.dispatch({
              type: "RECORD_AAX_REQ_PROP",
              bidReqID: t.bidReqID,
              key: "urlLength",
              value: H.length,
            }),
            H
          );
        } catch (t) {
          return (
            Object(s.b)(t, "buildBidUrl", { makeVisibleToAllUsers: !0 }), ""
          );
        }
      }
      function k(t, e) {
        try {
          return (
            (Object(a.j)(t, "deals") && !0 === t.deals) ||
            !0 === e.needNewBidObject
          );
        } catch (t) {
          return Object(s.b)(t, "isNewBidObjectRequired"), !1;
        }
      }
      function z(t, e, n) {
        try {
          var r = t.map(l.c),
            o = e.slots
              .filter(Object(l.d)(f.a.DISPLAY, f.a.MULTI_FORMAT))
              .map(l.c)
              .filter(function (t) {
                return !Object(a.g)(r, t);
              }),
            c = n ? i.t.bidInFlight : i.t.noBid;
          return t.concat(
            o.map(function (t) {
              return new I({
                size: "0x0",
                crid: "",
                slotID: t,
                mediaType: "d",
                meta: ["slotID", "mediaType", "size"],
                amznbid: c,
                amzniid: "",
                amznp: c,
                amznsz: "0x0",
                targeting: ["amzniid", "amznbid", "amznp", "amznsz"],
              });
            })
          );
        } catch (e) {
          return Object(s.b)(e, "addStateTrackingBidsToRealBids"), t;
        }
      }
      function L(t, e) {
        try {
          var n;
          return (
            !Object(a.g)(
              r.a.getState().displayAdServer.noBidSlotIDs,
              t.slotID
            ) &&
            ((n = r.a.getState().AAXReqs.filter(function (e) {
              return e.bidReqID === t.bidReqID;
            })[0]),
            !(
              (Object(a.j)(n, "rqTs") && Date.now() - n.rqTs > 24e4) ||
              (Object(a.j)(n, "url") &&
                !Object(a.b)(
                  n.url,
                  null != e && e.contextURL
                    ? encodeURIComponent(e.contextURL)
                    : Object(u.f)(window)
                )) ||
              t.bidState === i.c.rendered
            ))
          );
        } catch (e) {
          return Object(s.b)(e, "isBidEligible"), !1;
        }
      }
      function x(t, e) {
        try {
          var n = t.map(l.c),
            o = r.a.getState();
          return Object.keys(o.slotBids)
            .filter(function (t) {
              return Object(a.g)(n, t);
            })
            .reduce(function (t, n) {
              var a = o.slotBids[n]
                .filter(function (t) {
                  return t.bidState === i.c.new;
                })
                .filter(function (t) {
                  return L(t, e);
                });
              return (
                0 < a.length &&
                  ((a = a[a.length - 1]),
                  r.a.dispatch({
                    type: "BID_STATE_CHANGE",
                    slotID: n,
                    _targetingSetID: a._targetingSetID,
                    bidState: i.c.exposed,
                  }),
                  (t[n] = a)),
                t
              );
            }, {});
        } catch (t) {
          return Object(s.b)(t, "getNewSlotBidsAndExposeForRequestedSlots"), {};
        }
      }
    },
    function (t, e, n) {
      "use strict";
      function r(t) {
        return (r =
          "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
            ? function (t) {
                return typeof t;
              }
            : function (t) {
                return t &&
                  "function" == typeof Symbol &&
                  t.constructor === Symbol &&
                  t !== Symbol.prototype
                  ? "symbol"
                  : typeof t;
              })(t);
      }
      function o(t, e) {
        for (var n = 0; n < e.length; n++) {
          var r = e[n];
          (r.enumerable = r.enumerable || !1),
            (r.configurable = !0),
            "value" in r && (r.writable = !0),
            Object.defineProperty(t, a(r.key), r);
        }
      }
      function i(t, e, n) {
        (e = a(e)) in t
          ? Object.defineProperty(t, e, {
              value: n,
              enumerable: !0,
              configurable: !0,
              writable: !0,
            })
          : (t[e] = n);
      }
      function a(t) {
        return (
          (t = (function (t, e) {
            if ("object" !== r(t) || null === t) return t;
            var n = t[Symbol.toPrimitive];
            if (void 0 === n) return String(t);
            if ("object" !== r((n = n.call(t, e)))) return n;
            throw new TypeError("@@toPrimitive must return a primitive value.");
          })(t, "string")),
          "symbol" === r(t) ? t : String(t)
        );
      }
      n.d(e, "a", function () {
        return c;
      });
      var c = (function () {
        function t() {
          if (!(this instanceof t))
            throw new TypeError("Cannot call a class as a function");
          i(this, "isSupported", !1), i(this, "needNewBidObject", !1);
        }
        var e, n;
        return (
          (e = t),
          (n = [
            { key: "cmdQueuePush", value: function (t) {} },
            { key: "slotRenderEndedEvent", value: function (t) {} },
            { key: "setTargeting", value: function (t, e) {} },
            {
              key: "getTargeting",
              value: function (t) {
                return [];
              },
            },
            { key: "clearTargeting", value: function (t, e) {} },
            {
              key: "hasAdServerObjectLoaded",
              value: function () {
                return !1;
              },
            },
            {
              key: "isCommandQueueDefined",
              value: function () {
                return !1;
              },
            },
            {
              key: "getSlots",
              value: function () {
                return [];
              },
            },
          ]) && o(e.prototype, n),
          Object.defineProperty(e, "prototype", { writable: !1 }),
          t
        );
      })();
    },
    function (t, e, n) {
      "use strict";
      n.d(e, "a", function () {
        return l;
      });
      var r = n(0),
        o = n(1),
        i = n(4);
      function a(t) {
        return (a =
          "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
            ? function (t) {
                return typeof t;
              }
            : function (t) {
                return t &&
                  "function" == typeof Symbol &&
                  t.constructor === Symbol &&
                  t !== Symbol.prototype
                  ? "symbol"
                  : typeof t;
              })(t);
      }
      function c(t, e) {
        for (var n = 0; n < e.length; n++) {
          var r = e[n];
          (r.enumerable = r.enumerable || !1),
            (r.configurable = !0),
            "value" in r && (r.writable = !0),
            Object.defineProperty(t, u(r.key), r);
        }
      }
      function s(t, e, n) {
        (e = u(e)) in t
          ? Object.defineProperty(t, e, {
              value: n,
              enumerable: !0,
              configurable: !0,
              writable: !0,
            })
          : (t[e] = n);
      }
      function u(t) {
        return (
          (t = (function (t, e) {
            if ("object" !== a(t) || null === t) return t;
            var n = t[Symbol.toPrimitive];
            if (void 0 === n) return String(t);
            if ("object" !== a((n = n.call(t, e)))) return n;
            throw new TypeError("@@toPrimitive must return a primitive value.");
          })(t, "string")),
          "symbol" === a(t) ? t : String(t)
        );
      }
      var l = (function () {
        function t(e) {
          if (!(this instanceof t))
            throw new TypeError("Cannot call a class as a function");
          s(this, "_slotConfig", void 0),
            s(this, "rawSlot", void 0),
            (this._slotConfig = e),
            (this.rawSlot = e);
        }
        var e, n;
        return (
          (e = t),
          (n = [
            {
              key: "slotID",
              get: function () {
                return this._slotConfig.slotID;
              },
            },
            {
              key: "slotName",
              get: function () {
                return this._slotConfig.slotName;
              },
            },
            {
              key: "slotParams",
              get: function () {
                return this._slotConfig.slotParams;
              },
            },
            {
              key: "companions",
              get: function () {
                return this._slotConfig.companions;
              },
            },
            {
              key: "slotConfig",
              get: function () {
                return {
                  slotID: this.slotID,
                  slotName: this.slotName,
                  sizes: this.sizes,
                };
              },
            },
            {
              key: "mediaType",
              get: function () {
                return i.a.DISPLAY;
              },
            },
            {
              key: "sizes",
              get: function () {
                return [];
              },
            },
            {
              key: "floor",
              get: function () {
                var t;
                return Object(r.j)(this._slotConfig, "floor") &&
                  "USD" === this._slotConfig.floor.currency &&
                  this.validateFloorValue(this._slotConfig.floor.value)
                  ? this._slotConfig.floor
                  : t;
              },
            },
            {
              key: "aaxSlotParams",
              get: function () {
                var t = this;
                try {
                  return Object(r.j)(this, "slotParams") &&
                    Object(r.i)(this.slotParams)
                    ? Object.keys(this.slotParams)
                        .filter(function (e) {
                          return t.validateSlotParamValue(t.slotParams[e]);
                        })
                        .reduce(function (e, n) {
                          return (e[n] = t.slotParams[n]), e;
                        }, {})
                    : void 0;
                } catch (t) {
                  return this.reportError(t, "aaxSlotParams"), this.slotParams;
                }
              },
            },
            {
              key: "aaxSlot",
              get: function () {
                var t = { kv: this.aaxSlotParams };
                return (
                  this.floor &&
                    ((t.fc = this.floor.currency), (t.fp = this.floor.value)),
                  t
                );
              },
            },
            {
              key: "isValid",
              value: function () {
                var t,
                  e,
                  n = [],
                  o = [];
                return (
                  void 0 === this.slotID
                    ? n.push("'slotID' must be provided and a string")
                    : "string" != typeof this.slotID &&
                      o.push("'slotID' must be a string"),
                  Object(r.j)(this._slotConfig, "floor") &&
                    Object(r.i)(this._slotConfig.floor) &&
                    ((t = (e = this._slotConfig.floor).currency),
                    (e = e.value),
                    "USD" !== t && o.push("'floor' currency only supports USD"),
                    this.validateFloorValue(e) ||
                      o.push("'floor' value must be a positive integer")),
                  Object(r.j)(this, "companions") &&
                    (Object(r.h)(this.companions)
                      ? this.companions.forEach(function (t) {
                          "string" != typeof t &&
                            n.push(
                              "'companions' contains a non-string item : ".concat(
                                t
                              )
                            );
                        })
                      : n.push("'companions' contains non-array")),
                  0 < n.length
                    ? (this.reportIsValidMessages([].concat(n, o), !0), !1)
                    : (0 < o.length && this.reportIsValidMessages(o, !1), !0)
                );
              },
            },
            {
              key: "reportError",
              value: function (t, e, n) {
                Object(o.b)(t, "Slot-".concat(e), n);
              },
            },
            { key: "setTargeting", value: function (t, e) {} },
            {
              key: "getTargeting",
              value: function (t) {
                return [];
              },
            },
            { key: "clearTargeting", value: function (t) {} },
            {
              key: "reportIsValidMessages",
              value: function (t, e) {
                this.reportError(
                  {
                    name: "SlotValidationError",
                    message: this.buildIsValidMessage(t, this._slotConfig),
                  },
                  "validation-".concat(e ? "error" : "warn"),
                  { makeVisibleToAllUsers: !0 }
                );
              },
            },
            {
              key: "validateSlotParamValue",
              value: function (t) {
                var e = this;
                try {
                  return Object(r.h)(t)
                    ? 0 < t.length &&
                        t.reduce(function (t, n) {
                          return t && e.validateSlotParamValue(n);
                        }, !0)
                    : "string" == typeof t && 0 < t.length;
                } catch (t) {
                  return Object(o.b)(t, "validateSlotParamValue"), !1;
                }
              },
            },
            {
              key: "validateFloorValue",
              value: function (t) {
                return "number" == typeof t && 0 < t && t % 1 == 0;
              },
            },
            {
              key: "buildIsValidMessage",
              value: function (t, e) {
                return (
                  "There was an issue with the configuration for this slot: ".concat(
                    JSON.stringify(e),
                    "\n"
                  ) +
                  t
                    .map(function (t) {
                      return "- ".concat(t);
                    })
                    .join("\n")
                );
              },
            },
          ]) && c(e.prototype, n),
          Object.defineProperty(e, "prototype", { writable: !1 }),
          t
        );
      })();
    },
    function (i, t, e) {
      "use strict";
      e.r(t),
        e.d(t, "unsafelyGuessAccountID", function () {
          return Jt;
        }),
        e.d(t, "_getInitConfig", function () {
          return te;
        });
      var Tt = e(16),
        _t = e(2),
        Dt = e(8),
        Et = e(0),
        It = e(11),
        Pt = e(7),
        At = e(3),
        ee = e(28),
        Ct = e(24),
        kt = e(21),
        Rt = e(1),
        zt = e(10),
        Lt = e(23),
        n = e(29),
        xt = e(27),
        Ut = e(12),
        a = e(13),
        Nt = e(4),
        Bt = e(9),
        Mt = e(20),
        Vt = e(17),
        Ft = e(30),
        ne = e(34),
        qt = e(19),
        re = e(36),
        oe = e(25),
        Ht = e(5),
        Gt = e(6),
        Qt = e(31),
        ie = e(26),
        ae = e(35);
      function Xt(t) {
        return l(t) || u(t) || s(t) || c();
      }
      function c() {
        throw new TypeError(
          "Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."
        );
      }
      function s(t, e) {
        var n;
        if (t)
          return "string" == typeof t
            ? r(t, e)
            : "Map" ===
                (n =
                  "Object" ===
                    (n = Object.prototype.toString.call(t).slice(8, -1)) &&
                  t.constructor
                    ? t.constructor.name
                    : n) || "Set" === n
            ? Array.from(t)
            : "Arguments" === n ||
              /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)
            ? r(t, e)
            : void 0;
      }
      function u(t) {
        if (
          ("undefined" != typeof Symbol && null != t[Symbol.iterator]) ||
          null != t["@@iterator"]
        )
          return Array.from(t);
      }
      function l(t) {
        if (Array.isArray(t)) return r(t);
      }
      function r(t, e) {
        (null == e || e > t.length) && (e = t.length);
        for (var n = 0, r = new Array(e); n < e; n++) r[n] = t[n];
        return r;
      }
      function Wt(t) {
        return (Wt =
          "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
            ? function (t) {
                return typeof t;
              }
            : function (t) {
                return t &&
                  "function" == typeof Symbol &&
                  t.constructor === Symbol &&
                  t !== Symbol.prototype
                  ? "symbol"
                  : typeof t;
              })(t);
      }
      function o(t, e) {
        var n,
          r = Object.keys(t);
        return (
          Object.getOwnPropertySymbols &&
            ((n = Object.getOwnPropertySymbols(t)),
            e &&
              (n = n.filter(function (e) {
                return Object.getOwnPropertyDescriptor(t, e).enumerable;
              })),
            r.push.apply(r, n)),
          r
        );
      }
      function Yt(t) {
        for (var e = 1; e < arguments.length; e++) {
          var n = null != arguments[e] ? arguments[e] : {};
          e % 2
            ? o(Object(n), !0).forEach(function (e) {
                $t(t, e, n[e]);
              })
            : Object.getOwnPropertyDescriptors
            ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n))
            : o(Object(n)).forEach(function (e) {
                Object.defineProperty(
                  t,
                  e,
                  Object.getOwnPropertyDescriptor(n, e)
                );
              });
        }
        return t;
      }
      function $t(t, e, n) {
        return (
          (e = f(e)) in t
            ? Object.defineProperty(t, e, {
                value: n,
                enumerable: !0,
                configurable: !0,
                writable: !0,
              })
            : (t[e] = n),
          t
        );
      }
      function f(t) {
        return "symbol" === Wt((t = d(t, "string"))) ? t : String(t);
      }
      function d(t, e) {
        if ("object" !== Wt(t) || null === t) return t;
        var n = t[Symbol.toPrimitive];
        if (void 0 === n) return ("string" === e ? String : Number)(t);
        if ("object" !== Wt((n = n.call(t, e || "default")))) return n;
        throw new TypeError("@@toPrimitive must return a primitive value.");
      }
      var Kt = new a.a();
      function Jt(t) {
        try {
          var e;
          if ("string" == typeof t && 0 < t.trim().length) return t;
          if ("number" == typeof t && 0 < t) return t.toString();
          var n = null == (e = _t.a.getState().config) ? void 0 : e.pubID;
          if (n && "number" == typeof n && 0 < n) return n.toString();
          if (n && "string" == typeof n && "" !== n) return n;
          var r = Array.from(window._aps.keys()).filter(function (t) {
            return "_system" !== t && "" !== t;
          })[0];
          if (r) return r;
        } catch (t) {}
        return "_system";
      }
      function Zt(t, e, n, r) {
        try {
          Object(Ht.a)(t).safelyRecord(
            "cellophane/".concat(e, "/enter"),
            $t({}, r, n)
          );
          var o = Object(Ht.a)(t).read("cellophane/".concat(r));
          void 0 !== n && void 0 === o
            ? Object(Et.k)(1) &&
              Object(Rt.b)(
                new Error("Missing ".concat(r, " from client")),
                "cellophaneWrap"
              )
            : (n = o);
        } catch (t) {
          Object(Rt.b)(t, "cellophaneWrap");
        }
        return n;
      }
      function te(t) {
        return (t = t.overrides), Yt(Yt({}, _t.a.getState().config), t);
      }
      try {
        var b = Object(n.b)(window.apstag);
        b
          ? Object(Rt.b)(
              new Error(
                "apstag has already loaded - preventing duplicate load"
              ),
              "apstag-duplicateLoad"
            )
          : (Object(n.a)(window) &&
              Object(Rt.b)(
                new Error("apstag was loaded and then destroyed"),
                "apstag-destroyReload",
                { makeVisibleToAllUsers: !0 }
              ),
            (window.apstagLOADED = !0),
            (function () {
              Object(Et.k)(1) &&
                Object(Rt.b)(
                  new Error(
                    "apstag-".concat(
                      At.l,
                      " reference pixel - Used to compute ratios for other errors"
                    )
                  ),
                  "REFERENCE"
                );
              var a = new oe.a({ stateContainer: _t.a, globalContext: window }),
                t = (a.attemptConsentDataSync(), "ls"),
                n =
                  Object(Pt.d)("console") ||
                  (function () {
                    try {
                      return (
                        -1 !==
                          window.location.href.indexOf(
                            "amzn_debug_console=1"
                          ) && ((t = "url"), !0)
                      );
                    } catch (t) {
                      return !1;
                    }
                  })(),
                r =
                  Object(Pt.d)("console_v2") ||
                  (function () {
                    try {
                      return (
                        -1 !==
                          window.location.href.indexOf(
                            "amzn_debug_console=2"
                          ) && ((t = "url"), !0)
                      );
                    } catch (t) {
                      return !1;
                    }
                  })();
              function o(t) {
                try {
                  return (
                    !_t.a.getState().experiments.chunkRequests ||
                    0 ===
                      _t.a
                        .getState()
                        .bidReqs[t.split("-")[0]].networkReqs.filter(function (
                          t
                        ) {
                          return t.inFlight;
                        }).length
                  );
                } catch (t) {
                  return Object(Rt.b)(t, "_isRequestComplete"), 1;
                }
              }
              function c(t, e) {
                try {
                  !_t.a.getState().bidReqs[t].hasCallbackExecuted &&
                    o(t) &&
                    (_t.a.dispatch({ type: "RECORD_CALLBACK", fid: t }), e());
                } catch (t) {
                  Object(Rt.b)(t, "_checkAndCallCallback");
                }
              }
              function s(t) {
                try {
                  _t.a.getState().experiments.chunkRequests &&
                    _t.a.dispatch({
                      type: "RECORD_NETWORK_EXCHANGE",
                      fid: t[0],
                      timestamp: Date.now(),
                      exchangeType: "response",
                      networkID: parseInt(t[1], 10),
                    });
                } catch (t) {
                  Object(Rt.b)(t, "_recordResponse");
                }
              }
              function b(t, e, n, r, o) {
                var i = n.split("-");
                Object(Ht.a)(r)
                  .record("adExchange/bid/fetch", {
                    URL: t,
                    fetchBidsConfig: o,
                  })
                  .catch(function () {})
                  .finally(function () {
                    s(i), c(i[0], e);
                  });
              }
              function i(t) {
                try {
                  var e = new Date();
                  return e.setTime(e.getTime() + 1e3 * t), e.toUTCString();
                } catch (t) {
                  return (
                    Object(Rt.b)(t, "_getCookieExpiry"),
                    "Thu, 01 Jan 1970 00:00:00 GMT"
                  );
                }
              }
              function e(t) {
                try {
                  Object(Et.j)(t, "cr") &&
                    t.cr.forEach(function (t) {
                      var e = -1 !== t.exp ? i(t.exp) : Object(Et.e)(365);
                      Gt.a.getDefault().cookie.setItem(t.k, t.v, e);
                    });
                } catch (t) {
                  Object(Rt.b)(t, "_setFirstPartyCookies");
                }
              }
              function x(t, e, n) {
                try {
                  var r;
                  Object(Et.j)(t, "cb") &&
                    (_t.a.dispatch({
                      type: "RECORD_AAX_REQ_PROP",
                      bidReqID: t.cb,
                      key: "resTs",
                      value: Date.now(),
                    }),
                    (r = new RegExp("e/dtb/bid.*cb=".concat(t.cb))),
                    _t.a.dispatch({
                      type: "RECORD_AAX_REQ_PROP",
                      bidReqID: t.cb,
                      key: "perf",
                      value: Object(ee.b)(window, r),
                    })),
                    Object(Et.j)(t, "cfg") &&
                      _t.a.dispatch({ type: "SET_CFG", cfg: t.cfg }),
                    nt(t, e, n);
                } catch (t) {
                  Object(Rt.b)(t, "_doOnAaxResponse", {
                    makeVisibleToAllUsers: !0,
                  });
                }
              }
              function U(t) {
                try {
                  Object(Qt.b)(t),
                    e(t),
                    Object(Et.j)(t, "cfg") &&
                      Gt.a
                        .getDefault()
                        .localStorage.setItem(At.d, JSON.stringify(t.cfg), {
                          ignoreFailure: !0,
                        }),
                    N(t);
                } catch (t) {
                  Object(Rt.b)(t, "_doAfterAaxResponse", {
                    makeVisibleToAllUsers: !0,
                  });
                }
              }
              function N(t) {
                try {
                  var e;
                  Object(Et.j)(t, "fp") &&
                    ((e = t.fp), Object(Et.j)(e, "length")) &&
                    e.forEach(function (t) {
                      var e = t.d || 0;
                      setTimeout(function () {
                        Object(ae.a)(t.s);
                      }, e);
                    });
                } catch (t) {
                  Object(Rt.b)(t, "fireAAXPixels");
                }
              }
              function B() {
                try {
                  _t.a.getState().Q.forEach(function (t) {
                    var e = "init";
                    switch (t[0]) {
                      case "i":
                        e = "init";
                        break;
                      case "f":
                        e = "fetchBids";
                        break;
                      case "di":
                        e = "deleteId";
                        break;
                      case "ri":
                        e = "renewId";
                        break;
                      case "ui":
                        e = "updateId";
                        break;
                      default:
                        return;
                    }
                    window.apstag[e].apply(null, t[1]);
                  });
                } catch (t) {
                  Object(Rt.b)(t, "_QHandler", { makeVisibleToAllUsers: !0 });
                }
              }
              function M(t) {
                try {
                  Object(Et.i)(t) ||
                    (Object(Rt.c)("init.config", Wt(t), "object"),
                    (t = { pubID: "err" })),
                    Object(Bt.b)(t.pubID, ["string", "number"])
                      ? "number" == typeof t.pubID &&
                        (t.pubID = "".concat(t.pubID))
                      : Object(Rt.c)(
                          "init.config.pubID",
                          Wt(t.pubID),
                          "string"
                        ),
                    Object(Bt.b)(t.adServer, ["undefined", "string"]) ||
                      Object(Rt.c)(
                        "init.config.adServer",
                        Wt(t.adServer),
                        "string"
                      ),
                    Object(Bt.a)(t.bidTimeout) ||
                      ("string" == typeof t.bidTimeout
                        ? Object(Rt.b)(
                            {
                              name: "string-".concat(t.bidTimeout),
                              message:
                                "init.config.bidTimeout was a non-numeric string '".concat(
                                  t.bidTimeout,
                                  "'"
                                ),
                            },
                            "TypeError-init.config.bidTimeout",
                            { makeVisibleToAllUsers: !0 }
                          )
                        : Object(Rt.c)(
                            "init.config.bidTimeout",
                            Wt(t.bidTimeout),
                            "number"
                          )),
                    Object(Bt.b)(t.gdpr, ["undefined", "object"])
                      ? "object" !== Wt(t.gdpr) ||
                        Object(Bt.a)(t.gdpr.cmpTimeout) ||
                        (Object(Bt.b)(t.gdpr.cmpTimeout, [
                          "string",
                          "undefined",
                        ])
                          ? Object(Rt.b)(
                              {
                                name: "string-".concat(t.bidTimeout),
                                message:
                                  "init.config.gdpr.cmpTimeout was a non-numeric string '".concat(
                                    t.gdpr.cmpTimeout,
                                    "'"
                                  ),
                              },
                              "TypeError-init.config.gdpr.cmpTimeout",
                              { makeVisibleToAllUsers: !0 }
                            )
                          : Object(Rt.c)(
                              "init.config.gdpr.cmpTimeout",
                              Wt(t.gdpr.cmpTimeout),
                              "number"
                            ))
                      : Object(Rt.c)("init.config.gdpr", Wt(t.gdpr), "object"),
                    Object(Et.j)(t, "params") && !Object(Et.i)(t.params)
                      ? Object(Rt.c)(
                          "init.config.params",
                          Wt(t.params),
                          "object"
                        )
                      : Object(Et.j)(t, "params") &&
                        Object.keys(t.params).forEach(function (e) {
                          return !(
                            !Object(Et.j)(t, "params") ||
                            ("string" != typeof t.params[e] &&
                              "number" != typeof t.params[e] &&
                              (Object(Et.h)(t.params[e])
                                ? !t.params[e].reduce(function (t, e) {
                                    return (
                                      t &&
                                      ("string" == typeof e ||
                                        "number" == typeof e)
                                    );
                                  }, !0) &&
                                  (Object(Rt.b)(
                                    {
                                      name: "non-string array item",
                                      message: "'init.config.params.".concat(
                                        e,
                                        " contains a non-string item"
                                      ),
                                    },
                                    "TypeError-init.config.params.".concat(e),
                                    { makeVisibleToAllUsers: !0 }
                                  ),
                                  1)
                                : (Object(Rt.c)(
                                    "init.config.params.".concat(e),
                                    Wt(t.params[e]),
                                    "string' or 'array"
                                  ),
                                  1)))
                          );
                        }),
                    Object(Et.j)(t, "blockedBidders") &&
                    !Object(Et.h)(t.blockedBidders)
                      ? Object(Rt.c)(
                          "init.config.blockedBidders",
                          Wt(t.blockedBidders),
                          "array"
                        )
                      : Object(Et.j)(t, "blockedBidders") &&
                        Object(Et.h)(t.blockedBidders) &&
                        (t.blockedBidders.reduce(function (t, e) {
                          return (
                            t && ("string" == typeof e || "number" == typeof e)
                          );
                        }, !0) ||
                          Object(Rt.b)(
                            {
                              name: "non-string array item",
                              message:
                                "'init.config.blockedBidders contains a non-string item",
                            },
                            "TypeError-init.config.blockedBidders",
                            { makeVisibleToAllUsers: !0 }
                          )),
                    Object(Bt.b)(t.simplerGPT, ["undefined", "boolean"]) ||
                      Object(Rt.c)(
                        "init.config.simplerGPT",
                        Wt(t.simplerGPT),
                        "boolean"
                      ),
                    Object(Bt.b)(t.deals, ["undefined", "boolean"]) ||
                      Object(Rt.c)("init.config.deals", Wt(t.deals), "boolean"),
                    Object(Bt.b)(t.schain, ["undefined", "object"]) &&
                    null !== t.schain
                      ? Object(Et.j)(t, "schain") &&
                        !Object(Ut.g)(t.schain) &&
                        delete t.schain
                      : (Object(Rt.c)(
                          "init.config.schain",
                          Wt(t.schain),
                          "object"
                        ),
                        delete t.schain),
                    Object(Bt.b)(t.useSafeFrames, ["undefined", "boolean"]) ||
                      (Object(Rt.c)(
                        "init.config.useSafeFrames",
                        Wt(t.useSafeFrames),
                        "boolean"
                      ),
                      delete t.useSafeFrames),
                    Object(Bt.b)(t.signals, ["undefined", "object"])
                      ? delete t.signals
                      : Object(Rt.c)(
                          "init.config.signals",
                          Wt(t.signals),
                          "object"
                        );
                } catch (e) {
                  Object(Rt.b)(e, "_validateAndStoreConfig-validateConfig");
                }
                try {
                  var e = _t.a.getState().config;
                  Object(Et.j)(e, "pubID") &&
                    Object(Et.j)(t, "pubID") &&
                    e.pubID !== t.pubID &&
                    Object(Rt.b)(
                      new Error(
                        "`apstag.init` was called multiple times with different pubIDs ("
                          .concat(e.pubID, " then ")
                          .concat(t.pubID, ")")
                      ),
                      "_validateAndStoreConfig-diffPubId",
                      { makeVisibleToAllUsers: !0 }
                    ),
                    _t.a.dispatch({
                      type: "SET_CONFIG",
                      config: t,
                      defaultCmpTimeout: _t.a.getState().cfg.GDPR_CMP_TIMEOUT,
                    });
                } catch (e) {
                  Object(Rt.b)(e, "_validateAndStoreConfig", {
                    makeVisibleToAllUsers: !0,
                  });
                }
              }
              function u(t, e, n) {
                try {
                  var r = t.slotID,
                    o = !1;
                  Object(Et.j)(t.bidConfig, "amznbid") &&
                    "o_" === t.bidConfig.amznbid.slice(0, 2) &&
                    (o = !0),
                    (Object(Et.j)(t.bidConfig, "mediaType") &&
                      "v" === t.bidConfig.mediaType &&
                      !1 === o) ||
                      (!window.IntersectionObserver && o
                        ? Object(Rt.b)(
                            {
                              name: "IntersectionObserver",
                              message: "IntersectionObserver not supported ",
                            },
                            "_safeApplySlotTargeting"
                          )
                        : e.hasAdServerObjectLoaded()
                        ? e.isCommandQueueDefined()
                          ? e.hasAdServerObjectLoaded()
                            ? null !== l(r, e)
                              ? y(t, e, n)
                              : Object(Rt.a)(
                                  "".concat(
                                    r,
                                    " isn't defined when trying to set amazon bid!"
                                  )
                                )
                            : e.cmdQueuePush(function () {
                                u(t, e, n);
                              })
                          : Object(Rt.a)(
                              "displayAdServer Object's cmd queue hasn't been defined",
                              !0
                            )
                        : Object(Rt.a)(
                            "displayAdServer Object hasn't been defined",
                            !0
                          ));
                } catch (t) {
                  Object(Rt.b)(t, "_safeApplySlotTargeting", {
                    makeVisibleToAllUsers: !0,
                  });
                }
              }
              function l(t, e) {
                var n = null;
                try {
                  n =
                    Object(It.b)(e).filter(function (e) {
                      return e.slotID === t;
                    })[0] || null;
                } catch (e) {
                  Object(Rt.b)(e, "_getAdServerSlot");
                }
                return n;
              }
              function f(t, e, n) {
                try {
                  var r,
                    o = _t.a.getState().targetingKeys[t.slotID];
                  e.hasAdServerObjectLoaded() &&
                    Object(Et.h)(o) &&
                    (t instanceof qt.a
                      ? 0 <
                          (r = o.filter(function (e) {
                            return 0 < t.getTargeting(e).length;
                          })).length &&
                        Object(Ht.a)(n).safelyRecord(
                          "googletag/slot/clearTargeting",
                          { slot: t.rawSlot, keys: r }
                        )
                      : o.forEach(function (e) {
                          0 < t.getTargeting(e).length && t.clearTargeting(e);
                        }));
                } catch (e) {
                  Object(Rt.b)(e, "_clearTargetingFromSlot", {
                    makeVisibleToAllUsers: !0,
                  });
                }
              }
              function d(t) {
                try {
                  var e;
                  Object(Et.j)(_t.a.getState().slotBids, t.slotID) &&
                    (e = _t.a
                      .getState()
                      .slotBids[t.slotID].filter(function (t) {
                        return t.bidState === At.c.set;
                      })[0]) &&
                    e.bidState === At.c.set &&
                    _t.a.dispatch({
                      type: "BID_STATE_CHANGE",
                      slotID: t.slotID,
                      _targetingSetID: e._targetingSetID,
                      bidState: At.c.exposed,
                    });
                } catch (t) {
                  Object(Rt.b)(t, "_clearBidSetOnSlot", {
                    makeVisibleToAllUsers: !0,
                  });
                }
              }
              function V(t, e) {
                try {
                  return (
                    t
                      .map(function (t) {
                        return Object(Et.g)(e, t);
                      })
                      .filter(function (t) {
                        return t;
                      }).length === t.length
                  );
                } catch (t) {
                  Object(Rt.b)(t, "_hasAllItemsInArray");
                }
              }
              function p(t) {
                var e = {};
                try {
                  Object.keys(_t.a.getState().slotBids).forEach(function (n) {
                    var r = _t.a.getState().slotBids[n].filter(function (e) {
                      return Object(Ut.e)(e, t);
                    });
                    0 < r.length &&
                      (e[n] = r
                        .map(function (t) {
                          var e = _t.a.getState().AAXReqs.filter(function (e) {
                              return e.bidReqID === t.bidReqID;
                            }),
                            n = 0;
                          return (
                            0 < e.length
                              ? (n = e[0].rqTs)
                              : ((e = _t.a
                                  .getState()
                                  .AAXReqs.map(function (t) {
                                    return t.bidReqID;
                                  })
                                  .join(", ")),
                                Object(Rt.b)(
                                  {
                                    name: "BidError",
                                    message: "Request not found: "
                                      .concat(t.bidReqID, " not found in ")
                                      .concat(e),
                                  },
                                  "_getCurrentSlotBids-noRequest"
                                )),
                            { rqTs: n, bid: t }
                          );
                        })
                        .reduce(function (t, e) {
                          return t.rqTs > e.rqTs ? t : e;
                        }).bid);
                  });
                } catch (t) {
                  Object(Rt.b)(t, "_getCurrentSlotBids", {
                    makeVisibleToAllUsers: !0,
                  });
                }
                return e;
              }
              function F(t, e) {
                try {
                  return Object(Et.h)(_t.a.getState().targetingKeys[t])
                    ? e
                      ? ["amzniid_sp"]
                      : _t.a.getState().targetingKeys[t].filter(function (t) {
                          return (
                            -1 < t.indexOf("amzniid") &&
                            t.indexOf("amzniid_sp") < 0
                          );
                        })
                    : ["amzniid"];
                } catch (t) {
                  return Object(Rt.b)(t, "_getAllBidIdKeys"), [];
                }
              }
              function q(t, e) {
                var n, r;
                try {
                  var o = _t.a.getState().slotBids;
                  Object.keys(o).forEach(function (i) {
                    o[i].forEach(function (o) {
                      F(i, e).forEach(function (e) {
                        o.bidConfig[e] === t &&
                          ((n = o),
                          "amzniid_sp" === e
                            ? (r = "sp")
                            : "amzniid" !== e &&
                              (r = e.substr(0, e.indexOf("amzniid"))));
                      });
                    });
                  });
                } catch (t) {
                  Object(Rt.b)(t, "_findSlotBidByBidID", {
                    makeVisibleToAllUsers: !0,
                  });
                }
                return { slotBid: n, dealId: r };
              }
              function H(t, e, n) {
                var r = "";
                try {
                  e.bidConfig[n + "amzniid"] === t &&
                    (r = n.split("_").pop().trim());
                } catch (t) {
                  Object(Rt.b)(t, "_getPMPBidSize");
                }
                return r;
              }
              function G(t) {
                try {
                  var e;
                  return void 0 === t.slots
                    ? []
                    : ((e = {}),
                      t.slots.forEach(function (t) {
                        (t.mediaType !== Nt.a.VIDEO &&
                          "v" !== t.mediaType &&
                          "v" !== t.mediaType_sp) ||
                        (0 <= t.slotID.indexOf("rsv-") &&
                          (t = {
                            slotID: t.slotID.substring(4),
                            r_amznbid: t.amznbid,
                            r_amzniid: t.amzniid,
                            r_amznp: t.amznp,
                            mediaType: Nt.a.VIDEO,
                            targeting: ["r_amznbid", "r_amzniid", "r_amznp"],
                            amznsz: t.amznsz,
                            size: t.size,
                            crid: t.crid,
                            meta: t.meta,
                          }),
                        !Object(Et.j)(e, t.slotID))
                          ? (e[t.slotID] = new Ut.a(t))
                          : t.targeting.forEach(function (n) {
                              (e[t.slotID].bidConfig[n] = t[n]),
                                -1 ===
                                  e[t.slotID].bidConfig.targeting.indexOf(n) &&
                                  e[t.slotID].bidConfig.targeting.push(n);
                            });
                      }),
                      Object.keys(e).map(function (t) {
                        return e[t];
                      }));
                } catch (t) {
                  return Object(Rt.b)(t, "_mergeVideoBids"), [];
                }
              }
              function Q(t) {
                var e = G(t),
                  n = [];
                try {
                  n = e.map(function (e) {
                    return (
                      (e.bidReqID = t.cb),
                      (e.host = t.host),
                      (e.ev = t.ev),
                      (e.cfe = t.cfe),
                      e
                    );
                  });
                } catch (e) {
                  Object(Rt.b)(e, "_convertAaxResponse");
                }
                return n;
              }
              function y(t, e, n) {
                try {
                  var r,
                    o,
                    i = t.slotID,
                    a = t._targetingSetID;
                  t.bidState !== At.c.set &&
                    null !== (r = l(i, e)) &&
                    (d(r),
                    (o = t.newBidObject),
                    Object(Mt.a)(n),
                    r instanceof qt.a
                      ? Object(Ht.a)(n).safelyRecord(
                          "googletag/slot/setConfig",
                          { slot: r.rawSlot, targeting: o.targeting }
                        )
                      : Object.keys(o.targeting).forEach(function (t) {
                          return r.setTargeting(t, o.targeting[t]);
                        }),
                    _t.a.dispatch({
                      type: "BID_STATE_CHANGE",
                      slotID: i,
                      _targetingSetID: a,
                      bidState: At.c.set,
                      ts: Date.now(),
                    }));
                } catch (t) {
                  Object(Rt.b)(t, "_applyTargetingToAdServerSlot", {
                    makeVisibleToAllUsers: !0,
                  });
                }
              }
              function X(t, e, n, r) {
                try {
                  var o = p(r);
                  t.forEach(function (t) {
                    o[t] && u(o[t], e, n);
                  });
                } catch (t) {
                  Object(Rt.b)(t, "_applySuppliedSlotBidsToAdServerObject", {
                    makeVisibleToAllUsers: !0,
                  });
                }
              }
              function W(t, e, n) {
                try {
                  var r = p(n);
                  Object.keys(r).forEach(function (n) {
                    return u(r[n], t, e);
                  });
                } catch (n) {
                  Object(Rt.b)(
                    n,
                    "_applyAllCurrentSlotBidsTargetingToAdServerObject",
                    { makeVisibleToAllUsers: !0 }
                  );
                }
              }
              function Y(t, e, n, r) {
                try {
                  n ? X(n, t, e, r) : W(t, e, r),
                    _t.a.getState().displayAdServer.slotRenderEndedSet ||
                      (t.cmdQueuePush(function () {
                        try {
                          t.slotRenderEndedEvent(function (n) {
                            try {
                              f(n, t, e), d(n);
                            } catch (n) {
                              Object(Rt.b)(
                                n,
                                "_applySlotTargeting-cmdQueue-slotCb",
                                { makeVisibleToAllUsers: !0 }
                              );
                            }
                          });
                        } catch (t) {
                          Object(Rt.b)(t, "_applySlotTargeting-cmdQueue", {
                            makeVisibleToAllUsers: !0,
                          });
                        }
                      }),
                      _t.a.dispatch({ type: "SLOT_RENDER_ENDED_SET" }));
                } catch (n) {
                  Object(Rt.b)(n, "_applySlotTargeting", {
                    makeVisibleToAllUsers: !0,
                  });
                }
              }
              function g(t, e) {
                function n() {
                  if (!o)
                    if (20 <= i++)
                      Object(Rt.b)(
                        {
                          name: "LoopError",
                          message:
                            "Too many attempts to append to document.body",
                        },
                        "_safeDocumentBodyAppendChild-callback-loops",
                        { makeVisibleToAllUsers: !0 }
                      );
                    else {
                      try {
                        if (
                          t &&
                          t.body &&
                          null !== t.body &&
                          "function" == typeof t.body.appendChild
                        )
                          return t.body.appendChild(e), r(), void (o = !0);
                      } catch (t) {
                        Object(Rt.b)(
                          t,
                          "_safeDocumentBodyAppendChild-callback"
                        );
                      }
                      setTimeout(n, 100);
                    }
                }
                var r =
                    2 < arguments.length && void 0 !== arguments[2]
                      ? arguments[2]
                      : function () {},
                  o = !1,
                  i = 0;
                try {
                  "complete" === t.readyState || "interactive" === t.readyState
                    ? n()
                    : t.addEventListener("DOMContentLoaded", n);
                } catch (t) {
                  Object(Rt.b)(t, "_safeDocumentBodyAppendChild");
                }
              }
              function $(t) {
                try {
                  var e = ""
                      .concat(t.host)
                      .concat(_t.a.getState().cfg.DTB_PATH, "/imp"),
                    n = ""
                      .concat(t.host)
                      .concat(_t.a.getState().cfg.DTB_PATH, "/adm");
                  return t.cfe || t.isAmp || t.isSf ? n : e;
                } catch (t) {
                  return Object(Rt.b)(t, "determineCreativeFetchEndpoint"), "";
                }
              }
              function w(t) {
                try {
                  var e = "?b=".concat(t.bidID, "&rnd=").concat(Object(Et.c)()),
                    n =
                      (Object(Et.j)(t, "pp") && (e += "&pp=".concat(t.pp)),
                      Object(Et.j)(t, "amznp") && (e += "&p=".concat(t.amznp)),
                      Object(Et.j)(t, "crID") && (e += "&crid=".concat(t.crID)),
                      Object(Et.j)(t, "isSharedPMP") &&
                        !0 === t.isSharedPMP &&
                        (e += "&sp=true"),
                      Object(Mt.e)() && (e += "&ep=%7B%22ce%22%3A%221%22%7D"),
                      $(t));
                  return (t.fif ? "".concat(n, "j") : "".concat(n, "i")).concat(
                    e
                  );
                } catch (t) {
                  return Object(Rt.b)(t, "_creativeURL"), "";
                }
              }
              function m(t) {
                try {
                  var e = t.doc.createElement("iframe");
                  return (
                    (e.frameBorder = "0"),
                    (e.marginHeight = "0"),
                    (e.marginWidth = "0"),
                    (e.style.marginTop = "0"),
                    (e.style.marginLeft = "0"),
                    (e.scrolling = "no"),
                    t.inheritSize
                      ? ((e.style.width = "100%"), (e.style.height = "100%"))
                      : ((e.style.width = "".concat(t.sizes[0], "px")),
                        (e.style.height = "".concat(t.sizes[1], "px"))),
                    e
                  );
                } catch (t) {
                  return (
                    Object(Rt.b)(t, "_baseIframe"),
                    window.document.createElement("iframe")
                  );
                }
              }
              function K(t) {
                try {
                  if (Object(Et.j)(t, "bidType")) {
                    var e,
                      n = t.kvMap;
                    switch (t.bidType) {
                      case "sharedPMP":
                        return {
                          bidID: n.amzniid_sp[0],
                          pp: n.amznbid_sp[0],
                          sizes: n.amznsz_sp[0].split("x"),
                          amznp: n.amznp_sp[0],
                          inheritSize: t.inheritSize,
                          isSharedPMP: t.isSharedPMP,
                        };
                      case "preferredPMP":
                        if (Object(Nt.c)(t) && Object(Et.j)(t, "amzndeal"))
                          return (
                            (e = t.amzndeal.split("_").pop().trim()),
                            {
                              bidID: n["".concat(t.amzndeal, "amzniid")][0],
                              sizes: C(e),
                            }
                          );
                        break;
                      case "openAuction":
                        if (Object(Nt.c)(t))
                          return {
                            bidID: n.amzniid[0],
                            pp: Object(Dt.b)(n.amznbid[0]),
                            amznp: n.amznp[0],
                            inheritSize: t.inheritSize,
                            sizes: n.amznsz[0].split("x"),
                          };
                        if (Object(Nt.d)(t))
                          return {
                            bidID: t.amzniid,
                            pp: Object(Dt.b)(t.amznbid),
                            amznp: t.amznp,
                            sizes: t.amznsz.split("x"),
                          };
                        break;
                      default:
                        Object(Rt.b)(
                          {
                            name: "Invalid AMP Bid Type: ".concat(t.bidType),
                            message: "No valid AMP bid type",
                          },
                          "getAmpAdData-invalidBidType"
                        );
                    }
                  }
                } catch (t) {
                  Object(Rt.b)(t, "getAmpAdData");
                }
                return { bidID: "ERROR", sizes: [] };
              }
              function T(t, e, n) {
                try {
                  var r,
                    o = null;
                  void 0 !== e &&
                    ((Object(Et.j)(e, "ampEnv") && e.ampEnv) ||
                      (Object(Et.j)(e, "sfEnv") && e.sfEnv)) &&
                    ((o = e),
                    Object(Et.j)(e, "bidType") && "sharedPMP" === e.bidType
                      ? (o.isSharedPMP = !0)
                      : (o.isSharedPMP = !1),
                    (o.document = t),
                    (o.amznhost = o.kvMap.amznhost[0])),
                    A(t) &&
                      (((o = t).bidType = "openAuction"), (o.ampEnv = !0)),
                    null === o
                      ? Object(Rt.b)(
                          new Error("Invalid AMP parameters"),
                          "_renderAmpImpression-invalidParams",
                          { makeVisibleToAllUsers: !0 }
                        )
                      : "ERROR" !== (r = K(o)).bidID &&
                        ((r.doc = o.document),
                        (r.host = o.amznhost.replace("http://", "https://")),
                        (r.adID = "amznad".concat(Object(Et.c)())),
                        (r.isAmp = o.ampEnv),
                        (r.isSf = Object(Ct.c)(window)),
                        _t.a.getState().aaxViewabilityEnabled
                          ? R(r, r.doc, n)
                          : D(r));
                } catch (t) {
                  Object(Rt.b)(t, "_renderAmpImpression");
                }
              }
              function _(t) {
                var e,
                  n = "unknown";
                function r(r) {
                  try {
                    r && (t.hasTimedOut = !0),
                      r &&
                        !t.hasRendered &&
                        Object(Rt.b)(
                          {
                            name: "RenderTimeout",
                            message:
                              "renderAd was called from timeout. fifFlowMethod: ".concat(
                                n
                              ),
                          },
                          "__loadAdIntoFriendlyIframe-renderAd-timeout-isOutstream:".concat(
                            t.isOutstream
                          )
                        ),
                      null === e.contentDocument
                        ? Object(Rt.b)(
                            {
                              name: "NoDocument",
                              message:
                                "iframe.contentDocument was null inside renderAd. isFromTimeout: "
                                  .concat(r, ". fifFlowMethod: ")
                                  .concat(n),
                            },
                            "__loadAdIntoFriendlyIframe-renderAd-noDocument-isOutstream:".concat(
                              t.isOutstream
                            ),
                            { makeVisibleToAllUsers: !0 }
                          )
                        : t.hasRendered && !t.hasTimedOut
                        ? Object(Rt.b)(
                            {
                              name: "DupeRender",
                              message: "Render was called twice",
                            },
                            "__loadAdIntoFriendlyIframe-renderAd-rerender-isOutstream:".concat(
                              t.isOutstream
                            ),
                            { makeVisibleToAllUsers: !0 }
                          )
                        : t.hasRendered ||
                          ((t.hasRendered = !0),
                          e.contentDocument.open(),
                          e.contentDocument.write(t.html),
                          e.contentDocument.close());
                  } catch (r) {
                    Object(Rt.b)(
                      r,
                      "__loadAdIntoFriendlyIframe-renderAd-isOutstream:".concat(
                        t.isOutstream
                      )
                    );
                  }
                }
                function o() {
                  var o = r.bind(null, !1);
                  try {
                    (n =
                      null !== e.contentDocument &&
                      Object(Et.g)(
                        ["complete", "interactive"],
                        e.contentDocument.readyState
                      )
                        ? (o(), "doc-ready")
                        : null !== e.contentDocument &&
                          "uninitialized" !== e.contentDocument.readyState
                        ? (e.contentDocument.addEventListener(
                            "DOMContentLoaded",
                            o
                          ),
                          "dom-listener")
                        : (e.addEventListener("load", o), "iframe-listener")),
                      setTimeout(r, 1e3, !0);
                  } catch (o) {
                    Object(Rt.b)(
                      o,
                      "_loadAdIntoFriendlyIframe-setAttributes-isOutstream:".concat(
                        t.isOutstream
                      )
                    );
                  }
                }
                try {
                  if (void 0 === t.html)
                    throw new Error(
                      "No HTML available for ad, most likely the creative has expired"
                    );
                  if (
                    ((t = Yt({ hasRendered: !1, hasTimedOut: !1 }, t)),
                    ((e = m(t)).id = "apstag-f-iframe-".concat(Object(Et.c)())),
                    t.isOutstream)
                  )
                    try {
                      var i = Object(kt.d)(document, t);
                      if (void 0 === i)
                        throw new Error("gpt video div element is undefined");
                      i &&
                        i.firstElementChild &&
                        i.firstElementChild.style.setProperty(
                          "display",
                          "none",
                          "important"
                        );
                      var a = Object(kt.f)(t.sizes);
                      Object(kt.a)(a, i),
                        Object(kt.e)(a, e),
                        o(),
                        Object(kt.g)(a, e, t.bidID);
                    } catch (o) {
                      Object(Rt.b)(o, "_loadAdIntoFriendlyIframe-outstream", {
                        makeVisibleToAllUsers: !0,
                      });
                    }
                  else g(t.doc, e, o);
                } catch (o) {
                  Object(Rt.b)(o, "_loadAdIntoFriendlyIframe", {
                    makeVisibleToAllUsers: !0,
                  });
                }
              }
              function D(t) {
                var e =
                    1 < arguments.length && void 0 !== arguments[1]
                      ? arguments[1]
                      : {
                          states: {
                            csmLoaded: !1,
                            iframeLoaded: !1,
                            shouldRunViewability: !1,
                          },
                        },
                  n = 2 < arguments.length ? arguments[2] : void 0;
                try {
                  var r,
                    o = m(t);
                  (o.id = t.adID),
                    o.setAttribute(
                      "sandbox",
                      "allow-forms allow-pointer-lock allow-popups allow-popups-to-escape-sandbox allow-same-origin allow-scripts allow-top-navigation-by-user-activation"
                    ),
                    Object(Pt.d)("fake_bids")
                      ? ((r = '<body style="background-color: #FF9900;">'
                          .concat(
                            50 < parseInt(t.sizes[1], 10)
                              ? "<h3>apstag Test Creative</h3>"
                              : "",
                            "<h4>amzniid - "
                          )
                          .concat(t.bidID, " | amznbid: ")
                          .concat(t.pp, " | size: ")
                          .concat(t.sizes.join("x"), "</h4></body>")),
                        (o.src = "javascript:'".concat(r, "'")))
                      : (o.src = w(t)),
                    (!(t.isAmp && t.isSf && Object(Ct.b)(window)) &&
                      (!t.isSf || t.isAmp || t.inheritSize)) ||
                      Object(Ct.a)(t.sizes, window),
                    g(t.doc, o),
                    ((e.iframe = o).onload = function () {
                      (e.states.iframeLoaded = !0), n && n();
                    });
                } catch (t) {
                  Object(Rt.b)(t, "_loadAdIntoUnfriendlyIframe", {
                    makeVisibleToAllUsers: !0,
                  });
                }
              }
              function J(t, e) {
                var n,
                  r = t.states,
                  o = t.doc,
                  i = t.bidID;
                t = t.iframe;
                try {
                  Object(Et.a)(r) ||
                    ((r.shouldRunViewability = !1),
                    Object(Et.j)(window, "amzncsm")
                      ? (n = window.amzncsm)
                      : void 0 !== o &&
                        null !== o.defaultView &&
                        Object(Et.j)(o.defaultView, "amzncsm") &&
                        (n = o.defaultView.amzncsm),
                    void 0 !== o &&
                      void 0 !== n &&
                      Object(Et.j)(n, "rmD") &&
                      ((n.host = Object(Pt.c)(
                        "host",
                        _t.a.getState().hosts.DEFAULT_AAX_PIXEL_HOST
                      )),
                      n.rmD(
                        t,
                        i,
                        o.defaultView,
                        o,
                        te({ overrides: null == e ? void 0 : e.initConfig })
                          .pubID
                      )));
                } catch (t) {
                  Object(Rt.b)(t, "_triggerViewability");
                }
              }
              function Z(t, e, n, r) {
                return function (o) {
                  try {
                    var i = Object(Ut.d)(e.slots, r),
                      a = Object.keys(i),
                      c = [],
                      s =
                        (o &&
                          (_t.a.dispatch({
                            type: "RECORD_AAX_REQ_PROP",
                            bidReqID: e.bidReqID,
                            key: "timedOutAt",
                            value: Date.now(),
                          }),
                          _t.a.getState().experiments.chunkRequests) &&
                          _t.a.dispatch({
                            type: "RECORD_TIMEOUT",
                            fid: e.bidReqID,
                            timeOut: Date.now(),
                          }),
                        a.forEach(function (t) {
                          Object(Et.j)(i, t) &&
                            ((t = i[t]),
                            Object(Ut.f)(
                              te({
                                overrides: null == r ? void 0 : r.initConfig,
                              }),
                              n
                            ) || Object(Et.j)(t.bidConfig, "amznbid")
                              ? Object(Et.j)(t.bidConfig, "amznp") ||
                                (t.bidConfig.amznp = "")
                              : (t.mediaType !== Nt.a.VIDEO &&
                                  (t.bidConfig.targeting.unshift("amznsz"),
                                  (t.bidConfig.amznsz = "0x0")),
                                t.bidConfig.targeting.unshift(
                                  "amzniid",
                                  "amznbid",
                                  "amznp"
                                ),
                                (t.bidConfig.amzniid = ""),
                                (t.bidConfig.amznbid = At.t.noBid),
                                (t.bidConfig.amznp = At.t.noBid)),
                            c.push(t));
                        }),
                        n.isSupported && (c = Object(Ut.b)(c, e, o)),
                        { fromTimeout: o }),
                      u = Object(Ut.f)(
                        te({ overrides: null == r ? void 0 : r.initConfig }),
                        n
                      );
                    try {
                      t(
                        c.map(function (t) {
                          return u ? t.newBidObject : t.bidObject;
                        }),
                        s
                      );
                    } catch (a) {
                      console.error(a);
                    }
                  } catch (a) {
                    Object(Rt.b)(a, "_bidCallbackHandler", {
                      makeVisibleToAllUsers: !0,
                    });
                    try {
                      t([], { fromTimeout: o, fromError: !0 });
                    } catch (a) {
                      console.error(a);
                    }
                  }
                };
              }
              function tt(t, e) {
                try {
                  var n, r;
                  e.inheritSize ||
                    ((r =
                      t.defaultView && t.defaultView.frameElement
                        ? ((n = t.defaultView.frameElement), "defaultView")
                        : ((n = window.frameElement), "frameElement")),
                    null !== n
                      ? ((n.style.width = "".concat(e.sizes[0], "px")),
                        (n.style.height = "".concat(e.sizes[1], "px")))
                      : Object(Rt.b)(
                          {
                            name: "FrameNotFound",
                            message: "'win' is 'null'. Method used: ".concat(r),
                          },
                          "_resizeIframe-win"
                        ));
                } catch (t) {
                  Object(Rt.b)(t, "_resizeIframe");
                }
              }
              function h(t) {
                try {
                  return "".concat(t[0], "x").concat(t[1]);
                } catch (t) {
                  return Object(Rt.b)(t, "_sizeArrayToSring"), "x";
                }
              }
              function O(t) {
                try {
                  return 1 === t.length
                    ? h(t[0])
                    : h(t[Math.floor(t.length * Math.random())]);
                } catch (t) {
                  return (
                    Object(Rt.b)(t, "_pickRandomSizeForMockBid", {
                      makeVisibleToAllUsers: !0,
                    }),
                    ""
                  );
                }
              }
              function et(t) {
                try {
                  var e,
                    n = Object(Pt.c)(
                      "host",
                      _t.a.getState().hosts.DEFAULT_AAX_BID_HOST
                    ),
                    r = Object(Dt.f)(window),
                    o = t.bidReqID,
                    i = Object(Et.f)(window),
                    a = Object(Pt.c)("testBidTimeout", 200);
                  _t.a.dispatch({
                    type: "RECORD_AAX_REQUEST",
                    data: {
                      bidConfig: t,
                      timeout: a,
                      bidReqID: o,
                      ws: i,
                      url: r,
                      rqTs: Date.now(),
                    },
                  }),
                    (e = t.slots.map(function (t) {
                      var e = O(t.sizes),
                        n =
                          ((e = "testDeal"
                            .concat(Object(Et.c)(), "_")
                            .concat(e)),
                          "testDealIi-".concat(Object(Et.c)())),
                        r = O(t.sizes);
                      $t(
                        (r = {
                          slotID: t.slotID,
                          crid: ""
                            .concat(At.o.crid, "-")
                            .concat(Object(Et.c)()),
                          size: r,
                          amzniid: ""
                            .concat(At.o.amzniid, "-")
                            .concat(Object(Et.c)()),
                          amznbid: At.o.amznbid,
                          amznp: At.o.amznp,
                          amznsz: r,
                          amzniid_sp: ""
                            .concat(At.o.amzniid, "-")
                            .concat(Object(Et.c)()),
                          amznbid_sp: "".concat(At.o.amznbid, "SP"),
                          amznp_sp: "".concat(At.o.amznp, "SP"),
                          amznsz_sp: O(t.sizes),
                          amzndeals: [e],
                        }),
                        "".concat(e, "amzniid"),
                        n
                      ),
                        $t(r, "mediaType", "d"),
                        $t(r, "meta", ["slotID", "mediaType", "size"]),
                        $t(r, "targeting", [
                          "amzniid",
                          "amznbid",
                          "amznp",
                          "amznsz",
                          "amzniid_sp",
                          "amznbid_sp",
                          "amznp_sp",
                          "amznsz_sp",
                          "amzndeal_sp",
                          "amzndeals",
                          "".concat(e, "amzniid"),
                        ]),
                        (n = r);
                      return (
                        t.mediaType === Nt.a.VIDEO &&
                          ((n.mediaType = Nt.a.VIDEO),
                          (n.amznbid = "v_".concat(n.amznbid))),
                        n
                      );
                    })),
                    setTimeout(function () {
                      window.apstag.bids({
                        slots: e,
                        host: n,
                        status: "ok",
                        cb: o,
                      });
                    }, a);
                } catch (t) {
                  Object(Rt.b)(t, "_doMockBid", { makeVisibleToAllUsers: !0 });
                }
              }
              function nt(t, e, n) {
                try {
                  var r,
                    o,
                    i,
                    a = _t.a.getState().AAXReqs.filter(function (e) {
                      return e.bidReqID === t.cb;
                    })[0];
                  a &&
                    a.bidConfig &&
                    a.bidConfig.slots &&
                    ((r = a.bidConfig.slots
                      .filter(Object(It.d)(Nt.a.DISPLAY, Nt.a.MULTI_FORMAT))
                      .map(function (t) {
                        return t.slotID;
                      })),
                    (o = Object(Et.j)(t, "slots")
                      ? t.slots.map(function (t) {
                          return t.slotID;
                        })
                      : []),
                    (i = r.filter(function (t) {
                      return !Object(Et.g)(o, t);
                    })),
                    _t.a.dispatch({
                      type: "NO_BID_ON_ADSERVER_SLOTS",
                      slotIDs: i,
                    }),
                    e.hasAdServerObjectLoaded()
                      ? j(e, n)
                      : e.isCommandQueueDefined() &&
                        e.cmdQueuePush(function () {
                          j(e, n);
                        }));
                } catch (e) {
                  Object(Rt.b)(e, "_determineNoBidStateForAdServerObject");
                }
              }
              function rt(t) {
                return Object(Et.g)(
                  _t.a
                    .getState()
                    .AAXReqs.filter(function (t) {
                      return !t.resTs;
                    })
                    .map(function (t) {
                      return t.bidConfig.slots;
                    })
                    .reduce(function (t, e) {
                      return t.concat(e);
                    }, [])
                    .map(It.c),
                  t
                );
              }
              function v(t) {
                try {
                  var e = t.getTargeting("amznbid");
                  return 0 < e.length && 2 < e[0].length;
                } catch (t) {
                  return Object(Rt.b)(t, "_isRealAmznbidTargetingSetOnSlot"), 1;
                }
              }
              function j(t, e) {
                try {
                  t.hasAdServerObjectLoaded() &&
                    "1" === t.getTargeting("amznbid")[0] &&
                    E(t, e),
                    Object(It.b)(t).forEach(function (t) {
                      !Object(Et.g)(
                        _t.a.getState().displayAdServer.noBidSlotIDs,
                        t.slotID
                      ) ||
                        rt(t.slotID) ||
                        v(t) ||
                        "2" === t.getTargeting("amznbid")[0] ||
                        (S("noBid", t, e), Object(Mt.a)(e));
                    });
                } catch (t) {
                  Object(Rt.b)(t, "_applyNoBidFromAAXState");
                }
              }
              function S(t, e, n) {
                var r = {};
                At.u.forEach(function (e) {
                  r[e] = At.t[t];
                }),
                  e instanceof qt.a
                    ? Object(Ht.a)(n).safelyRecord("googletag/slot/setConfig", {
                        slot: e.rawSlot,
                        targeting: r,
                      })
                    : e instanceof Lt.a
                    ? Object(Ht.a)(n).safelyRecord(
                        "googletag/pubads/setConfig",
                        { targeting: r }
                      )
                    : At.u.forEach(function (n) {
                        return e.setTargeting(n, At.t[t]);
                      });
              }
              function E(t, e) {
                t instanceof Lt.a
                  ? Object(Ht.a)(e).safelyRecord(
                      "googletag/pubads/clearTargeting",
                      { keys: At.u }
                    )
                  : At.u.forEach(function (e) {
                      return t.clearTargeting(e);
                    });
              }
              !(function () {
                var t;
                Object(Gt.b)() &&
                  (t = Gt.a
                    .getDefault()
                    .localStorage.getItem(At.d, { ignoreFailure: !0 })) &&
                  null !== (t = JSON.parse(t)) &&
                  _t.a.dispatch({ type: "SET_CFG", cfg: t });
              })(),
                Object(Mt.d)();
              var ot = 0;
              function I() {
                try {
                  Object(Et.j)(window, "googletag") &&
                  Object(Et.j)(window.googletag, "cmd")
                    ? new Lt.a().cmdQueuePush(function () {
                        try {
                          window.googletag
                            .pubads()
                            .addEventListener("slotRequested", function (t) {
                              try {
                                var e = t.slot;
                                _t.a.dispatch({
                                  type: "LOG_GAM_EVENT",
                                  event: Yt(
                                    Yt({}, new qt.a(e).slotConfig),
                                    {},
                                    {
                                      ts: Date.now(),
                                      targeting: e.getTargetingMap(),
                                    }
                                  ),
                                });
                              } catch (t) {
                                Object(Rt.b)(
                                  t,
                                  "_initializeSlotRequestedEventListener-cmdQueue-listener"
                                );
                              }
                            });
                        } catch (t) {
                          Object(Rt.b)(
                            t,
                            "_initializeSlotRequestedEventListener-cmdQueue"
                          );
                        }
                      })
                    : ++ot < 5 && setTimeout(I, 100);
                } catch (t) {
                  Object(Rt.b)(t, "_initializeSlotRequestedEventListener");
                }
              }
              function it(t) {
                try {
                  var e = t.AAXReqs.slice(t.gamSlotRenderPixel.aaxReqOffset)
                      .reduce(function (t, e) {
                        return t.concat(e.bidConfig.slots);
                      }, [])
                      .map(function (t) {
                        return Yt(Yt({}, t), {}, { type: "a" });
                      })
                      .filter(function (t) {
                        return t.mediaType !== Nt.a.VIDEO;
                      }),
                    n = t.gamSlotFetchLog
                      .slice(t.gamSlotRenderPixel.gamSlotFetchLogOffset)
                      .map(function (t) {
                        return Yt(Yt({}, t), {}, { type: "g" });
                      }),
                    r = [].concat(Xt(e), Xt(n)).reduce(function (t, e) {
                      return (
                        void 0 === t[e.slotID] &&
                          (t[e.slotID] = {
                            sd: e.slotID,
                            a: { c: 0 },
                            g: { c: 0 },
                          }),
                        t[e.slotID][e.type].c++,
                        (t[e.slotID][e.type].s = e.sizes),
                        (t[e.slotID][e.type].sn = e.slotName || ""),
                        t
                      );
                    }, {});
                  return Object.keys(r)
                    .map(function (t) {
                      return r[t];
                    })
                    .filter(function (t) {
                      return 0 !== t.a.c || 0 !== t.g.c;
                    });
                } catch (t) {
                  return Object(Rt.b)(t, "getSlotFetchCounts"), [];
                }
              }
              function at(t) {
                try {
                  var e = ut(t),
                    n = [];
                  return (
                    null !== e &&
                      Object.keys(_t.a.getState().slotBids).forEach(function (
                        t
                      ) {
                        _t.a.getState().slotBids[t][0].bidConfig.mediaType !==
                          Nt.a.VIDEO &&
                          _t.a
                            .getState()
                            .slotBids[t].filter(function (t) {
                              return Object(Et.j)(t.bidConfig, "amzniid");
                            })
                            .forEach(function (r) {
                              var o, i, a;
                              null !== e &&
                                ((o = {
                                  state: -1,
                                  slotID: t,
                                  iid: r.bidConfig.amzniid,
                                  fid: r.bidReqID,
                                }),
                                (a = []),
                                (i = []),
                                t in e &&
                                  ((a = e[t].fetchedAt.filter(function (t) {
                                    return (
                                      t.AAXReqInfo &&
                                      t.AAXReqInfo.bidReqID === r.bidReqID
                                    );
                                  })),
                                  (i = e[t].targetedAt.filter(function (t) {
                                    return t.targeting === r.bidConfig.amzniid;
                                  }))),
                                0 < a.length
                                  ? 0 < a.length &&
                                    i.length >= a.length &&
                                    a.slice(a.length - 1)[0].ts >
                                      i.slice(a.length - 1)[0].ts
                                    ? 1 ===
                                      e[t].fetchWithIID.filter(function (t) {
                                        return t === r.bidConfig.amzniid;
                                      }).length
                                      ? (o.state = 1)
                                      : (o.state = 4)
                                    : Object(Et.g)(
                                        e[t].fetchWithIID,
                                        r.bidConfig.amzniid
                                      )
                                    ? (o.state = 3)
                                    : (o.state = 2)
                                  : (o.state = 0),
                                (1 !== o.state && 2 !== o.state) ||
                                  ((a = P(
                                    (i = _t.a
                                      .getState()
                                      .AAXReqs.filter(function (t) {
                                        return t.bidReqID === r.bidReqID;
                                      })[0].resTs),
                                    e[t].fetchedAt,
                                    2 === o.state
                                  )) &&
                                    Object(Et.j)(a, "ts") &&
                                    (o.delta = i - a.ts)),
                                n.push(o));
                            });
                      }),
                    n
                  );
                } catch (t) {
                  return Object(Rt.b)(t, "_getBidSetInfo"), [];
                }
              }
              function P(t, e, n) {
                var r = e.map(function (e) {
                  return (
                    (e = t - e.ts), !n && e <= 0 ? -e : n && 0 <= e ? e : null
                  );
                });
                return e[ct(r)];
              }
              function ct(t) {
                for (var e = -1, n = -1, r = 0; r < t.length; r++)
                  null !== t[r] && (-1 === n || t[r] < e) && (e = t[(n = r)]);
                return n;
              }
              function st(t, e) {
                return _t.a.getState().AAXReqs.filter(function (t) {
                  return Object(Et.g)(
                    t.bidConfig.slots.map(function (t) {
                      return t.slotID;
                    }),
                    e
                  );
                })[t];
              }
              function ut(t) {
                try {
                  var e;
                  return t.hasAdServerObjectLoaded()
                    ? ((e = _t.a
                        .getState()
                        .gamSlotFetchLog.reduce(function (t, e) {
                          Object(Et.j)(t, e.slotID) ||
                            (t[e.slotID] = { fetchedAt: [], targetedAt: [] });
                          var n = t[e.slotID];
                          return (
                            n.fetchedAt.push({
                              ts: e.ts,
                              AAXReqInfo: st(n.fetchedAt.length, e.slotID),
                            }),
                            Object(Et.j)(e.targeting, "amzniid") &&
                            0 < e.targeting.amzniid.length
                              ? n.targetedAt.push({
                                  ts: e.ts - 1,
                                  targeting: e.targeting.amzniid[0],
                                })
                              : n.targetedAt.push({
                                  ts: e.ts - 1,
                                  targeting: "",
                                }),
                            t
                          );
                        }, {})),
                      Object.keys(e).forEach(function (t) {
                        var n;
                        Object(Et.j)(e, t) &&
                          (((n = e[t]).fetchWithIID = n.fetchedAt.map(function (
                            t
                          ) {
                            return (t = P(t.ts, n.targetedAt, !0))
                              ? t.targeting
                              : 0;
                          })),
                          (e[t] = n));
                      }),
                      e)
                    : null;
                } catch (t) {
                  return Object(Rt.b)(t, "_getDFPSlotFetches"), null;
                }
              }
              function lt(t, e) {
                try {
                  t.hasAdServerObjectLoaded()
                    ? S("noRequest", t, e)
                    : t.isCommandQueueDefined() &&
                      t.cmdQueuePush(function () {
                        S("noRequest", t, e);
                      });
                } catch (t) {
                  Object(Rt.b)(t, "_applyNoRequestToAAXState");
                }
              }
              function ft(t, e, n) {
                try {
                  _t.a.dispatch({
                    type: "REQUESTED_BID_FOR_ADSERVER_SLOTS",
                    slotIDs: t,
                  }),
                    e.isCommandQueueDefined() &&
                      e.cmdQueuePush(function () {
                        try {
                          var r = Object(It.b)(e);
                          "0" === e.getTargeting("amznbid")[0] && E(e, n),
                            V(
                              t.filter(function (t) {
                                return void 0 !== t;
                              }),
                              r.map(function (t) {
                                return t.slotID;
                              })
                            )
                              ? r.forEach(function (e) {
                                  Object(Et.g)(t, e.slotID) &&
                                    !v(e) &&
                                    S("bidInFlight", e, n);
                                })
                              : e.cmdQueuePush(function () {
                                  try {
                                    S("bidInFlight", e, n);
                                  } catch (t) {
                                    Object(Rt.b)(
                                      t,
                                      "_setRequestToAAXInFlightState-cmdQueue-cmdQueue"
                                    );
                                  }
                                });
                        } catch (r) {
                          Object(Rt.b)(
                            r,
                            "_setRequestToAAXInFlightState-cmdQueue"
                          );
                        }
                      });
                } catch (t) {
                  Object(Rt.b)(t, "_setRequestToAAXInFlightState");
                }
              }
              function A(t) {
                try {
                  return (
                    Object(Et.j)(t, "type") &&
                    !(t instanceof Document) &&
                    "amp" === t.type
                  );
                } catch (t) {
                  return Object(Rt.b)(t, "_isLegacyAmpCreative"), !1;
                }
              }
              function dt(t, e) {
                try {
                  return (
                    (void 0 !== e && Object(Et.j)(e, "ampEnv") && e.ampEnv) ||
                    A(t)
                  );
                } catch (t) {
                  Object(Rt.b)(t, "_isAmpImpression");
                }
              }
              function C(t) {
                return t.split("x");
              }
              function bt(t, e, n, r) {
                var o = Zt(
                  Jt(),
                  "renderImp",
                  { doc: t, bidID: e, kvBidObject: n },
                  "renderImpArgs"
                );
                (t = o.doc), (e = o.bidID), (n = o.kvBidObject);
                try {
                  if (dt(t, n) && Object(Dt.i)(window, !0)) T(t, n, r);
                  else if (
                    Object(Ct.c)(window) &&
                    void 0 !== n &&
                    Object(Et.j)(n, "kvMap") &&
                    Object(Et.j)(n.kvMap, "amznhost")
                  )
                    T(t, n, r);
                  else {
                    var i = !1,
                      a =
                        ("string" == typeof e &&
                          0 === e.indexOf("sp|") &&
                          ((e = e.substring(3)), (i = !0)),
                        e || t.amzniid),
                      c = q(a, i),
                      s = c.slotBid,
                      u = c.dealId,
                      l = !1;
                    if (
                      (void 0 !== n &&
                        Object(Et.j)(n, "bidType") &&
                        "outstream" === n.bidType &&
                        (l = !0),
                      s)
                    ) {
                      var f,
                        d,
                        b,
                        p,
                        y,
                        g,
                        m,
                        h,
                        O,
                        v,
                        j,
                        S =
                          u && 1 <= u.length
                            ? C("sp" === u ? s.bidConfig.amznsz_sp : H(a, s, u))
                            : C(s.bidConfig.amznsz);
                      1 === arguments.length
                        ? _({
                            doc: s.doc,
                            bidID: s.bidConfig.amzniid,
                            sizes: S,
                            html: t.html,
                            inheritSize: s.inheritSize || !1,
                            isOutstream: l,
                          })
                        : ((f = s.host),
                          (d = s.bidConfig.slotID),
                          (b = "amznad".concat(
                            Math.round(1e6 * Math.random())
                          )),
                          (p = {
                            bidID: a,
                            doc: t,
                            slotID: d,
                            pp: k("amznbid", s, u),
                            host: f,
                            adID: b,
                            sizes: S,
                            amznp: k("amznp", s, u),
                            crID: k("crid", s, u),
                            fif: !1,
                            dealId: u,
                            isSharedPMP: i,
                            cfe: s.cfe,
                            isOutstream: l,
                            inheritSize:
                              Object(Et.i)(n) &&
                              Object(Et.j)(n, "inheritSize") &&
                              !0 === n.inheritSize,
                          }),
                          "1" === s.bidConfig.fif && !1 === l && !1 === i
                            ? ((p.fif = !0),
                              _t.a.dispatch({
                                type: "UPDATE_BID_INFO_PROP",
                                slotID: s.slotID,
                                iid: e,
                                key: "doc",
                                value: t,
                              }),
                              _t.a.dispatch({
                                type: "UPDATE_BID_INFO_PROP",
                                slotID: s.slotID,
                                iid: e,
                                key: "inheritSize",
                                value: p.inheritSize,
                              }),
                              Object(zt.b)(
                                w(p),
                                function () {},
                                document,
                                function () {
                                  return Object(Rt.b)(
                                    new Error(
                                      "Error Loading JSONP Render Callback"
                                    ),
                                    "renderImp-fif-callback-load"
                                  );
                                }
                              ))
                            : l
                            ? (_t.a.dispatch({
                                type: "OUTSTREAM_SHOULD_SAMPLE",
                                shouldSample: Object(Et.k)(10),
                              }),
                              (h = Object(kt.c)(p, At.b)),
                              (v =
                                1 <=
                                (null ==
                                (O =
                                  null ==
                                    (y =
                                      _t.a.getState().bidConfigs[s.bidReqID]) ||
                                  null == (g = y.slots)
                                    ? void 0
                                    : g.filter(function (t) {
                                        return (
                                          (null == t ? void 0 : t.slotID) ===
                                          (null == p ? void 0 : p.slotID)
                                        );
                                      }))
                                  ? void 0
                                  : O.length)
                                  ? null == (m = O[0])
                                    ? void 0
                                    : m.companions
                                  : []),
                              (j = Object(kt.b)(h, At.y, p, v)),
                              (p.html = j),
                              _(p))
                            : _t.a.getState().aaxViewabilityEnabled
                            ? R(p, t, r)
                            : D(p),
                          l || tt(t, p));
                    } else
                      try {
                        Object(Rt.b)(
                          new Error(
                            "Invalid bid ID. '"
                              .concat(
                                "(bidID value: " +
                                  e +
                                  ", bID value: " +
                                  a +
                                  ")",
                                "' tried to render into document "
                              )
                              .concat(
                                t instanceof Document
                                  ? t.documentURI
                                  : "with type " + Wt(t)
                              )
                          ),
                          "_renderImp-invalidId",
                          { makeVisibleToAllUsers: !0 }
                        );
                      } catch (t) {
                        Object(Rt.b)(t, "_renderImp-invalidId");
                      }
                  }
                } catch (t) {
                  Object(Rt.b)(t, "_renderImp", { makeVisibleToAllUsers: !0 });
                }
              }
              function k(t, e, n) {
                try {
                  var r,
                    o = "";
                  return (
                    void 0 !== n && 1 <= n.length
                      ? ((r = "".concat(t, "_sp")),
                        "sp" === n &&
                          Object(Et.j)(e.bidConfig, r) &&
                          (o = e.bidConfig[r]))
                      : Object(Et.j)(e.bidConfig, t) && (o = e.bidConfig[t]),
                    o
                  );
                } catch (t) {
                  return Object(Rt.b)(t, "_getProperBidInfoValue"), "";
                }
              }
              function R(t, e, n) {
                try {
                  var r = e.createElement("script"),
                    o =
                      ((r.type = "text/javascript"),
                      (r.async = !0),
                      {
                        doc: e,
                        bidID: t.bidID,
                        states: {
                          csmLoaded: !1,
                          iframeLoaded: !1,
                          shouldRunViewability: !0,
                        },
                      }),
                    i = J.bind(null, o, n);
                  Object(zt.a)(r, function () {
                    (o.states.csmLoaded = !0), i();
                  }),
                    D(t, o, i),
                    (r.src = _t.a.getState().cfg.CSM_JS),
                    g(e, r);
                } catch (t) {
                  Object(Rt.b)(t, "_loadViewabilityAd");
                }
              }
              function z(t) {
                var e = Jt();
                try {
                  (t = Zt(e, "bids", t, "aaxResp")),
                    Object(Ht.a)(e).safelyRecord(
                      "_legacy/bidRequest/didComplete",
                      {
                        pairedEvents: ["_legacy/bidRequest/monitor"],
                        eventIdentifier: t.cb,
                        statusUpdate: "completed",
                      }
                    );
                } catch (t) {}
                var n = Kt;
                try {
                  x(t, n, e),
                    Object(Et.j)(t, "slots") &&
                      (_t.a.dispatch({ type: "UPDATE_SLOT_BIDS", bids: Q(t) }),
                      Object(Et.j)(t, "ev") &&
                        _t.a.dispatch({
                          type: "SET_VIEWABILITY",
                          viewability: t.ev,
                        }),
                      Object(Et.j)(t, "cfn")) &&
                      _t.a.dispatch({
                        type: "SET_CFG",
                        cfg: {
                          CSM_JS:
                            "//" === t.cfn.substring(0, 2)
                              ? t.cfn
                              : "//c.amazon-adsystem.com/".concat(t.cfn),
                        },
                      }),
                    U(t);
                } catch (t) {
                  Object(Rt.b)(t, "_bids", { makeVisibleToAllUsers: !0 });
                }
              }
              function pt() {
                return (
                  "number" ==
                    typeof _t.a.getState().cfg.MAX_SLOTS_PER_REQUEST &&
                  0 < _t.a.getState().cfg.MAX_SLOTS_PER_REQUEST
                );
              }
              function yt(t, e, n) {
                var r,
                  o =
                    null !=
                    (r =
                      null == n || null == (r = n.initConfig)
                        ? void 0
                        : r.pubID)
                      ? r
                      : _t.a.getState().config.pubID;
                t = Zt(o, "fetchBids", t, "bidConfig");
                try {
                  Object(Ht.a)(o).safelyRecord("consent/tcfapi/attemptSync"),
                    Object(Ht.a)(o).safelyRecord("consent/gppapi/attemptSync"),
                    a.attemptConsentDataSync();
                  var i = Object(Mt.b)(o);
                  Object(Tt.a)(
                    _t.a.getState().config.gdpr,
                    function (r) {
                      L(t, e, r, i, {
                        initConfig: null == n ? void 0 : n.initConfig,
                        contextURL: null == n ? void 0 : n.contextURL,
                        accountID: o,
                      });
                    },
                    o
                  );
                } catch (r) {
                  Object(Rt.b)(r, "_getConfigsAndFetchBids", {
                    makeVisibleToAllUsers: !0,
                  });
                }
              }
              function gt(t, e, n) {
                var r = n.initConfig.pubID,
                  o =
                    (Object(Ht.a)(r).safelyRecord("consent/tcfapi/attemptSync"),
                    Object(Ht.a)(r).safelyRecord("consent/gppapi/attemptSync"),
                    a.attemptConsentDataSync(),
                    Object(Mt.b)(r));
                Object(Tt.a)(
                  _t.a.getState().config.gdpr,
                  function (i) {
                    L(t, e, i, o, {
                      initConfig: null == n ? void 0 : n.initConfig,
                      contextURL: null == n ? void 0 : n.contextURL,
                      accountID: r,
                    });
                  },
                  r
                );
              }
              function L(t, e, n, r, o) {
                var i = o.accountID,
                  a =
                    (Object(Ht.a)(i).safelyRecord(
                      "deviceSignal/cookieDeprecationLabel/set"
                    ),
                    null != o && o.adServer ? Object(xt.a)(o.adServer) : Kt);
                Object(Ht.a)(i).safelyRecord("sessionMarker/marker/sync");
                try {
                  Object(Bt.b)(e, ["function", "undefined"]) ||
                    Object(Rt.c)("fetchBids.callback", Wt(e), "function"),
                    "function" != typeof e && (e = function () {}),
                    Object(Et.i)(t) ||
                      (Object(Rt.c)("fetchBids.bidConfig", Wt(t), "object"),
                      (t = {})),
                    Object(Bt.a)(t.timeout) ||
                      ("string" == typeof t.timeout
                        ? Object(Rt.b)(
                            {
                              name: "string-".concat(t.timeout),
                              message:
                                "fetchBids.bidConfig.timeout was a non-numeric string '".concat(
                                  t.timeout,
                                  "'"
                                ),
                            },
                            "TypeError-fetchBids.bidConfig.timeout",
                            { makeVisibleToAllUsers: !0 }
                          )
                        : Object(Rt.c)(
                            "fetchBids.bidConfig.timeout",
                            Wt(t.timeout),
                            "number"
                          )),
                    Object(Et.j)(t, "params") && !Object(Et.i)(t.params)
                      ? Object(Rt.c)(
                          "fetchBids.bidConfig.params",
                          Wt(t.params),
                          "object"
                        )
                      : Object(Et.j)(t, "params") &&
                        Object(Et.i)(t.params) &&
                        Object.keys(t.params).forEach(function (e) {
                          return !(
                            void 0 === t.params ||
                            ("string" != typeof t.params[e] &&
                              "number" != typeof t.params[e] &&
                              (Object(Et.h)(t.params[e])
                                ? !t.params[e].reduce(function (t, e) {
                                    return (
                                      t &&
                                      ("string" == typeof e ||
                                        "number" == typeof e)
                                    );
                                  }, !0) &&
                                  (Object(Rt.b)(
                                    {
                                      name: "non-string array item",
                                      message:
                                        "'fetchBids.bidConfig.params.".concat(
                                          e,
                                          " contains a non-string item"
                                        ),
                                    },
                                    "TypeError-fetchBids.bidConfig.params.".concat(
                                      e
                                    ),
                                    { makeVisibleToAllUsers: !0 }
                                  ),
                                  1)
                                : (Object(Rt.c)(
                                    "fetchBids.bidConfig.params.".concat(e),
                                    Wt(t.params[e]),
                                    "string' or 'array"
                                  ),
                                  1)))
                          );
                        }),
                    Object(Et.j)(t, "blockedBidders") &&
                    !Object(Et.h)(t.blockedBidders)
                      ? Object(Rt.c)(
                          "fetchBids.bidConfig.blockedBidders",
                          Wt(t.blockedBidders),
                          "array"
                        )
                      : Object(Et.j)(t, "blockedBidders") &&
                        Object(Et.h)(t.blockedBidders) &&
                        (t.blockedBidders.reduce(function (t, e) {
                          return (
                            t && ("string" == typeof e || "number" == typeof e)
                          );
                        }, !0) ||
                          Object(Rt.b)(
                            {
                              name: "non-string array item",
                              message:
                                "'fetchBids.bidConfig.blockedBidders contains a non-string item",
                            },
                            "TypeError-fetchBids.bidConfig.blockedBidders",
                            { makeVisibleToAllUsers: !0 }
                          )),
                    Object(Et.j)(t, "slots") &&
                      !Object(Et.h)(t.slots) &&
                      Object(Rt.c)(
                        "fetchBids.bidConfig.slots",
                        Wt(t.slots),
                        "array"
                      );
                } catch (a) {
                  Object(Rt.b)(a, "_fetchBids-validation", {
                    makeVisibleToAllUsers: !0,
                  });
                }
                var c = !1,
                  s =
                    ((te({ overrides: null == o ? void 0 : o.initConfig })
                      .simplerGPT ||
                      Object(Ht.a)(i).read("ad/googletagSlotAutoImport")) &&
                      (c = !0),
                    Yt(
                      Yt({}, t),
                      {},
                      {
                        bidReqID: "".concat(_t.a.getState().AAXReqs.length),
                        slots: [],
                        validSlots: [],
                        networkReqs: [],
                      }
                    )),
                  u = !1;
                try {
                  !0 === c &&
                  (!Object(Et.j)(t, "slots") ||
                    (Object(Et.j)(t, "slots") &&
                      Object(Et.h)(t.slots) &&
                      0 < t.slots.length &&
                      Object(Et.j)(t.slots[0], "getSlotElementId")))
                    ? 0 === Object(It.b)(a).length
                      ? (Object(Rt.b)(
                          new Error(
                            "fetchBids was called in simplerGPT mode before any slots were defined in GPT"
                          ),
                          "_fetchBids-simplerGpt-NoSlots",
                          { makeVisibleToAllUsers: !0 }
                        ),
                        (u = !0),
                        (s.slots = []))
                      : (t.slots
                          ? (s.slots = t.slots.map(function (t) {
                              return new qt.a(t);
                            }))
                          : (s.slots = Object(It.b)(a)),
                        (s.slots = s.slots.filter(It.a)),
                        0 === s.slots.length &&
                          (Object(Rt.b)(
                            new Error(
                              "No GPT slots provided to apstag.fetchBids() had valid sizes"
                            ),
                            "_fetchBids-simplerGpt-NoValidSizes",
                            { makeVisibleToAllUsers: !0 }
                          ),
                          (u = !0)))
                    : Object(Et.j)(t, "slots") &&
                      Object(Et.h)(t.slots) &&
                      (s.slots = t.slots.map(function (t) {
                        switch (t.mediaType) {
                          case Nt.a.DISPLAY:
                            return new Ft.a(t);
                          case Nt.a.VIDEO:
                            return new ne.a(t);
                          case Nt.a.MULTI_FORMAT:
                            return new re.a(t);
                          default:
                            return new Ft.a(t);
                        }
                      })),
                    (s.validSlots = s.slots.filter(function (t) {
                      return t.isValid();
                    })),
                    s.validSlots.length > At.m &&
                      (s.validSlots = s.validSlots.slice(
                        s.validSlots.length - At.m
                      ));
                } catch (a) {
                  Object(Rt.b)(a, "_fetchBids-getSlots", {
                    makeVisibleToAllUsers: !0,
                  });
                }
                var l = Object(Dt.h)(s, _t.a.getState());
                try {
                  e = Object(Dt.a)(Z(e, s, a, o), l);
                } catch (a) {
                  Object(Rt.b)(a, "_fetchBids-wrapCallback", {
                    makeVisibleToAllUsers: !0,
                  });
                }
                try {
                  if (0 === s.validSlots.length)
                    !1 === u &&
                      Object(Rt.b)(
                        new Error(
                          "No valid slots provided to apstag.fetchBids"
                        ),
                        "_fetchBids-noSlots",
                        { makeVisibleToAllUsers: !0 }
                      ),
                      setTimeout(e.bind(null, []), 10);
                  else if (
                    (ft(
                      s.slots
                        .filter(Object(It.d)(Nt.a.DISPLAY, Nt.a.MULTI_FORMAT))
                        .map(It.c),
                      a,
                      i
                    ),
                    _t.a.dispatch({
                      type: "NEW_FETCH_BID_REQUEST",
                      fid: s.bidReqID,
                      pto: l,
                    }),
                    _t.a.dispatch({
                      type: "RECORD_ORIGINAL_BID_CONFIG",
                      bidConfig: s,
                    }),
                    Object(Ht.a)(i).safelyRecord("_legacy/bidRequest/monitor", {
                      eventIdentifier: s.bidReqID,
                      analyticsSampleRateAdjustFactor: { status: 0.3 },
                    }),
                    Object(Pt.d)("fake_bids"))
                  )
                    et(s);
                  else if (At.k)
                    if (
                      (_t.a.dispatch({
                        type: "SHOULD_CHUNK_REQUESTS",
                        value: Object(Et.k)(
                          _t.a.getState().cfg.CHUNK_BID_REQUESTS_PROPORTION
                        ),
                      }),
                      _t.a.getState().experiments.chunkRequests && pt())
                    ) {
                      for (var f = mt(s), d = 0; d < f.length; d++)
                        f[d].bidReqID = "".concat(s.bidReqID, "-").concat(d);
                      _t.a.dispatch({
                        type: "ADD_CHUNKED_REQUESTS",
                        fid: s.bidReqID,
                        numChunks: f.length,
                      }),
                        f.forEach(function (a) {
                          b(Object(Ut.c)(a, l, n, r, o), e, a.bidReqID, i, t);
                        });
                    } else b(Object(Ut.c)(s, l, n, r, o), e, s.bidReqID, i, t);
                  else Object(zt.b)(Object(Ut.c)(s, l, n, r, o), e);
                } catch (a) {
                  Object(Rt.b)(a, "_fetchBids", { makeVisibleToAllUsers: !0 });
                }
              }
              function mt(t) {
                try {
                  for (
                    var e = Math.ceil(
                        t.validSlots.length /
                          _t.a.getState().cfg.MAX_SLOTS_PER_REQUEST
                      ),
                      n = new Array(e),
                      r = 0;
                    r < e;
                    r++
                  ) {
                    var o = r * _t.a.getState().cfg.MAX_SLOTS_PER_REQUEST;
                    n[r] = {
                      slots: t.validSlots.slice(
                        o,
                        o + _t.a.getState().cfg.MAX_SLOTS_PER_REQUEST
                      ),
                    };
                  }
                  return n.map(function (e) {
                    return Yt(Yt({}, t), e);
                  });
                } catch (e) {
                  return (
                    Object(Rt.b)(e, "chunkConfig", {
                      makeVisibleToAllUsers: !0,
                    }),
                    []
                  );
                }
              }
              function ht(t, e) {
                var n =
                  null !=
                  (n =
                    null == e || null == (n = e.initConfig) ? void 0 : n.pubID)
                    ? n
                    : _t.a.getState().config.pubID;
                try {
                  t = Zt(n, "setDisplayBids", t, "slotIDList");
                } catch (t) {}
                var r = null != e && e.adServer ? Object(xt.a)(e.adServer) : Kt;
                try {
                  (null != e && e.adServer) ||
                  Object(Et.j)(_t.a.getState().config, "adServer")
                    ? r.isSupported
                      ? (Y(r, n, t, e), j(r, n))
                      : Object(Rt.b)(
                          new Error(
                            "apstag.setDisplayBids called with unsupported ad server: ".concat(
                              _t.a.getState().config.adServer
                            )
                          ),
                          "_setDisplayBids-invalidAdServer",
                          { makeVisibleToAllUsers: !0 }
                        )
                    : Object(Rt.b)(
                        new Error(
                          "apstag.setDisplayBids called without specifying ad server"
                        ),
                        "_setDisplayBids-noAdServer",
                        { makeVisibleToAllUsers: !0 }
                      );
                } catch (t) {
                  Object(Rt.b)(t, "_setDisplayBids", {
                    makeVisibleToAllUsers: !0,
                  });
                }
              }
              function Ot(t, e) {
                var n;
                ((null != (n = t.gdpr) && n.consent) ||
                  (null != (n = t.gdpr) && n.enabled)) &&
                  ((n = {
                    tcString: null == (n = t.gdpr) ? void 0 : n.consent,
                    gdprApplies: null == (n = t.gdpr) ? void 0 : n.enabled,
                  }),
                  a.writeConsentDataToStore(n)),
                  a.attemptConsentDataSync(),
                  M(t),
                  "function" == typeof e && e();
              }
              function vt(t, e) {
                var n = t.pubID;
                t = Zt(n, "init", t, "config");
                try {
                  var r = (Kt = t.adServer ? Object(xt.a)(t.adServer) : Kt),
                    o =
                      (Ot(t),
                      lt(r, n),
                      Object(ie.b)(),
                      Object(Ht.a)(n).read("idVendors/newConfigFlowEnabled"));
                  !0 !== o &&
                    (void 0 === o &&
                      Object(Ht.a)(n).safelyRecord(
                        "idVendors/legacy/didExecuteFirst",
                        {
                          analytics: {
                            context: "load3PLibraryConfig",
                            timing: "legacy-first",
                          },
                        }
                      ),
                    Object(Mt.c)(n));
                } catch (t) {
                  Object(Rt.b)(t, "_init");
                }
                "function" == typeof e && e();
              }
              function jt() {
                var t,
                  e =
                    0 < arguments.length && void 0 !== arguments[0]
                      ? arguments[0]
                      : "display",
                  n = Kt,
                  r = _t.a.getState();
                try {
                  switch (e) {
                    case Nt.a.DISPLAY:
                      return r.config.useSafeFrames
                        ? [].concat(Xt(At.i), ["amznhost"])
                        : At.i;
                    case Nt.a.VIDEO:
                      return r.config.useSafeFrames
                        ? [].concat(Xt(At.x), ["amznhost"])
                        : At.x;
                    default:
                      return Object(Ut.f)(
                        null == (t = _t.a.getState()) ? void 0 : t.config,
                        n
                      ) && Object(Et.h)(_t.a.getState().targetingKeys[e])
                        ? _t.a.getState().targetingKeys[e]
                        : [];
                  }
                } catch (t) {
                  return (
                    Object(Rt.b)(t, "_targetingKeys", {
                      makeVisibleToAllUsers: !0,
                    }),
                    []
                  );
                }
              }
              function St() {
                try {
                  return _t.a.getState().AAXReqs.reduce(function (t, e) {
                    return e.bidConfig.slots.reduce(function (t, e) {
                      return (t[e.slotID] = e.slotName), t;
                    }, t);
                  }, {});
                } catch (t) {
                  return (
                    Object(Rt.b)(t, "_getSlotIdToNameMapping", {
                      makeVisibleToAllUsers: !0,
                    }),
                    {}
                  );
                }
              }
              function wt() {
                return Gt.a
                  .getDefault()
                  .allowedToStoreAndAccessInformationOnDevice();
              }
              try {
                Object(Et.j)(window, "apstag") &&
                  Object(Et.j)(window.apstag, "_Q") &&
                  0 < window.apstag._Q.length &&
                  _t.a.dispatch({ type: "SET_Q", Q: window.apstag._Q });
              } catch (t) {
                Object(Rt.b)(t, "apstag-storeQ", { makeVisibleToAllUsers: !0 });
              }
              (window.apstag = (function () {
                var e = {
                  punt: z,
                  init: vt,
                  debug: Pt.a,
                  _getSlotIdToNameMapping: St,
                  targetingKeys: jt,
                  fetchBids: yt,
                  setDisplayBids: ht,
                  renderImp: bt,
                  bids: z,
                  deleteId: Vt.a,
                  updateId: Vt.e,
                  renewId: Vt.c,
                  dpa: Vt.a,
                  upa: Vt.e,
                  rpa: Vt.c,
                  thirdPartyData: {},
                  isGDPRRegion: !0,
                  rr: Vt.d,
                  re: Rt.b,
                  _load3PLibraryConfig: Mt.c,
                  _atsaaiod: wt,
                  clientFetchBids: gt,
                };
                return (
                  Object.keys(e).forEach(function (t) {
                    "function" == typeof e[t] &&
                      ((e[t] = Object(Qt.a)(t, e[t])),
                      (e[t] = Object(Rt.d)(e[t], t)));
                  }),
                  r ? Object(Pt.b)(!0, t) : n && Object(Pt.b)(!1, t),
                  !0 === Object(Pt.c)("exposeApi") &&
                    (e._api = {
                      _getBidSetInfo: at,
                      _applyTargetingToGPTSlot: y,
                      dispatch: _t.a.dispatch,
                      _clearTargetingFromGPTSlot: f,
                      _clearBidSetOnSlot: d,
                      _getCurrentSlotBids: p,
                      _creativeURL: w,
                      getSlotFetchCounts: it,
                      buildBidUrl: Ut.c,
                    }),
                  Yt(Yt({}, window.apstag), e)
                );
              })()),
                (function () {
                  try {
                    var t,
                      e =
                        (_t.a.dispatch({
                          type: "SHOULD_SAMPLE_FEATURES",
                          value: Object(Et.k)(
                            _t.a.getState().cfg.FEATURE_SAMPLING_RATE
                          ),
                        }),
                        _t.a.dispatch({
                          type: "SET_HOST",
                          hostName: "DEFAULT_AAX_BID_HOST",
                          hostValue: "aax.amazon-adsystem.com",
                        }),
                        _t.a.dispatch({
                          type: "SHOULD_SAMPLE_LATENCY",
                          value: Object(Et.k)(
                            _t.a.getState().cfg.LATENCY_SAMPLING_RATE
                          ),
                        }),
                        null !== _t.a.getState().cfg.TEST_BID_ENDPOINT &&
                          ((t = Object(Et.k)(
                            _t.a.getState().cfg.TEST_PATH_FREQUENCY
                          )),
                          _t.a.dispatch({
                            type: "SHOULD_USE_TEST_BID_ENDPOINT",
                            value: t,
                          }),
                          t) &&
                          null !==
                            _t.a.getState().cfg.TEST_PATH_LATENCY_SAMPLE_RATE &&
                          _t.a.dispatch({
                            type: "SHOULD_SAMPLE_LATENCY",
                            value: Object(Et.k)(
                              _t.a.getState().cfg.TEST_PATH_LATENCY_SAMPLE_RATE
                            ),
                          }),
                        _t.a.dispatch({
                          type: "SHOULD_SAMPLE_SLOT_RENDER",
                          value: Object(Et.k)(
                            _t.a.getState().cfg.SLOT_RENDER_SAMPLING_RATE
                          ),
                        }),
                        _t.a.getState());
                    (e.experiments.shouldSampleLatency ||
                      e.displayAdServer.shouldSampleRender) &&
                      I();
                  } catch (t) {
                    Object(Rt.b)(t, "apstag-sampleLatency");
                  }
                  try {
                    B();
                  } catch (t) {
                    Object(Rt.b)(t, "apstag-doLast");
                  }
                  if (!Object(Dt.i)(window, !0))
                    try {
                      var n = function (t) {
                        (t && "object" !== Wt(t)) ||
                          (t = "Request Timeout or Error"),
                          Object(Rt.b)(
                            {
                              message: "csm-rtb-comm-js loading failed",
                              name: t,
                            },
                            "__csm-rtb-comm-js__"
                          );
                      };
                      Object(zt.d)({
                        url: _t.a.getState().cfg.CSM_RTB_COMMUNICATOR_JS,
                        onload: function t(e) {
                          e.readyState === XMLHttpRequest.DONE &&
                          200 === e.status
                            ? eval(e.responseText)
                            : n(
                                JSON.stringify({
                                  status: e.statusText,
                                  response: e.responseXML,
                                })
                              );
                        },
                        onerror: n,
                        ontimeout: n,
                      });
                    } catch (t) {
                      Object(Rt.b)(t, "__load-csm-rtb-comm-js__");
                    }
                  Object(Pt.e)();
                })();
            })(),
            Object(Ht.a)("_system").safelyRecord("apstag/library/didLoad", {
              source: "bundle",
            }));
      } catch (t) {
        Object(Rt.b)(t, "apstag");
      }
    },
    function (t, e, n) {
      "use strict";
      n.d(e, "a", function () {
        return d;
      }),
        n.d(e, "c", function () {
          return m;
        }),
        n.d(e, "b", function () {
          return h;
        }),
        n.d(e, "d", function () {
          return O;
        });
      var r = n(1),
        o = n(0),
        i = n(2),
        a = n(5);
      function c(t) {
        return (c =
          "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
            ? function (t) {
                return typeof t;
              }
            : function (t) {
                return t &&
                  "function" == typeof Symbol &&
                  t.constructor === Symbol &&
                  t !== Symbol.prototype
                  ? "symbol"
                  : typeof t;
              })(t);
      }
      function s(t, e) {
        var n,
          r = Object.keys(t);
        return (
          Object.getOwnPropertySymbols &&
            ((n = Object.getOwnPropertySymbols(t)),
            e &&
              (n = n.filter(function (e) {
                return Object.getOwnPropertyDescriptor(t, e).enumerable;
              })),
            r.push.apply(r, n)),
          r
        );
      }
      function u(t) {
        for (var e = 1; e < arguments.length; e++) {
          var n = null != arguments[e] ? arguments[e] : {};
          e % 2
            ? s(Object(n), !0).forEach(function (e) {
                var r, o;
                (r = t),
                  (o = n[(e = e)]),
                  (e = (function (t) {
                    return (
                      (t = (function (t, e) {
                        if ("object" !== c(t) || null === t) return t;
                        var n = t[Symbol.toPrimitive];
                        if (void 0 === n) return String(t);
                        if ("object" !== c((n = n.call(t, e)))) return n;
                        throw new TypeError(
                          "@@toPrimitive must return a primitive value."
                        );
                      })(t, "string")),
                      "symbol" === c(t) ? t : String(t)
                    );
                  })(e)) in r
                    ? Object.defineProperty(r, e, {
                        value: o,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0,
                      })
                    : (r[e] = o);
              })
            : Object.getOwnPropertyDescriptors
            ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n))
            : s(Object(n)).forEach(function (e) {
                Object.defineProperty(
                  t,
                  e,
                  Object.getOwnPropertyDescriptor(n, e)
                );
              });
        }
        return t;
      }
      var l =
          Number.isInteger ||
          function (t) {
            return "number" == typeof t && isFinite(t) && Math.floor(t) === t;
          },
        f = "__tcfapi";
      function d(t, e, n) {
        if ((b = Object(a.a)(n).read("consent/TCData")))
          e({
            enabled: b.gdprApplies ? 1 : 0,
            consent: b.tcString,
            log: { status: "tcfv2-success" },
            gdprApplies: b.gdprApplies,
          });
        else {
          Object(a.a)(n).safelyRecord(
            "_legacy/getGdprConfig_legacy/willExecute"
          );
          var i,
            s = !1,
            d = { log: { status: "no-status" } },
            b = 50,
            p = "global-func-error";
          e = Object(r.d)(e, "GdprCallback");
          try {
            if (
              (!1 === (t = Object(o.i)(t) ? u({}, t) : {}).enabled ||
              0 === t.enabled
                ? ((d.log.status = "explicit-no-gdpr"), (d.enabled = 0))
                : !0 === t.enabled || 1 === t.enabled
                ? ((d.log.status = Object(o.j)(t, "consent")
                    ? "explicit-consent-passed"
                    : "explicit-no-consent-passed"),
                  (d.enabled = 1),
                  (d.consent = t.consent))
                : Object(o.j)(t, "enabled") &&
                  ((d.log.status = Object(o.j)(t, "consent")
                    ? "malformed-with-consent"
                    : "malformed-without-consent"),
                  (d.consent = t.consent),
                  l(t.enabled) ? (d.enabled = t.enabled) : (d.enabled = 1)),
              Object(o.j)(t, "enabled") && (d.log.enabled = t.enabled),
              Object(o.j)(t, "cmpTimeout") &&
                l(t.cmpTimeout) &&
                ((b = t.cmpTimeout), (d.log.cmpTimeout = b)),
              void 0 !== d.enabled)
            )
              return (
                Object(o.j)(d, "consent") &&
                  "string" != typeof d.consent &&
                  (delete d.consent,
                  Object(r.b)(
                    new Error(
                      "Invalid consent: must be string, given ".concat(
                        c(d.consent)
                      )
                    ),
                    "getGdprConfig-pub-consent-invalid",
                    { makeVisibleToAllUsers: !0 }
                  )),
                void y()
              );
          } catch (t) {
            Object(r.b)(t, "getGdprConfig-parseConfig", {
              makeVisibleToAllUsers: !0,
            });
          }
          try {
            Object(o.j)(window, f) && "function" == typeof window[f]
              ? ((i = "tcfv2"),
                setTimeout(function () {
                  (d.log.status = "".concat(i, "-timeout")), y();
                }, b),
                (p = "".concat(i, "-internal-error")),
                window[f]("getTCData", 2, function (t, e) {
                  try {
                    e && Object(o.i)(t)
                      ? ((d.log.status = "".concat(i, "-success")),
                        Object(o.j)(t, "tcString")
                          ? (d.consent = t.tcString)
                          : Object(o.j)(t, "consentData") &&
                            (d.consent = t.consentData),
                        (d.enabled = t.gdprApplies ? 1 : 0),
                        0 === d.enabled && delete d.consent,
                        (d.gdprApplies = t.gdprApplies),
                        y())
                      : ((d.log.status = "".concat(i, "-error")), y());
                  } catch (t) {
                    (d.log.status = "func-error"),
                      y(),
                      Object(r.b)(t, "cmpCallback-".concat(i), {
                        makeVisibleToAllUsers: !0,
                      });
                  }
                }))
              : ((d.log.status = "no-cmp"), y());
          } catch (t) {
            (d.log.status = p),
              y(),
              Object(r.b)(t, "getGdprConfig-".concat(p), {
                makeVisibleToAllUsers: !0,
              });
          }
        }
        function y() {
          s ||
            ((s = !0),
            d.consent &&
              Object(r.b)(
                new Error(
                  "Legacy getTCData logic was successful when addEventListener logic wasn't"
                ),
                "LEGACY-TCFAPI-SUCCESS",
                { makeVisibleToAllUsers: !1, accountId: n }
              ),
            e(u(u({}, d), {}, { log: u({}, d.log) })));
        }
      }
      function b(t) {
        for (var e = [], n = -1; 0 <= (n = t.indexOf("1", n + 1)); )
          e.push(n + 1);
        return e;
      }
      function p(t) {
        for (var e = [], n = parseInt(g(t, 12), 2), r = 0; r < n; r++) {
          var o = parseInt(g(t, 1), 2),
            i = parseInt(g(t, 16), 2);
          if ((e.push(i), o))
            for (var a = parseInt(g(t, 16), 2), c = i + 1; c <= a; c++)
              e.push(c);
        }
        return e;
      }
      function y(t) {
        var e = parseInt(g(t, 16), 2);
        return parseInt(g(t, 1), 2) ? p(t) : b(g(t, e));
      }
      function g(t, e) {
        var n = t.bits.substr(t.index, e);
        return (t.index += e), n;
      }
      function m(t) {
        try {
          var e, n, o;
          return (
            !!t &&
            !(
              (e = (function (t) {
                try {
                  for (
                    var e = (t = (t = t.replace(/-/g, "+")).replace(
                        /_/g,
                        "/"
                      )).split(".")[0],
                      n = window.atob(e),
                      o = "",
                      i = 0;
                    i < n.length;
                    i++
                  )
                    o += ("0000000" + n.charCodeAt(i).toString(2)).substr(-8);
                  return o;
                } catch (e) {
                  return (
                    Object(r.b)(
                      new Error(
                        "TCF string conversion failed. (TCF string: ".concat(
                          t,
                          ")"
                        )
                      ),
                      "TCFToBinary",
                      { makeVisibleToAllUsers: !0 }
                    ),
                    ""
                  );
                }
              })(t)).length < 230
            ) &&
            ((o = { bits: e, index: 0 }),
            ((n = {}).version = parseInt(g(o, 6), 2)),
            2 === n.version) &&
            ((n.created = parseInt(g(o, 36), 2)),
            (n.lastUpdated = parseInt(g(o, 36), 2)),
            (n.cmpId = parseInt(g(o, 12), 2)),
            (n.cmpVersion = parseInt(g(o, 12), 2)),
            (n.consentScreen = parseInt(g(o, 6), 2)),
            (n.consentLanguage =
              String.fromCharCode(parseInt(g(o, 6), 2) + 65) +
              String.fromCharCode(parseInt(g(o, 6), 2) + 65)),
            (n.vendorListVersion = parseInt(g(o, 12), 2)),
            (n.tcfPolicyVersion = parseInt(g(o, 6), 2)),
            (n.isServiceSpecific = "1" === g(o, 1)),
            (n.useNonStandardStacks = "1" === g(o, 1)),
            (n.specialFeatureOptIns = b(g(o, 12))),
            (n.purposesConsent = b(g(o, 24))),
            (n.purposesLITransparency = b(g(o, 24))),
            (n.purposeOneTreatment = "1" === g(o, 1)),
            (n.publisherCC =
              String.fromCharCode(parseInt(g(o, 6), 2) + 65) +
              String.fromCharCode(parseInt(g(o, 6), 2) + 65)),
            (n.vendorConsents = y(o)),
            (n.vendorLegitimateInterests = y(o)),
            (n.publisherRestrictions = (function (t) {
              for (var e = parseInt(g(t, 12), 2), n = [], r = 0; r < e; r++) {
                var o = parseInt(g(t, 6), 2),
                  i = parseInt(g(t, 2), 2);
                n.push({ purposeId: o, restrictionType: i, vendorIds: p(t) });
              }
              return n;
            })(o)),
            n)
          );
        } catch (t) {
          return (
            Object(r.b)(t, "parseTCFString", { makeVisibleToAllUsers: !0 }), !1
          );
        }
      }
      function h(t) {
        var e = [];
        try {
          var n = Date.now(),
            r =
              (t || e.push("Invalid tcString: ".concat(t)),
              2 !== t.version &&
                e.push("tcString version not supported: ".concat(t.version)),
              t.useNonStandardStacks &&
                e.push("tcString's useNonStandardStacks should not be true"),
              t.isServiceSpecific ||
                e.push("tcString needs to be service specific"),
              t.publisherRestrictions
                ? t.publisherRestrictions.filter(function (t) {
                    return 1 === t.purposeId && 0 <= t.vendorIds.indexOf(793);
                  })
                : []);
          if (0 === r.length) v(t) || e.push("Invalid publisher restrictions");
          else
            switch (r[0].restrictionType) {
              case 0:
              case 2:
                e.push("Invalid publisher restrictions");
                break;
              default:
                v(t) || e.push("Invalid publisher restrictions");
            }
          return (
            i.a.dispatch({
              type: "RECORD_TCF_PARSE_TIME",
              time: Date.now() - n,
            }),
            e
          );
        } catch (t) {
          if (e.length) return e;
          throw t;
        }
      }
      function O(t, e) {
        if (!t)
          return !!window.apstag && !window.apstag.isGDPRRegion && !0 !== e;
        if (window.apstag && !window.apstag.isGDPRRegion && !1 === e) return !0;
        if (2 !== t.version) return !1;
        if (t.useNonStandardStacks) return !1;
        if (!t.isServiceSpecific) return !1;
        if (
          0 ===
          (e = t.publisherRestrictions.filter(function (t) {
            return 1 === t.purposeId && 0 <= t.vendorIds.indexOf(793);
          })).length
        )
          return v(t);
        switch (e[0].restrictionType) {
          case 0:
          case 2:
            return !1;
          default:
            return v(t);
        }
      }
      function v(t) {
        return (
          !(
            !Object(o.j)(t, "vendorConsents") ||
            !Object(o.j)(t, "purposesConsent")
          ) &&
          0 <= t.vendorConsents.indexOf(793) &&
          0 <= t.purposesConsent.indexOf(1)
        );
      }
    },
    function (t, e, n) {
      "use strict";
      n.d(e, "b", function () {
        return l;
      }),
        n.d(e, "a", function () {
          return f;
        }),
        n.d(e, "e", function () {
          return d;
        }),
        n.d(e, "c", function () {
          return b;
        }),
        n.d(e, "d", function () {
          return p;
        });
      var r,
        o = n(1),
        i = n(6),
        a = n(2),
        c = n(5),
        s = "AMZN-Token",
        u = "AMZN-NoCookieConsent";
      function l() {
        var t =
          0 < arguments.length && void 0 !== arguments[0]
            ? arguments[0]
            : r.token;
        try {
          var e = i.a.getDefault().cookie.getItem(t === r.noConsent ? u : s);
          return e || "";
        } catch (e) {
          return Object(o.b)(e, "getAmznToken-".concat(t)), "";
        }
      }
      function f(t) {
        var e = a.a.getState().config.pubID;
        return Object(c.a)(e)
          .record("ad/record/delete")
          .then(function () {
            "function" == typeof t && t();
          })
          .catch(function () {
            "function" == typeof t && t();
          });
      }
      function d(t, e, n) {
        "boolean" != typeof n && (n = !0);
        var r = a.a.getState().config.pubID;
        return Object(c.a)(r)
          .record("ad/record/update", { config: t, setCookie: n })
          .then(function () {
            "function" == typeof e && e();
          })
          .catch(function () {
            "function" == typeof e && e();
          });
      }
      function b(t, e, n) {
        "boolean" != typeof n && (n = !0);
        var r = a.a.getState().config.pubID;
        return Object(c.a)(r)
          .record("ad/record/renew", { config: t, setCookie: n })
          .then(function () {
            "function" == typeof e && e();
          })
          .catch(function () {
            "function" == typeof e && e();
          });
      }
      function p(t) {
        var e = a.a.getState().config.pubID;
        return Object(c.a)(e).safelyRecord("ad/record/rr", { config: t });
      }
      ((e = r = r || {})[(e.noConsent = 0)] = "noConsent"),
        (e[(e.token = 1)] = "token");
    },
    function (t, e, n) {
      "use strict";
      var r;
      n.d(e, "a", function () {
        return r;
      }),
        ((n = r = r || {}).DISPLAY = "d"),
        (n.VIDEO = "v"),
        (n.MULTI_FORMAT = "mf");
    },
    function (t, e, n) {
      "use strict";
      n.d(e, "a", function () {
        return m;
      });
      e = n(14);
      var r = n(0),
        o = n(1),
        i = n(4);
      function a(t) {
        return (a =
          "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
            ? function (t) {
                return typeof t;
              }
            : function (t) {
                return t &&
                  "function" == typeof Symbol &&
                  t.constructor === Symbol &&
                  t !== Symbol.prototype
                  ? "symbol"
                  : typeof t;
              })(t);
      }
      function c(t, e) {
        var n,
          r = Object.keys(t);
        return (
          Object.getOwnPropertySymbols &&
            ((n = Object.getOwnPropertySymbols(t)),
            e &&
              (n = n.filter(function (e) {
                return Object.getOwnPropertyDescriptor(t, e).enumerable;
              })),
            r.push.apply(r, n)),
          r
        );
      }
      function s(t) {
        for (var e = 1; e < arguments.length; e++) {
          var n = null != arguments[e] ? arguments[e] : {};
          e % 2
            ? c(Object(n), !0).forEach(function (e) {
                y(t, e, n[e]);
              })
            : Object.getOwnPropertyDescriptors
            ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n))
            : c(Object(n)).forEach(function (e) {
                Object.defineProperty(
                  t,
                  e,
                  Object.getOwnPropertyDescriptor(n, e)
                );
              });
        }
        return t;
      }
      function u(t, e) {
        for (var n = 0; n < e.length; n++) {
          var r = e[n];
          (r.enumerable = r.enumerable || !1),
            (r.configurable = !0),
            "value" in r && (r.writable = !0),
            Object.defineProperty(t, g(r.key), r);
        }
      }
      function l() {
        return (l =
          "undefined" != typeof Reflect && Reflect.get
            ? Reflect.get.bind()
            : function (t, e, n) {
                var r = (function (t, e) {
                  for (
                    ;
                    !Object.prototype.hasOwnProperty.call(t, e) &&
                    null !== (t = p(t));

                  );
                  return t;
                })(t, e);
                if (r)
                  return (r = Object.getOwnPropertyDescriptor(r, e)).get
                    ? r.get.call(arguments.length < 3 ? t : n)
                    : r.value;
              }).apply(this, arguments);
      }
      function f(t, e) {
        return (f = Object.setPrototypeOf
          ? Object.setPrototypeOf.bind()
          : function (t, e) {
              return (t.__proto__ = e), t;
            })(t, e);
      }
      function d(t) {
        var e = (function () {
          if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
          if (Reflect.construct.sham) return !1;
          if ("function" == typeof Proxy) return !0;
          try {
            return (
              Boolean.prototype.valueOf.call(
                Reflect.construct(Boolean, [], function () {})
              ),
              !0
            );
          } catch (t) {
            return !1;
          }
        })();
        return function () {
          var n,
            r = p(t);
          (n = e
            ? ((n = p(this).constructor), Reflect.construct(r, arguments, n))
            : r.apply(this, arguments)),
            (r = this);
          if (n && ("object" === a(n) || "function" == typeof n)) return n;
          if (void 0 !== n)
            throw new TypeError(
              "Derived constructors may only return object or undefined"
            );
          return b(r);
        };
      }
      function b(t) {
        if (void 0 === t)
          throw new ReferenceError(
            "this hasn't been initialised - super() hasn't been called"
          );
        return t;
      }
      function p(t) {
        return (p = Object.setPrototypeOf
          ? Object.getPrototypeOf.bind()
          : function (t) {
              return t.__proto__ || Object.getPrototypeOf(t);
            })(t);
      }
      function y(t, e, n) {
        (e = g(e)) in t
          ? Object.defineProperty(t, e, {
              value: n,
              enumerable: !0,
              configurable: !0,
              writable: !0,
            })
          : (t[e] = n);
      }
      function g(t) {
        return (
          (t = (function (t, e) {
            if ("object" !== a(t) || null === t) return t;
            var n = t[Symbol.toPrimitive];
            if (void 0 === n) return String(t);
            if ("object" !== a((n = n.call(t, e)))) return n;
            throw new TypeError("@@toPrimitive must return a primitive value.");
          })(t, "string")),
          "symbol" === a(t) ? t : String(t)
        );
      }
      var m = (function (t) {
        var e = a;
        if ("function" != typeof t && null !== t)
          throw new TypeError(
            "Super expression must either be null or a function"
          );
        (e.prototype = Object.create(t && t.prototype, {
          constructor: { value: e, writable: !0, configurable: !0 },
        })),
          Object.defineProperty(e, "prototype", { writable: !1 }),
          t && f(e, t);
        var n = d(a);
        function a(t) {
          var e;
          if (this instanceof a)
            return (
              y(
                b(
                  (e = n.call(this, {
                    slotID: t.getSlotElementId(),
                    slotName: t.getAdUnitPath(),
                  }))
                ),
                "rawSlot",
                void 0
              ),
              (e.rawSlot = t),
              e
            );
          throw new TypeError("Cannot call a class as a function");
        }
        return (
          (e = a),
          (t = [
            {
              key: "mediaType",
              get: function () {
                return i.a.DISPLAY;
              },
            },
            {
              key: "sizes",
              get: function () {
                try {
                  var t = Object(r.f)(window)
                      .split("x")
                      .map(function (t) {
                        return Number(t);
                      }),
                    e = this.rawSlot.getSizes(t[0], t[1]);
                  return null === e
                    ? []
                    : e
                        .filter(function (t) {
                          return "fluid" !== t;
                        })
                        .map(function (t) {
                          return [t.getWidth(), t.getHeight()];
                        });
                } catch (t) {
                  return this.reportError(t, "sizes"), [];
                }
              },
            },
            {
              key: "aaxSlot",
              get: function () {
                var t = s(
                  s({}, l(p(a.prototype), "aaxSlot", this)),
                  {},
                  {
                    sd: this.slotID,
                    s: this.sizes.filter(r.h).map(function (t) {
                      return t.join("x");
                    }),
                  }
                );
                return (
                  this.slotID !== this.slotName && (t.sn = this.slotName), t
                );
              },
            },
            {
              key: "isValid",
              value: function () {
                return !(
                  !l(p(a.prototype), "isValid", this).call(this) ||
                  (0 === this.sizes.length &&
                    (this.reportIsValidMessages(
                      ["'sizes' must have at least 1 valid item"],
                      !0
                    ),
                    1))
                );
              },
            },
            {
              key: "reportError",
              value: function (t, e, n) {
                Object(o.b)(t, "GptSlot-".concat(e), n);
              },
            },
            {
              key: "setTargeting",
              value: function (t, e) {
                try {
                  this.rawSlot.setTargeting(t, e);
                } catch (t) {
                  this.reportError(t, "setTargeting");
                }
              },
            },
            {
              key: "getTargeting",
              value: function (t) {
                try {
                  var e, n;
                  return "function" == typeof this.rawSlot.getConfig
                    ? ((n =
                        (e = this.rawSlot.getConfig("targeting")) &&
                        e.targeting) &&
                        n[t]) ||
                        []
                    : this.rawSlot.getTargeting(t);
                } catch (t) {
                  return this.reportError(t, "getTargeting"), [];
                }
              },
            },
            {
              key: "clearTargeting",
              value: function (t) {
                try {
                  this.rawSlot.clearTargeting(t);
                } catch (t) {
                  this.reportError(t, "clearTargeting");
                }
              },
            },
          ]) && u(e.prototype, t),
          Object.defineProperty(e, "prototype", { writable: !1 }),
          a
        );
      })(e.a);
    },
    function (t, e, n) {
      "use strict";
      n.d(e, "a", function () {
        return O;
      }),
        n.d(e, "c", function () {
          return v;
        }),
        n.d(e, "e", function () {
          return j;
        }),
        n.d(e, "d", function () {
          return S;
        }),
        n.d(e, "b", function () {
          return w;
        });
      var c = n(10),
        s = n(1),
        u = n(32),
        l = n(3),
        f = n(2),
        d = n(6),
        r = n(0),
        b = n(16),
        o = n(33),
        i = n(5);
      function a(t) {
        return (a =
          "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
            ? function (t) {
                return typeof t;
              }
            : function (t) {
                return t &&
                  "function" == typeof Symbol &&
                  t.constructor === Symbol &&
                  t !== Symbol.prototype
                  ? "symbol"
                  : typeof t;
              })(t);
      }
      function p(t, e) {
        var n,
          r = Object.keys(t);
        return (
          Object.getOwnPropertySymbols &&
            ((n = Object.getOwnPropertySymbols(t)),
            e &&
              (n = n.filter(function (e) {
                return Object.getOwnPropertyDescriptor(t, e).enumerable;
              })),
            r.push.apply(r, n)),
          r
        );
      }
      function y(t) {
        for (var e = 1; e < arguments.length; e++) {
          var n = null != arguments[e] ? arguments[e] : {};
          e % 2
            ? p(Object(n), !0).forEach(function (e) {
                g(t, e, n[e]);
              })
            : Object.getOwnPropertyDescriptors
            ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n))
            : p(Object(n)).forEach(function (e) {
                Object.defineProperty(
                  t,
                  e,
                  Object.getOwnPropertyDescriptor(n, e)
                );
              });
        }
        return t;
      }
      function g(t, e, n) {
        (e = m(e)) in t
          ? Object.defineProperty(t, e, {
              value: n,
              enumerable: !0,
              configurable: !0,
              writable: !0,
            })
          : (t[e] = n);
      }
      function m(t) {
        return "symbol" === a((t = h(t, "string"))) ? t : String(t);
      }
      function h(t, e) {
        if ("object" !== a(t) || null === t) return t;
        var n = t[Symbol.toPrimitive];
        if (void 0 === n) return ("string" === e ? String : Number)(t);
        if ("object" !== a((n = n.call(t, e || "default")))) return n;
        throw new TypeError("@@toPrimitive must return a primitive value.");
      }
      function O(t) {
        Object(i.a)(t)
          .record("cxm/contextual/set")
          .catch(function () {});
      }
      function v(r, t, o, e) {
        var i = Date.now(),
          n = Object(u.a)(window.location, window.top.location, t);
        if (null !== n) {
          var a = {
            url: n,
            withCredentials: !0,
            onload: function t(e) {
              if (200 === e.status)
                try {
                  f.a.dispatch({
                    type: "RECORD_LIBRARY_LOAD_CALL_LATENCY",
                    latency: Date.now() - i,
                  });
                  var n = JSON.parse(e.response);
                  eval(n["3pvendor"]),
                    Object(b.a)(
                      f.a.getState().config.gdpr,
                      function (t) {
                        var e;
                        t &&
                          ((e = Object(b.c)(t.consent)), Object(d.b)()) &&
                          Object(b.d)(e, t.gdprApplies) &&
                          d.a.getDefault().localStorage.setItem(l.e, "1");
                      },
                      r
                    );
                } catch (t) {
                  Object(s.b)(t, "load3PLibraryConfig-onload");
                }
              null != o && o();
            },
            onerror: function (t) {
              (t = new Error(
                "".concat(t.type, ": ").concat(t.loaded, " bytes transferred")
              )),
                Object(s.b)(t, "load3PLibraryConfig-onerror"),
                null != e && e(t);
            },
          };
          try {
            Object(c.d)(a);
          } catch (t) {
            Object(s.b)(t, "load3PLibraryConfig"), null != e && e(t);
          }
        }
      }
      function j() {
        return (
          (Object(r.j)(window, "creativeVendorLibraryLoaded") &&
            !0 === window.creativeVendorLibraryLoaded) ||
          Object(r.j)(window, "confiant")
        );
      }
      function S() {
        var t = { renderTimes: {} };
        window.addEventListener("message", function (e) {
          Object(o.a)(t, e);
        });
      }
      function w(t) {
        var e = { ids: {} };
        try {
          if (
            !0 !== Object(i.a)(t).read("idVendors/newConfigFlowEnabled") &&
            "1" !== d.a.getDefault().localStorage.getItem(l.e)
          )
            return e;
          Object(i.a)(t)
            .record("idVendors/ids/get")
            .catch(function () {}),
            (e.ids = y({}, Object(i.a)(t).read("idVendors/ids")));
          var n = Object(i.a)(t).read("idVendors/metadata");
          n && (e.md = n);
        } catch (t) {
          Object(s.b)(t, "getIdentityConfig");
        }
        return e;
      }
    },
    function (t, e, n) {
      "use strict";
      n.d(e, "d", function () {
        return d;
      }),
        n.d(e, "c", function () {
          return b;
        }),
        n.d(e, "b", function () {
          return p;
        }),
        n.d(e, "g", function () {
          return h;
        }),
        n.d(e, "a", function () {
          return S;
        }),
        n.d(e, "e", function () {
          return w;
        }),
        n.d(e, "f", function () {
          return _;
        });
      var r = n(1),
        o = n(0),
        i = n(2),
        a = n(3),
        c = n(4);
      function s(t) {
        return (s =
          "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
            ? function (t) {
                return typeof t;
              }
            : function (t) {
                return t &&
                  "function" == typeof Symbol &&
                  t.constructor === Symbol &&
                  t !== Symbol.prototype
                  ? "symbol"
                  : typeof t;
              })(t);
      }
      function u(t, e) {
        for (var n = 0; n < e.length; n++) {
          var r = e[n];
          (r.enumerable = r.enumerable || !1),
            (r.configurable = !0),
            "value" in r && (r.writable = !0),
            Object.defineProperty(t, l(r.key), r);
        }
      }
      function l(t) {
        return (
          (t = (function (t, e) {
            if ("object" !== s(t) || null === t) return t;
            var n = t[Symbol.toPrimitive];
            if (void 0 === n) return String(t);
            if ("object" !== s((n = n.call(t, e)))) return n;
            throw new TypeError("@@toPrimitive must return a primitive value.");
          })(t, "string")),
          "symbol" === s(t) ? t : String(t)
        );
      }
      var f = (function () {
        function t() {
          var e,
            n =
              0 < arguments.length && void 0 !== arguments[0]
                ? arguments[0]
                : {},
            r = this,
            o = t;
          if (!(r instanceof o))
            throw new TypeError("Cannot call a class as a function");
          (r = this),
            (o = void 0),
            (e = l((e = "_rawProps"))) in r
              ? Object.defineProperty(r, e, {
                  value: o,
                  enumerable: !0,
                  configurable: !0,
                  writable: !0,
                })
              : (r[e] = o),
            (this._rawProps = n);
        }
        var e, n;
        return (
          (e = t),
          (n = [
            {
              key: "source",
              get: function () {
                return "web";
              },
            },
            {
              key: "omsdkAccessMode",
              get: function () {
                return "limited";
              },
            },
            {
              key: "publisherType",
              get: function () {
                var t = i.a.getState().config;
                return t && !0 === t.isSelfServePub
                  ? c.b.SELF_SERVE_WEB
                  : c.b.MANAGED_WEB;
              },
            },
            {
              key: "publisherUUID",
              get: function () {
                var t = i.a.getState().config;
                if (t) return t.pubID;
              },
            },
            {
              key: "integratorVersion",
              get: function () {
                return a.l;
              },
            },
            {
              key: "bidId",
              get: function () {
                var t = this._rawProps.bidId;
                if ("string" == typeof t) return t;
              },
            },
            {
              key: "dealId",
              get: function () {
                var t = this._rawProps.dealId;
                if ("string" == typeof t) return t;
              },
            },
            {
              key: "hostName",
              get: function () {
                var t = this._rawProps.hostName;
                if ("string" == typeof t) return t;
              },
            },
            {
              key: "pricePoint",
              get: function () {
                var t = this._rawProps.pricePoint;
                if ("string" == typeof t) return t;
              },
            },
            {
              key: "targetingMap",
              get: function () {
                var t = this._rawProps.targetingMap;
                if ("string" == typeof t) return t;
              },
            },
            {
              key: "adServerType",
              get: function () {
                var t = i.a.getState().config;
                if (t) return t.adServer;
              },
            },
            {
              key: "adServerAdUnitId",
              get: function () {
                var t = this._rawProps.adServerAdUnitId;
                if ("string" == typeof t) return t;
              },
            },
            {
              key: "apsAdUnitId",
              get: function () {
                var t = this._rawProps.apsAdUnitId;
                if ("string" == typeof t) return t;
              },
            },
            {
              key: "getProperties",
              value: function () {
                return JSON.stringify({
                  source: this.source,
                  omsdkAccessMode: this.omsdkAccessMode,
                  publisherType: this.publisherType,
                  publisherUUID: this.publisherUUID,
                  integratorVersion: this.integratorVersion,
                  bidId: this.bidId,
                  hostName: this.hostName,
                  dealId: this.dealId,
                  pricePoint: this.pricePoint,
                  targetingMap: this.targetingMap,
                  adServerType: this.adServerType,
                  adServerAdUnitId: this.adServerAdUnitId,
                  apsAdUnitId: this.apsAdUnitId,
                });
              },
            },
          ]) && u(e.prototype, n),
          Object.defineProperty(e, "prototype", { writable: !1 }),
          t
        );
      })();
      function d(t, e) {
        try {
          if (Object(o.j)(e, "slotID")) {
            var n = e.slotID,
              i = t.getElementById(n);
            if (i instanceof HTMLDivElement) return i;
          }
        } catch (t) {
          Object(r.b)(t, "getVideoDivElement-outstream");
        }
      }
      function b(t, e) {
        try {
          Object(o.j)(t, "bidID") && (e += "b=".concat(t.bidID)),
            Object(o.j)(t, "pp") &&
              void 0 === t.dealId &&
              (e += "&pp=".concat(t.pp)),
            (e += "&rnd=".concat(Object(o.c)()));
        } catch (t) {
          Object(r.b)(t, "constructVastTag");
        }
        return e;
      }
      function p(t, e, n, o) {
        try {
          var i = {
              bidId: null == n ? void 0 : n.bidID,
              hostName: null == n ? void 0 : n.host,
              dealId: null == n ? void 0 : n.dealId,
              pricePoint: null == n ? void 0 : n.pp,
              apsAdUnitId: null == n ? void 0 : n.slotID,
            },
            a = {
              key: "$$videoPlayerProps$$",
              value: new f(i).getProperties(),
            },
            c = { key: "$$apstagVastTag$$", value: t },
            s = {
              key: "$$apstagCompanionContainers$$",
              value: JSON.stringify(o || []),
            },
            u = e;
          return (
            [
              a,
              c,
              s,
              {
                key: "$$apsvidonerror$$",
                value:
                  "try { window.parent.apstag.re(new Error('video player load error'), 'vsdk-load-fail'); } catch(e) {}",
              },
            ].forEach(function (t) {
              var e = t.key;
              t = t.value;
              return (u = u.replace(e, t));
            }),
            u
          );
        } catch (t) {
          return Object(r.b)(t, "constructVastTag"), "";
        }
      }
      var y = {},
        g = function (t) {
          return (
            y[t] ||
              (y[t] = { started: !1, completed: !1, loaded: !1, isPaused: !1 }),
            y[t]
          );
        },
        m = { root: null, rootMargin: "0px", threshold: 0.5 };
      function h(t, e, n) {
        try {
          var o;
          window.addEventListener("message", function (t) {
            !(function (t, e) {
              if (
                t.origin === window.top.location.origin &&
                !0 === t.data.apsVideoPlayer
              )
                switch (t.data.event) {
                  case "completed":
                    g(e).completed = !0;
                    break;
                  case "loaded":
                    g(e).loaded = !0;
                }
            })(t, n);
          }),
            window.IntersectionObserver
              ? (o = new window.IntersectionObserver(function (r) {
                  r.forEach(function (r) {
                    0.5 < r.intersectionRatio &&
                      e.contentWindow &&
                      (O(e, t, n), o.disconnect());
                  });
                }, m)).observe(t)
              : Object(r.b)(
                  {
                    name: "IntersectionObserver",
                    message: "IntersectionObserver not supported ",
                  },
                  "startVideoAndHandlePlayback"
                );
        } catch (t) {
          Object(r.b)(t, "startVideoAndHandlePlayback");
        }
      }
      function O(t, e, n) {
        try {
          null !== t.contentDocument &&
          Object(o.g)(["complete", "interactive"], t.contentDocument.readyState)
            ? j(t, e, n)
            : null !== t.contentDocument &&
              "uninitialized" !== t.contentDocument.readyState
            ? t.contentDocument.addEventListener(
                "DOMContentLoaded",
                function () {
                  j(t, e, n);
                }
              )
            : t.addEventListener("load", function () {
                j(t, e, n);
              }),
            setTimeout(j, 1e3, !0);
        } catch (t) {
          Object(r.b)(t, "loadVideoAd");
        }
      }
      function v(t, e, n) {
        try {
          var o;
          window.IntersectionObserver &&
            (o = new window.IntersectionObserver(
              function (e) {
                e.forEach(function (e) {
                  g(n).completed && o.disconnect(),
                    e.intersectionRatio < 0.5 && !g(n).isPaused
                      ? t.contentWindow &&
                        t.contentWindow.adsM &&
                        (t.contentWindow.adsM.pause(), (g(n).isPaused = !0))
                      : g(n).isPaused &&
                        t.contentWindow &&
                        t.contentWindow.adsM &&
                        (t.contentWindow.adsM.play(), (g(n).isPaused = !1));
                });
              },
              { threshold: 0.5 }
            )).observe(e);
        } catch (e) {
          Object(r.b)(e, "handleAutoPauseAndPlay");
        }
      }
      function j(t, e, n) {
        t.contentWindow &&
          !g(n).started &&
          ((g(n).started = !0),
          (function (t, e, n) {
            var r = Number(new Date()) + (e || 2e3);
            return (
              (n = n || 100),
              new Promise(function e(o, i) {
                var a = t();
                a
                  ? o(a)
                  : Number(new Date()) < r
                  ? setTimeout(e, n, o, i)
                  : i(new Error("apsVideoPlayer timed out"));
              })
            );
          })(
            function () {
              return g(n).loaded;
            },
            3e4,
            100
          )
            .then(function () {
              t.contentWindow &&
                t.contentWindow.adsM &&
                (t.contentWindow.adsM.play(), v(t, e, n));
            })
            .catch(function () {
              v(t, e, n),
                Object(r.b)(
                  {
                    name: "VideoPlayerTimeout",
                    message: "video player took more than 30 seconds to load",
                  },
                  "startAd"
                );
            }));
      }
      function S(t, e) {
        try {
          e && e.appendChild(t);
        } catch (t) {
          Object(r.b)(t, "_appendDivElement");
        }
      }
      function w(t, e) {
        try {
          t.appendChild(e);
        } catch (t) {
          Object(r.b)(t, "_insertVideoIframeInsideDiv");
        }
      }
      function _(t) {
        var e = document.createElement("div");
        return (
          (e.style.width = "".concat(t[0], "px")),
          (e.style.height = "".concat(t[1], "px")),
          (e.style.margin = "0 auto"),
          (e.id = "apsVideoDiv-".concat(Object(o.c)())),
          e
        );
      }
    },
    function (t, e, n) {
      "use strict";
      n.d(e, "a", function () {
        return u;
      });
      var r = n(0),
        o = n(1);
      function i(t) {
        return (i =
          "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
            ? function (t) {
                return typeof t;
              }
            : function (t) {
                return t &&
                  "function" == typeof Symbol &&
                  t.constructor === Symbol &&
                  t !== Symbol.prototype
                  ? "symbol"
                  : typeof t;
              })(t);
      }
      function a(t, e) {
        for (var n = 0; n < e.length; n++) {
          var r = e[n];
          (r.enumerable = r.enumerable || !1),
            (r.configurable = !0),
            "value" in r && (r.writable = !0),
            Object.defineProperty(t, s(r.key), r);
        }
      }
      function c(t, e, n) {
        (e = s(e)) in t
          ? Object.defineProperty(t, e, {
              value: n,
              enumerable: !0,
              configurable: !0,
              writable: !0,
            })
          : (t[e] = n);
      }
      function s(t) {
        return (
          (t = (function (t, e) {
            if ("object" !== i(t) || null === t) return t;
            var n = t[Symbol.toPrimitive];
            if (void 0 === n) return String(t);
            if ("object" !== i((n = n.call(t, e)))) return n;
            throw new TypeError("@@toPrimitive must return a primitive value.");
          })(t, "string")),
          "symbol" === i(t) ? t : String(t)
        );
      }
      var u = (function () {
        function t(e) {
          var n =
              !(1 < arguments.length && void 0 !== arguments[1]) ||
              arguments[1],
            r = 2 < arguments.length && void 0 !== arguments[2] && arguments[2],
            o = this,
            i = t;
          if (!(o instanceof i))
            throw new TypeError("Cannot call a class as a function");
          c(this, "validSizeStringRegex", /^[0-9]+x[0-9]+$/),
            c(this, "numberStringRegex", /^[0-9]+$/),
            c(this, "_sizes", void 0),
            c(this, "_permit1D", !0),
            c(this, "_allowUndefined", !1),
            (this._sizes = e),
            (this._permit1D = n),
            (this._allowUndefined = r);
        }
        var e, n;
        return (
          (e = t),
          (n = [
            {
              key: "isValid",
              value: function () {
                return (
                  !(void 0 !== this._sizes || !this._allowUndefined) ||
                  0 < this.sizes.length
                );
              },
            },
            {
              key: "sizes",
              get: function () {
                var t = this;
                try {
                  var e = [];
                  if (Object(r.h)(this._sizes)) {
                    this._sizes = this._sizes.filter(function (t) {
                      return "fluid" !== t;
                    });
                    var n = "2d",
                      i = this._sizes;
                    if (
                      i &&
                      0 < i.length &&
                      !Object(r.h)(i[0]) &&
                      ("string" != typeof i[0] ||
                        !this.validSizeStringRegex.test(i[0]))
                    ) {
                      if (!this._permit1D)
                        throw new Error("Sizes must be 2d array");
                      (n = "1d"), (i = [i]);
                    }
                    e = i
                      .filter(function (e) {
                        return t.isValidSize(n, e);
                      })
                      .map(function (t) {
                        return Object(r.h)(t)
                          ? t
                          : t.split("x").map(function (t) {
                              return parseInt(t, 10);
                            });
                      });
                  }
                  return e;
                } catch (e) {
                  return Object(o.b)(e, "SizesDelegate-getSizes"), [];
                }
              },
            },
            {
              key: "aaxSizes",
              get: function () {
                if (void 0 !== this._sizes || !this._allowUndefined)
                  return this.sizes.filter(r.h).map(function (t) {
                    return t.join("x");
                  });
              },
            },
            {
              key: "isValidSize",
              value: function (t, e) {
                var n = this,
                  i = [];
                function a(t) {
                  (t = JSON.stringify(t)),
                    -1 === i.indexOf(t) &&
                      (i.push(t),
                      Object(o.b)(
                        {
                          name: "SizesDelegate-isValidSize-invalid",
                          message: "Invalid Slot Size: ".concat(
                            JSON.stringify(e)
                          ),
                        },
                        "SizesDelegate-isValidSize-invalid"
                      ));
                }
                try {
                  return (
                    !(
                      "string" != typeof e || !this.validSizeStringRegex.test(e)
                    ) ||
                    (Object(r.h)(e) && 1 !== e.length
                      ? (2 < e.length && a(e),
                        e.slice(0, 2).reduce(function (t, e) {
                          return (
                            t &&
                            !(
                              ("number" != typeof e && "string" != typeof e) ||
                              ("string" == typeof e &&
                                !n.numberStringRegex.test(e))
                            )
                          );
                        }, !0))
                      : (a(e), !1))
                  );
                } catch (t) {
                  return Object(o.b)(t, "isValidSize"), !0;
                }
              },
            },
          ]) && a(e.prototype, n),
          Object.defineProperty(e, "prototype", { writable: !1 }),
          t
        );
      })();
    },
    function (t, e, n) {
      "use strict";
      n.d(e, "a", function () {
        return b;
      });
      var r = n(0),
        o = ((e = n(13)), n(1)),
        i = n(19);
      function a(t) {
        return (a =
          "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
            ? function (t) {
                return typeof t;
              }
            : function (t) {
                return t &&
                  "function" == typeof Symbol &&
                  t.constructor === Symbol &&
                  t !== Symbol.prototype
                  ? "symbol"
                  : typeof t;
              })(t);
      }
      function c(t, e) {
        for (var n = 0; n < e.length; n++) {
          var r = e[n];
          (r.enumerable = r.enumerable || !1),
            (r.configurable = !0),
            "value" in r && (r.writable = !0),
            Object.defineProperty(t, d(r.key), r);
        }
      }
      function s(t, e) {
        return (s = Object.setPrototypeOf
          ? Object.setPrototypeOf.bind()
          : function (t, e) {
              return (t.__proto__ = e), t;
            })(t, e);
      }
      function u(t) {
        var e = (function () {
          if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
          if (Reflect.construct.sham) return !1;
          if ("function" == typeof Proxy) return !0;
          try {
            return (
              Boolean.prototype.valueOf.call(
                Reflect.construct(Boolean, [], function () {})
              ),
              !0
            );
          } catch (t) {
            return !1;
          }
        })();
        return function () {
          var n,
            r = f(t);
          (n = e
            ? ((n = f(this).constructor), Reflect.construct(r, arguments, n))
            : r.apply(this, arguments)),
            (r = this);
          if (n && ("object" === a(n) || "function" == typeof n)) return n;
          if (void 0 !== n)
            throw new TypeError(
              "Derived constructors may only return object or undefined"
            );
          return l(r);
        };
      }
      function l(t) {
        if (void 0 === t)
          throw new ReferenceError(
            "this hasn't been initialised - super() hasn't been called"
          );
        return t;
      }
      function f(t) {
        return (f = Object.setPrototypeOf
          ? Object.getPrototypeOf.bind()
          : function (t) {
              return t.__proto__ || Object.getPrototypeOf(t);
            })(t);
      }
      function d(t) {
        return (
          (t = (function (t, e) {
            if ("object" !== a(t) || null === t) return t;
            var n = t[Symbol.toPrimitive];
            if (void 0 === n) return String(t);
            if ("object" !== a((n = n.call(t, e)))) return n;
            throw new TypeError("@@toPrimitive must return a primitive value.");
          })(t, "string")),
          "symbol" === a(t) ? t : String(t)
        );
      }
      var b = (function (t) {
        var e = a;
        if ("function" != typeof t && null !== t)
          throw new TypeError(
            "Super expression must either be null or a function"
          );
        (e.prototype = Object.create(t && t.prototype, {
          constructor: { value: e, writable: !0, configurable: !0 },
        })),
          Object.defineProperty(e, "prototype", { writable: !1 }),
          t && s(e, t);
        var n = u(a);
        function a() {
          var t = this,
            e = a;
          if (!(t instanceof e))
            throw new TypeError("Cannot call a class as a function");
          for (
            var r, o, i = arguments.length, c = new Array(i), s = 0;
            s < i;
            s++
          )
            c[s] = arguments[s];
          return (
            (e = l((t = n.call.apply(n, [this].concat(c))))),
            (o = !0),
            (r = d((r = "isSupported"))) in e
              ? Object.defineProperty(e, r, {
                  value: o,
                  enumerable: !0,
                  configurable: !0,
                  writable: !0,
                })
              : (e[r] = o),
            t
          );
        }
        return (
          (e = a),
          (t = [
            {
              key: "reportError",
              value: function (t, e) {
                Object(o.b)(t, "GoogletagAdServer-".concat(e));
              },
            },
            {
              key: "cmdQueuePush",
              value: function (t) {
                try {
                  window.googletag.cmd.push(t);
                } catch (t) {
                  this.reportError(t, "cmdQueuePush");
                }
              },
            },
            {
              key: "slotRenderEndedEvent",
              value: function (t) {
                try {
                  window.googletag
                    .pubads()
                    .addEventListener("slotRenderEnded", function (e) {
                      (e = new i.a(e.slot)), t(e);
                    });
                } catch (t) {
                  this.reportError(t, "slotRenderEndedEvent");
                }
              },
            },
            {
              key: "setTargeting",
              value: function (t, e) {
                try {
                  window.googletag.pubads().setTargeting(t, e);
                } catch (t) {
                  this.reportError(t, "setTargeting");
                }
              },
            },
            {
              key: "getTargeting",
              value: function (t) {
                try {
                  var e,
                    n,
                    r = window.googletag;
                  return "function" == typeof r.getConfig
                    ? ((n = (e = r.getConfig("targeting")) && e.targeting) &&
                        n[t]) ||
                        []
                    : r.pubads().getTargeting(t) || [];
                } catch (t) {
                  return this.reportError(t, "getTargeting"), [];
                }
              },
            },
            {
              key: "clearTargeting",
              value: function (t) {
                try {
                  window.googletag.pubads().clearTargeting(t);
                } catch (t) {
                  this.reportError(t, "clearTargeting");
                }
              },
            },
            {
              key: "hasAdServerObjectLoaded",
              value: function () {
                try {
                  return (
                    Object(r.j)(window, "googletag") &&
                    Object(r.j)(window.googletag, "apiReady") &&
                    !0 === window.googletag.apiReady
                  );
                } catch (t) {
                  return this.reportError(t, "hasAdServerObjectLoaded"), !1;
                }
              },
            },
            {
              key: "isCommandQueueDefined",
              value: function () {
                try {
                  return (
                    Object(r.j)(window, "googletag") &&
                    Object(r.j)(window.googletag, "cmd")
                  );
                } catch (t) {
                  return this.reportError(t, "isCommandQueueDefined"), !1;
                }
              },
            },
            {
              key: "getSlots",
              value: function () {
                try {
                  return window.googletag
                    .pubads()
                    .getSlots()
                    .map(function (t) {
                      return new i.a(t);
                    });
                } catch (t) {
                  return this.reportError(t, "getSlots"), [];
                }
              },
            },
          ]) && c(e.prototype, t),
          Object.defineProperty(e, "prototype", { writable: !1 }),
          a
        );
      })(e.a);
    },
    function (t, e, n) {
      "use strict";
      n.d(e, "c", function () {
        return i;
      }),
        n.d(e, "a", function () {
          return a;
        }),
        n.d(e, "b", function () {
          return c;
        });
      var r = n(1),
        o = n(0);
      function i(t) {
        try {
          return !(!Object(o.j)(t, "$sf") || !Object(o.j)(t.$sf, "ext"));
        } catch (t) {
          return Object(r.b)(t, "isSafeFrame"), !1;
        }
      }
      function a(t, e) {
        try {
          var n,
            o,
            i,
            a = e.innerWidth,
            c = e.innerHeight,
            s = parseInt(t[0], 10),
            u = parseInt(t[1], 10),
            l = s - a,
            f = u - c,
            d = e.sfAPI || (null == (n = e.$sf) ? void 0 : n.ext);
          !d ||
            (a === s && c === u) ||
            (null != (o = d.register) && o.call(d, s, u),
            null != (i = d.expand) && i.call(d, { r: l, b: f, push: !0 }));
        } catch (t) {
          Object(r.b)(t, "expandSf");
        }
      }
      function c(t) {
        try {
          return 1 === t.innerWidth && 1 === t.innerHeight;
        } catch (t) {
          return Object(r.b)(t, "is1x1Creative"), !1;
        }
      }
    },
    function (t, e, n) {
      "use strict";
      n.d(e, "a", function () {
        return f;
      });
      var r = n(1);
      function o(t) {
        return (o =
          "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
            ? function (t) {
                return typeof t;
              }
            : function (t) {
                return t &&
                  "function" == typeof Symbol &&
                  t.constructor === Symbol &&
                  t !== Symbol.prototype
                  ? "symbol"
                  : typeof t;
              })(t);
      }
      function i(t, e) {
        for (var n = 0; n < e.length; n++) {
          var r = e[n];
          (r.enumerable = r.enumerable || !1),
            (r.configurable = !0),
            "value" in r && (r.writable = !0),
            Object.defineProperty(t, c(r.key), r);
        }
      }
      function a(t, e, n) {
        return (
          (e = c(e)) in t
            ? Object.defineProperty(t, e, {
                value: n,
                enumerable: !0,
                configurable: !0,
                writable: !0,
              })
            : (t[e] = n),
          t
        );
      }
      function c(t) {
        return (
          (t = (function (t, e) {
            if ("object" !== o(t) || null === t) return t;
            var n = t[Symbol.toPrimitive];
            if (void 0 === n) return String(t);
            if ("object" !== o((n = n.call(t, e)))) return n;
            throw new TypeError("@@toPrimitive must return a primitive value.");
          })(t, "string")),
          "symbol" === o(t) ? t : String(t)
        );
      }
      var s = "__tcfapi",
        u = "isListenedTo",
        l = "consentManagementPlatform",
        f = (function () {
          function t(e) {
            if (!(this instanceof t))
              throw new TypeError("Cannot call a class as a function");
            a(this, "store", void 0),
              a(this, "globalContext", void 0),
              (this.store = e.stateContainer),
              (this.globalContext = e.globalContext);
          }
          var e, n, o;
          return (
            (e = t),
            (o = [
              {
                key: "readStoredConsentData",
                value: function (t) {
                  return null == (t = t.getState()[l]) ? void 0 : t.tcData;
                },
              },
            ]),
            (n = [
              {
                key: "isListenerActive",
                get: function () {
                  return this.isListenedTo;
                },
              },
              {
                key: "isListenedTo",
                get: function () {
                  var t;
                  return (
                    (null == (t = this.store.getState()[l]) ? void 0 : t[u]) ||
                    !1
                  );
                },
                set: function (t) {
                  this.store.dispatch(
                    a({ type: "RECORD_CMP_LISTENED_TO" }, u, t)
                  );
                },
              },
              {
                key: "writeConsentDataToStore",
                value: function (t) {
                  this.store.dispatch(
                    a({ type: "RECORD_CMP_CONSENT_DATA" }, "tcData", t)
                  );
                },
              },
              {
                key: "onConsentDataChange",
                value: function (t, e, n) {
                  try {
                    e
                      ? ((this.isListenedTo = !0),
                        t && this.writeConsentDataToStore(t),
                        null != n && n(!0))
                      : null != n && n(!1);
                  } catch (t) {
                    Object(r.b)(
                      t,
                      "attemptConsentDataSync-onConsentDataChange"
                    );
                  }
                },
              },
              {
                key: "syncConsentData",
                value: function (t) {
                  var e = this;
                  this.globalContext[s]
                    ? this.globalContext[s](
                        "addEventListener",
                        2,
                        function (n, r) {
                          return e.onConsentDataChange(n, r, t);
                        }
                      )
                    : null != t && t(!1);
                },
              },
              {
                key: "syncConsentDataIfNotSynced",
                value: function (t) {
                  this.isListenedTo
                    ? null != t && t(!0)
                    : this.syncConsentData(t);
                },
              },
              {
                key: "attemptConsentDataSync",
                value: function (t) {
                  try {
                    this.syncConsentDataIfNotSynced(t);
                  } catch (e) {
                    Object(r.b)(e, "attemptConsentDataSync"),
                      null != t && t(!1);
                  }
                },
              },
            ]) && i(e.prototype, n),
            o && i(e, o),
            Object.defineProperty(e, "prototype", { writable: !1 }),
            t
          );
        })();
    },
    function (t, e, n) {
      "use strict";
      n.d(e, "a", function () {
        return j;
      }),
        n.d(e, "b", function () {
          return S;
        });
      var r = n(1),
        o = n(10),
        i = n(0),
        a = n(5),
        c = n(3),
        s = n(8),
        u = n(7),
        l = n(2);
      function f(t) {
        return (f =
          "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
            ? function (t) {
                return typeof t;
              }
            : function (t) {
                return t &&
                  "function" == typeof Symbol &&
                  t.constructor === Symbol &&
                  t !== Symbol.prototype
                  ? "symbol"
                  : typeof t;
              })(t);
      }
      function d() {
        /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ d =
          function () {
            return t;
          };
        var t = {},
          e = Object.prototype,
          n = e.hasOwnProperty,
          r =
            Object.defineProperty ||
            function (t, e, n) {
              t[e] = n.value;
            },
          o =
            (g = "function" == typeof Symbol ? Symbol : {}).iterator ||
            "@@iterator",
          i = g.asyncIterator || "@@asyncIterator",
          a = g.toStringTag || "@@toStringTag";
        function c(t, e, n) {
          return (
            Object.defineProperty(t, e, {
              value: n,
              enumerable: !0,
              configurable: !0,
              writable: !0,
            }),
            t[e]
          );
        }
        try {
          c({}, "");
        } catch (e) {
          c = function (t, e, n) {
            return (t[e] = n);
          };
        }
        function s(t, e, n, o) {
          var i, a, c, s;
          (e = e && e.prototype instanceof b ? e : b),
            (e = Object.create(e.prototype)),
            (o = new w(o || []));
          return (
            r(e, "_invoke", {
              value:
                ((i = t),
                (a = n),
                (c = o),
                (s = "suspendedStart"),
                function (t, e) {
                  if ("executing" === s)
                    throw new Error("Generator is already running");
                  if ("completed" === s) {
                    if ("throw" === t) throw e;
                    return { value: void 0, done: !0 };
                  }
                  for (c.method = t, c.arg = e; ; ) {
                    var n = c.delegate;
                    if (
                      n &&
                      (n = (function t(e, n) {
                        var r = n.method,
                          o = e.iterator[r];
                        return void 0 === o
                          ? ((n.delegate = null),
                            ("throw" === r &&
                              e.iterator.return &&
                              ((n.method = "return"),
                              (n.arg = void 0),
                              t(e, n),
                              "throw" === n.method)) ||
                              ("return" !== r &&
                                ((n.method = "throw"),
                                (n.arg = new TypeError(
                                  "The iterator does not provide a '" +
                                    r +
                                    "' method"
                                )))),
                            l)
                          : "throw" === (r = u(o, e.iterator, n.arg)).type
                          ? ((n.method = "throw"),
                            (n.arg = r.arg),
                            (n.delegate = null),
                            l)
                          : (o = r.arg)
                          ? o.done
                            ? ((n[e.resultName] = o.value),
                              (n.next = e.nextLoc),
                              "return" !== n.method &&
                                ((n.method = "next"), (n.arg = void 0)),
                              (n.delegate = null),
                              l)
                            : o
                          : ((n.method = "throw"),
                            (n.arg = new TypeError(
                              "iterator result is not an object"
                            )),
                            (n.delegate = null),
                            l);
                      })(n, c))
                    ) {
                      if (n === l) continue;
                      return n;
                    }
                    if ("next" === c.method) c.sent = c._sent = c.arg;
                    else if ("throw" === c.method) {
                      if ("suspendedStart" === s)
                        throw ((s = "completed"), c.arg);
                      c.dispatchException(c.arg);
                    } else "return" === c.method && c.abrupt("return", c.arg);
                    if (
                      ((s = "executing"), "normal" === (n = u(i, a, c)).type)
                    ) {
                      if (
                        ((s = c.done ? "completed" : "suspendedYield"),
                        n.arg === l)
                      )
                        continue;
                      return { value: n.arg, done: c.done };
                    }
                    "throw" === n.type &&
                      ((s = "completed"),
                      (c.method = "throw"),
                      (c.arg = n.arg));
                  }
                }),
            }),
            e
          );
        }
        function u(t, e, n) {
          try {
            return { type: "normal", arg: t.call(e, n) };
          } catch (t) {
            return { type: "throw", arg: t };
          }
        }
        t.wrap = s;
        var l = {};
        function b() {}
        function p() {}
        function y() {}
        var g,
          m,
          h =
            ((m =
              (m =
                (c((g = {}), o, function () {
                  return this;
                }),
                Object.getPrototypeOf)) && m(m(_([])))) &&
              m !== e &&
              n.call(m, o) &&
              (g = m),
            (y.prototype = b.prototype = Object.create(g)));
        function O(t) {
          ["next", "throw", "return"].forEach(function (e) {
            c(t, e, function (t) {
              return this._invoke(e, t);
            });
          });
        }
        function v(t, e) {
          var o;
          r(this, "_invoke", {
            value: function (r, i) {
              function a() {
                return new e(function (o, a) {
                  !(function r(o, i, a, c) {
                    var s;
                    if ("throw" !== (o = u(t[o], t, i)).type)
                      return (i = (s = o.arg).value) &&
                        "object" == f(i) &&
                        n.call(i, "__await")
                        ? e.resolve(i.__await).then(
                            function (t) {
                              r("next", t, a, c);
                            },
                            function (t) {
                              r("throw", t, a, c);
                            }
                          )
                        : e.resolve(i).then(
                            function (t) {
                              (s.value = t), a(s);
                            },
                            function (t) {
                              return r("throw", t, a, c);
                            }
                          );
                    c(o.arg);
                  })(r, i, o, a);
                });
              }
              return (o = o ? o.then(a, a) : a());
            },
          });
        }
        function j(t) {
          var e = { tryLoc: t[0] };
          1 in t && (e.catchLoc = t[1]),
            2 in t && ((e.finallyLoc = t[2]), (e.afterLoc = t[3])),
            this.tryEntries.push(e);
        }
        function S(t) {
          var e = t.completion || {};
          (e.type = "normal"), delete e.arg, (t.completion = e);
        }
        function w(t) {
          (this.tryEntries = [{ tryLoc: "root" }]),
            t.forEach(j, this),
            this.reset(!0);
        }
        function _(t) {
          if (t) {
            var e,
              r = t[o];
            if (r) return r.call(t);
            if ("function" == typeof t.next) return t;
            if (!isNaN(t.length))
              return (
                (e = -1),
                ((r = function r() {
                  for (; ++e < t.length; )
                    if (n.call(t, e)) return (r.value = t[e]), (r.done = !1), r;
                  return (r.value = void 0), (r.done = !0), r;
                }).next = r)
              );
          }
          return { next: E };
        }
        function E() {
          return { value: void 0, done: !0 };
        }
        return (
          r(h, "constructor", { value: (p.prototype = y), configurable: !0 }),
          r(y, "constructor", { value: p, configurable: !0 }),
          (p.displayName = c(y, a, "GeneratorFunction")),
          (t.isGeneratorFunction = function (t) {
            return (
              !!(t = "function" == typeof t && t.constructor) &&
              (t === p || "GeneratorFunction" === (t.displayName || t.name))
            );
          }),
          (t.mark = function (t) {
            return (
              Object.setPrototypeOf
                ? Object.setPrototypeOf(t, y)
                : ((t.__proto__ = y), c(t, a, "GeneratorFunction")),
              (t.prototype = Object.create(h)),
              t
            );
          }),
          (t.awrap = function (t) {
            return { __await: t };
          }),
          O(v.prototype),
          c(v.prototype, i, function () {
            return this;
          }),
          (t.AsyncIterator = v),
          (t.async = function (e, n, r, o, i) {
            void 0 === i && (i = Promise);
            var a = new v(s(e, n, r, o), i);
            return t.isGeneratorFunction(n)
              ? a
              : a.next().then(function (t) {
                  return t.done ? t.value : a.next();
                });
          }),
          O(h),
          c(h, a, "Generator"),
          c(h, o, function () {
            return this;
          }),
          c(h, "toString", function () {
            return "[object Generator]";
          }),
          (t.keys = function (t) {
            var e,
              n = Object(t),
              r = [];
            for (e in n) r.push(e);
            return (
              r.reverse(),
              function t() {
                for (; r.length; ) {
                  var e = r.pop();
                  if (e in n) return (t.value = e), (t.done = !1), t;
                }
                return (t.done = !0), t;
              }
            );
          }),
          (t.values = _),
          (w.prototype = {
            constructor: w,
            reset: function (t) {
              if (
                ((this.prev = 0),
                (this.next = 0),
                (this.sent = this._sent = void 0),
                (this.done = !1),
                (this.delegate = null),
                (this.method = "next"),
                (this.arg = void 0),
                this.tryEntries.forEach(S),
                !t)
              )
                for (var e in this)
                  "t" === e.charAt(0) &&
                    n.call(this, e) &&
                    !isNaN(+e.slice(1)) &&
                    (this[e] = void 0);
            },
            stop: function () {
              this.done = !0;
              var t = this.tryEntries[0].completion;
              if ("throw" === t.type) throw t.arg;
              return this.rval;
            },
            dispatchException: function (t) {
              if (this.done) throw t;
              var e = this;
              function r(n, r) {
                return (
                  (a.type = "throw"),
                  (a.arg = t),
                  (e.next = n),
                  r && ((e.method = "next"), (e.arg = void 0)),
                  !!r
                );
              }
              for (var o = this.tryEntries.length - 1; 0 <= o; --o) {
                var i = this.tryEntries[o],
                  a = i.completion;
                if ("root" === i.tryLoc) return r("end");
                if (i.tryLoc <= this.prev) {
                  var c = n.call(i, "catchLoc"),
                    s = n.call(i, "finallyLoc");
                  if (c && s) {
                    if (this.prev < i.catchLoc) return r(i.catchLoc, !0);
                    if (this.prev < i.finallyLoc) return r(i.finallyLoc);
                  } else if (c) {
                    if (this.prev < i.catchLoc) return r(i.catchLoc, !0);
                  } else {
                    if (!s)
                      throw new Error("try statement without catch or finally");
                    if (this.prev < i.finallyLoc) return r(i.finallyLoc);
                  }
                }
              }
            },
            abrupt: function (t, e) {
              for (var r = this.tryEntries.length - 1; 0 <= r; --r) {
                var o = this.tryEntries[r];
                if (
                  o.tryLoc <= this.prev &&
                  n.call(o, "finallyLoc") &&
                  this.prev < o.finallyLoc
                ) {
                  var i = o;
                  break;
                }
              }
              var a = (i =
                i &&
                ("break" === t || "continue" === t) &&
                i.tryLoc <= e &&
                e <= i.finallyLoc
                  ? null
                  : i)
                ? i.completion
                : {};
              return (
                (a.type = t),
                (a.arg = e),
                i
                  ? ((this.method = "next"), (this.next = i.finallyLoc), l)
                  : this.complete(a)
              );
            },
            complete: function (t, e) {
              if ("throw" === t.type) throw t.arg;
              return (
                "break" === t.type || "continue" === t.type
                  ? (this.next = t.arg)
                  : "return" === t.type
                  ? ((this.rval = this.arg = t.arg),
                    (this.method = "return"),
                    (this.next = "end"))
                  : "normal" === t.type && e && (this.next = e),
                l
              );
            },
            finish: function (t) {
              for (var e = this.tryEntries.length - 1; 0 <= e; --e) {
                var n = this.tryEntries[e];
                if (n.finallyLoc === t)
                  return this.complete(n.completion, n.afterLoc), S(n), l;
              }
            },
            catch: function (t) {
              for (var e = this.tryEntries.length - 1; 0 <= e; --e) {
                var n,
                  r,
                  o = this.tryEntries[e];
                if (o.tryLoc === t)
                  return (
                    "throw" === (n = o.completion).type && ((r = n.arg), S(o)),
                    r
                  );
              }
              throw new Error("illegal catch attempt");
            },
            delegateYield: function (t, e, n) {
              return (
                (this.delegate = { iterator: _(t), resultName: e, nextLoc: n }),
                "next" === this.method && (this.arg = void 0),
                l
              );
            },
          }),
          t
        );
      }
      function b(t, e, n, r, o, i, a) {
        try {
          var c = t[i](a),
            s = c.value;
        } catch (t) {
          return void n(t);
        }
        c.done ? e(s) : Promise.resolve(s).then(r, o);
      }
      function p(t, e) {
        var n,
          r = Object.keys(t);
        return (
          Object.getOwnPropertySymbols &&
            ((n = Object.getOwnPropertySymbols(t)),
            e &&
              (n = n.filter(function (e) {
                return Object.getOwnPropertyDescriptor(t, e).enumerable;
              })),
            r.push.apply(r, n)),
          r
        );
      }
      function y(t) {
        for (var e = 1; e < arguments.length; e++) {
          var n = null != arguments[e] ? arguments[e] : {};
          e % 2
            ? p(Object(n), !0).forEach(function (e) {
                O(t, e, n[e]);
              })
            : Object.getOwnPropertyDescriptors
            ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n))
            : p(Object(n)).forEach(function (e) {
                Object.defineProperty(
                  t,
                  e,
                  Object.getOwnPropertyDescriptor(n, e)
                );
              });
        }
        return t;
      }
      function g(t, e) {
        if (!(t instanceof e))
          throw new TypeError("Cannot call a class as a function");
      }
      function m(t, e) {
        for (var n = 0; n < e.length; n++) {
          var r = e[n];
          (r.enumerable = r.enumerable || !1),
            (r.configurable = !0),
            "value" in r && (r.writable = !0),
            Object.defineProperty(t, v(r.key), r);
        }
      }
      function h(t, e, n) {
        e && m(t.prototype, e),
          n && m(t, n),
          Object.defineProperty(t, "prototype", { writable: !1 });
      }
      function O(t, e, n) {
        (e = v(e)) in t
          ? Object.defineProperty(t, e, {
              value: n,
              enumerable: !0,
              configurable: !0,
              writable: !0,
            })
          : (t[e] = n);
      }
      function v(t) {
        return (
          (t = (function (t, e) {
            if ("object" !== f(t) || null === t) return t;
            var n = t[Symbol.toPrimitive];
            if (void 0 === n) return String(t);
            if ("object" !== f((n = n.call(t, e)))) return n;
            throw new TypeError("@@toPrimitive must return a primitive value.");
          })(t, "string")),
          "symbol" === f(t) ? t : String(t)
        );
      }
      function j(t) {
        try {
          var e = (function (t) {
            try {
              var e = Object(a.a)(t).read("ad/context");
              return Object(i.i)(e) ? { ortb2: e } : {};
            } catch (t) {
              return Object(r.b)(t, "getSignals"), {};
            }
          })(t);
          return 0 === Object.keys(e).length ? "" : Object(o.c)(e);
        } catch (t) {
          return Object(r.b)(t, "getSignalsParams"), "";
        }
      }
      function S() {
        P.get().log(E, "init");
        var t = window.apscustom || [];
        if (((window.apscustom = { push: T, loaded: !0 }), Array.isArray(t)))
          for (; t.length; ) T(t.shift());
      }
      var w = Object(u.c)("ASR_ENDPOINT_HOST", "c.aps.amazon-adsystem.com"),
        _ = Object(u.c)("ASR_ENDPOINT_IS", "86355855cc6ed9e335d0382c8563aa10"),
        E =
          ((e = (function () {
            function t() {
              g(this, t),
                O(this, "ignoreKeys", [
                  "apsCustomSlotname",
                  "apsCustomProgram",
                ]),
                O(this, "programKey", "apscustom"),
                O(this, "dataParamPrefix", "apsCustom");
            }
            return (
              h(t, [
                {
                  key: "init",
                  value: function (t) {
                    var e,
                      n,
                      r,
                      o = this;
                    t &&
                      t.id &&
                      (n = document.getElementById(t.id)) &&
                      ((t._element = n),
                      (e = Object.assign({}, n.dataset)),
                      n.setAttribute("data-aps-custom-status", "read"),
                      (n = {
                        program: e.apsCustomProgram || this.programKey,
                        is: _,
                      }),
                      Object.keys(e)
                        .filter(function (t) {
                          return (
                            t.indexOf(o.dataParamPrefix) <= -1 ||
                            o.ignoreKeys.includes(t)
                          );
                        })
                        .forEach(function (t) {
                          return delete e[t];
                        }),
                      (r = {
                        slotID: t.id,
                        slotName: e.apsCustomSlotname || t.id,
                        sizes: [[999, 999]],
                      }),
                      this.fetchBidsAndRender(r, t, y(y({}, n), e)));
                  },
                },
                {
                  key: "fetchBidsAndRender",
                  value: function (t, e, n) {
                    var r = this;
                    ((t =
                      (P.get().log(E, "fetchBids/start"),
                      { slots: [t], params: n })).timeout =
                      null != (n = e.timeout) ? n : 6e4),
                      (t._endpointDomain = w),
                      window.apstag.fetchBids(t, function (t) {
                        P.get().log(E, "fetchBids/end"), r.renderBids(t, e);
                      });
                  },
                },
                {
                  key: "renderBids",
                  value: function (t, e) {
                    t.forEach(function (t) {
                      new I(e, t).render();
                    });
                  },
                },
              ]),
              t
            );
          })()),
          "customPlacements"),
        D = new e();
      function T(t) {
        P.get().log(E, "implementation/legacyPush", 0.01),
          (t = Object.assign({}, t)),
          D.init(t);
      }
      var I = (function () {
          function t(e, n) {
            var r = this;
            g(this, t),
              O(this, "slotProps", void 0),
              O(this, "rawResponse", void 0),
              O(this, "getPageStyles", function () {
                return (
                  0 < arguments.length && void 0 !== arguments[0]
                    ? arguments[0]
                    : ["p", "h1", "h2"]
                )
                  .map(r.getTagStyle)
                  .filter(function (t) {
                    return 0 < Object.keys(t).length;
                  })
                  .reduce(function (t, e) {
                    return y(y({}, t), e);
                  }, {});
              }),
              O(this, "getContainerStyles", function (t) {
                try {
                  var e, n, r;
                  return t
                    ? ((e = window.getComputedStyle(t)),
                      (n = "--aps-custom-container-"),
                      (r = new Map()).set("".concat(n, "width"), e.width),
                      r.set("".concat(n, "margin"), e.margin),
                      r.set("".concat(n, "padding"), e.padding),
                      Object.fromEntries(r.entries()))
                    : {};
                } catch (t) {
                  return {};
                }
              }),
              (this.slotProps = e),
              (this.rawResponse = n);
          }
          return (
            h(t, [
              {
                key: "getTagStyle",
                value: function (t) {
                  var e,
                    n,
                    r = document.getElementsByTagName(t);
                  return r && r[0]
                    ? ((r = window.getComputedStyle(
                        document.getElementsByTagName(t)[0]
                      )),
                      (e = new Map()).set(
                        ""
                          .concat((n = "--aps-custom-page-"))
                          .concat(t, "-color"),
                        r.color
                      ),
                      e.set(
                        "".concat(n).concat(t, "-fontFamily"),
                        r.fontFamily
                      ),
                      e.set("".concat(n).concat(t, "-fontSize"), r.fontSize),
                      e.set(
                        "".concat(n).concat(t, "-fontWeight"),
                        r.fontWeight
                      ),
                      e.set(
                        "".concat(n).concat(t, "-lineHeight"),
                        r.lineHeight
                      ),
                      Object.fromEntries(e))
                    : {};
                },
              },
              {
                key: "getDynamicFrameBodyHeight",
                value: function (t, e, n) {
                  if (e) {
                    P.get().log(
                      E,
                      "render/"
                        .concat(n, "/")
                        .concat(this.slotProps.id, "/loaded")
                    );
                    var r =
                        (null == e ? void 0 : e.contentDocument) ||
                        (null == e || null == (o = e.contentWindow)
                          ? void 0
                          : o.document),
                      o = null == r ? void 0 : r.body.scrollHeight;
                    e.style.height = "".concat(o, "px");
                    try {
                      var i = y(
                        y({}, this.getPageStyles()),
                        this.getContainerStyles(t)
                      );
                      Object.keys(i).forEach(function (t) {
                        null != r &&
                          r.documentElement.style.setProperty(t, i[t]);
                      }),
                        P.get().trackEvent(E, "renderComplete", {
                          asrEndpoint: w,
                          height: o,
                          source: n,
                        });
                    } catch (t) {}
                  }
                },
              },
              {
                key: "render",
                value: function () {
                  return this._renderInIframe();
                },
              },
              {
                key: "_renderInIframe",
                value: function () {
                  var t = this;
                  if (!this.rawResponse || !this.slotProps) return !1;
                  try {
                    var e,
                      n,
                      o = this.rawResponse.size.split("x"),
                      i =
                        (null == (e = this.rawResponse.targeting)
                          ? void 0
                          : e.amzniid) || this.rawResponse.amzniid,
                      a =
                        (null == (n = this.rawResponse.targeting)
                          ? void 0
                          : n.amznadm) || this.rawResponse.amznadm;
                    if (!i) return !1;
                    P.get().log(
                      E,
                      "render/".concat(this.slotProps.id, "/start")
                    );
                    var c,
                      s,
                      u,
                      l,
                      f = this.slotProps._element;
                    return (
                      this.slotProps.location &&
                        this.slotProps.id &&
                        ((s = document.createElement("div")),
                        null !=
                          (c = document.getElementById(this.slotProps.id)) &&
                          c.insertAdjacentElement(this.slotProps.location, s),
                        (f = s)),
                      !!f &&
                        (((u =
                          document.createElement("iframe")).style.marginLeft =
                          "0"),
                        (u.style.marginTop = "0"),
                        (u.style.height = "".concat(o[1], "px")),
                        (u.style.width = "100%"),
                        u.setAttribute("scrolling", "no"),
                        u.setAttribute("frameborder", "0"),
                        (u.onload = function () {
                          return t.getDynamicFrameBodyHeight(
                            f,
                            u,
                            a ? "amznadm" : "admi"
                          );
                        }),
                        (l =
                          '\n      <!DOCTYPE html>\n      <html>\n        <head>\n          <meta charset="UTF-8">\n          <style>html{height:100%}body{height:100%;margin:0;overflow:hidden}</style>\n        </head>\n        <body>\n          <script>\n            window.parent.apstag.renderImp(document, "'.concat(
                            i,
                            '", {"inheritSize": true});\n          </script>\n        </body>\n      </html>'
                          )),
                        (u.srcdoc = a || l),
                        f.appendChild(u),
                        this.updateSlotAttribute("status", "rendered"),
                        !0)
                    );
                  } catch (t) {
                    return (
                      Object(r.b)(
                        new Error("Error while rendering"),
                        "CustomPlacements"
                      ),
                      !1
                    );
                  }
                },
              },
              {
                key: "updateSlotAttribute",
                value: function (t, e) {
                  var n;
                  null != (n = this.slotProps._element) &&
                    n.setAttribute("data-aps-custom-".concat(t), e);
                },
              },
            ]),
            t
          );
        })(),
        P = (function () {
          function t() {
            var e = this,
              n =
                (g(this, t),
                O(
                  this,
                  "TAHOE_PROD",
                  "04a6c6a40ec6c493437745b4ff085efb826e05c276ad857733462915bc4c35e0"
                ),
                O(
                  this,
                  "TAHOE_PROD_URL",
                  "https://prod.tahoe-analytics.publishers.advertising.a2z.com/logevent/postEquinoxEvent"
                ),
                O(this, "level", Object(u.c)("APS_ANALYTICS_LEVEL", "TAHOE")),
                O(this, "config", void 0),
                O(this, "timings", void 0),
                O(this, "log", void 0),
                O(this, "setLevel", function (t) {
                  e.level = t;
                }),
                O(
                  this,
                  "trackEvent",
                  (function () {
                    n = d().mark(function n(r, o) {
                      var i,
                        a,
                        u = arguments;
                      return d().wrap(function (n) {
                        for (;;)
                          switch ((n.prev = n.next)) {
                            case 0:
                              return (
                                (i =
                                  2 < u.length && void 0 !== u[2] ? u[2] : {}),
                                (a =
                                  3 < u.length && void 0 !== u[3]
                                    ? u[3]
                                    : t.getDefaultSamplingRate()),
                                n.abrupt(
                                  "return",
                                  new Promise(function (t) {
                                    try {
                                      var n, u;
                                      Math.random() > a
                                        ? t(!1)
                                        : ((n = y(
                                            {
                                              url: decodeURIComponent(
                                                Object(s.f)(window)
                                              ),
                                              libraryVersion: c.l,
                                              timings: e.timings,
                                            },
                                            e.getBrowserInfo()
                                          )),
                                          (u = JSON.stringify({
                                            eventSource: "apstag",
                                            eventCategory: r,
                                            eventName: o,
                                            eventTime: String(Date.now()),
                                            eventProperties: y(
                                              y(y({}, e.config), n),
                                              i
                                            ),
                                          })),
                                          "DEBUG" === e.level &&
                                            console.info(
                                              "<analytics> ",
                                              JSON.parse(u)
                                            ),
                                          "TAHOE" === e.level &&
                                            fetch(e.TAHOE_PROD_URL, {
                                              method: "POST",
                                              headers: {
                                                "Content-Type":
                                                  "application/json",
                                                "x-api-key": e.TAHOE_PROD,
                                              },
                                              body: JSON.stringify({
                                                Data: window.btoa(u),
                                                PartitionKey: String(
                                                  Date.now()
                                                ),
                                              }),
                                            }),
                                          t(!0));
                                    } catch (n) {
                                      t(!1);
                                    }
                                  })
                                )
                              );
                            case 3:
                            case "end":
                              return n.stop();
                          }
                      }, n);
                    });
                    var n,
                      r = function () {
                        var t = this,
                          e = arguments;
                        return new Promise(function (r, o) {
                          var i = n.apply(t, e);
                          function a(t) {
                            b(i, r, o, a, c, "next", t);
                          }
                          function c(t) {
                            b(i, r, o, a, c, "throw", t);
                          }
                          a(void 0);
                        });
                      };
                    return function (t, e) {
                      return r.apply(this, arguments);
                    };
                  })()
                ),
                l.a.getState());
            (this.config = n.config),
              (this.timings = []),
              (this.log = function (t, n, r) {
                try {
                  e.timings.push({
                    time: performance.now(),
                    key: "".concat(t, "/").concat(n),
                  }),
                    r && e.trackEvent(t, n, {}, r);
                } catch (t) {}
              });
          }
          return (
            h(
              t,
              [
                {
                  key: "getBrowserInfo",
                  value: function () {
                    try {
                      var t,
                        e = navigator.connection;
                      return {
                        connection: {
                          effectiveType: null == e ? void 0 : e.effectiveType,
                          rtt: null == e ? void 0 : e.rtt,
                          downlink: null == e ? void 0 : e.downlink,
                        },
                        screen: Object(i.f)(window),
                        userAgent:
                          null == (t = navigator) ? void 0 : t.userAgent,
                      };
                    } catch (t) {
                      return {};
                    }
                  },
                },
              ],
              [
                {
                  key: "get",
                  value: function () {
                    return (
                      null === this._analytics && (this._analytics = new t()),
                      this._analytics
                    );
                  },
                },
              ]
            ),
            t
          );
        })();
      O(P, "_analytics", null),
        O(P, "getDefaultSamplingRate", function () {
          var t = Object(u.c)("APS_ANALYTICS_RATE", 0.1);
          try {
            return Number(t);
          } catch (t) {
            return 0.1;
          }
        });
    },
    function (t, e, n) {
      "use strict";
      n.d(e, "a", function () {
        return L;
      });
      var r = n(13),
        o = n(0),
        i = n(1),
        a = ((e = n(14)), n(4));
      function c(t) {
        return (c =
          "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
            ? function (t) {
                return typeof t;
              }
            : function (t) {
                return t &&
                  "function" == typeof Symbol &&
                  t.constructor === Symbol &&
                  t !== Symbol.prototype
                  ? "symbol"
                  : typeof t;
              })(t);
      }
      function s(t, e) {
        var n,
          r = Object.keys(t);
        return (
          Object.getOwnPropertySymbols &&
            ((n = Object.getOwnPropertySymbols(t)),
            e &&
              (n = n.filter(function (e) {
                return Object.getOwnPropertyDescriptor(t, e).enumerable;
              })),
            r.push.apply(r, n)),
          r
        );
      }
      function u(t) {
        for (var e = 1; e < arguments.length; e++) {
          var n = null != arguments[e] ? arguments[e] : {};
          e % 2
            ? s(Object(n), !0).forEach(function (e) {
                g(t, e, n[e]);
              })
            : Object.getOwnPropertyDescriptors
            ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n))
            : s(Object(n)).forEach(function (e) {
                Object.defineProperty(
                  t,
                  e,
                  Object.getOwnPropertyDescriptor(n, e)
                );
              });
        }
        return t;
      }
      function l(t, e) {
        for (var n = 0; n < e.length; n++) {
          var r = e[n];
          (r.enumerable = r.enumerable || !1),
            (r.configurable = !0),
            "value" in r && (r.writable = !0),
            Object.defineProperty(t, m(r.key), r);
        }
      }
      function f() {
        return (f =
          "undefined" != typeof Reflect && Reflect.get
            ? Reflect.get.bind()
            : function (t, e, n) {
                var r = (function (t, e) {
                  for (
                    ;
                    !Object.prototype.hasOwnProperty.call(t, e) &&
                    null !== (t = y(t));

                  );
                  return t;
                })(t, e);
                if (r)
                  return (r = Object.getOwnPropertyDescriptor(r, e)).get
                    ? r.get.call(arguments.length < 3 ? t : n)
                    : r.value;
              }).apply(this, arguments);
      }
      function d(t, e) {
        return (d = Object.setPrototypeOf
          ? Object.setPrototypeOf.bind()
          : function (t, e) {
              return (t.__proto__ = e), t;
            })(t, e);
      }
      function b(t) {
        var e = (function () {
          if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
          if (Reflect.construct.sham) return !1;
          if ("function" == typeof Proxy) return !0;
          try {
            return (
              Boolean.prototype.valueOf.call(
                Reflect.construct(Boolean, [], function () {})
              ),
              !0
            );
          } catch (t) {
            return !1;
          }
        })();
        return function () {
          var n,
            r = y(t);
          (n = e
            ? ((n = y(this).constructor), Reflect.construct(r, arguments, n))
            : r.apply(this, arguments)),
            (r = this);
          if (n && ("object" === c(n) || "function" == typeof n)) return n;
          if (void 0 !== n)
            throw new TypeError(
              "Derived constructors may only return object or undefined"
            );
          return p(r);
        };
      }
      function p(t) {
        if (void 0 === t)
          throw new ReferenceError(
            "this hasn't been initialised - super() hasn't been called"
          );
        return t;
      }
      function y(t) {
        return (y = Object.setPrototypeOf
          ? Object.getPrototypeOf.bind()
          : function (t) {
              return t.__proto__ || Object.getPrototypeOf(t);
            })(t);
      }
      function g(t, e, n) {
        (e = m(e)) in t
          ? Object.defineProperty(t, e, {
              value: n,
              enumerable: !0,
              configurable: !0,
              writable: !0,
            })
          : (t[e] = n);
      }
      function m(t) {
        return (
          (t = (function (t, e) {
            if ("object" !== c(t) || null === t) return t;
            var n = t[Symbol.toPrimitive];
            if (void 0 === n) return String(t);
            if ("object" !== c((n = n.call(t, e)))) return n;
            throw new TypeError("@@toPrimitive must return a primitive value.");
          })(t, "string")),
          "symbol" === c(t) ? t : String(t)
        );
      }
      var h = (function (t) {
        var e = r;
        if ("function" != typeof t && null !== t)
          throw new TypeError(
            "Super expression must either be null or a function"
          );
        (e.prototype = Object.create(t && t.prototype, {
          constructor: { value: e, writable: !0, configurable: !0 },
        })),
          Object.defineProperty(e, "prototype", { writable: !1 }),
          t && d(e, t);
        var n = b(r);
        function r(t) {
          var e;
          if (this instanceof r)
            return (
              (e = {
                slotID: t.targetId,
                slotName: Object(o.j)(t, "invCode")
                  ? t.invCode
                  : Object(o.j)(t, "tagId")
                  ? t.tagId
                  : t.targetId,
              }),
              g(p((e = n.call(this, e))), "rawSlot", void 0),
              (e.rawSlot = t),
              e
            );
          throw new TypeError("Cannot call a class as a function");
        }
        return (
          (e = r),
          (t = [
            {
              key: "mediaType",
              get: function () {
                return a.a.DISPLAY;
              },
            },
            {
              key: "sizes",
              get: function () {
                try {
                  return this.rawSlot.sizes;
                } catch (t) {
                  return this.reportError(t, "sizes"), [];
                }
              },
            },
            {
              key: "aaxSlot",
              get: function () {
                try {
                  var t = u(
                    u({}, f(y(r.prototype), "aaxSlot", this)),
                    {},
                    {
                      sd: this.slotID,
                      s: this.sizes.filter(o.h).map(function (t) {
                        return t.join("x");
                      }),
                    }
                  );
                  return (
                    this.slotID !== this.slotName && (t.sn = this.slotName), t
                  );
                } catch (t) {
                  return { sd: "", s: [], kv: {} };
                }
              },
            },
            {
              key: "reportError",
              value: function (t, e, n) {
                Object(i.b)(t, "ApnSlot-".concat(e), n);
              },
            },
            {
              key: "isValid",
              value: function () {
                return !(
                  !f(y(r.prototype), "isValid", this).call(this) ||
                  (0 === this.sizes.length &&
                    (this.reportIsValidMessages(
                      ["'sizes' must have at least 1 valid item"],
                      !0
                    ),
                    1))
                );
              },
            },
            {
              key: "initKeywords",
              value: function () {
                try {
                  Object(o.j)(this.rawSlot, "keywords") ||
                    (this.rawSlot.keywords = {});
                } catch (t) {
                  this.reportError(t, "initKeywords");
                }
              },
            },
            {
              key: "setTargeting",
              value: function (t, e) {
                try {
                  this.initKeywords(), (this.rawSlot.keywords[t] = e);
                } catch (t) {
                  this.reportError(t, "setTargeting");
                }
              },
            },
            {
              key: "getTargeting",
              value: function (t) {
                try {
                  return (
                    this.initKeywords(),
                    Object(o.j)(this.rawSlot.keywords, t)
                      ? [this.rawSlot.keywords[t]]
                      : []
                  );
                } catch (t) {
                  return this.reportError(t, "getTargeting"), [];
                }
              },
            },
            {
              key: "clearTargeting",
              value: function (t) {
                try {
                  this.initKeywords(), delete this.rawSlot.keywords[t];
                } catch (t) {
                  this.reportError(t, "clearTargeting");
                }
              },
            },
          ]) && l(e.prototype, t),
          Object.defineProperty(e, "prototype", { writable: !1 }),
          r
        );
      })(e.a);
      function O(t) {
        return (O =
          "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
            ? function (t) {
                return typeof t;
              }
            : function (t) {
                return t &&
                  "function" == typeof Symbol &&
                  t.constructor === Symbol &&
                  t !== Symbol.prototype
                  ? "symbol"
                  : typeof t;
              })(t);
      }
      function v(t, e) {
        for (var n = 0; n < e.length; n++) {
          var r = e[n];
          (r.enumerable = r.enumerable || !1),
            (r.configurable = !0),
            "value" in r && (r.writable = !0),
            Object.defineProperty(t, _(r.key), r);
        }
      }
      function j(t, e) {
        return (j = Object.setPrototypeOf
          ? Object.setPrototypeOf.bind()
          : function (t, e) {
              return (t.__proto__ = e), t;
            })(t, e);
      }
      function S(t) {
        if (void 0 === t)
          throw new ReferenceError(
            "this hasn't been initialised - super() hasn't been called"
          );
        return t;
      }
      function w(t) {
        return (w = Object.setPrototypeOf
          ? Object.getPrototypeOf.bind()
          : function (t) {
              return t.__proto__ || Object.getPrototypeOf(t);
            })(t);
      }
      function _(t) {
        return (
          (t = (function (t, e) {
            if ("object" !== O(t) || null === t) return t;
            var n = t[Symbol.toPrimitive];
            if (void 0 === n) return String(t);
            if ("object" !== O((n = n.call(t, e)))) return n;
            throw new TypeError("@@toPrimitive must return a primitive value.");
          })(t, "string")),
          "symbol" === O(t) ? t : String(t)
        );
      }
      var E = (function (t) {
          var e = r;
          if ("function" != typeof t && null !== t)
            throw new TypeError(
              "Super expression must either be null or a function"
            );
          (e.prototype = Object.create(t && t.prototype, {
            constructor: { value: e, writable: !0, configurable: !0 },
          })),
            Object.defineProperty(e, "prototype", { writable: !1 }),
            t && j(e, t);
          var n = (function (t) {
            var e = (function () {
              if ("undefined" == typeof Reflect || !Reflect.construct)
                return !1;
              if (Reflect.construct.sham) return !1;
              if ("function" == typeof Proxy) return !0;
              try {
                return (
                  Boolean.prototype.valueOf.call(
                    Reflect.construct(Boolean, [], function () {})
                  ),
                  !0
                );
              } catch (t) {
                return !1;
              }
            })();
            return function () {
              var n,
                r = w(t);
              (n = e
                ? ((n = w(this).constructor),
                  Reflect.construct(r, arguments, n))
                : r.apply(this, arguments)),
                (r = this);
              if (n && ("object" === O(n) || "function" == typeof n)) return n;
              if (void 0 !== n)
                throw new TypeError(
                  "Derived constructors may only return object or undefined"
                );
              return S(r);
            };
          })(r);
          function r() {
            var t = this,
              e = r;
            if (!(t instanceof e))
              throw new TypeError("Cannot call a class as a function");
            for (
              var o, i, a = arguments.length, c = new Array(a), s = 0;
              s < a;
              s++
            )
              c[s] = arguments[s];
            return (
              (e = S((t = n.call.apply(n, [this].concat(c))))),
              (i = !0),
              (o = _((o = "isSupported"))) in e
                ? Object.defineProperty(e, o, {
                    value: i,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0,
                  })
                : (e[o] = i),
              t
            );
          }
          return (
            (e = r),
            (t = [
              {
                key: "reportError",
                value: function (t, e) {
                  Object(i.b)(t, "AppNexusAdServer-".concat(e));
                },
              },
              {
                key: "cmdQueuePush",
                value: function (t) {
                  try {
                    window.apntag.anq.push(t);
                  } catch (t) {
                    this.reportError(t, "cmdQueuePush");
                  }
                },
              },
              {
                key: "setTargeting",
                value: function (t, e) {
                  try {
                    Object(o.j)(window, "apntag") &&
                      Object(o.j)(window.apntag, "requests") &&
                      (Object(o.j)(window.apntag.requests, "keywords") ||
                        (window.apntag.requests.keywords = {}),
                      (window.apntag.requests.keywords[t] = e));
                  } catch (t) {
                    this.reportError(t, "setTargeting");
                  }
                },
              },
              {
                key: "getTargeting",
                value: function (t) {
                  try {
                    if (
                      !Object(o.j)(window, "apntag") ||
                      !Object(o.j)(window.apntag, "requests")
                    )
                      return [];
                    Object(o.j)(window.apntag.requests, "keywords") ||
                      (window.apntag.requests.keywords = {});
                    var e = window.apntag.requests.keywords[t];
                    return void 0 === e ? [] : [e];
                  } catch (t) {
                    return this.reportError(t, "getTargeting"), [];
                  }
                },
              },
              {
                key: "clearTargeting",
                value: function (t) {
                  try {
                    Object(o.j)(window, "apntag") &&
                      Object(o.j)(window.apntag, "requests") &&
                      Object(o.j)(window.apntag.requests, "keywords") &&
                      delete window.apntag.requests.keywords[t];
                  } catch (t) {
                    this.reportError(t, "clearTargeting");
                  }
                },
              },
              {
                key: "hasAdServerObjectLoaded",
                value: function () {
                  try {
                    return (
                      Object(o.j)(window, "apntag") &&
                      Object(o.j)(window.apntag, "loaded") &&
                      !0 === window.apntag.loaded
                    );
                  } catch (t) {
                    return this.reportError(t, "hasAdServerObjectLoaded"), !1;
                  }
                },
              },
              {
                key: "isCommandQueueDefined",
                value: function () {
                  try {
                    return (
                      Object(o.j)(window, "apntag") &&
                      Object(o.j)(window.apntag, "anq")
                    );
                  } catch (t) {
                    return this.reportError(t, "isCommandQueueDefined"), !1;
                  }
                },
              },
              {
                key: "getSlots",
                value: function () {
                  try {
                    var t = [];
                    return (
                      Object(o.j)(window, "apntag") &&
                        Object(o.j)(window.apntag, "requests") &&
                        Object(o.j)(window.apntag.requests, "tags") &&
                        Object(o.i)(window.apntag.requests.tags) &&
                        Object.keys(window.apntag.requests.tags).forEach(
                          function (e) {
                            (e = window.apntag.requests.tags[e]),
                              t.push(new h(e));
                          }
                        ),
                      t
                    );
                  } catch (t) {
                    return this.reportError(t, "getSlots"), [];
                  }
                },
              },
            ]) && v(e.prototype, t),
            Object.defineProperty(e, "prototype", { writable: !1 }),
            r
          );
        })(r.a),
        D = n(23);
      function T(t) {
        return (T =
          "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
            ? function (t) {
                return typeof t;
              }
            : function (t) {
                return t &&
                  "function" == typeof Symbol &&
                  t.constructor === Symbol &&
                  t !== Symbol.prototype
                  ? "symbol"
                  : typeof t;
              })(t);
      }
      function I(t, e) {
        for (var n = 0; n < e.length; n++) {
          var r = e[n];
          (r.enumerable = r.enumerable || !1),
            (r.configurable = !0),
            "value" in r && (r.writable = !0),
            Object.defineProperty(t, k(r.key), r);
        }
      }
      function P(t, e) {
        return (P = Object.setPrototypeOf
          ? Object.setPrototypeOf.bind()
          : function (t, e) {
              return (t.__proto__ = e), t;
            })(t, e);
      }
      function R(t) {
        if (void 0 === t)
          throw new ReferenceError(
            "this hasn't been initialised - super() hasn't been called"
          );
        return t;
      }
      function A(t) {
        return (A = Object.setPrototypeOf
          ? Object.getPrototypeOf.bind()
          : function (t) {
              return t.__proto__ || Object.getPrototypeOf(t);
            })(t);
      }
      function C(t, e, n) {
        (e = k(e)) in t
          ? Object.defineProperty(t, e, {
              value: n,
              enumerable: !0,
              configurable: !0,
              writable: !0,
            })
          : (t[e] = n);
      }
      function k(t) {
        return (
          (t = (function (t, e) {
            if ("object" !== T(t) || null === t) return t;
            var n = t[Symbol.toPrimitive];
            if (void 0 === n) return String(t);
            if ("object" !== T((n = n.call(t, e)))) return n;
            throw new TypeError("@@toPrimitive must return a primitive value.");
          })(t, "string")),
          "symbol" === T(t) ? t : String(t)
        );
      }
      var z = (function (t) {
        var e = r;
        if ("function" != typeof t && null !== t)
          throw new TypeError(
            "Super expression must either be null or a function"
          );
        (e.prototype = Object.create(t && t.prototype, {
          constructor: { value: e, writable: !0, configurable: !0 },
        })),
          Object.defineProperty(e, "prototype", { writable: !1 }),
          t && P(e, t);
        var n = (function (t) {
          var e = (function () {
            if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
            if (Reflect.construct.sham) return !1;
            if ("function" == typeof Proxy) return !0;
            try {
              return (
                Boolean.prototype.valueOf.call(
                  Reflect.construct(Boolean, [], function () {})
                ),
                !0
              );
            } catch (t) {
              return !1;
            }
          })();
          return function () {
            var n,
              r = A(t);
            (n = e
              ? ((n = A(this).constructor), Reflect.construct(r, arguments, n))
              : r.apply(this, arguments)),
              (r = this);
            if (n && ("object" === T(n) || "function" == typeof n)) return n;
            if (void 0 !== n)
              throw new TypeError(
                "Derived constructors may only return object or undefined"
              );
            return R(r);
          };
        })(r);
        function r() {
          var t = this,
            e = r;
          if (!(t instanceof e))
            throw new TypeError("Cannot call a class as a function");
          for (var o = arguments.length, i = new Array(o), a = 0; a < o; a++)
            i[a] = arguments[a];
          return (
            C(R((t = n.call.apply(n, [this].concat(i)))), "isSupported", !0),
            C(R(t), "needNewBidObject", !0),
            t
          );
        }
        return (
          (e = r),
          (t = [
            {
              key: "reportError",
              value: function (t, e) {
                Object(i.b)(t, "SmartAdServer-".concat(e));
              },
            },
            {
              key: "cmdQueuePush",
              value: function (t) {
                try {
                  window.sas.cmd.push(t);
                } catch (t) {
                  this.reportError(t, "cmdQueuePush");
                }
              },
            },
            {
              key: "hasAdServerObjectLoaded",
              value: function () {
                try {
                  return (
                    Object(o.j)(window, "sas") &&
                    Object(o.j)(window.sas, "__smartLoaded") &&
                    !0 === window.sas.__smartLoaded
                  );
                } catch (t) {
                  return this.reportError(t, "hasAdServerObjectLoaded"), !1;
                }
              },
            },
            {
              key: "isCommandQueueDefined",
              value: function () {
                try {
                  return (
                    Object(o.j)(window, "sas") && Object(o.j)(window.sas, "cmd")
                  );
                } catch (t) {
                  return this.reportError(t, "isCommandQueueDefined"), !1;
                }
              },
            },
          ]) && I(e.prototype, t),
          Object.defineProperty(e, "prototype", { writable: !1 }),
          r
        );
      })(r.a);
      function L(t) {
        var e = new r.a();
        try {
          switch (t) {
            case "appnexus":
              e = new E();
              break;
            case "googletag":
              e = new D.a();
              break;
            case "sas":
              e = new z();
          }
        } catch (t) {
          Object(i.b)(t, "getDisplayAdServer");
        }
        return e;
      }
    },
    function (t, e, n) {
      "use strict";
      function r(t, e) {
        try {
          var n = o(t, e)[0];
          if (void 0 !== n) return n;
        } catch (t) {}
        return null;
      }
      function o(t, e) {
        try {
          return t.performance
            .getEntriesByType("resource")
            .filter(function (t) {
              return e.test(t.name);
            });
        } catch (t) {
          return [];
        }
      }
      n.d(e, "b", function () {
        return r;
      }),
        n.d(e, "a", function () {
          return o;
        });
    },
    function (t, e, n) {
      "use strict";
      n.d(e, "b", function () {
        return a;
      }),
        n.d(e, "a", function () {
          return c;
        });
      var r = n(3),
        o = n(0),
        i = n(1);
      function a(t) {
        try {
          return Object(o.j)(t, "debug");
        } catch (t) {
          return Object(i.b)(t, "isApstagLibrary"), !1;
        }
      }
      function c(t) {
        try {
          return !!Object(o.j)(t, r.a) && !0 === t[r.a];
        } catch (t) {
          return Object(i.b)(t, "hasApstagJsLoaded"), !1;
        }
      }
    },
    function (t, e, n) {
      "use strict";
      n.d(e, "a", function () {
        return y;
      });
      e = n(14);
      var r = n(22);
      function o(t) {
        return (o =
          "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
            ? function (t) {
                return typeof t;
              }
            : function (t) {
                return t &&
                  "function" == typeof Symbol &&
                  t.constructor === Symbol &&
                  t !== Symbol.prototype
                  ? "symbol"
                  : typeof t;
              })(t);
      }
      function i(t, e) {
        var n,
          r = Object.keys(t);
        return (
          Object.getOwnPropertySymbols &&
            ((n = Object.getOwnPropertySymbols(t)),
            e &&
              (n = n.filter(function (e) {
                return Object.getOwnPropertyDescriptor(t, e).enumerable;
              })),
            r.push.apply(r, n)),
          r
        );
      }
      function a(t) {
        for (var e = 1; e < arguments.length; e++) {
          var n = null != arguments[e] ? arguments[e] : {};
          e % 2
            ? i(Object(n), !0).forEach(function (e) {
                b(t, e, n[e]);
              })
            : Object.getOwnPropertyDescriptors
            ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n))
            : i(Object(n)).forEach(function (e) {
                Object.defineProperty(
                  t,
                  e,
                  Object.getOwnPropertyDescriptor(n, e)
                );
              });
        }
        return t;
      }
      function c(t, e) {
        for (var n = 0; n < e.length; n++) {
          var r = e[n];
          (r.enumerable = r.enumerable || !1),
            (r.configurable = !0),
            "value" in r && (r.writable = !0),
            Object.defineProperty(t, p(r.key), r);
        }
      }
      function s() {
        return (s =
          "undefined" != typeof Reflect && Reflect.get
            ? Reflect.get.bind()
            : function (t, e, n) {
                var r = (function (t, e) {
                  for (
                    ;
                    !Object.prototype.hasOwnProperty.call(t, e) &&
                    null !== (t = d(t));

                  );
                  return t;
                })(t, e);
                if (r)
                  return (r = Object.getOwnPropertyDescriptor(r, e)).get
                    ? r.get.call(arguments.length < 3 ? t : n)
                    : r.value;
              }).apply(this, arguments);
      }
      function u(t, e) {
        return (u = Object.setPrototypeOf
          ? Object.setPrototypeOf.bind()
          : function (t, e) {
              return (t.__proto__ = e), t;
            })(t, e);
      }
      function l(t) {
        var e = (function () {
          if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
          if (Reflect.construct.sham) return !1;
          if ("function" == typeof Proxy) return !0;
          try {
            return (
              Boolean.prototype.valueOf.call(
                Reflect.construct(Boolean, [], function () {})
              ),
              !0
            );
          } catch (t) {
            return !1;
          }
        })();
        return function () {
          var n,
            r = d(t);
          (n = e
            ? ((n = d(this).constructor), Reflect.construct(r, arguments, n))
            : r.apply(this, arguments)),
            (r = this);
          if (n && ("object" === o(n) || "function" == typeof n)) return n;
          if (void 0 !== n)
            throw new TypeError(
              "Derived constructors may only return object or undefined"
            );
          return f(r);
        };
      }
      function f(t) {
        if (void 0 === t)
          throw new ReferenceError(
            "this hasn't been initialised - super() hasn't been called"
          );
        return t;
      }
      function d(t) {
        return (d = Object.setPrototypeOf
          ? Object.getPrototypeOf.bind()
          : function (t) {
              return t.__proto__ || Object.getPrototypeOf(t);
            })(t);
      }
      function b(t, e, n) {
        (e = p(e)) in t
          ? Object.defineProperty(t, e, {
              value: n,
              enumerable: !0,
              configurable: !0,
              writable: !0,
            })
          : (t[e] = n);
      }
      function p(t) {
        return (
          (t = (function (t, e) {
            if ("object" !== o(t) || null === t) return t;
            var n = t[Symbol.toPrimitive];
            if (void 0 === n) return String(t);
            if ("object" !== o((n = n.call(t, e)))) return n;
            throw new TypeError("@@toPrimitive must return a primitive value.");
          })(t, "string")),
          "symbol" === o(t) ? t : String(t)
        );
      }
      var y = (function (t) {
        var e = o;
        if ("function" != typeof t && null !== t)
          throw new TypeError(
            "Super expression must either be null or a function"
          );
        (e.prototype = Object.create(t && t.prototype, {
          constructor: { value: e, writable: !0, configurable: !0 },
        })),
          Object.defineProperty(e, "prototype", { writable: !1 }),
          t && u(e, t);
        var n = l(o);
        function o(t) {
          if (this instanceof o)
            return (
              b(f((t = n.call(this, t))), "_sizesDelegate", void 0),
              (t._sizesDelegate = new r.a(t.rawSlot.sizes)),
              t
            );
          throw new TypeError("Cannot call a class as a function");
        }
        return (
          (e = o),
          (t = [
            {
              key: "sizes",
              get: function () {
                return this._sizesDelegate.sizes;
              },
            },
            {
              key: "aaxSizes",
              get: function () {
                return this._sizesDelegate.aaxSizes || [];
              },
            },
            {
              key: "aaxSlot",
              get: function () {
                var t = { sd: this.slotID, s: this.aaxSizes };
                return (
                  this.slotID !== this.slotName && (t.sn = this.slotName),
                  a(a({}, t), s(d(o.prototype), "aaxSlot", this))
                );
              },
            },
            {
              key: "isValid",
              value: function () {
                return !(
                  !s(d(o.prototype), "isValid", this).call(this) ||
                  (0 === this.sizes.length &&
                    (this.reportIsValidMessages(
                      ["'sizes' must have at least 1 valid item"],
                      !0
                    ),
                    1))
                );
              },
            },
          ]) && c(e.prototype, t),
          Object.defineProperty(e, "prototype", { writable: !1 }),
          o
        );
      })(e.a);
    },
    function (t, e, n) {
      "use strict";
      n.d(e, "a", function () {
        return s;
      }),
        n.d(e, "b", function () {
          return c;
        });
      var r = n(2),
        o = n(1),
        i = n(0),
        a = n(10);
      function c(t) {
        try {
          var e = r.a.getState().cfg.COOKIE_MATCH_DELAY;
          setTimeout(function () {
            try {
              if (Object(i.j)(t, "cmp")) {
                var e = t.cmp;
                function n(t) {
                  try {
                    var e;
                    r.a.getState().cmpFired ||
                      (r.a.dispatch({ type: "CMP_FIRED" }),
                      ((e = document.createElement("iframe")).style.display =
                        "none"),
                      (e.src = t),
                      document.body.appendChild(e));
                  } catch (t) {
                    Object(o.b)(t, "_doCookieMatch-ready");
                  }
                }
                try {
                  "loading" === document.readyState
                    ? document.addEventListener &&
                      document.addEventListener(
                        "DOMContentLoaded",
                        function () {
                          n(e);
                        },
                        !1
                      )
                    : n(e);
                } catch (e) {
                  Object(o.b)(e, "_doCookieMatch");
                }
              } else Object(i.j)(t, "cmpjs") && Object(a.b)(t.cmpjs);
            } catch (e) {
              Object(o.b)(e, "_tryCookieMatch-setTimeout");
            }
          }, e);
        } catch (e) {
          Object(o.b)(e, "_tryCookieMatch");
        }
      }
      function s(t, e) {
        var n = e;
        return function () {
          var e = { method: t, args: arguments };
          try {
            (e.ts = Date.now()), r.a.dispatch({ type: "LOG_EVENT", event: e });
          } catch (e) {
            Object(o.b)(e, "_logEvent");
          }
          return n.apply(void 0, arguments);
        };
      }
    },
    function (t, e, n) {
      "use strict";
      n.d(e, "a", function () {
        return c;
      });
      var r = n(2),
        o = n(1),
        i = n(7),
        a = n(3);
      function c(t, e, n) {
        try {
          var c,
            s = r.a.getState(),
            u = s.config,
            l = Object(i.c)("host", s.hosts.DEFAULT_CXM_HOST),
            f = s.cfg.LIB_CONFIG_PATH;
          try {
            if (0 <= ["http:", "https:"].indexOf(t.protocol))
              c = t.protocol + "//" + t.hostname;
            else {
              if (!(0 <= ["http:", "https:"].indexOf(e.protocol))) return null;
              c = e.protocol + "//" + e.hostname;
            }
          } catch (t) {
            if (t instanceof window.DOMException) return null;
            throw t;
          }
          var d,
            b =
              (b = null == n ? void 0 : n.sourceID) ||
              (u.isSelfServePub ? a.s : u.pubID),
            p = null == n ? void 0 : n.publisherUUID,
            y =
              (p || (u.isSelfServePub && (p = u.pubID)),
              { src: b, u: encodeURIComponent(c) });
          return (
            p && (y.pubid = p),
            !y.src || isNaN(Number(y.src))
              ? null
              : ((d = Object.keys(y)
                  .map(function (t) {
                    return "".concat(t.trim(), "=").concat(String(y[t]).trim());
                  })
                  .join("&")),
                "".concat(a.v).concat(l).concat(f, "?").concat(d))
          );
        } catch (t) {
          return Object(o.b)(t, "buildLibraryConfigUrl"), null;
        }
      }
    },
    function (t, e, n) {
      "use strict";
      n.d(e, "a", function () {
        return o;
      });
      var r = n(0);
      function o(t, e) {
        var n, o, i;
        Object(r.i)(e.data) &&
          (Object(r.j)(e.data, "bidInfo") &&
            (Object(r.j)(e.data.bidInfo, "src")
              ? ((n = e.data.bidInfo.src),
                (n = new URL(n).searchParams.get("b")))
              : Object(r.j)(e.data.bidInfo, "jsonp") &&
                ((i = e.data.bidInfo.jsonp),
                (n = JSON.parse(i.substr(17, i.length - 20)).amzniid))),
          Object(r.j)(e.data, "renderData")) &&
          ((e = (i = e.data.renderData).id),
          Object(r.j)(i, "renderStart") || Object(r.j)(i, "renderEnd")) &&
          ((o = i.renderStart),
          (i = i.renderEnd),
          o
            ? ((t.renderTimes[e] = { timeStamp: o }),
              n && (t.renderTimes[e].bidId = n))
            : i &&
              Object(r.j)(t.renderTimes, e) &&
              0 !== t.renderTimes[e].timeStamp &&
              t.renderTimes[e].bidId &&
              t.renderTimes[e].bidId);
      }
    },
    function (t, e, n) {
      "use strict";
      n.d(e, "a", function () {
        return m;
      });
      e = n(14);
      var r = n(22),
        o = n(4),
        i = n(18);
      function a(t) {
        return (a =
          "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
            ? function (t) {
                return typeof t;
              }
            : function (t) {
                return t &&
                  "function" == typeof Symbol &&
                  t.constructor === Symbol &&
                  t !== Symbol.prototype
                  ? "symbol"
                  : typeof t;
              })(t);
      }
      function c(t, e) {
        var n,
          r = Object.keys(t);
        return (
          Object.getOwnPropertySymbols &&
            ((n = Object.getOwnPropertySymbols(t)),
            e &&
              (n = n.filter(function (e) {
                return Object.getOwnPropertyDescriptor(t, e).enumerable;
              })),
            r.push.apply(r, n)),
          r
        );
      }
      function s(t) {
        for (var e = 1; e < arguments.length; e++) {
          var n = null != arguments[e] ? arguments[e] : {};
          e % 2
            ? c(Object(n), !0).forEach(function (e) {
                y(t, e, n[e]);
              })
            : Object.getOwnPropertyDescriptors
            ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n))
            : c(Object(n)).forEach(function (e) {
                Object.defineProperty(
                  t,
                  e,
                  Object.getOwnPropertyDescriptor(n, e)
                );
              });
        }
        return t;
      }
      function u(t, e) {
        for (var n = 0; n < e.length; n++) {
          var r = e[n];
          (r.enumerable = r.enumerable || !1),
            (r.configurable = !0),
            "value" in r && (r.writable = !0),
            Object.defineProperty(t, g(r.key), r);
        }
      }
      function l() {
        return (l =
          "undefined" != typeof Reflect && Reflect.get
            ? Reflect.get.bind()
            : function (t, e, n) {
                var r = (function (t, e) {
                  for (
                    ;
                    !Object.prototype.hasOwnProperty.call(t, e) &&
                    null !== (t = p(t));

                  );
                  return t;
                })(t, e);
                if (r)
                  return (r = Object.getOwnPropertyDescriptor(r, e)).get
                    ? r.get.call(arguments.length < 3 ? t : n)
                    : r.value;
              }).apply(this, arguments);
      }
      function f(t, e) {
        return (f = Object.setPrototypeOf
          ? Object.setPrototypeOf.bind()
          : function (t, e) {
              return (t.__proto__ = e), t;
            })(t, e);
      }
      function d(t) {
        var e = (function () {
          if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
          if (Reflect.construct.sham) return !1;
          if ("function" == typeof Proxy) return !0;
          try {
            return (
              Boolean.prototype.valueOf.call(
                Reflect.construct(Boolean, [], function () {})
              ),
              !0
            );
          } catch (t) {
            return !1;
          }
        })();
        return function () {
          var n,
            r = p(t);
          (n = e
            ? ((n = p(this).constructor), Reflect.construct(r, arguments, n))
            : r.apply(this, arguments)),
            (r = this);
          if (n && ("object" === a(n) || "function" == typeof n)) return n;
          if (void 0 !== n)
            throw new TypeError(
              "Derived constructors may only return object or undefined"
            );
          return b(r);
        };
      }
      function b(t) {
        if (void 0 === t)
          throw new ReferenceError(
            "this hasn't been initialised - super() hasn't been called"
          );
        return t;
      }
      function p(t) {
        return (p = Object.setPrototypeOf
          ? Object.getPrototypeOf.bind()
          : function (t) {
              return t.__proto__ || Object.getPrototypeOf(t);
            })(t);
      }
      function y(t, e, n) {
        (e = g(e)) in t
          ? Object.defineProperty(t, e, {
              value: n,
              enumerable: !0,
              configurable: !0,
              writable: !0,
            })
          : (t[e] = n);
      }
      function g(t) {
        return (
          (t = (function (t, e) {
            if ("object" !== a(t) || null === t) return t;
            var n = t[Symbol.toPrimitive];
            if (void 0 === n) return String(t);
            if ("object" !== a((n = n.call(t, e)))) return n;
            throw new TypeError("@@toPrimitive must return a primitive value.");
          })(t, "string")),
          "symbol" === a(t) ? t : String(t)
        );
      }
      var m = (function (t) {
        var e = a;
        if ("function" != typeof t && null !== t)
          throw new TypeError(
            "Super expression must either be null or a function"
          );
        (e.prototype = Object.create(t && t.prototype, {
          constructor: { value: e, writable: !0, configurable: !0 },
        })),
          Object.defineProperty(e, "prototype", { writable: !1 }),
          t && f(e, t);
        var n = d(a);
        function a(t) {
          if (this instanceof a)
            return (
              y(b((t = n.call(this, t))), "_sizesDelegate", void 0),
              (t._sizesDelegate = new r.a(t.rawSlot.sizes)),
              t
            );
          throw new TypeError("Cannot call a class as a function");
        }
        return (
          (e = a),
          (t = [
            {
              key: "mediaType",
              get: function () {
                return o.a.VIDEO;
              },
            },
            {
              key: "aaxMediaType",
              get: function () {
                return i.a.VIDEO;
              },
            },
            {
              key: "sizes",
              get: function () {
                return this._sizesDelegate.sizes;
              },
            },
            {
              key: "aaxSizes",
              get: function () {
                return this._sizesDelegate.aaxSizes || [];
              },
            },
            {
              key: "aaxSlot",
              get: function () {
                var t = s(
                  s({}, l(p(a.prototype), "aaxSlot", this)),
                  {},
                  { id: this.slotID, mt: this.aaxMediaType }
                );
                return 0 < this.sizes.length && (t.s = this.aaxSizes), t;
              },
            },
          ]) && u(e.prototype, t),
          Object.defineProperty(e, "prototype", { writable: !1 }),
          a
        );
      })(e.a);
    },
    function (t, e, n) {
      "use strict";
      function r(t) {
        var e = new Image();
        return (e.src = t), e;
      }
      n.d(e, "a", function () {
        return r;
      });
    },
    function (t, e, n) {
      "use strict";
      n.d(e, "a", function () {
        return I;
      });
      e = n(14);
      var r = n(4),
        o = n(18),
        i = n(0),
        a = n(1),
        c = n(22);
      function s(t) {
        return (s =
          "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
            ? function (t) {
                return typeof t;
              }
            : function (t) {
                return t &&
                  "function" == typeof Symbol &&
                  t.constructor === Symbol &&
                  t !== Symbol.prototype
                  ? "symbol"
                  : typeof t;
              })(t);
      }
      function u(t, e) {
        for (var n = 0; n < e.length; n++) {
          var r = e[n];
          (r.enumerable = r.enumerable || !1),
            (r.configurable = !0),
            "value" in r && (r.writable = !0),
            Object.defineProperty(t, f(r.key), r);
        }
      }
      function l(t, e, n) {
        (e = f(e)) in t
          ? Object.defineProperty(t, e, {
              value: n,
              enumerable: !0,
              configurable: !0,
              writable: !0,
            })
          : (t[e] = n);
      }
      function f(t) {
        return (
          (t = (function (t, e) {
            if ("object" !== s(t) || null === t) return t;
            var n = t[Symbol.toPrimitive];
            if (void 0 === n) return String(t);
            if ("object" !== s((n = n.call(t, e)))) return n;
            throw new TypeError("@@toPrimitive must return a primitive value.");
          })(t, "string")),
          "symbol" === s(t) ? t : String(t)
        );
      }
      var d = (function () {
        function t() {
          var e =
              0 < arguments.length && void 0 !== arguments[0]
                ? arguments[0]
                : {},
            n = this,
            r = t;
          if (!(n instanceof r))
            throw new TypeError("Cannot call a class as a function");
          l(this, "_propertyConfig", void 0),
            l(this, "_sizesDelegate", void 0),
            (this._propertyConfig = e),
            (this._sizesDelegate = new c.a(
              null == e ? void 0 : e.sizes,
              !1,
              !0
            ));
        }
        var e, n;
        return (
          (e = t),
          (n = [
            {
              key: "sizes",
              get: function () {
                return this._sizesDelegate.sizes;
              },
            },
            {
              key: "validSizes",
              get: function () {
                return this._sizesDelegate.isValid();
              },
            },
            {
              key: "propertyConfig",
              get: function () {
                return this._propertyConfig;
              },
            },
            {
              key: "aaxPropertyConfig",
              get: function () {
                var t = {};
                return this.aaxSizes && (t.s = this.aaxSizes), t;
              },
            },
            {
              key: "aaxSizes",
              get: function () {
                return this._sizesDelegate.aaxSizes;
              },
            },
            {
              key: "isValid",
              value: function () {
                return !Object(i.i)(this.propertyConfig) ||
                  Array.isArray(this.propertyConfig)
                  ? (Object(a.b)(
                      {
                        name: "MultiFormatSlot-InvalidMultiFormatSlotProperty",
                        message: "multiFormatProperty must be an object",
                      },
                      "MultiFormatSlotProperty-isValid",
                      { makeVisibleToAllUsers: !0 }
                    ),
                    !1)
                  : !!this.validSizes;
              },
            },
          ]) && u(e.prototype, n),
          Object.defineProperty(e, "prototype", { writable: !1 }),
          t
        );
      })();
      function b(t) {
        return (b =
          "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
            ? function (t) {
                return typeof t;
              }
            : function (t) {
                return t &&
                  "function" == typeof Symbol &&
                  t.constructor === Symbol &&
                  t !== Symbol.prototype
                  ? "symbol"
                  : typeof t;
              })(t);
      }
      function p(t, e) {
        for (var n = 0; n < e.length; n++) {
          var r = e[n];
          (r.enumerable = r.enumerable || !1),
            (r.configurable = !0),
            "value" in r && (r.writable = !0),
            Object.defineProperty(t, g(r.key), r);
        }
      }
      function y(t, e, n) {
        (e = g(e)) in t
          ? Object.defineProperty(t, e, {
              value: n,
              enumerable: !0,
              configurable: !0,
              writable: !0,
            })
          : (t[e] = n);
      }
      function g(t) {
        return (
          (t = (function (t, e) {
            if ("object" !== b(t) || null === t) return t;
            var n = t[Symbol.toPrimitive];
            if (void 0 === n) return String(t);
            if ("object" !== b((n = n.call(t, e)))) return n;
            throw new TypeError("@@toPrimitive must return a primitive value.");
          })(t, "string")),
          "symbol" === b(t) ? t : String(t)
        );
      }
      var m = (function () {
        function t(e) {
          var n = this;
          if (!(this instanceof t))
            throw new TypeError("Cannot call a class as a function");
          y(this, "_multiFormatProperties", void 0),
            e &&
              Object(i.i)(e) &&
              !Array.isArray(e) &&
              ((this._multiFormatProperties = {}),
              this.toMultiFormatMediaTypes(e).forEach(function (t) {
                n._multiFormatProperties &&
                  (n._multiFormatProperties[t] = new d(e[t]));
              }));
        }
        var e, n;
        return (
          (e = t),
          (n = [
            {
              key: "convertMultiFormatMediaType",
              value: function (t) {
                var e;
                return (
                  y((e = {}), r.a.VIDEO, o.a.VIDEO),
                  y(e, r.a.DISPLAY, o.a.DISPLAY),
                  e[t]
                );
              },
            },
            {
              key: "isMultiFormatMediaType",
              value: function (t) {
                return Boolean(this.convertMultiFormatMediaType(t));
              },
            },
            {
              key: "toMultiFormatMediaTypes",
              value: function (t) {
                var e = this;
                return Object.keys(t).filter(function (t) {
                  return e.isMultiFormatMediaType(t);
                });
              },
            },
            {
              key: "multiFormatMediaTypes",
              get: function () {
                return this._multiFormatProperties
                  ? this.toMultiFormatMediaTypes(this._multiFormatProperties)
                  : [];
              },
            },
            {
              key: "aaxMultiFormatProperties",
              get: function () {
                var t,
                  e = this;
                return this._multiFormatProperties
                  ? ((t = {}),
                    this.multiFormatMediaTypes.forEach(function (n) {
                      var r = e.convertMultiFormatMediaType(n);
                      r &&
                        (t[r] =
                          null == (r = e._multiFormatProperties[n])
                            ? void 0
                            : r.aaxPropertyConfig);
                    }),
                    t)
                  : {};
              },
            },
            {
              key: "isValid",
              value: function () {
                var t = this,
                  e = !0;
                return this._multiFormatProperties
                  ? (this.multiFormatMediaTypes.forEach(function (n) {
                      t._multiFormatProperties[n].isValid() || (e = !1);
                    }),
                    e)
                  : (Object(a.b)(
                      {
                        name: "MultiFormatSlot-InvalidMultiFormatProperties",
                        message: "multiFormatProperties must be an object",
                      },
                      "MultiFormatProperties-isValid",
                      { makeVisibleToAllUsers: !0 }
                    ),
                    !1);
              },
            },
          ]) && p(e.prototype, n),
          Object.defineProperty(e, "prototype", { writable: !1 }),
          t
        );
      })();
      function h(t) {
        return (h =
          "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
            ? function (t) {
                return typeof t;
              }
            : function (t) {
                return t &&
                  "function" == typeof Symbol &&
                  t.constructor === Symbol &&
                  t !== Symbol.prototype
                  ? "symbol"
                  : typeof t;
              })(t);
      }
      function O(t, e) {
        var n,
          r = Object.keys(t);
        return (
          Object.getOwnPropertySymbols &&
            ((n = Object.getOwnPropertySymbols(t)),
            e &&
              (n = n.filter(function (e) {
                return Object.getOwnPropertyDescriptor(t, e).enumerable;
              })),
            r.push.apply(r, n)),
          r
        );
      }
      function v(t) {
        for (var e = 1; e < arguments.length; e++) {
          var n = null != arguments[e] ? arguments[e] : {};
          e % 2
            ? O(Object(n), !0).forEach(function (e) {
                D(t, e, n[e]);
              })
            : Object.getOwnPropertyDescriptors
            ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n))
            : O(Object(n)).forEach(function (e) {
                Object.defineProperty(
                  t,
                  e,
                  Object.getOwnPropertyDescriptor(n, e)
                );
              });
        }
        return t;
      }
      function j(t, e) {
        for (var n = 0; n < e.length; n++) {
          var r = e[n];
          (r.enumerable = r.enumerable || !1),
            (r.configurable = !0),
            "value" in r && (r.writable = !0),
            Object.defineProperty(t, T(r.key), r);
        }
      }
      function S() {
        return (S =
          "undefined" != typeof Reflect && Reflect.get
            ? Reflect.get.bind()
            : function (t, e, n) {
                var r = (function (t, e) {
                  for (
                    ;
                    !Object.prototype.hasOwnProperty.call(t, e) &&
                    null !== (t = E(t));

                  );
                  return t;
                })(t, e);
                if (r)
                  return (r = Object.getOwnPropertyDescriptor(r, e)).get
                    ? r.get.call(arguments.length < 3 ? t : n)
                    : r.value;
              }).apply(this, arguments);
      }
      function w(t, e) {
        return (w = Object.setPrototypeOf
          ? Object.setPrototypeOf.bind()
          : function (t, e) {
              return (t.__proto__ = e), t;
            })(t, e);
      }
      function _(t) {
        if (void 0 === t)
          throw new ReferenceError(
            "this hasn't been initialised - super() hasn't been called"
          );
        return t;
      }
      function E(t) {
        return (E = Object.setPrototypeOf
          ? Object.getPrototypeOf.bind()
          : function (t) {
              return t.__proto__ || Object.getPrototypeOf(t);
            })(t);
      }
      function D(t, e, n) {
        (e = T(e)) in t
          ? Object.defineProperty(t, e, {
              value: n,
              enumerable: !0,
              configurable: !0,
              writable: !0,
            })
          : (t[e] = n);
      }
      function T(t) {
        return (
          (t = (function (t, e) {
            if ("object" !== h(t) || null === t) return t;
            var n = t[Symbol.toPrimitive];
            if (void 0 === n) return String(t);
            if ("object" !== h((n = n.call(t, e)))) return n;
            throw new TypeError("@@toPrimitive must return a primitive value.");
          })(t, "string")),
          "symbol" === h(t) ? t : String(t)
        );
      }
      var I = (function (t) {
        var e = i;
        if ("function" != typeof t && null !== t)
          throw new TypeError(
            "Super expression must either be null or a function"
          );
        (e.prototype = Object.create(t && t.prototype, {
          constructor: { value: e, writable: !0, configurable: !0 },
        })),
          Object.defineProperty(e, "prototype", { writable: !1 }),
          t && w(e, t);
        var n = (function (t) {
          var e = (function () {
            if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
            if (Reflect.construct.sham) return !1;
            if ("function" == typeof Proxy) return !0;
            try {
              return (
                Boolean.prototype.valueOf.call(
                  Reflect.construct(Boolean, [], function () {})
                ),
                !0
              );
            } catch (t) {
              return !1;
            }
          })();
          return function () {
            var n,
              r = E(t);
            (n = e
              ? ((n = E(this).constructor), Reflect.construct(r, arguments, n))
              : r.apply(this, arguments)),
              (r = this);
            if (n && ("object" === h(n) || "function" == typeof n)) return n;
            if (void 0 !== n)
              throw new TypeError(
                "Derived constructors may only return object or undefined"
              );
            return _(r);
          };
        })(i);
        function i(t) {
          var e;
          if (this instanceof i)
            return (
              D(
                _((e = n.call(this, t))),
                "_multiFormatPropertiesDelegate",
                void 0
              ),
              (e._multiFormatPropertiesDelegate = new m(
                t.multiFormatProperties
              )),
              e
            );
          throw new TypeError("Cannot call a class as a function");
        }
        return (
          (e = i),
          (t = [
            {
              key: "mediaType",
              get: function () {
                return r.a.MULTI_FORMAT;
              },
            },
            {
              key: "aaxMediaType",
              get: function () {
                return o.a.MULTI_FORMAT;
              },
            },
            {
              key: "aaxMultiFormatProperties",
              get: function () {
                return this._multiFormatPropertiesDelegate
                  .aaxMultiFormatProperties;
              },
            },
            {
              key: "multiFormatPropertiesIsValid",
              get: function () {
                return this._multiFormatPropertiesDelegate.isValid();
              },
            },
            {
              key: "aaxSlot",
              get: function () {
                return v(
                  v({}, S(E(i.prototype), "aaxSlot", this)),
                  {},
                  {
                    id: this.slotID,
                    sd: this.slotID,
                    sn: this.slotName || this.slotID,
                    mt: this.aaxMediaType,
                    mfp: this.aaxMultiFormatProperties,
                  }
                );
              },
            },
            {
              key: "isValid",
              value: function () {
                return (
                  S(E(i.prototype), "isValid", this).call(this) &&
                  this.multiFormatPropertiesIsValid
                );
              },
            },
          ]) && j(e.prototype, t),
          Object.defineProperty(e, "prototype", { writable: !1 }),
          i
        );
      })(e.a);
    },
    function (t, e, n) {
      t.exports = n(15);
    },
  ]);
})();
