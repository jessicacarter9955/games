!(function (t) {
  var e = {};
  function i(a) {
    if (e[a]) return e[a].exports;
    var s = (e[a] = { i: a, l: !1, exports: {} });
    return t[a].call(s.exports, s, s.exports, i), (s.l = !0), s.exports;
  }
  (i.m = t),
    (i.c = e),
    (i.d = function (t, e, a) {
      i.o(t, e) || Object.defineProperty(t, e, { enumerable: !0, get: a });
    }),
    (i.r = function (t) {
      "undefined" != typeof Symbol &&
        Symbol.toStringTag &&
        Object.defineProperty(t, Symbol.toStringTag, { value: "Module" }),
        Object.defineProperty(t, "__esModule", { value: !0 });
    }),
    (i.t = function (t, e) {
      if ((1 & e && (t = i(t)), 8 & e)) return t;
      if (4 & e && "object" == typeof t && t && t.__esModule) return t;
      var a = Object.create(null);
      if (
        (i.r(a),
        Object.defineProperty(a, "default", { enumerable: !0, value: t }),
        2 & e && "string" != typeof t)
      )
        for (var s in t)
          i.d(
            a,
            s,
            function (e) {
              return t[e];
            }.bind(null, s)
          );
      return a;
    }),
    (i.n = function (t) {
      var e =
        t && t.__esModule
          ? function () {
              return t.default;
            }
          : function () {
              return t;
            };
      return i.d(e, "a", e), e;
    }),
    (i.o = function (t, e) {
      return Object.prototype.hasOwnProperty.call(t, e);
    }),
    (i.p = ""),
    i((i.s = "tbaA"));
})({
  tbaA: function (t, e) {
    var i = function () {
      var t = {
          domain: "www.amazon.de",
          iconSprite:
            "https://images-na.ssl-images-amazon.com/images/G/03/cstone/adchoices/topright/germany_opa.png",
          spriteWidth: 112,
        },
        e = {
          domain: "www.amazon.es",
          iconSprite:
            "https://images-na.ssl-images-amazon.com/images/G/03/cstone/adchoices/topright/spain_opa.png",
          spriteWidth: 118,
        },
        i = {
          domain: "www.amazon.fr",
          iconSprite:
            "https://images-na.ssl-images-amazon.com/images/G/03/cstone/adchoices/topright/france_opa.png",
          spriteWidth: 105,
        },
        a = {
          domain: "www.amazon.it",
          iconSprite:
            "https://images-na.ssl-images-amazon.com/images/G/03/cstone/adchoices/topright/italy_opa.png",
          spriteWidth: 81,
        },
        s = {
          domain: "www.amazon.co.uk",
          iconSprite:
            "https://images-na.ssl-images-amazon.com/images/G/03/cstone/adchoices/topright/uk_opa.png",
          spriteWidth: 91,
        },
        o = {
          domain: "www.amazon.com",
          iconSprite:
            "https://images-na.ssl-images-amazon.com/images/G/03/cstone/adchoices/topright/default_opa.png",
          spriteWidth: 91,
        },
        n = {
          domain: "www.amazon.ae",
          iconSprite:
            "https://images-na.ssl-images-amazon.com/images/G/03/cstone/adchoices/topright/default_opa.png",
          spriteWidth: 91,
        },
        r = {
          domain: "www.amazon.ca",
          iconSprite:
            "https://images-na.ssl-images-amazon.com/images/G/03/cstone/adchoices/topright/default_opa.png",
          spriteWidth: 91,
        },
        d = {
          domain: "www.amazon.co.jp",
          iconSprite:
            "https://images-fe.ssl-images-amazon.com/images/G/03/cstone/adchoices/topright/default_opa.png",
          spriteWidth: 91,
        },
        p = {
          domain: "www.amazon.com.au",
          iconSprite:
            "https://images-fe.ssl-images-amazon.com/images/G/03/cstone/adchoices/topright/default_opa.png",
          spriteWidth: 91,
        },
        c = {
          domain: "www.amazon.com.br",
          iconSprite:
            "https://images-na.ssl-images-amazon.com/images/G/03/cstone/adchoices/topright/brazil_opa.png",
          spriteWidth: 91,
        },
        h = {
          domain: "www.amazon.nl",
          iconSprite:
            "https://images-na.ssl-images-amazon.com/images/G/03/cstone/adchoices/topright/netherlands_opa.png",
          spriteWidth: 91,
        },
        l = {
          domain: "www.amazon.sa",
          iconSprite:
            "https://images-na.ssl-images-amazon.com/images/G/03/cstone/adchoices/topright/default_opa.png",
          spriteWidth: 91,
        },
        u = {
          domain: "www.amazon.se",
          iconSprite:
            "https://images-na.ssl-images-amazon.com/images/G/03/cstone/adchoices/topright/sweden_opa.png",
          spriteWidth: 91,
        },
        m = {
          domain: "www.amazon.com.tr",
          iconSprite:
            "https://images-na.ssl-images-amazon.com/images/G/03/cstone/adchoices/topright/default_opa.png",
          spriteWidth: 91,
        },
        g = {
          domain: "www.amazon.sg",
          iconSprite:
            "https://images-na.ssl-images-amazon.com/images/G/03/cstone/adchoices/topright/singapore_opa.png",
          spriteWidth: 91,
        };
      (g.domain = "www.amazon.in"),
        (g.iconSprite =
          "https://images-na.ssl-images-amazon.com/images/G/03/cstone/adchoices/topright/default_opa.png"),
        (g.spriteWidth = 91),
        (this.adChoicesIconWidth_ = 19),
        (this.adChoices_ = {
          uk: s,
          germany: t,
          de: t,
          france: i,
          fr: i,
          spain: e,
          es: e,
          italy: a,
          it: a,
          ae: n,
          us: o,
          ca: r,
          jp: d,
          au: p,
          br: c,
          nl: h,
          sa: l,
          se: u,
          tr: m,
          sg: g,
          in: {},
          default: o,
        }),
        (this.slot_ = null),
        (this.videoSlot_ = null),
        (this.eventListeners_ = {}),
        (this.attributes_ = {
          linear: !0,
          companions: "",
          icons: "",
          width: 0,
          height: 0,
          viewMode: "normal",
          desiredBitrate: 450,
          duration: 30,
          skippableState: !1,
          skipOffset: -1,
          remainingTime: 0,
          volume: 1,
          expanded: !1,
        }),
        (this.quartileEvents_ = [
          { event: "AdVideoStart", value: 0 },
          { event: "AdVideoFirstQuartile", value: 25 },
          { event: "AdVideoMidpoint", value: 50 },
          { event: "AdVideoThirdQuartile", value: 75 },
          { event: "AdVideoComplete", value: 100 },
        ]),
        (this.lastQuartileIndex_ = 0),
        (this.parameters_ = {});
    };
    i.prototype.createAdChoicesOverlay_ = function () {
      var t = this.parameters_.adChoicesLocale || "default";
      t = t.toLowerCase();
      var e = this.adChoices_[t] || this.adChoices_.default,
        i = this.parameters_.adCfid || 0,
        a = this.parameters_.creativeCfid || 0,
        s =
          "https://" + e.domain + "/adprefs/ref=cs_aap_" + a + "/?pn=1&pg=daae";
      this.slot_.innerHTML =
        '<style type="text/css">#adChoicesDiv' +
        i +
        " .invisible { display: none !important; }</style>";
      var o = document.createElement("div");
      o.setAttribute("id", "adChoicesDiv" + i);
      var n = document.createElement("a");
      n.setAttribute("target", "_blank"),
        n.setAttribute("href", s),
        n.setAttribute("border", "0"),
        n.setAttribute(
          "style",
          "display:block; margin:0; padding: 0; border: 0; text-decoration: none; cursor: pointer"
        ),
        o.appendChild(n);
      var r = document.createElement("span");
      r.setAttribute("id", "adChoicesIconText" + i),
        r.setAttribute(
          "style",
          "margin:0; padding:0; position: absolute; height: 15px; overflow: hidden; top: 0; right: 0;"
        ),
        n.appendChild(r);
      var d = document.createElement("span"),
        p = e.spriteWidth - this.adChoicesIconWidth_;
      d.setAttribute("id", "adMarkerFull" + i),
        d.setAttribute(
          "style",
          "width: " +
            p +
            "px; height: 15px;display:inline-block;background-color:transparent;background-position: -" +
            this.adChoicesIconWidth_ +
            "px 0;-ms-background-position-x: -" +
            (this.adChoicesIconWidth_ - 1) +
            'px; -ms-background-position-y: 1px;background-image:url("' +
            e.iconSprite +
            '");background-repeat: no-repeat;'
        ),
        (d.innerHTML = "&nbsp;"),
        r.appendChild(d);
      var c = document.createElement("span");
      c.setAttribute("id", "adChoicesIcon" + i),
        c.setAttribute(
          "style",
          "margin: 0; padding: 0;height: 15px; width: " +
            this.adChoicesIconWidth_ +
            'px; border: none;display:inline-block;position: absolute; overflow: hidden;background: transparent url("' +
            e.iconSprite +
            '") no-repeat 0 0;top: 0; right: 0;'
        ),
        (c.innerHTML = "&nbsp;"),
        n.appendChild(c),
        this.slot_.appendChild(o);
    };
    (i.prototype.initAd = function (t, e, i, a, s, o) {
      var n, r, d;
      if (
        ((this.attributes_.width = t),
        (this.attributes_.height = e),
        (this.attributes_.viewMode = i),
        (this.attributes_.desiredBitrate = a),
        (this.parameters_ =
          ((n = s.AdParameters),
          (r = /<JsParameters>([\s\S]*)<\/JsParameters>/g.exec(n)[1]),
          JSON.parse(r))),
        (this.attributes_.duration = this.parameters_.duration),
        (this.attributes_.skippableState = this.parameters_.skippableState),
        (this.attributes_.skipOffset = this.parameters_.skipOffset || -1),
        (this.attributes_.remainingTime = this.parameters_.duration),
        (this.slot_ = o.slot),
        (this.videoSlot_ = o.videoSlot),
        this.log("initAd " + t + "x" + e + " " + i + " " + a),
        this.updateVideoSlot_(),
        this.videoSlot_.addEventListener(
          "timeupdate",
          this.timeUpdateHandler_.bind(this),
          !1
        ),
        this.videoSlot_.addEventListener("ended", this.stopAd.bind(this), !1),
        this.callEvent_("AdLoaded"),
        this.parameters_ && this.parameters_.vu && this.parameters_.vuInstr)
      ) {
        var p =
            ((d = this.parameters_.vuInstr) &&
              (d = (function (t) {
                return "/" === t[t.length - 1] ? t : t + "/";
              })((d = d.replace(/^https?:/, document.location.protocol)))),
            d),
          c = this.parameters_.vu,
          h = this.parameters_.vuParams,
          l = this,
          u = function (t) {
            var e = {
              adViewability: [{ error: { m: t } }],
              c: "viewability",
              api: "VDO",
              error: 1,
            };
            new Image().src =
              p +
              encodeURI(JSON.stringify(e)) +
              "?cb=" +
              Math.floor(1e7 * Math.random());
          },
          m = document.createElement("script");
        (m.type = "text/javascript"),
          (m.onload = function () {
            "undefined" != typeof amzncsm && "function" == typeof amzncsm.rmVP
              ? amzncsm.rmVP(p, l, h)
              : u("amzncsm.rmVP is not a function");
          }),
          (m.onerror = function () {
            u("CSM JS loading failed");
          }),
          (m.src = c),
          document.head.appendChild(m);
      }
    }),
      (i.prototype.timeUpdateHandler_ = function () {
        if (!(this.lastQuartileIndex_ >= this.quartileEvents_.length)) {
          var t = this.attributes_.skippableState,
            e = this.attributes_.skipOffset;
          if (
            (!t &&
              e > 0 &&
              this.videoSlot_.currentTime >= e &&
              this.setAdSkippableState_(!0),
            (100 * this.videoSlot_.currentTime) / this.videoSlot_.duration >=
              this.quartileEvents_[this.lastQuartileIndex_].value)
          ) {
            var i = this.quartileEvents_[this.lastQuartileIndex_].event;
            this.callEvent_(i), (this.lastQuartileIndex_ += 1);
          }
        }
      }),
      (i.prototype.extractVideoSourceWithDesiredBitrate_ = function () {
        var t = null,
          e = this.attributes_.desiredBitrate;
        (e = isNaN(e) ? 450 : (e = Number(e)) > 0 ? e : 450),
          this.log("desiredBitrate " + e);
        for (var i = this.parameters_.videos || [], a = 0; a < i.length; a++)
          this.videoSlot_.canPlayType(i[a].mimetype) &&
            (!t || Math.abs(e - i[a].bitRate) < Math.abs(e - t.bitRate)) &&
            (t = i[a]);
        t
          ? (this.log("extracted video " + JSON.stringify(t, null, 2)),
            this.videoSlot_.setAttribute("src", t.url))
          : this.callEvent_("AdError");
      }),
      (i.prototype.updateVideoSlot_ = function () {
        (this.slot_ &&
          this.slot_.tagName &&
          "DIV" === this.slot_.tagName.toUpperCase()) ||
          ((this.slot_ = document.createElement("div")),
          document.body || (document.body = document.createElement("body")),
          document.body.appendChild(this.slot_)),
          this.parameters_.showAdChoices &&
            (this.createAdChoicesOverlay_(),
            (adCfid = this.parameters_.adCfid),
            (adChoicesDiv = this.getElement_("adChoicesDiv" + adCfid)),
            (adChoicesText = this.getElement_("adChoicesIconText" + adCfid)),
            (adChoicesImage = this.getElement_("adChoicesIcon" + adCfid)),
            (adChoicesText.className = "invisible"),
            (adChoicesImage.className = ""),
            (adChoicesDiv.onmouseover = function () {
              (adChoicesImage.className = "invisible"),
                (adChoicesText.className = "");
            }),
            (adChoicesDiv.onmouseout = function () {
              (adChoicesText.className = "invisible"),
                (adChoicesImage.className = "");
            }),
            adChoicesDiv.addEventListener("click", function (t) {
              if (!t) t = window.event;
              (t.cancelBubble = !0), t.stopPropagation && t.stopPropagation();
            })),
          null == this.videoSlot_ &&
            ((this.videoSlot_ = document.createElement("video")),
            this.log(
              "Warning: No video element passed to ad, creating element."
            ),
            this.slot_.appendChild(this.videoSlot_)),
          this.extractVideoSourceWithDesiredBitrate_(),
          (this.clickToPlay_ = document.createElement("div")),
          this.clickToPlay_.setAttribute(
            "style",
            "width: 100%; height: 100%; cursor: pointer; display: none;"
          ),
          this.slot_.appendChild(this.clickToPlay_);
        var t = this;
        this.clickToPlay_.addEventListener("click", function (e) {
          if ((t.resumeAd(), !e)) e = window.event;
          (e.cancelBubble = !0), e.stopPropagation && e.stopPropagation();
        });
      }),
      (i.prototype.updateVideoPlayerSize_ = function () {
        try {
          this.videoSlot_.setAttribute("width", this.attributes_.width),
            this.videoSlot_.setAttribute("height", this.attributes_.height),
            (this.videoSlot_.style.width = this.attributes_.width + "px"),
            (this.videoSlot_.style.height = this.attributes_.height + "px");
        } catch (t) {}
      }),
      (i.prototype.handshakeVersion = function (t) {
        return this.parameters_.vpaidVersion || "2.0";
      }),
      (i.prototype.startAd = function () {
        this.log("Starting ad"), this.callEvent_("AdImpression");
        var t = this;
        this.videoSlot_.play().catch(function (e) {
          console.warn("Warning: " + e), t.pauseAd();
        });
        var e = this.callEvent_.bind(this);
        this.slot_.addEventListener("click", function (t) {
          if ((e("AdClickThru"), !t)) t = window.event;
          (t.cancelBubble = !0), t.stopPropagation && t.stopPropagation();
        }),
          this.callEvent_("AdStarted");
      }),
      (i.prototype.stopAd = function () {
        this.log("Stopping ad");
        var t = this.callEvent_.bind(this);
        setTimeout(t, 75, ["AdStopped"]);
      }),
      (i.prototype.setAdVolume = function (t) {
        (this.attributes_.volume = t),
          this.log("setAdVolume " + t),
          this.updateVideoPlayerVolume(),
          this.callEvent_("AdVolumeChanged");
      }),
      (i.prototype.getAdVolume = function () {
        return this.log("getAdVolume"), this.attributes_.volume;
      }),
      (i.prototype.updateVideoPlayerVolume = function () {
        this.videoSlot_.setAttribute("volume", this.attributes_.volume);
      }),
      (i.prototype.resizeAd = function (t, e, i) {
        this.log("resizeAd " + t + "x" + e + " " + i),
          (this.attributes_.width = t),
          (this.attributes_.height = e),
          (this.attributes_.viewMode = i),
          this.updateVideoPlayerSize_(),
          this.callEvent_("AdSizeChange");
      }),
      (i.prototype.pauseAd = function () {
        this.log("pauseAd"),
          this.clickToPlay_ && (this.clickToPlay_.style.display = "block"),
          this.videoSlot_.pause(),
          this.callEvent_("AdPaused");
      }),
      (i.prototype.resumeAd = function () {
        this.log("resumeAd"),
          this.clickToPlay_ && (this.clickToPlay_.style.display = "none"),
          this.videoSlot_.play(),
          this.callEvent_("AdPlaying");
      }),
      (i.prototype.expandAd = function () {
        this.log("expandAd");
      }),
      (i.prototype.getAdExpanded = function () {
        return this.log("getAdExpanded"), this.attributes_.expanded;
      }),
      (i.prototype.getAdSkippableState = function () {
        return this.log("getAdSkippableState"), this.attributes_.skippableState;
      }),
      (i.prototype.setAdSkippableState_ = function (t) {
        var e = this.attributes_.skippableState;
        (this.attributes_.skippableState = t),
          e !== this.attributes_.skippableState &&
            this.callEvent_("AdSkippableStateChange");
      }),
      (i.prototype.collapseAd = function () {
        this.log("collapseAd");
      }),
      (i.prototype.skipAd = function () {
        this.log("skipAd"),
          this.attributes_.skippableState &&
            (this.callEvent_("AdSkipped"), this.callEvent_("AdStopped"));
      }),
      (i.prototype.subscribe = function (t, e, i) {
        this.log("Subscribe " + t.name + " to event " + e),
          (this.eventListeners_[e] = (this.eventListeners_[e] || []).concat({
            callback: t,
            context: i,
          }));
      }),
      (i.prototype.unsubscribe = function (t, e) {
        this.eventListeners_[e] &&
          (this.log("Unsubscribe " + t.name + " from event " + e),
          (this.eventListeners_[e] = this.eventListeners_[e].filter(function (
            e
          ) {
            return e.callback !== t;
          })));
      }),
      (i.prototype.getAdWidth = function () {
        return this.attributes_.width;
      }),
      (i.prototype.getAdHeight = function () {
        return this.attributes_.height;
      }),
      (i.prototype.getAdRemainingTime = function () {
        var t = this.attributes_.remainingTime,
          e = t;
        return (
          this.videoSlot_ &&
            this.videoSlot_.currentTime &&
            (e = t - this.videoSlot_.currentTime),
          e
        );
      }),
      (i.prototype.getAdDuration = function () {
        return this.attributes_.duration;
      }),
      (i.prototype.getAdLinear = function () {
        return this.attributes_.linear;
      }),
      (i.prototype.getAdCompanions = function () {
        return this.attributes_.companions;
      }),
      (i.prototype.getAdIcons = function () {
        return this.attributes_.icons;
      }),
      (i.prototype.log = console.log.bind(console)),
      (i.prototype.getElement_ = function (t) {
        if (null != (e = document.getElementById(t))) return e;
        try {
          var e = parent.document.getElementById(t);
        } catch (t) {
          return null;
        }
        return e;
      }),
      (i.prototype.callEvent_ = function (t) {
        this.eventListeners_[t] &&
          this.eventListeners_[t].forEach(
            function (e) {
              var i = e.context || this,
                a = [];
              "AdClickThru" === t &&
                (a = [
                  this.parameters_ && this.parameters_.clickThruUrl,
                  this.parameters_ && this.parameters_.adCfid,
                  !0,
                ]);
              try {
                e.callback.apply(i, a);
              } catch (e) {
                this.log('Event callback "' + t + '" encountered an error.', e);
              }
            }.bind(this)
          );
      }),
      (window.getVPAIDAd = function () {
        return new i();
      });
  },
});
