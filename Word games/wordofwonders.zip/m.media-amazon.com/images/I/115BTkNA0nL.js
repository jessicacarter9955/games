var CREM;
(() => {
  "use strict";
  var e = {
      905: (e, a) => {
        Object.defineProperty(a, "__esModule", { value: !0 }),
          (a.evaluateBTRCriteria = a.MRC_BTR_CLASS = void 0),
          (a.MRC_BTR_CLASS = "mrc-btr-creative");
        var t = "visibilitychange",
          r = !1;
        a.evaluateBTRCriteria = function (e, a, i) {
          if (
            (window.addEventListener("pagehide", function () {
              r ||
                i({
                  isBTRCompliant: !1,
                  imagesData: [],
                  isBTRTaggedCreative: !0,
                  isFramed: !1,
                });
            }),
            d(e))
          ) {
            var s = function () {
              d(e) || (n(a, i), e.removeEventListener(t, s));
            };
            e.addEventListener(t, s);
          } else n(a, i);
        };
        var n = function (e, t) {
            var n = 0,
              o = setInterval(function () {
                var c = e.getElementsByTagName("img"),
                  v = e.getElementsByClassName(a.MRC_BTR_CLASS),
                  d = v.length > 0,
                  m = e.getElementsByTagName("iframe");
                d
                  ? (clearInterval(o), i(v, t))
                  : c.length > 0
                  ? (clearInterval(o), s(c, t))
                  : n >= 6 && m.length > 0
                  ? (clearInterval(o), l(m, t))
                  : n >= 20 &&
                    (clearInterval(o),
                    (r = !0),
                    t({
                      isBTRCompliant: !1,
                      imagesData: [],
                      isBTRTaggedCreative: !1,
                      isFramed: !1,
                    })),
                  n++;
              }, 500);
          },
          i = function (e, a) {
            var t = [],
              n = 0,
              i = 0,
              s = setInterval(function () {
                for (var l = 0; l < e.length; l++) {
                  var c = e[l];
                  c instanceof HTMLImageElement &&
                    (o(c)
                      ? ((t[l] = { src: c.src, isLoaded: !0 }), n++)
                      : (t[l] = { src: c.src, isLoaded: !1 }));
                }
                n > 0
                  ? (clearInterval(s),
                    (r = !0),
                    a({
                      isBTRCompliant: !0,
                      imagesData: t,
                      isBTRTaggedCreative: !0,
                      isFramed: !1,
                    }))
                  : i > 100 &&
                    (clearInterval(s),
                    (r = !0),
                    a({
                      isBTRCompliant: !1,
                      imagesData: t,
                      isBTRTaggedCreative: !0,
                      isFramed: !1,
                    })),
                  i++;
              }, 200);
          },
          s = function (e, a) {
            var t = [],
              n = 0,
              i = 0,
              s = setInterval(function () {
                for (var l = 0; l < e.length; l++) {
                  var v = e[l];
                  v instanceof HTMLImageElement &&
                    !c(v) &&
                    (o(v)
                      ? ((t[l] = { src: v.src, isLoaded: !0 }), i++)
                      : (t[l] = { src: v.src, isLoaded: !1 }));
                }
                i > 0
                  ? (clearInterval(s),
                    (r = !0),
                    a({
                      isBTRCompliant: !0,
                      imagesData: t,
                      isBTRTaggedCreative: !1,
                      isFramed: !1,
                    }))
                  : n >= 100 &&
                    (clearInterval(s),
                    (r = !0),
                    a({
                      isBTRCompliant: !1,
                      imagesData: t,
                      isBTRTaggedCreative: !1,
                      isFramed: !1,
                    })),
                  n++;
              }, 200);
          },
          l = function (e, a) {
            var t = [],
              n = 0,
              i = 0,
              s = setInterval(function () {
                for (var l = 0; l < e.length; l++) {
                  var o = e[l];
                  o instanceof HTMLIFrameElement && null != o.contentDocument
                    ? v(o)
                      ? ((t[l] = { src: o.src, isLoaded: !0 }), i++)
                      : (t[l] = { src: o.src, isLoaded: !1 })
                    : o instanceof HTMLIFrameElement &&
                      null == o.contentDocument &&
                      (clearInterval(s),
                      (r = !0),
                      a({
                        isBTRCompliant: !1,
                        imagesData: t,
                        isBTRTaggedCreative: !1,
                        isFramed: !0,
                      }));
                }
                (i > 0 || n >= 100) &&
                  (clearInterval(s),
                  (r = !0),
                  a({
                    isBTRCompliant: !1,
                    imagesData: t,
                    isBTRTaggedCreative: !1,
                    isFramed: !0,
                  })),
                  n++;
              }, 200);
          },
          o = function (e) {
            return e.naturalHeight > 0 && e.naturalWidth > 0;
          },
          c = function (e) {
            return 1 === e.naturalHeight && 1 === e.naturalWidth;
          },
          v = function (e) {
            return (
              "complete" ===
              (
                e.contentDocument ||
                (e.contentWindow && e.contentWindow.document) || {
                  readyState: !1,
                }
              ).readyState
            );
          },
          d = function (e) {
            return "prerender" === e.visibilityState;
          };
      },
    },
    a = {};
  function t(r) {
    var n = a[r];
    if (void 0 !== n) return n.exports;
    var i = (a[r] = { exports: {} });
    return e[r](i, i.exports, t), i.exports;
  }
  var r = {};
  (() => {
    var e = r;
    Object.defineProperty(e, "__esModule", { value: !0 }),
      (e.evaluateBTRCriteria = void 0);
    var a = t(905);
    Object.defineProperty(e, "evaluateBTRCriteria", {
      enumerable: !0,
      get: function () {
        return a.evaluateBTRCriteria;
      },
    });
  })(),
    (CREM = r);
})();
