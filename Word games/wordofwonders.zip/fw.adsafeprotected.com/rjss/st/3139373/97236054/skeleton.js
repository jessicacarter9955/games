var __IntegralASDiagnosticCall = (function () {
  try {
    var e = {};
    return function (t, n, i) {
      try {
        if (!__IASScope.isDomless)
          try {
            __IASScope.postMessage(
              { code: t, name: "jsdiag", origin: "ias" },
              "*"
            );
          } catch (e) {}
        !e[t] &&
          Math.random() < 0.01 &&
          ((e[t] = !0),
          (r = (function (e, t, n) {
            var i = "//diag.adsafeprotected.com/js?";
            try {
              var r =
                t && t.message
                  ? encodeURIComponent(t.message.replace(/ /g, "-")).substring(
                      0,
                      200
                    )
                  : "";
              if (
                ((i += "code:fwjs-diag-" + e),
                (i += "&err:" + r),
                (i += "&codeanderr:" + e + "_" + r),
                n)
              ) {
                let e = "";
                "undefined" != typeof store &&
                  store.adTag &&
                  store.adTag.asid &&
                  (e = String(store.adTag.asid)),
                  (i += "&version:" + n.version || ""),
                  (i += "&server:" + n.mn || ""),
                  (i += "&region:" + n.region || ""),
                  (i += "&mode:" + n.mode || ""),
                  (i += "&forceAppend:" + n.forceAppend || ""),
                  (i += "&asid:" + e),
                  (i += "&anId:" + n.anId || ""),
                  (i += "&advEntityId:" + n.advEntityId || ""),
                  (i += "&pubEntityId:" + n.pubEntityId || ""),
                  (i += "&mobOrTab:" + n.mobOrTab || ""),
                  (i += "&app:" + n.app || ""),
                  (i += "&mobAppWebview:" + n.mobAppWebview || "");
              }
              i += "&domless:" + __IASScope.isDomless;
            } catch (e) {
              i +=
                "&diagx:" +
                (e && e.message ? e.message.toString().replace(/ /g, "-") : "");
            }
            return i;
          })(t, n, i)),
          __IASScope.isDomless &&
          __IASOmidVerificationClient &&
          __IASOmidVerificationClient.sendUrl
            ? __IASOmidVerificationClient.sendUrl(r)
            : (new Image().src = r));
      } catch (e) {}
      var r;
    };
  } catch (e) {
    return function () {};
  }
})();
try {
  var __IntegralASConfig = {};
  try {
    (__IASScope = "undefined" != typeof window ? window : this),
      (__IntegralASConfig.isResolved = !!__IntegralASConfig.jsFeatures),
      (__IntegralASConfig.staticMode = !__IntegralASConfig.isResolved),
      (__IntegralASConfig.birthdate = new Date().getTime()),
      (__IntegralASConfig.perfBirth =
        void 0 !== __IASScope.performance &&
        "function" == typeof __IASScope.performance.now
          ? __IASScope.performance.now()
          : null),
      (function (e, t, n) {
        if ("object" == typeof n && "string" != typeof n.nodeName) t(e, n);
        else {
          n = {};
          var i = ["1.5.3-iab4563"];
          function r(e) {
            for (var t in e) e.hasOwnProperty(t) && (e[t] = r(e[t]));
            return Object.freeze(e);
          }
          for (var o in (t(e, n), n))
            n.hasOwnProperty(o) &&
              (null == Object.getOwnPropertyDescriptor(e, o) &&
                Object.defineProperty(e, o, { value: {} }),
              i.forEach(function (t) {
                if (null == Object.getOwnPropertyDescriptor(e[o], t)) {
                  var i = r(n[o]);
                  Object.defineProperty(e[o], t, {
                    get: function () {
                      return i;
                    },
                    enumerable: !0,
                  });
                }
              }));
        }
      })(
        "undefined" == typeof global ? this : global,
        function (omidGlobal, omidExports) {
          var $jscomp = $jscomp || {};
          ($jscomp.scope = {}),
            ($jscomp.createTemplateTagFirstArg = function (e) {
              return (e.raw = e);
            }),
            ($jscomp.createTemplateTagFirstArgWithRaw = function (e, t) {
              return (e.raw = t), e;
            }),
            ($jscomp.arrayIteratorImpl = function (e) {
              var t = 0;
              return function () {
                return t < e.length
                  ? { done: !1, value: e[t++] }
                  : { done: !0 };
              };
            }),
            ($jscomp.arrayIterator = function (e) {
              return { next: $jscomp.arrayIteratorImpl(e) };
            }),
            ($jscomp.makeIterator = function (e) {
              var t =
                "undefined" != typeof Symbol &&
                Symbol.iterator &&
                e[Symbol.iterator];
              if (t) return t.call(e);
              if ("number" == typeof e.length) return $jscomp.arrayIterator(e);
              throw Error(String(e) + " is not an iterable or ArrayLike");
            }),
            ($jscomp.arrayFromIterator = function (e) {
              for (var t, n = []; !(t = e.next()).done; ) n.push(t.value);
              return n;
            }),
            ($jscomp.arrayFromIterable = function (e) {
              return e instanceof Array
                ? e
                : $jscomp.arrayFromIterator($jscomp.makeIterator(e));
            }),
            ($jscomp.ASSUME_ES5 = !1),
            ($jscomp.ASSUME_NO_NATIVE_MAP = !1),
            ($jscomp.ASSUME_NO_NATIVE_SET = !1),
            ($jscomp.SIMPLE_FROUND_POLYFILL = !1),
            ($jscomp.ISOLATE_POLYFILLS = !1),
            ($jscomp.FORCE_POLYFILL_PROMISE = !1),
            ($jscomp.FORCE_POLYFILL_PROMISE_WHEN_NO_UNHANDLED_REJECTION = !1),
            ($jscomp.objectCreate =
              $jscomp.ASSUME_ES5 || "function" == typeof Object.create
                ? Object.create
                : function (e) {
                    var t = function () {};
                    return (t.prototype = e), new t();
                  }),
            ($jscomp.defineProperty =
              $jscomp.ASSUME_ES5 || "function" == typeof Object.defineProperties
                ? Object.defineProperty
                : function (e, t, n) {
                    return (
                      e == Array.prototype ||
                        e == Object.prototype ||
                        (e[t] = n.value),
                      e
                    );
                  }),
            ($jscomp.getGlobal = function (e) {
              e = [
                "object" == typeof globalThis && globalThis,
                e,
                "object" == typeof window && window,
                "object" == typeof self && self,
                "object" == typeof global && global,
              ];
              for (var t = 0; t < e.length; ++t) {
                var n = e[t];
                if (n && n.Math == Math) return n;
              }
              throw Error("Cannot find global object");
            }),
            ($jscomp.global = $jscomp.getGlobal(this)),
            ($jscomp.IS_SYMBOL_NATIVE =
              "function" == typeof Symbol && "symbol" == typeof Symbol("x")),
            ($jscomp.TRUST_ES6_POLYFILLS =
              !$jscomp.ISOLATE_POLYFILLS || $jscomp.IS_SYMBOL_NATIVE),
            ($jscomp.polyfills = {}),
            ($jscomp.propertyToPolyfillSymbol = {}),
            ($jscomp.POLYFILL_PREFIX = "$jscp$");
          var $jscomp$lookupPolyfilledValue = function (e, t, n) {
            if (!n || null != e)
              return null == (n = $jscomp.propertyToPolyfillSymbol[t])
                ? e[t]
                : void 0 !== (n = e[n])
                ? n
                : e[t];
          };
          ($jscomp.polyfill = function (e, t, n, i) {
            t &&
              ($jscomp.ISOLATE_POLYFILLS
                ? $jscomp.polyfillIsolated(e, t, n, i)
                : $jscomp.polyfillUnisolated(e, t, n, i));
          }),
            ($jscomp.polyfillUnisolated = function (e, t, n, i) {
              for (
                n = $jscomp.global, e = e.split("."), i = 0;
                i < e.length - 1;
                i++
              ) {
                var r = e[i];
                if (!(r in n)) return;
                n = n[r];
              }
              (t = t((i = n[(e = e[e.length - 1])]))) != i &&
                null != t &&
                $jscomp.defineProperty(n, e, {
                  configurable: !0,
                  writable: !0,
                  value: t,
                });
            }),
            ($jscomp.polyfillIsolated = function (e, t, n, i) {
              var r = e.split(".");
              (e = 1 === r.length),
                (i = r[0]),
                (i =
                  !e && i in $jscomp.polyfills
                    ? $jscomp.polyfills
                    : $jscomp.global);
              for (var o = 0; o < r.length - 1; o++) {
                var s = r[o];
                if (!(s in i)) return;
                i = i[s];
              }
              (r = r[r.length - 1]),
                null !=
                  (t = t(
                    (n = $jscomp.IS_SYMBOL_NATIVE && "es6" === n ? i[r] : null)
                  )) &&
                  (e
                    ? $jscomp.defineProperty($jscomp.polyfills, r, {
                        configurable: !0,
                        writable: !0,
                        value: t,
                      })
                    : t !== n &&
                      (void 0 === $jscomp.propertyToPolyfillSymbol[r] &&
                        ((n = (1e9 * Math.random()) >>> 0),
                        ($jscomp.propertyToPolyfillSymbol[r] =
                          $jscomp.IS_SYMBOL_NATIVE
                            ? $jscomp.global.Symbol(r)
                            : $jscomp.POLYFILL_PREFIX + n + "$" + r)),
                      $jscomp.defineProperty(
                        i,
                        $jscomp.propertyToPolyfillSymbol[r],
                        { configurable: !0, writable: !0, value: t }
                      )));
            }),
            ($jscomp.getConstructImplementation = function () {
              if (
                $jscomp.TRUST_ES6_POLYFILLS &&
                "undefined" != typeof Reflect &&
                Reflect.construct
              ) {
                if (
                  (function () {
                    function e() {}
                    return (
                      new e(),
                      Reflect.construct(e, [], function () {}),
                      new e() instanceof e
                    );
                  })()
                )
                  return Reflect.construct;
                var e = Reflect.construct;
                return function (t, n, i) {
                  return (
                    (t = e(t, n)),
                    i && Reflect.setPrototypeOf(t, i.prototype),
                    t
                  );
                };
              }
              return function (e, t, n) {
                return (
                  void 0 === n && (n = e),
                  (n = $jscomp.objectCreate(n.prototype || Object.prototype)),
                  Function.prototype.apply.call(e, n, t) || n
                );
              };
            }),
            ($jscomp.construct = $jscomp.getConstructImplementation()),
            ($jscomp.underscoreProtoCanBeSet = function () {
              var e = {};
              try {
                return (e.__proto__ = { a: !0 }), e.a;
              } catch (e) {}
              return !1;
            }),
            ($jscomp.setPrototypeOf =
              $jscomp.TRUST_ES6_POLYFILLS &&
              "function" == typeof Object.setPrototypeOf
                ? Object.setPrototypeOf
                : $jscomp.underscoreProtoCanBeSet()
                ? function (e, t) {
                    if (((e.__proto__ = t), e.__proto__ !== t))
                      throw new TypeError(e + " is not extensible");
                    return e;
                  }
                : null),
            ($jscomp.inherits = function (e, t) {
              if (
                ((e.prototype = $jscomp.objectCreate(t.prototype)),
                (e.prototype.constructor = e),
                $jscomp.setPrototypeOf)
              ) {
                var n = $jscomp.setPrototypeOf;
                n(e, t);
              } else
                for (n in t)
                  if ("prototype" != n)
                    if (Object.defineProperties) {
                      var i = Object.getOwnPropertyDescriptor(t, n);
                      i && Object.defineProperty(e, n, i);
                    } else e[n] = t[n];
              e.superClass_ = t.prototype;
            }),
            ($jscomp.getRestArguments = function () {
              for (
                var e = Number(this), t = [], n = e;
                n < arguments.length;
                n++
              )
                t[n - e] = arguments[n];
              return t;
            }),
            $jscomp.polyfill(
              "Reflect",
              function (e) {
                return e || {};
              },
              "es6",
              "es3"
            ),
            $jscomp.polyfill(
              "Reflect.construct",
              function (e) {
                return $jscomp.construct;
              },
              "es6",
              "es3"
            ),
            $jscomp.polyfill(
              "Reflect.setPrototypeOf",
              function (e) {
                if (e) return e;
                if ($jscomp.setPrototypeOf) {
                  var t = $jscomp.setPrototypeOf;
                  return function (e, n) {
                    try {
                      return t(e, n), !0;
                    } catch (e) {
                      return !1;
                    }
                  };
                }
                return null;
              },
              "es6",
              "es5"
            ),
            ($jscomp.owns = function (e, t) {
              return Object.prototype.hasOwnProperty.call(e, t);
            }),
            $jscomp.polyfill(
              "Object.values",
              function (e) {
                return (
                  e ||
                  function (e) {
                    var t,
                      n = [];
                    for (t in e) $jscomp.owns(e, t) && n.push(e[t]);
                    return n;
                  }
                );
              },
              "es8",
              "es3"
            );
          var module$exports$omid$common$constants = {
              AdEventType: {
                IMPRESSION: "impression",
                LOADED: "loaded",
                GEOMETRY_CHANGE: "geometryChange",
                SESSION_START: "sessionStart",
                SESSION_ERROR: "sessionError",
                SESSION_FINISH: "sessionFinish",
                MEDIA: "media",
                VIDEO: "video",
                START: "start",
                FIRST_QUARTILE: "firstQuartile",
                MIDPOINT: "midpoint",
                THIRD_QUARTILE: "thirdQuartile",
                COMPLETE: "complete",
                PAUSE: "pause",
                RESUME: "resume",
                BUFFER_START: "bufferStart",
                BUFFER_FINISH: "bufferFinish",
                SKIPPED: "skipped",
                VOLUME_CHANGE: "volumeChange",
                PLAYER_STATE_CHANGE: "playerStateChange",
                AD_USER_INTERACTION: "adUserInteraction",
                STATE_CHANGE: "stateChange",
              },
              MediaEventType: {
                LOADED: "loaded",
                START: "start",
                FIRST_QUARTILE: "firstQuartile",
                MIDPOINT: "midpoint",
                THIRD_QUARTILE: "thirdQuartile",
                COMPLETE: "complete",
                PAUSE: "pause",
                RESUME: "resume",
                BUFFER_START: "bufferStart",
                BUFFER_FINISH: "bufferFinish",
                SKIPPED: "skipped",
                VOLUME_CHANGE: "volumeChange",
                PLAYER_STATE_CHANGE: "playerStateChange",
                AD_USER_INTERACTION: "adUserInteraction",
              },
              ImpressionType: {
                DEFINED_BY_JAVASCRIPT: "definedByJavaScript",
                UNSPECIFIED: "unspecified",
                LOADED: "loaded",
                BEGIN_TO_RENDER: "beginToRender",
                ONE_PIXEL: "onePixel",
                VIEWABLE: "viewable",
                AUDIBLE: "audible",
                OTHER: "other",
              },
              ErrorType: { GENERIC: "generic", VIDEO: "video", MEDIA: "media" },
              AdSessionType: {
                NATIVE: "native",
                HTML: "html",
                JAVASCRIPT: "javascript",
              },
              EventOwner: {
                NATIVE: "native",
                JAVASCRIPT: "javascript",
                NONE: "none",
              },
              SessionOwner: { JAVASCRIPT: "javascript", NATIVE: "native" },
              AccessMode: {
                FULL: "full",
                DOMAIN: "domain",
                LIMITED: "limited",
              },
              AppState: {
                BACKGROUNDED: "backgrounded",
                FOREGROUNDED: "foregrounded",
              },
              DeviceLockState: { LOCKED: "locked", UNLOCKED: "unlocked" },
              Environment: { APP: "app", WEB: "web" },
              DeviceCategory: {
                CTV: "ctv",
                DESKTOP: "desktop",
                MOBILE: "mobile",
                OTHER: "other",
              },
              InteractionType: {
                CLICK: "click",
                INVITATION_ACCEPT: "invitationAccept",
              },
              CreativeType: {
                DEFINED_BY_JAVASCRIPT: "definedByJavaScript",
                HTML_DISPLAY: "htmlDisplay",
                NATIVE_DISPLAY: "nativeDisplay",
                VIDEO: "video",
                AUDIO: "audio",
              },
              MediaType: { DISPLAY: "display", VIDEO: "video" },
              Reason: {
                NOT_FOUND: "notFound",
                HIDDEN: "hidden",
                BACKGROUNDED: "backgrounded",
                PICTURE_IN_PICTURE: "pictureInPicture",
                DEVICE_LOCKED: "deviceLocked",
                VIEWPORT: "viewport",
                OBSTRUCTED: "obstructed",
                CLIPPED: "clipped",
                UNMEASURABLE: "unmeasurable",
                NO_WINDOW_FOCUS: "noWindowFocus",
                NO_OUTPUT_DEVICE: "noOutputDevice",
              },
              SupportedFeatures: { CONTAINER: "clid", VIDEO: "vlid" },
              VideoPosition: {
                PREROLL: "preroll",
                MIDROLL: "midroll",
                POSTROLL: "postroll",
                STANDALONE: "standalone",
              },
              VideoPlayerState: {
                MINIMIZED: "minimized",
                COLLAPSED: "collapsed",
                NORMAL: "normal",
                EXPANDED: "expanded",
                FULLSCREEN: "fullscreen",
              },
              NativeViewKeys: {
                X: "x",
                LEFT: "left",
                Y: "y",
                TOP: "top",
                WIDTH: "width",
                HEIGHT: "height",
                AD_SESSION_ID: "adSessionId",
                IS_FRIENDLY_OBSTRUCTION_FOR: "isFriendlyObstructionFor",
                CLIPS_TO_BOUNDS: "clipsToBounds",
                CHILD_VIEWS: "childViews",
                END_X: "endX",
                END_Y: "endY",
                OBSTRUCTIONS: "obstructions",
                OBSTRUCTION_CLASS: "obstructionClass",
                OBSTRUCTION_PURPOSE: "obstructionPurpose",
                OBSTRUCTION_REASON: "obstructionReason",
                PIXELS: "pixels",
                HAS_WINDOW_FOCUS: "hasWindowFocus",
              },
              MeasurementStateChangeSource: {
                CONTAINER: "container",
                CREATIVE: "creative",
              },
              ElementMarkup: { OMID_ELEMENT_CLASS_NAME: "omid-element" },
              CommunicationType: {
                NONE: "NONE",
                DIRECT: "DIRECT",
                POST_MESSAGE: "POST_MESSAGE",
              },
              OmidImplementer: { OMSDK: "omsdk" },
              MessageMethod: {
                IDENTIFY_SERVICE_WINDOW: "identifyServiceWindow",
              },
            },
            module$contents$omid$common$InternalMessage_GUID_KEY =
              "omid_message_guid",
            module$contents$omid$common$InternalMessage_METHOD_KEY =
              "omid_message_method",
            module$contents$omid$common$InternalMessage_VERSION_KEY =
              "omid_message_version",
            module$contents$omid$common$InternalMessage_ARGS_KEY =
              "omid_message_args",
            module$exports$omid$common$InternalMessage = function (e, t, n, i) {
              (this.guid = e),
                (this.method = t),
                (this.version = n),
                (this.args = i);
            };
          (module$exports$omid$common$InternalMessage.isValidSerializedMessage =
            function (e) {
              return (
                !!e &&
                void 0 !==
                  e[module$contents$omid$common$InternalMessage_GUID_KEY] &&
                void 0 !==
                  e[module$contents$omid$common$InternalMessage_METHOD_KEY] &&
                void 0 !==
                  e[module$contents$omid$common$InternalMessage_VERSION_KEY] &&
                "string" ==
                  typeof e[
                    module$contents$omid$common$InternalMessage_GUID_KEY
                  ] &&
                "string" ==
                  typeof e[
                    module$contents$omid$common$InternalMessage_METHOD_KEY
                  ] &&
                "string" ==
                  typeof e[
                    module$contents$omid$common$InternalMessage_VERSION_KEY
                  ] &&
                (void 0 ===
                  e[module$contents$omid$common$InternalMessage_ARGS_KEY] ||
                  void 0 !==
                    e[module$contents$omid$common$InternalMessage_ARGS_KEY])
              );
            }),
            (module$exports$omid$common$InternalMessage.deserialize = function (
              e
            ) {
              return new module$exports$omid$common$InternalMessage(
                e[module$contents$omid$common$InternalMessage_GUID_KEY],
                e[module$contents$omid$common$InternalMessage_METHOD_KEY],
                e[module$contents$omid$common$InternalMessage_VERSION_KEY],
                e[module$contents$omid$common$InternalMessage_ARGS_KEY]
              );
            }),
            (module$exports$omid$common$InternalMessage.prototype.serialize =
              function () {
                var e = {};
                return (
                  (e[module$contents$omid$common$InternalMessage_GUID_KEY] =
                    this.guid),
                  (e[module$contents$omid$common$InternalMessage_METHOD_KEY] =
                    this.method),
                  (e[module$contents$omid$common$InternalMessage_VERSION_KEY] =
                    this.version),
                  (e = e),
                  void 0 !== this.args &&
                    (e[module$contents$omid$common$InternalMessage_ARGS_KEY] =
                      this.args),
                  e
                );
              });
          var module$exports$omid$common$Communication = function (e) {
            (this.to = e),
              (this.communicationType_ =
                module$exports$omid$common$constants.CommunicationType.NONE);
          };
          (module$exports$omid$common$Communication.prototype.sendMessage =
            function (e, t) {}),
            (module$exports$omid$common$Communication.prototype.handleMessage =
              function (e, t) {
                this.onMessage && this.onMessage(e, t);
              }),
            (module$exports$omid$common$Communication.prototype.serialize =
              function (e) {
                return JSON.stringify(e);
              }),
            (module$exports$omid$common$Communication.prototype.deserialize =
              function (e) {
                return JSON.parse(e);
              }),
            (module$exports$omid$common$Communication.prototype.isDirectCommunication =
              function () {
                return (
                  this.communicationType_ ===
                  module$exports$omid$common$constants.CommunicationType.DIRECT
                );
              }),
            (module$exports$omid$common$Communication.prototype.isCrossOrigin =
              function () {});
          var module$exports$omid$common$logger = {};
          function module$contents$omid$common$logger_error() {
            var e = $jscomp.getRestArguments.apply(0, arguments);
            module$contents$omid$common$logger_executeLog(
              function () {
                throw new (Function.prototype.bind.apply(
                  Error,
                  [null, "Could not complete the test successfully - "].concat(
                    $jscomp.arrayFromIterable(e)
                  )
                ))();
              },
              function () {
                return console.error.apply(
                  console,
                  $jscomp.arrayFromIterable(e)
                );
              }
            );
          }
          function module$contents$omid$common$logger_debug() {
            var e = $jscomp.getRestArguments.apply(0, arguments);
            module$contents$omid$common$logger_executeLog(
              function () {},
              function () {
                return console.error.apply(
                  console,
                  $jscomp.arrayFromIterable(e)
                );
              }
            );
          }
          function module$contents$omid$common$logger_executeLog(e, t) {
            "undefined" != typeof jasmine && jasmine
              ? e()
              : "undefined" != typeof console &&
                console &&
                console.error &&
                t();
          }
          (module$exports$omid$common$logger.error =
            module$contents$omid$common$logger_error),
            (module$exports$omid$common$logger.debug =
              module$contents$omid$common$logger_debug);
          var module$exports$omid$common$eventTypedefs = {},
            module$exports$omid$common$version = {
              ApiVersion: "1.0",
              Version: "1.5.3-iab4563",
            },
            module$exports$omid$common$argsChecker = {};
          function module$contents$omid$common$argsChecker_assertTruthyString(
            e,
            t
          ) {
            if (!t)
              throw Error("Value for " + e + " is undefined, null or blank.");
            if ("string" != typeof t && !(t instanceof String))
              throw Error("Value for " + e + " is not a string.");
            if ("" === t.trim())
              throw Error("Value for " + e + " is empty string.");
          }
          function module$contents$omid$common$argsChecker_assertNotNullObject(
            e,
            t
          ) {
            if (null == t)
              throw Error("Value for " + e + " is undefined or null");
          }
          function module$contents$omid$common$argsChecker_assertNumber(e, t) {
            if (null == t) throw Error(e + " must not be null or undefined.");
            if ("number" != typeof t || isNaN(t))
              throw Error("Value for " + e + " is not a number");
          }
          function module$contents$omid$common$argsChecker_assertNumberBetween(
            e,
            t,
            n,
            i
          ) {
            if (
              (module$contents$omid$common$argsChecker_assertNumber(e, t),
              t < n || t > i)
            )
              throw Error(
                "Value for " + e + " is outside the range [" + n + "," + i + "]"
              );
          }
          function module$contents$omid$common$argsChecker_assertFunction(
            e,
            t
          ) {
            if (!t) throw Error(e + " must not be truthy.");
          }
          function module$contents$omid$common$argsChecker_assertPositiveNumber(
            e,
            t
          ) {
            if (
              (module$contents$omid$common$argsChecker_assertNumber(e, t),
              0 > t)
            )
              throw Error(e + " must be a positive number.");
          }
          (module$exports$omid$common$argsChecker.assertTruthyString =
            module$contents$omid$common$argsChecker_assertTruthyString),
            (module$exports$omid$common$argsChecker.assertNotNullObject =
              module$contents$omid$common$argsChecker_assertNotNullObject),
            (module$exports$omid$common$argsChecker.assertNumber =
              module$contents$omid$common$argsChecker_assertNumber),
            (module$exports$omid$common$argsChecker.assertNumberBetween =
              module$contents$omid$common$argsChecker_assertNumberBetween),
            (module$exports$omid$common$argsChecker.assertFunction =
              module$contents$omid$common$argsChecker_assertFunction),
            (module$exports$omid$common$argsChecker.assertPositiveNumber =
              module$contents$omid$common$argsChecker_assertPositiveNumber);
          var module$exports$omid$common$VersionUtils = {},
            module$contents$omid$common$VersionUtils_SEMVER_DIGITS_NUMBER = 3;
          function module$contents$omid$common$VersionUtils_isValidVersion(e) {
            return /\d+\.\d+\.\d+(-.*)?/.test(e);
          }
          function module$contents$omid$common$VersionUtils_versionGreaterOrEqual(
            e,
            t
          ) {
            (e = e.split("-")[0].split(".")), (t = t.split("-")[0].split("."));
            for (
              var n = 0;
              n < module$contents$omid$common$VersionUtils_SEMVER_DIGITS_NUMBER;
              n++
            ) {
              var i = parseInt(e[n], 10),
                r = parseInt(t[n], 10);
              if (i > r) break;
              if (i < r) return !1;
            }
            return !0;
          }
          (module$exports$omid$common$VersionUtils.isValidVersion =
            module$contents$omid$common$VersionUtils_isValidVersion),
            (module$exports$omid$common$VersionUtils.versionGreaterOrEqual =
              module$contents$omid$common$VersionUtils_versionGreaterOrEqual);
          var module$exports$omid$common$ArgsSerDe = {},
            module$contents$omid$common$ArgsSerDe_ARGS_NOT_SERIALIZED_VERSION =
              "1.0.3";
          function module$contents$omid$common$ArgsSerDe_serializeMessageArgs(
            e,
            t
          ) {
            return module$contents$omid$common$VersionUtils_isValidVersion(e) &&
              module$contents$omid$common$VersionUtils_versionGreaterOrEqual(
                e,
                module$contents$omid$common$ArgsSerDe_ARGS_NOT_SERIALIZED_VERSION
              )
              ? t
              : JSON.stringify(t);
          }
          function module$contents$omid$common$ArgsSerDe_deserializeMessageArgs(
            e,
            t
          ) {
            return module$contents$omid$common$VersionUtils_isValidVersion(e) &&
              module$contents$omid$common$VersionUtils_versionGreaterOrEqual(
                e,
                module$contents$omid$common$ArgsSerDe_ARGS_NOT_SERIALIZED_VERSION
              )
              ? t || []
              : t && "string" == typeof t
              ? JSON.parse(t)
              : [];
          }
          (module$exports$omid$common$ArgsSerDe.serializeMessageArgs =
            module$contents$omid$common$ArgsSerDe_serializeMessageArgs),
            (module$exports$omid$common$ArgsSerDe.deserializeMessageArgs =
              module$contents$omid$common$ArgsSerDe_deserializeMessageArgs);
          var module$exports$omid$common$guid = {};
          function module$contents$omid$common$guid_generateGuid() {
            return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(
              /[xy]/g,
              function (e) {
                var t = (16 * Math.random()) | 0;
                return (e =
                  "y" === e ? ((3 & t) | 8).toString(16) : t.toString(16));
              }
            );
          }
          module$exports$omid$common$guid.generateGuid =
            module$contents$omid$common$guid_generateGuid;
          var module$exports$omid$common$DetectOmid = {
            OMID_PRESENT_FRAME_NAME: "omid_v1_present",
            OMID_PRESENT_FRAME_NAME_WEB: "omid_v1_present_web",
            OMID_PRESENT_FRAME_NAME_APP: "omid_v1_present_app",
            getEnvironmentIframeName: function (e) {
              var t = {};
              return ((t[module$exports$omid$common$constants.Environment.APP] =
                module$exports$omid$common$DetectOmid.OMID_PRESENT_FRAME_NAME_APP),
              (t[module$exports$omid$common$constants.Environment.WEB] =
                module$exports$omid$common$DetectOmid.OMID_PRESENT_FRAME_NAME_WEB),
              t)[e];
            },
          };
          function module$contents$omid$common$DetectOmid_isIframePresent(
            e,
            t
          ) {
            try {
              return e.frames && !!e.frames[t];
            } catch (e) {
              return !1;
            }
          }
          function module$contents$omid$common$DetectOmid_writePresenceIframe_(
            e,
            t
          ) {
            e.document.write(
              '<iframe style="display:none" id="' +
                t +
                '" name="' +
                t +
                '" sandbox></iframe>'
            );
          }
          (module$exports$omid$common$DetectOmid.isOmidPresent = function (e) {
            return [
              module$exports$omid$common$DetectOmid.OMID_PRESENT_FRAME_NAME,
              module$exports$omid$common$DetectOmid.OMID_PRESENT_FRAME_NAME_WEB,
              module$exports$omid$common$DetectOmid.OMID_PRESENT_FRAME_NAME_APP,
            ].some(function (t) {
              return module$contents$omid$common$DetectOmid_isIframePresent(
                e,
                t
              );
            });
          }),
            (module$exports$omid$common$DetectOmid.getOmidEnvironment =
              function (e) {
                for (
                  var t = $jscomp.makeIterator(
                      Object.values(
                        module$exports$omid$common$constants.Environment
                      )
                    ),
                    n = t.next();
                  !n.done;
                  n = t.next()
                ) {
                  if (
                    ((n = n.value),
                    module$contents$omid$common$DetectOmid_isIframePresent(
                      e,
                      module$exports$omid$common$DetectOmid.getEnvironmentIframeName(
                        n
                      )
                    ))
                  )
                    return n;
                }
                return null;
              }),
            (module$exports$omid$common$DetectOmid.declareOmidPresence =
              function (e, t) {
                e.frames &&
                  e.document &&
                  ![
                    module$exports$omid$common$DetectOmid.OMID_PRESENT_FRAME_NAME,
                    module$exports$omid$common$DetectOmid.OMID_PRESENT_FRAME_NAME_WEB,
                    module$exports$omid$common$DetectOmid.OMID_PRESENT_FRAME_NAME_APP,
                  ].some(function (t) {
                    return !!e.frames[t];
                  }) &&
                  (null == e.document.body &&
                  module$exports$omid$common$DetectOmid.isMutationObserverAvailable_(
                    e
                  )
                    ? module$exports$omid$common$DetectOmid.registerMutationObserver_(
                        e,
                        t
                      )
                    : ((t =
                        module$exports$omid$common$DetectOmid.getEnvironmentIframeName(
                          t
                        )),
                      e.document.body
                        ? (module$exports$omid$common$DetectOmid.appendPresenceIframe_(
                            e,
                            module$exports$omid$common$DetectOmid.OMID_PRESENT_FRAME_NAME
                          ),
                          module$exports$omid$common$DetectOmid.appendPresenceIframe_(
                            e,
                            t
                          ))
                        : (module$contents$omid$common$DetectOmid_writePresenceIframe_(
                            e,
                            module$exports$omid$common$DetectOmid.OMID_PRESENT_FRAME_NAME
                          ),
                          module$contents$omid$common$DetectOmid_writePresenceIframe_(
                            e,
                            t
                          ))));
              }),
            (module$exports$omid$common$DetectOmid.appendPresenceIframe_ =
              function (e, t) {
                var n = e.document.createElement("iframe");
                (n.id = t),
                  (n.name = t),
                  (n.style.display = "none"),
                  (n.sandbox = ""),
                  e.document.body.appendChild(n);
              }),
            (module$exports$omid$common$DetectOmid.isMutationObserverAvailable_ =
              function (e) {
                return "MutationObserver" in e;
              }),
            (module$exports$omid$common$DetectOmid.registerMutationObserver_ =
              function (e, t) {
                var n = new MutationObserver(function (i) {
                  i.forEach(function (i) {
                    "BODY" === i.addedNodes[0].nodeName &&
                      ((i =
                        module$exports$omid$common$DetectOmid.getEnvironmentIframeName(
                          t
                        )),
                      module$exports$omid$common$DetectOmid.appendPresenceIframe_(
                        e,
                        module$exports$omid$common$DetectOmid.OMID_PRESENT_FRAME_NAME
                      ),
                      module$exports$omid$common$DetectOmid.appendPresenceIframe_(
                        e,
                        i
                      ),
                      n.disconnect());
                  });
                });
                n.observe(e.document.documentElement, { childList: !0 });
              });
          var module$exports$omid$common$serviceMethodUtils = {},
            module$contents$omid$common$serviceMethodUtils_ServiceMethodPrefix =
              {
                SESSION_SERVICE: "SessionService.",
                VERIFICATION_SERVICE: "VerificationService.",
              };
          function module$contents$omid$common$serviceMethodUtils_getPrefixedSessionServiceMethod(
            e
          ) {
            return module$contents$omid$common$serviceMethodUtils_getPrefixedMethod(
              e,
              module$contents$omid$common$serviceMethodUtils_ServiceMethodPrefix.SESSION_SERVICE
            );
          }
          function module$contents$omid$common$serviceMethodUtils_getUnprefixedSessionServiceMethod(
            e
          ) {
            return module$contents$omid$common$serviceMethodUtils_getUnprefixedMethod(
              e,
              module$contents$omid$common$serviceMethodUtils_ServiceMethodPrefix.SESSION_SERVICE
            );
          }
          function module$contents$omid$common$serviceMethodUtils_isPrefixedSessionServiceMethod(
            e
          ) {
            return (
              null !=
              module$contents$omid$common$serviceMethodUtils_getUnprefixedSessionServiceMethod(
                e
              )
            );
          }
          function module$contents$omid$common$serviceMethodUtils_getPrefixedVerificationServiceMethod(
            e
          ) {
            return module$contents$omid$common$serviceMethodUtils_getPrefixedMethod(
              e,
              module$contents$omid$common$serviceMethodUtils_ServiceMethodPrefix.VERIFICATION_SERVICE
            );
          }
          function module$contents$omid$common$serviceMethodUtils_getUnprefixedVerificationServiceMethod(
            e
          ) {
            return module$contents$omid$common$serviceMethodUtils_getUnprefixedMethod(
              e,
              module$contents$omid$common$serviceMethodUtils_ServiceMethodPrefix.VERIFICATION_SERVICE
            );
          }
          function module$contents$omid$common$serviceMethodUtils_isPrefixedVerificationServiceMethod(
            e
          ) {
            return (
              null !=
              module$contents$omid$common$serviceMethodUtils_getUnprefixedVerificationServiceMethod(
                e
              )
            );
          }
          function module$contents$omid$common$serviceMethodUtils_getPrefixedMethod(
            e,
            t
          ) {
            return t + e;
          }
          function module$contents$omid$common$serviceMethodUtils_getUnprefixedMethod(
            e,
            t
          ) {
            return (e = e.match(new RegExp("^" + t + "(.*)"))) && e[1];
          }
          (module$exports$omid$common$serviceMethodUtils.getPrefixedSessionServiceMethod =
            module$contents$omid$common$serviceMethodUtils_getPrefixedSessionServiceMethod),
            (module$exports$omid$common$serviceMethodUtils.getPrefixedVerificationServiceMethod =
              module$contents$omid$common$serviceMethodUtils_getPrefixedVerificationServiceMethod),
            (module$exports$omid$common$serviceMethodUtils.getUnprefixedSessionServiceMethod =
              module$contents$omid$common$serviceMethodUtils_getUnprefixedSessionServiceMethod),
            (module$exports$omid$common$serviceMethodUtils.getUnprefixedVerificationServiceMethod =
              module$contents$omid$common$serviceMethodUtils_getUnprefixedVerificationServiceMethod),
            (module$exports$omid$common$serviceMethodUtils.isPrefixedSessionServiceMethod =
              module$contents$omid$common$serviceMethodUtils_isPrefixedSessionServiceMethod),
            (module$exports$omid$common$serviceMethodUtils.isPrefixedVerificationServiceMethod =
              module$contents$omid$common$serviceMethodUtils_isPrefixedVerificationServiceMethod);
          var module$exports$omid$common$OmidGlobalProvider = {};
          function module$contents$omid$common$OmidGlobalProvider_getOmidGlobal() {
            if (void 0 !== omidGlobal && omidGlobal) return omidGlobal;
            if ("undefined" != typeof global && global) return global;
            if ("undefined" != typeof window && window) return window;
            if ("undefined" != typeof globalThis && globalThis)
              return globalThis;
            var e = Function("return this")();
            if (e) return e;
            throw Error("Could not determine global object context.");
          }
          module$exports$omid$common$OmidGlobalProvider.omidGlobal =
            module$contents$omid$common$OmidGlobalProvider_getOmidGlobal();
          var module$exports$omid$common$exporter = {};
          function module$contents$omid$common$exporter_getOmidExports() {
            return void 0 === omidExports ? null : omidExports;
          }
          function module$contents$omid$common$exporter_getOrCreateName(e, t) {
            return e && (e[t] || (e[t] = {}));
          }
          function module$contents$omid$common$exporter_packageExport(e, t, n) {
            (n =
              void 0 === n
                ? module$contents$omid$common$exporter_getOmidExports()
                : n) &&
              ((e = e.split("."))
                .slice(0, e.length - 1)
                .reduce(
                  module$contents$omid$common$exporter_getOrCreateName,
                  n
                )[e[e.length - 1]] = t);
          }
          module$exports$omid$common$exporter.packageExport =
            module$contents$omid$common$exporter_packageExport;
          var module$exports$omid$common$windowUtils = {};
          function module$contents$omid$common$windowUtils_isValidWindow(e) {
            return null != e && void 0 !== e.top && null != e.top;
          }
          function module$contents$omid$common$windowUtils_isCrossOrigin(e) {
            if (e === module$exports$omid$common$OmidGlobalProvider.omidGlobal)
              return !1;
            try {
              if (void 0 === e.location.hostname) return !0;
              module$contents$omid$common$windowUtils_isSameOriginForIE(e);
            } catch (e) {
              return !0;
            }
            return !1;
          }
          function module$contents$omid$common$windowUtils_isSameOriginForIE(
            e
          ) {
            return "" === e.x || "" !== e.x;
          }
          function module$contents$omid$common$windowUtils_resolveGlobalContext(
            e
          ) {
            return (
              void 0 === e &&
                "undefined" != typeof window &&
                window &&
                (e = window),
              module$contents$omid$common$windowUtils_isValidWindow(e)
                ? e
                : module$exports$omid$common$OmidGlobalProvider.omidGlobal
            );
          }
          function module$contents$omid$common$windowUtils_resolveTopWindowContext(
            e
          ) {
            return module$contents$omid$common$windowUtils_isValidWindow(e)
              ? e.top
              : module$exports$omid$common$OmidGlobalProvider.omidGlobal;
          }
          function module$contents$omid$common$windowUtils_isTopWindowAccessible(
            e
          ) {
            try {
              return !!e.top.location.href;
            } catch (e) {
              return !1;
            }
          }
          function module$contents$omid$common$windowUtils_removeDomElements(
            e
          ) {
            return (
              e.type ===
                module$exports$omid$common$constants.AdEventType
                  .SESSION_START &&
                (void 0 !== e.data.context.videoElement &&
                  (e.data.context.videoElement =
                    "Video Element (" + e.data.context.videoElement.id + ")"),
                void 0 !== e.data.context.slotElement &&
                  (e.data.context.slotElement =
                    "Slot Element (" + e.data.context.slotElement.id + ")")),
              e
            );
          }
          function module$contents$omid$common$windowUtils_evaluatePageUrl(e) {
            if (!module$contents$omid$common$windowUtils_isValidWindow(e))
              return null;
            try {
              var t = e.top;
              return module$contents$omid$common$windowUtils_isCrossOrigin(t)
                ? null
                : t.location.href;
            } catch (e) {
              return null;
            }
          }
          (module$exports$omid$common$windowUtils.evaluatePageUrl =
            module$contents$omid$common$windowUtils_evaluatePageUrl),
            (module$exports$omid$common$windowUtils.isCrossOrigin =
              module$contents$omid$common$windowUtils_isCrossOrigin),
            (module$exports$omid$common$windowUtils.removeDomElements =
              module$contents$omid$common$windowUtils_removeDomElements),
            (module$exports$omid$common$windowUtils.resolveGlobalContext =
              module$contents$omid$common$windowUtils_resolveGlobalContext),
            (module$exports$omid$common$windowUtils.resolveTopWindowContext =
              module$contents$omid$common$windowUtils_resolveTopWindowContext),
            (module$exports$omid$common$windowUtils.isTopWindowAccessible =
              module$contents$omid$common$windowUtils_isTopWindowAccessible);
          var module$exports$omid$common$DirectCommunication = function (e) {
            module$exports$omid$common$Communication.call(this, e),
              (this.communicationType_ =
                module$exports$omid$common$constants.CommunicationType.DIRECT),
              (this.handleExportedMessage =
                module$exports$omid$common$DirectCommunication.prototype.handleExportedMessage.bind(
                  this
                ));
          };
          $jscomp.inherits(
            module$exports$omid$common$DirectCommunication,
            module$exports$omid$common$Communication
          ),
            (module$exports$omid$common$DirectCommunication.prototype.sendMessage =
              function (e, t) {
                if (!(t = void 0 === t ? this.to : t))
                  throw Error(
                    "Message destination must be defined at construction time or when sending the message."
                  );
                t.handleExportedMessage(e.serialize(), this);
              }),
            (module$exports$omid$common$DirectCommunication.prototype.handleExportedMessage =
              function (e, t) {
                module$exports$omid$common$InternalMessage.isValidSerializedMessage(
                  e
                ) &&
                  this.handleMessage(
                    module$exports$omid$common$InternalMessage.deserialize(e),
                    t
                  );
              }),
            (module$exports$omid$common$DirectCommunication.prototype.isCrossOrigin =
              function () {
                return !1;
              });
          var module$exports$omid$common$PostMessageCommunication = function (
            e,
            t
          ) {
            (t =
              void 0 === t
                ? module$exports$omid$common$OmidGlobalProvider.omidGlobal
                : t),
              module$exports$omid$common$Communication.call(this, t);
            var n = this;
            (this.communicationType_ =
              module$exports$omid$common$constants.CommunicationType.POST_MESSAGE),
              e.addEventListener("message", function (e) {
                if ("object" == typeof e.data) {
                  var t = e.data;
                  module$exports$omid$common$InternalMessage.isValidSerializedMessage(
                    t
                  ) &&
                    ((t =
                      module$exports$omid$common$InternalMessage.deserialize(
                        t
                      )),
                    e.source && n.handleMessage(t, e.source));
                }
              });
          };
          $jscomp.inherits(
            module$exports$omid$common$PostMessageCommunication,
            module$exports$omid$common$Communication
          ),
            (module$exports$omid$common$PostMessageCommunication.isCompatibleContext =
              function (e) {
                return !!(e && e.addEventListener && e.postMessage);
              }),
            (module$exports$omid$common$PostMessageCommunication.prototype.sendMessage =
              function (e, t) {
                if (!(t = void 0 === t ? this.to : t))
                  throw Error(
                    "Message destination must be defined at construction time or when sending the message."
                  );
                t.postMessage(e.serialize(), "*");
              }),
            (module$exports$omid$common$PostMessageCommunication.prototype.isCrossOrigin =
              function () {
                return (
                  !this.to ||
                  module$contents$omid$common$windowUtils_isCrossOrigin(this.to)
                );
              });
          var module$exports$omid$common$serviceCommunication = {},
            module$contents$omid$common$serviceCommunication_EXPORTED_SESSION_COMMUNICATION_NAME =
              ["omid", "v1_SessionServiceCommunication"],
            module$contents$omid$common$serviceCommunication_EXPORTED_VERIFICATION_COMMUNICATION_NAME =
              ["omid", "v1_VerificationServiceCommunication"],
            module$contents$omid$common$serviceCommunication_EXPORTED_SERVICE_WINDOW_NAME =
              ["omidVerificationProperties", "serviceWindow"];
          function module$contents$omid$common$serviceCommunication_getValueForKeypath(
            e,
            t
          ) {
            return t.reduce(function (e, t) {
              return e && e[t];
            }, e);
          }
          function module$contents$omid$common$serviceCommunication_startServiceCommunication(
            e,
            t,
            n,
            i
          ) {
            if (!module$contents$omid$common$windowUtils_isCrossOrigin(t))
              try {
                var r =
                  module$contents$omid$common$serviceCommunication_getValueForKeypath(
                    t,
                    n
                  );
                if (r)
                  return new module$exports$omid$common$DirectCommunication(r);
              } catch (e) {}
            return i(t)
              ? new module$exports$omid$common$PostMessageCommunication(e, t)
              : null;
          }
          function module$contents$omid$common$serviceCommunication_startServiceCommunicationFromCandidates(
            e,
            t,
            n,
            i
          ) {
            for (
              var r = (t = $jscomp.makeIterator(t)).next();
              !r.done;
              r = t.next()
            )
              if (
                (r =
                  module$contents$omid$common$serviceCommunication_startServiceCommunication(
                    e,
                    r.value,
                    n,
                    i
                  ))
              )
                return r;
            return null;
          }
          function module$contents$omid$common$serviceCommunication_startSessionServiceCommunication(
            e,
            t,
            n
          ) {
            n =
              void 0 === n
                ? module$exports$omid$common$DetectOmid.isOmidPresent
                : n;
            var i = [
              e,
              module$contents$omid$common$windowUtils_resolveTopWindowContext(
                e
              ),
            ];
            return (
              t && i.unshift(t),
              module$contents$omid$common$serviceCommunication_startServiceCommunicationFromCandidates(
                e,
                i,
                module$contents$omid$common$serviceCommunication_EXPORTED_SESSION_COMMUNICATION_NAME,
                n
              )
            );
          }
          function module$contents$omid$common$serviceCommunication_startVerificationServiceCommunication(
            e,
            t
          ) {
            t =
              void 0 === t
                ? module$exports$omid$common$DetectOmid.isOmidPresent
                : t;
            var n = [],
              i =
                module$contents$omid$common$serviceCommunication_getValueForKeypath(
                  e,
                  module$contents$omid$common$serviceCommunication_EXPORTED_SERVICE_WINDOW_NAME
                );
            return (
              i && n.push(i),
              n.push(
                module$contents$omid$common$windowUtils_resolveTopWindowContext(
                  e
                )
              ),
              module$contents$omid$common$serviceCommunication_startServiceCommunicationFromCandidates(
                e,
                n,
                module$contents$omid$common$serviceCommunication_EXPORTED_VERIFICATION_COMMUNICATION_NAME,
                t
              )
            );
          }
          (module$exports$omid$common$serviceCommunication.startSessionServiceCommunication =
            module$contents$omid$common$serviceCommunication_startSessionServiceCommunication),
            (module$exports$omid$common$serviceCommunication.startVerificationServiceCommunication =
              module$contents$omid$common$serviceCommunication_startVerificationServiceCommunication);
          var module$contents$omid$verificationClient$VerificationClient_VERIFICATION_CLIENT_VERSION =
              module$exports$omid$common$version.Version,
            module$contents$omid$verificationClient$VerificationClient_EventCallback;
          function module$contents$omid$verificationClient$VerificationClient_getThirdPartyOmid() {
            var e =
              module$exports$omid$common$OmidGlobalProvider.omidGlobal.omid3p;
            return e &&
              "function" == typeof e.registerSessionObserver &&
              "function" == typeof e.addEventListener
              ? e
              : null;
          }
          var module$exports$omid$verificationClient$VerificationClient =
            function (e) {
              (this.communication =
                e ||
                module$contents$omid$common$serviceCommunication_startVerificationServiceCommunication(
                  module$contents$omid$common$windowUtils_resolveGlobalContext()
                ))
                ? (this.communication.onMessage =
                    this.handleMessage_.bind(this))
                : (e =
                    module$contents$omid$verificationClient$VerificationClient_getThirdPartyOmid()) &&
                  (this.omid3p = e),
                (this.callbackMap_ = {}),
                (this.imgCache_ = []),
                (this.injectionId_ = (e =
                  module$exports$omid$common$OmidGlobalProvider.omidGlobal
                    .omidVerificationProperties)
                  ? e.injectionId
                  : void 0);
            };
          (module$exports$omid$verificationClient$VerificationClient.prototype.isSupported =
            function () {
              return (
                !(
                  this.getEnvironment() ===
                    module$exports$omid$common$constants.Environment.WEB &&
                  !this.injectionId_
                ) && !(!this.communication && !this.omid3p)
              );
            }),
            (module$exports$omid$verificationClient$VerificationClient.prototype.getEnvironment =
              function () {
                var e =
                  module$contents$omid$common$windowUtils_resolveGlobalContext();
                return (
                  this.injectionSource() ||
                  (0, module$exports$omid$common$DetectOmid.getOmidEnvironment)(
                    e
                  ) ||
                  (0, module$exports$omid$common$DetectOmid.getOmidEnvironment)(
                    module$contents$omid$common$windowUtils_resolveTopWindowContext(
                      e
                    )
                  )
                );
              }),
            (module$exports$omid$verificationClient$VerificationClient.prototype.injectionSource =
              function () {
                var e =
                  module$exports$omid$common$OmidGlobalProvider.omidGlobal
                    .omidVerificationProperties;
                if (e && e.injectionSource) return e.injectionSource;
              }),
            (module$exports$omid$verificationClient$VerificationClient.prototype.registerSessionObserver =
              function (e, t) {
                module$contents$omid$common$argsChecker_assertFunction(
                  "functionToExecute",
                  e
                ),
                  this.omid3p
                    ? this.omid3p.registerSessionObserver(
                        e,
                        t,
                        this.injectionId_
                      )
                    : this.sendMessage_(
                        "addSessionListener",
                        e,
                        t,
                        this.injectionId_
                      );
              }),
            (module$exports$omid$verificationClient$VerificationClient.prototype.addEventListener =
              function (e, t) {
                module$contents$omid$common$argsChecker_assertTruthyString(
                  "eventType",
                  e
                ),
                  module$contents$omid$common$argsChecker_assertFunction(
                    "functionToExecute",
                    t
                  ),
                  this.omid3p
                    ? this.omid3p.addEventListener(e, t, this.injectionId_)
                    : this.sendMessage_(
                        "addEventListener",
                        t,
                        e,
                        this.injectionId_
                      );
              }),
            (module$exports$omid$verificationClient$VerificationClient.prototype.sendUrl =
              function (e, t, n) {
                module$contents$omid$common$argsChecker_assertTruthyString(
                  "url",
                  e
                ),
                  module$exports$omid$common$OmidGlobalProvider.omidGlobal
                    .document &&
                  module$exports$omid$common$OmidGlobalProvider.omidGlobal
                    .document.createElement
                    ? this.sendUrlWithImg_(e, t, n)
                    : this.sendMessage_(
                        "sendUrl",
                        function (e) {
                          e && t ? t() : !e && n && n();
                        },
                        e
                      );
              }),
            (module$exports$omid$verificationClient$VerificationClient.prototype.sendUrlWithImg_ =
              function (e, t, n) {
                var i = this,
                  r =
                    module$exports$omid$common$OmidGlobalProvider.omidGlobal.document.createElement(
                      "img"
                    );
                this.imgCache_.push(r);
                var o = function (e) {
                  var t = i.imgCache_.indexOf(r);
                  0 <= t && i.imgCache_.splice(t, 1), e && e();
                };
                r.addEventListener("load", o.bind(this, t)),
                  r.addEventListener("error", o.bind(this, n)),
                  (r.src = e);
              }),
            (module$exports$omid$verificationClient$VerificationClient.prototype.injectJavaScriptResource =
              function (e, t, n) {
                var i = this;
                module$contents$omid$common$argsChecker_assertTruthyString(
                  "url",
                  e
                ),
                  module$exports$omid$common$OmidGlobalProvider.omidGlobal
                    .document
                    ? this.injectJavascriptResourceUrlInDom_(e, t, n)
                    : this.sendMessage_(
                        "injectJavaScriptResource",
                        function (r, o) {
                          r
                            ? (i.evaluateJavaScript_(o, e), t())
                            : (module$contents$omid$common$logger_error(
                                "Service failed to load JavaScript resource."
                              ),
                              n());
                        },
                        e
                      );
              }),
            (module$exports$omid$verificationClient$VerificationClient.prototype.injectJavascriptResourceUrlInDom_ =
              function (e, t, n) {
                var i =
                    module$exports$omid$common$OmidGlobalProvider.omidGlobal
                      .document,
                  r = i.body;
                ((i = i.createElement("script")).onload = t),
                  (i.onerror = n),
                  (i.src = e),
                  (i.type = "application/javascript"),
                  r.appendChild(i);
              }),
            (module$exports$omid$verificationClient$VerificationClient.prototype.evaluateJavaScript_ =
              function (a, b) {
                try {
                  eval(a);
                } catch (e) {
                  module$contents$omid$common$logger_error(
                    'Error evaluating the JavaScript resource from "' + b + '".'
                  );
                }
              }),
            (module$exports$omid$verificationClient$VerificationClient.prototype.setTimeout =
              function (e, t) {
                if (
                  (module$contents$omid$common$argsChecker_assertFunction(
                    "functionToExecute",
                    e
                  ),
                  module$contents$omid$common$argsChecker_assertPositiveNumber(
                    "timeInMillis",
                    t
                  ),
                  this.hasTimeoutMethods_())
                )
                  return module$exports$omid$common$OmidGlobalProvider.omidGlobal.setTimeout(
                    e,
                    t
                  );
                var n =
                  1e6 * new Date().getTime() + Math.floor(1e6 * Math.random());
                return this.sendMessage_("setTimeout", e, n, t), n;
              }),
            (module$exports$omid$verificationClient$VerificationClient.prototype.clearTimeout =
              function (e) {
                module$contents$omid$common$argsChecker_assertPositiveNumber(
                  "timeoutId",
                  e
                ),
                  this.hasTimeoutMethods_()
                    ? module$exports$omid$common$OmidGlobalProvider.omidGlobal.clearTimeout(
                        e
                      )
                    : this.sendOneWayMessage_("clearTimeout", e);
              }),
            (module$exports$omid$verificationClient$VerificationClient.prototype.setInterval =
              function (e, t) {
                if (
                  (module$contents$omid$common$argsChecker_assertFunction(
                    "functionToExecute",
                    e
                  ),
                  module$contents$omid$common$argsChecker_assertPositiveNumber(
                    "timeInMillis",
                    t
                  ),
                  this.hasIntervalMethods_())
                )
                  return module$exports$omid$common$OmidGlobalProvider.omidGlobal.setInterval(
                    e,
                    t
                  );
                var n =
                  1e6 * new Date().getTime() + Math.floor(1e6 * Math.random());
                return this.sendMessage_("setInterval", e, n, t), n;
              }),
            (module$exports$omid$verificationClient$VerificationClient.prototype.clearInterval =
              function (e) {
                module$contents$omid$common$argsChecker_assertPositiveNumber(
                  "intervalId",
                  e
                ),
                  this.hasIntervalMethods_()
                    ? module$exports$omid$common$OmidGlobalProvider.omidGlobal.clearInterval(
                        e
                      )
                    : this.sendOneWayMessage_("clearInterval", e);
              }),
            (module$exports$omid$verificationClient$VerificationClient.prototype.hasTimeoutMethods_ =
              function () {
                return (
                  "function" ==
                    typeof module$exports$omid$common$OmidGlobalProvider
                      .omidGlobal.setTimeout &&
                  "function" ==
                    typeof module$exports$omid$common$OmidGlobalProvider
                      .omidGlobal.clearTimeout
                );
              }),
            (module$exports$omid$verificationClient$VerificationClient.prototype.hasIntervalMethods_ =
              function () {
                return (
                  "function" ==
                    typeof module$exports$omid$common$OmidGlobalProvider
                      .omidGlobal.setInterval &&
                  "function" ==
                    typeof module$exports$omid$common$OmidGlobalProvider
                      .omidGlobal.clearInterval
                );
              }),
            (module$exports$omid$verificationClient$VerificationClient.prototype.handleMessage_ =
              function (e, t) {
                t = e.method;
                var n = e.guid;
                if (((e = e.args), "response" === t && this.callbackMap_[n])) {
                  var i =
                    module$contents$omid$common$ArgsSerDe_deserializeMessageArgs(
                      module$exports$omid$common$version.Version,
                      e
                    );
                  this.callbackMap_[n].apply(this, i);
                }
                "error" === t &&
                  window.console &&
                  module$contents$omid$common$logger_error(e);
              }),
            (module$exports$omid$verificationClient$VerificationClient.prototype.sendOneWayMessage_ =
              function (e) {
                var t = $jscomp.getRestArguments.apply(1, arguments);
                this.sendMessage_.apply(
                  this,
                  [e, null].concat($jscomp.arrayFromIterable(t))
                );
              }),
            (module$exports$omid$verificationClient$VerificationClient.prototype.sendMessage_ =
              function (e, t) {
                var n = $jscomp.getRestArguments.apply(2, arguments);
                if (this.communication) {
                  var i = module$contents$omid$common$guid_generateGuid();
                  t && (this.callbackMap_[i] = t),
                    (n = new module$exports$omid$common$InternalMessage(
                      i,
                      module$contents$omid$common$serviceMethodUtils_getPrefixedVerificationServiceMethod(
                        e
                      ),
                      module$exports$omid$common$version.Version,
                      module$contents$omid$common$ArgsSerDe_serializeMessageArgs(
                        module$exports$omid$common$version.Version,
                        n
                      )
                    )),
                    this.communication.sendMessage(n);
                }
              }),
            module$contents$omid$common$exporter_packageExport(
              "OmidVerificationClient",
              module$exports$omid$verificationClient$VerificationClient
            );
        },
        "undefined" == typeof exports ? void 0 : exports
      );
  } catch (e) {
    __IntegralASDiagnosticCall("thirdparty", e);
  }
  if (
    ((__IASScope.isDomless = "undefined" == typeof window),
    (__IASOmidVerificationClient = {
      isSupported: function () {
        return !1;
      },
    }),
    void 0 !== __IASScope.OmidVerificationClient)
  )
    try {
      __IASOmidVerificationClient = new __IASScope.OmidVerificationClient[
        "1.5.3-iab4563"
      ]();
    } catch (e) {
      try {
        __IASOmidVerificationClient = new __IASScope.OmidVerificationClient();
      } catch (e) {}
    }
  function isStaticCampaignMonitoringTag(e) {
    var t = /\/jload(?:[/?#]|$)/.test(e),
      n = /\/fw\.js(?:[?#]|$)/.test(e),
      i = /(?:[?&])anId=/.test(e),
      r = /(?:[?&])advEntityId=/.test(e) && /(?:[?&])pubEntityId=/.test(e),
      o = /(?:[?&])ias_tId=/.test(e) && /(?:[?&])ias_cId=/.test(e);
    return t || (n && i && !r && !o);
  }
  var isStaticCMTag = !1;
  function IASBaseTrustedTypesPolicy(e) {
    if (
      ((this.policy = null),
      e && !e.isDomless && e.trustedTypes && e.trustedTypes.createPolicy)
    )
      try {
        this.policy = e.trustedTypes.createPolicy("IASBaseTrustedTypesPolicy", {
          createHTML: function (e) {
            return e;
          },
          createScriptURL: function (e) {
            return e;
          },
          createScript: function (e) {
            return e;
          },
        });
      } catch (e) {}
    (this.createHTML = function (e) {
      return this.policy && this.policy.createHTML
        ? this.policy.createHTML(e)
        : e;
    }),
      (this.createScriptURL = function (e) {
        return this.policy && this.policy.createScriptURL
          ? this.policy.createScriptURL(e)
          : e;
      }),
      (this.createScript = function (e) {
        return this.policy && this.policy.createScript
          ? this.policy.createScript(e)
          : e;
      });
  }
  !__IASScope.isDomless &&
    document.currentScript &&
    document.currentScript.src &&
    (isStaticCMTag = isStaticCampaignMonitoringTag(document.currentScript.src)),
    __IASScope &&
      !__IASScope.iasBaseTrustedTypesPolicy &&
      (__IASScope.iasBaseTrustedTypesPolicy = new IASBaseTrustedTypesPolicy(
        __IASScope
      )),
    (__IntegralASConfig.useFIF =
      __IASScope &&
      !!__IASScope.__IntegralASUseFIF &&
      ("jload" === __IntegralASConfig.mode || isStaticCMTag)),
    (__IntegralASConfig.adRefreshThreshold =
      __IASScope && __IASScope.__IntegralASAdRefreshThreshold),
    (__IntegralASConfig.getContextNode = function (e, t) {
      "use strict";
      if (!__IASScope.isDomless) {
        if (
          e.location &&
          e.location.href &&
          (e.location.href.includes("fw.html") ||
            e.location.href.includes("/rjsi/"))
        )
          return {
            dataset: {},
            parentNode: e.document.body,
            src: e.location.href,
          };
        if (__IntegralASConfig.useFIF) return __IASScope.frameElement;
        if (document.currentScript) return document.currentScript;
        var n,
          i,
          r = function (e) {
            var t = [];
            if (e) {
              if (!document.body) return t;
              function e(n) {
                "SCRIPT" === n.tagName && t.push(n);
                var i = n.shadowRoot;
                i && e(i);
                for (var r = n.children, o = 0; o < r.length; o++) e(r[o]);
              }
              e(document.body);
            } else t = [...document.getElementsByTagName("script")];
            return t;
          },
          o = __IntegralASConfig.scriptUrl,
          s = o && o.includes("ias_searchshadowdom=true");
        if (!o)
          for (var a = (i = r(!0)).length; --a >= 0; )
            if (
              (n = i[a]).src &&
              n.src.includes("ias_searchshadowdom=true") &&
              null === n.getAttribute("data-ias-script-tag")
            ) {
              (o = n.src), (s = !0);
              break;
            }
        var c = s && i ? i : r(s),
          d = c[c.length - 1],
          u = c.length;
        try {
          for (; --u >= 0; )
            if (
              (n = c[u]).src &&
              0 === n.src.indexOf(o) &&
              null === n.getAttribute("data-ias-script-tag")
            ) {
              (d = n), n.setAttribute("data-ias-script-tag", "found");
              break;
            }
        } catch (e) {}
        return d;
      }
    }),
    (__IntegralASConfig.getCurrentScript = function () {
      if (document.currentScript) return document.currentScript;
    }),
    (__IntegralASConfig.contextNode = __IASScope.isDomless
      ? void 0
      : __IntegralASConfig.getContextNode(window, top)),
    (__IntegralASConfig.currentScript = __IASScope.isDomless
      ? void 0
      : __IntegralASConfig.getCurrentScript()),
    (__IntegralASConfig.perfFactory = function () {
      "use strict";
      var e = {},
        t = "A";
      function n(t, n) {
        e[t] = n;
      }
      function i(e) {
        n(e, Math.round(__IASScope.performance.now()));
      }
      function r(e) {
        i(e + t);
      }
      function o(e) {
        i(e + "Z");
      }
      function s(e) {
        var t,
          n,
          i = null;
        return e
          ? ((n = __IASScope.performance.getEntriesByName(e)) &&
              n.length &&
              (i = {
                startTime: (t = n[n.length - 1]).startTime,
                responseEnd: t.responseEnd,
                transferSize: t.transferSize,
                encodedBodySize: t.encodedBodySize,
                decodedBodySize: t.decodedBodySize,
                deliveryType: t.deliveryType,
              }),
            i)
          : i;
      }
      function a(e, i) {
        var r;
        (r = s(i)) &&
          r.startTime > 0 &&
          r.responseEnd > 0 &&
          (n(e + t, Math.round(r.startTime)),
          n(e + "Z", Math.round(r.responseEnd)));
      }
      function c() {}
      function d() {
        return null;
      }
      function u() {
        (n = c), (i = c), (r = c), (o = c), (a = c), (s = d);
      }
      function l(e) {
        return "function" == typeof e;
      }
      return (
        (function () {
          try {
            __IASScope.performance &&
            l(__IASScope.performance.getEntriesByName) &&
            l(__IASScope.performance.now) &&
            null !== __IntegralASConfig.perfBirth
              ? (a(
                  __IntegralASConfig.jsDoSplit ? "bd" : "md",
                  __IntegralASConfig.scriptUrl
                ),
                n("beA", Math.round(__IntegralASConfig.perfBirth)),
                o("be"))
              : u();
          } catch (e) {
            u(),
              l(__IASScope.__IntegralASDiagnosticCall) &&
                __IASScope.__IntegralASDiagnosticCall(
                  "perf",
                  e,
                  __IntegralASConfig
                );
          }
        })(),
        {
          mark: i,
          markStart: r,
          markEnd: o,
          markResource: a,
          getResourceTiming: s,
          getData: function () {
            return e;
          },
          getStart: function (n) {
            return e[n + t];
          },
          getEnd: function (t) {
            return e[t + "Z"];
          },
        }
      );
    }),
    (__IntegralASConfig.perf = __IntegralASConfig.perfFactory());
} catch (e) {
  (__IntegralASConfig = {}), __IntegralASDiagnosticCall("bootstrapper", e);
}
__IntegralASConfig.initialize = function (e, t, n) {
  var i = {};
  if (Object.assign) e = Object.assign({}, e);
  else {
    for (var r in e) i[r] = e[r];
    e = i;
  }
  const o = ({ stringOrObject: e }) => {
    let t = null;
    if ("object" == typeof e) t = e;
    else if ("string" == typeof e)
      try {
        t = JSON.parse(e);
      } catch {}
    return t;
  };
  class s {
    constructor() {
      this.logs = [];
    }
    add({ storeModelName: e, key: t, value: n, timeStamp: i }) {
      this.logs.push({ storeModelName: e, key: t, value: n, timeStamp: i });
    }
    getHistory() {
      return this.logs;
    }
    logHistory() {}
  }
  class a {
    constructor({ storeModelName: e }) {
      (this.storeModelName = e), (this.storeModelHistory = new s());
    }
    set(e, t, n = { locked: !0 }) {
      try {
        Object.defineProperty(this, e, {
          value: t,
          writable: !n.locked,
          configurable: !1,
        }),
          this.storeModelHistory.add({
            storeModelName: this.storeModelName,
            key: e,
            value: t,
            timeStamp: Date.now(),
          });
      } catch (e) {}
    }
    get(e) {
      return this[e];
    }
    getHistory() {
      return this.storeModelHistory.getHistory();
    }
    logHistory() {
      this.storeModelHistory.logHistory();
    }
  }
  class c extends a {
    constructor() {
      super({ storeModelName: "singleEventImpressionJsInfo" });
    }
    setPieces(e) {
      this.set("pieces", e, { locked: !1 });
    }
    getPieces() {
      return this.pieces;
    }
  }
  class d extends a {
    constructor({ currentWindow: e }) {
      super({ storeModelName: "trustedTypesPolicy" }),
        (this.baseTrustedTypesPolicy = e?.iasBaseTrustedTypesPolicy);
    }
    createHTML(e) {
      return this.baseTrustedTypesPolicy?.createHTML(e) ?? e;
    }
    createScriptURL(e) {
      return this.baseTrustedTypesPolicy?.createScriptURL(e) ?? e;
    }
    createScript(e) {
      return this.baseTrustedTypesPolicy?.createScript(e) ?? e;
    }
  }
  const u = { useSingleEvent: 0 };
  class l extends a {
    constructor() {
      super({ storeModelName: "staticFeatures" }),
        (this.useSingleEvent = (function ({ percentage: e }) {
          return e > 100 * Fi.random();
        })({ percentage: u.useSingleEvent }));
    }
  }
  const m = (e) =>
    !!(!0 === e || "true" === e || 1 === e) ||
    (!(!1 === e || "false" === e || 0 === e) && void 0);
  class g extends a {
    constructor({ windowObj: e, now: t, enabled: n, isDomless: i }) {
      super({ storeModelName: "mraidLifecycleTracker" }),
        (this.active = !1),
        (this.eligibility = "unknown"),
        (this.availability = "absent"),
        (this.mraidEverObserved = !1),
        (this.readyObserved = !1),
        (this.readyInferred = !1),
        (this.defaultObserved = !1),
        (this.stateChangeCount = 0),
        (this.viewableChangeCount = 0),
        (this.objectReplaced = !1),
        (this.usableTransitionObserved = !1),
        (this.usableNotifiedForCurrentBridge = !1),
        (this.readyListenerAttached = !1),
        (this.stateChangeListenerAttached = !1),
        (this.viewableChangeListenerAttached = !1),
        (this.listeners = []),
        (this.maxListeners = 20),
        (this.readyHandler = () => {
          this.runSafely("ready", () => {
            const e = this.getTime();
            try {
              this.readyListenerAttached &&
                this.isFunction(this.mraid?.removeEventListener) &&
                (this.mraid.removeEventListener("ready", this.readyHandler),
                (this.readyListenerAttached = !1));
            } catch (e) {}
            (this.readyObserved = !0),
              (this.readyTime = void 0 === this.readyTime ? e : this.readyTime),
              this.captureCapabilitiesAndState(),
              this.attachLifecycleListeners(),
              this.updateAvailability("ready_event"),
              this.notifyReady(e);
          });
        }),
        (this.stateChangeHandler = (e) => {
          this.runSafely("state_change", () => {
            const t = this.getTime(),
              n = this.normalizeState(e);
            this.stateChangeCount < 100 && (this.stateChangeCount += 1),
              (this.lastStateChangeTime = t),
              n && ((this.currentState = n), this.captureDefaultState(n, t)),
              this.captureCapabilitiesAndState(),
              this.updateAvailability("state_change"),
              this.notifyStateChange(n, t);
          });
        }),
        (this.viewableChangeHandler = (e) => {
          this.runSafely("viewable_change", () => {
            const t = this.getTime(),
              n = m(e);
            this.viewableChangeCount < 100 && (this.viewableChangeCount += 1),
              (this.lastViewableChangeTime = t),
              void 0 !== n && (this.currentViewable = n),
              this.updateAvailability("viewable_change"),
              this.notifyViewableChange(e, t);
          });
        }),
        (this.windowObj = e),
        (this.now = t),
        (this.enabled = n),
        (this.isDomless = i);
    }
    init() {
      this.runSafely("init", () => {
        this.enabled &&
          !this.isDomless &&
          ((this.active = !0),
          (this.trackerStartTime = this.getTime()),
          this.attachToCurrentMraid("initial"));
      });
    }
    confirmEligibility(e) {
      this.runSafely("eligibility", () => {
        (this.eligibility = e ? "eligible" : "ineligible"), e || this.destroy();
      });
    }
    refresh(e = "strategy") {
      this.runSafely("refresh", () => {
        if (!this.active) return;
        if (this.getWindowMraid() !== this.mraid)
          return (
            this.detachFromMraid(),
            (this.objectReplaced = void 0 !== this.mraid),
            this.objectReplaced && this.resetBridgeObservationLatches(),
            void this.attachToCurrentMraid(e)
          );
        this.captureCapabilitiesAndState(),
          this.attachReadyOrLifecycleListeners(),
          this.updateAvailability(e);
      });
    }
    refreshPending() {
      try {
        this.active &&
          "eligible" === this.eligibility &&
          "usable" !== this.availability &&
          this.refresh("viewability_loop");
      } catch (e) {}
    }
    subscribe(e) {
      try {
        this.listeners.length < this.maxListeners && this.listeners.push(e);
      } catch (e) {}
      return () => {
        try {
          const t = this.listeners.indexOf(e);
          t >= 0 && this.listeners.splice(t, 1);
        } catch (e) {}
      };
    }
    getSnapshot() {
      const e = this.isObject(this.mraid);
      return {
        active: this.active,
        eligibility: this.eligibility,
        availability: this.availability,
        mraidExists: e,
        mraidEverObserved: this.mraidEverObserved,
        getStateAvailable: e && this.isFunction(this.mraid.getState),
        addEventListenerAvailable:
          e && this.isFunction(this.mraid.addEventListener),
        removeEventListenerAvailable:
          e && this.isFunction(this.mraid.removeEventListener),
        isViewableAvailable: e && this.isFunction(this.mraid.isViewable),
        initialState: this.initialState,
        currentState: this.currentState,
        initialViewable: this.initialViewable,
        currentViewable: this.currentViewable,
        trackerStartTime: this.trackerStartTime,
        readyObserved: this.readyObserved,
        readyInferred: this.readyInferred,
        readyTime: this.readyTime,
        defaultObserved: this.defaultObserved,
        defaultTime: this.defaultTime,
        stateChangeCount: this.stateChangeCount,
        viewableChangeCount: this.viewableChangeCount,
        lastStateChangeTime: this.lastStateChangeTime,
        lastViewableChangeTime: this.lastViewableChangeTime,
        readyListenerAttached: this.readyListenerAttached,
        stateChangeListenerAttached: this.stateChangeListenerAttached,
        viewableChangeListenerAttached: this.viewableChangeListenerAttached,
        objectReplaced: this.objectReplaced,
        firstUsableTime: this.firstUsableTime,
        firstUsableSource: this.firstUsableSource,
        failureStage: this.failureStage,
      };
    }
    destroy() {
      this.runSafely("destroy", () => {
        this.detachFromMraid(),
          (this.listeners = []),
          (this.active = !1),
          (this.eligibility = "ineligible");
      });
    }
    attachToCurrentMraid(e) {
      this.runSafely("attach", () => {
        (this.mraid = this.getWindowMraid()),
          this.resetAttachmentFlags(),
          this.isObject(this.mraid)
            ? ((this.mraidEverObserved = !0),
              this.captureCapabilitiesAndState(),
              void 0 === this.initialState &&
                (this.initialState = this.currentState),
              void 0 === this.initialViewable &&
                (this.initialViewable = this.currentViewable),
              this.attachReadyOrLifecycleListeners(),
              this.updateAvailability(e))
            : this.updateAvailability(e);
      });
    }
    attachReadyOrLifecycleListeners() {
      this.runSafely("attach_listener", () => {
        if (
          this.isObject(this.mraid) &&
          this.isFunction(this.mraid.addEventListener)
        ) {
          if (
            !(
              (this.currentState && "loading" !== this.currentState) ||
              this.readyObserved ||
              this.readyInferred
            )
          )
            return (
              this.readyListenerAttached ||
                (this.mraid.addEventListener("ready", this.readyHandler),
                (this.readyListenerAttached = !0)),
              void this.attachLifecycleListeners()
            );
          (this.readyInferred = !0),
            (this.readyTime =
              void 0 === this.readyTime ? this.getTime() : this.readyTime),
            this.attachLifecycleListeners();
        }
      });
    }
    attachLifecycleListeners() {
      this.runSafely("attach_lifecycle", () => {
        if (
          this.isObject(this.mraid) &&
          this.isFunction(this.mraid.addEventListener)
        ) {
          if (!this.stateChangeListenerAttached)
            try {
              this.mraid.addEventListener(
                "stateChange",
                this.stateChangeHandler
              ),
                (this.stateChangeListenerAttached = !0);
            } catch (e) {
              this.failureStage = "attach_state_change";
            }
          if (
            !this.viewableChangeListenerAttached &&
            this.isFunction(this.mraid.isViewable)
          )
            try {
              this.mraid.addEventListener(
                "viewableChange",
                this.viewableChangeHandler
              ),
                (this.viewableChangeListenerAttached = !0);
            } catch (e) {
              this.failureStage = "attach_viewable_change";
            }
        }
      });
    }
    captureCapabilitiesAndState() {
      this.runSafely("capture_state", () => {
        if (this.isObject(this.mraid)) {
          if (this.isFunction(this.mraid.getState)) {
            const e = this.normalizeState(this.mraid.getState());
            e &&
              ((this.currentState = e),
              this.captureDefaultState(e, this.getTime()));
          }
          if (
            this.currentState &&
            "loading" !== this.currentState &&
            this.isFunction(this.mraid.isViewable)
          ) {
            const e = m(this.mraid.isViewable());
            void 0 !== e && (this.currentViewable = e);
          }
        }
      });
    }
    detachFromMraid() {
      try {
        if (
          this.isObject(this.mraid) &&
          this.isFunction(this.mraid.removeEventListener)
        ) {
          try {
            this.readyListenerAttached &&
              this.mraid.removeEventListener("ready", this.readyHandler);
          } catch (e) {}
          try {
            this.stateChangeListenerAttached &&
              this.mraid.removeEventListener(
                "stateChange",
                this.stateChangeHandler
              );
          } catch (e) {}
          try {
            this.viewableChangeListenerAttached &&
              this.mraid.removeEventListener(
                "viewableChange",
                this.viewableChangeHandler
              );
          } catch (e) {}
        }
      } catch (e) {
        this.failureStage = "detach";
      }
      this.resetAttachmentFlags();
    }
    notifyReady(e) {
      this.notify((t) => t.onReady && t.onReady(e));
    }
    notifyUsable(e, t) {
      this.notify((n) => n.onUsable && n.onUsable(e, t));
    }
    notifyStateChange(e, t) {
      this.notify((n) => n.onStateChange && n.onStateChange(e, t));
    }
    notifyViewableChange(e, t) {
      this.notify((n) => n.onViewableChange && n.onViewableChange(e, t));
    }
    notify(e) {
      try {
        const t = this.listeners.slice(0, this.maxListeners);
        for (let n = 0; n < t.length; n += 1)
          try {
            e(t[n]);
          } catch (e) {}
      } catch (e) {}
    }
    getWindowMraid() {
      try {
        return this.windowObj && this.windowObj.mraid;
      } catch (e) {
        return void (this.failureStage = "read_mraid");
      }
    }
    getTime() {
      try {
        return this.now();
      } catch (e) {
        return (this.failureStage = "time"), 0;
      }
    }
    runSafely(e, t) {
      try {
        t();
      } catch (t) {
        this.failureStage = e;
      }
    }
    resetAttachmentFlags() {
      (this.readyListenerAttached = !1),
        (this.stateChangeListenerAttached = !1),
        (this.viewableChangeListenerAttached = !1);
    }
    resetBridgeObservationLatches() {
      (this.readyObserved = !1),
        (this.readyInferred = !1),
        (this.readyTime = void 0),
        (this.defaultObserved = !1),
        (this.defaultTime = void 0),
        (this.currentState = void 0),
        (this.currentViewable = void 0),
        (this.usableNotifiedForCurrentBridge = !1);
    }
    updateAvailability(e) {
      try {
        const t = this.isObject(this.mraid);
        let n = "absent";
        if (t) {
          n =
            this.isFunction(this.mraid.getState) &&
            this.isFunction(this.mraid.isViewable) &&
            this.isFunction(this.mraid.addEventListener) &&
            this.currentState
              ? "loading" === this.currentState
                ? "loading"
                : "boolean" == typeof this.currentViewable
                ? "usable"
                : "incomplete"
              : "incomplete";
        }
        if (
          ((this.availability = n),
          "usable" === n && !this.usableNotifiedForCurrentBridge)
        ) {
          this.usableNotifiedForCurrentBridge = !0;
          const t = this.getTime();
          this.usableTransitionObserved ||
            ((this.usableTransitionObserved = !0),
            (this.firstUsableTime = t),
            (this.firstUsableSource = e)),
            this.notifyUsable(t, e);
        }
      } catch (e) {
        this.failureStage = "availability";
      }
    }
    isObject(e) {
      return "object" == typeof e && null !== e && !Array.isArray(e);
    }
    isFunction(e) {
      return "function" == typeof e;
    }
    captureDefaultState(e, t) {
      try {
        "default" === e &&
          ((this.defaultObserved = !0),
          (this.defaultTime =
            void 0 === this.defaultTime ? t : this.defaultTime));
      } catch (e) {}
    }
    normalizeState(e) {
      return "string" == typeof e && e.length > 0 ? e : void 0;
    }
  }
  const p = () => {
      let e = null;
      try {
        e =
          "string" == typeof __IASTagUrl && __IASTagUrl.length > 0
            ? __IASTagUrl
            : null;
      } catch (t) {
        e = null;
      }
      return e;
    },
    f = (e) => {
      let t;
      try {
        t = decodeURIComponent(e);
      } catch {
        t = e;
      }
      return t;
    },
    h = ({ search: e }) => {
      const t = {};
      return (
        e.startsWith("?") &&
          e
            .slice(1)
            .split("&")
            .forEach((e) => {
              const n = e.indexOf("="),
                i = -1 === n ? e : e.slice(0, n),
                r = -1 === n ? "" : e.slice(n + 1);
              i && (t[f(i)] = f(r));
            }),
        t
      );
    },
    y = ({ url: e }) => {
      const t = (e.startsWith("//") ? `https:${e}` : e).match(
        /^(https?):\/\/([^/:?#]+)(:\d+)?(\/[^?#]*)?(\?[^#]*)?(#.*)?$/
      );
      if (!t) return;
      const n = t[1],
        i = t[2],
        r = t[3] ? t[3].slice(1) : "",
        o = t[4] || "/",
        s = t[5] || "",
        a = t[6] || "",
        c = r ? i + ":" + r : i,
        d = n + "://" + c,
        u = d + o + (s || "") + (a || ""),
        l = h({ search: s }),
        m = {};
      Object.defineProperties(m, {
        get: {
          enumerable: !1,
          writable: !1,
          configurable: !1,
          value: (e) =>
            Object.prototype.hasOwnProperty.call(l, e) ? l[e] : null,
        },
        has: {
          enumerable: !1,
          writable: !1,
          configurable: !1,
          value: (e) => Object.prototype.hasOwnProperty.call(l, e),
        },
        toString: {
          enumerable: !1,
          writable: !1,
          configurable: !1,
          value() {
            if (s && "?" === s.charAt(0)) return s.slice(1);
            return Object.keys(l)
              .map(
                (e) =>
                  encodeURIComponent(e) + "=" + encodeURIComponent(l[e] || "")
              )
              .join("&");
          },
        },
      });
      for (const e in l)
        if (Object.prototype.hasOwnProperty.call(l, e))
          try {
            m[e] = l[e];
          } catch (e) {}
      return {
        href: u,
        origin: d,
        protocol: n + ":",
        host: c,
        hostname: i,
        port: r,
        pathname: o,
        search: s,
        hash: a,
        searchParams: m,
      };
    },
    v = (e) =>
      "string" == typeof e && e
        ? e
            .replace(/^[?&]+/, "")
            .split("&")
            .filter(Boolean)
        : [],
    S = (e) => {
      const t = e.indexOf("="),
        n = -1 === t ? e : e.slice(0, t);
      return f(n);
    },
    b = ({ isDomless: e, contextNode: t, verificationParameters: n }) =>
      (({ tagStaticFwjsMacros: e, verificationStaticFwjsMacros: t }) => {
        const n = v(e),
          i = v(t);
        if (0 === n.length && 0 === i.length) return;
        const r = Object.create(null);
        for (const e of n) r[S(e)] = !0;
        const o = i.filter((e) => !r[S(e)]);
        return [...n, ...o].join("&");
      })({
        tagStaticFwjsMacros: e
          ? ie({ url: p() ?? void 0 })
          : t?.staticFwjsMacros,
        verificationStaticFwjsMacros: n?.staticFwjsMacros,
      }),
    I = (e) => {
      const t = e.split("/").slice(1);
      return "/" + W({ pathParts: t }).join("/");
    };
  class w extends a {
    constructor({ contextNode: e, adTag: t }) {
      super({ storeModelName: "jsConfigRequest" }),
        (this.url = ""),
        (this.contentType = ""),
        (this.verificationParameters = {}),
        (this.contentType = ""),
        (this.contextNode = e),
        (this.adTag = t),
        this.buildRequestUrlFromParameters({ contextNode: e, adTag: t });
    }
    buildRequestUrlFromParameters({
      contextNode: e,
      omidParameters: t,
      adTag: n,
    }) {
      this.setParameters({ contextNode: e, omidParameters: t }),
        this.buildRequestUrl({ contextNode: e, adTag: n });
    }
    setParameters({ contextNode: t, omidParameters: n }) {
      if (n)
        if ("string" == typeof n)
          try {
            const e = JSON.parse(n);
            this.set("verificationParameters", e, { locked: !1 });
          } catch (e) {}
        else this.set("verificationParameters", n, { locked: !1 });
      else {
        const n = t?.dataAttributes,
          i = n?.iasParameters || e.iasParameters;
        if ("string" == typeof i)
          try {
            this.set("verificationParameters", JSON.parse(i), { locked: !1 });
          } catch (e) {}
        else
          void 0 !== i && this.set("verificationParameters", i, { locked: !1 });
      }
      this.set("contentType", this.verificationParameters.contentType || "", {
        locked: !1,
      });
    }
    buildRequestUrl({ contextNode: t, adTag: n } = {}) {
      const i = n ?? this.adTag,
        r = b({
          isDomless: zn.isDomless(),
          contextNode: t,
          verificationParameters: this.verificationParameters,
        }),
        o = (({ contextNode: t, verificationParameters: n } = {}) => {
          const i = t?.queryParameters,
            r = zn.isDomless(),
            o = p(),
            s = r && o ? y({ url: o }) : void 0,
            a =
              i?.get("iasConfigHost") ||
              s?.searchParams?.get("iasConfigHost") ||
              void 0;
          let c = null;
          const d = n?.config;
          if (d) c = /iasProxyPartnerId=([\d]+)/g.exec(d);
          else
            try {
              const e = t?.srcUrl?.href || (r ? o ?? "" : "") || "";
              (c = /iasProxyPartnerId=([\d]+)/g.exec(e)),
                c || (c = /iasProxyPartnerId%3D([\d]+)/g.exec(e));
            } catch (e) {}
          const u = c?.[1];
          return (
            (e.proxyPartnerId = u),
            n?.host ||
              a ||
              {
                37103: "https://vfw.amazon-adsystem.com/ias/ivt/j",
                2: "https://g.bing.com/p/tpv-ias",
              }[u] ||
              "https://jsconfig.adsafeprotected.com"
          );
        })({
          contextNode: t,
          verificationParameters: this.verificationParameters,
        }),
        s = (({ contextNode: e, verificationParameters: t, adTag: n } = {}) => {
          let i = t?.config;
          const r = zn.isDomless();
          if (!i) {
            n?.tagType === $.Jload && n?.anId && (i = `/jload/${n.anId}`),
              n?.tagType === $.Rjss &&
                n?.creativeDomain &&
                n?.advEntityId &&
                n?.pubEntityId &&
                n?.creativePath &&
                ((i = `/rjss/${n.creativeDomain}/${n.advEntityId}/${n.pubEntityId}${n.creativePath}`),
                n?.creativeSearch && (i += n.creativeSearch)),
              n?.tagType === $.Amt &&
                n?.tagId &&
                n?.contractId &&
                (i = `/amtjs?ias_tId=${n.tagId}&ias_cId=${n.contractId}`);
            try {
              const t = p();
              let n;
              if (t)
                try {
                  n = y({ url: t });
                } catch {}
              const o = e?.srcUrl,
                s = o || (r ? n : void 0),
                a = r && t && n && n?.pathname?.includes("/jload"),
                c = r && t && n && n?.href?.includes("/fwjsvid"),
                d = r && t && n && n?.href?.includes("/jsvid"),
                u = r && t && n && n?.pathname?.includes("/amtjs"),
                l = r && t && n && n?.pathname?.includes("/rjss"),
                m = !o?.href?.includes("/fw.js") && o?.href?.includes("/jload"),
                g =
                  !o?.href?.includes("/fw.js") && o?.href?.includes("/fwjsvid"),
                f = !o?.href?.includes("/fw.js") && o?.href?.includes("/jsvid"),
                h = !o?.href?.includes("/fw.js") && o?.href?.includes("/amtjs"),
                v = !o?.href?.includes("/fw.js") && o?.href?.includes("/rjss");
              if (a) {
                const e = n?.searchParams,
                  t = e?.get("anId") || void 0;
                t && ((i = `/jload/${t}`), n?.search && (i += n.search));
              } else if (c) {
                const e = n?.pathname;
                e && ((i = I(e)), n?.search && (i += n.search));
              } else if (d) {
                const e = n?.searchParams,
                  t = e?.get("anId") || void 0;
                t && ((i = `/jload/${t}`), n?.search && (i += n.search));
              } else if (m) {
                const t = e?.queryParameters,
                  n = t?.get("anId");
                n && ((i = `/jload/${n}`), t && (i += `?${t.toString()}`));
              } else if (g) {
                const t = o?.pathname;
                if (t) {
                  const n = e?.queryParameters;
                  (i = I(t)), n?.toString() && (i += `?${n.toString()}`);
                }
              } else if (f) {
                const t = e?.queryParameters,
                  n = t?.get("anId");
                n &&
                  ((i = `/jload/${n}`),
                  t?.toString() && (i += `?${t.toString()}`));
              } else if (u) (i = "/amtjs"), n?.search && (i += n.search);
              else if (h) {
                const t = e?.queryParameters;
                (i = "/amtjs"), t && (i += `?${t.toString()}`);
              } else if (l) {
                const e = n?.pathname;
                e && ((i = e), n?.search && (i += n.search));
              } else if (v) {
                const t = o?.pathname;
                if (t) {
                  const n = e?.queryParameters;
                  (i = t), n?.toString() && (i += `?${n.toString()}`);
                }
              } else if (s) {
                const e =
                  /iasConfig=([^&#]*)/g.exec(s.href) ||
                  /config=([^&#]*)/g.exec(s.href);
                e && "string" == typeof e[1] && (i = decodeURIComponent(e[1]));
              }
            } catch {}
          }
          return i;
        })({
          contextNode: t,
          verificationParameters: this.verificationParameters,
          adTag: i,
        });
      if (s) {
        const e = (({ host: e, path: t, queryParams: n }) => {
          const i = t.includes("?");
          let r = `${e}/jsconfig${t}`;
          return n && (r += `${i ? "&" : "?"}${n}`), r;
        })({ host: o, path: s, queryParams: r });
        this.set("url", e, { locked: !1 });
      }
    }
  }
  var A, $;
  !(function (e) {
    e.StaticAdsafeprotected = "static.adsafeprotected.com";
  })(A || (A = {})),
    (function (e) {
      (e.Rjss = "rjss"),
        (e.Rjsi = "rjsi"),
        (e.JsVid = "jsvid"),
        (e.FwjsVid = "fwjsvid"),
        (e.JsApi = "jsapi"),
        (e.Jload = "jload"),
        (e.Jss = "jss"),
        (e.Jsi = "jsi"),
        (e.Amt = "amtjs");
    })($ || ($ = {}));
  const T = {
      Firewall: [$.Jss, $.Jsi, $.Rjss, $.Rjsi, $.FwjsVid, $.JsApi],
      CampaignMonitoring: [$.Jload, $.JsVid],
      Amt: [$.Amt],
    },
    E = ({ contextNode: e, measurementConfig: t }) => {
      let n = P({ contextNode: e, measurementConfig: t });
      return n || (n = C({ contextNode: e, measurementConfig: t })), n;
    },
    C = ({ contextNode: e, measurementConfig: t }) => {
      let n = null;
      const i = M({ contextNode: e, measurementConfig: t });
      return i && (n = O({ tagUrl: i })), n;
    },
    O = ({ tagUrl: e }) => {
      let t,
        n = null,
        i = null,
        r = null;
      try {
        (i = e ? new URL(e) : null),
          (t = i?.pathname),
          (r = X({ pathname: t }));
      } catch (e) {}
      return (
        i && t && "Firewall" === r && (n = Y({ parsedUrl: i })),
        i && t && "CampaignMonitoring" === r && (n = H({ parsedUrl: i })),
        i && t && "Amt" === r && (n = z({ parsedUrl: i })),
        n
      );
    },
    _ = ({ tagUrl: e }) => {
      let t = null;
      try {
        let n = null,
          i = null,
          r = null;
        if (
          ((n = e ? y({ url: e }) : null),
          (r = n?.pathname),
          (i = X({ pathname: r })),
          "/fw.js" === n?.pathname)
        ) {
          const e =
            n.searchParams.get("config") || n.searchParams.get("iasConfig");
          (t = k({ configPath: e })),
            t || (t = J({ queryParameters: n.searchParams }));
        } else
          n && r && "Firewall" === i
            ? (t = Y({ parsedUrl: n }))
            : n && r && "CampaignMonitoring" === i
            ? (t = H({ parsedUrl: n }))
            : n && r && "Amt" === i && (t = z({ parsedUrl: n }));
      } catch {}
      return t;
    },
    M = ({ contextNode: e, measurementConfig: t }) => {
      let n = null;
      const {
        currentScript: i,
        isFrameInFrame: r,
        isLegacyTagRedirectedToStatic: o,
      } = t;
      return (
        (n = r ? x({ currentScript: i }) : D({ contextNode: e })),
        n && !n?.startsWith("http") && (n = B({ url: n })),
        n
      );
    },
    D = ({ contextNode: e }) => {
      let t = null;
      const n = e?.src;
      return n && (t = n), t;
    },
    x = ({ currentScript: e }) => {
      let t = null;
      const n = e?.getAttribute("src");
      return n && (t = n), t;
    },
    P = ({ contextNode: e, measurementConfig: t }) => {
      let n = null;
      const i = N({ contextNode: e, measurementConfig: t });
      return i && (n = k({ configPath: i })), n;
    },
    N = ({ contextNode: e, measurementConfig: t }) => {
      let n = null;
      const {
        isStaticMode: i,
        iasParameters: r,
        isSingleInstance: o,
        isStaticIframeTag: s,
      } = t;
      return (
        o
          ? (n = V({ iasParameters: r }))
          : (i || s) && (n = R({ contextNode: e })),
        n
      );
    },
    V = ({ iasParameters: e }) => {
      let t = null;
      if (e) {
        const n = G({ jsonOrObject: e });
        if (n) {
          const { config: e } = n;
          e && (t = e);
        }
      }
      return t;
    },
    R = ({ contextNode: e }) => F({ contextNode: e })?.config || null,
    k = ({ configPath: e }) => {
      let t = null;
      const n = (({ configPath: e }) => {
          if (!e || e.startsWith("?")) return null;
          const t = e.startsWith("/") ? e : `/${e}`,
            n = y({ url: `https://config-path.invalid${t}` });
          if (!n) return null;
          const i = { pathname: n.pathname };
          return (
            n.search.length > 1 &&
              ((i.search = n.search), (i.searchParams = n.searchParams)),
            i
          );
        })({ configPath: e }),
        i = n?.pathname,
        r = X({ pathname: i });
      return (
        i && "Firewall" === r && (t = Y({ parsedUrl: n })),
        i && "CampaignMonitoring" === r && (t = H({ parsedUrl: n })),
        i && "Amt" === r && (t = z({ parsedUrl: n })),
        t
      );
    },
    F = ({ contextNode: e }) => {
      let t = {};
      const n = j({ contextNode: e }),
        i = U({ contextNode: e });
      return (t = n || i), t;
    },
    j = ({ contextNode: e }) => {
      let t = null;
      const n = e?.dataAttributes?.iasParameters;
      if (n) {
        const e = G({ jsonOrObject: n });
        t = e?.config ? e : null;
      }
      return t;
    },
    U = ({ contextNode: e }) => {
      let t = null;
      if (e?.queryParameters) {
        const n = L({ queryParams: e.queryParameters });
        t = n?.config ? n : null;
      }
      return t;
    },
    L = ({ queryParams: e }) => ({
      config: e.get("config") || e.get("iasConfig"),
      host: e.get("host") || e.get("iasConfigHost"),
      contentType: e.get("iasConfigContentType"),
      sca: e.get("iasSca"),
      xsca: e.get("iasXsca"),
      h: e.get("iasHeight"),
      w: e.get("iasWidth"),
    }),
    q = ({
      creativeDomain: e,
      creativePath: t,
      creativeSearch: n,
      creativeHash: i,
      protocol: r = "https:",
    }) => {
      if (!e || !t) return null;
      const o = r ? (r.endsWith(":") ? r : `${r}:`) : "https:",
        s = ((e) => ("st" === e ? A.StaticAdsafeprotected : e))(e);
      return `${o}//${s}${t}${(({ creativeSearch: e }) => {
        const t = /["'<>{}[\]\\^`|\s]/,
          n = e.indexOf("?");
        if (-1 === n) return e;
        const i = e.slice(n + 1);
        if (!t.test(i)) return e;
        try {
          const r = i
            .split("&")
            .map((e) => {
              if (!t.test(e)) return e;
              const n = e.indexOf("=");
              return -1 === n
                ? encodeURIComponent(e)
                : `${encodeURIComponent(e.slice(0, n))}=${encodeURIComponent(
                    e.slice(n + 1)
                  )}`;
            })
            .join("&");
          return `${e.slice(0, n)}?${r}`;
        } catch {
          return e;
        }
      })({ creativeSearch: n || "" })}${i || ""}`;
    },
    W = ({ pathParts: e }) => {
      const t = Object.values($),
        n = new Set(t),
        i = e.findIndex((e) => n.has(e));
      let r = [...e];
      return -1 !== i && (r = e.slice(i)), r;
    },
    B = ({ url: e }) => `https:${e}`,
    G = ({ jsonOrObject: e }) => {
      let t = null;
      if ("string" == typeof e)
        try {
          t = JSON.parse(e);
        } catch (e) {}
      else t = e;
      return t;
    },
    H = ({ parsedUrl: e }) => {
      let t;
      const n = e.pathname.split("/").splice(1),
        i = W({ pathParts: n }),
        [r, o] = i;
      return (t = o || e.searchParams?.get("anId")), { anId: t, tagType: r };
    },
    Y = ({ parsedUrl: e }) => {
      const t = e.search,
        n = e.pathname.split("/").splice(1),
        i = W({ pathParts: n }),
        [r, o, s, a, ...c] = i,
        d = `/${c.join("/")}`;
      return {
        tagType: r,
        advEntityId: s,
        pubEntityId: a,
        creativeDomain: o,
        creativePath: d,
        creativeUrl: q({
          creativeDomain: o,
          creativePath: d,
          creativeSearch: t,
        }),
      };
    },
    z = ({ parsedUrl: e }) => {
      const t = e.pathname.split("/").splice(1),
        n = W({ pathParts: t }),
        [i] = n;
      return {
        tagType: i,
        contractId: e.searchParams?.get("ias_cId") || "",
        tagId: e.searchParams?.get("ias_tId") || "",
      };
    },
    X = function ({ pathname: e }) {
      let t = null;
      const n = Object.keys(T).find((t) => T[t].some((t) => e?.includes(t)));
      return n && (t = n), t;
    },
    J = ({ queryParameters: e }) => {
      let t = null,
        n = null;
      const i = e.get("anId"),
        r = e.get("advEntityId"),
        o = e.get("pubEntityId"),
        s = e.get("creativeUrl"),
        a = e.get("ias_tId"),
        c = e.get("ias_cId"),
        d = e.get("iasWidth"),
        u = e.get("iasHeight");
      if ((i && (t = { anId: i, tagType: $.Jload }), r && o))
        if (
          ((t = {
            advEntityId: r,
            pubEntityId: o,
            creativeUrl: s,
            tagType: $.Rjss,
          }),
          s)
        ) {
          const e = y({ url: s });
          (t.creativeDomain = e?.hostname || null),
            (t.creativePath = e?.pathname || null),
            (t.creativeSearch = e?.search || null),
            (t.creativeUrl = e
              ? q({
                  creativeDomain: e.host,
                  creativePath: e.pathname,
                  creativeSearch: e.search,
                  creativeHash: e.hash,
                  protocol: e.protocol,
                })
              : s);
        } else
          (t.creativeDomain = "st"),
            (t.creativePath = "/skeleton.js"),
            (t.creativeUrl = q({
              creativeDomain: "st",
              creativePath: "/skeleton.js",
            }));
      return (
        a && c && (t = { tagId: a, contractId: c, tagType: $.Amt }),
        (d || u) &&
          ((n = {}),
          d && (n.w = d),
          u && (n.h = u),
          t && (t.staticTagParams = n)),
        t
      );
    },
    K = ({ contextNode: e, measurementConfig: t }) => {
      const n = e?.queryParameters;
      return t.isStaticMode && n ? J({ queryParameters: n }) : null;
    };
  class Q extends a {
    constructor({ isDomless: t, contextNode: i, measurementConfig: r }) {
      super({ storeModelName: "adTag" }),
        (this.asid = gi()),
        (this.anId = null),
        (this.pubEntityId = null),
        (this.advEntityId = null),
        (this.tagId = null),
        (this.contractId = null),
        (this.tagType = null),
        (this.creativeDomain = null),
        (this.creativePath = null),
        (this.creativeSearch = null),
        (this.creativeUrl = null),
        (this.staticTagParams = null),
        (this.isScriptAsync = !1);
      const o = (({ isDomless: e, contextNode: t, measurementConfig: n }) => {
        let i = null;
        const r = p();
        return (
          e && r && (i = _({ tagUrl: r })),
          e || i || (i = E({ contextNode: t, measurementConfig: n })),
          e || i || (i = K({ contextNode: t, measurementConfig: n })),
          i
        );
      })({ isDomless: t, contextNode: i, measurementConfig: r });
      (this.isScriptAsync =
        !t &&
        (() => {
          let e = !1;
          try {
            const t = n.currentScript;
            e = !t || t.async || t.defer;
          } catch {}
          return e;
        })()),
        (this.anId = o?.anId),
        (this.pubEntityId = o?.pubEntityId),
        (this.advEntityId = o?.advEntityId),
        (this.tagId = o?.tagId),
        (this.contractId = o?.contractId),
        (this.tagType = o?.tagType || e.mode),
        (this.creativeDomain = o?.creativeDomain),
        (this.creativePath = o?.creativePath),
        (this.creativeSearch = o?.creativeSearch),
        (this.creativeUrl = o?.creativeUrl),
        (this.staticTagParams = o?.staticTagParams);
    }
    updateWithVerificationParameters({ verificationParameters: e }) {
      const t = (({ verificationParameters: e }) => {
        let t = null,
          n = null;
        const i = G({ jsonOrObject: e });
        if (i) {
          const { config: e } = i;
          e && (t = e), t && (n = k({ configPath: t }));
        }
        return n;
      })({ verificationParameters: e });
      (this.anId = this.anId ?? t?.anId),
        (this.pubEntityId = this.pubEntityId ?? t?.pubEntityId),
        (this.advEntityId = this.advEntityId ?? t?.advEntityId),
        (this.tagId = this.tagId ?? t?.tagId),
        (this.contractId = this.contractId ?? t?.contractId),
        (this.tagType = this.tagType ?? t?.tagType),
        (this.creativeDomain = this.creativeDomain ?? t?.creativeDomain),
        (this.creativePath = this.creativePath ?? t?.creativePath),
        (this.creativeSearch = this.creativeSearch ?? t?.creativeSearch),
        (this.creativeUrl = this.creativeUrl ?? t?.creativeUrl);
    }
    updateWithResolvedJsConfig({ jsConfig: e, measurementConfig: t }) {
      t.isStaticMode && !this.tagType && (this.tagType = e?.mode);
    }
  }
  class Z extends a {
    constructor({ bootstrapper: e }) {
      super({ storeModelName: "baseUrls" }),
        (this.ctvPlatformFromVp = !1),
        (this.dtBaseUrl = e?.dtBaseURL),
        (this.cmEventBaseUrl = e?.requrl),
        (this.fwEventBaseUrl = e?.adsafeSrc),
        (this.mobileAppEventBaseUrl = e?.mobFwUrl),
        (this.eventBaseUrl = this.fwEventBaseUrl || this.cmEventBaseUrl),
        e?.impressionBaseUrl &&
          (this.impressionBaseUrl = e.impressionBaseUrl.replace(/\/$/, "")),
        e?.enrichmentBaseUrl &&
          (this.enrichmentBaseUrl = e.enrichmentBaseUrl.replace(/\/$/, ""));
    }
    updateWithVerificationParameters({ verificationParameters: e }) {
      const t = o({ stringOrObject: e });
      if ("object" == typeof t) {
        const e = t?.iasImpBaseUrl,
          n = t?.iasDtBaseUrl,
          i = t?.iasMobileAppImpBaseUrl;
        n && (this.dtBaseUrl = n),
          e &&
            ((this.cmEventBaseUrl = e),
            (this.fwEventBaseUrl = e),
            (this.eventBaseUrl = e)),
          (i || e) && (this.mobileAppEventBaseUrl = i || e),
          "ctv" === t?.platform &&
            ((this.ctvPlatformFromVp = !0),
            !this.ctvImpressionUrl &&
              !this.ctvEnrichmentUrl &&
              this.impressionBaseUrl &&
              this.enrichmentBaseUrl &&
              ((this.ctvImpressionUrl =
                this.impressionBaseUrl + "/event/jsctv"),
              (this.ctvEnrichmentUrl =
                this.enrichmentBaseUrl + "/event/jsctv")));
      }
    }
    updateWithResolvedJsConfig({ jsConfig: e }) {
      this.dtBaseUrl || (this.dtBaseUrl = e?.dtBaseURL),
        this.cmEventBaseUrl || (this.cmEventBaseUrl = e?.requrl),
        this.fwEventBaseUrl || (this.fwEventBaseUrl = e?.adsafeSrc),
        this.mobileAppEventBaseUrl ||
          (this.mobileAppEventBaseUrl = e?.mobFwUrl),
        this.eventBaseUrl ||
          (this.eventBaseUrl = this.fwEventBaseUrl || this.cmEventBaseUrl),
        e?.impressionBaseUrl &&
          (this.impressionBaseUrl ||
            (this.impressionBaseUrl = e.impressionBaseUrl.replace(/\/$/, ""))),
        e?.enrichmentBaseUrl &&
          (this.enrichmentBaseUrl ||
            (this.enrichmentBaseUrl = e.enrichmentBaseUrl.replace(/\/$/, ""))),
        !this.ctvImpressionUrl &&
          !this.ctvEnrichmentUrl &&
          this.ctvPlatformFromVp &&
          this.impressionBaseUrl &&
          this.enrichmentBaseUrl &&
          ((this.ctvImpressionUrl = this.impressionBaseUrl + "/event/jsctv"),
          (this.ctvEnrichmentUrl = this.enrichmentBaseUrl + "/event/jsctv"));
    }
    isCtvSession() {
      return this.ctvPlatformFromVp;
    }
  }
  class ee extends a {
    constructor({
      isDomless: e,
      currentWindow: t,
      defaultBootstrapperConfig: n,
    }) {
      super({ storeModelName: "measurementConfig" }),
        this.setDefaultProps(),
        this.setBaseProps({ defaultBootstrapperConfig: n }),
        this.setVideoIdFromScriptUrl({
          currentScript: this.currentScript,
          isDomless: e,
        }),
        e ||
          this.setDomOnlyProps({
            currentWindow: t,
            isStaticMode: this.isStaticMode,
            currentScript: this.currentScript,
          });
    }
    setDefaultProps() {
      this.set("tagDeliveryType", "s", { locked: !1 });
    }
    setBaseProps({ defaultBootstrapperConfig: e }) {
      this.set("adRefreshThreshold", e.adRefreshThreshold),
        this.set("birthdate", e.birthdate),
        this.set("isResolved", e.isResolved, { locked: !1 }),
        this.set("perfBirth", e.perfBirth),
        this.set("staticMode", e.staticMode),
        this.set("useFIF", e.useFIF),
        this.set("currentScript", e.currentScript),
        this.set("iasParameters", e.iasParameters),
        this.set("jsDiag", !0),
        this.set("spImpJsInfoMinLength", 200),
        this.set("spImpMaxLength", 1e4),
        this.set("isStaticMode", e.staticMode, { locked: !1 }),
        this.set("isFrameInFrame", e.useFIF),
        this.set(
          "isStaticFrameInFrame",
          this.get("isStaticMode") && this.get("isFrameInFrame")
        ),
        this.setDebugProp();
    }
    setDomOnlyProps({ currentWindow: e, isStaticMode: t, currentScript: n }) {
      this.setSingleInstanceProps(),
        this.setTagDeliveryTypeProps({ currentWindow: e }),
        this.setStaticRedirectProps({ isStaticMode: t, currentScript: n });
    }
    setSingleInstanceProps() {
      try {
        this.set("adSlots", top?.iasAdSlots, { locked: !1 }),
          this.set("isSingleInstance", top?.isSingleIASInstance, {
            locked: !1,
          });
      } catch (e) {}
    }
    setTagDeliveryTypeProps({ currentWindow: e }) {
      const t = e?.location?.href?.includes("fw.html") ? "i" : "s",
        n = t ? "i" === t : void 0,
        i = t ? "s" === t : void 0;
      this.set("tagDeliveryType", t),
        this.set("isStaticIframeTag", n, { locked: !1 }),
        this.set("isStaticScriptTag", i, { locked: !1 });
    }
    setStaticRedirectProps({ isStaticMode: e, currentScript: t }) {
      e &&
        t?.src &&
        (t.src.includes("/jload") &&
          (this.set("isJloadRedirect", !0),
          this.set("isLegacyTagRedirectedToStatic", !0)),
        t.src.includes("/jsvid") &&
          (this.set("isJsvidRedirect", !0),
          this.set("isLegacyTagRedirectedToStatic", !0)),
        t.src.includes("/rjss") &&
          (this.set("isRjssRedirect", !0),
          this.set("isLegacyTagRedirectedToStatic", !0)),
        t.src.includes("/fwjsvid") &&
          (this.set("isFwjsvidRedirect", !0),
          this.set("isLegacyTagRedirectedToStatic", !0)),
        t.src.includes("/amt.js") &&
          (this.set("isAmtRedirect", !0),
          this.set("isLegacyTagRedirectedToStatic", !0)));
    }
    setDebugProp() {
      this.set("debug", !1);
    }
    setVideoIdFromScriptUrl({ currentScript: e, isDomless: t }) {
      const n = (({ url: e }) => {
        let t;
        if (e)
          try {
            const n = y({ url: e });
            if (n) {
              const e = n.searchParams?.get("videoId");
              t = e ?? void 0;
            }
          } catch {}
        return t;
      })({ url: e?.src || (t ? p() : null) || null });
      if (n) return void this.set("videoId", n);
      const i = e?.dataset?.iasParameters || this.iasParameters,
        r = o({ stringOrObject: i });
      null !== r &&
        "object" == typeof r &&
        "string" == typeof r.videoId &&
        this.set("videoId", r.videoId);
    }
    updateWithVerificationParameters({ verificationParameters: e }) {
      const t = o({ stringOrObject: e });
      "object" == typeof t &&
        (t?.iasImpBaseUrl && (this.impressionNodeType = "img"),
        t?.iasImpNodeType && (this.impressionNodeType = t?.iasImpNodeType));
    }
  }
  const te = new (class {
      constructor() {
        this.eventMap = {};
      }
      on(e, t) {
        this.eventMap[e] || (this.eventMap[e] = new Set()),
          this.eventMap[e].add(t);
      }
      off(e, t) {
        this.eventMap[e] && this.eventMap[e].delete(t);
      }
      emit(e, ...t) {
        this.eventMap[e] && this.eventMap[e].forEach((e) => e(...t));
      }
    })(),
    ne = ({ url: e, paramsToStrip: t = [] }) => {
      let n;
      if (e)
        try {
          const i = y({ url: e })?.search.slice(1).split("&") || [];
          n =
            i
              .filter((e) => {
                const n = e.replace(/=.*/, ""),
                  i = f(n);
                return !t.includes(i);
              })
              .join("&") || void 0;
        } catch {}
      return n;
    },
    ie = ({ url: e }) => {
      if (e && e.includes("fw.js"))
        return ne({
          url: e,
          paramsToStrip: ["config", "iasConfig", "creativeUrl"],
        });
    };
  class re extends a {
    constructor({ contextNodeElement: e }) {
      if ((super({ storeModelName: "contextNode" }), e)) {
        const t = new URL(e.src);
        this.set("element", e),
          this.set("srcUrl", t),
          this.set("src", t.href),
          this.set("path", t.pathname),
          this.set("protocol", t.protocol),
          this.set("dataAttributes", e.dataset),
          this.set("queryParameters", t.searchParams),
          this.set(
            "staticFwjsMacros",
            (({ url: e, iasParametersStr: t }) => {
              let n = ie({ url: e.href });
              const i = o({ stringOrObject: t });
              if (null !== i && "object" == typeof i) {
                n ||
                  "string" != typeof i.staticFwjsMacros ||
                  (n = i.staticFwjsMacros);
                const e = "string" == typeof i.videoId ? i.videoId : void 0;
                if (e && !n?.includes("videoId=")) {
                  const t = `videoId=${e}`,
                    i = n?.replace(/^&/, "");
                  n = i ? `${t}&${i}` : t;
                }
              }
              return n;
            })({ url: t, iasParametersStr: e.dataset?.iasParameters })
          );
      }
    }
  }
  const oe = new (class {
    addModel(e) {
      try {
        Object.defineProperty(this, e.storeModelName, {
          value: e,
          writable: !1,
          configurable: !1,
          enumerable: !0,
        });
      } catch (e) {}
      return this[e.storeModelName];
    }
    getHistory() {
      return Object.keys(this).reduce((e, t) => {
        const n = this[t].getHistory();
        return e.concat(n);
      }, []);
    }
    logHistory() {}
  })();
  function se() {
    let t = null;
    const n = oe.measurementConfig && oe.measurementConfig.currentScript,
      i = oe.contextNode && oe.contextNode.element;
    return (
      n && n.src
        ? (t = n.src)
        : e.currentScript && e.currentScript.src
        ? (t = e.currentScript.src)
        : i && i.src
        ? (t = i.src)
        : e.contextNode && e.contextNode.src && (t = e.contextNode.src),
      t || null
    );
  }
  function ae() {
    let t, n;
    const i = oe.measurementConfig;
    e.isSplitMode &&
      ((n = e.protocol + "://" + e.sp_cdnScripts.main),
      e.perf.markResource(ht, n)),
      e.impUrl && e.perf.markResource(yt, e.impUrl),
      (t = e.perf.getData()),
      i &&
        i.isStaticMode &&
        (t = Object.assign(
          {},
          t,
          (function () {
            let t,
              n,
              i,
              r,
              o,
              s = 0,
              a = 0,
              c = "u";
            const d = se(),
              u = e.perf.getResourceTiming(d);
            return (
              u &&
                ((r = Number(u.transferSize) || 0),
                (i = Number(u.encodedBodySize) || 0),
                (t = Number(u.decodedBodySize) || 0),
                (n = u.deliveryType),
                (o = t || i),
                (a = r > 0 || i > 0 || t > 0 ? 1 : 0),
                r > 0
                  ? (c = "n")
                  : o > 0 && 0 === r
                  ? (c = "l")
                  : "cache" === n && (c = "c"),
                a || "cache" === n || (c = "u"),
                (s = "u" !== c ? 1 : 0)),
              { rt: s, bc: c }
            );
          })()
        )),
      at
        .getAggregator()
        .trigger("addThrottledProp", "im", "prf", Ze(t).toION());
  }
  function ce() {
    if (e.executedContinueMain) return;
    oe.measurementConfig.isStaticMode &&
      oe.baseUrls.updateWithResolvedJsConfig({ jsConfig: e }),
      oe.adTag.updateWithResolvedJsConfig({
        jsConfig: e,
        measurementConfig: oe.measurementConfig,
      }),
      (e.executedContinueMain = !0),
      e.perf.markStart(dt),
      vt(e).verifyContextNode();
    const t = (function () {
        let t;
        const n = {};
        e.perf.markStart(ut), sr();
        const i = at.getAggregator();
        (function () {
          const t = at.getAggregator().request("omidAdSessionContext"),
            n = t.app && t.isDisplay && !t.isWeb,
            i = e.mobFwUrl && e.mobFwUrl.indexOf("/blocking/") > -1;
          i &&
            t.isLimitedSandbox &&
            "1" === e.adWidth &&
            "1" === e.adHeight &&
            (t.isLimitedSandbox = !1);
          n && i && (t.delayingViewabilityEvents = !0);
          ("app" !== t.environment && !0 !== e.mobAppWebview) ||
            ((e.origMobOrTab = e.mobOrTab), (e.mobOrTab = !0));
        })(),
          (n.mFeatures = i.request("features")),
          n.mFeatures || (n.mFeatures = i.provide("features", ui()));
        e.integration &&
          n.mFeatures.setReportedBootstrapFeatures("intblk", "integration");
        e.autotagSizeSet &&
          n.mFeatures.setReportedBootstrapFeatures("ats", "autotagSizeSet");
        (e.encodeInvalidUrlChars =
          !zn.isDomless() && n.mFeatures.on("encodeInvalidUrlChars")),
          i.provide("mobileApp", function () {
            return (t = t || new Us(n.mFeatures)), t;
          }),
          i.provide("context", zn),
          (n.mBrowser = i.request("browser")),
          (n.mErrors = i.request("mErrors")),
          (n.mIds = i.request("ids")),
          (n.iOutput = Zt(i));
        i.request("mJsonp");
        (n.mComm = i.request("mComm")),
          (n.viewabilityMeasurement = new Ao(
            $o(n.mIds),
            n.mFeatures,
            n.mBrowser
          ).create());
        (function (e, t) {
          if (e && e.queuedOutputItems)
            for (let n = 0; n < e.queuedOutputItems.length; n++)
              t.trigger(
                "addOutputItem",
                { output: e.queuedOutputItems[n].value },
                e.queuedOutputItems[n].code,
                { type: "impression" }
              );
        })(i.request("omidAdSessionContext"), i),
          (n.mAdTalk = new vr().createInstance(n.mFeatures));
        const r = Gt(),
          o = Hi(i),
          s = i.provide("mPage", new Ui().createInstance());
        (n.mAncestorOrigins = i.request("ancestorOrigins")),
          (n.mPageUrls = i.request("pageUrls")),
          (n.mAncestorOrigins = _n()),
          (n.mPageUrls = i.provide(
            "pageUrls",
            new Wi().createInstance(n.mAncestorOrigins, Fi)
          ));
        const a = i.provide("mScreenEvents", Yi()),
          c = li(n.mBrowser),
          d = (function (t, n) {
            const i = zn.isVideo() && !zn.isOmid() && !zn.isInMobiMraidVideo();
            i &&
              (at
                .getAggregator()
                .trigger("addOutputItem", { output: "v" }, "mtp", {
                  type: "impression",
                }),
              at
                .getAggregator()
                .trigger("addOutputItem", { output: "1" }, "xmvv", {
                  type: "impression",
                }));
            const r = oe.measurementConfig,
              o = (r && r.videoId) || e.videoId;
            return i ? ua(o, t, n) : {};
          })(n.mFeatures, a);
        (n.mVideo = i.provide("video", d)), fa(ya.build());
        const u = new ks().createInstance(n.mErrors, c, n.mFeatures),
          l = new vn().createInstance(u, n.mErrors, s, zn),
          m = i.provide("jobFactory", Ii());
        n.mDataTransfer = Zn(
          u,
          n.mErrors,
          n.mFeatures,
          n.mIds,
          n.iOutput,
          n.mBrowser,
          a,
          r
        );
        const g = Dn(n.mErrors, n.mFeatures, i, o);
        return (
          (n.mMode = Ri(
            g,
            n.mFeatures,
            n.viewabilityMeasurement.isImmediate()
          )),
          (n.mViewability = i.provide(
            "viewability",
            is(
              Yt(),
              n.viewabilityMeasurement,
              n.mBrowser,
              n.mDataTransfer,
              n.mFeatures,
              i,
              n.iOutput,
              l,
              a,
              n.mVideo
            )
          )),
          (function (t, n, i, r) {
            const o = (function (t) {
              const n = new Bo(t, zn),
                i = new Wo(),
                r = new Ho(t, zn),
                o = Go(t, zn),
                s = new Xo(e, zn, t).resolve(),
                a = [n],
                c = [];
              o.applies() && a.push(o);
              r.applies() && a.push(r);
              i.applies(t, zn) && a.push(i);
              s.forEach(function (e) {
                a.push(new zo(e, zn)), c.push(e.id);
              }),
                c.length > 0 &&
                  (at
                    .getAggregator()
                    .trigger("addOutputItem", { output: c.join(".") }, "scm", {
                      type: "impression",
                    }),
                  at
                    .getAggregator()
                    .trigger("addOutputItem", { output: c }, "metricIdList", {
                      type: "u",
                      asION: !0,
                    }));
              return a;
            })(t);
            at.getAggregator().provide("viewabilityDefinitions", o);
            const s = o.map(
              (function (e, t, n, i) {
                return function (r) {
                  let o, s, a, c;
                  const d = ns(r, t),
                    u = qo(n, e, r.rts).getCallbacks(),
                    l = Jt(
                      i.createPingJobs(
                        r.type,
                        r.timeInViewThresholds,
                        u,
                        r.metricId
                      )
                    );
                  return (
                    r.sendOtherwiseInViewSignal &&
                      ((c = ns(r, t, r.sendOtherwiseInViewSignal)),
                      (a = Jt(
                        i.createPingJobs(
                          r.type,
                          r.timeInViewThresholds,
                          u,
                          r.metricId,
                          r.sendOtherwiseInViewSignal
                        )
                      ))),
                    (r.rtsCallbacks = u),
                    "grpmMobPassThru" === r.thresholdType
                      ? (o = ts(d, r, l, zn.isVideo()))
                      : ((o = es(d, Tn(r.minUnit), l)),
                        r.sendOtherwiseInViewSignal &&
                          ((s = es(
                            c,
                            Tn(r.minUnit),
                            a,
                            r.sendOtherwiseInViewSignal
                          )),
                          s.start())),
                    o.start(),
                    o
                  );
                };
              })(t, n, i, r)
            );
            zn.isVideo() && new Ni().init();
          })(n.mFeatures, n.mViewability, o, m),
          (n.loopDelay = Pr()),
          (n.renderDetector = jt()),
          n.mDataTransfer.setViewabilityMod(n.mViewability),
          e.perf.markEnd(ut),
          n
        );
      })(),
      n = (function (t, n, i, r, o, s, a, c, d, u, l) {
        let m, g, p;
        try {
          new Xa({
            contextNode: e.contextNode,
            features: d,
            bootstrapper: e,
          }).start();
        } catch (e) {
          o.add("A2");
        }
        e.perf.markStart(lt),
          (e.b11 = "1" === e.adHeight && "1" === e.adWidth ? "true" : "false"),
          (e.cnod = e.contextNode ? "true" : "false"),
          at
            .getAggregator()
            .trigger(
              "addOutputItem",
              { output: oe.measurementConfig.mainBirthdate },
              "mtim",
              { type: "impression" }
            );
        const f = e.hasOwnProperty("origMobOrTab")
          ? e.origMobOrTab
          : e.mobOrTab;
        at
          .getAggregator()
          .trigger("addOutputItem", { output: f ? "1" : "0" }, "mot", {
            type: "impression",
          }),
          at
            .getAggregator()
            .trigger("addOutputItem", { output: e.app ? "1" : "0" }, "app", {
              type: "impression",
            }),
          at
            .getAggregator()
            .trigger(
              "addOutputItem",
              { output: e.mobAppWebview ? "1" : "0" },
              "maw",
              { type: "impression" }
            ),
          at
            .getAggregator()
            .trigger(
              "addOutputItem",
              { output: oe.measurementConfig.tagDeliveryType },
              "tdt",
              { type: "impression" }
            );
        const h = Pn().getUserAgent(),
          y = at.getAggregator().request("mobileApp");
        !(y && y.isMobileAppEnvironment && y.isMobileAppEnvironment()) &&
          h.indexOf("IMDb-flg") > -1 &&
          (at
            .getAggregator()
            .trigger("addOutputItem", { output: "1" }, "mapp", {
              type: "impression",
            }),
          at
            .getAggregator()
            .trigger("addOutputItem", { output: "a_imdb" }, "drul", {
              type: "impression",
            }));
        ue(i, r, d, o);
        try {
          s.isApplicable(a, u) && s.start(),
            (p = c.detectTopURL()),
            d.on("exch") && ((m = ai().createInstance(o, r)), m.parse(p)),
            (g = Na()),
            g.isApplicable(d) && g.start(d),
            u.usesGroupMCustomMetric() && Bt(),
            l.start();
        } catch (e) {
          o.add("L");
        }
        return e.perf.markEnd(lt), p;
      })(
        t.mDataTransfer,
        t.mViewability,
        t.mAdTalk,
        t.iOutput,
        t.mErrors,
        t.mAncestorOrigins,
        t.mBrowser,
        t.mPageUrls,
        t.mFeatures,
        zn,
        t.renderDetector
      );
    try {
      t.mFeatures.on("consentDetection") &&
        (at.getAggregator().trigger("dtEnterQueuingMode"),
        te.on("measurementStatus", ({ canSendMeasurementData: e }) => {
          e
            ? at.getAggregator().trigger("dtExitQueuingMode")
            : at.getAggregator().trigger("dtEnterQueuingMode");
        })),
        te.emit("consentDetection");
    } catch (e) {}
    !(function (t, n, i, r, o, s, a, c, d) {
      try {
        wa(t, n, i, r, o, s, a).send(c),
          Je(d.triggerInitializationEvents) && d.triggerInitializationEvents();
      } catch (t) {
        __IntegralASDiagnosticCall("impsend", t, e);
      }
    })(
      t.mErrors,
      t.mFeatures,
      t.mIds,
      t.mMode,
      t.iOutput,
      t.mBrowser,
      t.mViewability,
      n,
      t.mVideo
    ),
      (function (t, n, i, r, o, s, a, c, d, u, l, m, g) {
        try {
          e.perf.markStart(mt),
            (function () {
              const e = ma();
              e.start(), e.addFieldTypes(["im", "sca", "env", "xsca"]);
            })();
          try {
            if (
              (we(),
              "eligible" ===
                oe.mraidLifecycleTracker?.getSnapshot().eligibility)
            ) {
              const e = oe.mraidLifecycleTracker,
                t = () => {
                  try {
                    Ne(e.getSnapshot());
                  } catch (e) {}
                };
              t(),
                e.subscribe({
                  onReady: t,
                  onStateChange: () => {
                    1 === e.getSnapshot().stateChangeCount && t();
                  },
                  onViewableChange: () => {
                    1 === e.getSnapshot().viewableChangeCount && t();
                  },
                }),
                at.getAggregator().on("altAdSessionComplete", () => {
                  try {
                    t();
                  } catch (e) {}
                });
            }
          } catch (e) {}
          Ja(g),
            (function (e, t, n, i) {
              const r = kr(e, t, n);
              r.isApplicable(i) && r.start();
            })(t, n, i, r),
            (function (e, t, n, i, r, o) {
              let s;
              e.bootstrapOn("getTpl") &&
                e.on("usetpl") &&
                ((s = Mn(t, n, i, r, o)), s.init());
            })(r, o, s, a, n, c),
            (function (t, n, i, r, o, s, a, c, d) {
              let u;
              "true" !== e.minimizeCalls &&
                ((u = new Date().getTime()),
                Fi.execAtEndOfThread(function () {
                  de(t, n, i, r, u, o, s, a, c, d);
                }));
            })(c, d, u, a, r, o, s, n, m),
            (function (e) {
              e && e.start && e.start();
            })(l),
            ((e, t) => {
              if (!e.isDomless()) {
                const n = ka();
                let i = ["sca", "xsca", "rsrch"];
                e && e.isAMZN() && (i = []), n.start(i, t);
              }
            })(g, r),
            Cn(),
            at.runTier(7),
            (function (t) {
              const n = ga();
              n.isApplicable(t) &&
                (n.start(),
                Sa.recordBlockingTime(),
                e.perf.mark(gt),
                Sa.setupOnLoadTracking(),
                Sa.setupBrowserDelayTracking());
            })(r),
            Pa(),
            e.perf.markEnd(mt);
        } catch (e) {
          a.add("E");
        }
      })(
        t.mBrowser,
        t.mIds,
        t.mViewability,
        t.mFeatures,
        t.mComm,
        t.mDataTransfer,
        t.mErrors,
        t.iOutput,
        t.loopDelay,
        t.mAdTalk,
        t.viewabilityMeasurement,
        t.mAncestorOrigins,
        zn
      ),
      oe && oe.pageMetrics && oe.pageMetrics.sendPageMetricsData(),
      e.perf.markEnd(dt);
  }
  function de(t, n, i, r, o, s, a, c, d, u) {
    try {
      if ((e.perf.markStart(pt), e.tpiLookupURL)) {
        Si(a, c).init(e.tpiLookupURL);
      }
      zn.isDomless() || (u.isStarted() && u.sendOriginList()),
        at.runAll(),
        Fi.execAtEndOfThread(function () {
          !(function (t, n, i, r, o, s) {
            let a;
            try {
              e.perf.markStart(ft),
                (a = { output: new Date().getTime() - o }),
                t.addItem(a, "sinceFw", { type: "a" }),
                Xe(n.loopStarted()) &&
                  t.addItem({ output: n.loopStarted() }, "readyFired", {
                    type: "a",
                  }),
                e.perf.markEnd(ft),
                ae(),
                i.isApplicable(zn) && i.sendAdTalkCall();
            } catch (e) {
              r.add("f");
            }
          })(t, n, i, r, o);
        }),
        e.perf.markEnd(pt);
    } catch (e) {
      r.add("O");
    }
  }
  function ue(e, t, n, i) {
    let r;
    try {
      e.isApplicable(zn) &&
        (e.start(),
        t.addItem(e.getFrameMap(), "fm"),
        n.on("fm2") && t.addItem(e.getFrameMapIncludingPeerCase(), "fm2"),
        n.on("idMap") && ((r = e.getIdMap()), r && t.addItem(r, "idMap")));
    } catch (e) {
      i.add("c");
    }
  }
  const le = new Map(),
    me = new Map();
  let ge = !1,
    pe = !1;
  const fe = (e) => {
      try {
        e();
      } catch (e) {}
    },
    he = ({ fieldName: e, value: t }) => {
      fe(() => {
        at.getAggregator().trigger("addThrottledProp", "im", e, t);
      });
    },
    ye = (e) =>
      !0 === e ||
      1 === e ||
      "1" === e ||
      "true" === e ||
      (!1 !== e && 0 !== e && "0" !== e && "false" !== e && void 0),
    ve = (e) => {
      const t = ye(e);
      return void 0 === t ? void 0 : t ? 1 : 0;
    },
    Se = (e) =>
      null === e
        ? "null"
        : "string" == typeof e
        ? e.trim().length > 0
          ? "present"
          : "blank"
        : void 0,
    be = () => {
      try {
        const e = {};
        return (
          le.forEach((t, n) => {
            e[n] = t;
          }),
          e
        );
      } catch (e) {
        return {};
      }
    },
    Ie = (e) => {
      if (Array.isArray(e)) return e.length > 0;
      if ("string" == typeof e) {
        const t = e.trim();
        if (!t) return;
        return "[]" !== t;
      }
    },
    we = () => {
      fe(() => {
        (pe = !0),
          me.forEach((e, t) => he({ fieldName: t, value: e })),
          me.clear();
      });
    },
    Ae = () => {
      fe(() => {
        (ge = !0), le.clear();
      });
    },
    $e = (e) =>
      null == e || "" === e
        ? "missing"
        : "string" != typeof e
        ? "unsupported"
        : "script" === e || "img" === e
        ? "supported"
        : "unknown" === e
        ? "unknown"
        : "unsupported",
    Te = ye,
    Ee = (e) => ("string" == typeof e && e.length > 0 ? e : void 0),
    Ce = (e, t) => {
      fe(() => {
        null != t &&
          "" !== t &&
          ("number" != typeof t || (t == t && t !== 1 / 0 && t !== -1 / 0)) &&
          ("string" == typeof t && (nn(t) || on(t)) && (t = sn(t)),
          ge
            ? pe
              ? he({ fieldName: e, value: t })
              : me.set(e, t)
            : le.set(e, t));
      });
    },
    Oe = fe,
    _e = () => be(),
    Me = () =>
      !!oe.measurementConfig?.staticMode &&
      !!oe.staticFeatures?.useSingleEvent &&
      "rjss" === oe.adTag?.tagType &&
      !oe.baseUrls?.isCtvSession?.(),
    De = (e) => {
      Oe(() => {
        Ce("seia", e), Ce("seiat", zn.getTagTime());
      });
    },
    xe = (e, t, n, i) => {
      Oe(() => {
        Ce("semeg", e?.eligibility),
          Ce("semhv", e?.availability),
          Ce("semus", e?.firstUsableSource),
          Ce("semut", e?.firstUsableTime),
          Ce("semhs", e?.currentState || "missing"),
          Ce("semhu", ve(t)),
          Ce("semhf", n || "none"),
          "eligible" === e?.eligibility &&
            "usable" !== e.availability &&
            Ce("semds", 1),
          Ce("semht", i),
          Ce("semhe", ve(e?.mraidExists)),
          Ce("semhg", ve(e?.getStateAvailable)),
          Ce("semha", ve(e?.addEventListenerAvailable)),
          Ce("semhr", ve(e?.removeEventListenerAvailable)),
          Ce("semhi", ve(e?.isViewableAvailable)),
          Ce("semfs", e?.failureStage);
      });
    },
    Pe = (e) => {
      Oe(() => {
        Ce("semrx", e);
      });
    },
    Ne = (e) => {
      Oe(() => {
        e &&
          (Ce("sempa", e.availability),
          Ce("semus", e.firstUsableSource),
          Ce("semut", e.firstUsableTime),
          (e.mraidExists || e.initialState || e.objectReplaced) &&
            (Ce("semps", e?.currentState || "missing"),
            Ce("semro", ve(e?.readyObserved)),
            Ce("semri", ve(e?.readyInferred)),
            Ce("semrt", e?.readyTime),
            Ce("semdo", ve(e?.defaultObserved)),
            Ce("semdt", e?.defaultTime),
            Ce("semsc", e?.stateChangeCount),
            Ce("semvc", e?.viewableChangeCount),
            Ce("semst", e?.lastStateChangeTime),
            Ce("semvt", e?.lastViewableChangeTime),
            Ce("semrl", ve(e?.readyListenerAttached)),
            Ce("semsl", ve(e?.stateChangeListenerAttached)),
            Ce("semvl", ve(e?.viewableChangeListenerAttached)),
            Ce("semlv", ve(e?.currentViewable)),
            Ce("semor", ve(e?.objectReplaced)),
            Ce("semfs", e?.failureStage)));
      });
    },
    Ve = (e) => {
      Oe(() => {
        if (!e || "eligible" !== e.eligibility) return;
        const t = "usable" === e.availability ? "none" : e.availability;
        Ce("semtp", t),
          Ce("semus", e.firstUsableSource),
          Ce("semut", e.firstUsableTime),
          Ce("semsc", e.stateChangeCount),
          Ce("semvc", e.viewableChangeCount),
          Ce("semro", ve(e.readyObserved)),
          Ce("semdo", ve(e.defaultObserved)),
          Ce("semst", e.lastStateChangeTime),
          Ce("semvt", e.lastViewableChangeTime);
      });
    };
  function Re(t) {
    const n = t && t.sca,
      i = t && t.xsca,
      r = t && t.w,
      o = t && t.h;
    return function (t) {
      at.getAggregator().trigger(
        "addOutputItem",
        { output: zn.getTagTime() },
        "scs",
        { type: "impression" }
      );
      let s = "string" == typeof t ? JSON.parse(t) : t;
      try {
        if (Me()) {
          const e = oe.mraidLifecycleTracker;
          e?.refresh("response"), Ne(e?.getSnapshot());
        }
      } catch (e) {}
      try {
        if (Me()) {
          const e =
            s && "object" == typeof s.config && null !== s.config
              ? s.config
              : s;
          (a = {
            creativeUrl: s && s.creativeUrl,
            returnedNodeType: s && s.nodeType,
            serverMapp: e && e.mapp,
            deviceApp: e && e.app,
            mobileOrTablet: e && e.mobOrTab,
            mobileAppWebview: e && e.mobAppWebview,
            serverSideAppDetection: e && e.serverSideAppDetection,
          }),
            Oe(() => {
              Ce("secs", Se(a.creativeUrl)),
                Ce("sent", Ee(a.returnedNodeType)),
                Ce("sents", $e(a.returnedNodeType)),
                Ce("sems", ve(a.serverMapp)),
                Ce("seda", ve(a.deviceApp)),
                Ce("semot", ve(a.mobileOrTablet)),
                Ce("seaw", ve(a.mobileAppWebview)),
                Ce("sesd", ve(Ie(a.serverSideAppDetection)));
            });
        }
      } catch (e) {}
      var a;
      if (
        Me() &&
        s &&
        "object" == typeof s &&
        Object.prototype.hasOwnProperty.call(s, "creativeUrl") &&
        Object.prototype.hasOwnProperty.call(s, "nodeType")
      ) {
        const { creativeUrl: e, nodeType: t } = s;
        if ("string" == typeof e && e.trim().length > 0) {
          let n,
            i = "unchanged";
          try {
            (n = decodeURIComponent(e)),
              (i = n === e ? "unchanged" : "decoded");
          } catch (t) {
            (n = e), (i = "decode_error");
          }
          const r = "img" === t ? "img" : "script",
            o = "i" === oe.measurementConfig.tagDeliveryType ? "iframe" : r;
          try {
            ((e) => {
              Oe(() => {
                Ce("seut", e);
              });
            })(i);
          } catch (e) {}
          try {
            at.getAggregator().trigger("addNode", o, n);
            try {
              De("dispatched");
            } catch (e) {}
          } catch (e) {
            try {
              De("exception");
            } catch (e) {}
          }
        } else
          try {
            De("skipped_no_creative");
          } catch (e) {}
      }
      if (
        (s &&
          "object" == typeof s &&
          Object.prototype.hasOwnProperty.call(s, "config") &&
          (s = s.config),
        Object.assign)
      )
        Object.assign(e, s);
      else for (const t in s) e[t] = s[t];
      oe.measurementConfig.set("isResolved", !0),
        (e.sp_cdnScripts = e.sp_cdnScripts || {}),
        n && (e.sp_cdnScripts.sca = n),
        i && (e.sp_cdnScripts.xsca = i),
        r && o && ((e.adWidth = r), (e.adHeight = o), (e.autotagSizeSet = !0)),
        ce();
    };
  }
  const ke = "https://jsconfig.adsafeprotected.com/event",
    Fe = ["config", "iasConfig"],
    je = [
      "advEntityId",
      "pubEntityId",
      "creativeUrl",
      "format",
      "dmls",
      "ome",
      "mrd",
      "mad",
    ],
    Ue = ["adsafe_jsinfo", "adsafe_url", "adsafe_type"],
    Le = ({
      name: e,
      isDomless: t,
      queryParameters: n,
      domlessSearchParams: i,
      staticFwjsMacroParams: r,
    }) => {
      let o = null;
      if (t) {
        const t = i?.[e];
        o = "string" == typeof t ? t : null;
      } else o = n?.get(e) ?? null;
      return o ?? r?.[e] ?? null;
    },
    qe = ({ queryParts: e, key: t, value: n }) => {
      e.push(`${encodeURIComponent(t)}=${encodeURIComponent(n)}`);
    },
    We = /^[A-Za-z0-9._-]{1,64}$/,
    Be = "&adsafe_jsinfo=,",
    Ge = (e) =>
      e.replace(/%/g, "%25").replace(/&/g, "%26").replace(/#/g, "%23"),
    He = (e) => {
      const t = e?.queuedOutputItems;
      if (!Array.isArray(t)) return [];
      const n = Object.create(null),
        i = [];
      for (let e = 0; e < t.length && e < 1e3; e += 1) {
        const r = t[e];
        "string" == typeof r?.code &&
          0 !== r.code.length &&
          void 0 !== r.value &&
          null !== r.value &&
          (Object.prototype.hasOwnProperty.call(n, r.code) || i.push(r.code),
          (n[r.code] = String(r.value)));
      }
      return i.map((e) => `${Ge(e)}:${Ge(String(n[e]))}`);
    },
    Ye = () => {
      const e = zn.isDomless(),
        t = oe.jsConfigRequest?.contextNode ?? oe.contextNode,
        n = t?.queryParameters,
        i = e
          ? (() => {
              try {
                const e = p();
                if (e) {
                  const t = y({ url: e });
                  return t ? h({ search: t.search }) : void 0;
                }
              } catch {}
            })()
          : void 0,
        r = b({
          isDomless: e,
          contextNode: t,
          verificationParameters: oe.jsConfigRequest?.verificationParameters,
        }),
        o = r ? h({ search: "?" + r }) : void 0,
        s = at.getAggregator().request("omidAdSessionContext"),
        a = (s && s.environment) || "",
        c = e ? "1" : "0",
        d = zn.isMraid() ? "1" : "0",
        u = Bs(),
        l = Gs(),
        m = !e && oi.containsScriptTagWithSrc("mraid.js");
      try {
        const t = oe.mraidLifecycleTracker;
        t?.refresh("initial_request");
        const i = t?.getSnapshot(),
          r = oe.adTag?.creativeUrl,
          o =
            "string" == typeof r && r.trim().length > 0 ? "present" : "missing",
          s = e ? void 0 : n?.get("creativeUrl");
        ((e, t, n) => {
          Oe(() => {
            Ce("seqcs", t),
              Ce("seqcu", n),
              Ce("semta", ve(e?.active)),
              Ce("semia", e?.availability),
              e?.mraidExists &&
                (Ce("sepaf", 0),
                Ce("semme", 0),
                Ce("semis", e?.initialState || "missing"),
                Ce("semgs", ve(e?.getStateAvailable)),
                Ce("semae", ve(e?.addEventListenerAvailable)),
                Ce("semre", ve(e?.removeEventListenerAvailable)),
                Ce("semiv", ve(e?.isViewableAvailable)),
                Ce("semvv", ve(e?.initialViewable)),
                Ce("semt0", e?.trackerStartTime),
                Ce("semfs", e?.failureStage));
          });
        })(
          i,
          o,
          s
            ? "explicit"
            : "string" == typeof oe.adTag?.creativePath &&
              -1 !== oe.adTag.creativePath.indexOf("skeleton.js")
            ? "skeleton"
            : r
            ? "reconstructed"
            : "missing"
        );
      } catch (e) {}
      try {
        (g = {
          clientDetectionSignal: u,
          clientOmidEnvironment: a,
          clientDomless: c,
          clientMraid: d,
          clientMraidShape: l,
          clientMraidScriptTag: m,
        }),
          Oe(() => {
            Ce("semad", Ee(g.clientDetectionSignal) || "none"),
              Ce("seome", Ee(g.clientOmidEnvironment) || "none"),
              Ce("sedml", ve(g.clientDomless)),
              Ce("semrd", ve(g.clientMraid)),
              Ce("semsh", Ee(g.clientMraidShape) || "absent"),
              Ce("semjs", ve(g.clientMraidScriptTag));
          });
      } catch (e) {}
      var g;
      const f = at.getAggregator().request("ancestorOrigins");
      f.isApplicable(at.getAggregator().request("browser"), zn) && f.start();
      const v = at.getAggregator().request("pageUrls").detectTopURL(),
        S = oe.measurementConfig?.spImpMaxLength ?? 1e4,
        I = S - ke.length - (oe.measurementConfig?.spImpJsInfoMinLength ?? 200),
        w = (({
          isDomless: e,
          queryParameters: t,
          domlessSearchParams: n,
          staticFwjsMacroParams: i,
          pageUrlCandidates: r,
          domlessFlag: o,
          omidEnvironment: s,
          mraidFlag: a,
          appDetectionSignal: c,
        }) => {
          const d = [],
            u = Object.create(null),
            l = (e) => Fe.includes(e) || je.includes(e) || Ue.includes(e),
            m = (e, t) => {
              qe({ queryParts: d, key: e, value: t }), (u[e] = !0);
            };
          if (e) {
            if (n) {
              const e = 1e3,
                t = Object.keys(n);
              for (let i = 0; i < t.length && i < e; i += 1) {
                const e = t[i];
                if (l(e)) continue;
                const r = n[e];
                m(e, String(r));
              }
            }
          } else if (t) {
            const e = 1e3;
            let n = 0;
            t.forEach((t, i) => {
              n >= e || ((n += 1), l(i) || m(i, t));
            });
          }
          if (i) {
            const e = 1e3,
              t = Object.keys(i);
            for (let n = 0; n < t.length && n < e; n += 1) {
              const e = t[n];
              l(e) || u[e] || m(e, i[e]);
            }
          }
          qe({
            queryParts: d,
            key: "advEntityId",
            value: oe.adTag?.advEntityId || "",
          }),
            qe({
              queryParts: d,
              key: "pubEntityId",
              value: oe.adTag?.pubEntityId || "",
            }),
            qe({
              queryParts: d,
              key: "creativeUrl",
              value: oe.adTag?.creativeUrl || "",
            }),
            qe({ queryParts: d, key: "format", value: "jsonp" }),
            qe({ queryParts: d, key: "dmls", value: o }),
            qe({ queryParts: d, key: "ome", value: s }),
            qe({ queryParts: d, key: "mrd", value: a }),
            qe({ queryParts: d, key: "mad", value: c });
          for (const e of r) d.push(e);
          return d;
        })({
          isDomless: e,
          queryParameters: n,
          domlessSearchParams: i,
          staticFwjsMacroParams: o,
          pageUrlCandidates: Ma(v, I, ke.length, !0),
          domlessFlag: c,
          omidEnvironment: a,
          mraidFlag: d,
          appDetectionSignal: u,
        }),
        A = (({
          maxUrlLength: e,
          queryParts: t,
          isDomless: n,
          queryParameters: i,
          domlessSearchParams: r,
          staticFwjsMacroParams: o,
          appDetectionSignal: s,
          omidAdSessionContext: a,
        }) => {
          const c = oe.adTag?.asid || "",
            d = oe.adTag?.tagType || "",
            u = oe.measurementConfig?.tagDeliveryType || "",
            l = zn.embedded.toString(),
            m = zn.friendly.toString(),
            g = at.getAggregator().request("ids").getCacheBustId(),
            p = Ze.stringifyTriState(ji()),
            f = `mu:${e}`,
            h = at.getAggregator().request("browser"),
            y = Object.entries(h.params()).map(([e, t]) => `${e}:${String(t)}`),
            v = at.getAggregator().request("mErrors").toString(),
            S = `et:${zn.getTagTime()}`,
            b = (e) => (null != e && We.test(e) ? e : void 0),
            I = Le({
              name: "xmtp",
              isDomless: n,
              queryParameters: i,
              domlessSearchParams: r,
              staticFwjsMacroParams: o,
            }),
            w = "v" === I || "a" === I ? I : void 0,
            A = b(
              Le({
                name: "iasProxyPartnerId",
                isDomless: n,
                queryParameters: i,
                domlessSearchParams: r,
                staticFwjsMacroParams: o,
              })
            ),
            $ = b(
              Le({
                name: "ias_xpc",
                isDomless: n,
                queryParameters: i,
                domlessSearchParams: r,
                staticFwjsMacroParams: o,
              })
            ),
            T = [
              `id:${c}`,
              `c:${g}`,
              "sse:1",
              "st:1",
              `tt:${d}`,
              "v:19.8.748",
              `em:${l}`,
              `fr:${m}`,
              `thd:${p}`,
              f,
              ...y,
              S,
            ],
            E = [
              { shouldEmit: Boolean(v), code: `e:${v}` },
              { shouldEmit: Boolean(w), code: `xmtp:${w ?? ""}` },
              { shouldEmit: "a" === w, code: "vau:1" },
              { shouldEmit: Boolean(A), code: `ppi:${A ?? ""}` },
              { shouldEmit: Boolean($), code: `x_xpc:${$ ?? ""}` },
            ];
          for (const { shouldEmit: e, code: t } of E) e && T.push(t);
          const C = [...T],
            O = a?.mediaType,
            _ = "display" === (M = O) ? "d" : "video" === M ? "v" : "";
          var M;
          const D =
              "web" === a?.environment
                ? "a_oweb"
                : "app" === a?.environment
                ? s
                : "",
            x = [
              ...(D ? [`drul:${D}`] : []),
              ...(_ ? [`mtp:${_}`] : []),
              ...He(a),
              `tdt:${u}`,
            ],
            P = ke.length + t.join("&").length + 1;
          let N = Be.length + C.join(",").length,
            V = 0;
          for (const t of x)
            P + N + t.length + 5 <= e
              ? (C.push(t), (N += t.length + 1))
              : (V += 1);
          return (
            C.push(`ov:${V}`),
            oe.singleEventImpressionJsInfo?.setPieces(C),
            `&adsafe_jsinfo=,${C.join(",")}`
          );
        })({
          maxUrlLength: S,
          queryParts: w,
          isDomless: e,
          queryParameters: n,
          domlessSearchParams: i,
          staticFwjsMacroParams: o,
          appDetectionSignal: u,
          omidAdSessionContext: s,
        });
      return `${ke}?${w.join("&")}${A}`;
    };
  const ze = () => {
    oe.measurementConfig?.isResolved
      ? ce()
      : Me()
      ? (() => {
          const e = oe.jsConfigRequest?.verificationParameters,
            t = oe.jsConfigRequest?.contentType,
            n = Ye();
          at
            .getAggregator()
            .trigger("addOutputItem", { output: zn.getTagTime() }, "scq", {
              type: "impression",
            }),
            at
              .getAggregator()
              .trigger("addOutputItem", { output: 1 }, "scb", {
                type: "impression",
              }),
            "application/json" === t
              ? at.getAggregator().trigger("getJSON", n, Re(e))
              : at.getAggregator().trigger("jsonp", n, Re(e), !1, "cbName");
        })()
      : (() => {
          const e = oe.jsConfigRequest?.url,
            t = oe.jsConfigRequest?.contentType,
            n = oe.jsConfigRequest?.verificationParameters;
          if (e) {
            at.getAggregator().trigger(
              "addOutputItem",
              { output: zn.getTagTime() },
              "scq",
              { type: "impression" }
            );
            const i = "cbName";
            "application/json" === t
              ? at.getAggregator().trigger("getJSON", e, Re(n))
              : at.getAggregator().trigger("jsonp", e, Re(n), !1, i);
          }
        })();
  };
  const Xe = (e) => void 0 !== e,
    Je = (e) => "function" == typeof e,
    Ke = (e) => "string" == typeof e,
    Qe = (e) => (!0 === e ? 1 : !1 === e ? 0 : "na");
  var Ze = function (e) {
      "use strict";
      return new et(e);
    },
    et = function (e) {
      "use strict";
      this.iterable = e;
    };
  (et.prototype.isObj = function (e) {
    "use strict";
    var t = "object" == typeof this.iterable,
      n = null === this.iterable,
      i = t && !n,
      r = !this.isArray() && i;
    return e ? i : r;
  }),
    (et.prototype.isArray = function () {
      "use strict";
      return this.iterable instanceof Array;
    }),
    (et.prototype.isEmpty = function (e) {
      "use strict";
      return 0 === this.keys(e).length;
    }),
    (et.prototype.each = function (e, t) {
      "use strict";
      var n = this.iterable;
      if (n.length === +n.length)
        for (var i = 0, r = n.length; i < r; ++i) e(i, n[i]);
      else for (var o in n) (n.hasOwnProperty(o) || t) && e(o, n[o]);
    }),
    (et.prototype.map = function (e, t) {
      "use strict";
      var n = [];
      return (
        this.each(function (i, r) {
          var o = e(i, r);
          (void 0 !== o || t) && (n[n.length] = o);
        }),
        n
      );
    }),
    (et.prototype.stringify = function (e, t) {
      "use strict";
      t = t || ",";
      var n = [];
      return (
        this.each(function (t, i) {
          var r = e(t, i);
          Xe(r) && n.push(r);
        }),
        n.join(t)
      );
    }),
    (et.prototype.toION = function (e, t) {
      "use strict";
      var n,
        i = "[",
        r = "]";
      return (
        (t = t || 0),
        (e = e || {}),
        ++t > 4
          ? "object"
          : !this.isObj(!0) || this.iterable.hasOwnProperty("toString")
          ? "" + this.iterable
          : (this.isArray()
              ? (n = this.map(function (n, i) {
                  return Ze(i).toION(e, t);
                }))
              : ((i = "{"),
                (r = "}"),
                (n = this.map(function (n, i) {
                  var r = "string" == typeof n && -1 !== n.indexOf("NULL"),
                    o = Ze(i).toION(e, t);
                  return r ? o : (e[n] || n) + ":" + o;
                }))),
            i + n.join(",") + r)
      );
    }),
    (et.prototype.compareTo = function (e) {
      "use strict";
      var t = !1;
      return (
        this.each(function (n, i) {
          e[n] !== i && (t || (t = {}), (t[n] = i));
        }),
        t
      );
    }),
    (et.prototype.toParams = function (e) {
      "use strict";
      return this.stringify(function (e, t) {
        return "string" == typeof e && -1 !== e.indexOf("NULL")
          ? t
          : e + ":" + t;
      }, e);
    }),
    (et.prototype._privateMixin = function (e, t, n) {
      "use strict";
      var i;
      for (i in t) Xe(t[i]) && (n || t.hasOwnProperty(i)) && (e[i] = t[i]);
      return e;
    }),
    (et.prototype.mapToObj = function (e) {
      "use strict";
      var t = {},
        n = this;
      return (
        this.each(function (i, r) {
          var o = e(i, r);
          Ze(o).isObj() && n._privateMixin(t, o);
        }),
        t
      );
    }),
    (et.prototype.mixin = function (e, t) {
      "use strict";
      return this._privateMixin(this.iterable, e, t);
    }),
    (et.prototype.find = function (e) {
      "use strict";
      var t;
      return (
        this.each(function (n, i) {
          e(n, i) && (t = i);
        }),
        t
      );
    }),
    (et.prototype.findFirst = function (e) {
      "use strict";
      var t, n;
      return (
        this.each(function (i, r) {
          !n && e(i, r) && ((t = r), (n = !0));
        }),
        t
      );
    }),
    (et.prototype.keys = function (e) {
      "use strict";
      var t = [];
      return (
        this.each(function (e) {
          t.push(e);
        }, e),
        t
      );
    }),
    (et.prototype.asStrings = function () {
      "use strict";
      var e = {};
      return (
        this.each(function (t, n) {
          e[t] = "" + n;
        }),
        e
      );
    }),
    (et.prototype.selectProperties = function (e) {
      "use strict";
      var t = {},
        n = this;
      return (
        Ze(e).each(function (e, i) {
          Xe(n.iterable[i]) && (t[i] = n.iterable[i]);
        }),
        t
      );
    }),
    (et.prototype.filter = function (e, t) {
      "use strict";
      return this.map(function (t, n) {
        var i;
        return (void 0 === e || rt(e, t, n)) && (i = n), i;
      }, t);
    }),
    (et.prototype.toArray = function () {
      "use strict";
      return this.map(function (e, t) {
        return t;
      });
    });
  const tt = (e, t) => {
      var n,
        i = e < 0,
        r =
          "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ".split(
            ""
          ),
        o = [];
      e = i ? -e : e;
      do {
        (n = e % t), o.push(r[n]), (e = (e - n) / t);
      } while (e > 0);
      return (o = o.reverse().join("")), i ? "-" + o : o;
    },
    nt = () => {},
    it = (e) => {
      var t = parseInt(e);
      return isFinite(t) || (t = -1), t;
    };
  function rt(e, ...t) {
    return Je(e) ? e.apply({}, t) : e;
  }
  const ot = (e) => Xe(e) && null !== e && !isNaN(e),
    st = (e, t) => {
      var n = {
          $: "%24",
          "[": "%5B",
          "]": "%5D",
          "{": "%7B",
          "}": "%7D",
          "|": "%7C",
        },
        i = e;
      return (
        t &&
          "string" == typeof e &&
          (i = (i = e.replace(/%(?![0-9A-F][0-9A-F])/gi, "%25")).replace(
            /\$|\[|\]|\{|\}|\|/gi,
            function (e) {
              return n[e];
            }
          )),
        i
      );
    };
  (Ze.toBase = tt),
    (Ze.isDef = Xe),
    (Ze.noop = nt),
    (Ze.isFunction = Je),
    (Ze.isStr = Ke),
    (Ze.stringifyTriState = Qe),
    (Ze.getNum = it),
    (Ze.resolve = rt),
    (Ze.isNumeric = ot),
    (Ze.encodeInvalidUrlChars = st);
  const at = (function () {
      "use strict";
      let e,
        t = {},
        n = [],
        i = [];
      const r = function (...e) {
          const t = {},
            n = Ze(arguments).toArray();
          return n.unshift(t), i.push(n), t;
        },
        o = function (i, r, o, s, a) {
          let c, d;
          a = a || {};
          const u = function () {
            if (!c) {
              let r = [];
              const u = !0;
              (c = !0),
                (t = ["features", "browser", "context"]),
                0 === n.length &&
                  (n = Ze(t).map(function (t, n) {
                    return e.request(n);
                  })),
                a.emits && (i.events = new Yt()),
                (a.applies && !a.applies.apply(a, n)) ||
                  ((d = !0),
                  (r = Ze(o).map(function (t, n) {
                    return e.request(n);
                  }, u)),
                  r.push(i),
                  Ze(i).mixin(s.apply({}, r)));
            }
            var t;
          };
          return (
            (function () {
              const e = a.tier;
              Xe(e) && ((t[e] = t[e] || new Xt()), t[e].push(u));
            })(),
            e.provide(r, function () {
              let e;
              return u(), d && (e = i), e;
            }),
            i
          );
        };
      return (
        (r.runAll = function () {
          const e = Ze(t)
            .keys()
            .sort(function (e, t) {
              return e - t;
            });
          Ze(e).each(function (e, t) {
            r.runTier(t);
          });
        }),
        (r.runTier = function (e) {
          t[e].run(), delete t[e];
        }),
        (r.startSystem = function () {
          (e = e || new Ht()),
            Ze(i).each(function (e, t) {
              o.apply({}, t);
            });
        }),
        (r.getAggregator = function () {
          return e;
        }),
        r
      );
    })(),
    ct = "mf",
    dt = "cm",
    ut = "in",
    lt = "pr",
    mt = "po",
    gt = "bl",
    pt = "lo",
    ft = "lt",
    ht = "md",
    yt = "id";
  const vt = function (e) {
      "use strict";
      return {
        verifyContextNode: function () {
          !(
            __IASScope.isDomless ||
            (e.contextNode && null !== e.contextNode.parentNode)
          ) &&
            (e.contextNode = (function () {
              let t;
              const i = n.getElementsByTagName("script");
              let r = i.length,
                o = i[r - 1];
              const s = e.scriptUrl;
              try {
                for (; --r >= 0; )
                  if (
                    ((t = i[r]),
                    t.src &&
                      0 === t.src.indexOf(s) &&
                      null === t.getAttribute("data-ias-script-tag"))
                  ) {
                    (o = t), t.setAttribute("data-ias-script-tag", "found");
                    break;
                  }
              } catch (e) {}
              return o;
            })());
        },
      };
    },
    St = {
      getMessageHandler: (e, t) => {
        const n = St.getCallId(),
          i = (r) => {
            try {
              r &&
                r.data &&
                r.data[e] &&
                r.data[e].callId === n &&
                r.data[e].returnValue &&
                (t(r.data[e].returnValue),
                Jn.removeEvent(Fi.getWindow(), "message", i));
            } catch (e) {
              at.getAggregator().trigger("error", "g");
            }
          };
        return i;
      },
      getCallId: () => "ias_" + (oe.adTag && oe.adTag.asid),
      send: (e, t) => {
        at.getAggregator().trigger("addThrottledProp", "env", e, t);
      },
    },
    bt = {
      name: "CCPAConsentDetector",
      dependencies: [],
      creator: function () {
        "use strict";
        const e = (e) => {
          e && St.send("ccd", Ze(e).toION());
        };
        (() => {
          const t = Vt({
            apiFunctionName: "__uspapi",
            apiFrameLocatorName: "__uspapiLocator",
          });
          St.send("cca", !!t),
            t &&
              ((t) => {
                let n, i;
                Je(t)
                  ? t("getUSPData", 1, e)
                  : ((n = {
                      __uspapiCall: {
                        command: "getUSPData",
                        version: 1,
                        callId: St.getCallId(),
                      },
                    }),
                    (i = St.getMessageHandler("__uspapiReturn", e)),
                    Jn.addEvent(Fi.getWindow(), "message", i),
                    t.postMessage(n, "*"));
              })(t);
        })();
      },
      settings: {
        tier: 8,
        applies: (e, t, n) => {
          "use strict";
          return t.hasPostMessage() && !n.isDomless();
        },
      },
    },
    It = {
      name: "GDPRConsentDetector",
      dependencies: [],
      creator: function () {
        "use strict";
        const e = 278,
          t = (e) => {
            const t =
                Xe(e) && Xe(e.vendorConsents) && Xe(e.vendorConsents[278])
                  ? e.vendorConsents[278]
                  : void 0,
              n = {
                appl: Qe(e.gdprApplies),
                cnst: Qe(t),
                glbl: Qe(e.hasGlobalScope),
                mtdt: encodeURIComponent(e.metadata),
              },
              i = e && e.tcString;
            at.getAggregator().provide("tcString", () => i),
              St.send("gcd", Ze(n).toION());
          };
        (() => {
          const n = Vt({
            apiFunctionName: "__cmp",
            apiFrameLocatorName: "__cmpLocator",
          });
          St.send("gca", !!n),
            n &&
              ((n) => {
                let i, r;
                Je(n)
                  ? n("getVendorConsents", [e], t)
                  : ((i = {
                      __cmpCall: {
                        command: "getVendorConsents",
                        parameter: [e],
                        callId: St.getCallId(),
                      },
                    }),
                    (r = St.getMessageHandler("__cmpReturn", t)),
                    Jn.addEvent(Fi.getWindow(), "message", r),
                    n.postMessage(i, "*"));
              })(n);
        })();
      },
      settings: {
        tier: 8,
        applies: (e, t, n) => {
          "use strict";
          return t.hasPostMessage() && !n.isDomless();
        },
      },
    },
    wt = {
      name: "GDPRV2ConsentDetector",
      dependencies: [],
      creator: () => {
        const e = (e) => {
          const t =
              Xe(e) &&
              Xe(e.vendor) &&
              Xe(e.vendor.consents) &&
              Xe(e.vendor.consents[278])
                ? e.vendor.consents[278]
                : void 0,
            n = { appl: Qe(e?.gdprApplies), cnst: Qe(t) };
          St.send("gcd2", Ze(n).toION());
        };
        (() => {
          const t = Vt({
            apiFunctionName: "__tcfapi",
            apiFrameLocatorName: "__tcfapiLocator",
          });
          St.send("gca2", !!t),
            t &&
              ((t) => {
                let n, i;
                if (Je(t))
                  try {
                    t("addEventListener", 2, e);
                  } catch (n) {
                    try {
                      t("getTCData", 2, e);
                    } catch (e) {}
                  }
                else
                  (n = {
                    __tcfapiCall: {
                      command: "addEventListener",
                      callId: St.getCallId(),
                      version: 2,
                    },
                  }),
                    (i = St.getMessageHandler("__tcfapiReturn", e)),
                    Jn.addEvent(Fi.getWindow(), "message", i, !1),
                    t.postMessage(n, "*");
              })(t);
        })();
      },
      settings: {
        tier: 8,
        applies: (e, t, n) => t.hasPostMessage() && !n.isDomless(),
      },
    };
  class At extends a {
    constructor() {
      super(...arguments), (this.failed = !1), (this.callbacks = []);
    }
    onConsentFrameworkChange(e) {
      this.callbacks.push(e);
    }
    emitConsentFrameworkChange() {
      this.callbacks.forEach((e) => {
        e();
      });
    }
  }
  class $t extends a {
    constructor() {
      super({ storeModelName: "ConsentDetection" }),
        (this.consentDetection = !1),
        (this.isAbleToMeasure = !1),
        (this.previousConsentState = !1),
        (this.hasGottenAllUserInputs = !1),
        (this.hasSentInitialMinDT = !1),
        (this.consentFrameworkRecords = {}),
        (this.sendMinimalDTCall = ({ fields: e }) => {
          this.consentDetection &&
            at
              .getAggregator()
              .trigger("sendMinDt", "e", -5, { field: "tv", value: e });
        }),
        (this.updateMeasurementStatus = ({ newIsAbleToMeasure: e }) => {
          e !== this.isAbleToMeasure &&
            (this.set("isAbleToMeasure", e, { locked: !1 }),
            te.emit("measurementStatus", {
              canSendMeasurementData: this.isAbleToMeasure,
            }));
        }),
        (this.consentFrameworkRecords.tcf = {
          framework: new Et(),
          isAbleToMeasure: !1,
          DTFields: {},
          evaluator: Tt,
        }),
        this.startOnPubSubCD();
    }
    startOnPubSubCD() {
      te.on("consentDetection", () => {
        try {
          this.start();
        } catch (e) {}
      });
    }
    start() {
      Object.values(this.consentFrameworkRecords).forEach((e) => {
        const t = e.framework;
        if (t.applies()) {
          const e = this.checkFrameworks.bind(this);
          t.onConsentFrameworkChange(e), t.start();
        }
      });
      at.getAggregator().request("features").on("consentDetection") &&
        this.set("consentDetection", !0, { locked: !1 }),
        this.checkFrameworks();
    }
    checkFrameworks() {
      try {
        let e = !0;
        const t = {},
          n = Object.values(this.consentFrameworkRecords);
        n.forEach((n) => {
          const { DTFields: i, isAbleToMeasure: r } = n.evaluator(n.framework);
          e && (e = r), Object.assign(t, i), this.sendDTFields(i);
        }),
          !this.hasGottenAllUserInputs &&
            n.every((e) => e.evaluator(e.framework).hasUserInput) &&
            (this.hasGottenAllUserInputs = !0),
          ((this.hasGottenAllUserInputs && !this.hasSentInitialMinDT) ||
            (this.previousConsentState && !e)) &&
            (this.sendMinimalDTCall({ fields: t }),
            (this.hasSentInitialMinDT = !0)),
          (this.previousConsentState = e),
          this.updateMeasurementStatus({ newIsAbleToMeasure: e });
      } catch (e) {}
    }
    sendDTFields(e) {
      Object.entries(e).forEach(([e, t]) => {
        at.getAggregator().trigger("addOutputItem", { output: t }, e);
      });
    }
  }
  const Tt = (e) => {
    let t = !0,
      n = !1,
      i = {};
    if (!e.failed) {
      const r = e.consentData;
      (n = Nt({ consentData: r })),
        (t = Ct({ consentData: r })),
        (i = Dt({ consentData: r, isAbleToMeasure: t }));
    }
    return { isAbleToMeasure: t, DTFields: i, hasUserInput: n };
  };
  class Et extends At {
    constructor() {
      super({ storeModelName: "TransparencyConsentFramework" }),
        (this.consentData = null),
        (this.listenerIDs = []),
        (this.messageHandlers = []);
    }
    applies() {
      return !zn.isDomless();
    }
    start() {
      (this.apiEntrance = Vt({
        apiFunctionName: "__tcfapi",
        apiFrameLocatorName: "__tcfapiLocator",
      })),
        this.addTCFAPIEventListener(),
        this.onUnloadRemoveTCF();
    }
    messageHandler(e) {
      e &&
        (this.set("consentData", e, { locked: !1 }),
        this.emitConsentFrameworkChange()),
        Pt({
          consentData: e,
          listenerIDs: this.listenerIDs,
          messageHandlers: this.messageHandlers,
        });
    }
    onUnloadRemoveTCF() {
      at.getAggregator().on("unload", () => {
        this.end();
      });
    }
    end() {
      xt({
        apiEntrance: this.apiEntrance,
        listenerIDs: this.listenerIDs,
        messageHandlers: this.messageHandlers,
      });
    }
    addTCFAPIEventListener() {
      this.apiEntrance
        ? _t({
            apiEntrance: this.apiEntrance,
            command: "addEventListener",
            tcfv: 2,
            action: this.messageHandler.bind(this),
          })
        : (this.failed = !0);
    }
  }
  const Ct = ({ consentData: e }) => {
      let t = !1;
      try {
        const n = e?.gdprApplies;
        if (n) {
          if (n && "useractioncomplete" === e?.eventStatus) {
            Ot({ consentData: e }) && (t = !0);
          }
        } else t = !0;
      } catch (e) {}
      return t;
    },
    Ot = ({ consentData: e }) => {
      const { vendor: t, purpose: n } = e,
        i = t?.consents,
        r = i?.[278] || !1,
        o = t?.legitimateInterests,
        s = o?.[278] || !1,
        a = n?.legitimateInterests,
        c = [10, 7].every((e) => a?.[e] || !1);
      return r || (s && c);
    },
    _t = ({ apiEntrance: e, command: t, tcfv: n, action: i, id: r }) => {
      if (e)
        if ("function" == typeof e)
          try {
            e(
              t,
              n,
              (e, t) => {
                t && i(e);
              },
              r
            );
          } catch (e) {}
        else if (e && "function" == typeof e.postMessage) {
          const r = (e) => {
              const t = e.data;
              if (
                1 === t?.__tcfapiReturn?.callId &&
                t?.__tcfapiReturn?.success
              ) {
                const e = t.__tcfapiReturn.returnValue;
                (e.messageHandler = r), i(e);
              }
            },
            o = { __tcfapiCall: { command: t, callId: 1, version: n } };
          Jn.addEvent(Fi.getWindow(), "message", r, !1), e.postMessage(o, "*");
        }
    },
    Mt = { error: -1, useractioncomplete: 1, cmpuishown: 2, tcloaded: 3 },
    Dt = ({ consentData: e, isAbleToMeasure: t }) => {
      const n = {},
        i = [];
      return (
        e?.purpose?.legitimateInterests?.[7] && i.push(7),
        e?.purpose?.legitimateInterests?.[10] && i.push(10),
        (n.cpli = i),
        (n.cgc = e?.vendor?.consents?.[278] ? 1 : 0),
        (n.cvli = e?.vendor?.legitimateInterests?.[278] ? 1 : 0),
        e?.eventStatus && (n.ccmp = Mt[e?.eventStatus]),
        (n.cdop = e?.gdprApplies ? 1 : 0),
        (n.cttd = t ? 1 : 0),
        n
      );
    },
    xt = ({ apiEntrance: e, listenerIDs: t, messageHandlers: n }) => {
      t.forEach((t) => {
        _t({
          apiEntrance: e,
          command: "removeEventListener",
          tcfv: 2,
          action: () => {},
          id: t,
        });
      }),
        n.forEach((e) => {
          Jn.removeEvent(window, "message", e);
        });
    },
    Pt = ({ consentData: e, listenerIDs: t, messageHandlers: n }) => {
      e?.listenerId && t.push(e.listenerId),
        e?.messageHandler && n.push(e.messageHandler);
    },
    Nt = ({ consentData: e }) =>
      !(!e?.gdprApplies || "useractioncomplete" !== e?.eventStatus),
    Vt = ({ apiFunctionName: e, apiFrameLocatorName: t }) => {
      try {
        let n,
          i,
          r = Fi.getWindow();
        const o = Fi.getTop();
        try {
          n = o?.[e];
        } catch (e) {
          for (; !i; ) {
            try {
              if (r.frames[t]) {
                i = r.frames[t]?.parent;
              }
            } catch (e) {}
            if (r === o) break;
            r = r.parent;
          }
        }
        return n || i;
      } catch (e) {}
    },
    Rt = ["A", "DIV", "IFRAME", "INS"],
    kt = function () {
      "use strict";
      let t;
      const n = ["STYLE", "SCRIPT", "HEAD", "META"],
        i = ti.concat(Rt);
      let r = 0;
      const o =
        (oe.measurementConfig.useFIF && zn.friendlyIframe) ||
        zn.isSpecifiedAd();
      let s = 0,
        a = [];
      const c = function (t) {
          let n,
            i = t,
            o = t;
          const s = zn.friendly
            ? Fi.getTop().document.body
            : e.contextNode.ownerDocument.body;
          function a() {
            const e =
              "[data-integralas-id-" + (oe.adTag && oe.adTag.asid) + "]";
            return oi.crossQuerySelector(e);
          }
          for (; r < 3; ) {
            if (s && i === s) {
              (o = i), (r = 3);
              break;
            }
            oi.isWindow(i) && ((n = a()), (i = Xe(n) ? n : i)),
              (i = (Xe(i) && i.parentNode) || i),
              (o = i),
              r++;
          }
          return o;
        },
        d = function (e) {
          const t = (function (e) {
            const t = [],
              r = e && e.getElementsByTagName && e.getElementsByTagName("*"),
              o = r && r.length;
            let s, a;
            if (r)
              for (let e = 0; e < o; e++)
                (s = r[e]),
                  (a = s && s.nodeName && s.nodeName.toUpperCase()),
                  s.children &&
                    0 === s.children.length &&
                    -1 === i.indexOf(a) &&
                    -1 === n.indexOf(a) &&
                    -1 === t.indexOf(a) &&
                    t.push(a);
            return t;
          })(e);
          return i.concat(t);
        },
        u = function (t) {
          let n;
          const i = o ? c(t) : t;
          return (
            oi.isWindow(i)
              ? (n = (function (t) {
                  let n;
                  try {
                    n = t.document;
                  } catch (t) {
                    n = e.contextNode.ownerDocument;
                  }
                  return n;
                })(i))
              : "IFRAME" === oi.getNodeName(i)
              ? (a.push(t), (n = t.contentWindow.document))
              : (n = i),
            n
          );
        },
        l = function (n) {
          const i = oi.isNodeXDomainIframe(n) || oi.isNodeCreative(n),
            r = !n;
          if (((t = r ? e.contextNode.parentNode : n), i || r))
            !(function () {
              const e = a.length;
              e > 0 && (s < e ? (s = e) : ((s = 0), (a = [])));
            })(),
              at.getAggregator().trigger("evaluateCreativeFinderResult", n);
          else {
            const e = u(n),
              t = d(e);
            new Ft(t, a).searchDescendants(e);
          }
        };
      return (
        at.getAggregator().on("creativeFinderBatchCompleted", l),
        {
          find: l,
          getClosestContainerName: function () {
            return oi.getNodeName(t);
          },
        }
      );
    },
    Ft = function (t, n) {
      "use strict";
      const i = t,
        r = function (e) {
          let t = 0,
            i = null,
            r = -1;
          function o(e) {
            if (
              (function (e) {
                const t = oi.getNodeName(e),
                  n = oi.isNodeCreative(e) || "IFRAME" === t;
                return t && n;
              })(e) &&
              !oi.isEmptyFriendlyFrame(e)
            ) {
              const t = oi.getNodeArea(e);
              t > r && -1 === n.indexOf(e) && ((i = e), (r = t));
            }
          }
          e.length && at.getAggregator().request("useYieldSearch")
            ? (function n() {
                do {
                  o(e[t]), (t += 1);
                } while (t % 500 != 0 && t < e.length);
                t < e.length
                  ? Fi.execAtEndOfThread(n, 0)
                  : at
                      .getAggregator()
                      .trigger("creativeFinderBatchCompleted", i);
              })()
            : (function () {
                for (; t < e.length; t++) o(e[t]);
                at.getAggregator().trigger("creativeFinderBatchCompleted", i);
              })();
        };
      return {
        searchDescendants: function (t) {
          const n = t || e.contextNode.parentNode,
            o = oi.collectCandidateElements(n, i);
          r(o);
        },
      };
    },
    jt = function () {
      "use strict";
      let e,
        t = !1,
        n = !1,
        i = !1,
        r = !1;
      const o = { status: "0", details: "na" },
        s = { status: "1", details: "env" },
        a = "rend",
        c = "renddet",
        d = at.getAggregator().request("omidAdSessionContext"),
        u = function () {
          let e = !1;
          return zn.isOmid() && d && d.useOMID13Logic && (e = !0), e;
        },
        l = function () {
          (t = !0), (i = !0);
        },
        m = function (n) {
          const i = e.build(),
            s = n.status || o.status,
            d = i || o.details;
          if ("1" === s) {
            at.getAggregator().trigger("perfCheckpoint", {
              type: "render",
              timestamp: Fi.now(),
              code: "tdr",
            });
            try {
              Me() &&
                !r &&
                ((r = !0),
                (u = zn.getTagTime()),
                Oe(() => {
                  Ce("sert", u);
                }));
            } catch (e) {}
          }
          var u;
          t && "1" === s
            ? (at.getAggregator().trigger("addThrottledOutputItem", a, s),
              at.getAggregator().trigger("addThrottledOutputItem", c, d))
            : (at.getAggregator().trigger("addOutputItem", { output: s }, a),
              at.getAggregator().trigger("addOutputItem", { output: d }, c));
        },
        g = function () {
          const t = d && !!d.isVideo,
            i = !u() || (d && !!d.videoStartArrived),
            r = !u() || (d && !!d.geometryArrived),
            o = !d.omidEarlyExit || d.omidImpressionArrived,
            a = !(d.omidEarlyExit && u()) || d.omidLoadedArrived;
          return (
            !(n || !r || !o || !a || (t && !i)) &&
            (at
              .getAggregator()
              .trigger("addOutputItem", { output: zn.getTagTime() }, "oren"),
            at.getAggregator().trigger("eligiblerender"),
            e.save("env"),
            e.save("or"),
            at.getAggregator().trigger("adRendered"),
            m(s),
            (n = !0),
            !0)
          );
        };
      return {
        start: function () {
          let t = !1;
          at
            .getAggregator()
            .trigger("perfCheckpoint", {
              type: "render",
              timestamp: Fi.now(),
              code: "initial",
            }),
            at.getAggregator().on("adRendered", function () {
              t = !0;
            }),
            at.getAggregator().provide("adRenderStatus", function () {
              return t;
            }),
            at.getAggregator().provide("useYieldSearch", function () {
              return i;
            }),
            (e = new Lt()),
            new qt(),
            at.getAggregator().on("impressionsent", l),
            u() || d.omidEarlyExit
              ? g() ||
                (e.save("env"),
                e.save("ou"),
                m(o),
                at.getAggregator().on("omidrendgeoupdate", function () {
                  g();
                }),
                at.getAggregator().on("omidrendvideostart", function () {
                  g();
                }),
                d.omidEarlyExit &&
                  (at.getAggregator().on("omidimpressionarrived", function () {
                    g();
                  }),
                  at.getAggregator().on("omidloadedarrived", function () {
                    g();
                  })))
              : zn.isOmid() || zn.isVideo()
              ? (at.getAggregator().trigger("eligiblerender"),
                e.save(s.details),
                at.getAggregator().trigger("adRendered"),
                m(s))
              : (m(o), Ut(m, o, e));
        },
      };
    },
    Ut = function (e, t, n) {
      at.getAggregator().on("primaryadfound", function (i) {
        try {
          const e = oe.mraidLifecycleTracker?.getSnapshot();
          "eligible" === e?.eligibility &&
            e.mraidExists &&
            ((r = zn.getTagTime()),
            Oe(() => {
              Ce("sepaf", 1), Ce("sepat", r);
            }));
        } catch (e) {}
        var r;
        let o;
        const s = kt();
        let a = !0;
        const c = "data-ias-rend-bi",
          d = function (e) {
            e && (e.status = "1"), at.getAggregator().trigger("adRendered");
          },
          u = function (e) {
            let t = !0;
            const i = Xe(e.naturalWidth) ? e.naturalHeight * e.naturalWidth : 0,
              r = getComputedStyle(e),
              o = 0 === e.src.length && zi.contains(r.content, "url"),
              s = e.getAttribute && e.getAttribute(c);
            return (
              i > 0 && !o && (t = !1),
              "false" === s && (n.save("cs"), (t = !1)),
              o &&
                !s &&
                (function (e, t) {
                  n.save("cs");
                  const i = /url(?:\(['"]?)(.*?)(?:['"]?\))/.exec(t.content),
                    r = i && i[1],
                    o = oi.createImage(),
                    s = e;
                  (o.onload = function () {
                    o.naturalHeight * o.naturalWidth > 0 &&
                      s.setAttribute &&
                      s.setAttribute(c, !1);
                  }),
                    (o.src = r),
                    s.setAttribute(c, !0);
                })(e, r),
              t
            );
          },
          l = function () {
            o ? Fi.clearInterval(o) : (a = !1);
          };
        at.getAggregator().on("evaluateCreativeFinderResult", function (i) {
          let r;
          oi.isNodeXDomainIframe(i)
            ? (l(),
              (t = (function (t) {
                const i = {},
                  r = "readystatechange",
                  o = "load",
                  s = Fi.getDoc(),
                  a = "complete" === s.readyState,
                  c = function (a) {
                    const u = a && a.type;
                    ((u === r && "complete" === a.target.readyState) ||
                      u === o) &&
                      (d(i),
                      n.saveNode(t),
                      "readystatechange" === u
                        ? n.save("dr")
                        : "load" === u && n.save("lf"),
                      e(i),
                      Jn.removeEvent(t, o, c),
                      Jn.removeEvent(s, r, c));
                  };
                return (
                  a
                    ? (d(i), n.saveNode(t), n.save("dr"))
                    : (Jn.addEvent(t, o, c, void 0),
                      Jn.addEvent(s, r, c, void 0)),
                  i
                );
              })(i)))
            : i
            ? ((function (e) {
                let t = !1;
                const i = oi.getRect(e);
                return (
                  e &&
                    "IMG" === oi.getNodeName(e) &&
                    u(e) &&
                    ((t = !0), n.save("bi")),
                  !t && i.width >= 20 && i.height >= 8
                );
              })(i) && (d(t), l()),
              n.saveNode(i))
            : ((r =
                s.getClosestContainerName() || n.getAdNodeName(i) || t.details),
              n.save(r)),
            e(t);
        });
        const m = function () {
            const e = i && i.getAdNode();
            try {
              s.find(e);
            } catch (e) {
              at.getAggregator().trigger("renderdiag", e);
            }
          },
          g = at.getAggregator().request("mobileApp");
        g &&
        g.isMobileAppEnvironment &&
        g.isMobileAppEnvironment() &&
        zn.isMraid()
          ? (function (e, n) {
              const i = Fi.getWindow().mraid,
                r = i && i.getState && i.getState(),
                o = "ready",
                s = t;
              let a,
                c = !1;
              const d = function (t, i) {
                  if (!c) {
                    (c = !0),
                      n.save(i),
                      at.getAggregator().trigger("adRendered");
                    try {
                      "eligible" ===
                        oe.mraidLifecycleTracker?.getSnapshot().eligibility &&
                        Pe(t);
                    } catch (e) {}
                    a && a(), e({ status: "1" });
                  }
                },
                u = function () {
                  Jn.removeEvent(i, o, u),
                    n.save("env"),
                    d("ready_event", "mr");
                };
              let l;
              n.save("env");
              let m = !1;
              try {
                const e = oe.mraidLifecycleTracker;
                e?.refresh("render"),
                  (l = e?.getSnapshot()),
                  (m = !!(
                    e &&
                    "eligible" === l?.eligibility &&
                    l?.mraidExists &&
                    (l.defaultObserved ||
                      l.readyObserved ||
                      l.readyListenerAttached ||
                      l.stateChangeListenerAttached)
                  )),
                  m &&
                    e &&
                    (l.defaultObserved
                      ? d("cached_default", "md")
                      : l.readyObserved
                      ? (n.save("env"), d("cached_ready", "mr"))
                      : (a = e.subscribe({
                          onReady: () => {
                            n.save("env"), d("tracked_ready", "mr");
                          },
                          onStateChange: (e) => {
                            "default" === e && d("tracked_default", "md");
                          },
                        })));
              } catch (e) {}
              if (!c)
                if ("default" === r) d("current_default", "md");
                else if ("loading" === r) {
                  m || Jn.addEvent(i, o, u, void 0), n.save("ml");
                  try {
                    "eligible" ===
                      oe.mraidLifecycleTracker?.getSnapshot().eligibility &&
                      Pe("current_loading");
                  } catch (e) {}
                  e(s);
                } else {
                  m || Jn.addEvent(i, o, u, void 0), n.save("mu");
                  try {
                    "eligible" ===
                      oe.mraidLifecycleTracker?.getSnapshot().eligibility &&
                      Pe("current_unknown");
                  } catch (e) {}
                  e(s);
                }
            })(e, n)
          : (m(), a && (o = Fi.setInterval(m, 500))),
          at.getAggregator().trigger("eligiblerender");
      });
    },
    Lt = function () {
      "use strict";
      let e = [],
        t = [];
      const n = function (e) {
          let t;
          if (oi.isWindow(e)) t = "WINDOW";
          else if (oi.isNodeXDomainIframe(e)) t = "XIFRAME";
          else
            try {
              t = oi.getNodeName(e);
            } catch (e) {
              i("nen");
            }
          return t;
        },
        i = function (t) {
          e.push(t);
        };
      return {
        build: function () {
          const n = [];
          return (
            t.forEach(function (e) {
              n.push(e);
            }),
            e.forEach(function (e) {
              n.push(e);
            }),
            (t = []),
            (e = []),
            n.join(".")
          );
        },
        getAdNodeName: n,
        save: i,
        saveNode: function (e) {
          try {
            const i = e && n(e),
              r = e && oi.getRect(e),
              o = e && oi.hasBackgroundImage(e),
              s = e && e.children && 0 === e.children.length,
              a = e && e.innerText && e.innerText.length > 0,
              c = s && a,
              d = r && r.width >= 20 && r.height >= 8 ? "qs" : "us";
            t.push(i), t.push(d), o && t.push("sn"), c && t.push("tn");
          } catch (e) {
            i("sne");
          }
        },
      };
    },
    qt = function () {
      "use strict";
      let t,
        n = !1,
        i = !1;
      const r = "1",
        o = "0",
        s = function () {
          (n = !0), c();
        },
        a = function (e) {
          (t = e), c();
        },
        c = function () {
          at
            .getAggregator()
            .trigger("addOutputItem", { output: !t && n ? r : o }, "rmeas"),
            t &&
              t.message &&
              !i &&
              (__IntegralASDiagnosticCall("renderloop", t, e),
              at.getAggregator().trigger("addThrottledProp", "env", "rle", 1),
              (i = !0));
        };
      at.getAggregator().on("eligiblerender", s),
        at.getAggregator().on("renderdiag", a),
        c();
    },
    Wt = function () {
      "use strict";
      return {
        applies: function (e, t, n) {
          const i = at.getAggregator().request("mobileApp");
          return (
            (e.browserIs("c") ||
              e.isAndroidWebViewBrowser() ||
              e.browserIs("w") ||
              e.browserIs("e")) &&
            !i.isMobileAppEnvironment() &&
            e.hasIntersectionObserver()
          );
        },
      };
    },
    Bt = function () {
      "use strict";
      let e,
        t,
        n = !1;
      const i = at.getAggregator().request("mPage"),
        r = function () {
          !n &&
            t &&
            e &&
            !i.isHidden() &&
            ((n = !0), at.getAggregator().trigger("sendDt", "l"));
        };
      at.getAggregator().on("primaryadfound", function (t) {
        (e = t.getDims().area() >= 242500), r();
      }),
        at.getAggregator().on("impressionsent", function () {
          (t = !0), r();
        }),
        i.onHiddenChange(r);
    },
    Gt = function () {
      "use strict";
      const e = [],
        t = {},
        n = {
          percentInView: "piv",
          sl: "vs",
          reason: "r",
          width: "w",
          height: "h",
          omidObstructions: "oobs",
        },
        i = { omidObstructions: ["sl", "percentInView", "reason"] };
      at.getAggregator().on("newScreenEvent", function (i) {
        const o = Ze(i).selectProperties(Ze(n).keys()),
          s = Ze(o).asStrings();
        let a = Ze(s).compareTo(t);
        (a = r(a)),
          a &&
            JSON.stringify(a) !== JSON.stringify({}) &&
            ((a.t = zn.getTagTime()), e.push(a)),
          Ze(t).mixin(s);
      });
      const r = function (e) {
        return (
          Ze(i).each(function (t, n) {
            let i = !1;
            Ze(n).each(function (t, n) {
              e[n] && (i = !0);
            }),
              !1 === i && delete e[t];
          }),
          e
        );
      };
      return {
        toString: function () {
          return Ze(e).toION(n);
        },
      };
    };
  const Ht = function () {
      "use strict";
      const e = new yn(),
        t = new Yt();
      return Ze(e).mixin(t);
    },
    Yt = function () {
      "use strict";
      const e = {},
        t = {},
        n = function (e, n) {
          (t[e] = t[e] || []), t[e].push(n);
        },
        i = function (t, n) {
          const i = e[t];
          i && i.run.apply({}, n);
        },
        r = function (e, n, i) {
          let r = t[e];
          if (r && 0 !== r)
            return (
              i && (r = r.slice(0, 1)),
              Ze(r).each(function (e, t) {
                n.apply({}, t);
              }),
              !0
            );
        },
        o = function (t, n, i) {
          (e[t] = e[t] || new Xt()), e[t].push(n, i);
        };
      return {
        on: function (e, t) {
          let n = {};
          t ? (n[e] = t) : (n = e), Ze(n).each(o), Ze(n).each(r);
        },
        once: function (e, t) {
          r(e, t, !0) || o(e, t, 1);
        },
        trigger: function (e) {
          const t = Ze(arguments).toArray();
          t.shift(), i(e, t);
        },
        persistentTrigger: function (e) {
          const t = Ze(arguments).toArray();
          t.shift(), n(e, t), i(e, t);
        },
      };
    },
    zt = function () {
      "use strict";
      const e = (t, n, i) => {
          const r = oi.isWindow(t) ? t.frames : oi.getChildWindowsOf(t);
          if ((i && i(t, n), r && r.length)) {
            const t = n.length;
            for (let o = 0; o < r.length; o++) {
              const s = r[o];
              s && oi.isWindow(s) && ((n[t] = o), e(s, n, i));
            }
            n.pop();
          }
        },
        t = (t, n) => {
          try {
            e(n || top, [0], t);
          } catch (e) {}
        };
      return {
        traverse: t,
        getFrames: (e, n) => {
          const i = [];
          return (
            t((e) => {
              oi.isWindow(e) &&
                ((e, t) => {
                  let n = !0;
                  for (let i = 0; i < e.length; i++)
                    if (e[i] === t) {
                      n = !1;
                      break;
                    }
                  return n;
                })(i, e) &&
                i.push(e);
            }, n),
            Ze(i).filter(e)
          );
        },
      };
    },
    Xt = function () {
      "use strict";
      const e = [];
      return {
        push: function (t, n) {
          let i = 0;
          n = n || Number.MAX_VALUE;
          e[e.length] = function () {
            i < n && (i++, t.apply({}, arguments));
          };
        },
        run: function () {
          const t = arguments;
          e.forEach(function (e) {
            e.apply({}, t);
          });
        },
      };
    },
    Jt = function (e) {
      "use strict";
      const t = {};
      return {
        doEligibleJobs: function (n) {
          (e || []).forEach(function (e) {
            const i = e && e.getTime();
            Xe(i) && n >= i && !t[i] && (e.getTask().call(), (t[i] = !0));
          });
        },
      };
    },
    Kt = function () {
      "use strict";
      let e;
      const n = Qt();
      return {
        listen: (i, r, o) => {
          (e = (e) => {
            ((e, t, i, r) => {
              let o, s;
              if (JSON && JSON.parse)
                try {
                  o = JSON.parse(e.data);
                  const a = e.source;
                  if (((s = nt), t(o))) {
                    if (r) {
                      const e = r(a, o);
                      e &&
                        (s = () => {
                          n.send(() => e, a);
                        });
                    }
                    i(e, o, s);
                  }
                } catch (e) {
                  o && at.getAggregator().trigger("error", "m");
                }
            })(e, i, r, o);
          }),
            Jn.addEvent(t, "message", e);
        },
        stop: () => {
          e && Jn.removeEvent(t, "message", e), (e = null);
        },
      };
    },
    Qt = function () {
      "use strict";
      return {
        send: (e, t) => {
          if (!JSON || !JSON.stringify) return;
          const n = ((e) => (Ze(e).isObj() ? [e] : zt().getFrames(e)))(t);
          Ze(n).each((t, n) => {
            const i = rt(e, n) || {};
            i.sentTime = Fi.now();
            const r = ((e) =>
              Ze(e).mapToObj((e, t) => {
                let n;
                return Je(t) || ((n = {}), (n[e] = t)), n;
              }))(i);
            n.postMessage(JSON.stringify(r), "*");
          });
        },
      };
    },
    Zt = function (e) {
      "use strict";
      let t = 0;
      const n = {},
        i = function (e, n, i) {
          if (void 0 === e.output)
            throw new Error("item with id " + n + ' must have "output" method');
          (this.item = e),
            (this.id = n || ++t),
            (this.props = i || {}),
            (this.output = function () {
              let t = rt(e.output);
              return this.props.asION && (t = Ze(t).toION()), t;
            });
        },
        r = (e) => {
          const t = [];
          for (const i in n)
            if (n.hasOwnProperty(i)) {
              const r = e(i, n[i]);
              r && t.push(r);
            }
          return t;
        },
        o = (e, t, r) => {
          r = "string" != typeof (r = r || t) ? r : {};
          const o = Ze(e.output).isObj() && !r.asION,
            s = (e, t, r) => {
              const o = new i(e, t, r);
              n[o.id] = o;
            };
          o
            ? Ze(e.output).each((e, t) => {
                s({ output: t }, e, r);
              })
            : s(e, t, r);
        };
      return (
        e.on("addOutputItem", (e, t, n) => {
          o(e, t, n);
        }),
        {
          addItem: o,
          filterOutput: (e, t) =>
            r((n, i) => {
              const r = i.props;
              let o;
              e(r) &&
                ((o = i.output()),
                r.encode &&
                  ((n = encodeURIComponent(n)), (o = encodeURIComponent(o))),
                Je(t) ? t(n, o) : (t[n] = o));
            }),
          iterate: r,
          cleanup: () => {
            r((e, t) => {
              t.props.flagForRemoval && delete n[e];
            });
          },
          getItem: (e) => n[e],
        }
      );
    },
    en = /[,:={}[\]'"]/,
    tn = /^\{[\s\S]*\}$|^\[[\s\S]*\]$/,
    nn = (e) => en.test(e),
    rn = /[^\x20-\x7E]/,
    on = (e) => rn.test(e),
    sn = (e) => "'" + e.split("'").join("") + "'",
    an = ({ value: e }) => {
      if ("string" == typeof (t = e) && (nn(t) || on(t)) && !tn.test(t))
        return sn(e);
      var t;
      if (Array.isArray(e)) return e.map((e) => an({ value: e }));
      if (null !== e && "object" == typeof e) {
        const t = {};
        return (
          Object.keys(e).forEach((n) => {
            const i = e[n];
            t[n] = -1 !== n.indexOf("NULL") ? i : an({ value: i });
          }),
          t
        );
      }
      return e;
    },
    cn = /^,+|,+$/g,
    dn = /^id:[^,]*(?:,|$)/,
    un = /^id:/,
    ln = (e) => e.replace(/&/g, "%26").replace(/#/g, "%23"),
    mn = (e) => ln(((e) => nn(e) || on(e))(e) ? sn(e) : e),
    gn = (e) => {
      let t = e;
      for (let e = 0; e < 10; e += 1) {
        const e = f(t);
        if (e === t) break;
        t = e;
      }
      return t;
    },
    pn = ({ impressionUrl: e }) => {
      const t = Ta({ impressionUrl: e });
      if (t) return gn(t).replace(cn, "").replace(dn, "");
    },
    fn = ({ impressionUrl: e, recordedPieces: t }) => {
      const n = pn({ impressionUrl: e });
      if (void 0 === n || !Array.isArray(t)) return;
      const i = t.map((e) => gn(e)),
        r = i[0],
        o = void 0 !== r && un.test(r) ? i.slice(1) : i;
      return o.join(",") === n ? o : void 0;
    },
    hn = ({ impressionUrl: e, recordedPieces: t }) => {
      const n = pn({ impressionUrl: e });
      if (void 0 === n) return;
      const i = fn({ impressionUrl: e, recordedPieces: t });
      return i
        ? i
            .map((e) =>
              ((e) => {
                const t = e.indexOf(":");
                if (-1 === t) return e;
                const n = e.slice(0, t),
                  i = e.slice(t + 1);
                return n + ":" + mn(i);
              })(e)
            )
            .join(",")
        : ln(n);
    },
    yn = function () {
      "use strict";
      const e = {},
        t = (t, n) => {
          e[t] = n;
        };
      return {
        request: function (t) {
          let n;
          const i = e[t],
            r = Ze(arguments).toArray();
          return r.shift(), void 0 === i || (n = Je(i) ? i.apply({}, r) : i), n;
        },
        provide: (e, n) => (n ? t(e, n) : Ze(e).each(t), n),
      };
    },
    vn = function () {
      "use strict";
      return {
        createInstance: function (e, t, n, i) {
          return zn.isDomless() ? new bn() : new Sn(e, t, n, i);
        },
      };
    },
    Sn = function (e, t, n, i) {
      "use strict";
      let r;
      const o = function (e, t) {
        return {
          viewState: "na",
          posViewState: "na",
          embedded: zn.embedded,
          winDimensions: e,
          adDimensions: t,
        };
      };
      return {
        collect: function () {
          const t = e.find(),
            s = t.getOutOfViewReasons(),
            a = n.isHidden(),
            c = i.isDeviceTypeGroupMobile() && r ? r : ei(oi.calcWinDims()),
            d = t.getDims();
          return (
            (r = c),
            t.hasAd() && c.hasValidDims() && d.hasValidDims()
              ? (!0 === a && s.push("f"),
                {
                  winDimensions: c,
                  adDimensions: d,
                  containerDimensions: t.getContainerDims(),
                  method: t.getDetectionMethod(),
                  viewState: s.length ? "outOfView" : t.getViewState(),
                  viewStateIgnoringRender: t.getViewStateIgnoringRender(),
                  percentInView: t.getPercentInView(),
                  percentInViewIgnoringRender:
                    t.getPercentInViewIgnoringRender(),
                  reason: s.join("."),
                  obstructed: Qe(t.isObstructed()),
                  isHidden: Qe(t.isHidden()),
                  tabHidden: Qe(a),
                  posViewState: t.getViewState(),
                  adCompCount: t.getComponentCount(),
                  sliceStatus: t.getSliceStatus(),
                })
              : o(c, d)
          );
        },
      };
    },
    bn = function () {
      "use strict";
      return {
        collect: function () {
          return {};
        },
      };
    },
    In = function (e) {
      "use strict";
      const t = e || ((e) => e);
      let n = [],
        i = Fi.now();
      const r = () => {
        const e = Fi.now();
        n.length > 0 && ((n[n.length - 1].duration += e - i), (i = e));
      };
      return {
        clear: () => {
          r(), (n = []);
        },
        fastForward: r,
        get: () => n,
        hasAlwaysBeen: (e) => 1 === n.length && n[0].state === e,
        addState: (e) => {
          const i = t(e);
          r(),
            (0 !== n.length && i === n[n.length - 1].state) ||
              n.push({ state: i, duration: 0 });
        },
      };
    },
    wn = function (e, t) {
      "use strict";
      const n = e || 1;
      let i,
        r = 0,
        o = 0,
        s = 0;
      return {
        start: () => {
          r % n == 0 && (i = Fi.now());
        },
        stop: () => {
          const e = i || t;
          r % n == 0 && ((s += Fi.now() - e), o++), r++;
        },
        getTime: () => s,
        getCount: () => o,
      };
    },
    An = function () {
      "use strict";
      let e,
        t = 0,
        n = 0;
      const i = new Yt(),
        r = () => {
          (e = !1), (t = 0);
        },
        o = () => {
          e &&
            (t++, i.trigger(String(t)), n > t ? Fi.execAtEndOfThread(o) : r());
        };
      return {
        onTick: (e, t) => {
          const r = t ? { [e]: t } : e;
          Object.keys(r).forEach((e) => {
            const t = parseInt(e);
            n = t > n ? t : n;
          }),
            i.on(r);
        },
        start: () => {
          e || ((e = !0), Fi.execAtEndOfThread(o));
        },
        kill: r,
        isActive: () => e,
      };
    },
    $n = function (e, t) {
      "use strict";
      let n,
        i = t;
      const r = (t) => {
          n || (t && e(), (n = Fi.setInterval(e, i)));
        },
        o = (t) => {
          n && (t && e(), Fi.clearInterval(n), (n = null));
        };
      return {
        start: r,
        stop: o,
        updateFrequency: (e, t) => {
          (i = e), n && (o(), r(t));
        },
      };
    },
    Tn = function (e) {
      "use strict";
      let t,
        n,
        i = 0,
        r = zn.getTagTime(),
        o = 0,
        s = !1;
      return {
        getTotalTime: () => o,
        stop: () => {
          (i = 0), (r = zn.getTagTime()), (s = !1);
        },
        mark: () => {
          (t = s ? zn.getTagTime() - r : 0),
            (i += t),
            i >= e && ((n = i - t < e), (o += n ? i : t)),
            (r = zn.getTagTime()),
            (s = !0);
        },
      };
    },
    En = function (t, n) {
      "use strict";
      const i = oe.baseUrls;
      let r = t || i.fwEventBaseUrl || i.cmEventBaseUrl;
      (r && 0 === r.indexOf("http")) ||
        (r =
          0 === r.indexOf("//")
            ? e.protocol + ":" + r
            : e.protocol + "://" + r);
      const o =
          /((http|https):\/\/(([^\/\.]*)\.([^\/]*)))(?:\/(.[^?]*)\??(.+)?)*/.exec(
            r
          ) || [],
        s = o[1] ? o[1] : "",
        a = o[2] ? o[2] : "",
        c = o[3] ? o[3] : "";
      let d = o[4] ? o[4] : "",
        u = o[5] ? o[5] : "",
        l = t && o[6] ? o[6] : "",
        m = o[7] && n ? o[7] : "";
      const g = {},
        p = function (e) {
          return "string" == typeof e && (d = e), d;
        },
        f = function (e) {
          return "string" == typeof e && (u = e), u;
        },
        h = function (t, n) {
          const i = t + "=" + Ze(n).toION();
          return st(i, e.encodeInvalidUrlChars);
        },
        y = function () {
          const e = Ze(g).isEmpty() ? "" : Ze(g).stringify(h, "&");
          return "?" + m + (m && e ? "&" + e : e);
        };
      m = m ? m.replace(/&$/, "") : "";
      return {
        appendToParamValue: function (e, t) {
          let i, r, o, s;
          const a = g[e];
          a
            ? (g[e] = a + t)
            : n &&
              m.length &&
              ((i = m.split(e)),
              (s = i.length > 1),
              s &&
                ((r = i[1].split("&")[0]),
                (o = [i[0], r].join(e)),
                (m = m.replace(o, o + t))));
        },
        fullDom: s,
        hostname: c,
        sub: p,
        master: f,
        setParam: function (e, t) {
          (g[e] = g[e] || {}),
            "string" == typeof t || "number" == typeof t
              ? (g[e] = t)
              : Ze(g[e]).mixin(t);
        },
        path: function (e) {
          l = e;
        },
        toString: function () {
          const e = p() ? p() + "." : "",
            t = l ? "/" + l : "",
            n = m || !Ze(g).isEmpty() ? y() : "";
          return a + "://" + e + f() + t + n;
        },
      };
    },
    Cn = function () {
      "use strict";
      const e = (e) => {
          const t = [];
          return (
            e.forEach((e) => {
              t.concat(e).join("").length <= 400 && t.push(e);
            }),
            t
          );
        },
        t = (e) =>
          oi
            .getAncestorNodes(e)
            .map(n)
            .filter((e) => void 0 !== e),
        n = (e) => {
          let t;
          return e && e.id && (t = e.id.replace(/[^\w-_.>/]/g, "")), t;
        };
      return (() => {
        let n, i;
        try {
          return (
            zn.friendly &&
              !zn.isMobileApp() &&
              ((n = at.getAggregator().request("adSlotIds")),
              n
                ? (i = n)
                : ((n = (() => {
                    const n = oi.getOurNodeInTop();
                    let i;
                    return n && (i = t(n)), (i = i && e(i)), i;
                  })()),
                  n &&
                    (at
                      .getAggregator()
                      .trigger("addOutputItem", { output: n }, "slid", {
                        type: "a",
                        asION: !0,
                      }),
                    at.getAggregator().provide("adSlotIds", n),
                    (i = n)))),
            i
          );
        } catch (e) {
          at.getAggregator().trigger("error", "A");
        }
      })();
    },
    On = {
      name: "AdRefreshDetection",
      dependencies: [],
      creator: function () {
        "use strict";
        const t = [15, 20, 30, 45, 60, 90],
          n = {
            start: function () {
              const e = this,
                t = oe.adTag && oe.adTag.asid,
                n = e.parseQuery(),
                i = e.getCacheId(n);
              t &&
                n.chanId &&
                (this.recordAdSlotImpression(t, n.chanId, i, (t, n) => {
                  t
                    ? at.getAggregator().trigger("error", "r")
                    : e.sendRefreshSession(n);
                }),
                e.registerInternalViewabilityListener(n.chanId, i));
            },
            getCacheId: (t) => {
              if (t && t.cacheId) return t.cacheId;
              if (e && e.contextNode) {
                try {
                  const n = e.contextNode.ownerDocument.querySelector(
                    "#ias-" + t.cb
                  );
                  if (n) return n.id;
                } catch (e) {}
                if (e.contextNode.nextSibling && e.contextNode.nextSibling.id)
                  return e.contextNode.nextSibling.id;
              }
              return null;
            },
            adRefreshIntervalIsValid: (e) => -1 !== t.indexOf(e),
            parseQuery: () => {
              const t = e.reqquery.split("&"),
                n = {};
              for (let e = 0; e < t.length; e += 1) {
                const [i, r] = t[e].split("=", 2);
                "" !== i && (n[i] = r);
              }
              return n;
            },
            sendRefreshSession: (e) => {
              const t =
                (0 === e.refreshCount ? "self" : e.refreshSessionId) +
                "." +
                e.refreshCount;
              at.getAggregator().trigger("addThrottledProp", "env", "ar", t);
            },
            recordAdSlotImpression: (e, t, n, i) => {
              const r = Fi.getTop(),
                o = {
                  requestTop: "recordAdSlotImpression",
                  asid: e,
                  adUnitId: t,
                  cacheId: n,
                };
              window.addEventListener(
                "message",
                (e) => {
                  if (/refreshSession/g.test(e.data))
                    try {
                      const t = e && e.data && JSON.parse(e.data);
                      i(null, t);
                    } catch (e) {
                      i(e);
                    }
                },
                !1
              ),
                r.postMessage(JSON.stringify(o), "*");
            },
            registerInternalViewabilityListener: function (e, t) {
              const n = this,
                i =
                  (oe.measurementConfig.adRefreshThreshold &&
                    parseInt(oe.measurementConfig.adRefreshThreshold)) ||
                  null,
                r = Fi.getTop();
              i &&
                this.adRefreshIntervalIsValid(i) &&
                at.getAggregator().on("sendDt", (o, s) => {
                  ("p" !== o && "c" !== o) ||
                    s !== i ||
                    (Fi.execAtEndOfThread(() => {
                      r.postMessage(
                        JSON.stringify({
                          requestTop: "refreshAd",
                          adUnitId: e,
                          cacheId: t,
                        }),
                        "*"
                      );
                    }),
                    n.sendAutoRefreshProp(i));
                });
            },
            sendAutoRefreshProp: (e) => {
              at.getAggregator().trigger("addThrottledProp", "env", "ir", e),
                at.getAggregator().trigger("adSessionComplete");
            },
          };
        return (
          zn.isRefreshable((e, t) => {
            let i;
            if (!e && t)
              try {
                (i = JSON.parse(t)),
                  i.isRefreshable && i.adServerName && n.start();
              } catch (e) {
                at.getAggregator().trigger("error", "r");
              }
          }),
          n
        );
      },
      settings: {
        tier: 8,
        applies: (e, t, n) => {
          "use strict";
          return n.isPossiblyRefreshable();
        },
      },
    },
    _n = function () {
      "use strict";
      let e, t;
      const n = function (e) {
          return (
            -1 !== e.indexOf("https") && (e += "*"),
            e.replace(/^https?:\/\//, "")
          );
        },
        i = function () {
          if (at.getAggregator().request("adNode"))
            return parseFloat(at.getAggregator().request("videoVersion"));
        };
      return {
        isApplicable: function (e, t) {
          return (
            !(function (e) {
              return e.isVideo() && !(e.isMraid() || e.isOmid()) && i() < 3.7;
            })(t) &&
            e.hasAncestorOrigins &&
            e.hasAncestorOrigins() &&
            t.xDomainIframe
          );
        },
        isStarted: function () {
          return !!t;
        },
        start: function () {
          try {
            (e = Fi.getWindow().location.ancestorOrigins), (t = !0);
          } catch (e) {
            at.getAggregator().trigger("error", "o");
          }
        },
        getMyFrameDepth: function () {
          return (e && e.length) || 0;
        },
        getTopDomain: function () {
          return e[e.length - 1];
        },
        sendOriginList: function () {
          const t =
            "ao:" +
            (e ? Array.prototype.map.call(e, n).reverse() : []).join(",");
          at
            .getAggregator()
            .trigger("addOutputItem", { output: t }, "tpiLookup", {
              type: "i",
              standalone: !0,
              encode: !0,
            }),
            at.getAggregator().trigger("sendDt", "i");
        },
      };
    },
    Mn = function (e, t, n, i, r) {
      "use strict";
      const o = function (e, t, n) {
          r.addItem({ output: e + "." + t + "." + n }, "ctpl");
        },
        s = function (r) {
          try {
            const n = "c";
            t.diagnostic(n);
            const s = r.length;
            let a = 0,
              c = 0;
            o(s, 0, 0),
              r.forEach(function (t) {
                e.send(
                  (function (e) {
                    return e.replace("%%CBS%%", i.getCacheBustId());
                  })(t),
                  function () {
                    o(s, a, ++c);
                  },
                  !0
                ),
                  o(s, ++a, c);
              });
          } catch (e) {
            n.add("S");
          }
        };
      return {
        init: function () {
          try {
            let t = new En().fullDom;
            "/" !== t.slice(-1) && (t += "/"),
              (t += "tpl?asId=" + (oe.adTag && oe.adTag.asid)),
              e.jsonp(t, s);
          } catch (e) {
            n.add("N");
          }
        },
      };
    },
    Dn = function (t, n, i, r) {
      "use strict";
      return {
        enabled: "true" === e.useBapiCallback,
        callback: function (n) {
          i.trigger("sendDiag");
          try {
            "true" === e.accountForSadImps && r.measure(n),
              e._onAPIResult && e._onAPIResult(n);
          } catch (e) {
            t.add("b"), i.trigger("sendDiag", "bapiClient");
          }
        },
      };
    },
    xn = function () {
      "use strict";
      return {
        createInstance: function (e, t, n, i) {
          return zn.isDomless() ? new Nn() : new Pn();
        },
      };
    },
    Pn = function () {
      "use strict";
      const e = function () {
          let e = "u";
          const t = Fi.getWindow();
          try {
            (Xe(t.opr) && t.opr.addons) ||
            (Xe(t.opera) && Xe(t.opera.buildNumber))
              ? (e = "o")
              : Xe(t.mozInnerScreenY)
              ? (e = "g")
              : Xe(t.chrome) && Xe(t.chrome.csi)
              ? (e = "c")
              : Xe(t.msWriteProfilerMark) && Xe(t.crypto)
              ? (e = "e")
              : Xe(t.WebKitPoint)
              ? (e = "w")
              : (Xe(t.attachEvent) || Xe(t.msCrypto)) && (e = "i");
          } catch (e) {}
          return e;
        },
        t = function () {
          let e = "";
          try {
            const t = Fi.getWindow();
            Xe(t.navigator) &&
              Xe(t.navigator.userAgent) &&
              (e = t.navigator.userAgent);
          } catch (e) {}
          return e;
        },
        n = function () {
          let e = "u";
          const n = t().toLowerCase();
          return (
            (e =
              n.indexOf(" opr/") > -1
                ? "o"
                : n.indexOf("firefox") > -1
                ? "g"
                : n.indexOf("edg") > -1
                ? "e"
                : n.indexOf("chrome") > -1
                ? "c"
                : n.indexOf("webkit") > -1
                ? "w"
                : n.indexOf("msie") > -1
                ? "i"
                : encodeURIComponent(n) || "_"),
            e
          );
        },
        i = function () {
          let e = "na";
          const t = Fi.getWindow();
          return (
            Xe(t.navigator) &&
              Xe(t.navigator.appName) &&
              (e = t.navigator.appName.toLowerCase()[0]),
            e
          );
        };
      return {
        browserIs: function (t) {
          return e() === t;
        },
        hasIntersectionObserver: function () {
          return "function" == typeof IntersectionObserver;
        },
        hasMutationObserver: function () {
          return "function" == typeof MutationObserver;
        },
        hasResizeObserver: function () {
          return "function" == typeof ResizeObserver;
        },
        hasAncestorOrigins: function () {
          const e = Fi.getWindow().location;
          return !(!e || !e.ancestorOrigins);
        },
        hasPostMessage: function () {
          const e = Fi.getWindow();
          return !(!e || !Je(e.postMessage));
        },
        getBrowserType: e,
        getBrowserTypeByUA: n,
        getUserAgent: t,
        params: function () {
          return { br: e(), bru: n(), an: i() };
        },
        isAndroidWebViewBrowser: function () {
          const e = t(),
            n = zi.contains(e, "Android");
          return (
            n &&
            ["Line", "SamsungBrowser", "FB_IAB", "Silk"].find(function (t) {
              return zi.contains(e, t);
            })
          );
        },
        getIOSVersion: function () {
          let e, n, i;
          const r = t();
          return (
            r &&
              ((e = r.match(/OS\s\d+/)),
              e &&
                e.length > 0 &&
                ((n = e.toString().match(/\d+/)),
                (i = n && n.length > 0 && parseInt(n.toString())))),
            i
          );
        },
      };
    },
    Nn = function () {
      "use strict";
      const e = function () {
        return !1;
      };
      return {
        getBrowserType: () => "u",
        getBrowserTypeByUA: () => "d",
        getIOSVersion: () => {},
        params: () => ({ br: "u", bru: "d", an: "na" }),
        browserIs: e,
        getUserAgent: e,
        hasPostMessage: e,
        hasAncestorOrigins: e,
        hasIntersectionObserver: e,
        hasMutationObserver: e,
        isAndroidWebViewBrowser: e,
      };
    },
    Vn = function () {
      "use strict";
      return {
        createInstance: (e, t) => (zn.isDomless() ? new Un(t) : new Fn(e, t)),
      };
    },
    Rn = function () {
      "use strict";
      let t;
      return {
        isApplicable: (n) => {
          t = at.getAggregator().request("omidAdSessionContext");
          const i = !(!t.app || !t.isDisplay || t.isWeb),
            r =
              n &&
              n.indexOf("/blocking/") > -1 &&
              !zn.integratedBlockingApplies(n),
            o = 1 != e.forceNoIframe;
          return i && r && o;
        },
        deployBlockingScriptIntoIframe: (n, i) => {
          t = at.getAggregator().request("omidAdSessionContext");
          const r = "iasbi" + (oe.adTag && oe.adTag.asid),
            o = ((t, n) => {
              const i = e.contextNode.parentNode,
                r = "about:blank",
                o = e.adWidth && e.adWidth > 0 ? e.adWidth : 0,
                s = e.adHeight && e.adHeight > 0 ? e.adHeight : 0,
                a = Fi.getDoc().getElementsByTagName("ins");
              let c,
                d = 0,
                u = 0;
              a &&
                a.length > 0 &&
                ((c = a[0]),
                (d = parseInt(c.style.width)),
                (u = parseInt(c.style.height)));
              const l = d || o || window.innerWidth,
                m = u || s || window.innerHeight;
              if (
                ("complete" === Fi.getDoc().readyState &&
                  (e.forceAppend = "true"),
                "true" === e.forceAppend)
              ) {
                const e = Fi.getDoc().createElement("IFRAME");
                (e.id = t), (e.src = r), i.appendChild(e);
              } else
                Fi.getDoc().write(
                  oe.trustedTypesPolicy.createHTML(
                    '<iframe id="' + t + '" src="' + r + '"></iframe>'
                  )
                );
              const g = Fi.getDoc().getElementById(t);
              return (
                g &&
                  ((g.style.width = l + "px"),
                  (g.style.height = m + "px"),
                  (g.scrolling = "no"),
                  (g.frameborder = 0),
                  (g.tabIndex = -1),
                  (g.style.position = "absolute"),
                  (g.style.padding = g.style.margin = g.style.border = "0px")),
                g
              );
            })(r);
          if (o) {
            const e = o.contentWindow.document;
            if (e) {
              e.open().write(
                ((e, t) => {
                  let n = "",
                    i = "";
                  const r = Fi.getDoc().getElementsByTagName("ins");
                  let o;
                  if (r && r.length > 0) {
                    (o = r[0]), (n = "<ins");
                    for (let e = 0; e < o.attributes.length; e++)
                      n +=
                        " " +
                        o.attributes[e].nodeName +
                        '="' +
                        o.attributes[e].nodeValue +
                        '"';
                    (n += ">"), (i = "</ins>");
                  }
                  return (
                    '<!doctype html><html><head></head><body style="margin:0px;border:0px;padding:0px;font-size:0px"><script>var IASid = "' +
                    e +
                    '", largestSize = 0;var IASmonitorDom = function () {  var DOM_MONITOR_PERIOD = 100;  var i, us, thisSize, thisWidth, thisHeight;  var elems = document.body.getElementsByTagName("*");  for (i = 0; i < elems.length; i++) {    if (elems[i].tagName && elems[i].tagName.toLowerCase() === "ins")      continue;    thisWidth = elems[i].offsetWidth;    thisHeight = elems[i].offsetHeight;    thisSize = thisWidth * thisHeight;    if (thisSize > largestSize) {      largestSize = thisSize;      us = parent.document.getElementById(IASid);      if (us) {        us.setAttribute("CreativeLoaded","true");        if (elems[i].style.left !== "") {          us.style.left = elems[i].style.left;          elems[i].style.left = "0px";        }        if (elems[i].style.top !== "") {          us.style.top = elems[i].style.top;          elems[i].style.top = "0px";        }      }    }  }  setTimeout(IASmonitorDom, DOM_MONITOR_PERIOD);};setTimeout(IASmonitorDom,50);</script>' +
                    n +
                    '<script src="' +
                    t +
                    '" referrerpolicy="no-referrer-when-downgrade"></script>' +
                    i +
                    "</body></html>"
                  );
                })(r, n)
              ),
                e.close();
              const t = e.querySelector && e.querySelector("script[src]");
              t && i && (t.onload = i);
            }
          }
        },
      };
    },
    kn = ({ trimmedString: e, iasImpId: t }) => {
      const n = e.match(/^function\s*\(([^)]*)\)\s*\{([\s\S]*)\}$/);
      if (n && void 0 !== n[1] && void 0 !== n[2]) {
        const e = n[1],
          i = n[2];
        new Function(e, i)({ iasImpId: t });
      }
    },
    Fn = function (i, r) {
      "use strict";
      const o = (t, i, r, o) => {
          let s;
          const a = Gn({ url: i });
          if (((i = a || i), "script" !== t)) {
            const e = n.createElement("DIV");
            (e.innerHTML = oe.trustedTypesPolicy.createHTML(r)),
              (s = e.childNodes[0]);
          } else
            (s = n.createElement("SCRIPT")),
              (s.src = oe.trustedTypesPolicy.createScriptURL(i)),
              o && (s.onload = o);
          e.contextNode.parentNode.appendChild(s);
        },
        s = function (i, r, s) {
          let a,
            c,
            d = "";
          const u = ((e) => {
              const t = Gn({ url: e });
              return ' src="' + (e = t || e) + '"';
            })(r),
            l = ' referrerpolicy="no-referrer-when-downgrade"';
          if (zn.doesPageAllowAppendedScripts() && s) {
            const e = oe.adTag && oe.adTag.asid;
            (c =
              "__IntegralASEventLoadHandler_" + (e ? e.replace(/-/g, "") : "")),
              (t[c] = s),
              (d = ` ${"onload"}="${(m = c)} && ${m}()"`);
          }
          var m;
          const g = {
            script: ['<script type="text/javascript"', d, u, l, "></script>"],
            iframe: [
              '<iframe width="100%" height="100%" frameborder="0" vspace="0" hspace="0" scrolling="no" marginheight="0" marginwidth="0"',
              d,
              u,
              l,
              "></iframe>",
            ],
            img: ["<img", d, u, l, "/>"],
          }[i].join("");
          zn.isOmid()
            ? ((a = new Rn()),
              a.isApplicable(r)
                ? a.deployBlockingScriptIntoIframe(r, s)
                : o(i, r, g, s))
            : ("loading" !== Fi.getDoc().readyState && (e.forceAppend = "true"),
              "true" === e.forceAppend
                ? o(i, r, g, s)
                : n.write(oe.trustedTypesPolicy.createHTML(g)));
        },
        a = (e, t, n) => {
          let i;
          const r = !n && Jn.getXHR2(),
            o = Gn({ url: e });
          (e = o || e),
            r
              ? (r.open("POST", e),
                (r.onreadystatechange = () => {
                  4 === r.readyState && 200 === r.status && t && t();
                }),
                r.send())
              : ((i = oi.createImage()),
                t && (i.onload = t),
                (i.src = oe.trustedTypesPolicy.createScriptURL(e.toString())));
        },
        c = (e, t) => {
          const n = Jn.getXHR2(),
            i = Gn({ url: e });
          (e = i || e),
            n &&
              (n.open("GET", e),
              (n.onreadystatechange = () => {
                if (4 === n.readyState && 200 === n.status && t)
                  try {
                    const e = JSON.parse(n.responseText);
                    t(e);
                  } catch (e) {
                    return;
                  }
              }),
              n.send());
        },
        d = (e, t, i, r) => {
          const o = oe.contextNode,
            s = oe.measurementConfig,
            a = "text/javascript";
          let c = Fi.getDoc();
          const d = c && "loading" === c.readyState,
            u = s && s.isStaticMode,
            l = n.createElement("script"),
            m = Gn({ url: e }),
            g = o && o.dataAttributes,
            p = "true" === (g && g.iasForceAppend);
          let f = o && o.element && o.element.parentNode;
          if (
            (s &&
              s.isStaticFrameInFrame &&
              o &&
              o.element &&
              o.element.contentDocument &&
              ((c = o.element.contentDocument), (f = c.body)),
            (i = i || f),
            (e = m || e),
            (l.type = a),
            (l.src = oe.trustedTypesPolicy.createScriptURL(e)),
            (l.referrerPolicy = "no-referrer-when-downgrade"),
            t && (l.onload = t),
            r && (l.setAttribute("defer", ""), l.setAttribute("async", "")),
            u && !oe.adTag.isScriptAsync && d && !p)
          ) {
            const t = "ias_dw_" + Math.random().toString(36).substring(2, 11),
              n =
                '<script id="' +
                t +
                '" type="' +
                a +
                '" src="' +
                e +
                '"></script>',
              r = oe.trustedTypesPolicy.createHTML(n);
            c.write(r);
            !c.getElementById(t) && Xe(i) && i.appendChild(l);
          } else Xe(i) && i.appendChild(l);
        },
        u = (e) => {
          const t = oe.adTag && oe.adTag.asid;
          if (Je(e)) e({ iasImpId: t });
          else if (e && "string" == typeof e) {
            const n = "function" == typeof e.trim ? e.trim() : e;
            if (0 === n.indexOf("function"))
              try {
                kn({ trimmedString: n, iasImpId: t });
              } catch (e) {}
            else {
              const t = new En(e, !0).toString();
              a(t, void 0, !0);
            }
          }
        },
        l = (e, t, n, i) => {
          d(r.wrap(e, t, n, i));
        };
      return (
        at
          .getAggregator()
          .on({
            addNode: s,
            send: a,
            exec: d,
            notify: u,
            getJSON: c,
            jsonp: l,
          }),
        { addNode: s, send: a, exec: d, notify: u, getJSON: c, jsonp: l }
      );
    },
    jn = (e) => encodeURI(e).replace(/%25([0-9a-f]{2})/gi, "%$1"),
    Un = function (e) {
      "use strict";
      const t = function (e, t, n) {
          (t = t || e), (e = arguments.length > 1 ? e : "script");
          const i = Gn({ url: t });
          (t = i || t), (t = jn(String(t)));
          const r = at.getAggregator().request("omidVerificationClient");
          r["script" === e ? "injectJavaScriptResource" : "sendUrl"](
            t,
            n || (() => {})
          );
        },
        n = (e, t) => {
          const n = Gn({ url: e });
          e = jn((e = n || e));
          at.getAggregator()
            .request("omidVerificationClient")
            .sendUrl(e.toString(), t || (() => {}));
        },
        i = (e, t) => {
          const n = at.getAggregator().request("omidVerificationClient"),
            i = Gn({ url: e });
          (e = jn((e = i || e))),
            n.injectJavaScriptResource(e, t || (() => {}));
        },
        r = (e) => {
          const t = oe.adTag && oe.adTag.asid;
          if (Je(e)) e({ iasImpId: t });
          else if (e && "string" == typeof e) {
            const i = "function" == typeof e.trim ? e.trim() : e;
            if (0 === i.indexOf("function"))
              try {
                kn({ trimmedString: i, iasImpId: t });
              } catch (e) {}
            else {
              const t = new En(e, !0).toString();
              n(t);
            }
          }
        },
        o = (t, n, r, o) => {
          i(e.wrap(t, n, r, o));
        };
      return (
        at
          .getAggregator()
          .on({ addNode: t, send: n, exec: i, notify: r, jsonp: o }),
        { addNode: t, send: n, exec: i, notify: r, jsonp: o }
      );
    };
  class Ln {
    static checkIfFirstPartyBlockingApplies({ impressionUrl: e }) {
      let t = !1;
      if (e && zn.isBlocking() && !zn.isDomless() && zn.isAMZN())
        try {
          const n = new URL(e);
          let i = n.searchParams.get("fpb");
          if (!i || "true" !== i) {
            const e = n.searchParams.get("redirectUrl");
            if (e) {
              const t = decodeURIComponent(e);
              i = new URL(t).searchParams.get("fpb");
            }
          }
          t = "true" === i;
        } catch (e) {}
      return t;
    }
    static modifyUrlForFirstPartyBlocking({ impressionUrl: e }) {
      let t;
      if (e) {
        const n = at.getAggregator().request("mobileApp"),
          i = zn.isAMZN(),
          r = n.isMobileAppEnvironment()
            ? Bn({ impressionUrl: e, isAMZN: i })
            : Wn({ impressionUrl: e, isAMZN: i });
        t = r ? `${r.toString()}&` : void 0;
      }
      return t;
    }
  }
  const qn = ({ isAMZN: e }) => ({
      hostName: e ? "vfw.amazon-adsystem.com" : "static.adsafeprotected.com",
      passPath: e ? "ias/s/111.js" : "111.js",
      failPath: e ? "ias/s/111a.js" : "111a.js",
      pathSegment: e ? "amazon" : "st",
    }),
    Wn = ({ impressionUrl: e, isAMZN: t }) => {
      let n;
      try {
        const i = (({ url: e }) => {
          const t = new URL(e),
            n = t.protocol.replace(":", ""),
            i = t.host,
            r = t.search,
            o = t.pathname.split("/"),
            s = o.indexOf("rfw");
          return {
            protocol: n,
            host: i,
            upToRfwPath: o.slice(0, s + 1).join("/"),
            advEntityId: o[s + 2] ?? "",
            pubEntityId: o[s + 3] ?? "",
            search: r,
          };
        })({ url: e });
        if (i) {
          const {
            protocol: r,
            host: o,
            upToRfwPath: s,
            advEntityId: a,
            pubEntityId: c,
            search: d,
          } = i;
          if (r && o && s && a && c) {
            const {
                hostName: i,
                passPath: u,
                failPath: l,
                pathSegment: m,
              } = qn({ isAMZN: t }),
              g = `${r}://${o}${s}/${m}/${a}/${c}/${u}${d}`,
              p = `${r}://${i}/${l}`,
              f = new URL(g),
              h = new URL(p),
              y = new URL(e).searchParams.get("fpbmn");
            y && "fpba" !== y && h.searchParams.set("fpbmn", y),
              f.searchParams.set("adsafe_pb", h.toString()),
              (n = f);
          }
        }
      } catch (e) {}
      return n;
    },
    Bn = ({ impressionUrl: e, isAMZN: t }) => {
      let n;
      try {
        n = new URL(e);
        const i = n.protocol,
          { hostName: r, passPath: o, failPath: s } = qn({ isAMZN: t }),
          a = `${i}//${r}/${o}`,
          c = `${i}//${r}/${s}`,
          d = new URL(c),
          u = new URL(a),
          l = n.searchParams.get("fpbmn");
        l &&
          "fpba" !== l &&
          (d.searchParams.set("fpbmn", l), u.searchParams.set("fpbmn", l)),
          n.searchParams.set("redirectUrl", u.toString()),
          n.searchParams.set("passback", d.toString());
      } catch (e) {}
      return n;
    },
    Gn = ({ url: t }) => {
      const n = e.iasProxyPartnerDomain;
      let i, r, o;
      if ("string" == typeof t) r = t;
      else
        try {
          r = t.toString();
        } catch (e) {}
      if (
        r &&
        ((o = r.includes("jsconfig.adsafeprotected.com/jsconfig")),
        zn.isMSFT() && !o && n && "string" == typeof n)
      ) {
        i = `https://${n}${encodeURIComponent(r)}`;
      }
      return i;
    },
    Hn = () => ({
      advEntityId: (oe.adTag && oe.adTag.advEntityId) || "",
      pubEntityId: (oe.adTag && oe.adTag.pubEntityId) || "",
    }),
    Yn = ({ search: e }) => {
      try {
        return h({ search: `?${e}` }).xsId || "";
      } catch (e) {
        return "";
      }
    },
    zn = (function (t) {
      let n = "undefined" == typeof window;
      const i = function () {
          return n;
        },
        r = void 0 !== t && "undefined" != typeof top && t !== top,
        o = (function () {
          let e = !1;
          if (i()) e = !0;
          else
            try {
              e = !!top.document;
            } catch (e) {}
          return e;
        })(),
        s = function () {
          return i() || Xe(Fi.getWindow().mraid);
        },
        a = function () {
          return !i() && Xe(Fi.getWindow().mraid);
        },
        c = function () {
          const e = at.getAggregator(),
            t = e.request("omidVerificationClient");
          let n = !1;
          const i = e.request("omidAdSessionContext");
          return t && i && (n = "video" === i.mediaType), n;
        },
        d = function () {
          let e = !1;
          if (!i()) {
            const t = "inmobi",
              n = "IASDocumentVideoBuffer",
              i = "addVideoEventListener",
              r = Fi.getWindow()[t],
              o = r && r[n],
              s = r && o && Je(o[i]);
            e = a() && !!s;
          }
          return e;
        },
        u = function () {
          return e && e.adsafeSrc && e.adsafeSrc.indexOf("xmtp=v") > -1;
        },
        l = function () {
          const t =
              (e.mode && e.mode.includes("jsvid")) ||
              (oe.adTag.tagType && oe.adTag.tagType.includes("jsvid")),
            n =
              ((e.mode && e.mode.includes("amtjs")) ||
                (oe.adTag.tagType && oe.adTag.tagType.includes("amtjs"))) &&
              e.videoId &&
              "" !== e.videoId,
            i =
              "jload" === oe.adTag.tagType &&
              ((e.videoId && "" !== e.videoId) ||
                (oe.measurementConfig &&
                  oe.measurementConfig.videoId &&
                  "" !== oe.measurementConfig.videoId));
          return Boolean(t || n || i || c() || d() || u());
        },
        m = function () {
          return !1 === e.fwMonitoring || "false" === e.fwMonitoring;
        },
        g = function () {
          return e.mobOrTab;
        },
        p = function (t) {
          if (!(e.customViewability instanceof Array)) return !1;
          return (
            Ze(e.customViewability).filter(function (e, n) {
              return zi.contains(n.id, t);
            }).length > 0
          );
        },
        f = function () {
          return e.use100v;
        },
        h = function () {
          return p("grpm") || f();
        },
        y = function () {
          return (
            Ke(e.iasProxyPartnerDomain) &&
            -1 !== e.iasProxyPartnerDomain.indexOf("bing")
          );
        };
      return {
        embedded: r,
        friendly: o,
        isFriendlyToParent: function (e) {
          let t, n, r;
          if (i()) t = !0;
          else {
            try {
              (r = En(e.document.referrer)),
                (n = r.hostname === e.location.hostname);
            } catch (e) {}
            t = n;
          }
          return t;
        },
        friendlyIframe: r && o,
        xDomainIframe: r && !o,
        getTagTime: function () {
          return Fi.now() - oe.measurementConfig.birthdate;
        },
        getPageTime: function () {
          let e = "na";
          return (
            !i() &&
              Xe(t.chrome) &&
              Xe(t.chrome.csi) &&
              Je(t.chrome.csi) &&
              (e = Fi.round(t.chrome.csi().pageT)),
            e
          );
        },
        isVideo: l,
        isMobileApp: s,
        isSpecifiedAd: function () {
          let t = !1;
          if (!i()) {
            const n =
              (Je(e.contextNode.getAttribute) &&
                e.contextNode.getAttribute("data-ias-container")) ||
              e._cl_adpath;
            t = n && Ke(n);
          }
          return t;
        },
        isCompoundAd: function () {
          let t = !1;
          const n = /\[(.*)\]/;
          if (!i()) {
            const i = e._cl_adpath,
              r = n.exec(i);
            t = null !== r && 0 !== r[1].length && r[1].split(",").length > 1;
          }
          return t;
        },
        isOmid: function () {
          const t = at.getAggregator().request("omidVerificationClient");
          return t && t.isSupported() && !e.videoId;
        },
        isOmidNative: function () {
          return new No().accepts();
        },
        isOmidSandboxedEnvironment: function () {
          return new No().accepts();
        },
        isOmidForWeb: function () {
          return new Zr().accepts();
        },
        isOmidVideo: c,
        isOmidAudio: function () {
          const e = at.getAggregator(),
            t = e.request("omidVerificationClient");
          let n = !1;
          const i = e.request("omidAdSessionContext");
          return t && i && (n = "audio" === i.creativeType), n;
        },
        isDomless: i,
        isBustedIframe: function () {
          let e = !1;
          return i() || (e = void 0 !== vs()), e;
        },
        isMraid: a,
        isSafeFrame: function () {
          let e = !1;
          return (
            i() ||
              (e =
                Ze(Fi.getWindow().$sf).isObj(!1) &&
                Ze(Fi.getWindow().$sf.ext).isObj(!1)),
            e
          );
        },
        isInMobiMraidVideo: d,
        isDeviceTypeGroupMobile: g,
        usesIASFullyInViewCustomMetric: function () {
          return p("fiv") || f() || !h();
        },
        usesGroupMCustomMetric: h,
        isCeltra: function () {
          let e = !1;
          return i() || (e = $s().isApplicable()), e;
        },
        usesGroupMCustomMetricMobilePassThru: function () {
          return h() && g();
        },
        usesZeroPivCustomMetric: function () {
          if (!(e.customViewability instanceof Array)) return !1;
          return (
            Ze(e.customViewability).filter(function (e, t) {
              return !!Ze(t.thresholds).findFirst(function (e, t) {
                return 0 === t.piv;
              });
            }).length > 0
          );
        },
        isRefreshable: function (e) {
          try {
            const t = Fi.getTop();
            window.addEventListener(
              "message",
              function (t) {
                /isRefreshable/g.test(t.data) && e(null, t && t.data);
              },
              !1
            ),
              t.postMessage(
                JSON.stringify({ requestTop: "isRefreshable" }),
                "*"
              );
          } catch (t) {
            e(t);
          }
        },
        isPossiblyRefreshable: function () {
          return !i() && !s() && !l() && r && "jload" === oe.adTag.tagType;
        },
        integratedBlockingApplies: function (t) {
          let n,
            i,
            r,
            o,
            s = !1;
          e.contextNode &&
            Je(e.contextNode.getAttribute) &&
            ((n = e.contextNode.getAttribute("data-ias-check-tag")),
            (i = e.contextNode.getAttribute("data-ias-check-done")),
            (r = e.contextNode.getAttribute("data-ias-callback".toString())),
            (o = r && Je(Fi.getWindow()[r])));
          const a = Xe(JSON) && Je(JSON.parse),
            c =
              e.integration &&
              (t.indexOf("skeleton.js") > 0 || t.indexOf("/internal/") > 0),
            d = !0 === e.fwMonitoring || "true" === e.fwMonitoring;
          return (
            a &&
              c &&
              ("true" === n && "true" !== i && o
                ? ((s = !0),
                  d &&
                    at
                      .getAggregator()
                      .trigger("addOutputItem", { output: "imgb" }, "smm", {
                        type: "impression",
                      }))
                : ((s = !1),
                  d ||
                    at
                      .getAggregator()
                      .trigger("addOutputItem", { output: "ibgm" }, "smm", {
                        type: "impression",
                      }))),
            s
          );
        },
        isBlocking: m,
        isBlockingSizmekTag: function () {
          return m() && zi.contains(e.scriptUrl, "bs.serving-sys.com");
        },
        isVastAudio: function () {
          return e && e.adsafeSrc && e.adsafeSrc.indexOf("xmtp=a") > -1;
        },
        isVastVideo: u,
        isAMZN: function () {
          return (
            Ke(e.iasProxyPartnerDomain) &&
            -1 !== e.iasProxyPartnerDomain.indexOf("amazon")
          );
        },
        isMSFT: y,
        isPageOnShadowDomWhitelist: function () {
          let t = !1;
          return (
            (y() ||
              (function () {
                const t =
                  oe.contextNode?.src || (e.contextNode && e.contextNode.src);
                return (
                  (Ke(e.scriptUrl) &&
                    e.scriptUrl.includes("ias_searchshadowdom=true")) ||
                  (Ke(t) && t.includes("ias_searchshadowdom=true"))
                );
              })() ||
              (Ke(e.iasProxyPartnerDomain) &&
                -1 !== e.iasProxyPartnerDomain.indexOf("integral.local"))) &&
              (t = !0),
            t
          );
        },
        doesPageAllowAppendedScripts: function () {
          let e = !0;
          return y() && (e = !1), e;
        },
      };
    })(t),
    Xn = (e) => {
      "use strict";
      return function (t) {
        const n = t.relatedTarget;
        this === n ||
          ((e, t) => {
            if (e === t) return !1;
            let n = t;
            for (; n && n !== e; ) n = n.parentNode;
            return n === e;
          })(this, n) ||
          e.call(this, t);
      };
    },
    Jn = {
      addEvent: (e, t, n, i) => {
        "use strict";
        Xe(e.addEventListener) &&
          ("mouseenter" === t
            ? e.addEventListener("mouseover", Xn(n), i)
            : "mouseleave" === t
            ? e.addEventListener("mouseout", Xn(n), i)
            : e.addEventListener(t, n, i));
      },
      removeEvent: (e, t, n) => {
        "use strict";
        Xe(e.removeEventListener) &&
          ("mouseenter" === t
            ? ((t = "mouseover"), (n = Xn))
            : "mouseleave" === t && ((t = "mouseout"), (n = Xn)),
          e.removeEventListener(t, n));
      },
      getStyle: (e, t, i) => {
        "use strict";
        let r,
          o = "";
        if (((i = i || ""), n.defaultView && n.defaultView.getComputedStyle)) {
          try {
            r = n.defaultView.getComputedStyle(e, i);
          } catch (e) {}
          o = r ? r.getPropertyValue(t) : o;
        } else
          e.currentStyle &&
            ((t = t.replace(/-(\w)/g, (e, t) => t.toUpperCase())),
            (o = e.currentStyle[t]));
        return o;
      },
      getXHR2: () => {
        "use strict";
        let e, n;
        return (
          Xe(t.XMLHttpRequest)
            ? ((n = new XMLHttpRequest()), "withCredentials" in n && (e = n))
            : Xe(window.XDomainRequest) && (e = new window.XDomainRequest()),
          e
        );
      },
      whenReady: (e, t) => {
        "use strict";
        if (zn.isDomless())
          return void Fi.setTimeout(() => {
            e();
          }, 50);
        const i = t || (zn.xDomainIframe ? n : Fi.getTop().document);
        ((e) => {
          const t = () => {
            e(!0);
          };
          Je(n.addEventListener)
            ? "complete" == i.readyState ||
              "loaded" == i.readyState ||
              "interactive" == i.readyState
              ? Fi.execAtEndOfThread(t)
              : Jn.addEvent(i, "DOMContentLoaded", t, !1)
            : ((e) => {
                const t = Fi.setInterval(() => {
                  i.body && (Fi.clearInterval(t), e());
                }, 50);
              })(e);
        })(e);
      },
      isSandboxed: (e) => {
        "use strict";
        let t;
        const n = Fi.getWindow();
        let i = !1;
        if ("sandbox" in Fi.getDoc().createElement("iframe")) {
          try {
            t = n.frameElement;
          } catch (e) {
            t = null;
          }
          i = t
            ? t.hasAttribute("sandbox")
            : (() => {
                let t = !1;
                const n = Fi.getDoc();
                if (e.browserIs("c"))
                  try {
                    n.domain = "hol@#3+~";
                  } catch (e) {
                    /Assignment is forbidden for sandboxed iframes/.test(
                      e.message
                    ) && (t = !0);
                  }
                return t;
              })();
        }
        return i;
      },
      styleElement: (e, t) => {
        "use strict";
        if (!e || !Ze(e.style).isObj() || !Ze(t).isObj()) return;
        let n = "";
        Ze(t).each((e, t) => {
          n += e + ": " + t + " !important;";
        }),
          (e.style.cssText = n);
      },
    },
    Kn = function (e) {
      "use strict";
      const t = Kn.callTypeCounter,
        n = ["a"],
        i = -1,
        r = -2,
        o = -3,
        s = -4,
        a = -5,
        c = -6,
        d = -7,
        u = -8,
        l = -10,
        m = -11,
        g = (() => {
          let g = {
            u: i,
            a: r,
            v: o,
            m: s,
            b: a,
            i: c,
            qf: d,
            l: u,
            s: l,
            as: m,
          }[e];
          const p = t && t[e];
          return (
            Xe(p) && 0 !== p && -1 !== n.indexOf(e) && (g = g + "." + p),
            (() => {
              const n = t[e];
              t[e] = Xe(n) ? n + 1 : 1;
            })(),
            g
          );
        })();
      return { callType: e, enumerator: g };
    };
  Kn.callTypeCounter = {};
  const Qn = ({ url: t }) => {
      const { advEntityId: n, pubEntityId: i } = Hn(),
        r = (() => {
          let t = "";
          return (
            e.staticFwjsMacros && (t = Yn({ search: e.staticFwjsMacros })),
            !t &&
              e.adsafeSrc &&
              (t = Yn({ search: e.adsafeSrc.split("?")[1] || "" })),
            t
          );
        })();
      t.setParam("advEntityId", n),
        t.setParam("pubEntityId", i),
        r && t.setParam("xsId", r);
    },
    Zn = function (e, t, n, i, r, o, s, a) {
      "use strict";
      let c,
        d,
        u = 0,
        l = 0,
        m = !1,
        g = !1,
        p = !1;
      let f = !1;
      const h = (e, t, o, a, c, h) => {
          let y = !1;
          o = o || !n.on("postDts");
          const v =
            "b" === e ||
            "a" === e ||
            "s" === e ||
            "xs" === e ||
            "x" === e ||
            "l" === e ||
            "as" === e ||
            (f && "e" === e);
          if (i.impressionIsIdentifiable() && (v || "n" !== s.getCurrentLoc()))
            try {
              const i = oe.baseUrls?.ctvEnrichmentUrl,
                s = i || oe.baseUrls?.dtBaseUrl,
                v = new En(s, !0),
                I = Fi.now(),
                w = f
                  ? (() => {
                      const e = [];
                      return (
                        r.iterate((t, n) => {
                          n?.props?.singleEventMarkerItem &&
                            e.push({ outputKey: t, markerItem: n });
                        }),
                        e
                      );
                    })()
                  : [];
              at.getAggregator().trigger("preSendDt", e),
                w.length &&
                  w.forEach(({ outputKey: e, markerItem: t }) => {
                    const n = r.getItem?.(e);
                    if (!n || n === t) return;
                    const i = t.item?.output,
                      o = n.item?.output;
                    i &&
                      "object" == typeof i &&
                      o &&
                      "object" == typeof o &&
                      at
                        .getAggregator()
                        .trigger(
                          "addOutputItem",
                          { output: { ...i, ...o } },
                          e,
                          { ...t.props }
                        );
                  }),
                s || (v.path("dt"), n.on("usedtdomain") && v.sub("dt")),
                S(v, e, t),
                c && c.field && v.setParam(c.field, c.value),
                a || b(v, e),
                i && Qn({ url: v }),
                g && !a
                  ? (d.push({
                      url: v,
                      dtCallTime: Fi.now() - I,
                      additionalCallback: h,
                      useImg: o,
                    }),
                    (y = !0))
                  : p ||
                    (at.getAggregator().trigger(
                      "send",
                      v,
                      () => {
                        (l += 1), (u = Fi.now() - I), Je(h) && h();
                      },
                      o
                    ),
                    (y = !0)),
                "u" === e && (m = !0),
                r.cleanup();
            } catch (t) {
              __IntegralASDiagnosticCall("dt-" + e, t),
                at.getAggregator().trigger("error", "h");
            }
          return y;
        },
        y = () => {
          if (m) return;
          h("u", -1, !0);
        },
        v = (e, t) => {
          const i = {
              bapi: "a",
              bapiClient: "b",
              jload: "c",
              jss: "d",
              jsi: "e",
            },
            r = i[e] || i[oe.adTag.tagType];
          (t = t || oe.adTag.tagType + "Diag"),
            n.on(t) && r && h("b", -5, !0, !0, { field: "bkp", value: r });
        },
        S = (e, t, n) => {
          const o = new Kn(t),
            s = Xe(n) ? n : o.enumerator;
          e.setParam("asId", oe.adTag && oe.adTag.asid);
          const a = {
            c: i.getCacheBustId(),
            pingTime: s,
            time: zn.getTagTime(),
            type: t,
          };
          g && (a.qd = 1);
          r.filterOutput((e) => {
            const n = e.minDt && (!e.type || e.type === t);
            return n && e.oneTime && (e.flagForRemoval = !0), n;
          }, a),
            e.setParam("tv", f ? an({ value: a }) : a);
        },
        b = (e, i) => {
          let c, d;
          const m = {};
          r.filterOutput(
            (e) => e.standalone && !e.minDt && e.type === i,
            (t, n) => {
              e.setParam(t, n.replace(/%3A/g, ":"));
            }
          ),
            s.fastForward(),
            ((e) =>
              "c" === e ||
              "u" === e ||
              "m" === e ||
              "pf" === e ||
              "p" === e ||
              "v" === e ||
              "a" === e)(i) &&
              ((m.clog = a),
              zn.isVideo() &&
                ((d = zn.isOmid()
                  ? "omidVideoEventsString"
                  : "videoEventsString"),
                (c = at.getAggregator().request(d)),
                c && !c.isEmpty() && (m.ve = c))),
            "u" === i && (m.ndt = l),
            oe.adTag &&
              -1 !== oe.adTag.tagType.indexOf("jsvid") &&
              (m.vv = at.getAggregator().request("videoVersion")),
            (m.NULL1 = n.output()),
            (m.NULL2 = s.stringify(10)),
            (m.em = zn.embedded),
            (m.fr = zn.friendly),
            (m.e = t.toString()),
            (m.tt = oe.adTag.tagType),
            (m.dtt = u),
            r.filterOutput((e) => {
              const t = !(e.standalone || e.minDt || (e.type && e.type !== i));
              return t && e.oneTime && (e.flagForRemoval = !0), t;
            }, m),
            e.setParam("tv", f ? an({ value: m }) : m),
            e.setParam("br", o.getBrowserType());
        };
      return (
        at.getAggregator().on({
          sendDt: (e, t, n) => {
            h(e, rt(t), void 0, void 0, void 0, n);
          },
          sendMinDt: (e, t, n) => {
            h(e, t, void 0, !0, n);
          },
          sendSanitizedDt: (e, t, n) => {
            f = !0;
            try {
              h(e, rt(t), void 0, void 0, void 0, n)
                ? Ae()
                : (r.iterate((e, t) => {
                    t?.props?.singleEventMarkerItem &&
                      (t.props.flagForRemoval = !0);
                  }),
                  r.cleanup());
            } finally {
              f = !1;
            }
          },
          sendDiag: v,
          updateDtCount: () => {
            l++;
          },
          unload: y,
          dtEnterQueuingMode: () => {
            (d = []), (g = !0);
          },
          dtExitQueuingMode: () => {
            d &&
              d.forEach((e) => {
                at.getAggregator().trigger(
                  "send",
                  e.url,
                  () => {
                    (l += 1), (u = e.dtCallTime);
                  },
                  e.useImg
                );
              }),
              (g = !1),
              (d = void 0);
          },
          dtReportDtsNotAllowed: ({
            tcfData: e,
            gdprApplies: t,
            canMeasure: n,
          }) => {
            (p = !0), (g = !1), (d = []);
            const i =
              "https://fw.adsafeprotected.com/tc-data/asId=" +
              (oe.adTag && oe.adTag.asid) +
              "&tcfData=" +
              e +
              "&gdprApplies=" +
              t +
              "&canMeasure=" +
              n;
            at.getAggregator().trigger("send", i, !1, !0);
          },
        }),
        {
          send: h,
          unload: y,
          diagnostic: v,
          setViewabilityMod: (e) => {
            c = e;
          },
        }
      );
    },
    ei = function (e) {
      "use strict";
      let n = {},
        i = !1;
      const r = (e) => 1 === e.nodeType,
        o = () => {
          const t = r(e) ? oi.nodeIsHidden(e) : 0 === e.width || 0 === e.height;
          return !i && t;
        },
        s = () => {
          const e = {};
          return (
            Ze(n).each((t, n) => {
              e[t] = Fi.round(n);
            }),
            e
          );
        },
        a = (e) => ot(e) || void 0 === e,
        c = () => Fi.round(n.width) * Fi.round(n.height);
      return (
        (() => {
          if (e !== t.parent)
            if (r(e)) {
              if (Xe(e.getBoundingClientRect)) {
                const t = oi.getRect(e);
                Ze(n).mixin({
                  x: t.x || t.scrX,
                  y: t.y || t.scrY,
                  scrX: t.scrX,
                  scrY: t.scrY,
                  width: t.width,
                  height: t.height,
                });
              }
            } else n = e;
        })(),
        {
          hasValidDims: () =>
            a(n.scrX) && a(n.scrY) && ot(n.width) && ot(n.height),
          toString: () => {
            const e = s();
            return [e.scrX, e.scrY, e.width, e.height].join(".");
          },
          getRounded: s,
          getRoundedGeometry: () => {
            const e = {};
            return (
              Ze(n).each((t, n) => {
                const i = t;
                e[i] =
                  "x" === i || "y" === i || "width" === i || "height" === i
                    ? Fi.round(n)
                    : n;
              }),
              e
            );
          },
          set: (e, t) => {
            n[e] = t;
          },
          isHidden: o,
          treatAsPlaceholder: () => {
            i = !0;
          },
          area: c,
          isMrcLarge: () => c() >= 242500,
          isOneByOne: () => o() && c() <= 1,
        }
      );
    },
    ti = ["CANVAS", "EMBED", "IMG", "OBJECT", "PICTURE", "SVG", "VIDEO"],
    ni = (e, t) => {
      "use strict";
      return e.getAttribute(t);
    },
    ii = (e, t) => {
      "use strict";
      let n;
      const i = t || Fi.getDoc();
      try {
        n = i.getElementsByTagName(e);
      } catch (e) {
        n = null;
      }
      return n;
    },
    ri = (e, t) => {
      const n = [];
      try {
        if (e.querySelectorAll) {
          const i = e.querySelectorAll(t);
          i.length && n.push(...Array.from(i));
        }
        const i = e.shadowRoot;
        if (i?.querySelectorAll) {
          const e = i.querySelectorAll(t);
          e.length && n.push(...Array.from(e));
        }
        if (e.children)
          for (const i of Array.from(e.children)) {
            const e = i.shadowRoot;
            if (e && e.querySelectorAll) {
              const i = e.querySelectorAll(t);
              i.length && n.push(...Array.from(i));
            }
          }
      } catch (e) {}
      return n;
    },
    oi = {
      findElementsWithSize: (e) => {
        "use strict";
        const t = [],
          n = (e) => {
            oi.getNodeArea(e) < 1
              ? Array.prototype.forEach.call(e.children, (e) => {
                  n(e);
                })
              : t.push(e);
          };
        return n(e), t;
      },
      nodeIsHidden: function (e) {
        "use strict";
        const t = this.getRect(e),
          n = 0 !== parseInt(Jn.getStyle(e, "width")) && 0 === t.width,
          i = 0 === t.width || 0 === t.height,
          r = "hidden" === Jn.getStyle(e, "visibility");
        return n || i || r;
      },
      calcWinDims: () => {
        "use strict";
        let e;
        try {
          const t = oi.browserWindowPosition(),
            n = oi.windowSize();
          e = {
            scrX: Fi.round(t.scrX),
            scrY: Fi.round(t.scrY),
            width: Fi.round(n.width),
            height: Fi.round(n.height),
          };
        } catch (t) {
          at.getAggregator().trigger("error", "w"), (e = {});
        }
        return e;
      },
      windowSize: () => {
        "use strict";
        const e = {};
        if (zn.isDomless()) return { width: 0, height: 0 };
        if (zn.friendly) {
          const t = top.document,
            n = t.documentElement,
            i = t.body;
          if (Xe(top.innerWidth))
            (e.width = top.innerWidth), (e.height = top.innerHeight);
          else if (Xe(n.clientWidth))
            (e.width = n.clientWidth), (e.height = n.clientHeight);
          else {
            if (!Xe(i.clientWidth))
              throw (
                ((e.width = e.height = 0),
                "Can't find window size; set width and height to 0")
              );
            (e.width = i.clientWidth), (e.height = i.clientHeight);
          }
        } else
          Xe(t.outerWidth) &&
            ((e.width = t.outerWidth), (e.height = t.outerHeight));
        return e;
      },
      browserWindowPosition: () => {
        "use strict";
        let e = t.screenX,
          n = t.screenY;
        return (
          at.getAggregator().request("browser").browserIs("g") &&
            -8 == e &&
            -8 == n &&
            ((e += 8), (n += 8)),
          { scrX: e, scrY: n }
        );
      },
      getNodeArea: (e) => {
        "use strict";
        let t = -1;
        if (e) {
          const n = oi.getRect(e);
          t = n.width * n.height;
        }
        return t;
      },
      getRect: (e) => {
        "use strict";
        const t = {},
          n = oi.browserWindowPosition(),
          i = e.getBoundingClientRect();
        return (
          void 0 === i.x && ((t.x = i.left), (t.y = i.top)),
          void 0 === i.width &&
            ((t.width = i.right - i.left), (t.height = i.bottom - i.top)),
          Ze(t).mixin(i, !0),
          (t.scrX = n.scrX + t.x),
          (t.scrY = n.scrY + t.y),
          t
        );
      },
      getPlaceholderSpan: () => {
        "use strict";
        const e = n.createElement("span");
        return (
          Ze(e.style).mixin({
            width: "0px",
            height: "0px",
            display: "block",
            overflow: "hidden",
            visibiility: "hidden",
          }),
          (e.innerHTML = oe.trustedTypesPolicy.createHTML(".")),
          e
        );
      },
      createImage: () => {
        "use strict";
        const e = zn.friendly && Fi.getTop().Image;
        return Je(e) ? new e() : new Image();
      },
      createHiddenIframe: (e) => {
        "use strict";
        const t = Fi.getDoc().createElement("iframe"),
          n = e
            ? { display: "none" }
            : {
                width: "0px",
                height: "0px",
                border: "0",
                position: "absolute",
                top: "-10000px",
                left: "-10000px",
              };
        return Jn.styleElement(t, n), (t.tabIndex = -1), t;
      },
      tagNameIs: (e, t) => {
        "use strict";
        return e.tagName.toUpperCase() === t.toUpperCase();
      },
      getClippedDimensions: (e, t) => {
        "use strict";
        let i = 1e4,
          r = 1e4;
        const o =
            "absolute" === Jn.getStyle(e, "position") ||
            !(!e.style || "absolute" !== e.style.position),
          s = !oi.tagNameIs(e, "OBJECT");
        if (null !== e.parentNode && !o && s && !oi.tagNameIs(t, "BODY")) {
          let o = e;
          do {
            o = o.parentNode;
            const e = !oi.tagNameIs(o, "OBJECT"),
              t = "inline" !== Jn.getStyle(o, "display");
            if (e && t) {
              const e = oi.getRect(o);
              (i = e.width < i ? e.width : i),
                (r = e.height < r ? e.height : r);
            }
          } while (o.parentNode !== n && o !== t);
        }
        return { width: Fi.round(i), height: Fi.round(r) };
      },
      hasBackgroundImage: (e) => {
        const t = Jn.getStyle(e, "background-image");
        return "" !== t && "none" !== t;
      },
      isEmptyFriendlyFrame: (e) => {
        try {
          let t = !1;
          if (e && e.document) {
            const n = e && "IFRAME" === e.nodeName && e.contentDocument;
            if (n) {
              const e = n.body;
              e && e.childElementCount < 1 && (t = !0);
            }
          }
          return t;
        } catch (e) {
          return !1;
        }
      },
      findChildWithLargestContent: (e, t) => {
        const n = at
            .getAggregator()
            .request("mobileApp")
            .isMobileAppEnvironment(),
          i = at.getAggregator().request("omidAdSessionContext"),
          r = i && i.hasOwnProperty("ignoreDivAsCandidate"),
          o = oi.hasBackgroundImage,
          s = (e) => {
            let t = !0;
            return (
              ("visible" === Jn.getStyle(e, "overflow") ||
                ("visible" === Jn.getStyle(e, "overflowX") &&
                  "visible" === Jn.getStyle(e, "overflowY"))) &&
                (t = !1),
              t
            );
          },
          a = ((t) => {
            let n = null,
              i = -1,
              s = null;
            if (t.length)
              for (let c = 0, d = t.length; c < d; c++) {
                const d = t[c],
                  u = oi.getNodeArea(d);
                let l = !(
                  (a = d).parentNode === e &&
                  "DIV" === a.nodeName &&
                  !o(a) &&
                  ("0" === Jn.getStyle(a, "opacity") ||
                    "hidden" === Jn.getStyle(a, "visibility") ||
                    (() => {
                      let e = !1;
                      const t = a.childNodes;
                      for (let n = 0; n < t.length; n++)
                        1 === t[n].nodeType && (e = !0);
                      return !e;
                    })())
                );
                l && r && "DIV" === d.nodeName && (l = !1);
                const m = oi.isEmptyFriendlyFrame(d),
                  g =
                    "A" === d.nodeName &&
                    0 === d.childElementCount &&
                    !o(d) &&
                    "IMG" === s;
                u > i && l && !m && !g && ((n = d), (i = u), (s = d.nodeName));
              }
            var a;
            return n && (n.hasValidSizeForMobileApp = i > 1), n;
          })(
            oi.collectCandidateElements(
              e,
              t || "iframe,img,a,object,embed,div".split(",")
            )
          );
        let c = null;
        return (
          a &&
            ((c = ((t) => {
              let i = t,
                o = t;
              for (
                ;
                o.parentNode !== e &&
                "inline" !== Jn.getStyle(o.parentNode, "display");

              )
                (!n || (s(o.parentNode) && oi.getNodeArea(o.parentNode) > 0)) &&
                  ((n && r && "DIV" === o.parentNode.nodeName) ||
                    (i = o.parentNode)),
                  (o = o.parentNode);
              return i;
            })(a)),
            (c.hasValidSizeForMobileApp = a.hasValidSizeForMobileApp)),
          c
        );
      },
      screenSize: () => {
        "use strict";
        if (zn.isDomless()) return { width: 0, height: 0 };
        let e = { width: -1, height: -1 };
        try {
          Xe(t.screen) &&
            (e = { width: t.screen.width, height: t.screen.height });
        } catch (e) {}
        return e;
      },
      calcMonDims: () => {
        "use strict";
        let e = Ze(oi.screenSize()).mixin({ scrX: 0, scrY: 0 });
        return (
          Xe(screen.availLeft) &&
            (e = {
              scrX: t.screen.availLeft,
              scrY: t.screen.availTop,
              width: t.screen.availWidth,
              height: t.screen.availHeight,
            }),
          e
        );
      },
      getOurNodeInTop: () => {
        "use strict";
        let t;
        if (zn.friendly)
          if (zn.embedded) {
            const e = (() => {
              let e;
              const t = Fi.getTop();
              let n = Fi.getWindow();
              for (; n != t; ) (e = n), (n = e.parent);
              return e;
            })();
            t = e && e.frameElement;
          } else t = e.contextNode;
        return t;
      },
      getAncestorNodes: (e) => {
        "use strict";
        const t = [],
          n = e.ownerDocument && e.ownerDocument.documentElement;
        let i = e;
        if (n)
          for (; (i.parentNode || i.host) !== n; )
            t.push(i), (i = i.parentNode || i.host);
        return t;
      },
      containsScriptTagWithSrc: (e) => {
        "use strict";
        return !!Array.prototype.find.call(ii("script") || [], (t) => {
          const n = t.src;
          return Je(e) ? e(n) : n === e;
        });
      },
      querySelector: (e, t) => {
        "use strict";
        let n;
        try {
          n = e.querySelector(t);
        } catch (e) {
          n = null;
        }
        return n;
      },
      nodeIsInWindow: (e, t) => {
        "use strict";
        if (!e.ownerDocument) return !1;
        const n = e.ownerDocument;
        return (n.defaultView || n.parentWindow) === t;
      },
      setAttributeOf: (e, t, n) => {
        "use strict";
        e && Je(e.setAttribute) && e.setAttribute(t, n);
      },
      removeAttributeOf: (e, t) => {
        "use strict";
        e && Je(e.removeAttribute) && e.removeAttribute(t);
      },
      crossQuerySelector: (t, n) => {
        "use strict";
        let i;
        const r = [e.contextNode.parentNode, Fi.getDoc()];
        if ((zn.friendly && r.push(Fi.getTop().document), n && zn.embedded))
          try {
            r.push(Fi.getWindow().frameElement.ownerDocument);
          } catch (e) {}
        return (
          r.forEach((e) => {
            try {
              const n = oi.querySelector(e, t);
              !i && n && (i = n);
            } catch (e) {}
          }),
          i
        );
      },
      getNodeName: (e) => {
        "use strict";
        return e && e.nodeName;
      },
      isWindow: (e) => {
        "use strict";
        let t = !1;
        try {
          t = !!e && "object" == typeof e && "setInterval" in e;
        } catch (e) {
          t = !0;
        }
        return !!t;
      },
      getChildWindowsOf: (e) => {
        "use strict";
        let t = [];
        const n = ii("iframe", e);
        return n && (t = Ze(n).map((e, t) => t.contentWindow)), t;
      },
      getFrameId: () => {
        "use strict";
        const e = Fi.getWindow().frameElement;
        return e && e.id;
      },
      isViewportVisible: (e, t) => {
        "use strict";
        const n = e.innerWidth,
          i = e.innerHeight,
          r = n * i > t.width * t.height,
          o = n > t.width && i > t.height;
        return r && o;
      },
      attributeMatches: (e, t, n) => {
        "use strict";
        const i = e && ni(e, t);
        return n.test(i);
      },
      isImageTag: (e) => {
        "use strict";
        return !!(e && e.src && oi.tagNameIs(e, "img"));
      },
      getDimensionFromStyle: (e) => {
        "use strict";
        let t;
        const n = Jn.getStyle(e, "width"),
          i = Jn.getStyle(e, "height");
        return n && i && (t = { width: it(n), height: it(i) }), t;
      },
      getDimensionFromAttributes: (e) => {
        "use strict";
        let t;
        const n = ni(e, "width"),
          i = ni(e, "height");
        return n && i && (t = { width: it(n), height: it(i) }), t;
      },
      traverseAndFindFirstMatchingNode: function e(t, n) {
        "use strict";
        let i;
        if (n(t)) i = t;
        else {
          const r = t.children;
          if (r) for (let t = 0; t < r.length && ((i = e(r[t], n)), !i); t++);
        }
        return i;
      },
      isClippable: (e, t) => {
        "use strict";
        let n = !0;
        const i = "fixed" === Jn.getStyle(e, "position"),
          r = !("hidden" === Jn.getStyle(t, "overflow")) && !i;
        return zn.isSpecifiedAd() && (i || r) && (n = !1), n;
      },
      isNodeCreative: (e) => {
        "use strict";
        const t = oi.getNodeName(e),
          n = e && e.children && 0 === e.children.length,
          i = e && e.innerText && e.innerText.length > 0,
          r = n && i,
          o = t && -1 !== ti.indexOf(t.toUpperCase());
        return !!t && !!(o || oi.hasBackgroundImage(e) || r);
      },
      getElementsWindow: (e) => {
        "use strict";
        const t = ((e) => {
          return e.ownerDocument || e;
        })(e);
        return t.defaultView || t.parentWindow || e;
      },
      elementIsEmbedded: (e) => {
        "use strict";
        return oi.getElementsWindow(e) !== Fi.getTop();
      },
      getParent: (e) => {
        "use strict";
        return e.parentNode || e.parent;
      },
      isNodeXDomainIframe: (e) => {
        "use strict";
        let t = !1;
        if (e && "IFRAME" === oi.getNodeName(e))
          try {
            t = !e.contentWindow.document;
          } catch (e) {
            t = !0;
          }
        return t;
      },
      collectCandidateElements: (e, t) => {
        const n = [],
          i = t,
          r = zn.isPageOnShadowDomWhitelist();
        for (let t = 0, o = i.length; t < o; t++) {
          const o = i[t].toLowerCase();
          let s = Array.from(
            (e.getElementsByTagName && e.getElementsByTagName(o)) || []
          );
          if (r) {
            const t = ri(e, o);
            t && t.length && (s = [...new Set([...s, ...t])]);
          }
          for (let e = 0, t = s.length; e < t; e++) n.push(s[e]);
        }
        return n;
      },
    },
    si = function () {
      "use strict";
      const e = {},
        t = (t) => {
          Xe(e[t]) ? (e[t] = e[t] + 1) : (e[t] = 1);
        };
      return (
        at.getAggregator().on("error", (e) => {
          const n =
            "object" != typeof e || null === e || e instanceof Array
              ? e
              : e.errorCode;
          t(n);
        }),
        {
          list: e,
          add: t,
          toString: () => {
            let t = "";
            for (const n in e) e.hasOwnProperty(n) && (t += n);
            return t;
          },
          hasErrors: () => {
            for (const t in e) return !0;
            return !1;
          },
        }
      );
    },
    ai = function () {
      "use strict";
      return {
        createInstance: function (e, t) {
          return zn.isDomless() ? new di() : new ci(e, t);
        },
      };
    },
    ci = function (t, n) {
      "use strict";
      return {
        parse: function (i) {
          try {
            const t = (function (t) {
                if (t && t instanceof Array) {
                  const n = oe.baseUrls,
                    i = n.cmEventBaseUrl,
                    r = n.fwEventBaseUrl,
                    o = t.map(function (e) {
                      return e.val;
                    });
                  return o.push(r, i, e.reqquery), o;
                }
                throw new Error(
                  "Unexpected data type in ExchangeParser.getUrlList"
                );
              })(i),
              r = t && t.length && t.join("|"),
              o = e.exchList;
            if (r) {
              const e = Object.keys(o).filter(function (e) {
                return r.indexOf(zi.rot(o[e])) >= 0;
              });
              e.length &&
                n.addItem({ output: e.join(".") }, "ex", {
                  type: "impression",
                });
            }
          } catch (e) {
            t.add("x");
          }
        },
      };
    },
    di = function () {
      "use strict";
      return { parse: function (e) {} };
    },
    ui = function () {
      "use strict";
      const t = {},
        n = function (n) {
          let i, r, o, s;
          return (
            void 0 === t[n] &&
              ((i = e.jsFeatures),
              (t[n] = !1),
              -1 !== i.indexOf(n) &&
                ((r = new RegExp(
                  n + "(?=$|,)|" + n + ":(?!,|$)(.?\\d*(?=,|$))"
                ).exec(i)),
                r &&
                  ((o = r[1]), (s = !o), (t[n] = s || o > 100 * Fi.random())))),
            t[n]
          );
        },
        i = {
          es: "everySecond",
          sc: "usesca",
          ha: "usehaps",
          fgad: "forceKeepGoogleAdNode",
        },
        r = {
          fif: "useFIF",
          gmnp: "groupm_native_publisher",
          for: "forceAppend",
          b11: "b11",
          cnod: "cnod",
        },
        o = function (t) {
          const n = e[t];
          return -1 !== ["integration"].indexOf(t)
            ? !!n
            : !0 === n || "true" === n || Je(n);
        };
      Ze(i).each(function (e, t) {
        n(t);
      });
      return {
        on: n,
        bootstrapOn: o,
        bootstrapperHas: function (t) {
          const n = Ke(t) ? [t] : t;
          return (
            Ze(n).map(function (t, n) {
              if (n && Xe(e[n])) return 1;
            }).length === n.length
          );
        },
        getEnabledScriptUrl: function (t) {
          const i = n("use" + t),
            r = e.sp_cdnScripts && e.sp_cdnScripts[t];
          return i && r;
        },
        setReportedBootstrapFeatures: function (e, t) {
          r[e] = t;
        },
        reportedBootstrapFeatures: r,
        output: function () {
          return Ze(
            (function () {
              const e = Ze(i).mapToObj(function (e, n) {
                  const i = {};
                  return (i[e] = +!!t[n]), i;
                }),
                n = Ze(r).mapToObj(function (e, t) {
                  const n = {};
                  return (n[e] = +!!o(t)), n;
                });
              return (n.gm = +!!zn.usesGroupMCustomMetric()), Ze(e).mixin(n);
            })()
          ).toParams();
        },
      };
    },
    li = function () {
      const e = function (e, t) {
        const n = e.getRounded(),
          i = t.getRounded(),
          r = Math.max(n.scrX, i.scrX),
          o = Math.max(n.scrY, i.scrY),
          s = Math.min(n.scrX + n.width, i.scrX + i.width) - r,
          a = Math.min(n.scrY + n.height, i.scrY + i.height) - o;
        return ei({
          scrX: r,
          scrY: o,
          width: s > 0 ? s : 0,
          height: a > 0 ? a : 0,
        });
      };
      return {
        calcInitialViewState: function (e, t) {
          let n = "na";
          const i = t
            ? { IN_VIEW: 65, OUT_OF_VIEW: 25, PARTIAL_VIEW: 30 }
            : { IN_VIEW: 75, OUT_OF_VIEW: 25, PARTIAL_VIEW: 50 };
          return (
            Xe(e) &&
              "na" !== e &&
              e > -1 &&
              (n =
                e >= i.IN_VIEW
                  ? "inView"
                  : e <= i.OUT_OF_VIEW
                  ? "outOfView"
                  : e >= i.PARTIAL_VIEW
                  ? "partialViewPlus"
                  : "partialViewMinus"),
            n
          );
        },
        calcPercentInView: function (t, n, i, r) {
          let o = 0,
            s = t;
          return (
            t.hasValidDims() &&
              !t.isHidden() &&
              ([n, i, r].forEach(function (t) {
                t.hasValidDims() && (s = e(s, t));
              }),
              (o = Fi.round((s.area() / t.area()) * 100))),
            o
          );
        },
      };
    },
    mi = 5381,
    gi = () => {
      const e = yi();
      return pi(e);
    },
    pi = (e) =>
      [
        e.slice(0, 8),
        e.slice(8, 12),
        e.slice(12, 16),
        e.slice(16, 20),
        e.slice(20),
      ].join("-");
  let fi;
  const hi = () => {
      if (fi) return fi;
      const e = t,
        n =
          e.navigator?.userAgent ||
          "" ||
          (({ scope: e }) => {
            const t = e.navigator?.userAgent || "",
              n = e.screen?.width || 0,
              i = e.screen?.height || 0,
              r = e.screen?.colorDepth || 0,
              o = e.devicePixelRatio || 0;
            return `${t}${n * mi}${i * mi}${r * mi}${o * mi}`;
          })({ scope: e });
      let i = mi;
      for (let e = 0; e < n.length; e++) i = (33 * i + n.charCodeAt(e)) >>> 0;
      const r = String(i % 1e4);
      return (fi = ("0000" + r).slice(-4)), fi;
    },
    yi = function () {
      let e = "";
      try {
        let n;
        const i = 16,
          r = 32,
          o = t,
          s = !!(o.Uint32Array && o.crypto && o.crypto.getRandomValues);
        for (; e.length < r; )
          s
            ? ((n = new Uint32Array(1)),
              o.crypto?.getRandomValues(n),
              void 0 !== n[0] && (e += n[0].toString(i)))
            : (e += ((Fi.random() * i) | 0).toString(i));
        (e = e.slice(0, r)), (e = e.slice(0, 12) + hi() + e.slice(16));
      } catch (e) {
        const t = at.getAggregator();
        t && t.trigger("error", "i");
      }
      return e;
    };
  class vi {
    constructor() {
      (this.impIsIdentifiable = !1),
        (this.getCacheBustId = () => {
          const e = new Date(),
            t = Date.parse(`Jan 1 ${e.getFullYear()}`),
            n = e.getTime() - t;
          return tt(n, 62);
        }),
        (this.impressionIsIdentifiable = (e) => (
          e && (this.impIsIdentifiable = !0), this.impIsIdentifiable
        )),
        (this.getAsid = () => (oe.adTag?.asid ? String(oe.adTag.asid) : "")),
        (this.getAnId = () => (oe.adTag && oe.adTag.anId) || ""),
        (this.getFwId = () => {
          const e = (oe.adTag && oe.adTag.advEntityId) || "",
            t = (oe.adTag && oe.adTag.pubEntityId) || "";
          return this.getAnId() || e + "-" + t;
        });
    }
    get unq() {
      return this.getAsid();
    }
  }
  const Si = function (e, t) {
      "use strict";
      return {
        init: function (n) {
          e.jsonp(
            n,
            function (e) {
              t.send("i", void 0, !1, !0, { field: "tpiLookup", value: e });
            },
            !1,
            "callback"
          );
        },
      };
    },
    bi = function (e, n, i, r, o) {
      "use strict";
      return {
        getTime: function () {
          return 1e3 * e.getTimeInViewInSeconds();
        },
        getTask: function () {
          return o
            ? function () {
                const t = at.getAggregator().request("adRenderStatus"),
                  i = r || n,
                  o = e.getTimeInViewInSeconds();
                t ||
                  at
                    .getAggregator()
                    .trigger("addThrottledProp", "env", "nr_" + i, o);
              }
            : function () {
                const o = e.getTimeInViewInSeconds(),
                  s = e.getTimeInViewForRts();
                if (
                  (Xe(r) &&
                    (at
                      .getAggregator()
                      .trigger("addOutputItem", { output: r }, "metricId", {
                        type: n,
                      }),
                    at
                      .getAggregator()
                      .trigger("addOutputItem", { output: "t" }, "cmr", {
                        type: n,
                      })),
                  zn.isMSFT() && o > 0)
                )
                  try {
                    t.postMessage(
                      { name: "pingTime", origin: "ias", value: o },
                      "*"
                    );
                  } catch (e) {}
                at.getAggregator().trigger("sendDt", n, o), i[s] && i[s]();
              };
        },
      };
    },
    Ii = function () {
      "use strict";
      return {
        createPingJobs: function (e, t, n, i, r) {
          return t.getTimeThresholds().map(function (t) {
            return new bi(t, e, n, i, r);
          });
        },
      };
    },
    wi = function () {
      let e;
      const t = [],
        n = function (e) {
          const t = e?.videoEvent || e,
            n = "type",
            i = "t",
            r = "timestamp";
          return {
            type: t["tp"] || t[n] || "",
            time: t[i] || (t[r] && t[r] - oe.measurementConfig.birthdate) || "",
          };
        },
        i = function () {
          e || (e = at.getAggregator().request("viewabilityDefinitions")),
            e &&
              0 == t.length &&
              e.forEach(function (e) {
                e.qivThreshold && t.push(e);
              });
        },
        r = function (e, t) {
          at
            .getAggregator()
            .trigger("addOutputItem", { output: e.metricId }, "metricId", {
              type: "c",
            }),
            at
              .getAggregator()
              .trigger("addOutputItem", { output: "q" }, "cmr", { type: "c" }),
            at.getAggregator().trigger("sendDt", "c", t),
            e.rtsCallbacks && Je(e.rtsCallbacks.qiv) && e.rtsCallbacks.qiv();
        };
      return {
        init: function () {
          i(),
            at.getAggregator().on("videoQuartileEvent", function (e) {
              i(),
                (function (e) {
                  const i = new n(e),
                    o = [
                      "_",
                      "firstQuartile",
                      "midpoint",
                      "thirdQuartile",
                      "complete",
                    ],
                    s = o.indexOf(
                      o.find(function (e) {
                        return (
                          -1 !== i.type.toLowerCase().indexOf(e.toLowerCase())
                        );
                      })
                    ),
                    a = at
                      .getAggregator()
                      .request("mScreenEvents")
                      .getCurrentEvent(),
                    c = Math.floor(i.time / 1e3);
                  t.forEach(function (e) {
                    let t = !1;
                    const n = e.qivThreshold.indexOf(s);
                    -1 !== n &&
                      e.isInView(a) &&
                      e.qivThreshold.length > 0 &&
                      (e.qivThreshold.splice(n, 1),
                      (t = 0 == e.qivThreshold.length),
                      t && r(e, c));
                  });
                })(e);
            });
        },
      };
    },
    Ai = function (e) {
      const t = e && (e.tp || e.type);
      return t ? t.toLowerCase() : "";
    },
    $i = function (e) {
      let t;
      return (
        e && "number" == typeof e.t
          ? (t = e.t)
          : e &&
            "number" == typeof e.timestamp &&
            (t = e.timestamp - oe.measurementConfig.birthdate),
        "number" != typeof t || Number.isNaN(t) ? zn.getTagTime() : t
      );
    },
    Ti = function (e, t) {
      return Ai(e).includes(t.toLowerCase());
    },
    Ei = function (e, t) {
      return Ai(e) === t.toLowerCase();
    },
    Ci = function (e, t) {
      return !!t && e.isInView(t);
    },
    Oi = function (e) {
      return !!e && !0 === e.iasCached;
    },
    _i = function (e) {
      let t;
      if ("number" == typeof e) t = e;
      else if ("string" == typeof e) {
        const n = Number.parseFloat(e);
        Number.isNaN(n) || (t = n);
      }
      return t;
    },
    Mi = function (e, t) {
      let n = t?.isSoundOn;
      const i = e?.data || {},
        r = _i(
          i.mediaPlayerVolume ?? i.videoPlayerVolume ?? e?.volume ?? e?.adVolume
        ),
        o = _i(i.deviceVolume);
      return (
        "number" == typeof r
          ? (n = r > 0 && (null == o || o > 0))
          : "number" == typeof o && (n = o > 0),
        n
      );
    },
    Di = function () {
      return !!at.getAggregator().request("ids")?.impressionIsIdentifiable?.();
    },
    xi = function (e, t) {
      return -1 !== (e.segments || []).indexOf(t);
    },
    Pi = function (e) {
      return (
        e?.indicatesCompletion?.() ||
        Ei(e, "adStopped") ||
        Ei(e, "stopAd") ||
        Ei(e, "stopped") ||
        Ei(e, "adSkipped") ||
        Ei(e, "skipped") ||
        Ei(e, "adError") ||
        Ei(e, "error") ||
        Ei(e, "adUserClose")
      );
    },
    Ni = function () {
      "use strict";
      const e = "seconds",
        t = "percentage",
        n = [],
        i = {};
      let r;
      const o = function () {
          const e = at.getAggregator().request("viewabilityDefinitions");
          (n.length = 0),
            e &&
              ((r = e),
              r.forEach(function (e) {
                e.videoPlaybackSegmentRequirements &&
                  e.videoPlaybackSegmentRequirements.length > 0 &&
                  n.push(e);
              }));
        },
        s = function (e) {
          const t = e.metricId;
          return (
            i[t] ||
              (i[t] = {
                hasStarted: !1,
                hasFired: !1,
                activeSegment: 0,
                requirementStates: {},
              }),
            i[t]
          );
        },
        a = function (e) {
          const t = s(e);
          (t.hasStarted = !0),
            (t.hasFired = !1),
            (t.activeSegment = 0),
            (t.requirementStates = {}),
            e.videoPlaybackSegmentRequirements.forEach(function (e, n) {
              (t.requirementStates[n] = {}),
                e.segments.forEach(function (e) {
                  t.requirementStates[n][e] = {
                    isSatisfied: !1,
                    accumulatedTimeInView: 0,
                    consecutiveTimeInView: 0,
                    maxConsecutiveTimeInView: 0,
                    lastMeasurementTime: 0,
                    segmentStartTime: 0,
                    segmentDuration: 0,
                    wasInView: !1,
                  };
                });
            });
        },
        c = function (e, t, n) {
          return s(e).requirementStates[t]?.[n];
        },
        d = function (n, i) {
          const r =
            n.requirementType === t
              ? i.segmentDuration * (n.requirementValue / 100)
              : 1e3 * n.requirementValue;
          if (n.requirementType === t) {
            const e = r - Math.min(250, 0.1 * r);
            i.isSatisfied =
              i.segmentDuration > 0 && i.accumulatedTimeInView >= e;
          } else
            n.requirementType === e &&
              (i.isSatisfied = i.maxConsecutiveTimeInView >= r - 250);
        },
        u = function (t, n, i) {
          const r = s(t);
          r.hasStarted &&
            !r.hasFired &&
            t.videoPlaybackSegmentRequirements.forEach(function (o, s) {
              if (xi(o, r.activeSegment)) {
                const a = c(t, s, r.activeSegment);
                !(function (e, t, n, i) {
                  const r = Ci(e, n);
                  if (t.wasInView) {
                    const e = i - t.lastMeasurementTime;
                    (t.accumulatedTimeInView += e),
                      (t.consecutiveTimeInView += e),
                      (t.maxConsecutiveTimeInView = Math.max(
                        t.maxConsecutiveTimeInView,
                        t.consecutiveTimeInView
                      ));
                  }
                  r || (t.consecutiveTimeInView = 0),
                    (t.wasInView = r),
                    (t.lastMeasurementTime = i);
                })(t, a, n, i),
                  o.requirementType === e && d(o, a);
              }
            });
        },
        l = function (e, t, n, i) {
          (s(e).activeSegment = t),
            e.videoPlaybackSegmentRequirements.forEach(function (r, o) {
              if (xi(r, t)) {
                const r = c(e, o, t);
                r &&
                  ((r.segmentStartTime = i),
                  (r.lastMeasurementTime = i),
                  (r.wasInView = Ci(e, n)));
              }
            });
        },
        m = function (e, t, n) {
          const i = s(e).activeSegment;
          u(e, t, n),
            e.videoPlaybackSegmentRequirements.forEach(function (t, r) {
              if (xi(t, i)) {
                const o = c(e, r, i);
                (o.segmentDuration = n - o.segmentStartTime), d(t, o);
              }
            });
        },
        g = function (e) {
          let t = !0;
          return (
            e.videoPlaybackSegmentRequirements.forEach(function (n, i) {
              (function (e, t, n) {
                let i = !1;
                return (
                  t.segments.forEach(function (t) {
                    c(e, n, t)?.isSatisfied && (i = !0);
                  }),
                  i
                );
              })(e, n, i) || (t = !1);
            }),
            t
          );
        },
        p = function (e, t) {
          const n = s(e);
          !n.hasFired &&
            g(e) &&
            ((n.hasFired = !0),
            (function (e, t) {
              at
                .getAggregator()
                .trigger("addOutputItem", { output: e.metricId }, "metricId", {
                  type: "c",
                }),
                at
                  .getAggregator()
                  .trigger("addOutputItem", { output: "q" }, "cmr", {
                    type: "c",
                  }),
                at.getAggregator().trigger("sendDt", "c", Math.floor(t / 1e3)),
                e.rtsCallbacks &&
                  Je(e.rtsCallbacks.qiv) &&
                  e.rtsCallbacks.qiv();
            })(e, t));
        },
        f = function (e) {
          const t = s(e);
          (t.hasStarted = !1), (t.activeSegment = 0);
        },
        h = function (e) {
          const t = e?.videoEvent || e,
            i =
              e?.screenEvent ||
              at.getAggregator().request("mScreenEvents").getCurrentEvent();
          if (Oi(t) && !e?.screenEvent) return;
          o();
          const r = (function (e, t) {
              return e ? { ...e, isVideoPlaying: !0, isSoundOn: Mi(t, e) } : e;
            })(i, t),
            s = $i(t);
          n.forEach(function (e) {
            a(e), l(e, 1, r, s);
          });
        },
        y = function (e) {
          o();
          const t = zn.getTagTime();
          n.forEach(function (n) {
            u(n, e, t), p(n, t);
          });
        },
        v = function (e) {
          const t = e?.videoEvent || e;
          if (Oi(t)) return;
          o();
          const i =
              e?.screenEvent ||
              at.getAggregator().request("mScreenEvents").getCurrentEvent(),
            r = $i(t),
            a = (function (e) {
              let t;
              return (
                Ti(e, "firstQuartile")
                  ? (t = 2)
                  : Ti(e, "midpoint")
                  ? (t = 3)
                  : Ti(e, "thirdQuartile") && (t = 4),
                t
              );
            })(t);
          n.forEach(function (e) {
            const n = s(e);
            n.hasStarted &&
              ((a && a <= n.activeSegment) ||
                (m(e, i, r),
                p(e, r),
                a ? l(e, a, i, r) : Ti(t, "complete") && f(e)));
          });
        },
        S = function (e) {
          const t = at
              .getAggregator()
              .request("omidAdSessionContext")?.cachedVideoSegmentEvents,
            i = t ? t.indexOf(e) : -1;
          if (!Di()) return;
          i > -1 && t.splice(i, 1);
          const r = (function (e) {
              return e && (e.videoEvent || e);
            })(e),
            c = (function (e) {
              return e?.screenEvent;
            })(e);
          if (Ei(r, "start")) {
            o();
            const e = $i(r);
            n.forEach(function (t) {
              a(t), l(t, 1, c, e);
            });
          } else if (
            (function (e) {
              return (
                Ei(e, "start") ||
                Ei(e, "firstQuartile") ||
                Ei(e, "midpoint") ||
                Ei(e, "thirdQuartile") ||
                Ei(e, "complete")
              );
            })(r)
          )
            v({ ...r, iasCached: !1, screenEvent: c });
          else if (Pi(r)) {
            o();
            const e = $i(r);
            n.forEach(function (t) {
              s(t).hasStarted && (m(t, c, e), p(t, e), f(t));
            });
          } else {
            const e = $i(r);
            n.forEach(function (t) {
              u(t, c, e), p(t, e);
            });
          }
        },
        b = function (e) {
          const t = e?.videoEvent || e,
            i =
              e?.screenEvent ||
              at.getAggregator().request("mScreenEvents").getCurrentEvent(),
            r = $i(t);
          o(),
            n.forEach(function (e) {
              const n = s(e);
              if (Pi(t) && n.hasStarted) return m(e, i, r), p(e, r), void f(e);
              u(e, i, r), p(e, r);
            });
        },
        I = function () {
          const e = at
            .getAggregator()
            .request("omidAdSessionContext")?.cachedVideoSegmentEvents;
          if (e && e.length > 0) {
            if (!Di()) return;
            e.slice().forEach(function (e) {
              S(e);
            });
          }
        };
      return {
        init: function () {
          o(),
            at.getAggregator().on("videoStartEvent", h),
            at.getAggregator().on("newScreenEvent", y),
            at.getAggregator().on("videoPlaybackStateEvent", b),
            at.getAggregator().on("videoQuartileEvent", v),
            at.getAggregator().on("cachedOmidVideoSegmentEvent", S),
            at.getAggregator().on("impressionsent", I),
            Di() && I();
        },
      };
    },
    Vi = function () {
      "use strict";
      const e = () => {
        const e = oe.adTag && oe.adTag.asid;
        return (
          "__IntegralAS_" +
          ((e && e.replace(/-/g, "")) || "") +
          "_" +
          Fi.round(1e4 * Math.random())
        );
      };
      return {
        wrap: (n, i, r, o) => {
          const s = e();
          let a, c, d;
          ((e, t) => new RegExp(t).test(e))(
            (n = "" + n),
            (o = o || "ias_callback")
          ) &&
            ((a = ((e, t) => new RegExp("(" + t + "=)(.[^&]*)").exec(e)[0])(
              n,
              o
            )),
            (c = a.split("=")[1]),
            (d = zi.stringToFn(c)),
            (n = ((e, t) => (
              -1 !== e.indexOf(t + "&") && (t += "&"), e.replace(t, "")
            ))(n, a)));
          const u = oe.measurementConfig.isStaticFrameInFrame
            ? oe.contextNode.element.contentWindow
            : t;
          return (
            (u[s] = (e) => {
              i(e), r && d && d(e), (u[s] = void 0);
            }),
            (n = ((e, t, n) => {
              const i = e.indexOf("?"),
                r = t + "=" + n;
              if (-1 === i) return e + "?" + r;
              {
                const t = i + 1;
                return e.slice(0, t) + r + "&" + e.slice(t);
              }
            })(n, o, s)),
            n
          );
        },
        wrapToGlobal: (n) => {
          const i = e();
          return (
            (t[i] = (e) => {
              n(e), (t[i] = void 0);
            }),
            i
          );
        },
      };
    },
    Ri = function (t, n, i) {
      "use strict";
      const r = (t, n) => {
        let i = t;
        if (n) {
          const r = "," + Ze(n).stringify((e, t) => e + ":" + t, ",");
          (i = En(t, !0)),
            i.appendToParamValue(
              "adsafe_jsinfo",
              st(r, e.encodeInvalidUrlChars)
            ),
            (i = i.toString());
        }
        return i;
      };
      let o = !1;
      try {
        const t =
          (void 0 !== e.videoId && e.videoId && "" !== e.videoId) ||
          (oe.measurementConfig &&
            oe.measurementConfig.videoId &&
            "" !== oe.measurementConfig.videoId);
        o = zn.isVideo() && !zn.isOmid() && t;
      } catch (e) {}
      const s = {
        jss: {
          isFW: !0,
          nodeType: zn.doesPageAllowAppendedScripts() ? "script" : "img",
        },
        rjss: {
          isFW: !0,
          onloadCallback: Aa,
          impressionMethod: function (e) {
            if (Me()) {
              const t = {
                  type: "e",
                  oneTime: !0,
                  minDt: !0,
                  singleEventMarkerItem: !0,
                },
                n = ((e) => {
                  const t = fn(e);
                  if (!t) return;
                  const n = {};
                  for (const e of t) {
                    const t = e.indexOf(":");
                    if (-1 === t) return;
                    n[e.slice(0, t)] = mn(e.slice(t + 1));
                  }
                  return Object.keys(n).length > 0 ? n : void 0;
                })({
                  impressionUrl: e,
                  recordedPieces: oe.singleEventImpressionJsInfo?.getPieces(),
                });
              if (n)
                Object.keys(n).forEach((e) => {
                  at.getAggregator().trigger(
                    "addOutputItem",
                    { output: n[e] },
                    e,
                    t
                  );
                });
              else {
                const n = hn({
                  impressionUrl: e,
                  recordedPieces: oe.singleEventImpressionJsInfo?.getPieces(),
                });
                n &&
                  at
                    .getAggregator()
                    .trigger(
                      "addOutputItem",
                      { output: n },
                      "NULL_SINGLE_EVENT_IMPRESSION_JSINFO",
                      t
                    );
              }
              let i = {};
              try {
                oe.mraidLifecycleTracker?.refresh("recovery"), (i = _e());
              } catch (e) {}
              try {
                const e = oe.mraidLifecycleTracker?.getSnapshot();
                e?.mraidEverObserved &&
                  at
                    .getAggregator()
                    .trigger(
                      "addOutputItem",
                      { output: e.mraidExists ? "0" : "1" },
                      "mi",
                      t
                    );
              } catch (e) {}
              at
                .getAggregator()
                .trigger("addOutputItem", { output: { seir: 1, ...i } }, "im", {
                  ...t,
                  asION: !0,
                }),
                at.getAggregator().trigger("sendSanitizedDt", "e", 0);
            } else if (
              zn.isAMZN() &&
              zn.isBlocking() &&
              oe.measurementConfig.staticMode
            )
              at
                .getAggregator()
                .trigger("addOutputItem", { output: !0 }, "ablk"),
                at.getAggregator().trigger(
                  "jsonp",
                  e + "&format=jsonp",
                  (e) => {
                    const { nodeType: t, creativeUrl: n } = e,
                      i =
                        "i" === oe.measurementConfig.tagDeliveryType
                          ? "iframe"
                          : "unknown" === t
                          ? "script"
                          : t;
                    at.getAggregator().trigger("addNode", i, n);
                  },
                  !1,
                  "cbName"
                );
            else {
              let t = "script";
              const n = oe.measurementConfig.impressionNodeType,
                i = "i" === oe.measurementConfig.tagDeliveryType,
                r =
                  !zn.doesPageAllowAppendedScripts() ||
                  ("string" == typeof n && "img" === n);
              i ? (t = "iframe") : r && (t = "img"),
                at.getAggregator().trigger("addNode", t, e, Aa);
            }
          },
        },
        amtjs: {
          isFW: !0,
          manualDefer: zn.isVideo(),
          impressionMethod: function (t) {
            zn.isVideo()
              ? at.getAggregator().on("adImpression", (n, i) => {
                  let o;
                  try {
                    (o = r(t, i)),
                      at.getAggregator().trigger("send", o, nt, !0);
                  } catch (t) {
                    __IntegralASDiagnosticCall("amtjsvidimp", t, e);
                  }
                })
              : at.getAggregator().trigger("addNode", "img", t);
          },
        },
        jsi: { isFW: !0, nodeType: "iframe" },
        rjsi: { isFW: !0, nodeType: "iframe" },
        jload: {
          manualDefer: o,
          impressionMethod: function (i) {
            o
              ? at.getAggregator().on("adImpression", (o, s) => {
                  let a;
                  try {
                    (a = r(i, s)),
                      t.enabled
                        ? at.getAggregator().trigger("jsonp", a, t.callback, !0)
                        : at
                            .getAggregator()
                            .trigger("send", a, nt, !n.on("postMon"));
                  } catch (t) {
                    __IntegralASDiagnosticCall("jloadvidimp", t, e);
                  }
                })
              : t.enabled
              ? at.getAggregator().trigger("jsonp", i, t.callback, !0)
              : at.getAggregator().trigger(
                  "send",
                  i,
                  () => {
                    Aa(), at.getAggregator().trigger("sendDiag");
                  },
                  !n.on("postMon")
                );
          },
        },
        bapi: {
          impressionMethod: function (e) {
            const n = t.enabled ? t.callback : nt,
              i = !!t.enabled;
            at.getAggregator().trigger("jsonp", e, n, i);
          },
        },
        jsapi: {
          isFW: !0,
          impressionMethod: function (e) {
            const n = t.enabled ? t.callback : nt,
              i = !!t.enabled;
            at.getAggregator().trigger("jsonp", e, n, i);
          },
        },
        jsvid: {
          manualDefer: !0,
          impressionMethod: function (i) {
            at.getAggregator().on("adImpression", (o, s) => {
              let a;
              try {
                (a = r(i, s)),
                  t.enabled
                    ? at.getAggregator().trigger("jsonp", a, t.callback, !0)
                    : at
                        .getAggregator()
                        .trigger("send", a, nt, !n.on("postMon"));
              } catch (t) {
                __IntegralASDiagnosticCall("jsvidimp", t, e);
              }
            });
          },
        },
        fwjsvid: {
          isFW: !0,
          manualDefer: !0,
          impressionMethod: function (t) {
            const n = "false" === e.fwMonitoring;
            n &&
              at.getAggregator().trigger(
                "jsonp",
                ((e) => {
                  const t = e.split("/");
                  return (
                    zn.isAMZN()
                      ? ((t[6] = "fw"), (t[7] = "db2"), (t[8] = "video"))
                      : ((t[3] = "db2"), (t[4] = "video")),
                    t.join("/")
                  );
                })(t),
                (e) => {
                  at.getAggregator().trigger("videoBlockResult", e);
                }
              ),
              at.getAggregator().on("adImpression", (i, o) => {
                let s;
                try {
                  n &&
                    (a = i) &&
                    "boolean" == typeof a.integral_didBlock &&
                    a.integral_timeToDecision >= 0 &&
                    (t = ((e) => {
                      const n =
                        "$1$2,abc:" +
                        (e.integral_didBlock ? 1 : 0) +
                        ",abct:" +
                        e.integral_timeToDecision;
                      return t.replace(/(adsafe_jsinfo=)([^&]*)/, n);
                    })(i)),
                    (s = r(t, o)),
                    at.getAggregator().trigger("send", s, nt, !0);
                } catch (t) {
                  __IntegralASDiagnosticCall("fwjsvidimp", t, e);
                }
                var a;
              });
          },
        },
        jspix: { nodeType: "img" },
      };
      return new (function () {
        const t = s[oe.adTag.tagType],
          n = !!t.isFW,
          r = ((t) => {
            let n;
            const i = oe.baseUrls;
            return (
              (n =
                at
                  .getAggregator()
                  .request("mobileApp")
                  .isMobileAppEnvironment() && i.mobileAppEventBaseUrl
                  ? i.mobileAppEventBaseUrl
                  : t
                  ? i.fwEventBaseUrl
                  : i.cmEventBaseUrl),
              t || (n += "?" + e.reqquery),
              n
            );
          })(n),
          o = r.indexOf("BEGIN__ADSAFE"),
          a = -1 !== o,
          c = a ? r.slice(o) : "";
        return {
          isFW: n,
          baseUrl: a
            ? r.slice(0, o)
            : ((e) => {
                const t = -1 === e.indexOf("?") ? "?" : "&";
                return e + t;
              })(r),
          macroUrl: c,
          sendImpression: (e) => {
            const n = (e) => {
              at
                .getAggregator()
                .trigger("addOutputItem", { output: zn.getTagTime() }, "siq"),
                t.nodeType
                  ? at
                      .getAggregator()
                      .trigger("addNode", t.nodeType, e, t.onloadCallback)
                  : t.impressionMethod(e);
            };
            i || t.manualDefer
              ? n(e)
              : t.manualDefer ||
                at.getAggregator().on("adImpression", () => {
                  n(e);
                });
          },
        };
      })();
    },
    ki = function () {
      "use strict";
      return zn.isDomless() && zn.isOmid()
        ? at.getAggregator().request("omidVerificationClient")
        : t;
    };
  var Fi = {
    execAtEndOfThread: function (e) {
      "use strict";
      Fi.setTimeout(e, 0);
    },
    now: function () {
      "use strict";
      return Date.now();
    },
    random: function () {
      "use strict";
      return Math.random();
    },
    round: function (e) {
      "use strict";
      return Math.round(e);
    },
    floor: function (e) {
      "use strict";
      return Math.floor(e);
    },
    min: function () {
      "use strict";
      return Math.min.apply(null, arguments);
    },
    max: function () {
      "use strict";
      return Math.max.apply(null, arguments);
    },
    getWindow: function () {
      "use strict";
      return t;
    },
    setInterval: function (e, t) {
      "use strict";
      return ki().setInterval(e, t);
    },
    setTimeout: function (e, t) {
      "use strict";
      return ki().setTimeout(e, t);
    },
    clearInterval: function (e) {
      "use strict";
      ki().clearInterval(e);
    },
    getTop: function () {
      "use strict";
      return zn.isDomless(), top;
    },
    getDoc: function () {
      "use strict";
      return zn.isDomless(), n;
    },
    getIntersectionObserver: function (e, t) {
      "use strict";
      return zn.isDomless(), new IntersectionObserver(e, t);
    },
    getMutationObserver: function (e) {
      "use strict";
      return zn.isDomless(), new MutationObserver(e);
    },
    getResizeObserver: function (e) {
      "use strict";
      return zn.isDomless(), new ResizeObserver(e);
    },
    getTopmostAccessibleWindow: function () {
      "use strict";
      let e = Fi.getWindow();
      const t = Fi.getTop();
      let n = 0;
      for (; n < 20 && (!t || e !== t); ) {
        try {
          const n = e.parent;
          if (!n || n === e) break;
          if ((n.document, (e = n), t && e === t)) break;
        } catch (e) {
          break;
        }
        n += 1;
      }
      return e;
    },
  };
  const ji = () => {
      if (zn.isDomless()) return !0;
      const e = Fi.getDoc();
      return (
        void 0 !== e.hidden ||
        void 0 !== e.mozHidden ||
        void 0 !== e.msHidden ||
        void 0 !== e.webkitHidden
      );
    },
    Ui = function () {
      "use strict";
      return { createInstance: () => (zn.isDomless() ? new qi() : new Li()) };
    },
    Li = function () {
      "use strict";
      let e = !1,
        t = !1;
      at.getAggregator().request("features");
      const n = new Xt(),
        i = () => (Xe(r.prop) ? Fi.getDoc()[r.prop] : null),
        r = (() => {
          let t = "hidden",
            n = "visibilitychange";
          const i = Fi.getDoc();
          return (
            void 0 === i.hidden
              ? Ze(["moz", "ms", "webkit"]).each((r, o) => {
                  const s = o + "Hidden";
                  Xe(i[s]) && ((t = s), (n = o + n), (e = !0));
                })
              : (e = !0),
            e ? { prop: t, event: n } : {}
          );
        })();
      return {
        isHidden: i,
        onHiddenChange: (e) => {
          e && n.push(e),
            t ||
              ((t = !0),
              (() => {
                const e = Fi.getWindow(),
                  t = () => {
                    n.run(i());
                  };
                Jn.addEvent(e, "focus", t, !0),
                  Jn.addEvent(e, "blur", t, !0),
                  r.event && Jn.addEvent(Fi.getDoc(), r.event, t, !0);
              })());
        },
        supportsVisAPI: () => e,
      };
    },
    qi = function () {
      "use strict";
      return {
        isHidden: () => !1,
        onHiddenChange: (e) => {},
        supportsVisAPI: () => !0,
      };
    },
    Wi = function () {
      "use strict";
      return {
        createInstance: function (e, t) {
          return zn.isDomless() ? new Gi() : new Bi(e, t);
        },
      };
    },
    Bi = function (n, i) {
      "use strict";
      let r;
      const o = function (e) {
          const t = [
            ["ab", "about%3A"],
            ["da", "data%3A"],
            ["js", "javascript%3A"],
            ["fi", "file%3A"],
            ["uu", "uuid-in-package"],
            ["cx", "chrome-extension%3A"],
            ["lo", "http%3A%2F%2Flocalhost"],
            ["lo", "https%3A%2F%2Flocalhost"],
          ];
          if (
            "string" == typeof e &&
            "null" !== e &&
            "" !== e &&
            "undefined" !== e
          ) {
            for (let n = 0; n < t.length; n++)
              if (e.startsWith(t[n][1])) return "";
            if (-1 === e.indexOf("."))
              return (
                at
                  .getAggregator()
                  .trigger(
                    "addOutputItem",
                    { output: e.substring(0, 40) },
                    "bunp",
                    { type: "impression" }
                  ),
                ""
              );
          }
          return e;
        },
        s = function () {
          let s = {};
          try {
            s.a = encodeURIComponent(top.location.href);
          } catch (e) {}
          try {
            s.b = encodeURIComponent(parent.location.href);
          } catch (e) {}
          if (zn.embedded) {
            try {
              s.c = encodeURIComponent(parent.document.referrer);
            } catch (e) {}
            try {
              s.e = encodeURIComponent(t.document.referrer);
            } catch (e) {}
          }
          try {
            "jsi" !== oe.adTag.tagType &&
              (s.d = encodeURIComponent(t.location.href));
          } catch (e) {}
          try {
            s.f = encodeURIComponent(e.jsref);
          } catch (e) {}
          try {
            const e = i.getWindow();
            s.q = encodeURIComponent(
              e.parent.parent.parent.parent.parent.parent.parent.parent.parent
                .parent.location.href || ""
            );
          } catch (e) {}
          try {
            n.isStarted() &&
              n.getMyFrameDepth() > 1 &&
              (s.g = encodeURIComponent(n.getTopDomain())),
              n.isStarted() &&
                zn.xDomainIframe &&
                1 === n.getMyFrameDepth() &&
                (s.y = encodeURIComponent(n.getTopDomain()));
          } catch (e) {}
          let a = "not-set";
          try {
            if (zn.isSafeFrame()) {
              const e = i.getWindow(),
                t = e && e.$sf && e.$sf.ext && e.$sf.ext.hostURL,
                n = "function" == typeof t && t();
              if ("string" == typeof n) {
                a = encodeURIComponent(n);
                let e = !1;
                "function" == typeof URL
                  ? (new URL(n), (e = !0))
                  : n.startsWith("http") && (e = !0),
                  e
                    ? ((s.x = a),
                      at
                        .getAggregator()
                        .trigger("addOutputItem", { output: a }, "sfhu", {
                          type: "impression",
                        }))
                    : at
                        .getAggregator()
                        .trigger("addOutputItem", { output: a }, "sfiv", {
                          type: "impression",
                        });
              }
            }
          } catch (e) {
            at.getAggregator().trigger("addOutputItem", { output: a }, "sfiv", {
              type: "impression",
            });
          }
          (s = (function (e) {
            for (const t in e)
              if (e.hasOwnProperty(t)) {
                const n = o(e[t]);
                ("" !== n && "null" !== n && "undefined" !== n && null != n) ||
                  delete e[t];
              }
            return e;
          })(s)),
            (s = (function (e) {
              const t = {};
              let n, i;
              for (i in e)
                e.hasOwnProperty(i) &&
                  ((n = e[i]), void 0 === t[n] ? (t[n] = i) : (t[n] += i));
              const r = {};
              for (i in t) t.hasOwnProperty(i) && ((n = t[i]), (r[n] = i));
              return r;
            })(s));
          const c = [];
          for (const e in s)
            s.hasOwnProperty(e) && c.push({ key: e, val: s[e] });
          return (
            c.sort(function (e, t) {
              return e.val.length > t.val.length
                ? 1
                : e.val.length < t.val.length
                ? -1
                : 0;
            }),
            (r = c),
            c
          );
        };
      return {
        detectTopURL: s,
        getDetectedURLs: function () {
          return r || s();
        },
      };
    },
    Gi = function () {
      "use strict";
      return {
        detectTopURL: function () {
          return [];
        },
        getDetectedURLs: function () {
          return [];
        },
      };
    },
    Hi = function (t) {
      "use strict";
      let n = !1;
      return {
        measure: function (i) {
          (n = 0 === i.rsa), n && t.trigger("notify", e._onSuspicious);
        },
        skipAsFraudulent: function () {
          return n;
        },
      };
    },
    Yi = function () {
      "use strict";
      const e = [],
        t = {},
        n = { sl: "n" };
      let i,
        r,
        o,
        s = 0;
      const a = { i: 0, o: 0, n: 0, pp: 0, pm: 0 },
        c = function (e) {
          const t = at.getAggregator().request("features");
          if (t && t.on("recoverOmidLostTime")) {
            const t = a.ri;
            a.ri = t ? t + e : e;
          }
        },
        d = function (e, n) {
          const i = new In(n);
          return (t[e] = i), i;
        },
        u = function (e, t) {
          return (
            (t = t || "") +
            {
              inView: "i",
              outOfView: "o",
              na: "n",
              partialViewMinus: "pm",
              partialViewPlus: "pp",
            }[e]
          );
        },
        l = function () {
          Ze(n).each(function (t, n) {
            const i = e.length ? o - s : o;
            a[n] += i;
          }),
            (s = o);
        },
        m = function (t) {
          e.length && l(),
            Ze(t).each(function (e, t) {
              var i, r;
              (i = t),
                (r = n[e]) !== i && "n" === r && (a[i] += a.n),
                (n[e] = t);
            }),
            e.length || l();
        },
        g = function (e) {
          const n = e.adDimensions
              ? e.adDimensions.getRounded()
              : { width: 0, height: 0 },
            i = (function (e) {
              const t = {},
                n = e.winDimensions,
                i = e.adDimensions;
              Xe(n) && n.hasValidDims() && (t.wc = n),
                Xe(i) &&
                  i.hasValidDims() &&
                  ((t.ac = i),
                  (t.am = e.method),
                  (t.cc = e.containerDimensions)),
                Ze({
                  piv: "percentInView",
                  obst: "obstructed",
                  th: "tabHidden",
                  reas: "reason",
                }).each(function (n, i) {
                  const r = e[i];
                  Xe(r) && (t[n] = r);
                });
              const r = Ze(t).toParams();
              return "" === r ? "" : "," + r;
            })(e),
            s = e.omidObstructions,
            a = { sl: u(e.viewState) };
          (o = zn.getTagTime()), m(a), (a.t = o);
          const c = Ze({
            toString: function () {
              return (
                Ze(t).each(function (e, t) {
                  t.fastForward();
                }),
                "{" + Ze(a).toParams() + this.details + this.breakdowns + "}"
              );
            },
            details: i,
            breakdowns: {
              piv: [],
              as: [],
              toString: function () {
                let e = "";
                const t = function (e, t) {
                  return t.duration + "~" + t.state;
                };
                return (
                  (e += "piv:[" + Ze(this.piv).stringify(t) + "]"),
                  (e += ",as:[" + Ze(this.as).stringify(t) + "]"),
                  ",bkn:{" + e + "}"
                );
              },
            },
          }).mixin(a);
          return (
            Ze(c).mixin(e),
            (c.width = n.width),
            (c.height = n.height),
            void 0 === c.percentInView && (c.percentInView = -1),
            void 0 === c.reason && (c.reason = ""),
            Xe(s) && "" !== s && (c.omidObstructions = s),
            (r = c),
            c
          );
        };
      return (
        (function () {
          d("piv", function (e) {
            let t;
            const n = e.percentInView,
              i = [1, 25, 30, 50, 75];
            return (
              100 === n || 0 === n
                ? (t = n)
                : (Ze(i).each(function (e, r) {
                    void 0 === t && n < r && (t = i[e - 1]);
                  }),
                  void 0 === t && (t = i[i.length - 1])),
              t
            );
          }),
            d("as", function (e) {
              const t = e.adDimensions
                ? e.adDimensions.getRounded()
                : { width: "na", height: "na" };
              return t.width + "." + t.height;
            });
          const e = at.getAggregator().request("omidAdSessionContext");
          e && e.recoveredTime > -1 && c(e.recoveredTime);
        })(),
        {
          fastForward: function () {
            (o = zn.getTagTime()), l();
          },
          registerLocation: function (r) {
            let o,
              s = !1;
            return (
              n.sl == u(r.viewState) && e.length
                ? ((o = new g(r)), (e[e.length - 1].details = o.details))
                : ((o = new g(r)), e.push(o), (i = r.viewState), (s = !0)),
              at.getAggregator().trigger("newScreenEvent", o),
              Ze(t).each(function (t, n) {
                -1 !== "piv|as".indexOf(t)
                  ? (s && n.clear(),
                    n.addState(o),
                    (e[e.length - 1].breakdowns[t] = n.get()))
                  : n.addState(o);
              }),
              o
            );
          },
          stringify: function (t) {
            let n = "";
            return (
              e.length &&
                (n = Ze({
                  slTimes: "{" + Ze(a).toParams() + "}",
                  slEvents: "[" + e.slice(-t).join(",") + "]",
                  slEventCount: e.length,
                }).toParams()),
              n
            );
          },
          createViewabilityTracker: d,
          getCurrentLoc: function () {
            return u(i);
          },
          getCurrentEvent: function () {
            return r;
          },
          setRecoveredTimeInSlTimes: c,
          getLatestEvent: function () {
            let t;
            return e && e.length > 0 && (t = e[e.length - 1]), t;
          },
        }
      );
    },
    zi = {
      hashCode: function (e) {
        "use strict";
        let t,
          n,
          i,
          r = 0;
        if (0 === e.length) return r;
        for (t = 0, i = e.length; t < i; t++)
          (n = e.charCodeAt(t)), (r = (r << 5) - r + n), (r |= 0);
        return r;
      },
      rot: function (e) {
        "use strict";
        return e.replace(/[a-zA-Z]/g, function (e) {
          return String.fromCharCode(
            (e <= "Z" ? 90 : 122) >= (e = e.charCodeAt(0) + 13) ? e : e - 26
          );
        });
      },
      stringToFn: function (e) {
        "use strict";
        let n,
          i,
          r = t;
        const o = e.split(".");
        for (n = 0; n < o.length; n++)
          if (
            ((i = r),
            (r = r[o[n]]),
            void 0 === r || (n === o.length - 1 && !Je(r)))
          )
            return !1;
        return function () {
          r.apply(i, arguments);
        };
      },
      stringToProp: function (e) {
        "use strict";
        let t,
          n,
          i = Fi.getWindow();
        const r = e.split(".");
        for (
          t = 0;
          t < r.length && ((n = i), (i = i[r[t]]), void 0 !== i);
          t++
        );
        return i;
      },
      contains: function (e, t) {
        "use strict";
        return !!Ke(e) && -1 !== e.indexOf(t);
      },
    },
    Xi = function () {
      "use strict";
      const e = (function () {
          const e = function (e) {
              return e && e.width && e.width > 30 && e.height && e.height > 30;
            },
            t = function (t) {
              const n = oi.getDimensionFromAttributes(t);
              return e(n);
            };
          return {
            hasValidDimensions: function (n) {
              return (
                t(n) ||
                (function (t) {
                  const n = oi.getDimensionFromStyle(t);
                  return e(n);
                })(n)
              );
            },
            hasValidDimentionAttributes: t,
          };
        })(),
        t = /GoogleActiveViewElement/,
        n = /DfaVisibilityIdentifier_/,
        i = /doubleclick.net\/pcs\/click?/,
        r = /_blank/,
        o = function (e) {
          const t = e && oi.tagNameIs(e, "a"),
            n = oi.attributeMatches(e, "href", i),
            o = oi.attributeMatches(e, "target", r);
          return t && n && o;
        },
        s = function (e) {
          const i = oi.tagNameIs(e, "div"),
            r = oi.attributeMatches(e, "class", t),
            o = oi.attributeMatches(e, "id", n);
          return i && r && o;
        };
      return {
        getDFPGoogleDiv: function (e) {
          return oi.traverseAndFindFirstMatchingNode(e, s);
        },
        getClickableImage: function (t) {
          let n, i;
          const r = oi.traverseAndFindFirstMatchingNode(t, o);
          return (
            r &&
              ((i = r && r.children && r.children[0]),
              oi.isImageTag(i) && e.hasValidDimentionAttributes(i) && (n = i)),
            n
          );
        },
        getNodeMatchingMinimumSize: function (t) {
          return oi.traverseAndFindFirstMatchingNode(t, e.hasValidDimensions);
        },
      };
    },
    Ji = function () {
      "use strict";
      const e = Xi(),
        t = function (e, t) {
          (t.tag = e.tagName.toLowerCase()),
            (t.size =
              oi.getDimensionFromAttributes(e) || oi.getDimensionFromStyle(e));
        };
      return {
        getDFPValue: function (n) {
          let i;
          const r = e.getDFPGoogleDiv(n);
          return (
            (i = r
              ? (function (n) {
                  let i, r;
                  const o = { type: 0 };
                  return (
                    n &&
                      ((o.type = 1),
                      (i = e.getClickableImage(n)),
                      i
                        ? ((o.type = 2), t(i, o))
                        : ((r = e.getNodeMatchingMinimumSize(n)),
                          r && ((o.type = 3), t(r, o)))),
                    o
                  );
                })(r)
              : (function (n) {
                  const i = { type: 0 },
                    r = e.getNodeMatchingMinimumSize(n);
                  return r && ((i.type = 4), t(r, i)), i;
                })(n)),
            i
          );
        },
      };
    },
    Ki = {
      name: "hB",
      dependencies: [],
      creator: function () {
        try {
          const e = Pn().getUserAgent(),
            t = e.length > 0 && -1 !== e.indexOf("HeadlessChrome"),
            n = Fi.getWindow(),
            i = Fi.getTop(),
            r = !(!i || !i.document) && Object.getOwnPropertyNames(i),
            o = () => {
              const e = n?.navigator,
                t = e?.userAgentData?.brands;
              return t?.map((e) => e?.brand)?.includes("HeadlessChrome") || !1;
            },
            s = {
              cdcP: Qe(
                r && -1 !== r.indexOf("cdc_adoQpoasnfa76pfcZLmcfl_Promise")
              ),
              cdcA: Qe(
                r && -1 !== r.indexOf("cdc_adoQpoasnfa76pfcZLmcfl_Array")
              ),
              cdcS: Qe(
                r && -1 !== r.indexOf("cdc_adoQpoasnfa76pfcZLmcfl_Symbol")
              ),
              cyp: Qe(r && -1 !== r.indexOf("Cypress")),
              wd: Qe(Xe(n.navigator.webdriver) && !0 === n.navigator.webdriver),
              uaHC: Qe(t),
              chHC: Qe(o()),
            },
            a = 1,
            c = (e) => -1 !== Object.values(e).indexOf(a),
            d = function (e) {
              at.getAggregator().trigger(
                "addThrottledProp",
                "sca",
                "hbs",
                Ze(e).toION()
              );
            };
          c(s) && d(s);
        } catch (e) {}
      },
      settings: {
        tier: 4,
        applies: function () {
          "use strict";
          return !0;
        },
      },
    },
    Qi = {
      name: "viewport",
      dependencies: [],
      creator: function () {
        "use strict";
        const e = { width: 4, height: 4 },
          t = function (t) {
            return !oi.isViewportVisible(t, e);
          },
          n = function (e, i) {
            return e !== i && t(e)
              ? e
              : e !== i && zn.isFriendlyToParent(e)
              ? n(e.parent, i)
              : void 0;
          },
          i = function () {
            const e = Fi.getWindow();
            return n(e, Fi.getWindow().top);
          },
          r = function () {
            return void 0 !== i();
          };
        return {
          MIN_VISIBLE_DIM: e,
          isHidden: r,
          isCurrentIframeTheHiddenFrame: function () {
            let e;
            const n = Fi.getWindow();
            return t(n) ? (e = !0) : r() && (e = !1), e;
          },
          getWindowWithHiddenViewport: i,
        };
      },
    },
    Zi = function (e) {
      "use strict";
      let t, n;
      const i = function (i) {
          (t = e.setInterval(i, 100)),
            (n = e.setTimeout(function () {
              r();
            }, 42e4));
        },
        r = function () {
          t && (e.clearInterval(t), (t = null)),
            n && (e.clearTimeout(n), (n = null));
        };
      return {
        onResize: function (t) {
          let n = e.innerWidth,
            o = e.innerHeight,
            s = !1;
          i(function () {
            const i = (function () {
              const t = e.innerWidth,
                i = e.innerHeight;
              return t !== n || i !== o;
            })();
            i && (s = !0),
              s && !i && (t(), r(), (s = !1)),
              (n = e.innerWidth),
              (o = e.innerHeight);
          });
        },
      };
    },
    er = {
      name: "AS_Finder",
      dependencies: ["viewport"],
      creator: function (e, t) {
        "use strict";
        let n;
        const i = function () {
          try {
            !(function (i) {
              let r;
              const o = {};
              i !== n &&
                ((r = Qe(i)),
                (o.res1 = r),
                (o.ps = r),
                (o.ts = Fi.now()),
                (o.psfr = Qe(e.isCurrentIframeTheHiddenFrame())),
                t.events.trigger("newState", o)),
                (n = i);
            })(e.isHidden());
          } catch (e) {
            at.getAggregator().trigger("error", "H2");
          }
        };
        return {
          start: function () {
            e.isHidden() &&
              (i(),
              (function () {
                const t = e.getWindowWithHiddenViewport();
                t && Zi(t).onResize(i);
              })());
          },
        };
      },
      settings: {
        emits: !0,
        applies: function (e, t, n) {
          "use strict";
          return n.embedded && !n.isBustedIframe() && !n.isSpecifiedAd();
        },
      },
    },
    tr = {
      name: "hA",
      dependencies: ["AS_Finder"],
      creator: function (t) {
        "use strict";
        let n = 0;
        const i = function (e, t) {
            at.getAggregator().trigger(
              "addThrottledProp",
              "sca",
              e,
              Ze(t).toION()
            );
          },
          r = function (e) {
            n < 2 && i("ha1", e), n++;
          };
        !(function () {
          let n, o;
          if (zn.embedded)
            try {
              (o = e.contextNode.parentNode),
                (n = Ji().getDFPValue(o)),
                i(
                  "dfp",
                  (function (e) {
                    const t = {};
                    return (
                      (t.df = e.type),
                      e.size && (t.sz = e.size.width + "." + e.size.height),
                      e.tag && (t.dom = e.tag),
                      t
                    );
                  })(n)
                ),
                n.size && t && (t.events.on("newState", r), t.start());
            } catch (e) {
              at.getAggregator().trigger("error", "H1");
            }
        })();
      },
      settings: {
        tier: 4,
        applies: function (e) {
          "use strict";
          return e.on("usehaps");
        },
      },
    },
    nr = {
      name: "thresholdDetector",
      dependencies: [],
      creator: function () {
        "use strict";
        return {
          create: (e, t, n) => {
            let i;
            let r = t();
            const o = () => {
              const o = t();
              o !== r && !0 && (n(e, o), Fi.clearInterval(i)), (r = o);
            };
            r && (n(e, r), (i = Fi.setInterval(o, 50)));
          },
        };
      },
    },
    ir = {
      name: "invisibleAds",
      dependencies: ["thresholdDetector"],
      creator: function (t) {
        "use strict";
        const n = { width: 4, height: 4 },
          i = () => {
            const e = Jn.getStyle(Fi.getWindow().frameElement, "opacity");
            return parseFloat(e) < 0.2;
          },
          r = () =>
            "hidden" === Jn.getStyle(Fi.getWindow().frameElement, "visibility"),
          o = (e, t) => {
            const n = { res1: Qe(t) };
            at.getAggregator().trigger(
              "addThrottledProp",
              "sca",
              e,
              Ze(n).toION()
            );
          };
        try {
          const s = e.contextNode.parentNode,
            a = Ji().getDFPValue(s);
          oi.isViewportVisible(Fi.getWindow(), n) &&
            2 === a.type &&
            (i() && t.create("ha2", i, o), r() && t.create("ha3", r, o));
        } catch (e) {}
      },
      settings: {
        tier: 4,
        applies: function (e, t, n) {
          "use strict";
          return n.embedded && !n.isBustedIframe() && !n.isSpecifiedAd();
        },
      },
    },
    rr = function (e, n, i, r) {
      "use strict";
      let o,
        s = 0,
        a = 0;
      const c = e && e.body;
      let d = !1;
      const u = function () {
          if (((o = Math.round(oi.getNodeArea(e.body))), o >= r)) {
            const t = o + (20 * o) / 100,
              c = e.querySelectorAll("iframe"),
              u = Array.from(c);
            for (; u.length && (a < t || s < i); ) {
              const e = u.shift(),
                t = Math.round(oi.getNodeArea(e));
              t >= r && (s++, (a += t));
            }
            a >= t &&
              s >= i &&
              (function () {
                const e = { va: o, bia: a, bin: s };
                at
                  .getAggregator()
                  .trigger("addThrottledProp", "sca", n, Ze(e).toION()),
                  (d = !0);
              })();
          }
        },
        l = function () {
          new MutationObserver(function (e, t) {
            d
              ? t.disconnect()
              : Fi.execAtEndOfThread(function () {
                  Ze(e).each(function (e, t) {
                    if (t.addedNodes.length) {
                      const e = t.addedNodes[0];
                      e &&
                        1 === e.nodeType &&
                        oi.tagNameIs(e, "IFRAME") &&
                        ((e, t) => {
                          let n;
                        })(u, 10);
                    }
                  });
                });
          }).observe(e.body, {
            attributes: !1,
            childList: !0,
            characterData: !1,
          });
        };
      c && (Fi.execAtEndOfThread(u), !d && Xe(t.MutationObserver) && l());
    },
    or = {
      name: "BS_Browser",
      dependencies: [],
      creator: function () {
        "use strict";
        const e = Fi.getWindow().document,
          t = e.body ? Math.round(oi.getNodeArea(e.body)) : null;
        !at.getAggregator().request("mobileApp").isMobileAppEnvironment() &&
          t &&
          rr(e, "bs2", 10, t);
      },
      settings: {
        tier: 7,
        applies: function (e, t, n) {
          "use strict";
          const i = !e.bootstrapOn("app") && !n.isDomless();
          return e.on("bbs") && n.embedded && i;
        },
      },
    },
    sr = () => {
      try {
        new cr();
      } catch (e) {}
    },
    ar = ({ context: e, topMostDims: t }) => {
      setTimeout(() => {
        at.getAggregator().trigger(
          "addThrottledProp",
          "env",
          "bs_monitor_inapp",
          Ze({
            images: JSON.stringify(dr({ context: e, max_output_length: 300 })),
            topMostDims: t,
          }).toION()
        );
      }, 1e3);
    };
  class cr {
    constructor() {
      (this.omidFullyLoaded = !1),
        (this.omidInfo = {
          adSessionType: "",
          environment: "",
          creativeType: "",
          mediaType: "",
        }),
        (this.onOmidPartiallyLoaded = (e) => {
          this.omidInfo = (({ omidInfo: e, event: t }) => {
            const n = t.data || {},
              i = n.context || {};
            return {
              ...e,
              adSessionType: i.adSessionType || "",
              environment: i.environment || "",
              creativeType: n.creativeType || "",
              mediaType: n.mediaType || "",
            };
          })({ omidInfo: this.omidInfo, event: e });
        }),
        (this.onOmidFullyLoadedOnce = () => {
          try {
            (({ omidFullyLoaded: e, omidInfo: t }) =>
              !e && "app" === t.environment)({
              omidFullyLoaded: this.omidFullyLoaded,
              omidInfo: this.omidInfo,
            }) &&
              ((this.omidFullyLoaded = !0),
              ((e) => {
                const t = Fi.getTop()?.window;
                if (t) {
                  const n = pr({ node: t.document.body });
                  yr({
                    callback: e,
                    win: t,
                    topMostDims: n,
                    maxIframeDepth: 1,
                    currIframeDepth: 0,
                  });
                }
              })(ar));
          } catch (e) {}
        });
      try {
        if (
          (() => {
            const e = at.getAggregator().request("mobileApp");
            return !!(
              !zn.isDomless() &&
              zn.friendly &&
              Fi.getTop()?.window?.document?.body &&
              e.isMobileAppEnvironment() &&
              zn.isOmid()
            );
          })()
        ) {
          const e = (() => {
            try {
              const e = Fi.getWindow(),
                t = at.getAggregator().request("omidVerificationClient"),
                n = e && e.omid3p;
              return n &&
                Je(n.registerSessionObserver) &&
                Je(n.addEventListener)
                ? n
                : t;
            } catch (e) {
              return null;
            }
          })();
          if (!e) return;
          e.registerSessionObserver(
            this.onOmidPartiallyLoaded.bind(this),
            "IAS"
          ),
            e.addEventListener("loaded", this.onOmidFullyLoadedOnce.bind(this));
        }
      } catch (e) {}
    }
  }
  const dr = ({ context: e, max_output_length: t }) => {
      let n = { info: e.info, imgs: e.images };
      return (
        (n.origImgsLen = e.images?.length),
        (n = lr({ context: n, max_output_length: t })),
        (n = ur({ context: n, max_output_length: t })),
        n
      );
    },
    ur = ({ context: e, max_output_length: t }) => {
      for (let n = e.imgs.length; n > 0 && Ze(e).toION().length > t; n--)
        e.imgs.pop();
      return e;
    },
    lr = ({ context: e, max_output_length: t }) => {
      for (let n = e.imgs.length - 1; n >= 1; n--) {
        const i = e.imgs[n];
        if (!(Ze(e).toION().length > t && i?.src)) break;
        i.src = mr({ string: i.src, maxCharacterCount: 15 });
      }
      return e;
    },
    mr = ({ string: e, maxCharacterCount: t }) =>
      e.length > t ? e.slice(-t) : e,
    gr = {
      info: { w: -1, h: -1, left: -1, top: -1 },
      isSuspicious: !1,
      impressionShouldBeDisqualified: !1,
    },
    pr = ({ node: e }) => {
      const t = e.getBoundingClientRect(),
        n = {
          left: Math.round(t.left),
          top: Math.round(t.top),
          w: Math.round(t.width),
          h: Math.round(t.height),
        };
      if (e.hasAttribute("src")) {
        const t = e.getAttribute("src");
        t &&
          (n.src = (({ src: e }) => {
            const t = e.indexOf("?");
            return -1 === t ? e : e.slice(0, t);
          })({ src: t }));
      }
      return n;
    },
    fr = ({ image: e }) => {
      if (!e || !e.src) return !1;
      const t = e.src.toLowerCase();
      return (
        e.src.startsWith("/") ||
        e.src.startsWith("./") ||
        ["assets/", "logo", "icon"].some((e) => t.includes(e))
      );
    },
    hr = ({ win: e, topMostDims: t }) => {
      const n = (({ win: e, topMostDims: t }) => {
          let n;
          try {
            const i = e.document,
              r = i.body,
              o = Array.from(i.querySelectorAll("img"));
            n = {
              info: pr({ node: r }),
              images: o
                .map((e) => pr({ node: e }))
                .filter((e) =>
                  (({ imageNode: e, topMostDims: t }) =>
                    e.h >= t.h && e.w >= t.w)({ imageNode: e, topMostDims: t })
                ),
              isSuspicious: !1,
              impressionShouldBeDisqualified: !1,
            };
          } catch (e) {
            n = gr;
          }
          return n;
        })({ win: e, topMostDims: t }),
        i = (({ context: e }) =>
          !!e.images && e.images.some((e) => fr({ image: e })))({ context: n });
      return (
        i
          ? ((n.impressionShouldBeDisqualified = !0), (n.isSuspicious = !1))
          : ((n.impressionShouldBeDisqualified = !1),
            (n.isSuspicious = (({ context: e }) =>
              !!(e.images && e.images.length >= 10))({ context: n }))),
        n
      );
    },
    yr = ({
      callback: e,
      win: t,
      topMostDims: n,
      maxIframeDepth: i,
      currIframeDepth: r,
    }) => {
      const o = hr({ win: t, topMostDims: n });
      if (
        (({ context: e }) =>
          e.isSuspicious && !e.impressionShouldBeDisqualified)({ context: o })
      )
        return e({ context: o, topMostDims: n }), o;
      if (
        (({ currIframeDepth: e, maxIframeDepth: t, context: n }) =>
          e >= t || n.impressionShouldBeDisqualified)({
          currIframeDepth: r,
          maxIframeDepth: i,
          context: o,
        })
      )
        return o;
      try {
        const s = Array.from(t.document.getElementsByTagName("iframe"));
        for (const t of s.slice(0, 3)) {
          const s = t?.contentWindow;
          if (!s || !s.document || !s.document.body) continue;
          const a = yr({
            callback: e,
            win: s,
            topMostDims: n,
            maxIframeDepth: i,
            currIframeDepth: r + 1,
          });
          (o.iframes = o.iframes || []), o.iframes.push(a);
        }
      } catch {}
      return o;
    },
    vr = function () {
      "use strict";
      return { createInstance: (e) => (zn.isDomless() ? new br() : new Sr(e)) };
    },
    Sr = function (e) {
      "use strict";
      let n, i, r;
      const o = new Ht(),
        s = new zt(),
        a = new $r(o),
        c = new wr(),
        d = new Mr(),
        u = new Or(o, e),
        l = () => (void 0 === r && (r = new Er(o)), r);
      return {
        isApplicable: (e) =>
          Xe(t.JSON) &&
          Xe(t.postMessage) &&
          (!e.isOmidNative() || e.isOmidForWeb()),
        start: () => {
          o.provide({
            frameCollection: () => a,
            adProxy: () => d,
            adTalkMessage: (e) => new Ir(e, o),
            adTalkMessageCollection: () => c,
            idMapModule: l,
            interFrameQuerySelector: (e) => new Cr(e),
          }),
            s.traverse(a.addFrame),
            u.startListening(),
            u.sendToKnownFrames(),
            at.getAggregator().once("stopAdTalk", () => {
              u.stopListening();
            }),
            at.getAggregator().provide("adTalkEventAggregator", o);
        },
        sendAdTalkCall: u.sendAdTalkCall,
        getFrameMap: () => (void 0 === n && (n = new Tr(o)), n),
        getFrameMapIncludingPeerCase: () => (
          void 0 === i && (i = new Tr(o, true)), i
        ),
        getIdMap: l,
      };
    },
    br = function () {
      "use strict";
      return { isApplicable: () => !1, start: () => {} };
    },
    Ir = function (e, t) {
      "use strict";
      const n = oe.adTag && oe.adTag.asid,
        i = hi(),
        r = t.request("adProxy").myIdCard,
        o = t.request("frameCollection").getMe().getStringifiedPosition();
      return {
        messageContent: e || {},
        srcAsid: n,
        srcTagId: r.tagId,
        srcIsEmbedded: zn.embedded,
        srcIsFriendly: zn.friendly,
        srcBirthdate: oe.measurementConfig.birthdate,
        iasCommonId: i,
        nodeSelector: zn.friendly
          ? "[data-integralas-id-" + n + "]"
          : (() => {
              const e = Fi.getWindow(),
                t = e.location && e.location.href;
              return (
                'iframe[src*="' + (t && t.replace(/^https?:\/\//i, "")) + '"]'
              );
            })(),
        positionStr: o,
        version: "0.1",
      };
    },
    wr = function () {
      "use strict";
      const e = {};
      return {
        add: (t) => {
          const n = t && t.srcAsid;
          n && (e[n] = t);
        },
        map: (t) =>
          Object.keys(e)
            .map((n) => t(n, e[n]))
            .filter((e) => void 0 !== e),
        has: (t) => {
          const n = t && t.srcAsid;
          return e[n];
        },
      };
    },
    Ar = function (e, n, i, r) {
      "use strict";
      const o = e == t,
        s = {
          position: n.slice(0),
          id: n.join("-"),
          isMe: o,
          isLeaf: !e.frames.length,
          adProxies: o ? i : [],
          selfDescription: void 0,
          unifiedId: oe.measurementConfig.birthdate,
          srcIsEmbedded: r ? r.srcIsEmbedded : void 0,
          inbox: r ? [r] : [],
          getDomObj: () => e,
          getStringifiedPosition: () =>
            Ze(s.position)
              .map((e, t) => tt(Number(t) + 1, 36))
              .join(""),
          isValidForMapping: () => s.isLeaf || s.isMe || Xe(s.selfDescription),
        },
        a = (e, t) =>
          !Ze(e).find((e, n) => n.adSafeId && n.adSafeId === t.adSafeId);
      return (
        (s.addInformationFromSrc = (e, t) => {
          ((e) => {
            const t = s.adProxies,
              n = e.adProxies;
            let i = [];
            t.length && n.length
              ? Ze(n).each((e, n) => {
                  a(t, n) && i.push(n);
                })
              : (i = n),
              (s.adProxies = t.concat(i));
          })(t),
            ((e) => {
              Ze(s.inbox).find(
                (t, n) => n.srcAsid && n.srcAsid === e.srcAsid
              ) || s.inbox.push(e);
            })(e),
            (s.srcIsEmbedded = e.srcIsEmbedded),
            (s.selfDescription = t);
        }),
        s
      );
    },
    $r = function (e) {
      "use strict";
      const t = [],
        n = {};
      let i = { noMe: !0 };
      return {
        addFrame: (r, o, s) => {
          const a = e.request("adProxy").getAll(),
            c = new Ar(r, o, a, s);
          return t.push(c), (n[c.id] = c), c.isMe && (i = c), c;
        },
        getFrame: (e) => n[e],
        list: t,
        dictionary: n,
        getMe: () => i,
      };
    },
    Tr = function (e, t) {
      "use strict";
      const n = (e, n) => {
          const o = n.adProxies;
          let s = "";
          if (n.isValidForMapping())
            return (s += t ? r(o, n.getStringifiedPosition()) : i(o, n)), s;
        },
        i = (e, t) => {
          let n = "";
          return (
            (n += t.getStringifiedPosition()),
            (n += t.isMe ? "*" : ""),
            (n += e.length ? "." + e[0].tagId : ""),
            n
          );
        },
        r = (e, t) => {
          let n = "";
          return (
            e.length
              ? (n += Ze(e).stringify((e, n) => o(n, t), "|"))
              : (n += t),
            n
          );
        },
        o = (e, t) =>
          t +
          ((oe.adTag && oe.adTag.asid) === e.adSafeId ? "*" : "") +
          "." +
          e.tagId;
      return {
        output: () => {
          const t = e.request("frameCollection"),
            i = Ze(t.list).stringify(n, "|");
          return tt(t.getMe().unifiedId, 62) + "+" + i;
        },
      };
    },
    Er = function (t) {
      "use strict";
      const n = t.request("frameCollection").getMe().getStringifiedPosition(),
        i = e.contextNode.parentNode,
        r = t.request("interFrameQuerySelector", i),
        o = (e) => {
          let t = !1;
          const o = !zn.embedded,
            s = "BODY" !== oi.getNodeName(i) && "HEAD" !== oi.getNodeName(i),
            a =
              e.srcIsEmbedded &&
              !((e) => {
                const t = "0.1" !== e.version,
                  n =
                    e.nodeSelector &&
                    -1 === e.nodeSelector.indexOf("data-integralas-id");
                return t ? n : !e.srcIsFriendly;
              })(e);
          return (
            (t =
              o && s && !a
                ? !!((e) => r.queryFor(e.nodeSelector))(e)
                : !!((e) => {
                    const t = e.positionStr,
                      i = e.srcIsEmbedded && zn.embedded,
                      r = 0 === n.indexOf(t) || 0 === t.indexOf(n);
                    return i && r;
                  })(e)),
            t
          );
        };
      return {
        output: () => {
          let e;
          const i = n + "*",
            r = t.request("adTalkMessageCollection").map((e, t) => {
              let n;
              return (
                e !== (oe.adTag && oe.adTag.asid) &&
                  o(t) &&
                  (n = ((e) =>
                    e.positionStr +
                    "." +
                    e.srcAsid +
                    "." +
                    e.transferDuration +
                    "_" +
                    e.srcTagId)(t)),
                n
              );
            });
          return (
            r.push(i),
            (e = r.join("|")),
            e.length > 120 &&
              ((e = ((e) => e && e.substr(0, 120) + ".of" + e.length)(e)),
              at.getAggregator().trigger("stopAdTalk")),
            e
          );
        },
        isCandidateForMyIdMap: o,
      };
    },
    Cr = function (e) {
      "use strict";
      const t = new zt(),
        n = (e, t) =>
          oi.querySelector(
            ((e) => {
              let t = e;
              const n = "IFRAME" === oi.getNodeName(e),
                i = oi.isWindow(e);
              return (
                n ? (t = e.contentWindow.document) : i && (t = e.document), t
              );
            })(e),
            t
          );
      return {
        queryFor: (i) => {
          let r = null;
          return (
            i &&
              (r = ((i, r) => {
                let o, s, a;
                try {
                  (s = n(i, r)),
                    s ||
                      ((o = t.getFrames(!0, e)),
                      o.find((e) => ((a = n(e, r)), a)));
                } catch (e) {}
                return s || a || null;
              })(e, i)),
            r
          );
        },
      };
    },
    Or = function (e) {
      "use strict";
      let t,
        n = !1;
      const i = oe.adTag && oe.adTag.asid,
        r = (t) => {
          const n =
            !e.request("adTalkMessageCollection").has(t) && t.srcAsid !== i;
          return (
            t.hasOwnProperty("messageContent") && hi() === t.iasCommonId && n
          );
        },
        o = () => {
          const t = e.request("frameCollection").getMe(),
            n = { self: t, unifiedId: t.unifiedId };
          return e.request("adTalkMessage", n);
        },
        s = () => {
          e.request("frameCollection");
          n || (n = !0), at.getAggregator().trigger("sendDt", "a");
        },
        a = (t, i, r) => {
          let o, a, c, d, u;
          try {
            (o = e.request("frameCollection")),
              (a = e.request("adTalkMessageCollection")),
              (c = i.messageContent.self),
              a.add(i),
              (m = o.getMe()),
              (g = c),
              m.unifiedId > g.unifiedId && (m.unifiedId = g.unifiedId),
              (i.transferDuration = ((e) => Fi.now() - e.sentTime)(i)),
              (d = o.getFrame(c.id)),
              void 0 === (l = d) || void 0 === l.selfDescription
                ? ((d = d || o.addFrame(t.source, c.id.split("-"), i)),
                  d.addInformationFromSrc(i, c),
                  r())
                : d.addInformationFromSrc(i, c),
              (u = n && e.request("idMapModule").isCandidateForMyIdMap(i)),
              u && s();
          } catch (e) {
            at.getAggregator().trigger("error", "D");
          }
          var l, m, g;
        };
      return {
        sendAdTalkCall: s,
        sendToKnownFrames: () => {
          new Qt().send(o);
        },
        startListening: () => {
          (t = new Kt()), t.listen(r, a, o);
        },
        stopListening: () => {
          t && t.stop();
        },
        validateMessage: r,
        processMessage: a,
        createMessage: o,
      };
    },
    _r = function () {
      "use strict";
      const e = at.getAggregator().request("ids"),
        t = e.getAsid();
      return { tagId: e.getFwId(), adSafeId: t };
    },
    Mr = function () {
      "use strict";
      const e = [],
        t = (t) => {
          const n = new _r(t);
          return e.push(n), n;
        },
        n = t();
      return { createNew: t, getAll: () => e, myIdCard: n };
    },
    Dr = [0, 0.01, 0.2, 0.25, 0.3, 0.5, 0.7, 0.75, 0.8, 0.99, 1],
    xr = function (e, t) {
      "use strict";
      let n,
        i,
        r = "na",
        o = r,
        s = !1,
        a = !1,
        c = !1;
      const d = !t,
        u = at.getAggregator().request("browser"),
        l = function (e, t) {
          if (
            (function (e) {
              const t = at.getAggregator().request("mobileApp");
              return (
                (e.browserIs("c") ||
                  e.isAndroidWebViewBrowser() ||
                  e.browserIs("w") ||
                  e.browserIs("e")) &&
                !t.isMobileAppEnvironment() &&
                e.hasResizeObserver()
              );
            })(u)
          ) {
            Fi.getResizeObserver(function (n, i) {
              const r = n.pop();
              r.contentRect.height * r.contentRect.width > 0 &&
                (t.unobserve(e), t.observe(e), i.disconnect());
            }).observe(e);
          }
        },
        m = function () {
          const t = Fi.getIntersectionObserver(
            function (e, t) {
              const i = e.pop();
              let s =
                ((i.intersectionRect.width * i.intersectionRect.height) /
                  (i.boundingClientRect.width * i.boundingClientRect.height)) *
                100;
              isNaN(s) && (l(i.target, t), (s = 0)),
                (r = Math.min(s, 100)),
                (n = i.boundingClientRect),
                r !== o &&
                  Fi.execAtEndOfThread(function () {
                    at.getAggregator().trigger("IOPivChange", r);
                  }),
                (o = r);
            },
            { threshold: Dr }
          );
          d &&
            Fi.execAtEndOfThread(function () {
              "na" === r && (r = 0);
            }),
            t.observe(f(e)),
            d &&
              Fi.execAtEndOfThread(function () {
                zn.isBustedIframe() ||
                  at.getAggregator().trigger("delayedViewabilityReady");
              }),
            (s = !0);
        },
        g = function (e) {
          m();
          try {
            const t = Fi.getIntersectionObserver(function (e) {
              e.forEach(function (e) {
                e.isIntersecting ||
                  ((r = 0),
                  (o = 0),
                  (n = new DOMRectReadOnly(0, 0, 0, 0)),
                  t.disconnect());
              });
            });
            t.observe(e);
          } catch (e) {}
        },
        p = function () {
          try {
            let t;
            return (
              e &&
                e.ownerDocument &&
                e.ownerDocument.defaultView &&
                (t = e.ownerDocument.defaultView.frameElement),
              t
            );
          } catch (e) {}
        },
        f = function (t) {
          if (void 0 !== t) {
            if (c) {
              const n = e.document,
                i = n.createElement("div");
              Ze(i.style).mixin({
                position: "absolute",
                width: "100%",
                opacity: "0",
                height: "100%",
                zIndex: -999,
                top: "0px",
                left: "0px",
              }),
                (i.iasdetector = !0),
                n.body.appendChild(i),
                (t = i);
            }
            return (i = t), t;
          }
        };
      return {
        start: function () {
          const t = (function () {
              let t;
              try {
                e.document &&
                  ((c = !0),
                  (t = { bodyElement: e.document.body, document: e.document }));
              } catch (e) {
                a = !0;
              }
              return t;
            })(),
            n = p();
          t && null !== t.bodyElement
            ? m()
            : t && t.document
            ? Jn.whenReady(m, t.document)
            : a
            ? at.getAggregator().request("mErrors").add("y")
            : n && zn.isCeltra()
            ? g(n)
            : m();
        },
        isReady: function () {
          return "na" !== r;
        },
        isStarted: function () {
          return s;
        },
        getAdNodeDimensions: function () {
          let e;
          return (
            n &&
              (e = ei({
                scrX: void 0,
                scrY: void 0,
                width: n.width,
                height: n.height,
              })),
            e
          );
        },
        getObservedNode: function () {
          return i;
        },
        getPiv: function () {
          return r;
        },
      };
    },
    Pr = function () {
      "use strict";
      let e = !1;
      return (
        Jn.whenReady(function () {
          at.getAggregator().trigger("startViewabilityLoop"), (e = !0);
        }),
        {
          loopStarted: function () {
            return e;
          },
        }
      );
    },
    Nr = {
      name: "loopDelay",
      dependencies: [],
      creator: Pr,
      settings: {
        applies: function (e, t, n) {
          "use strict";
          return e.bootstrapOn("allowViewability");
        },
        tier: 7,
      },
    },
    Vr = function () {
      "use strict";
      return {
        start: function (e) {
          at.getAggregator().on("measurable", function () {
            e();
          });
        },
        isApplicable: function (e, t) {
          return !t.browserIs("w") || !e.isImmediatelyMeasurable();
        },
      };
    },
    Rr = function () {
      "use strict";
      return {
        start: function (e) {
          e();
        },
        isApplicable: function (e) {
          return e.isImmediatelyMeasurable();
        },
      };
    },
    kr = function (t, n, i) {
      "use strict";
      let r = !1;
      const o = function () {
        try {
          n.impressionIsIdentifiable() && !r
            ? ((r = !0), at.getAggregator().trigger("notify", e._onMeasurable))
            : n.impressionIsIdentifiable() ||
              __IntegralASDiagnosticCall("rtsmeas_imp_not_iden", {}, e);
        } catch (t) {
          __IntegralASDiagnosticCall("rtsmeas_send_noti_error", t, e);
        }
      };
      return {
        start: function () {
          try {
            const n = [jr(), Fr(), Rr(), Vr()].find(function (e) {
              return e.isApplicable(i, t);
            });
            n
              ? n.start(o)
              : __IntegralASDiagnosticCall("rtsmeas_no_chosen_strategy", {}, e);
          } catch (t) {
            __IntegralASDiagnosticCall("rtsmeas_start_error", t, e);
          }
        },
        isApplicable: function (t) {
          return (
            t.bootstrapOn("useViewabilityNotification") && Xe(e._onMeasurable)
          );
        },
      };
    },
    Fr = function () {
      "use strict";
      return {
        start: function (e) {
          var t, n;
          ((t = at.getAggregator()),
          (n = ["adImpression", "measurable"]),
          {
            onAll: (e) => {
              let i = {};
              n.forEach((r) => {
                t.on(r, () => {
                  (i[r] = 1),
                    Object.keys(i).length === n.length && ((i = {}), e());
                });
              });
            },
          }).onAll(function () {
            e();
          });
        },
        isApplicable: function (e, t) {
          const n = t.getIOSVersion() >= 9;
          return (!t.browserIs("w") || n) && zn.isVideo();
        },
      };
    },
    jr = function () {
      "use strict";
      return {
        start: function (e) {
          at.getAggregator().once("adImpression", function () {
            e();
          });
        },
        isApplicable: function (e) {
          return e.isImmediatelyMeasurable() && zn.isVideo();
        },
      };
    },
    Ur = function (e, t, n) {
      "use strict";
      return {
        accepts: function () {
          const e = Xe(
            Hr.find(function (e) {
              return e === n;
            })
          );
          return t.accepts() && t.isMediaType("display") && e;
        },
        isImmediate: function () {
          return !0;
        },
        isMediaType: t.isMediaType,
        supportsAdContainerGeometry: function () {
          return t.supportsAdContainerGeometry();
        },
        start: function () {},
      };
    },
    Lr = function (t) {
      "use strict";
      const n = Fi.getWindow(),
        i = n && n.omid3p,
        r = at.getAggregator().request("omidAdSessionContext"),
        o = !!(t && t.isSupported && t.isSupported()),
        s = !!(i && Je(i.registerSessionObserver) && Je(i.addEventListener));
      return {
        accepts: function () {
          return (o || s) && !e.videoId && !e._cl_adpath;
        },
        isMediaType: function (e) {
          return e === r.mediaType;
        },
        supportsAdContainerGeometry: function () {
          return !0;
        },
      };
    },
    qr = function (e, t, n) {
      "use strict";
      const i = at.getAggregator().request("omidAdSessionContext"),
        r = i.isHtml && i.isWeb ? Yr : Hr,
        o = zr(e);
      return {
        accepts: function () {
          const e = Xe(
            r.find(function (e) {
              return e === n;
            })
          );
          return t.accepts() && t.isMediaType("video") && e;
        },
        isImmediate: function () {
          return !0;
        },
        isMediaType: t.isMediaType,
        supportsAdContainerGeometry: function () {
          return t.supportsAdContainerGeometry();
        },
        start: function () {
          o.addEventListener("start", function (e) {
            at.getAggregator().trigger("adImpression");
          });
        },
      };
    },
    Wr = [
      "start",
      "firstQuartile",
      "midpoint",
      "thirdQuartile",
      "resume",
      "bufferFinish",
    ],
    Br = ["complete", "pause", "bufferStart", "skipped"],
    Gr = ["playerStateChange", "loaded", "volumeChange"],
    Hr = [$.Rjss, $.Amt, $.Jss, $.Jload],
    Yr = [...Hr, $.JsVid, $.FwjsVid],
    zr = (e) => {
      const t = Fi.getWindow(),
        n = t && t.omid3p;
      return !!(n && Je(n.registerSessionObserver) && Je(n.addEventListener))
        ? n
        : e;
    },
    Xr = [
      { root: "omidNativeInfo", code: "onpn", field: "partnerName" },
      { root: "omidNativeInfo", code: "onpv", field: "partnerVersion" },
      { root: "omidJsInfo", code: "ojpn", field: "partnerName" },
      { root: "omidJsInfo", code: "ojpv", field: "partnerVersion" },
      { root: "omidJsInfo", code: "osev", field: "serviceVersion" },
      { root: "omidJsInfo", code: "oscv", field: "sessionClientVersion" },
      { root: "app", code: "applv", field: "libraryVersion" },
      { root: "app", code: "appid", field: "appId" },
      { root: "deviceInfo", code: "dty", field: "deviceType", encode: !0 },
      { root: "deviceInfo", code: "osn", field: "os" },
      { root: "deviceInfo", code: "osv", field: "osVersion" },
    ],
    Jr = function (e) {
      "use strict";
      return {
        resolve: function () {
          return e.find(function (e) {
            return e.environment.accepts();
          });
        },
      };
    },
    Kr = function (n) {
      "use strict";
      let i = !1,
        r = !1,
        o = !1,
        s = !1;
      const a = at.getAggregator().request("omidAdSessionContext");
      (a.queuedOutputItems = []),
        (a.cachedEvents = []),
        (a.cachedGeometryEventsReceived = !1),
        (a.cachedVideoEventsReceived = !1),
        (a.recoveredTime = -1),
        (a.grnd = "u");
      const c = new ia();
      let d = at.getAggregator().request("omidAdSessionVerificationParameters");
      const u = at.getAggregator().request("features"),
        l = zr(n);
      let m = !1;
      (a.omidEarlyExit = !1), (a.mediaType = "display");
      let g = !1;
      const p = function () {
          return d && d.IAS && Object.keys(d.IAS).length > 0 ? d.IAS : d;
        },
        f = function (e, t) {
          a.queuedOutputItems.push({ code: e, value: t });
        },
        h = function (e, t, n) {
          at.getAggregator().trigger(e, t, n);
        },
        y = function (e, t) {
          e &&
            e.data &&
            e.data.hasOwnProperty("creativeType") &&
            ((!t && a.hasOwnProperty("creativeType")) ||
              (a.creativeType = e.data.creativeType));
        },
        v = function (e) {
          at.getAggregator().trigger(e);
        },
        S = function () {
          if (i && r && (!s || o)) {
            (t.omidSupported = !0),
              a.hasOwnProperty("impressionType") && f("oiet", a.impressionType),
              a.hasOwnProperty("creativeType") && f("oct", a.creativeType),
              a.underEvaluation && f("oef", !0),
              (a.exitedOASRS = !0),
              (m = !0);
            const e = p();
            e &&
              (oe.baseUrls &&
                oe.baseUrls.updateWithVerificationParameters({
                  verificationParameters: e,
                }),
              oe.measurementConfig &&
                oe.measurementConfig.updateWithVerificationParameters({
                  verificationParameters: e,
                }),
              oe.adTag &&
                oe.adTag.updateWithVerificationParameters({
                  verificationParameters: e,
                })),
              oe &&
                oe.jsConfigRequest &&
                oe.jsConfigRequest.buildRequestUrlFromParameters &&
                oe.jsConfigRequest.buildRequestUrlFromParameters({
                  contextNode: oe.jsConfigRequest.contextNode,
                  omidParameters: p(),
                }),
              ze();
          }
        },
        b = function (e) {
          if (e && "start" === e.type)
            return (a.videoStartArrived = !0), void v("omidrendvideostart");
          "loaded" !== e.type ||
            a.omidLoadedArrived ||
            (f("oloa", zn.getTagTime()),
            (o = !0),
            (a.omidLoadedArrived = !0),
            v("omidloadedarrived"),
            y(e, !0),
            "audio" === a.creativeType &&
              ((a.accessMode = "limited"), (a.isLimitedSandbox = !0)),
            e.data.hasOwnProperty("impressionType") &&
              (a.impressionType = e.data.impressionType),
            !0 === a.omidEarlyExit &&
              (g ||
                (h("addThrottledOutputItem", "oiet", a.impressionType),
                h("addThrottledOutputItem", "oct", a.creativeType),
                (g = !0))),
            S());
        },
        I = function (t) {
          if ("sessionStart" === t.type) {
            !(function (e, t, n, i) {
              const r = e.data.context;
              (t.adSessionType = r.adSessionType || "undefined"),
                (t.environment = r.environment),
                (t.accessMode = r.accessMode || "limited"),
                (t.omidNativeInfo = r.omidNativeInfo),
                (t.omidJsInfo = r.omidJsInfo),
                (t.deviceInfo = r.deviceInfo),
                (t.app = r.app),
                (t.supports = r.supports),
                (t.element = r.videoElement || r.slotElement || null),
                t.app &&
                  "string" == typeof t.app.appId &&
                  t.app.appId.toLowerCase().indexOf("pandora") > -1 &&
                  (t.ignoreDivAsCandidate = !0),
                e.data.hasOwnProperty("contentUrl") &&
                  (t.contentUrl = e.data.contentUrl),
                r.hasOwnProperty("underEvaluation") &&
                  (t.underEvaluation = r.underEvaluation),
                r.hasOwnProperty("podSequence") &&
                  ((t.podSequence = r.podSequence), i("opds", t.podSequence)),
                r.hasOwnProperty("adCount") &&
                  ((t.adCount = r.adCount), i("oadc", t.adCount)),
                r.hasOwnProperty("transactionId") &&
                  ((t.transactionId = r.transactionId),
                  i("otid", t.transactionId)),
                r.hasOwnProperty("friendlyToTop") &&
                  ((t.friendlyToTop = r.friendlyToTop),
                  i("oftt", t.friendlyToTop)),
                r.hasOwnProperty("deviceCategory") &&
                  ((t.deviceCategory = r.deviceCategory),
                  i("ocat", t.deviceCategory)),
                r.hasOwnProperty("universalAdId") &&
                  ((t.universalAdId = r.universalAdId),
                  i("uadid", t.universalAdId)),
                (t.isJavaScript = "javascript" === t.adSessionType),
                (t.isNative =
                  "native" === t.adSessionType ||
                  "javascript" === t.adSessionType),
                (t.isLimitedSandbox =
                  "app" === t.environment
                    ? n.embedded
                    : "full" !== r.accessMode),
                t.app &&
                  "string" == typeof t.app.appId &&
                  t.app.appId.toLowerCase().indexOf("pinterest") > -1 &&
                  "limited" === t.accessMode &&
                  (t.isLimitedSandbox = !0),
                (t.isHtml = "html" === r.adSessionType),
                (t.isWeb = "web" === r.environment),
                (t.partnerName =
                  t.omidNativeInfo &&
                  t.omidNativeInfo.partnerName &&
                  t.omidNativeInfo.partnerName.toLowerCase()),
                (t.isOmidForWebEnvironment = t.isHtml && t.isWeb);
              for (let e = 0; e < Xr.length; e++) {
                const n = Xr[e].root,
                  r = Xr[e].field,
                  o = Xr[e].code,
                  s = t[n];
                if ("object" == typeof s && void 0 !== s[r]) {
                  const t = s[r];
                  i(
                    o,
                    Xr[e].encode && "string" == typeof t
                      ? encodeURIComponent(t)
                      : t
                  );
                }
              }
              i("oast", t.adSessionType),
                i("oacm", t.accessMode),
                i("oenv", t.environment),
                t.hasOwnProperty("contentUrl") &&
                  i("ocon", encodeURIComponent(t.contentUrl || ""));
            })(t, a, zn, f),
              (d = t.data.verificationParameters),
              y(t, !1);
            const n = (function (e) {
              return (
                zn.isOmidForWeb() ||
                (e.data.hasOwnProperty("supportsLoadedEvent") &&
                  ("true" === e.data.supportsLoadedEvent ||
                    !0 === e.data.supportsLoadedEvent) &&
                  "string" == typeof e.data.creativeType &&
                  "" !== e.data.creativeType)
              );
            })(t);
            n
              ? ((s = !0),
                (a.useOMID13Logic = !0),
                f("ohand", "13"),
                l.addEventListener("media", b))
              : f("ohand", "12");
            const c = (function (t, n) {
              let i = "0";
              return (
                e.omidLeaveEarly
                  ? (e && e.mobFwUrl && e.mobFwUrl.indexOf("xmtp=v") > -1
                      ? (a.mediaType = "video")
                      : (a.mediaType =
                          "web" === a.environment
                            ? t.data.mediaType || "video"
                            : t.data.mediaType),
                    a.mediaType &&
                      t.data.creativeType &&
                      ((a.omidEarlyExit = !0),
                      (i = "1"),
                      (r = o = !0),
                      f("omtp", a.mediaType)),
                    "video" === a.mediaType &&
                      ((a.isVideo = !0), (a.isNativeVideo = a.isNative)),
                    (a.isDisplay = "display" === a.mediaType))
                  : (a.isOmidForWebEnvironment ||
                      ((a.integratedBlocking =
                        oe.measurementConfig.isResolved &&
                        zn.integratedBlockingApplies(e.mobFwUrl)),
                      a.integratedBlocking &&
                        u &&
                        u.on("exitOASRSEarly") &&
                        ((a.omidEarlyExit = !0),
                        (i = "1"),
                        a.omidEarlyExit &&
                          e.mobFwUrl.indexOf("xmtp=v") > -1 &&
                          (a.mediaType = "video")),
                      !t.data.mediaType ||
                        ("display" !== t.data.mediaType &&
                          "video" !== t.data.mediaType) ||
                        (a.mediaType = t.data.mediaType)),
                    a.omidEarlyExit &&
                      ((r = !0),
                      f("omtp", a.mediaType),
                      (o = !!n || o),
                      (a.isVideo = "video" === a.mediaType || a.isVideo),
                      (a.isNativeVideo = a.isNative && a.isVideo),
                      (a.isDisplay = "display" === a.mediaType))),
                i
              );
            })(t, n);
            if (
              ("audio" === t.data.creativeType &&
                ((a.accessMode = "limited"), (a.isLimitedSandbox = !0)),
              t.data.hasOwnProperty("lastActivity") &&
                t.data.lastActivity.hasOwnProperty("timestamp") &&
                oe &&
                oe.measurementConfig &&
                oe.measurementConfig.birthdate)
            ) {
              const e = t.data.lastActivity.timestamp;
              (a.lastActivity = e),
                f("olas", e - oe.measurementConfig.birthdate);
            }
            f("oerl", c), f("oses", zn.getTagTime()), (i = !0), S();
          }
          if ("sessionError" === t.type) {
            const e =
                "string" == typeof t.data.errorType
                  ? t.data.errorType
                  : "NoErrType",
              n =
                "string" == typeof t.data.message
                  ? t.data.message
                  : "NoMessage",
              i = e + "_" + encodeURIComponent(n);
            m ? h("addOutputItem", { output: i }, "oser") : f("oser", i);
          }
        },
        w = function (e) {
          "impression" === e.type &&
            ((a.omidImpressionArrived = !0),
            v("omidimpressionarrived"),
            (a.mediaType =
              "web" === a.environment
                ? e.data.mediaType || "video"
                : e.data.mediaType),
            f("omtp", a.mediaType),
            y(e, !0),
            "audio" === e.data.creativeType &&
              ((a.accessMode = "limited"), (a.isLimitedSandbox = !0)),
            f("oimp", zn.getTagTime()),
            "video" === e.data.mediaType && (a.isVideo = !0),
            (function (e) {
              return e.data.adView && (e.data.viewport || a.isWeb);
            })(e) &&
              ((a.impressionViewabilityMeasurement = {
                type: "geometryChange",
                data: { viewport: e.data.viewport, adView: e.data.adView },
                timestamp: e.timestamp,
              }),
              void 0 === a.geometryArrived &&
                c.checkForViewAttachmentBasedOnAdSessionType(
                  a,
                  e.data.adView
                ) &&
                ((a.geometryArrived = !0), v("omidrendgeoupdate"))),
            e.data.hasOwnProperty("impressionType") &&
              !o &&
              (a.impressionType = e.data.impressionType),
            (a.isNativeVideo = a.isNative && "video" === e.data.mediaType),
            (a.isDisplay = "display" === e.data.mediaType),
            (r = !0),
            S());
        },
        A = function (e) {
          e &&
            e.data &&
            e.data.interactionType &&
            "click" === e.data.interactionType &&
            mo.omid.trackClick(e);
        };
      return {
        start: function () {
          l.registerSessionObserver(I, "IAS"),
            l.addEventListener("impression", w),
            l.addEventListener("adUserInteraction", A);
        },
      };
    },
    Qr = function () {
      "use strict";
      return {
        accepts: function () {
          return !0;
        },
      };
    },
    Zr = function () {
      "use strict";
      const e = at.getAggregator().request("omidAdSessionContext"),
        t = at.getAggregator().request("omidVerificationClient"),
        n = new Lr(t),
        i = e.isHtml && e.isWeb;
      return {
        accepts: function () {
          return n.accepts() && i;
        },
      };
    },
    eo = function () {
      "use strict";
      return {
        start: function () {
          ze();
        },
      };
    };
  class to {
    static maxScrollDepth({ maxScrollDepth: e }) {
      at.getAggregator().trigger("addOutputItem", { output: e }, "msd");
    }
    static pageHeight({ pageHeight: e }) {
      at.getAggregator().trigger("addOutputItem", { output: e }, "ph");
    }
    static notAvailableOrApplicableMaxScrollDepth({ reason: e }) {
      at.getAggregator().trigger("addOutputItem", { output: e }, "nmsd");
    }
    static notAvailableOrApplicablePageHeight({ reason: e }) {
      at.getAggregator().trigger("addOutputItem", { output: e }, "nph");
    }
  }
  class no extends a {
    constructor() {
      super({ storeModelName: "pageMetrics" }),
        (this.maxScrollDepth = 0),
        (this.ticking = !1),
        (this.scrollHandler = () => {
          this.ticking ||
            (this.topWindow?.requestAnimationFrame(() => {
              this.sendPageMetricsData(), (this.ticking = !1);
            }),
            (this.ticking = !0));
        }),
        (this.topWindow = (() => {
          let e;
          try {
            zn.friendly && !zn.isDomless() && (e = Fi.getTop() || void 0);
          } catch (e) {}
          return e;
        })()),
        this.topWindow && this.initScrollListener();
    }
    sendPageMetricsData() {
      const e = this.getPageMetrics({ topWindow: this.topWindow });
      if (void 0 !== e) {
        const { pageHeight: t, maxScrollDepth: n } = e;
        void 0 !== n && to.maxScrollDepth({ maxScrollDepth: n }),
          void 0 !== t && to.pageHeight({ pageHeight: t });
      } else
        to.notAvailableOrApplicableMaxScrollDepth({ reason: -1 }),
          to.notAvailableOrApplicablePageHeight({ reason: -1 });
    }
    initScrollListener() {
      try {
        this.topWindow?.addEventListener("scroll", this.scrollHandler),
          this.prepareScrollListenerCleanup();
      } catch (e) {}
    }
    prepareScrollListenerCleanup() {
      Jn.whenReady(() => {
        const e = at.getAggregator();
        e &&
          e.on &&
          e.on("altAdSessionComplete", () => {
            try {
              this.topWindow?.removeEventListener("scroll", this.scrollHandler);
            } catch (e) {}
          });
      });
    }
    getPageMetrics({ topWindow: e }) {
      let t;
      if (e)
        try {
          const n = e.document.documentElement.scrollHeight,
            i = e.scrollY || e.document.documentElement.scrollTop;
          (this.maxScrollDepth = Math.max(this.maxScrollDepth, Math.round(i))),
            (t = { pageHeight: n, maxScrollDepth: this.maxScrollDepth });
        } catch (e) {
          to.notAvailableOrApplicableMaxScrollDepth({ reason: -1 }),
            to.notAvailableOrApplicablePageHeight({ reason: -1 });
        }
      return t;
    }
  }
  const io = ({ jsInfoCode: e, output: t, errorCode: n }) => {
    try {
      at.getAggregator().trigger("addOutputItem", { output: t }, e),
        at.getAggregator().trigger("sendDt", "e");
    } catch (e) {
      at.getAggregator().trigger("error", n);
    }
  };
  class ro {
    constructor() {
      (this.mousedOver = !1), (this.clicked = !1);
    }
    mouseOver() {
      this.mousedOver = !0;
    }
    mouseOut() {
      this.mousedOver = !1;
    }
    click() {
      this.clicked = !0;
    }
    isMousedOver() {
      return this.mousedOver;
    }
    wasClicked() {
      return this.clicked;
    }
  }
  class oo {
    constructor({ tagStartTime: e, adState: t }) {
      (this.initClickTracking = ({ clickSource: e }) => {
        this.clickData[e] || (this.clickData[e] = []);
      }),
        (this.getClicks = ({ clickSource: e }) => this.clickData[e]),
        (this.setupTrackAndBroadcastClick = ({
          clientX: e,
          clientY: t,
          clickSource: n,
        }) => {
          const i = [e, t, zn.getTagTime()];
          this.getClicks({ clickSource: n }).push(i),
            io({
              output: Ze(this.clickData).toION(),
              errorCode: "Q",
              jsInfoCode: "clks",
            });
        }),
        (this.trackClick = ({ event: e, clickSource: t }) => {
          const { clientX: n, clientY: i } = e;
          this.adState.click(),
            this.setupTrackAndBroadcastClick({
              clientX: n,
              clientY: i,
              clickSource: t,
            });
        }),
        (this.trackBlur = ({ clickSource: e }) => {
          this.setupTrackAndBroadcastClick({
            clientX: -1,
            clientY: -1,
            clickSource: e,
          });
        }),
        (this.trackTouch = ({ clientX: e, clientY: t, clickSource: n }) => {
          this.setupTrackAndBroadcastClick({
            clientX: e,
            clientY: t,
            clickSource: n,
          });
        }),
        (this.trackOmidClick = () => {
          this.initClickTracking({ clickSource: "om" }),
            this.trackClick({
              event: { clientX: 0, clientY: 0 },
              clickSource: "om",
            });
        }),
        (this.isProxyClick = () =>
          !this.adState.wasClicked() &&
          this.adState.isMousedOver() &&
          n.activeElement instanceof HTMLIFrameElement),
        (this.trackBlurClick = () => {
          if (this.isProxyClick()) {
            const e = "blr";
            this.adState.mouseOut(),
              this.initClickTracking({ clickSource: e }),
              this.trackBlur({ clickSource: e });
          }
        }),
        (this.trackAdComponentClick = (e) => {
          this.initClickTracking({ clickSource: "ac" }),
            this.trackClick({ event: e, clickSource: "ac" });
        }),
        (this.trackMobileTouchStart = (e) => {
          if (e.changedTouches && e.changedTouches[0]) {
            const t = e.changedTouches[0],
              { clientX: n, clientY: i } = {
                clientX: Math.round(t?.clientX),
                clientY: Math.round(t?.clientY),
              };
            this.mobileClickVerify.trackMobileTimeAndCoords({
              clientX: n,
              clientY: i,
            });
          }
        }),
        (this.trackMobileTouchEnd = (e) => {
          if (e.changedTouches && e.changedTouches[0]) {
            const t = e.changedTouches[0],
              { clientX: n, clientY: i } = {
                clientX: Math.round(t.clientX),
                clientY: Math.round(t.clientY),
              };
            if (
              this.mobileClickVerify.isMobileLinkClick({
                clientX: n,
                clientY: i,
              })
            ) {
              const e = "mt";
              this.initClickTracking({ clickSource: e }),
                this.trackTouch({ clientX: n, clientY: i, clickSource: e });
            }
          }
        }),
        (this.trackPointerUp = (e) => {
          if ("pen" === e.pointerType && e.clientX && e.clientY) {
            const { clientX: t, clientY: n } = {
              clientX: Math.round(e.clientX),
              clientY: Math.round(e.clientY),
            };
            if (
              this.mobileClickVerify.isMobileLinkClick({
                clientX: t,
                clientY: n,
              })
            ) {
              const e = "mt";
              this.initClickTracking({ clickSource: e }),
                this.trackTouch({ clientX: t, clientY: n, clickSource: e });
            }
          }
        }),
        (this.trackPointerDown = (e) => {
          if ("pen" === e.pointerType && e.clientX && e.clientY) {
            const { clientX: t, clientY: n } = {
              clientX: Math.round(e.clientX),
              clientY: Math.round(e.clientY),
            };
            this.mobileClickVerify.trackMobileTimeAndCoords({
              clientX: t,
              clientY: n,
            });
          }
        }),
        (this.clickData = {}),
        (this.tagStartTime = e),
        (this.adState = t),
        (this.mobileClickVerify = new so());
    }
  }
  class so {
    constructor() {
      (this.trackMobileTimeAndCoords = ({ clientX: e, clientY: t }) => {
        this.mobileTouchTimer.startTimer(),
          (this.lastClientX = e),
          (this.lastClientY = t);
      }),
        (this.isMobileLinkClick = ({ clientX: e, clientY: t }) => {
          const n = this.mobileTouchTimer.endTimer();
          let i = !1;
          if (
            (this.mobileTouchTimer.startTimer(),
            n && n <= 200 && this.lastClientX && this.lastClientY)
          ) {
            const n = Math.abs(e - this.lastClientX),
              r = Math.abs(t - this.lastClientY),
              o = 10;
            n <= o && r <= o && (i = !0);
          }
          return i;
        }),
        (this.mobileTouchTimer = new uo()),
        this.mobileTouchTimer.startTimer();
    }
  }
  class ao {
    constructor({ adState: e, tagStartTime: t }) {
      (this.trackAdComponentMouseOver = () => {
        this.adState.mouseOver(),
          this.hoverData.timeToFirstHover ||
            (this.hoverData.timeToFirstHover = zn.getTagTime()),
          (this.hoverData.hoverCount += 1),
          this.hoverTimer.startTimer(),
          io({
            output: Ze(this.hoverData.getData()).toION(),
            errorCode: "he",
            jsInfoCode: "hov",
          });
      }),
        (this.trackAdComponentMouseOut = () => {
          this.adState.mouseOut();
          const e = this.hoverTimer.endTimer();
          (e || 0 === e) &&
            ((this.hoverData.totalHoverTime += e),
            io({
              output: Ze(this.hoverData.getData()).toION(),
              errorCode: "he",
              jsInfoCode: "hov",
            }));
        }),
        (this.adState = e),
        (this.tagStartTime = t),
        (this.hoverData = new co()),
        (this.hoverTimer = new uo());
    }
  }
  class co {
    constructor() {
      (this.getData = () => [
        this.timeToFirstHover,
        this.hoverCount,
        this.totalHoverTime,
      ]),
        (this.hoverCount = 0),
        (this.totalHoverTime = 0),
        (this.timeToFirstHover = 0);
    }
  }
  class uo {
    constructor() {
      this.startTime = 0;
    }
    startTimer() {
      this.startTime = new Date().getTime();
    }
    endTimer() {
      let e;
      return (
        this.startTime && (e = new Date().getTime() - this.startTime),
        (this.startTime = 0),
        e
      );
    }
  }
  const { birthdate: lo } = e,
    mo = new (class {
      constructor({ tagStartTime: e }) {
        (this.finalizeAllCollectedData = () => {
          this.hover.trackAdComponentMouseOut();
        }),
          (this.adState = new ro()),
          (this.tagStartTime = e),
          (this.click = new oo({ tagStartTime: e, adState: this.adState })),
          (this.hover = new ao({ tagStartTime: e, adState: this.adState }));
      }
      get adComponent() {
        return {
          trackClick: this.click.trackAdComponentClick,
          trackBlur: this.click.trackBlurClick,
          trackMouseOver: this.hover.trackAdComponentMouseOver,
          trackMouseOut: this.hover.trackAdComponentMouseOut,
        };
      }
      get mobile() {
        return {
          trackTouchEnd: this.click.trackMobileTouchEnd,
          trackTouchStart: this.click.trackMobileTouchStart,
          trackPointerUp: this.click.trackPointerUp,
          trackPointerDown: this.click.trackPointerDown,
        };
      }
      get omid() {
        return { trackClick: this.click.trackOmidClick };
      }
    })({ tagStartTime: lo }),
    go = ({ omidVerificationClient: e, eventManager: n }) => {
      const i = "videoPlaybackEvent",
        r = at.getAggregator().request("omidAdSessionContext"),
        o = zr(e),
        s = [],
        a = ((e) => ({
          isEmpty: () => 0 === e.length,
          toString: () => {
            let t = "{vEventCount:" + e.length + ",vEvents:[";
            for (let n = 0; n < e.length; n++) {
              const i = e[n];
              let r =
                (n > 0 ? ",{" : "{") +
                "t:" +
                i.t +
                ",rt:" +
                i.rt +
                ",tp:" +
                i.tp +
                ",sl:" +
                i.sl +
                ",ad_duration:" +
                i.ad_duration +
                ",volume:" +
                i.volume +
                ",devol:" +
                i.devol;
              void 0 !== i.avoc && (r += i.avoc >= 0 ? ",avoc:" + i.avoc : ""),
                void 0 !== i.grnd && (r += ",grnd:" + i.grnd),
                (t += r + "}");
            }
            return (t += "]}"), t;
          },
        }))(s);
      let c = new Date().getTime(),
        d = 0,
        u = 1,
        l = 0,
        m = !1,
        g = !1,
        p = !1,
        f = !1,
        h = null,
        y = !1;
      const v = function () {
          const e = at
              .getAggregator()
              .request("mScreenEvents")
              ?.getCurrentEvent?.(),
            t = d > 0 && (null == u || u > 0);
          return e
            ? {
                ...e,
                percentInView: g ? 100 : e.percentInView,
                fullPercentInView: g ? 100 : e.fullPercentInView,
                isVideoPlaying: !0,
                isVideoPlayingInFullscreen: g,
                isSoundOn: t,
              }
            : e;
        },
        S = function (e) {
          if ([...Wr, ...Br, ...Gr].includes(e.type))
            try {
              f && (e.iasCached = !0);
              const t = e.hasOwnProperty("timestamp")
                  ? e.timestamp
                  : new Date().getTime(),
                o = t - (oe.measurementConfig.birthdate || t + 1),
                a = [];
              let S,
                b = !1;
              switch (e.type) {
                case "start":
                  a.push("adVideoStart"),
                    (r.videoStartArrived = !0),
                    at.getAggregator().trigger("omidrendvideostart"),
                    (c = t),
                    (l = e.data.duration || "0"),
                    l > 1e3 && (l /= 1e3),
                    (d =
                      null != e.data.mediaPlayerVolume
                        ? e.data.mediaPlayerVolume
                        : e.data.videoPlayerVolume),
                    (u = null != e.data.deviceVolume ? e.data.deviceVolume : 1),
                    "audio" === r.creativeType &&
                      0 === d &&
                      at
                        .getAggregator()
                        .trigger("addThrottledProp", "env", "smu", 1);
                  break;
                case "volumeChange":
                  a.push("volumeChanged"),
                    (d =
                      null != e.data.mediaPlayerVolume
                        ? e.data.mediaPlayerVolume
                        : e.data.videoPlayerVolume),
                    (u = null != e.data.deviceVolume ? e.data.deviceVolume : 1);
                  break;
                case "firstQuartile":
                  a.push("adVideoFirstQuartile"),
                    (b = !0),
                    at
                      .getAggregator()
                      .trigger("videoQuartileEvent", {
                        videoEvent: e,
                        screenEvent: v(),
                      });
                  break;
                case "midpoint":
                  a.push("adVideoMidpoint"),
                    (b = !0),
                    at
                      .getAggregator()
                      .trigger("videoQuartileEvent", {
                        videoEvent: e,
                        screenEvent: v(),
                      });
                  break;
                case "thirdQuartile":
                  a.push("adVideoThirdQuartile"),
                    (b = !0),
                    at
                      .getAggregator()
                      .trigger("videoQuartileEvent", {
                        videoEvent: e,
                        screenEvent: v(),
                      });
                  break;
                case "complete":
                  a.push("adVideoComplete"),
                    (b = !0),
                    at
                      .getAggregator()
                      .trigger("videoQuartileEvent", {
                        videoEvent: e,
                        screenEvent: v(),
                      });
                  break;
                case "bufferStart":
                  a.push("bufferStart");
                case "pause":
                  a.push("pauseAd");
                  break;
                case "bufferFinish":
                  a.push("bufferFinish");
                case "resume":
                  a.push("resumeAd");
                  break;
                case "skipped":
                  a.push("adSkipped");
              }
              if (
                ((d = d > 0 && d < 0.1 ? 0.1 : parseInt(10 * d) / 10),
                (u = u > 0 && u < 0.1 ? 0.1 : parseInt(10 * u) / 10),
                a.length > 0)
              ) {
                const e = at.getAggregator().request("mScreenEvents");
                let n,
                  i = "n";
                e && (i = e.getCurrentLoc() || i);
                try {
                  const t = e.getLatestEvent();
                  n =
                    d > 0 &&
                    ((Xe(u) && u > 0) || void 0 === u) &&
                    t &&
                    t.percentInView &&
                    t.percentInView >= 50
                      ? 1
                      : 0;
                } catch (e) {}
                const m = null != r?.grnd ? r.grnd : "u";
                for (let e = 0; e < a.length; e++) {
                  const r = a[e],
                    g = {
                      t: t - c,
                      rt: o,
                      tp: r,
                      sl: i,
                      ad_duration: l,
                      volume: d,
                      devol: u,
                      grnd: m,
                    };
                  "adVideoComplete" === r && (g.avoc = n), s.push(g);
                }
              }
              if (
                ("loaded" === e.type &&
                  Xe(e.data) &&
                  ((e, t, n) => {
                    const i = [
                        "preroll",
                        "midroll",
                        "postroll",
                        "standalone",
                      ].indexOf(e.data.position),
                      r = -1 !== i ? i + 1 : void 0,
                      o = [];
                    o.push(
                      !0 === e.data.autoPlay ? "autoplayed" : "clicktoplay"
                    ),
                      !0 === e.data.skippable && o.push("skippable");
                    const s = "fullscreen" === e.data.state;
                    s && ((n.loadedInFullscreen = !0), o.push("fullscreen"));
                    const a = o.join(".");
                    return (
                      t
                        ? (Xe(r) &&
                            at
                              .getAggregator()
                              .trigger("addThrottledProp", "env", "vbp", r),
                          at
                            .getAggregator()
                            .trigger("addThrottledProp", "env", "vps", a))
                        : (Xe(r) &&
                            at
                              .getAggregator()
                              .trigger("addOutputItem", { output: r }, "vbp", {
                                type: "impression",
                              }),
                          at
                            .getAggregator()
                            .trigger("addOutputItem", { output: a }, "vps", {
                              type: "impression",
                            })),
                      s
                    );
                  })(e, p, r) &&
                  (g = !0),
                "start" === e.type &&
                  (at
                    .getAggregator()
                    .trigger("omidAdDuration", { ad_duration: l }),
                  (r.adDuration = l)),
                "playerStateChange" === e.type
                  ? ((g = "fullscreen" === e.data.state),
                    (S =
                      "fullscreen" === e.data.state
                        ? "AdEnteredFullscreen"
                        : "AdExitedFullscreen"))
                  : Wr.includes(e.type)
                  ? ((S = "AdPlaying"), (m = !0))
                  : Br.includes(e.type) && ((S = "AdPaused"), (m = !1)),
                "audio" === r.creativeType && !y)
              ) {
                m && d > 0 && u > 0
                  ? null === h && (h = t)
                  : (null !== h &&
                      t - h >= 1990 &&
                      (at
                        .getAggregator()
                        .trigger("addThrottledProp", "env", "aco", 1),
                      (y = !0)),
                    (h = null));
              }
              if ("audio" === r.creativeType && a.length > 0) {
                const e = ((e, t, n, i, r) => {
                  const o = {
                    type: "geometryChange",
                    timestamp: i,
                    internallyGenerated: !0,
                    treatAsCached: r,
                    data: {
                      viewport: { width: e, height: t },
                      adView: {
                        measuringElement: !1,
                        percentageInView: n,
                        geometry: {
                          x: 0,
                          y: 0,
                          width: e,
                          height: t,
                          obstructions: [],
                          reasons: [],
                        },
                        reasons: [],
                      },
                    },
                  };
                  return (
                    (o.data.adView.onScreenGeometry =
                      o.data.adView.containerGeometry =
                      o.data.adView.onScreenContainerGeometry =
                        o.data.adView.geometry),
                    o
                  );
                })(20, 20, 100, t, f);
                (m && 0 !== u && 0 !== d) ||
                  ((e.data.adView.geometry.width =
                    e.data.adView.geometry.height =
                      0),
                  (e.data.adView.percentageInView = 0)),
                  at
                    .getAggregator()
                    .trigger("internallyGeneratedGeometryEvent", e);
              }
              f &&
                "loaded" !== e.type &&
                ((r.cachedVideoEventsReceived = !0),
                "start" === e.type &&
                  (r.cachedStartEventIndex = r.cachedEvents.length),
                r.cachedEvents.push(e)),
                Xe(S) && n.trigger(i, { eventType: S, eventData: null }),
                "start" === e.type &&
                  at
                    .getAggregator()
                    .trigger(
                      "videoStartEvent",
                      f ? e : { videoEvent: e, screenEvent: v() }
                    ),
                b && at.getAggregator().trigger("sendDt", "m");
            } catch (e) {
              __IntegralASDiagnosticCall("omidvideo", e, t.bootstrapper);
            }
        },
        b = function () {
          "audio" !== r.creativeType ||
            y ||
            null === h ||
            (new Date().getTime() - h >= 1990 &&
              (at.getAggregator().trigger("addThrottledProp", "env", "aco", 1),
              (y = !0)));
        };
      return {
        start: function () {
          at.getAggregator().on("impressionsent", function () {
            p = !0;
          }),
            at.getAggregator().provide({ omidVideoEventsString: a }),
            (f = !0),
            "audio" === r.creativeType
              ? o.addEventListener("media", S)
              : o.addEventListener("video", S),
            (f = !1),
            "audio" === r.creativeType && at.getAggregator().on("preSendDt", b),
            (r.cachedVideoEventsChecked = !0),
            r.cachedVideoEventsReceived && r.processCachedEvents();
        },
        addVideoPlaybackEventListener: function (e) {
          n.on(i, e);
        },
      };
    },
    po = (e, t) =>
      e && t && "number" == typeof e.x
        ? t.reduce((t, n) => {
            if (n && "number" == typeof n.x) {
              const i = Math.max(n.x, e.x),
                r = Math.max(n.y, e.y),
                o = Math.min(n.x + n.width, e.x + e.width) - i,
                s = Math.min(n.y + n.height, e.y + e.height) - r;
              o > 0 && s > 0 && t.push({ x: i, y: r, width: o, height: s });
            }
            return t;
          }, [])
        : t || [],
    fo = (e) => {
      const t = () => {
        const n = Fi.getDoc().getElementById(
          "iasbi" + (oe.adTag && oe.adTag.asid)
        );
        n && n.hasAttribute("CreativeLoaded") ? e() : Fi.setTimeout(t, 50);
      };
      return t;
    },
    ho = (e) => (e && e.indexOf("backgrounded") > -1 ? "b" : "f"),
    yo = function (e) {
      const t = {
          inactive: "f",
          viewport: "l",
          clipped: "l",
          obstructed: "o",
          backgrounded: "f",
          notFound: "h",
          hidden: "h",
          noWindowFocus: "w",
          noOutputDevice: "u",
          unmeasurable: "m",
          pictureInPicture: "p",
          deviceLocked: "k",
        },
        n = [];
      return e
        ? (e.forEach(function (e) {
            const i = t[e];
            i && n.indexOf(i) < 0 && n.push(i);
          }),
          n.join("."))
        : "";
    },
    vo = function (e, t) {
      let n = t;
      const i = e.data || {},
        r =
          i.mediaPlayerVolume ?? i.videoPlayerVolume ?? e.volume ?? e.adVolume,
        o = i.deviceVolume;
      return (
        "number" == typeof r
          ? (n = r > 0 && (null == o || o > 0))
          : "number" == typeof o && (n = o > 0),
        n
      );
    },
    So = function (e, t, n, i, r) {
      const o = r ? 100 : e,
        s = {
          percentInView: o,
          fullPercentInView: o,
          tabHidden: 0,
          isVideoPlaying: t,
          isVideoPlayingInFullscreen: r,
          isSoundOn: n,
        };
      return i && (s.adDimensions = new ei(i)), s;
    },
    bo = function (e, t) {
      "use strict";
      const n = new wi(),
        i = go({ omidVerificationClient: e, eventManager: t });
      return {
        start: function () {
          i.start(), n.init();
        },
        addVideoPlaybackEventListener: i.addVideoPlaybackEventListener,
      };
    },
    Io = function (e, t) {
      "use strict";
      const n = "measurementChanged";
      let i = !1;
      const r = function (e) {
          return e >= 50;
        },
        o = function (e) {
          const o = e.percentageInView;
          (i = !0),
            (e.viewState = (function (e) {
              return r(e) ? "inView" : "outOfView";
            })(o)),
            (e.outOfViewReason = r(o) ? "" : "l"),
            t.trigger(n, e);
        };
      return {
        start: function () {
          at
            .getAggregator()
            .trigger("addOutputItem", { output: "d" }, "mtp", {
              type: "impression",
            }),
            e.addScreenLocationChangedListener(o),
            e.start();
        },
        getStrategyName: function () {
          return "display";
        },
        addMeasurementChangedListener: function (e) {
          t.on(n, e);
        },
        isMeasurable: function () {
          return i;
        },
      };
    },
    wo = function (e, t, n) {
      "use strict";
      const i = Xe(e) ? e.environment : void 0,
        r = Xe(e) ? e.measurementStrategy : void 0,
        o = function () {
          return Xe(r);
        };
      Xe(t) && t.start();
      return {
        hasMeasurementStrategy: o,
        getScreenLocationInfo: function (e) {
          return t.create(e);
        },
        isImmediate: function () {
          return !o() || i.isImmediate();
        },
        isMeasurable: function () {
          return !!o() && r.isMeasurable();
        },
        isMediaType: function (e) {
          return !!o() && i.isMediaType(e);
        },
        supportsAdContainerGeometry: function () {
          return e.environment.supportsAdContainerGeometry();
        },
        start: function () {
          o() && i.start();
        },
        requiresDelayedViewabilityEvent: function () {
          o() && t.requiresDelayedViewabilityEvent();
        },
      };
    },
    Ao = function (e, t, n) {
      "use strict";
      const i = at.getAggregator().request("mobileApp");
      return {
        create: function () {
          let t = [];
          (t = t.concat(e.getOmidMeasurementStrategies())),
            (t = t.concat(e.getMraidMeasurementStrategies()));
          const n = new To(t).resolve();
          n ||
            at
              .getAggregator()
              .trigger("addOutputItem", { output: "0" }, "oam", {
                type: "impression",
              });
          const r = new Eo(n);
          return new wo(n, r, i.isMobileAppEnvironment());
        },
      };
    },
    $o = function (e) {
      "use strict";
      const t = at.getAggregator().request("mobileApp");
      return {
        getOmidMeasurementStrategies: function () {
          const e = at.getAggregator().request("omidVerificationClient"),
            t = new Lr(e),
            n = [];
          if (t.accepts()) {
            const i = new No(),
              r = new Ro(),
              o = new Zr(),
              s = at.getAggregator().request("omidAdSessionContext"),
              a = new Po(e, new Yt()),
              c = [
                { environment: i, measurementStrategy: new Vo(e, new Yt()) },
                {
                  environment: o,
                  measurementStrategy: new ko(
                    new ms(),
                    Fi.getWindow(),
                    new Yt()
                  ),
                },
                {
                  environment: r,
                  measurementStrategy: new jo(
                    new Ts(),
                    Fi.getWindow(),
                    new Yt()
                  ),
                },
              ],
              d = new To(c).resolve(),
              u = d ? d.measurementStrategy : {},
              l = new Mo(new xo(new Ks()), new Ks(), s.isHtml),
              m = new Ur(e, t, oe.adTag.tagType),
              g = new Do(a, u, new Yt(), l),
              p = new qr(e, t, oe.adTag.tagType),
              f = new Fo(a, u, new bo(e, new Yt()), new Yt(), l);
            n.push({ environment: m, measurementStrategy: g }),
              n.push({ environment: p, measurementStrategy: f });
          }
          return n;
        },
        getMraidMeasurementStrategies: function () {
          const e = [],
            n = t.isSafeToInjectMraid(),
            i = t.isMobileAppEnvironment(),
            r = oe.mraidLifecycleTracker;
          r?.refresh("strategy");
          let o = r?.getSnapshot();
          const s = Boolean(
            Me() && i && !zn.isOmid() && !zn.isVideo() && o?.mraidEverObserved
          );
          r?.confirmEligibility(s), (o = r?.getSnapshot());
          const a = new Uo(Fi.getWindow(), n, i, s);
          if (a.accepts()) {
            const t = at.getAggregator().request("context"),
              n = new Oo(Fi.getWindow(), t),
              i = new Lo(Fi.getWindow(), new Yt(), {
                useLifecycleTracker: "eligible" === o?.eligibility,
              });
            let r;
            if (n.accepts()) {
              const e = new _o(Fi.getWindow(), new Yt());
              r = {
                environment: n,
                measurementStrategy: new Co(i, e, new Yt()),
              };
            } else if (zn.isVideo()) {
              (r = {
                environment: a,
                measurementStrategy: new Co(i, void 0, new Yt()),
              }),
                at
                  .getAggregator()
                  .trigger("addOutputItem", { output: "1" }, "xmvd", {
                    type: "impression",
                  });
            } else {
              r = { environment: a, measurementStrategy: new Io(i, new Yt()) };
            }
            e.push(r);
          }
          return e;
        },
      };
    },
    To = function (e) {
      "use strict";
      return {
        resolve: function () {
          const t = e.find(function (e) {
            return e.environment.accepts();
          });
          if (Xe(t)) return t;
        },
      };
    },
    Eo = function (e) {
      "use strict";
      let t,
        n,
        i = !1;
      const r = {
          winDimensions: ei({ scrX: 0, scrY: 0, width: 0, height: 0 }),
          adDimensions: ei({ scrX: 0, scrY: 0, width: 0, height: 0 }),
          containerDimensions: ei({ scrX: 0, scrY: 0, width: 0, height: 0 }),
          method: "na",
          viewState: "na",
          percentInView: -1,
          reason: "",
          obstructed: "na",
          isHidden: "na",
          tabHidden: "na",
          posViewState: "na",
          adCompCount: 1,
        },
        o = function (e) {
          return e
            ? new ei({ scrX: e.x, scrY: e.y, width: e.width, height: e.height })
            : ei({ scrX: 0, scrY: 0, width: 0, height: 0 });
        },
        s = function (e) {
          n = {
            winDimensions: o(e.windowDimensions),
            adDimensions: o(e.adDimensions),
            containerDimensions: o(e.containerDimensions),
            method: e.detectionMethod || "na",
            viewState: e.viewState || "na",
            percentInView: Xe(e.percentageInView) ? e.percentageInView : -1,
            reason: e.outOfViewReason || "",
            obstructed: Qe(e.isObstructed),
            isHidden: "na",
            tabHidden: "na",
            posViewState: e.viewState || "na",
            adCompCount: 1,
            shouldDelegateToDomBasedViewability:
              e.shouldDelegateToDomBasedViewability,
            sliceStatus: e.sliceStatus,
            isVideoPlaying: e.isVideoPlaying,
            isVideoPlayingInFullscreen: e.isVideoPlayingInFullscreen,
            isSoundOn: e.isSoundOn,
          };
          const r = e.omidObstructions;
          Xe(r) && "" !== r && (n.omidObstructions = r),
            e.isMeasurable &&
              ((t = !0),
              i &&
                ((i = !1),
                at.getAggregator().trigger("delayedViewabilityReady")));
        };
      return {
        create: function (t) {
          let i = r;
          return (
            Xe(n) &&
              (e.environment.supportsAdContainerGeometry()
                ? (i = n)
                : n.shouldDelegateToDomBasedViewability
                ? ((i = Xe(t) ? t : r),
                  (i.method = Xe(i.method) ? i.method : "na"))
                : (0 === n.percentInView || n.percentInView >= 75) && (i = n)),
            i
          );
        },
        start: function () {
          let t;
          Xe(e) &&
            Xe(e.measurementStrategy) &&
            ((t = e.measurementStrategy),
            t.addMeasurementChangedListener(s),
            t.start());
        },
        requiresDelayedViewabilityEvent: function () {
          i = !0;
        },
      };
    },
    Co = function (e, t, n) {
      "use strict";
      const i = "measurementChanged";
      let r,
        o,
        s,
        a,
        c = !1,
        d = !1,
        u = !1;
      const l = function (e) {
          return e < 50;
        },
        m = function () {
          if (void 0 === o) return;
          const e = [];
          let t, m;
          c
            ? (d ? ((m = !1), (t = 100)) : ((m = a), (t = s)),
              l(t) && e.push("l"))
            : ((m = !1), (t = 0), e.push("v")),
            (u = !0),
            (o.shouldDelegateToDomBasedViewability = m),
            (o.percentageInView = t),
            (o.viewState = (function (e) {
              return l(e) ? "outOfView" : "inView";
            })(t)),
            (o.outOfViewReason = e.join(".")),
            (r = o),
            n.trigger(i, r);
        },
        g = function (e) {
          (o = e),
            (s = e.percentageInView),
            (a = e.shouldDelegateToDomBasedViewability),
            m();
        },
        p = function (e) {
          const t = e.eventType;
          "AdEnteredFullscreen" === t
            ? (d = !0)
            : "AdExitedFullscreen" === t
            ? (d = !1)
            : -1 !== "AdStarted|AdVideoStart|AdPlaying".indexOf(t)
            ? (c = !0)
            : -1 !==
                "AdSkipped|AdUserClose|AdPaused|AdVideoComplete|AdStopped".indexOf(
                  t
                ) && (c = !1),
            m();
        };
      return {
        start: function () {
          at
            .getAggregator()
            .trigger("addOutputItem", { output: "v" }, "mtp", {
              type: "impression",
            }),
            e && (e.addScreenLocationChangedListener(g), e.start()),
            t && (t.addVideoPlaybackEventListener(p), t.start());
        },
        getStrategyName: function () {
          return "video";
        },
        addMeasurementChangedListener: function (e) {
          n.on(i, e);
        },
        isMeasurable: function () {
          return u;
        },
      };
    },
    Oo = function (e, t) {
      "use strict";
      return {
        accepts: function () {
          return t.isInMobiMraidVideo();
        },
        isImmediate: function () {
          return !1;
        },
        supportsAdContainerGeometry: function () {
          return !1;
        },
        start: function () {
          try {
            let t;
            e.inmobi.IASDocumentVideoBuffer.addVideoEventListener(function (e) {
              "AdVideoStart" !== e.type ||
                t ||
                ((t = !0), at.getAggregator().trigger("adImpression"));
            });
          } catch (e) {}
        },
      };
    },
    _o = function (e, t) {
      "use strict";
      const n = "inMobiMraidVideoPlaybackEvent",
        i = function (e) {
          try {
            const i = e.type;
            t.trigger(n, { eventType: i });
          } catch (e) {}
        };
      return {
        start: function () {
          try {
            const t = e.inmobi;
            t.IASDocumentVideoBuffer.addVideoEventListener(i);
          } catch (e) {}
        },
        addVideoPlaybackEventListener: function (e) {
          t.on(n, e);
        },
      };
    },
    Mo = function (e, t, n) {
      "use strict";
      const i = function (e, t) {
          const n = Math.max(e.x, t.x),
            i = Math.max(e.y, t.y),
            r = Math.min(e.x + e.width, t.x + t.width) - n,
            o = Math.min(e.y + e.height, t.y + t.height) - i;
          return { x: n, y: i, width: r > 0 ? r : 0, height: o > 0 ? o : 0 };
        },
        r = function (e, t, n) {
          const r = i(t, e);
          return i(n, { x: 0, y: 0, width: r.width, height: r.height });
        },
        o = function (e, t) {
          const n = zn.isOmidForWeb(),
            i = !zn.isOmidSandboxedEnvironment(),
            r = n && i;
          return {
            x: r ? t.x : e.x + t.x,
            y: r ? t.y : e.y + t.y,
            width: t.width,
            height: t.height,
          };
        },
        s = function (e, t) {
          return {
            x: t.x - e.x,
            y: t.y - e.y,
            width: t.width,
            height: t.height,
          };
        };
      function a(e, t, n) {
        const i = s(t, n),
          o = r(e, t, i);
        return o.width * o.height;
      }
      const c = function (e) {
          return d(e) ? "inView" : "outOfView";
        },
        d = function (e) {
          return e >= 50;
        };
      return {
        calculateGeometricMeasurement: function (i, u) {
          if (!Xe(i) || !Xe(u)) return;
          const l = i.viewport,
            m = i.computedAdContainer,
            g = m.obstructions,
            p = i.omidObstructions,
            f = g && g.length > 0,
            h = i.originalAdContainer,
            y = u.adGeometry;
          let v = u.adFound;
          const S = i.detectionMethod;
          let b = 0;
          const I = { x: 0, y: 0, width: l.width, height: l.height },
            w = o(h, y);
          let A,
            $ = i.outOfViewReason,
            T = 0,
            E = 0,
            C = f || !1;
          const O = y.width * y.height <= 1,
            _ = !(
              !i.preserveOmidViewabilityOnZeroViewportFallback ||
              0 !== l.width ||
              0 !== l.height
            );
          n &&
            O &&
            ((v = !1),
            ($ = (function (e, t) {
              let n = e || "";
              return (
                t ||
                  -1 !== n.indexOf("l") ||
                  (n = "l" + ("" !== n ? "." + n : "")),
                n
              );
            })($, v))),
            v && _
              ? ((b = i.percentageInView),
                (A = (function (e, n) {
                  return t
                    .getConfig(e)
                    .percentInViewSliceArray.map(function (e) {
                      return e > 1 ? n >= e : n >= 100 * e;
                    });
                })(y, b)))
              : v && i.percentageInView > 0
              ? ((T = a(I, m, w)),
                (E = f
                  ? (function (t, n, i, a) {
                      const c = s(n, i),
                        d = r(t, n, c),
                        u = o(n, d);
                      return e.calculateObstructedArea(u, a);
                    })(I, m, w, g)
                  : 0),
                (b = Math.round(((T - E) / (w.width * w.height)) * 100)),
                f && 0 === E && (C = !1),
                (A = (function (n, i, r, o) {
                  let s,
                    c = 0;
                  const d = t.getConfig(r).numberOfSlices;
                  let u = Fi.floor(r.height / d) || 1;
                  const l = [],
                    m = o ? e.getObstructionStatusBySlice(d) : [];
                  let g, p, f, h;
                  for (c = 0; c < d; c++)
                    (h = r.y + u * c),
                      c == d - 1 && (u = r.y + r.height - h),
                      (s = { x: r.x, y: h, width: r.width, height: u }),
                      (g = a(n, i, s)),
                      (p = g / (s.width * s.height) == 1),
                      l.push(p);
                  if (o)
                    for (f = Fi.min(m.length, d), c = 0; c < f; c++)
                      l[c] = l[c] && !m[c];
                  return l;
                })(I, m, new ei(w).getRoundedGeometry(), C)))
              : (A = t.getConfig(y).defaultSliceArray);
          const M = {
            windowDimensions: I,
            containerDimensions: h,
            adDimensions: w,
            percentageInView: b,
            viewState: c(b),
            outOfViewReason: d(b) ? "" : $ || "l",
            detectionMethod: S,
            isObstructed: C,
            sliceStatus: A,
          };
          return Xe(p) && "" !== p && (M.omidObstructions = p), M;
        },
      };
    },
    Do = function (e, t, n, i) {
      "use strict";
      const r = "geometryMeasurementChanged";
      let o, s, a;
      const c = function () {
          if (Xe(o) && Xe(s)) {
            const e = i.calculateGeometricMeasurement(o, s);
            (e.isMeasurable = !0), (a = !0), n.trigger(r, e);
          }
        },
        d = function (e) {
          (o = e), c();
        },
        u = function (e) {
          (s = e), c();
        };
      return {
        start: function () {
          at
            .getAggregator()
            .trigger("addOutputItem", { output: "d" }, "mtp", {
              type: "impression",
            }),
            e.addAdContainerGeometryMeasurementChangedListener(d),
            e.start(),
            t.addAdGeometryMeasurementChangedListener(u),
            t.start();
        },
        addMeasurementChangedListener: function (e) {
          n.on(r, e);
        },
        getStrategyName: function () {
          return "display";
        },
        isMeasurable: function () {
          return a;
        },
      };
    },
    xo = function (e) {
      "use strict";
      const t = [];
      let n;
      const i = function (e, t) {
          const n = o(e, t),
            i = n.x - e.x,
            r = n.y - e.y,
            s = i + n.width,
            a = r + n.height;
          for (let t = Math.round(i); t < Math.round(s); t++)
            for (let n = Math.round(r); n < Math.round(a); n++)
              void 0 !== e.matrix[t] &&
                void 0 === e.matrix[t][n] &&
                ((e.matrix[t][n] = 1), (e.obscuredPixelCount += 1));
          return e;
        },
        r = function (e) {
          const t = Math.round(e.width),
            n = Math.round(e.height),
            i = new Array(t);
          let r = 0;
          for (; r < t; r++) i[r] = new Array(n);
          return {
            matrix: i,
            obscuredPixelCount: 0,
            x: Math.round(e.x),
            y: Math.round(e.y),
            width: t,
            height: n,
          };
        },
        o = function (e, t) {
          const n = Math.max(e.x, t.x),
            i = Math.max(e.y, t.y),
            r = Math.min(e.x + e.width, t.x + t.width) - n,
            o = Math.min(e.y + e.height, t.y + t.height) - i;
          return { x: n, y: i, width: r > 0 ? r : 0, height: o > 0 ? o : 0 };
        },
        s = function (e, t, n) {
          return e + (t - n);
        },
        a = function (e, t, n, i) {
          return e == t || n === i - 1;
        },
        c = function (t) {
          if (void 0 === t.matrix || 0 === t.matrix.length) return [];
          let n = 0,
            i = !1;
          const r = t.matrix[0].length,
            o = t.matrix.length,
            c = e.getConfig({ height: r }).numberOfSlices,
            d = Fi.floor(r / c) || 1,
            u = [];
          for (let e = 0; e < r; e++) {
            i = !1;
            for (let n = 0; n < o; n++)
              if (1 === t.matrix[n][e]) {
                i = !0;
                break;
              }
            n++,
              i && ((e = s(e, d, n)), (n = d)),
              a(n, d, e, r) && (u.push(i), (n = 0), (i = !1));
          }
          return u;
        };
      return {
        calculateObstructedArea: function (e, o) {
          const s = o && o.length > 0;
          let a,
            d = s ? r(e) : {},
            u = 0,
            l = 0;
          if (s) {
            for (; u < o.length; u++) (a = o[u]), (d = i(d, a));
            (l = d.obscuredPixelCount), (n = c(d));
          } else n = t;
          return l;
        },
        getObstructionStatusBySlice: function () {
          return n;
        },
      };
    },
    Po = function (e, t) {
      "use strict";
      const n = at.getAggregator().request("omidAdSessionContext");
      n.geometryChangeEvents = [];
      let i = null,
        r = !1;
      const o = zr(e),
        s = new ia();
      let a = !1,
        c = !1;
      const d = function (e, t) {
          const i = { videoEvent: e, screenEvent: t };
          (n.cachedVideoSegmentEvents = n.cachedVideoSegmentEvents || []),
            n.cachedVideoSegmentEvents.push(i),
            at.getAggregator().trigger("cachedOmidVideoSegmentEvent", i);
        },
        u = fo(function () {
          (n.delayingViewabilityEvents = !1), (r = !1), i && (l(i), (i = null));
        }),
        l = function (e) {
          if (!(e && "geometryChange" === e.type && e.data && e.data.adView))
            return;
          const o = e.data.adView;
          if (
            (o.onScreenGeometry &&
              o.onScreenGeometry.obstructions &&
              o.onScreenGeometry.obstructions.length > 0 &&
              ((o.onScreenGeometry.obstructions = po(
                o.geometry,
                o.onScreenGeometry.obstructions
              )),
              0 === o.onScreenGeometry.obstructions.length &&
                o.reasons.indexOf("obstructed") > -1 &&
                (o.reasons = o.reasons.filter((e) => "obstructed" !== e))),
            o.onScreenContainerGeometry &&
              o.onScreenContainerGeometry.obstructions &&
              o.onScreenContainerGeometry.obstructions.length > 0 &&
              ((o.onScreenContainerGeometry.obstructions = po(
                o.geometry,
                o.onScreenContainerGeometry.obstructions
              )),
              0 === o.onScreenContainerGeometry.obstructions.length &&
                o.reasons.indexOf("obstructed") > -1 &&
                (o.reasons = o.reasons.filter((e) => "obstructed" !== e))),
            e.internallyGenerated || (n.grnd = ho(o.reasons)),
            "audio" === n.creativeType && !e.internallyGenerated)
          )
            return;
          const c = a || e.treatAsCached;
          c &&
            (n.cachedGeometryEventsReceived ||
              (n.cachedFirstGeometricIndex = n.cachedEvents.length),
            (n.cachedGeometryEventsReceived = !0),
            n.cachedEvents.push(e));
          const d = !!(
            o.measuringElement &&
            o.containerGeometry &&
            o.onScreenContainerGeometry
          );
          o.hasOwnProperty("pixelsInView") && (n.pixelsInView = o.pixelsInView);
          const l = n.cachedStartEventIndex;
          if (
            !c &&
            n.unrecoveredPlayTime &&
            "number" == typeof l &&
            l > -1 &&
            o.percentageInView >= 50 &&
            "audio" !== n.creativeType
          ) {
            const e = Fi.now() - n.cachedEvents[l].timestamp,
              t = at.getAggregator().request("mScreenEvents");
            t && t.setRecoveredTimeInSlTimes && t.setRecoveredTimeInSlTimes(e);
          }
          if (
            (n.geometryChangeEvents.length < 10 &&
              (n.geometryChangeEvents.push(
                e.timestamp -
                  oe.measurementConfig.birthdate +
                  "." +
                  o.percentageInView
              ),
              at
                .getAggregator()
                .trigger(
                  "addOutputItem",
                  { output: n.geometryChangeEvents.join("_") },
                  "og"
                )),
            n.delayingViewabilityEvents)
          )
            (i = e), r || ((r = !0), u());
          else {
            const i = [];
            o.onScreenGeometry &&
              o.onScreenGeometry.obstructions &&
              o.onScreenGeometry.obstructions.length > 0 &&
              (!d ||
                (o.onScreenContainerGeometry.obstructions &&
                  0 !== o.onScreenContainerGeometry.obstructions.length) ||
                (o.onScreenContainerGeometry.obstructions =
                  o.onScreenGeometry.obstructions),
              o.reasons &&
                o.reasons.indexOf("obstructed") > -1 &&
                o.percentageInView < 100 &&
                ((o.onScreenGeometry.obstructions =
                  o.onScreenGeometry.obstructions.slice(0, 4)),
                o.onScreenGeometry.obstructions.forEach(function (e) {
                  i.push(
                    Math.round(e.x) +
                      "." +
                      Math.round(e.y) +
                      "." +
                      Math.round(e.width) +
                      "." +
                      Math.round(e.height)
                  );
                })));
            const r = zn.isOmidForWeb()
                ? oi.calcWinDims()
                : { width: 0, height: 0 },
              a = (function (e) {
                const t = new ei(e || {}).getRoundedGeometry();
                return {
                  width: ot(t.width) ? t.width : 0,
                  height: ot(t.height) ? t.height : 0,
                };
              })(e.data.viewport),
              c = 0 === a.width && 0 === a.height,
              u = !(
                !(
                  zn.isOmidForWeb() &&
                  c &&
                  0 === r.width &&
                  0 === r.height &&
                  o.percentageInView >= 50
                ) ||
                (o.reasons && 0 !== o.reasons.length)
              ),
              l = new ei(c ? r : e.data.viewport),
              m = new ei(
                d
                  ? o.containerGeometry
                  : o.geometry || { x: 0, y: 0, width: 0, height: 0 }
              ),
              g = new ei(
                d
                  ? o.onScreenContainerGeometry
                  : o.onScreenGeometry || { x: 0, y: 0, width: 0, height: 0 }
              ),
              p = {
                viewport: l.getRoundedGeometry(),
                originalAdContainer: m.getRoundedGeometry(),
                computedAdContainer: g.getRoundedGeometry(),
                percentageInView: o.percentageInView,
                detectionMethod: "o1",
                outOfViewReason: yo(o.reasons),
                omidObstructions: i.join("_"),
              };
            u && (p.preserveOmidViewabilityOnZeroViewportFallback = !0),
              void 0 === n.geometryArrived &&
                s.checkForViewAttachmentBasedOnAdSessionType(
                  n,
                  e.data.adView
                ) &&
                ((n.geometryArrived = !0),
                at.getAggregator().trigger("omidrendgeoupdate")),
              t.trigger("containerGeometryMeasurementChanged", p);
          }
        };
      n.processCachedEvents = function () {
        c ||
          (c = (function (e, t) {
            const n = "video" === e.mediaType,
              i = e.supports && e.supports.join().indexOf("clid") > -1,
              r = "limited" === e.accessMode,
              o = "full" === e.accessMode,
              s = r || (o && i),
              a = !n || e.cachedVideoEventsChecked,
              c = e.cachedGeometryEventsChecked;
            if (s && c && a && e.cachedEvents.length > 0) {
              let i,
                r = "o",
                o = "o",
                s = 0,
                a = 0,
                c = 0,
                u = !n,
                l = !0,
                m = !!e.loadedInFullscreen,
                g = !1;
              const p = Fi.now();
              let f;
              if (n) {
                const t = e.cachedStartEventIndex,
                  n = e.cachedFirstGeometricIndex;
                f = void 0 !== n ? e.cachedEvents[n] : void 0;
                const i = void 0 !== t ? e.cachedEvents[t] : void 0;
                f &&
                  i &&
                  f.timestamp > i.timestamp &&
                  (f.timestamp = i.timestamp);
              }
              for (let f = 0; f < e.cachedEvents.length; f++) {
                let f = p,
                  h = -1;
                for (let t = 0; t < e.cachedEvents.length; t++) {
                  const n = e.cachedEvents[t],
                    i = h > -1 ? e.cachedEvents[h] : void 0,
                    r = "geometryChange" === n.type,
                    o = "geometryChange" === i?.type;
                  !n.alreadyOrdered &&
                    (n.timestamp < f ||
                      (n.timestamp === f && (-1 === h || (r && !o)))) &&
                    ((f = n.timestamp), (h = t));
                }
                if (-1 === h) continue;
                const y = e.cachedEvents[h];
                y.alreadyOrdered = !0;
                const v = u;
                "geometryChange" === y.type && y.data && y.data.adView
                  ? ((s = y.data.adView.percentageInView),
                    (i =
                      (d = y.data.adView).geometry ||
                      d.onScreenGeometry ||
                      d.containerGeometry),
                    (g = !0))
                  : ((l = vo(y, l)),
                    "playerStateChange" === y.type &&
                      (m = "fullscreen" === y.data?.state),
                    Wr.includes(y.type)
                      ? (u = !0)
                      : Br.includes(y.type) && (u = !1)),
                  (o = (m || (s && s >= 50)) && u ? "i" : "o"),
                  "o" === r && "i" === o
                    ? (a = y.timestamp)
                    : "i" === r && "o" === o
                    ? (c += y.timestamp - a)
                    : "i" === r &&
                      "i" === o &&
                      ((c += y.timestamp - a), (a = y.timestamp)),
                  (r = o),
                  n && t(y, So(s, "complete" === y.type ? v : u, l, i, m));
              }
              if (
                ("i" === r
                  ? (c += p - a)
                  : n &&
                    !g &&
                    void 0 !== e.cachedStartEventIndex &&
                    (e.unrecoveredPlayTime = !0),
                c > 0)
              ) {
                "audio" === e.creativeType &&
                  (c = Math.min(c, p - f.timestamp)),
                  (e.recoveredTime = c);
                const t = at.getAggregator().request("mScreenEvents");
                t &&
                  t.setRecoveredTimeInSlTimes &&
                  (t.setRecoveredTimeInSlTimes(c), (e.recoveredTime = -1));
              }
              return !0;
            }
            var d;
            return !1;
          })(n, d));
      };
      return {
        start: function () {
          (a = !0),
            void 0 !== n.impressionViewabilityMeasurement &&
              l(n.impressionViewabilityMeasurement),
            o.addEventListener("geometryChange", l),
            (a = !1),
            (n.cachedGeometryEventsChecked = !0),
            n.cachedGeometryEventsReceived && n.processCachedEvents(),
            at.getAggregator().on("internallyGeneratedGeometryEvent", l);
        },
        addAdContainerGeometryMeasurementChangedListener: function (e) {
          t.on("containerGeometryMeasurementChanged", e);
        },
        translateOmidOutOfViewReasons: yo,
      };
    },
    No = function () {
      "use strict";
      const e = at.getAggregator().request("omidAdSessionContext");
      return {
        accepts: function () {
          return e && (e.isNative || e.isLimitedSandbox);
        },
      };
    },
    Vo = function (e, t) {
      "use strict";
      let n;
      const i = at.getAggregator().request("omidAdSessionContext");
      let r = null,
        o = !1;
      const s = zr(e),
        a = new ia(),
        c = fo(function () {
          (i.delayingViewabilityEvents = !1), (o = !1), r && (d(r), (r = null));
        }),
        d = function (e) {
          if (!(e && "geometryChange" === e.type && e.data && e.data.adView))
            return;
          if (
            (e.internallyGenerated || (i.grnd = ho(e.data.adView.reasons)),
            "audio" === i.creativeType && !e.internallyGenerated)
          )
            return;
          const s = e.data.adView;
          if (
            (s.onScreenGeometry &&
              s.onScreenGeometry.obstructions &&
              s.onScreenGeometry.obstructions.length > 0 &&
              ((s.onScreenGeometry.obstructions = po(
                s.geometry,
                s.onScreenGeometry.obstructions
              )),
              0 === s.onScreenGeometry.obstructions.length &&
                s.reasons.indexOf("obstructed") > -1 &&
                (s.reasons = s.reasons.filter((e) => "obstructed" !== e))),
            s.onScreenContainerGeometry &&
              s.onScreenContainerGeometry.obstructions &&
              s.onScreenContainerGeometry.obstructions.length > 0 &&
              ((s.onScreenContainerGeometry.obstructions = po(
                s.geometry,
                s.onScreenContainerGeometry.obstructions
              )),
              0 === s.onScreenContainerGeometry.obstructions.length &&
                s.reasons.indexOf("obstructed") > -1 &&
                (s.reasons = s.reasons.filter((e) => "obstructed" !== e))),
            i.delayingViewabilityEvents)
          )
            (r = e), o || ((o = !0), c());
          else {
            const r = e.data.adView.geometry,
              o = e.data.adView.containerGeometry,
              s = !!r,
              c = e.data.adView.measuringElement && !!o,
              d = new ei({
                x: s && c ? r.x - o.x : 0,
                y: s && c ? r.y - o.y : 0,
                width: s ? r.width : 0,
                height: s ? r.height : 0,
              }).getRoundedGeometry();
            (n = d),
              void 0 === i.geometryArrived &&
                a.checkForViewAttachmentBasedOnAdSessionType(
                  i,
                  e.data.adView
                ) &&
                ((i.geometryArrived = !0),
                at.getAggregator().trigger("omidrendgeoupdate")),
              t.trigger("omidGeometryChanged", { adGeometry: d, adFound: s });
          }
        };
      return {
        start: function () {
          void 0 !== i.impressionViewabilityMeasurement &&
            d(i.impressionViewabilityMeasurement),
            s.addEventListener("geometryChange", d),
            at.getAggregator().on("internallyGeneratedGeometryEvent", d);
        },
        addAdGeometryMeasurementChangedListener: function (e) {
          t.on("omidGeometryChanged", e);
        },
      };
    },
    Ro = function () {
      "use strict";
      const e = at.getAggregator().request("omidAdSessionContext");
      return {
        accepts: function () {
          return e && !e.isNative;
        },
      };
    },
    ko = function (e, t, n) {
      "use strict";
      let i;
      const r = function () {
        const t = e.find();
        let r,
          o,
          s,
          a = !1;
        Xe(t) && null !== t
          ? ((s = !0),
            (o = t.getBoundingClientRect()),
            (r = {
              x: o.x || o.left,
              y: o.y || o.top,
              width: o.width,
              height: o.height,
            }),
            t.hasOwnProperty("adWasClipped") && (r.adWasClipped = !0))
          : (i && ((a = !0), (r = { x: 0, y: 0, width: 0, height: 0 })),
            (s = !1)),
          ((s &&
            (function (e) {
              return !Xe(i) || !1 !== Ze(e).compareTo(i);
            })(r)) ||
            a) &&
            ((i = r),
            n.trigger("omidGeometryChanged", { adGeometry: r, adFound: s }));
      };
      return {
        start: function () {
          r(), t.setInterval(r, 50);
        },
        addAdGeometryMeasurementChangedListener: function (e) {
          n.on("omidGeometryChanged", e);
        },
      };
    },
    Fo = function (e, t, n, i, r) {
      "use strict";
      const o = "videoGeometryMeasurementChanged";
      let s,
        a,
        c,
        d,
        u,
        l = !1,
        m = !1;
      const g = function () {
          if (void 0 === a || void 0 === c || void 0 === d) return;
          u = !0;
          const e = r.calculateGeometricMeasurement(a, c),
            t = l && m,
            n = l && e.percentageInView >= 50,
            g = {
              windowDimensions: e.windowDimensions,
              containerDimensions: e.containerDimensions,
              adDimensions: e.adDimensions,
              percentageInView: e.percentageInView,
              detectionMethod: e.detectionMethod,
              isMeasurable: !0,
              isObstructed: e.isObstructed,
              sliceStatus: e.sliceStatus,
              isVideoPlaying: l,
              isVideoPlayingInFullscreen: t,
              isSoundOn: !0,
            },
            p = e.omidObstructions;
          Xe(p) && "" !== p && (g.omidObstructions = p),
            t && (g.percentageInView = 100),
            t || n
              ? (g.viewState = "inView")
              : ((g.viewState = "outOfView"),
                (g.outOfViewReason = e.outOfViewReason || "v")),
            (s = g),
            i.trigger(o, s);
        },
        p = function (e) {
          (a = e), g();
        },
        f = function (e) {
          (c = e), g();
        },
        h = function (e) {
          d = e;
          const t = e.eventType;
          "AdEnteredFullscreen" === t
            ? (m = !0)
            : "AdExitedFullscreen" === t
            ? (m = !1)
            : -1 !== "AdStarted|AdVideoStart|AdPlaying".indexOf(t)
            ? (l = !0)
            : -1 !==
                "AdSkipped|AdUserClose|AdPaused|AdVideoComplete|AdStopped|AdError".indexOf(
                  t
                ) && (l = !1),
            g();
        };
      return {
        start: function () {
          at
            .getAggregator()
            .trigger("addOutputItem", { output: "v" }, "mtp", {
              type: "impression",
            }),
            e.addAdContainerGeometryMeasurementChangedListener(p),
            e.start(),
            t.addAdGeometryMeasurementChangedListener(f),
            t.start(),
            n.addVideoPlaybackEventListener(h),
            n.start();
        },
        getStrategyName: function () {
          return "video";
        },
        addMeasurementChangedListener: function (e) {
          i.on(o, e);
        },
        isMeasurable: function () {
          return u;
        },
      };
    },
    jo = function (e, t, n) {
      "use strict";
      let i;
      const r = function () {
        const t = e.find();
        let r,
          o,
          s,
          a = !1;
        Xe(t)
          ? ((s = !0),
            (o = t.getBoundingClientRect()),
            (r = { x: o.left, y: o.top, width: o.width, height: o.height }),
            t.hasOwnProperty("adWasClipped") && (r.adWasClipped = !0))
          : (i && ((a = !0), (r = { x: 0, y: 0, width: 0, height: 0 })),
            (s = !1)),
          ((s &&
            (function (e) {
              return !Xe(i) || !1 !== Ze(e).compareTo(i);
            })(r)) ||
            a) &&
            ((i = r),
            n.trigger("omidGeometryChanged", { adGeometry: r, adFound: s }));
      };
      return {
        start: function () {
          r(), t.setInterval(r, 50);
        },
        addAdGeometryMeasurementChangedListener: function (e) {
          n.on("omidGeometryChanged", e);
        },
      };
    },
    Uo = function (e, t, n, i) {
      "use strict";
      return {
        accepts: function () {
          const r = e.mraid;
          return !(
            !n ||
            !(
              ("object" == typeof r && null !== r && !(r instanceof Array)) ||
              t ||
              i
            )
          );
        },
        isImmediate: function () {
          return !0;
        },
        supportsAdContainerGeometry: function () {
          return !1;
        },
        start: function () {},
      };
    },
    Lo = function (e, t, n) {
      "use strict";
      const i = !!n?.useLifecycleTracker,
        r = "mraidScreenLocationChanged",
        o = "mraid.js";
      let s,
        a = !1,
        c = !1,
        d = !1,
        u = !1,
        l = !1,
        m = 0;
      const g = function (e) {
          if ((s && (s.stop(), (s = void 0)), e))
            try {
              Ve(oe.mraidLifecycleTracker?.getSnapshot());
            } catch (e) {}
        },
        p = function () {
          try {
            if (d || l || u) return;
            u = !0;
            const e = { x: 0, y: 0, width: 0, height: 0 };
            t.trigger(r, {
              windowDimensions: e,
              adDimensions: e,
              containerDimensions: e,
              shouldDelegateToDomBasedViewability: !0,
              isMeasurable: !0,
              isObstructed: !1,
              isHidden: !1,
              percentageInView: 100,
              detectionMethod: "m",
              sliceStatus: [!0],
            }),
              Oe(() => {
                Ce("semfd", 1);
              });
          } catch (e) {}
        },
        f = function () {
          try {
            if (d) return void g(!1);
            const e = oe.mraidLifecycleTracker,
              t = e?.getSnapshot();
            if (!t?.active) return void g(!1);
            e?.refreshPending(), (m += 1), m >= 10 && g(!0);
          } catch (e) {
            g(!1);
          }
        },
        h = function (n) {
          let o, s, a;
          try {
            if (i) {
              o = (void 0 !== n ? n : e.mraid.isViewable()) ? 100 : 0;
            } else o = e.mraid.isViewable() ? 100 : 0;
            const d = { x: 0, y: 0, width: 0, height: 0 };
            if (
              ((a = 100 === o ? [!0] : [!1]),
              (s = {
                windowDimensions: d,
                adDimensions: d,
                containerDimensions: d,
                shouldDelegateToDomBasedViewability: !1,
                isMeasurable: !0,
                isObstructed: !1,
                isHidden: !1,
                percentageInView: o,
                detectionMethod: "m",
                sliceStatus: a,
              }),
              t.trigger(r, s),
              !l &&
                "eligible" ===
                  oe.mraidLifecycleTracker?.getSnapshot().eligibility)
            ) {
              l = !0;
              try {
                (c = zn.getTagTime()),
                  Oe(() => {
                    Ce("semac", 1), Ce("semme", 1), Ce("semmt", c);
                  });
              } catch (e) {}
            }
            return !0;
          } catch (e) {}
          var c;
          return !1;
        },
        y = function () {
          try {
            const t = e.mraid;
            (a = !0),
              h(),
              Je(t?.addEventListener) &&
                t.addEventListener("viewableChange", h);
          } catch (e) {}
        },
        v = function () {
          try {
            const t = e.mraid;
            (function () {
              const t = e.mraid;
              return (
                "object" == typeof t &&
                null !== t &&
                !(t instanceof Array) &&
                Je(t.isViewable)
              );
            })() &&
              ((c = !0),
              Je(t?.getState) && "loading" === t.getState()
                ? Je(t?.addEventListener) &&
                  t.addEventListener("ready", function () {
                    y();
                  })
                : y());
          } catch (e) {}
        },
        S = function () {
          c || v();
        },
        b = function () {
          if (!i) return !1;
          let e = "tracker_unavailable";
          try {
            const t = oe.mraidLifecycleTracker;
            t?.refresh("handoff");
            const n = t?.getSnapshot();
            if (t && "eligible" === n?.eligibility) {
              const i = (e) => {
                try {
                  if (d) return;
                  h(e) &&
                    ((d = !0),
                    u &&
                      Oe(() => {
                        Ce("semtt", 1);
                      }),
                    g(!0));
                } catch (e) {}
              };
              t.subscribe({
                onUsable: () => {
                  i();
                },
                onViewableChange: (e) => {
                  d ? h(e) : i(e);
                },
              }),
                (e =
                  "usable" === n.availability
                    ? "none"
                    : `pending_${n.availability}`),
                "usable" === n.availability &&
                  (i(), d || (e = "activation_failed")),
                d || (p(), s || ((m = 0), (s = $n(f, 500)), s.start()));
            } else e = "tracker_inactive";
            try {
              xe(n, !0, e, zn.getTagTime());
            } catch (e) {}
          } catch (t) {
            e = "tracker_error";
            try {
              xe(void 0, !1, e, zn.getTagTime());
            } catch (e) {}
          }
          return !0;
        };
      return {
        start: function () {
          b() ||
            (!(function () {
              let t = !0;
              return (
                (Xe(e.mraid) || oi.containsScriptTagWithSrc(o)) && (t = !1),
                at
                  .getAggregator()
                  .trigger("addOutputItem", { output: Qe(t) }, "mi", {
                    type: "impression",
                  }),
                t
              );
            })()
              ? v()
              : at.getAggregator().trigger("exec", o, S));
        },
        addScreenLocationChangedListener: function (e) {
          t.on(r, e);
        },
      };
    },
    qo = function (e, t, n) {
      "use strict";
      const i = {};
      return (
        n &&
          Ze(n).map(function (n, r) {
            i[n] = (function (n) {
              let i = nt;
              return (
                t.bootstrapOn("useViewabilityNotification") &&
                  (i = function () {
                    e.skipAsFraudulent() ||
                      at.getAggregator().trigger("notify", n);
                  }),
                i
              );
            })(r);
          }),
        {
          getCallbacks: function () {
            return i;
          },
        }
      );
    },
    Wo = function () {
      "use strict";
      const t = new Jo({ tiv: [1e4] }),
        n = ["inView", "partialViewPlus"];
      return {
        timeInViewThresholds: t,
        type: "pf",
        rts: {},
        isInView: function (e) {
          const t = Fi.max(e.fullPercentInView || 0, e.percentInView);
          return -1 !== n.indexOf(e.viewState) && 100 === t;
        },
        applies: function (t, n) {
          return (
            t.on("abcAudit") &&
            925955 == e.anId &&
            n.usesIASFullyInViewCustomMetric()
          );
        },
        minUnit: 1e3,
        shouldIncludeSound: !1,
      };
    },
    Bo = function (t, n) {
      "use strict";
      let i, r, o;
      const s = t.on("everySecond"),
        a = n.isVideo(),
        c = [
          1e3, 2e3, 3e3, 4e3, 5e3, 6e3, 7e3, 8e3, 9e3, 1e4, 11e3, 12e3, 13e3,
          14e3, 15e3,
        ],
        d = [1e3, 5e3, 15e3, 3e4, 45e3, 6e4, 9e4],
        u = [2e3, 5e3, 15e3],
        l = function (e, t) {
          return (
            -1 !==
            "inView|partialViewPlus".indexOf(
              e[t ? "viewStateIgnoringRender" : "viewState"]
            )
          );
        };
      return (
        s
          ? ((i = new Jo({ tiv: c })), (r = c[0]))
          : a
          ? ((i = new Jo({ tiv: u })), (r = u[0]))
          : ((i = new Jo({ tiv: d })), (r = d[0])),
        (o = { 5e3: e._onInViewMRC5, 15e3: e._onInViewMRC15 }),
        (o[r] = e._onInViewMRC),
        {
          timeInViewThresholds: i,
          type: "p",
          rts: o,
          isInView: l,
          isInViewIgnoringRender: function (e) {
            return l(e, !0);
          },
          applies: !0,
          minUnit: 1e3,
          shouldIncludeSound: !1,
          sendOtherwiseInViewSignal: !0,
        }
      );
    },
    Go = function (e, t) {
      "use strict";
      let n;
      const i = e.on("everySecond"),
        r = t.isVideo(),
        o = t.usesIASFullyInViewCustomMetric(),
        s = function (e) {
          const t = Fi.max(e.fullPercentInView || 0, e.percentInView);
          return (
            -1 !== "inView|partialViewPlus".indexOf(e.viewState) && 100 === t
          );
        };
      return (
        (n = new Jo(
          i
            ? {
                tiv: [
                  1e3, 2e3, 3e3, 4e3, 5e3, 6e3, 7e3, 8e3, 9e3, 1e4, 11e3, 12e3,
                  13e3, 14e3, 15e3,
                ],
              }
            : r
            ? { tiv: [2e3, 5e3, 15e3] }
            : { tiv: [1e3, 5e3, 15e3] }
        )),
        at
          .getAggregator()
          .provide("isFullyInViewProvider", { isFullyInView: s }),
        {
          timeInViewThresholds: n,
          type: "pf",
          isInView: s,
          applies: function () {
            return o;
          },
          minUnit: 1e3,
          shouldIncludeSound: !1,
        }
      );
    },
    Ho = function (t, n) {
      "use strict";
      return {
        timeInViewThresholds: new Jo({ tiv: [0] }),
        type: "pf",
        rts: { 0: e._onInViewFull },
        isInView: function (e) {
          const t = Fi.max(e.fullPercentInView || 0, e.percentInView);
          return (
            -1 !== "inView|partialViewPlus".indexOf(e.viewState) && 100 === t
          );
        },
        applies: function () {
          return n.usesGroupMCustomMetric();
        },
        minUnit: 1e3,
        shouldIncludeSound: !1,
      };
    },
    Yo = /^q[1-4](?:\|q[1-4])*:(?:[1-9]\d*|(?:[1-9]\d?|100)%)$/i,
    zo = function (t, n) {
      "use strict";
      let i, r, o;
      const s = Number.MAX_VALUE,
        a = n.isVideo();
      let c;
      const d = t.id,
        u = t.sound && "on" === t.sound,
        l =
          !(
            t.soundExcl &&
            "groupm_native" === t.soundExcl &&
            e.groupm_native_publisher
          ) && u,
        m = t.qiv || [];
      let g, p, f;
      const h = function () {
          (g = []), (p = []), (f = !1);
          let e = !1;
          m.forEach(function (t) {
            if (a && "string" == typeof t) {
              f = !0;
              const n = (function (e) {
                if ("string" != typeof e || !Yo.test(e)) return;
                const t = e.split(":"),
                  n = t[1],
                  i = -1 !== n.indexOf("%"),
                  r = t[0]
                    .split("|")
                    .map((e) =>
                      Number.parseInt(e.toLowerCase().replace("q", ""), 10)
                    ),
                  o = Number.parseInt(n.replace("%", ""), 10);
                return {
                  segments: r,
                  requirement: n,
                  requirementType: i ? "percentage" : "seconds",
                  requirementValue: o,
                };
              })(t);
              n ? p.push(n) : (e = !0);
            } else "number" == typeof t && g.push(t);
          });
          const t = f && g.length > 0;
          (e || t) && ((p = []), (g = []));
        },
        y = function (e, n) {
          if (!e.adDimensions) return !1;
          const i = n ? "percentInViewIgnoringRender" : "percentInView";
          let r, o, c;
          const d = e.adDimensions.area(),
            u = 1 === e.tabHidden,
            m = Fi.max(e.fullPercentInView || 0, e[i]),
            g = t.thresholds.find(function (e) {
              if (((r = e.lb || 0), (o = e.ub || s), d >= r && d <= o))
                return !0;
            });
          return (
            (c = !u && m >= g.piv),
            (function (e) {
              return "s" == e.method;
            })(e) &&
              (function (e) {
                return 0 === e.tiv;
              })(t) &&
              (c = !1),
            a && ((c = c && e.isVideoPlaying), l && (c = c && e.isSoundOn)),
            c
          );
        };
      return (
        h(),
        (function () {
          const e = f || p.length > 0;
          i = new Jo(e ? {} : t);
        })(),
        (r = g.length > 0 && 0 === p.length ? g : void 0),
        (function () {
          let t, n;
          (o = {}),
            Xe(e.rts) &&
              Xe(e.rts[d]) &&
              ((t = i && Je(i.getTimeThresholds) && i.getTimeThresholds()[0]),
              (n = Xe(t)
                ? Je(t.getTimeInViewForRts) && t.getTimeInViewForRts()
                : "qiv"),
              (o[n] = e.rts[d]));
        })(),
        (c = t.minunit ? 1e3 * t.minunit : 1e3),
        {
          timeInViewThresholds: i,
          qivThreshold: r,
          type: "c",
          rts: o,
          isInView: y,
          isInViewIgnoringRender: function (e) {
            return y(e, !0);
          },
          metricId: d,
          minUnit: c,
          thresholdType: t.thresholdType,
          videoPlaybackSegmentRequirements: p,
          shouldIncludeSound: l,
          sendOtherwiseInViewSignal: !0,
        }
      );
    },
    Xo = function (e, t, n) {
      "use strict";
      const i = "groupmCM",
        r = t.isVideo() ? "video" : "display",
        o = t.isMobileApp() ? "app" : "web",
        s = t.isDeviceTypeGroupMobile() ? "mobile" : "desktop",
        a =
          e.customViewability instanceof Array &&
          e.customViewability.length > 0,
        c = n.on("customMetric"),
        d = n.on(i),
        u = function (e) {
          let t;
          const n = -1 !== e.mediaTypes.indexOf(r),
            a = -1 !== e.distributionChannels.indexOf(o),
            c = !Xe(e.deviceGroups) || -1 !== e.deviceGroups.indexOf(s);
          return (
            (t = !zi.contains(e.id, "fiv")),
            zi.contains(e.id, i) && (t = d),
            t && n && a && c
          );
        };
      return {
        resolve: function () {
          const t = [];
          let n;
          return (
            c &&
              a &&
              ((n = e.customViewability.filter(u)),
              n.forEach(function (e) {
                t.push(e);
              })),
            t
          );
        },
      };
    },
    Jo = function (e) {
      "use strict";
      const t = 1e3,
        n = [];
      if (e.tiv instanceof Array)
        e.tiv.forEach(function (e) {
          n.push(new Qo(e));
        });
      else if ("string" == typeof e.tiv) {
        const i = e.tiv.split("|");
        if (2 === i.length) {
          const e = new Ko();
          n.push(new Zo(e, parseInt(i[1].replace("%")))),
            n.push(new Qo(parseInt(i[0]) * t));
        } else n.push(new Qo(parseInt(e.tiv) * t));
      } else Xe(e.tiv) && n.push(new Qo(e.tiv * t));
      return {
        getTimeThresholds: function () {
          return n;
        },
      };
    },
    Ko = function () {
      "use strict";
      let e =
        at.getAggregator().request("omidAdSessionContext").adDuration || -1;
      const t = function (t) {
          if (n()) return;
          const i = Xe(t.ad_duration) ? t.ad_duration : t.adRemainingTime;
          (function (e) {
            return void 0 !== e && e > 0;
          })(i) && (e = Math.ceil(i));
        },
        n = function () {
          return e > 0;
        };
      return (
        at
          .getAggregator()
          .on({ omidAdDuration: t, adVideoStart: t, adDurationChange: t }),
        {
          getAdDuration: function () {
            return e;
          },
          isVideoDurationResolved: n,
        }
      );
    },
    Qo = function (e) {
      "use strict";
      let t,
        n = 0;
      return (
        e > 0 && (n = e / 1e3),
        (t = 1e3 * n),
        {
          getTimeInViewInSeconds: function () {
            return n;
          },
          getTimeInViewForRts: function () {
            return t;
          },
        }
      );
    },
    Zo = function (e, t) {
      "use strict";
      let n = 0,
        i = !1;
      const r = function (e) {
        (n = 0), t > 0 && e > 0 && (n = Math.ceil(e * (t / 100)));
      };
      return (
        r(15),
        {
          getTimeInViewInSeconds: function () {
            return (
              !i &&
                e.isVideoDurationResolved() &&
                ((i = !0), r(e.getAdDuration())),
              n
            );
          },
          getTimeInViewForRts: function () {
            return 0;
          },
        }
      );
    },
    es = function (e, t, n, i) {
      "use strict";
      const r = i ? "isInViewIgnoringRender" : "isInView",
        o = function (i) {
          e[r](i) ? (t.mark(), n.doEligibleJobs(t.getTotalTime())) : t.stop();
        };
      return {
        start: function () {
          e.addMeasurementChangedListener(o);
        },
      };
    },
    ts = function (e, t, n, i) {
      "use strict";
      let r, o, s, a, c, d;
      const u = function (e, t) {
          return !t && e;
        },
        l = function (e, t, n, i) {
          let r = !1;
          return (r = !!i || (!t && (e || i) && n)), r;
        },
        m = function (e) {
          let u = 0;
          const m = 1 === e.tabHidden,
            p = e.isVideoPlaying,
            f = e.isSoundOn,
            h = e.isVideoPlayingInFullscreen;
          e.sliceStatus.forEach(function (e, t) {
            s(e, m, p, h) ? r[t].mark() : r[t].stop(),
              (a[t] = r[t].getTotalTime());
          }),
            g("slcVt", a),
            i &&
              (e.sliceStatus.forEach(function (e, t) {
                !(function (e, t, n, i, r) {
                  return l(e, t, n, i) && r;
                })(e, m, p, h, f)
                  ? o[t].stop()
                  : o[t].mark(),
                  (c[t] = o[t].getTotalTime());
              }),
              g("slcVtVol", c)),
            (d = i && t && t.shouldIncludeSound ? c : a);
          void 0 ===
            d.find(function (e) {
              return (u = Math.max(u, e)), e <= 0;
            }) && n.doEligibleJobs(u);
        },
        g = function (e, t) {
          const n = {};
          (n[e] = t),
            at
              .getAggregator()
              .trigger("addOutputItem", { output: n }, { minDt: !1 });
        },
        p = function (e) {
          void 0 !== e.sliceStatus &&
            (r ||
              (function (e) {
                !r &&
                  e.sliceStatus &&
                  ((r = []),
                  (o = []),
                  (a = []),
                  (c = []),
                  e.sliceStatus.forEach(function () {
                    r.push(new Tn(1)),
                      a.push(0),
                      i && (o.push(new Tn(1)), c.push(0));
                  }));
              })(e),
            m(e));
        };
      return {
        start: function () {
          (s = i ? l : u), e.addMeasurementChangedListener(p);
        },
      };
    },
    ns = function (e, t, n) {
      "use strict";
      return {
        isInView: e.isInView,
        isInViewIgnoringRender: e.isInViewIgnoringRender,
        addMeasurementChangedListener: function (e) {
          t.addMeasurementChangedListener(e, n);
        },
      };
    },
    is = function (e, t, n, i, r, o, s, a, c, d) {
      "use strict";
      const u = "measurementChanged";
      let l = !1;
      const m = zn.isVideo(),
        g = o.request("mobileApp"),
        p = Wt().applies(n, r),
        f = n.browserIs("g") || p,
        h = zn.xDomainIframe && !f,
        y = new wn(10),
        v = function () {
          r.on("viewabilityready") &&
            !l &&
            (i.send("v"), o.trigger("measurable"), (l = !0));
        };
      o.on("delayedViewabilityReady", function () {
        S(), v();
      }),
        o.on("delayedViewabilityReadyCallOnly", v);
      const S = function (n) {
        n = n || !1;
        try {
          let i;
          y.start(),
            t.hasMeasurementStrategy()
              ? (i =
                  (g.isMobileAppEnvironment() || zn.isOmidNative()) &&
                  t.supportsAdContainerGeometry()
                    ? t.getScreenLocationInfo({}, n)
                    : t.getScreenLocationInfo(a.collect(), n))
              : ((i = a.collect()),
                g.isMobileAppEnvironment()
                  ? ((i.viewState = "na"),
                    (i.method = "na"),
                    (i.percentInView = "na"))
                  : h && ((i.viewState = "na"), (i.percentInView = -1)),
                m && d.setVideoSpecificScreenEventFields(i));
          const r = c.registerLocation(i);
          n || e.trigger(u, i), y.stop();
          const o = Fi.round(y.getTime() / y.getCount());
          return s.addItem({ output: o }, "lt", { type: "u" }), r;
        } catch (e) {
          o.trigger("error", "V");
        }
      };
      return {
        checkScreenLoc: S,
        stringifyPingTimes: function () {
          let e;
          return (
            (e = r.on("everySecond")
              ? "1-2-3-4-5-6-7-8-9-10-11-12-13-14-15"
              : m
              ? "2-5-15"
              : "1-5-15"),
            e
          );
        },
        isImmediatelyMeasurable: function () {
          const e = zn.xDomainIframe,
            i = e && n.browserIs("w"),
            r = e && n.browserIs("e");
          let o = !i && !r && !(e && p);
          return (
            zn.isOmid() && (o = !0),
            g.isMobileAppEnvironment() ? t.isMeasurable() : o
          );
        },
        requiresDelayedViewabilityEvent: function () {
          g.isMobileAppEnvironment() &&
            t.hasMeasurementStrategy() &&
            t.requiresDelayedViewabilityEvent();
        },
        addMeasurementChangedListener: function (t) {
          e.on(u, t);
        },
      };
    },
    rs = {
      name: "viewabilityLoopLifecycle",
      dependencies: ["viewability", "features", "context", "browser"],
      creator: function (n, i, r, o) {
        "use strict";
        let s;
        const a = os(r),
          c = [new as(), new ss(a)],
          d = function (e) {
            "sessionFinish" === e.type &&
              (at
                .getAggregator()
                .trigger("addOutputItem", { output: zn.getTagTime() }, "osef"),
              at.getAggregator().trigger("adSessionComplete"));
          },
          u = function () {
            let e;
            const t = at
              .getAggregator()
              .request("mobileApp")
              .isMobileAppEnvironment();
            if (at.getAggregator().request("ids").impressionIsIdentifiable()) {
              if (
                ((s = $n(function () {
                  try {
                    oe.mraidLifecycleTracker?.refreshPending();
                  } catch (e) {}
                  n.checkScreenLoc();
                }, a.getPollingFrequency())),
                (e = c.find(function (e) {
                  return e.applies(o, i, r) ? e : void 0;
                })),
                e ? e.start(s) : s.start(!0),
                zn.isOmid())
              ) {
                at.getAggregator()
                  .request("omidVerificationClient")
                  .registerSessionObserver(d, "IAS");
              } else
                t
                  ? l("MOBILE_APP_TEST_EVENT_AD_SESSION_COMPLETE")
                  : (l("beforeunload"), m("pagehide"));
            }
          },
          l = function (e) {
            Jn.addEvent(
              t,
              e,
              function () {
                at.getAggregator().trigger("adSessionComplete");
              },
              !1
            );
          },
          m = function (e) {
            Jn.addEvent(
              t,
              e,
              function () {
                at.getAggregator().trigger("altAdSessionComplete"),
                  at.getAggregator().trigger("adSessionComplete");
              },
              !1
            );
          },
          g = function () {
            try {
              const e = oe.mraidLifecycleTracker;
              Ve(e?.getSnapshot()), e?.destroy();
            } catch (e) {}
            r.isVideo() && !r.isOmid() && p(),
              at.getAggregator().trigger("unload"),
              s && s.stop(),
              at.getAggregator().trigger("endAdSession"),
              at.getAggregator().trigger("stopAdTalk");
          },
          p = function () {
            const t = new Kn("m");
            at.getAggregator().trigger(
              "sendDt",
              t.callType,
              t.enumerator,
              function () {
                const t = {
                  id: e.videoId,
                  msg: "unloadComplete",
                  messageType: "misc",
                };
                Fi.getWindow().postMessage(JSON.stringify(t), "*");
              }
            );
          };
        at.getAggregator().once("startViewabilityLoop", u),
          at.getAggregator().once("adSessionComplete", g);
      },
      settings: { tier: 7 },
    },
    os = function (e) {
      "use strict";
      return {
        getPollingFrequency: function () {
          return e.isVideo() ? 200 : 100;
        },
        getOptimizedPollingFrequency: function () {
          return 1e3;
        },
      };
    },
    ss = function (e) {
      "use strict";
      const t = !0;
      let n, i, r, o, s;
      const a = function (c) {
          if (r && !s && c < 1)
            return (
              (s = !0),
              void Fi.setTimeout(function () {
                a(c);
              }, 1e3)
            );
          (o = c < 1),
            !i && o
              ? ((i = !0),
                n.updateFrequency(e.getOptimizedPollingFrequency(), t))
              : i &&
                !o &&
                ((i = !1), n.updateFrequency(e.getPollingFrequency(), t));
        },
        c = function (e) {
          a(e.percentInView);
        };
      return {
        applies: function (e, t, n) {
          const i = t.on("viewabilityOptimization");
          return (r = n.usesZeroPivCustomMetric()), i;
        },
        start: function (e) {
          (n = e),
            n.start(t),
            at.getAggregator().on("IOPivChange", a),
            at.getAggregator().on("newScreenEvent", c);
        },
      };
    },
    as = function () {
      "use strict";
      const e = !0;
      let t,
        n,
        i,
        r = !1;
      const o = function (s) {
          return i && !r && s < 1
            ? ((r = !0),
              void Fi.setTimeout(function () {
                o(s);
              }, 1e3))
            : (s < 1 ? (t || n.stop(e), (t = !0)) : t && ((t = !1), n.start(e)),
              t);
        },
        s = function () {
          n.start(e);
        };
      return {
        applies: function (e, t, n) {
          i = n.usesZeroPivCustomMetric();
          const r = Wt();
          return (
            t.on("viewabilityOptimization") &&
            r.applies(e, t, n) &&
            n.isDeviceTypeGroupMobile()
          );
        },
        start: function (t) {
          (n = t),
            n.start(e),
            at.getAggregator().on("IOPivChange", o),
            at.getAggregator().on("nodesAdded", s);
        },
      };
    },
    cs = function (i, r, o, s, a, c, d) {
      "use strict";
      let u, l, m, g, p, f, h, y, v;
      const S = oi.getElementsWindow(r),
        b =
          (at.getAggregator().provide("iframeCalculatorHelper", Rs(S)),
          Ds(r, s)),
        I = "data-integralas-id-" + (oe.adTag && oe.adTag.asid);
      let w = !1;
      const A = ei({}),
        $ = zn.isDeviceTypeGroupMobile(),
        T = zn.usesGroupMCustomMetricMobilePassThru();
      let E;
      const C = function () {
          if (!u) {
            u = b.calcDims(r, s, m);
            const t = e.autotagSizeSet && e.adWidth > 1 && e.adHeight > 1,
              n = oe && oe.adTag && oe.adTag.staticTagParams,
              i = n && n.w > 1 && n.h > 1;
            t && (u.set("width", e.adWidth), u.set("height", e.adHeight)),
              i && (u.set("width", n.w), u.set("height", n.h)),
              O() ? _(u) : "s" === o && u.treatAsPlaceholder();
          }
          return u;
        },
        O = function () {
          return "v" === o && zn.embedded;
        },
        _ = function (e) {
          const t = new ei(r).getRounded();
          try {
            e.set("width", t.width), e.set("height", t.height);
          } catch (e) {
            at.getAggregator().trigger("error", "F");
          }
        },
        M = function () {
          return !1;
        },
        D = function () {
          let e;
          const n = N(),
            r = b.getClippedDims && (O() || zn.isCeltra());
          return (
            n
              ? (l = m.getPiv())
              : void 0 === l &&
                ((e =
                  !$ &&
                  (zn.friendly || Xe(t.mozInnerScreenX)) &&
                  a.on("offscreen")),
                (y = C()),
                (h = new ei(oi.calcWinDims())),
                (f = new ei(e ? oi.calcMonDims() : {})),
                (v = r ? b.getClippedDims() : A),
                (l = i.calcPercentInView(y, h, f, v))),
            l
          );
        },
        x = function () {
          return i.calcInitialViewState(D());
        },
        P = function () {
          return r !== t && C().isHidden();
        },
        N = function () {
          const e = !!m,
            t = zn.xDomainIframe && w,
            n = $ && w && m.isReady(),
            i = zn.isPageOnShadowDomWhitelist();
          return e && (i || t || n);
        };
      return (
        (function () {
          const e = Fi.getWindow(),
            t = Fi.getDoc(),
            n = r === e,
            s = t.body,
            a = at.getAggregator(),
            c = new Wt(),
            u = a.request("browser"),
            l = a.request("features"),
            f = a.request("context"),
            h = !zn.xDomainIframe,
            y = n && s ? t.body : r;
          if (
            ((E = zn.friendlyIframe && !d ? e.frameElement : y),
            Jn.addEvent(y, "pointerdown", function (e) {
              at.getAggregator().trigger("adComponentPointerDown", e);
            }),
            Jn.addEvent(y, "pointerup", function (e) {
              at.getAggregator().trigger("adComponentPointerUp", e);
            }),
            Jn.addEvent(y, "click", function (e) {
              at.getAggregator().trigger("adComponentClicked", e);
            }),
            Jn.addEvent(window, "blur", function (e) {
              at.getAggregator().trigger("blur", e);
            }),
            Jn.addEvent(y, "touchstart", function (e) {
              at.getAggregator().trigger("adComponentTouchStart", e);
            }),
            Jn.addEvent(y, "touchend", function (e) {
              at.getAggregator().trigger("adComponentTouchEnd", e);
            }),
            Jn.addEvent(y, "mouseover", function (e) {
              at.getAggregator().trigger("adComponentMousedOver", e);
            }),
            Jn.addEvent(y, "mouseout", function (e) {
              at.getAggregator().trigger("adComponentMousedOut", e);
            }),
            c.applies(u, l, f))
          ) {
            if (((m = xr(r, h)), m.start(), (w = !0), T && "s" !== o)) {
              const e = new Xs(C().getRounded()),
                t = new ta(),
                n = new na(m.getObservedNode(), t);
              g = new Qs(e.getSlices(), n);
            }
          } else T && (p = new Zs(i));
        })(),
        {
          mark: function () {
            oi.setAttributeOf(E, I, "");
          },
          cleanup: function () {
            oi.removeAttributeOf(E, I);
          },
          isNode: function (e) {
            return r === e;
          },
          isHidden: P,
          isObstructed: M,
          getDims: C,
          getPercentInView: D,
          getLocationState: x,
          getOnPageViewability: function () {
            return P() ? "outOfView" : x();
          },
          getDetectionMethod: function () {
            return o;
          },
          getContainerDims: function () {
            return b.allowsOptimization ? u : ei(s);
          },
          refresh: function () {
            (u = void 0),
              (l = void 0),
              (f = void 0),
              (h = void 0),
              (y = void 0),
              (v = void 0),
              c &&
                (function () {
                  let e, i;
                  if (!zn.isDomless() && ((i = r.parentNode), i)) {
                    for (; r !== t && i && i !== n && !e; )
                      (e = i === s), (i = i.parentNode);
                    e || (s = r.parentNode);
                  }
                })();
          },
          getAdNode: function () {
            return r;
          },
          getSliceStatus: function () {
            let e;
            return (
              g && g.isReadyToMeasure()
                ? (e = g.getSliceStatus())
                : zn.friendly &&
                  p &&
                  Xe(y) &&
                  (e = p.getSliceStatus(y, h, f, v)),
              e
            );
          },
        }
      );
    },
    ds = function (e, t) {
      "use strict";
      let n,
        i = [];
      const r = function () {
          return i[0] && "s" === i[0].getDetectionMethod();
        },
        o = function (o, s, a, c, d) {
          const u = r() || 0 === i.length,
            l = cs(e, o, s, a, t, c, d);
          !(function () {
            let e;
            r() && ((e = i.shift()), e.cleanup(), (n = void 0));
          })(),
            i.push(l),
            u && l.mark(),
            u && "s" !== s && at.getAggregator().trigger("primaryadfound", l);
        },
        s = function () {
          if (n) return n;
          let e,
            t = !1,
            r = 0,
            o = 0;
          return (
            i.forEach(function (n) {
              let i;
              const s = n.getDims();
              s.hasValidDims() &&
                ((e = n.getPercentInView()),
                (t = "na" !== e),
                (i = s.area()),
                (r += i),
                (o += (e / 100) * i));
            }),
            (n = { totalArea: r, totalInView: o, hasMeasurement: t }),
            n
          );
        },
        a = function (e) {
          const t = at.getAggregator().request("adRenderStatus");
          return !e && !t;
        },
        c = function (e) {
          let t;
          const n = s();
          return (
            (t = n.hasMeasurement
              ? Fi.round((n.totalInView / n.totalArea) * 100)
              : -1),
            (isNaN(t) || a(e)) && (t = 0),
            t
          );
        },
        d = function (n) {
          const i = t.bootstrapOn("mobOrTab"),
            r =
              s().totalArea >= 242500 && t.on("largeAd") && !i && !zn.isVideo();
          return e.calcInitialViewState(c(n), r);
        },
        u = function (e) {
          let t = -1;
          return (
            i.forEach(function (n, i) {
              n.isNode(e) && (t = i);
            }),
            t
          );
        },
        l = function (e) {
          return function () {
            return i[0] && i[0][e]();
          };
        },
        m = function (e) {
          Array.prototype.forEach.call(e, function (e) {
            const t = -1 === u(e),
              n =
                "object" == typeof e &&
                "IMG" === e.nodeName &&
                1 === e.height &&
                1 === e.width;
            t && !n && o(e, "c");
          });
        };
      return (
        at.getAggregator().on("adComponentAdded", m),
        at.getAggregator().on("adComponentRemoved", function (e) {
          Array.prototype.forEach.call(e, function (e) {
            const t = u(e);
            t > -1 && i.splice(t, 1);
          });
        }),
        {
          addNodeToAdComponents: m,
          getDims: l("getDims"),
          isObstructed: l("isObstructed"),
          getDetectionMethod: l("getDetectionMethod"),
          getContainerDims: l("getContainerDims"),
          getViewState: d,
          getViewStateIgnoringRender: function () {
            return d(!0);
          },
          getPercentInView: c,
          getPercentInViewIgnoringRender: function () {
            return c(!0);
          },
          isHidden: l("isHidden"),
          isUsingPlaceholder: r,
          hasAd: function () {
            return !!i.length;
          },
          refresh: function () {
            (n = void 0),
              i.forEach(function (e) {
                e.refresh();
              });
          },
          addAdComponent: o,
          clearCollection: function () {
            i.forEach(function (e) {
              e.cleanup();
            }),
              (i = []),
              (n = void 0);
          },
          getOutOfViewReasons: function (e) {
            let t;
            const r = [],
              o = i[0];
            return (
              o &&
                ((t = n || d()),
                a(e)
                  ? r.push("r")
                  : ("outOfView" !== t && "partialViewMinus" !== t) ||
                    r.push("l"),
                o.isHidden() && r.push("h"),
                o.isObstructed() && r.push("o")),
              r
            );
          },
          getComponentCount: function () {
            return i.length;
          },
          getComponents: function () {
            return i;
          },
          getSliceStatus: l("getSliceStatus"),
        }
      );
    },
    us = function () {
      "use strict";
      let e, t, n;
      const i = function (e) {
        e
          ? e &&
            n &&
            (Fi.execAtEndOfThread(function () {
              at.getAggregator().trigger("delayedViewabilityReadyCallOnly");
            }),
            (n = !1))
          : (n = !0);
      };
      return {
        detectionMethod: function () {
          return t && t.detectionMethod;
        },
        isApplicable: function (e) {
          return e.isBustedIframe();
        },
        find: function () {
          t = t || vs();
          const n = vs(),
            r = oi.crossQuerySelector(n.getCssSelector(), !0);
          return (e = r ? r.parentNode : e), i(r), r;
        },
        getAdContainer: function () {
          return e;
        },
        allowForAdContainerChange: !0,
        noIframeAdNode: function () {
          return t && t.noIframeAdNode;
        },
      };
    },
    ls = function (t, n) {
      "use strict";
      let i;
      const r = t || e.contextNode.parentNode,
        o = oi.findChildWithLargestContent(r, n);
      return oi.getNodeArea(o) > 1 && !o.iasdetector && (i = o), i;
    },
    ms = function () {
      "use strict";
      const e = at.getAggregator().request("omidAdSessionContext");
      return {
        usePlaceholder: !0,
        detectionMethod: "o1",
        isApplicable: function () {
          return zn.isOmidForWeb() && !zn.isOmidNative();
        },
        find: function () {
          return (
            e.element || e.queuedOutputItems.push({ code: "oea", value: !0 }),
            e.element
          );
        },
        getAdContainer: function () {
          return e.element && e.element.parentNode;
        },
        allowForAdContainerChange: !0,
      };
    },
    gs = function () {
      "use strict";
      return {
        detectionMethod: "i",
        find: function () {
          return t;
        },
        isApplicable: function () {
          return zn.embedded;
        },
        getAdContainer: function () {
          return e.contextNode.parentNode;
        },
        allowForAdContainerChange: !0,
      };
    },
    ps = function () {
      "use strict";
      let e;
      const t = Fi.getDoc().scripts,
        n = function () {
          return (
            e ||
              (e = Array.prototype.find.call(t, function (e) {
                return zi.contains(e.src, "servedby.flashtalking");
              })),
            e
          );
        };
      return {
        detectionMethod: "bf",
        isApplicable: function (e, t) {
          return t.on("bustediframe") && e.embedded && void 0 !== n();
        },
        getCssSelector: function () {
          let t;
          const i = (function () {
              let t;
              const i = e || n(),
                r = /;(\d+);/;
              return i && i.src && (t = i.src.match(r)[1]), t;
            })(),
            r = "#ftdiv" + i,
            o = "#ftframe" + i;
          try {
            t = [r, o].find(function (e) {
              return !!oi.crossQuerySelector(e, true);
            });
          } catch (e) {}
          return t;
        },
      };
    },
    fs = function () {
      "use strict";
      const e = "_tpi";
      return {
        isApplicable: function (t, n) {
          let i;
          try {
            i = oi.getFrameId();
          } catch (e) {}
          return (
            n.on("yieldmo") &&
            i &&
            zi.contains(i, e) &&
            oi.crossQuerySelector("[data-href*='ads.yieldmo.com']", !0)
          );
        },
        getCssSelector: function () {
          return "[id='" + oi.getFrameId().replace(e, "") + "']";
        },
        detectionMethod: "by",
      };
    },
    hs = function () {
      "use strict";
      let e, t;
      const n = Fi.getDoc(),
        i = function () {
          let t, i;
          const r = "ebDiv";
          return (
            e ||
              ((t = oi.querySelector(n, "div[id*='ebDiv']")),
              (i = t && t.id),
              (e = i && i.split(r)[1])),
            e
          );
        },
        r = function () {
          const e = oi.crossQuerySelector(
            "iframe[id*='ebAd'][id$='" + i() + "']",
            !0
          );
          return e && e.id;
        },
        o = function () {
          let e;
          return (
            t ||
              ((e = r()
                ? r()
                : (function () {
                    const e = oi.crossQuerySelector(
                      "iframe[id*='ebBannerIFrame_'][id$='" + i() + "']",
                      !0
                    );
                    return e && e.id;
                  })()),
              (t = e && "#" + e)),
            t
          );
        };
      return {
        detectionMethod: "bs",
        isApplicable: function (e, t) {
          const n = Fi.getWindow(),
            r = e.friendlyIframe && Fi.getWindow().frameElement,
            s = r && ei(r).isOneByOne(),
            a = (function () {
              const e = [
                  "bs.serving-sys.com/BurstingPipe/adServer",
                  "secure-ds.serving-sys.com/BurstingCachedScripts",
                ],
                t = Fi.getDoc().scripts;
              return Array.prototype.find.call(t, function (t) {
                return !!e.find(function (e) {
                  return zi.contains(t.src, e);
                });
              });
            })(),
            c = n.EBG && n.EBG.ads && Object.keys(n.EBG.ads).length > 0;
          return t.on("sizmek") && a && c && s && i() && o();
        },
        getCssSelector: o,
      };
    },
    ys = function () {
      "use strict";
      let e;
      const t = () => {
        const e = Fi.getWindow(),
          t = e.IAS_OGURY_CONFIG && e.IAS_OGURY_CONFIG.REVEAL_DIV_ID;
        return t ? "[id='" + t + "']" : "";
      };
      return {
        isApplicable: () => !!t(),
        getCssSelector: t,
        detectionMethod: "bo",
        find: () => {
          const t = Fi.getWindow(),
            n = t.IAS_OGURY_CONFIG && t.IAS_OGURY_CONFIG.REVEAL_DIV_ID;
          let i;
          if (n)
            try {
              const t = Fi.getTop();
              if (t && t.document) {
                const r = t.document.getElementById(n);
                (e = r || void 0), (i = e);
              }
            } catch (e) {}
          return i;
        },
        getAdContainer: () => e,
        allowForAdContainerChange: !1,
        noIframeAdNode: !0,
      };
    },
    vs = function () {
      "use strict";
      let e;
      const t = at.getAggregator().request("features");
      return (
        e || (e = [hs(), fs(), ys(), ps()]),
        e.find(function (e) {
          return e.isApplicable(zn, t);
        })
      );
    },
    Ss = function () {
      const t = e && e.contextNode,
        n = t && t.getAttribute && t.getAttribute("data-ias-container");
      if (!n || 0 !== n.indexOf("gcc_")) return;
      const i = oi.crossQuerySelector("#" + n);
      return i && oi.getNodeArea(i) < 1 ? i : void 0;
    },
    bs = function () {
      const e = Ss();
      return (
        e &&
        e.ownerDocument &&
        (oi.querySelector(e.ownerDocument, ".celtra-banner") || void 0)
      );
    },
    Is = function () {
      const e = bs();
      return e && oi.getNodeArea(e) >= 1 ? e : void 0;
    },
    ws = function () {
      const e = Ss();
      return !(!e || !oi.querySelector(e, ".celtra-ad-v3, .celtra-ad-v4"));
    },
    As = function () {
      "use strict";
      let e, t, n;
      const i = function () {
          t && (t.disconnect(), (t = void 0)),
            n && (n.disconnect(), (n = void 0));
        },
        r = function () {
          i(), at.getAggregator().trigger("celtraCreativeReady");
        },
        o = function () {
          Fi.execAtEndOfThread(function () {
            at.getAggregator().trigger("delayedViewabilityReadyCallOnly");
          });
        };
      return {
        get usePlaceholder() {
          return ws();
        },
        detectionMethod: "vc",
        isApplicable: function (e, t) {
          return ws() || (t.on("celtra") && e.isCeltra());
        },
        find: function () {
          let s;
          const a = $s().find();
          return (
            a &&
              a.celtra &&
              a.celtra.loaded &&
              (s = a.celtra.viewabilityObservee),
            !s && ws() && (s = Is()),
            s
              ? (i(),
                (e = oi.getElementsWindow(s).frameElement || s.parentNode),
                o())
              : (function () {
                  if (t || !ws()) return;
                  const e = function () {
                    const e = bs();
                    if (e && !n)
                      try {
                        (n = Fi.getResizeObserver(function () {
                          Is() && r();
                        })),
                          n.observe(e);
                      } catch (e) {
                        n = void 0;
                      }
                  };
                  try {
                    const n = Ss(),
                      i = n && n.ownerDocument && n.ownerDocument.body;
                    if (!i) return;
                    (t = Fi.getMutationObserver(function () {
                      Is() ? r() : e();
                    })),
                      t.observe(i, {
                        childList: !0,
                        subtree: !0,
                        attributes: !0,
                      }),
                      Is() ? r() : e();
                  } catch (e) {
                    i();
                  }
                })(),
            s
          );
        },
        getAdContainer: function () {
          return e;
        },
        allowForAdContainerChange: !1,
      };
    },
    $s = function () {
      "use strict";
      let t;
      const n = "celtra-ad-v3",
        i = "celtra-ad-v4",
        r = function () {
          let r;
          const o = e.contextNode.parentNode;
          return (
            o && (zi.contains(o.className, n) || zi.contains(o.className, i))
              ? (t = o)
              : ((r =
                  o &&
                  (oi.querySelector(o, ".celtra-ad-v3") ||
                    oi.querySelector(o, ".celtra-ad-v4"))),
                r && (t = r)),
            t
          );
        };
      return {
        find: r,
        isApplicable: function () {
          return void 0 !== r();
        },
      };
    },
    Ts = function () {
      "use strict";
      return {
        usePlaceholder: !0,
        detectionMethod: "a",
        isApplicable: at.getAggregator().request("mobileApp")
          .isMobileAppEnvironment,
        find: function () {
          return (function () {
            const e = oi.findChildWithLargestContent(Fi.getDoc().body);
            return e && e.hasValidSizeForMobileApp && !e.iasdetector
              ? e
              : void 0;
          })();
        },
        getAdContainer: function () {
          return e.contextNode.parentNode;
        },
        allowForAdContainerChange: !0,
      };
    };
  const Es = new (class {
      constructor() {
        this.cachedIsFoundOnPage = !1;
      }
      getDocument() {
        let e;
        try {
          e = Fi.getDoc();
        } catch (e) {}
        return e;
      }
      hasBrowserSupport() {
        let e = !1;
        const t = this.getDocument(),
          n = !zn.isDomless(),
          i = !(!t || "function" != typeof t.body.attachShadow);
        return n && i && (e = !0), e;
      }
      isFoundOnPage(e) {
        const t = Fi.getDoc(),
          n = e || t.body;
        let i = !1;
        if (this.cachedIsFoundOnPage) i = !0;
        else if (this.hasBrowserSupport())
          if (n.shadowRoot) (i = !0), (this.cachedIsFoundOnPage = !0);
          else {
            const e = n.querySelectorAll("*");
            for (let t = 0; t < e.length; t++) {
              const n = e[t];
              if (n && n.shadowRoot) {
                (i = !0), (this.cachedIsFoundOnPage = !0);
                break;
              }
            }
          }
        else i = !1;
        return i;
      }
      findElement({ root: e, selector: t }) {
        if ("matches" in e && e.matches?.(t) && e.matches(t)) return e;
        if ("shadowRoot" in e && e.shadowRoot) {
          const n = this.findElement({ root: e.shadowRoot, selector: t });
          if (n) return n;
        }
        for (const n of Array.from(e.children)) {
          const e = this.findElement({ root: n, selector: t });
          if (e) return e;
        }
        return null;
      }
      querySelector({ customRootElement: e, selector: t }) {
        const n = Fi.getDoc(),
          i = e || n.body;
        return this.findElement({ root: i, selector: t });
      }
    })(),
    Cs = function () {
      "use strict";
      let t,
        n = !1;
      const i = function (e) {
          const t =
            Je(e.contextNode.getAttribute) &&
            e.contextNode.getAttribute("data-ias-container");
          return (t && "#" + t) || e._cl_adpath;
        },
        r = function () {
          const t = at.getAggregator().request("features"),
            n = e && 4 === e.integration;
          return !t.on("forceKeepGoogleAdNode") || !n;
        },
        o = function () {
          const t = at.getAggregator().request("features");
          if (!t || !t.on("celtra") || !zn.isCeltra()) return;
          const n = oi.crossQuerySelector(i(e));
          if (n && oi.getNodeArea(n) >= 1) return;
          const r = $s().find(),
            o =
              r && r.celtra && r.celtra.loaded && r.celtra.viewabilityObservee;
          if (o && oi.getNodeArea(o) >= 1) return o;
          const s =
            n &&
            n.ownerDocument &&
            oi.querySelector(n.ownerDocument, ".celtra-banner");
          return s && oi.getNodeArea(s) >= 1 ? s : void 0;
        };
      return {
        getAdSelectorId: i,
        detectionMethod: "sp",
        isApplicable: function () {
          const e = ws();
          return zn.isSpecifiedAd() && !e;
        },
        find: function () {
          const s = i(e);
          let a = oi.crossQuerySelector(s);
          const c = zn.isPageOnShadowDomWhitelist(),
            d = (function (e) {
              return r() && oi.getNodeArea(e) < 1;
            })(a),
            u = o();
          return u
            ? ((n = !0),
              (t = oi.getElementsWindow(u).frameElement || oi.getParent(u)),
              u)
            : ((n = !1),
              a
                ? ((t = oi.getParent(a)),
                  d && ((t = a), (a = oi.findElementsWithSize(a))))
                : c &&
                  Es.isFoundOnPage() &&
                  ((a = Es.querySelector({ selector: s })),
                  (t = oi.getParent(a))),
              a);
        },
        getAdContainer: function () {
          return t;
        },
        get allowForAdContainerChange() {
          return !n;
        },
        shouldValidateAdNode: r,
      };
    },
    Os = function () {
      "use strict";
      let t;
      return {
        detectionMethod: "spc",
        isApplicable: function () {
          return zn.isCompoundAd();
        },
        find: function () {
          const n = [];
          var i;
          let r;
          return (
            ((i = e._cl_adpath), /\[(.*)\]/.exec(i)[1].split(",")).forEach(
              function (e) {
                (r = oi.crossQuerySelector(e)),
                  r &&
                    ((t = oi.getParent(r)),
                    oi.getNodeArea(r) < 1 &&
                      ((t = r), (r = oi.findElementsWithSize(r)))),
                  n.push(r);
              }
            ),
            n
          );
        },
        getAdContainer: function () {
          return t;
        },
        allowForAdContainerChange: !0,
      };
    },
    _s = function () {
      "use strict";
      return {
        usePlaceholder: !0,
        detectionMethod: "a",
        isApplicable: function () {
          return !0;
        },
        find: ls,
        getAdContainer: function () {
          return e.contextNode.parentNode;
        },
        allowForAdContainerChange: !0,
      };
    },
    Ms = function () {
      "use strict";
      return {
        detectionMethod: "v",
        find: at.getAggregator().request("video").findAdNode,
        isApplicable: zn.isVideo,
        getAdContainer: function () {
          return e.contextNode.parentNode;
        },
        allowForAdContainerChange: !0,
      };
    },
    Ds = function (e, t) {
      "use strict";
      let n;
      n = [Ns(), Ps(), xs()].find(function (n) {
        return n.isApplicable(e, t);
      });
      const i = Vs();
      return i.isApplicable(t) && (i.setBaseStrategy(n), (n = i)), n;
    },
    xs = function () {
      "use strict";
      return {
        calcDims: function (e, t) {
          let n, i;
          const r = new ei(e);
          return (
            oi.isClippable(e, t) &&
              ((n = oi.getClippedDimensions(e, t)),
              (i = r.getRounded()),
              r.set("height", n.height < i.height ? n.height : i.height || 1),
              r.set("width", n.width < i.width ? n.width : i.width || 1)),
            r
          );
        },
        allowsOptimization: !1,
        isApplicable: function (e) {
          const t =
              (zn.isSpecifiedAd() || zn.isBustedIframe()) &&
              oi.nodeIsInWindow(e, Fi.getTop()),
            n = !oi.elementIsEmbedded(e);
          return t || n;
        },
      };
    },
    Ps = function () {
      "use strict";
      const e = at.getAggregator().request("iframeCalculatorHelper");
      return {
        calcDims: e.calcDims,
        getClippedDims: e.getClippedDims,
        allowsOptimization: !0,
        isApplicable: function (e) {
          return (
            !(zn.isSpecifiedAd() || zn.isBustedIframe()) &&
            oi.elementIsEmbedded(e)
          );
        },
      };
    },
    Ns = function () {
      "use strict";
      const e = at.getAggregator().request("iframeCalculatorHelper");
      return {
        calcDims: function (t) {
          const n = at.getAggregator().request("features"),
            i = e.calcDims(),
            r = new ei(t).getRounded(),
            o =
              ws() || (n && n.on("celtra") && zn.isCeltra())
                ? (function (e) {
                    try {
                      const t = oi.getElementsWindow(e).frameElement;
                      if (!t) return 1;
                      const n = oi.getRect(t).width,
                        i = t.contentWindow && t.contentWindow.innerWidth;
                      if (!n || !i) return 1;
                      const r = n / i;
                      return r >= 0.05 && r <= 1 ? r : 1;
                    } catch (e) {
                      return 1;
                    }
                  })(t)
                : 1,
            s = 1 !== o && Ze.isNumeric(r.width) && Ze.isNumeric(r.height);
          return (
            i.set("height", s ? Fi.round(r.height * o) : r.height),
            i.set("width", s ? Fi.round(r.width * o) : r.width),
            i
          );
        },
        getClippedDims: e.getClippedDims,
        allowsOptimization: !1,
        isApplicable: function (e, t) {
          const n =
              (zn.isSpecifiedAd() || zn.isBustedIframe()) &&
              zn.embedded &&
              !oi.nodeIsInWindow(t, Fi.getTop()),
            i = (zn.isCeltra() || ws()) && oi.elementIsEmbedded(e);
          return n || i;
        },
      };
    },
    Vs = function () {
      "use strict";
      let e;
      return {
        calcDims: function (t, n, i) {
          let r = Xe(i) ? i.getAdNodeDimensions() : void 0;
          return e && void 0 === r && (r = e.calcDims(t, n)), r;
        },
        isApplicable: function (e) {
          const t = Wt(),
            n = at.getAggregator(),
            i = n.request("browser"),
            r = n.request("features"),
            o = n.request("context"),
            s = zn.isPageOnShadowDomWhitelist();
          return (o.isDeviceTypeGroupMobile() || s) && t.applies(i, r, o);
        },
        allowsOptimization: !1,
        setBaseStrategy: function (t) {
          e = t;
        },
      };
    },
    Rs = function (e) {
      "use strict";
      e = e || Fi.getWindow();
      const t = function (n, i) {
          let r;
          (n = n || e),
            (i = i || {
              top: 0,
              left: 0,
              width: Number.MAX_VALUE,
              height: Number.MAX_VALUE,
            });
          const o = n.parent.frames;
          let s = !1;
          for (let e = 0, t = o.length; e < t; e++)
            if (o[e] == n) {
              (r = o[e]), (s = !0);
              break;
            }
          if (s) {
            const e = oi.getRect(r.frameElement);
            (i.left += e.left), (i.top += e.top);
            try {
              (i.width = Fi.min(i.width, e.width)),
                (i.height = Fi.min(i.height, e.height));
            } catch (e) {
              at.getAggregator().trigger("error", "a");
            }
            n !== Fi.getTop() && t(n.parent, i);
          }
          return i;
        },
        n = function () {
          let n,
            i = {};
          try {
            (i = (function () {
              let n,
                i,
                r,
                o,
                s,
                a,
                c = Number.MAX_VALUE,
                d = Number.MAX_VALUE;
              return (
                zn.friendly
                  ? ((n = t()),
                    (r = n.left),
                    (o = n.top),
                    (c = n.width),
                    (d = n.height),
                    (i = oi.browserWindowPosition()),
                    (s = i.scrX + r),
                    (a = i.scrY + o))
                  : Xe(e.mozInnerScreenX) &&
                    ((s = Fi.round(e.mozInnerScreenX)),
                    (a = Fi.round(e.mozInnerScreenY))),
                {
                  scrX: s,
                  scrY: a,
                  iFrameClippingWidth: c,
                  iFrameClippingHeight: d,
                }
              );
            })()),
              (n = (function () {
                let t, n;
                return (
                  Xe(e.innerWidth)
                    ? ((t = e.innerWidth), (n = e.innerHeight))
                    : e.frameElement &&
                      Xe(e.frameElement.clientWidth) &&
                      ((t = e.frameElement.clientWidth),
                      (n = e.frameElement.clientHeight)),
                  { width: t, height: n }
                );
              })()),
              (i.height = n.height),
              (i.width = n.width);
          } catch (e) {
            at.getAggregator().trigger("error", "a");
          }
          return i;
        };
      return {
        calcDims: function () {
          return new ei(n());
        },
        getClippedDims: function () {
          const e = n();
          return new ei({
            scrX: e.scrX,
            scrY: e.scrY,
            width: e.iFrameClippingWidth,
            height: e.iFrameClippingHeight,
          });
        },
      };
    },
    ks = function () {
      "use strict";
      return {
        createInstance: function (e, t, n) {
          return zn.isDomless() ? new js() : new Fs(e, t, n);
        },
      };
    },
    Fs = function (i, r, o) {
      "use strict";
      let s, a;
      const c = at.getAggregator().request("browser"),
        d =
          e && e.contextNode && e.contextNode.parentNode
            ? e.contextNode.parentNode
            : null,
        u = ds(r, o),
        l = function () {
          let e, t, n, i;
          s =
            s ||
            (function (e, t) {
              const n =
                  oe &&
                  oe.measurementConfig &&
                  oe.measurementConfig.tagDeliveryType,
                i = e.isBustedIframe() && "i" === n,
                r = [Os(), Cs()],
                o = [ms(), Ts(), Ms(), us(), As(), gs()],
                s = r.concat(o);
              return (
                i ? s.unshift(_s()) : s.push(_s()),
                s.find(function (n) {
                  return n.isApplicable(e, t);
                })
              );
            })(zn, o);
          const r = s.find();
          zn.friendlyIframe && zn.isBlockingSizmekTag() && h(r),
            !r && s.usePlaceholder
              ? (m(), p())
              : r &&
                ((t = r instanceof Array ? r : [r]),
                (e = s.getAdContainer()),
                (n = s.allowForAdContainerChange),
                (i = s.noIframeAdNode && s.noIframeAdNode()),
                t.forEach(function (t) {
                  u.addAdComponent(t, rt(s.detectionMethod), e, n, i);
                }));
        },
        m = function () {
          let t;
          u.hasAd() ||
            ((t = oi.getPlaceholderSpan()),
            d.insertBefore(t, e.contextNode.nextSibling),
            u.addAdComponent(t, "s", oi.getParent(t)));
        },
        g = function (e, t) {
          let n = !1;
          e.forEach(function (e) {
            e.addedNodes && e.addedNodes.length > 0 && (n = !0);
          }),
            n && (at.getAggregator().trigger("nodesAdded"), t.disconnect());
        },
        p = function () {
          if (zn.isDeviceTypeGroupMobile() && c.hasMutationObserver()) {
            Fi.getMutationObserver(g).observe(d, { childList: !0 });
          }
        },
        f = function (e, t) {
          let n,
            i = !1;
          e.forEach(function (e) {
            switch (e.type) {
              case "childList":
                Array.prototype.forEach.call(e.addedNodes, function (e) {
                  e.nodeName &&
                    "script" === e.nodeName.toLowerCase() &&
                    (i = !0);
                });
                break;
              case "attributes":
                e.target.height * e.target.width <= 1 && (i = !0);
            }
          }),
            i &&
              ((n = hs()),
              n.isApplicable(zn, o) &&
                (t.disconnect(),
                (s = us()),
                u.clearCollection(),
                at.getAggregator().trigger("nodesAdded")),
              setTimeout(function () {
                n.isApplicable(zn, o) &&
                  (t.disconnect(),
                  (s = us()),
                  u.clearCollection(),
                  at.getAggregator().trigger("nodesAdded"));
              }, 0));
        },
        h = function (e) {
          let t, n;
          if (!a && c.hasMutationObserver() && oi.isWindow(e))
            try {
              (a = Fi.getMutationObserver(f)),
                (t = e && e.frameElement),
                (n = e && e.document && e.document.body),
                a.observe(t, {
                  attributes: !0,
                  attributeFilter: ["height", "width"],
                }),
                a.observe(n, { childList: !0, subtree: !0 });
            } catch (e) {}
        },
        y = function () {
          return u.isUsingPlaceholder() || !u.hasAd() ? l() : u.refresh(), u;
        };
      return (
        (function (e) {
          let i = !1;
          if (void 0 === t.MutationObserver) return;
          const r = new t.MutationObserver(function (e) {
              Fi.execAtEndOfThread(function () {
                i &&
                  e.forEach(function (e) {
                    e.addedNodes.length &&
                      at
                        .getAggregator()
                        .trigger("adComponentAdded", e.addedNodes),
                      e.removedNodes.length &&
                        at
                          .getAggregator()
                          .trigger("adComponentRemoved", e.removedNodes);
                  });
              });
            }),
            o = function () {
              (i = !0),
                Fi.setTimeout(function () {
                  i = !1;
                }, 40);
            };
          at.getAggregator().on("adComponentClicked", o),
            at.getAggregator().on("adComponentTouchEnd", o),
            at.getAggregator().on("adComponentMousedOver", o),
            at
              .getAggregator()
              .on("adComponentClicked", mo.adComponent.trackClick),
            at
              .getAggregator()
              .on("adComponentMousedOver", mo.adComponent.trackMouseOver),
            at
              .getAggregator()
              .on("adComponentMousedOut", mo.adComponent.trackMouseOut),
            at
              .getAggregator()
              .on("adComponentTouchEnd", mo.mobile.trackTouchEnd),
            at
              .getAggregator()
              .on("adComponentTouchStart", mo.mobile.trackTouchStart),
            at.getAggregator().on("blur", mo.adComponent.trackBlur),
            at
              .getAggregator()
              .on("adComponentPointerDown", mo.mobile.trackPointerDown),
            at
              .getAggregator()
              .on("adComponentPointerUp", mo.mobile.trackPointerUp),
            Jn.addEvent(t, "beforeunload", mo.finalizeAllCollectedData, !1),
            Jn.addEvent(t, "pagehide", mo.finalizeAllCollectedData, !1),
            Jn.whenReady(function () {
              try {
                r.observe(n.body, {
                  attributes: !0,
                  childList: !0,
                  characterData: !0,
                });
              } catch (t) {
                e.add("W");
              }
            }, Fi.getDoc());
        })(i),
        at.getAggregator().on("celtraCreativeReady", y),
        { find: y, getDetectionMethod: function () {} }
      );
    },
    js = function () {
      "use strict";
      const e = function () {
        return null;
      };
      return { find: e, getDetectionMethod: e };
    },
    Us = function (t) {
      "use strict";
      const n = new Hs(),
        i = new Ys();
      let r = Pn().getUserAgent().toLowerCase();
      const o = function () {
        const e = [
          "FBAN",
          "FBAV",
          "Twitter",
          "Instagram",
          "Flipboard",
          "Snapchat",
          "LinkedInApp",
          "Pinterest",
        ];
        let t,
          n = !1;
        for (t = 0; t < e.length; t++)
          if (r.indexOf(e[t].toLowerCase()) > -1) {
            (n = !0),
              at
                .getAggregator()
                .trigger(
                  "addOutputItem",
                  { output: e[t].substring(0, 2) },
                  "xlu",
                  { type: "impression" }
                );
            break;
          }
        return n;
      };
      return (
        (function () {
          let r = "";
          const s = at.getAggregator().request("omidAdSessionContext"),
            a = zn.isDomless() || (s && "app" === s.environment),
            c = s && "web" === s.environment,
            d = t.bootstrapOn("mobOrTab"),
            u = t.bootstrapOn("mobAppWebview"),
            l = t.bootstrapOn("app"),
            m = (d && u) || l;
          try {
            a || (!c && m && !o())
              ? ((r = n.detect()),
                n.hasDetectedMobileApp() &&
                  (("s_serv" !== r && "u_cars" !== r) ||
                    (zs[zs.length - 1].detectionRules.userAgent[0] = "/"),
                  i.detect(),
                  at
                    .getAggregator()
                    .trigger("addOutputItem", { output: "1" }, "mapp", {
                      type: "impression",
                    }),
                  at
                    .getAggregator()
                    .trigger("addOutputItem", { output: r }, "drul", {
                      type: "impression",
                    })))
              : c &&
                at
                  .getAggregator()
                  .trigger("addOutputItem", { output: "a_oweb" }, "drul", {
                    type: "impression",
                  });
          } catch (e) {
            at.getAggregator().trigger("error", "M");
          }
          try {
            Me() &&
              ((g = n.hasDetectedMobileApp()),
              (p = e.mapp),
              Oe(() => {
                const e = Te(g),
                  t = Te(p);
                Ce("semc", ve(e)),
                  void 0 !== e && void 0 !== t && Ce("semm", e === t ? 0 : 1);
              }));
          } catch (e) {}
          var g, p;
        })(),
        {
          excludedByUserAgent: o,
          isMobileAppEnvironment: function () {
            return n.hasDetectedMobileApp();
          },
          isSafeToInjectMraid: function () {
            return i.isSafeToInjectMraid();
          },
        }
      );
    },
    Ls = {
      url: {
        STRINGIFIED_METHOD: "u",
        detect: function (i) {
          "use strict";
          if (zn.isDomless()) return !1;
          const r = Fi.getWindow().location.href,
            o = [r];
          try {
            o.push(top.location.href);
          } catch (e) {}
          try {
            o.push(parent.location.href);
          } catch (e) {}
          if (zn.embedded) {
            try {
              o.push(parent.document.referrer);
            } catch (e) {}
            try {
              o.push(n.referrer);
            } catch (e) {}
          }
          try {
            "jsi" !== oe.adTag?.tagType && o.push(t.location.href);
          } catch (e) {}
          try {
            o.push(e.jsref);
          } catch (e) {}
          return (
            o.sort(function (e, t) {
              return e.length > t.length ? 1 : e.length < t.length ? -1 : 0;
            }),
            !!i.find(function (e) {
              let t,
                n,
                i = !1;
              const s = "mobfox" === e ? o : [r];
              for (n = 0; n < s.length; n++) {
                t = s[n];
                const r = "string" == typeof e ? [e] : e;
                if (r instanceof Array && r)
                  for (
                    let e = 0;
                    e < r.length && ((i = t.indexOf(r[e]) > -1), !1 !== i);
                    e++
                  );
                if (i) break;
              }
              return i;
            })
          );
        },
      },
      userAgent: {
        STRINGIFIED_METHOD: "a",
        detect: function (e) {
          "use strict";
          return (
            !zn.isDomless() &&
            !!e.find(function (e) {
              let t = !1;
              const n = Pn().getUserAgent();
              return "string" == typeof e && (t = -1 !== n.indexOf(e)), t;
            })
          );
        },
      },
      javascript: {
        STRINGIFIED_METHOD: "j",
        detect: function (e) {
          "use strict";
          return !!e.find(function (e) {
            let t = !1;
            return (t = Xe(zi.stringToProp(e))), t;
          });
        },
      },
      scriptSrc: {
        STRINGIFIED_METHOD: "s",
        detect: function (e) {
          "use strict";
          return (
            !zn.isDomless() &&
            !!e.find(function (e) {
              return oi.containsScriptTagWithSrc(function (t) {
                let n = !1;
                return (n = Xe(t) && -1 !== t.indexOf(e)), n;
              });
            })
          );
        },
      },
    },
    qs = function () {
      "use strict";
      return {
        process: function (e) {
          return Object.keys(e)
            .map((t) =>
              (function (e, t) {
                let n;
                const i = Ls[e];
                return i.detect(t) && (n = i.STRINGIFIED_METHOD), n;
              })(t, e[t])
            )
            .join("");
        },
      };
    },
    Ws = [
      {
        STRINGIFIED_APPDET: "omid",
        detectionRules: { javascript: ["omidSupported"] },
      },
      {
        STRINGIFIED_APPDET: "file",
        detectionRules: { url: ["file:"], scriptSrc: ["file:"] },
      },
      { STRINGIFIED_APPDET: "cont", detectionRules: { url: ["content:"] } },
      {
        STRINGIFIED_APPDET: "appl",
        detectionRules: { url: ["applewebdata:"] },
      },
      {
        STRINGIFIED_APPDET: "adma",
        detectionRules: { javascript: ["ADMARVEL"] },
      },
      {
        STRINGIFIED_APPDET: "admb",
        detectionRules: { userAgent: ["afma-sdk"], url: ["afma-sdk"] },
      },
      {
        STRINGIFIED_APPDET: "imbi",
        detectionRules: { javascript: ["InmobiObj"] },
      },
      {
        STRINGIFIED_APPDET: "mopb",
        detectionRules: {
          url: ["ads.mopub.com"],
          javascript: ["mopubFinishLoad"],
        },
      },
      {
        STRINGIFIED_APPDET: "pand",
        detectionRules: { javascript: ["PandoraApp"] },
      },
      {
        STRINGIFIED_APPDET: "sads",
        detectionRules: { javascript: ["mraid.sasSendMessage"] },
      },
      {
        STRINGIFIED_APPDET: "ogry",
        detectionRules: { url: ["ogury.io"], scriptSrc: ["OguryFR"] },
      },
      {
        STRINGIFIED_APPDET: "cnvt",
        detectionRules: {
          url: ["adsx.greystripe.com/openx/www/delivery/ia.php"],
        },
      },
      {
        STRINGIFIED_APPDET: "mobf",
        safeToInjectMraid: !0,
        detectionRules: { url: ["mobfox"] },
      },
      {
        STRINGIFIED_APPDET: "innr",
        detectionRules: { url: ["inner-active.mobi"] },
      },
      { STRINGIFIED_APPDET: "apnx", detectionRules: { javascript: ["anjam"] } },
      {
        STRINGIFIED_APPDET: "aers",
        detectionRules: { userAgent: ["AerServ"] },
      },
      {
        STRINGIFIED_APPDET: "tapj",
        detectionRules: { url: [["tapjoyads", "app_id"]] },
      },
      {
        STRINGIFIED_APPDET: "quan",
        detectionRules: { userAgent: ["QuantcastSDK"] },
      },
      {
        STRINGIFIED_APPDET: "cars",
        safeToInjectMraid: !0,
        detectionRules: {
          url: [
            ["carsales", ".android"],
            ["carsales", ".ios"],
          ],
        },
      },
      {
        STRINGIFIED_APPDET: "kkao",
        detectionRules: { userAgent: ["KAKAOTALK"] },
      },
      { STRINGIFIED_APPDET: "mrai", detectionRules: { javascript: ["mraid"] } },
    ],
    Bs = () => {
      const e = qs();
      for (const t of Ws)
        try {
          const n = e.process(t.detectionRules);
          if (n) return n + "_" + t.STRINGIFIED_APPDET;
        } catch {}
      return "";
    },
    Gs = () => {
      try {
        const e = zi.stringToProp("mraid");
        if (null == e) return "absent";
        if ("object" != typeof e || Array.isArray(e)) return "non_obj";
        const t = "function" == typeof e.getState,
          n = "function" == typeof e.addEventListener,
          i = "function" == typeof e.isViewable;
        return t && n && i ? "full" : "partial";
      } catch (e) {
        return "error";
      }
    },
    Hs = function () {
      "use strict";
      let t;
      const n = function (e) {
        let t;
        const n = qs().process(e.detectionRules);
        return n && (t = n + "_" + e.STRINGIFIED_APPDET), t;
      };
      return {
        detect: function () {
          return (
            (t = Ws.map(n).filter((e) => void 0 !== e)),
            (t = t.length > 0 ? t[0] : ""),
            "" === t &&
              e.hasOwnProperty("serverSideAppDetection") &&
              0 !== e.serverSideAppDetection.length &&
              (t = "s_serv"),
            t
          );
        },
        hasDetectedMobileApp: function () {
          return void 0 !== t && "" !== t;
        },
      };
    },
    Ys = function () {
      "use strict";
      const e = [];
      let t = [];
      const n = function (t) {
        let n;
        const i = qs().process(t.detectionRules);
        return i && (e.push(t.STRINGIFIED_SDK + "*" + i), (n = t)), n;
      };
      return {
        detect: function () {
          return (
            (t = zs.map(n).filter((e) => void 0 !== e)),
            t.length > 0 &&
              at.getAggregator().trigger(
                "addOutputItem",
                {
                  output: function () {
                    return e.join(".");
                  },
                },
                "sdk",
                { type: "impression" }
              ),
            t.length > 0
          );
        },
        isSafeToInjectMraid: function () {
          return (
            1 === t.length &&
            Xe(t[0].safeToInjectMraid) &&
            t[0].safeToInjectMraid
          );
        },
      };
    },
    zs = [
      {
        STRINGIFIED_SDK: "adma",
        safeToInjectMraid: !0,
        detectionRules: { javascript: ["ADMARVEL"], url: ["AdMarvel"] },
      },
      {
        STRINGIFIED_SDK: "admb",
        safeToInjectMraid: !0,
        detectionRules: { userAgent: ["afma-sdk"], url: ["afma-sdk"] },
      },
      {
        STRINGIFIED_SDK: "imbi",
        safeToInjectMraid: !0,
        detectionRules: { javascript: ["InmobiObj"] },
      },
      {
        STRINGIFIED_SDK: "mmed",
        detectionRules: { url: ["mmsdk"], scriptSrc: ["mmsyscache"] },
      },
      {
        STRINGIFIED_SDK: "mopb",
        safeToInjectMraid: !0,
        detectionRules: {
          javascript: ["mopubFinishLoad"],
          url: ["ads.mopub.com"],
        },
      },
      {
        STRINGIFIED_SDK: "pand",
        detectionRules: { javascript: ["PandoraApp"] },
      },
      {
        STRINGIFIED_SDK: "ambe",
        safeToInjectMraid: !0,
        detectionRules: { url: ["amobee"] },
      },
      {
        STRINGIFIED_SDK: "smat",
        safeToInjectMraid: !0,
        detectionRules: { javascript: ["smaato_bridge"] },
      },
      {
        STRINGIFIED_SDK: "afrm",
        safeToInjectMraid: !0,
        detectionRules: { javascript: ["Adform"] },
      },
      {
        STRINGIFIED_SDK: "vrve",
        safeToInjectMraid: !0,
        detectionRules: { javascript: ["vrvsdk"] },
      },
      {
        STRINGIFIED_SDK: "sads",
        detectionRules: {
          javascript: ["mraid.sasSendMessage"],
          url: ["smartadserver.com"],
        },
      },
      {
        STRINGIFIED_SDK: "ogry",
        safeToInjectMraid: !0,
        detectionRules: { url: ["ogury.io"], scriptSrc: ["OguryFR"] },
      },
      {
        STRINGIFIED_SDK: "cnvt",
        detectionRules: {
          url: ["adsx.greystripe.com/openx/www/delivery/ia.php"],
        },
      },
      {
        STRINGIFIED_SDK: "mobf",
        safeToInjectMraid: !0,
        detectionRules: { url: ["mobfox"] },
      },
      {
        STRINGIFIED_SDK: "innr",
        detectionRules: { url: ["inner-active.mobi"] },
      },
      { STRINGIFIED_SDK: "apnx", detectionRules: { javascript: ["anjam"] } },
      {
        STRINGIFIED_SDK: "aers",
        safeToInjectMraid: !0,
        detectionRules: { userAgent: ["AerServ"] },
      },
      {
        STRINGIFIED_SDK: "tapj",
        detectionRules: { url: [["tapjoyads", "app_id"]] },
      },
      {
        STRINGIFIED_SDK: "quan",
        detectionRules: { userAgent: ["QuantcastSDK"] },
      },
      { STRINGIFIED_SDK: "kkao", detectionRules: { userAgent: ["KAKAOTALK"] } },
      {
        STRINGIFIED_SDK: "mrad",
        safeToInjectMraid: !0,
        detectionRules: { userAgent: ["unmatchabledetectionstring"] },
      },
    ],
    Xs = function (e) {
      "use strict";
      const t = [],
        n = function (e, t, n) {
          return new ea(0, e, n, n + t);
        };
      return (
        (function () {
          if (e.height < 10)
            t.push({
              geometry: new ea(0, e.width, 0, e.height),
              percentageInViewContribution: 100,
              isInView: !1,
            });
          else {
            const i = Math.floor(e.height),
              r = i % 10,
              o = (i - r) / 10;
            let s;
            const a = 10;
            for (let i = 0; i < 10; i++) {
              const c = i < r ? o + 1 : o,
                d = {
                  geometry: n(e.width, c, s || 0),
                  percentageInViewContribution: a,
                  isInView: !1,
                };
              t.push(d), (s = d.geometry.value().bottomY);
            }
          }
        })(),
        {
          getSlices: function () {
            return t;
          },
        }
      );
    },
    Js = [0, 0.1, 0.2, 0.25, 0.3, 0.4, 0.5, 0.6, 0.7, 0.75, 0.8, 0.9, 1],
    Ks = function () {
      "use strict";
      let e = Js.length,
        t = Js;
      const n = [];
      let i;
      return {
        getConfig: function (r) {
          if (i) return i;
          r.height < e && ((e = 1), (t = [100]));
          for (let t = 0; t < e; t++) n.push(!1);
          return (
            (i = {
              numberOfSlices: e,
              defaultSliceArray: n,
              percentInViewSliceArray: t,
            }),
            i
          );
        },
      };
    },
    Qs = function (e, t) {
      "use strict";
      const n = {
          mbrd: !1,
          mbvs: [],
          mbe: "n",
          mbv: 9,
          mbs: [],
          mbm: 1,
          mbivs: [],
        },
        i = function (e, t) {
          let n = 0;
          const i = (function (e, t) {
            const n = [],
              i = e.geometry.value();
            return (
              t.forEach(function (t) {
                if (e.geometry.doesIntersect(t)) {
                  const e = t.value(),
                    r = Math.max(i.leftX, e.leftX),
                    o = Math.min(i.rightX, e.rightX),
                    s = Math.max(i.topY, e.topY),
                    a = Math.min(i.bottomY, e.bottomY);
                  n.push(new ea(r, o, s, a));
                }
              }),
              n
            );
          })(e, t);
          let r;
          return (
            i.forEach(function (e) {
              (r = e.value()), (n += r.area);
            }),
            n
          );
        },
        r = function (t) {
          e.forEach(function (e) {
            e.isInView = i(e, t) >= e.geometry.value().area;
          });
        };
      return (
        t.addListener(r),
        {
          getPercentInView: function () {
            const t = (function () {
              let t = 0;
              return (
                (n.mbs = []),
                e.forEach(function (e) {
                  n.mbs.push(e.isInView),
                    e.isInView && (t += e.percentageInViewContribution);
                }),
                t
              );
            })();
            return (
              (n.mbrd = 1),
              t !== n.mbp && n.mbivs.push([zn.getTagTime(), t]),
              (n.mbp = t),
              t
            );
          },
          removePixels: function () {
            void 0 !== t && t.stop();
          },
          getPixelStateForDebug: function () {
            return (
              (n.mbm = 1),
              (n.mbpr = []),
              (n.mbir = []),
              e.forEach(function () {
                n.mbpr.push("na"), n.mbir.push(!1);
              }),
              n
            );
          },
          isReadyToMeasure: function () {
            return !0;
          },
          getSliceStatus: function () {
            const t = [];
            return (
              e.forEach(function (e) {
                t.push(e.isInView);
              }),
              t
            );
          },
        }
      );
    },
    Zs = function (e) {
      "use strict";
      const t = Ks();
      return {
        getSliceStatus: function (n, i, r, o) {
          const s = [],
            a = n.getRounded(),
            c = a.height,
            d = a.scrY,
            u = new ei({ scrX: a.scrX, width: a.width }),
            l = t.getConfig(a).numberOfSlices;
          let m;
          u.set("height", Fi.floor(c / l));
          for (let t = 0; t < l; t++)
            u.set("scrY", Math.ceil(d + (c / l) * t)),
              (m = 100 === e.calcPercentInView(u, i, r, o)),
              s.push(m);
          return s;
        },
      };
    },
    ea = function (e, t, n, i) {
      "use strict";
      const r = Math.ceil(e),
        o = Math.ceil(t),
        s = Math.ceil(n),
        a = Math.ceil(i),
        c = o - r,
        d = a - s,
        u = c * d,
        l = function () {
          return {
            leftX: r,
            rightX: o,
            topY: s,
            bottomY: a,
            width: c,
            height: d,
            area: u,
          };
        };
      return {
        value: l,
        doesIntersect: function (e) {
          const t = l(),
            n = e.value();
          return (
            n.leftX < t.rightX &&
            n.rightX > t.leftX &&
            n.topY < t.bottomY &&
            n.bottomY > t.topY
          );
        },
      };
    },
    ta = function () {
      "use strict";
      return {
        createInstance: function (e, t) {
          return new IntersectionObserver(e, t);
        },
      };
    },
    na = function (e, t) {
      "use strict";
      let n;
      const i = [];
      let r = [];
      const o = function (e, t) {
          -1 === e.indexOf(t) && e.push(t);
        },
        s = function (e) {
          const t = (function () {
            let e = [];
            return (
              r.forEach(function (t) {
                const n = t.value();
                o(e, n.topY), o(e, n.bottomY);
              }),
              (e = e.sort(function (e, t) {
                return e - t;
              })),
              e
            );
          })();
          r = [];
          for (let i = 0; t.length > i && ((n = i), t.length !== n + 1); i++) {
            const n = t[i],
              o = t[i + 1];
            r.push(new ea(0, e, n, o));
          }
          var n;
        },
        a = function (e, t) {
          r.push(e),
            s(t),
            i.forEach(function (e) {
              e(r);
            });
        },
        c = function () {
          n.unobserve(e), n.disconnect();
        };
      return (
        (n = t.createInstance(
          function (e) {
            const t = e.pop(),
              n = t.boundingClientRect,
              i = n.width,
              r = t.intersectionRatio,
              o = (function (e, t) {
                const n = t.left - e.left,
                  i = n + t.width,
                  r = t.top - e.top,
                  o = r + t.height;
                return new ea(n, i, r, o);
              })(n, t.intersectionRect);
            a(o, i), 1 === r && c();
          },
          { threshold: [0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1] }
        )),
        n.observe(e),
        {
          addListener: function (e) {
            i.push(e);
          },
        }
      );
    },
    ia = function () {
      "use strict";
      const e = function (e) {
          let t = !1;
          return (
            ra.forEach(function (n) {
              e === n.PARTNER_NAME && (t = !0);
            }),
            t
          );
        },
        t = function (t, i) {
          return t.omidNativeInfo &&
            t.omidNativeInfo.partnerName &&
            e(t.omidNativeInfo.partnerName)
            ? i && n(i.onScreenContainerGeometry)
            : i && n(i.onScreenGeometry);
        },
        n = function (e) {
          return (
            e &&
            e.hasOwnProperty("x") &&
            e.hasOwnProperty("y") &&
            e.hasOwnProperty("width") &&
            e.hasOwnProperty("height")
          );
        };
      return {
        detect: e,
        checkAdViewGeometryBasedOnWhitelist: t,
        checkGeometryObject: n,
        checkForViewAttachmentBasedOnAdSessionType: function (e, n) {
          if (
            n &&
            n.reasons &&
            n.reasons.indexOf("notFound") < 0 &&
            e.adSessionType &&
            (e.adSessionType.indexOf("native") > -1 ||
              e.adSessionType.indexOf("javascript") > -1 ||
              (e.adSessionType.indexOf("html") > -1 && t(e, n)))
          )
            return !0;
        },
      };
    },
    ra = [
      { PARTNER_NAME: "IAB" },
      { PARTNER_NAME: "IAS" },
      { PARTNER_NAME: "com.integralads.omid.iassdk" },
    ],
    oa = function () {
      "use strict";
      return {
        listenForResult: function () {
          at.getAggregator().on("videoBlockResult", function (t) {
            const n = at.getAggregator().request("adNode");
            let i = !1;
            const r = "blockAd" + e.videoId;
            "failed" === t.action && (i = !0),
              n && Xe(n.blockAd) ? n.blockAd(i) : n && Xe(n[r]) && n[r](i);
          });
        },
      };
    },
    sa = function () {
      "use strict";
      const e = [];
      return {
        registerEvent: (t, n) => {
          const i = (function (e, t) {
            const n = (e) => e.getVolumeFromContext(r),
              i = at
                .getAggregator()
                .request("videoTranslator")
                .translate(e.messageType),
              r = ((e) => {
                const t = e.eventData || {},
                  n = Ze({}).mixin(t);
                return n.ext_passthrough && delete n.ext_passthrough, n;
              })(e),
              o = ((e) => {
                let t;
                const n = e.eventData && e.eventData.ext_passthrough,
                  i = (e, t) => {
                    const n = {};
                    return (n[`x_${e}`] = t), n;
                  };
                return n && (t = Ze(n).mapToObj(i)), t;
              })(e),
              s = oe.measurementConfig?.birthdate,
              a = { t: e.time - s, tp: i, sl: t };
            try {
              if (void 0 !== e.volumeHandler) {
                const t = n(e.volumeHandler);
                if (void 0 !== t) {
                  const n = parseFloat(t),
                    i = e?.latestScreenEvent?.percentInView,
                    r = "number" == typeof i,
                    o = "AdVideoComplete" === e.messageType;
                  r && o && n > 0 && i >= 50
                    ? (a.avoc = 1)
                    : r && o && (a.avoc = 0);
                }
              }
            } catch (e) {}
            Ze(a).mixin(r), Ze(a).mixin(o);
            const c = Ze({
              indicatesPlaying: () =>
                -1 !== "showAd|adImpression|adVideoStart|resumeAd".indexOf(i),
              indicatesNotPlaying: () =>
                -1 !== "adVideoComplete|adStopped|stopAd|pauseAd".indexOf(i),
              indicatesFullscreen: () => {
                const e = Fi.getWindow();
                return !(
                  ("resizeAd" !== i && "initAd" !== i) ||
                  ("fullscreen" !== r.viewMode && r.width !== e.screen.width)
                );
              },
              indicatesNormalSize: () =>
                "resizeAd" === i && "normal" === r.viewMode,
              indicatesQuartile: () =>
                -1 !==
                "adVideoFirstQuartile|adVideoMidpoint|adVideoThirdQuartile|adVideoComplete".indexOf(
                  i
                ),
              indicatesCompletion: () =>
                -1 !== "adStopped|adVideoComplete|adSkipped|adError".indexOf(i),
              getVolume: n,
              updateScreenLoc: (e) => {
                (a.sl = e), (c.sl = e);
              },
              trigger: () => {
                "adImpression" === i
                  ? at.getAggregator().persistentTrigger(i, r, o)
                  : at.getAggregator().trigger(i, r, o);
              },
              toString: () => "{" + Ze(a).toParams() + "}",
            }).mixin(a);
            return c;
          })(t, n);
          return e.push(i), i;
        },
        toString: () =>
          "{" +
          Ze({
            vEventCount: e.length,
            vEvents: "[" + e.join(",") + "]",
          }).toParams() +
          "}",
        isEmpty: () => 0 === e.length,
      };
    },
    aa = function () {
      "use strict";
      let e, t, n;
      const i = function (i) {
          (n = Xe(i) ? 0 === i : n),
            t &&
              n &&
              e.addState({
                isFullyInView: function () {
                  return !1;
                },
              });
        },
        r = function () {
          e &&
            e.hasAlwaysBeen(!0) &&
            at.getAggregator().trigger("sendDt", "qf");
        },
        o = function () {
          (t = !0), i();
        },
        s = function (e) {
          const t = new da().getVolumeFromContext(e);
          i(t);
        };
      return {
        isApplicable: function (e) {
          return e.usesGroupMCustomMetric();
        },
        start: function (n) {
          at
            .getAggregator()
            .on({
              adVideoStart: o,
              adImpression: o,
              volumeChanged: s,
              adVideoMidpoint: r,
            }),
            (e = n.createViewabilityTracker("mpt", function (e) {
              const n = at.getAggregator().request("isFullyInViewProvider");
              return !t || (n && n.isFullyInView(e));
            }));
        },
      };
    },
    ca = function () {
      "use strict";
      const e = {
        AdPaused: "pauseAd",
        AdVolumeChange: "volumeChanged",
        AdPlaying: "resumeAd",
      };
      return {
        translate: function (t) {
          let n = t.charAt(0).toLowerCase() + t.slice(1);
          return t in e && (n = e[t]), n;
        },
      };
    },
    da = function () {
      "use strict";
      return {
        getVolumeFromContext: (e) => {
          let t,
            n = -1;
          return (
            Xe(e) &&
              (Xe(e.volume)
                ? (n = e.volume)
                : Xe(e.adVolume) && (n = e.adVolume)),
            -1 !== n && (t = n),
            t
          );
        },
      };
    },
    ua = function (t, n, i) {
      "use strict";
      const r = "IASid" + t,
        o = "getIasVidBridgeVersion" + t;
      let s,
        a,
        c,
        d = [],
        u = "outOfView",
        l = !1,
        m = !1,
        g = !1,
        p = !0,
        f = !1;
      const h = new sa(),
        y = aa(),
        v = new oa(),
        S = new da(),
        b = new wi(),
        I = function (e) {
          l = !0;
          const t = w(e);
          return (
            t && (t.iasPlaybackStateSnapshot = C()), d.push(t), c && _(), t
          );
        },
        w = function (e) {
          let n,
            r,
            o = {};
          try {
            o = JSON.parse(unescape(e && e.data ? e.data : e));
          } catch (e) {
            o = {};
          }
          if (o.id == t)
            if (zn && zn.isVastAudio() && o.messageType && o.eventData) {
              const e = !!o.eventData.volume,
                t =
                  -1 ===
                  "AdVideoComplete|AdStopped|AdSkipped|AdPaused|AdError|AdUserClose".indexOf(
                    o.messageType
                  ),
                i = e && t;
              (o.eventData.width = i ? 20 : 0),
                (o.eventData.height = i ? 20 : 0),
                (p = e),
                (m = t),
                (u = !!i && "inView"),
                (n = h.registerEvent(o, i ? "i" : "o"));
            } else
              (o.latestScreenEvent = i.getLatestEvent()),
                (o.volumeHandler = S),
                (n = h.registerEvent(o, i.getCurrentLoc())),
                n.indicatesPlaying()
                  ? ((m = !0), (u = !!g && "inView"))
                  : n.indicatesNotPlaying()
                  ? ((m = !1), (u = "outOfView"))
                  : n.indicatesFullscreen()
                  ? ((g = !0), (u = m ? "inView" : "outOfView"))
                  : n.indicatesNormalSize() &&
                    ((g = !1), (u = !m && "outOfView")),
                (r = parseFloat(n.getVolume(S))),
                r > 0 ? (p = !0) : 0 === r && (p = !1);
          return n;
        },
        A = function (n) {
          let i, s;
          const a = Vi().wrapToGlobal(I);
          try {
            (s = n[o] || n.getIasVidBridgeVersion),
              (i =
                Je(s) && "2" === s.call(n)
                  ? unescape(n[r].call(n, t, a))
                  : unescape(n[r].call(n, t))),
              (l = !0),
              (function (e) {
                Ke(e) &&
                  (at.getAggregator().provide("vc", function () {
                    return e;
                  }),
                  at
                    .getAggregator()
                    .trigger("addOutputItem", { output: e }, "vc", {
                      type: "impression",
                    }));
              })(i || "n");
          } catch (t) {
            __IntegralASDiagnosticCall("handshakefailure", t, e);
          }
        },
        $ = function () {
          if (
            !s &&
            (Ze([
              "*[data-integralas-vid-" + t + "]",
              ".integral-vid-" + t,
              "ias-ad",
              "object",
              "embed",
            ]).findFirst(function (e, t) {
              const n = Fi.getDoc().querySelectorAll(t);
              return (
                (s = (function (e) {
                  return Ze(Ze(e).toArray()).findFirst(function (e, t) {
                    return Je(t[r]);
                  });
                })(n)),
                s
              );
            }),
            !s && n.on("novidnodeerr"))
          ) {
            Math.random() < 0.1 &&
              __IntegralASDiagnosticCall(
                "novidnode",
                { message: "node not found*10" },
                e
              );
          }
          return s;
        },
        T = function () {
          const e = $();
          return e && !l && A(e), e;
        },
        E = function (e) {
          const t = S.getVolumeFromContext(e);
          p = !!Xe(t) && t > 0;
        },
        C = function () {
          return { isPlaying: m, isSoundOn: p, isFullscreen: g };
        },
        O = function (e) {
          const t = i.getCurrentEvent?.(),
            n = e || C(),
            r = n.isFullscreen && n.isPlaying;
          return t
            ? {
                ...t,
                percentInView: r ? 100 : t.percentInView,
                fullPercentInView: r ? 100 : t.fullPercentInView,
                isVideoPlaying: n.isPlaying,
                isSoundOn: n.isSoundOn,
                isVideoPlayingInFullscreen: r,
              }
            : t;
        },
        _ = function () {
          b.init(),
            Ze(d).each(function (e, t) {
              t &&
                (void 0 === t.sl && t.updateScreenLoc(i.getCurrentLoc()),
                t.trigger(),
                t.indicatesCompletion() &&
                  at.getAggregator().trigger("adSessionComplete"),
                (function (e) {
                  return (
                    e.indicatesCompletion() ||
                    "adUserClose" === e.tp ||
                    "stopAd" === e.tp ||
                    "adStopped" === e.tp ||
                    "adSkipped" === e.tp ||
                    "adError" === e.tp
                  );
                })(t) && (f = !1),
                t.indicatesQuartile() &&
                  ("adVideoComplete" !== t.tp &&
                    at.getAggregator().trigger("sendDt", "m"),
                  at
                    .getAggregator()
                    .trigger("videoQuartileEvent", {
                      videoEvent: t,
                      screenEvent: O(t.iasPlaybackStateSnapshot),
                    })),
                !f &&
                (function (e) {
                  return e.indicatesPlaying();
                })(t)
                  ? ((f = !0),
                    at
                      .getAggregator()
                      .trigger("videoStartEvent", {
                        videoEvent: t,
                        screenEvent: O(t.iasPlaybackStateSnapshot),
                      }))
                  : t.indicatesQuartile() ||
                    at
                      .getAggregator()
                      .trigger("videoPlaybackStateEvent", {
                        videoEvent: t,
                        screenEvent: O(t.iasPlaybackStateSnapshot),
                      }));
            }),
            (d = []),
            (c = !0);
        },
        M = function () {
          return g && m;
        };
      return (
        Jn.addEvent(Fi.getWindow(), "message", function (e) {
          I(e);
        }),
        at.getAggregator().on({ volumeChanged: E }),
        at.getAggregator().provide({
          videoEventsString: h,
          videoVersion: function () {
            let e;
            const t = T();
            try {
              e = t.getVersion();
            } catch (t) {
              (e = -1), at.getAggregator().trigger("error", "u");
            }
            return e;
          },
          videoTranslator: function () {
            return (a = a || new ca()), a;
          },
          adNode: T,
        }),
        T(),
        v.listenForResult(),
        y.isApplicable(zn) && y.start(i),
        {
          findAdNode: T,
          getViewStateOverride: function () {
            return u;
          },
          isHandshakeComplete: function () {
            return l;
          },
          triggerInitializationEvents: _,
          setVideoSpecificScreenEventFields: function (e) {
            const t = "na" === e.viewState;
            if (
              ((e.isVideoPlaying = !0),
              (e.isSoundOn = p),
              (e.isVideoPlayingInFullscreen = !1),
              u)
            ) {
              if ("outOfView" === u) {
                const t = e.reason ? e.reason.split(".") : [];
                (t[t.length] = "v"), (e.reason = t.join("."));
              }
              (e.viewState = t ? e.viewState : u),
                (e.isVideoPlaying = "inView" === u);
            }
            if (
              (M() &&
                ((e.percentInView = 100), (e.isVideoPlayingInFullscreen = !0)),
              zn && zn.isVastAudio && zn.isVastAudio())
            ) {
              const t = 20,
                n = 20,
                i = m && p,
                r = new ei({
                  scrX: 0,
                  scrY: 0,
                  width: i ? t : 0,
                  height: i ? n : 0,
                });
              (e.adDimensions = r),
                (e.containerDimensions = r),
                (e.viewState = i ? "inView" : "outOfView"),
                (e.viewStateIgnoringRender = i ? "inView" : "outOfView"),
                (e.posViewState = i ? "inView" : "outOfView"),
                (e.percentInView = i ? 100 : 0),
                (e.percentInViewIgnoringRender = i ? 100 : 0),
                (e.isHidden = i ? 0 : 1),
                (e.tabHidden = i ? 0 : 1);
            }
          },
        }
      );
    },
    la = function () {
      "use strict";
      return new ha("flwrapper", 9);
    },
    ma = function () {
      "use strict";
      let e, t;
      const n = {};
      let i = 0;
      const r = (n) => {
          (n || e) &&
            ((i += 5),
            t.onTick(i, () => {
              e ? r() : at.getAggregator().trigger("sendDt", "e");
            }),
            (e = !1));
        },
        o = () => {
          (t = new An()), (i = 0), r(!0), t.start();
        },
        s = (i, r, s, a) => {
          const c = n[i];
          a ? (Xe(c[r]) || (c[r] = []), c[r].push(s)) : (c[r] = s),
            (t && t.isActive()) || o(),
            (e = !0);
        },
        a = (n, i, r) => {
          at.getAggregator().trigger("addOutputItem", { output: i }, n, r),
            (t && t.isActive()) || o(),
            (e = !0);
        },
        c = (t) => {
          Object.keys(n).forEach((i) => {
            ((t, i) => {
              const r = n[t],
                o = { type: i, oneTime: !0, minDt: !0, asION: !0 };
              0 !== Object.keys(r).length &&
                (at
                  .getAggregator()
                  .trigger("addOutputItem", { output: r }, t, o),
                (n[t] = {})),
                (e = !1);
            })(i, t);
          });
        };
      return {
        start: () => {
          at.getAggregator().on("preSendDt", (e) => {
            c(e), t && t.kill();
          }),
            at.getAggregator().on("addThrottledProp", s),
            at.getAggregator().on("addThrottledOutputItem", a);
        },
        addFieldTypes: (e) => {
          e.forEach((e) => {
            n[e] = {};
          });
        },
      };
    },
    ga = function () {
      "use strict";
      const e = {},
        t = (t) => (
          !e[t] && (e[t] = new wn(1, oe.measurementConfig.birthdate)), e[t]
        ),
        n = (e) => {
          t(e).start();
        },
        i = (e) => {
          const n = t(e);
          n.stop(),
            at
              .getAggregator()
              .trigger("addThrottledProp", "im", e, n.getTime());
        };
      return {
        start: () => {
          at.getAggregator().on({ markTime: n, measureTime: i });
        },
        isApplicable: (e) => e.on("pIntervals"),
      };
    },
    pa = function () {
      "use strict";
      return new ha("jswrapper", 15);
    },
    fa = function (e) {
      "use strict";
      const t = {},
        n = e instanceof Array && e.length > 0;
      return (
        n &&
          (e.forEach(function (e) {
            var n;
            t[(n = e).getType()] = n;
          }),
          at.getAggregator().on("perfCheckpoint", function (e) {
            const n = t[e.type];
            if (n)
              try {
                n.addPoint(e),
                  n.isFinished() &&
                    at
                      .getAggregator()
                      .trigger("addThrottledProp", "im", "pci", n.toString());
              } catch (e) {}
          })),
        at.getAggregator().provide("perfActive", function () {
          return n;
        }),
        { isActive: n }
      );
    },
    ha = function (e, t) {
      "use strict";
      let n = 0;
      const i = [],
        r = function () {
          let e;
          const t = {};
          return (
            i.sort(function (e, t) {
              return e.timestamp - t.timestamp;
            }),
            Ze(i).each(function (i, r) {
              e && (t[r.code] = r.timestamp - e), i === n && (e = r.timestamp);
            }),
            t
          );
        };
      return {
        addPoint: function (e) {
          i.push(e);
        },
        toString: function () {
          return Ze(r()).toION();
        },
        getType: function () {
          return e;
        },
        setBaseOrdinal: function (e) {
          n = e;
        },
        isFinished: function () {
          return i.length === t;
        },
      };
    },
    ya = (function () {
      "use strict";
      function e() {}
      return (
        (e.build = function () {
          const e = [];
          e.push(new ha("render", 2));
          const t = (function () {
            const e = at.getAggregator().request("vc");
            return e ? { jv3: va, av3: va, jvw: pa, avw: la }[e] : void 0;
          })();
          return t && e.push(t()), e;
        }),
        e
      );
    })(),
    va = function () {
      "use strict";
      return new ha("vans", 4);
    },
    Sa = {
      IDS: { BLOCK_TIME: "pBlk", ON_LOAD: "pLoad", IN_BROWSER_DELAY: "pWait" },
      recordBlockingTime: () => {
        "use strict";
        at.getAggregator().trigger("measureTime", Sa.IDS.BLOCK_TIME);
      },
      setupOnLoadTracking: () => {
        "use strict";
        Jn.addEvent(t, "load", () => {
          at.getAggregator().trigger("measureTime", Sa.IDS.ON_LOAD);
        });
      },
      setupBrowserDelayTracking: () => {
        "use strict";
        const e = new An();
        e.onTick({
          4: () => {
            at.getAggregator().trigger("markTime", Sa.IDS.IN_BROWSER_DELAY);
          },
          5: () => {
            at.getAggregator().trigger("measureTime", Sa.IDS.IN_BROWSER_DELAY);
          },
        }),
          e.start();
      },
    },
    ba = {
      name: "postMessageDetector",
      dependencies: [],
      creator: function () {
        "use strict";
        let e = !1;
        const t = "pmdetector" + (oe.adTag && oe.adTag.asid),
          n = (n) => {
            (n && n.data) === t && (e = !0);
          };
        (() => {
          const i = Fi.getWindow();
          Jn.addEvent(i, "message", n),
            i.postMessage(t, "*"),
            Fi.execAtEndOfThread(() => {
              at
                .getAggregator()
                .trigger("addThrottledProp", "im", "pom", Qe(e)),
                Jn.removeEvent(i, "message", n);
            });
        })();
      },
      settings: {
        tier: 8,
        applies: (e, t, n) => {
          "use strict";
          return e.on("pmdetect") && t.hasPostMessage();
        },
      },
    },
    Ia = {
      name: "safeFrameDetector",
      dependencies: [],
      creator: function () {
        "use strict";
        at.getAggregator().trigger(
          "addThrottledProp",
          "im",
          "sf",
          Qe(zn.isSafeFrame())
        );
      },
      settings: {
        tier: 8,
        applies: (e, t, n) => {
          "use strict";
          return e.on("sfdetect");
        },
      },
    },
    wa = function (t, n, i, r, o, s, a) {
      "use strict";
      const c = "adsafe_jsinfo=",
        d = (e) => ("&" === e.slice(-1) ? "" : "&"),
        u = (u) => {
          const l = oe.baseUrls?.ctvImpressionUrl,
            m = !!l;
          let g = m
            ? (({ ctvImpressionUrl: t }) => {
                const { advEntityId: n, pubEntityId: i } = Hn(),
                  r = oe.adTag?.creativeUrl ?? "",
                  o = r.indexOf("?"),
                  s = -1 === o ? r : r.slice(0, o),
                  a = zn.isDomless()
                    ? ne({ url: p() || void 0 })
                    : oe.contextNode?.staticFwjsMacros ||
                      e.staticFwjsMacros ||
                      ne({
                        url: oe.contextNode?.src,
                        paramsToStrip: ["config", "iasConfig", "creativeUrl"],
                      }),
                  c =
                    oe.jsConfigRequest?.verificationParameters
                      ?.staticFwjsMacros,
                  d = c || a,
                  u = s.replace(/^https?:/i, ""),
                  l = [
                    "advEntityId=" + n,
                    "pubEntityId=" + i,
                    "creativeUrl=" + encodeURIComponent(u),
                  ];
                return d && l.push(d), t + "?" + l.join("&") + "&";
              })({ ctvImpressionUrl: l })
            : r.baseUrl;
          const f = oe.measurementConfig.spImpMaxLength;
          if (
            (m ||
              (Ln.checkIfFirstPartyBlockingApplies({ impressionUrl: g })
                ? (g = Ln.modifyUrlForFirstPartyBlocking({ impressionUrl: g }))
                : zn.integratedBlockingApplies(g) &&
                  (g = ((t) => {
                    const n = at.getAggregator().request("mobileApp"),
                      i =
                        n &&
                        n.isMobileAppEnvironment &&
                        n.isMobileAppEnvironment();
                    let r =
                      t +
                      "adContainerId=" +
                      e.contextNode.getAttribute("data-ias-container") +
                      "&cbFunctionName=" +
                      e.contextNode.getAttribute(
                        "data-ias-callback".toString()
                      );
                    r = i
                      ? r.replace("monitoring", "blocking")
                      : r.replace("skeleton.js", e.integration + ".js");
                    const o =
                        e.protocol +
                        ":" +
                        e.staticServer +
                        e.integration +
                        "a.js",
                      s =
                        e.protocol +
                        ":" +
                        e.staticServer +
                        e.integration +
                        ".js";
                    return (
                      r +
                      "&true_pb=" +
                      encodeURIComponent(e.passback) +
                      (i ? "&redirectUrl=" + encodeURIComponent(s) : "") +
                      (i ? "&passback=" : "&adsafe_pb=") +
                      encodeURIComponent(o) +
                      "&"
                    );
                  })(g)),
              (g = g.replace("[IAS_ASID]", oe.adTag && oe.adTag.asid))),
            (g += ((e, i, r) => {
              let o,
                s,
                a = "";
              try {
                (o = i - e - oe.measurementConfig.spImpJsInfoMinLength),
                  o > 0 &&
                    ((s = Ma(r, o, c.length, n.on("partialUrls"))),
                    (a += s.join("&")));
              } catch (e) {
                t.add("I");
              }
              return a;
            })(g.length, f, u)),
            (g += d(g)),
            (g += ((e, r) => {
              let d = "";
              try {
                d += Ea(r - e, c, t, n, i, o, s, a, r);
              } catch (e) {
                t.add("J"), (d += "adsafe_jsinfo=e:" + t.toString());
              }
              return d;
            })(g.length, f)),
            r.macroUrl && ((g += d(g)), (g += r.macroUrl)),
            !m &&
              e.staticFwjsMacros &&
              ((g += d(g)), (g += e.staticFwjsMacros)),
            zn.isAMZN() && -1 === g.indexOf("gdpr_consent"))
          ) {
            const e = at.getAggregator().request("tcString");
            Xe(e) && ((g += d(g)), (g += "gdpr_consent=" + e));
          }
          return g;
        };
      return {
        send: (t) => {
          try {
            const n = u(t);
            (e.impUrl = n),
              r.sendImpression(n),
              at.getAggregator().trigger("impressionsent"),
              (() => {
                if (e.rts && e.rts.tracked) {
                  const t = e.rts.tracked;
                  at.getAggregator().trigger("notify", t);
                }
              })();
          } catch (t) {
            __IntegralASDiagnosticCall("impsend", t, e);
          }
        },
      };
    },
    Aa = () => {
      try {
        const n = e.perf;
        at.getAggregator().trigger(
          "addOutputItem",
          { output: zn.getTagTime() },
          "sis"
        );
        const i = () =>
            t.performance &&
            "function" == typeof t.performance.getEntriesByName &&
            t.performance.getEntriesByName(e.impUrl)[0],
          r = (t) => {
            const i = n.getStart("bd"),
              r = n.getStart(ht);
            return e.jsDoSplit ? Math.round(t - i) : Math.round(t - r);
          },
          o = (e) => Math.round(e && e.duration),
          s = (e, t) => {
            const n = t && t.responseEnd;
            return Math.round(e - n);
          };
        n.markEnd("ec");
        const a = n.getEnd("ec"),
          c = i(),
          d = r(a),
          u = o(c),
          l = s(a, c);
        if (ot(d) && ot(u) && ot(l)) {
          const e = { ttecl: d, ecd: u, tsecr: l };
          at.getAggregator().trigger(
            "addThrottledProp",
            "im",
            "imprf",
            Ze(e).toION()
          );
        }
      } catch (e) {
        at.getAggregator().trigger("error", "e");
      }
    },
    $a = /(?:^|[?&])adsafe_jsinfo=/,
    Ta = ({ impressionUrl: e }) => {
      if ("string" != typeof e || 0 === e.length) return;
      const t = $a.exec(e);
      if (!t) return;
      const n = e.substring(t.index + t[0].length),
        i = n.indexOf("&");
      return -1 === i ? n : n.substring(0, i);
    },
    Ea = (t, n, i, r, o, s, a, c, d) => {
      "use strict";
      const u = (e) => {
          let t = "";
          return e && (t = `,${e}`), t;
        },
        l = (e, n) => e.length + n.length + 5 <= t;
      return ((t) => {
        let i = "";
        const s =
          !zn.isDomless() &&
          (({ apiFunctionName: e, apiFrameLocatorName: t }) => {
            let n = !1;
            try {
              n = !!Vt({ apiFunctionName: e, apiFrameLocatorName: t });
            } catch (e) {}
            return n;
          })({
            apiFunctionName: "__tcfapi",
            apiFrameLocatorName: "__tcfapiLocator",
          });
        return (
          s && r.on("consentDetection")
            ? (i += ((e) => {
                let t = n;
                const { primary: i } = e,
                  r = i.find((e) => e.includes("id:"));
                return (
                  (t += u("cmpApi:1")),
                  (t += u(r)),
                  o.impressionIsIdentifiable(!0),
                  t
                );
              })(t))
            : (i += ((t) => {
                const i = st(t.primary.join(","), e.encodeInvalidUrlChars);
                let r = 0,
                  s = n;
                return (
                  l(s, i)
                    ? ((s += u(i)),
                      o.impressionIsIdentifiable(!0),
                      t.secondary.forEach((t) => {
                        const n = st(t, e.encodeInvalidUrlChars);
                        l(s, n) ? (s += u(n)) : (r += 1);
                      }))
                    : (r += t.primary.length),
                  (s += ",ov:" + r)
                );
              })(t)),
          i
        );
      })(
        (() => {
          const e = (() => {
              const e = { viewState: "na" };
              let t,
                n = e;
              return (
                zn.isDomless()
                  ? (n = c.checkScreenLoc(!0) || e)
                  : r.on("impFailSafe")
                  ? Fi.getDoc().body &&
                    ((t = c.checkScreenLoc(!0)), (n = t || e))
                  : Xe(Fi.getDoc().body) && (n = c.checkScreenLoc(!0)),
                c.isImmediatelyMeasurable() ||
                  c.requiresDelayedViewabilityEvent(),
                n
              );
            })(),
            t = Ca(e.viewState, o, r),
            n = _a(e, i, r, s, a, c, d);
          return (
            at.getAggregator().trigger("eligiblerender"),
            { primary: t, secondary: n }
          );
        })()
      );
    },
    Ca = function (e, t, n) {
      "use strict";
      const i = at.getAggregator().request("mPage");
      return [
        "id:" + (oe.adTag && oe.adTag.asid),
        "c:" + t.getCacheBustId(),
        "sl:" + e,
        "em:" + zn.embedded,
        "fr:" + zn.friendly,
        "thd:" + Qe(i.supportsVisAPI()),
      ];
    },
    Oa = /\/fw\.js(?:[?#]|$)/,
    _a = function (t, n, i, r, o, s, a) {
      "use strict";
      const { measurementConfig: c } = oe,
        d = "NotFound",
        u = [];
      if (
        (u.push("mn:" + e.mn),
        u.push("rg:" + e.region),
        e.iasProxyPartnerDomain &&
          u.push("ipp:" + encodeURIComponent(e.iasProxyPartnerDomain)),
        u.push(
          "pt:" +
            (() => {
              let e = s.stringifyPingTimes();
              return "na" !== t.viewState && (e += t.details), e;
            })()
        ),
        u.push("mu:" + a),
        u.push(Ze(o.params()).toParams()),
        i.on("mrcAudit") &&
          !zn.isDomless() &&
          u.push("dvs:" + Fi.getDoc().visibilityState),
        r.iterate((e, t) => {
          const n = !t.props || void 0 === t.props.type,
            i = !t.props || "impression" === t.props.type;
          (n || i) && u.push(e + ":" + t.output());
        }),
        n.toString() && u.push("e:" + n.toString()),
        u.push(i.output()),
        u.push("tt:" + oe.adTag.tagType),
        zn && zn.isVastAudio && zn.isVastAudio() && u.push("vau:1"),
        zn)
      ) {
        let e;
        zn.isVideo() && (e = "v"),
          (zn.isVastAudio() || zn.isOmidAudio()) && (e = "a"),
          e && u.push(`xmtp:${e}`);
      }
      if (
        (u.push("et:" + (Fi.now() - c.birthdate)),
        e.perf.mark("si"),
        u.push("v:19.8.748"),
        u.push("sp:" + (e.isSplitMode ? 1 : 0)),
        u.push("st:" + (c.staticMode ? 1 : 0)),
        u.push("fwm:" + ("true" === e.fwMonitoring ? 1 : 0)),
        "rjss" === oe.adTag.tagType)
      ) {
        const e = oe.jsConfigRequest?.verificationParameters,
          t = se(),
          n = !!t && Oa.test(t),
          i = zn && zn.isDomless && zn.isDomless() ? p() : t,
          r = !ie({ url: i ?? void 0 }) && !!e?.staticFwjsMacros;
        n && u.push("rjd:1"), r && u.push("rjc:1");
      }
      !!oe.jsConfigRequest?.verificationParameters?.config && u.push("ipc:1");
      !!oe.jsConfigRequest?.verificationParameters?.useCacheableStatic &&
        u.push("cst:1"),
        i.on("resolution") &&
          (u.push("wr:" + Ze(oi.windowSize()).toArray().join(".")),
          u.push("sr:" + Ze(oi.screenSize()).toArray().join(".")));
      const l = /iasProxyPartnerId=([\d]+)/g.exec(e.scriptUrl),
        m = l && l[1],
        g = e.proxyPartnerId || m || "";
      g && u.push("ppi:" + g);
      const f = (() => {
        const t = "ias_xpc",
          n = (e) => {
            if (!e || "string" != typeof e) return d;
            const n = String(e).toLowerCase(),
              i = n.indexOf(t);
            if (-1 === i) return d;
            const r = n.substring(i + t.length + 1),
              o = r.indexOf("&");
            return o > -1 ? r.substring(0, o) : r;
          },
          i = n(e.scriptUrl);
        if (i !== d) return i || "";
        let r = "";
        try {
          const e = Fi.getDoc();
          e &&
            e.location &&
            "string" == typeof e.location.href &&
            (r = e.location.href);
        } catch (e) {
          r = "";
        }
        const o = n(r);
        return o !== d && "" !== o ? o : d;
      })();
      return d !== f && u.push("x_xpc:" + f), u;
    },
    Ma = function (e, t, n, i) {
      "use strict";
      let r, o;
      const s = "adsafe_url=",
        a = "&adsafe_type=",
        c = [],
        d = (e) => -1 !== e.key.indexOf("q") || -1 !== e.key.indexOf("g"),
        u = (e) => {
          let r = e.val;
          const o = e.key,
            d = ((e) => {
              const i = s.length + a.length + c.join("&").length + e.length + n;
              return t - i;
            })(o);
          if (
            (i && d < r.length && d > 0 && (r = r.substr(0, d)),
            r.length || "" === e.val || "" === e.type)
          ) {
            const e = s + r + a + o;
            ((e) => {
              const n = c.join("&").length;
              return e.length + n <= t;
            })(e) && c.push(e);
          }
        };
      return (
        e &&
          e.length &&
          ((r = e.filter((e) => d(e))),
          (o = e.filter((e) => !d(e))),
          r.concat(o).forEach((e) => {
            u(e);
          })),
        c
      );
    },
    Da = (e) => Math.round(e / 1048576) < 2 * Math.round(xa() / 1048576),
    xa = () =>
      Fi.getWindow().performance?.memory?.jsHeapSizeLimit || 1073741824,
    Pa = async () => {
      const e = (await (async () => {
        let e = !1;
        try {
          if (at.getAggregator().request("browser").browserIs("c")) {
            const t = (await navigator.storage.estimate()).quota || 0;
            e = Da(t);
          }
        } catch (e) {}
        return e;
      })())
        ? "1"
        : "0";
      at.getAggregator().trigger("addOutputItem", { output: e }, "igt");
    },
    Na = function () {
      "use strict";
      return {
        isApplicable: function (e) {
          const t = Fi.getWindow();
          return !(!t.navigator || !t.navigator.plugins);
        },
        start: function (e) {
          const t = Fi.getWindow(),
            n = Fa(t.navigator.plugins),
            i = n.hash();
          var r, o;
          if (
            ((r = i.join(".")),
            at
              .getAggregator()
              .trigger("addOutputItem", { output: r }, "pl", {
                type: "impression",
              }),
            i.length)
          ) {
            const e = n.decode(i);
            (o = e.join(".")),
              at
                .getAggregator()
                .trigger("addOutputItem", { output: o }, "pd", { type: "a" });
          }
        },
      };
    },
    Va = function (e, t) {
      "use strict";
      return {
        start: function () {
          try {
            const n = Ra(),
              i = n.getMethodName(e),
              r = new En(t.getEnabledScriptUrl(e) || "");
            new ja(
              (function () {
                const e = Fi.getDoc();
                return e.body || e.head || e.documentElement;
              })(),
              r
            ).getWindow()[i] = n.getMethod(t);
          } catch (e) {
            at.getAggregator().trigger("error", "H");
          }
        },
      };
    },
    Ra = function () {
      "use strict";
      const e = function (e, t, n) {
          e === (oe.adTag && oe.adTag.asid) &&
            (n.unshift(t), at.getAggregator().trigger.apply(null, n));
        },
        t = {
          DT_CODES: { SCA: "s", XSCA: "xs" },
          DT_SLOT: { FF_EXP: "xsca" },
          ERROR_CODES: { SCA: "X", XSCA: "Z" },
        };
      return {
        getMethod: function (n) {
          return function (i) {
            const r = {
              asid: oe.adTag && oe.adTag.asid,
              constant: t,
              features: n,
              context: zn,
              dtBaseURL: oe.baseUrls.dtBaseUrl,
              spg: Ua,
            };
            "function" == typeof i && i(e, r);
          };
        },
        getMethodName: function (e) {
          return "register_" + e;
        },
      };
    },
    ka = function () {
      "use strict";
      return {
        start: function (e, t) {
          e.forEach(function (e) {
            t.getEnabledScriptUrl(e) && Va(e, t).start();
          });
        },
      };
    },
    Fa = function (e) {
      "use strict";
      const t = function (e) {
        return e.filename.replace(/\.plugin$/, "");
      };
      return {
        hash: function () {
          let n = 0;
          const i = e.length,
            r = [];
          let o, s, a;
          for (; n < i; n++)
            (s = t(e[n])),
              (a = zi.hashCode(s)),
              (o = tt(a, 62).slice(-4)),
              r.push(o);
          return r;
        },
        decode: function (n) {
          const i = Fi.floor(Fi.random() * n.length),
            r = encodeURIComponent(t(e[i]));
          return [n[i], r];
        },
      };
    },
    ja = function (t, n) {
      "use strict";
      let i;
      return (
        (function (n) {
          (i = oi.createHiddenIframe()),
            i.setAttribute(
              "src",
              oe.trustedTypesPolicy.createScriptURL("about:blank")
            ),
            i.setAttribute("class", "_ntnrjf7826-hj"),
            i.setAttribute("tabindex", "-1");
          (t || e.contextNode.parentNode).appendChild(i);
          const r = (function (e) {
              return e.contentWindow.document;
            })(i),
            o = [
              "<head></head>",
              '<body onload="',
              "var d = document;",
              "var s = d.createElement('script');",
              "d.getElementsByTagName('head')[0].",
              "appendChild(s).src",
              "='" + n + "'\">",
            ].join("");
          r.open().write(oe.trustedTypesPolicy.createHTML(o)), r.close();
        })(n),
        {
          getWindow: function () {
            return i.contentWindow;
          },
        }
      );
    },
    Ua = function (e) {
      "use strict";
      const t = new Kt();
      t.listen(
        function (t) {
          return (
            t &&
            t.scaInfoOriginatorASID &&
            t.scaInfoOriginatorASID !== (oe.adTag && oe.adTag.asid) &&
            t.cache &&
            e.allExpectedKeysPresent(t.cache)
          );
        },
        function (n, i) {
          t.stop(),
            Fi.setTimeout(function () {
              e.isDtCallAlreadySent() ||
                (at
                  .getAggregator()
                  .trigger(
                    "addThrottledProp",
                    "sca",
                    "spg",
                    i.scaInfoOriginatorASID
                  ),
                Object.keys(i.cache).forEach(function (t) {
                  e.addToCache(t, i.cache[t]);
                }));
            }, Fi.round(1e3 * Fi.random()));
        }
      ),
        at.getAggregator().on("addToSpg", function (t, n) {
          e.addToCache(n, t),
            e.isFull() &&
              (e.sendToOtherTags(),
              Fi.setTimeout(e.sendToOtherTags, 1300),
              Fi.setTimeout(e.sendToOtherTags, 3200));
        });
    },
    La = {
      name: "spg",
      dependencies: ["spgCache"],
      creator: Ua,
      settings: {
        tier: 4,
        applies: function (e) {
          "use strict";
          return e.on("spg");
        },
      },
    },
    qa = {
      name: "spgCache",
      dependencies: [],
      creator: function () {
        "use strict";
        const e = ["asp", "ch", "fsc", "mvn", "no", "sd"],
          t = {};
        let n = !1;
        const i = function (t) {
            return Object.keys(t).sort().toString() === e.toString();
          },
          r = function () {
            return i(t);
          };
        return {
          allExpectedKeysPresent: i,
          isDtCallAlreadySent: function () {
            return n;
          },
          addToCache: function (e, i) {
            i && i.output && !r() && (t[e] = i),
              r() &&
                (n ||
                  ((n = !0),
                  Object.keys(t).forEach(function (e) {
                    at.getAggregator().trigger("addOutputItem", t[e], e, {
                      type: "s",
                      minDt: !0,
                      sendOnce: !0,
                    });
                  }),
                  at.getAggregator().trigger("sendMinDt", "s")));
          },
          isFull: r,
          sendToOtherTags: function () {
            new Qt().send({
              scaInfoOriginatorASID: oe.adTag && oe.adTag.asid,
              cache: t,
            });
          },
        };
      },
      settings: {},
    },
    Wa = function () {
      const e = [
        It,
        bt,
        wt,
        or,
        er,
        tr,
        Ki,
        ir,
        nr,
        Qi,
        ba,
        Ia,
        On,
        Nr,
        rs,
        qa,
        La,
      ];
      for (let t = 0; t < e.length; t += 1) {
        const n = e[t];
        at(n.name, n.dependencies, n.creator, n.settings);
      }
    },
    Ba = new RegExp("^(ft|ftias)_?.*_(\\d+)$"),
    Ga = "?iasend?",
    Ha = ({ aggregator: e, ftInstance: t, macros: n }) => {
      try {
        const i = (({ ftInstance: e, macros: t }) => {
          const n = Object.keys(t),
            i = n.map((e) => `${e}=${t[e]}`).join("&") + Ga;
          let r = e.replaceMacros(i);
          const o = r.indexOf(Ga);
          return (
            o > 0 && (r = r.substring(0, o)),
            r.split("&").reduce((e, t) => {
              const i = t.split("="),
                r = i ? i[0] : void 0,
                o = i ? i[1] : void 0;
              return r && n.includes(r) && r && o && (e[r] = o), e;
            }, {})
          );
        })({ ftInstance: t, macros: n });
        for (const [t, n] of Object.entries(i)) {
          const i =
            "string" == typeof n ? n : "number" == typeof n ? n.toString() : n;
          e.trigger("addOutputItem", { output: i }, t, {
            type: "as",
            standalone: !0,
          });
        }
        Object.keys(i).length > 0 && e.trigger("sendDt", "as");
      } catch (e) {}
    },
    Ya = ({
      checkInterval: e,
      collectorTimeout: t,
      aggregator: n,
      macros: i,
      contextNode: r,
      scopedWindow: o,
    }) => {
      const s = Fi.setInterval(() => {
        const e = (({ contextNode: e, scopedWindow: t }) => {
          const n = e?.getAttribute("data-ias-callback".toString())?.match(Ba);
          if (!n || n.length < 3) return;
          const i = n[2],
            r = t ? t[`ft${i}`] : null;
          return r && "function" == typeof r.replaceMacros ? r : void 0;
        })({ contextNode: r, scopedWindow: o });
        e &&
          (Fi.clearInterval(s),
          Ha({ aggregator: n, ftInstance: e, macros: i }));
      }, e);
      Fi.setTimeout(() => {
        Fi.clearInterval(s);
      }, t);
    };
  class za {
    constructor({
      macros: e,
      collectorTimeout: t,
      checkInterval: n,
      aggregator: i,
      scopedWindow: r,
    }) {
      (this.macros = {}),
        (this.collectorTimeout = 5e3),
        (this.checkInterval = 500),
        (this.aggregator = at.getAggregator()),
        (this.collectorTimeout = t ?? this.collectorTimeout),
        (this.checkInterval = n ?? this.checkInterval),
        (this.aggregator = i || this.aggregator),
        (this.scopedWindow =
          r || ("undefined" != typeof window ? window : void 0)),
        (this.macros = e || this.macros);
    }
    applies({ contextNode: e, features: t }) {
      const n = null != this.scopedWindow,
        i = null != t && 1 == t.on("ftPostRedirectMacros"),
        r =
          null != e &&
          null != e.getAttribute("data-ias-callback".toString()) &&
          Ba.test(e?.getAttribute("data-ias-callback".toString()) ?? "");
      return !!(n && i && r);
    }
    start({ contextNode: e }) {
      this.aggregator.on("impressionsent", () => {
        Ya({
          checkInterval: this.checkInterval,
          collectorTimeout: this.collectorTimeout,
          aggregator: this.aggregator,
          macros: this.macros,
          contextNode: e,
          scopedWindow: this.scopedWindow,
        });
      });
    }
  }
  class Xa {
    constructor({
      contextNode: e,
      features: t,
      bootstrapper: n,
      macroCollector: i,
    }) {
      (this.contextNode = e),
        (this.features = t),
        (this.macroCollectors = i || [new za({ macros: n.ftMacros })]);
    }
    start() {
      for (const e of this.macroCollectors)
        e.applies({ contextNode: this.contextNode, features: this.features }) &&
          e.start({ contextNode: this.contextNode });
    }
  }
  const Ja = (e) => {
    try {
      new Ka(e);
    } catch (e) {}
  };
  class Ka {
    constructor(e) {
      (this.context = e),
        (this.extractSignalsTriggered = !1),
        at.getAggregator().on("startViewabilityLoop", () => {
          this.extractSignalsTriggered ||
            ((this.extractSignalsTriggered = !0),
            Fi.setTimeout(() => {
              this.extractSignals();
            }, 250));
        });
    }
    extractSignals() {
      const e = this.detectEngine();
      this.executeDomlessSafeFunctions(),
        this.context.isDomless() || this.executeDomDependentFunctions(e);
    }
    executeDomlessSafeFunctions() {
      try {
        Za();
      } catch (e) {}
    }
    executeDomDependentFunctions(e) {
      try {
        Qa(e);
      } catch (e) {}
    }
    detectEngine() {
      return oc(this.context.isDomless());
    }
  }
  const Qa = (e) => {
      const t = [() => rc(e), cc, uc, gc, dc, sc, lc, mc, fc, pc];
      ("b" !== e && "e" !== e && "o" !== e) || t.push(Ac), t.push(Tc, Ec, Cc);
      const n = (e) => {
        if (e >= t.length) return;
        const i = t[e];
        if (i)
          try {
            i();
          } catch (e) {}
        Fi.setTimeout(() => n(e + 1), 10);
      };
      n(0);
    },
    Za = () => {
      ac();
    },
    ec = function (e, t) {
      at.getAggregator().trigger("addThrottledProp", "sca", e, t);
    },
    tc = (e, t) => {
      try {
        const n = Object.getOwnPropertyDescriptor(e, t);
        return !!n && "function" == typeof n.get;
      } catch {
        return !1;
      }
    },
    nc = (e, t) => {
      try {
        const n = (e) => {
            try {
              return void Date.prototype.getYear.call(e);
            } catch (e) {
              let t = e.message + "";
              t = t.replace(/\r?\n/g, "");
              const n = t.indexOf("function");
              return -1 !== n ? t.substring(n).trim() : t.trim();
            }
          },
          i = n(function () {
            return !0;
          });
        if (!(i?.includes("RANDOM_STRING") || !1)) {
          let n = Function.prototype.toString.call(e);
          return (n = n.replace(/\r?\n/g, "")), !t.test(n);
        }
        const r = n(e);
        return !(!r || t.test(r));
      } catch (e) {
        return !1;
      }
    },
    ic = (e) => e.replace(/[^A-Za-z0-9\-._~/|+*%]/g, ""),
    rc = (e) => {
      try {
        let t, n;
        const i = Error.prepareStackTrace,
          r = () => {
            let e = !1,
              r = !1;
            try {
              (t = new Error()),
                Object.defineProperty(t, "stack", {
                  configurable: !1,
                  enumerable: !1,
                  get: () => ((e = !0), ""),
                });
              try {
                (Error.prepareStackTrace = function () {
                  return (r = !0), "";
                }),
                  (Error.stackTraceLimit = 0),
                  (n = new Error()),
                  console.debug(t, n);
              } catch (e) {
              } finally {
                (Error.prepareStackTrace = i), (Error.stackTraceLimit = 10);
              }
            } catch (e) {}
            return { cdpDetected: e, cdpUpdatedDetected: r };
          },
          o = () => {
            try {
              throw new Error("");
            } catch (e) {
              return (e.stack + "").includes("*");
            }
          },
          s = {};
        if ("g" !== e) {
          const { cdpDetected: e, cdpUpdatedDetected: t } = r();
          e && (s.cdp = Qe(!0)),
            t && (s.ndp = Qe(!0)),
            (e || t) && ec("bdp", Ze(s).toION());
        }
        "g" === e && o() && ((s.rdp = Qe(!0)), ec("bdp", Ze(s).toION()));
      } catch (e) {}
    },
    oc = (e) => {
      let t;
      if (e) t = "d";
      else {
        t = "u";
        try {
          const e = Fi.getWindow(),
            n = Fi.getDoc();
          t = Xe(n.documentMode)
            ? "t"
            : Xe(e.netscape) && "MozAppearance" in n.documentElement.style
            ? "g"
            : Xe(e.opera) || Xe(e.opr) || Xe(e.chrome?.search)
            ? "o"
            : Xe(e.Blob) &&
              -1 !== e.Blob.prototype.toString().indexOf("BlobPrototype")
            ? "h"
            : Xe(e.external?.getHostEnvironmentValue) ||
              (Xe(n.documentElement?.style) &&
                -1 !==
                  Object.getOwnPropertyNames(n.documentElement.style).indexOf(
                    "msHighContrastAdjust"
                  )) ||
              Xe(e.speechSynthesis?.preload)
            ? "e"
            : (Xe(e.chrome) || Xe(e.PERSISTENT) || Xe(e.google?.gears)) &&
              -1 ===
                Object.prototype.toString
                  .call(HTMLElement)
                  .indexOf("Constructor")
            ? "b"
            : "webkitAppearance" in n.documentElement.style
            ? "w"
            : "u";
        } catch (e) {
          t = "u";
        }
      }
      return ec("eng", t), t;
    },
    sc = () => {
      const e = {
        exs: (() => {
          let e = "";
          try {
            (e = "" + Fi.getWindow().external),
              (e = "" === e ? "empty" : e.replace(/[[\]\s]/g, "")),
              (e = ic(e.substring(0, 50)));
          } catch (t) {
            e = "err";
          }
          return e;
        })(),
      };
      ec("exr", Ze(e).toION());
    },
    ac = () => {
      const e = {
        lts: (() => {
          try {
            const e = new Date(),
              t = e.getFullYear().toString(),
              n = ("0" + (e.getMonth() + 1)).slice(-2),
              i = ("0" + e.getDate()).slice(-2),
              r = ("0" + e.getHours()).slice(-2),
              o = ("0" + e.getMinutes()).slice(-2);
            return `${t}-${n}-${i}${r}.${o}.${("0" + e.getSeconds()).slice(
              -2
            )}`;
          } catch (e) {
            return "err";
          }
        })(),
        tzo: (() => {
          try {
            return new Date().getTimezoneOffset();
          } catch (e) {
            return -1;
          }
        })(),
        tzn: (() => {
          try {
            return ic(Intl.DateTimeFormat().resolvedOptions().timeZone);
          } catch (e) {
            return "err";
          }
        })(),
      };
      ec("tss", Ze(e).toION());
    },
    cc = () => {
      const e = {
        ori: Qe(
          (() => {
            let e = !1;
            try {
              e = Xe(Fi.getWindow().orientation);
            } catch (t) {
              e = !1;
            }
            return e;
          })()
        ),
        ges: Qe(
          (() => {
            let e = !1;
            try {
              const t = Fi.getWindow();
              e = Xe(t.GestureEvent);
            } catch (t) {
              e = !1;
            }
            return e;
          })()
        ),
        tch: Qe(
          (() => {
            let e = !1;
            try {
              e =
                Xe(Fi.getWindow().ontouchstart) || navigator.maxTouchPoints > 1;
            } catch (t) {
              e = !1;
            }
            return e;
          })()
        ),
      };
      ec("mob", Ze(e).toION());
    },
    dc = () => {
      const e = Fi.getWindow(),
        t = [
          {
            key: "not",
            check: () => !(!e.Notification && !e.webkitNotifications),
          },
          { key: "csi", check: () => !!e.chrome?.csi },
          { key: "msl", check: () => !!navigator.msLaunchUri },
          { key: "hdl", check: () => !!e.HTMLDataListElement },
          { key: "aps", check: () => !!e.ApplePaySession },
          { key: "hae", check: () => !!e.HTMLAudioElement },
          { key: "ito", check: () => !!e.IntersectionObserver },
          { key: "sec", check: () => !!e.isSecureContext },
          {
            key: "pha",
            check: () => !(!e.callPhantom && !e._phantom),
            sendIfTrue: !0,
          },
          {
            key: "plr",
            check: () => !(!e.__pwInitScripts && !e.__playwright__binding__),
            sendIfTrue: !0,
          },
        ],
        n = {};
      for (const { key: e, check: i, sendIfTrue: r } of t)
        try {
          const t = i();
          if (r && !t) continue;
          n[e] = Qe(t);
        } catch {
          n[e] = Qe(!1);
        }
      ec("prp", Ze(n).toION());
    },
    uc = () => {
      try {
        const e = () => {
            try {
              const e = Object.getOwnPropertyDescriptor(
                Navigator.prototype,
                "appName"
              );
              return !(!e || !e.get) && (e.get.call(navigator), !1);
            } catch (e) {
              return !0;
            }
          },
          t = {};
        navigator !== clientInformation && (t.nci = String(Qe(!0))),
          e() && (t.anc = String(Qe(!0))),
          (function (e) {
            try {
              return Date.prototype.getFullYear.call(e), !0;
            } catch (e) {
              return !!e.stack.includes("Proxy.getFullYear");
            }
          })(navigator) && (t.npx = String(Qe(!0))),
          Object.keys(t).length > 0 && ec("nic", Ze(t).toION());
      } catch (e) {}
    },
    lc = () => {
      let e,
        t = !1;
      try {
        const n = Fi.getTop()?.document,
          i = Object.getOwnPropertyDescriptor(n, "referrer");
        i &&
          "function" == typeof i.get &&
          ((t = !0),
          (e = i.get
            .toString()
            .replace(/[\n\r]/g, "")
            .substring(0, 50)),
          (e = ic(e)));
      } catch (e) {
        t = !1;
      }
      const n = {};
      t && ((n.tam = String(Qe(t))), e && (n.ref = e)),
        Object.keys(n).length > 0 && ec("ret", Ze(n).toION());
    },
    mc = () => {
      try {
        const e = Fi.getDoc(),
          t = tc(e, "visibilityState"),
          n = tc(e, "hidden");
        let i = !1;
        if ("undefined" != typeof IntersectionObserverEntry) {
          const e = Object.getOwnPropertyDescriptor(
            IntersectionObserverEntry.prototype,
            "isIntersecting"
          );
          if (e && "function" == typeof e.get) {
            const t = /isIntersecting\s*\(\)\s*\{\s*\[native\s+code\]\s*\}/;
            i = nc(e.get, t);
          }
        }
        const r = {};
        t && (r.vis = String(Qe(t))),
          n && (r.hid = String(Qe(n))),
          i && (r.itt = String(Qe(i))),
          Object.keys(r).length > 0 && ec("viw", Ze(r).toION());
      } catch (e) {}
    },
    gc = () => {
      try {
        const e = () => {
            try {
              const e = Object.getOwnPropertyDescriptor(
                Navigator.prototype,
                "webdriver"
              );
              if (e && "function" == typeof e.get) {
                const t =
                  /^function\s+(?:get\s+)?webdriver\(\)\s*{\s*\[native code\]\s*}$/;
                return nc(e.get, t);
              }
              return !1;
            } catch (e) {
              return !1;
            }
          },
          t = {};
        (() => {
          try {
            return navigator.hasOwnProperty("webdriver");
          } catch (e) {
            return !1;
          }
        })() && (t.wop = String(Qe(!0))),
          e() && (t.wgt = String(Qe(!0))),
          Object.keys(t).length > 0 && ec("wdt", Ze(t).toION());
      } catch (e) {}
    },
    pc = () => {
      try {
        const e = "ias-sb-10px",
          t = (t) => {
            let n = null;
            try {
              const i = Fi.getTopmostAccessibleWindow()?.document;
              if (!i) return null;
              const r = i.createElement("style");
              (r.textContent =
                "." + e + "::-webkit-scrollbar { width: 10px !important; }"),
                (i.head || i.documentElement).appendChild(r);
              const o = i.createElement("div");
              o.classList.add(e);
              const s = {
                left: "-10000px",
                top: "-10000px",
                width: "100px",
                height: "20px",
                visibility: "hidden",
              };
              t && (s.overflow = "scroll"), Jn.styleElement(o, s);
              const a = i.createElement("div"),
                c = { width: "100%", height: "1000px" };
              Jn.styleElement(a, c), o.appendChild(a), i.body.appendChild(o);
              const d = o.offsetWidth,
                u = o.clientWidth;
              ot(d) && ot(u) && (n = d - u),
                o.parentNode && o.parentNode.removeChild(o),
                r.parentNode && r.parentNode.removeChild(r);
            } catch (e) {}
            return n;
          },
          n = t(!0),
          i = t(!1);
        if (ot(n) || ot(i)) {
          const e = { wit: ot(n) ? n : "na", wot: ot(i) ? i : "na" };
          ec("dvw", Ze(e).toION());
        }
      } catch (e) {}
    },
    fc = () => {
      let e = 0,
        t = 0;
      try {
        let n = Fi.getWindow();
        const i = Fi.getTop();
        do {
          if (!n) break;
          if (n === i) break;
          const r = n.parent;
          e += 1;
          try {
            r.document;
          } catch (e) {
            t += 1;
          }
          n = r;
        } while (e < 20);
      } catch (n) {
        (e = -2), (t = -2);
      }
      ec("ifr", Ze({ act: e, eff: t }).toION());
    },
    hc = ["brands", "mobile", "platform"];
  function yc(e, t) {
    return Object.prototype.hasOwnProperty.call(e, t);
  }
  function vc(e) {
    return null == e ? "" : ic(String(e));
  }
  function Sc(e) {
    return Object.keys(e)
      .sort()
      .map((t) => `${vc(t)}~${vc(e[t])}`)
      .join("~");
  }
  function bc(e) {
    return Array.isArray(e)
      ? (function (e) {
          return e
            .map((e) => (e && "object" == typeof e ? Sc(e) : vc(e)))
            .join("/");
        })(e)
      : e && "object" == typeof e
      ? Sc(e)
      : vc(e);
  }
  function Ic(e) {
    return hc.every((t) => {
      return (
        !yc(e, t) ||
        null == (n = e[t]) ||
        "" === n ||
        (!!Array.isArray(n) && 0 === n.length)
      );
      var n;
    });
  }
  function wc() {
    const e = Fi.getWindow().navigator.userAgentData;
    if (e)
      return (function (e) {
        if (Je(e.toJSON)) return e.toJSON();
        const t = {};
        return (
          hc.forEach((n) => {
            yc(e, n) && (t[n] = e[n]);
          }),
          t
        );
      })(e);
  }
  function Ac() {
    const e = wc();
    if (!e) return;
    const t = {},
      n =
        ((i = e),
        hc
          .filter((e) => yc(i, e))
          .map((e) => `${e}~${bc(i[e])}`)
          .join("|"));
    var i;
    n && (t.uad = n),
      Ic(e) && (t.ent = String(Qe(!0))),
      Object.keys(t).length > 0 && ec("uai", Ze(t).toION());
  }
  const $c = (e) =>
      new Promise((t) => {
        try {
          const n = e.Notification?.permission;
          t(n ?? "na");
        } catch (e) {
          t("na");
        }
      }),
    Tc = () => {
      const e = Fi.getWindow();
      e?.isSecureContext &&
        Promise.all([
          new Promise((e) => {
            navigator.permissions && Je(navigator.permissions.query)
              ? navigator.permissions
                  .query({ name: "notifications" })
                  .then((t) => e(t.state))
                  .catch(() => e("na"))
              : e("na");
          }),
          $c(e),
        ])
          .then(([e, t]) => {
            ec("nit", Ze({ pqr: e, ntr: t }).toION());
          })
          .catch(() => {});
    },
    Ec = () => {
      try {
        const e = Fi.getDoc();
        if (!e) return;
        const t = ((e) => {
          const t = { probably: 2, maybe: 1, "": 0 },
            n = e.createElement("video");
          return [
            'video/mp4;codecs="avc1.42E01E, mp4a.40.2"',
            'video/mp4;codecs="avc1.58A01E, mp4a.40.2"',
            'video/mp4;codecs="avc1.4D401E, mp4a.40.2"',
            'video/mp4;codecs="avc1.64001E, mp4a.40.2"',
            'video/mp4;codecs="mp4v.20.8, mp4a.40.2"',
            'video/mp4;codecs="mp4v.20.240, mp4a.40.2"',
            'video/3gpp;codecs="mp4v.20.8, samr"',
            'video/ogg;codecs="theora, vorbis"',
            'video/ogg;codecs="theora, speex"',
            "audio/ogg;codecs=vorbis",
            "audio/ogg;codecs=speex",
            "audio/ogg;codecs=flac",
            'video/ogg;codecs="dirac, vorbis"',
            'video/x-matroska;codecs="theora, vorbis"',
            'video/mp4; codecs="avc1.42E01E"',
            'audio/mp4; codecs="mp4a.40.2"',
            'audio/mpeg;codecs="mp3"',
            'video/webm; codecs="vorbis,vp8"',
          ].map((e) => {
            const i = n.canPlayType(e);
            return t[i] ?? 0;
          });
        })(e);
        ec("cdc", Ze(t).toION());
      } catch (e) {}
    },
    Cc = () => {
      try {
        if (void 0 === window.speechSynthesis) return;
        let e = 0,
          t = 0,
          n = 0,
          i = !1,
          r = !1,
          o = !1;
        const s = window.speechSynthesis,
          a = (o, s = !1) => {
            if (o.length > 0) {
              const a = new Set();
              (t = o.filter((e) => !e.localService).length),
                (i = o.some((e) => e.name.includes("Chrome OS"))),
                (e = o.length),
                o.forEach((e) => a.add(e.lang)),
                (n = a.size),
                (r = s),
                c();
            }
          },
          c = () => {
            if (o) return;
            (o = !0), (s.onvoiceschanged = null);
            const a = { vct: e, rct: t, lct: n, cos: Qe(i), evt: Qe(r) };
            ec("spc", Ze(a).toION());
          },
          d = (e = !1) => {
            const t = s.getVoices();
            (t.length > 0 || e) && a(t, e);
          };
        d(),
          0 === e &&
            ((s.onvoiceschanged = () => d(!0)),
            Fi.setTimeout(() => {
              o || d(!0);
            }, 3e3));
      } catch (e) {}
    };
  try {
    !(function () {
      "use strict";
      try {
        (() => {
          const t = zn.isDomless(),
            n = Fi.getWindow(),
            i = new re({ contextNodeElement: e?.contextNode });
          oe.addModel(i);
          const r = new ee({
            isDomless: t,
            currentWindow: n,
            defaultBootstrapperConfig: e,
          });
          oe.addModel(r);
          const o = new l();
          oe.addModel(o);
          const s = r.isStaticFrameInFrame
              ? new re({ contextNodeElement: e?.currentScript })
              : i,
            a = new Q({ isDomless: t, contextNode: s, measurementConfig: r });
          oe.addModel(a);
          const u = new w({ contextNode: s, adTag: a });
          oe.addModel(u);
          const m = new no();
          oe.addModel(m);
          const p = new Z({ bootstrapper: e });
          oe.addModel(p);
          const f = new $t();
          oe.addModel(f);
          const h = new d({ currentWindow: n });
          oe.addModel(h);
          const y = new c();
          oe.addModel(y);
          const v = new g({
            windowObj: n,
            now: () => zn.getTagTime(),
            enabled: Boolean(o.useSingleEvent && r.isStaticMode),
            isDomless: t,
          });
          oe.addModel(v), v.init();
        })();
      } catch (e) {}
      e.perf.markStart(ct),
        oe.measurementConfig.set(
          "mainBirthdate",
          oe.measurementConfig.birthdate
            ? new Date().getTime() - oe.measurementConfig.birthdate
            : -1
        ),
        Wa(),
        at.startSystem();
      const t = at.getAggregator();
      t.provide({ omidAdSessionContext: {} }),
        t.provide({ omidAdSessionVerificationParameters: {} }),
        oe.measurementConfig.isResolved && t.provide("features", ui()),
        t.provide("browser", new xn().createInstance());
      const n = t.provide("ancestorOrigins", _n());
      t.provide("pageUrls", new Wi().createInstance(n, Fi));
      const i = si(),
        r = Vi(),
        o = new Vn().createInstance(i, r),
        s = new vi();
      t.provide({ mErrors: i, mJsonp: r, mComm: o, ids: s });
      const a = __IASOmidVerificationClient;
      t.provide({ omidVerificationClient: a });
      const u = [
        { environment: Lr(a), adSessionReadyStrategy: Kr(a) },
        { environment: Qr(), adSessionReadyStrategy: eo() },
      ];
      new Jr(u).resolve().adSessionReadyStrategy.start(), e.perf.markEnd(ct);
    })();
  } catch (t) {
    __IntegralASDiagnosticCall("main", t, e);
  }
};
try {
  !(function () {
    var e = __IntegralASConfig.useFIF ? __IASScope.parent : __IASScope;
    try {
      (top.__IntegralASAdPush = function (t) {
        (t || (top.isSingleIASInstance && top.iasAdSlots)).forEach(function (
          t
        ) {
          (__IntegralASConfig._cl_adpath = t.adSelector),
            (__IntegralASConfig.iasParameters = t.iasParameters),
            __IntegralASConfig.initialize(__IntegralASConfig, e, e.document);
        });
      }),
        top.isSingleIASInstance && top.iasAdSlots
          ? top.__IntegralASAdPush()
          : __IntegralASConfig.initialize(__IntegralASConfig, e, e.document);
    } catch (t) {
      __IntegralASConfig.initialize(__IntegralASConfig, e, e.document);
    }
  })();
} catch (e) {
  __IntegralASDiagnosticCall("initialize", e, __IntegralASConfig);
}
