!(function () {
  "use strict";
  var e,
    t = "vast",
    i = "time",
    r = "paused",
    a = "playing",
    n = "fullscreen",
    s = "volume",
    o = "mute",
    l = "viewable",
    d = "resize",
    h = "adClick",
    u = "adComplete",
    c = "adError",
    p = "adImpression",
    f = "adItem",
    m = "adLoadedXML",
    v = "mediaLoaded",
    g = "adMeta",
    y = "adPause",
    k = "adPlay",
    A = "adPlayComplete",
    P = "adPodError",
    w = "adSkipped",
    b = "adStarted",
    E = "clickthrough",
    T = "external",
    _ = T,
    I = "click",
    C = "play",
    S = "error",
    R = "complete",
    x = [p, c, P],
    j = [b, u, p, h, w, c, k, y, g],
    M = "instream",
    O = "article",
    V =
      (((e = {})[[M]] = 1),
      (e[["banner"]] = 2),
      (e[[O]] = 3),
      (e[["feed"]] = 4),
      (e[["floating"]] = 5),
      (e[["interstitial"]] = 5),
      (e[["slider"]] = 5),
      e);
  function B() {
    return (
      (B =
        Object.assign ||
        function (e) {
          for (var t = 1; t < arguments.length; t++) {
            var i = arguments[t];
            for (var r in i)
              Object.prototype.hasOwnProperty.call(i, r) && (e[r] = i[r]);
          }
          return e;
        }),
      B.apply(this, arguments)
    );
  }
  var L = (function () {
    function e(e, t, i) {
      (this.debugTrackFn = e),
        (this.div = null),
        (this.elem = null),
        (this.environment = t),
        (this.utils = i);
    }
    var t = e.prototype;
    return (
      (t.addCompanion = function (e, t) {
        if (
          ((this.div = e),
          (this.elem = document.getElementById(this.div.id)),
          !this.elem)
        )
          return !1;
        for (var i = 0; i < t.length; i++)
          if (this.fitsDiv(t[i])) return this.placeCompanion(t[i]), !0;
        return !1;
      }),
      (t.removeCompanion = function () {
        this.elem.innerHTML = "";
      }),
      (t.sendPings = function (e) {
        (e = e.creativeView) &&
          (e.forEach(function (e) {
            new Image().src = e;
          }),
          "function" == typeof this.debugTrackFn &&
            this.debugTrackFn({ type: "companion", data: { trackers: e } }));
      }),
      (t.placeCompanion = function (e) {
        var t = this;
        if ((this.removeCompanion(), "html" === e.type)) {
          var i = document.createElement("div");
          i.innerHTML = e.source;
          var r = i.getElementsByTagName("script");
          return (
            r.length &&
              r.forEach(function (e) {
                new t.utils.scriptloader(e.src).load(),
                  e.parentElement.removeChild(e);
              }),
            this.elem.appendChild(i),
            void this.sendPings(e.trackers)
          );
        }
        if ("iframe" === e.type) {
          var a = document.createElement("iframe");
          return (
            (a.height = this.div.height),
            (a.width = this.div.width),
            (a.src = e.source),
            (a.scrolling = "no"),
            (a.style.border = "none"),
            (a.marginWidth = 0),
            (a.marginHeight = 0),
            this.sendPings(e.trackers),
            (this.elem.innerHTML = ""),
            void this.elem.appendChild(a)
          );
        }
        if ("application/x-shockwave-flash" === e.type) {
          var n = document.createElement("object");
          return (
            n.setAttribute("type", "application/x-shockwave-flash"),
            n.setAttribute("data", e.source),
            n.setAttribute("width", "100%"),
            n.setAttribute("height", "100%"),
            n.setAttribute("tabindex", 0),
            H(n, "allowfullscreen", "true"),
            H(n, "allowscriptaccess", "always"),
            H(n, "seamlesstabbing", "true"),
            H(n, "wmode", "opaque"),
            this.elem.appendChild(n),
            void this.sendPings(e.trackers)
          );
        }
        var s = new Image();
        (s.src = e.source),
          e.clickthrough &&
            (s.onclick = function () {
              t.utils.openLink(e.clickthrough, "_blank", { rel: "noreferrer" });
            }),
          (this.elem.innerHTML = ""),
          this.elem.appendChild(s),
          this.sendPings(e.trackers);
      }),
      (t.fitsDiv = function (e) {
        return e.width === this.div.width && e.height === this.div.height;
      }),
      e
    );
  })();
  function H(e, t, i) {
    var r = document.createElement("param");
    r.setAttribute("name", t), r.setAttribute("value", i), e.appendChild(r);
  }
  var D = document.createElement("img"),
    q = document.createElement("img");
  (D.src = q.src =
    'data:image/svg+xml;charset=UTF-8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><circle cx="32" cy="32" r="32" fill="%23191919"/><line stroke="%23CCC" stroke-width="6" x1="32" y1="20" x2="32" y2="44"/><line stroke="%23CCC" stroke-width="6" x1="20" y1="32" x2="44" y2="32"/></svg>'),
    (D.className = "jw-vast-nonlinear-open-button"),
    (q.className = "jw-vast-nonlinear-close-button");
  var N = (function () {
      function e(e, t, i, r, a) {
        (this.player = e),
          (this.environment = e.getEnvironment()),
          (this.div = r),
          (this.staticURL = t),
          (this.clickURL = i),
          (this.loadTimer = -1),
          (this.animationTimer = -1),
          (this.banner = null),
          B(this, e.Events),
          (this.banner = document.createElement("img")),
          (this.banner.className = "jw-banner"),
          (this.banner.id = this.player.id + "_vast_static"),
          this.div.appendChild(D),
          this.div.appendChild(this.banner),
          this.div.appendChild(q),
          (this.loadTimer = setTimeout(this.imageLoadError.bind(this), a)),
          (this.banner.onerror = this.imageLoadError.bind(this)),
          (this.banner.onload = this.onLoaded.bind(this)),
          (this.banner.src = this.staticURL);
      }
      var t = e.prototype;
      return (
        (t.onLoaded = function () {
          if ((clearTimeout(this.loadTimer), 0 !== this.banner.naturalWidth)) {
            this.removeBannerEventListeners();
            var e = this.player.utils;
            e.addClass(this.div, "jw-vast-nonlinear-active"),
              e.style(
                q,
                { bottom: this.banner.height - 8, left: this.banner.width },
                !0
              ),
              new e.UI(this.banner).on("click", this.sendClick.bind(this)),
              (q.onclick = q.ontouchstart = this.collapse.bind(this)),
              (D.onclick = D.ontouchstart = this.expand.bind(this)),
              this.trigger(C);
          } else this.imageLoadError();
        }),
        (t.imageLoadError = function () {
          clearTimeout(this.loadTimer), this.trigger(S), this.removeBanner();
        }),
        (t.sendClick = function () {
          this.trigger(I);
        }),
        (t.collapse = function (e) {
          var t = this;
          e.preventDefault(),
            this.player.utils.addClass(this.div, "jw-vast-nonlinear-collapsed"),
            (this.animationTimer = setTimeout(function () {
              t.remove(t.banner), t.remove(q), (t.animationTimer = -1);
            }, 250));
        }),
        (t.expand = function (e) {
          -1 === this.animationTimer &&
            (e.preventDefault(),
            this.player.utils.removeClass(
              this.div,
              "jw-vast-nonlinear-collapsed"
            ),
            this.div.appendChild(this.banner),
            this.div.appendChild(q));
        }),
        (t.remove = function (e) {
          this.div.contains(e) && this.div.removeChild(e);
        }),
        (t.removeBannerEventListeners = function () {
          this.banner.onload = this.banner.onerror = null;
        }),
        (t.removeBanner = function () {
          this.removeBannerEventListeners(), this.remove(this.banner);
        }),
        (t.removeListeners = function () {
          clearTimeout(this.loadTimer),
            clearTimeout(this.animationTimer),
            (q.onclick = q.ontouchstart = D.onclick = D.ontouchstart = null),
            this.off(),
            this.removeBannerEventListeners();
        }),
        (t.stop = function () {
          this.player.utils.removeClass(
            this.div,
            "jw-vast-nonlinear-active jw-vast-nonlinear-collapsed"
          ),
            this.removeBanner(),
            this.remove(q),
            this.remove(D);
        }),
        e
      );
    })(),
    F = (function () {
      function e(e, t) {
        (this.player = e),
          (this.div = t),
          (this.startTime = 0),
          (this.minDur = 0),
          (this.environment = e.getEnvironment()),
          B(this, e.Events),
          (this.type = "static"),
          e.on("time", this.dispatchTime, this);
      }
      var t = e.prototype;
      return (
        (t.playAd = function (e, t, i, r, a) {
          (this.minDur = this.player.utils.seconds(i)),
            (this.adTag = r),
            this.static && (this.static.removeListeners(), this.static.stop()),
            this.player.utils.addClass(this.div, "jw-vast-nonlinear"),
            (this.static = new N(this.player, e, t, this.div, a)),
            this.static.on(C, this.startAd, this),
            this.static.on(I, this.clickHandler, this),
            this.static.on(S, this.errorHandler, this);
        }),
        (t.dispatchTime = function (e) {
          this.trigger(i, e);
        }),
        (t.startAd = function () {
          (this.startTime = this.player.getPosition()),
            this.minDur > 0 &&
              (0 === this.startTime
                ? this.on(i, this.startTimingAd, this)
                : this.on(i, this.timeAd, this)),
            this.sendEvent(C);
        }),
        (t.startTimingAd = function (e) {
          (this.startTime = e.position),
            this.off(i, this.startTimingAd, this),
            this.on(i, this.timeAd, this);
        }),
        (t.timeAd = function (e) {
          e.position - this.startTime > this.minDur &&
            (this.off(i, this.timeAd, this), this.stop());
        }),
        (t.clickHandler = function () {
          this.sendEvent(I);
        }),
        (t.errorHandler = function () {
          this.sendEvent(S);
        }),
        (t.sendEvent = function (e, t) {
          ((t = t || {}).tag = t.tag || this.adTag), this.trigger(e, t);
        }),
        (t.removeEvents = function () {
          this.off();
        }),
        (t.getState = function () {
          return a;
        }),
        (t.stop = function () {
          this.startTime &&
            this.static &&
            ((this.startTime = 0),
            (this.minDur = 0),
            this.off(i, this.startTimingAd, this),
            this.off(i, this.timeAd, this),
            this.static.removeListeners(),
            this.static.stop(),
            this.sendEvent(R));
        }),
        (t.pause = function () {}),
        e
      );
    })(),
    U =
      /^(https?:\/\/).*.(?:ampproject.org|bing-amp.com)\/(?:.\/)*(.*)\/amp.*$/;
  var Q = new RegExp(/^[^/]*:\/\/\/?([^\/]*)/);
  function X(e) {
    var t = e.match(Q);
    return t && t.length > 1 ? t[1] : "";
  }
  var W,
    z = new RegExp(/^[^:\/?#]+:?\/\/[^\/?#]+/);
  function G() {
    var e,
      t,
      i =
        null !== document.referrer.match(z)
          ? ((e = document.referrer),
            (t = e.match(U)) && t.length > 1 ? "" + t[1] + t[2] : e)
          : "";
    if (window.top !== window.self) {
      try {
        return {
          url: window.top.location.href,
          domain: window.top.document.domain,
          referrer: i,
        };
      } catch (e) {}
      return { url: i, domain: X(i), referrer: "" };
    }
    return {
      url: document.location.href,
      domain: document.domain,
      referrer: i,
    };
  }
  function J(e) {
    var t = e.advertising;
    if (t && t.placement) {
      var i = t.placement.toLowerCase();
      if (V[i]) return V[i];
    }
    return V[t && t.outstream ? O : M];
  }
  function $(e, t, i, r) {
    var a = Y(e, i, r),
      n = t.adErrorCode || 60900;
    return (
      B(a, {
        message: t.message,
        code: t.code >= 100 && t.code <= 1008 ? t.code : 900,
        adErrorCode: n,
      }),
      10402 === n || 50004 === n || 50400 === n
        ? (a.timeout = i ? i.creativeTimeout : r.creativeTimeout)
        : (11007 !== n && 10301 !== n && 60006 !== n) ||
          (a.timeout = i ? i.requestTimeout : r.requestTimeout),
      void 0 !== t.id && (a.id = t.id),
      void 0 !== t.sourceError && (a.sourceError = t.sourceError),
      void 0 !== t.tag && (a.tag = t.tag),
      void 0 !== t.vmap && (a.vmap = t.vmap),
      a
    );
  }
  function Y(e, i, r) {
    void 0 === i && (i = null), void 0 === r && (r = {});
    var a = { client: t };
    if (null === e) return a;
    var n = e.bidding,
      s = e.config,
      o = e.item,
      l = e.player;
    e.isDestroyed() || (a.placement = J(l.getConfig()));
    var d = r.schedule;
    if (d)
      return B(a, {
        item: o,
        tag: d.getVMAP(),
        adbreaks: d.getAllAds().map(function (e) {
          var t = { type: e._type, offset: e._offSet };
          if (
            (e._vmap ? (t.vmap = e._vmap) : (t.adbreak = B({}, e._adbreak)), n)
          ) {
            var i = n.getBid(e.adPlayId);
            i && B(t, i.getEventObject());
          }
          return t;
        }),
      });
    if (
      (s.preloadAds && (a.preloadAds = r.preload || (i && i._preload) || !1),
      r.jwpseg && (a.jwpseg = r.jwpseg),
      i)
    ) {
      var h = e.getAdIds(i, r),
        u = h.adBreakId,
        c = h.adPlayId;
      if ((B(a, { adBreakId: u, adPlayId: c, offset: i._offSet }), n)) {
        var p = n.getBid(c);
        p && B(a, p.getEventObject());
      }
    }
    var f = i && (r.tag || i._currentTag);
    if (
      (f &&
        (B(a, {
          id: i._id,
          tag: f,
          adposition: i._position,
          sequence: i._adPodIndex + 1,
          witem: i._waterfallIndex + 1,
          wcount: i._adQueue ? i._adQueue.length : 1,
          adsystem: i.adsystem || "",
        }),
        i.adServingId && (a.adServingId = i.adServingId),
        void 0 !== i.skipoffset && (a.skipoffset = i.skipoffset),
        i.wrappedTags &&
          B(a, {
            wrapperAdSystem: i.wrapper || "",
            wrappedTags: i.wrappedTags.slice(1),
          }),
        i._adbreak &&
          ((a.adschedule = i._adbreak), (a.adschedule.offset = i._offSet))),
      i && i.companions && r.companions)
    )
      return (a.companions = r.companions), a;
    if (i && i.response) {
      var m = e.params;
      B(a, {
        adtitle: i.adTitle || "",
        description: i.description || "",
        adId: i.adId || "",
        adVerifications: i.adVerifications || null,
        advertiser: i.advertiser || "",
        advertiserId: i.advertiserId || "",
        creativeId: i.creativeId || "",
        creativeAdId: i.creativeAdId || "",
        dealId: i.dealId || "",
        request: i.request,
        response: i.response,
        conditionalAd: i.conditionalAd,
        conditionalAdOptOut: m.conditionaladoptout,
        vastversion: i.vastversion,
        clickThroughUrl: i.clickthrough,
        duration: r.duration,
        linear: r.linear,
      }),
        "boolean" == typeof i.mediaFileCompliance &&
          ((a.mediaFileCompliance = i.mediaFileCompliance),
          i.nonComplianceReasons &&
            (a.nonComplianceReasons = i.nonComplianceReasons)),
        i.selectedMedia && (a.mediafile = { file: i.selectedMedia.file }),
        r.metadata &&
          ((a.adMessage = m.dynamicMessage || ""),
          i.companions && (a.companions = i.companions),
          i.sequence && (a.podMessage = m.podMessage || ""),
          void 0 !== i.skipoffset &&
            B(a, { skipMessage: m.skipMessage, skipText: m.skipText }));
    } else a.item = o;
    return a;
  }
  function K(e) {
    return e.isBeforePlay() ||
      (0 === e.getPosition() && "idle" === e.getState())
      ? "pre"
      : e.isBeforeComplete() || e.getPosition() === e.getDuration()
      ? "post"
      : "mid";
  }
  function Z(e, t) {
    return (
      (Z =
        Object.setPrototypeOf ||
        function (e, t) {
          return (e.__proto__ = t), e;
        }),
      Z(e, t)
    );
  }
  var ee = "vast",
    te = "googima",
    ie = "[ERRORCODE]",
    re = "vmap",
    ae = "-1",
    ne = "cust_params=",
    se = 5e3,
    oe = 5e3,
    le = "adBreakIgnored",
    de = "adError",
    he = "__jwpseg__",
    ue = "instream",
    ce = "article",
    pe =
      (((W = {})[[ue]] = 1),
      (W[["banner"]] = 2),
      (W[[ce]] = 3),
      (W[["feed"]] = 4),
      (W[["floating"]] = 5),
      (W[["interstitial"]] = 5),
      (W[["slider"]] = 5),
      W),
    fe = new RegExp(/^[^/]*:\/\/\/?([^/]*)/);
  function me(e) {
    var t = e.match(fe);
    return t && t.length > 1 ? t[1] : "";
  }
  var ve = new RegExp(/^[^:/?#]+:?\/\/[^/?#]+/);
  var ge =
    /^(https?:\/\/).*.(?:ampproject.org|bing-amp.com)\/(?:.\/)*(.*)\/amp.*$/;
  function ye(e) {
    var t = new RegExp("[?&]" + e + "=([^&]*)"),
      i = document.location.search.match(t);
    if (i) return decodeURIComponent(i[1]);
  }
  var ke = null,
    Ae = { gdprApplies: !0, consentData: "" },
    Pe = function (e) {
      return (
        void 0 === e && (e = 1e3),
        null === ke &&
          (ke = new Promise(function (e) {
            var t = window.__tcfapi || we("__tcfapi");
            if (t)
              return t("getTCData", 2, function (t, i) {
                e(
                  !1 !== i
                    ? {
                        gdprApplies: t.gdprApplies,
                        consentData: t.tcString,
                        addtlConsent: t.addtlConsent,
                      }
                    : null
                );
              });
            var i = window.__cmp || we("__cmp");
            if (i)
              return i("getConsentData", null, function (t, i) {
                e(
                  !1 !== i
                    ? {
                        gdprApplies: t.gdprApplies || t.isUserInEu,
                        consentData: t.consentData,
                      }
                    : null
                );
              });
            var r = (function () {
              if (ye("isAMP")) {
                var e = ye("consentValue"),
                  t = ye("consentGdpr");
                if (e || t) return { gdprApplies: t, consentData: e };
              }
            })();
            return e(r || { gdprApplies: !1, consentData: "" });
          }).then(function (e) {
            return e && (Ae = e), Ae;
          })),
        Promise.race([
          ke,
          new Promise(function (t) {
            setTimeout(t, e, Ae);
          }),
        ])
      );
    },
    we = function (e) {
      var t = (function (e) {
        for (var t = window; t; ) {
          try {
            if (t.frames[e]) break;
          } catch (e) {}
          t = t === window.top ? null : t.parent;
        }
        return t;
      })(e + "Locator");
      return (
        null !== t &&
        function (i, r, a, n) {
          var s,
            o,
            l = be();
          window.addEventListener(
            "message",
            function t(i) {
              var r = i ? i.data : {};
              if ("string" == typeof r)
                try {
                  r = JSON.parse(r);
                } catch (e) {
                  r = {};
                }
              var n = e + "Return";
              r[n] &&
                r[n].callId === l &&
                (removeEventListener("message", t),
                a(r[n].returnValue, r[n].success));
            },
            !1
          );
          var d =
            (((o = {})[[e + "Call"]] =
              (((s = { command: i, callId: l, parameter: n })[
                [void 0 !== n ? "version" : "parameter"]
              ] = r),
              s)),
            o);
          t.postMessage(JSON.stringify(d), "*");
        }
      );
    },
    be =
      Date.now ||
      function () {
        return new Date().getTime();
      };
  function Ee(e) {
    var t = e.advertising;
    if (t && t.placement) {
      var i = t.placement.toLowerCase();
      if (pe[i]) return pe[i];
    }
    return pe[t && t.outstream ? ce : ue];
  }
  function Te() {
    var e,
      t,
      i =
        null !== document.referrer.match(ve)
          ? ((e = document.referrer),
            (t = e.match(ge)) && t.length > 1 ? "" + t[1] + t[2] : e)
          : "";
    if (window.top !== window.self) {
      try {
        return {
          url: window.top.location.href,
          domain: window.top.document.domain,
          referrer: i,
        };
      } catch (e) {}
      return { url: i, domain: me(i), referrer: "" };
    }
    return {
      url: document.location.href,
      domain: document.domain,
      referrer: i,
    };
  }
  function _e(e, t) {
    var i,
      r = e.getPlugin("inference"),
      a = t.jwpseg_client_side,
      n = t.jwpseg || [];
    if (!a || !a.length || !r) return n;
    try {
      i = r.predict(a, t);
    } catch (e) {
      return t.jwpseg || [];
    }
    var s = Object.keys(i).filter(function (e) {
        return i[e];
      }),
      o = n.filter(function (e) {
        return -1 === a.indexOf(e);
      });
    return [].concat(s, o);
  }
  function Ie(e, t, i) {
    void 0 === t && (t = null), void 0 === i && (i = {});
    var r = { client: e.client },
      a = e.bidding,
      n = e.item,
      s = e.player;
    if (
      (e.isDestroyed() ||
        B(r, { placement: Ee(s.getConfig()), viewable: s.getViewable() }),
      i.jwpseg && (r.jwpseg = i.jwpseg),
      t)
    ) {
      var o = e.getAdIds(t, i),
        l = o.adBreakId,
        d = o.adPlayId;
      if ((B(r, { adBreakId: l, adPlayId: d, offset: t._offSet }), a)) {
        var h = a.getBid(d);
        h && B(r, h.getEventObject());
      }
    }
    return (r.item = n), r;
  }
  function Ce(e, t, i, r) {
    return {
      client: r,
      message: e,
      adErrorCode: t,
      id: ae,
      placement: Ee(i),
      tag: "",
    };
  }
  var Se =
    /^((https?:)?\/\/)?(secure)?pubads\.g\.doubleclick\.net\/gampad\/ads\?[\S]*$/;
  function Re(e, t, i, r, a, n) {
    if ((void 0 === n && (n = {}), !e)) return Promise.resolve(e);
    var s = (function (e, t) {
        var i = e.getConfig(),
          r = e.getPlaylistItem() === t,
          a = {
            playerHeight: e.getHeight() || i.height || "",
            playerWidth: e.getWidth() || i.width || "",
            itemDuration: (r && je(e.getDuration(), 3)) || "",
            item: t,
            jwpseg: _e(e, t),
            placement: Ee(i),
            userAgent: navigator.userAgent,
          },
          n = i.advertising ? i.advertising.ampMacros : {};
        return B(a, n);
      })(t, i),
      o = Te();
    -1 !== e.indexOf(he) && (n.jwpseg = s.jwpseg),
      (e = xe(e, "__random-number__", Math.random() * Math.pow(10, 18))),
      (e = xe(e, "__timestamp__", new Date().getTime())),
      (e = xe(e, "__page-url__", encodeURIComponent(s.pageUrl || o.url))),
      (e = xe(e, "__referrer__", encodeURIComponent(s.referrer || o.referrer))),
      (e = xe(e, "__player-height__", s.playerHeight)),
      (e = xe(e, "__player-width__", s.playerWidth)),
      (e = xe(e, "__item-duration__", s.itemDuration)),
      (e = xe(e, he, s.jwpseg)),
      (e = xe(e, "__domain__", encodeURIComponent(s.domain || o.domain))),
      (e = xe(e, "__placement__", s.placement)),
      (e = xe(e, "__device-ua__", encodeURIComponent(s.userAgent))),
      (e = a.companion
        ? xe(e, "__companion-div__", a.companion.id)
        : xe(e, "__companion-div__", ""));
    for (
      var l = Object.keys(s).filter(function (e) {
          return -1 !== e.indexOf("item");
        }),
        d = l.map(function (e) {
          var t = e.match(/item([\w]+?)(List)?$/);
          if (t) return t[1].toLowerCase();
        }),
        h = null,
        u = /__item-([\w-]+?)(-list)?__/g,
        c = e;
      null !== (h = u.exec(c));

    ) {
      var p = h[0],
        f = h[1],
        m = l[d.indexOf(f)],
        v = "";
      if ((i.hasOwnProperty(f) && "string" == typeof i[f]) || m) {
        v = m ? s[m] : i[f];
        var g = !1 === a.truncateMacros ? 4096 : 1e3;
        v.length > g && (v = v.substring(0, g));
        var y = h[2] ? "," : null;
        v = v.split(y).map(encodeURIComponent);
      }
      e = xe(e, p, v);
    }
    if (r === ee) {
      var k = t.getConfig().autostart ? 1 : 0,
        A = t.getMute() ? 1 : 0;
      e = (function (e, t, i) {
        Se.test(e) && (e = e + "&vpa=" + t + "&vpmute=" + i);
        return e;
      })(e, k, A);
    }
    if (r === te && i.title && -1 === e.indexOf("vid_t=")) {
      var P = i.title.substring(0, 100).replace(/[^\x00-\x7F]/g, "");
      e +=
        (function (e) {
          return -1 !== e.indexOf("?") ? "&" : "?";
        })(e) +
        "vid_t=" +
        encodeURIComponent(P);
    }
    return -1 !== e.indexOf("__gdpr__") ||
      -1 !== e.indexOf("__gdpr_consent__") ||
      -1 !== e.indexOf("__addtl_consent__")
      ? Pe()
          .then(function (t) {
            var i = t.gdprApplies,
              r = t.consentData,
              a = t.addtlConsent;
            return (
              (e = xe(e, "__gdpr__", i ? 1 : 0)),
              (e = xe(e, "__addtl_consent__", a || "")),
              xe(e, "__gdpr_consent__", r || "")
            );
          })
          .catch(function () {
            return e;
          })
      : Promise.resolve(e);
  }
  function xe(e, t, i) {
    return e.replace(t, i);
  }
  function je(e, t) {
    var i = Math.pow(10, t);
    return Math.round(e * i) / i;
  }
  var Me = Array.prototype,
    Oe = Me.forEach,
    Ve = Me.map,
    Be = function () {};
  function Le(e, t, i) {
    if (Ue(e, "VMAP", re).length)
      return (function (e, t, i) {
        var r = [];
        We(Ue(e, "VMAP", re)[0], "version") ||
          qe(r, "VMAP Schema Error: version missing from VMAP tag", ae);
        var a = Ue(e, "AdBreak", re);
        a.length || Ne();
        for (
          var n = e.lookupNamespaceURI(re), s = {}, o = 0;
          o < a.length;
          o++
        ) {
          var l = {},
            d = {},
            h = a[o],
            u = We(h, "timeOffset"),
            c = We(h, "breakId"),
            p = We(h, "breakType"),
            f = We(Ue(h, "AdSource", re)[0], "id"),
            m = Ue(h, "AdTagURI", re)[0],
            v = Ue(h, "VASTData", re)[0] || Ue(h, "VASTAdData", re)[0],
            g = We(m, "templateType"),
            y = Ge(m),
            k = Xe(n, h, "Tracking", re);
          if (
            (p || qe(r, "VMAP Schema Error: missing breakType on AdBreak", c),
            v ||
              g ||
              qe(r, "VMAP Schema Error: missing templateType on AdBreak", c),
            u || qe(r, "VMAP Schema Error: missing timeOffset on AdBreak", c),
            (l._type = p),
            (l._vmap = { id: f, breakid: c, timeoffset: u }),
            v)
          )
            l._adXML = He(Qe(v, "VAST"));
          else {
            if ("vast2" !== g && "vast3" !== g && "vast4" !== g) continue;
            (l._adQueue = [y]), (l._waterfallIndex = 0);
          }
          var A = [];
          if (k)
            for (var P = 0; P < k.length; P++) {
              ze(d, k[P]);
              var w = We(k[P], "event");
              A.push(w);
            }
          if (
            ((A.indexOf("breakStart") < 0 ||
              A.indexOf("breakEnd") < 0 ||
              A.indexOf("error") < 0) &&
              qe(
                r,
                "Tracking events are missing breakStart, breakEnd, or error for AdBreak",
                c
              ),
            (l._trackers = d),
            (l._type = p),
            u && !s[u])
          )
            (s[u] = l), (s[u]._pod = l._adQueue ? [].concat(l._adQueue) : []);
          else if (u && s[u]) {
            var b;
            if (l._adQueue) (b = s[u]._pod).push.apply(b, l._adQueue);
          }
        }
        Object.keys(s).forEach(function (e) {
          var r = s[e];
          switch ((r._pod && r._pod.length <= 1 && delete r._pod, e)) {
            case "start":
              (r._offSet = "pre"), t.setPreRoll(r);
              break;
            case "100%":
            case "end":
              (r._offSet = "post"), t.setPostRoll(r);
              break;
            default:
              if (/^#/.test(e)) break;
              /^\d\d?(?:\.\d+)?%$/.test(e)
                ? (r._offSet = e)
                : (r._offSet = i.seconds(e)),
                t.addMidRoll(r);
          }
        }),
          t.preRoll || t.midRolls.length || t.postRoll || Ne();
        return t.sort(null, !0), r;
      })(e, t, i);
    if (Ue(e, "Playlist", re).length)
      return (function (e, t, i) {
        var r = Ue(e, "Playlist", re)[0],
          a = r.getElementsByTagName("Preroll")[0],
          n = r.getElementsByTagName("Postroll")[0],
          s = De(a, "pre"),
          o = De(n, "post");
        s && t.setPreRoll(s);
        o && t.setPostRoll(o);
        for (
          var l = r.getElementsByTagName("Midroll"), d = 0;
          d < l.length;
          d++
        ) {
          var h = l[d],
            u = i.seconds(h.getAttribute("timeOffset")),
            c = De(h, u);
          t.addMidRoll(c);
        }
        return [];
      })(e, t, i);
    throw new Error("No VMAP tag in response");
  }
  function He(e) {
    return e.ownerDocument instanceof Document
      ? e.outerHTML || new XMLSerializer().serializeToString(e)
      : null;
  }
  function De(e, t) {
    if (!e) return null;
    var i = e.getElementsByTagName("Ad");
    if (!i.length) return null;
    var r = { _offSet: t };
    if (1 === i.length) r._adQueue = [i[0].textContent.trim()];
    else {
      r._pod = [];
      for (var a = 0; a < i.length; a++) r._pod.push(i[a].textContent.trim());
    }
    return r;
  }
  function qe(e, t, i) {
    e.push({ message: t, code: 1002, adErrorCode: 70001, id: i });
  }
  function Ne() {
    var e = new Error("No AdBreaks in VMAP");
    throw ((e.adErrorCode = 60005), e);
  }
  var Fe = (function () {
    function e(e, t) {
      (this.utils = t),
        (this._error = null),
        (this._version = null),
        e && this.parse(e);
    }
    var t = e.prototype;
    return (
      (t.error = function () {
        return this._error;
      }),
      (t.version = function () {
        return this._version;
      }),
      (t.parse = function (e, t) {
        var i,
          r = this;
        "VAST" === e.nodeName
          ? (i = e)
          : (i = Qe(e, "VAST")) || (i = Qe(e, "VideoAdServingTemplate")),
          i || this.throwError(101, "Invalid VAST response");
        var a =
          "VideoAdServingTemplate" === i.tagName
            ? 1
            : parseFloat(We(i, "version") || 0);
        this._version = a;
        var n,
          s = Ue(i, "Ad"),
          o = Ve.call(s, function (i) {
            var n = r.parseAd(a, i);
            return (
              (n.vastversion = a), (n.response = e), (n.request = t || null), n
            );
          });
        return (
          o.length ||
            ((n = Ue(i, "Error")),
            Oe.call(n, function (e) {
              var t = Ge(e).replace(ie, 303);
              new Image().src = t;
            })),
          o
        );
      }),
      (t.parseAd = function (e, t, i) {
        i = i || {};
        var r,
          a,
          n,
          s,
          o,
          l = Qe(t, "InLine"),
          d = Qe(t, "Wrapper"),
          h = l || d,
          u = Qe(h, "Advertiser"),
          c = Qe(h, "AdVerifications");
        return (
          c &&
            (i.adVerifications =
              ((a = Ue(c, "Verification")),
              (n = []),
              Oe.call(a, function (e) {
                var t = We(e, "vendor"),
                  i = Qe(e, "JavaScriptResource"),
                  r = Qe(e, "ExecutableResource"),
                  a = Ge(Qe(e, "VerificationParameters")),
                  s = Ue(Qe(e, "TrackingEvents"), "Tracking"),
                  o = {},
                  l = { vendor: t, verificationParameters: a, trackers: o };
                i &&
                  (l.javaScriptResource = {
                    url: Ge(i),
                    apiFramework: We(i, "apiFramework"),
                    browserOptional: We(i, "browserOptional"),
                  }),
                  r &&
                    (l.executableResource = {
                      url: Ge(r),
                      apiFramework: We(r, "apiFramework"),
                      type: We(r, "type"),
                    }),
                  Oe.call(s, function (e) {
                    ze(o, e);
                  }),
                  n.push(l);
              }),
              n)),
          (i.sequence = We(t, "sequence")),
          (i.adId = We(t, "id")),
          (i.adTitle = Ge(Qe(h, "AdTitle"))),
          (i.advertiser = Ge(u)),
          (i.advertiserId = We(u, "id")),
          (i.description = Ge(Qe(h, "Description"))),
          (i.dealId = Ge(Qe(h, "DealId"))),
          (!e || e > 4.2 || e < 2) &&
            this.throwError(102, "Vast version not supported"),
          e >= 4 && (i.conditionalAd = !!We(t, "conditionalAd")),
          h
            ? ((r = (function (e, t, i) {
                var r = Ue(Qe(e, "Creatives"), "Creative"),
                  a = {},
                  n = { trackers: a };
                (n.adServingId = Ge(Qe(e, "AdServingId"))),
                  (n.adsystem = Ge(Qe(e, "AdSystem")));
                var s = Ue(e, "Category");
                return (
                  (n.categories = Ve.call(s, function (e) {
                    return Ge(e);
                  })),
                  Oe.call(r, function (e) {
                    var r = Qe(e, "Linear"),
                      s = Qe(e, "NonLinear"),
                      o = Ue(Qe(e, "TrackingEvents"), "Tracking");
                    if (t >= 4) {
                      var l = Ue(e, "UniversalAdId");
                      n.universalAdId = Ve.call(l, function (e) {
                        return {
                          universalAdIdRegistry:
                            We(e, "idRegistry") || "unknown",
                          universalAdIdValue:
                            Ge(e) || We(e, "idValue") || "unknown",
                        };
                      });
                    }
                    (n.creativeId = We(e, "id")),
                      (n.creativeAdId = We(e, "adId")),
                      r && (n.linear = !0),
                      (r || s) &&
                        Oe.call(o, function (e) {
                          ze(a, e);
                        });
                    var d = Ge(Qe(e, "AdParameters"));
                    if ((d && (n.adParams = d), r)) {
                      var h = Qe(r, "VideoClicks"),
                        u = Ge(Qe(h, "ClickThrough")),
                        c = Ue(h, "ClickTracking"),
                        p = We(r, "skipoffset"),
                        f = Ge(Qe(r, "Duration"));
                      Oe.call(c, function (e) {
                        Je(a, "click", Ge(e));
                      }),
                        f && (n.duration = i.seconds(f)),
                        u && (n.clickthrough = u),
                        void 0 !== p && (n.skipoffset = p),
                        (function (e, t) {
                          var i = Ue(Qe(e, "MediaFiles"), "MediaFile"),
                            r = t.media ? t.media : [];
                          t.media = r.concat(
                            Ve.call(i, function (e) {
                              return {
                                type: We(e, "type"),
                                file: Ge(e),
                                adType: We(e, "apiFramework") || "",
                                width: parseInt(We(e, "width"), 10) || 0,
                                height: parseInt(We(e, "height"), 10) || 0,
                                bitrate: parseInt(We(e, "bitrate"), 10) || null,
                                maxBitrate:
                                  parseInt(We(e, "maxBitrate"), 10) || null,
                              };
                            }).filter(function (e) {
                              return e.file;
                            })
                          );
                        })(r, n),
                        (function (e, t) {
                          var i = Ue(e, "Icon");
                          t.icons = Array.prototype.reduce.call(
                            i,
                            function (e, t) {
                              var i, r;
                              if ((i = Qe(t, "StaticResource")))
                                r = We(i, "creativeType");
                              else if ((i = Qe(t, "IFrameResource")))
                                r = "iframe";
                              else {
                                if (!(i = Qe(t, "HTMLResource"))) return e;
                                r = "html";
                              }
                              var a = Ge(i),
                                n = {};
                              (n.iconClick =
                                Ge(Qe(t, "IconClickTracking")) || null),
                                (n.iconView =
                                  Ge(Qe(t, "IconViewTracking")) || null);
                              var s = We(t, "xPosition").toLowerCase(),
                                o = We(t, "yPosition").toLowerCase(),
                                l = {};
                              return (
                                "left" === s || "right" === s
                                  ? (l[s] = 0)
                                  : (l.left = parseInt(s, 10) || 0),
                                "top" === o || "bottom" === o
                                  ? (l[o] = 0)
                                  : (l.top = parseInt(o, 10) || 0),
                                (l.width = parseInt(We(t, "width"), 10) || 0),
                                (l.height = parseInt(We(t, "height"), 10) || 0),
                                e.push({
                                  program: We(t, "program"),
                                  style: l,
                                  apiFramework: We(t, "apiFramework"),
                                  offset: We(t, "offset") || "00:00:00",
                                  duration: We(t, "duration") || null,
                                  clickThrough: Ge(Qe(t, "IconClickThrough")),
                                  trackers: n,
                                  resource: {
                                    resourceType: r,
                                    resourceSource: a,
                                  },
                                }),
                                e
                              );
                            },
                            t.icons || []
                          );
                        })(r, n);
                    } else if (s) {
                      var m = Ge(Qe(s, "NonLinearClickThrough")),
                        v = Ue(s, "NonLinearClickTracking");
                      Oe.call(v, function (e) {
                        Je(a, "click", Ge(e));
                      }),
                        m && (n.clickthrough = m),
                        (function (e, t) {
                          var i = [],
                            r = Qe(e, "StaticResource");
                          r &&
                            !t.media &&
                            (i.push({
                              type: We(r, "creativeType"),
                              file: Ge(r),
                              adType:
                                We(Qe(e, "NonLinear"), "apiFramework") ||
                                "static",
                              minDuration:
                                We(
                                  Qe(e, "NonLinear"),
                                  "minSuggestedDuration"
                                ) || "00:00:00",
                            }),
                            (t.media = i));
                        })(e, n);
                    } else
                      !(function (e, t) {
                        var i = Ue(Qe(e, "CompanionAds"), "Companion"),
                          r = t.companions ? t.companions : [];
                        Oe.call(i, function (e) {
                          var t,
                            i,
                            a = Qe(e, "StaticResource"),
                            n = Qe(e, "IFrameResource"),
                            s = Qe(e, "HTMLResource"),
                            o = {};
                          if (a) (t = We(a, "creativeType")), (i = Ge(a));
                          else if (n) (t = "iframe"), (i = Ge(n));
                          else {
                            if (!s) return;
                            (t = "html"), (i = Ge(s));
                          }
                          var l = Ue(Qe(e, "TrackingEvents"), "Tracking");
                          Oe.call(l, function (e) {
                            var t = We(e, "event");
                            Je(o, t, Ge(e));
                          });
                          var d = Ge(Qe(e, "CompanionClickThrough"));
                          r.push({
                            width: parseInt(We(e, "width"), 10),
                            height: parseInt(We(e, "height"), 10),
                            type: t,
                            source: i,
                            trackers: o,
                            clickthrough: d,
                          });
                        }),
                          (t.companions = r);
                      })(e, n);
                  }),
                  n
                );
              })(h, e, this.utils)),
              $e(h, "Impression", r.trackers),
              $e(h, "Error", r.trackers),
              $e(h, "NotViewable", r.trackers),
              $e(h, "Viewable", r.trackers),
              (function (e) {
                var t = {};
                e.media &&
                  e.media.forEach(function (e) {
                    var i = e.type,
                      r =
                        "application/x-mpegURL" === i ||
                        "vnd.apple.mpegURL" === i;
                    "vpaid" === e.adType.toLowerCase() ||
                      r ||
                      ((t[i] = t[i] || 0), t[i]++);
                  });
                (e.mediaFileCompliance = !0),
                  Object.keys(t).forEach(function (i) {
                    var r = t[i];
                    r < 3 &&
                      ((e.mediaFileCompliance = !1),
                      (e.nonComplianceReasons = e.nonComplianceReasons || []),
                      e.nonComplianceReasons.push(
                        i + " has only " + r + " qualities"
                      ));
                  });
              })(r),
              d &&
                ((r.wrappedURI =
                  Ge(Qe(d, "VASTAdTagURI")) || Ge(Qe(d, "VASTAdTagURL"))),
                (r.followAdditionalWrappers = JSON.parse(
                  We(d, "followAdditionalWrappers")
                )),
                (r.allowMultipleAds = JSON.parse(We(d, "allowMultipleAds"))),
                (r.fallbackOnNoAd = JSON.parse(We(d, "fallbackOnNoAd")))),
              (s = r),
              (o = B({}, i)),
              Object.keys(s).forEach(function (e) {
                var t = s[e];
                Array.isArray(o[e])
                  ? (o[e] = o[e].concat(t))
                  : "object" == typeof o[e] && null !== o[e]
                  ? (o[e] = B(o[e], t))
                  : (o[e] = t);
              }),
              (r = o))
            : this.throwError(303, "No ads", 10303),
          r
        );
      }),
      (t.throwError = function (e, t, i) {
        throw (
          ((this._error = new Error(t)),
          (this._error.code = e),
          (this._error.adErrorCode = i || 1e4 + e),
          this._error)
        );
      }),
      e
    );
  })();
  function Ue(e, t, i) {
    var r = [];
    return (
      e &&
        ((r = e.getElementsByTagName(t)),
        i && r && 0 === r.length && (r = e.getElementsByTagName(i + ":" + t))),
      r
    );
  }
  function Qe(e, t) {
    if (e) {
      var i = e.getElementsByTagName(t);
      if (i) return i[0];
    }
    return null;
  }
  function Xe(e, t, i, r) {
    var a = [];
    return e || t
      ? (a = t.getElementsByTagNameNS
          ? t.getElementsByTagNameNS(e, i)
          : t.getElementsByTagName(r + ":" + i))
      : a;
  }
  function We(e, t) {
    return e ? e.getAttribute(t) : null;
  }
  function ze(e, t) {
    var i = We(t, "event");
    "progress" === i && (i = i + "_" + We(t, "offset"));
    Je(e, i, Ge(t));
  }
  function Ge(e) {
    if (e) {
      var t = e.textContent || e.text;
      if (t) return t.trim();
    }
    return "";
  }
  function Je(e, t, i) {
    e[t] || (e[t] = []), i && (e[t].push(i), Ye(i));
  }
  function $e(e, t, i) {
    var r = Ue(e, t);
    Ve.call(r, function (e) {
      Je(i, t.toLowerCase(), Ge(e));
    });
  }
  var Ye = function (e) {
    (e.indexOf("[REGULATIONS]") >= 0 || e.indexOf("[GDPRCONSENT]") >= 0) &&
      (Pe().catch(Be), (Ye = Be));
  };
  function Ke(e) {
    (e.onload = e.onreadystatechange = e.onerror = null),
      "abort" in e && e.abort();
  }
  var Ze = (function () {
    function e(e, t) {
      (this.adRules = e),
        (this.utils = t),
        (this.preRoll = null),
        (this.vmap = null),
        (this.postRoll = null),
        (this.midRolls = []),
        (this.playedMidRolls = []),
        (this.duration = 0),
        (this._vmapPromise = null),
        (this._vmapXHR = null);
    }
    var t = e.prototype;
    return (
      (t.load = function (e, t, i, r) {
        var a = this;
        if (this._vmapPromise) return this._vmapPromise;
        null !== this._vmapXHR && (Ke(this._vmapXHR), (this._vmapXHR = null));
        var n = Re(this.getVMAP(), e, t, i, r);
        return i === te
          ? ((this._vmapPromise = n.then(function (e) {
              a.setPreRoll({ _adQueue: [e] });
            })),
            this._vmapPromise)
          : ((this._vmapPromise = n.then(function (t) {
              return new Promise(function (i, n) {
                a._vmapXHR = e.utils.ajax(
                  {
                    url: t,
                    withCredentials: r.withCredentials,
                    retryWithoutCredentials: !0,
                    requireValidXML: !0,
                    timeout: a.requestTimeout,
                  },
                  i,
                  function (e, t, i, r) {
                    return n(r);
                  }
                );
              })
                .then(function (r) {
                  return (
                    (a._vmapXHR = null),
                    e.trigger("adLoadedXML", {
                      client: i,
                      tag: t,
                      xml: r.responseXML,
                    }),
                    Le(r.responseXML, a, e.utils).map(function (e) {
                      return B(e, { vmap: t });
                    })
                  );
                })
                .catch(function (i) {
                  a._vmapXHR = null;
                  var r = { id: ae, vmap: t };
                  if (i.message)
                    B(r, {
                      message: "VMAP Schema Error: " + i.message,
                      code: 1002,
                      adErrorCode: i.adErrorCode || 11002,
                    });
                  else {
                    var n = {
                        1: { code: 1007, message: "Timeout" },
                        602: { code: 1e3, message: "Invalid XML" },
                        default: {
                          code: 1008,
                          message: e.getConfig().localization.errors[i.key],
                        },
                      },
                      s = n[i.code] || n.default;
                    e.utils.log(s.message),
                      B(r, {
                        message: "Error Loading VMAP Schedule",
                        code: s.code,
                        adErrorCode: s.code + 1e4,
                      });
                  }
                  throw r;
                });
            })),
            this._vmapPromise);
      }),
      (t.canWaterfall = function (e) {
        return e._adQueue && e._waterfallIndex + 1 < e._adQueue.length;
      }),
      (t.getPreRoll = function (e) {
        return e && "none" === this.adRules.startOnSeek
          ? null
          : et(this.preRoll, this.requestTimeout, this.creativeTimeout);
      }),
      (t.getPostRoll = function (e) {
        var t = et(this.postRoll, this.requestTimeout, this.creativeTimeout);
        return this.adRules.timeBetweenAdsAllowsAdPlayback(t, e) ? t : null;
      }),
      (t.getMidRollAtIndex = function (e) {
        return et(this.midRolls[e], this.requestTimeout, this.creativeTimeout);
      }),
      (t.getLastMidRollIndexBetweenTime = function (e, t, i) {
        if (e > t) return null;
        this.sort(i);
        for (var r = this.midRolls.length; r--; ) {
          var a = this.midRolls[r],
            n = tt(this.midRolls[r]._offSet, i);
          if (e >= n) return null;
          if (t >= n) {
            var s = et(a, this.requestTimeout, this.creativeTimeout);
            if (!this.adRules.timeBetweenAdsAllowsAdPlayback(s)) return null;
            if (!this.adRules.timeBetweenAds) {
              if (this.playedMidRolls.indexOf(r) >= 0) return null;
              this.playedMidRolls.push(r);
            }
            return r;
          }
        }
        return null;
      }),
      (t.peek = function (e, t, i) {
        if (this.midRolls.length > this.playedMidRolls.length) {
          this.sort(i);
          for (var r = 0; this.midRolls[r]; ) {
            var a = tt(this.midRolls[r]._offSet, i);
            if (a >= e && -1 === this.playedMidRolls.indexOf(r)) {
              var n = be() + 1e3 * (a - e);
              return a <= t &&
                this.adRules.timeBetweenAdsAllowsAdPlayback(null, n)
                ? r
                : null;
            }
            r += 1;
          }
        }
        var s = be() + 1e3 * (i - e);
        return this.postRoll &&
          t >= i &&
          this.adRules.timeBetweenAdsAllowsAdPlayback(null, s)
          ? -1
          : null;
      }),
      (t.getNextMidrollIndex = function (e, t, i) {
        if (this.adRules.timeBetweenAds || this.adRules.startOnSeek)
          return this.getLastMidRollIndexBetweenTime(e, t, i);
        if (this.midRolls.length > this.playedMidRolls.length) {
          var r = this.getClosestIndex(t, i);
          if (r >= 0 && this.playedMidRolls.indexOf(r) < 0)
            return this.playedMidRolls.push(r), r;
        }
        return null;
      }),
      (t.getMidRolls = function () {
        var e = this;
        return this.midRolls.map(function (t) {
          return et(t, e.requestTimeout, e.creativeTimeout);
        });
      }),
      (t.reset = function () {
        null !== this._vmapXHR && (Ke(this._vmapXHR), (this._vmapXHR = null)),
          (this.playedMidRolls = []),
          (this.duration = 0);
      }),
      (t.setPreRoll = function (e) {
        this.resetBreakId(e), (this.preRoll = e);
      }),
      (t.addMidRoll = function (e) {
        this.resetBreakId(e), this.midRolls.push(e), (this.duration = 0);
      }),
      (t.setPostRoll = function (e) {
        this.resetBreakId(e), (this.postRoll = e);
      }),
      (t.sort = function (e, t) {
        (!e || e < 1) && (e = 1),
          (this.duration !== e || t) &&
            ((this.duration = e),
            this.midRolls.sort(function (t, i) {
              return tt(t._offSet, e) - tt(i._offSet, e);
            }),
            (function (e, t) {
              for (var i = 0; i < e.length; i++) {
                var r = e[i];
                t
                  ? (r._vmap.item = i + 1)
                  : ((r._adbreak = { item: i + 1, breakid: r._breakId }),
                    r._pod
                      ? (r._adbreak.pod = r._pod)
                      : (r._adbreak.tags = r._adQueue));
              }
            })(this.getAllAds(), t));
      }),
      (t.getAllAds = function () {
        var e = this.preRoll ? [this.preRoll] : [],
          t = this.postRoll ? [this.postRoll] : [];
        return e.concat(this.midRolls, t);
      }),
      (t.setVMAP = function (e) {
        this.vmap = e;
      }),
      (t.isVMAP = function () {
        return !!this.vmap;
      }),
      (t.getVMAP = function () {
        return this.vmap;
      }),
      (t.getClosestIndex = function (e, t) {
        this.sort(t);
        for (var i = this.midRolls.length; i--; )
          if (e >= tt(this.midRolls[i]._offSet, t)) return i;
        return -1;
      }),
      (t.resetBreakId = function (e) {
        e.adBreakId = this.utils.genId(12);
      }),
      (t.resetAllBreakIds = function () {
        var e = this;
        this.getAllAds().forEach(function (t) {
          e.resetBreakId(t);
        });
      }),
      (t.destroy = function () {
        this.reset(), this.adRules.destroy();
      }),
      e
    );
  })();
  function et(e, t, i) {
    var r;
    if (null !== e)
      return (
        Object.keys(e).forEach(function (t) {
          var i = e[t];
          (r = r || {})[t] = "_adQueue" === t || "_pod" === t ? i.slice() : i;
        }),
        r
          ? ((r.requestTimeout = t),
            (r.creativeTimeout = i),
            (r._errors = []),
            (r._waterfallIndex = 0),
            (r._adPodIndex = 0),
            r)
          : void 0
      );
  }
  function tt(e, t) {
    return "%" === e.toString().slice(-1)
      ? (t * parseFloat(e.slice(0, -1))) / 100
      : parseFloat(e);
  }
  var it = (function () {
    function e(e) {
      this.utils = e;
    }
    var t = e.prototype;
    return (
      (t.getSchedule = function (e, t) {
        var i = new Ze(t, this.utils);
        if (
          ((i.requestTimeout = at(e.requestTimeout, 5e3)),
          (i.creativeTimeout = at(e.creativeTimeout, 5e3)),
          e.tag)
        )
          i.setPreRoll({
            _offSet: "pre",
            _adQueue: rt(e.tag),
            _waterfallIndex: 0,
          });
        else if ("string" == typeof e.vastxml)
          i.setPreRoll({ _offSet: "pre", _adXML: e.vastxml });
        else {
          if ("string" == typeof e.schedule) return i.setVMAP(e.schedule), i;
          if ("string" == typeof e.adschedule)
            return i.setVMAP(e.adschedule), i;
          !(function (e, t, i) {
            var r = t.schedule || t.adschedule;
            if (!r) return;
            var a = {};
            Object.keys(r).forEach(function (e) {
              var t = r[e];
              t.ad && (B(t, t.ad), delete t.ad);
              var n = (function (e, t) {
                  if ("start" === e || "0%" === e || (!e && 0 !== e))
                    return "pre";
                  if ("end" === e || "100%" === e) return "post";
                  if ("pre" === e || "post" === e || (e + "").indexOf("%") >= 0)
                    return e;
                  var i = t.seconds(e);
                  if ("number" == typeof i) return i;
                  return !1;
                })(t.offset, i),
                s = at(t.requestTimeout, se),
                o = at(t.creativeTimeout, oe),
                l = a[n];
              if (l) {
                if ("nonlinear" === t.type) return;
                "nonlinear" === l._type && (l = null);
              }
              var d = (a[n] = l || {
                _offSet: n,
                _type: t.type,
                _breakId: e,
                adBreakId: i.genId(12),
                requestTimeout: s,
                creativeTimeout: o,
              });
              !1 === n && i.log("Error: ad offset format not supported", n);
              var h = t.skipoffset;
              if (
                (void 0 !== h && void 0 === d.skipoffset && (d.skipoffset = h),
                "string" == typeof t.adm)
              )
                d.adm = t.adm;
              else if (t.pod) {
                var u = d._pod || [];
                d._pod = u.concat(t.pod);
              } else if (t.tag) {
                var c = (function (e, t) {
                  if (!t) return e;
                  var i = e.indexOf("?") >= 0 ? "&" : "?",
                    r = e.indexOf(ne),
                    a = ne.length,
                    n = "",
                    s = "";
                  if (
                    (Object.keys(t).forEach(function (e) {
                      var i = t[e];
                      (n = "" + n + s + e + "=" + i), (s = "&");
                    }),
                    (n = encodeURIComponent(n)),
                    r >= 0)
                  ) {
                    var o = e.substr(0, r + a),
                      l = e.substr(r + a);
                    return "" + o + n + "%26" + l;
                  }
                  return "" + e + i + ne + n;
                })(t.tag, t.custParams);
                d._adQueue && ((d._pod = [d._adQueue[0]]), delete d._adQueue),
                  d._pod ? d._pod.push(rt(c)[0]) : (d._adQueue = rt(c));
              } else {
                if ("string" != typeof t.vastxml)
                  return void i.log("Error: no ad tag provided");
                d._adXML = t.vastxml;
              }
            }),
              Object.keys(a).forEach(function (i) {
                var r = a[i];
                switch (
                  ((r.skipoffset =
                    void 0 !== r.skipoffset ? r.skipoffset : t.skipoffset),
                  i)
                ) {
                  case "pre":
                    e.setPreRoll(r);
                    break;
                  case "post":
                    e.setPostRoll(r);
                    break;
                  default:
                    e.addMidRoll(r);
                }
              });
          })(i, e, this.utils);
        }
        return i.sort(), i;
      }),
      (t.getOptParams = function (e, t) {
        var i = {
            cuetext: t.cuetext,
            dynamicMessage: t.admessage,
            loadingAd: t.loadingAd,
            podMessage: t.podmessage,
            skipoffset: e.skipoffset,
            skipMessage: t.skipmessage,
            skipText: t.skiptext,
            omidAccessMode: e.omidAccessMode || "full",
            omidSupport: e.omidSupport || "auto",
            allowedOmidVendors: e.allowedOmidVendors || [],
            vpaidcontrols: e.vpaidcontrols || !1,
            conditionaladoptout: e.conditionaladoptout || !1,
            requestFilter: e.requestFilter,
            trackingFilter: e.trackingFilter,
            withCredentials: void 0 === e.withCredentials || e.withCredentials,
          },
          r = e.companiondiv;
        return (
          r && (i.companion = { id: r.id, height: r.height, width: r.width }), i
        );
      }),
      (t.getAdRules = function (e) {
        var t = e.rules || {},
          i = parseInt(t.frequency, 10);
        return {
          startOn: t.startOn || 1,
          frequency: isNaN(i) ? 1 : i,
          timeBetweenAds: t.timeBetweenAds || 0,
          startOnSeek: t.startOnSeek || null,
          deferAds: t.deferAds || null,
        };
      }),
      e
    );
  })();
  function rt(e) {
    return Array.isArray(e) ? e.slice(0) : [e];
  }
  function at(e, t) {
    return 0 === e ? 1 / 0 : e || t;
  }
  function nt(e, t) {
    for (var i = 0; i < t.length; i++) {
      var r = t[i];
      (r.enumerable = r.enumerable || !1),
        (r.configurable = !0),
        "value" in r && (r.writable = !0),
        Object.defineProperty(e, r.key, r);
    }
  }
  var st = (function () {
      function e(e, t) {
        (this.player = e),
          (this.options = t),
          (this.client = t.client),
          (this.ignoreStartOnSeek = !1),
          this.reset(),
          t.timeBetweenAds &&
            e.on(
              {
                adBreakStart: this.handleAdBreakStart,
                adSkipped: this.handleAdSkipped,
                adComplete: this.handleAdComplete,
                adBreakEnd: this.handleAdBreakEnd,
                destroyPlugin: this.destroy,
              },
              this
            );
      }
      var t,
        i,
        r,
        a = e.prototype;
      return (
        (a.shouldDeferAds = function () {
          return this.options.deferAds && !this.player.getConfig().activeTab;
        }),
        (a.clearStartOnSeek = function () {
          this.ignoreStartOnSeek = !0;
        }),
        (a.sendAdBreakIgnored = function (e, t) {
          e &&
            this.player.trigger(
              le,
              (function (e, t) {
                var i = {};
                return (
                  e &&
                    (i = {
                      id: e._breakId,
                      tag:
                        e._adQueue && e._adQueue.length > 0
                          ? e._adQueue[0]
                          : e._adXML,
                      offset: e._offSet,
                    }),
                  B(i, { timeSinceLastAd: t, type: le })
                );
              })(e, t, this.client)
            );
        }),
        (a.rulesAllowAdPlayback = function (e) {
          var t = this.options,
            i = 0 === t.frequency && 1 === e,
            r = e >= t.startOn && (e - t.startOn) % t.frequency == 0;
          return i || r;
        }),
        (a.handleAdBreakStart = function () {
          (this.adSkipped = !1), (this.adComplete = !1);
        }),
        (a.handleAdComplete = function () {
          this.adComplete = !0;
        }),
        (a.handleAdSkipped = function () {
          this.adSkipped = !0;
        }),
        (a.handleAdBreakEnd = function () {
          !this.adSkipped &&
            this.adComplete &&
            (this.recentCompletedAdTime = be());
        }),
        (a.timeBetweenAdsAllowsAdPlayback = function (e, t) {
          if ((void 0 === t && (t = be()), this.options.timeBetweenAds)) {
            var i = (t - this.recentCompletedAdTime) / 1e3;
            if (i < this.options.timeBetweenAds)
              return this.sendAdBreakIgnored(e, i), !1;
          }
          return !0;
        }),
        (a.reset = function () {
          (this.ignoreStartOnSeek = !1), (this.recentCompletedAdTime = 0);
        }),
        (a.destroy = function () {
          this.player.off(null, null, this);
        }),
        (t = e),
        (i = [
          {
            key: "timeBetweenAds",
            get: function () {
              return this.options.timeBetweenAds;
            },
          },
          {
            key: "startOnSeek",
            get: function () {
              return this.ignoreStartOnSeek ? null : this.options.startOnSeek;
            },
          },
        ]) && nt(t.prototype, i),
        r && nt(t, r),
        Object.defineProperty(t, "prototype", { writable: !1 }),
        e
      );
    })(),
    ot = function () {},
    lt = (function () {
      function e(e, t, i, r, a) {
        B(this, e.Events),
          (this.client = "shared"),
          (this.player = e),
          (this.item = i),
          (this.config = r),
          (this.casting = a);
        var n = e.utils,
          s = new it(n);
        (this.adRules = new st(e, s.getAdRules(r))),
          "string" == typeof t
            ? ((this.schedule = new Ze(this.adRules, n)),
              this.schedule.setPreRoll({ tag: t }))
            : ((this.schedule = t), t.resetAllBreakIds()),
          (this.vmapPromise = null),
          (this.lastTimeEvent = null),
          (this.prerollPromise = null),
          (this.midrollPromise = {}),
          (this.postrollPromise = null),
          (this.next = null),
          (this.nextPlaylistItemPromise = null),
          (this.relatedNextUp = null),
          (this.bidding = e.getPlugin("bidding")),
          (this.bids = []),
          (this.bidsPromises = []),
          (this.bidsPromise = null),
          (this._events = []);
      }
      var t = e.prototype;
      return (
        (t.attachListeners = function () {
          this.player.on(
            {
              all: this.onAll,
              beforePlay: this.checkPreroll,
              relatedReady: this.relatedReady,
              cast: this.onCast,
              destroyBidding: this.destroyBids,
            },
            this
          );
        }),
        (t.onAll = function (e, t) {
          "time" === e
            ? this.checkMidrolls(t)
            : "beforeComplete" === e && this.checkPostrolls(t);
        }),
        (t.relatedReady = function () {
          var e = this;
          if (this.config.preloadAds) {
            var t = this.player.getPlugin("related");
            t &&
              t.on("nextUp", function (t) {
                t && "discovery" === t.mode && (e.relatedNextUp = t);
              });
          }
        }),
        (t.onCast = function (e) {
          this.casting = !!e.active;
        }),
        (t.init = function (e, t) {
          var i = this;
          if (
            (void 0 === e && (e = null),
            this.schedule.isVMAP() &&
              ((t.requestTimeout = this.schedule.requestTimeout),
              (t.creativeTimeout = this.schedule.creativeTimeout),
              (this.vmapPromise = this.schedule.load(
                this.player,
                this.item,
                this.client,
                t
              ))),
            (this.bidsPromise = this.vmapPromise || Promise.resolve()),
            (this.bidsPromise =
              null !== e
                ? this.bidsPromise
                    .then(function () {
                      if (!i.isDestroyed()) {
                        if (i.bidding) return i.createBidsPromise(e, t);
                        var r = (function (e, t, i) {
                          var r = Ie(e, t, i);
                          return (
                            B(r, {
                              message: "Ad Error: bidding plugin unavailable",
                              code: 900,
                              adErrorCode: 60008,
                            }),
                            r
                          );
                        })(i, null, t);
                        i.player.trigger(de, r);
                      }
                    })
                    .catch(ot)
                : this.bidsPromise.catch(ot)),
            this.config.preloadAds)
          )
            if (1 === t.playlistItemEventCount) {
              var r = this.player.getConfig().autostart;
              !1 === r || ("viewable" === r && 0 === this.player.getViewable())
                ? this.loadPreroll(t).catch(function (e) {
                    return i.isDestroyed()
                      ? null
                      : i.enqueueAdEvent(de, e, { preload: !0 });
                  })
                : this.player.once("autostartNotAllowed", function () {
                    i.loadPreroll(t).catch(function (e) {
                      return i.isDestroyed()
                        ? null
                        : i.enqueueAdEvent(de, e, { preload: !0 });
                    });
                  });
            } else
              t.preloadPreroll &&
                this.loadPreroll(t).catch(function (e) {
                  return i.isDestroyed()
                    ? null
                    : i.enqueueAdEvent(de, e, { preload: !0 });
                });
          return this.bidsPromise;
        }),
        (t.createBidsPromise = function (e, t) {
          var i = this,
            r = this.player,
            a = parseInt(e.bidOnBreaks, 10);
          return (
            (a = a > 0 ? a : 1 / 0),
            (this.bids = this.schedule
              .getAllAds()
              .slice(0, a)
              .map(function (a) {
                var n = i.getAdIds(a).adPlayId,
                  s = r.getConfig(),
                  o = i.config.skipoffset,
                  l = null != o && o >= 0,
                  d = _e(r, i.item),
                  h = {
                    id: n,
                    offset: e.offset,
                    jwpseg: d,
                    placement: Ee(s),
                    tag: a._adQueue ? a._adQueue[0] : a._currentTag,
                    adClient: i.client,
                  };
                i.client === ee && (h.skipoffset = l ? o : -1);
                var u = i.bidding.createNewBid(h, { getURLParts: Te });
                i.player.trigger("adBidRequest", Ie(i, a, B({ jwpseg: d }, t))),
                  u.init();
                var c = u.start().then(function (e) {
                  var r = e.result;
                  if (!i.isDestroyed()) {
                    var n = Promise.resolve();
                    return (
                      r &&
                        !r.error &&
                        ((a.jwpseg = d),
                        r.adm
                          ? ((a._adXML = r.adm),
                            a._adQueue &&
                              a._adQueue.length &&
                              a._adQueue.unshift(r.adm))
                          : r.tag &&
                            (n = Re(
                              r.tag,
                              i.player,
                              i.item,
                              i.client,
                              {},
                              a
                            ).then(function (e) {
                              i.client === ee
                                ? ((a._adQueue = a._adQueue || []),
                                  a._adQueue.unshift(e))
                                : (a._adQueue = [e]);
                            }))),
                      i.player.trigger("adBidResponse", Ie(i, a, t)),
                      n
                    );
                  }
                });
                return i.bidsPromises.push(c), u;
              })),
            Promise.all(this.bidsPromises)
          );
        }),
        (t.checkPreroll = function (e) {
          var t = this;
          if (
            (this.bidTimeoutStarted ||
              ((this.bidTimeoutStarted = !0),
              this.bids.forEach(function (e) {
                return e.timeout();
              })),
            !(
              this.casting ||
              this.preRollPlayed ||
              this.adRules.shouldDeferAds()
            ))
          ) {
            this.preRollPlayed = !0;
            var i = (e || {}).startTime || this.player.getPosition();
            this.lastTimeEvent = i || this.lastTimeEvent;
            var r = this.schedule.getPreRoll(i);
            if (r || this.vmapPromise) {
              (null !== this.vmapPromise || (r && "nonlinear" !== r._type)) &&
                this.startBlocking(),
                this.bidsPromise.then(function () {
                  if (!t.isDestroyed()) {
                    var e = t.schedule.getPreRoll(i);
                    e &&
                      "nonlinear" !== e._type &&
                      t.triggerAdBreakEvents(e, "pre");
                  }
                }),
                i
                  ? "none" === this.adRules.startOnSeek &&
                    (this.prerollPromise = null)
                  : this.adRules.clearStartOnSeek();
              var a = e && e.playReason ? e.playReason : "external";
              this.playPreroll({
                adBlock: this.adBlockErrorDetected,
                startTime: i,
                reason: a,
              });
            }
          }
        }),
        (t.checkMidrolls = function (e) {
          var t = this;
          if (
            !this.casting &&
            0 !== e.duration &&
            !this.adRules.shouldDeferAds()
          ) {
            var i = this.schedule.getNextMidrollIndex(
              this.lastTimeEvent,
              e.position,
              e.duration
            );
            if (((this.lastTimeEvent = e.position), null !== i)) {
              var r = this.schedule.getMidRollAtIndex(i);
              "nonlinear" !== r._type &&
                (this.startBlocking(), this.triggerAdBreakEvents(r, "mid")),
                this.playMidrollAtIndex(i, {
                  adBlock: this.adBlockErrorDetected,
                });
            } else if (
              !this.preRollPlayed &&
              this.schedule.getClosestIndex(e.position, e.duration) < 0
            )
              this.checkPreroll(e);
            else if (this.config.preloadAds) {
              var a = e.position + 5,
                n = this.schedule.peek(e.position, a, e.duration);
              if (null !== n && n >= 0)
                this.loadMidrollAtIndex(n, {
                  adBlock: this.adBlockErrorDetected,
                  preload: !0,
                }).catch(ot);
              else if (-1 === n) {
                var s = be() + 1e3 * (e.duration - e.position);
                this.loadPostroll({
                  adBlock: this.adBlockErrorDetected,
                  preload: !0,
                  startTime: s,
                }).catch(ot);
              } else if (
                null === this.next &&
                null === this.nextPlaylistItemPromise &&
                a > e.duration
              ) {
                var o = this.player.getPlaylistIndex() + 1,
                  l = this.player.getPlaylistItem(o);
                if (
                  ((this.nextPlaylistRelated = !!this.relatedNextUp),
                  l || this.relatedNextUp)
                ) {
                  var d = this.relatedNextUp ? -1 : o;
                  this.nextPlaylistItemPromise = Promise.resolve(
                    this.player.getPlaylistItemPromise(d)
                  )
                    .then(function () {
                      t.isDestroyed() ||
                        (t.trigger("preloadNext", {
                          item: t.player.getPlaylistItem(o) || t.relatedNextUp,
                          index: d,
                        }),
                        (t.relatedNextUp = null),
                        (t.nextPlaylistItemPromise = null));
                    })
                    .catch(ot);
                }
              }
            }
          }
        }),
        (t.checkPostrolls = function (e) {
          if (
            !(
              this.casting ||
              this.adRules.shouldDeferAds() ||
              this.isDestroyed()
            )
          ) {
            var t = this.schedule.getPostRoll();
            t &&
              ("nonlinear" !== t._type &&
                (this.startBlocking(), this.triggerAdBreakEvents(t, "post")),
              this.playPostroll(e));
          }
        }),
        (t.getAdIds = function (e, t) {
          var i = void 0 === t ? {} : t,
            r = i.tagIndex,
            a = i.podIndex,
            n = e.adRequestIds && void 0 !== r ? e.adRequestIds[r] : null;
          if (!n) {
            var s =
              "p" + (a || e._adPodIndex || 0) + "w" + (e._waterfallIndex || 0);
            "p0w0" === s
              ? (n = e.adBreakId)
              : ((e.adPlayIds = e.adPlayIds || {}),
                (n = e.adPlayIds[s] =
                  e.adPlayIds[s] || this.player.utils.genId(12)));
          }
          return { adBreakId: e.adBreakId, adPlayId: n };
        }),
        (t.loadPreroll = function (e) {
          var t = this;
          return (
            void 0 === e && (e = {}),
            this.prerollPromise ||
              (this.prerollPromise = this.bidsPromise.then(function () {
                if (!t.isDestroyed()) {
                  var i = t.schedule.getPreRoll(e.startTime);
                  return i
                    ? ((i._position = "pre"), (i._preload = !0), t.loadAd(i, e))
                    : void 0;
                }
              })),
            this.prerollPromise
          );
        }),
        (t.loadMidrollAtIndex = function (e, t) {
          var i = this;
          return (
            this.midrollPromise[e] ||
              (this.midrollPromise[e] = this.bidsPromise.then(function () {
                if (!i.isDestroyed()) {
                  var r = i.schedule.getMidRollAtIndex(e);
                  return r
                    ? ((r._position = "mid"), (r._preload = !0), i.loadAd(r, t))
                    : void 0;
                }
              })),
            this.midrollPromise[e]
          );
        }),
        (t.loadPostroll = function (e) {
          var t = this;
          return (
            void 0 === e && (e = {}),
            this.postrollPromise ||
              (this.postrollPromise = this.bidsPromise.then(function () {
                if (!t.isDestroyed()) {
                  var i = t.schedule.getPostRoll(e.startTime);
                  return i
                    ? ((i._position = "post"),
                      (i._preload = !0),
                      t.loadAd(i, e))
                    : void 0;
                }
              })),
            this.postrollPromise
          );
        }),
        (t.playPreroll = function (e) {
          var t = this;
          this.prerollPromise
            ? this.playPreloadedPromise(this.prerollPromise, e)
            : this.bidsPromise.then(function () {
                if (!t.isDestroyed()) {
                  var i = t.schedule.getPreRoll(e.startTime);
                  i
                    ? ((i._position = "pre"), t.startAdBreak(i, e))
                    : t.stopBlocking();
                }
              });
        }),
        (t.playMidrollAtIndex = function (e) {
          var t = this;
          this.midrollPromise[e]
            ? this.playPreloadedPromise(this.midrollPromise[e])
            : this.bidsPromise.then(function () {
                var i = t.schedule.getMidRollAtIndex(e);
                i && ((i._position = "mid"), t.startAdBreak(i));
              });
        }),
        (t.playPostroll = function (e) {
          var t = this;
          this.postrollPromise
            ? this.playPreloadedPromise(this.postrollPromise)
            : this.bidsPromise.then(function () {
                var i = t.schedule.getPostRoll();
                i && ((i._position = "post"), t.startAdBreak(i, e));
              });
        }),
        (t.isDestroyed = function () {
          return null === this.player;
        }),
        (t.destroy = function () {
          this.destroyBids(),
            this.player.off(null, null, this),
            (this.player = null);
        }),
        (t.destroyBids = function () {
          this.bids.forEach(function (e) {
            return e.stop();
          }),
            (this.bidsPromises = []),
            (this.bids = []);
        }),
        (t.enqueueAdEvent = function (e, t, i) {
          this._events.push({ type: e, event: t }),
            i.preload || this.dequeueAdEvents();
        }),
        (t.dequeueAdEvents = function () {}),
        (t.triggerAdBreakEvents = function () {}),
        (t.startBlocking = function () {}),
        (t.stopBlocking = function () {}),
        (t.loadAd = function () {}),
        (t.playPreloadedPromise = function () {}),
        (t.startAdBreak = function () {}),
        e
      );
    })(),
    dt = (function () {
      function e(e, t, i, r, a, n, s) {
        B(this, e.Events),
          (this.player = e),
          (this.startingSize = e.getWidth() * e.getHeight());
        var o = n.allowedOmidVendors;
        try {
          var l = [];
          r.forEach(function (e) {
            var i = e.javaScriptResource,
              r = e.vendor,
              a = e.verificationParameters,
              d = e.trackers;
            o.length && o.indexOf(r) < 0
              ? s("verificationNotExecuted", d.verificationNotExecuted, {
                  "[REASON]": 1,
                })
              : i
              ? i.url
                ? l.push(
                    new t.VerificationScriptResource(
                      i.url,
                      r,
                      a,
                      n.omidAccessMode
                    )
                  )
                : s("verificationNotExecuted", d.verificationNotExecuted, {
                    "[REASON]": 3,
                  })
              : s("verificationNotExecuted", d.verificationNotExecuted, {
                  "[REASON]": 2,
                });
          });
          var d = new t.Partner("JWPlayer", e.version),
            h = new t.Context(d, l, location.href);
          h.setVideoElement(i),
            (h.underEvaluation = !0),
            h.setServiceWindow(window);
          var u = (this.adSession = new t.AdSession(h));
          if (!u.isSupported()) return;
          (this.adEvents = new t.AdEvents(u)),
            (this.mediaEvents = new t.MediaEvents(u)),
            a && u.setCreativeType("video"),
            u.start();
        } catch (e) {
          return null;
        }
      }
      var t = e.prototype;
      return (
        (t.resetResizeTimeout = function () {
          var e = this;
          clearTimeout(this.resizeTimer),
            this.isFullscreen ||
              (this.resizeTimer = setTimeout(function () {
                if (e.mediaEvents) {
                  var t = e.player.getWidth(),
                    i = e.player.getHeight();
                  t * i > e.startingSize
                    ? e.mediaEvents.playerStateChange("expanded")
                    : t * i < e.startingSize
                    ? e.mediaEvents.playerStateChange("collapsed")
                    : e.mediaEvents.playerStateChange("normal");
                }
              }, 250));
        }),
        (t.trackEvent = function (e) {
          var t, i;
          if (this.adEvents && this.mediaEvents)
            try {
              for (
                var r = arguments.length,
                  a = new Array(r > 1 ? r - 1 : 0),
                  n = 1;
                n < r;
                n++
              )
                a[n - 1] = arguments[n];
              switch (e) {
                case v:
                  this.adEvents.loaded();
                  break;
                case "click":
                  this.mediaEvents.adUserInteraction("click");
                  break;
                case "close":
                  this.finishSession();
                  break;
                case "complete":
                  this.mediaEvents.complete(), this.finishSession();
                  break;
                case "firstQuartile":
                  this.mediaEvents.firstQuartile();
                  break;
                case "fullscreen":
                  (this.isFullscreen = a[0]),
                    this.resetResizeTimeout(),
                    this.isFullscreen &&
                      this.mediaEvents.playerStateChange("fullscreen");
                  break;
                case "impression":
                  (t = this.mediaEvents).start.apply(t, a),
                    this.adEvents.impressionOccurred(),
                    (this.startingSize =
                      this.player.getWidth() * this.player.getHeight()),
                    (this.isFullscreen = this.player.getFullscreen());
                  break;
                case "midpoint":
                  this.mediaEvents.midpoint();
                  break;
                case "mute":
                  this.mediaEvents.volumeChange(0);
                  break;
                case "pause":
                  this.mediaEvents.pause();
                  break;
                case "resize":
                  this.resetResizeTimeout();
                  break;
                case "resume":
                  this.mediaEvents.resume();
                  break;
                case "skip":
                  this.mediaEvents.skipped(), this.finishSession();
                  break;
                case "thirdQuartile":
                  this.mediaEvents.thirdQuartile();
                  break;
                case "unmute":
                  this.mediaEvents.volumeChange(this.player.getVolume() / 100);
                  break;
                case "volume":
                  (i = this.mediaEvents).volumeChange.apply(i, a);
                  break;
                case "bufferStart":
                  this.mediaEvents.bufferStart();
                  break;
                case "bufferFinish":
                  this.mediaEvents.bufferFinish();
              }
            } catch (e) {
              console.warn(e), (this.adEvents = this.mediaEvents = null);
            }
        }),
        (t.finishSession = function () {
          this.adSession &&
            (this.adSession.finish(),
            (this.adSession = null),
            (this.adEvents = null),
            (this.mediaEvents = null));
        }),
        e
      );
    })(),
    ht = null,
    ut = null;
  function ct(e) {
    return (function (e) {
      if (ut) return ut;
      var t = ["//", "ssl.p.jwpcdn.com/player/lib/omid/v/1.3.15/omweb-v1.js"];
      "file:" === document.location.protocol && t.unshift("https:");
      var i = new (0, e.scriptloader)(t.join(""));
      return (ut = i.load());
    })(e).then(function () {
      return (function (e) {
        if (ht) return ht;
        if (window.OmidSessionClient && OmidSessionClient.default)
          return (ht = Promise.resolve());
        var t = [
          "//",
          "ssl.p.jwpcdn.com/player/lib/omid/v/1.3.15/omid-session-client-v1.js",
        ];
        "file:" === document.location.protocol && t.unshift("https:");
        var i = new (0, e.scriptloader)(t.join(""));
        return (ht = i.load());
      })(e);
    });
  }
  var pt = [];
  var ft = (function () {
      function e(e, t, i, r, a, n) {
        var s = this,
          o = t || {};
        (this.ad = e),
          (this.map = o),
          (this.omidDeferredEvents = []),
          n &&
            e.adVerifications &&
            "disabled" !== a.omidSupport &&
            (n.on(
              v,
              function () {
                n.off(null, null, s), s.trackOmidEvent(v);
              },
              this
            ),
            ct(r.utils).then(function () {
              var t = window.OmidSessionClient.default,
                i = n.getMediaElement();
              (s.omidTracker = new dt(
                r,
                t,
                i,
                e.adVerifications,
                e.linear,
                a,
                s.trackPingsByUrl.bind(s)
              )),
                s.omidDeferredEvents.forEach(function (e) {
                  var t = e.type,
                    i = e.args;
                  s.trackOmidEvent.apply(s, [t].concat(i));
                }),
                (s.omidDeferredEvents = []);
            })),
          (this.debugTrackFn = i),
          (this.trackerPlayerUtils = (function (e) {
            return {
              getPosition: function () {
                return e.getPosition();
              },
              getFile: function () {
                return e.getPlaylistItem().file;
              },
              getPlacement: function () {
                return J(e.getConfig());
              },
              getUserAgent: function () {
                return navigator.userAgent;
              },
            };
          })(r)),
          (this.trackingFilter = a.trackingFilter),
          (this.lastQuartile = 0),
          (this.progressEvents = []),
          (this.breakStarted = !1),
          (this.started = !1),
          (this.firedError = !1),
          (this.hasComp = !1),
          (this.buffering = !1),
          Object.keys(o).forEach(function (e) {
            if (o.hasOwnProperty(e) && 0 === e.indexOf("progress")) {
              var t = "" + e.split("_")[1],
                i = { key: e, offset: t, tracked: !1, percentage: !1 };
              /^\d+%$/.test(t)
                ? ((i.percentage = !0), (i.offset = parseFloat(t)))
                : (i.offset = r.utils.seconds(t)),
                s.progressEvents.push(i);
            }
          }),
          this.setFactories();
      }
      var t = e.prototype;
      return (
        (t.getUrls = function (e) {
          return this.map.hasOwnProperty(e) ? this.map[e] : [];
        }),
        (t.addUrl = function (e, t) {
          this.map.hasOwnProperty(e) || (this.map[e] = []), this.map[e].push(t);
        }),
        (t.trackPingsByUrl = function (e, t, i) {
          void 0 === i && (i = {});
          var r = this.trackingFilter,
            a = [],
            n = [],
            s = [];
          if (t.length) {
            (i = this.replaceMacros(i)),
              t.forEach(function (e) {
                if (e) {
                  if (
                    (Object.keys(i).forEach(function (t) {
                      e = e.replace(t, i[t]);
                    }),
                    r && !1 === r(e))
                  )
                    return void n.push(e);
                  var t = new Image();
                  (t.src = e), a.push(e), s.push(t);
                }
              }),
              Array.prototype.push.apply(pt, s);
            for (var o = pt.length; o-- && (pt[o].width || pt[o].complete); )
              pt.length = o;
          }
          "function" == typeof this.debugTrackFn &&
            this.debugTrackFn({
              type: "ping",
              data: { pingType: e, urls: a, filteredUrls: n, images: s },
            });
        }),
        (t.trackPings = function (e, t) {
          var i = this.getUrls(e);
          this.trackPingsByUrl(e, i, t);
        }),
        (t.trackOmidEvent = function (e) {
          for (
            var t,
              i = arguments.length,
              r = new Array(i > 1 ? i - 1 : 0),
              a = 1;
            a < i;
            a++
          )
            r[a - 1] = arguments[a];
          this.omidTracker
            ? (t = this.omidTracker).trackEvent.apply(t, [e].concat(r))
            : this.omidDeferredEvents.push({ type: e, args: r });
        }),
        (t.replaceMacros = function (e) {
          var t,
            i,
            r,
            a,
            n,
            s,
            o,
            l = Ae,
            d = l.gdprApplies,
            h = l.consentData;
          return (
            (e["[ADSERVINGID]"] = encodeURIComponent(
              this.ad.adServingId || ""
            )),
            (e["[ASSETURI]"] = encodeURIComponent(
              this.trackerPlayerUtils.getFile()
            )),
            (e["[CACHEBUSTING]"] = Math.random().toString().slice(2, 10)),
            (e["[CONTENTPLAYHEAD]"] = encodeURIComponent(
              ((t = this.trackerPlayerUtils.getPosition()),
              (i = ("0" + Math.floor(t / 3600)).slice(-2)),
              (r = ("0" + Math.floor((t - 3600 * i) / 60)).slice(-2)),
              i +
                ":" +
                r +
                ":" +
                ("0" + Math.floor(t - 3600 * i - 60 * r)).slice(-2) +
                "." +
                (t % 1).toFixed(3).toString().slice(2, 5))
            )),
            (e["[DEVICEUA]"] = encodeURIComponent(
              this.trackerPlayerUtils.getUserAgent()
            )),
            (e["[GDPRCONSENT]"] = h),
            (e["[PAGEURL]"] = encodeURIComponent(G().url)),
            (e["[PLACEMENTTYPE]"] = this.trackerPlayerUtils.getPlacement()),
            (e["[REGULATIONS]"] = d ? "gdpr" : ""),
            (e["[TIMESTAMP]"] = encodeURIComponent(
              ((a = new Date()),
              (n = a.getTime()),
              (s = a.getTimezoneOffset() / 60),
              (o = 6e4 * a.getTimezoneOffset()),
              new Date(n - o).toISOString().slice(0, -1) +
                (s > 0 ? "-" : "+") +
                ("0" + s).slice(-2))
            )),
            e
          );
        }),
        (t.start = function () {
          (this.started = !0), this.trackPings("start");
        }),
        (t.breakStart = function () {
          (this.breakStarted = !0), this.trackPings("breakStart");
        }),
        (t.time = function (e, t) {
          if (!(t <= 1)) {
            for (
              var i = ((4 * e + 0.05) / t) | 0;
              i > this.lastQuartile && this.lastQuartile < 3;

            )
              this.lastQuartile++,
                1 === this.lastQuartile
                  ? (this.trackPings("firstQuartile"),
                    this.trackOmidEvent("firstQuartile"))
                  : 2 === this.lastQuartile
                  ? (this.trackPings("midpoint"),
                    this.trackOmidEvent("midpoint"))
                  : 3 === this.lastQuartile &&
                    (this.trackPings("thirdQuartile"),
                    this.trackOmidEvent("thirdQuartile"));
            this.trackProgress(e, t);
          }
        }),
        (t.trackProgress = function (e, t) {
          for (var i = this.progressEvents.length; i--; ) {
            var r = this.progressEvents[i];
            if (!r.tracked) {
              var a = r.offset;
              r.percentage && (a = (t * a) / 100),
                e >= a && ((r.tracked = !0), this.trackPings(r.key));
            }
          }
        }),
        (t.error = function (e) {
          void 0 === e && (e = 900), (this.firedError = !0);
          var t = {};
          (t["[ERRORCODE]"] = e), this.trackPings("error", t);
        }),
        (t.factory = function (e) {
          var t = this;
          return function () {
            if ((t.trackPings(e), "fullscreen" !== e)) {
              for (
                var i = arguments.length, r = new Array(i), a = 0;
                a < i;
                a++
              )
                r[a] = arguments[a];
              t.trackOmidEvent.apply(t, [e].concat(r));
            }
          };
        }),
        (t.setFactories = function () {
          (this.creativeView = this.factory("creativeView")),
            (this.click = this.factory("click")),
            (this.skip = this.factory("skip")),
            (this.complete = this.factory("complete")),
            (this.pause = this.factory("pause")),
            (this.resume = this.factory("resume")),
            (this.mute = this.factory("mute")),
            (this.unmute = this.factory("unmute")),
            (this.fullscreen = this.factory("fullscreen")),
            (this.expand = this.factory("expand")),
            (this.collapse = this.factory("collapse")),
            (this.acceptInvitation = this.factory("acceptInvitation")),
            (this.close = this.factory("close")),
            (this.rewind = this.factory("rewind")),
            (this.impression = this.factory("impression")),
            (this.viewable = this.factory("viewable")),
            (this.notViewable = this.factory("notviewable")),
            (this.breakEnd = this.factory("breakEnd"));
        }),
        e
      );
    })(),
    mt = (function () {
      function e(e, t, i, r, a) {
        (this._scheduledAd = e),
          (this.player = t),
          (this.options = i),
          (this.item = i.item),
          (this.params = i.params || {}),
          (this.wrapperOptions = r || {}),
          "boolean" != typeof this.wrapperOptions.followAdditionalAds &&
            (this.wrapperOptions.followAdditionalAds = !0),
          "boolean" != typeof this.wrapperOptions.allowMultipleAds &&
            (this.wrapperOptions.allowMultipleAds = !0),
          (this.debugTrackFn = a),
          B(this, t.Events),
          (this._history = []),
          (this.loadedAds = []),
          (this.parser = null),
          (this.promise = null),
          (this.xmlhttp = null),
          (this.wrappedTags = null),
          this.options.isPodItemLoader || (e.adPlayIds = {});
      }
      var i = e.prototype;
      return (
        (i.load = function (e) {
          var t = this;
          if (null === this.promise) {
            this._history.push(e);
            var i = this.options.requestFilter;
            this.promise = new Promise(function (r, a) {
              t.xmlhttp = t.player.utils.ajax(
                {
                  url: e,
                  withCredentials: t.params.withCredentials,
                  retryWithoutCredentials: !0,
                  requireValidXML: !0,
                  timeout: t._scheduledAd.requestTimeout,
                  requestFilter: i,
                },
                r,
                function (e, t, i, r) {
                  return a(r);
                }
              );
            })
              .catch(function (i) {
                if (null !== t.player) throw t.ajaxError(i, e);
              })
              .then(function (i) {
                if (null !== t.player) {
                  var r = i.responseXML || i.responseText;
                  return (
                    t.trigger(m, { tag: e, xml: r }), t.parseXMLString(r, e)
                  );
                }
              });
          }
          return this.promise;
        }),
        (i.destroy = function () {
          var e;
          (e = this.xmlhttp) &&
            ((e.onload = null),
            (e.onreadystatechange = null),
            (e.onerror = null),
            e.abort && e.abort()),
            (this.player = null),
            (this.xmlhttp = null);
        }),
        (i.scheduledAd = function () {
          return this._scheduledAd;
        }),
        (i.allAds = function () {
          return this.loadedAds;
        }),
        (i.podMultipleVastLoaders = function (e) {
          var t = this,
            i = e.map(function (e) {
              return e
                .then(function (e) {
                  var i = e.adPod();
                  if (i.length) return i;
                  var r = e.adBuffet();
                  return r.length
                    ? [r[0]]
                    : Promise.reject({
                        vloader: t,
                        message: "No compatible ad",
                      });
                })
                .catch(function (e) {
                  return { error: e };
                });
            });
          return Promise.all(i).then(function (e) {
            var i = 0,
              r = e.reduce(function (e, r, a) {
                if (r.error)
                  return (r.error.tagIndex = a), t.trigger(P, r.error), e;
                if (r.length && 0 !== a) {
                  var n = "p" + i + "w" + t._scheduledAd._waterfallIndex;
                  t._scheduledAd.adPlayIds[n] = t._scheduledAd.adRequestIds[a];
                }
                return (
                  r.forEach(function (t) {
                    (t.sequence = ++i), e.push(t);
                  }),
                  e
                );
              }, []);
            return r.length ? ((t.loadedAds = r), t) : null;
          });
        }),
        (i.adPod = function () {
          var e = [];
          return (
            this.loadedAds.forEach(function (t) {
              t.sequence && e.push(t);
            }),
            e.sort(function (e, t) {
              return e.sequence - t.sequence;
            }),
            e
          );
        }),
        (i.adBuffet = function () {
          var e = [];
          return (
            this.loadedAds.forEach(function (t) {
              t.sequence || e.push(t);
            }),
            e
          );
        }),
        (i.parseXMLString = function (i, r) {
          var a = this;
          return (
            null === this.parser &&
              (this.parser = new Fe(null, this.player.utils)),
            new Promise(function (e) {
              var t,
                r =
                  ((t = i),
                  (
                    "object" == typeof Node
                      ? t instanceof Node
                      : t &&
                        "object" == typeof t &&
                        "number" == typeof t.nodeType &&
                        "string" == typeof t.nodeName
                  )
                    ? i
                    : a.player.utils.parseXML(i));
              if (null === r) {
                throw { message: "Invalid XML", code: 100 };
              }
              return e(a.parser.parse(r, a.xmlhttp));
            })
              .catch(function (e) {
                if (null !== a.player) {
                  var t = e.code || 900,
                    i = e.adErrorCode || 1e4 + t;
                  throw a.sendErrorEvent(e.message, t, i, r);
                }
              })
              .then(function (i) {
                if (null === a.player) return null;
                if (0 === i.length)
                  throw a.sendErrorEvent("No ads", 303, 10303, r);
                var n = i
                  .filter(function (e) {
                    return !e.sequence;
                  })
                  .map(function (e) {
                    return (e._currentTag = r), e;
                  });
                a.wrapperOptions.allowMultipleAds
                  ? (a.loadedAds = i)
                  : (a.loadedAds = n),
                  (a.options.wrapper = a.options.wrapper || []);
                var s = a.options,
                  o = s.adsystem,
                  l = s.dealId;
                o && a.options.wrapper.push(o),
                  l && (a.options.wrapperDealId = l),
                  (a.options.adsystem = a.loadedAds[0].adsystem),
                  (a.options.dealId = a.loadedAds[0].dealId);
                var d = [];
                return (
                  i.forEach(function (i, r) {
                    if (i.wrappedURI) {
                      if (!1 === a.wrapperOptions.followAdditionalWrappers)
                        return;
                      (a.options.wrappedTags = a.options.wrappedTags || [
                        a._scheduledAd._currentTag,
                      ]),
                        a.options.wrappedTags.push(i.wrappedURI);
                      var s = new e(
                        a._scheduledAd,
                        a.player,
                        a.options,
                        {
                          fallbackOnNoAd: i.fallbackOnNoAd,
                          allowMultipleAds: i.allowMultipleAds,
                          followAdditionalWrappers: i.followAdditionalWrappers,
                        },
                        a.debugTrackFn
                      );
                      s.on(
                        m,
                        function (e) {
                          a.trigger(m, e);
                        },
                        a
                      );
                      var o = Re(i.wrappedURI, a.player, a.item, t, a.params, i)
                        .then(function (e) {
                          return s.load(e);
                        })
                        .then(function (e) {
                          s.off(m, null, a);
                          var t,
                            r,
                            n,
                            o =
                              ((t = i),
                              (r = e.allAds()),
                              (n = []),
                              r.forEach(function (e) {
                                var i, r;
                                t.companions &&
                                  (e.companions = (
                                    e.companions ? e.companions : []
                                  ).concat(t.companions)),
                                  t.trackers &&
                                    (e.trackers =
                                      ((i = e.trackers),
                                      (r = t.trackers),
                                      (i = i || {}),
                                      Object.keys(r).forEach(function (e) {
                                        var t = r[e];
                                        i[e]
                                          ? (i[e] = i[e].concat(t))
                                          : (i[e] = t);
                                      }),
                                      i)),
                                  t.sequence && (e.sequence = t.sequence),
                                  t._currentTag &&
                                    (e._currentTag = t._currentTag),
                                  t.adVerifications &&
                                    (e.adVerifications = (
                                      e.adVerifications ? e.adVerifications : []
                                    ).concat(t.adVerifications)),
                                  n.push(e);
                              }),
                              n),
                            l = a.loadedAds.indexOf(i);
                          Array.prototype.splice.apply(
                            a.loadedAds,
                            [l, 1].concat(o)
                          );
                        })
                        .catch(function (e) {
                          s.off(m, null, a);
                          var t = a.sendAdpodErrorEvent(e, i, r),
                            o = i.fallbackOnNoAd && i.sequence && n.length,
                            l = a.loadedAds.indexOf(i);
                          if (o)
                            return (i.loadError = t), void e.vloader.destroy();
                          if (
                            (a.loadedAds.splice(l, 1),
                            e.vloader.destroy(),
                            t.type !== P)
                          )
                            throw t;
                          a.trigger(P, t);
                        });
                      d.push(o);
                    } else a.options.wrapper.length && ((i.wrapper = a.options.wrapper), (i.wrappedTags = a.options.wrappedTags), (i.dealId = a.options.wrapperDealId));
                  }),
                  Promise.all(d)
                );
              })
              .then(function () {
                if (null === a.player) return null;
                var e = a.loadedAds.filter(function (e) {
                  return !e.sequence;
                });
                a.loadedAds.forEach(function (t, i) {
                  if (t.loadError)
                    if (e.length) {
                      var r = a.loadedAds[i + 1],
                        n = r && !r.sequence ? r : e[0];
                      a.loadedAds[i] = B({}, n, { sequence: t.sequence });
                    } else a.trigger(P, t.loadError);
                });
                var t = a.loadedAds.slice(0),
                  i = t.length;
                t.forEach(function (e) {
                  (e.media && e.media.length) || t.length--;
                });
                var r = 0 === i,
                  n = t.length !== i;
                if (r || n)
                  throw a.sendErrorEvent(
                    "Ad Tag Empty",
                    101,
                    10101,
                    a._history[a._history.length - 1]
                  );
                return a;
              })
          );
        }),
        (i.ajaxError = function (e, t) {
          if (this.player.getAdBlock())
            return this.sendErrorEvent(
              "Ad playback blocked by an ad blocker",
              900,
              60003,
              t
            );
          var i = e.code;
          if (601 === i || 602 === i)
            return this.sendErrorEvent("Invalid XML", 100, 10100, t);
          var r = this.options.wrappedTags && this.options.wrappedTags.length,
            a = r ? 301 : 900,
            n = r ? 10301 : 60006;
          return this.sendErrorEvent(
            e.message || "Error loading file",
            a,
            n,
            t
          );
        }),
        (i.firstUrl = function () {
          return this._history && this._history.length ? this._history[0] : "";
        }),
        (i.sendAdpodErrorEvent = function (e, t, i) {
          var r = e.message,
            a = e.code,
            n = e.adErrorCode,
            s = e.url;
          if (1 === this.loadedAds.length)
            return this.sendErrorEvent(r, a, n, s, i);
          var o = {
            message: r,
            code: a,
            adErrorCode: n,
            podIndex: i,
            vloader: this,
            tag: this.firstUrl() || s,
            type: P,
          };
          return this.trackError(o, t), (this.wrappedTags = s), o;
        }),
        (i.sendErrorEvent = function (e, t, i, r, a) {
          var n = {
            message: e,
            code: t,
            adErrorCode: i,
            podIndex: a,
            vloader: this,
            tag: this.firstUrl() || r,
            adsystem: this.options.adsystem || "",
          };
          return (
            this.options.wrappedTags &&
              ((n.wrapperAdSystem = this.options.wrapper || ""),
              (n.wrappedTags = this.options.wrappedTags)),
            this.trackError(n),
            n
          );
        }),
        (i.trackError = function (e, t) {
          var i = e.vloader.allAds();
          if (i && i.length) {
            var r = t || i[0];
            if (r) {
              var a = r.trackers;
              if (a && a.error)
                new ft(
                  r,
                  a,
                  this.debugTrackFn,
                  this.player,
                  this.options
                ).error(e.code);
            }
          }
        }),
        e
      );
    })();
  var vt = (function () {
    function e(e, t, i, r, a) {
      var n = this;
      (this.player = e),
        (this.state = e.state),
        (this.vpaidURL = i),
        (this.adTag = r),
        (this.adParams = a.adParams),
        (this.vpaidControls = a.vpaidControls),
        (this.remainingTimeInterval = null),
        (this.type = "vpaid"),
        (this.instream = t || e.createInstream()),
        (this.vpaidState = { linear: !1, expanded: !1, remainingTime: -1 }),
        (this.paused = !1),
        B(this, e.Events),
        (this.setMuteCallback = function () {
          n.handleMute ? n.setMute() : (n.handleMute = !0);
        }),
        (this.playerContainer = this.player.getContainer()),
        a.adOptOut
          ? setTimeout(function () {
              n.sendEvent("error", {
                message: "Conditional ad rejected",
                code: 408,
              });
            }, 0)
          : (this.iframe = (function (e, t, i, r) {
              var a = document.createElement("iframe");
              a.setAttribute("allow", "autoplay"),
                (a.src = "javascript:false"),
                a.classList.add("jw-vpaid-iframe"),
                (a.scrolling = "no"),
                i.querySelector(".jw-media").appendChild(a);
              var n = a.contentWindow.document;
              return (
                n
                  .open()
                  .write(
                    "\n    <body onload=\"\n        var js = document.createElement('script');\n        js.src = '" +
                      t +
                      "';\n        js.addEventListener('load', function() { window.myCallback(); });\n        document.body.appendChild(js);\"\n    style=\"margin: 0\">"
                  ),
                (a.contentWindow.myCallback = r),
                n.close(),
                a
              );
            })(
              e.utils,
              this.vpaidURL,
              this.playerContainer,
              this.callback.bind(this)
            ));
    }
    var t = e.prototype;
    return (
      (t.sendEvent = function (e, t) {
        (t = t || {}).tag || (t.tag = this.adTag), this.trigger(e, t);
      }),
      (t.sendTimeEvent = function (e, t, i) {
        var r = t.getAdDuration(),
          a = t.getAdRemainingTime(),
          n = B({ duration: r }, i);
        this.sendEvent(e, n),
          a > 0 && ((n.position = r - a), this.trigger("time", n));
      }),
      (t.handleQuartile = function (e, t) {
        this.sendTimeEvent("quartile", e, { quartile: t });
      }),
      (t.genEvent = function (e) {
        var t = this;
        return function (i) {
          t.on(e, i);
        };
      }),
      (t.setMute = function () {
        var e = 0 === this.vpaidAd.getAdVolume();
        this.player.getMute() !== e && this.player.setMute(e);
      }),
      (t.prepareNonlinearAd = function () {
        if (
          (this.player.utils.style(this.iframe, { height: 150 }),
          this.iframe.classList.add("jw-vpaid-non-linear"),
          this.resize(null, 150),
          this.instream)
        ) {
          (this.instream.noResume = !0),
            this.instream.applyProviderListeners(null),
            this.instream.destroy(),
            (this.instream = null);
          var e = this.playerContainer.querySelector(".jw-media"),
            t = e.querySelector("video,audio");
          e.insertBefore(t, this.iframe), t.play();
        }
      }),
      (t.progressInterval = function (e) {
        var t = this;
        if (
          (clearInterval(this.remainingTimeInterval), e && e.getAdRemainingTime)
        ) {
          var i = -1;
          this.remainingTimeInterval = setInterval(function () {
            if (!t.paused) {
              var r = e.getAdRemainingTime();
              isNaN(r) ||
                r <= 0 ||
                i === r ||
                ((i = r),
                t.sendTimeEvent("remainingTimeChange", e, {
                  remainingTime: r,
                }));
            }
          }, 250);
        }
      }),
      (t.genListeners = function (e) {
        var t = this;
        return {
          AdLoaded: function () {
            e.setAdVolume(t.getPlayerVolume()), e.startAd();
          },
          AdStarted: function () {
            var i = e.getAdDuration ? e.getAdDuration() : 0,
              r = !e.getAdLinear || e.getAdLinear(),
              n = r ? "linear" : "nonlinear";
            if (r) {
              (t.instream = t.instream || t.player.createInstream()),
                t.vpaidControls || t.instream.hide();
              var s = t.instream.getMediaElement();
              t.player.getPip() && t.player.requestPip(s),
                t.progressInterval(e);
            } else t.prepareNonlinearAd();
            t.sendEvent("impression", { linear: n, duration: i }),
              t.sendEvent("play", {
                oldstate: "buffering",
                newstate: a,
                linear: n,
              }),
              (t.handleMute = !0),
              e.subscribe(t.setMuteCallback, "AdVolumeChange", e);
          },
          AdVideoStart: function () {
            t.sendEvent("started");
          },
          AdStopped: function () {
            t.sendEvent("stopped");
          },
          AdPaused: function () {
            t.paused ||
              ((t.paused = !0),
              t.sendEvent("pause", { newstate: r, oldstate: a }));
          },
          AdPlaying: function () {
            if (t.paused) {
              var i =
                !e.getAdLinear || e.getAdLinear() ? "linear" : "nonlinear";
              (t.paused = !1),
                t.sendEvent("play", { newstate: a, oldstate: r, linear: i });
            }
          },
          AdLinearChange: function () {
            !e.getAdLinear || e.getAdLinear()
              ? (t.player.utils.style(t.iframe, { height: "100%" }),
                t.player.off(null, null, t),
                (t.instream = t.instream || t.player.createInstream()),
                t.instream.init(),
                t.vpaidControls || t.instream.hide())
              : t.prepareNonlinearAd();
          },
          AdDurationChange: function () {
            t.sendTimeEvent("remainingTimeChange", e, {
              isDurationChange: !0,
              remainingTime: e.getAdRemainingTime(),
            });
          },
          AdRemainingTimeChange: function () {
            t.paused ||
              t.sendTimeEvent("remainingTimeChange", e, {
                remainingTime: e.getAdRemainingTime(),
              });
          },
          AdExpandedChange: function () {
            t.sendEvent("expandedChange", { expanded: e.getAdExpanded() });
          },
          AdSkippableStateChange: function () {
            t.sendEvent("skippableStateChange", {
              skippable: e.getAdSkippableState(),
            });
          },
          AdSkipped: function () {
            t.sendEvent("skipped");
          },
          AdVideoFirstQuartile: function () {
            t.handleQuartile(e, 1);
          },
          AdVideoMidpoint: function () {
            t.handleQuartile(e, 2);
          },
          AdVideoThirdQuartile: function () {
            t.handleQuartile(e, 3);
          },
          AdVideoComplete: function () {
            t.sendEvent("complete");
          },
          AdUserClose: function () {
            t.sendEvent("close");
          },
          AdClickThru: function (e, i, r) {
            t.sendEvent("click", { id: i, url: e, playerHandles: r });
          },
          AdError: function (e) {
            var i = (function (e) {
              if (e) {
                var t = e.match(/\b(?:[34])[0-9]{2}\b/);
                if (t) return parseInt(t[0], 10);
                if (e.match(/timeout/i))
                  return e.match(/vpaid|vast/i) ? 301 : 402;
                if (e.match(/found/i)) return 401;
                if (e.match(/supported/i)) return 403;
                if (e.match(/(?:displaying|media file)/i)) return 405;
              }
              return 901;
            })(e);
            t.sendEvent("error", { message: e, code: i, adErrorCode: 5e4 + i });
          },
        };
      }),
      (t.callback = function () {
        try {
          this.vpaidAd = this.iframe.contentWindow.getVPAIDAd();
          var e = this.vpaidAd.handshakeVersion("2.0");
          if (parseFloat(e) < 1)
            throw new Error("Invalid vpaid version in handshake");
        } catch (e) {
          return void this.sendEvent("error", {
            message: e.message || "VPAID general error",
            code: 901,
            adErrorCode: 51901,
          });
        }
        var t = this.vpaidAd,
          i = this.genListeners(t);
        Object.keys(i).forEach(function (e) {
          t.subscribe(i[e], e, t);
        }),
          (this.listeners = i);
        var r = { AdParameters: this.adParams },
          a = this.iframe.contentWindow.document.createElement("div");
        (a.className = "jw-vpaid-wrapper"),
          (a.style.height = "100%"),
          this.iframe.contentWindow.document.body.appendChild(a),
          this.vpaidURL.indexOf(
            "//imasdk.googleapis.com/js/sdkloader/vpaid_adapter.js"
          ) >= 0 &&
            (this.iframe.contentWindow.HTMLVideoElement = HTMLVideoElement);
        var n = { videoSlot: this.instream.getMediaElement(), slot: a };
        t.initAd(
          this.player.getWidth(),
          this.player.getHeight(),
          "normal",
          1e3,
          r,
          n
        ),
          t.setAdVolume(this.getPlayerVolume());
      }),
      (t.play = function () {
        this.vpaidAd.resumeAd();
      }),
      (t.pause = function () {
        this.vpaidAd.pauseAd();
      }),
      (t.skip = function () {
        return (
          !(!this.vpaidAd.skipAd || !this.vpaidAd.getAdSkippableState()) &&
          (this.vpaidAd.skipAd(), !0)
        );
      }),
      (t.stop = function () {
        if (this.vpaidAd)
          try {
            this.vpaidAd.stopAd();
          } catch (e) {}
      }),
      (t.getPlayerVolume = function () {
        return this.player.getMute() ? 0 : this.player.getVolume() / 100;
      }),
      (t.setVolume = function (e) {
        (this.handleMute = !1), this.vpaidAd.setAdVolume(e / 100);
      }),
      (t.resize = function (e, t) {
        if (this.vpaidAd && this.vpaidAd.resizeAd) {
          var i =
            this.player.getFullscreen() ||
            document.fullScreen ||
            document.mozFullScreen ||
            document.webkitIsFullScreen
              ? "fullscreen"
              : "normal";
          this.vpaidAd.resizeAd(
            e || this.player.getWidth(),
            t || this.player.getHeight(),
            i
          );
        }
      }),
      (t.destroy = function () {
        var e = this;
        if (
          (this.removeEvents(),
          clearInterval(this.remainingTimeInterval),
          this.vpaidAd)
        )
          try {
            var t = this.listeners,
              i = this.vpaidAd;
            Object.keys(t).forEach(function (e) {
              i.unsubscribe(t[e], e, i);
            }),
              i.unsubscribe(this.setMuteCallback, "AdVolumeChange", i);
          } catch (e) {}
        setTimeout(function () {
          e.iframe &&
            e.iframe.parentNode &&
            e.iframe.parentNode.removeChild(e.iframe);
        }, 0),
          (this.vpaidAd = null),
          (this.player = null),
          (this.instream = null);
      }),
      (t.removeEvents = function () {
        this.player && this.player.off(null, null, this), this.off();
      }),
      (t.attachMedia = function () {}),
      (t.detachMedia = function () {}),
      (t.volume = function () {}),
      (t.mute = function () {}),
      (t.getState = function () {
        return this.vpaidState.linear ? (this.paused ? r : a) : "idle";
      }),
      e
    );
  })();
  var gt = (function () {
    function e(e, t, i) {
      (this.player = e), (this.icon = t), (this.div = i);
      var r = (this.utils = e.utils);
      (this.images = []),
        (this.iconContainer = (function (e, t) {
          var i = document.createElement("div");
          return (i.className = "jw-ad-icon-container"), t.style(i, e), i;
        })(t.style, r));
      var a = (function (e, t) {
        var i,
          r = e.resourceSource,
          a = e.resourceType;
        switch (a) {
          case "iframe":
            ((i = document.createElement("iframe")).src = r),
              (i.scrolling = "no");
            break;
          case "html":
            (i = document.createElement("div")), t.replaceInnerHtml(i, r);
            break;
          default:
            ((i = document.createElement("img")).src = r),
              i.setAttribute("type", a);
        }
        return t.addClass(i, "jw-ad-icon"), i;
      })(t.resource, r);
      this.iconContainer.appendChild(a), i.appendChild(this.iconContainer);
      var n = 1e3 * r.seconds(t.offset);
      n > 0
        ? (this.showTimeout = setTimeout(this.show.bind(this), n))
        : this.show(),
        (this.ui = new r.UI(this.iconContainer).on(
          "click",
          this.clickHandler,
          this
        ));
    }
    var t = e.prototype;
    return (
      (t.clickHandler = function () {
        this.player.pause({ reason: E }),
          this.sendPing(this.icon.trackers.iconClick),
          this.utils.openLink(this.icon.clickThrough, "_blank", {
            rel: "noreferrer",
          });
      }),
      (t.show = function () {
        clearTimeout(this.showTimeout),
          this.utils.addClass(this.iconContainer, "jw-ad-icon-active"),
          this.sendPing(this.icon.trackers.iconView),
          this.icon.duration &&
            ((this.duration = this.utils.seconds(this.icon.duration)),
            (this.beginningPosition = this.utils.seconds(this.icon.offset)));
      }),
      (t.updateTime = function (e) {
        e - this.beginningPosition >= this.duration && this.remove();
      }),
      (t.sendPing = function (e) {
        if (e) {
          var t = this.images,
            i = new Image();
          i.src = e;
          for (var r = t.length; r-- && (t[r].width || t[r].complete); )
            t.length = r;
          t.push(i);
        }
      }),
      (t.remove = function () {
        clearTimeout(this.showTimeout),
          this.div.contains(this.iconContainer) &&
            this.div.removeChild(this.iconContainer),
          this.ui && (this.ui.destroy(), (this.ui = null));
      }),
      e
    );
  })();
  var yt = (function () {
    function e(e, t, i) {
      (this.player = t), (this.playlistItemManager = i);
      var r = i.adPlayerProperties,
        a = r.staticPlayer,
        n = r.companion,
        s = r.div,
        o = r.optionalParams;
      (this.staticPlayer = a),
        (this.companion = n),
        (this.div = s),
        (this.optionalParams = o),
        (this.omidSupport = o.omidSupport),
        (this.debugTrackFn = o.debugTrackFn),
        (this.scheduledAd = e.scheduledAd()),
        (this.vastBuffet = e.adBuffet()),
        (this.vastAdPod = e.adPod()),
        (this.vastAd = this.vastBuffet.length ? this.vastBuffet[0] : null),
        (this.adType = null),
        (this.vpaidPlayer = null),
        (this.instreamPlayer = null),
        (this.blockingInstreamPlayer = null),
        (this.mediaType = null),
        (this.adPodItems = null),
        (this.creativeTimeout = null),
        (this.vastOptions = null),
        (this.duration = 0),
        (this.position = 0),
        (this.initialIndex = 0),
        (this.viewablePlayedTime = 0),
        (this.adViewableImpressionHandler = t.utils.noop),
        (this.lastPosition = null),
        (this.reason = null),
        B(this, t.Events);
    }
    var t = e.prototype;
    return (
      (t.init = function (e, t) {
        return (
          (this.init = function () {
            throw new Error("Adplayer can only be initialized once");
          }),
          (this.blockingInstreamPlayer = e),
          (this.reason = t),
          this.prepareAdPod()
            ? (this.player.on(n, this.playerFullscreenHandler, this),
              this.player.on(s, this.playerVolumeHandler, this),
              this.player.on(o, this.muteHandler, this),
              this.player.on(d, this.playerResizeHandler, this),
              this.playAd())
            : Promise.reject()
        );
      }),
      (t.prepareAdPod = function () {
        var e,
          t = this,
          i = null,
          r = 0,
          a = [];
        if (
          (this.vastAd &&
            (Pt(
              this.vastAd,
              this.debugTrackFn,
              this.player,
              this.optionalParams,
              this.blockingInstreamPlayer
            ),
            (i = this.prepareAdPodItem(this.vastAd)) &&
              "vpaid" === i.adType &&
              !At(this.vastAd) &&
              (i = null)),
          this.vastAdPod)
        )
          for (var n = null, s = 0; s < this.vastAdPod.length; s++) {
            var o = this.vastAdPod[s];
            Pt(
              o,
              this.debugTrackFn,
              this.player,
              this.optionalParams,
              this.blockingInstreamPlayer
            );
            var l = this.prepareAdPodItem(o);
            if (l) {
              if (n !== l.adType && "instream" === n) break;
              if (((n = l.adType), "vpaid" !== l.adType || At(o))) {
                var d = a.length + r === s;
                l && d && a.push(l);
              } else r++;
            } else r++;
          }
        return a.length || i
          ? (a.length
              ? ((e = a),
                (this.vastOptions = []),
                e.forEach(function (e) {
                  t.vastOptions.push(t.getInstreamOptions(e.vastAd));
                }))
              : ((e = i),
                (this.vastOptions = this.getInstreamOptions(this.vastAd))),
            (this.adPodItems = e),
            !0)
          : ((this.scheduledAd._pod && this.scheduledAd._pod.length) ||
              this.adError("No Compatible Creatives", 403),
            !1);
      }),
      (t.prepareAdPodItem = function (e) {
        e.tracker.linear = "linear";
        var t = ("" + e.media[0].adType).toLowerCase() || "instream";
        "vpaid" !== t || At(e) || (t = "instream");
        var i = { vastAd: e, sources: [], adType: t };
        void 0 !== this.scheduledAd.skipoffset &&
          (i.skipoffset = this.scheduledAd.skipoffset);
        var r = e.media,
          a = {};
        if (
          (r.forEach(function (e, t) {
            i.sources.push({
              file: e.file,
              mimeType: e.type,
              type: ("" + e.type).replace(/^(?:video|audio)\/(?:x-)?/, ""),
              id: t,
            }),
              (a[e.file] = {
                width: e.width || 0,
                height: e.height || 0,
                bitrate: e.bitrate || e.maxBitrate,
                id: t,
              });
          }),
          "instream" === t &&
            (i.sources = (function (e) {
              var t;
              t = jwplayer.api.availableProviders.filter(function (e) {
                return "flash" !== e.name;
              });
              var i = e.filter(function (e) {
                  return t.some(function (t) {
                    return t.supports(e);
                  });
                }),
                r = i.filter(function (e) {
                  return "3gpp" !== e.type;
                });
              return r.length ? r : i;
            })(i.sources)),
          0 === i.sources.length)
        )
          return null;
        var n = this.player.getSafeRegion(!1).width,
          s = this.player.getConfig().bandwidthEstimate || 5e5,
          o = (function () {
            var e = (s / 1e3) * 0.95,
              t = i.sources.map(function (e) {
                return a[e.file];
              }),
              r = t
                .filter(function (e) {
                  return e.width >= n;
                })
                .sort(function (e, t) {
                  return e.width - t.width;
                });
            r.length ||
              (r = t.sort(function (e, t) {
                return t.width - e.width;
              }));
            var o = r.filter(function (e) {
              return e.width === r[0].width;
            });
            if (o.length > 1) {
              var l = o.reduce(function (t, i) {
                  return i.bitrate < e && i.bitrate > t.bitrate ? i : t;
                }),
                d = o.reduce(function (t, i) {
                  return i.bitrate >= e && i.bitrate < t.bitrate ? i : t;
                });
              return l || d;
            }
            return o[0];
          })().id;
        return (
          (i.vastAd.selectedMedia = i.sources.filter(function (e) {
            return e.id === o;
          })[0]),
          (this.mediaType = i.vastAd.selectedMedia.mimeType.toLowerCase()),
          (i.sources = [i.vastAd.selectedMedia]),
          i
        );
      }),
      (t.getInstreamOptions = function (e) {
        return {
          skipoffset: this.getSkipOffset(e),
          skipMessage: this.optionalParams.skipMessage,
          skipText: this.optionalParams.skipText,
        };
      }),
      (t.getSkipOffset = function (e) {
        var t = [
          this.scheduledAd.skipoffset,
          this.optionalParams.skipoffset,
          e.skipoffset,
        ].filter(function (e) {
          return null != e;
        });
        return (
          (e.skipoffset = t.length ? this.player.utils.seconds(t[0]) : void 0),
          e.skipoffset
        );
      }),
      (t.getVastAd = function () {
        var e,
          t = this.scheduledAd._adPodIndex;
        if (this.adPodItems) {
          if (
            (e = this.adPodItems.length ? this.adPodItems[t] : this.adPodItems)
              .vastAd
          )
            return e.vastAd;
        } else if (this.vastAdPod && this.vastAdPod.length)
          return this.vastAdPod[t];
        return this.vastAd;
      }),
      (t.adError = function (e, t, i) {
        clearTimeout(this.creativeTimeout), (this.creativeTimeout = null);
        var r = this.getVastAd();
        wt(r), (t = t || 900);
        var a = "vpaid" === this.adType ? 5e4 : 1e4;
        i = i || a + t;
        var n = B({}, this.scheduledAd, r),
          s = { jwpseg: n.jwpseg },
          o = $(
            this.playlistItemManager,
            { message: e, code: t, adErrorCode: i },
            n,
            s
          );
        this.vastAdPod &&
        this.scheduledAd._adPodIndex < this.vastAdPod.length - 1
          ? this.triggerEvent(P, o)
          : (r.tracker.error(o.code),
            this.triggerEvent(c, o),
            this.removePlayerListeners());
      }),
      (t.playAd = function () {
        var e = this.scheduledAd._adPodIndex,
          t = this.adPodItems[e] || this.adPodItems;
        if (((this.adType = t.adType), this.blockingInstreamPlayer)) {
          var i = this.optionalParams.loadingAd;
          this.blockingInstreamPlayer.setText(i);
        }
        if ("vpaid" === this.adType) return this.playVpaid(t.vastAd);
        if ("static" === this.adType)
          return this.playStatic(), Promise.resolve();
        var r = Array.isArray(this.adPodItems)
            ? this.adPodItems.slice(e)
            : this.adPodItems,
          a = Array.isArray(this.vastOptions)
            ? this.vastOptions.slice(e)
            : this.vastOptions;
        return (
          (this.initialIndex = e),
          this.playInstream(r, a).catch(this.player.utils.noop)
        );
      }),
      (t.clearVpaidBlocking = function () {
        var e = this.vpaidPlayer.instream;
        e &&
          e !== this.blockingInstreamPlayer &&
          ((this.vpaidPlayer.instream = null), this.clearBlocking(e));
      }),
      (t.clearBlocking = function (e) {
        (e = e || this.blockingInstreamPlayer) &&
          e !== this.instreamPlayer &&
          e.destroy();
      }),
      (t.getState = function () {
        return this.instreamPlayer
          ? this.instreamPlayer.getState()
          : this.vpaidPlayer
          ? this.vpaidPlayer.getState()
          : "";
      }),
      (t.clearNonlinear = function () {
        this.staticPlayer.stop(),
          this.vpaidPlayer &&
            (this.clearVpaidBlocking(),
            this.vpaidPlayer &&
              (this.vpaidPlayer.stop(),
              this.vpaidPlayer.destroy(),
              (this.vpaidPlayer = null)));
      }),
      (t.destroy = function () {
        if (
          (this.off(),
          this.removePlayerListeners(),
          clearTimeout(this.creativeTimeout),
          (this.creativeTimeout = null),
          this.instreamPlayer)
        ) {
          var e = this.instreamPlayer;
          (this.instreamPlayer = null), this.clearBlocking(e);
        }
        this.vpaidPlayer &&
          (this.clearVpaidBlocking(),
          this.vpaidPlayer &&
            (this.vpaidPlayer.destroy(), (this.vpaidPlayer = null))),
          this.clearNonlinear(),
          wt(this.vastAd),
          (this.player = null),
          (this.instreamPlayer = null),
          (this.scheduledAd = null),
          (this.vastBuffet = null),
          (this.vastAd = null),
          (this.vastAdPod = null);
      }),
      (t.pause = function (e) {
        var t = e.reason;
        (this.reason = t || T),
          this.instreamPlayer
            ? this.instreamPlayer.pause()
            : this.vpaidPlayer && this.vpaidPlayer.pause();
      }),
      (t.play = function (e) {
        var t = e.reason;
        (this.reason = t || T),
          this.instreamPlayer
            ? this.instreamPlayer.play()
            : this.vpaidPlayer && this.vpaidPlayer.play();
      }),
      (t.skip = function () {
        if (this.instreamPlayer) {
          var e = this.getSkipOffset(this.getVastAd());
          if (e > 0 && this.position < e) return;
          this.instreamPlayer.skipAd();
        } else this.vpaidPlayer && this.vpaidPlayer.skip();
      }),
      (t.removePlayerListeners = function () {
        this.player &&
          (this.player.off(n, this.playerFullscreenHandler, this),
          this.player.off(s, this.playerVolumeHandler, this),
          this.player.off(o, this.muteHandler, this),
          this.player.off(l, this.viewableHandler, this),
          this.player.off(d, this.playerResizeHandler, this)),
          this.instreamPlayer && this.instreamPlayer.off(null, null, this),
          this.vpaidPlayer &&
            (this.vpaidPlayer.removeEvents(),
            this.clearVpaidBlocking(),
            this.vpaidPlayer &&
              (this.vpaidPlayer.destroy(), (this.vpaidPlayer = null))),
          this.staticPlayer.stop(),
          this.staticPlayer.removeEvents();
      }),
      (t.adEventObject = function (e) {
        var t = this.getVastAd(),
          i = B({}, this.scheduledAd, t),
          r = Y(this.playlistItemManager, i);
        return (
          (r.viewable = this.player.getViewable()),
          this.adPodItems &&
            this.adPodItems.length &&
            ((r.sequence = this.scheduledAd._adPodIndex + 1),
            (r.podcount = this.adPodItems.length)),
          this.mediaType && (r.creativetype = this.mediaType),
          this.scheduledAd._vmap && (r.vmap = this.scheduledAd._vmap),
          -1 !== j.indexOf(e) &&
            ((r.universalAdId = t.universalAdId),
            (r.categories = t.categories)),
          r
        );
      }),
      (t.playStatic = function () {
        this.vastAd.tracker.linear = "nonlinear";
        var e = this.vastAd.media[0];
        this.vastAd.selectedMedia = e;
        var t = this.vastAd.clickthrough || "",
          i = this.staticPlayer;
        i.removeEvents(),
          i.on("play", this.impressionHandler, this),
          i.on("play", this.playHandler, this),
          i.on("complete", this.combinedCompleteHandler, this),
          i.on("click", this.clickStaticHandler, this),
          i.on("error", this.staticErrorHandler, this),
          i.playAd(
            e.file,
            t,
            e.minDuration,
            this.scheduledAd._currentTag,
            this.scheduledAd.requestTimeout
          ),
          this.clearBlocking();
      }),
      (t.creativeAdError = function (e, t, i) {
        if (
          (this.adError(e, t, i),
          this.adPodItems &&
            this.adPodItems.length - 1 > this.scheduledAd._adPodIndex)
        ) {
          if (
            (this.vpaidPlayer &&
              (this.vpaidPlayer.destroy(), (this.vpaidPlayer = null)),
            "instream" === this.adType && this.instreamPlayer)
          )
            return void this.instreamPlayer.loadNextItemOnError();
          this.scheduledAd._adPodIndex++, this.playAd();
        }
      }),
      (t.playVpaid = function (e) {
        var t = this;
        clearTimeout(this.creativeTimeout),
          (this.creativeTimeout = setTimeout(function () {
            t.creativeAdError("VPAID tag communication timeout", 900, 50004);
          }, this.scheduledAd.creativeTimeout)),
          (this.vastAd = e);
        var i = At(e),
          r = this.optionalParams.conditionaladoptout && e.conditionalAd;
        if (
          ((this.vastAd.selectedMedia = i),
          (this.mediaType = i.type),
          "flash" === kt(i))
        )
          return (
            this.creativeAdError(
              "Flash creatives are not supported",
              403,
              10403
            ),
            Promise.reject()
          );
        var a = {
          adParams: this.vastAd.adParams,
          vpaidControls: this.optionalParams.vpaidcontrols,
          adOptOut: r,
        };
        return (
          (this.vpaidPlayer = new vt(
            this.player,
            this.blockingInstreamPlayer,
            i.file,
            this.scheduledAd._currentTag,
            a
          )),
          this.blockingInstreamPlayer &&
            this.blockingInstreamPlayer.applyProviderListeners(
              this.vpaidPlayer
            ),
          this.vpaidPlayer.on("play", this.playHandler, this),
          this.vpaidPlayer.on("pause", this.pauseHandler, this),
          this.vpaidPlayer.on("quartile", this.quartileHandler, this),
          this.vpaidPlayer.on(
            "remainingTimeChange",
            this.remainingTimeHandler,
            this
          ),
          this.vpaidPlayer.on("click", this.clickVpaidHandler, this),
          this.vpaidPlayer.on("error", this.playbackErrorHandler, this),
          this.vpaidPlayer.on("impression", this.impressionHandler, this),
          this.vpaidPlayer.on(
            "expandedChange",
            this.vpaidExpandedHandler,
            this
          ),
          this.vpaidPlayer.on("close", this.adCloseHandler, this),
          this.vpaidPlayer.on("skipped", this.vpaidAdSkipped, this),
          this.vpaidPlayer.on("stopped", this.endOfVpaidAdHandler, this),
          this.vpaidPlayer.on("complete", this.adCompleteHandler, this),
          this.vpaidPlayer.on("started", this.adStartedHandler, this),
          this.vpaidPlayer.on(
            "skippableStateChange",
            this.skippableStateChangeHandler,
            this
          ),
          Promise.resolve()
        );
      }),
      (t.skippableStateChangeHandler = function (e) {
        e.skippable &&
          this.blockingInstreamPlayer &&
          (this.blockingInstreamPlayer.off(w, this.skipVpaidAd, this),
          this.blockingInstreamPlayer.setupSkipButton(
            0,
            this.optionalParams,
            this.player.utils.noop
          ),
          this.blockingInstreamPlayer.on(w, this.skipVpaidAd, this));
      }),
      (t.playInstream = function (e, t) {
        var i = this,
          r = this.player.getEnvironment().OS;
        if (r.android && 2 === r.version.major && 3 === r.version.minor)
          return (
            this.adError("Android 2.3 not supported", 900, 60007),
            Promise.reject()
          );
        clearTimeout(this.creativeTimeout),
          this.blockingInstreamPlayer
            ? (this.instreamPlayer = this.blockingInstreamPlayer)
            : (this.instreamPlayer = this.player.createInstream().init()),
          this.instreamPlayer.on("play", this.playHandler, this),
          this.instreamPlayer.on("pause", this.pauseHandler, this),
          this.instreamPlayer.on("state", this.stateHandler, this),
          this.instreamPlayer.on("time", this.timeHandler, this),
          this.instreamPlayer.on(
            "playlistItem",
            this.playlistItemHandler,
            this
          ),
          this.instreamPlayer.on("complete", this.adCompleteHandler, this),
          this.instreamPlayer.on(
            "playlistComplete",
            this.endOfAdBreakHandler,
            this
          ),
          this.instreamPlayer.on("mute", this.muteHandler, this),
          this.instreamPlayer.on(
            "instreamClick",
            this.clickInstreamHandler,
            this
          ),
          this.instreamPlayer.on("adSkipped", this.adSkipped, this),
          this.instreamPlayer.on("error", this.playbackErrorHandler, this),
          this.instreamPlayer.on("mediaError", this.playbackErrorHandler, this),
          this.instreamPlayer.on(
            "destroyed",
            function () {
              i.instreamPlayer = null;
            },
            this
          );
        var a = this.instreamPlayer.loadItem(e, t);
        return this.clearBlocking(), a;
      }),
      (t.playerFullscreenHandler = function (e) {
        var t = this.getVastAd().tracker;
        t.trackOmidEvent(n, e.fullscreen),
          e.fullscreen && t.started && t.fullscreen();
      }),
      (t.playerResizeHandler = function (e) {
        this.getVastAd().tracker.trackOmidEvent("resize", e.width, e.height),
          this.vpaidPlayer && this.vpaidPlayer.resize(e.width, e.height);
      }),
      (t.playerVolumeHandler = function (e) {
        this.getVastAd().tracker.trackOmidEvent("volume", e.volume / 100),
          this.vpaidPlayer && this.vpaidPlayer.setVolume(e.volume);
      }),
      (t.playlistItemHandler = function (e) {
        var t = this;
        this.instreamPlayer &&
          (clearTimeout(this.creativeTimeout),
          (this.creativeTimeout = setTimeout(function () {
            t.creativeAdError("Video creative timeout", 402, 10402);
          }, this.scheduledAd.creativeTimeout)),
          (this.scheduledAd._adPodIndex = e.index + this.initialIndex),
          this.scheduledAd._adPodIndex > 0 && this.triggerEvent(f));
      }),
      (t.impressionHandler = function (e) {
        var t = this.getVastAd(),
          i = t.tracker,
          r = B({}, this.scheduledAd, t),
          a = e.duration || t.duration || this.getDurationFromVideoTag(),
          n = this.player.getVolume() / 100;
        i.impression(a, n),
          this.player.getViewable() ? i.viewable() : i.notViewable(),
          this.triggerEvent(
            p,
            Y(this.playlistItemManager, r, {
              duration: a,
              linear: e.linear || i.linear,
            })
          ),
          this.setupViewableListener();
      }),
      (t.viewableHandler = function (e) {
        e.viewable
          ? ((this.viewablePlayedTime = 0),
            (this.lastPosition = null),
            (this.adViewableImpressionHandler = this.adViewableHandler))
          : (this.adViewableImpressionHandler = this.player.utils.noop);
      }),
      (t.bufferStartHandler = function (e) {
        (e.buffering = !0), e.trackOmidEvent("bufferStart");
      }),
      (t.bufferFinishHandler = function (e) {
        (e.buffering = !1), e.trackOmidEvent("bufferFinish");
      }),
      (t.stateHandler = function (e) {
        var t = e.oldstate,
          i = e.newstate;
        if (i !== t || "playing" === i) {
          var r = "loading" === i || "stalled" === i,
            a = this.getVastAd().tracker;
          !r && a.buffering
            ? this.bufferFinishHandler(a)
            : r && a.started && this.bufferStartHandler(a);
        }
      }),
      (t.playHandler = function (e) {
        var t = this;
        clearTimeout(this.creativeTimeout), (this.creativeTimeout = null);
        var i,
          a = this.getVastAd(),
          n = a.tracker;
        if (n.started) e.oldstate === r && (n.resume(), this.dispatchPlay(e));
        else {
          this.vpaidPlayer && (n.linear = e.linear),
            this.instreamPlayer && this.impressionHandler({ linear: n.linear });
          var s = B({}, this.scheduledAd, a),
            o = Y(this.playlistItemManager, s, {
              linear: n.linear,
              metadata: !0,
            });
          if ((this.triggerEvent(g, o), a.companions)) {
            var l = Y(this.playlistItemManager, s, {
              companions:
                ((i = a.companions),
                i.map(function (e) {
                  var t,
                    i =
                      "iframe" === e.type || "html" === e.type
                        ? e.type
                        : "static";
                  return (
                    e.trackers &&
                      e.trackers.creativeView &&
                      e.trackers.creativeView.length &&
                      (t = e.trackers.creativeView),
                    {
                      width: e.width,
                      height: e.height,
                      type: i,
                      resource: e.source,
                      creativeview: t,
                      click: e.clickthrough,
                    }
                  );
                })),
            });
            this.triggerEvent("adCompanions", l);
          }
          a.icons &&
            (a.iconInstances = a.icons.map(function (e) {
              return new gt(t.player, e, t.div);
            }));
          var d,
            h = this.companion;
          (d =
            this.player.utils.flashVersion() > 9
              ? a.companions
              : (function (e) {
                  if (e)
                    return e.filter(function (e) {
                      return e.type.indexOf("flash") < 0;
                    });
                  return [];
                })(a.companions)),
            this.optionalParams.companion &&
              d &&
              d.length &&
              (n.hasComp = h.addCompanion(this.optionalParams.companion, d)),
            n.start(),
            n.creativeView(),
            this.dispatchPlay(e);
        }
      }),
      (t.pauseHandler = function (e) {
        clearTimeout(this.creativeTimeout),
          (this.creativeTimeout = null),
          this.getVastAd().tracker.pause(),
          null === this.reason && "vpaid" === this.adType && (this.reason = _),
          this.setState(e);
      }),
      (t.remainingTimeHandler = function (e) {
        var t = this;
        e.duration
          ? (this.duration = e.duration)
          : (this.duration = Math.max(1, this.duration, e.remainingTime));
        var i = e.remainingTime >= 0 ? this.duration - e.remainingTime : 0;
        this.position === i
          ? (this.creativeTimeout =
              this.creativeTimeout ||
              setTimeout(function () {
                t.creativeAdError("Video stall", 400);
              }, this.scheduledAd.creativeTimeout))
          : this.creativeTimeout &&
            (clearTimeout(this.creativeTimeout), (this.creativeTimeout = null)),
          this.timeHandler({
            position: i,
            duration: this.duration,
            isDurationChange: e.isDurationChange,
          });
      }),
      (t.quartileHandler = function (e) {
        if (e.duration) this.duration = e.duration;
        else {
          var t = (4 * e.remainingTime) / (4 - e.quartile);
          this.duration = Math.max(this.duration, 1, t);
        }
        this.timeHandler({
          position: this.duration * e.quartile * 0.25,
          duration: this.duration,
        });
      }),
      (t.adViewableHandler = function (e) {
        var t = e.position;
        null === this.lastPosition && (this.lastPosition = t);
        var i = t - this.lastPosition;
        (this.lastPosition = t),
          (i = Math.min(Math.max(0, i), 4)),
          (this.viewablePlayedTime += i),
          this.viewablePlayedTime >= 2 &&
            (this.player.off(l, this.viewableHandler, this),
            (this.adViewableImpressionHandler = this.player.utils.noop),
            this.triggerEvent("adViewableImpression", {}));
      }),
      (t.timeHandler = function (e) {
        var t = this.getVastAd(),
          i = e.position,
          r = e.duration;
        this.adViewableImpressionHandler(e);
        var a = r - i,
          n = t.tracker,
          s = this.optionalParams.dynamicMessage || "",
          o = this.optionalParams.podMessage || "";
        if (s && a > 0) {
          if (
            ((s = s.replace(/(\b)xx(s?\b)/gi, "$1" + Math.ceil(a) + "$2")),
            this.adPodItems && this.adPodItems.length > 1 && o)
          ) {
            var l = this.scheduledAd._adPodIndex + 1;
            s =
              (o = (o = o.replace(/__AD_POD_CURRENT__/g, "" + l)).replace(
                /__AD_POD_LENGTH__/g,
                "" + this.adPodItems.length
              )) +
              " " +
              s;
          }
          this.instreamPlayer
            ? this.instreamPlayer.setText(s)
            : this.vpaidPlayer &&
              this.vpaidPlayer.instream &&
              this.vpaidPlayer.instream.setText(s);
        }
        if (!e.isDurationChange) {
          n && n.time(i, r),
            t.iconInstances &&
              t.iconInstances.forEach(function (e) {
                e.updateTime(i);
              });
          var d = {};
          (d.position = this.position = i),
            (d.duration = r),
            this.triggerEvent("adTime", d);
        }
      }),
      (t.combinedCompleteHandler = function () {
        this.adCompleteHandler(), this.endOfAdBreakHandler();
      }),
      (t.adCompleteHandler = function () {
        clearTimeout(this.viewableTimeout);
        var e = this.getVastAd();
        wt(e);
        var t = e.tracker;
        t.firedError || (t.complete(), this.triggerEvent(u));
      }),
      (t.adCloseHandler = function () {
        clearTimeout(this.viewableTimeout);
        var e = this.getVastAd().tracker;
        e.firedError || e.close();
      }),
      (t.adStartedHandler = function () {
        this.triggerEvent(b);
      }),
      (t.endOfVpaidAdHandler = function () {
        if (
          (clearTimeout(this.viewableTimeout),
          this.adPodItems &&
            this.adPodItems.length - 1 > this.scheduledAd._adPodIndex)
        )
          return (
            this.vpaidPlayer &&
              (this.vpaidPlayer.destroy(), (this.vpaidPlayer = null)),
            this.scheduledAd._adPodIndex++,
            void this.playAd()
          );
        this.endOfAdBreakHandler();
      }),
      (t.endOfAdBreakHandler = function () {
        this.removePlayerListeners(), this.trigger(A);
      }),
      (t.muteHandler = function (e) {
        var t = this.getVastAd().tracker;
        t &&
          (e.mute ? t.mute() : t.unmute(),
          this.vpaidPlayer &&
            this.vpaidPlayer.setVolume(e.mute ? 0 : this.player.getVolume()));
      }),
      (t.clickStaticHandler = function () {
        var e = this.getVastAd();
        this.player.pause({ reason: E }), this.clickThrough(e);
      }),
      (t.clickVpaidHandler = function (e) {
        var t = this.getVastAd(),
          i = !0;
        e &&
          void 0 !== e.url &&
          (!1 === e.playerHandles && (i = !1), (t.clickthrough = e.url)),
          this.clickThrough(t, i);
      }),
      (t.clickInstreamHandler = function () {
        this.instreamPlayer.getState() !== r &&
          this.clickThrough(this.getVastAd());
      }),
      (t.playbackErrorHandler = function (e) {
        var t = e.message || "Error Playing Ad Tag",
          i = e.code;
        i && 232404 === i ? (i = 403) : (!i || i <= 4 || i > 901) && (i = 405),
          this.vpaidPlayer && "function" == typeof this.vpaidPlayer.off
            ? (this.vpaidPlayer.off(),
              this.creativeAdError(t, i, e.adErrorCode))
            : this.adError(t, i, e.adErrorCode);
      }),
      (t.staticErrorHandler = function () {
        this.adError("Unable to fetch NonLinear resource", 502);
      }),
      (t.vpaidExpandedHandler = function (e) {
        var t = this.getVastAd().tracker;
        e.expanded ? t.expand() : t.collapse();
      }),
      (t.getDurationFromVideoTag = function () {
        var e = this.blockingInstreamPlayer
          ? this.blockingInstreamPlayer.getMediaElement()
          : null;
        return e ? e.duration : 0;
      }),
      (t.setupViewableListener = function () {
        this.player.off(l, this.viewableHandler, this),
          this.player.on(l, this.viewableHandler, this),
          this.viewableHandler({ viewable: this.player.getViewable() });
      }),
      (t.dispatchPlay = function (e) {
        "static" === this.adType ||
          ("vpaid" === this.adType && "linear" !== e.linear) ||
          (null === this.reason && "vpaid" === this.adType && (this.reason = _),
          this.setState(e));
      }),
      (t.setState = function (e) {
        var t = e.newstate,
          i = e.oldstate,
          r = t === a,
          n = this.adEventObject(r ? k : y);
        ((n.newstate = t), null !== this.reason) &&
          ((n[r ? "playReason" : "pauseReason"] = this.reason),
          (this.reason = null));
        this.vpaidPlayer
          ? ((n.oldstate = i), this.vpaidPlayer.trigger("state", n))
          : this.instreamPlayer.setEventData(n);
      }),
      (t.clickThrough = function (e, t) {
        void 0 === t && (t = !0), e.tracker.click();
        var i = {};
        e.clickthrough && (i.clickThroughUrl = e.clickthrough),
          (this.reason = E),
          this.triggerEvent(h, i),
          (window.jwcast && window.jwcast.player.id) ||
            (e.clickthrough && t && window.open(e.clickthrough));
      }),
      (t.skipVpaidAd = function () {
        this.vpaidPlayer && this.vpaidPlayer.skip() && this.vpaidAdSkipped();
      }),
      (t.vpaidAdSkipped = function () {
        this.adSkipped(), this.endOfVpaidAdHandler();
      }),
      (t.adSkipped = function () {
        clearTimeout(this.viewableTimeout);
        var e = this.getVastAd();
        e.tracker.skip(), wt(e);
        var t = "vpaid" === this.adType ? void 0 : this.getSkipOffset(e);
        this.triggerEvent(w, {
          duration: e.duration,
          skipoffset: t,
          position: this.position,
          watchedPastSkipPoint: this.position - t,
        });
      }),
      (t.triggerEvent = function (e, t) {
        var i = this.adEventObject(e);
        t && B(i, t),
          this.trigger(e, i),
          -1 === x.indexOf(e) && this.player.trigger(e, i);
      }),
      e
    );
  })();
  function kt(e) {
    return (function (e) {
      return (
        "application/javascript" === e.type ||
        "application/x-javascript" === e.type
      );
    })(e)
      ? "html5"
      : "flash";
  }
  function At(e) {
    for (var t, i = 0; i < e.media.length; i++) {
      var r = e.media[i];
      if ("html5" === kt(r)) {
        t = r;
        break;
      }
    }
    return t;
  }
  function Pt(e, t, i, r, a) {
    e.tracker = new ft(e, e.trackers, t, i, r, a);
  }
  function wt(e) {
    e &&
      e.iconInstances &&
      (e.iconInstances.forEach(function (e) {
        e.remove();
      }),
      (e.iconInstances = null));
  }
  var bt = function () {},
    Et = (function (e) {
      var i, r;
      function a(i, r, a, n, s, o, l) {
        var d;
        return (
          ((d = e.call(this, i, r, a, n, l) || this).client = t),
          (d.config = n),
          (d.item = a),
          (d.params = s),
          (d.player = i),
          (d.adPlayerProperties = o),
          (d._vloaderQueue = []),
          (d._events = []),
          (d.adPlayerQueue = []),
          (d.qoe = new i.utils.Timer()),
          (d.reason = null),
          (d._debugTrackFn = n.debug && n.trackFn ? n.trackFn : null),
          B(
            (function (e) {
              if (void 0 === e)
                throw new ReferenceError(
                  "this hasn't been initialised - super() hasn't been called"
                );
              return e;
            })(d),
            i.Events
          ),
          d
        );
      }
      (r = e),
        ((i = a).prototype = Object.create(r.prototype)),
        (i.prototype.constructor = i),
        Z(i, r);
      var n = a.prototype;
      return (
        (n.init = function (t, i) {
          var r = this,
            a = e.prototype.init.call(this, t, i);
          return (
            this.vmapPromise &&
              this.vmapPromise
                .then(function (e) {
                  !r.isDestroyed() &&
                    e &&
                    e.length &&
                    e.forEach(function (e) {
                      var t = $(r, e, null, i);
                      r.dispatchAdError(t);
                    });
                })
                .catch(function (e) {
                  if (!r.isDestroyed()) {
                    var t = $(r, e, null, i);
                    r.enqueueAdEvent(c, t, i);
                  }
                }),
            a
          );
        }),
        (n.adPlayerImpressionHandler = function (e) {
          Tt(e) &&
            (this.qoe.tick("adImpression" + e.id),
            (e.timeLoading = this.qoe.between(
              "adBreakStart",
              "adImpression" + e.id
            ))),
            this.player.trigger(p, e);
        }),
        (n.playAdAPI = function (e) {
          var t = this;
          this.startBlocking(),
            Promise.resolve(e)
              .then(function () {
                if (!t.isDestroyed())
                  return (
                    t.triggerAdBreakEvents(e),
                    t.startAdBreak(e, {
                      adBlock: t.adBlockErrorDetected,
                      reason: T,
                    })
                  );
              })
              .catch(function (e) {
                return t.isDestroyed() ? null : t.dispatchFatalAdError(e);
              });
        }),
        (n.tryPlayAd = function (e, t) {
          var i = this;
          return (
            (this.reason = t.reason || this.reason),
            this.dequeueAdEvents(),
            e
              ? ("nonlinear" === e.scheduledAd()._type && this.stopBlocking(),
                this.playAd(e).catch(function (r) {
                  return i.isDestroyed() ? null : i.adWaterfall(e, r, t);
                }))
              : (this.stopBlocking(), null)
          );
        }),
        (n.playAd = function (e) {
          var t = this,
            i = e.scheduledAd();
          return (
            0 === i._waterfallIndex && this.clearNonlinearAd(),
            this.removeVastLoader(e),
            new Promise(function (i, r) {
              var a = new yt(e, t.player, t);
              a.on(A, i),
                a.on(c, r),
                a.on(p, t.adPlayerImpressionHandler.bind(t)),
                a.on(g, t.player.trigger),
                a.on(P, t.dispatchAdError.bind(t)),
                a.init(t.blockingInstreamPlayer, t.reason).catch(bt),
                (t.reason = null),
                (t.adInstreamPlayer = t.blockingInstreamPlayer),
                (t.blockingInstreamPlayer = null),
                t.adPlayerQueue.push(a);
            }).then(function () {
              t.isDestroyed() || "nonlinear" === i._type || t.stopBlocking();
            })
          );
        }),
        (n.pauseAd = function (e, t) {
          if (this.adPlayerQueue.length) {
            var i = this.adPlayerQueue[this.adPlayerQueue.length - 1];
            e ? i.pause(t || {}) : i.play(t || {});
          }
        }),
        (n.skipAd = function () {
          this.adPlayerQueue.length &&
            this.adPlayerQueue[this.adPlayerQueue.length - 1].skip();
        }),
        (n.dispatchFatalAdError = function (e) {
          (e && e.adErrorCode) ||
            (e = $(this, {
              message: "An unexpected ad error has occurred",
              sourceError: e,
            })),
            this.dequeueAdEvents(),
            this.dispatchAdError(e),
            this.destroyPlayers(),
            this.stopBlocking();
        }),
        (n.destroyPlayers = function () {
          this.adPlayerQueue.forEach(function (e) {
            return e.destroy();
          }),
            this.adPlayerQueue.splice(0);
        }),
        (n.dispatchAdError = function (e) {
          Tt(e) &&
            (this.qoe.tick("adError" + e.id),
            (e.timeLoading = this.qoe.between(
              "adBreakStart",
              "adError" + e.id
            ))),
            this.vmapTracker && this.vmapTracker.error(e.code),
            (50004 !== e.adErrorCode && 50901 !== e.adErrorCode) ||
              !this.player.getAdBlock() ||
              (this.adBlockErrorDetected = !0);
          var t = 70001 === e.adErrorCode ? "adWarning" : c;
          this.player.trigger(t, e);
        }),
        (n.clearNonlinearAd = function () {
          this.adPlayerQueue.length &&
            this.adPlayerQueue[this.adPlayerQueue.length - 1].clearNonlinear();
        }),
        (n.getVMAPTracker = function (e) {
          if (!e._vmapTracker) {
            var t = new ft(
              e,
              e._trackers,
              this._debugTrackFn,
              this.player,
              this.config
            );
            e._vmapTracker = this.vmapTracker = t;
          }
          return e._vmapTracker;
        }),
        (n._loadTag = function (e, t) {
          var i = e._adQueue[e._waterfallIndex];
          return this._loadTagUrl(e, i, t);
        }),
        (n._loadTagUrl = function (e, t, i) {
          var r = this;
          return Re(
            t,
            this.player,
            this.item,
            this.client,
            this.params,
            e
          ).then(function (a) {
            "function" == typeof r._debugTrackFn &&
              r._debugTrackFn({
                type: "tagReplacement",
                data: { actualTag: a, originalTag: t },
              });
            var n = r._createVastLoader(e, i),
              s = n.load(a);
            return (
              i.isPodItemLoader
                ? i.tagIndex &&
                  (n.scheduledAd().adRequestIds[i.tagIndex] =
                    r.player.utils.genId(12))
                : (e._currentTag = a),
              r._dispatchAdRequest(e, B({ tag: a }, i)),
              s
            );
          });
        }),
        (n._loadPods = function (e, t) {
          var i = this;
          e.adRequestIds = [];
          var r = this._createVastLoader(e, t),
            a = e._pod.map(function (r, a) {
              var n = B({ tag: r, isPodItemLoader: !0, tagIndex: a }, t),
                s = i._loadTagUrl(e, r, n).catch(function (e) {
                  return (e.tagIndex = a), Promise.reject(e);
                }),
                o = function () {
                  return i.isDestroyed() ? null : i._dispatchAdLoaded(e, n);
                };
              return s.then(o).catch(bt), s.catch(o).catch(bt), s;
            });
          return r.podMultipleVastLoaders(a);
        }),
        (n._loadXML = function (e, t) {
          var i = this;
          return (
            (e._currentTag = e._currentTag || e._adXML.toString()),
            this.bidsPromise.then(function () {
              return (
                i._dispatchAdRequest(e, t),
                i
                  ._createVastLoader(e, t)
                  .parseXMLString(e._adXML, e._currentTag)
              );
            })
          );
        }),
        (n._dispatchAdRequest = function (e, t) {
          var i = Y(this, e, B({ jwpseg: e.jwpseg }, t));
          this.player.trigger("adRequest", i),
            this.qoe.tick("adLoading" + i.id);
        }),
        (n._dispatchAdLoaded = function (e, t) {
          var i = Y(this, e, t),
            r = i.id;
          this.qoe.tick("adLoaded" + r),
            (i.timeLoading = this.qoe.between("adLoading" + r, "adLoaded" + r)),
            this.player.trigger("adLoaded", i);
        }),
        (n._handleVastLoadError = function (e, t, i) {
          var r = e.vloader;
          return this.removeVastLoader(r), this._getVloaderErrorObject(e, t, i);
        }),
        (n._vloaderWaterfall = function (e, t) {
          var i = this._handleVastLoadError(e, null, t),
            r = e.vloader;
          return this.adWaterfall(r, i, t);
        }),
        (n.adWaterfall = function (e, t, i) {
          var r = e.scheduledAd();
          if (this.schedule.canWaterfall(r))
            return (
              (r.jwpseg = null),
              (r._adXML = null),
              (r._waterfallIndex += 1),
              this.enqueueAdEvent(c, t, i),
              this.startAdBreak(r, i)
            );
          throw t;
        }),
        (n._createVastLoader = function (e, t) {
          var i = this;
          void 0 === t && (t = {});
          var r = this.config,
            a = new mt(
              e,
              this.player,
              B(
                {
                  requestFilter: r.requestFilter,
                  trackingFilter: r.trackingFilter,
                  item: this.item,
                  params: this.params,
                },
                t
              )
            );
          this._vloaderQueue.push(a);
          var n = 0;
          return (
            a.on(P, function (r) {
              n += 1;
              var s = i._getVloaderErrorObject(r, null, t);
              if (
                (i.enqueueAdEvent(c, s, t),
                !(a._scheduledAd._pod && a._scheduledAd._pod.length === n))
              ) {
                var o = Y(i, e, {
                  podIndex: a._scheduledAd._adPodIndex,
                  tagIndex: n,
                });
                i.enqueueAdEvent(f, o, t);
              }
            }),
            a.on(m, function (e) {
              i.player.trigger(m, B(Y(i, null), e));
            }),
            a
          );
        }),
        (n._getVloaderErrorObject = function (e, t, i) {
          e.wrapperAdSystem &&
            e.wrapperAdSystem.length !== e.wrappedTags.length &&
            (e.wrapperAdSystem.push(e.adsystem), (e.adsystem = ""));
          var r = B(
            {
              adsystem: e.adsystem,
              wrapper: e.wrapperAdSystem,
              wrappedTags: e.wrappedTags,
            },
            e.vloader.scheduledAd()
          );
          return $(
            this,
            e,
            r,
            B(
              { tag: e.tag, tagIndex: e.tagIndex || t, podIndex: e.podIndex },
              B({ jwpseg: r.jwpseg }, i)
            )
          );
        }),
        (n.dequeueAdEvents = function () {
          var e = this;
          this._events.forEach(function (t) {
            var i = t.type,
              r = t.event;
            i === c ? e.dispatchAdError(r) : e.player.trigger(i, r);
          }),
            this._events.splice(0);
        }),
        (n.triggerAdBreakEvents = function (e) {
          var t = this,
            i = this.getVMAPTracker(e);
          this.blockingInstreamPlayer.once("destroyed", function () {
            t.qoe.clear("adBreakStart"),
              i.breakEnd(),
              t.player.trigger("adBreakEnd", Y(t, e));
          }),
            this.qoe.tick("adBreakStart"),
            i.breakStart();
          var r = Y(this, e);
          this.player.trigger("adBreakStart", r), this.player.trigger(f, r);
        }),
        (n.startBlocking = function () {
          this.blockingInstreamPlayer ||
            ((this.blockingInstreamPlayer = this.player
              .createInstream()
              .init()),
            this.blockingInstreamPlayer.setText(null));
        }),
        (n.stopBlocking = function () {
          if (this.blockingInstreamPlayer || this.adInstreamPlayer) {
            var e = this.blockingInstreamPlayer || this.adInstreamPlayer;
            (this.blockingInstreamPlayer = null), e.destroy();
          }
          this.adInstreamPlayer = null;
        }),
        (n.loadAd = function (e, t) {
          var i = this;
          void 0 === t && (t = {});
          var r = this.player.utils;
          if (
            ((e._id = e._id || r.genId(12)),
            (e._vmapTracker = this.getVMAPTracker(e)),
            e._adQueue || e._adXML || e._pod)
          ) {
            if (t.adBlock)
              throw $(
                this,
                {
                  message: "Ad playback blocked by an ad blocker",
                  adErrorCode: 600003,
                },
                e,
                t
              );
            var a;
            if (e._pod) return this._loadPods(e, t);
            var n = function () {
              return i.isDestroyed() ? null : i._dispatchAdLoaded(e, t);
            };
            return (
              (a = e._adXML ? this._loadXML(e, t) : this._loadTag(e, t))
                .then(n)
                .catch(bt),
              a.catch(n).catch(bt),
              a.catch(function (e) {
                return i.isDestroyed() ? null : i._vloaderWaterfall(e, t);
              })
            );
          }
          r.log("scheduled ad has no url or xml", e);
        }),
        (n.playPreloadedPromise = function (e, t) {
          var i = this;
          void 0 === t && (t = {}),
            e
              .then(function (e) {
                return i.tryPlayAd(e, t);
              })
              .catch(function (e) {
                i.isDestroyed() || (i.dispatchAdError(e), i.stopBlocking());
              });
        }),
        (n.startAdBreak = function (e, t) {
          var i = this;
          return (
            void 0 === t && (t = {}),
            this.bidsPromise
              .then(function () {
                return i.loadAd(e, t);
              })
              .then(function (e) {
                return i.tryPlayAd(e, t);
              })
              .catch(function (e) {
                i.dispatchAdError(e), i.stopBlocking();
              })
          );
        }),
        (n.removeVastLoader = function (e) {
          var t = this._vloaderQueue.indexOf(e);
          -1 !== t && (e.destroy(), this._vloaderQueue.splice(t, 1));
        }),
        (n.isDestroyed = function () {
          return null === this.player;
        }),
        (n.destroy = function () {
          this._vloaderQueue.forEach(function (e) {
            return e.destroy();
          }),
            this.clearNonlinearAd(),
            this.stopBlocking(),
            e.prototype.destroy.call(this);
        }),
        a
      );
    })(lt);
  function Tt(e) {
    return e.tag && (void 0 === e.podcount || 1 === e.sequence);
  }
  var _t = function () {},
    It = (function () {
      function e(e, t, i) {
        (this.player = e), (this.pluginConfig = t), (this.adClient = i);
        var r = (this.configParser = new it(e.utils)),
          a = (this.adRules = new st(e, r.getAdRules(t), i));
        this.emptySchedule = new Ze(a, e.utils);
      }
      var t = e.prototype;
      return (
        (t.getAdRules = function () {
          return this.adRules;
        }),
        (t.resetDefaultSchedule = function (e) {
          var t =
              void 0 === this.pluginConfig.withCredentials ||
              this.pluginConfig.withCredentials,
            i = (this.defaultSchedule = this.configParser.getSchedule(
              this.pluginConfig,
              this.adRules
            ));
          i.isVMAP() &&
            i
              .load(this.player, e, this.adClient, { withCredentials: t })
              .catch(_t);
        }),
        (t.getSchedule = function (e, t) {
          return t > 0 && !this.adRules.rulesAllowAdPlayback(t)
            ? this.emptySchedule
            : e && e.adschedule
            ? this.configParser.getSchedule(e, this.adRules)
            : (this.resetDefaultSchedule(e), this.defaultSchedule);
        }),
        (t.getOptParams = function (e, t) {
          return this.configParser.getOptParams(e, t);
        }),
        (t.reset = function () {
          this.adRules.reset();
        }),
        (t.destroy = function () {
          this.emptySchedule && this.emptySchedule.destroy(),
            this.defaultSchedule && this.defaultSchedule.destroy();
        }),
        e
      );
    })(),
    Ct = {},
    St = {},
    Rt = {};
  function xt(e, t) {
    var i = Ct[t];
    return (
      i ||
      (Ct[t] = new Promise(function (i, r) {
        var a = new e.key(t);
        if ("unlimited" === a.edition()) return r();
        var n = ["//", "entitlements.jwplayer.com", "/", a.token(), ".json"];
        "file:" === window.location.protocol && n.unshift("https:"),
          e.ajax(
            n.join(""),
            function (e) {
              var t = e && e.response;
              t ? i(t) : r();
            },
            function () {
              r();
            },
            { timeout: 1e4, responseType: "json" }
          );
      }))
    );
  }
  function jt(e, t) {
    var i = St[t];
    return (
      i ||
      (St[t] = xt(e, t)
        .catch(function () {
          return {};
        })
        .then(function (e) {
          if (!1 === e.canUseVPB)
            throw new Error("Not entitled for Player Bidding");
        }))
    );
  }
  var Mt = function (e, t, i) {
      var r = Rt[t];
      return (
        r ||
        (Rt[t] = xt(e, t)
          .catch(function () {
            return {};
          })
          .then(function (e) {
            var t, r;
            if (
              (!0 === i.outstream
                ? ((t = !1 !== e.canPlayOutstreamAds),
                  (r = "Outstream Ad Limit Reached"))
                : ((t = !1 !== e.canPlayAds), (r = "Ad Limit Reached")),
              !1 === t)
            )
              throw new Error(r);
            return { message: "Can Play Ads" };
          }))
      );
    },
    Ot = function () {};
  var Vt = function () {};
  !(function (e) {
    if (e && "undefined" != typeof window) {
      var t = document.createElement("style");
      t.setAttribute("media", "screen"),
        (t.innerHTML = e),
        document.head.appendChild(t);
    }
  })(
    ".jwplayer.jw-flag-time-slider-above .jw-vpaid-non-linear{bottom:66px}.jwplayer.jw-breakpoint-7 .jw-vpaid-non-linear{bottom:132px}.jwplayer.jw-flag-user-inactive:not(.jw-state-paused) .jw-vpaid-non-linear{bottom:.5em}.jwplayer .jw-vpaid-non-linear{bottom:60px}.jwplayer .jw-vpaid-iframe{border:0;width:100%;height:100%;position:absolute;overflow:hidden}.jwplayer .jw-plugin-vast.jw-plugin{top:0;width:100%;pointer-events:none}.jwplayer .jw-plugin-vast.jw-plugin *{pointer-events:all}.jwplayer .jw-plugin-vast .jw-ad-icon-container{position:absolute;display:none;pointer-events:all;cursor:pointer}.jwplayer .jw-plugin-vast .jw-ad-icon-container.jw-ad-icon-active{display:block}.jwplayer .jw-plugin-vast .jw-ad-icon-container iframe{pointer-events:none;border:none;height:100%;width:100%;margin:0}.jw-plugin-vast.jw-vast-nonlinear-active .jw-banner{opacity:1}.jw-plugin-vast.jw-vast-nonlinear-active .jw-vast-nonlinear-close-button{margin:0 auto;opacity:.75}.jw-plugin-vast.jw-vast-nonlinear-active:hover .jw-vast-nonlinear-close-button{opacity:1}.jw-plugin-vast.jw-vast-nonlinear-collapsed .jw-vast-nonlinear-open-button{margin:0 auto;opacity:.5}.jw-plugin-vast.jw-vast-nonlinear-collapsed .jw-banner,.jw-plugin-vast.jw-vast-nonlinear-collapsed .jw-vast-nonlinear-close-button{opacity:0}.jw-plugin-vast.jw-vast-nonlinear-collapsed:hover .jw-vast-nonlinear-open-button{opacity:1}.jw-plugin-vast.jw-vast-nonlinear-collapsed:hover .jw-vast-nonlinear-close-button{opacity:0}.jw-plugin-vast .jw-vast-nonlinear-close-button,.jw-plugin-vast .jw-vast-nonlinear-open-button{position:absolute;right:0;bottom:0;left:0;display:block;margin:auto;width:18px;height:18px;cursor:pointer;opacity:0;transition:opacity .2s ease}.jw-plugin-vast .jw-vast-nonlinear-close-button{transform:rotate(45deg)}"
  ),
    (window.jwplayerPluginJsonp || window.jwplayer().registerPlugin)(
      t,
      "8.1",
      function (e, i, r) {
        var n,
          s,
          o,
          l,
          d = new It(e, i, t),
          h = e.getConfig(),
          u = e.getEnvironment(),
          c = i.debug && i.trackFn ? i.trackFn : null,
          p = e.utils,
          f = this,
          m = {
            withCredentials: void 0 === i.withCredentials || i.withCredentials,
          },
          v = !1,
          g = 0,
          y = !1;
        function k(t, r, a) {
          var n = d.getSchedule(t, r),
            s = new Et(e, n, t, i, a, o, y);
          return (
            s
              .init(l, a)
              .then(function () {
                s.isDestroyed() ||
                  e.trigger("adSchedule", Y(s, null, { schedule: n }));
              })
              .catch(Vt),
            s.on(
              "preloadNext",
              function (e) {
                var t = B({}, a, {
                  preloadPreroll: !0,
                  playlistItemEventCount: g + 1,
                });
                s.next = k(e.item, t.playlistItemEventCount, t);
              },
              f
            ),
            s
          );
        }
        function A(t) {
          n &&
            (t && ((s = n.next), (v = n.nextPlaylistRelated)),
            n.schedule.reset(),
            n.off(null, null, f),
            n.destroy(),
            (n = null)),
            d.reset(),
            e.setCues([]);
        }
        function P(t) {
          var i = t.getMidRolls(),
            r = [];
          i.length &&
            i.forEach(function (e) {
              "nonlinear" !== e._type &&
                r.push({ begin: e._offSet, text: m.cuetext, cueType: "ads" });
            }),
            e.addCues(r);
        }
        (function (e) {
          try {
            var t = e.settings.mediationLayerAdServer || "jwp",
              i = !!e.bidders.length;
            return ("jwp" === t || "jwpspotx" === t) && i;
          } catch (e) {
            return !1;
          }
        })(i.bids) && (l = B({}, i.bids)),
          (function (e, t, i, r) {
            var a,
              n = t.key,
              s = e.utils,
              o = Mt(s, n, i);
            o.catch(Ot),
              i.bids && (a = jt(s, n)).catch(Ot),
              e.on("ready", function () {
                a &&
                  a.catch(function (i) {
                    e.trigger("destroyBidding"),
                      e.trigger(de, Ce(i.message, 60009, t, r));
                  }),
                  o.catch(function (i) {
                    e.trigger("destroyPlugin", i),
                      e.trigger(de, Ce(i.message, 60002, t, r));
                  });
              });
          })(e, h, i, t),
          "enabled" === i.omidSupport && ct(p).catch(p.noop),
          (this.version = "8.11.0"),
          B(this, e.Events),
          p.addClass(r, "jw-plugin-vast"),
          e.on(
            {
              ready: function () {
                (h.localization = e.getConfig().localization),
                  ((m = d.getOptParams(
                    i,
                    h.localization.advertising
                  )).debugTrackFn = c),
                  (o = {
                    staticPlayer: new F(e, r),
                    companion: new L(c, u, { openLink: p.openLink }),
                    div: r,
                    optionalParams: m,
                  });
              },
              cast: function (e) {
                y = !!e.active;
              },
              play: function (e) {
                f.trigger(a, e);
              },
              playlistItem: function (t) {
                (g += 1), A(!0);
                var i = e.getPlaylistItem(t.index);
                s &&
                  i !== s.item &&
                  !v &&
                  (s.off(null, null, f), s.destroy(), (s = null), (v = !1));
                (m.playlistItemEventCount = g),
                  (n = s || k(i, g, m)).attachListeners(),
                  (s = null),
                  (v = !1),
                  n.schedule.isVMAP()
                    ? n.vmapPromise
                        .then(function () {
                          n.isDestroyed() || P(n.schedule);
                        })
                        .catch(Vt)
                    : P(n.schedule);
              },
              playlistComplete: A,
              complete: function () {
                n && n.clearNonlinearAd();
              },
              destroyPlugin: A,
              destroyBidding: function () {
                l = null;
              },
            },
            this
          ),
          (e.pauseAd = function (e, t) {
            (e = "boolean" != typeof e || e), n && n.pauseAd(e, t);
          }),
          (e.playAd = function (t) {
            var i,
              r = 0 === m.requestTimeout ? 1 / 0 : m.requestTimeout,
              a = 0 === m.creativeTimeout ? 1 / 0 : m.creativeTimeout;
            i = Array.isArray(t) ? t.slice(0) : [t];
            var s = p.genId,
              o = {
                _id: s(12),
                _adQueue: i,
                _waterfallIndex: 0,
                _adPodIndex: 0,
                adBreakId: s(12),
                _offset: 0,
                _position: K(e),
                requestTimeout: r || 5e3,
                creativeTimeout: a || 15e3,
              };
            n
              ? (n.clearNonlinearAd(), n.playAdAPI(o))
              : e.once("playlistItem", function () {
                  return n.playAdAPI(o);
                });
          }),
          (e.skipAd = function () {
            n && n.skipAd();
          }),
          (this.destroy = A);
      }
    );
})();
