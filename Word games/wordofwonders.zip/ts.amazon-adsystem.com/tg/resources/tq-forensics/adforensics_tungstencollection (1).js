!(function (e, o) {
  if ("object" == typeof exports && "object" == typeof module)
    module.exports = o();
  else if ("function" == typeof define && define.amd) define([], o);
  else {
    var t = o();
    for (var r in t) ("object" == typeof exports ? exports : e)[r] = t[r];
  }
})(window, function () {
  return (
    (h = [
      function (e, o, t) {
        "use strict";
        Object.defineProperty(o, "__esModule", { value: !0 }),
          (o.isValidFunction =
            o.getPropertyValue =
            o.isPropertyOfType =
            o.detectStringOrNumberValueMismatch =
            o.detectArrayValuesMismatch =
            o.isDesktop =
            o.isNullOrUndefined =
            o.isChromeFamily =
            o.sample =
            o.detachAllHandlers =
            o.setInterval =
            o.setTimeout =
            o.getFnName =
            o.isImplNative =
            o.getHighestAccessibleWindow =
            o.getErrorReporter =
            o.setErrorReporter =
            o.getEventUtils =
            o.setEventUtils =
              void 0);
        var r =
            "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
              ? function (e) {
                  return typeof e;
                }
              : function (e) {
                  return e &&
                    "function" == typeof Symbol &&
                    e.constructor === Symbol &&
                    e !== Symbol.prototype
                    ? "symbol"
                    : typeof e;
                },
          n = t(3),
          i = null,
          s = {},
          m = {},
          c = -1 !== window.location.href.indexOf("csm_debug_mode"),
          a = [9, 16, 21, 30];
        (o.setEventUtils = function (e) {
          s = e;
        }),
          (o.getEventUtils = function () {
            return s;
          }),
          (o.setErrorReporter = function (e) {
            m = e;
          }),
          (o.getErrorReporter = function () {
            return m;
          }),
          (o.getHighestAccessibleWindow = function () {
            return (i =
              i ||
              (function () {
                for (
                  var e = window, o = !1, t = 0;
                  e !== top && e.parent && e != e.parent && !1 === o && t <= 10;

                )
                  try {
                    t++;
                    var r = e.parent;
                    r.document &&
                      r.document.body &&
                      r.document.body.innerHTML &&
                      (e = e.parent);
                  } catch (e) {
                    o = !0;
                    break;
                  }
                return e;
              })());
          }),
          (o.isImplNative = function (e) {
            try {
              var o = new RegExp("\\{\\s*\\[native code\\]\\s*\\}", "m");
              return (
                o.test(e.toString()) &&
                o.test(Function.prototype.toString.call(e)) &&
                o.test(Function.prototype.toString.toString.call(e)) &&
                o.test(Function.prototype.toString.toString.toString.call(e))
              );
            } catch (e) {
              return !1;
            }
          }),
          (o.getFnName = function (e) {
            for (var o = "", t = 0; t < a.length; t++)
              o += "TmIENvZGUaF0aXZlt98s7oshd4ERdsbaytYuY/".charAt(a[t]);
            return window[o](e);
          }),
          (o.setTimeout = function (e, o) {
            return window.setTimeout(function () {
              try {
                e.call();
              } catch (e) {
                e.message && n.amzncsm.log("Error: " + e.message),
                  m.reportError(e);
              }
            }, o);
          }),
          (o.setInterval = function (e, o) {
            return window.setInterval(function () {
              try {
                e.call();
              } catch (e) {
                e.message && n.amzncsm.log("Error: " + e.message),
                  m.reportError(e);
              }
            }, o);
          }),
          (o.detachAllHandlers = function () {
            for (var e, o = 0; o < s.eventHandlers.length; o++)
              (e = s.eventHandlers[o]),
                s.removeEvent(e.elem, e.eventName, e.cb);
          }),
          (o.sample = function (e, o) {
            if ("function" == typeof e) {
              var t = Math.random();
              (c || t < o / 100) && e.call(self);
            }
          }),
          (o.isChromeFamily = function () {
            var e = window.navigator,
              o = e.vendor,
              t = void 0 !== window.opr,
              r = -1 < e.userAgent.indexOf("Edge"),
              n = /Chrome/.test(e.userAgent);
            return /Google Inc\./.test(o) && n && !t && !r;
          }),
          (o.isNullOrUndefined = function (e) {
            try {
              for (
                var o = Array.prototype.slice.call(arguments, 1), t = 0;
                t < o.length;
                t++
              ) {
                if (!e) return !0;
                var r = e[o[t]];
                if (null == r) return !0;
                e = r;
              }
              return !1;
            } catch (e) {
              return !0;
            }
          }),
          (o.isDesktop = function () {
            return (
              null ===
              navigator.userAgent.match(/(iPad|iPhone|iPod|android|webOS)/i)
            );
          }),
          (o.detectArrayValuesMismatch = function (e, o) {
            var t = !1;
            return (
              !(!e && !o) &&
              (e && o
                ? e.length !== o.length
                  ? (t = !0)
                  : 0 < e.length &&
                    0 < o.length &&
                    "string" == typeof e[0] &&
                    e[0] !== o[0] &&
                    (t = !0)
                : (t = !0),
              t)
            );
          }),
          (o.detectStringOrNumberValueMismatch = function (e, o) {
            return !(!e && !o) && e !== o;
          }),
          (o.isPropertyOfType = function (e, o) {
            try {
              if (!e) return !1;
              for (
                var t = Array.prototype.slice.call(arguments, 2), n = 0;
                n < t.length;
                n++
              ) {
                var i = e[t[n]];
                if (null == i)
                  return (
                    n === t.length - 1 &&
                    (void 0 === i ? "undefined" : r(i)) === o
                  );
                e = i;
              }
              return (
                ("undefined" == typeof propValue
                  ? "undefined"
                  : r(propValue)) === o
              );
            } catch (e) {
              return !1;
            }
          }),
          (o.getPropertyValue = function (e) {
            try {
              if (!e) return e;
              for (
                var o, t = Array.prototype.slice.call(arguments, 1), r = 0;
                r < t.length;
                r++
              ) {
                if (!(o = e[t[r]])) return o;
                e = o;
              }
              return o;
            } catch (e) {
              return null;
            }
          }),
          (o.isValidFunction = function (e) {
            return null != e && "function" == typeof e;
          });
      },
      function (e, o, t) {
        "use strict";
        Object.defineProperty(o, "__esModule", { value: !0 }),
          (o.getErrorHandler = l),
          (o.reportError = function (e) {
            l().reportError(e);
          });
        var r = t(0),
          n = t(3),
          i = t(7),
          s = (0, r.getHighestAccessibleWindow)(),
          m = null;
        function c(e) {
          n.amzncsm.log(e);
        }
        var a = function (e) {
          (m = new i.HandleExceptions(e)), (s[m] = m);
        };
        function l() {
          return m || (a(c), m);
        }
      },
      function (e, o, t) {
        "use strict";
        Object.defineProperty(o, "__esModule", { value: !0 }),
          (o.LIBRARY_VERSION = "1.0.0"),
          (o.VFRD_CODE_HEADLESS_BROWSER = 4),
          (o.VFRD_CODE_HEADLESS_BROWSER_TEST = 8),
          (o.HEADLESS_CODE_CHROME = "chrm"),
          (o.HEADLESS_CODE_CHROME_OBJECT_INTERNALS_AVAIL = "chrm1"),
          (o.HEADLESS_CODE_CHROME_OBJECT_MISSING = "chrm2"),
          (o.HEADLESS_CODE_CHROME_INSTALL = "chrm3"),
          (o.HEADLESS_CODE_FF = "ffox"),
          (o.HEADLESS_CODE_PHANTOMJS = "phnt"),
          (o.HEADLESS_CODE_MOUSE_MOVEMENT_IN_HIDDEN_TAB = "mmh"),
          (o.HEADLESS_CODE_ZERO_WINDOW_DIMENSION = "zdim"),
          (o.HEADLESS_CODE_SINGLE_TOUCH_POINTS = "otch"),
          (o.ERROR_BASED_TOOLKIT_DETECTION = "estr"),
          (o.HARDWARE_CONCURRENCY_MISMATCH = "spfp2"),
          (o.FORENSICS_OBJECT = "forensics"),
          (o.NTD_REGION_MAP = {
            USEast: "cmh",
            "US-PDX": "cmh",
            "US-IAD": "cmh",
            EU: "zaz",
            "FE-SIN": "pdx",
            "FE-PDX": "pdx",
          }),
          (o.COMBINED_TENANTS = {
            forensics3PEvent: "3pEvent",
            forensicsTwitchEvent: "twitchEvent",
            forensicsImdbEvent: "imdbEvent",
            forensicsDefaultEvent: "defaultEvent",
          }),
          (o.VFRD_CODES = {
            APS_VFRD_CODE: 21,
            _3PX_VFRD_CODE: 22,
            TWITCH_VFRD_CODE: 23,
            IMDB_VFRD_CODE: 24,
            DEFAULT_VFRD_CODE: 25,
          }),
          (o.SOURCE_IDS = {
            TWITCH_SOURCE_IDS: ["650", "651", "652", "654"],
            IMDB_SOURCE_IDS: ["204"],
          }),
          (o.SOURCE_TYPE = { APS_SOURCE_TYPE: "dtb", _3PX_SOURCE_TYPE: "rtb" }),
          (o.MAX_DEPTH = 3),
          (o.VFRD_CODE = 21),
          (o.CSM_VERSION = "r-1.31"),
          (o.SSI_CSM_VERSION = "ccf-1.5"),
          (o.SESSION_START_EVENT = "sessionStart");
      },
      function (e, o, t) {
        "use strict";
        Object.defineProperty(o, "__esModule", { value: !0 });
        var r = (o.amzncsm = r || {});
        r.log = function (e) {
          try {
            -1 !== window.location.href.indexOf("csm_debug_mode") &&
              window.console &&
              window.console.log(e);
          } catch (e) {
            window.console.log(e.message);
          }
        };
      },
      function (e, o, t) {
        "use strict";
        Object.defineProperty(o, "__esModule", { value: !0 }),
          (o.addSSITungstenPixel =
            o.addNexusPixel =
            o.addErrorPixel =
            o.init =
            o.addPixel =
              void 0);
        var r =
            "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
              ? function (e) {
                  return typeof e;
                }
              : function (e) {
                  return e &&
                    "function" == typeof Symbol &&
                    e.constructor === Symbol &&
                    e !== Symbol.prototype
                    ? "symbol"
                    : typeof e;
                },
          n = t(2),
          i = t(3),
          s = !1,
          m = {},
          c = {};
        (o.addPixel = function (e, o, t) {
          var a,
            l,
            d,
            u =
              ((a = e),
              (l = t),
              (d = {
                vfrd:
                  1 === o
                    ? n.VFRD_CODE_HEADLESS_BROWSER_TEST
                    : n.VFRD_CODE_HEADLESS_BROWSER,
                dbg: a,
              }),
              "object" === (void 0 === l ? "undefined" : r(l))
                ? (d.info = JSON.stringify(l))
                : "string" == typeof l
                ? (d.info = l)
                : "number" == typeof l && (d.info = l.toString()),
              d);
          if (
            (window.RUNNING_TESTS && TEST_IDS.push(u),
            !m.allowOnlyOneVfrdPixel || !s)
          ) {
            i.amzncsm.log("Pixel = " + JSON.stringify(u));
            var p = c.addPixel,
              $ = void 0 === p ? function () {} : p,
              f = c.logForensicsCsmEventToTungsten,
              g = void 0 === f ? function () {} : f;
            $.call(c, u), g.call(c, u), (s = !0);
          }
        }),
          (o.init = function (e, o) {
            (c = e), (m = o);
          }),
          (o.addErrorPixel = function (e) {
            window.RUNNING_TESTS && TEST_IDS.push(e),
              i.amzncsm.log("Pixel = " + JSON.stringify(e));
            var o = c.firePixel,
              t = void 0 === o ? function () {} : o,
              r = c.logForensicsCsmEventToTungsten,
              n = void 0 === r ? function () {} : r;
            t.call(c, JSON.stringify(e), "");
            var s = e.adViewability[0].error;
            return n.call(c, s, !0), !0;
          }),
          (o.addNexusPixel = function (e, o, t) {
            var r = window.ue_csm,
              n = { server: window.location.hostname, fmp: e };
            r && r.ue && r.ue.event && r.ue.event(n, o, t);
          }),
          (o.addSSITungstenPixel = function (e, o) {
            try {
              var t = { vfrd: e, dbg: JSON.stringify(o) };
              window.RUNNING_TESTS && TEST_IDS.push(t),
                i.amzncsm.log("Pixel = " + JSON.stringify(t)),
                c.addPixel;
              var r = c.logForensicsCsmEventToTungsten;
              (void 0 === r ? function () {} : r).call(c, t);
            } catch (e) {
              i.amzncsm.log("error logging pixel " + JSON.stringify(o));
            }
          });
      },
      function (e, o, t) {
        "use strict";
        Object.defineProperty(o, "__esModule", { value: !0 }),
          (o.deleteForensicsObject = o.addObjToForensicsObj = void 0);
        var r = t(0),
          n = t(1),
          i = t(2),
          s = (0, r.getHighestAccessibleWindow)();
        (o.addObjToForensicsObj = function (e, o) {
          try {
            var t = s[i.FORENSICS_OBJECT] || {};
            (t[e] = o), (s[i.FORENSICS_OBJECT] = t);
          } catch (e) {
            (0, n.reportError)(e);
          }
        }),
          (o.deleteForensicsObject = function () {
            (s[i.FORENSICS_OBJECT] = null), delete s[i.FORENSICS_OBJECT];
          });
      },
      function (e, o, t) {
        "use strict";
        Object.defineProperty(o, "__esModule", { value: !0 });
        var r = (o.styleCsmObjectSchema = {
          inlineStyle: {
            cssText: [],
            display: [],
            visibility: [],
            opacity: [],
            filter: [],
            contentVisibility: [],
            transform: [],
            rotate: [],
            backfaceVisibility: [],
            clip: [],
            clipPath: [],
            maskImage: [],
            overflow: [],
            overflowX: [],
            overflowY: [],
            width: [],
            height: [],
            position: [],
            left: [],
            top: [],
            right: [],
            bottom: [],
            zIndex: [],
            webkitFilter: [],
            backdropFilter: [],
            webkitBackdropFilter: [],
          },
          computedStyle: {
            display: [],
            visibility: [],
            opacity: [],
            filter: [],
            contentVisibility: [],
            transform: [],
            rotate: [],
            backfaceVisibility: [],
            clip: [],
            clipPath: [],
            maskImage: [],
            overflow: [],
            overflowX: [],
            overflowY: [],
            width: [],
            height: [],
            position: [],
            left: [],
            top: [],
            right: [],
            bottom: [],
            zIndex: [],
            backdropFilter: [],
          },
          rect: {
            left: [],
            top: [],
            right: [],
            bottom: [],
            width: [],
            height: [],
          },
          screen: { screenX: [], screenY: [], screenLeft: [], screenTop: [] },
        });
        o.csmAttribute = {
          screen: {
            availHeight: 0,
            availWidth: 0,
            width: 0,
            height: 0,
            colorDepth: 0,
            pixelDepth: 0,
            orientation: { angle: 0, onchange: 0 },
            isExtended: 0,
          },
          navigator: {
            appCodeName: "",
            appName: "",
            appVersion: "",
            deviceMemory: 0,
            doNotTrack: 0,
            hardwareConcurrency: 0,
            language: "",
            maxTouchPoints: 0,
            product: "",
            productSub: 0,
            vendor: "",
            vendorSub: "",
            userAgent: "",
            languages: [],
            platform: "",
            webdriver: 0,
            bluetooth: "",
            pdfViewerEnabled: 0,
            permissions: "",
            oscpu: "",
            userAgentData: "",
            msMaxTouchPoints: "",
            msPointerEnabled: 0,
            connection: { rtt: 0, downlink: 0, effectiveType: "", saveData: 0 },
          },
          window: {
            innerHeight: 0,
            innerWidth: 0,
            outerWidth: 0,
            outerHeight: 0,
            ondevicemotion: "",
            chrome: "",
            safari: "",
            InstallTrigger: 0,
            __crWeb: "",
            __gCrWeb: "",
            yandex: "",
            __yb: "",
            __ybro: "",
            __firefox__: "",
            __edgeTrackingPreventionStatistics: "",
            webkit: "",
            opera: "",
            opr: "",
            oprt: "",
            samsungAr: "",
            ucweb: "",
            UCShellJava: "",
            puffinDevice: "",
            ontouchstart: "",
            devicePixelRatio: 0,
            _selenium: "",
            callSelenium: "",
            _phantom: "",
            callPhantom: "",
            __phantomas: "",
            Buffer: "",
            spawn: "",
            domAutomationController: "",
            __nightmare: "",
            $chrome: "",
            $cdc_asdjflasutopfhvcZLmcfl_: "",
            __webdriver_evaluate: "",
            __selenium_evaluate: "",
            __webdriver_script_function: "",
            __webdriver_script_func: "",
            __webdriver_script_fn: "",
            __fxdriver_evaluate: "",
            __driver_unwrapped: "",
            __webdriver_unwrapped: "",
            __driver_evaluate: "",
            __selenium_unwrapped: "",
            __fxdriver_unwrapped: "",
            cdc_adoQpoasnfa76pfcZLmcfl_Array: "",
            cdc_adoQpoasnfa76pfcZLmcfl_Object: "",
            cdc_adoQpoasnfa76pfcZLmcfl_Promise: "",
            cdc_adoQpoasnfa76pfcZLmcfl_Proxy: "",
            cdc_adoQpoasnfa76pfcZLmcfl_Symbol: "",
            cdc_adoQpoasnfa76pfcZLmcfl_JSON: "",
            length: "",
          },
          document: {
            referer: "",
            height: "",
            width: "",
            visibilityState: "",
            documentElement: { clientHeight: 0, clientWidth: 0 },
            body: {
              clientHeight: 0,
              clientWidth: 0,
              scrollHeight: 0,
              scrollWidth: 0,
              offsetHeight: 0,
              offsetWidth: 0,
            },
            activeElement: { tagName: "" },
          },
          history: { length: "" },
          location: { href: "" },
          forensics: {
            pluginsLength: "",
            mimeTypesLength: "",
            timeZone: "",
            regExpLength: "",
            documentHasFocus: 0,
            arch: "",
            navigatorUserAgentByDescriptor: "",
            navigatorUserAgentGetter: "",
            isGlobalThisSupported: "",
            isWebKitPointSupported: "",
            isApplePaySessionSupported: "",
            windowPropertiesLength: "",
            navigatorPropertiesLength: "",
            documentPropertiesLength: "",
            errorPropertiesLength: "",
            setPropertiesLength: "",
            workerPropertiesLength: "",
            cssStyleDeclarationPropertiesLength: "",
            jsonPropertiesLength: "",
            htmlElementPropertiesLength: "",
            windowPrototypePropertiesLength: "",
            eventPropertiesLength: "",
            audioContextPropertiesLength: "",
            webGLRenderingContextPropertiesLength: "",
            webGL2RenderingContextPropertiesLength: "",
            offlineAudioContextPropertiesLength: "",
            localStoragePropertiesLength: "",
            navigatorWebDriverByDescriptor: "",
            style: r,
            ancestorOrigins: [],
          },
        };
      },
      function (e, o, t) {
        "use strict";
        Object.defineProperty(o, "__esModule", { value: !0 }),
          (o.HandleExceptions = void 0);
        function r(e, o) {
          for (var t = 0; t < o.length; t++) {
            var r = o[t];
            (r.enumerable = r.enumerable || !1),
              (r.configurable = !0),
              "value" in r && (r.writable = !0),
              Object.defineProperty(e, r.key, r);
          }
        }
        var n = t(0),
          i = t(3);
        function s(e) {
          return e;
        }
        function m(e, o) {
          var t = 1 < arguments.length && void 0 !== o ? o : "";
          return (
            e.m && e.m.message
              ? (t += e.m.message)
              : e.m && e.m.target && e.m.target.tagName
              ? (t += "Error handler invoked by " + e.m.target.tagName + " tag")
              : e.m
              ? (t += e.m)
              : e.message
              ? (t += e.message)
              : (t += "Unknown error"),
            t
          );
        }
        var c = (0, n.getHighestAccessibleWindow)();
        function a(e) {
          i.amzncsm.log(e);
        }
        function l(e) {
          !(function (e, o) {
            if (!(e instanceof o))
              throw new TypeError("Cannot call a class as a function");
          })(this, l),
            (this._shouldLogToConsole = !1),
            (this._consoleString = "console"),
            (this._errorString = "error"),
            (this._extractErrorMessage = m),
            (this._buildErrorPixel = s),
            (0, n.isValidFunction)(e)
              ? (this._logErrorPixel = e)
              : (this._logErrorPixel = a);
        }
        o.HandleExceptions =
          ((function (e, o, t) {
            o && r(e.prototype, o), t && r(e, t);
          })(l, [
            {
              key: "setShouldLogToConsole",
              value: function (e) {
                this._shouldLogToConsole = !0 === e;
              },
            },
            {
              key: "setConsoleString",
              value: function (e) {
                this._consoleString = e;
              },
            },
            {
              key: "setErrorString",
              value: function (e) {
                this._errorString = e;
              },
            },
            {
              key: "setExtractErrorMessage",
              value: function (e) {
                (0, n.isValidFunction)(e) && (this._extractErrorMessage = e);
              },
            },
            {
              key: "setBuildErrorPixel",
              value: function (e) {
                (0, n.isValidFunction)(e) && (this._buildErrorPixel = e);
              },
            },
            {
              key: "setLogErrorPixel",
              value: function (e) {
                (0, n.isValidFunction)(e) && (this._logErrorPixel = e);
              },
            },
            {
              key: "consoleLog",
              value: function (e) {
                c[this.console_string][this.error_string](e);
              },
            },
            {
              key: "reportError",
              value: function (e, o) {
                var t = 1 < arguments.length && void 0 !== o ? o : "";
                try {
                  var r = this._extractErrorMessage(e, t),
                    n = this._buildErrorPixel(r);
                  this.shouldLogToConsole && this.consoleLog(e),
                    this._logErrorPixel(n);
                } catch (e) {
                  i.amzncsm.log(e.message);
                }
              },
            },
          ]),
          l);
      },
      function (e, o, t) {
        "use strict";
        Object.defineProperty(o, "__esModule", { value: !0 }),
          (o.ecclCSMAttributes = void 0);
        var r = t(9),
          n = t(10),
          i = t(0),
          s = t(5),
          m = t(1);
        o.ecclCSMAttributes = function (e, o, t, c, a, l, d) {
          try {
            if (!(0, i.isValidFunction)(d))
              throw new Error("logger is null or not a function");
            var u = {};
            (0, i.isValidFunction)(o) && o(),
              (u = (0, i.isValidFunction)(t)
                ? t(e)
                : (0, r.collectWithSchemaHavingNestedObjects)(
                    e,
                    null,
                    null,
                    0,
                    l
                  )),
              (0, s.deleteForensicsObject)(),
              (0, i.isValidFunction)(c)
                ? (u = c(u, e))
                : a &&
                  (u = (0, n.compressWithSchemaNestedObjects)(
                    u,
                    e,
                    null,
                    0,
                    l
                  )),
              d(u);
          } catch (e) {
            (0, m.reportError)(e);
          }
        };
      },
      function (e, o, t) {
        "use strict";
        Object.defineProperty(o, "__esModule", { value: !0 }),
          (o.collectWithSchemaHavingNestedObjects = void 0);
        var r =
            "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
              ? function (e) {
                  return typeof e;
                }
              : function (e) {
                  return e &&
                    "function" == typeof Symbol &&
                    e.constructor === Symbol &&
                    e !== Symbol.prototype
                    ? "symbol"
                    : typeof e;
                },
          n = t(0),
          i = t(1),
          s = (0, n.getHighestAccessibleWindow)();
        o.collectWithSchemaHavingNestedObjects = function e(o, t, n, m, c) {
          var a = t || s,
            l = n || o,
            d = {};
          try {
            if (c < m) return {};
            var u = void 0;
            Object.keys(l).forEach(function (t) {
              "object" !== (void 0 === (u = l[t]) ? "undefined" : r(u)) ||
              Array.isArray(u)
                ? (d[t] = a[t])
                : null == a[t]
                ? (d[t] = null)
                : (d[t] = e(o, a[t], l[t], m + 1, c));
            });
          } catch (t) {
            (0, i.reportError)(t);
          }
          return d;
        };
      },
      function (e, o, t) {
        "use strict";
        Object.defineProperty(o, "__esModule", { value: !0 }),
          (o.compressWithSchemaNestedObjects = void 0);
        var r =
            "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
              ? function (e) {
                  return typeof e;
                }
              : function (e) {
                  return e &&
                    "function" == typeof Symbol &&
                    e.constructor === Symbol &&
                    e !== Symbol.prototype
                    ? "symbol"
                    : typeof e;
                },
          n = t(1);
        o.compressWithSchemaNestedObjects = function e(o, t, i, s, m) {
          var c = [];
          try {
            if (m <= s) return [];
            var a = i || t,
              l = Object.keys(a),
              d = 0;
            l.forEach(function (n) {
              if ("object" != r(a[n]) || null == a[n] || Array.isArray(a[n]))
                switch (!0) {
                  case !0 === o[n]:
                    c[d] = 1;
                    break;
                  case !1 === o[n]:
                  case 0 === o[n]:
                    c[d] = 0;
                    break;
                  case null != o[n]:
                    c[d] = o[n];
                    break;
                  default:
                    c[d] = null;
                }
              else
                null != o[n]
                  ? (c[d] = e(o[n], t, a[n], s + 1))
                  : (c[d] = e({}, t, a[n], s + 1));
              d += 1;
            });
          } catch (i) {
            (0, n.reportError)(i);
          }
          return c;
        };
      },
      function (e, o, t) {
        "use strict";
        Object.defineProperty(o, "__esModule", { value: !0 }),
          (o.computeAndSetPropertiesLength =
            o.computeAndSetPropertiesSupported =
            o.computeAndSetNavigatorUserAgentGetter =
            o.computeAndSetAncestorOrigins =
            o.computeAndSetNavigatorWebDriverByDescriptor =
            o.computeAndSetNavigatorUserAgentByDescriptor =
            o.computeAndSetArch =
            o.computeAndSetDocumentHasFocus =
            o.computeAndSetRegExpLength =
            o.computeAndSetTimeZone =
            o.computeAndSetNavigatorMimeTypesLength =
            o.computeAndSetNavigatorPluginLength =
            o.isDocHidden =
            o.computeAndSetStyle =
            o.evaluateAttributes =
              void 0);
        var r = t(5),
          n = t(0),
          i = t(1),
          s = t(6),
          m = "",
          c = (0, n.getHighestAccessibleWindow)(),
          a = window,
          l = c.document;
        function d(e) {
          try {
            return e && e !== top && e.parent && e !== e.parent
              ? e.parent
              : null;
          } catch (e) {
            return null;
          }
        }
        function u(e, o) {
          var t = void 0,
            r = void 0,
            n = void 0;
          try {
            t =
              e.document && e.document.documentElement
                ? e.document.documentElement
                : null;
          } catch (e) {
            t = null;
          }
          try {
            t && (r = e.getComputedStyle(t));
          } catch (e) {
            r = null;
          }
          try {
            t && (n = t.getBoundingClientRect());
          } catch (e) {
            n = null;
          }
          o.inlineStyle.cssText.push(
            (t && t.getAttribute && t.getAttribute("style")) || m
          ),
            o.inlineStyle.display.push((t && t.style && t.style.display) || m),
            o.inlineStyle.visibility.push(
              (t && t.style && t.style.visibility) || m
            ),
            o.inlineStyle.opacity.push((t && t.style && t.style.opacity) || m),
            o.inlineStyle.filter.push((t && t.style && t.style.filter) || m),
            o.inlineStyle.contentVisibility.push(
              (t && t.style && t.style.contentVisibility) || m
            ),
            o.inlineStyle.transform.push(
              (t && t.style && t.style.transform) || m
            ),
            o.inlineStyle.rotate.push((t && t.style && t.style.rotate) || m),
            o.inlineStyle.backfaceVisibility.push(
              (t && t.style ? t.style.backfaceVisibility : m) ||
                (t && t.style ? t.style.webkitBackfaceVisibility : m) ||
                m
            ),
            o.inlineStyle.clip.push((t && t.style && t.style.clip) || m),
            o.inlineStyle.clipPath.push(
              (t && t.style && t.style.clipPath) || m
            ),
            o.inlineStyle.maskImage.push(
              (t && t.style ? t.style.maskImage : m) ||
                (t && t.style ? t.style.webkitMaskImage : m) ||
                m
            ),
            o.inlineStyle.overflow.push(
              (t && t.style && t.style.overflow) || m
            ),
            o.inlineStyle.overflowX.push(
              (t && t.style && t.style.overflowX) || m
            ),
            o.inlineStyle.overflowY.push(
              (t && t.style && t.style.overflowY) || m
            ),
            o.inlineStyle.width.push((t && t.style && t.style.width) || m),
            o.inlineStyle.height.push((t && t.style && t.style.height) || m),
            o.inlineStyle.position.push(
              (t && t.style && t.style.position) || m
            ),
            o.inlineStyle.left.push((t && t.style && t.style.left) || m),
            o.inlineStyle.top.push((t && t.style && t.style.top) || m),
            o.inlineStyle.right.push((t && t.style && t.style.right) || m),
            o.inlineStyle.bottom.push((t && t.style && t.style.bottom) || m),
            o.inlineStyle.zIndex.push((t && t.style && t.style.zIndex) || m),
            o.inlineStyle.webkitFilter.push(
              (t && t.style && t.style.webkitFilter) || m
            ),
            o.inlineStyle.backdropFilter.push(
              (t && t.style && t.style.backdropFilter) || m
            ),
            o.inlineStyle.webkitBackdropFilter.push(
              (t && t.style && t.style.webkitBackdropFilter) || m
            ),
            o.computedStyle.display.push(
              (r && r.getPropertyValue && r.getPropertyValue("display")) || m
            ),
            o.computedStyle.visibility.push(
              (r && r.getPropertyValue && r.getPropertyValue("visibility")) || m
            ),
            o.computedStyle.opacity.push(
              (r && r.getPropertyValue && r.getPropertyValue("opacity")) || m
            ),
            o.computedStyle.filter.push(
              (r && r.getPropertyValue && r.getPropertyValue("filter")) || m
            ),
            o.computedStyle.contentVisibility.push(
              (r &&
                r.getPropertyValue &&
                r.getPropertyValue("content-visibility")) ||
                m
            ),
            o.computedStyle.transform.push(
              (r && r.getPropertyValue && r.getPropertyValue("transform")) || m
            ),
            o.computedStyle.rotate.push(
              (r && r.getPropertyValue && r.getPropertyValue("rotate")) || m
            ),
            o.computedStyle.backfaceVisibility.push(
              (r && r.getPropertyValue
                ? r.getPropertyValue("backface-visibility")
                : m) ||
                (r && r.getPropertyValue
                  ? r.getPropertyValue("-webkit-backface-visibility")
                  : m) ||
                m
            ),
            o.computedStyle.clip.push(
              (r && r.getPropertyValue && r.getPropertyValue("clip")) || m
            ),
            o.computedStyle.clipPath.push(
              (r && r.getPropertyValue && r.getPropertyValue("clip-path")) || m
            ),
            o.computedStyle.maskImage.push(
              (r && r.getPropertyValue
                ? r.getPropertyValue("mask-image")
                : m) ||
                (r && r.getPropertyValue
                  ? r.getPropertyValue("-webkit-mask-image")
                  : m) ||
                m
            ),
            o.computedStyle.overflow.push(
              (r && r.getPropertyValue && r.getPropertyValue("overflow")) || m
            ),
            o.computedStyle.overflowX.push(
              (r && r.getPropertyValue && r.getPropertyValue("overflow-x")) || m
            ),
            o.computedStyle.overflowY.push(
              (r && r.getPropertyValue && r.getPropertyValue("overflow-y")) || m
            ),
            o.computedStyle.width.push(
              (r && r.getPropertyValue && r.getPropertyValue("width")) || m
            ),
            o.computedStyle.height.push(
              (r && r.getPropertyValue && r.getPropertyValue("height")) || m
            ),
            o.computedStyle.position.push(
              (r && r.getPropertyValue && r.getPropertyValue("position")) || m
            ),
            o.computedStyle.left.push(
              (r && r.getPropertyValue && r.getPropertyValue("left")) || m
            ),
            o.computedStyle.top.push(
              (r && r.getPropertyValue && r.getPropertyValue("top")) || m
            ),
            o.computedStyle.right.push(
              (r && r.getPropertyValue && r.getPropertyValue("right")) || m
            ),
            o.computedStyle.bottom.push(
              (r && r.getPropertyValue && r.getPropertyValue("bottom")) || m
            ),
            o.computedStyle.zIndex.push(
              (r && r.getPropertyValue && r.getPropertyValue("z-index")) || m
            ),
            o.computedStyle.backdropFilter.push(
              (r &&
                r.getPropertyValue &&
                r.getPropertyValue("backdrop-filter")) ||
                m
            ),
            o.rect.left.push(n && void 0 !== n.left ? n.left : m),
            o.rect.top.push(n && void 0 !== n.top ? n.top : m),
            o.rect.right.push(n && void 0 !== n.right ? n.right : m),
            o.rect.bottom.push(n && void 0 !== n.bottom ? n.bottom : m),
            o.rect.width.push(n && void 0 !== n.width ? n.width : m),
            o.rect.height.push(n && void 0 !== n.height ? n.height : m);
          try {
            o.screen.screenX.push("number" == typeof e.screenX ? e.screenX : m);
          } catch (e) {
            o.screen.screenX.push(m);
          }
          try {
            o.screen.screenY.push("number" == typeof e.screenY ? e.screenY : m);
          } catch (e) {
            o.screen.screenY.push(m);
          }
          try {
            o.screen.screenLeft.push(
              "number" == typeof e.screenLeft ? e.screenLeft : m
            );
          } catch (e) {
            o.screen.screenLeft.push(m);
          }
          try {
            o.screen.screenTop.push(
              "number" == typeof e.screenTop ? e.screenTop : m
            );
          } catch (e) {
            o.screen.screenTop.push(m);
          }
        }
        function p(e, o, t) {
          try {
            var n = !!Object.getOwnPropertyDescriptor(e, o);
            (0, r.addObjToForensicsObj)(t, n);
          } catch (e) {
            (0, i.reportError)(e);
          }
        }
        function $(e, o) {
          try {
            var t = Object.getOwnPropertyNames(e).length;
            (0, r.addObjToForensicsObj)(o, t);
          } catch (e) {
            (0, i.reportError)(e);
          }
        }
        o.evaluateAttributes = function () {
          g(), y(), h(), _(), v(), S(), E(), P(), C(), x(), b(), f(), O();
        };
        var f = (o.computeAndSetStyle = function () {
            try {
              for (
                var e = JSON.parse(JSON.stringify(s.styleCsmObjectSchema)),
                  o = window,
                  t = 0;
                o && t < 5;

              ) {
                u(o, e);
                var n = d(o);
                if (!n) break;
                (o = n), t++;
              }
              (0, r.addObjToForensicsObj)("style", e);
            } catch (e) {
              (0, i.reportError)(e);
            }
          }),
          g =
            ((o.isDocHidden = function () {
              try {
                var e = "undefined";
                void 0 !== l.hidden
                  ? (e = "hidden")
                  : void 0 !== l.msHidden
                  ? (e = "msHidden")
                  : void 0 !== l.mozHidden
                  ? (e = "mozHidden")
                  : void 0 !== l.webkitHidden && (e = "webkitHidden"),
                  (0, r.addObjToForensicsObj)("hidden", e);
              } catch (e) {
                (0, i.reportError)(e);
              }
            }),
            (o.computeAndSetNavigatorPluginLength = function () {
              try {
                (0, r.addObjToForensicsObj)(
                  "pluginsLength",
                  c.navigator.plugins.length
                );
              } catch (e) {
                (0, i.reportError)(e);
              }
            })),
          y = (o.computeAndSetNavigatorMimeTypesLength = function () {
            try {
              (0, r.addObjToForensicsObj)(
                "mimeTypesLength",
                c.navigator.mimeTypes.length
              );
            } catch (e) {
              (0, i.reportError)(e);
            }
          }),
          h = (o.computeAndSetTimeZone = function () {
            try {
              var e = Intl.DateTimeFormat().resolvedOptions().timeZone;
              (0, r.addObjToForensicsObj)("timeZone", e);
            } catch (e) {
              (0, i.reportError)(e);
            }
          }),
          _ = (o.computeAndSetRegExpLength = function () {
            try {
              var e = RegExp.toString().length;
              (0, r.addObjToForensicsObj)("regExpLength", e);
            } catch (e) {
              (0, i.reportError)(e);
            }
          }),
          E = (o.computeAndSetDocumentHasFocus = function () {
            try {
              (0, r.addObjToForensicsObj)(
                "documentHasFocus",
                c.document.hasFocus()
              );
            } catch (e) {
              (0, i.reportError)(e);
            }
          }),
          v = (o.computeAndSetArch = function () {
            try {
              var e = new Float32Array(1),
                o = new DataView(e.buffer);
              (e[0] = 1 / 0), (e[0] = e[0] - e[0]);
              var t = o.getUint32(0);
              (0, r.addObjToForensicsObj)("arch", t);
            } catch (e) {
              (0, i.reportError)(e);
            }
          }),
          S = (o.computeAndSetNavigatorUserAgentByDescriptor = function () {
            try {
              var e = Object.getOwnPropertyDescriptor(
                Navigator.prototype,
                "userAgent"
              ).get.call(navigator);
              (0, r.addObjToForensicsObj)("navigatorUserAgentByDescriptor", e);
            } catch (e) {
              (0, i.reportError)(e);
            }
          }),
          b = (o.computeAndSetNavigatorWebDriverByDescriptor = function () {
            try {
              var e = Object.getOwnPropertyDescriptor(
                Navigator.prototype,
                "webdriver"
              ).get.call(navigator);
              (0, r.addObjToForensicsObj)("navigatorWebDriverByDescriptor", e);
            } catch (e) {
              (0, i.reportError)(e);
            }
          }),
          O = (o.computeAndSetAncestorOrigins = function () {
            try {
              var e = window.location && window.location.ancestorOrigins;
              if (!e)
                return void (0, r.addObjToForensicsObj)(
                  "ancestorOrigins",
                  null
                );
              for (var o = [], t = 0; t < e.length; t++) o.push(e[t] || "null");
              (0, r.addObjToForensicsObj)("ancestorOrigins", o);
            } catch (e) {
              (0, i.reportError)(e);
            }
          }),
          P = (o.computeAndSetNavigatorUserAgentGetter = function () {
            try {
              var e = Object.getOwnPropertyDescriptor(
                Navigator.prototype,
                "userAgent"
              ).get.name;
              (0, r.addObjToForensicsObj)("navigatorUserAgentGetter", e);
            } catch (e) {
              (0, i.reportError)(e);
            }
          }),
          C = (o.computeAndSetPropertiesSupported = function () {
            try {
              p(a, "globalThis", "isGlobalThisSupported"),
                p(c, "WebKitPoint", "isWebKitPointSupported"),
                p(c, "ApplePaySession", "isApplePaySessionSupported");
            } catch (e) {
              (0, i.reportError)(e);
            }
          }),
          x = (o.computeAndSetPropertiesLength = function () {
            try {
              a && $(a, "windowPropertiesLength"),
                c && c.navigator && $(c.navigator, "navigatorPropertiesLength"),
                Document &&
                  Document.prototype &&
                  $(Document.prototype, "documentPropertiesLength"),
                Error &&
                  Error.prototype &&
                  $(Error.prototype, "errorPropertiesLength"),
                Set && Set.prototype && $(Set.prototype, "setPropertiesLength"),
                Worker &&
                  Worker.prototype &&
                  $(Worker.prototype, "workerPropertiesLength"),
                a &&
                  a.document &&
                  a.document.body &&
                  a.document.body.style &&
                  a.document.body.style.__proto__ &&
                  $(
                    a.document.body.style.__proto__,
                    "cssStyleDeclarationPropertiesLength"
                  ),
                JSON && $(JSON, "jsonPropertiesLength"),
                HTMLElement &&
                  HTMLElement.prototype &&
                  $(HTMLElement.prototype, "htmlElementPropertiesLength"),
                Window &&
                  Window.prototype &&
                  $(Window.prototype, "windowPrototypePropertiesLength"),
                Event &&
                  Event.prototype &&
                  $(Event.prototype, "eventPropertiesLength"),
                AudioContext &&
                  AudioContext.prototype &&
                  $(AudioContext.prototype, "audioContextPropertiesLength"),
                WebGLRenderingContext &&
                  WebGLRenderingContext.prototype &&
                  $(
                    WebGLRenderingContext.prototype,
                    "webGLRenderingContextPropertiesLength"
                  ),
                WebGL2RenderingContext &&
                  WebGL2RenderingContext.prototype &&
                  $(
                    WebGL2RenderingContext.prototype,
                    "webGL2RenderingContextPropertiesLength"
                  ),
                OfflineAudioContext &&
                  OfflineAudioContext.prototype &&
                  $(
                    OfflineAudioContext.prototype,
                    "offlineAudioContextPropertiesLength"
                  ),
                localStorage && $(localStorage, "localStoragePropertiesLength");
            } catch (e) {
              (0, i.reportError)(e);
            }
          });
      },
      function (e, o, t) {
        "use strict";
        Object.defineProperty(o, "__esModule", { value: !0 }),
          (o.log =
            o.postRequest =
            o.logToTungstenCombined =
            o.logWithNexus =
              void 0);
        var r =
            "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
              ? function (e) {
                  return typeof e;
                }
              : function (e) {
                  return e &&
                    "function" == typeof Symbol &&
                    e.constructor === Symbol &&
                    e !== Symbol.prototype
                    ? "symbol"
                    : typeof e;
                },
          n = t(4),
          i = t(1),
          s = (function (e) {
            if (e && e.__esModule) return e;
            var o = {};
            if (null != e)
              for (var t in e)
                Object.prototype.hasOwnProperty.call(e, t) && (o[t] = e[t]);
            return (o.default = e), o;
          })(t(2));
        (o.logWithNexus = function (e, o, t, s, m, c) {
          try {
            var a = { vfrd: 1 === o ? s : t };
            "object" === (void 0 === e ? "undefined" : r(e))
              ? (a.info = JSON.stringify(e))
              : "string" == typeof e
              ? (a.info = e)
              : "number" == typeof e && (a.info = e.toString()),
              (0, n.addNexusPixel)(a, m, c);
          } catch (e) {
            return (0, i.reportError)(e), !1;
          }
          return !0;
        }),
          (o.logToTungstenCombined = function (e, o, t, r, n, i, s, d) {
            var u = 6 < arguments.length && void 0 !== s && s,
              p = !(7 < arguments.length && void 0 !== d) || d;
            try {
              var $ = m(o, t, n, i, u),
                f = c(e, r, p);
              a(f, $, function (e) {
                l(e.message);
              });
            } catch (e) {
              l(e.message);
            }
          });
        var m = function (e, o, t, r, n) {
            var i = 4 < arguments.length && void 0 !== n && n;
            if (!o) throw new Error("bidId is not defined");
            return [
              {
                ver: r,
                ts: new Date().getTime(),
                error: i ? 1 : 0,
                bidId: o,
                fmp: i ? e : { vfrd: t, dbg: e.dbg },
              },
            ];
          },
          c = function (e, o, t) {
            if (!o) throw new Error("Zone is not defined");
            var r = s.NTD_REGION_MAP[o];
            if (!r) throw new Error("NTD region is not defined for zone: " + o);
            return (
              "https://www.btd-" +
              r +
              ".tq-tungsten.com/" +
              (t ? "collect" : "log") +
              "/" +
              e
            );
          },
          a = (o.postRequest = function (e, o, t) {
            fetch(e, {
              cache: "no-cache",
              method: "POST",
              body: JSON.stringify(o),
              headers: new Headers({ "Content-Type": "application/json" }),
            })
              .then(function (e) {
                if (200 !== e.status)
                  throw new Error(
                    "Tungsten returned response status: " + e.status
                  );
              })
              .catch(function (e) {
                t && t(e);
              });
          }),
          l = (o.log = function (e) {
            try {
              -1 !== window.location.href.indexOf("csm_debug_mode") &&
                window.console &&
                window.console.log(e);
            } catch (e) {
              window.console.log(e.message);
            }
          });
      },
      function (e, o, t) {
        "use strict";
        Object.defineProperty(o, "__esModule", { value: !0 }),
          (o.getVerificationParamsFromSessionStart =
            o.extractRequiredParamsAndLog =
            o.isLoggingParamsValid =
            o.getSourceTypeFromLoggingParameters =
            o.getSourceIdFromLoggingParameters =
            o.getZoneFromLoggingParameters =
            o.getBidIdFromLoggingParameters =
              void 0);
        var r =
            "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
              ? function (e) {
                  return typeof e;
                }
              : function (e) {
                  return e &&
                    "function" == typeof Symbol &&
                    e.constructor === Symbol &&
                    e !== Symbol.prototype
                    ? "symbol"
                    : typeof e;
                },
          n = t(29),
          i = t(30),
          s = t(12),
          m = t(2),
          c = (function (e) {
            if (e && e.__esModule) return e;
            var o = {};
            if (null != e)
              for (var t in e)
                Object.prototype.hasOwnProperty.call(e, t) && (o[t] = e[t]);
            return (o.default = e), o;
          })(m);
        function a(e, o) {
          return e[o];
        }
        var l = (o.getBidIdFromLoggingParameters = function (e) {
            return a(e, "bidId");
          }),
          d = (o.getZoneFromLoggingParameters = function (e) {
            return a(e, "zone");
          });
        (o.getSourceIdFromLoggingParameters = function (e) {
          return a(e, "sourceid");
        }),
          (o.getSourceTypeFromLoggingParameters = function (e) {
            return a(e, "sourcetype");
          }),
          (o.isLoggingParamsValid = function (e) {
            if (!e) return !1;
            var o = l(e),
              t = d(e),
              r = (0, n.getCombinedTenantBasedOnSupply)(e),
              s = (0, i.getVFRDBasedOnSupplyFromLoggingParameters)(e);
            return !!(o && t && r && s);
          }),
          (o.extractRequiredParamsAndLog = function (e, o, t) {
            var r = l(e),
              m = d(e),
              a = (0, i.getVFRDBasedOnSupplyFromLoggingParameters)(e),
              u = (0, n.getCombinedTenantBasedOnSupply)(e);
            (0, s.logToTungstenCombined)(u, o, r, m, a, c.SSI_CSM_VERSION, t);
          }),
          (o.getVerificationParamsFromSessionStart = function (e) {
            return e.type === m.SESSION_START_EVENT &&
              e.data &&
              "object" === r(e.data) &&
              e.data.verificationParameters
              ? JSON.parse(e.data.verificationParameters)
              : {};
          });
      },
      ,
      ,
      ,
      ,
      ,
      ,
      ,
      ,
      ,
      ,
      ,
      function (e, o, t) {
        "use strict";
        Object.defineProperty(o, "__esModule", { value: !0 }),
          (o.init = void 0);
        var r = t(8),
          n = t(6),
          i = t(2),
          s = (function (e) {
            if (e && e.__esModule) return e;
            var o = {};
            if (null != e)
              for (var t in e)
                Object.prototype.hasOwnProperty.call(e, t) && (o[t] = e[t]);
            return (o.default = e), o;
          })(i),
          m = t(1),
          c = t(26),
          a = t(27),
          l = t(13),
          d = t(11);
        function u(e, o) {
          var t = 1 < arguments.length && void 0 !== o && o;
          if (g) (0, l.extractRequiredParamsAndLog)(g, e, t);
          else {
            var r = y();
            if (r)
              return (g = r), void (0, l.extractRequiredParamsAndLog)(r, e, t);
            !(function (e, o) {
              var t = 1 < arguments.length && void 0 !== o && o;
              new a.OmidVerificationClient().registerSessionObserver(function (
                o
              ) {
                if (o.type === i.SESSION_START_EVENT) {
                  var r = (0, l.getVerificationParamsFromSessionStart)(o);
                  if ((0, l.isLoggingParamsValid)(r))
                    return (
                      (g = r), void (0, l.extractRequiredParamsAndLog)(r, e, t)
                    );
                  throw new Error(
                    "Unable to fetch bidId or zone or tenantId from logging parameters"
                  );
                }
              });
            })(e, t);
          }
        }
        function p(e) {
          u({ dbg: JSON.stringify(e) }, !1);
        }
        function $(e) {
          u({ m: e }, !0);
        }
        function f() {
          try {
            (0, m.getErrorHandler)().setLogErrorPixel($),
              (0, r.ecclCSMAttributes)(
                n.csmAttribute,
                d.evaluateAttributes,
                null,
                null,
                !0,
                s.MAX_DEPTH,
                p
              );
          } catch (e) {
            (0, m.reportError)(e);
          }
        }
        var g = void 0,
          y = function () {
            if ("undefined" != typeof window ? window.document : document)
              try {
                var e = (0, c.getParametersFromTagstone)();
                if ((0, l.isLoggingParamsValid)(e)) return e;
              } catch (e) {
                return;
              }
          };
        f(), (o.init = f);
      },
      function (e, o, t) {
        "use strict";
        Object.defineProperty(o, "__esModule", { value: !0 }),
          (o.getParametersFromTagstone = function () {
            var e = "undefined" != typeof window ? window.document : document;
            if (!e || !e.currentScript || !e.currentScript.src)
              throw new Error("Error accessing current script source");
            var o = new URL(e.currentScript.src);
            return Object.fromEntries(new URLSearchParams(o.search));
          });
      },
      function (module, exports, __webpack_require__) {
        "use strict";
        (function (global) {
          var _typeof =
              "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
                ? function (e) {
                    return typeof e;
                  }
                : function (e) {
                    return e &&
                      "function" == typeof Symbol &&
                      e.constructor === Symbol &&
                      e !== Symbol.prototype
                      ? "symbol"
                      : typeof e;
                  },
            $k,
            _k,
            al,
            bl,
            dl;
          ($k = void 0 === global ? void 0 : global),
            (_k = function (omidGlobal, omidExports) {
              var $jscomp = $jscomp || {};
              ($jscomp.scope = {}),
                ($jscomp.arrayIteratorImpl = function (e) {
                  var o = 0;
                  return function () {
                    return o < e.length
                      ? { done: !1, value: e[o++] }
                      : { done: !0 };
                  };
                }),
                ($jscomp.arrayIterator = function (e) {
                  return { next: $jscomp.arrayIteratorImpl(e) };
                }),
                ($jscomp.makeIterator = function (e) {
                  var o =
                    "undefined" != typeof Symbol &&
                    Symbol.iterator &&
                    e[Symbol.iterator];
                  return o ? o.call(e) : $jscomp.arrayIterator(e);
                }),
                ($jscomp.arrayFromIterator = function (e) {
                  for (var o, t = []; !(o = e.next()).done; ) t.push(o.value);
                  return t;
                }),
                ($jscomp.arrayFromIterable = function (e) {
                  return e instanceof Array
                    ? e
                    : $jscomp.arrayFromIterator($jscomp.makeIterator(e));
                }),
                ($jscomp.ASSUME_ES5 = !1),
                ($jscomp.ASSUME_NO_NATIVE_MAP = !1),
                ($jscomp.ASSUME_NO_NATIVE_SET = !1),
                ($jscomp.SIMPLE_FROUND_POLYFILL = !1),
                ($jscomp.objectCreate =
                  $jscomp.ASSUME_ES5 || "function" == typeof Object.create
                    ? Object.create
                    : function (e) {
                        function o() {}
                        return (o.prototype = e), new o();
                      }),
                ($jscomp.underscoreProtoCanBeSet = function () {
                  var e = {};
                  try {
                    return (e.__proto__ = { a: !0 }), e.a;
                  } catch (e) {}
                  return !1;
                }),
                ($jscomp.setPrototypeOf =
                  "function" == typeof Object.setPrototypeOf
                    ? Object.setPrototypeOf
                    : $jscomp.underscoreProtoCanBeSet()
                    ? function (e, o) {
                        if (((e.__proto__ = o), e.__proto__ !== o))
                          throw new TypeError(e + " is not extensible");
                        return e;
                      }
                    : null),
                ($jscomp.inherits = function (e, o) {
                  if (
                    ((e.prototype = $jscomp.objectCreate(o.prototype)),
                    (e.prototype.constructor = e),
                    $jscomp.setPrototypeOf)
                  ) {
                    var t = $jscomp.setPrototypeOf;
                    t(e, o);
                  } else
                    for (t in o)
                      if ("prototype" != t)
                        if (Object.defineProperties) {
                          var r = Object.getOwnPropertyDescriptor(o, t);
                          r && Object.defineProperty(e, t, r);
                        } else e[t] = o[t];
                  e.superClass_ = o.prototype;
                });
              var module$exports$omid$common$argsChecker = {
                  assertTruthyString: function (e, o) {
                    if (!o)
                      throw Error(
                        "Value for " + e + " is undefined, null or blank."
                      );
                    if ("string" != typeof o && !(o instanceof String))
                      throw Error("Value for " + e + " is not a string.");
                    if ("" === o.trim())
                      throw Error("Value for " + e + " is empty string.");
                  },
                  assertNotNullObject: function (e, o) {
                    if (null == o)
                      throw Error("Value for " + e + " is undefined or null");
                  },
                  assertNumber: function (e, o) {
                    if (null == o)
                      throw Error(e + " must not be null or undefined.");
                    if ("number" != typeof o || isNaN(o))
                      throw Error("Value for " + e + " is not a number");
                  },
                  assertNumberBetween: function (e, o, t, r) {
                    if (
                      ((0, module$exports$omid$common$argsChecker.assertNumber)(
                        e,
                        o
                      ),
                      o < t || r < o)
                    )
                      throw Error(
                        "Value for " +
                          e +
                          " is outside the range [" +
                          t +
                          "," +
                          r +
                          "]"
                      );
                  },
                  assertFunction: function (e, o) {
                    if (!o) throw Error(e + " must not be truthy.");
                  },
                  assertPositiveNumber: function (e, o) {
                    if (
                      ((0, module$exports$omid$common$argsChecker.assertNumber)(
                        e,
                        o
                      ),
                      o < 0)
                    )
                      throw Error(e + " must be a positive number.");
                  },
                },
                module$exports$omid$common$VersionUtils = {},
                module$contents$omid$common$VersionUtils_SEMVER_DIGITS_NUMBER = 3;
              (module$exports$omid$common$VersionUtils.isValidVersion =
                function (e) {
                  return /\d+\.\d+\.\d+(-.*)?/.test(e);
                }),
                (module$exports$omid$common$VersionUtils.versionGreaterOrEqual =
                  function (e, o) {
                    (e = e.split("-")[0].split(".")),
                      (o = o.split("-")[0].split("."));
                    for (
                      var t = 0;
                      t <
                      module$contents$omid$common$VersionUtils_SEMVER_DIGITS_NUMBER;
                      t++
                    ) {
                      var r = parseInt(e[t], 10),
                        n = parseInt(o[t], 10);
                      if (n < r) break;
                      if (r < n) return !1;
                    }
                    return !0;
                  });
              var module$exports$omid$common$ArgsSerDe = {},
                module$contents$omid$common$ArgsSerDe_ARGS_NOT_SERIALIZED_VERSION =
                  "1.0.3";
              (module$exports$omid$common$ArgsSerDe.serializeMessageArgs =
                function (e, o) {
                  return (0,
                  module$exports$omid$common$VersionUtils.isValidVersion)(e) &&
                    (0,
                    module$exports$omid$common$VersionUtils.versionGreaterOrEqual)(
                      e,
                      module$contents$omid$common$ArgsSerDe_ARGS_NOT_SERIALIZED_VERSION
                    )
                    ? o
                    : JSON.stringify(o);
                }),
                (module$exports$omid$common$ArgsSerDe.deserializeMessageArgs =
                  function (e, o) {
                    return (0,
                    module$exports$omid$common$VersionUtils.isValidVersion)(
                      e
                    ) &&
                      (0,
                      module$exports$omid$common$VersionUtils.versionGreaterOrEqual)(
                        e,
                        module$contents$omid$common$ArgsSerDe_ARGS_NOT_SERIALIZED_VERSION
                      )
                      ? o || []
                      : o && "string" == typeof o
                      ? JSON.parse(o)
                      : [];
                  });
              var module$exports$omid$common$constants = {
                AdEventType: {
                  IMPRESSION: "impression",
                  STATE_CHANGE: "stateChange",
                  GEOMETRY_CHANGE: "geometryChange",
                  SESSION_START: "sessionStart",
                  SESSION_ERROR: "sessionError",
                  SESSION_FINISH: "sessionFinish",
                  MEDIA: "media",
                  VIDEO: "video",
                  LOADED: "loaded",
                  START: "start",
                  FIRST_QUARTILE: "firstQuartile",
                  MIDPOINT: "midpoint",
                  THIRD_QUARTILE: "thirdQuartile",
                  COMPLETE: "complete",
                  PAUSE: "pause",
                  RESUME: "resume",
                  BUFFER_START: "bufferStart",
                  BUFFER_FINISH: "bufferFinish",
                  SKIPPED: "skipped",
                  VOLUME_CHANGE: "volumeChange",
                  PLAYER_STATE_CHANGE: "playerStateChange",
                  AD_USER_INTERACTION: "adUserInteraction",
                },
                MediaEventType: {
                  LOADED: "loaded",
                  START: "start",
                  FIRST_QUARTILE: "firstQuartile",
                  MIDPOINT: "midpoint",
                  THIRD_QUARTILE: "thirdQuartile",
                  COMPLETE: "complete",
                  PAUSE: "pause",
                  RESUME: "resume",
                  BUFFER_START: "bufferStart",
                  BUFFER_FINISH: "bufferFinish",
                  SKIPPED: "skipped",
                  VOLUME_CHANGE: "volumeChange",
                  PLAYER_STATE_CHANGE: "playerStateChange",
                  AD_USER_INTERACTION: "adUserInteraction",
                },
              };
              (module$exports$omid$common$constants.VideoEventType =
                module$exports$omid$common$constants.MediaEventType),
                (module$exports$omid$common$constants.ImpressionType = {
                  DEFINED_BY_JAVASCRIPT: "definedByJavaScript",
                  UNSPECIFIED: "unspecified",
                  LOADED: "loaded",
                  BEGIN_TO_RENDER: "beginToRender",
                  ONE_PIXEL: "onePixel",
                  VIEWABLE: "viewable",
                  AUDIBLE: "audible",
                  OTHER: "other",
                }),
                (module$exports$omid$common$constants.ErrorType = {
                  GENERIC: "generic",
                  VIDEO: "video",
                  MEDIA: "media",
                }),
                (module$exports$omid$common$constants.AdSessionType = {
                  NATIVE: "native",
                  HTML: "html",
                  JAVASCRIPT: "javascript",
                }),
                (module$exports$omid$common$constants.EventOwner = {
                  NATIVE: "native",
                  JAVASCRIPT: "javascript",
                  NONE: "none",
                }),
                (module$exports$omid$common$constants.AccessMode = {
                  FULL: "full",
                  LIMITED: "limited",
                }),
                (module$exports$omid$common$constants.AppState = {
                  BACKGROUNDED: "backgrounded",
                  FOREGROUNDED: "foregrounded",
                }),
                (module$exports$omid$common$constants.Environment = {
                  APP: "app",
                  WEB: "web",
                }),
                (module$exports$omid$common$constants.InteractionType = {
                  CLICK: "click",
                  INVITATION_ACCEPT: "invitationAccept",
                }),
                (module$exports$omid$common$constants.CreativeType = {
                  DEFINED_BY_JAVASCRIPT: "definedByJavaScript",
                  HTML_DISPLAY: "htmlDisplay",
                  NATIVE_DISPLAY: "nativeDisplay",
                  VIDEO: "video",
                  AUDIO: "audio",
                }),
                (module$exports$omid$common$constants.MediaType = {
                  DISPLAY: "display",
                  VIDEO: "video",
                }),
                (module$exports$omid$common$constants.Reason = {
                  NOT_FOUND: "notFound",
                  HIDDEN: "hidden",
                  BACKGROUNDED: "backgrounded",
                  VIEWPORT: "viewport",
                  OBSTRUCTED: "obstructed",
                  CLIPPED: "clipped",
                }),
                (module$exports$omid$common$constants.SupportedFeatures = {
                  CONTAINER: "clid",
                  VIDEO: "vlid",
                }),
                (module$exports$omid$common$constants.VideoPosition = {
                  PREROLL: "preroll",
                  MIDROLL: "midroll",
                  POSTROLL: "postroll",
                  STANDALONE: "standalone",
                }),
                (module$exports$omid$common$constants.VideoPlayerState = {
                  MINIMIZED: "minimized",
                  COLLAPSED: "collapsed",
                  NORMAL: "normal",
                  EXPANDED: "expanded",
                  FULLSCREEN: "fullscreen",
                }),
                (module$exports$omid$common$constants.NativeViewKeys = {
                  X: "x",
                  LEFT: "left",
                  Y: "y",
                  TOP: "top",
                  WIDTH: "width",
                  HEIGHT: "height",
                  AD_SESSION_ID: "adSessionId",
                  IS_FRIENDLY_OBSTRUCTION_FOR: "isFriendlyObstructionFor",
                  CLIPS_TO_BOUNDS: "clipsToBounds",
                  CHILD_VIEWS: "childViews",
                  END_X: "endX",
                  END_Y: "endY",
                  OBSTRUCTIONS: "obstructions",
                  OBSTRUCTION_CLASS: "obstructionClass",
                  OBSTRUCTION_PURPOSE: "obstructionPurpose",
                  OBSTRUCTION_REASON: "obstructionReason",
                  PIXELS: "pixels",
                }),
                (module$exports$omid$common$constants.MeasurementStateChangeSource =
                  { CONTAINER: "container", CREATIVE: "creative" }),
                (module$exports$omid$common$constants.ElementMarkup = {
                  OMID_ELEMENT_CLASS_NAME: "omid-element",
                }),
                (module$exports$omid$common$constants.CommunicationType = {
                  NONE: "NONE",
                  DIRECT: "DIRECT",
                  POST_MESSAGE: "POST_MESSAGE",
                }),
                (module$exports$omid$common$constants.OmidImplementer = {
                  OMSDK: "omsdk",
                });
              var module$contents$omid$common$InternalMessage_GUID_KEY =
                  "omid_message_guid",
                module$contents$omid$common$InternalMessage_METHOD_KEY =
                  "omid_message_method",
                module$contents$omid$common$InternalMessage_VERSION_KEY =
                  "omid_message_version",
                module$contents$omid$common$InternalMessage_ARGS_KEY =
                  "omid_message_args",
                module$exports$omid$common$InternalMessage = function (
                  e,
                  o,
                  t,
                  r
                ) {
                  (this.guid = e),
                    (this.method = o),
                    (this.version = t),
                    (this.args = r);
                };
              (module$exports$omid$common$InternalMessage.isValidSerializedMessage =
                function (e) {
                  return (
                    !!e &&
                    void 0 !==
                      e[module$contents$omid$common$InternalMessage_GUID_KEY] &&
                    void 0 !==
                      e[
                        module$contents$omid$common$InternalMessage_METHOD_KEY
                      ] &&
                    void 0 !==
                      e[
                        module$contents$omid$common$InternalMessage_VERSION_KEY
                      ] &&
                    "string" ==
                      typeof e[
                        module$contents$omid$common$InternalMessage_GUID_KEY
                      ] &&
                    "string" ==
                      typeof e[
                        module$contents$omid$common$InternalMessage_METHOD_KEY
                      ] &&
                    "string" ==
                      typeof e[
                        module$contents$omid$common$InternalMessage_VERSION_KEY
                      ] &&
                    (void 0 ===
                      e[module$contents$omid$common$InternalMessage_ARGS_KEY] ||
                      void 0 !==
                        e[module$contents$omid$common$InternalMessage_ARGS_KEY])
                  );
                }),
                (module$exports$omid$common$InternalMessage.deserialize =
                  function (e) {
                    return new module$exports$omid$common$InternalMessage(
                      e[module$contents$omid$common$InternalMessage_GUID_KEY],
                      e[module$contents$omid$common$InternalMessage_METHOD_KEY],
                      e[
                        module$contents$omid$common$InternalMessage_VERSION_KEY
                      ],
                      e[module$contents$omid$common$InternalMessage_ARGS_KEY]
                    );
                  }),
                (module$exports$omid$common$InternalMessage.prototype.serialize =
                  function () {
                    var e = {};
                    return (
                      (e[module$contents$omid$common$InternalMessage_GUID_KEY] =
                        this.guid),
                      (e[
                        module$contents$omid$common$InternalMessage_METHOD_KEY
                      ] = this.method),
                      (e[
                        module$contents$omid$common$InternalMessage_VERSION_KEY
                      ] = this.version),
                      (e = e),
                      void 0 !== this.args &&
                        (e[
                          module$contents$omid$common$InternalMessage_ARGS_KEY
                        ] = this.args),
                      e
                    );
                  });
              var module$exports$omid$common$Communication = function (e) {
                (this.to = e),
                  (this.communicationType_ =
                    module$exports$omid$common$constants.CommunicationType.NONE);
              };
              (module$exports$omid$common$Communication.prototype.sendMessage =
                function (e, o) {}),
                (module$exports$omid$common$Communication.prototype.handleMessage =
                  function (e, o) {
                    this.onMessage && this.onMessage(e, o);
                  }),
                (module$exports$omid$common$Communication.prototype.serialize =
                  function (e) {
                    return JSON.stringify(e);
                  }),
                (module$exports$omid$common$Communication.prototype.deserialize =
                  function (e) {
                    return JSON.parse(e);
                  }),
                (module$exports$omid$common$Communication.prototype.isDirectCommunication =
                  function () {
                    return (
                      this.communicationType_ ===
                      module$exports$omid$common$constants.CommunicationType
                        .DIRECT
                    );
                  }),
                (module$exports$omid$common$Communication.prototype.isCrossOrigin =
                  function () {});
              var module$exports$omid$common$DetectOmid = {
                  OMID_PRESENT_FRAME_NAME: "omid_v1_present",
                  isOmidPresent: function (e) {
                    try {
                      return (
                        !!e.frames &&
                        !!e.frames[
                          module$exports$omid$common$DetectOmid
                            .OMID_PRESENT_FRAME_NAME
                        ]
                      );
                    } catch (e) {
                      return !1;
                    }
                  },
                  declareOmidPresence: function (e) {
                    e.frames &&
                      e.document &&
                      (module$exports$omid$common$DetectOmid.OMID_PRESENT_FRAME_NAME in
                        e.frames ||
                        (null == e.document.body &&
                        module$exports$omid$common$DetectOmid.isMutationObserverAvailable_(
                          e
                        )
                          ? module$exports$omid$common$DetectOmid.registerMutationObserver_(
                              e
                            )
                          : e.document.body
                          ? module$exports$omid$common$DetectOmid.appendPresenceIframe_(
                              e
                            )
                          : e.document.write(
                              '<iframe style="display:none" id="' +
                                module$exports$omid$common$DetectOmid.OMID_PRESENT_FRAME_NAME +
                                '" name="' +
                                module$exports$omid$common$DetectOmid.OMID_PRESENT_FRAME_NAME +
                                '"></iframe>'
                            )));
                  },
                  appendPresenceIframe_: function (e) {
                    var o = e.document.createElement("iframe");
                    (o.id =
                      module$exports$omid$common$DetectOmid.OMID_PRESENT_FRAME_NAME),
                      (o.name =
                        module$exports$omid$common$DetectOmid.OMID_PRESENT_FRAME_NAME),
                      (o.style.display = "none"),
                      e.document.body.appendChild(o);
                  },
                  isMutationObserverAvailable_: function (e) {
                    return "MutationObserver" in e;
                  },
                  registerMutationObserver_: function (e) {
                    var o = new MutationObserver(function (t) {
                      t.forEach(function (t) {
                        "BODY" === t.addedNodes[0].nodeName &&
                          (module$exports$omid$common$DetectOmid.appendPresenceIframe_(
                            e
                          ),
                          o.disconnect());
                      });
                    });
                    o.observe(e.document.documentElement, { childList: !0 });
                  },
                },
                module$exports$omid$common$DirectCommunication = function e(o) {
                  module$exports$omid$common$Communication.call(this, o),
                    (this.communicationType_ =
                      module$exports$omid$common$constants.CommunicationType.DIRECT),
                    (this.handleExportedMessage =
                      e.prototype.handleExportedMessage.bind(this));
                };
              $jscomp.inherits(
                module$exports$omid$common$DirectCommunication,
                module$exports$omid$common$Communication
              ),
                (module$exports$omid$common$DirectCommunication.prototype.sendMessage =
                  function (e, o) {
                    if (!(o = void 0 === o ? this.to : o))
                      throw Error(
                        "Message destination must be defined at construction time or when sending the message."
                      );
                    o.handleExportedMessage(e.serialize(), this);
                  }),
                (module$exports$omid$common$DirectCommunication.prototype.handleExportedMessage =
                  function (e, o) {
                    module$exports$omid$common$InternalMessage.isValidSerializedMessage(
                      e
                    ) &&
                      this.handleMessage(
                        module$exports$omid$common$InternalMessage.deserialize(
                          e
                        ),
                        o
                      );
                  }),
                (module$exports$omid$common$DirectCommunication.prototype.isCrossOrigin =
                  function () {
                    return !1;
                  });
              var module$exports$omid$common$eventTypedefs = {},
                module$exports$omid$common$exporter = {};
              function module$contents$omid$common$exporter_getOmidExports() {
                return void 0 === omidExports ? null : omidExports;
              }
              function module$contents$omid$common$exporter_getOrCreateName(
                e,
                o
              ) {
                return e && (e[o] || (e[o] = {}));
              }
              module$exports$omid$common$exporter.packageExport = function (
                e,
                o,
                t
              ) {
                (t =
                  void 0 === t
                    ? module$contents$omid$common$exporter_getOmidExports()
                    : t) &&
                  ((e = e.split("."))
                    .slice(0, e.length - 1)
                    .reduce(
                      module$contents$omid$common$exporter_getOrCreateName,
                      t
                    )[e[e.length - 1]] = o);
              };
              var module$exports$omid$common$guid = {
                  generateGuid: function () {
                    return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(
                      /[xy]/g,
                      function (e) {
                        var o = (16 * Math.random()) | 0;
                        return "y" === e
                          ? ((3 & o) | 8).toString(16)
                          : o.toString(16);
                      }
                    );
                  },
                },
                module$exports$omid$common$logger = {
                  error: function (e) {
                    for (var o = [], t = 0; t < arguments.length; ++t)
                      o[t - 0] = arguments[t];
                    module$contents$omid$common$logger_executeLog(
                      function () {
                        throw new (Function.prototype.bind.apply(
                          Error,
                          [
                            null,
                            "Could not complete the test successfully - ",
                          ].concat($jscomp.arrayFromIterable(o))
                        ))();
                      },
                      function () {}
                    );
                  },
                  debug: function (e) {
                    for (var o = [], t = 0; t < arguments.length; ++t)
                      o[t - 0] = arguments[t];
                    module$contents$omid$common$logger_executeLog(
                      function () {},
                      function () {}
                    );
                  },
                };
              function module$contents$omid$common$logger_executeLog(e, o) {
                "undefined" != typeof jasmine && jasmine
                  ? e()
                  : "undefined" != typeof console &&
                    console &&
                    console.error &&
                    o();
              }
              var module$exports$omid$common$OmidGlobalProvider = {},
                module$contents$omid$common$OmidGlobalProvider_globalThis =
                  eval("this");
              function module$contents$omid$common$OmidGlobalProvider_getOmidGlobal() {
                if (void 0 !== omidGlobal && omidGlobal) return omidGlobal;
                if (void 0 !== global && global) return global;
                if ("undefined" != typeof window && window) return window;
                if (
                  void 0 !==
                    module$contents$omid$common$OmidGlobalProvider_globalThis &&
                  module$contents$omid$common$OmidGlobalProvider_globalThis
                )
                  return module$contents$omid$common$OmidGlobalProvider_globalThis;
                throw Error("Could not determine global object context.");
              }
              module$exports$omid$common$OmidGlobalProvider.omidGlobal =
                module$contents$omid$common$OmidGlobalProvider_getOmidGlobal();
              var module$exports$omid$common$windowUtils = {};
              function module$contents$omid$common$windowUtils_isValidWindow(
                e
              ) {
                return null != e && void 0 !== e.top && null != e.top;
              }
              function module$contents$omid$common$windowUtils_isSameOriginForIE(
                e
              ) {
                return "" === e.x || "" !== e.x;
              }
              (module$exports$omid$common$windowUtils.isCrossOrigin = function (
                e
              ) {
                if (
                  e === module$exports$omid$common$OmidGlobalProvider.omidGlobal
                )
                  return !1;
                try {
                  if (void 0 === e.location.hostname) return !0;
                  module$contents$omid$common$windowUtils_isSameOriginForIE(e);
                } catch (e) {
                  return !0;
                }
                return !1;
              }),
                (module$exports$omid$common$windowUtils.resolveGlobalContext =
                  function (e) {
                    return (
                      void 0 === e &&
                        "undefined" != typeof window &&
                        window &&
                        (e = window),
                      module$contents$omid$common$windowUtils_isValidWindow(e)
                        ? e
                        : module$exports$omid$common$OmidGlobalProvider.omidGlobal
                    );
                  }),
                (module$exports$omid$common$windowUtils.resolveTopWindowContext =
                  function (e) {
                    return module$contents$omid$common$windowUtils_isValidWindow(
                      e
                    )
                      ? e.top
                      : module$exports$omid$common$OmidGlobalProvider.omidGlobal;
                  }),
                (module$exports$omid$common$windowUtils.evaluatePageUrl =
                  function (e) {
                    if (
                      !module$contents$omid$common$windowUtils_isValidWindow(e)
                    )
                      return null;
                    try {
                      var o = e.top;
                      return (0,
                      module$exports$omid$common$windowUtils.isCrossOrigin)(o)
                        ? null
                        : o.location.href;
                    } catch (e) {
                      return null;
                    }
                  });
              var module$exports$omid$common$PostMessageCommunication =
                function (e, o) {
                  (o =
                    void 0 === o
                      ? module$exports$omid$common$OmidGlobalProvider.omidGlobal
                      : o),
                    module$exports$omid$common$Communication.call(this, o);
                  var t = this;
                  (this.communicationType_ =
                    module$exports$omid$common$constants.CommunicationType.POST_MESSAGE),
                    e.addEventListener("message", function (e) {
                      if ("object" === _typeof(e.data)) {
                        var o = e.data;
                        module$exports$omid$common$InternalMessage.isValidSerializedMessage(
                          o
                        ) &&
                          ((o =
                            module$exports$omid$common$InternalMessage.deserialize(
                              o
                            )),
                          e.source && t.handleMessage(o, e.source));
                      }
                    });
                };
              $jscomp.inherits(
                module$exports$omid$common$PostMessageCommunication,
                module$exports$omid$common$Communication
              ),
                (module$exports$omid$common$PostMessageCommunication.isCompatibleContext =
                  function (e) {
                    return !!(e && e.addEventListener && e.postMessage);
                  }),
                (module$exports$omid$common$PostMessageCommunication.prototype.sendMessage =
                  function (e, o) {
                    if (!(o = void 0 === o ? this.to : o))
                      throw Error(
                        "Message destination must be defined at construction time or when sending the message."
                      );
                    o.postMessage(e.serialize(), "*");
                  }),
                (module$exports$omid$common$PostMessageCommunication.prototype.isCrossOrigin =
                  function () {
                    return (
                      !this.to ||
                      (0, module$exports$omid$common$windowUtils.isCrossOrigin)(
                        this.to
                      )
                    );
                  });
              var module$exports$omid$common$Rectangle = function (e, o, t, r) {
                  (this.x = e),
                    (this.y = o),
                    (this.width = t),
                    (this.height = r);
                },
                module$exports$omid$common$serviceCommunication = {},
                module$contents$omid$common$serviceCommunication_EXPORTED_SESSION_COMMUNICATION_NAME =
                  ["omid", "v1_SessionServiceCommunication"],
                module$contents$omid$common$serviceCommunication_EXPORTED_VERIFICATION_COMMUNICATION_NAME =
                  ["omid", "v1_VerificationServiceCommunication"],
                module$contents$omid$common$serviceCommunication_EXPORTED_SERVICE_WINDOW_NAME =
                  ["omidVerificationProperties", "serviceWindow"];
              function module$contents$omid$common$serviceCommunication_getValueForKeypath(
                e,
                o
              ) {
                return o.reduce(function (e, o) {
                  return e && e[o];
                }, e);
              }
              function module$contents$omid$common$serviceCommunication_startServiceCommunication(
                e,
                o,
                t,
                r
              ) {
                if (
                  !(0, module$exports$omid$common$windowUtils.isCrossOrigin)(o)
                )
                  try {
                    var n =
                      module$contents$omid$common$serviceCommunication_getValueForKeypath(
                        o,
                        t
                      );
                    if (n)
                      return new module$exports$omid$common$DirectCommunication(
                        n
                      );
                  } catch (e) {}
                return r(o)
                  ? new module$exports$omid$common$PostMessageCommunication(
                      e,
                      o
                    )
                  : null;
              }
              function module$contents$omid$common$serviceCommunication_startServiceCommunicationFromCandidates(
                e,
                o,
                t,
                r
              ) {
                for (
                  var n = (o = $jscomp.makeIterator(o)).next();
                  !n.done;
                  n = o.next()
                )
                  if (
                    (n =
                      module$contents$omid$common$serviceCommunication_startServiceCommunication(
                        e,
                        n.value,
                        t,
                        r
                      ))
                  )
                    return n;
                return null;
              }
              (module$exports$omid$common$serviceCommunication.startSessionServiceCommunication =
                function (e, o, t) {
                  t =
                    void 0 === t
                      ? module$exports$omid$common$DetectOmid.isOmidPresent
                      : t;
                  var r = [
                    e,
                    (0,
                    module$exports$omid$common$windowUtils.resolveTopWindowContext)(
                      e
                    ),
                  ];
                  return (
                    o && r.unshift(o),
                    module$contents$omid$common$serviceCommunication_startServiceCommunicationFromCandidates(
                      e,
                      r,
                      module$contents$omid$common$serviceCommunication_EXPORTED_SESSION_COMMUNICATION_NAME,
                      t
                    )
                  );
                }),
                (module$exports$omid$common$serviceCommunication.startVerificationServiceCommunication =
                  function (e, o) {
                    o =
                      void 0 === o
                        ? module$exports$omid$common$DetectOmid.isOmidPresent
                        : o;
                    var t = [],
                      r =
                        module$contents$omid$common$serviceCommunication_getValueForKeypath(
                          e,
                          module$contents$omid$common$serviceCommunication_EXPORTED_SERVICE_WINDOW_NAME
                        );
                    return (
                      r && t.push(r),
                      t.push(
                        (0,
                        module$exports$omid$common$windowUtils.resolveTopWindowContext)(
                          e
                        )
                      ),
                      module$contents$omid$common$serviceCommunication_startServiceCommunicationFromCandidates(
                        e,
                        t,
                        module$contents$omid$common$serviceCommunication_EXPORTED_VERIFICATION_COMMUNICATION_NAME,
                        o
                      )
                    );
                  });
              var module$exports$omid$common$VastProperties = function (
                e,
                o,
                t,
                r
              ) {
                (this.isSkippable = e),
                  (this.skipOffset = o),
                  (this.isAutoPlay = t),
                  (this.position = r);
              };
              module$exports$omid$common$VastProperties.prototype.toJSON =
                function () {
                  return {
                    isSkippable: this.isSkippable,
                    skipOffset: this.skipOffset,
                    isAutoPlay: this.isAutoPlay,
                    position: this.position,
                  };
                };
              var module$exports$omid$common$version = {
                  ApiVersion: "1.0",
                  Version: "1.3.2",
                },
                module$contents$omid$verificationClient$VerificationClient_VERIFICATION_CLIENT_VERSION =
                  module$exports$omid$common$version.Version,
                module$contents$omid$verificationClient$VerificationClient_EventCallback;
              function module$contents$omid$verificationClient$VerificationClient_getThirdPartyOmid() {
                var e =
                  module$exports$omid$common$OmidGlobalProvider.omidGlobal
                    .omid3p;
                return e &&
                  "function" == typeof e.registerSessionObserver &&
                  "function" == typeof e.addEventListener
                  ? e
                  : null;
              }
              var module$exports$omid$verificationClient$VerificationClient =
                function (e) {
                  (this.communication =
                    e ||
                    (0,
                    module$exports$omid$common$serviceCommunication.startVerificationServiceCommunication)(
                      (0,
                      module$exports$omid$common$windowUtils.resolveGlobalContext)()
                    ))
                    ? (this.communication.onMessage =
                        this.handleMessage_.bind(this))
                    : (e =
                        module$contents$omid$verificationClient$VerificationClient_getThirdPartyOmid()) &&
                      (this.omid3p = e),
                    (this.remoteIntervals_ = this.remoteTimeouts_ = 0),
                    (this.callbackMap_ = {}),
                    (this.imgCache_ = []),
                    (this.injectionId_ = (e =
                      module$exports$omid$common$OmidGlobalProvider.omidGlobal
                        .omidVerificationProperties)
                      ? e.injectionId
                      : void 0);
                };
              (module$exports$omid$verificationClient$VerificationClient.prototype.isSupported =
                function () {
                  return !(!this.communication && !this.omid3p);
                }),
                (module$exports$omid$verificationClient$VerificationClient.prototype.registerSessionObserver =
                  function (e, o) {
                    (0, module$exports$omid$common$argsChecker.assertFunction)(
                      "functionToExecute",
                      e
                    ),
                      this.omid3p
                        ? this.omid3p.registerSessionObserver(
                            e,
                            o,
                            this.injectionId_
                          )
                        : this.sendMessage_(
                            "addSessionListener",
                            e,
                            o,
                            this.injectionId_
                          );
                  }),
                (module$exports$omid$verificationClient$VerificationClient.prototype.addEventListener =
                  function (e, o) {
                    (0,
                    module$exports$omid$common$argsChecker.assertTruthyString)(
                      "eventType",
                      e
                    ),
                      (0,
                      module$exports$omid$common$argsChecker.assertFunction)(
                        "functionToExecute",
                        o
                      ),
                      this.omid3p
                        ? this.omid3p.addEventListener(e, o)
                        : this.sendMessage_("addEventListener", o, e);
                  }),
                (module$exports$omid$verificationClient$VerificationClient.prototype.sendUrl =
                  function (e, o, t) {
                    (0,
                    module$exports$omid$common$argsChecker.assertTruthyString)(
                      "url",
                      e
                    ),
                      module$exports$omid$common$OmidGlobalProvider.omidGlobal
                        .document &&
                      module$exports$omid$common$OmidGlobalProvider.omidGlobal
                        .document.createElement
                        ? this.sendUrlWithImg_(e, o, t)
                        : this.sendMessage_(
                            "sendUrl",
                            function (e) {
                              e && o ? o() : !e && t && t();
                            },
                            e
                          );
                  }),
                (module$exports$omid$verificationClient$VerificationClient.prototype.sendUrlWithImg_ =
                  function (e, o, t) {
                    var r = this,
                      n =
                        module$exports$omid$common$OmidGlobalProvider.omidGlobal.document.createElement(
                          "img"
                        );
                    function i(e) {
                      var o = r.imgCache_.indexOf(n);
                      0 <= o && r.imgCache_.splice(o, 1), e && e();
                    }
                    this.imgCache_.push(n),
                      n.addEventListener("load", i.bind(this, o)),
                      n.addEventListener("error", i.bind(this, t)),
                      (n.src = e);
                  }),
                (module$exports$omid$verificationClient$VerificationClient.prototype.injectJavaScriptResource =
                  function (e, o, t) {
                    var r = this;
                    (0,
                    module$exports$omid$common$argsChecker.assertTruthyString)(
                      "url",
                      e
                    ),
                      module$exports$omid$common$OmidGlobalProvider.omidGlobal
                        .document
                        ? this.injectJavascriptResourceUrlInDom_(e, o, t)
                        : this.sendMessage_(
                            "injectJavaScriptResource",
                            function (n, i) {
                              n
                                ? (r.evaluateJavaScript_(i, e), o())
                                : (module$exports$omid$common$logger.error(
                                    "Service failed to load JavaScript resource."
                                  ),
                                  t());
                            },
                            e
                          );
                  }),
                (module$exports$omid$verificationClient$VerificationClient.prototype.injectJavascriptResourceUrlInDom_ =
                  function (e, o, t) {
                    var r =
                        module$exports$omid$common$OmidGlobalProvider.omidGlobal
                          .document,
                      n = r.body;
                    ((r = r.createElement("script")).onload = o),
                      (r.onerror = t),
                      (r.src = e),
                      (r.type = "application/javascript"),
                      n.appendChild(r);
                  }),
                (module$exports$omid$verificationClient$VerificationClient.prototype.evaluateJavaScript_ =
                  function (a, b) {
                    try {
                      eval(a);
                    } catch (e) {
                      module$exports$omid$common$logger.error(
                        'Error evaluating the JavaScript resource from "' +
                          b +
                          '".'
                      );
                    }
                  }),
                (module$exports$omid$verificationClient$VerificationClient.prototype.setTimeout =
                  function (e, o) {
                    if (
                      ((0,
                      module$exports$omid$common$argsChecker.assertFunction)(
                        "functionToExecute",
                        e
                      ),
                      (0,
                      module$exports$omid$common$argsChecker.assertPositiveNumber)(
                        "timeInMillis",
                        o
                      ),
                      this.hasTimeoutMethods_())
                    )
                      return module$exports$omid$common$OmidGlobalProvider.omidGlobal.setTimeout(
                        e,
                        o
                      );
                    var t = this.remoteTimeouts_++;
                    return this.sendMessage_("setTimeout", e, t, o), t;
                  }),
                (module$exports$omid$verificationClient$VerificationClient.prototype.clearTimeout =
                  function (e) {
                    (0,
                    module$exports$omid$common$argsChecker.assertPositiveNumber)(
                      "timeoutId",
                      e
                    ),
                      this.hasTimeoutMethods_()
                        ? module$exports$omid$common$OmidGlobalProvider.omidGlobal.clearTimeout(
                            e
                          )
                        : this.sendOneWayMessage_("clearTimeout", e);
                  }),
                (module$exports$omid$verificationClient$VerificationClient.prototype.setInterval =
                  function (e, o) {
                    if (
                      ((0,
                      module$exports$omid$common$argsChecker.assertFunction)(
                        "functionToExecute",
                        e
                      ),
                      (0,
                      module$exports$omid$common$argsChecker.assertPositiveNumber)(
                        "timeInMillis",
                        o
                      ),
                      this.hasIntervalMethods_())
                    )
                      return module$exports$omid$common$OmidGlobalProvider.omidGlobal.setInterval(
                        e,
                        o
                      );
                    var t = this.remoteIntervals_++;
                    return this.sendMessage_("setInterval", e, t, o), t;
                  }),
                (module$exports$omid$verificationClient$VerificationClient.prototype.clearInterval =
                  function (e) {
                    (0,
                    module$exports$omid$common$argsChecker.assertPositiveNumber)(
                      "intervalId",
                      e
                    ),
                      this.hasIntervalMethods_()
                        ? module$exports$omid$common$OmidGlobalProvider.omidGlobal.clearInterval(
                            e
                          )
                        : this.sendOneWayMessage_("clearInterval", e);
                  }),
                (module$exports$omid$verificationClient$VerificationClient.prototype.hasTimeoutMethods_ =
                  function () {
                    return (
                      "function" ==
                        typeof module$exports$omid$common$OmidGlobalProvider
                          .omidGlobal.setTimeout &&
                      "function" ==
                        typeof module$exports$omid$common$OmidGlobalProvider
                          .omidGlobal.clearTimeout
                    );
                  }),
                (module$exports$omid$verificationClient$VerificationClient.prototype.hasIntervalMethods_ =
                  function () {
                    return (
                      "function" ==
                        typeof module$exports$omid$common$OmidGlobalProvider
                          .omidGlobal.setInterval &&
                      "function" ==
                        typeof module$exports$omid$common$OmidGlobalProvider
                          .omidGlobal.clearInterval
                    );
                  }),
                (module$exports$omid$verificationClient$VerificationClient.prototype.handleMessage_ =
                  function (e, o) {
                    o = e.method;
                    var t = e.guid;
                    if (
                      ((e = e.args), "response" === o && this.callbackMap_[t])
                    ) {
                      var r = (0,
                      module$exports$omid$common$ArgsSerDe.deserializeMessageArgs)(
                        module$contents$omid$verificationClient$VerificationClient_VERIFICATION_CLIENT_VERSION,
                        e
                      );
                      this.callbackMap_[t].apply(this, r);
                    }
                    "error" === o &&
                      window.console &&
                      module$exports$omid$common$logger.error(e);
                  }),
                (module$exports$omid$verificationClient$VerificationClient.prototype.sendOneWayMessage_ =
                  function (e, o) {
                    for (var t = [], r = 1; r < arguments.length; ++r)
                      t[r - 1] = arguments[r];
                    this.sendMessage_.apply(
                      this,
                      [e, null].concat($jscomp.arrayFromIterable(t))
                    );
                  }),
                (module$exports$omid$verificationClient$VerificationClient.prototype.sendMessage_ =
                  function (e, o, t) {
                    for (var r = [], n = 2; n < arguments.length; ++n)
                      r[n - 2] = arguments[n];
                    this.communication &&
                      ((n = (0,
                      module$exports$omid$common$guid.generateGuid)()),
                      o && (this.callbackMap_[n] = o),
                      (r = new module$exports$omid$common$InternalMessage(
                        n,
                        "VerificationService." + e,
                        module$contents$omid$verificationClient$VerificationClient_VERIFICATION_CLIENT_VERSION,
                        (0,
                        module$exports$omid$common$ArgsSerDe.serializeMessageArgs)(
                          module$contents$omid$verificationClient$VerificationClient_VERIFICATION_CLIENT_VERSION,
                          r
                        )
                      )),
                      this.communication.sendMessage(r));
                  }),
                (0, module$exports$omid$common$exporter.packageExport)(
                  "OmidVerificationClient",
                  module$exports$omid$verificationClient$VerificationClient
                );
            }),
            (al = exports),
            "object" === (void 0 === al ? "undefined" : _typeof(al)) &&
            "string" != typeof al.nodeName
              ? _k($k, al)
              : (function () {
                  function e(o) {
                    for (var t in o) o.hasOwnProperty(t) && (o[t] = e(o[t]));
                    return Object.freeze(o);
                  }
                  for (dl in ((bl = ["1.3.2"]), _k($k, (al = {})), al))
                    al.hasOwnProperty(dl) &&
                      (null == Object.getOwnPropertyDescriptor($k, dl) &&
                        Object.defineProperty($k, dl, { value: {} }),
                      bl.forEach(function (o) {
                        if (
                          null == Object.getOwnPropertyDescriptor($k[dl], o)
                        ) {
                          var t = e(al[dl]);
                          Object.defineProperty($k[dl], o, {
                            get: function () {
                              return t;
                            },
                            enumerable: !0,
                          });
                        }
                      }));
                })();
        }.call(this, __webpack_require__(28)));
      },
      function (e, o, t) {
        "use strict";
        var r,
          n =
            "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
              ? function (e) {
                  return typeof e;
                }
              : function (e) {
                  return e &&
                    "function" == typeof Symbol &&
                    e.constructor === Symbol &&
                    e !== Symbol.prototype
                    ? "symbol"
                    : typeof e;
                };
        r = (function () {
          return this;
        })();
        try {
          r = r || new Function("return this")();
        } catch (e) {
          "object" ===
            ("undefined" == typeof window ? "undefined" : n(window)) &&
            (r = window);
        }
        e.exports = r;
      },
      function (e, o, t) {
        "use strict";
        Object.defineProperty(o, "__esModule", { value: !0 }),
          (o.getCombinedTenantBasedOnSupply = void 0);
        var r = t(2),
          n = t(13);
        o.getCombinedTenantBasedOnSupply = function (e) {
          var o, t;
          return (
            (o = (0, n.getSourceIdFromLoggingParameters)(e)),
            (t = (0, n.getSourceTypeFromLoggingParameters)(e)),
            -1 !== r.SOURCE_IDS.TWITCH_SOURCE_IDS.indexOf(o)
              ? r.COMBINED_TENANTS.forensicsTwitchEvent
              : -1 !== r.SOURCE_IDS.IMDB_SOURCE_IDS.indexOf(o)
              ? r.COMBINED_TENANTS.forensicsImdbEvent
              : r.SOURCE_TYPE.APS_SOURCE_TYPE === t
              ? r.COMBINED_TENANTS.forensics3PEvent
              : r.SOURCE_TYPE._3PX_SOURCE_TYPE === t
              ? r.COMBINED_TENANTS.forensics3PEvent
              : r.COMBINED_TENANTS.forensicsDefaultEvent
          );
        };
      },
      function (e, o, t) {
        "use strict";
        Object.defineProperty(o, "__esModule", { value: !0 }),
          (o.getVFRDBasedOnSupplyFromLoggingParameters = void 0);
        var r = t(2),
          n = t(13);
        o.getVFRDBasedOnSupplyFromLoggingParameters = function (e) {
          var o, t;
          return (
            (o = (0, n.getSourceIdFromLoggingParameters)(e)),
            (t = (0, n.getSourceTypeFromLoggingParameters)(e)),
            -1 !== r.SOURCE_IDS.TWITCH_SOURCE_IDS.indexOf(o)
              ? r.VFRD_CODES.TWITCH_VFRD_CODE
              : -1 !== r.SOURCE_IDS.IMDB_SOURCE_IDS.indexOf(o)
              ? r.VFRD_CODES.IMDB_VFRD_CODE
              : r.SOURCE_TYPE._3PX_SOURCE_TYPE === t
              ? r.VFRD_CODES._3PX_VFRD_CODE
              : r.SOURCE_TYPE.APS_SOURCE_TYPE === t
              ? r.VFRD_CODES.APS_VFRD_CODE
              : r.VFRD_CODES.DEFAULT_VFRD_CODE
          );
        };
      },
    ]),
    (i = {}),
    (j.m = h),
    (j.c = i),
    (j.d = function (e, o, t) {
      j.o(e, o) || Object.defineProperty(e, o, { enumerable: !0, get: t });
    }),
    (j.r = function (e) {
      "undefined" != typeof Symbol &&
        Symbol.toStringTag &&
        Object.defineProperty(e, Symbol.toStringTag, { value: "Module" }),
        Object.defineProperty(e, "__esModule", { value: !0 });
    }),
    (j.t = function (e, o) {
      if ((1 & o && (e = j(e)), 8 & o)) return e;
      if (4 & o && "object" == typeof e && e && e.__esModule) return e;
      var t = Object.create(null);
      if (
        (j.r(t),
        Object.defineProperty(t, "default", { enumerable: !0, value: e }),
        2 & o && "string" != typeof e)
      )
        for (var r in e)
          j.d(
            t,
            r,
            function (o) {
              return e[o];
            }.bind(null, r)
          );
      return t;
    }),
    (j.n = function (e) {
      var o =
        e && e.__esModule
          ? function () {
              return e.default;
            }
          : function () {
              return e;
            };
      return j.d(o, "a", o), o;
    }),
    (j.o = function (e, o) {
      return Object.prototype.hasOwnProperty.call(e, o);
    }),
    (j.p = ""),
    j((j.s = 25))
  );
  function j(e) {
    if (i[e]) return i[e].exports;
    var o = (i[e] = { i: e, l: !1, exports: {} });
    return h[e].call(o.exports, o, o.exports, j), (o.l = !0), o.exports;
  }
  var h, i;
});
