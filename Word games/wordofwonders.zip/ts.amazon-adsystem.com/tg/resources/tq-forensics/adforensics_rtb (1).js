var amzntqcsm;
((amzntqcsm = amzntqcsm || {}).errorCodes = {
  SLOT_INSIDE_UNFRIENDLY_FRAME: 1,
  UNSUPPORTED_BROWSER: 2,
  ERROR_SENDING_PIXEL: 3,
  INVALID_API: 4,
  MALFORMED_URL: 5,
}),
  (amzntqcsm.PST_ERROR_CODE = {
    UNSUPPORTED_FEATURE_POLICY: "UNSUPPORTED_FEATURE_POLICY",
    FEATURE_POLICY_EXCEPTION: "FEATURE_POLICY_EXCEPTION",
    TOKEN_NOT_PRESENT: "TOKEN_NOT_PRESENT",
    TUNGSTEN_LOGGING_ERROR: "TUNGSTEN_LOGGING_ERROR",
    HAS_RR_API_FAILURE: "HAS_RR_API_FAILURE",
    HAS_TOKEN_API_FAILURE: "HAS_TOKEN_API_FAILURE",
    TRS_RESPONSE_STATUS_NOT_200: "TRS_RESPONSE_STATUS_NOT_200",
    REDEMPTION_ERROR: "REDEMPTION_ERROR",
    SEND_RR_PAYLOAD_ERROR: "SEND_RR_PAYLOAD_ERROR",
  }),
  (amzntqcsm.errors = []),
  (amzntqcsm.errorMessages = []),
  (amzntqcsm.exceptions = {}),
  (amzntqcsm.reportErrors = function (t) {
    for (var n = 0; n < amzntqcsm.errors.length; n++)
      if (-1 === amzntqcsm.errorMessages.indexOf(amzntqcsm.errors[n])) {
        amzntqcsm.errorMessages.push(amzntqcsm.errors[n]);
        var e =
          '{"adViewability":[{"error": {"m": "' +
          amzntqcsm.errors[n] +
          '"}}], "c": "viewability", "api": "' +
          amzntqcsm.api +
          '", "error": 1}';
        amzntqcsm.sendPixel(t, e, "");
      }
    (amzntqcsm.errors = []),
      amzntqcsm.detachAllHandlers && amzntqcsm.detachAllHandlers();
  }),
  (amzntqcsm.sendPixel = function (t, n, e) {
    (n = n.replaceAll("%", "<per>")), (n = encodeURIComponent(n));
    var r = "?";
    void 0 !== e && "" !== e ? (t += e) : ((t += "?p="), (r = "&")),
      (new Image().src = t + n + r + "cb=" + Math.round(1e7 * Math.random()));
  }),
  (function () {
    var d = /\(?([^\s]*):(\d+):\d+\)?/,
      g = /.*@(.*):(\d*)/;
    function l(t, n) {
      try {
        return t[n];
      } catch (t) {
        return "";
      }
    }
    amzntqcsm.constructErrorMessage = function (t, n) {
      if (((n = n || {}), !t)) return {};
      t.m && t.m.message && (t = t.m);
      var e,
        r,
        a,
        s,
        m,
        o,
        i = {
          m: (function (t, n) {
            var e = n.m || n.message || "";
            t.m && t.m.message
              ? (e += t.m.message)
              : t.m && t.m.target && t.m.target.tagName
              ? (e += "Error handler invoked by " + t.m.target.tagName + " tag")
              : t.m
              ? (e += t.m)
              : t.message
              ? (e += t.message)
              : (e += "Unknown error");
            return e;
          })(t, n),
          c: t.c ? "" + t.c : t.c,
          s: [],
          l: t.l || t.line || t.lineno || t.lineNumber,
          name: t.name,
          type: t.type,
        },
        c = 0,
        u = 0;
      if ((e = t.stack || (t.err ? t.err.stack : "")) && e.split)
        for (r = e.split("\n"); c < r.length && i.s.length < 20; )
          (a = r[c++]) &&
            i.s.unshift((o = a) ? o.replace(/^\s+|\s+$/g, "") : o);
      else
        for (s = l(t.args || arguments, "callee"), u = c = 0; s && c < 20; )
          (m = 256),
            s.skipTrace ||
              ((a = s.toString()) &&
                a.substr &&
                ((m = 0 === u ? 1024 : m),
                (m = 1 === u ? 512 : m),
                i.s.unshift(a.substr(0, m)),
                u++)),
            (s = l(s, "caller")),
            c++;
      return (
        !i.f &&
          0 < i.s.length &&
          (function (t) {
            if (t && t.s) {
              var n,
                e = 0 < t.s.length ? t.s[0] : "",
                r = 1 < t.s.length ? t.s[1] : "";
              e && (n = e.match(g)),
                (n && 3 === n.length) || !r || (n = r.match(d)),
                n && 3 === n.length && ((t.f = n[1]), (t.l = n[2]));
            }
          })(i),
        i
      );
    };
  })(),
  (amzntqcsm.exceptions.invalidModuleException = function (t) {
    (this.value = t),
      (this.message = "does not conform to the expected format of a module"),
      (this.toString = function () {
        return this.value + this.message;
      });
  }),
  (amzntqcsm.exceptions.invalidStringException = function (t) {
    (this.value = t),
      (this.message = "should be a string. Pixel Queue expects a string."),
      (this.toString = function () {
        return this.value + this.message;
      });
  }),
  (amzntqcsm.getModules = function (t, n) {
    return {
      utils: { default: !0, params: [], global: !0 },
      pixelQueue: { default: !0, params: [n] },
      privateStateToken: { params: [] },
    };
  }),
  (amzntqcsm.log = function (t) {
    try {
      -1 !== window.location.href.indexOf("csm_debug_mode") &&
        window.console &&
        window.console.log(t);
    } catch (t) {
      t.message && amzntqcsm.errors.push(t.message);
    }
  }),
  (amzntqcsm.loadModules = function (t, n) {
    try {
      for (var e = 0; e < n.length; e++) {
        var r = n[e].name,
          a = n[e].params || [];
        if (
          (window.performance &&
            window.performance.mark &&
            "function" == typeof window.performance.mark &&
            window.performance.mark("loadStart" + r + t),
          "[object Array]" !== Object.prototype.toString.call(a) &&
            amzntqcsm.log(
              "Params passed in the amzntqcsm.loadModules methods must be an array"
            ),
          amzntqcsm[r])
        ) {
          if (void 0 === amzntqcsm[r].shortName)
            throw new amzntqcsm.exceptions.invalidModuleException(
              "Module shortName not defined for module " + r + ". "
            );
          a.unshift(t),
            amzntqcsm[r].init.apply(amzntqcsm[r], a),
            amzntqcsm.log("Initiated " + r + " module"),
            window.performance &&
              window.performance.mark &&
              "function" == typeof window.performance.mark &&
              (window.performance.mark("loadEnd" + r + t),
              window.performance.measure(
                "lt" + amzntqcsm[r].shortName + t,
                "loadStart" + r + t,
                "loadEnd" + r + t
              ));
        } else amzntqcsm.log("Undefined module " + r);
      }
    } catch (t) {
      t.message && amzntqcsm.errors.push(t.message);
    }
  }),
  (amzntqcsm.define = function (t) {
    try {
      for (
        var n = Array.prototype.slice.call(arguments),
          e = n[0],
          r = 2 < n.length ? n[1] : [],
          a = n[n.length - 1],
          s = [],
          m = 0,
          o = r.length;
        m < o;
        m++
      )
        s.push("string" == typeof (i = r[m]) ? amzntqcsm[i] : i);
      amzntqcsm[e] = a.apply(a, s);
    } catch (t) {
      t.message && amzntqcsm.errors.push(t.message);
    }
    var i;
  }),
  amzntqcsm.define("utils", [], function () {
    var t,
      s = { shortName: "ut" };
    return (
      (s.init = function (t) {
        amzntqcsm.log("Initializing utils for " + t);
      }),
      (s.getPixelID =
        ((t = null),
        function () {
          return null === t && (t = Math.random().toString(36).substr(2)), t;
        })),
      (s.detachAllHandlers = function () {
        for (var t, n = 0; n < amzntqcsm.eventHandlers.length; n++)
          (t = amzntqcsm.eventHandlers[n]),
            amzntqcsm.removeEvent(t.elem, t.eventName, t.cb);
      }),
      (s.reportClientError = function (t) {
        var n =
            t === parseInt(t, 10)
              ? '{"m": "' + t + '"}'
              : JSON.stringify(amzntqcsm.constructErrorMessage(t)),
          e = amzntqcsm.instrURL,
          r =
            '{"adViewability":[{"error": ' +
            n +
            '}], "c": "viewability", "api": "' +
            amzntqcsm.api +
            '", "error": 1}';
        amzntqcsm.log("ERROR " + n),
          -1 === amzntqcsm.errorMessages.indexOf(n) &&
            (amzntqcsm.errorMessages.push(n),
            amzntqcsm.scrollImitationTimer &&
              clearInterval(amzntqcsm.scrollImitationTimer),
            amzntqcsm.isV6
              ? amzntqcsm.sendPixel(e, r, "")
              : (new Image().src =
                  e + r + "?cb=" + Math.round(1e7 * Math.random())));
      }),
      (s.isPSTTenant = function (t) {
        return (
          t === amzntqcsm.tungstenTenants.pstErrorLoggingEvent ||
          t === amzntqcsm.tungstenTenants.pstRRLoggingEvent
        );
      }),
      (s.getTungstenCSMLoggingFrameworkBaseUrl = function (t) {
        var n = t.indexOf("/");
        return 0 < n ? t.substring(0, n) : t;
      }),
      (s.getTungstenLoggingHost = function (t, n) {
        return s.isPSTTenant(n) ? "www.btd-cmh.tq-tungsten.com/log/" : t;
      }),
      (s.setTimeout = function (t, n) {
        return setTimeout(function () {
          try {
            t.call();
          } catch (t) {
            t.message && amzntqcsm.log("Error: " + t.message),
              s.reportClientError(t);
          }
        }, n);
      }),
      (s.setInterval = function (t, n) {
        return setInterval(function () {
          try {
            t.call();
          } catch (t) {
            t.message && amzntqcsm.log("Error: " + t.message),
              s.reportClientError(t);
          }
        }, n);
      }),
      (s.encr = function (t) {
        if (null == t || "" == t || null == t) return t;
        var n,
          e,
          r = "",
          a = "",
          s = t.length,
          m = Math.floor(s / 2);
        for (n = 0, e = m; n < m && e < s; n++, e++)
          r += t.charAt(n) + t.charAt(e);
        for (s % 2 == 1 && (r += t.charAt(t.length - 1)), n = 0; n < s; n++)
          a += String.fromCharCode(r.charCodeAt(n) + (r.charCodeAt(n) % 5));
        return encodeURIComponent(a);
      }),
      (s.postRequest = function (n, t, e, r) {
        var a = new Headers({ "Content-Type": "application/json" }),
          s = r || {
            cache: "no-cache",
            method: "POST",
            body: JSON.stringify(t),
            headers: a,
          };
        fetch(n, s)
          .then(function (t) {
            if (200 !== t.status)
              throw new Error("Received " + t.status + " for " + n);
          })
          .catch(function (t) {
            e && e(t);
          });
      }),
      (s.logToTungsten = function (t, n, e) {
        try {
          if (!amzntqcsm.tungstenCSMLoggingFrameworkUrl) return;
          if (!amzntqcsm.bidId) throw new Error("bidId is not set");
          var r = s.getTungstenLoggingHost(
              amzntqcsm.tungstenCSMLoggingFrameworkUrl,
              n
            ),
            a = r.startsWith("http") ? "" : "https://";
          amzntqcsm.postRequest(
            a + r + n,
            t,
            function (t) {
              amzntqcsm.reportErrorToTungsten(t, n);
            },
            e
          );
        } catch (t) {
          amzntqcsm.reportErrorToTungsten(t, n);
        }
      }),
      (s.reportErrorToTungsten = function (t, n) {
        try {
          s.isPSTTenant(n) &&
            (n = amzntqcsm.tungstenTenants.pstErrorLoggingEvent);
          var e = amzntqcsm.createErrorPayloadForTenant(t, n);
          if (!amzntqcsm.tungstenCSMLoggingFrameworkUrl) return;
          var r = s.getTungstenLoggingHost(
              amzntqcsm.tungstenCSMLoggingFrameworkUrl,
              n
            ),
            a = r.startsWith("http") ? "" : "https://";
          amzntqcsm.postRequest(a + r + n, e, function (t) {
            amzntqcsm.reportClientError(t);
          });
        } catch (t) {
          amzntqcsm.reportClientError(t);
        }
      }),
      (s.createErrorPayloadForTenant = function (t, n) {
        var e = {};
        switch (n) {
          case "pstErrorLoggingEvent":
            var r =
              t === parseInt(t, 10)
                ? { m: "' + ex + '" }
                : amzntqcsm.constructErrorMessage(t);
            e = [
              {
                bidId: amzntqcsm.bidId || "",
                timeStamp: Date.now(),
                failureFunction:
                  amzntqcsm.PST_ERROR_CODE.TUNGSTEN_LOGGING_ERROR,
                errorStackTrace: JSON.stringify(r),
              },
            ];
            break;
          default:
            throw new Error("Invalid TenantId For Tungsten");
        }
        return e;
      }),
      s
    );
  }),
  amzntqcsm.define("pixelQueue", [], function () {
    var r = { shortName: "pq" };
    (r.init = function (t, n) {
      amzntqcsm.csmReport.pq = { queue: [], instrURL: n };
    }),
      (r.firePixel = function (t, n) {
        var e = amzntqcsm.csmReport.pq.instrURL;
        if (!1 !== s(t)) {
          try {
            var r = JSON.parse(t);
            if (
              ((r.ver = amzntqcsm.version),
              (t = JSON.stringify(r)),
              !0 === window.amzntqcsm.bnmk)
            ) {
              var a = {
                bnmk: {
                  pixelId: r.pixelId,
                  iframeId: document.body.getAttribute("data-absoluteparentid"),
                },
              };
              amzntqcsm.sendPixel(e + "bnmk/", JSON.stringify(a), ""),
                (window.amzntqcsm.bnmk = !1);
            }
          } catch (t) {}
          amzntqcsm.sendPixel(e, t, n);
        }
      });
    function a() {
      var t = amzntqcsm.csmReport.pq;
      0 < t.queue.length && (t.queue = []);
    }
    var s = function (t) {
      var n = "";
      if (!1 != ("string" == typeof t || t instanceof String)) return !0;
      (n = "Expected string: but " + typeof t + "found. "),
        "object" == typeof t && (n += JSON.stringify(t));
      try {
        throw new amzntqcsm.exceptions.invalidStringException(n);
      } catch (t) {
        amzntqcsm.reportClientError(t);
      }
      return !1;
    };
    return (
      (r.addPixel = function (t) {
        var n = this,
          e = amzntqcsm.csmReport.pq;
        !1 !== s(t) &&
          (amzntqcsm.log("Received pixel " + t),
          0 === e.queue.length &&
            amzntqcsm.setTimeout(function () {
              0 < e.queue.length && (n.send(), a());
            }, 2500),
          e.queue.push(JSON.parse(t)),
          4 <= e.queue.length && (n.send(), a()));
      }),
      (r.send = function () {
        var t = amzntqcsm.getPixelID(),
          n = new Date().getTime(),
          e = amzntqcsm.csmReport.pq;
        0 < e.queue.length &&
          r.firePixel(
            '{"adCsm": ' +
              JSON.stringify(e.queue) +
              ', "pixelId": "' +
              t +
              '", "ts": ' +
              n +
              "}",
            ""
          );
      }),
      r
    );
  }),
  amzntqcsm.define("privateStateToken", [], function () {
    var t = { shortName: "pst" },
      n = "private-state-token-redemption",
      m = "https://www.amazon.com";
    t.init = function () {
      e();
    };
    var e = function () {
        if (r()) {
          var t = a();
          t
            ? document
                .hasRedemptionRecord(m)
                .then(function (t) {
                  t ? o(t, !1) : s();
                })
                .catch(function (t) {
                  amzntqcsm.log(
                    "Error in calling hasRedemptionRecord function : " +
                      t.toString()
                  ),
                    i(t, amzntqcsm.PST_ERROR_CODE.HAS_RR_API_FAILURE, !1, !1);
                })
            : null !== t &&
              (amzntqcsm.log("PrivateStateToken feature policy not supported."),
              i(
                null,
                amzntqcsm.PST_ERROR_CODE.UNSUPPORTED_FEATURE_POLICY,
                !1,
                !1
              ));
        }
      },
      r = function () {
        try {
          return (
            "function" == typeof document.hasPrivateToken &&
            0 <= amzntqcsm.tungstenCSMLoggingFrameworkUrl.indexOf(".na.") &&
            "RTB" === amzntqcsm.api
          );
        } catch (t) {
          return amzntqcsm.log("PST operation is not supported."), null;
        }
      },
      a = function () {
        try {
          return (
            void 0 !== document.featurePolicy &&
            void 0 !== document.featurePolicy.allowsFeature &&
            document.featurePolicy.allowsFeature(n)
          );
        } catch (t) {
          return (
            amzntqcsm.log(
              "Exception in validating if PrivateStateToken feature policy is supported."
            ),
            i(t, amzntqcsm.PST_ERROR_CODE.FEATURE_POLICY_EXCEPTION, !1, !1),
            null
          );
        }
      },
      s = function () {
        document
          .hasPrivateToken(m)
          .then(function (n) {
            n
              ? fetch("https://www.amazon.com/tt/r", {
                  privateToken: {
                    version: 1,
                    operation: "token-redemption",
                    refreshPolicy: "none",
                  },
                })
                  .then(function (t) {
                    amzntqcsm.log(
                      "Response from redeem call : " +
                        t.status +
                        "," +
                        t.statusText
                    ),
                      200 !== t.status
                        ? i(
                            t.status,
                            amzntqcsm.PST_ERROR_CODE
                              .TRS_RESPONSE_STATUS_NOT_200,
                            !1,
                            n
                          )
                        : o(!1, n);
                  })
                  .catch(function (t) {
                    amzntqcsm.log("Error in redeeming token : " + t.toString()),
                      i(t, amzntqcsm.PST_ERROR_CODE.REDEMPTION_ERROR, !1, n);
                  })
              : (amzntqcsm.log("No Private State Token present in browser."),
                i(null, amzntqcsm.PST_ERROR_CODE.TOKEN_NOT_PRESENT, !1, n));
          })
          .catch(function (t) {
            amzntqcsm.log(
              "Error in calling hasPrivateToken function : " + t.toString()
            ),
              i(t, amzntqcsm.PST_ERROR_CODE.HAS_TOKEN_API_FAILURE, !1, !1);
          });
      },
      o = function (n, e) {
        try {
          var t = [
              {
                bidId: amzntqcsm.bidId || "",
                hasToken: e,
                hasRR: n,
                timeStamp: Date.now(),
              },
            ],
            r = {
              version: 1,
              operation: "send-redemption-record",
              issuers: [m],
            },
            a = new Headers({ "Content-Type": "application/json" }),
            s = {
              cache: "no-cache",
              method: "POST",
              body: JSON.stringify(t),
              privateToken: r,
              headers: a,
            };
          amzntqcsm.logToTungsten(
            t,
            amzntqcsm.tungstenTenants.pstRRLoggingEvent,
            s
          );
        } catch (t) {
          amzntqcsm.log(
            "Error in constructing params for send-rr call : " + t.toString()
          ),
            i(t, amzntqcsm.PST_ERROR_CODE.SEND_RR_PAYLOAD_ERROR, n, e);
        }
      },
      i = function (t, n, e, r, a) {
        try {
          var s = t
              ? t === parseInt(t, 10)
                ? '{"m": "' + t + '"}'
                : amzntqcsm.constructErrorMessage(t)
              : "",
            m = [
              {
                bidId: amzntqcsm.bidId || "",
                hasToken: r,
                hasRR: e,
                failureFunction: n,
                timeStamp: Date.now(),
                errorStackTrace: JSON.stringify(s),
                extraInfoJSON: a ? JSON.stringify(a) : "",
              },
            ];
          amzntqcsm.logToTungsten(
            m,
            amzntqcsm.tungstenTenants.pstErrorLoggingEvent
          );
        } catch (t) {
          amzntqcsm.reportErrorToTungsten(
            t,
            amzntqcsm.tungstenTenants.pstErrorLoggingEvent
          );
        }
      };
    return t;
  }),
  ((amzntqcsm = amzntqcsm || {}).rm = (function () {
    amzntqcsm.version = "r-1.36";
    var u = {
      RTB: { privateStateToken: !0 },
      DTB: {
        privateStateToken: !(amzntqcsm.tungstenTenants = {
          pstRRLoggingEvent: "pstRRLoggingEvent",
          pstErrorLoggingEvent: "pstErrorLoggingEvent",
        }),
      },
      ONO: { privateStateToken: !1 },
      supportedBrowsers: {
        IE: !0,
        Firefox: !0,
        Chrome: !0,
        Safari: !0,
        Other: !0,
      },
    };
    amzntqcsm.config = u;
    function a(t, n, e, r) {
      if (!((r = r || 20) < (e = e || 0)))
        try {
          t === t.parent
            ? t.postMessage(n, "*")
            : (t.parent.postMessage(n, "*"), a(t.parent, n, e + 1, r));
        } catch (t) {}
    }
    var o = function () {
        if (window.amzntqcsm.tungstenCSMLoggingFrameworkUrl) {
          (amzntqcsm.tungstenCSMLoggingFrameworkUrl =
            window.amzntqcsm.tungstenCSMLoggingFrameworkUrl),
            (amzntqcsm.bidId = window.amzntqcsm.bidId);
          var t = {
              tungstenCSMLoggingFrameworkUrl:
                amzntqcsm.tungstenCSMLoggingFrameworkUrl,
              bidId: amzntqcsm.bidId,
            },
            n = JSON.stringify(t);
          a(window, n);
          var e = 1,
            r = function () {
              if (!(6 <= e)) {
                var t = 1e3 * Math.pow(2, e - 1);
                setTimeout(function () {
                  a(window, n), e++, r();
                }, t);
              }
            };
          r();
        }
      },
      i = function (t, n, e, r, a, s) {
        var m = amzntqcsm.getModules(n, e, r, a);
        for (var o in m)
          if (m.hasOwnProperty(o)) {
            var i = m[o];
            if (
              (!0 === i.default || !0 === u[t][o]) &&
              (amzntqcsm.loadModules(s, [{ name: o, params: i.params }]),
              !0 === i.global)
            )
              for (var c in amzntqcsm[o])
                amzntqcsm[o].hasOwnProperty(c) &&
                  (amzntqcsm[c] = amzntqcsm[o][c]);
          }
      };
    return function (t) {
      var n = t.e,
        e = t.i,
        r = t.w,
        a = t.d,
        s = Math.round(1e7 * Math.random()).toString();
      if (
        ((amzntqcsm.csmReport = amzntqcsm.csmReport || {}),
        o(),
        i(amzntqcsm.api, n, e, r, a, s),
        "DTB" === amzntqcsm.api ||
          "RTB" === amzntqcsm.api ||
          "ONO" === amzntqcsm.api)
      ) {
        var m = new amzntqcsm.detectSignals(n, e, r, a, s);
        m.collectData && m.collectData();
      }
    };
  })()),
  (amzntqcsm.VENDOR_KEY = "amazon.com-omid"),
  (amzntqcsm.verificationClientConfig = {
    url: "https://c.amazon-adsystem.com/bao-csm/mobile/ovc.js",
    version: "1.3.2",
  }),
  (amzntqcsm.detectSignals = function (t, n, e, r, a) {
    amzntqcsm.log = function (t) {
      try {
        self.debug && window.console && window.console.log(t);
      } catch (t) {}
    };
    this.collectData = function () {
      !(function () {
        if (window.amzntqcsm.tsEndpoint) {
          var t = /\/x\/px\/(.*)\//g.exec(amzntqcsm.instrURL),
            n = "";
          null != t && 2 <= t.length && (n = t[1]);
          var e =
            "?imp=" +
            n +
            "&d=" +
            amzntqcsm.api +
            "&cb=" +
            Math.round(1e7 * Math.random());
          window.amzntqcsm.bidRequestId &&
            (e += "&bidR=" + window.amzntqcsm.bidRequestId),
            window.amzntqcsm.bidId && (e += "&bid=" + window.amzntqcsm.bidId),
            (new Image().src = window.amzntqcsm.tsEndpoint + e);
        }
      })();
    };
  }),
  (amzntqcsm.extend = function (t, n) {
    for (var e in n) n.hasOwnProperty(e) && (t.prototype[e] = n[e]);
  }),
  (window.amzntqcsm.rmR = function (t, n) {
    (amzntqcsm.api = "RTB"), startTqCsmComp(t, n);
  });
var startTqCsmComp = function (n, t) {
  try {
    function e(t) {
      return "complete" === t.readyState;
    }
    var r = function (t) {
        t.message &&
          (amzntqcsm.errors.push(t.message), amzntqcsm.reportErrors(n));
      },
      a = t,
      s = a.document;
    e(s)
      ? amzntqcsm.rm({ e: a, i: n, w: a, d: s })
      : void 0 === document.onreadystatechange
      ? amzntqcsm.rm({ e: a, i: n, w: a, d: s })
      : s.addEventListener("readystatechange", function () {
          try {
            e(s) && amzntqcsm.rm({ e: a, i: n, w: a, d: s });
          } catch (t) {
            r(t);
          }
        });
  } catch (t) {
    r(t);
  }
};
(amzntqcsm.getSanitizedInstrUrl = function (t) {
  return (
    !1 === /^https?:\/\//.test(t) &&
      (t = "https:" + (/^\/\//.test(t) ? "" : "//") + t),
    "/" !== t.substr(t.length - 1) && (t += "/"),
    !0 === /^http:\/\//.test(t) && (t = t.replace("http://", "https://")),
    t
  );
}),
  (amzntqcsm.getElement = function (t) {
    if (!t || "window" === t) return window;
    var n = t.match(/^document\.getElementById\(['"]([a-zA-Z0-9_-]+)['"]\)$/);
    return n && 1 < n.length ? document.getElementById(n[1]) : window;
  }),
  (amzntqcsm.injectJSResource = function (e, r, a, s) {
    var m = 0;
    !(function t() {
      if (e && e.body && "function" == typeof e.body.appendChild) {
        var n = e.createElement("script");
        a && (n.onload = a),
          (n.onerror = function () {
            m <= s && ((m += 1), t());
          }),
          (n.src = r),
          e.body.appendChild(n);
      } else m <= s && ((m += 1), setTimeout(t, 100));
    })();
  }),
  (amzntqcsm.processOMSDKAndInitiate = function () {
    try {
      if (
        window.OmidVerificationClient &&
        amzntqcsm.verificationClientConfig.version in
          window.OmidVerificationClient
      ) {
        var t = new window.OmidVerificationClient[
          amzntqcsm.verificationClientConfig.version
        ]();
        "true" === (!0 === t.isSupported() ? "true" : "false") &&
          t.registerSessionObserver(function (t) {
            try {
              if (
                t &&
                t.type &&
                "sessionStart" === t.type &&
                t.data.verificationParameters
              ) {
                var n = JSON.parse(t.data.verificationParameters);
                (amzntqcsm.bidId = n.bidId), (amzntqcsm.instrURL = n.instrUrl);
                var e = amzntqcsm.getElement(n.targetElement);
                window.amzntqcsm.rmR(amzntqcsm.instrURL, e);
              }
            } catch (t) {}
          }, amzntqcsm.VENDOR_KEY);
      }
    } catch (t) {}
  }),
  (amzntqcsm.parseUrlParams = function (t) {
    var n = {};
    if (!t) return n;
    var e = t.split("?")[1];
    if (e)
      for (var r = e.split("&"), a = 0; a < r.length; a++) {
        var s = r[a].split("=");
        if (2 <= s.length) {
          var m = s[0],
            o = s[1];
          if (m && /^[a-zA-Z0-9_-]+$/.test(m) && void 0 !== o)
            try {
              var i = decodeURIComponent(o).replace(/[<>"'&]/g, "");
              n[m] = i;
            } catch (t) {
              continue;
            }
        }
      }
    return n;
  }),
  (amzntqcsm.init = function () {
    var t =
      ("undefined" != typeof window && window && window.document) || document;
    if (t) {
      var n = amzntqcsm.parseUrlParams(t.currentScript.src);
      if (
        ((amzntqcsm.instrURL = amzntqcsm.getSanitizedInstrUrl(n.instrUrl)),
        (amzntqcsm.tsEndpoint = n.tsEndpoint),
        (amzntqcsm.tungstenCSMLoggingFrameworkUrl =
          n.tungstenCSMLoggingFrameworkUrl),
        (amzntqcsm.bidRequestId = n.bidRequestId),
        (amzntqcsm.bidId = n.bidId),
        (amzntqcsm.zone = n.zone),
        (amzntqcsm.isBen = n.isBen || !1),
        !amzntqcsm.instrURL)
      )
        throw amzntqcsm.errorCodes.MALFORMED_URL;
      var e = amzntqcsm.getElement(n.targetElement);
      if (amzntqcsm.bidId)
        amzntqcsm.log(
          "Query params fetched: " +
            amzntqcsm.instrURL +
            " : " +
            amzntqcsm.isBen
        ),
          window.amzntqcsm.rmR(amzntqcsm.instrURL, e);
      else {
        amzntqcsm.injectJSResource(
          t,
          amzntqcsm.verificationClientConfig.url,
          amzntqcsm.processOMSDKAndInitiate,
          2
        );
      }
    }
  }),
  amzntqcsm.init();
