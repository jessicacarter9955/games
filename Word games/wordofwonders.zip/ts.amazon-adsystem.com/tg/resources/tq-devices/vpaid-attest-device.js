!(function (e, t) {
  "object" == typeof exports && "object" == typeof module
    ? (module.exports = t())
    : "function" == typeof define && define.amd
    ? define([], t)
    : "object" == typeof exports
    ? (exports.DeviceAttestation = t())
    : (e.DeviceAttestation = t());
})(this, () =>
  (() => {
    "use strict";
    var e = {};
    function t(e) {
      return (
        (t =
          "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
            ? function (e) {
                return typeof e;
              }
            : function (e) {
                return e &&
                  "function" == typeof Symbol &&
                  e.constructor === Symbol &&
                  e !== Symbol.prototype
                  ? "symbol"
                  : typeof e;
              }),
        t(e)
      );
    }
    var n = ["iOS", "iPhone OS", "iPadOS"],
      o = ["macOS", "Mac OS X"];
    function i(e, i, r) {
      return (
        (function (e, t, i) {
          var r = parseInt(t, 10);
          return n.includes(e)
            ? r >= 16
            : !!o.includes(e) && r >= 13 && "Safari" === i;
        })(e, i, r) ||
        (function () {
          if (
            ((e =
              "undefined" != typeof CSS &&
              "function" == typeof CSS.supports &&
              CSS.supports("container-type: inline-size")),
            (n =
              "undefined" != typeof CSS &&
              "function" == typeof CSS.supports &&
              CSS.supports("grid-template-rows", "subgrid")),
            (o =
              "undefined" != typeof HTMLFormElement &&
              "requestSubmit" in HTMLFormElement.prototype),
            !(e && n && o))
          )
            return !1;
          var e, n, o;
          if (
            "object" !==
              ("undefined" == typeof window ? "undefined" : t(window)) ||
            "object" !== t(window.navigator)
          )
            return !1;
          var i = window.navigator.userAgent,
            r = /iPhone|iPad/.test(i),
            a = /(Macintosh)/.test(i),
            d = i.match(/(Mac OS X|CPU (?:iPhone )?OS) (\d+)[_.](\d+)/);
          if (!d) return !1;
          var s = parseInt(d[2], 10);
          if (r && s < 16) return !1;
          if (a) {
            var u = i.match(/Version\/(\d+)\.(\d+)/);
            return (
              !!u && parseInt(u[1], 10) >= 16 && /Version\/.+Safari/.test(i)
            );
          }
          return r || (s >= 16 && !/Version\//.test(i));
        })()
      );
    }
    return (
      (function () {
        try {
          var e = (function () {
            var e,
              t =
                ("undefined" != typeof window && window && window.document) ||
                document;
            if (t) {
              var n =
                  null == t || null === (e = t.currentScript) || void 0 === e
                    ? void 0
                    : e.src,
                o = {};
              if (!n) return o;
              var i = n.split("?")[1];
              if (i)
                for (var r = i.split("&"), a = 0; a < r.length; a++) {
                  var d = r[a].split("=");
                  if (d.length >= 2) {
                    var s = d[0],
                      u = d[1];
                    if (s && /^[a-zA-Z0-9_-]+$/.test(s) && void 0 !== u)
                      try {
                        var p = decodeURIComponent(u).replace(/[<>"'&]/g, "");
                        o[s] = p;
                      } catch (e) {
                        continue;
                      }
                  }
                }
              return o;
            }
          })();
          if (
            i(
              null == e ? void 0 : e.osN,
              null == e ? void 0 : e.osV,
              null == e ? void 0 : e.brF
            ) &&
            Math.floor(100 * Math.random()) < 100
          ) {
            var t = (function () {
              var e =
                  arguments.length > 0 && void 0 !== arguments[0]
                    ? arguments[0]
                    : {},
                t = e.appName,
                n = void 0 === t ? "appName1" : t,
                o = e.impressionId,
                i = void 0 === o ? "impressionId1" : o,
                r = e.device,
                a = void 0 === r ? "APPLE" : r;
              return "https://origin.amazon-ads-attestation.com/v1/attest-device?appName=%s&impressionId=%s&device=%s"
                .replace("%s", encodeURIComponent(n))
                .replace("%s", encodeURIComponent(i))
                .replace("%s", encodeURIComponent(a));
            })({ impressionId: null == e ? void 0 : e.bidId });
            new Image().src = t;
          }
        } catch (e) {}
      })(),
      e.default
    );
  })()
);
//# sourceMappingURL=vpaid-attest-device.js.map
