var CREM;
(() => {
  "use strict";
  var e = {
      905: (e, t) => {
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.evaluateBTRCriteria = void 0);
        var r = "visibilitychange",
          n = function (e) {
            return "prerender" === e.visibilityState;
          },
          a = function (e, t) {
            var r = getComputedStyle(e).backgroundImage;
            if ("none" === r) return !1;
            var n = r.replace(/url\(['"]?(.*?)['"]?\)/i, "$1");
            return (
              0 !== n.length &&
              (void 0 === t[n] && ((t[n] = new Image()), (t[n].src = n)),
              t[n].naturalHeight > 0 && t[n].naturalWidth > 0)
            );
          },
          i = {
            img: function (e) {
              if (0 === e.length) return !1;
              for (var t = 0; t < e.length; t++)
                if (
                  (1 !== (r = e[t]).naturalHeight || 1 !== r.naturalWidth) &&
                  e[t].naturalHeight > 0 &&
                  e[t].naturalWidth > 0
                )
                  return !0;
              var r;
              return !1;
            },
            span: function (e, t) {
              var r;
              if (0 === e.length) return !1;
              for (var n = 0; n < e.length; n++)
                if (
                  ((null === (r = e[n].textContent) || void 0 === r
                    ? void 0
                    : r.length) || 0) > 0 ||
                  a(e[n], t) ||
                  "" !== e[n].style.getPropertyValue("background-color")
                )
                  return !0;
              return !1;
            },
            p: function (e) {
              var t;
              if (0 === e.length) return !1;
              for (var r = 0; r < e.length; r++)
                if (
                  ((null === (t = e[r].textContent) || void 0 === t
                    ? void 0
                    : t.length) || 0) > 0
                )
                  return !0;
              return !1;
            },
            div: function (e, t) {
              var r;
              if (0 === e.length) return !1;
              for (var n = 0; n < e.length; n++)
                if (
                  ((null === (r = e[n].textContent) || void 0 === r
                    ? void 0
                    : r.trim().length) || 0) > 0 ||
                  a(e[n], t) ||
                  "" !== e[n].style.getPropertyValue("background-color")
                )
                  return !0;
              return !1;
            },
          };
        t.evaluateBTRCriteria = function (e, t, a) {
          var i = {};
          if (n(e)) {
            var o = function () {
              n(e) || (u(t, i, a), e.removeEventListener(r, o));
            };
            e.addEventListener(r, o);
          } else u(t, i, a);
        };
        var u = function (e, t, r) {
          var n = 0,
            a = setInterval(function () {
              var u = {};
              Object.keys(i).forEach(function (t) {
                u[t] = e.getElementsByTagName(t);
              }),
                (function (e, t) {
                  var r = !1;
                  return (
                    Object.keys(e).forEach(function (n) {
                      "div" === n || "span" === n
                        ? i[n](e[n], t) && (r = !0)
                        : i[n](e[n]) && (r = !0);
                    }),
                    r
                  );
                })(u, t)
                  ? (clearInterval(a), r({ isBTRCompliant: !0, debugInfo: [] }))
                  : n >= 30 &&
                    (clearInterval(a),
                    r({ isBTRCompliant: !1, debugInfo: [] })),
                n++;
            }, 500);
        };
      },
    },
    t = {};
  function r(n) {
    var a = t[n];
    if (void 0 !== a) return a.exports;
    var i = (t[n] = { exports: {} });
    return e[n](i, i.exports, r), i.exports;
  }
  var n = {};
  (() => {
    var e = n;
    Object.defineProperty(e, "__esModule", { value: !0 }),
      (e.evaluateBTRCriteria = void 0);
    var t = r(905);
    Object.defineProperty(e, "evaluateBTRCriteria", {
      enumerable: !0,
      get: function () {
        return t.evaluateBTRCriteria;
      },
    });
  })(),
    (CREM = n);
})();
