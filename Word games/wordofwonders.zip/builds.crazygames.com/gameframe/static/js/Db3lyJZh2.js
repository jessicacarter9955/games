!(function () {
  try {
    var e =
        "undefined" != typeof window
          ? window
          : "undefined" != typeof global
          ? global
          : "undefined" != typeof globalThis
          ? globalThis
          : "undefined" != typeof self
          ? self
          : {},
      n = new e.Error().stack;
    n &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[n] = "8dc752b8-5ff8-58ad-830b-eb4c7304d00f"));
  } catch (e) {}
})();
(function () {
  try {
    var e =
      typeof window < `u`
        ? window
        : typeof global < `u`
        ? global
        : typeof globalThis < `u`
        ? globalThis
        : typeof self < `u`
        ? self
        : {};
    (e._sentryModuleMetadata = e._sentryModuleMetadata || {}),
      (e._sentryModuleMetadata[new e.Error().stack] = (function (e) {
        for (var t = 1; t < arguments.length; t++) {
          var n = arguments[t];
          if (n != null) for (var r in n) n.hasOwnProperty(r) && (e[r] = n[r]);
        }
        return e;
      })({}, e._sentryModuleMetadata[new e.Error().stack], {
        "_sentryBundlerPluginAppKey:crazygames-gameframe": !0,
      }));
    var t = new e.Error().stack;
    t &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[t] = `eb145d38-e7af-4a0b-ac76-c088a7f4038d`),
      (e._sentryDebugIdIdentifier = `sentry-dbid-eb145d38-e7af-4a0b-ac76-c088a7f4038d`));
  } catch {}
})();
import {
  Jt as e,
  Xt as t,
  at as n,
  gn as r,
  ht as i,
  jt as a,
  ln as o,
  pt as s,
  wn as c,
  yn as l,
} from "../../bundle.js";
var u = c(l()),
  d = {
    notice: `_notice_1m4di_7`,
    atFooter: `_atFooter_1m4di_47`,
    atBottom: `_atBottom_1m4di_51`,
    pending: `_pending_1m4di_55`,
    visible: `_visible_1m4di_60`,
    content: `_content_1m4di_65`,
    close: `_close_1m4di_72`,
  },
  f = r(),
  p = 2,
  m = 7,
  h = 1440 * 60,
  g = `batterynotice_hidden_hour`,
  _ = () => {
    let { gameLoadStatus: r } = (0, u.useContext)(a),
      c = o(),
      l = u.useRef(null),
      [_, v] = u.useState(!1),
      [y, b] = u.useState(!1),
      [x, S] = u.useState(!1),
      [C] = u.useState(() => Date.now()),
      w = e.Instance.getItem(g),
      T = w ? C - Number(w) : null,
      E = r === `GAME_LOADED` && !(T && T < h),
      D = () => {
        S(!1),
          v(!1),
          b(!0),
          t.getInstance().userAction(`batteryWarning`, `batteryWarningClosed`);
        let n = Date.now();
        e.Instance.setItem(g, `${n}`);
      };
    if (
      (u.useEffect(() => {
        let e = null,
          n,
          r;
        return (
          typeof navigator < `u` &&
            typeof navigator.getBattery == `function` &&
            navigator.getBattery().then((i) => {
              (e = i),
                !y &&
                  !_ &&
                  e &&
                  e.level <= 0.2 &&
                  !e.charging &&
                  (b(!1),
                  v(!0),
                  t
                    .getInstance()
                    .userAction(`batteryWarning`, `batteryWarningDisplayed`)),
                (n = () => {
                  e.charging &&
                    _ &&
                    (b(!0),
                    c && S(!1),
                    v(!1),
                    t
                      .getInstance()
                      .userAction(
                        `batteryWarning`,
                        `batteryWarningRemovedChargingChange`
                      ));
                }),
                e.addEventListener(`chargingchange`, n),
                (r = () => {
                  y &&
                    !_ &&
                    e.level <= 0.2 &&
                    !e.charging &&
                    (b(!1),
                    c && S(!0),
                    v(!0),
                    t
                      .getInstance()
                      .userAction(
                        `batteryWarning`,
                        `batteryWarningDisplayedLevelChange`
                      ));
                }),
                e.addEventListener(`levelchange`, r);
            }),
          () => {
            e &&
              (e.removeEventListener(`chargingchange`, n),
              e.removeEventListener(`levelchange`, r));
          }
        );
      }, [_, c]),
      u.useEffect(() => {
        let e, t;
        if (!c) return;
        let n = new IntersectionObserver(([n]) => {
          n.isIntersecting &&
            !x &&
            (e ||= window.setTimeout(() => {
              S(!0), (t ||= window.setTimeout(D, m * 1e3));
            }, p * 1e3));
        });
        return (
          l && l.current && n.observe(l.current),
          function () {
            n.disconnect(),
              e && window.clearTimeout(e),
              t && window.clearTimeout(t);
          }
        );
      }, [c, l, r, _]),
      !_ || !E)
    )
      return null;
    let O = x || !c;
    return (0, f.jsxs)(`div`, {
      className: i(
        d.notice,
        c ? d.atBottom : d.atFooter,
        O ? d.visible : d.pending
      ),
      ref: l,
      id: `hornotice`,
      children: [
        (0, f.jsxs)(`div`, {
          className: d.content,
          children: [
            (0, f.jsx)(s, { name: `low-power` }),
            (0, f.jsx)(n, { id: `batteryWarning.info.text` }),
          ],
        }),
        (0, f.jsx)(`button`, {
          type: `button`,
          className: d.close,
          onClick: D,
          children: (0, f.jsx)(s, { name: `close` }),
        }),
      ],
    });
  };
export { _ as default };
//# debugId=8dc752b8-5ff8-58ad-830b-eb4c7304d00f
