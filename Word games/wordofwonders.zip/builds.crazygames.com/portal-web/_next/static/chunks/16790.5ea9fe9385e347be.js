!(function () {
  try {
    var e =
      "u" > typeof window
        ? window
        : "u" > typeof global
        ? global
        : "u" > typeof globalThis
        ? globalThis
        : "u" > typeof self
        ? self
        : {};
    (e._sentryModuleMetadata = e._sentryModuleMetadata || {}),
      (e._sentryModuleMetadata[new e.Error().stack] = (function (e) {
        for (var t = 1; t < arguments.length; t++) {
          var a = arguments[t];
          if (null != a) for (var n in a) a.hasOwnProperty(n) && (e[n] = a[n]);
        }
        return e;
      })({}, e._sentryModuleMetadata[new e.Error().stack], {
        "_sentryBundlerPluginAppKey:crazygames-portal": !0,
      }));
    var t = new e.Error().stack;
    t &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[t] = "72835e2b-6a36-48ce-820f-161a3c4c99f4"),
      (e._sentryDebugIdIdentifier =
        "sentry-dbid-72835e2b-6a36-48ce-820f-161a3c4c99f4"));
  } catch (e) {}
})();
("use strict");
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [16790],
  {
    16790: (e, t, a) => {
      a.r(t), a.d(t, { default: () => h });
      var n = a(6029),
        r = a(75155),
        l = a(55729),
        o = a(79942),
        i = a(50212),
        s = a(33165),
        c = a(93800),
        d = a(71684),
        u = a(37434),
        f = a(94618),
        g = a(78339),
        y = a.n(g);
      let h = (e) => {
        let t,
          a,
          g,
          h,
          b,
          m,
          v,
          p,
          w,
          k,
          A,
          M,
          E,
          x = (0, r.c)(30),
          { width: I, height: C } = e,
          { crazyAnalyticsService: N } = l.useContext(d.A).services,
          [j] = l.useState(_),
          D = (0, o.uB)(),
          { openDrawer: S } = l.useContext(s.lv);
        x[0] === Symbol.for("react.memo_cache_sentinel")
          ? ((t = (0, f.Ay)("crazygames/ziggy_rainbow2.svg")), (x[0] = t))
          : (t = x[0]);
        let z = t,
          T = I && C ? I / C : 1;
        x[1] !== D || x[2] !== j
          ? ((a = D._(`game.adUnitLogin.title${2 === j ? "2" : ""}`)),
            (x[1] = D),
            (x[2] = j),
            (x[3] = a))
          : (a = x[3]);
        let B = a,
          P = B.length > 30 ? 20 : 28;
        x[4] !== N
          ? ((g = () => {
              N.notificationActionEvent("banner-cta-login", "shown");
            }),
            (h = [N]),
            (x[4] = N),
            (x[5] = g),
            (x[6] = h))
          : ((g = x[5]), (h = x[6])),
          l.useEffect(g, h),
          x[7] !== N || x[8] !== S
            ? ((b = (e) => {
                e.preventDefault(),
                  e.stopPropagation(),
                  S("signIn", { clickOrigin: "banner-cta-login" }),
                  N.notificationActionEvent("banner-cta-login", "clicked");
              }),
              (x[7] = N),
              (x[8] = S),
              (x[9] = b))
            : (b = x[9]);
        let O = b,
          U = T > 2 && y().wide;
        x[10] !== U
          ? ((m = (0, i.A)(y().adUnitAlternative, U)), (x[10] = U), (x[11] = m))
          : (m = x[11]),
          x[12] !== C || x[13] !== I
            ? ((v = { width: I, height: C }),
              (x[12] = C),
              (x[13] = I),
              (x[14] = v))
            : (v = x[14]);
        let $ = y()[`fontSize${P}`];
        return (
          x[15] !== $
            ? ((p = (0, i.A)(y().placeholderTitle, $)),
              (x[15] = $),
              (x[16] = p))
            : (p = x[16]),
          x[17] !== p || x[18] !== B
            ? ((w = (0, n.jsx)("div", { className: p, children: B })),
              (x[17] = p),
              (x[18] = B),
              (x[19] = w))
            : (w = x[19]),
          x[20] === Symbol.for("react.memo_cache_sentinel")
            ? ((k = (0, n.jsx)(c.A, { name: "arrow-full-right" })), (x[20] = k))
            : (k = x[20]),
          x[21] !== O
            ? ((A = (0, n.jsx)(u.A, {
                height: 34,
                variant: "contained",
                color: "white",
                onClick: O,
                className: y().iconButton,
                dataTestId: "ad-login-cta",
                children: k,
              })),
              (x[21] = O),
              (x[22] = A))
            : (A = x[22]),
          x[23] === Symbol.for("react.memo_cache_sentinel")
            ? ((M = (0, n.jsx)("img", {
                className: y().image,
                src: z,
                alt: "",
              })),
              (x[23] = M))
            : (M = x[23]),
          x[24] !== O ||
          x[25] !== w ||
          x[26] !== A ||
          x[27] !== m ||
          x[28] !== v
            ? ((E = (0, n.jsxs)("div", {
                className: m,
                style: v,
                onClick: O,
                children: [w, A, M],
              })),
              (x[24] = O),
              (x[25] = w),
              (x[26] = A),
              (x[27] = m),
              (x[28] = v),
              (x[29] = E))
            : (E = x[29]),
          E
        );
      };
      function _() {
        return Math.floor(2 * Math.random()) + 1;
      }
    },
  },
]);
