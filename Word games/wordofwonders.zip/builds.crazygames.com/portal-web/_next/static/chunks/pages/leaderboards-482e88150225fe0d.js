!(function () {
  try {
    var e =
      "u" > typeof window
        ? window
        : "u" > typeof global
        ? global
        : "u" > typeof globalThis
        ? globalThis
        : "u" > typeof self
        ? self
        : {};
    (e._sentryModuleMetadata = e._sentryModuleMetadata || {}),
      (e._sentryModuleMetadata[new e.Error().stack] = (function (e) {
        for (var a = 1; a < arguments.length; a++) {
          var r = arguments[a];
          if (null != r) for (var t in r) r.hasOwnProperty(t) && (e[t] = r[t]);
        }
        return e;
      })({}, e._sentryModuleMetadata[new e.Error().stack], {
        "_sentryBundlerPluginAppKey:crazygames-portal": !0,
      }));
    var a = new e.Error().stack;
    a &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[a] = "b662b492-9498-4257-b442-bf7f785a2171"),
      (e._sentryDebugIdIdentifier =
        "sentry-dbid-b662b492-9498-4257-b442-bf7f785a2171"));
  } catch (e) {}
})(),
  (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [91836],
    {
      1660: (e, a, r) => {
        "use strict";
        r.r(a), r.d(a, { default: () => h });
        var t = r(6029),
          s = r(55729),
          n = r(68168),
          o = r(23033),
          l = r(30277),
          i = r(50293),
          u = r(87295),
          d = r(71543),
          f = r(47429),
          w = r(12097),
          g = r(95816),
          y = r(69694),
          c = r(39195),
          b = r(20183),
          p = r(66670);
        class _ extends s.Component {
          static async getInitialProps(e) {
            let {
                pageService: a,
                crawlerService: r,
                modelService: t,
              } = (0, w.V)(e),
              s = (0, i.hz)(e),
              y = (e.query && e.query[u.po]) || "default",
              c = e.query[u.Sh] || 1,
              b = (0, l.z)(c),
              p = (0, i.Fr)(s) ? f.w9 : f.F_,
              _ = Number((e.query && e.query[u.Fb]) || p),
              h = (0, i.v1)(s) ? f.uo : f.iF,
              m = (0, i.xl)(s) ? f.r2 : h,
              k = await a.tagPage(
                "tag",
                "climb-the-ranks",
                { page: b, size: _ },
                m,
                h,
                s,
                f.W$,
                f.F_,
                y
              ),
              v = "true" === e.query[u.pr],
              {
                tag: M,
                games: G,
                topGames: A,
                topMobileGames: E,
                linkBoostedGames: F,
              } = k,
              C = (0, g.Y)(G.items[0]),
              I = !v,
              N = async () => {
                let { games: e, extraDesktopGames: a } = await (0, d.fS)(
                  { sorting: y, isCrawler: v },
                  { deviceInfo: s, page: b, tag: M },
                  r,
                  t
                );
                return { games: I ? void 0 : e, extraDesktopGames: a };
              },
              { games: q, extraDesktopGames: P } = await N(),
              D = (0, o.SF)(b, y);
            if (q && !M.isArchived) {
              if (b > Math.ceil(q.total / f.F_))
                throw new n.A(404, "Incorrect pagination");
              if (0 === q.items.length) throw new n.A(404, "No games found");
            }
            return {
              alternatives: D,
              crawlerGames: q,
              tag: M,
              topGames: A,
              topMobileGames: E,
              page: b,
              linkBoostedGames: F,
              sorting: y,
              isCrawler: v,
              extraDesktopGames: P,
              shouldFetchGamesOnClient: I,
              featuredGame: C,
            };
          }
          render() {
            let {
              crawlerGames: e,
              tag: a,
              topGames: r,
              topMobileGames: s,
              page: n,
              sorting: o,
              linkBoostedGames: l,
              alternatives: i,
              fillerGames: u,
              isCrawler: d,
              extraDesktopGames: f,
              shouldFetchGamesOnClient: w,
              featuredGame: g,
            } = this.props;
            return (0, t.jsx)(
              y.A,
              {
                tag: a,
                topGames: r,
                topMobileGames: s,
                page: n,
                alternatives: i,
                linkBoostedGames: l,
                fillerGames: u,
                sorting: o,
                featuredGame: g,
                shouldFetchGamesOnClient: w,
                crawlerGames: e,
                extraDesktopGames: f,
                isCrawler: d,
              },
              a.name
            );
          }
        }
        let h = (0, c.A)((0, b.A)("tag", "carousels")((0, p.A)(_)));
      },
      89789: (e, a, r) => {
        (window.__NEXT_P = window.__NEXT_P || []).push([
          "/leaderboards",
          function () {
            return r(1660);
          },
        ]);
      },
    },
    (e) => {
      e.O(
        0,
        [
          6847, 5869, 89247, 88823, 67088, 67473, 22694, 32627, 19954, 46593,
          90636, 38792,
        ],
        () => e((e.s = 89789))
      ),
        (_N_E = e.O());
    },
  ]);
