!(function () {
  try {
    var e =
      "u" > typeof window
        ? window
        : "u" > typeof global
        ? global
        : "u" > typeof globalThis
        ? globalThis
        : "u" > typeof self
        ? self
        : {};
    (e._sentryModuleMetadata = e._sentryModuleMetadata || {}),
      (e._sentryModuleMetadata[new e.Error().stack] = (function (e) {
        for (var t = 1; t < arguments.length; t++) {
          var n = arguments[t];
          if (null != n) for (var a in n) n.hasOwnProperty(a) && (e[a] = n[a]);
        }
        return e;
      })({}, e._sentryModuleMetadata[new e.Error().stack], {
        "_sentryBundlerPluginAppKey:crazygames-portal": !0,
      }));
    var t = new e.Error().stack;
    t &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[t] = "fae8b428-6fd9-4e2e-91b3-b7aee5c9dd63"),
      (e._sentryDebugIdIdentifier =
        "sentry-dbid-fae8b428-6fd9-4e2e-91b3-b7aee5c9dd63"));
  } catch (e) {}
})(),
  (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [14506],
    {
      46844: (e) => {
        e.exports = {
          czyButton: "OriginalsPage_czyButton__1AoWS",
          "czyButton--contained--purple":
            "OriginalsPage_czyButton--contained--purple__MvguH",
          "czyButton--contained--white":
            "OriginalsPage_czyButton--contained--white__M2IJC",
          "czyButton--contained--grey":
            "OriginalsPage_czyButton--contained--grey__V3jXc",
          "czyButton--contained--warning":
            "OriginalsPage_czyButton--contained--warning__9IMDz",
          "czyButton--contained--alert":
            "OriginalsPage_czyButton--contained--alert__O7X4O",
          "czyButton--contained--success":
            "OriginalsPage_czyButton--contained--success__G69AQ",
          "czyButton--contained--black":
            "OriginalsPage_czyButton--contained--black__xJNJv",
          "czyButton--contained--green-gradient":
            "OriginalsPage_czyButton--contained--green-gradient__enCV_",
          "czyButton--contained--animated-green-gradient":
            "OriginalsPage_czyButton--contained--animated-green-gradient__q9B_H",
          "scroll-gradient": "OriginalsPage_scroll-gradient__LMa4D",
          "czyButton--outlined--purple":
            "OriginalsPage_czyButton--outlined--purple__fyhes",
          "czyButton--link--purple":
            "OriginalsPage_czyButton--link--purple__aqiA_",
          "czyButton--outlined--white":
            "OriginalsPage_czyButton--outlined--white__Hfm8F",
          "czyButton--link--white":
            "OriginalsPage_czyButton--link--white__yGWU4",
          "czyButton--outlined--grey":
            "OriginalsPage_czyButton--outlined--grey__huZYi",
          "czyButton--link--grey": "OriginalsPage_czyButton--link--grey__vJ0aR",
          "czyButton--outlined--warning":
            "OriginalsPage_czyButton--outlined--warning__D4DST",
          "czyButton--link--warning":
            "OriginalsPage_czyButton--link--warning__fLqfd",
          "czyButton--outlined--alert":
            "OriginalsPage_czyButton--outlined--alert__bNj7h",
          "czyButton--link--alert":
            "OriginalsPage_czyButton--link--alert__c_w8J",
          "czyButton--outlined--success":
            "OriginalsPage_czyButton--outlined--success__VLami",
          "czyButton--link--success":
            "OriginalsPage_czyButton--link--success__3veKp",
          "czyButton--outlined": "OriginalsPage_czyButton--outlined__g3isL",
          "czyButton--disabled": "OriginalsPage_czyButton--disabled__9Tk1H",
          "czyButton--height50": "OriginalsPage_czyButton--height50__qNR84",
          "czyButton--height34": "OriginalsPage_czyButton--height34__4xwmp",
          "czyButton--height28": "OriginalsPage_czyButton--height28__G0EnB",
          "czyButton--fullWidth": "OriginalsPage_czyButton--fullWidth__aSi2e",
          "czyButton--headerIcon": "OriginalsPage_czyButton--headerIcon__mUAcG",
          "czyButton--headerIcon--desktop":
            "OriginalsPage_czyButton--headerIcon--desktop___VQ45",
          "czyButton--headerIcon--mobile":
            "OriginalsPage_czyButton--headerIcon--mobile__vrLTX",
          "czyButton--headerIcon--withLabel":
            "OriginalsPage_czyButton--headerIcon--withLabel__CZA7x",
          root: "OriginalsPage_root__6zYQR",
          isDesktop: "OriginalsPage_isDesktop__FG6mE",
          container: "OriginalsPage_container__hMXO1",
          gridWrapper: "OriginalsPage_gridWrapper__wzKV2",
          gridContainer: "OriginalsPage_gridContainer__eHGLp",
          experimentInstantGrid: "OriginalsPage_experimentInstantGrid__zMLVx",
          addMarginBottom: "OriginalsPage_addMarginBottom__Y1Gvj",
          paginationContainer: "OriginalsPage_paginationContainer__VrztG",
        };
      },
      85116: (e, t, n) => {
        "use strict";
        n.d(t, { A: () => _ });
        var a = n(6029),
          i = n(55729),
          r = n(50212),
          o = n(47429),
          s = n(32627),
          l = n(6847),
          g = n(96940),
          c = n.n(g);
        let _ = i.memo((e) => {
          let {
            games: t,
            enableInstantJoin: n,
            isFirstPage: i,
            removeThumbLabels: g,
          } = e;
          return i
            ? (0, a.jsxs)(a.Fragment, {
                children: [
                  (0, a.jsx)(s.A, {
                    games: t.slice(0, 6),
                    expectedSize: 4,
                    enableInstantJoin: n,
                    customOrigin: "tagPageInstantLarge",
                    autoplayOnlyCentered: !0,
                    className: (0, r.A)(
                      c().experimentInstantGrid,
                      c().addMarginBottom
                    ),
                    removeThumbLabels: g,
                  }),
                  t.length > 6 &&
                    (0, a.jsx)(l.A, {
                      games: t.slice(6),
                      expectedSize: 24,
                      enableInstantJoin: n,
                      customOrigin: "tagPageInstantSmall",
                      className: c().experimentInstantGrid,
                      removeThumbLabels: g,
                    }),
                ],
              })
            : (0, a.jsx)(l.A, {
                games: t,
                expectedSize: o.w9,
                enableInstantJoin: n,
                customOrigin: "tagPageInstantSmall",
                removeThumbLabels: g,
              });
        });
      },
      89051: (e, t, n) => {
        (window.__NEXT_P = window.__NEXT_P || []).push([
          "/originals/[[...page]]",
          function () {
            return n(91615);
          },
        ]);
      },
      91615: (e, t, n) => {
        "use strict";
        n.r(t), n.d(t, { default: () => M });
        var a = n(6029),
          i = n(75155),
          r = n(55729),
          o = n(79942),
          s = n(23033),
          l = n(30277),
          g = n(50293),
          c = n(87295),
          _ = n(71543),
          u = n(47429),
          d = n(12097),
          y = n(952),
          z = n(50212),
          m = n(52722),
          B = n(52461),
          h = n(4230),
          p = n(58224),
          P = n(93389),
          O = n(47270),
          b = n(70930),
          w = n(77515),
          x = n(85116),
          f = n(86907),
          k = n.n(f),
          I = n(46844),
          v = n.n(I);
        let A = (e) => {
          let t,
            n,
            o,
            s,
            l,
            c,
            _,
            u = (0, i.c)(21),
            {
              crawlerGames: d,
              extraDesktopGames: y,
              page: f,
              shouldFetchGamesOnClient: I,
              isCrawler: A,
            } = e,
            { routeHelper: C } = r.useContext(P.A),
            j = r.useContext(h.A);
          u[0] !== d || u[1] !== y || u[2] !== A || u[3] !== f || u[4] !== I
            ? ((t = {
                isOriginalsPage: !0,
                page: f,
                shouldFetchGamesOnClient: I,
                crawlerGames: d,
                extraDesktopGames: y,
                isCrawler: A,
              }),
              (u[0] = d),
              (u[1] = y),
              (u[2] = A),
              (u[3] = f),
              (u[4] = I),
              (u[5] = t))
            : (t = u[5]);
          let { modelGames: G, loading: M } = (0, O.A)(t);
          u[6] !== C
            ? ((n = (e) => C.originalsPageLink(e)), (u[6] = C), (u[7] = n))
            : (n = u[7]);
          let L = n;
          return (
            u[8] === Symbol.for("react.memo_cache_sentinel")
              ? ((o = (0, a.jsx)(w.A, { title: "Originals" })), (u[8] = o))
              : (o = u[8]),
            u[9] === Symbol.for("react.memo_cache_sentinel")
              ? ((s = (0, z.A)(v().gridContainer)), (u[9] = s))
              : (s = u[9]),
            u[10] !== j || u[11] !== G.items || u[12] !== f
              ? ((l = (0, a.jsx)("div", {
                  className: s,
                  children: (0, g.PS)(j)
                    ? (0, a.jsx)(b.A, {
                        games: G.items,
                        justifyContent: "center",
                        slidesToLoadEagerly: p.CJ,
                        className: k().fullWidthExperiment,
                        removeThumbLabels: ["originals"],
                      })
                    : (0, a.jsx)(x.A, {
                        isFirstPage: 1 === f,
                        games: G.items,
                        removeThumbLabels: ["originals"],
                      }),
                })),
                (u[10] = j),
                (u[11] = G.items),
                (u[12] = f),
                (u[13] = l))
              : (l = u[13]),
            u[14] !== M || u[15] !== G || u[16] !== L
              ? ((c = (0, a.jsx)(m.A, {
                  loading: M,
                  games: G,
                  urlGenerator: L,
                })),
                (u[14] = M),
                (u[15] = G),
                (u[16] = L),
                (u[17] = c))
              : (c = u[17]),
            u[18] !== l || u[19] !== c
              ? ((_ = (0, a.jsx)(B.x, {
                  newClickOrigin: "originalsPage",
                  children: (0, a.jsxs)("div", {
                    className: v().root,
                    children: [
                      o,
                      (0, a.jsx)("div", {
                        className: v().container,
                        children: (0, a.jsxs)("div", {
                          className: v().gridWrapper,
                          children: [l, c],
                        }),
                      }),
                    ],
                  }),
                })),
                (u[18] = l),
                (u[19] = c),
                (u[20] = _))
              : (_ = u[20]),
            _
          );
        };
        var C = n(20183),
          j = n(66670);
        let G = (e) => {
          let t,
            n,
            s,
            l,
            g,
            c,
            _,
            u = (0, i.c)(24),
            {
              alternatives: d,
              games: z,
              extraDesktopGames: m,
              isCrawler: B,
              page: h,
            } = e,
            { i18n: p } = (0, o.uB)(),
            { routeHelper: O } = (0, r.useContext)(P.A);
          u[0] !== h || u[1] !== O
            ? ((t = O.originalsPageCanonical(h)),
              (u[0] = h),
              (u[1] = O),
              (u[2] = t))
            : (t = u[2]);
          let b = t;
          u[3] !== p
            ? ((n = p._({ id: "originals.head.title" })),
              (u[3] = p),
              (u[4] = n))
            : (n = u[4]),
            u[5] !== p || u[6] !== h
              ? ((s =
                  h > 1 ? ` - ${p._({ id: "games.title.page" })} ${h}` : ""),
                (u[5] = p),
                (u[6] = h),
                (u[7] = s))
              : (s = u[7]);
          let w = `${n} ${s}`;
          u[8] !== p
            ? ((l = p._({ id: "originals.head.metaDescription" })),
              (u[8] = p),
              (u[9] = l))
            : (l = u[9]),
            u[10] !== d || u[11] !== b || u[12] !== w || u[13] !== l
              ? ((g = (0, a.jsx)(y.A, {
                  canonical: b,
                  alternatives: d,
                  title: w,
                  metaDescription: l,
                })),
                (u[10] = d),
                (u[11] = b),
                (u[12] = w),
                (u[13] = l),
                (u[14] = g))
              : (g = u[14]);
          let x = !B;
          return (
            u[15] !== m ||
            u[16] !== z ||
            u[17] !== B ||
            u[18] !== h ||
            u[19] !== x
              ? ((c = (0, a.jsx)(A, {
                  crawlerGames: z,
                  extraDesktopGames: m,
                  shouldFetchGamesOnClient: x,
                  page: h,
                  isCrawler: B,
                })),
                (u[15] = m),
                (u[16] = z),
                (u[17] = B),
                (u[18] = h),
                (u[19] = x),
                (u[20] = c))
              : (c = u[20]),
            u[21] !== g || u[22] !== c
              ? ((_ = (0, a.jsxs)(a.Fragment, { children: [g, c] })),
                (u[21] = g),
                (u[22] = c),
                (u[23] = _))
              : (_ = u[23]),
            _
          );
        };
        G.getInitialProps = async (e) => {
          let { modelService: t, crawlerService: n } = (0, d.V)(e),
            a = (0, s.AJ)(),
            i = (0, g.hz)(e),
            r = "true" === e.query[c.pr],
            o = e.query[c.Sh] || 1,
            y = (0, l.z)(o),
            z = (0, _.Fs)(i),
            m = {
              items: [],
              pagination: { page: 1, size: 0 },
              total: 0,
              includesIneligibleGames: !1,
            };
          return (
            r &&
              (m = await n.getModelGamesForOriginalsPageForCrawler(i, y, u.F_))
                .includesIneligibleGames &&
              (z = !1),
            {
              alternatives: a,
              games: m,
              extraDesktopGames: z ? await (0, _.oP)(t, y) : void 0,
              isCrawler: r,
              page: y,
            }
          );
        };
        let M = (0, C.A)("games", "originals")((0, j.A)(G));
      },
    },
    (e) => {
      e.O(
        0,
        [
          6847, 5869, 89247, 88823, 67088, 67473, 22694, 32627, 46593, 90636,
          38792,
        ],
        () => e((e.s = 89051))
      ),
        (_N_E = e.O());
    },
  ]);
