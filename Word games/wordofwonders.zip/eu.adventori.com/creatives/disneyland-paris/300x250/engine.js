function initClick(idFrame) {
  return (
    "ADventori.click(event,{id:'frame" +
    idFrame +
    "', data: {url:'" +
    ADventori.data.frames["frame" + idFrame].data.url +
    "'}})"
  );
}

(function addStyleSheet() {
  var style = "";
  style +=
    "span.textADventori{font-size:inherit;line-height:inherit;font-family:inherit;display:inline-block;font-weight:inherit;}";
  var css = document.createElement("style");
  css.type = "text/css";
  css.id = "MTStyleSheet";
  css.innerHTML = style;
  document.head.appendChild(css);
})();

/**
 * Set a text into an element, it can fit the text to its container.
 * @param {string} elem - The text container
 * @param {string} data - The text to insert in the html container
 * @param {Object} conf - Optional - If present, it activates the adapt text function, you just have to put the fittext parameters
 */
function setText(elem, data, conf) {
  var conf = conf;
  if (elem) {
    var el = elem;
    ADventori.Display.setText(el, data);
    if (typeof conf == "object" && typeof conf != "undefined") {
      if (conf && conf.minFontSize)
        ADventori.Display.adaptText(el, conf.minFontSize);
    }
  }
}

/**
 * Init the HTML structure of the meta template
 * @param {string} elem - The html container to insert the meta template
 */
function initHtml(container) {
  var htmlStructure = "";
  for (var i = 1; i <= Object.keys(ADventori.data.frames).length; i++) {
    if (
      ADventori.data.frames["frame" + i] &&
      ADventori.data.frames["frame" + i]["template"] &&
      templates[ADventori.data.frames["frame" + i]["template"]]
    )
      htmlStructure +=
        templates[ADventori.data.frames["frame" + i]["template"]](i);
  }
  document
    .querySelector(container)
    .insertAdjacentHTML("beforeend", htmlStructure);
}

/**
 * Init the animation timeline
 */
function initAnimation() {
  var frames = document.querySelectorAll("[data-template]");
  for (var i = 1; i <= Object.keys(ADventori.data.frames).length; i++) {
    if (
      ADventori.data.frames["frame" + i] &&
      ADventori.data.frames["frame" + i]["template"]
    ) {
      var frame = document.querySelector(
        '[data-template="' +
          [ADventori.data.frames["frame" + i]["template"]] +
          '"]'
      );
      if (frame) {
        var animationFunction = frame.getAttribute("data-animation-function");
        var timeDuration = frame.getAttribute("data-time-duration") * 1000;
        animation[animationFunction](time, i);
        time += timeDuration;
      }
    }
  }
}

/**
 * Init the dynamisation
 */
function initDynamisation() {
  var frames = document.querySelectorAll("[data-id-frame]");
  for (var i = 0; i < frames.length; i++) {
    var dynPath =
      frames[i].getAttribute("data-id-frame") == "global"
        ? "global"
        : "frames." + frames[i].getAttribute("data-id-frame") + ".data";
    var dynElements = frames[i].querySelectorAll("[data-adventori-dyn]");
    for (var j = 0; j < dynElements.length; j++) {
      var data = "",
        dynFunction = "",
        conf = {};
      dynFunction = dynElements[j].getAttribute("data-adventori-dyn");
      if (dynElements[j].getAttribute("data-adventori-dyn-data"))
        data = eval(
          "ADventori.data." +
            dynPath +
            "." +
            dynElements[j].getAttribute("data-adventori-dyn-data")
        );
      if (dynElements[j].getAttribute("data-adventori-dyn-conf"))
        conf = JSON.parse(
          dynElements[j]
            .getAttribute("data-adventori-dyn-conf")
            .replace(/`/g, '"')
        );
      switch (dynFunction) {
        case "setText":
          if (hasValue(data)) {
            if (conf && (conf.minFontSize || conf.alignV)) {
              setText(dynElements[j], data, conf);
            } else {
              setText(dynElements[j], data);
            }
          } else {
            console.log(
              "SetText : You missed the data parameter !",
              dynElements[j]
            );
          }
          break;
        case "addImage":
          if (hasValue(data)) {
            if (conf && conf.imgDefault) {
              ADventori.Display.addImage(dynElements[j], data, conf.imgDefault);
            } else {
              console.log(
                "AddImage : You missed the conf.imgDefault parameter !",
                dynElements[j]
              );
            }
          } else {
            console.log(
              "AddImage : You missed the data parameter !",
              dynElements[j]
            );
          }
          break;
        default:
          console.log(dynFunction[k] + " is not an ADventori function !");
      }
    }
  }
}

/**
 * Init the HTML structure of the meta template
 * @param {string} value - The time (in second) where the frame will be displayed
 * @param {string} idFrame - ID of the Frame
 */
function chooseFrameTime(value, idFrame) {
  var frameTime,
    actualValue = value,
    tempValue;
  if (
    ADventori.data.frames["frame" + idFrame] &&
    hasValue(ADventori.data.frames["frame" + idFrame].animations) &&
    hasValue(ADventori.data.frames["frame" + idFrame].animations.frameTime)
  ) {
    tempValue = parseFloat(
      ADventori.data.frames["frame" + idFrame].animations.frameTime
    );
    if (actualValue < tempValue) {
      frameTime = tempValue;
    } else {
      frameTime = actualValue;
    }
  } else {
    frameTime = actualValue;
  }
  return frameTime;
}

/**
 * Remove a class from a HTML element
 * @param {string} el - The HTML element to target
 * @param {string} className - The name of the class to remove
 */
function removeClass(el, className) {
  document.querySelector(el).className = document
    .querySelector(el)
    .className.replace(new RegExp("\\b" + className + "\\b", "g"), "");
}

/**
 * Add a class to a HTML element
 * @param {string} el - The HTML element to target
 * @param {string} className - The name of the class to add
 */
function addClass(el, className) {
  if (!hasClass(el, className))
    document.querySelector(el).className += " " + className;
}

/**
 * Check if a class is present on a HTML element
 * @param {string} el - The HTML element to target
 * @param {string} className - The name of the class
 */
function hasClass(el, className) {
  return new RegExp("\\b" + className + "\\b").test(
    document.querySelector(el).className
  );
}

/**
 * Toggle a class is present on a HTML element
 * @param {string} el - The HTML element to target
 * @param {string} className - The name of the class
 */
function toggleClass(el, className) {
  hasClass(el, className)
    ? removeClass(el, className)
    : addClass(el, className);
}

/**
 * Timeline function
 * @param {Object} conf - settings.
 * @param {int} conf.time - time to launch animation
 * @param {string} conf.element - The HTML element to target
 * @param {string} conf.className - The name of the class
 * @param {function} conf.callBack - The name of the function
 * timeLine({time:{{int}}, element:{{string}}, className:{{string}} });
 * timeLine({time:{{int}}, callBack:{{function}} });
 */
function timeLine(conf) {
  var conf = conf || {};
  conf.callBack
    ? setTimeout(function () {
        eval(conf.callBack);
      }, conf.time)
    : setTimeout(function () {
        if (document.querySelector(conf.element)) {
          toggleClass(conf.element, conf.className);
        }
      }, conf.time);
}

/**
 * Check if a variable exists
 * @param {string} variable - The variable to check if it exists
 */
function hasValue(variable) {
  return (
    typeof variable !== "undefined" &&
    variable != null &&
    variable != "" &&
    variable != " " &&
    variable != "&nbsp;"
  );
}

/**
 * Combine data, placeholders and translations
 * @param {Object} data - Metatemplate json { frames:{}, global:{} }
 * @param {Object} placeholders - The name of the class
 * @param {Object} translations - The name of the class
 */
function combine(data, placeholders, translations) {
  if (data && typeof data.frames === "object") {
    for (var frame in data.frames) {
      var frameData = data.frames[frame].data;
      if (typeof translations === "object") {
        for (var key in frameData) {
          if (key.indexOf("§") == 0) {
            var translation = translations[frameData[key]];
            if (translation) {
              frameData[key.substring(1)] = translation;
            }
          }
        }
      }
      if (typeof placeholders === "object") {
        for (var key in frameData) {
          if (key.indexOf("§") < 0) {
            var missingPlaceholder = false;
            var value = frameData[key]
              .toString()
              .replace(/\{\{\s*(.*?)\s*\}\}/g, function (x) {
                var placeHolderValue =
                  placeholders[x.substring(2, x.length - 2).trim()];
                missingPlaceholder = missingPlaceholder || !placeHolderValue;
                return placeHolderValue;
              });
            frameData[key] = missingPlaceholder ? "" : value;
          }
        }
      }
    }
  }
  if (data && typeof data.global === "object") {
    if (typeof translations === "object") {
      for (var key in data.global) {
        if (key.indexOf("§") == 0) {
          var translation = translations[data.global[key]];
          if (translation) {
            data.global[key.substring(1)] = translation;
          }
        }
      }
    }
    if (typeof placeholders === "object") {
      for (var key in data.global) {
        if (key.indexOf("§") < 0) {
          var missingPlaceholder = false;
          var value = data.global[key].replace(
            /\{\{\s*(.*?)\s*\}\}/g,
            function (x) {
              var placeHolderValue =
                placeholders[x.substring(2, x.length - 2).trim()];
              missingPlaceholder = missingPlaceholder || !placeHolderValue;
              return placeHolderValue;
            }
          );
          data.global[key] = missingPlaceholder ? "" : value;
        }
      }
    }
  }
  return data;
}

function docReady(fn) {
  if (
    document.readyState === "complete" ||
    document.readyState === "interactive"
  ) {
    setTimeout(fn, 0);
  } else {
    document.addEventListener("DOMContentLoaded", fn);
  }
}
