(function () {
  "use strict";
  try {
    if (typeof document < "u") {
      var t = document.createElement("style");
      t.appendChild(
        document.createTextNode(
          '@import"https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap";*,*:before,*:after{border-color:#fff}*{outline:none;box-sizing:border-box;margin:0;padding:0}html{font-size:16px;overflow:hidden}body{font-family:Roboto,Helvetica,Arial,Verdana,sans-serif;color:#000;background:#fff;height:100vh;line-height:1;font-weight:400;overflow:hidden}a{color:#000;text-decoration:none}a:hover{text-decoration:none}#container{display:block;width:100vw;height:100vh;border:var(--container-border);border-radius:var(--border-radius);overflow:hidden}#text-part{cursor:pointer}#media-part{background-color:#000;background-size:cover;background-repeat:no-repeat;background-position:center;cursor:pointer}#video-root{width:100%;height:100%;cursor:default}.asset-disclaimer{font-weight:500;letter-spacing:.15px;color:#5b5656;line-height:18.75px;size:16px;flex:1 1 auto;margin-left:8px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.asset-title{font-weight:500;letter-spacing:.15px;color:#000}.asset-description{font-weight:400;color:#000}.asset-cta{padding:7px 8px;font-family:Roboto,sans-serif;font-style:normal;font-weight:700;font-size:16px;line-height:18.75px;letter-spacing:.25px;text-transform:uppercase;color:#1262eb;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}#layout-320x100{display:flex;flex-flow:row nowrap;height:100%;width:100%;align-items:center;background:#fff}#layout-320x100 #text-part{flex:1;height:100%;display:flex;flex-direction:column}#layout-320x100 #text-part .top-row{display:flex;align-items:center;padding:8px}#layout-320x100 #text-part .top-row .asset-disclaimer{flex:1 1 auto}#layout-320x100 #text-part .top-row .asset-adchoices{margin:4px 8px 0 0}#layout-320x100 #text-part .bottom-row{flex:1;display:flex;flex-direction:column;justify-content:center;height:100%}#layout-320x100 #text-part .bottom-row .asset-title{font-size:16px;line-height:1;margin:0 9px 5px}#layout-320x100 #text-part .bottom-row .asset-cta{font-size:12px;margin:5px 9px 3px}#layout-320x50{display:flex;flex-flow:row nowrap;height:100%;width:100%;align-items:center;background:#fff}#layout-320x50 #text-part{flex:1;height:100%}#layout-320x50 #text-part .top-row{display:flex;align-items:center;padding:4px}#layout-320x50 #text-part .top-row .asset-disclaimer{flex:1 1 auto}#layout-320x50 #text-part .top-row .asset-adchoices{margin:4px 8px 0 0}#layout-320x50 #text-part .asset-title{font-size:12px;line-height:14px;margin:0 8px 8px}#layout-728x90{display:flex;flex-flow:row nowrap;height:100%;width:100%;align-items:center;background:#fff}#layout-728x90 #text-part{flex:1;height:100%;display:flex;flex-direction:column}#layout-728x90 #text-part .top-row{display:flex;align-items:center;padding:8px}#layout-728x90 #text-part .top-row .asset-disclaimer{flex:1 1 auto;font-size:11px;line-height:12px}#layout-728x90 #text-part .top-row .asset-adchoices{margin:4px 8px 0 0}#layout-728x90 #text-part .bottom-row{flex:1;display:flex;flex-direction:column;justify-content:center}#layout-728x90 #text-part .bottom-row .asset-title,#layout-728x90 #text-part .bottom-row .asset-cta{font-size:14px;line-height:1;margin:0 16px 5px}#layout-970x90{display:flex;flex-flow:row nowrap;height:100%;width:100%;align-items:center;background:#fff}#layout-970x90 #text-part{flex:1;height:100%}#layout-970x90 #text-part .top-row{display:flex;align-items:center;padding:8px}#layout-970x90 #text-part .top-row .asset-disclaimer{flex:1 1 auto;font-size:11px;line-height:12px}#layout-970x90 #text-part .top-row .asset-adchoices{margin:4px 8px 0 0}#layout-970x90 #text-part .bottom-row{flex:1;flex-direction:column;justify-content:center}#layout-970x90 #text-part .bottom-row .asset-title{font-size:14px;line-height:13px;margin:0 16px 7px}#layout-970x90 #text-part .bottom-row .asset-cta{font-size:12px;margin:0 16px 5px;padding:3px}:root{--primary-color: rgb(0, 0, 0);--secondary-color: rgba(255, 255, 255, .08);--button-border-color: #ffffff;--button-font-size: 16px;--button-line-height: 19px}.container{width:100%;height:100%;display:flex;justify-content:center;align-items:center;background-color:var(--primary-color)}.vertical-container{flex-direction:column}.horizontal-container{flex-direction:row}.button-container{display:flex;align-items:center;justify-content:center}.cta-button{display:flex;justify-content:center;align-items:center;padding:10px 20px;border-radius:5px;background-color:var(--secondary-color);border:1px solid var(--button-border-color);font-family:Roboto,Helvetica,Arial,Verdana,sans-serif;font-weight:700;font-size:var(--button-font-size);line-height:var(--button-line-height);letter-spacing:.15px;text-transform:uppercase;color:#fff}#layout-square{display:flex;flex-flow:column nowrap;height:100%;width:100%;background:#fff}#layout-square #text-part{display:flex;flex-direction:column;flex-grow:1;min-width:1px}#layout-square #text-part .top-row{display:flex;flex:1;flex-direction:column;padding:0 0 0 5px;justify-content:center}#layout-square #text-part .top-row .asset-title{font-size:var(--title-font-size);line-height:20px;font-weight:500}#layout-square #text-part .top-row .asset-description{font-size:12px;line-height:14.06px;font-weight:400}#layout-square #text-part .bottom-row{border-top:1px solid #e5e6e6;padding:0 0 0 8px;align-items:center;height:40px;display:flex;overflow:hidden}#layout-square #text-part .bottom-row img{width:24px;height:24px}#layout-square #text-part .bottom-row .asset-disclaimer{font-size:12px;line-height:14.06px;font-weight:500}#layout-square #text-part .bottom-row .asset-cta{font-size:12px;line-height:14.06px;font-weight:700;text-align:center;padding:16px;text-overflow:unset}#layout-square #text-part .bottom-row .asset-cta-button{padding:10px 24px;min-width:60px}#layout-square #text-part .bottom-row .asset-cta:hover{background-color:#1262eb0a}#layout-square.hasValidMedia #text-part .bottom-row .asset-title{font-size:16px;line-height:17px}#layout-tall{display:flex;flex-flow:column nowrap;height:100%;width:100%;background:#fff}#layout-tall #text-part{flex:1;display:flex;flex-direction:column;width:100%;justify-content:space-between}#layout-tall #text-part .top-row{display:flex;flex:1;flex-direction:column;justify-content:var(--justify-content);padding:24px}#layout-tall #text-part .top-row .asset-title{font-size:24px;line-height:26px;margin-bottom:24px}#layout-tall #text-part .top-row .asset-description{font-size:16px;line-height:18.75px;margin-bottom:8px}#layout-tall #text-part .top-row .brand-row{line-height:18.75px;font-size:16px;font-weight:400;letter-spacing:.15px;display:flex;align-items:center;margin-top:24px}#layout-tall #text-part .top-row .brand-row img{width:32px;height:32px}#layout-tall #text-part .top-row .brand-row .ad-label{font-size:12px}#layout-tall #text-part .bottom-row{border-top:1px solid #e5e6e6;padding:0 24px;align-items:center;height:83px;display:flex;justify-content:center}#layout-tall #text-part .bottom-row:hover{background-color:#1262eb0a}#layout-video-square{display:flex;flex-flow:column nowrap;height:100%;width:100%;background:#3d4043;color:#fff}#layout-video-square #text-part{display:flex;flex-direction:column;flex-grow:1;min-width:1px}#layout-video-square #text-part .video-bottom-row{display:flex;flex:1;justify-content:right;align-items:center}#layout-video-square.hasValidMedia #text-part .bottom-row .asset-title{font-size:16px;line-height:17px}#layout-video-square .video-cta{font-weight:700;font-size:10px;letter-spacing:.15px;line-height:14px;display:flex;flex-direction:row;justify-content:center;align-items:center;padding:7px 12px;background:#ffffff14;border-radius:4px}#layout-video-square .video-cta:hover{background-color:#ffffff29}#layout-video-tall{display:flex;flex-flow:column nowrap;height:100%;width:100%;background:#3d4043;color:#fff}#layout-video-tall #text-part{display:flex;flex-direction:column;flex-grow:1;min-width:1px}#layout-video-tall #text-part .video-bottom-row{display:flex;flex:1;justify-content:right;align-items:center}#layout-video-tall.hasValidMedia #text-part .bottom-row .asset-title{font-size:16px;line-height:17px}#layout-video-tall .video-cta{font-weight:700;font-size:12px;letter-spacing:.15px;line-height:14px;display:flex;flex-direction:row;justify-content:center;align-items:center;padding:8.75px 15px;margin:0 20px;background:#ffffff14;border-radius:4px}#layout-video-tall .video-cta:hover{background-color:#ffffff29}#layout-video-wide{display:flex;flex-flow:row nowrap;height:100%;width:100%;background:#3d4043;color:#fff}#layout-video-wide #spacer{flex-grow:1;min-width:1px}#layout-video-wide #text-part{display:flex;flex-direction:column;flex-grow:1;flex-basis:0}#layout-video-wide #text-part .video-bottom-row{display:flex;flex:1;justify-content:center;align-items:center}#layout-video-wide.hasValidMedia #text-part .bottom-row .asset-title{font-size:16px;line-height:17px}#layout-video-wide .video-cta{font-weight:700;font-size:12px;letter-spacing:.15px;line-height:14px;display:flex;flex-direction:row;justify-content:center;align-items:center;padding:7px 12px;background:#ffffff14;border-radius:4px}#layout-video-wide .video-cta:hover{background-color:#ffffff29}#layout-wide{display:flex;flex-flow:row nowrap;height:100%;width:100%;align-items:center;background:#fff}@media (max-height: 180px){#layout-wide .asset-description{-webkit-line-clamp:1}}@media (max-height: 160px){#layout-wide .asset-title{-webkit-line-clamp:1}}#layout-wide #text-part{flex:1;display:flex;flex-direction:column;height:100%;min-width:1px;justify-content:space-between}#layout-wide #text-part .top-row{display:flex;flex-direction:column;justify-content:center;height:165px;padding:0 24px;margin-bottom:16px}#layout-wide #text-part .top-row .asset-title{font-size:22px;line-height:28px;margin-bottom:8px}#layout-wide #text-part .top-row .asset-description{font-size:16px;line-height:21px}#layout-wide #text-part .bottom-row{border-top:1px solid #e5e6e6;padding:0 0 0 24px;align-items:center;height:66px;display:flex;overflow:hidden}#layout-wide #text-part .bottom-row img{width:40px;height:40px}#layout-wide #text-part .bottom-row .asset-cta{padding:24px;text-align:center;max-width:fit-content;text-overflow:unset}#layout-wide #text-part .bottom-row .asset-cta-button{padding:26px 24px 24px;min-width:60px}#layout-wide #text-part .bottom-row .asset-cta:hover{background-color:#1262eb0a}#layout-wide #text-part .bottom-row .ad-label{font-size:12px}.asset-adchoices[data-v-05e566f5]{position:fixed;right:var(--right-position);top:var(--top-position);z-index:1}svg[data-v-05e566f5]{fill:#00aecd;background-color:var(--background-color);border-radius:0px var(--border-radius) 0px 0px;opacity:var(--opacity-percentage)}svg[data-v-05e566f5]:hover{fill:#000}.ad-label{text-transform:uppercase;font-size:10px;font-weight:700;color:#5b5656;line-height:14px;background-color:#eeeeee80;padding:4px;border-radius:4px}.asset-cta-button>svg{width:var(--icon-width);height:auto}.asset-description{display:-webkit-box;-webkit-box-orient:vertical;-webkit-line-clamp:var(--max-lines);line-clamp:var(--max-lines);overflow:hidden}.asset-disclaimer{font-size:16px}#media-part{background-color:#fff;height:var(--height);width:var(--width);border-right:var(--border-right-width) solid #e5e6e6;border-bottom:var(--border-bottom-width) solid #e5e6e6;transform:translateZ(.000000001px);overflow:hidden}#media-part img{position:absolute}#media-part .foreground{width:calc(var(--width) - var(--border-right-width));height:calc(var(--height) - var(--border-bottom-width));object-fit:contain;filter:drop-shadow(0 0 4px rgba(0,0,0,.5))}#media-part .background{width:calc(var(--width) + 20px);height:calc(var(--height) + 20px);top:-10px;left:-10px;filter:blur(15px);opacity:.5}.asset-title{display:-webkit-box;-webkit-box-orient:vertical;-webkit-line-clamp:var(--max-lines);overflow:hidden}#video-root{background-color:#000}#video-container>div.jw-wrapper.jw-reset>div.jw-controls.jw-reset>div.jw-controlbar.jw-reset>div.jw-reset.jw-button-container>div.jw-icon.jw-icon-tooltip.jw-icon-volume.jw-button-color.jw-reset{position:absolute;bottom:1px}#video-container>div.jw-wrapper.jw-reset>div.jw-controls.jw-reset>div.jw-controlbar.jw-reset>div.jw-reset.jw-button-container>div.jw-icon.jw-icon-tooltip.jw-icon-volume.jw-button-color.jw-reset>div>div{left:20px;bottom:5px}#video-container>div.jw-wrapper.jw-reset>div.jw-controls.jw-reset>div.jw-controlbar.jw-reset>div.jw-reset.jw-button-container>div.jw-icon.jw-icon-inline.jw-button-color.jw-reset.jw-icon-volume.jw-full{bottom:1px}#video-container>div.jw-wrapper.jw-reset>div.jw-controls.jw-reset>div.jw-controlbar.jw-reset{opacity:100%;visibility:visible}#video-container>div.jw-wrapper.jw-reset>div.jw-controls.jw-reset>div.jw-controlbar.jw-reset>div.jw-reset.jw-button-container>div.jw-icon.jw-icon-inline.jw-button-color.jw-reset.jw-icon-volume{position:absolute;left:0}#video-container>div.jw-wrapper.jw-reset>div.jw-controls.jw-reset>div.jw-controlbar.jw-reset>div.jw-reset.jw-button-container>div.jw-icon.jw-icon-inline.jw-button-color.jw-reset.jw-icon-playback,#video-container>div.jw-wrapper.jw-reset>div.jw-controls.jw-reset>div.jw-controlbar.jw-reset>div.jw-reset.jw-button-container>span,#video-container>div.jw-wrapper.jw-reset>div.jw-controls.jw-reset>div.jw-controlbar.jw-reset>div.jw-reset.jw-button-container>div:nth-child(17){visibility:hidden}#video-container>div.jw-wrapper.jw-reset>div.jw-controls.jw-reset>div.jw-controlbar.jw-reset>div.jw-reset.jw-button-container>div.jw-icon.jw-icon-tooltip.jw-icon-volume.jw-button-color.jw-reset{position:absolute;left:0}#video-container>div.jw-wrapper.jw-reset>div.jw-controls.jw-reset>div.jw-controlbar.jw-reset>div.jw-reset.jw-button-container>div.jw-icon.jw-icon-tooltip.jw-icon-volume.jw-open:after{opacity:0}#video-container>div.jw-wrapper.jw-reset>div.jw-controls.jw-reset>div.jw-controlbar.jw-reset>div.jw-slider-time.jw-background-color.jw-reset.jw-slider-horizontal.jw-reset{background-color:#4d4f5299}#video-container>div.jw-wrapper.jw-reset>div.jw-controls.jw-reset>div.jw-controlbar.jw-reset>div.jw-slider-time.jw-background-color.jw-reset.jw-slider-horizontal.jw-reset>div>div.jw-progress.jw-reset{background-color:#fff;border-radius:0 10px 10px 0}#video-container>div.jw-wrapper.jw-reset>div.jw-controls.jw-reset>div.jw-controlbar.jw-reset>div.jw-reset.jw-button-container>div.jw-icon.jw-icon-inline.jw-button-color.jw-reset.jw-icon-pip{visibility:hidden}#video-container>div.jw-wrapper.jw-reset>div.jw-controls.jw-reset>div.jw-controlbar.jw-reset>div.jw-reset.jw-button-container>div.jw-icon.jw-icon-inline.jw-text.jw-reset.jw-text-countdown{visibility:hidden}#video-container>div.jw-wrapper.jw-reset{background-color:#000}#video-container>div.jw-wrapper.jw-reset>div.jw-controls-backdrop{visibility:hidden}#video-container>div.jw-wrapper.jw-reset>div.jw-controls.jw-reset>div.jw-skip.jw-reset{visibility:hidden}#video-container>div.jw-wrapper.jw-reset:hover>div.jw-controls.jw-reset{background:linear-gradient(to bottom,transparent,rgba(0,0,0,.4) 77%,rgba(0,0,0,.4) 100%) 100% 100%}#video-container>div.jw-wrapper.jw-reset:hover>div.jw-controls.jw-reset>.jw-reset{visibility:visible;background:#0000}#video-container>div.jw-wrapper.jw-reset:hover>div.jw-controls.jw-reset>div.jw-controlbar.jw-reset>div.jw-reset.jw-button-container>div.jw-icon.jw-icon-inline.jw-button-color.jw-reset.jw-icon-playback{visibility:visible;position:absolute;left:30px}#video-container>div.jw-wrapper.jw-reset>div.jw-controls.jw-reset{display:block}#video-container>div.jw-wrapper.jw-reset>div.jw-controls.jw-reset>div.jw-controlbar.jw-reset>div.jw-reset.jw-button-container>div.jw-icon.jw-icon-inline.jw-button-color.jw-reset.jw-icon-playback{bottom:1px}#video-container>div.jw-wrapper.jw-reset>div.jw-controls.jw-reset>div.jw-controlbar.jw-reset>div.jw-reset.jw-button-container>div.jw-icon.jw-icon-inline.jw-button-color.jw-reset.jw-icon-volume.jw-off{bottom:1px}#video-container>div.jw-wrapper.jw-reset>div.jw-controls.jw-reset>div.jw-controlbar.jw-reset>div.jw-reset.jw-button-container>div.jw-icon.jw-icon-tooltip.jw-icon-volume.jw-button-color.jw-reset.jw-off{bottom:1px}.jwplayer.jw-state-complete .jw-controls{background:#000000ad!important}#video-container_vast>div{position:absolute;top:0;right:0}#video-container>div.jw-wrapper.jw-reset>div.jw-controls.jw-reset>div.jw-controlbar.jw-reset>div.jw-reset.jw-button-container>div.jw-icon.jw-icon-inline.jw-text.jw-reset.jw-text-elapsed,#video-container>div.jw-wrapper.jw-reset>div.jw-controls.jw-reset>div.jw-controlbar.jw-reset>div.jw-reset.jw-button-container>div.jw-icon.jw-icon-inline.jw-text.jw-reset.jw-text-duration,#video-container>div.jw-wrapper.jw-reset>div.jw-controls.jw-reset>div.jw-controlbar.jw-reset>div.jw-reset.jw-button-container>div.jw-icon.jw-icon-inline.jw-button-color.jw-reset.jw-icon-rewind,#video-container>div.jw-wrapper.jw-reset>div.jw-controls.jw-reset>div.jw-display.jw-reset>div>div>div.jw-display-icon-container.jw-display-icon-display.jw-reset>div>svg.jw-svg-icon.jw-svg-icon-play,#video-container>div.jw-wrapper.jw-reset>div.jw-controls.jw-reset>div.jw-display.jw-reset>div>div>div.jw-display-icon-container.jw-display-icon-display.jw-reset>div>svg.jw-svg-icon.jw-svg-icon-pause{visibility:hidden}#video-container>div.jw-wrapper.jw-reset>div.jw-controls.jw-reset>div.jw-controlbar.jw-reset>div.jw-reset.jw-button-container>div.jw-icon.jw-icon-inline.jw-button-color.jw-reset.jw-icon-volume.jw-off{display:block;left:5px;bottom:-9px}#video-container>div.jw-wrapper.jw-reset>div.jw-media.jw-reset{visibility:hidden}'
        )
      ),
        document.head.appendChild(t);
    }
  } catch (e) {
    console.error("vite-plugin-css-injected-by-js", e);
  }
})();
(function () {
  const t = document.createElement("link").relList;
  if (t && t.supports && t.supports("modulepreload")) return;
  for (const a of document.querySelectorAll('link[rel="modulepreload"]')) o(a);
  new MutationObserver((a) => {
    for (const f of a)
      if (f.type === "childList")
        for (const c of f.addedNodes)
          c.tagName === "LINK" && c.rel === "modulepreload" && o(c);
  }).observe(document, { childList: !0, subtree: !0 });
  function n(a) {
    const f = {};
    return (
      a.integrity && (f.integrity = a.integrity),
      a.referrerPolicy && (f.referrerPolicy = a.referrerPolicy),
      a.crossOrigin === "use-credentials"
        ? (f.credentials = "include")
        : a.crossOrigin === "anonymous"
        ? (f.credentials = "omit")
        : (f.credentials = "same-origin"),
      f
    );
  }
  function o(a) {
    if (a.ep) return;
    a.ep = !0;
    const f = n(a);
    fetch(a.href, f);
  }
})();
const di = "IX Native:",
  qe = {
    info: function (...e) {
      window.enableFlexDebugLogging && console.info(di, ...e);
    },
    debug: function (...e) {
      window.enableFlexDebugLogging && console.debug(di, ...e);
    },
  };
/**
 * @vue/shared v3.5.12
 * (c) 2018-present Yuxi (Evan) You and Vue contributors
 * @license MIT
 **/ /*! #__NO_SIDE_EFFECTS__ */ function Ur(e) {
  const t = Object.create(null);
  for (const n of e.split(",")) t[n] = 1;
  return (n) => n in t;
}
const Ue = {},
  dn = [],
  Tt = () => {},
  ys = () => !1,
  Yn = (e) =>
    e.charCodeAt(0) === 111 &&
    e.charCodeAt(1) === 110 &&
    (e.charCodeAt(2) > 122 || e.charCodeAt(2) < 97),
  Nr = (e) => e.startsWith("onUpdate:"),
  Xe = Object.assign,
  Vr = (e, t) => {
    const n = e.indexOf(t);
    n > -1 && e.splice(n, 1);
  },
  vs = Object.prototype.hasOwnProperty,
  De = (e, t) => vs.call(e, t),
  Be = Array.isArray,
  hn = (e) => Qn(e) === "[object Map]",
  Yi = (e) => Qn(e) === "[object Set]",
  Oe = (e) => typeof e == "function",
  ze = (e) => typeof e == "string",
  Mt = (e) => typeof e == "symbol",
  He = (e) => e !== null && typeof e == "object",
  Qi = (e) => (He(e) || Oe(e)) && Oe(e.then) && Oe(e.catch),
  eo = Object.prototype.toString,
  Qn = (e) => eo.call(e),
  ws = (e) => Qn(e).slice(8, -1),
  to = (e) => Qn(e) === "[object Object]",
  Hr = (e) =>
    ze(e) && e !== "NaN" && e[0] !== "-" && "" + parseInt(e, 10) === e,
  kn = Ur(
    ",key,ref,ref_for,ref_key,onVnodeBeforeMount,onVnodeMounted,onVnodeBeforeUpdate,onVnodeUpdated,onVnodeBeforeUnmount,onVnodeUnmounted"
  ),
  er = (e) => {
    const t = Object.create(null);
    return (n) => t[n] || (t[n] = e(n));
  },
  bs = /-(\w)/g,
  mt = er((e) => e.replace(bs, (t, n) => (n ? n.toUpperCase() : ""))),
  xs = /\B([A-Z])/g,
  rn = er((e) => e.replace(xs, "-$1").toLowerCase()),
  tr = er((e) => e.charAt(0).toUpperCase() + e.slice(1)),
  fr = er((e) => (e ? `on${tr(e)}` : "")),
  Zt = (e, t) => !Object.is(e, t),
  dr = (e, ...t) => {
    for (let n = 0; n < e.length; n++) e[n](...t);
  },
  no = (e, t, n, o = !1) => {
    Object.defineProperty(e, t, {
      configurable: !0,
      enumerable: !1,
      writable: o,
      value: n,
    });
  },
  Ss = (e) => {
    const t = parseFloat(e);
    return isNaN(t) ? e : t;
  };
let hi;
const nr = () =>
  hi ||
  (hi =
    typeof globalThis < "u"
      ? globalThis
      : typeof self < "u"
      ? self
      : typeof window < "u"
      ? window
      : typeof global < "u"
      ? global
      : {});
function ye(e) {
  if (Be(e)) {
    const t = {};
    for (let n = 0; n < e.length; n++) {
      const o = e[n],
        a = ze(o) ? ks(o) : ye(o);
      if (a) for (const f in a) t[f] = a[f];
    }
    return t;
  } else if (ze(e) || He(e)) return e;
}
const _s = /;(?![^(]*\))/g,
  Cs = /:([^]+)/,
  Es = /\/\*[^]*?\*\//g;
function ks(e) {
  const t = {};
  return (
    e
      .replace(Es, "")
      .split(_s)
      .forEach((n) => {
        if (n) {
          const o = n.split(Cs);
          o.length > 1 && (t[o[0].trim()] = o[1].trim());
        }
      }),
    t
  );
}
function Pt(e) {
  let t = "";
  if (ze(e)) t = e;
  else if (Be(e))
    for (let n = 0; n < e.length; n++) {
      const o = Pt(e[n]);
      o && (t += o + " ");
    }
  else if (He(e)) for (const n in e) e[n] && (t += n + " ");
  return t.trim();
}
const Ts =
    "itemscope,allowfullscreen,formnovalidate,ismap,nomodule,novalidate,readonly",
  Ps = Ur(Ts);
function ro(e) {
  return !!e || e === "";
}
const io = (e) => !!(e && e.__v_isRef === !0),
  Ot = (e) =>
    ze(e)
      ? e
      : e == null
      ? ""
      : Be(e) || (He(e) && (e.toString === eo || !Oe(e.toString)))
      ? io(e)
        ? Ot(e.value)
        : JSON.stringify(e, oo, 2)
      : String(e),
  oo = (e, t) =>
    io(t)
      ? oo(e, t.value)
      : hn(t)
      ? {
          [`Map(${t.size})`]: [...t.entries()].reduce(
            (n, [o, a], f) => ((n[hr(o, f) + " =>"] = a), n),
            {}
          ),
        }
      : Yi(t)
      ? { [`Set(${t.size})`]: [...t.values()].map((n) => hr(n)) }
      : Mt(t)
      ? hr(t)
      : He(t) && !Be(t) && !to(t)
      ? String(t)
      : t,
  hr = (e, t = "") => {
    var n;
    return Mt(e) ? `Symbol(${(n = e.description) != null ? n : t})` : e;
  };
/**
 * @vue/reactivity v3.5.12
 * (c) 2018-present Yuxi (Evan) You and Vue contributors
 * @license MIT
 **/ let dt;
class As {
  constructor(t = !1) {
    (this.detached = t),
      (this._active = !0),
      (this.effects = []),
      (this.cleanups = []),
      (this._isPaused = !1),
      (this.parent = dt),
      !t && dt && (this.index = (dt.scopes || (dt.scopes = [])).push(this) - 1);
  }
  get active() {
    return this._active;
  }
  pause() {
    if (this._active) {
      this._isPaused = !0;
      let t, n;
      if (this.scopes)
        for (t = 0, n = this.scopes.length; t < n; t++) this.scopes[t].pause();
      for (t = 0, n = this.effects.length; t < n; t++) this.effects[t].pause();
    }
  }
  resume() {
    if (this._active && this._isPaused) {
      this._isPaused = !1;
      let t, n;
      if (this.scopes)
        for (t = 0, n = this.scopes.length; t < n; t++) this.scopes[t].resume();
      for (t = 0, n = this.effects.length; t < n; t++) this.effects[t].resume();
    }
  }
  run(t) {
    if (this._active) {
      const n = dt;
      try {
        return (dt = this), t();
      } finally {
        dt = n;
      }
    }
  }
  on() {
    dt = this;
  }
  off() {
    dt = this.parent;
  }
  stop(t) {
    if (this._active) {
      let n, o;
      for (n = 0, o = this.effects.length; n < o; n++) this.effects[n].stop();
      for (n = 0, o = this.cleanups.length; n < o; n++) this.cleanups[n]();
      if (this.scopes)
        for (n = 0, o = this.scopes.length; n < o; n++) this.scopes[n].stop(!0);
      if (!this.detached && this.parent && !t) {
        const a = this.parent.scopes.pop();
        a &&
          a !== this &&
          ((this.parent.scopes[this.index] = a), (a.index = this.index));
      }
      (this.parent = void 0), (this._active = !1);
    }
  }
}
function Is() {
  return dt;
}
let $e;
const pr = new WeakSet();
class so {
  constructor(t) {
    (this.fn = t),
      (this.deps = void 0),
      (this.depsTail = void 0),
      (this.flags = 5),
      (this.next = void 0),
      (this.cleanup = void 0),
      (this.scheduler = void 0),
      dt && dt.active && dt.effects.push(this);
  }
  pause() {
    this.flags |= 64;
  }
  resume() {
    this.flags & 64 &&
      ((this.flags &= -65), pr.has(this) && (pr.delete(this), this.trigger()));
  }
  notify() {
    (this.flags & 2 && !(this.flags & 32)) || this.flags & 8 || uo(this);
  }
  run() {
    if (!(this.flags & 1)) return this.fn();
    (this.flags |= 2), pi(this), co(this);
    const t = $e,
      n = vt;
    ($e = this), (vt = !0);
    try {
      return this.fn();
    } finally {
      lo(this), ($e = t), (vt = n), (this.flags &= -3);
    }
  }
  stop() {
    if (this.flags & 1) {
      for (let t = this.deps; t; t = t.nextDep) qr(t);
      (this.deps = this.depsTail = void 0),
        pi(this),
        this.onStop && this.onStop(),
        (this.flags &= -2);
    }
  }
  trigger() {
    this.flags & 64
      ? pr.add(this)
      : this.scheduler
      ? this.scheduler()
      : this.runIfDirty();
  }
  runIfDirty() {
    Tr(this) && this.run();
  }
  get dirty() {
    return Tr(this);
  }
}
let ao = 0,
  Tn,
  Pn;
function uo(e, t = !1) {
  if (((e.flags |= 8), t)) {
    (e.next = Pn), (Pn = e);
    return;
  }
  (e.next = Tn), (Tn = e);
}
function Zr() {
  ao++;
}
function Wr() {
  if (--ao > 0) return;
  if (Pn) {
    let t = Pn;
    for (Pn = void 0; t; ) {
      const n = t.next;
      (t.next = void 0), (t.flags &= -9), (t = n);
    }
  }
  let e;
  for (; Tn; ) {
    let t = Tn;
    for (Tn = void 0; t; ) {
      const n = t.next;
      if (((t.next = void 0), (t.flags &= -9), t.flags & 1))
        try {
          t.trigger();
        } catch (o) {
          e || (e = o);
        }
      t = n;
    }
  }
  if (e) throw e;
}
function co(e) {
  for (let t = e.deps; t; t = t.nextDep)
    (t.version = -1),
      (t.prevActiveLink = t.dep.activeLink),
      (t.dep.activeLink = t);
}
function lo(e) {
  let t,
    n = e.depsTail,
    o = n;
  for (; o; ) {
    const a = o.prevDep;
    o.version === -1 ? (o === n && (n = a), qr(o), Os(o)) : (t = o),
      (o.dep.activeLink = o.prevActiveLink),
      (o.prevActiveLink = void 0),
      (o = a);
  }
  (e.deps = t), (e.depsTail = n);
}
function Tr(e) {
  for (let t = e.deps; t; t = t.nextDep)
    if (
      t.dep.version !== t.version ||
      (t.dep.computed && (fo(t.dep.computed) || t.dep.version !== t.version))
    )
      return !0;
  return !!e._dirty;
}
function fo(e) {
  if (
    (e.flags & 4 && !(e.flags & 16)) ||
    ((e.flags &= -17), e.globalVersion === Bn)
  )
    return;
  e.globalVersion = Bn;
  const t = e.dep;
  if (((e.flags |= 2), t.version > 0 && !e.isSSR && e.deps && !Tr(e))) {
    e.flags &= -3;
    return;
  }
  const n = $e,
    o = vt;
  ($e = e), (vt = !0);
  try {
    co(e);
    const a = e.fn(e._value);
    (t.version === 0 || Zt(a, e._value)) && ((e._value = a), t.version++);
  } catch (a) {
    throw (t.version++, a);
  } finally {
    ($e = n), (vt = o), lo(e), (e.flags &= -3);
  }
}
function qr(e, t = !1) {
  const { dep: n, prevSub: o, nextSub: a } = e;
  if (
    (o && ((o.nextSub = a), (e.prevSub = void 0)),
    a && ((a.prevSub = o), (e.nextSub = void 0)),
    n.subs === e && ((n.subs = o), !o && n.computed))
  ) {
    n.computed.flags &= -5;
    for (let f = n.computed.deps; f; f = f.nextDep) qr(f, !0);
  }
  !t && !--n.sc && n.map && n.map.delete(n.key);
}
function Os(e) {
  const { prevDep: t, nextDep: n } = e;
  t && ((t.nextDep = n), (e.prevDep = void 0)),
    n && ((n.prevDep = t), (e.nextDep = void 0));
}
let vt = !0;
const ho = [];
function qt() {
  ho.push(vt), (vt = !1);
}
function zt() {
  const e = ho.pop();
  vt = e === void 0 ? !0 : e;
}
function pi(e) {
  const { cleanup: t } = e;
  if (((e.cleanup = void 0), t)) {
    const n = $e;
    $e = void 0;
    try {
      t();
    } finally {
      $e = n;
    }
  }
}
let Bn = 0;
class Bs {
  constructor(t, n) {
    (this.sub = t),
      (this.dep = n),
      (this.version = n.version),
      (this.nextDep =
        this.prevDep =
        this.nextSub =
        this.prevSub =
        this.prevActiveLink =
          void 0);
  }
}
class zr {
  constructor(t) {
    (this.computed = t),
      (this.version = 0),
      (this.activeLink = void 0),
      (this.subs = void 0),
      (this.map = void 0),
      (this.key = void 0),
      (this.sc = 0);
  }
  track(t) {
    if (!$e || !vt || $e === this.computed) return;
    let n = this.activeLink;
    if (n === void 0 || n.sub !== $e)
      (n = this.activeLink = new Bs($e, this)),
        $e.deps
          ? ((n.prevDep = $e.depsTail),
            ($e.depsTail.nextDep = n),
            ($e.depsTail = n))
          : ($e.deps = $e.depsTail = n),
        po(n);
    else if (n.version === -1 && ((n.version = this.version), n.nextDep)) {
      const o = n.nextDep;
      (o.prevDep = n.prevDep),
        n.prevDep && (n.prevDep.nextDep = o),
        (n.prevDep = $e.depsTail),
        (n.nextDep = void 0),
        ($e.depsTail.nextDep = n),
        ($e.depsTail = n),
        $e.deps === n && ($e.deps = o);
    }
    return n;
  }
  trigger(t) {
    this.version++, Bn++, this.notify(t);
  }
  notify(t) {
    Zr();
    try {
      for (let n = this.subs; n; n = n.prevSub)
        n.sub.notify() && n.sub.dep.notify();
    } finally {
      Wr();
    }
  }
}
function po(e) {
  if ((e.dep.sc++, e.sub.flags & 4)) {
    const t = e.dep.computed;
    if (t && !e.dep.subs) {
      t.flags |= 20;
      for (let o = t.deps; o; o = o.nextDep) po(o);
    }
    const n = e.dep.subs;
    n !== e && ((e.prevSub = n), n && (n.nextSub = e)), (e.dep.subs = e);
  }
}
const Pr = new WeakMap(),
  en = Symbol(""),
  Ar = Symbol(""),
  Rn = Symbol("");
function Qe(e, t, n) {
  if (vt && $e) {
    let o = Pr.get(e);
    o || Pr.set(e, (o = new Map()));
    let a = o.get(n);
    a || (o.set(n, (a = new zr())), (a.map = o), (a.key = n)), a.track();
  }
}
function jt(e, t, n, o, a, f) {
  const c = Pr.get(e);
  if (!c) {
    Bn++;
    return;
  }
  const s = (r) => {
    r && r.trigger();
  };
  if ((Zr(), t === "clear")) c.forEach(s);
  else {
    const r = Be(e),
      l = r && Hr(n);
    if (r && n === "length") {
      const d = Number(o);
      c.forEach((w, S) => {
        (S === "length" || S === Rn || (!Mt(S) && S >= d)) && s(w);
      });
    } else
      switch (
        ((n !== void 0 || c.has(void 0)) && s(c.get(n)), l && s(c.get(Rn)), t)
      ) {
        case "add":
          r ? l && s(c.get("length")) : (s(c.get(en)), hn(e) && s(c.get(Ar)));
          break;
        case "delete":
          r || (s(c.get(en)), hn(e) && s(c.get(Ar)));
          break;
        case "set":
          hn(e) && s(c.get(en));
          break;
      }
  }
  Wr();
}
function un(e) {
  const t = Me(e);
  return t === e ? t : (Qe(t, "iterate", Rn), wt(e) ? t : t.map(st));
}
function Kr(e) {
  return Qe((e = Me(e)), "iterate", Rn), e;
}
const Rs = {
  __proto__: null,
  [Symbol.iterator]() {
    return gr(this, Symbol.iterator, st);
  },
  concat(...e) {
    return un(this).concat(...e.map((t) => (Be(t) ? un(t) : t)));
  },
  entries() {
    return gr(this, "entries", (e) => ((e[1] = st(e[1])), e));
  },
  every(e, t) {
    return Rt(this, "every", e, t, void 0, arguments);
  },
  filter(e, t) {
    return Rt(this, "filter", e, t, (n) => n.map(st), arguments);
  },
  find(e, t) {
    return Rt(this, "find", e, t, st, arguments);
  },
  findIndex(e, t) {
    return Rt(this, "findIndex", e, t, void 0, arguments);
  },
  findLast(e, t) {
    return Rt(this, "findLast", e, t, st, arguments);
  },
  findLastIndex(e, t) {
    return Rt(this, "findLastIndex", e, t, void 0, arguments);
  },
  forEach(e, t) {
    return Rt(this, "forEach", e, t, void 0, arguments);
  },
  includes(...e) {
    return mr(this, "includes", e);
  },
  indexOf(...e) {
    return mr(this, "indexOf", e);
  },
  join(e) {
    return un(this).join(e);
  },
  lastIndexOf(...e) {
    return mr(this, "lastIndexOf", e);
  },
  map(e, t) {
    return Rt(this, "map", e, t, void 0, arguments);
  },
  pop() {
    return xn(this, "pop");
  },
  push(...e) {
    return xn(this, "push", e);
  },
  reduce(e, ...t) {
    return gi(this, "reduce", e, t);
  },
  reduceRight(e, ...t) {
    return gi(this, "reduceRight", e, t);
  },
  shift() {
    return xn(this, "shift");
  },
  some(e, t) {
    return Rt(this, "some", e, t, void 0, arguments);
  },
  splice(...e) {
    return xn(this, "splice", e);
  },
  toReversed() {
    return un(this).toReversed();
  },
  toSorted(e) {
    return un(this).toSorted(e);
  },
  toSpliced(...e) {
    return un(this).toSpliced(...e);
  },
  unshift(...e) {
    return xn(this, "unshift", e);
  },
  values() {
    return gr(this, "values", st);
  },
};
function gr(e, t, n) {
  const o = Kr(e),
    a = o[t]();
  return (
    o !== e &&
      !wt(e) &&
      ((a._next = a.next),
      (a.next = () => {
        const f = a._next();
        return f.value && (f.value = n(f.value)), f;
      })),
    a
  );
}
const Fs = Array.prototype;
function Rt(e, t, n, o, a, f) {
  const c = Kr(e),
    s = c !== e && !wt(e),
    r = c[t];
  if (r !== Fs[t]) {
    const w = r.apply(e, f);
    return s ? st(w) : w;
  }
  let l = n;
  c !== e &&
    (s
      ? (l = function (w, S) {
          return n.call(this, st(w), S, e);
        })
      : n.length > 2 &&
        (l = function (w, S) {
          return n.call(this, w, S, e);
        }));
  const d = r.call(c, l, o);
  return s && a ? a(d) : d;
}
function gi(e, t, n, o) {
  const a = Kr(e);
  let f = n;
  return (
    a !== e &&
      (wt(e)
        ? n.length > 3 &&
          (f = function (c, s, r) {
            return n.call(this, c, s, r, e);
          })
        : (f = function (c, s, r) {
            return n.call(this, c, st(s), r, e);
          })),
    a[t](f, ...o)
  );
}
function mr(e, t, n) {
  const o = Me(e);
  Qe(o, "iterate", Rn);
  const a = o[t](...n);
  return (a === -1 || a === !1) && Jr(n[0])
    ? ((n[0] = Me(n[0])), o[t](...n))
    : a;
}
function xn(e, t, n = []) {
  qt(), Zr();
  const o = Me(e)[t].apply(e, n);
  return Wr(), zt(), o;
}
const js = Ur("__proto__,__v_isRef,__isVue"),
  go = new Set(
    Object.getOwnPropertyNames(Symbol)
      .filter((e) => e !== "arguments" && e !== "caller")
      .map((e) => Symbol[e])
      .filter(Mt)
  );
function Ls(e) {
  Mt(e) || (e = String(e));
  const t = Me(this);
  return Qe(t, "has", e), t.hasOwnProperty(e);
}
class mo {
  constructor(t = !1, n = !1) {
    (this._isReadonly = t), (this._isShallow = n);
  }
  get(t, n, o) {
    const a = this._isReadonly,
      f = this._isShallow;
    if (n === "__v_isReactive") return !a;
    if (n === "__v_isReadonly") return a;
    if (n === "__v_isShallow") return f;
    if (n === "__v_raw")
      return o === (a ? (f ? qs : bo) : f ? wo : vo).get(t) ||
        Object.getPrototypeOf(t) === Object.getPrototypeOf(o)
        ? t
        : void 0;
    const c = Be(t);
    if (!a) {
      let r;
      if (c && (r = Rs[n])) return r;
      if (n === "hasOwnProperty") return Ls;
    }
    const s = Reflect.get(t, n, nt(t) ? t : o);
    return (Mt(n) ? go.has(n) : js(n)) || (a || Qe(t, "get", n), f)
      ? s
      : nt(s)
      ? c && Hr(n)
        ? s
        : s.value
      : He(s)
      ? a
        ? xo(s)
        : ct(s)
      : s;
  }
}
class yo extends mo {
  constructor(t = !1) {
    super(!1, t);
  }
  set(t, n, o, a) {
    let f = t[n];
    if (!this._isShallow) {
      const r = tn(f);
      if (
        (!wt(o) && !tn(o) && ((f = Me(f)), (o = Me(o))),
        !Be(t) && nt(f) && !nt(o))
      )
        return r ? !1 : ((f.value = o), !0);
    }
    const c = Be(t) && Hr(n) ? Number(n) < t.length : De(t, n),
      s = Reflect.set(t, n, o, nt(t) ? t : a);
    return (
      t === Me(a) && (c ? Zt(o, f) && jt(t, "set", n, o) : jt(t, "add", n, o)),
      s
    );
  }
  deleteProperty(t, n) {
    const o = De(t, n);
    t[n];
    const a = Reflect.deleteProperty(t, n);
    return a && o && jt(t, "delete", n, void 0), a;
  }
  has(t, n) {
    const o = Reflect.has(t, n);
    return (!Mt(n) || !go.has(n)) && Qe(t, "has", n), o;
  }
  ownKeys(t) {
    return Qe(t, "iterate", Be(t) ? "length" : en), Reflect.ownKeys(t);
  }
}
class Ms extends mo {
  constructor(t = !1) {
    super(!0, t);
  }
  set(t, n) {
    return !0;
  }
  deleteProperty(t, n) {
    return !0;
  }
}
const Ds = new yo(),
  $s = new Ms(),
  Us = new yo(!0);
const Ir = (e) => e,
  Vn = (e) => Reflect.getPrototypeOf(e);
function Ns(e, t, n) {
  return function (...o) {
    const a = this.__v_raw,
      f = Me(a),
      c = hn(f),
      s = e === "entries" || (e === Symbol.iterator && c),
      r = e === "keys" && c,
      l = a[e](...o),
      d = n ? Ir : t ? Or : st;
    return (
      !t && Qe(f, "iterate", r ? Ar : en),
      {
        next() {
          const { value: w, done: S } = l.next();
          return S
            ? { value: w, done: S }
            : { value: s ? [d(w[0]), d(w[1])] : d(w), done: S };
        },
        [Symbol.iterator]() {
          return this;
        },
      }
    );
  };
}
function Hn(e) {
  return function (...t) {
    return e === "delete" ? !1 : e === "clear" ? void 0 : this;
  };
}
function Vs(e, t) {
  const n = {
    get(a) {
      const f = this.__v_raw,
        c = Me(f),
        s = Me(a);
      e || (Zt(a, s) && Qe(c, "get", a), Qe(c, "get", s));
      const { has: r } = Vn(c),
        l = t ? Ir : e ? Or : st;
      if (r.call(c, a)) return l(f.get(a));
      if (r.call(c, s)) return l(f.get(s));
      f !== c && f.get(a);
    },
    get size() {
      const a = this.__v_raw;
      return !e && Qe(Me(a), "iterate", en), Reflect.get(a, "size", a);
    },
    has(a) {
      const f = this.__v_raw,
        c = Me(f),
        s = Me(a);
      return (
        e || (Zt(a, s) && Qe(c, "has", a), Qe(c, "has", s)),
        a === s ? f.has(a) : f.has(a) || f.has(s)
      );
    },
    forEach(a, f) {
      const c = this,
        s = c.__v_raw,
        r = Me(s),
        l = t ? Ir : e ? Or : st;
      return (
        !e && Qe(r, "iterate", en),
        s.forEach((d, w) => a.call(f, l(d), l(w), c))
      );
    },
  };
  return (
    Xe(
      n,
      e
        ? {
            add: Hn("add"),
            set: Hn("set"),
            delete: Hn("delete"),
            clear: Hn("clear"),
          }
        : {
            add(a) {
              !t && !wt(a) && !tn(a) && (a = Me(a));
              const f = Me(this);
              return (
                Vn(f).has.call(f, a) || (f.add(a), jt(f, "add", a, a)), this
              );
            },
            set(a, f) {
              !t && !wt(f) && !tn(f) && (f = Me(f));
              const c = Me(this),
                { has: s, get: r } = Vn(c);
              let l = s.call(c, a);
              l || ((a = Me(a)), (l = s.call(c, a)));
              const d = r.call(c, a);
              return (
                c.set(a, f),
                l ? Zt(f, d) && jt(c, "set", a, f) : jt(c, "add", a, f),
                this
              );
            },
            delete(a) {
              const f = Me(this),
                { has: c, get: s } = Vn(f);
              let r = c.call(f, a);
              r || ((a = Me(a)), (r = c.call(f, a))), s && s.call(f, a);
              const l = f.delete(a);
              return r && jt(f, "delete", a, void 0), l;
            },
            clear() {
              const a = Me(this),
                f = a.size !== 0,
                c = a.clear();
              return f && jt(a, "clear", void 0, void 0), c;
            },
          }
    ),
    ["keys", "values", "entries", Symbol.iterator].forEach((a) => {
      n[a] = Ns(a, e, t);
    }),
    n
  );
}
function Gr(e, t) {
  const n = Vs(e, t);
  return (o, a, f) =>
    a === "__v_isReactive"
      ? !e
      : a === "__v_isReadonly"
      ? e
      : a === "__v_raw"
      ? o
      : Reflect.get(De(n, a) && a in o ? n : o, a, f);
}
const Hs = { get: Gr(!1, !1) },
  Zs = { get: Gr(!1, !0) },
  Ws = { get: Gr(!0, !1) };
const vo = new WeakMap(),
  wo = new WeakMap(),
  bo = new WeakMap(),
  qs = new WeakMap();
function zs(e) {
  switch (e) {
    case "Object":
    case "Array":
      return 1;
    case "Map":
    case "Set":
    case "WeakMap":
    case "WeakSet":
      return 2;
    default:
      return 0;
  }
}
function Ks(e) {
  return e.__v_skip || !Object.isExtensible(e) ? 0 : zs(ws(e));
}
function ct(e) {
  return tn(e) ? e : Xr(e, !1, Ds, Hs, vo);
}
function Gs(e) {
  return Xr(e, !1, Us, Zs, wo);
}
function xo(e) {
  return Xr(e, !0, $s, Ws, bo);
}
function Xr(e, t, n, o, a) {
  if (!He(e) || (e.__v_raw && !(t && e.__v_isReactive))) return e;
  const f = a.get(e);
  if (f) return f;
  const c = Ks(e);
  if (c === 0) return e;
  const s = new Proxy(e, c === 2 ? o : n);
  return a.set(e, s), s;
}
function An(e) {
  return tn(e) ? An(e.__v_raw) : !!(e && e.__v_isReactive);
}
function tn(e) {
  return !!(e && e.__v_isReadonly);
}
function wt(e) {
  return !!(e && e.__v_isShallow);
}
function Jr(e) {
  return e ? !!e.__v_raw : !1;
}
function Me(e) {
  const t = e && e.__v_raw;
  return t ? Me(t) : e;
}
function Xs(e) {
  return (
    !De(e, "__v_skip") && Object.isExtensible(e) && no(e, "__v_skip", !0), e
  );
}
const st = (e) => (He(e) ? ct(e) : e),
  Or = (e) => (He(e) ? xo(e) : e);
function nt(e) {
  return e ? e.__v_isRef === !0 : !1;
}
function Lt(e) {
  return Js(e, !1);
}
function Js(e, t) {
  return nt(e) ? e : new Ys(e, t);
}
class Ys {
  constructor(t, n) {
    (this.dep = new zr()),
      (this.__v_isRef = !0),
      (this.__v_isShallow = !1),
      (this._rawValue = n ? t : Me(t)),
      (this._value = n ? t : st(t)),
      (this.__v_isShallow = n);
  }
  get value() {
    return this.dep.track(), this._value;
  }
  set value(t) {
    const n = this._rawValue,
      o = this.__v_isShallow || wt(t) || tn(t);
    (t = o ? t : Me(t)),
      Zt(t, n) &&
        ((this._rawValue = t),
        (this._value = o ? t : st(t)),
        this.dep.trigger());
  }
}
function Qs(e) {
  return nt(e) ? e.value : e;
}
const ea = {
  get: (e, t, n) => (t === "__v_raw" ? e : Qs(Reflect.get(e, t, n))),
  set: (e, t, n, o) => {
    const a = e[t];
    return nt(a) && !nt(n) ? ((a.value = n), !0) : Reflect.set(e, t, n, o);
  },
};
function So(e) {
  return An(e) ? e : new Proxy(e, ea);
}
class ta {
  constructor(t, n, o) {
    (this.fn = t),
      (this.setter = n),
      (this._value = void 0),
      (this.dep = new zr(this)),
      (this.__v_isRef = !0),
      (this.deps = void 0),
      (this.depsTail = void 0),
      (this.flags = 16),
      (this.globalVersion = Bn - 1),
      (this.next = void 0),
      (this.effect = this),
      (this.__v_isReadonly = !n),
      (this.isSSR = o);
  }
  notify() {
    if (((this.flags |= 16), !(this.flags & 8) && $e !== this))
      return uo(this, !0), !0;
  }
  get value() {
    const t = this.dep.track();
    return fo(this), t && (t.version = this.dep.version), this._value;
  }
  set value(t) {
    this.setter && this.setter(t);
  }
}
function na(e, t, n = !1) {
  let o, a;
  return Oe(e) ? (o = e) : ((o = e.get), (a = e.set)), new ta(o, a, n);
}
const Zn = {},
  zn = new WeakMap();
let Yt;
function ra(e, t = !1, n = Yt) {
  if (n) {
    let o = zn.get(n);
    o || zn.set(n, (o = [])), o.push(e);
  }
}
function ia(e, t, n = Ue) {
  const {
      immediate: o,
      deep: a,
      once: f,
      scheduler: c,
      augmentJob: s,
      call: r,
    } = n,
    l = (m) => (a ? m : wt(m) || a === !1 || a === 0 ? Ht(m, 1) : Ht(m));
  let d,
    w,
    S,
    x,
    E = !1,
    I = !1;
  if (
    (nt(e)
      ? ((w = () => e.value), (E = wt(e)))
      : An(e)
      ? ((w = () => l(e)), (E = !0))
      : Be(e)
      ? ((I = !0),
        (E = e.some((m) => An(m) || wt(m))),
        (w = () =>
          e.map((m) => {
            if (nt(m)) return m.value;
            if (An(m)) return l(m);
            if (Oe(m)) return r ? r(m, 2) : m();
          })))
      : Oe(e)
      ? t
        ? (w = r ? () => r(e, 2) : e)
        : (w = () => {
            if (S) {
              qt();
              try {
                S();
              } finally {
                zt();
              }
            }
            const m = Yt;
            Yt = d;
            try {
              return r ? r(e, 3, [x]) : e(x);
            } finally {
              Yt = m;
            }
          })
      : (w = Tt),
    t && a)
  ) {
    const m = w,
      v = a === !0 ? 1 / 0 : a;
    w = () => Ht(m(), v);
  }
  const k = Is(),
    b = () => {
      d.stop(), k && Vr(k.effects, d);
    };
  if (f && t) {
    const m = t;
    t = (...v) => {
      m(...v), b();
    };
  }
  let g = I ? new Array(e.length).fill(Zn) : Zn;
  const _ = (m) => {
    if (!(!(d.flags & 1) || (!d.dirty && !m)))
      if (t) {
        const v = d.run();
        if (a || E || (I ? v.some((A, T) => Zt(A, g[T])) : Zt(v, g))) {
          S && S();
          const A = Yt;
          Yt = d;
          try {
            const T = [v, g === Zn ? void 0 : I && g[0] === Zn ? [] : g, x];
            r ? r(t, 3, T) : t(...T), (g = v);
          } finally {
            Yt = A;
          }
        }
      } else d.run();
  };
  return (
    s && s(_),
    (d = new so(w)),
    (d.scheduler = c ? () => c(_, !1) : _),
    (x = (m) => ra(m, !1, d)),
    (S = d.onStop =
      () => {
        const m = zn.get(d);
        if (m) {
          if (r) r(m, 4);
          else for (const v of m) v();
          zn.delete(d);
        }
      }),
    t ? (o ? _(!0) : (g = d.run())) : c ? c(_.bind(null, !0), !0) : d.run(),
    (b.pause = d.pause.bind(d)),
    (b.resume = d.resume.bind(d)),
    (b.stop = b),
    b
  );
}
function Ht(e, t = 1 / 0, n) {
  if (t <= 0 || !He(e) || e.__v_skip || ((n = n || new Set()), n.has(e)))
    return e;
  if ((n.add(e), t--, nt(e))) Ht(e.value, t, n);
  else if (Be(e)) for (let o = 0; o < e.length; o++) Ht(e[o], t, n);
  else if (Yi(e) || hn(e))
    e.forEach((o) => {
      Ht(o, t, n);
    });
  else if (to(e)) {
    for (const o in e) Ht(e[o], t, n);
    for (const o of Object.getOwnPropertySymbols(e))
      Object.prototype.propertyIsEnumerable.call(e, o) && Ht(e[o], t, n);
  }
  return e;
}
/**
 * @vue/runtime-core v3.5.12
 * (c) 2018-present Yuxi (Evan) You and Vue contributors
 * @license MIT
 **/ function Mn(e, t, n, o) {
  try {
    return o ? e(...o) : e();
  } catch (a) {
    rr(a, t, n);
  }
}
function At(e, t, n, o) {
  if (Oe(e)) {
    const a = Mn(e, t, n, o);
    return (
      a &&
        Qi(a) &&
        a.catch((f) => {
          rr(f, t, n);
        }),
      a
    );
  }
  if (Be(e)) {
    const a = [];
    for (let f = 0; f < e.length; f++) a.push(At(e[f], t, n, o));
    return a;
  }
}
function rr(e, t, n, o = !0) {
  const a = t ? t.vnode : null,
    { errorHandler: f, throwUnhandledErrorInProduction: c } =
      (t && t.appContext.config) || Ue;
  if (t) {
    let s = t.parent;
    const r = t.proxy,
      l = `https://vuejs.org/error-reference/#runtime-${n}`;
    for (; s; ) {
      const d = s.ec;
      if (d) {
        for (let w = 0; w < d.length; w++) if (d[w](e, r, l) === !1) return;
      }
      s = s.parent;
    }
    if (f) {
      qt(), Mn(f, null, 10, [e, r, l]), zt();
      return;
    }
  }
  oa(e, n, a, o, c);
}
function oa(e, t, n, o = !0, a = !1) {
  if (a) throw e;
  console.error(e);
}
const at = [];
let Ct = -1;
const pn = [];
let Nt = null,
  ln = 0;
const _o = Promise.resolve();
let Kn = null;
function sa(e) {
  const t = Kn || _o;
  return e ? t.then(this ? e.bind(this) : e) : t;
}
function aa(e) {
  let t = Ct + 1,
    n = at.length;
  for (; t < n; ) {
    const o = (t + n) >>> 1,
      a = at[o],
      f = Fn(a);
    f < e || (f === e && a.flags & 2) ? (t = o + 1) : (n = o);
  }
  return t;
}
function Yr(e) {
  if (!(e.flags & 1)) {
    const t = Fn(e),
      n = at[at.length - 1];
    !n || (!(e.flags & 2) && t >= Fn(n)) ? at.push(e) : at.splice(aa(t), 0, e),
      (e.flags |= 1),
      Co();
  }
}
function Co() {
  Kn || (Kn = _o.then(ko));
}
function ua(e) {
  Be(e)
    ? pn.push(...e)
    : Nt && e.id === -1
    ? Nt.splice(ln + 1, 0, e)
    : e.flags & 1 || (pn.push(e), (e.flags |= 1)),
    Co();
}
function mi(e, t, n = Ct + 1) {
  for (; n < at.length; n++) {
    const o = at[n];
    if (o && o.flags & 2) {
      if (e && o.id !== e.uid) continue;
      at.splice(n, 1),
        n--,
        o.flags & 4 && (o.flags &= -2),
        o(),
        o.flags & 4 || (o.flags &= -2);
    }
  }
}
function Eo(e) {
  if (pn.length) {
    const t = [...new Set(pn)].sort((n, o) => Fn(n) - Fn(o));
    if (((pn.length = 0), Nt)) {
      Nt.push(...t);
      return;
    }
    for (Nt = t, ln = 0; ln < Nt.length; ln++) {
      const n = Nt[ln];
      n.flags & 4 && (n.flags &= -2), n.flags & 8 || n(), (n.flags &= -2);
    }
    (Nt = null), (ln = 0);
  }
}
const Fn = (e) => (e.id == null ? (e.flags & 2 ? -1 : 1 / 0) : e.id);
function ko(e) {
  try {
    for (Ct = 0; Ct < at.length; Ct++) {
      const t = at[Ct];
      t &&
        !(t.flags & 8) &&
        (t.flags & 4 && (t.flags &= -2),
        Mn(t, t.i, t.i ? 15 : 14),
        t.flags & 4 || (t.flags &= -2));
    }
  } finally {
    for (; Ct < at.length; Ct++) {
      const t = at[Ct];
      t && (t.flags &= -2);
    }
    (Ct = -1),
      (at.length = 0),
      Eo(),
      (Kn = null),
      (at.length || pn.length) && ko();
  }
}
let ut = null,
  To = null;
function Gn(e) {
  const t = ut;
  return (ut = e), (To = (e && e.type.__scopeId) || null), t;
}
function bt(e, t = ut, n) {
  if (!t || e._n) return e;
  const o = (...a) => {
    o._d && Ei(-1);
    const f = Gn(t);
    let c;
    try {
      c = e(...a);
    } finally {
      Gn(f), o._d && Ei(1);
    }
    return c;
  };
  return (o._n = !0), (o._c = !0), (o._d = !0), o;
}
function Xt(e, t, n, o) {
  const a = e.dirs,
    f = t && t.dirs;
  for (let c = 0; c < a.length; c++) {
    const s = a[c];
    f && (s.oldValue = f[c].value);
    let r = s.dir[o];
    r && (qt(), At(r, n, 8, [e.el, s, e, t]), zt());
  }
}
const ca = Symbol("_vte"),
  la = (e) => e.__isTeleport;
function Qr(e, t) {
  e.shapeFlag & 6 && e.component
    ? ((e.transition = t), Qr(e.component.subTree, t))
    : e.shapeFlag & 128
    ? ((e.ssContent.transition = t.clone(e.ssContent)),
      (e.ssFallback.transition = t.clone(e.ssFallback)))
    : (e.transition = t);
}
/*! #__NO_SIDE_EFFECTS__ */ function Ze(e, t) {
  return Oe(e) ? Xe({ name: e.name }, t, { setup: e }) : e;
}
function Po(e) {
  e.ids = [e.ids[0] + e.ids[2]++ + "-", 0, 0];
}
function Br(e, t, n, o, a = !1) {
  if (Be(e)) {
    e.forEach((E, I) => Br(E, t && (Be(t) ? t[I] : t), n, o, a));
    return;
  }
  if (gn(o) && !a) return;
  const f = o.shapeFlag & 4 ? si(o.component) : o.el,
    c = a ? null : f,
    { i: s, r } = e,
    l = t && t.r,
    d = s.refs === Ue ? (s.refs = {}) : s.refs,
    w = s.setupState,
    S = Me(w),
    x = w === Ue ? () => !1 : (E) => De(S, E);
  if (
    (l != null &&
      l !== r &&
      (ze(l)
        ? ((d[l] = null), x(l) && (w[l] = null))
        : nt(l) && (l.value = null)),
    Oe(r))
  )
    Mn(r, s, 12, [c, d]);
  else {
    const E = ze(r),
      I = nt(r);
    if (E || I) {
      const k = () => {
        if (e.f) {
          const b = E ? (x(r) ? w[r] : d[r]) : r.value;
          a
            ? Be(b) && Vr(b, f)
            : Be(b)
            ? b.includes(f) || b.push(f)
            : E
            ? ((d[r] = [f]), x(r) && (w[r] = d[r]))
            : ((r.value = [f]), e.k && (d[e.k] = r.value));
        } else
          E
            ? ((d[r] = c), x(r) && (w[r] = c))
            : I && ((r.value = c), e.k && (d[e.k] = c));
      };
      c ? ((k.id = -1), ft(k, n)) : k();
    }
  }
}
nr().requestIdleCallback;
nr().cancelIdleCallback;
const gn = (e) => !!e.type.__asyncLoader,
  Ao = (e) => e.type.__isKeepAlive;
function fa(e, t) {
  Io(e, "a", t);
}
function da(e, t) {
  Io(e, "da", t);
}
function Io(e, t, n = et) {
  const o =
    e.__wdc ||
    (e.__wdc = () => {
      let a = n;
      for (; a; ) {
        if (a.isDeactivated) return;
        a = a.parent;
      }
      return e();
    });
  if ((ir(t, o, n), n)) {
    let a = n.parent;
    for (; a && a.parent; )
      Ao(a.parent.vnode) && ha(o, t, n, a), (a = a.parent);
  }
}
function ha(e, t, n, o) {
  const a = ir(t, e, o, !0);
  or(() => {
    Vr(o[t], a);
  }, n);
}
function ir(e, t, n = et, o = !1) {
  if (n) {
    const a = n[e] || (n[e] = []),
      f =
        t.__weh ||
        (t.__weh = (...c) => {
          qt();
          const s = Dn(n),
            r = At(t, n, e, c);
          return s(), zt(), r;
        });
    return o ? a.unshift(f) : a.push(f), f;
  }
}
const Dt =
    (e) =>
    (t, n = et) => {
      (!Ln || e === "sp") && ir(e, (...o) => t(...o), n);
    },
  pa = Dt("bm"),
  on = Dt("m"),
  ga = Dt("bu"),
  Oo = Dt("u"),
  ma = Dt("bum"),
  or = Dt("um"),
  ya = Dt("sp"),
  va = Dt("rtg"),
  wa = Dt("rtc");
function ba(e, t = et) {
  ir("ec", e, t);
}
const Bo = "components";
function Se(e, t) {
  return Fo(Bo, e, !0, t) || e;
}
const Ro = Symbol.for("v-ndc");
function xa(e) {
  return ze(e) ? Fo(Bo, e, !1) || e : e || Ro;
}
function Fo(e, t, n = !0, o = !1) {
  const a = ut || et;
  if (a) {
    const f = a.type;
    {
      const s = lu(f, !1);
      if (s && (s === t || s === mt(t) || s === tr(mt(t)))) return f;
    }
    const c = yi(a[e] || f[e], t) || yi(a.appContext[e], t);
    return !c && o ? f : c;
  }
}
function yi(e, t) {
  return e && (e[t] || e[mt(t)] || e[tr(mt(t))]);
}
function Sa(e, t, n = {}, o, a) {
  if (ut.ce || (ut.parent && gn(ut.parent) && ut.parent.ce))
    return Ae(), tt(gt, null, [Ee("slot", n, o)], 64);
  let f = e[t];
  f && f._c && (f._d = !1), Ae();
  const c = f && jo(f(n)),
    s = n.key || (c && c.key),
    r = tt(
      gt,
      { key: (s && !Mt(s) ? s : `_${t}`) + (!c && o ? "_fb" : "") },
      c || [],
      c && e._ === 1 ? 64 : -2
    );
  return (
    r.scopeId && (r.slotScopeIds = [r.scopeId + "-s"]),
    f && f._c && (f._d = !0),
    r
  );
}
function jo(e) {
  return e.some((t) =>
    ii(t) ? !(t.type === Wt || (t.type === gt && !jo(t.children))) : !0
  )
    ? e
    : null;
}
const Rr = (e) => (e ? (es(e) ? si(e) : Rr(e.parent)) : null),
  In = Xe(Object.create(null), {
    $: (e) => e,
    $el: (e) => e.vnode.el,
    $data: (e) => e.data,
    $props: (e) => e.props,
    $attrs: (e) => e.attrs,
    $slots: (e) => e.slots,
    $refs: (e) => e.refs,
    $parent: (e) => Rr(e.parent),
    $root: (e) => Rr(e.root),
    $host: (e) => e.ce,
    $emit: (e) => e.emit,
    $options: (e) => ei(e),
    $forceUpdate: (e) =>
      e.f ||
      (e.f = () => {
        Yr(e.update);
      }),
    $nextTick: (e) => e.n || (e.n = sa.bind(e.proxy)),
    $watch: (e) => Za.bind(e),
  }),
  yr = (e, t) => e !== Ue && !e.__isScriptSetup && De(e, t),
  _a = {
    get({ _: e }, t) {
      if (t === "__v_skip") return !0;
      const {
        ctx: n,
        setupState: o,
        data: a,
        props: f,
        accessCache: c,
        type: s,
        appContext: r,
      } = e;
      let l;
      if (t[0] !== "$") {
        const x = c[t];
        if (x !== void 0)
          switch (x) {
            case 1:
              return o[t];
            case 2:
              return a[t];
            case 4:
              return n[t];
            case 3:
              return f[t];
          }
        else {
          if (yr(o, t)) return (c[t] = 1), o[t];
          if (a !== Ue && De(a, t)) return (c[t] = 2), a[t];
          if ((l = e.propsOptions[0]) && De(l, t)) return (c[t] = 3), f[t];
          if (n !== Ue && De(n, t)) return (c[t] = 4), n[t];
          Fr && (c[t] = 0);
        }
      }
      const d = In[t];
      let w, S;
      if (d) return t === "$attrs" && Qe(e.attrs, "get", ""), d(e);
      if ((w = s.__cssModules) && (w = w[t])) return w;
      if (n !== Ue && De(n, t)) return (c[t] = 4), n[t];
      if (((S = r.config.globalProperties), De(S, t))) return S[t];
    },
    set({ _: e }, t, n) {
      const { data: o, setupState: a, ctx: f } = e;
      return yr(a, t)
        ? ((a[t] = n), !0)
        : o !== Ue && De(o, t)
        ? ((o[t] = n), !0)
        : De(e.props, t) || (t[0] === "$" && t.slice(1) in e)
        ? !1
        : ((f[t] = n), !0);
    },
    has(
      {
        _: {
          data: e,
          setupState: t,
          accessCache: n,
          ctx: o,
          appContext: a,
          propsOptions: f,
        },
      },
      c
    ) {
      let s;
      return (
        !!n[c] ||
        (e !== Ue && De(e, c)) ||
        yr(t, c) ||
        ((s = f[0]) && De(s, c)) ||
        De(o, c) ||
        De(In, c) ||
        De(a.config.globalProperties, c)
      );
    },
    defineProperty(e, t, n) {
      return (
        n.get != null
          ? (e._.accessCache[t] = 0)
          : De(n, "value") && this.set(e, t, n.value, null),
        Reflect.defineProperty(e, t, n)
      );
    },
  };
function vi(e) {
  return Be(e) ? e.reduce((t, n) => ((t[n] = null), t), {}) : e;
}
let Fr = !0;
function Ca(e) {
  const t = ei(e),
    n = e.proxy,
    o = e.ctx;
  (Fr = !1), t.beforeCreate && wi(t.beforeCreate, e, "bc");
  const {
    data: a,
    computed: f,
    methods: c,
    watch: s,
    provide: r,
    inject: l,
    created: d,
    beforeMount: w,
    mounted: S,
    beforeUpdate: x,
    updated: E,
    activated: I,
    deactivated: k,
    beforeDestroy: b,
    beforeUnmount: g,
    destroyed: _,
    unmounted: m,
    render: v,
    renderTracked: A,
    renderTriggered: T,
    errorCaptured: j,
    serverPrefetch: L,
    expose: M,
    inheritAttrs: q,
    components: W,
    directives: ie,
    filters: ne,
  } = t;
  if ((l && Ea(l, o, null), c))
    for (const $ in c) {
      const D = c[$];
      Oe(D) && (o[$] = D.bind(n));
    }
  if (a) {
    const $ = a.call(n, n);
    He($) && (e.data = ct($));
  }
  if (((Fr = !0), f))
    for (const $ in f) {
      const D = f[$],
        se = Oe(D) ? D.bind(n, n) : Oe(D.get) ? D.get.bind(n, n) : Tt,
        xe = !Oe(D) && Oe(D.set) ? D.set.bind(n) : Tt,
        me = lt({ get: se, set: xe });
      Object.defineProperty(o, $, {
        enumerable: !0,
        configurable: !0,
        get: () => me.value,
        set: (pe) => (me.value = pe),
      });
    }
  if (s) for (const $ in s) Lo(s[$], o, n, $);
  if (r) {
    const $ = Oe(r) ? r.call(n) : r;
    Reflect.ownKeys($).forEach((D) => {
      ti(D, $[D]);
    });
  }
  d && wi(d, e, "c");
  function he($, D) {
    Be(D) ? D.forEach((se) => $(se.bind(n))) : D && $(D.bind(n));
  }
  if (
    (he(pa, w),
    he(on, S),
    he(ga, x),
    he(Oo, E),
    he(fa, I),
    he(da, k),
    he(ba, j),
    he(wa, A),
    he(va, T),
    he(ma, g),
    he(or, m),
    he(ya, L),
    Be(M))
  )
    if (M.length) {
      const $ = e.exposed || (e.exposed = {});
      M.forEach((D) => {
        Object.defineProperty($, D, {
          get: () => n[D],
          set: (se) => (n[D] = se),
        });
      });
    } else e.exposed || (e.exposed = {});
  v && e.render === Tt && (e.render = v),
    q != null && (e.inheritAttrs = q),
    W && (e.components = W),
    ie && (e.directives = ie),
    L && Po(e);
}
function Ea(e, t, n = Tt) {
  Be(e) && (e = jr(e));
  for (const o in e) {
    const a = e[o];
    let f;
    He(a)
      ? "default" in a
        ? (f = yn(a.from || o, a.default, !0))
        : (f = yn(a.from || o))
      : (f = yn(a)),
      nt(f)
        ? Object.defineProperty(t, o, {
            enumerable: !0,
            configurable: !0,
            get: () => f.value,
            set: (c) => (f.value = c),
          })
        : (t[o] = f);
  }
}
function wi(e, t, n) {
  At(Be(e) ? e.map((o) => o.bind(t.proxy)) : e.bind(t.proxy), t, n);
}
function Lo(e, t, n, o) {
  let a = o.includes(".") ? Go(n, o) : () => n[o];
  if (ze(e)) {
    const f = t[e];
    Oe(f) && vn(a, f);
  } else if (Oe(e)) vn(a, e.bind(n));
  else if (He(e))
    if (Be(e)) e.forEach((f) => Lo(f, t, n, o));
    else {
      const f = Oe(e.handler) ? e.handler.bind(n) : t[e.handler];
      Oe(f) && vn(a, f, e);
    }
}
function ei(e) {
  const t = e.type,
    { mixins: n, extends: o } = t,
    {
      mixins: a,
      optionsCache: f,
      config: { optionMergeStrategies: c },
    } = e.appContext,
    s = f.get(t);
  let r;
  return (
    s
      ? (r = s)
      : !a.length && !n && !o
      ? (r = t)
      : ((r = {}), a.length && a.forEach((l) => Xn(r, l, c, !0)), Xn(r, t, c)),
    He(t) && f.set(t, r),
    r
  );
}
function Xn(e, t, n, o = !1) {
  const { mixins: a, extends: f } = t;
  f && Xn(e, f, n, !0), a && a.forEach((c) => Xn(e, c, n, !0));
  for (const c in t)
    if (!(o && c === "expose")) {
      const s = ka[c] || (n && n[c]);
      e[c] = s ? s(e[c], t[c]) : t[c];
    }
  return e;
}
const ka = {
  data: bi,
  props: xi,
  emits: xi,
  methods: Cn,
  computed: Cn,
  beforeCreate: it,
  created: it,
  beforeMount: it,
  mounted: it,
  beforeUpdate: it,
  updated: it,
  beforeDestroy: it,
  beforeUnmount: it,
  destroyed: it,
  unmounted: it,
  activated: it,
  deactivated: it,
  errorCaptured: it,
  serverPrefetch: it,
  components: Cn,
  directives: Cn,
  watch: Pa,
  provide: bi,
  inject: Ta,
};
function bi(e, t) {
  return t
    ? e
      ? function () {
          return Xe(
            Oe(e) ? e.call(this, this) : e,
            Oe(t) ? t.call(this, this) : t
          );
        }
      : t
    : e;
}
function Ta(e, t) {
  return Cn(jr(e), jr(t));
}
function jr(e) {
  if (Be(e)) {
    const t = {};
    for (let n = 0; n < e.length; n++) t[e[n]] = e[n];
    return t;
  }
  return e;
}
function it(e, t) {
  return e ? [...new Set([].concat(e, t))] : t;
}
function Cn(e, t) {
  return e ? Xe(Object.create(null), e, t) : t;
}
function xi(e, t) {
  return e
    ? Be(e) && Be(t)
      ? [...new Set([...e, ...t])]
      : Xe(Object.create(null), vi(e), vi(t ?? {}))
    : t;
}
function Pa(e, t) {
  if (!e) return t;
  if (!t) return e;
  const n = Xe(Object.create(null), e);
  for (const o in t) n[o] = it(e[o], t[o]);
  return n;
}
function Mo() {
  return {
    app: null,
    config: {
      isNativeTag: ys,
      performance: !1,
      globalProperties: {},
      optionMergeStrategies: {},
      errorHandler: void 0,
      warnHandler: void 0,
      compilerOptions: {},
    },
    mixins: [],
    components: {},
    directives: {},
    provides: Object.create(null),
    optionsCache: new WeakMap(),
    propsCache: new WeakMap(),
    emitsCache: new WeakMap(),
  };
}
let Aa = 0;
function Ia(e, t) {
  return function (o, a = null) {
    Oe(o) || (o = Xe({}, o)), a != null && !He(a) && (a = null);
    const f = Mo(),
      c = new WeakSet(),
      s = [];
    let r = !1;
    const l = (f.app = {
      _uid: Aa++,
      _component: o,
      _props: a,
      _container: null,
      _context: f,
      _instance: null,
      version: du,
      get config() {
        return f.config;
      },
      set config(d) {},
      use(d, ...w) {
        return (
          c.has(d) ||
            (d && Oe(d.install)
              ? (c.add(d), d.install(l, ...w))
              : Oe(d) && (c.add(d), d(l, ...w))),
          l
        );
      },
      mixin(d) {
        return f.mixins.includes(d) || f.mixins.push(d), l;
      },
      component(d, w) {
        return w ? ((f.components[d] = w), l) : f.components[d];
      },
      directive(d, w) {
        return w ? ((f.directives[d] = w), l) : f.directives[d];
      },
      mount(d, w, S) {
        if (!r) {
          const x = l._ceVNode || Ee(o, a);
          return (
            (x.appContext = f),
            S === !0 ? (S = "svg") : S === !1 && (S = void 0),
            w && t ? t(x, d) : e(x, d, S),
            (r = !0),
            (l._container = d),
            (d.__vue_app__ = l),
            si(x.component)
          );
        }
      },
      onUnmount(d) {
        s.push(d);
      },
      unmount() {
        r &&
          (At(s, l._instance, 16),
          e(null, l._container),
          delete l._container.__vue_app__);
      },
      provide(d, w) {
        return (f.provides[d] = w), l;
      },
      runWithContext(d) {
        const w = mn;
        mn = l;
        try {
          return d();
        } finally {
          mn = w;
        }
      },
    });
    return l;
  };
}
let mn = null;
function ti(e, t) {
  if (et) {
    let n = et.provides;
    const o = et.parent && et.parent.provides;
    o === n && (n = et.provides = Object.create(o)), (n[e] = t);
  }
}
function yn(e, t, n = !1) {
  const o = et || ut;
  if (o || mn) {
    const a = mn
      ? mn._context.provides
      : o
      ? o.parent == null
        ? o.vnode.appContext && o.vnode.appContext.provides
        : o.parent.provides
      : void 0;
    if (a && e in a) return a[e];
    if (arguments.length > 1) return n && Oe(t) ? t.call(o && o.proxy) : t;
  }
}
const Do = {},
  $o = () => Object.create(Do),
  Uo = (e) => Object.getPrototypeOf(e) === Do;
function Oa(e, t, n, o = !1) {
  const a = {},
    f = $o();
  (e.propsDefaults = Object.create(null)), No(e, t, a, f);
  for (const c in e.propsOptions[0]) c in a || (a[c] = void 0);
  n ? (e.props = o ? a : Gs(a)) : e.type.props ? (e.props = a) : (e.props = f),
    (e.attrs = f);
}
function Ba(e, t, n, o) {
  const {
      props: a,
      attrs: f,
      vnode: { patchFlag: c },
    } = e,
    s = Me(a),
    [r] = e.propsOptions;
  let l = !1;
  if ((o || c > 0) && !(c & 16)) {
    if (c & 8) {
      const d = e.vnode.dynamicProps;
      for (let w = 0; w < d.length; w++) {
        let S = d[w];
        if (sr(e.emitsOptions, S)) continue;
        const x = t[S];
        if (r)
          if (De(f, S)) x !== f[S] && ((f[S] = x), (l = !0));
          else {
            const E = mt(S);
            a[E] = Lr(r, s, E, x, e, !1);
          }
        else x !== f[S] && ((f[S] = x), (l = !0));
      }
    }
  } else {
    No(e, t, a, f) && (l = !0);
    let d;
    for (const w in s)
      (!t || (!De(t, w) && ((d = rn(w)) === w || !De(t, d)))) &&
        (r
          ? n &&
            (n[w] !== void 0 || n[d] !== void 0) &&
            (a[w] = Lr(r, s, w, void 0, e, !0))
          : delete a[w]);
    if (f !== s)
      for (const w in f) (!t || !De(t, w)) && (delete f[w], (l = !0));
  }
  l && jt(e.attrs, "set", "");
}
function No(e, t, n, o) {
  const [a, f] = e.propsOptions;
  let c = !1,
    s;
  if (t)
    for (let r in t) {
      if (kn(r)) continue;
      const l = t[r];
      let d;
      a && De(a, (d = mt(r)))
        ? !f || !f.includes(d)
          ? (n[d] = l)
          : ((s || (s = {}))[d] = l)
        : sr(e.emitsOptions, r) ||
          ((!(r in o) || l !== o[r]) && ((o[r] = l), (c = !0)));
    }
  if (f) {
    const r = Me(n),
      l = s || Ue;
    for (let d = 0; d < f.length; d++) {
      const w = f[d];
      n[w] = Lr(a, r, w, l[w], e, !De(l, w));
    }
  }
  return c;
}
function Lr(e, t, n, o, a, f) {
  const c = e[n];
  if (c != null) {
    const s = De(c, "default");
    if (s && o === void 0) {
      const r = c.default;
      if (c.type !== Function && !c.skipFactory && Oe(r)) {
        const { propsDefaults: l } = a;
        if (n in l) o = l[n];
        else {
          const d = Dn(a);
          (o = l[n] = r.call(null, t)), d();
        }
      } else o = r;
      a.ce && a.ce._setProp(n, o);
    }
    c[0] &&
      (f && !s ? (o = !1) : c[1] && (o === "" || o === rn(n)) && (o = !0));
  }
  return o;
}
const Ra = new WeakMap();
function Vo(e, t, n = !1) {
  const o = n ? Ra : t.propsCache,
    a = o.get(e);
  if (a) return a;
  const f = e.props,
    c = {},
    s = [];
  let r = !1;
  if (!Oe(e)) {
    const d = (w) => {
      r = !0;
      const [S, x] = Vo(w, t, !0);
      Xe(c, S), x && s.push(...x);
    };
    !n && t.mixins.length && t.mixins.forEach(d),
      e.extends && d(e.extends),
      e.mixins && e.mixins.forEach(d);
  }
  if (!f && !r) return He(e) && o.set(e, dn), dn;
  if (Be(f))
    for (let d = 0; d < f.length; d++) {
      const w = mt(f[d]);
      Si(w) && (c[w] = Ue);
    }
  else if (f)
    for (const d in f) {
      const w = mt(d);
      if (Si(w)) {
        const S = f[d],
          x = (c[w] = Be(S) || Oe(S) ? { type: S } : Xe({}, S)),
          E = x.type;
        let I = !1,
          k = !0;
        if (Be(E))
          for (let b = 0; b < E.length; ++b) {
            const g = E[b],
              _ = Oe(g) && g.name;
            if (_ === "Boolean") {
              I = !0;
              break;
            } else _ === "String" && (k = !1);
          }
        else I = Oe(E) && E.name === "Boolean";
        (x[0] = I), (x[1] = k), (I || De(x, "default")) && s.push(w);
      }
    }
  const l = [c, s];
  return He(e) && o.set(e, l), l;
}
function Si(e) {
  return e[0] !== "$" && !kn(e);
}
const Ho = (e) => e[0] === "_" || e === "$stable",
  ni = (e) => (Be(e) ? e.map(Et) : [Et(e)]),
  Fa = (e, t, n) => {
    if (t._n) return t;
    const o = bt((...a) => ni(t(...a)), n);
    return (o._c = !1), o;
  },
  Zo = (e, t, n) => {
    const o = e._ctx;
    for (const a in e) {
      if (Ho(a)) continue;
      const f = e[a];
      if (Oe(f)) t[a] = Fa(a, f, o);
      else if (f != null) {
        const c = ni(f);
        t[a] = () => c;
      }
    }
  },
  Wo = (e, t) => {
    const n = ni(t);
    e.slots.default = () => n;
  },
  qo = (e, t, n) => {
    for (const o in t) (n || o !== "_") && (e[o] = t[o]);
  },
  ja = (e, t, n) => {
    const o = (e.slots = $o());
    if (e.vnode.shapeFlag & 32) {
      const a = t._;
      a ? (qo(o, t, n), n && no(o, "_", a, !0)) : Zo(t, o);
    } else t && Wo(e, t);
  },
  La = (e, t, n) => {
    const { vnode: o, slots: a } = e;
    let f = !0,
      c = Ue;
    if (o.shapeFlag & 32) {
      const s = t._;
      s
        ? n && s === 1
          ? (f = !1)
          : qo(a, t, n)
        : ((f = !t.$stable), Zo(t, a)),
        (c = t);
    } else t && (Wo(e, t), (c = { default: 1 }));
    if (f) for (const s in a) !Ho(s) && c[s] == null && delete a[s];
  },
  ft = Ja;
function Ma(e) {
  return Da(e);
}
function Da(e, t) {
  const n = nr();
  n.__VUE__ = !0;
  const {
      insert: o,
      remove: a,
      patchProp: f,
      createElement: c,
      createText: s,
      createComment: r,
      setText: l,
      setElementText: d,
      parentNode: w,
      nextSibling: S,
      setScopeId: x = Tt,
      insertStaticContent: E,
    } = e,
    I = (
      P,
      R,
      N,
      X = null,
      G = null,
      Q = null,
      ce = void 0,
      oe = null,
      re = !!R.dynamicChildren
    ) => {
      if (P === R) return;
      P && !Sn(P, R) && ((X = U(P)), pe(P, G, Q, !0), (P = null)),
        R.patchFlag === -2 && ((re = !1), (R.dynamicChildren = null));
      const { type: Y, ref: ve, shapeFlag: le } = R;
      switch (Y) {
        case ar:
          k(P, R, N, X);
          break;
        case Wt:
          b(P, R, N, X);
          break;
        case br:
          P == null && g(R, N, X, ce);
          break;
        case gt:
          W(P, R, N, X, G, Q, ce, oe, re);
          break;
        default:
          le & 1
            ? v(P, R, N, X, G, Q, ce, oe, re)
            : le & 6
            ? ie(P, R, N, X, G, Q, ce, oe, re)
            : (le & 64 || le & 128) &&
              Y.process(P, R, N, X, G, Q, ce, oe, re, Pe);
      }
      ve != null && G && Br(ve, P && P.ref, Q, R || P, !R);
    },
    k = (P, R, N, X) => {
      if (P == null) o((R.el = s(R.children)), N, X);
      else {
        const G = (R.el = P.el);
        R.children !== P.children && l(G, R.children);
      }
    },
    b = (P, R, N, X) => {
      P == null ? o((R.el = r(R.children || "")), N, X) : (R.el = P.el);
    },
    g = (P, R, N, X) => {
      [P.el, P.anchor] = E(P.children, R, N, X, P.el, P.anchor);
    },
    _ = ({ el: P, anchor: R }, N, X) => {
      let G;
      for (; P && P !== R; ) (G = S(P)), o(P, N, X), (P = G);
      o(R, N, X);
    },
    m = ({ el: P, anchor: R }) => {
      let N;
      for (; P && P !== R; ) (N = S(P)), a(P), (P = N);
      a(R);
    },
    v = (P, R, N, X, G, Q, ce, oe, re) => {
      R.type === "svg" ? (ce = "svg") : R.type === "math" && (ce = "mathml"),
        P == null ? A(R, N, X, G, Q, ce, oe, re) : L(P, R, G, Q, ce, oe, re);
    },
    A = (P, R, N, X, G, Q, ce, oe) => {
      let re, Y;
      const { props: ve, shapeFlag: le, transition: ge, dirs: Z } = P;
      if (
        ((re = P.el = c(P.type, Q, ve && ve.is, ve)),
        le & 8
          ? d(re, P.children)
          : le & 16 && j(P.children, re, null, X, G, vr(P, Q), ce, oe),
        Z && Xt(P, null, X, "created"),
        T(re, P, P.scopeId, ce, X),
        ve)
      ) {
        for (const i in ve)
          i !== "value" && !kn(i) && f(re, i, null, ve[i], Q, X);
        "value" in ve && f(re, "value", null, ve.value, Q),
          (Y = ve.onVnodeBeforeMount) && _t(Y, X, P);
      }
      Z && Xt(P, null, X, "beforeMount");
      const p = $a(G, ge);
      p && ge.beforeEnter(re),
        o(re, R, N),
        ((Y = ve && ve.onVnodeMounted) || p || Z) &&
          ft(() => {
            Y && _t(Y, X, P), p && ge.enter(re), Z && Xt(P, null, X, "mounted");
          }, G);
    },
    T = (P, R, N, X, G) => {
      if ((N && x(P, N), X)) for (let Q = 0; Q < X.length; Q++) x(P, X[Q]);
      if (G) {
        let Q = G.subTree;
        if (
          R === Q ||
          (Jo(Q.type) && (Q.ssContent === R || Q.ssFallback === R))
        ) {
          const ce = G.vnode;
          T(P, ce, ce.scopeId, ce.slotScopeIds, G.parent);
        }
      }
    },
    j = (P, R, N, X, G, Q, ce, oe, re = 0) => {
      for (let Y = re; Y < P.length; Y++) {
        const ve = (P[Y] = oe ? Vt(P[Y]) : Et(P[Y]));
        I(null, ve, R, N, X, G, Q, ce, oe);
      }
    },
    L = (P, R, N, X, G, Q, ce) => {
      const oe = (R.el = P.el);
      let { patchFlag: re, dynamicChildren: Y, dirs: ve } = R;
      re |= P.patchFlag & 16;
      const le = P.props || Ue,
        ge = R.props || Ue;
      let Z;
      if (
        (N && Jt(N, !1),
        (Z = ge.onVnodeBeforeUpdate) && _t(Z, N, R, P),
        ve && Xt(R, P, N, "beforeUpdate"),
        N && Jt(N, !0),
        ((le.innerHTML && ge.innerHTML == null) ||
          (le.textContent && ge.textContent == null)) &&
          d(oe, ""),
        Y
          ? M(P.dynamicChildren, Y, oe, N, X, vr(R, G), Q)
          : ce || D(P, R, oe, null, N, X, vr(R, G), Q, !1),
        re > 0)
      ) {
        if (re & 16) q(oe, le, ge, N, G);
        else if (
          (re & 2 && le.class !== ge.class && f(oe, "class", null, ge.class, G),
          re & 4 && f(oe, "style", le.style, ge.style, G),
          re & 8)
        ) {
          const p = R.dynamicProps;
          for (let i = 0; i < p.length; i++) {
            const u = p[i],
              h = le[u],
              y = ge[u];
            (y !== h || u === "value") && f(oe, u, h, y, G, N);
          }
        }
        re & 1 && P.children !== R.children && d(oe, R.children);
      } else !ce && Y == null && q(oe, le, ge, N, G);
      ((Z = ge.onVnodeUpdated) || ve) &&
        ft(() => {
          Z && _t(Z, N, R, P), ve && Xt(R, P, N, "updated");
        }, X);
    },
    M = (P, R, N, X, G, Q, ce) => {
      for (let oe = 0; oe < R.length; oe++) {
        const re = P[oe],
          Y = R[oe],
          ve =
            re.el && (re.type === gt || !Sn(re, Y) || re.shapeFlag & 70)
              ? w(re.el)
              : N;
        I(re, Y, ve, null, X, G, Q, ce, !0);
      }
    },
    q = (P, R, N, X, G) => {
      if (R !== N) {
        if (R !== Ue)
          for (const Q in R) !kn(Q) && !(Q in N) && f(P, Q, R[Q], null, G, X);
        for (const Q in N) {
          if (kn(Q)) continue;
          const ce = N[Q],
            oe = R[Q];
          ce !== oe && Q !== "value" && f(P, Q, oe, ce, G, X);
        }
        "value" in N && f(P, "value", R.value, N.value, G);
      }
    },
    W = (P, R, N, X, G, Q, ce, oe, re) => {
      const Y = (R.el = P ? P.el : s("")),
        ve = (R.anchor = P ? P.anchor : s(""));
      let { patchFlag: le, dynamicChildren: ge, slotScopeIds: Z } = R;
      Z && (oe = oe ? oe.concat(Z) : Z),
        P == null
          ? (o(Y, N, X),
            o(ve, N, X),
            j(R.children || [], N, ve, G, Q, ce, oe, re))
          : le > 0 && le & 64 && ge && P.dynamicChildren
          ? (M(P.dynamicChildren, ge, N, G, Q, ce, oe),
            (R.key != null || (G && R === G.subTree)) && zo(P, R, !0))
          : D(P, R, N, ve, G, Q, ce, oe, re);
    },
    ie = (P, R, N, X, G, Q, ce, oe, re) => {
      (R.slotScopeIds = oe),
        P == null
          ? R.shapeFlag & 512
            ? G.ctx.activate(R, N, X, ce, re)
            : ne(R, N, X, G, Q, ce, re)
          : de(P, R, re);
    },
    ne = (P, R, N, X, G, Q, ce) => {
      const oe = (P.component = ou(P, X, G));
      if ((Ao(P) && (oe.ctx.renderer = Pe), su(oe, !1, ce), oe.asyncDep)) {
        if ((G && G.registerDep(oe, he, ce), !P.el)) {
          const re = (oe.subTree = Ee(Wt));
          b(null, re, R, N);
        }
      } else he(oe, P, R, N, G, Q, ce);
    },
    de = (P, R, N) => {
      const X = (R.component = P.component);
      if (Ga(P, R, N))
        if (X.asyncDep && !X.asyncResolved) {
          $(X, R, N);
          return;
        } else (X.next = R), X.update();
      else (R.el = P.el), (X.vnode = R);
    },
    he = (P, R, N, X, G, Q, ce) => {
      const oe = () => {
        if (P.isMounted) {
          let { next: le, bu: ge, u: Z, parent: p, vnode: i } = P;
          {
            const B = Ko(P);
            if (B) {
              le && ((le.el = i.el), $(P, le, ce)),
                B.asyncDep.then(() => {
                  P.isUnmounted || oe();
                });
              return;
            }
          }
          let u = le,
            h;
          Jt(P, !1),
            le ? ((le.el = i.el), $(P, le, ce)) : (le = i),
            ge && dr(ge),
            (h = le.props && le.props.onVnodeBeforeUpdate) && _t(h, p, le, i),
            Jt(P, !0);
          const y = wr(P),
            C = P.subTree;
          (P.subTree = y),
            I(C, y, w(C.el), U(C), P, G, Q),
            (le.el = y.el),
            u === null && Xa(P, y.el),
            Z && ft(Z, G),
            (h = le.props && le.props.onVnodeUpdated) &&
              ft(() => _t(h, p, le, i), G);
        } else {
          let le;
          const { el: ge, props: Z } = R,
            { bm: p, m: i, parent: u, root: h, type: y } = P,
            C = gn(R);
          if (
            (Jt(P, !1),
            p && dr(p),
            !C && (le = Z && Z.onVnodeBeforeMount) && _t(le, u, R),
            Jt(P, !0),
            ge && Ce)
          ) {
            const B = () => {
              (P.subTree = wr(P)), Ce(ge, P.subTree, P, G, null);
            };
            C && y.__asyncHydrate ? y.__asyncHydrate(ge, P, B) : B();
          } else {
            h.ce && h.ce._injectChildStyle(y);
            const B = (P.subTree = wr(P));
            I(null, B, N, X, P, G, Q), (R.el = B.el);
          }
          if ((i && ft(i, G), !C && (le = Z && Z.onVnodeMounted))) {
            const B = R;
            ft(() => _t(le, u, B), G);
          }
          (R.shapeFlag & 256 ||
            (u && gn(u.vnode) && u.vnode.shapeFlag & 256)) &&
            P.a &&
            ft(P.a, G),
            (P.isMounted = !0),
            (R = N = X = null);
        }
      };
      P.scope.on();
      const re = (P.effect = new so(oe));
      P.scope.off();
      const Y = (P.update = re.run.bind(re)),
        ve = (P.job = re.runIfDirty.bind(re));
      (ve.i = P),
        (ve.id = P.uid),
        (re.scheduler = () => Yr(ve)),
        Jt(P, !0),
        Y();
    },
    $ = (P, R, N) => {
      R.component = P;
      const X = P.vnode.props;
      (P.vnode = R),
        (P.next = null),
        Ba(P, R.props, X, N),
        La(P, R.children, N),
        qt(),
        mi(P),
        zt();
    },
    D = (P, R, N, X, G, Q, ce, oe, re = !1) => {
      const Y = P && P.children,
        ve = P ? P.shapeFlag : 0,
        le = R.children,
        { patchFlag: ge, shapeFlag: Z } = R;
      if (ge > 0) {
        if (ge & 128) {
          xe(Y, le, N, X, G, Q, ce, oe, re);
          return;
        } else if (ge & 256) {
          se(Y, le, N, X, G, Q, ce, oe, re);
          return;
        }
      }
      Z & 8
        ? (ve & 16 && O(Y, G, Q), le !== Y && d(N, le))
        : ve & 16
        ? Z & 16
          ? xe(Y, le, N, X, G, Q, ce, oe, re)
          : O(Y, G, Q, !0)
        : (ve & 8 && d(N, ""), Z & 16 && j(le, N, X, G, Q, ce, oe, re));
    },
    se = (P, R, N, X, G, Q, ce, oe, re) => {
      (P = P || dn), (R = R || dn);
      const Y = P.length,
        ve = R.length,
        le = Math.min(Y, ve);
      let ge;
      for (ge = 0; ge < le; ge++) {
        const Z = (R[ge] = re ? Vt(R[ge]) : Et(R[ge]));
        I(P[ge], Z, N, null, G, Q, ce, oe, re);
      }
      Y > ve ? O(P, G, Q, !0, !1, le) : j(R, N, X, G, Q, ce, oe, re, le);
    },
    xe = (P, R, N, X, G, Q, ce, oe, re) => {
      let Y = 0;
      const ve = R.length;
      let le = P.length - 1,
        ge = ve - 1;
      for (; Y <= le && Y <= ge; ) {
        const Z = P[Y],
          p = (R[Y] = re ? Vt(R[Y]) : Et(R[Y]));
        if (Sn(Z, p)) I(Z, p, N, null, G, Q, ce, oe, re);
        else break;
        Y++;
      }
      for (; Y <= le && Y <= ge; ) {
        const Z = P[le],
          p = (R[ge] = re ? Vt(R[ge]) : Et(R[ge]));
        if (Sn(Z, p)) I(Z, p, N, null, G, Q, ce, oe, re);
        else break;
        le--, ge--;
      }
      if (Y > le) {
        if (Y <= ge) {
          const Z = ge + 1,
            p = Z < ve ? R[Z].el : X;
          for (; Y <= ge; )
            I(null, (R[Y] = re ? Vt(R[Y]) : Et(R[Y])), N, p, G, Q, ce, oe, re),
              Y++;
        }
      } else if (Y > ge) for (; Y <= le; ) pe(P[Y], G, Q, !0), Y++;
      else {
        const Z = Y,
          p = Y,
          i = new Map();
        for (Y = p; Y <= ge; Y++) {
          const H = (R[Y] = re ? Vt(R[Y]) : Et(R[Y]));
          H.key != null && i.set(H.key, Y);
        }
        let u,
          h = 0;
        const y = ge - p + 1;
        let C = !1,
          B = 0;
        const ee = new Array(y);
        for (Y = 0; Y < y; Y++) ee[Y] = 0;
        for (Y = Z; Y <= le; Y++) {
          const H = P[Y];
          if (h >= y) {
            pe(H, G, Q, !0);
            continue;
          }
          let ue;
          if (H.key != null) ue = i.get(H.key);
          else
            for (u = p; u <= ge; u++)
              if (ee[u - p] === 0 && Sn(H, R[u])) {
                ue = u;
                break;
              }
          ue === void 0
            ? pe(H, G, Q, !0)
            : ((ee[ue - p] = Y + 1),
              ue >= B ? (B = ue) : (C = !0),
              I(H, R[ue], N, null, G, Q, ce, oe, re),
              h++);
        }
        const V = C ? Ua(ee) : dn;
        for (u = V.length - 1, Y = y - 1; Y >= 0; Y--) {
          const H = p + Y,
            ue = R[H],
            be = H + 1 < ve ? R[H + 1].el : X;
          ee[Y] === 0
            ? I(null, ue, N, be, G, Q, ce, oe, re)
            : C && (u < 0 || Y !== V[u] ? me(ue, N, be, 2) : u--);
        }
      }
    },
    me = (P, R, N, X, G = null) => {
      const { el: Q, type: ce, transition: oe, children: re, shapeFlag: Y } = P;
      if (Y & 6) {
        me(P.component.subTree, R, N, X);
        return;
      }
      if (Y & 128) {
        P.suspense.move(R, N, X);
        return;
      }
      if (Y & 64) {
        ce.move(P, R, N, Pe);
        return;
      }
      if (ce === gt) {
        o(Q, R, N);
        for (let le = 0; le < re.length; le++) me(re[le], R, N, X);
        o(P.anchor, R, N);
        return;
      }
      if (ce === br) {
        _(P, R, N);
        return;
      }
      if (X !== 2 && Y & 1 && oe)
        if (X === 0) oe.beforeEnter(Q), o(Q, R, N), ft(() => oe.enter(Q), G);
        else {
          const { leave: le, delayLeave: ge, afterLeave: Z } = oe,
            p = () => o(Q, R, N),
            i = () => {
              le(Q, () => {
                p(), Z && Z();
              });
            };
          ge ? ge(Q, p, i) : i();
        }
      else o(Q, R, N);
    },
    pe = (P, R, N, X = !1, G = !1) => {
      const {
        type: Q,
        props: ce,
        ref: oe,
        children: re,
        dynamicChildren: Y,
        shapeFlag: ve,
        patchFlag: le,
        dirs: ge,
        cacheIndex: Z,
      } = P;
      if (
        (le === -2 && (G = !1),
        oe != null && Br(oe, null, N, P, !0),
        Z != null && (R.renderCache[Z] = void 0),
        ve & 256)
      ) {
        R.ctx.deactivate(P);
        return;
      }
      const p = ve & 1 && ge,
        i = !gn(P);
      let u;
      if ((i && (u = ce && ce.onVnodeBeforeUnmount) && _t(u, R, P), ve & 6))
        z(P.component, N, X);
      else {
        if (ve & 128) {
          P.suspense.unmount(N, X);
          return;
        }
        p && Xt(P, null, R, "beforeUnmount"),
          ve & 64
            ? P.type.remove(P, R, N, Pe, X)
            : Y && !Y.hasOnce && (Q !== gt || (le > 0 && le & 64))
            ? O(Y, R, N, !1, !0)
            : ((Q === gt && le & 384) || (!G && ve & 16)) && O(re, R, N),
          X && _e(P);
      }
      ((i && (u = ce && ce.onVnodeUnmounted)) || p) &&
        ft(() => {
          u && _t(u, R, P), p && Xt(P, null, R, "unmounted");
        }, N);
    },
    _e = (P) => {
      const { type: R, el: N, anchor: X, transition: G } = P;
      if (R === gt) {
        Te(N, X);
        return;
      }
      if (R === br) {
        m(P);
        return;
      }
      const Q = () => {
        a(N), G && !G.persisted && G.afterLeave && G.afterLeave();
      };
      if (P.shapeFlag & 1 && G && !G.persisted) {
        const { leave: ce, delayLeave: oe } = G,
          re = () => ce(N, Q);
        oe ? oe(P.el, Q, re) : re();
      } else Q();
    },
    Te = (P, R) => {
      let N;
      for (; P !== R; ) (N = S(P)), a(P), (P = N);
      a(R);
    },
    z = (P, R, N) => {
      const { bum: X, scope: G, job: Q, subTree: ce, um: oe, m: re, a: Y } = P;
      _i(re),
        _i(Y),
        X && dr(X),
        G.stop(),
        Q && ((Q.flags |= 8), pe(ce, P, R, N)),
        oe && ft(oe, R),
        ft(() => {
          P.isUnmounted = !0;
        }, R),
        R &&
          R.pendingBranch &&
          !R.isUnmounted &&
          P.asyncDep &&
          !P.asyncResolved &&
          P.suspenseId === R.pendingId &&
          (R.deps--, R.deps === 0 && R.resolve());
    },
    O = (P, R, N, X = !1, G = !1, Q = 0) => {
      for (let ce = Q; ce < P.length; ce++) pe(P[ce], R, N, X, G);
    },
    U = (P) => {
      if (P.shapeFlag & 6) return U(P.component.subTree);
      if (P.shapeFlag & 128) return P.suspense.next();
      const R = S(P.anchor || P.el),
        N = R && R[ca];
      return N ? S(N) : R;
    };
  let K = !1;
  const fe = (P, R, N) => {
      P == null
        ? R._vnode && pe(R._vnode, null, null, !0)
        : I(R._vnode || null, P, R, null, null, null, N),
        (R._vnode = P),
        K || ((K = !0), mi(), Eo(), (K = !1));
    },
    Pe = {
      p: I,
      um: pe,
      m: me,
      r: _e,
      mt: ne,
      mc: j,
      pc: D,
      pbc: M,
      n: U,
      o: e,
    };
  let ke, Ce;
  return { render: fe, hydrate: ke, createApp: Ia(fe, ke) };
}
function vr({ type: e, props: t }, n) {
  return (n === "svg" && e === "foreignObject") ||
    (n === "mathml" &&
      e === "annotation-xml" &&
      t &&
      t.encoding &&
      t.encoding.includes("html"))
    ? void 0
    : n;
}
function Jt({ effect: e, job: t }, n) {
  n ? ((e.flags |= 32), (t.flags |= 4)) : ((e.flags &= -33), (t.flags &= -5));
}
function $a(e, t) {
  return (!e || (e && !e.pendingBranch)) && t && !t.persisted;
}
function zo(e, t, n = !1) {
  const o = e.children,
    a = t.children;
  if (Be(o) && Be(a))
    for (let f = 0; f < o.length; f++) {
      const c = o[f];
      let s = a[f];
      s.shapeFlag & 1 &&
        !s.dynamicChildren &&
        ((s.patchFlag <= 0 || s.patchFlag === 32) &&
          ((s = a[f] = Vt(a[f])), (s.el = c.el)),
        !n && s.patchFlag !== -2 && zo(c, s)),
        s.type === ar && (s.el = c.el);
    }
}
function Ua(e) {
  const t = e.slice(),
    n = [0];
  let o, a, f, c, s;
  const r = e.length;
  for (o = 0; o < r; o++) {
    const l = e[o];
    if (l !== 0) {
      if (((a = n[n.length - 1]), e[a] < l)) {
        (t[o] = a), n.push(o);
        continue;
      }
      for (f = 0, c = n.length - 1; f < c; )
        (s = (f + c) >> 1), e[n[s]] < l ? (f = s + 1) : (c = s);
      l < e[n[f]] && (f > 0 && (t[o] = n[f - 1]), (n[f] = o));
    }
  }
  for (f = n.length, c = n[f - 1]; f-- > 0; ) (n[f] = c), (c = t[c]);
  return n;
}
function Ko(e) {
  const t = e.subTree.component;
  if (t) return t.asyncDep && !t.asyncResolved ? t : Ko(t);
}
function _i(e) {
  if (e) for (let t = 0; t < e.length; t++) e[t].flags |= 8;
}
const Na = Symbol.for("v-scx"),
  Va = () => yn(Na);
function Ha(e, t) {
  return ri(e, null, t);
}
function vn(e, t, n) {
  return ri(e, t, n);
}
function ri(e, t, n = Ue) {
  const { immediate: o, deep: a, flush: f, once: c } = n,
    s = Xe({}, n),
    r = (t && o) || (!t && f !== "post");
  let l;
  if (Ln) {
    if (f === "sync") {
      const x = Va();
      l = x.__watcherHandles || (x.__watcherHandles = []);
    } else if (!r) {
      const x = () => {};
      return (x.stop = Tt), (x.resume = Tt), (x.pause = Tt), x;
    }
  }
  const d = et;
  s.call = (x, E, I) => At(x, d, E, I);
  let w = !1;
  f === "post"
    ? (s.scheduler = (x) => {
        ft(x, d && d.suspense);
      })
    : f !== "sync" &&
      ((w = !0),
      (s.scheduler = (x, E) => {
        E ? x() : Yr(x);
      })),
    (s.augmentJob = (x) => {
      t && (x.flags |= 4),
        w && ((x.flags |= 2), d && ((x.id = d.uid), (x.i = d)));
    });
  const S = ia(e, t, s);
  return Ln && (l ? l.push(S) : r && S()), S;
}
function Za(e, t, n) {
  const o = this.proxy,
    a = ze(e) ? (e.includes(".") ? Go(o, e) : () => o[e]) : e.bind(o, o);
  let f;
  Oe(t) ? (f = t) : ((f = t.handler), (n = t));
  const c = Dn(this),
    s = ri(a, f.bind(o), n);
  return c(), s;
}
function Go(e, t) {
  const n = t.split(".");
  return () => {
    let o = e;
    for (let a = 0; a < n.length && o; a++) o = o[n[a]];
    return o;
  };
}
const Wa = (e, t) =>
  t === "modelValue" || t === "model-value"
    ? e.modelModifiers
    : e[`${t}Modifiers`] || e[`${mt(t)}Modifiers`] || e[`${rn(t)}Modifiers`];
function qa(e, t, ...n) {
  if (e.isUnmounted) return;
  const o = e.vnode.props || Ue;
  let a = n;
  const f = t.startsWith("update:"),
    c = f && Wa(o, t.slice(7));
  c &&
    (c.trim && (a = n.map((d) => (ze(d) ? d.trim() : d))),
    c.number && (a = n.map(Ss)));
  let s,
    r = o[(s = fr(t))] || o[(s = fr(mt(t)))];
  !r && f && (r = o[(s = fr(rn(t)))]), r && At(r, e, 6, a);
  const l = o[s + "Once"];
  if (l) {
    if (!e.emitted) e.emitted = {};
    else if (e.emitted[s]) return;
    (e.emitted[s] = !0), At(l, e, 6, a);
  }
}
function Xo(e, t, n = !1) {
  const o = t.emitsCache,
    a = o.get(e);
  if (a !== void 0) return a;
  const f = e.emits;
  let c = {},
    s = !1;
  if (!Oe(e)) {
    const r = (l) => {
      const d = Xo(l, t, !0);
      d && ((s = !0), Xe(c, d));
    };
    !n && t.mixins.length && t.mixins.forEach(r),
      e.extends && r(e.extends),
      e.mixins && e.mixins.forEach(r);
  }
  return !f && !s
    ? (He(e) && o.set(e, null), null)
    : (Be(f) ? f.forEach((r) => (c[r] = null)) : Xe(c, f),
      He(e) && o.set(e, c),
      c);
}
function sr(e, t) {
  return !e || !Yn(t)
    ? !1
    : ((t = t.slice(2).replace(/Once$/, "")),
      De(e, t[0].toLowerCase() + t.slice(1)) || De(e, rn(t)) || De(e, t));
}
function wr(e) {
  const {
      type: t,
      vnode: n,
      proxy: o,
      withProxy: a,
      propsOptions: [f],
      slots: c,
      attrs: s,
      emit: r,
      render: l,
      renderCache: d,
      props: w,
      data: S,
      setupState: x,
      ctx: E,
      inheritAttrs: I,
    } = e,
    k = Gn(e);
  let b, g;
  try {
    if (n.shapeFlag & 4) {
      const m = a || o,
        v = m;
      (b = Et(l.call(v, m, d, w, x, S, E))), (g = s);
    } else {
      const m = t;
      (b = Et(
        m.length > 1 ? m(w, { attrs: s, slots: c, emit: r }) : m(w, null)
      )),
        (g = t.props ? s : za(s));
    }
  } catch (m) {
    (On.length = 0), rr(m, e, 1), (b = Ee(Wt));
  }
  let _ = b;
  if (g && I !== !1) {
    const m = Object.keys(g),
      { shapeFlag: v } = _;
    m.length &&
      v & 7 &&
      (f && m.some(Nr) && (g = Ka(g, f)), (_ = wn(_, g, !1, !0)));
  }
  return (
    n.dirs &&
      ((_ = wn(_, null, !1, !0)),
      (_.dirs = _.dirs ? _.dirs.concat(n.dirs) : n.dirs)),
    n.transition && Qr(_, n.transition),
    (b = _),
    Gn(k),
    b
  );
}
const za = (e) => {
    let t;
    for (const n in e)
      (n === "class" || n === "style" || Yn(n)) && ((t || (t = {}))[n] = e[n]);
    return t;
  },
  Ka = (e, t) => {
    const n = {};
    for (const o in e) (!Nr(o) || !(o.slice(9) in t)) && (n[o] = e[o]);
    return n;
  };
function Ga(e, t, n) {
  const { props: o, children: a, component: f } = e,
    { props: c, children: s, patchFlag: r } = t,
    l = f.emitsOptions;
  if (t.dirs || t.transition) return !0;
  if (n && r >= 0) {
    if (r & 1024) return !0;
    if (r & 16) return o ? Ci(o, c, l) : !!c;
    if (r & 8) {
      const d = t.dynamicProps;
      for (let w = 0; w < d.length; w++) {
        const S = d[w];
        if (c[S] !== o[S] && !sr(l, S)) return !0;
      }
    }
  } else
    return (a || s) && (!s || !s.$stable)
      ? !0
      : o === c
      ? !1
      : o
      ? c
        ? Ci(o, c, l)
        : !0
      : !!c;
  return !1;
}
function Ci(e, t, n) {
  const o = Object.keys(t);
  if (o.length !== Object.keys(e).length) return !0;
  for (let a = 0; a < o.length; a++) {
    const f = o[a];
    if (t[f] !== e[f] && !sr(n, f)) return !0;
  }
  return !1;
}
function Xa({ vnode: e, parent: t }, n) {
  for (; t; ) {
    const o = t.subTree;
    if ((o.suspense && o.suspense.activeBranch === e && (o.el = e.el), o === e))
      ((e = t.vnode).el = n), (t = t.parent);
    else break;
  }
}
const Jo = (e) => e.__isSuspense;
function Ja(e, t) {
  t && t.pendingBranch
    ? Be(e)
      ? t.effects.push(...e)
      : t.effects.push(e)
    : ua(e);
}
const gt = Symbol.for("v-fgt"),
  ar = Symbol.for("v-txt"),
  Wt = Symbol.for("v-cmt"),
  br = Symbol.for("v-stc"),
  On = [];
let ht = null;
function Ae(e = !1) {
  On.push((ht = e ? null : []));
}
function Ya() {
  On.pop(), (ht = On[On.length - 1] || null);
}
let jn = 1;
function Ei(e) {
  (jn += e), e < 0 && ht && (ht.hasOnce = !0);
}
function Yo(e) {
  return (
    (e.dynamicChildren = jn > 0 ? ht || dn : null),
    Ya(),
    jn > 0 && ht && ht.push(e),
    e
  );
}
function Fe(e, t, n, o, a, f) {
  return Yo(je(e, t, n, o, a, f, !0));
}
function tt(e, t, n, o, a) {
  return Yo(Ee(e, t, n, o, a, !0));
}
function ii(e) {
  return e ? e.__v_isVNode === !0 : !1;
}
function Sn(e, t) {
  return e.type === t.type && e.key === t.key;
}
const Qo = ({ key: e }) => e ?? null,
  Wn = ({ ref: e, ref_key: t, ref_for: n }) => (
    typeof e == "number" && (e = "" + e),
    e != null
      ? ze(e) || nt(e) || Oe(e)
        ? { i: ut, r: e, k: t, f: !!n }
        : e
      : null
  );
function je(
  e,
  t = null,
  n = null,
  o = 0,
  a = null,
  f = e === gt ? 0 : 1,
  c = !1,
  s = !1
) {
  const r = {
    __v_isVNode: !0,
    __v_skip: !0,
    type: e,
    props: t,
    key: t && Qo(t),
    ref: t && Wn(t),
    scopeId: To,
    slotScopeIds: null,
    children: n,
    component: null,
    suspense: null,
    ssContent: null,
    ssFallback: null,
    dirs: null,
    transition: null,
    el: null,
    anchor: null,
    target: null,
    targetStart: null,
    targetAnchor: null,
    staticCount: 0,
    shapeFlag: f,
    patchFlag: o,
    dynamicProps: a,
    dynamicChildren: null,
    appContext: null,
    ctx: ut,
  };
  return (
    s
      ? (oi(r, n), f & 128 && e.normalize(r))
      : n && (r.shapeFlag |= ze(n) ? 8 : 16),
    jn > 0 &&
      !c &&
      ht &&
      (r.patchFlag > 0 || f & 6) &&
      r.patchFlag !== 32 &&
      ht.push(r),
    r
  );
}
const Ee = Qa;
function Qa(e, t = null, n = null, o = 0, a = null, f = !1) {
  if (((!e || e === Ro) && (e = Wt), ii(e))) {
    const s = wn(e, t, !0);
    return (
      n && oi(s, n),
      jn > 0 &&
        !f &&
        ht &&
        (s.shapeFlag & 6 ? (ht[ht.indexOf(e)] = s) : ht.push(s)),
      (s.patchFlag = -2),
      s
    );
  }
  if ((fu(e) && (e = e.__vccOpts), t)) {
    t = eu(t);
    let { class: s, style: r } = t;
    s && !ze(s) && (t.class = Pt(s)),
      He(r) && (Jr(r) && !Be(r) && (r = Xe({}, r)), (t.style = ye(r)));
  }
  const c = ze(e) ? 1 : Jo(e) ? 128 : la(e) ? 64 : He(e) ? 4 : Oe(e) ? 2 : 0;
  return je(e, t, n, o, a, c, f, !0);
}
function eu(e) {
  return e ? (Jr(e) || Uo(e) ? Xe({}, e) : e) : null;
}
function wn(e, t, n = !1, o = !1) {
  const { props: a, ref: f, patchFlag: c, children: s, transition: r } = e,
    l = t ? nu(a || {}, t) : a,
    d = {
      __v_isVNode: !0,
      __v_skip: !0,
      type: e.type,
      props: l,
      key: l && Qo(l),
      ref:
        t && t.ref
          ? n && f
            ? Be(f)
              ? f.concat(Wn(t))
              : [f, Wn(t)]
            : Wn(t)
          : f,
      scopeId: e.scopeId,
      slotScopeIds: e.slotScopeIds,
      children: s,
      target: e.target,
      targetStart: e.targetStart,
      targetAnchor: e.targetAnchor,
      staticCount: e.staticCount,
      shapeFlag: e.shapeFlag,
      patchFlag: t && e.type !== gt ? (c === -1 ? 16 : c | 16) : c,
      dynamicProps: e.dynamicProps,
      dynamicChildren: e.dynamicChildren,
      appContext: e.appContext,
      dirs: e.dirs,
      transition: r,
      component: e.component,
      suspense: e.suspense,
      ssContent: e.ssContent && wn(e.ssContent),
      ssFallback: e.ssFallback && wn(e.ssFallback),
      el: e.el,
      anchor: e.anchor,
      ctx: e.ctx,
      ce: e.ce,
    };
  return r && o && Qr(d, r.clone(d)), d;
}
function tu(e = " ", t = 0) {
  return Ee(ar, null, e, t);
}
function Ve(e = "", t = !1) {
  return t ? (Ae(), tt(Wt, null, e)) : Ee(Wt, null, e);
}
function Et(e) {
  return e == null || typeof e == "boolean"
    ? Ee(Wt)
    : Be(e)
    ? Ee(gt, null, e.slice())
    : ii(e)
    ? Vt(e)
    : Ee(ar, null, String(e));
}
function Vt(e) {
  return (e.el === null && e.patchFlag !== -1) || e.memo ? e : wn(e);
}
function oi(e, t) {
  let n = 0;
  const { shapeFlag: o } = e;
  if (t == null) t = null;
  else if (Be(t)) n = 16;
  else if (typeof t == "object")
    if (o & 65) {
      const a = t.default;
      a && (a._c && (a._d = !1), oi(e, a()), a._c && (a._d = !0));
      return;
    } else {
      n = 32;
      const a = t._;
      !a && !Uo(t)
        ? (t._ctx = ut)
        : a === 3 &&
          ut &&
          (ut.slots._ === 1 ? (t._ = 1) : ((t._ = 2), (e.patchFlag |= 1024)));
    }
  else
    Oe(t)
      ? ((t = { default: t, _ctx: ut }), (n = 32))
      : ((t = String(t)), o & 64 ? ((n = 16), (t = [tu(t)])) : (n = 8));
  (e.children = t), (e.shapeFlag |= n);
}
function nu(...e) {
  const t = {};
  for (let n = 0; n < e.length; n++) {
    const o = e[n];
    for (const a in o)
      if (a === "class")
        t.class !== o.class && (t.class = Pt([t.class, o.class]));
      else if (a === "style") t.style = ye([t.style, o.style]);
      else if (Yn(a)) {
        const f = t[a],
          c = o[a];
        c &&
          f !== c &&
          !(Be(f) && f.includes(c)) &&
          (t[a] = f ? [].concat(f, c) : c);
      } else a !== "" && (t[a] = o[a]);
  }
  return t;
}
function _t(e, t, n, o = null) {
  At(e, t, 7, [n, o]);
}
const ru = Mo();
let iu = 0;
function ou(e, t, n) {
  const o = e.type,
    a = (t ? t.appContext : e.appContext) || ru,
    f = {
      uid: iu++,
      vnode: e,
      type: o,
      parent: t,
      appContext: a,
      root: null,
      next: null,
      subTree: null,
      effect: null,
      update: null,
      job: null,
      scope: new As(!0),
      render: null,
      proxy: null,
      exposed: null,
      exposeProxy: null,
      withProxy: null,
      provides: t ? t.provides : Object.create(a.provides),
      ids: t ? t.ids : ["", 0, 0],
      accessCache: null,
      renderCache: [],
      components: null,
      directives: null,
      propsOptions: Vo(o, a),
      emitsOptions: Xo(o, a),
      emit: null,
      emitted: null,
      propsDefaults: Ue,
      inheritAttrs: o.inheritAttrs,
      ctx: Ue,
      data: Ue,
      props: Ue,
      attrs: Ue,
      slots: Ue,
      refs: Ue,
      setupState: Ue,
      setupContext: null,
      suspense: n,
      suspenseId: n ? n.pendingId : 0,
      asyncDep: null,
      asyncResolved: !1,
      isMounted: !1,
      isUnmounted: !1,
      isDeactivated: !1,
      bc: null,
      c: null,
      bm: null,
      m: null,
      bu: null,
      u: null,
      um: null,
      bum: null,
      da: null,
      a: null,
      rtg: null,
      rtc: null,
      ec: null,
      sp: null,
    };
  return (
    (f.ctx = { _: f }),
    (f.root = t ? t.root : f),
    (f.emit = qa.bind(null, f)),
    e.ce && e.ce(f),
    f
  );
}
let et = null,
  Jn,
  Mr;
{
  const e = nr(),
    t = (n, o) => {
      let a;
      return (
        (a = e[n]) || (a = e[n] = []),
        a.push(o),
        (f) => {
          a.length > 1 ? a.forEach((c) => c(f)) : a[0](f);
        }
      );
    };
  (Jn = t("__VUE_INSTANCE_SETTERS__", (n) => (et = n))),
    (Mr = t("__VUE_SSR_SETTERS__", (n) => (Ln = n)));
}
const Dn = (e) => {
    const t = et;
    return (
      Jn(e),
      e.scope.on(),
      () => {
        e.scope.off(), Jn(t);
      }
    );
  },
  ki = () => {
    et && et.scope.off(), Jn(null);
  };
function es(e) {
  return e.vnode.shapeFlag & 4;
}
let Ln = !1;
function su(e, t = !1, n = !1) {
  t && Mr(t);
  const { props: o, children: a } = e.vnode,
    f = es(e);
  Oa(e, o, f, t), ja(e, a, n);
  const c = f ? au(e, t) : void 0;
  return t && Mr(!1), c;
}
function au(e, t) {
  const n = e.type;
  (e.accessCache = Object.create(null)), (e.proxy = new Proxy(e.ctx, _a));
  const { setup: o } = n;
  if (o) {
    qt();
    const a = (e.setupContext = o.length > 1 ? cu(e) : null),
      f = Dn(e),
      c = Mn(o, e, 0, [e.props, a]),
      s = Qi(c);
    if ((zt(), f(), (s || e.sp) && !gn(e) && Po(e), s)) {
      if ((c.then(ki, ki), t))
        return c
          .then((r) => {
            Ti(e, r, t);
          })
          .catch((r) => {
            rr(r, e, 0);
          });
      e.asyncDep = c;
    } else Ti(e, c, t);
  } else ts(e, t);
}
function Ti(e, t, n) {
  Oe(t)
    ? e.type.__ssrInlineRender
      ? (e.ssrRender = t)
      : (e.render = t)
    : He(t) && (e.setupState = So(t)),
    ts(e, n);
}
let Pi;
function ts(e, t, n) {
  const o = e.type;
  if (!e.render) {
    if (!t && Pi && !o.render) {
      const a = o.template || ei(e).template;
      if (a) {
        const { isCustomElement: f, compilerOptions: c } = e.appContext.config,
          { delimiters: s, compilerOptions: r } = o,
          l = Xe(Xe({ isCustomElement: f, delimiters: s }, c), r);
        o.render = Pi(a, l);
      }
    }
    e.render = o.render || Tt;
  }
  {
    const a = Dn(e);
    qt();
    try {
      Ca(e);
    } finally {
      zt(), a();
    }
  }
}
const uu = {
  get(e, t) {
    return Qe(e, "get", ""), e[t];
  },
};
function cu(e) {
  const t = (n) => {
    e.exposed = n || {};
  };
  return {
    attrs: new Proxy(e.attrs, uu),
    slots: e.slots,
    emit: e.emit,
    expose: t,
  };
}
function si(e) {
  return e.exposed
    ? e.exposeProxy ||
        (e.exposeProxy = new Proxy(So(Xs(e.exposed)), {
          get(t, n) {
            if (n in t) return t[n];
            if (n in In) return In[n](e);
          },
          has(t, n) {
            return n in t || n in In;
          },
        }))
    : e.proxy;
}
function lu(e, t = !0) {
  return Oe(e) ? e.displayName || e.name : e.name || (t && e.__name);
}
function fu(e) {
  return Oe(e) && "__vccOpts" in e;
}
const lt = (e, t) => na(e, t, Ln),
  du = "3.5.12";
/**
 * @vue/runtime-dom v3.5.12
 * (c) 2018-present Yuxi (Evan) You and Vue contributors
 * @license MIT
 **/ let Dr;
const Ai = typeof window < "u" && window.trustedTypes;
if (Ai)
  try {
    Dr = Ai.createPolicy("vue", { createHTML: (e) => e });
  } catch {}
const ns = Dr ? (e) => Dr.createHTML(e) : (e) => e,
  hu = "http://www.w3.org/2000/svg",
  pu = "http://www.w3.org/1998/Math/MathML",
  Ft = typeof document < "u" ? document : null,
  Ii = Ft && Ft.createElement("template"),
  gu = {
    insert: (e, t, n) => {
      t.insertBefore(e, n || null);
    },
    remove: (e) => {
      const t = e.parentNode;
      t && t.removeChild(e);
    },
    createElement: (e, t, n, o) => {
      const a =
        t === "svg"
          ? Ft.createElementNS(hu, e)
          : t === "mathml"
          ? Ft.createElementNS(pu, e)
          : n
          ? Ft.createElement(e, { is: n })
          : Ft.createElement(e);
      return (
        e === "select" &&
          o &&
          o.multiple != null &&
          a.setAttribute("multiple", o.multiple),
        a
      );
    },
    createText: (e) => Ft.createTextNode(e),
    createComment: (e) => Ft.createComment(e),
    setText: (e, t) => {
      e.nodeValue = t;
    },
    setElementText: (e, t) => {
      e.textContent = t;
    },
    parentNode: (e) => e.parentNode,
    nextSibling: (e) => e.nextSibling,
    querySelector: (e) => Ft.querySelector(e),
    setScopeId(e, t) {
      e.setAttribute(t, "");
    },
    insertStaticContent(e, t, n, o, a, f) {
      const c = n ? n.previousSibling : t.lastChild;
      if (a && (a === f || a.nextSibling))
        for (
          ;
          t.insertBefore(a.cloneNode(!0), n),
            !(a === f || !(a = a.nextSibling));

        );
      else {
        Ii.innerHTML = ns(
          o === "svg"
            ? `<svg>${e}</svg>`
            : o === "mathml"
            ? `<math>${e}</math>`
            : e
        );
        const s = Ii.content;
        if (o === "svg" || o === "mathml") {
          const r = s.firstChild;
          for (; r.firstChild; ) s.appendChild(r.firstChild);
          s.removeChild(r);
        }
        t.insertBefore(s, n);
      }
      return [
        c ? c.nextSibling : t.firstChild,
        n ? n.previousSibling : t.lastChild,
      ];
    },
  },
  mu = Symbol("_vtc");
function yu(e, t, n) {
  const o = e[mu];
  o && (t = (t ? [t, ...o] : [...o]).join(" ")),
    t == null
      ? e.removeAttribute("class")
      : n
      ? e.setAttribute("class", t)
      : (e.className = t);
}
const Oi = Symbol("_vod"),
  vu = Symbol("_vsh"),
  wu = Symbol(""),
  bu = /(^|;)\s*display\s*:/;
function xu(e, t, n) {
  const o = e.style,
    a = ze(n);
  let f = !1;
  if (n && !a) {
    if (t)
      if (ze(t))
        for (const c of t.split(";")) {
          const s = c.slice(0, c.indexOf(":")).trim();
          n[s] == null && qn(o, s, "");
        }
      else for (const c in t) n[c] == null && qn(o, c, "");
    for (const c in n) c === "display" && (f = !0), qn(o, c, n[c]);
  } else if (a) {
    if (t !== n) {
      const c = o[wu];
      c && (n += ";" + c), (o.cssText = n), (f = bu.test(n));
    }
  } else t && e.removeAttribute("style");
  Oi in e && ((e[Oi] = f ? o.display : ""), e[vu] && (o.display = "none"));
}
const Bi = /\s*!important$/;
function qn(e, t, n) {
  if (Be(n)) n.forEach((o) => qn(e, t, o));
  else if ((n == null && (n = ""), t.startsWith("--"))) e.setProperty(t, n);
  else {
    const o = Su(e, t);
    Bi.test(n)
      ? e.setProperty(rn(o), n.replace(Bi, ""), "important")
      : (e[o] = n);
  }
}
const Ri = ["Webkit", "Moz", "ms"],
  xr = {};
function Su(e, t) {
  const n = xr[t];
  if (n) return n;
  let o = mt(t);
  if (o !== "filter" && o in e) return (xr[t] = o);
  o = tr(o);
  for (let a = 0; a < Ri.length; a++) {
    const f = Ri[a] + o;
    if (f in e) return (xr[t] = f);
  }
  return t;
}
const Fi = "http://www.w3.org/1999/xlink";
function ji(e, t, n, o, a, f = Ps(t)) {
  o && t.startsWith("xlink:")
    ? n == null
      ? e.removeAttributeNS(Fi, t.slice(6, t.length))
      : e.setAttributeNS(Fi, t, n)
    : n == null || (f && !ro(n))
    ? e.removeAttribute(t)
    : e.setAttribute(t, f ? "" : Mt(n) ? String(n) : n);
}
function Li(e, t, n, o, a) {
  if (t === "innerHTML" || t === "textContent") {
    n != null && (e[t] = t === "innerHTML" ? ns(n) : n);
    return;
  }
  const f = e.tagName;
  if (t === "value" && f !== "PROGRESS" && !f.includes("-")) {
    const s = f === "OPTION" ? e.getAttribute("value") || "" : e.value,
      r = n == null ? (e.type === "checkbox" ? "on" : "") : String(n);
    (s !== r || !("_value" in e)) && (e.value = r),
      n == null && e.removeAttribute(t),
      (e._value = n);
    return;
  }
  let c = !1;
  if (n === "" || n == null) {
    const s = typeof e[t];
    s === "boolean"
      ? (n = ro(n))
      : n == null && s === "string"
      ? ((n = ""), (c = !0))
      : s === "number" && ((n = 0), (c = !0));
  }
  try {
    e[t] = n;
  } catch {}
  c && e.removeAttribute(a || t);
}
function _u(e, t, n, o) {
  e.addEventListener(t, n, o);
}
function Cu(e, t, n, o) {
  e.removeEventListener(t, n, o);
}
const Mi = Symbol("_vei");
function Eu(e, t, n, o, a = null) {
  const f = e[Mi] || (e[Mi] = {}),
    c = f[t];
  if (o && c) c.value = o;
  else {
    const [s, r] = ku(t);
    if (o) {
      const l = (f[t] = Au(o, a));
      _u(e, s, l, r);
    } else c && (Cu(e, s, c, r), (f[t] = void 0));
  }
}
const Di = /(?:Once|Passive|Capture)$/;
function ku(e) {
  let t;
  if (Di.test(e)) {
    t = {};
    let o;
    for (; (o = e.match(Di)); )
      (e = e.slice(0, e.length - o[0].length)), (t[o[0].toLowerCase()] = !0);
  }
  return [e[2] === ":" ? e.slice(3) : rn(e.slice(2)), t];
}
let Sr = 0;
const Tu = Promise.resolve(),
  Pu = () => Sr || (Tu.then(() => (Sr = 0)), (Sr = Date.now()));
function Au(e, t) {
  const n = (o) => {
    if (!o._vts) o._vts = Date.now();
    else if (o._vts <= n.attached) return;
    At(Iu(o, n.value), t, 5, [o]);
  };
  return (n.value = e), (n.attached = Pu()), n;
}
function Iu(e, t) {
  if (Be(t)) {
    const n = e.stopImmediatePropagation;
    return (
      (e.stopImmediatePropagation = () => {
        n.call(e), (e._stopped = !0);
      }),
      t.map((o) => (a) => !a._stopped && o && o(a))
    );
  } else return t;
}
const $i = (e) =>
    e.charCodeAt(0) === 111 &&
    e.charCodeAt(1) === 110 &&
    e.charCodeAt(2) > 96 &&
    e.charCodeAt(2) < 123,
  Ou = (e, t, n, o, a, f) => {
    const c = a === "svg";
    t === "class"
      ? yu(e, o, c)
      : t === "style"
      ? xu(e, n, o)
      : Yn(t)
      ? Nr(t) || Eu(e, t, n, o, f)
      : (
          t[0] === "."
            ? ((t = t.slice(1)), !0)
            : t[0] === "^"
            ? ((t = t.slice(1)), !1)
            : Bu(e, t, o, c)
        )
      ? (Li(e, t, o),
        !e.tagName.includes("-") &&
          (t === "value" || t === "checked" || t === "selected") &&
          ji(e, t, o, c, f, t !== "value"))
      : e._isVueCE && (/[A-Z]/.test(t) || !ze(o))
      ? Li(e, mt(t), o, f, t)
      : (t === "true-value"
          ? (e._trueValue = o)
          : t === "false-value" && (e._falseValue = o),
        ji(e, t, o, c));
  };
function Bu(e, t, n, o) {
  if (o)
    return !!(
      t === "innerHTML" ||
      t === "textContent" ||
      (t in e && $i(t) && Oe(n))
    );
  if (
    t === "spellcheck" ||
    t === "draggable" ||
    t === "translate" ||
    t === "form" ||
    (t === "list" && e.tagName === "INPUT") ||
    (t === "type" && e.tagName === "TEXTAREA")
  )
    return !1;
  if (t === "width" || t === "height") {
    const a = e.tagName;
    if (a === "IMG" || a === "VIDEO" || a === "CANVAS" || a === "SOURCE")
      return !1;
  }
  return $i(t) && ze(n) ? !1 : t in e;
}
const Ru = ["ctrl", "shift", "alt", "meta"],
  Fu = {
    stop: (e) => e.stopPropagation(),
    prevent: (e) => e.preventDefault(),
    self: (e) => e.target !== e.currentTarget,
    ctrl: (e) => !e.ctrlKey,
    shift: (e) => !e.shiftKey,
    alt: (e) => !e.altKey,
    meta: (e) => !e.metaKey,
    left: (e) => "button" in e && e.button !== 0,
    middle: (e) => "button" in e && e.button !== 1,
    right: (e) => "button" in e && e.button !== 2,
    exact: (e, t) => Ru.some((n) => e[`${n}Key`] && !t.includes(n)),
  },
  ur = (e, t) => {
    const n = e._withMods || (e._withMods = {}),
      o = t.join(".");
    return (
      n[o] ||
      (n[o] = (a, ...f) => {
        for (let c = 0; c < t.length; c++) {
          const s = Fu[t[c]];
          if (s && s(a, t)) return;
        }
        return e(a, ...f);
      })
    );
  },
  ju = Xe({ patchProp: Ou }, gu);
let Ui;
function Lu() {
  return Ui || (Ui = Ma(ju));
}
const Mu = (...e) => {
  const t = Lu().createApp(...e),
    { mount: n } = t;
  return (
    (t.mount = (o) => {
      const a = $u(o);
      if (!a) return;
      const f = t._component;
      !Oe(f) && !f.render && !f.template && (f.template = a.innerHTML),
        a.nodeType === 1 && (a.textContent = "");
      const c = n(a, !1, Du(a));
      return (
        a instanceof Element &&
          (a.removeAttribute("v-cloak"), a.setAttribute("data-v-app", "")),
        c
      );
    }),
    t
  );
};
function Du(e) {
  if (e instanceof SVGElement) return "svg";
  if (typeof MathMLElement == "function" && e instanceof MathMLElement)
    return "mathml";
}
function $u(e) {
  return ze(e) ? document.querySelector(e) : e;
}
const Ni = {
    "970x90": "Layout970x90",
    "728x90": "Layout728x90",
    "320x50": "Layout320x50",
    "320x100": "Layout320x100",
  },
  Uu = 1.2,
  Nu = 1.5,
  Vu = 300 / 450,
  Hu = 750 / 250;
function Zu(e, t, n) {
  const o = `${e}x${t}`;
  return n
    ? e / t <= Vu
      ? "LayoutVideoTall"
      : e / t >= Hu
      ? "LayoutVideoWide"
      : "LayoutVideoSquare"
    : Ni[o]
    ? Ni[o]
    : e === t
    ? "LayoutSquare"
    : t / e > Uu
    ? "LayoutTall"
    : e / t > Nu
    ? "LayoutWide"
    : "LayoutSquare";
}
const rs = Symbol(),
  is = Symbol();
var os = {},
  cr = {};
cr.byteLength = zu;
cr.toByteArray = Gu;
cr.fromByteArray = Yu;
var kt = [],
  pt = [],
  Wu = typeof Uint8Array < "u" ? Uint8Array : Array,
  _r = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
for (var cn = 0, qu = _r.length; cn < qu; ++cn)
  (kt[cn] = _r[cn]), (pt[_r.charCodeAt(cn)] = cn);
pt[45] = 62;
pt[95] = 63;
function ss(e) {
  var t = e.length;
  if (t % 4 > 0)
    throw new Error("Invalid string. Length must be a multiple of 4");
  var n = e.indexOf("=");
  n === -1 && (n = t);
  var o = n === t ? 0 : 4 - (n % 4);
  return [n, o];
}
function zu(e) {
  var t = ss(e),
    n = t[0],
    o = t[1];
  return ((n + o) * 3) / 4 - o;
}
function Ku(e, t, n) {
  return ((t + n) * 3) / 4 - n;
}
function Gu(e) {
  var t,
    n = ss(e),
    o = n[0],
    a = n[1],
    f = new Wu(Ku(e, o, a)),
    c = 0,
    s = a > 0 ? o - 4 : o,
    r;
  for (r = 0; r < s; r += 4)
    (t =
      (pt[e.charCodeAt(r)] << 18) |
      (pt[e.charCodeAt(r + 1)] << 12) |
      (pt[e.charCodeAt(r + 2)] << 6) |
      pt[e.charCodeAt(r + 3)]),
      (f[c++] = (t >> 16) & 255),
      (f[c++] = (t >> 8) & 255),
      (f[c++] = t & 255);
  return (
    a === 2 &&
      ((t = (pt[e.charCodeAt(r)] << 2) | (pt[e.charCodeAt(r + 1)] >> 4)),
      (f[c++] = t & 255)),
    a === 1 &&
      ((t =
        (pt[e.charCodeAt(r)] << 10) |
        (pt[e.charCodeAt(r + 1)] << 4) |
        (pt[e.charCodeAt(r + 2)] >> 2)),
      (f[c++] = (t >> 8) & 255),
      (f[c++] = t & 255)),
    f
  );
}
function Xu(e) {
  return (
    kt[(e >> 18) & 63] + kt[(e >> 12) & 63] + kt[(e >> 6) & 63] + kt[e & 63]
  );
}
function Ju(e, t, n) {
  for (var o, a = [], f = t; f < n; f += 3)
    (o =
      ((e[f] << 16) & 16711680) + ((e[f + 1] << 8) & 65280) + (e[f + 2] & 255)),
      a.push(Xu(o));
  return a.join("");
}
function Yu(e) {
  for (
    var t, n = e.length, o = n % 3, a = [], f = 16383, c = 0, s = n - o;
    c < s;
    c += f
  )
    a.push(Ju(e, c, c + f > s ? s : c + f));
  return (
    o === 1
      ? ((t = e[n - 1]), a.push(kt[t >> 2] + kt[(t << 4) & 63] + "=="))
      : o === 2 &&
        ((t = (e[n - 2] << 8) + e[n - 1]),
        a.push(kt[t >> 10] + kt[(t >> 4) & 63] + kt[(t << 2) & 63] + "=")),
    a.join("")
  );
}
var ai = {};
/*! ieee754. BSD-3-Clause License. Feross Aboukhadijeh <https://feross.org/opensource> */ ai.read =
  function (e, t, n, o, a) {
    var f,
      c,
      s = a * 8 - o - 1,
      r = (1 << s) - 1,
      l = r >> 1,
      d = -7,
      w = n ? a - 1 : 0,
      S = n ? -1 : 1,
      x = e[t + w];
    for (
      w += S, f = x & ((1 << -d) - 1), x >>= -d, d += s;
      d > 0;
      f = f * 256 + e[t + w], w += S, d -= 8
    );
    for (
      c = f & ((1 << -d) - 1), f >>= -d, d += o;
      d > 0;
      c = c * 256 + e[t + w], w += S, d -= 8
    );
    if (f === 0) f = 1 - l;
    else {
      if (f === r) return c ? NaN : (x ? -1 : 1) * (1 / 0);
      (c = c + Math.pow(2, o)), (f = f - l);
    }
    return (x ? -1 : 1) * c * Math.pow(2, f - o);
  };
ai.write = function (e, t, n, o, a, f) {
  var c,
    s,
    r,
    l = f * 8 - a - 1,
    d = (1 << l) - 1,
    w = d >> 1,
    S = a === 23 ? Math.pow(2, -24) - Math.pow(2, -77) : 0,
    x = o ? 0 : f - 1,
    E = o ? 1 : -1,
    I = t < 0 || (t === 0 && 1 / t < 0) ? 1 : 0;
  for (
    t = Math.abs(t),
      isNaN(t) || t === 1 / 0
        ? ((s = isNaN(t) ? 1 : 0), (c = d))
        : ((c = Math.floor(Math.log(t) / Math.LN2)),
          t * (r = Math.pow(2, -c)) < 1 && (c--, (r *= 2)),
          c + w >= 1 ? (t += S / r) : (t += S * Math.pow(2, 1 - w)),
          t * r >= 2 && (c++, (r /= 2)),
          c + w >= d
            ? ((s = 0), (c = d))
            : c + w >= 1
            ? ((s = (t * r - 1) * Math.pow(2, a)), (c = c + w))
            : ((s = t * Math.pow(2, w - 1) * Math.pow(2, a)), (c = 0)));
    a >= 8;
    e[n + x] = s & 255, x += E, s /= 256, a -= 8
  );
  for (
    c = (c << a) | s, l += a;
    l > 0;
    e[n + x] = c & 255, x += E, c /= 256, l -= 8
  );
  e[n + x - E] |= I * 128;
};
/*!
 * The buffer module from node.js, for the browser.
 *
 * @author   Feross Aboukhadijeh <https://feross.org>
 * @license  MIT
 */ (function (e) {
  const t = cr,
    n = ai,
    o =
      typeof Symbol == "function" && typeof Symbol.for == "function"
        ? Symbol.for("nodejs.util.inspect.custom")
        : null;
  (e.Buffer = s), (e.SlowBuffer = g), (e.INSPECT_MAX_BYTES = 50);
  const a = 2147483647;
  (e.kMaxLength = a),
    (s.TYPED_ARRAY_SUPPORT = f()),
    !s.TYPED_ARRAY_SUPPORT &&
      typeof console < "u" &&
      typeof console.error == "function" &&
      console.error(
        "This browser lacks typed array (Uint8Array) support which is required by `buffer` v5.x. Use `buffer` v4.x if you require old browser support."
      );
  function f() {
    try {
      const p = new Uint8Array(1),
        i = {
          foo: function () {
            return 42;
          },
        };
      return (
        Object.setPrototypeOf(i, Uint8Array.prototype),
        Object.setPrototypeOf(p, i),
        p.foo() === 42
      );
    } catch {
      return !1;
    }
  }
  Object.defineProperty(s.prototype, "parent", {
    enumerable: !0,
    get: function () {
      if (s.isBuffer(this)) return this.buffer;
    },
  }),
    Object.defineProperty(s.prototype, "offset", {
      enumerable: !0,
      get: function () {
        if (s.isBuffer(this)) return this.byteOffset;
      },
    });
  function c(p) {
    if (p > a)
      throw new RangeError(
        'The value "' + p + '" is invalid for option "size"'
      );
    const i = new Uint8Array(p);
    return Object.setPrototypeOf(i, s.prototype), i;
  }
  function s(p, i, u) {
    if (typeof p == "number") {
      if (typeof i == "string")
        throw new TypeError(
          'The "string" argument must be of type string. Received type number'
        );
      return w(p);
    }
    return r(p, i, u);
  }
  s.poolSize = 8192;
  function r(p, i, u) {
    if (typeof p == "string") return S(p, i);
    if (ArrayBuffer.isView(p)) return E(p);
    if (p == null)
      throw new TypeError(
        "The first argument must be one of type string, Buffer, ArrayBuffer, Array, or Array-like Object. Received type " +
          typeof p
      );
    if (
      Y(p, ArrayBuffer) ||
      (p && Y(p.buffer, ArrayBuffer)) ||
      (typeof SharedArrayBuffer < "u" &&
        (Y(p, SharedArrayBuffer) || (p && Y(p.buffer, SharedArrayBuffer))))
    )
      return I(p, i, u);
    if (typeof p == "number")
      throw new TypeError(
        'The "value" argument must not be of type number. Received type number'
      );
    const h = p.valueOf && p.valueOf();
    if (h != null && h !== p) return s.from(h, i, u);
    const y = k(p);
    if (y) return y;
    if (
      typeof Symbol < "u" &&
      Symbol.toPrimitive != null &&
      typeof p[Symbol.toPrimitive] == "function"
    )
      return s.from(p[Symbol.toPrimitive]("string"), i, u);
    throw new TypeError(
      "The first argument must be one of type string, Buffer, ArrayBuffer, Array, or Array-like Object. Received type " +
        typeof p
    );
  }
  (s.from = function (p, i, u) {
    return r(p, i, u);
  }),
    Object.setPrototypeOf(s.prototype, Uint8Array.prototype),
    Object.setPrototypeOf(s, Uint8Array);
  function l(p) {
    if (typeof p != "number")
      throw new TypeError('"size" argument must be of type number');
    if (p < 0)
      throw new RangeError(
        'The value "' + p + '" is invalid for option "size"'
      );
  }
  function d(p, i, u) {
    return (
      l(p),
      p <= 0
        ? c(p)
        : i !== void 0
        ? typeof u == "string"
          ? c(p).fill(i, u)
          : c(p).fill(i)
        : c(p)
    );
  }
  s.alloc = function (p, i, u) {
    return d(p, i, u);
  };
  function w(p) {
    return l(p), c(p < 0 ? 0 : b(p) | 0);
  }
  (s.allocUnsafe = function (p) {
    return w(p);
  }),
    (s.allocUnsafeSlow = function (p) {
      return w(p);
    });
  function S(p, i) {
    if (((typeof i != "string" || i === "") && (i = "utf8"), !s.isEncoding(i)))
      throw new TypeError("Unknown encoding: " + i);
    const u = _(p, i) | 0;
    let h = c(u);
    const y = h.write(p, i);
    return y !== u && (h = h.slice(0, y)), h;
  }
  function x(p) {
    const i = p.length < 0 ? 0 : b(p.length) | 0,
      u = c(i);
    for (let h = 0; h < i; h += 1) u[h] = p[h] & 255;
    return u;
  }
  function E(p) {
    if (Y(p, Uint8Array)) {
      const i = new Uint8Array(p);
      return I(i.buffer, i.byteOffset, i.byteLength);
    }
    return x(p);
  }
  function I(p, i, u) {
    if (i < 0 || p.byteLength < i)
      throw new RangeError('"offset" is outside of buffer bounds');
    if (p.byteLength < i + (u || 0))
      throw new RangeError('"length" is outside of buffer bounds');
    let h;
    return (
      i === void 0 && u === void 0
        ? (h = new Uint8Array(p))
        : u === void 0
        ? (h = new Uint8Array(p, i))
        : (h = new Uint8Array(p, i, u)),
      Object.setPrototypeOf(h, s.prototype),
      h
    );
  }
  function k(p) {
    if (s.isBuffer(p)) {
      const i = b(p.length) | 0,
        u = c(i);
      return u.length === 0 || p.copy(u, 0, 0, i), u;
    }
    if (p.length !== void 0)
      return typeof p.length != "number" || ve(p.length) ? c(0) : x(p);
    if (p.type === "Buffer" && Array.isArray(p.data)) return x(p.data);
  }
  function b(p) {
    if (p >= a)
      throw new RangeError(
        "Attempt to allocate Buffer larger than maximum size: 0x" +
          a.toString(16) +
          " bytes"
      );
    return p | 0;
  }
  function g(p) {
    return +p != p && (p = 0), s.alloc(+p);
  }
  (s.isBuffer = function (i) {
    return i != null && i._isBuffer === !0 && i !== s.prototype;
  }),
    (s.compare = function (i, u) {
      if (
        (Y(i, Uint8Array) && (i = s.from(i, i.offset, i.byteLength)),
        Y(u, Uint8Array) && (u = s.from(u, u.offset, u.byteLength)),
        !s.isBuffer(i) || !s.isBuffer(u))
      )
        throw new TypeError(
          'The "buf1", "buf2" arguments must be one of type Buffer or Uint8Array'
        );
      if (i === u) return 0;
      let h = i.length,
        y = u.length;
      for (let C = 0, B = Math.min(h, y); C < B; ++C)
        if (i[C] !== u[C]) {
          (h = i[C]), (y = u[C]);
          break;
        }
      return h < y ? -1 : y < h ? 1 : 0;
    }),
    (s.isEncoding = function (i) {
      switch (String(i).toLowerCase()) {
        case "hex":
        case "utf8":
        case "utf-8":
        case "ascii":
        case "latin1":
        case "binary":
        case "base64":
        case "ucs2":
        case "ucs-2":
        case "utf16le":
        case "utf-16le":
          return !0;
        default:
          return !1;
      }
    }),
    (s.concat = function (i, u) {
      if (!Array.isArray(i))
        throw new TypeError('"list" argument must be an Array of Buffers');
      if (i.length === 0) return s.alloc(0);
      let h;
      if (u === void 0) for (u = 0, h = 0; h < i.length; ++h) u += i[h].length;
      const y = s.allocUnsafe(u);
      let C = 0;
      for (h = 0; h < i.length; ++h) {
        let B = i[h];
        if (Y(B, Uint8Array))
          C + B.length > y.length
            ? (s.isBuffer(B) || (B = s.from(B)), B.copy(y, C))
            : Uint8Array.prototype.set.call(y, B, C);
        else if (s.isBuffer(B)) B.copy(y, C);
        else throw new TypeError('"list" argument must be an Array of Buffers');
        C += B.length;
      }
      return y;
    });
  function _(p, i) {
    if (s.isBuffer(p)) return p.length;
    if (ArrayBuffer.isView(p) || Y(p, ArrayBuffer)) return p.byteLength;
    if (typeof p != "string")
      throw new TypeError(
        'The "string" argument must be one of type string, Buffer, or ArrayBuffer. Received type ' +
          typeof p
      );
    const u = p.length,
      h = arguments.length > 2 && arguments[2] === !0;
    if (!h && u === 0) return 0;
    let y = !1;
    for (;;)
      switch (i) {
        case "ascii":
        case "latin1":
        case "binary":
          return u;
        case "utf8":
        case "utf-8":
          return G(p).length;
        case "ucs2":
        case "ucs-2":
        case "utf16le":
        case "utf-16le":
          return u * 2;
        case "hex":
          return u >>> 1;
        case "base64":
          return oe(p).length;
        default:
          if (y) return h ? -1 : G(p).length;
          (i = ("" + i).toLowerCase()), (y = !0);
      }
  }
  s.byteLength = _;
  function m(p, i, u) {
    let h = !1;
    if (
      ((i === void 0 || i < 0) && (i = 0),
      i > this.length ||
        ((u === void 0 || u > this.length) && (u = this.length), u <= 0) ||
        ((u >>>= 0), (i >>>= 0), u <= i))
    )
      return "";
    for (p || (p = "utf8"); ; )
      switch (p) {
        case "hex":
          return se(this, i, u);
        case "utf8":
        case "utf-8":
          return ne(this, i, u);
        case "ascii":
          return $(this, i, u);
        case "latin1":
        case "binary":
          return D(this, i, u);
        case "base64":
          return ie(this, i, u);
        case "ucs2":
        case "ucs-2":
        case "utf16le":
        case "utf-16le":
          return xe(this, i, u);
        default:
          if (h) throw new TypeError("Unknown encoding: " + p);
          (p = (p + "").toLowerCase()), (h = !0);
      }
  }
  s.prototype._isBuffer = !0;
  function v(p, i, u) {
    const h = p[i];
    (p[i] = p[u]), (p[u] = h);
  }
  (s.prototype.swap16 = function () {
    const i = this.length;
    if (i % 2 !== 0)
      throw new RangeError("Buffer size must be a multiple of 16-bits");
    for (let u = 0; u < i; u += 2) v(this, u, u + 1);
    return this;
  }),
    (s.prototype.swap32 = function () {
      const i = this.length;
      if (i % 4 !== 0)
        throw new RangeError("Buffer size must be a multiple of 32-bits");
      for (let u = 0; u < i; u += 4) v(this, u, u + 3), v(this, u + 1, u + 2);
      return this;
    }),
    (s.prototype.swap64 = function () {
      const i = this.length;
      if (i % 8 !== 0)
        throw new RangeError("Buffer size must be a multiple of 64-bits");
      for (let u = 0; u < i; u += 8)
        v(this, u, u + 7),
          v(this, u + 1, u + 6),
          v(this, u + 2, u + 5),
          v(this, u + 3, u + 4);
      return this;
    }),
    (s.prototype.toString = function () {
      const i = this.length;
      return i === 0
        ? ""
        : arguments.length === 0
        ? ne(this, 0, i)
        : m.apply(this, arguments);
    }),
    (s.prototype.toLocaleString = s.prototype.toString),
    (s.prototype.equals = function (i) {
      if (!s.isBuffer(i)) throw new TypeError("Argument must be a Buffer");
      return this === i ? !0 : s.compare(this, i) === 0;
    }),
    (s.prototype.inspect = function () {
      let i = "";
      const u = e.INSPECT_MAX_BYTES;
      return (
        (i = this.toString("hex", 0, u)
          .replace(/(.{2})/g, "$1 ")
          .trim()),
        this.length > u && (i += " ... "),
        "<Buffer " + i + ">"
      );
    }),
    o && (s.prototype[o] = s.prototype.inspect),
    (s.prototype.compare = function (i, u, h, y, C) {
      if (
        (Y(i, Uint8Array) && (i = s.from(i, i.offset, i.byteLength)),
        !s.isBuffer(i))
      )
        throw new TypeError(
          'The "target" argument must be one of type Buffer or Uint8Array. Received type ' +
            typeof i
        );
      if (
        (u === void 0 && (u = 0),
        h === void 0 && (h = i ? i.length : 0),
        y === void 0 && (y = 0),
        C === void 0 && (C = this.length),
        u < 0 || h > i.length || y < 0 || C > this.length)
      )
        throw new RangeError("out of range index");
      if (y >= C && u >= h) return 0;
      if (y >= C) return -1;
      if (u >= h) return 1;
      if (((u >>>= 0), (h >>>= 0), (y >>>= 0), (C >>>= 0), this === i))
        return 0;
      let B = C - y,
        ee = h - u;
      const V = Math.min(B, ee),
        H = this.slice(y, C),
        ue = i.slice(u, h);
      for (let be = 0; be < V; ++be)
        if (H[be] !== ue[be]) {
          (B = H[be]), (ee = ue[be]);
          break;
        }
      return B < ee ? -1 : ee < B ? 1 : 0;
    });
  function A(p, i, u, h, y) {
    if (p.length === 0) return -1;
    if (
      (typeof u == "string"
        ? ((h = u), (u = 0))
        : u > 2147483647
        ? (u = 2147483647)
        : u < -2147483648 && (u = -2147483648),
      (u = +u),
      ve(u) && (u = y ? 0 : p.length - 1),
      u < 0 && (u = p.length + u),
      u >= p.length)
    ) {
      if (y) return -1;
      u = p.length - 1;
    } else if (u < 0)
      if (y) u = 0;
      else return -1;
    if ((typeof i == "string" && (i = s.from(i, h)), s.isBuffer(i)))
      return i.length === 0 ? -1 : T(p, i, u, h, y);
    if (typeof i == "number")
      return (
        (i = i & 255),
        typeof Uint8Array.prototype.indexOf == "function"
          ? y
            ? Uint8Array.prototype.indexOf.call(p, i, u)
            : Uint8Array.prototype.lastIndexOf.call(p, i, u)
          : T(p, [i], u, h, y)
      );
    throw new TypeError("val must be string, number or Buffer");
  }
  function T(p, i, u, h, y) {
    let C = 1,
      B = p.length,
      ee = i.length;
    if (
      h !== void 0 &&
      ((h = String(h).toLowerCase()),
      h === "ucs2" || h === "ucs-2" || h === "utf16le" || h === "utf-16le")
    ) {
      if (p.length < 2 || i.length < 2) return -1;
      (C = 2), (B /= 2), (ee /= 2), (u /= 2);
    }
    function V(ue, be) {
      return C === 1 ? ue[be] : ue.readUInt16BE(be * C);
    }
    let H;
    if (y) {
      let ue = -1;
      for (H = u; H < B; H++)
        if (V(p, H) === V(i, ue === -1 ? 0 : H - ue)) {
          if ((ue === -1 && (ue = H), H - ue + 1 === ee)) return ue * C;
        } else ue !== -1 && (H -= H - ue), (ue = -1);
    } else
      for (u + ee > B && (u = B - ee), H = u; H >= 0; H--) {
        let ue = !0;
        for (let be = 0; be < ee; be++)
          if (V(p, H + be) !== V(i, be)) {
            ue = !1;
            break;
          }
        if (ue) return H;
      }
    return -1;
  }
  (s.prototype.includes = function (i, u, h) {
    return this.indexOf(i, u, h) !== -1;
  }),
    (s.prototype.indexOf = function (i, u, h) {
      return A(this, i, u, h, !0);
    }),
    (s.prototype.lastIndexOf = function (i, u, h) {
      return A(this, i, u, h, !1);
    });
  function j(p, i, u, h) {
    u = Number(u) || 0;
    const y = p.length - u;
    h ? ((h = Number(h)), h > y && (h = y)) : (h = y);
    const C = i.length;
    h > C / 2 && (h = C / 2);
    let B;
    for (B = 0; B < h; ++B) {
      const ee = parseInt(i.substr(B * 2, 2), 16);
      if (ve(ee)) return B;
      p[u + B] = ee;
    }
    return B;
  }
  function L(p, i, u, h) {
    return re(G(i, p.length - u), p, u, h);
  }
  function M(p, i, u, h) {
    return re(Q(i), p, u, h);
  }
  function q(p, i, u, h) {
    return re(oe(i), p, u, h);
  }
  function W(p, i, u, h) {
    return re(ce(i, p.length - u), p, u, h);
  }
  (s.prototype.write = function (i, u, h, y) {
    if (u === void 0) (y = "utf8"), (h = this.length), (u = 0);
    else if (h === void 0 && typeof u == "string")
      (y = u), (h = this.length), (u = 0);
    else if (isFinite(u))
      (u = u >>> 0),
        isFinite(h)
          ? ((h = h >>> 0), y === void 0 && (y = "utf8"))
          : ((y = h), (h = void 0));
    else
      throw new Error(
        "Buffer.write(string, encoding, offset[, length]) is no longer supported"
      );
    const C = this.length - u;
    if (
      ((h === void 0 || h > C) && (h = C),
      (i.length > 0 && (h < 0 || u < 0)) || u > this.length)
    )
      throw new RangeError("Attempt to write outside buffer bounds");
    y || (y = "utf8");
    let B = !1;
    for (;;)
      switch (y) {
        case "hex":
          return j(this, i, u, h);
        case "utf8":
        case "utf-8":
          return L(this, i, u, h);
        case "ascii":
        case "latin1":
        case "binary":
          return M(this, i, u, h);
        case "base64":
          return q(this, i, u, h);
        case "ucs2":
        case "ucs-2":
        case "utf16le":
        case "utf-16le":
          return W(this, i, u, h);
        default:
          if (B) throw new TypeError("Unknown encoding: " + y);
          (y = ("" + y).toLowerCase()), (B = !0);
      }
  }),
    (s.prototype.toJSON = function () {
      return {
        type: "Buffer",
        data: Array.prototype.slice.call(this._arr || this, 0),
      };
    });
  function ie(p, i, u) {
    return i === 0 && u === p.length
      ? t.fromByteArray(p)
      : t.fromByteArray(p.slice(i, u));
  }
  function ne(p, i, u) {
    u = Math.min(p.length, u);
    const h = [];
    let y = i;
    for (; y < u; ) {
      const C = p[y];
      let B = null,
        ee = C > 239 ? 4 : C > 223 ? 3 : C > 191 ? 2 : 1;
      if (y + ee <= u) {
        let V, H, ue, be;
        switch (ee) {
          case 1:
            C < 128 && (B = C);
            break;
          case 2:
            (V = p[y + 1]),
              (V & 192) === 128 &&
                ((be = ((C & 31) << 6) | (V & 63)), be > 127 && (B = be));
            break;
          case 3:
            (V = p[y + 1]),
              (H = p[y + 2]),
              (V & 192) === 128 &&
                (H & 192) === 128 &&
                ((be = ((C & 15) << 12) | ((V & 63) << 6) | (H & 63)),
                be > 2047 && (be < 55296 || be > 57343) && (B = be));
            break;
          case 4:
            (V = p[y + 1]),
              (H = p[y + 2]),
              (ue = p[y + 3]),
              (V & 192) === 128 &&
                (H & 192) === 128 &&
                (ue & 192) === 128 &&
                ((be =
                  ((C & 15) << 18) |
                  ((V & 63) << 12) |
                  ((H & 63) << 6) |
                  (ue & 63)),
                be > 65535 && be < 1114112 && (B = be));
        }
      }
      B === null
        ? ((B = 65533), (ee = 1))
        : B > 65535 &&
          ((B -= 65536),
          h.push(((B >>> 10) & 1023) | 55296),
          (B = 56320 | (B & 1023))),
        h.push(B),
        (y += ee);
    }
    return he(h);
  }
  const de = 4096;
  function he(p) {
    const i = p.length;
    if (i <= de) return String.fromCharCode.apply(String, p);
    let u = "",
      h = 0;
    for (; h < i; )
      u += String.fromCharCode.apply(String, p.slice(h, (h += de)));
    return u;
  }
  function $(p, i, u) {
    let h = "";
    u = Math.min(p.length, u);
    for (let y = i; y < u; ++y) h += String.fromCharCode(p[y] & 127);
    return h;
  }
  function D(p, i, u) {
    let h = "";
    u = Math.min(p.length, u);
    for (let y = i; y < u; ++y) h += String.fromCharCode(p[y]);
    return h;
  }
  function se(p, i, u) {
    const h = p.length;
    (!i || i < 0) && (i = 0), (!u || u < 0 || u > h) && (u = h);
    let y = "";
    for (let C = i; C < u; ++C) y += le[p[C]];
    return y;
  }
  function xe(p, i, u) {
    const h = p.slice(i, u);
    let y = "";
    for (let C = 0; C < h.length - 1; C += 2)
      y += String.fromCharCode(h[C] + h[C + 1] * 256);
    return y;
  }
  s.prototype.slice = function (i, u) {
    const h = this.length;
    (i = ~~i),
      (u = u === void 0 ? h : ~~u),
      i < 0 ? ((i += h), i < 0 && (i = 0)) : i > h && (i = h),
      u < 0 ? ((u += h), u < 0 && (u = 0)) : u > h && (u = h),
      u < i && (u = i);
    const y = this.subarray(i, u);
    return Object.setPrototypeOf(y, s.prototype), y;
  };
  function me(p, i, u) {
    if (p % 1 !== 0 || p < 0) throw new RangeError("offset is not uint");
    if (p + i > u)
      throw new RangeError("Trying to access beyond buffer length");
  }
  (s.prototype.readUintLE = s.prototype.readUIntLE =
    function (i, u, h) {
      (i = i >>> 0), (u = u >>> 0), h || me(i, u, this.length);
      let y = this[i],
        C = 1,
        B = 0;
      for (; ++B < u && (C *= 256); ) y += this[i + B] * C;
      return y;
    }),
    (s.prototype.readUintBE = s.prototype.readUIntBE =
      function (i, u, h) {
        (i = i >>> 0), (u = u >>> 0), h || me(i, u, this.length);
        let y = this[i + --u],
          C = 1;
        for (; u > 0 && (C *= 256); ) y += this[i + --u] * C;
        return y;
      }),
    (s.prototype.readUint8 = s.prototype.readUInt8 =
      function (i, u) {
        return (i = i >>> 0), u || me(i, 1, this.length), this[i];
      }),
    (s.prototype.readUint16LE = s.prototype.readUInt16LE =
      function (i, u) {
        return (
          (i = i >>> 0),
          u || me(i, 2, this.length),
          this[i] | (this[i + 1] << 8)
        );
      }),
    (s.prototype.readUint16BE = s.prototype.readUInt16BE =
      function (i, u) {
        return (
          (i = i >>> 0),
          u || me(i, 2, this.length),
          (this[i] << 8) | this[i + 1]
        );
      }),
    (s.prototype.readUint32LE = s.prototype.readUInt32LE =
      function (i, u) {
        return (
          (i = i >>> 0),
          u || me(i, 4, this.length),
          (this[i] | (this[i + 1] << 8) | (this[i + 2] << 16)) +
            this[i + 3] * 16777216
        );
      }),
    (s.prototype.readUint32BE = s.prototype.readUInt32BE =
      function (i, u) {
        return (
          (i = i >>> 0),
          u || me(i, 4, this.length),
          this[i] * 16777216 +
            ((this[i + 1] << 16) | (this[i + 2] << 8) | this[i + 3])
        );
      }),
    (s.prototype.readBigUInt64LE = ge(function (i) {
      (i = i >>> 0), P(i, "offset");
      const u = this[i],
        h = this[i + 7];
      (u === void 0 || h === void 0) && R(i, this.length - 8);
      const y =
          u + this[++i] * 2 ** 8 + this[++i] * 2 ** 16 + this[++i] * 2 ** 24,
        C = this[++i] + this[++i] * 2 ** 8 + this[++i] * 2 ** 16 + h * 2 ** 24;
      return BigInt(y) + (BigInt(C) << BigInt(32));
    })),
    (s.prototype.readBigUInt64BE = ge(function (i) {
      (i = i >>> 0), P(i, "offset");
      const u = this[i],
        h = this[i + 7];
      (u === void 0 || h === void 0) && R(i, this.length - 8);
      const y =
          u * 2 ** 24 + this[++i] * 2 ** 16 + this[++i] * 2 ** 8 + this[++i],
        C = this[++i] * 2 ** 24 + this[++i] * 2 ** 16 + this[++i] * 2 ** 8 + h;
      return (BigInt(y) << BigInt(32)) + BigInt(C);
    })),
    (s.prototype.readIntLE = function (i, u, h) {
      (i = i >>> 0), (u = u >>> 0), h || me(i, u, this.length);
      let y = this[i],
        C = 1,
        B = 0;
      for (; ++B < u && (C *= 256); ) y += this[i + B] * C;
      return (C *= 128), y >= C && (y -= Math.pow(2, 8 * u)), y;
    }),
    (s.prototype.readIntBE = function (i, u, h) {
      (i = i >>> 0), (u = u >>> 0), h || me(i, u, this.length);
      let y = u,
        C = 1,
        B = this[i + --y];
      for (; y > 0 && (C *= 256); ) B += this[i + --y] * C;
      return (C *= 128), B >= C && (B -= Math.pow(2, 8 * u)), B;
    }),
    (s.prototype.readInt8 = function (i, u) {
      return (
        (i = i >>> 0),
        u || me(i, 1, this.length),
        this[i] & 128 ? (255 - this[i] + 1) * -1 : this[i]
      );
    }),
    (s.prototype.readInt16LE = function (i, u) {
      (i = i >>> 0), u || me(i, 2, this.length);
      const h = this[i] | (this[i + 1] << 8);
      return h & 32768 ? h | 4294901760 : h;
    }),
    (s.prototype.readInt16BE = function (i, u) {
      (i = i >>> 0), u || me(i, 2, this.length);
      const h = this[i + 1] | (this[i] << 8);
      return h & 32768 ? h | 4294901760 : h;
    }),
    (s.prototype.readInt32LE = function (i, u) {
      return (
        (i = i >>> 0),
        u || me(i, 4, this.length),
        this[i] | (this[i + 1] << 8) | (this[i + 2] << 16) | (this[i + 3] << 24)
      );
    }),
    (s.prototype.readInt32BE = function (i, u) {
      return (
        (i = i >>> 0),
        u || me(i, 4, this.length),
        (this[i] << 24) | (this[i + 1] << 16) | (this[i + 2] << 8) | this[i + 3]
      );
    }),
    (s.prototype.readBigInt64LE = ge(function (i) {
      (i = i >>> 0), P(i, "offset");
      const u = this[i],
        h = this[i + 7];
      (u === void 0 || h === void 0) && R(i, this.length - 8);
      const y =
        this[i + 4] + this[i + 5] * 2 ** 8 + this[i + 6] * 2 ** 16 + (h << 24);
      return (
        (BigInt(y) << BigInt(32)) +
        BigInt(
          u + this[++i] * 2 ** 8 + this[++i] * 2 ** 16 + this[++i] * 2 ** 24
        )
      );
    })),
    (s.prototype.readBigInt64BE = ge(function (i) {
      (i = i >>> 0), P(i, "offset");
      const u = this[i],
        h = this[i + 7];
      (u === void 0 || h === void 0) && R(i, this.length - 8);
      const y =
        (u << 24) + this[++i] * 2 ** 16 + this[++i] * 2 ** 8 + this[++i];
      return (
        (BigInt(y) << BigInt(32)) +
        BigInt(
          this[++i] * 2 ** 24 + this[++i] * 2 ** 16 + this[++i] * 2 ** 8 + h
        )
      );
    })),
    (s.prototype.readFloatLE = function (i, u) {
      return (
        (i = i >>> 0), u || me(i, 4, this.length), n.read(this, i, !0, 23, 4)
      );
    }),
    (s.prototype.readFloatBE = function (i, u) {
      return (
        (i = i >>> 0), u || me(i, 4, this.length), n.read(this, i, !1, 23, 4)
      );
    }),
    (s.prototype.readDoubleLE = function (i, u) {
      return (
        (i = i >>> 0), u || me(i, 8, this.length), n.read(this, i, !0, 52, 8)
      );
    }),
    (s.prototype.readDoubleBE = function (i, u) {
      return (
        (i = i >>> 0), u || me(i, 8, this.length), n.read(this, i, !1, 52, 8)
      );
    });
  function pe(p, i, u, h, y, C) {
    if (!s.isBuffer(p))
      throw new TypeError('"buffer" argument must be a Buffer instance');
    if (i > y || i < C)
      throw new RangeError('"value" argument is out of bounds');
    if (u + h > p.length) throw new RangeError("Index out of range");
  }
  (s.prototype.writeUintLE = s.prototype.writeUIntLE =
    function (i, u, h, y) {
      if (((i = +i), (u = u >>> 0), (h = h >>> 0), !y)) {
        const ee = Math.pow(2, 8 * h) - 1;
        pe(this, i, u, h, ee, 0);
      }
      let C = 1,
        B = 0;
      for (this[u] = i & 255; ++B < h && (C *= 256); )
        this[u + B] = (i / C) & 255;
      return u + h;
    }),
    (s.prototype.writeUintBE = s.prototype.writeUIntBE =
      function (i, u, h, y) {
        if (((i = +i), (u = u >>> 0), (h = h >>> 0), !y)) {
          const ee = Math.pow(2, 8 * h) - 1;
          pe(this, i, u, h, ee, 0);
        }
        let C = h - 1,
          B = 1;
        for (this[u + C] = i & 255; --C >= 0 && (B *= 256); )
          this[u + C] = (i / B) & 255;
        return u + h;
      }),
    (s.prototype.writeUint8 = s.prototype.writeUInt8 =
      function (i, u, h) {
        return (
          (i = +i),
          (u = u >>> 0),
          h || pe(this, i, u, 1, 255, 0),
          (this[u] = i & 255),
          u + 1
        );
      }),
    (s.prototype.writeUint16LE = s.prototype.writeUInt16LE =
      function (i, u, h) {
        return (
          (i = +i),
          (u = u >>> 0),
          h || pe(this, i, u, 2, 65535, 0),
          (this[u] = i & 255),
          (this[u + 1] = i >>> 8),
          u + 2
        );
      }),
    (s.prototype.writeUint16BE = s.prototype.writeUInt16BE =
      function (i, u, h) {
        return (
          (i = +i),
          (u = u >>> 0),
          h || pe(this, i, u, 2, 65535, 0),
          (this[u] = i >>> 8),
          (this[u + 1] = i & 255),
          u + 2
        );
      }),
    (s.prototype.writeUint32LE = s.prototype.writeUInt32LE =
      function (i, u, h) {
        return (
          (i = +i),
          (u = u >>> 0),
          h || pe(this, i, u, 4, 4294967295, 0),
          (this[u + 3] = i >>> 24),
          (this[u + 2] = i >>> 16),
          (this[u + 1] = i >>> 8),
          (this[u] = i & 255),
          u + 4
        );
      }),
    (s.prototype.writeUint32BE = s.prototype.writeUInt32BE =
      function (i, u, h) {
        return (
          (i = +i),
          (u = u >>> 0),
          h || pe(this, i, u, 4, 4294967295, 0),
          (this[u] = i >>> 24),
          (this[u + 1] = i >>> 16),
          (this[u + 2] = i >>> 8),
          (this[u + 3] = i & 255),
          u + 4
        );
      });
  function _e(p, i, u, h, y) {
    Ce(i, h, y, p, u, 7);
    let C = Number(i & BigInt(4294967295));
    (p[u++] = C),
      (C = C >> 8),
      (p[u++] = C),
      (C = C >> 8),
      (p[u++] = C),
      (C = C >> 8),
      (p[u++] = C);
    let B = Number((i >> BigInt(32)) & BigInt(4294967295));
    return (
      (p[u++] = B),
      (B = B >> 8),
      (p[u++] = B),
      (B = B >> 8),
      (p[u++] = B),
      (B = B >> 8),
      (p[u++] = B),
      u
    );
  }
  function Te(p, i, u, h, y) {
    Ce(i, h, y, p, u, 7);
    let C = Number(i & BigInt(4294967295));
    (p[u + 7] = C),
      (C = C >> 8),
      (p[u + 6] = C),
      (C = C >> 8),
      (p[u + 5] = C),
      (C = C >> 8),
      (p[u + 4] = C);
    let B = Number((i >> BigInt(32)) & BigInt(4294967295));
    return (
      (p[u + 3] = B),
      (B = B >> 8),
      (p[u + 2] = B),
      (B = B >> 8),
      (p[u + 1] = B),
      (B = B >> 8),
      (p[u] = B),
      u + 8
    );
  }
  (s.prototype.writeBigUInt64LE = ge(function (i, u = 0) {
    return _e(this, i, u, BigInt(0), BigInt("0xffffffffffffffff"));
  })),
    (s.prototype.writeBigUInt64BE = ge(function (i, u = 0) {
      return Te(this, i, u, BigInt(0), BigInt("0xffffffffffffffff"));
    })),
    (s.prototype.writeIntLE = function (i, u, h, y) {
      if (((i = +i), (u = u >>> 0), !y)) {
        const V = Math.pow(2, 8 * h - 1);
        pe(this, i, u, h, V - 1, -V);
      }
      let C = 0,
        B = 1,
        ee = 0;
      for (this[u] = i & 255; ++C < h && (B *= 256); )
        i < 0 && ee === 0 && this[u + C - 1] !== 0 && (ee = 1),
          (this[u + C] = (((i / B) >> 0) - ee) & 255);
      return u + h;
    }),
    (s.prototype.writeIntBE = function (i, u, h, y) {
      if (((i = +i), (u = u >>> 0), !y)) {
        const V = Math.pow(2, 8 * h - 1);
        pe(this, i, u, h, V - 1, -V);
      }
      let C = h - 1,
        B = 1,
        ee = 0;
      for (this[u + C] = i & 255; --C >= 0 && (B *= 256); )
        i < 0 && ee === 0 && this[u + C + 1] !== 0 && (ee = 1),
          (this[u + C] = (((i / B) >> 0) - ee) & 255);
      return u + h;
    }),
    (s.prototype.writeInt8 = function (i, u, h) {
      return (
        (i = +i),
        (u = u >>> 0),
        h || pe(this, i, u, 1, 127, -128),
        i < 0 && (i = 255 + i + 1),
        (this[u] = i & 255),
        u + 1
      );
    }),
    (s.prototype.writeInt16LE = function (i, u, h) {
      return (
        (i = +i),
        (u = u >>> 0),
        h || pe(this, i, u, 2, 32767, -32768),
        (this[u] = i & 255),
        (this[u + 1] = i >>> 8),
        u + 2
      );
    }),
    (s.prototype.writeInt16BE = function (i, u, h) {
      return (
        (i = +i),
        (u = u >>> 0),
        h || pe(this, i, u, 2, 32767, -32768),
        (this[u] = i >>> 8),
        (this[u + 1] = i & 255),
        u + 2
      );
    }),
    (s.prototype.writeInt32LE = function (i, u, h) {
      return (
        (i = +i),
        (u = u >>> 0),
        h || pe(this, i, u, 4, 2147483647, -2147483648),
        (this[u] = i & 255),
        (this[u + 1] = i >>> 8),
        (this[u + 2] = i >>> 16),
        (this[u + 3] = i >>> 24),
        u + 4
      );
    }),
    (s.prototype.writeInt32BE = function (i, u, h) {
      return (
        (i = +i),
        (u = u >>> 0),
        h || pe(this, i, u, 4, 2147483647, -2147483648),
        i < 0 && (i = 4294967295 + i + 1),
        (this[u] = i >>> 24),
        (this[u + 1] = i >>> 16),
        (this[u + 2] = i >>> 8),
        (this[u + 3] = i & 255),
        u + 4
      );
    }),
    (s.prototype.writeBigInt64LE = ge(function (i, u = 0) {
      return _e(
        this,
        i,
        u,
        -BigInt("0x8000000000000000"),
        BigInt("0x7fffffffffffffff")
      );
    })),
    (s.prototype.writeBigInt64BE = ge(function (i, u = 0) {
      return Te(
        this,
        i,
        u,
        -BigInt("0x8000000000000000"),
        BigInt("0x7fffffffffffffff")
      );
    }));
  function z(p, i, u, h, y, C) {
    if (u + h > p.length) throw new RangeError("Index out of range");
    if (u < 0) throw new RangeError("Index out of range");
  }
  function O(p, i, u, h, y) {
    return (
      (i = +i),
      (u = u >>> 0),
      y || z(p, i, u, 4),
      n.write(p, i, u, h, 23, 4),
      u + 4
    );
  }
  (s.prototype.writeFloatLE = function (i, u, h) {
    return O(this, i, u, !0, h);
  }),
    (s.prototype.writeFloatBE = function (i, u, h) {
      return O(this, i, u, !1, h);
    });
  function U(p, i, u, h, y) {
    return (
      (i = +i),
      (u = u >>> 0),
      y || z(p, i, u, 8),
      n.write(p, i, u, h, 52, 8),
      u + 8
    );
  }
  (s.prototype.writeDoubleLE = function (i, u, h) {
    return U(this, i, u, !0, h);
  }),
    (s.prototype.writeDoubleBE = function (i, u, h) {
      return U(this, i, u, !1, h);
    }),
    (s.prototype.copy = function (i, u, h, y) {
      if (!s.isBuffer(i)) throw new TypeError("argument should be a Buffer");
      if (
        (h || (h = 0),
        !y && y !== 0 && (y = this.length),
        u >= i.length && (u = i.length),
        u || (u = 0),
        y > 0 && y < h && (y = h),
        y === h || i.length === 0 || this.length === 0)
      )
        return 0;
      if (u < 0) throw new RangeError("targetStart out of bounds");
      if (h < 0 || h >= this.length) throw new RangeError("Index out of range");
      if (y < 0) throw new RangeError("sourceEnd out of bounds");
      y > this.length && (y = this.length),
        i.length - u < y - h && (y = i.length - u + h);
      const C = y - h;
      return (
        this === i && typeof Uint8Array.prototype.copyWithin == "function"
          ? this.copyWithin(u, h, y)
          : Uint8Array.prototype.set.call(i, this.subarray(h, y), u),
        C
      );
    }),
    (s.prototype.fill = function (i, u, h, y) {
      if (typeof i == "string") {
        if (
          (typeof u == "string"
            ? ((y = u), (u = 0), (h = this.length))
            : typeof h == "string" && ((y = h), (h = this.length)),
          y !== void 0 && typeof y != "string")
        )
          throw new TypeError("encoding must be a string");
        if (typeof y == "string" && !s.isEncoding(y))
          throw new TypeError("Unknown encoding: " + y);
        if (i.length === 1) {
          const B = i.charCodeAt(0);
          ((y === "utf8" && B < 128) || y === "latin1") && (i = B);
        }
      } else
        typeof i == "number"
          ? (i = i & 255)
          : typeof i == "boolean" && (i = Number(i));
      if (u < 0 || this.length < u || this.length < h)
        throw new RangeError("Out of range index");
      if (h <= u) return this;
      (u = u >>> 0), (h = h === void 0 ? this.length : h >>> 0), i || (i = 0);
      let C;
      if (typeof i == "number") for (C = u; C < h; ++C) this[C] = i;
      else {
        const B = s.isBuffer(i) ? i : s.from(i, y),
          ee = B.length;
        if (ee === 0)
          throw new TypeError(
            'The value "' + i + '" is invalid for argument "value"'
          );
        for (C = 0; C < h - u; ++C) this[C + u] = B[C % ee];
      }
      return this;
    });
  const K = {};
  function fe(p, i, u) {
    K[p] = class extends u {
      constructor() {
        super(),
          Object.defineProperty(this, "message", {
            value: i.apply(this, arguments),
            writable: !0,
            configurable: !0,
          }),
          (this.name = `${this.name} [${p}]`),
          this.stack,
          delete this.name;
      }
      get code() {
        return p;
      }
      set code(y) {
        Object.defineProperty(this, "code", {
          configurable: !0,
          enumerable: !0,
          value: y,
          writable: !0,
        });
      }
      toString() {
        return `${this.name} [${p}]: ${this.message}`;
      }
    };
  }
  fe(
    "ERR_BUFFER_OUT_OF_BOUNDS",
    function (p) {
      return p
        ? `${p} is outside of buffer bounds`
        : "Attempt to access memory outside buffer bounds";
    },
    RangeError
  ),
    fe(
      "ERR_INVALID_ARG_TYPE",
      function (p, i) {
        return `The "${p}" argument must be of type number. Received type ${typeof i}`;
      },
      TypeError
    ),
    fe(
      "ERR_OUT_OF_RANGE",
      function (p, i, u) {
        let h = `The value of "${p}" is out of range.`,
          y = u;
        return (
          Number.isInteger(u) && Math.abs(u) > 2 ** 32
            ? (y = Pe(String(u)))
            : typeof u == "bigint" &&
              ((y = String(u)),
              (u > BigInt(2) ** BigInt(32) || u < -(BigInt(2) ** BigInt(32))) &&
                (y = Pe(y)),
              (y += "n")),
          (h += ` It must be ${i}. Received ${y}`),
          h
        );
      },
      RangeError
    );
  function Pe(p) {
    let i = "",
      u = p.length;
    const h = p[0] === "-" ? 1 : 0;
    for (; u >= h + 4; u -= 3) i = `_${p.slice(u - 3, u)}${i}`;
    return `${p.slice(0, u)}${i}`;
  }
  function ke(p, i, u) {
    P(i, "offset"),
      (p[i] === void 0 || p[i + u] === void 0) && R(i, p.length - (u + 1));
  }
  function Ce(p, i, u, h, y, C) {
    if (p > u || p < i) {
      const B = typeof i == "bigint" ? "n" : "";
      let ee;
      throw (
        (i === 0 || i === BigInt(0)
          ? (ee = `>= 0${B} and < 2${B} ** ${(C + 1) * 8}${B}`)
          : (ee = `>= -(2${B} ** ${(C + 1) * 8 - 1}${B}) and < 2 ** ${
              (C + 1) * 8 - 1
            }${B}`),
        new K.ERR_OUT_OF_RANGE("value", ee, p))
      );
    }
    ke(h, y, C);
  }
  function P(p, i) {
    if (typeof p != "number") throw new K.ERR_INVALID_ARG_TYPE(i, "number", p);
  }
  function R(p, i, u) {
    throw Math.floor(p) !== p
      ? (P(p, u), new K.ERR_OUT_OF_RANGE("offset", "an integer", p))
      : i < 0
      ? new K.ERR_BUFFER_OUT_OF_BOUNDS()
      : new K.ERR_OUT_OF_RANGE("offset", `>= 0 and <= ${i}`, p);
  }
  const N = /[^+/0-9A-Za-z-_]/g;
  function X(p) {
    if (((p = p.split("=")[0]), (p = p.trim().replace(N, "")), p.length < 2))
      return "";
    for (; p.length % 4 !== 0; ) p = p + "=";
    return p;
  }
  function G(p, i) {
    i = i || 1 / 0;
    let u;
    const h = p.length;
    let y = null;
    const C = [];
    for (let B = 0; B < h; ++B) {
      if (((u = p.charCodeAt(B)), u > 55295 && u < 57344)) {
        if (!y) {
          if (u > 56319) {
            (i -= 3) > -1 && C.push(239, 191, 189);
            continue;
          } else if (B + 1 === h) {
            (i -= 3) > -1 && C.push(239, 191, 189);
            continue;
          }
          y = u;
          continue;
        }
        if (u < 56320) {
          (i -= 3) > -1 && C.push(239, 191, 189), (y = u);
          continue;
        }
        u = (((y - 55296) << 10) | (u - 56320)) + 65536;
      } else y && (i -= 3) > -1 && C.push(239, 191, 189);
      if (((y = null), u < 128)) {
        if ((i -= 1) < 0) break;
        C.push(u);
      } else if (u < 2048) {
        if ((i -= 2) < 0) break;
        C.push((u >> 6) | 192, (u & 63) | 128);
      } else if (u < 65536) {
        if ((i -= 3) < 0) break;
        C.push((u >> 12) | 224, ((u >> 6) & 63) | 128, (u & 63) | 128);
      } else if (u < 1114112) {
        if ((i -= 4) < 0) break;
        C.push(
          (u >> 18) | 240,
          ((u >> 12) & 63) | 128,
          ((u >> 6) & 63) | 128,
          (u & 63) | 128
        );
      } else throw new Error("Invalid code point");
    }
    return C;
  }
  function Q(p) {
    const i = [];
    for (let u = 0; u < p.length; ++u) i.push(p.charCodeAt(u) & 255);
    return i;
  }
  function ce(p, i) {
    let u, h, y;
    const C = [];
    for (let B = 0; B < p.length && !((i -= 2) < 0); ++B)
      (u = p.charCodeAt(B)), (h = u >> 8), (y = u % 256), C.push(y), C.push(h);
    return C;
  }
  function oe(p) {
    return t.toByteArray(X(p));
  }
  function re(p, i, u, h) {
    let y;
    for (y = 0; y < h && !(y + u >= i.length || y >= p.length); ++y)
      i[y + u] = p[y];
    return y;
  }
  function Y(p, i) {
    return (
      p instanceof i ||
      (p != null &&
        p.constructor != null &&
        p.constructor.name != null &&
        p.constructor.name === i.name)
    );
  }
  function ve(p) {
    return p !== p;
  }
  const le = (function () {
    const p = "0123456789abcdef",
      i = new Array(256);
    for (let u = 0; u < 16; ++u) {
      const h = u * 16;
      for (let y = 0; y < 16; ++y) i[h + y] = p[u] + p[y];
    }
    return i;
  })();
  function ge(p) {
    return typeof BigInt > "u" ? Z : p;
  }
  function Z() {
    throw new Error("BigInt not supported");
  }
})(os);
var Je =
    (typeof globalThis < "u" && globalThis) ||
    (typeof self < "u" && self) ||
    (typeof global < "u" && global) ||
    {},
  ot = {
    searchParams: "URLSearchParams" in Je,
    iterable: "Symbol" in Je && "iterator" in Symbol,
    blob:
      "FileReader" in Je &&
      "Blob" in Je &&
      (function () {
        try {
          return new Blob(), !0;
        } catch {
          return !1;
        }
      })(),
    formData: "FormData" in Je,
    arrayBuffer: "ArrayBuffer" in Je,
  };
function Qu(e) {
  return e && DataView.prototype.isPrototypeOf(e);
}
if (ot.arrayBuffer)
  var ec = [
      "[object Int8Array]",
      "[object Uint8Array]",
      "[object Uint8ClampedArray]",
      "[object Int16Array]",
      "[object Uint16Array]",
      "[object Int32Array]",
      "[object Uint32Array]",
      "[object Float32Array]",
      "[object Float64Array]",
    ],
    tc =
      ArrayBuffer.isView ||
      function (e) {
        return e && ec.indexOf(Object.prototype.toString.call(e)) > -1;
      };
function bn(e) {
  if (
    (typeof e != "string" && (e = String(e)),
    /[^a-z0-9\-#$%&'*+.^_`|~!]/i.test(e) || e === "")
  )
    throw new TypeError('Invalid character in header field name: "' + e + '"');
  return e.toLowerCase();
}
function ui(e) {
  return typeof e != "string" && (e = String(e)), e;
}
function ci(e) {
  var t = {
    next: function () {
      var n = e.shift();
      return { done: n === void 0, value: n };
    },
  };
  return (
    ot.iterable &&
      (t[Symbol.iterator] = function () {
        return t;
      }),
    t
  );
}
function Ke(e) {
  (this.map = {}),
    e instanceof Ke
      ? e.forEach(function (t, n) {
          this.append(n, t);
        }, this)
      : Array.isArray(e)
      ? e.forEach(function (t) {
          if (t.length != 2)
            throw new TypeError(
              "Headers constructor: expected name/value pair to be length 2, found" +
                t.length
            );
          this.append(t[0], t[1]);
        }, this)
      : e &&
        Object.getOwnPropertyNames(e).forEach(function (t) {
          this.append(t, e[t]);
        }, this);
}
Ke.prototype.append = function (e, t) {
  (e = bn(e)), (t = ui(t));
  var n = this.map[e];
  this.map[e] = n ? n + ", " + t : t;
};
Ke.prototype.delete = function (e) {
  delete this.map[bn(e)];
};
Ke.prototype.get = function (e) {
  return (e = bn(e)), this.has(e) ? this.map[e] : null;
};
Ke.prototype.has = function (e) {
  return this.map.hasOwnProperty(bn(e));
};
Ke.prototype.set = function (e, t) {
  this.map[bn(e)] = ui(t);
};
Ke.prototype.forEach = function (e, t) {
  for (var n in this.map)
    this.map.hasOwnProperty(n) && e.call(t, this.map[n], n, this);
};
Ke.prototype.keys = function () {
  var e = [];
  return (
    this.forEach(function (t, n) {
      e.push(n);
    }),
    ci(e)
  );
};
Ke.prototype.values = function () {
  var e = [];
  return (
    this.forEach(function (t) {
      e.push(t);
    }),
    ci(e)
  );
};
Ke.prototype.entries = function () {
  var e = [];
  return (
    this.forEach(function (t, n) {
      e.push([n, t]);
    }),
    ci(e)
  );
};
ot.iterable && (Ke.prototype[Symbol.iterator] = Ke.prototype.entries);
function Cr(e) {
  if (!e._noBody) {
    if (e.bodyUsed) return Promise.reject(new TypeError("Already read"));
    e.bodyUsed = !0;
  }
}
function as(e) {
  return new Promise(function (t, n) {
    (e.onload = function () {
      t(e.result);
    }),
      (e.onerror = function () {
        n(e.error);
      });
  });
}
function nc(e) {
  var t = new FileReader(),
    n = as(t);
  return t.readAsArrayBuffer(e), n;
}
function rc(e) {
  var t = new FileReader(),
    n = as(t),
    o = /charset=([A-Za-z0-9_-]+)/.exec(e.type),
    a = o ? o[1] : "utf-8";
  return t.readAsText(e, a), n;
}
function ic(e) {
  for (
    var t = new Uint8Array(e), n = new Array(t.length), o = 0;
    o < t.length;
    o++
  )
    n[o] = String.fromCharCode(t[o]);
  return n.join("");
}
function Vi(e) {
  if (e.slice) return e.slice(0);
  var t = new Uint8Array(e.byteLength);
  return t.set(new Uint8Array(e)), t.buffer;
}
function us() {
  return (
    (this.bodyUsed = !1),
    (this._initBody = function (e) {
      (this.bodyUsed = this.bodyUsed),
        (this._bodyInit = e),
        e
          ? typeof e == "string"
            ? (this._bodyText = e)
            : ot.blob && Blob.prototype.isPrototypeOf(e)
            ? (this._bodyBlob = e)
            : ot.formData && FormData.prototype.isPrototypeOf(e)
            ? (this._bodyFormData = e)
            : ot.searchParams && URLSearchParams.prototype.isPrototypeOf(e)
            ? (this._bodyText = e.toString())
            : ot.arrayBuffer && ot.blob && Qu(e)
            ? ((this._bodyArrayBuffer = Vi(e.buffer)),
              (this._bodyInit = new Blob([this._bodyArrayBuffer])))
            : ot.arrayBuffer &&
              (ArrayBuffer.prototype.isPrototypeOf(e) || tc(e))
            ? (this._bodyArrayBuffer = Vi(e))
            : (this._bodyText = e = Object.prototype.toString.call(e))
          : ((this._noBody = !0), (this._bodyText = "")),
        this.headers.get("content-type") ||
          (typeof e == "string"
            ? this.headers.set("content-type", "text/plain;charset=UTF-8")
            : this._bodyBlob && this._bodyBlob.type
            ? this.headers.set("content-type", this._bodyBlob.type)
            : ot.searchParams &&
              URLSearchParams.prototype.isPrototypeOf(e) &&
              this.headers.set(
                "content-type",
                "application/x-www-form-urlencoded;charset=UTF-8"
              ));
    }),
    ot.blob &&
      (this.blob = function () {
        var e = Cr(this);
        if (e) return e;
        if (this._bodyBlob) return Promise.resolve(this._bodyBlob);
        if (this._bodyArrayBuffer)
          return Promise.resolve(new Blob([this._bodyArrayBuffer]));
        if (this._bodyFormData)
          throw new Error("could not read FormData body as blob");
        return Promise.resolve(new Blob([this._bodyText]));
      }),
    (this.arrayBuffer = function () {
      if (this._bodyArrayBuffer) {
        var e = Cr(this);
        return (
          e ||
          (ArrayBuffer.isView(this._bodyArrayBuffer)
            ? Promise.resolve(
                this._bodyArrayBuffer.buffer.slice(
                  this._bodyArrayBuffer.byteOffset,
                  this._bodyArrayBuffer.byteOffset +
                    this._bodyArrayBuffer.byteLength
                )
              )
            : Promise.resolve(this._bodyArrayBuffer))
        );
      } else {
        if (ot.blob) return this.blob().then(nc);
        throw new Error("could not read as ArrayBuffer");
      }
    }),
    (this.text = function () {
      var e = Cr(this);
      if (e) return e;
      if (this._bodyBlob) return rc(this._bodyBlob);
      if (this._bodyArrayBuffer)
        return Promise.resolve(ic(this._bodyArrayBuffer));
      if (this._bodyFormData)
        throw new Error("could not read FormData body as text");
      return Promise.resolve(this._bodyText);
    }),
    ot.formData &&
      (this.formData = function () {
        return this.text().then(ac);
      }),
    (this.json = function () {
      return this.text().then(JSON.parse);
    }),
    this
  );
}
var oc = [
  "CONNECT",
  "DELETE",
  "GET",
  "HEAD",
  "OPTIONS",
  "PATCH",
  "POST",
  "PUT",
  "TRACE",
];
function sc(e) {
  var t = e.toUpperCase();
  return oc.indexOf(t) > -1 ? t : e;
}
function nn(e, t) {
  if (!(this instanceof nn))
    throw new TypeError(
      'Please use the "new" operator, this DOM object constructor cannot be called as a function.'
    );
  t = t || {};
  var n = t.body;
  if (e instanceof nn) {
    if (e.bodyUsed) throw new TypeError("Already read");
    (this.url = e.url),
      (this.credentials = e.credentials),
      t.headers || (this.headers = new Ke(e.headers)),
      (this.method = e.method),
      (this.mode = e.mode),
      (this.signal = e.signal),
      !n && e._bodyInit != null && ((n = e._bodyInit), (e.bodyUsed = !0));
  } else this.url = String(e);
  if (
    ((this.credentials = t.credentials || this.credentials || "same-origin"),
    (t.headers || !this.headers) && (this.headers = new Ke(t.headers)),
    (this.method = sc(t.method || this.method || "GET")),
    (this.mode = t.mode || this.mode || null),
    (this.signal =
      t.signal ||
      this.signal ||
      (function () {
        if ("AbortController" in Je) {
          var f = new AbortController();
          return f.signal;
        }
      })()),
    (this.referrer = null),
    (this.method === "GET" || this.method === "HEAD") && n)
  )
    throw new TypeError("Body not allowed for GET or HEAD requests");
  if (
    (this._initBody(n),
    (this.method === "GET" || this.method === "HEAD") &&
      (t.cache === "no-store" || t.cache === "no-cache"))
  ) {
    var o = /([?&])_=[^&]*/;
    if (o.test(this.url))
      this.url = this.url.replace(o, "$1_=" + new Date().getTime());
    else {
      var a = /\?/;
      this.url += (a.test(this.url) ? "&" : "?") + "_=" + new Date().getTime();
    }
  }
}
nn.prototype.clone = function () {
  return new nn(this, { body: this._bodyInit });
};
function ac(e) {
  var t = new FormData();
  return (
    e
      .trim()
      .split("&")
      .forEach(function (n) {
        if (n) {
          var o = n.split("="),
            a = o.shift().replace(/\+/g, " "),
            f = o.join("=").replace(/\+/g, " ");
          t.append(decodeURIComponent(a), decodeURIComponent(f));
        }
      }),
    t
  );
}
function uc(e) {
  var t = new Ke(),
    n = e.replace(/\r?\n[\t ]+/g, " ");
  return (
    n
      .split("\r")
      .map(function (o) {
        return o.indexOf(`
`) === 0
          ? o.substr(1, o.length)
          : o;
      })
      .forEach(function (o) {
        var a = o.split(":"),
          f = a.shift().trim();
        if (f) {
          var c = a.join(":").trim();
          try {
            t.append(f, c);
          } catch (s) {
            console.warn("Response " + s.message);
          }
        }
      }),
    t
  );
}
us.call(nn.prototype);
function It(e, t) {
  if (!(this instanceof It))
    throw new TypeError(
      'Please use the "new" operator, this DOM object constructor cannot be called as a function.'
    );
  if (
    (t || (t = {}),
    (this.type = "default"),
    (this.status = t.status === void 0 ? 200 : t.status),
    this.status < 200 || this.status > 599)
  )
    throw new RangeError(
      "Failed to construct 'Response': The status provided (0) is outside the range [200, 599]."
    );
  (this.ok = this.status >= 200 && this.status < 300),
    (this.statusText = t.statusText === void 0 ? "" : "" + t.statusText),
    (this.headers = new Ke(t.headers)),
    (this.url = t.url || ""),
    this._initBody(e);
}
us.call(It.prototype);
It.prototype.clone = function () {
  return new It(this._bodyInit, {
    status: this.status,
    statusText: this.statusText,
    headers: new Ke(this.headers),
    url: this.url,
  });
};
It.error = function () {
  var e = new It(null, { status: 200, statusText: "" });
  return (e.ok = !1), (e.status = 0), (e.type = "error"), e;
};
var cc = [301, 302, 303, 307, 308];
It.redirect = function (e, t) {
  if (cc.indexOf(t) === -1) throw new RangeError("Invalid status code");
  return new It(null, { status: t, headers: { location: e } });
};
var Qt = Je.DOMException;
try {
  new Qt();
} catch {
  (Qt = function (t, n) {
    (this.message = t), (this.name = n);
    var o = Error(t);
    this.stack = o.stack;
  }),
    (Qt.prototype = Object.create(Error.prototype)),
    (Qt.prototype.constructor = Qt);
}
function cs(e, t) {
  return new Promise(function (n, o) {
    var a = new nn(e, t);
    if (a.signal && a.signal.aborted) return o(new Qt("Aborted", "AbortError"));
    var f = new XMLHttpRequest();
    function c() {
      f.abort();
    }
    (f.onload = function () {
      var l = {
        statusText: f.statusText,
        headers: uc(f.getAllResponseHeaders() || ""),
      };
      a.url.indexOf("file://") === 0 && (f.status < 200 || f.status > 599)
        ? (l.status = 200)
        : (l.status = f.status),
        (l.url =
          "responseURL" in f ? f.responseURL : l.headers.get("X-Request-URL"));
      var d = "response" in f ? f.response : f.responseText;
      setTimeout(function () {
        n(new It(d, l));
      }, 0);
    }),
      (f.onerror = function () {
        setTimeout(function () {
          o(new TypeError("Network request failed"));
        }, 0);
      }),
      (f.ontimeout = function () {
        setTimeout(function () {
          o(new TypeError("Network request timed out"));
        }, 0);
      }),
      (f.onabort = function () {
        setTimeout(function () {
          o(new Qt("Aborted", "AbortError"));
        }, 0);
      });
    function s(l) {
      try {
        return l === "" && Je.location.href ? Je.location.href : l;
      } catch {
        return l;
      }
    }
    if (
      (f.open(a.method, s(a.url), !0),
      a.credentials === "include"
        ? (f.withCredentials = !0)
        : a.credentials === "omit" && (f.withCredentials = !1),
      "responseType" in f &&
        (ot.blob
          ? (f.responseType = "blob")
          : ot.arrayBuffer && (f.responseType = "arraybuffer")),
      t &&
        typeof t.headers == "object" &&
        !(
          t.headers instanceof Ke ||
          (Je.Headers && t.headers instanceof Je.Headers)
        ))
    ) {
      var r = [];
      Object.getOwnPropertyNames(t.headers).forEach(function (l) {
        r.push(bn(l)), f.setRequestHeader(l, ui(t.headers[l]));
      }),
        a.headers.forEach(function (l, d) {
          r.indexOf(d) === -1 && f.setRequestHeader(d, l);
        });
    } else
      a.headers.forEach(function (l, d) {
        f.setRequestHeader(d, l);
      });
    a.signal &&
      (a.signal.addEventListener("abort", c),
      (f.onreadystatechange = function () {
        f.readyState === 4 && a.signal.removeEventListener("abort", c);
      })),
      f.send(typeof a._bodyInit > "u" ? null : a._bodyInit);
  });
}
cs.polyfill = !0;
Je.fetch ||
  ((Je.fetch = cs), (Je.Headers = Ke), (Je.Request = nn), (Je.Response = It));
const lc = "703";
function Hi(e, t, n = "beforeend") {
  var o;
  try {
    const a = t.ownerDocument,
      f = a.createElement("span");
    t.insertAdjacentElement(n, f);
    const c = a.createRange();
    c.setStartAfter(f);
    const s = c.createContextualFragment(e);
    for (; s.firstChild; )
      f.parentNode && f.parentNode.insertBefore(s.firstChild, f);
    return (o = f.parentNode) == null || o.removeChild(f), !0;
  } catch {
    return !1;
  }
}
function _n(e) {
  return os.Buffer.from(e).toString("base64");
}
function fn(e) {
  return e !== void 0 && e !== "" && e.trim() !== "";
}
async function fc(e) {
  let t = {};
  try {
    t = await (await fetch(e)).json();
  } catch {}
  return t;
}
function dc(e, t, n) {
  const o = new IntersectionObserver(
    (a) => {
      a.forEach((f) => {
        f.intersectionRatio >= t && (n(), o.unobserve(e));
      });
    },
    { threshold: t }
  );
  o.observe(e);
}
function Zi(e, t) {
  for (const n of t)
    n.type === "intervention" &&
      n.body.id === "HeavyAdIntervention" &&
      hc(e, n);
}
function hc(e, t) {
  const n = new Map([
    [
      "Ad was removed because its network usage exceeded the limit. See https://www.chromestatus.com/feature/4800491902992384?utm_source=devtools",
      "80101",
    ],
    [
      "Ad was removed because its total CPU usage exceeded the limit. See https://www.chromestatus.com/feature/4800491902992384?utm_source=devtools",
      "80102",
    ],
    [
      "Ad was removed because its peak CPU usage exceeded the limit. See https://www.chromestatus.com/feature/4800491902992384?utm_source=devtools",
      "80103",
    ],
  ]);
  try {
    const o = new URL(e),
      a = n.get(t.body.message);
    o.searchParams.set("ec", lc),
      a ? o.searchParams.set("ve", a) : o.searchParams.set("ve", "80100"),
      fetch(o.toString(), { keepalive: !0 }).catch(() => {});
  } catch (o) {
    qe.debug(`failed to parse ET URL: ${o}`);
  }
}
function pc(e) {
  if (typeof ReportingObserver != "function") return;
  const t = new ReportingObserver(
    (n, o) => {
      Zi(e, n);
    },
    { buffered: !0 }
  );
  window.addEventListener("pagehide", (n) => {
    const o = t.takeRecords();
    Zi(e, o);
  }),
    t.observe();
}
function Ye() {
  return yn(rs);
}
function gc() {
  return yn(is, "en");
}
function mc(e, t, n, o, a, f, c) {
  const s = ct({
    assets: e.assets,
    styles: e.styles,
    videoErrors: [],
    hasValidImage: fn(e.assets.imageUrl),
    hasValidVideo: lt(() => fn(e.assets.vastXml) && s.videoErrors.length === 0),
    hasOnlyVideo: lt(
      () =>
        fn(e.assets.vastXml) && !fn(e.assets.title) && !fn(e.assets.description)
    ),
    hasValidMedia: lt(() => s.hasValidImage || s.hasValidVideo),
    verification: n,
    autoplay: o,
    viewabilityURL: a,
    eventTrackerURL: f,
    eventTrackerEvents: c,
    ...vc(e, t),
  });
  return ti(rs, s), s;
}
function yc(e) {
  ti(is, e);
}
function vc(e, t) {
  function n() {
    if (t.value !== null) {
      qe.debug("firing impression trackers");
      const f = Wi(e.impressionTrackers);
      Hi(f, t.value, "beforeend");
    }
  }
  function o() {
    if (t.value !== null) {
      qe.debug("firing click trackers");
      const f = Wi(e.clickTrackers);
      Hi(f, t.value, "beforeend");
    }
  }
  function a(f) {
    switch (f) {
      case "text":
      case "image":
        o(), window.open(e.assets.clickUrl);
        break;
      case "adchoices":
        window.open(e.assets.privacyUrl);
        break;
      case "outstreamText":
        const c = document.getElementsByTagName("video"),
          s = window.jwplayer("video-container"),
          r = 500;
        if (c.length > 0) {
          const l = document.querySelector('[aria-label="Replay"]');
          s.getState() === "complete" && l.click(),
            s.getState() === "paused" && c[0].play(),
            wc(s, r)
              .then(() => {
                c[0].click();
              })
              .catch((d) => {
                qe.debug(d.message);
              });
        }
        break;
      default:
        qe.debug("unhandled click");
        break;
    }
  }
  return { fireImpressionTrackers: n, fireClickTrackers: o, handleClick: a };
}
function Wi(e) {
  let t = "";
  for (const n of e) t += atob(n);
  return t;
}
function wc(e, t) {
  const n = Date.now(),
    o = 10;
  return new Promise((a, f) => {
    function c() {
      e.getState() === "playing"
        ? a()
        : Date.now() - n > t
        ? f(new Error("waitForVideoToPlay: timeout reached"))
        : window.setTimeout(c, o);
    }
    c();
  });
}
function Kt() {
  const e = window.windowDimensions;
  if (e) return e;
  const t = ct({
    measured: !0,
    width: window.innerWidth,
    height: window.innerHeight,
    area: window.innerWidth * window.innerHeight,
  });
  function n() {
    (t.width = window.innerWidth),
      (t.height = window.innerHeight),
      (t.area = window.innerWidth * window.innerHeight),
      qe.debug(`window dimensions measured as ${t.width}x${t.height}`);
  }
  return (
    on(() => window.addEventListener("resize", n)),
    or(() => window.removeEventListener("resize", n)),
    (window.windowDimensions = t),
    t
  );
}
function bc(e) {
  const t = ct({ measured: !1, width: 0, height: 0, area: 0 });
  function n() {
    var a, f;
    if (e.value) {
      const c = (a = e.value) == null ? void 0 : a.offsetWidth,
        s = (f = e.value) == null ? void 0 : f.offsetHeight;
      t.measured || (t.measured = !0),
        (t.width !== c || t.height !== s) &&
          ((t.width = c),
          (t.height = s),
          (t.area = c * s),
          qe.debug(`element #${e.value.id} dimensions measured as ${c}x${s}`));
    }
  }
  on(n), Oo(n);
  const o = Kt();
  return vn(o, n), t;
}
const xc = Ze({
    props: {
      renderPayload: { type: Object, required: !0 },
      language: { type: String },
      interstitial: { type: Boolean },
      verification: { type: String, default: "" },
      autoplay: { type: Boolean, default: !1 },
      viewabilityURL: { type: String, default: "" },
      eventTrackerURL: { type: String, default: "" },
      eventTrackerEvents: { type: Array, required: !0 },
    },
    setup(e) {
      const t = Lt(null),
        n = mc(
          e.renderPayload,
          t,
          e.verification,
          e.autoplay,
          e.viewabilityURL,
          e.eventTrackerURL,
          e.eventTrackerEvents
        );
      yc(e.language || "en");
      const o = Kt(),
        a = ct({ name: "", key: "" });
      return (
        Ha(() => {
          (a.name = Zu(o.width, o.height, n.hasOnlyVideo)),
            qe.debug(`using layout: ${a.name}`);
        }),
        on(n.fireImpressionTrackers),
        { tagContainerRef: t, layoutComponent: a, renderState: n, props: e }
      );
    },
  }),
  We = (e, t) => {
    const n = e.__vccOpts || e;
    for (const [o, a] of t) n[o] = a;
    return n;
  },
  Sc = { ref: "tagContainerRef" };
function _c(e, t, n, o, a, f) {
  const c = Se("AdChoices");
  return (
    Ae(),
    Fe(
      "div",
      {
        id: "container",
        style: ye({
          "--container-border": e.renderState.hasValidVideo
            ? "0px"
            : "1px solid #e5e6e6",
          "--border-radius": e.props.interstitial ? "0px" : "5px",
        }),
      },
      [
        Ee(
          c,
          {
            "privacy-url": e.renderState.assets.privacyUrl,
            onClick: e.renderState.handleClick,
            style: ye(e.renderState.styles.adChoices),
          },
          null,
          8,
          ["privacy-url", "onClick", "style"]
        ),
        (Ae(),
        tt(
          xa(e.layoutComponent.name),
          { onClick: e.renderState.handleClick },
          null,
          8,
          ["onClick"]
        )),
        je("span", Sc, null, 512),
      ],
      4
    )
  );
}
const Cc = We(xc, [["render", _c]]);
var En = ((e) => (
    (e[(e.Description = 2)] = "Description"),
    (e[(e.Cta = 3)] = "Cta"),
    (e[(e.Disclaimer = 4)] = "Disclaimer"),
    (e[(e.MainImage = 5)] = "MainImage"),
    e
  ))(En || {}),
  ls = ((e) => ((e[(e.Icon = 1)] = "Icon"), (e[(e.Main = 3)] = "Main"), e))(
    ls || {}
  ),
  fs = ((e) => (
    (e[(e.Impression = 1)] = "Impression"),
    (e[(e.ViewableMrc50 = 2)] = "ViewableMrc50"),
    (e[(e.ViewableMrc100 = 3)] = "ViewableMrc100"),
    (e[(e.ViewableVideo50 = 4)] = "ViewableVideo50"),
    e
  ))(fs || {}),
  ds = ((e) => (
    (e[(e.Image = 1)] = "Image"), (e[(e.Javascript = 2)] = "Javascript"), e
  ))(ds || {});
const Ec = {
    en: "Learn More",
    de: "Mehr erfahren",
    es: "Saber más",
    fr: "En savoir plus",
    it: "Scopri di più",
    ja: "詳しくはこちら",
    ko: "더 알아보기",
    pl: "Dowiedz się więcej",
    pt: "Saiba mais",
    ru: "Подробнее",
    zh: "了解更多",
  },
  kc = {
    en: "Ad",
    de: "Anzeige",
    es: "Publicidad",
    fr: "Publicité",
    it: "Pubblicità",
    ja: "広告",
    ko: "광고",
    pl: "Reklama",
    pt: "Pub",
    ru: "Реклама",
    zh: "广告",
  };
async function Tc(e, t) {
  if (!e) throw new Error("No native JSON passed in");
  const { native: n } = e;
  if (!n) throw new Error("No native object found");
  const o = {
    assets: {
      title: "",
      description: "",
      imageUrl: "",
      iconUrl: "",
      disclaimer: "",
      ctaText: Ec[t],
      clickUrl: "",
    },
    impressionTrackers: [],
    clickTrackers: [],
    styles: {},
  };
  if ((qi(o, n), n.assetsurl)) {
    const a = await fc(n.assetsurl);
    qi(o, a);
  }
  return o;
}
function qi(e, t) {
  var o, a, f, c, s;
  if (
    ((e.assets.clickUrl = (o = t.link) == null ? void 0 : o.url),
    ((a = t.assets) == null ? void 0 : a.length) > 0 && Pc(e, t.assets),
    t.privacy && (e.assets.privacyUrl = t.privacy),
    t.jstracker)
  ) {
    const r = t.jstracker;
    e.impressionTrackers.push(_n(r));
  }
  if (Array.isArray(t.imptrackers))
    for (const r of t.imptrackers) {
      const l = `<img src="${r}" width="0" height="0" />`;
      e.impressionTrackers.push(_n(l));
    }
  if (Array.isArray((f = t.link) == null ? void 0 : f.clicktrackers))
    for (const r of t.link.clicktrackers) {
      const l = `<img src="${r}" width="0" height="0" />`;
      e.clickTrackers.push(_n(l));
    }
  if (Array.isArray(t.eventtrackers)) {
    for (const r of t.eventtrackers)
      if (r.event === fs.Impression)
        if (r.method === ds.Image) {
          const l = `<img src="${r.url}" width="0" height="0" />`;
          e.impressionTrackers.push(_n(l));
        } else {
          const l = `<script src="${r.url}" ><\/script>`;
          e.impressionTrackers.push(_n(l));
        }
  }
  const n = (s = (c = t.ext) == null ? void 0 : c.ix) == null ? void 0 : s.css;
  n && (e.styles = { ...n });
}
function Pc(e, t) {
  var n, o, a, f, c, s, r;
  for (const l of t) {
    if ((n = l.title) != null && n.text) {
      e.assets.title = l.title.text;
      continue;
    }
    if (
      (l == null ? void 0 : l.id) === En.MainImage &&
      (o = l.img) != null &&
      o.url
    ) {
      e.assets.imageUrl = l.img.url;
      continue;
    }
    if (((a = l.img) == null ? void 0 : a.type) === ls.Icon && l.img.url) {
      e.assets.iconUrl = l.img.url;
      continue;
    }
    if (l.id === En.Description && (f = l.data) != null && f.value) {
      e.assets.description = l.data.value;
      continue;
    }
    if (l.id === En.Disclaimer && (c = l.data) != null && c.value) {
      e.assets.disclaimer = `${l.data.value}`;
      continue;
    }
    if (l.id === En.Cta && (s = l.data) != null && s.value) {
      e.assets.ctaText = l.data.value;
      continue;
    }
    if ((r = l.video) != null && r.vasttag) {
      e.assets.vastXml = l.video.vasttag;
      continue;
    }
  }
}
const Ac = Ze({
    setup() {
      return { renderState: Ye() };
    },
  }),
  Ic = { class: "top-row" },
  Oc = { class: "bottom-row" };
function Bc(e, t, n, o, a, f) {
  const c = Se("MediaPartShrinking"),
    s = Se("Disclaimer"),
    r = Se("AdLabel"),
    l = Se("Title"),
    d = Se("Cta"),
    w = Se("TextPart");
  return (
    Ae(),
    Fe(
      "div",
      { id: "layout-320x100", style: ye(e.renderState.styles.layout) },
      [
        Ee(
          c,
          {
            onClick: e.renderState.handleClick,
            style: ye(e.renderState.styles.mediaPart),
            fill: "height",
            aspectRatio: 1 / 1,
          },
          null,
          8,
          ["onClick", "style"]
        ),
        Ee(
          w,
          {
            onClick: e.renderState.handleClick,
            style: ye(e.renderState.styles.textPart),
          },
          {
            default: bt(() => [
              je("div", Ic, [
                Ee(
                  s,
                  {
                    text: e.renderState.assets.disclaimer,
                    style: ye(e.renderState.styles.disclaimer),
                  },
                  null,
                  8,
                  ["text", "style"]
                ),
                Ee(r),
              ]),
              je("div", Oc, [
                Ee(
                  l,
                  {
                    text: e.renderState.assets.title,
                    style: ye(e.renderState.styles.title),
                  },
                  null,
                  8,
                  ["text", "style"]
                ),
                e.renderState.assets.ctaText
                  ? (Ae(),
                    tt(
                      d,
                      {
                        key: 0,
                        text: e.renderState.assets.ctaText,
                        style: ye(e.renderState.styles.cta),
                      },
                      null,
                      8,
                      ["text", "style"]
                    ))
                  : Ve("", !0),
              ]),
            ]),
            _: 1,
          },
          8,
          ["onClick", "style"]
        ),
      ],
      4
    )
  );
}
const Rc = We(Ac, [["render", Bc]]),
  Fc = Ze({
    setup() {
      return { renderState: Ye() };
    },
  }),
  jc = { class: "top-row" };
function Lc(e, t, n, o, a, f) {
  const c = Se("MediaPartShrinking"),
    s = Se("Disclaimer"),
    r = Se("AdLabel"),
    l = Se("Title"),
    d = Se("TextPart");
  return (
    Ae(),
    Fe(
      "div",
      { id: "layout-320x50", style: ye(e.renderState.styles.layout) },
      [
        Ee(
          c,
          {
            onClick: e.renderState.handleClick,
            style: ye(e.renderState.styles.mediaPart),
            fill: "height",
            aspectRatio: 1 / 1,
          },
          null,
          8,
          ["onClick", "style"]
        ),
        Ee(
          d,
          {
            onClick: e.renderState.handleClick,
            style: ye(e.renderState.styles.textPart),
          },
          {
            default: bt(() => [
              je("div", jc, [
                Ee(
                  s,
                  {
                    text: e.renderState.assets.disclaimer,
                    style: ye(e.renderState.styles.disclaimer),
                  },
                  null,
                  8,
                  ["text", "style"]
                ),
                Ee(r),
              ]),
              Ee(
                l,
                {
                  text: e.renderState.assets.title,
                  style: ye(e.renderState.styles.title),
                },
                null,
                8,
                ["text", "style"]
              ),
            ]),
            _: 1,
          },
          8,
          ["onClick", "style"]
        ),
      ],
      4
    )
  );
}
const Mc = We(Fc, [["render", Lc]]),
  Dc = Ze({
    setup() {
      const e = Ye(),
        t = ct({ showCta: lt(() => !e.hasValidMedia) });
      return { renderState: e, state: t };
    },
  }),
  $c = { class: "top-row" },
  Uc = { class: "bottom-row" };
function Nc(e, t, n, o, a, f) {
  const c = Se("MediaPartShrinking"),
    s = Se("Disclaimer"),
    r = Se("AdLabel"),
    l = Se("Title"),
    d = Se("Cta"),
    w = Se("TextPart");
  return (
    Ae(),
    Fe(
      "div",
      { id: "layout-728x90", style: ye(e.renderState.styles.layout) },
      [
        Ee(
          c,
          {
            onClick: e.renderState.handleClick,
            style: ye(e.renderState.styles.mediaPart),
            fill: "height",
            aspectRatio: 450 / 90,
          },
          null,
          8,
          ["onClick", "style"]
        ),
        Ee(
          w,
          {
            onClick: e.renderState.handleClick,
            style: ye(e.renderState.styles.textPart),
          },
          {
            default: bt(() => [
              je("div", $c, [
                Ee(
                  s,
                  {
                    text: e.renderState.assets.disclaimer,
                    style: ye(e.renderState.styles.disclaimer),
                  },
                  null,
                  8,
                  ["text", "style"]
                ),
                Ee(r),
              ]),
              je("div", Uc, [
                Ee(
                  l,
                  {
                    text: e.renderState.assets.title,
                    style: ye(e.renderState.styles.title),
                  },
                  null,
                  8,
                  ["text", "style"]
                ),
                e.state.showCta
                  ? (Ae(),
                    tt(
                      d,
                      {
                        key: 0,
                        text: e.renderState.assets.ctaText,
                        style: ye(e.renderState.styles.cta),
                      },
                      null,
                      8,
                      ["text", "style"]
                    ))
                  : Ve("", !0),
              ]),
            ]),
            _: 1,
          },
          8,
          ["onClick", "style"]
        ),
      ],
      4
    )
  );
}
const Vc = We(Dc, [["render", Nc]]),
  Hc = Ze({
    setup() {
      return { renderState: Ye() };
    },
  }),
  Zc = { class: "top-row" },
  Wc = { class: "bottom-row" };
function qc(e, t, n, o, a, f) {
  const c = Se("MediaPartShrinking"),
    s = Se("Disclaimer"),
    r = Se("AdLabel"),
    l = Se("Title"),
    d = Se("Cta"),
    w = Se("TextPart");
  return (
    Ae(),
    Fe(
      "div",
      { id: "layout-970x90", style: ye(e.renderState.styles.layout) },
      [
        Ee(
          c,
          {
            onClick: e.renderState.handleClick,
            style: ye(e.renderState.styles.mediaPart),
            fill: "height",
            aspectRatio: 450 / 90,
          },
          null,
          8,
          ["onClick", "style"]
        ),
        Ee(
          w,
          {
            onClick: e.renderState.handleClick,
            style: ye(e.renderState.styles.textPart),
          },
          {
            default: bt(() => [
              je("div", Zc, [
                Ee(
                  s,
                  {
                    text: e.renderState.assets.disclaimer,
                    style: ye(e.renderState.styles.disclaimer),
                  },
                  null,
                  8,
                  ["text", "style"]
                ),
                Ee(r),
              ]),
              je("div", Wc, [
                Ee(
                  l,
                  {
                    text: e.renderState.assets.title,
                    style: ye(e.renderState.styles.title),
                  },
                  null,
                  8,
                  ["text", "style"]
                ),
                Ee(
                  d,
                  {
                    text: e.renderState.assets.ctaText,
                    style: ye(e.renderState.styles.cta),
                  },
                  null,
                  8,
                  ["text", "style"]
                ),
              ]),
            ]),
            _: 1,
          },
          8,
          ["onClick", "style"]
        ),
      ],
      4
    )
  );
}
const zc = We(Hc, [["render", qc]]),
  Er = 70,
  zi = 30,
  Kc = Ze({
    emits: ["click"],
    setup(e, t) {
      const n = Ye(),
        o = Kt(),
        a = ct({ isLandscape: !1 });
      vn(
        () => [o.width, o.height],
        ([d, w]) => {
          a.isLandscape = w < d;
        },
        { immediate: !0 }
      );
      function f() {
        qe.debug("click from source: outstreamText"),
          t.emit("click", "outstreamText");
      }
      const c = lt(() =>
          a.isLandscape ? "horizontal-container" : "vertical-container"
        ),
        s = lt(() => (a.isLandscape ? "button-container" : "")),
        r = lt(() => {
          if (a.isLandscape)
            return { flex: "none", width: `${Er}%`, height: "100%" };
          {
            const d = Er - (100 - Er);
            return {
              flex: "none",
              width: "100%",
              height: `${d}%`,
              "margin-top": `${d}%`,
            };
          }
        }),
        l = lt(() =>
          a.isLandscape
            ? { flex: "none", width: `${zi}%`, height: "100%" }
            : {
                flex: "none",
                height: `${zi}%`,
                display: "flex",
                "align-items": "center",
              }
        );
      return {
        state: a,
        renderState: n,
        handleClick: f,
        containerClass: c,
        buttonContainerClass: s,
        mediaStyle: r,
        textStyle: l,
        windowDimensions: o,
      };
    },
  }),
  Gc = { class: "cta-button" };
function Xc(e, t, n, o, a, f) {
  const c = Se("VideoPlayer");
  return (
    Ae(),
    Fe(
      "div",
      { class: Pt(["container", e.containerClass]) },
      [
        je(
          "div",
          { id: "media", style: ye(e.mediaStyle) },
          [
            e.renderState.hasValidVideo
              ? (Ae(),
                tt(
                  c,
                  {
                    key: 0,
                    id: "video-root",
                    isInterstitial: !0,
                    isLandscape: e.state.isLandscape,
                  },
                  null,
                  8,
                  ["isLandscape"]
                ))
              : Ve("", !0),
          ],
          4
        ),
        je(
          "div",
          {
            id: "text",
            class: Pt(["button-container", e.buttonContainerClass]),
            style: ye(e.textStyle),
            onClick:
              t[0] || (t[0] = (...s) => e.handleClick && e.handleClick(...s)),
          },
          [je("div", Gc, Ot(e.renderState.assets.ctaText), 1)],
          6
        ),
      ],
      2
    )
  );
}
const Jc = We(Kc, [["render", Xc]]),
  Yc = 1,
  Qc = 2,
  el = Ze({
    setup() {
      const e = Ye();
      return {
        state: ct({
          showDescription: e.assets.description.length > 0,
          showCta: e.assets.ctaText.length > 0,
          maxLines: e.hasValidMedia ? Yc : Qc,
          titleFontSize: e.assets.description.length > 0 ? "14px" : "15px",
        }),
        renderState: e,
      };
    },
  }),
  tl = { class: "bottom-row" },
  nl = ["src"];
function rl(e, t, n, o, a, f) {
  const c = Se("MediaPartShrinking"),
    s = Se("Title"),
    r = Se("Description"),
    l = Se("AdLabel"),
    d = Se("Disclaimer"),
    w = Se("Cta"),
    S = Se("TextPart");
  return (
    Ae(),
    Fe(
      "div",
      {
        id: "layout-square",
        style: ye(e.renderState.styles.layout),
        class: Pt(e.renderState.hasValidMedia ? "hasValidMedia" : ""),
      },
      [
        Ee(
          c,
          {
            onClick: e.renderState.handleClick,
            style: ye(e.renderState.styles.mediaPart),
            aspectRatio: 1.91,
            fill: "width",
          },
          null,
          8,
          ["onClick", "style"]
        ),
        Ee(
          S,
          {
            onClick: e.renderState.handleClick,
            style: ye(e.renderState.styles.textPart),
          },
          {
            default: bt(() => [
              je(
                "div",
                {
                  class: "top-row",
                  style: ye({ "--title-font-size": e.state.titleFontSize }),
                },
                [
                  e.renderState.assets.title
                    ? (Ae(),
                      tt(
                        s,
                        {
                          key: 0,
                          text: e.renderState.assets.title,
                          style: ye(e.renderState.styles.title),
                          maxLines: e.state.showDescription
                            ? e.state.maxLines
                            : 2,
                        },
                        null,
                        8,
                        ["text", "style", "maxLines"]
                      ))
                    : Ve("", !0),
                  e.state.showDescription
                    ? (Ae(),
                      tt(
                        r,
                        {
                          key: 1,
                          maxLines: e.state.maxLines,
                          text: e.renderState.assets.description,
                          style: ye(e.renderState.styles.description),
                        },
                        null,
                        8,
                        ["maxLines", "text", "style"]
                      ))
                    : Ve("", !0),
                ],
                4
              ),
              je("div", tl, [
                e.renderState.assets.iconUrl
                  ? (Ae(),
                    Fe(
                      "img",
                      {
                        key: 0,
                        src: e.renderState.assets.iconUrl,
                        alt: "background.img",
                      },
                      null,
                      8,
                      nl
                    ))
                  : Ve("", !0),
                e.renderState.assets.iconUrl
                  ? Ve("", !0)
                  : (Ae(), tt(l, { key: 1 })),
                Ee(d, { text: e.renderState.assets.disclaimer }, null, 8, [
                  "text",
                ]),
                e.state.showCta
                  ? (Ae(),
                    tt(
                      w,
                      {
                        key: 2,
                        text: e.renderState.assets.ctaText,
                        showOverflowIcon: !0,
                        iconWidth: 16,
                      },
                      null,
                      8,
                      ["text"]
                    ))
                  : Ve("", !0),
              ]),
            ]),
            _: 1,
          },
          8,
          ["onClick", "style"]
        ),
      ],
      6
    )
  );
}
const il = We(el, [["render", rl]]),
  ol = 0.75,
  sl = 170,
  al = 2,
  ul = 190,
  cl = 3,
  ll = Ze({
    setup() {
      const e = Ye(),
        t = Kt(),
        n = t.height - t.width * ol;
      return {
        state: ct({
          showDescription: n > sl,
          descriptionLines: n > ul ? cl : al,
        }),
        renderState: e,
      };
    },
  }),
  fl = { class: "brand-row" },
  dl = ["src"],
  hl = { class: "bottom-row" };
function pl(e, t, n, o, a, f) {
  const c = Se("MediaPartShrinking"),
    s = Se("Title"),
    r = Se("Description"),
    l = Se("AdLabel"),
    d = Se("Disclaimer"),
    w = Se("Cta"),
    S = Se("TextPart");
  return (
    Ae(),
    Fe(
      "div",
      { id: "layout-tall", style: ye(e.renderState.styles.layout) },
      [
        Ee(
          c,
          {
            onClick: e.renderState.handleClick,
            style: ye(e.renderState.styles.mediaPart),
            fill: "width",
            aspectRatio: 4 / 3,
          },
          null,
          8,
          ["onClick", "style"]
        ),
        Ee(
          S,
          {
            onClick: e.renderState.handleClick,
            style: ye({
              "--justify-content": e.renderState.hasValidMedia
                ? "start"
                : "center",
              class: e.renderState.styles.textPart,
            }),
          },
          {
            default: bt(() => [
              je(
                "div",
                {
                  class: "top-row",
                  style: ye({
                    "--justify-content": e.renderState.hasValidMedia
                      ? "start"
                      : "center",
                  }),
                },
                [
                  Ee(
                    s,
                    {
                      text: e.renderState.assets.title,
                      style: ye(e.renderState.styles.title),
                      maxLines: 2,
                    },
                    null,
                    8,
                    ["text", "style"]
                  ),
                  e.state.showDescription
                    ? (Ae(),
                      tt(
                        r,
                        {
                          key: 0,
                          text: e.renderState.assets.description,
                          style: ye(e.renderState.styles.description),
                          maxLines: e.state.descriptionLines,
                        },
                        null,
                        8,
                        ["text", "style", "maxLines"]
                      ))
                    : Ve("", !0),
                  je("div", fl, [
                    e.renderState.assets.iconUrl
                      ? (Ae(),
                        Fe(
                          "img",
                          {
                            key: 0,
                            src: e.renderState.assets.iconUrl,
                            alt: "background.img",
                          },
                          null,
                          8,
                          dl
                        ))
                      : Ve("", !0),
                    e.renderState.assets.iconUrl
                      ? Ve("", !0)
                      : (Ae(), tt(l, { key: 1 })),
                    Ee(
                      d,
                      {
                        text: e.renderState.assets.disclaimer,
                        style: ye(e.renderState.styles.disclaimer),
                      },
                      null,
                      8,
                      ["text", "style"]
                    ),
                  ]),
                ],
                4
              ),
              je("div", hl, [
                Ee(
                  w,
                  {
                    text: e.renderState.assets.ctaText,
                    style: ye(e.renderState.styles.cta),
                  },
                  null,
                  8,
                  ["text", "style"]
                ),
              ]),
            ]),
            _: 1,
          },
          8,
          ["onClick", "style"]
        ),
      ],
      4
    )
  );
}
const gl = We(ll, [["render", pl]]),
  ml = 1.77 / 1,
  Ki = 0.36,
  yl = Ze({
    emits: ["click"],
    setup(e, t) {
      const n = Ye(),
        o = Kt(),
        a = lt(() => {
          const r = o.width / ml;
          return o.height - r;
        }),
        f = lt(() => Math.round(Math.max(0, a.value * Ki)) + "px"),
        c = lt(
          () => (Math.round(Math.max(0, a.value * (1 - Ki))) - 31.5) / 2 + "px"
        );
      function s() {
        qe.debug("click from source: outstreamText"),
          t.emit("click", "outstreamText");
      }
      return {
        renderState: n,
        handleClick: s,
        paddingTop: f,
        marginRightCTA: c,
      };
    },
  });
function vl(e, t, n, o, a, f) {
  const c = Se("MediaPartShrinking"),
    s = Se("TextPart");
  return (
    Ae(),
    Fe(
      "div",
      {
        id: "layout-video-square",
        style: ye({ paddingTop: e.paddingTop }),
        class: Pt(e.renderState.hasValidMedia ? "hasValidMedia" : ""),
      },
      [
        Ee(
          c,
          {
            style: ye(e.renderState.styles.mediaPart),
            aspectRatio: 1.77,
            fill: "width",
          },
          null,
          8,
          ["style"]
        ),
        Ee(
          s,
          { style: ye(e.renderState.styles.textPart) },
          {
            default: bt(() => [
              je(
                "div",
                {
                  class: "video-bottom-row",
                  onClick:
                    t[0] ||
                    (t[0] = (...r) => e.handleClick && e.handleClick(...r)),
                },
                [
                  je(
                    "div",
                    {
                      class: "video-cta",
                      style: ye({ marginRight: e.marginRightCTA }),
                    },
                    Ot(e.renderState.assets.ctaText.toUpperCase()),
                    5
                  ),
                ]
              ),
            ]),
            _: 1,
          },
          8,
          ["style"]
        ),
      ],
      6
    )
  );
}
const wl = We(yl, [["render", vl]]),
  bl = Ze({
    emits: ["click"],
    setup(e, t) {
      const n = Ye();
      function o() {
        qe.debug("click from source: outstreamText"),
          t.emit("click", "outstreamText");
      }
      return { renderState: n, handleClick: o };
    },
  }),
  xl = { class: "video-cta" };
function Sl(e, t, n, o, a, f) {
  const c = Se("MediaPartShrinking"),
    s = Se("TextPart");
  return (
    Ae(),
    Fe(
      "div",
      {
        id: "layout-video-tall",
        class: Pt(e.renderState.hasValidMedia ? "hasValidMedia" : ""),
      },
      [
        Ee(
          c,
          {
            style: ye(e.renderState.styles.mediaPart),
            aspectRatio: 1 / 1.77,
            fill: "width",
          },
          null,
          8,
          ["style"]
        ),
        Ee(
          s,
          { style: ye(e.renderState.styles.textPart) },
          {
            default: bt(() => [
              je(
                "div",
                {
                  class: "video-bottom-row",
                  onClick:
                    t[0] ||
                    (t[0] = (...r) => e.handleClick && e.handleClick(...r)),
                },
                [
                  je(
                    "div",
                    xl,
                    Ot(e.renderState.assets.ctaText.toUpperCase()),
                    1
                  ),
                ]
              ),
            ]),
            _: 1,
          },
          8,
          ["style"]
        ),
      ],
      2
    )
  );
}
const _l = We(bl, [["render", Sl]]),
  Cl = 300 / 450,
  El = Ze({
    emits: ["click"],
    setup(e, t) {
      const n = Ye(),
        o = Kt(),
        a = ct({ verticalVideo: o.height * Cl > o.width });
      function f() {
        qe.debug("click from source: outstreamText"),
          t.emit("click", "outstreamText");
      }
      return { state: a, renderState: n, handleClick: f };
    },
  }),
  kl = { class: "video-cta" };
function Tl(e, t, n, o, a, f) {
  const c = Se("MediaPartFixed"),
    s = Se("TextPart");
  return (
    Ae(),
    Fe(
      "div",
      {
        id: "layout-video-wide",
        style: ye(e.renderState.styles.layout),
        class: Pt(e.renderState.hasValidMedia ? "hasValidMedia" : ""),
      },
      [
        t[1] || (t[1] = je("div", { id: "spacer" }, null, -1)),
        Ee(
          c,
          {
            onClick: e.renderState.handleClick,
            style: ye(e.renderState.styles.mediaPart),
            borderSide: "",
            height: 1,
            width: 445 / 970,
          },
          null,
          8,
          ["onClick", "style"]
        ),
        Ee(
          s,
          { style: ye(e.renderState.styles.textPart) },
          {
            default: bt(() => [
              je(
                "div",
                {
                  class: "video-bottom-row",
                  onClick:
                    t[0] ||
                    (t[0] = (...r) => e.handleClick && e.handleClick(...r)),
                },
                [
                  je(
                    "div",
                    kl,
                    Ot(e.renderState.assets.ctaText.toUpperCase()),
                    1
                  ),
                ]
              ),
            ]),
            _: 1,
          },
          8,
          ["style"]
        ),
      ],
      6
    )
  );
}
const Pl = We(El, [["render", Tl]]),
  Al = 2,
  Il = Ze({
    setup() {
      const e = Ye();
      return {
        state: ct({ titleLines: e.assets.description ? 1 : Al }),
        renderState: e,
      };
    },
  }),
  Ol = { class: "top-row" },
  Bl = { class: "bottom-row" },
  Rl = ["src"];
function Fl(e, t, n, o, a, f) {
  const c = Se("MediaPartFixed"),
    s = Se("Title"),
    r = Se("Description"),
    l = Se("AdLabel"),
    d = Se("Disclaimer"),
    w = Se("Cta"),
    S = Se("TextPart");
  return (
    Ae(),
    Fe(
      "div",
      { id: "layout-wide", style: ye(e.renderState.styles.layout) },
      [
        Ee(
          c,
          {
            onClick: e.renderState.handleClick,
            style: ye(e.renderState.styles.mediaPart),
            borderSide: "right",
            height: 1,
            width: 474 / 970,
          },
          null,
          8,
          ["onClick", "style"]
        ),
        Ee(
          S,
          {
            onClick: e.renderState.handleClick,
            style: ye(e.renderState.styles.textPart),
          },
          {
            default: bt(() => [
              je("div", Ol, [
                Ee(
                  s,
                  {
                    text: e.renderState.assets.title,
                    style: ye(e.renderState.styles.title),
                    maxLines: 2,
                  },
                  null,
                  8,
                  ["text", "style"]
                ),
                Ee(
                  r,
                  {
                    text: e.renderState.assets.description,
                    style: ye(e.renderState.styles.description),
                  },
                  null,
                  8,
                  ["text", "style"]
                ),
              ]),
              je("div", Bl, [
                e.renderState.assets.iconUrl
                  ? (Ae(),
                    Fe(
                      "img",
                      {
                        key: 0,
                        src: e.renderState.assets.iconUrl,
                        alt: "background.img",
                      },
                      null,
                      8,
                      Rl
                    ))
                  : Ve("", !0),
                e.renderState.assets.iconUrl
                  ? Ve("", !0)
                  : (Ae(), tt(l, { key: 1 })),
                Ee(
                  d,
                  {
                    text: e.renderState.assets.disclaimer,
                    style: ye(e.renderState.styles.disclaimer),
                  },
                  null,
                  8,
                  ["text", "style"]
                ),
                Ee(
                  w,
                  {
                    text: e.renderState.assets.ctaText,
                    style: ye(e.renderState.styles.cta),
                    showOverflowIcon: !0,
                    iconWidth: 20,
                  },
                  null,
                  8,
                  ["text", "style"]
                ),
              ]),
            ]),
            _: 1,
          },
          8,
          ["onClick", "style"]
        ),
      ],
      4
    )
  );
}
const jl = We(Il, [["render", Fl]]),
  Ll = Ze({
    props: {
      privacyUrl: { type: String },
      size: { type: Number, default: 16 },
    },
    setup(e, t) {
      const n = Ye(),
        o = ct({ size: e.size, showIcon: fn(e.privacyUrl) });
      function a() {
        qe.debug("click from source: adchoices"), t.emit("click", "adchoices");
      }
      return {
        state: o,
        handleClick: a,
        renderState: n,
        hasValidVideo: n && n.hasValidVideo ? n.hasValidVideo : !1,
      };
    },
  }),
  Ml = ["height"];
function Dl(e, t, n, o, a, f) {
  return e.state.showIcon
    ? (Ae(),
      Fe(
        "div",
        {
          key: 0,
          class: "asset-adchoices",
          style: ye({
            "--top-position": e.hasValidVideo ? "0px" : "1px",
            "--right-position": e.hasValidVideo ? "0px" : "1px",
          }),
        },
        [
          (Ae(),
          Fe(
            "svg",
            {
              onClick:
                t[0] ||
                (t[0] = ur(
                  (...c) => e.handleClick && e.handleClick(...c),
                  ["stop"]
                )),
              height: e.state.size,
              viewBox: ".2 0 19.4 20",
              width: "16",
              xmlns: "http://www.w3.org/2000/svg",
              style: ye({
                "--background-color": e.hasValidVideo ? "#CCC" : "white",
                "--border-radius": e.hasValidVideo ? "5px" : "0px",
                "--opacity-percentage": e.hasValidVideo ? "60%" : "100%",
              }),
            },
            t[1] ||
              (t[1] = [
                je(
                  "path",
                  {
                    d: "m2.2 20c1 0 1.7-.5 2.4-.9.6-.3 1.2-.7 1.9-1 3.2-1.7 6.4-3.5 9.6-5.3 1-.5 2.3-1 3-1.9.2-.3.5-.7.4-1.2-.3-1.1-1.7-1.5-2.6-2-2.2-1.2-4.5-2.5-6.7-3.7-.8-.5-2-1.4-3-.7-.4.2-.6.4-.7.7-.1.4 0 .9 0 1.3v3.2c0 .9-.1 1.6.5 2 .2.1.6.2.9.1 1-.4.7-2.2.7-3.6v-1.1c1.7.9 3.4 1.8 5.1 2.6.6.3 1.6.6 1.8 1.4.2.9-1.7 1.6-2.3 1.9l-6.9 3.9c-.5.3-1.8 1.3-2.6 1-.3-.1-.5-.4-.5-.6-.1-.4-.1-1-.1-1.5v-3.2-5.4c0-.8-.1-1.8.2-2.3.7-1 2.3.8 2.8-.8.1-.4-.1-.8-.3-1-.4-.6-2.2-1.5-2.9-1.7-.2-.1-.7-.2-1-.2-1.7.3-1.3 3-1.3 5v9.9c0 1.5-.2 3.5.4 4.4.3.5.6.5 1.2.7zm5.2-6.5c1.5 0 1.6-1.9.2-2.2-.8-.1-1.4.7-1.2 1.4.2.5.5.6 1 .8z",
                  },
                  null,
                  -1
                ),
              ]),
            12,
            Ml
          )),
        ],
        4
      ))
    : Ve("", !0);
}
const $l = We(Ll, [
    ["render", Dl],
    ["__scopeId", "data-v-05e566f5"],
  ]),
  Ul = Ze({
    setup() {
      const e = gc();
      return { text: kc[e] };
    },
  }),
  Nl = { class: "ad-label" };
function Vl(e, t, n, o, a, f) {
  return Ae(), Fe("div", Nl, Ot(e.text), 1);
}
const Hl = We(Ul, [["render", Vl]]),
  Zl = Ze({
    props: {
      text: { type: String },
      showOverflowIcon: { type: Boolean },
      iconWidth: { type: Number },
    },
    setup(e) {
      const t = Lt(null),
        n = Lt(!1);
      return (
        on(() => {
          if (t.value) {
            const o = t.value.offsetWidth,
              a = t.value.scrollWidth;
            o < a && e.showOverflowIcon && (n.value = !0);
          }
        }),
        {
          text: e.text ? e.text.trim() : e.text,
          iconWidth: e.iconWidth,
          ctaRef: t,
          hasOverflow: n,
        }
      );
    },
  });
function Wl(e, t, n, o, a, f) {
  return e.hasOverflow
    ? (Ae(),
      Fe(
        "div",
        {
          key: 1,
          class: "asset-cta asset-cta-button",
          style: ye({ "--icon-width": `${e.iconWidth}px` }),
        },
        t[0] ||
          (t[0] = [
            je(
              "svg",
              {
                viewBox: "0 0 17 18",
                fill: "none",
                xmlns: "http://www.w3.org/2000/svg",
              },
              [
                je("path", {
                  d: "M9.11328 8.3516L2.23828 1.1641C1.88242 0.790666 1.28906 0.776994 0.914453 1.13481C0.721484 1.31918 0.625 1.56567 0.625 1.81215C0.625 2.04531 0.71168 2.27856 0.885 2.4602L7.14062 9.00004L0.886719 15.5391C0.530273 15.9139 0.54125 16.5071 0.916016 16.8649C1.29078 17.2225 1.88398 17.2091 2.2418 16.8356L9.1168 9.64809C9.46094 9.2852 9.46094 8.71488 9.11328 8.3516ZM16.6133 8.3516L9.73828 1.1641C9.38281 0.790666 8.78906 0.776994 8.41406 1.13481C8.22266 1.31918 8.125 1.56567 8.125 1.81215C8.125 2.04531 8.21168 2.27856 8.385 2.4602L14.6406 9.00004L8.38672 15.5391C8.03027 15.9139 8.04125 16.5071 8.41602 16.8649C8.79078 17.2225 9.38398 17.2091 9.7418 16.8356L16.6168 9.64809C16.9609 9.2852 16.9609 8.71488 16.6133 8.3516Z",
                  fill: "#1262EB",
                }),
              ],
              -1
            ),
          ]),
        4
      ))
    : (Ae(),
      Fe(
        "div",
        { key: 0, ref: "ctaRef", class: "asset-cta" },
        Ot(e.text),
        513
      ));
}
const ql = We(Zl, [["render", Wl]]),
  zl = Ze({
    props: { text: { type: String }, maxLines: { type: Number, default: 2 } },
  });
function Kl(e, t, n, o, a, f) {
  return (
    Ae(),
    Fe(
      "div",
      {
        class: "asset-description",
        style: ye({ "--max-lines": e.maxLines.toString() }),
      },
      Ot(e.text),
      5
    )
  );
}
const Gl = We(zl, [["render", Kl]]),
  Xl = Ze({
    setup(e) {
      return { renderState: Ye(), text: e.text ? e.text.trim() : "" };
    },
    props: { text: { type: String } },
  }),
  Jl = { class: "asset-disclaimer" };
function Yl(e, t, n, o, a, f) {
  return Ae(), Fe("div", Jl, Ot(e.text), 1);
}
const Ql = We(Xl, [["render", Yl]]),
  ef = 1,
  Gi = 2,
  tf = Ze({
    props: {
      height: { type: Number, required: !0 },
      width: { type: Number, required: !0 },
      borderSide: { type: String, required: !0 },
    },
    emits: ["click", "size-change"],
    setup(e, { emit: t }) {
      const n = Kt(),
        o = Ye(),
        a = n.width * e.width - (e.borderSide === "right" ? Gi : 0),
        f = n.height * e.height - (e.borderSide === "bottom" ? Gi : 0);
      function c() {
        o.hasValidVideo ||
          (qe.debug("click from source: image"), t("click", "image"));
      }
      return {
        renderState: o,
        handleClick: c,
        containerHeight: f,
        containerWidth: a,
        borderWidth: ef,
        borderSide: e.borderSide,
      };
    },
  }),
  nf = ["src"],
  rf = ["src"];
function of(e, t, n, o, a, f) {
  const c = Se("VideoPlayer");
  return e.renderState.hasValidMedia
    ? (Ae(),
      Fe(
        "div",
        {
          key: 0,
          id: "media-part",
          onClick:
            t[0] ||
            (t[0] = ur(
              (...s) => e.handleClick && e.handleClick(...s),
              ["stop"]
            )),
          style: ye({
            "--height": e.containerHeight + "px",
            "--width": e.containerWidth + "px",
            "--border-bottom-width":
              e.borderSide === "bottom" ? `${e.borderWidth}px` : "0px",
            "--border-right-width":
              e.borderSide === "right" ? `${e.borderWidth}px` : "0px",
          }),
        },
        [
          e.renderState.hasValidImage && !e.renderState.hasValidVideo
            ? (Ae(),
              Fe(
                "img",
                {
                  key: 0,
                  class: "background",
                  src: e.renderState.assets.imageUrl,
                  alt: "background.img",
                },
                null,
                8,
                nf
              ))
            : Ve("", !0),
          e.renderState.hasValidImage && !e.renderState.hasValidVideo
            ? (Ae(),
              Fe(
                "img",
                {
                  key: 1,
                  class: "foreground",
                  src: e.renderState.assets.imageUrl,
                  alt: "background.img",
                },
                null,
                8,
                rf
              ))
            : Ve("", !0),
          e.renderState.hasValidVideo
            ? (Ae(),
              tt(
                c,
                {
                  key: 2,
                  id: "video-root",
                  width: e.containerWidth,
                  height: e.containerHeight,
                },
                null,
                8,
                ["width", "height"]
              ))
            : Ve("", !0),
        ],
        4
      ))
    : Ve("", !0);
}
const sf = We(tf, [["render", of]]),
  af = 1,
  uf = 2,
  cf = Ze({
    props: {
      fill: { type: String, required: !0 },
      aspectRatio: { type: Number, required: !0 },
    },
    emits: ["click", "size-change"],
    setup(e, { emit: t }) {
      const n = Kt(),
        o = Ye(),
        a = o.hasValidVideo ? 0 : af,
        f = a * uf,
        c = Lt(null),
        s = Lt(null);
      let r = n.width - f,
        l = n.height - f;
      e.fill === "width"
        ? (l = (n.width - f) / e.aspectRatio + a)
        : (r = (n.height - f) * e.aspectRatio + a);
      const d = Lt(r),
        w = Lt(l);
      on(() => {
        if (!c.value) return;
        const x = new Image();
        (x.src = o.assets.imageUrl),
          (x.onload = () => {
            const E = c.value;
            (E.src = o.assets.imageUrl), (s.value.src = o.assets.imageUrl);
            const I = x.naturalWidth / x.naturalHeight;
            if (e.fill === "width") {
              if (I >= e.aspectRatio) {
                const k = (n.width - f) / x.naturalWidth;
                w.value = x.naturalHeight * k + a;
              }
            } else if (I <= e.aspectRatio) {
              const k = (n.height - f) / x.naturalHeight;
              d.value = x.naturalWidth * k + a;
            }
          });
      });
      function S() {
        o.hasValidVideo ||
          (qe.debug("click from source: image"), t("click", "image"));
      }
      return {
        imgRef: c,
        bgRef: s,
        renderState: o,
        handleClick: S,
        containerHeight: w,
        containerWidth: d,
        borderWidth: a,
      };
    },
  }),
  lf = {
    key: 0,
    class: "background",
    ref: "bgRef",
    src: "data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==",
    alt: "background img",
  },
  ff = {
    key: 1,
    class: "foreground",
    ref: "imgRef",
    src: "data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==",
    alt: "foreground img",
  };
function df(e, t, n, o, a, f) {
  const c = Se("VideoPlayer");
  return e.renderState.hasValidMedia
    ? (Ae(),
      Fe(
        "div",
        {
          key: 0,
          id: "media-part",
          onClick:
            t[0] ||
            (t[0] = ur(
              (...s) => e.handleClick && e.handleClick(...s),
              ["stop"]
            )),
          style: ye({
            "--height": e.containerHeight + "px",
            "--width": e.containerWidth + "px",
            "--border-bottom-width":
              e.fill === "width" ? `${e.borderWidth}px` : "0px",
            "--border-right-width":
              e.fill === "height" ? `${e.borderWidth}px` : "0px",
          }),
        },
        [
          e.renderState.hasValidImage && !e.renderState.hasValidVideo
            ? (Ae(), Fe("img", lf, null, 512))
            : Ve("", !0),
          e.renderState.hasValidImage && !e.renderState.hasValidVideo
            ? (Ae(), Fe("img", ff, null, 512))
            : Ve("", !0),
          e.renderState.hasValidVideo
            ? (Ae(),
              tt(
                c,
                {
                  key: 2,
                  id: "video-root",
                  width: e.containerWidth,
                  height: e.containerHeight,
                },
                null,
                8,
                ["width", "height"]
              ))
            : Ve("", !0),
        ],
        4
      ))
    : Ve("", !0);
}
const hf = We(cf, [["render", df]]),
  pf = Ze({
    emits: ["click", "size-change"],
    setup(e, t) {
      const n = Ye(),
        o = Lt(null),
        a = bc(o),
        f = ct({
          classes: {
            "with-media": lt(() => n.hasValidMedia),
            "text-only": lt(() => !n.hasValidMedia),
          },
        });
      vn(a, () => t.emit("size-change", a));
      function c() {
        qe.debug("click from source: text"), t.emit("click", "text");
      }
      return { elementRef: o, state: f, handleClick: c };
    },
  });
function gf(e, t, n, o, a, f) {
  return (
    Ae(),
    Fe(
      "div",
      {
        id: "text-part",
        ref: "elementRef",
        onClick:
          t[0] ||
          (t[0] = ur((...c) => e.handleClick && e.handleClick(...c), ["stop"])),
        class: Pt(e.state.classes),
      },
      [Sa(e.$slots, "default")],
      2
    )
  );
}
const mf = We(pf, [["render", gf]]),
  yf = Ze({
    props: { text: { type: String }, maxLines: { type: Number, default: 1 } },
  });
function vf(e, t, n, o, a, f) {
  return (
    Ae(),
    Fe(
      "div",
      {
        class: "asset-title",
        style: ye({ "--max-lines": e.maxLines.toString() }),
      },
      Ot(e.text),
      5
    )
  );
}
const wf = We(yf, [["render", vf]]),
  hs = 480,
  ps = 270;
window.createIXPlayer = (e, t, n) => {
  var r, l, d, w, S, x, E, I, k;
  typeof t.vastXml == "string" &&
    (t.vastXml = t.vastXml.replaceAll("__IXRENDEREDBYPUB__", "IXPLAYER"));
  const o = Object.assign(
      {
        floating:
          (d =
            (l =
              (r = t == null ? void 0 : t.params[0]) == null
                ? void 0
                : r.video) == null
              ? void 0
              : l.playerConfig) == null
            ? void 0
            : d.floatOnScroll,
        autostart:
          (x =
            (S =
              (w = t == null ? void 0 : t.params[0]) == null
                ? void 0
                : w.video) == null
              ? void 0
              : S.playerConfig) == null
            ? void 0
            : x.autostart,
        endState:
          (k =
            (I =
              (E = t == null ? void 0 : t.params[0]) == null
                ? void 0
                : E.video) == null
              ? void 0
              : I.playerConfig) == null
            ? void 0
            : k.endState,
      },
      n
    ),
    { playerConfig: a, width: f, height: c } = gs(t, o),
    s = window.jwplayer(e).setup(a);
  return bf(s, t, e, a.autoPause.viewability, f, c), s;
};
window.IXOutstreamPlayer = (e, t, n) => {
  const o = { width: n.width || hs, height: n.height || ps, params: [] };
  if (!document.getElementById(t)) {
    const s = t,
      r = googletag
        .pubads()
        .getSlots()
        .find((l) => l.getAdUnitPath() === s);
    if (r) t = r.getSlotElementId();
    else {
      console.error(
        `IX Outstream Player: No GPT slot found for ad unit path: ${s}`
      );
      return;
    }
  }
  return (
    new DOMParser()
      .parseFromString(e, "text/xml")
      .getElementsByTagName("parsererror").length === 0
      ? (o.vastXml = e.replaceAll("__IXRENDEREDBYPUB__", "IXPLAYER"))
      : (o.vastUrl = e),
    window.createIXPlayer(t, o, {})
  );
};
function gs(e, t = {}) {
  let n = e.width && e.width >= 144 ? e.width : hs,
    o = e.height && e.height >= 144 ? e.height : ps;
  const a = {
      width: n,
      height: o,
      autoPause: { viewability: !0, pauseAds: !0 },
      advertising: {
        client: "vast",
        outstream: !0,
        endstate: t.endState || "close",
        tag: e.vastXml ? void 0 : e.vastUrl,
        vastxml: e.vastXml,
      },
      controls: !0,
      aspectratio: "16:9",
      autostart: t.autostart || "viewable",
      displaydescription: !1,
      displaytitle: !1,
      mute: !0,
      ph: 1,
      playbackRateControls: !1,
      preload: "metadata",
      stretching: "uniform",
      repeat: "false",
    },
    f = $r(a, t);
  return (
    (f.doNotSaveCookies = !0),
    (f.key = "PHnn7tfF5BRcZ+A71I4JpMf0PvkRDpAraaXX98Q/+YCIdSco"),
    (f.floating = t.floating ? { dismissible: !0 } : void 0),
    (f.pid = "jJgzYVkv"),
    { playerConfig: $r(a, t), width: n, height: o }
  );
}
function $r(e, t) {
  for (let n in t)
    t.hasOwnProperty(n) &&
      (typeof t[n] == "object" && t[n] !== null
        ? (e[n] = $r(e[n], t[n]))
        : (e[n] = t[n]));
  return e;
}
function bf(e, t, n, o, a, f) {
  var w, S, x, E, I, k, b, g, _;
  const c = window.innerWidth,
    s =
      (x =
        (S =
          (w = t == null ? void 0 : t.params[0]) == null ? void 0 : w.video) ==
        null
          ? void 0
          : S.playerConfig) == null
        ? void 0
        : x.floatSize,
    r =
      (k =
        (I =
          (E = t == null ? void 0 : t.params[0]) == null ? void 0 : E.video) ==
        null
          ? void 0
          : I.playerConfig) == null
        ? void 0
        : k.endState,
    l =
      (_ =
        (g =
          (b = t == null ? void 0 : t.params[0]) == null ? void 0 : b.video) ==
        null
          ? void 0
          : g.playerConfig) == null
        ? void 0
        : _.dynamicResize;
  s &&
    s.every((m) => typeof m == "number") &&
    e.on("float", (m) => {
      m.floating ? e.resize(s[0], s[1]) : e.resize(a, f);
    }),
    (l || typeof l > "u") &&
      (e.on("ready", (m) => {
        const v = document.querySelector("div.jw-wrapper.jw-reset");
        v && (v.style.background = "transparent");
      }),
      e.on("adPlay", () => {
        Xi(e),
          e.on("resize", (m) => {
            m.width === 1 || m.height === 1 || Xi(e);
          });
      }),
      window.addEventListener("resize", () => {
        const m = window.innerWidth;
        e && m >= c * 0.25 && e.resize(a, f);
      })),
    r === "close_with_scroll" && xf(e, n, o);
}
function Xi(e) {
  const t = document.querySelector(
      "div.jw-wrapper.jw-reset > div.jw-media.jw-reset > video"
    ),
    n = document.querySelector("div.jw-wrapper.jw-reset");
  if (!t || !n) return;
  (t.style.height = "unset"),
    (t.style.width = "unset"),
    (n.style.background = "transparent");
  const o = t.clientHeight,
    a = t.clientWidth,
    f = n.clientHeight,
    c = n.clientWidth,
    s = f / o,
    r = c / a;
  s > r ? e.resize(c, o * r) : e.resize(a * s, f);
}
function xf(e, t, n) {
  e.on("adComplete", () => {
    const o = document.getElementById(t);
    if (!o) return;
    const a = o.getBoundingClientRect(),
      f = window.innerHeight,
      c = a.bottom >= 0 && a.bottom <= f,
      s = window.innerHeight / 2,
      r = a.bottom < s,
      l = o.clientHeight;
    (o.style.height = "0px"),
      (o.style.overflow = "hidden"),
      (o.style.display = "none");
    const d = document.body.style.overflow;
    (document.body.style.overflow = "hidden"),
      ((r && c) || (!n && r)) &&
        window.scrollTo({ top: window.scrollY - l, left: 0, behavior: "auto" }),
      (document.body.style.overflow = d);
  });
}
(function () {
  var e,
    t,
    n = {
      696: function (c, s) {
        s.Z = {
          advertising: {
            admessage: "This ad will end in xx",
            cuetext: "Advertisement",
            displayHeading: "Advertisement",
            loadingAd: "Loading ad",
            podmessage: "Ad __AD_POD_CURRENT__ of __AD_POD_LENGTH__.",
            skipmessage: "Skip ad in xx",
            skiptext: "Skip",
          },
          airplay: "AirPlay",
          audioTracks: "Audio Tracks",
          auto: "Auto",
          buffer: "Loading",
          cast: "Chromecast",
          cc: "Closed Captions",
          close: "Close",
          errors: {
            badConnection:
              "This video cannot be played because of a problem with your internet connection.",
            cantLoadPlayer: "Sorry, the video player failed to load.",
            cantPlayInBrowser: "The video cannot be played in this browser.",
            cantPlayVideo: "This video file cannot be played.",
            errorCode: "Error Code",
            liveStreamDown: "The live stream is either down or has ended.",
            protectedContent:
              "There was a problem providing access to protected content.",
            technicalError:
              "This video cannot be played because of a technical error.",
          },
          exitFullscreen: "Exit Fullscreen",
          fullscreen: "Fullscreen",
          hd: "Quality",
          liveBroadcast: "Live",
          logo: "Logo",
          mute: "Mute",
          next: "Next",
          nextUp: "Next Up",
          notLive: "Not Live",
          off: "Off",
          pause: "Pause",
          pipIcon: "Picture in Picture (PiP)",
          play: "Play",
          playback: "Play",
          playbackRates: "Playback Rates",
          player: "Video Player",
          poweredBy: "Powered by",
          prev: "Previous",
          related: { autoplaymessage: "Next up in xx", heading: "More Videos" },
          replay: "Replay",
          rewind: "Rewind 10 Seconds",
          settings: "Settings",
          sharing: {
            copied: "Copied",
            email: "Email",
            embed: "Embed",
            heading: "Share",
            link: "Link",
          },
          slider: "Seek",
          stop: "Stop",
          unmute: "Unmute",
          videoInfo: "About This Video",
          volume: "Volume",
          volumeSlider: "Volume",
          shortcuts: {
            playPause: "Play/Pause",
            volumeToggle: "Mute/Unmute",
            fullscreenToggle: "Fullscreen/Exit Fullscreen",
            seekPercent: "Seek %",
            keyboardShortcuts: "Keyboard Shortcuts",
            increaseVolume: "Increase Volume",
            decreaseVolume: "Decrease Volume",
            seekForward: "Seek Forward",
            seekBackward: "Seek Backward",
            spacebar: "SPACE",
            captionsToggle: "Captions On/Off",
          },
          captionsStyles: {
            subtitleSettings: "Subtitle Settings",
            color: "Font Color",
            fontOpacity: "Font Opacity",
            userFontScale: "Font Size",
            fontFamily: "Font Family",
            edgeStyle: "Character Edge",
            backgroundColor: "Background Color",
            backgroundOpacity: "Background Opacity",
            windowColor: "Window Color",
            windowOpacity: "Window Opacity",
            white: "White",
            black: "Black",
            red: "Red",
            green: "Green",
            blue: "Blue",
            yellow: "Yellow",
            magenta: "Magenta",
            cyan: "Cyan",
            none: "None",
            raised: "Raised",
            depressed: "Depressed",
            uniform: "Uniform",
            dropShadow: "Drop Shadow",
          },
          disabled: "Disabled",
          enabled: "Enabled",
          reset: "Reset",
        };
      },
      9128: function (c, s, r) {
        function l(d, w, S) {
          var x = [],
            E = {};
          function I() {
            for (; x.length > 0; ) {
              var k = x.shift(),
                b = k.command,
                g = k.args;
              (E[b] || d[b]).apply(d, g);
            }
          }
          w.forEach(function (k) {
            var b = d[k];
            (E[k] = b),
              (d[k] = function () {
                for (
                  var g = arguments.length, _ = new Array(g), m = 0;
                  m < g;
                  m++
                )
                  _[m] = arguments[m];
                S()
                  ? x.push({ command: k, args: _ })
                  : (I(), b && b.apply(this, _));
              });
          }),
            Object.defineProperty(this, "queue", {
              enumerable: !0,
              get: function () {
                return x;
              },
            }),
            (this.flush = I),
            (this.empty = function () {
              x.length = 0;
            }),
            (this.off = function () {
              w.forEach(function (k) {
                var b = E[k];
                b && ((d[k] = b), delete E[k]);
              });
            }),
            (this.destroy = function () {
              this.off(), this.empty();
            });
        }
        r.d(s, {
          Z: function () {
            return l;
          },
        });
      },
      4742: function (c, s) {
        s.Z = { debug: !1 };
      },
      5191: function (c, s, r) {
        function l(w) {
          return w.slice && w.slice(-2) === "px" && (w = w.slice(0, -2)), w;
        }
        function d(w, S) {
          if (S.toString().indexOf("%") === -1 || typeof w != "string" || !w)
            return 0;
          if (/^\d*\.?\d+%$/.test(w)) return w;
          var x = w.indexOf(":");
          if (x === -1) return 0;
          var E = parseFloat(w.substr(0, x)),
            I = parseFloat(w.substr(x + 1));
          return E <= 0 || I <= 0 ? 0 : (I / E) * 100 + "%";
        }
        r.d(s, {
          a: function () {
            return l;
          },
          R: function () {
            return d;
          },
        });
      },
      5083: function (c, s, r) {
        r.d(s, {
          ke: function () {
            return k;
          },
          G0: function () {
            return b;
          },
        });
        var l = r(6042),
          d = r(5191),
          w = r(1569),
          S = r(9888),
          x = r(8348),
          E = r(696),
          I = r(8518),
          k = {
            autoPause: { viewability: !1, pauseAds: !1 },
            autostart: !1,
            allowFullscreen: !0,
            bandwidthEstimate: null,
            bitrateSelection: null,
            castAvailable: !1,
            controls: !0,
            cues: [],
            defaultPlaybackRate: 1,
            displaydescription: !0,
            displaytitle: !0,
            displayPlaybackLabel: !1,
            enableShortcuts: !0,
            height: 360,
            intl: {},
            item: 0,
            language: "en",
            liveTimeout: null,
            localization: E.Z,
            mute: !1,
            nextUpDisplay: !0,
            playbackRateControls: !1,
            playbackRates: [0.5, 1, 1.25, 1.5, 2],
            renderCaptionsNatively: !1,
            repeat: !1,
            stretching: "uniform",
            volume: 90,
            width: 640,
          };
        function b(g) {
          return g < 5 ? 5 : g;
        }
        s.ZP = function (g, _) {
          var m = (0, l.l7)({}, (window.jwplayer || {}).defaults, _, g);
          (function (se) {
            Object.keys(se).forEach(function (xe) {
              xe !== "id" && (se[xe] = (0, S.serialize)(se[xe]));
            });
          })(m);
          var v = m.forceLocalizationDefaults ? k.language : (0, I.G3)(),
            A = (0, I.tK)(m.intl);
          m.localization = (0, I.Mh)(E.Z, (0, I.Pm)(m, A, v));
          var T = (0, l.l7)({}, k, m);
          T.base === "." && (T.base = (0, w.getScriptPath)("jwplayer.js")),
            (T.base = (T.base || (0, w.loadFrom)()).replace(/\/?$/, "/")),
            (r.p = T.base),
            (T.width = (0, d.a)(T.width)),
            (T.height = (0, d.a)(T.height)),
            (T.aspectratio = (0, d.R)(T.aspectratio, T.width)),
            (T.volume = (0, l.qh)(T.volume)
              ? Math.min(Math.max(0, T.volume), 100)
              : k.volume),
            (T.mute = !!T.mute),
            (T.language = v),
            (T.intl = A);
          var j = T.playlistIndex;
          j && (T.item = j), (0, l.hj)(T.item) || (T.item = 0);
          var L = m.autoPause;
          L &&
            (T.autoPause.viewability =
              !("viewability" in L) || !!L.viewability);
          var M = T.playbackRateControls;
          if (M) {
            var q = T.playbackRates;
            Array.isArray(M) && (q = M),
              (q = q
                .filter(function (se) {
                  return (0, l.hj)(se) && se >= 0.25 && se <= 4;
                })
                .map(function (se) {
                  return Math.round(100 * se) / 100;
                })).indexOf(1) < 0 && q.push(1),
              q.sort(),
              (T.playbackRateControls = !0),
              (T.playbackRates = q);
          }
          (!T.playbackRateControls ||
            T.playbackRates.indexOf(T.defaultPlaybackRate) < 0) &&
            (T.defaultPlaybackRate = 1),
            (T.playbackRate = T.defaultPlaybackRate),
            T.aspectratio || delete T.aspectratio;
          var W = T.playlist;
          if (W)
            Array.isArray(W.playlist) &&
              ((T.feedData = W), (T.playlist = W.playlist));
          else {
            var ie = (0, l.ei)(T, [
              "title",
              "description",
              "type",
              "mediaid",
              "image",
              "images",
              "file",
              "sources",
              "tracks",
              "preload",
              "duration",
            ]);
            T.playlist = [ie];
          }
          (T.qualityLabels = T.qualityLabels || T.hlslabels), delete T.duration;
          var ne = T.liveTimeout;
          ne !== null &&
            ((0, l.qh)(ne) ? ne !== 0 && (ne = Math.max(30, ne)) : (ne = null),
            (T.liveTimeout = ne));
          var de,
            he,
            $ = parseFloat(T.bandwidthEstimate),
            D = parseFloat(T.bitrateSelection);
          return (
            (T.bandwidthEstimate = (0, l.qh)($)
              ? $
              : ((de = T.defaultBandwidthEstimate),
                (he = parseFloat(de)),
                (0, l.qh)(he) ? Math.max(he, 1) : k.bandwidthEstimate)),
            (T.bitrateSelection = (0, l.qh)(D) ? D : k.bitrateSelection),
            (T.liveSyncDuration = b(T.liveSyncDuration)),
            (T.backgroundLoading = (0, l.jn)(T.backgroundLoading)
              ? T.backgroundLoading
              : x.Features.backgroundLoading),
            T
          );
        };
      },
      2894: function (c, s, r) {
        r.d(s, {
          Tr: function () {
            return d;
          },
          Ep: function () {
            return w;
          },
          Jt: function () {
            return S;
          },
          Zq: function () {
            return x;
          },
        });
        var l = r(4446),
          d = {};
        function w(E, I) {
          return function () {
            throw new l.rG(l.pJ, E, I);
          };
        }
        function S(E, I) {
          return function () {
            throw new l.rG(null, E, I);
          };
        }
        function x() {
          return r
            .e(681)
            .then(
              function (E) {
                return r(7573).default;
              }.bind(null, r)
            )
            .catch(w(l.fU + 101));
        }
      },
      623: function (c, s, r) {
        r.d(s, {
          Z: function () {
            return ge;
          },
          c: function () {
            return le;
          },
        });
        var l = r(6042),
          d = r(9128),
          w = r(2445),
          S = r(2894),
          x = r(393),
          E = r(8320),
          I = r(2963),
          k = r(670),
          b = r(4601),
          g = r(4446),
          _ = r(8348),
          m = null;
        function v(Z) {
          return (
            m ||
              (m = (function (p) {
                var i = p.get("controls"),
                  u = A(),
                  h = (function (C, B) {
                    var ee = C.get("playlist");
                    if (Array.isArray(ee) && ee.length)
                      for (
                        var V = (0, E.bx)(C.get("item"), ee.length),
                          H = (0, E.T5)((0, x.Z)(ee[V]), C),
                          ue = 0;
                        ue < H.length;
                        ue++
                      )
                        for (
                          var be = H[ue], Ge = C.getProviders(), Re = 0;
                          Re < I.B.length;
                          Re++
                        ) {
                          var Ne = I.B[Re];
                          if (Ge.providerSupports(Ne, be)) return Ne.name === B;
                        }
                    return !1;
                  })(p, "html5");
                if (_.OS.tizen) return T();
                if (i && u && h)
                  return (
                    (y = r
                      .e(605)
                      .then(
                        function (C) {
                          r(6337);
                          var B = r(7573).default;
                          return (
                            (b.v.controls = r(6867).default),
                            (0, k.Z)(r(9181).default),
                            B
                          );
                        }.bind(null, r)
                      )
                      .catch((0, S.Ep)(g.fU + 105))),
                    (S.Tr.html5 = y),
                    y
                  );
                var y;
                return i && h
                  ? (function () {
                      var C = r
                        .e(207)
                        .then(
                          function (B) {
                            var ee = r(7573).default;
                            return (
                              (b.v.controls = r(6867).default),
                              (0, k.Z)(r(9181).default),
                              ee
                            );
                          }.bind(null, r)
                        )
                        .catch((0, S.Ep)(g.fU + 104));
                      return (S.Tr.html5 = C), C;
                    })()
                  : i && u
                  ? r
                      .e(493)
                      .then(
                        function (C) {
                          r(6337);
                          var B = r(7573).default;
                          return (b.v.controls = r(6867).default), B;
                        }.bind(null, r)
                      )
                      .catch((0, S.Ep)(g.fU + 103))
                  : i
                  ? r
                      .e(581)
                      .then(
                        function (C) {
                          var B = r(7573).default;
                          return (b.v.controls = r(6867).default), B;
                        }.bind(null, r)
                      )
                      .catch((0, S.Ep)(g.fU + 102))
                  : T();
              })(Z)),
            m
          );
        }
        function A() {
          var Z = window.IntersectionObserverEntry;
          return (
            !Z ||
            !("IntersectionObserver" in window) ||
            !("intersectionRatio" in Z.prototype)
          );
        }
        function T() {
          return (function () {
            return A()
              ? r
                  .e(943)
                  .then(
                    function (Z) {
                      return r(6337);
                    }.bind(null, r)
                  )
                  .catch((0, S.Ep)(g.fU + 120))
              : Promise.resolve();
          })().then(S.Zq);
        }
        var j = r(1643),
          L = r(7263),
          M = r(676),
          q = r(8518),
          W = r(1241);
        function ie(Z) {
          var p = Z.get("playlist");
          return new Promise(function (i, u) {
            if (typeof p != "string") {
              var h = Z.get("feedData") || {};
              return ne(Z, p, h), i();
            }
            var y = new L.Z();
            y.on(j.Ow, function (C) {
              var B = C.playlist;
              delete C.playlist, ne(Z, B, C), i();
            }),
              y.on(j.pn, function (C) {
                ne(Z, [], {}), u((0, g.l9)(C, g.xk));
              }),
              y.load(p);
          });
        }
        function ne(Z, p, i) {
          var u = Z.attributes;
          (u.playlist = (0, E.ZP)(p)), (u.feedData = i);
        }
        function de(Z) {
          return Z.attributes._destroyed;
        }
        var he = r(1918),
          $ = r(6599),
          D = function (Z) {
            var p = Z.get("skin") ? Z.get("skin").url : void 0;
            return typeof p == "string" &&
              !(function (i) {
                for (
                  var u = document.styleSheets, h = 0, y = u.length;
                  h < y;
                  h++
                )
                  if (u[h].href === i) return !0;
                return !1;
              })(p)
              ? new M.ZP(p, !0).load().catch(function (i) {
                  return i;
                })
              : Promise.resolve();
          },
          se = function (Z) {
            var p = Z.get("advertising");
            return !!(p && p.outstream);
          },
          xe = function (Z) {
            return se(Z)
              ? Promise.resolve()
              : ie(Z)
                  .then(function () {
                    if (Z.get("drm") || (0, he.w0)(Z.get("playlist")))
                      return (0, he.lD)(Z.get("edition"));
                  })
                  .then(function () {
                    return ie((p = Z)).then(function () {
                      if (!de(p)) {
                        var i = (0, E.s7)(p.get("playlist"), p);
                        p.attributes.playlist = i;
                        try {
                          (0, E._)(i);
                        } catch (ee) {
                          throw ((ee.code += g.xk), ee);
                        }
                        var u = p.getProviders(),
                          h = (0, E.bx)(p.get("item"), i.length),
                          y = u.choose(i[h].sources[0]),
                          C = y.provider,
                          B = y.name;
                        return typeof C == "function"
                          ? C
                          : S.Tr.html5 && B === "html5"
                          ? S.Tr.html5
                          : u.load(B).catch(function (ee) {
                              throw (0, g.l9)(ee, g.y4);
                            });
                      }
                    });
                    var p;
                  });
          },
          me = function (Z) {
            var p = Z.attributes,
              i = p.error;
            if (i && i.code === $.u5) {
              var u = p.pid,
                h = p.ph,
                y = new $.ZP(p.key);
              if (h > 0 && h < 4 && u && y.duration() > -7776e6)
                return new M.ZP(
                  "//content.jwplatform.com/libraries/" + u + ".js"
                )
                  .load()
                  .then(function () {
                    var C = window.jwplayer.defaults.key,
                      B = new $.ZP(C);
                    B.error() ||
                      B.token() !== y.token() ||
                      ((p.key = C),
                      (p.edition = B.edition()),
                      (p.error = B.error()));
                  })
                  .catch(function () {});
            }
            return Promise.resolve();
          },
          pe = function (Z, p) {
            var i = [me(Z)];
            return se(Z) || i.push(Promise.resolve()), Promise.all(i);
          },
          _e = function (Z, p) {
            return (function (i, u) {
              return r
                .e(168)
                .then(
                  function (h) {
                    return new (r(5545).default)(u).setup(i);
                  }.bind(null, r)
                )
                .catch((0, S.Ep)(g.fU + 130));
            })(Z, p).then(function () {
              return D(Z);
            });
          },
          Te = function (Z, p) {
            var i = function () {
              return (function (u, h) {
                return (0, W.Z)(u, h);
              })(Z, p);
            };
            return window.location !== window.parent.location &&
              /isAMP/.test(document.location.search)
              ? _e(Z, p).then(i).catch(i)
              : i();
          },
          z = function (Z) {
            var p = Z.attributes,
              i = p.language,
              u = p.base,
              h = p.setupConfig,
              y = p.intl,
              C = (0, q.Pm)(h, y, i);
            return !(0, q.q2)(i) || (0, q.dl)(C)
              ? Promise.resolve()
              : new Promise(function (B) {
                  return (0, q.Dq)(u, i)
                    .then(function (ee) {
                      var V = ee.response;
                      if (!de(Z)) {
                        if (!V) throw new g.rG(null, g.wH);
                        (p.localization = (0, q.Mh)(V, C)), B();
                      }
                    })
                    .catch(function (ee) {
                      B(ee.code === g.wH ? ee : (0, g.l9)(ee, g.A6));
                    });
                });
          },
          O = function (Z) {
            return new Promise(function (p) {
              return Z.attributes.liveSyncDuration > 45
                ? p((0, g.l9)(new Error(), g.wM))
                : p();
            });
          },
          U = function (Z) {
            var p;
            (this.start = function (i) {
              var u = Te(Z, i),
                h = Promise.all([v(Z), O(Z), u, xe(Z), pe(Z), D(Z), z(Z)]),
                y = new Promise(function (C, B) {
                  p = setTimeout(function () {
                    B(new g.rG(g.pJ, g.T6));
                  }, 6e4);
                  var ee = function () {
                    clearTimeout(p), setTimeout(C, 6e4);
                  };
                  h.then(ee).catch(ee);
                });
              return Promise.race([h, y])
                .catch(function (C) {
                  var B = function () {
                    throw C;
                  };
                  return u.then(B).catch(B);
                })
                .then(function (C) {
                  return (function (B) {
                    if (!B || !B.length) return { core: null, warnings: [] };
                    var ee = B.reduce(function (V, H) {
                      return V.concat(H);
                    }, []).filter(function (V) {
                      return V && V.code;
                    });
                    return { core: B[0], warnings: ee };
                  })(C);
                });
            }),
              (this.destroy = function () {
                clearTimeout(p), Z.set("_destroyed", !0), (Z = null);
              });
          },
          K = r(2303),
          fe = r(7411),
          Pe = r(9888),
          ke = r(4742),
          Ce = { removeItem: function (Z) {} };
        try {
          Ce = window.localStorage || Ce;
        } catch {}
        var P = (function () {
            function Z(i, u) {
              (this.namespace = i), (this.items = u);
            }
            var p = Z.prototype;
            return (
              (p.getAllItems = function () {
                var i = this;
                return this.items.reduce(function (u, h) {
                  var y = Ce[i.namespace + "." + h];
                  return (
                    y &&
                      (u[h] =
                        h !== "captions"
                          ? (0, Pe.serialize)(y)
                          : JSON.parse(y)),
                    u
                  );
                }, {});
              }),
              (p.track = function (i) {
                var u = this;
                this.items.forEach(function (h) {
                  i.on("change:" + h, function (y, C) {
                    try {
                      h === "captions" && (C = JSON.stringify(C)),
                        (Ce[u.namespace + "." + h] = C);
                    } catch (B) {
                      ke.Z.debug && console.error(B);
                    }
                  });
                });
              }),
              (p.clear = function () {
                var i = this;
                this.items.forEach(function (u) {
                  Ce.removeItem(i.namespace + "." + u);
                });
              }),
              Z
            );
          })(),
          R = r(7753),
          N = r(9918),
          X = r(328),
          G = r(4225),
          Q = r(7683),
          ce = r(4609),
          oe = r(5882),
          re =
            (r(4671),
            r(9926),
            function (Z) {
              (this._events = {}),
                (this.modelShim = new R.Z()),
                (this.modelShim._qoeItem = new fe.Z()),
                (this.mediaShim = {}),
                (this.setup = new U(this.modelShim)),
                (this.currentContainer = this.originalContainer = Z),
                (this.apiQueue = new d.Z(
                  this,
                  [
                    "load",
                    "play",
                    "pause",
                    "seek",
                    "stop",
                    "playlistItem",
                    "playlistNext",
                    "playlistPrev",
                    "next",
                    "preload",
                    "setAllowFullscreen",
                    "setConfig",
                    "setCurrentAudioTrack",
                    "setCurrentCaptions",
                    "setCurrentQuality",
                    "setFullscreen",
                    "setPip",
                    "requestPip",
                    "addButton",
                    "removeButton",
                    "castToggle",
                    "setMute",
                    "setVolume",
                    "setPlaybackRate",
                    "addCues",
                    "setCues",
                    "setPlaylistItem",
                    "stopCasting",
                    "resize",
                    "setCaptions",
                    "setControls",
                  ],
                  function () {
                    return !0;
                  }
                ));
            });
        function Y(Z, p) {
          p &&
            p.code &&
            (p.sourceError && console.error(p.sourceError),
            console.error(g.rG.logMessage(p.code)));
        }
        function ve(Z) {
          Z && Z.code && console.warn(g.rG.logMessage(Z.code));
        }
        function le(Z, p) {
          if (!document.body.contains(Z.currentContainer)) {
            var i = document.getElementById(Z.get("id"));
            i && (Z.currentContainer = i);
          }
          Z.currentContainer.parentElement &&
            Z.currentContainer.parentElement.replaceChild(
              p,
              Z.currentContainer
            ),
            (Z.currentContainer = p);
        }
        (0, l.l7)(re.prototype, {
          on: X.ZP.on,
          once: X.ZP.once,
          off: X.ZP.off,
          trigger: X.ZP.trigger,
          init: function (Z, p) {
            var i = this,
              u = this.modelShim,
              h = new P("jwplayer", [
                "volume",
                "mute",
                "captionLabel",
                "captions",
                "bandwidthEstimate",
                "bitrateSelection",
                "qualityLabel",
                "enableShortcuts",
              ]),
              y = h && h.getAllItems();
            (u.attributes = u.attributes || {}),
              (0, l.l7)(this.mediaShim, N.L4);
            var C = Z,
              B = (0, w.ZP)((0, l.l7)({}, Z), y);
            (B.id = p.id),
              (B.setupConfig = C),
              (0, l.l7)(u.attributes, B, N.bv),
              (u.getProviders = function () {
                return new K.Z(B);
              }),
              (u.setProvider = function () {});
            var ee = (0, Q.Z)();
            u.get("backgroundLoading") ||
              (ee = (0, ce.Z)(ee.getPrimedElement(), ee));
            var V = (this.primeUi = new oe.ZP(
              (0, oe.GU)(this.originalContainer)
            ).once("gesture", function () {
              ee.prime(), i.preload(), V.destroy();
            }));
            return (
              u.on("change:errorEvent", Y),
              this.setup
                .start(p)
                .then(function (H) {
                  var ue = H.core;
                  if (!ue) throw (0, g.l9)(null, g.y7);
                  if (i.setup) {
                    i.on(j.cM, ve),
                      H.warnings.forEach(function (Ne) {
                        i.trigger(j.cM, Ne);
                      });
                    var be = i.modelShim.clone();
                    if (be.error) throw be.error;
                    var Ge = i.apiQueue.queue.slice(0);
                    i.apiQueue.destroy(),
                      (0, l.l7)(i, ue.prototype),
                      i.playerSetup(
                        be,
                        p,
                        i.originalContainer,
                        i._events,
                        Ge,
                        ee
                      );
                    var Re = i._model;
                    return (
                      u.off("change:errorEvent", Y),
                      Re.on("change:errorEvent", Y),
                      h.track(Re),
                      i
                        .updatePlaylist(Re.get("playlist"), Re.get("feedData"))
                        .catch(function (Ne) {
                          var yt = Ne.code === g._M ? g.IB : g.xk;
                          throw (0, g.l9)(Ne, yt);
                        })
                    );
                  }
                })
                .then(function () {
                  i.setup && i.playerReady();
                })
                .catch(function (H) {
                  i.setup &&
                    (function (ue, be, Ge) {
                      Promise.resolve().then(function () {
                        var Re = (0, g.Mm)(g.ud, g.nk, Ge),
                          Ne = ue._model || ue.modelShim;
                        (Re.message =
                          Re.message || Ne.get("localization").errors[Re.key]),
                          delete Re.key;
                        var yt = Ne.get("contextual");
                        if (!yt) {
                          var Bt = (0, G.Z)(ue, Re);
                          G.Z.cloneIcon &&
                            Bt.querySelector(".jw-icon").appendChild(
                              G.Z.cloneIcon("error")
                            ),
                            le(ue, Bt);
                        }
                        Ne.set("errorEvent", Re),
                          Ne.set("state", j.Vy),
                          ue.trigger(j.HH, Re),
                          yt && be.remove();
                      });
                    })(i, p, H);
                })
            );
          },
          playerDestroy: function () {
            this.destroy && this.destroy(),
              this.apiQueue && this.apiQueue.destroy(),
              this.setup && this.setup.destroy(),
              this.primeUi && this.primeUi.destroy(),
              this.currentContainer !== this.originalContainer &&
                le(this, this.originalContainer),
              this.off(),
              (this._events =
                this._model =
                this.modelShim =
                this.apiQueue =
                this.primeUi =
                this.setup =
                  null);
          },
          getContainer: function () {
            return this.currentContainer;
          },
          get: function (Z) {
            if (this.modelShim)
              return Z in this.mediaShim
                ? this.mediaShim[Z]
                : this.modelShim.get(Z);
          },
          getItemQoe: function () {
            return this.modelShim._qoeItem;
          },
          getItemPromise: function () {
            return null;
          },
          setItemCallback: function (Z) {
            this.modelShim &&
              (this.modelShim.attributes.playlistItemCallback = Z);
          },
          getConfig: function () {
            return (0, l.l7)({}, this.modelShim.attributes, this.mediaShim);
          },
          getCurrentCaptions: function () {
            return this.get("captionsIndex");
          },
          getWidth: function () {
            return this.get("containerWidth");
          },
          getHeight: function () {
            return this.get("containerHeight");
          },
          getMute: function () {
            return this.get("mute");
          },
          getProvider: function () {
            return this.get("provider");
          },
          getState: function () {
            return this.get("state");
          },
          getAudioTracks: function () {
            return null;
          },
          getCaptionsList: function () {
            return null;
          },
          getQualityLevels: function () {
            return null;
          },
          getVisualQuality: function () {
            return null;
          },
          getCurrentQuality: function () {
            return -1;
          },
          getCurrentAudioTrack: function () {
            return -1;
          },
          getSafeRegion: function () {
            return { x: 0, y: 0, width: 0, height: 0 };
          },
          isBeforeComplete: function () {
            return !1;
          },
          isBeforePlay: function () {
            return !1;
          },
          createInstream: function () {
            return null;
          },
          skipAd: function () {},
          attachMedia: function () {},
          detachMedia: function () {},
        });
        var ge = re;
      },
      4446: function (c, s, r) {
        r.d(s, {
          nk: function () {
            return d;
          },
          T6: function () {
            return w;
          },
          y7: function () {
            return S;
          },
          fU: function () {
            return x;
          },
          xk: function () {
            return E;
          },
          IB: function () {
            return I;
          },
          YQ: function () {
            return k;
          },
          DD: function () {
            return b;
          },
          y4: function () {
            return g;
          },
          tJ: function () {
            return _;
          },
          o2: function () {
            return m;
          },
          _M: function () {
            return v;
          },
          EY: function () {
            return A;
          },
          wM: function () {
            return T;
          },
          Y7: function () {
            return j;
          },
          A6: function () {
            return L;
          },
          wH: function () {
            return M;
          },
          ul: function () {
            return q;
          },
          MD: function () {
            return W;
          },
          pJ: function () {
            return ie;
          },
          zO: function () {
            return ne;
          },
          Sp: function () {
            return de;
          },
          H4: function () {
            return he;
          },
          ud: function () {
            return $;
          },
          rG: function () {
            return D;
          },
          Mm: function () {
            return se;
          },
          l9: function () {
            return xe;
          },
          nm: function () {
            return me;
          },
        });
        var l = r(6042),
          d = 1e5,
          w = 100001,
          S = 100002,
          x = 101e3,
          E = 102e3,
          I = 102700,
          k = 200001,
          b = 202e3,
          g = 104e3,
          _ = 203e3,
          m = 203640,
          v = 203700,
          A = 204e3,
          T = 300100,
          j = 306e3,
          L = 308e3,
          M = 308640,
          q = "cantPlayVideo",
          W = "badConnection",
          ie = "cantLoadPlayer",
          ne = "cantPlayInBrowser",
          de = "liveStreamDown",
          he = "protectedContent",
          $ = "technicalError",
          D = (function () {
            function pe(_e, Te, z) {
              (this.code = (0, l.qh)(Te) ? Te : 0),
                (this.sourceError = z || null),
                _e && (this.key = _e);
            }
            return (
              (pe.logMessage = function (_e) {
                var Te = _e % 1e3,
                  z = Math.floor((_e - Te) / 1e3),
                  O = _e.toString();
                return (
                  Te >= 400 && Te < 600 && (O = z + "400-" + z + "599"),
                  "JW Player " +
                    (_e > 299999 && _e < 4e5 ? "Warning" : "Error") +
                    " " +
                    _e +
                    ". For more information see https://developer.jwplayer.com/jw-player/docs/developer-guide/api/errors-reference#" +
                    O
                );
              }),
              pe
            );
          })();
        function se(pe, _e, Te) {
          return Te instanceof D && Te.code ? Te : new D(pe, _e, Te);
        }
        function xe(pe, _e) {
          var Te = se($, _e, pe);
          return (Te.code = ((pe && pe instanceof D && pe.code) || 0) + _e), Te;
        }
        function me(pe) {
          var _e = pe.name,
            Te = pe.message;
          switch (_e) {
            case "AbortError":
              return /pause/.test(Te)
                ? 303213
                : /load/.test(Te)
                ? 303212
                : 303210;
            case "NotAllowedError":
              return 303220;
            case "NotSupportedError":
              return 303230;
            default:
              return 303200;
          }
        }
      },
      6391: function (c, s) {
        s.Z = [];
      },
      7411: function (c, s, r) {
        r.d(s, {
          Z: function () {
            return E;
          },
        });
        var l = r(6042),
          d = r(5004),
          w = window.performance || { timing: {} },
          S = w.timing.navigationStart || (0, d.z)();
        function x() {
          return S + w.now();
        }
        "now" in w ||
          (w.now = function () {
            return (0, d.z)() - S;
          });
        var E = (function () {
          function I() {
            (this.startTimes = {}),
              (this.sum = {}),
              (this.counts = {}),
              (this.ticks = {});
          }
          var k = I.prototype;
          return (
            (k.start = function (b) {
              (this.startTimes[b] = x()),
                (this.counts[b] = this.counts[b] + 1 || 1);
            }),
            (k.end = function (b) {
              if (this.startTimes[b]) {
                var g = x() - this.startTimes[b];
                delete this.startTimes[b], (this.sum[b] = this.sum[b] + g || g);
              }
            }),
            (k.dump = function () {
              var b = (0, l.l7)({}, this.sum);
              for (var g in this.startTimes)
                if (Object.prototype.hasOwnProperty.call(this.startTimes, g)) {
                  var _ = x() - this.startTimes[g];
                  b[g] = b[g] + _ || _;
                }
              return {
                counts: (0, l.l7)({}, this.counts),
                sums: b,
                events: (0, l.l7)({}, this.ticks),
              };
            }),
            (k.tick = function (b) {
              this.ticks[b] = x();
            }),
            (k.clear = function (b) {
              delete this.ticks[b];
            }),
            (k.between = function (b, g) {
              return this.ticks[g] && this.ticks[b]
                ? this.ticks[g] - this.ticks[b]
                : null;
            }),
            I
          );
        })();
      },
      4601: function (c, s, r) {
        r.d(s, {
          v: function () {
            return S;
          },
          z: function () {
            return x;
          },
        });
        var l = r(2894),
          d = r(8348),
          w = null,
          S = {};
        function x() {
          return (
            w ||
              (w = d.OS.tizenApp
                ? r
                    .e(74)
                    .then(
                      function (E) {
                        var I = r(3112).default;
                        return (S.controls = I), I;
                      }.bind(null, r)
                    )
                    .catch(function () {
                      (w = null), (0, l.Jt)(301133)();
                    })
                : r
                    .e(716)
                    .then(
                      function (E) {
                        var I = r(6867).default;
                        return (S.controls = I), I;
                      }.bind(null, r)
                    )
                    .catch(function () {
                      (w = null), (0, l.Jt)(301130)();
                    })),
            w
          );
        }
      },
      8348: function (c, s, r) {
        r.r(s),
          r.d(s, {
            Browser: function () {
              return x;
            },
            Features: function () {
              return I;
            },
            OS: function () {
              return E;
            },
          });
        var l = r(2268);
        function d(k, b) {
          var g = k.exec(b);
          if (g && g.length > 1) return g[1];
        }
        var w = navigator.userAgent,
          S = function () {},
          x = {
            get androidNative() {
              return (0, l.O7)();
            },
            get chrome() {
              return (0, l.i7)();
            },
            get edge() {
              return (0, l.un)();
            },
            get facebook() {
              return (0, l.DF)();
            },
            get firefox() {
              return (0, l.pZ)();
            },
            get ie() {
              return (0, l.w1)();
            },
            get msie() {
              return (0, l.A)();
            },
            get safari() {
              return (0, l.G6)();
            },
            get version() {
              return (function (k, b) {
                var g, _, m, v;
                if (k.chrome)
                  g =
                    b.indexOf("Chrome") !== -1
                      ? b.substring(b.indexOf("Chrome") + 7)
                      : b.substring(b.indexOf("CriOS") + 6);
                else if (k.safari) g = b.substring(b.indexOf("Version") + 8);
                else if (k.firefox) g = b.substring(b.indexOf("Firefox") + 8);
                else if (k.edge) {
                  var A = b.indexOf("Edge");
                  A === -1 ? (A = b.indexOf("Edg") + 4) : (A += 5),
                    (g = b.substring(A));
                } else
                  k.ie &&
                    (b.indexOf("rv:") !== -1
                      ? (g = b.substring(b.indexOf("rv:") + 3))
                      : b.indexOf("MSIE") !== -1 &&
                        (g = b.substring(b.indexOf("MSIE") + 5)));
                return (
                  g &&
                    ((v = g.indexOf(";")) !== -1 && (g = g.substring(0, v)),
                    (v = g.indexOf(" ")) !== -1 && (g = g.substring(0, v)),
                    (v = g.indexOf(")")) !== -1 && (g = g.substring(0, v)),
                    (_ = parseInt(g, 10)),
                    (m = parseInt(g.split(".")[1], 10))),
                  { version: g, major: _, minor: m }
                );
              })(this, w);
            },
          },
          E = {
            get android() {
              return (0, l.Dt)();
            },
            get iOS() {
              return (0, l.gn)();
            },
            get mobile() {
              return (0, l.tq)();
            },
            get mac() {
              return (0, l.id)();
            },
            get iPad() {
              return (0, l.zc)();
            },
            get iPhone() {
              return (0, l.xb)();
            },
            get windows() {
              return w.indexOf("Windows") > -1;
            },
            get tizen() {
              return (0, l.yS)();
            },
            get tizenApp() {
              return (0, l.Q6)();
            },
            get version() {
              return (function (k, b) {
                var g, _, m;
                if (k.windows)
                  switch ((g = d(/Windows(?: NT|)? ([._\d]+)/, b))) {
                    case "6.1":
                      g = "7.0";
                      break;
                    case "6.2":
                      g = "8.0";
                      break;
                    case "6.3":
                      g = "8.1";
                  }
                else
                  k.android
                    ? (g = d(/Android ([._\d]+)/, b))
                    : k.iOS
                    ? (g = d(/OS ([._\d]+)/, b))
                    : k.mac
                    ? (g = d(/Mac OS X ([._\d]+)/, b))
                    : k.tizen && (g = d(/Tizen ([._\d]+)/, b));
                if (g) {
                  _ = parseInt(g, 10);
                  var v = g.split(/[._]/);
                  v && (m = parseInt(v[1], 10));
                }
                return { version: g, major: _, minor: m };
              })(this, w);
            },
          },
          I = {
            get flash() {
              return (0, l.NO)();
            },
            get flashVersion() {
              return (0, l.dI)();
            },
            get iframe() {
              return (0, l.cL)();
            },
            get passiveEvents() {
              return (function () {
                var k = !1;
                try {
                  var b = Object.defineProperty({}, "passive", {
                    get: function () {
                      return (k = !0);
                    },
                  });
                  window.addEventListener("testPassive", S, b),
                    window.removeEventListener("testPassive", S, b);
                } catch {}
                return k;
              })();
            },
            get backgroundLoading() {
              return !(E.iOS || x.safari || E.tizen);
            },
          };
      },
      1643: function (c, s, r) {
        r.d(s, {
          Kb: function () {
            return l;
          },
          bc: function () {
            return d;
          },
          xQ: function () {
            return w;
          },
          _5: function () {
            return S;
          },
          r0: function () {
            return x;
          },
          Vy: function () {
            return E;
          },
          ik: function () {
            return I;
          },
          nQ: function () {
            return k;
          },
          Wp: function () {
            return b;
          },
          nv: function () {
            return g;
          },
          Sv: function () {
            return _;
          },
          ot: function () {
            return m;
          },
          P: function () {
            return v;
          },
          B1: function () {
            return A;
          },
          tP: function () {
            return T;
          },
          K5: function () {
            return j;
          },
          U3: function () {
            return L;
          },
          pn: function () {
            return M;
          },
          cM: function () {
            return q;
          },
          Rt: function () {
            return W;
          },
          $_: function () {
            return ie;
          },
          Ax: function () {
            return ne;
          },
          WE: function () {
            return de;
          },
          k3: function () {
            return he;
          },
          uL: function () {
            return $;
          },
          wh: function () {
            return D;
          },
          Ms: function () {
            return se;
          },
          Rc: function () {
            return xe;
          },
          NZ: function () {
            return me;
          },
          $j: function () {
            return pe;
          },
          s$: function () {
            return _e;
          },
          Jl: function () {
            return Te;
          },
          cy: function () {
            return z;
          },
          V$: function () {
            return O;
          },
          pi: function () {
            return U;
          },
          Ew: function () {
            return K;
          },
          FU: function () {
            return fe;
          },
          cq: function () {
            return Pe;
          },
          Je: function () {
            return ke;
          },
          aQ: function () {
            return Ce;
          },
          HH: function () {
            return P;
          },
          uc: function () {
            return R;
          },
          uT: function () {
            return N;
          },
          R2: function () {
            return X;
          },
          TJ: function () {
            return G;
          },
          oZ: function () {
            return Q;
          },
          yH: function () {
            return ce;
          },
          gy: function () {
            return oe;
          },
          O1: function () {
            return re;
          },
          rx: function () {
            return Y;
          },
          UZ: function () {
            return ve;
          },
          aM: function () {
            return le;
          },
          ug: function () {
            return ge;
          },
          Hy: function () {
            return Z;
          },
          UW: function () {
            return p;
          },
          sF: function () {
            return i;
          },
          gO: function () {
            return u;
          },
          Ow: function () {
            return h;
          },
          j0: function () {
            return y;
          },
          _B: function () {
            return C;
          },
          jt: function () {
            return B;
          },
          UF: function () {
            return ee;
          },
          QF: function () {
            return V;
          },
          Ib: function () {
            return H;
          },
          SL: function () {
            return ue;
          },
          Z_: function () {
            return be;
          },
          Gj: function () {
            return Ge;
          },
          xf: function () {
            return Re;
          },
          l5: function () {
            return Ne;
          },
          Bs: function () {
            return yt;
          },
          h7: function () {
            return Bt;
          },
          qG: function () {
            return $t;
          },
          RF: function () {
            return sn;
          },
        });
        var l = "buffering",
          d = "idle",
          w = "complete",
          S = "paused",
          x = "playing",
          E = "error",
          I = "loading",
          k = "stalled",
          b = "drag",
          g = "dragStart",
          _ = "dragEnd",
          m = "click",
          v = "doubleClick",
          A = "over",
          T = "move",
          j = "enter",
          L = "out",
          M = E,
          q = "warning",
          W = "adClick",
          ie = "mediaLoaded",
          ne = "adPause",
          de = "adPlay",
          he = "adSkipped",
          $ = "adTime",
          D = "autostartNotAllowed",
          se = w,
          xe = "ready",
          me = "seek",
          pe = "beforePlay",
          _e = "beforeComplete",
          Te = "bufferFull",
          z = "displayClick",
          O = "playlistComplete",
          U = "cast",
          K = "mediaError",
          fe = "firstFrame",
          Pe = "playAttempt",
          ke = "playAttemptFailed",
          Ce = "seeked",
          P = "setupError",
          R = "state",
          N = "bufferChange",
          X = "time",
          G = "ratechange",
          Q = "mediaType",
          ce = "volume",
          oe = "mute",
          re = "metadataCueParsed",
          Y = "meta",
          ve = "levels",
          le = "levelsChanged",
          ge = "visualQuality",
          Z = "controls",
          p = "fullscreen",
          i = "resize",
          u = "playlistItem",
          h = "playlist",
          y = "audioTracks",
          C = "audioTrackChanged",
          B = "subtitlesTracks",
          ee = "subtitlesTrackChanged",
          V = "playbackRateChanged",
          H = "logoClick",
          ue = "captionsList",
          be = "captionsChanged",
          Ge = "providerFirstFrame",
          Re = "userAction",
          Ne = "instreamClick",
          yt = "breakpoint",
          Bt = "fullscreenchange",
          $t = "bandwidthEstimate",
          sn = "float";
      },
      9918: function (c, s, r) {
        r.d(s, {
          bv: function () {
            return l;
          },
          L4: function () {
            return d;
          },
          ni: function () {
            return w;
          },
          OG: function () {
            return S;
          },
        });
        var l = {
            audioMode: !1,
            itemMeta: {},
            playbackRate: 1,
            playRejected: !1,
            state: r(1643).bc,
            itemReady: !1,
            controlsEnabled: !1,
          },
          d = { position: 0, duration: 0, buffer: 0, currentTime: 0 },
          w = 120,
          S = 25;
      },
      7753: function (c, s, r) {
        function l(w, S) {
          return (
            (l =
              Object.setPrototypeOf ||
              function (x, E) {
                return (x.__proto__ = E), x;
              }),
            l(w, S)
          );
        }
        r.d(s, {
          Z: function () {
            return d;
          },
        });
        var d = (function (w) {
          var S, x;
          function E() {
            var k;
            return (
              ((k = w.call(this) || this).attributes = Object.create(null)), k
            );
          }
          (x = w),
            ((S = E).prototype = Object.create(x.prototype)),
            (S.prototype.constructor = S),
            l(S, x);
          var I = E.prototype;
          return (
            (I.addAttributes = function (k) {
              var b = this;
              Object.keys(k).forEach(function (g) {
                b.add(g, k[g]);
              });
            }),
            (I.add = function (k, b) {
              var g = this;
              Object.defineProperty(this, k, {
                get: function () {
                  return g.attributes[k];
                },
                set: function (_) {
                  g.set(k, _);
                },
                enumerable: !1,
              }),
                (this.attributes[k] = b);
            }),
            (I.get = function (k) {
              return this.attributes[k];
            }),
            (I.set = function (k, b) {
              if (this.attributes[k] !== b) {
                var g = this.attributes[k];
                (this.attributes[k] = b),
                  this.trigger("change:" + k, this, b, g);
              }
            }),
            (I.clone = function () {
              var k = {},
                b = this.attributes;
              if (b) for (var g in b) k[g] = b[g];
              return k;
            }),
            (I.change = function (k, b, g) {
              this.on("change:" + k, b, g);
              var _ = this.get(k);
              return b.call(g, this, _, _), this;
            }),
            E
          );
        })(r(328).ZP);
      },
      7941: function (c, s, r) {
        r.d(s, {
          r1: function () {
            return d;
          },
          dZ: function () {
            return w;
          },
          qk: function () {
            return S;
          },
          my: function () {
            return x;
          },
        });
        var l = r(2957);
        function d(E) {
          var I = "";
          return (
            E &&
              (E.localName
                ? (I = E.localName)
                : E.baseName && (I = E.baseName)),
            I
          );
        }
        function w(E) {
          var I = "";
          return (
            E &&
              (E.textContent
                ? (I = (0, l.fy)(E.textContent))
                : E.text && (I = (0, l.fy)(E.text))),
            I
          );
        }
        function S(E, I) {
          return E.childNodes[I];
        }
        function x(E) {
          return E.childNodes ? E.childNodes.length : 0;
        }
      },
      6769: function (c, s, r) {
        r.d(s, {
          Z: function () {
            return b;
          },
        });
        var l = r(7941),
          d = r(2957);
        function w(_) {
          var m = {
            zh: "Chinese",
            nl: "Dutch",
            en: "English",
            fr: "French",
            de: "German",
            it: "Italian",
            ja: "Japanese",
            pt: "Portuguese",
            ru: "Russian",
            es: "Spanish",
          };
          return m[_] ? m[_] : _;
        }
        function S(_) {
          for (var m = [], v = 0; v < (0, l.my)(_); v++) {
            var A = _.childNodes[v];
            A.prefix === "jwplayer" &&
              (0, l.r1)(A).toLowerCase() === "mediatypes" &&
              m.push((0, l.dZ)(A));
          }
          return m;
        }
        var x = function _(m, v) {
            for (var A = [], T = 0; T < (0, l.my)(m); T++) {
              var j = m.childNodes[T];
              if (j.prefix === "media") {
                if (!(0, l.r1)(j)) continue;
                switch ((0, l.r1)(j).toLowerCase()) {
                  case "content":
                    if (
                      ((0, d.Dc)(j, "duration") &&
                        (v.duration = (0, d.m9)((0, d.Dc)(j, "duration"))),
                      (0, d.Dc)(j, "url"))
                    ) {
                      v.sources || (v.sources = []);
                      var L = {
                          file: (0, d.Dc)(j, "url"),
                          type: (0, d.Dc)(j, "type"),
                          width: (0, d.Dc)(j, "width"),
                          label: (0, d.Dc)(j, "label"),
                        },
                        M = S(j);
                      M.length && (L.mediaTypes = M), v.sources.push(L);
                    }
                    (0, l.my)(j) > 0 && (v = _(j, v));
                    break;
                  case "title":
                    v.title = (0, l.dZ)(j);
                    break;
                  case "description":
                    v.description = (0, l.dZ)(j);
                    break;
                  case "guid":
                    v.mediaid = (0, l.dZ)(j);
                    break;
                  case "thumbnail":
                    v.image || (v.image = (0, d.Dc)(j, "url"));
                    break;
                  case "group":
                    _(j, v);
                    break;
                  case "subtitle":
                    var q = { file: (0, d.Dc)(j, "url"), kind: "captions" };
                    (0, d.Dc)(j, "lang").length > 0 &&
                      (q.label = w((0, d.Dc)(j, "lang"))),
                      A.push(q);
                }
              }
            }
            v.tracks || (v.tracks = []);
            for (var W = 0; W < A.length; W++) v.tracks.push(A[W]);
            return v;
          },
          E = r(9888),
          I = function (_, m) {
            for (
              var v = "default",
                A = "label",
                T = "file",
                j = [],
                L = [],
                M = m,
                q = 0;
              q < _.childNodes.length;
              q++
            ) {
              var W = _.childNodes[q];
              if (W.prefix === "jwplayer") {
                var ie = (0, l.r1)(W);
                ie === "source"
                  ? (delete m.sources,
                    j.push({
                      file: (0, d.Dc)(W, T),
                      default: (0, d.Dc)(W, v),
                      label: (0, d.Dc)(W, A),
                      type: (0, d.Dc)(W, "type"),
                    }))
                  : ie === "track"
                  ? (delete m.tracks,
                    L.push({
                      file: (0, d.Dc)(W, T),
                      default: (0, d.Dc)(W, v),
                      kind: (0, d.Dc)(W, "kind"),
                      label: (0, d.Dc)(W, A),
                    }))
                  : ((m[ie] = (0, E.serialize)((0, l.dZ)(W))),
                    ie === "file" && m.sources && delete m.sources);
              }
              m.file || (m.file = m.link);
            }
            if (j.length) {
              m.sources = [];
              for (var ne = 0; ne < j.length; ne++) {
                var de = j[ne];
                de.file.length > 0 &&
                  ((de[v] = j[ne][v] === "true"),
                  de.label || delete de.label,
                  M.sources.push(de));
              }
            }
            if (L.length) {
              m.tracks = [];
              for (var he = 0; he < L.length; he++) {
                var $ = L[he];
                $.file &&
                  $.file.length > 0 &&
                  (($[v] = L[he][v] === "true"),
                  ($.kind = L[he].kind.length ? L[he].kind : "captions"),
                  $.label || delete $.label,
                  M.tracks.push($));
              }
            }
            return M;
          },
          k = r(393);
        function b(_) {
          var m = [];
          m.feedData = {};
          for (var v = 0; v < (0, l.my)(_); v++) {
            var A = (0, l.qk)(_, v);
            if ((0, l.r1)(A).toLowerCase() === "channel")
              for (var T = 0; T < (0, l.my)(A); T++) {
                var j = (0, l.qk)(A, T),
                  L = (0, l.r1)(j).toLowerCase();
                L === "item"
                  ? m.push(g(j))
                  : L && (m.feedData[L] = (0, l.dZ)(j));
              }
          }
          return m;
        }
        function g(_) {
          for (var m = {}, v = 0; v < _.childNodes.length; v++) {
            var A = _.childNodes[v],
              T = (0, l.r1)(A);
            if (T)
              switch (T.toLowerCase()) {
                case "enclosure":
                  m.file = (0, d.Dc)(A, "url");
                  break;
                case "title":
                  m.title = (0, l.dZ)(A);
                  break;
                case "guid":
                  m.mediaid = (0, l.dZ)(A);
                  break;
                case "pubdate":
                  m.date = (0, l.dZ)(A);
                  break;
                case "description":
                  m.description = (0, l.dZ)(A);
                  break;
                case "link":
                  m.link = (0, l.dZ)(A);
                  break;
                case "category":
                  m.tags ? (m.tags += (0, l.dZ)(A)) : (m.tags = (0, l.dZ)(A));
              }
          }
          return new k.Z(I(_, x(_, m)));
        }
      },
      393: function (c, s, r) {
        r.d(s, {
          Z: function () {
            return I;
          },
        });
        var l = r(6042),
          d = r(6053),
          w = ["captions", "metadata", "thumbnails", "chapters"],
          S = function (k) {
            if (k && k.file) {
              var b,
                g = (0, l.l7)({}, { kind: "captions", default: !1 }, k);
              return (
                (g.kind =
                  ((b = g.kind), w.indexOf(b) !== -1 ? g.kind : "captions")),
                (g.default = !!g.default),
                g
              );
            }
          },
          x = r(9918),
          E = Array.isArray,
          I = function (k) {
            E((k = k || {}).tracks) || delete k.tracks;
            var b = (0, l.l7)(
              {},
              { sources: [], tracks: [], minDvrWindow: x.ni },
              k
            );
            b.sources !== Object(b.sources) ||
              E(b.sources) ||
              (b.sources = [(0, d.Z)(b.sources)]),
              (E(b.sources) && b.sources.length !== 0) ||
                (k.levels
                  ? (b.sources = k.levels)
                  : (b.sources = [(0, d.Z)(k)]));
            for (var g = 0; g < b.sources.length; g++) {
              var _ = b.sources[g];
              if (_) {
                var m = _.default;
                (_.default = !!m && m.toString() === "true"),
                  b.sources[g].label || (b.sources[g].label = g.toString()),
                  (b.sources[g] = (0, d.Z)(b.sources[g]));
              }
            }
            return (
              (b.sources = b.sources.filter(function (v) {
                return !!v;
              })),
              E(b.tracks) || (b.tracks = []),
              E(b.captions) &&
                ((b.tracks = b.tracks.concat(b.captions)), delete b.captions),
              (b.tracks = b.tracks.map(S).filter(function (v) {
                return !!v;
              })),
              b
            );
          };
      },
      7263: function (c, s, r) {
        var l = r(6042),
          d = r(1643),
          w = r(7941),
          S = r(6769),
          x = r(6886),
          E = r(328),
          I = r(4446);
        s.Z = function () {
          var k = (0, l.l7)(this, E.ZP);
          function b(_) {
            try {
              var m,
                v = _.responseXML ? _.responseXML.childNodes : null,
                A = null;
              if (v) {
                for (var T = 0; T < v.length && (A = v[T]).nodeType === 8; T++);
                if (
                  (A && (0, w.r1)(A) === "xml" && (A = A.nextSibling),
                  A && (0, w.r1)(A) === "rss")
                ) {
                  var j = (0, S.Z)(A);
                  m = (0, l.l7)({ playlist: j }, j.feedData);
                }
              }
              if (!m)
                try {
                  var L = JSON.parse(_.responseText);
                  if (Array.isArray(L)) m = { playlist: L };
                  else {
                    if (!Array.isArray(L.playlist))
                      throw Error("Playlist is not an array");
                    m = L;
                  }
                } catch (M) {
                  throw new I.rG(I.ul, 621, M);
                }
              k.trigger(d.Ow, m);
            } catch (M) {
              g(M);
            }
          }
          function g(_) {
            _ instanceof I.rG && !_.code && (_ = new I.rG(I.ul, 0)),
              k.trigger(d.pn, _);
          }
          (this.load = function (_) {
            (0, x.h)(_, b, function (m, v, A, T) {
              g(T);
            });
          }),
            (this.destroy = function () {
              this.off();
            });
        };
      },
      8320: function (c, s, r) {
        r.d(s, {
          ZP: function () {
            return L;
          },
          s7: function () {
            return k;
          },
          T5: function () {
            return m;
          },
          YF: function () {
            return g;
          },
          _: function () {
            return b;
          },
          bx: function () {
            return _;
          },
        });
        var l = r(6042),
          d = { none: !0, metadata: !0, auto: !0 };
        function w(M, q) {
          return d[M] ? M : d[q] ? q : "metadata";
        }
        var S = r(393),
          x = r(6053),
          E = r(2303),
          I = r(4446);
        function k(M, q, W) {
          var ie = (0, l.l7)({}, W);
          return (
            delete ie.playlist,
            M.map(function (ne) {
              return g(q, ne, ie);
            }).filter(function (ne) {
              return !!ne;
            })
          );
        }
        function b(M) {
          if (!Array.isArray(M) || M.length === 0) throw new I.rG(I.ul, 630);
        }
        function g(M, q, W) {
          var ie = M.getProviders(),
            ne = M.get("preload"),
            de = (0, l.l7)({}, q);
          if (
            ((de.preload = w(q.preload, ne)),
            (de.allSources = v(de, M)),
            (de.sources = A(de.allSources, ie)),
            de.sources.length)
          )
            return (
              (de.file = de.sources[0].file),
              (de.feedData = W),
              (function (he) {
                var $ = he.sources[0].liveSyncDuration;
                return $ && (he.liveSyncDuration = he.dvrSeekLimit = $), he;
              })(de)
            );
        }
        function _(M, q) {
          var W = (parseInt(M, 10) || 0) % q;
          return W < 0 && (W += q), W;
        }
        var m = function (M, q) {
          return A(v(M, q), q.getProviders());
        };
        function v(M, q) {
          var W = q.attributes,
            ie = M.sources,
            ne = M.allSources,
            de = M.preload,
            he = M.drm,
            $ = T(M.withCredentials, W.withCredentials);
          return (ne || ie)
            .map(function (D) {
              if (D !== Object(D)) return null;
              j(D, W, "androidhls"),
                j(D, W, "hlsjsdefault"),
                j(D, W, "safarihlsjs"),
                (function (me, pe, _e) {
                  if (!me.liveSyncDuration) {
                    var Te = pe.liveSyncDuration ? pe : _e;
                    j(me, Te, "liveSyncDuration");
                  }
                })(D, M, W),
                j(D, W, "_hlsjsProgressive"),
                (D.preload = w(D.preload, de));
              var se = D.drm || he || W.drm;
              se && (D.drm = se);
              var xe = T(D.withCredentials, $);
              return xe !== void 0 && (D.withCredentials = xe), (0, x.Z)(D);
            })
            .filter(function (D) {
              return !!D;
            });
        }
        function A(M, q) {
          (q && q.choose) || (q = new E.Z());
          var W = (function (de, he) {
            for (var $ = 0; $ < de.length; $++) {
              var D = de[$],
                se = he.choose(D).providerToCheck;
              if (se) return { type: D.type, provider: se };
            }
            return null;
          })(M, q);
          if (!W) return [];
          var ie = W.provider,
            ne = W.type;
          return M.filter(function (de) {
            return de.type === ne && q.providerSupports(ie, de);
          });
        }
        function T(M, q) {
          return M === void 0 ? q : M;
        }
        function j(M, q, W) {
          W in q && (M[W] = q[W]);
        }
        var L = function (M) {
          return (Array.isArray(M) ? M : [M]).map(S.Z);
        };
      },
      6053: function (c, s, r) {
        var l = r(6042),
          d = r(7034),
          w = r(2957);
        s.Z = function (S) {
          if (S && S.file) {
            var x = (0, l.l7)({}, { default: !1, type: "" }, S);
            x.file = (0, w.fy)("" + x.file);
            var E = /^[^/]+\/(?:x-)?([^/]+)$/,
              I = x.type;
            if (
              (E.test(I) && ((x.mimeType = I), (x.type = I.replace(E, "$1"))),
              (0, d.isYouTube)(x.file)
                ? (x.type = "youtube")
                : (0, d.isRtmp)(x.file)
                ? (x.type = "rtmp")
                : x.type || (x.type = (0, w.AO)(x.file)),
              x.type)
            ) {
              switch (x.type) {
                case "m3u8":
                case "vnd.apple.mpegurl":
                  x.type = "hls";
                  break;
                case "dash+xml":
                  x.type = "dash";
                  break;
                case "m4a":
                  x.type = "aac";
                  break;
                case "smil":
                  x.type = "rtmp";
              }
              return (
                Object.keys(x).forEach(function (k) {
                  x[k] === "" && delete x[k];
                }),
                x
              );
            }
          }
        };
      },
      4101: function (c, s, r) {
        var l = r(6042),
          d = r(676),
          w = r(9888),
          S = r(2957),
          x = r(4446),
          E = r(3487),
          I = function (b) {
            if (typeof b == "string") {
              var g = (b = b.split("?")[0]).indexOf("://");
              if (g > 0) return 0;
              var _ = b.indexOf("/"),
                m = (0, S.AO)(b);
              return !(g < 0 && _ < 0) || (m && isNaN(m)) ? 1 : 2;
            }
          },
          k = function (b) {
            (this.url = b), (this.promise_ = null);
          };
        Object.defineProperties(k.prototype, {
          promise: {
            get: function () {
              return this.load();
            },
            set: function () {},
          },
        }),
          (0, l.l7)(k.prototype, {
            load: function () {
              var b = this,
                g = this.promise_;
              if (!g) {
                if (I(this.url) === 2) return Promise.resolve(this);
                var _ = new d.ZP(
                  (function (m) {
                    switch (I(m)) {
                      case 0:
                        return m;
                      case 1:
                        return (0, w.getAbsolutePath)(m, window.location.href);
                    }
                  })(this.url)
                );
                (this.loader = _),
                  (g = _.load().then(function () {
                    return b;
                  })),
                  (this.promise_ = g);
              }
              return g;
            },
            registerPlugin: function (b, g, _) {
              (this.name = b), (this.target = g), (this.js = _);
            },
            getNewInstance: function (b, g, _) {
              var m = this.js;
              if (typeof m != "function")
                throw new x.rG(null, (0, E.bX)(this.url) + 100);
              var v = new m(b, g, _);
              return (
                (v.addToPlayer = function () {
                  var A = this.getContainer().querySelector(".jw-overlays");
                  A &&
                    ((_.left = A.style.left),
                    (_.top = A.style.top),
                    A.appendChild(_));
                }),
                (v.resizeHandler = function () {
                  var A = this.getContainer().querySelector(".jw-overlays");
                  A && v.resize(A.clientWidth, A.clientHeight);
                }),
                v
              );
            },
          }),
          (s.Z = k);
      },
      1241: function (c, s, r) {
        r.d(s, {
          Z: function () {
            return b;
          },
          f: function () {
            return k;
          },
        });
        var l = r(4446),
          d = r(3487),
          w = function () {
            this.load = function (g, _, m, v) {
              return m && typeof m == "object"
                ? Promise.all(
                    Object.keys(m)
                      .filter(function (A) {
                        return A;
                      })
                      .map(function (A) {
                        var T = m[A];
                        return _.setupPlugin(A)
                          .then(function (j) {
                            if (!v.attributes._destroyed)
                              return (0, d.MK)(j, T, g);
                          })
                          .catch(function (j) {
                            return (
                              _.removePlugin(A),
                              j.code ? j : new l.rG(null, (0, d.bX)(A), j)
                            );
                          });
                      })
                  )
                : Promise.resolve();
            };
          },
          S = r(4101),
          x = r(5499),
          E = {},
          I = new ((function () {
            function g() {}
            var _ = g.prototype;
            return (
              (_.setupPlugin = function (m) {
                var v = this.getPlugin(m);
                return v
                  ? (v.url !== m &&
                      (0, x.c)(
                        'JW Plugin "' +
                          (0, d.Nq)(m) +
                          '" already loaded from "' +
                          v.url +
                          '". Ignoring "' +
                          m +
                          '."'
                      ),
                    v.promise)
                  : this.addPlugin(m).load();
              }),
              (_.addPlugin = function (m) {
                var v = (0, d.Nq)(m),
                  A = E[v];
                return A || ((A = new S.Z(m)), (E[v] = A)), A;
              }),
              (_.getPlugin = function (m) {
                return E[(0, d.Nq)(m)];
              }),
              (_.removePlugin = function (m) {
                delete E[(0, d.Nq)(m)];
              }),
              (_.getPlugins = function () {
                return E;
              }),
              g
            );
          })())(),
          k = function (g, _, m) {
            var v = I.addPlugin(g);
            v.js || v.registerPlugin(g, _, m);
          };
        function b(g, _) {
          var m = g.get("plugins");
          return (
            (window.jwplayerPluginJsonp = k),
            (g.pluginLoader = g.pluginLoader || new w())
              .load(_, I, m, g)
              .then(function (v) {
                if (!g.attributes._destroyed)
                  return delete window.jwplayerPluginJsonp, v;
              })
          );
        }
      },
      7164: function (c, s, r) {
        r.d(s, {
          Nq: function () {
            return d;
          },
          bX: function () {
            return w;
          },
          MK: function () {
            return S;
          },
        });
        var l = r(6042),
          d = function (x) {
            return x.replace(/^(.*\/)?([^-]*)-?.*\.(js)$/, "$2");
          };
        function w(x) {
          return 305e3;
        }
        function S(x, E, I) {
          var k = x.name,
            b = (0, l.l7)({}, E),
            g = document.createElement("div");
          (g.id = I.id + "_" + k), (g.className = "jw-plugin jw-reset");
          var _ = x.getNewInstance(I, b, g);
          return I.addPlugin(k, _), _;
        }
      },
      7683: function (c, s, r) {
        r.d(s, {
          Z: function () {
            return d;
          },
          V: function () {
            return S;
          },
        });
        var l = r(658);
        function d() {
          for (var x = l.Jx, E = [], I = [], k = 0; k < x; k++) {
            var b = S();
            E.push(b), I.push(b), w(b);
          }
          var g = I.shift(),
            _ = I.shift(),
            m = !1;
          return {
            primed: function () {
              return m;
            },
            prime: function () {
              E.forEach(w), (m = !0);
            },
            played: function () {
              m = !0;
            },
            getPrimedElement: function () {
              return I.shift() || null;
            },
            getAdElement: function () {
              return g;
            },
            getTestElement: function () {
              return _;
            },
            clean: function (v) {
              if (v.src) {
                v.removeAttribute("src");
                try {
                  v.load();
                } catch {}
              }
            },
            recycle: function (v) {
              v &&
                !I.some(function (A) {
                  return A === v;
                }) &&
                (this.clean(v), I.push(v));
            },
            syncVolume: function (v) {
              var A = Math.min(Math.max(0, v / 100), 1);
              E.forEach(function (T) {
                T.volume = A;
              });
            },
            syncMute: function (v) {
              E.forEach(function (A) {
                A.muted = v;
              });
            },
          };
        }
        function w(x) {
          x.src || x.load();
        }
        function S(x) {
          var E = document.createElement("video");
          return (
            (E.className = "jw-video jw-reset"),
            E.setAttribute("tabindex", "-1"),
            E.setAttribute("disableRemotePlayback", ""),
            E.setAttribute("webkit-playsinline", ""),
            E.setAttribute("playsinline", ""),
            x &&
              Object.keys(x).forEach(function (I) {
                E.setAttribute(I, x[I]);
              }),
            E
          );
        }
      },
      658: function (c, s, r) {
        r.d(s, {
          Jx: function () {
            return l;
          },
          l_: function () {
            return d;
          },
          HB: function () {
            return w;
          },
        });
        var l = 4,
          d = 5,
          w = 1;
      },
      4609: function (c, s, r) {
        r.d(s, {
          Z: function () {
            return d;
          },
        });
        var l = r(6042);
        function d(w, S) {
          return (0, l.l7)({}, S, {
            prime: function () {
              w.src || w.load();
            },
            getPrimedElement: function () {
              return w;
            },
            clean: function () {
              S.clean(w);
            },
            recycle: function () {
              S.clean(w);
            },
          });
        }
      },
      6528: function (c, s, r) {
        var l = r(1643),
          d = function () {},
          w = function () {
            return !1;
          },
          S = { name: "default" },
          x = {
            supports: w,
            play: d,
            pause: d,
            preload: d,
            load: d,
            stop: d,
            volume: d,
            mute: d,
            seek: d,
            resize: d,
            remove: d,
            destroy: d,
            setVisibility: d,
            setFullscreen: d,
            getFullscreen: w,
            supportsFullscreen: w,
            getContainer: d,
            setContainer: d,
            getName: function () {
              return S;
            },
            getQualityLevels: d,
            getCurrentQuality: d,
            setCurrentQuality: d,
            getAudioTracks: d,
            getCurrentAudioTrack: d,
            setCurrentAudioTrack: d,
            getSeekRange: function () {
              return { start: 0, end: this.getDuration() };
            },
            setPlaybackRate: d,
            getPlaybackRate: function () {
              return 1;
            },
            getBandwidthEstimate: function () {
              return null;
            },
            getLiveLatency: function () {
              return null;
            },
            attachMedia: d,
            detachMedia: d,
            init: d,
            setState: function (E) {
              (this.state = E), this.trigger(l.uc, { newstate: E });
            },
            sendMediaType: function (E) {
              var I = E[0],
                k = I.type,
                b = I.mimeType,
                g =
                  k === "aac" ||
                  k === "mp3" ||
                  k === "mpeg" ||
                  (b && b.indexOf("audio/") === 0);
              this.trigger(l.oZ, { mediaType: g ? "audio" : "video" });
            },
            getDuration: function () {
              return 0;
            },
            trigger: d,
          };
        s.Z = x;
      },
      1628: function (c, s, r) {
        r.d(s, {
          V: function () {
            return d;
          },
        });
        var l = r(8348);
        function d(w) {
          return w.type === "hls" && l.OS.android
            ? w.androidhls !== !1 &&
                !l.Browser.firefox &&
                parseFloat(l.OS.version.version || "0") >= 4.4
            : null;
        }
      },
      12: function (c, s, r) {
        r.d(s, {
          U: function () {
            return l;
          },
        });
        var l = {};
      },
      670: function (c, s, r) {
        r.d(s, {
          Z: function () {
            return x;
          },
        });
        var l = r(12),
          d = r(2963),
          w = r(6528),
          S = r(6042);
        r(328);
        function x(E) {
          var I = E.getName().name;
          if (!l.U[I]) {
            if (!(0, S.sE)(d.B, (0, S.wB)({ name: I }))) {
              if (!(0, S.mf)(E.supports))
                throw new Error(
                  "Tried to register a provider with an invalid object"
                );
              d.B.unshift({ name: I, supports: E.supports });
            }
            (0, S.ce)(E.prototype, w.Z), (l.U[I] = E);
          }
        }
      },
      6593: function (c, s, r) {
        r.d(s, {
          B: function () {
            return x;
          },
          H: function () {
            return E;
          },
        });
        var l = r(1628),
          d = r(7034),
          w = r(9025),
          S = {
            aac: "audio/mp4",
            mp4: "video/mp4",
            f4v: "video/mp4",
            m4v: "video/mp4",
            mov: "video/mp4",
            mp3: "audio/mpeg",
            mpeg: "audio/mpeg",
            ogv: "video/ogg",
            ogg: "video/ogg",
            oga: "video/ogg",
            vorbis: "video/ogg",
            webm: "video/webm",
            f4a: "video/aac",
            m3u8: "application/vnd.apple.mpegurl",
            m3u: "application/vnd.apple.mpegurl",
            hls: "application/vnd.apple.mpegurl",
          },
          x = [{ name: "html5", supports: E }];
        function E(I) {
          if (!w.Z || !w.Z.canPlayType || (0, l.V)(I) === !1) return !1;
          var k = I.file,
            b = I.type;
          if ((0, d.isRtmp)(k, b)) return !1;
          var g = I.mimeType || S[b];
          if (!g) return !1;
          var _ = I.mediaTypes;
          return (
            _ && _.length && (g = [g].concat(_.slice()).join("; ")),
            !!w.Z.canPlayType(g)
          );
        }
      },
      6875: function (c, s) {
        s.Z =
          "hidden" in document
            ? function () {
                return !document.hidden;
              }
            : "webkitHidden" in document
            ? function () {
                return !document.webkitHidden;
              }
            : function () {
                return !0;
              };
      },
      6886: function (c, s, r) {
        r.d(s, {
          h: function () {
            return E;
          },
          E: function () {
            return I;
          },
        });
        var l = r(6042),
          d = r(9888),
          w = r(7034),
          S = r(4446),
          x = function () {};
        function E(g, _, m, v) {
          var A;
          g === Object(g) && (g = (v = g).url);
          var T = (0, l.l7)(
              {
                xhr: null,
                url: g,
                withCredentials: !1,
                retryWithoutCredentials: !1,
                timeout: 6e4,
                timeoutId: -1,
                oncomplete: _ || x,
                onerror: m || x,
                mimeType: v && !v.responseType ? "text/xml" : "",
                requireValidXML: !1,
                responseType: v && v.plainText ? "text" : "",
                useDomParser: !1,
                requestFilter: null,
              },
              v
            ),
            j = (function (M, q) {
              return function (W, ie) {
                var ne = W.currentTarget || q.xhr;
                if (
                  (clearTimeout(q.timeoutId),
                  q.retryWithoutCredentials && q.xhr.withCredentials)
                )
                  return (
                    I(ne),
                    void E(
                      (0, l.l7)({}, q, {
                        xhr: null,
                        withCredentials: !1,
                        retryWithoutCredentials: !1,
                      })
                    )
                  );
                !ie && ne.status >= 400 && ne.status < 600 && (ie = ne.status),
                  k(q, ie ? S.ul : S.ud, ie || 6, W);
              };
            })(0, T);
          if ("XMLHttpRequest" in window) {
            if (
              ((A = T.xhr = T.xhr || new window.XMLHttpRequest()),
              typeof T.requestFilter == "function")
            ) {
              var L;
              try {
                L = T.requestFilter({ url: g, xhr: A });
              } catch (M) {
                return j(M, 5), A;
              }
              L && "open" in L && "send" in L && (A = T.xhr = L);
            }
            (A.onreadystatechange = (function (M) {
              return function (q) {
                var W = q.currentTarget || M.xhr;
                if (W.readyState === 4) {
                  clearTimeout(M.timeoutId);
                  var ie = W.status;
                  if (ie >= 400) return void k(M, S.ul, ie < 600 ? ie : 6);
                  if (ie === 200)
                    return (function (ne) {
                      return function (de) {
                        var he = de.currentTarget || ne.xhr;
                        if ((clearTimeout(ne.timeoutId), ne.responseType)) {
                          if (ne.responseType === "json")
                            return (function (se, xe) {
                              if (
                                !se.response ||
                                (typeof se.response == "string" &&
                                  se.responseText.substr(1) !== '"')
                              )
                                try {
                                  se = (0, l.l7)({}, se, {
                                    response: JSON.parse(se.responseText),
                                  });
                                } catch (me) {
                                  return void k(xe, S.ul, 611, me);
                                }
                              return xe.oncomplete(se);
                            })(he, ne);
                        } else {
                          var $,
                            D = he.responseXML;
                          if (D)
                            try {
                              $ = D.firstChild;
                            } catch {}
                          if (
                            (D && $) ||
                            (ne.useDomParser &&
                              he.responseText &&
                              !D &&
                              (D = (0, d.parseXML)(he.responseText)) &&
                              D.firstChild)
                          )
                            return b(he, D, ne);
                          if (ne.requireValidXML) return void k(ne, S.ul, 602);
                        }
                        ne.oncomplete(he);
                      };
                    })(M)(q);
                  ie === 0 &&
                    (0, w.isFileProtocol)() &&
                    !/^[a-z][a-z0-9+.-]*:/.test(M.url) &&
                    k(M, S.ul, 7);
                }
              };
            })(T)),
              (A.onerror = j),
              "overrideMimeType" in A
                ? T.mimeType && A.overrideMimeType(T.mimeType)
                : (T.useDomParser = !0);
            try {
              (g = g.replace(/#.*$/, "")), A.open("GET", g, !0);
            } catch (M) {
              return j(M, 3), A;
            }
            if (T.responseType)
              try {
                A.responseType = T.responseType;
              } catch {}
            T.timeout &&
              ((T.timeoutId = setTimeout(function () {
                I(A), k(T, S.ud, 1);
              }, T.timeout)),
              (A.onabort = function () {
                clearTimeout(T.timeoutId);
              }));
            try {
              T.withCredentials &&
                "withCredentials" in A &&
                (A.withCredentials = !0),
                A.send();
            } catch (M) {
              j(M, 4);
            }
            return A;
          }
          k(T, S.ud, 2);
        }
        function I(g) {
          (g.onload = null),
            (g.onprogress = null),
            (g.onreadystatechange = null),
            (g.onerror = null),
            "abort" in g && g.abort();
        }
        function k(g, _, m, v) {
          g.onerror(_, g.url, g.xhr, new S.rG(_, m, v));
        }
        function b(g, _, m) {
          var v = _.documentElement;
          if (
            !m.requireValidXML ||
            (v.nodeName !== "parsererror" &&
              !v.getElementsByTagName("parsererror").length)
          )
            return (
              g.responseXML || (g = (0, l.l7)({}, g, { responseXML: _ })),
              m.oncomplete(g)
            );
          k(m, S.ul, 601);
        }
      },
      328: function (c, s, r) {
        r.d(s, {
          ZP: function () {
            return l;
          },
          on: function () {
            return d;
          },
          IH: function () {
            return w;
          },
          S1: function () {
            return S;
          },
          X$: function () {
            return x;
          },
          wj: function () {
            return E;
          },
        });
        var l = (function () {
            function g() {}
            var _ = g.prototype;
            return (
              (_.on = function (m, v, A) {
                if (!k(this, "on", m, [v, A]) || !v) return this;
                var T = this._events || (this._events = {});
                return (
                  (T[m] || (T[m] = [])).push({ callback: v, context: A }), this
                );
              }),
              (_.once = function (m, v, A) {
                if (!k(this, "once", m, [v, A]) || !v) return this;
                var T = 0,
                  j = this,
                  L = function M() {
                    T++ || (j.off(m, M), v.apply(this, arguments));
                  };
                return (L._callback = v), this.on(m, L, A);
              }),
              (_.off = function (m, v, A) {
                if (!this._events || !k(this, "off", m, [v, A])) return this;
                if (!m && !v && !A) return delete this._events, this;
                for (
                  var T = m ? [m] : Object.keys(this._events),
                    j = 0,
                    L = T.length;
                  j < L;
                  j++
                ) {
                  m = T[j];
                  var M = this._events[m];
                  if (M) {
                    var q = (this._events[m] = []);
                    if (v || A)
                      for (var W = 0, ie = M.length; W < ie; W++) {
                        var ne = M[W];
                        ((v &&
                          v !== ne.callback &&
                          v !== ne.callback._callback) ||
                          (A && A !== ne.context)) &&
                          q.push(ne);
                      }
                    q.length || delete this._events[m];
                  }
                }
                return this;
              }),
              (_.trigger = function (m) {
                for (
                  var v = arguments.length,
                    A = new Array(v > 1 ? v - 1 : 0),
                    T = 1;
                  T < v;
                  T++
                )
                  A[T - 1] = arguments[T];
                if (!this._events) return this;
                if (!k(this, "trigger", m, A)) return this;
                var j = this._events[m],
                  L = this._events.all;
                return j && b(j, A, this), L && b(L, arguments, this), this;
              }),
              (_.triggerSafe = function (m) {
                for (
                  var v = arguments.length,
                    A = new Array(v > 1 ? v - 1 : 0),
                    T = 1;
                  T < v;
                  T++
                )
                  A[T - 1] = arguments[T];
                if (!this._events) return this;
                if (!k(this, "trigger", m, A)) return this;
                var j = this._events[m],
                  L = this._events.all;
                return (
                  j && b(j, A, this, m), L && b(L, arguments, this, m), this
                );
              }),
              g
            );
          })(),
          d = l.prototype.on,
          w = l.prototype.once,
          S = l.prototype.off,
          x = l.prototype.trigger,
          E = l.prototype.triggerSafe;
        (l.on = d), (l.once = w), (l.off = S), (l.trigger = x);
        var I = /\s+/;
        function k(g, _, m, v) {
          if (!m) return !0;
          if (typeof m == "object") {
            for (var A in m)
              Object.prototype.hasOwnProperty.call(m, A) &&
                g[_].apply(g, [A, m[A]].concat(v));
            return !1;
          }
          if (I.test(m)) {
            for (var T = m.split(I), j = 0, L = T.length; j < L; j++)
              g[_].apply(g, [T[j]].concat(v));
            return !1;
          }
          return !0;
        }
        function b(g, _, m, v) {
          for (var A = -1, T = g.length; ++A < T; ) {
            var j = g[A];
            if (v)
              try {
                j.callback.apply(j.context || m, _);
              } catch (L) {
                console.log('Error in "' + v + '" event handler:', L);
              }
            else j.callback.apply(j.context || m, _);
          }
        }
      },
      2268: function (c, s, r) {
        function l(ne) {
          return navigator.userAgent.match(ne) !== null;
        }
        r.d(s, {
          pZ: function () {
            return w;
          },
          xb: function () {
            return S;
          },
          zc: function () {
            return x;
          },
          id: function () {
            return E;
          },
          DF: function () {
            return I;
          },
          un: function () {
            return k;
          },
          A: function () {
            return b;
          },
          yS: function () {
            return g;
          },
          Q6: function () {
            return _;
          },
          i7: function () {
            return m;
          },
          w1: function () {
            return v;
          },
          G6: function () {
            return A;
          },
          gn: function () {
            return T;
          },
          O7: function () {
            return j;
          },
          Dt: function () {
            return L;
          },
          tq: function () {
            return M;
          },
          cL: function () {
            return q;
          },
          NO: function () {
            return W;
          },
          dI: function () {
            return ie;
          },
        });
        var d = function () {
            return (
              navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1
            );
          },
          w = function () {
            return l(/firefox\//i);
          },
          S = function () {
            return l(/iP(hone|od)/i);
          },
          x = function () {
            return l(/iPad/i) || d();
          },
          E = function () {
            return l(/Macintosh/i) && !d();
          },
          I = function () {
            return l(/FBAV/i);
          },
          k = function () {
            return l(/\sEdge?\/\d+/i);
          },
          b = function () {
            return l(/msie/i);
          },
          g = function () {
            return l(/SMART-TV/);
          },
          _ = function () {
            return g() && !l(/SamsungBrowser/);
          },
          m = function () {
            return (
              l(/\s(?:(?:Headless)?Chrome|CriOS)\//i) &&
              !k() &&
              !l(/UCBrowser/i)
            );
          },
          v = function () {
            return (
              !l(/\sEdg\/\d+/i) && (k() || l(/trident\/.+rv:\s*11/i) || b())
            );
          },
          A = function () {
            return (
              l(/safari/i) &&
              !l(/(?:Chrome|CriOS|chromium|android|phantom)/i) &&
              !g()
            );
          },
          T = function () {
            return l(/iP(hone|ad|od)/i) || d();
          };
        function j() {
          return (
            !(l(/chrome\/[123456789]/i) && !l(/chrome\/18/i) && !w()) && L()
          );
        }
        var L = function ne() {
          return typeof ne.mock_ == "boolean"
            ? ne.mock_
            : l(/Android/i) && !l(/Windows Phone/i);
        };
        L.mock_ = null;
        var M = function () {
            return T() || L() || l(/Windows Phone/i);
          },
          q = function ne() {
            if (typeof ne.mock_ == "boolean") return ne.mock_;
            try {
              return window.self !== window.top;
            } catch {
              return !0;
            }
          };
        q.mock_ = null;
        var W = function () {
            return !1;
          },
          ie = function () {
            return 0;
          };
      },
      974: function (c, s, r) {
        r.d(s, {
          oI: function () {
            return x;
          },
          iv: function () {
            return E;
          },
          oB: function () {
            return I;
          },
          vs: function () {
            return g;
          },
          HY: function () {
            return _;
          },
        });
        var l,
          d = r(2957),
          w = r(9563),
          S = r.n(w),
          x = S().clear;
        function E(m, v, A, T) {
          A = A || "all-players";
          var j = "";
          if (typeof v == "object") {
            var L = document.createElement("div");
            I(L, v);
            var M = L.style.cssText;
            Object.prototype.hasOwnProperty.call(v, "content") &&
              M &&
              (M = M + ' content: "' + v.content + '";'),
              T && M && (M = M.replace(/;/g, " !important;")),
              (j = "{" + M + "}");
          } else typeof v == "string" && (j = v);
          j !== "" && j !== "{}" ? S().style([[m, m + j]], A) : S().clear(A, m);
        }
        function I(m, v) {
          if (m != null) {
            var A;
            m.length === void 0 && (m = [m]);
            var T = {};
            for (A in v)
              Object.prototype.hasOwnProperty.call(v, A) && (T[A] = b(A, v[A]));
            for (var j = 0; j < m.length; j++) {
              var L = m[j],
                M = void 0;
              if (L != null)
                for (A in T)
                  Object.prototype.hasOwnProperty.call(T, A) &&
                    ((M = k(A)), L.style[M] !== T[A] && (L.style[M] = T[A]));
            }
          }
        }
        function k(m) {
          m = m.split("-");
          for (var v = 1; v < m.length; v++)
            m[v] = m[v].charAt(0).toUpperCase() + m[v].slice(1);
          return m.join("");
        }
        function b(m, v) {
          return v === "" || v == null
            ? ""
            : typeof v == "string" && isNaN(v)
            ? /png|gif|jpe?g/i.test(v) && v.indexOf("url") < 0
              ? "url(" + v + ")"
              : v
            : v === 0 || m === "z-index" || m === "opacity"
            ? "" + v
            : /color/i.test(m)
            ? "#" + (0, d.vk)(v.toString(16).replace(/^0x/i, ""), 6)
            : Math.ceil(v) + "px";
        }
        function g(m, v) {
          I(m, { transform: v });
        }
        function _(m, v) {
          var A = "rgb",
            T = v !== void 0 && v !== 100;
          if ((T && (A += "a"), !l)) {
            var j = document.createElement("canvas");
            (j.height = 1), (j.width = 1), (l = j.getContext("2d"));
          }
          m ? isNaN(parseInt(m, 16)) || (m = "#" + m) : (m = "#000000"),
            l.clearRect(0, 0, 1, 1),
            (l.fillStyle = m),
            l.fillRect(0, 0, 1, 1);
          var L = l.getImageData(0, 0, 1, 1).data;
          return (
            (A += "(" + L[0] + ", " + L[1] + ", " + L[2]),
            T && (A += ", " + v / 100),
            A + ")"
          );
        }
      },
      5004: function (c, s, r) {
        r.d(s, {
          z: function () {
            return l;
          },
        });
        var l =
          Date.now ||
          function () {
            return new Date().getTime();
          };
      },
      2799: function (c, s, r) {
        r.d(s, {
          pv: function () {
            return I;
          },
          az: function () {
            return k;
          },
          nh: function () {
            return b;
          },
          bJ: function () {
            return g;
          },
          oH: function () {
            return _;
          },
          gB: function () {
            return v;
          },
          FK: function () {
            return A;
          },
          s1: function () {
            return L;
          },
          cn: function () {
            return M;
          },
          IV: function () {
            return q;
          },
          L_: function () {
            return W;
          },
          og: function () {
            return ie;
          },
          P$: function () {
            return ne;
          },
          EU: function () {
            return de;
          },
          kq: function () {
            return he;
          },
          cS: function () {
            return $;
          },
          A8: function () {
            return D;
          },
          SH: function () {
            return se;
          },
          AH: function () {
            return xe;
          },
          i3: function () {
            return me;
          },
          nG: function () {
            return pe;
          },
          UM: function () {
            return _e;
          },
          Ww: function () {
            return Te;
          },
        });
        var l,
          d = r(6042),
          w = r(2957),
          S = r(8348),
          x = window.DOMParser,
          E = !0;
        function I(z, O) {
          return z.classList.contains(O);
        }
        function k(z) {
          return g(z).firstChild;
        }
        function b(z, O) {
          de(z),
            (function (U, K) {
              if (K) {
                for (
                  var fe = document.createDocumentFragment(),
                    Pe = g(K).childNodes,
                    ke = 0;
                  ke < Pe.length;
                  ke++
                )
                  fe.appendChild(Pe[ke].cloneNode(!0));
                U.appendChild(fe);
              }
            })(z, O);
        }
        function g(z) {
          var O = (function (fe) {
            if (
              (l ||
                ((l = new x()),
                (E = (function () {
                  try {
                    if (l.parseFromString("", "text/html")) return !0;
                  } catch {}
                  return !1;
                })())),
              E)
            )
              return l.parseFromString(fe, "text/html").body;
            var Pe = document.implementation.createHTMLDocument("");
            return (
              fe.toLowerCase().indexOf("<!doctype") > -1
                ? (Pe.documentElement.innerHTML = fe)
                : (Pe.body.innerHTML = fe),
              Pe.body
            );
          })(z);
          _(O);
          for (var U = O.querySelectorAll("*"), K = U.length; K--; ) v(U[K]);
          return O;
        }
        function _(z) {
          for (
            var O = z.querySelectorAll("script,object,iframe,meta"),
              U = O.length;
            U--;

          ) {
            var K = O[U];
            K.parentNode.removeChild(K);
          }
          return z;
        }
        var m = new RegExp(
          /^((((https?):\/\/)|(mailto:))(%[0-9A-Fa-f]{2}|[-()_.!~*';/?:@&=+$,A-Za-z0-9])+)([).!';/?:,][[:blank:|:blank:]])?$/
        );
        function v(z) {
          for (var O = z.attributes, U = O.length; U--; ) {
            var K = O[U].name;
            if ((/^on/.test(K) && z.removeAttribute(K), /href/.test(K))) {
              var fe = O[U].value;
              /javascript:|javascript&colon;/.test(fe) || !m.test(fe)
                ? z.removeAttribute(K)
                : console.warn("Invalid or unsafe URL");
            }
          }
          return z;
        }
        function A(z) {
          return z + (z.toString().indexOf("%") > 0 ? "" : "px");
        }
        function T(z) {
          return (0, d.HD)(z.className) ? z.className.split(" ") : [];
        }
        function j(z, O) {
          (O = (0, w.fy)(O)), z.className !== O && (z.className = O);
        }
        function L(z) {
          return z.classList ? z.classList : T(z);
        }
        function M(z, O) {
          var U = T(z);
          (Array.isArray(O) ? O : O.split(" ")).forEach(function (K) {
            (0, d.r3)(U, K) || U.push(K);
          }),
            j(z, U.join(" "));
        }
        function q(z, O) {
          var U = T(z),
            K = Array.isArray(O) ? O : O.split(" ");
          j(z, (0, d.e5)(U, K).join(" "));
        }
        function W(z, O, U) {
          var K = z.className || "";
          O.test(K) ? (K = K.replace(O, U)) : U && (K += " " + U), j(z, K);
        }
        function ie(z, O, U) {
          var K = I(z, O);
          (U = (0, d.jn)(U) ? U : !K) !== K && (U ? M(z, O) : q(z, O));
        }
        function ne(z, O, U) {
          z.setAttribute(O, U);
        }
        function de(z) {
          for (; z.firstChild; ) z.removeChild(z.firstChild);
        }
        function he(z) {
          var O = document.createElement("link");
          (O.rel = "stylesheet"),
            (O.href = z),
            document.getElementsByTagName("head")[0].appendChild(O);
        }
        function $(z) {
          z && de(z);
        }
        function D(z) {
          var O = { left: 0, right: 0, width: 0, height: 0, top: 0, bottom: 0 };
          if (!z || !document.body.contains(z)) return O;
          var U = z.getBoundingClientRect(),
            K = window.pageYOffset,
            fe = window.pageXOffset;
          return (
            (U.width || U.height || U.left || U.top) &&
              ((O.left = U.left + fe),
              (O.right = U.right + fe),
              (O.top = U.top + K),
              (O.bottom = U.bottom + K),
              (O.width = U.right - U.left),
              (O.height = U.bottom - U.top)),
            O
          );
        }
        function se(z, O) {
          z.insertBefore(O, z.firstChild);
        }
        function xe(z) {
          return z.nextElementSibling;
        }
        function me(z) {
          return z.previousElementSibling;
        }
        function pe(z, O, U, K) {
          if (
            (U === void 0 && (U = {}),
            K === void 0 && (K = document),
            m.test(z))
          ) {
            var fe = K.createElement("a");
            (fe.href = z),
              (fe.target = O),
              (fe = v((0, d.l7)(fe, U))),
              S.Browser.firefox
                ? fe.dispatchEvent(
                    new MouseEvent("click", {
                      bubbles: !0,
                      cancelable: !0,
                      view: window,
                    })
                  )
                : fe.click();
          }
        }
        function _e() {
          var z = window.screen.orientation;
          return (
            (!!z &&
              (z.type === "landscape-primary" ||
                z.type === "landscape-secondary")) ||
            window.orientation === 90 ||
            window.orientation === -90
          );
        }
        function Te(z) {
          return (function (O) {
            var U = document.createElement("textarea");
            return (U.innerHTML = O), U.value;
          })(z)
            .replace(/&|<|>|"|''/gm, function (O) {
              return "&#" + O.charCodeAt(0) + ";";
            })
            .replace(
              /&#60;(\/?)(b|strong|i|em|p|br|ul|ol|li|h.)&#62;/gim,
              "<$1$2>"
            );
        }
      },
      4429: function (c, s, r) {
        r.d(s, {
          Z: function () {
            return j;
          },
        });
        var l = r(6042),
          d = r(1569),
          w = r(7034),
          S = r(9888),
          x = r(2957),
          E = r(7411),
          I = r(4742);
        function k(L, M) {
          (this.name = L),
            (this.message = M.message || M.toString()),
            (this.error = M);
        }
        var b = r(2268),
          g = r(2799),
          _ = r(974),
          m = r(6886),
          v = r(1261),
          A = r(5499),
          T = r(6234),
          j = (0, l.l7)({}, S, w, d, {
            addClass: g.cn,
            hasClass: g.pv,
            removeClass: g.IV,
            replaceClass: g.L_,
            toggleClass: g.og,
            classList: g.s1,
            styleDimension: g.FK,
            createElement: g.az,
            emptyElement: g.EU,
            addStyleSheet: g.kq,
            bounds: g.A8,
            openLink: g.nG,
            replaceInnerHtml: g.nh,
            css: _.iv,
            clearCss: _.oI,
            style: _.oB,
            transform: _.vs,
            getRgba: _.HY,
            ajax: m.h,
            crossdomain: function (L) {
              var M = window.URL;
              try {
                var q = new M(L, location.origin);
                return (
                  location.protocol + "//" + location.host !=
                  q.protocol + "//" + q.host
                );
              } catch {}
              return !0;
            },
            tryCatch: function (L, M, q) {
              if ((q === void 0 && (q = []), I.Z.debug))
                return L.apply(M || this, q);
              try {
                return L.apply(M || this, q);
              } catch (W) {
                return new k(L.name, W);
              }
            },
            Error: k,
            Timer: E.Z,
            log: A.c,
            genId: T.B,
            between: v.v,
            foreach: function (L, M) {
              for (var q in L)
                Object.prototype.hasOwnProperty.call(L, q) && M(q, L[q]);
            },
            flashVersion: b.dI,
            isIframe: b.cL,
            indexOf: l.cq,
            trim: x.fy,
            pad: x.vk,
            extension: x.AO,
            hms: x.WZ,
            seconds: x.m9,
            prefix: x.O4,
            suffix: x.uA,
            noop: function () {},
          });
      },
      7543: function (c, s, r) {
        function l(d) {
          return (
            !!(d = d || window.event) &&
            /^(?:mouse|pointer|touch|gesture|click|key)/.test(d.type)
          );
        }
        r.d(s, {
          C: function () {
            return l;
          },
        });
      },
      8518: function (c, s, r) {
        r.d(s, {
          tK: function () {
            return _;
          },
          id: function () {
            return m;
          },
          Cq: function () {
            return v;
          },
          G3: function () {
            return T;
          },
          t6: function () {
            return L;
          },
          q2: function () {
            return M;
          },
          Pm: function () {
            return q;
          },
          dl: function () {
            return ie;
          },
          Dq: function () {
            return ne;
          },
          Mh: function () {
            return de;
          },
        });
        var l = r(6042),
          d = r(2268),
          w = r(6886),
          S = r(7034),
          x = r(696),
          E = {},
          I = {
            aa: "Afar",
            ab: "Abkhazian",
            ae: "Avestan",
            af: "Afrikaans",
            ak: "Akan",
            am: "Amharic",
            ar: "Arabic",
            an: "Aragonese",
            as: "Assamese",
            av: "Avaric",
            ay: "Aymara",
            az: "Azerbaijani",
            ba: "Bashkir",
            be: "Belarusian",
            bg: "Bulgarian",
            bh: "Bihari languages",
            bi: "Bislama",
            bm: "Bambara",
            bn: "Bengali",
            bo: "Tibetan",
            br: "Breton",
            bs: "Bosnian",
            ca: "Catalan",
            ce: "Chechen",
            ch: "Chamorro",
            co: "Corsican",
            cr: "Cree",
            cs: "Czech",
            cu: "Church Slavic",
            cv: "Chuvash",
            cy: "Welsh",
            da: "Danish",
            de: "German",
            dv: "Divehi",
            dz: "Dzongkha",
            ee: "Ewe",
            el: "Greek",
            en: "English",
            eo: "Esperanto",
            es: "Spanish",
            et: "Estonian",
            eu: "Basque",
            fa: "Persian",
            ff: "Fulah",
            fi: "Finnish",
            fj: "Fijian",
            fo: "Faroese",
            fr: "French",
            fy: "Western Frisian",
            ga: "Irish",
            gd: "Gaelic",
            gl: "Galician",
            gn: "Guarani",
            gu: "Gujarati",
            gv: "Manx",
            ha: "Hausa",
            he: "Hebrew",
            hi: "Hindi",
            ho: "Hiri Motu",
            hr: "Croatian",
            ht: "Haitian",
            hu: "Hungarian",
            hy: "Armenian",
            hz: "Herero",
            ia: "Interlingua",
            id: "Indonesian",
            ie: "Interlingue",
            ig: "Igbo",
            ii: "Sichuan Yi",
            ik: "Inupiaq",
            io: "Ido",
            is: "Icelandic",
            it: "Italian",
            iu: "Inuktitut",
            ja: "Japanese",
            jv: "Javanese",
            ka: "Georgian",
            kg: "Kongo",
            ki: "Kikuyu",
            kj: "Kuanyama",
            kk: "Kazakh",
            kl: "Kalaallisut",
            km: "Central Khmer",
            kn: "Kannada",
            ko: "Korean",
            kr: "Kanuri",
            ks: "Kashmiri",
            ku: "Kurdish",
            kv: "Komi",
            kw: "Cornish",
            ky: "Kirghiz",
            la: "Latin",
            lb: "Luxembourgish",
            lg: "Ganda",
            li: "Limburgan",
            lo: "Lao",
            ln: "Lingala",
            lt: "Lithuanian",
            lu: "Luba-Katanga",
            lv: "Latvian",
            mg: "Malagasy",
            mh: "Marshallese",
            mi: "Maori",
            mk: "Macedonian",
            ml: "Malayalam",
            mn: "Mongolian",
            mr: "Marathi",
            ms: "Malay",
            mt: "Maltese",
            my: "Burmese",
            na: "Nauru",
            nb: "Bokmål",
            nd: "Ndebele",
            ne: "Nepali",
            ng: "Ndonga",
            nl: "Dutch",
            nn: "Norwegian Nynorsk",
            no: "Norwegian",
            nr: "Ndebele",
            nv: "Navajo",
            ny: "Chichewa",
            oc: "Occitan",
            oj: "Ojibwa",
            om: "Oromo",
            or: "Oriya",
            os: "Ossetian",
            pa: "Panjabi",
            pi: "Pali",
            pl: "Polish",
            pt: "Portuguese",
            ps: "Pushto",
            qu: "Quechua",
            rm: "Romansh",
            rn: "Rundi",
            ro: "Romanian",
            ru: "Russian",
            rw: "Kinyarwanda",
            sa: "Sanskrit",
            sc: "Sardinian",
            sd: "Sindhi",
            se: "Northern Sami",
            sg: "Sango",
            si: "Sinhala",
            sk: "Slovak",
            sl: "Slovenian",
            sm: "Samoan",
            sn: "Shona",
            so: "Somali",
            sq: "Albanian",
            sr: "Serbian",
            ss: "Swati",
            st: "Sotho",
            su: "Sundanese",
            sw: "Swahili",
            sv: "Swedish",
            ta: "Tamil",
            te: "Telugu",
            tg: "Tajik",
            th: "Thai",
            ti: "Tigrinya",
            tk: "Turkmen",
            tl: "Tagalog",
            tn: "Tswana",
            to: "Tonga",
            tr: "Turkish",
            ts: "Tsonga",
            tt: "Tatar",
            tw: "Twi",
            ty: "Tahitian",
            ug: "Uighur",
            uk: "Ukrainian",
            ur: "Urdu",
            uz: "Uzbek",
            ve: "Venda",
            vi: "Vietnamese",
            vo: "Volapük",
            wa: "Walloon",
            wo: "Wolof",
            xh: "Xhosa",
            yi: "Yiddish",
            yo: "Yoruba",
            za: "Zhuang",
            zh: "Chinese",
            zu: "Zulu",
          },
          k = (0, l.U_)(I);
        function b($) {
          var D = g($),
            se = D.indexOf("_");
          return se === -1 ? D : D.substring(0, se);
        }
        function g($) {
          return $.toLowerCase().replace("-", "_");
        }
        function _($) {
          return $
            ? Object.keys($).reduce(function (D, se) {
                return (D[g(se)] = $[se]), D;
              }, {})
            : {};
        }
        function m($) {
          if ($) return $.length === 3 ? $ : I[b($)] || $;
        }
        function v($) {
          return k[$] || "";
        }
        function A($) {
          var D = $.querySelector("html");
          return D ? D.getAttribute("lang") : null;
        }
        var T = function $() {
          if (typeof $.mock_ == "string") return $.mock_;
          var D = A(document);
          if (!D && (0, d.cL)())
            try {
              D = A(window.top.document);
            } catch {}
          return D || navigator.language || "en";
        };
        T.mock_ = null;
        var j = [
          "ar",
          "da",
          "de",
          "el",
          "es",
          "fi",
          "fr",
          "he",
          "id",
          "it",
          "ja",
          "ko",
          "nb",
          "nl",
          "nn",
          "no",
          "oc",
          "pt",
          "ro",
          "ru",
          "sl",
          "sv",
          "th",
          "tr",
          "vi",
          "zh",
        ];
        function L($) {
          return (
            $.charCodeAt(0) === 8207 ||
            /^[\u0591-\u07FF\uFB1D-\uFDFD\uFE70-\uFEFC]/.test($)
          );
        }
        var M = function $(D) {
          return typeof $.mock_ == "boolean" ? $.mock_ : j.indexOf(b(D)) >= 0;
        };
        function q($, D, se) {
          return (0, l.l7)(
            {},
            (function (xe) {
              var me = xe.advertising,
                pe = xe.related,
                _e = xe.sharing,
                Te = xe.abouttext,
                z = (0, l.l7)({}, xe.localization);
              me &&
                ((z.advertising = z.advertising || {}),
                W(z.advertising, me, "admessage"),
                W(z.advertising, me, "cuetext"),
                W(z.advertising, me, "loadingAd"),
                W(z.advertising, me, "podmessage"),
                W(z.advertising, me, "skipmessage"),
                W(z.advertising, me, "skiptext")),
                typeof z.related == "string"
                  ? (z.related = { heading: z.related })
                  : (z.related = z.related || {}),
                pe && W(z.related, pe, "autoplaymessage"),
                _e &&
                  ((z.sharing = z.sharing || {}),
                  W(z.sharing, _e, "heading"),
                  W(z.sharing, _e, "copied")),
                Te && W(z, xe, "abouttext");
              var O = z.close || z.nextUpClose;
              return O && (z.close = O), z;
            })($),
            D[b(se)],
            D[g(se)]
          );
        }
        function W($, D, se) {
          var xe = $[se] || D[se];
          xe && ($[se] = xe);
        }
        M.mock_ = null;
        var ie = function $(D) {
          return typeof $.mock_ == "boolean"
            ? $.mock_
            : (0, S.isDeepKeyCompliant)(x.Z, D, function (se, xe) {
                return typeof xe[se] == "string";
              });
        };
        ie.mock_ = null;
        var ne = function $(D, se) {
          if (typeof $.mock_ == "function") return $.mock_;
          var xe,
            me = E[se];
          if (!me) {
            var pe =
              D +
              "translations/" +
              ((xe = b(se)), (/^n[bn]$/.test(xe) ? "no" : xe) + ".json");
            E[se] = me = new Promise(function (_e, Te) {
              (0, w.h)({
                url: pe,
                oncomplete: _e,
                onerror: function (z, O, U, K) {
                  (E[se] = null), Te(K);
                },
                responseType: "json",
              });
            });
          }
          return me;
        };
        function de($, D) {
          var se = (0, l.l7)({}, $, D);
          return (
            he(se, "errors", $, D),
            he(se, "related", $, D),
            he(se, "sharing", $, D),
            he(se, "advertising", $, D),
            he(se, "shortcuts", $, D),
            he(se, "captionsStyles", $, D),
            se
          );
        }
        function he($, D, se, xe) {
          $[D] = (0, l.l7)({}, se[D], xe[D]);
        }
        ne.mock_ = null;
      },
      5499: function (c, s, r) {
        r.d(s, {
          c: function () {
            return l;
          },
        });
        var l =
          typeof console.log == "function"
            ? console.log.bind(console)
            : function () {};
      },
      1261: function (c, s, r) {
        r.d(s, {
          v: function () {
            return l;
          },
        });
        var l = function (d, w, S) {
          return Math.max(Math.min(d, S), w);
        };
      },
      9888: function (c, s, r) {
        r.r(s),
          r.d(s, {
            getAbsolutePath: function () {
              return w;
            },
            isAbsolutePath: function () {
              return S;
            },
            parseXML: function () {
              return x;
            },
            serialize: function () {
              return E;
            },
            parseDimension: function () {
              return I;
            },
            timeFormat: function () {
              return k;
            },
            timeFormatAria: function () {
              return b;
            },
          });
        var l = r(7034),
          d = r(6042);
        function w(g, _) {
          if (
            ((_ && (0, l.exists)(_)) || (_ = document.location.href),
            !(0, l.exists)(g))
          )
            return "";
          if (S(g)) return g;
          var m,
            v = _.substring(0, _.indexOf("://") + 3),
            A = _.substring(v.length, _.indexOf("/", v.length + 1));
          if (g.indexOf("/") === 0) m = g.split("/");
          else {
            var T = _.split("?")[0];
            m = (T = T.substring(v.length + A.length + 1, T.lastIndexOf("/")))
              .split("/")
              .concat(g.split("/"));
          }
          for (var j = [], L = 0; L < m.length; L++)
            m[L] &&
              (0, l.exists)(m[L]) &&
              m[L] !== "." &&
              (m[L] === ".." ? j.pop() : j.push(m[L]));
          return v + A + "/" + j.join("/");
        }
        function S(g) {
          return /^(?:(?:https?|file):)?\/\//.test(g);
        }
        function x(g) {
          var _ = null;
          try {
            (_ = new window.DOMParser().parseFromString(
              g,
              "text/xml"
            )).querySelector("parsererror") && (_ = null);
          } catch {}
          return _;
        }
        function E(g) {
          if (g === void 0) return null;
          if (typeof g == "string" && g.length < 6) {
            var _ = g.toLowerCase();
            if (_ === "true") return !0;
            if (_ === "false") return !1;
            if (!(0, d.i2)(Number(g)) && !(0, d.i2)(parseFloat(g)))
              return Number(g);
          }
          return g;
        }
        function I(g) {
          return (0, d.qh)(g)
            ? g
            : g === ""
            ? 0
            : g.lastIndexOf("%") > -1
            ? g
            : parseInt(g.replace("px", ""), 10);
        }
        function k(g, _) {
          if (
            ((0, d.i2)(g) && (g = parseInt(g.toString())),
            (0, d.i2)(g) || !isFinite(g) || (g <= 0 && !_))
          )
            return "00:00";
          var m = g < 0 ? "-" : "";
          g = Math.abs(g);
          var v = Math.floor(g / 3600),
            A = Math.floor((g - 3600 * v) / 60),
            T = Math.floor(g % 60);
          return (
            m +
            (v ? v + ":" : "") +
            (A < 10 ? "0" : "") +
            A +
            ":" +
            (T < 10 ? "0" : "") +
            T
          );
        }
        function b(g) {
          if (
            ((0, d.i2)(g) && (g = parseInt(g.toString())),
            (0, d.i2)(g) || !isFinite(g) || g <= 0)
          )
            return "0 seconds";
          var _ = Math.floor(g / 3600),
            m = Math.floor((g - 3600 * _) / 60),
            v = Math.floor(g % 60);
          return (
            (_ ? _ + (_ > 1 ? " hours, " : _ === 1 ? " hour, " : "") : "") +
            (m ? m + (m > 1 ? " minutes, " : m === 1 ? " minute, " : "") : "") +
            v +
            (v !== 1 ? " seconds" : v === 1 ? " second" : "")
          );
        }
      },
      1569: function (c, s, r) {
        r.r(s),
          r.d(s, {
            getScriptPath: function () {
              return w;
            },
            repo: function () {
              return S;
            },
            versionCheck: function () {
              return x;
            },
            loadFrom: function () {
              return E;
            },
          });
        var l = r(6601),
          d = r(7034),
          w = function (I) {
            for (
              var k = document.getElementsByTagName("script"), b = 0;
              b < k.length;
              b++
            ) {
              var g = k[b].src;
              if (g) {
                var _ = g.lastIndexOf("/" + I);
                if (_ >= 0) return g.substr(0, _ + 1);
              }
            }
            return "";
          },
          S = function () {
            var I = "//ssl.p.jwpcdn.com/player/v/8.25.1/";
            return ((0, d.isFileProtocol)() ? "https:" : "") + I;
          },
          x = function (I) {
            var k = ("0" + I).split(/\W/),
              b = l.i.split(/\W/),
              g = parseFloat(k[0]),
              _ = parseFloat(b[0]);
            return (
              !(g > _) &&
              !(g === _ && parseFloat("0" + k[1]) > parseFloat(b[1]))
            );
          },
          E = function () {
            return S();
          };
      },
      6234: function (c, s, r) {
        r.d(s, {
          F: function () {
            return l;
          },
          B: function () {
            return w;
          },
        });
        var l = 12;
        function d() {
          try {
            var S = window.crypto || window.msCrypto;
            if (S && S.getRandomValues)
              return S.getRandomValues(new Uint32Array(1))[0].toString(36);
          } catch {}
          return Math.random().toString(36).slice(2, 9);
        }
        function w(S) {
          for (var x = ""; x.length < S; ) x += d();
          return x.slice(0, S);
        }
      },
      1776: function (c, s, r) {
        r.d(s, {
          U: function () {
            return l;
          },
          W: function () {
            return d;
          },
        });
        var l =
            window.requestAnimationFrame ||
            function (w) {
              return setTimeout(w, 17);
            },
          d = window.cancelAnimationFrame || clearTimeout;
      },
      676: function (c, s, r) {
        var l = r(6042),
          d = r(328),
          w = r(1643),
          S = {};
        function x(k) {
          var b = document.createElement("link");
          return (b.type = "text/css"), (b.rel = "stylesheet"), (b.href = k), b;
        }
        function E(k, b) {
          var g = document.createElement("script");
          return (
            (g.type = "text/javascript"),
            (g.charset = "utf-8"),
            (g.async = !0),
            (g.timeout = b || 45e3),
            (g.src = k),
            g
          );
        }
        var I = function (k, b, g) {
          var _ = this,
            m = 0;
          function v(T) {
            (m = 2), _.trigger(w.pn, T).off();
          }
          function A(T) {
            (m = 3), _.trigger(w.xQ, T).off();
          }
          (this.getStatus = function () {
            return m;
          }),
            (this.load = function () {
              var T = S[k];
              return (
                m !== 0 ||
                  (T && T.then(A).catch(v),
                  (m = 1),
                  (T = new Promise(function (j, L) {
                    var M = (b ? x : E)(k, g),
                      q = function () {
                        (M.onerror = M.onload = null), clearTimeout(ie);
                      },
                      W = function (de) {
                        q(), v(de), L(de);
                      },
                      ie = setTimeout(function () {
                        W(new Error("Network timeout " + k));
                      }, 45e3);
                    (M.onerror = function () {
                      W(new Error("Failed to load " + k));
                    }),
                      (M.onload = function (de) {
                        q(), A(de), j(de);
                      });
                    var ne =
                      document.getElementsByTagName("head")[0] ||
                      document.documentElement;
                    ne.insertBefore(M, ne.firstChild);
                  })),
                  (S[k] = T)),
                T
              );
            });
        };
        (0, l.l7)(I.prototype, d.ZP), (s.ZP = I);
      },
      2957: function (c, s, r) {
        r.d(s, {
          fy: function () {
            return w;
          },
          vk: function () {
            return S;
          },
          Dc: function () {
            return x;
          },
          AO: function () {
            return E;
          },
          WZ: function () {
            return I;
          },
          m9: function () {
            return k;
          },
          U5: function () {
            return b;
          },
          O4: function () {
            return g;
          },
          uA: function () {
            return _;
          },
          zz: function () {
            return m;
          },
        });
        var l = r(6042),
          d = window.parseFloat;
        function w(v) {
          return v.replace(/^\s+|\s+$/g, "");
        }
        function S(v, A, T) {
          for (v = "" + v, T = T || "0"; v.length < A; ) v = T + v;
          return v;
        }
        function x(v, A) {
          for (var T = v.attributes, j = 0; j < T.length; j++)
            if (T[j].name && T[j].name.toLowerCase() === A.toLowerCase())
              return T[j].value.toString();
          return "";
        }
        function E(v) {
          if (!v || v.substr(0, 4) === "rtmp") return "";
          var A = /[(,]format=(m3u8|mpd)-/i.exec(v);
          if (A) return A[1];
          var T = v.replace(/^.+?\.(\w+)(?:[;].*)?(?:[?#].*)?$/, "$1");
          return T !== v
            ? T.toLowerCase()
            : (v = v.split("?")[0].split("#")[0]).lastIndexOf(".") > -1
            ? v.substr(v.lastIndexOf(".") + 1, v.length).toLowerCase()
            : "";
        }
        function I(v) {
          var A = ((v / 60) | 0) % 60,
            T = v % 60;
          return (
            S(((v / 3600) | 0).toString(), 2) +
            ":" +
            S(A.toString(), 2) +
            ":" +
            S(T.toFixed(3), 6)
          );
        }
        function k(v, A) {
          if (!v) return 0;
          if ((0, l.qh)(v)) return v;
          var T = v.replace(",", "."),
            j = T.slice(-1),
            L = T.split(":"),
            M = L.length,
            q = 0;
          if (j === "s") q = d(T);
          else if (j === "m") q = 60 * d(T);
          else if (j === "h") q = 3600 * d(T);
          else if (M > 1) {
            var W = M - 1;
            M === 4 && (A && (q = d(L[W]) / A), (W -= 1)),
              (q += d(L[W])),
              (q += 60 * d(L[W - 1])),
              M >= 3 && (q += 3600 * d(L[W - 2]));
          } else q = d(T);
          return (0, l.qh)(q) ? q : 0;
        }
        function b(v, A, T) {
          if ((0, l.HD)(v) && v.slice(-1) === "%") {
            var j = d(v);
            return A && (0, l.qh)(A) && (0, l.qh)(j) ? (A * j) / 100 : null;
          }
          return k(v, T);
        }
        function g(v, A) {
          return v.map(function (T) {
            return A + T;
          });
        }
        function _(v, A) {
          return v.map(function (T) {
            return T + A;
          });
        }
        function m(v) {
          return !!v && (0, l.HD)(v) && v.slice(-1) === "%";
        }
      },
      5882: function (c, s, r) {
        r.d(s, {
          ZP: function () {
            return M;
          },
          GU: function () {
            return $;
          },
          dO: function () {
            return Te;
          },
        });
        var l = r(8348),
          d = r(1643),
          w = r(328),
          S = r(5004),
          x = r(2799);
        function E(O, U) {
          return (
            (E =
              Object.setPrototypeOf ||
              function (K, fe) {
                return (K.__proto__ = fe), K;
              }),
            E(O, U)
          );
        }
        var I,
          k,
          b = "ontouchstart" in window,
          g = "PointerEvent" in window && !l.OS.android,
          _ = !(g || (b && l.OS.mobile)),
          m = "window",
          v = "init",
          A = "select",
          T = "keydown",
          j = l.Features.passiveEvents,
          L = !!j && { passive: !0 },
          M = (function (O) {
            var U, K;
            function fe(ke, Ce) {
              var P;
              P = O.call(this) || this;
              var R = !(Ce = Ce || {}).preventScrolling;
              return (
                (P.directSelect = !!Ce.directSelect),
                (P.dragged = !1),
                (P.enableDoubleClick = !1),
                (P.el = ke),
                (P.handlers = {}),
                (P.options = {}),
                (P.lastClick = 0),
                (P.lastStart = 0),
                (P.passive = R),
                (P.pointerId = null),
                (P.startX = 0),
                (P.startY = 0),
                (P.event = null),
                (P.clicking = !1),
                P
              );
            }
            (K = O),
              ((U = fe).prototype = Object.create(K.prototype)),
              (U.prototype.constructor = U),
              E(U, K);
            var Pe = fe.prototype;
            return (
              (Pe.on = function (ke, Ce, P) {
                return (
                  W(ke) && (this.handlers[ke] || he[ke](this)),
                  O.prototype.on.call(this, ke, Ce, P)
                );
              }),
              (Pe.off = function (ke, Ce, P) {
                var R = this;
                if (W(ke)) se(this, ke);
                else if (!ke) {
                  var N = this.handlers;
                  Object.keys(N).forEach(function (X) {
                    se(R, X);
                  });
                }
                return O.prototype.off.call(this, ke, Ce, P);
              }),
              (Pe.destroy = function () {
                this.el && (this.off(), g && xe(this), (this.el = null));
              }),
              fe
            );
          })(w.ZP),
          q = /\s+/;
        function W(O) {
          return O && !(q.test(O) || typeof O == "object");
        }
        function ie(O) {
          if (!O.handlers.init) {
            var U = O.el,
              K = O.passive,
              fe = !!j && { passive: K },
              Pe = function (Ce) {
                if (O.dragged) pe(O, d.Wp, Ce);
                else {
                  var P = _e(Ce),
                    R = P.pageX,
                    N = P.pageY,
                    X = R - O.startX,
                    G = N - O.startY;
                  X * X + G * G > 36 &&
                    (pe(O, d.nv, Ce), (O.dragged = !0), pe(O, d.Wp, Ce));
                }
                var Q;
                K ||
                  Ce.type !== "touchmove" ||
                  ((Q = Ce).preventDefault && Q.preventDefault());
              },
              ke = function (Ce) {
                clearTimeout(I),
                  O.el &&
                    (xe(O),
                    se(O, m),
                    O.dragged && ((O.dragged = !1), pe(O, d.Sv, Ce)));
              };
            de(O, v),
              z(
                O,
                v,
                function (Ce) {
                  if (((0, x.IV)(U, "jw-tab-focus"), !Te(Ce))) {
                    var P = Ce.target,
                      R = Ce.type;
                    if (!O.directSelect || P === U) {
                      var N = _e(Ce),
                        X = N.pageX,
                        G = N.pageY;
                      if (
                        ((O.dragged = !1),
                        (O.startX = X),
                        (O.startY = G),
                        se(O, m),
                        R === "pointerdown" && Ce.isPrimary)
                      ) {
                        if (!K) {
                          var Q = Ce.pointerId;
                          (O.pointerId = Q), U.setPointerCapture(Q);
                        }
                        D(O, m, "pointermove", Pe, fe),
                          D(O, m, "pointercancel", ke),
                          D(O, m, "pointerup", ke);
                      } else
                        R === "mousedown"
                          ? (D(O, m, "mousemove", Pe, fe),
                            D(O, m, "mouseup", ke))
                          : R === "touchstart" &&
                            (D(O, m, "touchmove", Pe, fe),
                            D(O, m, "touchcancel", ke),
                            D(O, m, "touchend", ke));
                    }
                  }
                },
                fe
              );
          }
        }
        function ne(O) {
          if (!O.handlers.select) {
            var U = O.el;
            de(O, A),
              z(O, A, function (K) {
                var fe = K.target;
                Te(K) ||
                  (O.directSelect && fe !== U) ||
                  (K.isPrimary && fe.tageName === "BUTTON" && fe.focus(),
                  (O.lastStart = (0, S.z)()),
                  (O.clicking = !0));
              }),
              D(O, A, "click", function (K) {
                Te(K) ||
                  (O.directSelect && K.target !== U) ||
                  (((0, S.z)() - O.lastStart > 500 && O.clicking === !0) ||
                    ((function (fe, Pe) {
                      fe.enableDoubleClick &&
                        ((0, S.z)() - fe.lastClick < 300
                          ? (pe(fe, d.P, Pe), (fe.lastClick = 0))
                          : (fe.lastClick = (0, S.z)()));
                    })(O, K),
                    pe(O, d.ot, K)),
                  (O.clicking = !1));
              });
          }
        }
        function de(O, U) {
          if (
            (k || (k = new M(document).on("interaction")),
            !O.handlers.init && !O.handlers.select)
          ) {
            var K = O.el;
            D(O, U, "blur", function () {
              (0, x.IV)(K, "jw-tab-focus"), (O.clicking = !1);
            }),
              D(O, U, "focus", function () {
                k.event && k.event.type === T && (0, x.cn)(K, "jw-tab-focus");
              });
          }
        }
        var he = {
          drag: function (O) {
            ie(O);
          },
          dragStart: function (O) {
            ie(O);
          },
          dragEnd: function (O) {
            ie(O);
          },
          click: function (O) {
            ne(O);
          },
          doubleClick: function (O) {
            (O.enableDoubleClick = !0), ne(O);
          },
          longPress: function (O) {
            var U = "longPress";
            if (l.OS.iOS) {
              var K = function () {
                clearTimeout(I);
              };
              D(O, U, "touchstart", function (fe) {
                K(),
                  (I = setTimeout(function () {
                    pe(O, U, fe);
                  }, 500));
              }),
                D(O, U, "touchmove", K),
                D(O, U, "touchcancel", K),
                D(O, U, "touchend", K);
            } else
              O.el.oncontextmenu = function (fe) {
                return pe(O, U, fe), !1;
              };
          },
          focus: function (O) {
            var U = "focus";
            D(O, U, U, function (K) {
              me(O, U, K);
            });
          },
          blur: function (O) {
            var U = "blur";
            D(O, U, U, function (K) {
              me(O, U, K);
            });
          },
          over: function (O) {
            (g || _) &&
              D(O, d.B1, g ? "pointerover" : "mouseover", function (U) {
                U.pointerType !== "touch" && pe(O, d.B1, U);
              });
          },
          out: function (O) {
            if (g) {
              var U = O.el;
              D(O, d.U3, "pointerout", function (K) {
                if (K.pointerType !== "touch" && "clientX" in K) {
                  var fe = document.elementFromPoint(K.clientX, K.clientY);
                  U.contains(fe) || pe(O, d.U3, K);
                }
              });
            } else
              _ &&
                D(O, d.U3, "mouseout", function (K) {
                  pe(O, d.U3, K);
                });
          },
          move: function (O) {
            (g || _) &&
              D(O, d.tP, g ? "pointermove" : "mousemove", function (U) {
                U.pointerType !== "touch" && pe(O, d.tP, U);
              });
          },
          enter: function (O) {
            D(O, d.K5, T, function (U) {
              (U.key !== "Enter" && U.keyCode !== 13) ||
                (U.stopPropagation(), me(O, d.K5, U));
            });
          },
          keydown: function (O) {
            D(
              O,
              T,
              T,
              function (U) {
                me(O, T, U);
              },
              !1
            );
          },
          gesture: function (O) {
            var U = "gesture",
              K = function (fe) {
                return pe(O, U, fe);
              };
            D(O, U, "click", K), D(O, U, T, K);
          },
          interaction: function (O) {
            var U = "interaction",
              K = function (fe) {
                O.event = fe;
              };
            D(O, U, "mousedown", K, !0), D(O, U, T, K, !0);
          },
          tap: function () {},
          doubleTap: function () {},
        };
        function $(O) {
          var U = O.ownerDocument || O;
          return U.defaultView || U.parentWindow || window;
        }
        function D(O, U, K, fe, Pe) {
          Pe === void 0 && (Pe = L);
          var ke = O.handlers[U],
            Ce = O.options[U];
          if (
            (ke || ((ke = O.handlers[U] = {}), (Ce = O.options[U] = {})), ke[K])
          )
            throw new Error(U + " " + K + " already registered");
          (ke[K] = fe), (Ce[K] = Pe);
          var P = O.el;
          (U === m ? $(P) : P).addEventListener(K, fe, Pe);
        }
        function se(O, U) {
          var K = O.el,
            fe = O.handlers,
            Pe = O.options,
            ke = U === m ? $(K) : K,
            Ce = fe[U],
            P = Pe[U];
          Ce &&
            (Object.keys(Ce).forEach(function (R) {
              var N = P[R];
              typeof N == "boolean"
                ? ke.removeEventListener(R, Ce[R], N)
                : ke.removeEventListener(R, Ce[R]);
            }),
            (fe[U] = null),
            (Pe[U] = null));
        }
        function xe(O) {
          var U = O.el;
          O.pointerId !== null &&
            (U.releasePointerCapture(O.pointerId), (O.pointerId = null));
        }
        function me(O, U, K) {
          var fe = O.el,
            Pe = K.target;
          O.trigger(U, {
            type: U,
            sourceEvent: K,
            currentTarget: fe,
            target: Pe,
          });
        }
        function pe(O, U, K) {
          var fe = (function (Pe, ke, Ce) {
            var P,
              R = ke.target,
              N = ke.touches,
              X = ke.changedTouches,
              G = ke.pointerType;
            N || X
              ? ((P = N && N.length ? N[0] : X[0]), (G = G || "touch"))
              : ((P = ke), (G = G || "mouse"));
            var Q = P,
              ce = Q.pageX,
              oe = Q.pageY;
            return {
              type: Pe,
              pointerType: G,
              pageX: ce,
              pageY: oe,
              sourceEvent: ke,
              currentTarget: Ce,
              target: R,
            };
          })(U, K, O.el);
          O.trigger(U, fe);
        }
        function _e(O) {
          return O.type.indexOf("touch") === 0
            ? (O.originalEvent || O).changedTouches[0]
            : O;
        }
        function Te(O) {
          return (
            !(!O.ctrlKey || O.type !== "click") ||
            ("which" in O ? O.which === 3 : "button" in O && O.button === 2)
          );
        }
        function z(O, U, K, fe) {
          g
            ? D(O, U, "pointerdown", K, fe)
            : (_ && D(O, U, "mousedown", K, fe), D(O, U, "touchstart", K, fe));
        }
      },
      6042: function (c, s, r) {
        r.d(s, {
          S6: function () {
            return ie;
          },
          UI: function () {
            return de;
          },
          u4: function () {
            return D;
          },
          sE: function () {
            return me;
          },
          hX: function () {
            return _e;
          },
          $6: function () {
            return z;
          },
          Yj: function () {
            return U;
          },
          dp: function () {
            return fe;
          },
          vM: function () {
            return P;
          },
          e1: function () {
            return N;
          },
          r3: function () {
            return X;
          },
          ar: function () {
            return Q;
          },
          _e: function () {
            return ce;
          },
          e5: function () {
            return oe;
          },
          cq: function () {
            return re;
          },
          ak: function () {
            return ve;
          },
          P2: function () {
            return i;
          },
          U_: function () {
            return y;
          },
          ce: function () {
            return C;
          },
          l7: function () {
            return B;
          },
          ei: function () {
            return ee;
          },
          Kn: function () {
            return H;
          },
          mf: function () {
            return Re;
          },
          hj: function () {
            return Ne;
          },
          HD: function () {
            return yt;
          },
          xV: function () {
            return Bt;
          },
          i2: function () {
            return $t;
          },
          jn: function () {
            return sn;
          },
          o8: function () {
            return $n;
          },
          yR: function () {
            return xt;
          },
          a9: function () {
            return Un;
          },
          Cb: function () {
            return Gt;
          },
          wB: function () {
            return an;
          },
          qh: function () {
            return li;
          },
        });
        var l = r(5004),
          d = {},
          w = Array.prototype,
          S = Object.prototype,
          x = Function.prototype,
          E = w.slice,
          I = w.concat,
          k = S.toString,
          b = S.hasOwnProperty,
          g = w.map,
          _ = w.reduce,
          m = w.forEach,
          v = w.filter,
          A = w.every,
          T = w.some,
          j = w.indexOf,
          L = Array.isArray,
          M = Object.keys,
          q = x.bind,
          W = window.isFinite,
          ie = function (F, J, te) {
            var ae, we;
            if (F == null) return F;
            if (m && F.forEach === m) F.forEach(J, te);
            else if (F.length === +F.length) {
              for (ae = 0, we = F.length; ae < we; ae++)
                if (J.call(te, F[ae], ae, F) === d) return;
            } else {
              var Ie = u(F);
              for (ae = 0, we = Ie.length; ae < we; ae++)
                if (J.call(te, F[Ie[ae]], Ie[ae], F) === d) return;
            }
            return F;
          },
          ne = ie,
          de = function (F, J, te) {
            var ae = [];
            return F == null
              ? ae
              : g && F.map === g
              ? F.map(J, te)
              : (ie(F, function (we, Ie, Le) {
                  ae.push(J.call(te, we, Ie, Le));
                }),
                ae);
          },
          he = de,
          $ = "Reduce of empty array with no initial value",
          D = function (F, J, te, ae) {
            var we = arguments.length > 2;
            if ((F == null && (F = []), _ && F.reduce === _))
              return ae && (J = ve(J, ae)), we ? F.reduce(J, te) : F.reduce(J);
            if (
              (ie(F, function (Ie, Le, rt) {
                we ? (te = J.call(ae, te, Ie, Le, rt)) : ((te = Ie), (we = !0));
              }),
              !we)
            )
              throw new TypeError($);
            return te;
          },
          se = D,
          xe = D,
          me = function (F, J, te) {
            var ae;
            return (
              U(F, function (we, Ie, Le) {
                if (J.call(te, we, Ie, Le)) return (ae = we), !0;
              }),
              ae
            );
          },
          pe = me,
          _e = function (F, J, te) {
            var ae = [];
            return F == null
              ? ae
              : v && F.filter === v
              ? F.filter(J, te)
              : (ie(F, function (we, Ie, Le) {
                  J.call(te, we, Ie, Le) && ae.push(we);
                }),
                ae);
          },
          Te = _e,
          z = function (F, J, te) {
            J || (J = xt);
            var ae = !0;
            return F == null
              ? ae
              : A && F.every === A
              ? F.every(J, te)
              : (ie(F, function (we, Ie, Le) {
                  if (!(ae = ae && J.call(te, we, Ie, Le))) return d;
                }),
                !!ae);
          },
          O = z,
          U = function (F, J, te) {
            J || (J = xt);
            var ae = !1;
            return F == null
              ? ae
              : T && F.some === T
              ? F.some(J, te)
              : (ie(F, function (we, Ie, Le) {
                  if (ae || (ae = J.call(te, we, Ie, Le))) return d;
                }),
                !!ae);
          },
          K = U,
          fe = function (F) {
            return F == null
              ? 0
              : F.length === +F.length
              ? F.length
              : u(F).length;
          },
          Pe = function (F, J) {
            var te;
            return function () {
              return (
                --F > 0 && (te = J.apply(this, arguments)),
                F <= 1 && (J = null),
                te
              );
            };
          },
          ke = function (F) {
            return F == null ? xt : Re(F) ? F : Gt(F);
          },
          Ce = function (F) {
            return function (J, te, ae) {
              var we = {};
              return (
                (te = ke(te)),
                ie(J, function (Ie, Le) {
                  var rt = te.call(ae, Ie, Le, J);
                  F(we, rt, Ie);
                }),
                we
              );
            };
          },
          P = Ce(function (F, J, te) {
            Ut(F, J) ? F[J].push(te) : (F[J] = [te]);
          }),
          R = Ce(function (F, J, te) {
            F[J] = te;
          }),
          N = function (F, J, te, ae) {
            for (
              var we = (te = ke(te)).call(ae, J), Ie = 0, Le = F.length;
              Ie < Le;

            ) {
              var rt = (Ie + Le) >>> 1;
              te.call(ae, F[rt]) < we ? (Ie = rt + 1) : (Le = rt);
            }
            return Ie;
          },
          X = function (F, J) {
            return (
              F != null && (F.length !== +F.length && (F = h(F)), re(F, J) >= 0)
            );
          },
          G = X,
          Q = function (F, J) {
            return _e(F, an(J));
          },
          ce = function (F, J) {
            return me(F, an(J));
          },
          oe = function (F) {
            var J = I.apply(w, E.call(arguments, 1));
            return _e(F, function (te) {
              return !X(J, te);
            });
          },
          re = function (F, J, te) {
            if (F == null) return -1;
            var ae = 0,
              we = F.length;
            if (te) {
              if (typeof te != "number")
                return F[(ae = N(F, J))] === J ? ae : -1;
              ae = te < 0 ? Math.max(0, we + te) : te;
            }
            if (j && F.indexOf === j) return F.indexOf(J, te);
            for (; ae < we; ae++) if (F[ae] === J) return ae;
            return -1;
          },
          Y = function () {},
          ve = function (F, J) {
            var te, ae;
            if (q && F.bind === q) return q.apply(F, E.call(arguments, 1));
            if (!Re(F)) throw new TypeError();
            return (
              (te = E.call(arguments, 2)),
              (ae = function () {
                if (!(this instanceof ae))
                  return F.apply(J, te.concat(E.call(arguments)));
                Y.prototype = F.prototype;
                var we = new Y();
                Y.prototype = null;
                var Ie = F.apply(we, te.concat(E.call(arguments)));
                return Object(Ie) === Ie ? Ie : we;
              }),
              ae
            );
          },
          le = function (F) {
            var J = E.call(arguments, 1);
            return function () {
              for (
                var te = 0, ae = J.slice(), we = 0, Ie = ae.length;
                we < Ie;
                we++
              )
                Ut(ae[we], "partial") && (ae[we] = arguments[te++]);
              for (; te < arguments.length; ) ae.push(arguments[te++]);
              return F.apply(this, ae);
            };
          },
          ge = le(Pe, 2),
          Z = function (F, J) {
            var te = E.call(arguments, 2);
            return setTimeout(function () {
              return F.apply(null, te);
            }, J);
          },
          p = le(Z, { partial: le }, 1),
          i = function (F, J, te) {
            var ae,
              we,
              Ie,
              Le = null,
              rt = 0;
            te || (te = {});
            var Nn = function () {
              (rt = te.leading === !1 ? 0 : St()),
                (Le = null),
                (Ie = F.apply(ae, we)),
                (ae = we = null);
            };
            return function () {
              var lr = St();
              rt || te.leading !== !1 || (rt = lr);
              var fi = J - (lr - rt);
              return (
                (ae = this),
                (we = arguments),
                fi <= 0
                  ? (clearTimeout(Le),
                    (Le = null),
                    (rt = lr),
                    (Ie = F.apply(ae, we)),
                    (ae = we = null))
                  : Le || te.trailing === !1 || (Le = setTimeout(Nn, fi)),
                Ie
              );
            };
          },
          u = function (F) {
            if (!H(F)) return [];
            if (M) return M(F);
            var J = [];
            for (var te in F) Ut(F, te) && J.push(te);
            return J;
          },
          h = function (F) {
            for (
              var J = u(F), te = u.length, ae = Array(te), we = 0;
              we < te;
              we++
            )
              ae[we] = F[J[we]];
            return ae;
          },
          y = function (F) {
            for (var J = {}, te = u(F), ae = 0, we = te.length; ae < we; ae++)
              J[F[te[ae]]] = te[ae];
            return J;
          },
          C = function (F) {
            return (
              ie(E.call(arguments, 1), function (J) {
                if (J) for (var te in J) F[te] === void 0 && (F[te] = J[te]);
              }),
              F
            );
          },
          B =
            Object.assign ||
            function (F) {
              return (
                ie(E.call(arguments, 1), function (J) {
                  if (J)
                    for (var te in J)
                      Object.prototype.hasOwnProperty.call(J, te) &&
                        (F[te] = J[te]);
                }),
                F
              );
            },
          ee = function (F) {
            var J = {},
              te = I.apply(w, E.call(arguments, 1));
            return (
              ie(te, function (ae) {
                ae in F && (J[ae] = F[ae]);
              }),
              J
            );
          },
          V =
            L ||
            function (F) {
              return k.call(F) == "[object Array]";
            },
          H = function (F) {
            return F === Object(F);
          },
          ue = [];
        ie(["Function", "String", "Number", "Date", "RegExp"], function (F) {
          ue[F] = function (J) {
            return k.call(J) == "[object " + F + "]";
          };
        }),
          (ue.Function = function (F) {
            return typeof F == "function";
          });
        var be = ue.Date,
          Ge = ue.RegExp,
          Re = ue.Function,
          Ne = ue.Number,
          yt = ue.String,
          Bt = function (F) {
            return W(F) && !$t(parseFloat(F));
          },
          $t = function (F) {
            return Ne(F) && F != +F;
          },
          sn = function (F) {
            return F === !0 || F === !1 || k.call(F) == "[object Boolean]";
          },
          $n = function (F) {
            return F === void 0;
          },
          Ut = function (F, J) {
            return b.call(F, J);
          },
          xt = function (F) {
            return F;
          },
          Un = function (F) {
            return function () {
              return F;
            };
          },
          Gt = function (F) {
            return function (J) {
              return J[F];
            };
          },
          an = function (F) {
            return function (J) {
              if (J === F) return !0;
              for (var te in F) if (F[te] !== J[te]) return !1;
              return !0;
            };
          },
          St = l.z,
          li = function (F) {
            return Ne(F) && !$t(F);
          };
        s.ZP = {
          after: function (F, J) {
            return function () {
              if (--F < 1) return J.apply(this, arguments);
            };
          },
          all: z,
          any: U,
          before: Pe,
          bind: ve,
          clone: function (F) {
            return H(F) ? (V(F) ? F.slice() : B({}, F)) : F;
          },
          collect: he,
          compact: function (F) {
            return _e(F, xt);
          },
          constant: Un,
          contains: X,
          debounce: function (F, J) {
            var te;
            return (
              J === void 0 && (J = 100),
              function () {
                for (
                  var ae = this,
                    we = arguments.length,
                    Ie = new Array(we),
                    Le = 0;
                  Le < we;
                  Le++
                )
                  Ie[Le] = arguments[Le];
                clearTimeout(te),
                  (te = setTimeout(function () {
                    F.apply(ae, Ie);
                  }, J));
              }
            );
          },
          defaults: C,
          defer: p,
          delay: Z,
          detect: pe,
          difference: oe,
          each: ie,
          every: O,
          extend: B,
          filter: _e,
          find: me,
          findWhere: ce,
          foldl: se,
          forEach: ne,
          groupBy: P,
          has: Ut,
          identity: xt,
          include: G,
          indexBy: R,
          indexOf: re,
          inject: xe,
          invert: y,
          isArray: V,
          isBoolean: sn,
          isDate: be,
          isFinite: Bt,
          isFunction: Re,
          isNaN: $t,
          isNull: function (F) {
            return F === null;
          },
          isNumber: Ne,
          isObject: H,
          isRegExp: Ge,
          isString: yt,
          isUndefined: $n,
          isValidNumber: li,
          keys: u,
          last: function (F, J, te) {
            if (F != null)
              return J == null || te
                ? F[F.length - 1]
                : E.call(F, Math.max(F.length - J, 0));
          },
          map: de,
          matches: an,
          max: function (F, J, te) {
            if (!J && V(F) && F[0] === +F[0] && F.length < 65535)
              return Math.max.apply(Math, F);
            var ae = -1 / 0,
              we = -1 / 0;
            return (
              ie(F, function (Ie, Le, rt) {
                var Nn = J ? J.call(te, Ie, Le, rt) : Ie;
                Nn > we && ((ae = Ie), (we = Nn));
              }),
              ae
            );
          },
          memoize: function (F, J) {
            var te = {};
            return (
              J || (J = xt),
              function () {
                var ae = J.apply(this, arguments);
                return Ut(te, ae)
                  ? te[ae]
                  : (te[ae] = F.apply(this, arguments));
              }
            );
          },
          now: St,
          omit: function (F) {
            var J = {},
              te = I.apply(w, E.call(arguments, 1));
            for (var ae in F) X(te, ae) || (J[ae] = F[ae]);
            return J;
          },
          once: ge,
          partial: le,
          pick: ee,
          pluck: function (F, J) {
            return de(F, Gt(J));
          },
          property: Gt,
          propertyOf: function (F) {
            return F == null
              ? function () {}
              : function (J) {
                  return F[J];
                };
          },
          reduce: D,
          reject: function (F, J, te) {
            return _e(
              F,
              function (ae, we, Ie) {
                return !J.call(te, ae, we, Ie);
              },
              te
            );
          },
          result: function (F, J) {
            if (F != null) {
              var te = F[J];
              return Re(te) ? te.call(F) : te;
            }
          },
          select: Te,
          size: fe,
          some: K,
          sortedIndex: N,
          throttle: i,
          where: Q,
          without: function (F) {
            return oe(F, E.call(arguments, 1));
          },
        };
      },
      7034: function (c, s, r) {
        r.r(s),
          r.d(s, {
            exists: function () {
              return d;
            },
            isHTTPS: function () {
              return w;
            },
            isFileProtocol: function () {
              return S;
            },
            isRtmp: function () {
              return x;
            },
            isYouTube: function () {
              return E;
            },
            typeOf: function () {
              return I;
            },
            isDeepKeyCompliant: function () {
              return k;
            },
          });
        var l = window.location.protocol;
        function d(b) {
          switch (typeof b) {
            case "string":
              return b.length > 0;
            case "object":
              return b !== null;
            case "undefined":
              return !1;
            default:
              return !0;
          }
        }
        function w() {
          return l === "https:";
        }
        function S() {
          return l === "file:";
        }
        function x(b, g) {
          return b.indexOf("rtmp:") === 0 || g === "rtmp";
        }
        function E(b, g) {
          return (
            g === "youtube" ||
            /^(http|\/\/).*(youtube\.com|youtu\.be)\/.+/.test(b)
          );
        }
        function I(b) {
          if (b === null) return "null";
          var g = typeof b;
          return g === "object" && Array.isArray(b) ? "array" : g;
        }
        function k(b, g, _) {
          var m = Object.keys(b);
          return (
            Object.keys(g).length >= m.length &&
            m.every(function (v) {
              var A = b[v],
                T = g[v];
              return A && typeof A == "object"
                ? !(!T || typeof T != "object") && k(A, T, _)
                : _(v, b);
            })
          );
        }
      },
      9025: function (c, s) {
        var r = document.createElement("video");
        s.Z = r;
      },
      6601: function (c, s, r) {
        r.d(s, {
          i: function () {
            return l;
          },
        });
        var l =
          "8.25.1+commercial_v8-25-1.497.commercial.868e0b8.hlsjs..jwplayer..dai..freewheel..googima..headerbidding.f58ce95.vast..analytics.9fd4899.analyticskraken.5a09bfc.gapro.";
      },
      4225: function (c, s, r) {
        r.d(s, {
          Z: function () {
            return w;
          },
        });
        var l = r(2799),
          d = r(974);
        function w(S, x) {
          var E = x.message,
            I = x.code,
            k = (function (m, v, A, T) {
              return (
                '<div id="' +
                m +
                '" class="jw-error jw-reset"><div class="jw-error-msg jw-info-overlay jw-reset"><style>[id="' +
                m +
                '"].jw-error{background:#000;overflow:hidden;position:relative}[id="' +
                m +
                '"] .jw-error-msg{top:50%;left:50%;position:absolute;transform:translate(-50%,-50%)}[id="' +
                m +
                '"] .jw-error-text{text-align:start;color:#FFF;font:14px/1.35 Arial,Helvetica,sans-serif}</style><div class="jw-icon jw-reset"></div><div class="jw-info-container jw-reset"><div class="jw-error-text jw-reset-text" dir="auto" data-nosnippet>' +
                (v || "") +
                '<span class="jw-break jw-reset"></span>' +
                (T
                  ? ("(" + A + ": " + T + ")").replace(/\s+/g, "&nbsp;")
                  : "") +
                "</div></div></div></div>"
              );
            })(
              S.get("id"),
              E,
              S.get("localization").errors.errorCode,
              I.toString()
            ),
            b = S.get("width"),
            g = S.get("height"),
            _ = (0, l.az)(k);
          return (
            (0, d.oB)(_, {
              width: b.toString().indexOf("%") > 0 ? b : b + "px",
              height: g.toString().indexOf("%") > 0 ? g : g + "px",
            }),
            _
          );
        }
      },
      9926: function (c, s, r) {
        r.d(s, {
          Z: function () {
            return k;
          },
        });
        var l = r(6042),
          d = r(1776),
          w = r(2799),
          S = r(974),
          x = [],
          E = -1;
        function I() {
          (0, d.W)(E),
            (E = (0, d.U)(function () {
              x.forEach(function (b) {
                b.view.updateBounds();
                var g = b.view.model.get("containerWidth");
                (b.resized = b.width !== g), (b.width = g);
              }),
                x.forEach(function (b) {
                  b.contractElement.scrollLeft = 2 * b.width;
                }),
                x.forEach(function (b) {
                  (0, S.oB)(b.expandChild, { width: b.width + 1 }),
                    b.resized &&
                      b.view.model.get("visibility") &&
                      b.view.updateStyles();
                }),
                x.forEach(function (b) {
                  b.expandElement.scrollLeft = b.width + 1;
                }),
                x.forEach(function (b) {
                  b.resized && b.view.checkResized();
                });
            }));
        }
        var k = (function () {
          function b(g, _, m) {
            var v = { display: "block", position: "absolute", top: 0, left: 0 },
              A = { width: "100%", height: "100%" },
              T = (0, w.az)(
                '<div style="opacity:0;visibility:hidden;overflow:hidden;"><div><div style="height:1px;"></div></div><div class="jw-contract-trigger"></div></div>'
              ),
              j = T.firstChild,
              L = j.firstChild,
              M = j.nextSibling;
            (0, S.oB)([j, M], (0, l.l7)({ overflow: "auto" }, v, A)),
              (0, S.oB)(T, (0, l.l7)({}, v, A)),
              (this.expandElement = j),
              (this.expandChild = L),
              (this.contractElement = M),
              (this.hiddenElement = T),
              (this.element = g),
              (this.view = _),
              (this.model = m),
              (this.width = 0),
              (this.resized = !1),
              g.firstChild ? g.insertBefore(T, g.firstChild) : g.appendChild(T),
              g.addEventListener("scroll", I, !0),
              x.push(this),
              I();
          }
          return (
            (b.prototype.destroy = function () {
              if (this.view) {
                var g = x.indexOf(this);
                g !== -1 && x.splice(g, 1),
                  this.element.removeEventListener("scroll", I, !0),
                  this.element.removeChild(this.hiddenElement),
                  (this.view = this.model = null);
              }
            }),
            b
          );
        })();
      },
      4671: function (c, s, r) {
        var l,
          d = r(6875),
          w = r(8348),
          S = r(2799),
          x = [],
          E = [],
          I = [],
          k = {},
          b = "screen" in window && "orientation" in window.screen,
          g = w.OS.android && w.Browser.chrome,
          _ = !1;
        function m(L, M) {
          for (var q = M.length; q--; ) {
            var W = M[q];
            if (L.target === W.getContainer()) {
              W.setIntersection(L);
              break;
            }
          }
        }
        function v() {
          x.forEach(function (L) {
            var M = L.model;
            if (
              !(
                M.get("audioMode") ||
                M.get("isFloating") ||
                !M.get("controls") ||
                M.get("visibility") < 0.75
              )
            ) {
              var q = M.get("state"),
                W = (0, S.UM)();
              !W && q === "paused" && L.api.getFullscreen()
                ? L.api.setFullscreen(!1)
                : q === "playing" && L.api.setFullscreen(W);
            }
          });
        }
        function A() {
          x.forEach(function (L) {
            L.model.set("activeTab", (0, d.Z)());
          });
        }
        function T(L, M) {
          var q = M.indexOf(L);
          q !== -1 && M.splice(q, 1);
        }
        function j(L) {
          I.forEach(function (M) {
            M(L);
          });
        }
        document.addEventListener("visibilitychange", A),
          document.addEventListener("webkitvisibilitychange", A),
          g && b && window.screen.orientation.addEventListener("change", v),
          window.addEventListener("beforeunload", function () {
            document.removeEventListener("visibilitychange", A),
              document.removeEventListener("webkitvisibilitychange", A),
              window.removeEventListener("scroll", j),
              g &&
                b &&
                window.screen.orientation.removeEventListener("change", v);
          }),
          (s.Z = {
            add: function (L) {
              x.push(L);
            },
            remove: function (L) {
              T(L, x);
            },
            addScrollHandler: function (L) {
              _ || ((_ = !0), window.addEventListener("scroll", j)), I.push(L);
            },
            removeScrollHandler: function (L) {
              var M = I.indexOf(L);
              M !== -1 && I.splice(M, 1);
            },
            addWidget: function (L) {
              E.push(L);
            },
            removeWidget: function (L) {
              T(L, E);
            },
            size: function () {
              return x.length;
            },
            observe: function (L) {
              var M;
              (M = window.IntersectionObserver),
                l ||
                  (l = new M(
                    function (q) {
                      if (q && q.length)
                        for (var W = q.length; W--; ) {
                          var ie = q[W];
                          m(ie, x), m(ie, E);
                        }
                    },
                    {
                      threshold: [
                        0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1,
                      ],
                    }
                  )),
                k[L.id] || ((k[L.id] = !0), l.observe(L));
            },
            unobserve: function (L) {
              l && k[L.id] && (delete k[L.id], l.unobserve(L));
            },
          });
      },
      2445: function (c, s, r) {
        r.d(s, {
          ZP: function () {
            return q;
          },
          qG: function () {
            return M;
          },
        });
        var l = r(6042),
          d = r(5083),
          w = r(1569),
          S = r(7034),
          x = r(817),
          E = r(6599),
          I = r(386),
          k = "__CONTEXTUAL__",
          b = function (W, ie) {
            var ne = W.querySelector(ie);
            if (ne) return ne.getAttribute("content");
          },
          g = r(4737),
          _ = r.n(g),
          m = r(67),
          v = function (W) {
            return (
              typeof W == "string" &&
              /^\/\/(?:content\.jwplatform|cdn\.jwplayer)\.com\//.test(W)
            );
          },
          A = function (W) {
            return "https:" + W;
          },
          T = function (W) {
            var ie = (0, I.Z)(W.edition),
              ne = W.related,
              de = !ie("discovery") || ne !== Object(ne),
              he = !ne || ne.displayMode !== "none",
              $ = ne || {},
              D = $.oncomplete === void 0 ? "none" : $.oncomplete,
              se = $.autoplaytimer;
            D === !1 || W.repeat ? (D = "hide") : D === "none" && (se = 0);
            var xe = (D === "autoplay" && se <= 0) || D === "none";
            return (0, l.l7)({}, ne, {
              disableRelated: de,
              showButton: he,
              oncomplete: D,
              autoplaytimer: se,
              shouldAutoAdvance: xe,
            });
          },
          j = function (W) {
            var ie = window.location.protocol === "file:" ? "https:" : "",
              ne = {
                bidding: "//ssl.p.jwpcdn.com/player/v/8.25.1/bidding.js",
                jwpsrv: "//ssl.p.jwpcdn.com/player/v/8.25.1/jwpsrv.js",
                dai: "//ssl.p.jwpcdn.com/player/v/8.25.1/dai.js",
                vast: "//ssl.p.jwpcdn.com/player/v/8.25.1/vast.js",
                googima: "//ssl.p.jwpcdn.com/player/v/8.25.1/googima.js",
                freewheel: "//ssl.p.jwpcdn.com/player/v/8.25.1/freewheel.js",
                gapro: "//ssl.p.jwpcdn.com/player/v/8.25.1/gapro.js",
              }[W];
            return ne ? ie + ne : "";
          },
          L = function (W, ie, ne) {
            ie && ((W[ie.client || j(ne)] = ie), delete ie.client);
          },
          M = function (W) {
            var ie = (0, l.l7)({}, W.plugins),
              ne = (0, I.Z)(W.edition);
            if (ne("ads")) {
              var de = (0, l.l7)({}, W.advertising),
                he = de.client;
              he && ((ie[j(he) || he] = de), delete de.client),
                de.bids && L(ie, de.bids, "bidding");
            }
            if (ne("jwpsrv")) {
              var $ = W.analytics;
              $ !== Object($) && ($ = {}), L(ie, $, "jwpsrv");
            }
            return L(ie, W.ga, "gapro"), ie;
          },
          q = function (W, ie) {
            var ne,
              de,
              he,
              $ = (0, d.ZP)(W, ie),
              D = $.key || x.default.key,
              se = new E.ZP(D),
              xe = se.edition();
            if (
              (se.edition() === "free" &&
                ($ = (0, l.l7)(
                  {
                    skin: {
                      active: "#ff0046",
                      timeslider: { progress: "none" },
                    },
                    logo: { position: "control-bar", file: _() },
                  },
                  d.ke,
                  (0, l.ei)($, [
                    "analytics",
                    "aspectratio",
                    "base",
                    "file",
                    "height",
                    "playlist",
                    "sources",
                    "width",
                  ])
                )),
              ($.key = D),
              ($.edition = xe),
              ($.error = se.error()),
              ($.generateSEOMetadata = $.generateSEOMetadata || !1),
              xe === "unlimited")
            ) {
              var me = (0, w.getScriptPath)("jwplayer.js");
              if (!me)
                throw new Error(
                  "Error setting up player: Could not locate jwplayer.js script tag"
                );
              r.p = me;
            }
            if (
              (($.related = T($)),
              $.ab &&
                ($.ab = (function (z) {
                  var O = z.ab;
                  return (
                    O.clone && (O = O.clone()),
                    Object.keys(O.tests).forEach(function (U) {
                      O.tests[U].forEach(function (K) {
                        K.addConfig && K.addConfig(z, K.selection);
                      });
                    }),
                    O
                  );
                })($)),
              ($.plugins = M($)),
              (ne = $.playlist),
              (0, l.HD)(ne) &&
                ne.indexOf(k) > -1 &&
                (($.playlist = (function (z, O) {
                  var U = (z.querySelector("title") || {}).textContent,
                    K = b(z, 'meta[property="og:title"]'),
                    fe = encodeURIComponent(K || U || ""),
                    Pe =
                      b(z, 'meta[property="og:description"]') ||
                      b(z, 'meta[name="description"]');
                  return (
                    Pe && (fe += "&page_description=" + encodeURIComponent(Pe)),
                    O.replace(k, fe)
                  );
                })(document, $.playlist)),
                ($.contextual = !0)),
              (0, S.isFileProtocol)())
            ) {
              var pe = $,
                _e = pe.playlist,
                Te = pe.related;
              v(_e) && ($.playlist = A(_e)),
                Te && v(Te.file) && (Te.file = A(Te.file));
            }
            return (
              $.__abSendDomainToFeeds &&
                ((he = $.playlist),
                /\.jwplatform.com|\.jwplayer.com/.test(he)) &&
                ($.playlist =
                  (de = $.playlist) +
                  (de.indexOf("?") !== -1 ? "&" : "?") +
                  "page_domain=" +
                  encodeURIComponent((0, m.X)())),
              $
            );
          };
      },
      817: function (c, s, r) {
        r.d(s, {
          default: function () {
            return u;
          },
        });
        var l = r(6042),
          d = setTimeout;
        function w() {}
        function S(h) {
          if (!(this instanceof S))
            throw new TypeError("Promises must be constructed via new");
          if (typeof h != "function") throw new TypeError("not a function");
          (this._state = 0),
            (this._handled = !1),
            (this._value = void 0),
            (this._deferreds = []),
            g(h, this);
        }
        function x(h, y) {
          for (; h._state === 3; ) h = h._value;
          h._state !== 0
            ? ((h._handled = !0),
              S._immediateFn(function () {
                var C = h._state === 1 ? y.onFulfilled : y.onRejected;
                if (C !== null) {
                  var B;
                  try {
                    B = C(h._value);
                  } catch (ee) {
                    return void I(y.promise, ee);
                  }
                  E(y.promise, B);
                } else (h._state === 1 ? E : I)(y.promise, h._value);
              }))
            : h._deferreds.push(y);
        }
        function E(h, y) {
          try {
            if (y === h)
              throw new TypeError("A promise cannot be resolved with itself.");
            if (y && (typeof y == "object" || typeof y == "function")) {
              var C = y.then;
              if (y instanceof S)
                return (h._state = 3), (h._value = y), void k(h);
              if (typeof C == "function")
                return void g(
                  ((B = C),
                  (ee = y),
                  function () {
                    B.apply(ee, arguments);
                  }),
                  h
                );
            }
            (h._state = 1), (h._value = y), k(h);
          } catch (V) {
            I(h, V);
          }
          var B, ee;
        }
        function I(h, y) {
          (h._state = 2), (h._value = y), k(h);
        }
        function k(h) {
          h._state === 2 &&
            h._deferreds.length === 0 &&
            S._immediateFn(function () {
              h._handled || S._unhandledRejectionFn(h._value);
            });
          for (var y = 0, C = h._deferreds.length; y < C; y++)
            x(h, h._deferreds[y]);
          h._deferreds = null;
        }
        function b(h, y, C) {
          (this.onFulfilled = typeof h == "function" ? h : null),
            (this.onRejected = typeof y == "function" ? y : null),
            (this.promise = C);
        }
        function g(h, y) {
          var C = !1;
          try {
            h(
              function (B) {
                C || ((C = !0), E(y, B));
              },
              function (B) {
                C || ((C = !0), I(y, B));
              }
            );
          } catch (B) {
            if (C) return;
            (C = !0), I(y, B);
          }
        }
        (S.prototype.catch = function (h) {
          return this.then(null, h);
        }),
          (S.prototype.then = function (h, y) {
            var C = new this.constructor(w);
            return x(this, new b(h, y, C)), C;
          }),
          (S.prototype.finally = function (h) {
            var y = this.constructor;
            return this.then(
              function (C) {
                return y.resolve(h()).then(function () {
                  return C;
                });
              },
              function (C) {
                return y.resolve(h()).then(function () {
                  return y.reject(C);
                });
              }
            );
          }),
          (S.all = function (h) {
            return new S(function (y, C) {
              if (!h || h.length === void 0)
                throw new TypeError("Promise.all accepts an array");
              var B = Array.prototype.slice.call(h);
              if (B.length === 0) return y([]);
              var ee = B.length;
              function V(ue, be) {
                try {
                  if (
                    be &&
                    (typeof be == "object" || typeof be == "function")
                  ) {
                    var Ge = be.then;
                    if (typeof Ge == "function")
                      return void Ge.call(
                        be,
                        function (Re) {
                          V(ue, Re);
                        },
                        C
                      );
                  }
                  (B[ue] = be), --ee == 0 && y(B);
                } catch (Re) {
                  C(Re);
                }
              }
              for (var H = 0; H < B.length; H++) V(H, B[H]);
            });
          }),
          (S.resolve = function (h) {
            return h && typeof h == "object" && h.constructor === S
              ? h
              : new S(function (y) {
                  y(h);
                });
          }),
          (S.reject = function (h) {
            return new S(function (y, C) {
              C(h);
            });
          }),
          (S.race = function (h) {
            return new S(function (y, C) {
              for (var B = 0, ee = h.length; B < ee; B++) h[B].then(y, C);
            });
          }),
          (S._immediateFn =
            (typeof setImmediate == "function" &&
              function (h) {
                setImmediate(h);
              }) ||
            function (h) {
              d(h, 0);
            }),
          (S._unhandledRejectionFn = function (h) {
            typeof console < "u" &&
              console &&
              console.warn("Possible Unhandled Promise Rejection:", h);
          });
        var _ = S;
        window.Promise || (window.Promise = _);
        var m = r(1569),
          v = r(6391),
          A = r(2963),
          T = r(670),
          j = { availableProviders: A.B, registerProvider: T.Z },
          L = r(1241);
        j.registerPlugin = function (h, y, C) {
          h !== "jwpsrv" && (0, L.f)(h, y, C);
        };
        var M = j,
          q = r(6601),
          W = r(4742),
          ie = r(8348),
          ne = r(623),
          de = r(1643),
          he = r(7411),
          $ = r(328),
          D = r(4429),
          se = 0;
        function xe(h, y) {
          var C = new ne.Z(y);
          return (
            C.on(de.Rc, function (B) {
              h._qoe.tick("ready"),
                (B.setupTime = h._qoe.between("setup", "ready"));
            }),
            C.on("all", function (B, ee) {
              h.trigger(B, ee);
            }),
            C
          );
        }
        function me(h, y) {
          var C = h.plugins,
            B = Object.keys(C).map(function (ee) {
              var V = C[ee];
              return delete C[ee], V;
            });
          y.get("setupConfig") && h.trigger("remove"),
            h.off(),
            y.playerDestroy(),
            B.forEach(function (ee) {
              if (ee.destroy)
                try {
                  ee.destroy();
                } catch {}
            }),
            y.getContainer().removeAttribute("data-jwplayer-id");
        }
        function pe(h) {
          var y = ++se,
            C = h.id || "player-" + y,
            B = new he.Z(),
            ee = {},
            V = xe(this, h);
          B.tick("init"),
            h.setAttribute("data-jwplayer-id", C),
            Object.defineProperties(this, {
              id: {
                enumerable: !0,
                get: function () {
                  return C;
                },
              },
              uniqueId: {
                enumerable: !0,
                get: function () {
                  return y;
                },
              },
              plugins: {
                enumerable: !0,
                get: function () {
                  return ee;
                },
              },
              _qoe: {
                enumerable: !0,
                get: function () {
                  return B;
                },
              },
              version: {
                enumerable: !0,
                get: function () {
                  return q.i;
                },
              },
              Events: {
                enumerable: !0,
                get: function () {
                  return $.ZP;
                },
              },
              utils: {
                enumerable: !0,
                get: function () {
                  return D.Z;
                },
              },
              _: {
                enumerable: !0,
                get: function () {
                  return l.ZP;
                },
              },
            }),
            (0, l.l7)(this, {
              _events: {},
              setup: function (H) {
                return (
                  B.clear("ready"),
                  B.tick("setup"),
                  V && me(this, V),
                  (V = xe(this, h)).init(H, this),
                  this.on(H.events, null, this)
                );
              },
              remove: function () {
                return (
                  this.getPip() && this.setPip(!1),
                  (function (H) {
                    for (var ue = v.Z.length; ue--; )
                      if (v.Z[ue].uniqueId === H.uniqueId) {
                        v.Z.splice(ue, 1);
                        break;
                      }
                  })(this),
                  V && me(this, V),
                  Object.keys(ee).forEach(function (H) {
                    delete ee[H];
                  }),
                  this
                );
              },
              qoe: function () {
                var H = V.getItemQoe();
                return {
                  setupTime: this._qoe.between("setup", "ready"),
                  firstFrame: H.getFirstFrame ? H.getFirstFrame() : null,
                  player: this._qoe.dump(),
                  item: H.dump(),
                };
              },
              addCues: function (H) {
                return Array.isArray(H) && V.addCues(H), this;
              },
              getAudioTracks: function () {
                return V.getAudioTracks();
              },
              getBuffer: function () {
                return V.get("buffer");
              },
              getCaptions: function () {
                return V.get("captions");
              },
              getCaptionsList: function () {
                return V.getCaptionsList();
              },
              getConfig: function () {
                return V.getConfig();
              },
              getContainer: function () {
                return V.getContainer();
              },
              getControls: function () {
                return V.get("controls");
              },
              getCues: function () {
                return V.get("cues");
              },
              getCurrentAudioTrack: function () {
                return V.getCurrentAudioTrack();
              },
              getCurrentCaptions: function () {
                return V.getCurrentCaptions();
              },
              getCurrentQuality: function () {
                return V.getCurrentQuality();
              },
              getCurrentTime: function () {
                return V.get("currentTime");
              },
              getDuration: function () {
                return V.get("duration");
              },
              getEnvironment: function () {
                return ie;
              },
              getFullscreen: function () {
                return V.get("fullscreen");
              },
              getHeight: function () {
                return V.getHeight();
              },
              getItemMeta: function () {
                return V.get("itemMeta") || {};
              },
              getMute: function () {
                return V.getMute();
              },
              getPercentViewable: function () {
                return V.get("visibility");
              },
              getPip: function () {
                return V.get("pip");
              },
              getPlaybackRate: function () {
                return V.get("playbackRate");
              },
              getPlaylist: function () {
                return V.get("playlist");
              },
              getPlaylistIndex: function () {
                return V.get("item");
              },
              getPlaylistItem: function (H) {
                if (!D.Z.exists(H)) return V.get("playlistItem");
                var ue = this.getPlaylist();
                return ue ? ue[H] : null;
              },
              getPosition: function () {
                return V.get("position");
              },
              getProvider: function () {
                return V.getProvider();
              },
              getQualityLevels: function () {
                return V.getQualityLevels();
              },
              getSafeRegion: function (H) {
                return H === void 0 && (H = !0), V.getSafeRegion(H);
              },
              getState: function () {
                return V.getState();
              },
              getStretching: function () {
                return V.get("stretching");
              },
              getViewable: function () {
                return V.get("viewable");
              },
              getVisualQuality: function () {
                return V.getVisualQuality();
              },
              getVolume: function () {
                return V.get("volume");
              },
              getWidth: function () {
                return V.getWidth();
              },
              setCaptions: function (H) {
                return V.setCaptions(H), this;
              },
              setConfig: function (H) {
                return V.setConfig(H), this;
              },
              setControls: function (H) {
                return V.setControls(H), this;
              },
              setCurrentAudioTrack: function (H) {
                V.setCurrentAudioTrack(H);
              },
              setCurrentCaptions: function (H) {
                V.setCurrentCaptions(H);
              },
              setCurrentQuality: function (H) {
                V.setCurrentQuality(H);
              },
              setFullscreen: function (H) {
                return V.setFullscreen(H), this;
              },
              setAllowFullscreen: function (H) {
                return V.setAllowFullscreen(H), this;
              },
              setMute: function (H) {
                return V.setMute(H), this;
              },
              setPip: function (H) {
                return V.setPip(H), this;
              },
              setPlaybackRate: function (H) {
                return V.setPlaybackRate(H), this;
              },
              setPlaylistItem: function (H, ue) {
                return V.setPlaylistItem(H, ue), this;
              },
              setCues: function (H) {
                return Array.isArray(H) && V.setCues(H), this;
              },
              setVolume: function (H) {
                return V.setVolume(H), this;
              },
              load: function (H, ue) {
                return V.load(H, ue), this;
              },
              play: function (H) {
                return V.play(H), this;
              },
              pause: function (H) {
                return V.pause(H), this;
              },
              playToggle: function (H) {
                switch (this.getState()) {
                  case de.r0:
                  case de.Kb:
                    return this.pause(H);
                  default:
                    return this.play(H);
                }
              },
              seek: function (H, ue) {
                return V.seek(H, ue), this;
              },
              playlistItem: function (H, ue) {
                return V.playlistItem(H, ue), this;
              },
              playlistNext: function (H) {
                return V.playlistNext(H), this;
              },
              playlistPrev: function (H) {
                return V.playlistPrev(H), this;
              },
              next: function (H) {
                return V.next(H), this;
              },
              requestPip: function (H) {
                return V.requestPip(H), this;
              },
              castToggle: function () {
                return V.castToggle(), this;
              },
              stopCasting: function () {
                return V.stopCasting(), this;
              },
              createInstream: function () {
                return V.createInstream();
              },
              stop: function () {
                return V.stop(), this;
              },
              resize: function (H, ue) {
                return V.resize(H, ue), this;
              },
              addButton: function (H, ue, be, Ge, Re) {
                return V.addButton(H, ue, be, Ge, Re), this;
              },
              removeButton: function (H) {
                return V.removeButton(H), this;
              },
              attachMedia: function () {
                return V.attachMedia(), this;
              },
              detachMedia: function () {
                return V.detachMedia(), this;
              },
              isBeforeComplete: function () {
                return V.isBeforeComplete();
              },
              isBeforePlay: function () {
                return V.isBeforePlay();
              },
              setPlaylistItemCallback: function (H, ue) {
                V.setItemCallback(H, ue);
              },
              removePlaylistItemCallback: function () {
                V.setItemCallback(null);
              },
              getPlaylistItemPromise: function (H) {
                return V.getItemPromise(H);
              },
              getFloating: function () {
                return !!V.get("isFloating");
              },
              setFloating: function (H) {
                V.setConfig({ floating: { mode: H ? "always" : "never" } });
              },
            });
        }
        (0, l.l7)(pe.prototype, {
          on: function (h, y, C) {
            return $.on.call(this, h, y, C);
          },
          once: function (h, y, C) {
            return $.IH.call(this, h, y, C);
          },
          off: function (h, y, C) {
            return $.S1.call(this, h, y, C);
          },
          trigger: function (h, y) {
            return (
              ((y = l.ZP.isObject(y) ? (0, l.l7)({}, y) : {}).type = h),
              W.Z.debug ? $.X$.call(this, h, y) : $.wj.call(this, h, y)
            );
          },
          getPlugin: function (h) {
            return this.plugins[h];
          },
          addPlugin: function (h, y) {
            (this.plugins[h] = y),
              this.on("ready", y.addToPlayer),
              y.resize && this.on("resize", y.resizeHandler);
          },
          registerPlugin: function (h, y, C) {
            (0, L.f)(h, y, C);
          },
          getAdBlock: function () {
            return !1;
          },
          playAd: function (h) {},
          pauseAd: function (h) {},
          skipAd: function () {},
        }),
          (r.p = (0, m.loadFrom)());
        var _e = function (h) {
          var y, C;
          if (
            (h
              ? typeof h == "string"
                ? (y = Te(h)) || (C = document.getElementById(h))
                : typeof h == "number"
                ? (y = v.Z[h])
                : h.nodeType &&
                  (y = Te((C = h).id || C.getAttribute("data-jwplayer-id")))
              : (y = v.Z[0]),
            y)
          )
            return y;
          if (C) {
            var B = new pe(C);
            return v.Z.push(B), B;
          }
          return { registerPlugin: L.f };
        };
        function Te(h) {
          for (var y = 0; y < v.Z.length; y++)
            if (v.Z[y].id === h) return v.Z[y];
          return null;
        }
        function z(h) {
          Object.defineProperties(h, {
            api: {
              get: function () {
                return M;
              },
              set: function () {},
            },
            version: {
              get: function () {
                return q.i;
              },
              set: function () {},
            },
            debug: {
              get: function () {
                return W.Z.debug;
              },
              set: function (y) {
                W.Z.debug = !!y;
              },
            },
          });
        }
        z(_e);
        var O = _e,
          U = r(5882),
          K = r(6599),
          fe = r(676),
          Pe = r(5592),
          ke = r(6769),
          Ce = r(9025),
          P = l.ZP.extend,
          R = {};
        (R._ = l.ZP),
          (R.utils = (0, l.l7)(D.Z, {
            key: K.ZP,
            extend: P,
            scriptloader: fe.ZP,
            rssparser: { parse: ke.Z },
            tea: Pe.p,
            UI: U.ZP,
          })),
          (R.utils.css.style = R.utils.style),
          (R.vid = Ce.Z);
        var N = R,
          X = r(7543),
          G = /^(?:on(?:ce)?|off|trigger)$/,
          Q = function (h, y, C) {
            var B = h.getConfig()[C];
            return (y[C] = B), B;
          },
          ce = function (h) {
            console.warn(
              "The API method jwplayer()." +
                h +
                "() is disabled in the free edition of JW Player."
            );
          },
          oe = function (h, y) {
            var C = {
              reason:
                !(h === "play" || h === "seek" || h === "pause") && (0, X.C)()
                  ? "interaction"
                  : "external",
            };
            switch (h) {
              case "play":
              case "pause":
              case "playToggle":
              case "playlistNext":
              case "playlistPrev":
              case "next":
                y[0] = C;
                break;
              case "seek":
              case "playlistItem":
                y[1] = C;
            }
          },
          re = function (h, y, C) {
            try {
              var B = (function (ee, V) {
                switch (ee) {
                  case "setup":
                    return !!V;
                  case "getSafeRegion":
                  case "pauseAd":
                  case "setControls":
                  case "setFullscreen":
                  case "setMute":
                    return !!V === V ? V : void 0;
                  case "setPlaylistItem":
                  case "getPlaylistItem":
                    return (0 | V) === V ? V : void 0;
                  case "setPlaybackRate":
                  case "setVolume":
                    return Number(V);
                  case "setConfig":
                    return Object.keys(Object(V)).join(",");
                  case "on":
                  case "once":
                  case "off":
                  case "trigger":
                  case "getPlugin":
                  case "addPlugin":
                  case "registerPlugin":
                    return "" + V;
                }
                return null;
              })(y, C);
              h.trackExternalAPIUsage(y, B);
            } catch (ee) {
              W.Z.debug && console.warn(ee);
            }
          },
          Y = function (h, y) {
            if (y.length) {
              var C = h.getPlugin("jwpsrv");
              C &&
                C.trackExternalAPIUsage &&
                (y.forEach(function (B) {
                  re(C, B[0], B[1]);
                }),
                (y.length = 0));
            }
          },
          ve = function h(y, C, B, ee, V) {
            return function () {
              for (
                var H = arguments.length, ue = new Array(H), be = 0;
                be < H;
                be++
              )
                ue[be] = arguments[be];
              var Ge = ue[0],
                Re = C._trackCallQueue || (C._trackCallQueue = []),
                Ne = G.test(B),
                yt = Ne && ue[1] && ue[1]._callback,
                Bt = V.edition || Q(C, V, "edition"),
                $t = Bt === "free";
              if ($t) {
                var sn = [
                  "addButton",
                  "addCues",
                  "detachMedia",
                  "load",
                  "next",
                  "pause",
                  "play",
                  "playlistItem",
                  "playlistNext",
                  "playlistPrev",
                  "playToggle",
                  "resize",
                  "seek",
                  "setCaptions",
                  "setConfig",
                  "setControls",
                  "setCues",
                  "setFullscreen",
                  "setMute",
                  "setPlaybackRate",
                  "setPlaylistItem",
                  "setVolume",
                  "stop",
                ];
                if (sn.indexOf(B) > -1) return ce(B), y;
                var $n = [
                  "createInstream",
                  "setCurrentAudioTrack",
                  "setCurrentCaptions",
                  "setCurrentQuality",
                ];
                if ($n.indexOf(B) > -1) return ce(B), null;
              }
              if ((yt || Re.push([B, Ge]), Ne))
                return Y(C, Re), C[B].apply(y, ue);
              oe(B, ue);
              var Ut = C[B].apply(C, ue);
              return (
                B === "remove"
                  ? C.off.call(y)
                  : B === "setup" &&
                    (C.off.call(y),
                    C.off(Ge.events, null, C),
                    C.on.call(y, Ge.events, null, y),
                    C.on("all", function (xt, Un) {
                      if (xt === "ready") {
                        var Gt = Object.keys(C).filter(function (St) {
                            return (
                              St[0] !== "_" &&
                              ee.indexOf(St) === -1 &&
                              typeof C[St] == "function"
                            );
                          }),
                          an = ee.concat(Gt);
                        Gt.forEach(function (St) {
                          y[St] = h(y, C, St, an, V);
                        });
                      }
                      C.trigger.call(y, xt, Un), Y(C, Re);
                    })),
                Y(C, Re),
                Ut === C ? y : Ut
              );
            };
          },
          le = function (h, y, C, B) {
            var ee = Object.keys(C);
            ee.forEach(function (V) {
              typeof C[V] == "function" && V !== "Events"
                ? (h[V] = ve(h, y, V, ee, B))
                : V === "_events"
                ? (h._events = {})
                : Object.defineProperty(h, V, {
                    enumerable: !0,
                    get: function () {
                      return C[V];
                    },
                  });
            });
          },
          ge = function (h) {
            var y = {};
            le(this, h, h, y), le(this, h, pe.prototype, y);
          },
          Z = window;
        (0, l.l7)(O, N);
        var p = function (h) {
          var y = O(h);
          return y.uniqueId ? y._publicApi || (y._publicApi = new ge(y)) : y;
        };
        (0, l.l7)(p, N),
          z(p),
          typeof Z.define == "function" &&
            Z.define.amd &&
            Z.define([], function () {
              return p;
            });
        var i = p;
        Z.jwplayer && (i = Z.jwplayer);
        var u = i;
      },
      3487: function (c, s, r) {
        r.d(s, {
          MK: function () {
            return d;
          },
          Nq: function () {
            return w;
          },
          bX: function () {
            return S;
          },
        });
        var l = r(7164),
          d = l.MK,
          w = l.Nq,
          S = function (x) {
            var E = (0, l.bX)(x);
            if (!x) return E;
            switch ((0, l.Nq)(x)) {
              case "jwpsrv":
                E = 305001;
                break;
              case "googima":
                E = 305002;
                break;
              case "vast":
                E = 305003;
                break;
              case "freewheel":
                E = 305004;
                break;
              case "dai":
                E = 305005;
                break;
              case "gapro":
                E = 305006;
                break;
              case "bidding":
                E = 305007;
            }
            return E;
          };
      },
      1918: function (c, s, r) {
        r.d(s, {
          w0: function () {
            return E;
          },
          lD: function () {
            return I;
          },
          Gb: function () {
            return k;
          },
          d3: function () {
            return b;
          },
        });
        var l,
          d = r(386),
          w = [
            { configName: "clearkey", keyName: "org.w3.clearkey" },
            { configName: "widevine", keyName: "com.widevine.alpha" },
            { configName: "playready", keyName: "com.microsoft.playready" },
          ],
          S = [],
          x = {};
        function E(g) {
          return g.some(function (_) {
            return (
              !!_.drm ||
              _.sources.some(function (m) {
                return !!m.drm;
              })
            );
          });
        }
        function I(g) {
          return (
            l ||
            (((navigator.requestMediaKeySystemAccess &&
              window.MediaKeySystemAccess.prototype.getConfiguration) ||
              window.MSMediaKeys) &&
            (0, d.Z)(g)("drm")
              ? (w.forEach(function (_) {
                  var m,
                    v,
                    A = ((m = _.keyName),
                    (v = [
                      {
                        initDataTypes: ["cenc"],
                        videoCapabilities: [
                          { contentType: 'video/mp4;codecs="avc1.4d401e"' },
                        ],
                        audioCapabilities: [
                          { contentType: 'audio/mp4;codecs="mp4a.40.2"' },
                        ],
                      },
                    ]),
                    navigator.requestMediaKeySystemAccess
                      ? navigator.requestMediaKeySystemAccess(m, v)
                      : new Promise(function (T, j) {
                          var L;
                          try {
                            L = new window.MSMediaKeys(m);
                          } catch (M) {
                            return void j(M);
                          }
                          T(L);
                        }))
                      .then(function () {
                        x[_.configName] = !0;
                      })
                      .catch(function () {
                        x[_.configName] = !1;
                      });
                  S.push(A);
                }),
                (l = Promise.all(S)))
              : Promise.resolve())
          );
        }
        function k(g) {
          return x[g];
        }
        function b(g) {
          if (l)
            return Object.keys(g).some(function (_) {
              return k(_);
            });
        }
      },
      2963: function (c, s, r) {
        r.d(s, {
          B: function () {
            return g;
          },
        });
        var l = r(6593),
          d = r(8348),
          w = r(386),
          S = r(6042),
          x = r(1918),
          E = r(9025),
          I = (0, S.sE)(l.B, (0, S.wB)({ name: "html5" })),
          k = I.supports;
        function b(_) {
          var m = window.MediaSource;
          return (0, S.$6)(_, function (v) {
            return !!m && !!m.isTypeSupported && m.isTypeSupported(v);
          });
        }
        (I.supports = function (_, m) {
          var v = k.apply(this, arguments);
          if (v && _.drm && _.type === "hls") {
            var A = (0, w.Z)(m),
              T = A("drm");
            if (T && _.drm.fairplay) {
              var j = window.WebKitMediaKeys;
              return (
                j &&
                j.isTypeSupported &&
                j.isTypeSupported("com.apple.fps.1_0", "video/mp4")
              );
            }
            return T;
          }
          return v;
        }),
          l.B.push({
            name: "shaka",
            supports: function (_) {
              return (
                !(_.drm && !(0, x.d3)(_.drm)) &&
                !(!window.HTMLVideoElement || !window.MediaSource) &&
                b(_.mediaTypes) &&
                (_.type === "dash" ||
                  _.type === "mpd" ||
                  (_.file || "").indexOf("mpd-time-csf") > -1)
              );
            },
          }),
          l.B.unshift({
            name: "hlsjs",
            supports: function (_) {
              return (function (m) {
                if (m.drm) return !1;
                var v = m.file.indexOf(".m3u8") > -1,
                  A = m.type === "hls" || m.type === "m3u8";
                if (!v && !A) return !1;
                var T =
                    d.Browser.chrome ||
                    d.Browser.firefox ||
                    d.Browser.edge ||
                    (d.Browser.ie && d.Browser.version.major === 11) ||
                    d.OS.tizen,
                  j =
                    d.Browser.safari &&
                    (!E.Z.canPlayType ||
                      !E.Z.canPlayType("application/vnd.apple.mpegURL")),
                  L = d.OS.android && m.hlsjsdefault === !1,
                  M = d.Browser.safari && !!m.safarihlsjs;
                return (
                  b(
                    m.mediaTypes || ['video/mp4;codecs="avc1.4d400d,mp4a.40.2"']
                  ) &&
                  (T || M || j) &&
                  !L
                );
              })(_);
            },
          });
        var g = l.B;
      },
      2303: function (c, s, r) {
        r.d(s, {
          Z: function () {
            return g;
          },
        });
        var l = r(6042),
          d = r(2963),
          w = r(12),
          S = r(670),
          x = r(2894),
          E = {
            html5: function () {
              return r
                .e(250)
                .then(
                  function (_) {
                    var m = r(9181).default;
                    return (0, S.Z)(m), m;
                  }.bind(null, r)
                )
                .catch((0, x.Ep)(152));
            },
          };
        (0, l.l7)(E, {
          shaka: function () {
            return r
              .e(371)
              .then(
                function (_) {
                  var m = r(2287).default;
                  return (0, S.Z)(m), m;
                }.bind(null, r)
              )
              .catch((0, x.Ep)(154));
          },
          hlsjs: function () {
            return r
              .e(98)
              .then(
                function (_) {
                  var m = r(9054).default;
                  return (0, S.Z)(m), m;
                }.bind(null, r)
              )
              .catch((0, x.Ep)(153));
          },
        });
        var I = E;
        function k(_) {
          this.config = _ || {};
        }
        (0, l.l7)(k.prototype, {
          load: function (_) {
            var m = I[_],
              v = function () {
                return Promise.reject(new Error("Failed to load media"));
              };
            return m
              ? m().then(function () {
                  var A = w.U[_];
                  return A || v();
                })
              : v();
          },
          providerSupports: function (_, m) {
            return _.supports(m);
          },
          choose: function (_) {
            if (_ === Object(_))
              for (var m = d.B.length, v = 0; v < m; v++) {
                var A = d.B[v];
                if (this.providerSupports(A, _))
                  return {
                    priority: m - v - 1,
                    name: A.name,
                    type: _.type,
                    providerToCheck: A,
                    provider: w.U[A.name],
                  };
              }
            return {};
          },
        });
        var b = k;
        b.prototype.providerSupports = function (_, m) {
          return _.supports(m, this.config.edition);
        };
        var g = b;
      },
      5140: function (c, s, r) {
        r.d(s, {
          t: function () {
            return l;
          },
        });
        var l = window.atob;
      },
      386: function (c, s, r) {
        r.d(s, {
          Z: function () {
            return _;
          },
        });
        var l = "free",
          d = "starter",
          w = "business",
          S = "premium",
          x = "enterprise",
          E = "developer",
          I = "platinum",
          k = "ads",
          b = "unlimited",
          g = "trial";
        function _(m) {
          var v = {
            setup: [l, d, w, S, x, E, k, b, g, I],
            drm: [x, E, k, b, g],
            ads: [k, b, g, I, x, E, w],
            jwpsrv: [l, d, w, S, x, E, k, g, I, "invalid"],
            discovery: [k, x, E, g, b],
          };
          return function (A) {
            return v[A] && v[A].indexOf(m) > -1;
          };
        }
      },
      560: function (c, s) {
        var r = function l() {
          return l._iframe;
        };
        (r.mock = function (l) {
          r._iframe = l;
        }),
          (r.unmock = function () {
            r._iframe = r._original;
          }),
          (r._iframe = window.top !== window.self),
          (r._original = r._iframe),
          (s.Z = r);
      },
      6599: function (c, s, r) {
        r.d(s, {
          u5: function () {
            return x;
          },
        });
        var l = r(5592),
          d = r(386),
          w = r(5140),
          S = r(4446),
          x = 100013,
          E = "invalid";
        s.ZP = function (I) {
          (this.keyData = (function (k) {
            var b, g, _;
            try {
              var m = (0, l.p)(
                k || "",
                (0, w.t)("NDh2aU1Cb0NHRG5hcDFRZQ==")
              ).split("/");
              if (
                ((b = m[0]) === "pro" && (b = "premium"),
                (0, d.Z)(b)("setup") || (b = E),
                m.length > 2)
              ) {
                g = m[1];
                var v = parseInt(m[2], 10);
                v > 0 && (_ = new Date()).setTime(v);
              }
            } catch {
              b = E;
            }
            return { edition: b, token: g, expiration: _ };
          })(I)),
            (this.edition = function () {
              return this.keyData.edition;
            }),
            (this.token = function () {
              return this.keyData.token;
            }),
            (this.expiration = function () {
              return this.keyData.expiration;
            }),
            (this.duration = function () {
              return this.keyData.expiration
                ? this.keyData.expiration.getTime() - new Date().getTime()
                : 0;
            }),
            (this.error = function () {
              var k;
              return (
                I === void 0
                  ? (k = 100011)
                  : this.keyData.edition !== E && this.keyData.token
                  ? this.duration() < 0 && (k = x)
                  : (k = 100012),
                k ? new S.rG(S.pJ, k) : null
              );
            });
        };
      },
      67: function (c, s, r) {
        r.d(s, {
          X: function () {
            return d;
          },
        });
        var l = r(560),
          d = function () {
            var w,
              S,
              x = window.location.host;
            if ((0, l.Z)()) {
              x = (
                document.referrer
                  ? ((w = document.referrer),
                    ((S = document.createElement("a")).href = w),
                    S)
                  : {}
              ).host;
              try {
                x = x || window.top.location.host;
              } catch {}
            }
            return x;
          };
      },
      5592: function (c, s, r) {
        r.d(s, {
          p: function () {
            return x;
          },
        });
        var l = r(5140),
          d = function (E) {
            return unescape(encodeURIComponent(E));
          },
          w = function (E) {
            for (
              var I = new Array(Math.ceil(E.length / 4)), k = 0;
              k < I.length;
              k++
            )
              I[k] =
                E.charCodeAt(4 * k) +
                (E.charCodeAt(4 * k + 1) << 8) +
                (E.charCodeAt(4 * k + 2) << 16) +
                (E.charCodeAt(4 * k + 3) << 24);
            return I;
          },
          S = function (E) {
            for (var I = new Array(E.length), k = 0; k < E.length; k++)
              I[k] = String.fromCharCode(
                255 & E[k],
                (E[k] >>> 8) & 255,
                (E[k] >>> 16) & 255,
                (E[k] >>> 24) & 255
              );
            return I.join("");
          },
          x = function (E, I) {
            if (((E = String(E)), (I = String(I)), E.length === 0)) return "";
            for (
              var k,
                b,
                g = w((0, l.t)(E)),
                _ = w(d(I).slice(0, 16)),
                m = g.length,
                v = 2654435769,
                A = g[m - 1],
                T = g[0],
                j = Math.floor(6 + 52 / m) * v;
              j;

            ) {
              b = (j >>> 2) & 3;
              for (var L = m - 1; L >= 0; L--)
                (k =
                  ((((A = g[L > 0 ? L - 1 : m - 1]) >>> 5) ^ (T << 2)) +
                    ((T >>> 3) ^ (A << 4))) ^
                  ((j ^ T) + (_[(3 & L) ^ b] ^ A))),
                  (T = g[L] -= k);
              j -= v;
            }
            return (function (M) {
              try {
                return decodeURIComponent(escape(M));
              } catch {
                return M;
              }
            })(S(g).replace(/\0+$/, ""));
          };
      },
      9563: function (c) {
        var s,
          r,
          l = {},
          d = {},
          w =
            ((s = function () {
              return document.head || document.getElementsByTagName("head")[0];
            }),
            function () {
              return r === void 0 && (r = s.apply(this, arguments)), r;
            });
        function S(b) {
          var g = document.createElement("style");
          return (
            (g.type = "text/css"),
            g.setAttribute("data-jwplayer-id", b),
            (function (_) {
              w().appendChild(_);
            })(g),
            g
          );
        }
        function x(b, g) {
          var _,
            m,
            v,
            A = d[b];
          A || (A = d[b] = { element: S(b), counter: 0 });
          var T = A.counter++;
          return (
            (_ = A.element),
            (v = function () {
              k(_, T, "");
            }),
            (m = function (j) {
              k(_, T, j);
            })(g.css),
            function (j) {
              if (j) {
                if (j.css === g.css && j.media === g.media) return;
                m((g = j).css);
              } else v();
            }
          );
        }
        c.exports = {
          style: function (b, g) {
            (function (_, m) {
              for (var v = 0; v < m.length; v++) {
                var A = m[v],
                  T = (l[_] || {})[A.id];
                if (T) {
                  for (var j = 0; j < T.parts.length; j++)
                    T.parts[j](A.parts[j]);
                  for (; j < A.parts.length; j++)
                    T.parts.push(x(_, A.parts[j]));
                } else {
                  var L = [];
                  for (j = 0; j < A.parts.length; j++) L.push(x(_, A.parts[j]));
                  (l[_] = l[_] || {}), (l[_][A.id] = { id: A.id, parts: L });
                }
              }
            })(
              g,
              (function (_) {
                for (var m = [], v = {}, A = 0; A < _.length; A++) {
                  var T = _[A],
                    j = T[0],
                    L = { css: T[1], media: T[2] };
                  v[j]
                    ? v[j].parts.push(L)
                    : m.push((v[j] = { id: j, parts: [L] }));
                }
                return m;
              })(b)
            );
          },
          clear: function (b, g) {
            var _ = l[b];
            if (_) {
              if (g) {
                var m = _[g];
                if (m) for (var v = 0; v < m.parts.length; v += 1) m.parts[v]();
                return;
              }
              for (var A = Object.keys(_), T = 0; T < A.length; T += 1)
                for (var j = _[A[T]], L = 0; L < j.parts.length; L += 1)
                  j.parts[L]();
              delete l[b];
            }
          },
        };
        var E,
          I =
            ((E = []),
            function (b, g) {
              return (
                (E[b] = g),
                E.filter(Boolean).join(`
`)
              );
            });
        function k(b, g, _) {
          if (b.styleSheet) b.styleSheet.cssText = I(g, _);
          else {
            var m = document.createTextNode(_),
              v = b.childNodes[g];
            v ? b.replaceChild(m, v) : b.appendChild(m);
          }
        }
      },
      4737: function (c) {
        c.exports =
          '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 150 29.3" class="jw-svg-icon jw-svg-icon-watermark" focusable="false"><path d="M37,16.68c0,2.4-.59,3.43-2.4,3.43a5.75,5.75,0,0,1-3.38-1.23v3.58a7.39,7.39,0,0,0,3.67,1c3.67,0,5.73-1.91,5.73-6.32V5.86H37Z"></path><polygon points="58.33 17.61 55.39 6.01 52.55 6.01 49.52 17.61 46.73 6.01 43.06 6.01 47.56 23.29 50.89 23.29 53.92 11.88 56.96 23.29 60.24 23.29 64.74 6.01 61.17 6.01 58.33 17.61"></polygon><path d="M73.84,6H67.47V23.29h2.2v-6.9h4.17c3.47,0,5.77-1.77,5.77-5.19S77.31,6,73.84,6Zm0,8.47H69.72V8h4.12c2.3,0,3.57,1.22,3.62,3.28C77.46,13.21,76.19,14.48,73.84,14.48Z"></path><path d="M99.2,6l-6,15.27H85V6H82.8V23.29H94.7l2-5.19h7.09l2,5.19H108L101.26,6ZM97.39,16.14l2.84-7.39L103,16.14Z"></path><polygon points="113.98 14.18 108.99 6.01 106.59 6.01 112.81 16.14 112.81 23.29 115.01 23.29 115.01 16.14 121.33 6.01 118.98 6.01 113.98 14.18"></polygon><polygon points="123.14 23.29 134.1 23.29 134.1 21.28 125.29 21.28 125.29 15.41 133.32 15.41 133.32 13.45 125.29 13.45 125.29 7.97 134.1 7.97 134.1 6.01 123.14 6.01 123.14 23.29"></polygon><path d="M144.86,15.85c2.74-.39,4.41-2,4.41-4.85,0-3.23-2.26-5-5.73-5h-6.32V23.29h2.22V16h3.08l4.94,7.29H150Zm-5.42-1.71V8h4.06c2.3,0,3.62,1.17,3.62,3.08s-1.32,3.09-3.62,3.09Z"></path><path d="M27.63.09a1,1,0,0,0-1.32.48c-.24.51-6.35,15.3-6.35,15.3-.2.46-.33.41-.33-.07,0,0,0-5.15,0-9.39,0-2.31-1.12-3.61-2.73-3.88A3.12,3.12,0,0,0,14.83,3a4.57,4.57,0,0,0-1.5,1.79c-.48.94-3.47,9.66-3.47,9.66-.16.46-.31.44-.31,0,0,0-.09-3.76-.18-4.64-.13-1.36-.44-3.59-2.2-3.7S4.77,8,4.36,9.24c-.29.84-1.65,5.35-1.65,5.35l-.2.46h0c-.06.24-.17.24-.24,0l-.11-.42Q2,14,1.74,13.31a1.71,1.71,0,0,0-.33-.66.83.83,0,0,0-.88-.22.82.82,0,0,0-.53.69,4.22,4.22,0,0,0,.07.79,29,29,0,0,0,1,4.6,1.31,1.31,0,0,0,1.8.66,3.43,3.43,0,0,0,1.24-1.81c.33-.81,2-5.48,2-5.48.18-.46.31-.44.29,0,0,0-.09,4.57-.09,6.64a13.11,13.11,0,0,0,.28,2.93,2.41,2.41,0,0,0,.82,1.27,2,2,0,0,0,1.41.4,2,2,0,0,0,.7-.24,3.15,3.15,0,0,0,.79-.71,12.52,12.52,0,0,0,1.26-2.11c.81-1.6,2.92-6.58,2.92-6.58.2-.46.33-.41.33.07,0,0-.26,8.36-.26,11.55a6.39,6.39,0,0,0,.44,2.33,2.8,2.8,0,0,0,1.45,1.61A2.57,2.57,0,0,0,18.79,29a3.76,3.76,0,0,0,1.28-1.32,15.12,15.12,0,0,0,1.07-2.31c.64-1.65,1.17-3.33,1.7-5s5-17.65,5.28-19a1.79,1.79,0,0,0,0-.46A1,1,0,0,0,27.63.09Z"></path></svg>';
      },
    },
    o = {};
  function a(c) {
    var s = o[c];
    if (s !== void 0) return s.exports;
    var r = (o[c] = { id: c, loaded: !1, exports: {} });
    return n[c].call(r.exports, r, r.exports, a), (r.loaded = !0), r.exports;
  }
  (a.m = n),
    (a.n = function (c) {
      var s =
        c && c.__esModule
          ? function () {
              return c.default;
            }
          : function () {
              return c;
            };
      return a.d(s, { a: s }), s;
    }),
    (a.d = function (c, s) {
      for (var r in s)
        a.o(s, r) &&
          !a.o(c, r) &&
          Object.defineProperty(c, r, { enumerable: !0, get: s[r] });
    }),
    (a.f = {}),
    (a.e = function (c) {
      return Promise.all(
        Object.keys(a.f).reduce(function (s, r) {
          return a.f[r](c, s), s;
        }, [])
      );
    }),
    (a.u = function (c) {
      return (
        {
          63: "polyfills.webvtt",
          74: "jwplayer.controls.tizen",
          98: "provider.hlsjs",
          168: "jwplayer.amp",
          207: "jwplayer.core.controls.html5",
          250: "provider.html5",
          347: "vttparser",
          365: "related",
          371: "provider.shaka",
          493: "jwplayer.core.controls.polyfills",
          520: "provider.airplay",
          581: "jwplayer.core.controls",
          605: "jwplayer.core.controls.polyfills.html5",
          681: "jwplayer.core",
          716: "jwplayer.controls",
          926: "jwplayer.stats",
          943: "polyfills.intersection-observer",
          977: "provider.cast",
        }[c] + ".js"
      );
    }),
    (a.o = function (c, s) {
      return Object.prototype.hasOwnProperty.call(c, s);
    }),
    (e = {}),
    (t = "jwplayer:"),
    (a.l = function (c, s, r, l) {
      if (e[c]) e[c].push(s);
      else {
        var d, w;
        if (r !== void 0)
          for (
            var S = document.getElementsByTagName("script"), x = 0;
            x < S.length;
            x++
          ) {
            var E = S[x];
            if (
              E.getAttribute("src") == c ||
              E.getAttribute("data-webpack") == t + r
            ) {
              d = E;
              break;
            }
          }
        d ||
          ((w = !0),
          ((d = document.createElement("script")).charset = "utf-8"),
          (d.timeout = 55),
          a.nc && d.setAttribute("nonce", a.nc),
          d.setAttribute("data-webpack", t + r),
          (d.src = c)),
          (e[c] = [s]);
        var I = function (b, g) {
            (d.onerror = d.onload = null), clearTimeout(k);
            var _ = e[c];
            if (
              (delete e[c],
              d.parentNode && d.parentNode.removeChild(d),
              _ &&
                _.forEach(function (m) {
                  return m(g);
                }),
              b)
            )
              return b(g);
          },
          k = setTimeout(
            I.bind(null, void 0, { type: "timeout", target: d }),
            55e3
          );
        (d.onerror = I.bind(null, d.onerror)),
          (d.onload = I.bind(null, d.onload)),
          w && document.head.appendChild(d);
      }
    }),
    (a.r = function (c) {
      typeof Symbol < "u" &&
        Symbol.toStringTag &&
        Object.defineProperty(c, Symbol.toStringTag, { value: "Module" }),
        Object.defineProperty(c, "__esModule", { value: !0 });
    }),
    (a.nmd = function (c) {
      return (c.paths = []), c.children || (c.children = []), c;
    }),
    (a.p = ""),
    (function () {
      var c = { 313: 0 };
      a.f.j = function (l, d) {
        var w = a.o(c, l) ? c[l] : void 0;
        if (w !== 0)
          if (w) d.push(w[2]);
          else {
            var S = new Promise(function (I, k) {
              w = c[l] = [I, k];
            });
            d.push((w[2] = S));
            var x = a.p + a.u(l),
              E = new Error();
            a.l(
              x,
              function (I) {
                if (a.o(c, l) && ((w = c[l]) !== 0 && (c[l] = void 0), w)) {
                  var k = I && (I.type === "load" ? "missing" : I.type),
                    b = I && I.target && I.target.src;
                  (E.message =
                    "Loading chunk " +
                    l +
                    ` failed.
(` +
                    k +
                    ": " +
                    b +
                    ")"),
                    (E.name = "ChunkLoadError"),
                    (E.type = k),
                    (E.request = b),
                    w[1](E);
                }
              },
              "chunk-" + l,
              l
            );
          }
      };
      var s = function (l, d) {
          var w,
            S,
            x = d[0],
            E = d[1],
            I = d[2],
            k = 0;
          if (
            x.some(function (b) {
              return c[b] !== 0;
            })
          ) {
            for (w in E) a.o(E, w) && (a.m[w] = E[w]);
            I && I(a);
          }
          for (l && l(d); k < x.length; k++)
            (S = x[k]), a.o(c, S) && c[S] && c[S][0](), (c[x[k]] = 0);
        },
        r = (self.webpackChunkjwplayer = self.webpackChunkjwplayer || []);
      r.forEach(s.bind(null, 0)), (r.push = s.bind(null, r.push.bind(r)));
    })();
  var f = a(817);
  window.jwplayer = f.default;
})();
const Sf = 0.01,
  _f = {
    allowFullscreen: !1,
    autostart: !1,
    repeat: !1,
    advertising: { endstate: "suspended" },
    autoPause: { pauseAds: !0, viewability: !0 },
  },
  Cf = "https://js-sec.indexww.com",
  kr = "703",
  Ef = Ze({
    emits: ["click", "size-change"],
    props: {
      width: { type: Number, required: !0 },
      height: { type: Number, required: !0 },
    },
    setup({ width: e, height: t }) {
      const n = Ye(),
        o = URL.createObjectURL(
          new Blob([`${n.assets.vastXml}`], { type: "text/plain" })
        ),
        a = Lt(null);
      function f() {
        qe.debug(`video: creating player with size ${e}x${t}`);
        const { playerConfig: s } = gs({ width: e, height: t }, _f),
          r = window.jwplayer("video-container").setup(s);
        r &&
          r.on("ready", () => {
            const l = document.querySelector(
              "#video-container > div.jw-wrapper.jw-reset > div.jw-media.jw-reset"
            );
            let d = "";
            const w = document.querySelector(
              "#video-container > div.jw-wrapper.jw-reset > div.jw-controls.jw-reset > div.jw-controlbar.jw-reset > div.jw-slider-time.jw-background-color.jw-reset.jw-slider-horizontal.jw-reset"
            );
            r.playAd(o),
              r.on("displayClick", () => {
                r.playAd(o);
              }),
              r.on("adPlay", () => {
                var S;
                if (
                  ((d =
                    (S = document.getElementsByTagName("video")[0]) != null &&
                    S.src
                      ? `${document.getElementsByTagName("video")[0].src}#t=1.2`
                      : ""),
                  w && (w.style.visibility = "visible"),
                  l && (l.style.visibility = "visible"),
                  !document.getElementById("video-thumbnail"))
                ) {
                  const x = document.createElement("video");
                  (x.src = d),
                    (x.id = "video-thumbnail"),
                    (x.controls = !1),
                    (x.muted = !1),
                    (x.width = e),
                    (x.height = t);
                  const E = document.querySelector(
                    "#video-container > div.jw-wrapper.jw-reset > div.jw-preview.jw-reset"
                  );
                  E && E.appendChild(x);
                }
              }),
              r.on("complete", () => {
                w && (w.style.visibility = "hidden"),
                  l && (l.style.visibility = "hidden");
              }),
              r.on("adError", (S) => {
                if (!(!n.eventTrackerURL || !n.eventTrackerEvents.includes(kr)))
                  try {
                    const x = new URL(n.eventTrackerURL);
                    x.searchParams.set("ec", kr),
                      x.searchParams.set("ve", S.adErrorCode ?? 0),
                      fetch(x.toString()).catch(() => {});
                  } catch (x) {
                    qe.debug(`failed to parse ET URL: ${x}`);
                  }
              });
          });
      }
      let c;
      return (
        on(() => {
          if (n.verification === "omid")
            qe.debug("video: waiting for OMID message"),
              (c = (s) => {
                s.origin === Cf && s.data === "start-video" && f();
              }),
              window.addEventListener("message", c);
          else {
            qe.debug("video: waiting for viewability");
            const s = document.getElementById("video-root");
            dc(s, Sf, () => {
              f(),
                n.eventTrackerURL &&
                  n.eventTrackerEvents.includes(kr) &&
                  pc(n.eventTrackerURL);
            });
          }
        }),
        or(() => {
          c && window.removeEventListener("message", c);
        }),
        { elementRef: a, renderState: n }
      );
    },
  }),
  kf = { ref: "elementRef", id: "video-root" };
function Tf(e, t, n, o, a, f) {
  return (
    Ae(),
    Fe(
      "div",
      kf,
      t[0] || (t[0] = [je("div", { id: "video-container" }, null, -1)]),
      512
    )
  );
}
const Pf = We(Ef, [["render", Tf]]);
function Af(e) {
  e.component("Layout320x50", Mc),
    e.component("Layout320x100", Rc),
    e.component("Layout728x90", Vc),
    e.component("Layout970x90", zc),
    e.component("LayoutInterstitial", Jc),
    e.component("LayoutSquare", il),
    e.component("LayoutTall", gl),
    e.component("LayoutVideoSquare", wl),
    e.component("LayoutVideoTall", _l),
    e.component("LayoutVideoWide", Pl),
    e.component("LayoutWide", jl),
    e.component("AdChoices", $l),
    e.component("AdLabel", Hl),
    e.component("Cta", ql),
    e.component("Description", Gl),
    e.component("Disclaimer", Ql),
    e.component("MediaPartFixed", sf),
    e.component("MediaPartShrinking", hf),
    e.component("TextPart", mf),
    e.component("Title", wf),
    e.component("VideoPlayer", Pf);
}
function ms(
  e,
  {
    renderPayload: t,
    language: n,
    interstitial: o,
    autoplay: a,
    verification: f,
    viewabilityURL: c,
    eventTrackerURL: s,
    eventTrackerEvents: r,
  }
) {
  Tc(t, n).then((l) => {
    const d = Mu(Cc, {
      renderPayload: l,
      language: n,
      interstitial: o,
      autoplay: a,
      verification: f,
      viewabilityURL: c,
      eventTrackerURL: s,
      eventTrackerEvents: r,
    });
    Af(d), d.mount(e);
  });
}
window.IXNativeRenderer = ms;
const {
  renderPayload: Ji,
  lang: If,
  interstitial: Of,
  autoplay: Bf,
  verification: Rf,
  viewabilityURL: Ff,
  eventTrackerURL: jf,
  eventTrackerEvents: Lf,
} = window;
Ji
  ? ms("#app", {
      renderPayload: Ji,
      language: If,
      interstitial: Of,
      autoplay: Bf,
      verification: Rf,
      viewabilityURL: Ff,
      eventTrackerURL: jf,
      eventTrackerEvents: Lf,
    })
  : qe.info("No render payload found");
