(() => {
  var S = Object.defineProperty;
  var R = (e, r, t) =>
    r in e
      ? S(e, r, { enumerable: !0, configurable: !0, writable: !0, value: t })
      : (e[r] = t);
  var d = (e, r, t) => R(e, typeof r != "symbol" ? r + "" : r, t);
  var u = ((e) => ((e.Error = "error"), e))(u || {}),
    p = ((e) => (
      (e.AdRequest = "ad-request"),
      (e.AdResolve = "ad-resolved"),
      (e.AdNotResolved = "ad-not-resolved"),
      e
    ))(p || {}),
    m = ((e) => (
      (e.AdReady = "ad-ready"),
      (e.AdView = "ad-view"),
      (e.AdInsert = "ad-insert"),
      (e.AdClick = "ad-click"),
      (e.AdClose = "ad-xtocloseclick"),
      (e.AdIframeReady = "ad-iframe-ready"),
      (e.AdOverlay = "ad-overlay"),
      e
    ))(m || {}),
    b = ((e) => (
      (e.MinipassConnected = "minipass-connected"),
      (e.AdCreativeImpression = "ad-creative-impression"),
      (e.AdCreativeClick = "ad-creative-click"),
      e
    ))(b || {}),
    w = ((e) => (
      (e.VideoVastAvailable = "video-vast-available"),
      (e.VideoVastLoaded = "video-vast-loaded"),
      (e.VideoReady = "video-ready"),
      (e.VideoLazyPlay = "video-lazyplay"),
      (e.VideoStarted = "video-started"),
      (e.VideoImpression = "video-impression"),
      (e.VideoPlay = "video-play"),
      (e.VideoPlayPercentile25 = "video-played-percentile-25"),
      (e.VideoPlayPercentile50 = "video-played-percentile-50"),
      (e.VideoPlayPercentile75 = "video-played-percentile-75"),
      (e.VideoEnd = "video-end"),
      (e.VideoClick = "video-click"),
      (e.VideoSkip = "video-skip"),
      (e.VideoError = "video-error"),
      (e.VideoViewableImpression = "video-viewable-impression"),
      (e.VideoPaused = "video-paused"),
      (e.VideoResumed = "video-resumed"),
      (e.VideoAllAdsCompleted = "video-all-ads-completed"),
      (e.VideoExpand = "video-expand"),
      e
    ))(w || {}),
    f = ((e) => (
      (e.AdViewability1s50 = "ad-viewability-1s50"),
      (e.AdViewability1s100 = "ad-viewability-1s100"),
      (e.AdViewability2s50 = "ad-viewability-2s50"),
      (e.AdViewability3s50 = "ad-viewability-3s50"),
      e
    ))(f || {}),
    A = ((e) => (
      (e.LazyInsert = "ad-lazyinsert"),
      (e.LazyInsertNotReady = "ad-lazyinsert-not-ready"),
      e
    ))(A || {}),
    v = ((e) => (
      (e.XandrViewabilityWrapperChange = "appnexus-viewability-wrapper-change"),
      e
    ))(v || {});
  ({ ...m, ...w, ...f, ...u, ...v, ...b, ...A, ...p });
  var o = ((e) => (
    (e.HeaderBidding = "HeaderBidding"),
    (e.Tam = "Tam"),
    (e.PrebidServer = "PrebidServer"),
    (e.SingleAdUnit = "Autonomous"),
    (e.Tag = "Tag"),
    (e.AMP = "AMP"),
    (e.GOB = "Gob"),
    e
  ))(o || {});
  class C extends Error {
    constructor() {
      super(), (this.name = "Error");
    }
  }
  class k extends C {
    constructor() {
      super(), (this.name = "ScriptLoadError");
    }
  }
  const G = (e) => {
    try {
      for (; e !== e.parent; ) e.parent.document.body, (e = e.parent);
    } catch {}
    return e;
  };
  class L {
    constructor(r) {
      d(this, "precision", 100);
      d(this, "abTests", [
        { version: 10, probability: 1, useGohan: !0, sourceType: o.Tag },
        { version: 11, probability: 1, useGohan: !1 },
        { version: 12, probability: 5, useGohan: !1 },
      ]);
      d(this, "abTestRanges", []);
      (this.sourceType = r), this.createRange();
    }
    getTest() {
      const r = this.getProbability(),
        t = this.abTestRanges.find((s) => r >= s.start && r < s.end);
      if (t) return { name: t.name, useGohan: t.isGohan };
    }
    getAbTests() {
      return this.abTests.filter(
        (r) => !r.sourceType || r.sourceType === this.sourceType
      );
    }
    getProbability() {
      return Math.floor(Math.random() * Math.floor(this.precision));
    }
    createRange() {
      this.abTestRanges = this.getAbTests().reduce((r, t) => {
        const s = r.length === 0 ? 0 : r[r.length - 1].end,
          i = s + t.probability,
          a = t.useGohan;
        return [
          ...r,
          { start: s, end: i, name: t.version.toString(), isGohan: a },
        ];
      }, []);
    }
  }
  function g(e = 1200, r = Date.now()) {
    if (e <= 0) throw new Error("maxAge must be greater than 0");
    const s = e > 86400 ? 86400 : Math.round(e);
    return r - (r % (s * 1e3));
  }
  const V = (e, r) =>
    new Promise((t, s) => {
      const i = r.document.createElement("script");
      (i.src = e),
        (i.async = !0),
        (i.defer = !0),
        (i.onload = () => t(i)),
        (i.onerror = () => s(new k())),
        r.document.head.appendChild(i);
    });
  class B {
    constructor(r, t, s) {
      d(this, "topWindow");
      (this.sourceType = r),
        (this.window = t),
        (this.isInApp = s),
        (this.topWindow = G(this.window));
    }
    async load() {
      const r = new L(this.sourceType).getTest(),
        t = this.getAssetUrl(r);
      return V(t, this.window);
    }
    getAssetName(r) {
      if (this.isInApp) return "inApp.js";
      switch (r) {
        case o.SingleAdUnit:
          return "singleAdUnit.js";
        case o.HeaderBidding:
          return "headerBidding.js";
        case o.Tag:
          return "tag.js";
        default:
          throw new Error(`Unsupported source type: ${r}`);
      }
    }
    getAssetUrl(r) {
      const t =
        r != null && r.useGohan
          ? "st_0.js"
          : this.getAssetName(this.sourceType);
      if (r) {
        const s = t === "st_0.js" ? "loader/" : "";
        return `https://t.seedtag.com/c/v/${r.name}/${s}${t}?cb=${g()}`;
      }
      return `https://t.seedtag.com/c/${t}?cb=${g()}`;
    }
  }
  const I = (e) => {
      var r;
      return (r = e.hbResponse) == null ? void 0 : r.hbConfig;
    },
    N = (e) => e._seedtag_tag,
    U = (e) => e._seedtagq || [],
    y = (e, r) => {
      var s;
      return (s = U(e).find(([i, a]) => i === r)) == null ? void 0 : s[1];
    },
    _ = (e) => y(e, "_setPublisher"),
    M = (e) => y(e, "_setId"),
    $ = (e) => e.inAppResponse,
    c = I(window),
    l = N(window),
    j = _(window),
    P = $(window),
    H = () => {
      if (c || P) return o.HeaderBidding;
      if (l) return o.SingleAdUnit;
      if (j) return o.Tag;
    },
    z = (e, r, t) => {
      const s = (e && e.message) || JSON.stringify(e);
      fetch(
        "https://endpoint1.collection.eu.sumologic.com/receiver/v1/http/ZaVnC4dhaV3AGFS6E0Ysz3fSDL-XPgtC2BIL2fEC-IbmNYLrELvAJsYPSFheE2S32YMJV1_wFRVO4JN0pV5s44NmcX6j1gUGn1ozH3BB4eTXeGoYMoijJg==",
        {
          method: "POST",
          body: JSON.stringify({
            t: "adunit-render",
            s: t,
            tk: r,
            ec: "TagLoadError",
            e: s,
          }),
        }
      );
    },
    h = (e, r, t) => {
      const s = "https://s.seedtag.com/e/eg",
        i = {
          name: u.Error,
          errorType: "TagLoadError",
          sourceType: r,
          token: t,
          url: window.location.href,
        },
        a = document.createElement("img");
      (a.src = `${s}?${new URLSearchParams(i).toString()}`),
        (a.style.width = "0"),
        (a.style.height = "0"),
        document.body.appendChild(a),
        z(e, t, r);
    },
    n = H();
  n
    ? new B(n, window, !!P).load().catch((r) => {
        let t;
        n === o.HeaderBidding
          ? (t = c == null ? void 0 : c.publisherToken)
          : n === o.SingleAdUnit
          ? (t = l == null ? void 0 : l.publisherToken)
          : n === o.Tag && (t = M(window)),
          h(r, n, t || "");
      })
    : h(new Error("No config found"), void 0, "");
})();
