(() => {
  var Hi = Object.defineProperty;
  var _i = (t, e, i) =>
    e in t
      ? Hi(t, e, { enumerable: !0, configurable: !0, writable: !0, value: i })
      : (t[e] = i);
  var g = (t, e, i) => _i(t, typeof e != "symbol" ? e + "" : e, i);
  var _t = ((t) => ((t.WEB = "WEB"), (t.APP = "APP"), t))(_t || {}),
    Me = ((t) => (
      (t.ScriptLoaded = "script-loaded"), (t.ClientReady = "client-ready"), t
    ))(Me || {}),
    Pe = ((t) => ((t.Error = "error"), t))(Pe || {}),
    pe = ((t) => (
      (t.AdRequest = "ad-request"),
      (t.AdResolve = "ad-resolved"),
      (t.AdNotResolved = "ad-not-resolved"),
      t
    ))(pe || {}),
    ie = ((t) => (
      (t.AdReady = "ad-ready"),
      (t.AdView = "ad-view"),
      (t.AdInsert = "ad-insert"),
      (t.AdClick = "ad-click"),
      (t.AdClose = "ad-xtocloseclick"),
      (t.AdIframeReady = "ad-iframe-ready"),
      (t.AdOverlay = "ad-overlay"),
      t
    ))(ie || {}),
    it = ((t) => (
      (t.MinipassConnected = "minipass-connected"),
      (t.AdCreativeImpression = "ad-creative-impression"),
      (t.AdCreativeClick = "ad-creative-click"),
      t
    ))(it || {}),
    Ee = ((t) => (
      (t.VideoVastAvailable = "video-vast-available"),
      (t.VideoVastLoaded = "video-vast-loaded"),
      (t.VideoReady = "video-ready"),
      (t.VideoLazyPlay = "video-lazyplay"),
      (t.VideoStarted = "video-started"),
      (t.VideoImpression = "video-impression"),
      (t.VideoPlay = "video-play"),
      (t.VideoPlayPercentile25 = "video-played-percentile-25"),
      (t.VideoPlayPercentile50 = "video-played-percentile-50"),
      (t.VideoPlayPercentile75 = "video-played-percentile-75"),
      (t.VideoEnd = "video-end"),
      (t.VideoClick = "video-click"),
      (t.VideoSkip = "video-skip"),
      (t.VideoError = "video-error"),
      (t.VideoViewableImpression = "video-viewable-impression"),
      (t.VideoPaused = "video-paused"),
      (t.VideoResumed = "video-resumed"),
      (t.VideoAllAdsCompleted = "video-all-ads-completed"),
      (t.VideoExpand = "video-expand"),
      t
    ))(Ee || {}),
    ge = ((t) => (
      (t.AdViewability1s50 = "ad-viewability-1s50"),
      (t.AdViewability1s100 = "ad-viewability-1s100"),
      (t.AdViewability2s50 = "ad-viewability-2s50"),
      (t.AdViewability3s50 = "ad-viewability-3s50"),
      t
    ))(ge || {}),
    ve = ((t) => (
      (t.LazyInsert = "ad-lazyinsert"),
      (t.LazyInsertNotReady = "ad-lazyinsert-not-ready"),
      t
    ))(ve || {}),
    nt = ((t) => (
      (t.XandrViewabilityWrapperChange = "appnexus-viewability-wrapper-change"),
      t
    ))(nt || {}),
    Ft = ((t) => (
      (t.TemplateFound = "tagmanager-template-found"),
      (t.TemplateNotFound = "tagmanager-template-not-found"),
      (t.AdUnitFound = "tagmanager-adunit-found"),
      (t.AdUnitNotFound = "tagmanager-adunit-not-found"),
      t
    ))(Ft || {});
  const Gt = { ...ie, ...Ee, ...ge, ...Pe, ...nt, ...it, ...ve, ...pe };
  var Ve = ((t) => (
    (t.DISPLAY = "display"), (t.VIDEO = "video"), (t.NATIVE = "native"), t
  ))(Ve || {});
  const Fi = (t) => {
      switch (t) {
        case Ve.DISPLAY:
        case Ve.NATIVE:
          return "display";
        case Ve.VIDEO:
          return "video";
      }
    },
    Gi = (t) => {
      switch (t) {
        case "OMN":
          return "native";
        case "OMV":
          return "outstreamVideo";
        default: {
          const e = t.replace(/^(P|OM)/, "").replace(/^C(?=\d+x\d+$)/, "");
          switch (e) {
            case "CEDh":
            case "CEDv":
              return "engagementDisplay";
            case "CID":
              return "impactDisplay";
            case "CN":
              return "native";
            case "CEV":
              return "engagementVideo";
            case "CBV":
              return "brandedVideo";
            case "COV":
              return "outstreamVideo";
            case "CFD":
              return "frameDisplay";
            default: {
              const [i, n] = Wi(e);
              return (i === 200 && n === 200) ||
                (i === 250 && n === 250) ||
                (i === 300 && n === 250) ||
                (i === 336 && n === 280)
                ? "standardAdsSquared"
                : i && n
                ? i >= n
                  ? "standardAdsBanner"
                  : "standardAdsVertical"
                : "unknown";
            }
          }
        }
      }
    },
    Xi = (t) => {
      switch (t) {
        case "engagementDisplay":
          return "contextual-engagement-display";
        case "impactDisplay":
          return "contextual-impact-display";
        case "native":
          return "contextual-native";
        case "engagementVideo":
          return "contextual-engagement-video";
        case "brandedVideo":
          return "contextual-branded-video";
        case "outstreamVideo":
          return "contextual-outstream-video";
        case "standardAdsBanner":
        case "standardAdsSquared":
        case "standardAdsVertical":
          return "display-standard";
        case "frameDisplay":
          return "contextual-frame-display";
        case "protectedAudiences":
          return "protected-audiences";
        case "unknown":
        default:
          return "unknown";
      }
    },
    Wi = (t) => {
      const e = /^(\d+)x(\d+)$/,
        i = t.match(e),
        n = (s, r) => (s ? parseInt(s[r], 10) : void 0);
      return [n(i, 1), n(i, 2)];
    };
  var Xt = ((t) => (
      (t.Open = "open"), (t.Deal = "deal"), (t.Direct = "direct"), t
    ))(Xt || {}),
    We = ((t) => (
      (t.CEV = "CEV"),
      (t.COV = "COV"),
      (t.CBV = "CBV"),
      (t.CEDV = "CEDv"),
      (t.CEDH = "CEDh"),
      (t.CID = "CID"),
      (t.CFD = "CFD"),
      (t.CN = "CN"),
      (t.C120X600 = "C120x600"),
      (t.C160X600 = "C160x600"),
      (t.C300X600 = "C300x600"),
      (t.C320X50 = "C320x50"),
      (t.C728X90 = "C728x90"),
      (t.C970X250 = "C970x250"),
      (t.C320X480 = "C320x480"),
      (t.C728X250 = "C728x250"),
      (t.C970X300 = "C970x300"),
      (t.C980X250 = "C980x250"),
      (t.C300X100 = "C300x100"),
      (t.C320X100 = "C320x100"),
      (t.C970X90 = "C970x90"),
      (t.C300X250 = "C300x250"),
      (t.PCEV = "PCEV"),
      (t.PCOV = "PCOV"),
      (t.PCBV = "PCBV"),
      (t.PCEDV = "PCEDv"),
      (t.PCEDH = "PCEDh"),
      (t.PCID = "PCID"),
      (t.PCFD = "PCFD"),
      (t.PCN = "PCN"),
      (t.PDS_GROUP = "PDS"),
      (t.P120X600 = "P120x600"),
      (t.P160X600 = "P160x600"),
      (t.P300X600 = "P300x600"),
      (t.P320X50 = "P320x50"),
      (t.P728X90 = "P728x90"),
      (t.P970X250 = "P970x250"),
      (t.P320X480 = "P320x480"),
      (t.P728X250 = "P728x250"),
      (t.P970X300 = "P970x300"),
      (t.P980X250 = "P980x250"),
      (t.P300X100 = "P300x100"),
      (t.P320X100 = "P320x100"),
      (t.P970X90 = "P970x90"),
      (t.PFDS_GROUP = "PFDS"),
      (t.P300X250 = "P300x250"),
      (t.OMN = "OMN"),
      (t.OMV = "OMV"),
      (t.OM85X31 = "OM85x31"),
      (t.OM120X60 = "OM120x60"),
      (t.OM120X240 = "OM120x240"),
      (t.OM120X600 = "OM120x600"),
      (t.OM160X600 = "OM160x600"),
      (t.OM300X50 = "OM300x50"),
      (t.OM300X100 = "OM300x100"),
      (t.OM300X600 = "OM300x600"),
      (t.OM320X50 = "OM320x50"),
      (t.OM320X100 = "OM320x100"),
      (t.OM320X480 = "OM320x480"),
      (t.OM468X60 = "OM468x60"),
      (t.OM728X90 = "OM728x90"),
      (t.OM728X200 = "OM728x200"),
      (t.OM728X250 = "OM728x250"),
      (t.OM980X90 = "OM980x90"),
      (t.OM970X90 = "OM970x90"),
      (t.OM970X250 = "OM970x250"),
      (t.OM970X300 = "OM970x300"),
      (t.OM980X250 = "OM980x250"),
      (t.OM125X125 = "OM125x125"),
      (t.OM180X150 = "OM180x150"),
      (t.OM200X200 = "OM200x200"),
      (t.OM213X120 = "OM213x120"),
      (t.OM250X250 = "OM250x250"),
      (t.OM300X200 = "OM300x200"),
      (t.OM300X250 = "OM300x250"),
      (t.OM320X250 = "OM320x250"),
      (t.OM336X280 = "OM336x280"),
      (t.OM350X196 = "OM350x196"),
      (t.OM400X225 = "OM400x225"),
      (t.OM400X300 = "OM400x300"),
      (t.OM600X400 = "OM600x400"),
      (t.OM640X360 = "OM640x360"),
      (t.OM640X480 = "OM640x480"),
      (t.OM700X393 = "OM700x393"),
      t
    ))(We || {});
  const ke = (t) =>
      [
        "CEV",
        "COV",
        "CBV",
        "CEDv",
        "CEDh",
        "CID",
        "CFD",
        "CN",
        "PCEV",
        "PCOV",
        "PCBV",
        "PCEDv",
        "PCEDh",
        "PCID",
        "PCFD",
        "PCN",
      ].includes(t),
    ji = (t) => ["OMV", "COV", "PCOV"].includes(t);
  var Wt = ((t) => (
      (t.SINGLE = "SINGLE"), (t.BACKUP = "BACKUP"), (t.EMPTY = "EMPTY"), t
    ))(Wt || {}),
    jt = ((t) => (
      (t.HeaderBidding = "HeaderBidding"),
      (t.Tam = "Tam"),
      (t.PrebidServer = "PrebidServer"),
      (t.SingleAdUnit = "Autonomous"),
      (t.Tag = "Tag"),
      (t.AMP = "AMP"),
      (t.GOB = "Gob"),
      t
    ))(jt || {}),
    D = ((t) => (
      (t.InTerstitial = "inTerstitial"),
      (t.InBanner = "inBanner"),
      (t.InArticle = "inArticle"),
      (t.InScreen = "inScreen"),
      (t.InTop = "inTop"),
      (t.InSkin = "inSkin"),
      (t.InImage = "inImage"),
      (t.InImageRestricted = "inImageRestricted"),
      t
    ))(D || {});
  class se extends Error {
    constructor() {
      super(), (this.name = "Error");
    }
  }
  class L extends se {
    constructor() {
      super(), (this.name = "HttpRequestError");
    }
  }
  class Qi extends se {
    constructor() {
      super(), (this.name = "HeaderBiddingResponseNotFoundError");
    }
  }
  class $i extends se {
    constructor() {
      super(), (this.name = "AdUnitTypeNotSupportedError");
    }
  }
  class Yi extends se {
    constructor() {
      super(), (this.name = "SafeFrameNotFoundError");
    }
  }
  class qi extends se {
    constructor() {
      super(), (this.name = "NoHttpMethodError");
    }
  }
  class Ki extends se {
    constructor() {
      super(), (this.name = "JsTrackerError");
    }
  }
  class Ji extends L {
    constructor() {
      super(), (this.name = "CorsError");
    }
  }
  class Zi extends L {
    constructor() {
      super(), (this.name = "MixedContentError");
    }
  }
  class en extends L {
    constructor() {
      super(), (this.name = "InvalidUrlFormatError");
    }
  }
  class tn extends L {
    constructor() {
      super(), (this.name = "DeviceOfflineError");
    }
  }
  class nn extends L {
    constructor() {
      super(), (this.name = "LocalDevelopmentServerError");
    }
  }
  class Ne extends L {
    constructor() {
      super(), (this.name = "HttpNetworkError");
    }
  }
  class sn extends L {
    constructor() {
      super(), (this.name = "HttpTimeoutError");
    }
  }
  class Qt extends L {
    constructor() {
      super(), (this.name = "HttpParseError");
    }
  }
  class rn extends L {
    constructor() {
      super(), (this.name = "HttpOpenError");
    }
  }
  class an extends L {
    constructor() {
      super(), (this.name = "HttpHeaderError");
    }
  }
  class on extends L {
    constructor() {
      super(), (this.name = "HttpSendError");
    }
  }
  class dn extends L {
    constructor() {
      super(), (this.name = "HttpRateLimitError");
    }
  }
  class hn extends L {
    constructor() {
      super(), (this.name = "HttpClientError");
    }
  }
  class cn extends L {
    constructor() {
      super(), (this.name = "HttpServerError");
    }
  }
  const $t = (t) =>
      t === 0
        ? new Ne()
        : t === 429
        ? new dn()
        : t >= 500
        ? new cn()
        : new hn(),
    Yt = (t = navigator.userAgent) =>
      /Android|web0S|iPhone|iPad|iPod|BlackBerry|Opera Mini/i.test(t),
    je = (t = navigator.userAgent) => !Yt(t),
    ln = () => {
      const t = document.currentScript;
      return t && t instanceof HTMLScriptElement ? t.src : null;
    },
    ne = (t) => {
      try {
        for (; t !== t.parent; ) t.parent.document.body, (t = t.parent);
      } catch {}
      return t;
    },
    un = (t = window) => ne(t) == t,
    pn = (t) => {
      const e = ln() || "",
        n =
          /https:\/\/(t\.seedtag\.com\/c|config\.seedtag\.com)\/v\/([0-9]*)\/*/gi.exec(
            e
          );
      return (n && n[2]) || void 0;
    },
    gn = (t, e, i, n, s, r, a, d, h, c, v) => {
      const p = t.name;
      let f = "unknown";
      t instanceof Error ? (f = t.message) : typeof t == "string" && (f = t),
        fetch(
          "https://endpoint1.collection.eu.sumologic.com/receiver/v1/http/ZaVnC4dhaV3AGFS6E0Ysz3fSDL-XPgtC2BIL2fEC-IbmNYLrELvAJsYPSFheE2S32YMJV1_wFRVO4JN0pV5s44NmcX6j1gUGn1ozH3BB4eTXeGoYMoijJg==",
          {
            method: "POST",
            body: JSON.stringify({
              s: e,
              e: f,
              t: "adunit-render",
              ec: p,
              v: a || "",
              at: n,
              tk: i,
              an: s,
              tn: r,
              u: d,
              d: h,
              b: c,
              c: v,
            }),
          }
        );
    },
    vn = () => {
      const t = () =>
        Math.floor((1 + Math.random()) * 65536)
          .toString(16)
          .slice(1);
      return [t(), t(), "-", t(), "-", t(), "-", t(), "-", t(), t(), t()].join(
        ""
      );
    },
    mn = () => crypto.randomUUID(),
    fn = () => {
      const t = URL.createObjectURL(new Blob());
      return URL.revokeObjectURL(t), t.substring(t.lastIndexOf("/") + 1);
    },
    An = () => {
      try {
        return mn();
      } catch {
        try {
          return fn();
        } catch {
          return vn();
        }
      }
    },
    En =
      "https://endpoint1.collection.eu.sumologic.com/receiver/v1/http/ZaVnC4dhaV0k0LvHVp9MzZlcaVeXtInn2jSHmUKeySYrKqLVkl5XrT-qWjrF1t1Hm_orx7gZtL6zbtrtTVsGj78gLUvmjE3KC786Efwg4Iq267cSLOnKfw==",
    yn =
      "https://endpoint1.collection.eu.sumologic.com/receiver/v1/http/ZaVnC4dhaV3lG7lBk3HmcQlulqU62JvgKEN50Qe4fgpjtzyoAQZ_aS5ATeErJkqZlAywcRqYHxWoI6aA-381WmG2eLzuYf0qkCmc6oZQYThhBbV2DQf-RA==",
    bn = 0.1,
    wn = 0.1,
    Cn = 150,
    Et = (t, e) =>
      fetch(t, {
        method: "POST",
        body: JSON.stringify(e),
        keepalive: !0,
      }).catch(() => {}),
    Sn = /(?:https?:)?\/\/[^\s"'<>]+/i,
    In = (t) => {
      const e = Sn.exec(t);
      if (!e) return t;
      let i = "<url>";
      try {
        i = new URL(/^\/\//.test(e[0]) ? "https:" + e[0] : e[0]).hostname;
      } catch {}
      return t.substring(0, e.index) + i;
    },
    Tn = (t) => {
      if (t)
        try {
          return new URL(t).hostname.replace(/^www\./, "");
        } catch {
          return;
        }
    },
    Vn = (t, e = Math.random) => {
      try {
        if (e() >= bn) return;
        const { context: i, url: n, message: s, ...r } = t,
          { xmlSample: a, ...d } = i,
          h = An(),
          c = d.adSystems.join(" > ");
        Et(En, {
          t: "vast-unwrap",
          logId: h,
          ...r,
          message: s && In(s).substring(0, Cn),
          ...d,
          adSystems: c,
          domain: Tn(n),
        }),
          a &&
            e() < wn &&
            Et(yn, {
              t: "vast-unwrap-xml",
              logId: h,
              errorCode: t.errorCode,
              host: d.host,
              adSystems: c,
              xml: a,
            });
      } catch {}
    },
    yt = (t) => {
      try {
        return !!t.$sf && !!t.$sf.ext;
      } catch {
        return !1;
      }
    },
    st = (t) => {
      try {
        if (yt(t)) return t.$sf;
        if (yt(t.parent)) return st(t.parent);
      } catch {}
    },
    ye = (t) => !!st(t),
    qt = (t) => {
      try {
        let e = t;
        for (let i = 0; e && i < 10; i++) {
          if (e.mraid) return e.mraid;
          if (e === e.parent) break;
          e = e.parent;
        }
      } catch {}
    },
    xn = (t) => !!qt(t);
  class Pn {
    constructor(e, i = window) {
      g(this, "safeFrame");
      this.threshold = e;
      const n = st(i);
      if (n) this.safeFrame = n;
      else throw new Yi();
    }
    get isIntersecting() {
      return this.safeFrame.ext.inViewPercentage() >= this.threshold;
    }
    get visible() {
      return this.safeFrame.ext.winHasFocus
        ? this.safeFrame.ext.winHasFocus()
        : !0;
    }
    observe() {}
    unobserve() {}
  }
  function Kt(t) {
    return !(t.hidden || t.webkitHidden || t.mozHidden || t.msHidden);
  }
  function kn(t, e) {
    const i = () => e(Kt(t));
    [
      "visibilitychange",
      "webkitvisibilitychange",
      "mozvisibilitychange",
      "msvisibilitychange",
    ].forEach((s) => t.addEventListener(s, i));
  }
  class Rn {
    constructor(e, i) {
      g(this, "root", null);
      g(this, "rootMargin", "");
      g(this, "thresholds", []);
      this.callback = e;
    }
    disconnect() {}
    observe(e) {
      this.callback([{ isIntersecting: !0 }], this);
    }
    takeRecords() {
      return [];
    }
    unobserve(e) {}
  }
  const On = (t = window, e, i) => {
    try {
      return new t.IntersectionObserver(e, i);
    } catch {
      return new Rn(e, i);
    }
  };
  class Dn {
    constructor(e, i, n = window) {
      g(this, "_isIntersecting", !1);
      g(this, "_visible", !1);
      g(this, "intersectionObserver");
      this.element = e;
      const s = this.callback.bind(this),
        r = { threshold: i / 100 };
      (this.intersectionObserver = On(n, s, r)),
        kn(n.document, (a) => {
          this._visible = a;
        }),
        (this._visible = Kt(n.document));
    }
    get isIntersecting() {
      return this._isIntersecting;
    }
    get visible() {
      return this._visible;
    }
    observe() {
      this.intersectionObserver.observe(this.element);
    }
    unobserve() {
      this.intersectionObserver.unobserve(this.element);
    }
    callback(e) {
      e.forEach((i) => (this._isIntersecting = i.isIntersecting));
    }
  }
  class Mn {
    constructor(e, i = window) {
      g(this, "_isIntersecting", !1);
      g(this, "_visible", !1);
      g(this, "mraid");
      g(this, "onExposureChange", (e) => {
        (this._isIntersecting = e >= this.threshold), (this._visible = e > 0);
      });
      (this.threshold = e), (this.mraid = qt(i));
    }
    get isIntersecting() {
      return this._isIntersecting;
    }
    get visible() {
      return this._visible;
    }
    observe() {
      var e;
      typeof ((e = this.mraid) == null ? void 0 : e.addEventListener) ==
        "function" &&
        this.mraid.addEventListener("exposureChange", this.onExposureChange);
    }
    unobserve() {
      var e;
      typeof ((e = this.mraid) == null ? void 0 : e.removeEventListener) ==
        "function" &&
        this.mraid.removeEventListener("exposureChange", this.onExposureChange);
    }
  }
  const Nn = "amp:visibilitychange";
  function be(t, e) {
    try {
      const i = e(t);
      if (i) return i;
      if (t !== t.parent) return be(t.parent, e);
    } catch {}
  }
  const Ln = (t) => !!t.AMP_CONTEXT_DATA && !!t.AMP_CONTEXT_DATA.canonicalUrl,
    zn = (t) => !!t.context && !!t.context.renderStart,
    Jt = (t) => !!be(t, Ln),
    rt = (t) => !!be(t, zn),
    Bn = (t) => be(t, (e) => e.AMP_CONTEXT_DATA),
    Zt = (t) => be(t, (e) => e.context),
    Un = (t) => rt(t) || Jt(t);
  class Hn {
    constructor(e, i = window, n) {
      g(this, "_isIntersecting", !1);
      g(this, "_visible", !1);
      g(this, "isObserving", !1);
      (this.threshold = e),
        (this.scope = i),
        (this.ampContext = n),
        (this._visible = !this.ampContext.hidden),
        this.scope.addEventListener(Nn, () => {
          this._visible = !this.ampContext.hidden;
        });
    }
    get isIntersecting() {
      return this._isIntersecting;
    }
    get visible() {
      return this._visible;
    }
    observe() {
      (this.isObserving = !0),
        this.ampContext.observeIntersection((e) => {
          e.forEach((i) => {
            this.isObserving &&
              (this._isIntersecting =
                i.intersectionRatio >= this.threshold / 100);
          });
        });
    }
    unobserve() {
      this.isObserving = !1;
    }
  }
  class _n {
    constructor(e, i, n, s = window) {
      g(this, "viewabilityObserver");
      g(this, "timeInView", 0);
      g(this, "intervalId");
      if (
        ((this.element = e), (this.duration = i), (this.threshold = n), xn(s))
      )
        this.viewabilityObserver = new Mn(n, s);
      else if (rt(s)) {
        const r = Zt(s);
        this.viewabilityObserver = new Hn(n, s, r);
      } else
        ye(s)
          ? (this.viewabilityObserver = new Pn(n, s))
          : (this.viewabilityObserver = new Dn(e, n, s));
    }
    observe() {
      return (
        this.viewabilityObserver.observe(),
        new Promise((e) => {
          this.intervalId = setInterval(() => {
            this.viewabilityObserver.isIntersecting &&
            this.viewabilityObserver.visible
              ? (this.timeInView += 100)
              : (this.timeInView = 0),
              this.timeInView >= this.duration * 1e3 &&
                (clearInterval(this.intervalId), this.unobserve(), e());
          }, 100);
        })
      );
    }
    unobserve() {
      (this.timeInView = 0),
        this.viewabilityObserver.unobserve(),
        this.intervalId && clearInterval(this.intervalId);
    }
  }
  class Fn {
    constructor() {
      g(this, "events", new Map());
    }
    addEventListener(e, i) {
      const n = this.events.get(e) || [];
      n.push(i), this.events.set(e, n);
    }
    removeEventListener(e, i) {
      const n = this.events.get(e) || [],
        s = n.indexOf(i);
      s !== -1 && n.splice(s, 1), this.events.set(e, n);
    }
    on(e) {
      return new Promise((i) => this.addEventListener(e, i));
    }
    dispatchEvent(e, i) {
      (this.events.get(e) || []).forEach((s) => s(i));
    }
    clearEventListeners() {
      this.events.clear();
    }
  }
  const Gn = (t, e, i) => {
      const n =
        (t == null ? void 0 : t.message) ||
        (t == null ? void 0 : t.toString()) ||
        "Unknown error";
      if (n.includes("Failed to fetch") || n.includes("Load failed")) {
        if (e.startsWith("http") && !e.startsWith(i.origin)) return new Ji();
        if (i.protocol === "https:" && e.startsWith("http:")) return new Zi();
        try {
          new URL(e);
        } catch {
          return new en();
        }
        if (typeof navigator < "u" && navigator.onLine === !1) return new tn();
        const s = new URL(e);
        if (
          s.hostname === "localhost" ||
          s.hostname === "127.0.0.1" ||
          s.hostname === "0.0.0.0" ||
          s.hostname.endsWith(".local")
        )
          return new nn();
      }
      return new Ne();
    },
    Xn = async (t, e, i) => {
      try {
        const n = await fetch(t, {
          method: e.method,
          body: e.body,
          credentials: e.credentials,
          headers: e.headers,
        }).catch((s) => {
          throw Gn(s, t, i);
        });
        if (!n.ok) throw $t(n.status);
        try {
          return await n.json();
        } catch {
          throw new Qt();
        }
      } catch (n) {
        throw n instanceof L ? n : new Ne();
      }
    },
    Wn = (t, e) =>
      new Promise((i, n) => {
        const s = new XMLHttpRequest();
        try {
          s.open(e.method, t, !0);
        } catch {
          n(new rn());
          return;
        }
        try {
          Object.entries(e.headers).forEach(([r, a]) => {
            s.setRequestHeader(r, a);
          });
        } catch {
          n(new an());
          return;
        }
        e.credentials === "include" && (s.withCredentials = !0),
          (s.onreadystatechange = () => {
            if (s.readyState === 4)
              if (s.status >= 200 && s.status < 300)
                try {
                  const r = JSON.parse(s.responseText);
                  i(r);
                } catch {
                  n(new Qt());
                }
              else n($t(s.status));
          }),
          (s.onerror = () => {
            n(new Ne());
          }),
          (s.ontimeout = () => {
            n(new sn());
          }),
          (s.timeout = 5e3);
        try {
          s.send(e.body);
        } catch {
          n(new on());
        }
      }),
    ei = (t, e, i) =>
      typeof fetch == "function"
        ? Xn(t, e, i)
        : typeof XMLHttpRequest == "function"
        ? Wn(t, e)
        : Promise.reject(new qi()),
    jn = (t, e, i) =>
      typeof navigator.sendBeacon == "function"
        ? navigator.sendBeacon(t, e.body)
        : ei(t, e, i),
    Qn = { makeRequest: ei, makeBeaconRequest: jn },
    Ue = { BASE_URL: "/", DEV: !1, MODE: "production", PROD: !0, SSR: !1 },
    $n =
      (Ue == null ? void 0 : Ue.VITE_EVENTS_URL) || "https://s.seedtag.com/e/",
    Yn = { ...Me, ...pe, ...ie, ...Ee, ...ge, ...nt, ...it, ...ve, ...Ft };
  class qn {
    constructor(e, i) {
      g(this, "exportedEvents", Object.values(Yn));
      g(this, "getEventEndpoint", (e) => $n + (e ? "ev" : "e"));
      (this.payload = e), (this.window = i);
    }
    reportErrorEvent(e, i = {}) {
      const n = { errorType: e.name, ...i, name: Pe.Error },
        s = { ...this.payload, events: [n] };
      this.sendEvent(s),
        e instanceof se ||
          gn(
            e,
            this.payload.sourceType,
            this.payload.token,
            i.adUnitType || "",
            i.adUnitName || "",
            this.payload.templateName || "",
            this.payload.version || "",
            this.payload.url,
            this.payload.device,
            this.payload.browser,
            this.payload.publisherCountry
          );
    }
    reportEvent(e, i) {
      if (!this.exportedEvents.includes(e)) return;
      if (e === Pe.Error) {
        const r = new Error("Unknown error - " + i.errorType);
        return this.reportErrorEvent(r, i);
      }
      const n = { name: e, ...i },
        s = { ...this.payload, events: [n] };
      this.sendEvent(s);
    }
    updatePayload(e) {
      this.payload = { ...this.payload, ...e };
    }
    getPayload() {
      return this.payload;
    }
    async sendEvent(e) {
      e.events.forEach(this.mapEventPayload);
      const i = btoa(JSON.stringify(e));
      (this.payload.events = []),
        Qn.makeBeaconRequest(
          this.getEventEndpoint(!!this.payload.eventChunk),
          { method: "POST", body: i, credentials: "include", headers: {} },
          this.window.location
        );
    }
    mapEventPayload(e) {
      e.channel === Xt.Deal && (e.channel = "programmatic-direct");
    }
  }
  var le = ((t) => (
      (t.FIXED = "fixed"), (t.MOBILE = "mobile"), (t.UNKNOWN = "unknown"), t
    ))(le || {}),
    Qe = ((t) => ((t.Desktop = "desktop"), (t.Handheld = "handheld"), t))(
      Qe || {}
    ),
    q = ((t) => (
      (t.Android = "Android"),
      (t.iOS = "iOS"),
      (t.Windows = "Windows"),
      (t.Mac_OS = "Mac OS"),
      (t.Linux = "Linux"),
      (t.Chromium_OS = "Chromium OS"),
      (t.Ubuntu = "Ubuntu"),
      t
    ))(q || {}),
    K = ((t) => (
      (t.Chrome = "chrome"),
      (t.Safari = "safari"),
      (t.Facebook = "facebook"),
      (t.Firefox = "firefox"),
      (t.Instagram = "instagram"),
      (t.Bot = "bot"),
      (t.Other = "other"),
      t
    ))(K || {});
  const Kn = (t) => {
      var i;
      const e = (i = t.navigator.connection) == null ? void 0 : i.effectiveType;
      return je() || e === "wifi" || e === "ethernet"
        ? le.FIXED
        : e === "cellular" || e === "wimax"
        ? le.MOBILE
        : le.UNKNOWN;
    },
    Jn = (t) => {
      const i = /Mobile|Android|iPhone|iPad|iPod|Windows Phone/i.test(t)
        ? Qe.Handheld
        : Qe.Desktop;
      let n;
      /Android/i.test(t)
        ? (n = q.Android)
        : /iPhone|iPad|iPod/i.test(t)
        ? (n = q.iOS)
        : /Windows/i.test(t)
        ? (n = q.Windows)
        : /Mac OS/i.test(t)
        ? (n = q.Mac_OS)
        : /Linux/i.test(t)
        ? (n = q.Linux)
        : /CrOS/i.test(t)
        ? (n = q.Chromium_OS)
        : /Ubuntu/i.test(t) && (n = q.Ubuntu);
      let s = K.Other;
      return (
        /bot|crawler|spider|slurp|bing|baidu|duckduckgo|yandex|teoma|facebookexternalhit|twitterbot|whatsapp|googlebot|adsbot|mediapartners/i.test(
          t.toLowerCase()
        )
          ? (s = K.Bot)
          : /Chrome/i.test(t) && !/Edg|OPR|FBAN|Instagram/i.test(t)
          ? (s = K.Chrome)
          : /Safari/i.test(t) && !/Chrome|CriOS/i.test(t)
          ? (s = K.Safari)
          : /Firefox/i.test(t)
          ? (s = K.Firefox)
          : /FBAN|FBAV/i.test(t)
          ? (s = K.Facebook)
          : /Instagram/i.test(t) && (s = K.Instagram),
        { device: i, os: n, browser: s }
      );
    },
    Zn = (t) => {
      let e;
      return (
        rt(t) && (e = Zt(t)),
        Jt(t) && (e = Bn(t)),
        e != null && e.canonicalUrl
          ? e == null
            ? void 0
            : e.canonicalUrl
          : ye(t)
          ? t.document.referrer
          : t.location.href
      );
    },
    es = (t, e) => {
      const i = t.navigator.userAgent,
        n = Jn(i),
        s = Kn(t);
      return {
        version: pn(),
        sourceType: e,
        url: Zn(t),
        safeframe: ye(t),
        browser: n.browser,
        os: n.os,
        device: n.device,
        connectionType: s,
        infiniteScroll: !1,
        events: [],
      };
    },
    ts = (t, e) => {
      const i = e.createElement("img");
      (i.loading = "eager"), (i.src = t);
    },
    is = (t, e) => {
      try {
        const s = new DOMParser()
          .parseFromString(t, "text/html")
          .querySelector("script");
        if (s) {
          const r = e.createElement("script");
          (r.src = s.src),
            s.async && (r.async = !0),
            s.type && (r.type = s.type),
            e.body.appendChild(r);
        }
      } catch (i) {
        return i instanceof Error ? i : new Ki();
      }
    };
  var ns = Object.defineProperty,
    ss = (t, e, i) =>
      e in t
        ? ns(t, e, { enumerable: !0, configurable: !0, writable: !0, value: i })
        : (t[e] = i),
    u = (t, e, i) => (ss(t, typeof e != "symbol" ? e + "" : e, i), i),
    ti = ((t) => ((t.Error = "error"), t))(ti || {}),
    ii = ((t) => (
      (t.AdRequest = "ad-request"),
      (t.AdResolve = "ad-resolved"),
      (t.AdNotResolved = "ad-not-resolved"),
      t
    ))(ii || {}),
    x = ((t) => (
      (t.AdReady = "ad-ready"),
      (t.AdView = "ad-view"),
      (t.AdInsert = "ad-insert"),
      (t.AdClick = "ad-click"),
      (t.AdClose = "ad-xtocloseclick"),
      (t.AdIframeReady = "ad-iframe-ready"),
      (t.AdOverlay = "ad-overlay"),
      t
    ))(x || {}),
    Le = ((t) => (
      (t.MinipassConnected = "minipass-connected"),
      (t.AdCreativeImpression = "ad-creative-impression"),
      (t.AdCreativeClick = "ad-creative-click"),
      t
    ))(Le || {}),
    at = ((t) => ((t.AdCreativeResize = "ad-creative-resize"), t))(at || {}),
    R = ((t) => (
      (t.VideoVastAvailable = "video-vast-available"),
      (t.VideoVastLoaded = "video-vast-loaded"),
      (t.VideoReady = "video-ready"),
      (t.VideoLazyPlay = "video-lazyplay"),
      (t.VideoStarted = "video-started"),
      (t.VideoImpression = "video-impression"),
      (t.VideoPlay = "video-play"),
      (t.VideoPlayPercentile25 = "video-played-percentile-25"),
      (t.VideoPlayPercentile50 = "video-played-percentile-50"),
      (t.VideoPlayPercentile75 = "video-played-percentile-75"),
      (t.VideoEnd = "video-end"),
      (t.VideoClick = "video-click"),
      (t.VideoSkip = "video-skip"),
      (t.VideoError = "video-error"),
      (t.VideoViewableImpression = "video-viewable-impression"),
      (t.VideoPaused = "video-paused"),
      (t.VideoResumed = "video-resumed"),
      (t.VideoAllAdsCompleted = "video-all-ads-completed"),
      (t.VideoExpand = "video-expand"),
      t
    ))(R || {}),
    oe = ((t) => (
      (t.AdViewability1s50 = "ad-viewability-1s50"),
      (t.AdViewability1s100 = "ad-viewability-1s100"),
      (t.AdViewability2s50 = "ad-viewability-2s50"),
      (t.AdViewability3s50 = "ad-viewability-3s50"),
      t
    ))(oe || {}),
    ni = ((t) => (
      (t.LazyInsert = "ad-lazyinsert"),
      (t.LazyInsertNotReady = "ad-lazyinsert-not-ready"),
      t
    ))(ni || {}),
    si = ((t) => (
      (t.XandrViewabilityWrapperChange = "appnexus-viewability-wrapper-change"),
      t
    ))(si || {});
  const me = { ...x, ...R, ...oe, ...ti, ...si, ...Le, ...ni, ...ii };
  var V = ((t) => (
      (t.DISPLAY = "display"), (t.VIDEO = "video"), (t.NATIVE = "native"), t
    ))(V || {}),
    ot = ((t) => (
      (t.Open = "open"), (t.Deal = "deal"), (t.Direct = "direct"), t
    ))(ot || {});
  const rs = (t) => /^OM\d+x\d+$/.test(t),
    ri = (t) =>
      [
        "CEV",
        "COV",
        "CBV",
        "CEDv",
        "CEDh",
        "CID",
        "CFD",
        "CN",
        "PCEV",
        "PCOV",
        "PCBV",
        "PCEDv",
        "PCEDh",
        "PCID",
        "PCFD",
        "PCN",
      ].includes(t),
    $ = (t) => ["OMV", "COV", "PCOV"].includes(t),
    as = (t) => /^C\d+x\d+$/.test(t);
  var z = ((t) => (
    (t.InTerstitial = "inTerstitial"),
    (t.InBanner = "inBanner"),
    (t.InArticle = "inArticle"),
    (t.InScreen = "inScreen"),
    (t.InTop = "inTop"),
    (t.InSkin = "inSkin"),
    (t.InImage = "inImage"),
    (t.InImageRestricted = "inImageRestricted"),
    t
  ))(z || {});
  class B extends Error {
    constructor() {
      super(), (this.name = "Error");
    }
  }
  class os extends B {
    constructor() {
      super(), (this.name = "AdUnitTypeNotSupportedError");
    }
  }
  class ds extends B {
    constructor() {
      super(), (this.name = "ProductTypeNotSupportedError");
    }
  }
  class bt extends B {
    constructor() {
      super(), (this.name = "NativeAssetsInvalidError");
    }
  }
  class hs extends B {
    constructor() {
      super(), (this.name = "NativeParseError");
    }
  }
  class cs extends B {
    constructor() {
      super(), (this.name = "AdCanvasNotFoundError");
    }
  }
  class ls extends B {
    constructor() {
      super(), (this.name = "AdControlsNotFoundError");
    }
  }
  class us extends B {
    constructor() {
      super(), (this.name = "AdRenderNotInitializedError");
    }
  }
  class Ce extends B {
    constructor() {
      super(), (this.name = "AdUnitNotInitializedError");
    }
  }
  class ps extends B {
    constructor() {
      super(), (this.name = "AdUnitAlreadyInitiatedError");
    }
  }
  class gs extends B {
    constructor() {
      super(), (this.name = "AdContainerNotInitializedError");
    }
  }
  class vs extends B {
    constructor() {
      super(), (this.name = "InvalidViewabilityEventError");
    }
  }
  class ms extends B {
    constructor() {
      super(), (this.name = "SafeFrameNotFoundError");
    }
  }
  class fs extends B {
    constructor() {
      super(), (this.name = "CreativeIframeDocInaccessibleError");
    }
  }
  class As extends B {
    constructor() {
      super(), (this.name = "CreativeIframeWriteFailedError");
    }
  }
  const Q = (t = navigator.userAgent) =>
      /Android|web0S|iPhone|iPad|iPod|BlackBerry|Opera Mini/i.test(t),
    Es = (t = navigator.userAgent) => !Q(t),
    ai = (t, e) => {
      const i = document.createElement("iframe");
      return (
        e &&
          i.setAttribute(
            "sandbox",
            "allow-scripts allow-same-origin allow-popups"
          ),
        (i.style.border = "none"),
        (i.style.overflow = "hidden"),
        (i.scrolling = "no"),
        (i.id = t),
        (i.style.height = "100%"),
        (i.style.width = "100%"),
        i
      );
    },
    wt = (t) => {
      try {
        return !!t.$sf && !!t.$sf.ext;
      } catch {
        return !1;
      }
    },
    fe = (t) => {
      try {
        if (wt(t)) return t.$sf;
        if (wt(t.parent)) return fe(t.parent);
      } catch {}
    },
    oi = (t) => !!fe(t),
    di = (t) => {
      try {
        let e = t;
        for (let i = 0; e && i < 10; i++) {
          if (e.mraid) return e.mraid;
          if (e === e.parent) break;
          e = e.parent;
        }
      } catch {}
    },
    ys = (t) => !!di(t);
  class bs {
    constructor(e, i = window) {
      u(this, "safeFrame"), (this.threshold = e);
      const n = fe(i);
      if (n) this.safeFrame = n;
      else throw new ms();
    }
    get isIntersecting() {
      return this.safeFrame.ext.inViewPercentage() >= this.threshold;
    }
    get visible() {
      return this.safeFrame.ext.winHasFocus
        ? this.safeFrame.ext.winHasFocus()
        : !0;
    }
    observe() {}
    unobserve() {}
  }
  function hi(t) {
    return !(t.hidden || t.webkitHidden || t.mozHidden || t.msHidden);
  }
  function ws(t, e) {
    const i = () => e(hi(t));
    [
      "visibilitychange",
      "webkitvisibilitychange",
      "mozvisibilitychange",
      "msvisibilitychange",
    ].forEach((n) => t.addEventListener(n, i));
  }
  class Cs {
    constructor(e, i) {
      u(this, "root", null),
        u(this, "rootMargin", ""),
        u(this, "thresholds", []),
        (this.callback = e);
    }
    disconnect() {}
    observe(e) {
      this.callback([{ isIntersecting: !0 }], this);
    }
    takeRecords() {
      return [];
    }
    unobserve(e) {}
  }
  const Ss = (t = window, e, i) => {
    try {
      return new t.IntersectionObserver(e, i);
    } catch {
      return new Cs(e, i);
    }
  };
  class Is {
    constructor(e, i, n = window) {
      u(this, "_isIntersecting", !1),
        u(this, "_visible", !1),
        u(this, "intersectionObserver"),
        (this.element = e);
      const s = this.callback.bind(this),
        r = { threshold: i / 100 };
      (this.intersectionObserver = Ss(n, s, r)),
        ws(n.document, (a) => {
          this._visible = a;
        }),
        (this._visible = hi(n.document));
    }
    get isIntersecting() {
      return this._isIntersecting;
    }
    get visible() {
      return this._visible;
    }
    observe() {
      this.intersectionObserver.observe(this.element);
    }
    unobserve() {
      this.intersectionObserver.unobserve(this.element);
    }
    callback(e) {
      e.forEach((i) => (this._isIntersecting = i.isIntersecting));
    }
  }
  class Ts {
    constructor(e, i = window) {
      u(this, "_isIntersecting", !1),
        u(this, "_visible", !1),
        u(this, "mraid"),
        u(this, "onExposureChange", (n) => {
          (this._isIntersecting = n >= this.threshold), (this._visible = n > 0);
        }),
        (this.threshold = e),
        (this.mraid = di(i));
    }
    get isIntersecting() {
      return this._isIntersecting;
    }
    get visible() {
      return this._visible;
    }
    observe() {
      var e;
      typeof ((e = this.mraid) == null ? void 0 : e.addEventListener) ==
        "function" &&
        this.mraid.addEventListener("exposureChange", this.onExposureChange);
    }
    unobserve() {
      var e;
      typeof ((e = this.mraid) == null ? void 0 : e.removeEventListener) ==
        "function" &&
        this.mraid.removeEventListener("exposureChange", this.onExposureChange);
    }
  }
  const Vs = "amp:visibilitychange";
  function dt(t, e) {
    try {
      const i = e(t);
      if (i) return i;
      if (t !== t.parent) return dt(t.parent, e);
    } catch {}
  }
  const xs = (t) => !!t.context && !!t.context.renderStart,
    Ps = (t) => !!dt(t, xs),
    ks = (t) => dt(t, (e) => e.context);
  class Rs {
    constructor(e, i = window, n) {
      u(this, "_isIntersecting", !1),
        u(this, "_visible", !1),
        u(this, "isObserving", !1),
        (this.threshold = e),
        (this.scope = i),
        (this.ampContext = n),
        (this._visible = !this.ampContext.hidden),
        this.scope.addEventListener(Vs, () => {
          this._visible = !this.ampContext.hidden;
        });
    }
    get isIntersecting() {
      return this._isIntersecting;
    }
    get visible() {
      return this._visible;
    }
    observe() {
      (this.isObserving = !0),
        this.ampContext.observeIntersection((e) => {
          e.forEach((i) => {
            this.isObserving &&
              (this._isIntersecting =
                i.intersectionRatio >= this.threshold / 100);
          });
        });
    }
    unobserve() {
      this.isObserving = !1;
    }
  }
  class Os {
    constructor(e, i, n, s = window) {
      if (
        (u(this, "viewabilityObserver"),
        u(this, "timeInView", 0),
        u(this, "intervalId"),
        (this.element = e),
        (this.duration = i),
        (this.threshold = n),
        ys(s))
      )
        this.viewabilityObserver = new Ts(n, s);
      else if (Ps(s)) {
        const r = ks(s);
        this.viewabilityObserver = new Rs(n, s, r);
      } else
        oi(s)
          ? (this.viewabilityObserver = new bs(n, s))
          : (this.viewabilityObserver = new Is(e, n, s));
    }
    observe() {
      return (
        this.viewabilityObserver.observe(),
        new Promise((e) => {
          this.intervalId = setInterval(() => {
            this.viewabilityObserver.isIntersecting &&
            this.viewabilityObserver.visible
              ? (this.timeInView += 100)
              : (this.timeInView = 0),
              this.timeInView >= this.duration * 1e3 &&
                (clearInterval(this.intervalId), this.unobserve(), e());
          }, 100);
        })
      );
    }
    unobserve() {
      (this.timeInView = 0),
        this.viewabilityObserver.unobserve(),
        this.intervalId && clearInterval(this.intervalId);
    }
  }
  class Ds {
    constructor() {
      u(this, "events", new Map());
    }
    addEventListener(e, i) {
      const n = this.events.get(e) || [];
      n.push(i), this.events.set(e, n);
    }
    removeEventListener(e, i) {
      const n = this.events.get(e) || [],
        s = n.indexOf(i);
      s !== -1 && n.splice(s, 1), this.events.set(e, n);
    }
    on(e) {
      return new Promise((i) => this.addEventListener(e, i));
    }
    dispatchEvent(e, i) {
      (this.events.get(e) || []).forEach((n) => n(i));
    }
    clearEventListeners() {
      this.events.clear();
    }
  }
  var N = ((t) => (
      (t.CENTER = "center"), (t.TOP = "top"), (t.BOTTOM = "bottom"), t
    ))(N || {}),
    H = ((t) => (
      (t.CENTER = "center"), (t.LEFT = "left"), (t.RIGHT = "right"), t
    ))(H || {}),
    F = ((t) => (
      (t.FIXED = "fixed"),
      (t.ABSOLUTE = "absolute"),
      (t.RELATIVE = "relative"),
      t
    ))(F || {});
  const ci =
    '<svg viewBox="0 0 83.6 83.6" xmlns="http://www.w3.org/2000/svg"><path d="M39.3 78.5C17.6 78.5 0 61 0 39.3 0 17.6 17.6 0 39.3 0 61 0 78.5 17.6 78.5 39.3 78.5 61 61 78.5 39.3 78.5" fill="#1D1D1B" opacity="0.7"></path><path d="M21.6 56.9l34.8-34.8M56.4 56.9L21.6 22.1" style="fill: none; stroke: rgb(255, 255, 255); stroke-linecap: round; stroke-miterlimit: 10; stroke-width: 6.353;"></path></svg>';
  var Y = ((t) => ((t.LEFT = "left"), (t.RIGHT = "right"), t))(Y || {});
  class Ms {
    constructor(e = 1, i, n) {
      u(this, "svg", ci),
        u(this, "closeButtonElement"),
        (this.undoScale = e),
        (this.closeButtonPosition = i),
        (this.onClick = n),
        (this.closeButtonElement = document.createElement("div")),
        this.closeButtonElement.setAttribute("data-testid", "close-button"),
        (this.closeButtonElement.className = "x-to-close st-reset"),
        (this.closeButtonElement.innerHTML = this.svg),
        this.setPositionStyle(this.closeButtonElement),
        this.closeButtonElement.addEventListener("click", () => {
          this.onClick();
        });
    }
    render(e) {
      return e.appendChild(this.closeButtonElement), this.closeButtonElement;
    }
    destroy() {
      this.closeButtonElement.removeEventListener("click", this.onClick),
        this.closeButtonElement.remove();
    }
    setPositionStyle(e) {
      if (
        ((e.style.position = "absolute"),
        this.closeButtonPosition === "right" &&
          ((e.style.top = "6px"),
          (e.style.right = "6px"),
          (e.style.left = "initial")),
        this.closeButtonPosition === "left" &&
          ((e.style.top = "6px"),
          (e.style.left = "6px"),
          (e.style.right = "initial")),
        (e.style.width = "18px"),
        (e.style.height = "18px"),
        (e.style.cursor = "pointer"),
        (e.style.zIndex = "2147483647"),
        this.undoScale !== 1)
      ) {
        const i = 1 / this.undoScale;
        (e.style.transform = `scale(${i.toString()})`),
          this.closeButtonPosition === "left"
            ? (e.style.transformOrigin = "top left")
            : (e.style.transformOrigin = "top right");
      }
    }
  }
  class Ns {
    constructor(e, i) {
      (this.content = e), (this.renderContainer = i);
    }
    init() {
      return this.renderContainer.init();
    }
    render() {
      this.renderContainer.render(this.content);
    }
    destroy() {
      return this.renderContainer.destroy();
    }
    hide() {
      this.renderContainer.setStyle({
        display: "none",
        zIndex: "0",
        opacity: "0",
      });
    }
    show() {
      this.renderContainer.setStyle({
        display: "block",
        zIndex: "1",
        opacity: "1",
      });
    }
    getIframe() {
      return this.renderContainer.getIframe();
    }
    resize(e) {
      this.renderContainer.resize(e);
    }
  }
  class Ct {
    constructor(e, i, n) {
      u(this, "iframe"),
        (this.settings = e),
        (this.canvas = i),
        (this.handleEvent = n),
        (this.iframe = ai(e.iframeId, e.isSandbox)),
        (this.iframe.className = e.isSandbox
          ? "st-standard-ads-sandbox"
          : "st-standard-ads"),
        this.iframe.setAttribute("data-testid", e.iframeId);
    }
    init() {
      return (
        this.canvas.appendChild(this.iframe),
        this.setSize(),
        this.iframe.setAttribute("data-testid", "iframe-ad-container"),
        (this.iframe.name = "seedtag_creative"),
        this.handleEvent(x.AdReady),
        Promise.resolve()
      );
    }
    render(e) {
      const i = this.getHtmlContent(e);
      this.handleEvent(x.AdInsert), (this.iframe.name = "seedtag_creative");
      const n = this.getContentDocument();
      if (!n) throw new fs();
      n.open(),
        n.addEventListener("AdViewEvent", () => this.handleEvent(x.AdView)),
        n.write(i),
        n.close();
      const s = this.getContentDocument();
      if (!(s != null && s.body) || s.body.childElementCount === 0)
        throw new As();
      this.handleEvent(x.AdIframeReady);
    }
    getContentDocument() {
      try {
        return this.iframe.contentDocument;
      } catch {
        return null;
      }
    }
    getIframeBody() {
      var e;
      return (e = this.iframe.contentDocument) == null ? void 0 : e.body;
    }
    destroy() {
      return this.iframe.remove(), Promise.resolve();
    }
    resize(e) {
      (this.settings.adSize = e), this.setSize();
    }
    setStyle(e) {
      (this.iframe.style.display = e.display),
        (this.iframe.style.zIndex = e.zIndex),
        (this.iframe.style.opacity = e.opacity);
    }
    addEventListener(e, i, n) {
      var s, r;
      (r =
        (s = this.iframe.contentWindow) == null
          ? void 0
          : s.document.querySelector(e)) == null || r.addEventListener(i, n);
    }
    getSize() {
      return this.settings.adSize;
    }
    getIframe() {
      return this.iframe;
    }
    setSize() {
      const { width: e, height: i } = this.settings.adSize;
      (this.iframe.style.width = e + "px"),
        (this.iframe.style.height = i + "px");
    }
    getHtmlContent(e) {
      return `<html> <head> <meta charset="utf-8"> <style> html, body, root { font-family: 'Roboto', sans-serif; width: 100%; height: 100%; margin: 0; overflow: hidden; transition: initial; } </style> </head> <body> ${e} </body> <script> document.addEventListener('DOMContentLoaded', () => { const event = new Event('AdViewEvent'); window.document.dispatchEvent(event); }); <\/script> </html>`;
    }
  }
  class St {
    constructor(e, i, n) {
      u(this, "iframe"),
        u(this, "window"),
        u(this, "onCreativeMessage", (s) => {
          s.source === this.iframe.contentWindow &&
            (s.data === li && this.handleEvent(x.AdView),
            s.data === ui && this.handleEvent(x.AdClick));
        }),
        (this.settings = e),
        (this.canvas = i),
        (this.handleEvent = n),
        (this.window = i.ownerDocument.defaultView || window),
        (this.iframe = ai(e.iframeId, e.isSandbox)),
        (this.iframe.className = "st-standard-ads"),
        this.iframe.setAttribute("data-testid", e.iframeId);
    }
    init() {
      return (
        this.canvas.appendChild(this.iframe),
        this.setSize(),
        this.iframe.setAttribute("data-testid", "iframe-ad-container"),
        this.handleEvent(x.AdReady),
        Promise.resolve()
      );
    }
    render(e) {
      this.handleEvent(x.AdInsert),
        this.window.addEventListener("message", this.onCreativeMessage),
        (this.iframe.srcdoc = Ls(e)),
        this.handleEvent(x.AdIframeReady);
    }
    destroy() {
      return (
        this.window.removeEventListener("message", this.onCreativeMessage),
        this.iframe.remove(),
        Promise.resolve()
      );
    }
    resize(e) {
      (this.settings.adSize = e), this.setSize();
    }
    setStyle(e) {
      (this.iframe.style.display = e.display),
        (this.iframe.style.zIndex = e.zIndex),
        (this.iframe.style.opacity = e.opacity);
    }
    addEventListener() {}
    getIframeBody() {}
    getSize() {
      return this.settings.adSize;
    }
    getIframe() {
      return this.iframe;
    }
    setSize() {
      const { width: e, height: i } = this.settings.adSize;
      (this.iframe.style.width = e + "px"),
        (this.iframe.style.height = i + "px");
    }
  }
  const li = "seedtag:ad-view",
    ui = "seedtag:ad-click",
    Ls = (t) =>
      `<html> <head> <meta charset="utf-8"> <style> html, body, root { font-family: 'Roboto', sans-serif; width: 100%; height: 100%; margin: 0; overflow: hidden; transition: initial; } </style> </head> <body> ${t} </body> <script> document.addEventListener('DOMContentLoaded', () => { try { parent.postMessage('${li}', '*') } catch (e) {} }); document.addEventListener('click', () => { try { parent.postMessage('${ui}', '*') } catch (e) {} }, true); <\/script></html>`,
    zs = [1, 2],
    Bs = 2,
    Us = 3,
    Hs = 4,
    _s = 5;
  class Fs {
    static parse(e) {
      try {
        const i = JSON.parse(e).native;
        let n = "",
          s = "",
          r = "",
          a = "",
          d = "",
          h = "";
        const c = i.link.url,
          v = i.privacy;
        if (!Array.isArray(i.assets)) throw new bt();
        return (
          i.assets.forEach((p) => {
            p.img &&
              (zs.indexOf(p.id) >= 0
                ? (n = p.img.url)
                : p.id === _s && (h = p.img.url)),
              p.title && (s = p.title.text || ""),
              p.data &&
                (p.id === Us
                  ? (r = p.data.value || "")
                  : p.id === Bs
                  ? (a = p.data.value || "")
                  : p.id === Hs && (d = p.data.value || ""));
          }),
          {
            link: c,
            img: n,
            headline: s,
            text: r,
            brand: a,
            button: d || void 0,
            privacy: v,
            adsby: void 0,
            show: void 0,
            icon: h || void 0,
          }
        );
      } catch (i) {
        throw i instanceof bt ? i : new hs();
      }
    }
  }
  const Gs = `html,body,ins,#st-ad{position:absolute;margin:0;width:100%;height:100%;overflow:hidden}img[src=undefined],[src="https://creatives.seedtag.com/assets/empty.png"]{display:none}a,u{color:inherit;text-decoration:none!important}*{cursor:pointer}[data-no-clickable]{cursor:initial!important}.native-container{display:flex;flex-direction:column;font-family:arial;font-size:clamp(10px,min(4vh,10vw),18px);background-color:#fff;height:100vh;width:100vw;overflow:hidden}.left{flex:2;display:flex;position:relative;min-height:0;min-width:0}.right{flex:1;display:flex;flex-direction:column;justify-content:center;gap:4%;padding:3%;min-height:0;min-width:0;max-height:100%;overflow:hidden}.native-image-blur{background-position:center;background-size:cover;width:100%;height:100%;position:absolute;filter:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='a' x='0' y='0' width='1' height='1' color-interpolation-filters='sRGB'%3E%3CfeGaussianBlur stdDeviation='5' result='b'/%3E%3CfeMorphology operator='dilate' radius='4'/%3E %3CfeMerge%3E%3CfeMergeNode/%3E%3CfeMergeNode in='b'/%3E%3C/feMerge%3E%3C/filter%3E %3C/svg%3E#a");z-index:1}.native-image-container{flex:1;display:flex;justify-content:center;align-items:center;z-index:2;overflow:hidden}.native-image-container img{max-width:100%;max-height:100%;object-fit:contain}.native-text-container{flex:1;display:flex;flex-direction:column;gap:.3em;overflow:hidden;min-height:0}.native-text-container>div:first-child{flex-shrink:0;font-size:1.4em;font-weight:600}.headline{font-size:1em;font-weight:600}.native-text-container .info{overflow:hidden;display:-webkit-box;-webkit-line-clamp:2;line-clamp:2;-webkit-box-orient:vertical;min-height:1.2em}.native-button-container{display:flex;flex-shrink:0}.native-button-container button{border-radius:4px;padding:.3em .6em;border:solid 2px black;font-weight:600;font-size:inherit;background-color:#fff;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:100%}@media (min-aspect-ratio: 2/1){.native-container{flex-direction:row;font-size:clamp(10px,min(2vw,8vh),28px)}.left{flex:1}.right{flex:2}}@media (min-aspect-ratio: 2/1) and (max-height: 90px){.native-container{font-size:clamp(11px,2vw,14px)}.right{flex-direction:row;align-items:center;gap:2%;padding-block:0}.native-text-container .info{-webkit-line-clamp:1;line-clamp:1}.native-button-container button{border-width:1px}}@media (height: 116px) and (width: 300px){.native-container{font-size:14px;background-color:transparent}.right{flex:1;justify-content:space-around;padding:2%;background:#111111b3;color:#fff}.native-text-container{flex:2;font-size:14px;font-weight:400;line-height:15px}.native-text-container .headline,.native-text-container .info{font-size:10px;line-height:15px;margin-top:5px}.native-button-container{flex:0;align-items:center;white-space:nowrap}.native-button-container button{font-size:10px;border-width:2px}}@media ((80px <= height <= 150px) and (300px <= width <= 500px)){a{background:transparent}.native-container{background-color:transparent}.left{flex:1}.right{flex:1;flex-direction:column;justify-content:space-around;padding:2%;white-space:normal;text-overflow:ellipsis;overflow:hidden;background:#111111b3;color:#fff}.native-button-container{flex:0;align-items:center;white-space:nowrap}.native-button-container button{padding:2% 6%;border-width:2px;font-size:14px;color:#000;border-color:#000}.native-text-container{flex:2}.headline,.info{line-height:13px}}`;
  class Xs {
    constructor(e, i, n) {
      u(this, "getHtmlContent", (s) => {
        const r =
            s.button && s.button !== ""
              ? `<div class="native-button-container" > <button> ${s.button} </button> </div>`
              : "",
          a = s.img ? new URL(s.img).toString() : void 0,
          d = a
            ? `<div class="left"> <div class="native-image-blur" style="background-image:url(${a})"></div> <div class="native-image-container"> <img src=${a} /> </div> </div>`
            : "";
        return ` <style> ${Gs} </style> <a target="_blank" href=${s.link} class="native-container" data-testid="native-container"> ${d} <div class="right"> <div class="native-text-container"> <div> ${s.brand} </div> <div class="headline"> ${s.headline} </div> <div class="info"> ${s.text} </div> </div> ${r} </div> </a>`;
      }),
        (this.content = e),
        (this.container = i),
        (this.handleEvent = n);
    }
    init() {
      return this.container.init();
    }
    render() {
      const e = Fs.parse(this.content),
        i = this.getHtmlContent(e);
      this.container.render(i),
        this.container.addEventListener(".native-container", "click", () => {
          this.handleEvent(x.AdClick);
        });
    }
    destroy() {
      return this.container.destroy();
    }
    getIframe() {
      return this.container.getIframe();
    }
    resize(e) {
      this.container.resize(e);
    }
  }
  var $e = function (t, e) {
    return (
      ($e =
        Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array &&
          function (i, n) {
            i.__proto__ = n;
          }) ||
        function (i, n) {
          for (var s in n)
            Object.prototype.hasOwnProperty.call(n, s) && (i[s] = n[s]);
        }),
      $e(t, e)
    );
  };
  function ht(t, e) {
    if (typeof e != "function" && e !== null)
      throw new TypeError(
        "Class extends value " + String(e) + " is not a constructor or null"
      );
    $e(t, e);
    function i() {
      this.constructor = t;
    }
    t.prototype =
      e === null ? Object.create(e) : ((i.prototype = e.prototype), new i());
  }
  var T = function () {
      return (
        (T =
          Object.assign ||
          function (t) {
            for (var e, i = 1, n = arguments.length; i < n; i++) {
              e = arguments[i];
              for (var s in e)
                Object.prototype.hasOwnProperty.call(e, s) && (t[s] = e[s]);
            }
            return t;
          }),
        T.apply(this, arguments)
      );
    },
    y = {
      AD_METADATA: "adMetadata",
      ALL_ADS_COMPLETED: "allAdsCompleted",
      CLICK: "click",
      COMPLETE: "complete",
      DURATION_CHANGE: "durationChange",
      FIRST_QUARTILE: "firstQuartile",
      IMPRESSION: "impression",
      INTERACTION: "interaction",
      LINEAR_CHANGED: "linearChanged",
      LOADED: "loaded",
      LOG: "log",
      MIDPOINT: "midpoint",
      PAUSED: "pause",
      RESUMED: "resume",
      SKIPPABLE_STATE_CHANGED: "skippableStateChanged",
      SKIPPED: "skip",
      STARTED: "start",
      THIRD_QUARTILE: "thirdQuartile",
      USER_CLOSE: "userClose",
      VOLUME_CHANGED: "volumeChange",
      VOLUME_MUTED: "mute",
      VIEWABLE_IMPRESSION: "viewable_impression",
      AD_ERROR: "adError",
      AD_PROGRESS: "adProgress",
      IFRAME_READY: "iframeReady",
    },
    Re;
  (function (t) {
    (t.AD_LOAD = "adLoadError"), (t.AD_PLAY = "adPlayError");
  })(Re || (Re = {}));
  var Z = (function () {
      function t(e) {
        this.vastAdError = e;
      }
      return (
        (t.prototype.getErrorCode = function () {
          return this.vastAdError.code;
        }),
        (t.prototype.getMessage = function () {
          return this.vastAdError.message;
        }),
        (t.prototype.getType = function () {
          return (
            this.vastAdError.type ||
            (this.getErrorCode() === 901 ? Re.AD_PLAY : Re.AD_LOAD)
          );
        }),
        (t.prototype.getVastErrorCode = function () {
          return this.vastAdError.code;
        }),
        (t.prototype.getInnerError = function () {
          return new Error(this.getMessage());
        }),
        (t.prototype.getContext = function () {
          return this.vastAdError.context;
        }),
        (t.prototype.setContext = function (e) {
          this.vastAdError.context = e;
        }),
        t
      );
    })(),
    It = function (t, e) {
      e === void 0 && (e = { withCredentials: !1 });
      var i = t.method || "GET",
        n = t.headers || {};
      return new Promise(function (s, r) {
        var a = new XMLHttpRequest(),
          d = function () {
            var f = a.responseText,
              m = a.getResponseHeader("Content-Type");
            s(
              /application\/json/.test((m || "").toLowerCase())
                ? JSON.parse(f)
                : f
            );
          },
          h = function (f) {
            return r(
              new TypeError(
                "Network request failed (".concat(f, ") to ").concat(t.url)
              )
            );
          };
        (a.onreadystatechange = function () {
          a.readyState === 4 &&
            (a.status >= 200 && a.status < 300 ? d() : h(a.status));
        }),
          a.open(i, t.url, !0),
          (a.withCredentials = e.withCredentials || !1);
        for (var c = Object.keys(t.headers || {}), v = 0; v < c.length; v++) {
          var p = n[c[v]];
          a.setRequestHeader(c[v], (t && p) || "");
        }
        a.send(t.method !== "GET" ? t.body : void 0);
      });
    },
    w = (function () {
      function t() {}
      return (
        (t.getXMLDoc = function (e) {
          var i;
          if (t.supportActiveX()) {
            try {
              i = new ActiveXObject("Msxml2.DOMDocument.6.0");
            } catch {
              try {
                i = new ActiveXObject("Msxml2.DOMDocument.3.0");
              } catch {
                i = new ActiveXObject("Microsoft.XMLDOM");
              }
            }
            (i.async = !1), i.loadXML(e);
          } else if (DOMParser) {
            var n = new DOMParser();
            i = n.parseFromString(e, "text/xml");
          } else
            throw new Error(
              "Connot parse XML, ActiveXObject or DOMParser not available"
            );
          return i;
        }),
        (t.getNodeContent = function (e) {
          if (e)
            try {
              var i = t.getFirstChild(e);
              return i ? t.getNodeTextContent(i) : "";
            } catch {}
        }),
        (t.getAttributeValue = function (e, i) {
          try {
            var n = e.getAttribute(i);
            if (n) return n;
            if (e.attributes[i]) return String(e.attributes[i].value);
            Array.from(e.attributes).forEach(function (s) {
              if (s.name === i)
                return (
                  console.log(s.name, s.value, String(s.value)), String(s.value)
                );
            });
          } catch {}
        }),
        (t.isAllWhitespace = function (e) {
          return !/[^\t\n\r ]/.test(e.textContent ? e.textContent : e.text);
        }),
        (t.isIgnorable = function (e) {
          return e.nodeType === 8 || (e.nodeType === 3 && t.isAllWhitespace(e));
        }),
        (t.getFirstChild = function (e) {
          for (var i = e.firstChild; i; ) {
            if (!t.isIgnorable(i)) return i;
            i = i.nextSibling;
          }
          return null;
        }),
        (t.getNodeTextContent = function (e) {
          var i = e.textContent ? e.textContent : e.text,
            n = i.replace(/[\t\n\r ]+/g, " ");
          return (
            n.charAt(0) === " " && (n = n.substring(1, n.length)),
            n.charAt(n.length - 1) === " " &&
              (n = n.substring(0, n.length - 1)),
            n
          );
        }),
        (t.supportActiveX = function () {
          return (
            (Object &&
              Object.getOwnPropertyDescriptor &&
              Object.getOwnPropertyDescriptor(window, "ActiveXObject")) ||
            "ActiveXObject" in window ||
            !!window.ActiveXObject
          );
        }),
        t
      );
    })(),
    Ye;
  (function (t) {
    t.verificationNotExecuted = "verificationNotExecuted";
  })(Ye || (Ye = {}));
  var de;
  (function (t) {
    (t.impression = "impression"),
      (t.start = "start"),
      (t.click = "click"),
      (t.firstQuartile = "firstQuartile"),
      (t.midpoint = "midpoint"),
      (t.thirdQuartile = "thirdQuartile"),
      (t.complete = "complete"),
      (t.progress = "progress"),
      (t.error = "error"),
      (t.play = "play"),
      (t.paused = "pause"),
      (t.loaded = "loaded");
  })(de || (de = {}));
  var Tt;
  (function (t) {
    (t.VIEWABLE = "viewable"),
      (t.NOT_VIEWABLE = "notViewable"),
      (t.VIEW_UNDETERMINED = "viewUndetermined");
  })(Tt || (Tt = {}));
  var Ws = { 1012: 301, 1007: 403 },
    js = function (t) {
      return (t !== void 0 && Ws[t]) || t;
    },
    Qs = function (t, e, i, n) {
      var s = Math.random().toString(36).substr(-8),
        r = {
          CONTENTPLAYHEAD: String(e),
          CACHEBUSTING: s,
          ERRORCODE: String(js(i)),
          ASSETURI: "",
        };
      return Object.keys(r).reduce(function (a, d) {
        var h = new RegExp("(\\[|%5[bB])".concat(d, "(\\]|%5[dD])"), "g");
        return a.replace(h, function () {
          return r[d];
        });
      }, t);
    },
    ct = 5,
    $s = [100, 201, 300],
    Ys = 2e4,
    qs = function (t) {
      var e = t.trim();
      return /^https:/i.test(e)
        ? "https"
        : /^http:/i.test(e)
        ? "http"
        : /^\/\//.test(e)
        ? "relative"
        : "other";
    },
    Ks = function (t) {
      try {
        var e = t.trim();
        return new URL(/^\/\//.test(e) ? "https:" + e : e).hostname;
      } catch {
        return;
      }
    },
    qe = function (t, e, i, n) {
      if (!(!(t instanceof Z) || t.getContext())) {
        var s = { depth: i.length, adSystems: i };
        e && ((s.host = Ks(e)), (s.scheme = qs(e))),
          typeof n == "string" &&
            $s.indexOf(t.getErrorCode()) !== -1 &&
            (s.xmlSample = n.substring(0, Ys)),
          t.setContext(s);
      }
    },
    Vt = new WeakSet(),
    pi = new WeakMap(),
    gi = function (t) {
      return t.tracking
        .filter(function (e) {
          return e.type === de.error;
        })
        .map(function (e) {
          return e.pixel;
        });
    },
    Js = function (t, e) {
      if (typeof t == "object" && t !== null) {
        if (Vt.has(t)) return;
        Vt.add(t);
      }
      var i = t,
        n = void 0;
      try {
        n = i.getErrorCode();
      } catch {}
      e.forEach(function (s) {
        var r = new Image();
        r.setAttribute("loading", "eager"), (r.src = Qs(s, void 0, n));
      });
    },
    ze = function (t) {
      return It({ method: "GET", url: t }, { withCredentials: !0 }).catch(
        function () {
          return It({ method: "GET", url: t }, { withCredentials: !1 });
        }
      );
    },
    Zs = function (t) {
      var e = Math.random().toString(36).substr(-8);
      return t
        .replace(/\[timestamp\]/gi, String(Date.now()))
        .replace(/\[(random|cachebusting|random_number|TTD_CACHEBUSTER)\]/gi, e)
        .replace(
          /ord=(%n|\{RANDOMNUM\}|%25%25TTD_CACHEBUSTER%25%25)/gi,
          "ord=" + e
        );
    };
  function er(t, e, i) {
    return (
      e === void 0 && (e = ze),
      i === void 0 && (i = ct),
      tr(t) ? mi(t, e, i) : vi(t, e, i)
    );
  }
  var tr = function (t) {
    return t.trim().indexOf("http") !== 0 && t.indexOf("<VAST") !== -1;
  };
  function vi(t, e, i, n, s, r) {
    if (
      (e === void 0 && (e = ze),
      i === void 0 && (i = ct),
      n === void 0 && (n = 0),
      s === void 0 && (s = []),
      r === void 0 && (r = []),
      n >= i)
    ) {
      var a = new Z({
        code: 302,
        message:
          "The maximum number of VAST wrapper redirects has been reached.",
      });
      throw (qe(a, t, r), a);
    }
    return ir(t, e)
      .catch(function (d) {
        throw (qe(d, t, r), d);
      })
      .then(function (d) {
        return mi(d, e, i, ++n, s, r, t);
      });
  }
  function mi(t, e, i, n, s, r, a) {
    e === void 0 && (e = ze),
      i === void 0 && (i = ct),
      n === void 0 && (n = 0),
      s === void 0 && (s = []),
      r === void 0 && (r = []);
    var d = [];
    return sr(t)
      .then(function (h) {
        return (
          (d = gi(h)),
          h.adTagUri
            ? vi(
                h.adTagUri,
                e,
                i,
                n,
                s.concat(d),
                r.concat(h.adSystem || "-")
              ).then(function (c) {
                return dr(h, c);
              })
            : h
        );
      })
      .catch(function (h) {
        throw (qe(h, a, r, t), Js(h, s.concat((h && pi.get(h)) || d)), h);
      });
  }
  function ir(t, e) {
    return (
      e === void 0 && (e = ze),
      e(Zs(t)).catch(function (i) {
        throw new Z({
          code: 1012,
          message: (i && i.message) || "unable to fetch vast " + t,
        });
      })
    );
  }
  var nr = function (t) {
    return {
      version: 4,
      tracking: [],
      clickThrough: "",
      mediafiles: [],
      wrappers: [],
      adSystem: "",
      adId: "",
      adTagUri: "",
      adTitle: "",
      adParameters: "",
      duration: -2,
      creativeId: "",
      viewableImpressions: [],
      xml: t,
      extensions: [],
      verifications: [],
    };
  };
  function sr(t) {
    return !t || !t.trim()
      ? Promise.reject(
          new Z({ code: 303, message: "empty VAST response (no ad)" })
        )
      : or(t).catch(function (e) {
          throw e instanceof Z
            ? e
            : new Z({
                code: 100,
                message: "XML Parsing error: " + ((e && e.message) || e),
              });
        });
  }
  var rr = "http://www.w3.org/2001/XMLSchema-instance",
    ar = function (t) {
      return /\bxsi:/.test(t) && !/\bxmlns:xsi\s*=/.test(t)
        ? t.replace(/<VAST(?=[\s>])/, '<VAST xmlns:xsi="'.concat(rr, '"'))
        : t;
    };
  function or(t) {
    return new Promise(function (e, i) {
      var n = nr(t),
        s = function (l) {
          var b = new Z(l);
          pi.set(b, gi(n)), i(b);
        },
        r = w.getXMLDoc(ar(t)),
        a = r.documentElement;
      if (a.tagName === "parsererror") {
        s({ code: 100, message: "XML Parsing error" });
        return;
      }
      if (a.tagName !== "VAST") {
        s({ code: 100, message: "no <VAST> tag in the file" });
        return;
      }
      Array.from(a.getElementsByTagName("Error")).forEach(function (l) {
        var b = w.getNodeContent(l);
        b && n.tracking.push({ pixel: b, type: de.error });
      });
      var d = a.getElementsByTagName("Ad")[0];
      if (!d) {
        s({ code: 303, message: "no <Ad> tag available" });
        return;
      }
      var h = !!d.getElementsByTagName("Wrapper").length,
        c = !!d.getElementsByTagName("InLine").length;
      if (!h && !c) {
        s({ code: 100, message: "Vast contains neither InLine or Wrapper" });
        return;
      }
      if (
        ((n.version = parseInt(w.getAttributeValue(a, "version") || "0", 10)),
        !n.version || n.version < 2)
      ) {
        s({ code: 102, message: "unsupported VAST version " + n.version });
        return;
      }
      var v = d.getElementsByTagName("Creative")[0];
      if (
        (v && (n.creativeId = w.getAttributeValue(v, "id") || ""),
        (n.adId = w.getAttributeValue(d, "id") || ""),
        (n.adTagUri =
          w.getNodeContent(d.getElementsByTagName("VASTAdTagURI")[0]) || ""),
        h && !n.adTagUri.trim())
      ) {
        s({ code: 300, message: "Wrapper without VASTAdTagURI" });
        return;
      }
      (n.adTitle =
        w.getNodeContent(d.getElementsByTagName("AdTitle")[0]) || ""),
        (n.adSystem =
          w.getNodeContent(d.getElementsByTagName("AdSystem")[0]) || "");
      var p = d.getElementsByTagName("ClickThrough")[0];
      p && (n.clickThrough = w.getNodeContent(p) || ""),
        Array.from(d.getElementsByTagName("Impression")).forEach(function (l) {
          n.tracking.push({
            pixel: w.getNodeContent(l) || "",
            type: de.impression,
            offset: null,
          });
        }),
        Array.from(d.getElementsByTagName("ClickTracking")).forEach(function (
          l
        ) {
          n.tracking.push({
            pixel: w.getNodeContent(l) || "",
            type: de.click,
            offset: null,
          });
        });
      var f = d.getElementsByTagName("Linear")[0];
      if (f)
        (n.duration =
          Ke(w.getNodeContent(f.getElementsByTagName("Duration")[0])) || -2),
          (n.adParameters =
            w.getNodeContent(f.getElementsByTagName("AdParameters")[0]) || ""),
          Array.from(f.getElementsByTagName("Tracking")).forEach(function (l) {
            var b = w.getAttributeValue(l, "event") || null;
            if (b) {
              var M = w.getAttributeValue(l, "offset");
              n.tracking.push({
                pixel: w.getNodeContent(l) || "",
                type: b,
                offset: Ke(M, n.duration),
                offsetPercentage: hr(M),
              });
            }
          }),
          (n.mediafiles = Array.from(f.getElementsByTagName("MediaFile")).map(
            function (l) {
              var b = w.getAttributeValue(l, "type") || "";
              return {
                id: w.getAttributeValue(l, "id") || "",
                type: b,
                url: w.getNodeContent(l) || "",
                width: parseInt(w.getAttributeValue(l, "width") || "", 10),
                height: parseInt(w.getAttributeValue(l, "height") || "", 10),
                delivery: w.getAttributeValue(l, "delivery") || "",
                bitrate: parseInt(w.getAttributeValue(l, "bitrate") || "", 10),
                apiFramework: w.getAttributeValue(l, "apiFramework") || "",
                scalable: !!w.getAttributeValue(l, "scalable"),
                minBitrate: parseInt(
                  w.getAttributeValue(l, "minBitrate") || "",
                  10
                ),
                maxBitrate: parseInt(
                  w.getAttributeValue(l, "maxBitrate") || "",
                  10
                ),
                maintainAspectRatio:
                  w.getAttributeValue(l, "maintainAspectRatio") === "true",
                codec: w.getAttributeValue(l, "codec") || "",
                adParameters: /(javascript|flash)/g.test(b)
                  ? String(n.adParameters)
                  : "",
              };
            }
          ));
      else if (c) {
        s({ code: 201, message: "Ad does not contains <Linear> tag" });
        return;
      }
      (n.viewableImpressions = Array.from(
        d.getElementsByTagName("ViewableImpression") || []
      ).map(function (l) {
        var b = w.getAttributeValue(l, "id") || "",
          M = w.getNodeContent(l.getElementsByTagName("Viewable")[0]) || "",
          X = w.getNodeContent(l.getElementsByTagName("NotViewable")[0]) || "",
          W =
            w.getNodeContent(l.getElementsByTagName("ViewUndetermined")[0]) ||
            "";
        return { id: b, viewable: M, notViewable: X, viewUndetermined: W };
      })),
        (n.extensions = Array.from(a.getElementsByTagName("Extension")).map(
          function (l) {
            return l.outerHTML;
          }
        ));
      var m =
        n.version > 3
          ? a.querySelector("InLine > AdVerifications")
          : a.querySelector("Extensions");
      (n.verifications = m !== null ? (n.verifications = cr(m)) : []),
        c &&
          n.mediafiles.length === 0 &&
          s({ code: 1007, message: "No mediafile found" }),
        e(n);
    });
  }
  var He = function (t) {
    return JSON.parse(JSON.stringify(t));
  };
  function dr(t, e) {
    try {
      var i = He(t);
      return (
        i.version > e.version && (i.version = e.version),
        (i.verifications = i.verifications.concat(e.verifications)),
        !i.adId && e.adId && (i.adId = e.adId),
        e.adTagUri ? (i.adTagUri = e.adTagUri) : (i.adTagUri = ""),
        e.clickThrough && (i.clickThrough = e.clickThrough),
        (i.tracking = i.tracking.concat(e.tracking)),
        (i.adSystem = e.adSystem || i.adSystem),
        (i.mediafiles = e.mediafiles),
        (i.adParameters = e.adParameters),
        (i.duration = e.duration),
        (i.tracking = i.tracking.map(function (s) {
          return s.offsetPercentage !== void 0
            ? T(T({}, s), {
                offset: Ke("".concat(s.offsetPercentage, "%"), i.duration),
              })
            : s;
        })),
        (i.creativeId = e.creativeId || i.creativeId),
        (i.adTitle = e.adTitle || i.adTitle),
        (i.extensions = i.extensions.concat(e.extensions)),
        (i.viewableImpressions = i.viewableImpressions.concat(
          e.viewableImpressions
        )),
        i.wrappers.push(He(e)),
        (i.wrappers = i.wrappers.concat(
          e.wrappers.map(function (s) {
            return He(s);
          })
        )),
        i
      );
    } catch (s) {
      var n = s instanceof Error ? s.message : "".concat(s);
      throw new Z({ code: 100, message: "merge throw an exception " + n });
    }
  }
  var hr = function (t) {
    var e = t && t.match(/^(\d+(?:\.\d+)?)%$/);
    return e ? parseFloat(e[1]) : void 0;
  };
  function Ke(t, e) {
    if ((e === void 0 && (e = 0), !t)) return null;
    var i = t.match(/^\d{2}:\d{2}:\d{2}(\.\d+)?$/),
      n = t.match(/^(\d+(?:\.\d+)?)%$/);
    if (i) {
      var s = t
        .split(":")
        .map(function (a, d) {
          return parseInt(a, 10) * Math.pow(60, 2 - d);
        })
        .reduce(function (a, d) {
          return a + d;
        });
      return Math.floor(s) || null;
    }
    if (n) {
      var r = Math.ceil((parseFloat(n[1]) * e) / 100);
      return r || null;
    }
    return null;
  }
  function cr(t) {
    for (
      var e = [],
        i = Array.from(t.getElementsByTagName("Verification")),
        n = 0,
        s = i;
      n < s.length;
      n++
    ) {
      var r = s[n],
        a = r.getAttribute("vendor");
      if (a) {
        for (
          var d = Array.from(r.getElementsByTagName("JavaScriptResource")),
            h = [],
            c = 0,
            v = d;
          c < v.length;
          c++
        ) {
          var p = v[c],
            f = p.getAttribute("apiFramework"),
            m = p.getAttribute("browserOptional"),
            l = m ? JSON.parse(m) : void 0,
            b = w.getNodeContent(p);
          !b || !f || h.push({ browserOptional: l, apiFramework: f, url: b });
        }
        var M = void 0,
          X = r.getElementsByTagName("VerificationParameters").item(0);
        r && (M = w.getNodeContent(X) || void 0);
        for (
          var W = [],
            Bi = Array.from(r.getElementsByTagName("Tracking")),
            Be = 0,
            mt = Bi;
          Be < mt.length;
          Be++
        ) {
          var ft = mt[Be],
            b = w.getNodeContent(ft);
          if (b) {
            var Ui = ft.getAttribute("event") || "",
              At = Ye[Ui];
            At && W.push({ type: At, url: b });
          }
        }
        e.push({
          vendor: a,
          events: W,
          javascriptResources: h,
          verificationParameters: M,
        });
      }
    }
    return e;
  }
  var xt;
  (function (t) {
    (t.LATEST = "latest"), (t.v3_330_0 = "3.330.0");
  })(xt || (xt = {}));
  var A = (function () {
      function t(e, i) {
        if (
          (i === void 0 && (i = {}),
          (this.type = e),
          (this.data = {}),
          typeof i == "object" && Array.isArray(i))
        )
          switch (e) {
            case t.AdLog:
            case t.AdError:
              (this.data.code = 901), (this.data.message = i[0]);
              break;
            case t.AdClickThru:
              this.data = { url: i[0], id: i[1], playerHandles: i[2] };
              break;
            case t.AdInteraction:
              this.data = { id: i[0] };
              break;
          }
        else if (typeof i == "object") this.data = i;
        else if (typeof i == "string")
          switch (e) {
            case t.AdLog:
            case t.AdError:
              (this.data.code = 901), (this.data.message = i);
              break;
            case t.AdInteraction:
              this.data = { id: i };
              break;
          }
      }
      return (
        (t.AdLoaded = "AdLoaded"),
        (t.AdStarted = "AdStarted"),
        (t.AdStopped = "AdStopped"),
        (t.AdSkipped = "AdSkipped"),
        (t.AdLinearChange = "AdLinearChange"),
        (t.AdSizeChange = "AdSizeChange"),
        (t.AdExpandedChange = "AdExpandedChange"),
        (t.AdSkippableStateChange = "AdSkippableStateChange"),
        (t.AdRemainingTimeChange = "AdRemainingTimeChange"),
        (t.AdDurationChange = "AdDurationChange"),
        (t.AdVolumeChange = "AdVolumeChange"),
        (t.AdImpression = "AdImpression"),
        (t.AdVideoStart = "AdVideoStart"),
        (t.AdVideoFirstQuartile = "AdVideoFirstQuartile"),
        (t.AdVideoMidpoint = "AdVideoMidpoint"),
        (t.AdVideoThirdQuartile = "AdVideoThirdQuartile"),
        (t.AdVideoComplete = "AdVideoComplete"),
        (t.AdClickThru = "AdClickThru"),
        (t.AdInteraction = "AdInteraction"),
        (t.AdUserAcceptInvitation = "AdUserAcceptInvitation"),
        (t.AdUserMinimize = "AdUserMinimize"),
        (t.AdUserClose = "AdUserClose"),
        (t.AdPaused = "AdPaused"),
        (t.AdPlaying = "AdPlaying"),
        (t.AdLog = "AdLog"),
        (t.AdError = "AdError"),
        t
      );
    })(),
    Pt;
  (function (t) {
    (t.VPAIDJS = "vpaidjs"),
      (t.MP4 = "mp4"),
      (t.WEBM = "webm"),
      (t.MPEG = "mpeg"),
      (t.DASH = "mpd");
  })(Pt || (Pt = {}));
  var kt;
  (function (t) {
    (t[(t.REMOVED = -6)] = "REMOVED"),
      (t[(t.REMOVING = -5)] = "REMOVING"),
      (t[(t.ERROR = -4)] = "ERROR"),
      (t[(t.STOPPED = -3)] = "STOPPED"),
      (t[(t.STOPPING = -2)] = "STOPPING"),
      (t[(t.SKIPPED = -1)] = "SKIPPED"),
      (t[(t.SKIPPING = 0)] = "SKIPPING"),
      (t[(t.READY = 1)] = "READY"),
      (t[(t.LOADING = 2)] = "LOADING"),
      (t[(t.LOADED = 3)] = "LOADED"),
      (t[(t.STARTING = 5)] = "STARTING"),
      (t[(t.STARTED = 6)] = "STARTED"),
      (t[(t.PAUSING = 7)] = "PAUSING"),
      (t[(t.PAUSED = 8)] = "PAUSED"),
      (t[(t.RESUMING = 9)] = "RESUMING"),
      (t[(t.PLAYING = 10)] = "PLAYING"),
      (t[(t.COMPLETE = 11)] = "COMPLETE");
  })(kt || (kt = {}));
  var O, k;
  (O = {}),
    (O[A.AdError] = "error"),
    (O[A.AdClickThru] = "click"),
    (O[A.AdPaused] = "pause"),
    (O[A.AdPlaying] = "resume"),
    (O[A.AdSkipped] = "skip"),
    (O[A.AdStarted] = "creativeView"),
    (O[A.AdVideoStart] = "start"),
    (O[A.AdVideoFirstQuartile] = "firstQuartile"),
    (O[A.AdVideoMidpoint] = "midpoint"),
    (O[A.AdVideoThirdQuartile] = "thirdQuartile"),
    (O[A.AdVideoComplete] = "complete"),
    (O[A.AdImpression] = "impression"),
    (O[A.AdUserClose] = "close"),
    (O[A.AdRemainingTimeChange] = "progress"),
    (O[A.AdLoaded] = "loaded");
  var Rt =
    ((k = {}),
    (k[y.ALL_ADS_COMPLETED] = A.AdStopped),
    (k[y.COMPLETE] = A.AdVideoComplete),
    (k[y.DURATION_CHANGE] = A.AdDurationChange),
    (k[y.FIRST_QUARTILE] = A.AdVideoFirstQuartile),
    (k[y.IMPRESSION] = A.AdImpression),
    (k[y.INTERACTION] = A.AdInteraction),
    (k[y.LINEAR_CHANGED] = A.AdLinearChange),
    (k[y.LOADED] = A.AdLoaded),
    (k[y.LOG] = A.AdLog),
    (k[y.MIDPOINT] = A.AdVideoMidpoint),
    (k[y.PAUSED] = A.AdPaused),
    (k[y.RESUMED] = A.AdPlaying),
    (k[y.SKIPPABLE_STATE_CHANGED] = A.AdSkippableStateChange),
    (k[y.SKIPPED] = A.AdSkipped),
    (k[y.STARTED] = A.AdStarted),
    (k[y.THIRD_QUARTILE] = A.AdVideoThirdQuartile),
    (k[y.USER_CLOSE] = A.AdUserClose),
    (k[y.VOLUME_CHANGED] = A.AdVolumeChange),
    (k[y.AD_ERROR] = A.AdError),
    (k[y.CLICK] = A.AdClickThru),
    (k[y.AD_PROGRESS] = A.AdRemainingTimeChange),
    k);
  Object.keys(Rt)
    .map(function (t) {
      return { adEventName: t, vpaidEventName: Rt[t] };
    })
    .reduce(function (t, e) {
      return (t[e.vpaidEventName] = e.adEventName), t;
    }, {});
  var _ = {
      impression: "impression",
      start: "start",
      click: "click",
      firstQuartile: "firstQuartile",
      midpoint: "midpoint",
      thirdQuartile: "thirdQuartile",
      complete: "complete",
      progress: "progress",
      error: "error",
      loaded: "loaded",
      skip: "skip",
      collapse: "collapse",
      minimize: "minimize",
      volumeChange: "volumeChange",
      mute: "mute",
      unmute: "unmute",
    },
    U;
  (U = {}),
    (U[A.AdImpression] = _.impression),
    (U[A.AdVideoStart] = _.start),
    (U[A.AdVideoFirstQuartile] = _.firstQuartile),
    (U[A.AdVideoMidpoint] = _.midpoint),
    (U[A.AdVideoThirdQuartile] = _.thirdQuartile),
    (U[A.AdVideoComplete] = _.complete),
    (U[A.AdClickThru] = _.click),
    (U[A.AdRemainingTimeChange] = _.progress),
    (U[A.AdError] = _.error),
    (U[A.AdLoaded] = _.loaded),
    (U[A.AdSkipped] = _.skip),
    (U[A.AdVolumeChange] = _.volumeChange);
  const lr =
      '<path d="M32.7 48.8c5 3.4 9.9 6.6 14.9 10 .4.3.8.5 1.3.7.9.4 1.3.1 1.4-.8V21.8v-.6c0-.7-.4-.9-1.1-.7-.6.2-1.1.5-1.6.8-5 3.4-9.9 6.6-14.9 9.9v17.6M19.1 31.1h9.1v18h-9.1zM65.1 57.8l-.6-.3c-.8-.5-.9-1.4-.2-2.1 1-1 2.1-2 3-3.1 2.8-3.4 4.3-7.2 4.5-11.4.3-5.5-1.6-10.3-5.7-14.6-.5-.6-1.2-1.1-1.7-1.7-.7-.7-.7-1.5-.1-2.1.7-.6 1.7-.5 2.4.1 4.1 3.6 6.8 7.8 7.8 12.7.2.9.3 1.9.4 2.8 0 .1.1.3.1.4v2.6c0 .1-.1.2-.1.4-.1.9-.2 1.9-.4 2.8-1 4.5-3.3 8.5-6.9 11.9-.5.5-1 1.1-1.9 1.3h-.6z" style="fill: rgb(255, 255, 255);" /><path style="fill: none; stroke: rgb(255, 255, 255); stroke-linecap: round; stroke-miterlimit: 10; stroke-width: 3.147;" d="M65.1 39.9c-.1-3.9-1.7-7.5-5-10.4-.3-.3-.6-.7-.8-1-.2-.6.2-1.2.8-1.5.6-.3 1.4-.2 1.9.3 1 .9 2 1.9 2.8 2.9 3 3.8 4 8 3.3 12.5-.7 3.9-2.7 7.3-5.9 10.2-.7.6-1.7.7-2.4.1-.7-.5-.7-1.4 0-2 2-1.8 3.5-3.8 4.4-6.2.6-1.6.9-3.2.9-4.9" />',
    ur =
      '<path d="M32.5 48.8c5 3.4 9.9 6.6 14.9 10 .4.3.8.5 1.3.7.9.4 1.3.1 1.4-.8v-.6-36.3-.6c0-.7-.4-.9-1.1-.7-.6.2-1.1.5-1.6.8-5 3.4-9.9 6.6-14.9 9.9v17.6M18.9 31.1H28v18h-9.1z" style="fill: rgb(255, 255, 255);"/><path d="M59.2 48.6l17.3-17.2M76.5 48.6L59.2 31.4" style="fill: none; stroke: rgb(255, 255, 255); stroke-linecap: round; stroke-miterlimit: 10; stroke-width: 3.147;"></path>',
    Ot = (t) =>
      `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 95.4 78.8"> <defs> <path d="M0 0h95.4v78.8H0z" /> </defs> <clipPath> <use overflow="visible" /> </clipPath> ${
        t ? ur : lr
      }</svg>`;
  class pr {
    constructor(e, i = !1) {
      (this.adsManager = e), (this.big = i);
    }
    get() {
      const e = document.createElement("div");
      (e.style.position = "absolute"),
        (e.style.top = "0"),
        (e.style.left = "0"),
        (e.style.zIndex = "9999"),
        (e.style.width = this.big ? "26px" : "20px"),
        (e.style.height = this.big ? "26px" : "20px"),
        (e.style.cursor = "pointer"),
        (e.style.backgroundColor = "rgba(29, 29, 27, 0.7)");
      let i = this.adsManager.getVolume() === 0;
      return (
        this.adsManager.addEventListener(y.VOLUME_CHANGED, () => {
          (i = this.adsManager.getVolume() === 0), (e.innerHTML = Ot(i));
        }),
        (e.innerHTML = Ot(i)),
        (e.onclick = () => {
          i ? this.adsManager.setVolume(1) : this.adsManager.setVolume(0);
        }),
        e
      );
    }
  }
  const I = {
    AD_METADATA: "adMetadata",
    ALL_ADS_COMPLETED: "allAdsCompleted",
    CLICK: "click",
    COMPLETE: "complete",
    DURATION_CHANGE: "durationChange",
    FIRST_QUARTILE: "firstQuartile",
    IMPRESSION: "impression",
    INTERACTION: "interaction",
    LINEAR_CHANGED: "linearChanged",
    LOADED: "loaded",
    LOG: "log",
    MIDPOINT: "midpoint",
    PAUSED: "pause",
    RESUMED: "resume",
    SKIPPABLE_STATE_CHANGED: "skippableStateChanged",
    SKIPPED: "skip",
    STARTED: "start",
    THIRD_QUARTILE: "thirdQuartile",
    USER_CLOSE: "userClose",
    VOLUME_CHANGED: "volumeChange",
    VOLUME_MUTED: "mute",
    VIEWABLE_IMPRESSION: "viewable_impression",
    AD_ERROR: "adError",
    AD_PROGRESS: "adProgress",
    IFRAME_READY: "iframeReady",
  };
  var Je = ((t) => (
    (t.AD_LOAD = "adLoadError"), (t.AD_PLAY = "adPlayError"), t
  ))(Je || {});
  class G {
    constructor(e) {
      this.vastAdError = e;
    }
    getErrorCode() {
      return this.vastAdError.code;
    }
    getMessage() {
      return this.vastAdError.message;
    }
    getType() {
      return (
        this.vastAdError.type ||
        (this.getErrorCode() === 901 ? "adPlayError" : "adLoadError")
      );
    }
    getVastErrorCode() {
      return this.vastAdError.code;
    }
    getInnerError() {
      return new Error(this.getMessage());
    }
    getContext() {
      return this.vastAdError.context;
    }
    setContext(e) {
      this.vastAdError.context = e;
    }
  }
  const gr = (t) => ({ type: I.AD_ERROR, getError: () => t }),
    Dt = (t, e = { withCredentials: !1 }) => {
      const i = t.method || "GET",
        n = t.headers || {};
      return new Promise(function (s, r) {
        let a = new XMLHttpRequest();
        const d = () => {
            let v = a.responseText,
              p = a.getResponseHeader("Content-Type");
            s(
              /application\/json/.test((p || "").toLowerCase())
                ? JSON.parse(v)
                : v
            );
          },
          h = (v) =>
            r(new TypeError(`Network request failed (${v}) to ${t.url}`));
        (a.onreadystatechange = () => {
          a.readyState === 4 &&
            (a.status >= 200 && a.status < 300 ? d() : h(a.status));
        }),
          a.open(i, t.url, !0),
          (a.withCredentials = e.withCredentials || !1);
        const c = Object.keys(t.headers || {});
        for (let v = 0; v < c.length; v++) {
          const p = n[c[v]];
          a.setRequestHeader(c[v], (t && p) || "");
        }
        a.send(t.method !== "GET" ? t.body : void 0);
      });
    },
    fi = class ae {
      static getXMLDoc(e) {
        var i;
        if (ae.supportActiveX()) {
          try {
            i = new ActiveXObject("Msxml2.DOMDocument.6.0");
          } catch {
            try {
              i = new ActiveXObject("Msxml2.DOMDocument.3.0");
            } catch {
              i = new ActiveXObject("Microsoft.XMLDOM");
            }
          }
          (i.async = !1), i.loadXML(e);
        } else if (DOMParser) {
          var n = new DOMParser();
          i = n.parseFromString(e, "text/xml");
        } else
          throw new Error(
            "Connot parse XML, ActiveXObject or DOMParser not available"
          );
        return i;
      }
      static getNodeContent(e) {
        if (e)
          try {
            var i = ae.getFirstChild(e);
            return i ? ae.getNodeTextContent(i) : "";
          } catch {}
      }
      static getAttributeValue(e, i) {
        try {
          const n = e.getAttribute(i);
          if (n) return n;
          if (e.attributes[i]) return String(e.attributes[i].value);
          Array.from(e.attributes).forEach((s) => {
            if (s.name === i)
              return (
                console.log(s.name, s.value, String(s.value)), String(s.value)
              );
          });
        } catch {}
      }
      static isAllWhitespace(e) {
        return !/[^\t\n\r ]/.test(e.textContent ? e.textContent : e.text);
      }
      static isIgnorable(e) {
        return e.nodeType === 8 || (e.nodeType === 3 && ae.isAllWhitespace(e));
      }
      static getFirstChild(e) {
        for (var i = e.firstChild; i; ) {
          if (!ae.isIgnorable(i)) return i;
          i = i.nextSibling;
        }
        return null;
      }
      static getNodeTextContent(e) {
        var i = e.textContent ? e.textContent : e.text,
          n = i.replace(/[\t\n\r ]+/g, " ");
        return (
          n.charAt(0) === " " && (n = n.substring(1, n.length)),
          n.charAt(n.length - 1) === " " && (n = n.substring(0, n.length - 1)),
          n
        );
      }
    };
  fi.supportActiveX = () =>
    (Object &&
      Object.getOwnPropertyDescriptor &&
      Object.getOwnPropertyDescriptor(window, "ActiveXObject")) ||
    "ActiveXObject" in window ||
    !!window.ActiveXObject;
  let C = fi;
  var Ai = ((t) => (
      (t.verificationNotExecuted = "verificationNotExecuted"), t
    ))(Ai || {}),
    ue = ((t) => (
      (t.impression = "impression"),
      (t.start = "start"),
      (t.click = "click"),
      (t.firstQuartile = "firstQuartile"),
      (t.midpoint = "midpoint"),
      (t.thirdQuartile = "thirdQuartile"),
      (t.complete = "complete"),
      (t.progress = "progress"),
      (t.error = "error"),
      (t.play = "play"),
      (t.paused = "pause"),
      (t.loaded = "loaded"),
      t
    ))(ue || {}),
    xe = ((t) => (
      (t.VIEWABLE = "viewable"),
      (t.NOT_VIEWABLE = "notViewable"),
      (t.VIEW_UNDETERMINED = "viewUndetermined"),
      t
    ))(xe || {});
  const vr = { 1012: 301, 1007: 403 },
    mr = (t) => (t !== void 0 && vr[t]) || t,
    Ei = (t, e, i, n) => {
      const s = Math.random().toString(36).substr(-8),
        r = {
          CONTENTPLAYHEAD: String(e),
          CACHEBUSTING: s,
          ERRORCODE: String(mr(i)),
          ASSETURI: n || "",
        };
      return Object.keys(r).reduce((a, d) => {
        const h = new RegExp(`(\\[|%5[bB])${d}(\\]|%5[dD])`, "g");
        return a.replace(h, () => r[d]);
      }, t);
    },
    lt = 5,
    fr = [100, 201, 300],
    Ar = 2e4,
    Er = (t) => {
      const e = t.trim();
      return /^https:/i.test(e)
        ? "https"
        : /^http:/i.test(e)
        ? "http"
        : /^\/\//.test(e)
        ? "relative"
        : "other";
    },
    yr = (t) => {
      try {
        const e = t.trim();
        return new URL(/^\/\//.test(e) ? "https:" + e : e).hostname;
      } catch {
        return;
      }
    },
    Ze = (t, e, i, n) => {
      if (!(t instanceof G) || t.getContext()) return;
      const s = { depth: i.length, adSystems: i };
      e && ((s.host = yr(e)), (s.scheme = Er(e))),
        typeof n == "string" &&
          fr.indexOf(t.getErrorCode()) !== -1 &&
          (s.xmlSample = n.substring(0, Ar)),
        t.setContext(s);
    },
    Mt = new WeakSet(),
    yi = new WeakMap(),
    bi = (t) =>
      t.tracking.filter((e) => e.type === ue.error).map((e) => e.pixel),
    br = (t, e) => {
      if (typeof t == "object" && t !== null) {
        if (Mt.has(t)) return;
        Mt.add(t);
      }
      const i = t;
      let n;
      try {
        n = i.getErrorCode();
      } catch {}
      e.forEach((s) => {
        const r = new Image();
        r.setAttribute("loading", "eager"), (r.src = Ei(s, void 0, n));
      });
    },
    we = (t) =>
      Dt({ method: "GET", url: t }, { withCredentials: !0 }).catch(() =>
        Dt({ method: "GET", url: t }, { withCredentials: !1 })
      ),
    wr = (t) => {
      const e = Math.random().toString(36).substr(-8);
      return t
        .replace(/\[timestamp\]/gi, String(Date.now()))
        .replace(/\[(random|cachebusting|random_number|TTD_CACHEBUSTER)\]/gi, e)
        .replace(
          /ord=(%n|\{RANDOMNUM\}|%25%25TTD_CACHEBUSTER%25%25)/gi,
          "ord=" + e
        );
    };
  function Nt(t, e = we, i = lt) {
    return Cr(t) ? Ci(t, e, i) : wi(t, e, i);
  }
  const Cr = (t) => t.trim().indexOf("http") !== 0 && t.indexOf("<VAST") !== -1;
  function wi(t, e = we, i = lt, n = 0, s = [], r = []) {
    if (n >= i) {
      const a = new G({
        code: 302,
        message:
          "The maximum number of VAST wrapper redirects has been reached.",
      });
      throw (Ze(a, t, r), a);
    }
    return Sr(t, e)
      .catch((a) => {
        throw (Ze(a, t, r), a);
      })
      .then((a) => Ci(a, e, i, ++n, s, r, t));
  }
  function Ci(t, e = we, i = lt, n = 0, s = [], r = [], a) {
    let d = [];
    return Tr(t)
      .then(
        (h) => (
          (d = bi(h)),
          h.adTagUri
            ? wi(
                h.adTagUri,
                e,
                i,
                n,
                s.concat(d),
                r.concat(h.adSystem || "-")
              ).then((c) => Si(h, c))
            : h
        )
      )
      .catch((h) => {
        throw (Ze(h, a, r, t), br(h, s.concat((h && yi.get(h)) || d)), h);
      });
  }
  function Sr(t, e = we) {
    return e(wr(t)).catch((i) => {
      throw new G({
        code: 1012,
        message: (i && i.message) || "unable to fetch vast " + t,
      });
    });
  }
  const Ir = (t) => ({
    version: 4,
    tracking: [],
    clickThrough: "",
    mediafiles: [],
    wrappers: [],
    adSystem: "",
    adId: "",
    adTagUri: "",
    adTitle: "",
    adParameters: "",
    duration: -2,
    creativeId: "",
    viewableImpressions: [],
    xml: t,
    extensions: [],
    verifications: [],
  });
  function Tr(t) {
    return !t || !t.trim()
      ? Promise.reject(
          new G({ code: 303, message: "empty VAST response (no ad)" })
        )
      : Pr(t).catch((e) => {
          throw e instanceof G
            ? e
            : new G({
                code: 100,
                message: "XML Parsing error: " + ((e && e.message) || e),
              });
        });
  }
  const Vr = "http://www.w3.org/2001/XMLSchema-instance",
    xr = (t) =>
      /\bxsi:/.test(t) && !/\bxmlns:xsi\s*=/.test(t)
        ? t.replace(/<VAST(?=[\s>])/, `<VAST xmlns:xsi="${Vr}"`)
        : t;
  function Pr(t) {
    return new Promise((e, i) => {
      const n = Ir(t),
        s = (m) => {
          const l = new G(m);
          yi.set(l, bi(n)), i(l);
        },
        r = C.getXMLDoc(xr(t)).documentElement;
      if (r.tagName === "parsererror") {
        s({ code: 100, message: "XML Parsing error" });
        return;
      }
      if (r.tagName !== "VAST") {
        s({ code: 100, message: "no <VAST> tag in the file" });
        return;
      }
      Array.from(r.getElementsByTagName("Error")).forEach((m) => {
        const l = C.getNodeContent(m);
        l && n.tracking.push({ pixel: l, type: ue.error });
      });
      const a = r.getElementsByTagName("Ad")[0];
      if (!a) {
        s({ code: 303, message: "no <Ad> tag available" });
        return;
      }
      const d = !!a.getElementsByTagName("Wrapper").length,
        h = !!a.getElementsByTagName("InLine").length;
      if (!d && !h) {
        s({ code: 100, message: "Vast contains neither InLine or Wrapper" });
        return;
      }
      if (
        ((n.version = parseInt(C.getAttributeValue(r, "version") || "0", 10)),
        !n.version || n.version < 2)
      ) {
        s({ code: 102, message: "unsupported VAST version " + n.version });
        return;
      }
      const c = a.getElementsByTagName("Creative")[0];
      if (
        (c && (n.creativeId = C.getAttributeValue(c, "id") || ""),
        (n.adId = C.getAttributeValue(a, "id") || ""),
        (n.adTagUri =
          C.getNodeContent(a.getElementsByTagName("VASTAdTagURI")[0]) || ""),
        d && !n.adTagUri.trim())
      ) {
        s({ code: 300, message: "Wrapper without VASTAdTagURI" });
        return;
      }
      (n.adTitle =
        C.getNodeContent(a.getElementsByTagName("AdTitle")[0]) || ""),
        (n.adSystem =
          C.getNodeContent(a.getElementsByTagName("AdSystem")[0]) || "");
      const v = a.getElementsByTagName("ClickThrough")[0];
      v && (n.clickThrough = C.getNodeContent(v) || ""),
        Array.from(a.getElementsByTagName("Impression")).forEach((m) => {
          n.tracking.push({
            pixel: C.getNodeContent(m) || "",
            type: ue.impression,
            offset: null,
          });
        }),
        Array.from(a.getElementsByTagName("ClickTracking")).forEach((m) => {
          n.tracking.push({
            pixel: C.getNodeContent(m) || "",
            type: ue.click,
            offset: null,
          });
        });
      const p = a.getElementsByTagName("Linear")[0];
      if (p)
        (n.duration =
          et(C.getNodeContent(p.getElementsByTagName("Duration")[0])) || -2),
          (n.adParameters =
            C.getNodeContent(p.getElementsByTagName("AdParameters")[0]) || ""),
          Array.from(p.getElementsByTagName("Tracking")).forEach((m) => {
            const l = C.getAttributeValue(m, "event") || null;
            if (l) {
              const b = C.getAttributeValue(m, "offset");
              n.tracking.push({
                pixel: C.getNodeContent(m) || "",
                type: l,
                offset: et(b, n.duration),
                offsetPercentage: kr(b),
              });
            }
          }),
          (n.mediafiles = Array.from(p.getElementsByTagName("MediaFile")).map(
            (m) => {
              const l = C.getAttributeValue(m, "type") || "";
              return {
                id: C.getAttributeValue(m, "id") || "",
                type: l,
                url: C.getNodeContent(m) || "",
                width: parseInt(C.getAttributeValue(m, "width") || "", 10),
                height: parseInt(C.getAttributeValue(m, "height") || "", 10),
                delivery: C.getAttributeValue(m, "delivery") || "",
                bitrate: parseInt(C.getAttributeValue(m, "bitrate") || "", 10),
                apiFramework: C.getAttributeValue(m, "apiFramework") || "",
                scalable: !!C.getAttributeValue(m, "scalable"),
                minBitrate: parseInt(
                  C.getAttributeValue(m, "minBitrate") || "",
                  10
                ),
                maxBitrate: parseInt(
                  C.getAttributeValue(m, "maxBitrate") || "",
                  10
                ),
                maintainAspectRatio:
                  C.getAttributeValue(m, "maintainAspectRatio") === "true",
                codec: C.getAttributeValue(m, "codec") || "",
                adParameters: /(javascript|flash)/g.test(l)
                  ? String(n.adParameters)
                  : "",
              };
            }
          ));
      else if (h) {
        s({ code: 201, message: "Ad does not contains <Linear> tag" });
        return;
      }
      (n.viewableImpressions = Array.from(
        a.getElementsByTagName("ViewableImpression") || []
      ).map((m) => {
        const l = C.getAttributeValue(m, "id") || "",
          b = C.getNodeContent(m.getElementsByTagName("Viewable")[0]) || "",
          M = C.getNodeContent(m.getElementsByTagName("NotViewable")[0]) || "",
          X =
            C.getNodeContent(m.getElementsByTagName("ViewUndetermined")[0]) ||
            "";
        return { id: l, viewable: b, notViewable: M, viewUndetermined: X };
      })),
        (n.extensions = Array.from(r.getElementsByTagName("Extension")).map(
          (m) => m.outerHTML
        ));
      const f =
        n.version > 3
          ? r.querySelector("InLine > AdVerifications")
          : r.querySelector("Extensions");
      (n.verifications = f !== null ? (n.verifications = Rr(f)) : []),
        h &&
          n.mediafiles.length === 0 &&
          s({ code: 1007, message: "No mediafile found" }),
        e(n);
    });
  }
  const _e = (t) => JSON.parse(JSON.stringify(t));
  function Si(t, e) {
    try {
      const i = _e(t);
      return (
        i.version > e.version && (i.version = e.version),
        (i.verifications = i.verifications.concat(e.verifications)),
        !i.adId && e.adId && (i.adId = e.adId),
        e.adTagUri ? (i.adTagUri = e.adTagUri) : (i.adTagUri = ""),
        e.clickThrough && (i.clickThrough = e.clickThrough),
        (i.tracking = i.tracking.concat(e.tracking)),
        (i.adSystem = e.adSystem || i.adSystem),
        (i.mediafiles = e.mediafiles),
        (i.adParameters = e.adParameters),
        (i.duration = e.duration),
        (i.tracking = i.tracking.map((n) =>
          n.offsetPercentage !== void 0
            ? { ...n, offset: et(`${n.offsetPercentage}%`, i.duration) }
            : n
        )),
        (i.creativeId = e.creativeId || i.creativeId),
        (i.adTitle = e.adTitle || i.adTitle),
        (i.extensions = i.extensions.concat(e.extensions)),
        (i.viewableImpressions = i.viewableImpressions.concat(
          e.viewableImpressions
        )),
        i.wrappers.push(_e(e)),
        (i.wrappers = i.wrappers.concat(e.wrappers.map((n) => _e(n)))),
        i
      );
    } catch (i) {
      const n = i instanceof Error ? i.message : `${i}`;
      throw new G({ code: 100, message: "merge throw an exception " + n });
    }
  }
  const kr = (t) => {
    const e = t && t.match(/^(\d+(?:\.\d+)?)%$/);
    return e ? parseFloat(e[1]) : void 0;
  };
  function et(t, e = 0) {
    if (!t) return null;
    const i = t.match(/^\d{2}:\d{2}:\d{2}(\.\d+)?$/),
      n = t.match(/^(\d+(?:\.\d+)?)%$/);
    if (i) {
      const s = t
        .split(":")
        .map((r, a) => parseInt(r, 10) * Math.pow(60, 2 - a))
        .reduce((r, a) => r + a);
      return Math.floor(s) || null;
    }
    return (n && Math.ceil((parseFloat(n[1]) * e) / 100)) || null;
  }
  function Rr(t) {
    const e = [],
      i = Array.from(t.getElementsByTagName("Verification"));
    for (const n of i) {
      const s = n.getAttribute("vendor");
      if (!s) continue;
      const r = Array.from(n.getElementsByTagName("JavaScriptResource")),
        a = [];
      for (const p of r) {
        const f = p.getAttribute("apiFramework"),
          m = p.getAttribute("browserOptional"),
          l = m ? JSON.parse(m) : void 0,
          b = C.getNodeContent(p);
        !b || !f || a.push({ browserOptional: l, apiFramework: f, url: b });
      }
      let d;
      const h = n.getElementsByTagName("VerificationParameters").item(0);
      n && (d = C.getNodeContent(h) || void 0);
      const c = [],
        v = Array.from(n.getElementsByTagName("Tracking"));
      for (const p of v) {
        const f = C.getNodeContent(p);
        if (!f) continue;
        const m = p.getAttribute("event") || "",
          l = Ai[m];
        l && c.push({ type: l, url: f });
      }
      e.push({
        vendor: s,
        events: c,
        javascriptResources: a,
        verificationParameters: d,
      });
    }
    return e;
  }
  const S = class J {
    constructor(e, i = {}) {
      if (
        ((this.type = e),
        (this.data = {}),
        typeof i == "object" && Array.isArray(i))
      )
        switch (e) {
          case J.AdLog:
          case J.AdError:
            (this.data.code = 901), (this.data.message = i[0]);
            break;
          case J.AdClickThru:
            this.data = { url: i[0], id: i[1], playerHandles: i[2] };
            break;
          case J.AdInteraction:
            this.data = { id: i[0] };
            break;
        }
      else if (typeof i == "object") this.data = i;
      else if (typeof i == "string")
        switch (e) {
          case J.AdLog:
          case J.AdError:
            (this.data.code = 901), (this.data.message = i);
            break;
          case J.AdInteraction:
            this.data = { id: i };
            break;
        }
    }
  };
  (S.AdLoaded = "AdLoaded"),
    (S.AdStarted = "AdStarted"),
    (S.AdStopped = "AdStopped"),
    (S.AdSkipped = "AdSkipped"),
    (S.AdLinearChange = "AdLinearChange"),
    (S.AdSizeChange = "AdSizeChange"),
    (S.AdExpandedChange = "AdExpandedChange"),
    (S.AdSkippableStateChange = "AdSkippableStateChange"),
    (S.AdRemainingTimeChange = "AdRemainingTimeChange"),
    (S.AdDurationChange = "AdDurationChange"),
    (S.AdVolumeChange = "AdVolumeChange"),
    (S.AdImpression = "AdImpression"),
    (S.AdVideoStart = "AdVideoStart"),
    (S.AdVideoFirstQuartile = "AdVideoFirstQuartile"),
    (S.AdVideoMidpoint = "AdVideoMidpoint"),
    (S.AdVideoThirdQuartile = "AdVideoThirdQuartile"),
    (S.AdVideoComplete = "AdVideoComplete"),
    (S.AdClickThru = "AdClickThru"),
    (S.AdInteraction = "AdInteraction"),
    (S.AdUserAcceptInvitation = "AdUserAcceptInvitation"),
    (S.AdUserMinimize = "AdUserMinimize"),
    (S.AdUserClose = "AdUserClose"),
    (S.AdPaused = "AdPaused"),
    (S.AdPlaying = "AdPlaying"),
    (S.AdLog = "AdLog"),
    (S.AdError = "AdError");
  let o = S;
  var j = ((t) => (
    (t.VPAIDJS = "vpaidjs"),
    (t.MP4 = "mp4"),
    (t.WEBM = "webm"),
    (t.MPEG = "mpeg"),
    (t.DASH = "mpd"),
    t
  ))(j || {});
  class Or {
    constructor() {
      this.res = [
        [/javascript/i, "vpaidjs"],
        [/video\/mp4/i, "mp4"],
        [/video\/webm/i, "webm"],
        [/video\/mpe?g/i, "mpeg"],
        [/application\/dash\+xml/, "mpd"],
      ];
    }
    match(e) {
      for (const [i, n] of this.res) if (e.match(i)) return n;
    }
  }
  class Dr {
    constructor(e = document) {
      this.video = e.createElement("video");
    }
    canPlay(e) {
      if (e === "application/javascript") return !0;
      const i = this.video.canPlayType(e);
      return i === "probably" || i === "maybe";
    }
  }
  class Mr {
    canPlay(e) {
      return !0;
    }
  }
  class Ii {
    constructor(e) {
      (this.allowedFormats = (e == null ? void 0 : e.allowedFormats) ?? [
        j.DASH,
        j.WEBM,
        j.MP4,
        j.MPEG,
        j.VPAIDJS,
      ]),
        (this.formatMatcher =
          (e == null ? void 0 : e.formatMatcher) ?? new Or()),
        (this.mediaPlayerSupport =
          (e == null ? void 0 : e.mediaPlayerSupport) ?? new Mr()),
        (this.formatsPriority = this.allowedFormats.reduce(
          (i, n, s) => ((i[n] = s), i),
          {}
        ));
    }
    resolve(e, { forWidth: i, forHeight: n, maxBitrate: s }) {
      const r = i / n;
      return e
        .filter((a) => {
          const d = this.formatMatcher.match(a.type);
          return (
            d &&
            d in this.formatsPriority &&
            (d === j.DASH || this.mediaPlayerSupport.canPlay(a.type))
          );
        })
        .sort((a, d) => {
          if (s !== void 0) {
            const f = (a.bitrate || 0) > s,
              m = (d.bitrate || 0) > s;
            if (f !== m) return f ? 1 : -1;
          }
          const { diffA: h, diffB: c } =
            r >= 1
              ? { diffA: Math.abs(a.width - i), diffB: Math.abs(d.width - i) }
              : {
                  diffA: Math.abs(a.height - n),
                  diffB: Math.abs(d.height - n),
                };
          if (h !== c) return h - c;
          const v = a.bitrate || 0,
            p = d.bitrate || 0;
          return v !== p
            ? p - v
            : this.formatsPriority[this.formatMatcher.match(a.type)] -
                this.formatsPriority[this.formatMatcher.match(d.type)];
        });
    }
    resolveOne(e, i) {
      let n, s;
      for (const r of e) {
        const a = this.formatMatcher.match(r.type);
        if (
          a &&
          a in this.formatsPriority &&
          this.mediaPlayerSupport.canPlay(r.type)
        ) {
          const d = {
              mediafile: r,
              format: a,
              priority: this.formatsPriority[a],
              widthDiff: r.width - i.forWidth,
            },
            h = d.format !== j.VPAIDJS && this.isBetterThan(d, n),
            c = d.format === j.VPAIDJS && this.isBetterThan(d, s);
          h && (n = d), c && (s = d);
        }
      }
      return (
        (n == null ? void 0 : n.mediafile) || (s == null ? void 0 : s.mediafile)
      );
    }
    isBetterThan(e, i) {
      return (
        i === void 0 ||
        (i.widthDiff < 0 && e.widthDiff >= 0) ||
        (i.widthDiff < 0 && e.widthDiff < 0 && e.widthDiff > i.widthDiff) ||
        (i.widthDiff >= 0 && e.widthDiff >= 0 && e.widthDiff < i.widthDiff) ||
        (e.widthDiff === i.widthDiff && e.priority < i.priority)
      );
    }
  }
  class ut {
    constructor() {
      (this.listeners = {}),
        (this.listenersScope = {}),
        (this.eventQueue = []),
        (this.isProcessing = !1);
    }
    subscribe(e, i, n) {
      (this.listeners[i] = this.listeners[i] || []),
        this.listeners[i].push(e),
        (this.listenersScope[i] = this.listenersScope[i] || []),
        this.listenersScope[i].push(n || null);
    }
    unsubscribe(e, i) {
      if (this.listeners[i]) {
        const n = this.listeners[i].indexOf(e);
        n >= 0 && (this.listeners[i][n] = function () {});
      }
    }
    clearListeners() {
      (this.listeners = {}), (this.listenersScope = {});
    }
    handleEvent(e) {
      this.eventQueue.push(e), this.processQueue();
    }
    processQueue() {
      if (!this.isProcessing && this.eventQueue.length > 0) {
        const e = this.eventQueue.shift();
        e && this.processEvent(e);
      }
    }
    processEvent(e) {
      if (this.isProcessing) return;
      this.isProcessing = !0;
      const i = this.listeners[e.type] || [];
      for (let n = 0, s = i.length; n < s; n++)
        try {
          let r = [];
          if (e.data)
            switch (e.type) {
              case o.AdClickThru:
                r = [e.data.url, e.data.id, !!e.data.playerHandles];
                break;
              case o.AdInteraction:
                r = [e.data.id];
                break;
              case o.AdLog:
              case o.AdError:
                r = [e.data.message];
                break;
            }
          i[n].apply(this.listenersScope[e.type][n], r);
        } catch (r) {
          this.handleEvent(
            new o(
              o.AdLog,
              "Callback #" +
                n +
                " on event " +
                e.type +
                " throws an exception: " +
                r
            )
          );
        }
      (this.isProcessing = !1), this.processQueue();
    }
  }
  const Nr = (t) => (window && window.atob(t)) || t,
    Lr = (t) => {
      var e = new RegExp(
          "^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$"
        ),
        i = e.exec(t);
      return !!(i && i.length > 0);
    };
  function Ti(t) {
    if (
      (typeof t == "object" &&
        t.AdParameters &&
        typeof t.AdParameters == "string" &&
        (t = t.AdParameters),
      t && typeof t == "string")
    ) {
      Lr(t)
        ? (t = Nr(t))
        : t.indexOf("%7B") === 0 && (t = decodeURIComponent(t));
      try {
        t = JSON.parse(t);
      } catch {
        throw "Unable to JSON.parse adParameter string: " + t;
      }
    }
    if (!t || typeof t != "object") throw "adParameter is not an object: " + t;
    return t;
  }
  const Vi = { NORMAL: "normal", FULLSCREEN: "fullscreen" };
  var E = ((t) => (
    (t[(t.REMOVED = -6)] = "REMOVED"),
    (t[(t.REMOVING = -5)] = "REMOVING"),
    (t[(t.ERROR = -4)] = "ERROR"),
    (t[(t.STOPPED = -3)] = "STOPPED"),
    (t[(t.STOPPING = -2)] = "STOPPING"),
    (t[(t.SKIPPED = -1)] = "SKIPPED"),
    (t[(t.SKIPPING = 0)] = "SKIPPING"),
    (t[(t.READY = 1)] = "READY"),
    (t[(t.LOADING = 2)] = "LOADING"),
    (t[(t.LOADED = 3)] = "LOADED"),
    (t[(t.STARTING = 5)] = "STARTING"),
    (t[(t.STARTED = 6)] = "STARTED"),
    (t[(t.PAUSING = 7)] = "PAUSING"),
    (t[(t.PAUSED = 8)] = "PAUSED"),
    (t[(t.RESUMING = 9)] = "RESUMING"),
    (t[(t.PLAYING = 10)] = "PLAYING"),
    (t[(t.COMPLETE = 11)] = "COMPLETE"),
    t
  ))(E || {});
  const zr = /paused to save power/,
    Br = (t) =>
      (t == null ? void 0 : t.name) === "AbortError" &&
      zr.test(String(t == null ? void 0 : t.message));
  function xi(t, e, i) {
    let n = !1,
      s = () => {};
    const r = () => {
      t.play()
        .then(() => {
          n || e();
        })
        .catch((a) => {
          if (n) return;
          const d = t.ownerDocument;
          if (!Br(a) || (d == null ? void 0 : d.visibilityState) !== "hidden") {
            i(a);
            return;
          }
          const h = () => {
            d.visibilityState === "visible" && (s(), r());
          };
          (s = () => {
            d.removeEventListener("visibilitychange", h), (s = () => {});
          }),
            d.addEventListener("visibilitychange", h);
        });
    };
    return (
      r(),
      () => {
        (n = !0), s();
      }
    );
  }
  class Ur {
    constructor() {
      (this.video = document.createElement("video")),
        (this.width = 0),
        (this.height = 9),
        (this.status = E.READY),
        (this.cancelPendingPlay = () => {}),
        (this.viewMode = Vi.NORMAL),
        (this.eventHandler = new ut()),
        (this.container = document.createElement("div")),
        (this.trackingRaised = {
          AdVideoFirstQuartile: !1,
          AdVideoMidpoint: !1,
          AdVideoThirdQuartile: !1,
        }),
        (this.parameters = {}),
        (this.expanded = !1),
        (this.config = {
          videoSources: [],
          clickUrl: "",
          keepVideoOnStop: !1,
          disableClick: !1,
        }),
        (this.eventMap = {
          durationchange: "AdDurationChange",
          resize: "AdSizeChange",
          volumechange: "AdVolumeChange",
          ended: "AdVideoComplete",
          play: "AdPlaying",
          playing: "AdPlaying",
          pause: "AdPaused",
          timeupdate: "AdRemainingTimeChange",
          error: "AdError",
        });
    }
    getVPAID() {
      return this;
    }
    getAdRemainingTime() {
      return this.video &&
        this.video.duration > 0 &&
        this.video.currentTime >= 0
        ? this.video.duration - this.video.currentTime
        : -1;
    }
    getAdDuration() {
      return this.video && this.video.duration > 0 ? this.video.duration : -1;
    }
    getAdVolume() {
      return this.video ? (this.video.muted ? 0 : this.video.volume) : 0;
    }
    setAdVolume(e) {
      return this.video
        ? ((this.video.muted = e === 0),
          (this.video.volume = e),
          this.video.muted ? 0 : this.video.volume)
        : 0;
    }
    expandAd() {
      return !1;
    }
    collapseAd() {
      return !1;
    }
    getAdLinear() {
      return !0;
    }
    getAdWidth() {
      return this.width;
    }
    getAdHeight() {
      return this.height;
    }
    getAdExpanded() {
      return !1;
    }
    getAdSkippableState() {
      return !0;
    }
    getAdCompanions() {
      return "";
    }
    getAdIcons() {
      return !1;
    }
    handshakeVersion(e) {
      return "2.0";
    }
    subscribe(e, i, n) {
      this.eventHandler.subscribe(e, i, n);
    }
    unsubscribe(e, i) {
      this.eventHandler.unsubscribe(e, i);
    }
    initAd(e, i, n, s, r, a) {
      var d;
      try {
        (this.status = E.LOADING),
          (this.width = e),
          (this.height = i),
          (this.viewMode = n);
        try {
          r = Ti(r);
        } catch (h) {
          console.error("VPAID error decoding adParameters : ", h, r),
            this.dispatchVpaidEvent(o.AdError, "invalid creative data : " + r);
          return;
        }
        this.parameters = this.config;
        for (let h in r) this.parameters[h] = r[h];
        if (!((d = this.parameters.videoSources) != null && d.length)) {
          this.dispatchVpaidEvent(
            o.AdError,
            "videoSources is missing in adParameters : " + JSON.stringify(r)
          );
          return;
        }
        if (
          ((this.environmentVars = a),
          this.environmentVars.videoSlot ||
            (this.environmentVars.videoSlot = document.createElement("video")),
          this.environmentVars.videoSlot.setAttribute &&
            (this.environmentVars.videoSlot.setAttribute(
              "webkit-playsinline",
              "true"
            ),
            this.environmentVars.videoSlot.setAttribute("playsinline", "true"),
            this.environmentVars.videoSlot.setAttribute("muted", "true")),
          !this.environmentVars.slot)
        ) {
          this.dispatchVpaidEvent(
            o.AdError,
            "no slot provided in environmentVars"
          );
          return;
        }
        if (
          ((this.video = this.environmentVars.videoSlot),
          this.initListeners(),
          this.createContainer(this.environmentVars.slot),
          this.video.addEventListener("error", (h) => {
            this.handleVideoError(h);
          }),
          this.isVideoElement(this.video))
        ) {
          if (
            ((this.video.style.backgroundColor = "black"),
            (this.video.preload = "metadata"),
            this.parameters.videoSources.length === 1 &&
              this.parameters.videoSources[0].url.endsWith(".mpd") &&
              dashjs !== void 0)
          )
            dashjs
              .MediaPlayer()
              .create()
              .initialize(this.video, this.parameters.videoSources[0].url, !0);
          else
            for (const { url: h, type: c } of this.parameters.videoSources) {
              const v = document.createElement("source");
              (v.src = h), (v.type = c), this.video.appendChild(v);
            }
          this.video.parentNode ||
            (this.dispatchVpaidEvent(
              o.AdLog,
              "Video slot got no parent node, appending to container"
            ),
            this.container.appendChild(this.video)),
            this.parameters.disableClick ||
              ((this.video.style.cursor = "pointer"),
              (this.video.onclick = (h) => {
                window.open(this.parameters.clickUrl),
                  h.preventDefault(),
                  this.dispatchVpaidEvent(o.AdClickThru, {
                    url: null,
                    id: null,
                    playerHandles: !1,
                  });
              }));
        } else {
          const h = new Ii().resolveOne(this.parameters.videoSources, {
            forWidth: this.width,
            forHeight: this.height,
          });
          if (h) this.video.src = h.url;
          else {
            this.dispatchVpaidEvent(
              o.AdError,
              "Unable to find Mediafile : " +
                JSON.stringify(this.parameters.videoSources)
            );
            return;
          }
        }
        this.setSize(this.width, this.height),
          this.video.load(),
          this.dispatchVpaidEvent(o.AdLoaded);
      } catch (h) {
        this.handleException(h, "initAd");
      }
    }
    startAd() {
      this.dispatchVpaidEvent(o.AdStarted),
        (this.cancelPendingPlay = xi(
          this.video,
          () => {
            this.dispatchVpaidEvent(o.AdImpression),
              this.dispatchVpaidEvent(o.AdVideoStart);
          },
          (e) => {
            (this.video.controls = !0), this.handleException(e, "startAd");
          }
        ));
    }
    skipAd() {
      if (this.status <= E.SKIPPING) {
        this.dispatchVpaidEvent(
          o.AdLog,
          "Ad is already stopped or is skipping"
        );
        return;
      }
      (this.status = E.SKIPPING),
        this.cancelPendingPlay(),
        this.video.pause(),
        (this.video.style.display = "none"),
        this.dispatchVpaidEvent(o.AdSkipped);
    }
    stopAd() {
      if (this.status <= E.STOPPING) {
        this.dispatchVpaidEvent(o.AdLog, "Ad is already stopped");
        return;
      }
      (this.status = E.STOPPING),
        this.cancelPendingPlay(),
        this.parameters.keepVideoOnStop ||
          (this.removeVideo(), this.dispatchVpaidEvent(o.AdStopped)),
        this.eventHandler.clearListeners();
    }
    resizeAd(e, i, n) {
      this.setSize(e, i), this.dispatchVpaidEvent(o.AdSizeChange);
    }
    pauseAd() {
      try {
        this.video.pause();
      } catch (e) {
        this.handleException(e, "pauseAd");
      }
    }
    resumeAd() {
      try {
        this.video.play();
      } catch (e) {
        this.handleException(e, "resumeAd");
      }
    }
    createContainer(e) {
      this.container ||
        ((this.container = document.createElement("div")),
        (this.container.style.position = "relative"),
        e.appendChild(this.container));
    }
    onAdVideoCompleteDispatched() {
      this.parameters.noAutoStop
        ? (this.video.addEventListener(
            "seeked",
            () => {
              this.video.pause();
            },
            !1
          ),
          (this.video.currentTime = 1))
        : this.stopAd();
    }
    dispatchVpaidEvent(e, i) {
      this.handleVPAIDEvent(new o(e, i));
    }
    handleVPAIDEvent(e) {
      if (
        !(
          (this.status === E.SKIPPING && e.type !== o.AdSkipped) ||
          (this.status === E.STOPPING && e.type !== o.AdStopped) ||
          this.status <= E.STOPPED
        ) &&
        !(this.status === E.STOPPING && e.type !== o.AdStopped)
      ) {
        switch (e.type) {
          case o.AdLoaded:
            this.status = E.LOADED;
            break;
          case o.AdStarted:
            this.status = E.STARTED;
            break;
          case o.AdVideoStart:
          case o.AdPlaying:
            this.status = E.PLAYING;
            break;
          case o.AdPaused:
            this.status = E.PAUSED;
            break;
          case o.AdSkipped:
            this.status = E.SKIPPED;
            break;
          case o.AdStopped:
            this.status = E.STOPPED;
            break;
          case o.AdDurationChange:
          case o.AdRemainingTimeChange:
            const i = this.getAdDuration(),
              n = i - this.getAdRemainingTime();
            i > 0 && n >= i * 0.25 && !this.trackingRaised.AdVideoFirstQuartile
              ? this.dispatchVpaidEvent(o.AdVideoFirstQuartile)
              : i > 0 && n >= i * 0.5 && !this.trackingRaised.AdVideoMidpoint
              ? this.dispatchVpaidEvent(o.AdVideoMidpoint)
              : i > 0 &&
                n >= i * 0.75 &&
                !this.trackingRaised.AdVideoThirdQuartile &&
                this.dispatchVpaidEvent(o.AdVideoThirdQuartile);
            break;
          case o.AdVideoFirstQuartile:
          case o.AdVideoMidpoint:
          case o.AdVideoThirdQuartile:
            if (this.trackingRaised[e.type]) return;
            this.trackingRaised[e.type] = !0;
            break;
          case o.AdVideoComplete:
            this.status = E.COMPLETE;
            break;
        }
        this.eventHandler.handleEvent(e),
          this.status === E.SKIPPED && this.stopAd(),
          e.type === o.AdVideoComplete && this.onAdVideoCompleteDispatched();
      }
    }
    handleException(e, i) {
      const n = 'method "' + i + '" threw an exception: ' + e.toString();
      this.dispatchVpaidEvent(o.AdError, n);
    }
    removeVideo() {
      try {
        this.video &&
          this.video.parentNode &&
          this.video.parentNode.removeChild(this.video);
      } catch {
        this.dispatchVpaidEvent(o.AdLog, "cannot remove video from DOM");
      }
    }
    setSize(e, i) {
      (this.width = e),
        (this.height = i),
        this.video &&
          ((this.video.width = this.width), (this.video.height = this.height)),
        (this.container.style.width = e + "px"),
        (this.container.style.height = i + "px");
    }
    initListeners() {
      for (var e in this.eventMap)
        this.video.addEventListener(
          e,
          (i) => {
            this.handleVideoEvent(i);
          },
          !1
        );
    }
    handleVideoError(e) {
      if (e.type === "error") {
        let i = this.video ? this.video.error : null;
        if (i)
          switch (i.code) {
            case 1:
              break;
            case 2:
              this.dispatchVpaidEvent(
                o.AdError,
                "video error : A network error caused the ressource to stop being fetched"
              );
              break;
            case 3:
              this.dispatchVpaidEvent(
                o.AdError,
                "video error : A decoding error caused the ressource to stop being fetched"
              );
              break;
            case 4:
              this.dispatchVpaidEvent(
                o.AdError,
                "video error : The associated ressource has been detected to be not suitable"
              );
              break;
          }
        else this.dispatchVpaidEvent(o.AdError, "video error : unkown error");
      }
    }
    handleVideoEvent(e) {
      try {
        const i = this.eventMap[e.type];
        switch (e.type) {
          case "pause":
            if (
              this.video.currentTime === this.video.duration ||
              this.status <= E.SKIPPING ||
              this.status === E.COMPLETE
            )
              return;
            break;
          case "play":
          case "playing":
            if (this.status !== E.PAUSED) return;
            break;
        }
        this.dispatchVpaidEvent(i);
      } catch (i) {
        const n =
          'Creative threw an exception when handling "' +
          e.type +
          '" HTML5 video event: ' +
          (i instanceof Error ? i.message : `${i}`);
        this.dispatchVpaidEvent(o.AdLog, n),
          this.dispatchVpaidEvent(o.AdError, n);
      }
    }
    isVideoElement(e) {
      return e instanceof HTMLVideoElement;
    }
  }
  class Hr {
    constructor() {
      (this.video = document.createElement("video")),
        (this.width = 0),
        (this.height = 9),
        (this.status = E.READY),
        (this.cancelPendingPlay = () => {}),
        (this.viewMode = Vi.NORMAL),
        (this.eventHandler = new ut()),
        (this.container = document.createElement("div")),
        (this.trackingRaised = {
          AdVideoFirstQuartile: !1,
          AdVideoMidpoint: !1,
          AdVideoThirdQuartile: !1,
        }),
        (this.parameters = {}),
        (this.expanded = !1),
        (this.config = {
          videoSources: [],
          clickUrl: "",
          keepVideoOnStop: !1,
          disableClick: !1,
        }),
        (this.eventMap = {
          durationchange: "AdDurationChange",
          resize: "AdSizeChange",
          volumechange: "AdVolumeChange",
          ended: "AdVideoComplete",
          play: "AdPlaying",
          playing: "AdPlaying",
          pause: "AdPaused",
          timeupdate: "AdRemainingTimeChange",
          error: "AdError",
        });
    }
    getVPAID() {
      return this;
    }
    getAdRemainingTime() {
      return this.video &&
        this.video.duration > 0 &&
        this.video.currentTime >= 0
        ? this.video.duration - this.video.currentTime
        : -1;
    }
    getAdDuration() {
      return this.video && this.video.duration > 0 ? this.video.duration : -1;
    }
    getAdVolume() {
      return this.video ? (this.video.muted ? 0 : this.video.volume) : 0;
    }
    setAdVolume(e) {
      return this.video && !this.videoSlot
        ? ((this.video.muted = e === 0),
          (this.video.volume = e),
          this.video.muted ? 0 : this.video.volume)
        : 0;
    }
    expandAd() {
      return !1;
    }
    collapseAd() {
      return !1;
    }
    getAdLinear() {
      return !0;
    }
    getAdWidth() {
      return this.width;
    }
    getAdHeight() {
      return this.height;
    }
    getAdExpanded() {
      return !1;
    }
    getAdSkippableState() {
      return !0;
    }
    getAdCompanions() {
      return "";
    }
    getAdIcons() {
      return !1;
    }
    handshakeVersion(e) {
      return "2.0";
    }
    subscribe(e, i, n) {
      this.eventHandler.subscribe(e, i, n);
    }
    unsubscribe(e, i) {
      this.eventHandler.unsubscribe(e, i);
    }
    initAd(e, i, n, s, r, a) {
      var d;
      (this.status = E.LOADING),
        (this.width = e),
        (this.height = i),
        (this.viewMode = n);
      try {
        r = Ti(r);
      } catch {
        this.dispatchVpaidEvent(o.AdError, "invalid creative data : " + r);
        return;
      }
      this.parameters = this.config;
      for (let h in r) this.parameters[h] = r[h];
      if (!((d = this.parameters.videoSources) != null && d.length)) {
        this.dispatchVpaidEvent(
          o.AdError,
          "videoSources is missing in adParameters : " + JSON.stringify(r)
        );
        return;
      }
      if (
        ((this.environmentVars = a),
        this.video.setAttribute("webkit-playsinline", "true"),
        this.video.setAttribute("playsinline", "true"),
        this.video.setAttribute("muted", "true"),
        this.container.appendChild(this.video),
        !this.environmentVars.slot)
      ) {
        this.dispatchVpaidEvent(
          o.AdError,
          "no slot provided in environmentVars"
        );
        return;
      }
      if (
        ((this.videoSlot = this.environmentVars.videoSlot),
        (this.video.style.backgroundColor = "black"),
        this.initListeners(),
        this.video.addEventListener("error", (h) => {
          this.handleVideoError(h);
        }),
        (this.video.preload = "metadata"),
        this.parameters.videoSources.length === 1 &&
          this.parameters.videoSources[0].url.endsWith(".mpd") &&
          dashjs !== void 0)
      )
        dashjs
          .MediaPlayer()
          .create()
          .initialize(this.video, this.parameters.videoSources[0].url, !0);
      else {
        try {
          for (const { url: h, type: c } of this.parameters.videoSources) {
            const v = document.createElement("source");
            (v.src = h), (v.type = c), this.video.appendChild(v);
          }
        } catch {
          this.video.src = this.parameters.videoSources[0].url;
        }
        this.videoSlot &&
          (this.videoSlot.src = this.parameters.videoSources[0].url);
      }
      this.parameters.disableClick ||
        ((this.video.style.cursor = "pointer"),
        (this.video.onclick = (h) => {
          window.open(this.parameters.clickUrl),
            h.preventDefault(),
            this.dispatchVpaidEvent(o.AdClickThru, {
              url: null,
              id: null,
              playerHandles: !1,
            });
        })),
        this.setSize(this.width, this.height),
        this.video.load(),
        this.dispatchVpaidEvent(o.AdLoaded);
    }
    startAd() {
      var e, i;
      this.dispatchVpaidEvent(o.AdStarted),
        this.videoSlot && (this.video.muted = !0),
        (this.cancelPendingPlay = xi(
          this.video,
          () => {
            this.dispatchVpaidEvent(o.AdImpression),
              this.dispatchVpaidEvent(o.AdVideoStart);
          },
          (n) => {
            (this.video.controls = !0), this.handleException(n, "startAd");
          }
        )),
        (e = this.environmentVars) == null ||
          e.slot.appendChild(this.container);
      try {
        (i = this.videoSlot) == null || i.play().catch((n) => {});
      } catch {}
    }
    skipAd() {
      if (this.status <= E.SKIPPING) {
        this.dispatchVpaidEvent(
          o.AdLog,
          "Ad is already stopped or is skipping"
        );
        return;
      }
      (this.status = E.SKIPPING),
        this.cancelPendingPlay(),
        this.video.pause(),
        (this.video.style.display = "none"),
        this.dispatchVpaidEvent(o.AdSkipped);
    }
    stopAd() {
      if (this.status <= E.STOPPING) {
        this.dispatchVpaidEvent(o.AdLog, "Ad is already stopped");
        return;
      }
      (this.status = E.STOPPING),
        this.cancelPendingPlay(),
        this.parameters.keepVideoOnStop ||
          (this.removeVideo(), this.dispatchVpaidEvent(o.AdStopped)),
        this.eventHandler.clearListeners();
    }
    resizeAd(e, i, n) {
      this.setSize(e, i), this.dispatchVpaidEvent(o.AdSizeChange);
    }
    pauseAd() {
      var e;
      try {
        this.video.pause(), (e = this.videoSlot) == null || e.pause();
      } catch (i) {
        this.handleException(i, "pauseAd");
      }
    }
    resumeAd() {
      var e;
      try {
        this.video.play(), (e = this.videoSlot) == null || e.play();
      } catch (i) {
        this.handleException(i, "resumeAd");
      }
    }
    onAdVideoCompleteDispatched() {
      this.parameters.noAutoStop
        ? (this.video.addEventListener(
            "seeked",
            () => {
              this.video.pause();
            },
            !1
          ),
          (this.video.currentTime = 1))
        : this.stopAd();
    }
    dispatchVpaidEvent(e, i) {
      this.handleVPAIDEvent(new o(e, i));
    }
    handleVPAIDEvent(e) {
      if (
        !(
          (this.status === E.SKIPPING && e.type !== o.AdSkipped) ||
          (this.status === E.STOPPING && e.type !== o.AdStopped) ||
          this.status <= E.STOPPED
        ) &&
        !(this.status === E.STOPPING && e.type !== o.AdStopped)
      ) {
        switch (e.type) {
          case o.AdLoaded:
            this.status = E.LOADED;
            break;
          case o.AdStarted:
            this.status = E.STARTED;
            break;
          case o.AdVideoStart:
          case o.AdPlaying:
            this.status = E.PLAYING;
            break;
          case o.AdPaused:
            this.status = E.PAUSED;
            break;
          case o.AdSkipped:
            this.status = E.SKIPPED;
            break;
          case o.AdStopped:
            this.status = E.STOPPED;
            break;
          case o.AdDurationChange:
          case o.AdRemainingTimeChange:
            const i = this.getAdDuration(),
              n = i - this.getAdRemainingTime();
            i > 0 && n >= i * 0.25 && !this.trackingRaised.AdVideoFirstQuartile
              ? this.dispatchVpaidEvent(o.AdVideoFirstQuartile)
              : i > 0 && n >= i * 0.5 && !this.trackingRaised.AdVideoMidpoint
              ? this.dispatchVpaidEvent(o.AdVideoMidpoint)
              : i > 0 &&
                n >= i * 0.75 &&
                !this.trackingRaised.AdVideoThirdQuartile &&
                this.dispatchVpaidEvent(o.AdVideoThirdQuartile);
            break;
          case o.AdVideoFirstQuartile:
          case o.AdVideoMidpoint:
          case o.AdVideoThirdQuartile:
            if (this.trackingRaised[e.type]) return;
            this.trackingRaised[e.type] = !0;
            break;
          case o.AdVideoComplete:
            this.status = E.COMPLETE;
            break;
        }
        this.eventHandler.handleEvent(e),
          this.status === E.SKIPPED && this.stopAd(),
          e.type === o.AdVideoComplete && this.onAdVideoCompleteDispatched();
      }
    }
    handleException(e, i) {
      const n = 'method "' + i + '" threw an exception: ' + e.toString();
      this.dispatchVpaidEvent(o.AdError, n);
    }
    removeVideo() {
      try {
        this.video &&
          this.video.parentNode &&
          this.video.parentNode.removeChild(this.video);
      } catch {
        this.dispatchVpaidEvent(o.AdLog, "cannot remove video from DOM");
      }
    }
    setSize(e, i) {
      (this.width = e),
        (this.height = i),
        this.video &&
          ((this.video.width = this.width), (this.video.height = this.height)),
        (this.container.style.width = e + "px"),
        (this.container.style.height = i + "px");
    }
    initListeners() {
      for (var e in this.eventMap)
        this.video.addEventListener(
          e,
          (i) => {
            this.handleVideoEvent(i);
          },
          !1
        );
    }
    handleVideoError(e) {
      if (e.type === "error") {
        let i = this.video ? this.video.error : null;
        if (i)
          switch (i.code) {
            case 1:
              break;
            case 2:
              this.dispatchVpaidEvent(
                o.AdError,
                "video error : A network error caused the ressource to stop being fetched"
              );
              break;
            case 3:
              this.dispatchVpaidEvent(
                o.AdError,
                "video error : A decoding error caused the ressource to stop being fetched"
              );
              break;
            case 4:
              this.dispatchVpaidEvent(
                o.AdError,
                "video error : The associated ressource has been detected to be not suitable"
              );
              break;
          }
        else this.dispatchVpaidEvent(o.AdError, "video error : unkown error");
      }
    }
    handleVideoEvent(e) {
      try {
        const i = this.eventMap[e.type];
        switch (e.type) {
          case "pause":
            if (
              this.video.currentTime === this.video.duration ||
              this.status <= E.SKIPPING ||
              this.status === E.COMPLETE
            )
              return;
            break;
          case "play":
          case "playing":
            if (this.status !== E.PAUSED) return;
            break;
        }
        this.dispatchVpaidEvent(i);
      } catch (i) {
        const n =
          'Creative threw an exception when handling "' +
          e.type +
          '" HTML5 video event: ' +
          (i instanceof Error ? i.message : `${i}`);
        this.dispatchVpaidEvent(o.AdLog, n),
          this.dispatchVpaidEvent(o.AdError, n);
      }
    }
  }
  class _r {
    constructor() {
      this.eventHandler = new ut();
    }
    getVPAID() {
      return this.vpaidAd;
    }
    getAdRemainingTime() {
      return this.vpaidAd ? this.vpaidAd.getAdRemainingTime() : -2;
    }
    getAdDuration() {
      return this.vpaidAd ? this.vpaidAd.getAdDuration() : 0;
    }
    getAdVolume() {
      return this.vpaidAd ? this.vpaidAd.getAdVolume() : 0;
    }
    setAdVolume(e) {
      return this.vpaidAd && this.vpaidAd.setAdVolume(e), e;
    }
    expandAd() {
      return !1;
    }
    collapseAd() {
      return !1;
    }
    getAdLinear() {
      return !0;
    }
    getAdWidth() {
      return this.vpaidAd ? this.vpaidAd.getAdWidth() : 0;
    }
    getAdHeight() {
      return this.vpaidAd ? this.vpaidAd.getAdHeight() : 0;
    }
    getAdExpanded() {
      return !1;
    }
    getAdSkippableState() {
      return !0;
    }
    getAdCompanions() {
      return "";
    }
    getAdIcons() {
      return !1;
    }
    handshakeVersion(e) {
      return "2.0";
    }
    initAd(e, i, n, s, r, a) {
      this.vpaidAd && this.vpaidAd.initAd(e, i, n, s, r, a);
    }
    startAd() {
      this.vpaidAd && this.vpaidAd.startAd();
    }
    stopAd() {
      this.vpaidAd && this.vpaidAd.stopAd();
    }
    skipAd() {
      this.vpaidAd && this.vpaidAd.skipAd();
    }
    pauseAd() {
      this.vpaidAd && this.vpaidAd.pauseAd();
    }
    resumeAd() {
      this.vpaidAd && this.vpaidAd.resumeAd();
    }
    resizeAd(e, i, n) {
      this.vpaidAd && this.vpaidAd.resizeAd(e, i, n);
    }
    subscribe(e, i, n) {
      this.eventHandler.subscribe(e, i, n);
    }
    unsubscribe(e, i) {
      this.eventHandler.unsubscribe(e, i);
    }
    triggerEvent(e, i = {}) {
      this.eventHandler.handleEvent(new o(e, i));
    }
    setVPAID(e) {
      Object.keys(o).map((i) => {
        const n = o[i];
        e.subscribe((...s) => {
          this.triggerEvent(n, s);
        }, n);
      }),
        (this.vpaidAd = e);
    }
  }
  let Fr = class {
    constructor(t, e, i) {
      (this.vastAd = t), (this.vpaidAd = e), (this.mediafile = i);
    }
    getAdId() {
      return this.vastAd.adId || "";
    }
    getAdSystem() {
      return this.vastAd.adSystem || "";
    }
    getAdvertiserName() {
      return "";
    }
    getApiFramework() {
      return (this.mediafile && this.mediafile.apiFramework) || "";
    }
    getCompanionAds() {
      return [];
    }
    getContentType() {
      return (this.mediafile && this.mediafile.type) || "";
    }
    getCreativeAdId() {
      return this.vastAd.creativeId || "";
    }
    getCreativeId() {
      return this.vastAd.creativeId || "";
    }
    getDescription() {
      return "";
    }
    getDuration() {
      const t = this.vpaidAd.getAdDuration();
      return t > 0 ? t : this.vastAd.duration;
    }
    getHeight() {
      return this.vpaidAd.getAdHeight();
    }
    getMediaUrl() {
      return (this.mediafile && this.mediafile.url) || "";
    }
    getSkipTimeOffset() {
      return 0;
    }
    getTitle() {
      return this.vastAd.adTitle || "";
    }
    getVastMediaHeight() {
      return (this.mediafile && this.mediafile.height) || 0;
    }
    getVastMediaWidth() {
      return (this.mediafile && this.mediafile.width) || 0;
    }
    getWidth() {
      return this.vpaidAd.getAdWidth();
    }
    getWrapperAdIds() {
      return this.vastAd.wrappers.map((t) => t.adId || "");
    }
    getWrapperAdSystems() {
      return this.vastAd.wrappers.map((t) => t.adSystem || "");
    }
    getWrapperCreativeIds() {
      return this.vastAd.wrappers.map((t) => t.creativeId || "");
    }
    isLinear() {
      return !0;
    }
  };
  const Gr = Math.round(Math.random() * 1e11);
  function Xr(t = {}, e = "seedtag_creative") {
    const i = document.createElement("iframe");
    return (
      (i.id = e),
      (i.name = e),
      (i.title = `${e}-${Gr}`),
      (i.style.position = "static"),
      (i.style.margin = "0px"),
      (i.style.padding = "0px"),
      (i.style.width = "100%"),
      (i.style.height = "100%"),
      (i.style.border = "0px"),
      (i.style.overflow = "hidden"),
      i.style.setProperty("min-height", "initial", "important"),
      i.style.setProperty("min-width", "initial", "important"),
      i.setAttribute("scrolling", "no"),
      i.setAttribute("loading", "eager"),
      (i.frameBorder = "0"),
      (i.style.maxWidth = "unset"),
      Object.keys(t).forEach((n) => {
        i.style[n] = t[n];
      }),
      i
    );
  }
  const Wr = (t, e, i = {}) =>
      new Promise((n, s) => {
        const r = document.createElement("div");
        (r.style.position = "relative"),
          (r.style.width = "100%"),
          (r.style.height = "100%"),
          e.appendChild(r);
        const a = Date.now() + Math.round(Math.random() * 1e3),
          d = Xr();
        (d.id = "vpaid-" + a),
          (d.style.width = "100%"),
          (d.style.height = "100%"),
          r.appendChild(d);
        const h = e.ownerDocument.defaultView,
          c = d.contentWindow,
          v = "vpaidjsload_" + a,
          p = "ad-container",
          f = (b) => {
            (h[v] = function () {}), s(b);
          };
        h[v] = (b, M) => {
          if (((h[v] = function () {}), b))
            try {
              const X = c.getVPAIDAd(),
                W = c.document.getElementById(p);
              n({ vpaidAd: X, container: W });
            } catch (X) {
              const W = X;
              f("getVPAIDAd() throw an exception " + (W && W.message));
              return;
            }
          else f("callback failled : " + M);
        };
        const m =
          `<!DOCTYPE html><html><head><style>html, body, #${p} { width: 100%; height: 100%; position: absolute; }</style></head><body style="margin:0px;padding:0px;overflow:hidden"><script async>var target = window.parent;var script = document.createElement("script");script.onload = function() { target["` +
          v +
          '"](true);};script.onerror = function(err) { target["' +
          v +
          '"](false, (err && err.message));};script.src="' +
          t +
          '";script.async=true;document.body.appendChild(script);</script><div id="' +
          p +
          '"></div></body></html>';
        c.document.write(m), c.document.close();
        const l = i.timeout || 5e3;
        setTimeout(() => {
          f(`VPAID ad did not load in ${l}ms`);
        }, l);
      }),
    jr = "1.0.0",
    Qr = (t, e) =>
      new Promise((i) => {
        var n;
        const s = e.ownerDocument,
          r = s.createElement("script");
        (r.onload = () => {
          var a;
          const d = s.createElement("script");
          (d.onload = i),
            (d.onerror = i),
            (d.src = t.sessionClient),
            (a = e.parentNode) == null || a.appendChild(d);
        }),
          (r.onerror = i),
          (r.src = t.sdk),
          (n = e.parentNode) == null || n.appendChild(r);
      }),
    $r = (t, e, i, n, s, r) => {
      const a = e.ownerDocument.defaultView,
        d = i.filter(
          (h) => !!h.javascriptResources.find((c) => c.apiFramework === "omid")
        );
      return !t || i.length === 0 || d.length === 0 || !a
        ? Promise.resolve()
        : Qr(t, e).then(() => {
            const h = a.OmidSessionClient && a.OmidSessionClient.default;
            if (h) {
              const c = d.reduce((m, l) => {
                  const b = l.javascriptResources.find(
                    (M) => M.apiFramework === "omid"
                  );
                  if (b) {
                    const M = new h.VerificationScriptResource(
                      b.url,
                      l.vendor,
                      l.verificationParameters,
                      "full"
                    );
                    m.push(M);
                  }
                  return m;
                }, []),
                v = new h.Partner(t.partnerName, jr),
                p = new h.Context(v, c, r);
              p.setServiceWindow(a), p.setVideoElement(n);
              const f = new h.AdSession(p);
              if (
                (f.setCreativeType("video"),
                f.setImpressionType("beginToRender"),
                f.isSupported())
              ) {
                const m = new h.AdEvents(f),
                  l = new h.MediaEvents(f);
                f.start(),
                  Object.keys(o).forEach((b) => {
                    s.subscribe(() => {
                      switch (b) {
                        case o.AdLoaded:
                          m.loaded(new h.VastProperties(!0, 0, !0, "preroll"));
                          break;
                        case o.AdImpression:
                          m.impressionOccurred();
                          break;
                        case o.AdVideoComplete:
                          l.complete();
                          break;
                        case o.AdVideoFirstQuartile:
                          l.firstQuartile();
                          break;
                        case o.AdPaused:
                          l.pause();
                          break;
                        case o.AdVideoMidpoint:
                          l.midpoint();
                          break;
                        case o.AdStarted:
                          l.start(s.getAdDuration(), s.getAdVolume());
                          break;
                        case o.AdPlaying:
                          l.resume();
                          break;
                        case o.AdSkipped:
                          l.skipped();
                          break;
                        case o.AdVideoThirdQuartile:
                          l.thirdQuartile();
                          break;
                        case o.AdVolumeChange:
                          l.volumeChange(s.getAdVolume());
                          break;
                        case o.AdStopped:
                          f.finish();
                          break;
                      }
                    }, b);
                  });
              }
            }
          });
    },
    Yr = {
      [o.AdError]: "error",
      [o.AdClickThru]: "click",
      [o.AdPaused]: "pause",
      [o.AdPlaying]: "resume",
      [o.AdSkipped]: "skip",
      [o.AdStarted]: "creativeView",
      [o.AdVideoStart]: "start",
      [o.AdVideoFirstQuartile]: "firstQuartile",
      [o.AdVideoMidpoint]: "midpoint",
      [o.AdVideoThirdQuartile]: "thirdQuartile",
      [o.AdVideoComplete]: "complete",
      [o.AdImpression]: "impression",
      [o.AdUserClose]: "close",
      [o.AdRemainingTimeChange]: "progress",
      [o.AdLoaded]: "loaded",
    },
    qr = [
      o.AdError,
      o.AdSkipped,
      o.AdStarted,
      o.AdVideoStart,
      o.AdVideoFirstQuartile,
      o.AdVideoMidpoint,
      o.AdVideoThirdQuartile,
      o.AdVideoComplete,
      o.AdImpression,
      o.AdUserClose,
      o.AdClickThru,
    ],
    Lt = {
      [I.ALL_ADS_COMPLETED]: o.AdStopped,
      [I.COMPLETE]: o.AdVideoComplete,
      [I.DURATION_CHANGE]: o.AdDurationChange,
      [I.FIRST_QUARTILE]: o.AdVideoFirstQuartile,
      [I.IMPRESSION]: o.AdImpression,
      [I.INTERACTION]: o.AdInteraction,
      [I.LINEAR_CHANGED]: o.AdLinearChange,
      [I.LOADED]: o.AdLoaded,
      [I.LOG]: o.AdLog,
      [I.MIDPOINT]: o.AdVideoMidpoint,
      [I.PAUSED]: o.AdPaused,
      [I.RESUMED]: o.AdPlaying,
      [I.SKIPPABLE_STATE_CHANGED]: o.AdSkippableStateChange,
      [I.SKIPPED]: o.AdSkipped,
      [I.STARTED]: o.AdStarted,
      [I.THIRD_QUARTILE]: o.AdVideoThirdQuartile,
      [I.USER_CLOSE]: o.AdUserClose,
      [I.VOLUME_CHANGED]: o.AdVolumeChange,
      [I.AD_ERROR]: o.AdError,
      [I.CLICK]: o.AdClickThru,
      [I.AD_PROGRESS]: o.AdRemainingTimeChange,
    },
    Kr = Object.keys(Lt)
      .map((t) => ({ adEventName: t, vpaidEventName: Lt[t] }))
      .reduce((t, e) => ((t[e.vpaidEventName] = e.adEventName), t), {}),
    Jr = [
      "skip",
      "creativeView",
      "start",
      "impression",
      "firstQuartile",
      "midpoint",
      "thirdQuartile",
      "complete",
      "error",
      "progress",
    ];
  class Fe {
    constructor(e, i, n = {}) {
      (this.mediafiles = []),
        (this.vpaidAd = new _r()),
        (this.listeners = new Map()),
        (this.tracking = []),
        (this.vpaidEventQueue = []),
        (this.isProcessingVpaidEvent = !1),
        (this.viewableImpressions = []),
        (this.isMuted = !0),
        (this.isStopped = !1),
        (this.settings = { timeout: 8e3 }),
        (this.triggeredEvents = []),
        (this.vastAd = e),
        (this.viewableImpressions = this.vastAd.viewableImpressions.map(
          (s) => ({ ...s, tracked: !1 })
        )),
        (this.container = i),
        (this.settings = { ...this.settings, ...n }),
        (this.resolver = new Ii({ mediaPlayerSupport: new Dr() })),
        Object.keys(o).forEach((s) => {
          this.vpaidAd.subscribe((...r) => {
            this.handleVpaidEvent(new o(s, r));
          }, s);
        }),
        (this.tracking = Array.from(this.vastAd.tracking)),
        (this.vpaidContainer = i.ownerDocument.createElement("div")),
        (this.vpaidContainer.style.position = "relative"),
        this.container.appendChild(this.vpaidContainer),
        (this.videoContent =
          this.container.ownerDocument.createElement("video")),
        (this.videoContent.muted = !0),
        this.videoContent.setAttribute("muted", "true"),
        this.videoContent.setAttribute("playsinline", "true"),
        this.videoContent.setAttribute("WebkitPlaysinline", "true"),
        this.videoContent.setAttribute("preload", "metadata"),
        (this.videoContent.style.display = "block"),
        (this.videoContent.style.background =
          n.backgroundColor || "transparent"),
        (this.videoContent.style.position = "absolute"),
        (this.videoContent.style.top = "0"),
        (this.videoContent.style.left = "0"),
        (this.videoContent.style.zIndex = "0");
    }
    init(e, i, n, s) {
      const r = this.container.getBoundingClientRect();
      if (
        ((this.mediafiles = this.resolver.resolve(this.vastAd.mediafiles, {
          forWidth: e || r.width || window.innerWidth,
          forHeight: i || r.height || window.innerHeight,
          maxBitrate: this.settings.maxBitrate,
        })),
        !this.mediafiles || !this.mediafiles.length)
      ) {
        this.handleVpaidEvent(
          new o(o.AdError, {
            code: 1007,
            message:
              "VAST_ASSET_NOT_FOUND: No assets were found in the VAST ad response. IMA Error code 1007",
          })
        );
        return;
      }
      const a = this.mediafiles[0];
      $r(
        this.settings.omsdk,
        this.container,
        this.vastAd.verifications || [],
        this.videoContent,
        this.vpaidAd,
        a.url
      ).then(() => {
        const d = a.type.indexOf("javascript") > -1;
        this.resizeVpaidContainer(e, i),
          s ||
            (this.vpaidContainer.appendChild(this.videoContent),
            d ||
              (this.videoContent.style.background =
                this.settings.backgroundColor || "black"));
        const h = (c, v, p) => {
          var f;
          this.vpaidAd.setVPAID(c);
          const m = p.ownerDocument.defaultView || window,
            l = m.setTimeout(() => {
              this.handleVpaidEvent(
                new o(o.AdError, {
                  code: 402,
                  message: "timeout initAd after " + this.settings.timeout,
                })
              );
            }, this.settings.timeout);
          this.vpaidAd.subscribe(() => {
            m.clearTimeout(l);
          }, o.AdLoaded);
          try {
            this.vpaidAd.initAd(
              e,
              i,
              n,
              (((f = this.mediafiles) == null ? void 0 : f.length) &&
                this.mediafiles[0].bitrate) ||
                512,
              v,
              {
                slot: p,
                videoSlot: s || this.videoContent,
                videoSlotCanAutoPlay: !0,
              }
            );
          } catch (b) {
            this.handleVpaidEvent(
              new o(o.AdError, { code: 901, message: `error on initAd ${b}` })
            );
          }
        };
        if (d)
          Wr(a.url, this.vpaidContainer, { timeout: this.settings.timeout })
            .then((c) => {
              this.dispatchAdsManagerEvent(I.IFRAME_READY);
              const { vpaidAd: v, container: p } = c;
              h(v, { AdParameters: this.vastAd.adParameters }, p);
            })
            .catch((c) => {
              this.handleVpaidEvent(
                new o(o.AdError, {
                  code: 400,
                  message: "Unable to load VPAID file : " + c,
                })
              );
            });
        else {
          const c = this.settings.useVideoSlot ? Hr : Ur;
          h(
            new c(),
            {
              videoSources: this.mediafiles,
              clickUrl: this.vastAd.clickThrough,
              keepVideoOnStop: this.settings.keepVideoOnStop,
              disableClick: this.settings.disableClick,
            },
            this.vpaidContainer
          );
        }
      });
    }
    destroy() {
      try {
        this.stop(),
          this.vpaidContainer.parentNode.removeChild(this.vpaidContainer),
          this.videoContent.parentNode.removeChild(this.videoContent);
      } catch {}
    }
    getAdSkippableState() {
      return this.vpaidAd.getAdSkippableState();
    }
    getRemainingTime() {
      return this.vpaidAd.getAdRemainingTime();
    }
    getVolume() {
      return this.vpaidAd.getAdVolume();
    }
    pause() {
      this.vpaidAd.pauseAd();
    }
    resize(e, i, n) {
      this.resizeVpaidContainer(e, i), this.vpaidAd.resizeAd(e, i, n);
    }
    resume() {
      this.vpaidAd.resumeAd();
    }
    setVolume(e) {
      e === 0
        ? this.videoContent.setAttribute("muted", "true")
        : this.videoContent.removeAttribute("muted"),
        (this.videoContent.volume = e),
        this.vpaidAd.setAdVolume(e);
    }
    skip() {
      this.vpaidAd.skipAd(), this.stop();
    }
    start() {
      try {
        this.vpaidAd.startAd();
      } catch (e) {
        this.handleVpaidEvent(
          new o(o.AdError, { code: 901, message: `error on startAd ${e}` })
        );
        return;
      }
      if (this.settings.viewabilityObserver) {
        let e = !1;
        const i = this.settings.viewabilityObserver.subscribe(() => {
          (e = !0),
            this.trackViewableImpressions(xe.VIEWABLE),
            this.dispatchAdsManagerEvent(I.VIEWABLE_IMPRESSION),
            i.unsubscribe();
        });
        this.vpaidAd.subscribe(() => {
          e || this.trackViewableImpressions(xe.NOT_VIEWABLE), i.unsubscribe();
        }, "AdVideoComplete");
      } else this.trackViewableImpressions(xe.VIEW_UNDETERMINED);
    }
    stop() {
      this.isStopped ||
        (this.vpaidAd.stopAd(),
        setTimeout(() => {
          this.isStopped ||
            ((this.isStopped = !0),
            this.dispatchAdsManagerEvent(I.ALL_ADS_COMPLETED));
        }, 200));
    }
    addEventListener(e, i, n) {
      this.listeners.set(i, { type: e, callback: i, tracked: !1 });
    }
    removeEventListener(e, i) {
      let n = this.listeners.get(i);
      e === (n == null ? void 0 : n.type) && this.listeners.delete(i);
    }
    getVPAID() {
      return this.vpaidAd;
    }
    getDuration() {
      const e = this.vpaidAd.getAdDuration();
      return e > 0 ? e : this.vastAd.duration;
    }
    getMediafile() {
      if (this.mediafiles[0]) return this.mediafiles[0];
      throw new Error("no mediafile selected");
    }
    resizeVpaidContainer(e, i) {
      (this.vpaidContainer.style.width = e + "px"),
        (this.vpaidContainer.style.height = i + "px"),
        (this.videoContent.style.width = e + "px"),
        (this.videoContent.style.height = i + "px");
    }
    handleVpaidEvent(e) {
      this.vpaidEventQueue.push(e), this.processVpaidEventQueue();
    }
    processVpaidEventQueue() {
      if (!this.isProcessingVpaidEvent && this.vpaidEventQueue.length > 0) {
        const e = this.vpaidEventQueue.shift();
        e && this.processVpaidEvent(e);
      }
    }
    processVpaidEvent(e) {
      if (
        this.isProcessingVpaidEvent ||
        (this.triggeredEvents.indexOf(e.type) > -1 && qr.indexOf(e.type) > -1)
      )
        return;
      this.triggeredEvents.push(e.type), (this.isProcessingVpaidEvent = !0);
      const i = e.type,
        n = e.data,
        s = Yr[i];
      switch (i) {
        case o.AdClickThru:
          n.url &&
            n.playerHandles &&
            (window.open(n.url), (e.data.playerHandles = !1)),
            this.trackPixel(s);
          break;
        case o.AdError:
          this.trackPixel(s, { errorCode: n.code });
          break;
        case o.AdVolumeChange:
          ((this.isMuted && this.getVolume()) ||
            (!this.isMuted && !this.getVolume())) &&
            this.trackPixel(this.getVolume() ? "unmute" : "mute");
          break;
        default:
          this.trackPixel(s);
      }
      const r = Kr[i];
      r && this.dispatchAdsManagerEvent(r, n),
        i === o.AdVolumeChange
          ? (!this.isMuted &&
              this.vpaidAd.getAdVolume() === 0 &&
              this.dispatchAdsManagerEvent(I.VOLUME_MUTED),
            (this.isMuted = !!this.getVolume()))
          : i === o.AdStopped
          ? ((this.isStopped = !0),
            setTimeout(() => {
              try {
                this.vpaidContainer.parentNode.removeChild(this.vpaidContainer);
              } catch {}
            }))
          : i === o.AdError && setTimeout(() => this.stop()),
        (this.isProcessingVpaidEvent = !1),
        this.processVpaidEventQueue();
    }
    dispatchAdsManagerEvent(e, i = {}) {
      this.listeners.forEach((n) => {
        if (n.type === e)
          try {
            n.callback(this.genAdEvent(e, i));
          } catch {}
      });
    }
    getCurrentTime() {
      return this.vpaidAd.getAdDuration() - this.vpaidAd.getAdRemainingTime();
    }
    trackPixel(e, i = {}) {
      this.tracking.forEach((n) => {
        var s;
        n.type === e &&
          (!n.tracked || Jr.indexOf(e) === -1) &&
          (e !== "progress" ||
            (e === "progress" && n.offset <= this.getCurrentTime())) &&
          (e !== "click" && (n.tracked = !0),
          (document.createElement("img").src = Ei(
            n.pixel,
            this.getCurrentTime(),
            i.errorCode,
            (s = this.mediafiles) != null && s.length
              ? this.mediafiles[0].url
              : void 0
          )));
      });
    }
    genAdEvent(e, i = {}) {
      return e === I.AD_ERROR
        ? gr(
            new G({
              code: i.code || 901,
              message: i.message || JSON.stringify(i),
              type:
                this.triggeredEvents.indexOf(o.AdImpression) > -1
                  ? Je.AD_PLAY
                  : Je.AD_LOAD,
            })
          )
        : {
            type: e,
            getAd: () => {
              var n;
              return new Fr(
                this.vastAd,
                this.vpaidAd,
                (n = this.mediafiles) != null && n.length
                  ? this.mediafiles[0]
                  : void 0
              );
            },
            getAdData: () => i,
          };
    }
    trackViewableImpressions(e) {
      this.viewableImpressions.forEach((i) => {
        i.tracked ||
          ((document.createElement("img").src = i[e]), (i.tracked = !0));
      });
    }
  }
  function Zr(t, e, i = {}) {
    const n = i.loadVastFetcher || we;
    return typeof t == "string"
      ? Nt(t, n).then((s) => new Fe(s, e, i))
      : t.adTagUri
      ? Nt(t.adTagUri, n)
          .then((s) => Si(t, s))
          .then((s) => new Fe(s, e, i))
      : Promise.resolve(new Fe(t, e, i));
  }
  const ea = "https://t.seedtag.com/c",
    Pi = "anwrapper-1.1021.0.js",
    ta = () => `${ea}/anwrapper/`,
    ki = (t = Pi, e) => ta() + t,
    Ri = () => /(.*)\/anwrapper\-([0-9\.]+)+\.js(\?.+)*/gi,
    zt = (t) => {
      const e = Ri().exec(t);
      return e && e[2];
    },
    ia = (t) => Ri().exec(t),
    na = (t, e, i = Pi) => (ia(t) ? ki(i) : t),
    sa = (t, e) => {
      const i = zt(t);
      return i
        ? (zt(ki()) !== i &&
            e(me.XandrViewabilityWrapperChange, { anwrapperVersion: i }),
          na(t))
        : t;
    },
    ra = (t, e, i = {}, n) => {
      const s = t.mediafiles.map((a) => ({ ...a, url: sa(a.url, n) })),
        r = { ...t, mediafiles: s };
      return Zr(r, e, i);
    },
    tt = "901",
    aa = "1205",
    oa = "303",
    da = "1290",
    ha = /AdError (\d{3,4})(?!\d)/g,
    ca = /VAST error (\d{3,4})(?!\d)/i,
    la = [/NotAllowedError/, /AbortError:.*paused to save power/],
    ua = [/No Ads VAST response after one or more Wrappers/i, /No Ads?$/i],
    pa = /^HeavyAdIntervention/;
  function ga(t) {
    if (!t) return;
    const e = [...[...t.matchAll(ha)].map((n) => n[1])]
      .reverse()
      .find((n) => n !== tt);
    if (e) return e;
    const i = t.match(ca);
    if (i && i[1] !== tt) return i[1];
    if (la.some((n) => n.test(t))) return aa;
    if (ua.some((n) => n.test(t))) return oa;
    if (pa.test(t)) return da;
  }
  const va = 2e4,
    ma = {
      [y.STARTED]: [R.VideoStarted],
      [y.IMPRESSION]: [x.AdView, R.VideoImpression, R.VideoPlay],
      [y.CLICK]: [R.VideoClick, x.AdClick],
      [y.LOADED]: [R.VideoReady, R.VideoVastLoaded],
      [y.PAUSED]: [R.VideoPaused],
      [y.RESUMED]: [R.VideoResumed],
      [y.FIRST_QUARTILE]: [R.VideoPlayPercentile25],
      [y.MIDPOINT]: [R.VideoPlayPercentile50],
      [y.THIRD_QUARTILE]: [R.VideoPlayPercentile75],
      [y.COMPLETE]: [R.VideoEnd],
      [y.AD_ERROR]: [R.VideoError],
      [y.SKIPPED]: [R.VideoSkip],
      [y.ALL_ADS_COMPLETED]: [R.VideoAllAdsCompleted],
      [y.IFRAME_READY]: [x.AdIframeReady],
    },
    fa = (t) => ma[t] || [];
  class Aa {
    constructor(e, i, n, s) {
      u(this, "adsManager"),
        u(this, "muteButton"),
        u(this, "videoContainer"),
        u(this, "triggeredEvents", []),
        u(this, "destroyed", !1),
        u(this, "videoDuration"),
        u(this, "videoContainerClassName", "video-container"),
        u(this, "dispatchErrorEvent", (a) => {
          var d;
          let h, c, v, p;
          try {
            const f = (d = a.getContext) == null ? void 0 : d.call(a);
            if (
              (f && (p = { ...f, message: a.getMessage() }),
              (h = a.getErrorCode()),
              (v = a.getType()),
              String(h) === tt)
            ) {
              const m = ga(a.getMessage());
              m && (c = Number(m));
            }
          } catch {}
          this.dispatchEvent(R.VideoError, {
            errorCode: h,
            vpaidErrorCode: c,
            errorType: v,
            vastErrorContext: p,
          });
        }),
        (this.content = e),
        (this.container = i),
        (this.handleEvent = n),
        (this.adSetting = s);
      const r = this.container.ownerDocument;
      (this.muteButton = r.createElement("div")),
        (this.videoContainer = r.createElement("div")),
        (this.videoContainer.className = `st-reset ${this.videoContainerClassName}`),
        this.videoContainer.setAttribute(
          "data-testid",
          this.videoContainerClassName
        ),
        (this.videoContainer.style.width = "100%"),
        (this.videoContainer.style.height = "100%"),
        this.container.appendChild(this.videoContainer);
    }
    init() {
      return new Promise((e, i) =>
        er(this.content)
          .then((n) => {
            (this.videoDuration = n.duration),
              ra(
                n,
                this.videoContainer,
                {
                  backgroundColor: this.adSetting.videoBackground,
                  timeout: va,
                },
                this.dispatchEvent.bind(this)
              ).then((s) => {
                (this.adsManager = s),
                  Object.keys(y).forEach((a) => {
                    const d = y[a];
                    s.addEventListener(d, (h) => {
                      fa(d).forEach((c) => {
                        switch (c) {
                          case R.VideoError:
                            this.dispatchErrorEvent(h.getError());
                            break;
                          default:
                            this.dispatchEvent(c);
                        }
                      });
                    });
                  });
                const r = !Q();
                if (this.adSetting.canMute) {
                  const a = new pr(s, r);
                  (this.muteButton = a.get()),
                    s.addEventListener(y.STARTED, () => {
                      this.videoContainer.appendChild(this.muteButton);
                    });
                }
                s.addEventListener(y.LOADED, () => {
                  this.dispatchEvent(x.AdReady), e();
                }),
                  s.addEventListener(y.ALL_ADS_COMPLETED, () => {
                    setTimeout(() => {
                      this.destroy();
                    }, 300);
                  }),
                  s.init(
                    this.adSetting.adSize.width,
                    this.adSetting.adSize.height,
                    "normal"
                  );
              });
          })
          .catch((n) => {
            n instanceof G || n.vastAdError
              ? (this.dispatchErrorEvent(n), this.destroy())
              : i(n);
          })
      );
    }
    render() {
      var e;
      this.dispatchEvent(x.AdInsert),
        (e = this.adsManager) == null || e.start();
    }
    destroy() {
      return new Promise((e) => {
        var i, n;
        try {
          this.destroyed ||
            ((this.destroyed = !0),
            (i = this.adsManager) == null || i.stop(),
            this.adSetting.canMute && this.muteButton.remove(),
            this.videoContainer.remove(),
            (n = this.adsManager) == null || n.destroy(),
            this.dispatchEvent(R.VideoAllAdsCompleted)),
            e();
        } catch {
          e();
        }
      });
    }
    dispatchEvent(e, i) {
      if (this.triggeredEvents.indexOf(e) === -1) {
        const n = { ...i, videoDuration: this.videoDuration };
        this.triggeredEvents.push(e), this.handleEvent(e, n);
      }
    }
    getIframe() {
      return this.container.querySelector("iframe");
    }
    resize(e) {
      var i;
      (i = this.adsManager) == null || i.resize(e.width, e.height, "normal");
    }
  }
  class Ea {
    constructor(e, i, n, s) {
      (this.container = e),
        (this.bidResponse = i),
        (this.eventHandler = n),
        (this.adSetting = s);
    }
    createAd() {
      switch (this.bidResponse.productType) {
        case V.DISPLAY:
          return this.createDisplay(this.bidResponse);
        case V.VIDEO:
          return this.createVideo();
        case V.NATIVE:
          return this.createNative();
        default:
          throw new ds();
      }
    }
    createDisplay(e) {
      const i = {
          adSize: this.adSetting.adSize,
          iframeId: e.creativeId,
          isSandbox: !this.adSetting.useSrcdoc,
        },
        n = (r, a) => {
          this.eventHandler(r, a);
        },
        s = this.adSetting.useSrcdoc
          ? new St(i, this.container, n)
          : new Ct(i, this.container, n);
      return new Ns(this.bidResponse.content, s);
    }
    createNative() {
      const e = {
          adSize: this.adSetting.adSize,
          iframeId: this.bidResponse.creativeId,
          isSandbox: !1,
        },
        i = (s, r) => {
          this.eventHandler(s, r);
        },
        n = this.adSetting.useSrcdoc
          ? new St(e, this.container, i)
          : new Ct(e, this.container, i);
      return new Xs(this.bidResponse.content, n, i);
    }
    createVideo() {
      const e = (i, n) => {
        this.eventHandler(i, n);
      };
      return new Aa(
        this.bidResponse.content,
        this.container,
        e,
        this.adSetting
      );
    }
  }
  function ya(t) {
    let e, i, n, s;
    const { horizontalAlign: r, verticalAlign: a } = t.positionSetting;
    return (
      r === H.CENTER
        ? (e = t.containerSize.width / 2 - t.adSize.width / 2)
        : r === H.LEFT
        ? (e = 0)
        : r === H.RIGHT && (i = 0),
      a === N.CENTER
        ? (n = t.containerSize.height / 2 - t.adSize.height / 2)
        : a === N.TOP
        ? (n = 0)
        : a === N.BOTTOM && (s = 0),
      { left: e, right: i, top: n, bottom: s }
    );
  }
  function ba(t, e) {
    const i = (e.width == 0 ? t.width : e.width) / t.width,
      n = (e.height == 0 ? t.height : e.height) / t.height;
    return Math.min(1, i, n);
  }
  function wa(t) {
    const { horizontalAlign: e, verticalAlign: i } = t.positionSetting;
    return `${e} ${i}`;
  }
  var te = ((t) => (
    (t.MOBILE_VIDEO = "mobile-video"),
    (t.VIDEO = "video"),
    (t.DISPLAY = "display"),
    t
  ))(te || {});
  class Ca {
    constructor(e) {
      u(this, "svg", ci),
        u(this, "closeButtonElement"),
        (this.onClick = e),
        (this.closeButtonElement = document.createElement("div")),
        this.closeButtonElement.setAttribute(
          "data-testid",
          "external-close-button"
        ),
        (this.closeButtonElement.className = "external-x-to-close st-reset"),
        (this.closeButtonElement.style.pointerEvents = "all"),
        (this.closeButtonElement.innerHTML = this.svg),
        this.setPositionStyle(this.closeButtonElement),
        this.closeButtonElement.addEventListener("click", () => {
          this.onClick();
        });
    }
    render(e) {
      return e.appendChild(this.closeButtonElement), this.closeButtonElement;
    }
    destroy() {
      this.closeButtonElement.removeEventListener("click", this.onClick),
        this.closeButtonElement.remove();
    }
    setPositionStyle(e) {
      (e.style.position = "fixed"),
        (e.style.top = "32px"),
        (e.style.right = "32px"),
        (e.style.width = "40px"),
        (e.style.height = "40px"),
        (e.style.cursor = "pointer"),
        (e.style.zIndex = "2147483647");
    }
  }
  const Sa =
    '<svg height="24" width="30" overflow="visible" viewBox="0 0 95.4 78.8" xmlns="http://www.w3.org/2000/svg"><path d="M0 0h95.4v78.8H0z" fill="#1d1d1d" opacity="0.5"/><path d="M12.5 5.8c-1.7.5-2.3 1.7-2.3 3.3V70c0 1.6.8 2.7 2.3 3 .3.1.6.1.9.1h26.1c2.3 0 3.7-1.7 3-3.5-.4-1.1-1.4-1.7-2.8-1.7H16.1V11.2h62.4V32.3c0 .5 0 1 .2 1.4.4 1 1.3 1.6 2.5 1.7 1.3.1 2.2-.5 2.7-1.5l.3-.6V8c-.4-1.1-1.1-1.8-2.3-2.1-23.2-.1-46.3-.1-69.4-.1z" fill="#fff"/><path d="M84.1 70.9c-.5 1.3-1.3 2.1-2.8 2.1H51.5c-1.6 0-2.7-1.1-2.7-2.7V40.5c0-1.7 1.1-2.7 2.7-2.7h29.9c1.2 0 2.1.6 2.5 1.7 0 .1.1.2.2.3v31.1zm-30-28v24.8h24.7V42.9H54.1zM81 5.8c1.1.3 1.8 1 2.1 2.1V5.8H81zM38 23.3h3.6c1.3 0 2.3-.9 2.5-2.1.2-1.2-.3-2.3-1.4-2.8-.4-.2-1.3-.3-1.3-.3h-9.3c-2 0-3 .9-3 2.9v10c0 1.4 1.2 2.4 2.5 2.4s2.5-1 2.6-2.3c.1-.8 0-1.7 0-2.6v-1.4c.3.3.5.4.6.6l7.5 7.5c.8.8 1.7 1.1 2.7.8 1.8-.5 2.5-2.6 1.4-4.1l-.6-.6-7.3-7.3c-.1-.3-.3-.5-.5-.7z" fill="#fff"/></svg>';
  class Ia {
    constructor(e) {
      u(this, "expandButtonElement"),
        u(this, "svg", Sa),
        (this.onClick = e),
        (this.expandButtonElement = document.createElement("div")),
        this.expandButtonElement.setAttribute("data-testid", "expand-button"),
        (this.expandButtonElement.className = "expand-button"),
        (this.expandButtonElement.innerHTML = this.svg),
        this.setPositionStyle(),
        this.expandButtonElement.addEventListener("click", () => {
          this.onClick();
        });
    }
    render(e) {
      return e.appendChild(this.expandButtonElement), this.expandButtonElement;
    }
    destroy() {
      this.expandButtonElement.removeEventListener("click", this.onClick),
        this.expandButtonElement.remove();
    }
    setPositionStyle() {
      (this.expandButtonElement.style.position = "absolute"),
        (this.expandButtonElement.style.bottom = "0px"),
        (this.expandButtonElement.style.right = "0px"),
        (this.expandButtonElement.style.width = "30px"),
        (this.expandButtonElement.style.height = "24px"),
        (this.expandButtonElement.style.cursor = "pointer"),
        (this.expandButtonElement.style.zIndex = "2147483647");
    }
  }
  const Ta = {
    [te.MOBILE_VIDEO]: "background-video-16-9 background-inscreen-video",
    [te.VIDEO]: "background-inscreen-video",
    [te.DISPLAY]: "background-inscreen-display",
  };
  class Va {
    constructor(e, i, n, s) {
      if (
        (u(this, "adRender"),
        u(this, "canvas"),
        u(this, "controlsContainer"),
        u(this, "adContainer"),
        u(this, "scale", 1),
        u(this, "closeButton"),
        u(this, "externalCloseButton"),
        u(this, "videoExpandButton"),
        (this.container = e),
        (this.adSettings = i),
        (this.eventHandler = n),
        (this.bidResponse = s),
        (e.innerHTML = this.getHtml(i.adSize)),
        (this.adContainer = e.querySelector(".st-adunit-ad")),
        this.setAdContainerStyle(i),
        (this.canvas = e.querySelector(".st-canvas")),
        (this.controlsContainer = e.querySelector(".st-controls")),
        !this.canvas)
      )
        throw new cs();
      if (!this.controlsContainer) throw new ls();
      (this.controlsContainer.style.display = "flex"),
        this.controlsContainer.setAttribute("data-testid", "controls"),
        this.adContainer.setAttribute("data-testid", "adunit-ad");
    }
    init() {
      return (
        (this.adRender = new Ea(
          this.canvas,
          this.bidResponse,
          this.eventHandlerInterceptor.bind(this),
          this.adSettings
        ).createAd()),
        this.adRender.init()
      );
    }
    render() {
      var e;
      (e = this.adRender) == null || e.render(),
        this.renderCloseButton(),
        this.renderInScreenBackground(),
        this.renderDisplayBackground(),
        this.renderExternalCloseButton(),
        this.renderVideoExpandButton();
    }
    async destroy() {
      const e = () =>
        (this.adRender && this.adRender.destroy()) || Promise.resolve();
      return (
        this.closeButton && this.closeButton.destroy(),
        this.videoExpandButton && this.videoExpandButton.destroy(),
        e().then(() => {
          this.container.innerHTML = "";
        })
      );
    }
    getAdContainer() {
      return this.adContainer;
    }
    redraw(e) {
      var i;
      (this.adSettings = e),
        this.setAdContainerStyle(this.adSettings),
        this.closeButton &&
          (this.closeButton.destroy(), this.renderCloseButton()),
        (i = this.adRender) == null || i.resize(e.adSize);
    }
    getIframe() {
      if (!this.adRender) throw new us();
      return this.adRender.getIframe();
    }
    setAdContainerStyle(e) {
      const { right: i, left: n, top: s, bottom: r } = ya(e);
      if (
        ((this.adContainer.style.pointerEvents = "all"),
        (this.adContainer.style.position = e.positionSetting.position),
        (this.adContainer.style.overflow = "hidden"),
        (this.adContainer.style.bottom = r !== void 0 ? r + "px" : "initial"),
        (this.adContainer.style.top = s !== void 0 ? s + "px" : "initial"),
        (this.adContainer.style.right = i !== void 0 ? i + "px" : "initial"),
        (this.adContainer.style.left = n !== void 0 ? n + "px" : "initial"),
        (this.adContainer.style.margin = e.positionSetting.margin + "px"),
        (this.adContainer.style.zIndex = "2147483647"),
        e.canScale &&
          ((this.scale = ba(e.adSize, e.containerSize)), this.scale !== 1))
      ) {
        this.adContainer.style.transform = `scale(${this.scale.toString()})`;
        const a = wa(e);
        this.adContainer.style.transformOrigin = a;
      }
      (this.adContainer.style.height = e.adSize.height + "px"),
        (this.adContainer.style.width = e.adSize.width + "px");
    }
    renderInScreenBackground() {
      const { inScreenBackground: e } = this.adSettings;
      if (e) {
        const i = document.createElement("div");
        (i.style.position = "fixed"),
          (i.style.height = "100%"),
          (i.style.width = "100%"),
          (i.style.right = "0px"),
          (i.className = Ta[e]),
          i.setAttribute("data-testid", "inscreen-background"),
          this.controlsContainer.appendChild(i);
      }
    }
    renderDisplayBackground() {
      if (this.adSettings.showDisplayBackground) {
        const e = document.createElement("div");
        (e.style.position = "fixed"),
          (e.style.height = "100%"),
          (e.style.width = "100%"),
          (e.style.top = "0px"),
          (e.style.zIndex = "2147483645"),
          (e.style.backgroundColor = "rgba(0, 0, 0, 0.8)"),
          (e.className = "background-display"),
          this.container.appendChild(e);
      }
    }
    renderExternalCloseButton() {
      this.adSettings.canExternalCloseButton &&
        ((this.externalCloseButton = new Ca(() => {
          this.eventHandler(x.AdClose), this.destroy();
        })),
        this.externalCloseButton.render(this.container));
    }
    renderCloseButton() {
      this.adSettings.canClose &&
        ((this.closeButton = new Ms(
          this.scale,
          this.adSettings.closeButtonPosition,
          () => {
            this.eventHandler(x.AdClose), this.destroy();
          }
        )),
        this.closeButton.render(this.controlsContainer));
    }
    renderVideoExpandButton() {
      this.adSettings.canExpandVideo &&
        ((this.videoExpandButton = new Ia(() => {
          var e;
          (e = this.videoExpandButton) == null || e.destroy(),
            this.eventHandler(R.VideoExpand);
        })),
        this.videoExpandButton.render(this.controlsContainer));
    }
    getHtml(e) {
      return ` <div class="st-adunit-ad st-reset"> <div class="st-display-render st-reset open st-controls"> <div class="st-canvas st-reset horizontal-static" data-testid="canvas" style="width:${e.width}px;height:${e.height}px;z-index:2147483640;position:relative"></div> </div> </div> `;
    }
    eventHandlerInterceptor(e, i) {
      var n, s;
      e === R.VideoAllAdsCompleted &&
        ((n = this.closeButton) == null || n.destroy(),
        (s = this.videoExpandButton) == null || s.destroy()),
        this.eventHandler(e, i);
    }
  }
  class re {
    constructor(e, i, n, s) {
      u(this, "ad"),
        (this.container = e),
        (this.eventHandler = i),
        (this.adUnitConfig = n),
        (this.bidResponse = s);
    }
    async init() {
      const e = this.buildAdSettings();
      (this.ad = new Va(
        this.container,
        e,
        this.handleEvent.bind(this),
        this.bidResponse
      )),
        await this.ad.init();
    }
    resize(e) {
      this.redraw();
    }
    redraw() {
      if (!this.ad) throw new Ce();
      const e = this.buildAdSettings();
      this.ad.redraw(e);
    }
    buildAdSettings() {
      return {
        ...this.getAdSettings(),
        useSrcdoc: this.adUnitConfig.useSrcdoc,
      };
    }
    render() {
      if (this.ad) this.ad.render();
      else throw new Ce();
    }
    destroy() {
      return (this.ad && this.ad.destroy()) || Promise.resolve();
    }
    getAdContainer() {
      if (this.ad) return this.ad.getAdContainer();
      throw new Ce();
    }
    getAdIframe() {
      if (!this.ad) throw new Ce();
      return this.ad.getIframe();
    }
    getConfig() {
      return this.adUnitConfig;
    }
    isBranding() {
      return ri(this.bidResponse.productShortCode);
    }
    getFullVideoAspectRatio() {
      return this.adUnitConfig.containerSize.width >
        this.adUnitConfig.containerSize.height
        ? this.get169AspectRatioWidth()
        : this.get169AspectRatioHeight();
    }
    get169AspectRatioWidth() {
      const e = this.adUnitConfig.containerSize.width,
        i = this.adUnitConfig.containerSize.height,
        n = (i * 16) / 9;
      return { width: Math.min(n, e), height: i };
    }
    get169AspectRatioHeight() {
      const e = this.adUnitConfig.containerSize.width,
        i = this.adUnitConfig.containerSize.height,
        n = e / (16 / 9),
        s = Math.min(n, i);
      return { width: e, height: s };
    }
    handleEvent(e, i) {
      this.eventHandler(e, i);
    }
  }
  class xa extends re {
    getAdSettings() {
      const e = this.getAdSize(),
        i = this.getContainerSize(),
        n = this.getPosition();
      return {
        containerSize: i,
        adSize: e,
        positionSetting: n,
        canScale: !this.isBranding(),
        canClose: !this.isBranding() && !this.adUnitConfig.disableCloseButton,
        canMute: !this.isBranding(),
        videoBackground: this.isBranding() ? "transparent" : "black",
        closeButtonPosition: Y.RIGHT,
        canExpandVideo: !1,
      };
    }
    getAdSize() {
      return $(this.bidResponse.productShortCode)
        ? this.getFullVideoAspectRatio()
        : this.isBranding() && Es()
        ? this.get169AspectRatioWidth()
        : this.isBranding() || this.bidResponse.productType === V.NATIVE
        ? this.adUnitConfig.containerSize
        : { width: this.bidResponse.width, height: this.bidResponse.height };
    }
    getContainerSize() {
      return this.adUnitConfig.containerSize;
    }
    getPosition() {
      return {
        horizontalAlign: H.CENTER,
        verticalAlign: Q() ? N.TOP : N.CENTER,
        position: F.ABSOLUTE,
        margin: 0,
      };
    }
  }
  class Pa extends re {
    getAdSettings() {
      const e = this.getAdSize(),
        i = this.getPosition();
      return {
        containerSize: this.adUnitConfig.containerSize,
        adSize: e,
        positionSetting: i,
        canScale: !this.isBranding(),
        canClose:
          !this.isBranding() &&
          this.bidResponse.productType === V.VIDEO &&
          this.bidResponse.productMarket === ot.Open &&
          !this.adUnitConfig.disableCloseButton,
        canMute: !this.isBranding(),
        videoBackground: this.isBranding() ? "transparent" : "black",
        closeButtonPosition: Y.RIGHT,
        canExpandVideo: !1,
      };
    }
    getPosition() {
      return {
        horizontalAlign: H.CENTER,
        verticalAlign: N.TOP,
        position: F.ABSOLUTE,
        margin: 0,
      };
    }
    getAdSize() {
      return $(this.bidResponse.productShortCode)
        ? this.getFullVideoAspectRatio()
        : this.isBranding() || this.bidResponse.productType === V.NATIVE
        ? this.adUnitConfig.containerSize
        : { width: this.bidResponse.width, height: this.bidResponse.height };
    }
  }
  const Bt = 900,
    Se = 150,
    Ut = 116,
    Ge = { width: 728, height: 90 },
    ka = { width: 400, height: 250 };
  class Ra extends re {
    getAdSettings() {
      const e = this.getAdSize(),
        i = this.getContainerSize(e),
        n = this.getPosition();
      return {
        containerSize: i,
        adSize: e,
        positionSetting: n,
        canScale: this.canScale(),
        canClose: !this.isBranding() && !this.adUnitConfig.disableCloseButton,
        canMute: !this.isBranding(),
        videoBackground: this.isBranding() ? "transparent" : "black",
        inScreenBackground: this.getInScreenBackground(),
        closeButtonPosition: Y.RIGHT,
        canExpandVideo: !1,
      };
    }
    resize(e) {
      (this.adUnitConfig.adUnitMaxHeight = e.height), super.resize(e);
    }
    getAdSize() {
      var e, i;
      const n = this.container.ownerDocument.documentElement.clientWidth,
        s = this.container.ownerDocument.documentElement.clientHeight,
        r = this.container.ownerDocument.defaultView;
      let a = Se,
        d = Bt;
      if (
        (oi(r) &&
          ((a = ((e = fe(r)) == null ? void 0 : e.ext.geom().self.h) || a),
          (d = ((i = fe(r)) == null ? void 0 : i.ext.geom().self.w) || d)),
        this.adUnitConfig.isEmbedInIframe &&
          ((a = Math.min(s, Se)),
          (d = Math.min(this.container.clientWidth, Bt))),
        this.adUnitConfig.adUnitMaxHeight &&
          (a = this.adUnitConfig.adUnitMaxHeight),
        this.bidResponse.productType === V.NATIVE)
      )
        return Q()
          ? { width: n, height: Math.min(a || Ut, Ut) }
          : { width: Ge.width, height: Math.min(a || Ge.height, Ge.height) };
      if ($(this.bidResponse.productShortCode))
        if (Q() || this.adUnitConfig.isEmbedInIframe) {
          const h = (n / 2 / 16) * 9,
            c = Math.min(h, a);
          return { width: (c * 16) / 9, height: c };
        } else return ka;
      else if (this.isBranding()) return { width: n > d ? d : n, height: a };
      return { width: this.bidResponse.width, height: this.bidResponse.height };
    }
    getContainerSize(e) {
      if (this.adUnitConfig.isEmbedInIframe)
        return this.adUnitConfig.containerSize;
      const i = this.container.ownerDocument.documentElement.clientWidth;
      if (this.isBranding()) return { width: i, height: Se };
      if (this.bidResponse.productType === V.NATIVE && Q())
        return { width: i, height: e.height };
      const n = Math.min(this.adUnitConfig.adUnitMaxHeight || e.height, Se);
      return { width: i, height: n };
    }
    getPosition() {
      return $(this.bidResponse.productShortCode) &&
        !Q() &&
        !this.adUnitConfig.isEmbedInIframe
        ? {
            horizontalAlign: H.RIGHT,
            verticalAlign: N.BOTTOM,
            position: F.FIXED,
            margin: 25,
          }
        : {
            horizontalAlign: H.CENTER,
            verticalAlign: this.adUnitConfig.isEmbedInIframe ? N.TOP : N.BOTTOM,
            position: this.adUnitConfig.isEmbedInIframe ? F.RELATIVE : F.FIXED,
            margin: 0,
          };
    }
    getInScreenBackground() {
      if ($(this.bidResponse.productShortCode))
        return Q() ? te.MOBILE_VIDEO : te.VIDEO;
      if (
        this.bidResponse.productType === V.DISPLAY ||
        this.bidResponse.productType === V.NATIVE
      )
        return te.DISPLAY;
    }
    canScale() {
      return !(
        this.isBranding() ||
        $(this.bidResponse.productShortCode) ||
        (this.bidResponse.productType === V.NATIVE && Q())
      );
    }
  }
  class Oa extends re {
    getAdSettings() {
      const e = this.getAdSize(this.adUnitConfig.containerSize),
        i = this.getPosition();
      return {
        containerSize: this.adUnitConfig.containerSize,
        adSize: e,
        positionSetting: i,
        canScale: this.canScale(),
        canClose: !this.isBranding(),
        canMute: !this.isBranding(),
        videoBackground: this.isBranding() ? "transparent" : "black",
        closeButtonPosition: Y.RIGHT,
        canExpandVideo: !1,
      };
    }
    getPosition() {
      return {
        horizontalAlign: H.CENTER,
        verticalAlign: N.TOP,
        position: F.ABSOLUTE,
        margin: 0,
      };
    }
    getAdSize(e) {
      return $(this.bidResponse.productShortCode)
        ? this.getFullVideoAspectRatio()
        : this.bidResponse.productMarket === ot.Open &&
          this.bidResponse.productType !== V.NATIVE
        ? { width: this.bidResponse.width, height: this.bidResponse.height }
        : e;
    }
    canScale() {
      return !(this.isBranding() || $(this.bidResponse.productShortCode));
    }
  }
  const Da = { width: 300, height: 600 };
  class Ma extends re {
    getAdSettings() {
      const e = this.getContainerSize(),
        i = this.getAdSize(e),
        n = this.getPosition();
      return {
        containerSize: e,
        adSize: i,
        positionSetting: n,
        canScale: !this.isBranding(),
        canClose: !1,
        canMute: !this.isBranding(),
        videoBackground: this.isBranding() ? "transparent" : "black",
        showDisplayBackground: !this.adUnitConfig.isEmbedInIframe,
        canExternalCloseButton: !this.adUnitConfig.isEmbedInIframe,
        closeButtonPosition: Y.RIGHT,
        canExpandVideo: !1,
      };
    }
    getPosition() {
      return {
        horizontalAlign: H.CENTER,
        verticalAlign: N.CENTER,
        position: F.FIXED,
        margin: 0,
      };
    }
    getAdSize(e) {
      return this.isBranding()
        ? e
        : this.bidResponse.productType === V.NATIVE
        ? Da
        : this.bidResponse.productType === V.DISPLAY
        ? { width: this.bidResponse.width, height: this.bidResponse.height }
        : this.bidResponse.productType === V.VIDEO
        ? this.getFullVideoAspectRatio()
        : e;
    }
    getContainerSize() {
      if (this.adUnitConfig.isEmbedInIframe)
        return this.adUnitConfig.containerSize;
      const e = this.container.ownerDocument.documentElement.clientWidth,
        i = this.container.ownerDocument.documentElement.clientHeight;
      return { width: e, height: i };
    }
  }
  class Na extends re {
    getAdSettings() {
      const e = this.getAdSize(),
        i = this.getPosition();
      return {
        containerSize: e,
        adSize: e,
        positionSetting: i,
        canScale: !1,
        canClose: !1,
        canMute: !1,
        videoBackground: "transparent",
        closeButtonPosition: Y.RIGHT,
        canExpandVideo: !1,
      };
    }
    getPosition() {
      return {
        horizontalAlign: H.CENTER,
        verticalAlign: N.TOP,
        position: F.ABSOLUTE,
        margin: 0,
      };
    }
    getAdSize() {
      return { width: 1, height: 1 };
    }
  }
  const La = { width: 300, height: 116 };
  class Oi extends re {
    constructor(e, i, n, s) {
      super(e, i, n, s),
        u(this, "isVideoArea30Active", !1),
        u(this, "resizedContainerHeight"),
        (this.isVideoArea30Active = this.adUnitConfig.videoArea30 || !1);
    }
    getAdSettings() {
      const e = this.getContainerSize(),
        i = this.getAdSize(e),
        n = this.getInImagePosition(),
        s = this.getPosition(n),
        r = this.getCloseButtonPosition(n);
      return {
        containerSize: e,
        adSize: i,
        positionSetting: s,
        canScale: !this.isBranding(),
        canClose: !this.isBranding() && !this.adUnitConfig.disableCloseButton,
        canMute: !this.isBranding(),
        videoBackground: "transparent",
        closeButtonPosition: r,
        canExpandVideo: this.isFullVideoArea30(),
      };
    }
    handleEvent(e, i) {
      super.handleEvent(e, i),
        e === R.VideoExpand && ((this.isVideoArea30Active = !1), this.redraw());
    }
    resize(e) {
      e != null &&
        e.height &&
        e.height !== 600 &&
        (this.resizedContainerHeight = e.height),
        super.resize(e);
    }
    getPosition(e) {
      switch (e) {
        case 2:
        case 0:
          return {
            horizontalAlign: H.CENTER,
            verticalAlign: N.BOTTOM,
            position: F.ABSOLUTE,
            margin: 0,
          };
        case 1:
          return {
            horizontalAlign: H.RIGHT,
            verticalAlign: N.BOTTOM,
            position: F.ABSOLUTE,
            margin: 0,
          };
      }
    }
    getAdSize(e) {
      return this.isBranding()
        ? e
        : this.bidResponse.productType === V.NATIVE
        ? La
        : this.bidResponse.productType === V.VIDEO
        ? e
        : this.bidResponse.productType === V.DISPLAY
        ? { width: this.bidResponse.width, height: this.bidResponse.height }
        : e;
    }
    getInImagePosition() {
      const e = this.bidResponse.width,
        i = this.bidResponse.height;
      return this.isFullVideoArea30()
        ? 1
        : this.bidResponse.productType === V.VIDEO
        ? 2
        : this.bidResponse.productType === V.NATIVE
        ? 1
        : this.isBranding()
        ? 2
        : (e === 200 && i === 200) ||
          (e === 250 && i === 250) ||
          (e === 300 && i === 250) ||
          (e === 336 && i === 280) ||
          e < i
        ? 1
        : 0;
    }
    getCloseButtonPosition(e) {
      return e === 1 && this.bidResponse.productType === V.DISPLAY
        ? Y.LEFT
        : Y.RIGHT;
    }
    getContainerSize() {
      return this.isFullVideoArea30()
        ? this.getVideoArea30ContainerSize()
        : this.resizedContainerHeight !== void 0
        ? {
            ...this.adUnitConfig.containerSize,
            height: this.resizedContainerHeight,
          }
        : this.adUnitConfig.containerSize;
    }
    getVideoArea30ContainerSize() {
      const e = this.adUnitConfig.containerSize.width * 0.3;
      return { width: (e * 16) / 9, height: e };
    }
    isFullVideoArea30() {
      return (
        this.bidResponse.productType === V.VIDEO &&
        this.isVideoArea30Active &&
        $(this.bidResponse.productShortCode)
      );
    }
  }
  class za extends Oi {
    constructor(e, i, n, s) {
      super(e, i, n, s),
        u(this, "isVideoArea30Active", !0),
        (this.isVideoArea30Active = !0);
    }
  }
  class Ba {
    constructor(e, i, n, s) {
      u(this, "adUnitTypeMap", {
        [z.InTerstitial]: Ma,
        [z.InBanner]: Pa,
        [z.InScreen]: Ra,
        [z.InArticle]: xa,
        [z.InTop]: Oa,
        [z.InSkin]: Na,
        [z.InImage]: Oi,
        [z.InImageRestricted]: za,
      }),
        (this.adUnitContainer = e),
        (this.handleEvent = i),
        (this.adUnitConfig = n),
        (this.bidResponse = s);
    }
    createAdUnit() {
      const e = this.adUnitTypeMap[this.adUnitConfig.adUnitType];
      if (!e) throw new os();
      return new e(
        this.adUnitContainer,
        this.handleEvent.bind(this),
        this.adUnitConfig,
        this.bidResponse
      );
    }
  }
  var Xe = (function () {
      function t(e) {
        (this.inMessages = []),
          (this.outMessages = []),
          (this.listeners = []),
          (this.connected = !1),
          (this.sender = e),
          this.sender.setDelegate(this.onReceive.bind(this));
      }
      return (
        (t.prototype.connect = function (e) {
          var i = this;
          return this.sender.connect(e).then(function () {
            i.onConnect();
          });
        }),
        (t.prototype.listen = function (e) {
          this.listeners.push(e);
        }),
        (t.prototype.send = function (e) {
          if (!this.connected) {
            this.outMessages.push(e);
            return;
          }
          this.sender.send(e);
        }),
        (t.prototype.onConnect = function () {
          (this.connected = !0), this.flushMessages();
        }),
        (t.prototype.onReceive = function (e) {
          this.inMessages.push(e), this.flushMessages();
        }),
        (t.prototype.flushMessages = function () {
          if (this.connected) {
            var e = this.inMessages.shift();
            e &&
              (this.listeners.map(function (i) {
                return i(e);
              }),
              this.flushMessages()),
              (e = this.outMessages.shift()),
              e && (this.send(e), this.flushMessages());
          }
        }),
        t
      );
    })(),
    he;
  (function (t) {
    (t.host = "ht"), (t.guest = "gt");
  })(he || (he = {}));
  var Ae;
  (function (t) {
    (t.connectionRequest = "conReq"), (t.connectionResponse = "conResp");
  })(Ae || (Ae = {}));
  var pt = "mPass://",
    Ua = function (t) {
      return pt + JSON.stringify(t);
    },
    Ha = function (t) {
      return JSON.parse(t.replace(pt, ""));
    },
    _a = function (t) {
      return t.indexOf(pt) === 0;
    },
    Di = (function () {
      function t(e) {
        var i = this,
          n = "pending",
          s = null,
          r = { ok: [], err: [] },
          a = function (h) {
            n === "not" &&
              ((n = "yes"),
              (s = r.ok.reduce(function (c, v) {
                var p = v(c);
                return p === void 0 ? c : p;
              }, h)));
          },
          d = function (h) {
            (n = "err"),
              (s = h || new Error("promise Error")),
              r.err.map(function (c) {
                c(s);
              });
          };
        (this.then = function (h) {
          if ((r.ok.push(h), n === "yes" && a(s), n === "pending")) {
            n = "not";
            var c = e(a, d);
            c !== void 0 && ("then" in c ? c.then(a).catch(d) : a(c));
          }
          return i;
        }),
          (this.catch = function (h) {
            return r.err.push(h), n === "err" && d(s), i;
          });
      }
      return t;
    })(),
    Mi = function (t, e, i) {
      t.addEventListener("message", function (n) {
        if (_a(new String(n.data))) {
          var s = Ha(n.data);
          s.to === e && i(s, n.source);
        }
      });
    },
    Oe = function (t, e) {
      e && e.postMessage(Ua(t), "*");
    },
    Ni = (function () {
      function t(e) {
        (this.target = null),
          (this.delegate = function (i) {}),
          (this.iframe = e);
      }
      return (
        (t.prototype.setDelegate = function (e) {
          this.delegate = e;
        }),
        (t.prototype.connect = function () {
          var e = this;
          return new Di(function (i) {
            Mi(e.iframe.contentWindow, he.host, function (n, s) {
              e.target || ((e.target = s), e.onConnect(), i()), e.delegate(n);
            });
          });
        }),
        (t.prototype.send = function (e) {
          if (this.target) {
            var i = T(T({}, e), { to: he.guest });
            Oe(i, this.target),
              this.target !== this.iframe.contentWindow &&
                Oe(i, this.iframe.contentWindow);
          }
        }),
        (t.prototype.onConnect = function () {
          this.send({ type: Ae.connectionResponse, payload: {} });
        }),
        t
      );
    })(),
    Fa = (function () {
      function t(e) {
        (this.delegate = function (i) {}), (this.currentWindow = e);
      }
      return (
        (t.prototype.setDelegate = function (e) {
          this.delegate = e;
        }),
        (t.prototype.connect = function (e) {
          var i = this;
          return new Di(function (n, s) {
            i.requestConnection();
            var r = setTimeout(function () {
              i.stopRequestConnection(), s();
            }, e || 300);
            Mi(window, he.guest, function (a) {
              a.type === Ae.connectionResponse &&
                (clearTimeout(r), n(), i.onConnect()),
                i.delegate(a);
            });
          });
        }),
        (t.prototype.send = function (e) {
          var i = T(T({}, e), { to: he.host }),
            n = this.currentWindow;
          Oe(i, n);
          try {
            do n && Oe(i, n), (n = n.parent);
            while (n !== n.parent);
          } catch {}
        }),
        (t.prototype.onConnect = function () {
          this.stopRequestConnection();
        }),
        (t.prototype.stopRequestConnection = function () {
          clearInterval(this.connectionInterval);
        }),
        (t.prototype.requestConnection = function () {
          var e = this,
            i = function () {
              e.send({ type: Ae.connectionRequest, payload: {} });
            };
          (this.connectionInterval = setInterval(function () {
            i();
          }, 100)),
            i();
        }),
        t
      );
    })(),
    ee;
  (function (t) {
    (t.Pend = "pending"), (t.Try = "try"), (t.Done = "done"), (t.Err = "err");
  })(ee || (ee = {}));
  var P;
  (function (t) {
    (t.Asset = "asset"),
      (t.Resize = "adResize"),
      (t.Expand = "adExpand"),
      (t.Close = "close"),
      (t.Click = "click"),
      (t.StateChange = "adState"),
      (t.InVideoReady = "inVideoReady"),
      (t.CreativeStart = "vpaid-adapter-started"),
      (t.CreativeType = "creativeType"),
      (t.TrackableAdElement = "trackableAdElement"),
      (t.Delivery = "delivery"),
      (t.Intervention = "intervention"),
      (t.CreativeMessage = "creativeMessage");
  })(P || (P = {}));
  var Li = (function () {
      function t(e) {
        (this.state = {
          sourceType: "Tag",
          url: "",
          slotReady: !1,
          publisherImage: "",
          connection: ee.Pend,
          placement: { hover: !1, scrollOffsetY: 0, viewportPosition: 0 },
          features: {
            fixed: !1,
            adunitType: "inImage",
            expandable: !0,
            closeable: !0,
            hideMuteButton: !1,
            iframeWidth: 0,
            iframeHeight: 0,
          },
          xToClose: { show: !1 },
        }),
          (this.connector = e.connector),
          (this.props = e);
      }
      return (
        (t.prototype.connect = function (e) {
          var i = this;
          return (
            (this.state.connection = ee.Try),
            this.connector.listen(function (n) {
              i.messageHandler(n);
            }),
            this.connector
              .connect(e)
              .then(function () {
                (i.state.connection = ee.Done), i.triggerStateChange();
              })
              .catch(function () {
                (i.state.connection = ee.Err), i.triggerStateChange();
              })
          );
        }),
        (t.prototype.listen = function (e) {
          this.connector.listen(function (i) {
            e(i);
          });
        }),
        (t.prototype.messageHandler = function (e) {
          if (e.type === P.StateChange) {
            var i = e.payload;
            this.stateChangeMessageHandler(i);
          }
        }),
        (t.prototype.stateChangeMessageHandler = function (e) {
          this.forceState(T(T({}, e), { connection: ee.Done }));
        }),
        (t.prototype.setState = function (e) {
          this.newStateHasChanges(e) && (this.forceState(e), this.notify(e));
        }),
        (t.prototype.notify = function (e) {
          this.connector.send({ type: P.StateChange, payload: e });
        }),
        (t.prototype.forceState = function (e) {
          var i = T(T({}, this.state), e);
          this.newStateHasChanges(i) &&
            ((this.state = i), this.triggerStateChange());
        }),
        (t.prototype.triggerStateChange = function () {
          this.props.onStateChange(this.state);
        }),
        (t.prototype.newStateHasChanges = function (e) {
          var i = T(T({}, this.state), e);
          return JSON.stringify(i) !== JSON.stringify(this.state);
        }),
        t
      );
    })(),
    Ga = (function (t) {
      ht(e, t);
      function e() {
        return (t !== null && t.apply(this, arguments)) || this;
      }
      return (
        (e.prototype.messageHandler = function (i) {
          switch ((t.prototype.messageHandler.call(this, i), i.type)) {
            case P.CreativeMessage:
              this.props.onCreativeMessage(i.payload.message, i.payload.time);
              break;
            case P.Click:
              this.props.onClick(i.payload.url);
              break;
            case P.Close:
              this.props.onClose();
              break;
            case P.Resize:
              this.props.onResize(i.payload.size);
              break;
            case P.Expand:
              this.props.onExpand();
              break;
            case P.InVideoReady:
              this.props.onInVideoReady(i.payload);
              break;
            case P.Delivery:
              this.props.onDelivery(i.payload);
              break;
            case P.Intervention:
              this.props.onIntervention(i.payload.pixelUrl);
              break;
            case P.Asset:
              this.props.onAsset(i.payload);
              break;
          }
        }),
        (e.prototype.slotData = function (i) {
          this.setState({
            slotReady: !0,
            publisherImage: i.publisherImage || this.state.publisherImage,
            sourceType: i.sourceType || this.state.sourceType,
            url: i.url || this.state.url,
            features: T(T({}, this.state.features), i.features || {}),
          });
        }),
        (e.prototype.features = function (i) {
          this.setState({ features: T(T({}, this.state.features), i) });
        }),
        (e.prototype.hovered = function (i) {
          this.setState({
            placement: T(T({}, this.state.placement), { hover: i }),
          });
        }),
        (e.prototype.scrollOffsetY = function (i) {
          this.setState({
            placement: T(T({}, this.state.placement), { scrollOffsetY: i }),
          });
        }),
        (e.prototype.viewportPosition = function (i) {
          this.setState({
            placement: T(T({}, this.state.placement), { viewportPosition: i }),
          });
        }),
        (e.prototype.close = function () {
          this.connector.send({ type: P.Close, payload: {} });
        }),
        e
      );
    })(Li),
    Xa = (function (t) {
      ht(e, t);
      function e() {
        return (t !== null && t.apply(this, arguments)) || this;
      }
      return (
        (e.prototype.connect = function () {
          return t.prototype.connect.call(this, 2e3);
        }),
        (e.prototype.click = function (i) {
          this.connector.send({ type: P.Click, payload: { url: i } });
        }),
        (e.prototype.asset = function (i) {
          this.connector.send({ type: P.Asset, payload: i });
        }),
        (e.prototype.close = function () {
          this.connector.send({ type: P.Close, payload: {} });
        }),
        (e.prototype.resize = function (i) {
          !i.width ||
            !i.height ||
            this.connector.send({ type: P.Resize, payload: { size: i } });
        }),
        (e.prototype.expand = function () {
          this.connector.send({ type: P.Expand, payload: {} });
        }),
        (e.prototype.delivery = function (i) {
          this.connector.send({ type: P.Delivery, payload: i });
        }),
        (e.prototype.intervention = function (i) {
          this.connector.send({
            type: P.Intervention,
            payload: { pixelUrl: i },
          });
        }),
        (e.prototype.inVideoConfig = function (i) {
          this.connector.send({ type: P.InVideoReady, payload: i });
        }),
        (e.prototype.xToCloseSetState = function (i) {
          this.setState({ xToClose: T(T({}, this.state.xToClose), i) });
        }),
        (e.prototype.creativeMessage = function (i, n) {
          this.connector.send({
            type: P.CreativeMessage,
            payload: { message: i, time: n },
          });
        }),
        (e.prototype.messageHandler = function (i) {
          t.prototype.messageHandler.call(this, i),
            i.type === P.Close && this.props.onClose();
        }),
        (e.prototype.stateChangeMessageHandler = function (i) {
          this.newStateHasChanges(i) && this.notify(i),
            t.prototype.stateChangeMessageHandler.call(this, i);
        }),
        e
      );
    })(Li),
    Wa = (function (t) {
      ht(e, t);
      function e() {
        return (t !== null && t.apply(this, arguments)) || this;
      }
      return (
        (e.prototype.onConnect = function () {
          return !1;
        }),
        e
      );
    })(Ni),
    Ht = {
      host: function (t) {
        return new Xe(new Ni(t));
      },
      guest: function (t) {
        return new Xe(new Fa(t));
      },
      mitm: function (t) {
        return new Xe(new Wa(t));
      },
      creativeHost: function (t) {
        return new Ga(
          T(
            {
              onClick: function () {},
              onClose: function () {},
              onInVideoReady: function () {},
              onDelivery: function () {},
              onIntervention: function () {},
              onAsset: function () {},
              onCreativeMessage: function () {},
              onExpand: function () {},
            },
            t
          )
        );
      },
      creativeGuest: function (t) {
        return new Xa({
          connector: t.connector,
          onStateChange: t.onChange,
          onClose: t.onClose,
        });
      },
    };
  const ja = [z.InImageRestricted];
  class Qa {
    constructor(e, i, n, s, r, a = {}) {
      u(this, "timeout", 1e3),
        u(this, "connector"),
        u(this, "sentEvents", {}),
        (this.iframe = e),
        (this.adUnitConfig = i),
        (this.productShortCode = n),
        (this.handleEvent = s),
        (this.handleInteractEvent = r),
        (this.features = a),
        (this.connector = Ht.creativeHost({
          connector: Ht.host(this.iframe),
          onClick: () => this.dispatchEvent(me.AdCreativeClick),
          onClose: () => this.dispatchEvent(me.AdClose),
          onStateChange: (d) => {},
          onResize: (d) => this.handleInteractEvent(at.AdCreativeResize, d),
          onCreativeMessage: (d, h) => {
            d === "impression" && this.dispatchEvent(Le.AdCreativeImpression);
          },
        }));
    }
    async connect() {
      return this.connector.connect(this.timeout).then(() => {
        this.connector.slotData({
          sourceType: this.adUnitConfig.sourceType,
          features: {
            fixed:
              this.adUnitConfig.adUnitType === z.InScreen ||
              this.adUnitConfig.adUnitType === z.InBanner,
            adunitType: this.adUnitConfig.adUnitType,
            expandable: this.isExpandable(),
            closeable: this.isCloseable(),
            hideMuteButton: !1,
            productCode: this.productShortCode,
            ...this.features,
          },
        });
      });
    }
    close() {
      this.connector.close();
    }
    setHovered(e) {
      this.connector.hovered(e);
    }
    dispatchEvent(e) {
      this.sentEvents[e] ||
        ((this.sentEvents[e] = !0), this.handleEvent(e, {}));
    }
    isExpandable() {
      return !ja.includes(this.adUnitConfig.adUnitType);
    }
    isCloseable() {
      return (
        this.adUnitConfig.adUnitType !== z.InBanner &&
        !this.adUnitConfig.disableCloseButton
      );
    }
  }
  const $a = (t, e) => {
    switch (`${t}-${e}`) {
      case "1-50":
        return oe.AdViewability1s50;
      case "1-100":
        return oe.AdViewability1s100;
      case "2-50":
        return oe.AdViewability2s50;
      case "3-50":
        return oe.AdViewability3s50;
      default:
        throw new vs();
    }
  };
  class Ya {
    constructor(e, i) {
      u(this, "viewabilityObservers", []),
        u(this, "durationThreshold", [
          [1, 50],
          [1, 100],
          [2, 50],
          [3, 50],
        ]),
        (this.eventHandler = i);
      const n = e.ownerDocument.defaultView;
      this.viewabilityObservers = this.durationThreshold.map(
        ([s, r]) => new Os(e, s, r, n)
      );
    }
    start() {
      this.viewabilityObservers.forEach((e) =>
        e.observe().then(() => {
          const i = $a(e.duration, e.threshold);
          this.eventHandler(i);
        })
      );
    }
    stop() {
      this.viewabilityObservers.forEach((e) => e.unobserve());
    }
  }
  const qa =
      /(^|\.)(adchoices\.com|youradchoices\.(com|ca)|aboutads\.info|evidon\.com|truste\.com|networkadvertising\.org|youronlinechoices\.(com|eu)|edaa\.eu|adssettings\.google\.com)$/i,
    Ka = /adchoices|whythisad|why-this-ad|optout|opt-out|privacy/i,
    Ja = (t) => {
      try {
        const e = new URL(t);
        return qa.test(e.hostname) || Ka.test(e.hostname + e.pathname);
      } catch {
        return !1;
      }
    };
  class Za {
    constructor(e, i) {
      u(this, "counted", !1),
        u(this, "stopped", !1),
        u(this, "windows", []),
        u(this, "documents", []),
        u(this, "cleanups", []),
        u(this, "pendingLinks", []),
        u(this, "onClick", (s) => {
          var r;
          const a = s.target,
            d =
              (r = a == null ? void 0 : a.closest) == null
                ? void 0
                : r.call(a, "a[href], area[href]");
          if (
            !d ||
            !/^https?:/i.test(d.href) ||
            (d.getAttribute("href") || "").startsWith("#") ||
            !s.isTrusted ||
            Ja(d.href)
          )
            return;
          const h = () => {
            (this.pendingLinks = this.pendingLinks.filter((c) => c !== h)),
              s.defaultPrevented || this.count();
          };
          this.pendingLinks.push(h), setTimeout(h, 0);
        }),
        u(this, "onVisibilityChange", () => {
          this.windows[this.windows.length - 1].document.visibilityState ===
            "hidden" && this.onPageLeft();
        }),
        u(this, "onPageLeft", () =>
          this.pendingLinks.slice().forEach((s) => s())
        ),
        (this.iframe = e),
        (this.handleEvent = i);
      let n = e.ownerDocument.defaultView;
      for (; n; ) {
        this.windows.push(n);
        try {
          if (n.parent === n || !n.parent.document) break;
        } catch {
          break;
        }
        n = n.parent;
      }
    }
    start() {
      const e = this.windows[this.windows.length - 1];
      this.listen(e.document, "visibilitychange", this.onVisibilityChange),
        this.listen(e, "pagehide", this.onPageLeft),
        this.watchFrame(this.iframe);
    }
    stop() {
      (this.stopped = !0),
        this.cleanups.forEach((e) => {
          try {
            e();
          } catch {}
        }),
        (this.cleanups = []);
    }
    listen(e, i, n, s = !1) {
      e.addEventListener(i, n, s),
        this.cleanups.push(() => e.removeEventListener(i, n, s));
    }
    watchFrame(e) {
      this.listen(e, "load", () => this.watchDocument(e)),
        this.watchDocument(e);
    }
    watchDocument(e) {
      let i = null;
      try {
        i = e.contentDocument;
      } catch {
        i = null;
      }
      if (!i || this.documents.includes(i)) return;
      this.documents.push(i),
        this.listen(i, "click", (s) => this.onClick(s), !0),
        this.wrapWindowOpen(i.defaultView),
        Array.from(i.getElementsByTagName("iframe")).forEach((s) =>
          this.watchFrame(s)
        );
      const n = new MutationObserver((s) =>
        s.forEach((r) =>
          r.addedNodes.forEach((a) => {
            if (a.nodeType !== Node.ELEMENT_NODE) return;
            const d = a;
            (d.tagName === "IFRAME"
              ? [d]
              : Array.from(d.getElementsByTagName("iframe"))
            ).forEach((h) => this.watchFrame(h));
          })
        )
      );
      n.observe(i, { childList: !0, subtree: !0 }),
        this.cleanups.push(() => n.disconnect());
    }
    wrapWindowOpen(e) {
      if (!e) return;
      const i = this,
        n = e.open,
        s = function (...r) {
          var a, d;
          const h =
              (d = (a = e.navigator) == null ? void 0 : a.userActivation) ==
              null
                ? void 0
                : d.isActive,
            c = n.apply(this, r);
          return c && h !== !1 && i.count(), c;
        };
      (e.open = s),
        this.cleanups.push(() => {
          e.open === s && (e.open = n);
        });
    }
    count() {
      this.counted ||
        this.stopped ||
        ((this.counted = !0), this.stop(), this.handleEvent(x.AdClick));
    }
  }
  class eo extends Ds {
    constructor(e, i, n) {
      super(),
        u(this, "adUnitContainer"),
        u(this, "stPlacement"),
        u(this, "adUnit"),
        u(this, "initiated", !1),
        u(this, "globalCustomDimensions", {}),
        u(this, "viewabilityService"),
        u(this, "clickDetector"),
        (this.container = e),
        (this.adUnitConfig = i),
        (this.bidResponse = n);
      const s = ` .st-placement, .st-placement .st-reset, .st-placement iframe { all: revert; } `,
        r = document.createElement("style");
      (r.innerHTML = s),
        this.container.appendChild(r),
        (this.stPlacement = document.createElement("div")),
        (this.stPlacement.className = `st-placement ${i.adUnitType} ${i.adUnitName}`),
        (this.stPlacement.id = i.adUnitName),
        (this.stPlacement.style.display = "block"),
        (this.stPlacement.style.width = "100%"),
        (this.stPlacement.style.height = "100%"),
        (this.stPlacement.style.pointerEvents = "none"),
        (this.adUnitContainer = document.createElement("div")),
        (this.adUnitContainer.className = `st-adunit st-adunit-tagged st-adunit-${i.adUnitType.toLowerCase()} st-reset st-show goku`),
        this.adUnitContainer.setAttribute("data-testid", "adunit"),
        (this.adUnitContainer.style.display = "block"),
        (this.adUnitContainer.style.width = "100%"),
        (this.adUnitContainer.style.height = "100%"),
        (this.adUnitContainer.style.position = "relative"),
        (this.adUnitContainer.style.pointerEvents = "none"),
        this.stPlacement.appendChild(this.adUnitContainer),
        this.container.appendChild(this.stPlacement);
      const a = new Ba(
        this.adUnitContainer,
        this.handleEvent.bind(this),
        this.adUnitConfig,
        this.bidResponse
      );
      this.adUnit = a.createAdUnit();
    }
    async init() {
      if (this.initiated) throw new ps();
      return (this.initiated = !0), this.adUnit.init().then(() => this.adUnit);
    }
    async destroy() {
      return this.adUnit.destroy().then(() => {
        var e, i;
        this.clearEventListeners(),
          (e = this.viewabilityService) == null || e.stop();
        try {
          (i = this.clickDetector) == null || i.stop();
        } catch {}
        this.stPlacement.remove();
      });
    }
    subscribeAll(e) {
      Object.values(me).forEach((i) => {
        this.addEventListener(i, e);
      });
    }
    dispatchEvent(e, i) {
      const n = this.getAdUnitSizeDimensions();
      this.globalCustomDimensions = {
        ...this.globalCustomDimensions,
        ...i,
        ...n,
      };
      const s = { name: e, customDimensions: this.globalCustomDimensions };
      super.dispatchEvent(e, s);
    }
    handleEvent(e, i = {}) {
      e === x.AdIframeReady &&
        (ri(this.bidResponse.productShortCode) ||
          as(this.bidResponse.productShortCode)) &&
        this.connectMinipass(),
        e === x.AdIframeReady &&
          !this.clickDetector &&
          rs(this.bidResponse.productShortCode) &&
          ((this.clickDetector = new Za(
            this.adUnit.getAdIframe(),
            this.handleEvent.bind(this)
          )),
          this.clickDetector.start()),
        this.bidResponse.productType === V.DISPLAY &&
          e === me.AdCreativeClick &&
          this.dispatchEvent(x.AdClick, i),
        ((e === x.AdIframeReady && this.bidResponse.productType !== V.VIDEO) ||
          (e === x.AdView && this.bidResponse.productType === V.VIDEO)) &&
          this.initViewabilityService(),
        this.dispatchEvent(e, i);
    }
    connectMinipass() {
      const e = this.adUnit.getAdIframe(),
        i = new Qa(
          e,
          this.adUnitConfig,
          this.bidResponse.productShortCode,
          this.handleEvent.bind(this),
          (n, s) => this.handleMiniPassInteractEvent(n, s)
        );
      (i.timeout = 2e3),
        i.connect().then(() => this.handleEvent(Le.MinipassConnected)),
        this.handleMiniPassMouseEvents(i);
    }
    handleMiniPassMouseEvents(e) {
      var i;
      if (this.adUnitConfig.adUnitType === z.InImage) {
        const n =
          (i = this.container.parentElement) == null
            ? void 0
            : i.querySelector(":scope > img");
        n &&
          (n.addEventListener("mouseenter", () => e.setHovered(!0)),
          n.addEventListener("mouseleave", () => e.setHovered(!1)));
      }
      this.container.addEventListener("mouseenter", () => e.setHovered(!0)),
        this.container.addEventListener("mouseleave", () => e.setHovered(!1));
    }
    handleMiniPassInteractEvent(e, i) {
      e === at.AdCreativeResize &&
        i &&
        i.height !== 600 &&
        this.adUnit.resize(i);
    }
    getAdUnitSizeDimensions() {
      if (this.adUnit.getAdContainer()) {
        const { height: e, width: i } = this.adUnit
          .getAdContainer()
          .getBoundingClientRect();
        return { adunitHeight: Math.round(e), adunitWidth: Math.round(i) };
      }
    }
    initViewabilityService() {
      var e;
      const i = (e = this.adUnit) == null ? void 0 : e.getAdContainer();
      if (!i) throw new gs();
      (this.viewabilityService = new Ya(i, this.handleEvent.bind(this))),
        this.viewabilityService.start();
    }
  }
  class to {
    constructor(e, i) {}
    disconnect() {}
    observe(e, i) {}
    unobserve(e) {}
  }
  function io(t) {
    try {
      return new ResizeObserver(t);
    } catch {
      return new to(t);
    }
  }
  class no {
    constructor() {
      g(this, "firstTime", !1);
      g(this, "observer");
    }
    observe(e, i) {
      (this.observer = io((n) => this.onResize(n, i))),
        this.observer.observe(e);
    }
    onResize(e, i) {
      for (const n of e)
        n.contentRect &&
          (this.firstTime ? i(n.contentRect) : (this.firstTime = !0));
    }
    disconnect() {
      var e;
      (e = this.observer) == null || e.disconnect();
    }
  }
  const so = 2e3,
    ro = 0.5;
  class ao {
    constructor(e, i = 5, n = 1e4) {
      g(this, "intervalId", null);
      (this.topWindow = e),
        (this.precision = i),
        (this.checkIntervalSeconds = n);
    }
    start(e, i) {
      this.intervalId = this.topWindow.setInterval(() => {
        this.isOverlaid(e, this.precision) && (i(), this.stop());
      }, this.checkIntervalSeconds);
    }
    stop() {
      this.intervalId && this.topWindow.clearInterval(this.intervalId);
    }
    isOverlaid(e, i) {
      if (!e || !e.getBoundingClientRect) return !1;
      const n = e.getBoundingClientRect(),
        s = n.width / (i + 1),
        r = n.height / (i + 1);
      for (let a = 1; a <= i; a++)
        for (let d = 1; d <= i; d++) {
          const h = n.left + s * a,
            c = n.top + r * d,
            v = this.topWindow.document.elementFromPoint(h, c);
          if (v && v !== e && !e.contains(v)) return !0;
        }
      return !1;
    }
  }
  function gt(t) {
    const e = Gi(t.productShortCode);
    return {
      mediaType: Fi(t.productType),
      channel: t.productMarket,
      size: `${t.width}x${t.height}`,
      channelId: t.ch,
      productFamily: Xi(e),
      requestId: t.requestId,
    };
  }
  class oo {
    constructor(e, i, n, s, r, a) {
      g(this, "adUnitRender");
      g(this, "resizeService");
      g(this, "overlayDetectorService");
      (this.container = e),
        (this.bidResponse = i),
        (this.adUnitConfig = n),
        (this.eventBus = s),
        (this.lazyInsertService = r),
        (this.window = a);
      const d = ne(this.window);
      (this.overlayDetectorService = new ao(d)),
        (this.resizeService = new no()),
        (this.adUnitRender = this.createAdUnitRender());
      const h = gt(this.bidResponse);
      this.adUnitRender.subscribeAll(({ name: c, customDimensions: v }) => {
        const { vastErrorContext: p, ...f } = v || {};
        this.eventBus.dispatchEvent(c, { ...f, ...h });
      });
    }
    async render() {
      await this.adUnitRender
        .init()
        .then((e) => this.onAdUnitRenderInit(e))
        .then((e) => e.render())
        .catch((e) => {
          throw (this.destroy(), e);
        });
    }
    async destroy() {
      this.resizeService.disconnect(),
        this.overlayDetectorService.stop(),
        await this.adUnitRender.destroy();
    }
    onAdUnitRenderInit(e) {
      const i = e.getAdContainer();
      if (
        (this.shouldStartOverlayDetectorService() &&
          this.overlayDetectorService.start(i, () =>
            this.eventBus.dispatchEvent(Gt.AdOverlay)
          ),
        this.resizeService.observe(this.container, () => e.redraw()),
        this.lazyInsertService.haveLazyInsert(this.bidResponse))
      ) {
        const n = this.window.setTimeout(
          () => this.eventBus.dispatchEvent(ve.LazyInsertNotReady),
          so
        );
        return this.lazyInsertService
          .onReadyToInsert(i, this.bidResponse)
          .then(
            () => (
              this.window.clearTimeout(n),
              this.eventBus.dispatchEvent(ve.LazyInsert),
              e
            )
          );
      }
      return Promise.resolve(e);
    }
    createAdUnitRender() {
      return new eo(this.container, this.adUnitConfig, this.bidResponse);
    }
    shouldStartOverlayDetectorService() {
      return (
        !this.adUnitConfig.isEmbedInIframe &&
        this.adUnitConfig.adUnitType === D.InScreen
      );
    }
  }
  const ho = (t, e) => {
      switch (t) {
        case ge.AdViewability1s50:
          return e.adview_1s50 || [];
        case ge.AdViewability1s100:
          return e.adview_1s100 || [];
        case ie.AdClick:
          return e.clicks || [];
        case ie.AdView:
          return e.imps || [];
        default:
          return [];
      }
    },
    co = [
      "1178-4918-01",
      "4333-4565-01",
      "3159-4546-01",
      "9631-2047-01",
      "9665-1959-01",
      "0516-9426-01",
      "9312-2431-01",
      "7633-7127-01",
      "8993-5121-01",
      "0271-1081-01",
      "6988-2846-01",
      "7006-5384-01",
      "5385-2836-01",
      "5643-7650-01",
      "6106-5797-01",
      "9437-6435-01",
      "0996-5921-01",
      "1181-7301-01",
      "1223-2776-01",
      "7328-9303-01",
      "0418-5137-01",
      "2901-7092-01",
      "7196-4208-01",
      "9426-8736-01",
      "6097-4082-01",
      "5993-0347-01",
      "9427-3648-01",
      "4614-3701-01",
      "4904-4202-01",
      "2194-6712-01",
      "3071-2212-01",
      "1959-9865-01",
      "1657-0318-01",
      "3504-2659-01",
      "2221-1442-01",
      "3619-0044-01",
      "9604-3373-01",
      "5099-5208-01",
      "0667-1332-01",
      "6981-9794-01",
      "0401-1865-01",
      "1256-1486-01",
      "8258-6233-01",
      "4069-3858-01",
      "6291-7904-01",
      "3687-9918-01",
      "5796-5449-01",
      "6428-9003-01",
      "6049-0013-01",
      "5124-1948-01",
      "5131-7872-01",
      "0645-8728-01",
      "0004-1229-01",
      "1927-7414-01",
      "3140-7724-01",
      "2729-5154-01",
      "1276-7921-01",
      "2070-1664-01",
      "5930-0788-01",
      "9491-7233-01",
      "9686-7043-01",
      "0204-3888-01",
      "0922-2163-01",
      "9827-7170-01",
      "6710-5059-01",
      "8188-1778-01",
      "4828-1583-01",
      "7759-8383-01",
      "6274-3610-01",
      "8312-4271-01",
      "7095-6588-01",
      "1975-0019-01",
      "7962-3932-01",
      "0203-4610-01",
      "1503-8651-01",
      "6698-1701-01",
      "8642-0717-01",
      "8689-6021-01",
      "2837-7979-01",
      "1010-7304-01",
      "0509-8134-01",
    ],
    lo = ["9066-0726-01", "8692-0127-01", "9773-2169-01", "6221-4136-01"];
  class uo {
    constructor(e, i) {
      g(this, "forceDisableCloseButtonTokens", co);
      g(this, "inAppLazyInsertAnyPixelTokens", lo);
      (this.token = e), (this.adunitType = i);
    }
    setForceDisableCloseButtonTokens(e) {
      this.forceDisableCloseButtonTokens = e;
    }
    setInAppLazyInsertAnyPixelTokens(e) {
      this.inAppLazyInsertAnyPixelTokens = e;
    }
    isInAppLazyInsertAnyPixel() {
      return this.inAppLazyInsertAnyPixelTokens.indexOf(this.token) > -1;
    }
    isCloseButtonDisabled() {
      return this.adunitType === D.InScreen
        ? this.forceDisableCloseButtonTokens.indexOf(this.token) > -1
        : !1;
    }
  }
  const po = (t, e) => {
      try {
        const i = t || "return";
        return new e.Function("event", `try {${i}} catch(e) {}`);
      } catch {
        return () => {};
      }
    },
    go = (t, e) => {
      try {
        if (!t) return;
        const i = e.document.createElement("style");
        return (
          (i.innerHTML = t),
          e.document.body.appendChild(i),
          e.addEventListener("pagehide", () => {
            var s;
            try {
              (s = e == null ? void 0 : e.document) != null &&
                s.body &&
                e.document.body.removeChild(i);
            } catch {}
          }),
          i
        );
      } catch {}
    };
  class vo {
    constructor(e, i, n) {
      g(this, "containerStyles");
      g(this, "publisherEventCallback");
      (this.publisherEvents = e),
        (this.publisherStyles = i),
        (this.window = n),
        (this.publisherEventCallback = po(this.publisherEvents, this.window)),
        (this.containerStyles = go(this.publisherStyles, this.window));
    }
    destroy() {
      var e;
      (e = this.containerStyles) == null || e.remove();
    }
    registerEventBus(e) {
      e.subscribeAll((i) => {
        this.publisherEventCallback(i);
      });
    }
  }
  class mo {
    constructor(e, i, n, s) {
      g(this, "topWindow");
      g(this, "adUnitRenderInitializer");
      g(this, "eventPayload", {});
      g(this, "pageHideCallback");
      g(this, "isEmbedInIframe");
      g(this, "containerSize");
      g(this, "container");
      g(this, "sspResponseType");
      g(this, "bidResponses", []);
      g(this, "publisherService");
      g(this, "window");
      g(this, "useSrcdoc", !1);
      (this.eventService = e),
        (this.config = i),
        (this.sourceType = n),
        (this.containerManager = s),
        (this.window = this.containerManager.getWindow()),
        (this.topWindow = ne(this.window)),
        (this.container = this.containerManager.getContainer()),
        (this.containerSize = this.containerManager.getContainerSize()),
        (this.isEmbedInIframe = this.containerManager.isEmbedInIframe()),
        (this.publisherService = new vo(
          this.config.publisherEvents,
          this.config.publisherStyles,
          this.topWindow
        )),
        (this.pageHideCallback = this.onPageHide),
        this.window.addEventListener("pagehide", () => this.pageHideCallback());
    }
    async stop() {
      await this.clearRenderedAd();
    }
    getEventPayload() {
      return this.eventPayload;
    }
    async initAdUnitRender(e, i) {
      i.subscribeAll((s) => {
        var r;
        ho(s.name, e.trackers).forEach((a) => ts(a, this.window.document)),
          s.name === ie.AdView &&
            (r = e == null ? void 0 : e.trackers) != null &&
            r.jsTrackers &&
            e.trackers.jsTrackers.length > 0 &&
            e.trackers.jsTrackers.forEach((a) => {
              const d = is(a, this.window.document);
              d &&
                this.eventService.reportErrorEvent(d, this.getEventPayload());
            });
      }),
        i.addEventListener(ie.AdClose, ({ adUnitType: s }) => {
          var r, a;
          s === D.InTop &&
            ((r = this.inTopResizeService) == null || r.removeResize()),
            s === D.InArticle &&
              ((a = this.inArticleResizeService) == null || a.removeResize()),
            this.stop();
        });
      const n = {
        adUnitType: this.config.adunitType,
        adUnitName: this.config.adunitName,
        containerSize: this.containerSize,
        isEmbedInIframe: this.isEmbedInIframe,
        sourceType: this.sourceType,
        disableCloseButton: this.isCloseButtonDisabled(),
        adUnitMaxHeight: this.config.adunitMaxHeight,
        videoArea30: this.config.videoArea30,
        useSrcdoc: this.useSrcdoc,
      };
      (this.adUnitRenderInitializer = new oo(
        this.container,
        e,
        n,
        i,
        this.lazyInsertService,
        this.window
      )),
        this.adUnitRenderInitializer.adUnitRender.addEventListener(
          Ee.VideoError,
          ({ customDimensions: s }) => {
            this.reportVastError(e, s);
          }
        ),
        this.applyAdUnitResizes(e),
        await this.adUnitRenderInitializer.render();
    }
    reportVastError(e, i) {
      const n = gt(e),
        s = this.eventService.getPayload(),
        { vastErrorContext: r, ...a } = i || {};
      if (!r) return;
      const { message: d, ...h } = r,
        c = { ...a, ...n };
      Vn({
        errorCode: c.errorCode,
        errorType: c.errorType,
        message: d,
        context: h,
        sourceType: s.sourceType,
        token: s.token,
        adUnitType: this.config.adunitType || c.adUnitType,
        channel: c.channel,
        browser: s.browser,
        device: s.device,
        os: s.os,
        country: s.publisherCountry,
        version: s.version,
        url: s.url,
      });
    }
    applyAdUnitResizes(e) {
      this.config.adunitType === D.InArticle &&
        this.inArticleResizeService.resize(e),
        this.config.adunitType === D.InTop && this.inTopResizeService.resize(e),
        this.config.adunitType === D.InTerstitial &&
          this.inTerstitialResizeService.resize(e);
    }
    async onPageHide() {
      this.publisherService.destroy(), await this.stop();
    }
    async clearRenderedAd() {
      this.adUnitRenderInitializer &&
        (await this.adUnitRenderInitializer.destroy(),
        (this.adUnitRenderInitializer = void 0));
    }
    isCloseButtonDisabled() {
      const e = new uo(this.config.publisherToken, this.config.adunitType),
        i = Un(this.window),
        n = this.config.adunitType === D.InTerstitial;
      return e.isCloseButtonDisabled() || i || n;
    }
  }
  class fo {
    constructor(e, i, n) {
      g(this, "container");
      g(this, "_isEmbedInIframe", !1);
      g(this, "getContainer", () => this.container);
      g(this, "getContainerSize", () => this.containerSize);
      g(this, "isEmbedInIframe", () => this._isEmbedInIframe);
      g(this, "getWindow", () => this.window);
      g(this, "destroy", () => {});
      (this.hbConfig = e),
        (this.containerSize = i),
        (this.window = n),
        (this._isEmbedInIframe = this.calculateIsEmbedInIframe()),
        (this.container = this.initContainer());
    }
    initContainer() {
      switch (this.hbConfig.adunitType) {
        case D.InBanner:
        case D.InArticle:
        case D.InTop:
          return this.window.document.body;
        case D.InTerstitial:
        case D.InScreen:
        case D.InSkin:
          return this._isEmbedInIframe
            ? this.window.document.body
            : ne(this.window).document.body;
        default:
          throw new $i();
      }
    }
    calculateIsEmbedInIframe() {
      return this.hbConfig.adunitType === D.InTerstitial
        ? !this.hbConfig.interstitialSeedtagTemplate
        : this.hbConfig.insertInsideIframe || ye(this.window) || un();
    }
  }
  class Ao extends Fn {
    constructor(e) {
      super(), (this.getEventPayload = e);
    }
    dispatchEvent(e, i = {}) {
      const n = { ...this.getEventPayload(), ...i, name: e };
      super.dispatchEvent(e, n);
    }
    subscribeAll(e) {
      Object.values(Gt).forEach((i) => {
        this.addEventListener(i, e);
      });
    }
  }
  const zi = "google_ads_iframe",
    vt = (t) => {
      const e = Eo(t);
      if (!e) return { googleDiv: void 0, googleIframe: void 0 };
      const i = e.parentElement;
      return (i == null ? void 0 : i.tagName) === "DIV" && i.id.includes(zi)
        ? { googleDiv: i, googleIframe: e }
        : { googleDiv: void 0, googleIframe: void 0 };
    },
    Eo = (t) => {
      var i, n;
      let e =
        (i = t.ownerDocument.defaultView) == null ? void 0 : i.frameElement;
      for (; e; ) {
        if (e.id.includes(zi)) return e;
        e = (n = e.ownerDocument.defaultView) == null ? void 0 : n.frameElement;
      }
      return e;
    },
    yo = 100,
    bo = 150,
    Ie = "st-intop-custom";
  class wo {
    constructor(e, i, n) {
      g(this, "googleDiv");
      g(this, "googleIframe");
      (this.container = e), (this.containerSize = i), (this.window = n);
      let { googleDiv: s, googleIframe: r } = vt(this.container);
      (this.googleDiv = s), (this.googleIframe = r);
    }
    resize(e) {
      if (!this.googleIframe || !this.googleDiv) return;
      const i = this.getHeight(e.productShortCode),
        n = this.getWidth();
      (this.containerSize.width = n), (this.containerSize.height = i);
      const s = this.getStyleTag(i, n);
      s && (this.googleDiv.appendChild(s), this.googleDiv.classList.add(Ie));
    }
    removeResize() {
      if (!this.googleIframe || !this.googleDiv) return;
      const e = this.getStyleTag(0, 0);
      e && (this.googleDiv.appendChild(e), this.googleDiv.classList.add(Ie));
    }
    getStyleTag(e, i) {
      if (!this.googleIframe || !this.googleDiv) return;
      const n = this.window.document.createElement("style");
      return (
        (n.innerHTML = ` .${Ie}{ height: ${e}px !important; width: ${i}px !important;} .${Ie} iframe { transform: none !important; transform-origin: unset !important; height:${e}px !important; width:${i}px !important; } `),
        n
      );
    }
    getHeight(e) {
      return ke(e) ? bo : yo;
    }
    getWidth() {
      return ne(this.window).innerWidth;
    }
  }
  const De = (t, e, i) => {
    t.setAttribute(e, i.toString()),
      (t.style[e] = i.toString() + "px"),
      (t.style.margin = "0 auto");
  };
  class Co {
    constructor(e, i, n, s) {
      g(this, "googleDiv");
      g(this, "googleIframe");
      g(this, "parentIframe");
      var d;
      (this.container = e),
        (this.containerSize = i),
        (this.insertInsideIframe = n),
        (this.window = s);
      let { googleDiv: r, googleIframe: a } = vt(this.container);
      (this.googleDiv = r),
        (this.googleIframe = a),
        (this.parentIframe =
          (d = this.container.ownerDocument.defaultView) == null
            ? void 0
            : d.frameElement);
    }
    resize(e) {
      if (
        !this.googleIframe ||
        !this.googleDiv ||
        (this.isInsideInsTag() && !ke(e.productShortCode))
      )
        return;
      const i = this.getNewGoogleIframeSize(e.productShortCode);
      (this.containerSize.width = i.width),
        (this.containerSize.height = i.height),
        this.setGoogleIframeSize("height", i.height),
        this.setGoogleIframeSize("width", i.width),
        this.isInsideInsTag() &&
          this.parentIframe &&
          ((this.parentIframe.style.height = `${this.containerSize.height}px`),
          (this.parentIframe.style.width = `${this.containerSize.width}px`));
    }
    removeResize() {}
    setGoogleIframeSize(e, i) {
      this.googleIframe &&
        (De(this.googleIframe, e, i),
        this.googleDiv && De(this.googleDiv, e, i));
    }
    getNewGoogleIframeSize(e) {
      return this.insertInsideIframe
        ? ke(e)
          ? {
              height: this.getFullScreenHeight(),
              width: this.getFullScreenWidth(),
            }
          : {
              height: this.containerSize.height,
              width: this.containerSize.width,
            }
        : { height: 1, width: 1 };
    }
    getFullScreenHeight() {
      return ne(this.window).innerHeight;
    }
    getFullScreenWidth() {
      return ne(this.window).innerWidth;
    }
    isInsideInsTag() {
      var e;
      try {
        return this.googleDiv
          ? ((e = this.googleDiv.parentElement) == null
              ? void 0
              : e.tagName) === "INS"
          : !1;
      } catch {
        return !1;
      }
    }
  }
  const So = 587;
  class Io {
    constructor(e, i, n, s) {
      g(this, "googleDiv");
      g(this, "googleIframe");
      g(this, "shouldResize16_9GoogleIframe", (e) => (je() && ke(e)) || ji(e));
      g(
        this,
        "shouldResizeViewport55",
        (e) => Yt() && (e == We.CID || e == We.CBV)
      );
      g(
        this,
        "shouldResize",
        (e) =>
          this.shouldResize16_9GoogleIframe(e) || this.shouldResizeViewport55(e)
      );
      (this.container = e),
        (this.containerSize = i),
        (this.topWindow = n),
        (this.adUnitMaxHeight = s);
      let { googleDiv: r, googleIframe: a } = vt(this.container);
      (this.googleDiv = r), (this.googleIframe = a);
    }
    resize(e) {
      ye(this.topWindow)
        ? this.expandInArticle(e.height)
        : this.shouldResize(e.productShortCode) &&
          (this.shouldResize16_9GoogleIframe(e.productShortCode)
            ? this.resizeGoogleContainerTo169AspectRatio()
            : this.shouldResizeViewport55(e.productShortCode) &&
              (this.resizeGoogleContainerToViewport55(this.topWindow),
              this.resizeGoogleContainerToParagraphWidth()),
          this.setIntermediatesIframeSize(),
          this.setParentElementHeightToAuto()),
        this.resizeIframeToTheParentSize();
    }
    removeResize() {
      this.setGoogleIframeSize("height", 0),
        this.setGoogleIframeSize("width", 0);
    }
    resizeGoogleContainerToViewport55(e) {
      if (this.googleDiv && this.googleIframe) {
        const i = this.adUnitMaxHeight || e.innerHeight * 0.55;
        (this.containerSize.height = i), this.setGoogleIframeSize("height", i);
      }
    }
    resizeGoogleContainerToParagraphWidth() {
      if (this.googleDiv) {
        const e = this.getParagraphWidth(this.googleDiv);
        e &&
          ((this.containerSize.width = e),
          this.setGoogleIframeSize("width", e));
      }
    }
    resizeGoogleContainerTo169AspectRatio() {
      this.googleDiv &&
        this.googleIframe &&
        (je()
          ? ((this.containerSize.width = So),
            this.setGoogleIframeSize("width", this.containerSize.width))
          : this.resizeGoogleContainerToParagraphWidth(),
        (this.containerSize.height =
          this.adUnitMaxHeight || this.containerSize.width / (16 / 9)),
        this.setGoogleIframeSize("height", this.containerSize.height));
    }
    resizeIframeToTheParentSize() {
      let e = !1;
      if (
        this.googleDiv &&
        this.googleDiv.parentElement &&
        this.googleDiv.parentElement.clientHeight !== 0
      ) {
        if (
          this.googleDiv.parentElement.clientHeight < this.containerSize.height
        ) {
          const i = this.googleDiv.parentElement.clientHeight;
          (this.containerSize.height = i),
            this.setGoogleIframeSize("height", i),
            (e = !0);
        }
        if (
          this.googleDiv.parentElement.clientWidth !== 0 &&
          this.googleDiv.parentElement.clientWidth < this.containerSize.width
        ) {
          const i = this.googleDiv.parentElement.clientWidth;
          (this.containerSize.width = i),
            this.setGoogleIframeSize("width", i),
            (e = !0);
        }
      }
      return e;
    }
    setIntermediatesIframeSize() {
      var e;
      if (this.googleIframe) {
        let i =
          (e = this.container.ownerDocument.defaultView) == null
            ? void 0
            : e.frameElement;
        try {
          for (
            ;
            i !== this.googleIframe &&
            (i == null ||
              i.setAttribute("height", this.containerSize.height.toString()),
            i == null ||
              i.setAttribute("width", this.containerSize.width.toString()),
            i == null ||
              i.style.setProperty(
                "height",
                this.containerSize.height.toString() + "px"
              ),
            i == null ||
              i.style.setProperty(
                "width",
                this.containerSize.width.toString() + "px"
              ),
            !!i.parentElement);

          )
            i = i.parentElement;
        } catch {}
      }
    }
    setParentElementHeightToAuto(e = this.googleDiv) {
      try {
        e &&
          e.parentElement &&
          (e.parentElement.clientHeight < this.containerSize.height &&
            (e.parentElement.style.height = "auto"),
          this.setParentElementHeightToAuto(e.parentElement));
      } catch {}
    }
    setGoogleIframeSize(e, i) {
      this.googleIframe &&
        (De(this.googleIframe, e, i),
        this.googleDiv && De(this.googleDiv, e, i));
    }
    expandInArticle(e) {
      var i;
      (i = this.topWindow.$sf) == null ||
        i.ext.expand({ b: e, l: 0, push: !1, r: 0, t: 0 });
    }
    getParagraphWidth(e) {
      var i, n, s, r;
      if (
        ((i = e.previousElementSibling) == null ? void 0 : i.tagName) === "P" ||
        ((n = e.previousElementSibling) == null ? void 0 : n.tagName) ===
          "ARTICLE"
      )
        return e.previousElementSibling.clientWidth;
      if (
        ((s = e.parentElement) == null ? void 0 : s.tagName) === "P" ||
        ((r = e.parentElement) == null ? void 0 : r.tagName) === "ARTICLE"
      )
        return e.parentElement.clientWidth;
      if (e.parentElement) return this.getParagraphWidth(e.parentElement);
    }
  }
  class To {
    constructor(e) {
      this.window = e;
    }
    haveLazyInsert(e) {
      return e.lazyInsert;
    }
    onReadyToInsert(e, i) {
      return new _n(e, 0.001, ro, this.window).observe();
    }
  }
  class Vo extends mo {
    constructor(i, n, s, r) {
      const a = { width: n.pbjsSize[0], height: n.pbjsSize[1] },
        d = new fo(n, a, r);
      super(i, n, n.sourceType, d);
      g(this, "inTopResizeService");
      g(this, "inTerstitialResizeService");
      g(this, "inArticleResizeService");
      g(this, "lazyInsertService");
      (this.eventService = i),
        (this.hbConfig = n),
        (this.hbResponse = s),
        (this.window = r),
        this.updateEventsPayload(),
        (this.sspResponseType = this.hbConfig.sspResponseType),
        (this.inArticleResizeService = new Io(
          this.container,
          this.containerSize,
          this.topWindow,
          this.hbConfig.adunitMaxHeight
        )),
        (this.inTerstitialResizeService = new Co(
          this.container,
          this.containerSize,
          this.hbConfig.insertInsideIframe,
          this.window
        )),
        (this.inTopResizeService = new wo(
          this.container,
          this.containerSize,
          this.window
        )),
        (this.lazyInsertService = new To(this.window)),
        this.eventService.reportEvent(Me.ClientReady, this.eventPayload);
    }
    async start(i) {
      const n = new Ao(() => this.eventPayload);
      if (
        (n.subscribeAll((r) => this.eventService.reportEvent(r.name, r)),
        this.publisherService.registerEventBus(n),
        n.dispatchEvent(pe.AdRequest),
        (this.bidResponses = i || this.hbResponse),
        this.bidResponses.length === 0)
      )
        return;
      const s = gt(this.hbResponse[0]);
      n.dispatchEvent(pe.AdResolve, s),
        this.sspResponseType === Wt.BACKUP &&
          this.bidResponses.length > 1 &&
          n.addEventListener(Ee.VideoError, () => {
            const r = this.bidResponses.slice(1);
            this.start(r).catch((a) =>
              this.eventService.reportErrorEvent(a, this.getEventPayload())
            );
          }),
        await this.clearRenderedAd(),
        await this.initAdUnitRender(this.bidResponses[0], n);
    }
    updateEventsPayload() {
      this.eventService.updatePayload({
        token: this.hbConfig.publisherToken,
        connectionType: this.hbConfig.userConnectionType,
        eventChunk: this.hbConfig.eventChunk,
        sourceType: this.hbConfig.sourceType,
        os: this.hbConfig.os,
        browser: this.hbConfig.browser,
        device: this.hbConfig.device,
        publisherInventoryType: _t.WEB,
      }),
        (this.eventPayload = {
          adUnitName: this.hbConfig.adunitName,
          adUnitType: this.hbConfig.adunitType,
          adUnitId: this.hbConfig.adunitId,
          adunitRatio: this.hbConfig.adunitRatio,
          adunitScreenRatioY: this.hbConfig.adunitScreenRatioY,
          adunitFoundPosition: this.hbConfig.adunitFoundPosition,
          sspResponseType: this.hbConfig.sspResponseType,
          transactionId: this.hbConfig.transactionId,
          supplyType: this.hbConfig.supplyType,
          videoMimeType: this.hbConfig.videoMimeType,
          firstRequest: this.hbConfig.firstRequest,
          rc: this.hbConfig.requestCount,
        });
    }
  }
  const xo = (t) => t.hbResponse,
    Po = es(window, jt.HeaderBidding);
  let ce = new qn(Po, window);
  const Te = {};
  try {
    const t = xo(window);
    if (!t) throw new Qi();
    const e = t.hbConfig.sourceType,
      i = t.hbConfig.publisherToken;
    ce.updatePayload({ token: i, sourceType: e }),
      (Te.adUnitId = t.hbConfig.adunitId),
      (Te.adUnitType = t.hbConfig.adunitType),
      ce.reportEvent(Me.ScriptLoaded, Te);
    const n = new Vo(ce, t.hbConfig, t.bidResponses, window);
    n.start().catch((s) => ce.reportErrorEvent(s, n.getEventPayload()));
  } catch (t) {
    ce.reportErrorEvent(t, Te);
  }
})();
