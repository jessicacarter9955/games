(() => {
  var r,
    s = 110615,
    F =
      (((R = r = r || {})[(R.Error = 0)] = "Error"),
      (R[(R.Warning = 1)] = "Warning"),
      (R[(R.Debug = 2)] = "Debug"),
      [
        "color: #fff;",
        "background: #ff8f1c;",
        "display: inline-block;",
        "padding: 1px 4px;",
        "border-radius: 3px;",
      ].join(" ")),
    d =
      ((o.Log = function (e, t) {
        var n;
        o.LOGLEVEL < e ||
          ((e = r[e].toUpperCase()),
          (n =
            0 < (n = window.navigator.userAgent).indexOf("MSIE ") ||
            0 < n.indexOf("Trident/")),
          window.console &&
            (n
              ? console.log("[PubTag] ".concat(e, ": %O"), t)
              : console.log("%cPubTag", F, "".concat(e, ": %O"), t)));
      }),
      (o.Debug = function (e) {
        o.Log(r.Debug, e);
      }),
      (o.Warning = function (e) {
        o.Log(r.Warning, e);
      }),
      (o.Error = function (e) {
        o.Log(r.Error, e);
      }),
      (o.LOGLEVEL = r.Error),
      o);
  function o() {}
  (e.getHighestAccessibleWindow = function (e) {
    var t = e,
      n = !1;
    try {
      for (; t.parent.document !== t.document; ) {
        if (!t.parent.document) {
          n = !0;
          break;
        }
        t = t.parent;
      }
    } catch (e) {
      n = !0;
    }
    return { topFrame: t, err: n };
  }),
    (e.getHighestAccessibleUrl = function (e) {
      var t,
        n = e.topFrame;
      if (!e.err) return n.location.href;
      try {
        var o = null == (t = n.top) ? void 0 : t.location.href;
        if (o) return o;
      } catch (e) {}
      try {
        var r = n.location.ancestorOrigins;
        if (r) return r[r.length - 1];
      } catch (e) {}
      return n.document.referrer;
    }),
    (e.inIframe = function () {
      try {
        return window.self !== window.top;
      } catch (e) {
        return !0;
      }
    });
  var i = e;
  function e() {}
  function a(e) {
    try {
      return JSON.parse(e);
    } catch (e) {}
  }
  ((R = u = u || {}).LOADED = "tcloaded"),
    (R.UI_SHOWN = "cmpuishown"),
    (R.USER_ACTION_COMPLETE = "useractioncomplete"),
    (t.prototype.getCMPFrame = function () {
      for (var e, t = this.currentWindow, n = 0; n < 10; ++n) {
        try {
          t.frames.__tcfapiLocator && (e = t);
        } catch (e) {}
        if (t === this.currentWindow.top) break;
        t = t.parent;
      }
      return e;
    }),
    (t.prototype.hasCallerFunctionInFrame = function () {
      return "function" == typeof this.currentWindow.__tcfapi;
    }),
    (t.prototype.readyToRetrieve = function () {
      return this.hasCallerFunctionInFrame() || void 0 !== this.getCMPFrame();
    }),
    (t.prototype.pingWithTimeout = function (n, e, t, o) {
      function r(e, t) {
        i.logger(t), clearTimeout(e), o();
      }
      var i = this;
      return window.setTimeout(function () {
        var t = window.setTimeout(function () {
          r(
            n,
            "Timeout: Unable to get TCFv2 ping return after ".concat(e, "ms")
          );
        }, e);
        i.executeCommand("ping", 2, function (e) {
          clearTimeout(t),
            i.logger("TCFv2 CMP ping returned in ms"),
            "error" === e.cmpStatus
              ? r(n, "Error status on ping to TCFv2 CMP")
              : !0 !== e.cmpLoaded
              ? r(n, "TCFv2 ping returned cmpLoaded = false")
              : i.logger("TCFv2 ping returned cmpLoaded = true");
        });
      }, t);
    }),
    (t.prototype.retrieveConsent = function (n) {
      var o,
        r,
        i = this,
        s = !1,
        a = window.setTimeout(function () {
          (s = !0),
            r === u.UI_SHOWN
              ? (i.logger(
                  "Timeout: User hasn't confirm their consent settings after ".concat(
                    i.timeout,
                    "ms"
                  )
                ),
                n(o))
              : (i.logger(
                  "Timeout: Unable to resolve TCFv2 consent after ".concat(
                    i.timeout,
                    "ms"
                  )
                ),
                n(void 0));
        }, this.timeout),
        c =
          !1 !== this.cmpAutoDetect
            ? this.pingWithTimeout(
                a,
                this.pingTimeout,
                this.pingDelay,
                function () {
                  (s = !0),
                    i.logger(
                      "Timeout: Unable to ping TCFv2 API after ".concat(
                        i.pingTimeout,
                        "ms"
                      )
                    ),
                    n(void 0);
                }
              )
            : void 0;
      this.executeCommand("addEventListener", 2, function (e, t) {
        clearTimeout(c),
          s ||
            ((r = e.eventStatus) !== u.UI_SHOWN && clearTimeout(a),
            t
              ? (i.logger("TCFv2 consent retrieved in ms"),
                e ||
                  (i.logger("Unable to read GDPR consent data from CMP"),
                  n(void 0)),
                (o = i.processResponseData(e)),
                ((!1 === e.gdprApplies && void 0 === r) ||
                  r === u.LOADED ||
                  r === u.USER_ACTION_COMPLETE) &&
                  n(o))
              : (i.logger("Error retrieving TCFv2 consent data from CMP"),
                n(void 0)));
      });
    }),
    (t.prototype.processResponseData = function (e) {
      var t,
        n = {};
      return (
        "undefined" === e.tcString && (e.tcString = ""),
        (n.consentData = void 0 !== e.tcString ? e.tcString : ""),
        void 0 !== e.gdprApplies && (n.gdprApplies = !!e.gdprApplies),
        (n.version = e.tcfPolicyVersion || 2),
        (n.purposes =
          null == (t = null == e ? void 0 : e.purpose) ? void 0 : t.consents),
        (n.vendorConsents =
          null == (t = null == e ? void 0 : e.vendor) ? void 0 : t.consents),
        n
      );
    }),
    (t.prototype.executeCommand = function (e, t, n, o) {
      var r,
        i = this;
      this.hasCallerFunctionInFrame() ||
        (this.logger("No TCFv2 CMP defined on current frame"),
        (r = this.getCMPFrame()),
        (this.currentWindow.__tcfapi = function (e, t, n, o) {
          r
            ? ((t = {
                __tcfapiCall: {
                  command: e,
                  version: t,
                  parameter: o,
                  callId: (e = Math.random().toString(10)),
                },
              }),
              (i.cmpCallbacks[e] = n),
              r.postMessage(t, "*"))
            : (i.logger("TCFv2 CMP not found in any frame"),
              n({ msg: "TCFv2 CMP not found in any frame" }, !1));
        }),
        this.currentWindow.addEventListener(
          "message",
          function (e) {
            var e = "string" == typeof e.data ? a(e.data) : e.data;
            e &&
              e.__tcfapiReturn &&
              e.__tcfapiReturn.callId &&
              e.__tcfapiReturn.returnValue &&
              ((e = e.__tcfapiReturn), i.cmpCallbacks) &&
              i.cmpCallbacks[e.callId] &&
              "function" == typeof i.cmpCallbacks[e.callId] &&
              (i.cmpCallbacks[e.callId](e.returnValue, e.success),
              e.returnValue.eventStatus !== u.UI_SHOWN) &&
              delete i.cmpCallbacks[e.callId];
          },
          !1
        )),
        this.currentWindow.__tcfapi(e, t, n, o);
    });
  var u,
    c = t;
  function t(e, t, n) {
    void 0 === n && (n = function (e) {}),
      (this.cmpCallbacks = {}),
      (this.currentWindow = e),
      (this.timeout = t.tcfTimeout),
      (this.pingTimeout = t.tcfPingTimeout),
      (this.pingDelay = t.tcfPingDelay),
      (this.cmpAutoDetect = t.cmpAutoDetect),
      (this.logger = n);
  }
  (n.prototype.getCMPFrame = function () {
    for (var e, t = this.currentWindow, n = 0; n < 10; ++n) {
      try {
        void 0 !== t && t.frames.__gppLocator && (e = t);
      } catch (e) {}
      if (t === this.currentWindow.top) break;
      t = t.parent;
    }
    return e;
  }),
    (n.prototype.hasCallerFunctionInFrame = function () {
      return "function" == typeof this.currentWindow.__gpp;
    }),
    (n.prototype.readyToRetrieve = function () {
      return this.hasCallerFunctionInFrame() || void 0 !== this.getCMPFrame();
    }),
    (n.prototype.retrieveConsent = function (n) {
      function o(e, t) {
        r.logger(t),
          clearTimeout(e),
          (i = !0),
          r.logger(
            "Timeout: Unable to ping GPP after ".concat(r.pingTimeout, "ms")
          ),
          n(void 0);
      }
      var r = this,
        i = !1,
        s = window.setTimeout(function () {
          (i = !0),
            r.logger(
              "Timeout: Unable to resolve GPP consent after ".concat(
                r.timeout,
                "ms"
              )
            ),
            n(void 0);
        }, this.timeout);
      window.setTimeout(function () {
        var t = window.setTimeout(function () {
          o(
            s,
            "Timeout: Unable to get GPP ping return after ".concat(
              r.pingTimeout,
              "ms"
            )
          );
        }, r.pingTimeout);
        r.executeCommand("ping", function (e) {
          clearTimeout(t),
            r.logger("GPP CMP ping has responsed"),
            "1.0" === e.gppVersion
              ? (r.logger("Detected GPP CMP 1.0"),
                "error" === e.cmpStatus
                  ? o(s, "Error status on ping to GPP CMP")
                  : "loaded" === e.cmpStatus
                  ? (r.logger("GPP ping returned cmpStatus = loaded"),
                    r.executeCommand("getGPPData", function (e, t) {
                      i ||
                        (clearTimeout(s),
                        t
                          ? (r.logger("GPP consent retrieved"),
                            r.processResponseData(e, n))
                          : (r.logger(
                              "Error retrieving GPP consent data from CMP"
                            ),
                            n(void 0)));
                    }))
                  : o(s, "GPP ping returned cmpStatus != loaded"))
              : "1.1" === e.gppVersion
              ? (r.logger("Detected GPP CMP 1.1"),
                "ready" === e.signalStatus
                  ? (clearTimeout(s),
                    r.logger("GPP consent retrieved"),
                    r.processResponseData(e, n))
                  : r.executeCommand("addEventListener", function (e, t) {
                      i ||
                        ("signalStatus" === e.eventName &&
                          "ready" === e.pingData.signalStatus &&
                          (clearTimeout(s),
                          r.logger("GPP consent retrieved"),
                          r.processResponseData(e.pingData, n)));
                    }))
              : o(s, "Unknown GPP version " + e.gppVersion);
        });
      }, this.pingDelay);
    }),
    (n.prototype.processResponseData = function (e, t) {
      var n;
      e
        ? ((n = {}),
          void 0 !== e.gppString && (n.gpp = e.gppString),
          void 0 !== e.applicableSections && (n.gppSid = e.applicableSections),
          t(n))
        : (this.logger("Unable to read GPP consent data from CMP"), t(void 0));
    }),
    (n.prototype.executeCommand = function (e, t, n) {
      var o,
        r = this;
      this.hasCallerFunctionInFrame() ||
        (this.logger("No GPP CMP defined on current frame"),
        (o = this.getCMPFrame()),
        (this.currentWindow.__gpp = function (e, t, n) {
          o
            ? ((n = {
                __gppCall: {
                  command: e,
                  parameter: n,
                  callId: (e = Math.random().toString(10)),
                },
              }),
              (r.cmpCallbacks[e] = t),
              o.postMessage(n, "*"))
            : (r.logger("GPP CMP not found in any frame"),
              t({ msg: "GPP CMP not found in any frame" }, !1));
        }),
        this.currentWindow.addEventListener(
          "message",
          function (e) {
            var e = "string" == typeof e.data ? a(e.data) : e.data;
            e &&
              e.__gppReturn &&
              e.__gppReturn.callId &&
              e.__gppReturn.returnValue &&
              ((e = e.__gppReturn), r.cmpCallbacks) &&
              r.cmpCallbacks[e.callId] &&
              "function" == typeof r.cmpCallbacks[e.callId] &&
              (r.cmpCallbacks[e.callId](e.returnValue, e.success),
              delete r.cmpCallbacks[e.callId]);
          },
          !1
        )),
        this.currentWindow.__gpp(e, t, n);
    });
  var l = n;
  function n(e, t, n) {
    void 0 === n && (n = function (e) {}),
      (this.cmpCallbacks = {}),
      (this.currentWindow = e),
      (this.timeout = t.gppTimeout),
      (this.pingTimeout = t.gppPingTimeout),
      (this.pingDelay = t.gppPingDelay),
      (this.logger = n);
  }
  var N = {
    FR: !0,
    GB: !0,
    DE: !0,
    IT: !0,
    BE: !0,
    NL: !0,
    SE: !0,
    AI: !0,
    AW: !0,
    AT: !0,
    BM: !0,
    IO: !0,
    BG: !0,
    HR: !0,
    CY: !0,
    CZ: !0,
    DK: !0,
    EE: !0,
    FO: !0,
    FI: !0,
    GI: !0,
    GR: !0,
    GL: !0,
    HU: !0,
    IE: !0,
    LT: !0,
    LU: !0,
    MT: !0,
    MC: !0,
    AN: !0,
    PN: !0,
    PL: !0,
    PT: !0,
    RO: !0,
    SK: !0,
    SI: !0,
    GS: !0,
    ES: !0,
    SH: !0,
    TC: !0,
    VA: !0,
    VG: !0,
    FX: !0,
    PF: !0,
    IM: !0,
    JE: !0,
    NC: !0,
    GG: !0,
  };
  function p(e) {
    return e && N[e.toUpperCase()];
  }
  (f.prototype.checkLocalStorage = function (e) {
    if (!this.localStorage) return !1;
    var t = this.CHECK_STORAGE_KEY;
    try {
      return this.checkTcfPurposeOne(e)
        ? (this.localStorage.setItem(t, t), this.localStorage.removeItem(t), !0)
        : (d.Debug("Purpose One not granted"), !1);
    } catch (e) {
      return !1;
    }
  }),
    (f.prototype.checkTcfPurposeOne = function (e) {
      return e && e.gdprConsent && e.gdprConsent.purposes
        ? !0 === e.gdprConsent.purposes[1]
        : "IT" == this.USER_COUNTRY_MACRO || !p(this.USER_COUNTRY_MACRO);
    }),
    (f.prototype.removeItem = function (e) {
      this.localStorageEnabled &&
        (this.localStorage.removeItem(e),
        this.localStorage.removeItem(e + this.EXPIRE_SUFFIX));
    }),
    (f.prototype.getItem = function (e, t) {
      var n, o;
      return this.localStorageEnabled
        ? ((n = new Date().getTime()),
          (-1 !==
            (o = (o = this.localStorage.getItem(e + this.EXPIRE_SUFFIX))
              ? parseInt(o, 10)
              : -1) &&
            o < n) ||
          (t && (-1 === o || t < o - n))
            ? (this.removeItem(e), null)
            : this.localStorage.getItem(e))
        : null;
    }),
    (f.prototype.setItem = function (e, t, n) {
      if (this.localStorageEnabled)
        try {
          var o;
          this.localStorage.setItem(e, t),
            n &&
              ((o = new Date().getTime() + n),
              this.localStorage.setItem(e + this.EXPIRE_SUFFIX, o.toString()));
        } catch (e) {}
    }),
    (f.prototype.getAllItemsByPrefix = function (e) {
      var t = [];
      if (this.localStorageEnabled)
        for (var n in localStorage) 0 === n.indexOf(e) && t.push(n);
      return t;
    });
  var H = f;
  function f(e, t) {
    (this.EXPIRE_SUFFIX = "_expires"),
      (this.CHECK_STORAGE_KEY = "criteo_localstorage_check"),
      (this.USER_COUNTRY_MACRO = "IT"),
      (this.localStorage = ((e) => {
        try {
          return e.localStorage;
        } catch (e) {}
      })(e || window)),
      (this.localStorageEnabled = this.checkLocalStorage(t));
  }
  (h.prototype.checkTcfPurposeOne = function (e) {
    return e && null != e && e.gdprConsent && e.gdprConsent.purposes
      ? !0 === e.gdprConsent.purposes[1]
      : "IT" == this.USER_COUNTRY_MACRO || !p(this.USER_COUNTRY_MACRO);
  }),
    (h.prototype.setCookie = function (e, t, n, o, r) {
      void 0 === r && (r = !1);
      var i = o || document,
        s = i.location.hostname,
        a = new Date(),
        c =
          (a.setTime(a.getTime() + 60 * n * 60 * 1e3),
          "expires=" + a.toUTCString());
      if (r)
        for (var u = s.split("."), l = 1; l < u.length; ++l) {
          var p = u.slice(u.length - l - 1, u.length).join(".");
          if (!(-1 < this.publicTopTlds.indexOf(p)))
            try {
              this.setCookieString(e, t, c, p, i);
              var d = this.getCookie(e, o);
              if (d && d === t) return p;
            } catch (e) {}
        }
      else this.setCookieString(e, t, c, void 0, i);
      return s;
    }),
    (h.prototype.deleteCookie = function (e, t, n) {
      this.setCookie(e, "", 0, t, (n = void 0 === n ? !1 : n));
    }),
    (h.prototype.getCookie = function (e, t) {
      if (this.cookiesEnabled)
        for (
          var n = 0, o = (t || document).cookie.split(";");
          n < o.length;
          n++
        ) {
          var r = o[n],
            i = r.substr(0, r.indexOf("=")).replace(/^\s+|\s+$/g, ""),
            r = r.substr(r.indexOf("=") + 1);
          if (i === e) return decodeURIComponent(r);
        }
    }),
    (h.prototype.setCookieString = function (e, t, n, o, r) {
      this.cookiesEnabled &&
        ((e = e + "=" + encodeURIComponent(t) + ";" + n + ";"),
        o && "" !== o && (e += "domain=." + o + ";"),
        (r.cookie = e + "path=/"));
    });
  var G = h;
  function h(e) {
    (this.publicTopTlds = [
      "co.id",
      "co.il",
      "co.jp",
      "co.kr",
      "co.nz",
      "co.th",
      "co.uk",
      "com.au",
      "com.br",
      "com.mx",
      "com.my",
      "com.pl",
      "com.sg",
      "com.tr",
      "com.vn",
    ]),
      (this.USER_COUNTRY_MACRO = "IT"),
      (this.cookiesEnabled = this.checkTcfPurposeOne(e));
  }
  (g.prototype.initializeServices = function () {
    var n = this;
    (this.initializing = !0),
      this.retrievePrivacyConsent(function (e) {
        var t = {
          localStorageHelper: new H(n.topFrame, e),
          privacies: e,
          gppConsentProvider: n.gppConsentProvider,
          cookieHelper: new G(e),
        };
        (n.services = t),
          (n.initialized = !0),
          (n.initializing = !1),
          n.postInitiliazeServicesCallbacks.forEach(function (e) {
            e(t);
          });
      });
  }),
    (g.prototype.getServicesAsync = function (e) {
      this.initialized
        ? e(this.services)
        : (this.postInitiliazeServicesCallbacks.push(e),
          this.initializing || this.initializeServices());
    }),
    (g.prototype.retrievePrivacyConsent = function (t) {
      var n,
        o,
        e = this.tcfv2ConsentProvider.readyToRetrieve(),
        r = this.gppConsentProvider.readyToRetrieve();
      e || r
        ? ((n = []),
          e && n.push(c),
          r && n.push(l),
          (o = {}),
          e &&
            this.tcfv2ConsentProvider.retrieveConsent(function (e) {
              (o.gdprConsent = e),
                n.splice(n.indexOf(c), 1),
                0 === n.length && t(o);
            }),
          r &&
            this.gppConsentProvider.retrieveConsent(function (e) {
              (o.gppConsent = e),
                n.splice(n.indexOf(l), 1),
                0 === n.length && t(o);
            }))
        : t(void 0);
    });
  var x = g;
  function g(e, t, n, o) {
    (this.initializing = !1),
      (this.initialized = !1),
      (this.postInitiliazeServicesCallbacks = []),
      (this.topFrame = e || window);
    e = o;
    o = {
      tcfTimeout: parseInt("10000", 10),
      tcfPingTimeout: Math.min(parseInt("10000", 10), parseInt("50", 10)),
      tcfPingDelay: Math.min(parseInt("10000", 10), parseInt("1000", 10)),
      gppTimeout: parseInt("10000", 10),
      gppPingTimeout: Math.min(parseInt("10000", 10), parseInt("50", 10)),
      gppPingDelay: Math.min(parseInt("10000", 10), parseInt("1000", 10)),
      cmpAutoDetect: null == e ? void 0 : e.cmpAutoDetect,
    };
    (this.tcfv2ConsentProvider = t || new c(window, o, d.Warning)),
      (this.gppConsentProvider = n || new l(window, o, d.Warning)),
      this.initializeServices();
  }
  function m(t, n) {
    try {
      return decodeURIComponent(t);
    } catch (e) {
      return void 0 !== n ? n : t;
    }
  }
  var v,
    W = function (e, t) {
      return (W =
        Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array
          ? function (e, t) {
              e.__proto__ = t;
            }
          : function (e, t) {
              for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n]);
            }))(e, t);
    };
  function y(e, t) {
    function n() {
      this.constructor = e;
    }
    W(e, t),
      (e.prototype =
        null === t ? Object.create(t) : ((n.prototype = t.prototype), new n()));
  }
  ((R = v = v || {})[(R.None = 0)] = "None"),
    (R[(R.Cookie = 1)] = "Cookie"),
    (R[(R.LocalStorage = 2)] = "LocalStorage"),
    (R[(R.Delegation = 4)] = "Delegation"),
    (_.prototype.getLocalWebId = function () {
      return this.userDataHandlers.localWebId().fromAllStorages();
    }),
    (_.prototype.getOptOut = function () {
      return this.userDataHandlers.optOut().fromAllStorages();
    }),
    (_.prototype.getBundle = function () {
      return this.userDataHandlers.bundle().fromAllStorages();
    });
  var B = _;
  function _(e) {
    this.userDataHandlers = e;
  }
  function w(e, t) {
    (this.value = e), (this.origin = t);
  }
  (w.fromUserIdentificationData = function (e) {
    return new w(e.value, e.origin);
  }),
    (w.fromValue = function (e) {
      return new w(e, v.None);
    }),
    (w.prototype.hasValue = function () {
      return "" !== String(this.value) && null != this.value;
    }),
    y(C, (V = w)),
    (C.prototype.hasValue = function () {
      return "" !== String(this.value) && null != this.value;
    }),
    (C.prototype.saveOnAllStorages = function () {
      var e;
      this.hasValue() &&
        ((e =
          "boolean" == typeof this.value
            ? this.value
              ? "1"
              : "0"
            : String(this.value)),
        this.storageAdapter.writeToAllStorages(
          this.storageKey,
          e,
          this.expirationTimeHours
        ));
    }),
    (C.prototype.toJSON = function () {
      return { value: this.value, origin: this.origin };
    });
  var V,
    q = C;
  function C(e, t, n, o, r) {
    n = V.call(this, n, o) || this;
    return (
      (n.storageKey = e), (n.expirationTimeHours = t), (n.storageAdapter = r), n
    );
  }
  (E.prototype.localWebId = function () {
    return this.createGuid(E.LWID_COOKIE_NAME);
  }),
    (E.prototype.optOut = function () {
      return new j(
        Boolean,
        E.OPTOUT_COOKIE_NAME,
        E.OPTOUT_RETENTION_TIME_HOUR,
        this.storageAdapter
      );
    }),
    (E.prototype.bundle = function () {
      return this.createGuid(E.BUNDLE_COOKIE_NAME);
    }),
    (E.prototype.createGuid = function (e) {
      return new j(String, e, E.GUID_RETENTION_TIME_HOUR, this.storageAdapter);
    }),
    (E.LWID_COOKIE_NAME = "cto_lwid"),
    (E.OPTOUT_COOKIE_NAME = "cto_optout"),
    (E.BUNDLE_COOKIE_NAME = "cto_bundle"),
    (E.GUID_RETENTION_TIME_HOUR = 9360),
    (E.OPTOUT_RETENTION_TIME_HOUR = 43200);
  var K = E;
  function E(e) {
    this.storageAdapter = e;
  }
  (S.prototype.fromAllStorages = function () {
    var e = this.storageAdapter.readFromAllStorages(this.storageKey),
      t =
        "boolean" == typeof new this.type().valueOf()
          ? "1" === e.value
          : e.value;
    return this.create(t, e.origin);
  }),
    (S.prototype.fromValue = function (e) {
      return this.create(e, v.None);
    }),
    (S.prototype.removeFromAllStorages = function () {
      this.storageAdapter.removeFromAllStorages(this.storageKey);
    }),
    (S.prototype.create = function (e, t) {
      return new q(
        this.storageKey,
        this.expirationTimeHours,
        e,
        t,
        this.storageAdapter
      );
    });
  var j = S;
  function S(e, t, n, o) {
    (this.type = e),
      (this.storageKey = t),
      (this.expirationTimeHours = n),
      (this.storageAdapter = o);
  }
  function T(e, t, n) {
    (this.criteoGlobalVendorListId = 91),
      (this.window = e),
      (this.document = e.document),
      (this.userDataHandlers = new K(t)),
      (this.syncframeOrigin = "https://".concat(
        (n = null != n ? n : "gum.criteo.com")
      )),
      (this.syncframeEndpoint = "https://".concat(n, "/syncframe")),
      this.window.criteo_syncframe_state ||
        (this.window.criteo_syncframe_state = { syncframeRequested: !1 }),
      this.window.criteo_syncframe_state.appendSyncframeRequestQueue ||
        (this.window.criteo_syncframe_state.appendSyncframeRequestQueue = []);
  }
  (T.prototype.getSyncframeListener = function (n, o, r) {
    var i = this;
    return function (e) {
      var t;
      (i.discardMessageFromOtherFrames(e) &&
        !i.window.criteo_syncframe_state.ForceSyncframeMessageHandling) ||
        ((null == (t = e.data) ? void 0 : t.requestId) === n &&
          (e.stopImmediatePropagation(),
          i.handleSyncframeResponse(t, o, r),
          (i.window.criteo_syncframe_state.firstSyncframeCompleted = !0),
          (i.window.criteo_syncframe_state.syncframeRequested = !1),
          i.tryUnqueueAppendSyncframeRequests()));
    };
  }),
    (T.prototype.userBundleHasAlreadyBeenRetrieved = function () {
      return this.userDataHandlers.bundle().fromAllStorages().hasValue();
    }),
    (T.prototype.canDropSyncframe = function () {
      return !this.window.criteo_syncframe_state.syncframeRequested;
    }),
    (T.prototype.discardMessageFromOtherFrames = function (e) {
      return !e.data || e.origin != this.syncframeOrigin;
    }),
    (T.prototype.appendGumIframeIfDoesNotExist = function (e, t, n) {
      var o,
        r = this;
      !0 ===
        (null == (o = this.window.criteo_syncframe_state)
          ? void 0
          : o.firstSyncframeCompleted) ||
      this.userBundleHasAlreadyBeenRetrieved() ||
      this.canDropSyncframe()
        ? this.appendGumIframe(e, t, n)
        : this.queueAppendSyncframeRequest(function () {
            return r.appendGumIframeIfDoesNotExist(e, t, n);
          });
    }),
    (T.prototype.doOnCompletedDom = function (e) {
      var t,
        n = this;
      this.window.addEventListener &&
        ("complete" === this.document.readyState
          ? e()
          : ((t = function () {
              n.window.removeEventListener("load", t),
                n.document.removeEventListener("DOMContentLoaded", t),
                e();
            }),
            this.window.addEventListener("load", t, !1),
            this.document.addEventListener("DOMContentLoaded", t, !1)));
    }),
    (T.prototype.appendGumIframe = function (e, t, n) {
      t();
      var t = e(),
        e =
          String(
            null != (e = null == (e = t.bundle) ? void 0 : e.value) ? e : ""
          ) || null;
      this.consentAllowsSyncframeToBeDropped(t.consent)
        ? (this.window.addEventListener(
            "message",
            this.getSyncframeListener(t.requestId, e, n),
            !0
          ),
          (t = this.createIFrame(t)),
          this.document.body.appendChild(t),
          (this.window.criteo_syncframe_state.syncframeRequested = !0))
        : this.handleSyncframeResponse({}, e, n);
    }),
    (T.prototype.consentAllowsSyncframeToBeDropped = function (e) {
      return (
        2 !== (null == e ? void 0 : e.gdprVersion) ||
        !0 !== (null == e ? void 0 : e.gdprApplies) ||
        !0 ===
          (null == (e = null == e ? void 0 : e.vendorConsents)
            ? void 0
            : e[this.criteoGlobalVendorListId])
      );
    }),
    (T.prototype.queueAppendSyncframeRequest = function (e) {
      void 0 !==
        this.window.criteo_syncframe_state.appendSyncframeRequestQueue &&
        this.window.criteo_syncframe_state.appendSyncframeRequestQueue.push(e);
    }),
    (T.prototype.tryUnqueueAppendSyncframeRequests = function () {
      for (
        var e,
          t,
          n =
            null ==
            (e = this.window.criteo_syncframe_state.appendSyncframeRequestQueue)
              ? void 0
              : e.shift();
        void 0 !== n;

      )
        n(),
          (n =
            null ==
            (t = this.window.criteo_syncframe_state.appendSyncframeRequestQueue)
              ? void 0
              : t.shift());
    }),
    (T.prototype.saveResponseBundleUnlessStorageChanged = function (e, t) {
      var n = this.userDataHandlers.bundle().fromAllStorages(),
        n = n.hasValue() ? String(n.value) : null;
      return n !== t
        ? { bundle: null != n ? n : "", responseWritten: !1 }
        : (this.userDataHandlers.bundle().fromValue(e).saveOnAllStorages(),
          { bundle: e, responseWritten: !0 });
    }),
    (T.prototype.createIFrame = function (e) {
      var t = this.document.createElement("iframe"),
        n = {
          bundle: e.bundle,
          optout: e.optoutCookie,
          tld: e.topLevelDomain,
          topUrl: e.topUrl,
          version:
            "string" == typeof e.version
              ? null == (n = e.version)
                ? void 0
                : n.replace(/\./g, "_")
              : e.version,
          origin: e.origin,
          pm: e.privateMode,
          rtusCallerId: e.rtusCallerId,
          requestId: e.requestId,
          ceid: e.ceid,
        },
        o = [];
      return (
        o.push("origin=".concat(e.origin)),
        o.push("topUrl=".concat(e.topUrl)),
        e.consent &&
          (void 0 !== e.consent.gdprApplies &&
            o.push("gdpr=".concat(e.consent.gdprApplies ? 1 : 0)),
          void 0 !== e.consent.consentData &&
            o.push("gdpr_consent=".concat(e.consent.consentData)),
          void 0 !== e.consent.uspString &&
            o.push("us_privacy=".concat(e.consent.uspString)),
          void 0 !== e.consent.gppString &&
            o.push("gpp=".concat(e.consent.gppString)),
          void 0 !== e.consent.gppSectionIds) &&
          o.push("gpp_sid=".concat(e.consent.gppSectionIds)),
        e.isDebug && o.push("debug=1"),
        (t.src = ""
          .concat(this.syncframeEndpoint, "?")
          .concat(o.join("&"), "#")
          .concat(JSON.stringify(n))),
        (t.width = "0"),
        (t.height = "0"),
        (t.frameBorder = "0"),
        (t.style.borderWidth = "0px"),
        (t.style.margin = "0px"),
        (t.style.display = "none"),
        t.setAttribute("sandbox", "allow-scripts allow-same-origin"),
        t.setAttribute("aria-hidden", "true"),
        t.setAttribute("tabindex", "-1"),
        (t.title = "Criteo GUM iframe"),
        t
      );
    }),
    y(b, (z = T)),
    (b.prototype.handleSyncframeResponse = function (e, t, n) {
      if (e.optout)
        this.deleteUserData(),
          this.userDataHandlers.optOut().fromValue(!0).saveOnAllStorages(),
          null != (o = null == n ? void 0 : n.resolve) && o.call(n, "");
      else {
        var o = "";
        if (e.callbacks)
          for (
            var r = 0,
              i = "string" == typeof e.callbacks ? [e.callbacks] : e.callbacks;
            r < i.length;
            r++
          ) {
            var s = i[r],
              a = this.document.createElement("img");
            (a.style.display = "none"),
              (a.width = 1),
              (a.height = 1),
              a.setAttribute("data-owner", "criteo-tag"),
              (a.src = s);
          }
        else
          e.bundle &&
            (o = this.saveResponseBundleUnlessStorageChanged(
              e.bundle,
              t
            ).bundle);
        null != n && n.resolve && n.resolve(o);
      }
    }),
    (b.prototype.appendGumIFrameOnCompletedDomIfItDoesNotExist = function (
      e,
      t
    ) {
      function n() {
        return o.appendGumIframeIfDoesNotExist(
          function () {
            return o.createSyncframeRequest(e(), r);
          },
          function () {},
          { resolve: t }
        );
      }
      var o = this,
        r = Math.random().toString();
      this.adapter.isPubTagIds ? n() : this.doOnCompletedDom(n);
    }),
    (b.prototype.createSyncframeRequest = function (e, t) {
      return {
        bundle: this.userDataHandlers.bundle().fromAllStorages().toJSON(),
        optoutCookie: this.userDataHandlers.optOut().fromAllStorages().toJSON(),
        topLevelDomain: e.topLevelDomain,
        topUrl: e.topUrl,
        version: e.version,
        canWriteCookie: e.canWriteCookie,
        canWriteLocalStorage: e.canWriteLocalStorage,
        origin: this.adapter.isPubTagIds ? "publishertagids" : "publishertag",
        privateMode: void 0,
        consent: e.consent,
        rtusCallerId: void 0,
        isDebug: this.adapter.isDebug,
        requestId: t,
      };
    }),
    (b.prototype.fetchUserData = function () {
      return new B(this.userDataHandlers);
    }),
    (b.prototype.deleteUserData = function () {
      this.userDataHandlers.bundle().removeFromAllStorages();
    });
  var z,
    Y = b;
  function b(e, t, n) {
    t =
      z.call(
        this,
        t,
        e.storageAdapter,
        (n = void 0 === n ? !1 : n) ? "gumi.criteo.com" : "gum.criteo.com"
      ) || this;
    return (t.adapter = e), t;
  }
  (I.prototype.synchronizeCriteoUid = function (e, t) {
    var n = this,
      o = null == e ? void 0 : e.gdprConsent,
      r = null == e ? void 0 : e.gppConsent;
    this.syncframe.appendGumIFrameOnCompletedDomIfItDoesNotExist(function () {
      var e, t;
      return {
        topLevelDomain: n.getTld(),
        topUrl: encodeURIComponent(
          ((e = n.topUrl),
          ((t = document.createElement("a")).href = e),
          {
            protocol: t.protocol,
            host: t.host,
            hostname: t.hostname,
            pathname: "/" === t.pathname[0] ? t.pathname.slice(1) : t.pathname,
            search: t.search,
            href: t.href,
          }).hostname
        ),
        version: s,
        canWriteCookie: n.canWriteCookies,
        canWriteLocalStorage: n.localStorageHelper.localStorageEnabled,
        consent: {
          gdprApplies: null == o ? void 0 : o.gdprApplies,
          consentData: null == o ? void 0 : o.consentData || "",
          gdprVersion: null == o ? void 0 : o.version,
          vendorConsents: null == o ? void 0 : o.vendorConsents,
          gppString: null == r ? void 0 : r.gpp,
          gppSectionIds:
            null == (e = null == r ? void 0 : r.gppSid) ? void 0 : e.join(","),
        },
      };
    }, t);
  }),
    (I.prototype.checkCookiesAreWriteable = function () {
      var e = "cto_writeable",
        t =
          (this.cookieHelper.setCookie(e, "1", 1, this.topDoc, !0),
          "1" === this.cookieHelper.getCookie(e, this.topDoc));
      return this.cookieHelper.deleteCookie(e, this.topDoc, !0), t;
    }),
    (I.prototype.writeOnAllStorages = function (e, t, n) {
      this.localStorageHelper.setItem(e, t),
        this.cookieHelper.setCookie(e, t, n, this.topDoc, !0);
    }),
    (I.prototype.getFromAllStorages = function (e) {
      var t = this.cookieHelper.getCookie(e, this.topDoc),
        e = this.localStorageHelper.getItem(e) || void 0;
      return { value: t || e, origin: (t && v.Cookie) | (e && v.LocalStorage) };
    }),
    (I.prototype.deleteFromAllStorage = function (e) {
      this.cookieHelper.deleteCookie(e, this.topDoc, !0),
        this.localStorageHelper.removeItem(e);
    }),
    (I.prototype.getTld = function () {
      var e = this.cookieHelper.setCookie(
        I.TLD_TEST_COOKIE_NAME,
        "test",
        1,
        this.topDoc,
        !0
      );
      return (
        this.cookieHelper.deleteCookie(I.TLD_TEST_COOKIE_NAME, this.topDoc, !0),
        e
      );
    }),
    (I.prototype.fetchUserData = function () {
      return this.syncframe.fetchUserData();
    }),
    (I.prototype.deleteUserData = function () {
      this.syncframe.deleteUserData();
    }),
    (I.TLD_TEST_COOKIE_NAME = "cto_pub_test_tld");
  var X = I;
  function I(e, t, n, o, r, i, s) {
    var a = this,
      e =
        ((this.topDoc = n.document),
        (this.cookieHelper = e),
        (this.localStorageHelper = t),
        (this.canWriteCookies = this.checkCookiesAreWriteable()),
        (this.topUrl = r),
        !1);
    try {
      e = JSON.parse("false");
    } catch (e) {}
    this.syncframe =
      null != s
        ? s
        : new Y(
            {
              storageAdapter: {
                readFromAllStorages: function (e) {
                  e = a.getFromAllStorages(e);
                  return { value: e.value, origin: e.origin };
                },
                writeToAllStorages: function (e, t, n) {
                  a.writeOnAllStorages(e, t, n);
                },
                removeFromAllStorages: function (e) {
                  a.deleteFromAllStorage(e);
                },
              },
              isPubTagIds: null != i && i,
              isDebug: o,
            },
            n,
            e
          );
  }
  function J(e) {
    return (
      e.top !== e &&
      !((e) => {
        var t;
        try {
          return null != (t = e.top) && t.location.toString(), 1;
        } catch (e) {}
      })(e)
    );
  }
  function Q(e) {
    if ((void 0 === e && (e = window), !J(window)))
      for (var t = 0; t < 10; t++) {
        if (void 0 !== e.googletag) return e.googletag;
        if (e === e.top) break;
        e = e.parent;
      }
    return window.googletag;
  }
  function Z(e) {
    var t = Q();
    t || ((t = {}), (window.googletag = t)),
      (t.cmd = t.cmd || []),
      t.cmd.push(e);
  }
  ee.generateCacheBuster = function () {
    return Math.floor(99999999999 * Math.random());
  };
  var P,
    $ = ee;
  function ee() {}
  ((R = P = P || {})[(R.Unspecified = 0)] = "Unspecified"),
    (R[(R.AMP = 1)] = "AMP"),
    (D.prototype.buildUrl = function (e, t, n, o, r) {
      void 0 === n && (n = P.Unspecified);
      var i = D.CRITEO_BIDDER_URL + this.getHandlerPath(e, t);
      return (
        (i += "?ptv=" + s),
        !0 === t.isAdBlocked && (i += "&abp=1"),
        (i = this.appendCommonParameters(i, e, o, r)),
        (i =
          (i += t.isOptOut ? "&optout=1" : "") +
          (t.bundle ? "&bundle=" + t.bundle : "")),
        n !== P.Unspecified && (i += "&im=" + n),
        (i =
          (i += "&cb=" + String($.generateCacheBuster())) + t.getContextFlags())
      );
    }),
    (D.prototype.buildErrorUrl = function () {
      return D.CRITEO_BIDDER_URL + D.CRITEO_ERROR_HANDLER;
    }),
    (D.prototype.appendCommonParameters = function (e, t, n, o) {
      return (
        (e += "&profileId=" + String(t)),
        void 0 !== n && (e += "&av=" + String(n)),
        void 0 !== o && (e += "&wv=" + encodeURIComponent(o)),
        e
      );
    }),
    (D.prototype.getHandlerPath = function (e, t) {
      var n;
      if (this.auditMode) return D.CRITEO_BIDDER_AUDIT_HANDLER;
      if (334 == e && void 0 !== t.slotsExt)
        for (var o in t.slotsExt) {
          o = t.slotsExt[o];
          if (
            void 0 !==
            (null == (n = null == o ? void 0 : o.data) ? void 0 : n.gtin)
          )
            return D.CRITEO_COMMERCE_EXPERIENCE_3_HANDLER;
          if (
            void 0 !==
            (null == (n = null == o ? void 0 : o.data) ? void 0 : n.keyword)
          )
            return D.CRITEO_COMMERCE_EXPERIENCE_4_HANDLER;
        }
      return D.CRITEO_BIDDER_HANDLER;
    }),
    (D.CRITEO_BIDDER_URL = "https://bidder.criteo.com/"),
    (D.CRITEO_BIDDER_HANDLER = "cdb"),
    (D.CRITEO_COMMERCE_EXPERIENCE_3_HANDLER =
      "experiences/2023-10/dynamic-buttons"),
    (D.CRITEO_COMMERCE_EXPERIENCE_4_HANDLER =
      "experiences/2023-10/product-recommendation"),
    (D.CRITEO_ERROR_HANDLER = "error"),
    (D.CRITEO_BIDDER_AUDIT_HANDLER = "prebid/audit");
  var te = D;
  function D(e) {
    this.auditMode = e = void 0 === e ? !1 : e;
  }
  ne.prototype.sendEventsToBeacon = function (e, t) {
    navigator.sendBeacon && e && navigator.sendBeacon(t, JSON.stringify(e));
  };
  var R = ne;
  function ne() {
    this.urlBuilder = new te();
  }
  (A.CreateRunning = function () {
    var e = new A();
    return e.start(), e;
  }),
    (A.CreateWithStartTime = function (e) {
      var t = new A(!1);
      return (t.startTime = e), t;
    }),
    (A.TimeSincePageLoad = function () {
      if (window.performance) {
        if (window.performance.now) return window.performance.now();
        if (
          window.performance.timing &&
          window.performance.timing.navigationStart
        )
          return new Date().getTime() - performance.timing.navigationStart;
      }
      return 0;
    }),
    (A.prototype.start = function () {
      this.startTime = this.now();
    }),
    (A.prototype.elapsed = function () {
      return this.now() - this.startTime;
    });
  var O = A;
  function A(e) {
    (e = void 0 === e ? !0 : e) && window.performance && window.performance.now
      ? (this.now = window.performance.now.bind(window.performance))
      : Date.now
      ? (this.now = Date.now)
      : (this.now = function () {
          return new Date().getTime();
        });
  }
  y(U, (oe = R)),
    (U.prototype.sendSetTagLoadedTime = function () {
      this.sendEvents({ eventId: "TagLoaded", elapsed: O.TimeSincePageLoad() });
    }),
    (U.prototype.sendSetEspPromiseTime = function () {
      this.sendEvents({
        eventId: "SetEspPromise",
        elapsed: O.TimeSincePageLoad(),
      });
    }),
    (U.prototype.sendReturnEspPromiseToGptTime = function () {
      this.sendEvents({
        eventId: "ReturnEspPromiseToGpt",
        elapsed: O.TimeSincePageLoad(),
      });
    }),
    (U.prototype.sendResolveEspPromiseTime = function () {
      this.sendEvents({
        eventId: "ResolveEspPromise",
        elapsed: O.TimeSincePageLoad(),
      });
    }),
    (U.prototype.sendEvents = function (e) {});
  var oe,
    re = U;
  function U(e, t) {
    var n = oe.call(this) || this;
    return (
      (n.topFrame = e),
      (n.isEligibleForCsmEvents = t),
      (n.requestId = crypto.randomUUID()),
      n
    );
  }
  function M(e, a, t, n) {
    void 0 === e &&
      (e =
        null == (o = window.Criteo_identitytag_110615 || window.Criteo)
          ? void 0
          : o.config),
      void 0 === n && (n = new Date().getUTCMilliseconds()),
      (this.sessionRandomId = n);
    var c = i.getHighestAccessibleWindow(window),
      u = i.getHighestAccessibleUrl(c),
      l = new re(c.topFrame, this.isEligibleForCsmEvents());
    l.sendSetTagLoadedTime();
    var o,
      p =
        "1" ===
          ((e) => {
            var t = {};
            if (1 < (e = e.split("?")).length)
              for (var n = 0, o = e[1].split("&"); n < o.length; n++) {
                var r = o[n].split("=");
                t[m(r[0])] = m(r[1]);
              }
            return t;
          })(u).pbt_debug || !1;
    p && ((o = r.Debug), (d.LOGLEVEL = o)),
      (t || new x(c.topFrame, void 0, void 0, e)).getServicesAsync(function (
        e
      ) {
        var t,
          n,
          o,
          r,
          i =
            (null == a ? void 0 : a()) ||
            new X(e.cookieHelper, e.localStorageHelper, c.topFrame, p, u, !0),
          s = i.fetchUserData().getBundle();
        s.hasValue() &&
          "" !== s.value &&
          ((t = new Promise(function (e, t) {
            e(s.value),
              d.Debug("Resolving GPT ESP Promise"),
              l.sendResolveEspPromiseTime();
          })),
          (n = t),
          (o = function () {
            l.sendReturnEspPromiseToGptTime();
          }),
          (r = function () {
            l.sendSetEspPromiseTime();
          }),
          Z(function () {
            var e = Q();
            e.secureSignalProviders || (e.secureSignalProviders = []),
              d.Debug("Promise set for GPT ESP"),
              e.secureSignalProviders.push({
                id: "esp.criteo.com",
                collectorFunction: function () {
                  return d.Debug("Returning Promise to GPT"), o(), n;
                },
              }),
              r();
          })),
          i.synchronizeCriteoUid(e.privacies);
      }),
      d.Debug("Publisher Tag loaded");
  }
  (M.prototype.isEligibleForCsmEvents = function () {
    return this.sessionRandomId % 100 == 0;
  }),
    (M.VERSION = s),
    (R = M);
  var ie,
    se =
      "undefined" != typeof globalThis
        ? globalThis
        : "undefined" != typeof window
        ? window
        : "undefined" != typeof global
        ? global
        : "undefined" != typeof self
        ? self
        : {},
    ae =
      ((k = { exports: {} }),
      (ie = function () {
        function c(e) {
          return "function" == typeof e;
        }
        var n =
            Array.isArray ||
            function (e) {
              return "[object Array]" === Object.prototype.toString.call(e);
            },
          o = 0,
          t = void 0,
          r = void 0,
          s = function (e, t) {
            (p[o] = e), (p[o + 1] = t), 2 === (o += 2) && (r ? r(d) : F());
          };
        var e = "undefined" != typeof window ? window : void 0,
          i = e || {},
          i = i.MutationObserver || i.WebKitMutationObserver,
          a =
            "undefined" == typeof self &&
            "undefined" != typeof process &&
            "[object process]" === {}.toString.call(process),
          u =
            "undefined" != typeof Uint8ClampedArray &&
            "undefined" != typeof importScripts &&
            "undefined" != typeof MessageChannel;
        function l() {
          var e = setTimeout;
          return function () {
            return e(d, 1);
          };
        }
        var p = new Array(1e3);
        function d() {
          for (var e = 0; e < o; e += 2)
            (0, p[e])(p[e + 1]), (p[e] = void 0), (p[e + 1] = void 0);
          o = 0;
        }
        function f() {
          try {
            var e = Function("return this")().require("vertx");
            return void 0 !== (t = e.runOnLoop || e.runOnContext)
              ? function () {
                  t(d);
                }
              : l();
          } catch (e) {
            return l();
          }
        }
        var h,
          g,
          m,
          F = void 0;
        function v(e, t) {
          var n,
            o = this,
            r = new this.constructor(w),
            i = (void 0 === r[_] && U(r), o._state);
          return (
            i
              ? ((n = arguments[i - 1]),
                s(function () {
                  return O(i, r, n, o._result);
                }))
              : D(o, r, e, t),
            r
          );
        }
        function y(e) {
          var t;
          return e && "object" == typeof e && e.constructor === this
            ? e
            : (b((t = new this(w)), e), t);
        }
        var F = a
            ? function () {
                return process.nextTick(d);
              }
            : i
            ? ((g = 0),
              (a = new i(d)),
              (m = document.createTextNode("")),
              a.observe(m, { characterData: !0 }),
              function () {
                m.data = g = ++g % 2;
              })
            : u
            ? (((h = new MessageChannel()).port1.onmessage = d),
              function () {
                return h.port2.postMessage(0);
              })
            : (void 0 === e ? f : l)(),
          _ = Math.random().toString(36).substring(2);
        function w() {}
        var C = void 0,
          E = 1,
          S = 2;
        function N(e, o, r) {
          s(function (t) {
            var n = !1,
              e = ((e, t, n, o) => {
                try {
                  e.call(t, n, o);
                } catch (e) {
                  return e;
                }
              })(
                r,
                o,
                function (e) {
                  n || ((n = !0), (o !== e ? b : I)(t, e));
                },
                function (e) {
                  n || ((n = !0), P(t, e));
                },
                t._label
              );
            !n && e && ((n = !0), P(t, e));
          }, e);
        }
        function T(e, t, n) {
          var o, r;
          t.constructor === e.constructor &&
          n === v &&
          t.constructor.resolve === y
            ? ((o = e),
              (r = t)._state === E
                ? I(o, r._result)
                : r._state === S
                ? P(o, r._result)
                : D(
                    r,
                    void 0,
                    function (e) {
                      return b(o, e);
                    },
                    function (e) {
                      return P(o, e);
                    }
                  ))
            : void 0 !== n && c(n)
            ? N(e, t, n)
            : I(e, t);
        }
        function b(t, e) {
          if (t === e)
            P(t, new TypeError("You cannot resolve a promise with itself"));
          else if (
            ((n = typeof e), null === e || ("object" != n && "function" != n))
          )
            I(t, e);
          else {
            n = void 0;
            try {
              n = e.then;
            } catch (e) {
              return void P(t, e);
            }
            T(t, e, n);
          }
          var n;
        }
        function H(e) {
          e._onerror && e._onerror(e._result), R(e);
        }
        function I(e, t) {
          e._state === C &&
            ((e._result = t), (e._state = E), 0 !== e._subscribers.length) &&
            s(R, e);
        }
        function P(e, t) {
          e._state === C && ((e._state = S), (e._result = t), s(H, e));
        }
        function D(e, t, n, o) {
          var r = e._subscribers,
            i = r.length;
          (e._onerror = null),
            (r[i] = t),
            (r[i + E] = n),
            (r[i + S] = o),
            0 === i && e._state && s(R, e);
        }
        function R(e) {
          var t = e._subscribers,
            n = e._state;
          if (0 !== t.length) {
            for (var o, r = void 0, i = e._result, s = 0; s < t.length; s += 3)
              (o = t[s]), (r = t[s + n]), o ? O(n, o, r, i) : r(i);
            e._subscribers.length = 0;
          }
        }
        function O(e, t, n, o) {
          var r = c(n),
            i = void 0,
            s = void 0,
            a = !0;
          if (r) {
            try {
              i = n(o);
            } catch (e) {
              (a = !1), (s = e);
            }
            if (t === i)
              return void P(
                t,
                new TypeError(
                  "A promises callback cannot return that same promise."
                )
              );
          } else i = o;
          t._state === C &&
            (r && a
              ? b(t, i)
              : !1 === a
              ? P(t, s)
              : e === E
              ? I(t, i)
              : e === S && P(t, i));
        }
        var A = 0;
        function U(e) {
          (e[_] = A++),
            (e._state = void 0),
            (e._result = void 0),
            (e._subscribers = []);
        }
        (M.prototype._enumerate = function (e) {
          for (var t = 0; this._state === C && t < e.length; t++)
            this._eachEntry(e[t], t);
        }),
          (M.prototype._eachEntry = function (t, e) {
            var n = this._instanceConstructor,
              o = n.resolve;
            if (o === y) {
              var r,
                i = void 0,
                s = void 0,
                a = !1;
              try {
                i = t.then;
              } catch (e) {
                (a = !0), (s = e);
              }
              i === v && t._state !== C
                ? this._settledAt(t._state, e, t._result)
                : "function" != typeof i
                ? (this._remaining--, (this._result[e] = t))
                : n === k
                ? ((r = new n(w)),
                  a ? P(r, s) : T(r, t, i),
                  this._willSettleAt(r, e))
                : this._willSettleAt(
                    new n(function (e) {
                      return e(t);
                    }),
                    e
                  );
            } else this._willSettleAt(o(t), e);
          }),
          (M.prototype._settledAt = function (e, t, n) {
            var o = this.promise;
            o._state === C &&
              (this._remaining--, e === S ? P(o, n) : (this._result[t] = n)),
              0 === this._remaining && I(o, this._result);
          }),
          (M.prototype._willSettleAt = function (e, t) {
            var n = this;
            D(
              e,
              void 0,
              function (e) {
                return n._settledAt(E, t, e);
              },
              function (e) {
                return n._settledAt(S, t, e);
              }
            );
          });
        var G = M;
        function M(e, t) {
          (this._instanceConstructor = e),
            (this.promise = new e(w)),
            this.promise[_] || U(this.promise),
            n(t)
              ? ((this.length = t.length),
                (this._remaining = t.length),
                (this._result = new Array(this.length)),
                (0 !== this.length &&
                  ((this.length = this.length || 0),
                  this._enumerate(t),
                  0 !== this._remaining)) ||
                  I(this.promise, this._result))
              : P(
                  this.promise,
                  new Error("Array Methods must be provided an Array")
                );
        }
        (L.prototype.catch = function (e) {
          return this.then(null, e);
        }),
          (L.prototype.finally = function (t) {
            var n = this.constructor;
            return c(t)
              ? this.then(
                  function (e) {
                    return n.resolve(t()).then(function () {
                      return e;
                    });
                  },
                  function (e) {
                    return n.resolve(t()).then(function () {
                      throw e;
                    });
                  }
                )
              : this.then(t, t);
          });
        var k = L;
        function L(e) {
          if (
            ((this[_] = A++),
            (this._result = this._state = void 0),
            (this._subscribers = []),
            w !== e)
          ) {
            if ("function" != typeof e)
              throw new TypeError(
                "You must pass a resolver function as the first argument to the promise constructor"
              );
            if (!(this instanceof L))
              throw new TypeError(
                "Failed to construct 'Promise': Please use the 'new' operator, this object constructor cannot be called as a function."
              );
            var t = this;
            try {
              e(
                function (e) {
                  b(t, e);
                },
                function (e) {
                  P(t, e);
                }
              );
            } catch (e) {
              P(t, e);
            }
          }
        }
        return (
          (k.prototype.then = v),
          (k.all = function (e) {
            return new G(this, e).promise;
          }),
          (k.race = function (r) {
            var i = this;
            return n(r)
              ? new i(function (e, t) {
                  for (var n = r.length, o = 0; o < n; o++)
                    i.resolve(r[o]).then(e, t);
                })
              : new i(function (e, t) {
                  return t(new TypeError("You must pass an array to race."));
                });
          }),
          (k.resolve = y),
          (k.reject = function (e) {
            var t = new this(w);
            return P(t, e), t;
          }),
          (k._setScheduler = function (e) {
            r = e;
          }),
          (k._setAsap = function (e) {
            s = e;
          }),
          (k._asap = s),
          (k.polyfill = function () {
            var e = void 0;
            if (void 0 !== se) e = se;
            else if ("undefined" != typeof self) e = self;
            else
              try {
                e = Function("return this")();
              } catch (e) {
                throw new Error(
                  "polyfill failed because global object is unavailable in this environment"
                );
              }
            var t = e.Promise;
            if (t) {
              var n = null;
              try {
                n = Object.prototype.toString.call(t.resolve());
              } catch (e) {}
              if ("[object Promise]" === n && !t.cast) return;
            }
            e.Promise = k;
          }),
          (k.Promise = k)
        );
      }),
      (k.exports = ie()),
      k.exports.polyfill),
    k =
      ((L.LoadPolyfills = function () {
        L.DefineIsArray(),
          L.DefineIndexOf(),
          L.DefineFilter(),
          L.DefinePromise();
      }),
      (L.DefinePromise = function () {
        window.Promise || ae();
      }),
      (L.DefineIsArray = function () {
        Array.isArray ||
          (Array.isArray = function (e) {
            return "[object Array]" === Object.prototype.toString.call(e);
          });
      }),
      (L.DefineIndexOf = function () {
        Array.prototype.indexOf ||
          (Array.prototype.indexOf = function (e, t) {
            if ((void 0 === t && (t = 0), void 0 === this))
              throw new TypeError("'this' is null or not defined");
            var n = this.length;
            if (0 !== n && !(n <= t))
              for (var o = Math.max(0 <= t ? t : n - Math.abs(t), 0); o < n; ) {
                if (o in this && this[o] === e) return o;
                o++;
              }
            return -1;
          });
      }),
      (L.DefineFilter = function () {
        Array.prototype.filter ||
          (Array.prototype.filter = function (e) {
            if (void 0 === this) throw new TypeError();
            var t = this.length;
            if ("function" != typeof e) throw new TypeError();
            for (
              var n,
                o = [],
                r = 2 <= arguments.length ? arguments[1] : void 0,
                i = 0;
              i < t;
              i++
            )
              i in this && ((n = this[i]), e.call(r, n, i, this)) && o.push(n);
            return o;
          });
      }),
      L);
  function L() {}
  window.criteo_pubtag ||
    (k.LoadPolyfills(),
    (window.criteo_pubtag = new R()),
    (window.criteo_identitytag_110615 = window.criteo_pubtag)),
    (window.Criteo = window.Criteo || {}),
    (window.Criteo_identitytag_110615 = window.Criteo);
})();
