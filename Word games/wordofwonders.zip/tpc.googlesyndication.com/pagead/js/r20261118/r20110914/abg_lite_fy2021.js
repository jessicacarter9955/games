(function () {
  "use strict"; /* 
 
 Copyright The Closure Library Authors. 
 SPDX-License-Identifier: Apache-2.0 
*/
  var l = this || self;
  function ba(a) {
    l.setTimeout(() => {
      throw a;
    }, 0);
  }
  var ca, q;
  a: {
    for (var da = ["CLOSURE_FLAGS"], r = l, ea = 0; ea < da.length; ea++)
      if (((r = r[da[ea]]), r == null)) {
        q = null;
        break a;
      }
    q = r;
  }
  var fa = q && q[748402147];
  ca = fa != null ? fa : !0;
  function ha(a) {
    ha[" "](a);
    return a;
  }
  ha[" "] = function () {};
  var ia = void 0;
  function ja(a, b = !1) {
    return b && Symbol.for && a
      ? Symbol.for(a)
      : a != null
      ? Symbol(a)
      : Symbol();
  }
  var ka = ja(),
    t = ja("m_m", !0);
  var w = ja("jas", !0);
  var z = {};
  function A(a, b) {
    return b === void 0
      ? a.i !== D && !!(2 & (a.h[w] | 0))
      : !!(2 & b) && a.i !== D;
  }
  var D = {};
  function la(a) {
    a.W = !0;
    return a;
  }
  var ma = la((a) => typeof a === "number"),
    na = la((a) => typeof a === "string");
  var qa = la((a) => a >= oa && a <= pa),
    oa = BigInt(Number.MIN_SAFE_INTEGER),
    pa = BigInt(Number.MAX_SAFE_INTEGER);
  var ra = Number.isFinite;
  function E(a) {
    if (a == null) return a;
    if (typeof a === "string" && a) a = +a;
    else if (typeof a !== "number") return;
    return ra(a) ? a | 0 : void 0;
  }
  function sa(a) {
    return a;
  }
  function ta(a, b, c, d) {
    var e = d !== void 0;
    d = !!d;
    var f = [],
      g = a.length,
      h = 4294967295,
      k = !1,
      n = !!(b & 64),
      m = n ? (b & 128 ? 0 : -1) : void 0;
    if (!(b & 1)) {
      var v = g && a[g - 1];
      v != null && typeof v === "object" && v.constructor === Object
        ? (g--, (h = g))
        : (v = void 0);
      !n ||
        b & 128 ||
        e ||
        ((k = !0), (h = (ua ?? sa)(h - m, m, a, v, void 0) + m));
    }
    b = void 0;
    for (e = 0; e < g; e++) {
      let p = a[e];
      if (p != null && (p = c(p, d)) != null)
        if (n && e >= h) {
          let u = e - m;
          (b ?? (b = {}))[u] = p;
        } else f[e] = p;
    }
    if (v)
      for (let p in v) {
        a = v[p];
        if (a == null || (a = c(a, d)) == null) continue;
        g = +p;
        let u;
        n && !Number.isNaN(g) && (u = g + m) < h
          ? (f[u] = a)
          : ((b ?? (b = {}))[p] = a);
      }
    b && (k ? f.push(b) : (f[h] = b));
    return f;
  }
  function va(a) {
    switch (typeof a) {
      case "number":
        return Number.isFinite(a) ? a : "" + a;
      case "bigint":
        return qa(a) ? Number(a) : "" + a;
      case "boolean":
        return a ? 1 : 0;
      case "object":
        if (Array.isArray(a)) {
          let b = a[w] | 0;
          return a.length === 0 && b & 1 ? void 0 : ta(a, b, va);
        }
        if (a != null && a[t] === z) return wa(a);
        return;
    }
    return a;
  }
  var ua;
  function wa(a) {
    a = a.h;
    return ta(a, a[w] | 0, va);
  }
  function za(a, b, c, d = 0) {
    if (a == null) {
      var e = 32;
      c ? ((a = [c]), (e |= 128)) : (a = []);
      b && (e = (e & -16760833) | ((b & 1023) << 14));
    } else {
      if (!Array.isArray(a)) throw Error("narr");
      e = a[w] | 0;
      if (ca && 1 & e) throw Error("rfarr");
      2048 & e && !(2 & e) && Aa();
      if (e & 256) throw Error("farr");
      if (e & 64) return (e | d) !== e && (a[w] = e | d), a;
      if (c && ((e |= 128), c !== a[0])) throw Error("mid");
      a: {
        c = a;
        e |= 64;
        var f = c.length;
        if (f) {
          var g = f - 1;
          let k = c[g];
          if (k != null && typeof k === "object" && k.constructor === Object) {
            b = e & 128 ? 0 : -1;
            g -= b;
            if (g >= 1024) throw Error("pvtlmt");
            for (var h in k)
              if (((f = +h), f < g)) (c[f + b] = k[h]), delete k[h];
              else break;
            e = (e & -16760833) | ((g & 1023) << 14);
            break a;
          }
        }
        if (b) {
          h = Math.max(b, f - (e & 128 ? 0 : -1));
          if (h > 1024) throw Error("spvt");
          e = (e & -16760833) | ((h & 1023) << 14);
        }
      }
    }
    a[w] = e | 64 | d;
    return a;
  }
  function Aa() {
    if (ca) throw Error("carr");
    if (ka != null) {
      var a = ia ?? (ia = {});
      var b = a[ka] || 0;
      b >= 5 ||
        ((a[ka] = b + 1),
        (a = Error()),
        a.__closure__error__context__984382 ||
          (a.__closure__error__context__984382 = {}),
        (a.__closure__error__context__984382.severity = "incident"),
        ba(a));
    }
  }
  function Ba(a, b) {
    if (typeof a !== "object") return a;
    if (Array.isArray(a)) {
      var c = a[w] | 0;
      a.length === 0 && c & 1
        ? (a = void 0)
        : c & 2 ||
          (!b || 4096 & c || 16 & c
            ? (a = G(a, c, !1, b && !(c & 16)))
            : ((a[w] |= 34), c & 4 && Object.freeze(a)));
      return a;
    }
    if (a != null && a[t] === z)
      return (
        (b = a.h),
        (c = b[w] | 0),
        A(a, c) ? a : Ca(a, b, c) ? Da(a, b) : G(b, c)
      );
  }
  function Da(a, b, c) {
    a = new a.constructor(b);
    c && (a.i = D);
    a.j = D;
    return a;
  }
  function G(a, b, c, d) {
    d ?? (d = !!(34 & b));
    a = ta(a, b, Ba, d);
    d = 32;
    c && (d |= 2);
    b = (b & 16769217) | d;
    a[w] = b;
    return a;
  }
  function Ea(a, b) {
    b === void 0 && (b = a[w] | 0);
    b & 32 && !(b & 4096) && (a[w] = b | 4096);
  }
  function Ca(a, b, c) {
    return c & 2
      ? !0
      : c & 32 && !(c & 4096)
      ? ((b[w] = c | 2), (a.i = D), !0)
      : !1;
  }
  function H(a, b) {
    a = Fa(a.h, b);
    if (a !== null) return a;
  }
  function Ga(a, b) {
    return Fa(a, 1, void 0, b);
  }
  function Fa(a, b, c, d) {
    if (b === -1) return null;
    var e = b + (c ? 0 : -1),
      f = a.length - 1;
    if (!(f < 1 + (c ? 0 : -1))) {
      if (e >= f) {
        var g = a[f];
        if (g != null && typeof g === "object" && g.constructor === Object) {
          c = g[b];
          var h = !0;
        } else if (e === f) c = g;
        else return;
      } else c = a[e];
      if (d && c != null) {
        d = d(c);
        if (d == null) return d;
        if (!Object.is(d, c)) return h ? (g[b] = d) : (a[e] = d), d;
      }
      return c;
    }
  }
  function Ha(a) {
    a = Fa(a.h, 1);
    return (a != null && a[t] === z) || Array.isArray(a);
  }
  function Ia(a, b) {
    var c = Ja,
      d = !1,
      e = Ga(a, (f) => {
        if (f != null && f[t] === z) var g = f;
        else if (Array.isArray(f)) {
          g = f[w] | 0;
          let h;
          h = g | (b & 32);
          h |= b & 2;
          h !== g && (f[w] = h);
          g = new c(f);
        } else g = void 0;
        d = g !== f && g != null;
        return g;
      });
    if (e != null) return d && !A(e) && Ea(a, b), e;
  }
  function Ka(a) {
    var b = a.h,
      c = b[w] | 0,
      d = Ia(b, c);
    if (d == null) return d;
    c = b[w] | 0;
    if (!A(a, c)) {
      var e = d;
      var f = e.h,
        g = f[w] | 0;
      e = A(e, g)
        ? Ca(e, f, g)
          ? Da(e, f, !0)
          : new e.constructor(G(f, g, !1))
        : e;
      if (e !== d) {
        a.i === D
          ? ((d = a.h),
            (d = G(d, d[w] | 0)),
            (d[w] |= 2048),
            (a.h = d),
            (a.i = void 0),
            (a.j = void 0),
            (d = !0))
          : (d = !1);
        d && ((b = a.h), (c = b[w] | 0));
        d = e;
        a: {
          a = b;
          e = d;
          f = a.length - 1;
          if (
            f >= 0 &&
            0 >= f &&
            ((g = a[f]),
            g != null && typeof g === "object" && g.constructor === Object)
          ) {
            g[1] = e;
            break a;
          }
          0 <= f
            ? (a[0] = e)
            : e !== void 0 &&
              ((f = ((c ?? (c = a[w] | 0)) >> 14) & 1023 || 536870912),
              1 >= f ? e != null && (a[f + -1] = { [1]: e }) : (a[0] = e));
        }
        Ea(b, c);
      }
    }
    return d;
  }
  function I(a, b) {
    a = H(a, b);
    return a == null || typeof a === "string" ? a : void 0;
  }
  function J(a, b) {
    a = H(a, b);
    return (
      (a == null || typeof a === "boolean"
        ? a
        : typeof a === "number"
        ? !!a
        : void 0) ?? !1
    );
  }
  var La = class {
    constructor(a) {
      this.h = za(a, void 0, void 0, 2048);
    }
    toJSON() {
      return wa(this);
    }
  };
  La.prototype[t] = z;
  var Ja = class extends La {};
  var Ma = (function (a) {
    return (b) => {
      if (b == null || b == "") b = new a();
      else {
        b = JSON.parse(b);
        if (!Array.isArray(b)) throw Error("dnarr");
        b[w] |= 32;
        b = new a(b);
      }
      return b;
    };
  })(class extends La {});
  function Na(a, b) {
    if (a)
      for (let c in a)
        Object.prototype.hasOwnProperty.call(a, c) && b(a[c], c, a);
  }
  function Oa(a) {
    var b = !1,
      c;
    return function () {
      b || ((c = a()), (b = !0));
      return c;
    };
  } /* 
 
 Copyright Google LLC 
 SPDX-License-Identifier: Apache-2.0 
*/
  var Pa = globalThis.trustedTypes,
    Qa;
  function Ra() {
    var a = null;
    if (!Pa) return a;
    try {
      let b = (c) => c;
      a = Pa.createPolicy("goog#html", {
        createHTML: b,
        createScript: b,
        createScriptURL: b,
      });
    } catch (b) {}
    return a;
  }
  var Sa = class {
    constructor(a) {
      this.h = a;
    }
    toString() {
      return this.h + "";
    }
  };
  function Ta(a = document) {
    a = a.querySelector?.("script[nonce]");
    return a == null ? "" : a.nonce || a.getAttribute("nonce") || "";
  }
  function Ua(a, b = document) {
    return b.createElement(String(a).toLowerCase());
  }
  function K(a) {
    var b = document;
    return typeof a === "string" ? b.getElementById(a) : a;
  }
  function Va(a) {
    var b = document;
    if (b.getElementsByClassName) a = b.getElementsByClassName(a)[0];
    else {
      b = document;
      var c;
      a
        ? (c = b.querySelector(a ? "." + a : ""))
        : (c =
            (a
              ? b.querySelectorAll(a ? "." + a : "")
              : b.getElementsByTagName("*"))[0] || null);
      a = c;
    }
    return a || null;
  }
  function Wa(a) {
    a && a.parentNode && a.parentNode.removeChild(a);
  }
  var Xa = { passive: !0 },
    Ya = Oa(() => {
      var a = !1;
      try {
        let b = Object.defineProperty({}, "passive", {
          get() {
            a = !0;
          },
        });
        l.addEventListener("test", null, b);
      } catch (b) {}
      return a;
    });
  function Za(a) {
    return a ? (a.passive && Ya() ? a : a.capture || !1) : !1;
  }
  function L(a, b, c, d) {
    typeof a.addEventListener === "function" && a.addEventListener(b, c, Za(d));
  }
  function M(a) {
    a.preventDefault ? a.preventDefault() : (a.returnValue = !1);
  }
  function $a(a, b, c = null, d = !1) {
    ab(a, b, c, d);
  }
  function ab(a, b, c, d) {
    a.google_image_requests || (a.google_image_requests = []);
    var e = Ua("IMG", a.document);
    if (c || d) {
      let f = (g) => {
        c && c(g);
        if (d) {
          g = a.google_image_requests;
          let h = Array.prototype.indexOf.call(g, e, void 0);
          h >= 0 && Array.prototype.splice.call(g, h, 1);
        }
        typeof e.removeEventListener === "function" &&
          e.removeEventListener("load", f, Za());
        typeof e.removeEventListener === "function" &&
          e.removeEventListener("error", f, Za());
      };
      L(e, "load", f);
      L(e, "error", f);
    }
    e.src = b;
    a.google_image_requests.push(e);
  }
  function bb(a, b) {
    var c;
    if ((c = a.navigator))
      (c = a.navigator.userAgent), (c = !(!/Chrome/.test(c) || /Edge/.test(c)));
    c && typeof a.navigator.sendBeacon === "function"
      ? a.navigator.sendBeacon(b)
      : $a(a, b, void 0, !1);
  }
  var cb = 0;
  function db(a) {
    return (
      ((a = ib(a, document.currentScript)) &&
        a.getAttribute("data-jc-version")) ||
      "unknown"
    );
  }
  function ib(a, b = null) {
    return b && b.getAttribute("data-jc") === String(a)
      ? b
      : document.querySelector(`[data-jc="${a}"]`);
  }
  function jb() {
    if (!(Math.random() > 0.01)) {
      var a = ib(60, document.currentScript);
      a = `https://${
        a && a.getAttribute("data-jc-rcd") === "true"
          ? "pagead2.googlesyndication-cn.com"
          : "pagead2.googlesyndication.com"
      }/pagead/gen_204?id=jca&jc=60&version=${db(60)}&sample=0.01`;
      bb(window, a);
    }
  }
  var kb = document,
    N = window;
  function lb(a) {
    return typeof a.className == "string"
      ? a.className
      : (a.getAttribute && a.getAttribute("class")) || "";
  }
  function mb(a, b) {
    a.classList
      ? (b = a.classList.contains(b))
      : ((a = a.classList ? a.classList : lb(a).match(/\S+/g) || []),
        (b = Array.prototype.indexOf.call(a, b, void 0) >= 0));
    return b;
  }
  function O(a, b) {
    if (a.classList) a.classList.add(b);
    else if (!mb(a, b)) {
      let c = lb(a);
      b = c + (c.length > 0 ? " " + b : b);
      typeof a.className == "string"
        ? (a.className = b)
        : a.setAttribute && a.setAttribute("class", b);
    }
  }
  var nb = class {
    constructor(a) {
      this.serializedAttributionData = wa(a);
      var b = a.h,
        c = b[w] | 0;
      this.h = Ca(a, b, c) ? Da(a, b, !0) : new a.constructor(G(b, c, !1));
      if ((a = Ha(this.h))) (a = Ka(this.h)), (a = !!J(a, 33));
      this.isMutableImpression = a;
      this.S = !!J(this.h, 11);
      this.hasUserFeedbackData = !!this.h && Ha(this.h);
      this.L = !!J(this.h, 4);
      this.O = !!J(this.h, 6);
      this.K = !!J(this.h, 13);
      E(H(this.h, 8));
      this.creativeIndexSuffix =
        (E(H(this.h, 8)) ?? 0) > 1 ? (E(H(this.h, 7)) ?? 0).toString() : "";
      I(this.h, 34) != null &&
        (this.creativeIndexSuffix =
          (I(this.h, 34) ?? "") + "_" + this.creativeIndexSuffix);
      this.T = !!J(this.h, 17);
      this.R = !!J(this.h, 18);
      this.J = !!J(this.h, 14);
      this.F = !!J(this.h, 15);
      this.U = !!J(this.h, 31);
      this.P = J(this.h, 9) == 1;
      this.openAttributionInline = J(this.h, 10) == 1;
      this.isMobileDevice = !!J(this.h, 12);
      this.B = null;
      this.N = (a = kb.querySelector("[data-slide]"))
        ? a.getAttribute("data-slide") === "true"
        : !1;
      (this.H = (E(H(this.h, 8)) ?? 0) > 1) &&
        N.goog_multislot_cache === void 0 &&
        (N.goog_multislot_cache = {});
      this.H && !this.N
        ? ((a = N.goog_multislot_cache.hd),
          a === void 0 &&
            ((a = !1),
            (b = kb.querySelector("[data-dim]"))
              ? ((b = b.getBoundingClientRect()),
                b.right - b.left >= 150 && b.bottom - b.top >= 150
                  ? (a = !1)
                  : ((c = document.body.getBoundingClientRect()),
                    (Math.abs(c.left - b.left) <= 1 &&
                    Math.abs(c.right - b.right) <= 1
                      ? b.bottom - b.top
                      : b.right - b.left) < 150 && (a = !0)))
              : (a = !1),
            (window.goog_multislot_cache.hd = a)))
        : (a = !1);
      this.G = a;
      this.v = K("abgcp" + this.creativeIndexSuffix);
      this.C = K("abgc" + this.creativeIndexSuffix);
      this.i = K("abgs" + this.creativeIndexSuffix);
      K("abgl" + this.creativeIndexSuffix);
      this.u = K("abgb" + this.creativeIndexSuffix);
      this.D = K("abgac" + this.creativeIndexSuffix);
      K("mute_panel" + this.creativeIndexSuffix);
      this.A = Va("goog_delegate_attribution" + this.creativeIndexSuffix);
      this.isDelegateAttributionActive =
        !!this.A && !!this.J && !Va("goog_delegate_disabled") && !this.F;
      if (this.i)
        a: for (a = this.i, b = a.childNodes, c = 0; c < b.length; c++) {
          let d = b.item(c);
          if (
            typeof d.tagName != "undefined" &&
            d.tagName.toUpperCase() == "A"
          ) {
            a = d;
            break a;
          }
        }
      else a = null;
      this.m = a;
      this.l = this.isDelegateAttributionActive
        ? this.A
        : K("cbb" + this.creativeIndexSuffix);
      this.M = this.G ? this.creativeIndexSuffix === "0" : !0;
      this.enableDelegateDismissableMenu =
        !!this.l && mb(this.l, "goog_dismissable_menu");
      this.o = null;
      this.I = 0;
      this.j = this.isDelegateAttributionActive
        ? this.A
        : this.O && this.v
        ? this.v
        : this.C;
      this.autoExpandOnLoad = !!J(this.h, 19);
      this.adbadgeEnabled = !!J(this.h, 24);
      this.enableNativeJakeUi = !!J(this.h, 27);
    }
  };
  var ob = class {
    constructor(a, b) {
      if (!a) throw Error("bad conv util ctor args");
      this.i = a;
      this.h = b;
    }
  };
  var pb = class {
    constructor(a, b) {
      this.error = a;
      this.meta = {};
      this.context = b.context;
      this.msg = b.message || "";
      this.id = b.id || "jserror";
    }
  };
  function qb(a) {
    var b = a.toString();
    a.name && b.indexOf(a.name) == -1 && (b += ": " + a.name);
    a.message && b.indexOf(a.message) == -1 && (b += ": " + a.message);
    if (a.stack)
      a: {
        a = a.stack;
        var c = b;
        try {
          a.indexOf(c) == -1 && (a = c + "\n" + a);
          let d;
          for (; a != d; )
            (d = a),
              (a = a.replace(
                RegExp("((https?:/..*/)[^/:]*:\\d+(?:.|\n)*)\\2"),
                "$1"
              ));
          b = a.replace(RegExp("\n *", "g"), "\n");
          break a;
        } catch (d) {
          b = c;
          break a;
        }
        b = void 0;
      }
    return b;
  }
  var rb = RegExp("^https?://(\\w|-)+\\.cdn\\.ampproject\\.(net|org)(\\?|/|$)"),
    sb = class {
      constructor(a, b) {
        this.h = a;
        this.i = b;
      }
    },
    tb = class {
      constructor(a, b) {
        this.url = a;
        this.h = !!b;
        this.depth = null;
      }
    };
  var P = null;
  function ub() {
    var a = l.performance;
    return a && a.now && a.timing
      ? Math.floor(a.now() + a.timing.navigationStart)
      : Date.now();
  }
  function vb() {
    var a = l.performance;
    return a && a.now ? a.now() : null;
  }
  var wb = class {
    constructor(a, b) {
      var c = vb() || ub();
      this.label = a;
      this.type = b;
      this.value = c;
      this.duration = 0;
      this.taskId = this.slotId = void 0;
      this.uniqueId = Math.random();
    }
  };
  var Q = l.performance,
    xb = !!(Q && Q.mark && Q.measure && Q.clearMarks),
    R = Oa(() => {
      var a;
      if ((a = xb)) {
        var b;
        a = window;
        if (P === null) {
          P = "";
          try {
            let c = "";
            try {
              c = a.top.location.hash;
            } catch (d) {
              c = a.location.hash;
            }
            c && (P = (b = c.match(/\bdeid=([\d,]+)/)) ? b[1] : "");
          } catch (c) {}
        }
        b = P;
        a = !!b.indexOf && b.indexOf("1337") >= 0;
      }
      return a;
    });
  function yb(a) {
    a &&
      Q &&
      R() &&
      (Q.clearMarks(`goog_${a.label}_${a.uniqueId}_start`),
      Q.clearMarks(`goog_${a.label}_${a.uniqueId}_end`));
  }
  function T(a, b) {
    var c = {};
    c[a] = b;
    return [c];
  }
  function zb(a, b, c, d, e) {
    var f = [];
    Na(a, (g, h) => {
      (g = Ab(g, b, c, d, e)) && f.push(`${encodeURIComponent(h)}=${g}`);
    });
    return f.join(b);
  }
  function Ab(a, b, c, d, e) {
    if (a == null) return "";
    b = b || "&";
    c = c || ",$";
    na(c) && (c = c.split(""));
    if (a instanceof Array) {
      if ((d || (d = 0), d < c.length)) {
        let f = [];
        for (let g = 0; g < a.length; g++) f.push(Ab(a[g], b, c, d + 1, e));
        return f.join(c[d]);
      }
    } else if (typeof a === "object")
      return (
        e || (e = 0), e < 2 ? encodeURIComponent(zb(a, b, c, d, e + 1)) : "..."
      );
    return encodeURIComponent(String(a));
  }
  function Bb(a) {
    var b = 1;
    for (let c in a.i) c.length > b && (b = c.length);
    return 3997 - b - a.j.length - 1;
  }
  function Cb(a, b) {
    var c = Bb(a) - b.length;
    if (c < 0) return "";
    b = "";
    a.h.sort((f, g) => f - g);
    var d = null,
      e = "";
    for (let f = 0; f < a.h.length; f++) {
      let g = a.h[f],
        h = a.i[g];
      for (let k = 0; k < h.length; k++) {
        if (!c) {
          d = d == null ? g : d;
          break;
        }
        let n = zb(h[k], a.j, ",$");
        if (n) {
          n = e + n;
          if (c >= n.length) {
            c -= n.length;
            b += n;
            e = a.j;
            break;
          }
          d = d == null ? g : d;
        }
      }
    }
    a = "";
    d != null && (a = `${e}trn=${d}`);
    return b + a;
  }
  function Db(a, b, c, d) {
    return Bb(a) - d.length < 0 ? "" : b + "//" + c + d + Cb(a, d);
  }
  var Eb = class {
    constructor() {
      this.j = "&";
      this.i = {};
      this.l = 0;
      this.h = [];
    }
  };
  var Fb = RegExp(
    "^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$"
  );
  function Gb(a, b, c) {
    try {
      if (a.h && a.h.h) {
        var d = a.h.start(b.toString(), 3);
        var e = c();
        a.h.end(d);
      } else e = c();
    } catch (f) {
      c = !0;
      try {
        yb(d), (c = a.m(b, new pb(f, { message: qb(f) }), void 0, void 0));
      } catch (g) {
        a.l(217, g);
      }
      if (c) window.console?.error?.(f);
      else throw f;
    }
    return e;
  }
  function Hb(a, b) {
    var c = U;
    return (...d) => Gb(c, a, () => b.apply(void 0, d));
  }
  var Kb = class {
    constructor(a = null) {
      this.pinger = Ib;
      this.h = a;
      this.i = null;
      this.j = !1;
      this.m = this.l;
    }
    l(a, b, c, d, e) {
      e = e || "jserror";
      var f = void 0;
      try {
        let B = new Eb();
        var g = B;
        g.h.push(1);
        g.i[1] = T("context", a);
        (b.error && b.meta && b.id) || (b = new pb(b, { message: qb(b) }));
        g = b;
        if (g.msg) {
          b = B;
          var h = g.msg.substring(0, 512);
          b.h.push(2);
          b.i[2] = T("msg", h);
        }
        var k = g.meta || {};
        h = k;
        if (this.i)
          try {
            this.i(h);
          } catch (y) {}
        if (d)
          try {
            d(h);
          } catch (y) {}
        d = B;
        k = [k];
        d.h.push(3);
        d.i[3] = k;
        var n;
        if (!(n = u)) {
          d = l;
          k = [];
          let y;
          h = null;
          do {
            var m = d;
            try {
              var v;
              if ((v = !!m && m.location.href != null))
                b: {
                  try {
                    ha(m.foo);
                    v = !0;
                    break b;
                  } catch (x) {}
                  v = !1;
                }
              var p = v;
            } catch {
              p = !1;
            }
            p
              ? ((y = m.location.href),
                (h = (m.document && m.document.referrer) || null))
              : ((y = h), (h = null));
            k.push(new tb(y || ""));
            try {
              d = m.parent;
            } catch (x) {
              d = null;
            }
          } while (d && m !== d);
          for (let x = 0, eb = k.length - 1; x <= eb; ++x) k[x].depth = eb - x;
          m = l;
          if (
            m.location &&
            m.location.ancestorOrigins &&
            m.location.ancestorOrigins.length === k.length - 1
          )
            for (p = 1; p < k.length; ++p) {
              let x = k[p];
              x.url ||
                ((x.url = m.location.ancestorOrigins[p - 1] || ""), (x.h = !0));
            }
          n = k;
        }
        var u = n;
        let aa = new tb(l.location.href, !1);
        n = null;
        let xa = u.length - 1;
        for (m = xa; m >= 0; --m) {
          var C = u[m];
          !n && rb.test(C.url) && (n = C);
          if (C.url && !C.h) {
            aa = C;
            break;
          }
        }
        C = null;
        let Vb = u.length && u[xa].url;
        aa.depth !== 0 && Vb && (C = u[xa]);
        f = new sb(aa, C);
        if (f.i) {
          u = B;
          var F = f.i.url || "";
          u.h.push(4);
          u.i[4] = T("top", F);
        }
        var ya = { url: f.h.url || "" };
        if (f.h.url) {
          let y = f.h.url.match(Fb);
          var S = y[1],
            fb = y[3],
            gb = y[4];
          F = "";
          S && (F += S + ":");
          fb && ((F += "//"), (F += fb), gb && (F += ":" + gb));
          var hb = F;
        } else hb = "";
        S = B;
        ya = [ya, { url: hb }];
        S.h.push(5);
        S.i[5] = ya;
        Jb(this.pinger, e, B, this.j, c);
      } catch (B) {
        try {
          Jb(
            this.pinger,
            e,
            { context: "ecmserr", rctx: a, msg: qb(B), url: f?.h.url ?? "" },
            this.j,
            c
          );
        } catch (aa) {}
      }
      return !0;
    }
  };
  function Jb(a, b, c, d = !1, e) {
    if ((d ? a.i : Math.random()) < (e || a.l))
      try {
        let f;
        c instanceof Eb
          ? (f = c)
          : ((f = new Eb()),
            Na(c, (h, k) => {
              var n = f,
                m = n.l++;
              h = T(k, h);
              n.h.push(m);
              n.i[m] = h;
            }));
        let g = Db(f, a.protocol, a.h(), a.path + b + "&");
        g && (a.j ? bb(l, g) : $a(l, g));
      } catch (f) {}
  }
  function Lb() {
    var a = Ib,
      b = window.google_srt;
    b >= 0 && b <= 1 && (a.i = b);
  }
  var Mb = class {
    constructor(a, b, c, d = !1) {
      this.domain = a;
      this.path = b;
      this.l = c;
      this.j = d;
      this.protocol = "https:";
      this.i = Math.random();
    }
    h() {
      return this.domain;
    }
  };
  var Ib,
    U,
    Nb = !1;
  class Ob extends Mb {
    h() {
      if (Nb) {
        ({ V: a = !1 } = { V: !0 });
        var a = a
          ? "connect.pagead2.googlesyndication.com"
          : "pagead2.googlesyndication.com";
      } else a = super.h();
      return a;
    }
  }
  var V = new (class {
    constructor(a, b) {
      this.i = [];
      this.j = b || l;
      var c = null;
      b &&
        ((b.google_js_reporting_queue = b.google_js_reporting_queue || []),
        (this.i = b.google_js_reporting_queue),
        (c = b.google_measure_js_timing));
      this.h = R() || (c != null ? c : Math.random() < a);
    }
    start(a, b) {
      if (!this.h) return null;
      a = new wb(a, b);
      b = `goog_${a.label}_${a.uniqueId}_start`;
      Q && R() && Q.mark(b);
      return a;
    }
    end(a) {
      if (this.h && ma(a.value)) {
        a.duration = (vb() || ub()) - a.value;
        var b = `goog_${a.label}_${a.uniqueId}_end`;
        Q && R() && Q.mark(b);
        !this.h || this.i.length > 2048 || this.i.push(a);
      }
    }
  })(1, window);
  function Pb() {
    window.google_measure_js_timing ||
      ((V.h = !1),
      V.i !== V.j.google_js_reporting_queue &&
        (R() && Array.prototype.forEach.call(V.i, yb, void 0),
        (V.i.length = 0)));
  }
  (function (a) {
    Nb = !1;
    Ib =
      a ?? new Ob("pagead2.googlesyndication.com", "/pagead/gen_204?id=", 0.01);
    typeof window.google_srt !== "number" &&
      (window.google_srt = Math.random());
    Lb();
    U = new Kb(V);
    U.i = (b) => {
      var c = cb;
      c !== 0 && ((b.jc = String(c)), (b.shv = db(c)));
    };
    U.j = !0;
    window.document.readyState === "complete"
      ? Pb()
      : V.h &&
        L(window, "load", () => {
          Pb();
        });
  })();
  function W(a, b) {
    return Hb(a, b);
  }
  var X = (a, b) => {
    a &&
      Na(b, (c, d) => {
        a.style[d] = c;
      });
  };
  function Qb(a) {
    if (a.h.m && a.h.R) {
      let b = Ka(a.h.h);
      b &&
        I(b, 5) != null &&
        I(b, 6) != null &&
        (a.j = new ob(I(b, 5) ?? "", I(b, 19) ?? ""));
      L(
        a.h.m,
        "click",
        W(452, () => {
          if (!a.l && ((a.l = !0), a.j)) {
            var c = a.j;
            let d = c.i + "&label=closebutton_whythisad_click";
            d += "&label_instance=1";
            c.h && (d += "&cid=" + c.h);
            $a(window, d);
          }
        })
      );
    }
  }
  function Rb(a) {
    if (a.h.S)
      L(
        a.h.j,
        "click",
        W(365, (b) => {
          var c = N.goog_interstitial_display;
          c && (c(b), b && (b.stopPropagation(), b.preventDefault()));
        })
      );
    else if (a.h.isMutableImpression && a.h.isMobileDevice)
      L(a.h.j, "click", () => a.i());
    else if (
      (a.h.isMutableImpression &&
        !a.h.isMobileDevice &&
        (a.h.l &&
          (L(a.h.l, "click", () => a.i()),
          L(a.h.l, "keydown", (b) => {
            (b.code !== "Enter" && b.code !== "Space") || a.i();
          })),
        a.h.U && a.h.i && L(a.h.i, "click", () => a.i())),
      a.h.L)
    )
      Sb(a);
    else {
      L(
        a.h.j,
        "mouseover",
        W(367, () => Sb(a))
      );
      L(
        a.h.j,
        "mouseout",
        W(369, () => Tb(a, 500))
      );
      L(
        a.h.j,
        "touchstart",
        W(368, () => Sb(a)),
        Xa
      );
      let b = W(370, () => Tb(a, 4e3));
      L(a.h.j, "mouseup", b);
      L(a.h.j, "touchend", b);
      L(a.h.j, "touchcancel", b);
      a.h.m &&
        L(
          a.h.m,
          "click",
          W(371, (c) => a.preventDefault(c))
        );
    }
  }
  function Sb(a) {
    window.clearTimeout(a.h.o);
    a.h.o = null;
    (a.h.i && a.h.i.style.display == "block") ||
      ((a.h.I = Date.now()),
      a.h.u &&
        a.h.i &&
        ((a.h.u.style.display = "none"), (a.h.i.style.display = "block")));
  }
  function Tb(a, b) {
    window.clearTimeout(a.h.o);
    a.h.o = window.setTimeout(() => Ub(a), b);
  }
  function Wb(a) {
    var b = a.h.D;
    b !== void 0 &&
      ((b.style.display = "block"),
      a.h.enableNativeJakeUi &&
        window.requestAnimationFrame(() => {
          O(b, "abgacfo");
        }));
  }
  function Ub(a) {
    window.clearTimeout(a.h.o);
    a.h.o = null;
    a.h.u &&
      a.h.i &&
      ((a.h.u.style.display = "block"), (a.h.i.style.display = "none"));
  }
  class Xb {
    constructor(a, b) {
      this.h = a;
      this.i = b;
      this.h.T ||
        ((this.l = !1),
        (this.j = null),
        !this.h.G || this.h.adbadgeEnabled || this.h.M
          ? Qb(this)
          : ((a = { display: "none" }),
            (b = { width: "15px", height: "15px" }),
            this.h.isMobileDevice
              ? (X(this.h.u, a), X(this.h.i, a), X(this.h.v, b), X(this.h.C, b))
              : X(this.h.C, a)),
        Rb(this),
        this.h.enableNativeJakeUi && O(this.h.D, "abgnac"),
        this.h.isDelegateAttributionActive
          ? (O(document.body, "goog_delegate_active"), O(document.body, "jaa"))
          : (!this.h.isMutableImpression && this.h.l && Wa(this.h.l),
            setTimeout(
              () => {
                O(document.body, "jar");
              },
              this.h.K ? 750 : 100
            )),
        this.h.F && O(document.body, "goog_delegate_disabled"),
        this.h.autoExpandOnLoad && N.addEventListener("load", () => this.i()));
    }
    preventDefault(a) {
      if (
        this.h.i &&
        this.h.i.style.display == "block" &&
        Date.now() - this.h.I < 500
      )
        M(a);
      else if (this.h.openAttributionInline) {
        var b = this.h.m.getAttribute("href");
        window.adSlot
          ? window.adSlot.openAttribution(b) && M(a)
          : window.openAttribution && (window.openAttribution(b), M(a));
      } else
        this.h.P &&
          ((b = this.h.m.getAttribute("href")),
          window.adSlot
            ? window.adSlot.openSystemBrowser(b) && M(a)
            : window.openSystemBrowser && (window.openSystemBrowser(b), M(a)));
    }
  }
  function Yb(a) {
    if (!a.h && ((a.h = !0), (N.goog_delegate_deferred_token = void 0), a.i)) {
      var b = a.j;
      a = Ma(JSON.stringify(a.i));
      if (!a) throw Error("bad attrdata");
      a = new nb(a);
      new b(a);
    }
  }
  class Zb {
    constructor(a) {
      var b = $b;
      if (!b) throw Error("bad ctor");
      this.j = b;
      this.i = a;
      this.h = !1;
      Va("goog_delegate_deferred")
        ? N.goog_delegate_deferred_token !== void 0
          ? Yb(this)
          : ((a = () => {
              Yb(this);
            }),
            (N.goog_delegate_deferred_token = a),
            setTimeout(a, 5e3))
        : Yb(this);
    }
  }
  var ac = (a = []) => {
    l.google_logging_queue || (l.google_logging_queue = []);
    l.google_logging_queue.push([11, a]);
  };
  class bc {
    constructor() {
      this.promise = new Promise((a, b) => {
        this.resolve = a;
        this.reject = b;
      });
    }
  }
  function cc() {
    var { promise: a, resolve: b } = new bc();
    return { promise: a, resolve: b };
  }
  function dc(a, b = () => {}) {
    a.google_llp || (a.google_llp = {});
    a = a.google_llp;
    var c = a[5];
    if (c) return c;
    c = cc();
    a[5] = c;
    b();
    return c;
  }
  function ec(a, b) {
    return dc(a, () => {
      var c = a.document,
        d = Ua("SCRIPT", c);
      if (b instanceof Sa) var e = b.h;
      else throw Error("");
      d.src = e;
      (e = Ta(d.ownerDocument)) && d.setAttribute("nonce", e);
      (c = c.getElementsByTagName("script")[0]) &&
        c.parentNode &&
        c.parentNode.insertBefore(d, c);
    }).promise;
  }
  function fc(a) {
    a = a === null ? "null" : a === void 0 ? "undefined" : a;
    var b;
    Qa === void 0 && (Qa = Ra());
    a = (b = Qa) ? b.createScriptURL(a) : a;
    return new Sa(a);
  }
  function hc(a) {
    ac([a]);
    new Zb(a);
  }
  function ic(a) {
    a.h.B
      ? a.h.B.expandAttributionCard()
      : (Gb(U, 373, () => {
          Ub(a.i);
          Wb(a.i);
        }),
        ec(
          window,
          fc(
            `https://pagead2.googlesyndication.com${
              "/pagead/js/" + (I(a.h.h, 33) ?? "") + "/abg_survey.js"
            }`
          )
        ).then((b) => {
          b.createAttributionCard(a.h);
          a.h.B = b;
          b.expandAttributionCard();
        }),
        jb());
  }
  var $b = class {
    constructor(a) {
      this.h = a;
      this.i = new Xb(
        this.h,
        W(359, () => ic(this))
      );
    }
  };
  cb = 60;
  var jc = ib(60, document.currentScript);
  if (jc == null) throw Error("JSC not found 60");
  var kc = {},
    lc = jc.attributes;
  for (let a = lc.length - 1; a >= 0; a--) {
    let b = lc[a].name;
    b.indexOf("data-jcp-") === 0 && (kc[b.substring(9)] = lc[a].value);
  }
  if (kc["attribution-data"]) hc(JSON.parse(kc["attribution-data"]));
  else
    for (
      var mc = ["buildAttribution"], Y = l, Z;
      mc.length && (Z = mc.shift());

    )
      mc.length || hc === void 0
        ? Y[Z] && Y[Z] !== Object.prototype[Z]
          ? (Y = Y[Z])
          : (Y = Y[Z] = {})
        : (Y[Z] = hc);
}.call(this));
