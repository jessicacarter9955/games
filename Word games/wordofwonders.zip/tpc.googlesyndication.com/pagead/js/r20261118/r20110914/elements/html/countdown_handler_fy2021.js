(function () {
  "use strict";
  var ba = Object.defineProperty,
    ca = globalThis;
  function da(a, b) {
    if (b)
      a: {
        var c = ca;
        a = a.split(".");
        for (var d = 0; d < a.length - 1; d++) {
          var e = a[d];
          if (!(e in c)) break a;
          c = c[e];
        }
        a = a[a.length - 1];
        d = c[a];
        b = b(d);
        b != d &&
          b != null &&
          ba(c, a, { configurable: !0, writable: !0, value: b });
      }
  }
  da("Symbol.dispose", function (a) {
    return a ? a : Symbol("Symbol.dispose");
  }); /* 
 
 Copyright The Closure Library Authors. 
 SPDX-License-Identifier: Apache-2.0 
*/
  var l = this || self;
  function ea(a) {
    l.setTimeout(() => {
      throw a;
    }, 0);
  }
  var fa, m;
  a: {
    for (var ha = ["CLOSURE_FLAGS"], q = l, ia = 0; ia < ha.length; ia++)
      if (((q = q[ha[ia]]), q == null)) {
        m = null;
        break a;
      }
    m = q;
  }
  var ja = m && m[748402147];
  fa = ja != null ? ja : !0;
  function t() {
    var a = l.navigator;
    return a && (a = a.userAgent) ? a : "";
  }
  function ka(a) {
    ka[" "](a);
    return a;
  }
  ka[" "] = function () {};
  var la = t().indexOf("Edge") != -1,
    ma =
      t().indexOf("Gecko") != -1 &&
      !(
        t().toLowerCase().indexOf("webkit") != -1 && t().indexOf("Edge") == -1
      ) &&
      !(t().indexOf("Trident") != -1 || t().indexOf("MSIE") != -1) &&
      t().indexOf("Edge") == -1,
    na = t().toLowerCase().indexOf("webkit") != -1 && t().indexOf("Edge") == -1;
  var oa = void 0;
  function pa(a, b = !1) {
    return b && Symbol.for && a
      ? Symbol.for(a)
      : a != null
      ? Symbol(a)
      : Symbol();
  }
  var qa = pa(),
    w = pa("m_m", !0);
  var y = pa("jas", !0);
  var z = {};
  function E(a, b) {
    return b === void 0
      ? a.i !== F && !!(2 & (a.h[y] | 0))
      : !!(2 & b) && a.i !== F;
  }
  var F = {};
  function ra(a) {
    a.fa = !0;
    return a;
  }
  var ua = ra((a) => typeof a === "number"),
    va = ra((a) => typeof a === "string");
  var ya = ra((a) => a >= wa && a <= xa),
    wa = BigInt(Number.MIN_SAFE_INTEGER),
    xa = BigInt(Number.MAX_SAFE_INTEGER);
  var za = Number.isFinite;
  function Aa(a) {
    if (a == null) return a;
    if (typeof a === "string" && a) a = +a;
    else if (typeof a !== "number") return;
    return za(a) ? a | 0 : void 0;
  }
  function Ba(a) {
    return a;
  }
  function Ca(a, b, c, d) {
    var e = d !== void 0;
    d = !!d;
    var f = [],
      g = a.length,
      h = 4294967295,
      k = !1,
      p = !!(b & 64),
      n = p ? (b & 128 ? 0 : -1) : void 0;
    if (!(b & 1)) {
      var v = g && a[g - 1];
      v != null && typeof v === "object" && v.constructor === Object
        ? (g--, (h = g))
        : (v = void 0);
      !p ||
        b & 128 ||
        e ||
        ((k = !0), (h = (Da ?? Ba)(h - n, n, a, v, void 0) + n));
    }
    b = void 0;
    for (e = 0; e < g; e++) {
      let r = a[e];
      if (r != null && (r = c(r, d)) != null)
        if (p && e >= h) {
          let u = e - n;
          (b ?? (b = {}))[u] = r;
        } else f[e] = r;
    }
    if (v)
      for (let r in v) {
        a = v[r];
        if (a == null || (a = c(a, d)) == null) continue;
        g = +r;
        let u;
        p && !Number.isNaN(g) && (u = g + n) < h
          ? (f[u] = a)
          : ((b ?? (b = {}))[r] = a);
      }
    b && (k ? f.push(b) : (f[h] = b));
    return f;
  }
  function Ea(a) {
    switch (typeof a) {
      case "number":
        return Number.isFinite(a) ? a : "" + a;
      case "bigint":
        return ya(a) ? Number(a) : "" + a;
      case "boolean":
        return a ? 1 : 0;
      case "object":
        if (Array.isArray(a)) {
          let b = a[y] | 0;
          return a.length === 0 && b & 1 ? void 0 : Ca(a, b, Ea);
        }
        if (a != null && a[w] === z) return Fa(a);
        return;
    }
    return a;
  }
  var Da;
  function Fa(a) {
    a = a.h;
    return Ca(a, a[y] | 0, Ea);
  }
  function Ga(a, b, c, d = 0) {
    if (a == null) {
      var e = 32;
      c ? ((a = [c]), (e |= 128)) : (a = []);
      b && (e = (e & -16760833) | ((b & 1023) << 14));
    } else {
      if (!Array.isArray(a)) throw Error("narr");
      e = a[y] | 0;
      if (fa && 1 & e) throw Error("rfarr");
      2048 & e && !(2 & e) && Ha();
      if (e & 256) throw Error("farr");
      if (e & 64) return (e | d) !== e && (a[y] = e | d), a;
      if (c && ((e |= 128), c !== a[0])) throw Error("mid");
      a: {
        c = a;
        e |= 64;
        var f = c.length;
        if (f) {
          var g = f - 1;
          let k = c[g];
          if (k != null && typeof k === "object" && k.constructor === Object) {
            b = e & 128 ? 0 : -1;
            g -= b;
            if (g >= 1024) throw Error("pvtlmt");
            for (var h in k)
              if (((f = +h), f < g)) (c[f + b] = k[h]), delete k[h];
              else break;
            e = (e & -16760833) | ((g & 1023) << 14);
            break a;
          }
        }
        if (b) {
          h = Math.max(b, f - (e & 128 ? 0 : -1));
          if (h > 1024) throw Error("spvt");
          e = (e & -16760833) | ((h & 1023) << 14);
        }
      }
    }
    a[y] = e | 64 | d;
    return a;
  }
  function Ha() {
    if (fa) throw Error("carr");
    if (qa != null) {
      var a = oa ?? (oa = {});
      var b = a[qa] || 0;
      b >= 5 ||
        ((a[qa] = b + 1),
        (a = Error()),
        a.__closure__error__context__984382 ||
          (a.__closure__error__context__984382 = {}),
        (a.__closure__error__context__984382.severity = "incident"),
        ea(a));
    }
  }
  function Ia(a, b) {
    if (typeof a !== "object") return a;
    if (Array.isArray(a)) {
      var c = a[y] | 0;
      a.length === 0 && c & 1
        ? (a = void 0)
        : c & 2 ||
          (!b || 4096 & c || 16 & c
            ? (a = G(a, c, !1, b && !(c & 16)))
            : ((a[y] |= 34), c & 4 && Object.freeze(a)));
      return a;
    }
    if (a != null && a[w] === z)
      return (
        (b = a.h),
        (c = b[y] | 0),
        E(a, c) ? a : Ja(a, b, c) ? Ka(a, b) : G(b, c)
      );
  }
  function Ka(a, b, c) {
    a = new a.constructor(b);
    c && (a.i = F);
    a.l = F;
    return a;
  }
  function G(a, b, c, d) {
    d ?? (d = !!(34 & b));
    a = Ca(a, b, Ia, d);
    d = 32;
    c && (d |= 2);
    b = (b & 16769217) | d;
    a[y] = b;
    return a;
  }
  function La(a, b) {
    b === void 0 && (b = a[y] | 0);
    b & 32 && !(b & 4096) && (a[y] = b | 4096);
  }
  function Ja(a, b, c) {
    return c & 2
      ? !0
      : c & 32 && !(c & 4096)
      ? ((b[y] = c | 2), (a.i = F), !0)
      : !1;
  }
  function Ma(a, b) {
    a = Na(a.h, b);
    if (a !== null) return a;
  }
  function Oa(a, b, c) {
    return Na(a, b, void 0, c);
  }
  function Na(a, b, c, d) {
    if (b === -1) return null;
    var e = b + (c ? 0 : -1),
      f = a.length - 1;
    if (!(f < 1 + (c ? 0 : -1))) {
      if (e >= f) {
        var g = a[f];
        if (g != null && typeof g === "object" && g.constructor === Object) {
          c = g[b];
          var h = !0;
        } else if (e === f) c = g;
        else return;
      } else c = a[e];
      if (d && c != null) {
        d = d(c);
        if (d == null) return d;
        if (!Object.is(d, c)) return h ? (g[b] = d) : (a[e] = d), d;
      }
      return c;
    }
  }
  function Pa(a) {
    a = Na(a.h, 12);
    return (a != null && a[w] === z) || Array.isArray(a);
  }
  function Qa(a, b, c, d) {
    var e = !1;
    d = Oa(a, d, (f) => {
      if (f != null && f[w] === z) var g = f;
      else if (Array.isArray(f)) {
        g = f[y] | 0;
        let h;
        h = g | (b & 32);
        h |= b & 2;
        h !== g && (f[y] = h);
        g = new c(f);
      } else g = void 0;
      e = g !== f && g != null;
      return g;
    });
    if (d != null) return e && !E(d) && La(a, b), d;
  }
  function Ra(a, b, c) {
    var d = a.h,
      e = d[y] | 0;
    b = Qa(d, e, b, c);
    if (b == null) return b;
    e = d[y] | 0;
    if (!E(a, e)) {
      var f = b;
      var g = f.h,
        h = g[y] | 0;
      f = E(f, h)
        ? Ja(f, g, h)
          ? Ka(f, g, !0)
          : new f.constructor(G(g, h, !1))
        : f;
      if (f !== b) {
        a.i === F
          ? ((b = a.h),
            (b = G(b, b[y] | 0)),
            (b[y] |= 2048),
            (a.h = b),
            (a.i = void 0),
            (a.l = void 0),
            (b = !0))
          : (b = !1);
        b && ((d = a.h), (e = d[y] | 0));
        b = f;
        a: {
          a = d;
          f = b;
          g = c + -1;
          h = a.length - 1;
          if (h >= 0 && g >= h) {
            let k = a[h];
            if (
              k != null &&
              typeof k === "object" &&
              k.constructor === Object
            ) {
              k[c] = f;
              break a;
            }
          }
          g <= h
            ? (a[g] = f)
            : f !== void 0 &&
              ((h = ((e ?? (e = a[y] | 0)) >> 14) & 1023 || 536870912),
              c >= h ? f != null && (a[h + -1] = { [c]: f }) : (a[g] = f));
        }
        La(d, e);
      }
    }
    return b;
  }
  function H(a, b) {
    a = Ma(a, b);
    return (
      (a == null || typeof a === "boolean"
        ? a
        : typeof a === "number"
        ? !!a
        : void 0) ?? !1
    );
  }
  function I(a, b) {
    return Aa(Ma(a, b)) ?? 0;
  }
  function J(a, b) {
    a = Ma(a, b);
    return (a == null || typeof a === "string" ? a : void 0) ?? "";
  }
  var K = class {
    constructor(a) {
      this.h = Ga(a, void 0, void 0, 2048);
    }
    toJSON() {
      var a = Fa(this);
      return a;
    }
  };
  K.prototype[w] = z;
  K.prototype.toString = function () {
    return this.h.toString();
  };
  var Sa = class extends K {};
  var Ta = class extends K {};
  var Ua = (function (a) {
    return (b) => {
      if (b == null || b == "") b = new a();
      else {
        b = JSON.parse(b);
        if (!Array.isArray(b)) throw Error("dnarr");
        b[y] |= 32;
        b = new a(b);
      }
      return b;
    };
  })(
    class extends K {
      j() {
        return H(this, 20);
      }
    }
  );
  class Va {
    constructor() {
      this.promise = new Promise((a, b) => {
        this.resolve = a;
        this.reject = b;
      });
    }
  }
  function Wa() {
    var { promise: a, resolve: b } = new Va();
    return { promise: a, resolve: b };
  }
  function Xa(a) {
    return String(a).replace(/\-([a-z])/g, function (b, c) {
      return c.toUpperCase();
    });
  }
  function bb(a) {
    return a.replace(RegExp("(^|[\\s]+)([a-z])", "g"), function (b, c, d) {
      return c + d.toUpperCase();
    });
  }
  function cb(a, b) {
    if (a)
      for (let c in a)
        Object.prototype.hasOwnProperty.call(a, c) && b(a[c], c, a);
  }
  function db(a = document) {
    return a.createElement("img");
  }
  function eb(a, b) {
    b.google_llp || (b.google_llp = {});
    b = b.google_llp;
    var c = b[a];
    if (c) return c;
    c = Wa();
    return (b[a] = c);
  }
  async function fb() {
    var a = window,
      b = [eb(9, a).promise];
    try {
      b.push(eb(9, a.parent).promise);
    } catch (c) {}
    return Promise.race(b);
  }
  function L(a, b, c) {
    if (typeof b === "string") gb(a, c, b);
    else for (let d in b) gb(a, b[d], d);
  }
  var hb = /^--.+/;
  function gb(a, b, c) {
    var d = ib[c];
    if (!d) {
      var e = Xa(c);
      d = e;
      a.style[e] === void 0 &&
        ((e = (na ? "Webkit" : ma ? "Moz" : null) + bb(e)),
        a.style[e] !== void 0 && (d = e));
      ib[c] = d;
    }
    (c = d) && (hb.test(c) ? a.style.setProperty(c, b) : (a.style[c] = b));
  }
  var ib = {};
  function M(a, b) {
    a.style.display = b ? "" : "none";
  }
  var N = ma ? "MozUserSelect" : na || la ? "WebkitUserSelect" : null;
  function jb(a, b) {
    var c = a.getElementsByTagName("*");
    if (N && ((b = b ? "none" : ""), a.style && (a.style[N] = b), c))
      for (let d = 0; (a = c[d]); d++) a.style && (a.style[N] = b);
  }
  function kb(a, b, c) {
    typeof a.addEventListener === "function" && a.addEventListener(b, c, !1);
  }
  function O(a, b = null, c = !1) {
    lb(a, b, c);
  }
  function lb(a, b, c) {
    l.google_image_requests || (l.google_image_requests = []);
    var d = db(l.document);
    if (b || c) {
      let e = (f) => {
        b && b(f);
        if (c) {
          f = l.google_image_requests;
          let g = Array.prototype.indexOf.call(f, d, void 0);
          g >= 0 && Array.prototype.splice.call(f, g, 1);
        }
        typeof d.removeEventListener === "function" &&
          d.removeEventListener("load", e, !1);
        typeof d.removeEventListener === "function" &&
          d.removeEventListener("error", e, !1);
      };
      kb(d, "load", e);
      kb(d, "error", e);
    }
    d.src = a;
    l.google_image_requests.push(d);
  }
  function mb(a) {
    var b;
    if ((b = l.navigator))
      (b = l.navigator.userAgent), (b = !(!/Chrome/.test(b) || /Edge/.test(b)));
    b && typeof l.navigator.sendBeacon === "function"
      ? l.navigator.sendBeacon(a)
      : O(a, void 0, !1);
  }
  var nb = 0;
  function ob(a, b = null) {
    return b && b.getAttribute("data-jc") === String(a)
      ? b
      : document.querySelector(`[data-jc="${a}"]`);
  }
  var pb = class {
    constructor(a, b) {
      this.error = a;
      this.meta = {};
      this.context = b.context;
      this.msg = b.message || "";
      this.id = b.id || "jserror";
    }
  };
  function qb(a) {
    var b = a.toString();
    a.name && b.indexOf(a.name) == -1 && (b += ": " + a.name);
    a.message && b.indexOf(a.message) == -1 && (b += ": " + a.message);
    if (a.stack)
      a: {
        a = a.stack;
        var c = b;
        try {
          a.indexOf(c) == -1 && (a = c + "\n" + a);
          let d;
          for (; a != d; )
            (d = a),
              (a = a.replace(
                RegExp("((https?:/..*/)[^/:]*:\\d+(?:.|\n)*)\\2"),
                "$1"
              ));
          b = a.replace(RegExp("\n *", "g"), "\n");
          break a;
        } catch (d) {
          b = c;
          break a;
        }
        b = void 0;
      }
    return b;
  }
  var rb = RegExp("^https?://(\\w|-)+\\.cdn\\.ampproject\\.(net|org)(\\?|/|$)"),
    sb = class {
      constructor(a, b) {
        this.h = a;
        this.i = b;
      }
    },
    tb = class {
      constructor(a, b) {
        this.url = a;
        this.h = !!b;
        this.depth = null;
      }
    };
  var Q = null;
  function ub() {
    var a = l.performance;
    return a && a.now && a.timing
      ? Math.floor(a.now() + a.timing.navigationStart)
      : Date.now();
  }
  function vb() {
    var a = l.performance;
    return a && a.now ? a.now() : null;
  }
  var wb = class {
    constructor(a, b) {
      var c = vb() || ub();
      this.label = a;
      this.type = b;
      this.value = c;
      this.duration = 0;
      this.taskId = this.slotId = void 0;
      this.uniqueId = Math.random();
    }
  };
  var R = l.performance,
    xb = !!(R && R.mark && R.measure && R.clearMarks),
    S = (function (a) {
      var b = !1,
        c;
      return function () {
        b || ((c = a()), (b = !0));
        return c;
      };
    })(() => {
      var a;
      if ((a = xb)) {
        var b;
        a = window;
        if (Q === null) {
          Q = "";
          try {
            let c = "";
            try {
              c = a.top.location.hash;
            } catch (d) {
              c = a.location.hash;
            }
            c && (Q = (b = c.match(/\bdeid=([\d,]+)/)) ? b[1] : "");
          } catch (c) {}
        }
        b = Q;
        a = !!b.indexOf && b.indexOf("1337") >= 0;
      }
      return a;
    });
  function yb(a) {
    a &&
      R &&
      S() &&
      (R.clearMarks(`goog_${a.label}_${a.uniqueId}_start`),
      R.clearMarks(`goog_${a.label}_${a.uniqueId}_end`));
  }
  function T(a, b) {
    var c = {};
    c[a] = b;
    return [c];
  }
  function zb(a, b, c, d, e) {
    var f = [];
    cb(a, (g, h) => {
      (g = Ab(g, b, c, d, e)) && f.push(`${encodeURIComponent(h)}=${g}`);
    });
    return f.join(b);
  }
  function Ab(a, b, c, d, e) {
    if (a == null) return "";
    b = b || "&";
    c = c || ",$";
    va(c) && (c = c.split(""));
    if (a instanceof Array) {
      if ((d || (d = 0), d < c.length)) {
        let f = [];
        for (let g = 0; g < a.length; g++) f.push(Ab(a[g], b, c, d + 1, e));
        return f.join(c[d]);
      }
    } else if (typeof a === "object")
      return (
        e || (e = 0), e < 2 ? encodeURIComponent(zb(a, b, c, d, e + 1)) : "..."
      );
    return encodeURIComponent(String(a));
  }
  function Bb(a) {
    var b = 1;
    for (let c in a.i) c.length > b && (b = c.length);
    return 3997 - b - a.j.length - 1;
  }
  function Cb(a, b) {
    var c = Bb(a) - b.length;
    if (c < 0) return "";
    b = "";
    a.h.sort((f, g) => f - g);
    var d = null,
      e = "";
    for (let f = 0; f < a.h.length; f++) {
      let g = a.h[f],
        h = a.i[g];
      for (let k = 0; k < h.length; k++) {
        if (!c) {
          d = d == null ? g : d;
          break;
        }
        let p = zb(h[k], a.j, ",$");
        if (p) {
          p = e + p;
          if (c >= p.length) {
            c -= p.length;
            b += p;
            e = a.j;
            break;
          }
          d = d == null ? g : d;
        }
      }
    }
    a = "";
    d != null && (a = `${e}trn=${d}`);
    return b + a;
  }
  function Db(a, b, c, d) {
    return Bb(a) - d.length < 0 ? "" : b + "//" + c + d + Cb(a, d);
  }
  var Eb = class {
    constructor() {
      this.j = "&";
      this.i = {};
      this.l = 0;
      this.h = [];
    }
  };
  var Fb = RegExp(
    "^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$"
  );
  function Gb(a, b, c) {
    try {
      if (a.i && a.i.h) {
        var d = a.i.start(b.toString(), 3);
        var e = c();
        a.i.end(d);
      } else e = c();
    } catch (f) {
      c = !0;
      try {
        yb(d), (c = a.m(b, new pb(f, { message: qb(f) }), void 0, void 0));
      } catch (g) {
        a.j(217, g);
      }
      if (c) window.console?.error?.(f);
      else throw f;
    }
    return e;
  }
  function Hb(a, b) {
    var c = U;
    return (...d) => Gb(c, a, () => b.apply(void 0, d));
  }
  function V(a, b) {
    var c = U;
    b.catch((d) => {
      d = d ? d : "unknown rejection";
      c.j(a, d instanceof Error ? d : Error(d), void 0, c.h || void 0);
    });
  }
  var Kb = class {
    constructor(a = null) {
      this.pinger = Ib;
      this.i = a;
      this.h = null;
      this.l = !1;
      this.m = this.j;
    }
    j(a, b, c, d, e) {
      e = e || "jserror";
      var f = void 0;
      try {
        let B = new Eb();
        var g = B;
        g.h.push(1);
        g.i[1] = T("context", a);
        (b.error && b.meta && b.id) || (b = new pb(b, { message: qb(b) }));
        g = b;
        if (g.msg) {
          b = B;
          var h = g.msg.substring(0, 512);
          b.h.push(2);
          b.i[2] = T("msg", h);
        }
        var k = g.meta || {};
        h = k;
        if (this.h)
          try {
            this.h(h);
          } catch (A) {}
        if (d)
          try {
            d(h);
          } catch (A) {}
        d = B;
        k = [k];
        d.h.push(3);
        d.i[3] = k;
        var p;
        if (!(p = u)) {
          d = l;
          k = [];
          let A;
          h = null;
          do {
            var n = d;
            try {
              var v;
              if ((v = !!n && n.location.href != null))
                b: {
                  try {
                    ka(n.foo);
                    v = !0;
                    break b;
                  } catch (x) {}
                  v = !1;
                }
              var r = v;
            } catch {
              r = !1;
            }
            r
              ? ((A = n.location.href),
                (h = (n.document && n.document.referrer) || null))
              : ((A = h), (h = null));
            k.push(new tb(A || ""));
            try {
              d = n.parent;
            } catch (x) {
              d = null;
            }
          } while (d && n !== d);
          for (let x = 0, Ya = k.length - 1; x <= Ya; ++x) k[x].depth = Ya - x;
          n = l;
          if (
            n.location &&
            n.location.ancestorOrigins &&
            n.location.ancestorOrigins.length === k.length - 1
          )
            for (r = 1; r < k.length; ++r) {
              let x = k[r];
              x.url ||
                ((x.url = n.location.ancestorOrigins[r - 1] || ""), (x.h = !0));
            }
          p = k;
        }
        var u = p;
        let aa = new tb(l.location.href, !1);
        p = null;
        let sa = u.length - 1;
        for (n = sa; n >= 0; --n) {
          var C = u[n];
          !p && rb.test(C.url) && (p = C);
          if (C.url && !C.h) {
            aa = C;
            break;
          }
        }
        C = null;
        let $b = u.length && u[sa].url;
        aa.depth !== 0 && $b && (C = u[sa]);
        f = new sb(aa, C);
        if (f.i) {
          u = B;
          var D = f.i.url || "";
          u.h.push(4);
          u.i[4] = T("top", D);
        }
        var ta = { url: f.h.url || "" };
        if (f.h.url) {
          let A = f.h.url.match(Fb);
          var P = A[1],
            Za = A[3],
            $a = A[4];
          D = "";
          P && (D += P + ":");
          Za && ((D += "//"), (D += Za), $a && (D += ":" + $a));
          var ab = D;
        } else ab = "";
        P = B;
        ta = [ta, { url: ab }];
        P.h.push(5);
        P.i[5] = ta;
        Jb(this.pinger, e, B, this.l, c);
      } catch (B) {
        try {
          Jb(
            this.pinger,
            e,
            { context: "ecmserr", rctx: a, msg: qb(B), url: f?.h.url ?? "" },
            this.l,
            c
          );
        } catch (aa) {}
      }
      return !0;
    }
  };
  function Jb(a, b, c, d = !1, e) {
    if ((d ? a.i : Math.random()) < (e || a.l))
      try {
        let f;
        c instanceof Eb
          ? (f = c)
          : ((f = new Eb()),
            cb(c, (h, k) => {
              var p = f,
                n = p.l++;
              h = T(k, h);
              p.h.push(n);
              p.i[n] = h;
            }));
        let g = Db(f, a.protocol, a.h(), a.path + b + "&");
        g && (a.j ? mb(g) : O(g));
      } catch (f) {}
  }
  function Lb() {
    var a = Ib,
      b = window.google_srt;
    b >= 0 && b <= 1 && (a.i = b);
  }
  var Mb = class {
    constructor(a, b, c, d = !1) {
      this.domain = a;
      this.path = b;
      this.l = c;
      this.j = d;
      this.protocol = "https:";
      this.i = Math.random();
    }
    h() {
      return this.domain;
    }
  };
  var Ib,
    U,
    Nb = !1;
  class Ob extends Mb {
    h() {
      if (Nb) {
        ({ ea: a = !1 } = { ea: !0 });
        var a = a
          ? "connect.pagead2.googlesyndication.com"
          : "pagead2.googlesyndication.com";
      } else a = super.h();
      return a;
    }
  }
  var W = new (class {
    constructor(a, b) {
      this.events = [];
      this.i = b || l;
      var c = null;
      b &&
        ((b.google_js_reporting_queue = b.google_js_reporting_queue || []),
        (this.events = b.google_js_reporting_queue),
        (c = b.google_measure_js_timing));
      this.h = S() || (c != null ? c : Math.random() < a);
    }
    start(a, b) {
      if (!this.h) return null;
      a = new wb(a, b);
      b = `goog_${a.label}_${a.uniqueId}_start`;
      R && S() && R.mark(b);
      return a;
    }
    end(a) {
      if (this.h && ua(a.value)) {
        a.duration = (vb() || ub()) - a.value;
        var b = `goog_${a.label}_${a.uniqueId}_end`;
        R && S() && R.mark(b);
        !this.h || this.events.length > 2048 || this.events.push(a);
      }
    }
  })(1, window);
  function Pb() {
    window.google_measure_js_timing ||
      ((W.h = !1),
      W.events !== W.i.google_js_reporting_queue &&
        (S() && Array.prototype.forEach.call(W.events, yb, void 0),
        (W.events.length = 0)));
  }
  (function (a) {
    Nb = !1;
    Ib =
      a ?? new Ob("pagead2.googlesyndication.com", "/pagead/gen_204?id=", 0.01);
    typeof window.google_srt !== "number" &&
      (window.google_srt = Math.random());
    Lb();
    U = new Kb(W);
    U.h = (b) => {
      var c = nb;
      c !== 0 &&
        ((b.jc = String(c)),
        (c =
          ((c = ob(c, document.currentScript)) &&
            c.getAttribute("data-jc-version")) ||
          "unknown"),
        (b.shv = c));
    };
    U.l = !0;
    window.document.readyState === "complete"
      ? Pb()
      : W.h &&
        kb(window, "load", () => {
          Pb();
        });
  })();
  function Qb(a, b) {
    return Hb(a, b);
  }
  async function Rb() {
    return eb(10, l).promise;
  }
  function Sb(a, b = null) {
    a = { type: "rewarded", message: a };
    b && (a.payload = b);
    window.parent.postMessage(JSON.stringify(a), "*");
  }
  var Tb = (a) => {
      Sb("granted", a);
    },
    Ub = (a, b) => {
      window.addEventListener(
        "message",
        (c) => {
          try {
            var d = c.data,
              e = typeof d;
            let f =
              (e == "object" && d != null) || e == "function"
                ? c.data
                : JSON.parse(c.data);
            if (f.type == "rewarded")
              switch (f.message) {
                case "visible":
                  a(f);
                  break;
                case "back_button":
                  b();
              }
          } catch (f) {}
        },
        !1
      );
    };
  function X() {
    this.M = this.M;
    this.H = this.H;
  }
  X.prototype.M = !1;
  X.prototype.dispose = function () {
    if (!this.M && ((this.M = !0), this.H))
      for (; this.H.length; ) this.H.shift()();
  };
  X.prototype[Symbol.dispose] = function () {
    this.dispose();
  };
  function Vb(a, b) {
    a.M ? b() : (a.H || (a.H = []), a.H.push(b));
  }
  async function Wb(a, b) {
    b = b.target.id;
    if (b === "close-ad-button")
      Xb(a),
        a.v?.dispatchEvent("confirmationCloseClicked"),
        (await a.o).dismiss(6);
    else if (
      b === "resume-ad-button" ||
      (b === "dialog-wrapper" && H(a.config, 15))
    )
      Xb(a),
        a.v?.dispatchEvent("confirmationResumeClicked"),
        (await a.o).notifyRewardedEvent("reward_confirmation_resume_clicked");
  }
  async function Yb(a) {
    H(a.config, 7) && !H(a.config, 8)
      ? (a.v?.dispatchEvent("skip"), (await a.o).dismiss(1))
      : H(a.config, 5) &&
        (Y(a) <= 0 && a.h !== -1
          ? (a.v?.dispatchEvent("abandon"), (await a.o).dismiss(7))
          : a.ca
          ? (a.pauseTimer(),
            a.v?.dispatchEvent("confirmationDialogueShown"),
            a.v?.dispatchEvent("abandon"),
            (await a.o).dismiss(6))
          : await Zb(a));
  }
  async function ac(a) {
    M(a.V, !1);
    Z(a);
    var b = await a.o;
    a.Y = b;
    H(a.config, 9)
      ? (jb(a.j, !0),
        a.W
          ? (a.j?.classList.remove("disabled"),
            a.j?.classList.add("greyed-out"),
            a.D?.classList.add("unskippable"))
          : a.j.classList.add("disabled"),
        b.disableDismissListeners(a.closeAd))
      : await bc(a);
    a.C && !a.J
      ? a.W || a.D.classList.add("disabled")
      : a.C &&
        a.J &&
        (H(a.config, 9)
          ? a.W || a.D.classList.add("disabled")
          : (a.B && L(a.B, "display", "flex"), a.ba && cc(a), Z(a)));
    b.addViewListener(() => {
      dc(a, 0);
      !a.I &&
        a.C &&
        ((a.l.style.transition = "width 1s linear"),
        (a.l.style.width =
          a.h > 0 ? `${Math.min((1 / a.h) * 100, 100)}%` : "100%"));
      (N && a.j.style[N].toLowerCase() == "none") || ec(a);
      a.h === -1 ||
        a.I ||
        (a.N = setInterval(() => {
          var c = fc(a);
          V(1012, c);
        }, 1e3));
    });
  }
  function hc(a) {
    if (H(a.config, 14)) {
      var b = H(a.config, 18);
      let c = b ? 0.9 : 0.78,
        d = b ? 0.05 : 0.031,
        e = b ? 0.04 : 0.025,
        f = b ? 0.035 : 0.0218,
        g = `${a.u * (b ? 0.04 : 0.066)}px`;
      L(document.getElementById("close-confirmation-dialog"), {
        width: `${a.u * c}px`,
        "border-radius": "8px",
        padding: b ? `${a.i * 0.05}px` : "0",
        "min-width": "min-content",
      });
      L(document.getElementById("confirmation-title"), {
        "font-size": `${a.i * d}px`,
        "margin-top": `${a.i * 0.0375}px`,
        "margin-left": g,
        "margin-right": g,
        color: "#202124",
        "font-weight": "500",
      });
      L(document.getElementById("confirmation-message"), {
        "font-size": `${a.i * e}px`,
        "margin-top": `${a.i * 0.0375}px`,
        "margin-bottom": `${a.i * 0.0375}px`,
        "margin-left": g,
        "margin-right": g,
        color: "#5f6368",
        "line-height": "1.3",
      });
      L(document.getElementById("confirmation-buttons"), {
        display: "flex",
        "justify-content": "flex-end",
        gap: "8px",
        "font-size": `${a.i * f}px`,
        "line-height": `${a.i * 0.05625}px`,
        "margin-top": "auto",
        "margin-right": `${a.i * 0.0125}px`,
        "margin-bottom": `${a.i * 0.0125}px`,
      });
      L(document.getElementById("close-ad-button"), {
        padding: b ? "10px 24px" : `0 ${a.u * 0.044}px`,
        "border-radius": "100px",
        "font-size": `${a.i * f}px`,
        "font-weight": "500",
        color: "#1a73e8",
        border: "none",
        background: "none",
        cursor: "pointer",
      });
      L(document.getElementById("resume-ad-button"), {
        padding: b ? "10px 24px" : `0 ${a.u * 0.044}px`,
        "border-radius": "100px",
        "font-size": `${a.i * f}px`,
        "font-weight": "500",
        background: "#1a73e8",
        color: "#fff",
        border: "none",
        cursor: "pointer",
      });
    } else
      (b = `${a.u * 0.066}px`),
        L(
          document.getElementById("close-confirmation-dialog"),
          "width",
          `${a.u * 0.78}px`
        ),
        L(document.getElementById("confirmation-title"), {
          "font-size": `${a.i * 0.031}px`,
          "margin-top": `${a.i * 0.0375}px`,
          "margin-left": b,
          "margin-right": b,
        }),
        L(document.getElementById("confirmation-message"), {
          "font-size": `${a.i * 0.025}px`,
          "margin-bottom": `${a.i * 0.0375}px`,
          "margin-top": `${a.i * 0.0375}px`,
          "margin-left": b,
          "margin-right": b,
        }),
        L(document.getElementById("confirmation-buttons"), {
          "font-size": `${a.i * 0.0218}px`,
          "line-height": `${a.i * 0.05625}px`,
          "margin-right": `${a.i * 0.0125}px`,
          "margin-bottom": `${a.i * 0.0125}px`,
        }),
        L(document.getElementById("close-ad-button"), {
          "padding-left": `${a.u * 0.044}px`,
          "padding-right": `${a.u * 0.044}px`,
        }),
        L(document.getElementById("resume-ad-button"), {
          "padding-left": `${a.u * 0.044}px`,
          "padding-right": `${a.u * 0.044}px`,
        });
  }
  function Z(a) {
    var b = J(a.config, 1),
      c = H(a.config, 9),
      d = a.O > 0 && a.m >= a.O;
    b =
      !a.J || (c && !d)
        ? b.replace("%1$d", Y(a).toFixed(0))
        : b.replace("%1$d", "").trim();
    a = a.B;
    if ("textContent" in a) a.textContent = b;
    else if (a.nodeType == 3) a.data = String(b);
    else if (a.firstChild && a.firstChild.nodeType == 3) {
      for (; a.lastChild != a.firstChild; ) a.removeChild(a.lastChild);
      a.firstChild.data = String(b);
    } else {
      for (; (c = a.firstChild); ) a.removeChild(c);
      a.appendChild(
        (a.nodeType == 9 ? a : a.ownerDocument || a.document).createTextNode(
          String(b)
        )
      );
    }
  }
  async function bc(a) {
    !a.Z &&
      ((a.Z = !0),
      (await a.o).disableDismissListeners(a.closeAd),
      H(a.config, 5) || H(a.config, 7)) &&
      (a.j.addEventListener("click", a.closeAd),
      Vb(a, () => {
        a.j.removeEventListener("click", a.closeAd);
      }),
      a.J &&
        a.B &&
        (a.B.addEventListener("click", a.closeAd),
        L(a.B, "cursor", "pointer"),
        Vb(a, () => {
          a.B.removeEventListener("click", a.closeAd);
        })));
  }
  function cc(a) {
    a.j.classList.remove("disabled");
    a.j?.classList.remove("greyed-out");
    a.D?.classList.remove("unskippable");
    jb(a.j, !1);
  }
  function dc(a, b) {
    if (!(a.h === -1 || a.h <= 0 || a.Y?.getReactiveAdType() !== 10)) {
      var c = Math.ceil(a.h);
      b = Math.min(b, c);
      if (!(b <= a.X)) {
        var d = H(a.config, 18) ? 1 : 0;
        for (let e = a.X + 1; e <= b; e++)
          a.Y?.maybeReportBeacon({ cd_t: e, cd_d: c, dt: d });
        a.X = b;
      }
    }
  }
  function ec(a) {
    a.j.focus();
    a.v?.dispatchEvent("skipShown");
  }
  async function fc(a) {
    a.K ||
      document.hidden ||
      a.R ||
      (a.U && Y(a) <= 1) ||
      (a.m++,
      dc(a, a.m),
      a.C &&
        a.h > 0 &&
        (a.l.style.width = `${Math.min(((a.m + 1) / a.h) * 100, 100)}%`),
      Y(a) <= 0
        ? (a.C && a.T.classList.add("loaded"), await a.grantReward())
        : (Z(a), await ic(a)));
  }
  function Y(a) {
    if (a.I) {
      if (a.G) return 0;
      let b = Math.min(I(a.config, 2), Math.ceil(a.h));
      return Math.max(1, b - a.m);
    }
    return a.h - a.m;
  }
  async function Zb(a) {
    a.K = !0;
    a.v?.dispatchEvent("confirmationDialogueShown");
    (await a.o).notifyRewardedEvent("reward_confirmation_shown");
    a.L.classList.add("visible");
    var b = document.getElementById("resume-ad-button");
    b.addEventListener("click", a.A);
    var c = document.getElementById("close-ad-button");
    c.addEventListener("click", a.A);
    H(a.config, 15) && a.L.addEventListener("click", a.A);
    c.focus();
    Vb(a, () => {
      b.removeEventListener("click", a.A);
      c.removeEventListener("click", a.A);
      H(a.config, 15) && a.L.removeEventListener("click", a.A);
    });
  }
  async function ic(a) {
    a.O > 0 &&
      a.m >= a.O &&
      !a.aa &&
      ((a.aa = !0),
      a.ba && cc(a),
      await bc(a),
      ec(a),
      a.D.classList.add("expanded"),
      a.C &&
        (a.D.classList.remove("disabled"),
        a.J && a.B && L(a.B, "display", "flex")));
  }
  function Xb(a) {
    a.K &&
      ((a.K = !1),
      document
        .getElementById("resume-ad-button")
        .removeEventListener("click", a.A),
      document
        .getElementById("close-ad-button")
        .removeEventListener("click", a.A),
      H(a.config, 15) && a.L.removeEventListener("click", a.A),
      a.L.classList.remove("visible"),
      a.j.focus());
  }
  var kc = class extends X {
      constructor(a) {
        super();
        this.config = a;
        this.m = 0;
        this.v = null;
        this.K = this.U = this.R = !1;
        this.N = 0;
        this.G = this.I = this.aa = !1;
        this.X = -1;
        this.P = this.Y = null;
        this.Z = !1;
        this.ca = H(a, 16);
        this.J = H(a, 17);
        this.da = !!a.j?.();
        this.F = Ra(a, Ta, 6) ?? new Ta();
        this.B = document.getElementById("count-down-text");
        this.h = I(a, 2);
        this.O = I(a, 11);
        this.D = document.getElementById("count-down-container");
        this.j = document.getElementById("close-button");
        this.V = document.getElementById("dismiss-button-element");
        this.L = document.getElementById("dialog-wrapper");
        this.i = Math.max(I(a, 3), I(a, 4));
        this.u = Math.min(I(a, 3), I(a, 4));
        this.o = fb();
        if (H(this.F, 1) || H(this.config, 21))
          (a = H(this.F, 5)),
            (this.P = new jc(J(this.F, 4), a)),
            this.o.then((b) => {
              b.addViewListener(() => {
                var c = this.P;
                if (!c.l) {
                  for (let d of c.u) O(d);
                  c.l = !0;
                }
              });
            }),
            a &&
              Ub(
                (b) => {
                  var c = this.P;
                  b = b?.ssvOptions;
                  c.j = b && typeof b.userId === "string" ? b.userId : "";
                  c.i =
                    b && typeof b.customData === "string" ? b.customData : "";
                },
                () => {}
              );
        this.A = Qb(949, (b) => {
          Wb(this, b);
        });
        this.closeAd = Qb(948, () => {
          Yb(this);
        });
        ac(this);
        H(this.config, 5) && hc(this);
        H(this.F, 1) && Sb("prefetched");
        this.T = document.getElementById("progress-bar");
        this.l = document.getElementById("progress-bar-inner");
        this.C = !(!this.T || !this.l);
      }
      get W() {
        return this.da && H(this.config, 9) && this.O > 0;
      }
      get ba() {
        return !(H(this.config, 18) && H(this.config, 5) && this.J);
      }
      async grantReward() {
        if (
          !this.G &&
          ((this.G = !0),
          M(this.D, !1),
          M(this.j, !1),
          M(this.V, !0),
          (await this.o).enableDismissListeners(),
          this.V.addEventListener("click", () => {
            this.v?.dispatchEvent("abandon");
          }),
          clearInterval(this.N),
          this.P?.o(),
          H(this.F, 1) && Tb({ type: J(this.F, 2), amount: I(this.F, 3) }),
          H(this.config, 5))
        )
          if (
            ((await this.o).notifyRewardedEvent("granted"), Pa(this.config))
          ) {
            var a = Rb().then((b) => {
              var c = b.grantReward;
              var d = Ra(this.config, Sa, 12);
              d = J(d, 1);
              var e = Ra(this.config, Sa, 12);
              e = I(e, 2);
              c.call(b, { type: d, amount: e });
            });
            V(1011, a);
          } else
            (a = Rb().then((b) => {
              b.grantReward();
            })),
              V(1011, a);
      }
      init(a, b) {
        this.v = b;
        a < this.h && ((this.h = a), Z(this));
      }
      pauseTimer() {
        this.R = !0;
      }
      resumeTimer() {
        this.R = !1;
      }
      waitForVideoCompletion() {
        H(this.config, 5) && (this.U = !0);
      }
      onVideoCompleted() {
        if (this.U && ((this.R = this.U = !1), Y(this) <= 1 && this.h !== -1)) {
          var a = fc(this);
          V(1012, a);
        }
      }
      enableVideoTimeSync() {
        this.I = !0;
        this.N && (clearInterval(this.N), (this.N = 0));
        this.G || ((this.m = 0), Z(this));
        this.C &&
          this.l &&
          ((this.l.style.transition = "none"),
          (this.l.style.width = "0%"),
          requestAnimationFrame(() => {
            requestAnimationFrame(() => {
              this.l && (this.l.style.transition = "width 0.25s linear");
            });
          }));
      }
      setVideoDuration(a) {
        a > 0 &&
          (a < this.h || Math.floor(a) === this.h) &&
          ((this.h = a), this.G || Z(this));
      }
      updateVideoTime(a) {
        !this.I ||
          this.G ||
          this.K ||
          document.hidden ||
          (this.C &&
            this.l &&
            this.h > 0 &&
            (this.l.style.width = `${Math.min((a / this.h) * 100, 100)}%`),
          a >= this.h
            ? this.completeVideoTimeSync()
            : ((this.m = Math.floor(a)),
              dc(this, this.m),
              Z(this),
              (a = ic(this)),
              V(1012, a)));
      }
      completeVideoTimeSync() {
        if (this.I && !this.G) {
          this.m = Math.ceil(this.h);
          dc(this, this.m);
          this.C &&
            (this.l && (this.l.style.width = "100%"),
            this.T && this.T.classList.add("loaded"));
          var a = this.grantReward();
          V(1012, a);
        }
      }
    },
    jc = class extends X {
      constructor(a, b = !1) {
        super();
        this.m = b;
        this.l = !1;
        this.i = this.j = "";
        a = JSON.parse(a || "{}");
        this.u = a.video_start_urls || [];
        this.h = a.video_complete_urls || [];
      }
      o() {
        var a = (this.h[0] || "").includes(
            "admob_mediation_reward_video_complete"
          )
            ? 0
            : 1,
          b = this.h[a] || "";
        a = this.h[(a + 1) % 2] || "";
        this.m &&
          (a = a
            .replace("@gw_tmstmp@", String(Date.now()))
            .replace("@gw_rwd_userid@", encodeURIComponent(this.j))
            .replace("@gw_rwd_custom_data@", encodeURIComponent(this.i)));
        O(b);
        O(a);
      }
    };
  nb = 94;
  var lc = ob(94, document.currentScript);
  if (lc == null) throw Error("JSC not found 94");
  var mc = {},
    nc = lc.attributes;
  for (let a = nc.length - 1; a >= 0; a--) {
    let b = nc[a].name;
    b.indexOf("data-jcp-") === 0 && (mc[b.substring(9)] = nc[a].value);
  }
  ((a) => {
    Gb(U, 1010, () => {
      var b = new kc(Ua(a.config)),
        c = window;
      c.countdownHandler || (c.countdownHandler = Wa());
      c.countdownHandler.resolve(b);
    });
  })(mc);
}.call(this));
