/**
 * ESP - RTBHouse
 * @version v1.2.11
 * @link https://www.rtbhouse.com/
 */
!(function () {
  async function n() {
    var e = (function () {
        var e = navigator.userAgent.toLowerCase();
        const t = {
          chrome: /chrome/.test(e) && !/edge|opr|brave/.test(e),
          firefox: /firefox/.test(e),
          safari: /safari/.test(e) && !/chrome/.test(e),
          edge: /edg/.test(e),
          opera: /opr/.test(e),
          brave: /brave/.test(e),
          ie: /msie|trident/.test(e),
        };
        var o = Object.keys(t).find((e) => t[e]) || "Unknown";
        const s = {
          android: /android/.test(e),
          ios: /iphone|ipad|ipod/.test(e),
          windows: /windows/.test(e),
          mac: /macintosh/.test(e),
          linux: /linux/.test(e),
        };
        return {
          browser: o,
          device: Object.keys(s).find((e) => s[e]) || "Unknown",
        };
      })(),
      t = localStorage.getItem("_GESPSK-rtbhouse"),
      e = {
        shared_id: window.localStorage.getItem("rtbhouse-esp") || "no_data",
        rtbhouse_cookie: pbjs?.getUserIds()?.pubcid || "no_data",
        device: e.device,
        browser: e.browser,
        agent: navigator.userAgent.toLowerCase(),
        google_stored: null !== t,
        ss_data: t,
      },
      t = await (
        await fetch(
          "https://secure-signals-gazetkowo-300234255994.europe-west4.run.app/ss-rtbhouse",
          {
            method: "POST",
            body: JSON.stringify(e),
            headers: { "Content-Type": "application/json" },
          }
        )
      ).json();
    return window.postMessage("triggerCollectSecureSignals", "*"), t.message;
  }
  const e = async () => {
    let e = window.localStorage.getItem("rtbhouse-esp");
    var t,
      o = window.localStorage.getItem("rtbhouse-segments");
    let s;
    pbjs?.getUserIds && (s = pbjs?.getUserIds()?.pubcid),
      e ||
        ((e =
          ((t = (e, t) => e.toString(16).padStart(t, 0)),
          ((r = crypto.getRandomValues(new Uint8Array(16)))[6] =
            (15 & r[6]) | 64),
          (r[8] = (63 & r[8]) | 128),
          (r = new DataView(r.buffer)),
          `${t(r.getUint32(0), 8)}-${t(r.getUint16(4), 4)}-${t(
            r.getUint16(6),
            4
          )}-${t(r.getUint16(8), 4)}-` +
            t(r.getUint32(10), 8) +
            t(r.getUint16(14), 4))),
        window.localStorage.setItem("rtbhouse-esp", e)),
      (signal_decrypted = { domain: encodeURIComponent(window.location.href) }),
      e && (signal_decrypted["rtbhouse-esp"] = e),
      s && (signal_decrypted.EID = s),
      "browsingTopics" in document &&
        document.featurePolicy.allowsFeature("browsing-topics") &&
        ((t = await document.browsingTopics()),
        (signal_decrypted.topics = JSON.stringify(t))),
      o && (signal_decrypted.segments = o),
      document.referrer &&
        (signal_decrypted.referrer = encodeURIComponent(document.referrer));
    r = signal_decrypted;
    var r,
      o = await (
        await (
          await fetch("https://esp.rtbhouse.com/encrypt", {
            method: "POST",
            body: JSON.stringify({ publisher_id: "rtbhouse", signal: r }),
            headers: { "Content-Type": "text/plain" },
          })
        ).json()
      ).message;
    return (
      0 < document.location.host.indexOf("gazetkowo.pl") &&
        setTimeout(async () => {
          await n();
        }, 2e3),
      Promise.resolve(o)
    );
  };
  new (class {
    constructor(e) {
      Object.assign(this, e);
    }
    send_signal() {
      window.googletag.secureSignalProviders ||
        (window.googletag.secureSignalProviders = []),
        null != googletag.secureSignalProviders &&
          googletag.secureSignalProviders.push({
            id: "rtbhouse",
            collectorFunction: e,
          });
    }
  })({ send_cookie: !0 }).send_signal();
})();
