// Copyright 2011 Google Inc. All Rights Reserved.
(function () {
  var n,
    aa =
      typeof Object.create == "function"
        ? Object.create
        : function (a) {
            var b = function () {};
            b.prototype = a;
            return new b();
          },
    ba =
      typeof Object.defineProperties == "function"
        ? Object.defineProperty
        : function (a, b, c) {
            if (a == Array.prototype || a == Object.prototype) return a;
            a[b] = c.value;
            return a;
          },
    da = function (a) {
      a = [
        "object" == typeof globalThis && globalThis,
        a,
        "object" == typeof window && window,
        "object" == typeof self && self,
        "object" == typeof global && global,
      ];
      for (var b = 0; b < a.length; ++b) {
        var c = a[b];
        if (c && c.Math == Math) return c;
      }
      throw Error("Cannot find global object");
    },
    ea = da(this),
    u = function (a, b) {
      if (b)
        a: {
          var c = ea;
          a = a.split(".");
          for (var d = 0; d < a.length - 1; d++) {
            var e = a[d];
            if (!(e in c)) break a;
            c = c[e];
          }
          a = a[a.length - 1];
          d = c[a];
          b = b(d);
          b != d &&
            b != null &&
            ba(c, a, { configurable: !0, writable: !0, value: b });
        }
    },
    ha = (function () {
      function a() {
        function c() {}
        new c();
        Reflect.construct(c, [], function () {});
        return new c() instanceof c;
      }
      if (typeof Reflect != "undefined" && Reflect.construct) {
        if (a()) return Reflect.construct;
        var b = Reflect.construct;
        return function (c, d, e) {
          c = b(c, d);
          e && Reflect.setPrototypeOf(c, e.prototype);
          return c;
        };
      }
      return function (c, d, e) {
        e === void 0 && (e = c);
        e = aa(e.prototype || Object.prototype);
        return Function.prototype.apply.call(c, e, d) || e;
      };
    })(),
    ia;
  if (typeof Object.setPrototypeOf == "function") ia = Object.setPrototypeOf;
  else {
    var ka;
    a: {
      var la = { a: !0 },
        ma = {};
      try {
        ma.__proto__ = la;
        ka = ma.a;
        break a;
      } catch (a) {}
      ka = !1;
    }
    ia = ka
      ? function (a, b) {
          a.__proto__ = b;
          if (a.__proto__ !== b) throw new TypeError(a + " is not extensible");
          return a;
        }
      : null;
  }
  var na = ia,
    w = function (a, b) {
      a.prototype = aa(b.prototype);
      a.prototype.constructor = a;
      if (na) na(a, b);
      else
        for (var c in b)
          if (c != "prototype")
            if (Object.defineProperties) {
              var d = Object.getOwnPropertyDescriptor(b, c);
              d && Object.defineProperty(a, c, d);
            } else a[c] = b[c];
      a.yb = b.prototype;
    },
    pa = function (a) {
      var b = 0;
      return function () {
        return b < a.length ? { done: !1, value: a[b++] } : { done: !0 };
      };
    },
    y = function (a) {
      var b =
        typeof Symbol != "undefined" && Symbol.iterator && a[Symbol.iterator];
      if (b) return b.call(a);
      if (typeof a.length == "number") return { next: pa(a) };
      throw Error(String(a) + " is not an iterable or ArrayLike");
    },
    qa = function (a) {
      for (var b, c = []; !(b = a.next()).done; ) c.push(b.value);
      return c;
    },
    ra = function (a) {
      return a instanceof Array ? a : qa(y(a));
    },
    ua = function (a) {
      return sa(a, a);
    },
    sa = function (a, b) {
      a.raw = b;
      Object.freeze && (Object.freeze(a), Object.freeze(b));
      return a;
    },
    z = function (a, b) {
      var c;
      b && !b.done && (c = a["return"]) && c.call(a);
    },
    va = function (a, b) {
      return Object.prototype.hasOwnProperty.call(a, b);
    },
    xa =
      typeof Object.assign == "function"
        ? Object.assign
        : function (a, b) {
            if (a == null) throw new TypeError("No nullish arg");
            a = Object(a);
            for (var c = 1; c < arguments.length; c++) {
              var d = arguments[c];
              if (d) for (var e in d) va(d, e) && (a[e] = d[e]);
            }
            return a;
          },
    ya = function (a) {
      if (!(a instanceof Object))
        throw new TypeError("Iterator result " + a + " is not an object");
    },
    A = function () {
      this.K = !1;
      this.C = null;
      this.l = void 0;
      this.j = 1;
      this.F = this.H = 0;
      this.R = this.D = null;
    },
    za = function (a) {
      if (a.K) throw new TypeError("Generator is already running");
      a.K = !0;
    };
  A.prototype.O = function (a) {
    this.l = a;
  };
  var Aa = function (a, b) {
    a.D = { sg: b, Eg: !0 };
    a.j = a.H || a.F;
  };
  A.prototype.getNextAddressJsc = function () {
    return this.j;
  };
  A.prototype.getYieldResultJsc = function () {
    return this.l;
  };
  A.prototype.return = function (a) {
    this.D = { return: a };
    this.j = this.F;
  };
  A.prototype["return"] = A.prototype.return;
  A.prototype.Y = function (a) {
    this.D = { ia: a };
    this.F < a ? ((this.j = a), (this.D = null)) : (this.j = this.F);
  };
  A.prototype.jumpThroughFinallyBlocks = A.prototype.Y;
  A.prototype.h = function (a, b) {
    this.j = b;
    return { value: a };
  };
  A.prototype.yield = A.prototype.h;
  A.prototype.ba = function (a, b) {
    a = y(a);
    var c = a.next();
    ya(c);
    if (c.done) (this.l = c.value), (this.j = b);
    else return (this.C = a), this.h(c.value, b);
  };
  A.prototype.yieldAll = A.prototype.ba;
  A.prototype.ia = function (a) {
    this.j = a;
  };
  A.prototype.jumpTo = A.prototype.ia;
  A.prototype.B = function () {
    this.j = 0;
  };
  A.prototype.jumpToEnd = A.prototype.B;
  A.prototype.A = function (a, b) {
    this.H = a;
    b != void 0 && (this.F = b);
  };
  A.prototype.setCatchFinallyBlocks = A.prototype.A;
  A.prototype.T = function (a) {
    this.H = 0;
    this.F = a || 0;
  };
  A.prototype.setFinallyBlock = A.prototype.T;
  A.prototype.N = function (a, b) {
    this.j = a;
    this.H = b || 0;
  };
  A.prototype.leaveTryBlock = A.prototype.N;
  A.prototype.o = function (a) {
    this.H = a || 0;
    a = this.D.sg;
    this.D = null;
    return a;
  };
  A.prototype.enterCatchBlock = A.prototype.o;
  A.prototype.V = function (a, b, c) {
    c ? (this.R[c] = this.D) : (this.R = [this.D]);
    this.H = a || 0;
    this.F = b || 0;
    this.D = null;
  };
  A.prototype.enterFinallyBlock = A.prototype.V;
  A.prototype.J = function (a, b) {
    b = this.R.splice(b || 0)[0];
    (b = this.D = this.D || b)
      ? b.Eg
        ? (this.j = this.H || this.F)
        : b.ia != void 0 && this.F < b.ia
        ? ((this.j = b.ia), (this.D = null))
        : (this.j = this.F)
      : (this.j = a);
  };
  A.prototype.leaveFinallyBlock = A.prototype.J;
  A.prototype.W = function (a) {
    return new Ba(a);
  };
  A.prototype.forIn = A.prototype.W;
  var Ba = function (a) {
    this.j = a;
    this.h = [];
    for (var b in a) this.h.push(b);
    this.h.reverse();
  };
  Ba.prototype.l = function () {
    for (; this.h.length > 0; ) {
      var a = this.h.pop();
      if (a in this.j) return a;
    }
    return null;
  };
  Ba.prototype.getNext = Ba.prototype.l;
  var Ca = function (a) {
      this.h = new A();
      this.j = a;
    },
    Ga = function (a, b) {
      za(a.h);
      var c = a.h.C;
      if (c)
        return Ea(
          a,
          "return" in c
            ? c["return"]
            : function (d) {
                return { value: d, done: !0 };
              },
          b,
          a.h.return
        );
      a.h.return(b);
      return Fa(a);
    },
    Ea = function (a, b, c, d) {
      try {
        var e = b.call(a.h.C, c);
        ya(e);
        if (!e.done) return (a.h.K = !1), e;
        var f = e.value;
      } catch (g) {
        return (a.h.C = null), Aa(a.h, g), Fa(a);
      }
      a.h.C = null;
      d.call(a.h, f);
      return Fa(a);
    },
    Fa = function (a) {
      for (; a.h.j; )
        try {
          var b = a.j(a.h);
          if (b) return (a.h.K = !1), { value: b.value, done: !1 };
        } catch (c) {
          (a.h.l = void 0), Aa(a.h, c);
        }
      a.h.K = !1;
      if (a.h.D) {
        b = a.h.D;
        a.h.D = null;
        if (b.Eg) throw b.sg;
        return { value: b.return, done: !0 };
      }
      return { value: void 0, done: !0 };
    },
    Ha = function (a) {
      this.next = function (b) {
        za(a.h);
        a.h.C ? (b = Ea(a, a.h.C.next, b, a.h.O)) : (a.h.O(b), (b = Fa(a)));
        return b;
      };
      this.throw = function (b) {
        za(a.h);
        if (a.h.C) {
          var c = a.h.C["throw"];
          if (c) var d = Ea(a, c, b, a.h.O);
          else {
            b = a.h.C;
            a.h.C = null;
            try {
              b["return"] && ((d = b["return"]()), ya(d)),
                Aa(
                  a.h,
                  new TypeError(
                    "The iterator does not provide a 'throw' method."
                  )
                );
            } catch (e) {
              Aa(a.h, e);
            }
            d = Fa(a);
          }
        } else Aa(a.h, b), (d = Fa(a));
        return d;
      };
      this.return = function (b) {
        return Ga(a, b);
      };
      this[Symbol.iterator] = function () {
        return this;
      };
    },
    Ja = function (a) {
      function b(d) {
        return a.next(d);
      }
      function c(d) {
        return a.throw(d);
      }
      return new Promise(function (d, e) {
        function f(g) {
          g.done ? d(g.value) : Promise.resolve(g.value).then(b, c).then(f, e);
        }
        f(a.next());
      });
    },
    Ka = function (a) {
      return Ja(new Ha(new Ca(a)));
    },
    La = function () {
      for (var a = Number(this), b = [], c = a; c < arguments.length; c++)
        b[c - a] = arguments[c];
      return b;
    };
  u("globalThis", function (a) {
    return a || ea;
  });
  u("Reflect", function (a) {
    return a ? a : {};
  });
  u("Reflect.construct", function () {
    return ha;
  });
  u("Reflect.setPrototypeOf", function (a) {
    return a
      ? a
      : na
      ? function (b, c) {
          try {
            return na(b, c), !0;
          } catch (d) {
            return !1;
          }
        }
      : null;
  });
  u("Symbol", function (a) {
    if (a) return a;
    var b = function (f, g) {
      this.h = f;
      ba(this, "description", { configurable: !0, writable: !0, value: g });
    };
    b.prototype.toString = function () {
      return this.h;
    };
    var c = "jscomp_symbol_" + ((Math.random() * 1e9) >>> 0) + "_",
      d = 0,
      e = function (f) {
        if (this instanceof e)
          throw new TypeError("Symbol is not a constructor");
        return new b(c + (f || "") + "_" + d++, f);
      };
    return e;
  });
  u("Symbol.iterator", function (a) {
    if (a) return a;
    a = Symbol("Symbol.iterator");
    ba(Array.prototype, a, {
      configurable: !0,
      writable: !0,
      value: function () {
        return Na(pa(this));
      },
    });
    return a;
  });
  u("Symbol.toStringTag", function (a) {
    return a ? a : Symbol("Symbol.toStringTag");
  });
  var Na = function (a) {
    var b =
        (typeof Iterator != "undefined" &&
        Iterator.prototype &&
        !Iterator.prototype.next
          ? Iterator.prototype
          : null) || Object.prototype,
      c = aa(b);
    c.next = a;
    b[Symbol.iterator] ||
      (c[Symbol.iterator] = function () {
        return this;
      });
    return c;
  };
  u("Promise", function (a) {
    function b() {
      this.h = null;
    }
    function c(g) {
      return g instanceof e
        ? g
        : new e(function (h) {
            h(g);
          });
    }
    if (a) return a;
    b.prototype.j = function (g) {
      if (this.h == null) {
        this.h = [];
        var h = this;
        this.l(function () {
          h.A();
        });
      }
      this.h.push(g);
    };
    var d = ea.setTimeout;
    b.prototype.l = function (g) {
      d(g, 0);
    };
    b.prototype.A = function () {
      for (; this.h && this.h.length; ) {
        var g = this.h;
        this.h = [];
        for (var h = 0; h < g.length; ++h) {
          var k = g[h];
          g[h] = null;
          try {
            k();
          } catch (l) {
            this.o(l);
          }
        }
      }
      this.h = null;
    };
    b.prototype.o = function (g) {
      this.l(function () {
        throw g;
      });
    };
    var e = function (g) {
      this.la = 0;
      this.j = void 0;
      this.h = [];
      this.D = !1;
      var h = this.l();
      try {
        g(h.resolve, h.reject);
      } catch (k) {
        h.reject(k);
      }
    };
    e.prototype.l = function () {
      function g(l) {
        return function (m) {
          k || ((k = !0), l.call(h, m));
        };
      }
      var h = this,
        k = !1;
      return { resolve: g(this.H), reject: g(this.o) };
    };
    e.prototype.H = function (g) {
      if (g === this)
        this.o(new TypeError("A Promise cannot resolve to itself"));
      else if (g instanceof e) this.J(g);
      else {
        a: switch (typeof g) {
          case "object":
            var h = g != null;
            break a;
          case "function":
            h = !0;
            break a;
          default:
            h = !1;
        }
        h ? this.N(g) : this.A(g);
      }
    };
    e.prototype.N = function (g) {
      var h = void 0;
      try {
        h = g.then;
      } catch (k) {
        this.o(k);
        return;
      }
      typeof h == "function" ? this.K(h, g) : this.A(g);
    };
    e.prototype.o = function (g) {
      this.B(2, g);
    };
    e.prototype.A = function (g) {
      this.B(1, g);
    };
    e.prototype.B = function (g, h) {
      if (this.la != 0)
        throw Error(
          "Cannot settle(" +
            g +
            ", " +
            h +
            "): Promise already settled in state" +
            this.la
        );
      this.la = g;
      this.j = h;
      this.la === 2 && this.V();
      this.C();
    };
    e.prototype.V = function () {
      var g = this;
      d(function () {
        if (g.F()) {
          var h = ea.console;
          typeof h !== "undefined" && h.error(g.j);
        }
      }, 1);
    };
    e.prototype.F = function () {
      if (this.D) return !1;
      var g = ea.CustomEvent,
        h = ea.Event,
        k = ea.dispatchEvent;
      if (typeof k === "undefined") return !0;
      typeof g === "function"
        ? (g = new g("unhandledrejection", { cancelable: !0 }))
        : typeof h === "function"
        ? (g = new h("unhandledrejection", { cancelable: !0 }))
        : ((g = ea.document.createEvent("CustomEvent")),
          g.initCustomEvent("unhandledrejection", !1, !0, g));
      g.promise = this;
      g.reason = this.j;
      return k(g);
    };
    e.prototype.C = function () {
      if (this.h != null) {
        for (var g = 0; g < this.h.length; ++g) f.j(this.h[g]);
        this.h = null;
      }
    };
    var f = new b();
    e.prototype.J = function (g) {
      var h = this.l();
      g.td(h.resolve, h.reject);
    };
    e.prototype.K = function (g, h) {
      var k = this.l();
      try {
        g.call(h, k.resolve, k.reject);
      } catch (l) {
        k.reject(l);
      }
    };
    e.prototype.then = function (g, h) {
      function k(q, r) {
        return typeof q == "function"
          ? function (t) {
              try {
                l(q(t));
              } catch (v) {
                m(v);
              }
            }
          : r;
      }
      var l,
        m,
        p = new e(function (q, r) {
          l = q;
          m = r;
        });
      this.td(k(g, l), k(h, m));
      return p;
    };
    e.prototype.catch = function (g) {
      return this.then(void 0, g);
    };
    e.prototype.td = function (g, h) {
      function k() {
        switch (l.la) {
          case 1:
            g(l.j);
            break;
          case 2:
            h(l.j);
            break;
          default:
            throw Error("Unexpected state: " + l.la);
        }
      }
      var l = this;
      this.h == null ? f.j(k) : this.h.push(k);
      this.D = !0;
    };
    e.resolve = c;
    e.reject = function (g) {
      return new e(function (h, k) {
        k(g);
      });
    };
    e.race = function (g) {
      return new e(function (h, k) {
        for (var l = y(g), m = l.next(); !m.done; m = l.next())
          c(m.value).td(h, k);
      });
    };
    e.all = function (g) {
      var h = y(g),
        k = h.next();
      return k.done
        ? c([])
        : new e(function (l, m) {
            function p(t) {
              return function (v) {
                q[t] = v;
                r--;
                r == 0 && l(q);
              };
            }
            var q = [],
              r = 0;
            do
              q.push(void 0),
                r++,
                c(k.value).td(p(q.length - 1), m),
                (k = h.next());
            while (!k.done);
          });
    };
    return e;
  });
  u("Object.setPrototypeOf", function (a) {
    return a || na;
  });
  u("Object.assign", function (a) {
    return a || xa;
  });
  u("Symbol.dispose", function (a) {
    return a ? a : Symbol("Symbol.dispose");
  });
  var Oa = function (a, b, c) {
    a instanceof String && (a = String(a));
    for (var d = a.length, e = 0; e < d; e++) {
      var f = a[e];
      if (b.call(c, f, e, a)) return { Bg: e, th: f };
    }
    return { Bg: -1, th: void 0 };
  };
  u("Array.prototype.find", function (a) {
    return a
      ? a
      : function (b, c) {
          return Oa(this, b, c).th;
        };
  });
  u("WeakMap", function (a) {
    function b() {}
    function c(k) {
      var l = typeof k;
      return (l === "object" && k !== null) || l === "function";
    }
    function d(k) {
      if (!va(k, f)) {
        var l = new b();
        ba(k, f, { value: l });
      }
    }
    function e(k) {
      var l = Object[k];
      l &&
        (Object[k] = function (m) {
          if (m instanceof b) return m;
          Object.isExtensible(m) && d(m);
          return l(m);
        });
    }
    if (
      (function () {
        if (!a || !Object.seal) return !1;
        try {
          var k = Object.seal({}),
            l = Object.seal({}),
            m = new a([
              [k, 2],
              [l, 3],
            ]);
          if (m.get(k) != 2 || m.get(l) != 3) return !1;
          m.delete(k);
          m.set(l, 4);
          return !m.has(k) && m.get(l) == 4;
        } catch (p) {
          return !1;
        }
      })()
    )
      return a;
    var f = "$jscomp_hidden_" + Math.random();
    e("freeze");
    e("preventExtensions");
    e("seal");
    var g = 0,
      h = function (k) {
        this.h = (g += Math.random() + 1).toString();
        if (k) {
          k = y(k);
          for (var l; !(l = k.next()).done; )
            (l = l.value), this.set(l[0], l[1]);
        }
      };
    h.prototype.set = function (k, l) {
      if (!c(k)) throw Error("Invalid WeakMap key");
      d(k);
      if (!va(k, f)) throw Error("WeakMap key fail: " + k);
      k[f][this.h] = l;
      return this;
    };
    h.prototype.get = function (k) {
      return c(k) && va(k, f) ? k[f][this.h] : void 0;
    };
    h.prototype.has = function (k) {
      return c(k) && va(k, f) && va(k[f], this.h);
    };
    h.prototype.delete = function (k) {
      return c(k) && va(k, f) && va(k[f], this.h) ? delete k[f][this.h] : !1;
    };
    return h;
  });
  u("Map", function (a) {
    if (
      (function () {
        if (
          !a ||
          typeof a != "function" ||
          !a.prototype.entries ||
          typeof Object.seal != "function"
        )
          return !1;
        try {
          var h = Object.seal({ x: 4 }),
            k = new a(y([[h, "s"]]));
          if (
            k.get(h) != "s" ||
            k.size != 1 ||
            k.get({ x: 4 }) ||
            k.set({ x: 4 }, "t") != k ||
            k.size != 2
          )
            return !1;
          var l = k.entries(),
            m = l.next();
          if (m.done || m.value[0] != h || m.value[1] != "s") return !1;
          m = l.next();
          return !(
            m.done ||
            m.value[0].x != 4 ||
            m.value[1] != "t" ||
            !l.next().done
          );
        } catch (p) {
          return !1;
        }
      })()
    )
      return a;
    var b = new WeakMap(),
      c = function (h) {
        this[0] = {};
        this[1] = f();
        this.size = 0;
        if (h) {
          h = y(h);
          for (var k; !(k = h.next()).done; )
            (k = k.value), this.set(k[0], k[1]);
        }
      };
    c.prototype.set = function (h, k) {
      h = h === 0 ? 0 : h;
      var l = d(this, h);
      l.list || (l.list = this[0][l.id] = []);
      l.entry
        ? (l.entry.value = k)
        : ((l.entry = {
            next: this[1],
            wb: this[1].wb,
            head: this[1],
            key: h,
            value: k,
          }),
          l.list.push(l.entry),
          (this[1].wb.next = l.entry),
          (this[1].wb = l.entry),
          this.size++);
      return this;
    };
    c.prototype.delete = function (h) {
      h = d(this, h);
      return h.entry && h.list
        ? (h.list.splice(h.index, 1),
          h.list.length || delete this[0][h.id],
          (h.entry.wb.next = h.entry.next),
          (h.entry.next.wb = h.entry.wb),
          (h.entry.head = null),
          this.size--,
          !0)
        : !1;
    };
    c.prototype.clear = function () {
      this[0] = {};
      this[1] = this[1].wb = f();
      this.size = 0;
    };
    c.prototype.has = function (h) {
      return !!d(this, h).entry;
    };
    c.prototype.get = function (h) {
      return (h = d(this, h).entry) && h.value;
    };
    c.prototype.entries = function () {
      return e(this, function (h) {
        return [h.key, h.value];
      });
    };
    c.prototype.keys = function () {
      return e(this, function (h) {
        return h.key;
      });
    };
    c.prototype.values = function () {
      return e(this, function (h) {
        return h.value;
      });
    };
    c.prototype.forEach = function (h, k) {
      for (var l = this.entries(), m; !(m = l.next()).done; )
        (m = m.value), h.call(k, m[1], m[0], this);
    };
    c.prototype[Symbol.iterator] = c.prototype.entries;
    var d = function (h, k) {
        var l = k && typeof k;
        l == "object" || l == "function"
          ? b.has(k)
            ? (l = b.get(k))
            : ((l = "" + ++g), b.set(k, l))
          : (l = "p_" + k);
        var m = h[0][l];
        if (m && va(h[0], l))
          for (h = 0; h < m.length; h++) {
            var p = m[h];
            if ((k !== k && p.key !== p.key) || k === p.key)
              return { id: l, list: m, index: h, entry: p };
          }
        return { id: l, list: m, index: -1, entry: void 0 };
      },
      e = function (h, k) {
        var l = h[1];
        return Na(function () {
          if (l) {
            for (; l.head != h[1]; ) l = l.wb;
            for (; l.next != l.head; )
              return (l = l.next), { done: !1, value: k(l) };
            l = null;
          }
          return { done: !0, value: void 0 };
        });
      },
      f = function () {
        var h = {};
        return (h.wb = h.next = h.head = h);
      },
      g = 0;
    return c;
  });
  u("Set", function (a) {
    if (
      (function () {
        if (
          !a ||
          typeof a != "function" ||
          !a.prototype.entries ||
          typeof Object.seal != "function"
        )
          return !1;
        try {
          var c = Object.seal({ x: 4 }),
            d = new a(y([c]));
          if (
            !d.has(c) ||
            d.size != 1 ||
            d.add(c) != d ||
            d.size != 1 ||
            d.add({ x: 4 }) != d ||
            d.size != 2
          )
            return !1;
          var e = d.entries(),
            f = e.next();
          if (f.done || f.value[0] != c || f.value[1] != c) return !1;
          f = e.next();
          return f.done ||
            f.value[0] == c ||
            f.value[0].x != 4 ||
            f.value[1] != f.value[0]
            ? !1
            : e.next().done;
        } catch (g) {
          return !1;
        }
      })()
    )
      return a;
    var b = function (c) {
      this.h = new Map();
      if (c) {
        c = y(c);
        for (var d; !(d = c.next()).done; ) this.add(d.value);
      }
      this.size = this.h.size;
    };
    b.prototype.add = function (c) {
      c = c === 0 ? 0 : c;
      this.h.set(c, c);
      this.size = this.h.size;
      return this;
    };
    b.prototype.delete = function (c) {
      c = this.h.delete(c);
      this.size = this.h.size;
      return c;
    };
    b.prototype.clear = function () {
      this.h.clear();
      this.size = 0;
    };
    b.prototype.has = function (c) {
      return this.h.has(c);
    };
    b.prototype.entries = function () {
      return this.h.entries();
    };
    b.prototype.values = function () {
      return this.h.values();
    };
    b.prototype.keys = b.prototype.values;
    b.prototype[Symbol.iterator] = b.prototype.values;
    b.prototype.forEach = function (c, d) {
      var e = this;
      this.h.forEach(function (f) {
        return c.call(d, f, f, e);
      });
    };
    return b;
  });
  u("Iterator", function (a) {
    var b = Object.getPrototypeOf,
      c =
        typeof Symbol != "undefined" && Symbol.iterator && [][Symbol.iterator]
          ? [][Symbol.iterator]()
          : null;
    b = (c = c && b ? b(c) : null) && b ? b(c) : null;
    b === Object.prototype && (b = null);
    if (a && b && a.prototype === b) return a;
    var d = function () {
      if (!(this instanceof d) || this.constructor === d)
        throw new TypeError("Abstract Iterator not directly constructable");
    };
    b && (d.prototype = b);
    ba(d.prototype, "constructor", {
      configurable: !0,
      writable: !0,
      value: d,
    });
    d.prototype[Symbol.iterator] ||
      (d.prototype[Symbol.iterator] = function () {
        return this;
      });
    return d;
  });
  var Pa = function (a) {
      if (Object(a) !== a) throw new TypeError("Expected an object");
      return a;
    },
    Qa = function (a) {
      try {
        var b = a["return"];
        typeof b == "function" && b.call(a);
      } catch (c) {}
    },
    Ra = function (a, b) {
      b == null && (b = !0);
      return { value: a, done: b };
    },
    Sa = null,
    Ta = function (a, b) {
      var c = Sa;
      if (!c) {
        var d = function (e, f) {
          if (!e || e.Yj !== e)
            throw new TypeError("Method called on incompatible object");
          var g = e.la;
          if (g === 3) throw new TypeError("Generator is already running");
          if (g != 4) {
            e.la = f && g == 1 ? 4 : 3;
            try {
              if (f) {
                var h = e.Jg,
                  k = h["return"];
                if (k != null) {
                  if (typeof k != "function")
                    throw new TypeError("Iterator return is not a function");
                  Pa(k.call(h));
                }
              } else {
                var l = e.mh();
                if (l) return (e.la = 2), l;
              }
            } finally {
              e.la != 2 && ((e.la = 4), (e.mh = e.Jg = null));
            }
          }
          return Ra();
        };
        c = Sa = aa(Iterator.prototype);
        c.next = function () {
          return d(this, !1);
        };
        c.return = function () {
          return d(this, !0);
        };
        c[Symbol.toStringTag] = "Iterator Helper";
      }
      c = aa(c);
      c.Yj = c;
      c.la = 1;
      c.Jg = a;
      c.mh = b;
      return c;
    },
    Ua = function (a, b) {
      Pa(a);
      if (typeof b != "function")
        throw (Qa(a), new TypeError("callback must be a function"));
    },
    Va = function (a, b, c) {
      Ua(a, b);
      b = a.next;
      for (var d = 0, e; !(e = Pa(b.call(a))).done; ) {
        try {
          var f = c(e.value, d++);
        } catch (g) {
          try {
            z(a, e);
          } catch (h) {}
          throw g;
        }
        if (f) {
          c = a["return"];
          c != null && Pa(c.call(a));
          break;
        }
      }
    };
  u("Iterator.prototype.find", function (a) {
    return (
      a ||
      function (b) {
        var c;
        Va(this, b, function (d, e) {
          if (b(d, e)) return (c = d), !0;
        });
        return c;
      }
    );
  });
  u("Object.values", function (a) {
    return a
      ? a
      : function (b) {
          var c = [],
            d;
          for (d in b) va(b, d) && c.push(b[d]);
          return c;
        };
  });
  u("Object.is", function (a) {
    return a
      ? a
      : function (b, c) {
          return b === c ? b !== 0 || 1 / b === 1 / c : b !== b && c !== c;
        };
  });
  u("Array.prototype.includes", function (a) {
    return a
      ? a
      : function (b, c) {
          var d = this;
          d instanceof String && (d = String(d));
          var e = d.length;
          c = c || 0;
          for (c < 0 && (c = Math.max(c + e, 0)); c < e; c++) {
            var f = d[c];
            if (f === b || Object.is(f, b)) return !0;
          }
          return !1;
        };
  });
  var Wa = function (a, b, c) {
    if (a == null)
      throw new TypeError(
        "The 'this' value for String.prototype." +
          c +
          " must not be null or undefined"
      );
    if (b instanceof RegExp)
      throw new TypeError(
        "First argument to String.prototype." +
          c +
          " must not be a regular expression"
      );
    return a + "";
  };
  u("String.prototype.includes", function (a) {
    return a
      ? a
      : function (b, c) {
          return Wa(this, b, "includes").indexOf(b, c || 0) !== -1;
        };
  });
  u("Array.from", function (a) {
    return a
      ? a
      : function (b, c, d) {
          c =
            c != null
              ? c
              : function (h) {
                  return h;
                };
          var e = [],
            f =
              typeof Symbol != "undefined" &&
              Symbol.iterator &&
              b[Symbol.iterator];
          if (typeof f == "function") {
            b = f.call(b);
            for (var g = 0; !(f = b.next()).done; )
              e.push(c.call(d, f.value, g++));
          } else
            for (f = b.length, g = 0; g < f; g++) e.push(c.call(d, b[g], g));
          return e;
        };
  });
  u("Object.entries", function (a) {
    return a
      ? a
      : function (b) {
          var c = [],
            d;
          for (d in b) va(b, d) && c.push([d, b[d]]);
          return c;
        };
  });
  u("Number.isFinite", function (a) {
    return a
      ? a
      : function (b) {
          return typeof b !== "number"
            ? !1
            : !isNaN(b) && b !== Infinity && b !== -Infinity;
        };
  });
  u("Number.MAX_SAFE_INTEGER", function () {
    return 9007199254740991;
  });
  u("Number.MIN_SAFE_INTEGER", function () {
    return -9007199254740991;
  });
  u("Number.isInteger", function (a) {
    return a
      ? a
      : function (b) {
          return Number.isFinite(b) ? b === Math.floor(b) : !1;
        };
  });
  u("Number.isSafeInteger", function (a) {
    return a
      ? a
      : function (b) {
          return Number.isInteger(b) && Math.abs(b) <= Number.MAX_SAFE_INTEGER;
        };
  });
  u("String.prototype.startsWith", function (a) {
    return a
      ? a
      : function (b, c) {
          var d = Wa(this, b, "startsWith");
          b += "";
          var e = d.length,
            f = b.length;
          c = Math.max(0, Math.min(c | 0, d.length));
          for (var g = 0; g < f && c < e; ) if (d[c++] != b[g++]) return !1;
          return g >= f;
        };
  });
  u("String.prototype.endsWith", function (a) {
    return a
      ? a
      : function (b, c) {
          var d = Wa(this, b, "endsWith");
          b += "";
          c === void 0 && (c = d.length);
          c = Math.max(0, Math.min(c | 0, d.length));
          for (var e = b.length; e > 0 && c > 0; )
            if (d[--c] != b[--e]) return !1;
          return e <= 0;
        };
  });
  var Xa = function (a, b) {
    a instanceof String && (a += "");
    var c = 0,
      d = !1;
    return Na(function () {
      if (!d && c < a.length) {
        var e = c++;
        return { value: b(e, a[e]), done: !1 };
      }
      d = !0;
      return { done: !0, value: void 0 };
    });
  };
  u("Array.prototype.entries", function (a) {
    return a
      ? a
      : function () {
          return Xa(this, function (b, c) {
            return [b, c];
          });
        };
  });
  u("Math.trunc", function (a) {
    return a
      ? a
      : function (b) {
          b = Number(b);
          if (isNaN(b) || b === Infinity || b === -Infinity || b === 0)
            return b;
          var c = Math.floor(Math.abs(b));
          return b < 0 ? -c : c;
        };
  });
  u("Number.isNaN", function (a) {
    return a
      ? a
      : function (b) {
          return typeof b === "number" && isNaN(b);
        };
  });
  u("Array.prototype.keys", function (a) {
    return a
      ? a
      : function () {
          return Xa(this, function (b) {
            return b;
          });
        };
  });
  u("Array.prototype.values", function (a) {
    return a
      ? a
      : function () {
          return Xa(this, function (b, c) {
            return c;
          });
        };
  });
  u("Object.fromEntries", function (a) {
    return a
      ? a
      : function (b) {
          var c = {};
          if (!(Symbol.iterator in b))
            throw new TypeError("" + b + " is not iterable");
          b = b[Symbol.iterator].call(b);
          for (var d = b.next(); !d.done; d = b.next()) {
            d = d.value;
            if (Object(d) !== d)
              throw new TypeError(
                "iterable for fromEntries should yield objects"
              );
            Object.defineProperty(c, d[0], {
              value: d[1],
              writable: !0,
              enumerable: !0,
              configurable: !0,
            });
          }
          return c;
        };
  });
  u("Iterator.prototype.forEach", function (a) {
    return (
      a ||
      function (b) {
        Va(this, b, function (c, d) {
          b(c, d);
        });
      }
    );
  });
  var Ya = function (a, b, c) {
    Ua(a, b);
    var d = a.next,
      e = 0;
    return Ta(a, function () {
      for (;;) {
        var f = Pa(d.call(a));
        if (f.done) break;
        f = f.value;
        try {
          var g = b(f, e++);
        } catch (h) {
          throw (Qa(a), h);
        }
        if (!c || g) return Ra(c ? f : g, !1);
      }
    });
  };
  u("Iterator.prototype.map", function (a) {
    return (
      a ||
      function (b) {
        return Ya(this, b, !1);
      }
    );
  });
  u("String.prototype.repeat", function (a) {
    return a
      ? a
      : function (b) {
          var c = Wa(this, null, "repeat");
          if (b < 0 || b > 1342177279)
            throw new RangeError("Invalid count value");
          b |= 0;
          for (var d = ""; b; ) if ((b & 1 && (d += c), (b >>>= 1))) c += c;
          return d;
        };
  });
  u("String.fromCodePoint", function (a) {
    return a
      ? a
      : function (b) {
          for (var c = "", d = 0; d < arguments.length; d++) {
            var e = Number(arguments[d]);
            if (e < 0 || e > 1114111 || e !== Math.floor(e))
              throw new RangeError("invalid_code_point " + e);
            e <= 65535
              ? (c += String.fromCharCode(e))
              : ((e -= 65536),
                (c += String.fromCharCode(((e >>> 10) & 1023) | 55296)),
                (c += String.fromCharCode((e & 1023) | 56320)));
          }
          return c;
        };
  });
  u("Iterator.prototype.filter", function (a) {
    return (
      a ||
      function (b) {
        return Ya(this, b, !0);
      }
    );
  });
  u("Array.prototype.findIndex", function (a) {
    return a
      ? a
      : function (b, c) {
          return Oa(this, b, c).Bg;
        };
  });
  u("Iterator.prototype.reduce", function (a) {
    return (
      a ||
      function (b) {
        var c = arguments.length > 1,
          d = arguments[1];
        Va(this, b, function (e, f) {
          c ? (d = b(d, e, f)) : ((c = !0), (d = e));
        });
        if (!c) throw new TypeError("Reduce of empty iterator");
        return d;
      }
    );
  });
  u("Iterator.prototype.some", function (a) {
    return (
      a ||
      function (b) {
        var c = !1;
        Va(this, b, function (d, e) {
          return (c = !!b(d, e));
        });
        return c;
      }
    );
  });
  u("String.prototype.padStart", function (a) {
    return a
      ? a
      : function (b, c) {
          var d = Wa(this, null, "padStart");
          b -= d.length;
          c = c !== void 0 ? String(c) : " ";
          return (
            (b > 0 && c
              ? c.repeat(Math.ceil(b / c.length)).substring(0, b)
              : "") + d
          );
        };
  });
  u("Number.parseInt", function (a) {
    return a || parseInt;
  });
  u("Promise.prototype.finally", function (a) {
    return a
      ? a
      : function (b) {
          return this.then(
            function (c) {
              return Promise.resolve(b()).then(function () {
                return c;
              });
            },
            function (c) {
              return Promise.resolve(b()).then(function () {
                throw c;
              });
            }
          );
        };
  });
  u("Math.imul", function (a) {
    return a
      ? a
      : function (b, c) {
          b = Number(b);
          c = Number(c);
          var d = b & 65535,
            e = c & 65535;
          return (
            (d * e +
              (((((b >>> 16) & 65535) * e + d * ((c >>> 16) & 65535)) << 16) >>>
                0)) |
            0
          );
        };
  });
  u("Array.prototype.flatMap", function (a) {
    return a
      ? a
      : function (b, c) {
          var d = [];
          Array.prototype.forEach.call(this, function (e, f, g) {
            e = b.call(c, e, f, g);
            Array.isArray(e) ? d.push.apply(d, e) : d.push(e);
          });
          return d;
        };
  }); /* 
 
 Copyright The Closure Library Authors. 
 SPDX-License-Identifier: Apache-2.0 
*/
  var Za = Za || {},
    C = this || self,
    D = function (a, b, c) {
      a = a.split(".");
      c = c || C;
      for (var d; a.length && (d = a.shift()); )
        a.length || b === void 0
          ? c[d] && c[d] !== Object.prototype[d]
            ? (c = c[d])
            : (c = c[d] = {})
          : (c[d] = b);
    },
    $a = function (a, b) {
      a = a.split(".");
      b = b || C;
      for (var c = 0; c < a.length; c++)
        if (((b = b[a[c]]), b == null)) return null;
      return b;
    },
    ab = function (a) {
      var b = typeof a;
      return b != "object" ? b : a ? (Array.isArray(a) ? "array" : b) : "null";
    },
    bb = function (a) {
      var b = ab(a);
      return b == "array" || (b == "object" && typeof a.length == "number");
    },
    cb = function (a) {
      var b = typeof a;
      return (b == "object" && a != null) || b == "function";
    },
    fb = function (a) {
      return (
        (Object.prototype.hasOwnProperty.call(a, db) && a[db]) || (a[db] = ++eb)
      );
    },
    gb = function (a) {
      a !== null && "removeAttribute" in a && a.removeAttribute(db);
      try {
        delete a[db];
      } catch (b) {}
    },
    db = "closure_uid_" + ((Math.random() * 1e9) >>> 0),
    eb = 0,
    ib = function (a, b, c) {
      return a.call.apply(a.bind, arguments);
    },
    jb = function (a, b, c) {
      if (!a) throw Error();
      if (arguments.length > 2) {
        var d = Array.prototype.slice.call(arguments, 2);
        return function () {
          var e = Array.prototype.slice.call(arguments);
          Array.prototype.unshift.apply(e, d);
          return a.apply(b, e);
        };
      }
      return function () {
        return a.apply(b, arguments);
      };
    },
    kb = function (a, b, c) {
      kb =
        Function.prototype.bind &&
        Function.prototype.bind.toString().indexOf("native code") != -1
          ? ib
          : jb;
      return kb.apply(null, arguments);
    },
    lb = function (a, b) {
      var c = Array.prototype.slice.call(arguments, 1);
      return function () {
        var d = c.slice();
        d.push.apply(d, arguments);
        return a.apply(this, d);
      };
    },
    nb = function (a) {
      return a;
    },
    ob = function (a, b) {
      function c() {}
      c.prototype = b.prototype;
      a.yb = b.prototype;
      a.prototype = new c();
      a.prototype.constructor = a;
      a.wm = function (d, e, f) {
        for (
          var g = Array(arguments.length - 2), h = 2;
          h < arguments.length;
          h++
        )
          g[h - 2] = arguments[h];
        return b.prototype[e].apply(d, g);
      };
    };
  function pb(a, b) {
    if (Error.captureStackTrace) Error.captureStackTrace(this, pb);
    else {
      var c = Error().stack;
      c && (this.stack = c);
    }
    a && (this.message = String(a));
    b !== void 0 && (this.cause = b);
  }
  ob(pb, Error);
  pb.prototype.name = "CustomError";
  var qb;
  function rb() {
    throw Error("Invalid UTF8");
  }
  function sb(a, b) {
    b = String.fromCharCode.apply(null, b);
    return a == null ? b : a + b;
  }
  var tb = void 0,
    ub,
    vb = typeof TextDecoder !== "undefined",
    wb,
    xb = typeof String.prototype.isWellFormed === "function",
    yb = typeof TextEncoder !== "undefined";
  function zb(a) {
    var b = !1;
    b = b === void 0 ? !1 : b;
    if (yb) {
      if (
        b &&
        (xb
          ? !a.isWellFormed()
          : /(?:[^\uD800-\uDBFF]|^)[\uDC00-\uDFFF]|[\uD800-\uDBFF](?![\uDC00-\uDFFF])/.test(
              a
            ))
      )
        throw Error("Found an unpaired surrogate");
      a = (wb || (wb = new TextEncoder())).encode(a);
    } else {
      for (
        var c = 0, d = new Uint8Array(3 * a.length), e = 0;
        e < a.length;
        e++
      ) {
        var f = a.charCodeAt(e);
        if (f < 128) d[c++] = f;
        else {
          if (f < 2048) d[c++] = (f >> 6) | 192;
          else {
            if (f >= 55296 && f <= 57343) {
              if (f <= 56319 && e < a.length) {
                var g = a.charCodeAt(++e);
                if (g >= 56320 && g <= 57343) {
                  f = (f - 55296) * 1024 + g - 56320 + 65536;
                  d[c++] = (f >> 18) | 240;
                  d[c++] = ((f >> 12) & 63) | 128;
                  d[c++] = ((f >> 6) & 63) | 128;
                  d[c++] = (f & 63) | 128;
                  continue;
                } else e--;
              }
              if (b) throw Error("Found an unpaired surrogate");
              f = 65533;
            }
            d[c++] = (f >> 12) | 224;
            d[c++] = ((f >> 6) & 63) | 128;
          }
          d[c++] = (f & 63) | 128;
        }
      }
      a = c === d.length ? d : d.subarray(0, c);
    }
    return a;
  }
  function Ab(a) {
    C.setTimeout(function () {
      throw a;
    }, 0);
  }
  var Bb,
    Cb = $a("CLOSURE_FLAGS"),
    Db = Cb && Cb[748402147];
  Bb = Db != null ? Db : !0;
  function Eb(a, b) {
    var c = a.length - b.length;
    return c >= 0 && a.indexOf(b, c) == c;
  }
  function Fb(a) {
    return /^[\s\xa0]*$/.test(a);
  }
  var Gb = String.prototype.trim
      ? function (a) {
          return a.trim();
        }
      : function (a) {
          return /^[\s\xa0]*([\s\S]*?)[\s\xa0]*$/.exec(a)[1];
        },
    Hb = /&/g,
    Ib = /</g,
    Jb = />/g,
    Kb = /"/g,
    Lb = /'/g,
    Mb = /\x00/g,
    Nb = /[\x00&<>"']/;
  function Ob(a, b) {
    return a.indexOf(b) != -1;
  }
  function Pb(a, b) {
    return Ob(a.toLowerCase(), b.toLowerCase());
  }
  function Qb(a, b) {
    var c = 0;
    a = Gb(String(a)).split(".");
    b = Gb(String(b)).split(".");
    for (var d = Math.max(a.length, b.length), e = 0; c == 0 && e < d; e++) {
      var f = a[e] || "",
        g = b[e] || "";
      do {
        f = /(\d*)(\D*)(.*)/.exec(f) || ["", "", "", ""];
        g = /(\d*)(\D*)(.*)/.exec(g) || ["", "", "", ""];
        if (f[0].length == 0 && g[0].length == 0) break;
        c =
          Rb(
            f[1].length == 0 ? 0 : parseInt(f[1], 10),
            g[1].length == 0 ? 0 : parseInt(g[1], 10)
          ) ||
          Rb(f[2].length == 0, g[2].length == 0) ||
          Rb(f[2], g[2]);
        f = f[3];
        g = g[3];
      } while (c == 0);
    }
    return c;
  }
  function Rb(a, b) {
    return a < b ? -1 : a > b ? 1 : 0;
  }
  function Sb() {
    var a = C.navigator;
    return a && (a = a.userAgent) ? a : "";
  }
  function G(a) {
    return Ob(Sb(), a);
  }
  function Tb() {
    return G("Trident") || G("MSIE");
  }
  function Ub() {
    return G("Firefox") || G("FxiOS");
  }
  function Wb() {
    return ((G("Chrome") || G("CriOS")) && !G("Edge")) || G("Silk");
  }
  function Xb() {
    return G("iPhone") && !G("iPod") && !G("iPad");
  }
  var Yb = function (a, b) {
      if (typeof a === "string")
        return typeof b !== "string" || b.length != 1 ? -1 : a.indexOf(b, 0);
      for (var c = 0; c < a.length; c++) if (c in a && a[c] === b) return c;
      return -1;
    },
    Zb = function (a, b) {
      for (
        var c = a.length, d = typeof a === "string" ? a.split("") : a, e = 0;
        e < c;
        e++
      )
        e in d && b.call(void 0, d[e], e, a);
    };
  function $b(a, b) {
    for (
      var c = typeof a === "string" ? a.split("") : a, d = a.length - 1;
      d >= 0;
      --d
    )
      d in c && b.call(void 0, c[d], d, a);
  }
  var bc = function (a, b) {
      for (
        var c = a.length,
          d = [],
          e = 0,
          f = typeof a === "string" ? a.split("") : a,
          g = 0;
        g < c;
        g++
      )
        if (g in f) {
          var h = f[g];
          b.call(void 0, h, g, a) && (d[e++] = h);
        }
      return d;
    },
    cc = function (a, b) {
      for (
        var c = a.length,
          d = Array(c),
          e = typeof a === "string" ? a.split("") : a,
          f = 0;
        f < c;
        f++
      )
        f in e && (d[f] = b.call(void 0, e[f], f, a));
      return d;
    },
    dc = function (a, b, c) {
      var d = c;
      Zb(a, function (e, f) {
        d = b.call(void 0, d, e, f, a);
      });
      return d;
    },
    ec = function (a, b) {
      for (
        var c = a.length, d = typeof a === "string" ? a.split("") : a, e = 0;
        e < c;
        e++
      )
        if (e in d && b.call(void 0, d[e], e, a)) return !0;
      return !1;
    };
  function fc(a, b) {
    b = hc(a, b);
    return b < 0 ? null : typeof a === "string" ? a.charAt(b) : a[b];
  }
  function hc(a, b) {
    for (
      var c = a.length, d = typeof a === "string" ? a.split("") : a, e = 0;
      e < c;
      e++
    )
      if (e in d && b.call(void 0, d[e], e, a)) return e;
    return -1;
  }
  function ic(a, b) {
    b = jc(a, b);
    return b < 0 ? null : typeof a === "string" ? a.charAt(b) : a[b];
  }
  function jc(a, b) {
    for (
      var c = typeof a === "string" ? a.split("") : a, d = a.length - 1;
      d >= 0;
      d--
    )
      if (d in c && b.call(void 0, c[d], d, a)) return d;
    return -1;
  }
  function kc(a, b) {
    return Yb(a, b) >= 0;
  }
  function lc(a, b) {
    b = Yb(a, b);
    var c;
    (c = b >= 0) && mc(a, b);
    return c;
  }
  function mc(a, b) {
    return Array.prototype.splice.call(a, b, 1).length == 1;
  }
  function nc(a, b) {
    var c = 0;
    $b(a, function (d, e) {
      b.call(void 0, d, e, a) && mc(a, e) && c++;
    });
  }
  function oc(a) {
    return Array.prototype.concat.apply([], arguments);
  }
  function qc(a) {
    var b = a.length;
    if (b > 0) {
      for (var c = Array(b), d = 0; d < b; d++) c[d] = a[d];
      return c;
    }
    return [];
  }
  function rc(a) {
    for (var b = 0, c = 0, d = {}; c < a.length; ) {
      var e = a[c++],
        f = cb(e) ? "o" + fb(e) : (typeof e).charAt(0) + e;
      Object.prototype.hasOwnProperty.call(d, f) || ((d[f] = !0), (a[b++] = e));
    }
    a.length = b;
  }
  function sc(a, b) {
    a.sort(b || tc);
  }
  function tc(a, b) {
    return a > b ? 1 : a < b ? -1 : 0;
  }
  function uc(a, b) {
    for (var c = {}, d = 0; d < a.length; d++) {
      var e = a[d],
        f = b.call(void 0, e, d, a);
      f !== void 0 && (c[f] || (c[f] = [])).push(e);
    }
    return c;
  }
  function vc(a) {
    for (var b = [], c = 0; c < a; c++) b[c] = "";
    return b;
  }
  var wc = function (a) {
    wc[" "](a);
    return a;
  };
  wc[" "] = function () {};
  var xc = function (a, b) {
      try {
        return wc(a[b]), !0;
      } catch (c) {}
      return !1;
    },
    zc = function (a) {
      var b = yc;
      return Object.prototype.hasOwnProperty.call(b, 8) ? b[8] : (b[8] = a(8));
    };
  var Ac = G("Opera"),
    Bc = Tb(),
    Cc = G("Edge"),
    Dc =
      G("Gecko") &&
      !(Pb(Sb(), "WebKit") && !G("Edge")) &&
      !(G("Trident") || G("MSIE")) &&
      !G("Edge"),
    Ec = Pb(Sb(), "WebKit") && !G("Edge"),
    Fc = G("Macintosh"),
    Gc = G("Android"),
    Hc = Xb(),
    Ic = G("iPad"),
    Jc = G("iPod"),
    Kc = Xb() || G("iPad") || G("iPod"),
    Lc;
  a: {
    var Mc = "",
      Nc = (function () {
        var a = Sb();
        if (Dc) return /rv:([^\);]+)(\)|;)/.exec(a);
        if (Cc) return /Edge\/([\d\.]+)/.exec(a);
        if (Bc) return /\b(?:MSIE|rv)[: ]([^\);]+)(\)|;)/.exec(a);
        if (Ec) return /WebKit\/(\S+)/.exec(a);
        if (Ac) return /(?:Version)[ \/]?(\S+)/.exec(a);
      })();
    Nc && (Mc = Nc ? Nc[1] : "");
    if (Bc) {
      var Oc,
        Pc = C.document;
      Oc = Pc ? Pc.documentMode : void 0;
      if (Oc != null && Oc > parseFloat(Mc)) {
        Lc = String(Oc);
        break a;
      }
    }
    Lc = Mc;
  }
  var Qc = Lc,
    yc = {},
    Rc = function () {
      return zc(function () {
        return Qb(Qc, 8) >= 0;
      });
    };
  var Sc = Ub(),
    Tc = G("Android") && !(Wb() || Ub() || G("Opera") || G("Silk")),
    Uc = Wb();
  var Vc = {},
    Wc = null;
  function Xc(a, b) {
    b === void 0 && (b = 0);
    Yc();
    b = Vc[b];
    for (
      var c = Array(Math.floor(a.length / 3)), d = b[64] || "", e = 0, f = 0;
      e < a.length - 2;
      e += 3
    ) {
      var g = a[e],
        h = a[e + 1],
        k = a[e + 2],
        l = b[g >> 2];
      g = b[((g & 3) << 4) | (h >> 4)];
      h = b[((h & 15) << 2) | (k >> 6)];
      k = b[k & 63];
      c[f++] = "" + l + g + h + k;
    }
    l = 0;
    k = d;
    switch (a.length - e) {
      case 2:
        (l = a[e + 1]), (k = b[(l & 15) << 2] || d);
      case 1:
        (a = a[e]),
          (c[f] = "" + b[a >> 2] + b[((a & 3) << 4) | (l >> 4)] + k + d);
    }
    return c.join("");
  }
  function Zc(a) {
    var b = [];
    $c(a, function (c) {
      b.push(c);
    });
    return b;
  }
  function ad(a) {
    var b = a.length,
      c = (b * 3) / 4;
    c % 3
      ? (c = Math.floor(c))
      : Ob("=.", a[b - 1]) && (c = Ob("=.", a[b - 2]) ? c - 2 : c - 1);
    var d = new Uint8Array(c),
      e = 0;
    $c(a, function (f) {
      d[e++] = f;
    });
    return e !== c ? d.subarray(0, e) : d;
  }
  function $c(a, b) {
    function c(k) {
      for (; d < a.length; ) {
        var l = a.charAt(d++),
          m = Wc[l];
        if (m != null) return m;
        if (!Fb(l)) throw Error("Unknown base64 encoding at char: " + l);
      }
      return k;
    }
    Yc();
    for (var d = 0; ; ) {
      var e = c(-1),
        f = c(0),
        g = c(64),
        h = c(64);
      if (h === 64 && e === -1) break;
      b((e << 2) | (f >> 4));
      g != 64 &&
        (b(((f << 4) & 240) | (g >> 2)), h != 64 && b(((g << 6) & 192) | h));
    }
  }
  function Yc() {
    if (!Wc) {
      Wc = {};
      for (
        var a =
            "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(
              ""
            ),
          b = ["+/=", "+/", "-_=", "-_.", "-_"],
          c = 0;
        c < 5;
        c++
      ) {
        var d = a.concat(b[c].split(""));
        Vc[c] = d;
        for (var e = 0; e < d.length; e++) {
          var f = d[e];
          Wc[f] === void 0 && (Wc[f] = e);
        }
      }
    }
  }
  var bd = typeof Uint8Array !== "undefined",
    cd = !Bc && typeof btoa === "function",
    dd = /[-_.]/g,
    ed = { "-": "+", _: "/", ".": "=" };
  function fd(a) {
    return ed[a] || "";
  }
  function gd(a) {
    if (!cd) return ad(a);
    a = dd.test(a) ? a.replace(dd, fd) : a;
    a = atob(a);
    for (var b = new Uint8Array(a.length), c = 0; c < a.length; c++)
      b[c] = a.charCodeAt(c);
    return b;
  }
  var hd = {};
  var jd = function (a, b) {
    id(b);
    this.h = a;
    if (a != null && a.length === 0)
      throw Error("ByteString should be constructed with non-empty values");
  };
  jd.prototype.isEmpty = function () {
    return this.h == null;
  };
  var kd = function (a) {
      id(hd);
      var b = a.h;
      b =
        b == null || (bd && b != null && b instanceof Uint8Array)
          ? b
          : typeof b === "string"
          ? gd(b)
          : null;
      return b == null ? b : (a.h = b);
    },
    ld;
  function id(a) {
    if (a !== hd) throw Error("illegal external caller");
  }
  function md(a, b) {
    a.__closure__error__context__984382 ||
      (a.__closure__error__context__984382 = {});
    a.__closure__error__context__984382.severity = b;
  }
  var nd = void 0;
  function od(a) {
    a = Error(a);
    md(a, "warning");
    return a;
  }
  function pd(a, b) {
    if (a != null) {
      var c;
      var d = (c = nd) != null ? c : (nd = {});
      c = d[a] || 0;
      c >= b || ((d[a] = c + 1), (a = Error()), md(a, "incident"), Ab(a));
    }
  }
  function qd() {
    return typeof BigInt === "function";
  }
  var rd = typeof Symbol === "function" && typeof Symbol() === "symbol";
  function sd(a, b, c) {
    return typeof Symbol === "function" && typeof Symbol() === "symbol"
      ? (c === void 0 ? 0 : c) && Symbol.for && a
        ? Symbol.for(a)
        : a != null
        ? Symbol(a)
        : Symbol()
      : b;
  }
  var td = sd("jas", void 0, !0),
    ud = sd(void 0, "0di"),
    vd = sd(void 0, "1oa"),
    wd = sd(void 0, Symbol()),
    xd = sd(void 0, "0ubs"),
    yd = sd(void 0, "0ubsb"),
    zd = sd(void 0, "0actk"),
    Ad = sd("m_m", "Vm", !0),
    Bd = sd(void 0, "vps");
  var Cd = { hj: { value: 0, configurable: !0, writable: !0, enumerable: !1 } },
    Dd = Object.defineProperties,
    H = rd ? td : "hj",
    Ed,
    Fd = [];
  Gd(Fd, 7);
  Ed = Object.freeze(Fd);
  function Hd(a, b) {
    rd || H in a || Dd(a, Cd);
    a[H] |= b;
  }
  function Gd(a, b) {
    rd || H in a || Dd(a, Cd);
    a[H] = b;
  }
  function Id(a) {
    if (4 & a) return 512 & a ? 512 : 1024 & a ? 1024 : 0;
  }
  function Jd(a) {
    Hd(a, 34);
    return a;
  }
  function Kd(a) {
    Hd(a, 8192);
    return a;
  }
  function Ld(a) {
    Hd(a, 32);
    return a;
  }
  function Md(a, b) {
    2 & b && (a |= 2);
    return a | 1;
  }
  var Nd = {};
  function Od(a) {
    return a != null && a[Ad] === Nd;
  }
  function Pd(a, b) {
    return b === void 0
      ? a.h !== Qd && !!(2 & (a.G[H] | 0))
      : !!(2 & b) && a.h !== Qd;
  }
  var Qd = {},
    Rd = function (a, b, c) {
      this.h = a;
      this.j = b;
      this.l = c;
    };
  Rd.prototype.next = function () {
    var a = this.h.next();
    a.done || (a.value = this.j.call(this.l, a.value));
    return a;
  };
  Rd.prototype[Symbol.iterator] = function () {
    return this;
  };
  var Sd = Object.freeze({});
  Object.freeze({});
  function Td(a, b, c) {
    var d = b & 128 ? 0 : -1,
      e = a.length,
      f;
    if ((f = !!e))
      (f = a[e - 1]),
        (f = f != null && typeof f === "object" && f.constructor === Object);
    var g = e + (f ? -1 : 0);
    for (b = b & 128 ? 1 : 0; b < g; b++) c(b - d, a[b]);
    if (f) {
      a = a[e - 1];
      for (var h in a) !isNaN(h) && c(+h, a[h]);
    }
  }
  var Vd = {};
  function Wd(a, b) {
    var c = Xd;
    if (!b(a)) {
      var d, e;
      b =
        (e =
          (d = typeof c === "function" ? c() : c) == null
            ? void 0
            : d.concat("\n")) != null
          ? e
          : "";
      throw Error(b + String(a));
    }
  }
  function Yd(a) {
    a.Qm = !0;
    return a;
  }
  var Xd = void 0,
    Zd = Yd(function (a) {
      return a !== null && a !== void 0;
    });
  var $d = Yd(function (a) {
      return typeof a === "number";
    }),
    ae = Yd(function (a) {
      return typeof a === "string";
    }),
    be = Yd(function (a) {
      return typeof a === "boolean";
    }),
    ce = Yd(function (a) {
      return typeof a === "bigint";
    }),
    de = Yd(function (a) {
      return a === void 0;
    }),
    ee = Yd(function (a) {
      return typeof a === "function";
    }),
    fe = Yd(function (a) {
      return !!a && (typeof a === "object" || typeof a === "function");
    });
  function ge(a) {
    return Yd(function (b) {
      if (!fe(b)) return !1;
      var c = y(Object.entries(a)),
        d = c.next();
      try {
        for (; !d.done; d = c.next()) {
          var e = y(d.value),
            f = e.next().value,
            g = e.next().value,
            h = f,
            k = g;
          if (!(h in b)) {
            if (k.mj === !0) continue;
            return !1;
          }
          if (!k(b[h])) return !1;
        }
      } finally {
        z(c, d);
      }
      return !0;
    });
  }
  function he(a) {
    a.mj = !0;
    return a;
  }
  function ie() {
    var a = La.apply(0, arguments);
    return Yd(function (b) {
      return a.some(function (c) {
        return c(b);
      });
    });
  }
  var je = typeof C.BigInt === "function" && typeof C.BigInt(0) === "bigint";
  function ke(a) {
    var b = a;
    if (ae(b)) {
      if (!/^\s*(?:-?[1-9]\d*|0)?\s*$/.test(b)) throw Error(String(b));
    } else if ($d(b) && !Number.isSafeInteger(b)) throw Error(String(b));
    return je
      ? BigInt(a)
      : (a = be(a) ? (a ? "1" : "0") : ae(a) ? a.trim() || "0" : String(a));
  }
  var le = Yd(function (a) {
      return je ? ce(a) : ae(a) && /^(?:-?[1-9]\d*|0)$/.test(a);
    }),
    re = Yd(function (a) {
      return je ? a >= me && a <= ne : a[0] === "-" ? oe(a, pe) : oe(a, qe);
    }),
    pe = Number.MIN_SAFE_INTEGER.toString(),
    me = je ? BigInt(Number.MIN_SAFE_INTEGER) : void 0,
    qe = Number.MAX_SAFE_INTEGER.toString(),
    ne = je ? BigInt(Number.MAX_SAFE_INTEGER) : void 0;
  function oe(a, b) {
    if (a.length > b.length) return !1;
    if (a.length < b.length || a === b) return !0;
    for (var c = 0; c < a.length; c++) {
      var d = a[c],
        e = b[c];
      if (d > e) return !1;
      if (d < e) return !0;
    }
  }
  var se = typeof Uint8Array.prototype.slice === "function",
    te = 0,
    ue = 0,
    ve;
  function we(a) {
    var b = a >>> 0;
    te = b;
    ue = ((a - b) / 4294967296) >>> 0;
  }
  function xe(a) {
    if (a < 0) {
      we(0 - a);
      var b = y(ye(te, ue));
      a = b.next().value;
      b = b.next().value;
      te = a >>> 0;
      ue = b >>> 0;
    } else we(a);
  }
  function ze(a, b) {
    var c = b * 4294967296 + (a >>> 0);
    return Number.isSafeInteger(c) ? c : Ae(a, b);
  }
  function Be(a, b) {
    return ke(
      qd()
        ? BigInt.asUintN(64, (BigInt(b >>> 0) << BigInt(32)) + BigInt(a >>> 0))
        : Ae(a, b)
    );
  }
  function Ce(a, b) {
    return qd()
      ? ke(
          BigInt.asIntN(
            64,
            (BigInt.asUintN(32, BigInt(b)) << BigInt(32)) +
              BigInt.asUintN(32, BigInt(a))
          )
        )
      : ke(De(a, b));
  }
  function Ae(a, b) {
    b >>>= 0;
    a >>>= 0;
    if (b <= 2097151) var c = "" + (4294967296 * b + a);
    else
      qd()
        ? (c = "" + ((BigInt(b) << BigInt(32)) | BigInt(a)))
        : ((c = ((a >>> 24) | (b << 8)) & 16777215),
          (b = (b >> 16) & 65535),
          (a = (a & 16777215) + c * 6777216 + b * 6710656),
          (c += b * 8147497),
          (b *= 2),
          a >= 1e7 && ((c += (a / 1e7) >>> 0), (a %= 1e7)),
          c >= 1e7 && ((b += (c / 1e7) >>> 0), (c %= 1e7)),
          (c = b + Ee(c) + Ee(a)));
    return c;
  }
  function Ee(a) {
    a = String(a);
    return "0000000".slice(a.length) + a;
  }
  function De(a, b) {
    b & 2147483648
      ? qd()
        ? (a = "" + ((BigInt(b | 0) << BigInt(32)) | BigInt(a >>> 0)))
        : ((b = y(ye(a, b))),
          (a = b.next().value),
          (b = b.next().value),
          (a = "-" + Ae(a, b)))
      : (a = Ae(a, b));
    return a;
  }
  function Fe(a) {
    if (a.length < 16) xe(Number(a));
    else if (qd())
      (a = BigInt(a)),
        (te = Number(a & BigInt(4294967295)) >>> 0),
        (ue = Number((a >> BigInt(32)) & BigInt(4294967295)));
    else {
      var b = +(a[0] === "-");
      ue = te = 0;
      for (
        var c = a.length, d = 0 + b, e = ((c - b) % 6) + b;
        e <= c;
        d = e, e += 6
      )
        (d = Number(a.slice(d, e))),
          (ue *= 1e6),
          (te = te * 1e6 + d),
          te >= 4294967296 &&
            ((ue += Math.trunc(te / 4294967296)), (ue >>>= 0), (te >>>= 0));
      b &&
        ((b = y(ye(te, ue))),
        (a = b.next().value),
        (b = b.next().value),
        (te = a),
        (ue = b));
    }
  }
  function ye(a, b) {
    b = ~b;
    a ? (a = ~a + 1) : (b += 1);
    return [a, b];
  }
  function Ge(a) {
    return Array.prototype.slice.call(a);
  }
  function He(a, b) {
    throw Error(b === void 0 ? "unexpected value " + a + "!" : b);
  }
  var Ie = typeof BigInt === "function" ? BigInt.asIntN : void 0,
    Je = typeof BigInt === "function" ? BigInt.asUintN : void 0,
    Ke = Number.isSafeInteger,
    Le = Number.isFinite,
    Me = Math.trunc;
  function Ne(a) {
    if (a == null || typeof a === "number") return a;
    if (a === "NaN" || a === "Infinity" || a === "-Infinity") return Number(a);
  }
  function Oe(a) {
    if (typeof a !== "boolean")
      throw Error("Expected boolean but got " + ab(a) + ": " + a);
    return a;
  }
  function Pe(a) {
    if (a == null || typeof a === "boolean") return a;
    if (typeof a === "number") return !!a;
  }
  var Qe = /^-?([1-9][0-9]*|0)(\.[0-9]+)?$/;
  function Re(a) {
    switch (typeof a) {
      case "bigint":
        return !0;
      case "number":
        return Le(a);
      case "string":
        return Qe.test(a);
      default:
        return !1;
    }
  }
  function Se(a) {
    if (!Le(a)) throw od("enum");
    return a | 0;
  }
  function Te(a) {
    return a == null ? a : Le(a) ? a | 0 : void 0;
  }
  function Ue(a) {
    if (typeof a !== "number") throw od("int32");
    if (!Le(a)) throw od("int32");
    return a | 0;
  }
  function Ve(a) {
    if (a == null) return a;
    if (typeof a === "string" && a) a = +a;
    else if (typeof a !== "number") return;
    return Le(a) ? a | 0 : void 0;
  }
  function We(a) {
    if (a == null) return a;
    if (typeof a === "string" && a) a = +a;
    else if (typeof a !== "number") return;
    return Le(a) ? a >>> 0 : void 0;
  }
  function Xe(a) {
    var b = void 0;
    b != null || (b = 1024);
    if (!Re(a)) throw od("int64");
    var c = typeof a;
    switch (b) {
      case 512:
        switch (c) {
          case "string":
            return Ye(a);
          case "bigint":
            return String(Ie(64, a));
          default:
            return Ze(a);
        }
      case 1024:
        switch (c) {
          case "string":
            return $e(a);
          case "bigint":
            return ke(Ie(64, a));
          default:
            return ke(Ke(a) ? a : Ze(a));
        }
      case 0:
        switch (c) {
          case "string":
            return Ye(a);
          case "bigint":
            return ke(Ie(64, a));
          default:
            return af(a);
        }
      default:
        return He(b, "Unknown format requested type for int64");
    }
  }
  function bf(a) {
    return a == null ? a : Xe(a);
  }
  function cf(a) {
    var b = a.length;
    if (
      a[0] === "-"
        ? b < 20 || (b === 20 && a <= "-9223372036854775808")
        : b < 19 || (b === 19 && a <= "9223372036854775807")
    )
      return a;
    Fe(a);
    return De(te, ue);
  }
  function af(a) {
    a = Me(a);
    if (!Ke(a)) {
      xe(a);
      var b = te,
        c = ue;
      if ((a = c & 2147483648))
        (b = (~b + 1) >>> 0), (c = ~c >>> 0), b == 0 && (c = (c + 1) >>> 0);
      b = ze(b, c);
      a = typeof b === "number" ? (a ? -b : b) : a ? "-" + b : b;
    }
    return a;
  }
  function Ze(a) {
    a = Me(a);
    Ke(a) ? (a = String(a)) : (xe(a), (a = De(te, ue)));
    return a;
  }
  function Ye(a) {
    var b = Me(Number(a));
    if (Ke(b)) return String(b);
    b = a.indexOf(".");
    b !== -1 && (a = a.substring(0, b));
    return cf(a);
  }
  function $e(a) {
    var b = Me(Number(a));
    if (Ke(b)) return ke(b);
    b = a.indexOf(".");
    b !== -1 && (a = a.substring(0, b));
    return qd() ? ke(Ie(64, BigInt(a))) : ke(cf(a));
  }
  function df(a) {
    var b = typeof a;
    if (a == null) return a;
    if (b === "bigint") return ke(Ie(64, a));
    if (Re(a)) return b === "string" ? $e(a) : ke(Ke(a) ? a : Ze(a));
  }
  function ef(a) {
    if (a == null) return a;
    var b = typeof a;
    if (b === "bigint") return String(Ie(64, a));
    if (Re(a)) {
      if (b === "string") return Ye(a);
      if (b === "number") return af(a);
    }
  }
  function ff(a) {
    if (a == null) return a;
    var b = typeof a;
    if (b === "bigint") return String(Je(64, a));
    if (Re(a)) {
      if (b === "string")
        return (
          (b = Me(Number(a))),
          Ke(b) && b >= 0
            ? (a = String(b))
            : ((b = a.indexOf(".")),
              b !== -1 && (a = a.substring(0, b)),
              a[0] === "-"
                ? (b = !1)
                : ((b = a.length),
                  (b = b < 20 ? !0 : b === 20 && a <= "18446744073709551615")),
              b || (Fe(a), (a = Ae(te, ue)))),
          a
        );
      if (b === "number")
        return (a = Me(a)), (a >= 0 && Ke(a)) || (xe(a), (a = ze(te, ue))), a;
    }
  }
  function gf(a) {
    if (typeof a !== "string") throw Error();
    return a;
  }
  function hf(a) {
    if (a != null && typeof a !== "string") throw Error();
    return a;
  }
  function jf(a) {
    return a == null || typeof a === "string" ? a : void 0;
  }
  function kf(a, b, c, d) {
    if (Od(a)) return a;
    if (!Array.isArray(a))
      return c ? (d & 2 ? b[ud] || (b[ud] = lf(b)) : new b()) : void 0;
    c = a[H] | 0;
    d = c | (d & 32) | (d & 2);
    d !== c && Gd(a, d);
    return new b(a);
  }
  function lf(a) {
    a = new a();
    Jd(a.G);
    return a;
  }
  function mf(a, b, c) {
    if (b) return Oe(a);
    var d;
    return (d = Pe(a)) != null ? d : c ? !1 : void 0;
  }
  function nf(a, b, c) {
    if (b) return gf(a);
    var d;
    return (d = jf(a)) != null ? d : c ? "" : void 0;
  }
  var of = {};
  function qf(a) {
    return a;
  }
  var rf = {},
    sf = (function () {
      try {
        var a = function () {
          return ha(Map, [], this.constructor);
        };
        w(a, Map);
        wc(new a());
        return !1;
      } catch (b) {
        return !0;
      }
    })(),
    tf = function () {
      this.h = new Map();
    };
  n = tf.prototype;
  n.get = function (a) {
    return this.h.get(a);
  };
  n.set = function (a, b) {
    this.h.set(a, b);
    this.size = this.h.size;
    return this;
  };
  n.delete = function (a) {
    a = this.h.delete(a);
    this.size = this.h.size;
    return a;
  };
  n.clear = function () {
    this.h.clear();
    this.size = this.h.size;
  };
  n.has = function (a) {
    return this.h.has(a);
  };
  n.entries = function () {
    return this.h.entries();
  };
  n.keys = function () {
    return this.h.keys();
  };
  n.values = function () {
    return this.h.values();
  };
  n.forEach = function (a, b) {
    return this.h.forEach(a, b);
  };
  tf.prototype[Symbol.iterator] = function () {
    return this.entries();
  };
  var uf = (function () {
    if (sf)
      return (
        Object.setPrototypeOf(tf.prototype, Map.prototype),
        Object.defineProperties(tf.prototype, {
          size: { value: 0, configurable: !0, enumerable: !0, writable: !0 },
        }),
        tf
      );
    var a = function () {
      return ha(Map, [], this.constructor);
    };
    w(a, Map);
    return a;
  })();
  function vf(a) {
    return a;
  }
  var xf = function (a, b, c, d) {
    c = c === void 0 ? vf : c;
    d = d === void 0 ? vf : d;
    var e = uf.call(this) || this;
    e.sc = a[H] | 0;
    e.kc = b;
    e.Id = c;
    e.uh = e.kc ? wf : d;
    for (var f = 0; f < a.length; f++) {
      var g = a[f],
        h = c(g[0], !1, !0),
        k = g[1];
      b
        ? k === void 0 && (k = null)
        : (k = d(g[1], !1, !0, void 0, void 0, e.sc));
      uf.prototype.set.call(e, h, k);
    }
    return e;
  };
  w(xf, uf);
  var yf = function (a) {
      if (a.sc & 2) throw Error("Cannot mutate an immutable Map");
    },
    zf = function (a, b) {
      return Kd(Array.from(uf.prototype.entries.call(a), b));
    };
  n = xf.prototype;
  n.clear = function () {
    yf(this);
    uf.prototype.clear.call(this);
  };
  n.delete = function (a) {
    yf(this);
    return uf.prototype.delete.call(this, this.Id(a, !0, !1));
  };
  n.entries = function () {
    if (this.kc) {
      var a = uf.prototype.keys.call(this);
      a = new Rd(a, Af, this);
    } else a = uf.prototype.entries.call(this);
    return a;
  };
  n.values = function () {
    if (this.kc) {
      var a = uf.prototype.keys.call(this);
      a = new Rd(a, xf.prototype.get, this);
    } else a = uf.prototype.values.call(this);
    return a;
  };
  n.forEach = function (a, b) {
    this.kc
      ? uf.prototype.forEach.call(this, function (c, d, e) {
          a.call(b, e.get(d), d, e);
        })
      : uf.prototype.forEach.call(this, a, b);
  };
  n.set = function (a, b) {
    yf(this);
    a = this.Id(a, !0, !1);
    return a == null
      ? this
      : b == null
      ? (uf.prototype.delete.call(this, a), this)
      : uf.prototype.set.call(
          this,
          a,
          this.uh(b, !0, !0, this.kc, !1, this.sc)
        );
  };
  n.has = function (a) {
    return uf.prototype.has.call(this, this.Id(a, !1, !1));
  };
  n.get = function (a) {
    a = this.Id(a, !1, !1);
    var b = uf.prototype.get.call(this, a);
    if (b !== void 0) {
      var c = this.kc;
      return c
        ? ((c = this.uh(b, !1, !0, c, this.zm, this.sc)),
          c !== b && uf.prototype.set.call(this, a, c),
          c)
        : b;
    }
  };
  xf.prototype[Symbol.iterator] = function () {
    return this.entries();
  };
  xf.prototype.toJSON = void 0;
  function wf(a, b, c, d, e, f) {
    a = kf(a, d, c, f);
    e && (a = Bf(a));
    return a;
  }
  function Af(a) {
    return [a, this.get(a)];
  }
  var Cf;
  function Df() {
    return Cf || (Cf = new xf(Jd([]), void 0, void 0, void 0, rf));
  }
  function Ef(a) {
    var b = nb(wd);
    return b ? a[b] : void 0;
  }
  var Ff = function () {},
    Gf = function (a, b) {
      for (var c in a) !isNaN(c) && b(a, +c, a[c]);
    },
    Hf = function (a) {
      var b = new Ff();
      Gf(a, function (c, d, e) {
        b[d] = Ge(e);
      });
      b.h = a.h;
      return b;
    };
  function If(a, b) {
    b < 100 || pd(xd, 1);
  }
  function Jf(a, b, c, d) {
    var e = d !== void 0;
    d = !!d;
    var f = nb(wd),
      g;
    !e && rd && f && (g = a[f]) && Gf(g, If);
    f = [];
    var h = a.length;
    g = 4294967295;
    var k = !1,
      l = !!(b & 64),
      m = l ? (b & 128 ? 0 : -1) : void 0;
    if (!(b & 1)) {
      var p = h && a[h - 1];
      p != null && typeof p === "object" && p.constructor === Object
        ? (h--, (g = h))
        : (p = void 0);
      if (l && !(b & 128) && !e) {
        k = !0;
        var q;
        g = ((q = Kf) != null ? q : qf)(g - m, m, a, p, void 0) + m;
      }
    }
    b = void 0;
    for (q = 0; q < h; q++) {
      var r = a[q];
      if (r != null && (r = c(r, d)) != null)
        if (l && q >= g) {
          var t = q - m,
            v = void 0;
          ((v = b) != null ? v : (b = {}))[t] = r;
        } else f[q] = r;
    }
    if (p)
      for (var x in p)
        (h = p[x]),
          h != null &&
            (h = c(h, d)) != null &&
            ((q = +x),
            (r = void 0),
            l && !Number.isNaN(q) && (r = q + m) < g
              ? (f[r] = h)
              : ((q = void 0), (((q = b) != null ? q : (b = {}))[x] = h)));
    b && (k ? f.push(b) : (f[g] = b));
    e && (c = nb(wd)) && (a = Ef(a)) && a instanceof Ff && (f[c] = Hf(a));
    return f;
  }
  function Lf(a) {
    a[0] = Mf(a[0]);
    a[1] = Mf(a[1]);
    return a;
  }
  function Mf(a) {
    switch (typeof a) {
      case "number":
        return Number.isFinite(a) ? a : "" + a;
      case "bigint":
        return re(a) ? Number(a) : "" + a;
      case "boolean":
        return a ? 1 : 0;
      case "object":
        if (Array.isArray(a)) {
          var b = a[H] | 0;
          return a.length === 0 && b & 1 ? void 0 : Jf(a, b, Mf);
        }
        if (Od(a)) return Nf(a);
        if (a instanceof jd) {
          b = a.h;
          if (b == null) a = "";
          else if (typeof b === "string") a = b;
          else {
            if (cd) {
              for (var c = "", d = 0, e = b.length - 10240; d < e; )
                c += String.fromCharCode.apply(
                  null,
                  b.subarray(d, (d += 10240))
                );
              c += String.fromCharCode.apply(null, d ? b.subarray(d) : b);
              b = btoa(c);
            } else b = Xc(b);
            a = a.h = b;
          }
          return a;
        }
        if (a instanceof xf) return (a = a.size !== 0 ? zf(a, Lf) : void 0), a;
        return;
    }
    return a;
  }
  var Kf;
  function Of(a, b) {
    if (b) {
      Kf = b == null || b === qf || b[Bd] !== of ? qf : b;
      try {
        return Nf(a);
      } finally {
        Kf = void 0;
      }
    }
    return Nf(a);
  }
  function Nf(a) {
    a = a.G;
    return Jf(a, a[H] | 0, Mf);
  }
  var Pf, Qf;
  function Rf(a) {
    switch (typeof a) {
      case "boolean":
        return Pf || (Pf = [0, void 0, !0]);
      case "number":
        return a > 0
          ? void 0
          : a === 0
          ? Qf || (Qf = [0, void 0])
          : [-a, void 0];
      case "string":
        return [0, a];
      case "object":
        return a;
    }
  }
  function Sf(a, b) {
    return Tf(a, b[0], b[1]);
  }
  function I(a, b, c) {
    return Tf(a, b, c, 2048);
  }
  function Tf(a, b, c, d) {
    d = d === void 0 ? 0 : d;
    if (a == null) {
      var e = 32;
      c ? ((a = [c]), (e |= 128)) : (a = []);
      b && (e = (e & -16760833) | ((b & 1023) << 14));
    } else {
      if (!Array.isArray(a)) throw Error("narr");
      e = a[H] | 0;
      if (Bb && 1 & e) throw Error("rfarr");
      2048 & e && !(2 & e) && Uf();
      if (e & 256) throw Error("farr");
      if (e & 64) return (e | d) !== e && Gd(a, e | d), a;
      if (c && ((e |= 128), c !== a[0])) throw Error("mid");
      a: {
        c = a;
        e |= 64;
        var f = c.length;
        if (f) {
          var g = f - 1,
            h = c[g];
          if (h != null && typeof h === "object" && h.constructor === Object) {
            b = e & 128 ? 0 : -1;
            g -= b;
            if (g >= 1024) throw Error("pvtlmt");
            for (var k in h)
              (f = +k), f < g && ((c[f + b] = h[k]), delete h[k]);
            e = (e & -16760833) | ((g & 1023) << 14);
            break a;
          }
        }
        if (b) {
          k = Math.max(b, f - (e & 128 ? 0 : -1));
          if (k > 1024) throw Error("spvt");
          e = (e & -16760833) | ((k & 1023) << 14);
        }
      }
    }
    Gd(a, e | 64 | d);
    return a;
  }
  function Uf() {
    if (Bb) throw Error("carr");
    pd(zd, 5);
  }
  function Vf(a, b) {
    if (typeof a !== "object") return a;
    if (Array.isArray(a)) {
      var c = a[H] | 0;
      return a.length === 0 && c & 1 ? void 0 : Wf(a, c, b);
    }
    if (Od(a)) return Xf(a);
    if (a instanceof xf) {
      b = a.sc;
      if (b & 2) return a;
      if (!a.size) return;
      c = Jd(zf(a));
      if (a.kc)
        for (a = 0; a < c.length; a++) {
          var d = c[a],
            e = d[1];
          e == null || typeof e !== "object"
            ? (e = void 0)
            : Od(e)
            ? (e = Xf(e))
            : Array.isArray(e)
            ? (e = Wf(e, e[H] | 0, !!(b & 32)))
            : (e = void 0);
          d[1] = e;
        }
      return c;
    }
    if (a instanceof jd) return a;
  }
  function Wf(a, b, c) {
    if (b & 2) return a;
    !c || 4096 & b || 16 & b
      ? (a = Yf(a, b, !1, c && !(b & 16)))
      : (Hd(a, 34), b & 4 && Object.freeze(a));
    return a;
  }
  function Zf(a, b, c) {
    a = new a.constructor(b);
    c && (a.h = Qd);
    a.o = Qd;
    return a;
  }
  function Xf(a) {
    var b = a.G,
      c = b[H] | 0;
    return Pd(a, c) ? a : $f(a, b, c) ? Zf(a, b) : Yf(b, c);
  }
  function Yf(a, b, c, d) {
    d != null || (d = !!(34 & b));
    a = Jf(a, b, Vf, d);
    d = 32;
    c && (d |= 2);
    b = (b & 16769217) | d;
    Gd(a, b);
    return a;
  }
  function Bf(a) {
    var b = a.G,
      c = b[H] | 0;
    return Pd(a, c)
      ? $f(a, b, c)
        ? Zf(a, b, !0)
        : new a.constructor(Yf(b, c, !1))
      : a;
  }
  function ag(a) {
    if (a.h !== Qd) return !1;
    var b = a.G;
    b = Yf(b, b[H] | 0);
    Hd(b, 2048);
    a.G = b;
    a.h = void 0;
    a.o = void 0;
    return !0;
  }
  function bg(a) {
    if (!ag(a) && Pd(a, a.G[H] | 0)) throw Error();
  }
  function cg(a, b) {
    b === void 0 && (b = a[H] | 0);
    b & 32 && !(b & 4096) && Gd(a, b | 4096);
  }
  function $f(a, b, c) {
    return c & 2
      ? !0
      : c & 32 && !(c & 4096)
      ? (Gd(b, c | 2), (a.h = Qd), !0)
      : !1;
  }
  var dg = ke(0),
    eg = {},
    gg = function (a, b, c, d, e) {
      b = fg(a.G, b, c, e);
      if (b !== null || (d && a.o !== Qd)) return b;
    },
    hg = function (a, b, c) {
      return fg(a, b, void 0, c);
    };
  function fg(a, b, c, d) {
    if (b === -1) return null;
    var e = b + (c ? 0 : -1),
      f = a.length - 1;
    if (!(f < 1 + (c ? 0 : -1))) {
      if (e >= f) {
        var g = a[f];
        if (g != null && typeof g === "object" && g.constructor === Object) {
          c = g[b];
          var h = !0;
        } else if (e === f) c = g;
        else return;
      } else c = a[e];
      if (d && c != null) {
        d = d(c);
        if (d == null) return d;
        if (!Object.is(d, c)) return h ? (g[b] = d) : (a[e] = d), d;
      }
      return c;
    }
  }
  var jg = function (a, b, c) {
    bg(a);
    var d = a.G;
    ig(d, d[H] | 0, b, c);
    return a;
  };
  function ig(a, b, c, d, e) {
    var f = c + (e ? 0 : -1),
      g = a.length - 1;
    if (g >= 1 + (e ? 0 : -1) && f >= g) {
      var h = a[g];
      if (h != null && typeof h === "object" && h.constructor === Object)
        return (h[c] = d), b;
    }
    if (f <= g) return (a[f] = d), b;
    if (d !== void 0) {
      var k;
      g = (((k = b) != null ? k : (b = a[H] | 0)) >> 14) & 1023 || 536870912;
      c >= g
        ? d != null && ((f = {}), (a[g + (e ? 0 : -1)] = ((f[c] = d), f)))
        : (a[f] = d);
    }
    return b;
  }
  var kg = function (a, b) {
      a = fg(a.G, b);
      return Od(a) || Array.isArray(a);
    },
    mg = function () {
      var a = lg;
      return a && a === Sd ? 2 : 4;
    };
  function pg(a, b, c, d, e, f) {
    var g = a.G,
      h = g[H] | 0;
    d = d && d !== 4 ? (d !== 1 && (a ? Pd(a, h) : 2 & h) ? 1 : d) : 4;
    e = !!e || d === 3;
    d === 2 && ag(a) && ((g = a.G), (h = g[H] | 0));
    a = qg(g, b, f);
    var k = a === Ed ? 7 : a[H] | 0,
      l = Md(k, h);
    var m = !(4 & l);
    if (m) {
      for (var p = 0, q = 0; p < a.length; p++) {
        var r = c(a[p]);
        r != null && (a[q++] = r);
      }
      q < p && (a.length = q);
      c = (l | 4) & -513;
      l = c &= -1025;
      l &= -4097;
    }
    l !== k && (Gd(a, l), 2 & l && Object.freeze(a));
    return (a = rg(a, l, g, h, b, f, d, m, e));
  }
  function rg(a, b, c, d, e, f, g, h, k) {
    var l = b,
      m = sg(b);
    m &&
      g === 2 &&
      ((a = Ge(a)), (l = 0), (b = tg(b, d)), (d = ig(c, d, e, a, f)), (m = !1));
    m ||
      (g === 1 || (g !== 4 ? 0 : 2 & b || (!(16 & b) && 32 & d))
        ? ((b |=
            !a.length || (h && !(4096 & b)) || (32 & d && !(4096 & b || 16 & b))
              ? 2
              : 256),
          b !== l && Gd(a, b),
          Object.freeze(a))
        : (k || (b |= 16), b !== l && Gd(a, b)));
    2 & b || !(4096 & b || 16 & b) || cg(c, d);
    return a;
  }
  function qg(a, b, c) {
    a = fg(a, b, c);
    return Array.isArray(a) ? a : Ed;
  }
  function sg(a) {
    return (!!(2 & a) && !!(4 & a)) || !!(256 & a);
  }
  function ug(a, b, c, d) {
    !d && ag(a) && ((b = a.G), (c = b[H] | 0));
    var e = fg(b, 1);
    a = !1;
    if (e == null) {
      if (d) return Df();
      e = [];
    } else if (e.constructor === xf)
      if (e.sc & 2 && !d) e = zf(e);
      else return e;
    else Array.isArray(e) ? (a = !!((e[H] | 0) & 2)) : (e = []);
    if (d) {
      if (!e.length) return Df();
      a || ((a = !0), Jd(e));
    } else if (a) {
      a = !1;
      Kd(e);
      d = Ge(e);
      for (e = 0; e < d.length; e++) {
        var f = (d[e] = Ge(d[e]));
        Array.isArray(f[1]) && (f[1] = Jd(f[1]));
      }
      e = Kd(d);
    }
    !a && c & 32 && Ld(e);
    d = new xf(e, void 0, nf, mf);
    c = ig(b, c, 1, d);
    a || cg(b, c);
    return d;
  }
  function vg(a, b, c, d) {
    bg(a);
    var e = a.G,
      f = e[H] | 0;
    if (c == null) return ig(e, f, b), a;
    var g = c === Ed ? 7 : c[H] | 0,
      h = g,
      k = sg(g),
      l = k || Object.isFrozen(c);
    k || (g = 0);
    l || ((c = Ge(c)), (h = 0), (g = tg(g, f)), (l = !1));
    g |= 5;
    var m;
    k = (m = Id(g)) != null ? m : 1024;
    g |= k;
    for (m = 0; m < c.length; m++) {
      var p = c[m],
        q = d(p, k);
      Object.is(p, q) ||
        (l && ((c = Ge(c)), (h = 0), (g = tg(g, f)), (l = !1)), (c[m] = q));
    }
    g !== h && (l && ((c = Ge(c)), (g = tg(g, f))), Gd(c, g));
    ig(e, f, b, c);
    return a;
  }
  function wg(a, b, c, d) {
    bg(a);
    var e = a.G;
    ig(e, e[H] | 0, b, (d === "0" ? Number(c) === 0 : c === d) ? void 0 : c);
    return a;
  }
  function xg(a, b, c) {
    if (b & 2) throw Error();
    var d = b & 128 ? Vd : void 0,
      e = qg(a, c, d),
      f = e === Ed ? 7 : e[H] | 0,
      g = Md(f, b);
    if (2 & g || sg(g) || 16 & g)
      g === f || sg(g) || Gd(e, g),
        (e = Ge(e)),
        (f = 0),
        (g = tg(g, b)),
        ig(a, b, c, e, d);
    g &= -13;
    g !== f && Gd(e, g);
    return e;
  }
  var Ag = function (a, b, c, d) {
      bg(a);
      var e = a.G,
        f = e[H] | 0;
      if (d == null) {
        var g = yg(e);
        if (zg(g, e, f, c) === b) g.set(c, 0);
        else return a;
      } else {
        g = yg(e);
        var h = zg(g, e, f, c);
        h !== b && (h && (f = ig(e, f, h)), g.set(c, b));
      }
      ig(e, f, b, d);
      return a;
    },
    Cg = function (a, b, c) {
      return Bg(a.G, b) === c ? c : -1;
    },
    Bg = function (a, b) {
      return zg(yg(a), a, void 0, b);
    };
  function yg(a) {
    if (rd) {
      var b;
      return (b = a[vd]) != null ? b : (a[vd] = new Map());
    }
    if (vd in a) return a[vd];
    b = new Map();
    Object.defineProperty(a, vd, { value: b });
    return b;
  }
  function zg(a, b, c, d) {
    var e = a.get(d);
    if (e != null) return e;
    for (var f = (e = 0); f < d.length; f++) {
      var g = d[f];
      fg(b, g, void 0) != null &&
        (e !== 0 && (c = ig(b, c, e, void 0, void 0)), (e = g));
    }
    a.set(d, e);
    return e;
  }
  var Dg = function (a, b, c) {
    bg(a);
    a = a.G;
    var d = a[H] | 0,
      e = fg(a, c);
    b = kf(e, b, !0, d);
    b = Bf(b);
    e !== b && ((d = ig(a, d, c, b)), cg(a, d));
    return b;
  };
  function Eg(a, b, c) {
    var d = a[H] | 0,
      e = d & 128 ? Vd : void 0,
      f = fg(a, c, e);
    if (Od(f)) {
      if (!Pd(f)) return ag(f), f.G;
      var g = f.G;
    } else Array.isArray(f) && ((g = f), d & 2 && Jd(g));
    if (g) {
      var h = g[H] | 0;
      h & 2 && (g = Yf(g, h));
    }
    g = Sf(g, b);
    g !== f && ig(a, d, c, g, e);
    return g;
  }
  function Fg(a, b, c, d) {
    var e = !1;
    d = hg(a, d, function (f) {
      var g = kf(f, c, !1, b);
      e = g !== f && g != null;
      return g;
    });
    if (d != null) return e && !Pd(d) && cg(a, b), d;
  }
  var Hg = function (a) {
      var b = Gg;
      a = a.G;
      return Fg(a, a[H] | 0, b, 4) || b[ud] || (b[ud] = lf(b));
    },
    Ig = function (a, b, c) {
      var d = a.G,
        e = d[H] | 0;
      b = Fg(d, e, b, c);
      if (b == null) return b;
      e = d[H] | 0;
      if (!Pd(a, e)) {
        var f = Bf(b);
        f !== b &&
          (ag(a) && ((d = a.G), (e = d[H] | 0)),
          (b = f),
          (e = ig(d, e, c, b)),
          cg(d, e));
      }
      return b;
    };
  function Jg(a, b, c, d, e, f, g, h) {
    f = f && f !== 4 ? (f !== 1 && (a ? Pd(a, c) : 2 & c) ? 1 : f) : 4;
    g = !!g || f === 3;
    var k = !!h && !(a ? Pd(a, c) : 2 & c);
    (f === 2 || k) && a && ag(a) && ((b = a.G), (c = b[H] | 0));
    a = qg(b, e);
    var l = a === Ed ? 7 : a[H] | 0,
      m = Md(l, c);
    if ((h = !(4 & m))) {
      var p = a,
        q = c,
        r = !!(2 & m);
      r && (q |= 2);
      for (var t = !r, v = !0, x = 0, E = 0; x < p.length; x++) {
        var F = kf(p[x], d, !1, q);
        if (F instanceof d) {
          if (!r) {
            var B = Pd(F);
            t && (t = !B);
            v && (v = B);
          }
          p[E++] = F;
        }
      }
      E < x && (p.length = E);
      m |= 4;
      m = v ? m & -4097 : m | 4096;
      m = t ? m | 8 : m & -9;
    }
    m !== l && (Gd(a, m), 2 & m && Object.freeze(a));
    if (
      k &&
      !(
        8 & m ||
        (!a.length &&
          (f === 1 || (f !== 4 ? 0 : 2 & m || (!(16 & m) && 32 & c))))
      )
    ) {
      sg(m) && ((a = Ge(a)), (m = tg(m, c)), (c = ig(b, c, e, a)));
      d = a;
      k = m;
      for (l = 0; l < d.length; l++)
        (p = d[l]), (m = Bf(p)), p !== m && (d[l] = m);
      k |= 8;
      m = k = d.length ? k | 4096 : k & -4097;
      Gd(a, m);
    }
    return (a = rg(a, m, b, c, e, void 0, f, h, g));
  }
  var Kg = function (a, b, c, d) {
    var e = a.G;
    return Jg(a, e, e[H] | 0, b, c, d, !1, !0);
  };
  function Lg(a) {
    a == null && (a = void 0);
    return a;
  }
  var Mg = function (a, b, c) {
      c = Lg(c);
      jg(a, b, c);
      c && !Pd(c) && cg(a.G);
      return a;
    },
    Ng = function (a, b, c, d) {
      d = Lg(d);
      Ag(a, b, c, d);
      d && !Pd(d) && cg(a.G);
      return a;
    },
    Og = function (a, b, c) {
      bg(a);
      var d = a.G,
        e = d[H] | 0;
      if (c == null) ig(d, e, b);
      else {
        for (
          var f = c === Ed ? 7 : c[H] | 0,
            g = f,
            h = sg(f),
            k = h || Object.isFrozen(c),
            l = !0,
            m = !0,
            p = 0;
          p < c.length;
          p++
        ) {
          var q = c[p];
          h || ((q = Pd(q)), l && (l = !q), m && (m = q));
        }
        h || ((f = l ? 13 : 5), (f = m ? f & -4097 : f | 4096));
        (k && f === g) || ((c = Ge(c)), (g = 0), (f = tg(f, e)));
        f !== g && Gd(c, f);
        e = ig(d, e, b, c);
        2 & f || !(4096 & f || 16 & f) || cg(d, e);
      }
      return a;
    };
  function tg(a, b) {
    return (a = (2 & b ? a | 2 : a & -3) & -273);
  }
  function Pg(a, b, c, d, e, f, g, h) {
    bg(a);
    a = pg(a, b, e, 2, !0, f);
    var k;
    b = (k = Id(a === Ed ? 7 : a[H] | 0)) != null ? k : 1024;
    if (h)
      if (Array.isArray(d))
        for (g = d.length, h = 0; h < g; h++) a.push(c(d[h], b));
      else {
        d = y(d);
        g = d.next();
        try {
          for (; !g.done; g = d.next()) a.push(c(g.value, b));
        } finally {
          z(d, g);
        }
      }
    else {
      if (g) throw Error();
      a.push(c(d, b));
    }
  }
  var Qg = function (a, b, c, d) {
      bg(a);
      var e = a.G;
      b = Jg(a, e, e[H] | 0, c, b, 2, !0);
      d = d != null ? d : new c();
      b.push(d);
      var f = (c = b === Ed ? 7 : b[H] | 0);
      (d = Pd(d)) ? ((c &= -9), b.length === 1 && (c &= -4097)) : (c |= 4096);
      c !== f && Gd(b, c);
      d || cg(e);
      return a;
    },
    Sg = function (a, b) {
      var c = Rg;
      bg(a);
      var d = a.G;
      c = Jg(a, d, d[H] | 0, c, 2, 2, !0);
      var e = 0,
        f = 0;
      if (Array.isArray(b))
        for (var g = b.length, h = 0; h < g; h++) {
          var k = b[h];
          c.push(k);
          (k = Pd(k)) && !e++ && (c[H] &= -9);
          k || f++ || Hd(c, 4096);
        }
      else {
        b = y(b);
        k = b.next();
        try {
          for (; !k.done; k = b.next())
            (g = k.value),
              c.push(g),
              (h = Pd(g)) && !e++ && (c[H] &= -9),
              h || f++ || Hd(c, 4096);
        } finally {
          z(b, k);
        }
      }
      f && cg(d);
      return a;
    },
    Tg = function (a, b) {
      a = Pe(gg(a, b));
      return a != null ? a : !1;
    },
    Ug = function (a, b) {
      var c = c === void 0 ? 0 : c;
      var d;
      return (d = Ve(gg(a, b))) != null ? d : c;
    },
    Vg = function (a, b) {
      var c = c === void 0 ? 0 : c;
      a = We(gg(a, b));
      return a != null ? a : c;
    },
    Wg = function (a, b) {
      var c = c === void 0 ? dg : c;
      var d;
      return (d = gg(a, b, void 0, void 0, df)) != null ? d : c;
    },
    Xg = function (a, b) {
      a = gg(a, b, void 0, void 0, Ne);
      return a != null ? a : 0;
    },
    Yg = function (a, b) {
      var c;
      return (c = jf(gg(a, b))) != null ? c : "";
    },
    Zg = function (a, b) {
      var c = c === void 0 ? 0 : c;
      var d;
      return (d = Te(gg(a, b))) != null ? d : c;
    },
    $g = function (a, b, c) {
      return Zg(a, Cg(a, c, b));
    },
    ah = function (a, b) {
      return jf(gg(a, b, void 0, eg));
    },
    bh = function (a, b, c) {
      return jg(a, b, c == null ? c : Oe(c));
    },
    ch = function (a, b, c) {
      return wg(a, b, c == null ? c : Oe(c), !1);
    },
    dh = function (a, b, c) {
      return jg(a, b, c == null ? c : Ue(c));
    },
    eh = function (a, b, c) {
      return wg(a, b, c == null ? c : Ue(c), 0);
    },
    fh = function (a, b, c) {
      return jg(a, b, bf(c));
    },
    gh = function (a, b, c) {
      return wg(a, b, bf(c), "0");
    },
    hh = function (a, b, c) {
      return jg(a, b, hf(c));
    },
    ih = function (a, b, c) {
      return jg(a, b, c == null ? c : Se(c));
    },
    jh = function (a, b, c) {
      return wg(a, b, c == null ? c : Se(c), 0);
    },
    kh = function (a, b, c, d) {
      return Ag(a, b, c, d == null ? d : Se(d));
    };
  var lh = function (a, b, c) {
    this.buffer = a;
    if (c && !b) throw Error();
    this.h = b;
  };
  function mh(a, b) {
    if (typeof a === "string") return new lh(gd(a), b);
    if (Array.isArray(a)) return new lh(new Uint8Array(a), b);
    if (a.constructor === Uint8Array) return new lh(a, !1);
    if (a.constructor === ArrayBuffer)
      return (a = new Uint8Array(a)), new lh(a, !1);
    if (a.constructor === jd)
      return (b = kd(a) || new Uint8Array(0)), new lh(b, !0, a);
    if (a instanceof Uint8Array)
      return (
        (a =
          a.constructor === Uint8Array
            ? a
            : new Uint8Array(a.buffer, a.byteOffset, a.byteLength)),
        new lh(a, !1)
      );
    throw Error();
  }
  var nh = function (a, b, c, d) {
    this.j = null;
    this.A = !1;
    this.h = this.l = this.o = 0;
    this.init(a, b, c, d);
  };
  nh.prototype.init = function (a, b, c, d) {
    var e = d === void 0 ? {} : d;
    d = e.oe;
    e = e.Cf;
    e = e === void 0 ? !1 : e;
    this.oe = d === void 0 ? !1 : d;
    this.Cf = e;
    a &&
      ((a = mh(a, this.Cf)),
      (this.j = a.buffer),
      (this.A = a.h),
      (this.o = b || 0),
      (this.l = c !== void 0 ? this.o + c : this.j.length),
      (this.h = this.o));
  };
  nh.prototype.clear = function () {
    this.j = null;
    this.A = !1;
    this.h = this.l = this.o = 0;
    this.oe = !1;
  };
  nh.prototype.reset = function () {
    this.h = this.o;
  };
  var ph = function (a, b) {
      var c = 0,
        d = 0,
        e = 0,
        f = a.j,
        g = a.h;
      do {
        var h = f[g++];
        c |= (h & 127) << e;
        e += 7;
      } while (e < 32 && h & 128);
      if (e > 32)
        for (d |= (h & 127) >> 4, e = 3; e < 32 && h & 128; e += 7)
          (h = f[g++]), (d |= (h & 127) << e);
      oh(a, g);
      if (!(h & 128)) return b(c >>> 0, d >>> 0);
      throw Error();
    },
    oh = function (a, b) {
      a.h = b;
      if (b > a.l) throw Error();
    },
    qh = function (a) {
      var b = a.j,
        c = a.h,
        d = b[c++],
        e = d & 127;
      if (
        d & 128 &&
        ((d = b[c++]),
        (e |= (d & 127) << 7),
        d & 128 &&
          ((d = b[c++]),
          (e |= (d & 127) << 14),
          d & 128 &&
            ((d = b[c++]),
            (e |= (d & 127) << 21),
            d & 128 &&
              ((d = b[c++]),
              (e |= d << 28),
              d & 128 &&
                b[c++] & 128 &&
                b[c++] & 128 &&
                b[c++] & 128 &&
                b[c++] & 128 &&
                b[c++] & 128))))
      )
        throw Error();
      oh(a, c);
      return e;
    },
    rh = function (a) {
      var b = a.j,
        c = a.h,
        d = b[c + 0],
        e = b[c + 1],
        f = b[c + 2];
      b = b[c + 3];
      oh(a, a.h + 4);
      return ((d << 0) | (e << 8) | (f << 16) | (b << 24)) >>> 0;
    },
    sh = function (a) {
      for (var b = 0, c = a.h, d = c + 10, e = a.j; c < d; ) {
        var f = e[c++];
        b |= f;
        if ((f & 128) === 0) return oh(a, c), !!(b & 127);
      }
      throw Error();
    },
    th = function (a, b) {
      if (b < 0) throw Error();
      var c = a.h;
      b = c + b;
      if (b > a.l) throw Error();
      a.h = b;
      return c;
    },
    uh = [];
  var vh = 0,
    xh = function (a, b, c, d) {
      if (uh.length) {
        var e = uh.pop();
        e.init(a, b, c, d);
        a = e;
      } else a = new nh(a, b, c, d);
      this.h = a;
      this.o = this.h.h;
      this.j = this.l = -1;
      wh(this, d);
    },
    wh = function (a, b) {
      b = (b === void 0 ? {} : b).hg;
      a.hg = b === void 0 ? !1 : b;
    },
    zh = function (a, b, c, d) {
      if (yh.length) {
        var e = yh.pop();
        wh(e, d);
        e.h.init(a, b, c, d);
        return e;
      }
      return new xh(a, b, c, d);
    },
    Ah = function (a) {
      a.h.clear();
      a.l = -1;
      a.j = -1;
      yh.length < 100 && yh.push(a);
    };
  xh.prototype.reset = function () {
    this.h.reset();
    this.o = this.h.h;
    this.j = this.l = -1;
  };
  var Bh = function (a) {
      var b = a.h;
      if (b.h == b.l) return !1;
      a.o = a.h.h;
      var c = qh(a.h) >>> 0;
      b = c >>> 3;
      c &= 7;
      if (!(c >= 0 && c <= 5)) throw Error();
      if (b < 1) throw Error();
      a.l = b;
      a.j = c;
      return !0;
    },
    Ch = function () {
      if (vh >= 100) throw new SyntaxError();
      vh++;
    },
    Dh = function (a) {
      try {
        switch (a.j) {
          case 0:
            a.j != 0 ? Dh(a) : sh(a.h);
            break;
          case 1:
            var b = a.h;
            oh(b, b.h + 8);
            break;
          case 2:
            if (a.j != 2) Dh(a);
            else {
              var c = qh(a.h) >>> 0,
                d = a.h;
              oh(d, d.h + c);
            }
            break;
          case 5:
            var e = a.h;
            oh(e, e.h + 4);
            break;
          case 3:
            Ch();
            var f = a.l;
            try {
              do {
                if (!Bh(a)) throw Error();
                if (a.j == 4) {
                  if (a.l != f) throw Error();
                  break;
                }
                Dh(a);
              } while (1);
            } catch (g) {
              if (g instanceof RangeError) throw new SyntaxError();
              throw g;
            } finally {
              vh > 0 && vh--;
            }
            break;
          default:
            throw Error();
        }
      } catch (g) {
        if (g instanceof RangeError) throw new SyntaxError();
        throw g;
      }
    },
    Eh = function (a, b, c) {
      var d = a.h.l,
        e = qh(a.h) >>> 0;
      e = a.h.h + e;
      var f = e - d;
      f <= 0 && ((a.h.l = e), c(b, a, void 0, void 0, void 0), (f = e - a.h.h));
      if (f) throw Error();
      a.h.h = e;
      a.h.l = d;
    },
    Fh = function (a) {
      var b = qh(a.h) >>> 0;
      a = a.h;
      var c = th(a, b);
      a = a.j;
      if (vb) {
        var d = a,
          e;
        (e = ub) || (e = ub = new TextDecoder("utf-8", { fatal: !0 }));
        b = c + b;
        d = c === 0 && b === d.length ? d : d.subarray(c, b);
        try {
          var f = e.decode(d);
        } catch (l) {
          if (tb === void 0) {
            try {
              e.decode(new Uint8Array([128]));
            } catch (m) {}
            try {
              e.decode(new Uint8Array([97])), (tb = !0);
            } catch (m) {
              tb = !1;
            }
          }
          !tb && (ub = void 0);
          throw l;
        }
      } else {
        f = c;
        b = f + b;
        c = [];
        for (var g = null, h, k; f < b; )
          (h = a[f++]),
            h < 128
              ? c.push(h)
              : h < 224
              ? f >= b
                ? rb()
                : ((k = a[f++]),
                  h < 194 || (k & 192) !== 128
                    ? (f--, rb())
                    : c.push(((h & 31) << 6) | (k & 63)))
              : h < 240
              ? f >= b - 1
                ? rb()
                : ((k = a[f++]),
                  (k & 192) !== 128 ||
                  (h === 224 && k < 160) ||
                  (h === 237 && k >= 160) ||
                  ((e = a[f++]) & 192) !== 128
                    ? (f--, rb())
                    : c.push(((h & 15) << 12) | ((k & 63) << 6) | (e & 63)))
              : h <= 244
              ? f >= b - 2
                ? rb()
                : ((k = a[f++]),
                  (k & 192) !== 128 ||
                  ((h << 28) + (k - 144)) >> 30 !== 0 ||
                  ((e = a[f++]) & 192) !== 128 ||
                  ((d = a[f++]) & 192) !== 128
                    ? (f--, rb())
                    : ((h =
                        ((h & 7) << 18) |
                        ((k & 63) << 12) |
                        ((e & 63) << 6) |
                        (d & 63)),
                      (h -= 65536),
                      c.push(((h >> 10) & 1023) + 55296, (h & 1023) + 56320)))
              : rb(),
            c.length >= 8192 && ((g = sb(g, c)), (c.length = 0));
        f = sb(g, c);
      }
      return f;
    },
    yh = [];
  var Gh = function (a, b) {
      this.j = a >>> 0;
      this.h = b >>> 0;
    },
    Hh = function (a) {
      return new Gh(a & 4294967295, Math.floor(a / 4294967296));
    },
    Ih,
    Jh = function (a, b) {
      this.j = a >>> 0;
      this.h = b >>> 0;
    },
    Kh = function (a) {
      return new Jh(a & 4294967295, Math.floor(a / 4294967296));
    },
    Lh,
    Mh,
    Nh,
    Oh,
    Ph,
    Qh,
    Rh,
    Sh;
  function Th(a, b, c) {
    if (typeof BigInt64Array !== "undefined")
      return (
        Rh ||
          ((Rh = new BigInt64Array(1)),
          (Sh = new Uint32Array(Rh.buffer)),
          (Rh[0] = BigInt(1)),
          (Qh = Sh[0] === 1)),
        (Rh[0] = a),
        (a = Qh ? 0 : 1),
        new b(Sh[a], Sh[1 - a])
      );
    Ph ||
      ((Mh = BigInt(Number.MIN_SAFE_INTEGER)),
      (Nh = BigInt(Number.MAX_SAFE_INTEGER)),
      (Oh = BigInt(4294967295)),
      (Ph = BigInt(32)));
    if (a >= Mh && a <= Nh) return c(Number(a));
    a = BigInt.asUintN(64, a);
    return new b(Number(a & Oh), Number(a >> Ph));
  }
  var Uh = function () {
    this.h = [];
  };
  Uh.prototype.length = function () {
    return this.h.length;
  };
  Uh.prototype.end = function () {
    var a = this.h;
    this.h = [];
    return a;
  };
  var Vh = function (a, b, c) {
      for (; c > 0 || b > 127; )
        a.h.push((b & 127) | 128),
          (b = ((b >>> 7) | (c << 25)) >>> 0),
          (c >>>= 7);
      a.h.push(b);
    },
    Wh = function (a, b) {
      for (; b > 127; ) a.h.push((b & 127) | 128), (b >>>= 7);
      a.h.push(b);
    },
    Xh = function (a, b) {
      if (b >= 0) Wh(a, b);
      else {
        for (var c = 0; c < 9; c++) a.h.push((b & 127) | 128), (b >>= 7);
        a.h.push(1);
      }
    },
    Yh = function (a, b) {
      a.h.push((b >>> 0) & 255);
      a.h.push((b >>> 8) & 255);
      a.h.push((b >>> 16) & 255);
      a.h.push((b >>> 24) & 255);
    };
  var Zh = function () {
      this.l = [];
      this.j = 0;
      this.h = new Uh();
    },
    $h = function (a, b) {
      b.length !== 0 && (a.l.push(b), (a.j += b.length));
    },
    bi = function (a, b) {
      ai(a, b, 2);
      b = a.h.end();
      $h(a, b);
      b.push(a.j);
      return b;
    },
    ci = function (a, b) {
      var c = b.pop();
      for (c = a.j + a.h.length() - c; c > 127; )
        b.push((c & 127) | 128), (c >>>= 7), a.j++;
      b.push(c);
      a.j++;
    },
    ai = function (a, b, c) {
      Wh(a.h, b * 8 + c);
    },
    di = function (a, b, c) {
      ai(a, b, 2);
      Wh(a.h, c.length);
      $h(a, a.h.end());
      $h(a, c);
    };
  function ei() {
    var a = function () {
      throw Error();
    };
    Object.setPrototypeOf(a, a.prototype);
    return a;
  }
  var fi = ei(),
    gi = ei(),
    hi = ei(),
    ii = ei(),
    ji = ei(),
    ki = ei(),
    ni = ei(),
    oi = ei(),
    pi = ei(),
    qi = ei();
  var K = function (a, b, c) {
    this.G = I(a, b, c);
  };
  K.prototype.toJSON = function () {
    return Of(this);
  };
  K.prototype.ha = function (a) {
    return JSON.stringify(Of(this, a));
  };
  K.prototype[Ad] = Nd;
  K.prototype.toString = function () {
    return this.G.toString();
  };
  var ri = function (a, b, c) {
    this.h = a;
    this.j = b;
    a = nb(fi);
    this.l = (!!a && c === a) || !1;
  };
  function si(a) {
    var b = ti;
    var c = c === void 0 ? fi : c;
    return new ri(a, b, c);
  }
  function ti(a, b, c, d, e) {
    b = ui(b, d);
    b != null && ((c = bi(a, c)), e(b, a), ci(a, c));
  }
  var vi = si(function (a, b, c, d, e) {
      if (a.j !== 2) return !1;
      Eh(a, Eg(b, d, c), e);
      return !0;
    }),
    wi = si(function (a, b, c, d, e) {
      if (a.j !== 2) return !1;
      Eh(a, Eg(b, d, c), e);
      return !0;
    }),
    xi = Symbol(),
    yi = Symbol(),
    zi = Symbol(),
    Ai = Symbol(),
    Bi = Symbol(),
    Ci,
    Di;
  function Ei(a, b, c, d) {
    var e = d[a];
    if (e) return e;
    e = {};
    e.ri = d;
    e.cd = Rf(d[0]);
    var f = d[1],
      g = 1;
    f &&
      f.constructor === Object &&
      ((e.Fe = f),
      (f = d[++g]),
      typeof f === "function" &&
        f.length > 0 &&
        ((e.Fg = !0),
        Ci != null || (Ci = f),
        Di != null || (Di = d[g + 1]),
        (f = d[(g += 2)])));
    for (
      var h = {};
      f && Array.isArray(f) && f.length && typeof f[0] === "number" && f[0] > 0;

    ) {
      for (var k = 0; k < f.length; k++) h[f[k]] = f;
      f = d[++g];
    }
    for (k = 1; f !== void 0; ) {
      typeof f === "number" && ((k += f), (f = d[++g]));
      var l = void 0;
      if (f instanceof ri) var m = f;
      else (m = vi), g--;
      f = void 0;
      if ((f = m) == null ? 0 : f.l) {
        f = d[++g];
        l = d;
        var p = g;
        typeof f === "function" && ((f = f()), (l[p] = f));
        l = f;
      }
      f = d[++g];
      p = k + 1;
      typeof f === "number" && f < 0 && ((p -= f), (f = d[++g]));
      for (; k < p; k++) {
        var q = h[k];
        l ? c(e, k, m, l, q) : b(e, k, m, q);
      }
    }
    return (d[a] = e);
  }
  function Fi(a) {
    return Array.isArray(a) ? (a[0] instanceof ri ? a : [wi, a]) : [a, void 0];
  }
  function ui(a, b) {
    if (a instanceof K) return a.G;
    if (Array.isArray(a)) return Sf(a, b);
  }
  function Gi(a, b, c, d) {
    var e = c.h;
    a[b] = d
      ? function (f, g, h) {
          return e(f, g, h, d);
        }
      : e;
  }
  function Hi(a, b, c, d, e) {
    var f = c.h,
      g,
      h;
    a[b] = function (k, l, m) {
      return f(k, l, m, h || (h = Ei(yi, Gi, Hi, d).cd), g || (g = Ii(d)), e);
    };
  }
  function Ii(a) {
    var b = a[zi];
    if (b != null) return b;
    var c = Ei(yi, Gi, Hi, a);
    b = c.Fg
      ? function (d, e) {
          return Ci(d, e, c);
        }
      : function (d, e) {
          a: {
            Ch();
            try {
              for (; Bh(e) && e.j != 4; ) {
                var f = e.l,
                  g = c[f];
                if (g == null) {
                  var h = c.Fe;
                  if (h) {
                    var k = h[f];
                    if (k) {
                      var l = Ji(k);
                      l != null && (g = c[f] = l);
                    }
                  }
                }
                if (g == null || !g(e, d, f)) {
                  var m = e,
                    p = m.o;
                  Dh(m);
                  var q = void 0,
                    r = void 0;
                  if (m.hg) var t = void 0;
                  else {
                    var v = m.h.h - p;
                    m.h.h = p;
                    var x = m.h;
                    if (v == 0) r = ld || (ld = new jd(null, hd));
                    else {
                      var E = th(x, v);
                      if (x.oe && x.A) q = x.j.subarray(E, E + v);
                      else {
                        var F = x.j;
                        m = E + v;
                        q =
                          E === m
                            ? new Uint8Array(0)
                            : se
                            ? F.slice(E, m)
                            : new Uint8Array(F.subarray(E, m));
                      }
                      r =
                        q.length == 0
                          ? ld || (ld = new jd(null, hd))
                          : new jd(q, hd);
                    }
                    t = r;
                  }
                  m = q = r = void 0;
                  var B = d,
                    J = f,
                    Q = t;
                  Q &&
                    ((r = (q = (m = B[wd]) != null ? m : (B[wd] = new Ff()))[
                      J
                    ]) != null
                      ? r
                      : (q[J] = [])
                    ).push(Q);
                }
              }
              var oa = Ef(d);
              oa && (oa.h = c.ri[Bi]);
              var ta = !0;
              break a;
            } catch (Da) {
              if (Da instanceof RangeError) throw new SyntaxError();
              throw Da;
            } finally {
              vh > 0 && vh--;
            }
            ta = void 0;
          }
          return ta;
        };
    a[zi] = b;
    a[Bi] = Ki.bind(a);
    return b;
  }
  function Ki(a, b, c, d) {
    var e = this[yi],
      f = this[zi],
      g = Sf(void 0, e.cd),
      h = Ef(a);
    if (h) {
      var k = !1,
        l = e.Fe;
      if (l) {
        e = function (t, v, x) {
          if (x.length !== 0)
            if (l[v]) {
              t = y(x);
              v = t.next();
              try {
                for (; !v.done; v = t.next()) {
                  var E = zh(v.value);
                  try {
                    (k = !0), f(g, E);
                  } finally {
                    Ah(E);
                  }
                }
              } finally {
                z(t, v);
              }
            } else d == null || d(a, v, x);
        };
        if (b == null) Gf(h, e);
        else if (h != null) {
          var m = h[b];
          m && e(h, b, m);
        }
        if (k) {
          var p = a[H] | 0;
          if (p & 2 && p & 2048 && (c == null || !c.cn)) throw Error();
          var q = p & 128 ? Vd : void 0,
            r = function (t, v) {
              if (fg(a, t, q) != null)
                switch (c == null ? void 0 : c.bn) {
                  case 1:
                    return;
                  default:
                    throw Error();
                }
              v != null && (p = ig(a, p, t, v, q));
              delete h[t];
            };
          b == null
            ? Td(g, g[H] | 0, function (t, v) {
                r(t, v);
              })
            : r(b, fg(g, b, q));
        }
      }
    }
  }
  function Ji(a) {
    a = Fi(a);
    var b = a[0].h;
    if ((a = a[1])) {
      var c = Ii(a),
        d = Ei(yi, Gi, Hi, a).cd;
      return function (e, f, g) {
        return b(e, f, g, d, c);
      };
    }
    return b;
  }
  function Li(a, b, c) {
    a[b] = c.j;
  }
  function Mi(a, b, c, d) {
    var e,
      f,
      g = c.j;
    a[b] = function (h, k, l) {
      return g(h, k, l, f || (f = Ei(xi, Li, Mi, d).cd), e || (e = Ni(d)));
    };
  }
  function Ni(a) {
    var b = a[Ai];
    if (!b) {
      var c = Ei(xi, Li, Mi, a);
      b = function (d, e) {
        return Oi(d, e, c);
      };
      a[Ai] = b;
    }
    return b;
  }
  function Oi(a, b, c) {
    Td(a, a[H] | 0, function (d, e) {
      if (e != null) {
        var f = Pi(c, d);
        f ? f(b, e, d) : d < 500 || pd(yd, 3);
      }
    });
    (a = Ef(a)) &&
      Gf(a, function (d, e, f) {
        $h(b, b.h.end());
        for (d = 0; d < f.length; d++) $h(b, kd(f[d]) || new Uint8Array(0));
      });
  }
  function Pi(a, b) {
    var c = a[b];
    if (c) return c;
    if ((c = a.Fe))
      if ((c = c[b])) {
        c = Fi(c);
        var d = c[0].j;
        if ((c = c[1])) {
          var e = Ni(c),
            f = Ei(xi, Li, Mi, c).cd;
          c = a.Fg
            ? Di(f, e)
            : function (g, h, k) {
                return d(g, h, k, f, e);
              };
        } else c = d;
        return (a[b] = c);
      }
  }
  var Qi = ke(0);
  function Ri(a, b) {
    if (Array.isArray(b)) {
      var c = b[H] | 0;
      if (c & 4) return b;
      for (var d = 0, e = 0; d < b.length; d++) {
        var f = a(b[d]);
        f != null && (b[e++] = f);
      }
      e < d && (b.length = e);
      a = (c | 5) & -1537;
      a !== c && Gd(b, a);
      a & 2 && Object.freeze(b);
      return b;
    }
  }
  var Si = function (a, b) {
    var c = new Zh();
    Oi(a.G, c, Ei(xi, Li, Mi, b));
    $h(c, c.h.end());
    a = new Uint8Array(c.j);
    b = c.l;
    for (var d = b.length, e = 0, f = 0; f < d; f++) {
      var g = b[f];
      a.set(g, e);
      e += g.length;
    }
    c.l = [a];
    return a;
  };
  function Ti(a, b, c) {
    return new ri(a, b, c);
  }
  function Ui(a, b, c) {
    ig(a, a[H] | 0, b, c, (a[H] | 0) & 128 ? Vd : void 0);
  }
  function Vi(a, b, c) {
    b = ef(b);
    if (b != null && b != null)
      switch ((ai(a, c, 0), typeof b)) {
        case "number":
          a = a.h;
          xe(b);
          Vh(a, te, ue);
          break;
        case "bigint":
          c = Th(b, Jh, Kh);
          Vh(a.h, c.j, c.h);
          break;
        default:
          b
            ? /^-?\d+$/.test(b)
              ? (Fe(b), (c = new Jh(te, ue)))
              : (c = null)
            : (c = Lh || (Lh = new Jh(0, 0))),
            Vh(a.h, c.j, c.h);
      }
  }
  function Wi(a, b, c) {
    b = Ve(b);
    b != null && b != null && (ai(a, c, 0), Xh(a.h, b));
  }
  function Xi(a, b, c) {
    if (a.j !== 0) return !1;
    Ui(b, c, ph(a.h, Ce));
    return !0;
  }
  var Yi = Ti(
      function (a, b, c) {
        if (a.j !== 1) return !1;
        var d = a.h;
        a = rh(d);
        var e = rh(d);
        d = (e >> 31) * 2 + 1;
        var f = (e >>> 20) & 2047;
        a = 4294967296 * (e & 1048575) + a;
        a =
          f == 2047
            ? a
              ? NaN
              : d * Infinity
            : f == 0
            ? d * 4.9e-324 * a
            : d * Math.pow(2, f - 1075) * (a + 4503599627370496);
        Ui(b, c, a === 0 ? void 0 : a);
        return !0;
      },
      function (a, b, c) {
        b = Ne(b);
        b != null &&
          (ai(a, c, 1),
          (a = a.h),
          (c = ve || (ve = new DataView(new ArrayBuffer(8)))),
          c.setFloat64(0, +b, !0),
          (te = c.getUint32(0, !0)),
          (ue = c.getUint32(4, !0)),
          Yh(a, te),
          Yh(a, ue));
      },
      pi
    ),
    Zi = Ti(
      function (a, b, c) {
        if (a.j !== 5) return !1;
        var d = rh(a.h);
        a = (d >> 31) * 2 + 1;
        var e = (d >>> 23) & 255;
        d &= 8388607;
        Ui(
          b,
          c,
          e == 255
            ? d
              ? NaN
              : a * Infinity
            : e == 0
            ? a * 1.401298464324817e-45 * d
            : a * Math.pow(2, e - 150) * (d + 8388608)
        );
        return !0;
      },
      function (a, b, c) {
        b = Ne(b);
        b != null &&
          (ai(a, c, 5),
          (a = a.h),
          (c = ve || (ve = new DataView(new ArrayBuffer(8)))),
          c.setFloat32(0, +b, !0),
          (ue = 0),
          (te = c.getUint32(0, !0)),
          Yh(a, te));
      },
      oi
    ),
    $i = Ti(
      function (a, b, c) {
        return Xi(a, b, c);
      },
      Vi,
      ki
    ),
    aj = Ti(
      function (a, b, c) {
        return Xi(a, b, c);
      },
      Vi,
      ki
    ),
    bj = Ti(
      function (a, b, c) {
        a.j !== 0
          ? (b = !1)
          : ((a = ph(a.h, Ce)), Ui(b, c, a === Qi ? void 0 : a), (b = !0));
        return b;
      },
      Vi,
      ki
    ),
    cj = Ti(
      function (a, b, c) {
        a.j !== 0 ? (a = !1) : (Ui(b, c, ph(a.h, Be)), (a = !0));
        return a;
      },
      function (a, b, c) {
        b = ff(b);
        if (b != null && b != null)
          switch ((ai(a, c, 0), typeof b)) {
            case "number":
              a = a.h;
              xe(b);
              Vh(a, te, ue);
              break;
            case "bigint":
              c = Th(b, Gh, Hh);
              Vh(a.h, c.j, c.h);
              break;
            default:
              b
                ? /^\d+$/.test(b)
                  ? (Fe(b), (c = new Gh(te, ue)))
                  : (c = null)
                : (c = Ih || (Ih = new Gh(0, 0))),
                Vh(a.h, c.j, c.h);
          }
      },
      ni
    ),
    dj = Ti(
      function (a, b, c) {
        if (a.j !== 0) return !1;
        Ui(b, c, qh(a.h));
        return !0;
      },
      Wi,
      ii
    ),
    ej = Ti(
      function (a, b, c) {
        if (a.j !== 0) return !1;
        a = qh(a.h);
        Ui(b, c, a === 0 ? void 0 : a);
        return !0;
      },
      Wi,
      ii
    ),
    fj = Ti(
      function (a, b, c) {
        if (a.j !== 0) return !1;
        Ui(b, c, sh(a.h));
        return !0;
      },
      function (a, b, c) {
        b = Pe(b);
        b != null && (ai(a, c, 0), a.h.h.push(b ? 1 : 0));
      },
      gi
    ),
    gj = Ti(
      function (a, b, c) {
        if (a.j !== 2) return !1;
        Ui(b, c, Fh(a));
        return !0;
      },
      function (a, b, c) {
        b = jf(b);
        b != null && di(a, c, zb(b));
      },
      hi
    ),
    hj;
  hj = new ri(
    function (a, b, c) {
      if (a.j !== 2) return !1;
      a = Fh(a);
      xg(b, b[H] | 0, c).push(a);
      return !0;
    },
    function (a, b, c) {
      b = Ri(jf, b);
      if (b != null)
        for (var d = 0; d < b.length; d++) {
          var e = a,
            f = c,
            g = b[d];
          g != null && di(e, f, zb(g));
        }
    },
    hi
  );
  var ij,
    jj = void 0;
  jj = jj === void 0 ? fi : jj;
  ij = new ri(
    function (a, b, c, d, e) {
      if (a.j !== 2) return !1;
      d = Sf(void 0, d);
      xg(b, b[H] | 0, c).push(d);
      Eh(a, d, e);
      return !0;
    },
    function (a, b, c, d, e) {
      if (Array.isArray(b)) {
        for (var f = 0; f < b.length; f++) {
          var g = a,
            h = c,
            k = e,
            l = ui(b[f], d);
          l != null && ((h = bi(g, h)), k(l, g), ci(g, h));
        }
        a = b[H] | 0;
        a & 1 || Gd(b, a | 1);
      }
    },
    jj
  );
  var kj = Ti(
      function (a, b, c) {
        if (a.j !== 0) return !1;
        Ui(b, c, qh(a.h) >>> 0);
        return !0;
      },
      function (a, b, c) {
        b = We(b);
        b != null && b != null && (ai(a, c, 0), Wh(a.h, b));
      },
      ji
    ),
    lj = Ti(
      function (a, b, c) {
        if (a.j !== 0) return !1;
        Ui(b, c, qh(a.h));
        return !0;
      },
      function (a, b, c) {
        b = Ve(b);
        b != null && ((b = parseInt(b, 10)), ai(a, c, 0), Xh(a.h, b));
      },
      qi
    ),
    mj;
  mj = new ri(
    function (a, b, c) {
      if (a.j !== 0 && a.j !== 2) return !1;
      b = xg(b, b[H] | 0, c);
      if (a.j == 2)
        for (c = qh(a.h) >>> 0, c = a.h.h + c; a.h.h < c; ) b.push(qh(a.h));
      else b.push(qh(a.h));
      return !0;
    },
    function (a, b, c) {
      b = Ri(Ve, b);
      if (b != null && b.length) {
        c = bi(a, c);
        for (var d = 0; d < b.length; d++) Xh(a.h, b[d]);
        ci(a, c);
      }
    },
    qi
  );
  function nj(a) {
    return function (b) {
      return Si(b, a);
    };
  }
  function oj(a) {
    return function () {
      return Si(this, a);
    };
  }
  function pj(a) {
    return function (b) {
      b = JSON.parse(b);
      if (!Array.isArray(b))
        throw Error(
          "Expected jspb data to be an array, got " + ab(b) + ": " + b
        );
      Jd(b);
      return new a(b);
    };
  }
  function qj(a) {
    return function (b) {
      if (b == null || b == "") b = new a();
      else {
        b = JSON.parse(b);
        if (!Array.isArray(b)) throw Error("dnarr");
        b = new a(Ld(b));
      }
      return b;
    };
  }
  var rj = function (a) {
    this.G = I(a);
  };
  w(rj, K);
  var sj = function (a) {
    this.G = I(a);
  };
  w(sj, K);
  var tj = function (a) {
    this.G = I(a);
  };
  w(tj, K);
  var uj = function (a) {
    this.G = I(a);
  };
  w(uj, K);
  var vj = function (a) {
    this.G = I(a);
  };
  w(vj, K);
  var wj = function (a) {
    this.G = I(a);
  };
  w(wj, K);
  var xj = [2, 3, 5];
  var yj = function (a) {
    this.G = I(a);
  };
  w(yj, K);
  var zj = function (a) {
    this.G = I(a);
  };
  w(zj, K);
  var Aj = function (a) {
    this.G = I(a);
  };
  w(Aj, K);
  Aj.prototype.getEscapedQemQueryId = function () {
    return Yg(this, 1);
  };
  var Bj = function (a) {
    this.G = I(a);
  };
  w(Bj, K);
  var Cj = function (a) {
    this.G = I(a);
  };
  w(Cj, K);
  var Dj = [0, gj, [0, $i], [0, lj, aj]];
  var Ej = function (a) {
    this.G = I(a);
  };
  w(Ej, K);
  var Fj = function (a, b, c) {
      c = c === void 0 ? {} : c;
      this.error = a;
      this.meta = c;
      this.context = b.context;
      this.msg = b.message || "";
      this.id = b.id || "jserror";
    },
    Gj = function (a) {
      return !!(a.error && a.meta && a.id);
    };
  function Hj(a) {
    var b = a.toString();
    a.name && b.indexOf(a.name) == -1 && (b += ": " + a.name);
    a.message && b.indexOf(a.message) == -1 && (b += ": " + a.message);
    if (a.stack)
      a: {
        a = a.stack;
        var c = b;
        try {
          a.indexOf(c) == -1 && (a = c + "\n" + a);
          for (var d; a != d; )
            (d = a),
              (a = a.replace(
                RegExp("((https?:/..*/)[^/:]*:\\d+(?:.|\n)*)\\2"),
                "$1"
              ));
          b = a.replace(RegExp("\n *", "g"), "\n");
          break a;
        } catch (e) {
          b = c;
          break a;
        }
        b = void 0;
      }
    return b;
  }
  function Ij(a, b) {
    if (a)
      for (var c in a)
        Object.prototype.hasOwnProperty.call(a, c) && b(a[c], c, a);
  }
  function Jj(a) {
    try {
      return !!a && a.location.href != null && xc(a, "foo");
    } catch (b) {
      return !1;
    }
  }
  function Kj(a) {
    for (var b = a; a && a !== a.parent; ) (a = a.parent), Jj(a) && (b = a);
    return b;
  }
  var Lj = function () {};
  function Mj(a) {
    var b = !1,
      c;
    return function () {
      b || ((c = a()), (b = !0));
      return c;
    };
  }
  function Nj(a) {
    var b = a;
    return function () {
      if (b) {
        var c = b;
        b = null;
        c();
      }
    };
  }
  function Oj(a) {
    var b = 0,
      c = !1,
      d = [],
      e = function () {
        b = 0;
        c && ((c = !1), f());
      },
      f = function () {
        b = C.setTimeout(e, 1e3);
        var g = d;
        d = [];
        a.apply(void 0, g);
      };
    return function (g) {
      d = arguments;
      b ? (c = !0) : f();
    };
  }
  function Pj() {
    return !Qj() && (G("iPod") || G("iPhone") || G("Android") || G("IEMobile"));
  }
  function Qj() {
    return G("iPad") || (G("Android") && !G("Mobile")) || G("Silk");
  } /* 
 
 Copyright Google LLC 
 SPDX-License-Identifier: Apache-2.0 
*/
  var Rj = globalThis.trustedTypes,
    Sj;
  function Tj() {
    var a = null;
    if (!Rj) return a;
    try {
      var b = function (c) {
        return c;
      };
      a = Rj.createPolicy("goog#html", {
        createHTML: b,
        createScript: b,
        createScriptURL: b,
      });
    } catch (c) {}
    return a;
  }
  function Uj() {
    Sj === void 0 && (Sj = Tj());
    return Sj;
  }
  var Vj = function (a) {
    this.h = a;
  };
  Vj.prototype.toString = function () {
    return this.h + "";
  };
  function Wj(a) {
    var b = Uj();
    a = b ? b.createScriptURL(a) : a;
    return new Vj(a);
  }
  function Xj(a) {
    if (a instanceof Vj) return a.h;
    throw Error("");
  }
  var Yj = function (a) {
    this.h = a;
  };
  Yj.prototype.toString = function () {
    return this.h;
  };
  function Zj(a) {
    return new Yj(a);
  }
  var ak = Zj("about:invalid#zClosurez");
  var bk = function (a) {
    this.oj = a;
  };
  function ck(a) {
    return new bk(function (b) {
      return b.substr(0, a.length + 1).toLowerCase() === a + ":";
    });
  }
  var dk = [
    ck("data"),
    ck("http"),
    ck("https"),
    ck("mailto"),
    ck("ftp"),
    new bk(function (a) {
      return /^[^:]*([/?#]|$)/.test(a);
    }),
  ];
  function ek(a) {
    var b = window;
    if (
      (typeof MediaSource !== "undefined" && a instanceof MediaSource) ||
      (typeof b.ManagedMediaSource !== "undefined" &&
        a instanceof b.ManagedMediaSource)
    )
      return Zj(URL.createObjectURL(a));
    b = a.type;
    b.toLowerCase() === "application/octet-stream"
      ? (b = !0)
      : ((b = b.match(/^([^;]+)(?:;\w+=(?:\w+|"[\w;,= ]+"))*$/i)),
        (b =
          (b == null ? void 0 : b.length) === 2 &&
          (/^image\/(?:bmp|gif|jpeg|jpg|png|tiff|webp|x-icon|heic|heif|avif|x-ms-bmp)$/i.test(
            b[1]
          ) ||
            /^video\/(?:3gpp|avi|mpeg|mpg|mp4|ogg|webm|x-flv|matroska|x-matroska|quicktime|x-ms-wmv)$/i.test(
              b[1]
            ) ||
            /^audio\/(?:3gpp2|3gpp|aac|amr|L16|midi|mp3|mp4|mpeg|oga|ogg|opus|x-m4a|matroska|x-matroska|x-wav|wav|webm)$/i.test(
              b[1]
            ) ||
            /^font\/[\w-]+$/i.test(b[1]))));
    if (!b) throw Error("");
    return Zj(URL.createObjectURL(a));
  }
  var fk = /^\s*(?!javascript:)(?:[\w+.-]+:|[^:/?#]*(?:[/?#]|$))/i;
  var gk = function (a) {
    this.h = a;
  };
  gk.prototype.toString = function () {
    return this.h + "";
  };
  function hk(a) {
    var b = Uj();
    a = b ? b.createHTML(a) : a;
    return new gk(a);
  }
  function ik(a) {
    if (a instanceof gk) return a.h;
    throw Error("");
  }
  var jk = {
      Tk: 0,
      Lk: 1,
      Mk: 2,
      0: "FORMATTED_HTML_CONTENT",
      1: "EMBEDDED_INTERNAL_CONTENT",
      2: "EMBEDDED_TRUSTED_EXTERNAL_CONTENT",
    },
    kk = function (a, b) {
      b = Error.call(this, a + " cannot be used with intent " + jk[b]);
      this.message = b.message;
      "stack" in b && (this.stack = b.stack);
      this.type = a;
      this.name = "TypeCannotBeUsedWithIframeIntentError";
    };
  w(kk, Error);
  function lk(a, b) {
    a.src = Xj(b);
    var c;
    b = a.ownerDocument;
    b = b === void 0 ? document : b;
    var d;
    b =
      (d = (c = b).querySelector) == null ? void 0 : d.call(c, "script[nonce]");
    (c = b == null ? "" : b.nonce || b.getAttribute("nonce") || "") &&
      a.setAttribute("nonce", c);
  }
  function mk(a, b) {
    if (a.nodeType === 1 && /^(script|style)$/i.test(a.tagName))
      throw Error("");
    a.innerHTML = ik(b);
  }
  var nk = function (a) {
    var b = [],
      c = [],
      d = {},
      e = function (f, g) {
        var h = g + "  ";
        try {
          if (f === void 0) b.push("undefined");
          else if (f === null) b.push("NULL");
          else if (typeof f === "string")
            b.push('"' + f.replace(/\n/g, "\n" + g) + '"');
          else if (typeof f === "function")
            b.push(String(f).replace(/\n/g, "\n" + g));
          else if (cb(f)) {
            f[db] || c.push(f);
            var k = fb(f);
            if (d[k]) b.push("*** reference loop detected (id=" + k + ") ***");
            else {
              d[k] = !0;
              b.push("{");
              for (var l in f)
                typeof f[l] !== "function" &&
                  (b.push("\n"), b.push(h), b.push(l + " = "), e(f[l], h));
              b.push("\n" + g + "}");
              delete d[k];
            }
          } else b.push(f);
        } catch (m) {
          b.push("*** " + m + " ***");
        }
      };
    e(a, "");
    for (a = 0; a < c.length; a++) gb(c[a]);
    return b.join("");
  };
  function ok(a, b) {
    a.write(ik(b));
  }
  var pk = function (a) {
      return decodeURIComponent(a.replace(/\+/g, " "));
    },
    qk = function (a) {
      Nb.test(a) &&
        (a.indexOf("&") != -1 && (a = a.replace(Hb, "&amp;")),
        a.indexOf("<") != -1 && (a = a.replace(Ib, "&lt;")),
        a.indexOf(">") != -1 && (a = a.replace(Jb, "&gt;")),
        a.indexOf('"') != -1 && (a = a.replace(Kb, "&quot;")),
        a.indexOf("'") != -1 && (a = a.replace(Lb, "&#39;")),
        a.indexOf("\x00") != -1 && (a = a.replace(Mb, "&#0;")));
      return a;
    },
    rk = function (a, b) {
      a.length > b && (a = a.substring(0, b - 3) + "...");
      return a;
    },
    sk = String.prototype.repeat
      ? function (a, b) {
          return a.repeat(b);
        }
      : function (a, b) {
          return Array(b + 1).join(a);
        },
    tk = function (a) {
      return a == null ? "" : String(a);
    },
    uk = (Math.random() * 2147483648) | 0,
    vk = function () {
      return "goog_" + uk++;
    },
    wk = function (a) {
      return String(a).replace(/\-([a-z])/g, function (b, c) {
        return c.toUpperCase();
      });
    },
    xk = function () {
      return "googleAvInapp".replace(/([A-Z])/g, "-$1").toLowerCase();
    },
    yk = function (a) {
      return a.replace(RegExp("(^|[\\s]+)([a-z])", "g"), function (b, c, d) {
        return c + d.toUpperCase();
      });
    },
    zk = function (a) {
      isFinite(a) && (a = String(a));
      return typeof a === "string"
        ? /^\s*-?0x/i.test(a)
          ? parseInt(a, 16)
          : parseInt(a, 10)
        : NaN;
    };
  function Ak(a) {
    var b, c;
    return (c = (b = /https?:\/\/[^\/]+/.exec(a)) == null ? void 0 : b[0]) !=
      null
      ? c
      : "";
  }
  function Bk() {
    try {
      for (var a = C, b = null; b != a; b = a, a = a.parent)
        switch (a.location.protocol) {
          case "https:":
            return !0;
          case "file:":
            return !0;
          case "http:":
            return !1;
        }
    } catch (c) {}
    return !0;
  }
  var Ck = Mj(function () {
    return Pj() ? 2 : Qj() ? 1 : 0;
  });
  function Dk() {
    if (!globalThis.crypto) return Math.random();
    try {
      var a = new Uint32Array(1);
      globalThis.crypto.getRandomValues(a);
      return a[0] / 65536 / 65536;
    } catch (b) {
      return Math.random();
    }
  }
  var Ek,
    Fk = 64;
  function Gk() {
    try {
      return (
        Ek != null || (Ek = new Uint32Array(64)),
        Fk >= 64 && (crypto.getRandomValues(Ek), (Fk = 0)),
        Ek[Fk++]
      );
    } catch (a) {
      return Math.floor(Math.random() * 4294967296);
    }
  }
  function Hk(a) {
    var b = window;
    if (!$d(b.goog_pvsid))
      try {
        var c = Gk() + (Gk() & 2097151) * 4294967296;
        Object.defineProperty(b, "goog_pvsid", { value: c, configurable: !1 });
      } catch (d) {
        a.Ya({ methodName: 784, Sb: d });
      }
    b = Number(b.goog_pvsid);
    (!b || b <= 0) &&
      a.Ya({ methodName: 784, Sb: Error("Invalid correlator, " + b) });
    return b || -1;
  }
  function Ik(a) {
    var b = a.split(/[?#]/),
      c = /[?]/.test(a) ? "?" + b[1] : "";
    return {
      Hf: b[0],
      Pg: c,
      fragment: /[#]/.test(a) ? "#" + (c ? b[2] : b[1]) : "",
    };
  }
  function Jk(a) {
    var b = La.apply(1, arguments);
    if (b.length === 0) return Wj(a[0]);
    for (var c = a[0], d = 0; d < b.length; d++)
      c += encodeURIComponent(b[d]) + a[d + 1];
    return Wj(c);
  }
  function Kk(a, b, c, d) {
    function e(g, h) {
      g != null &&
        (Array.isArray(g)
          ? g.forEach(function (k) {
              return e(k, h);
            })
          : ((b += f + encodeURIComponent(h) + "=" + encodeURIComponent(g)),
            (f = "&")));
    }
    var f = b.length ? "&" : "?";
    d.constructor === Object && (d = Object.entries(d));
    Array.isArray(d)
      ? d.forEach(function (g) {
          return e(g[1], g[0]);
        })
      : d.forEach(e);
    return Wj(a + b + c);
  }
  var Lk = /[^#]*/;
  var Mk = function (a, b) {
      try {
        return !(!a.frames || !a.frames[b]);
      } catch (c) {
        return !1;
      }
    },
    Nk = function (a, b) {
      for (var c = 0; c < 50; ++c) {
        if (Mk(a, b)) return a;
        a: {
          try {
            var d = a.parent;
            if (d && d !== a) {
              var e = d;
              break a;
            }
          } catch (f) {}
          e = null;
        }
        if (!(a = e)) break;
      }
      return null;
    },
    Ok = function () {
      return Hk({ Ya: function () {} });
    },
    Pk = function (a, b) {
      b = b === void 0 ? document : b;
      return b.createElement(String(a).toLowerCase());
    };
  function Qk(a, b) {
    this.x = a !== void 0 ? a : 0;
    this.y = b !== void 0 ? b : 0;
  }
  Qk.prototype.equals = function (a) {
    return (
      a instanceof Qk &&
      (this == a ? !0 : this && a ? this.x == a.x && this.y == a.y : !1)
    );
  };
  Qk.prototype.ceil = function () {
    this.x = Math.ceil(this.x);
    this.y = Math.ceil(this.y);
    return this;
  };
  Qk.prototype.floor = function () {
    this.x = Math.floor(this.x);
    this.y = Math.floor(this.y);
    return this;
  };
  Qk.prototype.round = function () {
    this.x = Math.round(this.x);
    this.y = Math.round(this.y);
    return this;
  };
  function Rk(a, b) {
    this.width = a;
    this.height = b;
  }
  n = Rk.prototype;
  n.aspectRatio = function () {
    return this.width / this.height;
  };
  n.isEmpty = function () {
    return !(this.width * this.height);
  };
  n.ceil = function () {
    this.width = Math.ceil(this.width);
    this.height = Math.ceil(this.height);
    return this;
  };
  n.floor = function () {
    this.width = Math.floor(this.width);
    this.height = Math.floor(this.height);
    return this;
  };
  n.round = function () {
    this.width = Math.round(this.width);
    this.height = Math.round(this.height);
    return this;
  };
  function Sk(a, b, c) {
    for (var d in a) b.call(c, a[d], d, a);
  }
  function Tk(a, b) {
    var c = {},
      d;
    for (d in a) b.call(void 0, a[d], d, a) && (c[d] = a[d]);
    return c;
  }
  function Uk(a) {
    var b = Vk,
      c;
    for (c in b) if (!a.call(void 0, b[c], c, b)) return !1;
    return !0;
  }
  function Wk(a) {
    var b = [],
      c = 0,
      d;
    for (d in a) b[c++] = a[d];
    return b;
  }
  function Xk(a) {
    var b = [],
      c = 0,
      d;
    for (d in a) b[c++] = d;
    return b;
  }
  function Yk(a, b) {
    var c = bb(b),
      d = c ? b : arguments;
    for (c = c ? 0 : 1; c < d.length; c++) {
      if (a == null) return;
      a = a[d[c]];
    }
    return a;
  }
  function Zk(a, b) {
    return a !== null && b in a;
  }
  function $k(a, b) {
    for (var c in a) if (a[c] == b) return !0;
    return !1;
  }
  function al(a) {
    var b = bl,
      c;
    for (c in b) if (a.call(void 0, b[c], c, b)) return c;
  }
  function cl(a) {
    for (var b in a) return !1;
    return !0;
  }
  function dl(a) {
    for (var b in a) delete a[b];
  }
  function el(a, b, c) {
    return a !== null && b in a ? a[b] : c;
  }
  var fl =
    "constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(
      " "
    );
  function gl(a, b) {
    for (var c, d, e = 1; e < arguments.length; e++) {
      d = arguments[e];
      for (c in d) a[c] = d[c];
      for (var f = 0; f < fl.length; f++)
        (c = fl[f]),
          Object.prototype.hasOwnProperty.call(d, c) && (a[c] = d[c]);
    }
  }
  var jl = function (a) {
      return a ? new hl(il(a)) : qb || (qb = new hl());
    },
    kl = function (a) {
      var b = document;
      return typeof a === "string" ? b.getElementById(a) : a;
    },
    ml = function (a, b) {
      Sk(b, function (c, d) {
        d == "style"
          ? (a.style.cssText = c)
          : d == "class"
          ? (a.className = c)
          : d == "for"
          ? (a.htmlFor = c)
          : ll.hasOwnProperty(d)
          ? a.setAttribute(ll[d], c)
          : d.lastIndexOf("aria-", 0) == 0 || d.lastIndexOf("data-", 0) == 0
          ? a.setAttribute(d, c)
          : (a[d] = c);
      });
    },
    ll = {
      cellpadding: "cellPadding",
      cellspacing: "cellSpacing",
      colspan: "colSpan",
      frameborder: "frameBorder",
      height: "height",
      maxlength: "maxLength",
      nonce: "nonce",
      role: "role",
      rowspan: "rowSpan",
      type: "type",
      usemap: "useMap",
      valign: "vAlign",
      width: "width",
    },
    nl = function (a) {
      a = a.document;
      a = a.compatMode == "CSS1Compat" ? a.documentElement : a.body;
      return new Rk(a.clientWidth, a.clientHeight);
    },
    ol = function (a) {
      return a ? a.defaultView : window;
    },
    rl = function (a, b, c) {
      var d = arguments,
        e = document,
        f = d[1],
        g = pl(e, String(d[0]));
      f &&
        (typeof f === "string"
          ? (g.className = f)
          : Array.isArray(f)
          ? (g.className = f.join(" "))
          : ml(g, f));
      d.length > 2 && ql(e, g, d, 2);
      return g;
    },
    ql = function (a, b, c, d) {
      function e(h) {
        h && b.appendChild(typeof h === "string" ? a.createTextNode(h) : h);
      }
      for (; d < c.length; d++) {
        var f = c[d];
        if (!bb(f) || (cb(f) && f.nodeType > 0)) e(f);
        else {
          a: {
            if (f && typeof f.length == "number") {
              if (cb(f)) {
                var g =
                  typeof f.item == "function" || typeof f.item == "string";
                break a;
              }
              if (typeof f === "function") {
                g = typeof f.item == "function";
                break a;
              }
            }
            g = !1;
          }
          Zb(g ? qc(f) : f, e);
        }
      }
    },
    pl = function (a, b) {
      b = String(b);
      a.contentType === "application/xhtml+xml" && (b = b.toLowerCase());
      return a.createElement(b);
    },
    sl = function (a) {
      for (var b; (b = a.firstChild); ) a.removeChild(b);
    },
    tl = function (a) {
      a && a.parentNode && a.parentNode.removeChild(a);
    },
    ul = function (a, b) {
      if (!a || !b) return !1;
      if (a.contains && b.nodeType == 1) return a == b || a.contains(b);
      if (typeof a.compareDocumentPosition != "undefined")
        return a == b || !!(a.compareDocumentPosition(b) & 16);
      for (; b && a != b; ) b = b.parentNode;
      return b == a;
    },
    il = function (a) {
      return a.nodeType == 9 ? a : a.ownerDocument || a.document;
    },
    vl = function (a) {
      try {
        return (
          a.contentWindow || (a.contentDocument ? ol(a.contentDocument) : null)
        );
      } catch (b) {}
      return null;
    },
    wl = function (a, b) {
      a && (a = a.parentNode);
      for (var c = 0; a; ) {
        if (b(a)) return a;
        a = a.parentNode;
        c++;
      }
      return null;
    },
    hl = function (a) {
      this.h = a || C.document || document;
    };
  hl.prototype.getElementsByTagName = function (a, b) {
    return (b || this.h).getElementsByTagName(String(a));
  };
  var xl = function (a) {
    var b = a.h;
    a = b.scrollingElement
      ? b.scrollingElement
      : Ec || b.compatMode != "CSS1Compat"
      ? b.body || b.documentElement
      : b.documentElement;
    b = b.defaultView;
    return new Qk(
      (b == null ? void 0 : b.pageXOffset) || a.scrollLeft,
      (b == null ? void 0 : b.pageYOffset) || a.scrollTop
    );
  };
  hl.prototype.appendChild = function (a, b) {
    a.appendChild(b);
  };
  hl.prototype.append = function (a, b) {
    ql(il(a), a, arguments, 1);
  };
  hl.prototype.canHaveChildren = function (a) {
    if (a.nodeType != 1) return !1;
    switch (a.tagName) {
      case "APPLET":
      case "AREA":
      case "BASE":
      case "BR":
      case "COL":
      case "COMMAND":
      case "EMBED":
      case "FRAME":
      case "HR":
      case "IMG":
      case "INPUT":
      case "IFRAME":
      case "ISINDEX":
      case "KEYGEN":
      case "LINK":
      case "NOFRAMES":
      case "NOSCRIPT":
      case "META":
      case "OBJECT":
      case "PARAM":
      case "SCRIPT":
      case "SOURCE":
      case "STYLE":
      case "TRACK":
      case "WBR":
        return !1;
    }
    return !0;
  };
  hl.prototype.contains = ul;
  function L(a, b, c, d) {
    this.top = a;
    this.right = b;
    this.bottom = c;
    this.left = d;
  }
  L.prototype.getWidth = function () {
    return this.right - this.left;
  };
  L.prototype.getHeight = function () {
    return this.bottom - this.top;
  };
  var yl = function (a) {
    return new L(a.top, a.right, a.bottom, a.left);
  };
  L.prototype.contains = function (a) {
    return this && a
      ? a instanceof L
        ? a.left >= this.left &&
          a.right <= this.right &&
          a.top >= this.top &&
          a.bottom <= this.bottom
        : a.x >= this.left &&
          a.x <= this.right &&
          a.y >= this.top &&
          a.y <= this.bottom
      : !1;
  };
  L.prototype.expand = function (a, b, c, d) {
    cb(a)
      ? ((this.top -= a.top),
        (this.right += a.right),
        (this.bottom += a.bottom),
        (this.left -= a.left))
      : ((this.top -= a),
        (this.right += Number(b)),
        (this.bottom += Number(c)),
        (this.left -= Number(d)));
    return this;
  };
  var zl = function (a, b) {
    return a == b
      ? !0
      : a && b
      ? a.top == b.top &&
        a.right == b.right &&
        a.bottom == b.bottom &&
        a.left == b.left
      : !1;
  };
  L.prototype.ceil = function () {
    this.top = Math.ceil(this.top);
    this.right = Math.ceil(this.right);
    this.bottom = Math.ceil(this.bottom);
    this.left = Math.ceil(this.left);
    return this;
  };
  L.prototype.floor = function () {
    this.top = Math.floor(this.top);
    this.right = Math.floor(this.right);
    this.bottom = Math.floor(this.bottom);
    this.left = Math.floor(this.left);
    return this;
  };
  L.prototype.round = function () {
    this.top = Math.round(this.top);
    this.right = Math.round(this.right);
    this.bottom = Math.round(this.bottom);
    this.left = Math.round(this.left);
    return this;
  };
  var Al = function (a, b, c) {
    b instanceof Qk
      ? ((a.left += b.x), (a.right += b.x), (a.top += b.y), (a.bottom += b.y))
      : ((a.left += b),
        (a.right += b),
        typeof c === "number" && ((a.top += c), (a.bottom += c)));
    return a;
  };
  function Bl(a, b, c, d) {
    this.left = a;
    this.top = b;
    this.width = c;
    this.height = d;
  }
  var Cl = function (a) {
    return new L(a.top, a.left + a.width, a.top + a.height, a.left);
  };
  n = Bl.prototype;
  n.contains = function (a) {
    return a instanceof Qk
      ? a.x >= this.left &&
          a.x <= this.left + this.width &&
          a.y >= this.top &&
          a.y <= this.top + this.height
      : this.left <= a.left &&
          this.left + this.width >= a.left + a.width &&
          this.top <= a.top &&
          this.top + this.height >= a.top + a.height;
  };
  n.getSize = function () {
    return new Rk(this.width, this.height);
  };
  n.ceil = function () {
    this.left = Math.ceil(this.left);
    this.top = Math.ceil(this.top);
    this.width = Math.ceil(this.width);
    this.height = Math.ceil(this.height);
    return this;
  };
  n.floor = function () {
    this.left = Math.floor(this.left);
    this.top = Math.floor(this.top);
    this.width = Math.floor(this.width);
    this.height = Math.floor(this.height);
    return this;
  };
  n.round = function () {
    this.left = Math.round(this.left);
    this.top = Math.round(this.top);
    this.width = Math.round(this.width);
    this.height = Math.round(this.height);
    return this;
  };
  var El = function (a, b) {
      if (typeof b === "string") Dl(a, void 0, b);
      else for (var c in b) Dl(a, b[c], c);
    },
    Fl = /^--.+/,
    Dl = function (a, b, c) {
      (c = Gl(a, c)) &&
        (Fl.test(c) ? a.style.setProperty(c, b) : (a.style[c] = b));
    },
    Hl = {},
    Gl = function (a, b) {
      var c = Hl[b];
      if (!c) {
        var d = wk(b);
        c = d;
        a.style[d] === void 0 &&
          ((d = (Ec ? "Webkit" : Dc ? "Moz" : null) + yk(d)),
          a.style[d] !== void 0 && (c = d));
        Hl[b] = c;
      }
      return c;
    },
    Il = function (a, b) {
      var c = a.style[wk(b)];
      return typeof c !== "undefined" ? c : a.style[Gl(a, b)] || "";
    },
    Jl = function (a, b) {
      var c = il(a);
      return c.defaultView &&
        c.defaultView.getComputedStyle &&
        (a = c.defaultView.getComputedStyle(a, null))
        ? a[b] || a.getPropertyValue(b) || ""
        : "";
    },
    Kl = function (a) {
      try {
        return a.getBoundingClientRect();
      } catch (b) {
        return { left: 0, top: 0, right: 0, bottom: 0 };
      }
    },
    Ll = function (a) {
      var b = il(a),
        c = new Qk(0, 0);
      if (a == (b ? il(b) : document).documentElement) return c;
      a = Kl(a);
      b = xl(jl(b));
      c.x = a.left + b.x;
      c.y = a.top + b.y;
      return c;
    },
    Ml = function (a, b) {
      var c = new Qk(0, 0),
        d = ol(il(a));
      if (!xc(d, "parent")) return c;
      do {
        if (d == b) var e = Ll(a);
        else (e = Kl(a)), (e = new Qk(e.left, e.top));
        c.x += e.x;
        c.y += e.y;
      } while (
        d &&
        d != b &&
        d != d.parent &&
        (a = d.frameElement) &&
        (d = d.parent)
      );
      return c;
    },
    Nl = function () {
      var a = "100%";
      typeof a == "number" && (a = Math.round(a) + "px");
      return a;
    },
    Pl = function (a) {
      var b = Ol,
        c;
      (c = Jl(a, "display")) ||
        (c = a.currentStyle ? a.currentStyle.display : null);
      if ((c || (a.style && a.style.display)) != "none") return b(a);
      c = a.style;
      var d = c.display,
        e = c.visibility,
        f = c.position;
      c.visibility = "hidden";
      c.position = "absolute";
      c.display = "inline";
      a = b(a);
      c.display = d;
      c.position = f;
      c.visibility = e;
      return a;
    },
    Ol = function (a) {
      var b = a.offsetWidth,
        c = a.offsetHeight,
        d = Ec && !b && !c;
      return (b === void 0 || d) && a.getBoundingClientRect
        ? ((a = Kl(a)), new Rk(a.right - a.left, a.bottom - a.top))
        : new Rk(b, c);
    },
    Ql = function (a) {
      var b = new Rk(a.offsetWidth, a.offsetHeight);
      var c = Jl(a, "paddingLeft");
      var d = Jl(a, "paddingRight"),
        e = Jl(a, "paddingTop"),
        f = Jl(a, "paddingBottom");
      c = new L(parseFloat(e), parseFloat(d), parseFloat(f), parseFloat(c));
      d = Jl(a, "borderLeftWidth");
      e = Jl(a, "borderRightWidth");
      f = Jl(a, "borderTopWidth");
      a = Jl(a, "borderBottomWidth");
      a = new L(parseFloat(f), parseFloat(e), parseFloat(a), parseFloat(d));
      return new Rk(
        b.width - a.left - c.left - c.right - a.right,
        b.height - a.top - c.top - c.bottom - a.bottom
      );
    };
  var Rl = Mj(function () {
    var a = !1;
    try {
      var b = Object.defineProperty({}, "passive", {
        get: function () {
          a = !0;
        },
      });
      C.addEventListener("test", null, b);
    } catch (c) {}
    return a;
  });
  function Sl(a) {
    return a ? (a.passive && Rl() ? a : a.capture || !1) : !1;
  }
  function Tl(a, b, c, d) {
    return typeof a.addEventListener === "function"
      ? (a.addEventListener(b, c, Sl(d)), !0)
      : !1;
  }
  function Ul(a, b, c) {
    typeof a.removeEventListener === "function" &&
      a.removeEventListener(b, c, Sl());
  }
  function Vl(a, b, c, d, e) {
    Wl(
      a,
      b,
      c === void 0 ? null : c,
      d === void 0 ? !1 : d,
      e === void 0 ? !1 : e
    );
  }
  function Wl(a, b, c, d, e) {
    e = e === void 0 ? !1 : e;
    a.google_image_requests || (a.google_image_requests = []);
    var f = Pk("IMG", a.document);
    if (c || d) {
      var g = function (h) {
        c && c(h);
        d && lc(a.google_image_requests, f);
        Ul(f, "load", g);
        Ul(f, "error", g);
      };
      Tl(f, "load", g);
      Tl(f, "error", g);
    }
    e && (f.attributionSrc = "");
    f.src = b;
    a.google_image_requests.push(f);
  }
  function Xl(a) {
    var b = b === void 0 ? !1 : b;
    var c;
    if ((c = C.navigator))
      (c = C.navigator.userAgent), (c = !(!/Chrome/.test(c) || /Edge/.test(c)));
    c && typeof C.navigator.sendBeacon === "function"
      ? C.navigator.sendBeacon(a)
      : Vl(C, a, void 0, b);
  }
  function Yl(a) {
    a = (a === void 0 ? {} : a).sh;
    return (a === void 0 ? 0 : a)
      ? "connect.pagead2.googlesyndication.com"
      : "pagead2.googlesyndication.com";
  }
  function Zl(a, b) {
    var c = {};
    var d = c.hn;
    d = d === void 0 ? !1 : d;
    c = c.sh;
    var e =
      "https://" +
      Yl({ sh: c === void 0 ? !1 : c }) +
      "/pagead/gen_204?id=" +
      b;
    Ij(a, function (f, g) {
      if (f || f === 0) e += "&" + g + "=" + encodeURIComponent(String(f));
    });
    $l(e, d);
  }
  function $l(a, b) {
    var c = window;
    b = b === void 0 ? !1 : b;
    var d = d === void 0 ? !1 : d;
    c.fetch
      ? ((b = {
          keepalive: !0,
          credentials: "include",
          redirect: "follow",
          method: "get",
          mode: "no-cors",
        }),
        d &&
          ((b.mode = "cors"),
          "setAttributionReporting" in XMLHttpRequest.prototype
            ? (b.attributionReporting = {
                eventSourceEligible: "true",
                triggerEligible: "false",
              })
            : (b.headers = {
                "Attribution-Reporting-Eligible": "event-source",
              })),
        c.fetch(a, b))
      : Vl(c, a, void 0, b, d);
  }
  function am(a, b) {
    try {
      var c = function (d) {
        var e = {};
        return [((e[d.Bf] = d.Te), e)];
      };
      return JSON.stringify([
        a
          .filter(function (d) {
            return d.Od;
          })
          .map(c),
        Of(b),
        a
          .filter(function (d) {
            return !d.Od;
          })
          .map(c),
      ]);
    } catch (d) {
      return bm(d, b), "";
    }
  }
  function bm(a, b) {
    try {
      Zl(
        {
          m: Hj(a instanceof Error ? a : Error(String(a))),
          b: Zg(b, 1) || null,
          v: Yg(b, 2) || null,
        },
        "rcs_internal"
      );
    } catch (c) {}
  }
  var cm = function (a, b, c) {
      this.D = c;
      c = new Ej();
      a = jh(c, 1, a);
      this.l = wg(a, 2, hf(b), "");
    },
    dm = function (a) {
      if (a.D) {
        var b = a.l,
          c = [],
          d = c.concat,
          e = Set,
          f = [],
          g = f.concat;
        var h = pg(a.l, 3, Ve);
        c = d.call(c, ra(new e(g.call(f, ra(h), ra(a.D())))));
        vg(b, 3, c, Ue);
      }
      a = a.l;
      b = a.G;
      c = b[H] | 0;
      return Pd(a, c)
        ? a
        : $f(a, b, c)
        ? Zf(a, b)
        : new a.constructor(Yf(b, c, !0));
    };
  function em(a) {
    var b = new CompressionStream("gzip"),
      c = new Response(b.readable).arrayBuffer(),
      d = b.writable.getWriter(),
      e = typeof a === "string" ? new TextEncoder().encode(a) : a;
    return d.ready
      .then(function () {
        return d.write(e);
      })
      .then(function () {
        return d.close();
      })
      .then(function () {
        return c;
      })
      .then(function (f) {
        return new Uint8Array(f);
      });
  }
  var fm = function (a) {
    this.G = I(a);
  };
  w(fm, K);
  var gm = function (a) {
    this.G = I(a);
  };
  w(gm, K);
  var hm = function (a, b) {
      return jh(a, 1, b);
    },
    im = function (a, b) {
      return jh(a, 2, b);
    };
  var jm = function (a) {
    this.G = I(a);
  };
  w(jm, K);
  var km = [1, 2];
  var lm = function (a) {
    this.G = I(a);
  };
  w(lm, K);
  var mm = function (a, b) {
      return Mg(a, 1, b);
    },
    nm = function (a, b) {
      return Og(a, 2, b);
    },
    om = function (a, b) {
      return vg(a, 4, b, Ue);
    },
    pm = function (a, b) {
      return Og(a, 5, b);
    },
    qm = function (a, b) {
      return jh(a, 6, b);
    };
  var rm = function (a) {
    this.G = I(a);
  };
  w(rm, K);
  var sm = [1, 2, 3, 4, 6, 7];
  var tm = function (a) {
    this.G = I(a);
  };
  w(tm, K);
  var um = function (a) {
    this.G = I(a);
  };
  w(um, K);
  var vm = [2, 3, 4];
  var wm = function (a) {
    this.G = I(a);
  };
  w(wm, K);
  var xm = [3, 4, 5],
    ym = [6, 7];
  var zm = function (a) {
    this.G = I(a);
  };
  w(zm, K);
  var Am = [4, 5];
  var Bm = function (a) {
    this.G = I(a);
  };
  w(Bm, K);
  Bm.prototype.getTagSessionCorrelator = function () {
    return Wg(this, 2);
  };
  var Dm = function (a) {
      var b = new Bm();
      return Ng(b, 4, Cm, a);
    },
    Cm = [4, 5, 7, 8, 9];
  var Em = function (a) {
    this.G = I(a);
  };
  w(Em, K);
  var Fm = function (a) {
    this.G = I(a);
  };
  w(Fm, K);
  var Gm = function (a) {
    this.G = I(a);
  };
  w(Gm, K);
  var Hm = function (a) {
    this.G = I(a);
  };
  w(Hm, K);
  Hm.prototype.Gb = function () {
    return Ig(this, Fm, 1);
  };
  Hm.prototype.getSize = function () {
    return Ig(this, Gm, 2);
  };
  Hm.prototype.getDuration = function () {
    return Ig(this, Em, 3);
  };
  var Im = function (a) {
    this.G = I(a);
  };
  w(Im, K);
  var Jm = function (a, b) {
      return gh(a, 1, b);
    },
    Km = function (a, b) {
      return gh(a, 2, b);
    };
  var Lm = function (a) {
    this.G = I(a);
  };
  w(Lm, K);
  var Mm = function (a) {
    this.G = I(a);
  };
  w(Mm, K);
  Mm.prototype.getType = function () {
    return Ug(this, 5);
  };
  var Nm = function (a, b) {
    return dh(a, 5, b);
  };
  Mm.prototype.getValue = function () {
    return Wg(this, 2);
  };
  var Om = function (a, b) {
    return fh(a, 2, b);
  };
  Mm.prototype.clearValue = function () {
    return jg(this, 2);
  };
  Mm.prototype.getDuration = function () {
    return Wg(this, 6);
  };
  var Pm = [1, 8, 9, 11];
  var Qm = function (a) {
    this.G = I(a);
  };
  w(Qm, K);
  var Rm = function (a, b) {
    fh(a, 24, b);
  };
  var Sm = function (a) {
    this.G = I(a);
  };
  w(Sm, K);
  Sm.prototype.getName = function () {
    return Yg(this, 1);
  };
  var Tm = function (a, b) {
    return hh(a, 1, b);
  };
  Sm.prototype.getValue = function () {
    return Yg(this, 2);
  };
  var Um = function (a, b) {
    return hh(a, 2, b);
  };
  Sm.prototype.clearValue = function () {
    return jg(this, 2);
  };
  var Vm = function (a) {
    this.G = I(a);
  };
  w(Vm, K);
  Vm.prototype.getSlotId = function () {
    return Ug(this, 22);
  };
  var Wm = function (a, b) {
    return dh(a, 22, b);
  };
  Vm.prototype.l = function () {
    return Kg(this, Sm, 28);
  };
  Vm.prototype.A = function (a) {
    Og(this, 28, a);
  };
  Vm.prototype.j = function (a) {
    Qg(this, 28, Sm, a);
  };
  var Xm = function (a) {
    this.G = I(a);
  };
  w(Xm, K);
  Xm.prototype.getCorrelator = function () {
    return Yg(this, 1);
  };
  Xm.prototype.setCorrelator = function (a) {
    return hh(this, 1, a);
  };
  var Ym = function (a, b) {
      Qg(a, 2, Mm, b);
    },
    Zm = function (a) {
      return Dg(a, Qm, 12);
    },
    $m = function (a) {
      return Kg(a, Vm, 3);
    },
    an = function (a, b) {
      Qg(a, 3, Vm, b);
    };
  Xm.prototype.l = function () {
    return Kg(this, Sm, 11);
  };
  Xm.prototype.A = function (a) {
    Og(this, 11, a);
  };
  Xm.prototype.j = function (a) {
    Qg(this, 11, Sm, a);
  };
  var bn = function (a) {
    this.G = I(a);
  };
  w(bn, K);
  bn.prototype.getTagSessionCorrelator = function () {
    return Wg(this, 2);
  };
  var cn = [6, 7];
  var dn = function () {
    cm.apply(this, arguments);
  };
  w(dn, cm);
  var en = function () {
    dn.apply(this, arguments);
  };
  w(en, dn);
  en.prototype.ge = function () {
    this.o.apply(
      this,
      ra(
        La.apply(0, arguments).map(function (a) {
          return { Od: !0, Bf: 4, Te: Of(a) };
        })
      )
    );
  };
  en.prototype.Zj = function () {
    this.o.apply(
      this,
      ra(
        La.apply(0, arguments).map(function (a) {
          return { Od: !0, Bf: 30, Te: Of(a) };
        })
      )
    );
  };
  en.prototype.ak = function () {
    this.o.apply(
      this,
      ra(
        La.apply(0, arguments).map(function (a) {
          return { Od: !0, Bf: 37, Te: Of(a) };
        })
      )
    );
  };
  function fn(a, b) {
    if (globalThis.fetch)
      globalThis
        .fetch(a, {
          method: "POST",
          body: b,
          keepalive: b.length < 65536,
          credentials: "omit",
          mode: "no-cors",
          redirect: "follow",
        })
        .catch(function () {});
    else {
      var c = new XMLHttpRequest();
      c.open("POST", a, !0);
      c.send(b);
    }
  }
  function gn(a, b, c, d) {
    c = c === void 0 ? 1 : c;
    if (d === void 0 ? 0 : d) {
      d = typeof CompressionStream === "function";
      var e = b.length > 1024;
      typeof document !== "undefined" &&
      document.visibilityState !== "hidden" &&
      d &&
      e
        ? em(b)
            .then(function (f) {
              var g = c === 1 ? 5 : 6;
              f = Xc(f);
              fn(a + "?e=" + g, f);
            })
            .catch(function () {
              fn(a + "?e=" + c, b);
            })
        : fn(a + "?e=" + c, b);
    } else fn(a + "?e=" + c, b);
  }
  var hn = function (a, b, c, d, e, f, g, h, k) {
    en.call(this, a, b, k);
    this.H = c;
    this.N = d;
    this.V = e;
    this.C = f;
    this.F = g;
    this.A = h;
    this.h = [];
    this.j = null;
    this.B = !1;
  };
  w(hn, en);
  var jn = function (a) {
    a.j !== null && (clearTimeout(a.j), (a.j = null));
    if (a.h.length) {
      var b = am(a.h, dm(a));
      a.N(a.H, b, 1, !1);
      a.h = [];
    }
  };
  hn.prototype.o = function () {
    var a = La.apply(0, arguments),
      b = this;
    try {
      this.F && am(this.h.concat(a), dm(this)).length >= 65536 && jn(this),
        this.A &&
          !this.B &&
          ((this.B = !0),
          this.A.h(function () {
            jn(b);
          })),
        this.h.push.apply(this.h, ra(a)),
        this.h.length >= this.C && jn(this),
        this.h.length &&
          this.j === null &&
          (this.j = setTimeout(function () {
            jn(b);
          }, this.V));
    } catch (c) {
      bm(c, dm(this));
    }
  };
  var kn = function (a, b, c, d, e, f, g) {
    hn.call(
      this,
      a,
      b,
      "https://pagead2.googlesyndication.com/pagead/ping",
      gn,
      c === void 0 ? 1e3 : c,
      d === void 0 ? 100 : d,
      (e === void 0 ? !1 : e) && !!globalThis.fetch,
      f,
      g
    );
  };
  w(kn, hn);
  var ln = function () {
    this.l = !1;
  };
  n = ln.prototype;
  n.disable = function () {};
  n.Rc = function () {};
  n.P = function () {};
  n.Vf = function () {};
  n.wg = function () {};
  n.Nb = function () {};
  n.yf = function () {
    return !1;
  };
  n.kf = function () {};
  function mn(a) {
    a = a === void 0 ? C : a;
    var b = a.context || a.AMP_CONTEXT_DATA;
    if (!b)
      try {
        b = a.parent.context || a.parent.AMP_CONTEXT_DATA;
      } catch (e) {}
    var c, d;
    return ((c = b) == null ? 0 : c.pageViewId) &&
      ((d = b) == null ? 0 : d.canonicalUrl)
      ? b
      : null;
  }
  var nn = function () {
      this.S = {};
    },
    on = function () {
      var a = mn(window);
      if (a) {
        if (a) {
          var b = a.pageViewId;
          a = a.clientId;
          ae(a) && (b += a.replace(/\D/g, "").substring(0, 6));
        } else b = null;
        return +b;
      }
      b = Kj(window);
      a = b.google_global_correlator;
      a ||
        (b.google_global_correlator = a =
          1 + Math.floor(Math.random() * 8796093022208));
      return a;
    },
    qn = function (a, b) {
      var c = pn[7] || "google_ps_7";
      a = a.S;
      var d = a[c];
      return d === void 0 ? ((a[c] = b()), a[c]) : d;
    },
    rn = function (a) {
      var b = on();
      return qn(a, function () {
        return b;
      });
    },
    tn = function () {
      if (sn) var a = sn;
      else {
        a =
          ((a = a === void 0 ? mn() : a)
            ? Jj(a.master)
              ? a.master
              : null
            : null) || window;
        var b = a.google_persistent_state_async;
        a =
          b != null &&
          typeof b == "object" &&
          b.S != null &&
          typeof b.S == "object"
            ? (sn = b)
            : (a.google_persistent_state_async = sn = new nn());
      }
      return rn(a);
    },
    sn = null,
    un = {},
    pn =
      ((un[8] = "google_prev_ad_formats_by_region"),
      (un[9] = "google_prev_ad_slotnames_by_region"),
      un);
  var vn = ua(["https://pagead2.googlesyndication.com/pagead/js/err_rep.js"]),
    wn = function () {
      var a = a === void 0 ? "jserror" : a;
      var b = b === void 0 ? 0.01 : b;
      var c = c === void 0 ? Jk(vn) : c;
      this.j = a;
      this.l = b;
      this.o = c;
      this.h = !1;
    };
  wn.prototype.wf = function (a) {
    this.h = a;
  };
  wn.prototype.lb = function (a, b, c, d) {
    c = c === void 0 ? this.l : c;
    d = d === void 0 ? this.j : d;
    if (Math.random() > c) return this.h;
    Gj(b) || (b = new Fj(b, { context: a, id: d }));
    C.google_js_errors = C.google_js_errors || [];
    C.google_js_errors.push(b);
    C.error_rep_loaded ||
      ((b = C.document),
      (a = Pk("SCRIPT", b)),
      lk(a, this.o),
      (b = b.getElementsByTagName("script")[0]) &&
        b.parentNode &&
        b.parentNode.insertBefore(a, b),
      (C.error_rep_loaded = !0));
    return this.h;
  };
  wn.prototype.bc = function (a, b) {
    try {
      return b();
    } catch (c) {
      if (!this.lb(a, c, this.l, this.j)) throw c;
    }
  };
  wn.prototype.jf = function (a, b, c) {
    var d = this;
    return function () {
      var e = La.apply(0, arguments);
      return d.bc(a, function () {
        return b.apply(c, e);
      });
    };
  };
  function xn(a) {
    if (a.prerendering) return 3;
    var b;
    return (b = {
      visible: 1,
      hidden: 2,
      prerender: 3,
      preview: 4,
      unloaded: 5,
      "": 0,
    }[
      a.visibilityState || a.webkitVisibilityState || a.mozVisibilityState || ""
    ]) != null
      ? b
      : 0;
  }
  function yn(a) {
    var b;
    a.visibilityState
      ? (b = "visibilitychange")
      : a.mozVisibilityState
      ? (b = "mozvisibilitychange")
      : a.webkitVisibilityState && (b = "webkitvisibilitychange");
    return b;
  }
  var zn = null,
    An = function () {
      var a = a === void 0 ? window : a;
      if (zn === null) {
        zn = "";
        try {
          var b = "";
          try {
            b = a.top.location.hash;
          } catch (d) {
            b = a.location.hash;
          }
          if (b) {
            var c = b.match(/\bdeid=([\d,]+)/);
            zn = c ? c[1] : "";
          }
        } catch (d) {}
      }
      return zn;
    };
  function Bn() {
    var a = a === void 0 ? C : a;
    return (a = a.performance) && a.now && a.timing
      ? Math.floor(a.now() + a.timing.navigationStart)
      : Date.now();
  }
  function Cn() {
    var a = a === void 0 ? C : a;
    return (a = a.performance) && a.now ? a.now() : null;
  }
  function Dn(a, b) {
    b = b === void 0 ? C : b;
    var c, d;
    return (
      ((c = b.performance) == null
        ? void 0
        : (d = c.timing) == null
        ? void 0
        : d[a]) || 0
    );
  }
  function En() {
    var a = a === void 0 ? C : a;
    var b = Math.min(
      Dn("domLoading", a) || Infinity,
      Dn("domInteractive", a) || Infinity
    );
    return b === Infinity
      ? Math.max(Dn("responseEnd", a), Dn("navigationStart", a))
      : b;
  }
  var Fn = function (a, b, c, d) {
    d = d === void 0 ? 0 : d;
    this.label = a;
    this.type = b;
    this.value = c;
    this.duration = d;
    this.taskId = this.slotId = void 0;
    this.uniqueId = Math.random();
  };
  var Gn = C.performance,
    Hn = !!(Gn && Gn.mark && Gn.measure && Gn.clearMarks),
    In = Mj(function () {
      var a;
      if ((a = Hn)) (a = An()), (a = !!a.indexOf && a.indexOf("1337") >= 0);
      return a;
    }),
    Jn = function (a, b) {
      this.events = [];
      this.h = b || C;
      var c = null;
      b &&
        ((b.google_js_reporting_queue = b.google_js_reporting_queue || []),
        (this.events = b.google_js_reporting_queue),
        (c = b.google_measure_js_timing));
      this.l = In() || (c != null ? c : Math.random() < a);
    };
  Jn.prototype.disable = function () {
    this.l = !1;
    this.events !== this.h.google_js_reporting_queue &&
      (In() && Zb(this.events, Kn), (this.events.length = 0));
  };
  Jn.prototype.H = function (a) {
    !this.l || this.events.length > 2048 || this.events.push(a);
  };
  var Kn = function (a) {
    a &&
      Gn &&
      In() &&
      (Gn.clearMarks("goog_" + a.label + "_" + a.uniqueId + "_start"),
      Gn.clearMarks("goog_" + a.label + "_" + a.uniqueId + "_end"));
  };
  Jn.prototype.kf = function (a, b, c) {
    this.l && this.H(new Fn(a, b, c, 0));
  };
  Jn.prototype.start = function (a, b) {
    if (!this.l) return null;
    a = new Fn(a, b, Cn() || Bn());
    b = "goog_" + a.label + "_" + a.uniqueId + "_start";
    Gn && In() && Gn.mark(b);
    return a;
  };
  Jn.prototype.end = function (a) {
    if (this.l && $d(a.value)) {
      a.duration = (Cn() || Bn()) - a.value;
      var b = "goog_" + a.label + "_" + a.uniqueId + "_end";
      Gn && In() && Gn.mark(b);
      this.H(a);
    }
  };
  function Ln(a) {
    a = a._google_rum_ns_ = a._google_rum_ns_ || {};
    return (a.pq = a.pq || []);
  }
  function Mn(a, b, c) {
    Ij(b, function (d, e) {
      var f = c && c[e];
      (!d && d !== 0) ||
        f ||
        ((a +=
          "&" + encodeURIComponent(e) + "=" + encodeURIComponent(String(d))),
        c && (c[e] = !0));
    });
    return a;
  }
  function Nn(a, b, c, d) {
    d = d === void 0 ? !0 : d;
    var e = a.l();
    if (!d) {
      var f = e.findIndex(function (g) {
        return g.getName() === b;
      });
      if (f !== -1) {
        Um(e[f], c);
        c = e.filter(function (g, h) {
          return h <= f || g.getName() !== b;
        });
        a.A(c);
        return;
      }
    }
    a.j(Um(Tm(new Sm(), b), c));
  }
  function On(a, b, c, d) {
    d = d === void 0 ? !0 : d;
    if (b !== "ec")
      switch (b) {
        case "c":
          a.setCorrelator(c);
          break;
        case "e":
          c.split(",")
            .map(Number)
            .filter(function (h) {
              return !isNaN(h);
            })
            .forEach(function (h) {
              Pg(a, 7, Ue, h, Ve);
            });
          break;
        default:
          var e = b.lastIndexOf(".");
          if (e !== -1) {
            var f = b.substring(0, e);
            e = b.substring(e + 1);
            if (e !== "") {
              var g = Number(e);
              if (!isNaN(g)) {
                b = $m(a).find(function (h) {
                  return h.getSlotId() === g;
                });
                b || ((b = Wm(new Vm(), g)), an(a, b));
                f === "qqid" ? hh(b, 63, c) : Nn(b, f, c, d);
                break;
              }
            }
          }
          Nn(a, b, c, d);
      }
  }
  var Wn = function (a, b, c, d, e, f, g, h) {
    f = f === void 0 ? Infinity : f;
    g = g === void 0 ? !1 : g;
    Jn.call(this, a, h);
    var k = this;
    this.protocol = b;
    this.domain = c;
    this.path = d;
    this.T = e;
    this.F = 0;
    this.D = {};
    this.J = {};
    this.ba = [];
    this.report = {};
    this.j = 0;
    this.B = [];
    this.K = f;
    this.namespace = (a = (this.path + this.T).match(/[?&]s=([^&]*)/))
      ? a[1]
      : "";
    a = this.h.navigator;
    this.Y = !(this.domain !== "csi.gstatic.com" || !a || !a.sendBeacon);
    (this.h.performance && this.h.performance.now) || this.Nb("dat", 1);
    a && a.deviceMemory && this.Nb("dmc", a.deviceMemory);
    this.h === this.h.top && this.Nb("top", 1);
    this.W = !g;
    this.O = function () {
      k.h.setTimeout(function () {
        k.o();
      }, 1100);
    };
    this.R = function () {
      var m = y(k.ba),
        p = m.next();
      try {
        for (; !p.done; p = m.next()) {
          var q = p.value;
          try {
            q();
          } catch (t) {}
        }
      } finally {
        z(m, p);
      }
      m = k.h;
      var r = r === void 0 ? {} : r;
      typeof window.CustomEvent === "function"
        ? (p = new CustomEvent("rum_blp", r))
        : ((p = document.createEvent("CustomEvent")),
          p.initCustomEvent("rum_blp", !!r.bubbles, !!r.cancelable, r.detail));
      m.dispatchEvent(p);
      k.o();
      k.N instanceof hn && jn(k.N);
    };
    this.da = Oj(function () {
      k.o();
    });
    this.fa = function () {
      var m = k.h.document;
      (m.hidden != null
        ? m.hidden
        : m.mozHidden != null
        ? m.mozHidden
        : m.webkitHidden != null && m.webkitHidden) && k.da();
    };
    this.V = this.h.setTimeout(function () {
      k.o();
    }, 5e3);
    this.A = b.length + c.length + d.length + e.length + 3;
    Zb(this.events, function (m) {
      Pn(k) && Qn(k, m);
      Rn(k) && Sn(k, m);
    });
    b = Ln(this.h);
    var l = function () {
      var m = La.apply(0, arguments)[0],
        p = m[0];
      m = m[1];
      var q = p.length + m.length + 2;
      Pn(k) && k.A + k.j + q > 8e3 && k.o();
      k.B.push([p, m]);
      Pn(k) && ((k.j += q), Tn(k));
      return 0;
    };
    Zb(b, function (m) {
      return l(m);
    });
    b.length = 0;
    b.push = l;
    Un(this);
    Vn(this);
  };
  w(Wn, Jn);
  var Vn = function (a) {
    a.h.document.readyState === "complete"
      ? a.h.setTimeout(function () {
          a.o();
        }, 0)
      : Tl(a.h, "load", a.O);
    var b = yn(a.h.document);
    typeof b !== "undefined" && Tl(a.h, b, a.fa);
    Tl(a.h, "pagehide", a.R);
  };
  n = Wn.prototype;
  n.Nb = function (a, b) {
    b = String(b);
    this.A =
      this.D[a] != null
        ? this.A + (b.length - this.D[a].length)
        : this.A + (a.length + b.length + 2);
    this.D[a] = b;
  };
  n.wg = function (a) {
    return this.D[a];
  };
  n.Vf = function (a) {
    var b = 0;
    if (Pn(this)) {
      var c = !1,
        d = y(Object.keys(a)),
        e = d.next();
      try {
        for (; !e.done; e = d.next()) {
          var f = e.value;
          this.report[f] != null && (c = !0);
          b += Xn(this, f, a[f], !1);
        }
      } finally {
        z(d, e);
      }
      (this.A + this.j + b > 8e3 || c) && this.o();
    }
    c = y(Object.keys(a));
    d = c.next();
    try {
      for (; !d.done; d = c.next()) {
        var g = d.value;
        Pn(this) && Yn(this, g, a[g], !1);
        Rn(this) && g !== "ec" && On(Zn(this), g, a[g], !1);
      }
    } finally {
      z(c, d);
    }
    Pn(this) && ((this.j += b), Tn(this));
  };
  n.P = function (a, b) {
    var c = a + "=" + b;
    this.J[c] ||
      (Rn(this) && a !== "ec" && On(Zn(this), a, b, !1),
      Pn(this) && $n(this, a, b, !1),
      c.length < 1e3 && (this.J[c] = !0));
  };
  n.yf = function () {
    return this.l && this.W;
  };
  var $n = function (a, b, c, d, e) {
      e = e === void 0 ? "" : e;
      var f = Xn(a, b, c, d, e);
      a.A + a.j + f > 8e3 && (a.o(), (f = b.length + c.length + 2));
      Yn(a, b, c, d, e);
      a.j += f;
      Tn(a);
    },
    Xn = function (a, b, c, d, e) {
      return a.report[b] == null
        ? b.length + c.length + 2
        : d
        ? c.length + (e === void 0 ? "" : e).length
        : c.length - a.report[b].length;
    },
    Yn = function (a, b, c, d, e) {
      a.report[b] =
        d && a.report[b] != null
          ? a.report[b] + ("" + (e === void 0 ? "" : e) + c)
          : c;
    },
    Tn = function (a) {
      a.A + a.j >= 6e3 && a.o();
    };
  Wn.prototype.o = function () {
    if (this.yf()) {
      var a = new wn();
      if (Rn(this))
        try {
          ao(this);
        } catch (b) {
          a.lb(358, b);
        }
      if (Pn(this)) {
        try {
          this.j && this.sendBeacon(this.report);
        } catch (b) {
          a.lb(358, b);
        }
        this.report = {};
        this.j = 0;
      }
      this.F === this.K && this.disable();
      this.events.length = 0;
      this.h.clearTimeout(this.V);
      this.V = 0;
    }
  };
  var bo = function (a, b) {
    var c = a.protocol + "//" + a.domain + a.path + a.T,
      d = {};
    c = Mn(c, a.D, d);
    c = Mn(c, b, d);
    b = a.h;
    b.google_timing_params &&
      ((c = Mn(c, b.google_timing_params, d)),
      (b.google_timing_params = void 0));
    Zb(a.B, function (e) {
      var f = y(e);
      e = f.next().value;
      f = f.next().value;
      var g = {};
      c = Mn(c, ((g[e] = f), g));
    });
    a.B.length = 0;
    return c;
  };
  Wn.prototype.sendBeacon = function (a) {
    this.F++;
    a = bo(this, a);
    var b = !1;
    try {
      b = !!(
        this.Y &&
        this.h.navigator &&
        this.h.navigator.sendBeacon(a, null)
      );
    } catch (c) {
      this.Y = !1;
    }
    b || Vl(this.h, a);
    Un(this);
  };
  var Un = function (a) {
      a.Nb("puid", (a.F + 1).toString(36) + "~" + Date.now().toString(36));
    },
    Qn = function (a, b) {
      var c = "met." + b.type,
        d = $d(b.value) ? Math.round(b.value).toString(36) : b.value,
        e = Math.round(b.duration);
      $n(
        a,
        c,
        "" +
          b.label +
          (b.slotId != null ? "_" + b.slotId : "") +
          ("." + d) +
          (e > 0 ? "_" + e.toString(36) : "") +
          (b.taskId != null ? "__" + Math.round(b.taskId).toString(36) : ""),
        !0,
        "~"
      );
    };
  Wn.prototype.H = function (a) {
    this.l &&
      this.F < this.K &&
      (Jn.prototype.H.call(this, a),
      Pn(this) && Qn(this, a),
      Rn(this) && Sn(this, a));
  };
  Wn.prototype.Rc = function () {
    this.W = !0;
    this.o();
  };
  Wn.prototype.disable = function () {
    Jn.prototype.disable.call(this);
    this.h.clearTimeout(this.V);
    this.j = this.V = 0;
    this.report = {};
    this.C = void 0;
    dl(this.J);
    dl(this.D);
    Ul(this.h, "load", this.O);
    Ul(this.h, "pagehide", this.R);
  };
  var Rn = function (a) {
      return a.namespace === "pagead";
    },
    Pn = function (a) {
      return a.namespace !== "pagead";
    },
    co = function (a) {
      if (!a.N) {
        var b = a.h;
        b.google_rum_rcs_pinger ||
          (b.google_rum_rcs_pinger = new kn(19, "1.0"));
        a.N = b.google_rum_rcs_pinger;
      }
      return a.N;
    },
    Zn = function (a) {
      a.C || (a.C = new Xm());
      return a.C;
    },
    Sn = function (a, b) {
      var c = Om(Nm(new Mm(), b.type), Math.round(Number(b.value)));
      a.namespace && hh(c, 3, a.namespace);
      isFinite(b.duration) && fh(c, 6, Math.round(b.duration));
      b.taskId != null && fh(c, 13, b.taskId);
      var d = Number(b.label),
        e = isFinite(d);
      switch (b.type) {
        case 1:
          d === 24 && Rm(Zm(Zn(a)), Math.round(Number(b.value)));
          return;
        case 3:
        case 13:
          e
            ? Ag(c, 9, Pm, d == null ? d : Ue(d))
            : Ag(c, 1, Pm, hf(String(b.label)));
          break;
        case 2:
          e
            ? Ag(c, 8, Pm, d == null ? d : Ue(d))
            : Ag(c, 1, Pm, hf(String(b.label)));
          break;
        case 9:
          e
            ? Ag(c, 11, Pm, d == null ? d : Ue(d))
            : Ag(c, 1, Pm, hf(String(b.label)));
          break;
        default:
          Ag(c, 1, Pm, hf(String(b.label)));
      }
      b.slotId != null
        ? ((d = $m(Zn(a)).find(function (f) {
            return f.getSlotId() === b.slotId;
          })),
          d || ((d = Wm(new Vm(), b.slotId)), an(Zn(a), d)),
          Qg(d, 2, Mm, c))
        : Ym(Zn(a), c);
    },
    ao = function (a) {
      var b = a.h,
        c = b.google_timing_params;
      if (!a.C) {
        var d =
            c &&
            Object.keys(c).some(function (g) {
              var h = c[g];
              return g !== "ec" && (h || h === 0);
            }),
          e = a.B.some(function (g) {
            var h = y(g);
            g = h.next().value;
            h = h.next().value;
            return g !== "ec" && !!h;
          });
        if (!d && !e) return;
      }
      Pn(a) || a.F++;
      var f = Zn(a);
      Ij(a.D, function (g, h) {
        g && On(f, h, g);
      });
      c &&
        (Ij(c, function (g, h) {
          (g || g === 0) && On(f, h, String(g));
        }),
        Pn(a) || (b.google_timing_params = void 0));
      a.B.forEach(function (g) {
        var h = y(g);
        g = h.next().value;
        (h = h.next().value) && On(f, g, h);
      });
      Pn(a) || (a.B.length = 0);
      co(a).Zj(f);
      Pn(a) || Un(a);
      a.C = void 0;
    };
  var M = function (a) {
    var b = "Wb";
    if (a.Wb && a.hasOwnProperty(b)) return a.Wb;
    b = new a();
    return (a.Wb = b);
  };
  var N = function () {
    this.h =
      typeof window !== "undefined" && typeof window.document !== "undefined"
        ? new Wn(
            1,
            "https:",
            "pagead2.googlesyndication.com",
            "/pagead/gen_204?id=",
            "ima",
            void 0,
            !0
          )
        : new ln();
    var a = tn();
    a != null && this.h.Nb("c", a);
    a = Math.floor(Number(this.h.wg("c")) / 2);
    a != null && this.h.Nb("slotId", a);
    this.Qa = null;
  };
  N.prototype.Rc = function () {
    this.h.Rc();
  };
  N.prototype.o = function () {
    this.Rc();
  };
  N.prototype.P = function (a, b) {
    b != null && this.h.P(a, b);
  };
  var eo = function (a, b) {
    a.h.kf(b, 4, Bn() - 0);
  };
  N.prototype.recordClick = function (a, b, c, d) {
    for (
      var e = !1, f = "notag";
      d != null && d !== document.documentElement;

    ) {
      var g = void 0,
        h = void 0;
      if (
        ((g = d) == null ? 0 : g.getAttribute("data-ck-navigates")) ||
        ((h = d) == null ? 0 : h.getAttribute("data-ck-tag"))
      ) {
        g = f = void 0;
        e =
          (g =
            (f = d) == null ? void 0 : f.getAttribute("data-ck-navigates")) !=
          null
            ? g
            : !1;
        h = g = void 0;
        f =
          (h = (g = d) == null ? void 0 : g.getAttribute("data-ck-tag")) != null
            ? h
            : "notag";
        break;
      }
      g = void 0;
      d = (g = d.parentElement) != null ? g : void 0;
    }
    this.h.kf(a + "_" + b + "x" + c + "|" + e + "|" + f, 4, Bn());
  };
  N.getInstance = function () {
    return M(N);
  };
  function fo(a) {
    return /^\s*$/.test(a)
      ? !1
      : /^[\],:{}\s\u2028\u2029]*$/.test(
          a
            .replace(/\\["\\\/bfnrtu]/g, "@")
            .replace(
              /(?:"[^"\\\n\r\u2028\u2029\x00-\x08\x0a-\x1f]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?)[\s\u2028\u2029]*(?=:|,|]|}|$)/g,
              "]"
            )
            .replace(/(?:^|:|,)(?:[\s\u2028\u2029]*\[)+/g, "")
        );
  }
  var go = function (a) {
    try {
      return C.JSON.parse(a);
    } catch (b) {}
    a = String(a);
    if (fo(a))
      try {
        return eval("(" + a + ")");
      } catch (b) {}
    throw Error("Invalid JSON string: " + a);
  };
  function ho() {
    this.h = io;
  }
  ho.prototype.ha = function (a) {
    var b = [];
    jo(this, a, b);
    return b.join("");
  };
  var jo = function (a, b, c) {
      if (b == null) c.push("null");
      else {
        if (typeof b == "object") {
          if (Array.isArray(b)) {
            var d = b;
            b = d.length;
            c.push("[");
            for (var e = "", f = 0; f < b; f++)
              c.push(e),
                (e = d[f]),
                jo(a, a.h ? a.h.call(d, String(f), e) : e, c),
                (e = ",");
            c.push("]");
            return;
          }
          if (
            b instanceof String ||
            b instanceof Number ||
            b instanceof Boolean
          )
            b = b.valueOf();
          else {
            c.push("{");
            f = "";
            for (d in b)
              Object.prototype.hasOwnProperty.call(b, d) &&
                ((e = b[d]),
                typeof e != "function" &&
                  (c.push(f),
                  ko(d, c),
                  c.push(":"),
                  jo(a, a.h ? a.h.call(b, d, e) : e, c),
                  (f = ",")));
            c.push("}");
            return;
          }
        }
        switch (typeof b) {
          case "string":
            ko(b, c);
            break;
          case "number":
            c.push(isFinite(b) && !isNaN(b) ? String(b) : "null");
            break;
          case "boolean":
            c.push(String(b));
            break;
          case "function":
            c.push("null");
            break;
          default:
            throw Error("Unknown type: " + typeof b);
        }
      }
    },
    lo = {
      '"': '\\"',
      "\\": "\\\\",
      "/": "\\/",
      "\b": "\\b",
      "\f": "\\f",
      "\n": "\\n",
      "\r": "\\r",
      "\t": "\\t",
      "\v": "\\u000b",
    },
    mo = /\uffff/.test("\uffff")
      ? /[\\"\x00-\x1f\x7f-\uffff]/g
      : /[\\"\x00-\x1f\x7f-\xff]/g,
    ko = function (a, b) {
      b.push(
        '"',
        a.replace(mo, function (c) {
          var d = lo[c];
          d ||
            ((d = "\\u" + (c.charCodeAt(0) | 65536).toString(16).slice(1)),
            (lo[c] = d));
          return d;
        }),
        '"'
      );
    };
  var no = function (a) {
      this.o = a;
      this.l = null;
      this.h = "missing-id";
      this.j = !1;
    },
    po = function (a) {
      var b = null;
      try {
        b = a.o.getElementsByClassName("lima-exp-data");
      } catch (c) {
        return oo("missing-element", a.h), null;
      }
      if (b.length > 1) return oo("multiple-elements", a.h), null;
      b = b[0];
      return b ? b.innerHTML : (oo("missing-element", a.h), null);
    },
    ro = function () {
      var a = qo,
        b = po(a);
      if (b !== null)
        if (fo(b)) {
          var c = JSON.parse(b);
          b = c.experimentIds;
          var d = c.binaryIdentifier;
          c = c.adEventId;
          var e = typeof d === "string";
          if (typeof c === "string") {
            var f = N.getInstance();
            c != null && f.h.Nb("qqid", c);
          }
          e && (a.h = d);
          typeof b !== "string"
            ? oo("missing-flags", a.h)
            : (e || oo("missing-binary-id", a.h), (a.l = b));
        } else oo("invalid-json", a.h);
    };
  no.prototype.reset = function () {
    this.l = null;
    this.h = "missing-id";
    this.j = !1;
  };
  var so = function () {};
  so.prototype.fe = function (a) {
    a = y(a);
    var b = a.next();
    try {
      for (; !b.done; b = a.next()) {
        var c = 0,
          d = Math.floor(Math.random() * 1e3),
          e = y(b.value.h),
          f = e.next();
        try {
          for (; !f.done; f = e.next()) {
            var g = f.value;
            c += g.I;
            if (d < c) {
              g.selected = !0;
              break;
            }
          }
        } finally {
          z(e, f);
        }
      }
    } finally {
      z(a, b);
    }
  };
  var to = function (a) {
    this.h = a;
  };
  to.prototype.fe = function (a, b) {
    a = y(this.h);
    var c = a.next();
    try {
      for (; !c.done; c = a.next()) {
        var d = b.get(c.value);
        d && (d.selected = !0);
      }
    } finally {
      z(a, c);
    }
  };
  function uo(a, b) {
    var c = Kg(a, wm, 2);
    if (!c.length) return vo(a, b);
    a = Zg(a, 1);
    if (a === 1) {
      var d = uo(c[0], b);
      return d.success ? { success: !0, value: !d.value } : d;
    }
    c = cc(c, function (h) {
      return uo(h, b);
    });
    switch (a) {
      case 2:
        var e;
        return (e =
          (d = c.find(function (h) {
            return h.success && !h.value;
          })) != null
            ? d
            : c.find(function (h) {
                return !h.success;
              })) != null
          ? e
          : { success: !0, value: !0 };
      case 3:
        var f, g;
        return (g =
          (f = c.find(function (h) {
            return h.success && h.value;
          })) != null
            ? f
            : c.find(function (h) {
                return !h.success;
              })) != null
          ? g
          : { success: !0, value: !1 };
      default:
        return { success: !1, Ua: 3 };
    }
  }
  function vo(a, b) {
    var c = Bg(a.G, xm);
    a: {
      switch (c) {
        case 3:
          var d = $g(a, 3, xm);
          break a;
        case 4:
          d = $g(a, 4, xm);
          break a;
        case 5:
          d = $g(a, 5, xm);
          break a;
      }
      d = void 0;
    }
    if (!d) return { success: !1, Ua: 2 };
    b = (b = b[c]) && b[d];
    if (!b) return { success: !1, Dc: d, gd: c, Ua: 1 };
    try {
      var e = b.apply;
      var f = pg(a, 8, jf);
      var g = e.call(b, null, ra(f));
    } catch (h) {
      return { success: !1, Dc: d, gd: c, Ua: 2 };
    }
    e = Zg(a, 1);
    if (e === 4) return { success: !0, value: !!g };
    if (e === 5) return { success: !0, value: g != null };
    if (e === 12) a = Yg(a, Cg(a, ym, 7));
    else
      a: {
        switch (c) {
          case 4:
            a = Xg(a, Cg(a, ym, 6));
            break a;
          case 5:
            a = Yg(a, Cg(a, ym, 7));
            break a;
        }
        a = void 0;
      }
    if (a == null) return { success: !1, Dc: d, gd: c, Ua: 3 };
    if (e === 6) return { success: !0, value: g === a };
    if (e === 9)
      return { success: !0, value: g != null && Qb(String(g), a) === 0 };
    if (g == null) return { success: !1, Dc: d, gd: c, Ua: 4 };
    switch (e) {
      case 7:
        c = g < a;
        break;
      case 8:
        c = g > a;
        break;
      case 12:
        c = ae(a) && ae(g) && new RegExp(a).test(g);
        break;
      case 10:
        c = g != null && Qb(String(g), a) === -1;
        break;
      case 11:
        c = g != null && Qb(String(g), a) === 1;
        break;
      default:
        return { success: !1, Ua: 3 };
    }
    return { success: !0, value: c };
  }
  function wo(a, b) {
    return a
      ? b
        ? uo(a, b)
        : { success: !1, Ua: 1 }
      : { success: !0, value: !0 };
  }
  var Gg = function (a) {
    this.G = I(a);
  };
  w(Gg, K);
  var xo = function (a) {
    return pg(a, 4, jf);
  };
  var yo = function (a) {
    this.G = I(a);
  };
  w(yo, K);
  yo.prototype.getValue = function () {
    return Ig(this, Gg, 2);
  };
  yo.prototype.clearValue = function () {
    return jg(this, 2);
  };
  var zo = function (a) {
    this.G = I(a);
  };
  w(zo, K);
  var Ao = qj(zo),
    Bo = [1, 2, 3, 6, 7, 8];
  var Co = function (a, b, c, d) {
      d = d === void 0 ? new kn(6, "unknown", b) : d;
      this.ah = a;
      this.l = c;
      this.pinger = d;
      this.h = [];
      this.j = a > 0 && Dk() < 1 / a;
    },
    Eo = function (a, b, c, d, e, f) {
      if (a.j) {
        var g = im(hm(new gm(), b), c);
        b = qm(nm(mm(pm(om(new lm(), d), e), g), a.h.slice()), f);
        b = Dm(b);
        a.pinger.ge(Do(a, b));
        if (
          f === 1 ||
          f === 3 ||
          (f === 4 &&
            !a.h.some(function (h) {
              return Zg(h, 1) === Zg(g, 1) && Zg(h, 2) === c;
            }))
        )
          a.h.push(g), a.h.length > 100 && a.h.shift();
      }
    },
    Fo = function (a, b, c, d) {
      if (a.j) {
        var e = new fm();
        b = dh(e, 1, b);
        c = dh(b, 2, c);
        d = ih(c, 3, d);
        c = new Bm();
        d = Ng(c, 8, Cm, d);
        a.pinger.ge(Do(a, d));
      }
    },
    Go = function (a, b, c, d, e) {
      if (a.j) {
        var f = new zm();
        b = Mg(f, 1, b);
        c = ih(b, 2, c);
        d = dh(c, 3, d);
        if (e.gd === void 0) kh(d, 4, Am, e.Ua);
        else
          switch (e.gd) {
            case 3:
              c = new um();
              c = kh(c, 2, vm, e.Dc);
              e = ih(c, 1, e.Ua);
              Ng(d, 5, Am, e);
              break;
            case 4:
              c = new um();
              c = kh(c, 3, vm, e.Dc);
              e = ih(c, 1, e.Ua);
              Ng(d, 5, Am, e);
              break;
            case 5:
              (c = new um()),
                (c = kh(c, 4, vm, e.Dc)),
                (e = ih(c, 1, e.Ua)),
                Ng(d, 5, Am, e);
          }
        e = new Bm();
        e = Ng(e, 9, Cm, d);
        a.pinger.ge(Do(a, e));
      }
    },
    Do = function (a, b) {
      var c = Date.now();
      c = Number.isFinite(c) ? Math.round(c) : 0;
      b = gh(b, 1, c);
      c = Ok();
      b = gh(b, 2, c);
      return gh(b, 6, a.ah);
    };
  var Ho = function () {
    var a = {};
    this.bb = ((a[3] = {}), (a[4] = {}), (a[5] = {}), a);
  };
  var Io = /^true$/.test("false");
  function Jo(a, b) {
    switch (b) {
      case 1:
        return $g(a, 1, Bo);
      case 7:
        return $g(a, 7, Bo);
      case 2:
        return $g(a, 2, Bo);
      case 3:
        return $g(a, 3, Bo);
      case 6:
        return $g(a, 6, Bo);
      case 8:
        return $g(a, 8, Bo);
      default:
        return null;
    }
  }
  function Ko(a, b) {
    if (!a) return null;
    switch (b) {
      case 1:
        return Tg(a, 1);
      case 7:
        return Yg(a, 3);
      case 2:
        return Xg(a, 2);
      case 3:
        return Yg(a, 3);
      case 6:
        return xo(a);
      case 8:
        return xo(a);
      default:
        return null;
    }
  }
  var Lo = Mj(function () {
    if (!Io) return {};
    try {
      var a = a === void 0 ? window : a;
      try {
        var b = a.sessionStorage.getItem("GGDFSSK");
      } catch (c) {
        b = null;
      }
      if (b) return JSON.parse(b);
    } catch (c) {}
    return {};
  });
  function Mo(a, b, c, d) {
    var e = (d = d === void 0 ? 0 : d),
      f,
      g;
    M(No).l[e] =
      (g = (f = M(No).l[e]) == null ? void 0 : f.add(b)) != null
        ? g
        : new Set().add(b);
    e = Lo();
    if (e[b] != null) return e[b];
    b = Oo(d)[b];
    if (!b) return c;
    b = Ao(JSON.stringify(b));
    b = Po(b);
    a = Ko(b, a);
    return a != null ? a : c;
  }
  function Po(a) {
    var b = M(Ho).bb;
    if (b && Bg(a.G, Bo) !== 8) {
      var c = ic(Kg(a, yo, 5), function (f) {
        f = wo(Ig(f, wm, 1), b);
        return f.success && f.value;
      });
      if (c) {
        var d;
        return (d = c.getValue()) != null ? d : null;
      }
    }
    var e;
    return (e = Ig(a, Gg, 4)) != null ? e : null;
  }
  var No = function () {
    this.j = {};
    this.o = [];
    this.l = {};
    this.h = new Map();
  };
  function Qo(a, b, c) {
    return !!Mo(1, a, b === void 0 ? !1 : b, c);
  }
  function Ro(a, b, c) {
    b = b === void 0 ? "" : b;
    a = Mo(7, a, b, c);
    if (ae(a))
      try {
        return JSON.parse(a);
      } catch (d) {}
    try {
      return JSON.parse(b);
    } catch (d) {
      return null;
    }
  }
  function So(a, b, c) {
    b = b === void 0 ? 0 : b;
    a = Number(Mo(2, a, b, c));
    return isNaN(a) ? b : a;
  }
  function To(a, b, c) {
    b = b === void 0 ? "" : b;
    a = Mo(3, a, b, c);
    return ae(a) ? a : b;
  }
  function Uo(a, b, c) {
    b = b === void 0 ? [] : b;
    a = Mo(6, a, b, c);
    return Array.isArray(a) ? a : b;
  }
  function Vo(a, b, c) {
    b = b === void 0 ? [] : b;
    a = Mo(8, a, b, c);
    return Array.isArray(a) ? a : b;
  }
  function Oo(a) {
    return M(No).j[a] || (M(No).j[a] = {});
  }
  function Wo(a, b) {
    var c = Oo(b);
    Ij(a, function (d, e) {
      if (c[e]) {
        d = Ao(JSON.stringify(d));
        var f = Cg(d, Bo, 8);
        if (Te(gg(d, f)) != null) {
          var g = Ao(JSON.stringify(c[e]));
          f = Dg(d, Gg, 4);
          g = xo(Hg(g));
          Pg(f, 4, gf, g, jf, void 0, void 0, !0);
        }
        c[e] = Of(d);
      } else c[e] = d;
    });
  }
  function Xo(a, b, c, d, e) {
    e = e === void 0 ? !1 : e;
    var f = [],
      g = [];
    b = y(b);
    var h = b.next();
    try {
      for (; !h.done; h = b.next()) {
        var k = h.value,
          l = Oo(k),
          m = y(a),
          p = m.next();
        try {
          for (; !p.done; p = m.next()) {
            var q = p.value,
              r = Bg(q.G, Bo),
              t = Jo(q, r);
            if (t) {
              var v = void 0,
                x = void 0,
                E = void 0;
              var F =
                (v =
                  (E = M(No).h.get(k)) == null
                    ? void 0
                    : (x = E.get(t)) == null
                    ? void 0
                    : x.slice(0)) != null
                  ? v
                  : [];
              a: {
                v = t;
                x = r;
                E = F;
                var B = new rm();
                switch (x) {
                  case 1:
                    kh(B, 1, sm, v);
                    break;
                  case 2:
                    kh(B, 2, sm, v);
                    break;
                  case 3:
                    kh(B, 3, sm, v);
                    break;
                  case 6:
                    kh(B, 4, sm, v);
                    break;
                  case 7:
                    kh(B, 7, sm, v);
                    break;
                  case 8:
                    kh(B, 6, sm, v);
                    break;
                  default:
                    var J = void 0;
                    break a;
                }
                vg(B, 5, E, Ue);
                J = B;
              }
              v = J;
              var Q;
              if ((Q = v))
                (x = void 0), (Q = !((x = M(No).l[k]) == null || !x.has(t)));
              Q && f.push(v);
              if (r === 8 && l[t]) {
                var oa = Ao(JSON.stringify(l[t])),
                  ta = Dg(q, Gg, 4),
                  Da = xo(Hg(oa));
                Pg(ta, 4, gf, Da, jf, void 0, void 0, !0);
              } else {
                var ca;
                if ((ca = v))
                  (x = void 0),
                    (ca = !((x = M(No).h.get(k)) == null || !x.has(t)));
                ca && g.push(v);
              }
              if (!e) {
                v = t;
                x = k;
                E = d;
                var fa = M(No);
                fa.h.has(x) || fa.h.set(x, new Map());
                fa.h.get(x).has(v) || fa.h.get(x).set(v, []);
                E && fa.h.get(x).get(v).push(E);
              }
              l[t] = Of(q);
            }
          }
        } finally {
          z(m, p);
        }
      }
    } finally {
      z(b, h);
    }
    if (f.length || g.length)
      (a = d != null ? d : void 0),
        c.j &&
          c.l &&
          ((d = new tm()),
          (f = Og(d, 2, f)),
          (g = Og(f, 3, g)),
          a && eh(g, 1, a),
          (f = new Bm()),
          (g = Ng(f, 7, Cm, g)),
          c.pinger.ge(Do(c, g)));
  }
  function Yo(a, b) {
    b = Oo(b);
    a = y(a);
    var c = a.next();
    try {
      for (; !c.done; c = a.next()) {
        var d = c.value,
          e = Ao(JSON.stringify(d)),
          f = Bg(e.G, Bo),
          g = Jo(e, f);
        g && (b[g] || (b[g] = d));
      }
    } finally {
      z(a, c);
    }
  }
  function Zo() {
    return Object.keys(M(No).j).map(function (a) {
      return Number(a);
    });
  }
  function $o(a) {
    M(No).o.includes(a) || Wo(Oo(4), a);
  }
  function ap(a, b, c) {
    c.hasOwnProperty(a) || Object.defineProperty(c, String(a), { value: b });
  }
  function bp(a, b, c) {
    return b[a] || c;
  }
  function cp(a) {
    ap(5, Qo, a);
    ap(18, Ro, a);
    ap(6, So, a);
    ap(7, To, a);
    ap(8, Uo, a);
    ap(17, Vo, a);
    ap(13, Yo, a);
    ap(15, $o, a);
  }
  function dp(a) {
    ap(
      4,
      function (b) {
        M(Ho).bb = b;
      },
      a
    );
    ap(
      9,
      function (b, c) {
        var d = M(Ho);
        d.bb[3][b] == null && (d.bb[3][b] = c);
      },
      a
    );
    ap(
      10,
      function (b, c) {
        var d = M(Ho);
        d.bb[4][b] == null && (d.bb[4][b] = c);
      },
      a
    );
    ap(
      11,
      function (b, c) {
        var d = M(Ho);
        d.bb[5][b] == null && (d.bb[5][b] = c);
      },
      a
    );
    ap(
      14,
      function (b) {
        var c = M(Ho),
          d = y([3, 4, 5]),
          e = d.next();
        try {
          for (; !e.done; e = d.next()) {
            var f = e.value;
            Object.assign(c.bb[f], b[f]);
          }
        } finally {
          z(d, e);
        }
      },
      a
    );
  }
  function ep(a) {
    a.hasOwnProperty("init-done") ||
      Object.defineProperty(a, "init-done", { value: !0 });
  }
  var fp = function () {};
  fp.prototype.h = function () {};
  fp.prototype.j = function () {
    return [];
  };
  var gp = function (a, b, c) {
    a.h = function (d, e) {
      bp(2, b, function () {
        return [];
      })(d, c, e);
    };
    a.j = function (d) {
      return bp(3, b, function () {
        return [];
      })(d != null ? d : c);
    };
  };
  function hp(a) {
    return M(fp).j(a);
  }
  var ip = function (a, b, c) {
      this.id = a;
      this.I = b;
      this.vg = c;
      this.selected = !1;
    },
    jp = function (a) {
      return a.selected || a.vg;
    },
    kp = function () {
      this.h = [];
    },
    lp = function () {
      this.j = !1;
      this.h = new Map();
      this.o = new kp();
      this.A = new ip(0, 0, !1);
      this.l = [this.o];
    },
    O = function (a) {
      var b = mp;
      if (
        b.j ||
        b.h.has(a.id) ||
        (a.I == null && a.control == null) ||
        a.Bm === !1
      )
        return b.A;
      var c = b.o;
      if (a.control != null) {
        var d = y(b.l),
          e = d.next();
        try {
          for (; !e.done; e = d.next()) {
            var f = e.value;
            if (f.h.includes(a.control)) {
              c = f;
              break;
            }
          }
        } finally {
          z(d, e);
        }
      } else a.Xa != null && (c = a.Xa);
      d = 0;
      a.control != null ? (d = a.control.I) : a.I != null && (d = a.I);
      a = new ip(a.id, d, !!a.vg);
      c.h.push(a);
      b.l.includes(c) || b.l.push(c);
      b.h.set(a.id, a);
      return a;
    },
    np = function () {
      var a = mp;
      a = [].concat(ra(a.h.keys())).filter(function (c) {
        return jp(this.h.get(c));
      }, a);
      var b = hp();
      return [].concat(ra(a), ra(b));
    },
    op = function () {
      return np()
        .sort(function (a, b) {
          return Number.isNaN(a) ? 1 : Number.isNaN(b) ? -1 : a - b;
        })
        .join(",");
    },
    pp = function (a) {
      var b = mp;
      b.j || (a.fe(b.l, b.h), (b.j = !0));
    };
  lp.prototype.reset = function () {
    var a = y(this.h),
      b = a.next();
    try {
      for (; !b.done; b = a.next()) {
        var c = y(b.value);
        c.next();
        c.next().value.selected = !1;
      }
    } finally {
      z(a, b);
    }
    this.j = !1;
  };
  var mp = new lp();
  function qp() {
    return rp.h
      .filter(function (a) {
        return jp(a);
      })
      .map(function (a) {
        return a.id;
      });
  }
  var sp = function (a, b) {
    this.h = a;
    this.j = b;
  };
  w(sp, to);
  sp.prototype.fe = function (a, b) {
    to.prototype.fe.call(this, a, b);
    var c = [];
    a = [];
    var d = y(this.h),
      e = d.next();
    try {
      for (; !e.done; e = d.next()) {
        var f = e.value;
        b.get(f) ? c.push(f) : a.push(f);
      }
    } finally {
      z(d, e);
    }
    b = c.map(String).join(",") || "0";
    a = a.map(String).join(",") || "0";
    N.getInstance().P("sei", b);
    N.getInstance().P("nsei", a);
    N.getInstance().P("bi", this.j);
  };
  var tp = function () {
      no.apply(this, arguments);
    },
    up;
  w(tp, no);
  var oo = function (a, b) {
    var c = N.getInstance();
    c.P("eee", a);
    c.P("bi", b);
  };
  tp.getInstance = function (a) {
    up || (up = new tp(a));
    return up;
  };
  function vp() {
    return wp
      .split(",")
      .map(function (a) {
        a = a.trim();
        a = Number(((a.charCodeAt(0) - 43) & -3 ? "0" : "") + a + ".");
        a = Number.isInteger(a) ? a : void 0;
        return a;
      })
      .filter(function (a) {
        return a != null && !isNaN(a);
      });
  }
  var rp = new kp(),
    xp = new kp(),
    yp = new kp(),
    zp = new kp();
  O({ id: 95342637, I: 0 });
  O({ id: 318475490, I: 0 });
  O({ id: 324123032, I: 0 });
  O({ id: 95342168, I: 10 });
  O({ id: 95342169, I: 10 });
  O({ id: 21062100, I: 0 });
  O({ id: 420706142, I: 0 });
  O({ id: 44745813, I: 0 });
  O({ id: 95355265, I: 0 });
  O({ id: 95382105, I: 0 });
  O({ id: 95389385, I: 0 });
  O({ id: 95391052, I: 0 });
  O({ id: 95390991, I: 0 });
  O({ id: 95405086, I: 0 });
  O({ id: 44746068, I: 0 });
  O({ id: 418572006, I: 10 });
  O({ id: 95338773, I: 10, Xa: yp });
  O({ id: 95338774, I: 10, Xa: yp });
  O({ id: 95334214, I: 10 });
  O({ id: 95334215, I: 10 });
  O({ id: 44714743, I: 0 });
  O({ id: 44715336, I: 10 });
  O({ id: 44724516, I: 0 });
  O({ id: 44726389, I: 10 });
  O({ id: 44733246, I: 10 });
  O({ id: 44751889, I: 10 });
  O({ id: 44751890, I: 10 });
  O({ id: 44752995, I: 10 });
  O({ id: 44752996, I: 10 });
  O({ id: 44762627, I: 0 });
  O({ id: 44762628, I: 0 });
  O({ id: 44801479, I: 10, Xa: xp });
  O({ id: 44801480, I: 10, Xa: xp });
  O({ id: 44754608, I: 10 });
  O({ id: 44754609, I: 10 });
  O({ id: 44776384, I: 0 });
  O({ id: 44789282, I: 0 });
  O({ id: 95355192, I: 0 });
  O({ id: 95403989, I: 0 });
  O({ id: 95334260, I: 0 });
  O({ id: 75259416, I: 0 });
  O({ id: 75259420, I: 0 });
  O({ id: 318524579, I: 0 });
  O({ id: 75259421, I: 0 });
  O({ id: 95399021, I: 0 });
  O({ id: 45401791, I: 0 });
  O({ id: 44809192, I: 0, Xa: zp });
  O({ id: 44809193, I: 0, Xa: zp });
  O({ id: 95320804, I: 0, Xa: zp });
  O({ id: 95320805, I: 0, Xa: zp });
  O({ id: 46130031, I: 0 });
  O({ id: 95377441, I: 0 });
  O({ id: 95327848, I: 0 });
  O({ id: 31065644, I: 1 });
  var Ap = O({ id: 31065645, I: 1 }),
    Bp = new kp();
  O({ id: 95331588, I: 0, Xa: Bp });
  O({ id: 95331589, I: 1e3, Xa: Bp });
  O({ id: 95378017, I: 0 });
  O({ id: 95332182, I: 0 });
  O({ id: 95362047, I: 0 });
  var Cp = O({ id: 789179015, I: 0 });
  O({ id: 95370886, I: 0 });
  O({ id: 318523523, I: 0 });
  O({ id: 95379050, I: 10 });
  O({ id: 95379051, I: 10 });
  O({ id: 95391729, I: 0 });
  O({ id: 95392006, I: 0 });
  O({ id: 95392007, I: 0 });
  O({ id: 95378020, I: 0 });
  O({ id: 95380703, I: 0 });
  O({ id: 95380704, I: 0 });
  O({ id: 95380705, I: 0 });
  O({ id: 95380706, I: 0 });
  O({ id: 95387020, I: 0 });
  O({ id: 95392225, I: 0 });
  O({ id: 95386938, I: 1 });
  O({ id: 95386939, I: 1 });
  O({ id: 95389256, I: 0 });
  O({ id: 95389401, I: 0 });
  O({ id: 95391764, I: 0 });
  O({ id: 95396213, I: 0 });
  O({ id: 95406154, I: 0 });
  O({ id: 95406098, I: 0 });
  O({ id: 95406099, I: 0 });
  O({ id: 95406100, I: 0 });
  O({ id: 95406101, I: 0 });
  O({ id: 95403657, I: 0 });
  O({ id: 95410373, I: 0 });
  if (
    typeof window !== "undefined" &&
    typeof window.document !== "undefined" &&
    typeof window.initializeVirtualDom === "undefined"
  ) {
    var qo = tp.getInstance(window.document);
    qo.j || (ro(), (qo.j = !0));
    var wp = qo.l,
      Dp;
    qo.j || (ro(), (qo.j = !0));
    Dp = qo.h;
    if (wp != null) {
      var Ep = new sp(vp(), Dp);
      pp(Ep);
    }
  }
  var Fp = function (a) {
    this.G = I(a);
  };
  w(Fp, K);
  var Gp = function (a) {
    this.G = I(a);
  };
  w(Gp, K);
  Gp.prototype.getId = function () {
    return Ug(this, 1);
  };
  var Hp = function (a) {
    this.G = I(a);
  };
  w(Hp, K);
  var Ip = function (a) {
    this.G = I(a);
  };
  w(Ip, K);
  var Jp = function (a) {
    this.G = I(a);
  };
  w(Jp, K);
  var Kp = function (a) {
    this.G = I(a);
  };
  w(Kp, K);
  var Lp = function (a) {
    this.G = I(a);
  };
  w(Lp, K);
  var Mp = function (a) {
    this.G = I(a);
  };
  w(Mp, K);
  var Op = function () {
    var a = Np();
    return Ig(a, Lp, 4);
  };
  var Pp = pj(Mp);
  var Qp = null;
  function Np() {
    var a;
    return (a = Qp) != null
      ? a
      : (Qp = Pp(
          '[[[[45713128,null,null,[]],[45848619,null,null,[1]],[45869267,null,null,[]],[957164676,null,null,[1]],[45816264,null,null,[]],[45761044,null,null,[]],[45803173,null,null,[]],[45722344,null,null,[]],[45879521,null,null,[]],[45801847,null,null,[]],[45784857,null,null,[]],[45668885,null,null,[]],[45843251,null,null,[]],[45685340,null,null,[]],[45663239,null,null,[]],[45676441,null,null,[]],[null,45645574,null,[]],[45688859,null,null,[]],[45870731,null,null,[]],[45870732,null,null,[]],[45685601,null,null,[1]],[null,45685602,null,[null,100]],[45830425,null,null,[]],[45820997,null,null,[]],[null,45812678,null,[]],[1009155880,null,null,[]],[45756824,null,null,[1]],[45794243,null,null,[]],[45747172,null,null,[]],[775241416,null,null,[]],[781107959,null,null,[]],[781107958,null,null,[]],[792614055,null,null,[]],[781107957,null,null,[]],[45729602,null,null,[]],[45753603,null,null,[]],[45753604,null,null,[]],[45877073,null,null,[]],[45868504,null,null,[]],[45867420,null,null,[]],[45851551,null,null,[]],[null,null,45886931,[null,null,"EgkIn8fuFRICCAA="]],[null,null,null,[],null,null,null,45823412]],[[16,[[100,[[83323870],[83323871,[[45830425,null,null,[1]]]]]],[10,[[83324496],[83324497,[[1009155880,null,null,[1]]]]]],[1000,[[95332046]]],[null,[[95332047]]],[10,[[95338769,[[null,45645574,null,[null,1]]]],[95338770,[[null,45645574,null,[null,2]]]]]],[50,[[95351425],[95351426,[[45676441,null,null,[1]]]]]],[1,[[95373378,[[792614055,null,null,[1]]]],[95373379,[[45747172,null,null,[1]],[781107959,null,null,[1]],[792614055,null,null,[1]],[781107957,null,null,[1]]]]]],[10,[[95378629],[95378630,[[45729602,null,null,[1]]]],[95404887,[[45729602,null,null,[1]]]],[95411620,[[45729602,null,null,[1]],[45877073,null,null,[1]]]]]],[10,[[95389581],[95389582,[[635466687,null,null,[1]]]]]],[50,[[95394237],[95394238,[[45801847,null,null,[1]]]]]],[100,[[95394594],[95394595,[[45803173,null,null,[1]]]]]],[10,[[95398837],[95398838,[[null,960449109,null,[null,1]]]]]],[500,[[95401453],[95403043,[[45668885,null,null,[1]],[45843251,null,null,[1]]]]]],[50,[[95405338],[95405339,[[45816264,null,null,[1]]]]]],[10,[[95407374],[95407375,[[45867420,null,null,[1]]]]]],[100,[[95407513],[95407514,[[45868504,null,null,[1]]]]]],[10,[[95407589],[95407590,[[45869267,null,null,[1]]]]]],[500,[[95408328],[95408330,[[45870731,null,null,[1]],[45870732,null,null,[1]]]]]]]],[34,[[10,[[95404718,[[null,null,null,[null,null,null,["CgUIsIW/LQ=="]],null,null,null,45823412]]],[95404719,[[null,null,null,[null,null,null,["CgUIsYW/LRIJCJ/H7hUSAggB"]],null,null,null,45823412]]]],[4,null,114,null,null,null,null,["45851551"]]]]],[35,[[null,[[95404720],[95404721,[[45851551,null,null,[1]]]]],[4,null,114,null,null,null,null,["45851551"]]]]]],null,null,[null,1000,1,1000]],null,["crazygames.com",[null,[[["1004887"],["107794268"],["10947743"],["11743293"],["21726375739"],["21939239661"],["22142119198"],["22917490941"],["5706918"],["70228659"],["7047"],["7103"],["88582731"],["14206847"],["21632739574"],["21734522779"],["22326630758"],["22466671215"],["23103256045"],["23014212494"],["23079078184"],["23104141172"],["23150589420"],["23169189715"],["23178201717"]],"crazygames.com"],[[["1004887",1],["107794268",1],["10947743",1],["11743293",1],["14206847",1],["21632739574",1],["21726375739",1],["21734522779",1],["21939239661",1],["22142119198",1],["22326630758",1],["22466671215",1],["22917490941",1],["23014212494",1],["23079078184",1],["23103256045",1],["23104141172",1],["23150589420",1],["23169189715",1],["23178201717",1],["5706918",1],["70228659",1],["7047",1],["7103",1],["88582731",1]]],null,[[["70228659",1,[[1]]],["22142119198",1,[[1]]],["7047",1,[[2]]]]],null,[["1004887",[["pubcid.org",null,1,1],["euid.eu",null,1,1],["liveintent.indexexchange.com",null,1,1],["audigent.com",null,1,1],["criteo.com",null,1,1],["adserver.org",null,1,1],["epsilon.com",null,1,1],["id5-sync.com",null,1,1],["pubmatic.com",null,1,1],["rubiconproject.com",null,1,1],["intentiq.com",null,1,1],["rtbhouse","https://invstatic101.creativecdn.com/encrypted-signals/encrypted-tag-g.js",null,1],["novatiq.com",null,1,1],["esp.criteo.com","https://static.criteo.net/js/ld/publishertag.ids.js",null,1],["crwdcntrl.net","https://tags.crwdcntrl.net/lt/c/16589/sync.min.js",null,1],["liveramp.com",null,1,1],["openx","https://oa.openxcdn.net/esp.js",null,1],["openxtest","https://oa.openxcdn.net/esp.js",null,1],["openx.net",null,null,1],["uidapi.com",null,1,1],["liveintent.com",null,1,1],["liveintent.triplelift.com",null,1,1],["bidswitch.net",null,1,1],["mygaruID",null,1,1],["utiq.com",null,1,1],["yahoo.com",null,1,1],["intimatemerger.com",null,1,1],["liveintent.sovrn.com",null,1,1],["esp.pubmatic.com",null,1,1],["justtag.com",null,1,1],["ceeid.eu",null,1,1],["acxiom.id",null,1,1],["google.com",null,1]]],["107794268",[["google.com",null,1]]],["10947743",[["google.com",null,1]]],["21726375739",[["pubcid.org",null,1,1],["rtbhouse","https://invstatic101.creativecdn.com/encrypted-signals/encrypted-tag-g.js",null,1],["id5-sync.com",null,1,1],["liveramp.com",null,1,1],["uidapi.com",null,1,1],["openx.net",null,1,1],["bidswitch.net",null,1,1],["epsilon.com",null,1,1],["acxiom.id",null,1,1],["crwdcntrl.net",null,1,1],["euid.eu",null,1,1],["pubmatic.com",null,1,1],["justtag.com",null,1,1],["criteo.com",null,1,1],["intimatemerger.com",null,1,1],["liveintent.sovrn.com",null,1,1],["adserver.org",null,1,1],["rubiconproject.com",null,1,1],["audigent.com",null,1,1],["liveintent.indexexchange.com",null,1,1],["esp.pubmatic.com",null,1,1],["ceeid.eu",null,1,1],["novatiq.com",null,1,1],["liveintent.com",null,1,1],["liveintent.triplelift.com",null,1,1],["utiq.com",null,1,1],["yahoo.com",null,1,1],["mygaruID",null,1,1],["intentiq.com",null,1,1],["google.com",null,1]]],["21939239661",[["google.com",null,1]]],["22142119198",[["openx","https://oa.openxcdn.net/esp.js",null,1],["openxtest","https://oa.openxcdn.net/esp.js",null,1],["openx.net",null,null,1],["mygaruID","https://cdn.mgaru.dev/static/myGaruStandalone.js",null,1],["id5-sync.com","https://cdn.id5-sync.com/api/1.0/esp.js",null,1],["crwdcntrl.net","https://tags.crwdcntrl.net/lt/c/16589/sync.min.js",null,1],["permutive-secure-signal",null,null,1],["esp.criteo.com","https://static.criteo.net/js/ld/publishertag.ids.js",null,1],["intimatemerger.com","https://dmp.im-apps.net/secure-signal/provider.js",null,1],["pubcid.org","https://cdn.jsdelivr.net/gh/prebid/shared-id/pubcid.js/docs/pubcid.min.js",null,1],["esp.pubmatic.com","https://ads.pubmatic.com/AdServer/js/google-esp.js",null,1],["euid.eu",null,1,1],["yahoo.com","https://connectid.analytics.yahoo.com/connectId-gpt.js",null,1],["uidapi.com",null,1,1],["bidswitch.net",null,1,1],["liveintent.indexexchange.com",null,1,1],["ceeid.eu",null,1,1],["adserver.org",null,1,1],["liveintent.com",null,1,1],["justtag.com",null,1,1],["intentiq.com",null,1,1],["epsilon.com",null,1,1],["acxiom.id",null,1,1],["liveintent.triplelift.com",null,1,1],["liveintent.sovrn.com",null,1,1],["utiq.com",null,1,1],["audigent.com",null,1,1],["rubiconproject.com",null,1,1],["criteo.com",null,1,1],["novatiq.com",null,1,1],["pubmatic.com",null,1,1],["liveramp.com",null,1,1],["google.com",null,1]]],["22917490941",[["liveramp.com",null,1],["uidapi.com",null,1],["intentiq.com",null,1],["criteo.com",null,1],["esp.pubmatic.com",null,1],["pubmatic.com",null,1],["crwdcntrl.net",null,1],["pubcid.org",null,1],["ceeid.eu",null,1],["epsilon.com",null,1],["mygaruID",null,1],["yahoo.com",null,1],["justtag.com",null,1],["intimatemerger.com",null,1],["bidswitch.net",null,1],["adserver.org",null,1],["liveintent.sovrn.com",null,1],["acxiom.id",null,1],["openx.net",null,1],["liveintent.indexexchange.com",null,1],["utiq.com",null,1],["id5-sync.com",null,1],["rubiconproject.com",null,1],["novatiq.com",null,1],["liveintent.com",null,1],["liveintent.triplelift.com",null,1],["euid.eu",null,1],["audigent.com",null,1],["google.com",null,1]]],["5706918",[["esp.criteo.com","https://static.criteo.net/js/ld/publishertag.ids.js",null,1],["permutive-secure-signal",null,null,1],["rtbhouse","https://invstatic101.creativecdn.com/encrypted-signals/encrypted-tag-g.js",null,1],["liveramp.com",null,1,1],["liveintent.sovrn.com",null,1,1],["openx.net",null,1,1],["liveintent.indexexchange.com",null,1,1],["esp.pubmatic.com",null,1,1],["euid.eu",null,1,1],["pubcid.org",null,1,1],["crwdcntrl.net",null,1,1],["criteo.com",null,1,1],["acxiom.id",null,1,1],["yahoo.com",null,1,1],["intimatemerger.com",null,1,1],["intentiq.com",null,1,1],["mygaruID",null,1,1],["uidapi.com",null,1,1],["utiq.com",null,1,1],["bidswitch.net",null,1,1],["epsilon.com",null,1,1],["id5-sync.com",null,1,1],["audigent.com",null,1,1],["pubmatic.com",null,1,1],["liveintent.com",null,1,1],["liveintent.triplelift.com",null,1,1],["justtag.com",null,1,1],["rubiconproject.com",null,1,1],["novatiq.com",null,1,1],["adserver.org",null,1,1],["ceeid.eu",null,1,1],["google.com",null,1]]],["70228659",[["crwdcntrl.net","https://tags.crwdcntrl.net/lt/c/16589/sync.min.js"],["liveramp.com"],["id5-sync.com","https://cdn.id5-sync.com/api/1.0/esp.js"],["intentiq.com",null,1],["esp.pubmatic.com",null,1],["pubmatic.com",null,1],["criteo.com",null,1],["pubcid.org",null,1],["novatiq.com",null,1],["adserver.org",null,1],["epsilon.com",null,1],["justtag.com",null,1],["ceeid.eu",null,1],["yahoo.com",null,1],["rubiconproject.com",null,1],["euid.eu",null,1],["acxiom.id",null,1],["liveintent.indexexchange.com",null,1],["openx.net",null,1],["liveintent.sovrn.com",null,1],["uidapi.com",null,1],["bidswitch.net",null,1],["liveintent.com",null,1],["liveintent.triplelift.com",null,1],["mygaruID",null,1],["utiq.com",null,1],["intimatemerger.com",null,1],["audigent.com",null,1],["google.com",null,1]]],["7047",[["google.com",null,1]]],["7103",[["esp.criteo.com","https://static.criteo.net/js/ld/publishertag.ids.js",null,1],["liveintent.com",null,null,1],["liveintent.triplelift.com",null,null,1],["uidapi.com",null,null,1],["yahoo.com","https://connectid.analytics.yahoo.com/connectId-gpt.js",null,1],["id5-sync.com","https://cdn.id5-sync.com/api/1.0/esp.js",null,1],["liveramp.com",null,null,1],["pubcid.org",null,null,1],["crwdcntrl.net","https://tags.crwdcntrl.net/lt/c/16589/sync.min.js",null,1],["criteo.com",null,null,1],["google.com",null,1]]]]]],[1,0,0],null,"m202611100101"]'
        ));
  }
  function Rp(a) {
    a == null || le(a);
    if (a != null) return Sp(a);
  }
  function Tp(a) {
    a == null || le(a);
    return a == null ? null : Sp(a);
  }
  function Sp(a) {
    re(a);
    return re(a) ? Number(a) : String(a);
  }
  var lg;
  lg = Sd;
  function Up(a) {
    a = a && a.toString && a.toString();
    return ae(a) && Ob(a, "[native code]");
  }
  function Vp(a, b) {
    try {
      var c = a.split(".");
      a = C;
      for (var d = 0, e; a != null && d < c.length; d++)
        (e = a), (a = a[c[d]]), typeof a === "function" && (a = e[c[d]]());
      var f = a;
      if (typeof f === b) return f;
    } catch (g) {}
  }
  var Wp = {},
    Xp = {},
    Yp = {},
    Zp = {},
    $p =
      ((Zp[3] =
        ((Wp[8] = function (a) {
          try {
            return $a(a) != null;
          } catch (b) {}
        }),
        (Wp[9] = function (a) {
          try {
            var b = $a(a);
          } catch (c) {
            return;
          }
          return typeof b === "function" && Up(b);
        }),
        (Wp[10] = function () {
          return window === window.top;
        }),
        (Wp[6] = function (a, b) {
          return kc(hp(b ? Number(b) : void 0), Number(a));
        }),
        (Wp[27] = function (a) {
          a = Vp(a, "boolean");
          return a !== void 0 ? a : void 0;
        }),
        (Wp[60] = function (a) {
          try {
            return !!C.document.querySelector(a);
          } catch (b) {}
        }),
        (Wp[80] = function (a) {
          try {
            return !!C.matchMedia(a).matches;
          } catch (b) {}
        }),
        (Wp[69] = function (a) {
          var b = C.document;
          b = b === void 0 ? document : b;
          var c;
          return !((c = b.featurePolicy) == null || !c.features().includes(a));
        }),
        (Wp[70] = function (a) {
          var b = C.document;
          b = b === void 0 ? document : b;
          var c;
          return !(
            (c = b.featurePolicy) == null || !c.allowedFeatures().includes(a)
          );
        }),
        Wp)),
      (Zp[4] =
        ((Xp[3] = function () {
          return Ck();
        }),
        (Xp[6] = function (a) {
          a = Vp(a, "number");
          return a !== void 0 ? a : void 0;
        }),
        Xp)),
      (Zp[5] =
        ((Yp[2] = function () {
          return window.location.href;
        }),
        (Yp[3] = function () {
          try {
            return window.top.location.hash;
          } catch (a) {
            return "";
          }
        }),
        (Yp[4] = function (a) {
          a = Vp(a, "string");
          return a !== void 0 ? a : void 0;
        }),
        (Yp[12] = function (a) {
          try {
            var b = Vp(a, "string");
            if (b !== void 0) return atob(b);
          } catch (c) {}
        }),
        Yp)),
      Zp);
  function aq() {
    var a = a === void 0 ? C : a;
    return a.ggeac || (a.ggeac = {});
  }
  function bq(a) {
    var b = {};
    return cq(
      ((b[0] = new Map()), (b[1] = new Map()), (b[2] = new Map()), b),
      a
    );
  }
  function cq(a, b) {
    var c = new Map(),
      d = y(a[1].entries()),
      e = d.next();
    try {
      for (; !e.done; e = d.next()) {
        var f = y(e.value),
          g = f.next().value,
          h = f.next().value,
          k = h[h.length - 1];
        c.set(g, k.jh + k.Kg * k.Lg);
      }
    } finally {
      z(d, e);
    }
    b = y(b);
    d = b.next();
    try {
      for (; !d.done; d = b.next()) {
        var l = d.value;
        var m = Kg(l, Hp, 2);
        var p = y(m),
          q = p.next();
        try {
          for (; !q.done; q = p.next()) {
            var r = q.value;
            if (Kg(r, Gp, 2).length !== 0) {
              var t = Vg(r, 8);
              if (Zg(r, 4) && !Zg(r, 13) && !Zg(r, 14)) {
                e = void 0;
                t = (e = c.get(Zg(r, 4))) != null ? e : 0;
                var v = Vg(r, 1) * Kg(r, Gp, 2).length;
                c.set(Zg(r, 4), t + v);
              }
              e = [];
              for (f = 0; f < Kg(r, Gp, 2).length; f++) {
                var x = {
                  jh: t,
                  Kg: Vg(r, 1),
                  Lg: Kg(r, Gp, 2).length,
                  qj: f,
                  yd: Zg(l, 1),
                  me: r,
                  ib: Kg(r, Gp, 2)[f],
                };
                e.push(x);
              }
              dq(a[2], Zg(r, 10), e) ||
                dq(a[1], Zg(r, 4), e) ||
                dq(a[0], Kg(r, Gp, 2)[0].getId(), e);
            }
          }
        } finally {
          z(p, q);
        }
      }
    } finally {
      z(b, d);
    }
    return a;
  }
  function dq(a, b, c) {
    if (!b) return !1;
    a.has(b) || a.set(b, []);
    var d;
    (d = a.get(b)).push.apply(d, ra(c));
    return !0;
  }
  var eq = RegExp(
    "^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$"
  );
  function fq(a) {
    var b = a.match(eq);
    a = b[1];
    var c = b[3];
    b = b[4];
    var d = "";
    a && (d += a + ":");
    c && ((d = d + "//" + c), b && (d += ":" + b));
    return d;
  }
  function gq(a, b) {
    if (a) {
      a = a.split("&");
      for (var c = 0; c < a.length; c++) {
        var d = a[c].indexOf("="),
          e = null;
        if (d >= 0) {
          var f = a[c].substring(0, d);
          e = a[c].substring(d + 1);
        } else f = a[c];
        b(f, e ? pk(e) : "");
      }
    }
  }
  var hq = /#|$/;
  function iq(a, b) {
    var c = a.search(hq);
    a: {
      var d = 0;
      for (var e = b.length; (d = a.indexOf(b, d)) >= 0 && d < c; ) {
        var f = a.charCodeAt(d - 1);
        if (f == 38 || f == 63)
          if (((f = a.charCodeAt(d + e)), !f || f == 61 || f == 38 || f == 35))
            break a;
        d += e + 1;
      }
      d = -1;
    }
    if (d < 0) return null;
    e = a.indexOf("&", d);
    if (e < 0 || e > c) e = c;
    d += b.length + 1;
    return pk(a.slice(d, e !== -1 ? e : 0));
  }
  function jq(a) {
    var b = a.length;
    if (b === 0) return 0;
    for (var c = 305419896, d = 0; d < b; d++)
      c ^= ((c << 5) + (c >> 2) + a.charCodeAt(d)) & 4294967295;
    return c > 0 ? c : 4294967296 + c;
  }
  var kq = [12, 13, 20, 32],
    lq = function (a, b, c, d) {
      d = d === void 0 ? {} : d;
      var e = d.tg;
      e = e === void 0 ? !1 : e;
      d = d.en;
      d = d === void 0 ? [] : d;
      this.Ld = a;
      this.ub = c;
      this.o = {};
      this.tg = e;
      a = {};
      this.h = ((a[b] = []), (a[4] = []), a);
      this.j = {};
      this.l = {};
      if ((b = An())) {
        b = y(b.split(",") || []);
        a = b.next();
        try {
          for (; !a.done; a = b.next()) {
            var f = Number(a.value);
            f && (this.j[f] = !0);
          }
        } finally {
          z(b, a);
        }
      }
      f = y(d);
      b = f.next();
      try {
        for (; !b.done; b = f.next()) this.j[b.value] = !0;
      } finally {
        z(f, b);
      }
    },
    oq = function (a, b, c, d) {
      var e = [],
        f;
      if ((f = b !== 9)) a.o[b] ? (f = !0) : ((a.o[b] = !0), (f = !1));
      if (f) return Eo(a.ub, b, c, e, [], 4), e;
      f = kq.includes(b);
      var g = [],
        h = [],
        k = y([0, 1, 2]),
        l = k.next();
      try {
        for (; !l.done; l = k.next()) {
          var m = l.value,
            p = y(a.Ld[m].entries()),
            q = p.next();
          try {
            for (; !q.done; q = p.next()) {
              var r = y(q.value),
                t = r.next().value,
                v = r.next().value,
                x = t,
                E = v,
                F = new jm(),
                B = E.filter(function (ng) {
                  return ng.yd === b && a.j[ng.ib.getId()] && mq(a, ng);
                });
              if (B.length) {
                var J = y(B),
                  Q = J.next();
                try {
                  for (; !Q.done; Q = J.next()) h.push(Q.value.ib);
                } finally {
                  z(J, Q);
                }
              } else if (!a.tg) {
                var oa = void 0;
                m === 2 ? ((oa = d[1]), kh(F, 2, km, x)) : (oa = d[0]);
                var ta = void 0,
                  Da = void 0,
                  ca =
                    (Da = (ta = oa) == null ? void 0 : ta(String(x))) != null
                      ? Da
                      : m === 2 && Zg(E[0].me, 11) === 1
                      ? void 0
                      : d[0](String(x));
                if (ca !== void 0) {
                  var fa = y(E),
                    Ma = fa.next();
                  try {
                    for (; !Ma.done; Ma = fa.next()) {
                      var wa = Ma.value;
                      if (wa.yd === b) {
                        var Ia = ca - wa.jh;
                        x = wa;
                        var Vb = x.Kg,
                          pc = x.Lg,
                          pf = x.qj;
                        if (
                          !(Ia < 0 || Ia >= Vb * pc || Ia % pc !== pf) &&
                          mq(a, wa)
                        ) {
                          var Ud = Zg(wa.me, 13);
                          if (Ud !== 0 && Ud !== void 0) {
                            var li = a.l[String(Ud)];
                            li !== void 0 && li !== wa.ib.getId()
                              ? Fo(a.ub, a.l[String(Ud)], wa.ib.getId(), Ud)
                              : (a.l[String(Ud)] = wa.ib.getId());
                          }
                          h.push(wa.ib);
                        }
                      }
                    }
                  } finally {
                    z(fa, Ma);
                  }
                  Bg(F.G, km) !== 0 && (eh(F, 3, ca), g.push(F));
                }
              }
            }
          } finally {
            z(p, q);
          }
        }
      } finally {
        z(k, l);
      }
      d = y(h);
      m = d.next();
      try {
        for (; !m.done; m = d.next()) {
          var mi = m.value,
            og = mi.getId();
          e.push(og);
          nq(a, og, f ? 4 : c);
          Xo(Kg(mi, zo, 2), f ? Zo() : [c], a.ub, og);
        }
      } finally {
        z(d, m);
      }
      Eo(a.ub, b, c, e, g, 1);
      return e;
    },
    nq = function (a, b, c) {
      a.h[c] || (a.h[c] = []);
      a = a.h[c];
      a.includes(b) || a.push(b);
    },
    mq = function (a, b) {
      var c = M(Ho).bb,
        d = wo(Ig(b.me, wm, 3), c);
      if (!d.success)
        return Go(a.ub, Ig(b.me, wm, 3), b.yd, b.ib.getId(), d), !1;
      if (!d.value) return !1;
      c = wo(Ig(b.ib, wm, 3), c);
      return c.success
        ? !!c.value
        : (Go(a.ub, Ig(b.ib, wm, 3), b.yd, b.ib.getId(), c), !1);
    },
    pq = function (a, b) {
      b = b
        .map(function (c) {
          return new Ip(c);
        })
        .filter(function (c) {
          return !kq.includes(Zg(c, 1));
        });
      a.Ld = cq(a.Ld, b);
    },
    qq = function (a, b) {
      ap(
        1,
        function (c) {
          a.j[c] = !0;
        },
        b
      );
      ap(
        2,
        function (c, d, e) {
          return oq(a, c, d, e);
        },
        b
      );
      ap(
        3,
        function (c) {
          return (a.h[c] || []).concat(a.h[4]);
        },
        b
      );
      ap(
        12,
        function (c) {
          return void pq(a, c);
        },
        b
      );
      ap(
        16,
        function (c, d) {
          return void nq(a, c, d);
        },
        b
      );
    };
  var rq = function () {
    var a = {};
    this.h = function (b, c) {
      return a[b] != null ? a[b] : c;
    };
    this.o = function (b, c) {
      var d = a[b];
      if (typeof d === "string" && b != null)
        try {
          return JSON.parse(d);
        } catch (e) {}
      try {
        return JSON.parse(c);
      } catch (e) {
        return null;
      }
    };
    this.j = function (b, c) {
      return a[b] != null ? a[b] : c;
    };
    this.D = function (b, c) {
      return a[b] != null ? a[b] : c;
    };
    this.B = function (b, c) {
      return a[b] != null ? a[b] : c;
    };
    this.A = function (b, c) {
      return a[b] != null ? c.concat(a[b]) : c;
    };
    this.l = function () {};
  };
  function sq(a) {
    return M(rq).h(a.h, a.defaultValue);
  }
  function tq(a) {
    return M(rq).j(a.h, a.defaultValue);
  }
  var uq = function () {
      this.h = function () {};
    },
    vq = function (a, b) {
      a.h = bp(14, b, function () {});
    };
  function wq(a) {
    M(uq).h(a);
  }
  var xq, yq, zq, Aq, Bq, Cq;
  function Dq(a, b) {
    var c = (b = b === void 0 ? aq() : b);
    gp(M(fp), c, a);
    Eq(b, a);
    a = b;
    vq(M(uq), a);
    M(rq).l();
  }
  function Eq(a, b) {
    var c = M(rq);
    c.h = function (d, e) {
      return bp(5, a, function () {
        return !1;
      })(d, e, b);
    };
    c.o = function (d, e) {
      return bp(18, a, function () {
        return null;
      })(d, e, b);
    };
    c.j = function (d, e) {
      return bp(6, a, function () {
        return 0;
      })(d, e, b);
    };
    c.D = function (d, e) {
      return bp(7, a, function () {
        return "";
      })(d, e, b);
    };
    c.B = function (d, e) {
      return bp(8, a, function () {
        return [];
      })(d, e, b);
    };
    c.A = function (d, e) {
      return bp(17, a, function () {
        return [];
      })(d, e, b);
    };
    c.l = function () {
      bp(15, a, function () {})(b);
    };
  }
  mp.reset();
  pp(new so());
  var Fq,
    Gq,
    Hq = Np();
  Gq = Ig(Hq, Kp, 1);
  (function (a) {
    var b = a.Ni;
    var c = a.bb;
    var d = a.config;
    var e = a.sm;
    e = e === void 0 ? aq() : e;
    var f = a.pi;
    f = f === void 0 ? 0 : f;
    var g = a.pinger;
    var h = a.ub;
    g =
      h === void 0
        ? new Co(
            (Aq = Rp((xq = Ig(b, Jp, 5)) == null ? void 0 : Wg(xq, 2))) != null
              ? Aq
              : 0,
            (Bq = Rp((yq = Ig(b, Jp, 5)) == null ? void 0 : Wg(yq, 4))) != null
              ? Bq
              : 0,
            (Cq = (zq = Ig(b, Jp, 5)) == null ? void 0 : Tg(zq, 3)) != null
              ? Cq
              : !1,
            g
          )
        : h;
    a = a.Ld;
    a = a === void 0 ? bq(Kg(b, Ip, 2, lg && mg())) : a;
    e.hasOwnProperty("init-done")
      ? (bp(12, e, function () {})(
          Kg(b, Ip, 2).map(function (k) {
            return Of(k);
          })
        ),
        bp(13, e, function () {})(
          Kg(b, zo, 1).map(function (k) {
            return Of(k);
          }),
          f
        ),
        c && bp(14, e, function () {})(c),
        Dq(f, e))
      : (qq(new lq(a, f, g, d), e),
        cp(e),
        dp(e),
        ep(e),
        Dq(f, e),
        Xo(Kg(b, zo, 1, lg && mg()), [f], g, void 0, !0),
        (Io = Io || !(!d || !d.Nm)),
        wq($p),
        c && wq(c));
  })({
    Ni: (Fq = Gq == null ? void 0 : Bf(Gq)) != null ? Fq : new Kp(),
    pi: 7,
  });
  var Iq = Ok(),
    Jq = {},
    Kq =
      ((Jq[0] = (function (a) {
        a = a === void 0 ? Dk() : a;
        return function (b) {
          return jq(b + " + " + a) % 1e3;
        };
      })(Iq)),
      Jq);
  M(fp).h(16, Kq);
  var Lq = function (a) {
    var b = {};
    Zb(a, function (c) {
      var d = c.event,
        e = b[d];
      b.hasOwnProperty(d)
        ? e !== null && (c.equals(e) || (b[d] = null))
        : (b[d] = c);
    });
    nc(a, function (c) {
      return b[c.event] === null;
    });
  };
  var Mq = { NONE: 0, Kk: 1 },
    Nq = { Hk: 0, Sl: 1, Rl: 2, Tl: 3 },
    Oq = { Nf: "a", Jk: "d", VIDEO: "v" };
  var Pq = function () {
    this.aa = 0;
    this.h = !1;
    this.j = -1;
    this.Xb = !1;
    this.Ca = 0;
  };
  Pq.prototype.isVisible = function () {
    return this.Xb ? this.aa >= 0.3 : this.aa >= 0.5;
  };
  var Qq = { Gk: 0, Pk: 1 },
    Rq = { 668123728: 0, 668123729: 1 },
    Sq = { 44731964: 0, 44731965: 1 },
    Tq = { NONE: 0, xl: 1, Vk: 2 },
    Uq = { 480596784: 0, 480596785: 1, 21063355: 2 };
  var Vq = function () {
      this.h = null;
      this.o = !1;
      this.l = null;
    },
    Wq = function (a) {
      a.o = !0;
      return a;
    },
    Xq = function (a, b) {
      a.l &&
        Zb(b, function (c) {
          c = a.l[c];
          c !== void 0 && a.j(c);
        });
    };
  Vq.prototype.getValue = function () {
    return this.h;
  };
  var Yq = function (a) {
    Vq.call(this);
    this.A = a;
  };
  w(Yq, Vq);
  Yq.prototype.j = function (a) {
    this.h === null && $k(this.A, a) && (this.h = a);
  };
  var Zq = function () {
    Vq.call(this);
  };
  w(Zq, Vq);
  Zq.prototype.j = function (a) {
    this.h === null && typeof a === "number" && (this.h = a);
  };
  var $q = function () {
    Vq.call(this);
  };
  w($q, Vq);
  $q.prototype.j = function (a) {
    this.h === null && typeof a === "string" && (this.h = a);
  };
  var ar = function () {
    this.h = {};
    this.l = !0;
    this.j = {};
  };
  ar.prototype.disable = function () {
    this.l = !1;
  };
  ar.prototype.reset = function () {
    this.h = {};
    this.l = !0;
    this.j = {};
  };
  var br = function (a, b, c) {
      a.h[b] || (a.h[b] = new Yq(c));
      return a.h[b];
    },
    cr = function (a) {
      a.h.queryid || (a.h.queryid = new $q());
    },
    dr = function (a, b, c) {
      (a = a.h[b]) && a.j(c);
    },
    er = function (a, b) {
      if (Zk(a.j, b)) return a.j[b];
      if ((a = a.h[b])) return a.getValue();
    },
    fr = function (a) {
      var b = {},
        c = Tk(a.h, function (d) {
          return d.o;
        });
      Sk(
        c,
        function (d, e) {
          d =
            a.j[e] !== void 0
              ? String(a.j[e])
              : d.o && d.h !== null
              ? String(d.h)
              : "";
          d.length > 0 && (b[e] = d);
        },
        a
      );
      return b;
    },
    gr = function (a) {
      a = fr(a);
      var b = [];
      Sk(a, function (c, d) {
        d in Object.prototype ||
          (typeof c != "undefined" && b.push([d, ":", c].join("")));
      });
      return b;
    },
    ir = function () {
      var a = hr().U,
        b = qp();
      a.l &&
        Zb(Wk(a.h), function (c) {
          return Xq(c, b);
        });
    };
  var jr = function (a) {
    br(a, "od", Mq);
    Wq(br(a, "opac", Qq));
    Wq(br(a, "sbeos", Qq));
    Wq(br(a, "prf", Qq));
    Wq(br(a, "mwt", Qq));
    br(a, "iogeo", Qq);
  };
  var kr = document,
    P = window;
  var lr =
    !Bc &&
    !(
      G("Safari") &&
      !(
        Wb() ||
        G("Coast") ||
        G("Opera") ||
        G("Edge") ||
        G("Edg/") ||
        G("OPR") ||
        Ub() ||
        G("Silk") ||
        G("Android")
      )
    );
  var mr = function () {
    this.h = this.Jb = null;
  };
  var nr = function () {};
  nr.prototype.now = function () {
    return 0;
  };
  nr.prototype.j = function () {
    return 0;
  };
  nr.prototype.l = function () {
    return 0;
  };
  nr.prototype.h = function () {
    return 0;
  };
  var pr = function () {
    if (!or()) throw Error();
  };
  w(pr, nr);
  var or = function () {
    return !(!P || !P.performance);
  };
  pr.prototype.now = function () {
    return or() && P.performance.now
      ? P.performance.now()
      : nr.prototype.now.call(this);
  };
  pr.prototype.j = function () {
    return or() && P.performance.memory
      ? P.performance.memory.totalJSHeapSize || 0
      : nr.prototype.j.call(this);
  };
  pr.prototype.l = function () {
    return or() && P.performance.memory
      ? P.performance.memory.usedJSHeapSize || 0
      : nr.prototype.l.call(this);
  };
  pr.prototype.h = function () {
    return or() && P.performance.memory
      ? P.performance.memory.jsHeapSizeLimit || 0
      : nr.prototype.h.call(this);
  };
  var qr = function () {};
  qr.prototype.isVisible = function () {
    return xn(kr) === 1;
  };
  var rr = RegExp("^https?://(\\w|-)+\\.cdn\\.ampproject\\.(net|org)(\\?|/|$)"),
    vr = function (a) {
      a = a || sr();
      for (
        var b = new tr(C.location.href, !1), c = null, d = a.length - 1, e = d;
        e >= 0;
        --e
      ) {
        var f = a[e];
        !c && rr.test(f.url) && (c = f);
        if (f.url && !f.h) {
          b = f;
          break;
        }
      }
      e = null;
      f = a.length && a[d].url;
      b.depth !== 0 && f && (e = a[d]);
      return new ur(b, e, c);
    },
    sr = function () {
      var a = C,
        b = [],
        c = null;
      do {
        var d = a;
        if (Jj(d)) {
          var e = d.location.href;
          c = (d.document && d.document.referrer) || null;
        } else (e = c), (c = null);
        b.push(new tr(e || ""));
        try {
          a = d.parent;
        } catch (f) {
          a = null;
        }
      } while (a && d !== a);
      d = 0;
      for (a = b.length - 1; d <= a; ++d) b[d].depth = a - d;
      d = C;
      if (
        d.location &&
        d.location.ancestorOrigins &&
        d.location.ancestorOrigins.length === b.length - 1
      )
        for (a = 1; a < b.length; ++a)
          (e = b[a]),
            e.url ||
              ((e.url = d.location.ancestorOrigins[a - 1] || ""), (e.h = !0));
      return b;
    },
    ur = function (a, b, c) {
      this.h = a;
      this.j = b;
      this.l = c;
    },
    tr = function (a, b) {
      this.url = a;
      this.h = !!b;
      this.depth = null;
    };
  var wr = function () {
      this.l = "&";
      this.j = {};
      this.o = 0;
      this.h = [];
    },
    xr = function (a, b) {
      var c = {};
      c[a] = b;
      return [c];
    },
    zr = function (a, b, c, d, e) {
      var f = [];
      Ij(a, function (g, h) {
        (g = yr(g, b, c, d, e)) && f.push(encodeURIComponent(h) + "=" + g);
      });
      return f.join(b);
    },
    yr = function (a, b, c, d, e) {
      if (a == null) return "";
      b = b || "&";
      c = c || ",$";
      ae(c) && (c = c.split(""));
      if (a instanceof Array) {
        if ((d || (d = 0), d < c.length)) {
          for (var f = [], g = 0; g < a.length; g++)
            f.push(yr(a[g], b, c, d + 1, e));
          return f.join(c[d]);
        }
      } else if (typeof a === "object")
        return (
          e || (e = 0),
          e < 2 ? encodeURIComponent(zr(a, b, c, d, e + 1)) : "..."
        );
      return encodeURIComponent(String(a));
    },
    Ar = function (a, b, c) {
      a.h.push(b);
      a.j[b] = c;
    },
    Br = function (a, b, c, d) {
      a.h.push(b);
      a.j[b] = xr(c, d);
    },
    Er = function (a, b, c, d) {
      return Cr(a) - d.length < 0 ? "" : b + "//" + c + d + Dr(a, d);
    },
    Dr = function (a, b) {
      var c = Cr(a) - b.length;
      if (c < 0) return "";
      b = "";
      a.h.sort(function (m, p) {
        return m - p;
      });
      for (var d = null, e = "", f = 0; f < a.h.length; f++)
        for (var g = a.h[f], h = a.j[g], k = 0; k < h.length; k++) {
          if (!c) {
            d = d == null ? g : d;
            break;
          }
          var l = zr(h[k], a.l, ",$");
          if (l) {
            l = e + l;
            if (c >= l.length) {
              c -= l.length;
              b += l;
              e = a.l;
              break;
            }
            d = d == null ? g : d;
          }
        }
      a = "";
      d != null && (a = "" + e + "trn=" + d);
      return b + a;
    },
    Cr = function (a) {
      var b = 1,
        c;
      for (c in a.j) c.length > b && (b = c.length);
      return 3997 - b - a.l.length - 1;
    };
  var Fr = function (a, b) {
      this.h = a;
      this.depth = b;
    },
    Hr = function () {
      var a = sr(),
        b = Math.max(a.length - 1, 0),
        c = vr(a);
      a = c.h;
      var d = c.j,
        e = c.l,
        f = [];
      c = function (h, k) {
        return h == null ? k : h;
      };
      e && f.push(new Fr([e.url, e.h ? 2 : 0], c(e.depth, 1)));
      d && d != e && f.push(new Fr([d.url, 2], 0));
      a.url && a != e && f.push(new Fr([a.url, 0], c(a.depth, b)));
      var g = cc(f, function (h, k) {
        return f.slice(0, f.length - k);
      });
      !a.url ||
        ((e || d) && a != e) ||
        ((d = Ak(a.url)) && g.push([new Fr([d, 1], c(a.depth, b))]));
      g.push([]);
      return cc(g, function (h) {
        return Gr(b, h);
      });
    };
  function Gr(a, b) {
    var c = dc(
        b,
        function (e, f) {
          return Math.max(e, f.depth);
        },
        -1
      ),
      d = vc(c + 2);
    d[0] = a;
    Zb(b, function (e) {
      return (d[e.depth + 1] = e.h);
    });
    return d;
  }
  function Ir() {
    var a = a === void 0 ? Hr() : a;
    return a.map(function (b) {
      return yr(b);
    });
  }
  var Jr = function () {
      this.j = new qr();
      this.h = or() ? new pr() : new nr();
    },
    Lr = function () {
      Kr();
      var a = P.document;
      return !!(
        a &&
        a.body &&
        a.body.getBoundingClientRect &&
        typeof P.setInterval === "function" &&
        typeof P.clearInterval === "function" &&
        typeof P.setTimeout === "function" &&
        typeof P.clearTimeout === "function"
      );
    };
  Jr.prototype.setInterval = function (a, b) {
    return P.setInterval(a, b);
  };
  Jr.prototype.clearInterval = function (a) {
    P.clearInterval(a);
  };
  Jr.prototype.setTimeout = function (a, b) {
    return P.setTimeout(a, b);
  };
  Jr.prototype.clearTimeout = function (a) {
    P.clearTimeout(a);
  };
  var Mr = function () {
    Kr();
    return Ir();
  };
  var Nr = function () {},
    Kr = function () {
      var a = M(Nr);
      if (!a.h) {
        if (!P)
          throw Error("Context has not been set and window is undefined.");
        a.h = M(Jr);
      }
      return a.h;
    };
  var Or = function (a) {
    this.G = I(a);
  };
  w(Or, K);
  Or.prototype.j = oj([0, Yi, bj, -2, ej]);
  var Pr = function (a) {
      this.l = a;
      this.h = -1;
      this.j = this.o = 0;
    },
    Qr = function (a, b) {
      return function () {
        var c = La.apply(0, arguments);
        if (a.h > -1) return b.apply(null, ra(c));
        try {
          return (a.h = a.l.h.now()), b.apply(null, ra(c));
        } finally {
          (a.o += a.l.h.now() - a.h), (a.h = -1), (a.j += 1);
        }
      };
    };
  var Rr = function (a, b) {
    this.j = a;
    this.l = b;
    this.h = new Pr(a);
  };
  var Sr = function () {
      this.h = {};
    },
    Ur = function () {
      var a = hr().flags,
        b = Tr;
      a = a.h[b.key];
      if (b.valueType === "proto") {
        try {
          var c = JSON.parse(a);
          if (Array.isArray(c)) return c;
        } catch (d) {}
        return b.defaultValue;
      }
      return typeof a === typeof b.defaultValue ? a : b.defaultValue;
    };
  var Vr = {
    Il: 1,
    nm: 2,
    El: 3,
    1: "POSITION",
    2: "VISIBILITY",
    3: "MONITOR_VISIBILITY",
  };
  var Wr = function () {
    this.l = void 0;
    this.j = this.D = 0;
    this.A = -1;
    this.U = new ar();
    Wq(br(this.U, "mv", Tq)).l = Uq === void 0 ? null : Uq;
    br(this.U, "omid", Qq);
    Wq(br(this.U, "epoh", Qq));
    Wq(br(this.U, "epph", Qq));
    Wq(br(this.U, "umt", Qq)).l = Rq === void 0 ? null : Rq;
    Wq(br(this.U, "phel", Qq));
    Wq(br(this.U, "phell", Qq));
    Wq(br(this.U, "oseid", Vr));
    var a = this.U;
    a.h.sloi || (a.h.sloi = new Zq());
    Wq(a.h.sloi);
    br(this.U, "mm", Oq);
    Wq(br(this.U, "ovms", Nq));
    Wq(br(this.U, "xdi", Qq));
    Wq(br(this.U, "amp", Qq));
    Wq(br(this.U, "prf", Qq));
    Wq(br(this.U, "gtx", Qq));
    Wq(br(this.U, "mvp_lv", Qq));
    Wq(br(this.U, "ssmol", Qq)).l = Sq === void 0 ? null : Sq;
    Wq(br(this.U, "fmd", Qq));
    br(this.U, "gen204simple", Qq);
    this.h = new Rr(Kr(), this.U);
    this.o = !1;
    this.flags = new Sr();
  };
  Wr.prototype.hf = function (a) {
    if (typeof a === "string" && a.length != 0) {
      var b = this.U;
      if (b.l) {
        a = a.split("&");
        for (var c = a.length - 1; c >= 0; c--) {
          var d = a[c].split("="),
            e = decodeURIComponent(d[0]);
          d.length > 1
            ? ((d = decodeURIComponent(d[1])),
              (d = /^[0-9]+$/g.exec(d) ? parseInt(d, 10) : d))
            : (d = 1);
          (e = b.h[e]) && e.j(d);
        }
      }
    }
  };
  var hr = function () {
    return M(Wr);
  };
  var Xr = function (a, b, c, d, e) {
    if ((d ? a.l : Math.random()) < (e || a.h))
      try {
        if (c instanceof wr) var f = c;
        else
          (f = new wr()),
            Ij(c, function (h, k) {
              var l = f,
                m = l.o++;
              Ar(l, m, xr(k, h));
            });
        var g = Er(
          f,
          a.j,
          "pagead2.googlesyndication.com",
          "/pagead/gen_204?id=" + b + "&"
        );
        g && (Kr(), Vl(P, g));
      } catch (h) {}
  };
  var $r = function () {
    var a = Yr,
      b = Zr;
    b = b === void 0 ? null : b;
    this.l = a;
    this.D = "jserror";
    this.o = !0;
    this.j = null;
    this.B = this.lb;
    this.h = b;
    this.A = !1;
  };
  n = $r.prototype;
  n.pinger = function () {
    return this.l;
  };
  n.tf = function (a) {
    this.j = a;
  };
  n.bh = function (a) {
    this.D = a;
  };
  n.wf = function (a) {
    this.o = a;
  };
  n.eh = function (a) {
    this.A = a;
  };
  n.bc = function (a, b, c) {
    var d = this;
    return Qr(hr().h.h, function () {
      try {
        if (d.h && d.h.l) {
          var e = d.h.start(a.toString(), 3);
          var f = b();
          d.h.end(e);
        } else f = b();
      } catch (h) {
        var g = d.o;
        try {
          Kn(e), (g = d.B(a, new as(bs(h)), void 0, c));
        } catch (k) {
          d.lb(217, k);
        }
        if (!g) throw h;
      }
      return f;
    })();
  };
  n.jf = function (a, b, c, d) {
    var e = this;
    return Qr(hr().h.h, function () {
      var f = La.apply(0, arguments);
      return e.bc(
        a,
        function () {
          return b.apply(c, f);
        },
        d
      );
    });
  };
  n.lb = function (a, b, c, d, e) {
    e = e || this.D;
    try {
      var f = new wr();
      Br(f, 1, "context", a);
      Gj(b) || (b = new as(bs(b)));
      b.msg && Br(f, 2, "msg", b.msg.substring(0, 512));
      var g = b.meta || {};
      if (this.j)
        try {
          this.j(g);
        } catch (k) {}
      if (d)
        try {
          d(g);
        } catch (k) {}
      Ar(f, 3, [g]);
      var h = vr();
      h.j && Br(f, 4, "top", h.j.url || "");
      Ar(f, 5, [{ url: h.h.url || "" }, { url: h.h.url ? fq(h.h.url) : "" }]);
      Xr(this.l, e, f, this.A, c);
    } catch (k) {
      try {
        Xr(
          this.l,
          e,
          { context: "ecmserr", rctx: a, msg: bs(k), url: h && h.h.url },
          this.A,
          c
        );
      } catch (l) {}
    }
    return this.o;
  };
  var bs = function (a) {
      var b = a.toString();
      a.name && b.indexOf(a.name) == -1 && (b += ": " + a.name);
      a.message && b.indexOf(a.message) == -1 && (b += ": " + a.message);
      if (a.stack)
        a: {
          a = a.stack;
          var c = b;
          try {
            a.indexOf(c) == -1 && (a = c + "\n" + a);
            for (var d; a != d; )
              (d = a),
                (a = a.replace(
                  /((https?:\/..*\/)[^\/:]*:\d+(?:.|\n)*)\2/,
                  "$1"
                ));
            b = a.replace(/\n */g, "\n");
            break a;
          } catch (e) {
            b = c;
            break a;
          }
          b = void 0;
        }
      return b;
    },
    as = function (a) {
      Fj.call(this, Error(a), { message: a });
    };
  w(as, Fj);
  var Yr,
    cs,
    Zr = new Jn(1, window),
    ds = function () {
      P &&
        typeof P.google_measure_js_timing != "undefined" &&
        (P.google_measure_js_timing || Zr.disable());
    };
  Yr = new (function () {
    var a = "https:";
    P && P.location && P.location.protocol === "http:" && (a = "http:");
    this.j = a;
    this.h = 0.01;
    this.l = Math.random();
  })();
  cs = new $r();
  P &&
    P.document &&
    (P.document.readyState == "complete"
      ? ds()
      : Zr.l &&
        Tl(P, "load", function () {
          ds();
        }));
  var es = function (a) {
      cs.tf(function (b) {
        Zb(a, function (c) {
          c(b);
        });
      });
    },
    fs = function (a, b) {
      return cs.bc(a, b);
    },
    gs = function (a, b, c, d) {
      return cs.jf(a, b, c, d);
    },
    hs = function (a, b, c, d) {
      cs.lb(a, b, c, d);
    };
  var is = Date.now(),
    js = -1,
    ks = -1,
    ls,
    ms = -1,
    ns = !1,
    os = function () {
      return Date.now() - is;
    },
    ps = function () {
      var a = hr().l,
        b = ks >= 0 ? os() - ks : -1,
        c = ns ? os() - js : -1,
        d = ms >= 0 ? os() - ms : -1;
      if (a == 947190542) return 100;
      if (a == 79463069) return 200;
      a = [2e3, 4e3];
      var e = [250, 500, 1e3];
      hs(637, Error(), 0.001);
      var f = b;
      c != -1 && c < b && (f = c);
      for (b = 0; b < a.length; ++b)
        if (f < a[b]) {
          var g = e[b];
          break;
        }
      g === void 0 && (g = e[a.length]);
      return d != -1 && d > 1500 && d < 4e3 ? 500 : g;
    };
  var qs = function (a, b, c) {
    var d = new L(0, 0, 0, 0);
    var e = e === void 0 ? null : e;
    var f = f === void 0 ? null : f;
    this.time = a;
    this.volume = e;
    this.o = b;
    this.h = d;
    this.j = f;
    this.l = c;
  };
  qs.prototype.equals = function (a, b) {
    return (
      !!a &&
      (!(b === void 0 ? 0 : b) || this.volume == a.volume) &&
      this.o == a.o &&
      zl(this.h, a.h) &&
      this.j == a.j
    );
  };
  var rs = function (a, b, c, d, e, f, g, h) {
    this.l = a;
    this.C = b;
    this.j = c;
    this.A = d;
    this.h = e;
    this.o = f;
    this.B = g;
    this.D = h;
  };
  rs.prototype.getTimestamp = function () {
    return this.B;
  };
  rs.prototype.equals = function (a, b) {
    return (
      this.l.equals(a.l, b === void 0 ? !1 : b) &&
      this.C == a.C &&
      zl(this.j, a.j) &&
      zl(this.A, a.A) &&
      this.h == a.h &&
      this.o == a.o &&
      this.B == a.B &&
      this.D == a.D
    );
  };
  var ts = {
      currentTime: 1,
      duration: 2,
      isVpaid: 4,
      volume: 8,
      isYouTube: 16,
      isPlaying: 32,
    },
    bl = {
      Tf: "start",
      FIRST_QUARTILE: "firstquartile",
      MIDPOINT: "midpoint",
      THIRD_QUARTILE: "thirdquartile",
      COMPLETE: "complete",
      ERROR: "error",
      Ph: "metric",
      PAUSE: "pause",
      Yh: "resume",
      SKIPPED: "skip",
      VIEWABLE_IMPRESSION: "viewable_impression",
      Qh: "mute",
      ci: "unmute",
      FULLSCREEN: "fullscreen",
      Lh: "exitfullscreen",
      Gh: "bufferstart",
      Fh: "bufferfinish",
      Pf: "fully_viewable_audible_half_duration_impression",
      Sf: "measurable_impression",
      Bh: "abandon",
      Of: "engagedview",
      IMPRESSION: "impression",
      Ih: "creativeview",
      LOADED: "loaded",
      PROGRESS: "progress",
      Ak: "close",
      Bk: "collapse",
      Rh: "overlay_resize",
      Sh: "overlay_unmeasurable_impression",
      Th: "overlay_unviewable_impression",
      Vh: "overlay_viewable_immediate_impression",
      Uh: "overlay_viewable_end_of_session_impression",
      Jh: "custom_metric_viewable",
      Ch: "audio_audible",
      Eh: "audio_measurable",
      Dh: "audio_impression",
    },
    us = "start firstquartile midpoint thirdquartile resume loaded".split(" "),
    vs = ["start", "firstquartile", "midpoint", "thirdquartile"],
    ws = ["abandon"],
    xs = {
      UNKNOWN: -1,
      Tf: 0,
      FIRST_QUARTILE: 1,
      MIDPOINT: 2,
      THIRD_QUARTILE: 3,
      COMPLETE: 4,
      Ph: 5,
      PAUSE: 6,
      Yh: 7,
      SKIPPED: 8,
      VIEWABLE_IMPRESSION: 9,
      Qh: 10,
      ci: 11,
      FULLSCREEN: 12,
      Lh: 13,
      Pf: 14,
      Sf: 15,
      Bh: 16,
      Of: 17,
      IMPRESSION: 18,
      Ih: 19,
      LOADED: 20,
      Jh: 21,
      Gh: 22,
      Fh: 23,
      Dh: 27,
      Eh: 28,
      Ch: 29,
    };
  var Vk = {
      wk: "addEventListener",
      Wk: "getMaxSize",
      Xk: "getScreenSize",
      Yk: "getState",
      Zk: "getVersion",
      Ql: "removeEventListener",
      zl: "isViewable",
    },
    ys = function (a) {
      var b = a !== a.top,
        c = a.top === Kj(a),
        d = -1,
        e = 0;
      if (b && c && a.top.mraid) {
        d = 3;
        var f = a.top.mraid;
      } else d = (f = a.mraid) ? (b ? (c ? 2 : 1) : 0) : -1;
      f &&
        (f.IS_GMA_SDK || (e = 2),
        Uk(function (g) {
          return typeof f[g] === "function";
        }) || (e = 1));
      return { Za: f, wd: e, fk: d };
    };
  var zs = function () {
    var a = window.document;
    return a && typeof a.elementFromPoint === "function";
  };
  function As(a, b, c) {
    try {
      if (a) {
        if (!b.top) return new L(-12245933, -12245933, -12245933, -12245933);
        b = b.top;
      }
      a: {
        var d = b;
        if (a && d !== null && d != d.top) {
          if (!d.top) {
            var e = new Rk(-12245933, -12245933);
            break a;
          }
          d = d.top;
        }
        try {
          e = (c === void 0 ? 0 : c)
            ? new Rk(d.innerWidth, d.innerHeight).round()
            : nl(d || window).round();
        } catch (m) {
          e = new Rk(-12245933, -12245933);
        }
      }
      a = e;
      var f = a.height,
        g = a.width;
      if (g === -12245933) return new L(g, g, g, g);
      var h = xl(jl(b.document)),
        k = h.x,
        l = h.y;
      return new L(l, k + g, l + f, k);
    } catch (m) {
      return new L(-12245933, -12245933, -12245933, -12245933);
    }
  }
  var Bs = function (a, b) {
    b = Math.pow(10, b);
    return Math.floor(a * b) / b;
  };
  function Cs(a, b, c, d) {
    if (!a) return { value: d, done: !1 };
    d = b(d, a);
    var e = c(d, a);
    return !e && xc(a, "parentElement")
      ? Cs(a.parentElement || null, b, c, d)
      : { done: e, value: d };
  }
  var Ds = function (a, b, c, d) {
    if (!a) return d;
    d = Cs(a, b, c, d);
    if (!d.done)
      try {
        var e = il(a),
          f = e && ol(e);
        return Ds(f && f.frameElement, b, c, d.value);
      } catch (g) {}
    return d.value;
  };
  function Es(a) {
    var b = !Bc || Rc();
    return Ds(
      a,
      function (c, d) {
        c = xc(d, "style") && d.style && Il(d, "visibility");
        return { hidden: c === "hidden", visible: b && c === "visible" };
      },
      function (c) {
        return c.hidden || c.visible;
      },
      { hidden: !1, visible: !1 }
    ).hidden;
  }
  var Fs = function (a) {
      return Ds(
        a,
        function (b, c) {
          return !(!xc(c, "style") || !c.style || Il(c, "display") !== "none");
        },
        function (b) {
          return b;
        },
        !1
      )
        ? !0
        : Es(a);
    },
    Gs = function (a) {
      return new L(a.top, a.right, a.bottom, a.left);
    },
    Hs = function (a) {
      var b = a.top || 0,
        c = a.left || 0;
      return new L(b, c + (a.width || 0), b + (a.height || 0), c);
    },
    Is = function (a) {
      return a != null && a >= 0 && a <= 1;
    };
  function Js() {
    var a = Sb();
    return a
      ? ec(
          "AmazonWebAppPlatform;Android TV;Apple TV;AppleTV;BRAVIA;BeyondTV;Freebox;GoogleTV;HbbTV;LongTV;MiBOX;MiTV;NetCast.TV;Netcast;Opera TV;PANASONIC;POV_TV;SMART-TV;SMART_TV;SWTV;Smart TV;SmartTV;TV Store;UnionTV;Version/8.0 Safari/601.1 WPE;WebOS".split(
            ";"
          ),
          function (b) {
            return Pb(a, b);
          }
        ) ||
        (Pb(a, "OMI/") && !Pb(a, "XiaoMi/"))
        ? !0
        : Pb(a, "Presto") &&
          Pb(a, "Linux") &&
          !Pb(a, "X11") &&
          !Pb(a, "Android") &&
          !Pb(a, "Mobi")
      : !1;
  }
  function Ks() {
    var a = Sb();
    return (
      Pb(a, "AppleTV") ||
      Pb(a, "Apple TV") ||
      Pb(a, "CFNetwork") ||
      Pb(a, "tvOS")
    );
  }
  function Ls(a) {
    a = a.userAgentData;
    return Array.isArray(a == null ? void 0 : a.brands)
      ? a.brands.some(function (b) {
          return b.brand.includes("kepler_webview");
        })
      : Pb(Sb(), "Kepler");
  }
  function Ms() {
    var a;
    (a =
      (Pb(Sb(), "CrKey") && !(Pb(Sb(), "CrKey") && Pb(Sb(), "SmartSpeaker"))) ||
      Pb(Sb(), "PlayStation") ||
      Pb(Sb(), "Roku") ||
      Js() ||
      Pb(Sb(), "Xbox") ||
      Ks()) ||
      ((a = Sb()), (a = Pb(a, "sdk_google_atv_x86") || Pb(a, "Android TV")));
    return a;
  }
  var Os = function () {
      this.l = !Jj(P.top);
      this.B = Qj() || Pj();
      var a = sr();
      a =
        a.length > 0 && a[a.length - 1] != null && a[a.length - 1].url != null
          ? ((a = a[a.length - 1].url.match(eq)[3] || null)
              ? decodeURI(a)
              : a) || ""
          : "";
      this.domain = a;
      this.h = new L(0, 0, 0, 0);
      this.A = new Rk(0, 0);
      this.o = new Rk(0, 0);
      this.C = new L(0, 0, 0, 0);
      this.frameOffset = new Qk(0, 0);
      this.D = 0;
      this.F = !1;
      this.j = !(!P || !ys(P).Za);
      Ns(this);
    },
    Ps = function (a, b) {
      b && b.screen && (a.A = new Rk(b.screen.width, b.screen.height));
    },
    Qs = function (a, b) {
      a: {
        var c = a.h ? new Rk(a.h.getWidth(), a.h.getHeight()) : new Rk(0, 0);
        b = b === void 0 ? P : b;
        b !== null && b != b.top && (b = b.top);
        var d = 0,
          e = 0;
        try {
          var f = b.document,
            g = f.body,
            h = f.documentElement;
          if (f.compatMode == "CSS1Compat" && h.scrollHeight)
            (d = h.scrollHeight != c.height ? h.scrollHeight : h.offsetHeight),
              (e = h.scrollWidth != c.width ? h.scrollWidth : h.offsetWidth);
          else {
            var k = h.scrollHeight,
              l = h.scrollWidth,
              m = h.offsetHeight,
              p = h.offsetWidth;
            h.clientHeight != m &&
              ((k = g.scrollHeight),
              (l = g.scrollWidth),
              (m = g.offsetHeight),
              (p = g.offsetWidth));
            k > c.height
              ? k > m
                ? ((d = k), (e = l))
                : ((d = m), (e = p))
              : k < m
              ? ((d = k), (e = l))
              : ((d = m), (e = p));
          }
          var q = new Rk(e, d);
          break a;
        } catch (r) {
          q = new Rk(-12245933, -12245933);
          break a;
        }
        q = void 0;
      }
      a.o = q;
    },
    Ns = function (a) {
      P &&
        P.document &&
        ((a.C = As(!1, P, a.B)), (a.h = As(!0, P, a.B)), Qs(a, P), Ps(a, P));
    },
    Ss = function () {
      var a = Rs();
      if (a.D > 0 || a.F) return !0;
      a = Kr().j.isVisible();
      var b = xn(kr) === 0;
      return a || b;
    },
    Rs = function () {
      return M(Os);
    };
  var Ts = function (a) {
    this.l = a;
    this.j = 0;
    this.h = null;
  };
  Ts.prototype.cancel = function () {
    Kr().clearTimeout(this.h);
    this.h = null;
  };
  var Us = function (a) {
    var b = Kr(),
      c = hr().h.h;
    a.h = b.setTimeout(
      Qr(
        c,
        gs(143, function () {
          a.j++;
          a.l.sample();
        })
      ),
      ps()
    );
  };
  var Vs = function (a, b, c) {
    c = c === void 0 ? "na" : c;
    this.l = a;
    this.za = c;
    this.A = [];
    this.Ga = !1;
    this.o = new qs(-1, !0, this);
    this.h = this;
    this.F = b;
    this.N = !1;
    this.sampler = new Ts(this);
    this.V = !1;
    this.W = "uk";
    this.O = !1;
    this.B = !0;
  };
  Vs.prototype.H = function () {
    return !1;
  };
  Vs.prototype.initialize = function () {
    return (this.Ga = !0);
  };
  Vs.prototype.wc = function () {
    return this.h.W;
  };
  Vs.prototype.Wc = function () {
    return this.h.V;
  };
  var Xs = function (a, b, c) {
    if (!a.V || (c === void 0 ? 0 : c))
      (a.V = !0), (a.W = b), (a.F = 0), a.h != a || Ws(a);
  };
  Vs.prototype.getName = function () {
    return this.h.za;
  };
  Vs.prototype.Fb = function () {
    return this.h.Y();
  };
  Vs.prototype.Y = function () {
    return {};
  };
  Vs.prototype.qb = function () {
    return this.h.F;
  };
  var Ys = function (a, b) {
    kc(a.A, b) || (a.A.push(b), b.yc(a.h), b.Hb(a.o), b.nb() && (a.N = !0));
  };
  Vs.prototype.R = function () {
    var a = Rs();
    a.h = As(!0, this.l, a.B);
  };
  Vs.prototype.T = function () {
    Ps(Rs(), this.l);
  };
  Vs.prototype.ba = function () {
    return this.o.h;
  };
  var Zs = function (a) {
    a = a.h;
    a.T();
    a.R();
    var b = Rs();
    b.C = As(!1, a.l, b.B);
    Qs(Rs(), a.l);
    a.o.h = a.ba();
  };
  Vs.prototype.sample = function () {};
  Vs.prototype.isActive = function () {
    return this.h.B;
  };
  var $s = function (a) {
      a.N = a.A.length
        ? ec(a.A, function (b) {
            return b.nb();
          })
        : !1;
    },
    at = function (a) {
      var b = qc(a.A);
      Zb(b, function (c) {
        c.Hb(a.o);
      });
    },
    Ws = function (a) {
      var b = qc(a.A);
      Zb(b, function (c) {
        c.yc(a.h);
      });
      a.h != a || at(a);
    };
  n = Vs.prototype;
  n.yc = function (a) {
    var b = this.h;
    this.h = a.qb() >= this.F ? a : this;
    b !== this.h
      ? ((this.B = this.h.B), Ws(this))
      : this.B !== this.h.B && ((this.B = this.h.B), Ws(this));
  };
  n.Hb = function (a) {
    if (a.l === this.h) {
      var b = !this.o.equals(a, this.N);
      this.o = a;
      b && at(this);
    }
  };
  n.nb = function () {
    return this.N;
  };
  n.dispose = function () {
    this.O = !0;
  };
  n.Va = function () {
    return this.O;
  };
  var bt = function (a, b, c, d) {
    this.element = a;
    this.h = new L(0, 0, 0, 0);
    this.l = null;
    this.D = new L(0, 0, 0, 0);
    this.j = b;
    this.U = c;
    this.K = d;
    this.J = !1;
    this.timestamp = -1;
    this.N = new rs(
      b.o,
      this.element,
      this.h,
      new L(0, 0, 0, 0),
      0,
      0,
      os(),
      0
    );
    this.A = void 0;
  };
  bt.prototype.observe = function () {
    return !0;
  };
  bt.prototype.F = function () {};
  bt.prototype.dispose = function () {
    if (!this.Va()) {
      var a = this.j;
      lc(a.A, this);
      a.N && this.nb() && $s(a);
      this.F();
      this.J = !0;
    }
  };
  bt.prototype.Va = function () {
    return this.J;
  };
  var ct = function (a, b) {
    return a.A
      ? new L(
          Math.max(b.top + a.A.top, b.top),
          Math.min(b.left + a.A.right, b.right),
          Math.min(b.top + a.A.bottom, b.bottom),
          Math.max(b.left + a.A.left, b.left)
        )
      : yl(b);
  };
  n = bt.prototype;
  n.Fb = function () {
    return this.j.Fb();
  };
  n.qb = function () {
    return this.j.qb();
  };
  n.wc = function () {
    return this.j.wc();
  };
  n.Wc = function () {
    return this.j.Wc();
  };
  n.yc = function () {};
  n.Hb = function () {
    this.Ab();
  };
  n.nb = function () {
    return this.K;
  };
  var dt = function (a) {
    this.A = !1;
    this.h = a;
    this.o = function () {};
  };
  n = dt.prototype;
  n.qb = function () {
    return this.h.qb();
  };
  n.wc = function () {
    return this.h.wc();
  };
  n.Wc = function () {
    return this.h.Wc();
  };
  n.create = function (a, b, c) {
    var d = null;
    this.h && ((d = this.nd(a, b, c)), Ys(this.h, d));
    return d;
  };
  n.Qf = function () {
    return this.Ic();
  };
  n.Ic = function () {
    return !1;
  };
  n.init = function (a) {
    return this.h.initialize() ? (Ys(this.h, this), (this.o = a), !0) : !1;
  };
  n.yc = function (a) {
    a.qb() == 0 && this.o(a.wc(), this);
  };
  n.Hb = function () {};
  n.nb = function () {
    return !1;
  };
  n.dispose = function () {
    this.A = !0;
  };
  n.Va = function () {
    return this.A;
  };
  n.Fb = function () {
    return {};
  };
  var et = function (a, b, c) {
      this.l = c === void 0 ? 0 : c;
      this.j = a;
      this.h = b == null ? "" : b;
    },
    ft = function (a) {
      switch (Math.trunc(a.l)) {
        case -16:
          return -16;
        case -8:
          return -8;
        case 0:
          return 0;
        case 8:
          return 8;
        case 16:
          return 16;
        default:
          return 16;
      }
    },
    gt = function (a, b) {
      return a.l < b.l
        ? !0
        : a.l > b.l
        ? !1
        : a.j < b.j
        ? !0
        : a.j > b.j
        ? !1
        : typeof a.h < typeof b.h
        ? !0
        : typeof a.h > typeof b.h
        ? !1
        : a.h < b.h;
    };
  var ht = function () {
    this.l = 0;
    this.h = [];
    this.j = !1;
  };
  ht.prototype.add = function (a, b, c) {
    ++this.l;
    a = new et(a, b, c);
    this.h.push(new et(a.j, a.h, a.l + this.l / 4096));
    this.j = !0;
    return this;
  };
  var it = function (a, b) {
      Zb(b.h, function (c) {
        a.add(c.j, c.h, ft(c));
      });
    },
    jt = function (a, b) {
      var c = c === void 0 ? 0 : c;
      var d = d === void 0 ? !0 : d;
      Ij(b, function (e, f) {
        (d && e === void 0) || a.add(f, e, c);
      });
      return a;
    },
    lt = function (a) {
      var b = kt;
      a.j &&
        (sc(a.h, function (c, d) {
          return gt(d, c) ? 1 : gt(c, d) ? -1 : 0;
        }),
        (a.j = !1));
      return dc(
        a.h,
        function (c, d) {
          d = b(d);
          return "" + c + (c != "" && d != "" ? "&" : "") + d;
        },
        ""
      );
    };
  var kt = function (a) {
    var b = a.j;
    a = a.h;
    return a === ""
      ? b
      : typeof a === "boolean"
      ? a
        ? b
        : ""
      : Array.isArray(a)
      ? a.length === 0
        ? b
        : b + "=" + a.join()
      : b + "=" + (kc(["mtos", "tos", "p"], b) ? a : encodeURIComponent(a));
  };
  var mt = function (a) {
    var b = b === void 0 ? !0 : b;
    this.h = new ht();
    a !== void 0 && it(this.h, a);
    b && this.h.add("v", "unreleased", -16);
  };
  mt.prototype.toString = function () {
    var a = "//pagead2.googlesyndication.com//pagead/gen_204",
      b = lt(this.h);
    b.length > 0 && (a += "?" + b);
    return a;
  };
  var nt = function (a) {
      var b = [],
        c = [];
      Sk(a, function (d, e) {
        if (!(e in Object.prototype) && typeof d != "undefined")
          switch (
            (Array.isArray(d) && (d = d.join(",")),
            (d = [e, "=", d].join("")),
            e)
          ) {
            case "adk":
            case "r":
            case "tt":
            case "error":
            case "mtos":
            case "tos":
            case "p":
            case "bs":
              b.unshift(d);
              break;
            case "req":
            case "url":
            case "referrer":
            case "iframe_loc":
              c.push(d);
              break;
            default:
              b.push(d);
          }
      });
      return b.concat(c);
    },
    ot = function (a) {
      a = a.toString();
      Kr();
      Vl(P, a);
    };
  var pt = function () {
    this.h = 0;
  };
  function qt(a) {
    a && typeof a.dispose == "function" && a.dispose();
  }
  function R() {
    this.V = this.V;
    this.N = this.N;
  }
  R.prototype.V = !1;
  R.prototype.Va = function () {
    return this.V;
  };
  R.prototype.dispose = function () {
    this.V || ((this.V = !0), this.M());
  };
  R.prototype[Symbol.dispose] = function () {
    this.dispose();
  };
  var tt = function (a, b) {
      rt(a, lb(qt, b));
    },
    rt = function (a, b) {
      a.V ? b() : (a.N || (a.N = []), a.N.push(b));
    };
  R.prototype.M = function () {
    if (this.N) for (; this.N.length; ) this.N.shift()();
  };
  var ut = function (a, b, c) {
    Zb(a.l, function (d) {
      var e = a.h;
      if (!d.h && (d.l(b, c), d.o())) {
        d.h = !0;
        var f = d.j(),
          g = new ht();
        g.add("id", "av-js");
        g.add("type", "verif");
        g.add("vtype", d.A);
        d = M(pt);
        g.add("i", d.h++);
        g.add("adk", e);
        jt(g, f);
        e = new mt(g);
        ot(e);
      }
    });
  };
  var vt = function () {
      var a = a === void 0 ? 0 : a;
      var b = b === void 0 ? 0 : b;
      var c = c === void 0 ? 0 : c;
      this.h = 0;
      this.o = a;
      this.l = b;
      this.j = c;
    },
    wt = function (a, b, c, d) {
      d = d === void 0 ? !b : d;
      b && ((a.h += c), (a.j += c), (a.o += c), (a.l = Math.max(a.l, a.o)));
      d && (a.o = 0);
    };
  var xt = [1, 0.75, 0.5, 0.3, 0],
    yt = function (a) {
      this.j = a = a === void 0 ? xt : a;
      this.h = cc(this.j, function () {
        return new vt();
      });
    },
    At = function (a, b) {
      return zt(
        a,
        function (c) {
          return c.h;
        },
        b === void 0 ? !0 : b
      );
    },
    Ct = function (a, b) {
      return Bt(a, b, function (c) {
        return c.h;
      });
    },
    Dt = function (a, b) {
      return zt(
        a,
        function (c) {
          return c.l;
        },
        b === void 0 ? !0 : b
      );
    },
    Et = function (a, b) {
      return Bt(a, b, function (c) {
        return c.l;
      });
    },
    Ft = function (a, b) {
      return Bt(a, b, function (c) {
        return c.j;
      });
    },
    Gt = function (a) {
      Zb(a.h, function (b) {
        b.j = 0;
      });
    },
    Ht = function (a, b, c, d, e, f, g) {
      g = g === void 0 ? !0 : g;
      c = f ? Math.min(b, c) : c;
      for (f = 0; f < a.j.length; f++) {
        var h = a.j[f],
          k = c > 0 && c >= h;
        h = !(b > 0 && b >= h) || d;
        wt(a.h[f], g && k, e, !g || h);
      }
    },
    zt = function (a, b, c) {
      a = cc(a.h, function (d) {
        return b(d);
      });
      return c ? a : It(a);
    },
    Bt = function (a, b, c) {
      var d = jc(a.j, function (e) {
        return b <= e;
      });
      return d == -1 ? 0 : c(a.h[d]);
    },
    It = function (a) {
      return cc(a, function (b, c, d) {
        return c > 0 ? d[c] - d[c - 1] : d[c];
      });
    };
  var Jt = function () {
      this.j = new yt();
      this.ba = this.Y = 0;
      this.fa = new vt();
      this.J = this.B = -1;
      this.W = 1e3;
      this.sa = new yt([1, 0.9, 0.8, 0.7, 0.6, 0.5, 0.4, 0.3, 0.2, 0.1, 0]);
      this.R = this.K = -1;
    },
    Kt = function (a, b) {
      return Dt(a.j, b === void 0 ? !0 : b);
    };
  Jt.prototype.N = function (a, b, c, d) {
    this.B = this.B != -1 ? Math.min(this.B, b.aa) : b.aa;
    this.J = Math.max(this.J, b.aa);
    this.K = this.K != -1 ? Math.min(this.K, b.Ca) : b.Ca;
    this.R = Math.max(this.R, b.Ca);
    Ht(this.sa, b.Ca, c.Ca, b.h, a, d);
    this.Y += a;
    b.aa === 0 && (this.ba += a);
    Ht(this.j, b.aa, c.aa, b.h, a, d);
    c = d || c.Xb != b.Xb ? c.isVisible() && b.isVisible() : c.isVisible();
    b = !b.isVisible() || b.h;
    wt(this.fa, c, a, b);
  };
  Jt.prototype.sb = function () {
    return this.fa.l >= this.W;
  };
  if (kr && kr.URL) {
    var Lt = kr.URL,
      Mt;
    a: {
      if (Lt) {
        var Nt = RegExp(".*[&#?]google_debug(=[^&]*)?(&.*)?$");
        try {
          var Ot = Nt.exec(decodeURIComponent(Lt));
          if (Ot) {
            Mt = Ot[1] && Ot[1].length > 1 ? Ot[1].substring(1) : "true";
            break a;
          }
        } catch (a) {}
      }
      Mt = "";
    }
    cs.wf(!(Mt.length > 0));
  }
  var Pt = function (a, b, c, d) {
    var e = e === void 0 ? !1 : e;
    c = gs(d, c);
    Tl(a, b, c, { capture: e });
  };
  var Qt = new L(0, 0, 0, 0);
  function Rt(a, b) {
    b = St(b);
    return b === 0 ? 0 : St(a) / b;
  }
  function St(a) {
    return Math.max(a.bottom - a.top, 0) * Math.max(a.right - a.left, 0);
  }
  function Tt(a, b) {
    if (!a || !b) return !1;
    for (var c = 0; a !== null && c++ < 100; ) {
      if (a === b) return !0;
      try {
        if ((a = a.parentElement || a)) {
          var d = il(a),
            e = d && ol(d),
            f = e && e.frameElement;
          f && (a = f);
        }
      } catch (g) {
        break;
      }
    }
    return !1;
  }
  function Ut(a, b, c) {
    if (!a || !b) return !1;
    b = Al(yl(a), -b.left, -b.top);
    a = (b.left + b.right) / 2;
    b = (b.top + b.bottom) / 2;
    Jj(window.top) &&
      window.top &&
      window.top.document &&
      (window = window.top);
    if (!zs()) return !1;
    a = window.document.elementFromPoint(a, b);
    if (!a) return !1;
    b =
      (b = (b = il(c)) && b.defaultView && b.defaultView.frameElement) &&
      Tt(b, a);
    var d = a === c;
    a =
      !d &&
      a &&
      wl(a, function (e) {
        return e === c;
      });
    return !(b || d || a);
  }
  function Vt(a, b, c, d) {
    return Rs().l
      ? !1
      : a.getWidth() <= 0 || a.getHeight() <= 0
      ? !0
      : c && d
      ? fs(208, function () {
          return Ut(a, b, c);
        })
      : !1;
  }
  var Wt = new L(0, 0, 0, 0),
    Yt = function (a, b, c) {
      R.call(this);
      this.position = yl(Wt);
      this.Ud = this.Bd();
      this.Pe = -2;
      this.jk = Date.now();
      this.ph = -1;
      this.Kd = b;
      this.Jd = null;
      this.Qc = !1;
      this.Zd = null;
      this.opacity = -1;
      this.Tj = c;
      this.mk = !1;
      this.Re = function () {};
      this.qh = function () {};
      this.Fa = new mr();
      this.Fa.Jb = a;
      this.Fa.h = a;
      this.rb = !1;
      this.Ub = { Ve: null, Ue: null };
      this.gh = !0;
      this.md = null;
      this.Ac = this.nj = !1;
      hr().D++;
      this.xa = this.Ie();
      this.oh = -1;
      this.Z = null;
      this.Ag = this.ij = !1;
      this.U = new ar();
      jr(this.U);
      Xt(this);
      this.Tj == 1 ? dr(this.U, "od", 1) : dr(this.U, "od", 0);
    };
  w(Yt, R);
  Yt.prototype.M = function () {
    this.Fa.h &&
      (this.Ub.Ve &&
        (Ul(this.Fa.h, "mouseover", this.Ub.Ve), (this.Ub.Ve = null)),
      this.Ub.Ue &&
        (Ul(this.Fa.h, "mouseout", this.Ub.Ue), (this.Ub.Ue = null)));
    this.md && this.md.dispose();
    this.Z && this.Z.dispose();
    delete this.Ud;
    delete this.Re;
    delete this.qh;
    delete this.Fa.Jb;
    delete this.Fa.h;
    delete this.Ub;
    delete this.md;
    delete this.Z;
    delete this.U;
    R.prototype.M.call(this);
  };
  Yt.prototype.Gb = function () {
    return this.Z ? this.Z.h : this.position;
  };
  Yt.prototype.hf = function (a) {
    hr().hf(a);
  };
  var Xt = function (a) {
    a = a.Fa.Jb;
    var b;
    if ((b = a && a.getAttribute))
      b = /-[a-z]/.test("googleAvInapp")
        ? !1
        : lr && a.dataset
        ? "googleAvInapp" in a.dataset
        : a.hasAttribute
        ? a.hasAttribute("data-" + xk())
        : !!a.getAttribute("data-" + xk());
    b && (Rs().j = !0);
  };
  Yt.prototype.nb = function () {
    return !1;
  };
  Yt.prototype.Bd = function () {
    return new Jt();
  };
  Yt.prototype.wa = function () {
    return this.Ud;
  };
  var Zt = function (a, b) {
      b != a.Ac && ((a.Ac = b), (a = Rs()), b ? a.D++ : a.D > 0 && a.D--);
    },
    $t = function (a, b) {
      if (a.Z) {
        if (b.getName() === a.Z.getName()) return;
        a.Z.dispose();
        a.Z = null;
      }
      b = b.create(a.Fa.h, a.U, a.nb());
      if ((b = b != null && b.observe() ? b : null)) a.Z = b;
    },
    au = function (a, b, c) {
      if (
        !a.Jd ||
        a.Kd == -1 ||
        b.getTimestamp() === -1 ||
        a.Jd.getTimestamp() === -1
      )
        return 0;
      a = b.getTimestamp() - a.Jd.getTimestamp();
      return a > c ? 0 : a;
    };
  Yt.prototype.xg = function (a) {
    return au(this, a, 1e4);
  };
  var bu = function (a, b, c) {
      if (a.Z) {
        a.Z.Ab();
        var d = a.Z.N,
          e = d.l,
          f = e.h;
        if (d.A != null) {
          var g = d.j;
          a.Zd = new Qk(g.left - f.left, g.top - f.top);
        }
        f = a.ie() ? Math.max(d.h, d.o) : d.h;
        g = {};
        e.volume !== null && (g.volume = e.volume);
        e = a.xg(d);
        a.Jd = d;
        a.Ff(f, b, c, !1, g, e, d.D);
      }
    },
    cu = function (a) {
      if (a.Qc && a.md) {
        var b = er(a.U, "od") == 1,
          c = Rs().h,
          d = a.md,
          e = a.Z ? a.Z.getName() : "ns",
          f = a.Zd,
          g = new Rk(c.getWidth(), c.getHeight());
        c = a.ie();
        a = { ik: e, Zd: f, vk: g, ie: c, aa: a.xa.aa, rk: b };
        if ((b = d.j)) {
          b.Ab();
          e = b.N;
          f = e.l.h;
          var h = (g = null);
          e.A != null &&
            f &&
            ((g = e.j),
            (g = new Qk(g.left - f.left, g.top - f.top)),
            (h = new Rk(f.right - f.left, f.bottom - f.top)));
          e = c ? Math.max(e.h, e.o) : e.h;
          c = { ik: b.getName(), Zd: g, vk: h, ie: c, rk: !1, aa: e };
        } else c = null;
        c && ut(d, a, c);
      }
    };
  n = Yt.prototype;
  n.Ff = function (a, b, c, d, e, f, g) {
    this.rb ||
      (this.Qc &&
        ((a = this.te(a, c, e, g)),
        (d = d && this.xa.aa >= (this.Xb() ? 0.3 : 0.5)),
        this.Gf(f, a, d),
        (this.Kd = b),
        a.aa > 0 && -1 === this.oh && (this.oh = b),
        this.ph == -1 && this.sb() && (this.ph = b),
        this.Pe == -2 && (this.Pe = St(this.Gb()) ? a.aa : -1),
        (this.xa = a)),
      this.Re(this));
  };
  n.Gf = function (a, b, c) {
    this.wa().N(a, b, this.xa, c);
  };
  n.Ie = function () {
    return new Pq();
  };
  n.te = function (a, b, c, d) {
    c = this.Ie();
    c.h = b;
    b = Kr().j;
    b = xn(kr) === 0 ? -1 : b.isVisible() ? 0 : 1;
    c.j = b;
    c.aa = this.we(a);
    c.Xb = this.Xb();
    c.Ca = d;
    return c;
  };
  n.we = function (a) {
    return this.opacity === 0 && er(this.U, "opac") === 1 ? 0 : a;
  };
  n.Xb = function () {
    return !1;
  };
  n.ie = function () {
    return this.ij || this.nj;
  };
  n.Pa = function () {
    return 0;
  };
  n.sb = function () {
    return this.Ud.sb();
  };
  n.zg = function () {
    var a = this.Qc;
    a = (this.Ag || this.Va()) && !a;
    var b = hr().j !== 2 || this.mk;
    return this.rb || (b && a) ? 2 : this.sb() ? 4 : 3;
  };
  n.zd = function () {
    return 0;
  };
  var du = function (a, b, c) {
    b && (a.Re = b);
    c && (a.qh = c);
  };
  var eu = function () {
      var a = a === void 0 ? 0 : a;
      var b = b === void 0 ? 0 : b;
      var c = c === void 0 ? 0 : c;
      var d = d === void 0 ? 0 : d;
      this.A = 0;
      this.j = a;
      this.l = b;
      this.h = d;
      this.o = c;
    },
    fu = function (a) {
      var b = {};
      b = ((b.ptlt = Date.now() - a.A), b);
      var c = a.j;
      c && (b.pnk = c);
      (c = a.l) && (b.pnc = c);
      (c = a.o) && (b.pnmm = c);
      (a = a.h) && (b.pns = a);
      return b;
    };
  var gu = function () {
    Pq.call(this);
    this.fullscreen = !1;
    this.volume = void 0;
    this.paused = !1;
    this.mediaTime = -1;
  };
  w(gu, Pq);
  var hu = function (a) {
    return Is(a.volume) && a.volume > 0;
  };
  var ju = function (a, b, c, d) {
      c = c === void 0 ? !0 : c;
      d =
        d === void 0
          ? function () {
              return !0;
            }
          : d;
      return function (e) {
        var f = e[a];
        if (Array.isArray(f) && d(e)) return iu(f, b, c);
      };
    },
    ku = function (a, b) {
      return function (c) {
        return b(c) ? c[a] : void 0;
      };
    },
    lu = function (a) {
      return function (b) {
        for (var c = 0; c < a.length; c++)
          if (a[c] === b.e || (a[c] === void 0 && !b.hasOwnProperty("e")))
            return !0;
        return !1;
      };
    },
    iu = function (a, b, c) {
      return c === void 0 || c
        ? bc(a, function (d, e) {
            return kc(b, e);
          })
        : cc(b, function (d, e, f) {
            return a
              .slice(e > 0 ? f[e - 1] + 1 : 0, d + 1)
              .reduce(function (g, h) {
                return g + h;
              }, 0);
          });
    };
  var mu = lu([void 0, 1, 2, 3, 4, 8, 16]),
    nu = lu([void 0, 4, 8, 16]),
    ou = {
      sv: "sv",
      v: "v",
      cb: "cb",
      e: "e",
      nas: "nas",
      msg: "msg",
      if: "if",
      sdk: "sdk",
      p: "p",
      p0: ku("p0", nu),
      p1: ku("p1", nu),
      p2: ku("p2", nu),
      p3: ku("p3", nu),
      cp: "cp",
      tos: "tos",
      mtos: "mtos",
      amtos: "amtos",
      mtos1: ju("mtos1", [0, 2, 4], !1, nu),
      mtos2: ju("mtos2", [0, 2, 4], !1, nu),
      mtos3: ju("mtos3", [0, 2, 4], !1, nu),
      mcvt: "mcvt",
      ps: "ps",
      scs: "scs",
      bs: "bs",
      vht: "vht",
      mut: "mut",
      a: "a",
      a0: ku("a0", nu),
      a1: ku("a1", nu),
      a2: ku("a2", nu),
      a3: ku("a3", nu),
      ft: "ft",
      dft: "dft",
      at: "at",
      dat: "dat",
      as: "as",
      vpt: "vpt",
      gmm: "gmm",
      std: "std",
      efpf: "efpf",
      swf: "swf",
      nio: "nio",
      px: "px",
      nnut: "nnut",
      vmer: "vmer",
      vmmk: "vmmk",
      vmiec: "vmiec",
      nmt: "nmt",
      tcm: "tcm",
      bt: "bt",
      pst: "pst",
      vpaid: "vpaid",
      dur: "dur",
      vmtime: "vmtime",
      dtos: "dtos",
      dtoss: "dtoss",
      dvs: "dvs",
      dfvs: "dfvs",
      dvpt: "dvpt",
      fmf: "fmf",
      vds: "vds",
      is: "is",
      i0: "i0",
      i1: "i1",
      i2: "i2",
      i3: "i3",
      ic: "ic",
      cs: "cs",
      c: "c",
      c0: ku("c0", nu),
      c1: ku("c1", nu),
      c2: ku("c2", nu),
      c3: ku("c3", nu),
      mc: "mc",
      nc: "nc",
      mv: "mv",
      nv: "nv",
      qmt: ku("qmtos", mu),
      qnc: ku("qnc", mu),
      qmv: ku("qmv", mu),
      qnv: ku("qnv", mu),
      raf: "raf",
      rafc: "rafc",
      lte: "lte",
      ces: "ces",
      tth: "tth",
      femt: "femt",
      femvt: "femvt",
      emc: "emc",
      emuc: "emuc",
      emb: "emb",
      avms: "avms",
      nvat: "nvat",
      qi: "qi",
      psm: "psm",
      psv: "psv",
      psfv: "psfv",
      psa: "psa",
      pnk: "pnk",
      pnc: "pnc",
      pnmm: "pnmm",
      pns: "pns",
      ptlt: "ptlt",
      pngs: "pings",
      veid: "veid",
      ssb: "ssb",
      ss0: ku("ss0", nu),
      ss1: ku("ss1", nu),
      ss2: ku("ss2", nu),
      ss3: ku("ss3", nu),
      dc_rfl: "urlsigs",
      obd: "obd",
      omidp: "omidp",
      omidr: "omidr",
      omidv: "omidv",
      omida: "omida",
      omids: "omids",
      omidpv: "omidpv",
      omidam: "omidam",
      omidct: "omidct",
      omidia: "omidia",
      omiddc: "omiddc",
      omidlat: "omidlat",
      omiddit: "omiddit",
      nopd: "nopd",
      co: "co",
      tm: "tm",
      tu: "tu",
    },
    pu = Object.assign({}, ou, {
      avid: (function (a) {
        return function () {
          return a;
        };
      })("audio"),
      avas: "avas",
      vs: "vs",
    }),
    qu = {
      atos: "atos",
      avt: ju("atos", [2]),
      davs: "davs",
      dafvs: "dafvs",
      dav: "dav",
      ss: (function (a, b) {
        return function (c) {
          return c[a] === void 0 && b !== void 0 ? b : c[a];
        };
      })("ss", 0),
      t: "t",
    };
  var ru = function () {
    this.j = this.h = "";
  };
  var tu = function () {},
    uu = function (a, b) {
      var c = {};
      if (a !== void 0)
        if (b != null)
          for (var d in b) {
            var e = b[d];
            d in Object.prototype ||
              (e != null && (c[d] = typeof e === "function" ? e(a) : a[e]));
          }
        else gl(c, a);
      return lt(jt(new ht(), c));
    };
  var vu = function () {
      var a = {};
      this.j =
        ((a.vs = [1, 0]),
        (a.vw = [0, 1]),
        (a.am = [2, 2]),
        (a.a = [4, 4]),
        (a.f = [8, 8]),
        (a.bm = [16, 16]),
        (a.b = [32, 32]),
        (a.avw = [0, 64]),
        (a.avs = [64, 0]),
        (a.pv = [256, 256]),
        (a.gdr = [0, 512]),
        (a.p = [0, 1024]),
        (a.r = [0, 2048]),
        (a.m = [0, 4096]),
        (a.um = [0, 8192]),
        (a.ef = [0, 16384]),
        (a.s = [0, 32768]),
        (a.pmx = [0, 16777216]),
        (a.mut = [33554432, 33554432]),
        (a.umutb = [67108864, 67108864]),
        (a.tvoff = [134217728, 134217728]),
        (a.yt1sv = [268435456, 268435456]),
        a);
      this.h = {};
      for (var b in this.j) this.j[b][1] > 0 && (this.h[b] = 0);
      this.l = 0;
    },
    wu = function (a, b) {
      var c = a.j[b],
        d = c[1];
      a.l += c[0];
      d > 0 && a.h[b] == 0 && (a.h[b] = 1);
    },
    xu = function (a) {
      var b = Xk(a.j),
        c = 0,
        d;
      for (d in a.h)
        kc(b, d) && a.h[d] == 1 && ((c += a.j[d][1]), (a.h[d] = 2));
      return c;
    },
    yu = function (a) {
      var b = 0,
        c;
      for (c in a.h) {
        var d = a.h[c];
        if (d == 1 || d == 2) b += a.j[c][1];
      }
      return b;
    };
  var zu = function () {
    this.h = this.j = 0;
  };
  zu.prototype.getValue = function () {
    return this.j;
  };
  var Au = function (a, b, c) {
    b >= 32 ||
      (a.h & (1 << b) && !c
        ? (a.j &= ~(1 << b))
        : a.h & (1 << b) || !c || (a.j |= 1 << b),
      (a.h |= 1 << b));
  };
  var Bu = function () {
    Jt.call(this);
    this.l = new vt();
    this.da = this.H = this.O = 0;
    this.F = -1;
    this.va = new vt();
    this.A = new vt();
    this.h = new yt();
    this.D = this.o = -1;
    this.V = new vt();
    this.W = 2e3;
    this.T = new zu();
    this.oa = new zu();
    this.za = new zu();
  };
  w(Bu, Jt);
  Bu.prototype.C = function (a) {
    this.W = a;
  };
  var Cu = function (a, b, c) {
    var d = a.da;
    ns || c || a.F == -1 || (d += b - a.F);
    return d;
  };
  Bu.prototype.N = function (a, b, c, d) {
    if (!b.paused) {
      Jt.prototype.N.call(this, a, b, c, d);
      var e = hu(b) && hu(c),
        f = (d ? Math.min(b.aa, c.aa) : c.aa) >= 0.5;
      Is(b.volume) &&
        ((this.o = this.o != -1 ? Math.min(this.o, b.volume) : b.volume),
        (this.D = Math.max(this.D, b.volume)));
      f && ((this.O += a), (this.H += e ? a : 0));
      Ht(this.h, b.aa, c.aa, b.h, a, d, e);
      wt(this.l, !0, a);
      wt(this.A, e, a);
      wt(this.V, c.fullscreen, a);
      wt(this.va, e && !f, a);
      a = Math.floor(b.mediaTime / 1e3);
      Au(this.T, a, b.isVisible());
      Au(this.oa, a, b.aa >= 1);
      Au(this.za, a, hu(b));
    }
  };
  var Du = function () {
    this.l = !1;
  };
  Du.prototype.j = function (a) {
    this.l ||
      (this.h(a)
        ? ((a = this.F.report(this.o, a)), (this.A |= a), (a = a == 0))
        : (a = !1),
      (this.l = a));
  };
  var Eu = function (a, b) {
    this.l = !1;
    this.o = a;
    this.F = b;
    this.A = 0;
  };
  w(Eu, Du);
  Eu.prototype.h = function () {
    return !0;
  };
  Eu.prototype.D = function () {
    return !1;
  };
  Eu.prototype.getId = function () {
    var a = this,
      b = al(function (c) {
        return c == a.o;
      });
    return xs[b].toString();
  };
  Eu.prototype.toString = function () {
    var a = "";
    this.D() && (a += "c");
    this.l && (a += "s");
    this.A > 0 && (a += ":" + this.A);
    return this.getId() + a;
  };
  var Fu = function (a, b) {
    Eu.call(this, a, b);
    this.B = [];
  };
  w(Fu, Eu);
  Fu.prototype.j = function (a, b) {
    b = b === void 0 ? null : b;
    b != null && this.B.push(b);
    Eu.prototype.j.call(this, a);
  };
  var Gu = function () {};
  var Hu = function () {};
  w(Hu, Gu);
  Hu.prototype.j = function () {
    return null;
  };
  Hu.prototype.l = function () {
    return [];
  };
  var Iu = function (a, b, c, d) {
    bt.call(this, a, b, c, d);
  };
  w(Iu, bt);
  n = Iu.prototype;
  n.ue = function () {
    if (this.element) {
      var a = this.element,
        b = this.j.h.l;
      try {
        try {
          var c = Gs(a.getBoundingClientRect());
        } catch (l) {
          c = new L(0, 0, 0, 0);
        }
        var d = c.right - c.left,
          e = c.bottom - c.top,
          f = Ml(a, b),
          g = f.x,
          h = f.y;
        var k = new L(
          Math.round(h),
          Math.round(g + d),
          Math.round(h + e),
          Math.round(g)
        );
      } catch (l) {
        k = yl(Qt);
      }
      this.l = k;
      this.h = ct(this, this.l);
    }
  };
  n.ag = function () {
    this.D = this.j.o.h;
  };
  n.Dg = function (a) {
    var b = er(this.U, "od") == 1;
    return Vt(a, this.D, this.element, b);
  };
  n.bg = function () {
    this.timestamp = os();
  };
  n.Ab = function () {
    this.bg();
    this.ue();
    if (
      this.element &&
      typeof this.element.videoWidth === "number" &&
      typeof this.element.videoHeight === "number"
    ) {
      var a = this.element;
      var b = new Rk(a.videoWidth, a.videoHeight);
      a = this.h;
      var c = a.getWidth(),
        d = a.getHeight(),
        e = b.width;
      b = b.height;
      e <= 0 ||
        b <= 0 ||
        c <= 0 ||
        d <= 0 ||
        ((e /= b),
        (a = yl(a)),
        e > c / d
          ? ((c /= e),
            (d = (d - c) / 2),
            d > 0 &&
              ((d = a.top + d),
              (a.top = Math.round(d)),
              (a.bottom = Math.round(d + c))))
          : ((d *= e),
            (c = Math.round((c - d) / 2)),
            c > 0 &&
              ((c = a.left + c),
              (a.left = Math.round(c)),
              (a.right = Math.round(c + d)))));
      this.h = a;
    }
    this.ag();
    a = this.h;
    c = this.D;
    a =
      a.left <= c.right &&
      c.left <= a.right &&
      a.top <= c.bottom &&
      c.top <= a.bottom
        ? new L(
            Math.max(a.top, c.top),
            Math.min(a.right, c.right),
            Math.min(a.bottom, c.bottom),
            Math.max(a.left, c.left)
          )
        : new L(0, 0, 0, 0);
    c = a.top >= a.bottom || a.left >= a.right ? new L(0, 0, 0, 0) : a;
    a = this.j.o;
    b = e = d = 0;
    if ((this.h.bottom - this.h.top) * (this.h.right - this.h.left) > 0)
      if (this.Dg(c)) c = new L(0, 0, 0, 0);
      else {
        d = Rs().A;
        b = new L(0, d.height, d.width, 0);
        var f;
        d = Rt(c, (f = this.A) != null ? f : this.h);
        e = Rt(c, Rs().h);
        b = Rt(c, b);
      }
    f =
      c.top >= c.bottom || c.left >= c.right
        ? new L(0, 0, 0, 0)
        : Al(c, -this.h.left, -this.h.top);
    Ss() || (e = d = 0);
    this.N = new rs(a, this.element, this.h, f, d, e, this.timestamp, b);
  };
  n.getName = function () {
    return this.j.getName();
  };
  var Ju = new L(0, 0, 0, 0),
    Ku = function (a, b, c) {
      bt.call(this, null, a, b, c);
      this.C = a.isActive();
      this.B = 0;
    };
  w(Ku, Iu);
  n = Ku.prototype;
  n.observe = function () {
    this.o();
    return !0;
  };
  n.Hb = function () {
    Iu.prototype.Ab.call(this);
  };
  n.bg = function () {};
  n.ue = function () {};
  n.Ab = function () {
    this.o();
    Iu.prototype.Ab.call(this);
  };
  n.yc = function (a) {
    a = a.isActive();
    a !== this.C &&
      (a
        ? this.o()
        : ((Rs().h = new L(0, 0, 0, 0)),
          (this.h = new L(0, 0, 0, 0)),
          (this.D = new L(0, 0, 0, 0)),
          (this.timestamp = -1)));
    this.C = a;
  };
  function Lu(a) {
    return [a.top, a.left, a.bottom, a.right];
  }
  var Mu = {},
    Nu =
      ((Mu.firstquartile = 0),
      (Mu.midpoint = 1),
      (Mu.thirdquartile = 2),
      (Mu.complete = 3),
      Mu),
    Ou = function (a, b, c, d, e, f) {
      f = f === void 0 ? new Hu() : f;
      Yt.call(this, b, c, d);
      this.gf = e;
      this.Be = 0;
      this.qa = {};
      this.na = new vu();
      this.zh = {};
      this.ua = "";
      this.Lb = null;
      this.fb = !1;
      this.h = [];
      this.tb = f.j();
      this.B = f.l();
      this.A = null;
      this.l = -1;
      this.J = this.H = void 0;
      this.za = !1;
      this.O = this.K = 0;
      this.T = -1;
      this.sa = this.oa = !1;
      this.R = this.F = this.j = this.Hc = this.Ta = 0;
      new yt();
      this.W = this.da = 0;
      this.fa = -1;
      this.ta = 0;
      this.C = Lj;
      this.D = [this.Bd()];
      this.Nc = 2;
      this.lc = {};
      this.lc.pause = "p";
      this.lc.resume = "r";
      this.lc.skip = "s";
      this.lc.mute = "m";
      this.lc.unmute = "um";
      this.lc.exitfullscreen = "ef";
      this.o = null;
      this.va = this.ba = !1;
      this.ob = Math.floor(Date.now() / 1e3 - 1704067200);
      this.Y = 0;
    };
  w(Ou, Yt);
  var Pu = function (a, b) {
    var c = (a.za = b) ? 1e3 : 2e3;
    (b = a.wa()) && b.C && b.C(c);
    a.D &&
      a.D.forEach(function (d) {
        d && d.C && d.C(c);
      });
  };
  Ou.prototype.nb = function () {
    return !0;
  };
  var Qu = function (a) {
      a.Ag = !0;
      a.ta != 0 && (a.ta = 3);
    },
    Ru = function (a) {
      return a === void 0 ? a : Number(a) ? Bs(a, 3) : 0;
    };
  n = Ou.prototype;
  n.xg = function (a) {
    return au(this, a, Math.max(1e4, this.l / 3));
  };
  n.Ff = function (a, b, c, d, e, f, g) {
    var h = this,
      k = this.C(this) || {};
    gl(k, e);
    this.l = k.duration || this.l;
    this.H = k.isVpaid || this.H;
    this.J = k.isYouTube || this.J;
    Kr();
    this.va = !1;
    e = Su(this, b);
    Tu(this) === 1 && (f = e);
    Yt.prototype.Ff.call(this, a, b, c, d, k, f, g);
    this.tb &&
      this.tb.l &&
      Zb(this.B, function (l) {
        l.j(h);
      });
  };
  n.Gf = function (a, b, c) {
    Yt.prototype.Gf.call(this, a, b, c);
    Uu(this).N(a, b, this.xa, c);
    this.sa = hu(this.xa) && hu(b);
    this.T == -1 && this.oa && (this.T = this.wa().l.h);
    this.na.l = 0;
    a = this.sb();
    b.isVisible() && wu(this.na, "vs");
    a && wu(this.na, "vw");
    Is(b.volume) && wu(this.na, "am");
    hu(b) ? wu(this.na, "a") : wu(this.na, "mut");
    this.Ac && wu(this.na, "f");
    b.j != -1 &&
      (wu(this.na, "bm"),
      b.j == 1 && (wu(this.na, "b"), hu(b) && wu(this.na, "umutb")));
    hu(b) && b.isVisible() && wu(this.na, "avs");
    this.sa && a && wu(this.na, "avw");
    b.aa > 0 && wu(this.na, "pv");
    Vu(this, this.wa().l.h, !0) && wu(this.na, "gdr");
    Et(this.wa().j, 1) >= 2e3 && wu(this.na, "pmx");
    this.va && wu(this.na, "tvoff");
    this.za && a && wu(this.na, "yt1sv");
  };
  n.Bd = function () {
    var a = new Bu();
    this && this.za && a.C(1e3);
    return a;
  };
  n.wa = function () {
    return this.Ud;
  };
  var Uu = function (a, b) {
    return a.D[b != null && b < a.D.length ? b : a.D.length - 1];
  };
  Ou.prototype.Ie = function () {
    return new gu();
  };
  Ou.prototype.te = function (a, b, c, d) {
    a = Yt.prototype.te.call(this, a, b, c, d === void 0 ? -1 : d);
    a.fullscreen = this.Ac;
    a.paused = this.ta == 2;
    a.volume = c.volume;
    Is(a.volume) ||
      (this.Ta++, (b = this.xa), Is(b.volume) && (a.volume = b.volume));
    c = c.currentTime;
    a.mediaTime = c !== void 0 && c >= 0 ? c : -1;
    return a;
  };
  var Tu = function (a) {
      var b = !!er(hr().U, "umt");
      return a.H || (!b && !a.J) ? 0 : 1;
    },
    Su = function (a, b) {
      a.ta == 2
        ? (b = 0)
        : a.Kd == -1
        ? (b = 0)
        : ((b -= a.Kd), (b = b > Math.max(1e4, a.l / 3) ? 0 : b));
      var c = a.C(a) || {};
      c = c.currentTime !== void 0 ? c.currentTime : a.K;
      var d = c - a.K,
        e = 0;
      d >= 0
        ? ((a.O += b), (a.W += Math.max(b - d, 0)), (e = Math.min(d, a.O)))
        : (a.da += Math.abs(d));
      d != 0 && (a.O = 0);
      a.fa == -1 && d > 0 && (a.fa = ms >= 0 ? os() - ms : -1);
      a.K = c;
      return e;
    };
  Ou.prototype.we = function (a) {
    return Rs(), this.Ac ? 1 : Yt.prototype.we.call(this, a);
  };
  Ou.prototype.Pa = function () {
    return 1;
  };
  Ou.prototype.getDuration = function () {
    return this.l;
  };
  var Wu = function (a, b) {
      ec(a.B, function (c) {
        return c.o == b.o;
      }) || a.B.push(b);
    },
    Xu = function (a) {
      var b = Ct(a.wa().h, 1);
      return Vu(a, b);
    },
    Vu = function (a, b, c) {
      return b >= 15e3
        ? !0
        : a.oa
        ? (c === void 0 ? 0 : c)
          ? !0
          : a.l > 0
          ? b >= a.l / 2
          : a.T > 0
          ? b >= a.T
          : !1
        : !1;
    },
    Yu = function (a) {
      var b = {},
        c = Rs();
      b.insideIframe = c.l;
      b.unmeasurable = a.rb;
      var d = a.Gb(),
        e = a.Z ? a.Z.l : null;
      b.position = d;
      e && !zl(d, e) && (b.containerPosition = e);
      b.exposure = a.xa.aa;
      b.documentSize = c.o;
      b.viewportSize = new Rk(c.h.getWidth(), c.h.getHeight());
      a.o != null && (b.presenceData = a.o);
      b.screenShare = a.xa.Ca;
      return b;
    },
    Zu = function (a) {
      var b = Bs(a.xa.aa, 2),
        c = a.na.l,
        d = a.xa,
        e = Uu(a),
        f = Ru(e.o),
        g = Ru(e.D),
        h = Ru(d.volume),
        k = Bs(e.B, 2),
        l = Bs(e.J, 2),
        m = Bs(d.aa, 2),
        p = Bs(e.K, 2),
        q = Bs(e.R, 2);
      d = Bs(d.Ca, 2);
      var r = yl(a.Gb()).round();
      a = a.Z && a.Z.l ? yl(a.Z ? a.Z.l : null).round() : null;
      e = Kt(e, !1);
      return {
        uk: b,
        Yc: c,
        Vd: f,
        Rd: g,
        audioVolume: h,
        Wd: k,
        Sd: l,
        aa: m,
        Xd: p,
        Td: q,
        Ca: d,
        position: r,
        Oc: a,
        Yd: e,
      };
    },
    av = function (a, b) {
      $u(a.h, b, function () {
        return {
          uk: 0,
          Yc: void 0,
          Vd: -1,
          Rd: -1,
          audioVolume: -1,
          Wd: -1,
          Sd: -1,
          aa: -1,
          Xd: -1,
          Td: -1,
          Ca: -1,
          position: void 0,
          Oc: void 0,
          Yd: [],
        };
      });
      a.h[b] = Zu(a);
    },
    bv = function (a, b) {
      b != 4 &&
        $u(a.D, b, function () {
          return a.Bd();
        });
    },
    $u = function (a, b, c) {
      for (var d = a.length; d < b + 1; ) a.push(c()), d++;
    },
    ev = function (a, b, c) {
      var d = a.zh[b];
      if (d != null) return d;
      d = cv(a, b);
      var e = al(function (f) {
        return f == b;
      });
      a = dv(a, d, d, c, Nu[bl[e]]);
      b == "fully_viewable_audible_half_duration_impression" && (a.std = "csm");
      return a;
    },
    fv = function (a, b, c) {
      var d = [b];
      if (a != b || c != b) d.unshift(a), d.push(c);
      return d;
    },
    dv = function (a, b, c, d, e) {
      if (a.rb) return { if: 0, vs: 0 };
      var f = yl(a.Gb()).round(),
        g = a.Z ? a.Z.l : null,
        h = Rs(),
        k = hr(),
        l = a.wa(),
        m = a.Z ? a.Z.getName() : "ns",
        p = {};
      p["if"] = h.l ? 1 : void 0;
      p.sdk = a.A ? a.A : void 0;
      p.t = a.jk;
      p.p = [f.top, f.left, f.bottom, f.right];
      f &&
        g &&
        !zl(g, f) &&
        ((f = g.round()), (p.cp = [f.top, f.left, f.bottom, f.right]));
      p.tos = At(l.j, !1);
      p.mtos = Kt(l);
      p.mcvt = l.fa.l;
      p.ps = void 0;
      p.vht = Cu(l, os(), a.ta == 2);
      p.mut = l.va.l;
      p.a = Ru(a.xa.volume);
      p.mv = Ru(l.D);
      p.fs = a.Ac ? 1 : 0;
      p.ft = l.V.h;
      p.at = l.A.h;
      p.as = l.o > 0 ? 1 : 0;
      p.atos = At(l.h);
      p.ssb = At(l.sa, !1);
      p.amtos = Dt(l.h, !1);
      p.uac = a.Ta;
      p.vpt = l.l.h;
      m == "nio" && ((p.nio = 1), (p.avms = "nio"));
      p.gmm = "4";
      p.gdr = Vu(a, l.l.h, !0) ? 1 : 0;
      p.efpf = a.Nc;
      if (m == "gsv" || m == "nis") (m = a.Z), m.B > 0 && (p.nnut = m.B);
      p.tcm = Tu(a);
      p.nmt = a.da;
      p.bt = a.W;
      p.pst = a.fa;
      p.vpaid = a.H;
      p.dur = a.l;
      p.vmtime = a.K;
      p.is = a.na.l;
      a.h.length >= 1 &&
        ((p.i0 = a.h[0].Yc),
        (p.a0 = [a.h[0].audioVolume]),
        (p.c0 = [a.h[0].aa]),
        (p.ss0 = [a.h[0].Ca]),
        (m = a.h[0].position),
        (f = a.h[0].Oc),
        (p.p0 = m ? Lu(m) : void 0),
        m && f && !zl(f, m) && (p.cp0 = Lu(f)));
      a.h.length >= 2 &&
        ((p.i1 = a.h[1].Yc),
        (p.a1 = fv(a.h[1].Vd, a.h[1].audioVolume, a.h[1].Rd)),
        (p.c1 = fv(a.h[1].Wd, a.h[1].aa, a.h[1].Sd)),
        (p.ss1 = fv(a.h[1].Xd, a.h[1].Ca, a.h[1].Td)),
        (m = a.h[1].position),
        (f = a.h[1].Oc),
        (p.p1 = m ? Lu(m) : void 0),
        m && f && !zl(f, m) && (p.cp1 = Lu(f)),
        (p.mtos1 = a.h[1].Yd));
      a.h.length >= 3 &&
        ((p.i2 = a.h[2].Yc),
        (p.a2 = fv(a.h[2].Vd, a.h[2].audioVolume, a.h[2].Rd)),
        (p.c2 = fv(a.h[2].Wd, a.h[2].aa, a.h[2].Sd)),
        (p.ss2 = fv(a.h[2].Xd, a.h[2].Ca, a.h[2].Td)),
        (m = a.h[2].position),
        (f = a.h[2].Oc),
        (p.p2 = m ? Lu(m) : void 0),
        m && f && !zl(f, m) && (p.cp2 = Lu(f)),
        (p.mtos2 = a.h[2].Yd));
      a.h.length >= 4 &&
        ((p.i3 = a.h[3].Yc),
        (p.a3 = fv(a.h[3].Vd, a.h[3].audioVolume, a.h[3].Rd)),
        (p.c3 = fv(a.h[3].Wd, a.h[3].aa, a.h[3].Sd)),
        (p.ss3 = fv(a.h[3].Xd, a.h[3].Ca, a.h[3].Td)),
        (m = a.h[3].position),
        (f = a.h[3].Oc),
        (p.p3 = m ? Lu(m) : void 0),
        m && f && !zl(f, m) && (p.cp3 = Lu(f)),
        (p.mtos3 = a.h[3].Yd));
      p.cs = yu(a.na);
      b &&
        ((p.ic = xu(a.na)),
        (p.dvpt = l.l.j),
        (p.dvs = Ft(l.j, 0.5)),
        (p.dfvs = Ft(l.j, 1)),
        (p.davs = Ft(l.h, 0.5)),
        (p.dafvs = Ft(l.h, 1)),
        c && ((l.l.j = 0), Gt(l.j), Gt(l.h)),
        a.sb() &&
          ((p.dtos = l.O),
          (p.dav = l.H),
          (p.dtoss = a.Be + 1),
          c && ((l.O = 0), (l.H = 0), a.Be++)),
        (p.dat = l.A.j),
        (p.dft = l.V.j),
        c && ((l.A.j = 0), (l.V.j = 0)));
      p.ps = [h.o.width, h.o.height];
      p.bs = [h.h.getWidth(), h.h.getHeight()];
      p.scs = [h.A.width, h.A.height];
      p.dom = h.domain;
      a.Hc && (p.vds = a.Hc);
      if (a.B.length > 0 || a.tb)
        (b = qc(a.B)),
          a.tb && b.push(a.tb),
          (p.pings = cc(b, function (q) {
            return q.toString();
          }));
      b = cc(
        bc(a.B, function (q) {
          return q.D();
        }),
        function (q) {
          return q.getId();
        }
      );
      rc(b);
      p.ces = b;
      a.j && (p.vmer = a.j);
      a.F && (p.vmmk = a.F);
      a.R && (p.vmiec = a.R);
      p.avms = a.Z ? a.Z.getName() : "ns";
      a.Z && gl(p, a.Z.Fb());
      d
        ? ((p.c = Bs(a.xa.aa, 2)), (p.ss = Bs(a.xa.Ca, 2)))
        : (p.tth = os() - ls);
      p.mc = Bs(l.J, 2);
      p.nc = Bs(l.B, 2);
      p.mv = Ru(l.D);
      p.nv = Ru(l.o);
      p.lte = Bs(a.Pe, 2);
      d = Uu(a, e);
      Kt(l);
      p.qmtos = Kt(d);
      p.qnc = Bs(d.B, 2);
      p.qmv = Ru(d.D);
      p.qnv = Ru(d.o);
      p.qas = d.o > 0 ? 1 : 0;
      p.qi = a.ua;
      p.avms || (p.avms = "geo");
      p.psm = l.T.h;
      p.psv = l.T.getValue();
      p.psfv = l.oa.getValue();
      p.psa = l.za.getValue();
      k = gr(k.U);
      k.length && (p.veid = k);
      a.o && gl(p, fu(a.o));
      p.avas = a.zd();
      p.vs = a.zg();
      p.co = gv(a);
      p.tm = l.Y;
      p.tu = l.ba;
      return p;
    },
    cv = function (a, b) {
      if (kc(ws, b)) return !0;
      var c = a.qa[b];
      return c !== void 0 ? ((a.qa[b] = !0), !c) : !1;
    };
  Ou.prototype.zg = function () {
    return this.rb ? 2 : Xu(this) ? 5 : this.sb() ? 4 : 3;
  };
  Ou.prototype.zd = function () {
    return (this.J ? this.ba : er(hr().U, "mm") === Oq.Nf || this.ba) &&
      Is(this.xa.volume)
      ? this.wa().A.l >= 2e3
        ? 4
        : 3
      : 2;
  };
  var gv = function (a) {
    var b = "" + a.ob + a.Y.toString(10).padStart(2, "0");
    a.Y < 99 && a.Y++;
    return b;
  };
  var hv = Date.now(),
    kv = function () {
      this.h = {};
      var a = ol();
      iv(this, a, document);
      var b = jv();
      try {
        if ("1" == b) {
          for (var c = a.parent; c != a.top; c = c.parent)
            iv(this, c, c.document);
          iv(this, a.top, a.top.document);
        }
      } catch (d) {}
    },
    jv = function () {
      var a = document.documentElement;
      try {
        if (!Jj(ol().top)) return "2";
        var b = [],
          c = ol(a.ownerDocument);
        for (a = c; a != c.top; a = a.parent)
          if (a.frameElement) b.push(a.frameElement);
          else break;
        return b && b.length != 0 ? "1" : "0";
      } catch (d) {
        return "2";
      }
    },
    iv = function (a, b, c) {
      Pt(
        c,
        "mousedown",
        function () {
          return lv(a);
        },
        301
      );
      Pt(
        b,
        "scroll",
        function () {
          return mv(a);
        },
        302
      );
      Pt(
        c,
        "touchmove",
        function () {
          return nv(a);
        },
        303
      );
      Pt(
        c,
        "mousemove",
        function () {
          return ov(a);
        },
        304
      );
      Pt(
        c,
        "keydown",
        function () {
          return pv(a);
        },
        305
      );
    },
    lv = function (a) {
      Sk(a.h, function (b) {
        b.l > 1e5 || ++b.l;
      });
    },
    mv = function (a) {
      Sk(a.h, function (b) {
        b.h > 1e5 || ++b.h;
      });
    },
    nv = function (a) {
      Sk(a.h, function (b) {
        b.h > 1e5 || ++b.h;
      });
    },
    pv = function (a) {
      Sk(a.h, function (b) {
        b.j > 1e5 || ++b.j;
      });
    },
    ov = function (a) {
      Sk(a.h, function (b) {
        b.o > 1e5 || ++b.o;
      });
    };
  var qv = function () {
      this.h = [];
      this.j = [];
    },
    rv = function (a, b) {
      return fc(a.h, function (c) {
        return c.ua == b;
      });
    },
    tv = function (a, b) {
      return b
        ? fc(a.h, function (c) {
            return c.Fa.Jb == b;
          })
        : null;
    },
    uv = function (a, b) {
      return fc(a.j, function (c) {
        return c.Pa() == 2 && c.ua == b;
      });
    },
    wv = function () {
      var a = vv;
      return a.h.length == 0 ? a.j : a.j.length == 0 ? a.h : oc(a.j, a.h);
    };
  qv.prototype.reset = function () {
    this.h = [];
    this.j = [];
  };
  var xv = function (a, b) {
      a = b.Pa() == 1 ? a.h : a.j;
      var c = hc(a, function (d) {
        return d == b;
      });
      return c != -1 ? (a.splice(c, 1), b.Z && b.Z.F(), b.dispose(), !0) : !1;
    },
    yv = function (a) {
      var b = vv;
      if (xv(b, a)) {
        switch (a.Pa()) {
          case 0:
            var c = function () {
              return null;
            };
          case 2:
            c = function () {
              return uv(b, a.ua);
            };
            break;
          case 1:
            c = function () {
              return rv(b, a.ua);
            };
        }
        for (var d = c(); d; d = c()) xv(b, d);
      }
    },
    zv = function (a) {
      var b = vv;
      a = bc(a, function (c) {
        return !tv(b, c.Fa.Jb);
      });
      b.h.push.apply(b.h, ra(a));
    },
    Av = function (a) {
      var b = vv,
        c = [];
      Zb(a, function (d) {
        ec(b.h, function (e) {
          return e.Fa.Jb === d.Fa.Jb && e.ua === d.ua;
        }) || (b.h.push(d), c.push(d));
      });
    },
    vv = M(qv);
  var Bv = function () {
      this.h = this.j = null;
    },
    Cv = function (a, b) {
      if (a.j == null) return !1;
      var c = function (d, e) {
        b(d, e);
      };
      a.h = fc(a.j, function (d) {
        return d != null && d.Qf();
      });
      a.h && (a.h.init(c) ? Zs(a.h.h) : b(a.h.h.wc(), a.h));
      return a.h != null;
    };
  var Ev = function (a) {
    a = Dv(a);
    dt.call(this, a.length ? a[a.length - 1] : new Vs(P, 0));
    this.l = a;
    this.j = null;
  };
  w(Ev, dt);
  n = Ev.prototype;
  n.getName = function () {
    return (this.j ? this.j : this.h).getName();
  };
  n.Fb = function () {
    return (this.j ? this.j : this.h).Fb();
  };
  n.qb = function () {
    return (this.j ? this.j : this.h).qb();
  };
  n.init = function (a) {
    var b = !1;
    Zb(this.l, function (c) {
      c.initialize() && (b = !0);
    });
    b && ((this.o = a), Ys(this.h, this));
    return b;
  };
  n.dispose = function () {
    Zb(this.l, function (a) {
      a.dispose();
    });
    dt.prototype.dispose.call(this);
  };
  n.Qf = function () {
    return ec(this.l, function (a) {
      return a.H();
    });
  };
  n.Ic = function () {
    return ec(this.l, function (a) {
      return a.H();
    });
  };
  n.nd = function (a, b, c) {
    return new Iu(a, this.h, b, c);
  };
  n.Hb = function (a) {
    this.j = a.l;
  };
  var Dv = function (a) {
    if (!a.length) return [];
    a = bc(a, function (c) {
      return c != null && c.H();
    });
    for (var b = 1; b < a.length; b++) Ys(a[b - 1], a[b]);
    return a;
  };
  var Fv = { threshold: [0, 0.3, 0.5, 0.75, 1] },
    Gv = function (a, b, c, d) {
      bt.call(this, a, b, c, d);
      this.V = this.H = this.B = this.C = this.o = null;
    };
  w(Gv, Iu);
  Gv.prototype.observe = function () {
    var a = this;
    this.V || (this.V = os());
    if (
      fs(298, function () {
        return Hv(a);
      })
    )
      return !0;
    Xs(this.j, "msf");
    return !1;
  };
  Gv.prototype.F = function () {
    if (this.o && this.element)
      try {
        this.o.unobserve(this.element),
          this.C
            ? (this.C.unobserve(this.element), (this.C = null))
            : this.B && (this.B.disconnect(), (this.B = null));
      } catch (a) {}
  };
  var Iv = function (a) {
      return a.o && a.o.takeRecords ? a.o.takeRecords() : [];
    },
    Hv = function (a) {
      if (!a.element) return !1;
      var b = a.element,
        c = a.j.h.l,
        d = hr().h.h;
      a.o = new c.IntersectionObserver(
        Qr(d, function (e) {
          return Jv(a, e);
        }),
        Fv
      );
      d = Qr(d, function () {
        a.o.unobserve(b);
        a.o.observe(b);
        Jv(a, Iv(a));
      });
      c.ResizeObserver
        ? ((a.C = new c.ResizeObserver(d)), a.C.observe(b))
        : c.MutationObserver &&
          ((a.B = new C.MutationObserver(d)),
          a.B.observe(b, {
            attributes: !0,
            childList: !0,
            characterData: !0,
            subtree: !0,
          }));
      a.o.observe(b);
      Jv(a, Iv(a));
      return !0;
    },
    Jv = function (a, b) {
      try {
        if (b.length) {
          a.H || (a.H = os());
          var c = Kv(b),
            d = Ml(a.element, a.j.h.l),
            e = d.x,
            f = d.y;
          a.l = new L(
            Math.round(f),
            Math.round(e) + c.boundingClientRect.width,
            Math.round(f) + c.boundingClientRect.height,
            Math.round(e)
          );
          a.h = ct(a, a.l);
          var g = Gs(c.intersectionRect);
          a.D = Al(g, a.l.left - g.left, a.l.top - g.top);
        }
      } catch (h) {
        a.F(), hs(299, h);
      }
    },
    Kv = function (a) {
      return dc(
        a,
        function (b, c) {
          return b.time > c.time ? b : c;
        },
        a[0]
      );
    };
  n = Gv.prototype;
  n.Ab = function () {
    var a = Iv(this);
    a.length > 0 && Jv(this, a);
    Iu.prototype.Ab.call(this);
  };
  n.ue = function () {};
  n.Dg = function () {
    return !1;
  };
  n.ag = function () {};
  n.Fb = function () {
    var a = {};
    return Object.assign(
      this.j.Fb(),
      ((a.niot_obs = this.V), (a.niot_cbk = this.H), a)
    );
  };
  n.getName = function () {
    return "nio";
  };
  var Lv = function (a) {
    a = a === void 0 ? P : a;
    dt.call(this, new Vs(a, 2));
  };
  w(Lv, dt);
  Lv.prototype.getName = function () {
    return "nio";
  };
  Lv.prototype.Ic = function () {
    return !Rs().j && this.h.h.l.IntersectionObserver != null;
  };
  Lv.prototype.nd = function (a, b, c) {
    return new Gv(a, this.h, b, c);
  };
  var Nv = function () {
    var a = Mv();
    Vs.call(this, P.top, a, "geo");
  };
  w(Nv, Vs);
  Nv.prototype.ba = function () {
    return Rs().h;
  };
  Nv.prototype.H = function () {
    var a = Mv();
    this.F !== a &&
      (this.h != this && a > this.h.F && ((this.h = this), Ws(this)),
      (this.F = a));
    return a == 2;
  };
  var Mv = function () {
    hr();
    var a = Rs();
    return a.l || a.j ? 0 : 2;
  };
  var Ov = function () {};
  var Pv = function () {
      this.done = !1;
      this.h = {
        ei: 0,
        Uf: 0,
        dn: 0,
        ig: 0,
        Le: -1,
        Ei: 0,
        Di: 0,
        Fi: 0,
        hk: 0,
      };
      this.o = null;
      this.A = !1;
      this.j = null;
      this.D = 0;
      this.sampler = new Ts(this);
    },
    Sv = function () {
      var a = Qv;
      a.A ||
        ((a.A = !0),
        Rv(a, function () {
          return a.l.apply(a, ra(La.apply(0, arguments)));
        }),
        a.l());
    };
  Pv.prototype.sample = function () {
    Tv(this, wv(), !1);
  };
  var Uv = function () {
      M(Ov);
      var a = M(Bv);
      a.h != null && a.h.h ? Zs(a.h.h) : Ns(Rs());
    },
    Tv = function (a, b, c) {
      if (!a.done && (a.sampler.cancel(), b.length != 0)) {
        a.j = null;
        try {
          Uv();
          var d = os();
          hr().A = d;
          if (M(Bv).h != null)
            for (var e = 0; e < b.length; e++) bu(b[e], d, c);
          for (d = 0; d < b.length; d++) cu(b[d]);
          ++a.h.ig;
        } finally {
          c
            ? Zb(b, function (f) {
                f.xa.aa = 0;
              })
            : Us(a.sampler);
        }
      }
    },
    Rv = function (a, b) {
      if (!a.o) {
        b = gs(142, b);
        Kr();
        var c = yn(kr);
        c && Tl(kr, c, b, { capture: !1 }) && (a.o = b);
      }
    };
  Pv.prototype.l = function () {
    var a = Ss(),
      b = os();
    a
      ? (ns ||
          ((js = b),
          Zb(vv.h, function (c) {
            var d = c.wa();
            d.da = Cu(d, b, c.ta != 1);
          })),
        (ns = !0))
      : ((this.D = Vv(this, b)),
        (ns = !1),
        (ls = b),
        Zb(vv.h, function (c) {
          c.Qc && (c.wa().F = b);
        }));
    Tv(this, wv(), !a);
  };
  var Wv = function () {
      var a = M(Bv);
      if (a.h != null) {
        var b = a.h;
        Zb(wv(), function (c) {
          return $t(c, b);
        });
      }
    },
    Vv = function (a, b) {
      a = a.D;
      ns && (a += b - js);
      return a;
    },
    Xv = function (a) {
      var b = Qv;
      a =
        a === void 0
          ? function () {
              return {};
            }
          : a;
      cs.bh("av-js");
      Yr.h = 0.01;
      es([
        function (c) {
          var d = hr(),
            e = {};
          e = ((e.bin = d.j), (e.type = "error"), e);
          d = fr(d.U);
          if (!b.j) {
            var f = P.document,
              g = ks >= 0 ? os() - ks : -1,
              h = os();
            b.h.Le == -1 && (g = h);
            var k = Rs(),
              l = hr(),
              m = fr(l.U),
              p = wv();
            try {
              if (p.length > 0) {
                var q = k.h;
                q && (m.bs = [q.getWidth(), q.getHeight()]);
                var r = k.o;
                r && (m.ps = [r.width, r.height]);
                P.screen && (m.scs = [P.screen.width, P.screen.height]);
              } else
                (m.url = encodeURIComponent(P.location.href.substring(0, 512))),
                  f.referrer &&
                    (m.referrer = encodeURIComponent(
                      f.referrer.substring(0, 512)
                    ));
              m.tt = g;
              m.pt = ks;
              m.bin = l.j;
              P.google_osd_load_pub_page_exp !== void 0 &&
                (m.olpp = P.google_osd_load_pub_page_exp);
              m.deb = [
                1,
                b.h.ei,
                b.h.Uf,
                b.h.ig,
                b.h.Le,
                0,
                b.sampler.j,
                b.h.Ei,
                b.h.Di,
                b.h.Fi,
                b.h.hk,
                -1,
              ].join(";");
              m.tvt = Vv(b, h);
              k.j && (m.inapp = 1);
              if (P !== null && P != P.top) {
                p.length > 0 &&
                  (m.iframe_loc = encodeURIComponent(
                    P.location.href.substring(0, 512)
                  ));
                var t = k.C;
                m.is = [t.getWidth(), t.getHeight()];
              }
            } catch (x) {
              m.error = 1;
            }
            b.j = m;
          }
          r = b.j;
          q = {};
          for (var v in r) q[v] = r[v];
          v = hr().h;
          if (er(v.l, "prf") == 1) {
            r = new Or();
            t = v.h;
            f = 0;
            t.h > -1 && (f = t.l.h.now() - t.h);
            t = t.o + f;
            if (t != null && typeof t !== "number")
              throw Error(
                "Value of float/double field must be a number, found " +
                  typeof t +
                  ": " +
                  t
              );
            r = wg(r, 1, t, 0);
            t = v.h;
            r = eh(r, 5, t.h > -1 ? t.j + 1 : t.j);
            r = gh(r, 2, v.j.h.l());
            r = gh(r, 3, v.j.h.j());
            v = gh(r, 4, v.j.h.h());
            r = {};
            v = ((r.pf = Xc(v.j())), r);
          } else v = {};
          gl(q, v);
          gl(c, e, d, q, a());
        },
      ]);
    },
    Qv = M(Pv);
  var Yv = null,
    Zv = "",
    $v = !1,
    aw = function () {
      var a = Yv || P;
      if (!a) return "";
      var b = [];
      if (!a.location || !a.location.href) return "";
      b.push("url=" + encodeURIComponent(a.location.href.substring(0, 512)));
      a.document &&
        a.document.referrer &&
        b.push(
          "referrer=" +
            encodeURIComponent(a.document.referrer.substring(0, 512))
        );
      return b.join("&");
    };
  var cw = function (a, b) {
      var c = { sv: "971", cb: "ima" };
      c.nas = vv.h.length;
      c.msg = a;
      b !== void 0 && (a = bw(b)) && (c.e = xs[a]);
      return c;
    },
    dw = function (a) {
      return a.lastIndexOf("custom_metric_viewable", 0) == 0;
    },
    bw = function (a) {
      var b = dw(a) ? "custom_metric_viewable" : a.toLowerCase();
      return al(function (c) {
        return c == b;
      });
    };
  var ew = { Qk: "visible", yk: "audible", Xl: "time", Zl: "timetype" },
    fw = {
      visible: function (a) {
        return /^(100|[0-9]{1,2})$/.test(a);
      },
      audible: function (a) {
        return a == "0" || a == "1";
      },
      timetype: function (a) {
        return a == "mtos" || a == "tos";
      },
      time: function (a) {
        return /^(100|[0-9]{1,2})%$/.test(a) || /^([0-9])+ms$/.test(a);
      },
    },
    gw = function () {
      this.h = void 0;
      this.j = !1;
      this.l = 0;
      this.o = -1;
      this.A = "tos";
    },
    hw = function (a) {
      try {
        var b = a.split(",");
        return b.length > Xk(ew).length
          ? null
          : dc(
              b,
              function (c, d) {
                d = d.toLowerCase().split("=");
                if (d.length != 2 || fw[d[0]] === void 0 || !fw[d[0]](d[1]))
                  throw Error("Entry (" + d[0] + ", " + d[1] + ") is invalid.");
                c[d[0]] = d[1];
                return c;
              },
              {}
            );
      } catch (c) {
        return null;
      }
    },
    iw = function (a, b) {
      if (a.h == void 0) return 0;
      switch (a.A) {
        case "mtos":
          return a.j ? Et(b.h, a.h) : Et(b.j, a.h);
        case "tos":
          return a.j ? Ct(b.h, a.h) : Ct(b.j, a.h);
      }
      return 0;
    };
  var jw = function (a, b, c, d) {
    Eu.call(this, b, d);
    this.B = a;
    this.C = c;
  };
  w(jw, Eu);
  jw.prototype.getId = function () {
    return this.B;
  };
  jw.prototype.D = function () {
    return !0;
  };
  jw.prototype.h = function (a) {
    var b = a.wa(),
      c = a.getDuration();
    return ec(this.C, function (d) {
      if (d.h != void 0) var e = iw(d, b);
      else
        b: {
          switch (d.A) {
            case "mtos":
              e = d.j ? b.A.l : b.l.h;
              break b;
            case "tos":
              e = d.j ? b.A.h : b.l.h;
              break b;
          }
          e = 0;
        }
      e == 0
        ? (d = !1)
        : ((d = d.l != -1 ? d.l : c !== void 0 && c > 0 ? d.o * c : -1),
          (d = d != -1 && e >= d));
      return d;
    });
  };
  var kw = function () {};
  w(kw, tu);
  kw.prototype.h = function (a) {
    var b = new ru();
    b.h = uu(a, ou);
    b.j = uu(a, qu);
    return b;
  };
  var lw = function (a) {
    Eu.call(this, "fully_viewable_audible_half_duration_impression", a);
  };
  w(lw, Eu);
  lw.prototype.h = function (a) {
    return Xu(a);
  };
  var mw = function (a) {
    this.h = a;
  };
  w(mw, Gu);
  var nw = function (a, b) {
    Eu.call(this, a, b);
  };
  w(nw, Eu);
  nw.prototype.h = function (a) {
    return a.wa().sb();
  };
  var ow = function (a) {
    Fu.call(this, "measurable_impression", a);
  };
  w(ow, Fu);
  ow.prototype.h = function (a) {
    var b = kc(this.B, er(hr().U, "ovms"));
    return !a.rb && (a.ta != 0 || b);
  };
  var pw = function () {
    mw.apply(this, arguments);
  };
  w(pw, mw);
  pw.prototype.j = function () {
    return new ow(this.h);
  };
  pw.prototype.l = function () {
    return [new nw("viewable_impression", this.h), new lw(this.h)];
  };
  var qw = function (a, b, c) {
    Ku.call(this, a, b, c);
  };
  w(qw, Ku);
  qw.prototype.o = function () {
    var a = $a("ima.admob.getViewability"),
      b = er(this.U, "queryid");
    typeof a === "function" && b && a(b);
  };
  qw.prototype.getName = function () {
    return "gsv";
  };
  var rw = function (a) {
    a = a === void 0 ? P : a;
    dt.call(this, new Vs(a, 2));
  };
  w(rw, dt);
  rw.prototype.getName = function () {
    return "gsv";
  };
  rw.prototype.Ic = function () {
    var a = Rs();
    hr();
    return a.j && !1;
  };
  rw.prototype.nd = function (a, b, c) {
    return new qw(this.h, b, c);
  };
  var tw = function (a, b, c) {
    Ku.call(this, a, b, c);
  };
  w(tw, Ku);
  tw.prototype.o = function () {
    var a = this,
      b = $a("ima.bridge.getNativeViewability"),
      c = er(this.U, "queryid");
    typeof b === "function" &&
      c &&
      b(c, function (d) {
        cl(d) && a.B++;
        var e = d.opt_nativeViewVisibleBounds || {},
          f = d.opt_nativeViewHidden;
        a.h = Hs(d.opt_nativeViewBounds || {});
        var g = a.j.o;
        g.h = f ? yl(Ju) : Hs(e);
        a.timestamp = d.opt_nativeTime || -1;
        Rs().h = g.h;
        d = d.opt_nativeVolume;
        d !== void 0 && (g.volume = d);
      });
  };
  tw.prototype.getName = function () {
    return "nis";
  };
  var uw = function (a) {
    a = a === void 0 ? P : a;
    dt.call(this, new Vs(a, 2));
  };
  w(uw, dt);
  uw.prototype.getName = function () {
    return "nis";
  };
  uw.prototype.Ic = function () {
    var a = Rs();
    hr();
    return a.j && !1;
  };
  uw.prototype.nd = function (a, b, c) {
    return new tw(this.h, b, c);
  };
  var vw = function () {
    Vs.call(this, P, 2, "mraid");
    this.da = 0;
    this.J = this.K = !1;
    this.C = null;
    this.j = ys(this.l);
    this.o.h = new L(0, 0, 0, 0);
    this.fa = !1;
  };
  w(vw, Vs);
  vw.prototype.H = function () {
    return this.j.Za != null;
  };
  vw.prototype.Y = function () {
    var a = {};
    this.da && (a.mraid = this.da);
    this.K && (a.mlc = 1);
    a.mtop = this.j.fk;
    this.C && (a.mse = this.C);
    this.fa && (a.msc = 1);
    a.mcp = this.j.wd;
    return a;
  };
  vw.prototype.D = function (a) {
    var b = La.apply(1, arguments);
    try {
      return this.j.Za[a].apply(this.j.Za, b);
    } catch (c) {
      hs(538, c, 0.01, function (d) {
        d.method = a;
      });
    }
  };
  var ww = function (a, b, c) {
    a.D("addEventListener", b, c);
  };
  vw.prototype.initialize = function () {
    var a = this;
    if (this.Ga) return !this.Wc();
    this.Ga = !0;
    if (this.j.wd === 2) return (this.C = "ng"), Xs(this, "w"), !1;
    if (this.j.wd === 1) return (this.C = "mm"), Xs(this, "w"), !1;
    Rs().F = !0;
    this.l.document.readyState && this.l.document.readyState == "complete"
      ? xw(this)
      : Pt(
          this.l,
          "load",
          function () {
            Kr().setTimeout(
              gs(292, function () {
                return xw(a);
              }),
              100
            );
          },
          292
        );
    return !0;
  };
  var xw = function (a) {
      hr().o = !!a.D("isViewable");
      ww(a, "viewableChange", yw);
      a.D("getState") === "loading" ? ww(a, "ready", zw) : Aw(a);
    },
    Aw = function (a) {
      typeof a.j.Za.AFMA_LIDAR === "string"
        ? ((a.K = !0), Bw(a))
        : ((a.j.wd = 3), (a.C = "nc"), Xs(a, "w"));
    },
    Bw = function (a) {
      a.J = !1;
      var b = er(hr().U, "rmmt") == 1,
        c = !!a.D("isViewable");
      (b ? !c : 1) &&
        Kr().setTimeout(
          gs(524, function () {
            a.J || (Cw(a), hs(540, Error()), (a.C = "mt"), Xs(a, "w"));
          }),
          500
        );
      Dw(a);
      ww(a, a.j.Za.AFMA_LIDAR, Ew);
    },
    Dw = function (a) {
      var b = er(hr().U, "sneio") == 1,
        c = a.j.Za.AFMA_LIDAR_EXP_1 !== void 0,
        d = a.j.Za.AFMA_LIDAR_EXP_2 !== void 0;
      (b = b && d) && (a.j.Za.AFMA_LIDAR_EXP_2 = !0);
      c && (a.j.Za.AFMA_LIDAR_EXP_1 = !b);
    },
    Cw = function (a) {
      a.D("removeEventListener", a.j.Za.AFMA_LIDAR, Ew);
      a.K = !1;
    };
  vw.prototype.R = function () {
    var a = Rs(),
      b = Fw(this, "getMaxSize");
    a.h = new L(0, b.width, b.height, 0);
  };
  vw.prototype.T = function () {
    Rs().A = Fw(this, "getScreenSize");
  };
  var Fw = function (a, b) {
    if (a.D("getState") === "loading") return new Rk(-1, -1);
    b = a.D(b);
    if (!b) return new Rk(-1, -1);
    a = parseInt(b.width, 10);
    b = parseInt(b.height, 10);
    return isNaN(a) || isNaN(b) ? new Rk(-1, -1) : new Rk(a, b);
  };
  vw.prototype.dispose = function () {
    Cw(this);
    Vs.prototype.dispose.call(this);
  };
  var zw = function () {
      try {
        var a = M(vw);
        a.D("removeEventListener", "ready", zw);
        Aw(a);
      } catch (b) {
        hs(541, b);
      }
    },
    Ew = function (a, b) {
      try {
        var c = M(vw);
        c.J = !0;
        var d = a
          ? new L(a.y, a.x + a.width, a.y + a.height, a.x)
          : new L(0, 0, 0, 0);
        var e = os(),
          f = Ss();
        var g = new qs(e, f, c);
        g.h = d;
        g.volume = b;
        c.Hb(g);
      } catch (h) {
        hs(542, h);
      }
    },
    yw = function (a) {
      var b = hr(),
        c = M(vw);
      a && !b.o && ((b.o = !0), (c.fa = !0), c.C && Xs(c, "w", !0));
    };
  var Tr = new (function (a, b) {
    b = b === void 0 ? !1 : b;
    this.key = a;
    this.defaultValue = b;
    this.valueType = "boolean";
  })("45378663");
  var Hw = function () {
    this.l = this.Ga = !1;
    this.h = this.j = null;
    var a = {};
    this.O =
      ((a.start = this.dj),
      (a.firstquartile = this.Yi),
      (a.midpoint = this.aj),
      (a.thirdquartile = this.ej),
      (a.complete = this.Vi),
      (a.error = this.Wi),
      (a.pause = this.ff),
      (a.resume = this.Zg),
      (a.skip = this.cj),
      (a.viewable_impression = this.jb),
      (a.mute = this.Gc),
      (a.unmute = this.Gc),
      (a.fullscreen = this.Zi),
      (a.exitfullscreen = this.Xi),
      (a.fully_viewable_audible_half_duration_impression = this.jb),
      (a.measurable_impression = this.jb),
      (a.abandon = this.ff),
      (a.engagedview = this.jb),
      (a.impression = this.jb),
      (a.creativeview = this.jb),
      (a.progress = this.Gc),
      (a.custom_metric_viewable = this.jb),
      (a.bufferstart = this.ff),
      (a.bufferfinish = this.Zg),
      (a.audio_measurable = this.jb),
      (a.audio_audible = this.jb),
      a);
    a = {};
    this.T =
      ((a.overlay_resize = this.bj),
      (a.abandon = this.Ke),
      (a.close = this.Ke),
      (a.collapse = this.Ke),
      (a.overlay_unmeasurable_impression = function (b) {
        return ev(b, "overlay_unmeasurable_impression", Ss());
      }),
      (a.overlay_viewable_immediate_impression = function (b) {
        return ev(b, "overlay_viewable_immediate_impression", Ss());
      }),
      (a.overlay_unviewable_impression = function (b) {
        return ev(b, "overlay_unviewable_impression", Ss());
      }),
      (a.overlay_viewable_end_of_session_impression = function (b) {
        return ev(b, "overlay_viewable_end_of_session_impression", Ss());
      }),
      a);
    hr().j = 3;
    Gw(this);
    this.C = null;
  };
  Hw.prototype.A = function (a) {
    Zt(a, !1);
    yv(a);
  };
  Hw.prototype.F = function () {};
  var Iw = function (a, b, c, d) {
    a = a.D(null, d, !0, b);
    a.A = c;
    zv([a]);
    return a;
  };
  Hw.prototype.D = function (a, b, c, d) {
    var e = this;
    a = new Ou(P, a, c ? b : -1, 7, this.ye(), this.fg());
    a.ua = d;
    cr(a.U);
    dr(a.U, "queryid", a.ua);
    a.hf("");
    du(
      a,
      function () {
        return e.K.apply(e, ra(La.apply(0, arguments)));
      },
      function () {
        return e.R.apply(e, ra(La.apply(0, arguments)));
      }
    );
    (d = M(Bv).h) && $t(a, d);
    this.C && (a.Z && (a.Z.A = this.C), (this.C = null));
    a.Fa.Jb && M(Ov);
    return a;
  };
  var Jw = function (a, b, c) {
      Lq(b);
      var d = a.h;
      Zb(b, function (e) {
        var f = cc(e.h, function (g) {
          var h = hw(g);
          if (h == null) g = null;
          else if (
            ((g = new gw()),
            h.visible != null && (g.h = h.visible / 100),
            h.audible != null && (g.j = h.audible == 1),
            h.time != null)
          ) {
            var k = h.timetype == "mtos" ? "mtos" : "tos",
              l = Eb(h.time, "%") ? "%" : "ms";
            h = parseInt(h.time, 10);
            l == "%" && (h /= 100);
            k = k === void 0 ? "tos" : k;
            l == "ms" ? ((g.l = h), (g.o = -1)) : ((g.l = -1), (g.o = h));
            g.A = k;
          }
          return g;
        });
        ec(f, function (g) {
          return g == null;
        }) || Wu(c, new jw(e.id, e.event, f, d));
      });
    },
    Kw = function () {
      var a = [],
        b = hr();
      a.push(M(Nv));
      er(b.U, "mvp_lv") && a.push(M(vw));
      b = [new rw(), new uw()];
      b.push(new Ev(a));
      b.push(new Lv(P));
      return b;
    },
    Mw = function (a) {
      if (!a.Ga) {
        a.Ga = !0;
        try {
          var b = os(),
            c = hr(),
            d = Rs();
          ks = b;
          c.l = 79463069;
          a.j !== "o" && (Yv = Kj(P));
          if (Lr()) {
            Qv.h.Uf = 0;
            Qv.h.Le = os() - b;
            var e = Kw(),
              f = M(Bv);
            f.j = e;
            Cv(f, function () {
              Lw();
            })
              ? Qv.done || (Wv(), Ys(f.h.h, a), Sv())
              : d.l
              ? Lw()
              : Sv();
          } else $v = !0;
        } catch (g) {
          throw (vv.reset(), g);
        }
      }
    },
    Nw = function (a) {
      Qv.sampler.cancel();
      Zv = a;
      Qv.done = !0;
    },
    Ow = function (a) {
      if (a.j) return a.j;
      var b = M(Bv).h;
      if (b)
        switch (b.getName()) {
          case "nis":
            a.j = "n";
            break;
          case "gsv":
            a.j = "m";
        }
      a.j || (a.j = "h");
      return a.j;
    },
    Pw = function (a, b, c) {
      if (a.h == null) return (b.Hc |= 4), !1;
      a = a.h.report(c, b);
      b.Hc |= a;
      return a == 0;
    };
  Hw.prototype.yc = function (a) {
    switch (a.qb()) {
      case 0:
        if ((a = M(Bv).h)) (a = a.h), lc(a.A, this), a.N && this.nb() && $s(a);
        Lw();
        break;
      case 2:
        Sv();
    }
  };
  Hw.prototype.Hb = function () {};
  Hw.prototype.nb = function () {
    return !1;
  };
  var Lw = function () {
    var a = [new Lv(P)],
      b = M(Bv);
    b.j = a;
    Cv(b, function () {
      Nw("i");
    })
      ? Qv.done || (Wv(), Sv())
      : Nw("i");
  };
  Hw.prototype.R = function (a, b) {
    a.rb = !0;
    switch (a.Pa()) {
      case 1:
        Qw(a, b);
        break;
      case 2:
        this.mf(a);
    }
    this.sf(a);
  };
  var Qw = function (a, b) {
    if (!a.fb) {
      var c = ev(a, "start", Ss());
      c = a.gf.h(c).h;
      var d = { id: "lidarv" };
      d.r = b;
      d.sv = "971";
      gq(c, function (e, f) {
        return (d[e] = e == "mtos" || e == "tos" ? f : encodeURIComponent(f));
      });
      b = aw();
      gq(b, function (e, f) {
        return (d[e] = encodeURIComponent(f));
      });
      b =
        "//pagead2.googlesyndication.com/pagead/gen_204?" + lt(jt(new ht(), d));
      ot(b);
      a.fb = !0;
    }
  };
  n = Hw.prototype;
  n.dj = function (a) {
    var b = a.C(a);
    b && ((b = b.volume), (a.ba = Is(b) && b > 0));
    av(a, 0);
    return ev(a, "start", Ss());
  };
  n.Gc = function (a, b, c) {
    Tv(Qv, [a], !Ss());
    return this.jb(a, b, c);
  };
  n.jb = function (a, b, c) {
    return ev(a, c, Ss());
  };
  n.Yi = function (a) {
    return Rw(a, "firstquartile", 1);
  };
  n.aj = function (a) {
    a.oa = !0;
    return Rw(a, "midpoint", 2);
  };
  n.ej = function (a) {
    return Rw(a, "thirdquartile", 3);
  };
  n.Vi = function (a) {
    var b = Rw(a, "complete", 4);
    Qu(a);
    return b;
  };
  n.Wi = function (a) {
    a.ta = 3;
    return ev(a, "error", Ss());
  };
  var Rw = function (a, b, c) {
    Tv(Qv, [a], !Ss());
    av(a, c);
    bv(a, c);
    return ev(a, b, Ss());
  };
  n = Hw.prototype;
  n.Zg = function (a, b, c) {
    b = Ss();
    a.ta != 2 || b || (a.wa().F = os());
    Tv(Qv, [a], !b);
    a.ta == 2 && (a.ta = 1);
    return ev(a, c, b);
  };
  n.cj = function (a, b) {
    b = this.Gc(a, b || {}, "skip");
    Qu(a);
    return b;
  };
  n.Zi = function (a, b) {
    Zt(a, !0);
    return this.Gc(a, b || {}, "fullscreen");
  };
  n.Xi = function (a, b) {
    Zt(a, !1);
    return this.Gc(a, b || {}, "exitfullscreen");
  };
  n.ff = function (a, b, c) {
    b = a.wa();
    b.da = Cu(b, os(), a.ta != 1);
    Tv(Qv, [a], !Ss());
    a.ta == 1 && (a.ta = 2);
    return ev(a, c, Ss());
  };
  n.bj = function (a) {
    Tv(Qv, [a], !Ss());
    return a.j();
  };
  n.Ke = function (a) {
    Tv(Qv, [a], !Ss());
    this.Wg(a);
    Qu(a);
    return a.j();
  };
  var Gw = function (a) {
      Xv(function () {
        var b = Sw();
        a.j != null && (b.sdk = a.j);
        var c = M(Bv);
        c.h != null && (b.avms = c.h.getName());
        return b;
      });
    },
    Tw = function (a, b, c, d) {
      var e = tv(vv, c);
      e !== null && e.ua !== b && (a.A(e), (e = null));
      e ||
        ((b = a.D(c, os(), !1, b)),
        vv.j.length == 0 && (hr().l = 79463069),
        Av([b]),
        (e = b),
        (e.A = Ow(a)),
        d && (e.Lb = d));
      return e;
    };
  Hw.prototype.K = function () {};
  var Vw = function (a, b) {
    b.F = 0;
    for (var c in ts) a[c] == null && (b.F |= ts[c]);
    Uw(a, "currentTime");
    Uw(a, "duration");
  };
  n = Hw.prototype;
  n.mf = function () {};
  n.Wg = function () {};
  n.Rf = function () {};
  n.sf = function () {};
  n.ze = function () {};
  n.fg = function () {
    this.h || (this.h = this.ze());
    return this.h == null || this.l ? new Hu() : new pw(this.h);
  };
  n.ye = function () {
    return new kw();
  };
  var Uw = function (a, b) {
      var c = a[b];
      c !== void 0 && c > 0 && (a[b] = Math.floor(c * 1e3));
    },
    Sw = function () {
      var a = Rs(),
        b = {},
        c = {};
      return xa(
        {},
        ((b.sv = "971"), b),
        !1,
        ((c["if"] = a.l ? "1" : "0"), (c.nas = String(vv.h.length)), c)
      );
    };
  var Ww = function (a) {
    Eu.call(this, "audio_audible", a);
  };
  w(Ww, Eu);
  Ww.prototype.h = function (a) {
    return a.zd() == 4;
  };
  var Xw = function (a) {
    Fu.call(this, "audio_measurable", a);
  };
  w(Xw, Fu);
  Xw.prototype.h = function (a) {
    a = a.zd();
    return a == 3 || a == 4;
  };
  var Yw = function () {
    mw.apply(this, arguments);
  };
  w(Yw, mw);
  Yw.prototype.j = function () {
    return new Xw(this.h);
  };
  Yw.prototype.l = function () {
    return [new Ww(this.h)];
  };
  var Zw = function () {};
  w(Zw, tu);
  Zw.prototype.h = function (a) {
    a &&
      (a.e === 28 && (a = Object.assign({}, a, { avas: 3 })),
      a.vs === 4 || a.vs === 5) &&
      (a = Object.assign({}, a, { vs: 3 }));
    var b = new ru();
    b.h = uu(a, pu);
    b.j = uu(a, qu);
    return b;
  };
  var $w = function (a) {
    this.j = a;
  };
  $w.prototype.report = function (a, b) {
    var c = this.h(b);
    if (typeof c === "function") {
      var d = {};
      d = xa({}, !1, ((d.sv = "971"), (d.cb = "ima"), (d.e = ax(a)), d));
      var e = ev(b, a, Ss());
      gl(d, e);
      b.zh[a] = e;
      d = b.Pa() == 2 ? nt(d).join("&") : b.gf.h(d).h;
      try {
        return c(b.ua, d, a), 0;
      } catch (f) {
        return 2;
      }
    } else return 1;
  };
  var ax = function (a) {
    var b = dw(a) ? "custom_metric_viewable" : a;
    a = al(function (c) {
      return c == b;
    });
    return xs[a];
  };
  $w.prototype.h = function () {
    return $a(this.j);
  };
  var bx = function (a, b) {
    this.j = a;
    this.l = b;
  };
  w(bx, $w);
  bx.prototype.h = function (a) {
    if (!a.Lb) return $w.prototype.h.call(this, a);
    if (this.l[a.Lb]) return function () {};
    hs(393, Error());
    return null;
  };
  var cx = function () {
    Hw.call(this);
    this.H = void 0;
    this.V = null;
    this.N = !1;
    this.o = {};
    this.J = 0;
    this.B = "ACTIVE_VIEW_TRAFFIC_TYPE_UNSPECIFIED";
  };
  w(cx, Hw);
  cx.prototype.F = function (a, b) {
    var c = this,
      d = M(Bv);
    if (d.h != null)
      switch (d.h.getName()) {
        case "nis":
          var e = dx(this, a, b);
          break;
        case "gsv":
          e = ex(this, a, b);
          break;
        case "exc":
          e = fx(this, a);
      }
    e ||
      (b.opt_overlayAdElement
        ? (e = void 0)
        : b.opt_adElement && (e = Tw(this, a, b.opt_adElement, b.opt_osdId)));
    e &&
      e.Pa() == 1 &&
      (e.C == Lj &&
        (e.C = function (f) {
          return c.Rf(f);
        }),
      (a = e),
      b.opt_useOneSecViewableForShortsVideo !== void 0 &&
        Pu(a, !!b.opt_useOneSecViewableForShortsVideo),
      gx(this, a, b));
    return e;
  };
  var gx = function (a, b, c) {
    c = c.opt_configurable_tracking_events;
    a.h != null && Array.isArray(c) && Jw(a, c, b);
  };
  cx.prototype.Rf = function (a) {
    a.j = 0;
    a.R = 0;
    if (a.A == "h" || a.A == "n") {
      var b;
      hr();
      if (a.Lb && hx(this)) {
        var c = this.o[a.Lb];
        c
          ? (b = function (e) {
              return ix(c, e);
            })
          : c !== null && hs(379, Error());
      } else b = $a("ima.common.getVideoMetadata");
      if (typeof b === "function")
        try {
          var d = b(a.ua);
        } catch (e) {
          a.j |= 4;
        }
      else a.j |= 2;
    } else if (a.A == "b")
      if (((b = $a("ytads.bulleit.getVideoMetadata")), typeof b === "function"))
        try {
          d = b(a.ua);
        } catch (e) {
          a.j |= 4;
        }
      else a.j |= 2;
    else if (a.A == "ml")
      if (((b = $a("ima.common.getVideoMetadata")), typeof b === "function"))
        try {
          d = b(a.ua);
        } catch (e) {
          a.j |= 4;
        }
      else a.j |= 2;
    else a.j |= 1;
    a.j ||
      (d === void 0
        ? (a.j |= 8)
        : d === null
        ? (a.j |= 16)
        : cl(d)
        ? (a.j |= 32)
        : d.errorCode != null && ((a.R = d.errorCode), (a.j |= 64)));
    d == null && (d = {});
    Vw(d, a);
    Is(d.volume) && Is(this.H) && (d.volume *= this.H);
    return d;
  };
  var ex = function (a, b, c) {
      var d = rv(vv, b);
      d ||
        ((d = c.opt_nativeTime || -1),
        (d = Iw(a, b, Ow(a), d)),
        c.opt_osdId && (d.Lb = c.opt_osdId));
      return d;
    },
    dx = function (a, b, c) {
      var d = rv(vv, b);
      d || (d = Iw(a, b, "n", c.opt_nativeTime || -1));
      return d;
    },
    fx = function (a, b) {
      var c = rv(vv, b);
      c || (c = Iw(a, b, "h", -1));
      return c;
    };
  cx.prototype.ze = function () {
    if (hx(this))
      return new bx("ima.common.triggerExternalActivityEvent", this.o);
    var a = jx(this);
    return a != null ? new $w(a) : null;
  };
  var jx = function (a) {
    hr();
    switch (Ow(a)) {
      case "b":
        return "ytads.bulleit.triggerExternalActivityEvent";
      case "n":
        return "ima.bridge.triggerExternalActivityEvent";
      case "h":
      case "m":
      case "ml":
        return "ima.common.triggerExternalActivityEvent";
    }
    return null;
  };
  cx.prototype.mf = function (a) {
    !a.h &&
      a.rb &&
      Pw(this, a, "overlay_unmeasurable_impression") &&
      (a.h = !0);
  };
  cx.prototype.Wg = function (a) {
    a.gh &&
      (a.sb()
        ? Pw(this, a, "overlay_viewable_end_of_session_impression")
        : Pw(this, a, "overlay_unviewable_impression"),
      (a.gh = !1));
  };
  var kx = function (a, b, c, d) {
    c = c === void 0 ? {} : c;
    var e = {};
    gl(e, { opt_adElement: void 0, opt_fullscreen: void 0 }, c);
    var f = a.F(b, c);
    c = f ? f.gf : a.ye();
    if (e.opt_bounds) return c.h(cw("ol", d));
    if (d !== void 0)
      if (bw(d) !== void 0)
        if ($v) a = cw("ue", d);
        else if ((Mw(a), Zv == "i")) (a = cw("i", d)), (a["if"] = 0);
        else if ((b = a.F(b, e))) {
          b: {
            Zv == "i" && ((b.rb = !0), a.sf(b));
            f = e.opt_fullscreen;
            f !== void 0 && Zt(b, !!f);
            var g;
            if ((f = !Rs().j && !Ms())) Kr(), (f = xn(kr) === 0);
            if ((g = f)) {
              switch (b.Pa()) {
                case 1:
                  Qw(b, "pv");
                  break;
                case 2:
                  a.mf(b);
              }
              Nw("pv");
            }
            f = d.toLowerCase();
            if ((g = !g))
              c: {
                if (er(hr().U, "ssmol") && ((g = a.l), f === "loaded")) break c;
                g = kc(us, f);
              }
            if (g && b.ta == 0) {
              Zv != "i" && (Qv.done = !1);
              g = e !== void 0 ? e.opt_nativeTime : void 0;
              ms = g = typeof g === "number" ? g : os();
              b.Qc = !0;
              var h = Ss();
              b.ta = 1;
              b.qa = {};
              b.qa.start = !1;
              b.qa.firstquartile = !1;
              b.qa.midpoint = !1;
              b.qa.thirdquartile = !1;
              b.qa.complete = !1;
              b.qa.resume = !1;
              b.qa.pause = !1;
              b.qa.skip = !1;
              b.qa.mute = !1;
              b.qa.unmute = !1;
              b.qa.viewable_impression = !1;
              b.qa.measurable_impression = !1;
              b.qa.fully_viewable_audible_half_duration_impression = !1;
              b.qa.fullscreen = !1;
              b.qa.exitfullscreen = !1;
              b.Be = 0;
              h || (b.wa().F = g);
              Tv(Qv, [b], !h);
            }
            (g = b.lc[f]) && wu(b.na, g);
            er(hr().U, "fmd") || (kc(vs, f) && b.tb && b.tb.j(b, null));
            switch (b.Pa()) {
              case 1:
                var k = dw(f) ? a.O.custom_metric_viewable : a.O[f];
                break;
              case 2:
                k = a.T[f];
            }
            if (
              k &&
              ((d = k.call(a, b, e, d)),
              er(hr().U, "fmd") && kc(vs, f) && b.tb && b.tb.j(b, null),
              d !== void 0)
            ) {
              e = cw(void 0, f);
              gl(e, d);
              d = e;
              break b;
            }
            d = void 0;
          }
          b.ta == 3 && a.A(b);
          a = d;
        } else a = cw("nf", d);
      else a = void 0;
    else
      $v
        ? (a = cw("ue"))
        : f
        ? ((a = cw()), gl(a, dv(f, !0, !1, !1)))
        : (a = cw("nf"));
    return typeof a === "string" ? c.h() : c.h(a);
  };
  cx.prototype.K = function (a) {
    this.l && a.Pa() == 1 && lx(this, a);
  };
  cx.prototype.sf = function (a) {
    this.l && a.Pa() == 1 && lx(this, a);
  };
  var lx = function (a, b) {
      var c;
      if (b.Lb && hx(a)) {
        var d = a.o[b.Lb];
        d
          ? (c = function (f, g) {
              mx(d, f, g);
            })
          : d !== null && hs(379, Error());
      } else c = $a("ima.common.triggerViewabilityMeasurementUpdate");
      if (typeof c === "function") {
        var e = Yu(b);
        e.nativeVolume = a.H;
        c(b.ua, e);
      }
    },
    hx = function (a) {
      return (hr(), Ow(a) != "h" && Ow(a) != "m") ? !1 : a.J != 0;
    };
  cx.prototype.D = function (a, b, c, d) {
    if (Ur()) {
      var e = er(hr().U, "mm"),
        f = {};
      (e = ((f[Oq.Nf] = "ACTIVE_VIEW_TRAFFIC_TYPE_AUDIO"),
      (f[Oq.VIDEO] = "ACTIVE_VIEW_TRAFFIC_TYPE_VIDEO"),
      f)[e]) &&
        e &&
        (this.B = e);
      this.B === "ACTIVE_VIEW_TRAFFIC_TYPE_UNSPECIFIED" && hs(1044, Error());
    }
    a = Hw.prototype.D.call(this, a, b, c, d);
    this.N &&
      ((b = this.V),
      a.o == null && (a.o = new eu()),
      (b.h[a.ua] = a.o),
      (a.o.A = hv));
    return a;
  };
  cx.prototype.A = function (a) {
    a && a.Pa() == 1 && this.N && delete this.V.h[a.ua];
    return Hw.prototype.A.call(this, a);
  };
  cx.prototype.fg = function () {
    this.h || (this.h = this.ze());
    return this.h == null || this.l
      ? new Hu()
      : this.B === "ACTIVE_VIEW_TRAFFIC_TYPE_AUDIO"
      ? new Yw(this.h)
      : new pw(this.h);
  };
  cx.prototype.ye = function () {
    return this.B === "ACTIVE_VIEW_TRAFFIC_TYPE_AUDIO" ? new Zw() : new kw();
  };
  var nx = function (a) {
      var b = {};
      return (b.viewability = a.h), (b.googleViewability = a.j), b;
    },
    ox = function (a, b, c) {
      c = c === void 0 ? {} : c;
      a = kx(M(cx), b, c, a);
      return nx(a);
    },
    px = gs(193, ox, void 0, Sw);
  D("Goog_AdSense_Lidar_sendVastEvent", px);
  var qx = gs(194, function (a, b) {
    b = b === void 0 ? {} : b;
    a = kx(M(cx), a, b);
    return nx(a);
  });
  D("Goog_AdSense_Lidar_getViewability", qx);
  var rx = gs(195, function () {
    return Mr();
  });
  D("Goog_AdSense_Lidar_getUrlSignalsArray", rx);
  var sx = gs(196, function () {
    return JSON.stringify(Mr());
  });
  D("Goog_AdSense_Lidar_getUrlSignalsList", sx);
  var tx = ua(["//ep2.adtrafficquality.google/sodar/", ""]),
    ux = ua(["//tpc.googlesyndication.com/sodar/", ""]);
  var vx = ua(["https://tpc.googlesyndication.com/sodar/", ".js"]),
    wx = ua(["https://ep2.adtrafficquality.google/sodar/", ".js"]),
    xx = ua(["https://www.google.com/recaptcha/api2/aframe"]);
  Jk(xx);
  function yx(a) {
    var b = window,
      c = !0;
    c = c === void 0 ? !1 : c;
    new Promise(function (d, e) {
      function f() {
        g.onload = null;
        g.onerror = null;
        var h;
        (h = g.parentElement) == null || h.removeChild(g);
      }
      var g = b.document.createElement("script");
      g.onload = function () {
        f();
        d();
      };
      g.onerror = function () {
        f();
        e(void 0);
      };
      g.type = "text/javascript";
      lk(g, a);
      c && b.document.readyState !== "complete"
        ? Tl(b, "load", function () {
            b.document.body.appendChild(g);
          })
        : b.document.body.appendChild(g);
    });
  }
  var zx = {},
    Ax =
      ((zx["internal-error"] = -1),
      (zx["non-recoverable-error"] = -2),
      (zx["api-disabled-by-application"] = -3),
      (zx["invalid-argument"] = -4),
      (zx["token-provider-invalid"] = -5),
      zx),
    Bx = function () {
      this.kb = !1;
    },
    Cx,
    Dx = function () {
      Cx || (Cx = new Bx());
      return Cx;
    },
    Fx = function (a) {
      var b;
      Ka(function (c) {
        if (c.j == 1)
          return (
            c.A(2),
            c.h(
              window.android.webview.getExperimentalMediaIntegrityTokenProvider(
                { cloudProjectNumber: 187810013193 }
              ),
              4
            )
          );
        if (c.j != 2) return (a.j = c.l), (a.h = void 0), c.N(0);
        b = c.o();
        a.h = Ex(b);
        c.B();
      });
    },
    Ex = function (a) {
      if (!a || typeof a !== "object") return -100;
      var b = a.mediaIntegrityErrorName;
      if (typeof b === "string") {
        var c;
        return (c = Ax[b]) != null ? c : -100;
      }
      a = a.code;
      if (typeof a === "function")
        try {
          return a();
        } catch (d) {}
      return -100;
    };
  function Gx(a) {
    var b, c, d, e, f, g, h, k, l, m, p;
    return Ka(function (q) {
      switch (q.j) {
        case 1:
          return (
            (b = a.Qb
              ? "https://ep1.adtrafficquality.google/getconfig/sodar"
              : "https://pagead2.googlesyndication.com/getconfig/sodar"),
            (c = a.o ? "&sde=1" : ""),
            (d = a.Yb ? "&sjk=" + a.Yb : ""),
            (e = a.h === "cr" && a.Ob === "env" ? a.h + "_" + a.Ob : a.Ob),
            (f =
              b +
              "?sv=200&tid=" +
              a.j +
              ("&tv=" + a.l + "&st=") +
              e +
              ("" + d) +
              ("" + c)),
            (g = void 0),
            q.A(2),
            q.h(Hx(f), 4)
          );
        case 4:
          g = q.l;
          q.N(3);
          break;
        case 2:
          q.o();
        case 3:
          if (!g || a.D) return q.return(void 0);
          h = a.Yb || g.sodar_query_id;
          k = g.rc_enable !== void 0 && a.A ? g.rc_enable : "n";
          l = g.bg_snapshot_delay_ms === void 0 ? "0" : g.bg_snapshot_delay_ms;
          m = g.is_gen_204 === void 0 ? "1" : g.is_gen_204;
          return h && g.bg_hash_basename && g.bg_binary
            ? ((p = {
                context: a.h,
                ti: g.bg_hash_basename,
                si: g.bg_binary,
                pj: a.j + "_" + a.l,
                Yb: h,
                Ob: a.Ob,
                Hd: k,
                ke: l,
                Gd: m,
                Qb: a.Qb,
                kd: a.kd,
                bd: a.bd,
              }),
              a.kb ? q.return(xa({}, p, { kb: !0 })) : q.return(p))
            : q.return(void 0);
      }
    });
  }
  var Hx = function (a) {
    return new Promise(function (b, c) {
      var d = new XMLHttpRequest();
      d.onreadystatechange = function () {
        d.readyState === d.DONE &&
          (d.status >= 200 && d.status < 300
            ? b(Object.assign(Object.create(null), JSON.parse(d.responseText)))
            : c());
      };
      d.open("GET", a, !0);
      d.send();
    });
  };
  var Ix = function (a) {
    var b;
    return Ka(function (c) {
      if (c.j == 1) {
        if (a.kb) {
          Dx().kb = !0;
          var d = Dx();
          window.android &&
            window.android.webview &&
            window.android.webview.getExperimentalMediaIntegrityTokenProvider &&
            d.kb &&
            Fx(d);
        }
        return c.h(Gx(a), 2);
      }
      if ((b = c.l)) {
        d = b;
        var e = "sodar2";
        e = e === void 0 ? "sodar2" : e;
        var f = window,
          g = f.GoogleGcLKhOms;
        (g && typeof g.push === "function") || (g = f.GoogleGcLKhOms = []);
        var h,
          k = {},
          l =
            ((k._ctx_ = d.context),
            (k._bgv_ = d.ti),
            (k._bgp_ = d.si),
            (k._li_ = d.pj),
            (k._jk_ = d.Yb),
            (k._st_ = d.Ob),
            (k._rc_ = d.Hd),
            (k._dl_ = d.ke),
            (k._g2_ = d.Gd),
            (k._atqg_ = d.Qb ? "1" : "0"),
            (k._sic_ = d.kd ? "1" : "0"),
            (k._ivm_ = ((h = d.bd) != null ? h : 1) ? "1" : "0"),
            k);
        d.kb && (l._wvp_ = "1");
        g.push(l);
        if ((g = f.GoogleDX5YKUSkRag)) {
          if (g.length > 0 && (f = g.shift()))
            try {
              f();
            } catch (m) {}
        } else if ((g = f.GoogleDX5YKUSk)) (f.GoogleDX5YKUSk = void 0), g[1]();
        d = d.Qb ? Jk(wx, e) : Jk(vx, e);
        yx(d);
      }
      return c.return(b);
    });
  };
  function Jx(a, b) {
    var c, d;
    return Ka(function (e) {
      return e.j == 1
        ? ((d = (c = a.B) != null ? c : window),
          "requestIdleCallback" in d &&
          typeof d.requestIdleCallback === "function"
            ? e.h(
                new Promise(function (f) {
                  d.requestIdleCallback(
                    function () {
                      return void f();
                    },
                    { timeout: b.Um }
                  );
                }),
                3
              )
            : e.h(
                new Promise(function (f) {
                  d.setTimeout(function () {
                    return void f();
                  }, b.rm);
                }),
                3
              ))
        : e.return(Ix(a));
    });
  }
  var Kx = function (a) {
    this.G = I(a);
  };
  w(Kx, K);
  var Lx = function (a) {
    this.G = I(a);
  };
  w(Lx, K);
  function Mx(a) {
    switch (a) {
      case 1:
        return "gda";
      case 2:
        return "gpt";
      case 3:
        return "ima";
      case 4:
        return "pal";
      case 10:
        return "pal2";
      case 5:
        return "xfad";
      case 6:
        return "dv3n";
      case 7:
        return "spa";
      case 8:
        return "afs";
      case 9:
        return "oos";
      default:
        return "unk";
    }
  }
  var Nx = function (a) {
      this.j = a.A;
      this.l = a.D;
      this.h = a.B;
      this.Yb = a.Yb;
      this.B = a.o;
      this.Ob = a.Ob;
      this.Hd = a.Hd;
      this.ke = a.ke;
      this.Gd = a.Gd;
      this.A = a.j;
      this.Qb = a.Qb;
      this.kb = a.kb;
      this.o = a.h;
      this.kd = a.kd;
      this.D = a.l;
      this.bd = a.bd;
    },
    Ox = function (a, b, c) {
      this.A = a;
      this.D = b;
      this.B = c;
      this.o = window;
      this.Ob = "env";
      this.Hd = "n";
      this.ke = "0";
      this.Gd = "1";
      this.j = !0;
      this.l = this.kd = this.h = this.kb = this.Qb = !1;
      this.bd = !0;
    };
  Ox.prototype.build = function () {
    return new Nx(this);
  };
  var Px = function (a, b) {
    var c = Tg(b, 6) === void 0 ? !0 : Tg(b, 6),
      d,
      e,
      f = Mx(Zg(b, 2)),
      g = Yg(b, 3);
    a: switch (Zg(b, 4)) {
      case 1:
        var h = "pt";
        break a;
      case 2:
        h = "cr";
        break a;
      default:
        h = "";
    }
    f = new Ox(f, g, h);
    g = (e = (d = Ig(b, Kx, 5)) == null ? void 0 : Yg(d, 1)) != null ? e : "";
    f.Yb = g;
    f.j = c;
    f.Qb = !!Tg(b, 7);
    f.kb = !!Tg(b, 8);
    f.h = !!Tg(b, 9);
    f.l = !!Tg(b, 10);
    f.o = a;
    return f.build();
  };
  var Qx = function (a, b, c) {
    c = c === void 0 ? {} : c;
    try {
      Jx(Px(a, b), c).catch(function () {});
    } catch (d) {}
  };
  function Rx(a, b, c, d, e) {
    d = d === void 0 ? {} : d;
    e = e === void 0 ? Qx : e;
    a[c] !== !0 &&
      ((a[c] = !0),
      a.document.readyState === "complete"
        ? e(a, b, d)
        : Tl(a, "load", function () {
            return void e(a, b, d);
          }));
  } /* 
 
Math.uuid.js (v1.4) 
http://www.broofa.com 
mailto:robert@broofa.com 
Copyright (c) 2010 Robert Kieffer 
Dual licensed under the MIT and GPL licenses. 
*/
  var Sx =
    "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz".split("");
  function Tx() {
    for (var a = Array(36), b = 0, c, d = 0; d < 36; d++)
      d == 8 || d == 13 || d == 18 || d == 23
        ? (a[d] = "-")
        : d == 14
        ? (a[d] = "4")
        : (b <= 2 && (b = (33554432 + Math.random() * 16777216) | 0),
          (c = b & 15),
          (b >>= 4),
          (a[d] = Sx[d == 19 ? (c & 3) | 8 : c]));
    return a.join("");
  }
  C.console &&
    typeof C.console.log === "function" &&
    kb(C.console.log, C.console);
  var Ux = function (a) {
    for (var b = [], c = (a = ol(a.ownerDocument)); c != a.top; c = c.parent)
      if (c.frameElement) b.push(c.frameElement);
      else break;
    return b;
  };
  var Vx = function (a, b) {
    this.type = a;
    this.currentTarget = this.target = b;
    this.defaultPrevented = !1;
  };
  Vx.prototype.preventDefault = function () {
    this.defaultPrevented = !0;
  };
  function Wx(a, b) {
    Vx.call(this, a ? a.type : "");
    this.relatedTarget = this.currentTarget = this.target = null;
    this.button = this.screenY = this.screenX = this.clientY = this.clientX = 0;
    this.key = "";
    this.metaKey = this.shiftKey = this.altKey = this.ctrlKey = !1;
    this.state = null;
    this.pointerId = 0;
    this.pointerType = "";
    this.Jc = null;
    a && this.init(a, b);
  }
  ob(Wx, Vx);
  Wx.prototype.init = function (a, b) {
    var c = (this.type = a.type),
      d =
        a.changedTouches && a.changedTouches.length
          ? a.changedTouches[0]
          : null;
    this.target = a.target || a.srcElement;
    this.currentTarget = b;
    b = a.relatedTarget;
    b ||
      (c == "mouseover"
        ? (b = a.fromElement)
        : c == "mouseout" && (b = a.toElement));
    this.relatedTarget = b;
    d
      ? ((this.clientX = d.clientX !== void 0 ? d.clientX : d.pageX),
        (this.clientY = d.clientY !== void 0 ? d.clientY : d.pageY),
        (this.screenX = d.screenX || 0),
        (this.screenY = d.screenY || 0))
      : ((this.clientX = a.clientX !== void 0 ? a.clientX : a.pageX),
        (this.clientY = a.clientY !== void 0 ? a.clientY : a.pageY),
        (this.screenX = a.screenX || 0),
        (this.screenY = a.screenY || 0));
    this.button = a.button;
    this.key = a.key || "";
    this.ctrlKey = a.ctrlKey;
    this.altKey = a.altKey;
    this.shiftKey = a.shiftKey;
    this.metaKey = a.metaKey;
    this.pointerId = a.pointerId || 0;
    this.pointerType = a.pointerType;
    this.state = a.state;
    this.Jc = a;
    a.defaultPrevented && Wx.yb.preventDefault.call(this);
  };
  Wx.prototype.preventDefault = function () {
    Wx.yb.preventDefault.call(this);
    var a = this.Jc;
    a.preventDefault ? a.preventDefault() : (a.returnValue = !1);
  };
  var Xx = (function () {
    if (!C.addEventListener || !Object.defineProperty) return !1;
    var a = !1,
      b = Object.defineProperty({}, "passive", {
        get: function () {
          a = !0;
        },
      });
    try {
      var c = function () {};
      C.addEventListener("test", c, b);
      C.removeEventListener("test", c, b);
    } catch (d) {}
    return a;
  })();
  var Yx = "closure_listenable_" + ((Math.random() * 1e6) | 0),
    Zx = function (a) {
      return !(!a || !a[Yx]);
    };
  var $x = 0;
  function ay(a, b, c, d, e) {
    this.listener = a;
    this.proxy = null;
    this.src = b;
    this.type = c;
    this.capture = !!d;
    this.handler = e;
    this.key = ++$x;
    this.jd = this.rd = !1;
  }
  var by = function (a) {
    a.jd = !0;
    a.listener = null;
    a.proxy = null;
    a.src = null;
    a.handler = null;
  };
  function cy(a) {
    this.src = a;
    this.h = {};
    this.j = 0;
  }
  cy.prototype.add = function (a, b, c, d, e) {
    var f = a.toString();
    a = this.h[f];
    a || ((a = this.h[f] = []), this.j++);
    var g = dy(a, b, d, e);
    g > -1
      ? ((b = a[g]), c || (b.rd = !1))
      : ((b = new ay(b, this.src, f, !!d, e)), (b.rd = c), a.push(b));
    return b;
  };
  cy.prototype.remove = function (a, b, c, d) {
    a = a.toString();
    if (!(a in this.h)) return !1;
    var e = this.h[a];
    b = dy(e, b, c, d);
    return b > -1
      ? (by(e[b]), mc(e, b), e.length == 0 && (delete this.h[a], this.j--), !0)
      : !1;
  };
  var ey = function (a, b) {
    var c = b.type;
    c in a.h &&
      lc(a.h[c], b) &&
      (by(b), a.h[c].length == 0 && (delete a.h[c], a.j--));
  };
  cy.prototype.Sc = function (a, b, c, d) {
    a = this.h[a.toString()];
    var e = -1;
    a && (e = dy(a, b, c, d));
    return e > -1 ? a[e] : null;
  };
  var dy = function (a, b, c, d) {
    for (var e = 0; e < a.length; ++e) {
      var f = a[e];
      if (!f.jd && f.listener == b && f.capture == !!c && f.handler == d)
        return e;
    }
    return -1;
  };
  var fy = "closure_lm_" + ((Math.random() * 1e6) | 0),
    gy = {},
    hy = 0,
    jy = function (a, b, c, d, e) {
      if (d && d.once) return iy(a, b, c, d, e);
      if (Array.isArray(b)) {
        for (var f = 0; f < b.length; f++) jy(a, b[f], c, d, e);
        return null;
      }
      c = ky(c);
      return Zx(a)
        ? a.listen(b, c, cb(d) ? !!d.capture : !!d, e)
        : ly(a, b, c, !1, d, e);
    },
    ly = function (a, b, c, d, e, f) {
      if (!b) throw Error("Invalid event type");
      var g = cb(e) ? !!e.capture : !!e,
        h = my(a);
      h || (a[fy] = h = new cy(a));
      c = h.add(b, c, d, g, f);
      if (c.proxy) return c;
      d = ny();
      c.proxy = d;
      d.src = a;
      d.listener = c;
      if (a.addEventListener)
        Xx || (e = g),
          e === void 0 && (e = !1),
          a.addEventListener(b.toString(), d, e);
      else if (a.attachEvent) a.attachEvent(oy(b.toString()), d);
      else if (a.addListener && a.removeListener) a.addListener(d);
      else throw Error("addEventListener and attachEvent are unavailable.");
      hy++;
      return c;
    },
    ny = function () {
      var a = py,
        b = function (c) {
          return a.call(b.src, b.listener, c);
        };
      return b;
    },
    iy = function (a, b, c, d, e) {
      if (Array.isArray(b)) {
        for (var f = 0; f < b.length; f++) iy(a, b[f], c, d, e);
        return null;
      }
      c = ky(c);
      return Zx(a)
        ? a.Zb(b, c, cb(d) ? !!d.capture : !!d, e)
        : ly(a, b, c, !0, d, e);
    },
    qy = function (a, b, c, d, e) {
      if (Array.isArray(b))
        for (var f = 0; f < b.length; f++) qy(a, b[f], c, d, e);
      else
        (d = cb(d) ? !!d.capture : !!d),
          (c = ky(c)),
          Zx(a)
            ? a.Ma(b, c, d, e)
            : a && (a = my(a)) && (b = a.Sc(b, c, d, e)) && ry(b);
    },
    ry = function (a) {
      if (typeof a !== "number" && a && !a.jd) {
        var b = a.src;
        if (Zx(b)) ey(b.D, a);
        else {
          var c = a.type,
            d = a.proxy;
          b.removeEventListener
            ? b.removeEventListener(c, d, a.capture)
            : b.detachEvent
            ? b.detachEvent(oy(c), d)
            : b.addListener && b.removeListener && b.removeListener(d);
          hy--;
          (c = my(b))
            ? (ey(c, a), c.j == 0 && ((c.src = null), (b[fy] = null)))
            : by(a);
        }
      }
    },
    oy = function (a) {
      return a in gy ? gy[a] : (gy[a] = "on" + a);
    },
    py = function (a, b) {
      if (a.jd) a = !0;
      else {
        b = new Wx(b, this);
        var c = a.listener,
          d = a.handler || a.src;
        a.rd && ry(a);
        a = c.call(d, b);
      }
      return a;
    },
    my = function (a) {
      a = a[fy];
      return a instanceof cy ? a : null;
    },
    sy = "__closure_events_fn_" + ((Math.random() * 1e9) >>> 0),
    ky = function (a) {
      if (typeof a === "function") return a;
      a[sy] ||
        (a[sy] = function (b) {
          return a.handleEvent(b);
        });
      return a[sy];
    };
  function S() {
    R.call(this);
    this.D = new cy(this);
    this.Gi = this;
    this.za = null;
  }
  ob(S, R);
  S.prototype[Yx] = !0;
  n = S.prototype;
  n.addEventListener = function (a, b, c, d) {
    jy(this, a, b, c, d);
  };
  n.removeEventListener = function (a, b, c, d) {
    qy(this, a, b, c, d);
  };
  n.dispatchEvent = function (a) {
    var b,
      c = this.za;
    if (c) for (b = []; c; c = c.za) b.push(c);
    c = this.Gi;
    var d = a.type || a;
    if (typeof a === "string") a = new Vx(a, c);
    else if (a instanceof Vx) a.target = a.target || c;
    else {
      var e = a;
      a = new Vx(d, c);
      gl(a, e);
    }
    e = !0;
    var f;
    if (b)
      for (f = b.length - 1; f >= 0; f--) {
        var g = (a.currentTarget = b[f]);
        e = ty(g, d, !0, a) && e;
      }
    g = a.currentTarget = c;
    e = ty(g, d, !0, a) && e;
    e = ty(g, d, !1, a) && e;
    if (b)
      for (f = 0; f < b.length; f++)
        (g = a.currentTarget = b[f]), (e = ty(g, d, !1, a) && e);
    return e;
  };
  n.M = function () {
    S.yb.M.call(this);
    this.lf();
    this.za = null;
  };
  n.listen = function (a, b, c, d) {
    return this.D.add(String(a), b, !1, c, d);
  };
  n.Zb = function (a, b, c, d) {
    return this.D.add(String(a), b, !0, c, d);
  };
  n.Ma = function (a, b, c, d) {
    this.D.remove(String(a), b, c, d);
  };
  n.lf = function () {
    if (this.D) {
      var a = this.D,
        b = 0,
        c;
      for (c in a.h) {
        for (var d = a.h[c], e = 0; e < d.length; e++) ++b, by(d[e]);
        delete a.h[c];
        a.j--;
      }
    }
  };
  var ty = function (a, b, c, d) {
    b = a.D.h[String(b)];
    if (!b) return !0;
    b = b.concat();
    for (var e = !0, f = 0; f < b.length; ++f) {
      var g = b[f];
      if (g && !g.jd && g.capture == c) {
        var h = g.listener,
          k = g.handler || g.src;
        g.rd && ey(a.D, g);
        e = h.call(k, d) !== !1 && e;
      }
    }
    return e && !d.defaultPrevented;
  };
  S.prototype.Sc = function (a, b, c, d) {
    return this.D.Sc(String(a), b, c, d);
  };
  var uy =
    typeof AsyncContext !== "undefined" &&
    typeof AsyncContext.Snapshot === "function"
      ? function (a) {
          return a && AsyncContext.Snapshot.wrap(a);
        }
      : function (a) {
          return a;
        };
  var vy = function (a, b) {
    this.l = a;
    this.o = b;
    this.j = 0;
    this.h = null;
  };
  vy.prototype.get = function () {
    if (this.j > 0) {
      this.j--;
      var a = this.h;
      this.h = a.next;
      a.next = null;
    } else a = this.l();
    return a;
  };
  var wy = function (a, b) {
    a.o(b);
    a.j < 100 && (a.j++, (b.next = a.h), (a.h = b));
  };
  var yy = function () {
    this.j = this.h = null;
  };
  yy.prototype.add = function (a, b) {
    var c = zy.get();
    c.set(a, b);
    this.j ? (this.j.next = c) : (this.h = c);
    this.j = c;
  };
  yy.prototype.remove = function () {
    var a = null;
    this.h &&
      ((a = this.h),
      (this.h = this.h.next),
      this.h || (this.j = null),
      (a.next = null));
    return a;
  };
  var zy = new vy(
      function () {
        return new Ay();
      },
      function (a) {
        return a.reset();
      }
    ),
    Ay = function () {
      this.next = this.h = this.j = null;
    };
  Ay.prototype.set = function (a, b) {
    this.j = a;
    this.h = b;
    this.next = null;
  };
  Ay.prototype.reset = function () {
    this.next = this.h = this.j = null;
  };
  var By,
    Cy = !1,
    Dy = new yy(),
    Fy = function (a, b) {
      By || Ey();
      Cy || (By(), (Cy = !0));
      Dy.add(a, b);
    },
    Ey = function () {
      var a = Promise.resolve(void 0);
      By = function () {
        a.then(Gy);
      };
    };
  function Gy() {
    for (var a; (a = Dy.remove()); ) {
      try {
        a.j.call(a.h);
      } catch (b) {
        Ab(b);
      }
      wy(zy, a);
    }
    Cy = !1;
  }
  var Hy = function (a) {
    if (!a) return !1;
    try {
      return !!a.$goog_Thenable;
    } catch (b) {
      return !1;
    }
  };
  var Jy = function (a) {
      this.la = 0;
      this.D = void 0;
      this.l = this.h = this.j = null;
      this.o = this.A = !1;
      if (a != Lj)
        try {
          var b = this;
          a.call(
            void 0,
            function (c) {
              Iy(b, 2, c);
            },
            function (c) {
              Iy(b, 3, c);
            }
          );
        } catch (c) {
          Iy(this, 3, c);
        }
    },
    Ky = function () {
      this.next = this.context = this.j = this.l = this.h = null;
      this.o = !1;
    };
  Ky.prototype.reset = function () {
    this.context = this.j = this.l = this.h = null;
    this.o = !1;
  };
  var Ly = new vy(
      function () {
        return new Ky();
      },
      function (a) {
        a.reset();
      }
    ),
    My = function (a, b, c) {
      var d = Ly.get();
      d.l = a;
      d.j = b;
      d.context = c;
      return d;
    };
  Jy.prototype.then = function (a, b, c) {
    return Ny(
      this,
      uy(typeof a === "function" ? a : null),
      uy(typeof b === "function" ? b : null),
      c
    );
  };
  Jy.prototype.$goog_Thenable = !0;
  Jy.prototype.B = function (a, b) {
    return Ny(this, null, uy(a), b);
  };
  Jy.prototype.catch = Jy.prototype.B;
  Jy.prototype.cancel = function (a) {
    if (this.la == 0) {
      var b = new Oy(a);
      Fy(function () {
        Py(this, b);
      }, this);
    }
  };
  var Py = function (a, b) {
      if (a.la == 0)
        if (a.j) {
          var c = a.j;
          if (c.h) {
            for (
              var d = 0, e = null, f = null, g = c.h;
              g && (g.o || (d++, g.h == a && (e = g), !(e && d > 1)));
              g = g.next
            )
              e || (f = g);
            e &&
              (c.la == 0 && d == 1
                ? Py(c, b)
                : (f
                    ? ((d = f),
                      d.next == c.l && (c.l = d),
                      (d.next = d.next.next))
                    : Qy(c),
                  Ry(c, e, 3, b)));
          }
          a.j = null;
        } else Iy(a, 3, b);
    },
    Ty = function (a, b) {
      a.h || (a.la != 2 && a.la != 3) || Sy(a);
      a.l ? (a.l.next = b) : (a.h = b);
      a.l = b;
    },
    Ny = function (a, b, c, d) {
      var e = My(null, null, null);
      e.h = new Jy(function (f, g) {
        e.l = b
          ? function (h) {
              try {
                var k = b.call(d, h);
                f(k);
              } catch (l) {
                g(l);
              }
            }
          : f;
        e.j = c
          ? function (h) {
              try {
                var k = c.call(d, h);
                k === void 0 && h instanceof Oy ? g(h) : f(k);
              } catch (l) {
                g(l);
              }
            }
          : g;
      });
      e.h.j = a;
      Ty(a, e);
      return e.h;
    };
  Jy.prototype.F = function (a) {
    this.la = 0;
    Iy(this, 2, a);
  };
  Jy.prototype.N = function (a) {
    this.la = 0;
    Iy(this, 3, a);
  };
  var Iy = function (a, b, c) {
      if (a.la == 0) {
        a === c &&
          ((b = 3), (c = new TypeError("Promise cannot resolve to itself")));
        a.la = 1;
        a: {
          var d = c,
            e = a.F,
            f = a.N;
          if (d instanceof Jy) {
            Ty(d, My(e || Lj, f || null, a));
            var g = !0;
          } else if (Hy(d)) d.then(e, f, a), (g = !0);
          else {
            if (cb(d))
              try {
                var h = d.then;
                if (typeof h === "function") {
                  Uy(d, h, e, f, a);
                  g = !0;
                  break a;
                }
              } catch (k) {
                f.call(a, k);
                g = !0;
                break a;
              }
            g = !1;
          }
        }
        g ||
          ((a.D = c),
          (a.la = b),
          (a.j = null),
          Sy(a),
          b != 3 || c instanceof Oy || Vy(a, c));
      }
    },
    Uy = function (a, b, c, d, e) {
      var f = !1,
        g = function (k) {
          f || ((f = !0), c.call(e, k));
        },
        h = function (k) {
          f || ((f = !0), d.call(e, k));
        };
      try {
        b.call(a, g, h);
      } catch (k) {
        h(k);
      }
    },
    Sy = function (a) {
      a.A || ((a.A = !0), Fy(a.C, a));
    },
    Qy = function (a) {
      var b = null;
      a.h && ((b = a.h), (a.h = b.next), (b.next = null));
      a.h || (a.l = null);
      return b;
    };
  Jy.prototype.C = function () {
    for (var a; (a = Qy(this)); ) Ry(this, a, this.la, this.D);
    this.A = !1;
  };
  var Ry = function (a, b, c, d) {
      if (c == 3 && b.j && !b.o) for (; a && a.o; a = a.j) a.o = !1;
      if (b.h) (b.h.j = null), Wy(b, c, d);
      else
        try {
          b.o ? b.l.call(b.context) : Wy(b, c, d);
        } catch (e) {
          Xy.call(null, e);
        }
      wy(Ly, b);
    },
    Wy = function (a, b, c) {
      b == 2 ? a.l.call(a.context, c) : a.j && a.j.call(a.context, c);
    },
    Vy = function (a, b) {
      a.o = !0;
      Fy(function () {
        a.o && Xy.call(null, b);
      });
    },
    Xy = Ab,
    Oy = function (a) {
      pb.call(this, a);
    };
  ob(Oy, pb);
  Oy.prototype.name = "cancel";
  function Yy(a, b) {
    var c = this;
    S.call(this);
    this.j = a || 1;
    this.h = b || C;
    this.l = function () {
      if (c.enabled) {
        var d = Date.now() - c.o;
        d > 0 && d < c.j * 0.8
          ? (c.Sa = c.h.setTimeout(c.l, c.j - d))
          : (c.Sa && (c.h.clearTimeout(c.Sa), (c.Sa = null)),
            c.dispatchEvent("tick"),
            c.enabled && (c.stop(), c.start()));
      }
    };
    this.o = Date.now();
  }
  ob(Yy, S);
  n = Yy.prototype;
  n.enabled = !1;
  n.Sa = null;
  n.setInterval = function (a) {
    this.j = a;
    this.Sa && this.enabled
      ? (this.stop(), this.start())
      : this.Sa && this.stop();
  };
  n.start = function () {
    this.enabled = !0;
    this.Sa ||
      ((this.Sa = this.h.setTimeout(this.l, this.j)), (this.o = Date.now()));
  };
  n.stop = function () {
    this.enabled = !1;
    this.Sa && (this.h.clearTimeout(this.Sa), (this.Sa = null));
  };
  n.M = function () {
    Yy.yb.M.call(this);
    this.stop();
    delete this.h;
  };
  var Zy = function (a, b) {
      if (typeof a !== "function")
        if (a && typeof a.handleEvent == "function") a = a.handleEvent.bind(a);
        else throw Error("Invalid listener argument");
      return Number(b) > 2147483647 ? -1 : C.setTimeout(a, b || 0);
    },
    $y = function (a, b) {
      var c = null;
      return new Jy(function (d, e) {
        c = Zy(function () {
          d(b);
        }, a);
        c == -1 && e(Error("Failed to schedule timer."));
      }).B(function (d) {
        C.clearTimeout(c);
        throw d;
      });
    };
  var az = function () {
    return Math.round(Date.now() / 1e3);
  };
  var bz = function () {
    this.h = {};
    return this;
  };
  bz.prototype.remove = function (a) {
    var b = this.h;
    a in b && delete b[a];
  };
  bz.prototype.set = function (a, b) {
    this.h[a] = b;
  };
  var cz = function (a, b) {
    a.h.eb = el(a.h, "eb", 0) | b;
  };
  bz.prototype.get = function (a) {
    return el(this.h, a, null);
  };
  bz.prototype.ha = function () {
    var a = [],
      b;
    for (b in this.h) a.push(b + this.h[b]);
    return a.join("_");
  };
  var dz = null,
    ez = function () {
      this.h = {};
      this.j = 0;
    },
    fz = function () {
      dz || (dz = new ez());
      return dz;
    },
    gz = function (a, b) {
      a.h[b.getName()] = b;
    };
  ez.prototype.ha = function (a) {
    var b = [];
    a || (a = 0);
    for (var c in this.h) {
      var d = this.h[c];
      d instanceof hz
        ? d.getValue() && (a |= d.A)
        : (d = this.h[c].ha()) && b.push(c + d);
    }
    b.push("eb" + String(a));
    return b.join("_");
  };
  var iz = function (a, b) {
    this.o = a;
    this.l = !0;
    this.h = b;
  };
  iz.prototype.getName = function () {
    return this.o;
  };
  iz.prototype.getValue = function () {
    return this.h;
  };
  iz.prototype.ha = function () {
    return this.l ? this.j() : "";
  };
  iz.prototype.j = function () {
    return String(this.h);
  };
  var hz = function (a, b) {
    iz.call(this, String(a), b);
    this.A = a;
    this.h = !!b;
  };
  w(hz, iz);
  hz.prototype.j = function () {
    return this.h ? "1" : "0";
  };
  var jz = function (a, b) {
    iz.call(this, a, b);
  };
  w(jz, iz);
  jz.prototype.j = function () {
    return this.h
      ? Math.round(this.h.top) +
          "." +
          Math.round(this.h.left) +
          "." +
          (Math.round(this.h.top) + Math.round(this.h.height)) +
          "." +
          (Math.round(this.h.left) + Math.round(this.h.width))
      : "";
  };
  var kz = function (a) {
    if (a.match(/^-?[0-9]+\.-?[0-9]+\.-?[0-9]+\.-?[0-9]+$/)) {
      a = a.split(".");
      var b = Number(a[0]),
        c = Number(a[1]);
      return new jz("", new Bl(c, b, Number(a[3]) - c, Number(a[2]) - b));
    }
    return new jz("", new Bl(0, 0, 0, 0));
  };
  var lz = function (a) {
      var b = new Bl(
          -Number.MAX_VALUE / 2,
          -Number.MAX_VALUE / 2,
          Number.MAX_VALUE,
          Number.MAX_VALUE
        ),
        c = new Bl(0, 0, 0, 0);
      if (!a || 0 == a.length) return c;
      for (var d = 0; d < a.length; d++) {
        a: {
          var e = b;
          var f = a[d],
            g = Math.max(e.left, f.left),
            h = Math.min(e.left + e.width, f.left + f.width);
          if (g <= h) {
            var k = Math.max(e.top, f.top);
            f = Math.min(e.top + e.height, f.top + f.height);
            if (k <= f) {
              e.left = g;
              e.top = k;
              e.width = h - g;
              e.height = f - k;
              e = !0;
              break a;
            }
          }
          e = !1;
        }
        if (!e) return c;
      }
      return b;
    },
    mz = function (a, b) {
      var c = a.getBoundingClientRect();
      a = Ml(a, b);
      return new Bl(
        Math.round(a.x),
        Math.round(a.y),
        Math.round(c.right - c.left),
        Math.round(c.bottom - c.top)
      );
    },
    nz = function (a, b, c) {
      if (b && c) {
        a: {
          var d = Math.max(b.left, c.left);
          var e = Math.min(b.left + b.width, c.left + c.width);
          if (d <= e) {
            var f = Math.max(b.top, c.top),
              g = Math.min(b.top + b.height, c.top + c.height);
            if (f <= g) {
              d = new Bl(d, f, e - d, g - f);
              break a;
            }
          }
          d = null;
        }
        e = d ? d.height * d.width : 0;
        f = d ? b.height * b.width : 0;
        d = d && f ? Math.round((e / f) * 100) : 0;
        gz(a, new iz("vp", d));
        d && d > 0
          ? ((e = Cl(b)), (f = Cl(c)), (e = e.top >= f.top && e.top < f.bottom))
          : (e = !1);
        gz(a, new hz(512, e));
        d && d > 0
          ? ((e = Cl(b)),
            (f = Cl(c)),
            (e = e.bottom <= f.bottom && e.bottom > f.top))
          : (e = !1);
        gz(a, new hz(1024, e));
        d && d > 0
          ? ((e = Cl(b)),
            (f = Cl(c)),
            (e = e.left >= f.left && e.left < f.right))
          : (e = !1);
        gz(a, new hz(2048, e));
        d && d > 0
          ? ((b = Cl(b)),
            (c = Cl(c)),
            (c = b.right <= c.right && b.right > c.left))
          : (c = !1);
        gz(a, new hz(4096, c));
      }
    };
  var oz = function (a, b) {
    var c = 0;
    Yk(ol(), "ima", "video", "client", "tagged") && (c = 1);
    var d = null;
    a && (d = a());
    if (d) {
      a = fz();
      a.h = {};
      var e = new hz(32, !0);
      e.l = !1;
      gz(a, e);
      e = ol().document;
      e =
        e.visibilityState ||
        e.webkitVisibilityState ||
        e.mozVisibilityState ||
        e.msVisibilityState ||
        "";
      gz(a, new hz(64, e.toLowerCase().substring(e.length - 6) != "hidden"));
      a: {
        try {
          var f = ol().top;
          try {
            var g = !!f.location.href || f.location.href === "";
          } catch (m) {
            g = !1;
          }
          if (g) {
            var h = Ux(d);
            var k = h && h.length != 0 ? "1" : "0";
            break a;
          }
          k = "2";
          break a;
        } catch (m) {
          k = "2";
          break a;
        }
        k = void 0;
      }
      gz(a, new hz(256, k == "2"));
      gz(a, new hz(128, k == "1"));
      h = g = ol().top;
      k == "2" && (h = ol());
      f = mz(d, h);
      gz(a, new jz("er", f));
      try {
        var l = h.document && !h.document.body ? null : nl(h || window);
      } catch (m) {
        l = null;
      }
      l
        ? ((h = xl(jl(h.document))),
          gz(a, new hz(16384, !!h)),
          (l = h ? new Bl(h.x, h.y, l.width, l.height) : null))
        : (l = null);
      gz(a, new jz("vi", l));
      if (l && "1" == k) {
        k = Ux(d);
        d = [];
        for (h = 0; h < k.length; h++) (e = mz(k[h], g)) && d.push(e);
        d.push(l);
        l = lz(d);
      }
      nz(a, f, l);
      a.j && gz(a, new iz("ts", az() - a.j));
      a.j = az();
    } else (a = fz()), (a.h = {}), (a.j = az()), gz(a, new hz(32, !1));
    this.l = a;
    this.h = new bz();
    this.h.set("ve", 4);
    c && cz(this.h, 1);
    Yk(ol(), "ima", "video", "client", "crossdomainTag") && cz(this.h, 4);
    Yk(ol(), "ima", "video", "client", "sdkTag") && cz(this.h, 8);
    Yk(ol(), "ima", "video", "client", "jsTag") && cz(this.h, 2);
    b && el(b, "fullscreen", !1) && cz(this.h, 16);
    this.j = b = null;
    if (c && ((c = Yk(ol(), "ima", "video", "client")), c.getEData)) {
      this.j = c.getEData();
      if ((c = Yk(ol(), "ima", "video", "client", "getLastSnapshotFromTop")))
        if ((a = c()))
          this.j.extendWithDataFromTopIframe(
            a.tagstamp,
            a.playstamp,
            a.lactstamp
          ),
            (c = this.l),
            (b = a.er),
            (a = a.vi),
            b &&
              a &&
              ((b = kz(b).getValue()),
              (a = kz(a).getValue()),
              (k = null),
              el(c.h, "er", null) &&
                ((k = el(c.h, "er", null).getValue()),
                (k.top += b.top),
                (k.left += b.left),
                gz(c, new jz("er", k))),
              el(c.h, "vi", null) &&
                ((l = el(c.h, "vi", null).getValue()),
                (l.top += b.top),
                (l.left += b.left),
                (d = []),
                d.push(l),
                d.push(b),
                d.push(a),
                (b = lz(d)),
                nz(c, k, b),
                gz(c, new jz("vi", a))));
      a: {
        if (this.j) {
          if (this.j.getTagLoadTimestamp) {
            b = this.j.getTagLoadTimestamp();
            break a;
          }
          if (this.j.getTimeSinceTagLoadSeconds) {
            b = this.j.getTimeSinceTagLoadSeconds();
            break a;
          }
        }
        b = null;
      }
    }
    c = this.h;
    a =
      window.performance &&
      window.performance.timing &&
      window.performance.timing.domLoading &&
      window.performance.timing.domLoading > 0
        ? Math.round(window.performance.timing.domLoading / 1e3)
        : null;
    c.set.call(c, "td", az() - (a != null ? a : b != null ? b : az()));
  };
  oz.prototype.ha = function () {
    var a = [],
      b = Number(this.h.get("eb"));
    this.h.remove("eb");
    var c = this.h.ha();
    c && a.push(c);
    this.j && (c = this.j.serialize()) && a.push(c);
    (c = this.l.ha(b)) && a.push(c);
    this.h.set("eb", b);
    return a.join("_");
  };
  new Yy(200);
  var pz = function (a) {
    this.G = I(a);
  };
  w(pz, K);
  pz.prototype.getId = function () {
    return Yg(this, 1);
  };
  var qz = [0, gj];
  var rz = function (a) {
    this.G = I(a);
  };
  w(rz, K);
  var sz = [0, gj, -3];
  var tz = function (a) {
    this.G = I(a);
  };
  w(tz, K);
  tz.prototype.getWidth = function () {
    return Ug(this, 1);
  };
  tz.prototype.getHeight = function () {
    return Ug(this, 2);
  };
  var uz = [0, dj, -1];
  var vz = function (a) {
    this.G = I(a);
  };
  w(vz, K);
  var wz = [0, aj, fj, gj, -1];
  var xz = function (a) {
    this.G = I(a);
  };
  w(xz, K);
  xz.prototype.getAdId = function () {
    return Yg(this, 1);
  };
  xz.prototype.getSize = function () {
    return Ig(this, tz, 7);
  };
  xz.prototype.xc = function () {
    return Ig(this, vz, 9);
  };
  var yz = [0, gj, aj, gj, hj, lj, qz, uz, aj, wz, gj, sz];
  var zz = function (a) {
    this.G = I(a);
  };
  w(zz, K);
  var Az = function (a, b) {
      return ih(a, 1, b);
    },
    Bz = function (a, b) {
      return bh(a, 4, b);
    },
    Cz = function (a, b) {
      return dh(a, 2, b);
    };
  var Rg = function (a) {
    this.G = I(a);
  };
  w(Rg, K);
  var Dz = function (a, b) {
      return hh(a, 1, b);
    },
    Ez = function (a, b) {
      return Qg(a, 3, xz, b);
    },
    Fz = function (a, b) {
      return ih(a, 4, b);
    },
    Gz = function (a, b) {
      return bh(a, 6, b);
    },
    Hz = function (a, b) {
      return ih(a, 7, b);
    };
  var Iz = [0, lj, dj, gj, fj];
  var Jz = [0, gj, aj, ij, yz, lj, Iz, fj, lj, 2, hj];
  var Kz = function (a) {
    this.G = I(a);
  };
  w(Kz, K);
  var Lz = [0, lj, ij, Jz, lj, gj, Iz, gj, fj, dj, [0, lj, fj, aj], gj, -1];
  var Mz = function (a) {
    this.G = I(a);
  };
  w(Mz, K);
  var Nz = nj([0, ij, Lz]);
  var Oz = pj(Cj);
  var Pz = function (a) {
    this.G = I(a);
  };
  w(Pz, K);
  var Qz = function (a) {
    var b = new Pz();
    return ih(b, 1, a);
  };
  var Rz = [0, lj];
  var Sz = function (a) {
    this.G = I(a);
  };
  w(Sz, K);
  var Tz = function (a, b) {
      return hh(a, 1, b);
    },
    Uz = function (a) {
      jg(a, 2);
    },
    Vz = function (a) {
      var b = window.Date.now();
      b = Number.isFinite(b) ? Math.round(b) : 0;
      return fh(a, 3, b);
    };
  Sz.prototype.getError = function () {
    return Ig(this, Pz, 10);
  };
  Sz.prototype.Da = function (a) {
    return Mg(this, 10, a);
  };
  var Wz = qj(Sz);
  var Xz = [0, gj, -1, aj, dj, -2, aj, Zi, fj, Rz, fj];
  var Yz = [0, 1, [0, cj, -2], -1, gj, -1, fj, [0, 3, lj, gj], aj, mj, kj];
  var Zz = function (a) {
    this.G = I(a);
  };
  w(Zz, K);
  var $z = [0, ij, Yz, ij, Xz];
  Zz.prototype.j = oj($z);
  var aA = (function (a, b) {
    return function (c, d) {
      a: {
        var e = { Cf: !0 };
        d && Object.assign(e, d);
        c = zh(c, void 0, void 0, e);
        try {
          var f = new a(),
            g = f.G;
          Ii(b)(g, c);
          var h = f;
          break a;
        } catch (k) {
          if (k instanceof RangeError) throw new SyntaxError();
          throw k;
        } finally {
          Ah(c);
        }
        h = void 0;
      }
      return h;
    };
  })(Zz, $z);
  var dA = function () {
    var a = bA,
      b = cA;
    b = b === void 0 ? null : b;
    this.pinger = a;
    this.A = "jserror";
    this.j = !0;
    this.h = b;
    this.l = null;
    this.o = !1;
    this.Ba = this.lb;
  };
  n = dA.prototype;
  n.tf = function (a) {
    this.l = a;
  };
  n.bh = function (a) {
    this.A = a;
  };
  n.wf = function (a) {
    this.j = a;
  };
  n.eh = function (a) {
    this.o = a;
  };
  n.bc = function (a, b, c) {
    try {
      if (this.h && this.h.l) {
        var d = this.h.start(a.toString(), 3);
        var e = b();
        this.h.end(d);
      } else e = b();
    } catch (h) {
      b = this.j;
      try {
        Kn(d), (b = this.Ba(a, new Fj(h, { message: Hj(h) }), void 0, c));
      } catch (k) {
        this.lb(217, k);
      }
      if (b) {
        var f, g;
        (f = window.console) == null || (g = f.error) == null || g.call(f, h);
      } else throw h;
    }
    return e;
  };
  n.jf = function (a, b, c, d) {
    var e = this;
    return function () {
      var f = La.apply(0, arguments);
      return e.bc(
        a,
        function () {
          return b.apply(c, f);
        },
        d
      );
    };
  };
  n.lb = function (a, b, c, d, e) {
    e = e || this.A;
    var f = void 0;
    try {
      var g = new wr();
      Br(g, 1, "context", a);
      Gj(b) || (b = new Fj(b, { message: Hj(b) }));
      b.msg && Br(g, 2, "msg", b.msg.substring(0, 512));
      var h = b.meta || {};
      if (this.l)
        try {
          this.l(h);
        } catch (m) {}
      if (d)
        try {
          d(h);
        } catch (m) {}
      Ar(g, 3, [h]);
      f = vr();
      f.j && Br(g, 4, "top", f.j.url || "");
      Ar(g, 5, [{ url: f.h.url || "" }, { url: f.h.url ? fq(f.h.url) : "" }]);
      eA(this.pinger, e, g, this.o, c);
    } catch (m) {
      try {
        var k, l;
        eA(
          this.pinger,
          e,
          {
            context: "ecmserr",
            rctx: a,
            msg: Hj(m),
            url: (l = (k = f) == null ? void 0 : k.h.url) != null ? l : "",
          },
          this.o,
          c
        );
      } catch (p) {}
    }
    return this.j;
  };
  var fA = function () {
      var a = a === void 0 ? !1 : a;
      this.domain = "pagead2.googlesyndication.com";
      this.path = "/pagead/gen_204?id=";
      this.j = a;
      this.protocol = "https:";
      this.h = Math.random();
    },
    gA = function () {
      var a = bA,
        b = window.google_srt;
      b >= 0 && b <= 1 && (a.h = b);
    },
    eA = function (a, b, c, d, e) {
      if (((d === void 0 ? 0 : d) ? a.h : Math.random()) < (e || 0.01))
        try {
          if (c instanceof wr) var f = c;
          else
            (f = new wr()),
              Ij(c, function (h, k) {
                var l = f,
                  m = l.o++;
                Ar(l, m, xr(k, h));
              });
          var g = Er(f, a.protocol, a.domain, a.path + b + "&");
          g && (a.j ? Xl(g) : Vl(C, g));
        } catch (h) {}
    };
  var bA,
    hA,
    cA = new Jn(1, window);
  (function (a) {
    bA = a != null ? a : new fA();
    typeof window.google_srt !== "number" &&
      (window.google_srt = Math.random());
    gA();
    hA = new dA();
    hA.tf(function () {});
    hA.eh(!0);
    window.document.readyState === "complete"
      ? window.google_measure_js_timing || cA.disable()
      : cA.l &&
        Tl(window, "load", function () {
          window.google_measure_js_timing || cA.disable();
        });
  })();
  var iA = function (a) {
    this.G = I(a);
  };
  w(iA, K);
  [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce(function (
    a,
    b
  ) {
    return a + b;
  });
  [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce(function (a, b) {
    return a + b;
  });
  [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce(function (
    a,
    b
  ) {
    return a + b;
  });
  [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce(function (
    a,
    b
  ) {
    return a + b;
  });
  [
    2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
    2, 2, 2, 2, 2, 2, 2,
  ].reduce(function (a, b) {
    return a + b;
  });
  [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce(function (a, b) {
    return a + b;
  });
  var jA = function (a) {
    this.G = I(a);
  };
  w(jA, K);
  var kA = function (a, b) {
    return vg(a, 1, b, Ue);
  };
  var lA = function (a) {
    this.G = I(a);
  };
  w(lA, K);
  var mA = function (a) {
    this.G = I(a);
  };
  w(mA, K);
  var nA = function (a, b) {
      return vg(a, 1, b, Se);
    },
    oA = function (a, b) {
      return vg(a, 2, b, Se);
    },
    pA = function (a, b) {
      return vg(a, 3, b, Ue);
    },
    qA = function (a, b) {
      vg(a, 4, b, Ue);
    };
  var rA = function (a) {
    this.G = I(a);
  };
  w(rA, K);
  rA.prototype.getVersion = function () {
    return Ug(this, 1);
  };
  var sA = function (a, b) {
      return eh(a, 1, b);
    },
    tA = function (a, b) {
      return Mg(a, 2, b);
    },
    uA = function (a, b) {
      return Mg(a, 3, b);
    },
    vA = function (a, b) {
      return eh(a, 4, b);
    },
    wA = function (a, b) {
      return eh(a, 5, b);
    },
    xA = function (a, b) {
      return eh(a, 6, b);
    },
    yA = function (a, b) {
      return wg(a, 7, hf(b), "");
    },
    zA = function (a, b) {
      return eh(a, 8, b);
    },
    AA = function (a, b) {
      return eh(a, 9, b);
    },
    BA = function (a, b) {
      return ch(a, 10, b);
    },
    CA = function (a, b) {
      return ch(a, 11, b);
    },
    DA = function (a, b) {
      return vg(a, 12, b, Se);
    },
    EA = function (a, b) {
      return vg(a, 13, b, Se);
    },
    FA = function (a, b) {
      return vg(a, 14, b, Se);
    },
    GA = function (a, b) {
      return ch(a, 15, b);
    },
    HA = function (a, b) {
      return wg(a, 16, hf(b), "");
    },
    IA = function (a, b) {
      return vg(a, 17, b, Ue);
    },
    JA = function (a, b) {
      return vg(a, 18, b, Ue);
    },
    KA = function (a, b) {
      return Og(a, 19, b);
    };
  var LA = function (a) {
    this.G = I(a);
  };
  w(LA, K);
  var MA = Wk({
      pl: 0,
      ol: 1,
      ll: 2,
      gl: 3,
      ml: 4,
      hl: 5,
      nl: 6,
      jl: 7,
      kl: 8,
      el: 9,
      il: 10,
      ql: 11,
    }).map(function (a) {
      return Number(a);
    }),
    NA = Wk({ tl: 0, ul: 1, rl: 2 }).map(function (a) {
      return Number(a);
    });
  var OA = function (a) {
      this.j = a;
      this.h = 0;
      if (/[^01]/.test(this.j))
        throw Error("Input bitstring " + this.j + " is malformed!");
    },
    QA = function (a) {
      a = PA(a, 36);
      var b = new iA();
      b = gh(b, 1, Math.floor(a / 10));
      return eh(b, 2, (a % 10) * 1e8);
    },
    RA = function (a) {
      var b = function () {
        var c = PA(a, 6);
        if (c > 25 || c < 0)
          throw Error(
            "Invalid character code, expected in range [0,25], got: " + c
          );
        return String.fromCharCode(97 + c);
      };
      return b() + b();
    },
    UA = function (a) {
      var b = PA(a, 16);
      if (!!PA(a, 1) === !0) {
        a = SA(a);
        var c = y(a),
          d = c.next();
        try {
          for (; !d.done; d = c.next()) {
            var e = d.value;
            if (e > b)
              throw Error("ID " + e + " is past MaxVendorId " + b + "!");
          }
        } finally {
          z(c, d);
        }
        return a;
      }
      return TA(a, b);
    },
    VA = function (a) {
      for (var b = [], c = PA(a, 12); c--; ) {
        var d = PA(a, 6),
          e = PA(a, 2),
          f = SA(a),
          g = b,
          h = g.push,
          k = new lA();
        d = jh(k, 1, d);
        e = jh(d, 2, e);
        f = vg(e, 3, f, Ue);
        h.call(g, f);
      }
      return b;
    },
    SA = function (a) {
      for (var b = PA(a, 12), c = []; b--; ) {
        var d = !!PA(a, 1) === !0,
          e = PA(a, 16);
        if (d) for (d = PA(a, 16); e <= d; e++) c.push(e);
        else c.push(e);
      }
      c.sort(function (f, g) {
        return f - g;
      });
      return c;
    },
    TA = function (a, b, c) {
      for (var d = [], e = 0; e < b; e++)
        if (PA(a, 1)) {
          var f = e + 1;
          if (c && c.indexOf(f) === -1)
            throw Error("ID: " + f + " is outside of allowed values!");
          d.push(f);
        }
      return d;
    },
    PA = function (a, b) {
      if (a.h + b > a.j.length)
        throw Error("Requested length " + b + " is past end of string.");
      var c = a.j.substring(a.h, a.h + b);
      a.h += b;
      return parseInt(c, 2);
    };
  OA.prototype.skip = function (a) {
    this.h += a;
  };
  function WA(a) {
    try {
      var b = Zc(a)
          .map(function (d) {
            return d.toString(2).padStart(8, "0");
          })
          .join(""),
        c = new OA(b);
      return PA(c, 3) !== 1 ? null : kA(new jA(), UA(c));
    } catch (d) {
      return null;
    }
  }
  function XA(a) {
    try {
      var b = Zc(a)
          .map(function (f) {
            return f.toString(2).padStart(8, "0");
          })
          .join(""),
        c = new OA(b);
      if (PA(c, 3) !== 3) return null;
      var d = oA(nA(new mA(), TA(c, 24, MA)), TA(c, 24, MA)),
        e = PA(c, 6);
      e !== 0 && qA(pA(d, TA(c, e)), TA(c, e));
      return d;
    } catch (f) {
      return null;
    }
  }
  function YA(a) {
    try {
      var b = Zc(a)
          .map(function (d) {
            return d.toString(2).padStart(8, "0");
          })
          .join(""),
        c = new OA(b);
      return KA(
        JA(
          IA(
            HA(
              GA(
                FA(
                  EA(
                    DA(
                      CA(
                        BA(
                          AA(
                            zA(
                              yA(
                                xA(
                                  wA(
                                    vA(
                                      uA(
                                        tA(sA(new rA(), PA(c, 6)), QA(c)),
                                        QA(c)
                                      ),
                                      PA(c, 12)
                                    ),
                                    PA(c, 12)
                                  ),
                                  PA(c, 6)
                                ),
                                RA(c)
                              ),
                              PA(c, 12)
                            ),
                            PA(c, 6)
                          ),
                          !!PA(c, 1)
                        ),
                        !!PA(c, 1)
                      ),
                      TA(c, 12, NA)
                    ),
                    TA(c, 24, MA)
                  ),
                  TA(c, 24, MA)
                ),
                !!PA(c, 1)
              ),
              RA(c)
            ),
            UA(c)
          ),
          UA(c)
        ),
        VA(c)
      );
    } catch (d) {
      return null;
    }
  }
  function ZA(a) {
    if (!a) return null;
    a = a.split(".");
    if (a.length > 4) return null;
    var b = YA(a[0]);
    if (!b) return null;
    var c = new LA();
    b = Mg(c, 1, b);
    a.shift();
    a = y(a);
    c = a.next();
    try {
      for (; !c.done; c = a.next()) {
        var d = c.value;
        switch ($A(d)) {
          case 1:
            var e = WA(d);
            if (!e) return null;
            Mg(b, 3, e);
            break;
          case 2:
            break;
          case 3:
            var f = XA(d);
            if (!f) return null;
            Mg(b, 2, f);
            break;
          default:
            return null;
        }
      }
    } finally {
      z(a, c);
    }
    return b;
  }
  function $A(a) {
    try {
      var b = Zc(a)
        .map(function (c) {
          return c.toString(2).padStart(8, "0");
        })
        .join("");
      return PA(new OA(b), 3);
    } catch (c) {
      return -1;
    }
  }
  function aB(a, b) {
    var c = {};
    if (Array.isArray(b) && b.length !== 0) {
      b = y(b);
      var d = b.next();
      try {
        for (; !d.done; d = b.next()) {
          var e = d.value;
          c[e] = a.indexOf(e) !== -1;
        }
      } finally {
        z(b, d);
      }
    } else {
      a = y(a);
      e = a.next();
      try {
        for (; !e.done; e = a.next()) c[e.value] = !0;
      } finally {
        z(a, e);
      }
    }
    delete c[0];
    return c;
  }
  var bB = function (a, b) {
      b = b === void 0 ? !1 : b;
      this.h = a;
      this.defaultValue = b;
    },
    cB = function (a, b) {
      b = b === void 0 ? 0 : b;
      this.h = a;
      this.defaultValue = b;
    };
  var dB = new cB(960449109),
    eB = new bB(45816264),
    fB = new bB(45803173),
    gB = new bB(45668885),
    hB = new bB(45843251),
    iB = new bB(635466687),
    jB = new cB(45645574),
    kB = new bB(45685601, !0),
    lB = new cB(45685602, 100),
    mB = new bB(45820997),
    nB = new cB(45812678),
    oB = new bB(1009155880),
    pB = new bB(45756824, !0),
    qB = new bB(45747172),
    rB = new bB(775241416),
    sB = new bB(781107959),
    tB = new bB(781107958),
    uB = new bB(781107957),
    vB = new bB(45867420);
  var wB = function (a) {
    this.G = I(a);
  };
  w(wB, K);
  var xB = function (a) {
    var b = new wB();
    Pg(b, 1, Se, a, Te, void 0, void 0, !0);
  };
  var yB = /^((market|itms|intent|itms-appss):\/\/)/i;
  function zB(a, b, c, d) {
    var e = Pk("IFRAME");
    e.id = b;
    e.name = b;
    e.width = String(c);
    e.height = String(d);
    e.allowTransparency = "true";
    e.scrolling = "no";
    e.marginWidth = "0";
    e.marginHeight = "0";
    e.frameBorder = "0";
    e.style.border = "0";
    e.style.verticalAlign = "bottom";
    e.src = "about:blank";
    e.setAttribute("aria-label", "Advertisement");
    e.title = "3rd party ad content";
    e.tabIndex = 0;
    a.appendChild(e);
    return e;
  }
  var AB = "ad_type vpos mridx pos vad_type videoad_start_delay".split(" ");
  var BB = function (a) {
    var b = a.Rb;
    var c = a.zb;
    var d = a.height;
    var e = a.width;
    a = a.Kb;
    a = a === void 0 ? !1 : a;
    this.Rb = b;
    this.zb = c;
    this.height = d;
    this.width = e;
    this.Kb = a;
  };
  BB.prototype.getHeight = function () {
    return this.height;
  };
  BB.prototype.getWidth = function () {
    return this.width;
  };
  var CB = function (a) {
    var b = a.Mf;
    var c = a.qe;
    var d = a.xh;
    var e = a.Yf;
    var f = a.Rb;
    var g = a.zb;
    var h = a.Lf;
    var k = a.pe;
    var l = a.height;
    var m = a.width;
    var p = a.Kb;
    var q = a.wh;
    a = a.Xf;
    BB.call(this, {
      Rb: f,
      zb: g,
      height: l,
      width: m,
      Kb: p === void 0 ? !1 : p,
    });
    this.Mf = b;
    this.qe = c;
    this.xh = d;
    this.Yf = e;
    this.Lf = h;
    this.pe = k;
    this.wh = q;
    this.Xf = a;
  };
  w(CB, BB);
  CB.prototype.Cd = function () {
    return this.Mf;
  };
  var DB = function (a) {
    var b = a === void 0 ? {} : a;
    a = b.Se;
    a = a === void 0 ? null : a;
    var c = b.itag;
    c = c === void 0 ? null : c;
    var d = b.mimeType;
    d = d === void 0 ? null : d;
    var e = b.Rb,
      f = b.zb,
      g = b.height,
      h = b.width,
      k = b.Kb;
    b = b.eg;
    b = b === void 0 ? null : b;
    BB.call(this, {
      Rb: e === void 0 ? null : e,
      zb: f === void 0 ? null : f,
      height: g === void 0 ? null : g,
      width: h === void 0 ? null : h,
      Kb: k === void 0 ? !1 : k,
    });
    this.Se = a;
    this.mimeType = d;
    this.itag = c;
    this.eg = b;
  };
  w(DB, BB);
  DB.prototype.getMediaUrl = function () {
    return this.Se;
  };
  function EB(a) {
    return new (Function.prototype.bind.apply(
      a,
      [null].concat(ra(La.apply(1, arguments)))
    ))();
  }
  var FB = function (a) {
    var b = Error.call(this, String(a));
    this.message = b.message;
    "stack" in b && (this.stack = b.stack);
    this.errorCode = a;
  };
  w(FB, Error);
  function GB(a) {
    return hk(a === null ? "null" : a === void 0 ? "undefined" : a);
  }
  function HB(a) {
    if (typeof DOMParser != "undefined") {
      var b = new DOMParser();
      a = GB(a);
      return b.parseFromString(ik(a), "application/xml");
    }
    throw Error("Your browser does not support loading xml documents");
  }
  var IB = function (a) {
    switch (a) {
      case 0:
        return "No Error";
      case 1:
        return "Access denied to content document";
      case 2:
        return "File not found";
      case 3:
        return "Firefox silently errored";
      case 4:
        return "Application custom error";
      case 5:
        return "An exception occurred";
      case 6:
        return "Http response at 400 or 500 level";
      case 7:
        return "Request was aborted";
      case 8:
        return "Request timed out";
      case 9:
        return "The resource is not available offline";
      default:
        return "Unrecognized error code";
    }
  };
  var JB = function () {};
  JB.prototype.get = function (a) {
    var b = a.url;
    var c = a.timeout;
    var d = a.withCredentials;
    var e = d === void 0 ? !0 : d;
    a = a.browsingTopics;
    var f = a === void 0 ? !0 : a;
    var g;
    return Ka(function (h) {
      if (h.j == 1)
        return (
          h.A(2),
          h.h(
            KB({ url: b, timeout: c, withCredentials: e, browsingTopics: f }),
            4
          )
        );
      if (h.j != 2) return h.return(h.l);
      g = h.o();
      if (!e) throw g;
      return h.return(
        KB({ url: b, timeout: c, withCredentials: !1, browsingTopics: f })
      );
    });
  };
  var KB = function (a) {
      var b = a.url;
      var c = a.timeout;
      var d = a.withCredentials;
      var e = d === void 0 ? !0 : d;
      a = a.browsingTopics;
      var f = a === void 0 ? !0 : a;
      var g, h, k, l;
      return Ka(function (m) {
        g = new AbortController();
        h = e ? "include" : "omit";
        k = setTimeout(function () {
          g.abort();
        }, LB(c));
        l = { method: "GET", credentials: h, signal: g.signal };
        f && (l.browsingTopics = f);
        return m.return(MB(b, l, k));
      });
    },
    MB = function (a, b, c) {
      var d, e, f, g, h;
      return Ka(function (k) {
        switch (k.j) {
          case 1:
            return k.A(2, 3), k.h(fetch(a, b), 5);
          case 5:
            d = k.l;
          case 3:
            k.V();
            clearTimeout(c);
            k.J(4);
            break;
          case 2:
            f = e = k.o();
            if (f.name === "AbortError") throw new FB(7, -1);
            throw new FB(6, -1);
          case 4:
            if (!d.ok) throw new FB(6, d.status);
            g = d.headers.get("Content-Type") || "";
            return g.indexOf("application/json") !== -1
              ? k.h(d.json(), 9)
              : k.h(d.text(), 8);
          case 8:
            return (h = k.l), k.return(HB(h) || new Document());
          case 9:
            return k.return(k.l || {});
        }
      });
    };
  var NB = function () {};
  NB.prototype.ec = function (a, b) {
    b = b === void 0 ? !1 : b;
    var c, d, e;
    return Ka(function (f) {
      switch (f.j) {
        case 1:
          N.getInstance().P("faa", "1");
          var g = {
            keepalive: !0,
            method: "get",
            redirect: "follow",
            credentials: "include",
            mode: "no-cors",
          };
          b && (g.referrerPolicy = "no-referrer");
          c = g;
          f.A(2);
          return f.h(fetch(a, c), 4);
        case 4:
          d = f.l;
          f.N(3);
          break;
        case 2:
          throw ((e = f.o()), N.getInstance().P("faf", "1"), e);
        case 3:
          N.getInstance().P("fas", "1");
          if (
            jp(Cp) &&
            a.includes("/pagead/adview") &&
            typeof window !== "undefined"
          ) {
            g = window;
            var h = {},
              k = d.headers.get("X-Ad-Event-Value");
            if (k)
              try {
                var l = JSON.parse(k);
                h.revenueCurrency = l.currency;
                h.revenueMicros = l.value;
                var m = g.parent;
                h.googMsgType = "aevi";
                m.postMessage(JSON.stringify(h), "*");
              } catch (p) {}
          }
          f.B();
      }
    });
  };
  var OB = function (a, b, c, d) {
    R.call(this);
    this.F = b;
    this.C = c;
    this.B = d;
    this.A = new Map();
    this.H = 0;
    this.o = new Map();
    this.D = new Map();
    this.l = void 0;
    this.j = a;
  };
  w(OB, R);
  OB.prototype.M = function () {
    delete this.h;
    this.A.clear();
    this.o.clear();
    this.D.clear();
    this.l && (Ul(this.j, "message", this.l), delete this.l);
    delete this.j;
    delete this.B;
    R.prototype.M.call(this);
  };
  var PB = function (a) {
      if (a.h) return a.h;
      a.C && a.C(a.j) ? (a.h = a.j) : (a.h = Nk(a.j, a.F));
      var b;
      return (b = a.h) != null ? b : null;
    },
    RB = function (a, b, c) {
      if (PB(a))
        if (a.h === a.j) (b = a.A.get(b)) && b(a.h, c);
        else {
          var d = a.o.get(b);
          if (d && d.Pd) {
            QB(a);
            var e = ++a.H;
            a.D.set(e, { dd: d.dd, Hi: d.Qe(c), Pj: b === "addEventListener" });
            a.h.postMessage(d.Pd(c, e), "*");
          }
        }
    },
    QB = function (a) {
      a.l ||
        ((a.l = function (b) {
          if (b.source === a.h)
            try {
              var c = a.B ? a.B(b) : void 0;
              if (c) {
                var d = c.Tg,
                  e = a.D.get(d);
                if (e) {
                  e.Pj || a.D.delete(d);
                  var f;
                  (f = e.dd) == null || f.call(e, e.Hi, c.payload);
                }
              }
            } catch (g) {}
        }),
        Tl(a.j, "message", a.l));
    };
  var SB = function (a, b) {
      (0, a.__uspapi)("getUSPData", 1, function (c, d) {
        b.Ea({ dg: c != null ? c : void 0, rg: d ? void 0 : 2 });
      });
    },
    TB = {
      Qe: function (a) {
        return a.Ea;
      },
      Pd: function (a, b) {
        a = {};
        return (
          (a.__uspapiCall = { callId: b, command: "getUSPData", version: 1 }), a
        );
      },
      dd: function (a, b) {
        b = b.__uspapiReturn;
        var c;
        a({
          dg: (c = b.returnValue) != null ? c : void 0,
          rg: b.success ? void 0 : 2,
        });
      },
    };
  function UB(a) {
    a = ae(a.data) ? JSON.parse(a.data) : a.data;
    return { payload: a, Tg: a.__uspapiReturn.callId };
  }
  var VB = function (a, b) {
    b = b === void 0 ? {} : b;
    R.call(this);
    var c;
    this.timeoutMs = (c = b.timeoutMs) != null ? c : 500;
    this.caller = new OB(
      a,
      "__uspapiLocator",
      function (d) {
        return typeof d.__uspapi === "function";
      },
      UB
    );
    this.caller.A.set("getDataWithCallback", SB);
    this.caller.o.set("getDataWithCallback", TB);
  };
  w(VB, R);
  VB.prototype.M = function () {
    this.caller.dispose();
    R.prototype.M.call(this);
  };
  var WB = function (a, b) {
    var c = {};
    if (PB(a.caller)) {
      var d = Nj(function () {
        b(c);
      });
      RB(a.caller, "getDataWithCallback", {
        Ea: function (e) {
          e.rg || (c = e.dg);
          d();
        },
      });
      setTimeout(d, a.timeoutMs);
    } else b(c);
  };
  function XB(a) {
    a.addtlConsent === void 0 ||
      ae(a.addtlConsent) ||
      (a.addtlConsent = void 0);
    a.gdprApplies === void 0 || be(a.gdprApplies) || (a.gdprApplies = void 0);
    return (a.tcString !== void 0 && !ae(a.tcString)) ||
      (a.listenerId !== void 0 && !$d(a.listenerId))
      ? 2
      : a.cmpStatus && a.cmpStatus !== "error"
      ? 0
      : 3;
  }
  var YB = function (a, b) {
    b = b === void 0 ? {} : b;
    R.call(this);
    this.h = null;
    this.o = {};
    this.A = 0;
    this.l = null;
    this.j = a;
    var c;
    this.timeoutMs = (c = b.timeoutMs) != null ? c : 500;
    var d;
    this.Lc = (d = b.Lc) != null ? d : !1;
  };
  w(YB, R);
  YB.prototype.M = function () {
    this.o = {};
    this.l && (Ul(this.j, "message", this.l), delete this.l);
    delete this.o;
    delete this.j;
    delete this.h;
    R.prototype.M.call(this);
  };
  var $B = function (a) {
      return typeof a.j.__tcfapi === "function" || ZB(a) != null;
    },
    cC = function (a, b) {
      var c = { internalErrorState: 0, internalBlockOnErrors: a.Lc },
        d = Nj(function () {
          b(c);
        }),
        e = 0;
      a.timeoutMs !== -1 &&
        (e = setTimeout(function () {
          e = 0;
          c.tcString = "tcunavailable";
          c.internalErrorState = 1;
          d();
        }, a.timeoutMs));
      aC(a, "addEventListener", function (f) {
        f &&
          ((c = f),
          (c.internalErrorState = XB(c)),
          (c.internalBlockOnErrors = a.Lc),
          bC(c)
            ? (c.internalErrorState !== 0 && (c.tcString = "tcunavailable"),
              aC(a, "removeEventListener", null, c.listenerId),
              (f = e) && clearTimeout(f),
              d())
            : (c.cmpStatus === "error" || c.internalErrorState !== 0) &&
              (f = e) &&
              clearTimeout(f));
      });
    };
  YB.prototype.addEventListener = function (a) {
    var b = this,
      c = { internalBlockOnErrors: this.Lc },
      d = Nj(function () {
        a(c);
      }),
      e = 0;
    this.timeoutMs !== -1 &&
      (e = setTimeout(function () {
        c.tcString = "tcunavailable";
        c.internalErrorState = 1;
        d();
      }, this.timeoutMs));
    var f = function (g, h) {
      clearTimeout(e);
      g
        ? ((c = g),
          (c.internalErrorState = XB(c)),
          (c.internalBlockOnErrors = b.Lc),
          (h && c.internalErrorState === 0) ||
            ((c.tcString = "tcunavailable"), h || (c.internalErrorState = 3)))
        : ((c.tcString = "tcunavailable"), (c.internalErrorState = 3));
      a(c);
    };
    try {
      aC(this, "addEventListener", f);
    } catch (g) {
      (c.tcString = "tcunavailable"),
        (c.internalErrorState = 3),
        e && (clearTimeout(e), (e = 0)),
        d();
    }
  };
  YB.prototype.removeEventListener = function (a) {
    a && a.listenerId && aC(this, "removeEventListener", null, a.listenerId);
  };
  var dC = function (a, b) {
      return !(!a || !a[b]);
    },
    aC = function (a, b, c, d) {
      c || (c = function () {});
      var e = a.j;
      typeof e.__tcfapi === "function"
        ? ((a = e.__tcfapi), a(b, 2, c, d))
        : ZB(a)
        ? (eC(a),
          (e = ++a.A),
          (a.o[e] = c),
          a.h &&
            ((c = {}),
            a.h.postMessage(
              ((c.__tcfapiCall = {
                command: b,
                version: 2,
                callId: e,
                parameter: d,
              }),
              c),
              "*"
            )))
        : c({}, !1);
    },
    ZB = function (a) {
      if (a.h) return a.h;
      a.h = Nk(a.j, "__tcfapiLocator");
      return a.h;
    },
    eC = function (a) {
      if (!a.l) {
        var b = function (c) {
          if (c.source === a.h)
            try {
              var d = (ae(c.data) ? JSON.parse(c.data) : c.data).__tcfapiReturn;
              a.o[d.callId](d.returnValue, d.success);
            } catch (e) {}
        };
        a.l = b;
        Tl(a.j, "message", b);
      }
    },
    bC = function (a) {
      if (a.gdprApplies === !1) return !0;
      a.internalErrorState === void 0 && (a.internalErrorState = XB(a));
      return a.cmpStatus === "error" || a.internalErrorState !== 0
        ? a.internalBlockOnErrors
          ? (Zl({ e: String(a.internalErrorState) }, "tcfe"), !1)
          : !0
        : a.cmpStatus === "loaded" &&
            (a.eventStatus === "tcloaded" ||
              a.eventStatus === "useractioncomplete");
    };
  var fC = function (a, b) {
      b = b.listener;
      (a = (0, a.__gpp)("addEventListener", b)) && b(a, !0);
    },
    gC = function (a, b) {
      (0, a.__gpp)("removeEventListener", b.listener, b.listenerId);
    },
    hC = {
      Qe: function (a) {
        return a.listener;
      },
      Pd: function (a, b) {
        a = {};
        return (
          (a.__gppCall = {
            callId: b,
            command: "addEventListener",
            version: "1.1",
          }),
          a
        );
      },
      dd: function (a, b) {
        b = b.__gppReturn;
        a(b.returnValue, b.success);
      },
    },
    iC = {
      Qe: function (a) {
        return a.listener;
      },
      Pd: function (a, b) {
        var c = {};
        return (
          (c.__gppCall = {
            callId: b,
            command: "removeEventListener",
            version: "1.1",
            parameter: a.listenerId,
          }),
          c
        );
      },
      dd: function (a, b) {
        b = b.__gppReturn;
        var c = b.returnValue.data;
        a == null || a(c, b.success);
      },
    };
  function jC(a) {
    var b = {};
    ae(a.data) ? (b = JSON.parse(a.data)) : (b = a.data);
    return { payload: b, Tg: b.__gppReturn.callId };
  }
  var kC = function (a, b) {
    b = (b === void 0 ? {} : b).timeoutMs;
    R.call(this);
    this.caller = new OB(
      a,
      "__gppLocator",
      function (c) {
        return typeof c.__gpp === "function";
      },
      jC
    );
    this.caller.A.set("addEventListener", fC);
    this.caller.o.set("addEventListener", hC);
    this.caller.A.set("removeEventListener", gC);
    this.caller.o.set("removeEventListener", iC);
    this.timeoutMs = b != null ? b : 500;
  };
  w(kC, R);
  kC.prototype.M = function () {
    this.caller.dispose();
    R.prototype.M.call(this);
  };
  kC.prototype.addEventListener = function (a) {
    var b = this,
      c = Nj(function () {
        a(lC, !0);
      }),
      d =
        this.timeoutMs === -1
          ? void 0
          : setTimeout(function () {
              c();
            }, this.timeoutMs);
    RB(this.caller, "addEventListener", {
      listener: function (e, f) {
        clearTimeout(d);
        try {
          var g;
          if (
            ((g = e.pingData) == null ? void 0 : g.gppVersion) === void 0 ||
            e.pingData.gppVersion === "1" ||
            e.pingData.gppVersion === "1.0"
          ) {
            b.removeEventListener(e.listenerId);
            var h = {
              eventName: "signalStatus",
              data: "ready",
              pingData: {
                internalErrorState: 1,
                gppString: "GPP_ERROR_STRING_IS_DEPRECATED_SPEC",
                applicableSections: [-1],
              },
            };
          } else
            Array.isArray(e.pingData.applicableSections)
              ? (h = e)
              : (b.removeEventListener(e.listenerId),
                (h = {
                  eventName: "signalStatus",
                  data: "ready",
                  pingData: {
                    internalErrorState: 2,
                    gppString:
                      "GPP_ERROR_STRING_EXPECTED_APPLICATION_SECTION_ARRAY",
                    applicableSections: [-1],
                  },
                }));
          a(h, f);
        } catch (k) {
          if (e == null ? 0 : e.listenerId)
            try {
              b.removeEventListener(e.listenerId);
            } catch (l) {
              a(mC, !0);
              return;
            }
          a(nC, !0);
        }
      },
    });
  };
  kC.prototype.removeEventListener = function (a) {
    RB(this.caller, "removeEventListener", {
      listener: function () {},
      listenerId: a,
    });
  };
  var nC = {
      eventName: "signalStatus",
      data: "ready",
      pingData: {
        internalErrorState: 2,
        gppString: "GPP_ERROR_STRING_UNAVAILABLE",
        applicableSections: [-1],
      },
      listenerId: -1,
    },
    lC = {
      eventName: "signalStatus",
      data: "ready",
      pingData: {
        gppString: "GPP_ERROR_STRING_LISTENER_REGISTRATION_TIMEOUT",
        internalErrorState: 2,
        applicableSections: [-1],
      },
      listenerId: -1,
    },
    mC = {
      eventName: "signalStatus",
      data: "ready",
      pingData: {
        gppString: "GPP_ERROR_STRING_REMOVE_EVENT_LISTENER_ERROR",
        internalErrorState: 2,
        applicableSections: [-1],
      },
      listenerId: -1,
    };
  xB([1, 8, 9, 10, 11, 12, 2, 3, 4, 5, 15, 16, 19, 20, 21, 23, 25]);
  xB([1, 6, 7, 9, 10, 11, 12, 2, 22, 3, 4, 5, 13, 14, 18, 19, 20, 21, 23, 24]);
  xB([
    1, 6, 7, 9, 10, 11, 12, 22, 26, 27, 2, 3, 4, 5, 13, 14, 17, 18, 19, 20, 21,
    23, 24,
  ]);
  new wB();
  function oC(a, b) {
    this.h = this.D = this.o = "";
    this.B = null;
    this.C = this.j = "";
    this.A = !1;
    var c;
    a instanceof oC
      ? ((this.A = b !== void 0 ? b : a.A),
        pC(this, a.o),
        (this.D = a.D),
        (this.h = a.h),
        qC(this, a.B),
        (this.j = a.j),
        rC(this, sC(a.l)),
        (this.C = a.F()))
      : a && (c = String(a).match(eq))
      ? ((this.A = !!b),
        pC(this, c[1] || "", !0),
        (this.D = tC(c[2] || "")),
        (this.h = tC(c[3] || "", !0)),
        qC(this, c[4]),
        (this.j = tC(c[5] || "", !0)),
        rC(this, c[6] || "", !0),
        (this.C = tC(c[7] || "")))
      : ((this.A = !!b), (this.l = new uC(null, this.A)));
  }
  oC.prototype.toString = function () {
    var a = [],
      b = this.o;
    b && a.push(vC(b, wC, !0), ":");
    var c = this.h;
    if (c || b == "file")
      a.push("//"),
        (b = this.D) && a.push(vC(b, wC, !0), "@"),
        a.push(
          encodeURIComponent(String(c)).replace(/%25([0-9a-fA-F]{2})/g, "%$1")
        ),
        (c = this.B),
        c != null && a.push(":", String(c));
    if ((c = this.j))
      this.h && c.charAt(0) != "/" && a.push("/"),
        a.push(vC(c, c.charAt(0) == "/" ? xC : yC, !0));
    (c = this.l.toString()) && a.push("?", c);
    (c = this.F()) && a.push("#", vC(c, zC));
    return a.join("");
  };
  oC.prototype.resolve = function (a) {
    var b = this.N(),
      c = !!a.o;
    c ? pC(b, a.o) : (c = !!a.D);
    c ? (b.D = a.D) : (c = !!a.h);
    c ? (b.h = a.h) : (c = a.B != null);
    var d = a.j;
    if (c) qC(b, a.B);
    else if ((c = !!a.j)) {
      if (d.charAt(0) != "/")
        if (this.h && !this.j) d = "/" + d;
        else {
          var e = b.j.lastIndexOf("/");
          e != -1 && (d = b.j.slice(0, e + 1) + d);
        }
      e = d;
      if (e == ".." || e == ".") d = "";
      else if (Ob(e, "./") || Ob(e, "/.")) {
        d = e.lastIndexOf("/", 0) == 0;
        e = e.split("/");
        for (var f = [], g = 0; g < e.length; ) {
          var h = e[g++];
          h == "."
            ? d && g == e.length && f.push("")
            : h == ".."
            ? ((f.length > 1 || (f.length == 1 && f[0] != "")) && f.pop(),
              d && g == e.length && f.push(""))
            : (f.push(h), (d = !0));
        }
        d = f.join("/");
      } else d = e;
    }
    c ? (b.j = d) : (c = a.l.toString() !== "");
    c ? rC(b, sC(a.l)) : (c = !!a.C);
    c && (b.C = a.F());
    return b;
  };
  oC.prototype.N = function () {
    return new oC(this);
  };
  var pC = function (a, b, c) {
      a.o = c ? tC(b, !0) : b;
      a.o && (a.o = a.o.replace(/:$/, ""));
    },
    qC = function (a, b) {
      if (b) {
        b = Number(b);
        if (isNaN(b) || b < 0) throw Error("Bad port number " + b);
        a.B = b;
      } else a.B = null;
    },
    rC = function (a, b, c) {
      b instanceof uC
        ? ((a.l = b), AC(a.l, a.A))
        : (c || (b = vC(b, BC)), (a.l = new uC(b, a.A)));
    },
    CC = function (a, b, c) {
      a.l.set(b, c);
      return a;
    },
    DC = function (a, b) {
      return a.l.get(b);
    };
  oC.prototype.F = function () {
    return this.C;
  };
  var EC = function (a) {
      return a instanceof oC ? a.N() : new oC(a, void 0);
    },
    tC = function (a, b) {
      return a
        ? b
          ? decodeURI(a.replace(/%25/g, "%2525"))
          : decodeURIComponent(a)
        : "";
    },
    vC = function (a, b, c) {
      return typeof a === "string"
        ? ((a = encodeURI(a).replace(b, FC)),
          c && (a = a.replace(/%25([0-9a-fA-F]{2})/g, "%$1")),
          a)
        : null;
    },
    FC = function (a) {
      a = a.charCodeAt(0);
      return "%" + ((a >> 4) & 15).toString(16) + (a & 15).toString(16);
    },
    wC = /[#\/\?@]/g,
    yC = /[#\?:]/g,
    xC = /[#\?]/g,
    BC = /[#\?@]/g,
    zC = /#/g,
    uC = function (a, b) {
      this.j = this.h = null;
      this.l = a || null;
      this.o = !!b;
    },
    GC = function (a) {
      a.h ||
        ((a.h = new Map()),
        (a.j = 0),
        a.l &&
          gq(a.l, function (b, c) {
            a.add(pk(b), c);
          }));
    };
  uC.prototype.add = function (a, b) {
    GC(this);
    this.l = null;
    a = HC(this, a);
    var c = this.h.get(a);
    c || this.h.set(a, (c = []));
    c.push(b);
    this.j += 1;
    return this;
  };
  uC.prototype.remove = function (a) {
    GC(this);
    a = HC(this, a);
    return this.h.has(a)
      ? ((this.l = null), (this.j -= this.h.get(a).length), this.h.delete(a))
      : !1;
  };
  uC.prototype.clear = function () {
    this.h = this.l = null;
    this.j = 0;
  };
  uC.prototype.isEmpty = function () {
    GC(this);
    return this.j == 0;
  };
  var IC = function (a, b) {
    GC(a);
    b = HC(a, b);
    return a.h.has(b);
  };
  n = uC.prototype;
  n.forEach = function (a, b) {
    GC(this);
    this.h.forEach(function (c, d) {
      c.forEach(function (e) {
        a.call(b, e, d, this);
      }, this);
    }, this);
  };
  n.Vc = function (a) {
    GC(this);
    var b = [];
    if (typeof a === "string")
      IC(this, a) && (b = b.concat(this.h.get(HC(this, a))));
    else {
      a = Array.from(this.h.values());
      for (var c = 0; c < a.length; c++) b = b.concat(a[c]);
    }
    return b;
  };
  n.set = function (a, b) {
    GC(this);
    this.l = null;
    a = HC(this, a);
    IC(this, a) && (this.j -= this.h.get(a).length);
    this.h.set(a, [b]);
    this.j += 1;
    return this;
  };
  n.get = function (a, b) {
    if (!a) return b;
    a = this.Vc(a);
    return a.length > 0 ? String(a[0]) : b;
  };
  n.toString = function () {
    if (this.l) return this.l;
    if (!this.h) return "";
    for (var a = [], b = Array.from(this.h.keys()), c = 0; c < b.length; c++) {
      var d = b[c],
        e = encodeURIComponent(String(d));
      d = this.Vc(d);
      for (var f = 0; f < d.length; f++) {
        var g = e;
        d[f] !== "" && (g += "=" + encodeURIComponent(String(d[f])));
        a.push(g);
      }
    }
    return (this.l = a.join("&"));
  };
  var sC = function (a) {
      var b = new uC();
      b.l = a.l;
      a.h && ((b.h = new Map(a.h)), (b.j = a.j));
      return b;
    },
    HC = function (a, b) {
      b = String(b);
      a.o && (b = b.toLowerCase());
      return b;
    },
    AC = function (a, b) {
      b &&
        !a.o &&
        (GC(a),
        (a.l = null),
        a.h.forEach(function (c, d) {
          var e = d.toLowerCase();
          d != e &&
            (this.remove(d),
            this.remove(e),
            c.length > 0 &&
              ((this.l = null),
              this.h.set(HC(this, e), qc(c)),
              (this.j += c.length)));
        }, a));
      a.o = b;
    };
  var JC,
    KC,
    LC,
    MC = function () {
      return C.navigator ? C.navigator.userAgent : "";
    },
    NC =
      Ob(MC(), "(iPad") ||
      Ob(MC(), "(Macintosh") ||
      Ob(MC(), "(iPod") ||
      Ob(MC(), "(iPhone"),
    OC = function () {
      KC === void 0 && (KC = Ob(MC(), "afma-sdk-a"));
      return !!KC;
    },
    PC = function () {
      if (LC === void 0) {
        a: {
          if (JC === void 0) {
            if (NC) {
              var a = Ob(MC(), "Safari");
              var b = new oC(window.location.href).l.Vc("js");
              b: {
                if (
                  (b = b.length ? b[0] : "") &&
                  b.lastIndexOf("afma-", 0) == 0
                ) {
                  var c = b.lastIndexOf("v");
                  if (
                    c > -1 &&
                    (b = b
                      .substr(c + 1)
                      .match(/^(\d+\.\d+\.\d+|^\d+\.\d+|^\d+)(-.*)?$/))
                  ) {
                    b = b[1];
                    break b;
                  }
                }
                b = "0.0.0";
              }
              if (!a || b !== "0.0.0") {
                a = JC = !0;
                break a;
              }
            }
            JC = !1;
          }
          a = JC;
        }
        LC = a || OC();
      }
      return LC;
    };
  var QC = /OS (\S+) like/,
    RC = /Android ([\d\.]+)/;
  function SC(a, b) {
    a = (a = a.exec(Sb())) ? a[1] : "";
    a = a.replace(/_/g, ".");
    return Qb(a, b) >= 0;
  }
  function TC() {
    return Ic || (Fc && "ontouchstart" in document.documentElement);
  }
  function UC(a) {
    return (a = a === void 0 ? null : a) && typeof a.getAttribute === "function"
      ? !!a.getAttribute("playsinline")
      : !1;
  }
  var VC =
      "ad.doubleclick.net bid.g.doubleclick.net ggpht.com google.co.uk google.com googleads.g.doubleclick.net googleads4.g.doubleclick.net googleadservices.com googlesyndication.com googleusercontent.com gstatic.com gvt1.com prod.google.com pubads.g.doubleclick.net s0.2mdn.net static.doubleclick.net surveys.g.doubleclick.net youtube.com ytimg.com".split(
        " "
      ),
    WC = ["c.googlesyndication.com"];
  function XC(a) {
    if (b === void 0) {
      var b = typeof window !== "undefined" ? ol() : void 0;
      b = !Ks() && (b == null ? 0 : b.location) ? b.location.protocol : "https";
    }
    var c = !1;
    a == null ||
    !a.startsWith("http") ||
    (a == null ? 0 : a.startsWith("https"))
      ? (c = !1)
      : YC(a, WC)
      ? (c = !1)
      : b.includes("https") && YC(a, VC) && (c = !0);
    return c
      ? ((a = new oC(a)),
        N.getInstance().P("htp", "1"),
        pC(a, "https"),
        a.toString())
      : a;
  }
  function ZC(a) {
    if (!a) return !1;
    try {
      return (typeof a === "string" ? new oC(a) : a).o === "gcache";
    } catch (b) {
      return !1;
    }
  }
  function $C(a) {
    return ZC(a) && !!DC(new oC(a), "url");
  }
  function aD(a) {
    try {
      var b = typeof a === "string" ? new oC(a) : a;
      if (ZC(b)) {
        var c, d;
        return (d = (c = DC(b, "url")) != null ? c : DC(b, "tag.check_url")) !=
          null
          ? d
          : null;
      }
    } catch (e) {}
    return null;
  }
  function YC(a, b) {
    return new RegExp(
      "^https?://([a-z0-9-]{1,63}\\.)*(" +
        b.join("|").replace(/\./g, "\\.") +
        ")(:[0-9]+)?([/?#]|$)",
      "i"
    ).test(a);
  }
  var bD = function () {
    var a = this;
    this.promise = new Promise(function (b, c) {
      a.resolve = b;
      a.reject = c;
    });
  };
  var cD = function () {
    this.j = window.document;
    this.h = new Map();
    this.l = 0;
  };
  cD.prototype.ec = function (a, b) {
    var c = this;
    b = b === void 0 ? !1 : b;
    var d = new bD(),
      e = Pk("IMG", this.j),
      f = (this.l++).toString();
    this.h.set(f, e);
    e.addEventListener("load", function () {
      c.h.delete(f);
      d.resolve();
    });
    e.addEventListener("error", function (g) {
      c.h.delete(f);
      d.reject(g);
    });
    b && (e.referrerPolicy = "no-referrer");
    e.src = a;
    return d.promise;
  };
  var dD = -1;
  function eD(a) {
    if (!Fb(tk(a))) {
      var b = a instanceof Yj || !yB.test(a) ? a : Zj(a);
      if (!(b instanceof Yj)) {
        var c = c === void 0 ? dk : c;
        a: if (((b = c), (b = b === void 0 ? dk : b), !(a instanceof Yj))) {
          for (c = 0; c < b.length; ++c) {
            var d = b[c];
            if (d instanceof bk && d.oj(a)) {
              a = Zj(a);
              break a;
            }
          }
          a = void 0;
        }
        b = a || ak;
      }
      a = window;
      if (b instanceof Yj)
        if (b instanceof Yj) b = b.h;
        else throw Error("");
      else b = fk.test(b) ? b : void 0;
      b !== void 0 && a.open(b, "_blank", void 0);
    }
  }
  function fD(a, b) {
    for (var c; !(c = a.next()).done; ) b(c.value);
  }
  var gD = function (a, b) {
    var c = new Set(a);
    fD(b[Symbol.iterator](), function (d) {
      return c.add(d);
    });
    return c;
  };
  var hD = { attributes: !0, attributeFilter: ["style", "class"] },
    iD = new Map();
  function jD(a, b, c, d) {
    return typeof DOMRect !== "undefined"
      ? new DOMRect(a, b, c, d)
      : {
          x: a,
          y: b,
          width: c,
          height: d,
          top: b,
          bottom: b + d,
          left: a,
          right: a + c,
          toJSON: function () {
            return this;
          },
        };
  }
  function kD(a, b) {
    return [
      a.top - b.top,
      a.left - b.left,
      a.width - b.width,
      a.height - b.height,
    ].every(function (c) {
      return Math.abs(c) <= 1;
    });
  }
  var lD = function () {
    this.l = this.h = this.j = null;
  };
  function mD(a, b, c, d) {
    var e = a.getBoundingClientRect();
    kD(b, e)
      ? ((e = setTimeout(function () {
          return void mD(a, b, c, d);
        }, 200)),
        (d.l = e))
      : (nD(d), c(e));
  }
  function oD(a) {
    var b = new lD(),
      c = new Promise(function (f) {
        var g = a.getBoundingClientRect();
        if ("ResizeObserver" in window) {
          var h = new ResizeObserver(function (k) {
            window.requestAnimationFrame(function () {
              var l = y(k),
                m = l.next();
              try {
                for (; !m.done; m = l.next()) {
                  var p = m.value,
                    q = 0,
                    r = 0;
                  if (p.contentBoxSize) {
                    var t = Array.isArray(p.contentBoxSize)
                      ? p.contentBoxSize[0]
                      : p.contentBoxSize;
                    q = Math.round(t.inlineSize);
                    r = Math.round(t.blockSize);
                  } else
                    (q = Math.round(p.contentRect.width)),
                      (r = Math.round(p.contentRect.height));
                  var v = void 0,
                    x = void 0,
                    E =
                      ((v = p) == null
                        ? void 0
                        : (x = v.contentRect) == null
                        ? void 0
                        : x.left) || g.left;
                  x = v = void 0;
                  var F =
                      ((v = p) == null
                        ? void 0
                        : (x = v.contentRect) == null
                        ? void 0
                        : x.top) || g.top,
                    B = jD(E, F, q, r);
                  if (!kD(g, B)) {
                    nD(b);
                    f(B);
                    break;
                  }
                }
              } finally {
                z(l, m);
              }
            });
          });
          b.j = h;
          h.observe(a);
          h = new MutationObserver(function () {
            window.requestAnimationFrame(function () {
              var k = a.getBoundingClientRect();
              kD(g, k) || (nD(b), f(k));
            });
          });
          b.h = h;
          h.observe(a, hD);
        } else mD(a, g, f, b);
      }),
      d,
      e = (d = iD.get(c)) != null ? d : new Set();
    e.add(b);
    iD.set(c, e);
    return c;
  }
  function pD(a, b) {
    b = b === void 0 ? jD(0, 0, 1, 1) : b;
    var c = function (g) {
        var h = oD(a),
          k,
          l = (k = iD.get(g)) != null ? k : new Set(),
          m;
        k = (m = iD.get(h)) != null ? m : new Set();
        iD.set(g, gD(l, k));
        return h;
      },
      d = function (g, h) {
        c(g).then(function (k) {
          b.width <= k.width && b.height <= k.height ? (qD(g), h(k)) : d(g, h);
        });
      },
      e = new bD(),
      f = e.promise;
    d(f, e.resolve);
    return f;
  }
  function qD(a) {
    a = iD.get(a);
    a = y(a);
    var b = a.next();
    try {
      for (; !b.done; b = a.next()) nD(b.value);
    } finally {
      z(a, b);
    }
  }
  function nD(a) {
    a.l && window.clearTimeout(a.l);
    a.j && (a.j.disconnect(), (a.j = null));
    a.h && (a.h.disconnect(), (a.h = null));
  }
  var rD = function (a) {
    S.call(this);
    this.j = a;
    this.l = this.o = !1;
    this.A = this.B = 0;
    this.h = new Yy(1e3);
    tt(this, this.h);
    jy(this.h, "tick", this.Lj, !1, this);
    jy(this.j, "pause", this.be, !1, this);
    jy(this.j, "playing", this.be, !1, this);
    jy(this.j, "ended", this.be, !1, this);
    jy(this.j, "timeupdate", this.be, !1, this);
    this.Qa = null;
  };
  w(rD, S);
  n = rD.prototype;
  n.getCurrentTime = function () {
    var a = this.j;
    return typeof a.currentTime === "number"
      ? a.currentTime
      : typeof a.getCurrentTime === "function"
      ? a.getCurrentTime()
      : 0;
  };
  n.be = function (a) {
    switch (a.type) {
      case "playing":
        this.Pb();
        break;
      case "pause":
      case "ended":
        this.Ra();
        break;
      case "timeupdate":
        !this.o && this.getCurrentTime() > 0 && ((this.o = !0), this.Pb());
    }
  };
  n.Pb = function () {
    !this.h.enabled &&
      this.o &&
      ((this.B = this.getCurrentTime() * 1e3),
      (this.A = Date.now()),
      (this.l = !1),
      this.h.start());
  };
  n.Ra = function () {
    this.h.enabled && this.h.stop();
  };
  n.Lj = function () {
    var a = Date.now(),
      b = a - this.A,
      c = this.getCurrentTime() * 1e3;
    c - this.B < b * 0.5
      ? this.l || ((this.l = !0), this.dispatchEvent("playbackStalled"))
      : (this.l = !1);
    this.B = c;
    this.A = a;
  };
  var sD =
      "://secure-...imrworldwide.com/ ://cdn.imrworldwide.com/ ://aksecure.imrworldwide.com/ ://[^.]*.moatads.com ://youtube[0-9]+.moatpixel.com ://pm.adsafeprotected.com/youtube ://pm.test-adsafeprotected.com/youtube ://e[0-9]+.yt.srs.doubleverify.com www.google.com/pagead/xsul www.youtube.com/pagead/slav".split(
        " "
      ),
    tD = /\bocr\b/;
  function uD(a) {
    if (Fb(tk(a)) || (Bc && a.length > 2048)) return !1;
    try {
      if (new oC(a).F().match(tD)) return !0;
    } catch (b) {}
    return (
      sD.find(function (b) {
        return a.match(b) != null;
      }) != null
    );
  }
  function vD(a, b) {
    return Fb(b) ? !1 : new RegExp(a).test(b);
  }
  function wD(a) {
    var b = {};
    a.split(",").forEach(function (c) {
      var d = c.split("=");
      d.length === 2 &&
        ((c = Gb(d[0])), (d = Gb(d[1])), c.length > 0 && (b[c] = d));
    });
    return b;
  }
  function xD(a) {
    var b =
      "af am ar_eg ar_sa ar_xb ar be bg bn ca cs da de_at de_cn de el en_au en_ca en_gb en_ie en_in en_sg en_xa en_xc en_za en es_419 es_ar es_bo es_cl es_co es_cr es_do es_ec es_gt es_hn es_mx es_ni es_pa es_pe es_pr es_py es_sv es_us es_uy es_ve es et eu fa fi fil fr_ca fr_ch fr gl gsw gu he hi hr hu id in is it iw ja kn ko ln lo lt lv ml mo mr ms nb ne nl no pl pt_br pt_pt pt ro ru sk sl sr_latn sr sv sw ta te th tl tr uk ur vi zh_cn zh_hk zh_tw zh zu".split(
        " "
      );
    if (!a) return null;
    a = a.toLowerCase().replace("-", "_");
    if (b.includes(a)) return a;
    a = (a = a.match(/^\w{2,3}([-_]|$)/)) ? a[0].replace(/[_-]/g, "") : "";
    return b.includes(a) ? a : null;
  }
  var yD = function () {
    this.timeoutMs = 5e3;
    this.startTime = Date.now();
  };
  yD.prototype.reset = function () {
    this.startTime = Date.now();
  };
  var LB = function (a) {
    a = a.startTime + a.timeoutMs - Date.now();
    return a > 0 ? a : 0;
  };
  function zD(a) {
    R.call(this);
    this.o = a;
    this.l = {};
  }
  ob(zD, R);
  var AD = [];
  zD.prototype.listen = function (a, b, c, d) {
    return BD(this, a, b, c, d);
  };
  var BD = function (a, b, c, d, e, f) {
    Array.isArray(c) || (c && (AD[0] = c.toString()), (c = AD));
    for (var g = 0; g < c.length; g++) {
      var h = jy(b, c[g], d || a.handleEvent, e || !1, f || a.o || a);
      if (!h) break;
      a.l[h.key] = h;
    }
    return a;
  };
  zD.prototype.Zb = function (a, b, c, d) {
    return CD(this, a, b, c, d);
  };
  var CD = function (a, b, c, d, e, f) {
    if (Array.isArray(c))
      for (var g = 0; g < c.length; g++) CD(a, b, c[g], d, e, f);
    else {
      b = iy(b, c, d || a.handleEvent, e, f || a.o || a);
      if (!b) return a;
      a.l[b.key] = b;
    }
    return a;
  };
  zD.prototype.Ma = function (a, b, c, d, e) {
    if (Array.isArray(b))
      for (var f = 0; f < b.length; f++) this.Ma(a, b[f], c, d, e);
    else
      (c = c || this.handleEvent),
        (d = cb(d) ? !!d.capture : !!d),
        (e = e || this.o || this),
        (c = ky(c)),
        (d = !!d),
        (b = Zx(a)
          ? a.Sc(b, c, d, e)
          : a
          ? (a = my(a))
            ? a.Sc(b, c, d, e)
            : null
          : null),
        b && (ry(b), delete this.l[b.key]);
  };
  var DD = function (a) {
    Sk(
      a.l,
      function (b, c) {
        this.l.hasOwnProperty(c) && ry(b);
      },
      a
    );
    a.l = {};
  };
  zD.prototype.M = function () {
    zD.yb.M.call(this);
    DD(this);
  };
  zD.prototype.handleEvent = function () {
    throw Error("EventHandler.handleEvent not implemented");
  };
  var ED = function () {
    S.call(this);
    this.headers = new Map();
    this.j = !1;
    this.h = null;
    this.H = "";
    this.o = 0;
    this.l = this.F = this.A = this.C = !1;
    this.J = 0;
    this.B = null;
    this.R = "";
    this.K = !1;
  };
  ob(ED, S);
  var FD = /^https?$/i,
    GD = ["POST", "PUT"],
    JD = function (a, b, c, d) {
      var e;
      if (a.h)
        throw Error(
          "[goog.net.XhrIo] Object is active with another request=" +
            a.H +
            "; newUri=" +
            b
        );
      if (typeof c === "string") var f = c;
      else
        c &&
          ((f = c.method),
          d != null || (d = c.body),
          e != null || (e = c.headers));
      f = f ? f.toUpperCase() : "GET";
      a.H = b;
      a.o = 0;
      a.C = !1;
      a.j = !0;
      a.h = new XMLHttpRequest();
      a.h.onreadystatechange = uy(function () {
        return a.O();
      });
      try {
        (a.F = !0), a.h.open(f, String(b), !0), (a.F = !1);
      } catch (p) {
        HD(a);
        return;
      }
      b = d || "";
      c = new Map(a.headers);
      if (e)
        if (Object.getPrototypeOf(e) === Object.prototype)
          for (var g in e) c.set(g, e[g]);
        else if (typeof e.keys === "function" && typeof e.get === "function") {
          g = y(e.keys());
          d = g.next();
          try {
            for (; !d.done; d = g.next()) {
              var h = d.value;
              c.set(h, e.get(h));
            }
          } finally {
            z(g, d);
          }
        } else throw Error("Unknown input type for opt_headers: " + String(e));
      e = Array.from(c.keys()).find(function (p) {
        return "content-type" == p.toLowerCase();
      });
      h = C.FormData && b instanceof C.FormData;
      !kc(GD, f) ||
        e ||
        h ||
        c.set(
          "Content-Type",
          "application/x-www-form-urlencoded;charset=utf-8"
        );
      f = y(c);
      e = f.next();
      try {
        for (; !e.done; e = f.next()) {
          var k = y(e.value),
            l = k.next().value,
            m = k.next().value;
          a.h.setRequestHeader(l, m);
        }
      } finally {
        z(f, e);
      }
      a.R && (a.h.responseType = a.R);
      "withCredentials" in a.h &&
        a.h.withCredentials !== a.K &&
        (a.h.withCredentials = a.K);
      try {
        ID(a),
          a.J > 0 && (a.B = setTimeout(a.W.bind(a), a.J)),
          (a.A = !0),
          a.h.send(b),
          (a.A = !1);
      } catch (p) {
        HD(a);
      }
    };
  ED.prototype.W = function () {
    typeof Za != "undefined" &&
      this.h &&
      ((this.o = 8), this.dispatchEvent("timeout"), this.abort(8));
  };
  var HD = function (a) {
      a.j = !1;
      a.h && ((a.l = !0), a.h.abort(), (a.l = !1));
      a.o = 5;
      KD(a);
      LD(a);
    },
    KD = function (a) {
      a.C ||
        ((a.C = !0), a.dispatchEvent("complete"), a.dispatchEvent("error"));
    };
  ED.prototype.abort = function (a) {
    this.h &&
      this.j &&
      ((this.j = !1),
      (this.l = !0),
      this.h.abort(),
      (this.l = !1),
      (this.o = a || 7),
      this.dispatchEvent("complete"),
      this.dispatchEvent("abort"),
      LD(this));
  };
  ED.prototype.M = function () {
    this.h &&
      (this.j && ((this.j = !1), (this.l = !0), this.h.abort(), (this.l = !1)),
      LD(this, !0));
    ED.yb.M.call(this);
  };
  ED.prototype.O = function () {
    this.Va() || (this.F || this.A || this.l ? MD(this) : this.T());
  };
  ED.prototype.T = function () {
    MD(this);
  };
  var MD = function (a) {
      if (a.j && typeof Za != "undefined")
        if (a.A && (a.h ? a.h.readyState : 0) == 4) setTimeout(a.O.bind(a), 0);
        else if (
          (a.dispatchEvent("readystatechange"), (a.h ? a.h.readyState : 0) == 4)
        ) {
          a.j = !1;
          try {
            var b = ND(a);
            a: switch (b) {
              case 200:
              case 201:
              case 202:
              case 204:
              case 206:
              case 304:
              case 1223:
                var c = !0;
                break a;
              default:
                c = !1;
            }
            var d;
            if (!(d = c)) {
              var e;
              if ((e = b === 0)) {
                var f = String(a.H).match(eq)[1] || null;
                !f &&
                  C.self &&
                  C.self.location &&
                  (f = C.self.location.protocol.slice(0, -1));
                e = !FD.test(f ? f.toLowerCase() : "");
              }
              d = e;
            }
            d
              ? (a.dispatchEvent("complete"), a.dispatchEvent("success"))
              : ((a.o = 6), KD(a));
          } finally {
            LD(a);
          }
        }
    },
    LD = function (a, b) {
      if (a.h) {
        ID(a);
        var c = a.h;
        a.h = null;
        b || a.dispatchEvent("ready");
        try {
          c.onreadystatechange = null;
        } catch (d) {}
      }
    },
    ID = function (a) {
      a.B && (clearTimeout(a.B), (a.B = null));
    };
  ED.prototype.isActive = function () {
    return !!this.h;
  };
  var ND = function (a) {
      try {
        return (a.h ? a.h.readyState : 0) > 2 ? a.h.status : -1;
      } catch (b) {
        return -1;
      }
    },
    OD = function (a) {
      if (a.h) {
        a: {
          a = a.h.responseText;
          if (C.JSON)
            try {
              var b = C.JSON.parse(a);
              break a;
            } catch (c) {}
          b = go(a);
        }
        return b;
      }
    };
  var PD = function () {
    this.Qa = null;
  };
  PD.prototype.get = function (a) {
    var b = a.withCredentials,
      c = a.headers;
    return QD({
      url: a.url,
      timeout: a.timeout,
      withCredentials: b === void 0 ? !0 : b,
      method: "GET",
      headers: c === void 0 ? {} : c,
    });
  };
  var QD = function (a) {
      var b = a.url;
      var c = a.timeout;
      var d = a.withCredentials;
      var e = a.method;
      var f = a.content;
      var g = f === void 0 ? void 0 : f;
      a = a.headers;
      var h = a === void 0 ? {} : a;
      var k, l;
      return Ka(function (m) {
        switch (m.j) {
          case 1:
            return (
              m.A(2),
              m.h(
                RD({
                  url: b,
                  timeout: c,
                  withCredentials: d,
                  method: e,
                  content: g,
                  headers: h,
                }),
                4
              )
            );
          case 4:
            return m.return(m.l);
          case 2:
            if (
              ((k = m.o()),
              (l =
                (k instanceof Error && k.message === "6") ||
                (k instanceof FB && k.errorCode === 6)),
              !l || !d)
            )
              throw k instanceof Error ? k : Error(String(k));
          case 3:
            return m.h(
              RD({
                url: b,
                timeout: c,
                withCredentials: !d,
                method: e,
                content: g,
                headers: h,
              }),
              5
            );
          case 5:
            return m.return(m.l);
        }
      });
    },
    RD = function (a) {
      var b = a.url;
      var c = a.timeout;
      var d = a.withCredentials;
      var e = a.method;
      var f = a.content;
      var g = f === void 0 ? void 0 : f;
      a = a.headers;
      var h = a === void 0 ? {} : a;
      var k, l, m, p, q, r, t, v, x;
      return Ka(function (E) {
        if (E.j == 1) {
          k = new ED();
          k.K = d;
          k.J = Math.max(0, LB(c));
          l = y(Object.entries(h));
          m = l.next();
          try {
            for (; !m.done; m = l.next())
              (p = m.value),
                (q = y(p)),
                (r = q.next().value),
                (t = q.next().value),
                (v = r),
                (x = t),
                k.headers.set(v, x);
          } finally {
            z(l, m);
          }
          E.T(2);
          return E.h(SD(k, XC(b), e, g), 4);
        }
        if (E.j != 2) return E.return(E.l);
        E.V();
        k.dispose();
        return E.J(0);
      });
    };
  function SD(a, b, c, d) {
    var e = TD,
      f = new zD();
    return new Promise(function (g, h) {
      f.Zb(a, "success", function () {
        try {
          g(e(a));
        } catch (k) {
          h(k);
        }
      });
      f.Zb(a, ["error", "timeout"], function () {
        return void h(new FB(a.o, ND(a)));
      });
      JD(a, b, c, d);
    }).finally(function () {
      f.dispose();
    });
  }
  function TD(a) {
    a: {
      if (Ks())
        try {
          OD(a);
          var b = "application/json";
          break a;
        } catch (e) {
          b = "application/xml";
          break a;
        }
      a.h && (a.h ? a.h.readyState : 0) == 4
        ? ((b = a.h.getResponseHeader("Content-Type")),
          (b = b === null ? void 0 : b))
        : (b = void 0);
      b = b || "";
    }
    if (b.indexOf("application/json") !== -1)
      try {
        return OD(a) || {};
      } catch (e) {
        throw new FB(5, ND(a));
      }
    try {
      var c = a.h ? a.h.responseXML : null;
    } catch (e) {
      c = null;
    }
    if (c == null) {
      try {
        var d = a.h ? a.h.responseText : "";
      } catch (e) {
        d = "";
      }
      c = HB(d);
    }
    Wd(c, Zd);
    return c;
  }
  D("google.javascript.ads.imalib.common.UrlLoader", PD);
  var UD = function () {
    var a;
    this.h = a = a === void 0 ? new PD() : a;
  };
  UD.prototype.ec = function (a) {
    var b = this;
    return Ka(function (c) {
      return c.h(b.h.get({ url: a, timeout: new yD() }), 0);
    });
  };
  var VD = function () {
    this.l = typeof window !== "undefined" && window.fetch != null;
  };
  VD.prototype.ec = function (a, b) {
    b = b === void 0 ? !1 : b;
    var c = this,
      d,
      e,
      f;
    return Ka(function (g) {
      switch (g.j) {
        case 1:
          g.A(2);
          a = XC(a);
          b = b || uD(a);
          if (!c.l) {
            g.ia(4);
            break;
          }
          (d = c).h != null || (d.h = new NB());
          g.A(5);
          return g.h(c.h.ec(a, b), 7);
        case 7:
          return g.return();
        case 5:
          g.o(2), (c.l = !1);
        case 4:
          if (Ks())
            return (f = c).o != null || (f.o = new UD()), g.h(c.o.ec(a, b), 9);
          (e = c).j != null || (e.j = new cD());
          return g.h(c.j.ec(a, b), 9);
        case 9:
          g.N(0);
          break;
        case 2:
          g.o(), g.B();
      }
    });
  };
  var WD = {
    AUTOPLAY_DISALLOWED: "autoplayDisallowed",
    zk: "beginFullscreen",
    CAN_PLAY: "canPlay",
    CAN_PLAY_THROUGH: "canPlayThrough",
    CLICK: "click",
    DURATION_CHANGE: "durationChange",
    Nk: "end",
    Ok: "endFullscreen",
    ERROR: "error",
    Sk: "focusSkipButton",
    LOAD_START: "loadStart",
    LOADED: "loaded",
    Al: "mediaLoadAttempt",
    Bl: "mediaLoadTimeout",
    Cl: "mediaPlaybackTimeout",
    PAUSE: "pause",
    PLAY: "play",
    PLAYING: "playing",
    SEEKED: "seeked",
    SEEKING: "seeking",
    Vl: "skip",
    Zh: "skipShown",
    STALLED: "stalled",
    Tf: "start",
    TIME_UPDATE: "timeUpdate",
    Yl: "timedMetadata",
    om: "volumeChange",
    WAITING: "waiting",
    qm: "windowFocusChanged",
    Uk: "fullyLoaded",
    yl: "inStreamAdBreakAnnounced",
  };
  var XD = function (a, b, c, d) {
    b = b === void 0 ? !1 : b;
    c = c === void 0 ? !1 : c;
    d = d === void 0 ? !1 : d;
    S.call(this);
    this.h = a;
    this.ba = d;
    this.loaded = this.l = !1;
    this.R = null;
    this.A = 0;
    this.j = new zD(this);
    tt(this, this.j);
    this.Ge = (b && Gc && !Tc) || c;
    this.va = [];
  };
  w(XD, S);
  n = XD.prototype;
  n.dispatchEvent = function (a) {
    return this.ba
      ? (this.va.push(a), !0)
      : S.prototype.dispatchEvent.call(this, a);
  };
  n.releaseEvents = function () {
    var a = this;
    this.ba &&
      ((this.ba = !1),
      this.va.forEach(function (b) {
        a.dispatchEvent(b);
      }));
  };
  n.Pb = function () {
    this.Ra();
    this.j.listen(this.h, "ended", this.Ye);
    this.j.listen(this.h, "pause", this.af);
    this.j.listen(this.h, "playing", this.ae);
    this.j.listen(this.h, "timeupdate", this.cf);
    this.j.listen(this.h, "volumechange", this.Og);
    this.j.listen(this.h, "error", this.qc);
    this.j.listen(this.h, "canplay", this.vj);
    this.j.listen(this.h, "canplaythrough", this.wj);
    this.j.listen(this.h, "loadstart", this.Dj);
    this.j.listen(this.h, "durationchange", this.Cj);
    this.j.listen(this.h, "waiting", this.Mj);
    this.j.listen(this.h, "seeked", this.Hj);
    this.j.listen(this.h, "seeking", this.Ij);
    this.j.listen(this.h, "stalled", this.Kj);
    this.j.listen(this.h, "progress", this.Gj);
    this.j.listen(this.h, "loadeddata", this.Ze);
  };
  n.Ra = function () {
    DD(this.j);
  };
  n.getCurrentTime = function () {
    return this.h.currentTime;
  };
  n.getDuration = function () {
    return isNaN(this.h.duration) ? -1 : this.h.duration;
  };
  n.getVolume = function () {
    return this.h.muted ? 0 : this.h.volume;
  };
  n.Gg = function () {
    return this.h.paused;
  };
  n.Ne = function () {
    return !1;
  };
  n.Ye = function () {
    this.dispatchEvent("end");
    YD(this);
  };
  n.af = function () {
    this.h.ended || this.dispatchEvent("pause");
    YD(this);
  };
  n.ae = function () {
    this.dispatchEvent("play");
    this.Ge && this.ed();
  };
  n.ed = function () {
    this.l || ((this.l = !0), YD(this), this.dispatchEvent("start"));
  };
  n.cf = function () {
    var a = this.getCurrentTime();
    if (!this.l) {
      if (a <= 0) return;
      if (Tc && this.h.ended && this.getDuration() === 1) {
        this.qc();
        return;
      }
      this.ed();
    }
    this.A = Math.max(this.A, a);
    this.dispatchEvent("timeUpdate");
  };
  n.Mj = function () {
    this.dispatchEvent("waiting");
  };
  n.Og = function () {
    this.dispatchEvent("volumeChange");
  };
  n.Cj = function () {
    this.dispatchEvent("durationChange");
  };
  n.qc = function () {
    YD(this);
    this.dispatchEvent("error");
  };
  n.vj = function () {
    this.dispatchEvent("canPlay");
    this.Ze();
  };
  n.wj = function () {
    this.dispatchEvent("canPlayThrough");
  };
  n.Dj = function () {
    this.dispatchEvent("loadStart");
    this.dispatchEvent("mediaLoadAttempt");
  };
  n.Hj = function () {
    this.dispatchEvent("seeked");
  };
  n.Ij = function () {
    this.dispatchEvent("seeking");
  };
  n.Kj = function () {
    this.dispatchEvent("stalled");
  };
  n.Gj = function () {
    this.h.buffered &&
      this.h.buffered.length &&
      this.h.buffered.end(this.h.buffered.length - 1) === this.getDuration() &&
      (eo(N.getInstance(), "vfl"), this.dispatchEvent("fullyLoaded"));
  };
  n.Ze = function () {
    this.loaded ||
      (eo(N.getInstance(), "vil"),
      (this.loaded = !0),
      this.dispatchEvent("loaded"));
  };
  n.unload = function () {
    this.h.removeAttribute("src");
    this.h.load();
  };
  n.play = function () {
    this.l || ZD(this);
    return this.h.play();
  };
  n.pause = function () {
    this.h.pause();
  };
  var ZD = function (a) {
      a.R ||
        (a.R = Zy(function () {
          a.l || a.dispatchEvent("mediaPlaybackTimeout");
        }, 8e3));
    },
    YD = function (a) {
      a.R && (C.clearTimeout(a.R), (a.R = null));
    };
  XD.prototype.setVolume = function (a) {
    this.h.volume = a;
  };
  XD.prototype.canPlayType = function (a) {
    if (typeof this.h.canPlayType !== "function")
      return N.getInstance().P("vmcpy", "1"), !0;
    a = this.h.canPlayType(a);
    return a !== "" && a != null;
  };
  XD.prototype.Cd = function () {
    return this.h.currentSrc;
  };
  XD.prototype.getSize = function () {
    return Pl(this.h);
  };
  var $D = function (a) {
    a = a === void 0 ? null : a;
    S.call(this);
    this.j = a;
  };
  w($D, S);
  n = $D.prototype;
  n.Me = function () {
    return !1;
  };
  n.rc = function () {
    return !1;
  };
  n.Fd = function () {
    return !1;
  };
  n.He = function () {
    return -1;
  };
  n.Je = function () {
    return -1;
  };
  n.Oe = function () {};
  n.kh = function () {};
  n.qg = function () {};
  n.reset = function () {};
  var bE = function (a, b) {
      b = b === void 0 ? !1 : b;
      this.uri = a;
      this.h = b;
      this.j = aE(a);
    },
    aE = function (a) {
      return new Map(
        a.j.split("/").reduce(function (b, c, d, e) {
          d % 2 && b.set(e[d - 1], c);
          return b;
        }, new Map())
      );
    },
    cE = function (a) {
      var b, c;
      return (b = a.uri) == null
        ? void 0
        : (c = b.j) == null
        ? void 0
        : c.startsWith("/videoplayback");
    };
  bE.prototype.getId = function () {
    return dE(this, "id");
  };
  var eE = function (a) {
      a = DC(a.uri, "range");
      if (!a) return null;
      a = a.split("-")[0];
      return !a || isNaN(Number(a)) ? null : Number(a);
    },
    dE = function (a, b) {
      var c = DC(a.uri, b);
      return c ? c : (a = a.j.get(b)) ? a : null;
    };
  var fE = {},
    gE =
      ((fE[18] = -1),
      (fE[22] = -1),
      (fE[43] = 350),
      (fE[44] = 350),
      (fE[45] = 350),
      (fE[59] = -1),
      (fE[133] = 350),
      (fE[134] = 350),
      (fE[135] = 350),
      (fE[136] = 350),
      (fE[137] = 350),
      (fE[139] = 50),
      (fE[140] = 50),
      (fE[141] = 50),
      (fE[160] = 350),
      (fE[242] = 150),
      (fE[243] = 150),
      (fE[244] = 150),
      (fE[245] = 150),
      (fE[247] = 150),
      (fE[248] = 150),
      (fE[249] = 50),
      (fE[250] = 50),
      (fE[251] = 50),
      (fE[278] = 150),
      (fE[342] = -1),
      (fE[343] = -1),
      (fE[344] = -1),
      (fE[345] = -1),
      (fE[346] = -1),
      (fE[347] = -1),
      (fE[396] = 150),
      (fE[397] = 150),
      (fE[398] = 150),
      (fE[399] = 150),
      fE),
    hE = {},
    iE =
      ((hE[18] = !1),
      (hE[22] = !1),
      (hE[43] = !0),
      (hE[44] = !0),
      (hE[45] = !0),
      (hE[59] = !1),
      (hE[133] = !0),
      (hE[134] = !0),
      (hE[135] = !0),
      (hE[136] = !0),
      (hE[137] = !0),
      (hE[139] = !0),
      (hE[140] = !0),
      (hE[141] = !0),
      (hE[160] = !0),
      (hE[242] = !0),
      (hE[243] = !0),
      (hE[244] = !0),
      (hE[245] = !0),
      (hE[247] = !0),
      (hE[248] = !0),
      (hE[249] = !0),
      (hE[250] = !0),
      (hE[251] = !0),
      (hE[278] = !0),
      (hE[342] = !1),
      (hE[343] = !1),
      (hE[344] = !1),
      (hE[345] = !1),
      (hE[346] = !1),
      (hE[347] = !1),
      (hE[396] = !0),
      (hE[397] = !0),
      (hE[398] = !0),
      (hE[399] = !0),
      hE),
    jE = {},
    kE =
      ((jE[18] = "video/mp4"),
      (jE[22] = "video/mp4"),
      (jE[43] = "video/webm"),
      (jE[44] = "video/webm"),
      (jE[45] = "video/webm"),
      (jE[59] = "video/mp4"),
      (jE[133] = "video/mp4"),
      (jE[134] = "video/mp4"),
      (jE[135] = "video/mp4"),
      (jE[136] = "video/mp4"),
      (jE[137] = "video/mp4"),
      (jE[139] = "audio/mp4"),
      (jE[140] = "audio/mp4"),
      (jE[141] = "audio/mp4"),
      (jE[160] = "video/mp4"),
      (jE[242] = "video/webm"),
      (jE[243] = "video/webm"),
      (jE[244] = "video/webm"),
      (jE[245] = "video/webm"),
      (jE[247] = "video/webm"),
      (jE[248] = "video/webm"),
      (jE[249] = "audio/webm"),
      (jE[250] = "audio/webm"),
      (jE[251] = "audio/webm"),
      (jE[278] = "video/webm"),
      (jE[342] = "video/mp4"),
      (jE[343] = "video/mp4"),
      (jE[344] = "video/mp4"),
      (jE[345] = "video/mp4"),
      (jE[346] = "video/mp4"),
      (jE[347] = "video/mp4"),
      (jE[396] = "video/mp4"),
      (jE[397] = "video/mp4"),
      (jE[398] = "video/mp4"),
      (jE[399] = "video/mp4"),
      jE),
    lE = {},
    mE =
      ((lE[18] = "avc1.42001E, mp4a.40.2"),
      (lE[22] = "avc1.64001F, mp4a.40.2"),
      (lE[43] = "vp8, vorbis"),
      (lE[44] = "vp8, vorbis"),
      (lE[45] = "vp8, vorbis"),
      (lE[59] = "avc1.4D001F, mp4a.40.2"),
      (lE[133] = "avc1.4D401C"),
      (lE[134] = "avc1.4D401E"),
      (lE[135] = "avc1.4D401E"),
      (lE[136] = "avc1.4D401F"),
      (lE[137] = "avc1.640028"),
      (lE[139] = "mp4a.40.2"),
      (lE[140] = "mp4a.40.2"),
      (lE[141] = "mp4a.40.2"),
      (lE[160] = "avc1.4D401E"),
      (lE[242] = "vp9"),
      (lE[243] = "vp9"),
      (lE[244] = "vp9"),
      (lE[245] = "vp9"),
      (lE[247] = "vp9"),
      (lE[248] = "vp9"),
      (lE[249] = "opus"),
      (lE[250] = "opus"),
      (lE[251] = "opus"),
      (lE[278] = "vp9"),
      (lE[342] = "avc1.42E01E, mp4a.40.2"),
      (lE[343] = "avc1.42E01E, mp4a.40.2"),
      (lE[344] = "avc1.42E01E, mp4a.40.2"),
      (lE[345] = "avc1.42E01E, mp4a.40.2"),
      (lE[346] = "avc1.42E01E, mp4a.40.2"),
      (lE[347] = "avc1.4D001F, mp4a.40.2"),
      (lE[396] = "av01.0.01M.08"),
      (lE[397] = "av01.0.04M.08"),
      (lE[398] = "av01.0.08M.08"),
      (lE[399] = "av01.0.09M.08"),
      lE);
  var nE = RegExp("/itag/(\\d+)/");
  function oE(a) {
    var b = Number(iq(a, "itag"));
    return b ? b : (a = a.match(nE)) && a.length === 2 ? Number(a[1]) : null;
  }
  function pE(a) {
    var b = kE[a];
    a = mE[a];
    b
      ? ((b = tk(b).toLowerCase()),
        (b = a ? b + '; codecs="' + tk(a) + '"' : b))
      : (b = "");
    return b;
  }
  function qE(a, b) {
    if (typeof CustomEvent === "function")
      return new CustomEvent(a, { detail: b });
    var c = document.createEvent("CustomEvent");
    c.initCustomEvent(a, !1, !0, b);
    return c;
  }
  var rE = ["doubleclick.net"];
  function sE(a) {
    return Xb() || G("iPad") || G("iPod")
      ? !!(PC() && (a == null ? 0 : a.Fm))
      : G("Android")
      ? PC()
        ? !0
        : Qj()
        ? !1
        : tE()
      : !1;
  }
  function tE() {
    var a = !1,
      b = new oC(window.location.href).h;
    rE.forEach(function (c) {
      b.includes(c) && (a = !0);
    });
    return a;
  }
  function uE(a, b, c) {
    if (typeof a === "number") var d = { name: vE(a) };
    else
      a && a.name
        ? ((d = a), (a = wE(a.name)))
        : ((d = { name: "UnknownError" }), (a = xE));
    this.code = a;
    this.h = d;
    b = "Error " + b + ": " + this.getName();
    c && (b += ", " + c);
    pb.call(this, b);
  }
  ob(uE, pb);
  uE.prototype.getName = function () {
    return (this.h && this.h.name) || "";
  };
  var yE = {
      bi: 1,
      Gl: 2,
      NOT_FOUND_ERR: 3,
      Hh: 4,
      Kh: 5,
      Hl: 6,
      ai: 7,
      ABORT_ERR: 8,
      Xh: 9,
      gm: 10,
      TIMEOUT_ERR: 11,
      Wh: 12,
      INVALID_ACCESS_ERR: 13,
      INVALID_STATE_ERR: 14,
    },
    xE = (C.h || C.j || yE).bi,
    zE = (C.h || C.j || yE).NOT_FOUND_ERR,
    AE = (C.h || C.j || yE).Hh,
    BE = (C.h || C.j || yE).Kh,
    CE = (C.h || C.j || yE).ai,
    DE = (C.h || C.j || yE).ABORT_ERR,
    EE = (C.h || C.j || yE).Xh,
    FE = (C.h || C.j || yE).TIMEOUT_ERR,
    GE = (C.h || C.j || yE).Wh,
    HE = (C.DOMException || yE).INVALID_ACCESS_ERR,
    IE = (C.DOMException || yE).INVALID_STATE_ERR,
    wE = function (a) {
      switch (a) {
        case "UnknownError":
          return xE;
        case "NotFoundError":
          return zE;
        case "ConstraintError":
          return AE;
        case "DataError":
          return BE;
        case "TransactionInactiveError":
          return CE;
        case "AbortError":
          return DE;
        case "ReadOnlyError":
          return EE;
        case "TimeoutError":
          return FE;
        case "QuotaExceededError":
          return GE;
        case "InvalidAccessError":
          return HE;
        case "InvalidStateError":
          return IE;
        default:
          return xE;
      }
    },
    vE = function (a) {
      switch (a) {
        case xE:
          return "UnknownError";
        case zE:
          return "NotFoundError";
        case AE:
          return "ConstraintError";
        case BE:
          return "DataError";
        case CE:
          return "TransactionInactiveError";
        case DE:
          return "AbortError";
        case EE:
          return "ReadOnlyError";
        case FE:
          return "TimeoutError";
        case GE:
          return "QuotaExceededError";
        case HE:
          return "InvalidAccessError";
        case IE:
          return "InvalidStateError";
        default:
          return "UnknownError";
      }
    },
    JE = function (a, b) {
      return "error" in a
        ? new uE(a.error, b)
        : new uE({ name: "UnknownError" }, b);
    },
    KE = function (a, b) {
      return "name" in a
        ? new uE(a, b + ": " + a.message)
        : new uE({ name: "UnknownError" }, b);
    };
  function LE(a) {
    this.h = a;
  }
  var ME = C.IDBKeyRange || C.webkitIDBKeyRange;
  LE.prototype.range = function () {
    return this.h;
  }; /* 
 
 Copyright 2005, 2007 Bob Ippolito. All Rights Reserved. 
 Copyright The Closure Library Authors. 
 SPDX-License-Identifier: MIT 
*/
  function NE() {
    this.A = [];
    this.o = this.l = !1;
    this.j = void 0;
    this.F = this.H = this.B = !1;
    this.D = 0;
    this.h = null;
    this.C = 0;
  }
  NE.prototype.cancel = function (a) {
    if (this.l) this.j instanceof NE && this.j.cancel();
    else {
      if (this.h) {
        var b = this.h;
        delete this.h;
        a ? b.cancel(a) : (b.C--, b.C <= 0 && b.cancel());
      }
      this.F = !0;
      this.l || OE(this, new PE(this));
    }
  };
  NE.prototype.N = function (a, b) {
    this.B = !1;
    QE(this, a, b);
  };
  var QE = function (a, b, c) {
      a.l = !0;
      a.j = c;
      a.o = !b;
      RE(a);
    },
    TE = function (a) {
      if (a.l) {
        if (!a.F) throw new SE(a);
        a.F = !1;
      }
    };
  NE.prototype.Ea = function (a) {
    TE(this);
    QE(this, !0, a);
  };
  var OE = function (a, b) {
      TE(a);
      QE(a, !1, b);
    },
    VE = function (a, b) {
      return UE(a, b, null);
    },
    UE = function (a, b, c, d) {
      var e = a.l;
      e || (b === c ? (b = c = uy(b)) : ((b = uy(b)), (c = uy(c))));
      a.A.push([b, c, d]);
      e && RE(a);
      return a;
    };
  NE.prototype.then = function (a, b, c) {
    var d,
      e,
      f = new Jy(function (g, h) {
        e = g;
        d = h;
      });
    UE(
      this,
      e,
      function (g) {
        g instanceof PE ? f.cancel() : d(g);
        return WE;
      },
      this
    );
    return f.then(a, b, c);
  };
  NE.prototype.$goog_Thenable = !0;
  var XE = function (a) {
      return ec(a.A, function (b) {
        return typeof b[1] === "function";
      });
    },
    WE = {},
    RE = function (a) {
      if (a.D && a.l && XE(a)) {
        var b = a.D,
          c = YE[b];
        c && (C.clearTimeout(c.h), delete YE[b]);
        a.D = 0;
      }
      a.h && (a.h.C--, delete a.h);
      b = a.j;
      for (var d = (c = !1); a.A.length && !a.B; ) {
        var e = a.A.shift(),
          f = e[0],
          g = e[1];
        e = e[2];
        if ((f = a.o ? g : f))
          try {
            var h = f.call(e || null, b);
            h === WE && (h = void 0);
            h !== void 0 &&
              ((a.o = a.o && (h == b || h instanceof Error)), (a.j = b = h));
            if (
              Hy(b) ||
              (typeof C.Promise === "function" && b instanceof C.Promise)
            )
              (d = !0), (a.B = !0);
          } catch (k) {
            (b = k), (a.o = !0), XE(a) || (c = !0);
          }
      }
      a.j = b;
      d &&
        ((h = a.N.bind(a, !0)),
        (d = a.N.bind(a, !1)),
        b instanceof NE ? (UE(b, h, d), (b.H = !0)) : b.then(h, d));
      c && ((b = new ZE(b)), (YE[b.h] = b), (a.D = b.h));
    },
    SE = function () {
      pb.call(this);
    };
  ob(SE, pb);
  SE.prototype.message = "Deferred has already fired";
  SE.prototype.name = "AlreadyCalledError";
  var PE = function () {
    pb.call(this);
  };
  ob(PE, pb);
  PE.prototype.message = "Deferred was canceled";
  PE.prototype.name = "CanceledError";
  var ZE = function (a) {
      var b = this;
      this.h = C.setTimeout(function () {
        delete YE[b.h];
        throw b.j;
      }, 0);
      this.j = a;
    },
    YE = {};
  function $E() {
    S.call(this);
  }
  ob($E, S);
  $E.prototype.h = null;
  $E.prototype.next = function (a) {
    if (a) this.h["continue"](a);
    else this.h["continue"]();
  };
  $E.prototype.remove = function () {
    var a = new NE();
    try {
      var b = this.h["delete"]();
    } catch (c) {
      return OE(a, KE(c, "deleting via cursor")), a;
    }
    b.onsuccess = function () {
      a.Ea();
    };
    b.onerror = function (c) {
      OE(a, JE(c.target, "deleting via cursor"));
    };
    return a;
  };
  $E.prototype.getValue = function () {
    return this.h.value;
  };
  var aF = function (a, b) {
    var c = new $E();
    try {
      var d = b ? b.range() : null;
      var e = a.openCursor(d);
    } catch (f) {
      throw (c.dispose(), KE(f, a.name));
    }
    e.onsuccess = function (f) {
      c.h = f.target.result || null;
      c.h ? c.dispatchEvent("n") : c.dispatchEvent("c");
    };
    e.onerror = function () {
      c.dispatchEvent("e");
    };
    return c;
  };
  function bF(a) {
    this.h = a;
  }
  bF.prototype.getName = function () {
    return this.h.name;
  };
  var cF = function (a, b, c) {
    var d = new NE();
    try {
      var e = a.h.get(c);
    } catch (f) {
      return (b += " with key " + nk(c)), OE(d, KE(f, b)), d;
    }
    e.onsuccess = function (f) {
      d.Ea(f.target.result);
    };
    e.onerror = function (f) {
      b += " with key " + nk(c);
      OE(d, JE(f.target, b));
    };
    return d;
  };
  bF.prototype.get = function (a) {
    return cF(this, "getting from index " + this.getName(), a);
  };
  bF.prototype.getAll = function (a, b) {
    return dF(this, "getting all from index " + this.getName(), a, b);
  };
  var dF = function (a, b, c, d) {
      var e;
      c === void 0
        ? (e = void 0)
        : (e = c instanceof LE ? c.range() : new LE(ME.only(c)).range());
      var f = new NE();
      try {
        var g = a.h.getAll(e, d);
      } catch (h) {
        return (b += " for range " + (e ? nk(e) : "<all>")), OE(f, KE(h, b)), f;
      }
      g.onsuccess = function () {
        f.Ea(g.result);
      };
      g.onerror = function (h) {
        b += " for range " + (e ? nk(e) : "<all>");
        OE(f, JE(h.target, b));
      };
      return f;
    },
    eF = function (a, b) {
      return aF(a.h, b);
    };
  var fF = function (a) {
    this.h = a;
  };
  fF.prototype.getName = function () {
    return this.h.name;
  };
  var gF = function (a, b, c, d, e) {
      var f = new NE();
      try {
        var g = e ? a.h[b](d, e) : a.h[b](d);
      } catch (h) {
        return (
          (c += nk(d)), e && (c += ", with key " + nk(e)), OE(f, KE(h, c)), f
        );
      }
      g.onsuccess = function (h) {
        f.Ea(h.target.result);
      };
      g.onerror = function (h) {
        c += nk(d);
        e && (c += ", with key " + nk(e));
        OE(f, JE(h.target, c));
      };
      return f;
    },
    hF = function (a, b) {
      return gF(a, "put", "putting into " + a.getName() + " with value", b);
    };
  fF.prototype.add = function (a, b) {
    return gF(
      this,
      "add",
      "adding into " + this.getName() + " with value ",
      a,
      b
    );
  };
  fF.prototype.remove = function (a) {
    var b = new NE();
    try {
      var c = this.h["delete"](a instanceof LE ? a.range() : a);
    } catch (e) {
      return (
        (c = "removing from " + this.getName() + " with key " + nk(a)),
        OE(b, KE(e, c)),
        b
      );
    }
    c.onsuccess = function () {
      b.Ea();
    };
    var d = this;
    c.onerror = function (e) {
      var f = "removing from " + d.getName() + " with key " + nk(a);
      OE(b, JE(e.target, f));
    };
    return b;
  };
  fF.prototype.get = function (a) {
    var b = new NE();
    try {
      var c = this.h.get(a);
    } catch (e) {
      return (
        (c = "getting from " + this.getName() + " with key " + nk(a)),
        OE(b, KE(e, c)),
        b
      );
    }
    c.onsuccess = function (e) {
      b.Ea(e.target.result);
    };
    var d = this;
    c.onerror = function (e) {
      var f = "getting from " + d.getName() + " with key " + nk(a);
      OE(b, JE(e.target, f));
    };
    return b;
  };
  fF.prototype.getAll = function (a, b) {
    return iF(this, "getting all from index " + this.getName(), a, b);
  };
  var iF = function (a, b, c, d) {
    var e;
    c === void 0
      ? (e = void 0)
      : (e = c instanceof LE ? c.range() : new LE(ME.only(c)).range());
    var f = new NE();
    try {
      var g = a.h.getAll(e, d);
    } catch (h) {
      return (b += " for range " + (e ? nk(e) : "<all>")), OE(f, KE(h, b)), f;
    }
    g.onsuccess = function () {
      f.Ea(g.result);
    };
    g.onerror = function (h) {
      b += " for range " + (e ? nk(e) : "<all>");
      OE(f, JE(h.target, b));
    };
    return f;
  };
  fF.prototype.clear = function () {
    var a = "clearing store " + this.getName(),
      b = new NE();
    try {
      var c = this.h.clear();
    } catch (d) {
      return OE(b, KE(d, a)), b;
    }
    c.onsuccess = function () {
      b.Ea();
    };
    c.onerror = function (d) {
      OE(b, JE(d.target, a));
    };
    return b;
  };
  var jF = function (a) {
    try {
      return new bF(a.h.index("timestamp"));
    } catch (b) {
      throw KE(b, "getting index timestamp");
    }
  };
  fF.prototype.count = function (a) {
    var b = new NE();
    try {
      var c = a ? a.range() : null,
        d = this.h.count(c);
      d.onsuccess = function (f) {
        b.Ea(f.target.result);
      };
      var e = this;
      d.onerror = function (f) {
        OE(b, JE(f.target, e.getName()));
      };
    } catch (f) {
      OE(b, KE(f, this.getName()));
    }
    return b;
  };
  var kF = function (a, b) {
    S.call(this);
    this.h = a;
    this.l = b;
    this.j = new zD(this);
    this.j.listen(
      this.h,
      "complete",
      this.dispatchEvent.bind(this, "complete")
    );
    this.j.listen(this.h, "abort", this.dispatchEvent.bind(this, "abort"));
    this.j.listen(this.h, "error", this.Mh);
  };
  w(kF, S);
  n = kF.prototype;
  n.Mh = function (a) {
    a.target instanceof uE
      ? this.dispatchEvent({ type: "error", target: a.target })
      : this.dispatchEvent({
          type: "error",
          target: JE(a.target, "in transaction"),
        });
  };
  n.objectStore = function (a) {
    try {
      return new fF(this.h.objectStore(a));
    } catch (b) {
      throw KE(b, "getting object store " + a);
    }
  };
  n.commit = function (a) {
    if (this.h.commit || !a)
      try {
        this.h.commit();
      } catch (b) {
        throw KE(b, "cannot commit the transaction");
      }
  };
  n.wait = function () {
    var a = new NE();
    iy(this, "complete", a.Ea.bind(a));
    var b = iy(this, "abort", function () {
      ry(c);
      OE(a, new uE(DE, "waiting for transaction to complete"));
    });
    var c = iy(this, "error", function (e) {
      ry(b);
      OE(a, e.target);
    });
    var d = this.l;
    return VE(a, function () {
      return d;
    });
  };
  n.abort = function () {
    this.h.abort();
  };
  n.M = function () {
    S.prototype.M.call(this);
    this.j.dispose();
  };
  var lF = {
    READ_ONLY: "readonly",
    READ_WRITE: "readwrite",
    im: "versionchange",
  };
  function mF(a) {
    S.call(this);
    this.h = a;
    this.j = new zD(this);
    this.j.listen(this.h, "abort", this.dispatchEvent.bind(this, "abort"));
    this.j.listen(this.h, "error", this.Nh);
    this.j.listen(this.h, "versionchange", this.Ji);
    this.j.listen(this.h, "close", this.dispatchEvent.bind(this, "close"));
  }
  ob(mF, S);
  n = mF.prototype;
  n.df = !0;
  n.Nh = function (a) {
    a = (a = a.target) && a.error;
    this.dispatchEvent({ type: "error", errorCode: a && a.severity });
  };
  n.Ji = function (a) {
    this.dispatchEvent(new nF(a.oldVersion, a.newVersion));
  };
  n.close = function () {
    this.df && (this.h.close(), (this.df = !1));
  };
  n.Wa = function () {
    return this.df;
  };
  n.getName = function () {
    return this.h.name;
  };
  n.getVersion = function () {
    return Number(this.h.version);
  };
  var oF = function (a, b) {
    var c = ["MediaSourceVideoChunk"];
    try {
      var d = b ? a.h.transaction(c, b) : a.h.transaction(c);
      return new kF(d, a);
    } catch (e) {
      throw KE(e, "creating transaction");
    }
  };
  mF.prototype.M = function () {
    mF.yb.M.call(this);
    this.j.dispose();
  };
  var nF = function (a, b) {
    Vx.call(this, "versionchange");
    this.oldVersion = a;
    this.newVersion = b;
  };
  ob(nF, Vx);
  var pF = void 0;
  function qF(a) {
    var b = new NE();
    pF == void 0 &&
      (pF =
        C.indexedDB || C.mozIndexedDB || C.webkitIndexedDB || C.moz_indexedDB);
    var c = pF.open("IndexedDbVideoChunkPersistentStorage", 7);
    c.onsuccess = function (d) {
      d = new mF(d.target.result);
      b.Ea(d);
    };
    c.onerror = function (d) {
      OE(
        b,
        JE(d.target, "opening database IndexedDbVideoChunkPersistentStorage")
      );
    };
    c.onupgradeneeded = function (d) {
      if (a) {
        var e = new mF(d.target.result);
        a(
          new nF(d.oldVersion, d.newVersion),
          e,
          new kF(d.target.transaction, e)
        );
      }
    };
    c.onblocked = function () {};
    return b;
  }
  var rF = function (a) {
    S.call(this);
    this.j = a;
    this.Qa = this.h = null;
  };
  w(rF, S);
  rF.prototype.initialize = function () {
    var a = this;
    return Promise.resolve(qF(this.l)).then(
      function (b) {
        a.h = b;
      },
      function (b) {
        N.getInstance().P("codf", b.message);
      }
    );
  };
  rF.prototype.Wa = function () {
    return this.h !== null && this.h.Wa();
  };
  rF.prototype.close = function () {
    var a = this;
    return new Promise(function (b) {
      sF(a, b);
    })
      .then(function () {
        return tF();
      })
      .then(function () {
        a.h.close();
      });
  };
  var tF = function () {
    var a;
    return ((a = navigator.storage) == null ? 0 : a.estimate)
      ? navigator.storage.estimate().then(function (b) {
          N.getInstance().P("csue", String(b.usage));
        })
      : Promise.resolve(void 0);
  };
  rF.prototype.xc = function (a) {
    return (a = uF(this, a, 0))
      ? vF(this, wF(a), a.lmt)
      : Promise.resolve(null);
  };
  rF.prototype.Kc = function (a, b, c, d) {
    (b = uF(this, b, c))
      ? ((c = b.startIndex),
        xF(this, {
          cacheId: wF(b),
          startIndex: c,
          endIndex: c + a.byteLength - 1,
          lmt: b.lmt,
          timestamp: new Date(Date.now()),
          isLastVideoChunk: d,
          itag: b.itag,
          video: a,
        }))
      : Promise.resolve(void 0);
  };
  rF.prototype.l = function (a, b) {
    if (a.oldVersion !== 6) {
      if (b.h.objectStoreNames.contains("MediaSourceVideoChunk"))
        try {
          b.h.deleteObjectStore("MediaSourceVideoChunk");
        } catch (d) {
          throw KE(d, "deleting object store MediaSourceVideoChunk");
        }
      a = { keyPath: "cacheId" };
      try {
        var c = new fF(b.h.createObjectStore("MediaSourceVideoChunk", a));
      } catch (d) {
        throw KE(d, "creating object store MediaSourceVideoChunk");
      }
      b = { unique: !1 };
      try {
        c.h.createIndex("timestamp", "timestamp", b);
      } catch (d) {
        throw KE(d, "creating new index timestamp with key path timestamp");
      }
    }
  };
  var sF = function (a, b) {
      var c = new Date(Date.now());
      c.setDate(c.getDate() - 30);
      c = new LE(ME.upperBound(c, void 0));
      var d = eF(
          jF(oF(a.h, lF.READ_WRITE).objectStore("MediaSourceVideoChunk")),
          c
        ),
        e = d.listen("n", function () {
          d.remove();
          d.next();
        });
      iy(d, "c", function () {
        ry(e);
        b();
      });
    },
    yF = function (a) {
      var b = new Set(),
        c = new LE(
          ME.bound(
            new Date(Date.now() - 2592e6),
            new Date(Date.now()),
            void 0,
            void 0
          )
        );
      return new Promise(function (d) {
        var e = eF(
            jF(oF(a.h, lF.READ_ONLY).objectStore("MediaSourceVideoChunk")),
            c
          ),
          f = e.listen("n", function () {
            var g = e.getValue();
            g && g.videoId && b.add(g.videoId);
            e.next();
          });
        iy(e, "c", function () {
          ry(f);
          d(Array.from(b));
        });
      });
    },
    uF = function (a, b, c) {
      var d,
        e = new bE(b, (d = a.j) == null ? void 0 : d.mg);
      d = e.getId();
      a = dE(e, "itag");
      b = dE(e, "source");
      var f = dE(e, "lmt");
      e = eE(e);
      var g = [];
      d
        ? a
          ? b
            ? f
              ? e === null && g.push("startIndex")
              : g.push("lmt")
            : g.push("source")
          : g.push("itag")
        : g.push("videoId");
      return g.length > 0
        ? (N.getInstance().P("civp", g.join("-")), null)
        : { videoId: d, itag: a, source: b, lmt: f, startIndex: e + c };
    },
    wF = function (a) {
      for (
        var b = [a.videoId, a.source, a.startIndex].join(), c = 0, d = 0;
        d < b.length;
        d++
      )
        c = (Math.imul(31, c) + b.charCodeAt(d)) | 0;
      return c.toString() + "," + a.itag;
    },
    vF = function (a, b, c) {
      var d = oF(a.h, lF.READ_WRITE).objectStore("MediaSourceVideoChunk");
      return Promise.resolve(d.get(b)).then(
        function (e) {
          if (!e) return N.getInstance().P("cenf", "1"), null;
          if (e.lmt !== c)
            return (
              N.getInstance().P("cdl", "1"),
              d.remove(b).then(null, function (f) {
                N.getInstance().P("crdlvf", f.message);
              }),
              null
            );
          N.getInstance().P("cefml", "1");
          return {
            itag: e.itag,
            endIndex: e.endIndex,
            isLastVideoChunk: e.isLastVideoChunk,
            video: e.video,
          };
        },
        function (e) {
          N.getInstance().P("cgvf", e.message);
          return null;
        }
      );
    },
    xF = function (a, b) {
      a = oF(a.h, lF.READ_WRITE).objectStore("MediaSourceVideoChunk");
      Promise.resolve(hF(a, b)).then(
        function () {
          N.getInstance().P("cavs", "1");
        },
        function (c) {
          N.getInstance().P("cavf", c.message);
        }
      );
    };
  var zF = function (a) {
    a = Error.call(this, a === void 0 ? "" : a);
    this.message = a.message;
    "stack" in a && (this.stack = a.stack);
    this.name = "XhrAbortedError";
  };
  w(zF, Error);
  var AF = function (a, b, c) {
    $D.call(this, b === void 0 ? null : b);
    var d = this;
    this.h = c;
    this.C = null;
    this.K = !1;
    this.O = this.o = this.l = 0;
    this.R = !1;
    this.F = this.J = null;
    this.ac = "ls_unknown";
    this.Qa = null;
    this.H = a;
    this.uri = new oC(a.url);
    this.state = 0;
    this.A = (this.B = sE(this.h) && !$C(this.uri)) ? EB(rF) : null;
    rt(this, function () {
      qt(d.A);
    });
    this.J = this.B ? this.A.initialize() : null;
    var e;
    (e = this.J) == null ||
      e.then(function () {
        var f, g, h, k, l;
        return Ka(function (m) {
          if (m.j == 1) {
            if ((f = d.A) == null ? 0 : f.Wa())
              (g = d.j) == null ||
                g.dispatchEvent(
                  qE("cache_init_success", { mimeType: d.H.mimeType })
                );
            return (h = d.h) != null && h.gn ? m.h(yF(d.A), 3) : m.ia(0);
          }
          k = m.l;
          k.length > 0 &&
            ((l = d.j) == null ||
              l.dispatchEvent(qE("indexed_db_mrid", { qn: k.join(",") })));
          m.B();
        });
      });
  };
  w(AF, $D);
  n = AF.prototype;
  n.He = function () {
    return this.l;
  };
  n.Je = function () {
    return this.o;
  };
  n.rc = function () {
    return this.state === 3;
  };
  n.Me = function () {
    return this.state === 0;
  };
  n.Fd = function () {
    return this.l <= this.o;
  };
  n.kh = function () {
    var a;
    (a = this.h) != null &&
      a.Ec &&
      ((this.K = !0),
      this.state === 3 || this.Fd() || ((this.state = 1), BF(this)));
  };
  n.qg = function () {
    var a;
    (a = this.h) != null && a.Ec && ((this.K = !1), CF(this));
  };
  n.reset = function () {
    CF(this);
    this.O = this.state = this.o = this.l = 0;
    this.ac = "ls_unknown";
  };
  var CF = function (a) {
    a.C && (a.C.abort(), (a.C = null), (a.state = 0));
  };
  AF.prototype.Oe = function (a) {
    if (this.state === 1) (this.l += a), (this.state = 2);
    else if (this.state === 0) {
      this.l += a;
      var b;
      if ((b = this.h) == null || !b.Ec || this.K) (this.state = 1), BF(this);
    }
  };
  var DF = function (a) {
      var b;
      if (((b = a.h) == null ? 0 : b.Ec) && !a.K) return !1;
      b = a.O > 3;
      var c = a.j && a.j.readyState >= HTMLMediaElement.HAVE_FUTURE_DATA,
        d = a.o >= a.l || a.state === 3,
        e;
      if (((e = a.h) == null ? 0 : e.Xe) && c) return !d;
      b &&
        a.F !== null &&
        ((e = qE("media_source_error", {
          code:
            a.o > 0
              ? MediaError.MEDIA_ERR_NETWORK
              : MediaError.MEDIA_ERR_SRC_NOT_SUPPORTED,
          message:
            'Response code "' +
            a.F +
            '" with ' +
            a.l +
            " bytes requested and " +
            a.o +
            " bytes loaded",
        })),
        a.dispatchEvent(e));
      return !d && !b;
    },
    BF = function (a) {
      var b, c, d, e, f;
      Ka(function (g) {
        switch (g.j) {
          case 1:
            b = 0;
          case 2:
            c = void 0;
            if ((c = a.h) == null || !c.Xe) {
              g.ia(5);
              break;
            }
            return g.h(
              new Promise(function (h) {
                setTimeout(h, Math.min(1e3, Math.pow(2, b) - 1));
              }),
              5
            );
          case 5:
            return a.state === 2 && (a.state = 1), g.h(EF(a), 7);
          case 7:
            b++,
              (d = DC(a.uri, "range")),
              (e = void 0),
              (e = a.j) == null ||
                e.dispatchEvent(
                  qE("chunk_load_attempted", {
                    Df: b,
                    range: d,
                    mimeType: a.H.mimeType,
                  })
                ),
              DF(a)
                ? g.ia(2)
                : ((f = a.j) == null ||
                    f.dispatchEvent(
                      qE("chunk_loaded", {
                        Df: b,
                        mimeType: a.H.mimeType,
                        ac: a.ac,
                      })
                    ),
                  a.state !== 3 && (a.state = 0),
                  (a.ac = "ls_unknown"),
                  g.B());
        }
      });
    },
    EF = function (a) {
      var b, c, d, e, f;
      return Ka(function (g) {
        switch (g.j) {
          case 1:
            b = a.o + "-" + (a.l - 1);
            CC(a.uri, "range", b);
            if (!a.B || a.R) {
              g.ia(2);
              break;
            }
            return ((d = (c = a.h) == null ? void 0 : c.tk) != null ? d : 0) > 0
              ? g.h(
                  Promise.race([
                    a.J,
                    new Promise(function (h) {
                      var k;
                      setTimeout(
                        function () {
                          h(void 0);
                        },
                        (k = a.h) == null ? void 0 : k.tk
                      );
                    }),
                  ]),
                  6
                )
              : g.h(a.J, 5);
          case 5:
            return g.return(FF(a));
          case 6:
            if ((e = a.A) == null ? 0 : e.Wa()) return g.return(FF(a));
            a.R = !0;
          case 2:
            return g.A(7, 8), g.h(GF(a), 8);
          case 8:
            g.V();
            a.C = null;
            a.ac = "ls_network";
            g.J(0);
            break;
          case 7:
            (f = g.o()), HF(a, f), g.ia(8);
        }
      });
    },
    FF = function (a) {
      var b, c, d, e, f, g, h;
      return Ka(function (k) {
        switch (k.j) {
          case 1:
            return (
              (b = a.A),
              ((f = (d = a.h) == null ? void 0 : d.sk) != null ? f : 0) > 0 &&
              ((e = a.h) == null ? 0 : e.Am)
                ? k.h(
                    Promise.race([
                      b
                        .xc(a.uri)
                        .then(function (l) {
                          return l;
                        })
                        .catch(function (l) {
                          var m;
                          (m = a.j) == null ||
                            m.dispatchEvent(
                              qE("video_cache_get_video_error", { error: l })
                            );
                          return null;
                        }),
                      new Promise(function (l) {
                        var m;
                        setTimeout(
                          function () {
                            l(null);
                          },
                          (m = a.h) == null ? void 0 : m.sk
                        );
                      }),
                    ]),
                    5
                  )
                : k.h(b.xc(a.uri), 4)
            );
          case 4:
            c = k.l;
            k.ia(3);
            break;
          case 5:
            c = k.l;
          case 3:
            (g = a.j) == null ||
              g.dispatchEvent(
                qE("chunk_cache_query", {
                  xi: c !== null,
                  mimeType: a.H.mimeType,
                })
              );
            if (c) {
              c.isLastVideoChunk && (a.state = 3);
              a.ac = "ls_cache_hit";
              IF(a, c.video, 0);
              k.ia(0);
              break;
            }
            k.A(7, 8);
            return k.h(GF(a), 8);
          case 8:
            k.V();
            a.C = null;
            a.ac = "ls_cache_miss_fallback";
            k.J(0);
            break;
          case 7:
            (h = k.o()), HF(a, h), k.ia(8);
        }
      });
    },
    HF = function (a, b) {
      if (!(b instanceof zF)) {
        var c;
        b = new bE(a.uri, (c = a.h) == null ? void 0 : c.mg);
        var d;
        if (((d = a.h) == null ? 0 : d.De) && cE(b)) {
          a: if (cE(b)) {
            var e = (c = dE(b, "mn")) ? c.split(",") : null;
            d = dE(b, "fvip");
            c = b.uri.N();
            if (e && d && !b.h) {
              var f = (Number(dE(b, "fallback_count")) || 0) + 1;
              if ((e = e[f])) {
                c.h = "r" + d + "---" + e + ".googlevideo.com";
                CC(c, "fallback_count", f);
                var g = c;
                break a;
              }
            }
            var h;
            d =
              Number(
                ((h = (g = DC(c, "cmo")) == null ? void 0 : g.split("=")) !=
                null
                  ? h
                  : [])[1]
              ) || 0;
            b.uri.h.match(/^r{1,2}(\d+)---(.+)\.googlevideo.com$/) &&
              (c.h = "redirector.googlevideo.com");
            CC(c, "cmo", "pf=" + (d + 1));
            g = c;
          } else g = b.uri;
          a.uri = g;
          a.dispatchEvent(qE("bandaid_fallback_count"));
        } else
          ((f = a.h) == null ? 0 : f.ln) &&
            $C(a.uri) &&
            (a.uri = new oC(aD(a.uri)));
        a.O++;
      }
    },
    GF = function (a) {
      var b = JF(a);
      return new Promise(function (c, d) {
        var e = new XMLHttpRequest();
        a.C = e;
        var f;
        ((f = a.h) == null ? 0 : f.Ec) &&
          e.addEventListener("abort", function () {
            d(new zF());
          });
        var g = 0,
          h = [],
          k = a.l - a.o,
          l = function () {
            if (e.status >= 400) a.F = e.status;
            else {
              var m = g;
              if (b) {
                var p = e.responseText;
                m = new ArrayBuffer(p.length - g);
                for (var q = new Uint8Array(m), r = 0; r < m.byteLength; r++)
                  q[r] = p.charCodeAt(g + r) & 255;
                p = m;
                m = 0;
                a.B && h.push(p);
              } else p = e.response;
              p = IF(a, p, m);
              g += p;
            }
          };
        e.addEventListener("load", function () {
          eo(N.getInstance(), "lvlcl");
          if (e.status >= 400)
            N.getInstance().P("lvlxes", e.status.toString()),
              (a.F = e.status),
              d();
          else {
            var m = b ? e.responseText.length : e.response.byteLength;
            m < k && (a.state = 3);
            l();
            if (a.B && m > 0)
              if (((m = m < k), b)) {
                var p = h.reduce(function (x, E) {
                  return x + E.byteLength;
                }, 0);
                p = new Uint8Array(p);
                var q = 0,
                  r = y(h),
                  t = r.next();
                try {
                  for (; !t.done; t = r.next()) {
                    var v = t.value;
                    p.set(new Uint8Array(v), q);
                    q += v.byteLength;
                  }
                } finally {
                  z(r, t);
                }
                a.A.Kc(p.buffer, a.uri, 0, m);
              } else a.A.Kc(e.response, a.uri, 0, m);
            c();
          }
        });
        e.addEventListener("timeout", function () {
          eo(N.getInstance(), "lvlct");
          a.F = e.status;
          d();
        });
        e.addEventListener("error", function () {
          eo(N.getInstance(), "lvlce");
          a.F = e.status;
          d();
        });
        e.addEventListener("readystatechange", function () {
          if (
            e.readyState === e.HEADERS_RECEIVED &&
            e.getResponseHeader("X-Afma-Gcache-IsGcacheHit") === "true"
          ) {
            var m =
                e.getResponseHeader("X-Afma-Gcache-IsDownloaded") === "true",
              p =
                Number(
                  e.getResponseHeader("X-Afma-Gcache-CachedBytes") || "0"
                ) || 0,
              q;
            (q = a.j) == null ||
              q.dispatchEvent(
                qE("gcache_hit", {
                  mimeType: a.H.mimeType,
                  rangeStart: a.o,
                  Zm: a.l - a.o,
                  Km: m,
                  Jm: p,
                })
              );
          }
        });
        b ? (e.onprogress = l) : e.addEventListener("progress", l);
        e.open("get", a.uri.toString());
        b
          ? e.overrideMimeType &&
            e.overrideMimeType("text/plain; charset=x-user-defined")
          : (e.responseType = "arraybuffer");
        e.send(null);
      });
    },
    IF = function (a, b, c) {
      if (b === null) return 0;
      b = b.slice(c);
      a.o += b.byteLength;
      a.dispatchEvent({ type: "progress", ve: b });
      return b.byteLength;
    },
    JF = function (a) {
      var b, c, d;
      return (
        ((b = a.h) == null ? void 0 : b.on) === !0 ||
        ((c = a.h) == null ? void 0 : c.og) === !0 ||
        ((d = a.h) == null ? void 0 : d.ng) === !0
      );
    };
  AF.prototype.M = function () {
    this.B && this.A.Wa() && this.A.close();
    $D.prototype.M.call(this);
  };
  function KF() {
    return window.ManagedMediaSource || window.MediaSource;
  }
  function LF(a) {
    return (
      a !== null &&
      !!window.ManagedMediaSource &&
      a instanceof window.ManagedMediaSource
    );
  }
  function MF(a) {
    return KF() !== void 0 && KF().isTypeSupported(a);
  }
  function NF(a) {
    return [43, 44, 45].includes(a) && Sc
      ? !1
      : iE[a]
      ? ((a = pE(a)), !!a && MF(a))
      : !1;
  }
  var OF = { Ym: 2e5, Wm: 7e4, gb: 3e5, Tm: 5e3, rn: 5e3, Xm: 6e3 };
  var PF = function (a, b, c, d) {
    $D.call(this, c === void 0 ? null : c);
    var e = this;
    this.o = b;
    this.F = d;
    this.B = this.l = this.h = 0;
    this.A = null;
    this.C = a;
    this.uri = new oC(a.url);
    this.state = 0;
    var f;
    this.H = (f = this.o) == null ? void 0 : f.initialize();
    rt(this, function () {
      qt(e.o);
    });
  };
  w(PF, $D);
  n = PF.prototype;
  n.He = function () {
    return this.h;
  };
  n.Je = function () {
    return this.l;
  };
  n.rc = function () {
    return this.state === 3;
  };
  n.Me = function () {
    return this.state === 0;
  };
  n.Oe = function (a) {
    this.state === 1
      ? ((this.h += a), (this.state = 2))
      : this.state === 0 && ((this.h += a), (this.state = 1), QF(this));
  };
  n.reset = function () {
    this.B = this.state = this.l = this.h = 0;
  };
  var RF = function (a) {
      var b = a.B > 3,
        c = a.j && a.j.readyState >= HTMLMediaElement.HAVE_FUTURE_DATA,
        d = a.l >= a.h || a.state === 3,
        e;
      if (((e = a.F) == null ? 0 : e.Xe) && c) return !d;
      b &&
        (a.A === null && (a.A = 400),
        (c = qE("media_source_error", {
          code:
            a.l > 0
              ? MediaError.MEDIA_ERR_NETWORK
              : MediaError.MEDIA_ERR_SRC_NOT_SUPPORTED,
          message:
            'Response code "' +
            a.A +
            '" with ' +
            a.h +
            " bytes requested and " +
            a.l +
            " bytes loaded",
        })),
        a.dispatchEvent(c));
      return !d && !b;
    },
    QF = function (a) {
      var b, c, d, e, f;
      Ka(function (g) {
        switch (g.j) {
          case 1:
            b = 0;
          case 2:
            c = void 0;
            if ((c = a.F) == null || !c.Xe) {
              g.ia(5);
              break;
            }
            return g.h(
              new Promise(function (h) {
                setTimeout(h, Math.min(1e3, Math.pow(2, b) - 1));
              }),
              5
            );
          case 5:
            return a.state === 2 && (a.state = 1), g.h(SF(a), 7);
          case 7:
            b++,
              (d = DC(a.uri, "range")),
              (e = void 0),
              (e = a.j) == null ||
                e.dispatchEvent(
                  qE("chunk_load_attempted", {
                    Df: b,
                    range: d,
                    mimeType: a.C.mimeType,
                  })
                ),
              RF(a)
                ? g.ia(2)
                : ((f = a.j) == null ||
                    f.dispatchEvent(
                      qE("chunk_loaded", { Df: b, mimeType: a.C.mimeType })
                    ),
                  a.state !== 3 && (a.state = 0),
                  g.B());
        }
      });
    },
    SF = function (a) {
      var b;
      return Ka(function (c) {
        switch (c.j) {
          case 1:
            b = a.l + "-" + (a.h - 1);
            CC(a.uri, "range", b);
            if (!a.o) {
              c.ia(2);
              break;
            }
            return c.h(a.H, 3);
          case 3:
            return c.return(TF(a));
          case 2:
            return c.A(4), c.h(UF(a), 6);
          case 6:
            c.N(0);
            break;
          case 4:
            c.o(), a.B++, c.B();
        }
      });
    },
    TF = function (a) {
      var b, c;
      return Ka(function (d) {
        switch (d.j) {
          case 1:
            return a.o ? d.h(a.o.xc(a.uri), 2) : d.return(Promise.reject());
          case 2:
            b = d.l;
            (c = a.j) == null ||
              c.dispatchEvent(
                qE("chunk_cache_query", {
                  xi: b !== null,
                  mimeType: a.C.mimeType,
                })
              );
            if (b)
              return (
                b.isLastVideoChunk && (a.state = 3), VF(a, b.video), d.return()
              );
            d.A(3);
            return d.h(UF(a), 5);
          case 5:
            d.N(0);
            break;
          case 3:
            d.o(), a.B++, d.B();
        }
      });
    },
    UF = function (a) {
      var b, c, d, e, f, g, h;
      return Ka(function (k) {
        if (k.j == 1)
          return (b = 0), (c = a.h - a.l), k.h(fetch(a.uri.toString()), 2);
        d = k.l;
        if (d.status >= 400)
          return (
            N.getInstance().P("lvlfes", d.status.toString()),
            (a.A = d.status),
            k.return(Promise.reject())
          );
        f = (e = d.body) == null ? void 0 : e.getReader();
        if (!f)
          return (
            eo(N.getInstance(), "lvlmr"),
            (a.A = d.status),
            k.return(Promise.reject())
          );
        g = [];
        h = function () {
          var l, m, p, q, r, t;
          return Ka(function (v) {
            if (v.j == 1) return v.h(f.read(), 2);
            l = v.l;
            m = l.done;
            p = l.value;
            if (m) return (q = b < c), WF(a, g, q), v.return();
            g.push(p);
            b += (r = p) == null ? void 0 : r.length;
            VF(a, (t = p) == null ? void 0 : t.buffer);
            return v.h(h(), 0);
          });
        };
        return k.h(h(), 0);
      });
    },
    WF = function (a, b, c) {
      c && ((a.state = 3), VF(a, new ArrayBuffer(0)));
      var d = new Uint8Array(
          b.reduce(function (h, k) {
            return h + k.length;
          }, 0)
        ),
        e = 0;
      b = y(b);
      var f = b.next();
      try {
        for (; !f.done; f = b.next()) {
          var g = f.value;
          d.set(g, e);
          e += g.length;
        }
      } finally {
        z(b, f);
      }
      a.o && d.buffer.byteLength > 0 && a.o.Kc(d.buffer, a.uri, 0, c);
    },
    VF = function (a, b) {
      b !== null &&
        ((b = b.slice(0)),
        (a.l += b.byteLength),
        a.dispatchEvent({ type: "progress", ve: b }));
    };
  PF.prototype.M = function () {
    var a;
    ((a = this.o) == null ? 0 : a.Wa()) && this.o.close();
    $D.prototype.M.call(this);
  };
  var XF = function (a) {
    this.h = a;
  };
  XF.prototype.sj = function (a, b, c, d) {
    var e;
    return ((e = this.h) == null ? 0 : e.Hm) && c - d >= 3e5
      ? 0
      : c === 0
      ? 1e6
      : b - a < 5e3
      ? 3e5
      : 0;
  };
  var ZF = function (a, b, c, d, e, f) {
    c = c === void 0 ? 0 : c;
    d = d === void 0 ? null : d;
    e = e === void 0 ? null : e;
    f = f === void 0 ? 0 : f;
    S.call(this);
    var g = this;
    this.Na = a;
    this.h = [];
    this.j = !1;
    this.o = function () {
      YF(g);
    };
    this.F = c;
    this.C = d;
    this.l = e;
    this.A = f;
    this.l && this.l.listen("updateend", this.o);
    this.Na || eo(N.getInstance(), "msms_sbf" + b);
    this.B = function () {
      eo(N.getInstance(), "msms_sbe" + b);
    };
    this.Na.addEventListener("updateend", this.o);
    this.Na.addEventListener("error", this.B);
  };
  w(ZF, S);
  ea.Object.defineProperties(ZF.prototype, {
    updating: {
      configurable: !0,
      enumerable: !0,
      get: function () {
        return this.j;
      },
    },
  });
  var YF = function (a) {
    if (!a.Na.updating && a.j) {
      if (a.l && a.C !== null) {
        var b = a.l.Na;
        b = b.buffered.length > 0 ? b.buffered.end(b.buffered.length - 1) : 0;
        var c =
          a.Na.buffered.length > 0
            ? a.Na.buffered.end(a.Na.buffered.length - 1)
            : 0;
        if (!a.C() && c > b - a.F) return;
      }
      a.h.length > 0
        ? ((b = a.h.shift()), a.Na.appendBuffer(b))
        : ((a.j = !1), a.dispatchEvent(new Event("updateend")));
    }
  };
  ZF.prototype.M = function () {
    this.h.length = 0;
    this.j = !1;
    var a;
    (a = this.l) == null || a.Ma("updateend", this.o);
    var b;
    (b = this.Na) == null || b.removeEventListener("updateend", this.o);
    var c;
    (c = this.Na) == null || c.removeEventListener("error", this.B);
    S.prototype.M.call(this);
  };
  var $F = function (a) {
    this.j = a;
    this.h = this.cache = null;
  };
  n = $F.prototype;
  n.initialize = function () {
    var a = this;
    return window.caches.open("CACHE_VIDEO_CHUNK_PERSISTENT_STORAGE").then(
      function (b) {
        a.cache = b;
      },
      function (b) {
        N.getInstance().P("codf", b.message);
      }
    );
  };
  n.Wa = function () {
    return this.cache !== null;
  };
  n.close = function () {
    return Promise.resolve();
  };
  n.xc = function (a) {
    var b = this;
    a = aG(this, a);
    return this.Wa() && a
      ? this.cache.match(a).then(
          function (c) {
            if (!c)
              return N.getInstance().P("cenf", "1"), Promise.resolve(null);
            N.getInstance().P("cef", "1");
            return c.arrayBuffer().then(function (d) {
              var e = eE(b.h),
                f;
              (f = DC(b.h.uri, "range"))
                ? ((f = f.split("-")[1]),
                  (f = !f || isNaN(Number(f)) ? null : Number(f)))
                : (f = null);
              e = e + d.byteLength - 1;
              f = f > e;
              return {
                itag: dE(b.h, "itag"),
                endIndex: e,
                isLastVideoChunk: f,
                video: d,
              };
            });
          },
          function (c) {
            N.getInstance().P("cgvf", c.message);
            return Promise.resolve(null);
          }
        )
      : (N.getInstance().P("cgvf", "1"), Promise.resolve(null));
  };
  n.Kc = function (a, b) {
    b = aG(this, b);
    a = new Response(a);
    this.Wa() && b
      ? this.cache.put(b, a).then(
          function () {
            N.getInstance().P("cavs", "1");
          },
          function (c) {
            N.getInstance().P("cavf", c.message);
          }
        )
      : (N.getInstance().P("cavf", "1"), Promise.resolve());
  };
  var aG = function (a, b) {
    var c;
    a.h = new bE(b, (c = a.j) == null ? void 0 : c.mg);
    b = a.h.getId();
    c = dE(a.h, "itag");
    var d = dE(a.h, "source"),
      e = dE(a.h, "lmt");
    a = dE(a.h, "range");
    if (b && c && d && a)
      return new Request(
        "http://url/videoplayback?id=" +
          b +
          "&itag=" +
          c +
          "&source=" +
          d +
          "&lmt=" +
          e +
          "&range=" +
          a
      );
    N.getInstance().P("civp", "1");
    return null;
  };
  var bG = function (a, b) {
      this.currentTimeSeconds = a;
      this.removedRanges = b;
    },
    gG = function (a, b, c, d, e) {
      d = d === void 0 ? 1 : d;
      e = e === void 0 ? 1e3 : e;
      S.call(this);
      var f = this;
      this.A = a;
      this.h = b;
      this.j = c;
      this.o = [];
      this.H = [];
      this.J = null;
      this.K = 0;
      this.W = !1;
      this.da = 0;
      this.B = [];
      this.F = [];
      this.C = [];
      this.sa = !1;
      this.Qa = null;
      this.va = d;
      this.Y = e;
      this.oa = function () {
        f.sa = !0;
      };
      this.h.addEventListener("ended", this.oa, { once: !0 });
      var g;
      if ((g = this.j) == null ? 0 : g.If) {
        var h = null;
        if (sE(this.j)) {
          var k;
          h = ((k = this.j) == null ? 0 : k.mn) ? EB($F) : EB(rF);
        }
        this.l = this.A.map(function (l) {
          return EB(PF, l, $C(l.url) ? null : h, f.h, f.j);
        });
      } else
        this.l = this.A.map(function (l) {
          return EB(AF, l, f.h, f.j);
        });
      (c == null ? 0 : c.De) &&
        this.l.forEach(function (l) {
          l.listen("bandaid_fallback_count", function (m) {
            f.dispatchEvent(m);
          });
        });
      this.ca = EB(KF());
      this.O = function () {
        cG(f);
      };
      this.T = function () {
        var l;
        if ((l = f.j) == null ? 0 : l.Ec) {
          l = y(f.l);
          var m = l.next();
          try {
            for (; !m.done; m = l.next()) m.value.kh();
          } finally {
            z(l, m);
          }
          dG(f);
        }
        f.h.dispatchEvent(new CustomEvent("mms_start_streaming"));
      };
      this.R = function () {
        var l;
        if ((l = f.j) == null ? 0 : l.Ec) {
          l = y(f.l);
          var m = l.next();
          try {
            for (; !m.done; m = l.next()) m.value.qg();
          } finally {
            z(l, m);
          }
        }
        f.h.dispatchEvent(new CustomEvent("mms_end_streaming"));
      };
      this.ca.addEventListener("sourceopen", this.O);
      LF(this.ca) &&
        (this.ca.addEventListener("startstreaming", this.T),
        this.ca.addEventListener("endstreaming", this.R));
      this.ba = eG(this);
      this.fa = function () {
        fG(f);
      };
      this.h.addEventListener("playbackStalled", this.fa);
    };
  w(gG, S);
  var eG = function (a) {
      for (var b = [], c = 0; c < a.A.length; ++c) b.push(new XF(a.j));
      return b;
    },
    cG = function (a) {
      eo(N.getInstance(), "msms_oso");
      a.h.dispatchEvent(new CustomEvent("media_source_open"));
      if (a.W) hG(a) && iG(a);
      else {
        for (
          var b = { ga: 0 };
          b.ga < a.A.length;
          b = {
            yh: void 0,
            Mb: void 0,
            Md: void 0,
            ga: b.ga,
            hc: void 0,
            Nd: void 0,
            ih: void 0,
          },
            ++b.ga
        ) {
          var c = a.A[b.ga];
          N.getInstance().P("msms_mime" + b.ga, c.mimeType);
          N.getInstance().P("msms_cs" + b.ga, c.gb.toString());
          var d = void 0,
            e = void 0,
            f = void 0;
          if (
            ((d = a.j) == null ? 0 : d.rh) ||
            ((e = a.j) == null ? 0 : e.og) ||
            (((f = a.j) == null ? 0 : f.ng) && OC())
          )
            (d = b.Mb = void 0),
              ((d = a.j) == null ? 0 : d.kn)
                ? b.ga > 0
                  ? ((b.yh = a.l[0]),
                    (d = a.H[0]),
                    (b.Mb = EB(
                      ZF,
                      a.ca.addSourceBuffer(c.mimeType),
                      b.ga,
                      a.va,
                      (function (g) {
                        return function () {
                          return g.yh.rc();
                        };
                      })(b),
                      d,
                      a.Y
                    )))
                  : (b.Mb = EB(
                      ZF,
                      a.ca.addSourceBuffer(c.mimeType),
                      b.ga,
                      0,
                      null,
                      null,
                      a.Y
                    ))
                : (b.Mb = EB(ZF, a.ca.addSourceBuffer(c.mimeType), b.ga)),
              (b.Md = a.l[b.ga]),
              (a.F[b.ga] = (function (g) {
                return function (h) {
                  var k = g.Mb,
                    l = g.Md;
                  h = h.ve;
                  if (h.byteLength !== 0) {
                    k.j = !0;
                    if (k.A > 0)
                      for (var m = 0; m < h.byteLength; m += k.A)
                        k.h.push(h.slice(m, m + k.A));
                    else k.h.push(h);
                    YF(k);
                  }
                  l.rc() && (a.K++, hG(a) && iG(a));
                };
              })(b)),
              b.Md.listen("progress", a.F[b.ga]),
              (a.C[b.ga] = function (g) {
                a.dispatchEvent(g);
              }),
              b.Md.listen("media_source_error", a.C[b.ga]),
              a.o.push(b.Mb.Na),
              a.H.push(b.Mb),
              b.Mb.listen(
                "updateend",
                (function (g) {
                  return function () {
                    a.l[g.ga].Fd() && dG(a);
                  };
                })(b)
              );
          else {
            b.hc = a.ca.addSourceBuffer(c.mimeType);
            if (!b.hc) {
              eo(N.getInstance(), "msms_sbf" + b.ga);
              continue;
            }
            b.Nd = a.l[b.ga];
            c = void 0;
            if ((c = a.j) == null ? 0 : c.If)
              a.B.push([]),
                b.hc.addEventListener(
                  "updateend",
                  (function (g) {
                    return function () {
                      jG(a, g.hc, g.ga);
                    };
                  })(b)
                );
            b.hc.addEventListener(
              "error",
              (function (g) {
                return function () {
                  eo(N.getInstance(), "msms_sbe" + g.ga);
                };
              })(b)
            );
            a.F[b.ga] = (function (g) {
              return function (h) {
                var k = g.hc,
                  l = g.Nd,
                  m = g.ga;
                h = h.ve;
                if (h.byteLength !== 0) {
                  var p;
                  ((p = a.j) == null ? 0 : p.If)
                    ? (a.B[m].push(h), jG(a, k, m))
                    : k.appendBuffer(h);
                }
                l.rc() && (a.K++, hG(a) && iG(a));
              };
            })(b);
            b.Nd.listen("progress", a.F[b.ga]);
            a.C[b.ga] = function (g) {
              a.dispatchEvent(g);
            };
            b.Nd.listen("media_source_error", a.C[b.ga]);
            a.o.push(b.hc);
          }
          LF(a.ca) &&
            ((b.ih = a.o[b.ga]),
            (b.ih.onbufferedchange = (function () {
              return function (g) {
                g.removedRanges.length > 0 &&
                  a.h.dispatchEvent(
                    new CustomEvent("bufferremoved", {
                      detail: new bG(a.h.currentTime, g.removedRanges),
                    })
                  );
              };
            })(b)));
        }
        N.getInstance().P("msms_ns", a.o.length.toString());
        a.W = !0;
        dG(a);
      }
    },
    jG = function (a, b, c) {
      a.B[c].length === 0 && a.l[c].Fd()
        ? dG(a)
        : b.updating ||
          a.B[c].length === 0 ||
          ((a = a.B[c].shift()), b.appendBuffer(a));
    },
    iG = function (a) {
      var b, c, d;
      ((b = a.j) == null ? 0 : b.rh) ||
      ((c = a.j) == null ? 0 : c.og) ||
      (((d = a.j) == null ? 0 : d.ng) && OC())
        ? Promise.all(
            a.H.map(function (e) {
              return new Promise(function (f) {
                e.updating
                  ? e.Zb("updateend", function () {
                      f();
                    })
                  : f();
              });
            })
          ).then(function () {
            a.ca.endOfStream();
          })
        : Promise.all(
            a.o.map(function (e, f) {
              return new Promise(function (g) {
                if (e.updating) {
                  var h = function () {
                    var k;
                    (((k = a.j) == null ? 0 : k.If) &&
                      (e.updating || a.B[f].length > 0)) ||
                      (e.removeEventListener("updateend", h), g());
                  };
                  e.addEventListener("updateend", h);
                } else g();
              });
            })
          ).then(function () {
            a.ca.endOfStream();
          });
    },
    dG = function (a) {
      if (a.W && !hG(a) && a.ca.readyState !== "closed")
        for (var b = 0; b < a.A.length; ++b) {
          var c = a.l[b],
            d = a.o[b];
          d = d.buffered.length === 0 ? 0 : d.buffered.end(0) * 1e3;
          d = a.ba[b].sj(a.da, d, c.He(), c.Je());
          d !== 0 && c.Oe(d);
        }
    },
    hG = function (a) {
      return a.K === a.A.length;
    },
    kG = function (a) {
      a.ca.readyState === "open" && iG(a);
      a.h.currentTime = a.h.duration + 0.01;
    },
    mG = function (a, b) {
      a.da = b;
      dG(a);
      var c;
      if ((c = a.j) == null ? 0 : c.pg)
        if (
          ((b = a.h.currentTime),
          !(
            a.sa ||
            a.h.paused ||
            a.A.length <= 1 ||
            !hG(a) ||
            Math.abs(b - a.h.duration) >= 0.25
          ))
        ) {
          c = y(a.o);
          var d = c.next();
          try {
            for (; !d.done; d = c.next()) {
              var e = d.value,
                f = e.buffered.end(e.buffered.length - 1);
              if (b > f - lG) {
                kG(a);
                break;
              }
            }
          } finally {
            z(c, d);
          }
        }
    };
  gG.prototype.Uc = function () {
    return (this.J = ek(this.ca).toString());
  };
  var fG = function (a) {
      if (
        hG(a) &&
        (a.h.ended || Math.abs(a.h.currentTime - a.h.duration) < 0.25)
      )
        kG(a);
      else {
        var b, c;
        if (
          !(c = a.h.readyState === HTMLMediaElement.HAVE_ENOUGH_DATA) &&
          (c =
            ((b = a.j) == null ? 0 : b.Em) &&
            a.h.readyState === HTMLMediaElement.HAVE_FUTURE_DATA)
        )
          a: {
            b = a.h.currentTime;
            c = a.h.buffered;
            for (var d = 0; d < c.length; d++)
              if (b >= c.start(d) && b < c.end(d)) {
                c = c.end(d) - b >= 1;
                break a;
              }
            c = !1;
          }
        if (c) nG(a);
        else if (hG(a)) {
          a.K = 0;
          b = y(a.l);
          c = b.next();
          try {
            for (; !c.done; c = b.next()) c.value.reset();
          } finally {
            z(b, c);
          }
          dG(a);
        } else if (oG(a) && pG(a)) {
          for (b = a.K = 0; b < a.A.length; b++) a.l[b].reset(), a.o[b].abort();
          dG(a);
        }
      }
    },
    nG = function (a) {
      a.h.playbackRate += 0.01;
      a.h.playbackRate -= 0.01;
    },
    oG = function (a) {
      return a.l.every(function (b) {
        return b.Me() || b.rc();
      });
    },
    pG = function (a) {
      var b;
      return (((b = a.j) == null ? 0 : b.rh) ? a.H : a.o).every(function (c) {
        return !c.updating;
      });
    },
    qG = function (a) {
      a.J && window.URL.revokeObjectURL(a.J);
      a.ca.removeEventListener("sourceopen", a.O);
      a.ca.removeEventListener("startstreaming", a.T);
      a.ca.removeEventListener("endstreaming", a.R);
      var b = y(a.H),
        c = b.next();
      try {
        for (; !c.done; c = b.next()) c.value.dispose();
      } finally {
        z(b, c);
      }
      a.W = !1;
      a.o.length = 0;
      a.H.length = 0;
      a.B.length = 0;
      for (b = a.K = 0; b < a.l.length; ++b)
        (c = a.l[b]),
          a.F[b] && c.Ma("progress", a.F[b]),
          a.C[b] && c.Ma("media_source_error", a.C[b]),
          c.reset();
      a.F.length = 0;
      a.C.length = 0;
      a.ca = EB(KF());
      a.ca.addEventListener("sourceopen", a.O);
      LF(a.ca) &&
        (a.ca.addEventListener("startstreaming", a.T),
        a.ca.addEventListener("endstreaming", a.R));
      return a.Uc();
    };
  gG.prototype.M = function () {
    this.J && window.URL.revokeObjectURL(this.J);
    var a = y(this.H),
      b = a.next();
    try {
      for (; !b.done; b = a.next()) b.value.dispose();
    } finally {
      z(a, b);
    }
    a = y(this.l);
    b = a.next();
    try {
      for (; !b.done; b = a.next()) b.value.dispose();
    } finally {
      z(a, b);
    }
    this.ca.removeEventListener("sourceopen", this.O);
    this.ca.removeEventListener("startstreaming", this.T);
    this.ca.removeEventListener("endstreaming", this.R);
    this.h.removeEventListener("ended", this.oa);
    this.h.removeEventListener("playbackStalled", this.fa);
    S.prototype.M.call(this);
  };
  gG.prototype.he = function (a) {
    this.ba
      .filter(function () {
        return !1;
      })
      .map(function (b) {
        return b;
      })
      .forEach(function (b) {
        b.h = xa({}, OF, b.h, a);
      });
  };
  var lG = 1 / 30;
  var rG = RegExp(
      "/pagead/conversion|/pagead/adview|/pagead/gen_204|/activeview?|csi.gstatic.com/csi|google.com/pagead/xsul|google.com/ads/measurement/l|googleads.g.doubleclick.net/pagead/ide_cookie|googleads.g.doubleclick.net/xbbe/pixel"
    ),
    sG = RegExp("outstream.min.js"),
    tG = RegExp("outstream.min.css"),
    uG = RegExp("fonts.gstatic.com"),
    vG = RegExp(
      "googlevideo.com/videoplayback|c.2mdn.net/videoplayback|gcdn.2mdn.net/videoplayback"
    ),
    wG = RegExp("custom.elements.min.js");
  function xG(a, b) {
    var c = 0,
      d = 0,
      e = 0,
      f = 0,
      g = 0,
      h = 0,
      k = 0,
      l = !1,
      m = !1;
    if (
      typeof $a("performance.getEntriesByType", C) === "function" &&
      "transferSize" in C.PerformanceResourceTiming.prototype
    ) {
      var p = C.performance.getEntriesByType("resource");
      p = y(p);
      var q = p.next();
      try {
        for (; !q.done; q = p.next()) {
          var r = q.value;
          rG.test(r.name) ||
            ((f += 1),
            r.transferSize
              ? ((c += r.transferSize),
                r.encodedBodySize &&
                  r.transferSize < r.encodedBodySize &&
                  ((h += 1),
                  (e += r.encodedBodySize),
                  sG.test(r.name) && (l = !0),
                  tG.test(r.name) && (m = !0)),
                vG.test(r.name) && (d += r.transferSize))
              : r.transferSize === 0 && r.encodedBodySize === 0
              ? wG.test(r.name)
                ? (c += 6686)
                : uG.test(r.name) || (k += 1)
              : ((g += 1),
                (e += r.encodedBodySize),
                sG.test(r.name) && (l = !0),
                tG.test(r.name) && (m = !0)));
        }
      } finally {
        z(p, q);
      }
      r = 0;
      if (a.duration) {
        for (p = 0; p < a.buffered.length; p++)
          r += a.buffered.end(p) - a.buffered.start(p);
        r = Math.min(r, a.duration);
      }
      p = N.getInstance();
      a = {
        event_name: b,
        asset_bytes: c,
        video_bytes: d,
        cached_data_bytes: e,
        js_cached: l,
        css_cached: m,
        num_assets: f,
        num_assets_cached: g,
        num_assets_cache_validated: h,
        num_assets_unmeasurable: k,
        video_played_seconds: a.currentTime.toFixed(2),
        video_muted: a.muted,
        video_seconds_loaded: r.toFixed(2),
      };
      for (var t in a)
        a[t] =
          typeof a[t] === "object"
            ? encodeURIComponent(JSON.stringify(a[t]))
            : encodeURIComponent(String(a[t]));
      p.h.Vf(a);
    } else N.getInstance().P("error", "reporting_timing_not_supported");
  }
  var yG = function (a, b, c, d) {
    d = d === void 0 ? null : d;
    this.url = a;
    this.mimeType = b;
    this.gb = c;
    this.h = d;
  };
  function zG(a) {
    var b = N.getInstance(),
      c = a.getVideoPlaybackQuality && a.getVideoPlaybackQuality();
    c
      ? ((a = a.currentTime),
        b.P("vqdf", String(c.droppedVideoFrames)),
        b.P("vqtf", String(c.totalVideoFrames)),
        b.P("vqfr", String(Math.round(c.totalVideoFrames / a))))
      : b.P("vqu", "1");
  }
  function AG(a) {
    this.h = a;
  }
  AG.prototype.toString = function () {
    return this.h;
  };
  var BG = new AG("video_mute"),
    CG = new AG("video_caption_visibility");
  var DG = function (a) {
    a = a === void 0 ? null : a;
    R.call(this);
    this.j = new zD(this);
    tt(this, this.j);
    this.h = a;
  };
  w(DG, R);
  var EG = function (a, b, c) {
    var d = a.h;
    d &&
      (d.subscribe(CG, b, c),
      rt(a, function () {
        d.unsubscribe(CG, b, c);
      }));
  };
  DG.prototype.unsubscribe = function (a, b, c) {
    return this.h ? this.h.unsubscribe(a, b, c) : !1;
  };
  function FG(a) {
    R.call(this);
    this.D = 1;
    this.l = [];
    this.o = 0;
    this.h = [];
    this.j = {};
    this.C = !!a;
  }
  ob(FG, R);
  FG.prototype.subscribe = function (a, b, c) {
    var d = this.j[a];
    d || (d = this.j[a] = []);
    var e = this.D;
    this.h[e] = a;
    this.h[e + 1] = b;
    this.h[e + 2] = c;
    this.D = e + 3;
    d.push(e);
    return e;
  };
  FG.prototype.unsubscribe = function (a, b, c) {
    if ((a = this.j[a])) {
      var d = this.h;
      if (
        (a = a.find(function (e) {
          return d[e + 1] == b && d[e + 2] == c;
        }))
      )
        return this.A(a);
    }
    return !1;
  };
  FG.prototype.A = function (a) {
    var b = this.h[a];
    if (b) {
      var c = this.j[b];
      this.o != 0
        ? (this.l.push(a), (this.h[a + 1] = function () {}))
        : (c && lc(c, a),
          delete this.h[a],
          delete this.h[a + 1],
          delete this.h[a + 2]);
    }
    return !!b;
  };
  FG.prototype.B = function (a, b) {
    var c = this.j[a];
    if (c) {
      var d = Array(arguments.length - 1),
        e = arguments.length,
        f;
      for (f = 1; f < e; f++) d[f - 1] = arguments[f];
      if (this.C)
        for (f = 0; f < c.length; f++)
          (e = c[f]), GG(this.h[e + 1], this.h[e + 2], d);
      else {
        this.o++;
        try {
          for (f = 0, e = c.length; f < e && !this.Va(); f++) {
            var g = c[f];
            this.h[g + 1].apply(this.h[g + 2], d);
          }
        } finally {
          if ((this.o--, this.l.length > 0 && this.o == 0))
            for (; (c = this.l.pop()); ) this.A(c);
        }
      }
    }
  };
  var GG = function (a, b, c) {
    Fy(function () {
      a.apply(b, c);
    });
  };
  FG.prototype.clear = function (a) {
    if (a) {
      var b = this.j[a];
      b && (b.forEach(this.A, this), delete this.j[a]);
    } else (this.h.length = 0), (this.j = {});
  };
  FG.prototype.M = function () {
    FG.yb.M.call(this);
    this.clear();
    this.l.length = 0;
  };
  function HG(a) {
    R.call(this);
    this.h = new FG(a);
    tt(this, this.h);
  }
  ob(HG, R);
  HG.prototype.subscribe = function (a, b, c) {
    return this.h.subscribe(a.toString(), b, c);
  };
  HG.prototype.unsubscribe = function (a, b, c) {
    return this.h.unsubscribe(a.toString(), b, c);
  };
  HG.prototype.clear = function (a) {
    this.h.clear(a !== void 0 ? a.toString() : void 0);
  };
  var IG = function (a, b) {
    DG.call(this, b);
    EG(
      this,
      function (c) {
        c ? (a.h.mode = "showing") : a.Ib();
      },
      this
    );
  };
  w(IG, DG);
  var JG = function () {
    S.call(this);
    this.element = null;
    this.j = new zD(this);
    tt(this, this.j);
  };
  w(JG, S);
  var LG = function (a, b, c) {
    c = c === void 0 ? !0 : c;
    JG.call(this);
    a.setAttribute("crossorigin", "anonymous");
    var d = rl("TRACK");
    d.setAttribute("kind", "captions");
    d.setAttribute("src", b);
    d.setAttribute("default", "");
    a.appendChild(d);
    this.h = a.textTracks[0];
    KG(this);
    c ? (this.h.mode = "showing") : this.Ib();
  };
  w(LG, JG);
  var KG = function (a) {
    var b = a.h;
    b.addEventListener(
      "cuechange",
      function () {
        for (var c = b.cues, d = 0; d < c.length; d++) {
          var e = c[d];
          e.align = "center";
          e.position = "auto";
        }
      },
      { once: !0 }
    );
  };
  LG.prototype.Ib = function () {
    this.h.mode = "hidden";
  };
  function MG(a, b) {
    if (typeof ReportingObserver === "undefined")
      return { ub: null, destroy: function () {} };
    var c = function (f) {
        f = y(f);
        var g = f.next();
        try {
          for (; !g.done; g = f.next()) {
            var h = g.value;
            a(h) && b(h);
          }
        } finally {
          z(f, g);
        }
      },
      d = new ReportingObserver(c, { buffered: !0 }),
      e = function () {
        c(d.takeRecords(), d);
        d.disconnect();
      };
    C.addEventListener("pagehide", e);
    d.observe();
    return {
      ub: d,
      destroy: function () {
        d.disconnect();
        C.removeEventListener("pagehide", e);
      },
    };
  }
  function NG(a) {
    a = a === void 0 ? null : a;
    return MG(
      function (b) {
        var c;
        return ((c = b.body) == null ? void 0 : c.id) === "HeavyAdIntervention";
      },
      function (b) {
        var c = b.body.message,
          d = N.getInstance();
        d.P("ham", c);
        c.includes("CPU")
          ? d.P("hacpu", "true")
          : c.includes("network") && d.P("habytes", "true");
        a && a(b);
      }
    );
  }
  var OG =
      "autoplay controls crossorigin demuxedaudiosrc demuxedvideosrc loop muted playsinline poster preload src webkit-playsinline x-webkit-airplay".split(
        " "
      ),
    PG =
      "autoplay buffered controls crossOrigin currentSrc currentTime defaultMuted defaultPlaybackRate disablePictureInPicture disableRemotePlayback duration ended loop muted networkState onerror onwaitingforkey paused played playsinline poster preload preservesPitch mozPreservesPitch webkitPreservesPitch readyState seekable videoWidth videoHeight volume textTracks canPlayType captureStream getVideoPlaybackQuality load pause play requestPictureInPicture setSinkId oncanplay oncanplaythrough onload onplay onpause onended onfullscreenchange onfullscreenerror addEventListener dispatchEvent removeEventListener requestFullscreen".split(
        " "
      ),
    QG = { childList: !0 },
    RG = !RegExp("^\\s*class\\s*\\{\\s*\\}\\s*$").test(
      function () {}.toString()
    ),
    SG = HTMLElement;
  RG &&
    ((SG = function () {
      var a = Object.getPrototypeOf(this).constructor;
      return C.Reflect.construct(HTMLElement, [], a);
    }),
    Object.setPrototypeOf(SG, HTMLElement),
    Object.setPrototypeOf(SG.prototype, HTMLElement.prototype));
  var TG = function (a) {
      if (a !== null) {
        a = y(a);
        var b = a.next();
        try {
          for (; !b.done; b = a.next()) {
            var c = b.value;
            if (c.nodeName === "TRACK".toString()) return c;
          }
        } finally {
          z(a, b);
        }
      }
      return null;
    },
    UG = function (a, b) {
      b = b === void 0 ? "" : b;
      this.code = a;
      this.message = b;
    },
    VG = function (a) {
      UG.call(
        this,
        MediaError.MEDIA_ERR_SRC_NOT_SUPPORTED,
        a === void 0 ? "" : a
      );
    };
  w(VG, UG);
  var ZG = function (a, b, c) {
    b = b === void 0 ? !1 : b;
    c = c === void 0 ? null : c;
    var d = SG.call(this) || this;
    d.Ja = c;
    N.getInstance().P("ulv", "1");
    d.pk = b;
    d.ka = null;
    d.Ug = null;
    d.Wf = null;
    d.L = rl("VIDEO");
    WG(d);
    d.Ef = a || new HG();
    XG(d);
    d.ud = null;
    YG(d);
    d.attachShadow({ mode: "open" });
    d.shadowRoot.appendChild(d.L);
    NG(function () {
      N.getInstance().P("has", d.src || d.Cb);
      N.getInstance().P("hat", String(d.L.currentTime));
    });
    d.de = !1;
    d.Xg = !1;
    d.Bc = !1;
    d.gg = 0;
    d.Cc = null;
    d.dc = null;
    d.fc = !1;
    d.fd = null;
    d.bf = function () {};
    d.ne = null;
    d.qk = !1;
    d.hh = !1;
    d.kj = !1;
    d.fh = !1;
    d.Gm = null;
    d.Pc = null;
    return d;
  };
  w(ZG, SG);
  ea.Object.defineProperties(ZG.prototype, {
    Vb: {
      configurable: !0,
      enumerable: !0,
      set: function (a) {
        this.setAttribute("demuxedaudiosrc", a);
      },
      get: function () {
        return this.getAttribute("demuxedaudiosrc");
      },
    },
    Cb: {
      configurable: !0,
      enumerable: !0,
      set: function (a) {
        this.setAttribute("demuxedvideosrc", a);
      },
      get: function () {
        return this.getAttribute("demuxedvideosrc");
      },
    },
    src: {
      configurable: !0,
      enumerable: !0,
      set: function (a) {
        this.setAttribute("src", a);
      },
      get: function () {
        return this.getAttribute("src");
      },
    },
  });
  var $G = function (a) {
    a.L.load();
    var b;
    ((b = a.Ja) == null ? 0 : b.Dm) &&
      a.L.dispatchEvent(new Event("canplaythrough"));
  };
  ZG.prototype.attributeChangedCallback = function (a, b, c) {
    switch (a) {
      case "src":
        aH(this, c);
        break;
      case "demuxedaudiosrc":
      case "demuxedvideosrc":
        bH(this);
        break;
      case "muted":
        this.L[a] = c === "" ? !0 : !!c;
        cH(this, a, c);
        break;
      default:
        cH(this, a, c);
    }
  };
  ZG.prototype.he = function (a) {
    this.Pc = a;
    var b;
    (b = this.ka) == null || b.he(a);
  };
  var dH = function () {
      navigator.audioSession &&
        navigator.audioSession.type !== "ambient" &&
        (navigator.audioSession.type = "ambient");
    },
    cH = function (a, b, c) {
      c !== a.L.getAttribute(b) &&
        (c === null ? a.L.removeAttribute(b) : a.L.setAttribute(b, c));
    },
    fH = function (a) {
      eH(a);
      a.dc = null;
      a.Bc = !1;
      a.fc = !1;
      a.ka &&
        (a.L.removeEventListener("timeupdate", a.fd),
        a.L.removeEventListener("playing", a.bf),
        a.ka.dispose(),
        (a.ka = null));
    },
    eH = function (a) {
      a.Cc && (a.L.removeEventListener("loadedmetadata", a.Cc), (a.Cc = null));
    },
    gH = function (a) {
      if (a.ka) {
        a.L.dispatchEvent(qE("media_source_reconstruct"));
        a.Bc = !1;
        a.Cc = function () {
          eH(a);
          a.dc !== null && ((a.L.currentTime = a.dc), (a.dc = null));
          a.fc && a.L.play();
        };
        a.L.addEventListener("loadedmetadata", a.Cc, { once: !0 });
        var b = qG(a.ka);
        cH(a, "src", b);
      }
    },
    hH = function (a, b) {
      a.Wf = b;
      a.L.dispatchEvent(new Event("error"));
    },
    WG = function (a) {
      iH(a);
      jH(a);
      var b;
      ((b = a.Ja) == null ? 0 : b.Ee) &&
        a.L.addEventListener("ended", function () {
          a.fc = !1;
        });
      a.L.addEventListener("loadedmetadata", function () {
        a.ne = pD(a);
        a.ne.then(function (d) {
          var e = a.L;
          var f = new Rk(d.width, d.height);
          d = a.L.videoWidth;
          var g = a.L.videoHeight,
            h = f.width,
            k = f.height;
          d > 0 && g > 0 && h > 0 && k > 0
            ? ((f = f.width / f.height),
              (d /= g),
              (d =
                Math.min(d, f) / Math.max(d, f) >= 0.97 ? "cover" : "contain"))
            : (d = null);
          d !== null && El(e, { "object-fit": d });
        });
      });
      a.L.addEventListener("playing", function () {
        a.Xg || (xG(a.L, "first_play"), (a.Xg = !0));
      });
      a.L.addEventListener("pause", function () {
        a.de || (xG(a.L, "first_pause"), zG(a.L), (a.de = !0));
      });
      jy(C, "pagehide", function () {
        a.de || (xG(a.L, "first_pause"), zG(a.L), (a.de = !0));
      });
      a.L.addEventListener("stalled", function () {
        N.getInstance().P("ves", "1");
      });
      EB(rD, a.L).listen("playbackStalled", function () {
        N.getInstance().P("pbs", "1");
        var d;
        if ((d = a.Ja) == null ? 0 : d.pg) {
          var e;
          (e = a.ka) == null || fG(e);
        }
      });
      a.L.addEventListener("media_source_error", function (d) {
        fH(a);
        d = d.detail;
        hH(a, new UG(d.code, d.message));
      });
      var c;
      ((c = a.Ja) == null ? 0 : c.Ee) &&
        a.L.addEventListener("error", function (d) {
          eH(a);
          var e = a.L.error,
            f;
          !e ||
          (e.code !== MediaError.MEDIA_ERR_DECODE &&
            ((f = e.message) == null ||
              !f.includes("Media failed to decode"))) ||
          !a.ka ||
          a.gg >= 10
            ? ((a.Bc = !1), (a.dc = null), (a.fc = !1))
            : (d.stopImmediatePropagation(),
              a.gg++,
              a.dc === null && (a.dc = a.L.currentTime),
              (a.Bc = !0),
              setTimeout(function () {
                a.Bc && a.fc && gH(a);
              }, 0));
        });
      kH(a);
    },
    YG = function (a) {
      var b = TG(a.childNodes);
      b && lH(a, b);
      a.ud === null && mH(a);
    },
    mH = function (a) {
      if (C.MutationObserver) {
        var b = new MutationObserver(function (c) {
          c = y(c);
          var d = c.next();
          try {
            for (; !d.done; d = c.next()) {
              var e = d.value;
              if (e.type === "childList") {
                var f = TG(e.addedNodes);
                if (f) {
                  lH(a, f);
                  b.disconnect();
                  break;
                }
              }
            }
          } finally {
            z(c, d);
          }
        });
        b.observe(a, QG);
      }
    },
    XG = function (a) {
      a.L.addEventListener("volumechange", function () {
        a.Ef.h.B(BG.toString(), a.L.muted);
        a.pk || a.Ef.h.B(CG.toString(), a.L.muted);
      });
    },
    lH = function (a, b) {
      if (a.ud === null && b.hasAttribute("src")) {
        var c = b.getAttribute("src");
        a.ud = new LG(a.L, c, b.hasAttribute("default"));
        new IG(a.ud, a.Ef);
        c.includes("kind=asr") && N.getInstance().P("act", "1");
      }
    },
    aH = function (a, b) {
      if (b !== a.Ug) {
        a.Ug = b;
        a.qk && b && ZC(b) && (b = aD(b));
        var c = b ? oE(b) : null,
          d = !!c && NF(c);
        N.getInstance().P("umsem", d ? "1" : "0");
        if (d) {
          c = EB(yG, b, pE(c), gE[c] * 1e3, null);
          a.ka = EB(gG, [c], a.L, a.Ja);
          a.Pc && a.ka.he(a.Pc);
          a.ka.listen("media_source_error", function (f) {
            f = qE("media_source_error", f.detail);
            a.L.dispatchEvent(f);
          });
          var e;
          ((e = a.Ja) == null ? 0 : e.De) &&
            a.ka.listen("bandaid_fallback_count", function () {
              a.dispatchEvent(qE("bandaid_fallback_count"));
            });
          a.fd = function () {
            return mG(a.ka, a.L.currentTime * 1e3);
          };
          a.L.addEventListener("timeupdate", a.fd);
          LF(a.ka.ca) && (cH(a, "disableRemotePlayback", "true"), dH());
          cH(a, "src", a.ka.Uc());
        } else fH(a), cH(a, "src", b);
        a.hh || $G(a);
        b && a.L.dispatchEvent(new Event("loadstart"));
      }
    },
    bH = function (a) {
      a.src &&
        hH(
          a,
          new UG(
            MediaError.MEDIA_ERR_ABORTED,
            "Setting demuxed src after src is already set."
          )
        );
      if (!a.Vb && !a.Cb && a.ka) fH(a), cH(a, "src", null), $G(a);
      else if (a.Vb && a.Cb) {
        a.L.dispatchEvent(new Event("loadstart"));
        var b = oE(ZC(a.Cb) ? aD(a.Cb) : a.Cb),
          c = oE(ZC(a.Vb) ? aD(a.Vb) : a.Vb);
        if (b && NF(b))
          if (c && NF(c)) {
            var d = !!b && NF(b) && !!c && NF(c);
            N.getInstance().P("umsed", d ? "1" : "0");
            b = EB(yG, a.Cb, pE(b), -1, null);
            c = EB(yG, a.Vb, pE(c), -1, null);
            var e;
            d = ((e = a.Ja) == null ? 0 : e.nn) ? [b] : [b, c];
            a.ka = EB(gG, d, a.L, a.Ja);
            a.Pc && a.ka.he(a.Pc);
            a.ka.listen("media_source_error", function (k) {
              k = qE("media_source_error", k.detail);
              a.L.dispatchEvent(k);
            });
            var f;
            ((f = a.Ja) == null ? 0 : f.De) &&
              a.ka.listen("bandaid_fallback_count", function () {
                a.dispatchEvent(qE("bandaid_fallback_count"));
              });
            a.fd = function () {
              return mG(a.ka, a.L.currentTime * 1e3);
            };
            a.L.addEventListener("timeupdate", a.fd);
            var g, h;
            (g = a.Ja) == null ||
              !g.pg ||
              ((h = a.Ja) != null && h.Cm) ||
              ((a.bf = function () {
                nG(a.ka);
              }),
              a.L.addEventListener("playing", a.bf));
            LF(a.ka.ca) && (cH(a, "disableRemotePlayback", "true"), dH());
            cH(a, "src", a.ka.Uc());
            a.hh || $G(a);
          } else hH(a, new VG('Audio itag "' + c + '" not supported.'));
        else hH(a, new VG('Video itag "' + b + '" not supported.'));
      }
    },
    iH = function (a) {
      var b = y(PG),
        c = b.next();
      try {
        for (
          var d = {};
          !c.done;
          d = { Sg: void 0, Qg: void 0, ab: void 0, getValue: void 0 },
            c = b.next()
        )
          (d.ab = c.value),
            d.ab in a.L &&
              (d.ab === "play"
                ? ((d.Sg = function () {
                    var e;
                    if ((e = a.Ja) == null ? 0 : e.Ee) {
                      a.fc = !0;
                      if (a.Bc) return gH(a), Promise.resolve();
                      if (a.Cc) return Promise.resolve();
                    }
                    return a.kj ? ((a.fh = !0), Promise.resolve()) : a.L.play();
                  }),
                  Object.defineProperty(a, "play", {
                    set: function (e) {
                      a.L.play = e;
                    },
                    get: (function (e) {
                      return function () {
                        return e.Sg;
                      };
                    })(d),
                  }))
                : d.ab === "pause"
                ? ((d.Qg = function () {
                    var e;
                    if ((e = a.Ja) == null ? 0 : e.Ee) a.fc = !1;
                    a.fh = !1;
                    a.L.pause();
                  }),
                  Object.defineProperty(a, "pause", {
                    set: function (e) {
                      a.L.pause = e;
                    },
                    get: (function (e) {
                      return function () {
                        return e.Qg;
                      };
                    })(d),
                  }))
                : typeof a.L[d.ab] === "function"
                ? ((d.getValue = a.L[d.ab].bind(a.L)),
                  Object.defineProperty(a, d.ab, {
                    set: (function (e) {
                      return function (f) {
                        a.L[e.ab] = f;
                      };
                    })(d),
                    get: (function (e) {
                      return function () {
                        return e.getValue;
                      };
                    })(d),
                  }))
                : Object.defineProperty(a, d.ab, {
                    set: (function (e) {
                      return function (f) {
                        a.L[e.ab] = f;
                      };
                    })(d),
                    get: (function (e) {
                      return function () {
                        return a.L[e.ab];
                      };
                    })(d),
                  }));
      } finally {
        z(b, c);
      }
    },
    jH = function (a) {
      Object.defineProperty(a, "error", {
        set: function () {},
        get: function () {
          return a.L.error ? a.L.error : a.Wf;
        },
      });
    },
    kH = function (a) {
      a.L.style.width = Nl();
      a.L.style.height = Nl();
    };
  ZG.prototype.disconnectedCallback = function () {
    this.ne && qD(this.ne);
    SG.prototype.disconnectedCallback &&
      SG.prototype.disconnectedCallback.call(this);
  };
  ea.Object.defineProperties(ZG, {
    observedAttributes: {
      configurable: !0,
      enumerable: !0,
      get: function () {
        return OG;
      },
    },
  });
  C.customElements &&
    (C.customElements.get("lima-video") ||
      C.customElements.define("lima-video", ZG));
  var nH = function (a, b, c, d) {
    XD.call(
      this,
      a,
      b === void 0 ? !1 : b,
      c === void 0 ? !1 : c,
      d === void 0 ? !1 : d
    );
  };
  w(nH, XD);
  nH.prototype.unload = function () {
    this.h.removeAttribute("demuxedVideoSrc");
    this.h.removeAttribute("demuxedAudioSrc");
    XD.prototype.unload.call(this);
  };
  var oH = function (a) {
      this.h = a;
      this.o = "";
      this.l = -1;
      this.j = null;
      this.A = !1;
    },
    qH = function (a, b) {
      if (a.l >= 0) {
        var c = b == null ? function () {} : b,
          d = function () {
            pH(a, c);
            a.h.removeEventListener("loadedmetadata", d, !1);
          };
        a.h.addEventListener("loadedmetadata", d, !1);
        a.h.src = a.o;
        a.j !== null && a.h.setAttribute("crossOrigin", a.j);
        a.h.load();
      } else b != null && b();
    },
    pH = function (a, b) {
      var c = a.h.seekable.length > 0;
      a.A
        ? c
          ? ((a.h.currentTime = a.l), rH(a), b())
          : setTimeout(function () {
              return void pH(a, b);
            }, 100)
        : (rH(a), b());
    },
    rH = function (a) {
      a.l = -1;
      a.o = "";
      a.A = !1;
      a.j = null;
    };
  var sH = function (a, b, c, d) {
    nH.call(
      this,
      a,
      b === void 0 ? !1 : b,
      c === void 0 ? !1 : c,
      d === void 0 ? !1 : d
    );
    this.Ta = new oH(a);
  };
  w(sH, nH);
  sH.prototype.sa = function () {
    var a = this.Ta;
    a.o = a.h.currentSrc;
    a.A = a.h.seekable.length > 0;
    a.j = a.h.getAttribute("crossOrigin");
    a.l = a.h.ended ? -1 : a.h.currentTime;
  };
  sH.prototype.T = function (a) {
    qH(this.Ta, a);
  };
  sH.prototype.nf = function (a, b) {
    var c = this.h;
    b &&
      b > 0 &&
      ((c.style.transition = "all " + b + "ms"),
      c.addEventListener(
        "transitionend",
        function () {
          c.style.transition = "";
        },
        { once: !0 }
      ));
    c.style.left = String(a.left) + "px";
    c.style.top = String(a.top) + "px";
    c.style.width = String(a.width) + "px";
    c.style.height = String(a.height) + "px";
  };
  sH.prototype.qf = function (a) {
    var b = this.h;
    a &&
      a > 0 &&
      ((b.style.transition = "all " + a + "ms"),
      b.addEventListener(
        "transitionend",
        function () {
          b.style.transition = "";
        },
        { once: !0 }
      ));
    b.style.width = "100%";
    b.style.height = "100%";
    b.style.top = "0";
    b.style.bottom = "0";
    b.style.left = "0";
    b.style.right = "0";
  };
  var tH = function () {};
  function uH() {
    var a = EB(rF);
    a.initialize().then(function () {
      var b = qE("initialized");
      a.dispatchEvent(b);
    });
    return a;
  }
  var wH = function (a, b, c, d, e) {
    R.call(this);
    this.F = a;
    this.j = c;
    this.o = e;
    this.Y = this.R = this.fb = this.C = this.l = this.Ta = 0;
    this.B = [];
    this.K = !1;
    this.ba = this.fa = this.da = null;
    this.oa = !1;
    this.ob = this.J = this.A = this.sa = this.va = null;
    this.isLastVideoChunk = !1;
    this.H = new oC(b.url);
    this.gb = b.gb;
    this.za = d;
    (this.O = b.h) || this.H.l.remove("alr");
    N.getInstance().P("sl_dv" + this.o, (this.O !== null).toString());
    this.T = !this.O;
    this.h = new XMLHttpRequest();
    this.W = 0.1;
    if ((this.D = sE() && !$C(this.H))) (this.A = uH()), tt(this, this.A);
    vH(this);
  };
  w(wH, R);
  var xH = function (a, b) {
      b = qE("media_source_error", b);
      a.F.dispatchEvent(b);
    },
    yH = function (a, b) {
      xH(a, {
        code:
          a.l > 1
            ? MediaError.MEDIA_ERR_NETWORK
            : MediaError.MEDIA_ERR_SRC_NOT_SUPPORTED,
        message: b,
      });
    },
    vH = function (a) {
      a.da = function () {
        zH(a);
        if (a.T) {
          var b = a.h.responseText;
          a.K = !b || b.length < a.gb;
          a.R = 0;
          eo(N.getInstance(), "sl_cc" + a.o + "_" + a.l);
          a.C++;
          AH(a);
        }
      };
      a.fa = function () {
        zH(a);
      };
      a.ba = function () {
        eo(N.getInstance(), "sl_ec" + a.o + "_" + a.l);
        yH(a, "Failed to load chunk " + a.l + " for stream " + a.o);
      };
      a.h.addEventListener("load", a.da);
      a.h.addEventListener("progress", a.fa);
      a.h.addEventListener("error", a.ba);
      a.j.addEventListener("updateend", function () {
        a.j.buffered.length &&
          ((a.fb = a.j.buffered.end(0)),
          a.D
            ? a.isLastVideoChunk &&
              !a.j.updating &&
              a.l === a.C &&
              (eo(N.getInstance(), "sl_lc" + a.o), a.za())
            : a.K &&
              !a.j.updating &&
              a.l === a.C &&
              (eo(N.getInstance(), "sl_lc" + a.o), a.za()));
        !a.oa &&
          a.F.buffered.length > 1 &&
          (N.getInstance().P("dbr", "1"), (a.oa = !0));
      });
      a.j.addEventListener("update", function () {
        a.B.length && !a.j.updating && a.j.appendBuffer(a.B.shift());
      });
      a.j.addEventListener("error", function () {
        eo(N.getInstance(), "msb_err" + a.o);
        xH(a, {
          code: MediaError.MEDIA_ERR_DECODE,
          message: "Error on SourceBuffer " + a.o,
        });
      });
      a.D
        ? (a.A.Wa()
            ? BH(a)
            : (a.va = jy(a.A, "initialized", function () {
                BH(a);
              })),
          (a.sa = jy(a.A, "get_video_succeeded", function () {
            AH(a);
          })))
        : BH(a);
    },
    DH = function (a) {
      eo(N.getInstance(), "sl_rc" + a.o + "_" + a.l);
      var b = CH(a);
      a.h.open("get", b);
      a.h.overrideMimeType("text/plain; charset=x-user-defined");
      a.h.send(null);
      a.D && ((a.J = null), (a.ob = b));
    },
    zH = function (a) {
      if (a.h.status >= 400)
        yH(
          a,
          'Response code "' +
            a.h.status +
            '" on loading chunk ' +
            a.l +
            " for stream " +
            a.o
        );
      else {
        if (!a.T) {
          var b = a.h.getResponseHeader("content-type");
          if (b && b.indexOf("text/plain") >= 0) {
            a.h.readyState === XMLHttpRequest.DONE &&
              ((a.H = new oC(a.h.response)),
              (a.l = 0),
              (a.C = 0),
              a.Ta++,
              BH(a));
            return;
          }
          a.T = !0;
          eo(N.getInstance(), "sl_redc" + a.o);
          N.getInstance().P("sl_tr" + a.o, a.Ta.toString());
        }
        a.H.l.remove("alr");
        if (
          a.h.readyState === XMLHttpRequest.LOADING ||
          a.h.readyState === XMLHttpRequest.DONE
        )
          (b = EH(a, a.R)),
            (a.R = a.h.response.length),
            (a.Y += b.byteLength),
            FH(a, b);
        if (
          a.D &&
          a.h.readyState === XMLHttpRequest.DONE &&
          ((b = EH(a, 0)), b.byteLength > 0)
        ) {
          var c = a.h.responseText;
          a.isLastVideoChunk = !c || c.length < a.gb;
          a.A.Kc(b, new oC(a.ob), 0, a.isLastVideoChunk);
        }
      }
    },
    FH = function (a, b) {
      b.byteLength > 0 &&
        (a.j.updating || a.B.length ? a.B.push(b) : a.j.appendBuffer(b));
    },
    EH = function (a, b) {
      a = a.h.response;
      for (var c = new Uint8Array(a.length - b), d = 0; d < c.length; d++)
        c[d] = a.charCodeAt(d + b) & 255;
      return c.buffer;
    },
    AH = function (a) {
      var b = dD;
      b !== -1 && b < a.Y + a.gb
        ? (a.F.pause(), (dD = -1), (b = !1))
        : ((b = a.C === a.l && !a.j.updating && !a.B.length),
          (b = a.D
            ? !a.isLastVideoChunk && b && a.F.currentTime >= a.W
            : !a.K && b && a.F.currentTime >= a.W));
      b && ((a.W = a.fb + 0.1), BH(a));
    },
    CH = function (a) {
      var b = a.D && a.J ? a.J + 1 : a.l * a.gb;
      return CC(a.H, "range", b + "-" + (b + a.gb - 1)).toString();
    },
    BH = function (a) {
      if (a.D) {
        var b = new oC(CH(a));
        a.A.xc(b).then(function (c) {
          c
            ? ((a.J = Number(c.endIndex)),
              (a.isLastVideoChunk = c.isLastVideoChunk),
              FH(a, c.video),
              (c = qE("get_video_succeeded")),
              a.A.dispatchEvent(c),
              a.C++)
            : DH(a);
          a.l++;
        });
      } else DH(a), a.l++;
    };
  wH.prototype.M = function () {
    this.D && this.A.Wa() && this.A.close();
    this.h.removeEventListener("load", this.da);
    this.h.removeEventListener("progress", this.fa);
    this.h.removeEventListener("error", this.ba);
    ry(this.va);
    ry(this.sa);
    R.prototype.M.call(this);
  };
  var HH = function (a, b) {
    R.call(this);
    var c = this;
    this.A = a;
    this.F = b;
    this.j = new MediaSource();
    this.C = [];
    this.l = [];
    this.h = this.o = null;
    this.D = !1;
    this.B = function () {
      GH(c);
    };
    this.j.addEventListener("sourceopen", this.B);
  };
  w(HH, R);
  HH.prototype.Uc = function () {
    return this.h ? this.h : (this.h = ek(this.j).toString());
  };
  var IH = function (a) {
      a.o && a.A.removeEventListener("timeupdate", a.o);
    },
    GH = function (a) {
      eo(N.getInstance(), "msmsw_oso");
      a.o = function () {
        if (!a.D) {
          var e = y(a.l),
            f = e.next();
          try {
            for (; !f.done; f = e.next()) AH(f.value);
          } finally {
            z(e, f);
          }
        }
      };
      a.A.addEventListener("timeupdate", a.o);
      for (var b = 0; b < a.F.length; b++) {
        var c = a.F[b];
        N.getInstance().P("msmsw_mime" + b, c.mimeType);
        N.getInstance().P("msmsw_cs" + b, c.gb.toString());
        var d = a.j.addSourceBuffer(c.mimeType);
        d
          ? (a.C.push(d),
            (c = EB(
              wH,
              a.A,
              c,
              d,
              function () {
                a: if (!a.D) {
                  var e = y(a.l),
                    f = e.next();
                  try {
                    for (; !f.done; f = e.next()) {
                      var g = f.value;
                      if (
                        g.D
                          ? !g.isLastVideoChunk || g.j.updating || g.B.length
                          : !g.K || g.j.updating || g.B.length
                      )
                        break a;
                    }
                  } finally {
                    z(e, f);
                  }
                  a.j.endOfStream();
                  a.D = !0;
                  IH(a);
                }
              },
              b
            )),
            a.l.push(c))
          : eo(N.getInstance(), "msmsw_sbf" + b);
      }
      N.getInstance().P("msmsw_ns", a.C.length.toString());
    };
  HH.prototype.M = function () {
    this.h && window.URL.revokeObjectURL(this.h);
    var a = y(this.l),
      b = a.next();
    try {
      for (; !b.done; b = a.next()) b.value.dispose();
    } finally {
      z(a, b);
    }
    IH(this);
    this.j.removeEventListener("sourceopen", this.B);
    R.prototype.M.call(this);
  };
  RegExp.prototype.hasOwnProperty("sticky");
  var KH = function (a) {
    oC.call(this, a);
    this.parameters = new Map();
    a = this.j;
    var b = a.indexOf(";"),
      c = null;
    b >= 0
      ? ((this.j = a.substring(0, b)), (c = a.substring(b + 1)))
      : (this.j = a);
    JH(this, c);
  };
  w(KH, oC);
  KH.prototype.toString = function () {
    return LH(this, oC.prototype.toString.call(this));
  };
  KH.prototype.F = function () {
    return "";
  };
  var JH = function (a, b) {
      Fb(tk(b)) ||
        b == null ||
        b.split(";").forEach(function (c) {
          var d = c.indexOf("=");
          if (!(d <= 0)) {
            var e = pk(c.substring(0, d));
            c = pk(c.substring(d + 1));
            d = a.parameters.get(e);
            d != null ? d.includes(c) || d.push(c) : (d = [tk(c)]);
            a.parameters.set(e, d);
          }
        }, a);
    },
    MH = function (a) {
      if (Fb(tk("ord"))) return null;
      a = a.parameters.get("ord");
      return a != null ? a : null;
    },
    NH = function (a, b) {
      Fb(tk("ord")) || ((b = b.map(tk)), a.parameters.set("ord", b));
    },
    LH = function (a, b) {
      b = [tk(b)];
      b.push.apply(b, ra(OH(a)));
      return b.join(";");
    },
    OH = function (a) {
      var b = MH(a);
      b == null
        ? (b = [tk(Date.now())])
        : Fb(tk("ord")) || a.parameters.delete("ord");
      var c = [];
      a.parameters.forEach(function (d, e) {
        d.forEach(function (f) {
          c.push(e + "=" + f);
        });
      });
      c.push("ord=" + b[0]);
      NH(a, b);
      return c;
    };
  KH.prototype.N = function () {
    return new KH(this.toString());
  };
  var PH = {
    wl: "IABUSPrivacy_String",
    dl: "IABTCF_gdprApplies",
    vl: "IABTCF_TCString",
    cl: "IABTCF_AddtlConsent",
    bl: "IABGPP_HDR_GppString",
    al: "IABGPP_GppSID",
  };
  var T = {
    DEPRECATED_ERROR_CODE: -1,
    VAST_MALFORMED_RESPONSE: 100,
    VAST_SCHEMA_VALIDATION_ERROR: 101,
    VAST_UNSUPPORTED_VERSION: 102,
    VAST_TRAFFICKING_ERROR: 200,
    VAST_UNEXPECTED_LINEARITY: 201,
    VAST_UNEXPECTED_DURATION_ERROR: 202,
    VAST_WRAPPER_ERROR: 300,
    VAST_LOAD_TIMEOUT: 301,
    VAST_TOO_MANY_REDIRECTS: 302,
    VAST_NO_ADS_AFTER_WRAPPER: 303,
    VIDEO_PLAY_ERROR: 400,
    VAST_MEDIA_LOAD_TIMEOUT: 402,
    VAST_LINEAR_ASSET_MISMATCH: 403,
    VAST_PROBLEM_DISPLAYING_MEDIA_FILE: 405,
    OVERLAY_AD_PLAYING_FAILED: 500,
    NONLINEAR_DIMENSIONS_ERROR: 501,
    OVERLAY_AD_LOADING_FAILED: 502,
    VAST_NONLINEAR_ASSET_MISMATCH: 503,
    COMPANION_REQUIRED_ERROR: 602,
    COMPANION_AD_LOADING_FAILED: 603,
    UNKNOWN_ERROR: 900,
    VPAID_ERROR: 901,
    FAILED_TO_REQUEST_ADS: 1005,
    VAST_ASSET_NOT_FOUND: 1007,
    VAST_EMPTY_RESPONSE: 1009,
    UNKNOWN_AD_RESPONSE: 1010,
    UNSUPPORTED_LOCALE: 1011,
    ADS_REQUEST_NETWORK_ERROR: 1012,
    INVALID_AD_TAG: 1013,
    PROTECTED_AUDIENCE_API_ERROR: 1014,
    STREAM_INITIALIZATION_FAILED: 1020,
    ASSET_FALLBACK_FAILED: 1021,
    UNSUPPORTED_URL: 1022,
    STREAM_INITIALIZATION_TIMEOUT: 1023,
    STREAM_AUTHORIZATION_FAILED: 1024,
    INVALID_ARGUMENTS: 1101,
    NATIVE_MESSAGE_ERROR: 1204,
    AUTOPLAY_DISALLOWED: 1205,
    CONSENT_MANAGEMENT_PROVIDER_NOT_READY: 1300,
    Jl: 1400,
    Nl: 1401,
    Ml: 1402,
    Ll: 1403,
    Ol: 1404,
    Kl: 1405,
    Wl: 2002,
  };
  T[-1] = "DEPRECATED_ERROR_CODE";
  T[100] = "VAST_MALFORMED_RESPONSE";
  T[101] = "VAST_SCHEMA_VALIDATION_ERROR";
  T[102] = "VAST_UNSUPPORTED_VERSION";
  T[200] = "VAST_TRAFFICKING_ERROR";
  T[201] = "VAST_UNEXPECTED_LINEARITY";
  T[202] = "VAST_UNEXPECTED_DURATION_ERROR";
  T[300] = "VAST_WRAPPER_ERROR";
  T[301] = "VAST_LOAD_TIMEOUT";
  T[302] = "VAST_TOO_MANY_REDIRECTS";
  T[303] = "VAST_NO_ADS_AFTER_WRAPPER";
  T[400] = "VIDEO_PLAY_ERROR";
  T[402] = "VAST_MEDIA_LOAD_TIMEOUT";
  T[403] = "VAST_LINEAR_ASSET_MISMATCH";
  T[405] = "VAST_PROBLEM_DISPLAYING_MEDIA_FILE";
  T[500] = "OVERLAY_AD_PLAYING_FAILED";
  T[501] = "NONLINEAR_DIMENSIONS_ERROR";
  T[502] = "OVERLAY_AD_LOADING_FAILED";
  T[503] = "VAST_NONLINEAR_ASSET_MISMATCH";
  T[602] = "COMPANION_REQUIRED_ERROR";
  T[603] = "COMPANION_AD_LOADING_FAILED";
  T[900] = "UNKNOWN_ERROR";
  T[901] = "VPAID_ERROR";
  T[1005] = "FAILED_TO_REQUEST_ADS";
  T[1007] = "VAST_ASSET_NOT_FOUND";
  T[1009] = "VAST_EMPTY_RESPONSE";
  T[1010] = "UNKNOWN_AD_RESPONSE";
  T[1011] = "UNSUPPORTED_LOCALE";
  T[1012] = "ADS_REQUEST_NETWORK_ERROR";
  T[1013] = "INVALID_AD_TAG";
  T[1014] = "PROTECTED_AUDIENCE_API_ERROR";
  T[1020] = "STREAM_INITIALIZATION_FAILED";
  T[1021] = "ASSET_FALLBACK_FAILED";
  T[1022] = "UNSUPPORTED_URL";
  T[1023] = "STREAM_INITIALIZATION_TIMEOUT";
  T[1024] = "STREAM_AUTHORIZATION_FAILED";
  T[1101] = "INVALID_ARGUMENTS";
  T[1204] = "NATIVE_MESSAGE_ERROR";
  T[1205] = "AUTOPLAY_DISALLOWED";
  T[1300] = "CONSENT_MANAGEMENT_PROVIDER_NOT_READY";
  T[1400] = "PREBID_ERROR_RETRIEVING_VAST";
  T[1401] = "PREBID_UNKNOWN_GLOBAL";
  T[1402] = "PREBID_UNKNOWN_BID";
  T[1403] = "PREBID_UNKNOWN_AD_ID";
  T[1404] = "PREBID_UNKNOWN_VAST";
  T[1405] = "PREBID_INCOMPATIBLE_VERSION";
  T[2002] = "SUPPORTED_ADS_NOT_FOUND";
  var QH = function (a, b, c) {
    var d = Error.call(this);
    this.message = d.message;
    "stack" in d && (this.stack = d.stack);
    this.type = a;
    this.errorMessage = b;
    this.errorCode = c;
    this.ad = this.h = null;
    this.yf = !0;
  };
  w(QH, Error);
  n = QH.prototype;
  n.getAd = function () {
    return this.ad;
  };
  n.getInnerError = function () {
    return this.h;
  };
  n.getMessage = function () {
    return this.errorMessage;
  };
  n.getErrorCode = function () {
    return this.errorCode;
  };
  n.getVastErrorCode = function () {
    return this.errorCode < 1e3 ? this.errorCode : 900;
  };
  n.getType = function () {
    return this.type;
  };
  n.toString = function () {
    return (
      "AdError " +
      this.getErrorCode() +
      ": " +
      this.getMessage() +
      (this.getInnerError() != null
        ? " Caused by: " + this.getInnerError()
        : "")
    );
  };
  n.ha = function () {
    for (
      var a = {},
        b = (a =
          ((a.type = this.getType()),
          (a.errorCode = this.getErrorCode()),
          (a.errorMessage = this.getMessage()),
          a)),
        c = this.getInnerError(),
        d = 0;
      d < 3;
      ++d
    )
      if (c instanceof QH) {
        var e = {};
        e =
          ((e.type = c.getType()),
          (e.errorCode = c.getErrorCode()),
          (e.errorMessage = c.getMessage()),
          e);
        b = b.innerError = e;
        c = c.getInnerError();
      } else {
        c != null && (b.innerError = String(c));
        break;
      }
    return a;
  };
  var RH = function (a, b) {
    return a.indexOf(b) == 0 ? a.substr(b.length) : null;
  };
  function SH() {
    if (Ks()) return window.location.href;
    var a = vr(),
      b = a.j,
      c = a.h;
    a = a.l;
    var d = null;
    if (a)
      try {
        var e = EC(a.url),
          f = e.j,
          g = RH(f, "/v/");
        g || (g = RH(f, "/a/"));
        if (!g) throw Error("Can not extract standalone amp url.");
        var h = RH("/" + g, "/s/"),
          k = sC(e.l);
        k.remove("amp_js_v");
        k.remove("amp_lite");
        var l = h ? EC("https://" + h) : EC("http://" + g);
        rC(l, k);
        d = l.toString();
      } catch (m) {
        d = null;
      }
    return d ? d : b && b.url ? b.url : c && c.url ? c.url : "";
  }
  function TH() {
    var a = sr();
    a = y(a);
    var b = a.next();
    try {
      for (; !b.done; b = a.next()) {
        var c = b.value;
        if (c.url && c.url.includes("amp=1")) return !0;
      }
    } finally {
      z(a, b);
    }
    return window.context != null
      ? ((c = Number(window.context.ampcontextVersion)),
        isNaN(c) ? !1 : Math.floor(c) > 0)
      : vr().l != null;
  }
  function UH() {
    var a = ol().location.ancestorOrigins;
    return a ? (a.length > 0 ? [].concat(ra(a)).join(",") : "") : "";
  }
  var VH = function (a) {
      this.h = a;
    },
    XH = function (a) {
      return WH(a);
    },
    YH = function (a, b) {
      return Zk(a.h, b) && ((a = a.h[b]), typeof a === "boolean") ? a : !1;
    },
    WH = function (a) {
      if (Zk(a.h, "forceExperimentIds")) {
        a = a.h.forceExperimentIds;
        var b = [],
          c = 0;
        Array.isArray(a) &&
          a.forEach(function (d) {
            typeof d === "number" && (b[c++] = d);
          });
        return b;
      }
      return null;
    };
  var ZH = function () {
      this.C = "always";
      this.V = 4;
      this.O = null;
      this.A = 1;
      this.h = 0;
      this.B = !0;
      this.locale = "en";
      this.j = null;
      this.H = !1;
      this.K = this.J = "";
      this.o = null;
      this.T = this.D = -1;
      this.l = "";
      this.F = !1;
      this.W = null;
      this.sessionId = Tx();
      this.R = null;
      this.N = {};
      try {
        this.W = Hr()[0];
      } catch (a) {}
    },
    $H = function (a) {
      a = tk(a);
      Fb(a) || (a = a.substring(0, 20));
      return a;
    };
  n = ZH.prototype;
  n.setCompanionBackfill = function (a) {
    this.C = a;
  };
  n.getCompanionBackfill = function () {
    return this.C;
  };
  n.setNumRedirects = function (a) {
    this.V = a;
  };
  n.getNumRedirects = function () {
    return this.V;
  };
  n.setPpid = function (a) {
    this.O = a;
  };
  n.getPpid = function () {
    return this.O;
  };
  n.setVpaidAllowed = function (a) {
    typeof a === "boolean" && (this.A = a ? 1 : 0);
  };
  n.setVpaidMode = function (a) {
    this.A = a;
  };
  n.Dd = function () {
    return this.A;
  };
  n.setAutoPlayAdBreaks = function (a) {
    this.B = a;
  };
  n.Zc = function () {
    return this.B;
  };
  n.setPreloadTimeSeconds = function (a) {
    this.R = a;
  };
  n.getPreloadTimeSeconds = function () {
    return this.R;
  };
  n.uf = function (a) {
    this.H = a;
  };
  n.Eb = function () {
    return this.H;
  };
  n.setLocale = function (a) {
    if ((a = xD(a))) this.locale = a;
  };
  n.getLocale = function () {
    return this.locale;
  };
  n.setPlayerType = function (a) {
    this.J = $H(a);
  };
  n.getPlayerType = function () {
    return this.J;
  };
  n.setPlayerVersion = function (a) {
    this.K = $H(a);
  };
  n.getPlayerVersion = function () {
    return this.K;
  };
  var aI = function (a) {
    if (a.o == null) {
      var b = {};
      var c = new oC(ol().location.href).l;
      if (IC(c, "tcnfp"))
        try {
          b = JSON.parse(c.get("tcnfp"));
        } catch (d) {}
      a.o = new VH(b);
    }
    return a.o;
  };
  n = ZH.prototype;
  n.vf = function (a) {
    this.D = a;
  };
  n.Tc = function () {
    return this.D;
  };
  n.xf = function (a) {
    this.T = a;
  };
  n.setDisableCustomPlaybackForIOS10Plus = function (a) {
    this.F = a;
  };
  n.getDisableCustomPlaybackForIOS10Plus = function () {
    return this.F;
  };
  n.setSessionId = function (a) {
    this.sessionId = a;
  };
  n.setFeatureFlags = function (a) {
    this.N = a;
  };
  n.getFeatureFlags = function () {
    return this.N;
  };
  n.ha = function (a) {
    a = a === void 0 ? null : a;
    var b = {};
    a != null && (b.activeViewPushUpdates = a);
    b.activityMonitorMode = this.h;
    b.adsToken = this.l;
    b.autoPlayAdBreaks = this.Zc();
    b.companionBackfill = this.getCompanionBackfill();
    b.disableCustomPlaybackForIOS10Plus =
      this.getDisableCustomPlaybackForIOS10Plus();
    b.engagementDetection = !0;
    b.isFunctionalTest = !1;
    b.isVpaidAdapter = this.Eb();
    b["1pJar"] = "";
    b.numRedirects = this.getNumRedirects();
    b.pageCorrelator = this.Tc();
    b.persistentStateCorrelator = tn();
    b.playerType = this.getPlayerType();
    b.playerVersion = this.getPlayerVersion();
    b.ppid = this.getPpid();
    b.preloadTimeSeconds = this.getPreloadTimeSeconds();
    b.privacyControls = "";
    b.reportMediaRequests = !1;
    b.sessionId = this.sessionId;
    b.streamCorrelator = this.T;
    b.testingConfig = aI(this).h;
    b.urlSignals = this.W;
    b.vpaidMode = this.Dd();
    b.featureFlags = this.getFeatureFlags();
    return b;
  };
  var U = new ZH();
  function bI(a, b) {
    CC(a, "url", "");
    try {
      var c = 2083 - a.toString().length - 1;
      if (c <= 0) return a.toString();
      for (
        var d = b.slice(0, c), e = encodeURIComponent(d), f = c;
        f > 0 && e.length > c;

      )
        (d = b.slice(0, f--)), (e = encodeURIComponent(d));
      CC(a, "url", d);
    } catch (g) {}
    return a.toString();
  }
  var V = {},
    cI =
      ((V.creativeView = "creativeview"),
      (V.start = "start"),
      (V.midpoint = "midpoint"),
      (V.firstQuartile = "firstquartile"),
      (V.thirdQuartile = "thirdquartile"),
      (V.complete = "complete"),
      (V.mute = "mute"),
      (V.unmute = "unmute"),
      (V.pause = "pause"),
      (V.rewind = "rewind"),
      (V.resume = "resume"),
      (V.fullscreen = "fullscreen"),
      (V.exitFullscreen = "exitfullscreen"),
      (V.expand = "expand"),
      (V.collapse = "collapse"),
      (V.close = "close"),
      (V.acceptInvitation = "acceptinvitation"),
      (V.adCanPlay = "adCanPlay"),
      (V.adStarted = "adStarted"),
      (V.abandon = "abandon"),
      (V.acceptInvitationLinear = "acceptinvitationlinear"),
      (V.engagedView = "engagedview"),
      (V.instreamAdComplete = "instreamAdComplete"),
      (V.skipShown = "skipshown"),
      (V.skippableStateChanged = "skippableStateChanged"),
      (V.skip = "skip"),
      (V.progress = "progress"),
      (V.publisher_invoked_skip = "PUBLISHER_INVOKED_SKIP"),
      (V.annotation_start = "annotation_start"),
      (V.annotation_click = "annotation_click"),
      (V.annotation_close = "annotation_close"),
      (V.cta_annotation_shown = "cta_annotation_shown"),
      (V.cta_annotation_clicked = "cta_annotation_clicked"),
      (V.cta_annotation_closed = "cta_annotation_closed"),
      (V.replay = "replay"),
      (V.stop = "stop"),
      (V.autoplayDisallowed = "autoplayDisallowed"),
      (V.error = "error"),
      (V.mediaLoadTimeout = "mediaLoadTimeout"),
      (V.linearChanged = "linearChanged"),
      (V.click = "click"),
      (V.contentPauseRequested = "contentPauseRequested"),
      (V.contentResumeRequested = "contentResumeRequested"),
      (V.discardAdBreak = "discardAdBreak"),
      (V.updateAdsRenderingSettings = "updateAdsRenderingSettings"),
      (V.durationChange = "durationChange"),
      (V.expandedChanged = "expandedChanged"),
      (V.autoClose = "autoClose"),
      (V.userClose = "userClose"),
      (V.userRecall = "userRecall"),
      (V.prefetched = "prefetched"),
      (V.loaded = "loaded"),
      (V.init = "init"),
      (V.allAdsCompleted = "allAdsCompleted"),
      (V.adMetadata = "adMetadata"),
      (V.adBreakReady = "adBreakReady"),
      (V.adBreakFetchError = "adBreakFetchError"),
      (V.log = "log"),
      (V.volumeChange = "volumeChange"),
      (V.companionBackfill = "companionBackfill"),
      (V.companionInitialized = "companionInitialized"),
      (V.companionImpression = "companionImpression"),
      (V.companionClick = "companionClick"),
      (V.impression = "impression"),
      (V.interaction = "interaction"),
      (V.adProgress = "adProgress"),
      (V.adBuffering = "adBuffering"),
      (V.trackingUrlPinged = "trackingUrlPinged"),
      (V.measurable_impression = "measurable_impression"),
      (V.custom_metric_viewable = "custom_metric_viewable"),
      (V.viewable_impression = "viewable_impression"),
      (V.fully_viewable_audible_half_duration_impression =
        "fully_viewable_audible_half_duration_impression"),
      (V.audio_audible = "audio_audible"),
      (V.audio_measurable = "audio_measurable"),
      (V.overlay_resize = "overlay_resize"),
      (V.overlay_unmeasurable_impression = "overlay_unmeasurable_impression"),
      (V.overlay_unviewable_impression = "overlay_unviewable_impression"),
      (V.overlay_viewable_immediate_impression =
        "overlay_viewable_immediate_impression"),
      (V.overlay_viewable_end_of_session_impression =
        "overlay_viewable_end_of_session_impression"),
      (V.externalActivityEvent = "externalActivityEvent"),
      (V.adEvent = "adEvent"),
      (V.configure = "configure"),
      (V.remainingTime = "remainingTime"),
      (V.destroy = "destroy"),
      (V.resize = "resize"),
      (V.volume = "volume"),
      (V.authorIconClicked = "videoAuthorIconClicked"),
      (V.authorNameClicked = "videoAuthorClicked"),
      (V.videoClicked = "videoClicked"),
      (V.videoIconClicked = "videoIconClicked"),
      (V.learnMoreClicked = "videoLearnMoreClicked"),
      (V.muteClicked = "videoMuteClicked"),
      (V.titleClicked = "videoTitleClicked"),
      (V.videoSkipClicked = "SKIPPED"),
      (V.unmuteClicked = "videoUnmuteClicked"),
      (V.vpaidEvent = "vpaidEvent"),
      (V.show_ad = "show_ad"),
      (V.video_card_endcap_collapse = "video_card_endcap_collapse"),
      (V.video_card_endcap_dismiss = "video_card_endcap_dismiss"),
      (V.video_card_endcap_impression = "video_card_endcap_impression"),
      (V.mediaUrlPinged = "mediaUrlPinged"),
      (V.breakStart = "breakstart"),
      (V.breakEnd = "breakend"),
      (V.omidReady = "omidReady"),
      (V.omidUnavailable = "omidUnavailable"),
      (V.omidAdSessionCompleted = "omidAdSessionCompleted"),
      (V.omidAdSessionAbandoned = "omidAdSessionAbandoned"),
      (V.verificationNotExecuted = "verificationNotExecuted"),
      (V.loadStart = "loadStart"),
      (V.seeked = "seeked"),
      (V.seeking = "seeking"),
      (V.nonLinearAdError = "nonLinearAdError"),
      (V.nonLinearAdRendered = "nonLinearAdRendered"),
      V);
  var dI = new VD();
  function eI(a) {
    var b = b === void 0 ? dI : b;
    b.ec(a);
  }
  function fI(a) {
    a = { rj: null, appName: null, lj: !1, Ed: !1, jc: a.jc };
    var b = (a = a === void 0 ? {} : a);
    a = b.rj;
    a = a === void 0 ? null : a;
    var c = b.appName;
    c = c === void 0 ? null : c;
    var d = b.lj,
      e = b.Ed;
    b = b.jc;
    b = b === void 0 ? null : b;
    var f = "h.3.800.0";
    a != null
      ? ((f += "/n." + a), c != null && (f += "/" + c))
      : U.Eb() && (f += "/vpaid_adapter");
    (d === void 0 ? 0 : d) && (f += "/ima_eap");
    (e === void 0 ? 0 : e) && (f += "/ima_cast");
    if (b && sq(vB))
      switch (b) {
        case "tizen_hosted":
        case "tizen_packaged":
          f += "/n.tizen";
          break;
        case "lg_channels":
        case "webos":
          f += "/n.webos";
          break;
        default:
          He(b);
      }
    return f;
  }
  var W = function () {
    this.o = Math.random();
    this.l = Math.floor(Math.random() * 4503599627370496);
    this.h = this.j = null;
  };
  W.prototype.report = function (a, b, c) {
    b = b === void 0 ? {} : b;
    c = c === void 0 ? 0.01 : c;
    this.o < (c === void 0 ? 0.01 : c) && gI(this, a, b);
  };
  var gI = function (a, b, c) {
      c = c === void 0 ? {} : c;
      if (C.G_testRunner == null) {
        c.lid = b;
        a.h && ((b = fI(a.h)), (c.sdkv = b));
        a.j && (c.palv = a.j);
        b = op();
        Fb(tk(b)) || (c.e = b);
        c = hI(a, c);
        var d = new oC("https://pagead2.googlesyndication.com/pagead/gen_204");
        Sk(
          c,
          function (e, f) {
            e != null &&
              CC(
                d,
                f,
                e == null
                  ? ""
                  : typeof e === "boolean"
                  ? e
                    ? "t"
                    : "f"
                  : "" + e
              );
          },
          a
        );
        a = d.toString();
        c = DC(d, "url");
        c != null && Tb() && a.length > 2083 && (a = bI(d, c));
        eI(a);
      }
    },
    hI = function (a, b) {
      b.id = "ima_html5";
      b.c = a.l;
      if (typeof window !== "undefined") {
        var c = window,
          d,
          e;
        a = new oC(
          c.parent === c
            ? (d = c.location) == null
              ? void 0
              : d.href
            : (e = c.document) == null
            ? void 0
            : e.referrer
        );
        b.domain = a.h;
      }
      return b;
    };
  W.getInstance = function () {
    return M(W);
  };
  var iI = ge({
    newToken: (function (a) {
      return he(
        Yd(function (b, c) {
          return b === void 0 ? !0 : a(b, c);
        })
      );
    })(ae),
  });
  function jI(a) {
    var b = Date.now(),
      c = {};
    a = ((c["x-afma-token-requester-type"] = a), c);
    c =
      "https://pubads.g.doubleclick.net/adsid/integrator.json?aos=" +
      encodeURIComponent(UH());
    return (
      Up(window.fetch) && Up(window.AbortController) && !Pb(Sb(), "HbbTV")
        ? new JB()
        : new PD()
    )
      .get({ url: c, withCredentials: !0, timeout: new yD(), headers: a })
      .then(function (d) {
        Wd(d, iI);
        var e = Date.now();
        d = d.newToken || "";
        var f = {};
        W.getInstance().report(182, ((f.t = e - b), (f.aos = UH()), f));
        return new kI(d);
      })
      .catch(function (d) {
        var e = "not instanceof Error";
        d instanceof Error && (e = IB(Number(d.message)));
        d = Date.now();
        var f = {};
        W.getInstance().report(182, ((f.except = e), (f.t = d - b), f));
        return Promise.resolve(lI);
      });
  }
  var mI = function () {
    S.call(this);
    this.h = null;
    this.o = new zD(this);
    tt(this, this.o);
    this.j = new Yy(72e5);
    this.l = Promise.resolve(lI);
  };
  w(mI, S);
  var nI = function (a) {
    var b = "requester_type_8";
    b = b === void 0 ? "requester_type_9" : b;
    var c = function (d) {
      a.h = d;
      return a.h;
    };
    a.l = jI(b).then(c);
    a.j = new Yy(72e5);
    a.o.listen(a.j, "tick", function () {
      a.l = jI(b).then(c);
    });
    a.j.start();
    rt(a, function () {
      a.j.stop();
    });
  };
  mI.prototype.getId = function () {
    var a = this;
    return Ka(function (b) {
      if (b.j == 1) return a.h != null && a.h !== lI ? b.ia(2) : b.h(a.l, 3);
      b.j != 2 && (a.h = b.l);
      return b.return(a.h);
    });
  };
  var kI = function (a) {
      this.id = a;
    },
    lI = new kI("");
  function oI(a) {
    return a
      ? (a = /\/(\d+)(?:,\d+){0,2}\//.exec(a)) && a.length === 2
        ? a[1]
        : null
      : null;
  }
  function pI(a) {
    if (a === "") return null;
    a = new oC(a);
    var b = DC(a, "slotname") || DC(a, "iu");
    if (!(b = b ? oI(b) : null)) {
      var c;
      b = (a = (c = DC(a, "client")) != null ? c : "") ? a : null;
    }
    return b;
  }
  function qI(a, b) {
    try {
      var c = new URL(a);
      return c.searchParams.get("slotname") || c.searchParams.get("iu") || "";
    } catch (d) {
      b == null || b(d);
    }
    return "";
  }
  function rI(a) {
    try {
      var b = new URL(a),
        c = b.searchParams.get("cust_params"),
        d = b.searchParams.get("scp");
      if (c == null) return {};
      a = function (e) {
        return e == null
          ? {}
          : Object.fromEntries(
              e
                .split("&")
                .map(function (f) {
                  return f.split("=");
                })
                .map(function (f) {
                  var g;
                  return [
                    f[0],
                    decodeURIComponent((g = f[1]) != null ? g : "").split(","),
                  ];
                })
                .filter(function (f) {
                  return f[0].length > 0;
                })
            );
      };
      return xa({}, a(c), a(d));
    } catch (e) {}
    return {};
  }
  var sI = function (a, b, c, d, e) {
      this.name = a;
      this.type = b;
      this.data = c;
      this.id = d;
      this.h = e;
    },
    tI = function (a) {
      S.call(this);
      this.j = [];
      this.connected = !1;
      this.sessionId = a || vk();
    };
  w(tI, S);
  tI.prototype.connect = function () {
    for (this.connected = !0; this.j.length !== 0; ) {
      var a = this.j.shift();
      a && this.sendMessage(a);
    }
  };
  var uI = function (a, b, c, d, e, f) {
    a.connected
      ? a.sendMessage(new sI(b, c, d, e, f))
      : a.j.push(new sI(b, c, d, e, f));
  };
  tI.prototype.sendMessage = function () {};
  var vI = function (a, b, c, d, e, f) {
    e = e === void 0 ? "" : e;
    f = f === void 0 ? "" : f;
    Vx.call(this, a);
    this.messageType = b;
    this.ra = c;
    this.sessionId = d;
    this.origin = e;
    this.id = f;
  };
  w(vI, Vx);
  vI.prototype.getId = function () {
    return this.id;
  };
  vI.prototype.toString = function () {
    return "";
  };
  var wI = function (a) {
    var b = a;
    b: {
      if (b && typeof b === "object") {
        a = y(Object.values(PH));
        var c = a.next();
        try {
          for (; !c.done; c = a.next())
            if (b.hasOwnProperty(c.value)) {
              var d = !0;
              break b;
            }
        } finally {
          z(a, c);
        }
      }
      d = !1;
    }
    if (d) {
      var e, f, g, h, k, l;
      d = {};
      a =
        ((d.uspString = (e = b.IABUSPrivacy_String) != null ? e : null),
        (d.gdprApplies = (f = b.IABTCF_gdprApplies) != null ? f : null),
        (d.tcString = (g = b.IABTCF_TCString) != null ? g : null),
        (d.addtlConsent = (h = b.IABTCF_AddtlConsent) != null ? h : null),
        (d.gppString = (k = b.IABGPP_HDR_GppString) != null ? k : null),
        (d.gppSid = (l = b.IABGPP_GppSID) != null ? l : null),
        d);
    } else a = b;
    b = a.uspString;
    this.uspString = typeof b === "string" ? b : "";
    b = a.gdprApplies;
    this.j =
      typeof b === "boolean"
        ? b
          ? "1"
          : "0"
        : typeof b !== "number" || (b !== 1 && b !== 0)
        ? typeof b !== "string" || (b !== "1" && b !== "0")
          ? ""
          : b === "1"
          ? "1"
          : "0"
        : b === 1
        ? "1"
        : "0";
    b = a.tcString;
    this.h = typeof b === "string" ? b : "";
    /^[\.\w_-]*$/.test(this.h) || (this.h = encodeURIComponent(this.h));
    a = a.gppString;
    this.gppString = typeof a === "string" ? a : "";
  };
  var xI = function (a) {
    this.G = I(a);
  };
  w(xI, K);
  var yI = function (a) {
    return Tg(a, 5);
  };
  function zI(a) {
    var b = {};
    new oC(a).l.forEach(function (c, d) {
      b[d] = c;
    });
    return b;
  }
  var AI = function (a, b, c) {
      a = a === void 0 ? {} : a;
      b = b === void 0 ? {} : b;
      this.l = c === void 0 ? !1 : c;
      c = {};
      a = y(Object.entries(a));
      var d = a.next();
      try {
        for (; !d.done; d = a.next()) {
          var e = y(d.value),
            f = e.next().value,
            g = e.next().value,
            h = f,
            k = g;
          k != null && (c[h] = String(k));
        }
      } finally {
        z(a, d);
      }
      this.h = c;
      this.j = new wI(b);
    },
    BI = function (a, b) {
      var c = !0;
      c = c === void 0 ? !1 : c;
      var d = new oC(a);
      var e = d.j;
      (d =
        Eb(d.h, "googleads.g.doubleclick.net") &&
        vD("/pagead/(live/)?ads", e)) ||
        ((e = new KH(a)),
        (d = e.h),
        (e = LH(e, e.j)),
        (d =
          !Eb(d, ".g.doubleclick.net") &&
          (Eb(d, "doubleclick.net") ||
            Eb(d, "pagead2.googlesyndication.com")) &&
          vD("/(ad|pfad)[x|i|j]?/", e)));
      d ||
        ((d = new oC(a)),
        (e = d.j),
        (d = Eb(d.h, "doubleclick.net") && vD("/gampad/(live/)?ads", e)));
      (d = d || new oC(a).h === "bid.g.doubleclick.net") ||
        ((d = new oC(a)),
        (e = d.j),
        (d = d.h === "ad.doubleclick.net" && vD("/dv3/adv", e)));
      d ||
        ((d = new oC(a)),
        (e = d.j),
        d.h === "pubads.g.doubleclick.net" &&
          (vD("/ssai/", e) || vD("/ondemand/", e)));
      return new AI(zI(a), b, c);
    },
    EI = function (a) {
      var b = a.j.h;
      var c = CI(a, "gdpr_consent");
      b =
        b && b !== "tcunavailable"
          ? b
          : b === "tcunavailable"
          ? c || b
          : c || "";
      if (b === "tcunavailable") return null;
      var d;
      a = DI(a);
      var e = ZA(b);
      if (e && b) {
        var f = Ig(e, rA, 1);
        c = Ig(e, mA, 2) || new mA();
        var g = {
          consents: aB(pg(f, 17, Ve)),
          legitimateInterests: aB(pg(f, 18, Ve)),
        };
        kg(e, 3) &&
          ((e = Ig(e, jA, 3)),
          (e = pg(e, 1, Ve)),
          (g.disclosedVendors = aB(e)));
        e = Ug(f, 9);
        var h = Ug(f, 4),
          k = Ug(f, 5),
          l = Tg(f, 10),
          m = Tg(f, 11),
          p = Yg(f, 16),
          q = Tg(f, 15),
          r = {
            consents: aB(pg(f, 13, Te), MA),
            legitimateInterests: aB(pg(f, 14, Te), MA),
          },
          t = aB(pg(f, 12, Te), NA),
          v = Kg(f, lA, 19);
        f = {};
        v = y(v);
        var x = v.next();
        try {
          for (; !x.done; x = v.next()) {
            var E = x.value;
            var F = Zg(E, 1);
            f[F] = f[F] || {};
            var B = pg(E, 3, Ve);
            var J = y(B),
              Q = J.next();
            try {
              for (; !Q.done; Q = J.next()) f[F][Q.value] = Zg(E, 2);
            } finally {
              z(J, Q);
            }
          }
        } finally {
          z(v, x);
        }
        E = {
          tcString: b,
          tcfPolicyVersion: e,
          gdprApplies: a,
          cmpId: h,
          cmpVersion: k,
          isServiceSpecific: l,
          useNonStandardStacks: m,
          publisherCC: p,
          purposeOneTreatment: q,
          purpose: r,
          vendor: g,
          specialFeatureOptins: t,
          publisher: {
            restrictions: f,
            consents: aB(pg(c, 1, Te), MA),
            legitimateInterests: aB(pg(c, 2, Te), MA),
            customPurposes: {
              consents: aB(pg(c, 3, Ve)),
              legitimateInterests: aB(pg(c, 4, Ve)),
            },
          },
        };
      } else E = null;
      return (d = E) != null ? d : null;
    },
    CI = function (a, b) {
      if (a.h.hasOwnProperty(b)) return a.h[b];
    },
    GI = function (a) {
      var b;
      if (!(b = FI(a))) {
        if (DI(a)) {
          a = EI(a);
          if ((b = !!a)) {
            var c = c === void 0 ? {} : c;
            if (bC(a))
              if (a.gdprApplies === !1) var d = !0;
              else if (a.tcString === "tcunavailable") d = !c.idpcApplies;
              else if (
                (c.idpcApplies || a.gdprApplies !== void 0 || c.Lm) &&
                (c.idpcApplies || (ae(a.tcString) && a.tcString.length))
              ) {
                d = d === void 0 ? "755" : d;
                c: {
                  if (
                    a.publisher &&
                    a.publisher.restrictions &&
                    ((c = a.publisher.restrictions["1"]), c !== void 0)
                  ) {
                    c = c[d === void 0 ? "755" : d];
                    break c;
                  }
                  c = void 0;
                }
                d =
                  c === 0
                    ? !1
                    : a.purpose && a.vendor
                    ? (d = dC(a.vendor.consents, d === void 0 ? "755" : d)) &&
                      a.purposeOneTreatment &&
                      a.publisherCC === "CH"
                      ? !0
                      : d && dC(a.purpose.consents, "1")
                    : !0;
              } else d = !0;
            else d = !1;
            b = d;
          }
          d = b;
        } else d = !0;
        b = !d;
      }
      return b;
    },
    FI = function (a) {
      a = CI(a, "ltd");
      return a === "1" || a === "true";
    },
    DI = function (a) {
      var b = CI(a, "gdpr"),
        c = a.j.j;
      b = (c === "1" || c === "0" ? c : b !== void 0 ? b : "").toLowerCase();
      return b === "true" || b === "1" || a.l;
    },
    II = function (a) {
      var b = new xI(),
        c = !GI(a);
      bh(b, 5, c);
      a = HI(a);
      bh(b, 17, a);
      return b;
    },
    HI = function (a) {
      return DI(a)
        ? (a = EI(a)) && a.tcString !== "tcunavailable"
          ? a.gdprApplies
            ? a.vendor
              ? a.vendor.disclosedVendors === void 0
                ? !0
                : dC(a.vendor.consents, "755") ||
                  dC(a.vendor.legitimateInterests, "755") ||
                  dC(a.vendor.disclosedVendors, "755")
              : !1
            : !0
          : !0
        : !0;
    };
  var JI = { IMAGE: "Image", FLASH: "Flash", ALL: "All" },
    KI = { HTML: "Html", IFRAME: "IFrame", STATIC: "Static", ALL: "All" },
    LI = {
      IGNORE: "IgnoreSize",
      SELECT_EXACT_MATCH: "SelectExactMatch",
      SELECT_NEAR_MATCH: "SelectNearMatch",
      SELECT_FLUID: "SelectFluid",
    },
    MI = { Ik: "DisallowResize", Ul: "ResizeSmaller" },
    NI = function () {
      this.allowCustom = !0;
      this.creativeType = this.resourceType = "All";
      this.sizeCriteria = "SelectExactMatch";
      this.nearMatchPercent = 90;
      this.adSlotIds = [];
      this.ee = "DisallowResize";
    };
  D(
    "module$exports$google3$javascript$ads$interactivemedia$sdk$clientside$api$companion_ad_selection_settings.CompanionAdSelectionSettings.CreativeType",
    JI
  );
  D(
    "module$exports$google3$javascript$ads$interactivemedia$sdk$clientside$api$companion_ad_selection_settings.CompanionAdSelectionSettings.ResourceType",
    KI
  );
  D(
    "module$exports$google3$javascript$ads$interactivemedia$sdk$clientside$api$companion_ad_selection_settings.CompanionAdSelectionSettings.SizeCriteria",
    LI
  );
  var PI = function (a, b) {
      b = b === void 0 ? new NI() : b;
      this.h = a;
      this.settings = b ? b : new NI();
      this.resourceType = OI(KI, this.settings.resourceType)
        ? this.settings.resourceType
        : "All";
      this.creativeType = OI(JI, this.settings.creativeType)
        ? this.settings.creativeType
        : "All";
      this.sizeCriteria = OI(LI, this.settings.sizeCriteria)
        ? this.settings.sizeCriteria
        : "SelectExactMatch";
      this.ee = OI(MI, this.settings.ee) ? this.settings.ee : "DisallowResize";
      this.adSlotIds =
        this.settings.adSlotIds != null ? this.settings.adSlotIds : [];
      this.nearMatchPercent =
        typeof this.settings.nearMatchPercent === "number" &&
        this.settings.nearMatchPercent > 0 &&
        this.settings.nearMatchPercent <= 100
          ? this.settings.nearMatchPercent
          : 90;
    },
    SI = function (a, b) {
      var c = [];
      b.forEach(function (d) {
        a.settings.allowCustom &&
          (!Fb(d.getContent()) &&
          (isNaN(d.data.sequenceNumber) ||
            isNaN(d.data.mainAdSequenceNumber) ||
            d.data.mainAdSequenceNumber === d.data.sequenceNumber) &&
          QI(a, d)
            ? c.push(d)
            : ((d = RI(a, d)), d != null && !Fb(d.getContent()) && c.push(d)));
      });
      return c;
    };
  PI.prototype.yg = function () {
    return this.resourceType;
  };
  var QI = function (a, b) {
      var c;
      if ((c = b.getContentType() !== "Flash")) {
        if ((c = a.resourceType === "All" || a.resourceType === b.yg()))
          (c = b.getContentType()),
            (c =
              c == null
                ? !0
                : a.creativeType === "All" || a.creativeType === c);
        c &&
          ((c = b.getAdSlotId()),
          (c =
            a.adSlotIds.length === 0
              ? !0
              : c != null
              ? a.adSlotIds.includes(c)
              : !1));
      }
      if (c)
        if (((c = b.getSize()), (b = !!b.data.fluidSize) || a.h.ug))
          a = b && a.h.ug;
        else if (
          ((b = a.sizeCriteria === "IgnoreSize") ||
            ((b = a.h.size),
            (b =
              b == c
                ? !0
                : b && c
                ? b.width == c.width && b.height == c.height
                : !1)),
          b)
        )
          a = !0;
        else {
          if ((b = a.sizeCriteria === "SelectNearMatch"))
            a.ee === "ResizeSmaller"
              ? ((c.width <= a.h.size.width && c.height <= a.h.size.height) ||
                  ((b = a.h.size),
                  (b = Math.min(b.width / c.width, b.height / c.height)),
                  (c = new Rk(b * c.width, b * c.height))),
                (b = c.width),
                (c = c.height))
              : ((b = c.width), (c = c.height)),
              (b = !(
                b > a.h.size.width ||
                c > a.h.size.height ||
                b < (a.nearMatchPercent / 100) * a.h.size.width ||
                c < (a.nearMatchPercent / 100) * a.h.size.height
              ));
          a = b;
        }
      else a = !1;
      return a;
    },
    RI = function (a, b) {
      b = TI(b);
      return b == null
        ? null
        : b.find(function (c) {
            return QI(a, c);
          }) || null;
    },
    OI = function (a, b) {
      return b != null && $k(a, b);
    };
  var UI = function (a, b) {
    R.call(this);
    this.h = a;
    this.timeoutMs = b;
    tt(this, this.h);
  };
  w(UI, R);
  var WI = function (a) {
      if (!PB(a.h.caller)) return Promise.resolve(null);
      var b = new bD(),
        c = null;
      a.h.addEventListener(function (e) {
        if (e.pingData.internalErrorState === 1) b.resolve(null);
        else if (e.eventName === "listenerRegistered")
          (c = e.listenerId),
            e.pingData.applicableSections.length === 1 &&
              e.pingData.applicableSections[0] === -1 &&
              b.resolve(new VI("", "-1"));
        else if (e.eventName === "signalStatus" && e.data === "ready") {
          e = e.pingData;
          var f,
            g = ((f = e.applicableSections) != null ? f : []).join("_");
          b.resolve(new VI(e.gppString, g));
        }
      });
      var d = new Promise(function (e) {
        setTimeout(function () {
          e(null);
        }, a.timeoutMs);
      });
      d = Promise.race([b.promise, d]);
      d.then(function () {
        c !== null && a.h.removeEventListener(c);
      });
      return d;
    },
    VI = function (a, b) {
      this.gppString = a;
      this.sid = b;
    };
  function XI() {
    var a = a === void 0 ? C : a;
    return Mk(a.top, "googlefcLoaded");
  }
  var YI = function (a) {
    R.call(this);
    this.j = new YB(a, { timeoutMs: 500 });
    this.l = new VB(a, { timeoutMs: 500 });
    a = new kC(a, { timeoutMs: 500 });
    this.h = new UI(a, 500);
    tt(this, this.h);
  };
  w(YI, R);
  var ZI = function (a) {
    var b,
      c,
      d,
      e,
      f,
      g,
      h,
      k,
      l,
      m,
      p,
      q,
      r,
      t,
      v,
      x,
      E,
      F,
      B,
      J,
      Q,
      oa,
      ta,
      Da,
      ca;
    return Ka(function (fa) {
      if (fa.j == 1)
        return (
          (b = Promise.resolve(null)),
          $B(a.j) &&
            (b = new Promise(function (Ma) {
              cC(a.j, Ma);
            })),
          (c = Promise.resolve(null)),
          PB(a.l.caller) &&
            (c = new Promise(function (Ma) {
              WB(a.l, Ma);
            })),
          (d = Promise.resolve(null)),
          (d = WI(a.h)),
          (e = y),
          fa.h(Promise.all([c, b, d]), 2)
        );
      f = e(fa.l);
      g = f.next().value;
      h = f.next().value;
      k = f.next().value;
      l = g;
      m = h;
      p = k;
      q = XI();
      ca = {};
      return fa.return(
        ((ca.gfcLoaded = q),
        (ca.addtlConsent =
          (B = (r = m) == null ? void 0 : r.addtlConsent) != null ? B : null),
        (ca.gdprApplies =
          (J = (t = m) == null ? void 0 : t.gdprApplies) != null ? J : null),
        (ca.tcString =
          (Q = (v = m) == null ? void 0 : v.tcString) != null ? Q : null),
        (ca.uspString =
          (oa = (x = l) == null ? void 0 : x.uspString) != null ? oa : null),
        (ca.gppString =
          (ta = (E = p) == null ? void 0 : E.gppString) != null ? ta : null),
        (ca.gppSid =
          (Da = (F = p) == null ? void 0 : F.sid) != null ? Da : null),
        ca)
      );
    });
  };
  function $I(a, b) {
    var c = new Hm(),
      d = a.getBoundingClientRect();
    var e = d.y;
    d = d.x;
    var f = new Fm();
    e = eh(f, 1, e);
    e = eh(e, 2, d);
    d = a.duration;
    var g = a.clientWidth;
    f = a.clientHeight;
    var h = new Gm();
    g = eh(h, 1, g);
    f = eh(g, 2, f);
    d === Number.POSITIVE_INFINITY ||
      isNaN(d) ||
      ((g = new Em()), (d = dh(g, 1, d)), Mg(c, 3, d));
    a = Number(window.getComputedStyle(a).opacity);
    e = Mg(c, 1, e);
    e = Mg(e, 2, f);
    a = dh(e, 4, a);
    jh(a, 5, b);
    return c;
  }
  function aJ(a, b) {
    if (a.length === 0) return null;
    var c = b.ma.h,
      d,
      e,
      f = (e = (d = b.Ka) == null ? void 0 : d.h) != null ? e : null;
    a = a.filter(function (g) {
      return bJ(g) && !g.isEqualNode(c) && !g.isEqualNode(f);
    });
    return a.length > 0 ? a[0] : null;
  }
  function bJ(a) {
    var b,
      c = (b = a.ownerDocument) == null ? void 0 : b.defaultView;
    return (
      (c && a instanceof c.HTMLVideoElement) ||
      (a.nodeType === 1 && a.tagName === "VIDEO")
    );
  }
  var cJ = function (a, b) {
    this.message = a;
    this.errorCode = b;
  };
  cJ.prototype.getErrorCode = function () {
    return this.errorCode;
  };
  cJ.prototype.getMessage = function () {
    return this.message;
  };
  var dJ = new cJ(
      "Failed to initialize ad playback element before starting ad playback.",
      400
    ),
    eJ = new cJ("The provided {0} information: {1} is invalid.", 1101),
    fJ = new cJ(
      "The ad response references a locally cached Prebid bid, but the bid could not be found.",
      1402
    ),
    gJ = new cJ(
      "The ad response references a locally cached Prebid bid, but the global Prebid instance is missing. Verify that Prebid has not been unloaded or destroyed.",
      1401
    ),
    hJ = new cJ(
      "The ad response references a locally cached Prebid bid, but the version of the Prebid library is incompatible.",
      1405
    ),
    iJ = new cJ(
      "The ad response references a locally cached Prebid bid, but an unknown error occurred while retrieving the cached VAST.",
      1400
    );
  function jJ(a, b) {
    return kJ(
      "adPlayError",
      a,
      b === void 0 ? null : b,
      La.apply(2, arguments)
    );
  }
  function kJ(a, b, c, d) {
    if (c instanceof QH) return c;
    var e = b.getErrorCode();
    b = b.getMessage();
    if (d.length > 0)
      for (var f = 0; f < d.length; f++)
        b = b.replace(new RegExp("\\{" + f + "\\}", "ig"), d[f]);
    a = new QH(a, b, e);
    a.h = c;
    return a;
  }
  function lJ(a, b, c) {
    b = b === void 0 ? window : b;
    c = c === void 0 ? function () {} : c;
    try {
      return b.localStorage.getItem(a);
    } catch (d) {
      return c(d), null;
    }
  }
  function mJ(a, b, c) {
    var d = window;
    d = d === void 0 ? window : d;
    return yI(b) ? lJ(a, d, c === void 0 ? function () {} : c) : null;
  }
  function nJ(a, b, c, d) {
    c = c === void 0 ? window : c;
    d = d === void 0 ? function () {} : d;
    try {
      return c.localStorage.setItem(a, b), !0;
    } catch (e) {
      d(e);
    }
    return !1;
  }
  function oJ(a, b, c, d) {
    var e = window;
    e = e === void 0 ? window : e;
    return yI(c) ? nJ(a, b, e, d === void 0 ? function () {} : d) : !1;
  }
  function pJ(a, b, c) {
    b = b === void 0 ? window : b;
    c = c === void 0 ? function () {} : c;
    try {
      b.localStorage.removeItem(a);
    } catch (d) {
      c(d);
    }
  }
  function qJ(a, b, c, d) {
    c = c === void 0 ? window : c;
    yI(b) && pJ(a, c, d === void 0 ? function () {} : d);
  }
  function rJ(a, b) {
    a = a === void 0 ? window : a;
    try {
      return a.localStorage.length;
    } catch (c) {
      (b === void 0 ? function () {} : b)(c);
    }
    return null;
  }
  function sJ(a) {
    var b = b === void 0 ? window : b;
    return yI(a) ? rJ(b, function () {}) : null;
  }
  function tJ(a, b, c) {
    b = b === void 0 ? window : b;
    c = c === void 0 ? function () {} : c;
    try {
      return b.localStorage.key(a);
    } catch (d) {
      c(d);
    }
    return null;
  }
  function uJ(a, b) {
    var c = c === void 0 ? window : c;
    return yI(b) ? tJ(a, c, function () {}) : null;
  }
  function vJ(a, b) {
    a = a === void 0 ? window : a;
    b = b === void 0 ? function () {} : b;
    try {
      return Object.keys(a.localStorage);
    } catch (c) {
      b(c);
    }
    return null;
  }
  function wJ(a) {
    var b = b === void 0 ? window : b;
    return yI(a) ? vJ(b, function () {}) : null;
  }
  function xJ(a) {
    return Xc(a, 3);
  }
  var yJ = { zi: [], wi: 0, Ii: [], fn: !1, Uj: !1 };
  var zJ = function () {};
  zJ.getInstance = function () {
    throw Error("Must be overridden");
  };
  var AJ = function () {
    this.h = 0;
  };
  w(AJ, zJ);
  AJ.Wb = void 0;
  AJ.getInstance = function () {
    return AJ.Wb ? AJ.Wb : (AJ.Wb = new AJ());
  };
  function BJ(a, b, c, d, e) {
    c = c === void 0 ? null : c;
    d = d === void 0 ? {} : d;
    var f = AJ.getInstance(),
      g,
      h = (g = e == null ? void 0 : e.ah) != null ? g : 1e3;
    f.h === 0 && (f.h = Math.random() < 1 / h ? 2 : 1);
    if (f.h === 2) {
      if (e) {
        f = e.pinger;
        g = f.ak;
        var k = c,
          l = d,
          m = e.Rm;
        k = k === void 0 ? null : k;
        l = l === void 0 ? {} : l;
        var p = new bn();
        p = jh(p, 1, a);
        m = Hk(m);
        m = gh(p, 2, m);
        k = wg(m, 3, hf(k), "");
        k = wg(k, 4, hf(b), "");
        m = hp();
        k = vg(k, 5, m, Ue);
        h = eh(k, 8, h);
        l.sl && Ag(h, 6, cn, bf(Number(l.sl)));
        l.url && Ag(h, 7, cn, hf(l.url));
        g.call(f, h);
      }
      (e != null && e.jn) ||
        ((e = {}),
        Zl(
          xa(
            {},
            ((e.c = String(a)),
            (e.pc = String(Ok())),
            (e.em = c),
            (e.lid = b),
            (e.eids = hp().join()),
            e),
            d
          ),
          "esp"
        ));
    }
  }
  function CJ(a, b) {
    b = b === void 0 ? function () {} : b;
    return new Promise(function (c) {
      var d = function () {
        c(b());
        Ul(a, "load", d);
      };
      Tl(a, "load", d);
    });
  }
  function DJ() {
    var a = window;
    var b = b === void 0 ? function () {} : b;
    var c;
    return ((c = a.document) == null ? void 0 : c.readyState) === "complete"
      ? Promise.resolve(b())
      : CJ(a, b);
  }
  var EJ = function () {
      this.cache = {};
    },
    GJ = function () {
      FJ || (FJ = new EJ());
      return FJ;
    },
    HJ = function (a) {
      var b = Tp(gg(a, 3, void 0, void 0, df));
      if (!b) return 3;
      if (ah(a, 2) === void 0) return 4;
      a = Date.now();
      return a > b + 2592e5 ? 2 : a > b + 432e5 ? 1 : 0;
    };
  EJ.prototype.get = function (a, b, c, d) {
    function e(l) {
      BJ(6, a, l == null ? void 0 : l.message, {}, d);
      f = !0;
    }
    if (this.cache[a]) return { X: this.cache[a], success: !0 };
    var f = !1,
      g = "_GESPSK-" + a;
    b = c ? lJ(g, window, e) : mJ(g, b, e);
    if (f) return { X: null, success: !1 };
    if (!b) return { X: null, success: !0 };
    try {
      var h = Wz(b);
      this.cache[a] = h;
      return { X: h, success: !0 };
    } catch (l) {
      var k;
      BJ(5, a, (k = l) == null ? void 0 : k.message, {}, d);
      return { X: null, success: !1 };
    }
  };
  EJ.prototype.set = function (a, b, c, d) {
    function e(h) {
      BJ(7, f, h == null ? void 0 : h.message, {}, d);
    }
    var f = ah(a, 1),
      g = "_GESPSK-" + f;
    Vz(a);
    if (c ? !nJ(g, a.ha(), window, e) : !oJ(g, a.ha(), b, e)) return !1;
    this.cache[f] = a;
    return !0;
  };
  EJ.prototype.remove = function (a, b, c, d) {
    function e(f) {
      BJ(8, a, f == null ? void 0 : f.message, {}, d);
    }
    c ? pJ("_GESPSK-" + a, window, e) : qJ("_GESPSK-" + a, b, window, e);
    delete this.cache[a];
  };
  var FJ = null;
  var IJ = function (a) {
      var b = new Map();
      a = y(a);
      var c = a.next();
      try {
        for (; !c.done; c = a.next()) {
          var d = c.value,
            e = Yg(d, 1),
            f = void 0,
            g = (f = b.get(e)) != null ? f : new Map(),
            h = y(Kg(d, wj, 2)),
            k = h.next();
          try {
            for (; !k.done; k = h.next()) {
              var l = k.value,
                m = Yg(l, 1);
              g.has(m) || g.set(m, []);
              g.get(m).push(l);
            }
          } finally {
            z(h, k);
          }
          b.set(e, g);
        }
      } finally {
        z(a, c);
      }
      this.h = b;
    },
    JJ = function (a, b, c) {
      var d, e, f;
      return !!((d = a.h) == null
        ? 0
        : (e = d.get(c)) == null
        ? 0
        : (f = e.get(b)) == null
        ? 0
        : f.some(function (g) {
            return Tg(g, 4);
          }));
    },
    KJ = function (a, b) {
      a = y(a.h.values());
      var c = a.next();
      try {
        for (; !c.done; c = a.next()) {
          var d = void 0;
          if (
            (d = c.value.get(b)) == null
              ? 0
              : d.some(function (e) {
                  return Tg(e, 4);
                })
          )
            return !0;
        }
      } finally {
        z(a, c);
      }
      return !1;
    },
    MJ = function (a, b) {
      return LJ(a, b, function (c) {
        return Tg(c, 4);
      });
    },
    LJ = function (a, b, c) {
      var d = new Set();
      a = a.h.get(b);
      if (!a) return d;
      a = y(a.entries());
      b = a.next();
      try {
        for (; !b.done; b = a.next()) {
          var e = y(b.value),
            f = e.next().value,
            g = e.next().value,
            h = f;
          g.some(function (k) {
            return c(k);
          }) && d.add(h);
        }
      } finally {
        z(a, b);
      }
      return d;
    };
  function NJ(a, b, c) {
    b = Yg(b, 1);
    var d;
    if ((d = a.get(b)) == null ? 0 : jf(gg(d, 2)) != null) return !1;
    d = null;
    try {
      var e, f, g, h;
      d =
        (e = c.getUserIdsAsEidBySource) == null
          ? void 0
          : (f = e.call(c, b)) == null
          ? void 0
          : (g = f.uids) == null
          ? void 0
          : (h = g[0]) == null
          ? void 0
          : h.id;
    } catch (l) {
      var k;
      BJ(45, b, (k = l) == null ? void 0 : k.message, {});
      return !1;
    }
    if (!d) return BJ(57, b, null, {}), !1;
    if (d.length > 1024)
      return (
        (a = {}),
        BJ(12, b, null, ((a.sl = String(d.length)), (a.fp = "1"), a)),
        !1
      );
    c = a.set;
    e = Tz(new Sz(), b);
    e = hh(e, 2, d);
    e = bh(e, 11, !0);
    c.call(a, b, e);
    a = {};
    BJ(19, b, null, ((a.fp = "1"), (a.hs = "1"), (a.sl = String(d.length)), a));
    return !0;
  }
  function OJ(a, b, c, d) {
    var e = new Map(),
      f = {};
    BJ(56, "", null, b ? ((f.nc = b), f) : void 0);
    f = d != null ? d : [];
    if (
      b &&
      c &&
      f &&
      typeof c.getUserIdsAsEidBySource === "function" &&
      typeof c.getUserIdsAsEids === "function"
    )
      try {
        var g = y(c.getUserIdsAsEids()),
          h = g.next();
        try {
          for (; !h.done; h = g.next()) {
            var k = h.value;
            if (ae(k.source)) {
              var l = (f = void 0),
                m = void 0,
                p = void 0,
                q = {};
              BJ(
                52,
                k.source,
                null,
                ((q.sl = String(
                  (p =
                    (f = k.uids) == null
                      ? void 0
                      : (l = f[0]) == null
                      ? void 0
                      : (m = l.id) == null
                      ? void 0
                      : m.length) != null
                    ? p
                    : -1
                )),
                q)
              );
            }
          }
        } finally {
          z(g, h);
        }
      } catch (ca) {
        var r;
        BJ(45, "", (r = ca) == null ? void 0 : r.message, {});
      }
    h = d != null ? d : [];
    if (b && c && h && typeof c.getUserIdsAsEidBySource === "function") {
      g = b.split(",");
      h = y(h);
      k = h.next();
      try {
        for (; !k.done; k = h.next()) {
          var t = k.value;
          if (g.includes(Yg(t, 1))) {
            var v = y(Kg(t, wj, 2)),
              x = v.next();
            try {
              for (; !x.done; x = v.next()) {
                var E = x.value;
                Tg(E, Cg(E, xj, 3)) && NJ(e, E, c);
              }
            } finally {
              z(v, x);
            }
          }
        }
      } finally {
        z(h, k);
      }
    }
    PJ(e, b, d != null ? d : [], a);
    a = d != null ? d : [];
    if (b && c && a && typeof c.getUserIdsAsEidBySource === "function") {
      b = b.split(",");
      a = y(a);
      d = a.next();
      try {
        for (; !d.done; d = a.next()) {
          var F = d.value;
          if (b.includes(Yg(F, 1))) {
            var B = y(Kg(F, wj, 2)),
              J = B.next();
            try {
              for (; !J.done; J = B.next()) {
                var Q = J.value,
                  oa = Yg(Q, 1);
                t = void 0;
                ((t = e.get(oa)) == null ? 0 : jf(gg(t, 2)) != null) ||
                  (NJ(e, Q, c) && BJ(58, oa, null, {}));
              }
            } finally {
              z(B, J);
            }
          }
        }
      } finally {
        z(a, d);
      }
    }
    c = new Zz();
    e = y(e);
    F = e.next();
    try {
      for (; !F.done; F = e.next()) {
        var ta = y(F.value);
        ta.next();
        var Da = ta.next().value;
        Qg(c, 2, Sz, Da);
      }
    } finally {
      z(e, F);
    }
    if (!Kg(c, Sz, 2).length) return null;
    ta = {};
    BJ(50, "", null, ((ta.ns = String(Kg(c, Sz, 2).length)), ta));
    return xJ(c.j());
  }
  function PJ(a, b, c, d) {
    var e = new IJ(c),
      f;
    c = Array.from(
      QJ(d, (f = b == null ? void 0 : b.split(",")) != null ? f : [], e)
    );
    f = y(c);
    c = f.next();
    try {
      for (var g = {}; !c.done; g = { pb: void 0 }, c = f.next()) {
        g.pb = c.value;
        var h = void 0;
        if ((h = a.get(g.pb)) == null || jf(gg(h, 2)) == null) {
          var k = (h = void 0),
            l = GJ().get(
              g.pb,
              d,
              RJ(
                g.pb,
                (k = (h = b) == null ? void 0 : h.split(",")) != null ? k : [],
                e
              ),
              void 0
            ).X;
          if (l) {
            var m = HJ(l);
            if (m !== 2 && m !== 3) {
              h = !1;
              if (b) {
                var p = /^(\d+)$/.exec(g.pb);
                if (p && !(h = b.split(",").includes(p[1]))) continue;
                if (
                  !h &&
                  !b.split(",").some(
                    (function (v) {
                      return function (x) {
                        var E = v.pb,
                          F,
                          B;
                        return !!((F = e.h) == null
                          ? 0
                          : (B = F.get(x)) == null
                          ? 0
                          : B.has(E));
                      };
                    })(g)
                  )
                )
                  continue;
              }
              bh(l, 9, h);
              var q = ah(l, 2);
              q &&
                q.length > 1024 &&
                ((h = {}),
                BJ(55, g.pb, null, ((h.sl = String(q.length)), h)),
                Uz(l.Da(Qz(108))));
              a.set(g.pb, l);
              var r = ah(l, 2);
              k = h = void 0;
              var t = {};
              BJ(
                19,
                g.pb,
                null,
                ((t.hs = r ? "1" : "0"),
                (t.sl = String(
                  (k = (h = r) == null ? void 0 : h.length) != null ? k : -1
                )),
                t)
              );
            }
          }
        }
      }
    } finally {
      z(f, c);
    }
  }
  function QJ(a, b, c) {
    for (
      var d = Set, e = [], f = RegExp("^_GESPSK-(.+)$"), g = sJ(a), h, k = 0;
      k < ((h = g) != null ? h : 0);
      k++
    ) {
      var l = uJ(k, a);
      l !== null && (l = (f.exec(l) || [])[1]) && e.push(l);
    }
    a = new d(e);
    b = y(b);
    d = b.next();
    try {
      for (; !d.done; d = b.next()) {
        var m = y(MJ(c, d.value)),
          p = m.next();
        try {
          for (; !p.done; p = m.next()) a.add(p.value);
        } finally {
          z(m, p);
        }
      }
    } finally {
      z(b, d);
    }
    return a;
  }
  function RJ(a, b, c) {
    return b.some(function (d) {
      return JJ(c, a, d);
    });
  }
  var SJ = function (a) {
    a = Error.call(this, a);
    this.message = a.message;
    "stack" in a && (this.stack = a.stack);
    Object.setPrototypeOf(this, SJ.prototype);
    this.name = "InputError";
  };
  w(SJ, Error);
  var TJ = function (a) {
      this.reason = a;
    },
    UJ = function () {
      this.h = !1;
    },
    VJ = function () {
      UJ.apply(this, arguments);
      this.l = new bD();
    };
  w(VJ, UJ);
  var WJ = function (a, b) {
    a.h || ((a.h = !0), (a.o = b), a.l.resolve(b));
  };
  ea.Object.defineProperties(VJ.prototype, {
    promise: {
      configurable: !0,
      enumerable: !0,
      get: function () {
        return this.l.promise;
      },
    },
    Yg: {
      configurable: !0,
      enumerable: !0,
      get: function () {
        return this.h;
      },
    },
    error: {
      configurable: !0,
      enumerable: !0,
      get: function () {
        return this.j;
      },
    },
  });
  var XJ = function () {
    VJ.apply(this, arguments);
  };
  w(XJ, VJ);
  var YJ = function (a, b) {
    b.then(function (c) {
      WJ(a, c);
    }).catch(function (c) {
      a.Da(c);
    });
  };
  XJ.prototype.Da = function (a, b) {
    this.h ||
      ((this.h = !0),
      (this.o = null),
      (this.j = a),
      b && b(this.j),
      this.l.reject(a));
  };
  var ZJ = function (a) {
    this.h = !1;
    this.l = a;
  };
  w(ZJ, UJ);
  ea.Object.defineProperties(ZJ.prototype, {
    error: {
      configurable: !0,
      enumerable: !0,
      get: function () {
        return this.l.j;
      },
    },
  });
  ZJ.prototype.Yg = function () {
    return this.l.h;
  };
  var $J = function (a) {
    ZJ.call(this, a);
    this.l = a;
  };
  w($J, ZJ);
  ea.Object.defineProperties($J.prototype, {
    value: {
      configurable: !0,
      enumerable: !0,
      get: function () {
        var a;
        return (a = this.l.o) != null ? a : null;
      },
    },
  });
  var aK = function () {
    VJ.apply(this, arguments);
  };
  w(aK, VJ);
  aK.prototype.notify = function () {
    WJ(this, null);
  };
  var bK = function (a, b, c) {
    b.then(function () {
      a.notify();
    }).catch(function (d) {
      a.h = !0;
      a.j = d;
      c && c(a.j);
      a.l.reject(d);
    });
  };
  var cK = function () {
    R.apply(this, arguments);
    this.j = [];
    this.h = [];
    this.l = [];
  };
  w(cK, R);
  var dK = function (a, b) {
    a.h.push({ pd: !1, Ce: b });
  };
  cK.prototype.pd = function (a) {
    var b = this.h.find(function (c) {
      return c.Ce === a;
    });
    b && (b.pd = !0);
  };
  cK.prototype.M = function () {
    this.j.length = 0;
    this.l.length = 0;
    this.h.length = 0;
    R.prototype.M.call(this);
  };
  function eK(a, b) {
    var c, d;
    return Ka(function (e) {
      if (e.j == 1)
        return (
          (c = b
            ? a.filter(function (f) {
                return !f.pd;
              })
            : a),
          e.h(
            Promise.all(
              c.map(function (f) {
                return f.Ce.promise;
              })
            ),
            2
          )
        );
      if (a.length === c.length) return e.return();
      d = a.filter(function (f) {
        return f.pd;
      });
      return e.h(
        Promise.race([
          Promise.all(
            d.map(function (f) {
              return f.Ce.promise;
            })
          ),
          new Promise(function (f) {
            return void setTimeout(f, b);
          }),
        ]),
        0
      );
    });
  }
  var fK = function (a, b, c) {
    R.call(this);
    this.id = a;
    this.A = b;
    this.timeoutMs = c;
    this.l = !1;
    this.h = new cK();
    tt(this, this.h);
  };
  w(fK, R);
  fK.prototype.start = function () {
    var a = this,
      b,
      c;
    return Ka(function (d) {
      if (d.j == 1) {
        if (a.l) return d.return();
        a.l = !0;
        d.A(2);
        return d.h(eK(a.h.h, (b = a.C) != null ? b : a.timeoutMs), 4);
      }
      if (d.j != 2) {
        if (!a.Va()) {
          var e = 0,
            f = y(a.h.l),
            g = f.next();
          try {
            for (; !g.done; g = f.next()) {
              if (g.value.l.o == null)
                throw Error("missing input: " + a.id + "/" + e);
              ++e;
            }
          } finally {
            z(f, g);
          }
          e = a.f;
          f = e.apply;
          g = {};
          var h = y(Object.entries(a.inputs)),
            k = h.next();
          try {
            for (; !k.done; k = h.next()) {
              var l = y(k.value),
                m = l.next().value,
                p = l.next().value;
              g[m] = p.value;
            }
          } finally {
            z(h, k);
          }
          l = f.call(e, a, [g].concat(ra(a.B)));
          a.o(l);
        }
        return d.N(0);
      }
      c = d.o();
      if (a.Va()) return d.return();
      c instanceof SJ
        ? a.D(c)
        : c instanceof Error && (a.A.Ya({ methodName: a.id, Sb: c }), a.j(c));
      d.B();
    });
  };
  var gK = function (a, b) {
    b = b === void 0 ? new XJ() : b;
    a.h.j.push(b);
    return b;
  };
  fK.prototype.D = function () {};
  fK.prototype.j = function (a) {
    if (this.h.j.length) {
      var b = new SJ(a.message),
        c = y(this.h.j),
        d = c.next();
      try {
        for (; !d.done; d = c.next()) {
          var e = d.value;
          if (!e.Yg) {
            var f = e,
              g = b;
            f.h = !0;
            f.j = g;
            f.l.reject(g);
          }
        }
      } finally {
        z(c, d);
      }
    }
    if (!(a instanceof SJ)) {
      var h;
      (h = console) == null || h.error(a);
    }
  };
  var hK = function (a, b, c, d, e) {
    fK.call(this, a, c);
    this.f = b;
    this.B = e;
    a = {};
    d = y(Object.entries(d));
    b = d.next();
    try {
      for (; !b.done; b = d.next()) {
        var f = y(b.value),
          g = f.next().value,
          h = f.next().value;
        h && (dK(this.h, h), (a[g] = new $J(h)));
      }
    } finally {
      z(d, b);
    }
    this.inputs = a;
  };
  w(hK, fK);
  hK.prototype.D = function (a) {
    this.j(a);
  };
  hK.prototype.reportError = function () {};
  var iK = function (a, b) {
    if (a.l) throw Error("Invalid operation: producer has already started");
    dK(a.h, b);
    return a;
  };
  var jK = function (a, b, c, d, e, f) {
    hK.call(this, a, b, c, d, f);
    this.Ba = e;
    this.output = gK(this, new XJ());
    this.complete = new aK();
  };
  w(jK, hK);
  jK.prototype.o = function (a) {
    var b = this;
    a.then(
      function (c) {
        c instanceof TJ || (WJ(b.output, c), b.complete.notify());
      },
      function (c) {
        b.Ba
          ? WJ(b.output, b.Ba(c))
          : b.output.Da(new SJ("output error: " + c.message), function () {
              b.A.Ya({ methodName: b.id, Sb: c });
            });
        b.complete.notify();
      }
    );
  };
  jK.prototype.j = function (a) {
    this.Ba
      ? (WJ(this.output, this.Ba(a)), this.complete.notify())
      : hK.prototype.j.call(this, a);
  };
  function kK(a, b) {
    a.id = b.id;
    a.Ba = b.Ba;
    return a;
  }
  function lK(a, b, c) {
    return new jK(a.id, a, b, c, a.Ba, La.apply(3, arguments));
  }
  var mK = function (a, b, c, d, e, f, g) {
    hK.call(this, a, b, c, d, g);
    this.Ba = f;
    this.finished = new aK();
    a = Object.keys(e);
    a = y(a);
    b = a.next();
    try {
      for (; !b.done; b = a.next()) this[b.value] = gK(this);
    } finally {
      z(a, b);
    }
  };
  w(mK, hK);
  mK.prototype.o = function (a) {
    a = y(Object.entries(a));
    var b = a.next();
    try {
      for (; !b.done; b = a.next()) {
        var c = y(b.value),
          d = c.next().value,
          e = c.next().value,
          f = d,
          g = e;
        g instanceof Error && this[f].Da(g);
        g instanceof TJ || WJ(this[f], g);
      }
    } finally {
      z(a, b);
    }
    this.finished.notify();
  };
  mK.prototype.j = function (a) {
    this.Ba ? this.o(this.Ba(a)) : hK.prototype.j.call(this, a);
  };
  function nK(a, b) {
    a.id = b.id;
    a.pa = b.pa;
    a.Ba = b.Ba;
    return a;
  }
  function oK(a, b, c) {
    return new mK(a.id, a, b, c, a.pa, a.Ba, La.apply(3, arguments));
  }
  var pK = function (a) {
    R.call(this);
    this.C = a;
    this.B = [];
    this.H = [];
    this.D = {};
    this.l = [];
    this.j = new bD();
    this.A = {};
  };
  w(pK, R);
  var qK = function (a, b) {
    tt(a, b);
    a.B.push(b);
    return b;
  };
  pK.prototype.h = function (a, b) {
    return qK(
      this,
      oK.apply(null, [a, this.C, b].concat(ra(La.apply(2, arguments))))
    );
  };
  pK.prototype.o = function (a, b) {
    return qK(
      this,
      lK.apply(null, [a, this.C, b].concat(ra(La.apply(2, arguments))))
    );
  };
  var sK = function (a) {
      var b, c, d, e, f, g, h, k, l, m, p, q, r;
      Ka(function (t) {
        switch (t.j) {
          case 1:
            if (!a.l.length) {
              t.ia(2);
              break;
            }
            return t.h(
              Promise.all(
                a.l.map(function (v) {
                  return v.j.promise;
                })
              ),
              2
            );
          case 2:
            return t.h(rK(), 4);
          case 4:
            b = t.l;
            if (!b) return a.j.resolve(a.D), t.return(a.j.promise);
            c = y(a.B);
            d = c.next();
            try {
              for (; !d.done; d = c.next()) (e = d.value), e.start();
            } finally {
              z(c, d);
            }
            f = y(a.H);
            g = f.next();
            try {
              for (; !g.done; g = f.next()) (h = g.value), sK(h);
            } finally {
              z(f, g);
            }
            if (!a.A) {
              t.ia(5);
              break;
            }
            k = Object.keys(a.A);
            if (!k.length) {
              t.ia(5);
              break;
            }
            return t.h(
              Promise.all(
                Object.values(a.A).map(function (v) {
                  return v.promise;
                })
              ),
              7
            );
          case 7:
            l = t.l;
            m = 0;
            p = y(k);
            q = p.next();
            try {
              for (; !q.done; q = p.next()) (r = q.value), (a.D[r] = l[m++]);
            } finally {
              z(p, q);
            }
          case 5:
            return a.j.resolve(a.D), t.return(a.j.promise);
        }
      });
    },
    rK = function () {
      return Ka(function (a) {
        return a.return(!0);
      });
    };
  pK.prototype.M = function () {
    R.prototype.M.call(this);
    this.B.length = 0;
    this.H.length = 0;
    this.l.length = 0;
  };
  var uK = nK(tK, { id: 1041, pa: {} });
  function tK(a, b, c) {
    if (!a.X) return {};
    GJ().set(a.X, a.Aa, b) &&
      jf(gg(a.X, 2)) != null &&
      BJ(27, ah(a.X, 1), null, {}, c);
    return {};
  }
  var vK = nK(
    function (a) {
      var b = a.Aa;
      if ((a = a.Wj)) {
        a = y(a);
        var c = a.next();
        try {
          for (; !c.done; c = a.next()) {
            var d = y(Kg(c.value, wj, 2)),
              e = d.next();
            try {
              for (; !e.done; e = d.next()) {
                var f = e.value;
                Tg(f, 4) && GJ().remove(Yg(f, 1), b, !0);
              }
            } finally {
              z(d, e);
            }
          }
        } finally {
          z(a, c);
        }
      }
      if (yI(b)) {
        if (b) {
          var g;
          d = (g = wJ(b)) != null ? g : [];
          g = y(d);
          d = g.next();
          try {
            for (; !d.done; d = g.next()) {
              var h = d.value;
              h.startsWith("_GESPSK") && qJ(h, b);
            }
          } finally {
            z(g, d);
          }
        }
        FJ = new EJ();
      }
      return {};
    },
    { id: 1094, pa: {} }
  );
  var wK = nK(
    function (a, b, c) {
      var d = a.X;
      a = function (e) {
        var f = {};
        BJ(
          e,
          ah(d, 1),
          null,
          ((f.tic = String(
            Math.round((Date.now() - Tp(gg(d, 3, void 0, void 0, df))) / 6e4)
          )),
          f),
          c
        );
      };
      switch (HJ(d)) {
        case 0:
          return (
            a(24), { Bb: new TJ("FRESH_ENTRY"), Tb: new TJ("FRESH_ENTRY") }
          );
        case 1:
          return a(25), { Bb: new TJ("STALE_ENTRY"), Tb: d };
        case 2:
          return a(26), { Bb: d, Tb: new TJ("EXPIRED_ENTRY") };
        case 3:
          return (
            BJ(9, ah(d, 1), null, {}, c), { Bb: d, Tb: new TJ("ERROR_ENTRY") }
          );
        case 4:
          return a(23), { Bb: d, Tb: new TJ("NEW_ENTRY") };
        default:
          return { Bb: new TJ("DEFAULT_ENTRY"), Tb: new TJ("DEFAULT_ENTRY") };
      }
    },
    { id: 1048, pa: { Bb: void 0, Tb: void 0 } }
  );
  var xK = nK(
    function (a, b, c, d, e, f) {
      if ((a = GJ().get(b, d, c, f).X))
        return { Ia: a, ya: new TJ("CACHED_ENTRY") };
      a = Vz(Tz(new Sz(), b));
      return { Ia: a, ya: a.Da(Qz(100)) };
    },
    { id: 1027, pa: { Ia: void 0, ya: void 0 } }
  );
  var zK = nK(yK, { id: 1046, pa: { La: void 0 } });
  function yK(a) {
    return { La: a.Ia };
  }
  var AK = nK(
    function (a) {
      var b = a.Zf;
      a = a.X;
      return b.ya
        ? { Af: a.Da(b.ya), Ia: new TJ(), signal: new TJ() }
        : { Ia: b.Ia, Af: new TJ(), signal: b.signal };
    },
    { id: 1479, pa: { Ia: void 0, Af: void 0, signal: void 0 } }
  );
  function BK(a) {
    return ae(a) ? a : a instanceof Error ? a.message : null;
  }
  var CK = kK(
    function (a, b, c) {
      var d, e;
      return Ka(function (f) {
        d = Bn();
        e = jf(gg(a.X, 1));
        BJ(18, e, null, {}, c);
        try {
          return f.return(
            b()
              .then(function (g) {
                BJ(29, e, null, { delta: String(Bn() - d) }, c);
                return { Ia: hh(a.X, 2, g), ya: null, signal: g };
              })
              .catch(function (g) {
                BJ(28, e, BK(g), {}, c);
                return { Ia: null, ya: Qz(106), signal: null };
              })
          );
        } catch (g) {
          return (
            BJ(1, e, BK(g), {}, c),
            f.return({ Ia: null, ya: Qz(107), signal: null })
          );
        }
      });
    },
    { id: 1478 }
  );
  var EK = nK(DK, { id: 1028, pa: { La: void 0 } });
  function DK(a, b) {
    var c = ah(a.X, 1);
    var d = gg(a.X, 3, void 0, void 0, df);
    if (d != null)
      if (typeof d === "bigint")
        re(d)
          ? (d = Number(d))
          : ((d = Ie(64, d)), (d = re(d) ? Number(d) : String(d)));
      else if (Re(d)) {
        var e;
        typeof d === "number" ? (e = af(d)) : (e = Ye(d));
        d = e;
      } else d = void 0;
    d != null || BJ(35, c, null, {}, b);
    return { La: a.X };
  }
  var GK = nK(FK, { id: 1050, pa: { La: void 0 } });
  function FK(a, b, c) {
    var d = ah(a.X, 1);
    if (a.signal == null)
      return BJ(41, d, null, {}, c), a.X.Da(Qz(111)), { La: a.X };
    if (!ae(a.signal)) return BJ(21, d, null, {}, c), { La: a.X.Da(Qz(113)) };
    if (a.signal.length > b)
      return (
        (b = {}),
        BJ(12, d, null, ((b.sl = String(a.signal.length)), b), c),
        Uz(a.X.Da(Qz(108))),
        { La: a.X }
      );
    a.signal.length || BJ(20, d, null, {}, c);
    jg(a.X, 10);
    return { La: a.X };
  }
  var HK = function (a, b, c) {
    this.output = new aK();
    bK(this.output, a, function (d) {
      return void c.Ya({ methodName: b, Sb: d });
    });
  };
  var IK = function (a, b) {
    HK.call(this, a, 1046, b);
  };
  w(IK, HK);
  var JK = function (a, b, c, d, e, f, g) {
    f = f === void 0 ? yJ : f;
    pK.call(this, e, 2);
    this.F = new XJ();
    var h = this.h(xK, {}, a, b, d, e),
      k = new XJ();
    WJ(k, d);
    this.h(uK, { X: h.ya, Aa: k }, b, g);
    d = this.h(EK, { X: h.Ia }, g);
    d = this.h(wK, { X: d.La }, e, g);
    h = this.o(CK, { X: d.Bb }, c, g);
    h = this.h(AK, { Zf: h.output, X: d.Bb });
    var l = h.signal,
      m = h.Ia;
    this.h(uK, { X: h.Af, Aa: k }, b, g);
    h = this.h(GK, { X: m, signal: l }, 1024, g);
    this.h(uK, { X: h.La, Aa: k }, b, g);
    f = f.Uj ? DJ() : CJ(window);
    e = new IK(f, e);
    e = iK(this.h(zK, { Ia: d.Tb }), e.output);
    c = this.o(CK, { X: e.La }, c, g);
    c = this.h(AK, { Zf: c.output, X: e.La }).Ia;
    this.h(uK, { X: c, Aa: k }, b, g);
    b = h.La.promise
      .then(function (p) {
        var q;
        return {
          id: a,
          collectorGeneratedData:
            (q = p == null ? void 0 : jf(gg(p, 2))) != null ? q : null,
        };
      })
      .catch(function () {
        return { id: a, collectorGeneratedData: null };
      });
    YJ(this.F, b);
  };
  w(JK, pK);
  var KK = kK(
    function (a, b, c, d, e) {
      d = d === void 0 ? yJ : d;
      var f, g, h, k, l, m, p, q, r, t, v;
      return Ka(function (x) {
        g = new IJ((f = a.Xj) != null ? f : []);
        h = a.xb;
        k = h.id;
        l = h.networkCode;
        m = h.collectorFunction;
        q = (p = l) != null ? p : k;
        r = !!((k && KJ(g, k)) || KJ(g, q));
        if (!yI(a.Aa) && !r)
          return x.return(new TJ("Storage consent not granted."));
        t = {};
        BJ(42, q, null, ((t.ea = String(Number(b))), t), e);
        v = new JK(q, r, m, a.Aa, c, d, e);
        sK(v);
        return x.return(v.F.promise);
      });
    },
    { id: 1059 }
  );
  var LK = nK(
    function (a, b, c, d, e) {
      d = d === void 0 ? yJ : d;
      if (!b)
        return (
          BJ(39, "UNKNOWN_COLLECTOR_ID", null, {}, e),
          { ya: Tz(new Sz(), "UNKNOWN_COLLECTOR_ID").Da(Qz(110)), xb: new TJ() }
        );
      if (typeof b !== "object")
        return (
          BJ(46, "UNKNOWN_COLLECTOR_ID", null, {}, e),
          { ya: Tz(new Sz(), "UNKNOWN_COLLECTOR_ID").Da(Qz(112)), xb: new TJ() }
        );
      a = b.id;
      c = b.networkCode;
      a && c && (delete b.id, BJ(47, a + ";" + c, null, {}, e));
      a = c != null ? c : a;
      return ae(a)
        ? typeof b.collectorFunction !== "function"
          ? (BJ(14, a, null, {}, e),
            { ya: Tz(new Sz(), a).Da(Qz(105)), xb: new TJ() })
          : d.Ii.includes(a)
          ? (BJ(22, a, null, {}, e),
            { ya: Tz(new Sz(), a).Da(Qz(104)), xb: new TJ() })
          : { ya: null, xb: b }
        : ((b = {}),
          BJ(
            37,
            "INVALID_COLLECTOR_ID",
            null,
            ((b.ii = JSON.stringify(a)), b),
            e
          ),
          {
            ya: Tz(new Sz(), "INVALID_COLLECTOR_ID").Da(Qz(102)),
            xb: new TJ(),
          });
    },
    { id: 1057, pa: { ya: void 0, xb: void 0 } }
  );
  var NK = function (a, b, c, d, e, f, g) {
    var h = document;
    h = h === void 0 ? document : h;
    g = g === void 0 ? yJ : g;
    this.o = b;
    this.F = c;
    this.H = d;
    this.D = h;
    this.V = e;
    this.B = f;
    this.l = g;
    this.j = void 0;
    this.N = [];
    this.C = [];
    this.h = new MK();
    this.A = 0;
    a = y(a);
    b = a.next();
    try {
      for (; !b.done; b = a.next()) this.push(b.value);
    } finally {
      z(a, b);
    }
  };
  NK.prototype.push = function (a) {
    this.H || this.V();
    var b = new pK(this.h, 3);
    a = b.h(LK, {}, a, this.h, this.l, this.j);
    var c = a.xb;
    b.h(uK, { X: a.ya, Aa: this.o }, void 0, this.j);
    a = b.o(
      KK,
      { xb: c, Aa: this.o, Xj: this.F },
      this.H,
      this.h,
      this.l,
      this.j
    ).output.promise;
    sK(b);
    this.N.push(a);
    b = y(this.C);
    c = b.next();
    try {
      for (; !c.done; c = b.next()) a.then(c.value);
    } finally {
      z(b, c);
    }
  };
  NK.prototype.addOnSignalResolveCallback = function (a) {
    this.C.push(a);
    var b = y(this.N),
      c = b.next();
    try {
      for (; !c.done; c = b.next()) c.value.then(a);
    } finally {
      z(b, c);
    }
  };
  var OK = function (a, b) {
    a.h.h.push(b);
  };
  NK.prototype.clearAllCache = function () {
    var a = this,
      b =
        this.D.currentScript instanceof HTMLScriptElement
          ? this.D.currentScript.src
          : "";
    if (this.A === 1) {
      var c = {};
      BJ(49, "", null, ((c.url = b), c), this.j);
    } else if (this.l.zi.includes(String(jq(b != null ? b : ""))))
      (c = {}), BJ(48, "", null, ((c.url = b), c), this.j);
    else {
      this.B && this.B();
      var d = new pK(this.h, 4);
      c = d.h(vK, { Aa: this.o, Wj: this.F }, this.h);
      sK(d);
      this.A = 1;
      setTimeout(function () {
        a.A = 0;
      }, this.l.wi * 1e3);
      d = {};
      BJ(43, "", null, ((d.url = b), d), this.j);
      return c.finished.promise;
    }
  };
  var MK = function () {
    this.h = [];
  };
  MK.prototype.Ya = function (a) {
    this.h.forEach(function (b) {
      return void b.Ya(a);
    });
  };
  var PK = function (a) {
    this.push = function (b) {
      a.push(b);
    };
    this.addOnSignalResolveCallback = function (b) {
      a.addOnSignalResolveCallback(b);
    };
    this.addErrorHandler = function (b) {
      OK(a, {
        Ya: function (c) {
          return void b(c.methodName, c.Sb);
        },
      });
    };
    this.clearAllCache = function () {
      a.clearAllCache();
    };
  };
  function QK(a, b, c, d, e, f, g, h) {
    h = h === void 0 ? yJ : h;
    if (
      !RK(a, "encryptedSignalProviders", d, g) ||
      !RK(a, "secureSignalProviders", d, g)
    ) {
      BJ(38, "", null, {});
      var k = {
        Ya: function (l) {
          return void d(l.methodName, l.Sb);
        },
      };
      SK(a, "encryptedSignalProviders", b, c, h, k, e, f, g);
      SK(a, "secureSignalProviders", b, c, h, k, function () {}, f, g);
    }
  }
  function RK(a, b, c, d) {
    a =
      b === "secureSignalProviders"
        ? a.secureSignalProviders
        : a.encryptedSignalProviders;
    if (a === void 0 || a instanceof Array) return !1;
    d && a.addOnSignalResolveCallback(d);
    a.addErrorHandler(c);
    return !0;
  }
  function SK(a, b, c, d, e, f, g, h, k) {
    var l =
      b === "secureSignalProviders"
        ? a.secureSignalProviders
        : a.encryptedSignalProviders;
    c = new NK(
      l instanceof Array ? l : [],
      c,
      d,
      b === "secureSignalProviders",
      g,
      h,
      e
    );
    d = new PK(c);
    b === "secureSignalProviders"
      ? (a.secureSignalProviders = d)
      : (a.encryptedSignalProviders = d);
    k && c.addOnSignalResolveCallback(k);
    OK(c, f);
  }
  function TK(a, b, c, d, e, f) {
    var g = g === void 0 ? yJ : g;
    var h = new XJ();
    WJ(h, b);
    QK(a, h, void 0, c, d, e, f, g);
  }
  function UK(a, b, c, d) {
    var e = VK,
      f = WK,
      g = new XJ();
    WJ(g, c);
    var h = new Map();
    c = b
      .flatMap(function (l) {
        return Kg(l, wj, 2).map(function (m) {
          return Yg(m, 1);
        });
      })
      .map(function (l) {
        return new Promise(function (m) {
          h.set(l, m);
        });
      });
    var k = new XJ();
    WJ(k, b);
    QK(a, g, k, d, e, f, function (l) {
      var m = l.collectorGeneratedData;
      l = l.id;
      var p;
      return void ((p = h.get(l)) == null
        ? void 0
        : p({ collectorGeneratedData: m, id: l }));
    });
    return c;
  }
  function XK(a, b, c, d) {
    var e = VK,
      f = WK,
      g = new Map();
    b = b.map(function (h) {
      var k = h.Bi;
      return new Promise(function (l) {
        g.set(k, l);
      });
    });
    TK(a, c, d, e, f, function (h) {
      var k = h.collectorGeneratedData;
      h = h.id;
      var l;
      return void ((l = g.get(h)) == null
        ? void 0
        : l({ collectorGeneratedData: k, id: h }));
    });
    return b;
  }
  function YK() {
    var a;
    return (a = C.googletag) != null ? a : (C.googletag = { cmd: [] });
  }
  function ZK(a, b) {
    a = II(a);
    if (!yI(a)) return !1;
    TK(YK(), a, function () {}, VK, WK, b);
    return !0;
  }
  function $K(a, b) {
    b = II(b);
    return yI(b) && a.length !== 0 ? UK(YK(), a, b, function () {}) : null;
  }
  function aL(a, b) {
    b = II(b);
    return yI(b) && a.length !== 0 ? XK(YK(), a, b, function () {}) : null;
  }
  function WK() {}
  function VK() {}
  function bL(a, b, c, d) {
    return OJ(II(a), b, c, d);
  }
  function cL(a, b, c, d) {
    var e = new bD(),
      f = "",
      g = function (k) {
        try {
          var l = typeof k.data === "object" ? k.data : JSON.parse(k.data);
          f === l.paw_id &&
            (Ul(a, "message", g),
            l.error ? e.reject(Error(l.error)) : e.resolve(d(l)));
        } catch (m) {}
      },
      h = dL(a);
    return h
      ? (Tl(a, "message", g), (f = c(h)), e.promise)
      : (c = eL(a))
      ? ((f = String(Math.floor(Dk() * 2147483647))),
        Tl(a, "message", g),
        b(c, f),
        e.promise)
      : null;
  }
  function fL(a) {
    return cL(
      a,
      function (b, c) {
        var d, e;
        return void ((d = (e = b.getGmaQueryInfo) != null ? e : b.getGmaSig) ==
        null
          ? void 0
          : d.postMessage(c));
      },
      function (b) {
        return b.getQueryInfo();
      },
      function (b) {
        return b.signal;
      }
    );
  }
  function gL() {
    var a = window;
    return !!dL(a) || !!eL(a);
  }
  function dL(a) {
    var b;
    if (
      typeof ((b = a.gmaSdk) == null ? void 0 : b.getQueryInfo) === "function"
    )
      return a.gmaSdk;
  }
  function eL(a) {
    var b, c, d, e, f, g;
    if (
      typeof ((b = a.webkit) == null
        ? void 0
        : (c = b.messageHandlers) == null
        ? void 0
        : (d = c.getGmaQueryInfo) == null
        ? void 0
        : d.postMessage) === "function" ||
      typeof ((e = a.webkit) == null
        ? void 0
        : (f = e.messageHandlers) == null
        ? void 0
        : (g = f.getGmaSig) == null
        ? void 0
        : g.postMessage) === "function"
    )
      return a.webkit.messageHandlers;
  }
  var iL = function () {
      this.timeoutMs = hL;
      this.j = fL;
      this.signal = null;
      this.h = 0;
    },
    jL = function (a) {
      if (!gL() || (!Kc && !TC() && !sq(kB))) return Promise.resolve(null);
      var b;
      return ((b = a.j(window)) != null ? b : Promise.resolve(null)).catch(
        function () {
          return "0";
        }
      );
    },
    lL = function (a) {
      var b;
      return Ka(function (c) {
        if (c.j == 1)
          return (
            (b = Date.now() - a.h),
            !a.signal || b > 3e5 ? c.h(kL(a), 3) : c.ia(2)
          );
        c.j != 2 && ((a.signal = c.l), (a.h = Date.now()));
        return c.return(a.signal);
      });
    },
    kL = function (a) {
      return Promise.race([
        jL(a).then(function (b) {
          if (b == null) return null;
          a.signal = b.length > 1e4 ? "0" : b;
          a.h = Date.now();
          return a.signal;
        }),
        $y(a.timeoutMs, "0"),
      ]);
    };
  function io(a, b) {
    return b instanceof RegExp ? "__REGEXP" + b.toString() : b;
  }
  function mL(a, b) {
    return b && b.toString().indexOf("__REGEXP") === 0
      ? ((a = b.split("__REGEXP")[1].match(/\/(.*)\/(.*)?/)),
        new RegExp(a[1], a[2] || ""))
      : b;
  }
  var pL = function (a, b, c) {
    tI.call(this, b);
    var d = this;
    this.l = a;
    this.h = null;
    this.o = new zD(this);
    this.o.listen(ol(), "message", function (e) {
      try {
        a: {
          var f = e.Jc,
            g = nL(f.data);
          if (oL(d, g)) {
            if (d.h === null) (d.h = f.source), d.connected || d.connect();
            else if (d.h !== f.source) break a;
            oL(d, g) &&
              d.dispatchEvent(
                new vI(
                  g.name,
                  g.type,
                  g.data || {},
                  g.sid,
                  f.origin,
                  g.id,
                  g.replyToMessageId
                )
              );
          }
        }
      } catch (h) {
        throw (c == null || c.Ya({ Sb: h }), h);
      }
    });
  };
  w(pL, tI);
  var nL = function (a) {
    if (a == null || typeof a !== "string" || !a.startsWith("ima://"))
      return null;
    a = a.substr(6);
    try {
      return JSON.parse(a, mL);
    } catch (b) {
      return null;
    }
  };
  pL.prototype.sendMessage = function (a) {
    if (this.h != null && this.h.postMessage != null) {
      var b = this.h,
        c = b.postMessage,
        d = {};
      d.name = a.name;
      d.type = a.type;
      a.data != null && (d.data = a.data);
      a.id && (d.id = a.id);
      a.h && (d.replyToMessageId = a.h);
      d.sid = this.sessionId;
      d.channel = this.l;
      a = "ima://" + new ho().ha(d);
      c.call(b, a, "*");
    }
    this.h != null && this.h.postMessage == null && W.getInstance().report(11);
  };
  pL.prototype.M = function () {
    qt(this.o);
    this.h = null;
    tI.prototype.M.call(this);
  };
  var oL = function (a, b) {
    if (b == null) return !1;
    var c = b.channel;
    if (c == null || c !== a.l) return !1;
    b = b.sid;
    return !(b == null || (a.sessionId !== "*" && b !== a.sessionId));
  };
  var qL = function () {
    S.call(this);
    this.F = !1;
    this.h = null;
    this.A = this.C = this.K = !1;
    this.j = 0;
    this.o = [];
    this.B = !1;
    this.R = this.O = Infinity;
    this.l = 0;
    this.H = {};
    this.J = new zD(this);
    tt(this, this.J);
  };
  w(qL, S);
  qL.prototype.Pb = function (a) {
    a == null || this.F || ((this.h = a), rL(this), (this.F = !0));
  };
  qL.prototype.Ra = function () {
    this.h != null &&
      this.F &&
      (sL(this),
      (this.A = this.C = this.F = !1),
      (this.j = 0),
      (this.o = []),
      (this.B = !1));
  };
  var rL = function (a) {
      sL(a);
      !(a.h instanceof S) && "ontouchstart" in document.documentElement && Kc
        ? ((a.H = {
            touchstart: function (b) {
              a.C = !0;
              a.j = b.touches.length;
              a.l && (window.clearTimeout(a.l), (a.l = 0), (a.K = !0));
              a.B = tL(a, b.touches) || b.touches.length !== 1;
              a.B
                ? ((a.O = Infinity), (a.R = Infinity))
                : ((a.O = b.touches[0].clientX), (a.R = b.touches[0].clientY));
              b = b.touches;
              a.o = [];
              for (var c = 0; c < b.length; c++) a.o.push(b[c].identifier);
            },
            touchmove: function (b) {
              a.j = b.touches.length;
              if (
                !Kc ||
                !SC(QC, 8) ||
                Math.pow(b.changedTouches[0].clientX - a.O, 2) +
                  Math.pow(b.changedTouches[0].clientY - a.R, 2) >
                  25
              )
                a.A = !0;
            },
            touchend: function (b) {
              return void uL(a, b);
            },
          }),
          Sk(a.H, function (b, c) {
            a.h.addEventListener(c, b, !1);
          }))
        : a.J.listen(a.h, "click", a.T);
    },
    sL = function (a) {
      a.J.Ma(a.h, "click", a.T);
      Sk(
        a.H,
        function (b, c) {
          this.h.removeEventListener(c, b, !1);
        },
        a
      );
      a.H = {};
    },
    uL = function (a, b) {
      !a.C ||
        a.j !== 1 ||
        a.A ||
        a.K ||
        a.B ||
        !tL(a, b.changedTouches) ||
        (a.l = window.setTimeout(function () {
          return void vL(a);
        }, 300));
      a.j = b.touches.length;
      a.j === 0 && ((a.C = !1), (a.A = !1), (a.o = []));
      a.K = !1;
    };
  qL.prototype.T = function () {
    vL(this);
  };
  var tL = function (a, b) {
      for (var c = 0; c < b.length; c++)
        if (a.o.includes(b[c].identifier)) return !0;
      return !1;
    },
    vL = function (a) {
      a.l = 0;
      a.dispatchEvent(new Vx("click"));
    };
  qL.prototype.M = function () {
    this.Ra();
    S.prototype.M.call(this);
  };
  var wL = function (a) {
      return Ka(function (b) {
        return b.j == 1
          ? b.h(a.h.promise, 2)
          : b.return({
              serializedConfig: a.serializedConfig,
              errorMessage: a.j,
              latencyMs: a.l,
            });
      });
    },
    AL = function () {
      var a = xL,
        b = yL,
        c = Date.now(),
        d = a.o();
      d.timeout = 6e4;
      d.open("GET", b, !0);
      d.onload = function () {
        a.l = Date.now() - c;
        d.status < 200 || d.status >= 300
          ? zL(a, Error("status: " + d.status))
          : ((a.j = null),
            (a.serializedConfig = d.responseText),
            a.h.resolve());
      };
      d.onerror = function () {
        a.l = Date.now() - c;
        zL(a, Error("status: " + d.status));
      };
      d.send();
    },
    zL = function (a, b) {
      a.serializedConfig = null;
      a.j = b.message;
      a.h.resolve();
    },
    BL = new (function () {
      this.o = function () {
        return new XMLHttpRequest();
      };
      this.h = new bD();
      this.j = this.serializedConfig = null;
      this.l = 0;
    })();
  function CL() {
    var a = DL;
    var b = a.appName;
    var c = a.We;
    a = a.pageUrl;
    var d = new URL(
      "https://securepubads.g.doubleclick.net/pagead/ima_ppub_config"
    );
    if (b && c) {
      switch (c) {
        case "android":
          d.searchParams.set("msid", b);
          break;
        case "ios":
        case "tvos":
        case "kepler":
          d.searchParams.set("an", b);
      }
      return d.toString();
    }
    return a ? (d.searchParams.set("ippd", a), d.toString()) : null;
  }
  var EL = [0, ij, Dj];
  var FL = function (a) {
    this.G = I(a);
  };
  w(FL, K);
  var GL = nj([0, ij, Dj, ij, EL]);
  function HL(a, b, c, d) {
    var e, f, g;
    a = (
      (g =
        (e = Ig(a, vj, 2)) == null
          ? void 0
          : (f = Kg(e, uj, 1)) == null
          ? void 0
          : f.map(function (h) {
              return Yg(h, 1);
            })) != null
        ? g
        : []
    ).some(function (h) {
      return h === b;
    });
    W.getInstance().report(190, { fm: a, fl: c, nc: b, t: d, b: "csWeb" });
  }
  function IL(a, b) {
    if (!b)
      return (
        W.getInstance().report(196, {
          status: !1,
          optOutReason: "noNetworkCode",
          network: b,
        }),
        !1
      );
    if (!a) return !1;
    if ((a = Ig(a, tj, 3)) == null) a = void 0;
    else {
      var c = a.G,
        d = c[H] | 0;
      a = ug(a, c, d, Pd(a, d));
      a = a == null ? void 0 : a.get(b);
    }
    W.getInstance().report(196, {
      status: a,
      optOutReason: a ? null : a === void 0 ? "codeNotFound" : "optedOutInFe",
      network: b,
    });
    return a != null ? a : !1;
  }
  function JL(a, b) {
    if (!a || !b) return !1;
    var c;
    return !(
      (c = Ig(a, sj, 5)) == null ||
      !Kg(c, rj, 1).find(function (d) {
        return (
          (d == null ? void 0 : Yg(d, 1)) === b &&
          (d == null ? void 0 : Tg(d, 2))
        );
      })
    );
  }
  function KL(a) {
    var b = { cg: 0, Cg: !1, Ed: !1, jc: null, We: null };
    a = a === void 0 ? !1 : a;
    var c = aI(U);
    if ((c && YH(c, "forceCustomPlayback")) || U.Eb()) return !0;
    if (TC() && a) return !1;
    a =
      a &&
      (TC() || (Kc && SC(QC, 10))) &&
      U.getDisableCustomPlaybackForIOS10Plus();
    return !(((!Hc && !Jc) || a) && (!Gc || (Gc && SC(RC, 4))) && !LL(b));
  }
  function ML(a) {
    var b = { cg: 0, Cg: !1, Ed: !1, jc: null, We: null };
    return a === null
      ? !1
      : U.Eb()
      ? !0
      : Kc || TC()
      ? UC(a)
        ? !(
            TC() ||
            (Kc && SC(QC, 10) && U.getDisableCustomPlaybackForIOS10Plus())
          )
        : !0
      : !((!Gc || (Gc && SC(RC, 4))) && !LL(b));
  }
  function NL() {
    var a = aI(U);
    return a && YH(a, "disableOnScreenDetection")
      ? !1
      : !(navigator && Ls(navigator)) && !Ks();
  }
  function LL(a) {
    return OL(a) === 1 || OL(a) === 2;
  }
  function OL(a) {
    var b = a.cg;
    var c = a.Cg;
    var d = a.Ed;
    var e = a.jc;
    a = a.We;
    switch (b) {
      case 1:
        return 3;
      case 2:
        return 1;
    }
    b = C.navigator || null;
    return c || d || e || (b && Ls(b)) || a === "tvos" || a === "kepler"
      ? 1
      : Ms()
      ? 2
      : 0;
  }
  var PL = function (a, b) {
    R.call(this);
    var c = this;
    this.h = a;
    this.j = new Map();
    this.l = function (d) {
      var e = c.j.get(d.messageType);
      if (e) {
        var f = vk(),
          g = d.getId();
        e(d.ra).then(function (h) {
          uI(c.h, d.type, d.messageType, h, f, g);
        });
      }
    };
    this.h.listen(b, this.l);
    rt(this, function () {
      c.j.clear();
      c.h.Ma(b, c.l);
    });
  };
  w(PL, R);
  var QL = function (a, b, c) {
    a.j.set(b, c);
  };
  function RL(a) {
    return Ka(function (b) {
      return b.return(
        new Promise(function (c) {
          setTimeout(function () {
            c(void 0);
          }, a);
        })
      );
    });
  }
  function SL(a, b, c, d, e, f) {
    if (sq(mB) && b && b.length !== 0) {
      var g = Bn();
      b = b.map(function (h, k) {
        var l, m, p, q;
        return Ka(function (r) {
          switch (r.j) {
            case 1:
              return (
                (m = (l = a[k]) ? Kg(l, wj, 2) : []),
                (p = m.length > 0 ? Yg(m[0], 1) : ""),
                (q = 0),
                r.A(2, 3),
                r.h(Promise.race([h, RL(500)]), 3)
              );
            case 3:
              r.V();
              q = Bn() - g;
              r.J(4);
              break;
            case 2:
              r.o();
              r.ia(3);
              break;
            case 4:
              return r.return({ tc: p, kg: q });
          }
        });
      });
      Promise.all(b).then(function (h) {
        var k = new Set();
        if (f)
          try {
            var l = ad(f),
              m = aA(l),
              p = y(Kg(m, Sz, 2)),
              q = p.next();
            try {
              for (; !q.done; q = p.next()) {
                var r = jf(gg(q.value, 1));
                r && k.add(r);
              }
            } finally {
              z(p, q);
            }
          } catch (J) {}
        l = bL(c, d, e, a);
        var t = new Set();
        if (l)
          try {
            var v = ad(l),
              x = aA(v),
              E = y(Kg(x, Sz, 2)),
              F = E.next();
            try {
              for (; !F.done; F = E.next()) {
                var B = jf(gg(F.value, 1));
                B && t.add(B);
              }
            } finally {
              z(E, F);
            }
          } catch (J) {}
        h = h.map(function (J) {
          var Q = J.tc !== "" && k.has(J.tc),
            oa = J.tc !== "" && t.has(J.tc);
          return { tc: J.tc, kg: Math.round(J.kg), Mm: Q, Im: oa };
        });
        v = {};
        W.getInstance().report(248, ((v.ss_rm = JSON.stringify(h)), v), 1);
      });
    }
  }
  var TL = (function () {
    var a = La.apply(0, arguments);
    return Yd(function (b) {
      return a.every(function (c) {
        return c(b);
      });
    });
  })(
    Yd(function (a) {
      return a instanceof Window;
    }),
    ge({
      tizen: ge({
        tvaudiocontrol: ge({ getVolume: ee }),
        time: ge({ getLocalTimezone: ee }),
        application: ge({
          getCurrentApplication: ee,
          appInfo: ge({ id: ie(ae, de), version: ie(ae, de) }),
        }),
        systeminfo: ge({ getPropertyValue: ee }),
      }),
      webapis: ge({
        adinfo: ge({ getTIFA: ee, isLATEnabled: ee }),
        network: ge({ getIp: ee }),
        productinfo: ge({ getModel: ee, getFirmware: ee }),
      }),
    })
  );
  var UL = {
      Sm: function (a, b) {
        var c = a.injector_basename,
          d = a.sodar_query_id,
          e = a.bg_hash_basename,
          f = a.bg_binary;
        a = window;
        var g = g === void 0 ? !1 : g;
        var h = (g === void 0 ? 0 : g)
          ? "//ep1.adtrafficquality.google/bg/" + qk(e) + ".js"
          : "//pagead2.googlesyndication.com/bg/" + qk(e) + ".js";
        e = g;
        e = e === void 0 ? !1 : e;
        g = a.document;
        var k = {};
        k._bgu_ = h;
        k._bgp_ = f;
        b && (k._li_ = b);
        d && (k._sid_ = d);
        ((b = a.GoogleTyFxhY) && typeof b.push == "function") ||
          (b = a.GoogleTyFxhY = []);
        b.push(k);
        b = jl(g);
        b = pl(b.h, "SCRIPT");
        b.type = "text/javascript";
        b.async = !0;
        c = (e === void 0 ? 0 : e)
          ? Jk(tx, qk(c) + ".js")
          : Jk(ux, qk(c) + ".js");
        lk(b, c);
        (c = (a.GoogleTyFxhYEET || {})[b.src])
          ? c()
          : g.getElementsByTagName("head")[0].appendChild(b);
      },
      gj: function (a, b) {
        var c = c === void 0 ? {} : c;
        var d = d === void 0 ? Qx : d;
        var e = "Googxrctsbkhf" + Zg(b, 2) + "XFg";
        Rx(a, b, e, c, d);
      },
    },
    VL = function () {
      var a = window,
        b = sq(hB);
      b = b === void 0 ? !1 : b;
      try {
        if (!a.GoogleGHBKKJ3LJKH) {
          var c = (
            typeof crypto !== "undefined" && crypto.randomUUID
              ? crypto.randomUUID()
              : Tx()
          ).replace(/-/g, "");
          if (c.length === 32) {
            for (var d = new Uint8Array(16), e = 0; e < c.length; e += 2)
              d[e / 2] = Number.parseInt(c.substring(e, e + 2), 16);
            var f = btoa(String.fromCodePoint.apply(String, ra(d)));
          } else f = void 0;
          f && (a.GoogleGHBKKJ3LJKH = f);
        }
        var g = a.GoogleGHBKKJ3LJKH;
        var h = typeof g === "string" ? g : void 0;
        if (!h) return null;
        var k = new Lx();
        var l = Dg(k, Kx, 5);
        wg(l, 1, hf(h), "");
        var m = jh(k, 2, 3);
        var p = wg(m, 3, hf("imaq_h.3.800.0"), "");
        var q = jh(p, 4, 1);
        var r = ch(q, 6, !1);
        var t = ch(r, 7, !0);
        var v = ch(t, 8, b);
        ch(v, 10, !1);
        UL.gj(a, k);
        return h;
      } catch (x) {
        return null;
      }
    };
  var WL =
    "abort canplay canplaythrough durationchange emptied loadstart loadeddata loadedmetadata progress ratechange seeked seeking stalled suspend waiting".split(
      " "
    );
  function XL(a) {
    var b = new Map();
    a = y(Object.entries(a));
    var c = a.next();
    try {
      for (; !c.done; c = a.next()) {
        var d = y(c.value),
          e = d.next().value,
          f = d.next().value,
          g = e,
          h = f;
        g === "deid" && h
          ? b.set(g, h)
          : b.set(g, encodeURIComponent(JSON.stringify(h)));
      }
    } finally {
      z(a, c);
    }
    return b;
  }
  function YL(a) {
    return Array.from(XL(a).entries(), function (b) {
      var c = y(b);
      b = c.next().value;
      c = c.next().value;
      return b + "=" + c;
    }).join("&");
  }
  var ZL = ua([
      "https://pagead2.googlesyndication.com/omsdk/releases/live/omweb-v1.js",
    ]),
    $L = ua([
      "https://pagead2.googlesyndication.com/omsdk/releases/control/omweb-v1.js",
    ]),
    aM = ua([
      "https://pagead2.googlesyndication.com/omsdk/releases/canary/omweb-v1.js",
    ]),
    bM = ua([
      "https://pagead2.googlesyndication.com/omsdk/releases/experimental/omweb-v1.js",
    ]),
    cM = Jk(ZL),
    dM = Jk($L),
    eM = Jk(aM),
    fM = Jk(bM);
  function gM(a) {
    var b;
    return (b = a.omidSessionInterface) != null ? b : null;
  }
  function hM(a) {
    var b, c, d, e, f, g;
    return Ka(function (h) {
      if (h.j == 1)
        return (
          sq(fB)
            ? ((b = Pk("IFRAME")),
              (b.style.visibility = "hidden"),
              (b.style.width = "0"),
              (b.style.height = "0"),
              (b.style.position = "absolute"),
              (b.style.left = "0"),
              (b.style.top = "0"),
              (b.title = "Advertisement"))
            : (b = rl("IFRAME", {
                style:
                  "visibility: hidden; width: 0; height: 0; position: absolute; left: 0; top: 0;",
                title: "Advertisement",
              })),
          (c = new Promise(function (k) {
            b.addEventListener("load", function () {
              k();
            });
          })),
          a.appendChild(b),
          h.h(c, 2)
        );
      d = sq(fB) ? Pk("SCRIPT") : rl("SCRIPT");
      e = iM();
      lk(d, e);
      f = new Promise(function (k, l) {
        d.addEventListener("load", function () {
          var m = vl(b);
          m && gM(m) ? k(b) : l();
        });
      });
      g = b.contentDocument || b.contentWindow.document;
      g.head.appendChild(d);
      return h.return(f);
    });
  }
  function iM() {
    switch (tq(jB)) {
      case 0:
        return cM;
      case 1:
        return dM;
      case 2:
        return eM;
      case 3:
        return fM;
      default:
        return cM;
    }
  }
  var jM = function (a, b) {
    S.call(this);
    this.j = b;
    this.h = gM(a);
  };
  w(jM, S);
  var lM = function (a) {
      try {
        a.h &&
          a.h.registerSessionObserver(function (b) {
            b.type === "sessionStart"
              ? kM(a, a.j)
              : b.type === "sessionFinish" && lM(a);
          });
      } catch (b) {
        a.dispatchEvent(new Event("error"));
      }
    },
    kM = function (a, b) {
      b instanceof ZG && (b = b.L);
      var c;
      if (((c = b.tagName) == null ? void 0 : c.toUpperCase()) !== "AUDIO")
        try {
          a.h && a.h.setVideoElement(b);
        } catch (d) {
          a.dispatchEvent(new Event("error"));
        }
    };
  jM.prototype.M = function () {
    try {
      this.h && this.h.finishAdSession();
    } catch (a) {}
    S.prototype.M.call(this);
  };
  var mM = function (a) {
    this.data = a;
  };
  n = mM.prototype;
  n.getTotalAds = function () {
    return this.data.totalAds;
  };
  n.getMaxDuration = function () {
    return this.data.maxDuration;
  };
  n.getAdPosition = function () {
    return this.data.adPosition;
  };
  n.getPodIndex = function () {
    return this.data.podIndex;
  };
  n.getTimeOffset = function () {
    return this.data.timeOffset;
  };
  n.getIsBumper = function () {
    return this.data.isBumper;
  };
  mM.prototype.getIsBumper = mM.prototype.getIsBumper;
  mM.prototype.getTimeOffset = mM.prototype.getTimeOffset;
  mM.prototype.getPodIndex = mM.prototype.getPodIndex;
  mM.prototype.getAdPosition = mM.prototype.getAdPosition;
  mM.prototype.getMaxDuration = mM.prototype.getMaxDuration;
  mM.prototype.getTotalAds = mM.prototype.getTotalAds;
  var nM = function (a) {
    this.data = a;
  };
  n = nM.prototype;
  n.getContent = function () {
    return this.data.content;
  };
  n.getContentType = function () {
    return this.data.contentType;
  };
  n.getWidth = function () {
    return this.getSize().width;
  };
  n.getHeight = function () {
    return this.getSize().height;
  };
  n.getAdSlotId = function () {
    return this.data.adSlotId;
  };
  n.getSize = function () {
    var a = this.data.size;
    return new Rk(a.width, a.height);
  };
  n.yg = function () {
    return this.data.resourceType;
  };
  var TI = function (a) {
    return (a = a.data.backupCompanions)
      ? a.map(function (b) {
          return new nM(b);
        })
      : [];
  };
  nM.prototype.getAdSlotId = nM.prototype.getAdSlotId;
  nM.prototype.getHeight = nM.prototype.getHeight;
  nM.prototype.getWidth = nM.prototype.getWidth;
  nM.prototype.getContentType = nM.prototype.getContentType;
  nM.prototype.getContent = nM.prototype.getContent;
  var oM = function (a, b) {
    this.j = a;
    this.h = b;
  };
  oM.prototype.getAdIdValue = function () {
    return this.j;
  };
  oM.prototype.getAdIdRegistry = function () {
    return this.h;
  };
  oM.prototype.getAdIdRegistry = oM.prototype.getAdIdRegistry;
  oM.prototype.getAdIdValue = oM.prototype.getAdIdValue;
  var X = function (a) {
    this.data = a;
  };
  X.prototype.getAdId = function () {
    return this.data.adId;
  };
  X.prototype.getCreativeAdId = function () {
    return this.data.creativeAdId;
  };
  X.prototype.getCreativeId = function () {
    return this.data.creativeId;
  };
  var pM = function (a) {
    return a.data.adQueryId;
  };
  X.prototype.getAdSystem = function () {
    return this.data.adSystem;
  };
  X.prototype.getAdvertiserName = function () {
    return this.data.advertiserName;
  };
  X.prototype.getApiFramework = function () {
    return this.data.apiFramework;
  };
  var qM = function (a) {
    var b;
    return (b = a.data.clickThroughUrl) != null ? b : null;
  };
  n = X.prototype;
  n.getWrapperAdIds = function () {
    return this.data.adWrapperIds;
  };
  n.getWrapperCreativeIds = function () {
    return this.data.adWrapperCreativeIds;
  };
  n.getWrapperAdSystems = function () {
    return this.data.adWrapperSystems;
  };
  n.isLinear = function () {
    return this.data.linear;
  };
  n.isSkippable = function () {
    return this.data.skippable;
  };
  n.getContentType = function () {
    return this.data.contentType;
  };
  n.getDescription = function () {
    return this.data.description;
  };
  n.getTitle = function () {
    return this.data.title;
  };
  n.getDuration = function () {
    return this.data.duration;
  };
  n.getVastMediaWidth = function () {
    return this.data.vastMediaWidth;
  };
  n.getVastMediaHeight = function () {
    return this.data.vastMediaHeight;
  };
  n.getWidth = function () {
    return this.data.width;
  };
  n.getHeight = function () {
    return this.data.height;
  };
  n.getUiElements = function () {
    return this.data.uiElements;
  };
  n.getMinSuggestedDuration = function () {
    return this.data.minSuggestedDuration;
  };
  n.getAdPodInfo = function () {
    return new mM(this.data.adPodInfo);
  };
  n.getCompanionAds = function (a, b, c) {
    var d = this.data.companions;
    if (!d) return [];
    d = d.map(function (e) {
      return new nM(e);
    });
    return SI(
      new PI(
        { size: new Rk(a, b), ug: c ? c.sizeCriteria === "SelectFluid" : !1 },
        c
      ),
      d
    );
  };
  n.getTraffickingParameters = function () {
    return wD(tk(this.data.traffickingParameters));
  };
  n.getTraffickingParametersString = function () {
    return this.data.traffickingParameters;
  };
  n.getVastMediaBitrate = function () {
    return this.data.vastMediaBitrate;
  };
  n.getMediaUrl = function () {
    return this.data.mediaUrl;
  };
  n.getSurveyUrl = function () {
    return this.data.surveyUrl;
  };
  n.getDealId = function () {
    return this.data.dealId;
  };
  n.getUniversalAdIds = function () {
    return (this.data.universalAdIds || []).map(function (a) {
      return new oM(a.adIdValue, a.adIdRegistry);
    });
  };
  n.getUniversalAdIdValue = function () {
    return this.data.universalAdIdValue;
  };
  n.getUniversalAdIdRegistry = function () {
    return this.data.universalAdIdRegistry;
  };
  n.getSkipTimeOffset = function () {
    return this.data.skipTimeOffset;
  };
  n.Ig = function () {
    return this.data.disableUi;
  };
  X.prototype.isUiDisabled = X.prototype.Ig;
  X.prototype.getSkipTimeOffset = X.prototype.getSkipTimeOffset;
  X.prototype.getUniversalAdIdRegistry = X.prototype.getUniversalAdIdRegistry;
  X.prototype.getUniversalAdIdValue = X.prototype.getUniversalAdIdValue;
  X.prototype.getUniversalAdIds = X.prototype.getUniversalAdIds;
  X.prototype.getDealId = X.prototype.getDealId;
  X.prototype.getSurveyUrl = X.prototype.getSurveyUrl;
  X.prototype.getMediaUrl = X.prototype.getMediaUrl;
  X.prototype.getVastMediaBitrate = X.prototype.getVastMediaBitrate;
  X.prototype.getTraffickingParametersString =
    X.prototype.getTraffickingParametersString;
  X.prototype.getTraffickingParameters = X.prototype.getTraffickingParameters;
  X.prototype.getCompanionAds = X.prototype.getCompanionAds;
  X.prototype.getAdPodInfo = X.prototype.getAdPodInfo;
  X.prototype.getMinSuggestedDuration = X.prototype.getMinSuggestedDuration;
  X.prototype.getUiElements = X.prototype.getUiElements;
  X.prototype.getHeight = X.prototype.getHeight;
  X.prototype.getWidth = X.prototype.getWidth;
  X.prototype.getVastMediaHeight = X.prototype.getVastMediaHeight;
  X.prototype.getVastMediaWidth = X.prototype.getVastMediaWidth;
  X.prototype.getDuration = X.prototype.getDuration;
  X.prototype.getTitle = X.prototype.getTitle;
  X.prototype.getDescription = X.prototype.getDescription;
  X.prototype.getContentType = X.prototype.getContentType;
  X.prototype.isSkippable = X.prototype.isSkippable;
  X.prototype.isLinear = X.prototype.isLinear;
  X.prototype.getWrapperAdSystems = X.prototype.getWrapperAdSystems;
  X.prototype.getWrapperCreativeIds = X.prototype.getWrapperCreativeIds;
  X.prototype.getWrapperAdIds = X.prototype.getWrapperAdIds;
  X.prototype.getApiFramework = X.prototype.getApiFramework;
  X.prototype.getAdvertiserName = X.prototype.getAdvertiserName;
  X.prototype.getAdSystem = X.prototype.getAdSystem;
  X.prototype.getCreativeId = X.prototype.getCreativeId;
  X.prototype.getCreativeAdId = X.prototype.getCreativeAdId;
  X.prototype.getAdId = X.prototype.getAdId;
  var rM = function (a) {
    this.h = a;
  };
  rM.prototype.getCuePoints = function () {
    return this.h;
  };
  rM.prototype.getCuePoints = rM.prototype.getCuePoints;
  D(
    "module$exports$google3$javascript$ads$interactivemedia$sdk$clientside$api$ad_cue_points.AdCuePoints.PREROLL",
    0
  );
  D(
    "module$exports$google3$javascript$ads$interactivemedia$sdk$clientside$api$ad_cue_points.AdCuePoints.POSTROLL",
    -1
  );
  var sM = function () {
    this.autoAlign = !0;
    this.bitrate = -1;
    this.enablePreloading = this.disableUi = this.disableClickThrough = !1;
    this.loadVideoTimeout = 8e3;
    this.prerollLoadVideoTimeout = -1;
    this.mimeTypes = null;
    this.playAdsAfterTime = -1;
    this.restoreCustomPlaybackStateOnAdBreakComplete = !1;
    this.uiElements = null;
    this.useStyledNonLinearAds =
      this.useStyledLinearAds =
      this.useLearnMoreButton =
        !1;
    this.useVideoAdUi = !0;
  };
  sM.prototype.ha = function () {
    var a = {};
    Object.assign(a, this);
    return a;
  };
  sM.prototype.append = function (a) {
    if (a) {
      var b = a.autoAlign;
      b != null && (this.autoAlign = b);
      b = zk(a.bitrate);
      typeof b === "number" && !isNaN(b) && b > 0 && (this.bitrate = b);
      this.disableUi = a.disableUi || this.disableUi;
      this.enablePreloading = a.enablePreloading || this.enablePreloading;
      (b = a.mimeTypes) && b.length !== 0 && (this.mimeTypes = b);
      b = zk(a.playAdsAfterTime);
      typeof b === "number" &&
        !isNaN(b) &&
        b > 0 &&
        (this.playAdsAfterTime = b);
      this.restoreCustomPlaybackStateOnAdBreakComplete =
        a.restoreCustomPlaybackStateOnAdBreakComplete ||
        this.restoreCustomPlaybackStateOnAdBreakComplete;
      b = zk(a.loadVideoTimeout);
      typeof b === "number" &&
        !isNaN(b) &&
        b > 0 &&
        (this.loadVideoTimeout = b);
      b = zk(a.prerollLoadVideoTimeout);
      typeof b === "number" &&
        !isNaN(b) &&
        b > -1 &&
        (this.prerollLoadVideoTimeout = b);
      this.uiElements = a.uiElements || this.uiElements;
      this.useLearnMoreButton = a.useLearnMoreButton || this.useLearnMoreButton;
      this.useStyledLinearAds = a.useStyledLinearAds || this.useStyledLinearAds;
      this.useStyledNonLinearAds =
        a.useStyledNonLinearAds || this.useStyledNonLinearAds;
      this.useVideoAdUi = a.useVideoAdUi === !1 ? !1 : this.useVideoAdUi;
    }
  };
  D(
    "module$exports$google3$javascript$ads$interactivemedia$sdk$clientside$api$ads_rendering_settings.AdsRenderingSettings.AUTO_SCALE",
    -1
  );
  var tM = function (a) {
    R.call(this);
    this.h = a;
    this.j = null;
    this.l = this.o = !1;
    a = new zD(this);
    tt(this, a);
    a.listen(this.h, "play", this.zj);
    a.listen(this.h, "pause", this.yj);
    a.listen(this.h, "seeking", this.Bj);
    a.listen(this.h, "seeked", this.Aj);
    a.listen(this.h, "ended", this.xj);
  };
  w(tM, R);
  n = tM.prototype;
  n.zj = function () {
    this.l = this.o = !1;
    var a;
    (a = this.j) == null || uI(a, "contentMonitor", "contentResume");
  };
  n.yj = function () {
    if (!(this.h.ended || this.o || this.h.seeking || this.l)) {
      var a;
      (a = this.j) == null || uI(a, "contentMonitor", "contentPause");
    }
  };
  n.Bj = function () {
    this.l = !0;
  };
  n.Aj = function () {
    this.l = !1;
    this.h.ended || (this.o = !1);
  };
  n.xj = function () {
    this.o = !0;
  };
  n.destroy = function () {
    this.dispose();
  };
  var Y = function () {};
  n = Y.prototype;
  n.setCompanionBackfill = function (a) {
    U.setCompanionBackfill(a);
  };
  n.getCompanionBackfill = function () {
    return U.getCompanionBackfill();
  };
  n.setNumRedirects = function (a) {
    U.setNumRedirects(a);
  };
  n.getNumRedirects = function () {
    return U.getNumRedirects();
  };
  n.setPpid = function (a) {
    U.setPpid(a);
  };
  n.getPpid = function () {
    return U.getPpid();
  };
  n.setPreloadTimeSeconds = function (a) {
    U.setPreloadTimeSeconds(a);
  };
  n.getPreloadTimeSeconds = function () {
    return U.getPreloadTimeSeconds();
  };
  n.setVpaidAllowed = function (a) {
    U.setVpaidAllowed(a);
  };
  n.setVpaidMode = function (a) {
    U.setVpaidMode(a);
  };
  n.Dd = function () {
    return U.Dd();
  };
  n.setAutoPlayAdBreaks = function (a) {
    U.setAutoPlayAdBreaks(a);
  };
  n.Zc = function () {
    return U.Zc();
  };
  n.uf = function (a) {
    U.uf(a);
  };
  n.Eb = function () {
    return U.Eb();
  };
  n.setLocale = function (a) {
    U.setLocale(a);
  };
  n.getLocale = function () {
    return U.getLocale();
  };
  n.setPlayerType = function (a) {
    U.setPlayerType(a);
  };
  n.getPlayerType = function () {
    return U.getPlayerType();
  };
  n.setPlayerVersion = function (a) {
    U.setPlayerVersion(a);
  };
  n.getPlayerVersion = function () {
    return U.getPlayerVersion();
  };
  var uM = function () {
    return aI(U);
  };
  n = Y.prototype;
  n.vf = function (a) {
    U.vf(a);
  };
  n.Tc = function () {
    return U.Tc();
  };
  n.xf = function (a) {
    U.xf(a);
  };
  n.setDisableCustomPlaybackForIOS10Plus = function (a) {
    U.setDisableCustomPlaybackForIOS10Plus(a);
  };
  n.getDisableCustomPlaybackForIOS10Plus = function () {
    return U.getDisableCustomPlaybackForIOS10Plus();
  };
  n.jj = function () {
    console.warn(
      "isCookiesEnabled always returns true. The ltd parameter in the ad tag URL determines an ad request's ability to use cookies."
    );
    W.getInstance().report(230, { method: "ImaSdkSettings.isCookiesEnabled" });
    return !0;
  };
  n.bk = function () {
    console.warn(
      "setCookiesEnabled is a no-op. The ltd parameter in the ad tag URL determines an ad request's ability to use cookies."
    );
    W.getInstance().report(230, { method: "ImaSdkSettings.setCookiesEnabled" });
  };
  n.setSessionId = function (a) {
    U.setSessionId(a);
    W.getInstance().report(232);
  };
  n.ck = function () {};
  n.Ui = function () {
    return !0;
  };
  n.setFeatureFlags = function (a) {
    U.setFeatureFlags(a);
  };
  n.getFeatureFlags = function () {
    return U.getFeatureFlags();
  };
  n.ha = function (a) {
    return U.ha(a === void 0 ? null : a);
  };
  Y.prototype.getFeatureFlags = Y.prototype.getFeatureFlags;
  Y.prototype.setFeatureFlags = Y.prototype.setFeatureFlags;
  Y.prototype.getDisableFlashAds = Y.prototype.Ui;
  Y.prototype.setDisableFlashAds = Y.prototype.ck;
  Y.prototype.setSessionId = Y.prototype.setSessionId;
  Y.prototype.setCookiesEnabled = Y.prototype.bk;
  Y.prototype.isCookiesEnabled = Y.prototype.jj;
  Y.prototype.getDisableCustomPlaybackForIOS10Plus =
    Y.prototype.getDisableCustomPlaybackForIOS10Plus;
  Y.prototype.setDisableCustomPlaybackForIOS10Plus =
    Y.prototype.setDisableCustomPlaybackForIOS10Plus;
  Y.prototype.setStreamCorrelator = Y.prototype.xf;
  Y.prototype.setPageCorrelator = Y.prototype.vf;
  Y.prototype.getPlayerVersion = Y.prototype.getPlayerVersion;
  Y.prototype.setPlayerVersion = Y.prototype.setPlayerVersion;
  Y.prototype.getPlayerType = Y.prototype.getPlayerType;
  Y.prototype.setPlayerType = Y.prototype.setPlayerType;
  Y.prototype.getLocale = Y.prototype.getLocale;
  Y.prototype.setLocale = Y.prototype.setLocale;
  Y.prototype.getIsVpaidAdapter = Y.prototype.Eb;
  Y.prototype.setIsVpaidAdapter = Y.prototype.uf;
  Y.prototype.isAutoPlayAdBreaks = Y.prototype.Zc;
  Y.prototype.setAutoPlayAdBreaks = Y.prototype.setAutoPlayAdBreaks;
  Y.prototype.getVpaidMode = Y.prototype.Dd;
  Y.prototype.setVpaidMode = Y.prototype.setVpaidMode;
  Y.prototype.setVpaidAllowed = Y.prototype.setVpaidAllowed;
  Y.prototype.getPreloadTimeSeconds = Y.prototype.getPreloadTimeSeconds;
  Y.prototype.setPreloadTimeSeconds = Y.prototype.setPreloadTimeSeconds;
  Y.prototype.getPpid = Y.prototype.getPpid;
  Y.prototype.setPpid = Y.prototype.setPpid;
  Y.prototype.getNumRedirects = Y.prototype.getNumRedirects;
  Y.prototype.setNumRedirects = Y.prototype.setNumRedirects;
  Y.prototype.getCompanionBackfill = Y.prototype.getCompanionBackfill;
  Y.prototype.setCompanionBackfill = Y.prototype.setCompanionBackfill;
  var vM = new Y();
  var wM = function () {
    var a = window,
      b,
      c,
      d;
    this.jc =
      (d =
        (c = (b = a.lg) == null ? void 0 : b.webos) == null ? void 0 : c.pal) !=
        null && d.SignalObserver
        ? "lg_channels"
        : TL(a)
        ? "tizen_packaged"
        : !TL(a) &&
          Pb(Sb(), "Tizen") &&
          (Pb(Sb(), " TV ") || Pb(Sb(), "SMART-TV"))
        ? "tizen_hosted"
        : a.hasOwnProperty("webOS")
        ? "webos"
        : null;
    this.h = SH();
    this.j = Math.floor(Math.random() * 4503599627370496);
    this.l = Ok();
  };
  wM.prototype.Tc = function () {
    return this.j;
  };
  function xM(a) {
    this.h = a || { cookie: "" };
  }
  n = xM.prototype;
  n.set = function (a, b, c) {
    var d = !1;
    if (typeof c === "object") {
      var e = c.sameSite;
      d = c.secure || !1;
      var f = c.domain || void 0;
      var g = c.path || void 0;
      var h = c.Qd;
    }
    if (/[;=\s]/.test(a)) throw Error('Invalid cookie name "' + a + '"');
    if (/[;\r\n]/.test(b)) throw Error('Invalid cookie value "' + b + '"');
    h === void 0 && (h = -1);
    this.h.cookie =
      a +
      "=" +
      b +
      (f ? ";domain=" + f : "") +
      (g ? ";path=" + g : "") +
      (h < 0
        ? ""
        : h == 0
        ? ";expires=" + new Date(1970, 1, 1).toUTCString()
        : ";expires=" + new Date(Date.now() + h * 1e3).toUTCString()) +
      (d ? ";secure" : "") +
      (e != null ? ";samesite=" + e : "");
  };
  n.get = function (a, b) {
    for (
      var c = a + "=", d = (this.h.cookie || "").split(";"), e = 0, f;
      e < d.length;
      e++
    ) {
      f = Gb(d[e]);
      if (f.lastIndexOf(c, 0) == 0) return f.slice(c.length);
      if (f == a) return "";
    }
    return b;
  };
  n.remove = function (a, b, c) {
    var d = this.get(a) !== void 0;
    this.set(a, "", { Qd: 0, path: b, domain: c });
    return d;
  };
  n.Vc = function () {
    return yM(this).values;
  };
  n.isEmpty = function () {
    return !this.h.cookie;
  };
  n.clear = function () {
    for (var a = yM(this).keys, b = a.length - 1; b >= 0; b--)
      this.remove(a[b]);
  };
  var yM = function (a) {
    a = (a.h.cookie || "").split(";");
    for (var b = [], c = [], d, e, f = 0; f < a.length; f++)
      (e = Gb(a[f])),
        (d = e.indexOf("=")),
        d == -1
          ? (b.push(""), c.push(e))
          : (b.push(e.substring(0, d)), c.push(e.substring(d + 1)));
    return { keys: b, values: c };
  };
  var zM;
  function AM(a) {
    return zM ? zM : a.origin === "null" ? (zM = !1) : (zM = BM(a));
  }
  function BM(a) {
    if (!a.navigator.cookieEnabled) return !1;
    var b = new xM(a.document);
    if (!b.isEmpty()) return !0;
    b.set("TESTCOOKIESENABLED", "1", {
      Qd: 60,
      sameSite: a.isSecureContext ? "none" : void 0,
      secure: a.isSecureContext || void 0,
    });
    if (b.get("TESTCOOKIESENABLED") !== "1") return !1;
    b.remove("TESTCOOKIESENABLED");
    return !0;
  }
  function CM(a, b) {
    b = b.origin !== "null" ? b.document.cookie : null;
    return b === null ? null : new xM({ cookie: b }).get(a) || "";
  }
  function DM(a, b, c, d) {
    d.origin !== "null" &&
      (d.isSecureContext && (c = xa({}, c, { sameSite: "none", secure: !0 })),
      new xM(d.document).set(a, b, c));
  }
  var EM = function () {
    this.h = window;
  };
  function FM(a, b, c) {
    var d = c.Rj;
    c = c.Sj;
    return !(!Tg(b, 17) || ((d || !yI(b)) && c) || !AM(a));
  }
  var GM = function () {
      this.h = window;
    },
    HM = function (a, b, c, d) {
      if (d) {
        var e = Sp(Wg(c, 2)) - Date.now() / 1e3;
        e = {
          Qd: Math.max(e, 0),
          path: Yg(c, 3),
          domain: Yg(c, 4),
          secure: !1,
        };
        c = c.getValue();
        yI(d) && DM(b, c, e, a.h);
      }
    },
    IM = function (a, b, c) {
      if (c && yI(c) && CM(b, a.h)) {
        var d = a.h.location.hostname;
        if (d === "localhost") d = ["localhost"];
        else if (((d = d.split(".")), d.length < 2)) d = [];
        else {
          for (var e = [], f = 0; f < d.length - 1; ++f)
            e.push(d.slice(f).join("."));
          d = e;
        }
        d = y(d);
        e = d.next();
        try {
          for (; !e.done; e = d.next())
            if (yI(c)) {
              var g = a.h;
              g.origin !== "null" && new xM(g.document).remove(b, "/", e.value);
            }
        } finally {
          z(d, e);
        }
      }
    };
  var JM = function (a, b, c) {
    var d;
    this.l = d = d === void 0 ? new EM() : d;
    this.j = II(a);
    this.h = { Rj: FI(a), Sj: !IL(c, b) };
  };
  function KM(a) {
    if (!a) return [];
    if (sq(tB)) return ["15018773"];
    var b;
    return (b = Ig(a, vj, 2)) == null
      ? void 0
      : Kg(b, uj, 1).map(function (c) {
          return Yg(c, 1).toString();
        });
  }
  function LM(a, b, c, d, e, f, g, h, k, l, m, p, q) {
    p = p === void 0 ? null : p;
    q = q === void 0 ? [] : q;
    var r = a.adTagUrl ? pI(a.adTagUrl) : null,
      t = new JM(c, r, e),
      v = Ok(),
      x = {};
    x.consentSettings = b;
    x.settings = k;
    x.videoEnvironment = l;
    x.preferredLinearOrientation = a.preferredLinearOrientation;
    x.pvsid = v;
    x.networkCodes = KM(e);
    var E;
    e == null ? (E = void 0) : (E = pg(e, 1, Ve));
    b =
      ((x.perPubConfigExperimentIds = E || []),
      (x.sqid = null),
      (x.sjk = p),
      (x.supportsQuicksilver = !0),
      x);
    Object.assign(b, a.ha());
    a = II(c);
    k = window;
    k = yI(a) ? !!AM(k) : !1;
    b.isBrowserCookieEnabled = k;
    k = a ? (yI(a) ? CM("__gads", m.h) : null) : null;
    k !== null && (b.gfpCookieValue = k);
    k = a ? (yI(a) ? CM("__gpi", m.h) : null) : null;
    k !== null && (b.gfpCookieV2Id = k);
    m = a ? (yI(a) ? CM("__gpi_opt_out", m.h) : null) : null;
    m !== null && (b.gfpCookieV2OptOut = m);
    b.eoidCookieEnabled = FM(window, t.j, t.h);
    m = t.l;
    if (FM(m.h, t.j, t.h)) {
      var F;
      t = (F = CM("__eoi", m.h)) != null ? F : void 0;
    } else t = void 0;
    (F = t) && (b.eoidCookieValue = F);
    HI(c)
      ? ((F = II(c)), (c = FI(c) || !yI(F)), (r = IL(e, r)), (r = !(c && !r)))
      : (r = !1);
    b.ivtDetectionOnlyStorageAllowed = r;
    f && (b.espSignals = f);
    d && (b.gmaSignals = d);
    b.isEapLoader = !1;
    g && (b.clientBidsProto = xJ(Nz(g)));
    h && (b.globalPlacementId = h);
    q.length > 0 && (b.prebidCachedBids = q);
    try {
      if (e) {
        var B = new FL(),
          J = y(Kg(e, Bj, 6)),
          Q = J.next();
        try {
          for (; !Q.done; Q = J.next()) {
            d = void 0;
            var oa = (d = Ig(Q.value, Aj, 4)) == null ? void 0 : Ig(d, zj, 2);
            if (oa) {
              var ta = new Aj(),
                Da = new zj(),
                ca = Wg(oa, 1);
              var fa = jg(Da, 1, bf(ca));
              var Ma = Mg(ta, 2, fa);
              Qg(B, 1, Aj, Ma);
            }
          }
        } finally {
          z(J, Q);
        }
        var wa = Kg(B, Aj, 1).length === 0 ? null : B;
      } else wa = null;
      wa && (b.publisherInitiatedExperimentDataProto = xJ(GL(wa)));
    } catch (Vb) {
      var Ia;
      W.getInstance().report(214, {
        message: (Ia = Vb) == null ? void 0 : Ia.message,
      });
    }
    return b;
  }
  var MM = function () {
    this.l = this.j = "unknown";
    this.h = "0";
    this.adTagUrl = "";
    this.adsResponse = null;
    this.nonLinearAdSlotHeight =
      this.nonLinearAdSlotWidth =
      this.linearAdSlotHeight =
      this.linearAdSlotWidth =
      this.liveStreamPrefetchSeconds =
        0;
    this.forceNonLinearFullSlot = !1;
    this.contentTitle = this.contentKeywords = this.contentDuration = null;
    this.vastLoadTimeout = 5e3;
    this.omidAccessModeRules = {};
    this.pageUrl = null;
    this.preferredLinearOrientation = 0;
  };
  MM.prototype.ha = function () {
    var a = {};
    a.adsResponse = this.adsResponse;
    a.videoPlayActivation = this.j;
    a.videoPlayMuted = this.l;
    a.videoContinuousPlay = this.h;
    a.adTagUrl = this.adTagUrl;
    a.contentDuration = this.contentDuration;
    a.contentKeywords = this.contentKeywords;
    a.contentTitle = this.contentTitle;
    a.linearAdSlotWidth = this.linearAdSlotWidth;
    a.linearAdSlotHeight = this.linearAdSlotHeight;
    a.nonLinearAdSlotWidth = this.nonLinearAdSlotWidth;
    a.nonLinearAdSlotHeight = this.nonLinearAdSlotHeight;
    a.forceNonLinearFullSlot = this.forceNonLinearFullSlot;
    a.liveStreamPrefetchSeconds = this.liveStreamPrefetchSeconds;
    a.vastLoadTimeout = this.vastLoadTimeout;
    a.omidAccessModeRules = this.omidAccessModeRules;
    a.pageUrl = this.pageUrl;
    return a;
  };
  MM.prototype.setAdWillAutoPlay = function (a) {
    this.j = a ? "auto" : "click";
  };
  MM.prototype.setAdWillPlayMuted = function (a) {
    this.l = a ? "muted" : "unmuted";
  };
  MM.prototype.setContinuousPlayback = function (a) {
    this.h = a ? "2" : "1";
  };
  MM.prototype.setContinuousPlayback = MM.prototype.setContinuousPlayback;
  MM.prototype.setAdWillPlayMuted = MM.prototype.setAdWillPlayMuted;
  MM.prototype.setAdWillAutoPlay = MM.prototype.setAdWillAutoPlay;
  var OM = function (a, b, c) {
    R.call(this);
    this.B = a;
    this.A = b;
    this.D = c;
    this.h = this.j = this.o = null;
    this.l = 0;
    a = new zD(this);
    tt(this, a);
    this.Qa = null;
    NM(this);
    a.listen(this.A, "adsManager", this.C);
  };
  w(OM, R);
  var NM = function (a) {
    hM(a.B)
      .then(function (b) {
        a.j = b;
        PM(a, vl(b));
      })
      .catch(function () {
        return void QM(a);
      });
  };
  OM.prototype.C = function (a) {
    if (["complete", "skip", "error"].includes(a.messageType)) {
      this.l++;
      if (this.l === 10) {
        this.l = 0;
        var b;
        (b = this.h) == null || b.dispose();
        NM(this);
      }
      a = vl(this.j);
      var c;
      (a && ((c = a.frames) == null ? 0 : c.omid_v1_present)) ||
        W.getInstance().report(188, {});
    }
  };
  var RM = function (a) {
      if (a.h && a.o) {
        var b = a.h;
        try {
          b.h && b.h.setSessionClientWindow(a.o);
        } catch (c) {
          b.dispatchEvent(new Event("error"));
        }
      }
    },
    PM = function (a, b) {
      a.h = new jM(b, a.D);
      a.h.listen("error", function () {
        return void QM(a);
      });
      lM(a.h);
      RM(a);
    },
    QM = function (a) {
      uI(a.A, "omid", "iframeFailed");
      a.dispose();
    };
  OM.prototype.M = function () {
    this.j && (tl(this.j), (this.j = null));
    var a;
    (a = this.h) == null || a.dispose();
    R.prototype.M.call(this);
  };
  var SM = function (a, b, c, d) {
    R.call(this);
    this.o = a;
    this.l = b;
    this.h = c;
    this.B = d;
    this.j = new zD(this);
    tt(this, this.j);
    this.j.listen(this.o, d, this.D);
  };
  w(SM, R);
  var TM = function (a, b) {
    var c = b.ra;
    switch (b.messageType) {
      case "showVideo":
        a.l.je();
        break;
      case "hide":
        a.l.Ib();
        break;
      case "resizeAndPositionVideo":
        b = c.resizeAndPositionVideo;
        a.l.nf(new Bl(b.x, b.y, b.width, b.height));
        break;
      case "restoreSizeAndPositionVideo":
        a.l.qf();
    }
  };
  SM.prototype.D = function (a) {
    var b = a.ra;
    switch (a.messageType) {
      case "activate":
        this.l.od(this.h);
        break;
      case "startTracking":
        a = this.h;
        var c = this.A;
        this.j.listen(a, Wk(WD), c);
        this.j.listen(a, WL, c);
        this.h.Pb();
        break;
      case "stopTracking":
        a = this.h;
        c = this.A;
        this.j.Ma(a, Wk(WD), c);
        this.j.Ma(a, WL, c);
        this.h.Ra();
        break;
      case "exitFullscreen":
        a = this.h.h;
        (Hc || Jc) && a.webkitDisplayingFullscreen && a.webkitExitFullscreen();
        break;
      case "play":
        this.h.play();
        break;
      case "pause":
        this.h.pause();
        break;
      case "load":
        a = this.h;
        c = b.videoUrl;
        var d = b.muxedMediaUrl,
          e = b.muxedAudioCodec,
          f = b.muxedVideoCodec,
          g = b.demuxedAudioUrl,
          h = b.demuxedVideoUrl,
          k = b.audioMimeType,
          l = b.videoMimeType,
          m = b.demuxedAudioCodec,
          p = b.demuxedVideoCodec,
          q = b.mseCompatible;
        b = b.universalAdIds;
        var r = null;
        h &&
          g &&
          q &&
          l &&
          k &&
          p &&
          m &&
          (r = new CB({
            Mf: h,
            qe: g,
            xh: null,
            Yf: null,
            Lf: l,
            pe: k,
            Rb: p,
            zb: m,
            height: null,
            width: null,
            Kb: q,
            wh: null,
            Xf: null,
          }));
        g = null;
        d &&
          l &&
          f &&
          e &&
          (g = new DB({
            Se: d,
            itag: null,
            mimeType: l,
            Rb: f,
            zb: e,
            height: null,
            width: null,
            Kb: q,
            eg: null,
          }));
        r ? UM(a, c, r, b) : g ? UM(a, c, g, b) : UM(a, c, null, b);
        break;
      case "unload":
        this.h.unload();
        break;
      case "setCurrentTime":
        this.h.h.currentTime = b.currentTime;
        break;
      case "setVolume":
        this.h.setVolume(b.volume);
    }
  };
  SM.prototype.A = function (a) {
    var b = {};
    switch (a.type) {
      case "autoplayDisallowed":
        a = "autoplayDisallowed";
        break;
      case "beginFullscreen":
        a = "fullscreen";
        break;
      case "endFullscreen":
        a = "exitFullscreen";
        break;
      case "click":
        a = "click";
        break;
      case "end":
        a = "end";
        break;
      case "error":
        a = "error";
        break;
      case "loaded":
        a = "loaded";
        break;
      case "mediaLoadTimeout":
        a = "mediaLoadTimeout";
        break;
      case "pause":
        a = "pause";
        b.ended = this.h.h.ended;
        break;
      case "play":
        a = "play";
        break;
      case "skip":
        a = "skip";
        break;
      case "start":
        a = "start";
        b.volume = this.h.getVolume();
        break;
      case "timeUpdate":
        a = "timeupdate";
        b.currentTime = this.h.getCurrentTime();
        b.duration = this.h.getDuration();
        break;
      case "volumeChange":
        a = "volumeChange";
        b.volume = this.h.getVolume();
        break;
      case "loadedmetadata":
        a = a.type;
        b.duration = this.h.getDuration();
        break;
      case "abort":
      case "canplay":
      case "canplaythrough":
      case "durationchange":
      case "emptied":
      case "loadstart":
      case "loadeddata":
      case "progress":
      case "ratechange":
      case "seeked":
      case "seeking":
      case "stalled":
      case "suspend":
      case "waiting":
        a = a.type;
        break;
      default:
        return;
    }
    uI(this.o, this.B, a, b);
  };
  var VM = function (a, b) {
    R.call(this);
    this.j = b;
    this.h = null;
    this.l = new SM(a, b, this.j.ma, "videoDisplay1");
    tt(this, this.l);
    var c = this.j.Ka;
    c != null &&
      ((this.h = new SM(a, b, c, "videoDisplay2")), tt(this, this.h));
  };
  w(VM, R);
  var XM = function (a, b) {
      var c = WM;
      if (c.h) return HL(c.h, a, 0, !0), Promise.resolve(c.h);
      c = wL(c.j)
        .then(function (d) {
          var e = d.serializedConfig;
          var f = d.errorMessage;
          if (e) e = Oz(e);
          else throw Error(f != null ? f : "Unknown PPC error");
          HL(e, a, d.latencyMs, !1);
          return e;
        })
        .catch(function (d) {
          W.getInstance().report(189, { message: d.message });
          return null;
        });
      return Promise.race([c, $y(b, null)]);
    },
    WM = new (function () {
      var a;
      this.j = a = a === void 0 ? BL : a;
    })();
  function YM(a) {
    var b, c, d;
    return (
      (a == null ? void 0 : (b = a.ext) == null ? void 0 : b.gpid) ||
      (a == null
        ? void 0
        : (c = a.ext) == null
        ? void 0
        : (d = c.data) == null
        ? void 0
        : d.pbadslot)
    );
  }
  function ZM(a, b) {
    if (!b.length) return [];
    var c,
      d,
      e =
        (d =
          (c = a.getEvents) == null
            ? void 0
            : c.call(a).filter(function (f) {
                return f.eventType === "auctionEnd";
              })) != null
          ? d
          : [];
    return b.map(function (f) {
      f = y(f);
      f.next();
      f = f.next().value;
      var g = YM(f.ortb2Imp),
        h = f.transactionId;
      if (g && h) return { gpid: g, transactionId: h };
      var k = y(e),
        l = k.next();
      try {
        for (; !l.done; l = k.next()) {
          var m = void 0,
            p = void 0,
            q =
              (p = (m = l.value.args) == null ? void 0 : m.adUnits) != null
                ? p
                : [],
            r = y(q),
            t = r.next();
          try {
            for (; !t.done; t = r.next()) {
              var v = t.value;
              if (
                f.code === v.code &&
                ((g = g || YM(v.ortb2Imp)), (h = h || v.transactionId), g && h)
              )
                return { gpid: g, transactionId: h };
            }
          } finally {
            z(r, t);
          }
        }
      } finally {
        z(k, l);
      }
      return { gpid: g, transactionId: h };
    });
  }
  var $M = nK(
    function (a) {
      var b = a.ld,
        c = a.nk,
        d = a.Pi,
        e = a.Ha,
        f = a.kk,
        g = a.lk;
      a = a.fj;
      var h;
      if (
        !(
          b &&
          e &&
          e.auctionId &&
          e.timestamp != null &&
          ((h = e.bidderRequests) == null ? 0 : h.length)
        )
      )
        return { zf: void 0 };
      c = Sg(b, c || []);
      Sg(c, d || []);
      a && Mg(b, 5, a);
      f && hh(b, 4, f);
      d = new Mz();
      b = Qg(d, 1, Kz, b);
      return { zf: { transactionId: g, arg: e, zc: b } };
    },
    { id: 1681, pa: { zf: void 0 } }
  );
  var aN = nK(
    function (a, b) {
      a = y(a.Db || []);
      var c = a.next();
      try {
        for (; !c.done; c = a.next()) {
          var d = c.value;
          try {
            var e = void 0;
            (e = b) == null || e(d, d.transactionId);
          } catch (f) {}
        }
      } finally {
        z(a, c);
      }
      return {};
    },
    { id: 1675, pa: {} }
  );
  function bN(a) {
    switch (a) {
      case null:
      case void 0:
      case "client":
        return 1;
      case "s2s":
        return 2;
      default:
        return 0;
    }
  }
  function cN(a, b, c) {
    for (var d = []; b && !d.includes(b); ) {
      d.unshift(b);
      var e = void 0,
        f = void 0;
      b =
        (e = a) == null
          ? void 0
          : (f = e.aliasRegistry) == null
          ? void 0
          : f[b];
    }
    vg(c, 10, d, gf);
  }
  function dN(a, b, c, d) {
    var e = a.cpm,
      f = a.originalCpm,
      g = a.currency,
      h = a.originalCurrency,
      k = a.dealId,
      l = a.adserverTargeting,
      m = a.bidder,
      p = a.adId,
      q = a.mediaType,
      r = a.height,
      t = a.width,
      v = a.meta,
      x = new xz();
    $d(e) &&
      (fh(x, 2, Math.round(e * 1e6)),
      (h && h !== g) ||
        ((e = Math.round(Number(f) * 1e6)),
        isNaN(e) || e === Sp(Wg(x, 2)) || fh(x, 8, e)));
    ae(g) && hh(x, 3, g);
    if (ae(k) || $d(k)) (g = new pz()), (k = hh(g, 1, String(k))), Mg(x, 6, k);
    if (typeof l === "object") {
      k = y(["", "_" + m]);
      g = k.next();
      try {
        for (; !g.done; g = k.next()) {
          var E = g.value;
          e = [];
          var F = y(Object.entries(l)),
            B = F.next();
          try {
            for (; !B.done; B = F.next()) {
              var J = y(B.value),
                Q = J.next().value,
                oa = J.next().value,
                ta = ("" + Q + E).slice(0, 20);
              h = f = void 0;
              if ((f = c) == null ? 0 : (h = f[ta]) == null ? 0 : h.length)
                if (c[ta][0] === String(oa)) e.push(ta);
                else {
                  e = [];
                  break;
                }
            }
          } finally {
            z(F, B);
          }
          var Da = pg(x, 4, jf);
          vg(x, 4, Da.concat(e), gf);
        }
      } finally {
        z(k, g);
      }
    }
    switch (q || "banner") {
      case "banner":
        ih(x, 5, 1);
        break;
      case "native":
        ih(x, 5, 2);
        break;
      case "video":
        ih(x, 5, 3);
        c = new vz();
        var ca;
        if (
          (b == null
            ? void 0
            : (ca = b.video) == null
            ? void 0
            : ca.context) === "adpod"
        ) {
          var fa,
            Ma =
              b == null
                ? void 0
                : (fa = b.video) == null
                ? void 0
                : fa.adPodDurationSec;
          fh(c, 1, Ma);
        } else
          (fa =
            b == null
              ? void 0
              : (Ma = b.video) == null
              ? void 0
              : Ma.maxduration),
            fh(c, 1, fa);
        var wa;
        if (
          $d(b == null ? void 0 : (wa = b.video) == null ? void 0 : wa.skip)
        ) {
          var Ia;
          b = !!(b == null ? 0 : (Ia = b.video) == null ? 0 : Ia.skip);
          bh(c, 2, b);
        }
        var Vb;
        Ia = (Vb = a.meta) == null ? void 0 : Vb.adServerCatId;
        Vb = hh(c, 3, Ia);
        if (typeof l !== "object") l = null;
        else {
          var pc, pf;
          Ia = String(
            (pf =
              (pc = l["hb_pb_cat_dur_" + m]) != null ? pc : l.hb_pb_cat_dur) !=
              null
              ? pf
              : ""
          );
          var Ud, li, mi, og;
          pc = String(
            (og =
              (mi =
                (li =
                  (Ud = l["hb_cache_id_" + m]) != null
                    ? Ud
                    : l["hb_uuid_" + m]) != null
                  ? li
                  : l.hb_cache_id) != null
                ? mi
                : l.hb_uuid) != null
              ? og
              : ""
          );
          l = Ia && pc ? Ia + "_" + pc : pc ? pc : null;
        }
        hh(Vb, 4, l);
        Mg(x, 9, c);
    }
    Number.isFinite(r) &&
      Number.isFinite(t) &&
      ((l = new tz()),
      (t = dh(l, 1, Math.round(t))),
      (r = dh(t, 2, Math.round(r))),
      Mg(x, 7, r));
    ae(p) && hh(x, 1, p);
    var ng;
    (d == null ? 0 : d.di) &&
      Array.isArray(v == null ? void 0 : v.advertiserDomains) &&
      (v == null ? 0 : (ng = v.advertiserDomains[0]) == null ? 0 : ng.length) &&
      hh(x, 10, v.advertiserDomains[0].substring(0, d == null ? void 0 : d.di));
    if (a.meta && d) {
      var ac;
      d.ji &&
        ae(a.meta.agencyId) &&
        a.meta.agencyId.length &&
        (ac != null || (ac = new rz()),
        hh(ac, 1, a.meta.agencyId.substring(0, d.ji)));
      d.ki &&
        ae(a.meta.agencyName) &&
        a.meta.agencyName.length &&
        (ac != null || (ac = new rz()),
        hh(ac, 2, a.meta.agencyName.substring(0, d.ki)));
      d.Li &&
        ae(a.meta.networkId) &&
        a.meta.networkId.length &&
        (ac != null || (ac = new rz()),
        hh(ac, 3, a.meta.networkId.substring(0, d.Li)));
      d.Mi &&
        ae(a.meta.networkName) &&
        a.meta.networkName.length &&
        (ac != null || (ac = new rz()),
        hh(ac, 4, a.meta.networkName.substring(0, d.Mi)));
      ac && Mg(x, 11, ac);
    }
    return x;
  }
  var eN = nK(
    function (a, b, c, d, e) {
      var f = a.Db,
        g = a.Ha;
      a = a.transactionId;
      var h = [],
        k,
        l = (
          (k = g == null ? void 0 : g.bidderRequests) != null ? k : []
        ).flatMap(function (B) {
          return B.bids;
        });
      f = y(f || []);
      k = f.next();
      try {
        for (var m = {}; !k.done; m = { Oa: void 0 }, k = f.next()) {
          m.Oa = k.value;
          var p = void 0,
            q = m.Oa.adUnitCode !== ((p = b) == null ? void 0 : p.code);
          p = void 0;
          var r =
            !q && m.Oa.auctionId !== ((p = g) == null ? void 0 : p.auctionId);
          a || r || q || !m.Oa.transactionId || (a = m.Oa.transactionId);
          var t = (p = void 0),
            v = void 0,
            x =
              (v =
                (p = l.find(
                  (function (B) {
                    return function (J) {
                      return J.bidId === B.Oa.requestId;
                    };
                  })(m)
                )) == null
                  ? void 0
                  : p.mediaTypes) != null
                ? v
                : (t = b) == null
                ? void 0
                : t.mediaTypes,
            E = dN(m.Oa, x, c, d),
            F = Ez(
              Hz(Gz(Fz(Dz(new Rg(), m.Oa.bidder), 1), r), bN(m.Oa.source)),
              E
            );
          cN(e, m.Oa.bidder, F);
          typeof m.Oa.timeToRespond === "number" &&
            fh(F, 2, Math.round(m.Oa.timeToRespond));
          h.push(F);
        }
      } finally {
        z(f, k);
      }
      return { Xc: h, transactionId: a };
    },
    { id: 1674, pa: { Xc: void 0, transactionId: void 0 } }
  );
  var fN = new Map();
  function gN(a, b, c) {
    return a ? (c !== void 0 ? c(a) : a === b.jg || a === b.adUnitCode) : !1;
  }
  function hN(a) {
    var b, c;
    return (
      ((b = a.jg) != null ? b : "") + ((c = a.adUnitCode) != null ? c : "")
    );
  }
  function iN(a) {
    var b = [];
    a = y(Object.entries(a));
    var c = a.next();
    try {
      for (; !c.done; c = a.next()) {
        var d = y(c.value),
          e = d.next().value,
          f = d.next().value,
          g = e,
          h = f,
          k = void 0;
        ((k = h) == null ? void 0 : k[0]) != null &&
          (g.startsWith("hb_adid") || g.startsWith("bid_id")) &&
          b.push(h[0]);
      }
    } finally {
      z(a, c);
    }
    return b;
  }
  function jN(a, b, c) {
    function d() {
      if (!k) {
        var B;
        k = (
          (B = a.getEvents) != null
            ? B
            : function () {
                return [];
              }
        )();
      }
      return k;
    }
    var e = hN(b);
    if (fN.has(e)) return fN.get(e);
    var f,
      g =
        (f = a.adUnits) == null
          ? void 0
          : f.find(function (B) {
              return gN(
                B == null ? void 0 : B.code,
                b,
                c.customGptSlotMatching
              );
            }),
      h = c.vm;
    f = c.ym;
    var k;
    g ||
      (h ||
        (h = d().filter(function (B) {
          return B.eventType === "auctionEnd";
        })),
      (g = h
        .flatMap(function (B) {
          return B.args.adUnits;
        })
        .find(function (B) {
          return gN(B == null ? void 0 : B.code, b, c.customGptSlotMatching);
        })));
    var l = g ? [] : iN(c.nh);
    if (!g && a.getBidResponseByAdId) {
      h = y(l);
      var m = h.next();
      try {
        for (var p = {}; !m.done; p = { re: void 0 }, m = h.next()) {
          p.re = a.getBidResponseByAdId(m.value);
          var q = void 0;
          if ((q = p.re) == null ? 0 : q.adUnitCode)
            if (
              ((q = void 0),
              (g =
                (q = a.adUnits) == null
                  ? void 0
                  : q.find(
                      (function (B) {
                        return function (J) {
                          return J.code === B.re.adUnitCode;
                        };
                      })(p)
                    )))
            )
              break;
        }
      } finally {
        z(h, m);
      }
    }
    if (!g) {
      f ||
        (f = d().filter(function (B) {
          return B.eventType === "bidResponse";
        }));
      f = f.find(function (B) {
        var J;
        if (!(J = B.args.adId != null && l.includes(B.args.adId))) {
          var Q, oa, ta;
          J =
            (ta = (Q = B.args) == null ? void 0 : Q.sharedBidInUse) != null
              ? ta
              : (oa = B.args) == null
              ? void 0
              : oa.adUnitCode;
          J = gN(J, b, c.customGptSlotMatching);
        }
        return J;
      });
      var r,
        t,
        v,
        x =
          (v =
            f == null
              ? void 0
              : (r = f.args) == null
              ? void 0
              : r.sharedBidInUse) != null
            ? v
            : f == null
            ? void 0
            : (t = f.args) == null
            ? void 0
            : t.adUnitCode;
      if (x) {
        var E, F;
        g =
          (F =
            (E = a.adUnits) == null
              ? void 0
              : E.find(function (B) {
                  return B.code === x;
                })) != null
            ? F
            : { code: x };
      }
    }
    if (g) return fN.set(e, g), g;
  }
  function kN(a, b) {
    var c = a.reduce(function (e, f) {
        var g = f.bidder;
        e[g] || (e[g] = []);
        e[g].push(f);
        return e;
      }, {}),
      d = [];
    Object.keys(c).forEach(function (e) {
      d.push(
        c[e]
          .sort(function (f, g) {
            var h, k;
            return (
              ((h = f.timeToRespond) != null ? h : 0) -
              ((k = g.timeToRespond) != null ? k : 0)
            );
          })
          .reduce(function (f, g) {
            var h, k;
            return ((h = f.cpm) != null ? h : 0) >=
              ((k = g.cpm) != null ? k : 0)
              ? f
              : g;
          })
      );
    });
    d.sort(function (e, f) {
      var g, h;
      return ((g = f.cpm) != null ? g : 0) - ((h = e.cpm) != null ? h : 0);
    });
    return b ? d.slice(0, b) : d;
  }
  function lN(a, b, c, d) {
    var e,
      f = (e = b.getConfig) == null ? void 0 : e.call(b).ttlBuffer,
      g;
    e = (g = a.responseTimestamp) != null ? g : 0;
    var h, k;
    g =
      ((h = a.ttl) != null ? h : 0) -
      ((k = a.ttlBuffer) != null ? k : f === void 0 ? 1 : f);
    if (!(e + g * 1e3 > new Date().getTime() && "rendered" !== a.status))
      return !1;
    var l;
    f = (l = b.getConfig) == null ? void 0 : l.call(b).useBidCache;
    var m;
    l = (m = b.getConfig) == null ? void 0 : m.call(b).bidCacheFilterFunction;
    b = a.auctionId === c;
    c = f && !b && typeof l === "function" ? !!l(a) : !0;
    return (a.adUnitCode !== d || f || b) && c;
  }
  function mN(a, b, c) {
    var d = [];
    if (a.getBidResponseByAdId) {
      b = y(iN(b));
      var e = b.next();
      try {
        for (; !e.done; e = b.next()) {
          var f = a.getBidResponseByAdId(e.value);
          if (f && c(f)) {
            d.push(f);
            break;
          }
        }
      } finally {
        z(b, e);
      }
    }
    return d;
  }
  function nN(a, b, c, d) {
    var e = b.getBidResponsesForAdUnitCode,
      f,
      g;
    e = (
      e && a.code
        ? (g = (f = e(a.code)) == null ? void 0 : f.bids) != null
          ? g
          : []
        : []
    ).filter(function (h) {
      return lN(h, b, c, a.code);
    });
    return e.length === 0
      ? mN(b, d, function (h) {
          return lN(h, b, c, a.code);
        })
      : e;
  }
  var oN = nK(
    function (a, b, c, d) {
      a = a.Ha;
      if (!b || !a) return { Db: void 0 };
      b = nN(b, c, a.auctionId || "", d);
      if (!b.length) return { Db: void 0 };
      var e;
      d = (e = c.getConfig) == null ? void 0 : e.call(c).enableSendAllBids;
      var f, g;
      e =
        (f = c.getConfig) == null
          ? void 0
          : (g = f.call(c).sendBidsControl) == null
          ? void 0
          : g.bidLimit;
      return { Db: kN(b, (d && e) || 0) };
    },
    { id: 1673, pa: { Db: void 0 } }
  );
  var pN = new Map();
  function qN(a, b, c) {
    var d,
      e = (d = pN.get(hN(b))) != null ? d : 0,
      f = function (l) {
        return l === a.code;
      },
      g;
    b =
      (g = c.filter(function (l) {
        var m, p, q;
        return (
          Number((m = l.args) == null ? void 0 : m.timestamp) > e &&
          ((p = l.args) == null
            ? void 0
            : (q = p.adUnitCodes) == null
            ? void 0
            : q.find(f))
        );
      })) != null
        ? g
        : [];
    if (!b.length) return null;
    var h, k;
    return (k =
      (h = b.reduce(function (l, m) {
        return Number(m.args.timestamp) > Number(l.args.timestamp) ? m : l;
      })) == null
        ? void 0
        : h.args) != null
      ? k
      : null;
  }
  var rN = nK(
    function (a, b, c, d) {
      if (!b) return { Ha: void 0 };
      a = qN(b, c, d);
      if (!a) return { Ha: void 0 };
      b = a.bidderRequests;
      b = b === void 0 ? [] : b;
      d = a.timestamp;
      a.auctionId && d != null && b.length && pN.set(hN(c), d);
      return { Ha: a };
    },
    { id: 1662, pa: { Ha: void 0 } }
  );
  function sN(a, b, c, d) {
    var e = new Map(),
      f = function (Ma) {
        var wa = e.get(Ma);
        wa || ((wa = {}), e.set(Ma, wa));
        return wa;
      };
    a = y(a);
    var g = a.next();
    try {
      for (; !g.done; g = a.next()) {
        var h = g.value,
          k = h.args,
          l = h.elapsedTime;
        if (k.auctionId === d && Array.isArray(k.bids)) {
          var m = y(k.bids),
            p = m.next();
          try {
            for (; !p.done; p = m.next()) {
              var q = p.value.bidId;
              q && (f(q).requestTime = l);
            }
          } finally {
            z(m, p);
          }
        }
      }
    } finally {
      z(a, g);
    }
    b = y(b);
    h = b.next();
    try {
      for (; !h.done; h = b.next()) {
        var r = h.value,
          t = r.args,
          v = r.elapsedTime;
        t.auctionId === d && t.bidId && (f(t.bidId).Vj = v);
      }
    } finally {
      z(b, h);
    }
    f = new Map();
    r = y(e.entries());
    t = r.next();
    try {
      for (; !t.done; t = r.next()) {
        var x = y(t.value),
          E = x.next().value,
          F = x.next().value,
          B = F.requestTime,
          J = F.Vj;
        B && J && f.set(E, { latency: J - B, Hg: !1 });
      }
    } finally {
      z(r, t);
    }
    c = y(c);
    x = c.next();
    try {
      for (; !x.done; x = c.next()) {
        var Q = y(x.value.args),
          oa = Q.next();
        try {
          for (; !oa.done; oa = Q.next()) {
            var ta = oa.value,
              Da = ta.bidId,
              ca = ta.auctionId;
            if (Da && ca === d) {
              var fa = f.get(Da);
              fa && (fa.Hg = !0);
            }
          }
        } finally {
          z(Q, oa);
        }
      }
    } finally {
      z(c, x);
    }
    return f;
  }
  var tN = /^v?\d{1,3}(\.\d{1,3}){0,2}(-pre)?$/;
  function uN() {
    var a = window,
      b,
      c;
    return (c = ((b = a._pbjsGlobals) != null ? b : [])
      .concat(["pbjs"])
      .map(function (d) {
        return a[d];
      })
      .find(function (d) {
        return Array.isArray(d == null ? void 0 : d.que);
      })) != null
      ? c
      : null;
  }
  function vN(a) {
    return a && typeof a === "object"
      ? Array.isArray(a)
        ? [].concat(ra(a))
        : xa({}, a)
      : a;
  }
  function wN(a) {
    try {
      var b;
      return vN((b = a.getAdserverTargeting) == null ? void 0 : b.call(a));
    } catch (c) {}
  }
  function xN(a) {
    var b,
      c = vN((b = a.getEvents) == null ? void 0 : b.call(a)),
      d,
      e = vN((d = a.getConfig) == null ? void 0 : d.call(a));
    b = vN(a.adUnits);
    d = vN(a.aliasRegistry);
    var f = wN(a),
      g,
      h = vN((g = a.getUserIdsAsEids) == null ? void 0 : g.call(a)),
      k = new Map(),
      l = new Map();
    if (a.getBidResponsesForAdUnitCode) {
      g = y(b || []);
      var m = g.next();
      try {
        for (; !m.done; m = g.next()) {
          var p = m.value;
          if (p.code) {
            var q = a.getBidResponsesForAdUnitCode(p.code);
            if (q !== void 0 && q !== null) {
              var r = vN(q);
              r.bids
                ? (r.bids = vN(r.bids))
                : Array.isArray(r) && (r.bids = vN(r));
              if (r.bids) {
                k.set(p.code, r);
                var t = y(r.bids),
                  v = t.next();
                try {
                  for (; !v.done; v = t.next()) {
                    var x = v.value;
                    x && x.adId && l.set(x.adId, x);
                  }
                } finally {
                  z(t, v);
                }
              }
            }
          }
        }
      } finally {
        z(g, m);
      }
    }
    var E;
    return {
      adUnits: b,
      aliasRegistry: d,
      getBidResponsesForAdUnitCode: a.getBidResponsesForAdUnitCode
        ? function (F) {
            var B, J;
            return (J = k.get(F)) != null
              ? J
              : (B = a.getBidResponsesForAdUnitCode) == null
              ? void 0
              : B.call(a, F);
          }
        : a.getBidResponsesForAdUnitCode,
      getBidResponseByAdId: a.getBidResponseByAdId
        ? function (F) {
            var B, J, Q;
            return (Q =
              (J = l.get(F)) != null
                ? J
                : (B = a.getBidResponseByAdId) == null
                ? void 0
                : B.call(a, F)) != null
              ? Q
              : null;
          }
        : a.getBidResponseByAdId,
      getConfig: e
        ? function () {
            return e;
          }
        : void 0,
      getEvents: c
        ? function () {
            return c;
          }
        : void 0,
      version: (E = a.version) != null ? E : "",
      getAdserverTargeting: f
        ? function () {
            return f;
          }
        : void 0,
      installedModules: a.installedModules,
      getUserIdsAsEids: h
        ? function () {
            return h;
          }
        : void 0,
      getUserIdsAsEidBySource: h
        ? function (F) {
            return h.find(function (B) {
              return B.source === F;
            });
          }
        : void 0,
      markWinningBidAsUsed: a.markWinningBidAsUsed,
    };
  }
  function yN() {
    var a = uN();
    return a ? xN(a) : null;
  }
  function zN(a, b) {
    var c, d, e;
    b == null ? (e = void 0) : (e = b.get.call(b, a));
    return (d = (c = e) != null ? c : b == null ? void 0 : b.get(jq(a))) != null
      ? d
      : 0;
  }
  function AN(a, b, c, d, e, f, g) {
    d = g.get(
      d != null
        ? d
        : function () {
            return null;
          }
    );
    (d == null ? void 0 : Zg(d, 1)) !== 1 && Mg(b, 5, d);
    if (!a)
      return d
        ? Zg(d, 1) === 1
          ? d
          : Cz(Az(Bz(new zz(), e), 1), zN(c, f))
        : Az(Bz(new zz(), e), zN(c, f) ? 2 : 3);
  }
  var BN = nK(
    function (a, b, c, d, e, f, g, h, k, l) {
      var m = a.Ha;
      a = [];
      c = void 0;
      var p = Mj(function () {
        return sN(h, k, l, (m == null ? void 0 : m.auctionId) || "");
      });
      e = e || new Map();
      var q,
        r = y((q = m == null ? void 0 : m.bidderRequests) != null ? q : []);
      q = r.next();
      try {
        for (; !q.done; q = r.next()) {
          var t = q.value,
            v = t.bidderCode,
            x = t.src,
            E = t.timeout,
            F = y(t.bids),
            B = F.next();
          try {
            for (var J = {}; !B.done; J = { qd: void 0 }, B = F.next()) {
              var Q = B.value;
              J.qd = Q.bidId;
              var oa = Q.adUnitCode,
                ta = Q.getFloor;
              if (J.qd) {
                var Da = void 0;
                if (oa === ((Da = b) == null ? void 0 : Da.code)) {
                  var ca = (Da = void 0);
                  if (
                    !((Da = m) == null
                      ? 0
                      : (ca = Da.bidsReceived) == null
                      ? 0
                      : ca.find(
                          (function (Ia) {
                            return function (Vb) {
                              return Vb.requestId === Ia.qd;
                            };
                          })(J)
                        ))
                  ) {
                    var fa = Dz(new Rg(), v);
                    cN(d, v, fa);
                    Hz(fa, bN(x));
                    a.push(fa);
                    var Ma = AN(!!c, fa, oa, ta, f, e, g);
                    Ma && (c = Ma);
                    var wa = p().get(J.qd);
                    wa && !wa.Hg
                      ? (Fz(fa, 2),
                        Number.isFinite(wa.latency) &&
                          fh(fa, 2, Math.round(wa.latency)))
                      : (Fz(fa, 3),
                        Number.isFinite(E) && fh(fa, 2, Math.round(E)));
                  }
                }
              }
            }
          } finally {
            z(F, B);
          }
        }
      } finally {
        z(r, q);
      }
      return { Xc: a, Ah: c };
    },
    { id: 1666, pa: { Xc: void 0, Ah: void 0 } }
  );
  var CN = nK(
    function (a, b, c, d) {
      a = a.Ha;
      if (!a || !b) return { ld: void 0, transactionId: void 0 };
      var e = d.G,
        f = e[H] | 0;
      d = $f(d, e, f) ? Zf(d, e, !0) : new d.constructor(Yf(e, f, !1));
      e = void 0;
      var g;
      a = y((g = a.bidderRequests) != null ? g : []);
      g = a.next();
      try {
        for (; !g.done; g = a.next()) {
          var h = g.value,
            k = h.timeout,
            l = y(h.bids),
            m = l.next();
          try {
            for (; !m.done; m = l.next()) {
              var p = m.value,
                q = p.transactionId,
                r = p.adUnitCode;
              p.bidId &&
                r === b.code &&
                (Te(gg(d, 3)) != null ||
                  (r === c.adUnitCode
                    ? ih(d, 3, 1)
                    : r === c.jg && ih(d, 3, 2)),
                q &&
                  (e != null || (e = q), jf(gg(d, 4)) != null || hh(d, 4, q)),
                Ve(gg(d, 8)) == null && Number.isFinite(k) && dh(d, 8, k));
            }
          } finally {
            z(l, m);
          }
        }
      } finally {
        z(a, g);
      }
      return { ld: d, transactionId: e };
    },
    { id: 1665, pa: { ld: void 0, transactionId: void 0 } }
  );
  var DN = function (a) {
    pK.call(this, a.Qa, 106);
    var b = a.slot,
      c = a.fi,
      d = a.gk,
      e = a.pbjs,
      f = a.events,
      g = a.Oj,
      h = a.Nj,
      k = a.Qi,
      l = k.Qj,
      m = k.Ki,
      p = k.Ri;
    k = a.yi;
    a = k.uj;
    k = k.Jj;
    !c && iN(d).length > 0 && k();
    k = this.h(rN, {}, c, b, f.auctionEnd).Ha;
    var q = this.h(CN, { Ha: k }, c, b, g, h);
    g = q.ld;
    q = q.transactionId;
    f = this.h(
      BN,
      { Ha: k },
      c,
      b,
      e,
      l != null ? l : null,
      m,
      p || new Map(),
      f.li,
      f.tj,
      f.mi
    );
    b = f.Xc;
    f = f.Ah;
    l = this.h(oN, { Ha: k }, c, e, d).Db;
    d = this.h(eN, { Db: l, Ha: k, transactionId: q }, c, d, h, e);
    c = d.Xc;
    d = d.transactionId;
    this.h(aN, { Db: l }, a);
    this.F = {
      Oi: this.h($M, { ld: g, nk: b, Pi: c, Ha: k, kk: d, lk: q, fj: f }).zf,
    };
  };
  w(DN, pK);
  function EN(a) {
    var b = new Kz();
    b = ih(b, 1, 1);
    a.version && tN.test(a.version) && hh(b, 6, a.version);
    var c, d, e;
    if (
      (c = a.getConfig) == null
        ? 0
        : (d = c.call(a).cache) == null
        ? 0
        : (e = d.url) == null
        ? 0
        : e.length
    ) {
      var f, g;
      c =
        (f = a.getConfig) == null
          ? void 0
          : (g = f.call(a).cache) == null
          ? void 0
          : g.url;
      hh(b, 10, c);
    }
    return b;
  }
  function FN(a) {
    a = a.getEvents ? a.getEvents() : [];
    a = uc(a, function (b) {
      return b.eventType;
    });
    return {
      auctionEnd: a.auctionEnd || [],
      li: a.bidRequested || [],
      tj: a.noBid || [],
      mi: a.bidTimeout || [],
      xm: a.bidResponse || [],
    };
  }
  function GN(a, b) {
    if (!b) return [];
    var c = qI(a);
    a = jN(b, { adUnitCode: c }, { nh: rI(a) });
    if (!a || !a.code) return [];
    var d, e;
    c =
      (d = b.getBidResponsesForAdUnitCode) == null
        ? void 0
        : (e = d.call(b, a.code)) == null
        ? void 0
        : e.bids;
    return Array.isArray(c) ? c : [];
  }
  function HN(a, b, c) {
    var d = {
      m: "getPrebidBidResponsesByAdTagUrl",
      adTagUrlNotEmpty: b ? "1" : "0",
    };
    a = GN(b, a);
    if (a.length === 0)
      return (
        IN(d, "cannot_find_any_bids_for_ad_tag_url"),
        (d = {}),
        (d.error = JN(fJ)),
        d
      );
    a = a.find(function (e) {
      return e.adId === c;
    });
    if (!a) return IN(d, "cannot_find_bid"), (d = {}), (d.error = JN(fJ)), d;
    IN(d);
    d = {};
    return (d.vastUrl = a.vastUrl), (d.vastXml = a.vastXml), d;
  }
  function IN(a, b) {
    W.getInstance().report(243, xa({}, a, { error: b }));
  }
  function JN(a, b) {
    b = b === void 0 ? null : b;
    return kJ("adLoadError", a, b instanceof Error ? b : null, []).ha();
  }
  function KN(a, b, c, d) {
    var e, f, g, h, k, l;
    return Ka(function (m) {
      if (m.j == 1)
        return (
          (e = FN(a)),
          (f = EN(a)),
          (g = { Ya: function () {} }),
          (h = new DN({
            Qa: g,
            slot: { adUnitCode: b },
            fi: d,
            gk: c,
            pbjs: a,
            events: e,
            Oj: f,
            Qi: { Qj: void 0, Ki: !1, Ri: void 0 },
            yi: { uj: function () {}, Jj: function () {} },
            Nj: {},
          })),
          sK(h),
          m.h(h.F.Oi.promise, 2)
        );
      k = m.l;
      return m.return((l = k) == null ? void 0 : l.zc);
    });
  }
  function LN(a, b, c) {
    var d, e, f, g, h, k, l, m, p, q;
    return Ka(function (r) {
      switch (r.j) {
        case 1:
          d = function (t) {
            W.getInstance().report(195, {
              method: "getPrebidRequestDataForAdsRequest",
              message: t == null ? void 0 : t.message,
            });
          };
          r.A(2);
          if (!c) return r.return({ zc: void 0, globalPlacementId: void 0 });
          f = (e = qI(a, d)) ? (jp(Ap) ? 1 : JL(b, oI(e)) ? 2 : 0) : 0;
          g = rI(a);
          h = jN(c, { adUnitCode: e }, { nh: g });
          k = void 0;
          if (f !== 1 && f !== 2) {
            r.ia(4);
            break;
          }
          return r.h(KN(c, e, g, h), 5);
        case 5:
          k = r.l;
        case 4:
          return (
            (p =
              h != null
                ? (l = ZM(c, [[{ adUnitCode: e }, h]])[0]) == null
                  ? void 0
                  : (m = l.gpid) == null
                  ? void 0
                  : m.substring(0, 128)
                : void 0),
            r.return({ zc: k, globalPlacementId: p })
          );
        case 2:
          return (
            (q = r.o()),
            d(q),
            r.return({ zc: void 0, globalPlacementId: void 0 })
          );
      }
    });
  }
  var MN = function (a, b) {
      this.h = a;
      this.j = b;
    },
    ON = function (a, b, c) {
      var d = {};
      d.contentMediaUrl = a.h.xe;
      d.customClickTrackingProvided = a.h.Ae != null;
      d.isAmp = TH();
      a: {
        try {
          var e = window.top.location.href;
        } catch (x) {
          e = 2;
          break a;
        }
        e = e == null ? 2 : e === window.document.location.href ? 0 : 1;
      }
      d.iframeState = e;
      d.imaHostingDomain = window.document.domain;
      d.imaHostingPageUrl = window.document.URL;
      d.topAccessiblePageUrl = SH();
      d.referrer = window.document.referrer;
      d.domLoadTime = c.uc;
      d.sdkImplLoadTime = c.Fc;
      d.supportsResizing = !NN(a.h);
      c = ol().location.ancestorOrigins;
      d.topOrigin = c
        ? c.length > 0 && c[c.length - 1].length < 200
          ? c[c.length - 1]
          : ""
        : null;
      d.osdId = a.j;
      d.usesCustomVideoPlayback = NN(a.h);
      d.usesProxyMediaElement = a.h.Jf();
      d.usesInlinePlayback = a.h.xd;
      c = a.h.hd;
      a = [];
      var f = (e = "");
      if (c != null) {
        e = c;
        f = !0;
        f = f === void 0 ? !1 : f;
        for (var g = [], h = 0; e && h < 25; ++h) {
          var k = "";
          (f !== void 0 && f) ||
            (k = (k = e.nodeType !== 9 && e.id) ? "/" + k : "");
          a: {
            if (e && e.nodeName && e.parentElement)
              for (
                var l = e.nodeName.toString().toLowerCase(),
                  m = e.parentElement.childNodes,
                  p = 0,
                  q = 0;
                q < m.length;
                ++q
              ) {
                var r = m[q];
                if (r.nodeName && r.nodeName.toString().toLowerCase() === l) {
                  if (e === r) {
                    r = "." + p;
                    break a;
                  }
                  ++p;
                }
              }
            r = "";
          }
          g.push((e.nodeName && e.nodeName.toString().toLowerCase()) + k + r);
          e = e.parentElement;
        }
        e = g.join();
        if (c) {
          c =
            ((c = c.ownerDocument) && (c.defaultView || c.parentWindow)) ||
            null;
          f = [];
          if (c)
            try {
              var t = c.parent;
              for (g = 0; t && t !== c && g < 25; ++g) {
                var v = t.frames;
                for (h = 0; h < v.length; ++h)
                  if (c === v[h]) {
                    f.push(h);
                    break;
                  }
                c = t;
                t = c.parent;
              }
            } catch (x) {}
          f = f.join();
        } else f = "";
      }
      a.push(e, f);
      if (b != null) {
        for (t = 0; t < AB.length - 1; ++t) a.push(iq(b, AB[t]) || "");
        b = iq(b, "videoad_start_delay");
        t = "";
        b &&
          ((b = parseInt(b, 10)),
          (t = b < 0 ? "postroll" : b == 0 ? "preroll" : "midroll"));
        a.push(t);
      } else for (b = 0; b < AB.length; ++b) a.push("");
      return (d.videoAdKey = jq(a.join(":")).toString()), d;
    };
  function PN() {
    var a,
      b,
      c,
      d = ol();
    d = d === void 0 ? window : d;
    d = ((c = d === void 0 ? null : d) != null ? c : window).googletag;
    c = (d == null ? 0 : d.apiReady) ? d : void 0;
    return (b =
      c == null ? void 0 : (a = c.companionAds) == null ? void 0 : a.call(c)) !=
      null
      ? b
      : null;
  }
  function QN(a) {
    var b = {};
    b.slotId = a.getSlotId().getId();
    var c = [];
    a = y(a.getSizes() || []);
    var d = a.next();
    try {
      for (; !d.done; d = a.next()) {
        var e = d.value;
        if (typeof e !== "string") {
          var f = {};
          c.push(((f.adWidth = e.getWidth()), (f.adHeight = e.getHeight()), f));
        } else e === "fluid" && ((f = {}), c.push(((f.fluidSize = !0), f)));
      }
    } finally {
      z(a, d);
    }
    return (b.adSizes = c), b;
  }
  function RN(a) {
    var b = PN();
    if (b && a && Array.isArray(a)) {
      var c = new Map(
        b.getSlots().map(function (v) {
          return [v.getSlotId().getId(), v];
        })
      );
      a = y(a);
      var d = a.next();
      try {
        for (; !d.done; d = a.next()) {
          var e = d.value,
            f = c.get(e.slotId);
          if (f && !b.isSlotAPersistentRoadblock(f)) {
            var g = e.adContent;
            if (g) {
              var h = kl(f.getSlotId().getDomId());
              if (h) {
                h.style.display = "";
                var k = e.adWidth,
                  l = e.adHeight;
                if (e.fluidSize) {
                  var m = Ql(h);
                  k = m.width;
                  l = m.height;
                }
                h.textContent = "";
                if (e.friendlyIframeRendering)
                  try {
                    var p = "google_companion_" + f.getSlotId().getId(),
                      q = zB(h, p, k, l),
                      r = q.contentWindow
                        ? q.contentWindow.document
                        : q.contentDocument;
                    Dc && r.open("text/html", "replace");
                    ok(r, GB(g));
                    r.close();
                  } catch (v) {}
                else
                  mk(h, GB(g)),
                    (h.style.width = k + "px"),
                    (h.style.height = l + "px");
                b.slotRenderEnded(f, k, l);
                var t = e.onAdContentSet;
                t && t(h);
              }
            }
          }
        }
      } finally {
        z(a, d);
      }
    }
  }
  var SN = function (a, b, c, d, e, f) {
    vI.call(this, a, b, c, d, e);
    this.h = f;
  };
  w(SN, vI);
  var TN = function (a, b) {
    S.call(this);
    this.A = a;
    this.o = b;
    this.h = {};
    this.Qa = null;
    this.j = new zD(this);
    tt(this, this.j);
    this.j.listen(ol(), "message", this.l);
    this.Qa = null;
  };
  w(TN, S);
  var UN = function (a, b) {
      var c = b.h;
      a.h.hasOwnProperty(c) && uI(a.h[c], b.type, b.messageType, b.ra);
    },
    VN = function (a, b, c, d) {
      a.h.hasOwnProperty(b) ||
        ((c = new pL(b, c)),
        a.j.listen(c, a.A, function (e) {
          this.dispatchEvent(
            new SN(e.type, e.messageType, e.ra, e.sessionId, e.origin, b)
          );
        }),
        (c.h = d),
        c.connect(),
        (a.h[b] = c));
    };
  TN.prototype.M = function () {
    var a = y(Object.values(this.h)),
      b = a.next();
    try {
      for (; !b.done; b = a.next()) qt(b.value);
    } finally {
      z(a, b);
    }
    S.prototype.M.call(this);
  };
  TN.prototype.l = function (a) {
    a = a.Jc;
    var b = nL(a.data);
    if (b != null) {
      var c = b.channel;
      if (this.o && !this.h.hasOwnProperty(c)) {
        var d = b.sid;
        VN(this, c, d, a.source);
        this.dispatchEvent(
          new SN(b.name, b.type, b.data || {}, d, a.origin, c)
        );
      }
    }
  };
  function WN() {
    return !!$a("googletag.cmd", ol());
  }
  function XN() {
    var a = $a("googletag.console", ol());
    return a != null ? a : null;
  }
  function YN(a) {
    return (
      typeof a === "object" &&
      a !== null &&
      typeof a.getSizes === "function" &&
      typeof a.getSlotId === "function"
    );
  }
  var ZN = function () {
    zD.call(this);
    this.Qa = this.h = null;
    this.j = new TN("gpt", !0);
    tt(this, this.j);
    this.listen(this.j, "gpt", this.D);
    WN() ||
      ol().top === ol() ||
      ((this.h = new TN("gpt", !1)),
      tt(this, this.h),
      this.listen(this.h, "gpt", this.A));
  };
  w(ZN, zD);
  ZN.prototype.D = function (a) {
    var b = a.origin,
      c = "//imasdk.googleapis.com".match(eq);
    b = b.match(eq);
    if (c[3] == b[3] && c[4] == b[4])
      if (this.h != null)
        VN(this.h, a.h, a.sessionId, ol().parent),
          this.h != null && UN(this.h, a);
      else if (((c = a.ra), c != null && c.scope !== void 0)) {
        b = c.scope;
        c = c.args;
        var d;
        if (b === "proxy") {
          var e = a.messageType;
          e === "isGptPresent"
            ? (d = WN())
            : e === "isConsolePresent" && (d = XN() != null);
        } else if (WN())
          if (b === "pubads" || b === "companionAds") {
            d = a.messageType;
            var f = ol().googletag;
            if (
              f != null &&
              f[b] != null &&
              ((b = f[b]()), b != null && ((d = b[d]), d != null))
            )
              try {
                e = d.apply(b, c);
              } catch (g) {}
            d = e;
            a.messageType === "getSlots" &&
              (Array.isArray(d) && d.every(YN) ? (d = $N(d)) : (d = null));
          } else if (b === "console") {
            if (((e = XN()), e != null && ((b = e[a.messageType]), b != null)))
              try {
                b.apply(e, c);
              } catch (g) {}
          } else
            b === null &&
              ((e = a.messageType),
              e === "googleGetCompanionAdSlots"
                ? (e = PN())
                  ? ((e = e.getSlots().map(QN)), (d = e.length ? e : null))
                  : (d = null)
                : (e === "googleSetCompanionAdContents" &&
                    RN(c == null ? void 0 : c[0]),
                  (d = null)));
        d !== void 0 && ((a.ra.returnValue = d), UN(this.j, a));
      }
  };
  var $N = function (a) {
    if (a == null) return null;
    a = a.map(function (b) {
      var c = b.getSizes();
      if (c == null)
        return (
          (c = {}), (c.slotId = b.getSlotId().getId()), (c.adSizes = []), c
        );
      var d = {};
      return (
        (d.adSizes = c.map(function (e) {
          if (
            typeof e === "string" ||
            (Array.isArray(e) && (e[0] === "fluid" || e[0] === "auto"))
          )
            return (e = {}), (e.fluidSize = !0), e;
          var f = {};
          return (f.adWidth = e.getWidth()), (f.adHeight = e.getHeight()), f;
        })),
        (d.slotId = b.getSlotId().getId()),
        d
      );
    });
    return a.length > 0 ? a : null;
  };
  ZN.prototype.A = function (a) {
    UN(this.j, a);
  };
  var aO = function (a, b) {
    if (a.h) {
      var c = a.h;
      qt(c.h[b]);
      delete c.h[b];
    }
    a.j && ((a = a.j), qt(a.h[b]), delete a.h[b]);
  };
  function bO(a, b) {
    var c = Array.prototype.slice.call(arguments),
      d = c.shift();
    if (typeof d == "undefined")
      throw Error("[goog.string.format] Template required");
    return d.replace(
      /%([0\- \+]*)(\d+)?(\.(\d+))?([%sfdiu])/g,
      function (e, f, g, h, k, l, m, p) {
        if (l == "%") return "%";
        var q = c.shift();
        if (typeof q == "undefined")
          throw Error("[goog.string.format] Not enough arguments");
        arguments[0] = q;
        return cO[l].apply(null, arguments);
      }
    );
  }
  var cO = {
    s: function (a, b, c) {
      return isNaN(c) || c == "" || a.length >= Number(c)
        ? a
        : (a =
            b.indexOf("-", 0) > -1
              ? a + sk(" ", Number(c) - a.length)
              : sk(" ", Number(c) - a.length) + a);
    },
    f: function (a, b, c, d, e) {
      d = a.toString();
      isNaN(e) || e == "" || (d = parseFloat(a).toFixed(e));
      var f =
        Number(a) < 0
          ? "-"
          : b.indexOf("+") >= 0
          ? "+"
          : b.indexOf(" ") >= 0
          ? " "
          : "";
      Number(a) >= 0 && (d = f + d);
      if (isNaN(c) || d.length >= Number(c)) return d;
      d = isNaN(e)
        ? Math.abs(Number(a)).toString()
        : Math.abs(Number(a)).toFixed(e);
      a = Number(c) - d.length - f.length;
      return (d =
        b.indexOf("-", 0) >= 0
          ? f + d + sk(" ", a)
          : f + sk(b.indexOf("0", 0) >= 0 ? "0" : " ", a) + d);
    },
    d: function (a, b, c, d, e, f, g, h) {
      return cO.f(parseInt(a, 10), b, c, d, 0, f, g, h);
    },
  };
  cO.i = cO.d;
  cO.u = cO.d;
  var dO = ua(["https://imasdk.googleapis.com/js/core"]);
  function eO() {
    return ["autoplay"]
      .filter(function (a) {
        var b = document.featurePolicy;
        return (
          b !== void 0 &&
          typeof b.allowedFeatures === "function" &&
          typeof b.allowedFeatures() === "object" &&
          Array.isArray(b.allowedFeatures()) &&
          b.allowedFeatures().includes(a)
        );
      })
      .join(";");
  }
  function fO(a, b, c) {
    var d, e, f, g, h, k, l, m, p, q, r, t, v, x, E, F, B;
    return Ka(function (J) {
      if (J.j == 1)
        return (
          (d = new MM()),
          (e = XM(null, 1e3)),
          (f = yN()),
          (g = e.then(function (Q) {
            return LN("", Q, f);
          })),
          (h = y),
          J.h(Promise.all([ZI(a), e, g]), 2)
        );
      k = h(J.l);
      l = k.next().value;
      m = k.next().value;
      p = k.next().value;
      q = l;
      r = m;
      t = p;
      x = BI("", q, (v = Op()) == null ? void 0 : Tg(v, 2));
      E = {};
      F = ON(b, "", { uc: c.uc, Fc: c.Fc });
      B = new GM();
      return J.return(
        LM(d, q, x, null, r, null, t.zc, t.globalPlacementId, E, F, B)
      );
    });
  }
  var iO = function (a, b, c, d) {
    d = d === void 0 ? !1 : d;
    S.call(this);
    this.l = b;
    this.A = c;
    this.K = d;
    this.Fc = this.uc = this.Mc = null;
    this.connected = !1;
    this.C = vk();
    this.o = new Map();
    c = ol();
    d = $a("google.ima.gptProxyInstance", c);
    d != null
      ? (c = d)
      : ((d = new ZN()), D("google.ima.gptProxyInstance", d, c), (c = d));
    this.R = c;
    this.B = null;
    this.j = new zD(this);
    tt(this, this.j);
    this.se = Bn();
    this.frameElement = gO(this, this.C, a);
    this.h = hO(this);
    this.F = new YI(window);
    tt(this, this.F);
    this.O = new MN(this.l, null);
    this.H = new VM(this.h, this.l);
    tt(this, this.H);
    this.l.ma && this.j.listen(this.h, "displayContainer", this.J);
    this.j.listen(this.h, "mouse", this.T);
    this.j.listen(this.h, "touch", this.W);
    c = b.Jf();
    Ms() ||
      (Pb(Sb(), "CrKey") && Pb(Sb(), "SmartSpeaker")) ||
      Pb(Sb(), "Edge/18.") ||
      c ||
      ((this.B = new OM(a, this.h, b.ma.h)), tt(this, this.B));
  };
  w(iO, S);
  var hO = function (a, b) {
    b = b === void 0 ? "*" : b;
    var c = a.o.get(b);
    c == null &&
      ((c = new pL(a.C, b)),
      a.connected && ((c.h = vl(a.frameElement)), c.connect()),
      a.o.set(b, c));
    return c;
  };
  iO.prototype.od = function (a) {
    var b;
    (b = this.B) != null &&
      ((a = a.h), (b.D = a), b.h && ((b = b.h), (b.j = a), kM(b, a)));
  };
  iO.prototype.M = function () {
    this.o.forEach(function (a) {
      qt(a);
    });
    this.o.clear();
    aO(this.R, this.C);
    tl(this.frameElement);
    S.prototype.M.call(this);
  };
  var gO = function (a, b, c) {
      var d = eO();
      if (sq(fB)) {
        var e = Pk("IFRAME");
        e.allowFullscreen = !0;
        e.allow = d;
        e.id = b;
        e.style.border = "0";
        e.style.opacity = "0";
        e.style.margin = "0";
        e.style.padding = "0";
        e.style.position = "relative";
        e.style.colorScheme = "light";
        e.title = "Advertisement";
        jO(a, e, b);
      } else
        e = rl("IFRAME", {
          src: kO(a, b),
          allowFullscreen: !0,
          allow: d,
          id: b,
          style:
            "border:0; opacity:0; margin:0; padding:0; position:relative; color-scheme: light;",
          title: "Advertisement",
        });
      a.j.Zb(e, "load", a.Y);
      if (sq(uB)) {
        var f = fO(a.F, a.O, a);
        a.j.Zb(e, "load", function () {
          lO(a, f);
        });
      }
      c.appendChild(e);
      return e;
    },
    mO = function (a, b) {
      var c = Np(),
        d,
        e,
        f = {},
        g =
          ((f.experimentStateProto =
            (e = (d = Ig(c, Kp, 1)) == null ? void 0 : d.ha()) != null
              ? e
              : ""),
          f);
      d = pg(c, 2, Ve);
      e = Ug(c, 5);
      f = {};
      b =
        ((f.compression_dictionary_version = Yg(c, 6)),
        (f.deid = An()),
        (f.eventfe_experiment_ids = [].concat(ra(d))),
        (f.fid = b),
        (f.genotype_experiment_data = g),
        (f.imalib_experiments = np()),
        (f.is_eap_loader = !1),
        (f.managed_js_experiment_id = e),
        (f.page_correlator = a.A.Tc()),
        (f.pvsid = a.A.l),
        (f.top_accessible_page_url = a.A.h),
        f);
      (a = a.A.jc) && (b.tv_web_variant = a);
      return b;
    },
    nO = function (a, b, c) {
      var d = new URLSearchParams();
      a.K && d.append("gdpr", "1");
      a: {
        a = window;
        try {
          do {
            try {
              if (
                a.location.href.indexOf(b) === 0 ||
                a.document.referrer.indexOf(b) === 0
              ) {
                var e = !0;
                break a;
              }
            } catch (f) {}
            a = a.parent;
          } while (a !== a.top);
        } catch (f) {}
        e = !1;
      }
      e && d.append("f", c);
      return d;
    },
    jO = function (a, b, c) {
      var d = U.getLocale(),
        e = Jk(dO);
      e = Ik(Xj(e).toString());
      d =
        e.Hf +
        (e.Hf.slice(-1) === "/" ? "" : "/") +
        encodeURIComponent("bridge3.800.0_" + d + ".html");
      e = Wj(d + e.Pg + e.fragment);
      d = nO(a, e.toString(), c);
      a = mO(a, c);
      a = YL(a);
      c = Ik(Xj(e).toString());
      e = Kk(c.Hf, c.Pg, c.fragment, d);
      c = Xj(e).toString();
      e = Wj(Lk.exec(c)[0] + (a.trim() ? "#" + a : ""));
      b.src = Xj(e).toString();
    },
    kO = function (a, b) {
      var c =
        (Bk() ? "https:" : "http:") +
        bO(
          "//imasdk.googleapis.com/js/core/bridge3.800.0_%s.html",
          U.getLocale()
        );
      c = new URL(c, window.location.href);
      var d = nO(a, c.toString(), b);
      d = y(d.entries());
      var e = d.next();
      try {
        for (; !e.done; e = d.next()) {
          var f = y(e.value),
            g = f.next().value,
            h = f.next().value;
          c.searchParams.append(g, h);
        }
      } finally {
        z(d, e);
      }
      a = mO(a, b);
      c.hash = YL(a);
      return c.toString();
    };
  iO.prototype.T = function (a) {
    var b = a.ra,
      c = Ll(this.frameElement),
      d = document.createEvent("MouseEvent");
    d.initMouseEvent(
      a.messageType,
      !0,
      !0,
      window,
      b.detail,
      b.screenX,
      b.screenY,
      b.clientX + c.x,
      b.clientY + c.y,
      b.ctrlKey,
      b.altKey,
      b.shiftKey,
      b.metaKey,
      b.button,
      null
    );
    this.frameElement.dispatchEvent(d);
  };
  var oO = function (a, b) {
    var c = Ll(a.frameElement),
      d = "TouchEvent" in window && TouchEvent.length > 0;
    b = b.map(function (f) {
      return d
        ? new Touch({
            identifier: f.identifier,
            target: a.frameElement,
            clientX: f.clientX,
            clientY: f.clientY,
            screenX: f.screenX,
            screenY: f.screenY,
            pageX: f.pageX + c.x,
            pageY: f.pageY + c.y,
          })
        : document.createTouch(
            window,
            a.frameElement,
            f.identifier,
            f.pageX + c.x,
            f.pageY + c.y,
            f.screenX,
            f.screenY
          );
    });
    if (d) return b;
    var e;
    return (e = document.createTouchList) == null
      ? void 0
      : e.apply(document, b);
  };
  iO.prototype.W = function (a) {
    var b = a.ra,
      c = Ll(this.frameElement);
    if ("TouchEvent" in window && TouchEvent.length > 0)
      (b = {
        bubbles: !0,
        cancelable: !0,
        view: window,
        detail: b.detail,
        ctrlKey: b.ctrlKey,
        altKey: b.altKey,
        shiftKey: b.shiftKey,
        metaKey: b.metaKey,
        touches: oO(this, b.touches),
        targetTouches: oO(this, b.targetTouches),
        changedTouches: oO(this, b.changedTouches),
      }),
        (a = new TouchEvent(a.messageType, b)),
        this.frameElement.dispatchEvent(a);
    else {
      var d = document.createEvent("TouchEvent");
      d.initTouchEvent(
        a.messageType,
        !0,
        !0,
        window,
        b.detail,
        b.screenX,
        b.screenY,
        b.clientX + c.x,
        b.clientY + c.y,
        b.ctrlKey,
        b.altKey,
        b.shiftKey,
        b.metaKey,
        oO(this, b.touches),
        oO(this, b.targetTouches),
        oO(this, b.changedTouches),
        b.scale,
        b.rotation
      );
      this.frameElement.dispatchEvent(d);
    }
  };
  iO.prototype.J = function (a) {
    switch (a.messageType) {
      case "displayPauseAd":
        var b = a.ra.pauseAdData,
          c = this.l.ce,
          d = hO(this, a.sessionId),
          e = b.htmlContent;
        if (c && b && typeof e === "string") {
          b = document.createElement("div");
          b.style.position = "relative";
          b.style.display = "inline-block";
          b.style.width = "100%";
          b.style.height = "100%";
          var f = document.createElement("iframe");
          f.style.border = "none";
          f.style.overflow = "hidden";
          f.style.width = "100%";
          f.style.height = "100%";
          f.setAttribute("scrolling", "no");
          f.removeAttribute("src");
          if (e instanceof gk) throw new kk("SafeHtml", 1);
          var g = [
            "allow-scripts",
            "allow-forms",
            "allow-popups",
            "allow-popups-to-escape-sandbox",
            "allow-storage-access-by-user-activation",
          ];
          f.setAttribute("sandbox", "");
          for (var h = 0; h < g.length; h++)
            (f.sandbox.supports && !f.sandbox.supports(g[h])) ||
              f.sandbox.add(g[h]);
          e = hk(e);
          f.srcdoc = ik(e);
          b.appendChild(f);
          sl(c);
          c.appendChild(b);
          uI(d, "displayContainer", "pauseAdView");
        } else uI(d, "displayContainer", "pauseAdError");
        break;
      case "hidePauseAd":
        (c = this.l.ce) && sl(c);
    }
    c = this.H;
    TM(c.l, a);
    c.h && TM(c.h, a);
  };
  iO.prototype.Y = function () {
    this.uc = En();
    this.Fc = Bn();
    var a = vl(this.frameElement);
    this.o.forEach(function (c) {
      c.h = a;
      c.connect();
    });
    var b;
    (b = this.B) != null && ((b.o = a), RM(b));
    this.connected = !0;
    sq(rB) && ((this.Mc = Bn()), uI(this.h, "bridgeInitialize", "connect"));
  };
  var lO = function (a, b) {
    var c;
    Ka(function (d) {
      if (d.j == 1) return d.h(b, 2);
      c = d.l;
      a.Mc = Bn();
      uI(a.h, "bridgeInitialize", "connect", c);
      d.B();
    });
  };
  var pO = ua(["https://s0.2mdn.net/instream/video/client.js"]),
    qO = null,
    rO = function () {
      S.call(this);
      this.h = null;
      this.j = new Map();
      this.l = new Map();
      this.Ga = this.B = !1;
      this.o = null;
      this.A = new zD(this);
      tt(this, this.A);
    };
  w(rO, S);
  var sO = function () {
      qO == null && (qO = new rO());
      return qO;
    },
    mx = function (a, b, c) {
      var d = {};
      d.queryId = b;
      d.viewabilityData = c;
      a.h && uI(a.h, "activityMonitor", "viewabilityMeasurement", d);
    };
  rO.prototype.destroy = function () {
    this.A.Ma(this.h, "activityMonitor", this.C);
    this.Ga = !1;
    this.j.clear();
  };
  rO.prototype.M = function () {
    this.destroy();
    S.prototype.M.call(this);
  };
  rO.prototype.init = function (a) {
    if (!this.Ga) {
      if ((this.h = a || null))
        this.A.listen(this.h, "activityMonitor", this.C), tO(this);
      if (
        !(
          C.ima &&
          C.ima.video &&
          C.ima.video.client &&
          C.ima.video.client.tagged
        )
      ) {
        D("ima.video.client.sdkTag", !0);
        var b = C.document;
        a = Pk("SCRIPT");
        var c = Jk(pO);
        lk(a, c);
        a.async = !0;
        a.type = "text/javascript";
        b = b.getElementsByTagName("script")[0];
        b.parentNode.insertBefore(a, b);
      }
      ir();
      M(cx).J = U.h;
      this.B = !0;
      M(cx).l = !0;
      this.o = null;
      a = M(cx);
      b = Ow(a) == "h" || Ow(a) == "b";
      c = !(hr(), !1);
      b && c && ((a.N = !0), (a.V = new kv()));
      this.Ga = !0;
    }
  };
  var vO = function (a) {
      if (a == null) return !1;
      if ((Hc || Jc) && a.webkitDisplayingFullscreen !== null)
        return a.webkitDisplayingFullscreen;
      a = uO(a);
      var b = window.screen.availHeight || window.screen.height;
      return (
        (window.screen.availWidth || window.screen.width) - a.width <= 0 &&
        b - a.height <= 42
      );
    },
    uO = function (a) {
      var b = {
        left: a.offsetLeft,
        top: a.offsetTop,
        width: a.offsetWidth,
        height: a.offsetHeight,
      };
      try {
        typeof a.getBoundingClientRect === "function" &&
          ul(il(a), a) &&
          (b = a.getBoundingClientRect());
      } catch (c) {}
      return b;
    },
    wO = function (a, b, c, d, e) {
      e = e === void 0 ? {} : e;
      if (a.Ga) {
        d && e.opt_osdId == null && (e.opt_osdId = d);
        if (a.o) return a.o(b, c, e);
        if ((a = d ? a.l.get(d) : U.j))
          e.opt_fullscreen == null && (e.opt_fullscreen = vO(a)),
            e.opt_adElement == null && (e.opt_adElement = a);
        return hA.bc(469, lb(ox, b, c, e)) || {};
      }
      return {};
    },
    xO = function (a) {
      var b;
      U.h !== 0 ? (b = M(cx).l) : (b = a.B);
      return b;
    },
    yO = function (a, b) {
      var c = String(Math.floor(Math.random() * 1e9));
      a.l.set(c, b);
      U.h !== 0 && (M(cx).o[c] = a);
      return c;
    },
    zO = function (a, b, c) {
      if (c) a.j.get(c) === b && a.j.delete(c);
      else {
        var d = [];
        a.j.forEach(function (e, f) {
          e === b && d.push(f);
        });
        d.forEach(a.j.delete, a.j);
      }
    },
    ix = function (a, b) {
      a = a.j.get(b);
      return typeof a === "function" ? a() : {};
    },
    tO = function (a) {
      if (typeof window.Goog_AdSense_Lidar_getUrlSignalsArray === "function") {
        var b = {};
        b.pageSignals = window.Goog_AdSense_Lidar_getUrlSignalsArray();
        var c;
        (c = a.h) == null || uI(c, "activityMonitor", "pageSignals", b);
      }
    };
  rO.prototype.C = function (a) {
    var b = a.ra,
      c = b.queryId,
      d = {},
      e = null;
    d.eventId = b.eventId;
    switch (a.messageType) {
      case "getPageSignals":
        tO(this);
        break;
      case "reportVastEvent":
        e = b.vastEvent;
        a = b.osdId;
        var f = {};
        f.opt_fullscreen = b.isFullscreen;
        b.isOverlay && (f.opt_bounds = b.overlayBounds);
        d.viewabilityData = wO(this, e, c, a, f);
        var g;
        (g = this.h) == null || uI(g, "activityMonitor", "viewability", d);
        break;
      case "fetchAdTagUrl":
        (c = {}),
          (c.eventId = b.eventId),
          (a = b.osdId),
          Zk(b, "isFullscreen") && (e = b.isFullscreen),
          Zk(b, "loggingId") &&
            ((b = b.loggingId),
            (c.loggingId = b),
            W.getInstance().report(43, {
              step: "beforeLookup",
              logid: b,
              time: Date.now(),
            })),
          (c.engagementString = AO(this, a, e)),
          this.h && uI(this.h, "activityMonitor", "engagement", c);
    }
  };
  var AO = function (a, b, c) {
    var d,
      e = b ? ((d = a.l.get(b)) != null ? d : null) : U.j;
    a = function () {
      return e;
    };
    b = {};
    c != null && (b.fullscreen = c);
    c = "";
    try {
      try {
        c = new oz(a, b).ha();
      } catch (f) {
        c = "tle;" + rk(f.name, 12) + ";" + rk(f.message, 40);
      }
    } catch (f) {
      (c = f), (c = "sdktle;" + rk(c.name, 12) + ";" + rk(c.message, 40));
    }
    return c;
  };
  D("ima.common.getVideoMetadata", function (a) {
    return ix(sO(), a);
  });
  D("ima.common.triggerViewabilityMeasurementUpdate", function (a, b) {
    mx(sO(), a, b);
  });
  function BO(a, b) {
    return a && b
      ? a.some(function (c) {
          return b.includes(c);
        })
      : !1;
  }
  var CO = jD(0, 0, 5, 5);
  function DO(a, b) {
    try {
      if ("removeAttribute" in a) return a.removeAttribute(b), !0;
    } catch (c) {}
    return !1;
  }
  var EO = function (a) {
    sH.call(this, a);
    this.B = this.fa = null;
    this.J = this.W = this.H = !1;
    this.Y = this.F = this.K = this.o = null;
    this.da = !1;
    this.C = this.oa = null;
    this.O = 0;
    this.size = this.getSize();
    this.fullscreen = this.Ne();
    this.Qa = null;
  };
  w(EO, sH);
  var UM = function (a, b, c, d) {
      if (sq(uB)) {
        if (a.h.src !== "" && (BO(d, a.oa) || a.h.src === b)) {
          a.Ng(null);
          a.O = 1;
          return;
        }
        a.h.src !== "" ? (a.unload(), (a.O = 3)) : (a.O = 2);
        a.oa = d;
      }
      N.getInstance().Rc();
      eo(N.getInstance(), "hvd_lc");
      FO(a);
      d = a.h;
      if (Kc || TC()) DO(d, "crossOrigin");
      else if (sq(eB) && Wb()) {
        var e = b;
        if (c instanceof DB) {
          var f;
          e = (f = c.getMediaUrl()) != null ? f : null;
        } else if (c instanceof CB) {
          var g;
          e = (g = c.Cd()) != null ? g : null;
        }
        f = !1;
        if (e)
          try {
            f = new URL(e).pathname.toLowerCase().endsWith(".m3u8");
          } catch (l) {}
        f ? (d.crossOrigin = "anonymous") : DO(d, "crossOrigin");
      }
      a.W = !1;
      if (c)
        if ((eo(N.getInstance(), "hvd_ad"), c instanceof DB)) {
          if ((eo(N.getInstance(), "hvd_mad"), (c = c.getMediaUrl()))) {
            eo(N.getInstance(), "hvd_admu");
            GO(a, c);
            return;
          }
        } else if (c instanceof CB) {
          eo(N.getInstance(), "hvd_dad");
          d = c.Cd();
          e = c.qe;
          var h = c.Lf;
          f = c.pe;
          var k = c.Rb;
          g = c.zb;
          if (
            d &&
            e &&
            h &&
            f &&
            k &&
            g &&
            (eo(N.getInstance(), "hvd_addu"), c.Kb)
          ) {
            eo(N.getInstance(), "hvd_admse");
            c = h + '; codecs="' + k + '"';
            f = f + '; codecs="' + g + '"';
            if (window.MediaSource && MF(c) && MF(f)) {
              eo(N.getInstance(), "hvd_ymse");
              eo(N.getInstance(), "hvd_mse");
              g = !1;
              try {
                window.location.search.indexOf("goog_limavideo=true") !== -1 &&
                  (g = !0);
              } catch (l) {}
              b = a.h;
              C.customElements
                ? g
                  ? (g = !0)
                  : (sq(iB) && W.getInstance().report(153, { limvid: "vd" }),
                    (g = !!sq(iB)))
                : (g = !1);
              g && b instanceof ZG
                ? ((b.Cb = d), (b.Vb = e))
                : ((a.fa = new HH(b, [
                    new yG(d, c, 35e4, new tH()),
                    new yG(e, f, 82e3, new tH()),
                  ])),
                  tt(a, a.fa),
                  (b.src = a.fa.Uc()));
              b.load();
              return;
            }
            eo(N.getInstance(), "hvd_nmse");
          }
        } else eo(N.getInstance(), "hvd_uad");
      b ? GO(a, b) : (eo(N.getInstance(), "hvd_vn"), a.h.load());
    },
    GO = function (a, b) {
      eo(N.getInstance(), "hvd_src");
      a = a.h;
      a.src = b;
      a.load();
    };
  n = EO.prototype;
  n.unload = function () {
    FO(this);
    this.W = !1;
    var a = this.h;
    DO(this.h, "src") || (a.src = "");
    this.oa = null;
    a.load();
  };
  n.Cd = function () {
    return this.h.src;
  };
  n.setVolume = function (a) {
    var b = this.h;
    b.volume = Math.max(a, 0);
    b.muted = a === 0;
  };
  n.play = function () {
    var a = this;
    this.da = !1;
    if (!this.W && !Tb()) return (this.J = !0), Promise.resolve();
    this.J = !1;
    this.o = this.h.play();
    return this.o != null
      ? ((this.K = null),
        this.o
          .then(function () {
            a.o = null;
            a.ae(a.K);
            a.K = null;
          })
          .catch(function (b) {
            a.o = null;
            var c = "";
            b != null && b.name != null && (c = b.name);
            c === "AbortError" || c === "NotAllowedError"
              ? a.dispatchEvent("autoplayDisallowed")
              : a.qc();
          }))
      : Promise.resolve();
  };
  n.pause = function () {
    this.o == null && ((this.da = !0), this.h.pause());
  };
  n.Gg = function () {
    var a = this.h;
    return a.paused ? (Kc || Uc ? a.currentTime < a.duration : !0) : !1;
  };
  n.Ne = function () {
    return vO(this.h);
  };
  n.getSize = function () {
    return new Rk(this.h.offsetWidth, this.h.offsetHeight);
  };
  n.M = function () {
    this.Y && qD(this.Y);
    this.Ra();
    sH.prototype.M.call(this);
  };
  n.Pb = function () {
    this.Ra();
    var a = this.h;
    this.j.listen(a, WL, this.Fj);
    this.j.listen(a, "ended", this.Ye);
    this.j.listen(a, "webkitbeginfullscreen", this.Nc);
    this.j.listen(a, "webkitendfullscreen", this.Mg);
    this.j.listen(a, "loadedmetadata", this.Ng);
    this.j.listen(a, "pause", this.af);
    this.j.listen(a, "playing", this.ae);
    this.j.listen(a, "timeupdate", this.cf);
    this.j.listen(a, "volumechange", this.Og);
    this.j.listen(a, "error", this.qc);
    this.j.listen(
      a,
      Tc || (Kc && (!Kc || !SC(QC, 8))) ? "loadeddata" : "canplay",
      this.Ze
    );
    this.B = new qL();
    this.j.listen(this.B, "click", this.Oh);
    this.B.Pb(a);
    this.F = new Yy(1e3);
    this.j.listen(this.F, "tick", this.ob);
    this.F.start();
  };
  n.Ra = function () {
    this.B != null && (this.B.Ra(), (this.B = null));
    this.F != null && this.F.dispose();
    DD(this.j);
    FO(this);
  };
  var FO = function (a) {
    a.loaded = !1;
    a.l = !1;
    a.H = !1;
    a.J = !1;
    a.A = 0;
    a.o = null;
    a.K = null;
    a.O = 0;
    qt(a.C);
  };
  n = EO.prototype;
  n.Fj = function (a) {
    this.dispatchEvent(a.type);
  };
  n.ed = function () {
    if (!this.l) {
      this.l = !0;
      this.dispatchEvent("start");
      try {
        if (sq(iB) && C.customElements) {
          var a = C.customElements.get("lima-video");
          this.h instanceof a
            ? W.getInstance().report(153, { limvid: "limastart" })
            : W.getInstance().report(153, { limvid: "videostart" });
        }
      } catch (b) {
        W.getInstance().report(153, { limvid: "startfail" });
      }
    }
  };
  n.Ng = function () {
    this.W = !0;
    this.J && this.play();
    this.J = !1;
    HO(this);
  };
  n.ae = function (a) {
    this.o != null
      ? (this.K = a)
      : (this.dispatchEvent("play"), Kc || TC() || Tc || this.ed());
  };
  n.cf = function (a) {
    if (!this.l && (Kc || TC() || Tc)) {
      if (this.getCurrentTime() <= 0) return;
      if (Tc && this.h.ended && this.getDuration() === 1) {
        this.qc(a);
        return;
      }
      this.ed();
    }
    if (Kc || Pb(Sb(), "Nintendo WiiU")) {
      if (this.getCurrentTime() - this.A > 1.5) {
        this.H = !0;
        this.h.currentTime = this.A;
        return;
      }
      this.H = !1;
      this.getCurrentTime() > this.A && (this.A = this.getCurrentTime());
    }
    this.dispatchEvent("timeUpdate");
  };
  n.af = function () {
    if (this.l && Kc && !this.da && (IO(this) < 2 || this.H)) {
      this.C = new Yy(250);
      this.j.listen(this.C, "tick", this.fb);
      this.C.start();
      var a = !0;
    } else a = !1;
    a || this.o || this.dispatchEvent("pause");
  };
  n.Ye = function () {
    var a = !0;
    if (Kc || Pb(Sb(), "Nintendo WiiU")) a = this.A >= this.h.duration - 1.5;
    !this.H && a && this.dispatchEvent("end");
  };
  n.Mg = function () {
    this.dispatchEvent("endFullscreen");
  };
  n.qc = function () {
    this.dispatchEvent("error");
  };
  n.Oh = function () {
    this.dispatchEvent("click");
  };
  var HO = function (a) {
    var b = a.h;
    b instanceof HTMLElement &&
      ((a.Y = pD(b, CO)),
      a.Y.then(function (c) {
        a.Va() || N.getInstance().P("ps", c.width + "x" + c.height);
      }));
  };
  EO.prototype.ob = function () {
    var a = this.getSize(),
      b = this.Ne();
    if (a.width !== this.size.width || a.height !== this.size.height)
      !this.fullscreen && b
        ? this.dispatchEvent("beginFullscreen")
        : this.fullscreen && !b && this.Mg(),
        (this.size = a),
        (this.fullscreen = b);
  };
  EO.prototype.fb = function () {
    if (this.h.ended || !this.Gg()) qt(this.C);
    else {
      var a = this.h;
      a = a.duration - a.currentTime;
      var b = IO(this);
      b > 0 && (b >= 2 || a < 2) && (qt(this.C), this.play());
    }
  };
  var IO = function (a) {
    var b;
    a: {
      for (b = a.h.buffered.length - 1; b >= 0; b--)
        if (a.h.buffered.start(b) <= a.h.currentTime) {
          b = a.h.buffered.end(b);
          break a;
        }
      b = 0;
    }
    return b - a.h.currentTime;
  };
  EO.prototype.Nc = function () {
    W.getInstance().report(139);
    this.dispatchEvent("beginFullscreen");
  };
  var KO = function (a) {
    R.call(this);
    this.l = a;
    this.j = null;
    this.o = function () {};
    this.h = JO(this);
    this.j = document.createElement("div");
    this.j.style.display = "none";
    this.l.appendChild(this.j);
    this.j.appendChild(this.h);
    this.o = NG(function () {
      N.getInstance().P("haob", "1");
    }).destroy;
  };
  w(KO, R);
  KO.prototype.initialize = function () {
    this.h && (sq(qB) ? (this.h.play(), this.h.pause()) : this.h.load());
  };
  KO.prototype.M = function () {
    tl(this.j);
    this.o();
    R.prototype.M.call(this);
  };
  var JO = function (a) {
      var b = !1;
      try {
        window.location.search.indexOf("goog_limavideo=true") !== -1 &&
          (b = !0);
      } catch (c) {}
      if (LO(a, b)) {
        b && console.log("force lima video in wrapper");
        a = null;
        try {
          a = new ZG();
        } catch (c) {
          (a = document.createElement("lima-video")),
            sq(iB) && W.getInstance().report(153, { limvid: "firefail" });
        }
        a.style.backgroundColor = "#000";
        a.style.height = "100%";
        a.style.width = "100%";
        a.style.position = "absolute";
        a.style.left = "0";
        a.style.top = "0";
      } else
        (a = document.createElement("video")),
          (a.style.backgroundColor = "#000"),
          (a.style.height = "100%"),
          (a.style.width = "100%"),
          (a.style.position = "absolute"),
          (a.style.left = "0"),
          (a.style.top = "0"),
          (a.title = "Advertisement".toString());
      a.setAttribute("webkit-playsinline", "true");
      a.setAttribute("playsinline", "true");
      sq(sB) && a.setAttribute("preload", "auto");
      return a;
    },
    LO = function (a, b) {
      if (!C.customElements) return !1;
      if (b) return !0;
      if (Ub() && il(a.l) !== document) return !1;
      sq(iB) && W.getInstance().report(153, { limvid: "vw" });
      return !!sq(iB);
    };
  KO.prototype.Ib = function () {
    var a = this.j;
    a != null && (a.style.display = "none");
  };
  var NO = function (a, b, c, d) {
    d = d === void 0 ? M(wM) : d;
    this.N = String(Math.floor(Math.random() * 1e9));
    this.C = !1;
    this.B = this.ce = null;
    this.size = new Rk(0, 0);
    this.Kf = new Map();
    var e = a && a.getRootNode ? a.getRootNode({ composed: !0 }) : a;
    if (a == null || !ul(il(e), e))
      throw jJ(eJ, null, "containerElement", "element");
    b instanceof tM && ((this.B = b), (b = b.h));
    this.j = b;
    this.V = ML(this.j || null);
    this.H = UC(this.j || null);
    this.hd = a;
    this.F = b != null;
    U.h = 2;
    this.xd = MO(b ? b : null);
    e = Pk("DIV");
    e.style.position = "absolute";
    a.insertBefore(e, a.firstChild);
    this.o = e;
    this.h = null;
    NN(this) && b
      ? (a = new EO(b))
      : ((this.h = new KO(this.o)), (a = new EO(this.h.h)));
    this.ma = a;
    this.Ka = this.l = null;
    if ((a = this.h && vM.Zc()))
      a = !(NN(this) || Hc || Jc || Ms() || (Gc && (!Gc || !SC(RC, 4))));
    a && ((this.l = new KO(this.o)), (this.Ka = new EO(this.l.h)));
    this.Ae = c || null;
    NN(this) && b
      ? typeof b.getBoundingClientRect !== "function"
        ? ((c = this.o), (U.j = c))
        : (c = b)
      : (c = this.o);
    this.D = c;
    this.A = new iO(this.o, this, d, !0);
    (d = this.B) != null && ((c = hO(this.A)), (d.j = c));
    this.xe = "";
    b &&
      ((d = EC(b.src || b.currentSrc)),
      d.toString().length < 200
        ? (this.xe = d.toString())
        : d.h.length < 200 && (this.xe = d.h));
    this.Kf.set("videoDisplay1", this.ma);
    this.Ka && this.Kf.set("videoDisplay2", this.Ka);
    this.Jf() &&
      !vM.Eb() &&
      console.warn(
        "Custom media element must be a <video> or <audio> element. Viewability/audibility measurement will fail."
      );
  };
  n = NO.prototype;
  n.initialize = function () {
    this.C = !0;
    this.h != null && this.h.initialize();
    this.l != null && this.l.initialize();
  };
  n.Ga = function () {
    return this.C;
  };
  n.destroy = function () {
    var a = this;
    this.j = null;
    qt(this.B);
    qt(this.h);
    qt(this.l);
    qt(this.A);
    this.ma.T(function () {
      qt(a.ma);
    });
    this.Ka != null &&
      this.Ka.T(function () {
        qt(a.Ka);
      });
    tl(this.o);
  };
  n.je = function () {
    if (this.h != null) {
      var a = this.h.j;
      a != null && (a.style.display = "block");
    }
  };
  n.od = function (a) {
    this.ma !== a &&
      this.h &&
      this.l &&
      this.Ka &&
      (a.setVolume(this.ma.getVolume()),
      (a = this.ma),
      (this.ma = this.Ka),
      (this.Ka = a),
      (a = this.h),
      (this.h = this.l),
      (this.l = a),
      this.l.Ib(),
      this.A.od(this.ma));
  };
  n.Ib = function () {
    this.h != null && this.h.Ib();
  };
  var NN = function (a) {
    return KL(a.xd) && a.F;
  };
  NO.prototype.Jf = function () {
    var a = ["VIDEO", "AUDIO"],
      b;
    return (
      NN(this) &&
      !!this.j &&
      !a.includes((b = this.j.tagName) == null ? void 0 : b.toUpperCase())
    );
  };
  NO.prototype.getSize = function () {
    return this.size;
  };
  var MO = function (a) {
    return (
      a != null &&
      typeof a.getAttribute === "function" &&
      a.getAttribute("playsinline") != null
    );
  };
  NO.prototype.nf = function (a, b) {
    this.ma.nf(a, b === void 0 ? 0 : b);
  };
  NO.prototype.qf = function (a) {
    this.ma.qf(a === void 0 ? 0 : a);
  };
  NO.prototype.dk = function (a) {
    this.ce = a;
  };
  NO.prototype.setPauseAdSlot = NO.prototype.dk;
  NO.prototype.destroy = NO.prototype.destroy;
  NO.prototype.initialize = NO.prototype.initialize;
  var OO = { AD_LOAD: "adLoadError", AD_PLAY: "adPlayError" },
    PO = function (a) {
      var b = Error.call(this);
      this.message = b.message;
      "stack" in b && (this.stack = b.stack);
      this.data = a;
    };
  w(PO, Error);
  n = PO.prototype;
  n.getInnerError = function () {
    var a = this.data.innerError;
    return a instanceof Object ? new PO(a) : a != null ? Error(a) : null;
  };
  n.getMessage = function () {
    return this.data.errorMessage;
  };
  n.getErrorCode = function () {
    return this.data.errorCode;
  };
  n.getVastErrorCode = function () {
    var a = this.getErrorCode();
    return a < 1e3 ? a : 900;
  };
  n.getType = function () {
    return this.data.type;
  };
  n.toString = function () {
    return (
      "AdError " +
      this.getErrorCode() +
      ": " +
      this.getMessage() +
      (this.getInnerError() != null
        ? " Caused by: " + this.getInnerError()
        : "")
    );
  };
  PO.prototype.getType = PO.prototype.getType;
  PO.prototype.getVastErrorCode = PO.prototype.getVastErrorCode;
  PO.prototype.getErrorCode = PO.prototype.getErrorCode;
  PO.prototype.getMessage = PO.prototype.getMessage;
  PO.prototype.getInnerError = PO.prototype.getInnerError;
  D(
    "module$exports$google3$javascript$ads$interactivemedia$sdk$clientside$api$ad_error.AdError.Type",
    OO
  );
  var QO = { AD_ERROR: "adError" },
    RO = function (a, b) {
      b = b === void 0 ? null : b;
      Vx.call(this, "adError");
      this.error = a;
      this.h = b;
    };
  w(RO, Vx);
  RO.prototype.getError = function () {
    return this.error;
  };
  RO.prototype.getUserRequestContext = function () {
    return this.h;
  };
  RO.prototype.getUserRequestContext = RO.prototype.getUserRequestContext;
  RO.prototype.getError = RO.prototype.getError;
  D(
    "module$exports$google3$javascript$ads$interactivemedia$sdk$clientside$api$ad_error_event.AdErrorEvent.Type",
    QO
  );
  var SO = {
      AD_CAN_PLAY: "adCanPlay",
      xk: "adStarted",
      CONTENT_PAUSE_REQUESTED: "contentPauseRequested",
      CONTENT_RESUME_REQUESTED: "contentResumeRequested",
      CLICK: "click",
      VIDEO_CLICKED: "videoClicked",
      VIDEO_ICON_CLICKED: "videoIconClicked",
      Of: "engagedView",
      EXPANDED_CHANGED: "expandedChanged",
      STARTED: "start",
      AD_PROGRESS: "adProgress",
      AD_BUFFERING: "adBuffering",
      IMPRESSION: "impression",
      Sf: "measurable_impression",
      VIEWABLE_IMPRESSION: "viewable_impression",
      Pf: "fully_viewable_audible_half_duration_impression",
      Rh: "overlay_resize",
      Sh: "overlay_unmeasurable_impression",
      Th: "overlay_unviewable_impression",
      Vh: "overlay_viewable_immediate_impression",
      Uh: "overlay_viewable_end_of_session_impression",
      Rk: "externalActivityEvent",
      PAUSED: "pause",
      RESUMED: "resume",
      FIRST_QUARTILE: "firstQuartile",
      MIDPOINT: "midpoint",
      THIRD_QUARTILE: "thirdQuartile",
      COMPLETE: "complete",
      DURATION_CHANGE: "durationChange",
      USER_CLOSE: "userClose",
      hm: "userRecall",
      Pl: "prefetched",
      LOADED: "loaded",
      ALL_ADS_COMPLETED: "allAdsCompleted",
      SKIPPED: "skip",
      Zh: "skipShown",
      LINEAR_CHANGED: "linearChanged",
      SKIPPABLE_STATE_CHANGED: "skippableStateChanged",
      AD_METADATA: "adMetadata",
      AD_BREAK_FETCH_ERROR: "adBreakFetchError",
      AD_BREAK_READY: "adBreakReady",
      LOG: "log",
      VOLUME_CHANGED: "volumeChange",
      VOLUME_MUTED: "mute",
      INTERACTION: "interaction",
      Ck: "companionBackfill",
      dm: "trackingUrlPinged",
      jm: "video_card_endcap_collapse",
      km: "video_card_endcap_dismiss",
      lm: "video_card_endcap_impression",
      Fk: "companionInitialized",
      Ek: "companionImpression",
      Dk: "companionClick",
      Dl: "mediaUrlPinged",
      LOAD_START: "loadStart",
      Fl: "navigationRequested",
    },
    TO = function (a, b, c) {
      b = b === void 0 ? null : b;
      c = c === void 0 ? null : c;
      Vx.call(this, a);
      this.ad = b;
      this.j = c;
    };
  w(TO, Vx);
  TO.prototype.getAd = function () {
    return this.ad;
  };
  TO.prototype.getAdData = function () {
    return this.j;
  };
  TO.prototype.getAdData = TO.prototype.getAdData;
  TO.prototype.getAd = TO.prototype.getAd;
  D(
    "module$exports$google3$javascript$ads$interactivemedia$sdk$clientside$api$ad_event.AdEvent.Type",
    SO
  );
  var UO = function (a, b) {
    b = b === void 0 ? null : b;
    TO.call(this, "adMetadata", a);
    this.h = b;
  };
  w(UO, TO);
  UO.prototype.Si = function () {
    return this.h;
  };
  UO.prototype.getAdCuePoints = UO.prototype.Si;
  var VO = function (a) {
    this.adBreakDuration = a.adBreakDuration;
    this.adPosition = a.adPosition;
    this.currentTime = a.currentTime;
    this.duration = a.duration;
    this.totalAds = a.totalAds;
  };
  var WO = function (a, b) {
    S.call(this);
    this.l = a;
    this.A = b;
    this.j = this.l.currentTime;
    this.h = new Yy(250);
    tt(this, this.h);
    this.o = new zD(this);
    tt(this, this.o);
    BD(this.o, this.h, "tick", this.B, !1, this);
  };
  w(WO, S);
  WO.prototype.Gb = function () {
    return this.j;
  };
  WO.prototype.start = function () {
    XO(this);
    this.h.start();
  };
  WO.prototype.stop = function () {
    this.h.stop();
  };
  WO.prototype.B = function () {
    var a = this.l.currentTime;
    a !== this.Gb() && ((this.j = a), XO(this));
  };
  var XO = function (a) {
    var b = {};
    b.currentTime = a.Gb();
    uI(a.A, "contentTimeUpdate", "contentTimeUpdate", b);
  };
  var YO;
  if ((YO = Ec)) YO = "srcdoc" in pl(document, "IFRAME");
  var ZO = YO;
  function $O(a, b) {
    a.open("text/html", "replace");
    ok(a, GB(String(b)));
    a.close();
  }
  var aP = ua(["about:blank"]),
    bP = function (a, b, c) {
      S.call(this);
      this.j = a;
      this.l = b;
      this.A = c;
      this.h = null;
      this.C = this.B = "";
      this.F = 0;
      this.o = this.slot = this.frameElement = null;
      this.sessionId = "";
    };
  w(bP, S);
  bP.prototype.init = function (a) {
    this.sessionId = a;
    sq(fB)
      ? ((this.frameElement = Pk("IFRAME")),
        (a = Jk(aP)),
        (this.frameElement.src = Xj(a).toString()),
        (this.frameElement.title = "Advertisement"))
      : (this.frameElement = rl("IFRAME", {
          src: Bc ? "" : "about:blank",
          allowtransparency: !0,
          background: "transparent",
          title: "Advertisement",
        }));
    El(this.frameElement, { display: "none", width: "0", height: "0" });
    a = this.j.hd;
    a.appendChild(this.frameElement);
    a = a.ownerDocument;
    a = a.defaultView || a.parentWindow;
    this.o == null && (this.o = new zD(this));
    this.o.listen(a, "message", this.H);
    a =
      '<body><script src="//imasdk.googleapis.com/js/sdkloader/loader.js">\x3c/script><script>loader = new VPAIDLoader(false, "' +
      (this.sessionId + '");\x3c/script></body>');
    if (Uc || Sc || Cc) {
      var b = this.frameElement.contentWindow;
      b && $O(b.document, a);
    } else
      (b = this.frameElement),
        ZO
          ? ((a = GB(a)), (b.srcdoc = ik(a)))
          : (b = b.contentWindow) && $O(b.document, a);
  };
  bP.prototype.H = function (a) {
    try {
      var b = a.Jc.data;
      try {
        var c = JSON.parse(b);
      } catch (v) {
        return;
      }
      var d = c.session;
      if (d != null && this.sessionId === d)
        switch (c.type) {
          case "friendlyReady":
            var e = cP(this);
            if (e != null)
              (this.h = e),
                (this.B = e.currentSrc),
                (this.C = e.style ? e.style.cssText : ""),
                (this.F = e.currentTime);
            else {
              var f = this.j.hd,
                g = this.j.getSize(),
                h = Pk("VIDEO");
              h.style.border = "0";
              h.style.margin = "0";
              h.style.padding = "0";
              h.style.position = "absolute";
              h.style.width = g.width + "px";
              h.style.height = g.height + "px";
              h.autoplay = !0;
              this.h = h;
              f.appendChild(this.h);
            }
            var k = this.j.hd,
              l,
              m = ((l = this.h) == null ? 0 : l.style)
                ? Pl(this.h)
                : this.j.getSize(),
              p = Pk("DIV");
            p.style.border = "0";
            p.style.margin = "0";
            p.style.padding = "0";
            p.style.position = "absolute";
            p.style.width = m.width + "px";
            p.style.height = m.height + "px";
            this.slot = p;
            k.appendChild(this.slot);
            try {
              this.frameElement.contentWindow.loader.initFriendly(
                this.h,
                this.slot
              );
            } catch (v) {
              dP(this);
            }
            uI(this.l, "vpaid", "", b);
            break;
          case "becameLinear":
            var q;
            ((q = this.h) == null ? 0 : q.style) &&
              !Pj() &&
              !Qj() &&
              El(this.h, { visibility: "visible" });
            uI(this.l, "vpaid", "", b);
            break;
          case "becameNonlinear":
            eP(this);
            uI(this.l, "vpaid", "", b);
            break;
          case "startAd":
            a = {};
            if (this.h) {
              var r = this.h.paused,
                t = this.h.currentTime > 0;
              a.apl = t && !r ? "1" : "0";
              a.ip = r ? "1" : "0";
              a.iavp = t ? "1" : "0";
            } else a.apl = "n";
            W.getInstance().report(99, a);
            uI(this.l, "vpaid", "", b);
            this.je();
            break;
          default:
            uI(this.l, "vpaid", "", b);
        }
    } catch (v) {
      dP(this);
    }
  };
  var dP = function (a) {
    var b = { type: "error" };
    b.session = a.sessionId;
    b = JSON.stringify(b);
    a.postMessage(b);
  };
  bP.prototype.postMessage = function (a) {
    window.postMessage(a, "*");
  };
  var cP = function (a) {
    return (a.A === "videoDisplayUnknown" ? a.j.ma : a.j.Kf.get(a.A)).h;
  };
  bP.prototype.je = function () {
    cP(this) != null && this.j.je();
  };
  var eP = function (a) {
    var b;
    ((b = a.h) == null ? 0 : b.style) &&
      !Pj() &&
      !Qj() &&
      El(a.h, { visibility: "hidden" });
  };
  bP.prototype.M = function () {
    qt(this.o);
    this.o = null;
    tl(this.slot);
    this.slot = null;
    tl(this.frameElement);
    this.frameElement = null;
    var a = cP(this);
    a != null
      ? (a.style && (a.style.cssText = this.C),
        Pj() || Qj()
          ? ((a.src = this.B), (a.currentTime = this.F))
          : (typeof a.removeAttribute === "function"
              ? a.removeAttribute("src")
              : (a.src = ""),
            this.j.Ib()))
      : (tl(this.h), (this.h = null));
    S.prototype.M.call(this);
  };
  var fP = function (a, b) {
    R.call(this);
    this.j = a;
    this.l = b;
    this.h = new Map();
  };
  w(fP, R);
  var gP = function (a, b) {
    try {
      var c = b.session;
      switch (b.vpaidEventType) {
        case "createFriendlyIframe":
          c = "videoDisplayUnknown";
          b.videoDisplayName && (c = b.videoDisplayName);
          var d = b.session,
            e = new bP(a.j, a.l, c);
          a.h.set(d, e);
          e.init(d);
          break;
        case "vpaidNonLinear":
          var f = a.h.get(c);
          f && eP(f);
          break;
        case "destroyFriendlyIframe":
          var g = a.h.get(c);
          g && (g.dispose(), a.h.delete(c));
      }
    } catch (h) {
      W.getInstance().report(125, { msg: h.message });
    }
  };
  fP.prototype.M = function () {
    this.h.forEach(function (a) {
      a.dispose();
    });
  };
  var hP = function (a) {
    this.G = I(a);
  };
  w(hP, K);
  hP.prototype.getValue = function () {
    return Yg(this, 1);
  };
  hP.prototype.clearValue = function () {
    return jg(this, 1);
  };
  hP.prototype.getVersion = function () {
    return Zg(this, 5);
  };
  var iP = qj(hP);
  function jP() {
    this.h = [];
    this.j = [];
  }
  n = jP.prototype;
  n.isEmpty = function () {
    return this.h.length === 0 && this.j.length === 0;
  };
  n.clear = function () {
    this.h = [];
    this.j = [];
  };
  n.contains = function (a) {
    return kc(this.h, a) || kc(this.j, a);
  };
  n.remove = function (a) {
    var b = this.h;
    b: {
      var c = b.length - 1;
      c < 0 && (c = Math.max(0, b.length + c));
      if (typeof b === "string")
        c = typeof a !== "string" || a.length != 1 ? -1 : b.lastIndexOf(a, c);
      else {
        for (; c >= 0; c--) if (c in b && b[c] === a) break b;
        c = -1;
      }
    }
    c >= 0 ? (mc(b, c), (b = !0)) : (b = !1);
    return b || lc(this.j, a);
  };
  n.Vc = function () {
    for (var a = [], b = this.h.length - 1; b >= 0; --b) a.push(this.h[b]);
    b = this.j.length;
    for (var c = 0; c < b; ++c) a.push(this.j[c]);
    return a;
  };
  var kP = Bn(),
    Z = function (a, b, c, d, e, f, g, h) {
      S.call(this);
      var k = this;
      this.O = a;
      this.h = b;
      this.adTagUrl = c;
      this.Nc = d;
      this.sa = e;
      this.A = f;
      this.Aa = g;
      this.W = h;
      this.B = new sM();
      this.T = !1;
      this.volume = 1;
      this.oa = -1;
      this.F = this.o = this.j = null;
      this.H = new jP();
      this.va = this.ba = !1;
      this.J = null;
      this.fa = this.fb = !1;
      this.l = null;
      this.Y = function () {
        var l = k.h.ma,
          m = l.getCurrentTime();
        l = l.getDuration();
        return { currentTime: m, duration: l, isPlaying: !0, volume: k.volume };
      };
      this.K = this.da = this.Ta = null;
      this.C = new WO({ currentTime: 0 }, this.A);
      this.ob = new fP(b, f);
      tt(this, this.ob);
      this.R = new zD(this);
      tt(this, this.R);
      this.R.listen(this.A, "adsManager", this.Ge);
    };
  w(Z, S);
  Z.prototype.Ge = function (a) {
    var b = this,
      c = { type: a.messageType, data: a.ra };
    switch (c.type) {
      case "error":
        lP(this);
        mP(this, c.data);
        break;
      case "contentPauseRequested":
        W.getInstance().report(130);
        nP(this);
        this.C.stop();
        oP(this, c);
        break;
      case "contentResumeRequested":
        pP(this, function () {
          oP(b, c);
        });
        break;
      case "remainingTime":
        this.oa = c.data.remainingTime;
        break;
      case "companionBackfill":
        a = $a("window.google_show_companion_ad");
        a != null && a();
        break;
      case "skipShown":
        this.T = !0;
        oP(this, c);
        break;
      case "vpaidEvent":
        gP(this.ob, c.data);
        break;
      case "skippableStateChanged":
        a = c.data.adData;
        (a == null ? void 0 : a.skippable) != null && (this.T = a.skippable);
        oP(this, c);
        break;
      case "volumeChange":
        a = c.data.adData;
        a != null && typeof a.volume === "number" && (this.volume = a.volume);
        oP(this, c);
        break;
      case "firstQuartile":
        oP(this, { type: cI.firstQuartile, data: c.data });
        oP(this, c);
        break;
      case "thirdQuartile":
        oP(this, { type: cI.thirdQuartile, data: c.data });
        oP(this, c);
        break;
      case "updateGfpCookie":
        qP(this, c.data);
        break;
      default:
        oP(this, c);
    }
  };
  var oP = function (a, b) {
      var c = b.data.adData,
        d = null;
      c &&
        (c.companions == null && a.J != null && (c.companions = a.J),
        (d = new X(c)),
        (a.j = d));
      switch (b.type) {
        case "adBreakReady":
        case "mediaUrlPinged":
          b = new TO(b.type, null, b.data);
          break;
        case "adMetadata":
          c = null;
          b.data.adCuePoints != null && (c = new rM(b.data.adCuePoints));
          b = new UO(d, c);
          break;
        case "allAdsCompleted":
          rP(a);
          a.l = null;
          a.j = null;
          a.fb = !0;
          b = new TO(b.type, d);
          break;
        case "contentPauseRequested":
          a.fa = !1;
          b = new TO(b.type, d);
          break;
        case "contentResumeRequested":
          rP(a);
          a.l = null;
          a.j = null;
          a.fa = !0;
          b = new TO(b.type, d);
          break;
        case "loaded":
          a.l = null;
          a.oa = d.getDuration();
          a.T = !1;
          if (a.sa && NL()) {
            var e = a.O,
              f = d,
              g = a.sa;
            e.j.set(pM(f), a.Y);
            xO(e) && wO(e, "loaded", pM(f), g);
          }
          b = new TO(b.type, d, c);
          break;
        case "skip":
          rP(a);
          a.l = null;
          a.j = null;
          a.J = null;
          b = new TO(b.type, d);
          break;
        case "start":
          c && (c = c.companions) && (a.J = c);
          a.l = !!b.data.usingCustomClickTracking;
          rP(a);
          a.l &&
            ((c = a.h.Ae),
            c != null &&
              (a.o == null
                ? ((a.o = new qL()), a.R.listen(a.o, "click", a.Ej))
                : a.o.Ra(),
              a.o.Pb(c)));
          a.da == null &&
            ((a.da = Bn()),
            (c = a.h.ma),
            (e = new Lm()),
            (c = jh(e, 4, c.O)),
            (e = Km(Jm(new Im(), En()), kP)),
            (c = Mg(c, 5, e)),
            (e = Km(Jm(new Im(), a.W.se), a.W.Mc)),
            (c = Mg(c, 1, e)),
            (e = Km(Jm(new Im(), a.W.hi), a.W.gi)),
            (c = Mg(c, 2, e)),
            (e = Km(Jm(new Im(), a.Ta), a.da)),
            (c = Mg(c, 3, e)),
            (e = {}),
            sP(a, {
              type: "videoPlaybackInstrumentation",
              data: ((e.videoPlaybackLatency = c.ha()), e),
            }));
          b = new TO(b.type, d);
          break;
        case "complete":
          rP(a);
          a.l = null;
          NL() && zO(a.O, a.Y, pM(d));
          a.j = null;
          a.J = null;
          b = new TO(b.type, d);
          break;
        case "log":
          c = null;
          e = b.data.logData;
          e != null && e.type != null
            ? ((f = e.type), (f = f === "adLoadError" || f === "adPlayError"))
            : (f = !1);
          f && (c = { adError: new PO(e) });
          b = new TO(b.type, d, c);
          break;
        case "interaction":
          b = new TO(b.type, d, b.data.interactionData);
          break;
        case "adProgress":
          b = new TO(b.type, d, new VO(b.data));
          break;
        default:
          b = new TO(b.type, d);
      }
      S.prototype.dispatchEvent.call(a, b);
      a.fb && a.fa && a.destroy();
    },
    mP = function (a, b) {
      var c = new RO(new PO(b));
      a.ba
        ? (S.prototype.dispatchEvent.call(a, c),
          NL() && a.j && zO(a.O, a.Y, pM(a.j)),
          (a.j = null),
          rP(a),
          (a.l = null))
        : a.H.j.push(c);
      a = { error: b.errorCode, vis: xn(document) };
      W.getInstance().report(7, a);
    },
    sP = function (a, b) {
      uI(a.A, "adsManager", b.type, b.data);
    },
    pP = function (a, b) {
      W.getInstance().report(131);
      lP(a, b);
      a.Va() || a.C.start();
    },
    nP = function (a) {
      var b = a.h.ma;
      NN(a.h) &&
        a.B.restoreCustomPlaybackStateOnAdBreakComplete &&
        b.sa != null &&
        b.sa();
    },
    lP = function (a, b) {
      var c = a.h.ma;
      NN(a.h) && a.B.restoreCustomPlaybackStateOnAdBreakComplete && c.T != null
        ? c.T(b)
        : b && b();
    };
  n = Z.prototype;
  n.addEventListener = function (a, b, c, d) {
    d &&
      (console.warn("Handler scope is deprecated. Use arrow function or bind."),
      W.getInstance().report(217, {
        method: "AdsManager.addEventListener w/ handler scope",
      }));
    if (Array.isArray(a)) {
      console.warn("Array not supported. Listen for a single event type.");
      W.getInstance().report(217, {
        method: "AdsManager.addEventListener w/ array",
      });
      a = y(a);
      var e = a.next();
      try {
        for (; !e.done; e = a.next()) this.addEventListener(e.value, b, c, d);
      } finally {
        z(a, e);
      }
    } else S.prototype.listen.call(this, a, b, c, d);
  };
  n.removeEventListener = function (a, b, c, d) {
    d &&
      (console.warn("Handler scope is deprecated. Use arrow function or bind."),
      W.getInstance().report(217, {
        method: "AdsManager.removeEventListener w/ handler scope",
      }));
    if (Array.isArray(a)) {
      console.warn("Array not supported. Listen for a single event type.");
      W.getInstance().report(217, {
        method: "AdsManager.removeEventListener w/ array",
      });
      a = y(a);
      var e = a.next();
      try {
        for (; !e.done; e = a.next())
          this.removeEventListener(e.value, b, c, d);
      } finally {
        z(a, e);
      }
    } else S.prototype.Ma.call(this, a, b, c, d);
  };
  n.Vg = function () {
    S.prototype.lf.call(this);
  };
  n.listen = function () {
    throw Error("Not supported; use addEventListener instead.");
  };
  n.dispatchEvent = function () {
    console.error("Dispatching events is not supported.");
    W.getInstance().report(217, { method: "AdsManager.dispatchEvent" });
    return !1;
  };
  n.configureAdsManager = function (a, b) {
    a instanceof tM && ((a.j = this.A), (a = a.h));
    var c = a;
    this.F = c;
    c.currentTime != null && ((this.C = new WO(c, this.A)), this.C.start());
    b != null && (this.B = tP(b));
    b = a;
    bJ(b) && (this.K = $I(b, 2));
  };
  n.init = function (a, b, c, d) {
    if (this.H.isEmpty()) {
      c = this.h;
      var e = null;
      c.j && d == null && (e = { vd: "setnull" });
      c.j && c.j === d && (e = { vd: "match" });
      if (c.j && c.j !== d) {
        e = ML(d || null);
        var f = UC(d || null);
        e = { vd: "diff", oc: c.V, nc: e, oi: c.H, ni: f };
      }
      !c.j && d && (e = { vd: "new" });
      e && ((e.custVid = c.N), W.getInstance().report(93, e));
      d != null &&
        ((c.xd = MO(d)),
        KL(c.xd) &&
          ((c.F = !0),
          qt(c.h),
          qt(c.l),
          qt(c.Ka),
          (c.h = null),
          (c.l = null),
          (c.Ka = null),
          qt(c.ma),
          (c.ma = new EO(d)),
          typeof d.getBoundingClientRect !== "function"
            ? ((c.D = c.o), (U.j = c.D))
            : (c.D = d),
          c.A.od(c.ma)));
      this.ba = !0;
      this.resize(a, b);
      c = this.B.ha();
      e = this.K;
      if (!(e && kg(e, 1) && kg(e, 2)))
        if (d) this.K = $I(d, 1);
        else
          try {
            var g,
              h = this.h;
            var k = h.hd,
              l = k.clientWidth,
              m = k.clientHeight;
            if (typeof k.getBoundingClientRect === "function" && ul(il(k), k)) {
              var p = k.getBoundingClientRect();
              var q = document.elementsFromPoint(p.x + 0.5 * l, p.y + 0.5 * m);
            } else q = [];
            if ((g = aJ(q, h))) this.K = $I(g, 3);
          } catch (x) {
            var r;
            W.getInstance().report(
              212,
              { message: (r = x) == null ? void 0 : r.message },
              1
            );
          }
      var t, v;
      d = {};
      a =
        ((d.adsRenderingSettings = c),
        (d.width = a),
        (d.height = b),
        (d.videoContentSignals =
          (v = (t = this.K) == null ? void 0 : t.ha()) != null ? v : null),
        d);
      sP(this, { type: "init", data: a });
    } else {
      for (; !this.H.isEmpty(); )
        (v = t = this.H),
          v.h.length === 0 && ((v.h = v.j), v.h.reverse(), (v.j = [])),
          (t = t.h.pop()),
          S.prototype.dispatchEvent.call(this, t);
      this.dispose();
    }
  };
  n.isCustomPlaybackUsed = function () {
    return NN(this.h);
  };
  n.isCustomClickTrackingUsed = function () {
    return this.l == null
      ? (console.warn(
          "Calling isCustomClickTrackingUsed() before the STARTED event has fired is not supported."
        ),
        !1)
      : this.l;
  };
  n.getRemainingTime = function () {
    return this.oa;
  };
  n.getAdSkippableState = function () {
    return this.T;
  };
  n.discardAdBreak = function () {
    sP(this, { type: "discardAdBreak" });
  };
  n.updateAdsRenderingSettings = function (a) {
    if (a != null) {
      a = tP(a);
      var b = this.B.bitrate,
        c = a.bitrate;
      W.getInstance().report(96, {
        init: this.ba ? "1" : "0",
        start: this.va ? "1" : "0",
        old: b,
        new: c,
        changed: b !== c ? "1" : "0",
      });
      this.B = a;
      a = this.B.ha();
      b = {};
      a = ((b.adsRenderingSettings = a), b);
      sP(this, { type: "updateAdsRenderingSettings", data: a });
    }
  };
  n.skip = function () {
    sP(this, { type: "skip" });
  };
  n.start = function () {
    this.Ta = Bn();
    if (this.adTagUrl) {
      var a;
      if ((a = Hc || Jc)) a = !0;
      a && W.getInstance().report(50, { customPlayback: NN(this.h) });
      this.h.Ga() ||
        W.getInstance().report(26, {
          adtagurl: this.adTagUrl,
          customPlayback: NN(this.h),
        });
      Fs(this.h.o) &&
        W.getInstance().report(30, {
          adtagurl: this.adTagUrl,
          customPlayback: NN(this.h),
        });
      var b = this.h.Ae;
      a = this.h.o;
      var c;
      if ((c = b && a && !Fs(b)))
        (b = uO(b)),
          (a = uO(a)),
          (c =
            b.width > 0 &&
            b.height > 0 &&
            a.width > 0 &&
            a.height > 0 &&
            b.left <= a.left + a.width &&
            a.left <= b.left + b.width &&
            b.top <= a.top + a.height &&
            a.top <= b.top + b.height);
      a = c;
      W.getInstance().report(31, {
        adtagurl: this.adTagUrl,
        customPlayback: NN(this.h),
        covers: a,
      });
    }
    if (!this.h.Ga() && !NN(this.h)) throw jJ(dJ);
    this.h.A.frameElement.style.opacity = "1";
    if (this.F != null && this.getVolume() === 1) {
      var d, e;
      if (
        typeof ((d = this.F) == null ? void 0 : d.muted) === "boolean" &&
        ((e = this.F) == null ? 0 : e.muted)
      )
        this.setVolume(0);
      else {
        var f;
        if (typeof ((f = this.F) == null ? void 0 : f.volume) === "number") {
          var g;
          d = (g = this.F) == null ? void 0 : g.volume;
          if (d >= 0 && d <= 1) {
            var h;
            this.setVolume((h = this.F) == null ? void 0 : h.volume);
          }
        }
      }
    }
    this.va = !0;
    sP(this, { type: "start" });
  };
  var rP = function (a) {
    a.o != null && a.o.Ra();
  };
  n = Z.prototype;
  n.Ej = function () {
    uI(this.A, "displayContainer", "videoClick");
    if (this.j != null) {
      var a = qM(this.j);
      a != null && eD(a);
    }
  };
  n.resize = function (a, b) {
    var c = this.h,
      d = c.o;
    d != null &&
      (a === -1
        ? ((d.style.right = "0"), (d.style.left = "0"))
        : (d.style.width = a + "px"),
      b === -1
        ? ((d.style.bottom = "0"), (d.style.top = "0"))
        : (d.style.height = b + "px"));
    d = c.A;
    d.frameElement.width = a === -1 ? "100%" : String(a);
    d.frameElement.height = b === -1 ? "100%" : String(b);
    try {
      d.frameElement.offsetTop = d.frameElement.offsetTop;
    } catch (e) {}
    c.size = new Rk(a, b);
    c = {};
    a = ((c.width = a), (c.height = b), c);
    sP(this, { type: "resize", data: a });
  };
  n.stop = function () {
    sP(this, { type: "stop" });
  };
  n.expand = function () {
    sP(this, { type: "expand" });
  };
  n.collapse = function () {
    sP(this, { type: "collapse" });
  };
  n.getVolume = function () {
    return this.volume;
  };
  n.setVolume = function (a) {
    this.volume = a;
    this.h.ma.setVolume(a);
    var b = {};
    a = ((b.volume = a), b);
    sP(this, { type: "volume", data: a });
  };
  n.pause = function () {
    sP(this, { type: "pause" });
  };
  n.resume = function () {
    sP(this, { type: "resume" });
  };
  n.destroy = function () {
    this.dispose();
  };
  n.getCuePoints = function () {
    return this.Nc;
  };
  n.Ti = function () {
    return this.j;
  };
  n.M = function () {
    sP(this, { type: "destroy" });
    this.o != null && this.o.dispose();
    this.R.dispose();
    this.H.clear();
    this.C && (this.C.stop(), this.C.dispose());
    NL() && zO(this.O, this.Y);
    S.prototype.M.call(this);
  };
  n.Ai = function () {
    W.getInstance().report(124, { api: "clicked" });
    var a = this.j && qM(this.j),
      b;
    a && ((b = this.j) == null ? 0 : b.Ig()) && eD(a);
    sP(this, { type: "click" });
  };
  n.focus = function () {
    uI(this.A, "userInteraction", "focusUiElement");
  };
  var qP = function (a, b) {
    var c = b.gfpCookieUserEnabled;
    b = b.gfpCookieClearData;
    var d = new hP();
    d = hh(d, 1, c ? "0" : "1");
    d = fh(d, 2, 2147483647);
    d = hh(d, 3, "/");
    d = hh(d, 4, window.location.hostname);
    var e = new GM(),
      f,
      g;
    a = (g = (f = a.Aa) == null ? void 0 : II(f)) != null ? g : null;
    HM(e, "__gpi_opt_out", d, a);
    if (!c || b) IM(e, "__gads", a), IM(e, "__gpi", a);
  };
  Z.prototype.clicked = Z.prototype.Ai;
  Z.prototype.getCurrentAd = Z.prototype.Ti;
  Z.prototype.getCuePoints = Z.prototype.getCuePoints;
  Z.prototype.destroy = Z.prototype.destroy;
  Z.prototype.resume = Z.prototype.resume;
  Z.prototype.pause = Z.prototype.pause;
  Z.prototype.setVolume = Z.prototype.setVolume;
  Z.prototype.getVolume = Z.prototype.getVolume;
  Z.prototype.collapse = Z.prototype.collapse;
  Z.prototype.expand = Z.prototype.expand;
  Z.prototype.stop = Z.prototype.stop;
  Z.prototype.resize = Z.prototype.resize;
  Z.prototype.start = Z.prototype.start;
  Z.prototype.skip = Z.prototype.skip;
  Z.prototype.updateAdsRenderingSettings =
    Z.prototype.updateAdsRenderingSettings;
  Z.prototype.discardAdBreak = Z.prototype.discardAdBreak;
  Z.prototype.getAdSkippableState = Z.prototype.getAdSkippableState;
  Z.prototype.getRemainingTime = Z.prototype.getRemainingTime;
  Z.prototype.isCustomClickTrackingUsed = Z.prototype.isCustomClickTrackingUsed;
  Z.prototype.isCustomPlaybackUsed = Z.prototype.isCustomPlaybackUsed;
  Z.prototype.init = Z.prototype.init;
  Z.prototype.dispatchEvent = Z.prototype.dispatchEvent;
  Z.prototype.listen = Z.prototype.listen;
  Z.prototype.removeAllEventListeners = Z.prototype.Vg;
  function tP(a) {
    if (a instanceof sM) return W.getInstance().report(174, { valid: !0 }), a;
    W.getInstance().report(174, { valid: !1 });
    var b = new sM();
    b.append(a);
    return b;
  }
  var uP = { ADS_MANAGER_LOADED: "adsManagerLoaded" },
    vP = function (a, b) {
      Vx.call(this, "adsManagerLoaded");
      this.h = a;
      this.j = b;
    };
  w(vP, Vx);
  vP.prototype.getAdsManager = function (a, b) {
    this.h.configureAdsManager(a || { currentTime: null }, b);
    return this.h;
  };
  vP.prototype.getUserRequestContext = function () {
    return this.j;
  };
  vP.prototype.getUserRequestContext = vP.prototype.getUserRequestContext;
  vP.prototype.getAdsManager = vP.prototype.getAdsManager;
  D(
    "module$exports$google3$javascript$ads$interactivemedia$sdk$clientside$api$ads_manager_loaded_event.AdsManagerLoadedEvent.Type",
    uP
  );
  var hL = tq(lB);
  function wP(a, b) {
    return b
      ? (a = a.find(function (c) {
          return Yg(c, 1) === b;
        }))
        ? [a]
        : []
      : [];
  }
  var xP = function (a) {
      var b = this;
      this.target = a;
      this.forward = function () {
        var c;
        (c = b.target) == null || c.call(b);
      };
    },
    zP = function (a) {
      S.call(this);
      var b = this;
      this.C = new GM();
      this.l = null;
      this.H = new Map();
      this.J = {};
      this.W = this.F = this.B = null;
      this.T = new xP(function () {
        var e = b.W;
        e && yP(b, e.Ci, e.pbjs);
      });
      this.R = !1;
      var c = XH(uM(this.getSettings()));
      c && c.length > 0 && (mp.reset(), pp(new to(c)));
      this.o = a;
      this.h = this.o.A;
      this.A = new zD(this);
      tt(this, this.A);
      this.K = new YI(window);
      tt(this, this.K);
      rt(this, function () {
        b.T.target = null;
      });
      this.O = new iL();
      lL(this.O);
      U.h !== 0 ? ((this.j = new rO()), tt(this, this.j)) : (this.j = sO());
      this.ba = sq(gB) ? VL() : null;
      a = hO(this.h);
      if (NL()) {
        this.j.init(a);
        var d = yO(this.j, this.o.D);
        rt(this, function () {
          b.j.l.delete(d);
          U.h !== 0 && (M(cx).o[d] = null);
        });
        this.B = d;
      }
      this.Y = new MN(this.o, this.B);
    };
  w(zP, S);
  n = zP.prototype;
  n.addEventListener = function (a, b, c, d) {
    d &&
      (console.warn("Handler scope is deprecated. Use arrow function or bind."),
      W.getInstance().report(217, {
        method: "AdsLoader.addEventListener w/ handler scope",
      }));
    if (Array.isArray(a))
      throw Error("Array not supported. Listen for a single event type.");
    S.prototype.listen.call(this, a, b, c, d);
  };
  n.removeEventListener = function (a, b, c, d) {
    d &&
      (console.warn("Handler scope is deprecated. Use arrow function or bind."),
      W.getInstance().report(217, {
        method: "AdsLoader.removeEventListener w/ handler scope",
      }));
    if (Array.isArray(a))
      throw Error("Array not supported. Listen for a single event type.");
    S.prototype.Ma.call(this, a, b, c, d);
  };
  n.Vg = function () {
    S.prototype.lf.call(this);
  };
  n.listen = function () {
    throw Error("Not supported; use addEventListener instead.");
  };
  n.dispatchEvent = function () {
    throw Error("Dispatching events is not supported.");
  };
  var AP = function (a, b) {
    S.prototype.dispatchEvent.call(a, b);
  };
  zP.prototype.destroy = function () {
    this.dispose();
  };
  zP.prototype.getVersion = function () {
    return "h.3.800.0";
  };
  zP.prototype.requestAds = function (a, b) {
    var c = this,
      d,
      e,
      f,
      g,
      h,
      k,
      l,
      m,
      p;
    return Ka(function (q) {
      if (q.j == 1) {
        d = yN();
        e = Bn();
        if (!a.adTagUrl && !a.adsResponse)
          return (
            (f = {}),
            BP(
              c,
              ((f.errorCode = 1013),
              (f.errorMessage =
                "The ad request must either have an ad tag URL or an ads response."),
              (f.type = "adLoadError"),
              f),
              ""
            ),
            q.return()
          );
        g = vk();
        c.H.set(g, b || null);
        return q.h(CP(c, a, d), 2);
      }
      h = q.l;
      k = h.data;
      l = h.Aa;
      m = h.networkCode;
      p = h.Rg;
      DP(c, g, l, k, e, d, EP(c, g, d), m, p);
      q.B();
    });
  };
  zP.prototype.ek = function (a) {
    var b = this,
      c,
      d,
      e,
      f,
      g,
      h,
      k,
      l;
    return Ka(function (m) {
      if (m.j == 1) {
        if (a == null)
          return (
            (b.F = null),
            uI(hO(b.h), "adsLoader", "setPauseAdsRequest", null),
            m.return()
          );
        if (!a.adTagUrl && !a.adsResponse)
          return (
            (c = {}),
            BP(
              b,
              ((c.errorCode = 1013),
              (c.errorMessage =
                "The ad request must either have an ad tag URL or an ads response."),
              (c.type = "adLoadError"),
              c),
              ""
            ),
            m.return()
          );
        d = vk();
        return m.h(CP(b, a, null), 2);
      }
      e = m.l;
      f = e.data;
      g = e.Aa;
      h = e.networkCode;
      k = e.Rg;
      (l = b.o.ce) &&
        l.offsetWidth > 0 &&
        l.offsetHeight > 0 &&
        (f.pauseAdSlot = l.offsetWidth + "x" + l.offsetHeight);
      b.F = a;
      b.A.listen(hO(b.h, d), "adsLoader", function (p) {
        b.F === a &&
          (p.messageType === "error"
            ? AP(b, new TO("log", null, { adError: new PO(p.ra) }))
            : FP(b, p, g, Bn(), null, null, h, k));
      });
      uI(hO(b.h), "adsLoader", "setPauseAdsRequest", f, d);
      m.B();
    });
  };
  var EP = function (a, b, c) {
      b = hO(a.h, b);
      b = new PL(b, "prebid");
      QL(b, "requestPrebidAd", function (d) {
        try {
          var e = d.adId,
            f = d.adTagUrl;
          if (c) {
            if (c.getBidResponseByAdId) {
              var g = "adId";
              d = { m: "getPrebidBidResponseByAdId" };
              var h,
                k =
                  (h = c.getBidResponseByAdId) == null ? void 0 : h.call(c, e);
              if (k) {
                IN(d);
                h = {};
                var l = ((h.vastUrl = k.vastUrl), (h.vastXml = k.vastXml), h);
              } else
                IN(d, "cannot_find_bid"),
                  (k = {}),
                  (l = ((k.error = JN(fJ)), k));
            } else
              c.getBidResponsesForAdUnitCode
                ? ((g = "adUnitCode"), (l = HN(c, f, e)))
                : ((g = "incompat"), (k = {}), (l = ((k.error = JN(hJ)), k)));
            var m = !l.error;
            W.getInstance().report(
              251,
              {
                type: g,
                status: m ? "success" : "error",
                hasAdTagUrl: f ? "1" : "0",
                hasVastXml: l.vastXml ? "1" : "0",
              },
              tq(dB)
            );
            if (m) {
              var p;
              (p = c.markWinningBidAsUsed) == null || p.call(c, { adId: e });
            }
            var q = l;
          } else (e = {}), (q = ((e.error = JN(gJ)), e));
        } catch (r) {
          (q = {}), (q = ((q.error = JN(iJ, r)), q));
        }
        return Promise.resolve(q);
      });
      QL(b, "markPrebidAdUsed", function (d) {
        if (c)
          try {
            var e;
            (e = c.markWinningBidAsUsed) == null || e.call(c, { adId: d.adId });
          } catch (f) {
            W.getInstance().report(195, {
              method: "markCachedPrebidBidAsUsed",
              message: f instanceof Error ? f.message : void 0,
            });
          }
        return Promise.resolve({});
      });
      tt(a, b);
      return b;
    },
    CP = function (a, b, c) {
      var d = Bn(),
        e = b.adTagUrl || "",
        f = e.includes("GOOGLE_INSTREAM_VIDEO_NONCE"),
        g = ZI(a.K),
        h = g.then(function (t) {
          var v;
          return BI(e, t || {}, (v = Op()) == null ? void 0 : Tg(v, 2));
        });
      h.then(function (t) {
        sq(oB)
          ? GP(a, t, c)
          : ZK(t, function () {
              yP(a, t, c);
            });
      });
      var k = HP(a, f, h),
        l = lL(a.O),
        m = e ? pI(e) : null,
        p = XM(m, 500),
        q = Promise.all([h, p]).then(function (t) {
          var v = y(t);
          t = v.next().value;
          v = v.next().value;
          return IP(a, t, m, c, v);
        }),
        r = p.then(function (t) {
          return LN(e, t, c);
        });
      return Promise.all([g, h, l, p, q, r, k]).then(function (t) {
        var v = y(t);
        t = v.next().value;
        var x = v.next().value;
        var E = v.next().value;
        var F = v.next().value;
        var B = v.next().value;
        var J = v.next().value;
        qa(v);
        v = GI(x);
        var Q = {};
        W.getInstance().report(
          182,
          ((Q.aid = !!U.l), (Q.aidf = !!a.l), (Q.hsc = !v && f), Q)
        );
        v = {};
        W.getInstance().report(
          155,
          ((v.ws = gL()), (v.blob = E != null ? E : "undef"), v)
        );
        sq(pB) || (B = OJ(II(x)));
        B && (a.J.espSignals = B);
        v = B;
        Q = {};
        W.getInstance().report(
          239,
          ((Q.ppc_ss_enabled = sq(pB)),
          (Q.ss_empty_cache_timeout_ms = sq(pB) ? tq(nB) : "undef"),
          (Q.ss = !!v),
          (Q.ss_latency = Bn() - d),
          Q)
        );
        v = J.zc;
        J = J.globalPlacementId;
        Q = a.getSettings().ha(xO(a.j));
        var oa = ON(a.Y, e, { uc: a.h.uc, Fc: a.h.Fc }),
          ta = a.C,
          Da = a.ba;
        try {
          var ca = GN(e, c),
            fa = [],
            Ma = y(ca),
            wa = Ma.next();
          try {
            for (; !wa.done; wa = Ma.next()) {
              var Ia = wa.value;
              ca = void 0;
              if ((ca = Ia) != null && ca.adId && (Ia.vastUrl || Ia.vastXml)) {
                ca = {};
                var Vb = ((ca.adId = Ia.adId), ca);
                Ia.vastUrl && (Vb.vastUrl = Ia.vastUrl);
                Ia.vastXml && (Vb.vastXml = Ia.vastXml);
                fa.push(Vb);
              }
            }
          } finally {
            z(Ma, wa);
          }
          var pc = fa;
        } catch (pf) {
          W.getInstance().report(195, {
            method: "getAllBidsByAdTagUrl",
            message: pf instanceof Error ? pf.message : void 0,
          }),
            (pc = []);
        }
        return {
          data: LM(b, t, x, E, F, B, v, J, Q, oa, ta, Da, pc),
          Aa: x,
          networkCode: m,
          Rg: F,
        };
      });
    },
    GP = function (a, b, c) {
      a.W = { Ci: b, pbjs: c };
      a.R || (a.R = ZK(b, a.T.forward));
    };
  zP.prototype.getSettings = function () {
    return vM;
  };
  zP.prototype.contentComplete = function () {
    uI(hO(this.h), "adsLoader", "contentComplete");
  };
  var FP = function (a, b, c, d, e, f, g, h) {
      f = f === void 0 ? null : f;
      var k = b.messageType;
      switch (k) {
        case "adsLoaded":
          JP(a, b.ra, b.sessionId, c, d, f);
          break;
        case "error":
          BP(a, b.ra, b.sessionId);
          var l;
          (l = f) == null || l.dispose();
          break;
        case "cookieUpdate":
          b = b.ra;
          if (b == null) break;
          d = new xI();
          d = bh(d, 5, !0);
          (f = b.gfpCookie) && HM(a.C, "__gads", iP(f), d);
          (f = b.gfpCookieV2) && HM(a.C, "__gpi", iP(f), d);
          if ((f = b.eoidCookie))
            (d = new EM()),
              (f = iP(f)),
              (k = Sp(Wg(f, 2)) - Date.now() / 1e3),
              (k = {
                Qd: Math.max(k, 0),
                path: Yg(f, 3),
                domain: Yg(f, 4),
                secure: !1,
              }),
              DM("__eoi", f.getValue(), k, d.h);
          KP(a, b.encryptedSignalBidderIds || [], c, e, g, h);
          break;
        case "trackingUrlPinged":
          AP(a, new TO(k, null, b.ra));
      }
    },
    KP = function (a, b, c, d, e, f) {
      if (b.length !== 0) {
        var g = null;
        if (sq(pB) && f) {
          var h;
          b = wP((h = Kg(f, yj, 7)) != null ? h : [], e != null ? e : null);
          g = $K(b, c);
        } else
          g = aL(
            b.map(function (k) {
              return { Bi: k, Pm: !1, Om: !1 };
            }),
            c
          );
        g &&
          g.forEach(function (k) {
            k.then(function (l) {
              l && yP(a, c, d, e, f);
            });
          });
      }
    },
    yP = function (a, b, c, d, e) {
      var f = sq(pB);
      if (f) {
        var g;
        e =
          f && e
            ? wP((g = Kg(e, yj, 7)) != null ? g : [], d != null ? d : null)
            : [];
        b = bL(b, d, c, e);
      } else b = OJ(II(b));
      b &&
        ((a.J.espSignals = b), uI(hO(a.h), "adsLoader", "signalsRefresh", a.J));
    },
    IP = function (a, b, c, d, e) {
      var f, g, h, k, l, m, p, q, r;
      return Ka(function (t) {
        switch (t.j) {
          case 1:
            if (!sq(pB) || !e) return t.return(null);
            t.A(2);
            h = wP(
              (f = Kg(e, yj, 7)) != null ? f : [],
              (g = c) != null ? g : null
            );
            k = $K(h, b);
            (l = k) == null ||
              l.forEach(function (v) {
                v.then(function (x) {
                  x && yP(a, b, d, c, e);
                });
              });
            m = bL(b, c, d, h);
            SL(h, k, b, c, d, m);
            p = tq(nB);
            if (!(!m && ((q = k) == null ? 0 : q.length) && p > 0)) {
              t.ia(4);
              break;
            }
            return t.h(Promise.race([Promise.all(k), RL(p)]), 5);
          case 5:
            return t.return(bL(b, c, d, h));
          case 4:
            return t.return(m);
          case 2:
            return (
              (r = t.o()),
              W.getInstance().report(240, { secure_signals_error: r.message }),
              t.return(null)
            );
        }
      });
    },
    JP = function (a, b, c, d, e, f) {
      f = f === void 0 ? null : f;
      b = new Z(a.j, a.o, b.adTagUrl || "", b.adCuePoints, a.B, hO(a.h, c), d, {
        hi: e,
        gi: Bn(),
        se: a.h.se,
        Mc: a.h.Mc,
      });
      f &&
        rt(b, function () {
          f.dispose();
        });
      AP(a, new vP(b, LP(a, c)));
    },
    LP = function (a, b) {
      var c = a.H.get(b);
      a.H.delete(b);
      return c != null ? c : null;
    },
    BP = function (a, b, c) {
      AP(a, new RO(new PO(b), LP(a, c)));
      a = { error: b.errorCode, vis: xn(document) };
      W.getInstance().report(7, a);
    },
    DP = function (a, b, c, d, e, f, g, h, k) {
      b = hO(a.h, b);
      a.A.listen(b, "adsLoader", function (l) {
        return void FP(a, l, c, e, f, g, h, k);
      });
      uI(b, "adsLoader", "requestAds", d);
    },
    HP = function (a, b, c) {
      var d, e;
      return Ka(function (f) {
        if (f.j == 1) return f.h(c, 2);
        if (f.j != 3) {
          d = f.l;
          if (GI(d)) return (a.l = null), f.return();
          if (!b) return f.return();
          a.l || ((a.l = new mI()), nI(a.l));
          return f.h(a.l.getId(), 3);
        }
        e = f.l;
        U.l = e.id || "";
        f.B();
      });
    };
  zP.prototype.contentComplete = zP.prototype.contentComplete;
  zP.prototype.getSettings = zP.prototype.getSettings;
  zP.prototype.setPauseAdsRequest = zP.prototype.ek;
  zP.prototype.requestAds = zP.prototype.requestAds;
  zP.prototype.getVersion = zP.prototype.getVersion;
  zP.prototype.destroy = zP.prototype.destroy;
  zP.prototype.dispatchEvent = zP.prototype.dispatchEvent;
  zP.prototype.listen = zP.prototype.listen;
  function MP(a, b) {
    return a && (a[b] || (a[b] = {}));
  }
  function NP(a, b) {
    var c;
    if (
      (c =
        c === void 0
          ? typeof omidExports === "undefined"
            ? null
            : omidExports
          : c)
    )
      (a = a.split(".")),
        (a.slice(0, a.length - 1).reduce(MP, c)[a[a.length - 1]] = b);
  }
  var OP = new Map([
    [
      3,
      [
        /^(https?:\/\/|\/\/)?[-a-zA-Z0-9.]+\.doubleverify\.com\/.*$/,
        /^(https?:\/\/|\/\/)?c\.[\w\-]+\.com\/vfw\/dv\/.*$/,
        /^(https?:\/\/|\/\/)?(www\.)?[\w]+\.tv\/r\/s\/d\/.*$/,
        /^(https?:\/\/|\/\/)?(\w\.?)+\.dv\.tech\/.*$/,
      ],
    ],
    [4, [/^(https?:\/\/|\/\/)?[-a-zA-Z0-9.]+\.adsafeprotected\.com\/.*$/]],
    [
      5,
      [
        /^https?:\/\/(q|cdn)\.adrta\.com\/s\/.*\/(aa|aanf)\.js.*$/,
        /^https:\/\/cdn\.rta247\.com\/s\/.*\/(aa|aanf)\.js.*$/,
      ],
    ],
    [6, []],
    [
      7,
      [
        /^(https?:\/\/|\/\/)?[-a-zA-Z0-9.]+\.voicefive\.com\/.*$/,
        /^(https?:\/\/|\/\/)?[-a-zA-Z0-9.]+\.measuread\.com\/.*$/,
        /^(https?:\/\/|\/\/)?[-a-zA-Z0-9.]+\.scorecardresearch\.com\/.*$/,
      ],
    ],
    [
      8,
      [/^(https?:\/\/|\/\/)?s418\.mxcdn\.net\/bb-serve\/omid-meetrics.*\.js$/],
    ],
    [
      9,
      [
        /^(https?:\/\/|\/\/)?pagead2\.googlesyndication\.com\/.*$/,
        /^(https?:\/\/|\/\/)?www\.googletagservices\.com\/.*$/,
      ],
    ],
    [
      10,
      [
        /^(https?:\/\/|\/\/)?[-a-zA-Z0-9.]+\.script\.ac\/.*$/,
        /^(https?:\/\/|\/\/)?[-a-zA-Z0-9.]+\/(2|ag|static)\/[a-zA-Z0-9.]*\/analytics.js.*$/,
      ],
    ],
    [11, [/^(https?:\/\/|\/\/)?[-a-zA-Z0-9.]+\.outcomes\.net\/.*$/]],
  ]);
  NP("OmidSessionClient.verificationVendorIdForScriptUrl", function (a) {
    var b = y(OP.keys()),
      c = b.next();
    try {
      for (; !c.done; c = b.next()) {
        var d = c.value,
          e = y(OP.get(d)),
          f = e.next();
        try {
          for (; !f.done; f = e.next()) if (f.value.test(a)) return d;
        } finally {
          z(e, f);
        }
      }
    } finally {
      z(b, c);
    }
    return 1;
  });
  NP("OmidSessionClient.VerificationVendorId", {
    OTHER: 1,
    MOAT: 2,
    DOUBLEVERIFY: 3,
    INTEGRAL_AD_SCIENCE: 4,
    PIXELATE: 5,
    NIELSEN: 6,
    COMSCORE: 7,
    MEETRICS: 8,
    GOOGLE: 9,
    HUMAN: 10,
    MOBIAN: 11,
  });
  var PP = function () {
    MM.call(this);
  };
  w(PP, MM);
  D("google.ima.AdCuePoints.POSTROLL", -1, window);
  D("google.ima.AdCuePoints.PREROLL", 0, window);
  D("google.ima.AdDisplayContainer", NO, window);
  D("google.ima.ContentMonitor", tM, window);
  D("google.ima.AdError.ErrorCode", T, window);
  D("google.ima.AdError.ErrorCode.VIDEO_ELEMENT_USED", -1, window);
  D("google.ima.AdError.ErrorCode.VIDEO_ELEMENT_REQUIRED", -1, window);
  D("google.ima.AdError.ErrorCode.VAST_MEDIA_ERROR", -1, window);
  D("google.ima.AdError.ErrorCode.ADSLOT_NOT_VISIBLE", -1, window);
  D("google.ima.AdError.ErrorCode.OVERLAY_AD_LOADING_FAILED", -1, window);
  D("google.ima.AdError.ErrorCode.VAST_MALFORMED_RESPONSE", -1, window);
  D("google.ima.AdError.ErrorCode.COMPANION_AD_LOADING_FAILED", -1, window);
  D("google.ima.AdError.Type", OO, window);
  D("google.ima.AdErrorEvent.Type", QO, window);
  D("google.ima.AdEvent.Type", SO, window);
  D("google.ima.AdsLoader", zP, window);
  D("google.ima.AdsManagerLoadedEvent.Type", uP, window);
  D("google.ima.CompanionAdSelectionSettings", NI, window);
  D("google.ima.CompanionAdSelectionSettings.CreativeType", JI);
  D("google.ima.CompanionAdSelectionSettings.ResourceType", KI);
  D("google.ima.CompanionAdSelectionSettings.SizeCriteria", LI);
  D(
    "google.ima.CustomContentLoadedEvent.Type.CUSTOM_CONTENT_LOADED",
    "deprecated-event",
    window
  );
  D("ima.ImaSdkSettings", Y, window);
  D("google.ima.settings", vM, window);
  D("google.ima.ImaSdkSettings.CompanionBackfillMode", {
    ALWAYS: "always",
    ON_MASTER_AD: "on_master_ad",
  });
  D("google.ima.ImaSdkSettings.VpaidMode", {
    DISABLED: 0,
    ENABLED: 1,
    INSECURE: 2,
    0: "DISABLED",
    1: "ENABLED",
    2: "INSECURE",
  });
  D("google.ima.AdsRenderingSettings", sM, window);
  D("google.ima.AdsRenderingSettings.AUTO_SCALE", -1, window);
  D("google.ima.AdsRequest", MM, window);
  D("google.ima.PauseAdsRequest", PP, window);
  D(
    "google.ima.VideoOrientation",
    {
      UNSET: 0,
      LANDSCAPE: 1,
      PORTRAIT: 2,
      SQUARE: 3,
      0: "UNSET",
      1: "LANDSCAPE",
      2: "PORTRAIT",
      3: "SQUARE",
    },
    window
  );
  D("google.ima.VERSION", "3.800.0");
  D("google.ima.OmidAccessMode", {
    LIMITED: "limited",
    DOMAIN: "limited",
    FULL: "full",
  });
  D("google.ima.OmidVerificationVendor", {
    COMSCORE: 7,
    DOUBLEVERIFY: 3,
    GOOGLE: 9,
    HUMAN: 10,
    INTEGRAL_AD_SCIENCE: 4,
    MEETRICS: 8,
    MOAT: 2,
    MOBIAN: 11,
    NIELSEN: 6,
    PIXELATE: 5,
    OTHER: 1,
    7: "COMSCORE",
    3: "DOUBLEVERIFY",
    9: "GOOGLE",
    10: "HUMAN",
    4: "INTEGRAL_AD_SCIENCE",
    8: "MEETRICS",
    2: "MOAT",
    11: "MOBIAN",
    6: "NIELSEN",
    5: "PIXELATE",
    1: "OTHER",
  });
  D("google.ima.UiElements", {
    AD_ATTRIBUTION: "adAttribution",
    COUNTDOWN: "countdown",
  });
  D("google.ima.ViewMode", { NORMAL: "normal", FULLSCREEN: "fullscreen" });
  D("google.ima.secureSignals", {
    clearAllCache: function () {
      var a = window.localStorage;
      if (a !== void 0) {
        var b = y(Object.keys(a)),
          c = b.next();
        try {
          for (; !c.done; c = b.next()) {
            var d = c.value;
            if (d.startsWith("_GESPSK"))
              try {
                a.removeItem(d);
              } catch (e) {}
          }
        } finally {
          z(b, c);
        }
      }
      FJ = new EJ();
    },
  });
  var QP = [
      94, 40, 63, 58, 104, 116, 116, 112, 115, 63, 58, 41, 63, 47, 47, 105, 109,
      97, 115, 100, 107, 92, 46, 103, 111, 111, 103, 108, 101, 97, 112, 105,
      115, 92, 46, 99, 111, 109, 47, 106, 115, 47, 40, 115, 100, 107, 108, 111,
      97, 100, 101, 114, 124, 99, 111, 114, 101, 41, 47,
    ],
    RP = [
      94, 40, 63, 58, 104, 116, 116, 112, 115, 63, 58, 41, 63, 47, 47, 115, 48,
      92, 46, 50, 109, 100, 110, 92, 46, 110, 101, 116, 47, 105, 110, 115, 116,
      114, 101, 97, 109, 47, 104, 116, 109, 108, 53, 47,
    ],
    SP = [
      94, 40, 63, 58, 104, 116, 116, 112, 115, 63, 58, 41, 63, 47, 47, 105, 109,
      97, 115, 100, 107, 92, 46, 103, 111, 111, 103, 108, 101, 97, 112, 105,
      115, 92, 46, 99, 111, 109, 47, 112, 97, 108, 47, 115, 100, 107, 108, 111,
      97, 100, 101, 114, 47,
    ],
    TP = [
      [105, 109, 97, 51, 92, 46, 106, 115],
      [105, 109, 97, 51, 95, 100, 101, 98, 117, 103, 92, 46, 106, 115],
      [105, 109, 97, 51, 95, 101, 97, 112, 46, 106, 115],
    ],
    UP = [
      [
        98, 114, 105, 100, 103, 101, 40, 91, 48, 45, 57, 93, 43, 92, 46, 91, 48,
        45, 57, 92, 46, 93, 43, 41, 40, 95, 40, 91, 97, 45, 122, 48, 45, 57, 93,
        41, 123, 50, 44, 51, 125, 41, 123, 48, 44, 50, 125, 92, 46, 104, 116,
        109, 108,
      ],
      [
        98, 114, 105, 100, 103, 101, 40, 91, 48, 45, 57, 93, 43, 92, 46, 91, 48,
        45, 57, 92, 46, 93, 43, 41, 95, 100, 101, 98, 117, 103, 40, 95, 40, 91,
        97, 45, 122, 48, 45, 57, 93, 41, 123, 50, 44, 51, 125, 41, 123, 48, 44,
        50, 125, 92, 46, 104, 116, 109, 108,
      ],
      [
        98, 114, 105, 100, 103, 101, 40, 95, 40, 91, 97, 45, 122, 48, 45, 57,
        93, 41, 123, 50, 44, 51, 125, 41, 123, 48, 44, 50, 125, 92, 46, 104,
        116, 109, 108,
      ],
    ];
  var VP = function (a, b, c) {
      this.j = c;
      b.length === 0 && (b = [[]]);
      this.h = b.map(function (d) {
        d = a.concat(d);
        for (var e = [], f = 0, g = 0; f < d.length; ) {
          var h = d[f++];
          if (h < 128) e[g++] = String.fromCharCode(h);
          else if (h > 191 && h < 224) {
            var k = d[f++];
            e[g++] = String.fromCharCode(((h & 31) << 6) | (k & 63));
          } else if (h > 239 && h < 365) {
            k = d[f++];
            var l = d[f++],
              m = d[f++];
            h =
              (((h & 7) << 18) |
                ((k & 63) << 12) |
                ((l & 63) << 6) |
                (m & 63)) -
              65536;
            e[g++] = String.fromCharCode(55296 + (h >> 10));
            e[g++] = String.fromCharCode(56320 + (h & 1023));
          } else
            (k = d[f++]),
              (l = d[f++]),
              (e[g++] = String.fromCharCode(
                ((h & 15) << 12) | ((k & 63) << 6) | (l & 63)
              ));
        }
        return new RegExp(e.join(""));
      });
    },
    WP = function (a, b) {
      return b
        ? a.h.some(function (c) {
            c = b.match(c);
            return c == null
              ? !1
              : !a.j ||
                  (c.length >= 1 && c[1] === "3.800.0") ||
                  (c.length >= 2 && c[2] === "3.800.0");
          })
        : !1;
    },
    XP = new VP(QP, TP, !1);
  new VP(QP, UP, !0);
  var YP = new VP(RP, TP, !1);
  new VP(RP, UP, !0);
  var ZP = new VP(
      [
        94, 40, 63, 58, 104, 116, 116, 112, 115, 63, 58, 41, 63, 47, 47, 105,
        109, 97, 115, 100, 107, 92, 46, 103, 111, 111, 103, 108, 101, 97, 112,
        105, 115, 92, 46, 99, 111, 109, 47, 112, 114, 101, 114, 101, 108, 101,
        97, 115, 101, 47, 106, 115, 47, 91, 48, 45, 57, 93, 43, 46, 91, 48, 45,
        57, 46, 93, 43, 47,
      ],
      TP,
      !1
    ),
    $P = new VP(
      [
        94, 40, 63, 58, 104, 116, 116, 112, 115, 63, 58, 41, 63, 47, 47, 40,
        112, 97, 103, 101, 97, 100, 50, 124, 116, 112, 99, 41, 92, 46, 103, 111,
        111, 103, 108, 101, 115, 121, 110, 100, 105, 99, 97, 116, 105, 111, 110,
        92, 46, 99, 111, 109, 47, 112, 97, 103, 101, 97, 100, 47, 40, 103, 97,
        100, 103, 101, 116, 115, 124, 106, 115, 41, 47,
      ],
      [],
      !1
    );
  new VP(
    QP,
    [
      [
        100, 97, 105, 95, 105, 102, 114, 97, 109, 101, 40, 91, 48, 45, 57, 93,
        43, 92, 46, 91, 48, 45, 57, 92, 46, 93, 43, 41, 40, 95, 40, 91, 97, 45,
        122, 48, 45, 57, 93, 41, 123, 50, 44, 51, 125, 41, 123, 48, 44, 50, 125,
        92, 46, 104, 116, 109, 108,
      ],
      [
        100, 97, 105, 95, 105, 102, 114, 97, 109, 101, 40, 91, 48, 45, 57, 93,
        43, 92, 46, 91, 48, 45, 57, 92, 46, 93, 43, 41, 95, 100, 101, 98, 117,
        103, 40, 95, 40, 91, 97, 45, 122, 48, 45, 57, 93, 41, 123, 50, 44, 51,
        125, 41, 123, 48, 44, 50, 125, 92, 46, 104, 116, 109, 108,
      ],
      [
        100, 97, 105, 95, 105, 102, 114, 97, 109, 101, 40, 95, 40, 91, 97, 45,
        122, 48, 45, 57, 93, 41, 123, 50, 44, 51, 125, 41, 123, 48, 44, 50, 125,
        92, 46, 104, 116, 109, 108,
      ],
    ],
    !0
  );
  new VP(SP, [[112, 97, 108, 46, 106, 115]], !1);
  new VP(SP, [[99, 97, 115, 116, 95, 112, 97, 108, 46, 106, 115]], !1);
  new VP(
    SP,
    [
      [112, 97, 108, 95, 99, 116, 118, 46, 106, 115],
      [99, 116, 118, 95, 112, 97, 108, 46, 106, 115],
    ],
    !1
  );
  function aQ(a, b) {
    for (var c = {}, d = 0; d < b.length; c = { rf: void 0 }, d++)
      if (
        ((c.rf = b[d]),
        a.some(
          (function (e) {
            return function (f) {
              return WP(f, e.rf.src);
            };
          })(c)
        ))
      )
        return c.rf;
    return null;
  }
  if (
    !(function (a) {
      if (
        a.some(function (c) {
          return WP(c, ol().location.href);
        })
      )
        return !0;
      var b = aQ(a, document.querySelectorAll("SCRIPT"));
      b == null &&
        document.querySelectorAll &&
        (b = aQ(a, document.querySelectorAll("script")));
      return b != null;
    })([XP, ZP, YP, $P])
  )
    throw Error(
      "IMA SDK is either not loaded from a google domain or is not a supported version."
    );
  var bQ = M(wM);
  W.getInstance().h = bQ;
  var cQ,
    dQ = Np();
  cQ = Ig(dQ, Fp, 3);
  var eQ = WM,
    fQ = bQ.h,
    gQ;
  var hQ = cQ != null ? cQ : null;
  if (hQ) {
    var iQ = Yg(hQ, 1);
    if (iQ && new URL(fQ).hostname.includes(iQ)) {
      var jQ = Ig(hQ, Cj, 2);
      gQ = jQ ? jQ : null;
    } else gQ = null;
  } else gQ = null;
  var kQ = gQ;
  if (kQ) eQ.h = kQ;
  else {
    var xL = eQ.j,
      DL = { pageUrl: fQ };
    try {
      var yL = CL();
      if (!yL) throw Error("Could not generate config URL");
      AL();
    } catch (a) {
      zL(xL, a);
    }
  }
})();
