!(function () {
  try {
    var e =
        "undefined" != typeof window
          ? window
          : "undefined" != typeof global
          ? global
          : "undefined" != typeof globalThis
          ? globalThis
          : "undefined" != typeof self
          ? self
          : {},
      n = new e.Error().stack;
    n &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[n] = "a4329c6e-904d-5554-a0d9-738f86d82048"));
  } catch (e) {}
})();
(function () {
  try {
    var e =
      typeof window < `u`
        ? window
        : typeof global < `u`
        ? global
        : typeof globalThis < `u`
        ? globalThis
        : typeof self < `u`
        ? self
        : {};
    (e._sentryModuleMetadata = e._sentryModuleMetadata || {}),
      (e._sentryModuleMetadata[new e.Error().stack] = (function (e) {
        for (var t = 1; t < arguments.length; t++) {
          var n = arguments[t];
          if (n != null) for (var r in n) n.hasOwnProperty(r) && (e[r] = n[r]);
        }
        return e;
      })({}, e._sentryModuleMetadata[new e.Error().stack], {
        "_sentryBundlerPluginAppKey:crazygames-gameframe": !0,
      }));
    var t = new e.Error().stack;
    t &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[t] = `3cfeb6ae-1cdd-4786-9690-1cec4510a84c`),
      (e._sentryDebugIdIdentifier = `sentry-dbid-3cfeb6ae-1cdd-4786-9690-1cec4510a84c`));
  } catch {}
})();
import {
  D as e,
  Dt as t,
  Et as n,
  Lt as r,
  O as i,
  Ot as a,
  T as o,
  Zt as s,
  en as c,
  gn as l,
  k as u,
  kt as d,
  nn as f,
  rn as p,
  wn as m,
  xn as h,
  yn as g,
} from "../../bundle.js";
import { t as _ } from "./Dkw7RdYv.js";
var v = m(g()),
  y = l(),
  b = `ruffleready`,
  x = o(
    u(
      i(
        class extends v.Component {
          constructor(e) {
            super(e),
              h(this, `progressTracker`, void 0),
              h(this, `config`, void 0),
              h(this, `iframe`, null),
              h(this, `detachRenderScale`, null),
              h(this, `disableIframe`, () => {
                this.iframe &&=
                  (this.detachRenderScale?.(),
                  (this.detachRenderScale = null),
                  this.iframe.remove(),
                  null);
              }),
              h(this, `restartGame`, () => {
                window.location.reload();
              }),
              h(this, `onIframeLoad`, () => {
                this.onLoad(),
                  this.progressTracker.trackLoadFinished(),
                  this.focusOnIframe();
              }),
              h(this, `onLoad`, () => {
                this.props.onLoadFinished();
              }),
              (this.progressTracker = new _()),
              (this.config = p()),
              (this.state = { state: `loading` }),
              (this.onRuffleLoaded = this.onRuffleLoaded.bind(this));
          }
          async componentDidMount() {
            window.addEventListener(`message`, this.onRuffleLoaded, !1),
              await this.startLoading();
          }
          componentWillUnmount() {
            window.removeEventListener(`message`, this.onRuffleLoaded, !1),
              this.detachRenderScale?.(),
              (this.detachRenderScale = null);
          }
          componentDidUpdate(e) {
            e.isFullscreen !== this.props.isFullscreen && this.focusOnIframe(),
              !e.isGameDisabled && this.props.isGameDisabled
                ? this.disableIframe()
                : e.isGameDisabled &&
                  !this.props.isGameDisabled &&
                  this.restartGame();
          }
          render() {
            return this.state.state === `loaded`
              ? null
              : (0, y.jsx)(e, { showProgress: !1 });
          }
          async startLoading() {
            try {
              await r.Instance.waitForAPS();
            } catch {
            } finally {
              this.progressTracker.trackLoadStarted(), this.loadIframe();
            }
          }
          loadIframe() {
            if (this.props.isGameDisabled) return;
            let e = document.createElement(`iframe`);
            (e.id = t),
              (e.src = this.getIframeUrl()),
              (e.onload = this.onIframeLoad),
              (e.style.border = `0`),
              (e.style.backgroundColor = `var(--neutral-0)`),
              (e.style.width = `10px`),
              (e.style.height = `10px`),
              (e.style.minWidth = `100%`),
              (e.style.minHeight = `100%`),
              e.setAttribute(
                `allow`,
                d({ src: this.getIframeUrl(), extra: [`gamepad`] })
              ),
              e.setAttribute(`webkitallowfullscreen`, `true`),
              e.setAttribute(`mozallowfullscreen`, `true`),
              e.setAttribute(`msallowfullscreen`, `true`),
              e.setAttribute(`allowfullscreen`, `true`),
              e.setAttribute(`sandbox`, ``),
              e.sandbox.add(...a),
              (this.iframe = e),
              f().appendChild(e),
              c() && (this.detachRenderScale = s(e));
          }
          getIframeUrl() {
            let e = this.config.loaderOptions,
              t = e.swfLocation.slice(0, -4),
              r = new URL(`${t}.html`),
              i = `https://${this.config.gameSlug}.${n}`,
              a = new URL(`/ruffle${r.pathname}`, i),
              o = `ruffle`;
            return (
              new URLSearchParams(window.location.search).forEach((e, t) => {
                t !== o && a.searchParams.append(t, e);
              }),
              e.loaderLocation && a.searchParams.set(o, e.loaderLocation),
              a.toString()
            );
          }
          focusOnIframe() {
            this.iframe &&
              this.iframe.contentWindow &&
              this.iframe.contentWindow.focus();
          }
          onRuffleLoaded(e) {
            e.data?.type === b && this.setState({ state: `loaded` });
          }
        }
      )
    )
  );
export { x as default };
//# debugId=a4329c6e-904d-5554-a0d9-738f86d82048
