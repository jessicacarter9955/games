(function () {
  "use strict"; /* 
 
 Copyright The Closure Library Authors. 
 SPDX-License-Identifier: Apache-2.0 
*/
  var n = this || self;
  function aa(a, b) {
    a: {
      var c = ["CLOSURE_FLAGS"];
      for (var d = n, e = 0; e < c.length; e++)
        if (((d = d[c[e]]), d == null)) {
          c = null;
          break a;
        }
      c = d;
    }
    a = c && c[a];
    return a != null ? a : b;
  }
  function ba(a) {
    var b = typeof a;
    return b != "object" ? b : a ? (Array.isArray(a) ? "array" : b) : "null";
  }
  function ca(a) {
    var b = ba(a);
    return b == "array" || (b == "object" && typeof a.length == "number");
  }
  function da(a) {
    var b = typeof a;
    return (b == "object" && a != null) || b == "function";
  }
  function r(a, ...b) {
    b = b.filter(Boolean).join("&");
    if (!b) return a;
    var c = a.match(/[?&]adurl=/);
    return c
      ? a.slice(0, c.index + 1) + b + "&" + a.slice(c.index + 1)
      : a + (a.indexOf("?") < 0 ? "?" : "&") + b;
  }
  function ea(a, b) {
    return a === 0
      ? "ri=1"
      : a === 1
      ? b
        ? "ri=24"
        : "ri=27"
      : a === 2
      ? b
        ? "ri=25"
        : "ri=26"
      : "";
  }
  function fa(a, b) {
    return b ? "&" + a + "=" + encodeURIComponent(b) : "";
  }
  function ha(a) {
    a = a.m;
    if (!a) return "";
    var b =
      fa("uap", a.platform) +
      fa("uapv", a.platformVersion) +
      fa("uafv", a.uaFullVersion) +
      fa("uaa", a.architecture) +
      fa("uam", a.model) +
      fa("uab", a.bitness);
    a.fullVersionList &&
      (b +=
        "&uafvl=" +
        encodeURIComponent(
          a.fullVersionList
            .map(
              (c) =>
                encodeURIComponent(c.brand) +
                ";" +
                encodeURIComponent(c.version)
            )
            .join("|")
        ));
    a.wow64 != null && (b += "&uaw=" + Number(a.wow64));
    return b.slice(1);
  }
  function ia(a, b) {
    if (a.h.dsh === "1") return null;
    var c = a.h.ae;
    if (c === "1") {
      let d = a.h.adurl;
      if (d)
        try {
          return {
            version: 3,
            B: decodeURIComponent(d),
            A: r(a.i, "act=1", ea(b, !0), ha(a)),
          };
        } catch (e) {}
    }
    return c === "2"
      ? {
          version: 4,
          B: r(a.i, "dct=1", "suid=" + a.j, ea(b, !1)),
          A: r(a.i, "act=1", ea(b, !0), "suid=" + a.j),
        }
      : null;
  }
  function ka(a, b) {
    return b === 2 ? r(a.i, "ri=2") : b === 0 ? r(a.i, "ri=16") : a.i;
  }
  var la = class {
    constructor({ url: a, ta: b }) {
      this.i = a;
      this.m = b;
      this.j = new Date().getTime() - 17040672e5;
      this.h = {};
      for (var c = /[?&]([^&=]+)=([^&]*)/g; (b = c.exec(a)); )
        this.h[b[1]] = b[2];
    }
  }; /* 
 
 Copyright Google LLC 
 SPDX-License-Identifier: Apache-2.0 
*/
  var ma = class {
      constructor(a) {
        this.h = a;
      }
      toString() {
        return this.h;
      }
    },
    na = new ma("about:invalid#zClosurez");
  class oa {
    constructor(a) {
      this.sa = a;
    }
  }
  function t(a) {
    return new oa((b) => b.substr(0, a.length + 1).toLowerCase() === a + ":");
  }
  var pa = new oa((a) => /^[^:]*([/?#]|$)/.test(a)),
    qa = t("http"),
    ra = t("https"),
    sa = t("ftp"),
    ta = t("mailto"),
    ua = t("intent"),
    va = t("market"),
    wa = t("itms"),
    xa = t("itms-appss"),
    ya = [t("data"), qa, ra, ta, sa, pa];
  function za(a, b = ya) {
    if (a instanceof ma) return a;
    for (let c = 0; c < b.length; ++c) {
      let d = b[c];
      if (d instanceof oa && d.sa(a)) return new ma(a);
    }
  }
  function Aa(a, b = ya) {
    return za(a, b) || na;
  }
  var Ba = /^\s*(?!javascript:)(?:[\w+.-]+:|[^:/?#]*(?:[/?#]|$))/i;
  function Ca(a, b) {
    if (b instanceof ma)
      if (b instanceof ma) b = b.h;
      else throw Error("");
    else b = Ba.test(b) ? b : void 0;
    b !== void 0 && (a.href = b);
  }
  function Da(a, b) {
    Array.prototype.forEach.call(a, b, void 0);
  }
  function Ea(a, b) {
    a: {
      let c = a.length,
        d = typeof a === "string" ? a.split("") : a;
      for (let e = 0; e < c; e++)
        if (e in d && b.call(void 0, d[e], e, a)) {
          b = e;
          break a;
        }
      b = -1;
    }
    return b < 0 ? null : typeof a === "string" ? a.charAt(b) : a[b];
  }
  function Fa(a) {
    var b = a.length;
    if (b > 0) {
      let c = Array(b);
      for (let d = 0; d < b; d++) c[d] = a[d];
      return c;
    }
    return [];
  }
  function Ga(a, b) {
    a.__closure__error__context__984382 ||
      (a.__closure__error__context__984382 = {});
    a.__closure__error__context__984382.severity = b;
  }
  function Ha(a) {
    fetch(a, { keepalive: !0, mode: "no-cors", credentials: "include" });
  }
  function Ia(a) {
    n.setTimeout(() => {
      throw a;
    }, 0);
  }
  var Ja = aa(899588437, !1),
    Ka = aa(748402147, !0);
  function La(a) {
    var b;
    a: {
      if ((b = n.navigator)) if ((b = b.userAgent)) break a;
      b = "";
    }
    return b.indexOf(a) != -1;
  }
  function Ma() {
    return La("iPhone") && !La("iPod") && !La("iPad");
  }
  function Na(a) {
    Na[" "](a);
    return a;
  }
  Na[" "] = function () {};
  var Oa = Ma(),
    Pa = La("iPad");
  var Qa = Ma() || La("iPod"),
    Ra = La("iPad");
  var Sa = {},
    Ta = null;
  var Ua = void 0;
  function Xa(a) {
    a = Error(a);
    Ga(a, "warning");
    return a;
  }
  function Ya(a, b = !1) {
    return b && Symbol.for && a
      ? Symbol.for(a)
      : a != null
      ? Symbol(a)
      : Symbol();
  }
  var Za = Ya(),
    $a = Ya(),
    ab = Ya("m_m", !0);
  var u = Ya("jas", !0),
    bb,
    cb = [];
  cb[u] = 7;
  bb = Object.freeze(cb);
  function db(a) {
    a[u] |= 34;
    return a;
  }
  function eb(a) {
    a[u] |= 8192;
    return a;
  }
  function fb(a) {
    a[u] |= 32;
    return a;
  }
  function gb(a, b) {
    2 & b && (a |= 2);
    return a | 1;
  }
  var ib = {};
  function w(a, b) {
    return b === void 0
      ? a.h !== jb && !!(2 & (a.l[u] | 0))
      : !!(2 & b) && a.h !== jb;
  }
  var jb = {};
  class kb {
    constructor(a, b, c) {
      this.h = a;
      this.i = b;
      this.j = c;
    }
    next() {
      var a = this.h.next();
      a.done || (a.value = this.i.call(this.j, a.value));
      return a;
    }
    [Symbol.iterator]() {
      return this;
    }
  }
  Object.freeze({});
  function lb(a) {
    a.Ja = !0;
    return a;
  }
  var nb = lb((a) => typeof a === "number"),
    ob = lb((a) => typeof a === "string"),
    pb = lb((a) => typeof a === "function");
  function qb(a) {
    if (ob(a)) {
      if (!/^\s*(?:-?[1-9]\d*|0)?\s*$/.test(a)) throw Error(String(a));
    } else if (nb(a) && !Number.isSafeInteger(a)) throw Error(String(a));
    return BigInt(a);
  }
  var tb = lb((a) => a >= rb && a <= sb),
    rb = BigInt(Number.MIN_SAFE_INTEGER),
    sb = BigInt(Number.MAX_SAFE_INTEGER);
  var ub = 0,
    vb = 0;
  function wb(a) {
    var b = a >>> 0;
    ub = b;
    vb = ((a - b) / 4294967296) >>> 0;
  }
  function xb(a) {
    if (a < 0) {
      wb(0 - a);
      a = ub;
      var b = vb;
      b = ~b;
      a ? (a = ~a + 1) : (b += 1);
      let [c, d] = [a, b];
      ub = c >>> 0;
      vb = d >>> 0;
    } else wb(a);
  }
  function yb(a, b) {
    b >>>= 0;
    a >>>= 0;
    var c;
    b <= 2097151
      ? (c = "" + (4294967296 * b + a))
      : (c = "" + ((BigInt(b) << BigInt(32)) | BigInt(a)));
    return c;
  }
  var zb = typeof BigInt === "function" ? BigInt.asIntN : void 0,
    Bb = Number.isSafeInteger,
    x = Number.isFinite,
    Cb = Math.trunc,
    Db = /^-?([1-9][0-9]*|0)(\.[0-9]+)?$/;
  function Eb(a) {
    switch (typeof a) {
      case "bigint":
        return !0;
      case "number":
        return x(a);
      case "string":
        return Db.test(a);
      default:
        return !1;
    }
  }
  function Fb(a) {
    if (!x(a)) throw Xa("enum");
    return a | 0;
  }
  function Gb(a) {
    return a == null ? a : x(a) ? a | 0 : void 0;
  }
  function Hb(a) {
    if (typeof a !== "number") throw Xa("int32");
    if (!x(a)) throw Xa("int32");
    return a | 0;
  }
  function Ib(a) {
    if (a == null) return a;
    if (typeof a === "string" && a) a = +a;
    else if (typeof a !== "number") return;
    return x(a) ? a | 0 : void 0;
  }
  function Jb(a) {
    if (typeof a !== "number") throw Xa("uint32");
    if (!x(a)) throw Xa("uint32");
    return a >>> 0;
  }
  function Kb(a) {
    if (a == null) return a;
    if (typeof a === "string" && a) a = +a;
    else if (typeof a !== "number") return;
    return x(a) ? a >>> 0 : void 0;
  }
  function Lb(a) {
    if (!Eb(a)) throw Xa("int64");
    switch (typeof a) {
      case "string":
        var b = a;
        a = Cb(Number(b));
        Bb(a)
          ? (b = qb(a))
          : ((a = b.indexOf(".")),
            a !== -1 && (b = b.substring(0, a)),
            (b = qb(zb(64, BigInt(b)))));
        return b;
      case "bigint":
        return qb(zb(64, a));
      default:
        if (Bb(a)) b = a;
        else if (((a = Cb(a)), Bb(a))) b = String(a);
        else {
          xb(a);
          a = ub;
          var c = vb;
          c & 2147483648
            ? (b = "" + ((BigInt(c | 0) << BigInt(32)) | BigInt(a >>> 0)))
            : (b = yb(a, c));
        }
        return qb(b);
    }
    b = Cb(a);
    if (!Bb(b)) {
      xb(b);
      a = ub;
      c = vb;
      if ((b = c & 2147483648))
        (a = (~a + 1) >>> 0), (c = ~c >>> 0), a == 0 && (c = (c + 1) >>> 0);
      let d = c * 4294967296 + (a >>> 0);
      a = Number.isSafeInteger(d) ? d : yb(a, c);
      b = typeof a === "number" ? (b ? -a : a) : b ? "-" + a : a;
    }
    return b;
  }
  function y(a) {
    return a == null || typeof a === "string" ? a : void 0;
  }
  function Mb(a, b, c, d) {
    if (a != null && a[ab] === ib) return a;
    if (!Array.isArray(a))
      return (
        c
          ? d & 2
            ? ((a = b[Za]) || ((a = new b()), db(a.l), (a = b[Za] = a)),
              (b = a))
            : (b = new b())
          : (b = void 0),
        b
      );
    c = a[u] | 0;
    d = c | (d & 32) | (d & 2);
    d !== c && (a[u] = d);
    return new b(a);
  }
  function Nb(a, b, c) {
    a = b ? Hb(a) : Ib(a);
    return a == null ? (c ? 0 : void 0) : a | 0;
  }
  function B(a, b, c) {
    if (b) {
      if (typeof a !== "string") throw Error();
    } else a = y(a) ?? (c ? "" : void 0);
    return a;
  }
  function Ob(a) {
    return a;
  }
  var Pb = {},
    Qb = (() =>
      class extends Map {
        constructor() {
          super();
        }
      })();
  function Rb(a) {
    return a;
  }
  function Sb(a) {
    if (a.v & 2) throw Error("Cannot mutate an immutable Map");
  }
  var D = class extends Qb {
    constructor(a, b, c = Rb, d = Rb) {
      super();
      this.v = a[u] | 0;
      this.u = b;
      this.D = c;
      this.ia = this.u ? Tb : d;
      for (let e = 0; e < a.length; e++) {
        let f = a[e],
          g = c(f[0], !1, !0),
          k = f[1];
        b
          ? k === void 0 && (k = null)
          : (k = d(f[1], !1, !0, void 0, void 0, this.v));
        super.set(g, k);
      }
    }
    M(a) {
      return eb(Array.from(super.entries(), a));
    }
    clear() {
      Sb(this);
      super.clear();
    }
    delete(a) {
      Sb(this);
      return super.delete(this.D(a, !0, !1));
    }
    entries() {
      if (this.u) {
        var a = super.keys();
        a = new kb(a, Ub, this);
      } else a = super.entries();
      return a;
    }
    values() {
      if (this.u) {
        var a = super.keys();
        a = new kb(a, D.prototype.get, this);
      } else a = super.values();
      return a;
    }
    forEach(a, b) {
      this.u
        ? super.forEach((c, d, e) => {
            a.call(b, e.get(d), d, e);
          })
        : super.forEach(a, b);
    }
    set(a, b) {
      Sb(this);
      a = this.D(a, !0, !1);
      return a == null
        ? this
        : b == null
        ? (super.delete(a), this)
        : super.set(a, this.ia(b, !0, !0, this.u, !1, this.v));
    }
    has(a) {
      return super.has(this.D(a, !1, !1));
    }
    get(a) {
      a = this.D(a, !1, !1);
      var b = super.get(a);
      if (b !== void 0) {
        var c = this.u;
        return c
          ? ((c = this.ia(b, !1, !0, c, this.ra, this.v)),
            c !== b && super.set(a, c),
            c)
          : b;
      }
    }
    [Symbol.iterator]() {
      return this.entries();
    }
  };
  D.prototype.toJSON = void 0;
  function Tb(a, b, c, d, e, f) {
    a = Mb(a, d, c, f);
    e && (a = Vb(a));
    return a;
  }
  function Ub(a) {
    return [a, this.get(a)];
  }
  var Wb;
  function Xb() {
    return Wb || (Wb = new D(db([]), void 0, void 0, void 0, Pb));
  }
  function Yb(a, b, c, d) {
    var e = d !== void 0;
    d = !!d;
    var f = [],
      g = a.length,
      k = 4294967295,
      h = !1,
      l = !!(b & 64),
      m = l ? (b & 128 ? 0 : -1) : void 0;
    if (!(b & 1)) {
      var p = g && a[g - 1];
      p != null && typeof p === "object" && p.constructor === Object
        ? (g--, (k = g))
        : (p = void 0);
      !l ||
        b & 128 ||
        e ||
        ((h = !0), (k = (Zb ?? Ob)(k - m, m, a, p, void 0) + m));
    }
    b = void 0;
    for (e = 0; e < g; e++) {
      let q = a[e];
      if (q != null && (q = c(q, d)) != null)
        if (l && e >= k) {
          let v = e - m;
          (b ?? (b = {}))[v] = q;
        } else f[e] = q;
    }
    if (p)
      for (let q in p) {
        a = p[q];
        if (a == null || (a = c(a, d)) == null) continue;
        g = +q;
        let v;
        l && !Number.isNaN(g) && (v = g + m) < k
          ? (f[v] = a)
          : ((b ?? (b = {}))[q] = a);
      }
    b && (h ? f.push(b) : (f[k] = b));
    return f;
  }
  function $b(a) {
    a[0] = ac(a[0]);
    a[1] = ac(a[1]);
    return a;
  }
  function ac(a) {
    switch (typeof a) {
      case "number":
        return Number.isFinite(a) ? a : "" + a;
      case "bigint":
        return tb(a) ? Number(a) : "" + a;
      case "boolean":
        return a ? 1 : 0;
      case "object":
        if (Array.isArray(a)) {
          let b = a[u] | 0;
          return a.length === 0 && b & 1 ? void 0 : Yb(a, b, ac);
        }
        if (a != null && a[ab] === ib) return bc(a);
        if (a instanceof D) return (a = a.size !== 0 ? a.M($b) : void 0), a;
        return;
    }
    return a;
  }
  var Zb;
  function bc(a) {
    a = a.l;
    return Yb(a, a[u] | 0, ac);
  }
  function cc(a, b, c, d = 0) {
    if (a == null) {
      var e = 32;
      c ? ((a = [c]), (e |= 128)) : (a = []);
      b && (e = (e & -16760833) | ((b & 1023) << 14));
    } else {
      if (!Array.isArray(a)) throw Error("narr");
      e = a[u] | 0;
      if (Ka && 1 & e) throw Error("rfarr");
      2048 & e && !(2 & e) && dc();
      if (e & 256) throw Error("farr");
      if (e & 64) return (e | d) !== e && (a[u] = e | d), a;
      if (c && ((e |= 128), c !== a[0])) throw Error("mid");
      a: {
        c = a;
        e |= 64;
        var f = c.length;
        if (f) {
          var g = f - 1;
          let h = c[g];
          if (h != null && typeof h === "object" && h.constructor === Object) {
            b = e & 128 ? 0 : -1;
            g -= b;
            if (g >= 1024) throw Error("pvtlmt");
            for (var k in h)
              if (((f = +k), f < g)) (c[f + b] = h[k]), delete h[k];
              else break;
            e = (e & -16760833) | ((g & 1023) << 14);
            break a;
          }
        }
        if (b) {
          k = Math.max(b, f - (e & 128 ? 0 : -1));
          if (k > 1024) throw Error("spvt");
          e = (e & -16760833) | ((k & 1023) << 14);
        }
      }
    }
    a[u] = e | 64 | d;
    return a;
  }
  function dc() {
    if (Ka) throw Error("carr");
    if ($a != null) {
      var a = Ua ?? (Ua = {});
      var b = a[$a] || 0;
      b >= 5 || ((a[$a] = b + 1), (a = Error()), Ga(a, "incident"), Ia(a));
    }
  }
  function ec(a, b) {
    if (typeof a !== "object") return a;
    if (Array.isArray(a)) {
      var c = a[u] | 0;
      return a.length === 0 && c & 1 ? void 0 : fc(a, c, b);
    }
    if (a != null && a[ab] === ib) return hc(a);
    if (a instanceof D) {
      c = a.v;
      if (c & 2) return a;
      if (a.size) {
        b = db(a.M());
        if (a.u)
          for (a = 0; a < b.length; a++) {
            let d = b[a],
              e = d[1];
            e == null || typeof e !== "object"
              ? (e = void 0)
              : e != null && e[ab] === ib
              ? (e = hc(e))
              : Array.isArray(e)
              ? (e = fc(e, e[u] | 0, !!(c & 32)))
              : (e = void 0);
            d[1] = e;
          }
        return b;
      }
    }
  }
  function fc(a, b, c) {
    if (b & 2) return a;
    !c || 4096 & b || 16 & b
      ? (a = ic(a, b, !1, c && !(b & 16)))
      : ((a[u] |= 34), b & 4 && Object.freeze(a));
    return a;
  }
  function jc(a, b, c) {
    a = new a.constructor(b);
    c && (a.h = jb);
    a.o = jb;
    return a;
  }
  function hc(a) {
    var b = a.l,
      c = b[u] | 0;
    return w(a, c) ? a : kc(a, b, c) ? jc(a, b) : ic(b, c);
  }
  function lc(a) {
    var b = a.l,
      c = b[u] | 0;
    return kc(a, b, c) ? jc(a, b, !0) : new a.constructor(ic(b, c, !1));
  }
  function ic(a, b, c, d) {
    d ?? (d = !!(34 & b));
    a = Yb(a, b, ec, d);
    d = 32;
    c && (d |= 2);
    b = (b & 16769217) | d;
    a[u] = b;
    return a;
  }
  function Vb(a) {
    var b = a.l,
      c = b[u] | 0;
    return w(a, c)
      ? kc(a, b, c)
        ? jc(a, b, !0)
        : new a.constructor(ic(b, c, !1))
      : a;
  }
  function mc(a) {
    if (a.h !== jb) return !1;
    var b = a.l;
    b = ic(b, b[u] | 0);
    b[u] |= 2048;
    a.l = b;
    a.h = void 0;
    a.o = void 0;
    return !0;
  }
  function nc(a) {
    if (!mc(a) && w(a, a.l[u] | 0)) throw Error();
  }
  function oc(a, b) {
    b === void 0 && (b = a[u] | 0);
    b & 32 && !(b & 4096) && (a[u] = b | 4096);
  }
  function kc(a, b, c) {
    return c & 2
      ? !0
      : c & 32 && !(c & 4096)
      ? ((b[u] = c | 2), (a.h = jb), !0)
      : !1;
  }
  function E(a, b) {
    a = pc(a.l, b);
    if (a !== null) return a;
  }
  function qc(a, b, c) {
    return pc(a, b, void 0, c);
  }
  function pc(a, b, c, d) {
    if (b === -1) return null;
    var e = b + (c ? 0 : -1),
      f = a.length - 1;
    if (!(f < 1 + (c ? 0 : -1))) {
      if (e >= f) {
        var g = a[f];
        if (g != null && typeof g === "object" && g.constructor === Object) {
          c = g[b];
          var k = !0;
        } else if (e === f) c = g;
        else return;
      } else c = a[e];
      if (d && c != null) {
        d = d(c);
        if (d == null) return d;
        if (!Object.is(d, c)) return k ? (g[b] = d) : (a[e] = d), d;
      }
      return c;
    }
  }
  function F(a, b, c) {
    nc(a);
    var d = a.l;
    G(d, d[u] | 0, b, c);
    return a;
  }
  function G(a, b, c, d) {
    var e = c + -1,
      f = a.length - 1;
    if (f >= 0 && e >= f) {
      let g = a[f];
      if (g != null && typeof g === "object" && g.constructor === Object)
        return (g[c] = d), b;
    }
    if (e <= f) return (a[e] = d), b;
    d !== void 0 &&
      ((f = ((b ?? (b = a[u] | 0)) >> 14) & 1023 || 536870912),
      c >= f ? d != null && (a[f + -1] = { [c]: d }) : (a[e] = d));
    return b;
  }
  function H(a, b) {
    a = pc(a.l, b);
    return (a != null && a[ab] === ib) || Array.isArray(a);
  }
  function rc(a, b, c, d, e) {
    var f = a.l,
      g = f[u] | 0;
    d = d && d !== 4 ? (d !== 1 && (a ? w(a, g) : 2 & g) ? 1 : d) : 4;
    e = !!e || d === 3;
    d === 2 && mc(a) && ((f = a.l), (g = f[u] | 0));
    a = sc(f, b);
    var k = a === bb ? 7 : a[u] | 0,
      h = gb(k, g),
      l = !(4 & h);
    if (l) {
      let m = 0,
        p = 0;
      for (; m < a.length; m++) {
        let q = c(a[m]);
        q != null && (a[p++] = q);
      }
      p < m && (a.length = p);
      c = (h | 4) & -513;
      h = c &= -1025;
      h &= -4097;
    }
    h !== k && ((a[u] = h), 2 & h && Object.freeze(a));
    return (a = tc(a, h, f, g, b, d, l, e));
  }
  function tc(a, b, c, d, e, f, g, k) {
    var h = b,
      l = uc(b);
    l &&
      f === 2 &&
      ((a = [...a]), (h = 0), (b = vc(b, d)), (d = G(c, d, e, a)), (l = !1));
    l ||
      (f === 1 || (f !== 4 ? 0 : 2 & b || (!(16 & b) && 32 & d))
        ? ((b |=
            !a.length || (g && !(4096 & b)) || (32 & d && !(4096 & b || 16 & b))
              ? 2
              : 256),
          b !== h && (a[u] = b),
          Object.freeze(a))
        : (k || (b |= 16), b !== h && (a[u] = b)));
    2 & b || !(4096 & b || 16 & b) || oc(c, d);
    return a;
  }
  function sc(a, b) {
    a = pc(a, b);
    return Array.isArray(a) ? a : bb;
  }
  function uc(a) {
    return (!!(2 & a) && !!(4 & a)) || !!(256 & a);
  }
  function J(a, b, c, d, e) {
    var f = a.l,
      g = f[u] | 0;
    var k = w(a, g);
    a: {
      !k && mc(a) && ((f = a.l), (g = f[u] | 0));
      var h = pc(f, b);
      a = !1;
      if (h == null) {
        if (k) {
          b = Xb();
          break a;
        }
        h = [];
      } else if (h.constructor === D)
        if (h.v & 2 && !k) h = h.M();
        else {
          b = h;
          break a;
        }
      else Array.isArray(h) ? (a = !!((h[u] | 0) & 2)) : (h = []);
      if (k) {
        if (!h.length) {
          b = Xb();
          break a;
        }
        a || ((a = !0), db(h));
      } else if (a) {
        a = !1;
        eb(h);
        h = [...h];
        for (let l = 0; l < h.length; l++) {
          let m = (h[l] = [...h[l]]);
          Array.isArray(m[1]) && (m[1] = db(m[1]));
        }
        h = eb(h);
      }
      !a && g & 32 && fb(h);
      d = new D(h, c, d, e);
      g = G(f, g, b, d);
      a || oc(f, g);
      b = d;
    }
    !k && c && (b.ra = !0);
    return b;
  }
  function wc(a, b, c, d) {
    var e = !1;
    d = qc(a, d, (f) => {
      var g = Mb(f, c, !1, b);
      e = g !== f && g != null;
      return g;
    });
    if (d != null) return e && !w(d) && oc(a, b), d;
  }
  function M(a, b, c) {
    var d = a.l,
      e = d[u] | 0;
    b = wc(d, e, b, c);
    if (b == null) return b;
    e = d[u] | 0;
    if (!w(a, e)) {
      let f = Vb(b);
      f !== b &&
        (mc(a) && ((d = a.l), (e = d[u] | 0)),
        (b = f),
        (e = G(d, e, c, b)),
        oc(d, e));
    }
    return b;
  }
  function vc(a, b) {
    return (a = (2 & b ? a | 2 : a & -3) & -273);
  }
  function N(a, b) {
    a = E(a, b);
    return (
      (a == null || typeof a === "boolean"
        ? a
        : typeof a === "number"
        ? !!a
        : void 0) ?? !1
    );
  }
  function O(a, b) {
    return y(E(a, b)) ?? "";
  }
  function Q(a, b, c = 0) {
    return Gb(E(a, b)) ?? c;
  }
  function R(a, b, c) {
    if (c != null && typeof c !== "boolean")
      throw Error(`Expected boolean but got ${ba(c)}: ${c}`);
    return F(a, b, c);
  }
  function S(a, b, c) {
    F(a, b, c == null ? c : Hb(c));
  }
  function T(a, b, c) {
    if (c != null && typeof c !== "string") throw Error();
    return F(a, b, c);
  }
  function xc(a, b, c) {
    F(a, b, c == null ? c : Fb(c));
  }
  function yc(a) {
    return JSON.stringify(bc(a));
  }
  var U = class {
    constructor(a) {
      this.l = cc(a, void 0, void 0, 2048);
    }
    toJSON() {
      return bc(this);
    }
  };
  U.prototype[ab] = ib;
  U.prototype.toString = function () {
    return this.l.toString();
  };
  var zc = class extends U {};
  var Ac = class extends U {};
  var Bc = class extends U {};
  var Cc = class extends U {};
  var Dc = class extends U {
    i() {
      return N(this, 1);
    }
    j() {
      return N(this, 2);
    }
    m() {
      return N(this, 7);
    }
  };
  var Ec = class extends U {
    C() {
      return O(this, 3);
    }
    ga(a) {
      R(this, 5, a);
    }
  };
  var Fc = class extends U {
    j() {
      return N(this, 1);
    }
    i() {
      return Kb(E(this, 2)) ?? 0;
    }
    m() {
      return Kb(E(this, 2)) != null;
    }
  };
  var Gc = class extends U {
    C() {
      return O(this, 1);
    }
    ga(a) {
      R(this, 2, a);
    }
  };
  var Hc = class extends U {};
  var Ic = class extends U {
    i() {
      return y(E(this, 1)) != null;
    }
  };
  function Jc(a) {
    var b = a.l,
      c = b;
    b = b[u] | 0;
    var d = !(a ? w(a, b) : 2 & b);
    d && a && mc(a) && ((c = a.l), (b = c[u] | 0));
    a = sc(c, 7);
    var e = a === bb ? 7 : a[u] | 0,
      f = gb(e, b),
      g = !(4 & f);
    if (g) {
      var k = a,
        h = b;
      let l = !!(2 & f);
      l && (h |= 2);
      let m = !l,
        p = !0,
        q = 0,
        v = 0;
      for (; q < k.length; q++) {
        let z = Mb(k[q], Ec, !1, h);
        if (z instanceof Ec) {
          if (!l) {
            let C = w(z);
            m && (m = !C);
            p && (p = C);
          }
          k[v++] = z;
        }
      }
      v < q && (k.length = v);
      f |= 4;
      f = p ? f & -4097 : f | 4096;
      f = m ? f | 8 : f & -9;
    }
    f !== e && ((a[u] = f), 2 & f && Object.freeze(a));
    if (d && !(8 & f || (!a.length && (2 & f || (!(16 & f) && 32 & b))))) {
      uc(f) && ((a = [...a]), (f = vc(f, b)), (b = G(c, b, 7, a)));
      d = a;
      e = f;
      for (k = 0; k < d.length; k++)
        (f = d[k]), (h = Vb(f)), f !== h && (d[k] = h);
      e |= 8;
      f = e = d.length ? e | 4096 : e & -4097;
      a[u] = f;
    }
    return (a = tc(a, f, c, b, 7, 4, g, !1));
  }
  function Kc(a, b) {
    F(a, 28, b == null ? b : Jb(b));
  }
  var Lc = class extends U {
    i() {
      return M(this, Ic, 26);
    }
    ea() {
      return N(this, 21);
    }
    j() {
      return H(this, 29);
    }
  };
  var Mc = class extends U {};
  var Nc = (function (a) {
    return (b) => {
      if (b == null || b == "") b = new a();
      else {
        b = JSON.parse(b);
        if (!Array.isArray(b)) throw Error("dnarr");
        b = new a(fb(b));
      }
      return b;
    };
  })(class extends U {});
  var Oc = class extends U {};
  function Pc(a, b) {
    if (a)
      for (let c in a)
        Object.prototype.hasOwnProperty.call(a, c) && b(a[c], c, a);
  }
  function Qc(a) {
    var b = !1,
      c;
    return function () {
      b || ((c = a()), (b = !0));
      return c;
    };
  }
  function Rc(a = document) {
    return a.createElement("img");
  }
  var Sc = [];
  function Tc() {
    var a = Sc;
    Sc = [];
    for (let b of a)
      try {
        b();
      } catch {}
  }
  function Uc(a) {
    Sc.push(a);
    Sc.length === 1 &&
      (window.Promise
        ? Promise.resolve().then(Tc)
        : ((a = window.setImmediate), pb(a) ? a(Tc) : setTimeout(Tc, 0)));
  }
  function Vc(a, b) {
    for (let c in a) b.call(void 0, a[c], c, a);
  }
  function Zc(a) {
    var b = [],
      c = 0;
    for (let d in a) b[c++] = a[d];
    return b;
  }
  function $c(a, b) {
    Vc(b, function (c, d) {
      d == "style"
        ? (a.style.cssText = c)
        : d == "class"
        ? (a.className = c)
        : d == "for"
        ? (a.htmlFor = c)
        : ad.hasOwnProperty(d)
        ? a.setAttribute(ad[d], c)
        : d.lastIndexOf("aria-", 0) == 0 || d.lastIndexOf("data-", 0) == 0
        ? a.setAttribute(d, c)
        : (a[d] = c);
    });
  }
  var ad = {
    cellpadding: "cellPadding",
    cellspacing: "cellSpacing",
    colspan: "colSpan",
    frameborder: "frameBorder",
    height: "height",
    maxlength: "maxLength",
    nonce: "nonce",
    role: "role",
    rowspan: "rowSpan",
    type: "type",
    usemap: "useMap",
    valign: "vAlign",
    width: "width",
  };
  function bd(a, b, c) {
    var d = arguments,
      e = document,
      f = d[1];
    var g = String(d[0]);
    g = String(g);
    e.contentType === "application/xhtml+xml" && (g = g.toLowerCase());
    g = e.createElement(g);
    f &&
      (typeof f === "string"
        ? (g.className = f)
        : Array.isArray(f)
        ? (g.className = f.join(" "))
        : $c(g, f));
    d.length > 2 && cd(e, g, d);
    return g;
  }
  function cd(a, b, c) {
    function d(e) {
      e && b.appendChild(typeof e === "string" ? a.createTextNode(e) : e);
    }
    for (let e = 2; e < c.length; e++) {
      let f = c[e];
      !ca(f) || (da(f) && f.nodeType > 0)
        ? d(f)
        : Da(
            f && typeof f.length == "number" && typeof f.item == "function"
              ? Fa(f)
              : f,
            d
          );
    }
  }
  var dd = { capture: !0 },
    ed = { passive: !0 },
    fd = Qc(() => {
      var a = !1;
      try {
        let b = Object.defineProperty({}, "passive", {
          get() {
            a = !0;
          },
        });
        n.addEventListener("test", null, b);
      } catch (b) {}
      return a;
    });
  function gd(a) {
    return a ? (a.passive && fd() ? a : a.capture || !1) : !1;
  }
  function V(a, b, c, d) {
    typeof a.addEventListener === "function" && a.addEventListener(b, c, gd(d));
  }
  function hd(a) {
    var b = W;
    b.readyState === "complete" || b.readyState === "interactive"
      ? Uc(a)
      : b.addEventListener("DOMContentLoaded", a);
  }
  function id(a) {
    var b = window;
    b.document.readyState === "complete"
      ? Uc(a)
      : b.addEventListener("load", a);
  }
  function jd(a, b, c = null, d = !1) {
    kd(a, b, c, d);
  }
  function kd(a, b, c, d) {
    a.google_image_requests || (a.google_image_requests = []);
    var e = Rc(a.document);
    if (c || d) {
      let f = (g) => {
        c && c(g);
        if (d) {
          g = a.google_image_requests;
          let k = Array.prototype.indexOf.call(g, e, void 0);
          k >= 0 && Array.prototype.splice.call(g, k, 1);
        }
        typeof e.removeEventListener === "function" &&
          e.removeEventListener("load", f, gd());
        typeof e.removeEventListener === "function" &&
          e.removeEventListener("error", f, gd());
      };
      V(e, "load", f);
      V(e, "error", f);
    }
    e.src = b;
    a.google_image_requests.push(e);
  }
  function X(a, b) {
    var c;
    if ((c = a.navigator))
      (c = a.navigator.userAgent), (c = !(!/Chrome/.test(c) || /Edge/.test(c)));
    c && typeof a.navigator.sendBeacon === "function"
      ? a.navigator.sendBeacon(b)
      : jd(a, b, void 0, !1);
  }
  function ld({ ha: a = !1 } = {}) {
    return a
      ? "connect.pagead2.googlesyndication.com"
      : "pagead2.googlesyndication.com";
  }
  var md = 0;
  function nd() {
    var a = od(md, document.currentScript);
    a && (a.dataset.initialized = "true");
  }
  function pd(a) {
    return (
      ((a = od(a, document.currentScript)) &&
        a.getAttribute("data-jc-version")) ||
      "unknown"
    );
  }
  function od(a, b = null) {
    return b && b.getAttribute("data-jc") === String(a)
      ? b
      : document.querySelector(`[data-jc="${a}"]`);
  }
  function qd(a) {
    if (!(Math.random() > 0.01)) {
      let b = od(a, document.currentScript);
      a = `https://${
        b && b.getAttribute("data-jc-rcd") === "true"
          ? "pagead2.googlesyndication-cn.com"
          : "pagead2.googlesyndication.com"
      }/pagead/gen_204?id=jca&jc=${a}&version=${pd(a)}&sample=0.01`;
      X(window, a);
    }
  }
  var rd = class {
    constructor(a, b) {
      this.error = a;
      this.meta = {};
      this.context = b.context;
      this.msg = b.message || "";
      this.id = b.id || "jserror";
    }
  };
  function sd(a) {
    var b = a.toString();
    a.name && b.indexOf(a.name) == -1 && (b += ": " + a.name);
    a.message && b.indexOf(a.message) == -1 && (b += ": " + a.message);
    if (a.stack)
      a: {
        a = a.stack;
        var c = b;
        try {
          a.indexOf(c) == -1 && (a = c + "\n" + a);
          let d;
          for (; a != d; )
            (d = a),
              (a = a.replace(
                RegExp("((https?:/..*/)[^/:]*:\\d+(?:.|\n)*)\\2"),
                "$1"
              ));
          b = a.replace(RegExp("\n *", "g"), "\n");
          break a;
        } catch (d) {
          b = c;
          break a;
        }
        b = void 0;
      }
    return b;
  }
  var td = RegExp("^https?://(\\w|-)+\\.cdn\\.ampproject\\.(net|org)(\\?|/|$)"),
    ud = class {
      constructor(a, b) {
        this.h = a;
        this.i = b;
      }
    },
    vd = class {
      constructor(a, b) {
        this.url = a;
        this.h = !!b;
        this.depth = null;
      }
    };
  var wd = null;
  function xd() {
    var a = n.performance;
    return a && a.now && a.timing
      ? Math.floor(a.now() + a.timing.navigationStart)
      : Date.now();
  }
  function yd() {
    var a = n.performance;
    return a && a.now ? a.now() : null;
  }
  var zd = class {
    constructor(a, b) {
      var c = yd() || xd();
      this.label = a;
      this.type = b;
      this.value = c;
      this.duration = 0;
      this.taskId = this.slotId = void 0;
      this.uniqueId = Math.random();
    }
  };
  var Y = n.performance,
    Ad = !!(Y && Y.mark && Y.measure && Y.clearMarks),
    Bd = Qc(() => {
      var a;
      if ((a = Ad)) {
        var b;
        a = window;
        if (wd === null) {
          wd = "";
          try {
            let c = "";
            try {
              c = a.top.location.hash;
            } catch (d) {
              c = a.location.hash;
            }
            c && (wd = (b = c.match(/\bdeid=([\d,]+)/)) ? b[1] : "");
          } catch (c) {}
        }
        b = wd;
        a = !!b.indexOf && b.indexOf("1337") >= 0;
      }
      return a;
    });
  function Cd(a) {
    a &&
      Y &&
      Bd() &&
      (Y.clearMarks(`goog_${a.label}_${a.uniqueId}_start`),
      Y.clearMarks(`goog_${a.label}_${a.uniqueId}_end`));
  }
  function Dd(a, b) {
    var c = {};
    c[a] = b;
    return [c];
  }
  function Ed(a, b, c, d, e) {
    var f = [];
    Pc(a, (g, k) => {
      (g = Fd(g, b, c, d, e)) && f.push(`${encodeURIComponent(k)}=${g}`);
    });
    return f.join(b);
  }
  function Fd(a, b, c, d, e) {
    if (a == null) return "";
    b = b || "&";
    c = c || ",$";
    ob(c) && (c = c.split(""));
    if (a instanceof Array) {
      if ((d || (d = 0), d < c.length)) {
        let f = [];
        for (let g = 0; g < a.length; g++) f.push(Fd(a[g], b, c, d + 1, e));
        return f.join(c[d]);
      }
    } else if (typeof a === "object")
      return (
        e || (e = 0), e < 2 ? encodeURIComponent(Ed(a, b, c, d, e + 1)) : "..."
      );
    return encodeURIComponent(String(a));
  }
  function Gd(a) {
    var b = 1;
    for (let c in a.i) c.length > b && (b = c.length);
    return 3997 - b - a.j.length - 1;
  }
  function Hd(a, b) {
    var c = Gd(a) - b.length;
    if (c < 0) return "";
    b = "";
    a.h.sort((f, g) => f - g);
    var d = null,
      e = "";
    for (let f = 0; f < a.h.length; f++) {
      let g = a.h[f],
        k = a.i[g];
      for (let h = 0; h < k.length; h++) {
        if (!c) {
          d = d == null ? g : d;
          break;
        }
        let l = Ed(k[h], a.j, ",$");
        if (l) {
          l = e + l;
          if (c >= l.length) {
            c -= l.length;
            b += l;
            e = a.j;
            break;
          }
          d = d == null ? g : d;
        }
      }
    }
    a = "";
    d != null && (a = `${e}trn=${d}`);
    return b + a;
  }
  function Id(a, b, c, d) {
    return Gd(a) - d.length < 0 ? "" : b + "//" + c + d + Hd(a, d);
  }
  var Jd = class {
    constructor() {
      this.j = "&";
      this.i = {};
      this.m = 0;
      this.h = [];
    }
  };
  var Kd = RegExp(
    "^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$"
  );
  function Ld(a, b) {
    if (!b) return a;
    var c = a.indexOf("#");
    c < 0 && (c = a.length);
    var d = a.indexOf("?");
    if (d < 0 || d > c) {
      d = c;
      var e = "";
    } else e = a.substring(d + 1, c);
    a = [a.slice(0, d), e, a.slice(c)];
    c = a[1];
    a[1] = b ? (c ? c + "&" + b : b) : c;
    return a[0] + (a[1] ? "?" + a[1] : "") + a[2];
  }
  function Md(a, b, c) {
    if (Array.isArray(b))
      for (let d = 0; d < b.length; d++) Md(a, String(b[d]), c);
    else
      b != null &&
        c.push(a + (b === "" ? "" : "=" + encodeURIComponent(String(b))));
  }
  function Nd(a, b, c, d) {
    for (var e = c.length; (b = a.indexOf(c, b)) >= 0 && b < d; ) {
      var f = a.charCodeAt(b - 1);
      if (f == 38 || f == 63)
        if (((f = a.charCodeAt(b + e)), !f || f == 61 || f == 38 || f == 35))
          return b;
      b += e + 1;
    }
    return -1;
  }
  var Od = /#|$/;
  function Pd(a, b) {
    var c = a.search(Od),
      d = Nd(a, 0, b, c);
    if (d < 0) return null;
    var e = a.indexOf("&", d);
    if (e < 0 || e > c) e = c;
    d += b.length + 1;
    return decodeURIComponent(a.slice(d, e !== -1 ? e : 0).replace(/\+/g, " "));
  }
  var Qd = /[?&]($|#)/;
  function Rd(a, b) {
    for (var c = a.search(Od), d = 0, e, f = []; (e = Nd(a, d, b, c)) >= 0; )
      f.push(a.substring(d, e)), (d = Math.min(a.indexOf("&", e) + 1 || c, c));
    f.push(a.slice(d));
    return f.join("").replace(Qd, "$1");
  }
  function Sd(a, b) {
    a = Rd(a, "label");
    b = b != null ? "=" + encodeURIComponent(String(b)) : "";
    return Ld(a, "label" + b);
  }
  function Td(a, b, c) {
    try {
      if (a.h && a.h.h) {
        var d = a.h.start(b.toString(), 3);
        var e = c();
        a.h.end(d);
      } else e = c();
    } catch (f) {
      c = !0;
      try {
        Cd(d), (c = a.o(b, new rd(f, { message: sd(f) }), void 0, void 0));
      } catch (g) {
        a.m(217, g);
      }
      if (c) window.console?.error?.(f);
      else throw f;
    }
    return e;
  }
  function Ud(a, b) {
    var c = Vd;
    return (...d) => Td(c, a, () => b.apply(void 0, d));
  }
  var Yd = class {
    constructor(a = null) {
      this.pinger = Wd;
      this.h = a;
      this.i = null;
      this.j = !1;
      this.o = this.m;
    }
    m(a, b, c, d, e) {
      e = e || "jserror";
      var f = void 0;
      try {
        let P = new Jd();
        var g = P;
        g.h.push(1);
        g.i[1] = Dd("context", a);
        (b.error && b.meta && b.id) || (b = new rd(b, { message: sd(b) }));
        g = b;
        if (g.msg) {
          b = P;
          var k = g.msg.substring(0, 512);
          b.h.push(2);
          b.i[2] = Dd("msg", k);
        }
        var h = g.meta || {};
        k = h;
        if (this.i)
          try {
            this.i(k);
          } catch (K) {}
        if (d)
          try {
            d(k);
          } catch (K) {}
        d = P;
        h = [h];
        d.h.push(3);
        d.i[3] = h;
        var l;
        if (!(l = v)) {
          d = n;
          h = [];
          let K;
          k = null;
          do {
            var m = d;
            try {
              var p;
              if ((p = !!m && m.location.href != null))
                b: {
                  try {
                    Na(m.foo);
                    p = !0;
                    break b;
                  } catch (I) {}
                  p = !1;
                }
              var q = p;
            } catch {
              q = !1;
            }
            q
              ? ((K = m.location.href),
                (k = (m.document && m.document.referrer) || null))
              : ((K = k), (k = null));
            h.push(new vd(K || ""));
            try {
              d = m.parent;
            } catch (I) {
              d = null;
            }
          } while (d && m !== d);
          for (let I = 0, Wc = h.length - 1; I <= Wc; ++I) h[I].depth = Wc - I;
          m = n;
          if (
            m.location &&
            m.location.ancestorOrigins &&
            m.location.ancestorOrigins.length === h.length - 1
          )
            for (q = 1; q < h.length; ++q) {
              let I = h[q];
              I.url ||
                ((I.url = m.location.ancestorOrigins[q - 1] || ""), (I.h = !0));
            }
          l = h;
        }
        var v = l;
        let Va = new vd(n.location.href, !1);
        l = null;
        let Ab = v.length - 1;
        for (m = Ab; m >= 0; --m) {
          var z = v[m];
          !l && td.test(z.url) && (l = z);
          if (z.url && !z.h) {
            Va = z;
            break;
          }
        }
        z = null;
        let Be = v.length && v[Ab].url;
        Va.depth !== 0 && Be && (z = v[Ab]);
        f = new ud(Va, z);
        if (f.i) {
          v = P;
          var C = f.i.url || "";
          v.h.push(4);
          v.i[4] = Dd("top", C);
        }
        var A = { url: f.h.url || "" };
        if (f.h.url) {
          let K = f.h.url.match(Kd);
          var L = K[1],
            Wa = K[3],
            Xc = K[4];
          C = "";
          L && (C += L + ":");
          Wa && ((C += "//"), (C += Wa), Xc && (C += ":" + Xc));
          var Yc = C;
        } else Yc = "";
        L = P;
        A = [A, { url: Yc }];
        L.h.push(5);
        L.i[5] = A;
        Xd(this.pinger, e, P, this.j, c);
      } catch (P) {
        try {
          Xd(
            this.pinger,
            e,
            { context: "ecmserr", rctx: a, msg: sd(P), url: f?.h.url ?? "" },
            this.j,
            c
          );
        } catch (Va) {}
      }
      return !0;
    }
  };
  class Zd {}
  function Xd(a, b, c, d = !1, e) {
    if ((d ? a.i : Math.random()) < (e || a.m))
      try {
        let f;
        c instanceof Jd
          ? (f = c)
          : ((f = new Jd()),
            Pc(c, (k, h) => {
              var l = f,
                m = l.m++;
              k = Dd(h, k);
              l.h.push(m);
              l.i[m] = k;
            }));
        let g = Id(f, a.protocol, a.h(), a.path + b + "&");
        g && (a.j ? X(n, g) : jd(n, g));
      } catch (f) {}
  }
  function $d() {
    var a = Wd,
      b = window.google_srt;
    b >= 0 && b <= 1 && (a.i = b);
  }
  var ae = class {
    constructor(a, b, c, d = !1) {
      this.domain = a;
      this.path = b;
      this.m = c;
      this.j = d;
      this.protocol = "https:";
      this.i = Math.random();
    }
    h() {
      return this.domain;
    }
  };
  var be = [qa, ra, ta, sa, pa, va, wa, ua, xa];
  function ce(a, b) {
    if (a instanceof ma) return a;
    var c = Aa(a, be);
    c === na && b(a);
    return c;
  }
  function de(a) {
    var b = `https://${ld({ ha: ee })}/pagead/gen_204`;
    return (c) => {
      c = { id: "unsafeurl", ctx: a, url: c };
      var d = [];
      for (e in c) Md(e, c[e], d);
      var e = Ld(b, d.join("&"));
      navigator.sendBeacon && navigator.sendBeacon(e, "");
    };
  }
  var Wd,
    Vd,
    ee = !1;
  class fe extends ae {
    h() {
      return ee ? ld({ ha: !0 }) : super.h();
    }
  }
  var Z = new (class {
    constructor(a, b) {
      this.i = [];
      this.j = b || n;
      var c = null;
      b &&
        ((b.google_js_reporting_queue = b.google_js_reporting_queue || []),
        (this.i = b.google_js_reporting_queue),
        (c = b.google_measure_js_timing));
      this.h = Bd() || (c != null ? c : Math.random() < a);
    }
    start(a, b) {
      if (!this.h) return null;
      a = new zd(a, b);
      b = `goog_${a.label}_${a.uniqueId}_start`;
      Y && Bd() && Y.mark(b);
      return a;
    }
    end(a) {
      if (this.h && nb(a.value)) {
        a.duration = (yd() || xd()) - a.value;
        var b = `goog_${a.label}_${a.uniqueId}_end`;
        Y && Bd() && Y.mark(b);
        !this.h || this.i.length > 2048 || this.i.push(a);
      }
    }
  })(1, window);
  function ge() {
    window.google_measure_js_timing ||
      ((Z.h = !1),
      Z.i !== Z.j.google_js_reporting_queue &&
        (Bd() && Da(Z.i, Cd), (Z.i.length = 0)));
  }
  (function (a) {
    ee = !1;
    Wd =
      a ?? new fe("pagead2.googlesyndication.com", "/pagead/gen_204?id=", 0.01);
    typeof window.google_srt !== "number" &&
      (window.google_srt = Math.random());
    $d();
    Vd = new Yd(Z);
    Vd.i = (b) => {
      var c = md;
      c !== 0 && ((b.jc = String(c)), (b.shv = pd(c)));
    };
    Vd.j = !0;
    window.document.readyState === "complete"
      ? ge()
      : Z.h &&
        V(window, "load", () => {
          ge();
        });
  })();
  function he(a, b) {
    return Ud(a, b);
  }
  function ie(a, b) {
    var c = Zd;
    var d = "fa";
    (c.fa && c.hasOwnProperty(d)) || ((d = new c()), (c.fa = d));
    c = [];
    !b.eid && c.length && (b.eid = c.toString());
    Xd(Wd, a, b, !0);
  }
  function je(a = window) {
    return a;
  }
  var W = document,
    ke = window;
  var le = (a) => {
    var b = W;
    try {
      return b.querySelectorAll("*[" + a + "]");
    } catch (c) {
      return [];
    }
  };
  Zc({
    Ea: 0,
    Da: 1,
    Aa: 2,
    va: 3,
    Ba: 4,
    wa: 5,
    Ca: 6,
    ya: 7,
    za: 8,
    ua: 9,
    xa: 10,
    Fa: 11,
  }).map((a) => Number(a));
  Zc({ Ha: 0, Ia: 1, Ga: 2 }).map((a) => Number(a));
  function me(a) {
    var b = new ne();
    nc(b);
    b = rc(b, 1, Gb, 2, !0);
    if (Array.isArray(a)) {
      var c = a.length;
      for (let d = 0; d < c; d++) b.push(Fb(a[d]));
    } else for (c of a) b.push(Fb(c));
  }
  var ne = class extends U {};
  [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce(
    (a, b) => a + b
  );
  [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce((a, b) => a + b);
  [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce(
    (a, b) => a + b
  );
  [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce(
    (a, b) => a + b
  );
  [
    2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
    2, 2, 2, 2, 2, 2, 2,
  ].reduce((a, b) => a + b);
  [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce((a, b) => a + b);
  me([1, 8, 9, 10, 11, 12, 2, 3, 4, 5, 15, 16, 19, 20, 21, 23, 25]);
  me([1, 6, 7, 9, 10, 11, 12, 2, 22, 3, 4, 5, 13, 14, 18, 19, 20, 21, 23, 24]);
  me([
    1, 6, 7, 9, 10, 11, 12, 22, 26, 27, 2, 3, 4, 5, 13, 14, 17, 18, 19, 20, 21,
    23, 24,
  ]);
  new ne();
  var oe = class extends U {};
  var pe = (a, b) => {
      a = lc(a);
      a = bc(a);
      b = bc(b);
      var c = Math.max(a.length, b.length);
      for (let d = 0; d < c; ++d) a[d] == null && (a[d] = b[d]);
      return new Lc(a);
    },
    qe = (a, b) => {
      b = O(a, 2) || b;
      if (!b) return "";
      if (N(a, 13)) return b;
      var c = /[?&]adurl=([^&]+)/.exec(b);
      if (!c) return b;
      var d = [b.slice(0, c.index + 1)];
      J(a, 4, void 0, B, B).forEach((e, f) => {
        d.push(encodeURIComponent(f) + "=" + encodeURIComponent(e) + "&");
      });
      d.push(b.slice(c.index + 1));
      return N(a, 27)
        ? ((b = d.join("")),
          (a = J(a, 4, void 0, B, B).get("label")) && (b = Sd(b, a)),
          b)
        : d.join("");
    },
    re = (a, b, c) => {
      var d = J(b, 1, Lc, B);
      b = c.split(",");
      if (!b.every((e) => d.has(e)))
        return ie("gdn-asoch", { type: 1, data: c }), null;
      c = a || d.get(b[0]);
      a = a ? b : b.slice(1);
      for (let e of a)
        (a = d.get(e)),
          (c = pe(c, a)),
          Kc(c, ((Kb(E(c, 28)) ?? 0) || 0) | ((Kb(E(a, 28)) ?? 0) || 0));
      return c;
    },
    se = (a) => {
      var b = J(a, 4, void 0, B, B);
      Gb(E(a, 5)) != null && b.set("nb", Q(a, 5).toString());
      (Kb(E(a, 28)) ?? 0) && b.set("als", (Kb(E(a, 28)) ?? 0).toString());
    },
    te = (a, b = []) => {
      b = b.length > 0 ? b : le("data-asoch-targets");
      var c = [];
      for (let e = 0; e < b.length; ++e) {
        var d = b[e].getAttribute("data-asoch-targets");
        if ((d = re(null, a, d))) se(d), c.push({ element: b[e], data: d });
      }
      return c;
    },
    ve = (a, b, c, d) => {
      c = qe(b, c);
      if (c.length !== 0) {
        if (d === 609 && H(b, 24)) {
          var e = M(b, zc, 24);
          a.setAttribute("attributionDestination", O(e, 2));
          a.setAttribute("attributionSourceNonce", O(e, 1));
        }
        (e = (e = od(35)) && e.dataset.expanded ? e.dataset.expanded : null) &&
          d === 557 &&
          (c = ue(c, "expanded", e));
        Ca(a, ce(c, de(d)));
        a.target || (a.target = y(E(b, 11)) != null ? O(b, 11) : "_top");
      }
    },
    we = (a) => {
      for (let b of a)
        if (((a = b.data), b.element.tagName == "A" && !N(a, 1))) {
          let c = b.element;
          ve(c, a, c.href, 609);
        }
    },
    ue = (a, b, c) => {
      b = encodeURIComponent(b);
      var d = encodeURIComponent(c);
      c = new RegExp("[?&]" + b + "=([^&]+)");
      var e = c.exec(a);
      b = b + "=" + d;
      return e
        ? a.replace(c, e[0].charAt(0) + b)
        : a.replace("?", "?" + b + "&");
    },
    xe = (a) => {
      var b = n.oneAfmaInstance;
      if (b)
        for (var c of a)
          if ((a = c.data) && H(a, 8)) {
            var d = M(a, Hc, 8);
            if ((d = O(d, 4))) {
              c = b.fetchAppStoreOverlay;
              a = M(a, Hc, 8);
              c.call(b, d, void 0, O(a, 6));
              break;
            }
          }
    },
    ye = (a, b = 500) => {
      var c = [],
        d = [];
      for (var e of a)
        (a = e.data) &&
          H(a, 12) &&
          (d.push(M(a, Gc, 12)), c.push(M(a, Gc, 12).C()));
      e = (f, g) => {
        if (g) for (let k of d) g[k.C()] && k.ga(!0);
      };
      a = n.oneAfmaInstance;
      for (let f of c) a?.canOpenAndroidApp(f, e, () => {}, b);
    },
    Ce = (a, b, c, d, e, f) => {
      if (!d || !H(d, 8)) return !1;
      var g = M(d, Hc, 8),
        k = O(g, 2);
      J(d, 10, void 0, B, B).forEach((A, L) => {
        k = ue(k, L, A);
      });
      ze(d) &&
        N(d, 15) &&
        !/[?&]label=/.test(e) &&
        (e = Ae(e, "label", "deep_link_fallback"));
      b?.i() && (O(d, 9) ? ie("skspvc", { url: 1 }) : ie("skspvc", { url: 0 }));
      var h = O(d, 9),
        l = void 0,
        m = void 0,
        p = -1;
      if (b?.m() && h) {
        let A = Sd(h, "skspvc_triggered"),
          L = Sd(h, "skspvc_registered"),
          Wa = Sd(h, "skspvc_dismissed");
        l = () => {
          X(window, A);
          p = setTimeout(() => {
            X(window, L);
          }, 3e3);
        };
        m = () => {
          X(window, Wa);
          clearTimeout(p);
        };
      }
      var q = N(g, 7);
      ie("deeplink", {
        is_alleyoop_eligible: q ? "1" : "0",
        app_id: Pd(k, "id"),
      });
      var v = void 0;
      if (c && h && !a && q) {
        let A = Sd(h, "alleyoop_triggered");
        v = () => {
          X(window, A);
        };
      }
      var z = (A) => f.openStoreOverlay(A, l, m, O(g, 6)),
        C = (A) => f.openIntentOrNativeApp(A, !0, {}, v);
      b = f.redirectForStoreU2({
        clickUrl: e,
        trackingUrl: O(g, 3),
        finalUrl: k,
        pingFunc: N(d, 13) ? f.httpTrack : f.click,
        openFunc: b?.i() ? z : C,
        isExternalClickUrl: N(d, 13),
      });
      c && h && !a && !b && q && ((a = Sd(h, "alleyoop_failed")), X(window, a));
      return b;
    },
    De = (a, b, c, d, e = !1) => {
      c && c.startsWith("intent:")
        ? d.openIntentOrNativeApp(c)
        : e
        ? d.openWebApp(c, void 0, void 0, !0, !0)
        : (e = a?.j()) && a?.m() && !b
        ? d.openChromeCustomTab(c, { cct_init_h: String(a?.i()), cct_bp: "2" })
        : e
        ? b
          ? d.openBrowser(c)
          : d.openChromeCustomTab(c)
        : d.openSystemBrowser(c, {
            useFirstPackage: !0,
            useRunningProcess: !0,
          });
    },
    Fe = (a, b, c, d, e, f, g, k = !1, h = !1) => {
      var l = N(e, 15);
      if (a && b && !l && ((f = Ee(f, g.click)), k && e?.ea())) return;
      De(c, d, f, g, h);
    },
    Ee = (a, b = null) => {
      if (b === null) {
        var c = new la({ url: a, ta: null });
        if (c.h.dsh === "1" || c.h.aspm !== "1")
          a = (b = ia(c, 0))
            ? navigator.sendBeacon
              ? navigator.sendBeacon(b.A, "")
                ? b.B
                : ka(c, 2)
              : ka(c, 0)
            : a;
        else if ((b = ia(c, 1))) Ha(b.A), (a = b.B);
        return a;
      }
      c = ia(new la({ url: a }), 0);
      if (!c) return a;
      b(c.A);
      return c.B;
    },
    Ge = (a, b = !0) => {
      b && ke.fetch
        ? ke
            .fetch(a, { method: "GET", keepalive: !0, mode: "no-cors" })
            .then((c) => {
              c.ok || jd(ke, a);
            })
        : jd(ke, a);
    },
    Ae = (a, b, c) => {
      b = encodeURIComponent(String(b));
      c = encodeURIComponent(String(c));
      return a.replace("?", "?" + b + "=" + c + "&");
    },
    ze = (a) => {
      for (let b of Jc(a)) if (Q(b, 1) === 3 && O(b, 2)) return !0;
      return !1;
    };
  var He = (a, b) =>
    a && (a = a.match(b + "=([^&]+)")) && a.length == 2 ? a[1] : "";
  var Ie = class extends U {};
  function Je(a, b) {
    return T(a, 2, b);
  }
  function Ke(a, b) {
    return T(a, 3, b);
  }
  function Le(a, b) {
    return T(a, 4, b);
  }
  function Me(a, b) {
    return T(a, 5, b);
  }
  function Ne(a, b) {
    return T(a, 9, b);
  }
  function Oe(a, b) {
    nc(a);
    var c = a.l,
      d = c[u] | 0;
    if (b == null) G(c, d, 10);
    else {
      var e = b === bb ? 7 : b[u] | 0,
        f = e,
        g = uc(e),
        k = g || Object.isFrozen(b),
        h = !0,
        l = !0;
      for (let p = 0; p < b.length; p++) {
        var m = b[p];
        g || ((m = w(m)), h && (h = !m), l && (l = m));
      }
      g || ((e = h ? 13 : 5), (e = l ? e & -4097 : e | 4096));
      (k && e === f) || ((b = [...b]), (f = 0), (e = vc(e, d)));
      e !== f && (b[u] = e);
      d = G(c, d, 10, b);
      2 & e || !(4096 & e || 16 & e) || oc(c, d);
    }
    return a;
  }
  function Pe(a, b) {
    return R(a, 11, b);
  }
  function Qe(a, b) {
    return T(a, 1, b);
  }
  function Re(a, b) {
    return R(a, 7, b);
  }
  var Se = class extends U {};
  var Te =
    "platform platformVersion architecture model uaFullVersion bitness fullVersionList wow64".split(
      " "
    );
  function Ue() {
    var a = window;
    if (typeof a.navigator?.userAgentData?.getHighEntropyValues !== "function")
      return null;
    var b = a.google_tag_data ?? (a.google_tag_data = {});
    if (b.uach_promise) return b.uach_promise;
    a = a.navigator.userAgentData.getHighEntropyValues(Te).then((c) => {
      b.uach ?? (b.uach = c);
      return c;
    });
    return (b.uach_promise = a);
  }
  function Ve(a) {
    return Pe(
      Oe(
        Me(
          Je(
            Qe(
              Le(
                Re(
                  Ne(Ke(new Se(), a.architecture || ""), a.bitness || ""),
                  a.mobile || !1
                ),
                a.model || ""
              ),
              a.platform || ""
            ),
            a.platformVersion || ""
          ),
          a.uaFullVersion || ""
        ),
        a.fullVersionList?.map((b) => {
          var c = new Ie();
          c = T(c, 1, b.brand);
          return T(c, 2, b.version);
        }) || []
      ),
      a.wow64 || !1
    );
  }
  function We() {
    return Ue()?.then((a) => Ve(a)) ?? null;
  }
  function Xe(a) {
    for (let b of a)
      if (b.element.tagName == "A") {
        a = b.element;
        let c = b.data;
        y(E(c, 2)) == null && T(c, 2, a.href);
      }
  }
  function Ye(a, b) {
    return Ea(a, (c) => c.element === b);
  }
  function Ze(a) {
    hd(
      he(556, () => {
        new $e(a || {});
      })
    );
  }
  function af(a) {
    J(a.i, 1, Lc, B).forEach((b) => {
      a.j != null ||
        O(b, 2) === "" ||
        O(b, 9) === "" ||
        N(b, 13) ||
        N(b, 1) ||
        (a.j = b);
    });
    a.j &&
      (Ca(a.N, ce(O(a.j, 2), de(1714))), (a.N.target = O(a.j, 11) || "_top"));
  }
  function bf(a, b) {
    var c, d;
    if (!b.defaultPrevented || a.J === b) {
      var e = b.type === "click";
      if (a.I && e && !a.oa) b.preventDefault();
      else {
        for (c = b.target; (!k || !d) && c; ) {
          d || c.tagName != "A" || (d = c);
          var f = c.hasAttribute("data-asoch-targets"),
            g = c.hasAttribute("data-asoch-fixed-value");
          if (!k)
            if (g)
              var k = new Lc(
                JSON.parse(c.getAttribute("data-asoch-fixed-value")) || []
              );
            else if (c.tagName == "A" || f)
              if (
                ((f =
                  f && c.getAttribute("data-asoch-is-dynamic") === "true"
                    ? te(a.i, [c])
                    : a.h),
                (f = Ye(f, c)))
              )
                if (
                  ((k = f.data),
                  (f = c.getAttribute("data-asoch-dyn-extra-targets")))
                )
                  a: {
                    f = re(k, a.i, f);
                    if (!f) break a;
                    k = lc(f);
                    se(k);
                  }
          c = c.parentElement;
        }
        k = (c = k) && !N(c, 1);
        if (a.L && a.j && b.defaultPrevented) cf(a, b, d, k ? c : a.j);
        else {
          if (k) {
            if (!a.L && b.defaultPrevented) {
              cf(a, b, d, c);
              return;
            }
            for (var h of rc(c, 6, y)) Ge(h);
          }
          a.O &&
            k &&
            c.ea() &&
            (b.preventDefault ? b.preventDefault() : (b.returnValue = !1));
          h = d;
          d = c;
          !a.I || e || h || d || ((h = a.N), (d = a.j));
          if (h && (c = d && !N(d, 1))) {
            e = h;
            h = c ? d : null;
            (d = Ye(a.h, e))
              ? (d = d.data)
              : ((d = new Lc()),
                T(d, 2, e.href),
                T(d, 11, e.target || "_top"),
                a.h.push({ element: e, data: d }));
            ve(e, h || d, O(d, 2), 557);
            df(a, b, e, h);
            for (var l of rc(a.i, 17, y))
              (d = W.body),
                (c = {}),
                typeof window.CustomEvent === "function"
                  ? (k = new CustomEvent(l, c))
                  : ((k = document.createEvent("CustomEvent")),
                    k.initCustomEvent(
                      l,
                      !!c.bubbles,
                      !!c.cancelable,
                      c.detail
                    )),
                d.dispatchEvent(k);
            if (h?.i()?.i()) {
              l = new Ac();
              Gb(E(h, 5)) != null
                ? ((d = l), (c = Q(h, 5)), xc(d, 1, c))
                : ((d = He(e.href, "nb")), d != "" && xc(l, 1, +d));
              d = He(e.href, "nx");
              d != "" && S(l, 2, +d);
              d = He(e.href, "ny");
              d != "" && S(l, 3, +d);
              d = He(e.href, "bg");
              d != "" && T(l, 4, d);
              d = He(e.href, "nm");
              d != "" && S(l, 5, +d);
              d = He(e.href, "mb");
              d != "" && S(l, 6, +d);
              d = Rd(e.href, "bg");
              Ca(e, ce(d, de(1211)));
              d = h.i();
              f = O(d, 1);
              d = h.i();
              d = O(d, 2);
              c = Ib(E(h, 20)) != null ? Ib(E(h, 20)) ?? 0 : null;
              g = yc(l);
              l = a.G;
              k = je(n);
              var m = new Oc();
              f = T(m, 1, f);
              f = T(f, 4, g);
              f = T(f, 10, Date.now().toString());
              c !== null && S(f, 2, c);
              l !== null && T(f, 3, l);
              xc(f, 9, 7);
              k?.fence?.setReportEventDataForAutomaticBeacons({
                eventType: "reserved.top_navigation_start",
                eventData: JSON.stringify(f),
                destination: ["buyer"],
                once: !0,
              });
              k?.fence?.reportEvent({
                eventType: "click",
                eventData: d,
                destination: ["component-seller"],
              });
            }
            N(a.i, 16) || a.T
              ? ef(a, b, e, h)
              : ((l = ""),
                (d = n.oneAfmaInstance) &&
                  (l = a.ca
                    ? d.appendClickSignals(e.href, !0)
                    : d.appendClickSignals(e.href)),
                ff(a, b, e, h, l));
          }
        }
      }
    }
  }
  function cf(a, b, c, d) {
    if (a.J === b && a.K) {
      var e = new Cc(a.K),
        f = O(d, 9),
        g = "";
      switch (Q(e, 4, 1)) {
        case 2:
          if (Ib(E(e, 2)) ?? 0) g = "blocked_fast_click";
          else if (O(e, 1) || O(e, 7)) g = "blocked_border_click";
          break;
        case 3:
          g = W;
          g = g.getElementById
            ? g.getElementById("common_15click_anchor")
            : null;
          var k = window;
          if (typeof k.copfcChm === "function" && g) {
            var h = lc(d);
            xc(h, 5, 12);
            J(h, 4, void 0, B, B).set("nb", (12).toString());
            let l = Ye(a.h, g);
            l ? (l.data = h) : a.h.push({ element: g, data: h });
            !a.aa && c && (df(a, b, c, h), T(h, 2, c.href));
            k.copfcChm(
              b,
              qe(h, g.href),
              null,
              H(e, 10) ? yc(M(e, Bc, 10)) : null
            );
            a.aa && df(a, b, g, h);
          }
          g = "onepointfiveclick_first_click";
      }
      if (f && g) {
        c = f + "&label=" + g;
        if (
          g === "onepointfiveclick_first_click" ||
          g === "blocked_border_click"
        ) {
          k = a.Y;
          g = a.X;
          f = a.ba;
          e = new oe();
          d = Q(d, 5);
          h = b.clientX;
          F(e, 1, h == null ? h : Lb(h));
          h = b.clientY;
          F(e, 2, h == null ? h : Lb(h));
          S(e, 3, d);
          d = k ? k.changedTouches : [];
          g = g ? g.changedTouches : [];
          d && d.length > 0 && (S(e, 4, d[0].clientX), S(e, 5, d[0].clientY));
          g && g.length > 0 && (S(e, 6, g[0].clientX), S(e, 7, g[0].clientY));
          (b.isTrusted === !1 ||
            (navigator.userActivation &&
              navigator.userActivation.hasBeenActive === !1) ||
            (navigator.userActivation &&
              navigator.userActivation.isActive === !1)) &&
            R(e, 8, !0);
          if (f != null) {
            b = f instanceof Map ? f.entries() : Object.entries(f);
            for (let [l, m] of b)
              (b = Number(l)),
                (d = Date.now() - Number(m)),
                J(e, 9, void 0, Nb, Nb).set(b, d);
          }
          c += "&cpspb=" + yc(e);
        }
        Ge(c, !1);
      }
      qd(a.U);
    }
  }
  function df(a, b, c, d) {
    if (!N(d, 13)) {
      var e = c.href;
      var f = /[?&]adurl=([^&]+)/.exec(e);
      e = f ? [e.slice(0, f.index), e.slice(f.index)] : [e, ""];
      for (Ca(c, ce(e[0], de(557))); !c.id; )
        if (
          ((f =
            "asoch-id-" +
            (Math.floor(Math.random() * 2147483648).toString(36) +
              Math.abs(
                Math.floor(Math.random() * 2147483648) ^ Date.now()
              ).toString(36))),
          !W.getElementById(f))
        ) {
          c.id = f;
          break;
        }
      f = c.id;
      typeof window.xy === "function" && window.xy(b, c, W.body);
      typeof window.mb === "function" && window.mb(c);
      typeof window.bgz === "function" && window.bgz(f);
      typeof window.ja === "function" && window.ja(f, d ? Q(d, 5) : 0);
      typeof window.vti === "function" && window.vti(c);
      a.m &&
        typeof window.ss === "function" &&
        (a.Z ? window.ss(f, 1, a.m) : window.ss(a.m, 1));
      e.length > 0 &&
        ((a =
          a.G.length > 0 && !d?.i()?.i()
            ? c.href + "&uach=" + encodeURIComponent(a.G) + e[1]
            : c.href + e[1]),
        Ca(c, ce(a, de(557))));
    }
  }
  async function ef(a, b, c, d) {
    var e = "",
      f = n.oneAfmaInstance;
    if (
      f &&
      (b.preventDefault(),
      (e =
        (a.ca
          ? await f.appendClickSignalsAsync(c.href, !0)
          : await f.appendClickSignalsAsync(c.href)) || ""),
      a.T)
    ) {
      if (a.na) return;
      if ((f = await f.getNativeClickMeta())) {
        if (f.customClickGestureEligible) return;
        e = Ae(e, "nas", f.encodedNas);
      }
    }
    ff(a, b, c, d, e);
  }
  function ff(a, b, c, d, e) {
    a.S++;
    a.H < 0 && (a.H = Date.now());
    var f = N(a.i, 2),
      g = a.P > 0 ? a.P : 300;
    g = f && Date.now() - a.V > g;
    var k = d?.j() ? M(d, Fc, 29) : null;
    (a.pa || a.da) &&
      k === null &&
      ((k = new Fc()), R(k, 1, !0), a.da && F(k, 2, Jb(200)));
    var h = n.oneAfmaInstance;
    if (h) {
      b.preventDefault ? b.preventDefault() : (b.returnValue = !1);
      c = N(d, 13) ? e : h.logScionEventAndAddParam(e);
      b = c;
      if (!a.F && d && H(d, 12)) {
        e = M(d, Gc, 12).C();
        if (Jc(d).length > 0) for (l of Jc(d));
        var l = M(d, Gc, 12);
        N(l, 2) ? (h.click(b), h.openAndroidApp(e), (l = !0)) : (l = !1);
      } else l = !1;
      l || Ce(a.F, a.o, a.ka, d, c, h) || Fe(f, g, k, a.F, d, c, h, a.O, a.la);
    } else {
      if (g && (d = c.href) && Pd(d, "cce")) {
        f = new la({ url: d });
        a: {
          d = f.h.cce;
          if (d === "1") d = 0;
          else if (d === "2") d = 1;
          else {
            d = null;
            break a;
          }
          f = r(f.i, "cc=1");
          k = f.indexOf("?");
          d =
            k < 0
              ? null
              : {
                  url:
                    "https://www.googleadservices.com/pagead/aclk" + f.slice(k),
                  method: d,
                };
        }
        d &&
          (d.method === 0
            ? navigator.sendBeacon && navigator.sendBeacon(d.url, "")
            : d.method === 1 && Ha(d.url));
      }
      d = window;
      a.ma && d.pawsig && typeof d.pawsig.clk === "function"
        ? (ie("paw_sigs", {
            msg: "click",
            count: a.S.toString(),
            elapsed: (Date.now() - a.H).toString(),
          }),
          g && d.pawsig.clk(c))
        : g && ((d = Ee(c.href)), d !== c.href && Ca(c, ce(d, de(599))));
    }
    g && (a.V = Date.now());
    qd(a.U);
  }
  var $e = class {
    constructor(a) {
      this.F = Qa || Oa || Ra || Pa;
      var b = le("data-asoch-meta");
      if (b.length !== 1) ie("gdn-asoch", { type: 2, data: b.length });
      else {
        this.U = 70;
        this.i = new Mc(JSON.parse(b[0].getAttribute("data-asoch-meta")) || []);
        this.R = a["extra-meta"] ? new Mc(JSON.parse(a["extra-meta"])) : null;
        this.T = a["is-fsn"] === "true";
        this.na = a["is-tap-disabled-for-fsn"] === "true";
        this.I = (b = a.nm ? Nc(a.nm) : null) ? Q(b, 4) != 0 : !1;
        this.oa = b ? N(b, 5) : !1;
        this.o = a["ios-store-overlay-config"]
          ? new Dc(JSON.parse(a["ios-store-overlay-config"]))
          : null;
        this.ka = a["enable-alleyoop-interactions"] === "true";
        this.pa = a["use-cct-over-browser"] === "true";
        this.la = a["enable-lock-screen-ad-custom-webview"] === "true";
        this.da = a["use-half-page-cct-over-browser"] === "true";
        this.aa = a["correct-redirect-url-for-och-15-click"] === "true";
        this.ca = a["use-click-signals-json"] === "true";
        this.L = a["default-msg-in-och"] === "true";
        this.ma = a["enable-paw"] === "true";
        this.O = a["allow-redirection-muted-in-och"] === "true";
        this.P = Number(a["custom-async-tracking-throttle-interval"]) || -1;
        this.G = "";
        b = We();
        b != null &&
          b.then((c) => {
            var d = yc(c);
            c = [];
            var e = 0;
            for (var f = 0; f < d.length; f++) {
              var g = d.charCodeAt(f);
              if (g > 255) {
                var k = Error("go/unicode-to-byte-error");
                Ja && Ia(k);
                c[e++] = g & 255;
                g >>= 8;
              }
              c[e++] = g;
            }
            d = 3;
            d === void 0 && (d = 0);
            if (!Ta)
              for (
                Ta = {},
                  e =
                    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(
                      ""
                    ),
                  f = ["+/=", "+/", "-_=", "-_.", "-_"],
                  g = 0;
                g < 5;
                g++
              ) {
                k = e.concat(f[g].split(""));
                Sa[g] = k;
                for (var h = 0; h < k.length; h++) {
                  var l = k[h];
                  Ta[l] === void 0 && (Ta[l] = h);
                }
              }
            d = Sa[d];
            e = Array(Math.floor(c.length / 3));
            f = d[64] || "";
            for (g = k = 0; k < c.length - 2; k += 3) {
              var m = c[k],
                p = c[k + 1];
              l = c[k + 2];
              h = d[m >> 2];
              m = d[((m & 3) << 4) | (p >> 4)];
              p = d[((p & 15) << 2) | (l >> 6)];
              l = d[l & 63];
              e[g++] = h + m + p + l;
            }
            h = 0;
            l = f;
            switch (c.length - k) {
              case 2:
                (h = c[k + 1]), (l = d[(h & 15) << 2] || f);
              case 1:
                (c = c[k]),
                  (e[g] = d[c >> 2] + d[((c & 3) << 4) | (h >> 4)] + l + f);
            }
            this.G = e.join("");
          });
        this.h = te(this.i, []);
        this.j = null;
        this.N = bd("A");
        this.L && af(this);
        this.qa =
          Number(a["deeplink-and-android-app-validation-timeout"]) || 500;
        this.V = -Infinity;
        this.H = this.S = 0;
        this.m = O(this.i, 5) || "";
        this.Z = N(this.i, 11);
        this.R && (this.Z = N(this.R, 11));
        this.K = this.ba = this.W = this.X = this.Y = this.J = null;
        N(this.i, 3) || (we(this.h), R(this.i, 3, !0));
        Xe(this.h);
        a = n.oneAfmaInstance;
        !this.F && a && ye(this.h, this.qa);
        if (a && this.o?.j())
          switch (
            ((b = () => {
              var c = Ib(E(this.o, 4)) ?? 0;
              c > 0
                ? n.setTimeout(() => {
                    xe(this.h);
                  }, c)
                : xe(this.h);
            }),
            Q(this.o, 3))
          ) {
            case 1:
              a.runOnOnShowEvent(b);
              break;
            case 2:
              id(b);
              break;
            default:
              xe(this.h);
          }
        if (a && this.I) {
          af(this);
          if (!this.j) return;
          V(
            W,
            "touchstart",
            (c) => {
              this.W = c;
            },
            dd
          );
          ke.AFMA_Communicator?.addEventListener?.(
            "onCustomClickGesture",
            () => {
              bf(this, this.W || new Event("touchstart"));
            }
          );
        }
        V(
          W,
          "click",
          he(557, (c) => {
            bf(this, c);
          }),
          dd
        );
        V(
          W,
          "auxclick",
          he(557, (c) => {
            c.button === 1 && bf(this, c);
          }),
          dd
        );
        this.m &&
          typeof window.ss === "function" &&
          V(
            W.body,
            "mouseover",
            he(626, () => {
              window.ss(this.m, 0);
            }),
            ed
          );
        typeof window.ivti === "function" && window.ivti(W.body);
        a = window;
        a.googqscp &&
          typeof a.googqscp.registerCallback === "function" &&
          a.googqscp.registerCallback((c, d, e, f, g) => {
            this.J = c;
            this.K = d;
            this.Y = e;
            this.X = f;
            this.ba = g;
          });
        nd();
      }
    }
  };
  var gf = he(555, (a) => Ze(a));
  md = 70;
  var hf = od(70, document.currentScript);
  if (hf == null) throw Error("JSC not found 70");
  var jf = {},
    kf = hf.attributes;
  for (let a = kf.length - 1; a >= 0; a--) {
    let b = kf[a].name;
    b.indexOf("data-jcp-") === 0 && (jf[b.substring(9)] = kf[a].value);
  }
  gf(jf);
}.call(this));
