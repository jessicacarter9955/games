(function ($global) {
  "use strict";
  var $estr = function () {
      return js_Boot.__string_rec(this, "");
    },
    $hxEnums = $hxEnums || {},
    $_;
  class ScriptComponent extends pc.ScriptType {
    initialize() {}
    postInitialize() {}
    swap(e) {}
    postUpdate(e) {}
    update(e) {}
    get_position() {
      return this.entity.getPosition();
    }
    set_position(e) {
      return this.entity.setPosition(e), e;
    }
    get_rotation() {
      return this.entity.getRotation();
    }
    set_rotation(e) {
      return this.entity.setRotation(e), e;
    }
    get_localScale() {
      return this.entity.getLocalScale();
    }
    set_localScale(e) {
      return this.entity.setLocalScale(e), e;
    }
    get_lossyScale() {
      return this.entity.getScale();
    }
    get_localPosition() {
      return this.entity.getLocalPosition();
    }
    set_localPosition(e) {
      return this.entity.setLocalPosition(e), e;
    }
    get_localRotation() {
      return this.entity.getLocalRotation();
    }
    set_localRotation(e) {
      return this.entity.setLocalRotation(e), e;
    }
    get_eulerAngles() {
      return this.entity.getEulerAngles();
    }
    set_eulerAngles(e) {
      return this.entity.setEulerAngles(e), e;
    }
    get_localEulerAngles() {
      return this.entity.getLocalEulerAngles();
    }
    set_localEulerAngles(e) {
      return this.entity.setLocalEulerAngles(e), e;
    }
    getChildByName(e) {
      for (var t = this.entity.children, a = 0, n = t.length; a < n; ) {
        var i = a++;
        if (t[i].name == e) return t[i];
      }
      return null;
    }
  }
  (ScriptComponent.__name__ = "ScriptComponent"),
    (ScriptComponent.__super__ = pc.ScriptType),
    Object.assign(ScriptComponent.prototype, {
      __class__: ScriptComponent,
      __properties__: {
        set_localEulerAngles: "set_localEulerAngles",
        get_localEulerAngles: "get_localEulerAngles",
        set_eulerAngles: "set_eulerAngles",
        get_eulerAngles: "get_eulerAngles",
        set_localRotation: "set_localRotation",
        get_localRotation: "get_localRotation",
        set_localPosition: "set_localPosition",
        get_localPosition: "get_localPosition",
        get_lossyScale: "get_lossyScale",
        set_localScale: "set_localScale",
        get_localScale: "get_localScale",
        set_rotation: "set_rotation",
        get_rotation: "get_rotation",
        set_position: "set_position",
        get_position: "get_position",
      },
    });
  class APIManager extends ScriptComponent {
    constructor(e) {
      super(e),
        (this.rewardedTopIcon = null),
        (this.ghostTube_adIcon = null),
        (this.skipItIcon = null),
        (this.adLoadedIcon = null),
        (this.adLoadingIcon = null);
    }
    initialize() {
      super.initialize(),
        (APIManager.inst = this),
        (APIManager.hasRewardedAd = !1),
        APIManager.GameInterface.onRewardedAdAvailabilityChange(function (
          e,
          t
        ) {
          APIManager.hasFamobiRewardedAd = t;
        }),
        APIManager.GameInterface.hasRewardedAd().then(function (e) {
          APIManager.hasFamobiRewardedAd = e;
        });
    }
    update(e) {
      super.update(e);
    }
    static ShowInterstitial(e, t) {
      null == t && (t = ""),
        motion_Actuate.timer(0.05).onComplete(function () {
          null != e && e(!0);
        });
    }
    static IsRewardedAdReady(e) {
      return null == e && (e = ""), APIManager.hasFamobiRewardedAd;
    }
    static IsRewardedAdReadyFamobi(e, t) {
      null == e && (e = ""), t(APIManager.hasFamobiRewardedAd);
    }
    static ShowRewardedAD(e, t) {
      null == t && (t = ""),
        APIManager.HasFeature("rewarded")
          ? APIManager.GameInterface.showRewardedAd(t).then(function (t) {
              null != e && e(t.isRewardGranted);
            })
          : motion_Actuate.timer(0.05).onComplete(function () {
              null != e && e(!0);
            });
    }
    static HasFeature(e) {
      var t = APIManager.CachedFeatures;
      if (
        null != __map_reserved[e] ? t.existsReserved(e) : t.h.hasOwnProperty(e)
      ) {
        var a = APIManager.CachedFeatures;
        return null != __map_reserved[e] ? a.getReserved(e) : a.h[e];
      }
      var n = APIManager.GameInterface.hasFeature(e),
        i = APIManager.CachedFeatures;
      return null != __map_reserved[e] ? i.setReserved(e, n) : (i.h[e] = n), n;
    }
    static HasSkipTickets() {
      return APIManager.numSkipTickets > 0;
    }
  }
  (APIManager.__name__ = "APIManager"),
    (APIManager.__super__ = ScriptComponent),
    Object.assign(APIManager.prototype, { __class__: APIManager });
  class AdLoadingIcon extends ScriptComponent {
    constructor(e) {
      super(e),
        (this.elapsedTimeToCheck = 100),
        (this.isRewardReady = !1),
        (this.isEnabled = !1),
        (this.rotate = !0),
        (this.eoe = null),
        (this.adBtn = null);
    }
    initialize() {
      super.initialize(), this.OnEnable();
      var e = this;
      this.on(
        "state",
        function (t) {
          return t ? e.OnEnable() : e.OnDisable(), !0;
        },
        this
      );
    }
    OnEnable() {
      (this.isEnabled = !0), (this.sr = this.entity);
      for (var e = this, t = 0, a = this.eoe.length; t < a; ) {
        var n = t++;
        this.eoe[n].enabled = !0;
      }
      (this.isRewardReady = !1),
        this.setFamobiImageIcon(),
        APIManager.IsRewardedAdReadyFamobi(this.placement, function (t) {
          (e.isRewardReady = t), e.setFamobiImageIcon();
        });
    }
    setFamobiImageIcon() {
      if (null != this.sr)
        if (this.isRewardReady) {
          if (
            ((this.sr.element.spriteAsset = APIManager.inst.adLoadedIcon.id),
            null != this.adBtn)
          ) {
            var e,
              t = 1;
            null == t
              ? ((t = [0, 0, 0, 0]), (e = new pc.Color(t)))
              : (e = new pc.Color(t, 1, 1, 1)),
              (this.adBtn.element.color = e);
          }
          this.rotate = !1;
          var a = this.entity,
            n = new pc.Quat(0, 0, 0, 1),
            i = _$Quaternion_Quaternion_$Impl_$.setFromEulerAngles(n, 0, 0, 0);
          a.setRotation(i);
        } else {
          if (
            ((this.sr.element.spriteAsset = APIManager.inst.adLoadingIcon.id),
            null != this.adBtn)
          ) {
            var s,
              r = 1;
            null == r
              ? ((r = [0, 0, 0, 0]), (s = new pc.Color(r)))
              : (s = new pc.Color(r, 1, 1, 0.75)),
              (this.adBtn.element.color = s);
          }
          this.rotate = !0;
        }
    }
    OnDisable() {
      this.isEnabled = !1;
      for (var e = 0, t = this.eoe.length; e < t; ) {
        var a = e++;
        this.eoe[a].enabled = !1;
      }
    }
    SetImageIcon() {
      null != this.placement &&
        "" != this.placement &&
        ((this.isRewardReady = APIManager.IsRewardedAdReady(this.placement)),
        this.setFamobiImageIcon());
    }
    update(e) {
      super.update(e),
        (this.elapsedTimeToCheck += e),
        this.elapsedTimeToCheck > 0.4 &&
          (this.SetImageIcon(), (this.elapsedTimeToCheck = 0));
    }
    postUpdate(e) {
      super.postUpdate(e),
        this.rotate &&
          this.isEnabled &&
          this.entity.rotateLocal(0, 0, this.speed * e);
    }
    static SetPlacementForEntity(e, t) {
      var a = EntityHelper.GetComponentInChildren_AdLoadingIcon(
        e,
        AdLoadingIcon
      );
      null != a &&
        ((a.placement = t),
        a.setFamobiImageIcon(),
        APIManager.IsRewardedAdReadyFamobi(t, function (e) {
          (a.isRewardReady = e), a.setFamobiImageIcon();
        }));
    }
  }
  (AdLoadingIcon.__name__ = "AdLoadingIcon"),
    (AdLoadingIcon.__super__ = ScriptComponent),
    Object.assign(AdLoadingIcon.prototype, { __class__: AdLoadingIcon });
  class AnimHelper {
    static addAnimStateEvent(e, t, a, n, i, s, r) {
      null == n && (n = 0);
      for (var o = 0, l = e.layers; o < l.length; ) {
        var u = l[o];
        if (
          (++o, Object.prototype.hasOwnProperty.call(u._controller._states, t))
        ) {
          var c = Reflect.field(u._controller._states, t),
            h = c.animations[0]._animTrack._animEvents._events;
          null == h && (h = []);
          for (var p = 0; p < 100 && null != h[p]; ) ++p;
          for (var m = h, _ = !1, d = 0; d < m.length; ) {
            var g = m[d];
            if (
              (++d,
              g.name == a && g.time == n && g.number == s && g.string == r)
            ) {
              _ = !0;
              break;
            }
          }
          _ || h.push({ name: a, time: n, number: s, string: r }),
            (c.animations[0]._animTrack._animEvents._events = h);
        }
      }
      null != i &&
        e.on(a, function (e) {
          return e.number == s && e.string == r && i(e), !0;
        });
    }
  }
  AnimHelper.__name__ = "AnimHelper";
  class CheatsWindow extends ScriptComponent {
    initialize() {
      CheatsWindow.inst = this;
      var e = this.getChildByName("PreLevelBtn"),
        t = this.getChildByName("NextLevelBtn");
      UIHelper.AddButtonClickHandler(e, function () {
        UIManager.GoToPreviousLevel();
      }),
        UIHelper.AddButtonClickHandler(t, function () {
          UIManager.GoToNextLevel();
        }),
        (this.entity.enabled = !1),
        UIHelper.AddButtonClickHandler(
          this.entity.findByPath("Buttons/WinBtn"),
          function () {
            UIManager.inst.GameWon(!1);
          }
        ),
        UIHelper.AddButtonClickHandler(
          this.entity.findByPath("Buttons/LoseBtn"),
          function () {
            (UIManager.inst.movesUsed = 0 | UIManager.inst.totalMoves),
              UIManager.inst.SetStarBarAndText(),
              UIManager.inst.GameLose();
          }
        ),
        UIHelper.AddButtonClickHandler(
          this.entity.findByPath("Buttons/NoMoreMovesBtn"),
          function () {
            UIManager.inst.ShowNoMorePanel();
          }
        ),
        UIHelper.AddButtonClickHandler(
          this.entity.findByPath("Buttons/Add100MoneyBtn"),
          function () {
            UIManager.inst.AddCurrency(100);
          }
        ),
        UIHelper.AddButtonClickHandler(
          this.entity.findByPath("Buttons/Add5000MoneyBtn"),
          function () {
            UIManager.inst.AddCurrency(5e3);
          }
        ),
        UIHelper.AddButtonClickHandler(
          this.entity.findByPath("Buttons/AddPowersBtns"),
          function () {
            var e = GameManager;
            e.set_SkipLvlCount(e.get_SkipLvlCount() + 1);
            var t = GameManager;
            t.set_EmptyTubesCount(t.get_EmptyTubesCount() + 1);
            var a = GameManager;
            a.set_UndoMovesCount(a.get_UndoMovesCount() + 1);
            var n = GameManager;
            n.set_HintCounts(n.get_HintCounts() + 1),
              UIManager.inst.SetSkipLvlCount(),
              UIManager.inst.SetXtraTubeCount(),
              UIManager.inst.SetUndoCount(),
              UIManager.inst.SetHintCount();
          }
        ),
        UIHelper.AddButtonClickHandler(
          this.entity.findByPath("Buttons/ResetTimersBtn"),
          function () {
            for (
              var e = EntityHelper.GetComponentsInChildren_TimerDailySpin(
                  UIManager.inst.mainPanel,
                  TimerDailySpin
                ),
                t = new Date(
                  new Date().getTime() +
                    (1e3 * -TimerDailySpin.spinGapHours * 60 * 60 + 1e3)
                ),
                a = 0;
              a < e.length;

            ) {
              var n = e[a];
              ++a, (n.lastTime = t);
            }
            PlayerPrefs.SetString("SpinTime", HxOverrides.dateStr(t));
            var i = EntityHelper.GetComponentsInChildren_OfflineReward(
              UIManager.inst.mainPanel,
              OfflineReward
            );
            t = new Date(
              new Date().getTime() +
                (1e3 * -OfflineReward.rewardGapHours * 60 * 60 + 1e3)
            );
            for (var s = 0; s < i.length; ) {
              var r = i[s];
              ++s, (r.lastTime = t);
            }
            PlayerPrefs.SetString("OfflineTime", HxOverrides.dateStr(t));
          }
        ),
        UIHelper.AddButtonClickHandler(
          this.entity.findByPath("Buttons/OpenAllLevelsBtn"),
          function () {}
        ),
        UIHelper.AddButtonClickHandler(
          this.entity.findByPath("Buttons/OpenAllSkinsBtn"),
          function () {
            for (
              var e = EntityHelper.GetComponentsInChildren_ShopItems(
                  UIManager.inst.mainPanel,
                  ShopItems
                ),
                t = 0;
              t < e.length;

            ) {
              var a = e[t];
              ++t, a.UnlockItem(!1);
            }
          }
        ),
        CheatsWindowWatcher.init();
    }
  }
  (CheatsWindow.__name__ = "CheatsWindow"),
    (CheatsWindow.__super__ = ScriptComponent),
    Object.assign(CheatsWindow.prototype, { __class__: CheatsWindow });
  class CheatsWindowWatcher extends ScriptComponent {
    constructor(e) {
      super(e), (this.lastClickTime = -1), (this.numClicks = 0);
    }
    update(e) {
      super.update(e);
    }
    static init() {}
  }
  (CheatsWindowWatcher.__name__ = "CheatsWindowWatcher"),
    (CheatsWindowWatcher.__super__ = ScriptComponent),
    Object.assign(CheatsWindowWatcher.prototype, {
      __class__: CheatsWindowWatcher,
    });
  class CoinsCollector extends ScriptComponent {
    constructor(e) {
      super(e),
        (this.distance = 0),
        (this.isSpawned = !1),
        (this.spawnedObj = 0),
        (this.spawnedCoinsTrans = null),
        (this.targetPos = null),
        (this.coinPrefab = null);
    }
    initialize() {
      super.initialize(), this.onEnable();
      var e = this;
      this.on(
        "state",
        function (t) {
          return t ? e.onEnable() : e.onDisable(), !0;
        },
        this
      );
    }
    onEnable() {
      this.totalCoinsToAdd <= 0
        ? ((this.spawnedCoinsObj = []),
          (this.entity.enabled = !1),
          this.callToMain && UIManager.inst.CoinSended())
        : this.Animate();
    }
    onDisable() {
      for (var e = 0, t = this.spawnedCoinsObj.length; e < t; ) {
        var a = e++;
        this.spawnedCoinsObj[a].destroy();
      }
      (this.spawnedCoinsObj = []),
        (this.spawnedCoinsRect = []),
        (this.spawnedCoinsTrans = []),
        (this.spawnedCoinsPos = []),
        (this.movingTime = []),
        (this.spawnedObj = 0),
        (this.isSpawned = !1);
    }
    Animate() {
      MainManager.inst.PlayOneShot("GemsCollect"),
        (this.spawnedCoinsObj = []),
        this.is2dCoins
          ? (this.spawnedCoinsTrans = [])
          : (this.spawnedCoinsRect = []),
        (this.spawnedCoinsPos = []),
        (this.movingTime = []),
        this.spawnNextCoin();
    }
    spawnNextCoin() {
      if (this.spawnedObj >= this.coinsToSpawn) this.isSpawned = !0;
      else {
        this.spawnedCoinsObj.push(
          EntityHelper.InstantiatePrefab(this.coinPrefab, this.entity)
        ),
          (this.spawnedCoinsObj[this.spawnedCoinsObj.length - 1].enabled = !0),
          this.is2dCoins
            ? this.spawnedCoinsTrans.push(
                this.spawnedCoinsObj[this.spawnedCoinsObj.length - 1]
              )
            : this.spawnedCoinsRect.push(
                this.spawnedCoinsObj[this.spawnedCoinsObj.length - 1]
              ),
          this.spawnedCoinsPos.push(
            this.RandomCircle(
              _$Vector3_Vector3_$Impl_$.get_ZERO(),
              this.circleRadius
            )
          );
        var e = this.minMoveSpeedInCircle;
        this.movingTime.push(
          e + (this.maxMoveSpeedInCircle - e) * Math.random()
        ),
          (this.spawnedObj += 1);
        var t = this.minSpawnGap;
        motion_Actuate
          .timer(t + (this.maxSpawnGap - t) * Math.random())
          .onComplete($bind(this, this.spawnNextCoin));
      }
    }
    update(e) {
      if ((super.update(e), this.isSpawned)) {
        if (this.isSpawned) {
          for (var t = !1, a = 0, n = this.spawnedObj; a < n; ) {
            var i = a++;
            if (this.spawnedCoinsObj[i].enabled) {
              if (((t = !0), !this.is2dCoins)) {
                this.distance = _$Vector3_Vector3_$Impl_$
                  .sub(
                    this.spawnedCoinsRect[i].getPosition().clone(),
                    this.targetPos.getPosition().clone()
                  )
                  .length();
                var s = this.spawnedCoinsRect[i],
                  r = this.spawnedCoinsRect[i].getPosition().clone(),
                  o = this.targetPos.getPosition().clone(),
                  l = e / (this.distance / (this.moveSpeed / 700));
                l = l > 1 ? 1 : l < 0 ? 0 : l;
                var u = r.x + (o.x - r.x) * l,
                  c = r.y + (o.y - r.y) * l,
                  h = r.z + (o.z - r.z) * l;
                null == h && (h = 0),
                  null == c && (c = 0),
                  null == u && (u = 0);
                var p = new pc.Vec3(u, c, h);
                s.setPosition(p);
              }
              this.distance < 0.02 &&
                (null != UIManager.inst &&
                  UIManager.inst.AddCurrency(
                    this.totalCoinsToAdd / this.coinsToSpawn
                  ),
                (this.spawnedCoinsObj[i].enabled = !1));
            }
          }
          t ||
            (MainManager.inst.PlayOneShot("GemsReceive"),
            (this.entity.enabled = !1),
            this.callToMain && UIManager.inst.CoinSended());
        }
      } else
        for (var m = 0, _ = this.spawnedObj; m < _; ) {
          var d = m++;
          if (this.is2dCoins) {
            this.distance = _$Vector3_Vector3_$Impl_$
              .sub(
                this.spawnedCoinsTrans[d].getLocalPosition().clone(),
                this.spawnedCoinsPos[d]
              )
              .length();
            var g = this.spawnedCoinsTrans[d],
              y = this.spawnedCoinsTrans[d].getLocalPosition().clone(),
              v = this.spawnedCoinsPos[d],
              b = e / (this.distance / this.movingTime[d]);
            b = b > 1 ? 1 : b < 0 ? 0 : b;
            var f = y.x + (v.x - y.x) * b,
              S = y.y + (v.y - y.y) * b,
              P = y.z + (v.z - y.z) * b;
            null == P && (P = 0), null == S && (S = 0), null == f && (f = 0);
            var M = new pc.Vec3(f, S, P);
            g.setLocalPosition(M);
          } else {
            this.distance = _$Vector3_Vector3_$Impl_$
              .sub(
                this.spawnedCoinsRect[d].getLocalPosition().clone(),
                this.spawnedCoinsPos[d]
              )
              .length();
            var C = this.spawnedCoinsRect[d],
              I = this.spawnedCoinsRect[d].getLocalPosition().clone(),
              B = this.spawnedCoinsPos[d],
              T = e / (this.distance / this.movingTime[d]);
            T = T > 1 ? 1 : T < 0 ? 0 : T;
            var L = I.x + (B.x - I.x) * T,
              x = I.y + (B.y - I.y) * T,
              G = I.z + (B.z - I.z) * T;
            null == G && (G = 0), null == x && (x = 0), null == L && (L = 0);
            var w = new pc.Vec3(L, x, G);
            C.setLocalPosition(w);
          }
        }
    }
    RandomCircle(e, t) {
      var a = 360 * Math.random(),
        n = new pc.Vec3(0, 0, 0);
      return (
        (n.x = e.x + t * Math.sin(0.01745329251994 * a)),
        (n.y = e.y + t * Math.cos(0.01745329251994 * a)),
        (n.z = e.z),
        n
      );
    }
  }
  (CoinsCollector.__name__ = "CoinsCollector"),
    (CoinsCollector.__super__ = ScriptComponent),
    Object.assign(CoinsCollector.prototype, { __class__: CoinsCollector });
  class CoinsCollectorScreenSpaceCam extends ScriptComponent {
    constructor(e) {
      super(e),
        (this.distance = 0),
        (this.isSpawned = !1),
        (this.spawnedObj = 0);
    }
    initialize() {
      super.initialize(), this.onEnable();
      var e = this;
      this.entity.on(
        "state",
        function (t) {
          return t ? e.onEnable() : e.onDisable(), !0;
        },
        this
      );
    }
    onEnable() {
      this.Animate();
    }
    onDisable() {
      for (var e = 0, t = this.spawnedCoinsObj.length; e < t; ) {
        var a = e++;
        this.spawnedCoinsObj[a].destroy();
      }
      (this.spawnedCoinsObj = []),
        (this.spawnedCoinsRect = []),
        (this.spawnedCoinsPos = []),
        (this.movingTime = []),
        (this.spawnedObj = 0),
        (this.isSpawned = !1);
    }
    update(e) {
      if ((super.update(e), this.isSpawned)) {
        if (this.isSpawned) {
          for (var t = !1, a = 0, n = this.spawnedObj; a < n; ) {
            var i = a++;
            if (this.spawnedCoinsObj[i].enabled) {
              (t = !0),
                (this.distance = _$Vector3_Vector3_$Impl_$
                  .sub(
                    this.spawnedCoinsRect[i].getPosition().clone(),
                    this.targetPos.getPosition().clone()
                  )
                  .length());
              var s = this.spawnedCoinsRect[i],
                r = this.spawnedCoinsRect[i].getPosition().clone(),
                o = this.targetPos.getPosition().clone(),
                l = e / (this.distance / (this.moveSpeed / 3.7));
              l = l > 1 ? 1 : l < 0 ? 0 : l;
              var u = r.x + (o.x - r.x) * l,
                c = r.y + (o.y - r.y) * l,
                h = r.z + (o.z - r.z) * l;
              null == h && (h = 0), null == c && (c = 0), null == u && (u = 0);
              var p = new pc.Vec3(u, c, h);
              s.setPosition(p),
                this.distance < 0.02 &&
                  (null != UIManager.inst &&
                    UIManager.inst.AddCurrency(
                      this.totalCoinsToAdd / this.coinsToSpawn
                    ),
                  (this.spawnedCoinsObj[i].enabled = !1));
            }
          }
          this.isSpawned && (t || (this.entity.enabled = !1));
        }
      } else
        for (var m = 0, _ = this.spawnedObj; m < _; ) {
          var d = m++;
          this.distance = _$Vector3_Vector3_$Impl_$
            .sub(
              this.spawnedCoinsRect[d].getLocalPosition().clone(),
              this.spawnedCoinsPos[d]
            )
            .length();
          var g = this.spawnedCoinsRect[d],
            y = this.spawnedCoinsRect[d].getLocalPosition().clone(),
            v = this.spawnedCoinsPos[d],
            b = e / (this.distance / this.movingTime[d]);
          b = b > 1 ? 1 : b < 0 ? 0 : b;
          var f = y.x + (v.x - y.x) * b,
            S = y.y + (v.y - y.y) * b,
            P = y.z + (v.z - y.z) * b;
          null == P && (P = 0), null == S && (S = 0), null == f && (f = 0);
          var M = new pc.Vec3(f, S, P);
          g.setLocalPosition(M);
        }
    }
    Animate() {
      (this.spawnedCoinsObj = []),
        (this.spawnedCoinsRect = []),
        (this.spawnedCoinsPos = []),
        (this.movingTime = []),
        motion_Actuate.timer(0.1).onComplete($bind(this, this.spawnNextCoin));
    }
    spawnNextCoin() {
      if (this.spawnedObj >= this.coinsToSpawn) this.isSpawned = !0;
      else {
        this.spawnedCoinsObj.push(
          EntityHelper.InstantiatePrefab(this.coinPrefab, this.entity)
        ),
          this.spawnedCoinsRect.push(
            this.spawnedCoinsObj[this.spawnedCoinsObj.length - 1]
          ),
          (this.spawnedCoinsObj[this.spawnedCoinsObj.length - 1].enabled = !0),
          this.spawnedCoinsPos.push(
            this.RandomCircle(
              _$Vector3_Vector3_$Impl_$.get_ZERO(),
              170 * this.circleRadius
            )
          );
        var e = this.minMoveSpeedInCircle;
        this.movingTime.push(
          300 * (e + (this.maxMoveSpeedInCircle - e) * Math.random())
        ),
          (this.spawnedObj += 1);
        var t = this.minSpawnGap;
        motion_Actuate
          .timer(t + (this.maxSpawnGap - t) * Math.random())
          .onComplete($bind(this, this.spawnNextCoin));
      }
    }
    RandomCircle(e, t) {
      var a = 360 * Math.random(),
        n = new pc.Vec3(0, 0, 0);
      return (
        (n.x = e.x + t * Math.sin(0.01745329251994 * a)),
        (n.y = e.y + t * Math.cos(0.01745329251994 * a)),
        (n.z = e.z),
        n
      );
    }
  }
  (CoinsCollectorScreenSpaceCam.__name__ = "CoinsCollectorScreenSpaceCam"),
    (CoinsCollectorScreenSpaceCam.__super__ = ScriptComponent),
    Object.assign(CoinsCollectorScreenSpaceCam.prototype, {
      __class__: CoinsCollectorScreenSpaceCam,
    });
  class _$Color_Color_$Impl_$ {
    static get_BLACK() {
      return pc.Color.BLACK.clone();
    }
    static get_BLUE() {
      return pc.Color.BLUE.clone();
    }
    static get_CYAN() {
      return pc.Color.CYAN.clone();
    }
    static get_GRAY() {
      return pc.Color.GRAY.clone();
    }
    static get_GREEN() {
      return pc.Color.GREEN.clone();
    }
    static get_MAGENTA() {
      return pc.Color.MAGENTA.clone();
    }
    static get_RED() {
      return pc.Color.RED.clone();
    }
    static get_WHITE() {
      return pc.Color.WHITE.clone();
    }
    static get_YELLOW() {
      return pc.Color.YELLOW.clone();
    }
    static _new(e, t, a, n) {
      var i;
      return (
        null == e
          ? ((e = [0, 0, 0, 0]), (i = new pc.Color(e)))
          : (i = new pc.Color(e, t, a, n)),
        i
      );
    }
    static equals(e, t) {
      return e.equals(t);
    }
    static notequals(e, t) {
      return !e.equals(t);
    }
  }
  (_$Color_Color_$Impl_$.__name__ = "_Color.Color_Impl_"),
    (_$Color_Color_$Impl_$.__properties__ = {
      get_YELLOW: "get_YELLOW",
      get_WHITE: "get_WHITE",
      get_RED: "get_RED",
      get_MAGENTA: "get_MAGENTA",
      get_GREEN: "get_GREEN",
      get_GRAY: "get_GRAY",
      get_CYAN: "get_CYAN",
      get_BLUE: "get_BLUE",
      get_BLACK: "get_BLACK",
    });
  class ColorWaterLevel {
    constructor() {
      (this.tubes = null),
        (this.haveKey = !1),
        (this.minTimeToSort = 15),
        (this.minMovesToSort = 1),
        (this.tubesToSort = 1),
        (this.useGhostTube = !0),
        (this.skipWinInterstitial = !1);
    }
  }
  (ColorWaterLevel.__name__ = "ColorWaterLevel"),
    Object.assign(ColorWaterLevel.prototype, { __class__: ColorWaterLevel });
  class WaterName {
    constructor(e) {
      (this.waterNames = null), (this.waterNames = e);
    }
  }
  (WaterName.__name__ = "WaterName"),
    Object.assign(WaterName.prototype, { __class__: WaterName });
  class Coroutines extends ScriptComponent {
    initialize() {
      super.initialize();
    }
    postUpdate(e) {
      super.postUpdate(e);
      for (var t = Coroutines.coroutines.length; t-- > 0; )
        if (null == Coroutines.coroutines[t].entity)
          Coroutines.coroutines.splice(t, 1);
        else if (Coroutines.coroutines[t].entity.enabled) {
          Coroutines.coroutines[t].fun() &&
            (Coroutines.coroutines[t].onComplete(),
            Coroutines.coroutines.splice(t, 1));
        }
      for (; Coroutines.onEndOfFrameCallbacks.length > 0; )
        Coroutines.onEndOfFrameCallbacks[0](),
          Coroutines.onEndOfFrameCallbacks.shift();
    }
    static AddOnEndOfFrameCallback(e) {
      Coroutines.onEndOfFrameCallbacks.push(e);
    }
    static StartCoroutineForEntity(e, t, a) {
      Coroutines.coroutines.push({ entity: e, fun: t, onComplete: a });
    }
    static StopCoroutineForEntity(e) {
      for (var t = Coroutines.coroutines.length; t-- > 0; )
        Coroutines.coroutines[t].entity == e &&
          Coroutines.coroutines.splice(t, 1);
    }
  }
  (Coroutines.__name__ = "Coroutines"),
    (Coroutines.__super__ = ScriptComponent),
    Object.assign(Coroutines.prototype, { __class__: Coroutines });
  class CurrencyCollector extends ScriptComponent {
    constructor(e) {
      super(e),
        (this.isMoving = !1),
        (this.startRots = null),
        (this.startPoses = null),
        (this.sended = 0),
        (this.items = null);
    }
    update(e) {
      if ((super.update(e), this.isMoving))
        for (var t = 0, a = this.items.length; t < a; ) {
          var n = t++;
          if (this.items[n].enabled) {
            this.dist = _$Vector3_Vector3_$Impl_$
              .sub(
                this.items[n].getPosition().clone(),
                this.targetPoint.getPosition().clone()
              )
              .length();
            var i = this.items[n],
              s = this.items[n].getPosition().clone(),
              r = this.targetPoint.getPosition().clone(),
              o = e / (this.dist / this.speed[n]);
            o = o > 1 ? 1 : o < 0 ? 0 : o;
            var l = s.x + (r.x - s.x) * o,
              u = s.y + (r.y - s.y) * o,
              c = s.z + (r.z - s.z) * o;
            null == c && (c = 0), null == u && (u = 0), null == l && (l = 0);
            var h = new pc.Vec3(l, u, c);
            i.setPosition(h);
            var p = this.items[n],
              m = this.items[n].getRotation().clone(),
              _ = _$Quaternion_Quaternion_$Impl_$.get_IDENTITY(),
              d = e / (this.dist / this.speed[n]);
            d = d > 1 ? 1 : d < 0 ? 0 : d;
            var g = _$Quaternion_Quaternion_$Impl_$.slerp(
              _$Quaternion_Quaternion_$Impl_$.clone(m),
              m,
              _,
              d
            );
            p.setRotation(g), this.dist < 0.002 && this.ItemSent(n);
          }
        }
    }
    DoStart(e) {
      (this.Callback = e),
        (this.startPoses = []),
        (this.startRots = []),
        (this.speed = []),
        (this.sended = 0);
      for (var t = 0, a = this.items.length; t < a; ) {
        var n = t++;
        this.startPoses.push(this.items[n].getPosition().clone()),
          this.startRots.push(this.items[n].getRotation().clone());
        var i = this.minSpeed;
        this.speed.push(0.001 * (i + (this.maxSpeed - i) * Math.random()));
      }
      this.isMoving = !0;
    }
    ItemSent(e) {
      this.items[e].enabled = !1;
      var t = this.startPoses[e];
      this.items[e].setPosition(t);
      var a = this.startRots[e];
      this.items[e].setRotation(a),
        null != UIManager.inst &&
          UIManager.inst.AddCurrency(
            this.amountToAdd / this.items.length + 1e-4,
            this.currencyName
          ),
        (this.sended += 1),
        this.sended >= this.items.length &&
          ((this.isMoving = !1), this.ItemsSended());
    }
    ItemsSended() {
      var e = "coins";
      "Currency_1" == this.currencyName
        ? (e = "coins")
        : "Currency_2" == this.currencyName && (e = "gems"),
        UIManager.inst.OnCurrencyAdded(
          this.amountToAdd,
          e,
          "Meta",
          null == this.analyticsId || "" == this.analyticsId
            ? "CurrencyCollector"
            : this.analyticsId
        ),
        (this.startPoses = []),
        (this.startRots = []),
        (this.speed = []),
        (this.amountToAdd = 0),
        null != this.Callback && (this.Callback(!0), (this.Callback = null));
    }
  }
  (CurrencyCollector.__name__ = "CurrencyCollector"),
    (CurrencyCollector.__super__ = ScriptComponent),
    Object.assign(CurrencyCollector.prototype, {
      __class__: CurrencyCollector,
    });
  class EntityHelper {
    static GetComponent_ShopItems(e, t) {
      var a = t;
      if (
        null != e.script &&
        null != e.script.scripts &&
        e.script.scripts.length > 0
      )
        for (var n = 0, i = e.script.scripts; n < i.length; ) {
          var s = i[n];
          if ((++n, js_Boot.__instanceof(s, a))) return s;
        }
      return null;
    }
    static GetComponentsInChildren_SpriteMasked(e, t) {
      return EntityHelper.GetComponentsInChildrenByScriptClass(e, t);
    }
    static GetComponent_TimerDailySpin(e, t) {
      var a = t;
      if (
        null != e.script &&
        null != e.script.scripts &&
        e.script.scripts.length > 0
      )
        for (var n = 0, i = e.script.scripts; n < i.length; ) {
          var s = i[n];
          if ((++n, js_Boot.__instanceof(s, a))) return s;
        }
      return null;
    }
    static GetComponent_Stopper(e, t) {
      var a = t;
      if (
        null != e.script &&
        null != e.script.scripts &&
        e.script.scripts.length > 0
      )
        for (var n = 0, i = e.script.scripts; n < i.length; ) {
          var s = i[n];
          if ((++n, js_Boot.__instanceof(s, a))) return s;
        }
      return null;
    }
    static GetComponent_SpinItem(e, t) {
      var a = t;
      if (
        null != e.script &&
        null != e.script.scripts &&
        e.script.scripts.length > 0
      )
        for (var n = 0, i = e.script.scripts; n < i.length; ) {
          var s = i[n];
          if ((++n, js_Boot.__instanceof(s, a))) return s;
        }
      return null;
    }
    static GetComponent_SubLvlBtn(e, t) {
      var a = t;
      if (
        null != e.script &&
        null != e.script.scripts &&
        e.script.scripts.length > 0
      )
        for (var n = 0, i = e.script.scripts; n < i.length; ) {
          var s = i[n];
          if ((++n, js_Boot.__instanceof(s, a))) return s;
        }
      return null;
    }
    static GetComponent_OfflineReward(e, t) {
      var a = t;
      if (
        null != e.script &&
        null != e.script.scripts &&
        e.script.scripts.length > 0
      )
        for (var n = 0, i = e.script.scripts; n < i.length; ) {
          var s = i[n];
          if ((++n, js_Boot.__instanceof(s, a))) return s;
        }
      return null;
    }
    static GetComponent_CoinsCollector(e, t) {
      var a = t;
      if (
        null != e.script &&
        null != e.script.scripts &&
        e.script.scripts.length > 0
      )
        for (var n = 0, i = e.script.scripts; n < i.length; ) {
          var s = i[n];
          if ((++n, js_Boot.__instanceof(s, a))) return s;
        }
      return null;
    }
    static GetComponent_GiftBox(e, t) {
      var a = t;
      if (
        null != e.script &&
        null != e.script.scripts &&
        e.script.scripts.length > 0
      )
        for (var n = 0, i = e.script.scripts; n < i.length; ) {
          var s = i[n];
          if ((++n, js_Boot.__instanceof(s, a))) return s;
        }
      return null;
    }
    static GetComponentInParent_GiftBoxSystem(e, t) {
      if (null == e) return null;
      for (var a = t, n = pc.app.root, i = e; null != i && i != n; ) {
        if (
          null != i.script &&
          null != i.script.scripts &&
          i.script.scripts.length > 0
        )
          for (var s = 0, r = i.script.scripts; s < r.length; ) {
            var o = r[s];
            if ((++s, js_Boot.__instanceof(o, a))) return o;
          }
        i = i.parent;
      }
      return null;
    }
    static GetComponent_CoinsCollectorScreenSpaceCam(e, t) {
      var a = t;
      if (
        null != e.script &&
        null != e.script.scripts &&
        e.script.scripts.length > 0
      )
        for (var n = 0, i = e.script.scripts; n < i.length; ) {
          var s = i[n];
          if ((++n, js_Boot.__instanceof(s, a))) return s;
        }
      return null;
    }
    static GetComponent_TutorialManager(e, t) {
      var a = t;
      if (
        null != e.script &&
        null != e.script.scripts &&
        e.script.scripts.length > 0
      )
        for (var n = 0, i = e.script.scripts; n < i.length; ) {
          var s = i[n];
          if ((++n, js_Boot.__instanceof(s, a))) return s;
        }
      return null;
    }
    static GetComponentInChildren_SortingGroup(e, t) {
      return EntityHelper.GetComponentInChildrenByScriptClass(e, t);
    }
    static GetComponentInChildren_TubeData(e, t) {
      return EntityHelper.GetComponentInChildrenByScriptClass(e, t);
    }
    static GetComponentsInChildren_ShopItems(e, t) {
      return EntityHelper.GetComponentsInChildrenByScriptClass(e, t);
    }
    static GetComponentsInChildren_OfflineReward(e, t) {
      return EntityHelper.GetComponentsInChildrenByScriptClass(e, t);
    }
    static GetComponentsInChildren_TimerDailySpin(e, t) {
      return EntityHelper.GetComponentsInChildrenByScriptClass(e, t);
    }
    static GetComponent_CurrencyCollector(e, t) {
      var a = t;
      if (
        null != e.script &&
        null != e.script.scripts &&
        e.script.scripts.length > 0
      )
        for (var n = 0, i = e.script.scripts; n < i.length; ) {
          var s = i[n];
          if ((++n, js_Boot.__instanceof(s, a))) return s;
        }
      return null;
    }
    static GetComponent_TubeData(e, t) {
      var a = t;
      if (
        null != e.script &&
        null != e.script.scripts &&
        e.script.scripts.length > 0
      )
        for (var n = 0, i = e.script.scripts; n < i.length; ) {
          var s = i[n];
          if ((++n, js_Boot.__instanceof(s, a))) return s;
        }
      return null;
    }
    static GetComponent_TubeController(e, t) {
      var a = t;
      if (
        null != e.script &&
        null != e.script.scripts &&
        e.script.scripts.length > 0
      )
        for (var n = 0, i = e.script.scripts; n < i.length; ) {
          var s = i[n];
          if ((++n, js_Boot.__instanceof(s, a))) return s;
        }
      return null;
    }
    static AddComponent_LevelManager(e, t) {
      var a = t.__name__;
      return (
        (a = a.charAt(0).toLowerCase() + HxOverrides.substr(a, 1, null)),
        null == e.script && e.addComponent("script"),
        e.script.create(a),
        e.script.get(a)
      );
    }
    static GetComponentsInChildren_TubeController(e, t) {
      return EntityHelper.GetComponentsInChildrenByScriptClass(e, t);
    }
    static GetComponentsInChildren_LevelManager(e, t) {
      return EntityHelper.GetComponentsInChildrenByScriptClass(e, t);
    }
    static GetComponentInChildren_AdLoadingIcon(e, t) {
      return EntityHelper.GetComponentInChildrenByScriptClass(e, t);
    }
    static GetComponentInChildren_GameConfig(e, t) {
      return EntityHelper.GetComponentInChildrenByScriptClass(e, t);
    }
    static GetComponentInChildrenByScriptClass(e, t) {
      var a = null;
      if (
        null != e.script &&
        null != e.script.scripts &&
        e.script.scripts.length > 0
      )
        for (var n = 0, i = e.script.scripts; n < i.length; ) {
          var s = i[n];
          if ((++n, js_Boot.__instanceof(s, t))) return s;
        }
      for (var r = 0, o = e.children.length; r < o; ) {
        var l = r++;
        if (
          null !=
          (a = EntityHelper.GetComponentInChildrenByScriptClass(
            e.children[l],
            t
          ))
        )
          return a;
      }
      return a;
    }
    static GetComponentsInChildrenByScriptClass(e, t, a) {
      var n = null != a ? a : [];
      if (
        null != e.script &&
        null != e.script.scripts &&
        e.script.scripts.length > 0
      )
        for (var i = 0, s = e.script.scripts; i < s.length; ) {
          var r = s[i];
          ++i, js_Boot.__instanceof(r, t) && n.push(r);
        }
      for (var o = 0, l = e.children.length; o < l; ) {
        var u = o++;
        EntityHelper.GetComponentsInChildrenByScriptClass(e.children[u], t, n);
      }
      return n;
    }
    static Instantiate(e, t) {
      var a = e.clone();
      return null == t ? pc.app.root.addChild(a) : t.addChild(a), a;
    }
    static InstantiatePrefab(e, t) {
      var a = e.resource.instantiate();
      return null == a
        ? null
        : (null == t ? pc.app.root.addChild(a) : t.addChild(a), a);
    }
    static SetActive(e, t) {
      e.enabled = t;
    }
  }
  EntityHelper.__name__ = "EntityHelper";
  class EntityTween {
    static DOLocalMove(e, t, a, n) {
      null == n && (n = !0);
      var i = e.getLocalPosition();
      return motion_Actuate.update(
        $bind(e, e.setLocalPosition),
        a,
        [i.x, i.y, i.z],
        [t.x, t.y, t.z],
        n
      );
    }
    static DOMove(e, t, a, n) {
      null == n && (n = !0);
      var i = e.getPosition();
      return motion_Actuate.update(
        $bind(e, e.setPosition),
        a,
        [i.x, i.y, i.z],
        [t.x, t.y, t.z],
        n
      );
    }
    static DOScale(e, t, a, n) {
      null == n && (n = !0);
      var i = e.getLocalScale();
      return motion_Actuate.update(
        $bind(e, e.setLocalScale),
        a,
        [i.x, i.y, i.z],
        [t.x, t.y, t.z],
        n
      );
    }
    static DOLocalRotateQuaternion(e, t, a, n) {
      return (
        null == n && (n = !0),
        motion_Actuate.update(
          EntityTween.slerpAndSetEntityLocalRotation,
          a,
          [e, e.getLocalRotation(), t, 0],
          [e, e.getLocalRotation(), t, 1],
          n
        )
      );
    }
    static slerpAndSetEntityLocalRotation(e, t, a, n) {
      e.setLocalRotation(new pc.Quat().slerp(t, a, n));
    }
    static DORotateQuaternion(e, t, a, n) {
      return (
        null == n && (n = !0),
        motion_Actuate.update(
          EntityTween.slerpAndSetEntityLocalRotation,
          a,
          [e, e.getRotation(), t, 0],
          [e, e.getRotation(), t, 1],
          n
        )
      );
    }
    static slerpAndSetEntityRotation(e, t, a, n) {
      e.setRotation(new pc.Quat().slerp(t, a, n));
    }
  }
  EntityTween.__name__ = "EntityTween";
  class GameConfig extends ScriptComponent {
    constructor(e) {
      super(e), (this.isInitialized = !1);
    }
    initialize() {
      super.initialize(), (GameConfig._inst = this);
    }
    Initialize() {
      this.isInitialized = !0;
    }
    static get_inst() {
      return (
        null == GameConfig._inst &&
          (GameConfig._inst = EntityHelper.GetComponentInChildren_GameConfig(
            pc.app.root,
            GameConfig
          )),
        GameConfig._inst
      );
    }
    static get_numLevelSkips() {
      return (
        GameConfig.set_numLevelSkips(GameManager.get_SkipLvlCount()),
        GameConfig.numLevelSkips
      );
    }
    static set_numLevelSkips(e) {
      return (
        (GameConfig.numLevelSkips = e),
        GameManager.set_SkipLvlCount(GameConfig.get_numLevelSkips()),
        GameConfig.get_numLevelSkips()
      );
    }
  }
  (GameConfig.__name__ = "GameConfig"),
    (GameConfig.__properties__ = {
      set_numLevelSkips: "set_numLevelSkips",
      get_numLevelSkips: "get_numLevelSkips",
      get_inst: "get_inst",
    }),
    (GameConfig.__super__ = ScriptComponent),
    Object.assign(GameConfig.prototype, { __class__: GameConfig });
  class GameLoseScreen extends ScriptComponent {
    constructor(e) {
      super(e),
        (this.inited = !1),
        (this.allBtnsEntities = []),
        (this.isActive = !1);
    }
    initialize() {
      (GameLoseScreen.inst = this), super.initialize();
      for (
        var e = this.entity.findComponents("button"), t = 0, a = e.length;
        t < a;

      ) {
        var n = t++;
        this.allBtnsEntities.push(e[n].entity);
      }
      this.init();
    }
    init() {
      this.inited ||
        ((this.inited = !0),
        (this.top = this.entity.findByPath("Top")),
        (this.topInitLocPos = this.top.getLocalPosition().clone()),
        (this.topBar = this.entity.findByPath("TopBar")),
        (this.topBarInitLocPos = this.topBar.getLocalPosition().clone()));
    }
    activate() {
      this.init(), (this.entity.enabled = !0), this.startApearAnim();
      for (var e = [], t = 0, a = this.allBtnsEntities; t < a.length; ) {
        var n = a[t];
        ++t, n.enabled && ((n.enabled = !1), e.push(n));
      }
      APIManager.GameInterface.showInterstitialAd("break:fail").then(
        function () {
          for (var t = 0; t < e.length; ) {
            var a = e[t];
            ++t, (a.enabled = !0);
          }
        }
      );
    }
    deactivate() {
      this.entity.enabled = !1;
    }
    startApearAnim() {
      this.entity.anim.baseLayer.play("ActivateAnim"),
        this.entity.anim.update(0.001);
      var e = this.top.getLocalPosition().clone(),
        t = this.topBar.getLocalPosition().clone(),
        a = this.top,
        n = a.getLocalPosition().clone(),
        i = 0,
        s = 300,
        r = 0;
      null == r && (r = 0), null == s && (s = 0), null == i && (i = 0);
      var o = new pc.Vec3(i, s, r),
        l = new pc.Vec3(n.x + o.x, n.y + o.y, n.z + o.z);
      a.setLocalPosition(l);
      var u = this.topBar,
        c = u.getLocalPosition().clone(),
        h = 0,
        p = 300,
        m = 0;
      null == m && (m = 0), null == p && (p = 0), null == h && (h = 0);
      var _ = new pc.Vec3(h, p, m),
        d = new pc.Vec3(c.x + _.x, c.y + _.y, c.z + _.z);
      u.setLocalPosition(d),
        (e.y = this.topInitLocPos.y),
        (t.y = this.topBarInitLocPos.y);
      var g = this.top,
        y = g.getLocalPosition();
      motion_Actuate
        .update(
          $bind(g, g.setLocalPosition),
          0.5,
          [y.x, y.y, y.z],
          [e.x, e.y, e.z],
          !0
        )
        .ease(motion_easing_Sine.easeInOut);
      var v = this.topBar,
        b = v.getLocalPosition();
      motion_Actuate
        .update(
          $bind(v, v.setLocalPosition),
          0.5,
          [b.x, b.y, b.z],
          [t.x, t.y, t.z],
          !0
        )
        .ease(motion_easing_Sine.easeInOut);
    }
    static Activate() {
      null != GameLoseScreen.inst && GameLoseScreen.inst.activate();
    }
    static Deactivate() {
      null != GameLoseScreen.inst && GameLoseScreen.inst.deactivate();
    }
  }
  (GameLoseScreen.__name__ = "GameLoseScreen"),
    (GameLoseScreen.__super__ = ScriptComponent),
    Object.assign(GameLoseScreen.prototype, { __class__: GameLoseScreen });
  class GameManager extends ScriptComponent {
    constructor(e) {
      super(e),
        (this.isKeyAssign = !1),
        (this.giveKey = !1),
        (this.isRedoing = !1);
    }
    get_isWithoutUILvl() {
      return 0 == GameManager.currLvlNum;
    }
    initialize() {
      super.initialize(),
        (GameManager.inst = this),
        GameConfig.get_inst().Initialize(),
        this.Start();
    }
    Start() {
      this.isFirstTime && (this.isFirstTime = !1);
      var e = PlayerPrefs.GetInt(
        "Mode_" + PlayerPrefs.GetInt("CurrModeNum", 1) + "_LvlUnlocked",
        1
      );
      PlayerPrefs.SetInt("CurrLvlNum", e),
        this.isMakingLevel ||
          (PlayerPrefs.GetBool("IsTutorialPlayed", !1) &&
            this.InstantiateNewLevel(function (e) {})),
        this.isMakingLevel && this.GenerateLvlFromPreset(),
        this.CheckConfig();
    }
    CheckConfig() {
      this.OnGameConfigLoaded();
    }
    OnGameConfigLoaded() {}
    InstantiateNewLevel(e, t) {
      null == t && (t = !1);
      var a = this;
      if ((t || Main.GameReadySent || (t = !0), !t))
        return (
          (GameManager.currLvlNum = PlayerPrefs.GetInt("CurrLvlNum", 1) - 1),
          GameManager.currLvlNum >=
            GameManager.inst.modes[GameManager.currModeNum - 1].totalLvls &&
            (GameManager.currLvlNum = 0),
          void APIManager.GameInterface.gameStart(
            GameManager.currLvlNum + 1
          ).then(function () {
            a.InstantiateNewLevel(e, !0);
          })
        );
      this.DestroyLevel();
      (this.isTutorialLvl = !PlayerPrefs.GetBool("IsTutorialPlayed", !1)),
        (GameManager.currModeNum = PlayerPrefs.GetInt("CurrModeNum", 1)),
        (GameManager.currModeName =
          GameManager.inst.modes[GameManager.currModeNum - 1].name),
        (GameManager.currMode = GameManager.currModeNum - 1),
        (GameManager.currLvlNum = PlayerPrefs.GetInt("CurrLvlNum", 1) - 1),
        haxe_Log.trace(
          "!!! instantiate currLvlNum : " + GameManager.currLvlNum,
          {
            fileName: "src/GameManager.hx",
            lineNumber: 248,
            className: "GameManager",
            methodName: "InstantiateNewLevel",
          }
        ),
        GameManager.currLvlNum >=
          GameManager.inst.modes[GameManager.currModeNum - 1].totalLvls &&
          (GameManager.currLvlNum = 0);
      var n,
        i = PlayerPrefs.GetBool(
          "Mode_" +
            GameManager.currModeNum +
            "_Lvl_" +
            (GameManager.currLvlNum + 1) +
            "_KeyPicked",
          !1
        );
      if (((this.giveKey = !i), (this.isKeyAssign = !1), this.isTutorialLvl))
        haxe_Log.trace("!!! instantiate tuto lvl", {
          fileName: "src/GameManager.hx",
          lineNumber: 263,
          className: "GameManager",
          methodName: "InstantiateNewLevel",
        }),
          (UIManager.inst.tutorialAnim.enabled = !0),
          (this.currLvlObj = EntityHelper.InstantiatePrefab(
            UIManager.inst.tutorialPrefab
          )),
          (LevelManager.tubes =
            EntityHelper.GetComponentsInChildren_TubeController(
              this.currLvlObj,
              TubeController
            )),
          this.OnInstantiateLvl(),
          (UIManager.isGameplaying = !0);
      else if (-1 != [1, 2].indexOf(GameManager.currLvlNum + 1)) {
        haxe_Log.trace("!!! instantiate ftue lvl", {
          fileName: "src/GameManager.hx",
          lineNumber: 270,
          className: "GameManager",
          methodName: "InstantiateNewLevel",
        }),
          (n =
            "LevelPresets/_FTUE/Level " +
            GameManager.intTo3DigString(GameManager.currLvlNum + 1)),
          (this.lvlPreset = LevelsImporter.GetColorWaterLevelByPath(n)),
          this.GenerateLvlFromPreset(),
          this.OnInstantiateLvl();
        var s = this.currLvlObj,
          r = 0,
          o = -1,
          l = 0;
        null == l && (l = 0), null == o && (o = 0), null == r && (r = 0);
        var u = new pc.Vec3(r, o, l);
        s.setPosition(u), e(!0);
      } else {
        if (
          (haxe_Log.trace(
            "!!! next level number is : " + (GameManager.currLvlNum + 1),
            {
              fileName: "src/GameManager.hx",
              lineNumber: 278,
              className: "GameManager",
              methodName: "InstantiateNewLevel",
            }
          ),
          (n =
            "LevelPresets/" +
            GameManager.inst.modes[GameManager.currModeNum - 1].name +
            "/Level " +
            GameManager.intTo3DigString(GameManager.currLvlNum + 1)),
          "Classic" == GameManager.inst.modes[GameManager.currModeNum - 1].name)
        ) {
          var c = "LvlVar_" + (GameManager.currLvlNum + 1);
          1 == PlayerPrefs.GetInt(c, 0) &&
            -1 !=
              GameManager.inst.lvlsHaveVarient.indexOf(
                GameManager.currLvlNum + 1
              ) &&
            (n += " b");
        }
        try {
          haxe_Log.trace("!!! generate lvl", {
            fileName: "src/GameManager.hx",
            lineNumber: 288,
            className: "GameManager",
            methodName: "InstantiateNewLevel",
          }),
            (this.lvlPreset = LevelsImporter.GetColorWaterLevelByPath(n)),
            this.GenerateLvlFromPreset(),
            this.OnInstantiateLvl();
          var h = this.currLvlObj,
            p = 0,
            m = -1,
            _ = 0;
          null == _ && (_ = 0), null == m && (m = 0), null == p && (p = 0);
          var d = new pc.Vec3(p, m, _);
          h.setPosition(d), e(!0);
        } catch (t) {
          t instanceof js__$Boot_HaxeError && t.val;
          e(!1);
        }
      }
      haxe_Log.trace("!!! check for playgap reward", {
        fileName: "src/GameManager.hx",
        lineNumber: 299,
        className: "GameManager",
        methodName: "InstantiateNewLevel",
      });
    }
    GenerateLvlFromPreset() {
      if (
        ((this.isKeyAssign = !1),
        (this.currLvlObj = new pc.Entity(this.lvlPreset.name)),
        pc.app.root.addChild(this.currLvlObj),
        GameManager.currLvlNum <= 0 && null != this.instTxtPrefab)
      )
        EntityHelper.InstantiatePrefab(this.instTxtPrefab, this.currLvlObj);
      var e,
        t = EntityHelper.AddComponent_LevelManager(
          this.currLvlObj,
          LevelManager
        );
      (t.colorsToSort = this.lvlPreset.tubesToSort),
        (t.minMoveToSort = this.lvlPreset.minMovesToSort),
        (t.minTimeToSort = this.lvlPreset.minTimeToSort);
      for (var a = 0, n = this.lvlPreset.tubes.length; a < n; ) {
        var i = a++;
        if (
          (((e = EntityHelper.GetComponent_TubeController(
            EntityHelper.InstantiatePrefab(this.tubePrefab, this.currLvlObj),
            TubeController
          )).filledColors = this.lvlPreset.tubes[i].waterNames.length),
          this.lvlPreset.haveKey &&
            !this.isKeyAssign &&
            0 ==
              PlayerPrefs.GetInt(
                "Mode_" +
                  GameManager.currModeNum +
                  "_Lvl_" +
                  (GameManager.currLvlNum + 1) +
                  "_KeyPicked",
                0
              ) &&
            this.lvlPreset.tubes[i].waterNames.length <= 0 &&
            ((e.haveKey = !0), this.AssignKey(e.entity)),
          this.lvlPreset.tubes[i].waterNames.length > 0)
        ) {
          (e.colorNames = []),
            (e.colorNames.length = this.lvlPreset.tubes[i].waterNames.length);
          for (var s = 0, r = e.colorNames.length; s < r; ) {
            var o = s++;
            0 != this.lvlPreset.tubes[i].waterNames[o]
              ? (e.colorNames[o] = this.lvlPreset.tubes[i].waterNames[o])
              : haxe_Log.trace("color num never be zero(0)", {
                  fileName: "src/GameManager.hx",
                  lineNumber: 349,
                  className: "GameManager",
                  methodName: "GenerateLvlFromPreset",
                });
          }
        } else e.colorNames = [];
        e.waitesInit = !0;
      }
      0 != GameConfig.get_inst().useGhostTube &&
        null != this.lvlPreset &&
        this.lvlPreset.useGhostTube &&
        ((1 == GameConfig.get_inst().useGhostTube &&
          GameManager.currLvlNum >= 5) ||
          (2 == GameConfig.get_inst().useGhostTube &&
            GameManager.currLvlNum >= 9)) &&
        (((e = EntityHelper.GetComponent_TubeController(
          EntityHelper.InstantiatePrefab(this.tubePrefab, this.currLvlObj),
          TubeController
        )).colorNames = []),
        e.SetAsGhostTube(),
        (e.waitesInit = !0)),
        t.LevelEnabled();
    }
    OnInstantiateLvl() {
      (GameManager.lvlLoaded += 1),
        (GameManager.recordingNodes = []),
        (GameManager.recordingNodes2 = []),
        GameManager.lvlLoaded >= 5 && (GameManager.lvlLoaded = 0);
    }
    DestroyLevel() {
      if (null != this.currLvlObj) {
        this.currLvlObj.destroy();
        for (
          var e = EntityHelper.GetComponentsInChildren_LevelManager(
              pc.app.root,
              LevelManager
            ),
            t = 0;
          t < e.length;

        ) {
          var a = e[t];
          ++t, a.entity.destroy();
        }
      }
    }
    GetCurrTube() {
      return null != this.curTubeEntity
        ? this.curTubeEntity
        : (GameManager.LoadCurrTube(), this.GetCurrTube());
    }
    AssignKey(e) {
      if (!this.isKeyAssign && null != this.keyPrefab) {
        (this.isKeyAssign = !0),
          (this.keyObj = EntityHelper.InstantiatePrefab(this.keyPrefab, e));
        var t = this.keyObj,
          a = 0,
          n = 1.25,
          i = 0;
        null == i && (i = 0), null == n && (n = 0), null == a && (a = 0);
        var s = new pc.Vec3(a, n, i);
        t.setLocalPosition(s);
      }
    }
    Record_Redo(e) {
      if (
        this.isRedoing ||
        GameManager.recordingNodes.length <= 0 ||
        !UIManager.isGameplaying
      )
        e(!1);
      else {
        var t;
        this.isRedoing = !0;
        for (var a = 0; a < 1; ) {
          a++;
          if (
            GameManager.recordingNodes.length <= 0 ||
            GameManager.recordingNodes2.length <= 0
          )
            break;
          Coroutines.StopCoroutineForEntity(GameManager.inst.entity),
            GameManager.recordingNodes.pop();
          for (
            var n = 0, i = (t = GameManager.recordingNodes2.pop()).length;
            n < i;

          ) {
            var s = t[n++],
              r = s.tube;
            r.filledColors = s.filledColors;
            for (var o = 0, l = s.colorNames.length; o < l; ) {
              var u = o++;
              u > r.colorNames.length && (r.colorNames[u] = s.colorNames[u]);
            }
            r.data.anim.baseLayer.play("Tilt70R"),
              r.data.anim.update(1e5),
              r.SetTubeOnMatch(),
              r.data.anim.setTrigger("Start_" + s.filledColors),
              r.data.anim.update(1e5),
              r.data.stopTweenFoamColor(),
              r.SetTubeFoamColor();
            var c = r.startPos;
            r.entity.setPosition(c),
              (r.sendersList = []),
              (r.data.isTiltRev = !1),
              (r.isFliped = !1);
            var h = r.entity,
              p = _$Vector3_Vector3_$Impl_$.get_ONE();
            h.setLocalScale(p);
            var m = r.data.tubeBack,
              _ = Math.abs(r.data.tubeBack.getLocalScale().clone().x),
              d = 1,
              g = 0;
            null == g && (g = 0), null == d && (d = 0), null == _ && (_ = 0);
            var y = new pc.Vec3(_, d, g);
            m.setLocalScale(y),
              (r.isSendingStart = !1),
              r.SendingWater(!1),
              (r.tubeStage = TubeStage.Idle),
              (r.data.currRecPortionNum = r.filledColors),
              r.SetTubeOnMatch(),
              r.WaterReceived(),
              (r.data.particleParent.entity.enabled = !1);
            for (var v = 0, b = r.data.flows.length; v < b; ) {
              var f = v++;
              r.data.flows[f].flowPar.enabled = !1;
            }
          }
          1 != GameManager.currMode && UIManager.inst.movesUsed--;
        }
        if (
          (1 != GameManager.currMode && UIManager.inst.SetStarBarAndText(),
          LevelManager.inst.ReCountSortedTubes(),
          null != GameManager.tempFillerTube)
        ) {
          var S = GameManager.tempFillerTube.startPos;
          GameManager.tempFillerTube.entity.setPosition(S),
            (GameManager.tempFillerTube.tubeStage = TubeStage.Idle),
            (GameManager.tempFillerTube = null);
        }
        (this.isRedoing = !1), e(!0);
      }
    }
    WaterColorIndex(e) {
      var t = this.indexOfColorInArr(this.waterCols, e);
      return t > -1 ? t : 0;
    }
    ReturnFoamCol(e) {
      var t = this.indexOfColorInArr(this.waterCols, e);
      return -1 != t ? this.foamCols[t] : this.foamCols[0];
    }
    indexOfColorInArr(e, t) {
      for (var a = 0, n = e.length; a < n; ) {
        var i = a++;
        if (
          !(Math.abs(e[i].a - t.a) > 0.001) &&
          !(
            Math.abs(e[i].r - t.r) > 0.001 ||
            Math.abs(e[i].g - t.g) > 0.001 ||
            Math.abs(e[i].b - t.b) > 0.001
          )
        )
          return i;
      }
      return -1;
    }
    static get_SkipLvlCount() {
      return (
        -1 == GameManager._SkipLvlCount &&
          (GameManager._SkipLvlCount = PlayerPrefs.GetInt("SkipLvlCount", 0)),
        GameManager._SkipLvlCount
      );
    }
    static set_SkipLvlCount(e) {
      return (
        GameManager._SkipLvlCount != e && (GameManager._SkipLvlCount = e),
        PlayerPrefs.SetInt("SkipLvlCount", GameManager._SkipLvlCount),
        GameManager._SkipLvlCount
      );
    }
    static get_EmptyTubesCount() {
      return (
        -1 == GameManager._EmptyTubesCount &&
          (GameManager._EmptyTubesCount = PlayerPrefs.GetInt("EmptyTubes", 0)),
        GameManager._EmptyTubesCount
      );
    }
    static set_EmptyTubesCount(e) {
      return (
        GameManager._EmptyTubesCount != e && (GameManager._EmptyTubesCount = e),
        PlayerPrefs.SetInt("EmptyTubes", GameManager._EmptyTubesCount),
        GameManager._EmptyTubesCount
      );
    }
    static get_UndoMovesCount() {
      return (
        -1 == GameManager._UndoMovesCount &&
          (GameManager._UndoMovesCount = PlayerPrefs.GetInt("UndoMoves", 0)),
        GameManager._UndoMovesCount
      );
    }
    static set_UndoMovesCount(e) {
      return (
        GameManager._UndoMovesCount != e && (GameManager._UndoMovesCount = e),
        PlayerPrefs.SetInt("UndoMoves", GameManager._UndoMovesCount),
        GameManager._UndoMovesCount
      );
    }
    static get_HintCounts() {
      return (
        -1 == GameManager._HintCounts &&
          (GameManager._HintCounts = PlayerPrefs.GetInt("HintCounts", 0)),
        GameManager._HintCounts
      );
    }
    static set_HintCounts(e) {
      return (
        GameManager._HintCounts != e && (GameManager._HintCounts = e),
        PlayerPrefs.SetInt("HintCounts", GameManager._HintCounts),
        GameManager._HintCounts
      );
    }
    static intTo3DigString(e) {
      for (
        var t = null == e ? "null" : "" + e, a = "";
        a.length < 3 - t.length;

      )
        a += "0";
      return a + t;
    }
    static LoadCurrTube() {
      null != GameManager.inst.curTubeEntity &&
        GameManager.inst.curTubeEntity.destroy();
      var e = GameManager.inst.currTube.resource.instantiate();
      GameManager.inst.curTubeEntity = e;
      for (
        var t = "Tube_" + MainManager.pickedItemNum[0],
          a = null,
          n = pc.app.assets.findByTag("AllTubesData")[0].resources,
          i = 0,
          s = n.length;
        i < s;

      ) {
        var r = i++;
        if (n[r].tubeName == t) {
          a = n[r];
          break;
        }
      }
      if (null != a) {
        for (var o = a.overrides, l = 0, u = o.length; l < u; ) {
          var c = o[l++],
            h = GameManager.inst.curTubeEntity.findByPath(c.pt);
          if (null != h) {
            if (null != c.p) {
              var p = c.p[0],
                m = c.p[1],
                _ = c.p[2];
              null == _ && (_ = 0), null == m && (m = 0), null == p && (p = 0);
              var d = new pc.Vec3(p, m, _);
              h.setLocalPosition(d);
            }
            if (null != c.s) {
              var g = c.s[0],
                y = c.s[1],
                v = c.s[2];
              null == v && (v = 0), null == y && (y = 0), null == g && (g = 0);
              var b = new pc.Vec3(g, y, v);
              h.setLocalScale(b);
            }
            if (null != c.r) {
              var f = c.r[0],
                S = c.r[1],
                P = c.r[2];
              null == P && (P = 0), null == S && (S = 0), null == f && (f = 0);
              var M = new pc.Vec3(f, S, P);
              h.setLocalEulerAngles(M);
            }
            null != c.sp &&
              null != h.sprite &&
              (h.sprite.spriteAsset = GameManager.findSpriteAssetIDByPath(
                c.sp
              ));
          }
        }
        GameManager.LoadTubeCap();
      }
    }
    static LoadTubeCap() {
      if (null != GameManager.inst.curTubeEntity) {
        var e = EntityHelper.GetComponent_TubeData(
          GameManager.inst.curTubeEntity,
          TubeData
        );
        if (null != e) {
          var t = e.tickMark[3].findComponent("sprite");
          null != t &&
            (t.spriteAsset =
              UIManager.inst.corkSprite[MainManager.pickedItemNum[2] - 1].id);
        }
      }
    }
    static findSpriteAssetIDByPath(e) {
      for (
        var t = pc.app.assets,
          a = e.split("/"),
          n = t.findAll(a[a.length - 1], "sprite"),
          i = 0;
        i < n.length;

      ) {
        var s = n[i];
        ++i;
        var r = t.get(s.data.textureAtlasAsset);
        if (
          null != r &&
          null != r.data &&
          null != r.data.frames &&
          null != s.data.frameKeys &&
          Reflect.field(r.data.frames, s.data.frameKeys[0]).name == e
        )
          return s.id;
      }
      return null;
    }
    static MoveSenderToReceiver(e, t) {
      var a =
        e.get_PortionCanSend() < t.get_PortionCanReceive()
          ? e.get_PortionCanSend()
          : t.get_PortionCanReceive();
      (t.tempReceiving += a), (e.tempSending += a);
      var n = a,
        i = new Record(e, t, e.get_CurrLiqColor().clone(), n);
      GameManager.Record_AddNode(i), GameManager.MakeNewRedoRecord2();
      var s = GameManager.inst.fillerTubeAngle[4 - e.filledColors].x;
      (e.isSendingStart = !0), e.SendingWater(!0), e.CancelSendingInvoke();
      var r,
        o = t.GetNearFillPoint(e.entity);
      if (o.getLocalPosition().clone().x > 0) {
        e.isFliped = !0;
        var l = e.entity,
          u = -1,
          c = 1,
          h = 1;
        null == h && (h = 0), null == c && (c = 0), null == u && (u = 0);
        var p = new pc.Vec3(u, c, h);
        l.setLocalScale(p);
        var m = e.data.tubeBack,
          _ = -1 * e.data.tubeBack.getLocalScale().clone().x,
          d = 1,
          g = 0;
        null == g && (g = 0), null == d && (d = 0), null == _ && (_ = 0);
        var y = new pc.Vec3(_, d, g);
        m.setLocalScale(y);
      }
      null != UIManager.inst &&
        1 != GameManager.currMode &&
        ((UIManager.inst.movesUsed += 1), UIManager.inst.SetStarBarAndText()),
        (e.data.isTiltEnd = !1),
        e.data.anim.setTrigger("Tilt_" + e.filledColors);
      var v = e.entity.getPosition().clone();
      Coroutines.StartCoroutineForEntity(
        GameManager.inst.entity,
        function () {
          if (e.data.isTiltEnd || t.stopReceiving) return !0;
          for (var a = e.data.entity.getLocalEulerAngles().clone().z; a > 100; )
            a -= 180;
          for (; a < -100; ) a += 180;
          r = Math.abs(GameManager.GetEulerAngle(a)) / s;
          var n = e.entity,
            i = o.getPosition().clone(),
            l = r;
          l = l > 1 ? 1 : l < 0 ? 0 : l;
          var u = v.x + (i.x - v.x) * l,
            c = v.y + (i.y - v.y) * l,
            h = v.z + (i.z - v.z) * l;
          null == h && (h = 0), null == c && (c = 0), null == u && (u = 0);
          var p = new pc.Vec3(u, c, h);
          return n.setPosition(p), !1;
        },
        function () {
          var n = e.entity,
            i = o.getPosition().clone();
          n.setPosition(i), GameManager.ReceiverWait(e, t, a);
        }
      );
    }
    static ReceiverWait(e, t, a) {
      GameManager.SenderWait(e, t, a),
        MainManager.inst.PlayOneShot("WaterPour"),
        (e.haveKey || t.haveKey) &&
          null != GameManager.inst.keyObj &&
          ((e.haveKey = t.haveKey = !1),
          UIManager.inst.KeyPicked(GameManager.inst.keyObj));
      var n = e.get_CurrLiqColor();
      t.SetColorOnIndexToOnward(n);
      var i = 0,
        s = !0;
      Coroutines.StartCoroutineForEntity(
        GameManager.inst.entity,
        function () {
          return (
            s &&
              ((t.data.isReceiving = !0),
              GameManager.PlayReceiverAnimCut(t),
              t.filledColors++,
              t.SetTubeFoamColor(),
              t.tempReceiving--,
              (s = !1)),
            t.data.currRecPortionNum == t.filledColors && ((i += 1), (s = !0)),
            i >= a
          );
        },
        function () {
          t.sendersList.length <= 1 &&
            (t.get_IsColorsWillMatch()
              ? (t.SetTubeOnMatch2(!0), t.data.anim.setTrigger("Start_4_Shine"))
              : t.data.anim.setTrigger("Start_" + t.filledColors)),
            t.WaterReceived(),
            HxOverrides.remove(t.sendersList, e);
        }
      );
    }
    static SenderWait(e, t, a) {
      var n = GameManager.inst.fillerTubeAngle[4 - e.filledColors].x,
        i = t.GetFlow();
      i.flowRd.sprite.color = t.data.particleParent.color =
        e.get_CurrLiqColor();
      var s = i.flowScaler.getLocalScale().clone(),
        r = _$Vector3_Vector3_$Impl_$.clone(t.startPos);
      e.isFliped ? (s.x = -1 * Math.abs(s.x)) : (s.x = Math.abs(s.x));
      var o = GameManager.GetEulerAngle(
          e.data.entity.getEulerAngles().clone().z
        ),
        l = e.GetCurrTopPoint(o);
      i.flowPar.enabled = !0;
      var u = 0,
        c = !0;
      Coroutines.StartCoroutineForEntity(
        GameManager.inst.entity,
        function () {
          if (
            (c &&
              (GameManager.PlaySenderAnimCut(e),
              (e.data.currPortionNum = e.filledColors + 1),
              (c = !1)),
            e.data.currPortionNum != e.filledColors)
          ) {
            var n = Math.abs(
              l.getPosition().clone().y - t.get_LiquidSurfaceY()
            );
            (s.y = n),
              i.flowScaler.setLocalScale(s),
              (r.y = l.getPosition().clone().y),
              i.flowScaler.setPosition(r),
              (t.data.particleParent.entity.enabled = !0),
              t.SetBubbleOnTop();
          } else
            (c = !0),
              (e.filledColors -= 1),
              (e.tempSending -= 1),
              e.LerpFoamColor(),
              (u += 1);
          return u >= a;
        },
        function () {
          (i.flowPar.enabled = !1), (t.data.particleParent.entity.enabled = !1);
          var a,
            s = e.entity.getPosition().clone();
          e.data.anim.setTrigger("Tilt_R_" + e.filledColors),
            Coroutines.StartCoroutineForEntity(
              GameManager.inst.entity,
              function () {
                if (e.data.isTiltRev) return !0;
                for (
                  var t = e.data.entity.getLocalEulerAngles().clone().z;
                  t > 100;

                )
                  t -= 180;
                for (; t < -100; ) t += 180;
                a = Math.abs(GameManager.GetEulerAngle(t)) / (0 - n);
                var i = e.entity,
                  r = e.startPos,
                  o = 1 + a,
                  l = o > 1 ? 1 : o < 0 ? 0 : o;
                l = l > 1 ? 1 : l < 0 ? 0 : l;
                var u = s.x + (r.x - s.x) * l,
                  c = s.y + (r.y - s.y) * l,
                  h = s.z + (r.z - s.z) * l;
                null == h && (h = 0),
                  null == c && (c = 0),
                  null == u && (u = 0);
                var p = new pc.Vec3(u, c, h);
                return i.setPosition(p), !1;
              },
              function () {
                var a = e.startPos;
                e.entity.setPosition(a),
                  (e.data.isTiltRev = !1),
                  e.data.anim.setTrigger("Start_" + e.filledColors),
                  (e.isFliped = !1);
                var n = e.entity,
                  i = _$Vector3_Vector3_$Impl_$.get_ONE();
                n.setLocalScale(i);
                var s = e.data.tubeBack,
                  r = Math.abs(e.data.tubeBack.getLocalScale().clone().x),
                  o = 1,
                  l = 0;
                null == l && (l = 0),
                  null == o && (o = 0),
                  null == r && (r = 0);
                var u = new pc.Vec3(r, o, l);
                s.setLocalScale(u),
                  (e.isSendingStart = !1),
                  e.SendingWater(!1),
                  (e.tubeStage = TubeStage.Idle),
                  (e.data.currRecPortionNum = e.filledColors),
                  Coroutines.AddOnEndOfFrameCallback(function () {
                    t.get_IsColorsMatched() &&
                      null != LevelManager.inst &&
                      LevelManager.inst.ReCountSortedTubes(),
                      UIManager.isGameplaying &&
                        null != LevelManager.inst &&
                        LevelManager.inst.get_RemainColToSort() > 1 &&
                        !LevelManager.inst.get_IsReceiving() &&
                        !LevelManager.inst.get_IsSending() &&
                        (UIManager.inst.GetHintMove(!1),
                        (IngameMenu.inst.pauseBtn.element.useInput = !0)),
                      UIManager.get_RemainingMoves() <= 0 &&
                        UIManager.isGameplaying &&
                        1 != GameManager.currMode &&
                        (LevelManager.inst.get_IsSending() ||
                          UIManager.inst.GameLose());
                  });
              }
            );
        }
      );
    }
    static PlaySenderAnimCut(e) {
      switch (e.filledColors) {
        case 1:
          e.data.anim.baseLayer.play("FullAnim"),
            GameManager.setAnimStateNormalizedTime(e.data.anim, 0.75);
          break;
        case 2:
          e.data.anim.baseLayer.play("FullAnim"),
            GameManager.setAnimStateNormalizedTime(e.data.anim, 0.5);
          break;
        case 3:
          e.data.anim.baseLayer.play("FullAnim"),
            GameManager.setAnimStateNormalizedTime(e.data.anim, 0.25);
          break;
        case 4:
          e.data.anim.baseLayer.play("FullAnim"),
            GameManager.setAnimStateNormalizedTime(e.data.anim, 0);
          break;
        default:
          haxe_Log.trace("Unknown filled lvl=>" + e.filledColors, {
            fileName: "src/GameManager.hx",
            lineNumber: 715,
            className: "GameManager",
            methodName: "PlaySenderAnimCut",
          });
      }
    }
    static PlayReceiverAnimCut(e) {
      if (
        (e.data.anim.getTrigger("Start_0") &&
          e.data.anim.resetTrigger("Start_0"),
        "ReceiveFull" != e.data.anim.baseLayer.activeState)
      )
        switch (e.filledColors) {
          case 0:
            e.data.anim.baseLayer.play("ReceiveFull"),
              GameManager.setAnimStateNormalizedTime(e.data.anim, 0);
            break;
          case 1:
            e.data.anim.baseLayer.play("ReceiveFull"),
              GameManager.setAnimStateNormalizedTime(e.data.anim, 0.25);
            break;
          case 2:
            e.data.anim.baseLayer.play("ReceiveFull"),
              GameManager.setAnimStateNormalizedTime(e.data.anim, 0.5);
            break;
          case 3:
            e.data.anim.baseLayer.play("ReceiveFull"),
              GameManager.setAnimStateNormalizedTime(e.data.anim, 0.75);
            break;
          default:
            haxe_Log.trace("Unknown receive lvl=>" + e.filledColors, {
              fileName: "src/GameManager.hx",
              lineNumber: 728,
              className: "GameManager",
              methodName: "PlayReceiverAnimCut",
            });
        }
    }
    static setAnimStateNormalizedTime(e, t) {
      (e.baseLayer.activeStateCurrentTime = 0),
        e.baseLayer.update(
          (t * e.baseLayer.activeStateDuration) /
            e.speed /
            e.baseLayer._controller.activeState.speed
        );
    }
    static GetEulerAngle(e) {
      return e > 180 ? e - 360 : e;
    }
    static Record_AddNode(e) {
      GameManager.recordingNodes.length >= 20 &&
        GameManager.recordingNodes.shift(),
        GameManager.recordingNodes.push(e);
    }
    static MakeNewRedoRecord2() {
      GameManager.recordingNodes2.length >= 20 &&
        GameManager.recordingNodes2.shift();
      for (var e = [], t = 0, a = LevelManager.tubes.length; t < a; ) {
        var n = t++,
          i = LevelManager.tubes[n];
        e.push({
          tube: i,
          filledColors: i.filledColors,
          colorNames: i.colorNames.slice(),
        });
      }
      GameManager.recordingNodes2.push(e);
    }
  }
  (GameManager.__name__ = "GameManager"),
    (GameManager.__properties__ = {
      set_HintCounts: "set_HintCounts",
      get_HintCounts: "get_HintCounts",
      set_UndoMovesCount: "set_UndoMovesCount",
      get_UndoMovesCount: "get_UndoMovesCount",
      set_EmptyTubesCount: "set_EmptyTubesCount",
      get_EmptyTubesCount: "get_EmptyTubesCount",
      set_SkipLvlCount: "set_SkipLvlCount",
      get_SkipLvlCount: "get_SkipLvlCount",
    }),
    (GameManager.__super__ = ScriptComponent),
    Object.assign(GameManager.prototype, {
      __class__: GameManager,
      __properties__: Object.assign(
        {},
        ScriptComponent.prototype.__properties__,
        { get_isWithoutUILvl: "get_isWithoutUILvl" }
      ),
    });
  class Record {
    constructor(e, t, a, n) {
      (this.sendedPortions = 0),
        (this.color = _$Color_Color_$Impl_$.get_BLACK()),
        (this.receiverTube = null),
        (this.senderTube = null),
        null != e && (this.senderTube = e),
        null != t && (this.receiverTube = t),
        null != a && (this.color = a),
        null != n && (this.sendedPortions = n);
    }
  }
  (Record.__name__ = "Record"),
    Object.assign(Record.prototype, { __class__: Record });
  class Modes {
    constructor() {
      (this.totalLvls = 0),
        (this.starsToUnlock = 0),
        (this.achievedStars = 0),
        (this.name = "");
    }
  }
  (Modes.__name__ = "Modes"),
    Object.assign(Modes.prototype, { __class__: Modes });
  class GameSettings extends ScriptComponent {
    initialize() {
      super.initialize(),
        (GameSettings.inst = this),
        this.CLEAR_SAVES && PlayerPrefs.DeleteAll();
    }
  }
  (GameSettings.__name__ = "GameSettings"),
    (GameSettings.__super__ = ScriptComponent),
    Object.assign(GameSettings.prototype, { __class__: GameSettings });
  class GiftBox extends ScriptComponent {
    constructor(e) {
      super(e), (this.isBoxOpened = !1), (this.boxPrice = 0);
    }
    initialize() {
      super.initialize();
      var e = this;
      this.entity.anim.on(
        "SetActive",
        function (t) {
          return e.SetActiveFromAnimEv(t), !0;
        },
        this
      ),
        this.entity.anim.on(
          "BoxOpenAnimEnd",
          function (t) {
            return e.BoxOpenAnimEnd(), !0;
          },
          this
        ),
        this.entity.anim.on(
          "BoxOpenEvent",
          function (t) {
            return e.BoxOpenEvent(), !0;
          },
          this
        ),
        (this.giftBoxSystem = EntityHelper.GetComponentInParent_GiftBoxSystem(
          this.priceText,
          GiftBoxSystem
        ));
    }
    SetActiveFromAnimEv(e) {
      var t = "" == e.string ? this.entity : this.entity.findByPath(e.string);
      null != t && (t.enabled = 1 == e.number);
    }
    BoxOpenAnimEnd() {
      (!this.isTopRewardBox ||
        (this.isTopRewardBox &&
          null != this.giftBoxSystem &&
          this.giftBoxSystem.isPriceTopReward)) &&
        (this.priceText.enabled = !0),
        (this.entity.enabled = !1);
    }
    BoxOpenEvent() {
      GiftBoxSystem.inst.BlastConfetti(this);
    }
  }
  (GiftBox.__name__ = "GiftBox"),
    (GiftBox.__super__ = ScriptComponent),
    Object.assign(GiftBox.prototype, { __class__: GiftBox });
  class GiftBoxSystem extends ScriptComponent {
    constructor(e) {
      super(e),
        (this.moreKeysRwPlacement = "button.giftbox.morekeys"),
        (this.capNum = 0),
        (this.isRewardCap = !1),
        (this.isSoundOn = !0),
        (this.keysGiven = 0),
        (this.pickedKeys = 3),
        (this.topRewrdValue = 1),
        (this.canGetTopReward = !1),
        (this.keyImages = null),
        (this.giftBoxes = null),
        (this.boxPrices = null),
        (this.currCollector = 0),
        (this.coinsCollectors = null);
    }
    initialize() {
      super.initialize(), (GiftBoxSystem.inst = this), this.OnEnable();
      var e = this;
      this.entity.on(
        "state",
        function (t) {
          return t && e.OnEnable(), !0;
        },
        this
      );
      for (var t = 0, a = this.giftBoxes.length; t < a; ) {
        var n = t++,
          i = EntityHelper.GetComponent_GiftBox(this.giftBoxes[n], GiftBox),
          s = [n + 1];
        UIHelper.AddButtonClickHandler(
          js_Boot.__cast(i.priceText.parent, pc.Entity),
          (function (t) {
            return function () {
              e.UI_OnBoxClick(t[0]);
            };
          })(s)
        );
      }
      AdLoadingIcon.SetPlacementForEntity(
        this.getMoreKeysBtn,
        this.moreKeysRwPlacement
      ),
        UIHelper.AddButtonClickHandler(
          this.getMoreKeysBtn,
          $bind(this, this.UI_OnMoreKeysBtn)
        ),
        UIHelper.AddButtonClickHandler(
          this.continueBtn,
          $bind(this, this.UI_OnContinueBtn)
        );
    }
    OnEnable() {
      var e = this.grid.getLocalScale().clone(),
        t = this.grid,
        a = _$Vector3_Vector3_$Impl_$.mulN(e, 1e-4);
      t.setLocalScale(a);
      var n = this.grid,
        i = n.getLocalScale();
      motion_Actuate
        .update(
          $bind(n, n.setLocalScale),
          0.42,
          [i.x, i.y, i.z],
          [e.x, e.y, e.z],
          !0
        )
        .ease(motion_easing_Back.easeOut)
        .delay(0.17),
        (e = this.boxes3DCont.getLocalScale().clone());
      var s = this.boxes3DCont,
        r = _$Vector3_Vector3_$Impl_$.mulN(e, 1e-4);
      s.setLocalScale(r);
      var o = this.boxes3DCont,
        l = o.getLocalScale();
      motion_Actuate
        .update(
          $bind(o, o.setLocalScale),
          0.42,
          [l.x, l.y, l.z],
          [e.x, e.y, e.z],
          !0
        )
        .ease(motion_easing_Back.easeOut)
        .delay(0.17),
        (this.isSoundOn = 1 == PlayerPrefs.GetInt("Audio", 1)),
        (this.continueBtn.enabled = !1),
        (this.getMoreKeysBtn.enabled = !1);
      var u = Math.round(PlayerPrefs.GetFloat("Currency_1", 0));
      (this.coinsText.element.text = "" + u),
        this.SetKeysImage(),
        PlayerPrefs.SetInt("PickedKeys", 0);
      for (var c = []; c.length < this.giftBoxes.length; )
        c.push(Math.floor(this.boxPrices.length * Math.random()));
      for (var h = 0, p = this.giftBoxes.length; h < p; ) {
        var m = h++,
          _ = EntityHelper.GetComponent_GiftBox(this.giftBoxes[m], GiftBox);
        (_.boxPrice = this.boxPrices[c[m]]),
          (_.priceText.element.text = "" + _.boxPrice),
          (_.priceText.enabled = !1);
      }
      (this.canGetTopReward = 101 * Math.random() <= this.topRewardPercent),
        this.canGetTopReward &&
          (EntityHelper.GetComponent_GiftBox(
            this.giftBoxes[Math.floor(this.giftBoxes.length * Math.random())],
            GiftBox
          ).isTopRewardBox = !0);
      for (
        var d = [], g = UIManager.inst.capPanel2, y = 0, v = g.shopItems.length;
        y < v;

      ) {
        var b = y++;
        PlayerPrefs.GetBool(
          _$MainManager_ShopCategory_$Impl_$.ToString(
            g.shopItems[b].shopCategory
          ) + g.shopItems[b].itemNum,
          g.shopItems[b].defaultLocked
        ) && d.push(b + 10);
      }
      if (
        0 == Math.floor(2 * Math.random()) &&
        d.length > 0 &&
        GameConfig.get_inst().useCapShop
      ) {
        (this.capNum = d[Math.floor(d.length * Math.random())]),
          (this.topRewrdValue = this.capNum);
        try {
          var f =
            "Resources/ShopCaps/" +
            StringTools.lpad(this.capNum + "", "0", 3) +
            ".png";
          (this.topRewardImageCap.element.spriteAsset =
            GameManager.findSpriteAssetIDByPath(f)),
            (this.boxesRawImage_Cap.element.spriteAsset =
              this.topRewardImageCap.element.spriteAsset),
            (this.topRewardImageCap.enabled = !0),
            (this.isRewardCap = !0);
        } catch (e) {
          haxe_Log.trace(
            "Asset load exception=>" +
              Std.string(e instanceof js__$Boot_HaxeError ? e.val : e),
            {
              fileName: "src/GiftBoxSystem.hx",
              lineNumber: 131,
              className: "GiftBoxSystem",
              methodName: "OnEnable",
            }
          );
        }
      } else {
        var S = [];
        if (
          (PlayerPrefs.GetBool("Tube28", !0) && S.push(28),
          PlayerPrefs.GetBool("Tube29", !0) && S.push(29),
          PlayerPrefs.GetBool("Tube30", !0) && S.push(30),
          PlayerPrefs.GetBool("Tube31", !0) && S.push(31),
          PlayerPrefs.GetBool("Tube32", !0) && S.push(32),
          PlayerPrefs.GetBool("Tube33", !0) && S.push(33),
          PlayerPrefs.GetBool("Tube34", !0) && S.push(34),
          PlayerPrefs.GetBool("Tube35", !0) && S.push(35),
          PlayerPrefs.GetBool("Tube36", !0) && S.push(36),
          S.length > 0)
        ) {
          var P = Math.floor(S.length * Math.random());
          this.topRewrdValue = S[P];
          try {
            var M =
              "Resources/ShopBottles/" +
              StringTools.lpad(this.topRewrdValue + "", "0", 3) +
              ".png";
            (this.topRewardImageTube.element.spriteAsset =
              GameManager.findSpriteAssetIDByPath(M)),
              (this.boxesRawImage.element.spriteAsset =
                this.topRewardImageTube.element.spriteAsset),
              (this.topRewardImageTube.enabled = !0);
          } catch (e) {
            haxe_Log.trace(
              "Asset load exception=>" +
                Std.string(e instanceof js__$Boot_HaxeError ? e.val : e),
              {
                fileName: "src/GiftBoxSystem.hx",
                lineNumber: 153,
                className: "GiftBoxSystem",
                methodName: "OnEnable",
              }
            );
          }
        } else
          (this.isPriceTopReward = !0),
            (this.topRewrdValue = 500),
            (this.topRewardText.element.text = "" + this.topRewrdValue),
            (this.topRewardText.enabled = !0);
      }
    }
    BlastConfetti(e) {
      var t = e.entity.getPosition().clone();
      if (
        ((t.z = this.topRewardConfetti.getPosition().clone().z),
        (this.topRewardConfetti.enabled = !0),
        (t.y -= 1),
        this.topRewardConfetti.setPosition(t),
        this.topRewardConfetti.particlesystem.stop(),
        this.topRewardConfetti.particlesystem.reset(),
        this.topRewardConfetti.particlesystem.play(),
        this.isSoundOn && MainManager.inst.PlayOneShot("ProgressBoxOpen"),
        e.isTopRewardBox && !this.isPriceTopReward)
      )
        this.isRewardCap
          ? (this.boxesRawImage_Cap.enabled = !0)
          : (this.boxesRawImage.enabled = !0);
      else {
        e.isTopRewardBox && this.isPriceTopReward
          ? ((EntityHelper.GetComponent_CoinsCollectorScreenSpaceCam(
              this.coinsCollectors[this.currCollector],
              CoinsCollectorScreenSpaceCam
            ).totalCoinsToAdd = this.topRewrdValue),
            haxe_Log.trace(this.topRewrdValue + " Top price", {
              fileName: "src/GiftBoxSystem.hx",
              lineNumber: 182,
              className: "GiftBoxSystem",
              methodName: "BlastConfetti",
            }))
          : (EntityHelper.GetComponent_CoinsCollectorScreenSpaceCam(
              this.coinsCollectors[this.currCollector],
              CoinsCollectorScreenSpaceCam
            ).totalCoinsToAdd = e.boxPrice);
        var a = this.coinsCollectors[this.currCollector],
          n = e.priceText.getPosition().clone(),
          i = -0.1,
          s = 0,
          r = 0;
        null == r && (r = 0), null == s && (s = 0), null == i && (i = 0);
        var o = new pc.Vec3(i, s, r),
          l = new pc.Vec3(n.x + o.x, n.y + o.y, n.z + o.z);
        a.setPosition(l),
          (this.coinsCollectors[this.currCollector].enabled = !0),
          (this.currCollector += 1),
          this.currCollector >= this.coinsCollectors.length &&
            (this.currCollector = 0);
      }
    }
    UI_OnMoreKeysBtn() {
      null != MainManager.inst && MainManager.inst.PlayOneShot("BtnClick");
      var e = this;
      null != APIManager.inst
        ? APIManager.ShowRewardedAD(function (t) {
            t &&
              motion_Actuate.timer(0.1).onComplete($bind(e, e.MoreKeysReward));
          }, this.moreKeysRwPlacement)
        : haxe_Log.trace("AdsManager not found", {
            fileName: "src/GiftBoxSystem.hx",
            lineNumber: 206,
            className: "GiftBoxSystem",
            methodName: "UI_OnMoreKeysBtn",
          });
    }
    MoreKeysReward() {
      (this.keysGiven += 1),
        (this.pickedKeys = 3),
        (this.continueBtn.element.useInput = !0),
        (this.getMoreKeysBtn.enabled = !1),
        this.SetKeysImage();
    }
    UI_OnBoxClick(e) {
      if (!(this.pickedKeys <= 0)) {
        null != MainManager.inst && MainManager.inst.PlayOneShot("BtnClick");
        var t = this.GetGiftBox(e);
        if (!t.isBoxOpened) {
          (this.pickedKeys -= 1),
            this.pickedKeys <= 0 &&
              (this.keysGiven < 2
                ? ((this.infoText.enabled = !1),
                  (this.getMoreKeysBtn.enabled = !0),
                  this.OnOffGameObject(this.continueBtn, !0, 2))
                : ((this.getMoreKeysBtn.element.useInput = !1),
                  (this.continueBtn.element.useInput = !0)),
              APIManager.HasFeature("rewarded") ||
                (this.getMoreKeysBtn.enabled = !1)),
            this.isSoundOn && MainManager.inst.PlayOneShot("KeyUse");
          for (var a = 0, n = this.giftBoxes.length; a < n; ) {
            var i = a++;
            EntityHelper.GetComponent_GiftBox(this.giftBoxes[i], GiftBox)
              .isBoxOpened || this.giftBoxes[i].anim.setTrigger("Spin");
          }
          if (
            (t.anim.anim.setBoolean("ChestOpen", !0),
            (t.isBoxOpened = !0),
            t.isTopRewardBox && !this.isPriceTopReward)
          )
            if (this.isRewardCap) {
              this.boxesRawImage_Cap.reparent(t.priceText.parent);
              var s = _$Vector3_Vector3_$Impl_$.zero;
              this.boxesRawImage_Cap.setLocalPosition(s),
                PlayerPrefs.SetBool("Cap" + this.topRewrdValue, !1),
                MainManager.inst.NewItemUsing(2, this.topRewrdValue),
                haxe_Log.trace(this.topRewrdValue + " num Cap unlocked", {
                  fileName: "src/GiftBoxSystem.hx",
                  lineNumber: 262,
                  className: "GiftBoxSystem",
                  methodName: "UI_OnBoxClick",
                });
            } else {
              this.boxesRawImage.reparent(t.priceText.parent);
              var r = _$Vector3_Vector3_$Impl_$.zero;
              this.boxesRawImage.setLocalPosition(r),
                PlayerPrefs.SetBool("Tube" + this.topRewrdValue, !1),
                MainManager.inst.NewItemUsing(0, this.topRewrdValue),
                haxe_Log.trace(this.topRewrdValue + " num skin unlocked", {
                  fileName: "src/GiftBoxSystem.hx",
                  lineNumber: 270,
                  className: "GiftBoxSystem",
                  methodName: "UI_OnBoxClick",
                });
            }
          motion_Actuate.timer(0.1).onComplete($bind(this, this.SetKeysImage));
        }
      }
    }
    UI_OnContinueBtn() {
      null != MainManager.inst &&
        (MainManager.inst.PlayOneShot("BtnClick"),
        UIManager.inst.CloseChestPanel()),
        js_Boot.__cast(this.entity.parent, pc.Entity).destroy(),
        (GiftBoxSystem.inst = null);
    }
    GetGiftBox(e) {
      for (var t = 0, a = this.giftBoxes.length; t < a; ) {
        var n = t++,
          i = EntityHelper.GetComponent_GiftBox(this.giftBoxes[n], GiftBox);
        if (null != i && i.boxNumber == e) return i;
      }
      return null;
    }
    SetKeysImage() {
      for (var e = 0, t = this.keyImages.length; e < t; ) {
        var a = e++;
        a < this.pickedKeys
          ? (this.keyImages[a].enabled = !0)
          : (this.keyImages[a].enabled = !1);
      }
    }
    OnOffGameObject(e, t, a) {
      null == a && (a = 1),
        motion_Actuate.timer(a).onComplete(function () {
          e.enabled = t;
        });
    }
  }
  (GiftBoxSystem.__name__ = "GiftBoxSystem"),
    (GiftBoxSystem.__super__ = ScriptComponent),
    Object.assign(GiftBoxSystem.prototype, { __class__: GiftBoxSystem });
  class Helpers {
    static Delay(e, t) {
      motion_Actuate.timer(e).onComplete(t);
    }
  }
  Helpers.__name__ = "Helpers";
  class HxOverrides {
    static dateStr(e) {
      var t = e.getMonth() + 1,
        a = e.getDate(),
        n = e.getHours(),
        i = e.getMinutes(),
        s = e.getSeconds();
      return (
        e.getFullYear() +
        "-" +
        (t < 10 ? "0" + t : "" + t) +
        "-" +
        (a < 10 ? "0" + a : "" + a) +
        " " +
        (n < 10 ? "0" + n : "" + n) +
        ":" +
        (i < 10 ? "0" + i : "" + i) +
        ":" +
        (s < 10 ? "0" + s : "" + s)
      );
    }
    static strDate(e) {
      switch (e.length) {
        case 8:
          var t = e.split(":"),
            a = new Date();
          return (
            a.setTime(0),
            a.setUTCHours(t[0]),
            a.setUTCMinutes(t[1]),
            a.setUTCSeconds(t[2]),
            a
          );
        case 10:
          var n = e.split("-");
          return new Date(n[0], n[1] - 1, n[2], 0, 0, 0);
        case 19:
          var i = e.split(" "),
            s = i[0].split("-"),
            r = i[1].split(":");
          return new Date(s[0], s[1] - 1, s[2], r[0], r[1], r[2]);
        default:
          throw new js__$Boot_HaxeError("Invalid date format : " + e);
      }
    }
    static substr(e, t, a) {
      if (null == a) a = e.length;
      else if (a < 0) {
        if (0 != t) return "";
        a = e.length + a;
      }
      return e.substr(t, a);
    }
    static remove(e, t) {
      var a = e.indexOf(t);
      return -1 != a && (e.splice(a, 1), !0);
    }
    static iter(e) {
      return {
        cur: 0,
        arr: e,
        hasNext: function () {
          return this.cur < this.arr.length;
        },
        next: function () {
          return this.arr[this.cur++];
        },
      };
    }
  }
  HxOverrides.__name__ = "HxOverrides";
  class IngameMenu extends ScriptComponent {
    constructor(e) {
      super(e),
        (this.hintBtnPlacement = "button:game:hint"),
        (this.undoBtnPlacement = "button:game:undo"),
        (this.xTraTubeBtnPlacement = "button:game:extratube"),
        (this.skipBtnPlacement = "button:game:skiplevel"),
        (this.keys = []);
    }
    initialize() {
      super.initialize(),
        (IngameMenu.inst = this),
        (this.levelNumTxt = this.getChildByName("LvlNumText")),
        (this.movesTxt = this.getChildByName("MovesText")),
        (this.upBtnsCont = this.getChildByName("UpBtnsBg")),
        (this.skipLevelBtn = this.upBtnsCont.findByName("SkipLevelBtn")),
        (this.skipLevelBtnCounter = this.skipLevelBtn.findByName("Count")),
        (this.skipLevelRewIcon = this.skipLevelBtn.findByName("Play")),
        (this.btnSkipLevel = js_Boot.__cast(
          this.skipLevelBtn.findByName("Button"),
          pc.Entity
        ).button),
        (this.xTraTubeBtn = this.upBtnsCont.findByName("XtraTubeBtn")),
        (this.xTraTubeBtnCounter = this.xTraTubeBtn.findByName("Count")),
        (this.xTraTubeBtnRewIcon = this.xTraTubeBtn.findByName("Play")),
        (this.btnXTraTube = js_Boot.__cast(
          this.xTraTubeBtn.findByName("Button"),
          pc.Entity
        ).button),
        (this.undoBtn = this.upBtnsCont.findByName("UndoBtn")),
        (this.undoBtnCounter = this.undoBtn.findByName("Count")),
        (this.undoBtnRewIcon = this.undoBtn.findByName("Play")),
        (this.btnUndo = js_Boot.__cast(
          this.undoBtn.findByName("Button"),
          pc.Entity
        ).button),
        (this.hintBtn = this.upBtnsCont.findByName("HintBtn")),
        (this.hintBtnCounter = this.hintBtn.findByName("Count")),
        (this.hintBtnRewIcon = this.hintBtn.findByName("Play")),
        (this.btnHint = js_Boot.__cast(
          this.hintBtn.findByName("Button"),
          pc.Entity
        ).button),
        UIHelper.AddButtonClickHandler(
          this.skipLevelBtn.findByName("Button"),
          $bind(this, this.onSkipLevelClick)
        ),
        UIHelper.AddButtonClickHandler(
          this.xTraTubeBtn.findByName("Button"),
          $bind(this, this.onXTraTubeBtnClick)
        ),
        UIHelper.AddButtonClickHandler(
          this.undoBtn.findByName("Button"),
          $bind(this, this.onUndoBtnClick)
        ),
        UIHelper.AddButtonClickHandler(
          this.hintBtn.findByName("Button"),
          $bind(this, this.onHintBtnClick)
        ),
        (this.starsCont = this.getChildByName("StarsBg")),
        (this.starsFill = this.starsCont.findByName("StarsFillBar")),
        (this.initStarsFillWidth = this.starsFill.element.width),
        (this.star3 = this.starsCont.findByName("3rdStar")),
        (this.star2 = this.starsCont.findByName("2ndStar")),
        (this.star1 = this.starsCont.findByName("1stStar")),
        (this.line3 = this.starsCont.findByName("3rdLine")),
        (this.line2 = this.starsCont.findByName("2ndLine")),
        (this.line1 = this.starsCont.findByName("1stLine")),
        (this.gameplayKeysCont = this.getChildByName("GameplayKeys")),
        (this.gameplayKeysContInitPos = this.gameplayKeysCont
          .getLocalPosition()
          .clone()),
        (this.key1 = this.gameplayKeysCont.findByName("Key 1")),
        (this.key2 = this.gameplayKeysCont.findByName("Key 2")),
        (this.key3 = this.gameplayKeysCont.findByName("Key 3")),
        (this.starsBlast = this.gameplayKeysCont.findByName("StarsBlast")),
        (this.starsBlast.enabled = !1),
        this.keys.push(this.key1),
        this.keys.push(this.key2),
        this.keys.push(this.key3),
        (this.pauseBg = this.getChildByName("PauseBg")),
        (this.pauseBtn = this.pauseBg.findByName("PauseBtn")),
        this.updateBtns(),
        (this.entity.enabled = !1);
    }
    onLevelStarted() {
      (this.pauseBtn.element.useInput = !0),
        (this.levelNumTxt.element.text =
          "LEVEL: " + (GameManager.currLvlNum + 1)),
        (this.xTraTubeBtn.element.useInput = !0),
        (this.undoBtn.element.useInput = !0),
        (this.skipLevelBtn.element.useInput = !0),
        (this.hintBtn.element.useInput = !0),
        null !=
          js_Boot.__cast(this.star3.children[0], pc.Entity).element
            .spriteAsset &&
          (js_Boot.__cast(
            this.star3.children[0],
            pc.Entity
          ).element.spriteAsset =
            js_Boot.__cast(
              this.star2.children[0],
              pc.Entity
            ).element.spriteAsset =
            js_Boot.__cast(
              this.star1.children[0],
              pc.Entity
            ).element.spriteAsset =
              this.goldenStar.id),
        (this.star3.element.opacity =
          this.star2.element.opacity =
          this.star1.element.opacity =
            1),
        this.movesTxt.anim.baseLayer.play("Idle"),
        this.setStarsFillProgress(1),
        (this.entity.enabled = !0);
    }
    addXtraTubeInLevel() {
      (UIManager.inst.tubesAdded += 1),
        UIManager.inst.tubesAdded >= 2 &&
          (this.xTraTubeBtn.element.useInput = !1);
    }
    updateBtns() {
      var e = GameManager.get_SkipLvlCount(),
        t = GameManager.get_EmptyTubesCount(),
        a = GameManager.get_UndoMovesCount(),
        n = GameManager.get_HintCounts();
      (this.skipLevelBtnCounter.enabled = e > 0),
        (this.skipLevelRewIcon.enabled = e <= 0),
        (this.skipLevelBtnCounter.element.text = e + ""),
        (this.xTraTubeBtnCounter.enabled = t > 0),
        (this.xTraTubeBtnRewIcon.enabled = t <= 0),
        (this.xTraTubeBtnCounter.element.text = t + ""),
        (this.undoBtnCounter.enabled = a > 0),
        (this.undoBtnRewIcon.enabled = a <= 0),
        (this.undoBtnCounter.element.text = a + ""),
        (this.hintBtnCounter.enabled = n > 0),
        (this.hintBtnRewIcon.enabled = n <= 0),
        (this.hintBtnCounter.element.text = n + ""),
        APIManager.HasFeature("rewarded")
          ? (this.setPlayIcon(this.skipLevelRewIcon, this.skipBtnPlacement),
            this.setPlayIcon(
              this.xTraTubeBtnRewIcon,
              this.xTraTubeBtnPlacement
            ),
            this.setPlayIcon(this.undoBtnRewIcon, this.undoBtnPlacement),
            this.setPlayIcon(this.hintBtnRewIcon, this.hintBtnPlacement))
          : ((this.skipLevelRewIcon.enabled = !1),
            (this.xTraTubeBtnRewIcon.enabled = !1),
            (this.undoBtnRewIcon.enabled = !1),
            (this.hintBtnRewIcon.enabled = !1),
            (this.skipLevelBtnCounter.enabled = !0),
            (this.xTraTubeBtnCounter.enabled = !0),
            (this.undoBtnCounter.enabled = !0),
            (this.hintBtnCounter.enabled = !0),
            (this.btnSkipLevel.active = e > 0),
            (this.btnXTraTube.active = t > 0),
            (this.btnUndo.active = a > 0),
            (this.btnHint.active = n > 0));
    }
    setPlayIcon(e, t) {
      if ((null == t && (t = ""), e.enabled)) {
        var a = APIManager.HasSkipTickets()
          ? APIManager.inst.skipItIcon.id
          : APIManager.inst.rewardedTopIcon.id;
        APIManager.HasSkipTickets() ||
          APIManager.IsRewardedAdReady(t) ||
          (a = APIManager.inst.adLoadingIcon.id),
          e.element.spriteAsset != a && (e.element.spriteAsset = a);
      }
    }
    setStarsFillProgress(e) {
      (e = e > 1 ? 1 : e < 0 ? 0 : e),
        (this.starsFill.element.width = e * this.initStarsFillWidth);
    }
    onSkipLevelClick() {
      if (UIManager.isGameplaying) {
        var e = GameManager.get_SkipLvlCount();
        if (e > 0)
          MainManager.inst.PlayOneShot("BtnClick"),
            --e,
            GameManager.set_SkipLvlCount(e),
            UIManager.inst.SkipLevelOnReward();
        else {
          if (!APIManager.HasFeature("rewarded")) return;
          MainManager.inst.PlayOneShot("BtnClick"),
            APIManager.ShowRewardedAD(function (e) {
              e && UIManager.inst.SkipLevelOnReward();
            }, this.skipBtnPlacement);
        }
      }
    }
    onXTraTubeBtnClick() {
      if (UIManager.isGameplaying) {
        var e = GameManager.get_EmptyTubesCount();
        if (e > 0)
          MainManager.inst.PlayOneShot("BtnClick"),
            GameManager.set_EmptyTubesCount(e - 1),
            IngameMenu.AddXtraTubeInLevel(),
            LevelManager.inst.AddExtraTube(),
            UIManager.inst.GetHintMove(!1);
        else {
          if (!APIManager.HasFeature("rewarded")) return;
          MainManager.inst.PlayOneShot("BtnClick"),
            APIManager.ShowRewardedAD(function (e) {
              if (e) {
                var t = GameManager;
                t.set_EmptyTubesCount(t.get_EmptyTubesCount() + 1);
              }
            }, this.xTraTubeBtnPlacement);
        }
      }
    }
    onUndoBtnClick() {
      if (UIManager.isGameplaying) {
        var e = GameManager.get_UndoMovesCount();
        if (e > 0)
          GameManager.inst.Record_Redo(function (t) {
            t &&
              (MainManager.inst.PlayOneShot("BtnClick"),
              GameManager.set_UndoMovesCount(e - 1),
              TubeController.SwitchOffBlinking(),
              (UIManager.isGameplaying = !0),
              UIManager.inst.GetHintMove(!1));
          });
        else {
          if (!APIManager.HasFeature("rewarded")) return;
          MainManager.inst.PlayOneShot("BtnClick"),
            APIManager.ShowRewardedAD(function (e) {
              if (e) {
                var t = GameManager;
                t.set_UndoMovesCount(t.get_UndoMovesCount() + 5);
              }
            }, this.undoBtnPlacement);
        }
      }
    }
    onHintBtnClick() {
      var e = GameManager.get_HintCounts(),
        t = this;
      if (e > 0)
        MainManager.inst.PlayOneShot("BtnClick"),
          (this.hintBtn.element.useInput = !1),
          UIManager.inst.GetHintMove(!0);
      else {
        if (!APIManager.HasFeature("rewarded")) return;
        MainManager.inst.PlayOneShot("BtnClick"),
          APIManager.ShowRewardedAD(function (e) {
            if (e) {
              var a = GameManager;
              a.set_HintCounts(a.get_HintCounts() + 3),
                (t.hintBtn.element.useInput = !0);
            }
          }, this.hintBtnPlacement);
      }
    }
    SetStarBarAndText() {
      0 == GameManager.currMode &&
        (this.movesTxt.anim.baseLayer.play("HeartbeatAnim"),
        (this.movesTxt.element.text = "M:" + UIManager.inst.movesUsed),
        this.MoveGameplayBar());
    }
    MoveGameplayBar() {
      var e =
        (UIManager.inst.totalMoves - UIManager.inst.movesUsed) /
        UIManager.inst.totalMoves;
      motion_Actuate.stop($bind(this, this.setStarsFillProgress)),
        motion_Actuate
          .update(
            $bind(this, this.setStarsFillProgress),
            0.5,
            [this.starsFill.element.width / this.initStarsFillWidth],
            [e]
          )
          .ease(motion_easing_Linear.get_easeNone()),
        0 == GameManager.currMode &&
          (UIManager.inst.movesUsed > UIManager.inst.moves1Star
            ? ((js_Boot.__cast(
                this.star3.children[0],
                pc.Entity
              ).element.spriteAsset =
                js_Boot.__cast(
                  this.star2.children[0],
                  pc.Entity
                ).element.spriteAsset =
                js_Boot.__cast(
                  this.star1.children[0],
                  pc.Entity
                ).element.spriteAsset =
                  this.greyStar.id),
              (this.star3.element.opacity =
                this.star2.element.opacity =
                this.star1.element.opacity =
                  0))
            : UIManager.inst.movesUsed > UIManager.inst.moves2Star
            ? ((js_Boot.__cast(
                this.star3.children[0],
                pc.Entity
              ).element.spriteAsset = js_Boot.__cast(
                this.star2.children[0],
                pc.Entity
              ).element.spriteAsset =
                this.greyStar.id),
              (this.star3.element.opacity = this.star2.element.opacity = 0))
            : UIManager.inst.movesUsed > UIManager.inst.moves3Star &&
              ((js_Boot.__cast(
                this.star3.children[0],
                pc.Entity
              ).element.spriteAsset = this.greyStar.id),
              (this.star3.element.opacity = 0)));
    }
    activateKeyPanel() {
      this.key1.enabled = this.key2.enabled = this.key3.enabled = !1;
      var e = _$Vector3_Vector3_$Impl_$.clone(this.gameplayKeysContInitPos);
      e.x = 93;
      var t = this.gameplayKeysCont,
        a = t.getLocalPosition();
      motion_Actuate
        .update(
          $bind(t, t.setLocalPosition),
          0.65,
          [a.x, a.y, a.z],
          [e.x, e.y, e.z],
          !0
        )
        .ease(motion_easing_Sine.easeInOut);
    }
    activateKeyAndHide(e) {
      for (var t = null, a = this, n = 0, i = this.keys.length; n < i; ) {
        var s = n++;
        s + 1 <= e && (this.keys[s].enabled = !0),
          s + 1 == e && (t = this.keys[s]);
      }
      if (null != t) {
        var r = t.getLocalScale().clone(),
          o = 10,
          l = 10,
          u = 10;
        null == u && (u = 0), null == l && (l = 0), null == o && (o = 0);
        var c = new pc.Vec3(o, l, u);
        t.setLocalScale(c);
        var h = t.getLocalScale();
        motion_Actuate
          .update(
            $bind(t, t.setLocalScale),
            0.33,
            [h.x, h.y, h.z],
            [r.x, r.y, r.z],
            !0
          )
          .ease(motion_easing_Sine.easeInOut),
          motion_Actuate.timer(0.3).onComplete(function () {
            a.starsBlast.enabled = !0;
            var e = a.starsBlast,
              n = t.getLocalPosition().clone();
            e.setLocalPosition(n);
            for (
              var i = a.starsBlast.findComponents("particlesystem"), s = 0;
              s < i.length;

            ) {
              var r = i[s];
              ++s, r.reset(), r.play();
            }
          });
      }
      var p = this.gameplayKeysCont,
        m = this.gameplayKeysContInitPos,
        _ = p.getLocalPosition();
      motion_Actuate
        .update(
          $bind(p, p.setLocalPosition),
          1,
          [_.x, _.y, _.z],
          [m.x, m.y, m.z],
          !0
        )
        .delay(1)
        .ease(motion_easing_Sine.easeInOut);
    }
    update(e) {
      super.update(e), this.updateBtns();
    }
    static OnLevelStarted() {
      null != IngameMenu.inst && IngameMenu.inst.onLevelStarted();
    }
    static AddXtraTubeInLevel() {
      null != IngameMenu.inst && IngameMenu.inst.addXtraTubeInLevel();
    }
  }
  (IngameMenu.__name__ = "IngameMenu"),
    (IngameMenu.__super__ = ScriptComponent),
    Object.assign(IngameMenu.prototype, { __class__: IngameMenu });
  class _$Vector3_Vector3_$Impl_$ {
    static get_BACK() {
      return new pc.Vec3(0, 0, 1);
    }
    static get_DOWN() {
      return new pc.Vec3(0, -1, 0);
    }
    static get_FORWARD() {
      return new pc.Vec3(0, 0, -1);
    }
    static get_LEFT() {
      return new pc.Vec3(-1, 0, 0);
    }
    static get_ONE() {
      return new pc.Vec3(1, 1, 1);
    }
    static get_RIGHT() {
      return new pc.Vec3(1, 0, 0);
    }
    static get_UP() {
      return new pc.Vec3(0, 1, 0);
    }
    static get_ZERO() {
      return new pc.Vec3(0, 0, 0);
    }
    static Distance(e, t) {
      return _$Vector3_Vector3_$Impl_$.sub(e, t).length();
    }
    static Angle(e, t) {
      var a = Math.sqrt(e.lengthSq() * t.lengthSq());
      if (a < _$Vector3_Vector3_$Impl_$.kEpsilonNormalSqrt) return 0;
      var n = e.dot(t) / a,
        i = n < -1 ? -1 : n > 1 ? 1 : n;
      return 57.2957795130823 * Math.acos(i);
    }
    static SignedAngle(e, t, a) {
      var n,
        i = Math.sqrt(e.lengthSq() * t.lengthSq());
      if (i < _$Vector3_Vector3_$Impl_$.kEpsilonNormalSqrt) n = 0;
      else {
        var s = e.dot(t) / i,
          r = s < -1 ? -1 : s > 1 ? 1 : s;
        n = 57.2957795130823 * Math.acos(r);
      }
      var o = e.y * t.z - e.z * t.y,
        l = e.z * t.x - e.x * t.z,
        u = e.x * t.y - e.y * t.x;
      return n * (a.x * o + a.y * l + a.z * u >= 0 ? 1 : -1);
    }
    static Dot(e, t) {
      return e.dot(t);
    }
    static _new(e, t, a) {
      return (
        null == a && (a = 0),
        null == t && (t = 0),
        null == e && (e = 0),
        new pc.Vec3(e, t, a)
      );
    }
    static addV(e, t) {
      return new pc.Vec3(e.x + t.x, e.y + t.y, e.z + t.z);
    }
    static mulV(e, t) {
      return new pc.Vec3(e.x * t.x, e.y * t.y, e.z * t.z);
    }
    static mulN(e, t) {
      return new pc.Vec3(e.x * t, e.y * t, e.z * t);
    }
    static devV(e, t) {
      return new pc.Vec3(e.x / t.x, e.y / t.y, e.z / t.z);
    }
    static devN(e, t) {
      return new pc.Vec3(e.x / t, e.y / t, e.z / t);
    }
    static neg(e) {
      return new pc.Vec3(-1 * e.x, -1 * e.y, -1 * e.z);
    }
    static sub(e, t) {
      return new pc.Vec3(e.x - t.x, e.y - t.y, e.z - t.z);
    }
    static get_normalized(e) {
      return e.clone().normalize();
    }
    static get_magnitude(e) {
      return e.length();
    }
    static get_sqrMagnitude(e) {
      return e.lengthSq();
    }
    static Lerp(e, t, a) {
      a = a > 1 ? 1 : a < 0 ? 0 : a;
      var n = e.x + (t.x - e.x) * a,
        i = e.y + (t.y - e.y) * a,
        s = e.z + (t.z - e.z) * a;
      return (
        null == s && (s = 0),
        null == i && (i = 0),
        null == n && (n = 0),
        new pc.Vec3(n, i, s)
      );
    }
    static Slerp(e, t, a) {
      var n = e.dot(t),
        i = Math.acos(n) * a,
        s = _$Vector3_Vector3_$Impl_$.sub(
          t,
          _$Vector3_Vector3_$Impl_$.mulN(e, n)
        );
      _$Vector3_Vector3_$Impl_$.normalize(s);
      var r = _$Vector3_Vector3_$Impl_$.mulN(e, Math.cos(i)),
        o = _$Vector3_Vector3_$Impl_$.mulN(s, Math.sin(i));
      return new pc.Vec3(r.x + o.x, r.y + o.y, r.z + o.z);
    }
    static ClampMagnitude(e, t) {
      var a = e.lengthSq();
      if (a > t * t) {
        var n = Math.sqrt(a),
          i = (e.x / n) * t,
          s = (e.y / n) * t,
          r = (e.z / n) * t;
        return (
          null == r && (r = 0),
          null == s && (s = 0),
          null == i && (i = 0),
          new pc.Vec3(i, s, r)
        );
      }
      return e;
    }
    static FromVec2(e) {
      var t = e.x,
        a = e.y,
        n = 0;
      return (
        null == n && (n = 0),
        null == a && (a = 0),
        null == t && (t = 0),
        new pc.Vec3(t, a, n)
      );
    }
    static Project(e, t) {
      var a = t.dot(t);
      if (a < 1e-8) return _$Vector3_Vector3_$Impl_$.get_ZERO();
      var n = e.dot(t),
        i = (t.x * n) / a,
        s = (t.y * n) / a,
        r = (t.z * n) / a;
      return (
        null == r && (r = 0),
        null == s && (s = 0),
        null == i && (i = 0),
        new pc.Vec3(i, s, r)
      );
    }
    static Cross(e, t) {
      var a = e.y * t.z - e.z * t.y,
        n = e.z * t.x - e.x * t.z,
        i = e.x * t.y - e.y * t.x;
      return (
        null == i && (i = 0),
        null == n && (n = 0),
        null == a && (a = 0),
        new pc.Vec3(a, n, i)
      );
    }
    static LerpVector3NonAlloc(e, t, a, n) {
      a = a > 1 ? 1 : a < 0 ? 0 : a;
      var i = _$Vector3_Vector3_$Impl_$.sub(t, e);
      (n.x = e.x + i.x * a), (n.y = e.y + i.y * a), (n.z = e.z + i.z * a);
    }
    static clone(e) {
      return e.clone();
    }
    static set(e, t, a, n) {
      return e.set(t, a, n);
    }
    static normalize(e) {
      return e.normalize();
    }
    static copy(e, t) {
      return e.copy(t);
    }
    static project(e, t) {
      return e.project(t);
    }
    static cross(e, t, a) {
      return e.cross(t, a);
    }
    static lerp(e, t, a, n) {
      return e.lerp(t, a, n);
    }
  }
  (_$Vector3_Vector3_$Impl_$.__name__ = "_Vector3.Vector3_Impl_"),
    (_$Vector3_Vector3_$Impl_$.__properties__ = {
      get_sqrMagnitude: "get_sqrMagnitude",
      get_magnitude: "get_magnitude",
      get_normalized: "get_normalized",
      get_ZERO: "get_ZERO",
      get_UP: "get_UP",
      get_RIGHT: "get_RIGHT",
      get_ONE: "get_ONE",
      get_LEFT: "get_LEFT",
      get_FORWARD: "get_FORWARD",
      get_DOWN: "get_DOWN",
      get_BACK: "get_BACK",
    });
  class Input {
    static Init() {
      if (!Input.inited && null != pc.app) {
        Input.inited = !0;
        var e = pc.app.touch;
        null != e &&
          (e.on(pc.EVENT_TOUCHSTART, Input.onTouchStart),
          e.on(pc.EVENT_TOUCHMOVE, Input.onTouchMove),
          e.on(pc.EVENT_TOUCHEND, Input.onTouchEnd),
          e.on(pc.EVENT_TOUCHCANCEL, Input.onTouchCancel)),
          pc.app.mouse.on(pc.EVENT_MOUSEMOVE, Input.onMouseMove),
          pc.app.mouse.on(pc.EVENT_MOUSEDOWN, Input.onMouseDown),
          pc.app.mouse.on(pc.EVENT_MOUSEUP, Input.onMouseUp),
          pc.app.on("update", function (e) {
            return Input.Update(e), !0;
          });
      }
    }
    static GetMouseButton(e) {
      return !(e > 2 || e < 0) && Input.mouseButtonsPressStates[e];
    }
    static GetMouseButtonDown(e) {
      return !(e > 2 || e < 0) && Input.mouseButtonsWasPressStates[e];
    }
    static GetMouseButtonUp(e) {
      return !(e > 2 || e < 0) && Input.mouseButtonsWasReleaseStates[e];
    }
    static get_mousePosition() {
      return _$Vector3_Vector3_$Impl_$.clone(Input.curMPos);
    }
    static onTouchStart(e) {
      return (
        Input.mouseButtonsPressStates[0] ||
          (_$Vector3_Vector3_$Impl_$.set(
            Input.mDownPos,
            e.changedTouches[0].x,
            e.changedTouches[0].y,
            0
          ),
          _$Vector3_Vector3_$Impl_$.set(
            Input.curMPos,
            e.changedTouches[0].x,
            e.changedTouches[0].y,
            0
          ),
          (Input.mouseButtonsPressStates[0] = !0),
          (Input.mouseButtonsWasPressStates[0] = !0),
          (Input.touchID = e.changedTouches[0].id)),
        !0
      );
    }
    static onTouchMove(e) {
      if (Input.mouseButtonsPressStates[0]) {
        var t = e.getTouchById(Input.touchID, e.changedTouches);
        null != t && _$Vector3_Vector3_$Impl_$.set(Input.curMPos, t.x, t.y, 0);
      }
      return !0;
    }
    static onTouchEnd(e) {
      Input.mouseButtonsPressStates[0] &&
        null != e.getTouchById(Input.touchID, e.changedTouches) &&
        ((Input.mouseButtonsWasReleaseStates[0] = !0),
        (Input.mouseButtonsPressStates[0] = !1));
      return !0;
    }
    static onTouchCancel(e) {
      Input.mouseButtonsPressStates[0] &&
        null != e.getTouchById(Input.touchID, e.changedTouches) &&
        ((Input.mouseButtonsWasReleaseStates[0] = !0),
        (Input.mouseButtonsPressStates[0] = !1));
      return !0;
    }
    static onMouseDown(e) {
      var t = Input.getMouseButtonIdx(e);
      return (
        (Input.mouseButtonsPressStates[t] = !0),
        (Input.mouseButtonsWasPressStates[t] = !0),
        _$Vector3_Vector3_$Impl_$.set(Input.curMPos, e.x, e.y, 0),
        0 == t && _$Vector3_Vector3_$Impl_$.set(Input.mDownPos, e.x, e.y, 0),
        !0
      );
    }
    static onMouseMove(e) {
      return _$Vector3_Vector3_$Impl_$.set(Input.curMPos, e.x, e.y, 0), !0;
    }
    static onMouseUp(e) {
      var t = Input.getMouseButtonIdx(e);
      return (
        (Input.mouseButtonsPressStates[t] = !1),
        (Input.mouseButtonsWasReleaseStates[t] = !0),
        !0
      );
    }
    static Update(e) {
      for (var t = 0, a = Input.mouseButtonsWasPressStates.length; t < a; ) {
        var n = t++;
        Input.mouseButtonsWasPressStates[n] = !1;
      }
      for (var i = 0, s = Input.mouseButtonsWasReleaseStates.length; i < s; ) {
        var r = i++;
        Input.mouseButtonsWasReleaseStates[r] = !1;
      }
    }
    static getMouseButtonIdx(e) {
      return 0 == e.button ? 0 : 1 == e.button ? 1 : 2;
    }
  }
  (Input.__name__ = "Input"),
    (Input.__properties__ = { get_mousePosition: "get_mousePosition" });
  class Joystick extends ScriptComponent {
    get_speedCoef() {
      var e =
        new pc.Vec2(
          this.knob.x - this.center.x,
          this.knob.y - this.center.y
        ).length() / this.__attributes.radius;
      return e < 0.15 ? 0 : e;
    }
    initialize() {
      super.initialize(),
        (Joystick.current = this),
        (this.center = new pc.Vec2()),
        (this.knob = new pc.Vec2()),
        (this.start = new pc.Vec2()),
        (this.direction = new pc.Vec2()),
        (this.curMPos = new pc.Vec2()),
        (this.isMouseDown = !1);
      var e = this.app.touch,
        t = this;
      null != e
        ? (e.on(pc.EVENT_TOUCHSTART, $bind(this, this.onTouchStart), this),
          e.on(pc.EVENT_TOUCHMOVE, $bind(this, this.onTouchMove), this),
          e.on(pc.EVENT_TOUCHEND, $bind(this, this.onTouchEnd), this),
          e.on(pc.EVENT_TOUCHCANCEL, $bind(this, this.onTouchCancel), this),
          this.on(
            "destroy",
            function () {
              return (
                e.off(pc.EVENT_TOUCHSTART, $bind(t, t.onTouchStart), t),
                e.off(pc.EVENT_TOUCHMOVE, $bind(t, t.onTouchMove), t),
                e.off(pc.EVENT_TOUCHEND, $bind(t, t.onTouchEnd), t),
                e.off(pc.EVENT_TOUCHCANCEL, $bind(t, t.onTouchCancel), t)
              );
            },
            this
          ))
        : (this.app.mouse.on(
            pc.EVENT_MOUSEMOVE,
            $bind(this, this.onMouseMove),
            this
          ),
          this.app.mouse.on(
            pc.EVENT_MOUSEDOWN,
            $bind(this, this.onMouseDown),
            this
          ),
          this.app.mouse.on(
            pc.EVENT_MOUSEUP,
            $bind(this, this.onMouseUp),
            this
          ));
    }
    reset() {
      this.direction.set(0, 0);
    }
    onMDown(e, t) {
      this.start.set(e, t),
        this.knob.set(e, t),
        this.center.set(e, t),
        this.curMPos.set(e, t),
        (this.isMouseDown = !0);
    }
    onMMove(e, t) {
      if ((this.curMPos.set(e, t), this.isMouseDown)) {
        this.knob.set(e, t);
        var a = new pc.Vec2(
            this.knob.x - this.center.x,
            this.knob.y - this.center.y
          ),
          n = a.length();
        if (
          (n > this.__attributes.radius &&
            a.divScalar(n / this.__attributes.radius),
          (this.knob = this.center.clone().add(a)),
          !this.knob.equals(this.curMPos) && !this.__attributes.fixedJoystick)
        ) {
          var i = new pc.Vec2(
            this.curMPos.x - this.knob.x,
            this.curMPos.y - this.knob.y
          );
          this.center.add(i);
        }
        this.direction.set(
          this.knob.x - this.center.x,
          this.knob.y - this.center.y
        ),
          this.direction.normalize();
      }
    }
    onMUp() {
      this.direction.set(0, 0), (this.isMouseDown = !1);
    }
    onTouchStart(e) {
      return this.onMDown(e.touches[0].x, e.touches[0].y), !0;
    }
    onTouchMove(e) {
      return this.onMMove(e.touches[0].x, e.touches[0].y), !0;
    }
    onTouchEnd(e) {
      return this.onMUp(), !0;
    }
    onTouchCancel(e) {
      return this.onMUp(), !0;
    }
    onMouseDown(e) {
      return e.button == pc.MOUSEBUTTON_LEFT && this.onMDown(e.x, e.y), !0;
    }
    onMouseMove(e) {
      return this.onMMove(e.x, e.y), !0;
    }
    onMouseUp(e) {
      return e.button == pc.MOUSEBUTTON_LEFT && this.onMUp(), !0;
    }
  }
  (Joystick.__name__ = "Joystick"),
    (Joystick.__super__ = ScriptComponent),
    Object.assign(Joystick.prototype, {
      __class__: Joystick,
      __properties__: Object.assign(
        {},
        ScriptComponent.prototype.__properties__,
        { get_speedCoef: "get_speedCoef" }
      ),
    });
  class Lambda {
    static array(e) {
      for (var t = [], a = $getIterator(e); a.hasNext(); ) {
        var n = a.next();
        t.push(n);
      }
      return t;
    }
  }
  Lambda.__name__ = "Lambda";
  class LevelCompleteScreen extends ScriptComponent {
    constructor(e) {
      super(e),
        (this.isActive = !1),
        (this.curProgressBarFillAmount = 1),
        (this.wpEarnedStarsB = []);
    }
    get_curProgressBarFillAmount() {
      var e = this.progressBar.element.height / this.progressBarInitHeight;
      return e > 1 ? 1 : e < 0 ? 0 : e;
    }
    set_curProgressBarFillAmount(e) {
      this.progressBar.element.height = this.progressBarInitHeight * e;
      var t = this.progressBar.element.height / this.progressBarInitHeight;
      return t > 1 ? 1 : t < 0 ? 0 : t;
    }
    initialize() {
      super.initialize(),
        (LevelCompleteScreen.inst = this),
        (this.top = this.entity.findByPath("Top")),
        (this.topInitLocPos = this.top.getLocalPosition().clone()),
        (this.settingsBtn = this.top.findByPath("SettingsBtn")),
        (this.moneyCounterTF = this.top.findByPath("CoinsCounter/CounterText")),
        (this.topBar = this.entity.findByPath("TopBar")),
        (this.modeText = this.topBar.findByPath("ModeText")),
        (this.topBarInitLocPos = this.topBar.getLocalPosition().clone()),
        (this.starsAndCount = this.entity.findByPath("StarsAndCount")),
        (this.shine = this.starsAndCount.findByPath("Shine")),
        (this.star1 = this.starsAndCount.findByPath("1Star")),
        (this.star2 = this.starsAndCount.findByPath("2Star")),
        (this.star3 = this.starsAndCount.findByPath("3Star")),
        this.wpEarnedStarsB.push(this.star1.children[0]),
        this.wpEarnedStarsB.push(this.star2.children[0]),
        this.wpEarnedStarsB.push(this.star3.children[0]),
        (this.star1InitLocSc = this.star1.getLocalScale().clone()),
        (this.star2InitLocSc = this.star2.getLocalScale().clone()),
        (this.star3InitLocSc = this.star3.getLocalScale().clone()),
        (this.progressBarBg = this.entity.findByPath("ProgressBarBg")),
        (this.progressBar = this.progressBarBg.findByPath("ProgressBar")),
        (this.progressBarInitHeight = this.progressBar.element.height),
        (this.progressText = this.progressBarBg.findByPath("ProgressText")),
        (this.rewardScaleEmpty = this.entity.findByPath("RewardScaleEmpty")),
        (this.rewardScaleEmptyInitLocSc = this.rewardScaleEmpty
          .getLocalScale()
          .clone()),
        (this.rewardScale = this.rewardScaleEmpty.findByPath("RewardScale")),
        (this.rewardScalePivot = this.rewardScale.findByPath("Pivot")),
        (this.getx_rewardBtn = this.entity.findByPath("Getx_rewardBtn")),
        (this.getx_rewardBtnInitLocSc = this.getx_rewardBtn
          .getLocalScale()
          .clone()),
        (this.getx_rewardBtnCoinsTF =
          this.getx_rewardBtn.findByPath("GemsGiving")),
        AdLoadingIcon.SetPlacementForEntity(
          this.getx_rewardBtn,
          LevelCompleteScreen.rwGetScaledRewardPlacement
        ),
        UIHelper.AddButtonClickHandler(
          this.getx_rewardBtn,
          $bind(($_ = UIManager.inst), $_.UI_Won_ClaimXRewardBtn)
        ),
        (this.claimBtn = this.entity.findByPath("ClaimBtn")),
        (this.claimBtnInitLocSc = this.claimBtn.getLocalScale().clone()),
        (this.claimBtnCoinsTF = this.claimBtn.findByPath("GemsGiving")),
        UIHelper.AddButtonClickHandler(
          this.claimBtn,
          $bind(($_ = UIManager.inst), $_.UI_Won_MissBtn)
        ),
        (this.missBtn = this.entity.findByPath("MissBtn")),
        (this.missBtnInitLocSc = this.missBtn.getLocalScale().clone()),
        (this.missBtnCoinsTF = this.missBtn.findByPath("CoinsText")),
        UIHelper.AddButtonClickHandler(
          this.missBtn,
          $bind(($_ = UIManager.inst), $_.UI_Won_MissBtn)
        ),
        (this.wpXrewardGcB = EntityHelper.GetComponent_CoinsCollector(
          this.getChildByName("WP_Reward_CC"),
          CoinsCollector
        )),
        (this.wpNextGcB = EntityHelper.GetComponent_CoinsCollector(
          this.getChildByName("WP_Skip_CC"),
          CoinsCollector
        )),
        this.set_curProgressBarFillAmount(0),
        (this.entity.enabled = !1);
    }
    activate() {
      this.isActive ||
        ((this.isActive = !0),
        (this.entity.enabled = !0),
        this.startApearAnim());
    }
    deactivate() {
      this.isActive && ((this.isActive = !1), (this.entity.enabled = !1));
    }
    startApearAnim() {
      var e = this,
        t = this.top.getLocalPosition().clone(),
        a = this.topBar.getLocalPosition().clone(),
        n = this.top,
        i = n.getLocalPosition().clone(),
        s = 0,
        r = 300,
        o = 0;
      null == o && (o = 0), null == r && (r = 0), null == s && (s = 0);
      var l = new pc.Vec3(s, r, o),
        u = new pc.Vec3(i.x + l.x, i.y + l.y, i.z + l.z);
      n.setLocalPosition(u);
      var c = this.topBar,
        h = c.getLocalPosition().clone(),
        p = 0,
        m = 300,
        _ = 0;
      null == _ && (_ = 0), null == m && (m = 0), null == p && (p = 0);
      var d = new pc.Vec3(p, m, _),
        g = new pc.Vec3(h.x + d.x, h.y + d.y, h.z + d.z);
      c.setLocalPosition(g),
        (t.y = this.topInitLocPos.y),
        (a.y = this.topBarInitLocPos.y);
      var y = this.top,
        v = y.getLocalPosition();
      motion_Actuate
        .update(
          $bind(y, y.setLocalPosition),
          0.5,
          [v.x, v.y, v.z],
          [t.x, t.y, t.z],
          !0
        )
        .ease(motion_easing_Sine.easeInOut);
      var b = this.topBar,
        f = b.getLocalPosition();
      motion_Actuate
        .update(
          $bind(b, b.setLocalPosition),
          0.5,
          [f.x, f.y, f.z],
          [a.x, a.y, a.z],
          !0
        )
        .ease(motion_easing_Sine.easeInOut),
        (this.entity.element.opacity = 0),
        motion_Actuate
          .update(
            function (t) {
              e.entity.element.opacity = 0.78 * t;
            },
            1,
            [0],
            [1]
          )
          .ease(motion_easing_Sine.easeInOut)
          .delay(0.83),
        (this.shine.element.opacity = 0),
        motion_Actuate
          .update(
            function (t) {
              e.shine.element.opacity = t;
            },
            0.5,
            [0],
            [1]
          )
          .ease(motion_easing_Sine.easeInOut)
          .delay(0.83);
      var S = this.star1,
        P = _$Vector3_Vector3_$Impl_$.get_ZERO();
      S.setLocalScale(P);
      var M = this.star2,
        C = _$Vector3_Vector3_$Impl_$.get_ZERO();
      M.setLocalScale(C);
      var I = this.star3,
        B = _$Vector3_Vector3_$Impl_$.get_ZERO();
      I.setLocalScale(B);
      var T = this.star1,
        L = this.star1InitLocSc,
        x = T.getLocalScale();
      motion_Actuate
        .update(
          $bind(T, T.setLocalScale),
          0.03,
          [x.x, x.y, x.z],
          [L.x, L.y, L.z],
          !0
        )
        .delay(0.8999999999999999)
        .ease(motion_easing_Back.easeOut);
      var G = this.star2,
        w = this.star2InitLocSc,
        A = G.getLocalScale();
      motion_Actuate
        .update(
          $bind(G, G.setLocalScale),
          0.1,
          [A.x, A.y, A.z],
          [w.x, w.y, w.z],
          !0
        )
        .delay(0.83)
        .ease(motion_easing_Back.easeOut);
      var O = this.star3,
        E = this.star2InitLocSc,
        k = O.getLocalScale();
      motion_Actuate
        .update(
          $bind(O, O.setLocalScale),
          0.03,
          [k.x, k.y, k.z],
          [E.x, E.y, E.z],
          !0
        )
        .delay(0.8999999999999999)
        .ease(motion_easing_Back.easeOut);
      var R = this.rewardScaleEmpty,
        $ = _$Vector3_Vector3_$Impl_$.get_ZERO();
      R.setLocalScale($);
      var U = this.getx_rewardBtn,
        N = 0.36,
        H = 0,
        F = 0;
      null == F && (F = 0), null == H && (H = 0), null == N && (N = 0);
      var V = new pc.Vec3(N, H, F);
      U.setLocalScale(V);
      var z = this.claimBtn,
        D = 0.36,
        j = 0,
        W = 0;
      null == W && (W = 0), null == j && (j = 0), null == D && (D = 0);
      var Q = new pc.Vec3(D, j, W);
      z.setLocalScale(Q);
      var K = this.missBtn,
        q = 0.36,
        Y = 0,
        X = 0;
      null == X && (X = 0), null == Y && (Y = 0), null == q && (q = 0);
      var Z = new pc.Vec3(q, Y, X);
      K.setLocalScale(Z),
        motion_Actuate.timer(0.1).onComplete(function () {
          APIManager.GameInterface.showInterstitialAd("break:win").then(
            function () {
              var t = e.missBtn,
                a = e.missBtnInitLocSc,
                n = t.getLocalScale();
              motion_Actuate
                .update(
                  $bind(t, t.setLocalScale),
                  0.17,
                  [n.x, n.y, n.z],
                  [a.x, a.y, a.z],
                  !0
                )
                .delay(3)
                .ease(motion_easing_Back.easeOut);
              var i = e.rewardScaleEmpty,
                s = e.rewardScaleEmptyInitLocSc,
                r = i.getLocalScale();
              motion_Actuate
                .update(
                  $bind(i, i.setLocalScale),
                  0.41,
                  [r.x, r.y, r.z],
                  [s.x, s.y, s.z],
                  !0
                )
                .delay(1.26)
                .ease(motion_easing_Back.easeOutWith(0.5));
              var o = e.getx_rewardBtn,
                l = e.getx_rewardBtnInitLocSc,
                u = o.getLocalScale();
              motion_Actuate
                .update(
                  $bind(o, o.setLocalScale),
                  0.27,
                  [u.x, u.y, u.z],
                  [l.x, l.y, l.z],
                  !0
                )
                .delay(1.5)
                .ease(motion_easing_Back.easeOutWith(0.5));
              var c = e.claimBtn,
                h = e.claimBtnInitLocSc,
                p = c.getLocalScale();
              motion_Actuate
                .update(
                  $bind(c, c.setLocalScale),
                  0.27,
                  [p.x, p.y, p.z],
                  [h.x, h.y, h.z],
                  !0
                )
                .delay(1.5)
                .ease(motion_easing_Back.easeOutWith(0.5));
            }
          );
        });
    }
    update(e) {
      super.update(e);
      var t = this.shine,
        a = t.getLocalRotation().clone(),
        n = new pc.Quat(0, 0, 0, 1),
        i = _$Quaternion_Quaternion_$Impl_$.mulQ(
          a,
          _$Quaternion_Quaternion_$Impl_$.setFromEulerAngles(n, 0, 0, -50 * e)
        );
      t.setLocalRotation(i);
    }
    static get_IsActive() {
      return (
        null != LevelCompleteScreen.inst && LevelCompleteScreen.inst.isActive
      );
    }
    static Activate() {
      null != LevelCompleteScreen.inst && LevelCompleteScreen.inst.activate();
    }
    static Deactivate() {
      null != LevelCompleteScreen.inst && LevelCompleteScreen.inst.deactivate();
    }
  }
  (LevelCompleteScreen.__name__ = "LevelCompleteScreen"),
    (LevelCompleteScreen.__properties__ = { get_IsActive: "get_IsActive" }),
    (LevelCompleteScreen.__super__ = ScriptComponent),
    Object.assign(LevelCompleteScreen.prototype, {
      __class__: LevelCompleteScreen,
      __properties__: Object.assign(
        {},
        ScriptComponent.prototype.__properties__,
        {
          set_curProgressBarFillAmount: "set_curProgressBarFillAmount",
          get_curProgressBarFillAmount: "get_curProgressBarFillAmount",
        }
      ),
    });
  class LevelManager extends ScriptComponent {
    constructor(e) {
      super(e), (this.prevSortedTubeCount = 0), (this.colorsSorted = 0);
    }
    get_IsReceiving() {
      for (var e = 0, t = LevelManager.tubes.length; e < t; ) {
        var a = e++;
        if (LevelManager.tubes[a].tubeStage == TubeStage.Receiving) return !0;
      }
      return !1;
    }
    get_IsSending() {
      for (var e = 0, t = LevelManager.tubes.length; e < t; ) {
        var a = e++;
        if (LevelManager.tubes[a].tubeStage == TubeStage.Sending) return !0;
      }
      return !1;
    }
    get_RemainColToSort() {
      return this.colorsToSort - this.colorsSorted;
    }
    initialize() {
      super.initialize(),
        (LevelManager.inst = this),
        (this.mainCam = js_Boot.__cast(
          pc.app.root.findByTag("MainCamera")[0],
          pc.Entity
        ).camera);
    }
    update(e) {
      if (
        (super.update(e),
        null != UIManager.inst &&
          UIManager.isGameplaying &&
          !UIManager.IsPointerOverUIElement() &&
          !(
            (null != WinScreen.inst && WinScreen.inst.enabled) ||
            (null != LoseScreen.inst && LoseScreen.inst.enabled)
          ) &&
          Input.GetMouseButtonDown(0) &&
          UIManager.isGameplaying &&
          !UIManager.inst.pausedPanel.enabled &&
          !UIManager.inst.nmmPanel.enabled &&
          !UIManager.inst.newGpPowerTutPanel.enabled &&
          !PauseOverlay.isActive)
      ) {
        var t = this.mainCam.screenToWorld(
            Input.get_mousePosition().x,
            Input.get_mousePosition().y,
            this.mainCam.nearClip
          ),
          a = this.mainCam.screenToWorld(
            Input.get_mousePosition().x,
            Input.get_mousePosition().y,
            this.mainCam.farClip
          ),
          n = _$Vector3_Vector3_$Impl_$.sub(a, t);
        _$Vector3_Vector3_$Impl_$.normalize(n);
        for (
          var i = new pc.Ray(t, n), s = 0, r = LevelManager.tubes.length;
          s < r;

        ) {
          var o = s++,
            l = LevelManager.tubes[o];
          if (l.col && null != l && null != l.data)
            if (this.getEntityBounds(l.data.hitZone).intersectsRay(i)) {
              l.ClickedOnTube();
              break;
            }
        }
      }
    }
    getEntityBounds(e) {
      var t = new pc.BoundingBox(),
        a = e.sprite._model.meshInstances;
      if (a.length > 0) {
        t.copy(a[0].aabb);
        for (var n = 1, i = a.length; n < i; ) {
          var s = n++;
          t.add(a[s].aabb);
        }
      }
      return t;
    }
    LevelEnabled() {
      if (
        ((LevelManager.tubes = null),
        (LevelManager.tubes =
          EntityHelper.GetComponentsInChildren_TubeController(
            this.entity,
            TubeController
          )),
        (GameManager.inst.levelFormat_B = LevelsImporter.levelPosFormat),
        null != GameManager.inst)
      ) {
        LevelManager.currFormat =
          GameManager.inst.levelFormat_B.levelPoseFormates[
            LevelManager.tubes.length - 1
          ];
        for (var e = 0, t = LevelManager.tubes.length; e < t; ) {
          var a = e++;
          LevelManager.tubes[a].startPos = _$Vector3_Vector3_$Impl_$.FromVec2(
            LevelManager.currFormat.tubePoses[a]
          );
          var n = LevelManager.tubes[a].entity,
            i = _$Vector3_Vector3_$Impl_$.FromVec2(
              LevelManager.currFormat.tubePoses[a]
            );
          n.setPosition(i);
        }
        (this.mainCam.orthoHeight = LevelManager.currFormat.camSize),
          UIManager.inst.setThemeScale(LevelManager.currFormat.camSize);
      }
    }
    get_PrevSortedTubeCount() {
      return this.prevSortedTubeCount;
    }
    ReCountSortedTubes() {
      (this.colorsSorted = 0),
        null == LevelManager.tubes &&
          (LevelManager.tubes =
            EntityHelper.GetComponentsInChildren_TubeController(
              this.entity,
              TubeController
            ));
      for (var e = 0, t = LevelManager.tubes.length; e < t; ) {
        var a = e++;
        LevelManager.tubes[a].get_IsColorsMatched() && (this.colorsSorted += 1);
      }
      this.colorsSorted >= this.colorsToSort && UIManager.inst.GameWon();
    }
    AddExtraTube() {
      var e = EntityHelper.GetComponent_TubeController(
        EntityHelper.InstantiatePrefab(
          GameManager.inst.tubePrefab,
          this.entity
        ),
        TubeController
      );
      (LevelManager.tubes = null),
        (LevelManager.tubes =
          EntityHelper.GetComponentsInChildren_TubeController(
            this.entity,
            TubeController
          )),
        (GameManager.inst.levelFormat_B = LevelsImporter.levelPosFormat),
        (LevelManager.currFormat =
          GameManager.inst.levelFormat_B.levelPoseFormates[
            LevelManager.tubes.length - 1
          ]),
        (this.mainCam.orthoHeight = LevelManager.currFormat.camSize);
      for (var t = 0, a = LevelManager.tubes.length; t < a; ) {
        var n = t++,
          i = _$Vector3_Vector3_$Impl_$.FromVec2(
            LevelManager.currFormat.tubePoses[n]
          ),
          s = 0,
          r = 1,
          o = 0;
        null == o && (o = 0), null == r && (r = 0), null == s && (s = 0);
        var l = new pc.Vec3(s, r, o);
        LevelManager.tubes[n].startPos = _$Vector3_Vector3_$Impl_$.sub(i, l);
        var u = LevelManager.tubes[n].entity,
          c = _$Vector3_Vector3_$Impl_$.FromVec2(
            LevelManager.currFormat.tubePoses[n]
          ),
          h = 0,
          p = 1,
          m = 0;
        null == m && (m = 0), null == p && (p = 0), null == h && (h = 0);
        var _ = new pc.Vec3(h, p, m),
          d = _$Vector3_Vector3_$Impl_$.sub(c, _);
        u.setPosition(d);
      }
      UIManager.inst.setThemeScale(this.mainCam.orthoHeight),
        (e.colorNames = []),
        e.init();
    }
  }
  (LevelManager.__name__ = "LevelManager"),
    (LevelManager.__super__ = ScriptComponent),
    Object.assign(LevelManager.prototype, {
      __class__: LevelManager,
      __properties__: Object.assign(
        {},
        ScriptComponent.prototype.__properties__,
        {
          get_PrevSortedTubeCount: "get_PrevSortedTubeCount",
          get_RemainColToSort: "get_RemainColToSort",
          get_IsSending: "get_IsSending",
          get_IsReceiving: "get_IsReceiving",
        }
      ),
    });
  class LevelPoseFormatSO {
    constructor() {}
  }
  (LevelPoseFormatSO.__name__ = "LevelPoseFormatSO"),
    Object.assign(LevelPoseFormatSO.prototype, {
      __class__: LevelPoseFormatSO,
    });
  class LevelPoseFormat {
    constructor() {
      (this.camSize = 3), (this.name = "");
    }
  }
  (LevelPoseFormat.__name__ = "LevelPoseFormat"),
    Object.assign(LevelPoseFormat.prototype, { __class__: LevelPoseFormat });
  class LevelTFTMP extends ScriptComponent {
    initialize() {
      this.setLevelTF();
    }
    setLevelTF() {
      var e = "LEVEL" + PlayerPrefs.GetInt("CurrLvlNum", 1);
      if (this.entity.element.text != e) {
        var t = PlayerPrefs.GetInt("CurrLvlNum", 1);
        this.entity.element.text = "LEVEL" + t;
      }
    }
    update(e) {
      super.update(e), this.setLevelTF();
    }
  }
  (LevelTFTMP.__name__ = "LevelTFTMP"),
    (LevelTFTMP.__super__ = ScriptComponent),
    Object.assign(LevelTFTMP.prototype, { __class__: LevelTFTMP });
  class LevelsImporter {
    static get_loaded() {
      return !!LevelsImporter.inited && 0 == LevelsImporter.numLoadLeft;
    }
    static init(e) {
      if (null != pc.app && null != pc.app.root && !LevelsImporter.inited) {
        (LevelsImporter.inited = !0), (LevelsImporter.loadedCallback = e);
        var t = pc.app.assets.findByTag("ClassicLevelsData")[0];
        null != t &&
          (LevelsImporter.numLoadLeft++,
          t.ready(function (e) {
            return (
              LevelsImporter.importLevels(
                LevelsImporter.classicLevels,
                e.resource
              ),
              !0
            );
          }, null));
        var a = pc.app.assets.findByTag("HardLevelsData")[0];
        null != a &&
          (LevelsImporter.numLoadLeft++,
          a.ready(function (e) {
            return (
              LevelsImporter.importLevels(
                LevelsImporter.hardLevels,
                e.resource
              ),
              !0
            );
          }, null));
        var n = pc.app.assets.findByTag("TimedLevelsData")[0];
        null != n &&
          (LevelsImporter.numLoadLeft++,
          n.ready(function (e) {
            return (
              LevelsImporter.importLevels(
                LevelsImporter.timedLevels,
                e.resource
              ),
              !0
            );
          }, null));
        var i = pc.app.assets.findByTag("FTUELevelsData")[0];
        null != i &&
          (LevelsImporter.numLoadLeft++,
          i.ready(function (e) {
            return (
              LevelsImporter.importLevels(
                LevelsImporter.FTUELevels,
                e.resource
              ),
              !0
            );
          }, null));
        var s = pc.app.assets.findByTag("LevelPosFormat")[0];
        null != s &&
          (LevelsImporter.numLoadLeft++,
          s.ready(function (e) {
            return LevelsImporter.importLevelPosFormat(e.resource), !0;
          }, null));
      }
    }
    static importLevels(e, t) {
      for (var a = t.split("@"), n = 0, i = a.length; n < i; ) {
        var s = a[n++],
          r = HxOverrides.substr(s, 0, s.indexOf(";"));
        null != __map_reserved[r] ? e.setReserved(r, s) : (e.h[r] = s);
      }
      LevelsImporter.numLoadLeft--,
        0 == LevelsImporter.numLoadLeft &&
          null != LevelsImporter.loadedCallback &&
          (LevelsImporter.loadedCallback(),
          (LevelsImporter.loadedCallback = null));
    }
    static GetColorWaterLevel(e, t) {
      null == t && (t = LevelsType.CLASSIC);
      var a = null;
      switch (t._hx_index) {
        case 0:
          a = LevelsImporter.classicLevels;
          break;
        case 1:
          a = LevelsImporter.hardLevels;
          break;
        case 2:
          a = LevelsImporter.timedLevels;
          break;
        case 3:
          a = LevelsImporter.FTUELevels;
      }
      var n = null != __map_reserved[e] ? a.getReserved(e) : a.h[e];
      if (null == n) return null;
      var i = new ColorWaterLevel(),
        s = n.split("*");
      if (2 != s.length) return null;
      var r = s[0].split(";");
      if (6 != r.length) return null;
      (i.name = r[0]),
        (i.useGhostTube = "1" == r[1]),
        (i.tubesToSort = Std.parseInt(r[2])),
        (i.minMovesToSort = Std.parseInt(r[3])),
        (i.minTimeToSort = parseFloat(r[4])),
        (i.haveKey = "1" == r[5]),
        (i.tubes = []);
      for (var o = 0, l = (r = s[1].split(";")).length; o < l; ) {
        var u = r[o++].split(","),
          c = [];
        if (1 != u.length || "" != u[0]) {
          for (var h = 0, p = u.length; h < p; ) {
            var m = h++;
            c.push(Std.parseInt(u[m]));
          }
          i.tubes.push(new WaterName(c));
        } else i.tubes.push(new WaterName(c));
      }
      return i;
    }
    static GetColorWaterLevelByPath(e) {
      var t = e.split("/");
      if (t.length < 2) return null;
      var a = LevelsType.CLASSIC;
      switch (t[t.length - 2]) {
        case "Classic":
        default:
          a = LevelsType.CLASSIC;
          break;
        case "Hard":
          a = LevelsType.HARD;
          break;
        case "Timed":
          a = LevelsType.TIMED;
          break;
        case "_FTUE":
          a = LevelsType.FTUE;
      }
      return LevelsImporter.GetColorWaterLevel(t[t.length - 1], a);
    }
    static importLevelPosFormat(e) {
      (LevelsImporter.levelPosFormat = new LevelPoseFormatSO()),
        (LevelsImporter.levelPosFormat.levelPoseFormates = []);
      for (var t = e.split("@"), a = 0, n = t.length; a < n; ) {
        var i = t[a++].split("*"),
          s = new LevelPoseFormat(),
          r = i[0].split(";");
        (s.name = r[0]),
          (s.camSize = parseFloat(r[1])),
          (r = i[1].split(";")),
          (s.tubePoses = []);
        var o = (r.length / 2) | 0,
          l = 0;
        o >= 15 && (l = -0.5);
        for (var u = 0, c = o; u < c; ) {
          var h = u++;
          s.tubePoses.push(
            new pc.Vec2(parseFloat(r[2 * h]), parseFloat(r[2 * h + 1]) + l)
          );
        }
        LevelsImporter.levelPosFormat.levelPoseFormates.push(s);
      }
      LevelsImporter.numLoadLeft--,
        0 == LevelsImporter.numLoadLeft &&
          null != LevelsImporter.loadedCallback &&
          (LevelsImporter.loadedCallback(),
          (LevelsImporter.loadedCallback = null));
    }
  }
  (LevelsImporter.__name__ = "LevelsImporter"),
    (LevelsImporter.__properties__ = { get_loaded: "get_loaded" });
  var LevelsType = ($hxEnums.LevelsType = {
    __ename__: !0,
    __constructs__: ["CLASSIC", "HARD", "TIMED", "FTUE"],
    CLASSIC: { _hx_index: 0, __enum__: "LevelsType", toString: $estr },
    HARD: { _hx_index: 1, __enum__: "LevelsType", toString: $estr },
    TIMED: { _hx_index: 2, __enum__: "LevelsType", toString: $estr },
    FTUE: { _hx_index: 3, __enum__: "LevelsType", toString: $estr },
  });
  LevelsType.__empty_constructs__ = [
    LevelsType.CLASSIC,
    LevelsType.HARD,
    LevelsType.TIMED,
    LevelsType.FTUE,
  ];
  class LoseScreen extends ScriptComponent {
    initialize() {
      LoseScreen.inst = this;
      this.getChildByName("PreLevelBtn");
      var e = this.getChildByName("NextLevelBtn"),
        t = this.getChildByName("RestartBtn"),
        a = this;
      null != e &&
        UIHelper.AddButtonClickHandler(e, function () {
          UIManager.GoToNextLevel(), (a.entity.enabled = !1);
        }),
        null != t &&
          UIHelper.AddButtonClickHandler(t, function () {
            MainManager.inst.LoadLevel(!1), (a.entity.enabled = !1);
          }),
        (this.entity.enabled = !1);
    }
    static Activate() {
      LoseScreen.isActivating ||
        ((LoseScreen.isActivating = !0),
        motion_Actuate.timer(1).onComplete(function () {
          (LoseScreen.isActivating = !1), (LoseScreen.inst.entity.enabled = !0);
        }));
    }
  }
  (LoseScreen.__name__ = "LoseScreen"),
    (LoseScreen.__super__ = ScriptComponent),
    Object.assign(LoseScreen.prototype, { __class__: LoseScreen });
  class Macro {}
  Macro.__name__ = "Macro";
  class Main {
    static main() {
      (haxe_Log.trace = window.GameInterface.log),
        Main.runHardFixes(),
        APIManager.GameInterface.isMuted() && Main.OnFamobiMuteStateChange(!0),
        LevelsImporter.init(function () {
          Coroutines.AddOnEndOfFrameCallback(function () {
            (Main.LevelsDataLoaded = !0),
              MainManager.BgLoaded && !Main.GameReadySent && Main.OnGameReady();
          });
        });
    }
    static OnGameReady() {
      Main.GameReadySent ||
        ((Main.GameReadySent = !0),
        APIManager.GameInterface.sendPreloadProgress(100),
        Main.initFamobi(),
        MainManager.inst.LoadLevel(!0),
        eval(
          "if (window.HideLoadingSplash !== undefined) window.HideLoadingSplash();"
        ));
    }
    static initFamobi() {
      APIManager.GameInterface.gameReady(),
        APIManager.GameInterface.onGoToHome(function () {
          UIManager.inst.UI_Game_HomeBtn(!1);
        }),
        APIManager.GameInterface.onGoToNextLevel(function () {
          UIManager.GoToNextLevel();
        }),
        APIManager.GameInterface.onGoToLevel(function (e) {
          UIManager.GoToLevel(e);
        }),
        APIManager.GameInterface.onRestartGame(function () {
          UIManager.inst.famobiRestartRequest();
        }),
        APIManager.GameInterface.onQuitGame(function () {
          UIManager.inst.UI_Game_HomeBtn(!1);
        }),
        APIManager.GameInterface.onAudioStateChange(
          Main.OnFamobiMuteStateChange
        ),
        APIManager.GameInterface.onPauseStateChange(function (e) {
          e ? PauseOverlay.Activate() : PauseOverlay.Deactivate();
        }),
        APIManager.HasFeature("pause") ||
          (IngameMenu.inst.pauseBtn.enabled = !1);
    }
    static OnFamobiMuteStateChange(e) {
      (Main.isFamobiMuted = e),
        null != UIManager.inst && UIManager.inst.SetSettingsPanel();
      var t = null,
        a = pc.app.root.findByTag("SoundsController");
      null != a && a.length > 0 && (t = a[0]),
        null != t && null != t.sound && (t.sound.enabled = !Main.isFamobiMuted);
    }
    static runHardFixes() {
      (pc.CollisionComponentSystem.prototype._getNodeTransform = function (
        e,
        t
      ) {
        let a = new pc.Vec3(),
          n = a,
          i = new pc.Quat(),
          s = new pc.Quat(),
          r = new pc.Mat4();
        t
          ? (this._calculateNodeRelativeTransform2(e, t, r),
            r.getTranslation(a),
            i.setFromMat4(r))
          : ((a = e.getPosition()), (i = e.getRotation()));
        const o = new Ammo.btQuaternion(),
          l = new Ammo.btTransform();
        l.setIdentity();
        const u = l.getOrigin(),
          c = e.collision;
        if (c && c._hasOffset) {
          const e = c.data.linearOffset,
            t = c.data.angularOffset;
          (a = a.clone()),
            s.copy(i).transformVector(e, n),
            n.add(a),
            s.copy(i).mul(t),
            u.setValue(n.x, n.y, n.z),
            o.setValue(s.x, s.y, s.z, s.w);
        } else u.setValue(a.x, a.y, a.z), o.setValue(i.x, i.y, i.z, i.w);
        return l.setRotation(o), Ammo.destroy(o), Ammo.destroy(u), l;
      }),
        (pc.CollisionComponentSystem.prototype._calculateNodeRelativeTransform2 =
          function (e, t, a) {
            if (e === t) {
              const t = e.getWorldTransform().getScale();
              a.setScale(t.x, t.y, t.z);
            } else
              this._calculateNodeRelativeTransform(e.parent, t),
                a.mul(e.getLocalTransform());
          }),
        (pc.SpriteComponent.prototype._showFrame = function (e) {
          if (!this.sprite) return;
          const t = this.sprite.meshes[e];
          if (!t)
            return void (
              this._meshInstance &&
              ((this._meshInstance.mesh = null),
              (this._meshInstance.visible = !1))
            );
          let a;
          if (
            ((a =
              this.sprite.renderMode === pc.SPRITE_RENDERMODE_SLICED
                ? this.system.default9SlicedMaterialSlicedMode
                : this.sprite.renderMode === pc.SPRITE_RENDERMODE_TILED
                ? this.system.default9SlicedMaterialTiledMode
                : this.system.defaultMaterial),
            this._meshInstance ||
              ((this._meshInstance = new pc.MeshInstance(
                t,
                this._material,
                this._node
              )),
              (this._meshInstance.castShadow = !1),
              (this._meshInstance.receiveShadow = !1),
              (this._meshInstance.drawOrder = this._drawOrder),
              this._model.meshInstances.push(this._meshInstance),
              (this._colorUniform[0] = this._color.r),
              (this._colorUniform[1] = this._color.g),
              (this._colorUniform[2] = this._color.b),
              this._meshInstance.setParameter(
                "material_emissive",
                this._colorUniform
              ),
              this._meshInstance.setParameter(
                "material_opacity",
                this._color.a
              ),
              this.enabled && this.entity.enabled && this._showModel()),
            this._material && (a = this._material),
            this._meshInstance.material !== a &&
              (this._meshInstance.material = a),
            this._meshInstance.mesh !== t &&
              ((this._meshInstance.mesh = t),
              (this._meshInstance.visible = !0),
              (this._meshInstance._aabbVer = -1)),
            this.sprite.atlas && this.sprite.atlas.texture
              ? (this._meshInstance.setParameter(
                  "texture_emissiveMap",
                  this.sprite.atlas.texture
                ),
                this._meshInstance.setParameter(
                  "texture_opacityMap",
                  this.sprite.atlas.texture
                ))
              : (this._meshInstance.deleteParameter("texture_emissiveMap"),
                this._meshInstance.deleteParameter("texture_opacityMap")),
            !this.sprite.atlas ||
              (this.sprite.renderMode !== pc.SPRITE_RENDERMODE_SLICED &&
                this.sprite.renderMode !== pc.SPRITE_RENDERMODE_TILED))
          )
            this._meshInstance._updateAabbFunc = null;
          else {
            this._meshInstance._updateAabbFunc = this._updateAabbFunc;
            const t = this.sprite.atlas.frames[this.sprite.frameKeys[e]];
            if (t) {
              const e = 2 / t.rect.z,
                a = 2 / t.rect.w;
              this._innerOffset.set(
                t.border.x * e,
                t.border.y * a,
                t.border.z * e,
                t.border.w * a
              );
              const n = this.sprite.atlas.texture;
              this._atlasRect.set(
                t.rect.x / n.width,
                t.rect.y / n.height,
                t.rect.z / n.width,
                t.rect.w / n.height
              );
            } else this._innerOffset.set(0, 0, 0, 0);
            (this._innerOffsetUniform[0] = this._innerOffset.x),
              (this._innerOffsetUniform[1] = this._innerOffset.y),
              (this._innerOffsetUniform[2] = this._innerOffset.z),
              (this._innerOffsetUniform[3] = this._innerOffset.w),
              this._meshInstance.setParameter(
                "innerOffset",
                this._innerOffsetUniform
              ),
              (this._atlasRectUniform[0] = this._atlasRect.x),
              (this._atlasRectUniform[1] = this._atlasRect.y),
              (this._atlasRectUniform[2] = this._atlasRect.z),
              (this._atlasRectUniform[3] = this._atlasRect.w),
              this._meshInstance.setParameter(
                "atlasRect",
                this._atlasRectUniform
              );
          }
          this._updateTransform();
        });
    }
  }
  Main.__name__ = "Main";
  class MainManager extends ScriptComponent {
    constructor(e) {
      super(e),
        (this.soundController = null),
        (this.isBgMusicOn = !0),
        (this.itemSelectedCol = _$Color_Color_$Impl_$.get_GREEN()),
        (this.confetti = null),
        (this.bgThemeSr = null),
        (this.intervals = 0);
    }
    initialize() {
      if (
        (super.initialize(),
        null == MainManager.inst && (MainManager.inst = this),
        PlayerPrefs.GetIntArray("PickedItemNum").length <= 1 &&
          ((MainManager.pickedItemNum[0] = 1),
          (MainManager.pickedItemNum[1] = 2),
          (MainManager.pickedItemNum[2] = 1),
          PlayerPrefs.SetIntArray("PickedItemNum", MainManager.pickedItemNum)),
        0 == PlayerPrefs.GetInt("NewUser", 0))
      ) {
        if (
          (PlayerPrefs.SetInt("NewUser", 1),
          GameManager.set_EmptyTubesCount(1),
          GameManager.set_UndoMovesCount(5),
          GameManager.set_HintCounts(3),
          !APIManager.HasFeature("rewarded"))
        ) {
          GameManager.set_SkipLvlCount(2);
          var e = new Date(),
            t =
              "freebonusyoutube_" +
              (e.getHours() < 12 ? 0 : 1) +
              e.getDate() +
              e.getMonth() +
              e.getFullYear();
          PlayerPrefs.SetBool(t, !0);
        }
      } else {
        if (!APIManager.HasFeature("rewarded")) {
          var a = new Date(),
            n =
              "freebonusyoutube_" +
              (a.getHours() < 12 ? 0 : 1) +
              a.getDate() +
              a.getMonth() +
              a.getFullYear();
          PlayerPrefs.GetBool(n) ||
            (PlayerPrefs.SetBool(n, !0),
            GameManager.get_EmptyTubesCount() < 1 &&
              GameManager.set_EmptyTubesCount(1),
            GameManager.get_UndoMovesCount() < 5 &&
              GameManager.set_UndoMovesCount(5),
            GameManager.get_HintCounts() < 3 && GameManager.set_HintCounts(3),
            GameManager.get_SkipLvlCount() < 2 &&
              GameManager.set_SkipLvlCount(2));
        }
        PlayerPrefs.SetInt("Lvl1Played", 1),
          PlayerPrefs.GetInt("BuildVersion", 54) <= 54 &&
            PlayerPrefs.SetInt("BuildVersion", 59);
      }
      PlayerPrefs.HasKey("Currency_1") ||
        PlayerPrefs.SetFloat("Currency_1", PlayerPrefs.GetFloat("Gems", 0)),
        (MainManager.pickedItemNum = PlayerPrefs.GetIntArray("PickedItemNum"));
    }
    LoadLevel(e) {
      null == e && (e = !1),
        GameManager.inst.isMakingLevel || (LevelManager.inst = null),
        e
          ? GameManager.inst.isMakingLevel
            ? (UIManager.inst.SetGameplayPanel(),
              UIManager.inst.GamePlayPanelOnOff(!0, 1, 0.1),
              (UIManager.isGameplaying = !0))
            : GameManager.inst.InstantiateNewLevel(function (e) {
                e
                  ? (UIManager.inst.SetGameplayPanel(),
                    UIManager.inst.GamePlayPanelOnOff(!0, 1, 0.1),
                    (UIManager.isGameplaying = !0))
                  : haxe_Log.trace("Takleef ho gae h", {
                      fileName: "src/MainManager.hx",
                      lineNumber: 194,
                      className: "MainManager",
                      methodName: "LoadLevel",
                    });
              })
          : UIManager.inst.FadeInOutPanel(function (e) {
              e &&
                (0 == PlayerPrefs.GetInt("IsReviewed", 0) &&
                  PlayerPrefs.GetInt("LevelComplete", 1),
                GameManager.inst.isMakingLevel ||
                  GameManager.inst.InstantiateNewLevel(function (e) {
                    null != e &&
                      (UIManager.inst.SetGameplayPanel(),
                      UIManager.inst.GamePlayPanelOnOff(!0, 1, 0.1),
                      (UIManager.inst.mainPanel.enabled = !1),
                      (UIManager.isGameplaying = !0));
                  }));
            }),
        UIManager.inst.UpdateCurrency();
    }
    EmptyTubeClicked() {
      this.PlayOneShot("EmptyTube");
    }
    FilledTubeClicked() {
      this.PlayOneShot("FilledTube");
    }
    setBGMusic(e) {
      if (((this.isBgMusicOn = e), null == this.soundController)) {
        var t = pc.app.root.findByTag("SoundsController");
        null != t && t.length > 0 && (this.soundController = t[0].sound);
      }
      try {
        e
          ? this.soundController.slot("BGMusic").play()
          : this.soundController.slot("BGMusic").isPlaying &&
            this.soundController.slot("BGMusic").stop();
      } catch (e) {
        e instanceof js__$Boot_HaxeError && e.val;
      }
    }
    PlayOneShot(e) {
      if (UIManager.isAudioOn) {
        if (null == this.soundController) {
          var t = pc.app.root.findByTag("SoundsController");
          null != t && t.length > 0 && (this.soundController = t[0].sound);
        }
        null != this.soundController && this.soundController.play(e);
      }
    }
    PlayCorkPop() {
      this.PlayOneShot("CorkPop");
    }
    NewItemUsing(e, t) {
      MainManager.pickedItemNum[e] != t &&
        ((MainManager.pickedItemNum[e] = t),
        PlayerPrefs.SetIntArray("PickedItemNum", MainManager.pickedItemNum),
        0 == e
          ? (GameManager.LoadCurrTube(),
            GameManager.inst.InstantiateNewLevel(function (e) {}, !0))
          : 1 == e
          ? UIManager.inst.SetBgTheme()
          : GameManager.LoadTubeCap());
    }
    update(e) {
      super.update(e),
        MainManager.SplashRemoveLeftFrames > 0 &&
          pc.app.assets.get(this.bgThemeSr.sprite.spriteAsset).loaded &&
          (MainManager.SplashRemoveLeftFrames--,
          0 == MainManager.SplashRemoveLeftFrames &&
            ((MainManager.BgLoaded = !0),
            Main.LevelsDataLoaded &&
              !Main.GameReadySent &&
              Main.OnGameReady())),
        this.isBgMusicOn &&
          "suspended" != pc.app._soundManager._context.state &&
          null != this.soundController &&
          null != this.soundController.slot("BGMusic") &&
          !this.soundController.slot("BGMusic").isPlaying &&
          (this.soundController.slot("BGMusic").isPaused
            ? this.soundController.slot("BGMusic").resume()
            : this.soundController.slot("BGMusic").play());
    }
  }
  (MainManager.__name__ = "MainManager"),
    (MainManager.__super__ = ScriptComponent),
    Object.assign(MainManager.prototype, { __class__: MainManager });
  class _$MainManager_ShopCategory_$Impl_$ {
    static ToString(e) {
      switch (e) {
        case 0:
          return "Tube";
        case 1:
          return "Theme";
        case 2:
          return "Cap";
        default:
          return null;
      }
    }
  }
  _$MainManager_ShopCategory_$Impl_$.__name__ =
    "_MainManager.ShopCategory_Impl_";
  class MaterialHelper {
    static SetEntityMaterial(e, t) {
      null != e.render
        ? "asset" != e.render.type
          ? (e.render.material = t)
          : (e.render.materialAsset = t.id)
        : null != e.model &&
          ("asset" == e.model.type
            ? (e.model.mapping = { 0: t.id })
            : (e.model.material = t));
    }
    static SetEntityMaterials(e, t) {
      if (null != e.render)
        if ("asset" != e.render.type) e.render.material = t[0];
        else {
          for (var a = [], n = 0, i = t.length; n < i; ) {
            var s = n++;
            a.push(0 | t[s].id);
          }
          var r = a;
          e.render.materialAssets = r;
        }
      else if (null != e.model)
        if ("asset" == e.model.type) {
          for (var o = {}, l = 0, u = t.length; l < u; ) {
            var c = l++;
            o[c + ""] = t[c].id;
          }
          e.model.mapping = o;
        } else e.model.material = t[0];
    }
    static SetEntityFirstRendererMaterial(e, t) {
      var a = e.findComponent("render");
      null != a && MaterialHelper.SetEntityMaterial(a.entity, t);
      var n = e.findComponent("model");
      null != n && MaterialHelper.SetEntityMaterial(n.entity, t);
    }
    static SetEntityFirstRendererMaterials(e, t) {
      var a = e.findComponent("render");
      null != a && MaterialHelper.SetEntityMaterials(a.entity, t);
      var n = e.findComponent("model");
      null != n && MaterialHelper.SetEntityMaterials(n.entity, t);
    }
    static SetEntityWithChildsMaterial(e, t) {
      for (var a = e.findComponents("render"), n = 0; n < a.length; ) {
        var i = a[n];
        ++n;
        for (var s = 0, r = i.meshInstances; s < r.length; ) {
          var o = r[s];
          ++s, (o.material = t);
        }
      }
      for (var l = e.findComponents("model"), u = 0; u < l.length; ) {
        var c = l[u];
        ++u;
        for (var h = 0, p = c.meshInstances; h < p.length; ) {
          var m = p[h];
          ++h, (m.material = t);
        }
      }
    }
  }
  (MaterialHelper.__name__ = "MaterialHelper"), (Math.__name__ = "Math");
  class Mathf {
    static Abs(e) {
      return Math.abs(e);
    }
    static Sin(e) {
      return Math.sin(e);
    }
    static Cos(e) {
      return Math.cos(e);
    }
    static Atan(e) {
      return Math.atan(e);
    }
    static Acos(e) {
      return Math.acos(e);
    }
    static Atan2(e, t) {
      return Math.atan2(e, t);
    }
    static FloorToInt(e) {
      return 0 | Math.floor(e);
    }
    static Sqrt(e) {
      return Math.sqrt(e);
    }
    static Clamp01(e) {
      return e > 1 ? 1 : e < 0 ? 0 : e;
    }
    static Sign(e) {
      return e >= 0 ? 1 : -1;
    }
    static Clamp(e, t, a) {
      return e < t ? t : e > a ? a : e;
    }
    static Lerp(e, t, a) {
      return a < 0 && (a = 0), a > 1 && (a = 1), e + (t - e) * a;
    }
    static Repeat(e, t) {
      var a = e - Math.floor(e / t) * t;
      return a < 0 ? 0 : a > t ? t : a;
    }
    static PingPong(e, t) {
      var a = 2 * t,
        n = e - Math.floor(e / a) * a;
      return (e = n < 0 ? 0 : n > a ? a : n), t - Math.abs(e - t);
    }
  }
  Mathf.__name__ = "Mathf";
  class OfflineReward extends ScriptComponent {
    constructor(e) {
      super(e), (this.checkElapsed = 0);
    }
    initialize() {
      super.initialize(), this.OnEnable();
      var e = this;
      this.on(
        "state",
        function (t) {
          return t && e.OnEnable(), !0;
        },
        this
      );
    }
    OnEnable() {
      (this.lastTime = HxOverrides.strDate(
        PlayerPrefs.GetString("OfflineTime", HxOverrides.dateStr(new Date()))
      )),
        (new Date().getTime() - this.lastTime.getTime()) / 1e3 / 60 / 60 <
        OfflineReward.rewardGapHours
          ? (this.checkElapsed = 0)
          : motion_Actuate
              .timer(1)
              .onComplete($bind(($_ = UIManager.inst), $_.OfflineRewardCheck)),
        (this.checkElapsed = 100),
        this.update(0);
    }
    update(e) {
      if (
        (super.update(e), (this.checkElapsed += e), !(this.checkElapsed < 0.5))
      ) {
        var t =
          1e3 * OfflineReward.rewardGapHours * 60 * 60 -
          (new Date().getTime() - this.lastTime.getTime());
        (t /= 1e3) < 0 && (t = 0);
        var a = Math.floor(t / 3600),
          n = Math.floor((t - 60 * a * 60) / 60),
          i = Math.floor(t - 60 * a * 60 - 60 * n),
          s = a + ":" + StringTools.lpad(n + "", "0", 2) + ":",
          r = StringTools.lpad(i + "", "0", 2);
        (this.entity.element.text = s + r),
          t <= 0 && UIManager.inst.OfflineRewardCheck();
      }
    }
  }
  (OfflineReward.__name__ = "OfflineReward"),
    (OfflineReward.__super__ = ScriptComponent),
    Object.assign(OfflineReward.prototype, { __class__: OfflineReward });
  class PauseOverlay extends ScriptComponent {
    initialize() {
      super.initialize(),
        (PauseOverlay.inst = this),
        (this.entity.enabled = !1);
    }
    static Activate() {
      PauseOverlay.isActive ||
        ((PauseOverlay.isActive = !0),
        null != PauseOverlay.inst && (PauseOverlay.inst.entity.enabled = !0));
    }
    static Deactivate() {
      PauseOverlay.isActive &&
        ((PauseOverlay.isActive = !1),
        null != PauseOverlay.inst && (PauseOverlay.inst.entity.enabled = !1));
    }
  }
  (PauseOverlay.__name__ = "PauseOverlay"),
    (PauseOverlay.__super__ = ScriptComponent),
    Object.assign(PauseOverlay.prototype, { __class__: PauseOverlay });
  class PiggyAnimReceiver extends ScriptComponent {
    constructor(e) {
      super(e),
        (this.dist = 0),
        (this.isMoving = !1),
        (this.startRots = null),
        (this.startPoses = null),
        (this.sended = 0),
        (this.coins = null),
        (this.moreCoins = null),
        (this.lessCoins = null);
    }
    initialize() {
      super.initialize();
      var e = this;
      this.entity.anim.on(
        "SetActive",
        function (t) {
          return e.SetActiveFromAnimEv(t), !0;
        },
        this
      ),
        this.entity.anim.on(
          "EnableCoins",
          function (t) {
            return e.EnableCoins(), !0;
          },
          this
        ),
        this.entity.anim.on(
          "StartMoveCoins",
          function (t) {
            return e.StartMoveCoins(), !0;
          },
          this
        ),
        this.entity.anim.on(
          "RemoveAdHammer",
          function (t) {
            return e.RemoveAdHammer(), !0;
          },
          this
        ),
        this.entity.anim.on(
          "RemoveAdGlass",
          function (t) {
            return e.RemoveAdGlass(), !0;
          },
          this
        ),
        this.OnEnable(),
        this.entity.on(
          "state",
          function (t) {
            return t && e.OnEnable(), !0;
          },
          this
        );
    }
    OnEnable() {
      if (
        ((this.entity.element.opacity = 1),
        (this.entity.element.mask = !0),
        !APIManager.HasFeature("rewarded"))
      ) {
        var e = this.entity.parent.findByPath("VideoClaim"),
          t = this.entity.parent.findByPath("ClaimYoutube"),
          a = this.entity.parent.findByPath("OfflineSimpleClaim");
        (UIManager.inst.meterPriceText = t.findByName("Price")),
          (a.enabled = !1),
          (e.enabled = !1),
          (t.enabled = !0);
      }
    }
    SetActiveFromAnimEv(e) {
      var t = this.entity.findByPath(e.string);
      null != t && (t.enabled = 1 == e.number);
    }
    update(e) {
      if ((super.update(e), this.isMoving))
        for (var t = 0, a = this.coins.length; t < a; ) {
          var n = t++;
          if (this.coins[n].enabled) {
            this.dist = _$Vector3_Vector3_$Impl_$
              .sub(
                this.coins[n].getPosition().clone(),
                this.targetPoint.getPosition().clone()
              )
              .length();
            var i = this.coins[n],
              s = this.coins[n].getPosition().clone(),
              r = this.targetPoint.getPosition().clone(),
              o = e / (this.dist / this.speed[n]);
            o = o > 1 ? 1 : o < 0 ? 0 : o;
            var l = s.x + (r.x - s.x) * o,
              u = s.y + (r.y - s.y) * o,
              c = s.z + (r.z - s.z) * o;
            null == c && (c = 0), null == u && (u = 0), null == l && (l = 0);
            var h = new pc.Vec3(l, u, c);
            i.setPosition(h);
            var p = this.coins[n],
              m = this.coins[n].getRotation().clone(),
              _ = _$Quaternion_Quaternion_$Impl_$.get_IDENTITY(),
              d = e / (this.dist / this.speed[n]);
            d = d > 1 ? 1 : d < 0 ? 0 : d;
            var g = _$Quaternion_Quaternion_$Impl_$.slerp(
              _$Quaternion_Quaternion_$Impl_$.clone(m),
              m,
              _,
              d
            );
            p.setRotation(g), this.dist < 0.02 && this.GemSent(n);
          }
        }
    }
    EnableCoins() {
      (this.coins = null),
        PiggyAnimReceiver.amountToSend <= 200
          ? (this.coins = this.lessCoins)
          : (this.coins = this.moreCoins),
        (this.sended = 0),
        (this.startPoses = []),
        (this.startRots = []),
        (this.speed = []);
      for (var e = 0, t = this.coins.length; e < t; ) {
        var a = e++;
        this.startPoses.push(this.coins[a].getLocalPosition().clone()),
          this.startRots.push(this.coins[a].getLocalRotation().clone()),
          this.speed.push(100 * (17 + 10 * Math.random()) * 0.0014),
          (this.coins[a].enabled = !0);
      }
    }
    StartMoveCoins() {
      (this.isMoving = !0),
        (this.entity.element.mask = !1),
        (this.entity.element.opacity = 0);
    }
    GemSent(e) {
      this.coins[e].enabled = !1;
      var t = this.startPoses[e];
      this.coins[e].setLocalPosition(t);
      var a = this.startRots[e];
      this.coins[e].setLocalRotation(a),
        null != UIManager.inst &&
          UIManager.inst.AddCurrency(
            PiggyAnimReceiver.amountToSend / this.coins.length,
            "Currency_1"
          ),
        (this.sended += 1),
        this.sended >= this.coins.length &&
          ((this.isMoving = !1), this.GemsSended());
    }
    GemsSended() {
      UIManager.inst.OnCurrencyAdded(
        PiggyAnimReceiver.amountToSend,
        "coins",
        "Meta",
        "PiggyFullPopup"
      ),
        (this.startPoses = []),
        (this.startRots = []),
        (this.speed = []),
        (PiggyAnimReceiver.amountToSend = 0),
        UIManager.inst.PiggyCoinsSended();
    }
    RemoveAdHammer() {
      MainManager.inst.PlayOneShot("Hammer");
    }
    RemoveAdGlass() {
      MainManager.inst.PlayOneShot("Glass");
    }
  }
  (PiggyAnimReceiver.__name__ = "PiggyAnimReceiver"),
    (PiggyAnimReceiver.__super__ = ScriptComponent),
    Object.assign(PiggyAnimReceiver.prototype, {
      __class__: PiggyAnimReceiver,
    });
  class PingPongScale extends ScriptComponent {
    constructor(e) {
      super(e),
        (this.speed = 1),
        (this.maxScale = new pc.Vec3(1.1, 1.1, 1.1)),
        (this.minScale = _$Vector3_Vector3_$Impl_$.one);
    }
    initialize() {
      super.initialize();
    }
    update(e) {
      super.update(e), (this.time = (pc.now() / 1e3) * this.speed);
      var t = this.time,
        a = this.maxScale.x - 1,
        n = 2 * a,
        i = t - Math.floor(t / n) * n;
      (t = i < 0 ? 0 : i > n ? n : i),
        (this.xPingVal = a - Math.abs(t - a) + this.minScale.x);
      var s = this.time,
        r = this.maxScale.y - 1,
        o = 2 * r,
        l = s - Math.floor(s / o) * o;
      (s = l < 0 ? 0 : l > o ? o : l),
        (this.yPingVal = r - Math.abs(s - r) + this.minScale.y);
      var u = this.entity,
        c = this.xPingVal,
        h = this.yPingVal,
        p = this.entity.getLocalScale().clone().z;
      null == p && (p = 0), null == h && (h = 0), null == c && (c = 0);
      var m = new pc.Vec3(c, h, p);
      u.setLocalScale(m);
    }
  }
  (PingPongScale.__name__ = "PingPongScale"),
    (PingPongScale.__super__ = ScriptComponent),
    Object.assign(PingPongScale.prototype, { __class__: PingPongScale });
  class PlayerPrefs {
    static initStorage() {
      PlayerPrefs.inited ||
        (null == PlayerPrefs.localStorage &&
          (PlayerPrefs.localStorage = window.GameInterface.storage),
        null != PlayerPrefs.localStorage && (PlayerPrefs.inited = !0));
    }
    static DeleteAll() {
      PlayerPrefs.initStorage(),
        null != PlayerPrefs.localStorage && PlayerPrefs.localStorage.clear();
    }
    static DeleteKey(e) {
      PlayerPrefs.initStorage(), PlayerPrefs.localStorage.removeItem(e);
    }
    static GetFloat(e, t) {
      null == t && (t = 0), PlayerPrefs.initStorage();
      var a = PlayerPrefs.localStorage.getItem(e);
      return null != a ? parseFloat(a) : t;
    }
    static GetInt(e, t) {
      null == t && (t = 0), PlayerPrefs.initStorage();
      var a = PlayerPrefs.localStorage.getItem(e);
      return null != a ? Std.parseInt(a) : t;
    }
    static GetBool(e, t) {
      null == t && (t = !1), PlayerPrefs.initStorage();
      var a = PlayerPrefs.localStorage.getItem(e);
      return null != a ? 1 == Std.parseInt(a) : t;
    }
    static GetString(e, t) {
      PlayerPrefs.initStorage();
      var a = PlayerPrefs.localStorage.getItem(e);
      return null != a ? a : t;
    }
    static GetIntArray(e) {
      PlayerPrefs.initStorage();
      var t = PlayerPrefs.localStorage.getItem(e),
        a = [];
      if (null == t) return a;
      for (var n = t.split(";"), i = 0, s = n.length; i < s; ) {
        var r = i++;
        a.push(Std.parseInt(n[r]));
      }
      return a;
    }
    static GetFloatArray(e) {
      PlayerPrefs.initStorage();
      var t = PlayerPrefs.localStorage.getItem(e),
        a = [];
      if (null == t) return a;
      for (var n = t.split(";"), i = 0, s = n.length; i < s; ) {
        var r = i++;
        a.push(parseFloat(n[r]));
      }
      return a;
    }
    static SetIntArray(e, t) {
      PlayerPrefs.initStorage(),
        PlayerPrefs.localStorage.setItem(e, t.join(";"));
    }
    static SetFloatArray(e, t) {
      PlayerPrefs.initStorage(),
        PlayerPrefs.localStorage.setItem(e, t.join(";"));
    }
    static SetString(e, t) {
      PlayerPrefs.initStorage(), PlayerPrefs.localStorage.setItem(e, t);
    }
    static SetFloat(e, t) {
      PlayerPrefs.initStorage(), PlayerPrefs.localStorage.setItem(e, t + "");
    }
    static SetInt(e, t) {
      PlayerPrefs.initStorage(), PlayerPrefs.localStorage.setItem(e, t + "");
    }
    static SetBool(e, t) {
      PlayerPrefs.initStorage(), PlayerPrefs.localStorage.setItem(e, t ? 1 : 0);
    }
    static HasKey(e) {
      return (
        PlayerPrefs.initStorage(),
        null != PlayerPrefs.localStorage &&
          null != PlayerPrefs.localStorage.getItem(e)
      );
    }
  }
  PlayerPrefs.__name__ = "PlayerPrefs";
  class ProgressionBoxSystem extends ScriptComponent {
    constructor(e) {
      super(e),
        (this.rwOpenBtnPlacements = "button.progression.open"),
        (this.openBtnYoutube = null),
        (this.capNum = 0),
        (this.btnAnimator = null),
        (this.itemImage = null),
        (this.progText = null),
        (this.progImage = null),
        (this.progContinueBtn = null),
        (this.progClaimBtn = null),
        (this.progRewardBtn = null),
        (this.progSkipBtn = null),
        (this.confetti = null),
        (this.progressBoxAnim = null);
    }
    initialize() {
      super.initialize(), this.OnEnable();
      var e = this;
      this.on(
        "state",
        function (t) {
          return t && e.OnEnable(), !0;
        },
        this
      ),
        AdLoadingIcon.SetPlacementForEntity(
          this.progRewardBtn,
          this.rwOpenBtnPlacements
        ),
        UIHelper.AddButtonClickHandler(
          this.progRewardBtn,
          $bind(this, this.UI_PP_ClaimBtn)
        ),
        UIHelper.AddButtonClickHandler(
          this.progClaimBtn,
          $bind(this, this.UI_PP_SkipBtn)
        ),
        UIHelper.AddButtonClickHandler(
          this.progSkipBtn,
          $bind(this, this.UI_PP_SkipBtn)
        ),
        APIManager.HasFeature("rewarded") ||
          ((this.openBtnYoutube = this.entity.findByName("OpenBtnYoutube")),
          UIHelper.AddButtonClickHandler(
            this.openBtnYoutube,
            $bind(this, this.UI_PP_ClaimBtn)
          ),
          (this.openBtnYoutube.enabled = !0),
          (this.progRewardBtn.enabled = !1),
          (this.progClaimBtn.enabled = !1),
          (this.progSkipBtn.enabled = !1)),
        (this.confetti = this.progressBoxAnim.findByName(
          "NewConfettiWithTrails"
        ));
    }
    OnEnable() {}
    DisplayBtns(e) {
      e >= 1
        ? ((this.progContinueBtn.enabled = !1),
          (this.progSkipBtn.enabled = !0),
          (this.progRewardBtn.enabled = !0),
          APIManager.HasFeature("rewarded") ||
            ((this.openBtnYoutube.enabled = !0),
            (this.progSkipBtn.enabled = !1),
            (this.progRewardBtn.enabled = !1)))
        : ((this.progSkipBtn.enabled = !1),
          (this.progRewardBtn.enabled = !1),
          (this.btnAnimator.anim.enabled = !0),
          (this.progContinueBtn.enabled = !0),
          APIManager.HasFeature("rewarded") ||
            (this.openBtnYoutube.enabled = !1));
    }
    UI_PP_ClaimBtn() {
      null != MainManager.inst && MainManager.inst.PlayOneShot("BtnClick");
      var e = this;
      null != APIManager.inst
        ? APIManager.ShowRewardedAD(function (t) {
            t
              ? motion_Actuate
                  .timer(0.35)
                  .onComplete($bind(e, e.GiveProgressReward))
              : haxe_Log.trace("Failed callback here", {
                  fileName: "src/ProgressionBoxSystem.hx",
                  lineNumber: 136,
                  className: "ProgressionBoxSystem",
                  methodName: "UI_PP_ClaimBtn",
                });
          }, this.rwOpenBtnPlacements)
        : haxe_Log.trace("APIManager not found", {
            fileName: "src/ProgressionBoxSystem.hx",
            lineNumber: 142,
            className: "ProgressionBoxSystem",
            methodName: "UI_PP_ClaimBtn",
          });
    }
    GiveProgressReward() {
      var e = [],
        t = this;
      if (
        (PlayerPrefs.GetBool("Tube19", !0) && e.push(19),
        PlayerPrefs.GetBool("Tube20", !0) && e.push(20),
        PlayerPrefs.GetBool("Tube21", !0) && e.push(21),
        PlayerPrefs.GetBool("Tube22", !0) && e.push(22),
        PlayerPrefs.GetBool("Tube23", !0) && e.push(23),
        PlayerPrefs.GetBool("Tube24", !0) && e.push(24),
        PlayerPrefs.GetBool("Tube25", !0) && e.push(25),
        PlayerPrefs.GetBool("Tube26", !0) && e.push(26),
        PlayerPrefs.GetBool("Tube27", !0) && e.push(27),
        e.length > 0)
      ) {
        var a = e[Math.floor(e.length * Math.random())];
        haxe_Log.trace(a + " num skin unlocked", {
          fileName: "src/ProgressionBoxSystem.hx",
          lineNumber: 162,
          className: "ProgressionBoxSystem",
          methodName: "GiveProgressReward",
        }),
          PlayerPrefs.SetBool("Tube" + a, !1),
          (this.progSkipBtn.enabled = !1),
          (this.progRewardBtn.enabled = !1),
          (this.progClaimBtn.enabled = !0),
          APIManager.HasFeature("rewarded") ||
            (this.openBtnYoutube.enabled = !1),
          (this.progressBoxAnim.enabled = !0),
          null != this.progressBoxAnim &&
            null != this.progressBoxAnim.anim &&
            this.progressBoxAnim.anim.setTrigger("Open"),
          motion_Actuate.timer(0.8).onComplete(function () {
            null != t.confetti && (t.confetti.enabled = !0);
          });
        try {
          this.itemImage.enabled = !0;
          var n =
            "Resources/ShopBottles/" +
            StringTools.lpad(null == a ? "null" : "" + a, "0", 3) +
            ".png";
          this.itemImage.element.spriteAsset =
            GameManager.findSpriteAssetIDByPath(n);
        } catch (e) {
          haxe_Log.trace(
            "Asset load exception=>" +
              Std.string(e instanceof js__$Boot_HaxeError ? e.val : e),
            {
              fileName: "src/ProgressionBoxSystem.hx",
              lineNumber: 194,
              className: "ProgressionBoxSystem",
              methodName: "GiveProgressReward",
            }
          );
        }
        1 == PlayerPrefs.GetInt("Audio", 1) &&
          MainManager.inst.PlayOneShot("ProgressBoxOpen");
      }
    }
    UI_PP_SkipBtn() {
      UIManager.inst.CloseChestPanel(),
        (this.entity.enabled = !1),
        this.entity.destroy();
    }
    UI_PP_MissBtn() {
      PlayerPrefs.SetFloat("ProgValue", 0.1),
        PlayerPrefs.SetFloat("ProgressVal", 0),
        UIManager.inst.OnCloseProgressPanel(),
        this.entity.destroy();
    }
  }
  (ProgressionBoxSystem.__name__ = "ProgressionBoxSystem"),
    (ProgressionBoxSystem.__super__ = ScriptComponent),
    Object.assign(ProgressionBoxSystem.prototype, {
      __class__: ProgressionBoxSystem,
    });
  class _$Quaternion_Quaternion_$Impl_$ {
    static get_IDENTITY() {
      return new pc.Quat(0, 0, 0, 1);
    }
    static Euler(e) {
      var t = new pc.Quat(0, 0, 0, 1);
      return _$Quaternion_Quaternion_$Impl_$.setFromEulerAngles(
        t,
        e.x,
        e.y,
        e.z
      );
    }
    static EulerXYZ(e, t, a) {
      var n = new pc.Quat(0, 0, 0, 1);
      return _$Quaternion_Quaternion_$Impl_$.setFromEulerAngles(n, e, t, a);
    }
    static AngleAxis(e, t) {
      var a = new pc.Quat(0, 0, 0, 1);
      return _$Quaternion_Quaternion_$Impl_$.setFromAxisAngle(a, t, e);
    }
    static _new(e, t, a, n) {
      return (
        null == n && (n = 1),
        null == a && (a = 0),
        null == t && (t = 0),
        null == e && (e = 0),
        new pc.Quat(e, t, a, n)
      );
    }
    static Slerp(e, t, a) {
      return (
        (a = a > 1 ? 1 : a < 0 ? 0 : a),
        _$Quaternion_Quaternion_$Impl_$.slerp(
          _$Quaternion_Quaternion_$Impl_$.clone(e),
          e,
          t,
          a
        )
      );
    }
    static LookRotation(e, t) {
      return (
        (e = _$Vector3_Vector3_$Impl_$.normalize(e)),
        null == t && (t = _$Vector3_Vector3_$Impl_$.get_UP()),
        _$Quaternion_Quaternion_$Impl_$.hMatrix.setLookAt(
          _$Quaternion_Quaternion_$Impl_$.zeroVec,
          e,
          t
        ),
        new pc.Quat().setFromMat4(_$Quaternion_Quaternion_$Impl_$.hMatrix)
      );
    }
    static mulQ(e, t) {
      return e.clone().mul(t);
    }
    static mulV(e, t) {
      return e.transformVector(t);
    }
    static clone(e) {
      return e.clone();
    }
    static invert(e) {
      return e.invert();
    }
    static normalize(e) {
      return e.normalize();
    }
    static set(e, t, a, n, i) {
      return e.set(t, a, n, i);
    }
    static setFromAxisAngle(e, t, a) {
      return e.setFromAxisAngle(t, a);
    }
    static setFromEulerAngles(e, t, a, n) {
      return e.setFromEulerAngles(t, a, n);
    }
    static setFromMat4(e, t) {
      return e.setFromMat4(t);
    }
    static slerp(e, t, a, n) {
      return e.slerp(t, a, n);
    }
    static transformVector(e, t, a) {
      return e.transformVector(t, a);
    }
    static copy(e, t) {
      return e.copy(t);
    }
    static mul(e, t) {
      return e.mul(t);
    }
    static getEulerAngles(e, t) {
      return e.getEulerAngles(t);
    }
  }
  (_$Quaternion_Quaternion_$Impl_$.__name__ = "_Quaternion.Quaternion_Impl_"),
    (_$Quaternion_Quaternion_$Impl_$.__properties__ = {
      get_IDENTITY: "get_IDENTITY",
    });
  class Random {
    static bool() {
      return Math.random() < 0.5;
    }
    static int(e, t) {
      return e + Math.floor((t - e) * Math.random());
    }
    static float(e, t) {
      return e + (t - e) * Math.random();
    }
    static floatFromArrayIndex0_1(e) {
      var t = e[0];
      return t + (e[1] - t) * Math.random();
    }
    static intFromArrayIndex0_1(e) {
      var t = e[0];
      return t + Math.floor((e[1] - t) * Math.random());
    }
    static get_insideUnitSphere() {
      var e = 2 * Math.random() - 1,
        t = 2 * Math.random() - 1,
        a = 2 * Math.random() - 1;
      null == a && (a = 0), null == t && (t = 0), null == e && (e = 0);
      var n = new pc.Vec3(e, t, a);
      return (
        _$Vector3_Vector3_$Impl_$.normalize(n),
        (n = _$Vector3_Vector3_$Impl_$.mulN(n, Math.random()))
      );
    }
    static get_onUnitSphere() {
      var e = 2 * Math.random() - 1,
        t = 2 * Math.random() - 1,
        a = 2 * Math.random() - 1;
      null == a && (a = 0), null == t && (t = 0), null == e && (e = 0);
      var n = new pc.Vec3(e, t, a);
      return _$Vector3_Vector3_$Impl_$.normalize(n), n;
    }
    static string(e, t) {
      null == t &&
        (t = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789");
      for (var a = "", n = 0, i = e; n < i; ) {
        n++;
        a += t.charAt(Math.floor((t.length - 1) * Math.random()));
      }
      return a;
    }
    static date(e, t) {
      var a = e.getTime();
      return new Date(a + (t.getTime() - a) * Math.random());
    }
    static fromArray(e) {
      return null != e && e.length > 0
        ? e[Math.floor((e.length - 1) * Math.random())]
        : null;
    }
    static shuffle(e) {
      if (null != e)
        for (var t = 0, a = e.length; t < a; ) {
          var n = t++,
            i = Math.floor((e.length - 1) * Math.random()),
            s = e[n],
            r = e[i];
          (e[n] = r), (e[i] = s);
        }
      return e;
    }
    static fromIterable(e) {
      if (null != e) {
        var t = Lambda.array(e);
        return null != t && t.length > 0
          ? t[Math.floor((t.length - 1) * Math.random())]
          : null;
      }
      return null;
    }
    static enumConstructor(e) {
      if (null != e) {
        var t = e.__empty_constructs__.slice();
        return null != t && t.length > 0
          ? t[Math.floor((t.length - 1) * Math.random())]
          : null;
      }
      return null;
    }
  }
  (Random.__name__ = "Random"),
    (Random.__properties__ = {
      get_onUnitSphere: "get_onUnitSphere",
      get_insideUnitSphere: "get_insideUnitSphere",
    });
  class RaycastHelper {
    static PlaneRaycast(e, t, a, n) {
      var i = n.dot(e);
      if (Math.abs(i) < 1e-4) return null;
      var s = e.dot(_$Vector3_Vector3_$Impl_$.sub(t, a)) / i;
      if (s < 0) return null;
      var r = _$Vector3_Vector3_$Impl_$.mulN(n, s);
      return new pc.Vec3(a.x + r.x, a.y + r.y, a.z + r.z);
    }
  }
  RaycastHelper.__name__ = "RaycastHelper";
  class Reflect {
    static field(e, t) {
      try {
        return e[t];
      } catch (e) {
        e instanceof js__$Boot_HaxeError && e.val;
        return null;
      }
    }
    static getProperty(e, t) {
      var a;
      return null == e
        ? null
        : !!e.__properties__ && (a = e.__properties__["get_" + t])
        ? e[a]()
        : e[t];
    }
    static setProperty(e, t, a) {
      var n;
      !!e.__properties__ && (n = e.__properties__["set_" + t])
        ? e[n](a)
        : (e[t] = a);
    }
    static fields(e) {
      var t = [];
      if (null != e) {
        var a = Object.prototype.hasOwnProperty;
        for (var n in e)
          "__id__" != n && "hx__closures__" != n && a.call(e, n) && t.push(n);
      }
      return t;
    }
    static compare(e, t) {
      return e == t ? 0 : e > t ? 1 : -1;
    }
  }
  Reflect.__name__ = "Reflect";
  class ResizeLogoByScreen extends ScriptComponent {
    constructor(e) {
      super(e), (this.initElHeight = 0), (this.initElWidth = 0);
    }
    initialize() {
      super.initialize();
      var e = this;
      pc.app.graphicsDevice.on(
        "resizecanvas",
        function () {
          return e.onResize(), !0;
        },
        this
      ),
        (this.initElWidth = this.entity.element.width),
        (this.initElHeight = this.entity.element.height),
        this.onResize();
    }
    onResize() {
      var e = pc.app.graphicsDevice.height / pc.app.graphicsDevice.width;
      this.entity.element.width =
        e > 1.4 ? this.initElWidth - 250 * (e - 1.4) : this.initElWidth;
    }
  }
  (ResizeLogoByScreen.__name__ = "ResizeLogoByScreen"),
    (ResizeLogoByScreen.__super__ = ScriptComponent),
    Object.assign(ResizeLogoByScreen.prototype, {
      __class__: ResizeLogoByScreen,
    });
  class RewardScale extends ScriptComponent {
    initialize() {
      super.initialize();
      var e = this;
      this.entity.anim.on(
        "ScaleValue",
        function (t) {
          return e.ScaleValue(t.number), !0;
        },
        this
      );
    }
    ScaleValue(e) {
      (RewardScale.xRewardVal = e), UIManager.inst.SetEarnedCoin_WP(e);
    }
  }
  (RewardScale.__name__ = "RewardScale"),
    (RewardScale.__super__ = ScriptComponent),
    Object.assign(RewardScale.prototype, { __class__: RewardScale });
  class RotationOnAxis extends ScriptComponent {
    constructor(e) {
      super(e), (this.canMove = !1);
    }
    initialize() {
      super.initialize();
    }
    update(e) {
      super.update(e),
        this.xAxis
          ? this.entity.rotateLocal(this.speed * e, 0, 0)
          : this.yAxis
          ? this.entity.rotateLocal(0, this.speed * e, 0)
          : this.zAxis && this.entity.rotateLocal(0, 0, this.speed * e);
    }
  }
  (RotationOnAxis.__name__ = "RotationOnAxis"),
    (RotationOnAxis.__super__ = ScriptComponent),
    Object.assign(RotationOnAxis.prototype, { __class__: RotationOnAxis });
  class ScaloMeter extends ScriptComponent {
    initialize() {
      super.initialize();
      var e = this;
      this.entity.anim.on(
        "ScaleValue",
        function (t) {
          return e.ScaleValue(t.number), !0;
        },
        this
      );
    }
    ScaleValue(e) {
      UIManager.inst.SetPiggyCoins(e);
    }
  }
  (ScaloMeter.__name__ = "ScaloMeter"),
    (ScaloMeter.__super__ = ScriptComponent),
    Object.assign(ScaloMeter.prototype, { __class__: ScaloMeter });
  class SettingsButtonsManager extends ScriptComponent {
    initialize() {
      super.initialize(), SettingsButtonsManager.allSettingsButtons.push(this);
      var e = this;
      if (
        (this.entity.on(
          "destroy",
          function () {
            return e.OnDestroy(), !0;
          },
          this
        ),
        !APIManager.HasFeature("audio"))
      ) {
        (this.entity.enabled = !1),
          null != this.entity.element && (this.entity.element.enabled = !1),
          null != this.entity.button && (this.entity.button.enabled = !1);
        var t = this.entity,
          a = t.getLocalPosition().clone(),
          n = 1e6,
          i = 1e6,
          s = 0;
        null == s && (s = 0), null == i && (i = 0), null == n && (n = 0);
        var r = new pc.Vec3(n, i, s),
          o = new pc.Vec3(a.x + r.x, a.y + r.y, a.z + r.z);
        t.setLocalPosition(o);
        var l = this.entity,
          u = l.getLocalScale().clone(),
          c = _$Vector3_Vector3_$Impl_$.zero,
          h = new pc.Vec3(u.x + c.x, u.y + c.y, u.z + c.z);
        l.setLocalScale(h);
      }
    }
    OnDestroy() {
      HxOverrides.remove(SettingsButtonsManager.allSettingsButtons, this);
    }
  }
  (SettingsButtonsManager.__name__ = "SettingsButtonsManager"),
    (SettingsButtonsManager.__super__ = ScriptComponent),
    Object.assign(SettingsButtonsManager.prototype, {
      __class__: SettingsButtonsManager,
    });
  class ShopItems extends ScriptComponent {
    constructor(e) {
      super(e),
        (this.itemImage = null),
        (this.myImage = null),
        (this.isLocked = !0),
        (this.defaultLocked = !0),
        (this.shopCategory = 0),
        (this.itemNum = 0);
    }
    initialize() {
      super.initialize(), this.OnEnable();
      var e = this;
      this.on(
        "state",
        function (t) {
          return t && e.OnEnable(), !0;
        },
        this
      ),
        UIHelper.AddButtonClickHandler(
          this.entity,
          $bind(this, this.UI_OnSelectItem)
        );
    }
    OnEnable() {
      this.OnSceneLoad();
    }
    OnSceneLoad() {
      (this.isLocked = PlayerPrefs.GetBool(
        _$MainManager_ShopCategory_$Impl_$.ToString(this.shopCategory) +
          this.itemNum,
        this.defaultLocked
      )),
        PlayerPrefs.GetBool("IsSubsBuyed", !1) && (this.isLocked = !1),
        this.isLocked
          ? ((this.myImage.element.spriteAsset =
              MainManager.inst.itemLocked.id),
            (this.itemImage.enabled = !1),
            1 == this.shopCategory &&
              (this.myImage.element.color = _$Color_Color_$Impl_$.get_WHITE()))
          : MainManager.pickedItemNum[this.shopCategory] == this.itemNum
          ? this.SelectItem()
          : this.ResetItem();
    }
    SelectItem() {
      null != UIManager.currShopItem && UIManager.currShopItem.ResetItem(),
        1 == this.shopCategory
          ? ((this.myImage.element.color = MainManager.inst.itemSelectedCol),
            (this.myImage.button.hoverTint = MainManager.inst.itemSelectedCol),
            (this.myImage.element.spriteAsset =
              MainManager.inst.itemUnlocked2.id))
          : (this.myImage.element.spriteAsset =
              MainManager.inst.itemSelected.id),
        (this.itemImage.enabled = !0),
        MainManager.inst.NewItemUsing(this.shopCategory, this.itemNum),
        (UIManager.currShopItem = this);
    }
    ResetItem() {
      var e = this.entity,
        t = _$Vector3_Vector3_$Impl_$.get_ONE();
      e.setLocalScale(t),
        1 == this.shopCategory
          ? ((this.myImage.element.color = _$Color_Color_$Impl_$.get_WHITE()),
            (this.myImage.button.hoverTint = _$Color_Color_$Impl_$.get_WHITE()),
            (this.myImage.element.spriteAsset =
              MainManager.inst.itemUnlocked2.id))
          : (this.myImage.element.spriteAsset =
              MainManager.inst.itemUnlocked.id),
        (this.itemImage.enabled = !0);
    }
    UnlockItem(e) {
      PlayerPrefs.SetBool(
        _$MainManager_ShopCategory_$Impl_$.ToString(this.shopCategory) +
          this.itemNum,
        !1
      ),
        PlayerPrefs.GetBool("IsSubsBuyed", !1)
          ? (this.isLocked = !1)
          : (this.isLocked = PlayerPrefs.GetBool(
              _$MainManager_ShopCategory_$Impl_$.ToString(this.shopCategory) +
                this.itemNum,
              this.defaultLocked
            )),
        e && this.UI_OnSelectItem();
    }
    UI_OnSelectItem() {
      this.isLocked || this.SelectItem();
    }
  }
  (ShopItems.__name__ = "ShopItems"),
    (ShopItems.__super__ = ScriptComponent),
    Object.assign(ShopItems.prototype, { __class__: ShopItems });
  class ShopSwitchBtnsHandler extends ScriptComponent {
    constructor(e) {
      super(e), (this.curActiveBtnIdx = 0);
    }
    initialize() {
      super.initialize();
      for (var e = this, t = 0, a = this.buttons.length; t < a; ) {
        var n = t++,
          i = [n];
        UIHelper.AddButtonClickHandler(
          this.buttons[n].button,
          (function (t) {
            return function () {
              e.onBtnClick(t[0]);
            };
          })(i)
        );
      }
      this.updateBtns();
    }
    onBtnClick(e) {
      (this.curActiveBtnIdx = e), this.updateBtns();
      for (var t = 0, a = this.buttons.length; t < a; ) {
        var n = t++;
        this.buttons[n].shopPanel.enabled = n == e;
      }
      "" != this.buttons[e].uiManagerCallback &&
        Reflect.field(UIManager.inst, this.buttons[e].uiManagerCallback).apply(
          UIManager.inst,
          null
        );
    }
    updateBtns() {
      for (var e = 0, t = this.buttons.length; e < t; ) {
        var a = e++;
        this.buttons[a].imageEntity.element.spriteAsset =
          a == this.curActiveBtnIdx
            ? this.buttons[a].activeSprite.id
            : this.buttons[a].inactiveSprite.id;
      }
    }
  }
  (ShopSwitchBtnsHandler.__name__ = "ShopSwitchBtnsHandler"),
    (ShopSwitchBtnsHandler.__super__ = ScriptComponent),
    Object.assign(ShopSwitchBtnsHandler.prototype, {
      __class__: ShopSwitchBtnsHandler,
    });
  class SleepZParticles extends ScriptComponent {
    constructor(e) {
      super(e), (this.leftTimeToGen = 0), (this.particlesData = []);
    }
    initialize() {
      super.initialize(), (this.baseEntity.enabled = !1);
    }
    genNewParticle() {
      var e = EntityHelper.Instantiate(this.baseEntity, this.baseEntity.parent);
      e.enabled = !0;
      var t = e,
        a = t.getLocalScale().clone(),
        n = this.startSize.x,
        i = _$Vector3_Vector3_$Impl_$.mulN(
          a,
          n + (this.startSize.y - n) * Math.random()
        );
      t.setLocalScale(i);
      var s = e,
        r = s.getLocalPosition().clone(),
        o = _$Vector3_Vector3_$Impl_$.mulN(Random.get_onUnitSphere(), 5),
        l = new pc.Vec3(r.x + o.x, r.y + o.y, r.z + o.z);
      s.setLocalPosition(l);
      var u = (Math.PI / 2) * Math.random(),
        c = new pc.Vec2(Math.cos(u), Math.sin(u)),
        h = this.particlesData,
        p = this.lifetime.x,
        m = p + (this.lifetime.y - p) * Math.random(),
        _ = e.getLocalScale().clone(),
        d = this.speed.x;
      h.push({
        entity: e,
        lifetime: m,
        initSc: _,
        elapsed: 0,
        speed: d + (this.speed.y - d) * Math.random(),
        dir: c,
      });
    }
    update(e) {
      if (
        (super.update(e), (this.leftTimeToGen -= e), this.leftTimeToGen <= 0)
      ) {
        this.genNewParticle();
        var t = 1 / this.rateOverTime.y;
        this.leftTimeToGen = t + (1 / this.rateOverTime.x - t) * Math.random();
      }
      for (var a = this.particlesData.length; a-- > 0; ) {
        var n = this.particlesData[a];
        if (((n.elapsed += e), n.elapsed >= n.lifetime))
          (n.entity.enabled = !1),
            n.entity.destroy(),
            this.particlesData.splice(a, 1);
        else {
          var i = n.entity.getLocalPosition();
          (i.x += n.speed * e * n.dir.x),
            (i.y += n.speed * e * n.dir.y),
            n.entity.setLocalPosition(i);
          var s = n.elapsed / n.lifetime,
            r = motion_easing_Quad.easeIn.calculate(s);
          n.entity.element.opacity = 1 - r;
          var o = n.entity,
            l = _$Vector3_Vector3_$Impl_$.mulN(
              n.initSc,
              0.5 + 0.5 * motion_easing_Quart.easeOut.calculate(s)
            );
          o.setLocalScale(l);
        }
      }
    }
  }
  (SleepZParticles.__name__ = "SleepZParticles"),
    (SleepZParticles.__super__ = ScriptComponent),
    Object.assign(SleepZParticles.prototype, { __class__: SleepZParticles });
  class SortingGroup extends ScriptComponent {
    constructor(e) {
      super(e), (this.inited = !1), (this.initSpritesData = []);
    }
    initialize() {
      SortingGroup.AllSortingGroups.push(this), SortingGroupsManager.init();
      var e = this;
      this.on("destroy", function (t) {
        return e.OnDestroy(), !0;
      });
    }
    OnDestroy() {
      HxOverrides.remove(SortingGroup.AllSortingGroups, this);
    }
    init() {
      if (!this.inited) {
        this.inited = !0;
        for (
          var e = this.entity.findComponents("sprite"), t = 0, a = e.length;
          t < a;

        ) {
          var n = t++;
          this.initSpritesData.push({
            sprite: e[n],
            initDrawOrder: 0 | e[n].drawOrder,
          });
        }
      }
    }
  }
  (SortingGroup.__name__ = "SortingGroup"),
    (SortingGroup.__super__ = ScriptComponent),
    Object.assign(SortingGroup.prototype, { __class__: SortingGroup });
  class SortingGroupsManager extends ScriptComponent {
    initialize() {}
    updateSortingGroupsDrawOrder() {
      for (
        var e = {}, t = [], a = 0, n = SortingGroup.AllSortingGroups.length;
        a < n;

      ) {
        var i = a++,
          s = SortingGroup.AllSortingGroups[i];
        s.init(),
          e.hasOwnProperty(s.orderInLayer) ||
            ((e[s.orderInLayer] = []), t.push(s.orderInLayer)),
          e[s.orderInLayer].push(s);
      }
      t.sort(Reflect.compare);
      for (var r = 0, o = 0, l = t.length; o < l; )
        for (var u = e[t[o++]], c = 0, h = u.length; c < h; ) {
          for (
            var p = u[c++], m = 0, _ = 0, d = p.initSpritesData.length;
            _ < d;

          ) {
            var g = _++,
              y = p.initSpritesData[g],
              v = y.initDrawOrder + r;
            null != y.sprite && ((y.sprite.drawOrder = v), v > m && (m = v));
          }
          r = m + 1;
        }
    }
    postUpdate(e) {
      super.postUpdate(e), this.updateSortingGroupsDrawOrder();
    }
    static init() {
      if (
        !SortingGroupsManager.inited &&
        null != pc.app &&
        null != pc.app.root
      ) {
        SortingGroupsManager.inited = !0;
        var e = new pc.Entity("SortingGroupsManager", pc.app);
        pc.app.root.addChild(e), e.addComponent("script");
        e.script.create("sortingGroupsManager");
      }
    }
  }
  (SortingGroupsManager.__name__ = "SortingGroupsManager"),
    (SortingGroupsManager.__super__ = ScriptComponent),
    Object.assign(SortingGroupsManager.prototype, {
      __class__: SortingGroupsManager,
    });
  class SpinItem extends ScriptComponent {
    constructor(e) {
      super(e), (this.maxPercent = 1), (this.minPercent = 0);
    }
  }
  (SpinItem.__name__ = "SpinItem"),
    (SpinItem.__super__ = ScriptComponent),
    Object.assign(SpinItem.prototype, { __class__: SpinItem });
  class SpinWheel extends ScriptComponent {
    constructor(e) {
      super(e),
        (this.rwSpinPlacement = "button.spinwheel.spin"),
        (this.spinItems = []),
        (this.spinItemsEntities = null),
        (this.curveMode = motion_easing_Quad.easeOut),
        (this.currentPercent = 0),
        (this.totalPercent = 0),
        (this.sended = 0),
        (this.isMoving = !1),
        (this.earnImages = null);
    }
    initialize() {
      super.initialize(), (SpinWheel.inst = this), this.OnEnable();
      var e = this;
      this.entity.on(
        "state",
        function (t) {
          return t && e.OnEnable(), !0;
        },
        this
      );
      for (var t = 0, a = this.spinItemsEntities.length; t < a; ) {
        var n = t++;
        this.spinItems.push(
          EntityHelper.GetComponent_SpinItem(
            this.spinItemsEntities[n],
            SpinItem
          )
        );
      }
      (this.stoperComp = EntityHelper.GetComponent_Stopper(
        this.stopper,
        Stopper
      )),
        UIHelper.AddButtonClickHandler(
          this.crossBtn,
          $bind(this, this.UI_CloseBtn)
        ),
        AdLoadingIcon.SetPlacementForEntity(
          this.spinWithAdBtn,
          this.rwSpinPlacement
        ),
        UIHelper.AddButtonClickHandler(
          this.spinWithAdBtn,
          $bind(this, this.UI_SpinWithAd)
        ),
        UIHelper.AddButtonClickHandler(
          this.spinBtn,
          $bind(this, this.UI_OnSpinClick)
        );
    }
    OnEnable() {
      this.panel.anim.baseLayer.play("ActivateAnim");
      var e = HxOverrides.strDate(
        PlayerPrefs.GetString("SpinTime", HxOverrides.dateStr(new Date()))
      );
      (new Date().getTime() - e.getTime()) / 1e3 / 60 / 60 >=
      TimerDailySpin.spinGapHours
        ? ((this.spinBtn.button.active = !0),
          (this.spinBtn.enabled = !0),
          (this.spinNowBg.enabled = !0),
          (this.timerBg.enabled = !1),
          (this.spinWithAdBtn.enabled = !1))
        : ((this.spinWithAdBtn.button.active = !0),
          (this.spinWithAdBtn.enabled = !0),
          (this.spinNowBg.enabled = !1),
          (this.timerBg.enabled = !0),
          (this.spinBtn.enabled = !1),
          APIManager.HasFeature("rewarded") ||
            ((this.spinWithAdBtn.enabled = !1),
            (this.spinBtn.enabled = !0),
            (this.spinBtn.button.active = !1)));
      var t = Math.round(PlayerPrefs.GetFloat("Currency_1", 0));
      if (((this.coinsTxt.element.text = "" + t), null != this.gemsTxt)) {
        var a = Math.round(PlayerPrefs.GetFloat("Currency_2", 0));
        this.gemsTxt.element.text = "" + a;
      }
      if (null != this.skipsTxt) {
        var n = GameManager.get_SkipLvlCount();
        this.skipsTxt.element.text = "" + n;
      }
      var i = GameManager.get_UndoMovesCount();
      this.undoTxt.element.text = "" + i;
      var s = GameManager.get_EmptyTubesCount();
      this.xtraTubeTxt.element.text = "" + s;
      var r = GameManager.get_HintCounts();
      this.hintsTxt.element.text = "" + r;
    }
    update(e) {
      if ((super.update(e), this.isMoving))
        for (var t = 0, a = this.earnImages.length; t < a; ) {
          var n = t++;
          if (this.earnImages[n].enabled) {
            this.dist = _$Vector3_Vector3_$Impl_$
              .sub(
                this.earnImages[n].getPosition().clone(),
                this.targPoint.getPosition().clone()
              )
              .length();
            var i = this.earnImages[n],
              s = this.earnImages[n].getPosition().clone(),
              r = this.targPoint.getPosition().clone(),
              o = e / (this.dist / this.speed[n]);
            o = o > 1 ? 1 : o < 0 ? 0 : o;
            var l = s.x + (r.x - s.x) * o,
              u = s.y + (r.y - s.y) * o,
              c = s.z + (r.z - s.z) * o;
            null == c && (c = 0), null == u && (u = 0), null == l && (l = 0);
            var h = new pc.Vec3(l, u, c);
            i.setPosition(h), this.dist < 0.02 && this.RewardImageSent(n);
          }
        }
    }
    UI_OnSpinClick() {
      MainManager.inst.PlayOneShot("BtnClick"),
        (this.spinBtn.button.active = !1),
        (this.crossBtn.button.active = !1),
        (this.totalPercent = 0);
      for (var e = 0, t = this.spinItems; e < t.length; ) {
        var a = t[e];
        ++e, (this.totalPercent += a.percentage);
      }
      for (var n = 0, i = 0, s = this.spinItems.length; i < s; ) {
        var r = i++;
        0 == this.spinItems[r].percentage
          ? ((this.spinItems[r].minPercent = -2),
            (this.spinItems[r].maxPercent = -1))
          : ((this.spinItems[r].minPercent = n),
            (this.spinItems[r].maxPercent =
              (this.spinItems[r].percentage / this.totalPercent) * 100 + n),
            (n = this.spinItems[r].maxPercent + 0.1));
      }
      this.currentPercent = 0.1 + (n - 0.1) * Math.random();
      for (var o = 0, l = this.spinItems; o < l.length; ) {
        var u = l[o];
        if (
          (++o,
          u.minPercent <= this.currentPercent &&
            u.maxPercent >= this.currentPercent)
        ) {
          SpinWheel.spinItem = u;
          break;
        }
      }
      this.FakeRotaion();
    }
    UI_CloseBtn() {
      MainManager.inst.PlayOneShot("BtnClick"),
        PlayerPrefs.SetInt("SpinWithAd", 0),
        null != UIManager.inst &&
          (UIManager.inst.ShowChestPanel(!1),
          this.entity.destroy(),
          UIManager.inst.UI_Spin_CloseBtn());
    }
    UI_SpinWithAd() {
      MainManager.inst.PlayOneShot("BtnClick");
      var e = this;
      null != APIManager.inst &&
        APIManager.ShowRewardedAD(function (t) {
          t &&
            (PlayerPrefs.SetInt("SpinWithAd", 1),
            (e.spinWithAdBtn.enabled = !1),
            (e.timerBg.enabled = !1),
            (e.spinNowBg.enabled = !0),
            (e.spinBtn.button.active = !0),
            (e.spinBtn.enabled = !0));
        }, this.rwSpinPlacement);
    }
    FakeRotaion() {
      if (null != SpinWheel.spinItem) {
        haxe_Log.trace(
          "SpeenWheel item = " +
            SpinWheel.spinItem.itemName +
            " " +
            SpinWheel.spinItem.quantity,
          {
            fileName: "src/SpinWheel.hx",
            lineNumber: 211,
            className: "SpinWheel",
            methodName: "FakeRotaion",
          }
        );
        var e = this;
        haxe_Log.trace(this.spinWheel.getLocalEulerAngles().clone().z, {
          fileName: "src/SpinWheel.hx",
          lineNumber: 212,
          className: "SpinWheel",
          methodName: "FakeRotaion",
        }),
          (SpinWheel.stopperTryToStop = !0);
        var t =
          57.2957795130823 *
            Math.atan2(
              SpinWheel.spinItem.entity.getLocalPosition().clone().x,
              SpinWheel.spinItem.entity.getLocalPosition().clone().y
            ) -
          this.spinWheel.getLocalEulerAngles().clone().z;
        t < 0 && (t = 360 - Math.abs(t)),
          null != this.rotActuator &&
            motion_Actuate.stop(this.rotActuator, null, !1, !1);
        for (
          var a = -360 * this.rounds + t,
            n = this.spinWheel.getLocalRotation().clone(),
            i = this.spinWheel.getLocalEulerAngles().clone().z;
          i < 0;

        )
          i += 360;
        for (; i > 360; ) i -= 360;
        var s = 0 | Math.floor(i / 45);
        this.rotActuator = motion_Actuate
          .update(
            function (t) {
              t = e.curveMode.calculate(t);
              var r = e.spinWheel,
                o = new pc.Quat(0, 0, 0, 1),
                l = _$Quaternion_Quaternion_$Impl_$.setFromEulerAngles(
                  o,
                  0,
                  0,
                  t * a
                ),
                u = _$Quaternion_Quaternion_$Impl_$.mulQ(n, l);
              for (
                r.setLocalRotation(u),
                  i = e.spinWheel.getLocalEulerAngles().clone().z;
                i < 0;

              )
                i += 360;
              for (; i > 360; ) i -= 360;
              var c = 0 | Math.floor(i / 45);
              s != c && ((s = c), e.stoperComp.onHitColider());
            },
            this.rotaionTime,
            [0],
            [1]
          )
          .ease(motion_easing_Linear.get_easeNone())
          .onComplete(function () {
            (SpinWheel.stopperTryToStop = !1),
              null != MainManager.inst &&
                MainManager.inst.PlayOneShot("FilledTube"),
              e.GiveReward(),
              (e.rotActuator = null);
          });
      } else
        motion_Actuate.timer(0.2).onComplete($bind(this, this.FakeRotaion));
    }
    GiveReward() {
      if (null != SpinWheel.spinItem)
        switch (SpinWheel.spinItem.itemName) {
          case 0:
            if (0 == PlayerPrefs.GetInt("SpinWithAd", 0))
              try {
                PlayerPrefs.SetString(
                  "SpinTime",
                  HxOverrides.dateStr(new Date())
                );
              } catch (e) {
                haxe_Log.trace(e instanceof js__$Boot_HaxeError ? e.val : e, {
                  fileName: "src/SpinWheel.hx",
                  lineNumber: 285,
                  className: "SpinWheel",
                  methodName: "GiveReward",
                });
              }
            if (
              (PlayerPrefs.SetFloat(
                "Currency_2",
                PlayerPrefs.GetFloat("Currency_2", 0) +
                  SpinWheel.spinItem.quantity
              ),
              UIManager.inst.OnCurrencyAdded(
                SpinWheel.spinItem.quantity,
                "gems",
                "Meta",
                "SpinWheelReward"
              ),
              null != this.gemsTxt)
            ) {
              var e = Math.round(PlayerPrefs.GetFloat("Currency_2", 0));
              this.gemsTxt.element.text = "" + e;
            }
            (this.targPoint = this.gemTargetPos), this.MoveRewardImages();
            break;
          case 1:
            if (0 == PlayerPrefs.GetInt("SpinWithAd", 0))
              try {
                PlayerPrefs.SetString(
                  "SpinTime",
                  HxOverrides.dateStr(new Date())
                );
              } catch (e) {
                haxe_Log.trace(e instanceof js__$Boot_HaxeError ? e.val : e, {
                  fileName: "src/SpinWheel.hx",
                  lineNumber: 300,
                  className: "SpinWheel",
                  methodName: "GiveReward",
                });
              }
            PlayerPrefs.SetFloat(
              "Currency_1",
              PlayerPrefs.GetFloat("Currency_1", 0) +
                SpinWheel.spinItem.quantity
            ),
              UIManager.inst.OnCurrencyAdded(
                SpinWheel.spinItem.quantity,
                "coins",
                "Meta",
                "SpinWheelReward"
              );
            var t = Math.round(PlayerPrefs.GetFloat("Currency_1", 0));
            (this.coinsTxt.element.text = "" + t),
              (this.targPoint = this.coinTargetPos),
              this.MoveRewardImages();
            break;
          case 2:
            if (0 == PlayerPrefs.GetInt("SpinWithAd", 0))
              try {
                PlayerPrefs.SetString(
                  "SpinTime",
                  HxOverrides.dateStr(new Date())
                );
              } catch (e) {
                haxe_Log.trace(e instanceof js__$Boot_HaxeError ? e.val : e, {
                  fileName: "src/SpinWheel.hx",
                  lineNumber: 315,
                  className: "SpinWheel",
                  methodName: "GiveReward",
                });
              }
            var a = GameManager;
            a.set_UndoMovesCount(
              a.get_UndoMovesCount() + SpinWheel.spinItem.quantity
            ),
              UIManager.inst.OnCurrencyAdded(
                SpinWheel.spinItem.quantity,
                "undo",
                "Meta",
                "PowerupUndoSpinWheel"
              );
            var n = GameManager.get_UndoMovesCount();
            (this.undoTxt.element.text = "" + n),
              (this.targPoint = this.undoTargetPos),
              this.MoveRewardImages();
            break;
          case 3:
            if (0 == PlayerPrefs.GetInt("SpinWithAd", 0))
              try {
                PlayerPrefs.SetString(
                  "SpinTime",
                  HxOverrides.dateStr(new Date())
                );
              } catch (e) {
                haxe_Log.trace(e instanceof js__$Boot_HaxeError ? e.val : e, {
                  fileName: "src/SpinWheel.hx",
                  lineNumber: 330,
                  className: "SpinWheel",
                  methodName: "GiveReward",
                });
              }
            var i = GameManager;
            i.set_EmptyTubesCount(
              i.get_EmptyTubesCount() + SpinWheel.spinItem.quantity
            ),
              UIManager.inst.OnCurrencyAdded(
                SpinWheel.spinItem.quantity,
                "undo",
                "Meta",
                "PowerupTubeSpinWheel"
              );
            var s = GameManager.get_EmptyTubesCount();
            (this.xtraTubeTxt.element.text = "" + s),
              (this.targPoint = this.xtraTargetPos),
              this.MoveRewardImages();
            break;
          case 4:
            if (0 == PlayerPrefs.GetInt("SpinWithAd", 0))
              try {
                PlayerPrefs.SetString(
                  "SpinTime",
                  HxOverrides.dateStr(new Date())
                );
              } catch (e) {
                haxe_Log.trace(e instanceof js__$Boot_HaxeError ? e.val : e, {
                  fileName: "src/SpinWheel.hx",
                  lineNumber: 345,
                  className: "SpinWheel",
                  methodName: "GiveReward",
                });
              }
            var r = GameManager;
            r.set_HintCounts(r.get_HintCounts() + SpinWheel.spinItem.quantity),
              UIManager.inst.OnCurrencyAdded(
                SpinWheel.spinItem.quantity,
                "hint",
                "Meta",
                "PowerupHintSpinWheel"
              );
            var o = GameManager.get_HintCounts();
            (this.hintsTxt.element.text = "" + o),
              (this.targPoint = this.hintTargetPos),
              this.MoveRewardImages();
            break;
          case 5:
            if (0 == PlayerPrefs.GetInt("SpinWithAd", 0))
              try {
                PlayerPrefs.SetString(
                  "SpinTime",
                  HxOverrides.dateStr(new Date())
                );
              } catch (e) {
                haxe_Log.trace(e instanceof js__$Boot_HaxeError ? e.val : e, {
                  fileName: "src/SpinWheel.hx",
                  lineNumber: 360,
                  className: "SpinWheel",
                  methodName: "GiveReward",
                });
              }
            var l = GameManager;
            if (
              (l.set_SkipLvlCount(
                l.get_SkipLvlCount() + SpinWheel.spinItem.quantity
              ),
              UIManager.inst.OnCurrencyAdded(
                SpinWheel.spinItem.quantity,
                "skips",
                "Meta",
                "PowerupSkipsSpinWheel"
              ),
              null != this.skipsTxt)
            ) {
              var u = GameManager.get_SkipLvlCount();
              this.skipsTxt.element.text = "" + u;
            }
            (this.targPoint = this.skipsTargetPos), this.MoveRewardImages();
            break;
          case 6:
            (this.spinBtn.button.active = !0),
              (this.crossBtn.button.active = !0);
            break;
          default:
            if (0 == PlayerPrefs.GetInt("SpinWithAd", 0))
              try {
                PlayerPrefs.SetString(
                  "SpinTime",
                  HxOverrides.dateStr(new Date())
                );
              } catch (e) {
                haxe_Log.trace(e instanceof js__$Boot_HaxeError ? e.val : e, {
                  fileName: "src/SpinWheel.hx",
                  lineNumber: 378,
                  className: "SpinWheel",
                  methodName: "GiveReward",
                });
              }
            this.crossBtn.button.active = !0;
        }
      else this.UI_OnSpinClick();
    }
    MoveRewardImages() {
      PlayerPrefs.SetInt("SpinWithAd", 0), (this.speed = []), (this.poses = []);
      for (var e = 0, t = this.earnImages.length; e < t; ) {
        var a = e++;
        this.speed.push((3 + 2 * Math.random()) / 2.5),
          this.poses.push(this.earnImages[a].getPosition().clone()),
          (this.earnImages[a].element.spriteAsset =
            SpinWheel.spinItem.itemSp.id),
          (this.earnImages[a].enabled = !0);
      }
      (this.sended = 0), (this.isMoving = !0);
    }
    RewardImageSent(e) {
      this.earnImages[e].enabled = !1;
      var t = this.poses[e];
      this.earnImages[e].setPosition(t),
        this.sended++,
        this.sended >= this.earnImages.length &&
          ((this.isMoving = !1),
          (this.poses = []),
          (this.speed = []),
          (this.crossBtn.button.active = !0),
          (this.spinBtn.enabled = !1),
          (this.spinWithAdBtn.enabled = !0),
          (this.timerBg.enabled = !0),
          (this.spinNowBg.enabled = !1),
          APIManager.HasFeature("rewarded") ||
            ((this.spinWithAdBtn.enabled = !1),
            (this.spinBtn.enabled = !0),
            (this.spinBtn.button.active = !1)));
    }
    static Vec2SignedAngle(e, t) {
      return SpinWheel.Vec2Angle(e, t) * (e.x * t.y - e.y * t.x >= 0 ? 1 : -1);
    }
    static Vec2Angle(e, t) {
      var a = Math.sqrt(e.lengthSq() * t.lengthSq());
      if (a < 1e-15) return 0;
      var n = e.dot(t) / a,
        i = n < -1 ? -1 : n > 1 ? 1 : n;
      return 57.2957795130823 * Math.acos(i);
    }
    static FromVec3ToVec2(e) {
      return new pc.Vec2(e.x, e.y);
    }
  }
  (SpinWheel.__name__ = "SpinWheel"),
    (SpinWheel.__super__ = ScriptComponent),
    Object.assign(SpinWheel.prototype, { __class__: SpinWheel });
  class SpriteMask extends ScriptComponent {
    initialize() {
      if ((super.initialize(), null != this.entity.sprite)) {
        for (
          var e = this.entity.findComponents("sprite"),
            t = -5e5,
            a = 0,
            n = e.length;
          a < n;

        ) {
          var i = a++;
          e[i].drawOrder > t && (t = 0 | e[i].drawOrder);
        }
        var s = new pc.Entity("StencilClearSprite", pc.app);
        s.addComponent("sprite"),
          (s.sprite.sprite = this.entity.sprite.sprite),
          (s.sprite.spriteAsset = this.entity.sprite.spriteAsset),
          (s.sprite.layers = this.entity.sprite.layers),
          this.entity.parent.addChild(s);
        var r = this.entity.getLocalPosition().clone();
        s.setLocalPosition(r);
        var o = this.entity.getLocalRotation().clone();
        s.setLocalRotation(o);
        var l = this.entity.getLocalScale().clone();
        s.setLocalScale(l);
        var u = this.entity,
          c = !0;
        if (
          (null == c && (c = !0),
          null == u && (u = pc.app.scene.root),
          null != s.parent)
        )
          if (c) {
            var h = s.getWorldTransform().clone(),
              p = u.getWorldTransform().clone().invert();
            h.mul2(p, h);
            var m = h.getTranslation(),
              _ = new pc.Quat().setFromMat4(h),
              d = h.getScale();
            s.reparent(u),
              s.setLocalPosition(m),
              s.setLocalRotation(_),
              s.setLocalScale(d);
          } else s.reparent(u);
        s.sprite.drawOrder = t + 1;
        var g = new pc.StencilParameters({
            readMask: 1,
            writeMask: 1,
            ref: 1,
            zpass: pc.STENCILOP_REPLACE,
          }),
          y = new pc.StencilParameters({
            readMask: 1,
            writeMask: 1,
            ref: 1,
            zpass: pc.STENCILOP_ZERO,
          }),
          v = new pc.StencilParameters({
            readMask: 1,
            writeMask: 1,
            ref: 1,
            func: this.showInside ? pc.FUNC_EQUAL : pc.FUNC_NOTEQUAL,
          }),
          b = this.entity.sprite.material.clone(),
          f = s.sprite.material.clone(),
          S = this.entity.sprite.material.clone();
        (b.stencilBack = b.stencilFront = g),
          (b.redWrite = b.greenWrite = b.blueWrite = b.alphaWrite = !1),
          (this.entity.sprite.material = b),
          (b.alphaToCoverage = !0),
          b.update(),
          (f.stencilBack = f.stencilFront = y),
          (f.redWrite = f.greenWrite = f.blueWrite = f.alphaWrite = !1),
          (s.sprite.material = f),
          (f.alphaToCoverage = !0),
          f.update(),
          (S.stencilBack = S.stencilFront = v);
        for (
          var P = EntityHelper.GetComponentsInChildren_SpriteMasked(
              this.entity,
              SpriteMasked
            ),
            M = 0;
          M < P.length;

        ) {
          var C = P[M];
          ++M;
          var I = C.entity.sprite._model;
          null != I && null != I.meshInstances && I.meshInstances.length > 0
            ? (I.meshInstances[0].material = S)
            : (C.entity.sprite.material = S);
        }
      }
    }
    static getNextStencilRef() {
      return (
        SpriteMask.curStencilRef++,
        SpriteMask.curStencilRef >= 255 && (SpriteMask.curStencilRef = 0),
        SpriteMask.curStencilRef
      );
    }
  }
  (SpriteMask.__name__ = "SpriteMask"),
    (SpriteMask.__super__ = ScriptComponent),
    Object.assign(SpriteMask.prototype, { __class__: SpriteMask });
  class SpriteMasked extends ScriptComponent {}
  (SpriteMasked.__name__ = "SpriteMasked"),
    (SpriteMasked.__super__ = ScriptComponent),
    Object.assign(SpriteMasked.prototype, { __class__: SpriteMasked });
  class Std {
    static string(e) {
      return js_Boot.__string_rec(e, "");
    }
    static parseInt(e) {
      var t = parseInt(
        e,
        !e || "0" != e[0] || ("x" != e[1] && "X" != e[1]) ? 10 : 16
      );
      return isNaN(t) ? null : t;
    }
  }
  Std.__name__ = "Std";
  class Stopper extends ScriptComponent {
    constructor(e) {
      super(e), (this.waitToReset = !1);
    }
    initialize() {
      super.initialize(),
        (this.startPos = this.entity.getLocalPosition().clone()),
        (this.startRot = this.entity.getLocalRotation().clone());
      var e = this.startRot,
        t = this.hitMaxAng,
        a = new pc.Quat(0, 0, 0, 1);
      (this.hitRot = _$Quaternion_Quaternion_$Impl_$.mulQ(
        e,
        _$Quaternion_Quaternion_$Impl_$.setFromEulerAngles(a, 0, 0, t)
      )),
        (this.startRotEuls = this.entity.getLocalEulerAngles().clone());
    }
    update(e) {
      super.update(e);
      var t = this.startPos;
      if (
        (this.entity.setLocalPosition(t),
        this.entity.getLocalEulerAngles().clone().z < 0 ||
          this.entity.getLocalEulerAngles().clone().z > 180)
      ) {
        var a = this.entity,
          n = _$Quaternion_Quaternion_$Impl_$.get_IDENTITY();
        a.setLocalRotation(n);
      }
      if (!this.waitToReset) {
        var i = this.entity,
          s = this.entity.getLocalRotation().clone(),
          r = this.startRot,
          o = this.rotResetSpeed * e;
        o = o > 1 ? 1 : o < 0 ? 0 : o;
        var l = _$Quaternion_Quaternion_$Impl_$.slerp(
          _$Quaternion_Quaternion_$Impl_$.clone(s),
          s,
          r,
          o
        );
        i.setLocalRotation(l);
      }
    }
    onHitColider() {
      this.waitToReset = !0;
      for (
        var e = this,
          t = this.entity.getLocalEulerAngles().clone().z - this.startRotEuls.z;
        t < 0;

      )
        t += 360;
      var a = 0.08 * (1 - t / this.hitMaxAng);
      null != this.curActuator &&
        motion_Actuate.stop(this.curActuator, null, !1, !1);
      var n = this.entity,
        i = this.hitRot;
      this.curActuator = motion_Actuate
        .update(
          EntityTween.slerpAndSetEntityLocalRotation,
          a,
          [n, n.getRotation(), i, 0],
          [n, n.getRotation(), i, 1],
          !0
        )
        .ease(motion_easing_Sine.easeOut)
        .onComplete(function () {
          e.waitToReset = !1;
        });
    }
  }
  (Stopper.__name__ = "Stopper"),
    (Stopper.__super__ = ScriptComponent),
    Object.assign(Stopper.prototype, { __class__: Stopper });
  class StringTools {
    static lpad(e, t, a) {
      if (t.length <= 0) return e;
      var n = "";
      for (a -= e.length; n.length < a; ) n += null == t ? "null" : "" + t;
      return (n += null == e ? "null" : "" + e);
    }
  }
  StringTools.__name__ = "StringTools";
  class SubLvlBtn extends ScriptComponent {}
  (SubLvlBtn.__name__ = "SubLvlBtn"),
    (SubLvlBtn.__super__ = ScriptComponent),
    Object.assign(SubLvlBtn.prototype, { __class__: SubLvlBtn });
  class SwipeShopTab extends ScriptComponent {
    constructor(e) {
      super(e),
        (this.needRestoreButtonsActiveState = !1),
        (this.deactivatedButtons = []),
        (this.allButtons = null),
        (this.currentPage = 1),
        (this.dotImages = null);
    }
    initialize() {
      super.initialize(),
        (this.allButtons = this.entity.findComponents("button"));
      var e = this;
      (this.panelLocation = this.mover.getLocalPosition().clone()),
        this.SetPagesDots();
      for (var t = 0, a = this.dotImages.length; t < a; ) {
        var n = t++;
        (this.dotImages[n].element.useInput = !0),
          this.dotImages[n].addComponent("button");
        var i = [n];
        UIHelper.AddButtonClickHandler(
          this.dotImages[n],
          (function (t) {
            return function () {
              e.onDotClicked(t[0]);
            };
          })(i)
        );
      }
      (this.dragHelper = new pc.ElementDragHelper(this.entity.element, "x")),
        this.dragHelper.on("drag:end", function () {
          return e.OnEndDrag(), !0;
        }),
        this.dragHelper.on("drag:start", function () {
          return (
            e.dragHelper._deltaHandlePosition.copy(
              e.dragHelper._dragStartHandlePosition
            ),
            !0
          );
        }),
        (this.dragHelper._onMove = function (e) {
          const {
            _element: t,
            _deltaMousePosition: a,
            _deltaHandlePosition: n,
            _axis: i,
          } = this;
          if (
            t &&
            this._isDragging &&
            this.enabled &&
            t.enabled &&
            t.entity.enabled
          ) {
            const s = this._screenToLocal(e);
            if (s) {
              if (
                (a.sub2(s, this._dragStartMousePosition),
                n.add2(this._dragStartHandlePosition, a),
                i)
              ) {
                const e = t.entity.getLocalPosition(),
                  a = "y";
                n[a] = e[a];
              }
              this.fire("drag:move", n);
            }
          }
        });
    }
    OnEndDrag() {
      var e =
        (this.dragHelper._dragStartHandlePosition.x -
          this.dragHelper._deltaHandlePosition.x) /
        300;
      if (Math.abs(e) >= this.percentThreshold) {
        var t = this.panelLocation;
        e > 0 && this.currentPage < this.totalPages
          ? (this.currentPage++, (t.x -= this.canvWidth))
          : e < 0 &&
            this.currentPage > 1 &&
            (this.currentPage--, (t.x += this.canvWidth)),
          null != this.tween && motion_Actuate.stop(this.tween, null, !1, !1);
        var a = this.mover,
          n = this.easing,
          i = a.getLocalPosition();
        (this.tween = motion_Actuate.update(
          $bind(a, a.setLocalPosition),
          n,
          [i.x, i.y, i.z],
          [t.x, t.y, t.z],
          !0
        )),
          (this.panelLocation = t),
          this.SetPagesDots();
        for (var s = 0, r = this.allButtons; s < r.length; ) {
          var o = r[s];
          ++s, o.active && (this.deactivatedButtons.push(o), (o.active = !1));
        }
      } else {
        null != this.tween && motion_Actuate.stop(this.tween, null, !1, !1);
        var l = this.mover,
          u = this.panelLocation,
          c = this.easing,
          h = l.getLocalPosition();
        this.tween = motion_Actuate.update(
          $bind(l, l.setLocalPosition),
          c,
          [h.x, h.y, h.z],
          [u.x, u.y, u.z],
          !0
        );
      }
    }
    onDotClicked(e) {
      if (this.currentPage != e + 1) {
        var t = e + 1 - this.currentPage,
          a = this.panelLocation;
        (a.x -= this.canvWidth * t),
          (this.currentPage = e + 1),
          null != this.tween && motion_Actuate.stop(this.tween, null, !1, !1);
        var n = this.mover,
          i = this.easing,
          s = n.getLocalPosition();
        (this.tween = motion_Actuate.update(
          $bind(n, n.setLocalPosition),
          i,
          [s.x, s.y, s.z],
          [a.x, a.y, a.z],
          !0
        )),
          (this.panelLocation = a),
          this.SetPagesDots();
      }
    }
    SetPagesDots() {
      for (var e = 0, t = this.dotImages.length; e < t; ) {
        var a = e++;
        this.dotImages[a].element.spriteAsset = this.unfillDot.id;
      }
      this.dotImages[this.currentPage - 1].element.spriteAsset =
        this.filledDot.id;
    }
    postUpdate(e) {
      if ((super.postUpdate(e), this.deactivatedButtons.length > 0))
        for (; this.deactivatedButtons.length > 0; )
          this.deactivatedButtons.pop().active = !0;
    }
  }
  (SwipeShopTab.__name__ = "SwipeShopTab"),
    (SwipeShopTab.__super__ = ScriptComponent),
    Object.assign(SwipeShopTab.prototype, { __class__: SwipeShopTab });
  class TimerDailySpin extends ScriptComponent {
    constructor(e) {
      super(e), (this.checkElapsed = 0);
    }
    initialize() {
      super.initialize(),
        APIManager.HasFeature("rewarded") || (TimerDailySpin.spinGapHours = 4),
        this.OnEnable();
      var e = this;
      this.on(
        "state",
        function (t) {
          return t && e.OnEnable(), !0;
        },
        this
      );
    }
    OnEnable() {
      (this.lastTime = HxOverrides.strDate(
        PlayerPrefs.GetString("SpinTime", HxOverrides.dateStr(new Date()))
      )),
        (new Date().getTime() - this.lastTime.getTime()) / 1e3 / 60 / 60 <
        TimerDailySpin.spinGapHours
          ? (this.checkElapsed = 0)
          : motion_Actuate
              .timer(1)
              .onComplete($bind(($_ = UIManager.inst), $_.SpinWheelCheck)),
        (this.checkElapsed = 100),
        this.update(0);
    }
    update(e) {
      if (
        (super.update(e), (this.checkElapsed += e), !(this.checkElapsed < 0.5))
      ) {
        var t =
          1e3 * TimerDailySpin.spinGapHours * 60 * 60 -
          (new Date().getTime() - this.lastTime.getTime());
        (t /= 1e3) < 0 && (t = 0);
        var a = Math.floor(t / 3600),
          n = Math.floor((t - 60 * a * 60) / 60),
          i = Math.floor(t - 60 * a * 60 - 60 * n),
          s = a + ":" + StringTools.lpad(n + "", "0", 2) + ":",
          r = StringTools.lpad(i + "", "0", 2);
        (this.entity.element.text = s + r),
          t <= 0 && UIManager.inst.SpinWheelCheck();
      }
    }
  }
  (TimerDailySpin.__name__ = "TimerDailySpin"),
    (TimerDailySpin.__super__ = ScriptComponent),
    Object.assign(TimerDailySpin.prototype, { __class__: TimerDailySpin });
  class TubeController extends ScriptComponent {
    constructor(e) {
      super(e),
        (this.waitesInit = !1),
        (this.sendingCheckTimers = []),
        (this.IsGhostTube = !1),
        (this.stopReceiving = !1),
        (this.col = !0),
        (this.isFliped = !1),
        (this.isSendingStart = !1),
        (this.sendersList = []),
        (this.tubeStage = TubeStage.Idle),
        (this.tempSending = 0),
        (this.tempReceiving = 0),
        (this.flowIndex = 0),
        (this.startPos = _$Vector3_Vector3_$Impl_$.get_ZERO()),
        (this.haveKey = !1),
        (this.data = null),
        (this.colorNames = null),
        (this.filledColors = 0);
    }
    get_CurrLiqColor() {
      return this.filledColors > 0
        ? this.data.waterPortions[this.filledColors - 1].color
        : _$Color_Color_$Impl_$.get_BLACK();
    }
    set_CurrLiqColor(e) {
      return (
        (this.data.waterPortions[this.filledColors - 1].color = e),
        (this.data.waterPortionsTilted[this.filledColors - 1].color = e),
        (this.CurrLiqColor = e)
      );
    }
    get_PortionCanSend() {
      if (0 == this.filledColors || 1 == this.filledColors)
        return this.filledColors;
      for (
        var e = 0, t = this.get_CurrLiqColor(), a = 0, n = this.filledColors;
        a < n;

      ) {
        var i = a++;
        if (
          !_$Color_Color_$Impl_$.equals(
            t,
            js_Boot.__cast(
              this.data.waterPortions[this.filledColors - i - 1].color,
              pc.Color
            )
          )
        )
          break;
        ++e;
      }
      return e;
    }
    get_PortionCanReceive() {
      var e = 4 - this.filledColors;
      return 0 | (e < 0 ? 0 : e > 4 ? 4 : e);
    }
    get_IsColorsMatched() {
      if (
        this.sendersList.length > 0 ||
        this.tubeStage != TubeStage.Idle ||
        this.filledColors < 4
      )
        return !1;
      var e = this.data.waterPortions[0].color;
      return (
        !_$Color_Color_$Impl_$.notequals(
          js_Boot.__cast(this.data.waterPortions[0].color, pc.Color),
          e
        ) &&
        !_$Color_Color_$Impl_$.notequals(
          js_Boot.__cast(this.data.waterPortions[1].color, pc.Color),
          e
        ) &&
        !_$Color_Color_$Impl_$.notequals(
          js_Boot.__cast(this.data.waterPortions[2].color, pc.Color),
          e
        ) &&
        !_$Color_Color_$Impl_$.notequals(
          js_Boot.__cast(this.data.waterPortions[3].color, pc.Color),
          e
        )
      );
    }
    get_IsColorsWillMatch() {
      if (this.filledColors < 4) return !1;
      var e = this.data.waterPortions[0].color;
      return (
        !_$Color_Color_$Impl_$.notequals(
          js_Boot.__cast(this.data.waterPortions[0].color, pc.Color),
          e
        ) &&
        !_$Color_Color_$Impl_$.notequals(
          js_Boot.__cast(this.data.waterPortions[1].color, pc.Color),
          e
        ) &&
        !_$Color_Color_$Impl_$.notequals(
          js_Boot.__cast(this.data.waterPortions[2].color, pc.Color),
          e
        ) &&
        !_$Color_Color_$Impl_$.notequals(
          js_Boot.__cast(this.data.waterPortions[3].color, pc.Color),
          e
        )
      );
    }
    get_LiquidSurfaceY() {
      return this.data.tubeFoam.entity.getPosition().clone().y;
    }
    initialize() {
      super.initialize(), (this.anim = this.entity.anim);
    }
    init() {
      null != GameManager.inst &&
        (GameManager.inst.isMakingLevel
          ? Helpers.Delay(1, $bind(this, this.LoadTubeData))
          : this.LoadTubeData());
    }
    SetAsGhostTube() {
      this.IsGhostTube = !0;
    }
    SetAsActualTube() {
      this.IsGhostTube &&
        ((this.IsGhostTube = !1),
        null != this.data.tubeBackSprite &&
          (this.data.tubeBackSprite.color = _$Color_Color_$Impl_$.get_WHITE()),
        null != this.data.tubeFrontSprite &&
          (this.data.tubeFrontSprite.color = _$Color_Color_$Impl_$.get_WHITE()),
        null != this.data.addIcon && (this.data.addIcon.enabled = !1),
        UIManager.inst.SetXtraTubeCount());
    }
    ClickedOnTube() {
      if (
        (GameManager.inst.isTutorialLvl ||
          1 == GameManager.currMode ||
          !(UIManager.get_RemainingMoves() <= 0)) &&
        this.tubeStage != TubeStage.Receiving &&
        (this.tubeStage != TubeStage.Sending ||
          GameManager.tempFillerTube == this) &&
        !this.IsGhostTube
      ) {
        if (GameManager.inst.isTutorialLvl) {
          var e = EntityHelper.GetComponent_TutorialManager(
            this.entity,
            TutorialManager
          );
          if (null != TutorialManager.lastTut) {
            if (TutorialManager.lastTut == e) return;
            if (TutorialManager.tutorialVal != e.vals[0]) return;
            (TutorialManager.tutorialVal += 1),
              (TutorialManager.lastTut = e),
              e.vals.shift(),
              UIManager.inst.tutorialAnim.anim.setTrigger(
                "" + TutorialManager.tutorialVal
              );
          } else {
            if (TutorialManager.tutorialVal != e.vals[0]) return;
            (TutorialManager.tutorialVal += 1),
              (TutorialManager.lastTut = e),
              e.vals.shift(),
              UIManager.inst.tutorialAnim.anim.setTrigger(
                "" + TutorialManager.tutorialVal
              );
          }
        }
        if (
          this.tubeStage == TubeStage.Idle &&
          null == GameManager.tempFillerTube
        )
          if (this.filledColors > 0 && !this.get_IsColorsMatched()) {
            (this.tubeStage = TubeStage.Sending), this.SendingCheckDelayied(5);
            var t = this.entity.getPosition().clone(),
              a = _$Vector3_Vector3_$Impl_$.mulN(
                _$Vector3_Vector3_$Impl_$.get_UP(),
                0.5
              );
            this.SetTubePos(new pc.Vec3(t.x + a.x, t.y + a.y, t.z + a.z)),
              (GameManager.tempFillerTube = this),
              TubeController.SwitchOffBlinking();
          } else
            this.filledColors > 0 && this.get_IsColorsMatched()
              ? (LevelManager.inst.ReCountSortedTubes(),
                this.anim.baseLayer.play("TubeWrongAnim"),
                MainManager.inst.EmptyTubeClicked())
              : (haxe_Log.trace("You can't pick an empty tube", {
                  fileName: "src/TubeController.hx",
                  lineNumber: 232,
                  className: "TubeController",
                  methodName: "ClickedOnTube",
                }),
                this.anim.baseLayer.play("TubeWrongAnim"),
                MainManager.inst.EmptyTubeClicked());
        else if (this.tubeStage == TubeStage.Sending)
          null == GameManager.tempFillerTube ||
            this.isSendingStart ||
            (this.CancelSendingInvoke(),
            (GameManager.tempFillerTube = null),
            this.SetTubePos(this.startPos),
            (this.tubeStage = TubeStage.Idle));
        else if (
          !(
            (this.tubeStage != TubeStage.Idle &&
              this.tubeStage != TubeStage.Receiving) ||
            (null == GameManager.tempFillerTube &&
              this.tubeStage == TubeStage.Receiving)
          )
        )
          if (
            this.get_PortionCanReceive() <= 0 ||
            this.filledColors + this.tempReceiving >= 4
          )
            this.tubeStage != TubeStage.Receiving &&
              (this.anim.baseLayer.play("TubeWrongAnim"),
              MainManager.inst.FilledTubeClicked()),
              GameManager.tempFillerTube.CancelSendingInvoke(),
              (GameManager.tempFillerTube.tubeStage = TubeStage.Idle),
              GameManager.tempFillerTube.SetTubePos(
                GameManager.tempFillerTube.startPos
              ),
              (GameManager.tempFillerTube = null);
          else if (
            this.sendersList.length > 0 &&
            this.tubeStage != TubeStage.Idle
          ) {
            var n = !0;
            ((this.get_PortionCanReceive() <= 3 &&
              _$Color_Color_$Impl_$.notequals(
                GameManager.tempFillerTube.get_CurrLiqColor(),
                this.get_CurrLiqColor()
              )) ||
              (0 == this.filledColors &&
                _$Color_Color_$Impl_$.notequals(
                  GameManager.tempFillerTube.get_CurrLiqColor(),
                  this.sendersList[0].get_CurrLiqColor()
                ))) &&
              ((n = !1),
              MainManager.inst.FilledTubeClicked(),
              GameManager.tempFillerTube.SetTubePos(
                GameManager.tempFillerTube.startPos
              ),
              (GameManager.tempFillerTube.tubeStage = TubeStage.Idle),
              (GameManager.tempFillerTube = null)),
              n &&
                (this.sendersList.push(GameManager.tempFillerTube),
                GameManager.MoveSenderToReceiver(
                  GameManager.tempFillerTube,
                  this
                ),
                (GameManager.tempFillerTube = null));
          } else {
            var i = !0;
            ((this.get_PortionCanReceive() <= 3 &&
              _$Color_Color_$Impl_$.notequals(
                GameManager.tempFillerTube.get_CurrLiqColor(),
                this.get_CurrLiqColor()
              )) ||
              this.tubeStage != TubeStage.Idle) &&
              ((i = !1),
              MainManager.inst.FilledTubeClicked(),
              this.anim.baseLayer.play("TubeWrongAnim"),
              GameManager.tempFillerTube.anim.baseLayer.play("TubeWrongAnim"),
              GameManager.tempFillerTube.SetTubePos(
                GameManager.tempFillerTube.startPos
              ),
              (GameManager.tempFillerTube.tubeStage = TubeStage.Idle),
              (GameManager.tempFillerTube = null)),
              i &&
                ((this.tubeStage = TubeStage.Receiving),
                this.sendersList.push(GameManager.tempFillerTube),
                GameManager.MoveSenderToReceiver(
                  GameManager.tempFillerTube,
                  this
                ),
                (GameManager.tempFillerTube = null));
          }
      }
    }
    LoadTubeData() {
      if (
        ((this.startPos = this.entity.getPosition().clone()),
        null != GameManager.inst
          ? ((this.data = EntityHelper.GetComponent_TubeData(
              EntityHelper.Instantiate(
                GameManager.inst.GetCurrTube(),
                this.entity
              ),
              TubeData
            )),
            (this.data.entity.enabled = !0))
          : (this.data = EntityHelper.GetComponentInChildren_TubeData(
              this.entity,
              TubeData
            )),
        null != this.data)
      ) {
        (this.sg = EntityHelper.GetComponentInChildren_SortingGroup(
          this.entity,
          SortingGroup
        )),
          this.data.anim.setTrigger("Start_" + this.filledColors);
        for (var e = 0, t = this.colorNames.length; e < t; ) {
          var a = e++;
          a < this.filledColors &&
            ((this.data.waterPortions[a].color = Colors.GetColor(
              this.colorNames[a]
            )),
            (this.data.waterPortionsTilted[a].color = Colors.GetColor(
              this.colorNames[a]
            )));
        }
        this.SetTubeFoamColor(), (this.anim = this.entity.anim);
        var n = GameConfig.get_inst().tubeAnimationSpeed / 100;
        if (((this.data.anim.speed = 1 + n), this.IsGhostTube)) {
          var i = _$Color_Color_$Impl_$.get_WHITE();
          null != this.data.tubeFrontSprite &&
            (((i = this.data.tubeBackSprite.color).a = 0.25),
            (this.data.tubeBackSprite.color = i)),
            null != this.data.tubeBackSprite &&
              (((i = this.data.tubeFrontSprite.color).a = 0.25),
              (this.data.tubeFrontSprite.color = i)),
            null != this.data.addIcon &&
              ((this.data.addIcon.enabled = !0),
              0 ==
                PlayerPrefs.GetInt("first ghost tube to appear in level", 0) &&
                this.ShowTutoBubble());
        }
        GameManager.currLvlNum;
      }
    }
    ShowTutoBubble() {
      (this.data.ghostTubeBubble.enabled = !0),
        PlayerPrefs.SetInt("first ghost tube to appear in level", 1);
      var e = this;
      motion_Actuate.timer(5).onComplete(function () {
        e.data.ghostTubeBubble.enabled = !1;
      });
    }
    SetColorOnIndex(e, t) {
      e > 3 && (e = 3),
        (this.data.waterPortions[e].color = t),
        (this.data.waterPortionsTilted[e].color = t);
    }
    SetColorOnIndexToOnward(e) {
      for (
        var t = this.filledColors - 1,
          a = 0 | (t < 0 ? 0 : t > 3 ? 3 : t),
          n = this.data.waterPortions.length;
        a < n;

      ) {
        var i = a++;
        (this.data.waterPortions[i].color = e),
          (this.data.waterPortionsTilted[i].color = e);
      }
    }
    SetBubbleOnTop() {
      this.partPos = this.data.particleParent.entity.getPosition().clone();
      var e = this.get_LiquidSurfaceY();
      this.partPos.y = e + 0.03;
      var t = this.partPos;
      this.data.particleParent.entity.setPosition(t);
    }
    SetTubeOnMatch2(e) {
      (this.data.tickMark[3].enabled = e),
        e &&
          null != this.data.tickMark[3].anim &&
          this.data.tickMark[3].anim.baseLayer.update(0.01),
        motion_Actuate
          .timer(0.3)
          .onComplete($bind(($_ = MainManager.inst), $_.PlayCorkPop));
    }
    SetTubeOnMatch() {
      (this.data.tickMark[3].enabled = this.get_IsColorsMatched()),
        this.get_IsColorsMatched() &&
          null != this.data.tickMark[3].anim &&
          this.data.tickMark[3].anim.baseLayer.update(0.01),
        motion_Actuate
          .timer(0.3)
          .onComplete($bind(($_ = MainManager.inst), $_.PlayCorkPop));
    }
    WaterReceived() {
      this.sendersList.length < 2 &&
        ((this.tubeStage = TubeStage.Idle), (this.tempReceiving = 0));
    }
    GetCurrFillPoint(e) {
      return this.vec2Vec2Dist(
        e.getPosition().clone(),
        this.data.fillPoints[0].getPosition().clone()
      ) <=
        this.vec2Vec2Dist(
          e.getPosition().clone(),
          this.data.fillPoints[1].getPosition().clone()
        )
        ? this.data.fillPoints[0]
        : this.data.fillPoints[1];
    }
    vec2Vec2Dist(e, t) {
      var a = e.x - t.x,
        n = e.y - t.y;
      return Math.sqrt(a * a + n * n);
    }
    GetCurrTopPoint(e) {
      return (
        this.entity.getLocalScale().clone().x,
        e < 0 ? this.data.topPointRight : this.data.topPointLeft
      );
    }
    GetNearFillPoint(e) {
      return this.vec2Vec2Dist(
        e.getPosition().clone(),
        this.data.fillPoints[0].getPosition().clone()
      ) <=
        this.vec2Vec2Dist(
          e.getPosition().clone(),
          this.data.fillPoints[1].getPosition().clone()
        )
        ? this.data.fillPoints[0]
        : this.data.fillPoints[1];
    }
    GetFlow() {
      return (
        this.flowIndex++,
        this.flowIndex >= this.data.flows.length && (this.flowIndex = 0),
        this.data.flows[this.flowIndex]
      );
    }
    SetTubeFoamColor() {
      if (null != GameManager.inst && this.filledColors > 0) {
        var e = GameManager.inst.ReturnFoamCol(
          this.data.waterPortions[this.filledColors - 1].color
        );
        (this.data.tubeFoam.color = e), (this.data.tubeFoamTilted.color = e);
      }
    }
    LerpFoamColor() {
      if (this.filledColors > 0) {
        var e = GameManager.inst.ReturnFoamCol(
          this.data.waterPortions[this.filledColors - 1].color
        );
        this.data.tweenFoamColor(e, 0.2),
          this.data.tweenFoamTiltedColor(e, 0.2);
      }
    }
    SendingCheckDelayied(e) {
      var t = this,
        a = motion_Actuate.timer(e);
      this.sendingCheckTimers.push(a),
        a.onComplete(function () {
          !t.__destroyed &&
            null != t.entity &&
            t.entity.enabled &&
            (HxOverrides.remove(t.sendingCheckTimers, a), t.SendingCheck());
        });
    }
    SendingCheck() {
      this.isSendingStart ||
        GameManager.inst.isTutorialLvl ||
        (this.CancelSendingInvoke(),
        GameManager.tempFillerTube == this &&
          (GameManager.tempFillerTube = null),
        (this.tubeStage = TubeStage.Idle),
        this.SetTubePos(this.startPos));
    }
    CancelSendingInvoke() {
      for (var e = 0, t = this.sendingCheckTimers.length; e < t; ) {
        var a = e++;
        motion_Actuate.stop(this.sendingCheckTimers[a], null, !1, !1);
      }
      this.sendingCheckTimers = [];
    }
    SetTubePos(e) {
      var t = this.entity,
        a = !0;
      null == a && (a = !0);
      var n = t.getPosition();
      motion_Actuate.update(
        $bind(t, t.setPosition),
        0.15,
        [n.x, n.y, n.z],
        [e.x, e.y, e.z],
        a
      );
    }
    GetColorIndex(e) {
      return e > this.colorNames.length ? 0 : this.colorNames[e - 1];
    }
    SendingWater(e) {
      (this.col = !e), (this.sg.orderInLayer = e ? 2 : 0);
    }
    postUpdate(e) {
      super.postUpdate(e),
        this.waitesInit && ((this.waitesInit = !1), this.init());
    }
    static SwitchOffBlinking() {
      if (!(UIManager.inst.blinkingTubes.length <= 0)) {
        for (var e = 0, t = UIManager.inst.blinkingTubes.length; e < t; ) {
          var a = e++;
          UIManager.inst.blinkingTubes[a].data.blinkAnim.setTrigger("Blink_E"),
            (UIManager.inst.blinkingTubes[a].data.tubeBackSprite.color =
              _$Color_Color_$Impl_$.get_WHITE()),
            (UIManager.inst.blinkingTubes[a].data.blinkArrow.enabled = !1);
        }
        UIManager.inst.blinkingTubes = [];
      }
    }
  }
  (TubeController.__name__ = "TubeController"),
    (TubeController.__super__ = ScriptComponent),
    Object.assign(TubeController.prototype, {
      __class__: TubeController,
      __properties__: Object.assign(
        {},
        ScriptComponent.prototype.__properties__,
        {
          get_LiquidSurfaceY: "get_LiquidSurfaceY",
          get_IsColorsWillMatch: "get_IsColorsWillMatch",
          get_IsColorsMatched: "get_IsColorsMatched",
          get_PortionCanReceive: "get_PortionCanReceive",
          get_PortionCanSend: "get_PortionCanSend",
          set_CurrLiqColor: "set_CurrLiqColor",
          get_CurrLiqColor: "get_CurrLiqColor",
        }
      ),
    });
  class Colors {
    static GetColor(e) {
      var t;
      switch (e) {
        case 0:
          t = "#000000";
          break;
        case 1:
          t = "#FF0000";
          break;
        case 2:
          t = "#0DBB06";
          break;
        case 3:
          t = "#2361FF";
          break;
        case 4:
          t = "#FEFF00";
          break;
        case 5:
          t = "#B614FF";
          break;
        case 6:
          t = "#FF37AB";
          break;
        case 7:
          t = "#FF820D";
          break;
        case 8:
          t = "#AB4927";
          break;
        case 9:
          t = "#6ADE6B";
          break;
        case 10:
          t = "#00C2E0";
          break;
        case 11:
          t = "#39FFCB";
          break;
        case 12:
          t = "#FB98CB";
          break;
        case 13:
          t = "#2101B3";
          break;
        case 14:
          t = "#909090";
          break;
        case 15:
          t = "#FFFFFF";
          break;
        case 16:
          t = "#930014";
          break;
        case 17:
          t = "#6A2DB2";
          break;
        case 18:
          t = "#405863";
          break;
        default:
          haxe_Log.trace("Unknown Color", {
            fileName: "src/TubeController.hx",
            lineNumber: 642,
            className: "Colors",
            methodName: "GetColor",
          }),
            (t = "#000000");
      }
      var a,
        n = null;
      null == n
        ? ((n = [0, 0, 0, 0]), (a = new pc.Color(n)))
        : (a = new pc.Color(n, null, null, null));
      var i = a;
      return (i = i.fromString(t));
    }
  }
  Colors.__name__ = "Colors";
  var TubeStage = ($hxEnums.TubeStage = {
    __ename__: !0,
    __constructs__: ["Idle", "Sending", "Receiving"],
    Idle: { _hx_index: 0, __enum__: "TubeStage", toString: $estr },
    Sending: { _hx_index: 1, __enum__: "TubeStage", toString: $estr },
    Receiving: { _hx_index: 2, __enum__: "TubeStage", toString: $estr },
  });
  TubeStage.__empty_constructs__ = [
    TubeStage.Idle,
    TubeStage.Sending,
    TubeStage.Receiving,
  ];
  class TubeControllerForceSettings extends ScriptComponent {
    constructor(e) {
      super(e), (this.colorNames = null);
    }
    initialize() {
      super.initialize();
      for (
        var e = EntityHelper.GetComponent_TubeController(
            this.entity,
            TubeController
          ),
          t = [],
          a = 0,
          n = this.colorNames.length;
        a < n;

      ) {
        var i = a++;
        t.push(this.colorNames[i]);
      }
      (e.filledColors = this.filledColors),
        (e.colorNames = t),
        (e.haveKey = this.haveKey),
        (e.waitesInit = !0);
    }
  }
  (TubeControllerForceSettings.__name__ = "TubeControllerForceSettings"),
    (TubeControllerForceSettings.__super__ = ScriptComponent),
    Object.assign(TubeControllerForceSettings.prototype, {
      __class__: TubeControllerForceSettings,
    });
  class TubeData extends ScriptComponent {
    constructor(e) {
      super(e),
        (this.currRecPortionNum = 0),
        (this.currPortionNum = 0),
        (this.isPortionSended = !1),
        (this.isTiltRev = !1),
        (this.isTiltEnd = !1),
        (this.isReceiving = !1);
    }
    initialize() {
      super.initialize(),
        (this.anim = this.entity.anim),
        (this.blinkAnim = js_Boot.__cast(
          this.__attributes.BlinkAnim,
          pc.Entity
        ).anim);
      var e = this;
      this.anim.on(
        "SetActive",
        function (t) {
          return e.SetActiveFromAnimEv(t), !0;
        },
        this
      ),
        this.anim.on(
          "portionSent",
          function (t) {
            return e.portionSent(t.number), !0;
          },
          this
        ),
        this.anim.on(
          "receiveEndAt",
          function (t) {
            return e.receiveEndAt(t.number), !0;
          },
          this
        ),
        this.anim.on(
          "tiltReverse",
          function (t) {
            return e.tiltReverse(), !0;
          },
          this
        ),
        this.anim.on(
          "tiltComplete",
          function (t) {
            return e.tiltComplete(), !0;
          },
          this
        ),
        this.anim.on(
          "blastConfetti",
          function (t) {
            return e.blastConfetti(), !0;
          },
          this
        );
      var t = this.__attributes.WaterPortions,
        a = this.__attributes.WaterPortionsTilted;
      if (
        ((this.waterPortions = []), (this.waterPortionsTilted = []), null != t)
      )
        for (var n = 0, i = t.length; n < i; ) {
          var s = n++;
          this.waterPortions.push(t[s].sprite);
        }
      if (null != a)
        for (var r = 0, o = a.length; r < o; ) {
          var l = r++;
          this.waterPortionsTilted.push(a[l].sprite);
        }
      (this.tubeBackSprite = js_Boot.__cast(
        this.__attributes.TubeBackSprite,
        pc.Entity
      ).sprite),
        (this.tubeFrontSprite = js_Boot.__cast(
          this.__attributes.TubeFrontSprite,
          pc.Entity
        ).sprite),
        (this.tubeFoam = js_Boot.__cast(
          this.__attributes.TubeFoam,
          pc.Entity
        ).sprite),
        (this.tubeFoamTilted = js_Boot.__cast(
          this.__attributes.TubeFoamTilted,
          pc.Entity
        ).sprite),
        (this.particleParent = js_Boot.__cast(
          this.__attributes.ParticleParent,
          pc.Entity
        ).sprite);
    }
    SetActiveFromAnimEv(e) {
      var t = this.entity.findByPath("FullMask/" + Std.string(e.string));
      null != t && (t.enabled = 1 == e.number);
    }
    tiltComplete() {
      this.isTiltEnd = !0;
    }
    tiltReverse() {
      this.isTiltRev = !0;
    }
    receiverStart() {
      this.isReceiving = !0;
    }
    receiverEnd() {
      this.isReceiving = !1;
    }
    portionSent(e) {
      (this.currPortionNum = e), (this.isPortionSended = !0);
    }
    receiveEndAt(e) {
      this.currRecPortionNum = e;
    }
    blastConfetti() {
      UIManager.inst.BlastTubeConfetti(this.entity);
    }
    stopTweenFoamColor() {
      motion_Actuate.stop($bind(this, this.updateFoamColor), null, !1, !1);
    }
    tweenFoamColor(e, t) {
      motion_Actuate.stop($bind(this, this.updateFoamColor), null, !1, !1),
        motion_Actuate.update(
          $bind(this, this.updateFoamColor),
          t,
          [this.tubeFoam.color, e, 0],
          [this.tubeFoam.color, e, 1]
        );
    }
    updateFoamColor(e, t, a) {
      var n,
        i = null;
      null == i
        ? ((i = [0, 0, 0, 0]), (n = new pc.Color(i)))
        : (n = new pc.Color(i, null, null, null));
      var s = n;
      (s = s.lerp(e, t, a)), (this.tubeFoam.color = s);
    }
    tweenFoamTiltedColor(e, t) {
      motion_Actuate.stop(
        $bind(this, this.updateFoamTiltedColor),
        null,
        !1,
        !1
      ),
        motion_Actuate.update(
          $bind(this, this.updateFoamTiltedColor),
          t,
          [this.tubeFoamTilted.color, e, 0],
          [this.tubeFoamTilted.color, e, 1]
        );
    }
    updateFoamTiltedColor(e, t, a) {
      var n,
        i = null;
      null == i
        ? ((i = [0, 0, 0, 0]), (n = new pc.Color(i)))
        : (n = new pc.Color(i, null, null, null));
      var s = n;
      (s = s.lerp(e, t, a)), (this.tubeFoamTilted.color = s);
    }
  }
  (TubeData.__name__ = "TubeData"),
    (TubeData.__super__ = ScriptComponent),
    Object.assign(TubeData.prototype, { __class__: TubeData });
  class TutorialManager extends ScriptComponent {
    constructor(e) {
      super(e), (this.vals = null);
    }
    initialize() {
      TutorialManager.tutorialVal = 1;
    }
  }
  (TutorialManager.__name__ = "TutorialManager"),
    (TutorialManager.__super__ = ScriptComponent),
    Object.assign(TutorialManager.prototype, { __class__: TutorialManager });
  class Type {
    static createInstance(e, t) {
      return new (Function.prototype.bind.apply(e, [null].concat(t)))();
    }
  }
  Type.__name__ = "Type";
  class UIHelper {
    static AddButtonClickHandler(e, t) {
      return (
        null != e &&
        null != e.button &&
        (e.button.on("click", function (e) {
          return t(), !0;
        }),
        !0)
      );
    }
    static RemoveAllButtonClickHandlers(e) {
      return null != e && null != e.button && (e.button.off("click"), !0);
    }
    static SetFillAmount(e, t, a) {
      null == a && (a = !0),
        (t = t > 1 ? 1 : t < 0 ? 0 : t),
        Object.prototype.hasOwnProperty.call(e.element, "initSize") ||
          (e.element.initSize = new pc.Vec2(e.element.width, e.element.height));
      var n = Reflect.field(e.element, "initSize");
      if (a) {
        e.element.width = n.x * t;
        var i = e.element.rect.clone();
        (i.z = t), (e.element.rect = i);
      } else {
        e.element.height = n.y * t;
        var s = e.element.rect.clone();
        (s.w = t), (e.element.rect = s);
      }
    }
  }
  UIHelper.__name__ = "UIHelper";
  class UIManager extends ScriptComponent {
    constructor(e) {
      super(e),
        (this.minBuyPrice = 5e5),
        (this.capPanel2 = null),
        (this.capPanel1 = null),
        (this.themePanel2 = null),
        (this.themePanel1 = null),
        (this.tubesPanel2 = null),
        (this.tubesPanel1 = null),
        (this.corkSprite = null),
        (this.bgThemeSprite = null),
        (this.coinChestAmount = 50),
        (this.piggyCoinAmount = 0),
        (this.levelBtnClickBlockFramesLeft = 0),
        (this.lvlBtns = []),
        (this.slpDiv = 250),
        (this.slvlBtns = []),
        (this.showNoMoreTimer = null),
        (this.nmmUndoBtn = null),
        (this.nmmSkipLevelBtnYoutube = null),
        (this.nmmSkipLevelBtn = null),
        (this.blinkingTubes = []),
        (this.availableMoves = []),
        (this.objDisOnChest = null),
        (this.chestboxPrefabB = null),
        (this.immediateStartRequested = !1),
        (this.wpEarnedGems = 0),
        (this.isWonPanelOpened = !1),
        (this.IsOnMainMenu = !0),
        (this.switchBtnsTweens = []),
        (this.curMMButton = null),
        (this.skipItRefused = !1),
        (this.time1Star = 0),
        (this.time2Star = 0),
        (this.time3Star = 0),
        (this.timeLeft = 0),
        (this.elapsedTime = 0),
        (this.totalTime = 0),
        (this.tubesAdded = 0),
        (this.movesOut = 0),
        (this.moves1Star = 0),
        (this.moves2Star = 0),
        (this.moves3Star = 0),
        (this.totalMoves = 0),
        (this.movesUsed = 0),
        (this.lvl_mean_duration = 0),
        (this.lvl_start_time = 0),
        (this.isRewardedAdSeen = !1),
        (this.progressObj = null),
        (this.tubeConfetti = null),
        (this.spinPrefabYoutube = null),
        (this.spinPrefab = null),
        (this.mmButtonsInitPoses = new haxe_ds_ObjectMap());
    }
    initialize() {
      UIManager.inst = this;
      var e = this;
      pc.app.graphicsDevice.on(
        "resizecanvas",
        function () {
          var t = pc.app.root.findByTag("MainCamera");
          return (
            e.setThemeScale(js_Boot.__cast(t[0], pc.Entity).camera.orthoHeight),
            !0
          );
        },
        this
      ),
        UIHelper.AddButtonClickHandler(
          this.mmHomeBtn,
          $bind(this, this.mmHomeClick)
        ),
        UIHelper.AddButtonClickHandler(
          this.mmLevelsBtn,
          $bind(this, this.mmLevelsClick)
        ),
        UIHelper.AddButtonClickHandler(
          this.mmShopBtn,
          $bind(this, this.mmShopClick)
        ),
        this.mmButtonsInitPoses.set(
          this.mmHomeBtn,
          this.mmHomeBtn.getLocalPosition().clone()
        ),
        this.mmButtonsInitPoses.set(
          this.mmLevelsBtn,
          this.mmLevelsBtn.getLocalPosition().clone()
        ),
        this.mmButtonsInitPoses.set(
          this.mmShopBtn,
          this.mmShopBtn.getLocalPosition().clone()
        ),
        (this.tubesPanel1.shopItems = []);
      for (var t = 0, a = this.tubesPanel1.shopItemsEntities.length; t < a; ) {
        var n = t++;
        this.tubesPanel1.shopItems.push(
          EntityHelper.GetComponent_ShopItems(
            this.tubesPanel1.shopItemsEntities[n],
            ShopItems
          )
        );
      }
      this.tubesPanel2.shopItems = [];
      for (var i = 0, s = this.tubesPanel2.shopItemsEntities.length; i < s; ) {
        var r = i++;
        this.tubesPanel2.shopItems.push(
          EntityHelper.GetComponent_ShopItems(
            this.tubesPanel2.shopItemsEntities[r],
            ShopItems
          )
        );
      }
      this.themePanel1.shopItems = [];
      for (var o = 0, l = this.themePanel1.shopItemsEntities.length; o < l; ) {
        var u = o++;
        this.themePanel1.shopItems.push(
          EntityHelper.GetComponent_ShopItems(
            this.themePanel1.shopItemsEntities[u],
            ShopItems
          )
        );
      }
      this.themePanel2.shopItems = [];
      for (var c = 0, h = this.themePanel2.shopItemsEntities.length; c < h; ) {
        var p = c++;
        this.themePanel2.shopItems.push(
          EntityHelper.GetComponent_ShopItems(
            this.themePanel2.shopItemsEntities[p],
            ShopItems
          )
        );
      }
      this.capPanel1.shopItems = [];
      for (var m = 0, _ = this.capPanel1.shopItemsEntities.length; m < _; ) {
        var d = m++;
        this.capPanel1.shopItems.push(
          EntityHelper.GetComponent_ShopItems(
            this.capPanel1.shopItemsEntities[d],
            ShopItems
          )
        );
      }
      this.capPanel2.shopItems = [];
      for (var g = 0, y = this.capPanel2.shopItemsEntities.length; g < y; ) {
        var v = g++;
        this.capPanel2.shopItems.push(
          EntityHelper.GetComponent_ShopItems(
            this.capPanel2.shopItemsEntities[v],
            ShopItems
          )
        );
      }
    }
    postInitialize() {
      super.postInitialize(), this.InitGame();
    }
    InitGame() {
      this.SetXtraTubeCount(),
        this.SetUndoCount(),
        this.SetHintCount(),
        PlayerPrefs.GetBool("IsTutorialPlayed", !1)
          ? ((GameManager.inst.isTutorialLvl = !PlayerPrefs.GetBool(
              "IsTutorialPlayed",
              !1
            )),
            this.UI_Main_PlayBtn(!0))
          : GameManager.inst.InstantiateNewLevel(function (e) {}),
        this.OfflineRewardCheck(),
        this.SpinWheelCheck(),
        this.SetBgTheme(),
        this.CountTotalStars(),
        this.UpdateCurrency(),
        this.SetSettingsPanel(),
        this.TubesPanel1Check(),
        this.TubesPanel2Check(),
        this.ThemesPanel1Check(),
        this.ThemesPanel2Check(),
        this.CapsPanel1Check(),
        this.CapsPanel2Check(),
        this.SetCoinChestBar();
    }
    mmHomeClick() {
      this.switchMMBtn(this.mmHomeBtn);
    }
    mmLevelsClick() {
      this.switchMMBtn(this.mmLevelsBtn);
    }
    mmShopClick() {
      this.switchMMBtn(this.mmShopBtn);
    }
    switchMMBtn(e, t) {
      if ((null == t && (t = !1), this.curMMButton != e)) {
        var a = 0,
          n = 100,
          i = 0;
        null == i && (i = 0), null == n && (n = 0), null == a && (a = 0);
        for (var s = new pc.Vec3(a, n, i); this.switchBtnsTweens.length > 0; )
          motion_Actuate.stop(this.switchBtnsTweens.pop(), null, !0, !0);
        if (t) {
          for (var r = this.mmButtonsInitPoses.keys(); r.hasNext(); ) {
            var o = r.next(),
              l = this.mmButtonsInitPoses.h[o.__id__];
            if ((o.setLocalPosition(l), o == e)) {
              var u = o,
                c = u.getLocalPosition().clone(),
                h = new pc.Vec3(c.x + s.x, c.y + s.y, c.z + s.z);
              u.setLocalPosition(h);
            }
            (o.button.active = o != e), (o.element.useInput = o != e);
          }
          this.curMMButton = e;
        } else {
          for (var p = this.mmButtonsInitPoses.keys(); p.hasNext(); ) {
            var m = [p.next()];
            if (m[0] == this.curMMButton) {
              (m[0].button.active = !0), (m[0].element.useInput = !0);
              var _ = this.switchBtnsTweens,
                d = this.mmButtonsInitPoses.h[m[0].__id__],
                g = m[0].getLocalPosition();
              _.push(
                motion_Actuate
                  .update(
                    (($_ = m[0]), $bind($_, $_.setLocalPosition)),
                    0.25,
                    [g.x, g.y, g.z],
                    [d.x, d.y, d.z],
                    !0
                  )
                  .ease(motion_easing_Linear.get_easeNone())
              );
            }
            if (m[0] == e) {
              (m[0].button.active = !0), (m[0].element.useInput = !1);
              var y = this.switchBtnsTweens,
                v = this.mmButtonsInitPoses.h[m[0].__id__],
                b = new pc.Vec3(v.x + s.x, v.y + s.y, v.z + s.z),
                f = m[0].getLocalPosition();
              y.push(
                motion_Actuate
                  .update(
                    (($_ = m[0]), $bind($_, $_.setLocalPosition)),
                    0.25,
                    [f.x, f.y, f.z],
                    [b.x, b.y, b.z],
                    !0
                  )
                  .ease(motion_easing_Linear.get_easeNone())
                  .onComplete(
                    (function (e) {
                      return function () {
                        e[0].button.active = !1;
                      };
                    })(m)
                  )
              );
              var S = m[0].findByName("Icon");
              if (null != S) {
                var P = S.getLocalScale().clone(),
                  M = this.switchBtnsTweens,
                  C = _$Vector3_Vector3_$Impl_$.mulN(P, 0.88),
                  I = S.getLocalScale();
                M.push(
                  motion_Actuate
                    .update(
                      $bind(S, S.setLocalScale),
                      0.15,
                      [I.x, I.y, I.z],
                      [C.x, C.y, C.z],
                      !0
                    )
                    .ease(motion_easing_Quad.easeInOut)
                    .reflect()
                    .repeat(1)
                );
              }
            }
          }
          (this.curMMButton = e),
            e == this.mmHomeBtn
              ? ((this.mmMainMenu.enabled = !0),
                (this.mmLevelsCont.enabled = !1),
                (this.shopPanelB.enabled = !1),
                this.IsGoingToMainMenu(!0),
                this.OnShopClose())
              : e == this.mmLevelsBtn
              ? ((this.mmMainMenu.enabled = !1),
                (this.mmLevelsCont.enabled = !0),
                (this.shopPanelB.enabled = !1),
                this.UI_LGP_GroupToSubLvl(1),
                this.IsGoingToMainMenu(!1),
                this.OnShopClose())
              : ((this.mmMainMenu.enabled = !1),
                (this.mmLevelsCont.enabled = !1),
                (this.shopPanelB.enabled = !0),
                this.IsGoingToMainMenu(!1),
                this.OnShopOpen());
        }
      }
    }
    IsGoingToMainMenu(e) {
      this.IsOnMainMenu = e;
    }
    SetStarBarAndText() {
      IngameMenu.inst.SetStarBarAndText();
    }
    KeyPicked(e) {
      null != e &&
        (MainManager.inst.PlayOneShot("KeyCollect"),
        PlayerPrefs.SetBool(
          "Mode_" +
            GameManager.currModeNum +
            "_Lvl_" +
            (GameManager.currLvlNum + 1) +
            "_KeyPicked",
          !0
        ),
        PlayerPrefs.SetInt(
          "PickedKeys",
          PlayerPrefs.GetInt("PickedKeys", 0) + 1
        ),
        (e.findByPath("HealStream3").enabled = !1),
        this.AnimatePickedKey(e));
    }
    AnimatePickedKey(e) {
      if (null != e) {
        var t = PlayerPrefs.GetInt("PickedKeys", 0),
          a = 0 | (t < 0 ? 0 : t > 3 ? 3 : t),
          n = UIManager.inst.entity,
          i = !0;
        if (
          (null == i && (i = !0),
          null == n && (n = pc.app.scene.root),
          null != e.parent)
        )
          if (i) {
            var s = e.getWorldTransform().clone(),
              r = n.getWorldTransform().clone().invert();
            s.mul2(r, s);
            var o = s.getTranslation(),
              l = new pc.Quat().setFromMat4(s),
              u = s.getScale();
            e.reparent(n),
              e.setLocalPosition(o),
              e.setLocalRotation(l),
              e.setLocalScale(u);
          } else e.reparent(n);
        var c = IngameMenu.inst.keys[a - 1],
          h =
            c.element.screenCorners[0].x +
            (c.element.screenCorners[1].x - c.element.screenCorners[0].x) / 2,
          p =
            pc.app.graphicsDevice.height -
            (c.element.screenCorners[0].y +
              (c.element.screenCorners[2].y - c.element.screenCorners[0].y) /
                2);
        null == p && (p = 0), null == h && (h = 0);
        var m = new pc.Vec3(h, p, 0),
          _ = js_Boot
            .__cast(pc.app.root.findByTag("MainCamera")[0], pc.Entity)
            .camera.screenToWorld(m.x, m.y, m.z);
        IngameMenu.inst.activateKeyPanel();
        var d = e.getPosition();
        motion_Actuate
          .update(
            $bind(e, e.setPosition),
            0.5,
            [d.x, d.y, d.z],
            [_.x, _.y, _.z],
            !0
          )
          .ease(motion_easing_Linear.get_easeNone())
          .onComplete(function () {
            IngameMenu.inst.activateKeyAndHide(a),
              e.destroy(),
              MainManager.inst.PlayOneShot("StarCollect");
          });
      }
    }
    GameLose(e) {
      null == e && (e = !1);
      var t = this;
      (UIManager.isGameplaying || e) &&
        ((UIManager.isGameplaying = !1),
        e
          ? (MainManager.inst.PlayOneShot("GameLose"),
            this.GamePlayPanelOnOff(!1, 0, 0.1),
            (this.losePanel.enabled = !0),
            GameLoseScreen.Activate())
          : APIManager.GameInterface.gameOver().then(function () {
              t.GameLose(!0);
            }));
    }
    GameWon(e, t) {
      null == t && (t = !1),
        null == e && (e = !1),
        (UIManager.isGameplaying = !1);
      var a = this;
      if (t) {
        this.EarnedStars();
        GameConfig.get_inst().useImmediateTransition || this.BlackP_FadeIn(),
          (this.nmmPanel.enabled = !1);
        var n = pc.app.root.findByName("InstructionText");
        if ((null != n && (n.enabled = !1), GameManager.inst.isTutorialLvl))
          (MainManager.inst.confetti.enabled = !0),
            MainManager.inst.PlayOneShot("Confetti"),
            (this.tutorialAnim.enabled = !1),
            PlayerPrefs.SetBool("IsTutorialPlayed", !0),
            MainManager.inst.LoadLevel(!1);
        else {
          (this.isWonPanelOpened = !0),
            PlayerPrefs.SetInt(
              "LevelComplete",
              PlayerPrefs.GetInt("LevelComplete", 1) + 1
            );
          var i = !0;
          if (
            (APIManager.HasFeature("rewarded") || (i = !1),
            GameManager.currLvlNum > 0 && i)
          ) {
            var s = !e && APIManager.IsRewardedAdReady();
            (LevelCompleteScreen.inst.getx_rewardBtn.button.active = s),
              (LevelCompleteScreen.inst.getx_rewardBtn.enabled = !e),
              (LevelCompleteScreen.inst.claimBtn.enabled = !1),
              this.ShowNextBtn(!0);
          } else
            (LevelCompleteScreen.inst.getx_rewardBtn.button.active = !1),
              (LevelCompleteScreen.inst.getx_rewardBtn.enabled = !1),
              (LevelCompleteScreen.inst.claimBtn.button.active = !0),
              (LevelCompleteScreen.inst.claimBtn.enabled = !0),
              this.ShowNextBtn(!1);
          this.GamePlayPanelOnOff(!1, 0, 0.1),
            MainManager.inst.PlayOneShot("GameWon"),
            e ? this.GameWon2(e) : this.AfterWonInter(e);
        }
      } else
        APIManager.GameInterface.gameComplete().then(function () {
          a.GameWon(e, !0);
        });
    }
    ShowNextBtn(e) {
      for (
        var t =
            LevelCompleteScreen.inst.getx_rewardBtn.findComponents("element"),
          a = 0;
        a < t.length;

      ) {
        var n = t[a];
        ++a,
          n.type == pc.ELEMENTTYPE_IMAGE && (n.opacity = e ? 1 : 0),
          n.type == pc.ELEMENTTYPE_TEXT && (n.opacity = e ? 1 : 0);
      }
    }
    GameWon2(e) {
      null == e && (e = !1);
      var t = this;
      motion_Actuate.timer(0.7).onComplete(function () {
        t.GameWon2_1(e);
      });
    }
    GameWon2_1(e) {
      null == e && (e = !1);
      var t = this.EarnedStars(),
        a = PlayerPrefs.GetInt("CurrLvlNum", 1),
        n = 0,
        i = this;
      PlayerPrefs.HasKey(
        "Mode_" + GameManager.currModeNum + "_Lvl_" + a + "_Stars"
      ) &&
        (n = PlayerPrefs.GetInt(
          "Mode_" + GameManager.currModeNum + "_Lvl_" + a + "_Stars",
          0
        ));
      var s = 0;
      LevelCompleteScreen.inst.set_curProgressBarFillAmount(
        PlayerPrefs.GetFloat("ProgressVal", 0)
      );
      var r = Math.round(100 * PlayerPrefs.GetFloat("ProgressVal", 0));
      LevelCompleteScreen.inst.progressText.element.text =
        (r < 0 ? 0 : r > 100 ? 100 : r) + "%";
      var o = 0;
      n < t
        ? (PlayerPrefs.SetInt(
            "Mode_" + GameManager.currModeNum + "_Lvl_" + a + "_Stars",
            t
          ),
          e || (s = t - n),
          0 != PlayerPrefs.GetInt("Lvl1Played", 0) ||
            (2 != PlayerPrefs.GetInt("GemScaler", 1) &&
              3 != PlayerPrefs.GetInt("GemScaler", 1)) ||
            PlayerPrefs.SetInt("Lvl1Played", 1),
          e
            ? ((LevelCompleteScreen.inst.rewardScale.enabled = !1),
              (LevelCompleteScreen.inst.getx_rewardBtn.button.active = !1),
              (LevelCompleteScreen.inst.getx_rewardBtnCoinsTF.element.text =
                "0"))
            : ((LevelCompleteScreen.inst.rewardScale.anim.enabled = !0),
              (LevelCompleteScreen.inst.rewardScale.enabled = !0),
              (LevelCompleteScreen.inst.getx_rewardBtn.button.active = !0)))
        : ((LevelCompleteScreen.inst.rewardScale.enabled = !1),
          (LevelCompleteScreen.inst.getx_rewardBtn.button.active = !1),
          (LevelCompleteScreen.inst.getx_rewardBtnCoinsTF.element.text = "0")),
        PlayerPrefs.SetInt(
          "CoinChestStars",
          PlayerPrefs.GetInt("CoinChestStars", 0) + s
        ),
        this.SetCoinChestBar(),
        (this.wpEarnedGems = 50 * s),
        APIManager.HasFeature("rewarded") ||
          (this.wpEarnedGems = (this.wpEarnedGems / 2) | 0);
      var l = [];
      (LevelCompleteScreen.inst.missBtnCoinsTF.element.text =
        "" + this.wpEarnedGems),
        (LevelCompleteScreen.inst.claimBtnCoinsTF.element.text =
          "" + this.wpEarnedGems);
      for (
        var u = 0, c = LevelCompleteScreen.inst.wpEarnedStarsB.length;
        u < c;

      ) {
        var h = u++,
          p = LevelCompleteScreen.inst.wpEarnedStarsB[h],
          m = _$Vector3_Vector3_$Impl_$.get_ZERO();
        p.setLocalScale(m),
          h < t && l.push(LevelCompleteScreen.inst.wpEarnedStarsB[h]);
      }
      GameConfig.get_inst().useImmediateTransition
        ? this.immediateTransition()
        : LevelCompleteScreen.Activate(),
        motion_Actuate.timer(0.5).onComplete(function () {
          for (var n = 0, s = l.length; n < s; ) {
            var r = n++,
              u = l[r],
              c = _$Vector3_Vector3_$Impl_$.get_ONE(),
              h = u.getLocalScale();
            motion_Actuate
              .update(
                $bind(u, u.setLocalScale),
                0.2,
                [h.x, h.y, h.z],
                [c.x, c.y, c.z],
                !0
              )
              .delay(0.2 * r)
              .ease(motion_easing_Linear.get_easeNone())
              .onComplete(function () {
                MainManager.inst.PlayOneShot("StarCollect");
              });
          }
          var p = PlayerPrefs.GetInt(
            "Mode_" + GameManager.currModeNum + "_LvlUnlocked",
            1
          );
          a == p &&
            (a <=
              GameManager.inst.modes[GameManager.currModeNum - 1].totalLvls &&
              (PlayerPrefs.SetInt(
                "Mode_" + GameManager.currModeNum + "_LvlUnlocked",
                p + 1
              ),
              GameConfig.get_inst().progressionPopup ||
                ((o =
                  PlayerPrefs.GetFloat("ProgressVal", 0) +
                  PlayerPrefs.GetFloat("ProgValue", 0.2)),
                e || PlayerPrefs.SetFloat("ProgressVal", o))),
            p >=
              GameManager.inst.modes[PlayerPrefs.GetInt("CurrModeNum", 1) - 1]
                .totalLvls &&
              0 ==
                PlayerPrefs.GetInt(
                  "Mode_" + PlayerPrefs.GetInt("CurrModeNum", 1) + "_Completed",
                  0
                ) &&
              PlayerPrefs.SetInt(
                "Mode_" + PlayerPrefs.GetInt("CurrModeNum", 1) + "_Completed",
                1
              ));
          var m = LevelCompleteScreen.inst.get_curProgressBarFillAmount();
          m < o &&
          !GameConfig.get_inst().progressionPopup &&
          !GameConfig.get_inst().useImmediateTransition
            ? motion_Actuate
                .update(
                  function (e) {
                    LevelCompleteScreen.inst.set_curProgressBarFillAmount(e),
                      (LevelCompleteScreen.inst.progressText.element.text =
                        Math.round(100 * (e > 1 ? 1 : e < 0 ? 0 : e)) + "%");
                  },
                  1,
                  [m],
                  [o]
                )
                .delay(1)
                .ease(motion_easing_Quad.easeOut)
                .onComplete(function () {
                  i.GameWon3(o, t);
                })
            : i.GameWon3(o, t);
        });
    }
    GameWon3(e, t) {
      this.CountTotalStars(),
        (this.isRewardedAdSeen = !1),
        0 == PlayerPrefs.GetInt("Lvl1Played", 0) &&
        2 == PlayerPrefs.GetInt("GemScaler", 1)
          ? (PlayerPrefs.SetInt("Lvl1Played", 1),
            (LevelCompleteScreen.inst.missBtn.enabled = !1))
          : GameManager.currLvlNum > 0
          ? ((LevelCompleteScreen.inst.missBtn.button.active = !0),
            (LevelCompleteScreen.inst.missBtn.enabled =
              APIManager.HasFeature("rewarded")))
          : ((LevelCompleteScreen.inst.missBtn.button.active = !1),
            (LevelCompleteScreen.inst.missBtn.enabled = !1));
    }
    immediateTransition() {
      LevelCompleteScreen.Activate();
      var e = this;
      motion_Actuate.timer(5).onComplete(function () {
        e.immediateStartRequested || e.ImmediateStartNextLevel(),
          (e.immediateStartRequested = !1);
      });
    }
    famobiRestartRequest() {
      UIManager.isGameplaying &&
        ((this.losePanel.enabled = !1),
        (this.pausedPanel.enabled = !1),
        motion_Actuate.stop(this.showNoMoreTimer, null, !1, !1),
        MainManager.inst.LoadLevel(!1),
        LevelCompleteScreen.Deactivate());
    }
    ImmediateStartNextLevel() {
      LevelCompleteScreen.Deactivate();
      var e = PlayerPrefs.GetInt(
        "Mode_" + PlayerPrefs.GetInt("CurrModeNum", 1) + "_LvlUnlocked",
        1
      );
      PlayerPrefs.SetInt("CurrLvlNum", e),
        (this.isWonPanelOpened = !1),
        MainManager.inst.LoadLevel(!1);
    }
    ImmediateStartNextLevelRequest() {
      (this.immediateStartRequested = !0), this.ImmediateStartNextLevel();
    }
    CountTotalStars() {
      UIManager.totalStars = 0;
      for (var e = 0, t = GameManager.inst.modes.length; e < t; ) {
        var a = e++;
        GameManager.inst.modes[a].achievedStars = 0;
        for (
          var n = 0,
            i = PlayerPrefs.GetInt("Mode_" + (a + 1) + "_LvlUnlocked", 1) - 1;
          n < i;

        ) {
          var s = n++;
          (UIManager.totalStars += PlayerPrefs.GetInt(
            "Mode_" + (a + 1) + "_Lvl_" + (s + 1) + "_Stars",
            0
          )),
            (GameManager.inst.modes[a].achievedStars += PlayerPrefs.GetInt(
              "Mode_" + (a + 1) + "_Lvl_" + (s + 1) + "_Stars",
              0
            ));
        }
      }
      this.UpdateCurrency();
    }
    UpdateCurrency() {
      for (
        var e = 0 | PlayerPrefs.GetFloat("Currency_1"),
          t = 0,
          a = this.mainCoinTexts;
        t < a.length;

      ) {
        var n = a[t];
        ++t, (n.element.text = "" + e);
      }
      null != GiftBoxSystem.inst &&
        (GiftBoxSystem.inst.coinsText.element.text = "" + e),
        this.TubesPanel1Check(),
        this.TubesPanel2Check(),
        this.CapsPanel1Check(),
        this.CapsPanel2Check(),
        this.ThemesPanel1Check(),
        this.ThemesPanel2Check();
    }
    OnCurrencyAdded(e, t, a, n) {}
    AfterWonInter(e) {
      null == e && (e = !1);
      var t = this;
      if (null != APIManager.inst) {
        if (
          (null != GameManager.inst &&
            GameManager.inst.lvlPreset.skipWinInterstitial) ||
          (GameConfig.get_inst().useImmediateTransition &&
            GameManager.currLvlNum % 2 == 0 &&
            0 != GameManager.currLvlNum)
        )
          return (
            (MainManager.inst.confetti.enabled = !0),
            MainManager.inst.PlayOneShot("Confetti"),
            void this.GameWon2(e)
          );
        APIManager.ShowInterstitial(function (a) {
          (MainManager.inst.confetti.enabled = !0),
            MainManager.inst.PlayOneShot("Confetti"),
            t.GameWon2(e);
        }, "level_complete");
      }
    }
    SetEarnedCoin_WP(e) {
      LevelCompleteScreen.inst.getx_rewardBtnCoinsTF.element.text =
        LevelCompleteScreen.inst.claimBtnCoinsTF.element.text =
          "" + this.wpEarnedGems * e;
    }
    UI_Main_PlayBtn(e) {
      if (
        (null == e && (e = !1),
        !GameManager.inst.isTutorialLvl && !UIManager.isGameplaying)
      ) {
        (UIManager.lastBtnPressed = "PlayBtn"),
          e || MainManager.inst.PlayOneShot("BtnClick");
        var t = PlayerPrefs.GetInt(
          "Mode_" + PlayerPrefs.GetInt("CurrModeNum", 1) + "_LvlUnlocked",
          1
        );
        PlayerPrefs.SetInt("CurrLvlNum", t),
          MainManager.inst.LoadLevel(!0),
          (this.mainPanel.enabled = !1);
      }
    }
    UI_Won_ClaimXRewardBtn() {
      MainManager.inst.PlayOneShot("BtnClick"),
        (LevelCompleteScreen.inst.getx_rewardBtn.button.active = !1),
        (LevelCompleteScreen.inst.rewardScale.anim.enabled = !1),
        (LevelCompleteScreen.inst.missBtn.button.active = !1),
        (LevelCompleteScreen.inst.claimBtn.button.active = !1);
      var e = this;
      null != APIManager.inst && APIManager.IsRewardedAdReady()
        ? APIManager.ShowRewardedAD(function (t) {
            t
              ? motion_Actuate.timer(0.1).onComplete($bind(e, e.Give_X_Reward))
              : ((LevelCompleteScreen.inst.getx_rewardBtn.button.active = !0),
                (LevelCompleteScreen.inst.rewardScale.anim.enabled = !0),
                (LevelCompleteScreen.inst.missBtn.button.active = !0),
                (LevelCompleteScreen.inst.claimBtn.button.active = !0));
          }, LevelCompleteScreen.rwGetScaledRewardPlacement)
        : ((LevelCompleteScreen.inst.getx_rewardBtn.button.active = !0),
          (LevelCompleteScreen.inst.rewardScale.anim.enabled = !0),
          (LevelCompleteScreen.inst.missBtn.button.active = !0),
          (LevelCompleteScreen.inst.claimBtn.button.active = !0));
    }
    Give_X_Reward() {
      (this.wpEarnedGems *= RewardScale.xRewardVal),
        this.SetEarnedCoin_WP(1),
        (LevelCompleteScreen.inst.missBtn.enabled = !1),
        this.UI_Won_MissBtn();
    }
    UI_Won_MissBtn() {
      MainManager.inst.PlayOneShot("BtnClick"),
        (LevelCompleteScreen.inst.missBtn.button.active = !1),
        (LevelCompleteScreen.inst.getx_rewardBtn.button.active = !1),
        (LevelCompleteScreen.inst.claimBtn.button.active = !1);
      var e = !0;
      APIManager.HasFeature("rewarded") || (e = !1);
      var t = 1;
      (PlayerPrefs.GetInt("CurrLvlNum", 1) - 1 != 0 && e) ||
        ((LevelCompleteScreen.inst.rewardScale.anim.enabled = !1),
        (t = RewardScale.xRewardVal)),
        this.isRewardedAdSeen
          ? ((LevelCompleteScreen.inst.wpXrewardGcB.totalCoinsToAdd =
              this.wpEarnedGems * t),
            (LevelCompleteScreen.inst.wpXrewardGcB.callToMain = !0),
            (LevelCompleteScreen.inst.wpXrewardGcB.entity.enabled = !0))
          : ((LevelCompleteScreen.inst.wpNextGcB.totalCoinsToAdd =
              this.wpEarnedGems * t),
            (LevelCompleteScreen.inst.wpNextGcB.callToMain = !0),
            (LevelCompleteScreen.inst.wpNextGcB.entity.enabled = !0));
    }
    CoinSended() {
      if (
        PlayerPrefs.GetFloat("ProgressVal", 0) >= 0.98999999 &&
        this.ProgressTubeAvail() &&
        !GameConfig.get_inst().progressionPopup
      )
        LevelCompleteScreen.Deactivate(),
          (this.isWonPanelOpened = !1),
          this.OpenProgressPanel();
      else if (PlayerPrefs.GetInt("PickedKeys", 0) >= 3)
        LevelCompleteScreen.Deactivate(),
          (this.isWonPanelOpened = !1),
          this.OpenChestPanel();
      else {
        var e = PlayerPrefs.GetInt(
          "Mode_" + PlayerPrefs.GetInt("CurrModeNum", 1) + "_LvlUnlocked",
          1
        );
        PlayerPrefs.SetInt("CurrLvlNum", e),
          MainManager.inst.LoadLevel(!1),
          LevelCompleteScreen.Deactivate(),
          (this.isWonPanelOpened = !1);
      }
    }
    OpenChestPanel() {
      var e = this;
      this.FadeInOutPanel(function (t) {
        var a = EntityHelper.InstantiatePrefab(e.chestboxPrefabB, pc.app.root);
        (js_Boot.__cast(
          a.findComponent("screen"),
          pc.ScreenComponent
        ).scaleBlend = 1),
          (js_Boot.__cast(
            a.findComponent("screen"),
            pc.ScreenComponent
          ).priority = 100),
          e.ShowChestPanel(!0);
      });
    }
    CloseChestPanel() {
      this.ShowChestPanel(!1);
      var e = PlayerPrefs.GetInt(
        "Mode_" + PlayerPrefs.GetInt("CurrModeNum", 1) + "_LvlUnlocked",
        1
      );
      PlayerPrefs.SetInt("CurrLvlNum", e), MainManager.inst.LoadLevel(!1);
    }
    ShowChestPanel(e) {
      for (var t = 0, a = this.objDisOnChest.length; t < a; ) {
        var n = t++;
        this.objDisOnChest[n].enabled = !e;
      }
      if (!e) {
        var i = this.faderImage.element.color.clone();
        (i.a = 0),
          (this.faderImage.element.color = i),
          (this.faderImage.element.useInput = !1);
      }
    }
    OnCloseProgressPanel() {
      haxe_Log.trace("!!! OnCloseProgressPanel", {
        fileName: "src/UIManager.hx",
        lineNumber: 980,
        className: "UIManager",
        methodName: "OnCloseProgressPanel",
      });
      for (var e = 0, t = this.objDisOnChest.length; e < t; ) {
        var a = e++;
        this.objDisOnChest[a].enabled = !0;
      }
      if (PlayerPrefs.GetInt("PickedKeys", 0) >= 3)
        LevelCompleteScreen.Deactivate(),
          (this.isWonPanelOpened = !1),
          this.OpenChestPanel();
      else {
        var n = PlayerPrefs.GetInt(
          "Mode_" + PlayerPrefs.GetInt("CurrModeNum", 1) + "_LvlUnlocked",
          1
        );
        haxe_Log.trace("!!! OnCloseProgressPanel lvlUnlockedNum: " + n, {
          fileName: "src/UIManager.hx",
          lineNumber: 995,
          className: "UIManager",
          methodName: "OnCloseProgressPanel",
        }),
          PlayerPrefs.SetInt("CurrLvlNum", n),
          MainManager.inst.LoadLevel(!1);
      }
    }
    ProgressTubeAvail() {
      for (var e = !1, t = 19; t < 28; ) {
        var a = t++;
        if (PlayerPrefs.GetBool("Tube" + a, !0)) {
          e = !0;
          break;
        }
      }
      return e;
    }
    OpenProgressPanel() {
      var e = this;
      this.FadeInOutPanel(function (t) {
        if (t) {
          PlayerPrefs.SetFloat("ProgValue", 0.1),
            PlayerPrefs.SetFloat("ProgressVal", 0);
          var a = EntityHelper.InstantiatePrefab(e.progressObj, pc.app.root);
          (js_Boot.__cast(
            a.findComponent("screen"),
            pc.ScreenComponent
          ).scaleBlend = 1),
            (js_Boot.__cast(
              a.findComponent("screen"),
              pc.ScreenComponent
            ).priority = 100),
            e.ShowChestPanel(!0),
            (LevelCompleteScreen.inst.progressText.element.text = "100%"),
            LevelCompleteScreen.inst.set_curProgressBarFillAmount(1);
        }
      });
    }
    AddCurrency(e, t) {
      null == t && (t = "Currency_1"),
        PlayerPrefs.SetFloat(t, PlayerPrefs.GetFloat(t) + e),
        this.UpdateCurrency(),
        "Currency_1" == t && this.CanBuyShopItem();
    }
    SetGameplayPanel() {
      switch (
        (this.BlackP_FadeOut(),
        (MainManager.inst.confetti.enabled = !1),
        (this.tubesAdded = 0),
        (this.movesUsed = 0),
        (this.elapsedTime = 0),
        GameManager.currMode)
      ) {
        case 0:
          (this.totalMoves = LevelManager.inst.minMoveToSort),
            (this.moves3Star = 0 | this.totalMoves),
            (this.totalMoves += LevelManager.inst.minMoveToSort),
            (this.moves2Star = 0 | this.totalMoves),
            (this.totalMoves += LevelManager.inst.minMoveToSort),
            (this.moves1Star = 0 | this.totalMoves),
            (this.totalMoves += LevelManager.inst.minMoveToSort);
          break;
        case 1:
          (this.totalTime = LevelManager.inst.minTimeToSort),
            (this.time3Star = 0 | this.totalTime),
            (this.totalTime += LevelManager.inst.minTimeToSort),
            (this.time2Star = 0 | this.totalTime),
            (this.totalTime += LevelManager.inst.minTimeToSort),
            (this.time1Star = 0 | this.totalTime),
            (this.totalTime += LevelManager.inst.minTimeToSort);
          break;
        case 2:
          this.totalMoves = LevelManager.inst.minMoveToSort;
      }
      if (
        (IngameMenu.OnLevelStarted(),
        (LevelCompleteScreen.inst.modeText.element.text =
          this.lpModeText.element.text =
          IngameMenu.inst.levelNumTxt.element.text =
            "LEVEL: " + (GameManager.currLvlNum + 1)),
        this.SetXtraTubeCount(),
        this.SetUndoCount(),
        this.SetSkipLvlCount(),
        this.SetHintCount(),
        this.SetStarBarAndText(),
        (this.nmmPanel.enabled = !1),
        GameManager.currLvlNum + 1 == 5 &&
          0 == GameManager.currMode &&
          0 == PlayerPrefs.GetInt("XtraPowerShown", 0))
      ) {
        PlayerPrefs.SetInt("XtraPowerShown", 1);
        var e = GameManager;
        e.set_EmptyTubesCount(e.get_EmptyTubesCount() + 1);
        var t = GameManager.get_EmptyTubesCount();
        (this.newGpPowerXtraCount.element.text = "" + t),
          (this.newGpPowerTutPanel.enabled = !0);
      }
    }
    GamePlayPanelOnOff(e, t, a) {
      1 == t &&
        GameManager.currLvlNum + 1 > 2 &&
        (this.lvl_start_time = new Date().getTime()),
        (IngameMenu.inst.entity.element.useInput = e),
        (IngameMenu.inst.entity.enabled = 1 == t);
    }
    GetHintMove(e) {
      if (
        UIManager.isGameplaying &&
        !(this.blinkingTubes.length > 0) &&
        !(e && GameManager.get_HintCounts() < 1)
      ) {
        this.availableMoves = [];
        for (var t = 0, a = LevelManager.tubes.length; t < a; )
          for (var n = t++, i = 0, s = LevelManager.tubes.length; i < s; ) {
            var r = i++;
            if (
              n != r &&
              LevelManager.tubes[r].filledColors < 4 &&
              LevelManager.tubes[n].get_PortionCanSend() <=
                LevelManager.tubes[r].get_PortionCanReceive() &&
              !LevelManager.tubes[n].get_IsColorsMatched() &&
              LevelManager.tubes[n].filledColors > 0 &&
              !this.CheckSingleColorToEmpty(
                LevelManager.tubes[n],
                LevelManager.tubes[r]
              ) &&
              !this.CheckSingleToManyColor(
                LevelManager.tubes[n],
                LevelManager.tubes[r]
              ) &&
              (_$Color_Color_$Impl_$.equals(
                LevelManager.tubes[n].get_CurrLiqColor(),
                LevelManager.tubes[r].get_CurrLiqColor()
              ) ||
                0 == LevelManager.tubes[r].filledColors)
            ) {
              var o = {
                source: LevelManager.tubes[n],
                destination: LevelManager.tubes[r],
              };
              this.availableMoves.push(o);
            }
          }
        if (this.availableMoves.length > 0)
          if (e) {
            var l;
            this.availableMoves.length > 1
              ? -1 == (l = this.SingleToSingleColReturn()) &&
                -1 == (l = this.ManyToSingleColReturn()) &&
                -1 == (l = this.MoreColToEmpty()) &&
                (l = Math.floor(this.availableMoves.length * Math.random()))
              : (l = 0);
            var u = GameManager;
            u.set_HintCounts(u.get_HintCounts() - 1),
              (IngameMenu.inst.hintBtn.element.useInput = !1),
              this.availableMoves[l].source.data.blinkAnim.setTrigger(
                "Blink_S"
              );
            var c,
              h = 1;
            null == h
              ? ((h = [0, 0, 0, 0]), (c = new pc.Color(h)))
              : (c = new pc.Color(h, 0.81, 0, null)),
              (this.availableMoves[l].source.data.tubeBackSprite.color = c);
            var p = this.availableMoves[l].source.data.blinkArrow,
              m = 1,
              _ = -1,
              d = 1;
            null == d && (d = 0), null == _ && (_ = 0), null == m && (m = 0);
            var g = new pc.Vec3(m, _, d);
            p.setLocalScale(g),
              (this.availableMoves[l].source.data.blinkArrow.enabled = !0),
              this.availableMoves[l].destination.data.blinkAnim.setTrigger(
                "Blink_R"
              );
            var y,
              v = 1;
            null == v
              ? ((v = [0, 0, 0, 0]), (y = new pc.Color(v)))
              : (y = new pc.Color(v, 0.81, 0, null)),
              (this.availableMoves[l].destination.data.tubeBackSprite.color =
                y);
            var b = _$Vector3_Vector3_$Impl_$.one;
            this.availableMoves[l].destination.data.blinkArrow.setLocalScale(b),
              (this.availableMoves[l].destination.data.blinkArrow.enabled = !0),
              this.blinkingTubes.push(this.availableMoves[l].source),
              this.blinkingTubes.push(this.availableMoves[l].destination);
          } else IngameMenu.inst.hintBtn.element.useInput = !0;
        else
          (IngameMenu.inst.hintBtn.element.useInput = !1),
            (this.availableMoves = []),
            UIManager.isGameplaying &&
              !this.isWonPanelOpened &&
              (haxe_Log.trace("No More Moves", {
                fileName: "src/UIManager.hx",
                lineNumber: 1197,
                className: "UIManager",
                methodName: "GetHintMove",
              }),
              (this.showNoMoreTimer = motion_Actuate
                .timer(2)
                .onComplete($bind(this, this.ShowNoMorePanel))));
      }
    }
    ShowNoMorePanel() {
      if (!APIManager.HasFeature("rewarded")) {
        var e = GameManager.get_SkipLvlCount(),
          t = GameManager.get_EmptyTubesCount(),
          a = GameManager.get_UndoMovesCount();
        if (0 == e && (0 == t || this.tubesAdded >= 2) && 0 == a)
          return void this.GameLose();
      }
      if (
        (this.tubesAdded >= 2
          ? ((this.nmmXtraTubeBtn.enabled = !1),
            (this.powerupImage.element.spriteAsset = this.skipLvlSp.id),
            (this.descriptionText.element.text =
              "You can skip Level with skip powerup"))
          : ((this.nmmXtraTubeBtn.enabled = !0),
            (this.powerupImage.element.spriteAsset = this.xtraTubeSp.id),
            (this.descriptionText.element.text = "Add extra tube to continue")),
        UIManager.isGameplaying &&
          (MainManager.inst.PlayOneShot("GameLose"),
          (this.nmmPanel.enabled = !0),
          this.nmmPanel.anim.baseLayer.play("ActivateAnim"),
          !APIManager.HasFeature("rewarded")))
      ) {
        null == this.nmmSkipLevelBtn &&
          (this.nmmSkipLevelBtn = this.nmmPanel.findByPath("BG/SkipBtn")),
          null == this.nmmSkipLevelBtnYoutube &&
            (this.nmmSkipLevelBtnYoutube =
              this.nmmPanel.findByPath("BG/SkipBtnYoutube")),
          null == this.nmmUndoBtn &&
            (this.nmmUndoBtn = this.nmmPanel.findByPath("BG/UndoBtn")),
          (this.nmmSkipLevelBtn.enabled = !1),
          (this.nmmSkipLevelBtnYoutube.enabled = !0);
        var n = GameManager.get_SkipLvlCount();
        this.nmmSkipLevelBtnYoutube.button.active = n > 0;
        var i = GameManager.get_UndoMovesCount();
        this.nmmUndoBtn.button.active = i > 0;
        var s = GameManager.get_EmptyTubesCount();
        this.nmmXtraTubeBtn.button.active = s > 0;
      }
    }
    UI_AA_BtnClick() {
      null != MainManager.inst && MainManager.inst.PlayOneShot("BtnClick");
    }
    UI_Game_AddXtraTube(e) {
      MainManager.inst.PlayOneShot("BtnClick");
      var t = this;
      if (null != LevelManager.inst && null != APIManager.inst)
        if (GameManager.get_EmptyTubesCount() <= 0)
          APIManager.ShowRewardedAD(function (e) {
            if (e) {
              var a = GameManager;
              a.set_EmptyTubesCount(a.get_EmptyTubesCount() + 1),
                t.SetXtraTubeCount();
            }
          }, e);
        else {
          (this.nmmPanel.enabled = !1),
            (this.newGpPowerTutPanel.enabled = !1),
            this.AddXtraTubeInLevel(),
            LevelManager.inst.AddExtraTube();
          var a = GameManager;
          a.set_EmptyTubesCount(a.get_EmptyTubesCount() - 1),
            this.SetXtraTubeCount(),
            this.GetHintMove(!1);
        }
    }
    AddXtraTubeInLevel() {
      (this.tubesAdded += 1),
        this.tubesAdded >= 2 &&
          (IngameMenu.inst.xTraTubeBtn.element.useInput = !1);
    }
    UI_Game_SkipBtn(e) {
      if ("SkipBtn" != UIManager.lastBtnPressed) {
        (UIManager.lastBtnPressed = "SkipBtn"),
          MainManager.inst.PlayOneShot("BtnClick");
        var t = this;
        if (APIManager.HasFeature("rewarded"))
          null != APIManager.inst
            ? APIManager.ShowRewardedAD(function (e) {
                e
                  ? ((UIManager.lastBtnPressed = ""),
                    (UIManager.isGameplaying = !0),
                    motion_Actuate
                      .timer(0.1)
                      .onComplete($bind(t, t.SkipLevelOnReward)))
                  : (UIManager.lastBtnPressed = "");
              }, e)
            : (haxe_Log.trace("AdsManager not found", {
                fileName: "src/UIManager.hx",
                lineNumber: 1398,
                className: "UIManager",
                methodName: "UI_Game_SkipBtn",
              }),
              (UIManager.lastBtnPressed = ""));
        else {
          if (!UIManager.isGameplaying) return;
          var a = GameManager.get_SkipLvlCount();
          a > 0 &&
            (MainManager.inst.PlayOneShot("BtnClick"),
            --a,
            GameManager.set_SkipLvlCount(a),
            UIManager.inst.SkipLevelOnReward());
        }
      }
    }
    SkipLevelOnReward() {
      (this.losePanel.enabled = !1),
        (this.isRewardedAdSeen = !0),
        (this.movesUsed = this.moves1Star + 1),
        this.GameWon(!0);
    }
    UI_Game_RetryBtn() {
      MainManager.inst.PlayOneShot("BtnClick");
      var e = this;
      null != APIManager.inst &&
        APIManager.ShowInterstitial(function (t) {
          (e.losePanel.enabled = !1),
            (e.pausedPanel.enabled = !1),
            motion_Actuate.stop(e.showNoMoreTimer, null, !1, !1),
            MainManager.inst.LoadLevel(!1);
        }, "RetryBtn");
    }
    UI_Game_UndoBtn(e) {
      if ("UndoBtn" != UIManager.lastBtnPressed) {
        (UIManager.lastBtnPressed = "UndoBtn"),
          MainManager.inst.PlayOneShot("BtnClick");
        var t = this;
        GameManager.get_UndoMovesCount() > 0
          ? GameManager.inst.Record_Redo(function (a) {
              if (a) {
                var n = GameManager;
                n.set_UndoMovesCount(n.get_UndoMovesCount() - 1),
                  motion_Actuate
                    .timer(0.1)
                    .onComplete($bind(t, t.SetUndoCount)),
                  TubeController.SwitchOffBlinking(),
                  (t.losePanel.enabled = !1),
                  "button.nomoremoves.undomoves" == e &&
                    ((t.nmmPanel.enabled = !1),
                    (t.newGpPowerTutPanel.enabled = !1)),
                  (UIManager.isGameplaying = !0),
                  t.GetHintMove(!1);
              } else haxe_Log.trace("Undo failed=>", { fileName: "src/UIManager.hx", lineNumber: 1454, className: "UIManager", methodName: "UI_Game_UndoBtn" });
              UIManager.lastBtnPressed = "";
            })
          : APIManager.ShowRewardedAD(function (e) {
              e &&
                (GameManager.set_UndoMovesCount(
                  GameManager.get_UndoMovesCount() + 5
                ),
                t.SetUndoCount()),
                (UIManager.lastBtnPressed = "");
            }, e);
      }
    }
    UI_Game_HomeBtn(e, t) {
      null == t && (t = !1), null == e && (e = !1);
      var a = this;
      t
        ? "HomeBtn" != UIManager.lastBtnPressed &&
          ((UIManager.lastBtnPressed = "HomeBtn"),
          MainManager.inst.PlayOneShot("BtnClick"),
          (UIManager.isGameplaying = !1),
          LevelCompleteScreen.Deactivate(),
          (this.losePanel.enabled = !1),
          (this.isWonPanelOpened = !1),
          null != APIManager.inst &&
            APIManager.ShowInterstitial(function (t) {
              a.FadeInOutPanel(function (t) {
                var n = PlayerPrefs.GetInt(
                  "Mode_" +
                    PlayerPrefs.GetInt("CurrModeNum", 1) +
                    "_LvlUnlocked",
                  1
                );
                PlayerPrefs.SetInt("CurrLvlNum", n),
                  e && a.AddCurrency(a.wpEarnedGems),
                  a.OfflineRewardCheck(),
                  a.activateMainPanel(),
                  a.OnMainMenuReached(),
                  (IngameMenu.inst.entity.enabled = !1),
                  a.GamePlayPanelOnOff(!1, 0, 1),
                  GameManager.inst.InstantiateNewLevel(function (e) {}, !0),
                  (a.mmMainMenu.enabled = !0),
                  (a.mmLevelsCont.enabled = !1),
                  (a.shopPanelB.enabled = !1);
              });
            }, "HomeBtn"))
        : APIManager.GameInterface.gameQuit().then(function () {
            a.UI_Game_HomeBtn(e, !0);
          });
    }
    activateMainPanel() {
      (this.mainPanel.enabled = !0),
        (this.curMMButton = null),
        this.switchMMBtn(this.mmHomeBtn, !0);
    }
    OnMainMenuReached() {
      PlayerPrefs.GetBool("OnMainMenuReached", !1) ||
        PlayerPrefs.SetBool("OnMainMenuReached", !0);
    }
    CheckSingleColorToEmpty(e, t) {
      return e.filledColors == e.get_PortionCanSend() && t.filledColors <= 0;
    }
    CheckSingleToManyColor(e, t) {
      return (
        e.filledColors == e.get_PortionCanSend() &&
        t.filledColors != t.get_PortionCanSend()
      );
    }
    SingleToSingleColReturn() {
      for (var e = 0, t = this.availableMoves.length; e < t; ) {
        var a = e++;
        if (
          this.availableMoves[a].source.filledColors ==
            this.availableMoves[a].source.get_PortionCanSend() &&
          this.availableMoves[a].destination.filledColors ==
            this.availableMoves[a].destination.get_PortionCanSend()
        )
          return a;
      }
      return -1;
    }
    ManyToSingleColReturn() {
      for (var e = 0, t = this.availableMoves.length; e < t; ) {
        var a = e++;
        if (
          this.availableMoves[a].source.filledColors !=
            this.availableMoves[a].source.get_PortionCanSend() &&
          this.availableMoves[a].destination.filledColors ==
            this.availableMoves[a].destination.get_PortionCanSend()
        ) {
          if (!(GameManager.recordingNodes.length > 0)) return a;
          if (
            GameManager.recordingNodes[GameManager.recordingNodes.length - 1]
              .senderTube != this.availableMoves[a].destination &&
            GameManager.recordingNodes[GameManager.recordingNodes.length - 1]
              .receiverTube != this.availableMoves[a].source
          )
            return a;
        }
      }
      return -1;
    }
    MoreColToEmpty() {
      for (var e = 0, t = this.availableMoves.length; e < t; ) {
        var a = e++;
        if (
          this.availableMoves[a].source.filledColors !=
            this.availableMoves[a].source.get_PortionCanSend() &&
          0 == this.availableMoves[a].destination.filledColors &&
          this.availableMoves[a].source.get_PortionCanSend() > 2
        ) {
          if (!(GameManager.recordingNodes.length > 0)) return a;
          if (
            GameManager.recordingNodes[GameManager.recordingNodes.length - 1]
              .senderTube != this.availableMoves[a].destination &&
            GameManager.recordingNodes[GameManager.recordingNodes.length - 1]
              .receiverTube != this.availableMoves[a].source
          )
            return a;
        }
      }
      for (var n = 0, i = this.availableMoves.length; n < i; ) {
        var s = n++;
        if (
          this.availableMoves[s].source.filledColors !=
            this.availableMoves[s].source.get_PortionCanSend() &&
          0 == this.availableMoves[s].destination.filledColors &&
          this.availableMoves[s].source.get_PortionCanSend() > 1
        ) {
          if (!(GameManager.recordingNodes.length > 0)) return s;
          if (
            GameManager.recordingNodes[GameManager.recordingNodes.length - 1]
              .senderTube != this.availableMoves[s].destination &&
            GameManager.recordingNodes[GameManager.recordingNodes.length - 1]
              .receiverTube != this.availableMoves[s].source
          )
            return s;
        }
      }
      return -1;
    }
    setThemeScale(e) {
      var t = MainManager.inst.bgThemeSr,
        a = 1,
        n = 1,
        i = 1;
      null == i && (i = 0), null == n && (n = 0), null == a && (a = 0);
      var s = new pc.Vec3(a, n, i);
      t.setLocalScale(s);
      var r = js_Boot
          .__cast(MainManager.inst.bgThemeSr.sprite.aabb, pc.BoundingBox)
          .halfExtents.clone(),
        o = (2 * e) / (r = _$Vector3_Vector3_$Impl_$.mulN(r, 2)).y,
        l =
          (((2 * e) / pc.app.graphicsDevice.height) *
            pc.app.graphicsDevice.width) /
          r.x;
      if (o > l) {
        var u = MainManager.inst.bgThemeSr,
          c = o,
          h = o,
          p = 1;
        null == p && (p = 0), null == h && (h = 0), null == c && (c = 0);
        var m = new pc.Vec3(c, h, p);
        u.setLocalScale(m);
      } else {
        var _ = MainManager.inst.bgThemeSr,
          d = l,
          g = l,
          y = 1;
        null == y && (y = 0), null == g && (g = 0), null == d && (d = 0);
        var v = new pc.Vec3(d, g, y);
        _.setLocalScale(v);
      }
      var b = _$Vector3_Vector3_$Impl_$.zero;
      if ((MainManager.inst.bgThemeSr.setLocalPosition(b), o < l))
        if (
          15 == MainManager.pickedItemNum[1] ||
          18 == MainManager.pickedItemNum[1]
        ) {
          var f = MainManager.inst.bgThemeSr,
            S = 0,
            P = -(l * r.y - 2 * e) / 2,
            M = 0;
          null == M && (M = 0), null == P && (P = 0), null == S && (S = 0);
          var C = new pc.Vec3(S, P, M);
          f.setLocalPosition(C);
        } else if (14 == MainManager.pickedItemNum[1]) {
          var I = MainManager.inst.bgThemeSr,
            B = 0,
            T = (l * r.y - 2 * e) / 2,
            L = 0;
          null == L && (L = 0), null == T && (T = 0), null == B && (B = 0);
          var x = new pc.Vec3(B, T, L);
          I.setLocalPosition(x);
        }
    }
    EarnedStars() {
      var e = 3;
      switch (GameManager.currMode) {
        case 0:
          UIManager.inst.movesUsed > UIManager.inst.moves1Star
            ? (e = 0)
            : UIManager.inst.movesUsed > UIManager.inst.moves2Star
            ? (e = 1)
            : UIManager.inst.movesUsed > UIManager.inst.moves3Star && (e = 2);
          break;
        case 1:
          UIManager.inst.elapsedTime > UIManager.inst.time1Star
            ? (e = 0)
            : UIManager.inst.elapsedTime > this.time2Star
            ? (e = 1)
            : UIManager.inst.elapsedTime > this.time3Star && (e = 2);
          break;
        case 2:
          e = 3;
      }
      return e;
    }
    FadeInOutPanel(e) {
      var t = (1 / this.fadeSpeed) * 0.016666666666666666;
      (this.faderImage.element.useInput = !0),
        (this.faderImage.element.opacity = 0);
      var a = this;
      motion_Actuate
        .update(
          function (e) {
            a.faderImage.element.opacity = e;
          },
          t,
          [0],
          [1]
        )
        .ease(motion_easing_Linear.get_easeNone())
        .onComplete(function () {
          (a.faderImage.element.opacity = 1), e(!0);
        }),
        motion_Actuate
          .update(
            function (e) {
              a.faderImage.element.opacity = e;
            },
            t,
            [1],
            [0]
          )
          .delay(t + 0.2)
          .ease(motion_easing_Linear.get_easeNone())
          .onComplete(function () {
            (a.faderImage.element.opacity = 0),
              (a.faderImage.element.useInput = !1);
          });
    }
    BlackP_FadeIn() {
      var e = (1 / this.fadeSpeed) * 0.016666666666666666,
        t = this;
      motion_Actuate
        .update(
          function (e) {
            t.blackImage.element.opacity = e;
          },
          e,
          [0],
          [1]
        )
        .ease(motion_easing_Linear.get_easeNone())
        .onComplete(function () {
          t.blackImage.element.opacity = 1;
        });
    }
    BlackP_FadeOut() {
      var e = (1 / this.fadeSpeed) * 0.016666666666666666,
        t = this;
      motion_Actuate
        .update(
          function (e) {
            t.blackImage.element.opacity = e;
          },
          e,
          [1],
          [0]
        )
        .ease(motion_easing_Linear.get_easeNone())
        .onComplete(function () {
          t.blackImage.element.opacity = 0;
        });
    }
    UI_Setting_AudioBtn() {
      PlayerPrefs.SetInt("Audio", 1 - PlayerPrefs.GetInt("Audio", 1)),
        this.SetSettingsPanel(),
        MainManager.inst.PlayOneShot("BtnClick");
    }
    UI_Setting_MusicBtn() {
      PlayerPrefs.SetInt("Music", 1 - PlayerPrefs.GetInt("Music", 1)),
        this.SetSettingsPanel(),
        MainManager.inst.PlayOneShot("BtnClick");
    }
    SetSettingsPanel() {
      (UIManager.isAudioOn = 1 == PlayerPrefs.GetInt("Audio", 1)),
        (UIManager.isMusicOn = 1 == PlayerPrefs.GetInt("Music", 1)),
        (UIManager.isAudioOn = UIManager.isAudioOn && !Main.isFamobiMuted),
        (UIManager.isMusicOn = UIManager.isMusicOn && !Main.isFamobiMuted),
        (this.audioToggleImageB.element.opacity = Main.isFamobiMuted ? 0.5 : 1),
        (this.musicToggleImageB.element.opacity = Main.isFamobiMuted ? 0.5 : 1),
        UIManager.isAudioOn
          ? (this.audioToggleImageB.element.spriteAsset =
              this.toggleOnSprite.id)
          : (this.audioToggleImageB.element.spriteAsset =
              this.toggleOffSprite.id),
        UIManager.isMusicOn
          ? ((this.musicToggleImageB.element.spriteAsset =
              this.toggleOnSprite.id),
            MainManager.inst.setBGMusic(!0))
          : ((this.musicToggleImageB.element.spriteAsset =
              this.toggleOffSprite.id),
            MainManager.inst.setBGMusic(!1));
    }
    UI_Main_Settings() {
      MainManager.inst.PlayOneShot("BtnClick"),
        (this.settingsPanelB.enabled = !0),
        this.settingsPanelB.anim.baseLayer.play("ActivateAnim");
    }
    BlastTubeConfetti(e) {
      var t = EntityHelper.Instantiate(this.tubeConfetti, pc.app.root),
        a = e.getPosition().clone();
      t.setPosition(a);
      var n = e.getRotation().clone();
      t.setRotation(n), (t.enabled = !0);
      for (
        var i = this.entity.findComponents("particlesystem"),
          s = 0,
          r = i.length;
        s < r;

      ) {
        i[s++].play();
      }
      motion_Actuate.timer(5).onComplete(function () {
        null != t && t.destroy();
      }),
        MainManager.inst.PlayOneShot("Confetti");
    }
    SetXtraTubeCount() {
      for (
        var e = GameManager.get_EmptyTubesCount(),
          t = 0,
          a = this.xtraTubeCounters;
        t < a.length;

      ) {
        var n = a[t];
        ++t, (n.element.text = "" + e);
      }
      var i = !0;
      if (
        (APIManager.HasFeature("rewarded") || (i = !1),
        e > 0 || !i
          ? ((IngameMenu.inst.xTraTubeBtnRewIcon.enabled = !1),
            (IngameMenu.inst.xTraTubeBtnCounter.enabled = !0),
            (this.nmmXtraTubeAd.enabled = !1),
            (this.nmmXtraTubePlus.enabled = !1),
            (this.nmmXtraTubeCountParent.enabled = !0))
          : ((IngameMenu.inst.xTraTubeBtnRewIcon.enabled = !0),
            (IngameMenu.inst.xTraTubeBtnCounter.enabled = !1),
            (this.nmmXtraTubeAd.enabled = !0),
            (this.nmmXtraTubeCountParent.enabled = !1)),
        !APIManager.HasFeature("rewarded") && null != this.nmmXtraTubeBtn)
      ) {
        var s = GameManager.get_EmptyTubesCount();
        this.nmmXtraTubeBtn.button.active = s > 0;
      }
    }
    SetUndoCount() {
      for (
        var e = GameManager.get_UndoMovesCount(), t = 0, a = this.undoCounters;
        t < a.length;

      ) {
        var n = a[t];
        ++t,
          null != n.element &&
            n.element.text != e + "" &&
            (n.element.text = e + "");
      }
      var i = !0;
      if (
        (APIManager.HasFeature("rewarded") || (i = !1),
        e > 0 || !i
          ? ((IngameMenu.inst.undoBtnRewIcon.enabled = !1),
            (IngameMenu.inst.undoBtnCounter.enabled = !0),
            (this.undoVideoIconOnLosePanel.enabled = !1),
            (this.nmmUndoAd.enabled = !1),
            (this.nmmUndoPlus.enabled = !1),
            (this.nmmUndoCountParent.enabled = !0))
          : ((IngameMenu.inst.undoBtnRewIcon.enabled = !0),
            (IngameMenu.inst.undoBtnCounter.enabled = !1),
            (this.undoVideoIconOnLosePanel.enabled = !0),
            (this.nmmUndoAd.enabled = !0),
            (this.nmmUndoCountParent.enabled = !1)),
        !APIManager.HasFeature("rewarded") && null != this.nmmUndoBtn)
      ) {
        var s = GameManager.get_UndoMovesCount();
        this.nmmUndoBtn.button.active = s > 0;
      }
    }
    SetHintCount() {
      for (
        var e = GameManager.get_HintCounts(), t = 0, a = this.hintsCounters;
        t < a.length;

      ) {
        var n = a[t];
        ++t, (n.element.text = "" + e);
      }
      var i = !0;
      APIManager.HasFeature("rewarded") || (i = !1),
        e > 0 || !i
          ? ((IngameMenu.inst.hintBtnRewIcon.enabled = !1),
            (IngameMenu.inst.hintBtnCounter.enabled = !0))
          : ((IngameMenu.inst.hintBtnRewIcon.enabled = !0),
            (IngameMenu.inst.hintBtnCounter.enabled = !1));
    }
    SetSkipLvlCount() {
      for (
        var e = GameManager.get_SkipLvlCount(), t = 0, a = this.skipsCounters;
        t < a.length;

      ) {
        var n = a[t];
        ++t, null != n && (n.element.text = "" + e);
      }
      var i = GameManager.get_SkipLvlCount();
      if (
        ((IngameMenu.inst.skipLevelBtnCounter.element.text = "" + i),
        (IngameMenu.inst.skipLevelRewIcon.enabled =
          GameManager.get_SkipLvlCount() <= 0),
        !APIManager.HasFeature("rewarded") &&
          null != this.nmmSkipLevelBtnYoutube)
      ) {
        var s = GameManager.get_SkipLvlCount();
        this.nmmSkipLevelBtnYoutube.button.active = s > 0;
      }
    }
    SetBgTheme() {
      if (1 == MainManager.pickedItemNum[1])
        MainManager.inst.bgThemeSr.enabled = !1;
      else {
        (MainManager.inst.bgThemeSr.enabled = !0),
          (MainManager.inst.bgThemeSr.sprite.spriteAsset =
            this.bgThemeSprite[MainManager.pickedItemNum[1] - 1].id);
        var e = 1;
        if (
          ((e =
            MainManager.pickedItemNum[1] > 9
              ? 0.39215686274509803
              : 0.054901960784313725),
          (MainManager.inst.bgThemeSr.sprite.opacity = e),
          null !=
            this.bgThemeSprite[MainManager.pickedItemNum[1] - 1].data
              .textureAtlasAsset)
        )
          pc.app.assets
            .get(
              this.bgThemeSprite[MainManager.pickedItemNum[1] - 1].data
                .textureAtlasAsset
            )
            .ready(function (e) {
              return (
                UIManager.inst.setThemeScale(
                  js_Boot.__cast(
                    pc.app.root.findByTag("MainCamera")[0],
                    pc.Entity
                  ).camera.orthoHeight
                ),
                !0
              );
            });
        else
          this.bgThemeSprite[MainManager.pickedItemNum[1] - 1].ready(function (
            e
          ) {
            return (
              UIManager.inst.setThemeScale(
                js_Boot.__cast(
                  pc.app.root.findByTag("MainCamera")[0],
                  pc.Entity
                ).camera.orthoHeight
              ),
              !0
            );
          });
      }
    }
    UI_OnPauseBtnClick() {
      this.pausedPanel.anim.baseLayer.play("ActivateAnim");
    }
    SubLvlStars(e, t, a) {
      for (var n = 0, i = t, s = a; i < s; ) {
        var r = i++;
        n += PlayerPrefs.GetInt("Mode_" + e + "_Lvl_" + r + "_Stars", 0);
      }
      return n;
    }
    UI_LGP_GroupToSubLvl(e) {
      if ("GroupToSlvl" != UIManager.lastBtnPressed) {
        (UIManager.lastBtnPressed = "GroupToSlvl"),
          MainManager.inst.PlayOneShot("BtnClick");
        var t = this;
        if (
          (PlayerPrefs.SetInt("CurrGroupNum", e),
          (GameManager.currModeNum = e),
          this.slvlBtns.length > 0)
        )
          for (var a = 0, n = this.slvlBtns.length; a < n; ) {
            var i = a++;
            (this.slvlBtns[i].entity.button.enabled = !1),
              this.slvlBtns[i].entity.destroy();
          }
        var s = Math.ceil(
          GameManager.inst.modes[e - 1].totalLvls / this.slpDiv
        );
        this.slvlBtns = [];
        for (var r = GameManager.currLvlNum, o = 0, l = s; o < l; ) {
          var u = o++,
            c = EntityHelper.GetComponent_SubLvlBtn(
              EntityHelper.InstantiatePrefab(
                this.slvlBtnPrefab,
                this.slvlBtnParent
              ),
              SubLvlBtn
            );
          this.slvlBtns.push(c);
          var h = [1 + u * this.slpDiv],
            p = (1 + u) * this.slpDiv,
            m = GameManager.inst.modes[e - 1].totalLvls,
            _ = [0 | (p < 1 ? 1 : p > m ? m : p)];
          if (
            ((this.slvlBtns[u].lvlText.element.text = h[0] + "-" + _[0]),
            r >= h[0])
          ) {
            (this.slvlBtns[u].slBtn.button.active = !0),
              (this.slvlBtns[u].bar.button.active = !0);
            var d =
              this.SubLvlStars(GameManager.currGroupNum, h[0], _[0]) + "/";
            this.slvlBtns[u].starText.element.text = d + 3 * this.slpDiv;
          } else
            this.slvlBtns[u].starText.element.text = "0/" + 3 * this.slpDiv;
          UIHelper.AddButtonClickHandler(
            this.slvlBtns[u].slBtn,
            (function (e, a) {
              return function () {
                t.UI_SLP_MainBtn(a[0], e[0]);
              };
            })(_, h)
          );
        }
        (this.slvlPanel.enabled = !0),
          (this.levelPanel.enabled = !1),
          this.recalculateScrollContHeight(this.slvlBtnParent);
      }
    }
    recalculateScrollContHeight(e) {
      (e.element.height = 0), e.layoutgroup.reflow();
      for (var t = 0, a = 0, n = e.children.length; a < n; ) {
        var i = a++,
          s = e.children[i];
        -s.getLocalPosition().clone().y + s.element.height > t &&
          (t = -s.getLocalPosition().clone().y + s.element.height);
      }
      e.element.height = t;
    }
    UI_SLP_MainBtn(e, t) {
      if ("SlvlMain" != UIManager.lastBtnPressed) {
        (UIManager.lastBtnPressed = "SlvlMain"),
          MainManager.inst.PlayOneShot("BtnClick");
        var a = PlayerPrefs.GetInt("CurrModeNum", 1),
          n = this,
          i = PlayerPrefs.GetInt("Mode_" + a + "_LvlUnlocked", 1),
          s = t - e + 1;
        if (this.lvlBtns.length > 0)
          for (var r = 0, o = this.lvlBtns.length; r < o; ) {
            var l = r++;
            (this.lvlBtns[l].button.enabled = !1), this.lvlBtns[l].destroy();
          }
        this.lvlBtns = [];
        for (var u = 0, c = s; u < c; ) {
          var h = u++,
            p = EntityHelper.InstantiatePrefab(
              this.lvlBtnPrefab,
              this.lvlParentGrid
            );
          this.lvlBtns.push(p);
          var m = [e + h],
            _ = m[0];
          (js_Boot.__cast(p.findByName("Number"), pc.Entity).element.text =
            _ + ""),
            UIHelper.AddButtonClickHandler(
              p,
              (function (e) {
                return function () {
                  n.UI_Lvl_OnLvlBtn(e[0]);
                };
              })(m)
            ),
            e + h - 1 == i - 1
              ? (p.button.active = !0)
              : e + h - 1 < i - 1 || PlayerPrefs.GetBool("IsSubsBuyed", !1)
              ? ((p.button.active = !0),
                this.AssignStarToBtn(p.findByName("Stars"), a, h + e))
              : (p.button.active = !1);
        }
        (this.levelPanel.enabled = !0),
          (this.slvlPanel.enabled = !1),
          (this.levelBtnClickBlockFramesLeft = 2),
          this.recalculateScrollContHeight(this.lvlParentGrid);
        var d = i - e,
          g = this.lvlBtns.length - 1;
        this.scrollScrollViewToChild(
          this.lvlScrollRect,
          this.lvlBtns[0 | (d < 0 ? 0 : d > g ? g : d)]
        );
      }
    }
    scrollScrollViewToChild(e, t) {
      var a = e.scrollview,
        n = e.findByGuid(Std.string(a.contentEntity) + ""),
        i = e.findByGuid(Std.string(a.viewportEntity) + "");
      if ((this.recalculateScrollContHeight(n), null != t)) {
        var s = -t.getLocalPosition().y - 225,
          r = a.scroll.clone(),
          o = s / (n.element.height - i.element.height);
        (r.y = o < 0 ? 0 : o > 1 ? 1 : o), (a.scroll = r);
      }
    }
    AssignStarToBtn(e, t, a) {
      1 == PlayerPrefs.GetInt("Mode_" + t + "_Lvl_" + a + "_Stars", 0)
        ? (e.element.spriteAsset = this.lvlBtn1Star.id)
        : 2 == PlayerPrefs.GetInt("Mode_" + t + "_Lvl_" + a + "_Stars", 0)
        ? (e.element.spriteAsset = this.lvlBtn2Star.id)
        : 3 == PlayerPrefs.GetInt("Mode_" + t + "_Lvl_" + a + "_Stars", 0) &&
          (e.element.spriteAsset = this.lvlBtn3Star.id);
    }
    UI_Lvl_OnLvlBtn(e) {
      if (
        !(this.levelBtnClickBlockFramesLeft > 0) &&
        "LvlPanelBtn" != UIManager.lastBtnPressed
      ) {
        if (
          ((UIManager.lastBtnPressed = "LvlPanelBtn"),
          MainManager.inst.PlayOneShot("BtnClick"),
          PlayerPrefs.SetInt("CurrLvlNum", e),
          MainManager.inst.LoadLevel(!1),
          this.slvlBtns.length > 0)
        )
          for (var t = 0, a = this.slvlBtns.length; t < a; ) {
            var n = t++;
            this.slvlBtns[n].entity.destroy();
          }
        if (((this.slvlBtns = []), this.lvlBtns.length > 0))
          for (var i = 0, s = this.lvlBtns.length; i < s; ) {
            var r = i++;
            (this.lvlBtns[r].button.enabled = !1), this.lvlBtns[r].destroy();
          }
        this.lvlBtns = [];
      }
    }
    OfflineRewardCheck() {
      if (PlayerPrefs.GetBool("IsTutorialPlayed", !1)) {
        if (!PlayerPrefs.HasKey("OfflineTime"))
          try {
            PlayerPrefs.SetString(
              "OfflineTime",
              HxOverrides.dateStr(new Date())
            );
          } catch (e) {
            haxe_Log.trace(e instanceof js__$Boot_HaxeError ? e.val : e, {
              fileName: "src/UIManager.hx",
              lineNumber: 2285,
              className: "UIManager",
              methodName: "OfflineRewardCheck",
            });
          }
        try {
          var e = HxOverrides.strDate(
            PlayerPrefs.GetString(
              "OfflineTime",
              HxOverrides.dateStr(new Date())
            )
          );
          (new Date().getTime() - e.getTime()) / 1e3 / 60 / 60 >=
          OfflineReward.rewardGapHours
            ? ((EntityHelper.GetComponent_OfflineReward(
                this.offlineTimerTextB,
                OfflineReward
              ).enabled = !1),
              (this.offlineTimerTextB.element.text = "FULL"),
              (this.mmPiggyImage.element.spriteAsset = this.normalPig.id))
            : ((EntityHelper.GetComponent_OfflineReward(
                this.offlineTimerTextB,
                OfflineReward
              ).enabled = !0),
              (this.mmPiggyImage.element.spriteAsset = this.sleepyPig.id));
        } catch (e) {
          haxe_Log.trace(e instanceof js__$Boot_HaxeError ? e.val : e, {
            fileName: "src/UIManager.hx",
            lineNumber: 2306,
            className: "UIManager",
            methodName: "OfflineRewardCheck",
          }),
            (EntityHelper.GetComponent_OfflineReward(
              this.offlineTimerTextB,
              OfflineReward
            ).enabled = !0),
            (this.mmPiggyImage.element.spriteAsset = this.sleepyPig.id);
        }
      } else
        try {
          PlayerPrefs.SetString("OfflineTime", HxOverrides.dateStr(new Date()));
        } catch (e) {
          haxe_Log.trace(e instanceof js__$Boot_HaxeError ? e.val : e, {
            fileName: "src/UIManager.hx",
            lineNumber: 2271,
            className: "UIManager",
            methodName: "OfflineRewardCheck",
          });
        }
    }
    SetPiggyCoins(e) {
      (this.piggyCoinAmount = 200 * e),
        (this.meterPriceText.element.text = "" + this.piggyCoinAmount);
    }
    OfflineVideoReward() {
      PiggyAnimReceiver.amountToSend = this.piggyCoinAmount;
      try {
        PlayerPrefs.SetString("OfflineTime", HxOverrides.dateStr(new Date()));
      } catch (e) {
        haxe_Log.trace(
          "=>" + Std.string(e instanceof js__$Boot_HaxeError ? e.val : e),
          {
            fileName: "src/UIManager.hx",
            lineNumber: 2329,
            className: "UIManager",
            methodName: "OfflineVideoReward",
          }
        );
      }
      this.pigAnim.anim.baseLayer.play("Break");
    }
    PiggyCoinsSended() {
      (this.piggyCoinAmount = 0),
        (this.mainPanel.enabled = !0),
        (this.piggyPop.enabled = !1),
        this.OfflineRewardCheck();
    }
    UI_Offline_OpenPig() {
      (UIManager.lastBtnPressed = ""), MainManager.inst.PlayOneShot("BtnClick");
      var e = HxOverrides.strDate(
        PlayerPrefs.GetString("OfflineTime", HxOverrides.dateStr(new Date()))
      );
      (new Date().getTime() - e.getTime()) / 1e3 / 60 / 60 >=
      OfflineReward.rewardGapHours
        ? ((this.meterAnim.anim.enabled = !0),
          this.meterAnim.anim.baseLayer.play("RewardScale"),
          (this.orSimpleBtn.element.useInput = !0),
          (this.orRewardBtn.element.useInput = !0),
          (this.piggyPop.enabled = !0),
          this.piggyPop.anim.baseLayer.play("ActivateAnim"),
          this.pigAnim.anim.baseLayer.play("PiggyFull"),
          (this.mainPanel.enabled = !1))
        : ((this.piggySleepPop.enabled = !0),
          this.piggySleepPop.anim.baseLayer.play("ActivateAnim"));
    }
    UI_Offline_OnSimpleReward() {
      if ("SimpleReward" != UIManager.lastBtnPressed) {
        (UIManager.lastBtnPressed = "SimpleReward"),
          MainManager.inst.PlayOneShot("BtnClick"),
          (this.orSimpleBtn.element.useInput = !1),
          (this.orRewardBtn.element.useInput = !1),
          (PiggyAnimReceiver.amountToSend = 200);
        try {
          PlayerPrefs.SetString("OfflineTime", HxOverrides.dateStr(new Date()));
        } catch (e) {
          haxe_Log.trace(
            "=>" + Std.string(e instanceof js__$Boot_HaxeError ? e.val : e),
            {
              fileName: "src/UIManager.hx",
              lineNumber: 2385,
              className: "UIManager",
              methodName: "UI_Offline_OnSimpleReward",
            }
          );
        }
        this.pigAnim.anim.baseLayer.play("Break");
      }
    }
    UI_Offline_OfflineVideoReward() {
      if ("OfflineAd" != UIManager.lastBtnPressed) {
        (UIManager.lastBtnPressed = "OfflineAd"),
          MainManager.inst.PlayOneShot("BtnClick");
        var e = this;
        null != APIManager.inst
          ? ((this.orSimpleBtn.element.useInput = !1),
            (this.orRewardBtn.element.useInput = !1),
            (this.meterAnim.anim.enabled = !1),
            APIManager.ShowRewardedAD(function (t) {
              t
                ? motion_Actuate
                    .timer(0.1)
                    .onComplete($bind(e, e.OfflineVideoReward))
                : ((e.meterAnim.anim.enabled = !0),
                  (e.orSimpleBtn.element.useInput = !0),
                  (e.orRewardBtn.element.useInput = !0),
                  (UIManager.lastBtnPressed = ""));
            }, "button.piggybank.claim"))
          : ((UIManager.lastBtnPressed = ""),
            (this.meterAnim.anim.enabled = !0),
            (this.orSimpleBtn.element.useInput = !0),
            (this.orRewardBtn.element.useInput = !0));
      }
    }
    SpinWheelCheck() {
      if (PlayerPrefs.GetBool("IsTutorialPlayed", !1)) {
        if (!PlayerPrefs.HasKey("SpinTime"))
          try {
            PlayerPrefs.SetString("SpinTime", HxOverrides.dateStr(new Date()));
          } catch (e) {
            haxe_Log.trace(e instanceof js__$Boot_HaxeError ? e.val : e, {
              fileName: "src/UIManager.hx",
              lineNumber: 2456,
              className: "UIManager",
              methodName: "SpinWheelCheck",
            });
          }
        try {
          var e = HxOverrides.strDate(
            PlayerPrefs.GetString("SpinTime", HxOverrides.dateStr(new Date()))
          );
          (new Date().getTime() - e.getTime()) / 1e3 / 60 / 60 >=
          TimerDailySpin.spinGapHours
            ? ((EntityHelper.GetComponent_TimerDailySpin(
                this.mmSpinTimer,
                TimerDailySpin
              ).enabled = !1),
              (this.mmSpinTimer.element.text = "SPIN NOW!"))
            : (EntityHelper.GetComponent_TimerDailySpin(
                this.mmSpinTimer,
                TimerDailySpin
              ).enabled = !0);
        } catch (e) {
          haxe_Log.trace(e instanceof js__$Boot_HaxeError ? e.val : e, {
            fileName: "src/UIManager.hx",
            lineNumber: 2475,
            className: "UIManager",
            methodName: "SpinWheelCheck",
          }),
            (EntityHelper.GetComponent_TimerDailySpin(
              this.mmSpinTimer,
              TimerDailySpin
            ).enabled = !0);
        }
      } else
        try {
          PlayerPrefs.SetString("SpinTime", HxOverrides.dateStr(new Date()));
        } catch (e) {
          haxe_Log.trace(e instanceof js__$Boot_HaxeError ? e.val : e, {
            fileName: "src/UIManager.hx",
            lineNumber: 2442,
            className: "UIManager",
            methodName: "SpinWheelCheck",
          });
        }
    }
    UI_Spin_CloseBtn() {
      (UIManager.lastBtnPressed = ""),
        MainManager.inst.PlayOneShot("BtnClick"),
        this.SpinWheelCheck(),
        this.UpdateCurrency(),
        this.SetUndoCount(),
        this.SetXtraTubeCount(),
        this.SetHintCount(),
        (this.mainPanel.enabled = !0),
        (this.spinPanel.enabled = !1);
    }
    UI_Spin_OpenWheel() {
      (UIManager.lastBtnPressed = ""), MainManager.inst.PlayOneShot("BtnClick");
      var e = this;
      this.FadeInOutPanel(function (t) {
        if (t) {
          var a = APIManager.HasFeature("rewarded")
            ? EntityHelper.InstantiatePrefab(e.spinPrefab[0])
            : EntityHelper.InstantiatePrefab(e.spinPrefabYoutube[0]);
          (js_Boot.__cast(
            a.findComponent("screen"),
            pc.ScreenComponent
          ).scaleBlend = 1),
            (js_Boot.__cast(
              a.findComponent("screen"),
              pc.ScreenComponent
            ).priority = 100),
            (e.mainPanel.enabled = !1);
        }
      });
    }
    UI_Open_CoinsChestBar() {
      this.UI_AA_BtnClick(),
        (this.coinsChestPop.enabled = !0),
        this.coinsChestPop.anim.baseLayer.play("ActivateAnim");
    }
    GiveCoinChestReward() {
      PlayerPrefs.SetInt("CoinChestStars", 0);
      var e = EntityHelper.GetComponent_CurrencyCollector(
          this.coinChest_CC,
          CurrencyCollector
        ),
        t = this;
      (e.currencyName = "Currency_1"),
        (e.amountToAdd = 500),
        e.DoStart(function (e) {
          haxe_Log.trace("Sended", {
            fileName: "src/UIManager.hx",
            lineNumber: 2566,
            className: "UIManager",
            methodName: "GiveCoinChestReward",
          }),
            t.SetCoinChestBar(),
            "ShowModes" == UIManager.lastBtnPressed &&
              (UIManager.lastBtnPressed = "");
        });
    }
    SetCoinChestBar() {
      var e = PlayerPrefs.GetInt("CoinChestStars", 0) / this.coinChestAmount;
      this.setFillAmount(this.coinChestBar, e),
        this.setFillAmount(this.mmCoinChestBar, e);
      var t = PlayerPrefs.GetInt("CoinChestStars", 0) + "/";
      if (
        ((this.coinChestStarCount.element.text = t + this.coinChestAmount),
        APIManager.HasFeature("rewarded") ||
          ("BuyBtnYoutube" != this.coinChestBtn.name &&
            ((this.coinChestBtn.enabled = !1),
            (this.coinChestBtn =
              this.coinsChestPop.findByPath("BG/BuyBtnYoutube")))),
        (this.coinChestBtn.button.active = !0),
        PlayerPrefs.GetInt("CoinChestStars", 0) >= this.coinChestAmount)
      ) {
        (this.coinChestBtn.enabled = !0), (this.coinChestInfo.enabled = !1);
        for (
          var a = 0,
            n = EntityHelper.GetComponent_CurrencyCollector(
              this.coinChest_CC,
              CurrencyCollector
            ).items;
          a < n.length;

        ) {
          var i = n[a];
          ++a, (i.enabled = !0);
        }
        (this.coinChestOpened.enabled = !0),
          (this.ccpOpenedCoins.enabled = !0),
          (this.coinChestClosed.enabled = !1);
      } else
        (this.coinChestBtn.enabled = !1),
          (this.coinChestInfo.enabled = !0),
          (this.coinChestOpened.enabled = !1),
          (this.ccpOpenedCoins.enabled = !1),
          (this.coinChestClosed.enabled = !0);
    }
    setFillAmount(e, t) {
      null == e.initFAWidth && (e.initFAWidth = e.element.width),
        (e.element.width = e.initFAWidth * t);
    }
    UI_CCP_BuyCoinChest() {
      if (
        !(
          "ShowModes" == UIManager.lastBtnPressed ||
          PlayerPrefs.GetInt("CoinChestStars", 0) < this.coinChestAmount
        )
      ) {
        (UIManager.lastBtnPressed = "ShowModes"),
          MainManager.inst.PlayOneShot("BtnClick"),
          (this.coinChestBtn.button.active = !1);
        var e = this;
        null != APIManager.inst
          ? APIManager.ShowRewardedAD(function (t) {
              t
                ? motion_Actuate
                    .timer(0.1)
                    .onComplete($bind(e, e.GiveCoinChestReward))
                : (UIManager.lastBtnPressed = "");
            }, "button.starschest.claim")
          : (haxe_Log.trace("APIManager not found", {
              fileName: "src/UIManager.hx",
              lineNumber: 2650,
              className: "UIManager",
              methodName: "UI_CCP_BuyCoinChest",
            }),
            (UIManager.lastBtnPressed = ""));
      }
    }
    TubesPanel1Check() {
      var e = [],
        t = 0;
      this.minBuyPrice = 5e5;
      this.tubesPanel1.buyBtn;
      for (var a = 0, n = this.tubesPanel1.shopItems.length; a < n; ) {
        var i = a++;
        PlayerPrefs.GetBool(
          _$MainManager_ShopCategory_$Impl_$.ToString(
            this.tubesPanel1.shopItems[i].shopCategory
          ) + this.tubesPanel1.shopItems[i].itemNum,
          this.tubesPanel1.shopItems[i].defaultLocked
        ) && e.push(this.tubesPanel1.shopItems[i]);
      }
      if (e.length > 0) {
        (t = this.tubesPanel1.buyPrices[9 - e.length]),
          this.minBuyPrice >= t && (this.minBuyPrice = t);
        var s = PlayerPrefs.GetFloat("Currency_1", 0);
        (this.tubesPanel1.buyBtn.button.active = s >= t),
          (this.tubesPanel1.buyPriceText.element.text = "" + t);
      } else
        (this.tubesPanel1.buyBtn.button.active = !1),
          (this.tubesPanel1.buyPriceText.element.text =
            "" +
            this.tubesPanel1.buyPrices[this.tubesPanel1.buyPrices.length - 1]);
    }
    UI_TubesPanel1_BuyBtn() {
      var e,
        t = [];
      this.minBuyPrice = 5e5;
      for (
        var a = this.tubesPanel1.buyBtn,
          n = 0,
          i = this.tubesPanel1.shopItems.length;
        n < i;

      ) {
        var s = n++;
        PlayerPrefs.GetBool(
          _$MainManager_ShopCategory_$Impl_$.ToString(
            this.tubesPanel1.shopItems[s].shopCategory
          ) + this.tubesPanel1.shopItems[s].itemNum,
          this.tubesPanel1.shopItems[s].defaultLocked
        ) && t.push(this.tubesPanel1.shopItems[s]);
      }
      if (0 == t.length)
        return (
          (this.tubesPanel1.buyBtn.button.active = !1),
          void (this.tubesPanel1.buyPriceText.element.text =
            "" +
            this.tubesPanel1.buyPrices[this.tubesPanel1.buyPrices.length - 1])
        );
      (e = this.tubesPanel1.buyPrices[9 - t.length]),
        this.minBuyPrice >= e && (this.minBuyPrice = e);
      var r = PlayerPrefs.GetFloat("Currency_1", 0);
      (this.tubesPanel1.buyBtn.button.active = r >= e),
        (this.tubesPanel1.buyPriceText.element.text = "" + e),
        this.RandBuyListner(t, a, e);
    }
    TubesPanel2Check() {
      for (
        var e = [],
          t = 0,
          a = (this.tubesPanel2.buyBtn, 0),
          n = this.tubesPanel2.shopItems.length;
        a < n;

      ) {
        var i = a++;
        PlayerPrefs.GetBool(
          _$MainManager_ShopCategory_$Impl_$.ToString(
            this.tubesPanel2.shopItems[i].shopCategory
          ) + this.tubesPanel2.shopItems[i].itemNum,
          this.tubesPanel2.shopItems[i].defaultLocked
        ) && e.push(this.tubesPanel2.shopItems[i]);
      }
      if (e.length > 0) {
        (t = this.tubesPanel2.buyPrices[9 - e.length]),
          this.minBuyPrice >= t && (this.minBuyPrice = t);
        var s = PlayerPrefs.GetFloat("Currency_1", 0);
        (this.tubesPanel2.buyBtn.button.active = s >= t),
          (this.tubesPanel2.buyPriceText.element.text = "" + t);
      } else
        (this.tubesPanel2.buyBtn.button.active = !1),
          (this.tubesPanel2.buyPriceText.element.text =
            "" +
            this.tubesPanel2.buyPrices[this.tubesPanel2.buyPrices.length - 1]);
    }
    UI_TubesPanel2_BuyBtn() {
      for (
        var e,
          t = [],
          a = this.tubesPanel2.buyBtn,
          n = 0,
          i = this.tubesPanel2.shopItems.length;
        n < i;

      ) {
        var s = n++;
        PlayerPrefs.GetBool(
          _$MainManager_ShopCategory_$Impl_$.ToString(
            this.tubesPanel2.shopItems[s].shopCategory
          ) + this.tubesPanel2.shopItems[s].itemNum,
          this.tubesPanel2.shopItems[s].defaultLocked
        ) && t.push(this.tubesPanel2.shopItems[s]);
      }
      if (0 == t.length)
        return (
          (this.tubesPanel2.buyBtn.button.active = !1),
          void (this.tubesPanel2.buyPriceText.element.text =
            "" +
            this.tubesPanel2.buyPrices[this.tubesPanel2.buyPrices.length - 1])
        );
      (e = this.tubesPanel2.buyPrices[9 - t.length]),
        this.minBuyPrice >= e && (this.minBuyPrice = e);
      var r = PlayerPrefs.GetFloat("Currency_1", 0);
      (this.tubesPanel2.buyBtn.button.active = r >= e),
        (this.tubesPanel2.buyPriceText.element.text = "" + e),
        this.RandBuyListner(t, a, e);
    }
    ThemesPanel1Check() {
      for (
        var e = [],
          t = 0,
          a = this.themePanel1.buyBtn,
          n = this,
          i = 0,
          s = this.themePanel1.shopItems.length;
        i < s;

      ) {
        var r = i++;
        PlayerPrefs.GetBool(
          _$MainManager_ShopCategory_$Impl_$.ToString(
            this.themePanel1.shopItems[r].shopCategory
          ) + this.themePanel1.shopItems[r].itemNum,
          this.themePanel1.shopItems[r].defaultLocked
        ) && e.push(this.themePanel1.shopItems[r]);
      }
      if (e.length > 0) {
        (t = this.themePanel1.buyPrices[9 - e.length]),
          this.minBuyPrice >= t && (this.minBuyPrice = t);
        var o = PlayerPrefs.GetFloat("Currency_1", 0);
        (this.themePanel1.buyBtn.button.active = o >= t),
          (this.themePanel1.buyPriceText.element.text = "" + t),
          UIHelper.RemoveAllButtonClickHandlers(this.themePanel1.buyBtn),
          UIHelper.AddButtonClickHandler(this.themePanel1.buyBtn, function () {
            n.RandBuyListner(e, a, t);
          });
      } else
        (this.themePanel1.buyBtn.button.active = !1),
          (this.themePanel1.buyPriceText.element.text =
            "" +
            this.themePanel1.buyPrices[this.themePanel1.buyPrices.length - 1]);
    }
    ThemesPanel2Check() {
      for (
        var e = [],
          t = 0,
          a = this.themePanel2.buyBtn,
          n = this,
          i = 0,
          s = this.themePanel2.shopItems.length;
        i < s;

      ) {
        var r = i++;
        PlayerPrefs.GetBool(
          _$MainManager_ShopCategory_$Impl_$.ToString(
            this.themePanel2.shopItems[r].shopCategory
          ) + this.themePanel2.shopItems[r].itemNum,
          this.themePanel2.shopItems[r].defaultLocked
        ) && e.push(this.themePanel2.shopItems[r]);
      }
      if (e.length > 0) {
        (t = this.themePanel2.buyPrices[9 - e.length]),
          this.minBuyPrice >= t && (this.minBuyPrice = t);
        var o = PlayerPrefs.GetFloat("Currency_1", 0);
        (this.themePanel2.buyBtn.button.active = o >= t),
          (this.themePanel2.buyPriceText.element.text = "" + t),
          UIHelper.RemoveAllButtonClickHandlers(this.themePanel2.buyBtn),
          UIHelper.AddButtonClickHandler(this.themePanel2.buyBtn, function () {
            n.RandBuyListner(e, a, t);
          });
      } else
        (this.themePanel2.buyBtn.button.active = !1),
          (this.themePanel2.buyPriceText.element.text =
            "" +
            this.themePanel2.buyPrices[this.themePanel2.buyPrices.length - 1]);
      this.CanBuyShopItem();
    }
    CapsPanel1Check() {
      for (
        var e = [],
          t = 0,
          a = this.capPanel1.buyBtn,
          n = this,
          i = 0,
          s = this.capPanel1.shopItems.length;
        i < s;

      ) {
        var r = i++;
        PlayerPrefs.GetBool(
          _$MainManager_ShopCategory_$Impl_$.ToString(
            this.capPanel1.shopItems[r].shopCategory
          ) + this.capPanel1.shopItems[r].itemNum,
          this.capPanel1.shopItems[r].defaultLocked
        ) && e.push(this.capPanel1.shopItems[r]);
      }
      if (e.length > 0) {
        (t = this.capPanel1.buyPrices[9 - e.length]),
          this.minBuyPrice >= t && (this.minBuyPrice = t);
        var o = PlayerPrefs.GetFloat("Currency_1", 0);
        (this.capPanel1.buyBtn.button.active = o >= t),
          (this.capPanel1.buyPriceText.element.text = "" + t),
          UIHelper.RemoveAllButtonClickHandlers(this.capPanel1.buyBtn),
          UIHelper.AddButtonClickHandler(this.capPanel1.buyBtn, function () {
            n.RandBuyListner(e, a, t);
          });
      } else
        (this.capPanel1.buyBtn.button.active = !1),
          (this.capPanel1.buyPriceText.element.text =
            "" + this.capPanel1.buyPrices[this.capPanel1.buyPrices.length - 1]);
    }
    CapsPanel2Check() {
      for (
        var e = [],
          t = 0,
          a = this.capPanel2.buyBtn,
          n = this,
          i = 0,
          s = this.capPanel2.shopItems.length;
        i < s;

      ) {
        var r = i++;
        PlayerPrefs.GetBool(
          _$MainManager_ShopCategory_$Impl_$.ToString(
            this.capPanel2.shopItems[r].shopCategory
          ) + this.capPanel2.shopItems[r].itemNum,
          this.capPanel2.shopItems[r].defaultLocked
        ) && e.push(this.capPanel2.shopItems[r]);
      }
      if (e.length > 0) {
        (t = this.capPanel2.buyPrices[9 - e.length]),
          this.minBuyPrice >= t && (this.minBuyPrice = t);
        var o = PlayerPrefs.GetFloat("Currency_1", 0);
        (this.capPanel2.buyBtn.button.active = o >= t),
          (this.capPanel2.buyPriceText.element.text = "" + t),
          UIHelper.RemoveAllButtonClickHandlers(this.capPanel2.buyBtn),
          UIHelper.AddButtonClickHandler(this.capPanel2.buyBtn, function () {
            n.RandBuyListner(e, a, t);
          });
      } else
        (this.capPanel2.buyBtn.button.active = !1),
          (this.capPanel2.buyPriceText.element.text =
            "" + this.capPanel2.buyPrices[this.capPanel2.buyPrices.length - 1]);
      this.CanBuyShopItem();
    }
    CanBuyShopItem() {
      this.minBuyPrice <= PlayerPrefs.GetFloat("Currency_1", 0)
        ? (this.shopBuyNotif.enabled = !0)
        : (this.shopBuyNotif.enabled = !1);
    }
    RandBuyListner(e, t, a) {
      null == a && (a = 1e3),
        MainManager.inst.PlayOneShot("BtnClick"),
        PlayerPrefs.GetFloat("Currency_1", 0) >= a &&
          ((t.button.active = !1),
          e.length > 0 && this.ShopBuyRandBtn(e, t, a));
    }
    ShopBuyRandBtn(e, t, a) {
      UIManager.currShopItem.ResetItem();
      for (
        var n = null, i = null, s = [], r = this, o = 0, l = e.length;
        o < l;

      ) {
        var u = o++;
        e[u].isLocked && s.push(e[u]);
      }
      var c = 0;
      motion_Actuate
        .timer(0.15)
        .repeat(5)
        .onRepeat(function () {
          if (!(c >= 5)) {
            var e = Math.floor(s.length * Math.random());
            if (((n = s[e]), null != i)) {
              var t = i.entity,
                o = _$Vector3_Vector3_$Impl_$.get_ONE();
              t.setLocalScale(o);
            }
            var l = n.entity,
              u = 1.2,
              h = 1.2,
              p = 1.2;
            null == p && (p = 0), null == h && (h = 0), null == u && (u = 0);
            var m = new pc.Vec3(u, h, p);
            if (
              (l.setLocalScale(m),
              MainManager.inst.PlayOneShot("ShopBoxPop"),
              (i = n),
              5 == (c += 1))
            ) {
              if (null != i) {
                var _ = i.entity,
                  d = _$Vector3_Vector3_$Impl_$.get_ONE();
                _.setLocalScale(d);
              }
              r.AddCurrency(-a),
                MainManager.inst.PlayOneShot("TubeUnlock"),
                n.UnlockItem(!0),
                r.TubesPanel1Check(),
                r.TubesPanel2Check(),
                r.ThemesPanel1Check(),
                r.ThemesPanel2Check(),
                r.CapsPanel1Check(),
                r.CapsPanel2Check();
            }
          }
        });
    }
    OnShopOpen() {
      this.isShopOpen = !0;
    }
    OnShopTubeOpen() {}
    OnShopWallpaperOpen() {}
    OnShopCapOpen() {}
    OnShopClose() {
      this.isShopOpen && ((this.isShopOpen = !1), (this.timeInShop = 0));
    }
    UI_Shop_RewardBtn(e) {
      if (
        (null == e && (e = 50),
        haxe_Log.trace("!!!UI_Shop_RewardBtn", {
          fileName: "src/UIManager.hx",
          lineNumber: 3048,
          className: "UIManager",
          methodName: "UI_Shop_RewardBtn",
        }),
        "VideoReward" != UIManager.lastBtnPressed)
      ) {
        (UIManager.lastBtnPressed = "VideoReward"),
          MainManager.inst.PlayOneShot("BtnClick");
        var t = this;
        null != APIManager.inst
          ? APIManager.ShowRewardedAD(function (e) {
              e
                ? motion_Actuate
                    .timer(0.1)
                    .onComplete($bind(t, t.ShopVideoReward))
                : (UIManager.lastBtnPressed = "");
            }, "button.shop.getmoney")
          : (haxe_Log.trace("AdsManager not found", {
              fileName: "src/UIManager.hx",
              lineNumber: 3072,
              className: "UIManager",
              methodName: "UI_Shop_RewardBtn",
            }),
            (UIManager.lastBtnPressed = ""));
      }
    }
    ShopVideoReward() {
      (UIManager.lastBtnPressed = ""),
        (EntityHelper.GetComponent_CoinsCollector(
          this.shopAdCcB,
          CoinsCollector
        ).totalCoinsToAdd = 50),
        (this.shopAdCcB.enabled = !0);
    }
    update(e) {
      super.update(e),
        this.levelBtnClickBlockFramesLeft > 0 &&
          this.levelBtnClickBlockFramesLeft--;
    }
    static get_RemainingMoves() {
      return (UIManager.inst.totalMoves - UIManager.inst.movesUsed) | 0;
    }
    static IsPointerOverUIElement() {
      return !1;
    }
    static GoToNextLevel() {
      UIManager.GoToLevel(PlayerPrefs.GetInt("CurrLvlNum", 1) + 1);
    }
    static GoToPreviousLevel() {
      UIManager.GoToLevel(PlayerPrefs.GetInt("CurrLvlNum", 1) - 1);
    }
    static GoToLevel(e) {
      UIManager.isGameplaying &&
        (e < 1 && (e = 1),
        PlayerPrefs.SetInt("CurrLvlNum", e),
        PlayerPrefs.SetInt(
          "Mode_" + GameManager.currModeNum + "_LvlUnlocked",
          e
        ),
        MainManager.inst.LoadLevel(!1));
    }
  }
  (UIManager.__name__ = "UIManager"),
    (UIManager.__properties__ = { get_RemainingMoves: "get_RemainingMoves" }),
    (UIManager.__super__ = ScriptComponent),
    Object.assign(UIManager.prototype, { __class__: UIManager });
  class UIManagerClickBtn extends ScriptComponent {
    initialize() {
      super.initialize(),
        null == this.entity.button && this.entity.addComponent("button");
      var e = this;
      UIHelper.AddButtonClickHandler(this.entity, function () {
        null != e.famobiEventId &&
        "" != e.famobiEventId &&
        null != e.famobiPlacement &&
        "" != e.famobiPlacement
          ? APIManager.GameInterface.showInterstitialAd(
              e.famobiEventId,
              e.famobiPlacement
            ).then(function () {
              e.releaseAction();
            })
          : e.releaseAction();
      });
    }
    releaseAction() {
      if (null != this.Callbacks && this.Callbacks.length > 0)
        for (var e = 0, t = this.Callbacks; e < t.length; ) {
          var a = t[e];
          if ((++e, null != a.method && "" != a.method)) {
            var n = [];
            if (null != a.arguments && a.arguments.length > 0)
              for (var i = 0, s = a.arguments.length; i < s; ) {
                var r = i++,
                  o = a.arguments[r],
                  l = o;
                if (0 != o.indexOf(":")) {
                  var u = o.split(":");
                  "float" == u[0] && (l = parseFloat(u[1])),
                    "int" == u[0] && (l = Std.parseInt(u[1])),
                    "bool" == u[0] && (l = "1" == u[1] || "true" == u[1]);
                }
                n.push(l);
              }
            Reflect.field(UIManager.inst, a.method).apply(UIManager.inst, n);
          }
        }
      if (null != this.SetActiveCalls && this.SetActiveCalls.length > 0)
        for (var c = 0, h = this.SetActiveCalls; c < h.length; ) {
          var p = h[c];
          ++c, null != p.entity && (p.entity.enabled = p.enabled);
        }
    }
  }
  (UIManagerClickBtn.__name__ = "UIManagerClickBtn"),
    (UIManagerClickBtn.__super__ = ScriptComponent),
    Object.assign(UIManagerClickBtn.prototype, {
      __class__: UIManagerClickBtn,
    });
  class WinScreen extends ScriptComponent {
    initialize() {
      WinScreen.inst = this;
      this.getChildByName("PreLevelBtn");
      var e = this.getChildByName("NextLevelBtn"),
        t = this.getChildByName("RestartBtn"),
        a = this;
      null != e &&
        UIHelper.AddButtonClickHandler(e, function () {
          UIManager.GoToNextLevel(), (a.entity.enabled = !1);
        }),
        null != t &&
          UIHelper.AddButtonClickHandler(t, function () {
            MainManager.inst.LoadLevel(!1), (a.entity.enabled = !1);
          }),
        (this.entity.enabled = !1);
    }
    static Activate() {
      WinScreen.isActivating ||
        ((WinScreen.isActivating = !0),
        motion_Actuate.timer(1).onComplete(function () {
          (WinScreen.isActivating = !1), (WinScreen.inst.entity.enabled = !0);
        }));
    }
  }
  (WinScreen.__name__ = "WinScreen"),
    (WinScreen.__super__ = ScriptComponent),
    Object.assign(WinScreen.prototype, { __class__: WinScreen });
  class YoutubeDisabler extends ScriptComponent {
    initialize() {
      if ((super.initialize(), !APIManager.HasFeature("rewarded"))) {
        (this.entity.enabled = !1),
          null != this.entity.element && (this.entity.element.enabled = !1);
        var e = this.entity,
          t = e.getLocalPosition().clone(),
          a = 1e5,
          n = 1e5,
          i = 0;
        null == i && (i = 0), null == n && (n = 0), null == a && (a = 0);
        var s = new pc.Vec3(a, n, i),
          r = new pc.Vec3(t.x + s.x, t.y + s.y, t.z + s.z);
        e.setLocalPosition(r);
      }
    }
  }
  (YoutubeDisabler.__name__ = "YoutubeDisabler"),
    (YoutubeDisabler.__super__ = ScriptComponent),
    Object.assign(YoutubeDisabler.prototype, { __class__: YoutubeDisabler });
  class haxe_IMap {}
  (haxe_IMap.__name__ = "haxe.IMap"), (haxe_IMap.__isInterface__ = !0);
  class haxe_Log {
    static formatOutput(e, t) {
      var a = Std.string(e);
      if (null == t) return a;
      var n = t.fileName + ":" + t.lineNumber;
      if (null != t.customParams)
        for (var i = 0, s = t.customParams; i < s.length; ) {
          var r = s[i];
          ++i, (a += ", " + Std.string(r));
        }
      return n + ": " + a;
    }
    static trace(e, t) {
      var a = haxe_Log.formatOutput(e, t);
      "undefined" != typeof console && null != console.log && console.log(a);
    }
  }
  haxe_Log.__name__ = "haxe.Log";
  class haxe_ds_ObjectMap {
    constructor() {
      this.h = { __keys__: {} };
    }
    set(e, t) {
      var a = e.__id__ || (e.__id__ = $global.$haxeUID++);
      (this.h[a] = t), (this.h.__keys__[a] = e);
    }
    remove(e) {
      var t = e.__id__;
      return (
        null != this.h.__keys__[t] &&
        (delete this.h[t], delete this.h.__keys__[t], !0)
      );
    }
    keys() {
      var e = [];
      for (var t in this.h.__keys__)
        this.h.hasOwnProperty(t) && e.push(this.h.__keys__[t]);
      return HxOverrides.iter(e);
    }
    iterator() {
      return {
        ref: this.h,
        it: this.keys(),
        hasNext: function () {
          return this.it.hasNext();
        },
        next: function () {
          var e = this.it.next();
          return this.ref[e.__id__];
        },
      };
    }
  }
  (haxe_ds_ObjectMap.__name__ = "haxe.ds.ObjectMap"),
    (haxe_ds_ObjectMap.__interfaces__ = [haxe_IMap]),
    Object.assign(haxe_ds_ObjectMap.prototype, {
      __class__: haxe_ds_ObjectMap,
    });
  class haxe_ds_StringMap {
    constructor() {
      this.h = {};
    }
    setReserved(e, t) {
      null == this.rh && (this.rh = {}), (this.rh["$" + e] = t);
    }
    getReserved(e) {
      return null == this.rh ? null : this.rh["$" + e];
    }
    existsReserved(e) {
      return null != this.rh && this.rh.hasOwnProperty("$" + e);
    }
  }
  (haxe_ds_StringMap.__name__ = "haxe.ds.StringMap"),
    (haxe_ds_StringMap.__interfaces__ = [haxe_IMap]),
    Object.assign(haxe_ds_StringMap.prototype, {
      __class__: haxe_ds_StringMap,
    });
  class js__$Boot_HaxeError extends Error {
    constructor(e) {
      super(),
        (this.val = e),
        Error.captureStackTrace &&
          Error.captureStackTrace(this, js__$Boot_HaxeError);
    }
  }
  (js__$Boot_HaxeError.__name__ = "js._Boot.HaxeError"),
    (js__$Boot_HaxeError.__super__ = Error),
    Object.assign(js__$Boot_HaxeError.prototype, {
      __class__: js__$Boot_HaxeError,
    });
  class js_Boot {
    static getClass(e) {
      if (null == e) return null;
      if (e instanceof Array) return Array;
      var t = e.__class__;
      if (null != t) return t;
      var a = js_Boot.__nativeClassName(e);
      return null != a ? js_Boot.__resolveNativeClass(a) : null;
    }
    static __string_rec(e, t) {
      if (null == e) return "null";
      if (t.length >= 5) return "<...>";
      var a = typeof e;
      switch (
        ("function" == a && (e.__name__ || e.__ename__) && (a = "object"), a)
      ) {
        case "function":
          return "<function>";
        case "object":
          if (e.__enum__) {
            var n = $hxEnums[e.__enum__],
              i = n.__constructs__[e._hx_index],
              s = n[i];
            return s.__params__
              ? ((t += "\t"),
                i +
                  "(" +
                  (function (a) {
                    for (var n = [], i = 0, r = s.__params__; i < r.length; ) {
                      var o = r[i];
                      (i += 1), n.push(js_Boot.__string_rec(e[o], t));
                    }
                    return n;
                  })().join(",") +
                  ")")
              : i;
          }
          if (e instanceof Array) {
            var r = "[";
            t += "\t";
            for (var o = 0, l = e.length; o < l; ) {
              var u = o++;
              r += (u > 0 ? "," : "") + js_Boot.__string_rec(e[u], t);
            }
            return (r += "]");
          }
          var c;
          try {
            c = e.toString;
          } catch (e) {
            e instanceof js__$Boot_HaxeError && e.val;
            return "???";
          }
          if (null != c && c != Object.toString && "function" == typeof c) {
            var h = e.toString();
            if ("[object Object]" != h) return h;
          }
          var p = "{\n";
          t += "\t";
          var m = null != e.hasOwnProperty,
            _ = null;
          for (_ in e)
            (m && !e.hasOwnProperty(_)) ||
              ("prototype" != _ &&
                "__class__" != _ &&
                "__super__" != _ &&
                "__interfaces__" != _ &&
                "__properties__" != _ &&
                (2 != p.length && (p += ", \n"),
                (p += t + _ + " : " + js_Boot.__string_rec(e[_], t))));
          return (p += "\n" + (t = t.substring(1)) + "}");
        case "string":
          return e;
        default:
          return String(e);
      }
    }
    static __interfLoop(e, t) {
      if (null == e) return !1;
      if (e == t) return !0;
      if (Object.prototype.hasOwnProperty.call(e, "__interfaces__"))
        for (var a = e.__interfaces__, n = 0, i = a.length; n < i; ) {
          var s = a[n++];
          if (s == t || js_Boot.__interfLoop(s, t)) return !0;
        }
      return js_Boot.__interfLoop(e.__super__, t);
    }
    static __instanceof(e, t) {
      if (null == t) return !1;
      switch (t) {
        case Array:
          return e instanceof Array;
        case Bool:
          return "boolean" == typeof e;
        case Dynamic:
          return null != e;
        case Float:
          return "number" == typeof e;
        case Int:
          return "number" == typeof e && (0 | e) === e;
        case String:
          return "string" == typeof e;
        default:
          if (null == e) return !1;
          if ("function" == typeof t) {
            if (js_Boot.__downcastCheck(e, t)) return !0;
          } else if (
            "object" == typeof t &&
            js_Boot.__isNativeObj(t) &&
            e instanceof t
          )
            return !0;
          return (
            (t == Class && null != e.__name__) ||
            (t == Enum && null != e.__ename__) ||
            (null != e.__enum__ && $hxEnums[e.__enum__] == t)
          );
      }
    }
    static __downcastCheck(e, t) {
      return (
        e instanceof t ||
        (!!t.__isInterface__ && js_Boot.__interfLoop(js_Boot.getClass(e), t))
      );
    }
    static __implements(e, t) {
      return js_Boot.__interfLoop(js_Boot.getClass(e), t);
    }
    static __cast(e, t) {
      if (null == e || js_Boot.__instanceof(e, t)) return e;
      throw new js__$Boot_HaxeError(
        "Cannot cast " + Std.string(e) + " to " + Std.string(t)
      );
    }
    static __nativeClassName(e) {
      var t = js_Boot.__toStr.call(e).slice(8, -1);
      return "Object" == t || "Function" == t || "Math" == t || "JSON" == t
        ? null
        : t;
    }
    static __isNativeObj(e) {
      return null != js_Boot.__nativeClassName(e);
    }
    static __resolveNativeClass(e) {
      return $global[e];
    }
  }
  js_Boot.__name__ = "js.Boot";
  class motion_actuators_IGenericActuator {}
  (motion_actuators_IGenericActuator.__name__ =
    "motion.actuators.IGenericActuator"),
    (motion_actuators_IGenericActuator.__isInterface__ = !0),
    Object.assign(motion_actuators_IGenericActuator.prototype, {
      __class__: motion_actuators_IGenericActuator,
    });
  class motion_actuators_GenericActuator {
    constructor(e, t, a) {
      motion_actuators_GenericActuator._hx_skip_constructor ||
        this._hx_constructor(e, t, a);
    }
    _hx_constructor(e, t, a) {
      (this._autoVisible = !0),
        (this._delay = 0),
        (this._reflect = !1),
        (this._repeat = 0),
        (this._reverse = !1),
        (this._smartRotation = !1),
        (this._snapping = !1),
        (this.special = !1),
        (this.target = e),
        (this.properties = a),
        (this.duration = t),
        (this._ease = motion_Actuate.defaultEase);
    }
    apply() {
      for (var e = 0, t = Reflect.fields(this.properties); e < t.length; ) {
        var a = t[e];
        ++e,
          Object.prototype.hasOwnProperty.call(this.target, a)
            ? (this.target[a] = Reflect.field(this.properties, a))
            : Reflect.setProperty(
                this.target,
                a,
                Reflect.field(this.properties, a)
              );
      }
    }
    autoVisible(e) {
      return null == e && (e = !0), (this._autoVisible = e), this;
    }
    callMethod(e, t) {
      return null == t && (t = []), e.apply(e, t);
    }
    change() {
      if (null != this._onUpdate) {
        var e = this._onUpdate,
          t = this._onUpdateParams;
        null == t && (t = []), e.apply(e, t);
      }
    }
    complete(e) {
      if (
        (null == e && (e = !0), e && (this.change(), null != this._onComplete))
      ) {
        var t = this._onComplete,
          a = this._onCompleteParams;
        null == a && (a = []), t.apply(t, a);
      }
      motion_Actuate.unload(this);
    }
    delay(e) {
      return (this._delay = e), this;
    }
    ease(e) {
      return (this._ease = e), this;
    }
    move() {}
    onComplete(e, t) {
      return (
        (this._onComplete = e),
        (this._onCompleteParams = null == t ? [] : t),
        0 == this.duration && this.complete(),
        this
      );
    }
    onRepeat(e, t) {
      return (
        (this._onRepeat = e), (this._onRepeatParams = null == t ? [] : t), this
      );
    }
    onUpdate(e, t) {
      return (
        (this._onUpdate = e), (this._onUpdateParams = null == t ? [] : t), this
      );
    }
    onPause(e, t) {
      return (
        (this._onPause = e), (this._onPauseParams = null == t ? [] : t), this
      );
    }
    onResume(e, t) {
      return (
        (this._onResume = e), (this._onResumeParams = null == t ? [] : t), this
      );
    }
    pause() {
      if (null != this._onPause) {
        var e = this._onPause,
          t = this._onPauseParams;
        null == t && (t = []), e.apply(e, t);
      }
    }
    reflect(e) {
      return (
        null == e && (e = !0), (this._reflect = e), (this.special = !0), this
      );
    }
    repeat(e) {
      return null == e && (e = -1), (this._repeat = e), this;
    }
    resume() {
      if (null != this._onResume) {
        var e = this._onResume,
          t = this._onResumeParams;
        null == t && (t = []), e.apply(e, t);
      }
    }
    reverse(e) {
      return (
        null == e && (e = !0), (this._reverse = e), (this.special = !0), this
      );
    }
    smartRotation(e) {
      return (
        null == e && (e = !0),
        (this._smartRotation = e),
        (this.special = !0),
        this
      );
    }
    snapping(e) {
      return (
        null == e && (e = !0), (this._snapping = e), (this.special = !0), this
      );
    }
    stop(e, t, a) {}
  }
  (motion_actuators_GenericActuator.__name__ =
    "motion.actuators.GenericActuator"),
    (motion_actuators_GenericActuator.__interfaces__ = [
      motion_actuators_IGenericActuator,
    ]),
    Object.assign(motion_actuators_GenericActuator.prototype, {
      __class__: motion_actuators_GenericActuator,
    });
  class motion_actuators_SimpleActuator extends motion_actuators_GenericActuator {
    constructor(e, t, a) {
      motion_actuators_GenericActuator._hx_skip_constructor
        ? super()
        : ((motion_actuators_GenericActuator._hx_skip_constructor = !0),
          super(),
          (motion_actuators_GenericActuator._hx_skip_constructor = !1),
          this._hx_constructor(e, t, a));
    }
    _hx_constructor(e, t, a) {
      (this.active = !0),
        (this.propertyDetails = []),
        (this.sendChange = !1),
        (this.paused = !1),
        (this.cacheVisible = !1),
        (this.initialized = !1),
        (this.setVisible = !1),
        (this.toggleVisible = !1),
        (this.startTime = window.performance.now() / 1e3),
        super._hx_constructor(e, t, a),
        motion_actuators_SimpleActuator.addedEvent ||
          ((motion_actuators_SimpleActuator.addedEvent = !0),
          window.requestAnimationFrame(
            motion_actuators_SimpleActuator.stage_onEnterFrame
          ));
    }
    reverse(e) {
      var t,
        a = super.reverse(e);
      return (t = window.performance.now() / 1e3), this.update(t), a;
    }
    apply() {
      if (
        (super.apply(),
        this.toggleVisible &&
          Object.prototype.hasOwnProperty.call(this.properties, "alpha"))
      ) {
        var e = this.target;
        if (
          null !=
          (Object.prototype.hasOwnProperty.call(e, "visible")
            ? Reflect.field(e, "visible")
            : Reflect.getProperty(e, "visible"))
        ) {
          var t = this.target,
            a = Reflect.field(this.properties, "alpha") > 0;
          !Object.prototype.hasOwnProperty.call(t, "visible") ||
          (t.__properties__ && t.__properties__.set_visible)
            ? Reflect.setProperty(t, "visible", a)
            : (t.visible = a);
        }
      }
    }
    autoVisible(e) {
      if (
        (null == e && (e = !0),
        (this._autoVisible = e),
        !e && ((this.toggleVisible = !1), this.setVisible))
      ) {
        var t = this.target,
          a = this.cacheVisible;
        !Object.prototype.hasOwnProperty.call(t, "visible") ||
        (t.__properties__ && t.__properties__.set_visible)
          ? Reflect.setProperty(t, "visible", a)
          : (t.visible = a);
      }
      return this;
    }
    delay(e) {
      return (this._delay = e), (this.timeOffset = this.startTime + e), this;
    }
    getField(e, t) {
      return Object.prototype.hasOwnProperty.call(e, t)
        ? Reflect.field(e, t)
        : Reflect.getProperty(e, t);
    }
    initialize() {
      for (
        var e, t, a = 0, n = Reflect.fields(this.properties);
        a < n.length;

      ) {
        var i = n[a];
        ++a;
        var s = !0;
        if (
          (!Object.prototype.hasOwnProperty.call(this.target, i) ||
          (this.target.__properties__ && this.target.__properties__["set_" + i])
            ? ((s = !1), (t = Reflect.getProperty(this.target, i)))
            : (t = Reflect.field(this.target, i)),
          "number" == typeof t)
        ) {
          var r = this.properties,
            o = Object.prototype.hasOwnProperty.call(r, i)
              ? Reflect.field(r, i)
              : Reflect.getProperty(r, i);
          null == t && (t = 0),
            null == o && (o = 0),
            (e = new motion_actuators_PropertyDetails(
              this.target,
              i,
              t,
              o - t,
              s
            )),
            this.propertyDetails.push(e);
        }
      }
      (this.detailsLength = this.propertyDetails.length),
        (this.initialized = !0);
    }
    move() {
      var e;
      if (
        ((this.toggleVisible =
          Object.prototype.hasOwnProperty.call(this.properties, "alpha") &&
          Object.prototype.hasOwnProperty.call(this.properties, "visible")),
        this.toggleVisible && 0 != this.properties.alpha)
      ) {
        var t = this.target;
        e = !(Object.prototype.hasOwnProperty.call(t, "visible")
          ? Reflect.field(t, "visible")
          : Reflect.getProperty(t, "visible"));
      } else e = !1;
      if (e) {
        this.setVisible = !0;
        var a = this.target,
          n = null;
        (n = Object.prototype.hasOwnProperty.call(a, "visible")
          ? Reflect.field(a, "visible")
          : Reflect.getProperty(a, "visible")),
          (this.cacheVisible = n);
        var i = this.target;
        !Object.prototype.hasOwnProperty.call(i, "visible") ||
        (i.__properties__ && i.__properties__.set_visible)
          ? Reflect.setProperty(i, "visible", true)
          : (i.visible = true);
      }
      (this.timeOffset = this.startTime),
        motion_actuators_SimpleActuator.actuators.push(this),
        ++motion_actuators_SimpleActuator.actuatorsLength;
    }
    onUpdate(e, t) {
      return (
        (this._onUpdate = e),
        (this._onUpdateParams = null == t ? [] : t),
        (this.sendChange = !0),
        this
      );
    }
    pause() {
      this.paused ||
        ((this.paused = !0),
        super.pause(),
        (this.pauseTime = window.performance.now()));
    }
    resume() {
      this.paused &&
        ((this.paused = !1),
        (this.timeOffset += (window.performance.now() - this.pauseTime) / 1e3),
        super.resume());
    }
    setField(e, t, a) {
      !Object.prototype.hasOwnProperty.call(e, t) ||
      (e.__properties__ && e.__properties__["set_" + t])
        ? Reflect.setProperty(e, t, a)
        : (e[t] = a);
    }
    setProperty(e, t) {
      e.isField
        ? (e.target[e.propertyName] = t)
        : Reflect.setProperty(e.target, e.propertyName, t);
    }
    stop(e, t, a) {
      if (this.active) {
        if (null == e)
          return (this.active = !1), t && this.apply(), void this.complete(a);
        for (var n = 0, i = Reflect.fields(e); n < i.length; ) {
          var s = i[n];
          if ((++n, Object.prototype.hasOwnProperty.call(this.properties, s)))
            return (this.active = !1), t && this.apply(), void this.complete(a);
        }
      }
    }
    update(e) {
      if (!this.paused) {
        var t,
          a,
          n = (e - this.timeOffset) / this.duration;
        if (
          (n > 1 && (n = 1),
          this.initialized || this.initialize(),
          this.special)
        ) {
          var i;
          a = this._reverse
            ? this._ease.calculate(1 - n)
            : this._ease.calculate(n);
          for (var s = 0, r = this.detailsLength; s < r; ) {
            var o = s++;
            if (
              ((t = this.propertyDetails[o]),
              !this._smartRotation ||
                ("rotation" != t.propertyName &&
                  "rotationX" != t.propertyName &&
                  "rotationY" != t.propertyName &&
                  "rotationZ" != t.propertyName))
            )
              i = t.start + t.change * a;
            else {
              var l = t.change % 360;
              l > 180 ? (l -= 360) : l < -180 && (l += 360),
                (i = t.start + l * a);
            }
            this._snapping
              ? this.setProperty(t, Math.round(i))
              : this.setProperty(t, i);
          }
        } else {
          a = this._ease.calculate(n);
          for (var u = 0, c = this.detailsLength; u < c; ) {
            var h = u++;
            (t = this.propertyDetails[h]),
              this.setProperty(t, t.start + t.change * a);
          }
        }
        if (1 == n) {
          if (0 == this._repeat) {
            var p;
            if (((this.active = !1), this.toggleVisible)) {
              var m = this.target;
              p =
                0 ==
                (Object.prototype.hasOwnProperty.call(m, "alpha")
                  ? Reflect.field(m, "alpha")
                  : Reflect.getProperty(m, "alpha"));
            } else p = !1;
            if (p) {
              var _ = this.target;
              !Object.prototype.hasOwnProperty.call(_, "visible") ||
              (_.__properties__ && _.__properties__.set_visible)
                ? Reflect.setProperty(_, "visible", false)
                : (_.visible = false);
            }
            return void this.complete(!0);
          }
          if (null != this._onRepeat) {
            var d = this._onRepeat,
              g = this._onRepeatParams;
            null == g && (g = []), d.apply(d, g);
          }
          this._reflect && (this._reverse = !this._reverse),
            (this.startTime = e),
            (this.timeOffset = this.startTime + this._delay),
            this._repeat > 0 && this._repeat--;
        }
        this.sendChange && this.change();
      }
    }
    static stage_onEnterFrame(e) {
      for (
        var t,
          a = e / 1e3,
          n = 0,
          i = 0,
          s = motion_actuators_SimpleActuator.actuatorsLength;
        i < s;

      ) {
        i++;
        null != (t = motion_actuators_SimpleActuator.actuators[n]) && t.active
          ? (a >= t.timeOffset && t.update(a), ++n)
          : (motion_actuators_SimpleActuator.actuators.splice(n, 1),
            --motion_actuators_SimpleActuator.actuatorsLength);
      }
      window.requestAnimationFrame(
        motion_actuators_SimpleActuator.stage_onEnterFrame
      );
    }
  }
  (motion_actuators_SimpleActuator.__name__ =
    "motion.actuators.SimpleActuator"),
    (motion_actuators_SimpleActuator.__super__ =
      motion_actuators_GenericActuator),
    Object.assign(motion_actuators_SimpleActuator.prototype, {
      __class__: motion_actuators_SimpleActuator,
    });
  class motion_easing_IEasing {}
  (motion_easing_IEasing.__name__ = "motion.easing.IEasing"),
    (motion_easing_IEasing.__isInterface__ = !0),
    Object.assign(motion_easing_IEasing.prototype, {
      __class__: motion_easing_IEasing,
    });
  class motion_easing__$Expo_ExpoEaseIn {
    constructor() {}
    calculate(e) {
      return 0 == e ? 0 : Math.exp(6.931471805599453 * (e - 1));
    }
    ease(e, t, a, n) {
      return 0 == e ? t : a * Math.exp(6.931471805599453 * (e / n - 1)) + t;
    }
  }
  (motion_easing__$Expo_ExpoEaseIn.__name__ = "motion.easing._Expo.ExpoEaseIn"),
    (motion_easing__$Expo_ExpoEaseIn.__interfaces__ = [motion_easing_IEasing]),
    Object.assign(motion_easing__$Expo_ExpoEaseIn.prototype, {
      __class__: motion_easing__$Expo_ExpoEaseIn,
    });
  class motion_easing__$Expo_ExpoEaseInOut {
    constructor() {}
    calculate(e) {
      return 0 == e
        ? 0
        : 1 == e
        ? 1
        : (e /= 0.5) < 1
        ? 0.5 * Math.exp(6.931471805599453 * (e - 1))
        : 0.5 * (2 - Math.exp(-6.931471805599453 * --e));
    }
    ease(e, t, a, n) {
      return 0 == e
        ? t
        : e == n
        ? t + a
        : (e /= n / 2) < 1
        ? (a / 2) * Math.exp(6.931471805599453 * (e - 1)) + t
        : (a / 2) * (2 - Math.exp(-6.931471805599453 * --e)) + t;
    }
  }
  (motion_easing__$Expo_ExpoEaseInOut.__name__ =
    "motion.easing._Expo.ExpoEaseInOut"),
    (motion_easing__$Expo_ExpoEaseInOut.__interfaces__ = [
      motion_easing_IEasing,
    ]),
    Object.assign(motion_easing__$Expo_ExpoEaseInOut.prototype, {
      __class__: motion_easing__$Expo_ExpoEaseInOut,
    });
  class motion_easing__$Expo_ExpoEaseOut {
    constructor() {}
    calculate(e) {
      return 1 == e ? 1 : 1 - Math.exp(-6.931471805599453 * e);
    }
    ease(e, t, a, n) {
      return e == n
        ? t + a
        : a * (1 - Math.exp((-6.931471805599453 * e) / n)) + t;
    }
  }
  (motion_easing__$Expo_ExpoEaseOut.__name__ =
    "motion.easing._Expo.ExpoEaseOut"),
    (motion_easing__$Expo_ExpoEaseOut.__interfaces__ = [motion_easing_IEasing]),
    Object.assign(motion_easing__$Expo_ExpoEaseOut.prototype, {
      __class__: motion_easing__$Expo_ExpoEaseOut,
    });
  class motion_easing_Expo {}
  motion_easing_Expo.__name__ = "motion.easing.Expo";
  class motion_Actuate {
    static apply(e, t, a) {
      motion_Actuate.stop(e, t),
        null == a && (a = motion_Actuate.defaultActuator);
      var n = Type.createInstance(a, [e, 0, t]);
      return n.apply(), n;
    }
    static getLibrary(e, t) {
      return (
        null == t && (t = !0),
        null == motion_Actuate.targetLibraries.h.__keys__[e.__id__] &&
          t &&
          motion_Actuate.targetLibraries.set(e, []),
        motion_Actuate.targetLibraries.h[e.__id__]
      );
    }
    static isActive() {
      for (
        var e = !1, t = motion_Actuate.targetLibraries.iterator();
        t.hasNext();

      ) {
        t.next();
        e = !0;
        break;
      }
      return e;
    }
    static motionPath(e, t, a, n) {
      return (
        null == n && (n = !0),
        motion_Actuate.tween(e, t, a, n, motion_actuators_MotionPathActuator)
      );
    }
    static pause(e) {
      if (js_Boot.__implements(e, motion_actuators_IGenericActuator)) {
        e.pause();
      } else {
        var t = motion_Actuate.getLibrary(e, !1);
        if (null != t)
          for (var a = 0; a < t.length; ) {
            var n = t[a];
            ++a, n.pause();
          }
      }
    }
    static pauseAll() {
      for (var e = motion_Actuate.targetLibraries.iterator(); e.hasNext(); )
        for (var t = e.next(), a = 0; a < t.length; ) {
          var n = t[a];
          ++a, n.pause();
        }
    }
    static reset() {
      for (var e = motion_Actuate.targetLibraries.iterator(); e.hasNext(); )
        for (var t = e.next(), a = t.length - 1; a >= 0; )
          t[a].stop(null, !1, !1), --a;
      motion_Actuate.targetLibraries = new haxe_ds_ObjectMap();
    }
    static resume(e) {
      if (js_Boot.__implements(e, motion_actuators_IGenericActuator)) {
        e.resume();
      } else {
        var t = motion_Actuate.getLibrary(e, !1);
        if (null != t)
          for (var a = 0; a < t.length; ) {
            var n = t[a];
            ++a, n.resume();
          }
      }
    }
    static resumeAll() {
      for (var e = motion_Actuate.targetLibraries.iterator(); e.hasNext(); )
        for (var t = e.next(), a = 0; a < t.length; ) {
          var n = t[a];
          ++a, n.resume();
        }
    }
    static stop(e, t, a, n) {
      if ((null == n && (n = !0), null == a && (a = !1), null != e))
        if (js_Boot.__implements(e, motion_actuators_IGenericActuator)) {
          e.stop(null, a, n);
        } else {
          var i = motion_Actuate.getLibrary(e, !1);
          if (null != i) {
            if ("string" == typeof t) {
              var s = {};
              (s[t] = null), (t = s);
            } else if (t instanceof Array) {
              for (
                var r = {}, o = 0, l = js_Boot.__cast(t, Array);
                o < l.length;

              ) {
                var u = l[o];
                ++o, (r[u] = null);
              }
              t = r;
            }
            for (var c = i.length - 1; c >= 0; ) i[c].stop(t, a, n), --c;
          }
        }
    }
    static timer(e, t) {
      return motion_Actuate.tween(
        new motion__$Actuate_TweenTimer(0),
        e,
        new motion__$Actuate_TweenTimer(1),
        !1,
        t
      );
    }
    static tween(e, t, a, n, i) {
      if ((null == n && (n = !0), null != e)) {
        if (t > 0) {
          null == i && (i = motion_Actuate.defaultActuator);
          var s = Type.createInstance(i, [e, t, a]),
            r = motion_Actuate.getLibrary(s.target);
          if (n) {
            for (var o = r.length - 1; o >= 0; )
              r[o].stop(s.properties, !1, !1), --o;
            r = motion_Actuate.getLibrary(s.target);
          }
          return r.push(s), s.move(), s;
        }
        return motion_Actuate.apply(e, a, i);
      }
      return null;
    }
    static unload(e) {
      var t = e.target;
      null != motion_Actuate.targetLibraries.h.__keys__[t.__id__] &&
        (HxOverrides.remove(motion_Actuate.targetLibraries.h[t.__id__], e),
        0 == motion_Actuate.targetLibraries.h[t.__id__].length &&
          motion_Actuate.targetLibraries.remove(t));
    }
    static update(e, t, a, n, i) {
      null == i && (i = !0);
      var s = { start: a, end: n };
      return motion_Actuate.tween(e, t, s, i, motion_actuators_MethodActuator);
    }
  }
  motion_Actuate.__name__ = "motion.Actuate";
  class motion__$Actuate_TweenTimer {
    constructor(e) {
      this.progress = e;
    }
  }
  (motion__$Actuate_TweenTimer.__name__ = "motion._Actuate.TweenTimer"),
    Object.assign(motion__$Actuate_TweenTimer.prototype, {
      __class__: motion__$Actuate_TweenTimer,
    });
  class motion_MotionPath {
    constructor() {
      (this._x = new motion__$MotionPath_ComponentPath()),
        (this._y = new motion__$MotionPath_ComponentPath()),
        (this._rotation = null);
    }
    bezier(e, t, a, n, i) {
      return null == i && (i = 1), this.bezierN(e, t, [a], [n], i);
    }
    bezierN(e, t, a, n, i) {
      return (
        null == i && (i = 1),
        this._x.addPath(new motion__$MotionPath_BezierPath(e, a, i)),
        this._y.addPath(new motion__$MotionPath_BezierPath(t, n, i)),
        this
      );
    }
    bezierSpline(e, t, a) {
      return (
        null == a && (a = 1),
        this._x.addPath(new motion__$MotionPath_BezierSplinePath(e, a)),
        this._y.addPath(new motion__$MotionPath_BezierSplinePath(t, a)),
        this
      );
    }
    line(e, t, a) {
      return null == a && (a = 1), this.bezierN(e, t, [], [], a);
    }
    get_rotation() {
      return (
        null == this._rotation &&
          (this._rotation = new motion__$MotionPath_RotationPath(
            this._x,
            this._y
          )),
        this._rotation
      );
    }
    get_x() {
      return this._x;
    }
    get_y() {
      return this._y;
    }
  }
  (motion_MotionPath.__name__ = "motion.MotionPath"),
    Object.assign(motion_MotionPath.prototype, {
      __class__: motion_MotionPath,
      __properties__: {
        get_y: "get_y",
        get_x: "get_x",
        get_rotation: "get_rotation",
      },
    });
  class motion_IComponentPath {}
  (motion_IComponentPath.__name__ = "motion.IComponentPath"),
    (motion_IComponentPath.__isInterface__ = !0),
    Object.assign(motion_IComponentPath.prototype, {
      __class__: motion_IComponentPath,
      __properties__: {
        get_end: "get_end",
        set_start: "set_start",
        get_start: "get_start",
      },
    });
  class motion__$MotionPath_ComponentPath {
    constructor() {
      (this.paths = []), (this.strength = 0);
    }
    addPath(e) {
      this.paths.length > 0 &&
        e.set_start(this.paths[this.paths.length - 1].get_end()),
        this.paths.push(e),
        (this.strength += e.strength);
    }
    calculate(e) {
      if (1 == this.paths.length) return this.paths[0].calculate(e);
      for (var t = e * this.strength, a = 0, n = this.paths; a < n.length; ) {
        var i = n[a];
        if ((++a, !(t - i.strength > 1e-7))) return i.calculate(t / i.strength);
        t -= i.strength;
      }
      return 0;
    }
    get_start() {
      return this.paths.length > 0 ? this.paths[0].get_start() : 0;
    }
    set_start(e) {
      return this.paths.length > 0 ? this.paths[0].set_start(e) : 0;
    }
    get_end() {
      return this.paths.length > 0
        ? this.paths[this.paths.length - 1].get_end()
        : this.get_start();
    }
  }
  (motion__$MotionPath_ComponentPath.__name__ =
    "motion._MotionPath.ComponentPath"),
    (motion__$MotionPath_ComponentPath.__interfaces__ = [
      motion_IComponentPath,
    ]),
    Object.assign(motion__$MotionPath_ComponentPath.prototype, {
      __class__: motion__$MotionPath_ComponentPath,
      __properties__: {
        get_end: "get_end",
        set_start: "set_start",
        get_start: "get_start",
      },
    });
  class motion__$MotionPath_BezierPath {
    constructor(e, t, a) {
      (this._end = e), (this.control = t), (this.strength = a);
    }
    calculate(e) {
      var t = 1 - e;
      switch (this.control.length) {
        case 0:
          return t * this._start + e * this._end;
        case 1:
          return (
            t * t * this._start +
            2 * t * e * this.control[0] +
            e * e * this._end
          );
        case 2:
          return (
            t * t * t * this._start +
            3 * t * t * e * this.control[0] +
            3 * t * e * e * this.control[1] +
            e * e * e * this._end
          );
        default:
          if (t < 1e-7) return this._end;
          for (
            var a = e / t,
              n = this.control.length + 1,
              i = Math.pow(t, n),
              s = i * this._start,
              r = 1,
              o = n;
            r < o;

          ) {
            var l = r++;
            s += (i *= (a * (n + 1 - l)) / l) * this.control[l - 1];
          }
          return s + (i *= a / n) * this._end;
      }
    }
    get_start() {
      return this._start;
    }
    set_start(e) {
      return (this._start = e);
    }
    get_end() {
      return this._end;
    }
  }
  (motion__$MotionPath_BezierPath.__name__ = "motion._MotionPath.BezierPath"),
    (motion__$MotionPath_BezierPath.__interfaces__ = [motion_IComponentPath]),
    Object.assign(motion__$MotionPath_BezierPath.prototype, {
      __class__: motion__$MotionPath_BezierPath,
      __properties__: {
        get_end: "get_end",
        set_start: "set_start",
        get_start: "get_start",
      },
    });
  class motion__$MotionPath_BezierSplinePath extends motion__$MotionPath_ComponentPath {
    constructor(e, t) {
      super(), (this.through = e), (this.strength = t);
    }
    computeControlPoints(e) {
      for (
        var t = [e].concat(this.through), a = t.length, n = [], i = 0, s = a;
        i < s;

      ) {
        i++;
        n.push([0, 0]);
      }
      var r = n,
        o = [],
        l = [],
        u = [],
        c = [];
      (o[0] = 0), (l[0] = 2), (u[0] = 1), (c[0] = t[0] + 2 * t[1]);
      for (var h = 1, p = a - 1; h < p; ) {
        var m = h++;
        (o[m] = 1), (l[m] = 4), (u[m] = 1), (c[m] = 4 * t[m] + 2 * t[m + 1]);
      }
      (o[a - 1] = 1), (l[a - 1] = 2), (u[a - 1] = 0), (c[a - 1] = 3 * t[a - 1]);
      for (var _ = 1, d = a; _ < d; ) {
        var g = _++,
          y = o[g] / l[g - 1];
        (l[g] -= y * u[g - 1]), (c[g] -= y * c[g - 1]);
      }
      r[a - 1][0] = c[a - 1] / l[a - 1];
      for (var v = a - 2; v >= 0; )
        (r[v][0] = (c[v] - u[v] * r[v + 1][0]) / l[v]), --v;
      for (var b = 0, f = a - 1; b < f; ) {
        var S = b++;
        r[S][1] = 2 * t[S + 1] - r[S + 1][0];
      }
      return (r[a - 1][1] = 0.5 * (t[a] + r[a - 1][0])), r.pop(), r;
    }
    set_start(e) {
      if (0 == this.paths.length || Math.abs(e - this.get_start()) > 1e-7) {
        var t = this.computeControlPoints(e),
          a = this.strength / t.length;
        (this.strength = 0), this.paths.splice(0, this.paths.length);
        for (var n = 0, i = t.length; n < i; ) {
          var s = n++;
          this.addPath(
            new motion__$MotionPath_BezierPath(this.through[s], t[s], a)
          );
        }
      }
      return super.set_start(e);
    }
    get_end() {
      return this.through[this.through.length - 1];
    }
  }
  (motion__$MotionPath_BezierSplinePath.__name__ =
    "motion._MotionPath.BezierSplinePath"),
    (motion__$MotionPath_BezierSplinePath.__super__ =
      motion__$MotionPath_ComponentPath),
    Object.assign(motion__$MotionPath_BezierSplinePath.prototype, {
      __class__: motion__$MotionPath_BezierSplinePath,
    });
  class motion__$MotionPath_RotationPath {
    constructor(e, t) {
      (this.step = 0.01),
        (this._x = e),
        (this._y = t),
        (this.offset = 0),
        this.set_start(this.calculate(0));
    }
    calculate(e) {
      var t = this._x.calculate(e) - this._x.calculate(e + this.step),
        a = this._y.calculate(e) - this._y.calculate(e + this.step),
        n = Math.atan2(a, t) * (180 / Math.PI);
      return (n = (n + this.offset) % 360);
    }
    get_start() {
      return this._start;
    }
    set_start(e) {
      return this._start;
    }
    get_end() {
      return this.calculate(1);
    }
  }
  (motion__$MotionPath_RotationPath.__name__ =
    "motion._MotionPath.RotationPath"),
    (motion__$MotionPath_RotationPath.__interfaces__ = [motion_IComponentPath]),
    Object.assign(motion__$MotionPath_RotationPath.prototype, {
      __class__: motion__$MotionPath_RotationPath,
      __properties__: {
        set_start: "set_start",
        get_start: "get_start",
        get_end: "get_end",
      },
    });
  class motion_actuators_MethodActuator extends motion_actuators_SimpleActuator {
    constructor(e, t, a) {
      (motion_actuators_GenericActuator._hx_skip_constructor = !0),
        super(),
        (motion_actuators_GenericActuator._hx_skip_constructor = !1),
        this._hx_constructor(e, t, a);
    }
    _hx_constructor(e, t, a) {
      (this.currentParameters = []),
        (this.tweenProperties = {}),
        super._hx_constructor(e, t, a),
        Object.prototype.hasOwnProperty.call(a, "start") ||
          (this.properties.start = []),
        Object.prototype.hasOwnProperty.call(a, "end") ||
          (this.properties.end = this.properties.start);
      for (var n = 0, i = this.properties.start.length; n < i; ) {
        var s = n++;
        this.currentParameters.push(this.properties.start[s]);
      }
    }
    apply() {
      var e = this.target,
        t = this.properties.end;
      null == t && (t = []), e.apply(e, t);
    }
    complete(e) {
      if ((null == e && (e = !0), this.initialized)) {
        for (var t = 0, a = this.properties.start.length; t < a; ) {
          var n = t++;
          this.currentParameters[n] = Reflect.field(
            this.tweenProperties,
            "param" + n
          );
        }
        var i = this.target,
          s = this.currentParameters;
        null == s && (s = []), i.apply(i, s);
      }
      super.complete(e);
    }
    initialize() {
      for (var e, t, a, n = 0, i = this.properties.start.length; n < i; ) {
        var s = n++;
        (t = "param" + s),
          (a = this.properties.start[s]),
          (this.tweenProperties[t] = a),
          ("number" == typeof a || ("number" == typeof a && (0 | a) === a)) &&
            ((e = new motion_actuators_PropertyDetails(
              this.tweenProperties,
              t,
              a,
              this.properties.end[s] - a
            )),
            this.propertyDetails.push(e));
      }
      (this.detailsLength = this.propertyDetails.length),
        (this.initialized = !0);
    }
    update(e) {
      if ((super.update(e), this.active && !this.paused)) {
        for (var t = 0, a = this.properties.start.length; t < a; ) {
          var n = t++;
          this.currentParameters[n] = Reflect.field(
            this.tweenProperties,
            "param" + n
          );
        }
        var i = this.target,
          s = this.currentParameters;
        null == s && (s = []), i.apply(i, s);
      }
    }
  }
  (motion_actuators_MethodActuator.__name__ =
    "motion.actuators.MethodActuator"),
    (motion_actuators_MethodActuator.__super__ =
      motion_actuators_SimpleActuator),
    Object.assign(motion_actuators_MethodActuator.prototype, {
      __class__: motion_actuators_MethodActuator,
    });
  class motion_actuators_MotionPathActuator extends motion_actuators_SimpleActuator {
    constructor(e, t, a) {
      super(e, t, a);
    }
    apply() {
      for (var e = 0, t = Reflect.fields(this.properties); e < t.length; ) {
        var a = t[e];
        ++e,
          Object.prototype.hasOwnProperty.call(this.target, a)
            ? (this.target[a] = js_Boot
                .__cast(
                  Reflect.field(this.properties, a),
                  motion_IComponentPath
                )
                .get_end())
            : Reflect.setProperty(
                this.target,
                a,
                js_Boot
                  .__cast(
                    Reflect.field(this.properties, a),
                    motion_IComponentPath
                  )
                  .get_end()
              );
      }
    }
    initialize() {
      for (
        var e, t, a = 0, n = Reflect.fields(this.properties);
        a < n.length;

      ) {
        var i = n[a];
        if (
          (++a,
          null !=
            (t = js_Boot.__cast(
              Reflect.field(this.properties, i),
              motion_IComponentPath
            )))
        ) {
          var s = !0;
          Object.prototype.hasOwnProperty.call(this.target, i)
            ? t.set_start(Reflect.field(this.target, i))
            : ((s = !1), t.set_start(Reflect.getProperty(this.target, i))),
            (e = new motion_actuators_PropertyPathDetails(
              this.target,
              i,
              t,
              s
            )),
            this.propertyDetails.push(e);
        }
      }
      (this.detailsLength = this.propertyDetails.length),
        (this.initialized = !0);
    }
    update(e) {
      if (!this.paused) {
        var t,
          a = (e - this.timeOffset) / this.duration;
        if (
          (a > 1 && (a = 1),
          this.initialized || this.initialize(),
          this.special)
        ) {
          t = this._reverse
            ? this._ease.calculate(1 - a)
            : this._ease.calculate(a);
          for (var n = 0, i = this.propertyDetails; n < i.length; ) {
            var s = i[n];
            ++n,
              this._snapping
                ? s.isField
                  ? (s.target[s.propertyName] = Math.round(
                      js_Boot
                        .__cast(s, motion_actuators_PropertyPathDetails)
                        .path.calculate(t)
                    ))
                  : Reflect.setProperty(
                      s.target,
                      s.propertyName,
                      Math.round(
                        js_Boot
                          .__cast(s, motion_actuators_PropertyPathDetails)
                          .path.calculate(t)
                      )
                    )
                : s.isField
                ? (s.target[s.propertyName] = js_Boot
                    .__cast(s, motion_actuators_PropertyPathDetails)
                    .path.calculate(t))
                : Reflect.setProperty(
                    s.target,
                    s.propertyName,
                    js_Boot
                      .__cast(s, motion_actuators_PropertyPathDetails)
                      .path.calculate(t)
                  );
          }
        } else {
          t = this._ease.calculate(a);
          for (var r = 0, o = this.propertyDetails; r < o.length; ) {
            var l = o[r];
            ++r,
              l.isField
                ? (l.target[l.propertyName] = js_Boot
                    .__cast(l, motion_actuators_PropertyPathDetails)
                    .path.calculate(t))
                : Reflect.setProperty(
                    l.target,
                    l.propertyName,
                    js_Boot
                      .__cast(l, motion_actuators_PropertyPathDetails)
                      .path.calculate(t)
                  );
          }
        }
        if (1 == a) {
          if (0 == this._repeat) {
            var u;
            if (((this.active = !1), this.toggleVisible)) {
              var c = this.target;
              u =
                0 ==
                (Object.prototype.hasOwnProperty.call(c, "alpha")
                  ? Reflect.field(c, "alpha")
                  : Reflect.getProperty(c, "alpha"));
            } else u = !1;
            if (u) {
              var h = this.target;
              !Object.prototype.hasOwnProperty.call(h, "visible") ||
              (h.__properties__ && h.__properties__.set_visible)
                ? Reflect.setProperty(h, "visible", false)
                : (h.visible = false);
            }
            return void this.complete(!0);
          }
          if (null != this._onRepeat) {
            var p = this._onRepeat,
              m = this._onRepeatParams;
            null == m && (m = []), p.apply(p, m);
          }
          this._reflect && (this._reverse = !this._reverse),
            (this.startTime = e),
            (this.timeOffset = this.startTime + this._delay),
            this._repeat > 0 && this._repeat--;
        }
        this.sendChange && this.change();
      }
    }
  }
  (motion_actuators_MotionPathActuator.__name__ =
    "motion.actuators.MotionPathActuator"),
    (motion_actuators_MotionPathActuator.__super__ =
      motion_actuators_SimpleActuator),
    Object.assign(motion_actuators_MotionPathActuator.prototype, {
      __class__: motion_actuators_MotionPathActuator,
    });
  class motion_actuators_PropertyDetails {
    constructor(e, t, a, n, i) {
      null == i && (i = !0),
        (this.target = e),
        (this.propertyName = t),
        (this.start = a),
        (this.change = n),
        (this.isField = i);
    }
  }
  (motion_actuators_PropertyDetails.__name__ =
    "motion.actuators.PropertyDetails"),
    Object.assign(motion_actuators_PropertyDetails.prototype, {
      __class__: motion_actuators_PropertyDetails,
    });
  class motion_actuators_PropertyPathDetails extends motion_actuators_PropertyDetails {
    constructor(e, t, a, n) {
      null == n && (n = !0), super(e, t, 0, 0, n), (this.path = a);
    }
  }
  (motion_actuators_PropertyPathDetails.__name__ =
    "motion.actuators.PropertyPathDetails"),
    (motion_actuators_PropertyPathDetails.__super__ =
      motion_actuators_PropertyDetails),
    Object.assign(motion_actuators_PropertyPathDetails.prototype, {
      __class__: motion_actuators_PropertyPathDetails,
    });
  class motion_easing__$Back_BackEaseIn {
    constructor(e) {
      this.s = e;
    }
    calculate(e) {
      return e * e * ((this.s + 1) * e - this.s);
    }
    ease(e, t, a, n) {
      return a * (e /= n) * e * ((this.s + 1) * e - this.s) + t;
    }
  }
  (motion_easing__$Back_BackEaseIn.__name__ = "motion.easing._Back.BackEaseIn"),
    (motion_easing__$Back_BackEaseIn.__interfaces__ = [motion_easing_IEasing]),
    Object.assign(motion_easing__$Back_BackEaseIn.prototype, {
      __class__: motion_easing__$Back_BackEaseIn,
    });
  class motion_easing__$Back_BackEaseInOut {
    constructor(e) {
      this.s = e;
    }
    calculate(e) {
      if ((e /= 0.5) < 1) {
        return e * e * ((1 + (this.s *= 1.525)) * e - this.s) * 0.5;
      }
      return 0.5 * ((e -= 2) * e * ((1 + (this.s *= 1.525)) * e + this.s) + 2);
    }
    ease(e, t, a, n) {
      if ((e /= n / 2) < 1) {
        return (a / 2) * (e * e * ((1 + (this.s *= 1.525)) * e - this.s)) + t;
      }
      return (
        (a / 2) * ((e -= 2) * e * ((1 + (this.s *= 1.525)) * e + this.s) + 2) +
        t
      );
    }
  }
  (motion_easing__$Back_BackEaseInOut.__name__ =
    "motion.easing._Back.BackEaseInOut"),
    (motion_easing__$Back_BackEaseInOut.__interfaces__ = [
      motion_easing_IEasing,
    ]),
    Object.assign(motion_easing__$Back_BackEaseInOut.prototype, {
      __class__: motion_easing__$Back_BackEaseInOut,
    });
  class motion_easing__$Back_BackEaseOut {
    constructor(e) {
      this.s = e;
    }
    calculate(e) {
      return --e * e * ((this.s + 1) * e + this.s) + 1;
    }
    ease(e, t, a, n) {
      return a * ((e = e / n - 1) * e * ((this.s + 1) * e + this.s) + 1) + t;
    }
  }
  (motion_easing__$Back_BackEaseOut.__name__ =
    "motion.easing._Back.BackEaseOut"),
    (motion_easing__$Back_BackEaseOut.__interfaces__ = [motion_easing_IEasing]),
    Object.assign(motion_easing__$Back_BackEaseOut.prototype, {
      __class__: motion_easing__$Back_BackEaseOut,
    });
  class motion_easing_Back {
    static easeInWith(e) {
      return new motion_easing__$Back_BackEaseIn(e);
    }
    static easeInOutWith(e) {
      return new motion_easing__$Back_BackEaseInOut(e);
    }
    static easeOutWith(e) {
      return new motion_easing__$Back_BackEaseOut(e);
    }
  }
  motion_easing_Back.__name__ = "motion.easing.Back";
  class motion_easing_Linear {
    static get_easeNone() {
      return new motion_easing_LinearEaseNone();
    }
  }
  (motion_easing_Linear.__name__ = "motion.easing.Linear"),
    (motion_easing_Linear.__properties__ = { get_easeNone: "get_easeNone" });
  class motion_easing_LinearEaseNone {
    constructor() {}
    calculate(e) {
      return e;
    }
    ease(e, t, a, n) {
      return (a * e) / n + t;
    }
  }
  (motion_easing_LinearEaseNone.__name__ = "motion.easing.LinearEaseNone"),
    (motion_easing_LinearEaseNone.__interfaces__ = [motion_easing_IEasing]),
    Object.assign(motion_easing_LinearEaseNone.prototype, {
      __class__: motion_easing_LinearEaseNone,
    });
  class motion_easing__$Quad_QuadEaseIn {
    constructor() {}
    calculate(e) {
      return e * e;
    }
    ease(e, t, a, n) {
      return a * (e /= n) * e + t;
    }
  }
  (motion_easing__$Quad_QuadEaseIn.__name__ = "motion.easing._Quad.QuadEaseIn"),
    (motion_easing__$Quad_QuadEaseIn.__interfaces__ = [motion_easing_IEasing]),
    Object.assign(motion_easing__$Quad_QuadEaseIn.prototype, {
      __class__: motion_easing__$Quad_QuadEaseIn,
    });
  class motion_easing__$Quad_QuadEaseInOut {
    constructor() {}
    calculate(e) {
      return (e *= 2) < 1 ? 0.5 * e * e : -0.5 * ((e - 1) * (e - 3) - 1);
    }
    ease(e, t, a, n) {
      return (e /= n / 2) < 1
        ? (a / 2) * e * e + t
        : (-a / 2) * ((e - 1) * (e - 3) - 1) + t;
    }
  }
  (motion_easing__$Quad_QuadEaseInOut.__name__ =
    "motion.easing._Quad.QuadEaseInOut"),
    (motion_easing__$Quad_QuadEaseInOut.__interfaces__ = [
      motion_easing_IEasing,
    ]),
    Object.assign(motion_easing__$Quad_QuadEaseInOut.prototype, {
      __class__: motion_easing__$Quad_QuadEaseInOut,
    });
  class motion_easing__$Quad_QuadEaseOut {
    constructor() {}
    calculate(e) {
      return -e * (e - 2);
    }
    ease(e, t, a, n) {
      return -a * (e /= n) * (e - 2) + t;
    }
  }
  (motion_easing__$Quad_QuadEaseOut.__name__ =
    "motion.easing._Quad.QuadEaseOut"),
    (motion_easing__$Quad_QuadEaseOut.__interfaces__ = [motion_easing_IEasing]),
    Object.assign(motion_easing__$Quad_QuadEaseOut.prototype, {
      __class__: motion_easing__$Quad_QuadEaseOut,
    });
  class motion_easing_Quad {}
  motion_easing_Quad.__name__ = "motion.easing.Quad";
  class motion_easing__$Quart_QuartEaseIn {
    constructor() {}
    calculate(e) {
      return e * e * e * e;
    }
    ease(e, t, a, n) {
      return a * (e /= n) * e * e * e + t;
    }
  }
  (motion_easing__$Quart_QuartEaseIn.__name__ =
    "motion.easing._Quart.QuartEaseIn"),
    (motion_easing__$Quart_QuartEaseIn.__interfaces__ = [
      motion_easing_IEasing,
    ]),
    Object.assign(motion_easing__$Quart_QuartEaseIn.prototype, {
      __class__: motion_easing__$Quart_QuartEaseIn,
    });
  class motion_easing__$Quart_QuartEaseInOut {
    constructor() {}
    calculate(e) {
      return (e *= 2) < 1
        ? 0.5 * e * e * e * e
        : -0.5 * ((e -= 2) * e * e * e - 2);
    }
    ease(e, t, a, n) {
      return (e /= n / 2) < 1
        ? (a / 2) * e * e * e * e + t
        : (-a / 2) * ((e -= 2) * e * e * e - 2) + t;
    }
  }
  (motion_easing__$Quart_QuartEaseInOut.__name__ =
    "motion.easing._Quart.QuartEaseInOut"),
    (motion_easing__$Quart_QuartEaseInOut.__interfaces__ = [
      motion_easing_IEasing,
    ]),
    Object.assign(motion_easing__$Quart_QuartEaseInOut.prototype, {
      __class__: motion_easing__$Quart_QuartEaseInOut,
    });
  class motion_easing__$Quart_QuartEaseOut {
    constructor() {}
    calculate(e) {
      return -(--e * e * e * e - 1);
    }
    ease(e, t, a, n) {
      return -a * ((e = e / n - 1) * e * e * e - 1) + t;
    }
  }
  (motion_easing__$Quart_QuartEaseOut.__name__ =
    "motion.easing._Quart.QuartEaseOut"),
    (motion_easing__$Quart_QuartEaseOut.__interfaces__ = [
      motion_easing_IEasing,
    ]),
    Object.assign(motion_easing__$Quart_QuartEaseOut.prototype, {
      __class__: motion_easing__$Quart_QuartEaseOut,
    });
  class motion_easing_Quart {}
  motion_easing_Quart.__name__ = "motion.easing.Quart";
  class motion_easing__$Sine_SineEaseIn {
    constructor() {}
    calculate(e) {
      return 1 - Math.cos(e * (Math.PI / 2));
    }
    ease(e, t, a, n) {
      return -a * Math.cos((e / n) * (Math.PI / 2)) + a + t;
    }
  }
  (motion_easing__$Sine_SineEaseIn.__name__ = "motion.easing._Sine.SineEaseIn"),
    (motion_easing__$Sine_SineEaseIn.__interfaces__ = [motion_easing_IEasing]),
    Object.assign(motion_easing__$Sine_SineEaseIn.prototype, {
      __class__: motion_easing__$Sine_SineEaseIn,
    });
  class motion_easing__$Sine_SineEaseInOut {
    constructor() {}
    calculate(e) {
      return -(Math.cos(Math.PI * e) - 1) / 2;
    }
    ease(e, t, a, n) {
      return (-a / 2) * (Math.cos((Math.PI * e) / n) - 1) + t;
    }
  }
  (motion_easing__$Sine_SineEaseInOut.__name__ =
    "motion.easing._Sine.SineEaseInOut"),
    (motion_easing__$Sine_SineEaseInOut.__interfaces__ = [
      motion_easing_IEasing,
    ]),
    Object.assign(motion_easing__$Sine_SineEaseInOut.prototype, {
      __class__: motion_easing__$Sine_SineEaseInOut,
    });
  class motion_easing__$Sine_SineEaseOut {
    constructor() {}
    calculate(e) {
      return Math.sin(e * (Math.PI / 2));
    }
    ease(e, t, a, n) {
      return a * Math.sin((e / n) * (Math.PI / 2)) + t;
    }
  }
  (motion_easing__$Sine_SineEaseOut.__name__ =
    "motion.easing._Sine.SineEaseOut"),
    (motion_easing__$Sine_SineEaseOut.__interfaces__ = [motion_easing_IEasing]),
    Object.assign(motion_easing__$Sine_SineEaseOut.prototype, {
      __class__: motion_easing__$Sine_SineEaseOut,
    });
  class motion_easing_Sine {}
  motion_easing_Sine.__name__ = "motion.easing.Sine";
  class utils_RaycastUtils {
    static PlaneRaycast(e, t, a, n) {
      if (0 == n.dot(e)) return null;
      var i = e.clone().mulScalar(-1).dot(a.clone().sub(t)) / n.dot(e);
      return a.clone().add(n.clone().mulScalar(i));
    }
  }
  function $getIterator(e) {
    return e instanceof Array ? HxOverrides.iter(e) : e.iterator();
  }
  function $bind(e, t) {
    return null == t
      ? null
      : (null == t.__id__ && (t.__id__ = $global.$haxeUID++),
        null == e.hx__closures__
          ? (e.hx__closures__ = {})
          : (a = e.hx__closures__[t.__id__]),
        null == a && ((a = t.bind(e)), (e.hx__closures__[t.__id__] = a)),
        a);
    var a;
  }
  if (
    ((utils_RaycastUtils.__name__ = "utils.RaycastUtils"),
    ($global.$haxeUID |= 0),
    pc.registerScript(APIManager, "aPIManager"),
    APIManager.attributes.add("adLoadingIcon", {
      type: "asset",
      assetType: "sprite",
    }),
    APIManager.attributes.add("adLoadedIcon", {
      type: "asset",
      assetType: "sprite",
    }),
    APIManager.attributes.add("skipItIcon", {
      type: "asset",
      assetType: "sprite",
    }),
    APIManager.attributes.add("ghostTube_adIcon", {
      type: "asset",
      assetType: "sprite",
    }),
    APIManager.attributes.add("rewardedTopIcon", {
      type: "asset",
      assetType: "sprite",
    }),
    pc.registerScript(AdLoadingIcon, "adLoadingIcon"),
    AdLoadingIcon.attributes.add("placement", { type: "string", default: "" }),
    AdLoadingIcon.attributes.add("speed", { type: "number", default: 10 }),
    AdLoadingIcon.attributes.add("adBtn", { type: "entity" }),
    AdLoadingIcon.attributes.add("eoe", { type: "entity", array: !0 }),
    pc.registerScript(CheatsWindow, "cheatsWindow"),
    pc.registerScript(CheatsWindowWatcher, "cheatsWindowWatcher"),
    pc.registerScript(CoinsCollector, "coinsCollector"),
    CoinsCollector.attributes.add("analyticsId", {
      type: "string",
      default: "",
    }),
    CoinsCollector.attributes.add("coinsToSpawn", {
      type: "number",
      default: 30,
    }),
    CoinsCollector.attributes.add("totalCoinsToAdd", {
      type: "number",
      default: 150,
    }),
    CoinsCollector.attributes.add("minSpawnGap", {
      type: "number",
      default: 0.2,
    }),
    CoinsCollector.attributes.add("maxSpawnGap", {
      type: "number",
      default: 0.2,
    }),
    CoinsCollector.attributes.add("circleRadius", {
      type: "number",
      default: 150,
    }),
    CoinsCollector.attributes.add("moveSpeed", {
      type: "number",
      default: 2300,
    }),
    CoinsCollector.attributes.add("minMoveSpeedInCircle", {
      type: "number",
      default: 1950,
    }),
    CoinsCollector.attributes.add("maxMoveSpeedInCircle", {
      type: "number",
      default: 2100,
    }),
    CoinsCollector.attributes.add("is2dCoins", {
      type: "boolean",
      default: !1,
    }),
    CoinsCollector.attributes.add("callToMain", {
      type: "boolean",
      default: !1,
    }),
    CoinsCollector.attributes.add("coinPrefab", {
      type: "asset",
      assetType: "template",
    }),
    CoinsCollector.attributes.add("targetPos", { type: "entity" }),
    pc.registerScript(
      CoinsCollectorScreenSpaceCam,
      "coinsCollectorScreenSpaceCam"
    ),
    CoinsCollectorScreenSpaceCam.attributes.add("coinPrefab", {
      type: "asset",
      default: null,
    }),
    CoinsCollectorScreenSpaceCam.attributes.add("coinsToSpawn", {
      type: "number",
      default: 30,
    }),
    CoinsCollectorScreenSpaceCam.attributes.add("totalCoinsToAdd", {
      type: "number",
      default: 150,
    }),
    CoinsCollectorScreenSpaceCam.attributes.add("targetPos", {
      type: "entity",
      default: null,
    }),
    CoinsCollectorScreenSpaceCam.attributes.add("minSpawnGap", {
      type: "number",
      default: 0.2,
    }),
    CoinsCollectorScreenSpaceCam.attributes.add("maxSpawnGap", {
      type: "number",
      default: 0.2,
    }),
    CoinsCollectorScreenSpaceCam.attributes.add("circleRadius", {
      type: "number",
      default: 2.5,
    }),
    CoinsCollectorScreenSpaceCam.attributes.add("moveSpeed", {
      type: "number",
      default: 2,
    }),
    CoinsCollectorScreenSpaceCam.attributes.add("minMoveSpeedInCircle", {
      type: "number",
      default: 100,
    }),
    CoinsCollectorScreenSpaceCam.attributes.add("maxMoveSpeedInCircle", {
      type: "number",
      default: 500,
    }),
    pc.registerScript(Coroutines, "coroutines"),
    null != pc.app && null != pc.app.root)
  ) {
    var entity = new pc.Entity("CoroutinesManager", pc.app);
    pc.app.root.addChild(entity), entity.addComponent("script");
    var cName = "coroutines";
    entity.script.create(cName);
  }
  pc.registerScript(CurrencyCollector, "currencyCollector"),
    CurrencyCollector.attributes.add("analyticsId", {
      type: "string",
      default: "",
    }),
    CurrencyCollector.attributes.add("currencyName", {
      type: "string",
      default: "",
    }),
    CurrencyCollector.attributes.add("targetPoint", {
      type: "entity",
      default: null,
    }),
    CurrencyCollector.attributes.add("items", { type: "entity", array: !0 }),
    CurrencyCollector.attributes.add("minSpeed", {
      type: "number",
      default: 1500,
    }),
    CurrencyCollector.attributes.add("maxSpeed", {
      type: "number",
      default: 1800,
    }),
    CurrencyCollector.attributes.add("amountToAdd", {
      type: "number",
      default: 0,
    }),
    pc.registerScript(GameConfig, "gameConfig"),
    GameConfig.attributes.add("useCrosspromo", {
      type: "boolean",
      default: !1,
    }),
    GameConfig.attributes.add("useWeeklyLb", { type: "boolean", default: !1 }),
    GameConfig.attributes.add("progressionPopup", {
      type: "boolean",
      default: !1,
    }),
    GameConfig.attributes.add("starSystemEnabled", {
      type: "boolean",
      default: !1,
    }),
    GameConfig.attributes.add("tubeAnimationSpeed", {
      type: "number",
      default: 0,
    }),
    GameConfig.attributes.add("audioAds", { type: "number", default: 0 }),
    GameConfig.attributes.add("preATT", { type: "boolean", default: !1 }),
    GameConfig.attributes.add("adPressureLvl", { type: "number", default: 0 }),
    GameConfig.attributes.add("useGhostTube", { type: "number", default: 0 }),
    GameConfig.attributes.add("useCapShop", { type: "boolean", default: !1 }),
    GameConfig.attributes.add("newUI", { type: "boolean", default: !1 }),
    GameConfig.attributes.add("starterPack", { type: "boolean", default: !1 }),
    GameConfig.attributes.add("starterPackType", {
      type: "number",
      default: 0,
    }),
    GameConfig.attributes.add("notEnoughMoneyPopup", {
      type: "boolean",
      default: !1,
    }),
    GameConfig.attributes.add("txg_GoalPage", { type: "boolean", default: !1 }),
    GameConfig.attributes.add("playgap", { type: "boolean", default: !1 }),
    GameConfig.attributes.add("StarterPackPopup", {
      type: "number",
      default: 0,
    }),
    GameConfig.attributes.add("useSkipIt", { type: "boolean", default: !1 }),
    GameConfig.attributes.add("useImmediateTransition", {
      type: "boolean",
      default: !1,
    }),
    pc.registerScript(GameLoseScreen, "gameLoseScreen"),
    pc.registerScript(GameManager, "gameManager"),
    GameManager.attributes.add("isTutorialLvl", {
      type: "boolean",
      default: !1,
    }),
    GameManager.attributes.add("isMakingLevel", {
      type: "boolean",
      default: !1,
    }),
    GameManager.attributes.add("isLvlPreset", { type: "boolean", default: !1 }),
    GameManager.attributes.add("canReset", { type: "boolean", default: !1 }),
    GameManager.attributes.add("lvlNumToForce", { type: "number", default: 0 }),
    GameManager.attributes.add("tubePrefab", {
      type: "asset",
      assetType: "template",
    }),
    GameManager.attributes.add("instTxtPrefab", {
      type: "asset",
      assetType: "template",
    }),
    GameManager.attributes.add("fillerTubeAngle", { type: "vec2", array: !0 }),
    GameManager.attributes.add("levelWinEvents", { type: "number", array: !0 }),
    GameManager.attributes.add("waterCols", { type: "rgba", array: !0 }),
    GameManager.attributes.add("foamCols", { type: "rgba", array: !0 }),
    GameManager.attributes.add("modes", {
      type: "json",
      schema: [
        { name: "name", type: "string" },
        { name: "achievedStars", type: "number" },
        { name: "starsToUnlock", type: "number" },
        { name: "totalLvls", type: "number" },
      ],
      array: !0,
    }),
    GameManager.attributes.add("lvlsHaveVarient", {
      type: "number",
      array: !0,
    }),
    GameManager.attributes.add("keyPrefab", {
      type: "asset",
      assetType: "template",
    }),
    GameManager.attributes.add("currTube", {
      type: "asset",
      assetType: "template",
    }),
    pc.registerScript(GameSettings, "gameSettings"),
    GameSettings.attributes.add("CLEAR_SAVES", {
      type: "boolean",
      default: !1,
    }),
    pc.registerScript(GiftBox, "giftBox"),
    GiftBox.attributes.add("boxNumber", { type: "number", default: 0 }),
    GiftBox.attributes.add("priceText", { type: "entity", default: null }),
    GiftBox.attributes.add("anim", { type: "entity", default: null }),
    GiftBox.attributes.add("boxObj", { type: "entity", default: null }),
    GiftBox.attributes.add("isTopRewardBox", { type: "boolean", default: !1 }),
    pc.registerScript(GiftBoxSystem, "giftBoxSystem"),
    GiftBoxSystem.attributes.add("grid", { type: "entity", default: null }),
    GiftBoxSystem.attributes.add("boxes3DCont", {
      type: "entity",
      default: null,
    }),
    GiftBoxSystem.attributes.add("coinsText", {
      type: "entity",
      default: null,
    }),
    GiftBoxSystem.attributes.add("coinsCollectors", {
      type: "entity",
      array: !0,
    }),
    GiftBoxSystem.attributes.add("boxPrices", { type: "number", array: !0 }),
    GiftBoxSystem.attributes.add("giftBoxes", { type: "entity", array: !0 }),
    GiftBoxSystem.attributes.add("keyImages", { type: "entity", array: !0 }),
    GiftBoxSystem.attributes.add("topRewardConfetti", {
      type: "entity",
      default: null,
    }),
    GiftBoxSystem.attributes.add("topRewardPercent", {
      type: "number",
      default: 30,
    }),
    GiftBoxSystem.attributes.add("boxesRawImage", {
      type: "entity",
      default: null,
    }),
    GiftBoxSystem.attributes.add("boxesRawImage_Cap", {
      type: "entity",
      default: null,
    }),
    GiftBoxSystem.attributes.add("isPriceTopReward", {
      type: "boolean",
      default: !1,
    }),
    GiftBoxSystem.attributes.add("topRewardText", {
      type: "entity",
      default: null,
    }),
    GiftBoxSystem.attributes.add("topRewardImageTube", {
      type: "entity",
      default: null,
    }),
    GiftBoxSystem.attributes.add("topRewardImageCap", {
      type: "entity",
      default: null,
    }),
    GiftBoxSystem.attributes.add("continueBtn", {
      type: "entity",
      default: null,
    }),
    GiftBoxSystem.attributes.add("getMoreKeysBtn", {
      type: "entity",
      default: null,
    }),
    GiftBoxSystem.attributes.add("infoText", { type: "entity", default: null }),
    pc.registerScript(IngameMenu, "ingameMenu"),
    IngameMenu.attributes.add("greyStar", {
      type: "asset",
      assetType: "sprite",
    }),
    IngameMenu.attributes.add("goldenStar", {
      type: "asset",
      assetType: "sprite",
    }),
    Input.Init(),
    pc.registerScript(Joystick, "joystick"),
    Joystick.attributes.add("radius", { type: "number", default: 200 }),
    Joystick.attributes.add("fixedJoystick", { type: "boolean", default: !0 }),
    pc.registerScript(LevelCompleteScreen, "levelCompleteScreen"),
    pc.registerScript(LevelManager, "levelManager"),
    LevelManager.attributes.add("colorsToSort", { type: "number", default: 4 }),
    LevelManager.attributes.add("minMoveToSort", {
      type: "number",
      default: 1,
    }),
    LevelManager.attributes.add("minTimeToSort", {
      type: "number",
      default: 15,
    }),
    pc.registerScript(LevelTFTMP, "levelTFTMP"),
    pc.registerScript(LoseScreen, "loseScreen"),
    pc.registerScript(MainManager, "mainManager"),
    MainManager.attributes.add("itemLocked", { type: "asset", default: null }),
    MainManager.attributes.add("itemUnlocked", {
      type: "asset",
      default: null,
    }),
    MainManager.attributes.add("itemSelected", {
      type: "asset",
      default: null,
    }),
    MainManager.attributes.add("itemUnlocked2", {
      type: "asset",
      default: null,
    }),
    MainManager.attributes.add("themeLockSprite", {
      type: "asset",
      default: null,
    }),
    MainManager.attributes.add("itemSelectedCol", { type: "rgba" }),
    MainManager.attributes.add("bgThemeSr", { type: "entity" }),
    MainManager.attributes.add("confetti", { type: "entity" }),
    pc.registerScript(OfflineReward, "offlineReward"),
    pc.registerScript(PauseOverlay, "pauseOverlay"),
    pc.registerScript(PiggyAnimReceiver, "piggyAnimReceiver"),
    PiggyAnimReceiver.attributes.add("lessCoins", {
      type: "entity",
      array: !0,
    }),
    PiggyAnimReceiver.attributes.add("moreCoins", {
      type: "entity",
      array: !0,
    }),
    PiggyAnimReceiver.attributes.add("targetPoint", {
      type: "entity",
      default: null,
    }),
    pc.registerScript(PingPongScale, "pingPongScale"),
    PingPongScale.attributes.add("minScale", {
      type: "vec3",
      default: [1, 1, 1],
    }),
    PingPongScale.attributes.add("maxScale", {
      type: "vec3",
      default: [1.1, 1.1, 1.1],
    }),
    PingPongScale.attributes.add("speed", { type: "number", default: 1 }),
    pc.registerScript(ProgressionBoxSystem, "progressionBoxSystem"),
    ProgressionBoxSystem.attributes.add("progressBoxAnim", { type: "entity" }),
    ProgressionBoxSystem.attributes.add("progSkipBtn", { type: "entity" }),
    ProgressionBoxSystem.attributes.add("progRewardBtn", { type: "entity" }),
    ProgressionBoxSystem.attributes.add("progClaimBtn", { type: "entity" }),
    ProgressionBoxSystem.attributes.add("progContinueBtn", { type: "entity" }),
    ProgressionBoxSystem.attributes.add("progImage", { type: "entity" }),
    ProgressionBoxSystem.attributes.add("progText", { type: "entity" }),
    ProgressionBoxSystem.attributes.add("itemImage", { type: "entity" }),
    ProgressionBoxSystem.attributes.add("btnAnimator", { type: "entity" }),
    ProgressionBoxSystem.attributes.add("progressionPanel", { type: "entity" }),
    pc.registerScript(ResizeLogoByScreen, "resizeLogoByScreen"),
    pc.registerScript(RewardScale, "rewardScale"),
    pc.registerScript(RotationOnAxis, "rotationOnAxis"),
    RotationOnAxis.attributes.add("xAxis", { type: "boolean", default: !1 }),
    RotationOnAxis.attributes.add("yAxis", { type: "boolean", default: !1 }),
    RotationOnAxis.attributes.add("zAxis", { type: "boolean", default: !0 }),
    RotationOnAxis.attributes.add("speed", { type: "number", default: 10 }),
    pc.registerScript(ScaloMeter, "scaloMeter"),
    pc.registerScript(SettingsButtonsManager, "settingsButtonsManager"),
    pc.registerScript(ShopItems, "shopItems"),
    ShopItems.attributes.add("itemNum", { type: "number", default: 0 }),
    ShopItems.attributes.add("shopCategory", {
      type: "number",
      default: 0,
      enum: [{ Tube: 0 }, { Theme: 1 }, { Cap: 2 }],
    }),
    ShopItems.attributes.add("defaultLocked", { type: "boolean", default: !0 }),
    ShopItems.attributes.add("myImage", { type: "entity", default: null }),
    ShopItems.attributes.add("itemImage", { type: "entity", default: null }),
    pc.registerScript(ShopSwitchBtnsHandler, "shopSwitchBtnsHandler"),
    ShopSwitchBtnsHandler.attributes.add("buttons", {
      type: "json",
      array: !0,
      schema: [
        { name: "button", type: "entity", default: null },
        { name: "shopPanel", type: "entity", default: null },
        { name: "imageEntity", type: "entity", default: null },
        {
          name: "activeSprite",
          type: "asset",
          default: null,
          assetType: "sprite",
        },
        {
          name: "inactiveSprite",
          type: "asset",
          default: null,
          assetType: "sprite",
        },
        { name: "uiManagerCallback", type: "string", default: "" },
      ],
    }),
    pc.registerScript(SleepZParticles, "sleepZParticles"),
    SleepZParticles.attributes.add("baseEntity", {
      type: "entity",
      default: null,
    }),
    SleepZParticles.attributes.add("rateOverTime", {
      type: "vec2",
      default: [2, 5],
    }),
    SleepZParticles.attributes.add("lifetime", {
      type: "vec2",
      default: [0.5, 0.75],
    }),
    SleepZParticles.attributes.add("speed", { type: "vec2", default: [1, 2] }),
    SleepZParticles.attributes.add("startSize", {
      type: "vec2",
      default: [0.5, 1.5],
    }),
    pc.registerScript(SortingGroup, "sortingGroup"),
    SortingGroup.attributes.add("orderInLayer", { type: "number", default: 0 }),
    pc.registerScript(SortingGroupsManager, "sortingGroupsManager"),
    pc.registerScript(SpinItem, "spinItem"),
    SpinItem.attributes.add("percentage", { type: "number", default: 5 }),
    SpinItem.attributes.add("itemName", {
      type: "number",
      default: 0,
      enum: [
        { gems: 0 },
        { coins: 1 },
        { undoMoves: 2 },
        { xtraTubes: 3 },
        { hints: 4 },
        { skips: 5 },
        { spins: 6 },
      ],
    }),
    SpinItem.attributes.add("quantity", { type: "number", default: 1 }),
    SpinItem.attributes.add("itemSp", { type: "asset", default: null }),
    pc.registerScript(SpinWheel, "spinWheel"),
    SpinWheel.attributes.add("panel", { type: "entity", default: null }),
    SpinWheel.attributes.add("spinBtn", { type: "entity", default: null }),
    SpinWheel.attributes.add("spinWithAdBtn", {
      type: "entity",
      default: null,
    }),
    SpinWheel.attributes.add("crossBtn", { type: "entity", default: null }),
    SpinWheel.attributes.add("spinNowBg", { type: "entity", default: null }),
    SpinWheel.attributes.add("timerBg", { type: "entity", default: null }),
    SpinWheel.attributes.add("coinsTxt", { type: "entity", default: null }),
    SpinWheel.attributes.add("coinTargetPos", {
      type: "entity",
      default: null,
    }),
    SpinWheel.attributes.add("gemsTxt", { type: "entity", default: null }),
    SpinWheel.attributes.add("gemTargetPos", { type: "entity", default: null }),
    SpinWheel.attributes.add("skipsTxt", { type: "entity", default: null }),
    SpinWheel.attributes.add("skipsTargetPos", {
      type: "entity",
      default: null,
    }),
    SpinWheel.attributes.add("undoTxt", { type: "entity", default: null }),
    SpinWheel.attributes.add("undoTargetPos", {
      type: "entity",
      default: null,
    }),
    SpinWheel.attributes.add("xtraTubeTxt", { type: "entity", default: null }),
    SpinWheel.attributes.add("xtraTargetPos", {
      type: "entity",
      default: null,
    }),
    SpinWheel.attributes.add("hintsTxt", { type: "entity", default: null }),
    SpinWheel.attributes.add("hintTargetPos", {
      type: "entity",
      default: null,
    }),
    SpinWheel.attributes.add("spinWheel", { type: "entity", default: null }),
    SpinWheel.attributes.add("stopper", { type: "entity", default: null }),
    SpinWheel.attributes.add("rounds", { type: "number", default: 3 }),
    SpinWheel.attributes.add("rotaionTime", { type: "number", default: 3 }),
    SpinWheel.attributes.add("earnImages", { type: "entity", array: !0 }),
    SpinWheel.attributes.add("spinItemsEntities", {
      type: "entity",
      array: !0,
    }),
    pc.registerScript(SpriteMask, "spriteMask"),
    SpriteMask.attributes.add("showInside", { type: "boolean", default: !0 }),
    pc.registerScript(SpriteMasked, "spriteMasked"),
    (String.prototype.__class__ = String),
    (String.__name__ = "String"),
    (Array.__name__ = "Array"),
    (Date.prototype.__class__ = Date),
    (Date.__name__ = "Date");
  var Int = {},
    Dynamic = {},
    Float = Number,
    Bool = Boolean,
    Class = {},
    Enum = {};
  pc.registerScript(Stopper, "stopper"),
    Stopper.attributes.add("rotResetSpeed", { type: "number", default: 10 }),
    Stopper.attributes.add("hitMaxAng", { type: "number", default: 50 }),
    pc.registerScript(SubLvlBtn, "subLvlBtn"),
    SubLvlBtn.attributes.add("slBtn", { type: "entity", default: null }),
    SubLvlBtn.attributes.add("lvlText", { type: "entity", default: null }),
    SubLvlBtn.attributes.add("bar", { type: "entity", default: null }),
    SubLvlBtn.attributes.add("starText", { type: "entity", default: null }),
    pc.registerScript(SwipeShopTab, "swipeShopTab"),
    SwipeShopTab.attributes.add("mover", { type: "entity", default: null }),
    SwipeShopTab.attributes.add("percentThreshold", {
      type: "number",
      default: 0.2,
    }),
    SwipeShopTab.attributes.add("easing", { type: "number", default: 0.5 }),
    SwipeShopTab.attributes.add("canvWidth", { type: "number", default: 1003 }),
    SwipeShopTab.attributes.add("totalPages", { type: "number", default: 1 }),
    SwipeShopTab.attributes.add("dotImages", { type: "entity", array: !0 }),
    SwipeShopTab.attributes.add("unfillDot", { type: "asset", default: null }),
    SwipeShopTab.attributes.add("filledDot", { type: "asset", default: null }),
    pc.registerScript(TimerDailySpin, "timerDailySpin"),
    pc.registerScript(TubeController, "tubeController"),
    pc.registerScript(
      TubeControllerForceSettings,
      "tubeControllerForceSettings"
    ),
    TubeControllerForceSettings.attributes.add("filledColors", {
      type: "number",
      default: 0,
    }),
    TubeControllerForceSettings.attributes.add("colorNames", {
      type: "number",
      array: !0,
    }),
    TubeControllerForceSettings.attributes.add("haveKey", {
      type: "boolean",
      default: !1,
    }),
    pc.registerScript(TubeData, "tubeData"),
    TubeData.attributes.add("BlinkAnim", { type: "entity" }),
    TubeData.attributes.add("blinkArrow", { type: "entity" }),
    TubeData.attributes.add("WaterPortions", { type: "entity", array: !0 }),
    TubeData.attributes.add("WaterPortionsTilted", {
      type: "entity",
      array: !0,
    }),
    TubeData.attributes.add("addIcon", { type: "entity" }),
    TubeData.attributes.add("tubeBack", { type: "entity" }),
    TubeData.attributes.add("TubeBackSprite", { type: "entity" }),
    TubeData.attributes.add("TubeFrontSprite", { type: "entity" }),
    TubeData.attributes.add("TubeFoam", { type: "entity" }),
    TubeData.attributes.add("TubeFoamTilted", { type: "entity" }),
    TubeData.attributes.add("topPointRight", { type: "entity" }),
    TubeData.attributes.add("topPointLeft", { type: "entity" }),
    TubeData.attributes.add("fillPoints", { type: "entity", array: !0 }),
    TubeData.attributes.add("flows", {
      type: "json",
      schema: [
        { name: "flowPar", type: "entity" },
        { name: "flowScaler", type: "entity" },
        { name: "flowRd", type: "entity" },
      ],
      array: !0,
    }),
    TubeData.attributes.add("ParticleParent", { type: "entity" }),
    TubeData.attributes.add("tickMark", { type: "entity", array: !0 }),
    TubeData.attributes.add("ghostTubeBubble", { type: "entity" }),
    TubeData.attributes.add("hitZone", { type: "entity" }),
    pc.registerScript(TutorialManager, "tutorialManager"),
    TutorialManager.attributes.add("vals", { type: "number", array: !0 }),
    pc.registerScript(UIManager, "uIManager"),
    UIManager.attributes.add("tutorialAnim", { type: "entity", default: null }),
    UIManager.attributes.add("tutorialPrefab", {
      type: "asset",
      default: null,
    }),
    UIManager.attributes.add("mainPanel", { type: "entity", default: null }),
    UIManager.attributes.add("mmHomeBtn", { type: "entity", default: null }),
    UIManager.attributes.add("mmLevelsBtn", { type: "entity", default: null }),
    UIManager.attributes.add("mmShopBtn", { type: "entity", default: null }),
    UIManager.attributes.add("mmMainMenu", { type: "entity", default: null }),
    UIManager.attributes.add("mmLevelsCont", { type: "entity", default: null }),
    UIManager.attributes.add("shopPanelB", { type: "entity", default: null }),
    UIManager.attributes.add("mmPiggyImage", { type: "entity", default: null }),
    UIManager.attributes.add("sleepyPig", { type: "asset", default: null }),
    UIManager.attributes.add("normalPig", { type: "asset", default: null }),
    UIManager.attributes.add("mmSpinTimer", { type: "entity", default: null }),
    UIManager.attributes.add("spinPanel", { type: "entity", default: null }),
    UIManager.attributes.add("spinTimerBg", { type: "entity", default: null }),
    UIManager.attributes.add("spinPrefab", { type: "asset", array: !0 }),
    UIManager.attributes.add("spinPrefabYoutube", { type: "asset", array: !0 }),
    UIManager.attributes.add("fadeSpeed", { type: "number", default: 0.02 }),
    UIManager.attributes.add("nmmPanel", { type: "entity", default: null }),
    UIManager.attributes.add("powerupImage", { type: "entity", default: null }),
    UIManager.attributes.add("xtraTubeSp", { type: "asset", default: null }),
    UIManager.attributes.add("nmmXtraTubeBtn", {
      type: "entity",
      default: null,
    }),
    UIManager.attributes.add("nmmXtraTubeAd", {
      type: "entity",
      default: null,
    }),
    UIManager.attributes.add("nmmXtraTubePlus", {
      type: "entity",
      default: null,
    }),
    UIManager.attributes.add("nmmXtraTubeCountParent", {
      type: "entity",
      default: null,
    }),
    UIManager.attributes.add("skipLvlSp", { type: "asset", default: null }),
    UIManager.attributes.add("descriptionText", {
      type: "entity",
      default: null,
    }),
    UIManager.attributes.add("nmmUndoAd", { type: "entity", default: null }),
    UIManager.attributes.add("nmmUndoPlus", { type: "entity", default: null }),
    UIManager.attributes.add("nmmUndoCountParent", {
      type: "entity",
      default: null,
    }),
    UIManager.attributes.add("losePanel", { type: "entity", default: null }),
    UIManager.attributes.add("lpModeText", { type: "entity", default: null }),
    UIManager.attributes.add("undoVideoIconOnLosePanel", {
      type: "entity",
      default: null,
    }),
    UIManager.attributes.add("pausedPanel", { type: "entity", default: null }),
    UIManager.attributes.add("toggleOnSprite", {
      type: "asset",
      default: null,
    }),
    UIManager.attributes.add("toggleOffSprite", {
      type: "asset",
      default: null,
    }),
    UIManager.attributes.add("settingsPanelB", {
      type: "entity",
      default: null,
    }),
    UIManager.attributes.add("audioToggleImageB", {
      type: "entity",
      default: null,
    }),
    UIManager.attributes.add("musicToggleImageB", {
      type: "entity",
      default: null,
    }),
    UIManager.attributes.add("slvlBtnPrefab", { type: "asset", default: null }),
    UIManager.attributes.add("slvlPanel", { type: "entity", default: null }),
    UIManager.attributes.add("slvlBtnParent", {
      type: "entity",
      default: null,
    }),
    UIManager.attributes.add("btnPopSpeed", { type: "number", default: 0.05 }),
    UIManager.attributes.add("lvlBtn1Star", { type: "asset", default: null }),
    UIManager.attributes.add("lvlBtn2Star", { type: "asset", default: null }),
    UIManager.attributes.add("lvlBtn3Star", { type: "asset", default: null }),
    UIManager.attributes.add("lvlBtnPrefab", { type: "asset", default: null }),
    UIManager.attributes.add("levelPanel", { type: "entity", default: null }),
    UIManager.attributes.add("lvlScrollRect", {
      type: "entity",
      default: null,
    }),
    UIManager.attributes.add("lvlParentGrid", {
      type: "entity",
      default: null,
    }),
    UIManager.attributes.add("offlineTimerTextB", {
      type: "entity",
      default: null,
    }),
    UIManager.attributes.add("piggyPop", { type: "entity", default: null }),
    UIManager.attributes.add("piggySleepPop", {
      type: "entity",
      default: null,
    }),
    UIManager.attributes.add("pigAnim", { type: "entity", default: null }),
    UIManager.attributes.add("orRewardBtn", { type: "entity", default: null }),
    UIManager.attributes.add("orSimpleBtn", { type: "entity", default: null }),
    UIManager.attributes.add("meterAnim", { type: "entity", default: null }),
    UIManager.attributes.add("meterPriceText", {
      type: "entity",
      default: null,
    }),
    UIManager.attributes.add("mmCoinChestBar", {
      type: "entity",
      default: null,
    }),
    UIManager.attributes.add("coinsChestPop", {
      type: "entity",
      default: null,
    }),
    UIManager.attributes.add("coinChestOpened", {
      type: "entity",
      default: null,
    }),
    UIManager.attributes.add("ccpOpenedCoins", {
      type: "entity",
      default: null,
    }),
    UIManager.attributes.add("coinChestClosed", {
      type: "entity",
      default: null,
    }),
    UIManager.attributes.add("coinChestBar", { type: "entity", default: null }),
    UIManager.attributes.add("coinChestStarCount", {
      type: "entity",
      default: null,
    }),
    UIManager.attributes.add("coinChestBtn", { type: "entity", default: null }),
    UIManager.attributes.add("coinChestInfo", {
      type: "entity",
      default: null,
    }),
    UIManager.attributes.add("coinChest_CC", { type: "entity", default: null }),
    UIManager.attributes.add("bgThemeSprite", { type: "asset", array: !0 }),
    UIManager.attributes.add("corkSprite", { type: "asset", array: !0 }),
    UIManager.attributes.add("notEnoughGems", {
      type: "entity",
      default: null,
    }),
    UIManager.attributes.add("shopAdCcB", { type: "entity", default: null }),
    UIManager.attributes.add("ShopTopBarCap", {
      type: "entity",
      default: null,
    }),
    UIManager.attributes.add("NotEnoughMoney_Popup", {
      type: "entity",
      default: null,
    }),
    UIManager.attributes.add("shopBuyNotif", { type: "entity", default: null }),
    UIManager.attributes.add("newGpPowerTutPanel", {
      type: "entity",
      default: null,
    }),
    UIManager.attributes.add("newGpPowerXtraCount", {
      type: "entity",
      default: null,
    }),
    UIManager.attributes.add("mainCoinTexts", { type: "entity", array: !0 }),
    UIManager.attributes.add("tubeConfetti", { type: "entity" }),
    UIManager.attributes.add("xtraTubeCounters", { type: "entity", array: !0 }),
    UIManager.attributes.add("undoCounters", { type: "entity", array: !0 }),
    UIManager.attributes.add("hintsCounters", { type: "entity", array: !0 }),
    UIManager.attributes.add("skipsCounters", { type: "entity", array: !0 }),
    UIManager.attributes.add("faderImage", { type: "entity" }),
    UIManager.attributes.add("blackImage", { type: "entity" }),
    UIManager.attributes.add("chestboxPrefabB", {
      type: "asset",
      assetType: "template",
    }),
    UIManager.attributes.add("objDisOnChest", { type: "entity", array: !0 }),
    UIManager.attributes.add("progressObj", {
      type: "asset",
      assetType: "template",
    }),
    UIManager.attributes.add("tubesPanel1", {
      type: "json",
      schema: [
        { name: "buyBtn", type: "entity", default: null },
        { name: "buyPriceText", type: "entity", default: null },
        { name: "shopItemsEntities", type: "entity", array: !0 },
        { name: "buyPrices", type: "number", array: !0 },
      ],
    }),
    UIManager.attributes.add("tubesPanel2", {
      type: "json",
      schema: [
        { name: "buyBtn", type: "entity", default: null },
        { name: "buyPriceText", type: "entity", default: null },
        { name: "shopItemsEntities", type: "entity", array: !0 },
        { name: "buyPrices", type: "number", array: !0 },
      ],
    }),
    UIManager.attributes.add("themePanel1", {
      type: "json",
      schema: [
        { name: "buyBtn", type: "entity", default: null },
        { name: "buyPriceText", type: "entity", default: null },
        { name: "shopItemsEntities", type: "entity", array: !0 },
        { name: "buyPrices", type: "number", array: !0 },
      ],
    }),
    UIManager.attributes.add("themePanel2", {
      type: "json",
      schema: [
        { name: "buyBtn", type: "entity", default: null },
        { name: "buyPriceText", type: "entity", default: null },
        { name: "shopItemsEntities", type: "entity", array: !0 },
        { name: "buyPrices", type: "number", array: !0 },
      ],
    }),
    UIManager.attributes.add("capPanel1", {
      type: "json",
      schema: [
        { name: "buyBtn", type: "entity", default: null },
        { name: "buyPriceText", type: "entity", default: null },
        { name: "shopItemsEntities", type: "entity", array: !0 },
        { name: "buyPrices", type: "number", array: !0 },
      ],
    }),
    UIManager.attributes.add("capPanel2", {
      type: "json",
      schema: [
        { name: "buyBtn", type: "entity", default: null },
        { name: "buyPriceText", type: "entity", default: null },
        { name: "shopItemsEntities", type: "entity", array: !0 },
        { name: "buyPrices", type: "number", array: !0 },
      ],
    }),
    pc.registerScript(UIManagerClickBtn, "uIManagerClickBtn"),
    UIManagerClickBtn.attributes.add("famobiEventId", {
      type: "string",
      default: "",
    }),
    UIManagerClickBtn.attributes.add("famobiPlacement", {
      type: "string",
      default: "",
    }),
    UIManagerClickBtn.attributes.add("Callbacks", {
      type: "json",
      array: !0,
      schema: [
        { name: "method", type: "string" },
        { name: "arguments", type: "string", array: !0 },
      ],
    }),
    UIManagerClickBtn.attributes.add("SetActiveCalls", {
      type: "json",
      array: !0,
      schema: [
        { name: "entity", type: "entity" },
        { name: "enabled", type: "boolean" },
      ],
    }),
    pc.registerScript(WinScreen, "winScreen"),
    pc.registerScript(YoutubeDisabler, "youtubeDisabler"),
    (haxe_ds_ObjectMap.count = 0);
  var __map_reserved = {};
  Object.defineProperty(js__$Boot_HaxeError.prototype, "message", {
    get: function () {
      return String(this.val);
    },
  }),
    (js_Boot.__toStr = {}.toString),
    (APIManager.hasRewardedAd = !0),
    (APIManager.numSkipTickets = 0),
    (APIManager.GameInterface = window.GameInterface),
    (APIManager.CachedFeatures = new haxe_ds_StringMap()),
    (APIManager.hasFamobiRewardedAd = !1),
    (CheatsWindowWatcher.inited = !1),
    (Coroutines.coroutines = []),
    (Coroutines.onEndOfFrameCallbacks = []),
    (GameConfig.numLevelSkips = -1),
    (GameManager.capacity = 20),
    (GameManager.redoMoves = 1),
    (GameManager.recordingNodes = []),
    (GameManager.recordingNodes2 = []),
    (GameManager.lvlLoaded = 0),
    (GameManager.currLvlNum = 0),
    (GameManager.currModeNum = 1),
    (GameManager.currGroupNum = 1),
    (GameManager.currModeName = ""),
    (GameManager._SkipLvlCount = -1),
    (GameManager._EmptyTubesCount = -1),
    (GameManager._UndoMovesCount = -1),
    (GameManager._HintCounts = -1),
    (_$Vector3_Vector3_$Impl_$.kEpsilonNormalSqrt = 1e-15),
    (_$Vector3_Vector3_$Impl_$.back = _$Vector3_Vector3_$Impl_$.get_BACK()),
    (_$Vector3_Vector3_$Impl_$.down = _$Vector3_Vector3_$Impl_$.get_DOWN()),
    (_$Vector3_Vector3_$Impl_$.forward =
      _$Vector3_Vector3_$Impl_$.get_FORWARD()),
    (_$Vector3_Vector3_$Impl_$.left = _$Vector3_Vector3_$Impl_$.get_LEFT()),
    (_$Vector3_Vector3_$Impl_$.one = _$Vector3_Vector3_$Impl_$.get_ONE()),
    (_$Vector3_Vector3_$Impl_$.right = _$Vector3_Vector3_$Impl_$.get_RIGHT()),
    (_$Vector3_Vector3_$Impl_$.up = _$Vector3_Vector3_$Impl_$.get_UP()),
    (_$Vector3_Vector3_$Impl_$.zero = _$Vector3_Vector3_$Impl_$.get_ZERO()),
    (Input.inited = !1),
    (Input.mDownPos = new pc.Vec3(0, 0, 0)),
    (Input.curMPos = new pc.Vec3(0, 0, 0)),
    (Input.touchID = -1),
    (Input.mouseButtonsPressStates = [!1, !1, !1]),
    (Input.mouseButtonsWasPressStates = [!1, !1, !1]),
    (Input.mouseButtonsWasReleaseStates = [!1, !1, !1]),
    (LevelCompleteScreen.IsActive = !1),
    (LevelCompleteScreen.rwGetScaledRewardPlacement =
      "button.winscreen.getscaled"),
    (LevelsImporter.classicLevels = new haxe_ds_StringMap()),
    (LevelsImporter.hardLevels = new haxe_ds_StringMap()),
    (LevelsImporter.timedLevels = new haxe_ds_StringMap()),
    (LevelsImporter.FTUELevels = new haxe_ds_StringMap()),
    (LevelsImporter.inited = !1),
    (LevelsImporter.numLoadLeft = 0),
    (LoseScreen.isActivating = !1),
    (Main.LevelsDataLoaded = !1),
    (Main.GameReadySent = !1),
    (Main.isFamobiMuted = !1),
    (MainManager.normalFps = 150),
    (MainManager.uiFps = 80),
    (MainManager.tubeHeightUp = 0.5),
    (MainManager.pickedItemNum = []),
    (MainManager.SplashRemoveLeftFrames = 5),
    (MainManager.BgLoaded = !1),
    (_$MainManager_ShopCategory_$Impl_$.Tube = 0),
    (_$MainManager_ShopCategory_$Impl_$.Theme = 1),
    (_$MainManager_ShopCategory_$Impl_$.Cap = 2),
    (Mathf.Deg2Rad = 0.01745329251994),
    (Mathf.Rad2Deg = 57.2957795130823),
    (Mathf.PI = Math.PI),
    (OfflineReward.rewardGapHours = 8),
    (PauseOverlay.isActive = !1),
    (PiggyAnimReceiver.amountToSend = 0),
    (PlayerPrefs.inited = !1),
    (_$Quaternion_Quaternion_$Impl_$.ZERO = pc.Quat.ZERO),
    (_$Quaternion_Quaternion_$Impl_$.hMatrix = new pc.Mat4()),
    (_$Quaternion_Quaternion_$Impl_$.zeroVec =
      _$Vector3_Vector3_$Impl_$.get_ZERO()),
    (RewardScale.xRewardVal = 0),
    (SettingsButtonsManager.allSettingsButtons = []),
    (SortingGroup.AllSortingGroups = []),
    (SortingGroupsManager.inited = !1),
    (SpinWheel.stopperTryToStop = !1),
    (SpriteMask.curStencilRef = -1),
    (TimerDailySpin.spinGapHours = 24),
    (TutorialManager.tutorialVal = 0),
    (UIManager.totalStars = 0),
    (UIManager.isGameplaying = !1),
    (UIManager.lastBtnPressed = "PlayBtn"),
    (UIManager.progNeedsToUpdate = !1),
    (UIManager.isAudioOn = !0),
    (UIManager.isMusicOn = !0),
    (WinScreen.isActivating = !1),
    (motion_actuators_GenericActuator._hx_skip_constructor = !1),
    (motion_actuators_SimpleActuator.actuators = []),
    (motion_actuators_SimpleActuator.actuatorsLength = 0),
    (motion_actuators_SimpleActuator.addedEvent = !1),
    (motion_easing_Expo.easeIn = new motion_easing__$Expo_ExpoEaseIn()),
    (motion_easing_Expo.easeInOut = new motion_easing__$Expo_ExpoEaseInOut()),
    (motion_easing_Expo.easeOut = new motion_easing__$Expo_ExpoEaseOut()),
    (motion_Actuate.defaultActuator = motion_actuators_SimpleActuator),
    (motion_Actuate.defaultEase = motion_easing_Expo.easeOut),
    (motion_Actuate.targetLibraries = new haxe_ds_ObjectMap()),
    (motion_easing_Back.easeIn = new motion_easing__$Back_BackEaseIn(1.70158)),
    (motion_easing_Back.easeInOut = new motion_easing__$Back_BackEaseInOut(
      1.70158
    )),
    (motion_easing_Back.easeOut = new motion_easing__$Back_BackEaseOut(
      1.70158
    )),
    (motion_easing_Quad.easeIn = new motion_easing__$Quad_QuadEaseIn()),
    (motion_easing_Quad.easeInOut = new motion_easing__$Quad_QuadEaseInOut()),
    (motion_easing_Quad.easeOut = new motion_easing__$Quad_QuadEaseOut()),
    (motion_easing_Quart.easeIn = new motion_easing__$Quart_QuartEaseIn()),
    (motion_easing_Quart.easeInOut =
      new motion_easing__$Quart_QuartEaseInOut()),
    (motion_easing_Quart.easeOut = new motion_easing__$Quart_QuartEaseOut()),
    (motion_easing_Sine.easeIn = new motion_easing__$Sine_SineEaseIn()),
    (motion_easing_Sine.easeInOut = new motion_easing__$Sine_SineEaseInOut()),
    (motion_easing_Sine.easeOut = new motion_easing__$Sine_SineEaseOut()),
    Main.main();
})(
  "undefined" != typeof window
    ? window
    : "undefined" != typeof global
    ? global
    : "undefined" != typeof self
    ? self
    : this
);
var ParticleScalingFix = pc.createScript("particleScalingFix");
let originalScale;
ParticleScalingFix.attributes.add("scaleY", { type: "boolean" }),
  ParticleScalingFix.attributes.add("scaleX", { type: "boolean" }),
  (ParticleScalingFix.prototype.initialize = function () {
    (originalScale = { ...this.entity.getLocalScale() }),
      this.app.graphicsDevice.on("resizecanvas", this.onResizeCanvas, this),
      this.onResizeCanvas(
        this.app.graphicsDevice.width,
        this.app.graphicsDevice.height
      );
  }),
  (ParticleScalingFix.prototype.onResizeCanvas = function (i, a) {
    this.entity.setLocalScale(
      this.scaleX
        ? a > i
          ? (a / i) * originalScale.x
          : (i / a) * originalScale.x
        : originalScale.x,
      this.scaleY ? (i / a) * originalScale.y : originalScale.y,
      originalScale.z
    ),
      this.entity.particlesystem.reset();
  });
var TouchFix = pc.createScript("touchFix");
TouchFix.prototype.initialize = function () {
  const t = this.app.touch;
  t &&
    t.on(pc.EVENT_TOUCHEND, function (t) {
      t.event.preventDefault();
    });
};
pc.script.createLoadingScreen(function (e) {
  const t = document.createElement("div");
  (t.style.backgroundColor = "#232323"),
    (t.style.position = "absolute"),
    (t.style.top = "0"),
    (t.style.left = "0"),
    (t.style.height = "100%"),
    (t.style.width = "100%"),
    document.body.appendChild(t);
  const o = document.createElement("div");
  (o.style.position = "absolute"),
    (o.style.top = "50%"),
    (o.style.left = "25%"),
    (o.style.transform = "translateY(-50%)"),
    (o.style.width = "50%"),
    (o.style.height = "20px"),
    (o.style.backgroundColor = "#d3d3d3"),
    t.appendChild(o);
  const l = document.createElement("div");
  (l.style.height = "100%"),
    (l.style.backgroundColor = "#2847af"),
    (l.style.width = "0%"),
    o.appendChild(l);
  var n = 0;
  e.on("preload:end", function () {
    e.off("preload:progress");
  }),
    e.on("preload:progress", function (e) {
      let t = Math.floor(100 * e - 0.1);
      n != t &&
        void 0 !== window.GameInterface &&
        window.GameInterface.sendPreloadProgress(t),
        (n = t),
        (l.style.width = 100 * e + "%");
    }),
    e.once("start", () => {
      document.body.removeChild(t);
    });
});
var YoutubeSoundsFix = pc.createScript("youtubeSoundsFix");
(YoutubeSoundsFix.prototype.initialize = function () {
  pc.platform.ios &&
    this.app.touch.on(pc.EVENT_TOUCHEND, () => {
      ("interrupted" !== this.app.soundManager.context.state &&
        "suspended" !== this.app.soundManager.context.state) ||
        this.app.soundManager.context
          .resume()
          .then(() => {
            console.log("[iOS] Audio context restored");
          })
          .catch((t) => {
            console.warn(
              "[iOS] Could not restore audio context after suspending"
            );
          });
    }),
    (this.audioContextWasStarted = !1);
}),
  (YoutubeSoundsFix.prototype.checkSoundCurrentTime = function () {
    if (!this.audioContextWasStarted)
      return void setTimeout(() => this.checkSoundCurrentTime(), 500);
    const t = pc.app.soundManager._context.currentTime;
    setTimeout(() => {
      const e = pc.app.soundManager._context.currentTime;
      t === e && this.createNewAudioContext(),
        setTimeout(() => this.checkSoundCurrentTime(), 500);
    }, 1e3);
  }),
  (YoutubeSoundsFix.prototype.update = function (t) {
    this.audioContextWasStarted ||
      void 0 === pc.app.soundManager ||
      void 0 === pc.app.soundManager._context ||
      "running" != pc.app.soundManager._context.state ||
      (this.audioContextWasStarted = !0);
  }),
  (YoutubeSoundsFix.prototype.createNewAudioContext = function () {
    pc.app.soundManager._context.close(),
      (pc.app.soundManager._context = new AudioContext());
    try {
      pc.app.soundManager._context
        .resume()
        .then(() => {
          console.log("resumed");
        })
        .catch((t) => {
          console.log(t);
        });
    } catch (t) {
      console.log(t);
    }
    var t = pc.app.root.findComponents("sound");
    for (let e = 0; e < t.length; e++)
      for (let o in t[e].slots) {
        let n = t[e].slots[o];
        ((n.isPlaying && n.loop) || n.isPaused) && (n.stop(), n.play());
      }
  });
var LogoHandler = pc.createScript("logoHandler");
(LogoHandler.prototype.numClicks = 0),
  (LogoHandler.prototype.lastClickTime = -1),
  (LogoHandler.prototype.initialize = function () {
    this.entity.findByName("Button").button.on(
      "click",
      function (i) {
        -1 == this.lastClickTime || pc.now() - this.lastClickTime > 500
          ? ((this.numClicks = 1), (this.lastClickTime = pc.now()))
          : (this.numClicks++,
            (this.lastClickTime = pc.now()),
            this.numClicks >= 5 &&
              ((LogoHandler.lastClickTime = -1),
              (this.numClicks = 0),
              (this.entity.findByName("Window").enabled = !0)));
      },
      this
    );
  }),
  (LogoHandler.prototype.update = function (i) {});
var LogoWindow = pc.createScript("logoWindow");
LogoWindow.prototype.initialize = function () {
  this.entity.button.on(
    "click",
    function (i) {
      this.entity.enabled = !1;
    },
    this
  );
};
